from pathlib import Path
import shutil
out=Path('build/runs/20261107-125201-cumulative-diagnostic-budget-4bf1d7')
for name in ['check-runner.log','python-checks.log']:shutil.copy2(out/name,out/('initial-'+name))
p=out/'verify_batch.py';s=p.read_text().replace("r.returncode==1 and report['reasons']", "r.returncode==2 and report['reasons']").replace("expectedExitCode=1", "expectedExitCode=2");p.write_text(s)
