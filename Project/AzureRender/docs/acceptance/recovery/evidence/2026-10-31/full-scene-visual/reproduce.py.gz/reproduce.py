from pathlib import Path
import json,hashlib,subprocess,sys,time,os,re,shutil
import numpy as np
from PIL import Image
root=Path.cwd();run=Path(__file__).resolve().parent;out=run/'current-full';out.mkdir(exist_ok=False)
source=root/'build/runs/20261029-045743-snapshot-shading-budget-8ee0b1';project=source/'full-candidate/enclosure-sampler.azureproject';level=source/'full-candidate/scene/enclosure-sampler.azurelevel'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(project)=='7844d0921ac0b2df10f8d247b6e6b4b74971b3e9e33fff91f283a100a72f96c5'
assert sha(level)=='def6f52a0bccc9aca7aa270d5787b584a8b8b6e29cee39f487297ac135e4e14e'
description=json.loads(project.read_text(encoding='utf-8'));assert len(description['mounts'])==23 and all((project.parent/x['path']).is_dir() for x in description['mounts'])
old=source/'candidate-capture/frames';build=root/'build/ninja-msvc-release';player=build/'AzurePlayer.exe'
shaders={p.name:sha(p) for p in (build/'shaders').glob('*.spv')}
command=[str(player),'--project',str(project),'--width','2560','--height','1440','--capture-frames','12','--capture-fps','60','--capture-dir',str(out/'frames'),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--runtime-report',str(out/'runtime.json')]
report=dict(status='running',sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),workingSourceReceipt='docs/acceptance/nr/evidence/2026-10-31/projected-history-motion/summary.json',playerSha256=sha(player),shaders=shaders,project=str(project),projectSha256=sha(project),levelSha256=sha(level),referenceFrames=str(old),command=command,mountCount=23,timeoutSeconds=300)
shutil.copy2(Path('C:/Users/admin/AppData/Local/Temp/codex-clipboard-99ed1cf1-a78f-4532-a483-83334228e5b2.jpg'),run/'user-reference.jpg')
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8');(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
env=os.environ.copy();env.update(DOTNET_ROOT='D:/Tools/dotnet9',PYTHONUTF8='1',TEMP=str(out),TMP=str(out));env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
start=time.perf_counter()
try:
 with (out/'player.log').open('wb') as log:
  process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup);report['pid']=process.pid;(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
  try:exitCode=process.wait(timeout=300)
  except subprocess.TimeoutExpired:process.kill();process.wait();raise
 report['exitCode']=exitCode;assert exitCode==0
 text=(out/'player.log').read_text(encoding='utf-8',errors='replace');assert not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD|\[error\]',text,re.I)
 assert 'Allocator after unload: buffers=0 images=0' in text and 'Validation layer: disabled' in text
 runtime=json.loads((out/'runtime.json').read_text(encoding='utf-8-sig'));assert not runtime['scriptErrors'] and not runtime['presentationErrors']
 capture=json.loads((out/'frames/capture_manifest.json').read_text(encoding='utf-8-sig'));assert capture['width']==2560 and capture['height']==1440 and capture['capturedFrames']==12 and capture['antiAliasing']==1
 assert capture['screenReflectionComputeActive'] and capture['screenReflectionAlgorithm']=='linear'
 pairs=[]
 for image in sorted((out/'frames').glob('frame_*.png')):
  expected=old/image.name;a=np.asarray(Image.open(image).convert('RGB')).astype(np.int16);b=np.asarray(Image.open(expected).convert('RGB')).astype(np.int16);assert a.shape==b.shape==(1440,2560,3)
  delta=np.abs(a-b);pairs.append(dict(frame=image.name,pngBytesExact=image.read_bytes()==expected.read_bytes(),differentPixels=int(np.any(delta,axis=2).sum()),maximumChannelError=int(delta.max()),meanAbsoluteByteError=float(delta.mean()),outputSha256=sha(image),referenceSha256=sha(expected)))
 assert len(pairs)==12;report['comparisons']=pairs;report['capture']=capture
 assert sha(project)==report['projectSha256'] and sha(level)==report['levelSha256'] and sha(player)==report['playerSha256'] and shaders=={p.name:sha(p) for p in (build/'shaders').glob('*.spv')}
 report['status']='captured-comparison-recorded';print('Complete scene captured; exact PNGs:',sum(x['pngBytesExact'] for x in pairs),'/12; mean byte error:',[round(x['meanAbsoluteByteError'],6) for x in pairs],flush=True)
except Exception as error:report.update(status='failed',error=str(error));raise
finally:report['elapsedSeconds']=time.perf_counter()-start;(out/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
