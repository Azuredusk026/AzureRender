from pathlib import Path
import json,gzip,hashlib,subprocess,copy
root=Path.cwd();run=Path(__file__).resolve().parent;out=root/'docs/acceptance/recovery/evidence/2026-10-31/full-scene-character';out.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def archive(p,label):
 raw=p.read_bytes();target=out/(label+'.gz');target.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(target.read_bytes())==raw
 return dict(file=target.relative_to(root).as_posix(),bytes=target.stat().st_size,sha256=sha(target),rawSha256=sha(p))
hidden=read(run/'hidden/summary.json');repeat=read(run/'hidden-repeat/summary.json');visible=read(run/'visible/summary.json');candidate=read(run/'candidate-manifest.json')
assert hidden['status']=='failed' and hidden['error']=='Hidden actor changed complete environment PNGs'
assert repeat['status']=='diagnostic-complete' and all(repeat['repeatBytesExact'].values()) and not repeat['strictBaselinePassed']
assert visible['status']=='passed'
for case in (hidden,repeat,visible):
 assert case['exitCode']==0 and case['playerSha256']==hidden['playerSha256'] and case['shaderSet']==hidden['shaderSet']
 assert case['capture']['qaCameraPosition']==hidden['capture']['qaCameraPosition']
 assert case['capture']['gradeSettings']==hidden['capture']['gradeSettings']
 assert case['capture']['screenReflectionHistoryValid'] and case['capture']['screenReflectionTemporalActive']
original=root/'build/runs/20261029-045743-snapshot-shading-budget-8ee0b1/full-candidate';source=read(original/'scene/enclosure-sampler.azurelevel')
assert sha(original/'enclosure-sampler.azureproject')==candidate['sourceProjectSha256'] and sha(original/'scene/enclosure-sampler.azurelevel')==candidate['sourceLevelSha256']
for item in candidate['sharedActorInputs']:assert sha(original/item['file'])==sha(run/'project'/item['file'])==item['sha256']
levels={k:read(run/'project/scene'/('full-character-'+k+'.azurelevel')) for k in ('hidden','visible')}
for level in levels.values():
 assert level['nodes'][:-1]==source['nodes'] and level['resources'][:-1]==source['resources']
 assert {k:v for k,v in level.items() if k not in ('resources','nodes')}=={k:v for k,v in source.items() if k not in ('resources','nodes')}
 assert 'azure.character' not in level['nodes'][-1]['components']
check=copy.deepcopy(levels['visible']);check['nodes'][-1]['components']['azure.renderable']['data']['visible']=False;assert check==levels['hidden']
assert sha(root/'build/ninja-msvc-release/AzurePlayer.exe')==visible['playerSha256']
assert {p.name:sha(p) for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv')}==visible['shaderSet']
protected=read(run/'preserved-user-files.json')
for name,value in protected.items():assert sha(root/name)==value
retained=[]
for kind in ('hidden','hidden-repeat','visible'):
 for name in ('summary.json','player.log','runtime.json','command.json'):retained.append(archive(run/kind/name,kind+'-'+name))
for name in ('capture_case.py','repeat_hidden.py','prepare_candidate.py','query_ground.py','ground-query.json','candidate-manifest.json','shared-actor-inputs.json','hidden-difference-pixels.json','diagnostic-intent.txt'):
 retained.append(archive(run/name,name))
for kind in ('hidden','visible'):
 for folder,name in [('','full-character-'+kind+'.azureproject'),('scene','full-character-'+kind+'.azurelevel')]:retained.append(archive(run/'project'/folder/name,name))
image=out/'full-scene-character.png';image.write_bytes((run/'visible/frames/frame_000011.png').read_bytes())
strict=hidden['comparisons'];worst=max(x['differentPixels'] for x in strict);total=2560*1440
result=dict(schemaVersion=1,status='visual-composition-verified-strict-environment-png-gate-pending',implementationCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),scope='Data-only independent full environment and fixed actor placement. No C++, shader, original source or playable-controller change.',candidate=candidate,ground=read(run/'ground-query.json'),run=dict(path=run.relative_to(root).as_posix(),retained=True),image=dict(file=image.relative_to(root).as_posix(),sha256=sha(image)),hiddenControl=dict(status='strict-gate-failed',comparisons=strict,pngBytesExactPairs=sum(x['pngBytesExact'] for x in strict),maximumDifferentPixels=worst,minimumExactPixelFraction=1-worst/total,maximumChannelError=max(x['maximumChannelError'] for x in strict)),repeatDiagnostic=dict(status='all-twelve-repeat-pngs-byte-identical',comparison=repeat['repeatBytesExact'],conclusion='Difference is reproducible for these inputs. Shared Hair class specialization changed; causality remains unproven, no rendering patch or acceptance-threshold change applied.'),visibleCapture=dict(status='passed',configuration='Release',validationEnabled=False,frames=12,dimensions=[2560,1440],actorAnimation=visible['actorAnimation'],comparisons=visible['comparisons'],elapsedSeconds=visible['elapsedSeconds'],exitCode=visible['exitCode'],unloadZero=True),logs=retained,preservedUserFiles=protected,limitations=['Strict hidden-control gate remains failed: five of twelve baseline PNG pairs byte-identical, including the final frame.','Tiny stable differences in shared environment shading require a relevant rendering correction before re-running the strict gate.','Actor placement and idle playback only; playable movement, full animation cycle, sustained performance, dual-device and formal SSIM remain separate gates.'])
(out/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Archived composed scene, visible image and unchanged strict failure; repeat images all identical; user files protected')
