from pathlib import Path
import os,json,shutil,hashlib,copy,math
root=Path.cwd();run=Path(__file__).resolve().parent;source=root/'build/runs/20261029-045743-snapshot-shading-budget-8ee0b1/full-candidate';actorSource=root/'build/runs/20261027-002548-native-hair-layer-region-closure-61c105/main-candidate-v7';target=run/'project';target.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
project=json.loads((source/'enclosure-sampler.azureproject').read_text(encoding='utf-8'));original=json.loads((source/'scene/enclosure-sampler.azurelevel').read_text(encoding='utf-8'));actorLevel=json.loads((actorSource/'assets/scene.azurelevel').read_text(encoding='utf-8'))
assert len(project['mounts'])==23 and not any(n['id']=='hero' for n in original['nodes'])
shared=[Path('content-character/hero-restored-inputs-v7.glb'),Path('content-assets/locomotion.json')]+[Path('assets/restored-character-materials')/('material-'+str(i)+'.azurematerial') for i in range(13)]
assert all((source/p).read_bytes()==(actorSource/p).read_bytes() for p in shared)
receipt=dict(sourceProjectSha256=sha(source/'enclosure-sampler.azureproject'),sourceLevelSha256=sha(source/'scene/enclosure-sampler.azurelevel'),files=0,linkedBinaryBytes=0,copiedTextBytes=0,sharedActorInputs=[dict(file=p.as_posix(),sha256=sha(source/p)) for p in shared])
binary={'.glb','.bin','.dds','.png','.jpg','.jpeg','.tga','.ppm','.hdr','.azenv','.azvol','.azlut'}
for mountPath in sorted({m['path'] for m in project['mounts']}):
 assert not Path(mountPath).is_absolute() and '..' not in Path(mountPath).parts
 base=source/mountPath;destination=target/mountPath;destination.mkdir(parents=True,exist_ok=True)
 for directory,dirs,files in os.walk(base):
  dirs[:]=[d for d in dirs if d!='.azure'];relative=Path(directory).relative_to(base);folder=destination/relative;folder.mkdir(exist_ok=True)
  for name in files:
   a=Path(directory)/name;b=folder/name
   if a.suffix.lower() in binary:os.link(a,b);receipt['linkedBinaryBytes']+=a.stat().st_size
   else:shutil.copy2(a,b);receipt['copiedTextBytes']+=a.stat().st_size
   receipt['files']+=1
ground=json.loads((run/'ground-query.json').read_text(encoding='utf-8'));x,z=ground['pointXZ'];y=ground['selectedHeight']+.0025
camera=json.loads((root/'build/runs/20261031-102704-preinstall-visual-audit-b55e42/current-full/frames/capture_manifest.json').read_text())['qaCameraPosition'];yaw=math.degrees(math.atan2(camera[0]-x,camera[2]-z))
actor=copy.deepcopy(next(n for n in actorLevel['nodes'] if n['id']=='hero'));actor['components'].pop('azure.character',None)
transform=actor['components']['azure.transform']['data'];transform['translation']=[x,y,z];transform['rotation']=[0,yaw,0]
resource=copy.deepcopy(next(r for r in actorLevel['resources'] if r['id']=='hero'))
assert original['renderSettings']['nprLighting']==actorLevel['renderSettings']['nprLighting']
levels={}
for kind,visible in [('hidden',False),('visible',True)]:
 level=copy.deepcopy(original);node=copy.deepcopy(actor);node['components']['azure.renderable']['data']['visible']=visible;level['resources'].append(resource);level['nodes'].append(node)
 assert level['resources'][:-1]==original['resources'] and level['nodes'][:-1]==original['nodes']
 assert {k:v for k,v in level.items() if k not in ('resources','nodes')}=={k:v for k,v in original.items() if k not in ('resources','nodes')}
 filename='full-character-'+kind+'.azurelevel';path=target/'scene'/filename;path.write_text(json.dumps(level,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');levels[kind]=level
 descriptor=copy.deepcopy(project);descriptor.update(id='full-scene-character-'+kind,name='Complete native scene and character '+kind,startupScene='stage:/'+filename)
 entry=target/('full-character-'+kind+'.azureproject');entry.write_text(json.dumps(descriptor,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 receipt[kind]=dict(project=entry.relative_to(root).as_posix(),levelSha256=sha(path))
check=copy.deepcopy(levels['visible']);check['nodes'][-1]['components']['azure.renderable']['data']['visible']=False;assert check==levels['hidden']
receipt['actorPlacement']=dict(translation=transform['translation'],rotationDegrees=transform['rotation'],groundHeight=ground['selectedHeight'],footClearance=.0025,scope='fixed world placement and original animation graph; playable controller remains in original character project')
receipt['environmentSettingsAndNodesPreserved']=True;receipt['caseDifference']='hero renderable visibility only';receipt['resources']=len(levels['visible']['resources']);receipt['nodes']=len(levels['visible']['nodes'])
assert sha(source/'enclosure-sampler.azureproject')==receipt['sourceProjectSha256'] and sha(source/'scene/enclosure-sampler.azurelevel')==receipt['sourceLevelSha256']
(run/'candidate-manifest.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Prepared independent complete environment and hero;',receipt['resources'],'resources;',receipt['actorPlacement'])
