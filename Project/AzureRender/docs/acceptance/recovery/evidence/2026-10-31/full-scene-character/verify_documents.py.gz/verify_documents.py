from pathlib import Path
import json,re,subprocess,hashlib
from urllib.parse import unquote
root=Path.cwd();run=Path(__file__).resolve().parent
files=['README.md','CHANGELOG.md','docs/plans/azure-engine-plan.md','docs/plans/2026-10-30-development-recovery.md','docs/plans/2026-10-31-full-scene-character-composition.md','docs/acceptance/p8/2026-10-31-environment.md','docs/acceptance/recovery/full-scene-visual.md','docs/acceptance/recovery/full-scene-character.md','docs/tutorials/restored-native-scene.md']
subprocess.run([str(root/'build/reinstall-environment/venv/Scripts/python.exe'),'-X','utf8','tools/check_doc_style.py',*files],check=True)
errors=[];count=0
for name in files:
 path=root/name;text=re.sub(r'```.*?```','',path.read_text(encoding='utf-8'),flags=re.S)
 for para in re.split(r'\n\s*\n',text):
  if para.lstrip().startswith(('#','-','|','>','![')) or re.match(r'\d+[.)]',para.lstrip()):continue
  assert len(re.findall('[。！？]',para))<=4,(name,para)
 for url in re.findall(r'!?\[[^]\n]*\]\(([^)\n]+)\)',text):
  url=url.strip().strip('<>')
  if url.startswith(('https:','http:','mailto:','#','data:')):continue
  local=unquote(url.split('#',1)[0]);count+=1
  if local and not (path.parent/local).exists():errors.append(dict(file=name,target=local))
assert not errors,errors
(run/'doc-links.log').write_text(json.dumps(dict(status='passed',files=len(files),links=count,errors=errors),indent=2)+'\n',encoding='utf-8')
old=(root/'build/runs/20261031-102704-preinstall-visual-audit-b55e42/mkdocs.log').read_text(encoding='utf-8-sig');new=(run/'mkdocs.log').read_text(encoding='utf-8-sig')
assert 'Documentation built in' in new
warnings=lambda t:{x for x in t.splitlines() if 'WARNING' in x or 'contains a link' in x}
assert not warnings(new)-warnings(old),warnings(new)-warnings(old)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
evidence=root/'docs/acceptance/recovery/evidence/2026-10-31/full-scene-character/summary.json';d=json.loads(evidence.read_text(encoding='utf-8'))
for name,value in d['preservedUserFiles'].items():assert sha(root/name)==value
assert sha(root/d['image']['file'])==d['image']['sha256'] and d['hiddenControl']['status']=='strict-gate-failed'
envPath=root/'docs/acceptance/p8/evidence/2026-10-31/environment-review.json';current=json.loads(envPath.read_text(encoding='utf-8'));previous=json.loads(subprocess.check_output(['git','show','HEAD:Project/AzureRender/'+envPath.relative_to(root).as_posix()],text=True,encoding='utf-8'));assert {k:v for k,v in current.items() if k!='fullSceneCharacterComposition'}==previous
assert current['fullSceneCharacterComposition']['status']=='strict environment PNG gate pending'
d['documentation']=dict(files=[dict(file=n,sha256=sha(root/n)) for n in files],linksChecked=count,paragraphAudit='passed',siteBuild='passed',newWarnings=0,newInvalidAnchors=0,strictSiteAcceptance='pending')
evidence.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
subprocess.run(['git','diff','--check'],check=True)
print('PASS:',len(files),'documents;',count,'local links; no new site warnings or invalid anchors; original P8 items and user files protected')
