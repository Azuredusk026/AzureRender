from pathlib import Path
import json,struct,math,os,base64,sys
import numpy as np
root=Path.cwd();run=Path(__file__).resolve().parent;project=root/'build/runs/20261029-045743-snapshot-shading-budget-8ee0b1/full-candidate/enclosure-sampler.azureproject'
description=json.loads(project.read_text());mounts={m['name']:project.parent/m['path'] for m in description['mounts']};level=json.loads((mounts['stage']/'enclosure-sampler.azurelevel').read_text())
assets={}
for mount in mounts.values():
 for directory,dirs,files in os.walk(mount):
  dirs[:]=[d for d in dirs if d!='.azure']
  for name in files:
   if name.endswith('.azmeta'):
    p=Path(directory)/name;meta=json.loads(p.read_text(encoding='utf-8'));assets[meta['id']]=Path(str(p)[:-7])
def resolve(ref):
 if ':/' in ref:
  name,tail=ref.split(':/',1);return mounts[name]/tail
 return assets[ref]
def euler(data):
 x,y,z=np.radians(data.get('rotation',[0,0,0]));cx,sx=math.cos(x),math.sin(x);cy,sy=math.cos(y),math.sin(y);cz,sz=math.cos(z),math.sin(z)
 rx=np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]]);ry=np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]]);rz=np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])
 m=np.eye(4);m[:3,:3]=rx@ry@rz@np.diag(data.get('scale',[1,1,1]));m[:3,3]=data.get('translation',[0,0,0]);return m
nodes={n['id']:n for n in level['nodes']};world={}
def node_world(key):
 if not key:return np.eye(4)
 if key not in world:
  n=nodes[key];world[key]=node_world(n.get('parentId',''))@euler(n.get('components',{}).get('azure.transform',{}).get('data',{}))
 return world[key]
def gltf_matrix(n):
 if 'matrix' in n:return np.array(n['matrix'],float).reshape(4,4,order='F')
 x,y,z,w=n.get('rotation',[0,0,0,1]);m=np.eye(4)
 m[:3,:3]=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])@np.diag(n.get('scale',[1,1,1]));m[:3,3]=n.get('translation',[0,0,0]);return m
cache={}
def geometry(path):
 if path in cache:return cache[path]
 with path.open('rb') as f:
  header=f.read(12);magic,version,total=struct.unpack('<III',header);binary=magic==0x46546c67
  if binary:
   assert version==2;length,kind=struct.unpack('<II',f.read(8));assert kind==0x4e4f534a;doc=json.loads(f.read(length));binaryLength,binaryKind=struct.unpack('<II',f.read(8));assert binaryKind==0x004e4942;base=f.tell()
  else:f.seek(0);doc=json.load(f);base=0
  def accessor(index):
   a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];assert not v.get('extensions'),path
   dtype=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']]);size={'SCALAR':1,'VEC3':3}[a['type']];stride=v.get('byteStride',size*dtype.itemsize)
   offset=v.get('byteOffset',0)+a.get('byteOffset',0);count=stride*(a['count']-1)+size*dtype.itemsize
   if binary:f.seek(base+offset);raw=f.read(count)
   else:
    uri=doc['buffers'][v['buffer']]['uri']
    if uri.startswith('data:'):raw=base64.b64decode(uri.split(',',1)[1],validate=True)[offset:offset+count]
    else:
     with (path.parent/uri).open('rb') as external:external.seek(offset);raw=external.read(count)
   return np.ndarray((a['count'],size),dtype=dtype,buffer=raw,strides=(stride,dtype.itemsize)).copy()
  meshes=[]
  for mesh in doc.get('meshes',[]):
   triangles=[]
   for p in mesh['primitives']:
    if p.get('mode',4)!=4:continue
    material=doc.get('materials',[])[p['material']] if 'material' in p else {}
    if material.get('alphaMode')=='BLEND':continue
    positions=accessor(p['attributes']['POSITION']);indices=accessor(p['indices']).reshape(-1) if 'indices' in p else np.arange(len(positions));triangles.append(positions[indices.reshape(-1,3)].astype(float))
   meshes.append(np.concatenate(triangles) if triangles else np.empty((0,3,3)))
  output=[]
  def visit(i,parent):
   n=doc['nodes'][i];matrix=parent@gltf_matrix(n)
   if 'mesh' in n:
    triangle=meshes[n['mesh']];output.append(triangle@matrix[:3,:3].T+matrix[:3,3])
   for child in n.get('children',[]):visit(child,matrix)
  for i in doc['scenes'][doc.get('scene',0)]['nodes']:visit(i,np.eye(4))
 cache[path]=np.concatenate(output) if output else np.empty((0,3,3));return cache[path]
resources={r['id']:resolve(r['asset']) for r in level['resources']};point=np.array([float(sys.argv[1]),float(sys.argv[2])]) if len(sys.argv)==3 else np.array([-2.2,-12.]);hits=[];tested=0
for n in level['nodes']:
 if not n.get('resourceId') or not n.get('components',{}).get('azure.renderable',{}).get('data',{}).get('visible',True):continue
 matrix=node_world(n['id']);tri=geometry(resources[n['resourceId']]);tri=tri@matrix[:3,:3].T+matrix[:3,3];tested+=len(tri)
 if not len(tri):continue
 a=tri[:,0];u=tri[:,1]-a;v=tri[:,2]-a;delta=point-a[:,[0,2]];det=u[:,0]*v[:,2]-u[:,2]*v[:,0];valid=np.abs(det)>1e-10;den=np.where(valid,det,1)
 b=(delta[:,0]*v[:,2]-delta[:,1]*v[:,0])/den;c=(u[:,0]*delta[:,1]-u[:,2]*delta[:,0])/den;y=a[:,1]+b*u[:,1]+c*v[:,1]
 normal=np.cross(u,v);flat=np.abs(normal[:,1])>=.8*np.linalg.norm(normal,axis=1)
 valid&=(b>=-1e-6)&(c>=-1e-6)&(b+c<=1+1e-6)&(y>=-2)&(y<2.5)&flat
 for value in y[valid]:hits.append(dict(node=n['id'],name=n.get('name',''),height=float(value)))
assert hits,'No floor intersection at proposed actor placement';hits.sort(key=lambda x:x['height']);result=dict(pointXZ=point.tolist(),selectedHeight=hits[-1]['height'],testedTriangles=tested,hits=hits)
(run/'ground-query.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Ground at',point.tolist(),'is',result['selectedHeight'],'triangles tested',tested,'hits',len(hits))
