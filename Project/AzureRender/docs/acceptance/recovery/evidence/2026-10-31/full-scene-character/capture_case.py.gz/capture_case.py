from pathlib import Path
import json,subprocess,os,hashlib,re,time,sys
import numpy as np
from PIL import Image
root=Path.cwd();run=Path(__file__).resolve().parent;kind=sys.argv[1];assert kind in ('hidden','visible');out=run/kind;out.mkdir(exist_ok=False)
candidate=json.loads((run/'candidate-manifest.json').read_text(encoding='utf-8'));project=root/candidate[kind]['project'];build=root/'build/ninja-msvc-release';player=build/'AzurePlayer.exe'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shaders={p.name:sha(p) for p in (build/'shaders').glob('*.spv')};reference=root/'build/runs/20261031-102704-preinstall-visual-audit-b55e42/current-full/frames'
command=[str(player),'--project',str(project),'--width','2560','--height','1440','--capture-frames','12','--capture-fps','60','--capture-dir',str(out/'frames'),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--runtime-report',str(out/'runtime.json')]
report=dict(status='running',kind=kind,playerSha256=sha(player),shaderSet=shaders,projectSha256=sha(project),command=command,timeoutSeconds=600,scope='Complete scene and original actor visual composition; fixed placement, original idle graph, playable control remains a separate project')
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
env=os.environ.copy();env.update(DOTNET_ROOT='D:/Tools/dotnet9',PYTHONUTF8='1',TEMP=str(out),TMP=str(out));env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8');start=time.perf_counter()
try:
 with (out/'player.log').open('wb') as log:
  process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup);report['pid']=process.pid;(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
  try:code=process.wait(timeout=600)
  except subprocess.TimeoutExpired:process.kill();process.wait();raise
 report['exitCode']=code;assert code==0
 text=(out/'player.log').read_text(encoding='utf-8',errors='replace');assert not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD|\[error\]',text,re.I)
 assert 'Allocator after unload: buffers=0 images=0' in text and 'Validation layer: disabled' in text
 runtime=json.loads((out/'runtime.json').read_text(encoding='utf-8-sig'));assert not runtime['scriptErrors'] and not runtime['presentationErrors']
 actor=next(x for x in runtime['animations'] if x['node']=='hero');assert actor['time']>=.18,actor;report['actorAnimation']=actor
 manifest=json.loads((out/'frames/capture_manifest.json').read_text(encoding='utf-8-sig'));baseline=json.loads((reference/'capture_manifest.json').read_text(encoding='utf-8-sig'))
 for key in ('qaCameraPosition','qaCameraTarget','gradeSettings','viewFogMode','antiAliasing'):
  if key in baseline:assert manifest[key]==baseline[key],(key,manifest.get(key),baseline[key])
 assert manifest['screenReflectionTemporalActive'] and manifest['screenReflectionHistoryValid'] and manifest['screenReflectionAlgorithm']=='linear'
 images=sorted((out/'frames').glob('frame_*.png'));assert len(images)==12
 report['capture']=manifest;comparisons=[]
 if kind=='hidden':
  for image in images:
   expected=reference/image.name;a=np.asarray(Image.open(image).convert('RGB')).astype(np.int16);b=np.asarray(Image.open(expected).convert('RGB')).astype(np.int16);delta=np.abs(a-b)
   comparisons.append(dict(frame=image.name,pngBytesExact=image.read_bytes()==expected.read_bytes(),differentPixels=int(np.any(delta,axis=2).sum()),maximumChannelError=int(delta.max()),meanAbsoluteByteError=float(delta.mean()),sha256=sha(image)))
  report['comparisons']=comparisons;assert all(x['pngBytesExact'] for x in comparisons),'Hidden actor changed complete environment PNGs'
 else:
  report['images']={p.name:sha(p) for p in images}
  for image in images:
   control=run/'hidden/frames'/image.name;a=np.asarray(Image.open(image).convert('RGB')).astype(np.int16);b=np.asarray(Image.open(control).convert('RGB')).astype(np.int16);delta=np.abs(a-b)
   assert np.count_nonzero(np.any(delta>8,axis=2))>1000,'Visible actor did not affect the actual scene'
   comparisons.append(dict(frame=image.name,differentPixels=int(np.any(delta,axis=2).sum()),maximumChannelError=int(delta.max()),meanAbsoluteByteError=float(delta.mean())))
  report['comparisons']=comparisons
 assert sha(player)==report['playerSha256'] and shaders=={p.name:sha(p) for p in (build/'shaders').glob('*.spv')} and sha(project)==report['projectSha256']
 report['status']='passed';print(kind,'complete-scene actor capture passed',flush=True)
except Exception as error:report.update(status='failed',error=str(error));raise
finally:report['elapsedSeconds']=time.perf_counter()-start;(out/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
