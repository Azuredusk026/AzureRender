from pathlib import Path
import subprocess,json,os,re,time,hashlib
root=Path.cwd();r=Path(__file__).resolve().parent;source=root/'build/runs/20261024-074605-native-material-aa-reference-9eb92d';report={'status':'running','cases':[]};env=os.environ.copy();env['DOTNET_ROOT']='D:/Tools/dotnet9';startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
try:
 for name in ['temporal','high']:
  out=r/name;out.mkdir();cmd=json.loads((source/name/'command.json').read_text());cmd[0]=str(root/'build/ninja-msvc-release/AzurePlayer.exe')
  for k,v in {'--project':r/'project'/(name+'.azureproject'),'--capture-dir':out/'frames','--runtime-report':out/'runtime.json','--gpu-timing-output':out/'gpu-timing.json'}.items():cmd[cmd.index(k)+1]=str(v)
  row={'case':name,'command':cmd,'status':'running'};report['cases'].append(row);(r/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print('START exact',name,flush=True);t=time.perf_counter()
  with (out/'player.log').open('wb') as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=log,startupinfo=startup,timeout=600)
  row.update(exitCode=p.returncode,elapsedSeconds=time.perf_counter()-t);assert p.returncode==0;text=(out/'player.log').read_text(encoding='utf-8',errors='replace');assert 'Allocator after unload: buffers=0 images=0' in text and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD|\[error\]',text,re.I)
  m=json.loads((out/'frames/capture_manifest.json').read_text(encoding='utf-8-sig'));count=32 if name=='temporal' else 1;assert m['capturedFrames']==count and m['antiAliasing']==(3 if name=='temporal' else 0)
  if name=='temporal':assert m['motionOutputActive'] and m['temporalHistorySubmission']>=32
  row['capture']=m;row['status']='captured';(r/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print('DONE exact',name,flush=True)
 report['status']='captures-complete'
finally:(r/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
