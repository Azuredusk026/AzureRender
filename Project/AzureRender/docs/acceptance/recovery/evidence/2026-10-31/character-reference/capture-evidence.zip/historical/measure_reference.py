from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent
def rgb(p):return np.asarray(Image.open(p).convert('RGB')).astype(np.float32)/255
def lin(a):return np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
def read(p):return lin(rgb(p))
maskFile=R.parent/'20261023-105023-character-composite-contribution-diagnosis-acb8e5/native-hair-visible-mask.png'
hair=(np.asarray(Image.open(maskFile).convert('L')).reshape(720,2,1280,2).max((1,3))>0)
padded=np.pad(hair,1);interior=np.logical_and.reduce([padded[y:y+720,x:x+1280] for y in range(3) for x in range(3)])
boundary=hair&~interior
report=dict(schemaVersion=1,referenceScale=4,measureDomain='linear display RGB',maskSha256=hashlib.sha256(maskFile.read_bytes()).hexdigest(),regions=[])
for isolation in ('beauty','hair-kk'):
    suffix='' if isolation=='beauty' else '-'+isolation
    if not (R/f'high{suffix}/frames/frame_000000.png').exists() or not (R/f'temporal{suffix}/frames/frame_000031.png').exists():continue
    reference=read(R/f'high{suffix}/frames/frame_000000.png').reshape(720,4,1280,4,3).mean((1,3))
    frames=np.stack([read(R/f'temporal{suffix}/frames/frame_{index:06d}.png') for index in range(24,32)])
    low=read(R/'off/frames/frame_000000.png') if isolation=='beauty' else None
    for name,box in [('crown',(607,80,670,121)),('hair-interior',(570,65,715,220)),('fine-hair-boundary',(570,65,715,220)),('clothing',(500,220,800,550))]:
        x0,y0,x1,y1=box;ref=reference[y0:y1,x0:x1];current=frames[:,y0:y1,x0:x1]
        mask=(np.abs(ref-reference[0,0]).max(2)>.005) if name=='clothing' else (boundary if name=='fine-hair-boundary' else interior)[y0:y1,x0:x1].copy()
        if isolation=='hair-kk':mask&=(ref.max(2)-ref.min(2))>.001
        if not mask.any():continue
        values=current[:,mask];ref=ref[mask];energy=float(ref.sum())
        row=dict(isolation=isolation,region=name,box=box,pixels=int(mask.sum()),referenceEnergy=energy,
            lastEightEnergyRatios=[float(v.sum()/energy) for v in values],meanAbsoluteError=float(np.abs(values-ref).mean()),
            temporalMeanDeviation=float(values.std(0).mean()),temporalMaximumRange=float(np.ptp(values,axis=0).max()))
        if low is not None:row['modeZeroMeanAbsoluteError']=float(np.abs(low[y0:y1,x0:x1][mask]-ref).mean())
        report['regions'].append(row)
    def encode(a):return np.clip(np.where(a<=.0031308,a*12.92,1.055*np.maximum(a,0)**(1/2.4)-.055)*255+.5,0,255).astype(np.uint8)
    overview=Image.new('RGB',(580,310))
    for i,array in enumerate((reference,frames[-1])):overview.paste(Image.fromarray(encode(array)).crop((570,65,715,220)).resize((290,310)),(i*290,0))
    overview.save(R/f'{isolation}-reference-comparison.png')
(R/'reference-metrics.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
