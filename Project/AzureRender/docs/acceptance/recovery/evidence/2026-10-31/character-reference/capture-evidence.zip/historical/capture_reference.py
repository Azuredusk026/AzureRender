from pathlib import Path
import copy,hashlib,json,re,shutil,subprocess,sys,uuid
R=Path(__file__).resolve().parent;E=R.parents[2]
source=R.parent/'20261023-235559-material-outline-binding-fb611b'
kind=sys.argv[1];isolation=sys.argv[2] if len(sys.argv)>2 else 'beauty'
case=kind if isolation=='beauty' else kind+'-'+isolation
exposure=float(sys.argv[3]) if len(sys.argv)>3 else None
if exposure is not None:case+='-gain'+str(exposure)
sampling=sys.argv[4] if len(sys.argv)>4 else None
if sampling is not None:
    assert sampling in ('normal','parameter','both','normal-linear')
    case+='-'+sampling
scale=4 if kind=='high' else 1;mode=3 if kind=='temporal' else 0
folder=R/case;folder.mkdir(exist_ok=True)
level=json.loads((source/'native-assets/outline-converted-document.azurelevel').read_text())
project=json.loads((source/'outline-converted-document.azureproject').read_text())
for mount in project['mounts']:
    destination=R/mount['path']
    if not destination.exists():shutil.copytree(source/mount['path'],destination)
if sampling is not None:
    destination=R/('sampling-'+sampling)
    if not destination.exists():shutil.copytree(R/'native-character',destination)
    for slot in ((18,) if sampling.startswith('normal') else (17,) if sampling=='parameter' else (17,18)):
        path=destination/f'native-textures/t{slot}.dds.azmeta';metadata=json.loads(path.read_text())
        metadata['settings']['texture']['mipBias']=-1 if sampling=='normal-linear' else -3
        if sampling=='normal-linear':metadata['settings']['texture']['mipFilter']='linear'
        path.write_text(json.dumps(metadata,indent=2))
    next(mount for mount in project['mounts'] if mount['name']=='character')['path']=destination.name
project['mounts'].append(dict(name='reference',path=case))
project['startupScene']='reference:/reference.azurelevel'
project['id']=str(uuid.uuid4())
if kind.startswith('phase'):
    phase=int(kind[5:]);jitter=[(0,-1/6),(-.25,1/6),(.25,-7/18),(-.375,-1/18),(.125,5/18),(-.125,-5/18),(.375,1/18),(-.4375,7/18)][phase]
    for node in level['nodes']:
        camera=node.get('components',{}).get('azure.camera',{}).get('data')
        if camera:
            camera['projectionOffsetX']=camera.get('projectionOffsetX',0)+2*jitter[0]/1280
            camera['projectionOffsetY']=camera.get('projectionOffsetY',0)+2*jitter[1]/720
if scale!=1:
    material=json.loads((source/'native-character/outline-converted.azurematerial').read_text())
    def scale_outline(value):
        if isinstance(value,dict):
            for key,item in value.items():
                if key=='outlineSurface' and isinstance(item,dict):item['minimumPixels']=item.get('minimumPixels',0)*scale
                else:scale_outline(item)
        elif isinstance(value,list):
            for item in value:scale_outline(item)
    scale_outline(material)
    meta=json.loads((source/'native-character/outline-converted.azurematerial.azmeta').read_text());old=meta['id'];meta['id']=str(uuid.uuid4())
    (folder/'reference.azurematerial').write_text(json.dumps(material,indent=2))
    (folder/'reference.azurematerial.azmeta').write_text(json.dumps(meta))
    for node in level['nodes']:
        for slot,identifier in node.get('materialSlots',{}).items():
            if identifier==old:node['materialSlots'][slot]=meta['id']
        receiver=node.get('components',{}).get('azure.object-shadow',{}).get('data',{})
        for key in ('receiverPixelOffsetX','receiverPixelOffsetY'):
            if key in receiver:receiver[key]*=scale
level['renderSettings']['schemaVersion']=18;level['renderSettings']['antiAliasing']=mode
if exposure is not None:level['renderSettings']['exposure']=exposure
(folder/'reference.azurelevel').write_text(json.dumps(level,indent=2));(R/f'{case}.azureproject').write_text(json.dumps(project,indent=2))
command=json.loads((source/'native-release-embedded-temporal-state-api3/command.json').read_text())
command[0]=str(E/'build/ninja-msvc-release/AzurePlayer.exe')
for key,value in {'--project':R/f'{case}.azureproject','--width':1280*scale,'--height':720*scale,
    '--capture-dir':folder/'frames','--capture-frames':32 if mode==3 else 1,'--runtime-report':folder/'runtime.json'}.items():
    command[command.index(key)+1]=str(value)
command[command.index('--qa-isolation')+1]=isolation
command+=['--set',f'render.antiAliasing={mode}','--gpu-timing-output',str(folder/'gpu-timing.json')]
if exposure is not None:command+=['--qa-exposure',str(exposure)]
(folder/'command.json').write_text(json.dumps(command,indent=2))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=sha(Path(command[0]))
with (folder/'player.log').open('w',encoding='utf-8') as log:subprocess.run(command,cwd=E,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=480)
log=(folder/'player.log').read_text(encoding='utf-8',errors='replace')
assert not re.search(r'VUID-|Validation (?:Error|Warning)|\[error\]',log),log[-2000:]
assert 'Allocator after unload: buffers=0 images=0' in log
assert sha(Path(command[0]))==before
manifest=json.loads((folder/'frames/capture_manifest.json').read_text(encoding='utf-8-sig'))
assert manifest['antiAliasing']==mode and manifest['width']==1280*scale and manifest['height']==720*scale
if exposure is not None:assert manifest['qaExposureEv']==exposure and manifest['gradeSettings']['exposureEv']==exposure
assert len(list((folder/'frames').glob('frame_*.png')))==(32 if mode==3 else 1)
if mode==3:assert manifest['motionOutputActive'] and manifest['temporalHistorySubmission']>=32
result=dict(status='passed',kind=kind,playerSha256=before,referenceScale=scale,output=[1280*scale,720*scale],
    minimumPixelsScaled=scale!=1,receiverPixelOffsetsScaled=scale!=1,
    images={p.name:sha(p) for p in sorted((folder/'frames').glob('frame_*.png'))})
(folder/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(status='passed',kind=kind,frames=len(result['images']))))
