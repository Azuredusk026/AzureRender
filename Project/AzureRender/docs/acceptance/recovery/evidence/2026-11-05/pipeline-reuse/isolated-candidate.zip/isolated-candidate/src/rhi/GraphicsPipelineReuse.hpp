#pragma once
#include "rhi/Rhi.hpp"
#include <functional>
#include <list>
#include <memory>
#include <mutex>
#include <string>

namespace azurerender::rhi {
struct GraphicsPipelineIdentity {
    std::shared_ptr<const std::vector<char>> vertex,fragment;
    std::string state;
    bool operator==(const GraphicsPipelineIdentity& other) const;
    std::size_t byteSize() const;
};
std::string descriptorSetIdentity(std::vector<DescriptorBindingDesc> bindings);
std::string pipelineLayoutIdentity(const std::string& set,const PushConstantRangeDesc* range);
std::string renderPassIdentity(const RenderPassDesc& pass);
GraphicsPipelineIdentity graphicsPipelineIdentity(const GraphicsPipelineDesc& desc,
    std::shared_ptr<const std::vector<char>> vertex,std::shared_ptr<const std::vector<char>> fragment,
    const std::string& pass,const std::string& layout,VkPipelineCreateFlags flags);

struct GraphicsPipelineReuseStatistics {
    std::uint64_t requests=0,hits=0,creations=0,releases=0,evictions=0,destroyed=0,bypassed=0;
    std::size_t activeReferences=0,activePipelines=0,retainedPipelines=0,retainedBytes=0;
};
// The device owner clears the pool after retiring all users and before device
// destruction. Native creation callbacks run serially; destruction must not throw.
class GraphicsPipelineReusePool final {
public:
    GraphicsPipelineReusePool(VkDevice device,std::function<void(VkPipeline)> destroy,
        std::size_t retainedLimit=128,std::size_t retainedBytes=64ULL*1024*1024);
    ~GraphicsPipelineReusePool();
    GraphicsPipelineReusePool(const GraphicsPipelineReusePool&)=delete;
    GraphicsPipelineReusePool& operator=(const GraphicsPipelineReusePool&)=delete;
    VkDevice device() const noexcept{return device_;}
    VkPipeline acquire(const GraphicsPipelineIdentity&,const std::function<VkPipeline()>&);
    bool release(VkPipeline);
    void clear();
    void noteBypass();
    GraphicsPipelineReuseStatistics statistics() const;
private:
    struct Entry {GraphicsPipelineIdentity key;VkPipeline pipeline;std::size_t references;std::uint64_t access;};
    void trim();
    VkDevice device_;
    std::function<void(VkPipeline)> destroy_;
    std::size_t retainedLimit_,retainedBytes_;
    std::uint64_t access_=0;
    std::list<Entry> entries_;
    mutable std::mutex mutex_;
    GraphicsPipelineReuseStatistics totals_;
};
}
