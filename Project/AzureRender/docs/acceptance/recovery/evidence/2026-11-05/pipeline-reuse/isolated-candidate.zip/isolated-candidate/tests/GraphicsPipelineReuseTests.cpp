#include "rhi/GraphicsPipelineReuse.hpp"
#include "rhi/VulkanRhi.hpp"
#include <iostream>
#include <algorithm>
#include <stdexcept>

using namespace azurerender::rhi;
namespace {
void require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
VkPipeline handle(unsigned value){return reinterpret_cast<VkPipeline>(static_cast<std::uintptr_t>(value));}
std::shared_ptr<const std::vector<char>> code(std::initializer_list<char> bytes){return std::make_shared<const std::vector<char>>(bytes);}
}
int main()try {
    {
        GpuAllocator allocator;
        auto device=reinterpret_cast<VkDevice>(static_cast<std::uintptr_t>(1));
        GraphicsPipelineReusePool pool(device,[](VkPipeline){});
        bool rejected=false;
        try { VulkanRhi wrong(VK_NULL_HANDLE,VK_NULL_HANDLE,VK_NULL_HANDLE,VK_NULL_HANDLE,allocator,false,nullptr,false,false,&pool); }
        catch(const std::invalid_argument&) {rejected=true;}
        require(rejected,"A borrowed pipeline pool must belong to the same logical device");
        VulkanRhi matching(device,VK_NULL_HANDLE,VK_NULL_HANDLE,VK_NULL_HANDLE,allocator,false,nullptr,false,false,&pool);
    }
    auto vertex=code({1,2,3,4}),fragment=code({5,6,7,8});
    GraphicsPipelineDesc desc;desc.vertexStride=12;desc.colorAttachmentCount=1;
    desc.vertexAttributes={{0,VK_FORMAT_R32G32B32_SFLOAT,0,0}};
    const auto key=graphicsPipelineIdentity(desc,vertex,fragment,"pass","layout",0);
    std::vector<VkPipeline> destroyed;unsigned creates=0;
    const auto create=[&]{return handle(++creates);};
    {
        GraphicsPipelineReusePool pool(VK_NULL_HANDLE,[&](auto pipeline){destroyed.push_back(pipeline);},2,4096);
        auto first=pool.acquire(key,create),second=pool.acquire(key,create);
        require(first!=second&&creates==2,"Active callers require independent native pipeline identities");
        require(pool.statistics().activeReferences==2&&pool.statistics().hits==0,"Active acquisitions must retain independent leases");
        require(pool.release(first)&&destroyed.empty(),"A released pipeline remains idle within budget");
        bool rejected=false;try{pool.clear();}catch(const std::logic_error&){rejected=true;}
        require(rejected&&destroyed.empty(),"Clearing with any active pipeline must fail without destroying resources");
        auto again=pool.acquire(key,create);require(again==first&&creates==2,"Only the idle pipeline can be reused");
        pool.release(again);pool.release(second);
        auto changed=key;changed.fragment=code({5,6,7,9});auto other=pool.acquire(changed,create);pool.release(other);
        require(creates==3&&destroyed.size()==1&&destroyed.front()==first,"A shader change creates a pipeline and retires the oldest idle entry");
        require(!pool.release(handle(999)),"Unknown native handles keep their direct destruction path");
        bool doubleRelease=false;try{pool.release(second);}catch(const std::logic_error&){doubleRelease=true;}
        require(doubleRelease,"Duplicate release must fail without native destruction");
        pool.clear();require(destroyed.size()==3&&pool.statistics().retainedPipelines==0,"Clear destroys all retired native objects");
        bool failed=false;try{pool.acquire(key,[]()->VkPipeline{throw std::runtime_error("creation failed");});}catch(const std::runtime_error&){failed=true;}
        require(failed&&pool.statistics().activeReferences==0,"Creation failure must retain no lease");
    }
    {
        GraphicsPipelineReusePool pool(VK_NULL_HANDLE,[&](auto pipeline){destroyed.push_back(pipeline);},0,4096);
        auto value=pool.acquire(key,create);const auto before=destroyed.size();pool.release(value);
        require(destroyed.size()==before+1&&pool.statistics().retainedPipelines==0,"Zero retention must destroy released objects immediately");
    }

    auto changedState=[&](auto edit){auto value=desc;edit(value);require(!(graphicsPipelineIdentity(value,vertex,fragment,"pass","layout",0)==key),"Every declared graphics state participates in the reuse identity");};
    changedState([](auto& d){d.vertexStride=16;});
    changedState([](auto& d){d.vertexAttributes[0].offset=4;});
    changedState([](auto& d){d.vertexBindings={{0,12,VK_VERTEX_INPUT_RATE_INSTANCE}};});
    changedState([](auto& d){d.cullMode=VK_CULL_MODE_FRONT_BIT;});
    changedState([](auto& d){d.frontFace=VK_FRONT_FACE_COUNTER_CLOCKWISE;});
    changedState([](auto& d){d.depthBias=true;});
    changedState([](auto& d){d.depthBiasConstant=1;});
    changedState([](auto& d){d.depthBiasSlope=1;});
    changedState([](auto& d){d.depthBiasExact=true;});
    changedState([](auto& d){d.depthTest=false;});
    changedState([](auto& d){d.depthWrite=false;});
    changedState([](auto& d){d.depthCompare=VK_COMPARE_OP_EQUAL;});
    changedState([](auto& d){d.alphaBlend=true;});
    changedState([](auto& d){d.premultipliedAlpha=true;});
    changedState([](auto& d){d.primaryColorBlend=PrimaryColorBlend::Additive;});
    changedState([](auto& d){d.colorAttachmentCount=2;});
    changedState([](auto& d){d.colorWriteMasks={VK_COLOR_COMPONENT_R_BIT};});
    changedState([](auto& d){d.rasterizationSamples=VK_SAMPLE_COUNT_4_BIT;});
    changedState([](auto& d){d.minSampleShading=.5F;});
    changedState([](auto& d){d.vertexSpecialization={{0,1}};});
    changedState([](auto& d){d.fragmentSpecialization={{0,1}};});
    require(!(graphicsPipelineIdentity(desc,vertex,fragment,"other-pass","layout",0)==key),"Render pass definitions must remain isolated");
    require(!(graphicsPipelineIdentity(desc,vertex,fragment,"pass","other-layout",0)==key),"Pipeline layout definitions must remain isolated");
    require(!(graphicsPipelineIdentity(desc,vertex,fragment,"pass","layout",1)==key),"Creation and inspection flags must remain isolated");
    auto equalVertex=code({1,2,3,4});require(graphicsPipelineIdentity(desc,equalVertex,fragment,"pass","layout",0)==key,"Byte equality must survive shader module handle replacement");
    std::vector<DescriptorBindingDesc> bindings{{2,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_VERTEX_BIT},{0,VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT}};
    auto reversed=bindings;std::reverse(reversed.begin(),reversed.end());
    require(descriptorSetIdentity(bindings)==descriptorSetIdentity(reversed),"Descriptor declaration order must preserve structural compatibility");
    PushConstantRangeDesc range{VK_SHADER_STAGE_VERTEX_BIT,128};auto layout=pipelineLayoutIdentity(descriptorSetIdentity(bindings),&range);range.size=132;
    require(layout!=pipelineLayoutIdentity(descriptorSetIdentity(bindings),&range),"Push ranges must participate in layout identity");
    RenderPassDesc pass;pass.attachments.push_back({VK_FORMAT_R8G8B8A8_UNORM});auto identity=renderPassIdentity(pass);pass.attachments[0].samples=VK_SAMPLE_COUNT_4_BIT;
    require(identity!=renderPassIdentity(pass),"Attachment sample counts must participate in pass identity");
    std::cout<<"Pipeline identities, independent leases, idle reuse, limits and failures passed\n";
    return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
