#include "GraphicsPipelineReuse.hpp"
#include <algorithm>
#include <cstring>
#include <stdexcept>

namespace azurerender::rhi {
namespace {
struct Writer {
    std::string data;
    void number(std::uint64_t value){for(unsigned i=0;i<8;++i)data.push_back(static_cast<char>((value>>(8*i))&255));}
    void real(float value){std::uint32_t bits;std::memcpy(&bits,&value,sizeof(bits));number(bits);}
    void text(const std::string& value){number(value.size());data+=value;}
};
bool equalCode(const std::shared_ptr<const std::vector<char>>& a,const std::shared_ptr<const std::vector<char>>& b){
    return a==b||(a&&b&&*a==*b);
}
}
bool GraphicsPipelineIdentity::operator==(const GraphicsPipelineIdentity& other) const {
    return state==other.state&&equalCode(vertex,other.vertex)&&equalCode(fragment,other.fragment);
}
std::size_t GraphicsPipelineIdentity::byteSize() const {
    return state.size()+(vertex?vertex->size():0)+(fragment?fragment->size():0);
}
std::string descriptorSetIdentity(std::vector<DescriptorBindingDesc> bindings){
    std::sort(bindings.begin(),bindings.end(),[](const auto& a,const auto& b){return a.binding<b.binding;});
    Writer out;out.number(bindings.size());
    for(const auto& b:bindings){out.number(b.binding);out.number(b.type);out.number(b.count);out.number(b.stages);}
    return out.data;
}
std::string pipelineLayoutIdentity(const std::string& set,const PushConstantRangeDesc* range){
    Writer out;out.text(set);out.number(range!=nullptr);
    if(range){out.number(range->stages);out.number(range->size);}
    return out.data;
}
std::string renderPassIdentity(const RenderPassDesc& pass){
    Writer out;out.number(pass.depthAttachment);out.number(pass.externalReadDependency);out.number(pass.depthReadOnly);
    out.number(pass.attachments.size());
    for(const auto& a:pass.attachments){
        out.number(a.format);out.number(a.initialLayout);out.number(a.finalLayout);
        out.number(a.clear);out.number(a.store);out.number(a.isDepth);out.number(a.load);out.number(a.samples);
    }
    return out.data;
}
GraphicsPipelineIdentity graphicsPipelineIdentity(const GraphicsPipelineDesc& desc,
    std::shared_ptr<const std::vector<char>> vertex,std::shared_ptr<const std::vector<char>> fragment,
    const std::string& pass,const std::string& layout,VkPipelineCreateFlags flags){
    Writer out;out.text(pass);out.text(layout);out.number(flags);out.number(desc.vertexStride);
    out.number(desc.vertexAttributes.size());
    for(const auto& a:desc.vertexAttributes){out.number(a.location);out.number(a.format);out.number(a.offset);out.number(a.binding);}
    out.number(desc.vertexBindings.size());
    for(const auto& b:desc.vertexBindings){out.number(b.binding);out.number(b.stride);out.number(b.inputRate);}
    out.number(desc.cullMode);out.number(desc.frontFace);out.number(desc.depthBias);
    out.real(desc.depthBiasConstant);out.real(desc.depthBiasSlope);out.number(desc.depthBiasExact);
    out.number(desc.depthTest);out.number(desc.depthWrite);out.number(desc.depthCompare);
    out.number(desc.alphaBlend);out.number(desc.premultipliedAlpha);out.number(static_cast<unsigned>(desc.primaryColorBlend));
    out.number(desc.colorAttachmentCount);out.number(desc.colorWriteMasks.size());
    for(auto mask:desc.colorWriteMasks)out.number(mask);
    out.number(desc.rasterizationSamples);out.real(desc.minSampleShading);
    for(const auto* constants:{&desc.vertexSpecialization,&desc.fragmentSpecialization}){
        out.number(constants->size());for(const auto& c:*constants){out.number(c.id);out.number(c.value);}
    }
    return {std::move(vertex),std::move(fragment),std::move(out.data)};
}
GraphicsPipelineReusePool::GraphicsPipelineReusePool(VkDevice device,std::function<void(VkPipeline)> destroy,
    std::size_t retainedLimit,std::size_t retainedBytes)
    :device_(device),destroy_(std::move(destroy)),retainedLimit_(retainedLimit),retainedBytes_(retainedBytes){
    if(!destroy_||retainedLimit>4096||retainedBytes>1024ULL*1024*1024)
        throw std::invalid_argument("Invalid pipeline reuse pool limits or destruction callback");
}
GraphicsPipelineReusePool::~GraphicsPipelineReusePool(){
    for(const auto& e:entries_)destroy_(e.pipeline);
}
VkPipeline GraphicsPipelineReusePool::acquire(const GraphicsPipelineIdentity& key,const std::function<VkPipeline()>& create){
    if(!key.vertex||!key.fragment||key.vertex->empty()||key.fragment->empty()||!create)
        throw std::invalid_argument("Pipeline reuse requires shader bytes and a creation callback");
    std::lock_guard<std::mutex> lock(mutex_);++totals_.requests;
    for(auto& e:entries_)if(e.references==0&&e.key==key){e.references=1;e.access=++access_;++totals_.hits;return e.pipeline;}
    const auto pipeline=create();if(!pipeline)throw std::runtime_error("Native pipeline creation returned no pipeline");
    try{entries_.push_back({key,pipeline,1,++access_});}
    catch(...){destroy_(pipeline);throw;}
    ++totals_.creations;return pipeline;
}
bool GraphicsPipelineReusePool::release(VkPipeline pipeline){
    std::lock_guard<std::mutex> lock(mutex_);
    for(auto& e:entries_)if(e.pipeline==pipeline){
        if(!e.references)throw std::logic_error("Pipeline reuse lease was already released");
        --e.references;e.access=++access_;++totals_.releases;trim();return true;
    }
    return false;
}
void GraphicsPipelineReusePool::trim(){
    for(;;){
        std::size_t count=0,bytes=0;auto oldest=entries_.end();
        for(auto it=entries_.begin();it!=entries_.end();++it)if(!it->references){
            ++count;bytes+=it->key.byteSize();if(oldest==entries_.end()||it->access<oldest->access)oldest=it;
        }
        if(count<=retainedLimit_&&bytes<=retainedBytes_)return;
        auto pipeline=oldest->pipeline;entries_.erase(oldest);destroy_(pipeline);++totals_.evictions;++totals_.destroyed;
    }
}
void GraphicsPipelineReusePool::clear(){
    std::lock_guard<std::mutex> lock(mutex_);
    for(const auto& e:entries_)if(e.references)throw std::logic_error("Pipeline reuse pool still has active leases");
    for(const auto& e:entries_){destroy_(e.pipeline);++totals_.destroyed;}
    entries_.clear();
}
void GraphicsPipelineReusePool::noteBypass(){std::lock_guard<std::mutex> lock(mutex_);++totals_.bypassed;}
GraphicsPipelineReuseStatistics GraphicsPipelineReusePool::statistics() const {
    std::lock_guard<std::mutex> lock(mutex_);auto result=totals_;
    for(const auto& e:entries_)if(e.references){result.activeReferences+=e.references;++result.activePipelines;}
    else {++result.retainedPipelines;result.retainedBytes+=e.key.byteSize();}
    return result;
}
}
