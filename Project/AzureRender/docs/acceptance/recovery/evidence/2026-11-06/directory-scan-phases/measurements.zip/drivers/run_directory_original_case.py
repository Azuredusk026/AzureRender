from pathlib import Path
import subprocess,json,time,shutil,sys
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'directory-scale-original-retest';out.mkdir(exist_ok=True);build=root/'build/ninja-msvc-debug';ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
cmd=[ctest,'--test-dir',str(build),'-R','^AzureEditor.ContentDirectoryScale$','--output-on-failure','--no-tests=error','--output-junit',str(out/'test.xml')];start=time.monotonic()
with (out/'test.log').open('wb') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=240)
(out/'results.json').write_text(json.dumps({'status':'passed' if r.returncode==0 else 'failed','exitCode':r.returncode,'seconds':time.monotonic()-start,'command':cmd,'originalCaseTimeoutSeconds':180,'scope':'Original registered CTest with no external file-count observer; previous180s failures retained'},indent=2))
shutil.copy2(build/'Testing/Temporary/LastTest.log',out/'test-full.log')
with (out/'post-verify.log').open('w') as log:verify=subprocess.run([sys.executable,'-X','utf8',str(root/'tools/build_provenance.py'),'verify','--source',str(root),'--build-dir',str(build),'--config','Debug'],stdout=log,stderr=subprocess.STDOUT)
(out/'post-verify.json').write_text(json.dumps({'exitCode':verify.returncode},indent=2));print('original directory case',r.returncode,'source/product verification',verify.returncode,flush=True)
if r.returncode or verify.returncode:raise SystemExit(1)
