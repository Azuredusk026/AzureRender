from pathlib import Path
import subprocess,time,json,os,tempfile,hashlib,datetime
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'directory-scale-phase-observation';build=root/'build/ninja-msvc-debug';exe=build/'AzureContentDirectoryScaleTests.exe';temp=Path(tempfile.gettempdir());before=set(temp.glob('azure-directory-scale-*'));start=time.monotonic();wall=time.time();fixture=None;rows=[]
with (out/'test.log').open('w',encoding='utf-8') as log:
 p=subprocess.Popen([str(exe)],stdout=log,stderr=subprocess.STDOUT,cwd=build)
 (out/'task.json').write_text(json.dumps({'pid':p.pid,'command':[str(exe)],'budgetSeconds':180,'tempDirectory':str(temp),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binarySha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'scope':'Original CPU fixture with external file-count observation; not a formal performance retry'},indent=2))
 while p.poll() is None and time.monotonic()-start<180:
  if fixture is None:
   candidates=[]
   for candidate in set(temp.glob('azure-directory-scale-*'))-before:
    try:
     project=candidate/'project.azureproject'
     if project.is_file() and candidate.stat().st_ctime>=wall-2 and json.loads(project.read_text()).get('name')=='Scale':candidates.append(candidate)
    except (OSError,ValueError):pass
   if len(candidates)>1:raise RuntimeError('Ambiguous fixture ownership')
   if len(candidates)==1:fixture=candidates[0]
  if fixture is not None:
   row={'seconds':time.monotonic()-start,'metadataFiles':0,'cacheUuidDirectories':0,'cacheStagingDirectories':0,'fixturePresent':fixture.exists()}
   for base in [fixture/'assets',fixture/'assets/large']:
    try:
     with os.scandir(base) as entries:row['metadataFiles']+=sum(e.name.endswith('.azmeta') for e in entries)
    except FileNotFoundError:pass
   try:
    with os.scandir(fixture/'.azure/cache') as entries:
     for entry in entries:
      if entry.name.endswith('.tmp'):row['cacheStagingDirectories']+=1
      elif len(entry.name)==36:row['cacheUuidDirectories']+=1
   except FileNotFoundError:pass
   rows.append(row);(out/'progress.json').write_text(json.dumps({'fixture':str(fixture),'rows':rows},indent=2));print(json.dumps(row),flush=True)
  remain=min(5,max(0,180-(time.monotonic()-start)))
  try:p.wait(timeout=remain)
  except subprocess.TimeoutExpired:pass
 if p.poll() is None:
  subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True);p.wait();status='failed-original180s-timeout'
 else:status='passed' if p.returncode==0 else 'failed'
 result={'status':status,'exitCode':p.returncode,'seconds':time.monotonic()-start,'fixture':str(fixture) if fixture else None,'rows':rows,'sourceInputsUnchanged':True}
 (out/'results.json').write_text(json.dumps(result,indent=2));print(status,flush=True)
