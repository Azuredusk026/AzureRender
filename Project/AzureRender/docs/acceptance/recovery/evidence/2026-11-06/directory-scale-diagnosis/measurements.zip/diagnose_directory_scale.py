from pathlib import Path
import subprocess,time,json,hashlib
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'directory-scale-diagnosis';out.mkdir(exist_ok=True)
exe=root/'build/ninja-msvc-debug/AzureContentDirectoryScaleTests.exe';sampler=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/sample_native_stack.exe'
start=time.monotonic();rows=[]
with (out/'test.log').open('w',encoding='utf-8') as log:
 p=subprocess.Popen([str(exe)],stdout=log,stderr=subprocess.STDOUT,cwd=exe.parent)
 (out/'task.json').write_text(json.dumps({'pid':p.pid,'command':[str(exe)],'budgetSeconds':180,'scope':'Diagnostic stack sampling under original180s deadline; not a formal timing result','binarySha256':hashlib.sha256(exe.read_bytes()).hexdigest()},indent=2))
 for index,at in enumerate([20,33,47,62,79,99,122,146]):
  while p.poll() is None and time.monotonic()-start<at:time.sleep(.25)
  if p.poll() is not None:break
  began=time.monotonic()
  try:
   result=subprocess.run([str(sampler),str(p.pid),str(exe.parent)],capture_output=True,timeout=12)
   (out/f'stack-{index:02d}.log').write_bytes(result.stdout+result.stderr)
   rows.append({'elapsedSeconds':began-start,'samplerExitCode':result.returncode})
  except subprocess.TimeoutExpired as err:
   (out/f'stack-{index:02d}.log').write_bytes((err.stdout or b'')+(err.stderr or b''));rows.append({'elapsedSeconds':began-start,'samplerTimeout':True})
  print('sample',index,'elapsed',round(time.monotonic()-start,2),flush=True)
 try:code=p.wait(timeout=max(.01,180-(time.monotonic()-start)));status='passed' if code==0 else 'failed'
 except subprocess.TimeoutExpired:
  subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True);p.wait();code=p.returncode;status='failed-timeout'
 (out/'results.json').write_text(json.dumps({'status':status,'exitCode':code,'seconds':time.monotonic()-start,'samples':rows},indent=2))
 print(status,flush=True)
