from pathlib import Path
import sys,os
sys.path.insert(0,'D:\\Projects\\FYP\\Project\\AzureRender\\tools')
from write_engine_contracts import write_bundle
source=Path(__file__).resolve().parents[1];build=Path(sys.argv[1]);name=sys.argv[2]
if name=='AzureEngineContracts':
 adoption={'referenceCommit':'fixture','items':[{'id':'S1','implementation':{'interfaceFiles':['src/Runtime.hpp'],'interfaces':['RuntimeFixture'],'scope':'Fixture','verification':{'adoption':'adapted-adoption'}}}]};write_bundle(source,adoption,build/'contracts')
elif name=='AzureShaderModulePrototypes':
 for item in ['bloom-direct.spv','bloom-direct.spv.json','bloom-cached.spv','bloom-cached.spv.json']:
  f=build/'shader-modules'/item;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b'fixture shader module')
elif name=='AzureManagedArtifacts':
 for item in ['coreclr/Azure.Engine.dll','coreclr/Azure.Engine.runtimeconfig.json','coreclr/Azure.Engine.deps.json','coreclr/Azure.Samples.dll','nativeaot/Azure.Engine.Native.dll','manifest.json','complete.stamp']:
  f=build/'managed'/item;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b'fixture managed product')
else:(build/(name+('.exe' if os.name=='nt' else ''))).write_bytes(('fixture-product:'+name).encode())
