from pathlib import Path
import os,subprocess,sys,json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;temporary=out/'tmp';temporary.mkdir(exist_ok=True)
env=os.environ.copy();env.update(TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary),SQLITE_TMPDIR=str(temporary),PYTHONPATH=str(root/'tools'))
names=['test_daily_drains_multiple_batches_of_expired_generated_tasks','test_daily_stops_at_its_batch_limit','test_daily_rechecks_activity_between_batches','test_daily_budget_is_shared_by_all_batches','test_daily_reports_blocked_batch_without_continuing','test_shared_deadline_protects_expired_compact_evidence']
command=[sys.executable,'-X','utf8','-m','unittest',*["test_artifact_maintenance.MaintenanceTests."+name for name in names]]
with (out/'red.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
text=(out/'red.log').read_text(errors='replace');assert r.returncode!=0 and 'Ran 6 tests' in text and 'FAILED' in text,text
(out/'red.json').write_text(json.dumps(dict(command=command,exitCode=r.returncode,failedExpected=True),indent=2));print(text[-4000:])
