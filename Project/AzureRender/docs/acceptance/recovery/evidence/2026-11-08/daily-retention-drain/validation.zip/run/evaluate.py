from pathlib import Path
import os,sys,tempfile,subprocess,json,time,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;temporary=out/'tmp';temporary.mkdir(exist_ok=True)
for key in ['TEMP','TMP','TMPDIR','SQLITE_TMPDIR']:os.environ[key]=str(temporary)
tempfile.tempdir=str(temporary);sys.path.insert(0,str(root/'tools'));import artifact_maintenance as maintenance
with tempfile.TemporaryDirectory() as workspace:
 engine=Path(workspace)/'AzureRender';engine.mkdir();build=engine/'build';(build/'runs').mkdir(parents=True)
 subprocess.run(['git','init','--quiet',str(engine)],check=True,capture_output=True)
 sentinel=engine/'sentinel.txt';sentinel.write_bytes(b'isolated-source-contract');(engine/'.gitignore').write_text('build/\n')
 subprocess.run(['git','-C',str(engine),'add','sentinel.txt','.gitignore'],check=True,capture_output=True)
 original=hashlib.sha256(sentinel.read_bytes()).hexdigest();before=maintenance.git_state(engine);paths=[];when=time.time()-2*86400
 for index in range(33):
  path=build/'runs'/('daily-'+str(index));maintenance.create_run(build,path,dict(plannedBytes=4096),retain_recovery=False)
  (path/'payload.bin').write_bytes(b'x'*4096);(path/'result.json').write_text('{"status":"generated"}')
  maintenance.seal(build,path);(path/'.finished').touch();os.utime(path/'.finished',(when,when))
  with maintenance.database(build,True) as db:
   record=maintenance.rows(db)[path.name];record['closed']=when;maintenance.save(db,path.name,record)
  paths.append(path)
 started=time.monotonic();result=maintenance.daily(build,apply=True);seconds=time.monotonic()-started
 assert all(not path.exists() for path in paths)
 assert [len(batch['items']) for batch in result['managed']['batches']]==[10,10,10,3]
 assert result['managed']['stopReason']=='drained' and result['status']=='completed'
 assert maintenance.git_state(engine)==before and hashlib.sha256(sentinel.read_bytes()).hexdigest()==original
 report=dict(status='passed',expiredTasks=33,releasedTasks=len(result['managed']['items']),batchSizes=[len(b['items']) for b in result['managed']['batches']],seconds=seconds,deadlineSeconds=maintenance.POLICY['maintenanceSeconds'],trackedSentinelUnchanged=True,gitStateUnchanged=True,scope='Isolated D-volume repository; actual process audit, Git guards, sealing, compact evidence, and permanent removal of generated fixture payloads; no live project cleanup invoked',result=result)
 (out/'evaluation.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='result'}))
