from pathlib import Path
import os,sys,subprocess,json,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;temporary=out/'tmp';temporary.mkdir(exist_ok=True)
env=os.environ.copy();env.update(TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary),SQLITE_TMPDIR=str(temporary),PYTHONPATH=str(root/'tools'))
modules=['test_artifact_maintenance','test_artifact_cleanup','test_artifact_budget','test_artifact_pipeline_cache','test_artifact_asset_cleanup','test_artifact_cache_cleanup']
command=[sys.executable,'-X','utf8','-m','unittest',*modules];started=time.monotonic()
with (out/'checks.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
(out/'checks.json').write_text(json.dumps(dict(command=command,exitCode=r.returncode,seconds=time.monotonic()-started,tempRoot=str(temporary)),indent=2));print((out/'checks.log').read_text(errors='replace')[-5000:]);raise SystemExit(r.returncode)
