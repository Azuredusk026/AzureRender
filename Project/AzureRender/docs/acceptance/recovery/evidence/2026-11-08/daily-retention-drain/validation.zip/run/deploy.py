from pathlib import Path
import json,hashlib,subprocess,os,sys,stat,shutil
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;repo=root.parents[1]
canonical=root/'tools/skills/azurerender-artifact-maintenance';deployed=repo/'.agents/skills/azurerender-artifact-maintenance';legacy=Path('C:/Users/admin/.codex/skills/azurerender-artifact-maintenance').resolve()
names=['SKILL.md','agents/openai.yaml','references/legacy-recovery.md','scripts/maintain.py']
assert sorted(p.relative_to(legacy).as_posix() for p in legacy.rglob('*') if p.is_file())==sorted(names)
rows=[]
for name in names:
 p=legacy/name;assert p.resolve().is_relative_to(legacy)
 for parent in [p,*p.parents]:assert not parent.stat().st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT
 # The complete source package was identical before its current instruction edit.
 expected=subprocess.check_output(['git','show','525a287:Project/AzureRender/tools/skills/azurerender-artifact-maintenance/'+name])
 actual=p.read_bytes();assert actual.replace(b'\r\n',b'\n')==expected.replace(b'\r\n',b'\n'),name
 rows.append(dict(path=str(p),bytes=len(actual),sha256=hashlib.sha256(actual).hexdigest(),source='525a287:Project/AzureRender/tools/skills/azurerender-artifact-maintenance/'+name))
(out/'legacy-skill-plan.json').write_text(json.dumps(dict(paths=rows,projectSkill=str(deployed)),indent=2))
(deployed/'agents').mkdir(exist_ok=True);shutil.copyfile(canonical/'agents/openai.yaml',deployed/'agents/openai.yaml')
env=os.environ.copy();temporary=out/'tmp';temporary.mkdir(exist_ok=True);env.update(TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary),SQLITE_TMPDIR=str(temporary))
validator='C:/Users/admin/.codex/skills/.system/skill-creator/scripts/quick_validate.py';checks=[]
for folder in [canonical,deployed]:
 command=[sys.executable,'-X','utf8',validator,str(folder)];r=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True)
 checks.append(dict(command=command,exitCode=r.returncode,output=r.stdout+r.stderr));assert r.returncode==0,checks[-1]
link=(deployed/'../../../Project/AzureRender/tools/skills/azurerender-artifact-maintenance/SKILL.md').resolve();assert link==canonical/'SKILL.md' and link.is_file()
fixture=out/'fixture/AzureRender';(fixture/'tools').mkdir(parents=True,exist_ok=True);(fixture/'CMakeLists.txt').write_text('')
(fixture/'tools/artifact_maintenance.py').write_text('import os,sys,json;print(json.dumps(dict(args=sys.argv[1:],cwd=os.getcwd())))')
command=[sys.executable,'-X','utf8',str(canonical/'scripts/maintain.py'),'daily','--apply','--engine',str(fixture)]
r=subprocess.run(command,cwd=repo,env=env,capture_output=True,text=True);assert r.returncode==0,(r.stdout,r.stderr);forward=json.loads(r.stdout);assert forward['args']==['daily','--apply'] and Path(forward['cwd'])==fixture
for row in rows:
 p=Path(row['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];p.unlink()
for folder in [legacy/'agents',legacy/'references',legacy/'scripts',legacy]:
 assert folder.resolve().is_relative_to(legacy) and not any(folder.iterdir());folder.rmdir()
report=dict(status='deployed-in-project',projectSkill=str(deployed),projectSource=str(canonical),removedLegacyFiles=rows,removedLegacyBytes=sum(r['bytes'] for r in rows),legacySkillPresent=legacy.exists(),validators=checks,forwarding=dict(command=command,result=forward),projectPayloadOnC=False)
(out/'deployment.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));(root/'build/maintenance/project-skill-deployment.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['validators','removedLegacyFiles','forwarding']}))
