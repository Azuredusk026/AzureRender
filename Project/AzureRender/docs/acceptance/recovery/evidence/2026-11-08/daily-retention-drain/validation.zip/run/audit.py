from pathlib import Path
import json,sys,hashlib,subprocess
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
measured=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text());current=inputs(root)
changes=[name for name in sorted(current.keys()|measured['source'].keys()) if current.get(name)!=measured['source'].get(name)]
assert changes==['tools/artifact_maintenance.py','tools/skills/azurerender-artifact-maintenance/SKILL.md','tools/test_artifact_maintenance.py'],changes
products=[]
for config in ['release','debug']:
 proof=json.loads((root/('build/ninja-msvc-'+config)/'build-provenance.json').read_text());assert proof['source']==measured['source']
 for name,sha in proof['products'].items():assert digest(Path(name))==sha,name
 products.append(dict(configuration=config,verifiedProducts=len(proof['products']),runtimeAndShaderBytesUnchanged=True))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
user=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest();assert user=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
deployment=json.loads((out/'deployment.json').read_text());assert not Path('C:/Users/admin/.codex/skills/azurerender-artifact-maintenance').exists()
automation=Path('C:/Users/admin/.codex/automations/azurerender/automation.toml').read_text(encoding='utf-8');assert 'D:/Projects/FYP/.agents/skills/azurerender-artifact-maintenance/SKILL.md' in automation and 'C:/Users/admin/.codex/skills/azurerender-artifact-maintenance' not in automation
assert 'notification_policy = "failed_runs_only"' in automation and 'BYHOUR=10;BYMINUTE=0' in automation and 'status = "ACTIVE"' in automation
report=dict(sourceBase='525a287',changedBuildInputs=changes,scope='Artifact tools and skill metadata only; runtime build manifest predates tool changes and must be refreshed before the next runtime measurement',runtimeAndShaderInputsUnchanged=True,products=products,userDiffSha256=user,projectSkillOnD=True,legacyCSkillFiles=0,automation=dict(id='azurerender',kind='heartbeat',dailyHour=10,timezone='Asia/Shanghai',active=True,notificationPolicy='failed_runs_only',projectSkillOnD=True,scheduledExecutionObserved=False),newRuntimeBuildExecuted=False,newGpuMeasurementExecuted=False)
(out/'audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
