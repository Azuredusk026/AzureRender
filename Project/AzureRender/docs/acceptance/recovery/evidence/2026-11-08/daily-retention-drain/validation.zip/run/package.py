from pathlib import Path
import json,sys,zipfile,hashlib,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;repo=root.parents[1];sys.path.insert(0,str(root/'tools'));from build_provenance import digest
checks=json.loads((out/'checks.json').read_text());assert checks['exitCode']==0 and 'Ran 82 tests' in (out/'checks.log').read_text() and 'OK (skipped=1)' in (out/'checks.log').read_text()
deployment=json.loads((out/'deployment.json').read_text());audit=json.loads((out/'audit.json').read_text());evaluation=json.loads((out/'evaluation.json').read_text());assert evaluation['releasedTasks']==33 and evaluation['batchSizes']==[10,10,10,3]
paths=['tools/artifact_maintenance.py','tools/test_artifact_maintenance.py','tools/skills/azurerender-artifact-maintenance/SKILL.md','tools/skills/azurerender-artifact-maintenance/agents/openai.yaml','tools/skills/azurerender-artifact-maintenance/scripts/maintain.py','tools/skills/azurerender-artifact-maintenance/references/legacy-recovery.md']
members={'source/Project/AzureRender/'+name:root/name for name in paths}
for name in ['AGENT.md','.agents/skills/azurerender-artifact-maintenance/SKILL.md','.agents/skills/azurerender-artifact-maintenance/agents/openai.yaml']:members['source/'+name]=repo/name
for p in out.iterdir():
 if p.is_file() and p.suffix in ['.py','.json','.log']:members['run/'+p.name]=p
evidence=root/'docs/acceptance/recovery/evidence/2026-11-08/daily-retention-drain';evidence.mkdir(parents=True,exist_ok=True);archive=evidence/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(members.items()):z.write(path,name)
assert archive.stat().st_size<8*2**20
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,path in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='project-skill-daily-drain-deployed',sourceBase='525a287',sourceHashes={name:digest(path) for name,path in members.items() if name.startswith('source/')},checks=dict(total=82,passed=81,skipped=1,reason='Windows symbolic-link creation unavailable',run=checks),deployment=deployment,evaluation={k:v for k,v in evaluation.items() if k!='result'},runtimeAudit=audit,policy=dict(maximumBatchItems=10,maximumDailyBatches=10,maintenanceSeconds=120,retentionDays=1),evidenceBytes=archive.stat().st_size,evidenceSha256=digest(archive),formalPerformancePassed=False,overallVisualAcceptance='failed-user-review')
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'docs/development/artifact-manifest.json';data=json.loads(p.read_text(encoding='utf-8'));data['managedTaskPolicy'].update(maximumBatchItems=10,dailyMaximumBatches=10,repositorySkill='.agents/skills/azurerender-artifact-maintenance/SKILL.md',skillSource='tools/skills/azurerender-artifact-maintenance/SKILL.md')
data['milestones'].insert(0,dict(path='runs/'+out.name,name='每日回收与项目技能部署',status='ProjectSkillDailyDrainDeployed',sourceBase='525a287',evidence='docs/acceptance/recovery/daily-retention-drain.md',checksPassed=81,checksSkipped=1,maximumBatchItems=10,dailyMaximumBatches=10,maintenanceSeconds=120,projectSkillOnD=True,legacyCSkillFiles=0,isolatedExpiredTasksReleased=33,isolatedMaintenanceSeconds=evaluation['seconds'],runtimeAndShaderBytesUnchanged=True))
p.write_text(json.dumps(data,ensure_ascii=False,indent=2).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/development/artifact-retention.md','docs/acceptance/recovery/daily-retention-drain.md','docs/plans/2026-11-08-daily-retention-drain.md','tools/skills/azurerender-artifact-maintenance/SKILL.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],passed=81,skipped=1,projectSkillOnD=True,legacyCSkillFiles=0,isolatedTasksReleased=33,seconds=evaluation['seconds'],evidenceBytes=archive.stat().st_size)))
