from pathlib import Path
import os,sys,time,json,cProfile,pstats,io,statistics
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
import artifact_maintenance as maintenance
tag=sys.argv[1];assert tag in ['baseline','candidate']
target=out.parent/'20261108-124916-main-depth-reuse-2703c1';rows=[]
for _ in range(3):
 cpu=time.process_time();wall=time.perf_counter();size=maintenance.measure(target)
 rows.append(dict(cpuSeconds=time.process_time()-cpu,wallSeconds=time.perf_counter()-wall,bytes=size))
profile=cProfile.Profile();profile.runcall(maintenance.measure,target);stream=io.StringIO();pstats.Stats(profile,stream=stream).strip_dirs().sort_stats('cumulative').print_stats(16)
(out/(tag+'-profile.log')).write_text(stream.getvalue())
report=dict(target=str(target),files=sum(len(files) for _,_,files in os.walk(target)),samples=rows,cpuMedianSeconds=statistics.median(r['cpuSeconds'] for r in rows),wallMedianSeconds=statistics.median(r['wallSeconds'] for r in rows))
(out/(tag+'.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True);print(stream.getvalue())
