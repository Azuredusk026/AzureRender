from pathlib import Path
import os,sys,json,subprocess
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
if '--inside' not in sys.argv:
 env=os.environ.copy();temporary=out/'tmp';temporary.mkdir(exist_ok=True);env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary))
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],cwd=root,env=env).returncode)
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
old={config:json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text()) for config in ['release','debug']}
assert old['release']['source']==old['debug']['source'];current=inputs(root)
changed=sorted(name for name in current.keys()|old['release']['source'].keys() if current.get(name)!=old['release']['source'].get(name))
assert changed==['tools/artifact_maintenance.py','tools/test_artifact_maintenance.py'],changed
products={name:sha for config in old.values() for name,sha in config['products'].items()}
if (out/'runtime-identity.json').is_file():products.update(json.loads((out/'runtime-identity.json').read_text())['products'])
for config in ['release','debug']:
 command=[sys.executable,'-X','utf8','tools/build_provenance.py','build','--runtime-only','--build-dir','build/ninja-msvc-'+config,'--config',config.capitalize()]
 with (out/(config+'-refresh.log')).open('wb') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(out/(config+'-refresh.log')).read_text(errors='replace')[-2500:]
 print(config+' runtime provenance refreshed',flush=True)
assert all(digest(Path(name))==sha for name,sha in products.items())
report=dict(status='passed',changedSourceFiles=changed,unchangedProducts=len(products),unchangedPrograms=sum(name.endswith('.spv') for name in products),products=products,sourceInputsUnchangedDuringBuild=inputs(root)==current)
(out/'runtime-identity.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='products'}),flush=True)
