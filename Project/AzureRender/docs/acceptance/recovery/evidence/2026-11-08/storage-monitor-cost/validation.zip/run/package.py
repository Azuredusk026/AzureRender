from pathlib import Path
import sys,json,hashlib,zipfile,subprocess,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify
baseline=json.loads((out/'baseline.json').read_text());candidate=json.loads((out/'candidate.json').read_text());before=json.loads((out/'baseline-monitor.json').read_text());after=json.loads((out/'candidate-monitor.json').read_text())
assert baseline['files']==candidate['files']==110
assert {r['bytes'] for r in baseline['samples']+candidate['samples']}=={44682954}
assert candidate['wallMedianSeconds']<baseline['wallMedianSeconds']*.25 and after['parentCpuSeconds']<before['parentCpuSeconds']*.25
checks=json.loads((out/'green-checks.json').read_text());log=(out/'green.log').read_text();assert checks['exitCode']==0 and 'Ran 76 tests' in log and 'OK (skipped=1)' in log
identity=json.loads((out/'runtime-identity.json').read_text());assert identity['status']=='passed' and identity['unchangedProducts']==1490
assert all(digest(Path(name))==sha for name,sha in identity['products'].items())
for config in ['release','debug']:verify(root,json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text()))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
user=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest();assert user=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
skill=root/'tools/skills/azurerender-artifact-maintenance';installed=Path('C:/Users/admin/.codex/skills/azurerender-artifact-maintenance');skillFiles={p.relative_to(skill).as_posix():digest(p) for p in skill.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
assert len(skillFiles)==4 and all(digest(installed/name)==sha for name,sha in skillFiles.items())
archive=Path('C:/Users/admin/.codex/archives/AzureRender');archiveFiles=[p for p in archive.rglob('*') if p.is_file()] if archive.exists() else [];assert not archiveFiles
sources=['tools/artifact_maintenance.py','tools/test_artifact_maintenance.py'];members={}
for p in out.rglob('*'):
 if p.is_file() and 'tmp' not in p.relative_to(out).parts and p.suffix in ['.py','.json','.log'] and p.stat().st_size<2*2**20:members['run/'+p.relative_to(out).as_posix()]=p
for name in sources:members['source/'+name]=root/name
evidence=root/'docs/acceptance/recovery/evidence/2026-11-08/storage-monitor-cost';evidence.mkdir(parents=True,exist_ok=True);package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='ready-low-overhead-monitor',sourceBase='794aad1',sourceHashes={name:digest(root/name) for name in sources},directoryBaseline=baseline,directoryCandidate=candidate,scanWallReductionFraction=1-candidate['wallMedianSeconds']/baseline['wallMedianSeconds'],monitorBaseline=before,monitorCandidate=after,monitorCpuReductionFraction=1-after['parentCpuSeconds']/before['parentCpuSeconds'],checks=checks,testsExecuted=76,testsPassed=75,testsSkipped=[dict(name='test_artifact_maintenance.MaintenanceTests.test_indexed_symbolic_link_protects_name_and_referent',reason='Symbolic link creation is unavailable')],runtimeIdentity=identity,userDiffSha256=user,skillDeploymentUnchanged=True,skillFileHashes=skillFiles,cProjectArchiveFiles=0,externalProjectStorageUsed=False,nativePerformanceTestsStarted=False,evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),formalPerformancePassed=False,overallVisualAcceptance='failed-user-review')
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'docs/development/artifact-manifest.json';data=json.loads(p.read_text());data['milestones']=[m for m in data['milestones'] if m['path']!='runs/'+out.name];data['milestones'].insert(0,dict(path='runs/'+out.name,name='前台空间监控开销',status='ReadyLowOverheadMonitor',sourceBase='794aad1',evidence='docs/acceptance/recovery/storage-monitor-cost.md',testsPassed=75,testsSkipped=1,monitorCpuReductionFraction=report['monitorCpuReductionFraction'],runtimeProductsUnchanged=True,externalProjectStorageUsed=False));p.write_text(json.dumps(data,ensure_ascii=False,indent=2).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-storage-monitor-cost.md','docs/development/artifact-retention.md','docs/acceptance/recovery/storage-monitor-cost.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],scanWallReductionFraction=report['scanWallReductionFraction'],monitorCpuReductionFraction=report['monitorCpuReductionFraction'],testsPassed=75,unchangedRuntimeProducts=identity['unchangedProducts'],evidenceBytes=package.stat().st_size,userDiffPreserved=True),ensure_ascii=False))
