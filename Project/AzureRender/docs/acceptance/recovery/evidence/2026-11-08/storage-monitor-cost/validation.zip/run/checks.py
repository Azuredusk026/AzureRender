from pathlib import Path
import subprocess,os,json,sys,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;temporary=out/'tmp';temporary.mkdir(exist_ok=True)
env=os.environ.copy();env.update({key:str(temporary) for key in ['TEMP','TMP','TMPDIR','SQLITE_TMPDIR']})
tag=sys.argv[1];assert tag in ['red','red-replacement','green']
targets=['test_artifact_maintenance.MaintenanceTests.test_measure_bounds_filesystem_queries_for_nested_payload'] if tag=='red' else ['test_artifact_maintenance.MaintenanceTests.test_measure_rejects_an_ancestor_replaced_during_enumeration'] if tag=='red-replacement' else ['test_artifact_maintenance','test_artifact_cleanup','test_artifact_budget','test_artifact_asset_cleanup','test_artifact_cache_cleanup','test_artifact_pipeline_cache']
command=[sys.executable,'-X','utf8','-m','unittest',*targets];started=time.perf_counter()
with (out/(tag+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root/'tools',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
report=dict(command=command,exitCode=r.returncode,seconds=time.perf_counter()-started);(out/(tag+'-checks.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report));print((out/(tag+'.log')).read_text(errors='replace')[-2500:])
assert (r.returncode!=0 and 'Per-file ancestor queries' in (out/'red.log').read_text()) if tag=='red' else (r.returncode!=0 and 'ValueError not raised' in (out/'red-replacement.log').read_text()) if tag=='red-replacement' else r.returncode==0
