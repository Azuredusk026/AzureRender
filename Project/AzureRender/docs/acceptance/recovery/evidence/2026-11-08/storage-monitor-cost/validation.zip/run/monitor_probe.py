from pathlib import Path
import importlib.util,sys,time,json,shutil
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
tag=sys.argv[1];assert tag in ['baseline','candidate']
fixture=out/'probe-files';fixture.mkdir(exist_ok=True)
for index in range(100):(fixture/str(index)).touch(exist_ok=True)
if tag=='baseline':
 spec=importlib.util.spec_from_file_location('artifact_maintenance',out/'original-source/tools/artifact_maintenance.py');module=importlib.util.module_from_spec(spec);sys.modules['artifact_maintenance']=module;spec.loader.exec_module(module)
else:import artifact_maintenance as module
command=[sys.executable,'-X','utf8','-c','import time;print("monitor-probe",flush=True);time.sleep(3)']
cpu=time.process_time();wall=time.perf_counter();result=module.guarded_run(root/'build',out.name,command,timeout=10)
report=dict(status=result['status'],exitCode=result['exitCode'],parentCpuSeconds=time.process_time()-cpu,wallSeconds=time.perf_counter()-wall,execution=result,monitorSource=str(Path(module.__file__).resolve()))
shutil.copyfile(out/'process.log',out/(tag+'-monitor-process.log'));(out/(tag+'-monitor.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
assert result['status']=='exited' and result['exitCode']==0
