from pathlib import Path
import subprocess,sys,os
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',TEMP=str(out/'tmp'),TMP=str(out/'tmp'),TMPDIR=str(out/'tmp'),VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 (out/'tmp').mkdir(exist_ok=True)
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],env=env).returncode)
for config in ['Debug','Release']:
 command=[sys.executable,'-X','utf8','tools/build_provenance.py','build','--build-dir',f'build/ninja-msvc-{config.lower()}','--config',config,'--runtime-only']
 with (out/(config.lower()+'-build.log')).open('wb') as log:subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(config+' runtime provenance passed',flush=True)
