from pathlib import Path
import tempfile,os,json
out=Path(__file__).resolve().parent
temporary=Path(tempfile.mkdtemp())/'probe.bin';temporary.write_bytes(b'bounded task temporary storage')
expected=out/'tmp';assert temporary.is_relative_to(expected)
result=dict(path=str(temporary),bytes=temporary.stat().st_size,environment={key:os.environ.get(key) for key in ['TEMP','TMP','TMPDIR','SQLITE_TMPDIR']})
assert set(result['environment'].values())=={str(expected)}
(out/'temporary-probe.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
