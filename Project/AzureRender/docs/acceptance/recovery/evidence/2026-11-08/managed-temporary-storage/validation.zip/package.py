from pathlib import Path
import json,sys,hashlib,subprocess,zipfile,re,tomllib,shutil
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify
baseline=json.loads((out/'baseline.json').read_text());proof=[]
for config,products in baseline['products'].items():
 assert all(Path(name).is_file() and digest(Path(name))==sha for name,sha in products.items())
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,sha256=digest(p)))
assert all(digest(root/name)==sha for name,sha in baseline['runtimeSource'].items())
projectLock=json.loads((out.parent/'20261107-171836-consolidated-preparation-images-374280/image/frozen-inputs.json').read_text())['project']
assert all(Path(name).is_file() and digest(Path(name))==sha for name,sha in projectLock.items())
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
skill=root/'tools/skills/azurerender-artifact-maintenance';installed=Path('C:/Users/admin/.codex/skills/azurerender-artifact-maintenance');skillFiles=[]
for p in skill.rglob('*'):
 if p.is_file():
  deployed=installed/p.relative_to(skill);assert digest(p)==digest(deployed);skillFiles.append(dict(path=p.relative_to(skill).as_posix(),bytes=p.stat().st_size,sha256=digest(p)))
cArchive=Path('C:/Users/admin/.codex/archives/AzureRender');archiveFiles=[p for p in cArchive.rglob('*') if p.is_file()] if cArchive.exists() else [];assert not archiveFiles
automation=tomllib.loads(Path('C:/Users/admin/.codex/automations/azurerender/automation.toml').read_text(encoding='utf-8'));schedule={key:automation.get(key) for key in ['id','name','status','rrule','notification_policy','cwds']}
green=(out/'green.log').read_text(encoding='utf-8-sig');assert 'Ran 54 tests' in green and 'OK (skipped=1)' in green
final=(out/'final-scoped.log').read_text(encoding='utf-8-sig');assert 'Ran 3 tests' in final and 'OK' in final
receipt=json.loads((root/'build/maintenance/process-receipts'/f'{out.name}.json').read_text());assert receipt['exitCode']==0 and receipt['status']=='exited'
(out/'process-receipt.json').write_text(json.dumps(receipt,indent=2))
evidence=root/'docs/acceptance/recovery/evidence/2026-11-08/managed-temporary-storage';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.json','.log']}
for p in [root/'tools/artifact_maintenance.py',root/'tools/test_artifact_maintenance.py',skill/'SKILL.md']:members['source/'+p.name]=p
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='task-local-temporary-storage-verified',sourceBase='74b4dfc',toolTests=dict(run=54,passed=53,skipped=1,finalScopedPassed=3),temporaryProbe=json.loads((out/'temporary-probe.json').read_text()),processReceipt=receipt,skillFiles=skillFiles,cDriveProjectArchiveFiles=len(archiveFiles),dailySchedule=schedule,scheduleObservedExecuting=False,productionProvenance=proof,unchangedProducts=sum(map(len,baseline['products'].values())),unchangedRuntimeFiles=len(baseline['runtimeSource']),unchangedProjectInputs=len(projectLock),userDiffSha256=protected,volumeFreeBytes=shutil.disk_usage(root).free,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package))
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-managed-temporary-storage.md','docs/acceptance/recovery/managed-temporary-storage.md','docs/development/artifact-retention.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],products=report['unchangedProducts'],projectInputs=len(projectLock),evidenceBytes=package.stat().st_size,installedSkillBytes=sum(p['bytes'] for p in skillFiles),freeBytes=report['volumeFreeBytes'])))
