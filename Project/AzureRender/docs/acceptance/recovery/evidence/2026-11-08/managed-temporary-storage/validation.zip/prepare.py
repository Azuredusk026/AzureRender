from pathlib import Path
import json,sys,hashlib,subprocess
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest
products={}
for config in ['release','debug']:
 manifest=json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text())
 products[config]=manifest['products']
 assert all(Path(name).is_file() and digest(Path(name))==sha for name,sha in manifest['products'].items())
source={str(p.relative_to(root)):digest(p) for folder in ['src','shaders'] for p in (root/folder).rglob('*') if p.is_file()}
(out/'baseline.json').write_text(json.dumps(dict(products=products,runtimeSource=source),indent=2))
manifest=root/'docs/development/artifact-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'));data['milestones']=[m for m in data['milestones'] if m['path']!='runs/'+out.name];data['milestones'].insert(0,dict(path='runs/'+out.name,name='受管任务临时目录',status='TaskLocalTemporaryStorage',sourceBase='74b4dfc',evidence='docs/acceptance/recovery/managed-temporary-storage.md',temporaryDirectory='task/tmp',retentionDays=1));manifest.write_text(json.dumps(data,indent=2,ensure_ascii=False).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md']:
 p=root/name;text=p.read_text(encoding='utf-8');start=text.index('[目录维护技能]');end=text.index('\n',start)
 line='[任务临时目录]('+('docs/acceptance/recovery/' if name=='README.md' else '../acceptance/recovery/')+'managed-temporary-storage.md)随任务计入配额及每日回收，子进程沿用项目所在卷。\n'
 if line not in text:p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')
print(json.dumps(dict(frozenProducts=sum(map(len,products.values())),runtimeFiles=len(source))))
