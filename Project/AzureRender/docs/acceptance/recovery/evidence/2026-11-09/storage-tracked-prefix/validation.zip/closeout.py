from pathlib import Path
import os,sys,json,hashlib,zipfile,shutil,subprocess
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,tracked_paths,write_json
from artifact_cleanup import remove_artifact
from build_provenance import verify,digest
os.environ.update(managed_environment(o/'tmp'))
for role in ['green','extra']:assert json.loads((o/(role+'-execution.json')).read_text())['exitCode']==0
assert 'Ran 70 tests' in (o/'green.log').read_text() and 'OK (skipped=1)' in (o/'green.log').read_text()
assert 'Ran 3 tests' in (o/'extra.log').read_text() and 'Symbolic link creation is unavailable' in (o/'extra.log').read_text()
benchmark=json.loads((o/'benchmark.json').read_text());benchmark['status']='tracking-guard-and-owned-fixture-benchmark';benchmark.pop('deletedFiles',None);benchmark['deletedProjectArtifacts']=0;write_json(o/'benchmark.json',benchmark)
assert benchmark['ownedFileDeletion']['files']==50 and benchmark['ownedFileDeletion']['remainingFiles']==0
assert benchmark['queries'][0]['speedRatio']>100 and benchmark['ownedFileDeletion']['seconds']<5
builds={}
with zipfile.ZipFile(r/'docs/acceptance/nr/evidence/2026-11-09/temporal-shadow-history-prototype/validation.zip') as z:
 baselines={config:json.loads(z.read(config+'-build-provenance.json')) for config in ['release','debug']}
for config in ['release','debug']:
 p=r/('build/ninja-msvc-'+config)/'build-provenance.json';m=json.loads(p.read_text());verify(r,m);shutil.copyfile(p,o/(config+'-build-provenance.json'))
 prior=baselines[config]['products'];selected={name:sha for name,sha in prior.items() if (Path(name).parent.name=='shaders' and name.endswith('.spv')) or Path(name).name in ['AzureRender.exe','AzurePlayer.exe','AzureGameLauncher.exe']}
 assert sum(name.endswith('.spv') for name in selected)==675
 assert all(digest(Path(name))==sha for name,sha in selected.items())
 builds[config]=dict(verified=True,unchangedProgramAndShaderProducts=len(selected),unchangedMainShaders=675)
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py'];ph=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest();assert ph=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
for rel in ['tools/artifact_cleanup.py','tools/artifact_maintenance.py','tools/test_artifact_cleanup.py','tools/test_artifact_maintenance.py','tools/skills/azurerender-artifact-maintenance/SKILL.md','docs/development/artifact-retention.md']:
 p=o/'final-source'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,p)
report=dict(status='indexed-tracking-protection-verified',run=o.name,baselineCommit='77e0b11',benchmark=benchmark,tests=dict(baseTotal=70,basePassed=69,baseSkipped=1,additionalUniquePassed=2,skipReason='Symbolic link creation is unavailable',nestedWorktreeTaskProtectionRetained=True,testFixtureRoot='D:/Projects/FYP/Project/AzureRender/build/maintenance/test-fixtures'),builds=builds,protectedDiffSha256=ph,newNativeImageProcesses=0,newNativePerformanceProcesses=0,dailyMaintenanceRerun=False,newCDriveProjectPayload=False);write_json(o/'results.json',report)
dest=r/'docs/acceptance/recovery/evidence/2026-11-09/storage-tracked-prefix';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
selected=[p for p in sorted(o.rglob('*')) if p.is_file() and 'tmp' not in p.relative_to(o).parts and p.suffix.lower() in ['.py','.md','.json','.log','.txt']]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in selected:z.write(p,p.relative_to(o).as_posix())
assert archive.stat().st_size<8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in selected:assert hashlib.sha256(z.read(p.relative_to(o).as_posix())).hexdigest()==digest(p)
report['package']=dict(bytes=archive.stat().st_size,files=len(selected),sha256=digest(archive));write_json(dest/'results.json',report)
tracked=tracked_paths(r);before=shutil.disk_usage(r).free;start=__import__('time').perf_counter()
removed=remove_artifact(r/'build',o/'tmp',tracked,apply=True) if (o/'tmp').exists() else None
cleanup=dict(removed=removed,seconds=__import__('time').perf_counter()-start,freeBefore=before,freeAfter=shutil.disk_usage(r).free);write_json(o/'cleanup.json',cleanup);print(json.dumps(dict(package=report['package'],cleanup=cleanup)))
