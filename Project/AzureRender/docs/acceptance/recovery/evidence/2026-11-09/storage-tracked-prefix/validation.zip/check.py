from pathlib import Path
import sys,os,json,subprocess,tempfile
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
os.environ.update(managed_environment(o/'tmp'));os.environ['PYTHONPATH']=str(r/'tools');mode=sys.argv[1]
command=[sys.executable,'-X','utf8','-m','unittest','test_artifact_cleanup.CleanupTests.test_indexed_tracking_guard_does_not_walk_all_paths']
if mode!='red':command=[sys.executable,'-X','utf8','-m','unittest','test_artifact_cleanup','test_artifact_maintenance','test_artifact_asset_cleanup','test_artifact_cache_cleanup']
if mode=='extra':command=[sys.executable,'-X','utf8','-m','unittest','-v','test_artifact_cleanup.CleanupTests.test_unicode_and_space_prefix_boundaries','test_artifact_maintenance.MaintenanceTests.test_indexed_gitlink_protects_its_entire_directory','test_artifact_maintenance.MaintenanceTests.test_indexed_symbolic_link_protects_name_and_referent']
if '--inside' in sys.argv:
 base=r/'build/maintenance/test-fixtures';base.mkdir(parents=True,exist_ok=True)
 assert base.resolve().is_relative_to((r/'build/maintenance').resolve())
 with tempfile.TemporaryDirectory(prefix=o.name+'-',dir=base) as fixture:
  env=managed_environment(Path(fixture)/'tmp');env['PYTHONPATH']=str(r/'tools')
  result=subprocess.run(command,env=env,timeout=180)
 raise SystemExit(result.returncode)
if mode!='red':command=[sys.executable,'-X','utf8',str(Path(__file__).resolve()),mode,'--inside']
result=guarded_run(r/'build',o.name,command,180);(o/(mode+'-execution.json')).write_text(json.dumps(result,indent=2));(o/(mode+'.log')).write_bytes((o/'process.log').read_bytes());print(result);print((o/'process.log').read_text(errors='replace')[-2200:]);assert result['exitCode']==(1 if mode=='red' else 0)
