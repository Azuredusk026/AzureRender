from pathlib import Path
import os,json,subprocess,sys
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
os.environ.update(managed_environment(o/'tmp'));mode=sys.argv[-1]
if '--inside' not in sys.argv:
 os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 result=guarded_run(r/'build',o.name,[str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',mode],300);(o/(mode.lower()+'-execution.json')).write_text(json.dumps(result,indent=2));print(result);raise SystemExit(result['exitCode'])
b=r/('build/ninja-msvc-'+mode.lower())
with (o/(mode.lower()+'-build.log')).open('wb') as log:result=subprocess.run([sys.executable,'-X','utf8','tools/build_provenance.py','build','--build-dir',str(b),'--config',mode,'--runtime-only'],stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(result.returncode)
