from pathlib import Path
import sys,time,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import tracked_paths
start=time.perf_counter();index=tracked_paths(r);loaded=time.perf_counter()-start
queries=[o/'virtual-owned-output.bin',r/'tools',r/'docs/acceptance']
rows=[]
for path in queries:
 start=time.perf_counter();expected=any(p==path or path in p.parents for p in index);legacy=time.perf_counter()-start
 start=time.perf_counter()
 for unused in range(1000):actual=index.protects(path)
 indexed=(time.perf_counter()-start)/1000
 assert actual==expected
 rows.append(dict(path=str(path),protected=actual,legacySecondsPerQuery=legacy,indexedSecondsPerQuery=indexed,speedRatio=legacy/indexed))
report=dict(status='tracking-guard-and-owned-fixture-benchmark',trackedPaths=len(index),indexLoadSeconds=loaded,queries=rows,repetitionsPerIndexedQuery=1000,deletedProjectArtifacts=0)
folder=o/'tmp'/'owned-cleanup-benchmark';folder.mkdir(parents=True,exist_ok=True)
assert folder.resolve().is_relative_to(o.resolve())
from artifact_cleanup import remove_artifact
files=[]
for i in range(50):
 path=folder/(str(i)+'.bin');path.write_bytes(b'generated'*16);files.append(path)
start=time.perf_counter()
for path in files:remove_artifact(r/'build',path,index,apply=True)
report['ownedFileDeletion']=dict(files=50,seconds=time.perf_counter()-start,remainingFiles=len(list(folder.iterdir())))
assert not report['ownedFileDeletion']['remainingFiles'];folder.rmdir()
(o/'benchmark.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
