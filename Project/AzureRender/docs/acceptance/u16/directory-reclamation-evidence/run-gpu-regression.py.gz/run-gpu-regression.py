import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path.cwd()
WORK=ROOT/'build/p5-directory-reclamation-2026-10-11'
sys.path.insert(0,str(ROOT/'tools'))
from build_provenance import verify

jobs=[]
for config in ('debug','release'):
    proof=json.loads((WORK/(config+'-provenance.json')).read_text(encoding='utf-8'))
    verify(ROOT,proof)
    for row in json.loads((WORK/(config+'-gpu-inventory.json')).read_text(encoding='utf-8'))['tests']:
        jobs.append((config,row['name']))
native=[row for row in jobs if row[1]=='AzureEditor.NativeInputGpu']
ordinary=[row for row in jobs if row not in native]
gate=WORK/'native-input-window.json'
results=[]
def run(config,name):
    logfile=WORK/(config+'-'+name+'.log')
    started=time.monotonic()
    with logfile.open('w',encoding='utf-8') as log:
        code=subprocess.run(['ctest','--test-dir','build/ninja-msvc-'+config,'-C',config.title(),
            '-R','^'+re.escape(name)+'$','--output-on-failure','-V','-j','1'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT).returncode
    result=dict(configuration=config,test=name,exitCode=code,seconds=time.monotonic()-started,log=str(logfile))
    results.append(result)
    (WORK/'gpu-partial.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(result),flush=True)
def run_native_if_ready():
    if native and gate.exists():
        window=json.loads(gate.read_text(encoding='utf-8'))
        assert window['userGrantedWindow'] is True
        for config,name in list(native):
            run(config,name)
        native.clear()
for config,name in ordinary:
    run_native_if_ready()
    run(config,name)
run_native_if_ready()
for config in ('debug','release'):
    verify(ROOT,json.loads((WORK/(config+'-provenance.json')).read_text(encoding='utf-8')))
summary=dict(results=results,expectedTests=len(jobs),executedTests=len(results),
    failedTests=[row for row in results if row['exitCode']],pendingNativeTests=native,
    physicalOperatorVerification=False,passed=not native and all(row['exitCode']==0 for row in results))
(WORK/'gpu-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({key:value for key,value in summary.items() if key!='results'}),flush=True)
sys.exit(0 if summary['passed'] else 1)
