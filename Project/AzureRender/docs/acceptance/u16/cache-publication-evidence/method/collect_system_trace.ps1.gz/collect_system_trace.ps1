param(
    [ValidateSet('standard','stress','exploration','platformer')][string]$Workload='exploration',
    [ValidateRange(1,3)][int]$Round=1
)
$ErrorActionPreference='Stop'
$taskRoot='D:\Assigment\2609\FYP\Project\AzureRender'
$taskPython='C:\Users\23587\AppData\Local\Programs\Python\Python311\python.exe'
$taskWpr=Join-Path $env:SystemRoot 'System32\wpr.exe'
$taskPerformance=Join-Path $PSScriptRoot 'formal-performance'
$taskActions=Join-Path $taskPerformance ($Workload+'-'+$Round+'.input.json')
$taskProject=Join-Path $taskPerformance ($Workload+'\project.azureproject')
$taskPlayer=Join-Path $taskRoot 'build\ninja-msvc-release\AzurePlayer.exe'
$taskSummary=Get-Content -LiteralPath (Join-Path $taskPerformance 'summary.json') -Raw | ConvertFrom-Json
if ($taskSummary.sourceHash -ne 'b2af43f8a206f6edc16e30c259e41f6230fa64adf6b261e8fd7cbf4dec9b64c2') {
    throw 'The selected measurement does not belong to this candidate.'
}
$taskProcesses=Get-Process AzureRender,AzurePlayer,ctest -ErrorAction SilentlyContinue
if ($taskProcesses) {throw 'Wait for the current engine acceptance batch to finish.'}
$taskLongRuns=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'longrun-status.json') -Raw | ConvertFrom-Json
if (@($taskLongRuns).Count -ne 2) {throw 'Both real-time runs must finish before diagnosis.'}
$taskFrozen=Get-Content -LiteralPath (Join-Path $taskPerformance 'frozen-inputs.json') -Raw | ConvertFrom-Json
foreach ($taskProperty in $taskFrozen.source.PSObject.Properties) {
    $taskPath=Join-Path $taskRoot $taskProperty.Name
    if ((Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskProperty.Value) {
        throw ('The measured source changed: '+$taskProperty.Name)
    }
}
foreach ($taskProperty in $taskFrozen.products.PSObject.Properties) {
    if ((Get-FileHash -LiteralPath $taskProperty.Name -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskProperty.Value) {
        throw ('The measured product changed: '+$taskProperty.Name)
    }
}
foreach ($taskProperty in $taskSummary.sceneHashes.$Workload.PSObject.Properties) {
    $taskPath=Join-Path (Split-Path $taskProject -Parent) $taskProperty.Name
    if ((Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskProperty.Value) {
        throw ('The measured project changed: '+$taskProperty.Name)
    }
}
$taskStamp=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
$taskSession='AzureP5CacheMemory_'+$taskStamp
$taskOutput=Join-Path $PSScriptRoot ('system-trace-'+$taskStamp)
$taskStarted=$false
$taskChild=$null
$taskClock=[Diagnostics.Stopwatch]::new()
$taskSamples=[Collections.Generic.List[object]]::new()
Push-Location $taskRoot
try {
    & $taskPython tools/build_provenance.py verify --source . --build-dir build/ninja-msvc-release --config Release
    if ($LASTEXITCODE -ne 0) {throw 'Release build provenance verification failed.'}
    New-Item -ItemType Directory -Path $taskOutput -ErrorAction Stop | Out-Null
    Copy-Item -LiteralPath $taskActions -Destination (Join-Path $taskOutput 'input.json')
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'release-provenance.json') -Destination (Join-Path $taskOutput 'build-provenance.json')
    $taskIdentity=[Security.Principal.WindowsIdentity]::GetCurrent()
    $taskPrincipal=[Security.Principal.WindowsPrincipal]::new($taskIdentity)
    @{sourceHash=$taskSummary.sourceHash; workload=$Workload; round=$Round; diagnosticOnly=$true;
      administrator=$taskPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator);
      inputSha256=(Get-FileHash -LiteralPath $taskActions -Algorithm SHA256).Hash.ToLowerInvariant();
      measuredSummarySha256=(Get-FileHash -LiteralPath (Join-Path $taskPerformance 'summary.json') -Algorithm SHA256).Hash.ToLowerInvariant()} |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskOutput 'association.json') -Encoding utf8
    $taskWprStart=Start-Process -FilePath $taskWpr -ArgumentList @('-start','VirtualAllocation','-start','ResidentSet','-filemode','-instancename',$taskSession) -WindowStyle Hidden -Wait -PassThru `
        -RedirectStandardOutput (Join-Path $taskOutput 'wpr-start.log') -RedirectStandardError (Join-Path $taskOutput 'wpr-start-error.log')
    $taskStartCode=$taskWprStart.ExitCode
    if ($taskStartCode -ne 0) {throw ('WPR start failed: '+$taskStartCode)}
    $taskStarted=$true
    $taskTiming=Join-Path $taskOutput 'timing.json'
    $taskArguments=@('--project',('"'+$taskProject+'"'),'--game-actions',('"'+$taskActions+'"'),
        '--fixed-frame-step','--width','1920','--height','1080','--smoke-frames','2100',
        '--gpu-timing','--gpu-timing-output',('"'+$taskTiming+'"'))
    $taskChild=Start-Process -FilePath $taskPlayer -ArgumentList $taskArguments -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput (Join-Path $taskOutput 'stdout.log') -RedirectStandardError (Join-Path $taskOutput 'stderr.log')
    $taskClock.Start()
    while (-not $taskChild.HasExited) {
        if ($taskClock.Elapsed.TotalSeconds -gt 600) {throw 'The owned diagnostic process timed out.'}
        $taskChild.Refresh()
        if (-not $taskChild.HasExited) {
            $taskSamples.Add(@{seconds=$taskClock.Elapsed.TotalSeconds; working=$taskChild.WorkingSet64;
                privateBytes=$taskChild.PrivateMemorySize64})
        }
        Start-Sleep -Milliseconds 30
    }
    $taskChild.WaitForExit()
    @{diagnosticOnly=$true; formalAcceptance=$false; processId=$taskChild.Id; exitCode=$taskChild.ExitCode;
      session=$taskSession; seconds=$taskClock.Elapsed.TotalSeconds; runtimeReportEnabled=$false} |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskOutput 'process.json') -Encoding utf8
    if ($taskChild.ExitCode -ne 0) {throw ('Player failed: '+$taskChild.ExitCode)}
} catch {
    if (Test-Path -LiteralPath $taskOutput) {
        @{status='failed'; diagnosticOnly=$true; message=$_.Exception.Message; session=$taskSession;
          errorType=$_.Exception.GetType().FullName; traceStarted=$taskStarted} |
            ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskOutput 'failure.json') -Encoding utf8
    }
    throw
} finally {
    try {
        if ($taskChild -and -not $taskChild.HasExited) {$taskChild.Kill();$taskChild.WaitForExit()}
        if (Test-Path -LiteralPath $taskOutput) {
            ConvertTo-Json -InputObject @($taskSamples.ToArray()) -Depth 4 |
                Set-Content -LiteralPath (Join-Path $taskOutput 'observations.json') -Encoding utf8
        }
    } finally {
        try {
            if ($taskStarted) {
                $taskWprStop=Start-Process -FilePath $taskWpr -ArgumentList @('-stop',('"'+(Join-Path $taskOutput 'memory.etl')+'"'),'-instancename',$taskSession) -WindowStyle Hidden -Wait -PassThru `
                    -RedirectStandardOutput (Join-Path $taskOutput 'wpr-stop.log') -RedirectStandardError (Join-Path $taskOutput 'wpr-stop-error.log')
                $taskStopCode=$taskWprStop.ExitCode
                if ($taskStopCode -ne 0) {Write-Error ('WPR stop failed: '+$taskStopCode)}
            }
        } finally {
            if (Test-Path -LiteralPath $taskOutput) {
                Get-ChildItem -LiteralPath $taskOutput -File | ForEach-Object {
                    @{file=$_.Name; bytes=$_.Length; sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
                } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $taskOutput 'files.json') -Encoding utf8
            }
            Pop-Location
        }
    }
}
Write-Output $taskOutput
