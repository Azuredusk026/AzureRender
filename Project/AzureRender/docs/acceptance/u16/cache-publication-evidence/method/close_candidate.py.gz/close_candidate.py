"""Finish evidence and document checks after all measured GPU work exits."""
import json
import subprocess
import sys
import time
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-cache-publication-2026-10-11'
deadline=time.monotonic()+14400
while True:
    path=work/'longrun-status.json'
    records=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
    if len(records)==2:break
    assert time.monotonic()<deadline,'Measured workloads did not finish'
    time.sleep(10)
status=[]
def run(name,command,required=True):
    print('Starting',name,flush=True)
    with (work/(name+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run(list(map(str,command)),cwd=root,stdout=log,stderr=subprocess.STDOUT)
    status.append(dict(name=name,exitCode=result.returncode,required=required))
    (work/'closure-status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
    print(name,'exit',result.returncode,flush=True)
    if required:assert result.returncode==0,(name,result.returncode)
    return result.returncode
run('regression-inventory',[sys.executable,work/'inventory_regression.py'])
formal=json.loads((work/'formal-performance/summary.json').read_text(encoding='utf-8'))
failed=[(name,i) for name,rows in formal['rounds'].items() for i,row in enumerate(rows,1)
        if not row['passed'] and name!='editor']
workload,number=failed[0] if failed else ('exploration',1)
run('system-trace-attempt',['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass',
    '-File',work/'collect_system_trace.ps1','-Workload',workload,'-Round',number],required=False)
run('sync-documents',[sys.executable,work/'sync_cache_documents.py'])
documents=['README.md','CHANGELOG.md','docs/runtime/assets-levels.md',
    'docs/plans/2026-10-11-cache-publication.md','docs/acceptance/u16/cache-publication.md',
    'docs/plans/2026-10-10-p5-closure-and-user-experience.md','docs/plans/azure-engine-plan.md',
    'docs/acceptance/p5/2026-10-10.md','docs/acceptance/p6/2026-10-10.md',
    'docs/acceptance/p5/closure/ui-residency.md']
run('doc-style',[sys.executable,root/'tools/check_doc_style.py',*documents])
run('archive-evidence',[sys.executable,work/'archive_cache_candidate.py'])
run('doc-links',[sys.executable,'C:/Users/23587/.codex/skills/developer-documentation/scripts/validate_docs.py',*documents])
run('user-baseline',[sys.executable,root/'build/p5-p6-closure-2026-10-10/audit_user_files.py'])
run('repository-audit',[sys.executable,root/'tools/audit_repository.py','--source',root.parent.parent,
    '--output',work/'repository-audit.json'])
run('docs-strict',[sys.executable,'-m','mkdocs','build','--strict','--site-dir',work/'verified-site'])
run('verify-evidence',[sys.executable,work/'verify_cache_candidate.py'])
print('Evidence is ready for selective index review; no commit was created by this runner.',flush=True)
