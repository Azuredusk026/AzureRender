"""Repeat the exact failed planner schedule with both rebuilt configurations."""
import hashlib
import json
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

root=Path.cwd().resolve()
out=root/'build/p5-cache-publication-2026-10-11/concurrency-refined'
out.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify
frozen=inputs(root)
source_hash=hashlib.sha256(json.dumps(frozen,sort_keys=True).encode()).hexdigest()
records=[]
for configuration in ('release','debug'):
    executable=root/('build/ninja-msvc-'+configuration)/'AzurePlatformerFlowTests.exe'
    proof=json.loads((executable.parent/'build-provenance.json').read_text(encoding='utf-8'))
    verify(root,proof)
    def run(base,phase):
        command=[str(executable),str(base/'project.azureproject'),str(base.parent/('phase-'+str(phase))),str(phase)]
        result=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
        log=base.parent/('phase-'+str(phase)+'.log')
        log.write_text(result.stdout+result.stderr,encoding='utf-8')
        return dict(phase=phase,exitCode=result.returncode,log=log.relative_to(out).as_posix(),
                    sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    for attempt in range(1,4):
        base=out/configuration/('concurrent-'+str(attempt))/'project'
        shutil.copytree(root/'assets_public/platformer',base,ignore=shutil.ignore_patterns('.azure'))
        with ThreadPoolExecutor(max_workers=3) as executor:
            results=list(executor.map(lambda phase:run(base,phase),(0,60,135)))
        records.append(dict(configuration=configuration,schedule='concurrent',attempt=attempt,results=results))
        print(configuration,'concurrent',attempt,[row['exitCode'] for row in results],flush=True)
    base=out/configuration/'serialized'/'project'
    shutil.copytree(root/'assets_public/platformer',base,ignore=shutil.ignore_patterns('.azure'))
    results=[run(base,phase) for phase in (0,60,135)]
    records.append(dict(configuration=configuration,schedule='serialized',results=results))
    assert inputs(root)==frozen
failures=[row for batch in records for row in batch['results'] if row['exitCode']]
result=dict(schemaVersion=1,sourceHash=source_hash,records=records,
    concurrentRuns=18,serializedRuns=6,failures=failures,passed=not failures,
    configurations=['release','debug'],existingMetadataOnly=True)
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:result[key] for key in ('sourceHash','concurrentRuns','serializedRuns','failures','passed')}))
raise SystemExit(int(bool(failures)))
