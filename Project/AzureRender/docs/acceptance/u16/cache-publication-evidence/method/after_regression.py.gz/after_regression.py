"""Publish and measure only after all frozen cache candidate tests finish."""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-cache-publication-2026-10-11'
os.environ['PATH']='D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin'+os.pathsep+os.environ['PATH']
deadline=time.monotonic()+10800
while True:
    path=work/'regression-status.json'
    records=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
    if len(records)==4:break
    assert time.monotonic()<deadline,'Regression did not finish'
    time.sleep(10)
assert not any(row['exitCode'] for row in records),records
status=[]
def run(name,args):
    print('Starting',name,flush=True)
    with (work/(name+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run(list(map(str,args)),cwd=root,stdout=log,stderr=subprocess.STDOUT)
    status.append(dict(name=name,exitCode=result.returncode))
    (work/'continuation-status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
    print(name,'exit',result.returncode,flush=True)
    return result.returncode
assert run('delivery',[sys.executable,work/'verified_delivery.py'])==0
run('formal-performance',[sys.executable,root/'tools/run_playable_performance.py',
    '--player',root/'build/ninja-msvc-release/AzurePlayer.exe',
    '--editor',root/'build/ninja-msvc-release/AzureRender.exe',
    '--exploration',root/'assets_public/exploration/project.azureproject',
    '--platformer',root/'assets_public/platformer/project.azureproject',
    '--output',work/'formal-performance'])
assert run('operator-packet',[sys.executable,work/'create_operator_packet.py'])==0
raise SystemExit(int(any(row['exitCode'] for row in status)))
