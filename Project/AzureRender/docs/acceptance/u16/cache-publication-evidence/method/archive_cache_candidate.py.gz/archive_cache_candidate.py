"""Preserve failures and successes as deterministic original-byte evidence."""
import gzip
import hashlib
import json
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-cache-publication-2026-10-11'
target=root/'docs/acceptance/u16/cache-publication-evidence'
assert not target.exists(),target
inventory=json.loads((work/'regression-inventory.json').read_text(encoding='utf-8'))
assert inventory['complete'] and inventory['total']==454
delivery=json.loads((work/'arena-delivery/summary.json').read_text(encoding='utf-8'))
assert delivery['passed'] and len(delivery['checks'])==10 and len(delivery['packages'])==6
formal=json.loads((work/'formal-performance/summary.json').read_text(encoding='utf-8'))
rounds=[row for group in formal['rounds'].values() for row in group]
assert len(rounds)==15
schedule=json.loads((work/'concurrency-shared-read/summary.json').read_text(encoding='utf-8'))
assert schedule['passed'] and schedule['concurrentRuns']==18 and schedule['serializedRuns']==6
assert schedule['sourceHash']==formal['sourceHash']
selected={}
def add(path,label):
    assert path.is_file() and label not in selected,(path,label)
    selected[label]=path
for path in sorted(work.iterdir()):
    if (path.is_file() and path.name not in ('closure.log','closure-status.json',
            'archive-evidence.log','verify-evidence.log')
            and path.suffix in ('.json','.log','.py','.ps1','.cmd','.cpp','.txt')):
        add(path,'method/'+path.name)
for base in sorted(work.glob('concurrency*')):
    if not base.is_dir():continue
    for path in sorted(base.rglob('*')):
        relative=path.relative_to(base)
        if path.is_file() and 'project' not in relative.parts and (path.name=='summary.json' or path.suffix=='.log'):
            add(path,base.name+'/'+relative.as_posix())
for base in sorted(work.glob('system-trace-*')):
    if not base.is_dir():continue
    for path in sorted(base.iterdir()):
        if path.is_file() and path.suffix in ('.json','.log','.csv'):
            add(path,base.name+'/'+path.name)
for name in ('formal-performance','operator-review','platformer-interrupted-1','platformer-longrun','standard-longrun'):
    base=work/name
    if not base.exists():continue
    for path in sorted(base.iterdir()):
        if path.is_file() and path.suffix in ('.json','.jsonl','.log','.csv','.md','.png'):
            add(path,name+'/'+path.name)
    for path in sorted((base/'captures').glob('*')):
        if path.is_file() and (path.name.startswith('hud-') or path.name=='gpu_capabilities.json'):
            add(path,name+'/captures/'+path.name)
base=work/'arena-delivery'
for path in sorted(base.iterdir()):
    if path.is_file() and path.suffix in ('.json','.log'):
        add(path,'delivery/'+path.name)
for path in sorted(base.glob('nvidia-*/*'))+sorted(base.glob('intel-*/*')):
    if path.is_file() and path.suffix in ('.json','.log'):
        add(path,'delivery/'+path.relative_to(base).as_posix())
add(base/'packages/provenance.json','delivery/provenance.json')
for row in delivery['packages']:
    folder=base/('Moved Engine' if row['kind']=='engine' else 'Moved '+row['kind'])
    add(folder/('install_manifest.json' if row['kind']=='engine' else 'game_manifest.json'),
        'package-manifests/'+row['kind']+'.json')
for name in ('src/runtime/AssetDatabase.cpp','tests/AssetLevelTests.cpp'):
    add(root/name,'source/'+name)
files={}
for label,path in selected.items():
    raw=path.read_bytes()
    stored=gzip.compress(raw,mtime=0)
    name=label+'.gz'
    output=target/name
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_bytes(stored)
    assert gzip.decompress(output.read_bytes())==raw
    files[name]=dict(source=path.relative_to(root).as_posix(),originalBytes=len(raw),storedBytes=len(stored),
        originalSha256=hashlib.sha256(raw).hexdigest(),sha256=hashlib.sha256(stored).hexdigest(),compressed=True)
records=json.loads((work/'longrun-status.json').read_text(encoding='utf-8'))
runs={row['name']:dict(status=row['status'],actualSeconds=None,frames=None,workingSetGrowth=None) for row in records}
for name in ('platformer','standard'):
    path=work/(name+'-longrun')/'summary.json'
    if path.exists():runs[name]=json.loads(path.read_text(encoding='utf-8'))
manifest=dict(schemaVersion=1,sourceHash=formal['sourceHash'],regressionTotal=454,
    concurrentRuns=18,serializedRuns=6,deliveryChecks=10,formalRounds=15,
    formalPerformancePassed=formal['passed'],formalPassedRounds=sum(row['passed'] for row in rounds),
    longRuns={name:{key:row[key] for key in ('status','actualSeconds','frames','workingSetGrowth')} for name,row in runs.items()},
    physicalInputVerified=False,subjectiveAudioVerified=False,authoringEfficiencyVerified=False,
    priorWorkingSetCauseResolved=False,files=files)
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:manifest[key] for key in ('sourceHash','regressionTotal','formalPassedRounds','longRuns')}))
print(json.dumps(dict(files=len(files),storedBytes=sum(row['storedBytes'] for row in files.values()))))
