"""Run both full-duration workloads after the frozen delivery batch finishes."""
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-cache-publication-2026-10-11'
os.environ['PATH']='D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin'+os.pathsep+os.environ['PATH']
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify
from build_game import build_game,verify_package
from test_level_cycles import prepare
frozen=inputs(root)
source_hash=hashlib.sha256(json.dumps(frozen,sort_keys=True).encode()).hexdigest()
assert source_hash=='b2af43f8a206f6edc16e30c259e41f6230fa64adf6b261e8fd7cbf4dec9b64c2'
deadline=time.monotonic()+10800
while True:
    path=work/'continuation-status.json'
    records=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
    if any(row['name']=='operator-packet' and row['exitCode']==0 for row in records):break
    assert time.monotonic()<deadline,'The frozen delivery batch has not completed'
    time.sleep(10)
assert inputs(root)==frozen
proof=json.loads((work/'release-provenance.json').read_text(encoding='utf-8'))
verify(root,proof)
delivery=work/'arena-delivery'
assert json.loads((delivery/'summary.json').read_text(encoding='utf-8'))['passed']
source=work/'standard-source'
standard=work/'Moved cache standard'
prepare(source)
build_game(source/'project.azureproject',delivery/'Moved Engine',standard)
source.rename(work/'Unavailable cache standard source')
verify_package(standard)
records=[]
for name,tool,package in [('platformer','run_platformer_long_run.py',delivery/'Moved exploration'),
                           ('standard','run_playable_long_run.py',standard)]:
    print('Starting',name,'1800 seconds',flush=True)
    with (work/(name+'-longrun.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run([sys.executable,str(root/'tools'/tool),'--package',str(package),
            '--output',str(work/(name+'-longrun')),'--seconds','1800'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    assert inputs(root)==frozen
    verify(root,proof)
    records.append(dict(name=name,exitCode=result.returncode,sourceHash=source_hash))
    (work/'longrun-status.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
    print(name,'exit',result.returncode,flush=True)
raise SystemExit(int(any(row['exitCode'] for row in records)))
