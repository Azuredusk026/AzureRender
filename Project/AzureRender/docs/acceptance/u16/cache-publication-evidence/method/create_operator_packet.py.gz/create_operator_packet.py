"""Bind the pending human checks to the verified candidate products."""
import hashlib
import json
from pathlib import Path

root = Path.cwd().resolve()
work = root/'build/p5-cache-publication-2026-10-11'
delivery = work/'arena-delivery'
summary = json.loads((delivery/'summary.json').read_text(encoding='utf-8'))
assert summary['passed'] and len(summary['checks']) == 10
for package in summary['packages']:
    assert hashlib.sha256(Path(package['path']).read_bytes()).hexdigest() == package['sha256']
proof = json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text(encoding='utf-8'))
out = work/'operator-review'
out.mkdir(exist_ok=True)
feedback = dict(schemaVersion=1, status='NotExecuted', baseCommit=proof['commit'],
                physicalInput=False, subjectiveAudio=False, authoringEfficiency=False,
                operator=None, date=None, devices=None, displayScale=None, audioOutput=None,
                packageHashes={row['kind']: row['sha256'] for row in summary['packages']},
                workflows={name: dict(baselineSeconds=None, baselineSteps=None, efficiencyTarget=None,
                                      verificationSeconds=None, verificationSteps=None, recoveryResult=None,
                                      tasks=[], issues=[])
                           for name in ('exploration', 'inspection')},
                gameplay=dict(exploration=None, sequence=None, mandatoryJumps=None, movingPlatforms=None,
                              coins=None, fallRecovery=None, restart=None, completion=None),
                audio={name: dict(audible=None, recognizable=None, acceptableVolume=None, repeatedTriggers=None)
                       for name in ('jump', 'land', 'coin', 'respawn', 'complete')},
                issues=[])
template = out/'feedback-template.json'
if not template.exists():
    template.write_text(json.dumps(feedback, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
rows = '\n'.join('| '+row['kind']+' | `'+row['sha256']+'` |' for row in summary['packages'])
engine = delivery/'Moved Engine/bin/AzureRender.exe'
seed = delivery/'Moved scene_inspector/game/project.azureproject'
game = delivery/'Moved exploration/start-game.cmd'
text = f'''# 候选包人工复核操作单

> 文档类型：本机验收操作单
> 状态：发布链机器检查通过，人工结果待填写
> 源码基点：`{proof['commit']}`

## 使用条件

正式性能、根因归因和长跑分别维护状态。
操作前核对本轮测量汇总与候选来源。
实体操作、制作效率和听感由操作者记录。
自动输入结果按其实际覆盖范围使用。

## 进入编辑器

使用 PowerShell 启动候选编辑器。
通过项目入口创建两个新的制作项目。
验收项目放入独立目录，保留候选包原件。

```powershell
& "{engine.as_posix()}" --editor-project "{seed.as_posix()}"
```

制作步骤见[从空关卡制作并发布游戏]({(root/'docs/tutorials/editor-first-game.md').as_posix()})。
实体检查见[键鼠与音效复核表]({(root/'docs/acceptance/p5/physical-input.md').as_posix()})。
制作任务见[P6 制作验收表]({(root/'docs/acceptance/p6/2026-10-10.md').as_posix()})。
两份表中的未执行项由实际结果填写。

## 完整游戏与听感

启动探索包，实际通关并进入平台关卡。
使用 WASD、Shift、Space、E 和 R 操作。
检查必经跳跃、金币、承载、掉落及终点。
五类音效分别记录辨识度、音量和重复触发。

```powershell
& "{game.as_posix()}"
```

## 制作效率与反馈

两工作流分别记录步骤、耗时与误操作恢复。
依据首轮实际数据填写效率目标。
目标登记后执行复核并记录结果。
发现问题时记录触发步骤与可观察结果。

结果模板为[feedback-template.json]({template.as_posix()})。
另存填写结果，保留原模板中的待验状态。
记录操作者、设备、显示缩放和声音输出。
每项填写通过、失败或未执行。

## 候选包来源

| 产物 | SHA-256 |
| --- | --- |
{rows}

包清单见[发布来源]({(delivery/'packages/provenance.json').as_posix()})。
源码原字节归档见[构建输入]({(root/'build/p5-cache-publication-2026-10-11/release-provenance.json').as_posix()})。
人工结果只适用于表中记录的具体候选包。
'''
(out/'operator-checklist.md').write_text(text, encoding='utf-8')
print(json.dumps(dict(packages=len(summary['packages']), path=str(out/'operator-checklist.md'),
                      physicalInput='pending', subjectiveAudio='pending', efficiency='pending')))
