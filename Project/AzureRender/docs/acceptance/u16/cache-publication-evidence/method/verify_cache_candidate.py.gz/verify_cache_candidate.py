"""Check evidence bytes, source provenance and explicitly unfinished gates."""
import gzip
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-cache-publication-2026-10-11'
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify
target=root/'docs/acceptance/u16/cache-publication-evidence'
manifest=json.loads((target/'manifest.json').read_text(encoding='utf-8'))
source=hashlib.sha256(json.dumps(inputs(root),sort_keys=True).encode()).hexdigest()
assert source==manifest['sourceHash']=='b2af43f8a206f6edc16e30c259e41f6230fa64adf6b261e8fd7cbf4dec9b64c2'
for name,item in manifest['files'].items():
    stored=(target/name).read_bytes()
    raw=gzip.decompress(stored)
    assert hashlib.sha256(stored).hexdigest()==item['sha256'],name
    assert hashlib.sha256(raw).hexdigest()==item['originalSha256'],name
    assert raw==(root/item['source']).read_bytes(),item['source']
for config in ('release','debug'):
    proof=json.loads((work/(config+'-provenance.json')).read_text(encoding='utf-8'))
    verify(root,proof)
    assert proof['source']==inputs(root)
inventory=json.loads((work/'regression-inventory.json').read_text(encoding='utf-8'))
assert inventory['complete'] and inventory['total']==manifest['regressionTotal']==454
schedule=json.loads((work/'concurrency-shared-read/summary.json').read_text(encoding='utf-8'))
assert schedule['passed'] and schedule['concurrentRuns']==manifest['concurrentRuns']==18
assert schedule['serializedRuns']==manifest['serializedRuns']==6
for batch in schedule['records']:
    for row in batch['results']:
        assert row['exitCode']==0
        log=work/'concurrency-shared-read'/row['log']
        assert hashlib.sha256(log.read_bytes()).hexdigest()==row['sha256']
delivery=json.loads((work/'arena-delivery/summary.json').read_text(encoding='utf-8'))
assert delivery['passed'] and len(delivery['checks'])==manifest['deliveryChecks']==10
assert len(delivery['packages'])==6
for row in delivery['packages']:
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['kind']
formal=json.loads((work/'formal-performance/summary.json').read_text(encoding='utf-8'))
rounds=[row for group in formal['rounds'].values() for row in group]
assert len(rounds)==manifest['formalRounds']==15
assert sum(row['passed'] for row in rounds)==manifest['formalPassedRounds']
assert formal['passed']==manifest['formalPerformancePassed']
for name,record in manifest['longRuns'].items():
    path=work/(name+'-longrun')/'summary.json'
    if path.exists():
        measured=json.loads(path.read_text(encoding='utf-8'))
        assert measured['sourceHash']==source
        if measured['status']=='passed':assert measured['actualSeconds']>=1800
        assert record=={key:measured[key] for key in record}
    else:
        assert record['status'] in ('InterruptedWithoutFinalResult','NotExecuted')
        assert record['actualSeconds'] is None and record['workingSetGrowth'] is None
operator=json.loads((work/'operator-review/feedback-template.json').read_text(encoding='utf-8'))
assert operator['status']=='NotExecuted'
assert not operator['physicalInput'] and not operator['subjectiveAudio'] and not operator['authoringEfficiency']
assert operator['packageHashes']=={row['kind']:row['sha256'] for row in delivery['packages']}
assert not manifest['physicalInputVerified'] and not manifest['subjectiveAudioVerified']
assert not manifest['authoringEfficiencyVerified'] and not manifest['priorWorkingSetCauseResolved']
pending=json.loads((root/'docs/plans/authoring-usability-manifest.json').read_text(encoding='utf-8'))
assert not pending['u15Complete'] and not pending['u16Complete'] and not pending['p6Complete']
assert pending['cachePublicationCandidate']['sourceHash']==source
assert not pending['cachePublicationCandidate']['priorWorkingSetCauseResolved']
issue=next(row for row in pending['issues'] if row['id']=='UX-009')
assert issue['status']=='MechanismConcurrencyAndFullRegressionVerified'
plan=json.loads((root/'docs/plans/asset-format-manifest.json').read_text(encoding='utf-8'))
assert not plan['prerequisitesComplete'] and all(row['status']=='Planned' for row in plan['phases'])
mode=sys.argv[1] if len(sys.argv)>1 else None
if mode:
    assert mode in ('HEAD','index')
    for name,item in manifest['files'].items():
        path='Project/AzureRender/docs/acceptance/u16/cache-publication-evidence/'+name
        reference='HEAD:'+path if mode=='HEAD' else ':'+path
        stored=subprocess.run(['git','show',reference],capture_output=True,check=True).stdout
        assert hashlib.sha256(stored).hexdigest()==item['sha256'],name
result=dict(passed=True,sourceHash=source,files=len(manifest['files']),gitMode=mode,
    regressionTotal=manifest['regressionTotal'],formalPassedRounds=manifest['formalPassedRounds'],
    longRuns=manifest['longRuns'],currentStagesComplete=False,assetStagesStarted=False)
(work/('verification-'+(mode or 'working')+'.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
