"""Install cache publication regressions only after the frozen UI batch closes."""
from pathlib import Path
import subprocess

root = Path.cwd().resolve()
work = root/'build/p5-cache-publication-2026-10-11'
path = root/'tests/AssetLevelTests.cpp'
assert not subprocess.run(['git','diff','--',str(path)],capture_output=True,check=True).stdout
assert not (work/'AssetLevelTests.original.cpp').exists()
before = path.read_bytes()
(work/'AssetLevelTests.original.cpp').write_bytes(before)
text = before.decode('utf-8').replace('\r\n','\n')
anchor = '  write(db.cacheFile(id),"corrupt");check(db.readSource(id)=="first");'
assert text.count(anchor) == 1
test = r'''  // A cache publisher owns only its unique staging file. Another
  // operation's staging path must survive both publication and failure.
  const auto cachePath=db.cacheFile(id);
  const auto foreignTemporary=std::filesystem::path(cachePath.string()+".tmp");
  std::filesystem::remove(cachePath);
  std::filesystem::create_directory(foreignTemporary);
  write(foreignTemporary/"owner.txt","other operation");
  check(db.readSource(id)=="first");
  std::string owner;std::getline(std::ifstream(foreignTemporary/"owner.txt"),owner);
  check(owner=="other operation" && std::filesystem::is_directory(foreignTemporary));
  std::filesystem::remove(cachePath);std::filesystem::create_directory(cachePath);
  bool publicationRejected=false;
  try{db.readSource(id);}catch(const std::exception&){publicationRejected=true;}
  check(publicationRejected && std::filesystem::is_directory(cachePath));
  for(const auto& entry:std::filesystem::directory_iterator(cachePath.parent_path().parent_path()))
    if(entry.path().extension()==".tmp")
      throw std::runtime_error("Failed cache publication must clean owned staging files");
  std::filesystem::remove(cachePath);check(db.readSource(id)=="first");
  std::filesystem::remove_all(foreignTemporary);
  write(cachePath,"existing incomplete cache");
  write(root/"assets/moved.txt","changed after snapshot");
  bool stalePublicationRejected=false;
  try{db.readSource(id);}catch(const std::exception&){stalePublicationRejected=true;}
  std::string preserved;std::ifstream priorCache(cachePath);std::getline(priorCache,preserved);priorCache.close();
  check(stalePublicationRejected && preserved=="existing incomplete cache");
  write(root/"assets/moved.txt","first");check(db.readSource(id)=="first");
'''
# getline requires an lvalue stream on every supported standard library.
test = test.replace('std::string owner;std::getline(std::ifstream(foreignTemporary/"owner.txt"),owner);',
                    'std::string owner;std::ifstream ownerFile(foreignTemporary/"owner.txt");std::getline(ownerFile,owner);ownerFile.close();')
path.write_bytes(text.replace(anchor,test+anchor).encode('utf-8'))
print('Cache publication behavior tests installed; production code unchanged.')
