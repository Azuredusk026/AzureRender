"""Stage only the cache fix and its verified documentation increments."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

root=Path.cwd().resolve()
prefix='Project/AzureRender/'
work=root/'build/p5-cache-publication-2026-10-11'
def git(*args,data=None):
    return subprocess.run(['git',*args],input=data,capture_output=True,check=True).stdout
assert not git('diff','--cached','--name-only').strip()
def stage(name,replacements):
    original=git('show','HEAD:'+prefix+name).decode('utf-8')
    newline='\r\n' if '\r\n' in original else '\n'
    text=original.replace('\r\n','\n')
    for old,new in replacements:
        assert text.count(old)==1,(name,old)
        text=text.replace(old,new,1)
    blob=git('hash-object','-w','--stdin',data=text.replace('\n',newline).encode()).decode().strip()
    git('update-index','--cacheinfo','100644,'+blob+','+prefix+name)
readme=(root/'README.md').read_text(encoding='utf-8')
start=readme.index('资产缓存使用独立暂存目录与完整文件发布。')
end=readme.index('资产格式后续阶段见',start)
stage('README.md',[
    ('当前来源回归与实测见[界面驻留验收]','界面共享页候选的回归与实测见[界面驻留验收]'),
    ('\n资产格式后续阶段见','\n'+readme[start:end]+'资产格式后续阶段见')])
changelog=(root/'CHANGELOG.md').read_text(encoding='utf-8')
start=changelog.index('## U16 缓存并发发布修复 2026-10-11')
end=changelog.index('## P5-E 界面几何驻留修复 2026-10-11',start)
stage('CHANGELOG.md',[('# Changelog\n\n','# Changelog\n\n'+changelog[start:end])])
stage('mkdocs.yml',[('nav:\n','nav:\n  - 资产缓存并发验收: acceptance/u16/cache-publication.md\n  - 资产缓存发布计划: plans/2026-10-11-cache-publication.md\n')])
plan=(root/'docs/plans/azure-engine-plan.md').read_text(encoding='utf-8')
start=plan.index('\n## 缓存并发候选验收\n')
original=git('show','HEAD:'+prefix+'docs/plans/azure-engine-plan.md').decode('utf-8')
stage('docs/plans/azure-engine-plan.md',[(original.replace('\r\n','\n'),original.replace('\r\n','\n')+plan[start:])])
paths=['src/runtime/AssetDatabase.cpp','tests/AssetLevelTests.cpp',
    'docs/runtime/assets-levels.md','docs/acceptance/u16/cache-publication.md',
    'docs/plans/2026-10-11-cache-publication.md','docs/plans/authoring-usability-manifest.json',
    'docs/plans/2026-10-10-p5-closure-and-user-experience.md',
    'docs/acceptance/p5/2026-10-10.md','docs/acceptance/p6/2026-10-10.md',
    'docs/acceptance/p5/closure/ui-residency.md']
git('add','--',*paths)
evidence='docs/acceptance/u16/cache-publication-evidence'
git('add','--force','--',evidence)
manifest=json.loads((root/evidence/'manifest.json').read_text(encoding='utf-8'))
for name,item in manifest['files'].items():
    stored=git('show',':'+prefix+evidence+'/'+name)
    assert hashlib.sha256(stored).hexdigest()==item['sha256'],name
    assert hashlib.sha256(gzip.decompress(stored)).hexdigest()==item['originalSha256'],name
git('diff','--cached','--check')
print('Selective staging and',len(manifest['files']),'original-byte Git blobs verified.')
