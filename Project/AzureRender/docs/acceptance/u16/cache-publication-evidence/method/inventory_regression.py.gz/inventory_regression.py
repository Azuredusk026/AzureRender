"""Check the complete test-name inventory, not only the runner exit status."""
import json
import re
import subprocess
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-cache-publication-2026-10-11'
ctest='D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
records=json.loads((work/'regression-status.json').read_text(encoding='utf-8'))
assert len(records)==4 and all(row['exitCode']==0 for row in records)
rows=[]
for config,count in [('release',228),('debug',226)]:
    listing=subprocess.run([ctest,'--test-dir',str(root/('build/ninja-msvc-'+config)),
        '-C',config.capitalize(),'--show-only=json-v1'],capture_output=True,text=True,check=True)
    expected={row['name'] for row in json.loads(listing.stdout)['tests']}
    observed=[]
    for group in ('cpu','gpu'):
        text=(work/(config+'-'+group+'.log')).read_text(encoding='utf-8')
        assert '100% tests passed, 0 tests failed out of ' in text
        observed.extend(re.findall(r'Test\s+#\d+:\s+(\S+)\s+\.+\s+Passed\s+',text))
    assert len(observed)==len(set(observed))==len(expected)==count,(config,len(observed),len(expected))
    assert set(observed)==expected,(config,sorted(expected-set(observed)))
    rows.append(dict(configuration=config,count=count,tests=sorted(observed)))
result=dict(complete=True,total=sum(row['count'] for row in rows),configurations=rows)
(work/'regression-inventory.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(complete=result['complete'],total=result['total'])))
