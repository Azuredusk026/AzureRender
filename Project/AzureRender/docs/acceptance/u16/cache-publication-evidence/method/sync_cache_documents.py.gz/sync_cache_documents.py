"""Publish the actual result of this candidate without closing human gates."""
import json
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-cache-publication-2026-10-11'
inventory=json.loads((work/'regression-inventory.json').read_text(encoding='utf-8'))
assert inventory['complete'] and inventory['total']==454
delivery=json.loads((work/'arena-delivery/summary.json').read_text(encoding='utf-8'))
assert delivery['passed'] and len(delivery['checks'])==10
formal=json.loads((work/'formal-performance/summary.json').read_text(encoding='utf-8'))
rounds=[row for group in formal['rounds'].values() for row in group]
assert len(rounds)==15
passed=sum(row['passed'] for row in rounds)
records=json.loads((work/'longrun-status.json').read_text(encoding='utf-8'))
runs={row['name']:dict(status=row['status'],actualSeconds=None,frames=None,workingSetGrowth=None) for row in records}
for name in ('platformer','standard'):
    path=work/(name+'-longrun')/'summary.json'
    if path.exists():runs[name]=json.loads(path.read_text(encoding='utf-8'))
def replace(name,old,new):
    path=root/name
    text=path.read_text(encoding='utf-8')
    assert text.count(old)==1,(name,old)
    path.write_text(text.replace(old,new,1),encoding='utf-8')
def append(name,text):
    path=root/name
    assert text.strip() not in path.read_text(encoding='utf-8')
    path.write_text(path.read_text(encoding='utf-8')+text,encoding='utf-8')
status='机制、并发规划与完整回归通过。'
page='docs/acceptance/u16/cache-publication.md'
replace(page,'> 状态：机制与并发规划通过，完整回归进行中。','> 状态：'+status)
replace(page,'| 两配置完整 GPU 回归 | 串行执行中 |','| 两配置完整 GPU 回归 | Release 六十六项与 Debug 六十四项通过 |')
replace(page,'| 当前候选移动发布与设备复核 | 待执行 |','| 当前候选移动发布与设备复核 | 五项目双设备共十组通过 |')
replace(page,'| 当前候选正式性能测量 | 待执行 |',f'| 当前候选正式性能测量 | {passed}/15 轮通过 |')
block='\n## 当前来源的完整验收\n\n'
block+='Release 二百二十八项与 Debug 二百二十六项通过。\n'
block+='完整清单按测试名称核对，共四百五十四项。\n'
block+='全部回归使用串行入口，来源保持冻结。\n'
block+='两种配置分别保存构建输入与产物哈希。\n\n'
block+='五项目在 NVIDIA 与 Intel 上完成十组检查。\n'
block+='覆盖移动隔离、完整游戏与退出释放。\n'
block+='六份 ZIP 的条目、许可与哈希逐项核验。\n'
block+='两份制作项目沿用已制作内容，经当前运行时发布。\n\n'
block+=f'十五轮正式性能中，{passed} 轮通过。\n'
block+='每轮初温、预热、采样和预算保持既定要求。\n'
block+='本轮结果只对应本页的候选来源。\n'
block+='原始失败与通过记录共同保存。\n\n'
block+='| 负载 | 轮次 | GPU P95 | 工作集增长 | 结果 |\n| --- | --- | --- | --- | --- |\n'
for name,group in formal['rounds'].items():
    for number,row in enumerate(group,1):
        gpu=f"{row['gpu']['p95']:.3f} 毫秒" if 'gpu' in row else '无有效值'
        memory=f"{row['stableWorkingSetGrowth']*100:.3f}%" if 'stableWorkingSetGrowth' in row else '无有效值'
        block+=f"| {name} | {number} | {gpu} | {memory} | {'通过' if row['passed'] else '失败'} |\n"
block+='\n| 正式长跑 | 实际秒数 | 帧数 | 工作集增长 | 状态 |\n| --- | --- | --- | --- | --- |\n'
for name,label in [('platformer','平台关卡'),('standard','标准交替场景')]:
    row=runs[name]
    seconds=f"{row['actualSeconds']:.3f}" if row['actualSeconds'] is not None else '缺少完整结果'
    growth=f"{row['workingSetGrowth']*100:.3f}%" if row['workingSetGrowth'] is not None else '缺少有效值'
    block+=f"| {label} | {seconds} | {row['frames'] or '缺少完整结果'} | {growth} | {row['status']} |\n"
block+='\n平台长跑留下 300.016 秒的最后进度。\n'
block+='Player 与验收进程退出，完整结果缺失。\n'
block+='终止原因待查，该次记录保持未通过验收。\n'
block+='两类三十分钟门禁由后续冻结候选继续执行。\n\n'
block+='本轮 WPR 启动实际返回 `0x80070005`。\n'
block+='系统拒绝访问，完整系统追踪尚待执行。\n'
block+='原始错误、独立会话与来源校验结果已保存。\n\n'
block+='原始记录见[缓存证据清单](cache-publication-evidence/manifest.json)。\n'
block+='工作集历史异常的完整因果仍需系统追踪。\n'
block+='实体操作、听感与人工效率各有待验记录。\n'
block+='当前阶段全部必需项通过后推进格式拓展。\n'
append(page,block)
plan='docs/plans/2026-10-11-cache-publication.md'
replace(plan,'> 状态：机制与并发规划通过，完整回归进行中。','> 状态：'+status)
replace(plan,'- [ ] 执行两配置回归，保存失败和完整结果。','- [x] 执行两配置回归，保存失败和完整结果。')
replace(plan,'- [ ] 同步机制说明、缺陷清单与变更记录。','- [x] 同步机制说明、缺陷清单与变更记录。')
replace('README.md','当前来源回归与实测见[界面驻留验收]',
    '界面共享页候选的回归与实测见[界面驻留验收]')
readme='\n资产缓存使用独立暂存目录与完整文件发布。\n'
readme+='Windows 缓存读取共享发布所需的删除访问。\n'
readme+='完整回归与当前来源实测见[缓存并发验收](docs/acceptance/u16/cache-publication.md)。\n'
readme+='人工门禁与历史内存归因按各自证据维护。\n'
replace('README.md','\n资产格式后续阶段见',readme+'\n资产格式后续阶段见')
changelog='## U16 缓存并发发布修复 2026-10-11\n\n'
changelog+='缓存写入使用独占暂存目录与原子发布。\n'
changelog+='Windows 缓存读取补齐共享删除访问。\n'
changelog+='完整获胜缓存可供同一指纹的发布者复用。\n'
changelog+='失败清理仅处理本次拥有的暂存内容。\n\n'
changelog+=f'二十四次规划与四百五十四项完整回归通过。\n十五轮正式性能中，{passed} 轮通过。\n'
changelog+='双设备移动发布通过，两类长跑继续按计划验收。\n'
changelog+='原始证据与待项见[缓存验收](docs/acceptance/u16/cache-publication.md)。\n\n'
replace('CHANGELOG.md','# Changelog\n\n','# Changelog\n\n'+changelog)
replace('mkdocs.yml','nav:\n','nav:\n  - 资产缓存并发验收: acceptance/u16/cache-publication.md\n  - 资产缓存发布计划: plans/2026-10-11-cache-publication.md\n')
append('docs/plans/azure-engine-plan.md','\n## 缓存并发候选验收\n\n'
    'UX-009 的缓存机制、并发规划与完整回归通过。\n'
    f'该来源的正式性能通过 {passed}/15 轮。\n'
    '两类三十分钟长跑按[缓存验收](../acceptance/u16/cache-publication.md)维护状态。\n'
    'P5、U15、U16 与 P6 的人工及归因门禁保持待验。\n')
append('docs/plans/2026-10-10-p5-closure-and-user-experience.md',
    '\n## 缓存并发独立修复\n\n'
    'UX-009 由资产数据库的缓存所有权规则处理。\n'
    '两配置并发与串行规划共二十四次通过。\n'
    '完整回归共四百五十四项通过。\n'
    f'当前来源正式性能通过 {passed}/15 轮。\n\n'
    '两类长跑及双设备发布分别记录实际结果。\n'
    '证据见[缓存并发验收](../acceptance/u16/cache-publication.md)。\n'
    '完整阶段仍按性能、归因与人工门禁验收。\n')
append('docs/acceptance/p5/2026-10-10.md','\n## 缓存并发候选\n\n'
    '当前缓存候选通过四百五十四项完整回归。\n'
    '五项目双设备移动发布共十组通过。\n'
    f'正式性能中，{passed}/15 轮通过。\n'
    '两类长跑与来源见[缓存验收](../u16/cache-publication.md)。\n')
append('docs/acceptance/p6/2026-10-10.md','\n## 缓存并发候选来源\n\n'
    '缓存候选的完整回归与双设备移动发布通过。\n'
    f'正式性能中，{passed}/15 轮通过。\n'
    '两类长跑与待项见[缓存验收](../u16/cache-publication.md)。\n'
    '本表的人工结果按实际执行情况填写。\n')
replace('docs/acceptance/p5/closure/ui-residency.md',
    '> 状态：界面峰值已归因，正式测量按本页结果维护。',
    '> 状态：界面峰值已归因，正式测量按本页结果维护。\n'
    '> 候选来源：`3ed9f9c0a2addbbff59b7e827c8b589e7a688622bfb6f413b84440741c909122`。')
path=root/'docs/plans/authoring-usability-manifest.json'
manifest=json.loads(path.read_text(encoding='utf-8'))
issue=next(row for row in manifest['issues'] if row['id']=='UX-009')
issue.update(status='MechanismConcurrencyAndFullRegressionVerified',
    acceptance='docs/acceptance/u16/cache-publication.md',
    test='AzureEngine.AssetLevel',concurrentRuns=18,serializedRuns=6)
manifest['cachePublicationCandidate']=dict(sourceHash=formal['sourceHash'],
    acceptance='docs/acceptance/u16/cache-publication.md',releaseTests=228,debugTests=226,
    concurrentRuns=18,serializedRuns=6,deliveryChecks=10,
    formalPerformancePassed=formal['passed'],formalPassedRounds=passed,formalTotalRounds=15,
    longRuns={name:{key:row[key] for key in ('status','actualSeconds','frames','workingSetGrowth')}
        for name,row in runs.items()},packageHashes={row['kind']:row['sha256'] for row in delivery['packages']},
    physicalInputVerified=False,subjectiveAudioVerified=False,authoringEfficiencyVerified=False,
    priorWorkingSetCauseResolved=False)
assert not manifest['u15Complete'] and not manifest['u16Complete'] and not manifest['p6Complete']
path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(sourceHash=formal['sourceHash'],formalPassedRounds=passed,
    longRuns={name:row['status'] for name,row in runs.items()},currentStagesComplete=False)))
