"""Keep CPU and GPU tests serial and bind each result to the frozen candidate."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root=Path.cwd().resolve()
out=root/'build/p5-cache-publication-2026-10-11'
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify
frozen=inputs(root)
source_hash=hashlib.sha256(json.dumps(frozen,sort_keys=True).encode()).hexdigest()
records=[]
ctest=Path('D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe')
for configuration in ('release','debug'):
    proof=json.loads((root/('build/ninja-msvc-'+configuration)/'build-provenance.json').read_text(encoding='utf-8'))
    verify(root,proof)
    (out/(configuration+'-provenance.json')).write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
for group,selection in [('cpu',['-LE','gpu']),('gpu',['-L','gpu'])]:
    for configuration in ('release','debug'):
        log=out/(configuration+'-'+group+'.log')
        print('Starting',configuration,group,flush=True)
        with log.open('w',encoding='utf-8') as stream:
            result=subprocess.run([str(ctest),'--test-dir',str(root/('build/ninja-msvc-'+configuration)),
                '-C',configuration.capitalize(),'--output-on-failure',*selection,'-j','1'],
                cwd=root,stdout=stream,stderr=subprocess.STDOUT)
        assert inputs(root)==frozen
        records.append(dict(configuration=configuration,group=group,exitCode=result.returncode,
            log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest(),sourceHash=source_hash))
        (out/'regression-status.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
        print(configuration,group,'exit',result.returncode,flush=True)
raise SystemExit(int(any(row['exitCode'] for row in records)))
