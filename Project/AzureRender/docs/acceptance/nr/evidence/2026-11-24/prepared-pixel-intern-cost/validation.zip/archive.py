from pathlib import Path
import hashlib,json,re,sqlite3,subprocess,zipfile
import xml.etree.ElementTree as ET

run=Path(__file__).resolve().parent
repo=Path("D:/Projects/FYP")
engine=repo/"Project/AzureRender"
dest=engine/"docs/acceptance/nr/evidence/2026-11-24/prepared-pixel-intern-cost"
dest.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(p,a):p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
pair=read(run/"pair.json")
release=read(run/"release-product.json")
assert pair["poolReduction"]>=.20 and pair["cpuPreparationSavedMs"]>=2000
assert pair["candidate"]["intern"]["constructed"]==350 and pair["candidate"]["intern"]["hits"]==1096
assert all(pair[k]["inputsVerified"]==1729 for k in ["reference","candidate"])
assert release["source"]==sha(engine/"src/foundation/ImmutableBytes.cpp")
assert "Intern profile:" not in (engine/"src/foundation/ImmutableBytes.cpp").read_text()
gpu=read(run/"gpu/summary.json")
assert gpu["status"]=="passed" and len(gpu["cases"])==4
assert gpu["programSha256"]==release["player"]==sha(engine/"build/ninja-msvc-release/AzurePlayer.exe")
cpu=ET.parse(run/"cpu.xml").getroot()
assert len(list(cpu.iter("testcase")))==2 and not list(cpu.iter("failure")) and not list(cpu.iter("skipped"))
protected=read(run/"protected.json");assert all(sha(repo/n)==h for n,h in protected.items())
with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro",uri=True) as db:
    db.row_factory=sqlite3.Row
    rows=[dict(row) for row in db.execute("SELECT id,task,state,exit_code,run_seconds FROM jobs WHERE output=? ORDER BY id",(str(run),))]
assert len(rows)==6 and all(row["state"]=="succeeded" for row in rows),rows
write(run/"jobs.json",rows)
files={n:run/n for n in ["measure.py","archive.py","unit.json","reference.patch","candidate.patch","pair.json","jobs.json",
    "cpu.xml","cpu.log","gpu.log","gpu/summary.json","release-product.json","release-build.log"]}
for role in ["reference","candidate"]:
    for kind in ["build","player"]:
        for suffix in [".log","-command.json"]:
            n=role+"-"+kind+suffix;files[n]=run/n
    for name in ["product","timing","summary"]:
        n=role+"-"+name+".json";files[n]=run/n
files["release-source.cpp"]=engine/"src/foundation/ImmutableBytes.cpp"
manifest={name:dict(sha256=sha(p),bytes=p.stat().st_size) for name,p in files.items()}
archive=dest/"validation.zip"
with zipfile.ZipFile(archive,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in files.items():z.write(p,n)
    z.writestr("manifest.json",json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(files)|{"manifest.json"}
    assert all(hashlib.sha256(z.read(n)).hexdigest()==m["sha256"] for n,m in manifest.items())
write(dest/"results.json",dict(baseline="587b48428f3f0998fa03f7126ce8adf6756cb194",pair=pair,release=release,
    jobs=rows,cpuChecks=2,gpuCaptures=4,protectedFiles=len(protected),scope="Joint scene data preparation and immutable pool operations",
    archive=dict(sha256=sha(archive),members=len(files)+1,bytes=archive.stat().st_size)))
doc=engine/"docs/acceptance/nr/prepared-pixel-intern-cost.md"
s=doc.read_text(encoding="utf-8")
assert all((doc.parent/n).exists() for n in re.findall(r"\]\(([^)]+)\)",s))
assert all(len(re.findall(r"[\u4e00-\u9fff]",part))<=45 for part in re.split(r"[。！？\n]",s))
print("Verified pair, two CPU cases, four GPU captures, and",len(files)+1,"archive members")
