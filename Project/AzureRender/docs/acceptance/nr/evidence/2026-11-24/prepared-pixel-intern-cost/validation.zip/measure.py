from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

run = Path(__file__).resolve().parent
engine = Path("D:/Projects/FYP/Project/AzureRender")
build = engine / "build/ninja-msvc-release"
mode, role = sys.argv[1:3]
env = os.environ.copy()
env["DOTNET_ROOT"] = "D:/Tools/dotnet9"
env["PATH"] = env["DOTNET_ROOT"] + os.pathsep + "D:/Tools/Python311" + os.pathsep + env["PATH"]
env["VK_LOADER_DRIVERS_SELECT"] = "*nv-vk64*"
player = build / "AzurePlayer.exe"

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def write(name, data):
    (run / name).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

def execute(name, command, timeout):
    write(name + "-command.json", command)
    with (run / (name + ".log")).open("wb") as log:
        subprocess.run(command, cwd=build, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=timeout, check=True)

if mode == "build":
    command = [str(engine / "tools/msvc_env.bat"), "cmake", "--build", str(build), "--target",
               "AzurePlayer", "AzureSampledTextureCacheTests", "-j", "3"]
    execute(role + "-build", command, 520)
    write(role + "-product.json", dict(player=sha(player), source=sha(engine/"src/foundation/ImmutableBytes.cpp"),
        test=sha(build/"AzureSampledTextureCacheTests.exe")))
elif mode == "scene":
    product = json.loads((run/(role+"-product.json")).read_bytes())
    assert sha(player) == product["player"]
    frozen_file = engine / "build/runs/20261119-180745-mainline-joint-consumer-attribution-b0a9c4/input-verification.json"
    frozen = json.loads(frozen_file.read_bytes())["files"]
    assert len(frozen) == 1729 and all(sha(Path(p)) == h for p,h in frozen.items())
    driver = subprocess.check_output(["C:/Windows/System32/nvidia-smi.exe","--query-gpu=driver_version,name",
                                      "--format=csv,noheader"],text=True).strip()
    assert driver.startswith("595.79"),driver
    project = engine / "build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject"
    command = [str(player),"--resource-root",str(build),"--project",str(project),"--width","1920","--height","1080",
               "--qa-camera","scene","--qa-light","scene","--fixed-frame-step","--capture-fps","60","--smoke-frames","4",
               "--gpu-timing","--gpu-timing-output",str(run/(role+"-timing.json"))]
    t = time.perf_counter()
    execute(role+"-player",command,420)
    report = json.loads((run/(role+"-timing.json")).read_bytes())
    log = (run/(role+"-player.log")).read_text(encoding="utf-8",errors="replace")
    rows = [line for line in log.splitlines() if line.startswith("Intern profile:")]
    assert len(rows) == 1, rows
    assert "Allocator after unload: buffers=0 images=0" in log and "Rendered frames: 4" in log
    assert not re.search(r"VUID-|Validation (?:Error|Warning)|\[error\]",log)
    assert sha(player)==product["player"] and all(sha(Path(p))==h for p,h in frozen.items())
    counters = {k: float(v) if "." in v else int(v) for k,v in re.findall(r"(\w+)=([0-9.]+)",rows[0])}
    write(role+"-summary.json",dict(driver=driver,elapsed=time.perf_counter()-t,sceneLoad=report["sceneLoad"],
        texture=report["materialTextureCache"],intern=counters,inputsVerified=len(frozen)))
elif mode == "tests":
    product=json.loads((run/(role+"-product.json")).read_bytes())
    assert sha(player)==product["player"] and sha(build/"AzureSampledTextureCacheTests.exe")==product["test"]
    ctest="D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe"
    execute("cpu",[ctest,"--test-dir",str(build),"-R","^AzureRender[.](SampledTextureCache|TextureMipCoverage)$",
                   "--output-on-failure","--output-junit",str(run/"cpu.xml")],90)
    execute("gpu",[str(engine/"build/reinstall-environment/venv/Scripts/python.exe"),
        str(engine/"tools/test_material_coverage_mips_gpu.py"),"--executable",str(player),"--output",str(run/"gpu"),
        "--expected-validation","disabled","--case","ring-4"],220)
else:
    raise ValueError(mode)
