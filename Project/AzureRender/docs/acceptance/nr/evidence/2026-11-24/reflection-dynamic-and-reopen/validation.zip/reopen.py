import importlib.util,json
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('fixture',R.parent/'20261120-000157-nr-original-reflection-switch-fed32b/switch_fixture.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.ROOT=R;m.HOST=R.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/msaa-release'
m.prepare(R/'rotating-reopen',True)
(R/'rotating-reopen/assets/switch.lua').write_bytes((R/'rotating/assets/switch.lua').read_bytes())
m.start('rotating-reopen',True,'reflection',R.parent/'20261112-231945-projected-hair-reference-grid-4b775d/nv-vk64-active-absolute.json')
for a,b in zip(m.frames(R/'rotating'),m.frames(R/'rotating-reopen')):np.testing.assert_array_equal(a,b)
a=m.load(R/'rotating-reopen/runtime.json');assert a['replayedActions']==2 and not a['scriptErrors'] and not a['presentationErrors']
assert not a['routeFrames'][0]['doorOpen'] and a['routeFrames'][-1]['doorOpen']
(R/'reopen.json').write_text(json.dumps(dict(replayedActions=2,initialState=False,finalState=True,exactFrames=12),indent=2)+'\n')
print('PASS: reopening resets state and reproduces twelve complete frames')
