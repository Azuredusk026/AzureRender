from pathlib import Path
import json,math,re
import numpy as np
from PIL import Image
from test_screen_space_reflections_gpu import RIGHT,TARGET_Y,target_corners,project,polygon_mask,linear
R=Path(__file__).resolve().parent
d=json.loads((R/'results.json').read_bytes());assert len(d['gpu'])==5
for row in d['gpu']:
 q=row['result'];assert q['validationErrors']==q['liveBuffers']==q['liveImages']==0
 out=R/(row['mode']+'-qualified');col=np.fromfile(out/'0.bin','<u4').reshape(240,320);conf=np.fromfile(out/'2.bin','u1').reshape(240,320)
 count=int(((col[192:211,96:224]==0x380)&(conf[192:211,96:224]>=128)).sum());assert count==q['redHits']
 expected=2432 if row['mode'] in ('history-response-moving','history-shifted') else 0
 assert q['redHits']==q['filteredRedHits']==expected
center=np.array([RIGHT,TARGET_Y,0]);a=math.pi/4;rot=np.array([[math.cos(a),-math.sin(a),0],[math.sin(a),math.cos(a),0],[0,0,1]])
corners=(target_corners(RIGHT)-center)@rot.T+center;corners[:,1]*=-1;mask=polygon_mask(project(corners),.6)
for case in ('rotating','rotating-reopen'):
 p=R/case;log=(p/'player.log').read_bytes();assert not re.search(rb'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[validation warning\]',log,re.I);assert b'Allocator after unload: buffers=0 images=0' in log
 images=[np.asarray(Image.open(x).convert('RGB')) for x in sorted((p/'frames').glob('frame_*.png'))];assert len(images)==12
 if case=='rotating':first=images
 else:
  for a,b in zip(first,images):np.testing.assert_array_equal(a,b)
 for image in images[4:]:
  rgb=linear(image);assert np.maximum(rgb[...,0]-.5*(rgb[...,1]+rgb[...,2]),0)[mask].mean()>.003
 q=json.loads((p/'runtime.json').read_bytes());assert q['replayedActions']==2 and not q['scriptErrors'] and not q['presentationErrors'];assert not q['routeFrames'][0]['doorOpen'] and q['routeFrames'][-1]['doorOpen']
print('PASS: five composition cases, rotated reflection and twelve exact reopen frames')
