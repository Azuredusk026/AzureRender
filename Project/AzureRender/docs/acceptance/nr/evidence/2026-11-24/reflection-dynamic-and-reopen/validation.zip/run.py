import importlib.util,json,os,subprocess,math
from pathlib import Path
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent
B=R.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/msaa-release'
spec=importlib.util.spec_from_file_location('switch',R.parent/'20261120-000157-nr-original-reflection-switch-fed32b/switch_fixture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
driver=R.parent/'20261112-231945-projected-hair-reference-grid-4b775d/nv-vk64-active-absolute.json'
env=dict(os.environ,VK_DRIVER_FILES=str(driver),VK_LAYER_PATH='D:/Tools/VulkanSDK/1.4.350.0/Bin',VK_LAYER_VALIDATE_SYNC='1')
rows=[]
for mode,ok in [('history-reset',False),('history-response-moving',True),('history-response-moving-depth',False),('history-disoccluded',False),('history-shifted',True)]:
 out=R/(mode+'-qualified');p=subprocess.run([str(B/'AzureProjectedReflectionCameraGpuTests.exe'),str(B/'shaders/projected_reflection_trace.comp.spv'),str(out),mode,'--composition',str(B/'shaders')],capture_output=True,env=env,timeout=45)
 (R/(mode+'.log')).write_bytes(p.stdout+p.stderr);d=json.loads((out/'result.json').read_bytes());assert p.returncode==(0 if ok else 1),(mode,d)
 assert d['validationErrors']==d['liveBuffers']==d['liveImages']==0,d
 if not ok:assert d['redHits']==d['filteredRedHits']==0,d
 rows.append(dict(mode=mode,result=d))
m.ROOT=R;m.HOST=B;path=R/'rotating';m.prepare(path,True)
lua=path/'assets/switch.lua';lua.write_text(m.SWITCH.replace("lamp:set('azure.transform'", "plate:set('azure.transform', 'rotation', {0,0,45})\n    lamp:set('azure.transform'"),encoding='utf-8')
m.start('rotating',True,'reflection',driver)
corners=m.mirror.target_corners(m.mirror.RIGHT);center=np.array([m.mirror.RIGHT,m.mirror.TARGET_Y,0]);theta=math.pi/4;rot=np.array([[math.cos(theta),-math.sin(theta),0],[math.sin(theta),math.cos(theta),0],[0,0,1]])
corners=(corners-center)@rot.T+center;corners[:,1]*=-1;mask=m.mirror.polygon_mask(m.mirror.project(corners),.6)
signals=[]
for image in m.frames(path):
 rgb=m.mirror.linear(image);signals.append(float(np.maximum(rgb[...,0]-.5*(rgb[...,1]+rgb[...,2]),0)[mask].mean()))
assert min(signals[4:])>.003,signals
(R/'results.json').write_text(json.dumps(dict(gpu=rows,rotatingSignals=signals),indent=2)+'\n')
print('PASS: composition reset, camera shift, disocclusion, moving depth and rotated Player')
