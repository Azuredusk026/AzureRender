import json,zlib,hashlib,sys,re
from pathlib import Path
import numpy as np
from test_screen_space_reflections_gpu import RIGHT,oracle,polygon_mask
R=Path(__file__).resolve().parent
rows=json.loads((R/'normal-readback.json').read_bytes());assert len(rows)==2
mask=polygon_mask(oracle(RIGHT)['reflectionPolygon'],.65)[1::2,1::2];assert mask.sum()==97
results={}
for row in rows:
 m=row['normal'];raw=zlib.decompress((R/m['file']).read_bytes());assert hashlib.sha256(raw).hexdigest()==m['sha256']
 a=np.frombuffer(raw,'<f4').reshape(m['height'],m['width'],4);assert np.isfinite(a).all();p=a[...,:2]*2-1;n=np.stack([p[...,0],1-np.abs(p).sum(axis=-1),p[...,1]],-1);n/=np.linalg.norm(n,axis=-1,keepdims=True)
 angle=np.degrees(np.arctan2(np.linalg.norm(n[mask][:,[0,2]],axis=1),n[mask][:,1]))
 if row['label'].startswith('without-map'):
  assert np.all(angle==0);control=a
 else:
  assert np.all((angle>.317)&(angle<.319));np.testing.assert_array_equal(control[...,[2,3]],a[...,[2,3]])
 results[row['label']]=dict(pixels=97,minDegrees=float(angle.min()),maxDegrees=float(angle.max()))
 for name in ('without-map-isolated','with-map-isolated'):
  log=(R/name/'player.log').read_bytes();assert b'Allocator after unload: buffers=0 images=0' in log;assert not re.search(rb'VUID-|SYNC-HAZARD|\[validation warning\]|\[error\]',log,re.I)
cpu=json.loads((R/'matrix-cpu.json').read_bytes());assert len(cpu)==14 and all(x['exitCode']==0 for x in cpu)
smoke=json.loads((R/'smoke.json').read_bytes());assert smoke['released'] and smoke['tracingSamples']==4
if '--record' in sys.argv:(R/'computed.json').write_text(json.dumps(results,indent=2)+'\n')
else:assert results==json.loads((R/'computed.json').read_bytes())
print(json.dumps(results,indent=2));print('PASS: actual normal provenance, authored pixels, two configurations and tracing smoke')
