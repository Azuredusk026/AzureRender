import importlib.util,json,subprocess,os,sys,re
from pathlib import Path
R=Path(__file__).resolve().parent
B=R.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/msaa-release'
s=importlib.util.spec_from_file_location('fixture',R/'fixture-source/switch_fixture.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.ROOT=R;m.HOST=B
for name in ('without-map-isolated','with-map-isolated'):m.start(name,True,'beauty',R/'nv-active.json')
sys.path.insert(0,str(R.parents[2]/'tools'))
from create_pathtracing_project import create
project=create(R/'pathtracing-project');f=project.parent/'assets/room.azurelevel';d=json.loads(f.read_bytes());d['renderSettings']['pathTraceSamples']=4;f.write_text(json.dumps(d,indent=2)+'\n')
env=dict(os.environ,VK_DRIVER_FILES=str(R/'nv-active.json'),VK_LAYER_PATH='D:/Tools/VulkanSDK/1.4.350.0/Bin',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
report=R/'pathtracing-runtime.json';p=subprocess.run([str(B/'AzurePlayer.exe'),'--project',str(project),'--width','320','--height','240','--fixed-frame-step','--smoke-frames','16','--runtime-report',str(report)],env=env,cwd=R,capture_output=True,timeout=90)
log=p.stdout+p.stderr;(R/'pathtracing.log').write_bytes(log);assert p.returncode==0,log[-1200:]
assert not re.search(rb'VUID-|SYNC-HAZARD|\[validation warning\]|\[error\]',log,re.I)
assert b'Allocator after unload: buffers=0 images=0' in log
d=json.loads(report.read_bytes());assert d['renderer']=='pathtracing' and d['renderProgress']==dict(samples=4,target=4),d
(R/'smoke.json').write_text(json.dumps(dict(normalPlayerRuns=2,tracingSamples=4,released=True),indent=2)+'\n')
print('PASS: both normal sources on real Player; path tracing reaches four samples and releases resources')
