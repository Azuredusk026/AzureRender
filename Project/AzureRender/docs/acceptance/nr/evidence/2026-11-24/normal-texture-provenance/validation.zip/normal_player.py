import importlib.util,json,subprocess,os,hashlib
from pathlib import Path
from PIL import Image
R=Path(__file__).resolve().parent
B=R.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/msaa-release'
s=importlib.util.spec_from_file_location('fixture',R/'fixture-source/switch_fixture.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
reqs=[]
for name,authored in [('without-map-isolated',False),('with-map-isolated',True)]:
 p=R/name;m.prepare(p,True)
 if authored:
  Image.new('RGBA',(2,2),(128,128,255,255)).save(p/'assets/normal.png')
  f=p/'assets/floor.gltf';d=json.loads(f.read_bytes());d['images']=[dict(uri='normal.png')];d['textures']=[dict(source=0)];d['materials'][0]['normalTexture']=dict(index=0);f.write_text(json.dumps(d,indent=2)+'\n')
 out=R/(name+'-capture');out.mkdir()
 args=[str(B/'AzurePlayer.exe'),'--project',str(p/'project.azureproject'),'--width','320','--height','240','--capture-dir',str(out/'frames'),'--capture-frames','12','--capture-fps','60','--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--runtime-report',str(out/'runtime.json'),'--game-actions',str(p/'actions.json')]
 reqs.append(dict(label=name,operation='capture',output=str(out),source=dict(path=str(B/'AzurePlayer.exe')),arguments=args[1:],working_directory=str(R.parents[2]),timeout=90,frame=4,limitBytes=134217728))
(R/'requests.json').write_text(json.dumps(reqs,indent=2)+'\n')
env=dict(os.environ,AZR_NORMAL_ROOT=str(R),VK_DRIVER_FILES=str(R/'nv-active.json'),VK_LAYER_PATH='D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64;D:/Tools/VulkanSDK/1.4.350.0/Bin',VK_INSTANCE_LAYERS='VK_LAYER_RENDERDOC_Capture;VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',ENABLE_VULKAN_RENDERDOC_CAPTURE='1')
(R/'target-environment.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith('VK_') or k=='ENABLE_VULKAN_RENDERDOC_CAPTURE'},indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('VK_') and k!='ENABLE_VULKAN_RENDERDOC_CAPTURE'};env['AZR_NORMAL_ROOT']=str(R)
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
with (R/'capture-worker.log').open('wb') as log:subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(R/'normal_readback.py')],cwd=R,env=env,startupinfo=startup,stdout=log,stderr=subprocess.STDOUT,timeout=260,check=True)
