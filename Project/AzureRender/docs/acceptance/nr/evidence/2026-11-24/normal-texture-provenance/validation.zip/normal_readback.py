import renderdoc as rd
import os,json,sys,traceback,hashlib,zlib
from pathlib import Path
R=Path(os.environ['AZR_NORMAL_ROOT'])
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools/native_render')
from renderdoc_worker import capture_target
sha=lambda x:hashlib.sha256(x).hexdigest()
def walk(rows):
 for a in rows:
  yield a
  yield from walk(a.children)
class Environment:
 def __getattr__(self,n):return getattr(rd,n)
 def ExecuteAndInject(self,*args):
  args=list(args);env=list(args[3])
  for n in ('VK_DRIVER_FILES','VK_LAYER_PATH','VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','ENABLE_VULKAN_RENDERDOC_CAPTURE'):
   m=rd.EnvironmentModification();m.name=n;m.value=json.loads((R/'target-environment.json').read_bytes())[n];m.mod=rd.EnvMod.Set;env.append(m)
  args[3]=env;return rd.ExecuteAndInject(*args)
rows=[]
try:
 for req in json.loads((R/'requests.json').read_bytes()):
  (R/'phase.txt').write_text(req['label']+' capture')
  receipt=dict(status='failed',artifacts=[],started_unix=0);capture_target(Environment(),req,receipt)
  cap=rd.OpenCaptureFile();ctl=None
  try:
   path=receipt['artifacts'][0]['path'];assert cap.OpenFile(path,'',None)==rd.ResultCode.Succeeded
   opts=rd.ReplayOptions();opts.forceGPUVendor=rd.GPUVendor.nVidia;opts.forceGPUDeviceID=0x28e0
   status,ctl=cap.OpenCapture(opts,None);assert status==rd.ResultCode.Succeeded
   textures={t.resourceId:t for t in ctl.GetTextures()};expected=sha((R.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/msaa-release/shaders/projected_reflection_prepare.comp.spv').read_bytes());matches=[]
   for a in walk(ctl.GetRootActions()):
    if not a.flags&rd.ActionFlags.Dispatch:continue
    ctl.SetFrameEvent(a.eventId,True);p=ctl.GetPipelineState();s=p.GetShaderReflection(rd.ShaderStage.Compute)
    if s is None or sha(bytes(s.rawBytes))!=expected:continue
    for use in p.GetReadWriteResources(rd.ShaderStage.Compute):
     decl=s.readWriteResources[use.access.index]
     if decl.name!='preparedNormal':continue
     t=textures[use.descriptor.resource];data=bytes(ctl.GetTextureData(t.resourceId,rd.Subresource()));f=req['label']+'-normal.zlib';(R/f).write_bytes(zlib.compress(data));matches.append(dict(event=a.eventId,resource=str(t.resourceId),width=t.width,height=t.height,format=t.format.Name(),file=f,sha256=sha(data)))
   assert len(matches)==1,matches
   rows.append(dict(label=req['label'],capture=receipt,normal=matches[0]))
  finally:
   if ctl:ctl.Shutdown()
   cap.Shutdown()
 (R/'normal-readback.json').write_text(json.dumps(rows,indent=2)+'\n')
except Exception:
 (R/'failure.txt').write_text(traceback.format_exc());os._exit(1)
os._exit(0)
