import json,os,subprocess,sys,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
B=R.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'/'msaa-release'
phase=sys.argv[1]
env=dict(os.environ,VK_DRIVER_FILES=str(R.parent/'20261112-231945-projected-hair-reference-grid-4b775d'/'nv-vk64-active-absolute.json'),VK_LAYER_PATH='D:/Tools/VulkanSDK/1.4.350.0/Bin',VK_LAYER_VALIDATE_SYNC='1')
cases=[('history-response-moving',phase!='red')]
if phase!='red':
 cases += [(n,True) for n in ('positive','history-static','history-response-tracked','history-shifted','history-response-cutout','history-response-partial')]
 cases += [(n,False) for n in ('history-response-moving-depth','history-response-background','history-response-missing','history-response-reactive','history-response-nonfinite','history-response-depth','history-response-zero-depth','history-response-outside','history-wrong-pose','history-disoccluded')]
rows=[]
for mode,ok in cases:
 out=R/(phase+'-'+mode);args=[str(B/'AzureProjectedReflectionCameraGpuTests.exe'),str(B/'shaders/projected_reflection_trace.comp.spv'),str(out),mode,str(B/'shaders/projected_reflection_prepare.comp.spv')]
 p=subprocess.run(args,cwd=R,env=env,capture_output=True,timeout=45)
 (R/(out.name+'.log')).write_bytes(p.stdout+p.stderr)
 assert (out/'result.json').exists(),(mode,p.returncode,p.stderr.decode(errors='replace'))
 d=json.loads((out/'result.json').read_bytes());assert d['validationErrors']==d['liveBuffers']==d['liveImages']==0,d
 assert p.returncode==(0 if ok else 1),(mode,d)
 if phase=='red':assert d['redHits']==0,d
 rows.append(dict(mode=mode,expectedSuccess=ok,exitCode=p.returncode,result=d))
 (R/(phase+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
 print(mode,p.returncode,d['redHits'],flush=True)
print('PASS:',phase,len(rows),'cases')
