import importlib.util,json,hashlib,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent
source=R.parent/'20261120-000157-nr-original-reflection-switch-fed32b/switch_fixture.py'
spec=importlib.util.spec_from_file_location('switch',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
B=R.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/msaa-release'
shader=B/'shaders/projected_reflection_trace.comp.spv';candidate=shader.read_bytes()
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
args=[str(sdk/'dxc.exe'),'-spirv','-T','cs_6_0','-E','main','-HV','2018','-fspv-target-env=vulkan1.1','-fvk-b-shift','0','0','-fvk-t-shift','1','0','-fvk-s-shift','8','0','-fvk-u-shift','9','0','-Od','-Fo',str(R/'baseline.spv'),str(R/'baseline.hlsl')]
subprocess.run(args,check=True);subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.1',str(R/'baseline.spv')],check=True)
driver=R.parent/'20261112-231945-projected-hair-reference-grid-4b775d/nv-vk64-active-absolute.json'
rows={}
try:
 for label,binary in [('baseline',(R/'baseline.spv').read_bytes()),('candidate',candidate)]:
  shader.write_bytes(binary);m.ROOT=R/label;m.ROOT.mkdir();m.HOST=B
  for name,action,view in m.CASES:m.prepare(m.ROOT/name,action);m.start(name,action,view,driver)
  m.checks();rows[label]=m.load(m.ROOT/'measurements.json')
 assert rows['baseline']['switch-reflection']['redReflectionMeans'][4][1]<.003
 assert rows['candidate']['switch-reflection']['redReflectionMeans'][4][1]>.003
 # No input events: complete images remain identical across the sequence.
 for i in range(12):
  a=m.frames(R/'baseline/idle-reflection')[i];b=m.frames(R/'candidate/idle-reflection')[i]
  assert (a==b).all(),i
 (R/'player-pair.json').write_text(json.dumps(dict(results=rows,playerSha256=hashlib.sha256((B/'AzurePlayer.exe').read_bytes()).hexdigest(),candidateSha256=hashlib.sha256(candidate).hexdigest(),idleExact=True),indent=2)+'\n')
 print('PASS: input-driven switch recovers frame 4; twelve idle frames exact')
finally:
 shader.write_bytes(candidate)
 assert shader.read_bytes()==candidate
