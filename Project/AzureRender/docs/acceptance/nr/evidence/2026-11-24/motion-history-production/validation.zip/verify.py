from pathlib import Path
import json,re
import numpy as np
from PIL import Image
from test_screen_space_reflections_gpu import RIGHT,oracle,polygon_mask,linear
R=Path(__file__).resolve().parent
read=lambda p:json.loads((R/p).read_bytes())
red=read('red.json');green=read('green.json');assert red[0]['result']['redHits']==0
assert len(green)==17 and green[0]['result']['redHits']==2432
for row in green:
 d=row['result'];assert row['exitCode']==(0 if row['expectedSuccess'] else 1)
 assert d['validationErrors']==d['liveBuffers']==d['liveImages']==0
 if not row['expectedSuccess']:assert d['redHits']==0
 raw=R/('green-'+row['mode']);col=np.fromfile(raw/'0.bin','<u4').reshape(240,320);conf=np.fromfile(raw/'2.bin','u1').reshape(240,320);foot=np.fromfile(raw/'1.bin','<u2').reshape(240,320,2)
 reg=(col[192:211,96:224]==0x380)&(conf[192:211,96:224]>=d['minimumConfidence'])
 assert int(reg.sum())==d['redHits']
 assert int((reg&(foot[192:211,96:224,0]==65535)).sum())==d['staticHits']
mask=polygon_mask(oracle(RIGHT)['reflectionPolygon'],.65)
for label in ('baseline','candidate'):
 for name in ('switch-reflection','idle-reflection','switch-beauty'):
  p=R/label/name;log=(p/'player.log').read_bytes()
  assert not re.search(rb'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[validation warning\]',log,re.I)
  assert b'Allocator after unload: buffers=0 images=0' in log
  assert len(list((p/'frames').glob('frame_*.png')))==12
def frame(label,case,i):return np.asarray(Image.open(R/label/case/'frames'/('frame_%06d.png'%i)).convert('RGB'))
signals={}
for label in ('baseline','candidate'):
 for case in ('switch-reflection','switch-beauty'):
  rgb=linear(frame(label,case,4));signals[label+'-'+case]=float(np.maximum(rgb[...,0]-.5*(rgb[...,1]+rgb[...,2]),0)[mask].mean())
for case in ('switch-reflection','switch-beauty'):
 assert signals['baseline-'+case]<.003 and signals['candidate-'+case]>.003
for i in range(12):np.testing.assert_array_equal(frame('baseline','idle-reflection',i),frame('candidate','idle-reflection',i))
print(json.dumps(signals,indent=2));print('PASS: 17 GPU cases, frame-4 beauty and reflection, 12 identical idle frames')
