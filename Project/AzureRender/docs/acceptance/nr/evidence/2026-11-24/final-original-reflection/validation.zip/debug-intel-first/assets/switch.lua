function interact(actor)
    local plate = self:find('guide-plate')
    local lamp = self:find('inspection-lamp')
    if actor ~= 'technician' or self:get('azure.door', 'open') then return end
    plate:set('azure.transform', 'translation', {0.7, 1, 0})
    plate:set('azure.transform', 'rotation', {0,0,45})
    lamp:set('azure.transform', 'translation', {1.75, 1.1, 1.1})
    self:set('azure.door', 'open', true)
    self:set('azure.interactable', 'prompt', 'Inspection route active')
end
