import json,importlib.util,math
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parent
N=R.parent/'20261124-020832-nr-normal-production-34180e'
s=importlib.util.spec_from_file_location('fixture',N/'fixture-source/switch_fixture.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.ROOT=R
builds={'release':R.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/msaa-release','debug':R.parent/'20261110-031856-hair-main-chroma-debug-668bf2/debug'}
drivers={'nvidia':N/'nv-active.json','intel':R.parent/'20261124-020035-nr-intel-motion-qualification-b71a94/intel-absolute.json'}
c=np.array([m.mirror.RIGHT,m.mirror.TARGET_Y,0]);a=math.pi/4;rot=np.array([[math.cos(a),-math.sin(a),0],[math.sin(a),math.cos(a),0],[0,0,1]]);corners=(m.mirror.target_corners(m.mirror.RIGHT)-c)@rot.T+c;corners[:,1]*=-1;mask=m.mirror.polygon_mask(m.mirror.project(corners),.6)
rows=[]
for config,b in builds.items():
 m.HOST=b
 for device,driver in drivers.items():
  for attempt in ('first','reopen'):
   name=config+'-'+device+'-'+attempt;p=R/name;m.prepare(p,True);(p/'assets/switch.lua').write_text(m.SWITCH.replace("lamp:set('azure.transform'","plate:set('azure.transform', 'rotation', {0,0,45})\n    lamp:set('azure.transform'"),encoding='utf-8');m.start(name,True,'reflection',driver)
   images=m.frames(p)
   if attempt=='first':first=images
   else:
    for a,b in zip(first,images):np.testing.assert_array_equal(a,b)
   values=[]
   for image in images:
    rgb=m.mirror.linear(image);values.append(float(np.maximum(rgb[...,0]-.5*(rgb[...,1]+rgb[...,2]),0)[mask].mean()))
   assert min(values[4:])>.003,values
   d=m.load(p/'runtime.json');assert not d['scriptErrors'] and not d['presentationErrors'];assert not d['routeFrames'][0]['doorOpen'] and d['routeFrames'][-1]['doorOpen']
   rows.append(dict(config=config,device=device,attempt=attempt,minSignal=float(min(values[4:])),exactFramesOnReopen=12 if attempt=='reopen' else 0));(R/'player.json').write_text(json.dumps(rows,indent=2)+'\n')
print('PASS: eight current Player launches across two devices and configurations, including exact reopen frames')
