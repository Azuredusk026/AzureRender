import json,os,subprocess,re
from pathlib import Path
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent
N=R.parent/'20261124-020832-nr-normal-production-34180e'
builds={'release':R.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/msaa-release','debug':R.parent/'20261110-031856-hair-main-chroma-debug-668bf2/debug'}
drivers={'nvidia':N/'nv-active.json','intel':R.parent/'20261124-020035-nr-intel-motion-qualification-b71a94/intel-absolute.json'}
rows=[]
for config,b in builds.items():
 for device,driver in drivers.items():
  first=R/(config+'-'+device+'-first');out=R/(config+'-'+device+'-same-project');out.mkdir()
  env=dict(os.environ,VK_DRIVER_FILES=str(driver),VK_LAYER_PATH='D:/Tools/VulkanSDK/1.4.350.0/Bin',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
  args=[str(b/'AzurePlayer.exe'),'--project',str(first/'project.azureproject'),'--width','320','--height','240','--capture-dir',str(out/'frames'),'--capture-frames','12','--capture-fps','60','--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','reflection','--game-actions',str(first/'actions.json'),'--runtime-report',str(out/'runtime.json')]
  p=subprocess.run(args,cwd=R.parents[2],env=env,capture_output=True,timeout=90);log=p.stdout+p.stderr;(out/'player.log').write_bytes(log)
  assert p.returncode==0,log[-1200:];assert not re.search(rb'VUID-|SYNC-HAZARD|\[validation warning\]|\[error\]',log,re.I);assert b'Allocator after unload: buffers=0 images=0' in log
  for i in range(12):
   name='frame_%06d.png'%i;a=np.asarray(Image.open(first/'frames'/name).convert('RGB'));c=np.asarray(Image.open(out/'frames'/name).convert('RGB'));np.testing.assert_array_equal(a,c)
  d=json.loads((out/'runtime.json').read_bytes());assert not d['routeFrames'][0]['doorOpen'] and d['routeFrames'][-1]['doorOpen'];assert d['replayedActions']==2
  rows.append(dict(config=config,device=device,project=str(first/'project.azureproject'),exactFrames=12,initialState=False,finalState=True));(R/'same-project.json').write_text(json.dumps(rows,indent=2)+'\n')
print('PASS: four same-path project reopen checks, twelve exact frames per case')
