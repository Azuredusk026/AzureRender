import json,subprocess,os,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
builds={'release':R.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/msaa-release','debug':R.parent/'20261110-031856-hair-main-chroma-debug-668bf2/debug'}
rows=[]
cpu=('AzureTextureMaterialImportTests','AzureMaterialDocumentTests','AzureMaterialPipelinePolicyTests','AzurePathTracingTests','AzureProjectedReflectionRayTests','AzureProjectedReflectionPreparationTests','AzureProjectedScreenReflectionTests')
for config,b in builds.items():
 for name in cpu:
  p=subprocess.run([str(b/(name+'.exe'))],cwd=R,capture_output=True,timeout=120);(R/(config+'-'+name+'.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0,(config,name,p.stderr.decode(errors='replace')[-1000:])
  rows.append(dict(config=config,test=name,exitCode=0,executableSha256=hashlib.sha256((b/(name+'.exe')).read_bytes()).hexdigest()));(R/'cpu.json').write_text(json.dumps(rows,indent=2)+'\n')
drivers={'nvidia':R.parent/'20261124-020832-nr-normal-production-34180e/nv-active.json','intel':R.parent/'20261124-020035-nr-intel-motion-qualification-b71a94/intel-absolute.json'}
gpu=[]
for config,b in builds.items():
 for device,driver in drivers.items():
  env=dict(os.environ,VK_DRIVER_FILES=str(driver),VK_LAYER_PATH='D:/Tools/VulkanSDK/1.4.350.0/Bin',VK_LAYER_VALIDATE_SYNC='1')
  for case,ok,composed in [('positive',True,False),('history-response-moving',True,False),('history-response-moving-depth',False,False),('history-reset',False,True),('history-disoccluded',False,True)]:
   out=R/(config+'-'+device+'-'+case);args=[str(b/'AzureProjectedReflectionCameraGpuTests.exe'),str(b/'shaders/projected_reflection_trace.comp.spv'),str(out),case]
   args+=['--composition',str(b/'shaders')] if composed else [str(b/'shaders/projected_reflection_prepare.comp.spv')]
   p=subprocess.run(args,env=env,capture_output=True,timeout=60);(R/(out.name+'.log')).write_bytes(p.stdout+p.stderr);assert (out/'result.json').exists(),p.stderr.decode(errors='replace')[-1000:]
   d=json.loads((out/'result.json').read_bytes());assert p.returncode==(0 if ok else 1),(config,device,case,d);assert d['validationErrors']==d['liveBuffers']==d['liveImages']==0,d
   assert ('Intel' in d['device'])==(device=='intel'),d
   if not ok:assert d['redHits']==0,d
   gpu.append(dict(config=config,device=device,case=case,result=d));(R/'gpu.json').write_text(json.dumps(gpu,indent=2)+'\n')
 for device,driver in drivers.items():
  env=dict(os.environ,VK_DRIVER_FILES=str(driver),VK_LAYER_PATH='D:/Tools/VulkanSDK/1.4.350.0/Bin',VK_LAYER_VALIDATE_SYNC='1')
  out=R/(config+'-'+device+'-material-table')
  p=subprocess.run([str(b/'AzureMaterialDisplayViewGpuTests.exe'),str(b/'shaders'),str(out)],env=env,capture_output=True,timeout=180);(R/(out.name+'.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0,(config,device,p.stderr.decode(errors='replace')[-1400:])
print('PASS: fourteen CPU tests, twenty GPU reflection paths, four material-table checks')
