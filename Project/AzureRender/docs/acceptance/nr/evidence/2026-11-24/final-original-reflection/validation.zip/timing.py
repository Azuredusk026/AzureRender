import json,os,subprocess,hashlib,re,sys
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parent
B=R.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/msaa-release'
N=R.parent/'20261124-020832-nr-normal-production-34180e'
project=N/'without-map-isolated/project.azureproject';actions=N/'without-map-isolated/actions.json'
shader=B/'shaders/projected_reflection_trace.comp.spv';original=shader.read_bytes();baseline=(R.parent/'20261124-013842-nr-motion-history-production-0cccc9/baseline.spv').read_bytes()
env=dict(os.environ,VK_DRIVER_FILES=str(N/'nv-active.json'),VK_LAYER_PATH='D:/Tools/VulkanSDK/1.4.350.0/Bin',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
device=sys.argv[1] if len(sys.argv)>1 else 'nvidia'
prefix='' if device=='nvidia' else device+'-'
if device=='intel':env['VK_DRIVER_FILES']=str(R.parent/'20261124-020035-nr-intel-motion-qualification-b71a94/intel-absolute.json')
rows=[]
try:
 for name,binary in [('baseline',baseline),('candidate',original)]:
  shader.write_bytes(binary);report=R/(prefix+name+'-timing.json');runtime=R/(prefix+name+'-timing-runtime.json')
  args=[str(B/'AzurePlayer.exe'),'--project',str(project),'--width','320','--height','240','--fixed-frame-step','--smoke-frames','240','--qa-camera','scene','--qa-light','scene','--runtime-report',str(runtime),'--game-actions',str(actions),'--gpu-timing-output',str(report)]
  p=subprocess.run(args,env=env,cwd=R,capture_output=True,timeout=90);log=p.stdout+p.stderr;(R/(prefix+name+'-timing.log')).write_bytes(log);assert p.returncode==0,log[-1500:]
  assert not re.search(rb'VUID-|SYNC-HAZARD|\[validation warning\]|\[error\]',log,re.I);assert b'Allocator after unload: buffers=0 images=0' in log
  d=json.loads(report.read_bytes());cpu=np.asarray(d['cpuFrame']['workSamplesMs'],float);wall=np.asarray(d['cpuFrame']['totalSamplesMs'],float);assert len(cpu)>=180 and d['samples']>=180,d['samples']
  result=dict(name=name,device=d['gpu'],samples=d['samples'],cpuSamples=len(cpu),cpuWarmupFrames=30,cpuWorkP95Ms=float(np.percentile(cpu[30:],95)),cpuWallP95Ms=float(np.percentile(wall[30:],95)),gpuAverageMs=d['totalAverageMs'],gpuP95Ms=d['totalP95Ms'],shaderSha256=hashlib.sha256(binary).hexdigest(),programSha256=hashlib.sha256((B/'AzurePlayer.exe').read_bytes()).hexdigest())
  assert result['cpuWorkP95Ms']<=8 and result['gpuP95Ms']<=16.6,result
  rows.append(result);(R/(prefix+'timing-summary.json')).write_text(json.dumps(rows,indent=2)+'\n');print(result,flush=True)
finally:shader.write_bytes(original)
assert shader.read_bytes()==original
print('PASS: paired 240-frame original-scene CPU/GPU budgets and resource release')
