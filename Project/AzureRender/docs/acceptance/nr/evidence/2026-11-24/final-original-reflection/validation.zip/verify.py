from pathlib import Path
import json,re
import numpy as np
from PIL import Image
from test_screen_space_reflections_gpu import RIGHT,TARGET_Y,target_corners,project,polygon_mask,linear
R=Path(__file__).resolve().parent
read=lambda p:json.loads((R/p).read_bytes())
cpu=read('cpu.json');assert len(cpu)==14 and all(x['exitCode']==0 for x in cpu)
gpu=read('gpu.json');assert len(gpu)==20
for row in gpu:
 d=row['result'];assert d['validationErrors']==d['liveBuffers']==d['liveImages']==0
 assert ('Intel' in d['device'])==(row['device']=='intel')
 p=R/(row['config']+'-'+row['device']+'-'+row['case'])
 col=np.fromfile(p/'0.bin','<u4').reshape(240,320);conf=np.fromfile(p/'2.bin','u1').reshape(240,320)
 actual=int(((col[192:211,96:224]==0x380)&(conf[192:211,96:224]>=128)).sum());assert actual==d['redHits']
 if row['case'] in ('history-response-moving-depth','history-disoccluded'):assert not np.any(conf)
 if row['case']=='history-reset':
  a=np.fromfile(p/'3.bin','<f4').reshape(240,320,4)[192:211,96:224]
  assert np.count_nonzero((a[...,2]>.95)&(a[...,0]<.05)&(a[...,3]>=.5))==2432
for config in ('release','debug'):
 for device in ('nvidia','intel'):
  d=read(config+'-'+device+'-material-table/summary.json');assert d['status']=='passed' and len(d['checks'])==6
  assert all(x['maximumByteError']<=1 and x['interiorPixels']>0 for x in d['checks'])
angle=np.pi/4;c=np.array([RIGHT,TARGET_Y,0]);rot=np.array([[np.cos(angle),-np.sin(angle),0],[np.sin(angle),np.cos(angle),0],[0,0,1]])
corners=(target_corners(RIGHT)-c)@rot.T+c;corners[:,1]*=-1;mask=polygon_mask(project(corners),.6)
player=read('player.json');assert len(player)==8
def frames(p):return [np.asarray(Image.open(f).convert('RGB')) for f in sorted((p/'frames').glob('frame_*.png'))]
for config in ('release','debug'):
 for device in ('nvidia','intel'):
  first=frames(R/(config+'-'+device+'-first'));assert len(first)==12
  for suffix in ('first','reopen','same-project'):
   p=R/(config+'-'+device+'-'+suffix);images=frames(p);assert len(images)==12
   for a,b in zip(first,images):np.testing.assert_array_equal(a,b)
   for image in images[4:]:
    rgb=linear(image);assert np.maximum(rgb[...,0]-.5*(rgb[...,1]+rgb[...,2]),0)[mask].mean()>.003
   d=json.loads((p/'runtime.json').read_bytes());assert d['replayedActions']==2 and not d['routeFrames'][0]['doorOpen'] and d['routeFrames'][-1]['doorOpen']
   assert not d['scriptErrors'] and not d['presentationErrors']
   log=(p/'player.log').read_bytes();assert b'Allocator after unload: buffers=0 images=0' in log
   assert not re.search(rb'VUID-|SYNC-HAZARD|\[validation warning\]|\[error\]',log,re.I)
same=read('same-project.json');assert len(same)==4 and all(x['exactFrames']==12 for x in same)
for prefix in ('','intel-'):
 rows=read(prefix+'timing-summary.json');assert len(rows)==2
 for row in rows:
  data=read(prefix+row['name']+'-timing.json');work=np.asarray(data['cpuFrame']['workSamplesMs'],float)
  assert len(work)>=180 and data['samples']>=180
  p95=float(np.percentile(work[30:],95));assert abs(p95-row['cpuWorkP95Ms'])<1e-9
  assert 0<p95<=8 and 0<data['totalP95Ms']<=16.6
print('PASS: 14 CPU checks, 20 GPU paths, 24 material checks, 12 Player launches and paired budgets on both devices')
