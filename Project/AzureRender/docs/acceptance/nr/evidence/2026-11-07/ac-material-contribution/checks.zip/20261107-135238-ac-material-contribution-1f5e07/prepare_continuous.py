from pathlib import Path
import json
old=Path(__file__).resolve().parent;root=old.parents[2];out=max((root/'build/runs').glob('*-replay-continuity-check-*'),key=lambda p:p.name)
s=(old/'control.py').read_text().replace(str(old.name),out.name)
s=s.replace("env={k:v for k,v in snapshot().items() if k!='rawXml'};telemetry.append(dict(phase=phase,attempt=attempt,totalMs=total,environment=env));","telemetry.append(dict(phase=phase,attempt=attempt,totalMs=total));")
s=s.replace('time.sleep(2);','');(out/'control.py').write_text(s)
(out/'run_control.py').write_text((old/'run_control.py').read_text())
(out/'plan.md').write_text('''# 连续重放调度核对

首轮阴影控制在八次重放内未稳定。
逐次驱动查询及两秒等待形成额外空闲间隔。
本轮唯一修正是保持重放计数调用连续。
周期设备观察继续由所属工作线程记录。
三次连续 3% 及成对基线 5% 门槛保持有效。
本项为供电恢复后的一次有因复核。
再次失败后保存限制并推进独立实现。
诊断预留十六 MiB，重放上限三百秒。
''')
print(out)
