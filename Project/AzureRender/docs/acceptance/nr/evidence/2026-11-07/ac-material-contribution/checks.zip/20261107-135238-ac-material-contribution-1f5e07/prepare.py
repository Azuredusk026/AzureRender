from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2];prior=root/'build/runs/20261107-122133-material-contribution-cost-c567b5'
s=(prior/'control_warm.py').read_text();s=s.replace("out=root/'build/runs/20261107-122133-material-contribution-cost-c567b5'","out=root/'build/runs/20261107-135238-ac-material-contribution-1f5e07';prior=root/'build/runs/20261107-122133-material-contribution-cost-c567b5'")
s=s.replace("(out/'profile.json')","(prior/'profile.json')").replace("(out/'control-builds.json')","(prior/'control-builds.json')").replace("(out/kind/entry['programFile'])","(prior/kind/entry['programFile'])")
(out/'control.py').write_text(s)
