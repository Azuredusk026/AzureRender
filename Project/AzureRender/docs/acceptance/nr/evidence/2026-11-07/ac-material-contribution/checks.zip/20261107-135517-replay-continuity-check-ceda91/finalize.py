from pathlib import Path
import json,zipfile,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];e=root/'docs/acceptance/nr/evidence/2026-11-07/ac-material-contribution';e.mkdir(parents=True,exist_ok=True)
r=json.loads((out/'result.json').read_text());assert r['status']=='measured' and not r['environmentErrors'];r['qualifiedControls']=[x['control'] for x in r['summary'] if x['bracketStable']];r['outputChangingControls']=True;r['nativeBatchStarted']=False
prior=root/'build/runs/20261107-135238-ac-material-contribution-1f5e07'
with zipfile.ZipFile(e/'checks.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in [prior,out]:
  for p in folder.iterdir():
   if p.is_file():z.write(p,folder.name+'/'+p.name)
p=e/'checks.zip';r['archive']=dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest());(e/'results.json').write_text(json.dumps(r,indent=2));print(r['qualifiedControls'])
