from pathlib import Path
import subprocess,sys,json,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from artifact_budget import check
from gpu_environment import wait_and_record,RunEnvironmentMonitor,environment_errors
assert check(root/'build',run=out,planned=12*1024**2,diagnostic=True)['allowed']
environment=wait_and_record(out/'environment.json',timeout=60);source=inputs(root);products={str(p):digest(p) for p in [root/'build/ninja-msvc-release/AzurePlayer.exe',*sorted((root/'build/ninja-msvc-release/shaders').glob('*.spv'))]};si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with RunEnvironmentMonitor(environment,path=out/'environment.json'):
 with (out/'driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'control.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=300)
assert inputs(root)==source and all(digest(Path(path))==value for path,value in products.items())
report=json.loads((out/'control-state.json').read_text());result=dict(status=report['status'],error=report.get('error'),seconds=time.monotonic()-start,summary=report.get('summary'),environmentErrors=environment_errors(environment),sourceAndProductsUnchanged=True,replayProcessExitCode=p.returncode);(out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
