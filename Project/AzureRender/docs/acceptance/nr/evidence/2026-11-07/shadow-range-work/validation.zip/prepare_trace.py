from pathlib import Path
import json,subprocess,sys
root=Path.cwd();out=Path(__file__).resolve().parent;folder=out/'trace';sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
assert check(root/'build',run=out,planned=12*1024**2,diagnostic=True)['allowed']
folder.mkdir(exist_ok=True)
text=(root/'shaders/mesh.frag').read_text();text=text.replace('float sampleCascadeShadow(', 'vec4 azRangeTrace=vec4(-1.0);\nfloat sampleCascadeShadow(',1)
needle='    float minimumDepth=1,maximumDepth=0;';assert needle in text
text=text.replace(needle,'    azRangeTrace=vec4(tileLow,tileHigh);\n'+needle,1)
assert text.count('void main()')==1;text=text.replace('void main()','void azOriginalMain()',1)
text+='\nvoid main(){azOriginalMain();outputColor=azRangeTrace;}\n';(folder/'mesh.frag').write_text(text)
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());programs={p['output']:p for p in manifest['programs']}
rows=[]
for row in json.loads((out/'builds.json').read_text()):
 name=row['file'];p=programs[name];command=[manifest['compiler'],*[f'-D{d}' for d in p['defines']],f'-I{folder}',f'-I{root/"shaders"}',str(folder/'mesh.frag'),'-o',str(folder/name)]
 r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr
 rows.append(dict(file=name,command=command,exitCode=r.returncode,stdout=r.stdout,stderr=r.stderr))
(folder/'builds.json').write_text(json.dumps(rows,indent=2))
script=(out/'capture_ranges.py').read_text().replace("root/'build/runs/20261107-195033-shadow-range-work-f9476d'", "root/'build/runs/20261107-195033-shadow-range-work-f9476d/trace'")
script=script.replace("report['event']=event", "report['event']=event\n buffers=c.GetBuffers();bounds=next(b for b in buffers if str(b.resourceId)=='ResourceId::10291');raw=bytes(c.GetBufferData(bounds.resourceId,0,2097152));assert len(raw)==2097152;(out/'bounds.bin.zlib').write_bytes(zlib.compress(raw,6));report['bounds']=dict(resource=str(bounds.resourceId),rawBytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())")
script=script.replace('Functional counts in the final visible opaque snapshot. Counts exclude overwritten/occluded fragments and do not measure GPU time.','Last cascade rectangle for each final visible opaque snapshot pixel. Blend pixels retain only their final cascade. Bounds are captured at the same event; no GPU timing.')
(folder/'capture_ranges.py').write_text(script)
runner=(out/'run.py').read_text().replace("out=Path(__file__).resolve().parent", "run=Path(__file__).resolve().parent;out=run/'trace'")
runner=runner.replace("run=out,planned=20", "run=run,planned=20")
(out/'run_trace.py').write_text(runner)
print('Prepared four trace shaders and exact captured bounds export')
