from pathlib import Path
import sys,json,subprocess,re,os,zlib,hashlib,numpy as np
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
assert check(root/'build',run=out,planned=36*1024**2,diagnostic=True)['allowed']
trace=out/'trace';report=json.loads((trace/'inspection.json').read_text());assert report['status']=='inspected' and report['restoredTargetIdentical']
raw=zlib.decompress((trace/'counts.bin.zlib').read_bytes());p=np.frombuffer(raw,dtype='<f2').astype(np.float32).reshape(-1,4)
valid=np.isfinite(p).all(axis=1)&(p>=0).all(axis=1)&(p<512).all(axis=1)&(p==np.floor(p)).all(axis=1)&(p[:,:2]<=p[:,2:]).all(axis=1)
queries=p[valid].astype('<u4');assert len(queries)==json.loads((out/'counts-summary.json').read_text())['activeShadowPixels']
queries.tofile(out/'queries.bin');raw=zlib.decompress((trace/'bounds.bin.zlib').read_bytes());(out/'bounds.bin').write_bytes(raw)
extent=queries[:,2:]-queries[:,:2]+1;size=np.where(extent.min(axis=1)>=4,4,np.where(extent.min(axis=1)>=2,2,1)).astype(np.uint32)
base=int(np.prod(extent,axis=1).sum());hier=int(np.prod((extent+size[:,None]-1)//size[:,None],axis=1).sum())
summary=dict(queries=len(queries),rawRangeReads=base,hierarchyRangeReads=hier,rangeReadReduction=1-hier/base,boundsSha256=hashlib.sha256(raw).hexdigest(),traceSha256=hashlib.sha256(queries.tobytes()).hexdigest(),rectangleHistogram={f'{w}x{h}':int(n) for (w,h),n in zip(*np.unique(extent,axis=0,return_counts=True))},omittedBlendFirstCascadeCalls=json.loads((out/'counts-summary.json').read_text())['cascadeCalls']-len(queries))
(out/'range-inputs.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
compiler='D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe';validator='D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe'
command=[compiler,str(out/'range.comp'),'-o',str(out/'range.spv')];subprocess.run(command,check=True,capture_output=True);subprocess.run([validator,'--target-env','vulkan1.0',str(out/'range.spv')],check=True,capture_output=True)
env=dict(os.environ);env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9');bat=['cmd','/d','/c',str(root/'tools/msvc_env.bat')]
flags=['cl','/nologo','/O2','/MD','/EHsc','/std:c++17','/utf-8','/DNDEBUG','/DNOMINMAX','/I'+str(root/'src'),'/I'+str(root/'tests'),'/I'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'),'/ID:/Tools/VulkanSDK/1.4.350.0/Include','/c']
with (out/'range-compile.log').open('wb') as log:r=subprocess.run(bat+flags+[str(out/'range.cpp'),'/Fo'+str(out/'range.obj')],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(out/'range-compile.log').read_text(errors='replace')[-3500:]
response=(root/'build/runs/20261107-161237-cpu-asset-load-stages-3ff597/link.rsp').read_text();response=re.sub(r'^"[^\"]+profile\.obj"',lambda m:'"'+str(out/'range.obj')+'"',response)
response=re.sub(r'/(out|implib|pdb|MAP):"[^\"]+"',lambda m:'/'+m[1]+':"'+str(out/('range.'+{'out':'exe','implib':'lib','pdb':'pdb','MAP':'map'}[m[1]]))+'"',response)
(out/'range-link.rsp').write_text(response)
with (out/'range-link.log').open('wb') as log:r=subprocess.run(bat+['link','@'+str(out/'range-link.rsp')],cwd=root/'build/ninja-msvc-release',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0,(out/'range-link.log').read_text(errors='replace')[-3500:]
print('Private exact range fixture compiled',flush=True)
