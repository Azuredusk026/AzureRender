#include "support/VulkanComputeFixture.hpp"
#include "resources/BinaryFile.hpp"
#include <nlohmann/json.hpp>
#include <fstream>
#include <array>
#include <algorithm>
#include <cstring>
#include <numeric>
#include <cmath>
using namespace azurerender;
using Pair=std::array<float,2>;
using Query=std::array<std::uint32_t,4>;
struct Parameters{std::uint32_t width,count,mode;};
template<class T>std::vector<T> read(const char* path){auto bytes=readBinaryFile(path);if(bytes.size()%sizeof(T))throw std::runtime_error("Invalid input stride");std::vector<T> value(bytes.size()/sizeof(T));std::memcpy(value.data(),bytes.data(),bytes.size());return value;}
int main(int argc,char** argv)try{
 if(argc!=5)throw std::invalid_argument("Expected shader, bounds, query trace and result");
 const auto source=read<Pair>(argv[2]);auto trace=read<Query>(argv[3]);constexpr unsigned width=512;
 if(source.size()!=width*width)throw std::invalid_argument("Expected captured 512-square bounds");
 for(const auto& pair:source)if(!std::isfinite(pair[0])||!std::isfinite(pair[1])||pair[0]<0||pair[1]>1||pair[0]>pair[1])throw std::invalid_argument("Invalid captured bounds");
 const auto capturedQueries=trace.size();
 // All widths/heights at atlas corners and power-of-two boundaries supplement the actual trace.
 for(unsigned h=1;h<=8;++h)for(unsigned w=1;w<=8;++w)for(unsigned x:{0u,1u,3u,7u,255u,width-w})for(unsigned y:{0u,1u,3u,7u,255u,width-h})trace.push_back({x,y,x+w-1,y+h-1});
 std::vector<Pair> expected;expected.reserve(trace.size());std::uint64_t baseReads=0,hierarchyReads=0;
 for(const auto& query:trace){
  if(query[0]>query[2]||query[1]>query[3]||query[2]>=width||query[3]>=width)throw std::invalid_argument("Query is outside captured bounds");
  Pair value{1,0};
  for(unsigned y=query[1];y<=query[3];++y)for(unsigned x=query[0];x<=query[2];++x){auto v=source[y*width+x];value[0]=std::min(value[0],v[0]);value[1]=std::max(value[1],v[1]);}
  expected.push_back(value);auto w=query[2]-query[0]+1,h=query[3]-query[1]+1;unsigned size=std::min(w,h)>=4?4:std::min(w,h)>=2?2:1;
  baseReads+=w*h;hierarchyReads+=((w+size-1)/size)*((h+size-1)/size);
 }
 test::VulkanComputeFixture host;auto& backend=*host.backend;
 auto bounds=host.allocator.createBuffer(source.size()*sizeof(Pair)*3,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
 auto input=host.allocator.createBuffer(trace.size()*sizeof(Query),VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
 auto output=host.allocator.createBuffer(trace.size()*sizeof(Pair),VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
 std::memset(bounds.mapped,0,static_cast<std::size_t>(bounds.size));std::memcpy(bounds.mapped,source.data(),source.size()*sizeof(Pair));std::memcpy(input.mapped,trace.data(),input.size);
 host.allocator.flush(bounds,0,bounds.size);host.allocator.flush(input,0,input.size);
 VkDescriptorSetLayout setLayout{};VkDescriptorPool pool{};VkPipelineLayout layout{};VkPipeline pipeline{};VkQueryPool timer{};
 auto cleanup=std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*){
  if(timer)vkDestroyQueryPool(host.device,timer,nullptr);if(pipeline)backend.destroyPipeline(pipeline);if(layout)backend.destroyPipelineLayout(layout);if(pool)backend.destroyDescriptorPool(pool);if(setLayout)backend.destroyDescriptorSetLayout(setLayout);
  host.allocator.destroyBuffer(output);host.allocator.destroyBuffer(input);host.allocator.destroyBuffer(bounds);
 });
 setLayout=backend.createDescriptorSetLayout({{0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},{1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},{2,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT}});
 rhi::DescriptorPoolDesc descriptorPool;descriptorPool.sizes={{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,3}};descriptorPool.maxSets=1;pool=backend.createDescriptorPool(descriptorPool);
 auto set=backend.allocateDescriptorSets(pool,setLayout,1).front();
 backend.writeDescriptorBuffer({set,0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,bounds.buffer,bounds.size});backend.writeDescriptorBuffer({set,1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,input.buffer,input.size});backend.writeDescriptorBuffer({set,2,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,output.buffer,output.size});
 rhi::PushConstantRangeDesc push{VK_SHADER_STAGE_COMPUTE_BIT,sizeof(Parameters)};layout=backend.createPipelineLayout(setLayout,&push);
 auto shader=backend.createShaderModule(readBinaryFile(argv[1]));pipeline=backend.createComputePipeline({shader,layout});backend.destroyShaderModule(shader);
 VkQueryPoolCreateInfo queryInfo{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};queryInfo.queryType=VK_QUERY_TYPE_TIMESTAMP;queryInfo.queryCount=32;test::vkRequire(vkCreateQueryPool(host.device,&queryInfo,nullptr,&timer),"vkCreateQueryPool");
 auto sample=[&](bool hierarchical){
  host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer native){
   commands.bufferBarrier({bounds.buffer,0,bounds.size,VK_PIPELINE_STAGE_HOST_BIT|VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_WRITE_BIT|VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});
   commands.bufferBarrier({input.buffer,0,input.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT});
   commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_HOST_BIT|VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});
   vkCmdResetQueryPool(native,timer,0,32);commands.bindComputePipeline(pipeline);commands.bindComputeDescriptorSet(layout,set);
   // Identical continuous baseline warmup precedes every measured phase.
   Parameters warm{width,static_cast<unsigned>(trace.size()),2u};commands.pushConstants(layout,VK_SHADER_STAGE_COMPUTE_BIT,0,&warm,sizeof(warm));
   for(unsigned iteration=0;iteration<64;++iteration){commands.dispatch((warm.count+63)/64,1,1);commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});}
   for(unsigned repeat=0;repeat<8;++repeat){
   vkCmdWriteTimestamp(native,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,timer,repeat*4);
   for(unsigned level=0;level<2;++level){
    if(hierarchical){Parameters p{width,static_cast<unsigned>(trace.size()),level};commands.pushConstants(layout,VK_SHADER_STAGE_COMPUTE_BIT,0,&p,sizeof(p));commands.dispatch((width*width+63)/64,1,1);
     commands.bufferBarrier({bounds.buffer,0,bounds.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});}
    vkCmdWriteTimestamp(native,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,timer,repeat*4+level+1);
   }
   Parameters p{width,static_cast<unsigned>(trace.size()),hierarchical?3u:2u};commands.pushConstants(layout,VK_SHADER_STAGE_COMPUTE_BIT,0,&p,sizeof(p));commands.dispatch((p.count+63)/64,1,1);
   vkCmdWriteTimestamp(native,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,timer,repeat*4+3);
   commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});
   }
   commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
  });
  host.allocator.invalidate(output,0,output.size);if(std::memcmp(expected.data(),output.mapped,output.size)!=0)throw std::runtime_error("GPU range result differs from independent exact CPU rectangle reduction");
  std::uint64_t timestamps[32]{};test::vkRequire(vkGetQueryPoolResults(host.device,timer,0,32,sizeof(timestamps),timestamps,sizeof(std::uint64_t),VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT),"vkGetQueryPoolResults");
  const auto mask=host.timestampBits==64?~std::uint64_t(0):(std::uint64_t(1)<<host.timestampBits)-1;
  auto elapsed=[&](unsigned a,unsigned b){return double((timestamps[b]-timestamps[a])&mask)*host.properties.limits.timestampPeriod/1e6;};
  nlohmann::json values=nlohmann::json::array();
  for(unsigned repeat=0;repeat<8;++repeat){auto i=repeat*4;values.push_back({{"repeat",repeat},{"hierarchical",hierarchical},{"totalMs",elapsed(i,i+3)},{"buildMs",elapsed(i,i+2)},{"queryMs",elapsed(i+2,i+3)}});}
  return values;
 };
 nlohmann::json samples=nlohmann::json::array();
 for(unsigned phase=0;phase<3;++phase)for(auto result:sample(phase==1)){result["phase"]=phase;samples.push_back(result);}
 if(host.errors.load())throw std::runtime_error("Vulkan validation errors");
 nlohmann::json result={{"status","passed"},{"device",host.properties.deviceName},{"capturedQueries",capturedQueries},{"boundaryQueries",trace.size()-capturedQueries},{"allResultsBitExact",true},{"baseRangeReads",baseReads},{"hierarchyRangeReads",hierarchyReads},{"extraBoundsBytes",source.size()*sizeof(Pair)*2},{"validationErrors",host.errors.load()},{"samples",samples},{"scope","Standalone compute query fixture with actual captured bounds and last visible cascade rectangle; includes hierarchy build cost, excludes rasterization, overdraw, blend-first cascades and native frame acceptance."}};
 cleanup.reset();if(host.allocator.statistics().liveBuffers||host.allocator.statistics().liveImages)throw std::runtime_error("Private range fixture leaked resources");
 result["liveBuffersAfterRelease"]=0;std::ofstream(argv[4])<<result.dump(2);std::cout<<result.dump(2)<<std::endl;return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<std::endl;return 1;}
