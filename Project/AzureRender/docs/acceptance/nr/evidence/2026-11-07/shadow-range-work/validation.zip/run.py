from pathlib import Path
import sys,json,subprocess,time
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs
assert check(root/'build',run=out,planned=20*1024**2,diagnostic=True)['allowed']
source=inputs(root)
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
start=time.monotonic()
with (out/'driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'capture_ranges.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=180)
assert source==inputs(root);result=json.loads((out/'inspection.json').read_text());result.update(processExitCode=p.returncode,seconds=time.monotonic()-start,productionSourceUnchanged=True)
(out/'inspection.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
