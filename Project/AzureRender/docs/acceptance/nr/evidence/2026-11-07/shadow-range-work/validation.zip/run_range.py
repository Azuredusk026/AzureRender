from pathlib import Path
import json,subprocess,os,sys,time
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
from gpu_environment import wait_and_record,RunEnvironmentMonitor,environment_errors
assert check(root/'build',run=out,planned=3*1024**2,diagnostic=True)['allowed']
source=inputs(root);environment=wait_and_record(out/'range-environment.json',timeout=30)
results=[]
with RunEnvironmentMonitor(environment,path=out/'range-environment.json'):
 for name,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  env=dict(os.environ);env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH'];env['VK_LOADER_DRIVERS_SELECT']=driver
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
  command=[str(out/'range.exe'),str(out/'range.spv'),str(out/'bounds.bin'),str(out/'queries.bin'),str(out/(name+'-range.json'))]
  (out/(name+'-range-command.json')).write_text(json.dumps(command,indent=2));started=time.monotonic()
  with (out/(name+'-range.log')).open('wb') as log:p=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  assert p.returncode==0,(out/(name+'-range.log')).read_text(errors='replace')[-3000:]
  result=json.loads((out/(name+'-range.json')).read_text());result['seconds']=time.monotonic()-started
  phases=[]
  for phase in range(3):
   samples=[r for r in result['samples'] if r['phase']==phase and r['repeat']>=4]
   phases.append(dict(phase=phase,totalMs=sum(r['totalMs'] for r in samples)/len(samples),queryMs=sum(r['queryMs'] for r in samples)/len(samples),buildMs=sum(r['buildMs'] for r in samples)/len(samples),sampleRangeRatio=max(r['totalMs'] for r in samples)/min(r['totalMs'] for r in samples)))
  result['phases']=phases;result['baselineBracketRatio']=max(phases[0]['totalMs'],phases[2]['totalMs'])/min(phases[0]['totalMs'],phases[2]['totalMs'])
  mean=(phases[0]['totalMs']+phases[2]['totalMs'])/2
  result['descriptiveTotalReduction']=1-phases[1]['totalMs']/mean
  result['timingSeriesStable']=result['baselineBracketRatio']<=1.05 and all(r['sampleRangeRatio']<=1.03 for r in phases)
  result['timingScope']='Standalone compute cost at observed device state; no 80W or native-frame qualification. Hierarchy rebuild included once per full visible trace.'
  (out/(name+'-range.json')).write_text(json.dumps(result,indent=2));results.append(result)
  print(json.dumps({k:result[k] for k in ['device','allResultsBitExact','phases','baselineBracketRatio','descriptiveTotalReduction','timingSeriesStable','validationErrors']}),flush=True)
assert source==inputs(root)
result=dict(status='functionally-passed',devices=results,sourceInputsUnchanged=True,environmentErrors=environment_errors(environment),executableSha256=digest(out/'range.exe'),shaderSha256=digest(out/'range.spv'))
(out/'range-results.json').write_text(json.dumps(result,indent=2));print('Completed both private device controls; production untouched',flush=True)
