from pathlib import Path
import json,sys,subprocess
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs
assert check(root/'build',run=out,planned=24*1024**2,diagnostic=True)['allowed']
(out/'source-inputs.json').write_text(json.dumps(inputs(root),indent=2))
text=(root/'shaders/mesh.frag').read_text()
text=text.replace('float sampleCascadeShadow(', 'uint azRangeReads=0u,azQuadReads=0u,azCalls=0u,azEarly=0u;\nfloat sampleCascadeShadow(',1)
text=text.replace('    ivec2 extent=textureSize(AZ_TEX_SHADOW,0),tile=', '    ++azCalls;\n    ivec2 extent=textureSize(AZ_TEX_SHADOW,0),tile=',1)
text=text.replace('        vec2 range=shadowBounds.values[', '        ++azRangeReads;vec2 range=shadowBounds.values[',1)
text=text.replace('if(receiver+planeMargin<=minimumDepth)return 1.0;', 'if(receiver+planeMargin<=minimumDepth){++azEarly;return 1.0;}',1)
text=text.replace('if(receiver-planeMargin>maximumDepth)return 0.0;', 'if(receiver-planeMargin>maximumDepth){++azEarly;return 0.0;}',1)
text=text.replace('        vec4 weights=shadowBlockerGridWeights(', '        ++azQuadReads;vec4 weights=shadowBlockerGridWeights(',1)
text=text.replace('        if(weight<=0)continue;', '        if(weight<=0)continue;++azQuadReads;',1)
assert text.count('void main()')==1
text=text.replace('void main()', 'void azOriginalMain()',1)
text+='\nvoid main(){azOriginalMain();outputColor=vec4(float(azRangeReads),float(azQuadReads),float(azCalls*4u+azEarly),1.0);}\n'
(out/'mesh.frag').write_text(text)
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());programs={p['output']:p for p in manifest['programs']}
prior=root/'build/runs/20261107-122133-material-contribution-cost-c567b5'
names=sorted({r['file'] for r in json.loads((prior/'control-builds.json').read_text()) if r['file'].startswith('character_snapshot')})
rows=[]
for name in names:
 p=programs[name];command=[manifest['compiler'],*[f'-D{d}' for d in p['defines']],f'-I{out}',f'-I{root/"shaders"}',str(out/'mesh.frag'),'-o',str(out/name)]
 r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr
 rows.append(dict(file=name,command=command,exitCode=r.returncode,stdout=r.stdout,stderr=r.stderr))
(out/'builds.json').write_text(json.dumps(rows,indent=2));print('Compiled',len(rows),'private operation-count programs')
