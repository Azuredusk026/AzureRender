from pathlib import Path
import json,sys,shutil,zipfile,subprocess,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
old=root/'build/runs/20261107-070333-surface-radiance-reuse-bdfb96';baseline=old/'baseline/shaders';candidate=old/'candidate-programs'
files=list(baseline.glob('*.spv'))+list(candidate.glob('*.spv'));assert len(files)==710
planned=sum(f.stat().st_size for f in files)+32*1024**2
budget=check(root/'build',run=out,planned=planned);assert budget['allowed'],budget
(out/'budget.json').write_text(json.dumps(budget,indent=2))
source=inputs(root);(out/'source-inputs.json').write_text(json.dumps(source,indent=2))
assert digest(old/'isolated-candidate.exe')=='e894558008aca8bbbb81f4c55a5a1bfef65d4be2b7fc2a1cb01e86dc8c5e6037'
assert all(digest(f)==digest(root/'build/ninja-msvc-release/shaders'/f.name) for f in baseline.glob('*.spv'))
runtime=out/'runtime';shaders=runtime/'shaders';shaders.mkdir(parents=True)
for f in files:shutil.copyfile(f,shaders/f.name)
folder=out/'source';folder.mkdir();z=zipfile.ZipFile(root/'docs/acceptance/nr/evidence/2026-11-07/surface-radiance-reuse/measurements.zip')
for name in z.namelist():
 if name.startswith('candidate-source/shaders/'):(folder/Path(name).name).write_bytes(z.read(name))
helper=folder/'surface_radiance.glsl';text=helper.read_text()
text=text.replace('vec4 a=vec4(beauty,ambientSpecular.x),b=vec4(response,ambientSpecular.y),c=vec4(radiance,ambientSpecular.z);','vec4 a=vec4(beauty-ambientSpecular,beauty.x),b=vec4(response,beauty.y),c=vec4(radiance,beauty.z);')
text=text.replace('    vec3 beauty=a.rgb;','    vec3 beauty=vec3(a.a,b.a,c.a);')
assert text!=helper.read_text();helper.write_text(text)
helper=folder/'surface_radiance_identity.glsl';text=helper.read_text();text=text.replace('source.y+triangle*3u,materialIndex);','source.y+triangle*3u,materialIndex|0x80000000u);')
text=text.replace('    return a.rgb+(blended-vec3(a.a,b.a,c.a));','    return reflection.a==0.0?vec3(a.a,b.a,c.a):a.rgb+blended;')
assert text!=helper.read_text();helper.write_text(text)
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());programs={p['output']:p for p in manifest['programs']};builds=[]
for f in sorted(candidate.glob('*.frag.spv')):
 if f.name.startswith('surface_radiance_'):continue
 base=f.name.replace('_radiance.frag.spv','.frag.spv');program=programs[base]
 command=[manifest['compiler'],'--target-env=vulkan1.3',*[f'-D{d}' for d in program['defines']],'-DAZURE_SURFACE_RADIANCE_REUSE=1',f'-I{folder}',f'-I{root/"shaders"}',str(folder/'mesh.frag'),'-o',str(shaders/f.name)]
 r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr
 validation=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.3',str(shaders/f.name)];v=subprocess.run(validation,capture_output=True,text=True);assert v.returncode==0,v.stderr
 builds.append(dict(file=f.name,baselineProgram=base,command=command,validationCommand=validation,sha256=digest(shaders/f.name)))
(out/'builds.json').write_text(json.dumps(builds,indent=2))
assert len(builds)==32 and source==inputs(root)
(out/'products.json').write_text(json.dumps({str(p):digest(p) for p in shaders.glob('*.spv')},indent=2))
print(json.dumps(dict(status='prepared',recompiledPrograms=len(builds),preservedBaselinePrograms=663,shaderBytes=sum(p.stat().st_size for p in shaders.iterdir()),player=str(old/'isolated-candidate.exe'),productionSourceUnchanged=True)),flush=True)
