from pathlib import Path
import json,sys,zipfile,io,hashlib,subprocess
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
source=inputs(root);assert source==json.loads((out/'source-inputs.json').read_text())
image=json.loads((out/'image/results.json').read_text());assert image['status']=='failed' and image['productsUnchanged'] and image['allMountedProjectBytesUnchanged']
products=json.loads((out/'products.json').read_text());assert all(digest(Path(p))==h for p,h in products.items())
old=root/'build/runs/20261107-070333-surface-radiance-reuse-bdfb96';baseline=json.loads((old/'baseline-products.json').read_text())['programs'];assert len(baseline)==663
baselineBuffer=io.BytesIO()
with zipfile.ZipFile(baselineBuffer,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,h in sorted(baseline.items()):
  p=out/'runtime/shaders'/name;assert digest(p)==h;z.write(p,'shaders/'+name)
baselineBytes=baselineBuffer.getvalue();baselineArchive=root/'build/archives/shader-baseline-e6c5b3e.zip';assert not baselineArchive.exists()
candidateBuffer=io.BytesIO()
with zipfile.ZipFile(candidateBuffer,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in out.rglob('*'):
  if not p.is_file() or '__pycache__' in p.parts:continue
  if out/'runtime' in p.parents:continue
  z.write(p,p.relative_to(out).as_posix())
 for p in (out/'runtime/shaders').glob('*.spv'):
  if p.name not in baseline:z.write(p,'runtime/shaders/'+p.name)
 z.write(old/'isolated-candidate.exe','runtime/isolated-candidate.exe')
 z.write(old/'candidate-record.json','upstream/candidate-record.json')
 z.write(root/'docs/acceptance/nr/evidence/2026-11-07/surface-radiance-reuse/manifest.json','upstream/manifest.json')
candidateBytes=candidateBuffer.getvalue()
budget=check(root/'build',run=out,planned=len(baselineBytes)+len(candidateBytes)+1024**2);assert budget['allowed'],budget
baselineArchive.write_bytes(baselineBytes);dest=root/'docs/acceptance/nr/evidence/2026-11-07/radiance-recomposition';dest.mkdir(parents=True,exist_ok=True)
(dest/'validation.zip').write_bytes(candidateBytes)
recovery=[]
with zipfile.ZipFile(baselineArchive) as base,zipfile.ZipFile(dest/'validation.zip') as candidate:
 for path,h in products.items():
  p=Path(path)
  if p.name in baseline:archive=baselineArchive;member='shaders/'+p.name;data=base.read(member)
  else:archive=dest/'validation.zip';member='runtime/shaders/'+p.name;data=candidate.read(member)
  assert hashlib.sha256(data).hexdigest()==h
  recovery.append(dict(path=str(p),sha256=h,archive=str(archive),member=member,bytes=len(data)))
h=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--','src','tests','tools/endfield_native','tools/test_native_character_surfaces.py','docs/acceptance/p5'],stderr=subprocess.DEVNULL)).hexdigest();assert h=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
result=dict(status='isolated-native-zero-pixel-gate-failed',productionIntegrated=False,image=image,prototype='Non-reflective subtotal plus original beauty in alpha channels; representation tag in material identity high bit.',rootCause='Unconfirmed: changed representation does not restore the original floating-point output; no further native batch or timing launched.',upstreamArchiveSha256=digest(root/'docs/acceptance/nr/evidence/2026-11-07/surface-radiance-reuse/measurements.zip'),sourceInputs=source,protectedDiffSha256=h,sourceAndMainProductsUnchanged=True,sharedShaderArchive=dict(path=str(baselineArchive),bytes=len(baselineBytes),sha256=digest(baselineArchive),programs=663),archive=dict(path='validation.zip',bytes=len(candidateBytes),sha256=digest(dest/'validation.zip')),temporaryFixtureRecovery=dict(target=str(out/'runtime'),files=len(recovery),allBytesVerified=True),limitations=['The retained candidate executable is based on 521e002, while current production remains e6c5b3e runtime inputs.','All 663 baseline shader bytes match current production; this is an isolated compatibility experiment, not a production integration result.','Four-frame zero-pixel gate failed; one-byte differences are not accepted as passing.','No causal GPU frame gain, original 80W qualification, long run or overall visual acceptance is claimed.'])
(out/'fixture-recovery.json').write_text(json.dumps(recovery,indent=2));(out/'results.json').write_text(json.dumps(result,indent=2));(dest/'results.json').write_text(json.dumps(result,indent=2))
receipt=dict(status='verified-not-pruned',target=str(out/'runtime'),files=len(recovery),bytes=sum(r['bytes'] for r in recovery),baselineArchive=result['sharedShaderArchive'],candidateArchive=dict(path=str(dest/'validation.zip'),**{k:v for k,v in result['archive'].items() if k!='path'}),sourceAndMainProductsUnchanged=True)
(root/'build/maintenance/20261107-radiance-fixture-recovery.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({'status':result['status'],'sharedShaderArchive':result['sharedShaderArchive'],'archive':result['archive'],'verifiedTemporaryBytes':receipt['bytes']}),flush=True)
