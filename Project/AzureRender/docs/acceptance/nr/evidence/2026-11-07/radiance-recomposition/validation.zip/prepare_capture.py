from pathlib import Path
import sys,json
root=Path.cwd();out=Path(__file__).resolve().parent;old=root/'build/runs/20261107-070333-surface-radiance-reuse-bdfb96';sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
assert check(root/'build',run=out,planned=32*1024**2)['allowed']
text=(old/'capture.py').read_text()
text=text.replace("products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')", "products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe');products.update(json.loads((out.parent/'products.json').read_text()));products[str(root/'build/runs/20261107-070333-surface-radiance-reuse-bdfb96/isolated-candidate.exe')]='e894558008aca8bbbb81f4c55a5a1bfef65d4be2b7fc2a1cb01e86dc8c5e6037'")
text=text.replace("project=Path(command[command.index('--project')+1]);", "command[0]=str(root/'build/runs/20261107-070333-surface-radiance-reuse-bdfb96/isolated-candidate.exe');command.extend(['--resource-root',str(out.parent/'runtime')]);project=Path(command[command.index('--project')+1]);")
text=text.replace("out.mkdir()", "out.mkdir(exist_ok=True);assert not any(out.iterdir()),'Capture output must be empty'")
text=text.replace("env=os.environ.copy();", "env=os.environ.copy();env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH'];")
text=text.replace("json.loads((out.parent/'baseline-products.json').read_text())", "json.loads((root/'build/runs/20261107-070333-surface-radiance-reuse-bdfb96/baseline-products.json').read_text())")
text=text.replace("new_programs={name:value for name,value in shader_after.items() if name not in shader_before}", "private_programs={p.name:digest(p) for p in (out.parent/'runtime/shaders').glob('*.spv')};new_programs={name:value for name,value in private_programs.items() if name not in shader_before}")
text=text.replace("'521e002-with-surface-radiance-reuse'", "'521e002-isolated-runtime-with-radiance-recomposition'")
text=text.replace("'Single-frame FP32 surface radiance with exact geometry identity and quad-uniform fallback; original four frozen native RGB references, zero-pixel gate unchanged; full user visual acceptance remains failed'", "'Isolated saved runtime and updated producer/consumer payload; current production code and products frozen; original four RGB references remain zero-pixel gate; full visual/performance acceptance remains open'")
(out/'capture.py').write_text(text)
print('Prepared one frozen native four-frame batch using retained isolated runtime',flush=True)
