from pathlib import Path
import renderdoc as rd
import json,zlib,hashlib,traceback,sys
out=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261107-191143-hair-gradient-region-08b1f9')
root=out.parents[2];capture=root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc'
result=dict(status='starting',capture=str(capture),snapshots=[])
def save():(out/'export-state.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
def walk(actions):
 for a in actions:
    if a.flags&rd.ActionFlags.Drawcall and not a.children:yield a
    yield from walk(a.children)
cap=None;c=None
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(capture),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 textures={str(t.resourceId):t for t in c.GetTextures()}
 c.SetFrameEvent(493,True);p=c.GetPipelineState();shader=p.GetShader(rd.ShaderStage.Pixel);reflection=p.GetShaderReflection(rd.ShaderStage.Pixel);code=bytes(reflection.rawBytes);(out/'original-hair.spv').write_bytes(code);result['shaderSha256']=hashlib.sha256(code).hexdigest()
 def snapshot(name,event):
    c.SetFrameEvent(event,True);targets=c.GetPipelineState().GetOutputTargets();assert targets
    target=targets[0].resource;t=textures[str(target)];raw=bytes(c.GetTextureData(target,rd.Subresource()))
    bytesPerPixel=len(raw)//(t.width*t.height);assert len(raw)==t.width*t.height*bytesPerPixel
    box=[1140,130,1430,440];crop=b''.join(raw[(y*t.width+box[0])*bytesPerPixel:(y*t.width+box[2])*bytesPerPixel] for y in range(box[1],box[3]))
    (out/(name+'.zlib')).write_bytes(zlib.compress(crop,9));result['snapshots'].append(dict(name=name,event=event,resource=str(target),format=str(t.format.Name()),extent=[t.width,t.height],box=box,bytesPerPixel=bytesPerPixel,cropSha256=hashlib.sha256(crop).hexdigest()));save()
 snapshot('original-hdr',493)
 draws=list(walk(c.GetRootActions()));last=draws[-1];result['lastDrawEvent']=int(last.eventId)
 snapshot('original-final',int(last.eventId));result['status']='exported';save()
except Exception:result.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if result['status']=='exported' else 1)
