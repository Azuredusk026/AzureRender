from pathlib import Path
import re,json,subprocess,sys
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import digest,inputs
assert check(root/'build',run=out,planned=8*1024**2,diagnostic=True)['allowed']
source=(out/'original-hair.spvasm').read_text()
definitions={m[1]:m[2] for line in source.splitlines() if (m:=re.match(r'\s*(%\S+) = (.+)$',line))}
bindings={m[1]:int(m[2]) for m in re.finditer(r'OpDecorate (%\S+) Binding (\d+)',source)}
selected={1,2,3,5,6,7,8,12};rows=[]
for mode in ['roundtrip','coarse','fine','flipped-quad']:
    text=source;count=0;used=[]
    if mode!='roundtrip':
        lines=[]
        for line in source.splitlines():
            match=re.fullmatch(r'\s*(%\S+) = OpImageSampleImplicitLod (%\S+) (%\S+) (%\S+)',line)
            if not match:lines.append(line);continue
            result,output,sampler,coordinate=match.groups()
            load=re.fullmatch(r'OpLoad %\S+ (%\S+)',definitions.get(sampler,''))
            if not load or bindings.get(load[1]) not in selected:lines.append(line);continue
            binding=bindings[load[1]];used.append(binding);count+=1;prefix='%hair_grad_'+str(count)
            suffix='Coarse' if mode=='coarse' else 'Fine'
            lines += [f'{prefix}_dx = OpDPdx{suffix} %v2float {coordinate}',f'{prefix}_dy = OpDPdy{suffix} %v2float {coordinate}']
            dx,dy=prefix+'_dx',prefix+'_dy'
            if mode=='flipped-quad':
                lines += [f'{prefix}_source_dx = OpGroupNonUniformQuadBroadcast %v2float %uint_3 {dx} %uint_2',f'{prefix}_source_dy = OpGroupNonUniformQuadBroadcast %v2float %uint_3 {dy} %uint_0']
                dx,dy=prefix+'_source_dx',prefix+'_source_dy'
            lines.append(f'{result} = OpImageSampleExplicitLod {output} {sampler} {coordinate} Grad {dx} {dy}')
        assert count>=7,(mode,count);text='\n'.join(lines)+'\n';text=text.replace('OpCapability Shader','OpCapability Shader\n               OpCapability DerivativeControl',1)
        if mode=='flipped-quad':text=text.replace('OpCapability Shader','OpCapability Shader\n               OpCapability GroupNonUniform\n               OpCapability GroupNonUniformQuad',1)
    asm=out/(mode+'.spvasm');spv=out/(mode+'.spv');asm.write_text(text,encoding='utf-8');target='vulkan1.1' if mode=='flipped-quad' else 'vulkan1.0'
    command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-as.exe','--target-env',target,str(asm),'-o',str(spv)]
    p=subprocess.run(command,capture_output=True,text=True,timeout=30);assert p.returncode==0,p.stderr
    p=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env',target,str(spv)],capture_output=True,text=True,timeout=30);assert p.returncode==0,p.stderr
    rows.append(dict(name=mode,file=spv.name,sha256=digest(spv),replacedOperations=count,bindings=used,command=command));print(mode,count,sorted(set(used)),flush=True)
(out/'variants.json').write_text(json.dumps(dict(variants=rows,sourceInputs=inputs(root),originalShaderSha256=digest(out/'original-hair.spv')),indent=2)+'\n',encoding='utf-8')
