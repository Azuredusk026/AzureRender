from pathlib import Path
import renderdoc as rd
import json,zlib,hashlib,traceback,sys
out=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261107-191143-hair-gradient-region-08b1f9');root=out.parents[2]
inputs=json.loads((out/'variants.json').read_text());capture=root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc'
result=dict(status='starting',variants=[]);cap=None;c=None;original=None;replacement=None
def save():(out/'compare-state.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(capture),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 c.SetFrameEvent(493,True);original=c.GetPipelineState().GetShader(rd.ShaderStage.Pixel)
 last=json.loads((out/'export-state.json').read_text())['lastDrawEvent']
 for variant in inputs['variants']:
    replacement,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/variant['file']).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
    assert replacement!=rd.ResourceId.Null(),errors;c.ReplaceResource(original,replacement);c.SetFrameEvent(last,True)
    target=c.GetPipelineState().GetOutputTargets()[0].resource;raw=bytes(c.GetTextureData(target,rd.Subresource()));assert len(raw)==2560*1440*4
    crop=b''.join(raw[(y*2560+1140)*4:(y*2560+1430)*4] for y in range(130,440));(out/(variant['name']+'-final.zlib')).write_bytes(zlib.compress(crop,9))
    messages=c.GetDebugMessages();result['variants'].append(dict(name=variant['name'],cropSha256=hashlib.sha256(crop).hexdigest(),debugMessages=[dict(severity=str(m.severity),description=str(m.description)) for m in messages[:50]],debugMessageCount=len(messages)));save()
    c.RemoveReplacement(original);c.FreeTargetResource(replacement);replacement=None
 result['status']='compared';save()
except Exception:result.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:
    if original:c.RemoveReplacement(original)
    if replacement:c.FreeTargetResource(replacement)
    c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if result['status']=='compared' else 1)
