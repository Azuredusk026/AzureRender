from pathlib import Path
import json,re,subprocess,os,sys,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
budget=check(root/'build',run=out,planned=40*1024**2,diagnostic=True)
assert budget['allowed'],budget
(out/'budget.json').write_text(json.dumps(budget,indent=2))
source=inputs(root)
(out/'source-inputs.json').write_text(json.dumps(source,indent=2))
text=(root/'src/assets/GltfLoader.cpp').read_text(encoding='utf-8-sig')
at='LoadedAsset loadGltfAsset(const std::string& path) {'
text=text.replace(at,(out/'batch.inc').read_text()+ '\n'+at,1)
old='AuthoredImageMips authored;loader.SetImageLoader(decodeGltfImage,&authored);\n    tinygltf::Model model;'
new='AuthoredImageMips authored;\n    tinygltf::Model model;ImageDecodeBatch batch{model,authored};loader.SetImageLoader(queueGltfImage,&batch);'
assert old in text;text=text.replace(old,new,1)
text=text.replace('const bool loaded = extension == ".glb"','const bool parsed = extension == ".glb"',1)
marker='    if (!warning.empty()) {'
assert marker in text;text=text.replace(marker,'    const bool decoded=batch.finish(&error,&warning);\n    const bool loaded=parsed&&decoded;\n'+marker,1)
old='tinygltf::TinyGLTF loader;loader.SetImageLoader(decodeGltfImage,&authored);std::string error,warning;bool external=false;'
new='tinygltf::TinyGLTF loader;ImageDecodeBatch batch{model,authored};loader.SetImageLoader(queueGltfImage,&batch);std::string error,warning;bool external=false;'
assert old in text;text=text.replace(old,new,1)
text=text.replace('const bool loaded=binary?loader.LoadBinaryFromMemory','const bool parsed=binary?loader.LoadBinaryFromMemory',1)
marker='    if(external)throw std::invalid_argument('
assert marker in text;text=text.replace(marker,'    const bool decoded=batch.finish(&error,&warning);const bool loaded=parsed&&decoded;\n'+marker,1)
(out/'GltfLoader.cpp').write_text(text,encoding='utf-8')
driver=(root/'build/runs/20261107-162522-binary-material-images-621f66/control.cpp').read_text()
driver=driver.replace('extern "C" double* azure_diag_times();','extern "C" double* azure_diag_times(){static double values[4]{};return values;}')
# Time only loading/interpretation; CPU work and working set are process-wide observations.
driver=driver.replace('#include <windows.h>','#include <windows.h>\n#include <psapi.h>')
driver=driver.replace('int main(int argc,char** argv)try{','double processCpuMs(){FILETIME a,b,k,u;GetProcessTimes(GetCurrentProcess(),&a,&b,&k,&u);ULARGE_INTEGER x,y;x.LowPart=k.dwLowDateTime;x.HighPart=k.dwHighDateTime;y.LowPart=u.dwLowDateTime;y.HighPart=u.dwHighDateTime;return (x.QuadPart+y.QuadPart)/10000.;}\nint main(int argc,char** argv)try{')
driver=driver.replace('auto start=std::chrono::steady_clock::now();','auto start=std::chrono::steady_clock::now();double cpuStart=processCpuMs();',1)
driver=driver.replace('start=std::chrono::steady_clock::now();\n            const auto slots=', 'start=std::chrono::steady_clock::now();cpuStart=processCpuMs();\n            const auto slots=')
driver=driver.replace('{"totalMs",elapsed}', '{"totalMs",elapsed},{"cpuMs",processCpuMs()-cpuStart}')
driver=driver.replace('const auto interpretationMs=', 'const auto cpuElapsed=processCpuMs()-cpuStart;const auto interpretationMs=')
driver=driver.replace('{"totalMs",interpretationMs}', '{"totalMs",interpretationMs},{"cpuMs",cpuElapsed}')
driver=driver.replace('std::ofstream(argv[2])<<rows.dump(2);std::cout', 'PROCESS_MEMORY_COUNTERS memory{};memory.cb=sizeof(memory);GetProcessMemoryInfo(GetCurrentProcess(),&memory,sizeof(memory));\n        rows.back()["peakWorkingSetBytes"]=memory.PeakWorkingSetSize;std::ofstream(argv[2])<<rows.dump(2);std::cout')
(out/'control.cpp').write_text(driver,encoding='utf-8')
targets=json.loads((root/'build/runs/20261107-164329-decoded-image-reuse-e2e46c/native-targets.json').read_text())
(out/'targets.json').write_text(json.dumps(targets,indent=2))
env=dict(os.environ);env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9')
bat=['cmd','/d','/c',str(root/'tools/msvc_env.bat')]
flags=['cl','/nologo','/O2','/MD','/EHsc','/std:c++17','/utf-8','/DNDEBUG','/DNOMINMAX','/I'+str(root/'src'),'/I'+str(root/'src/assets'),'/I'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'),'/ID:/Tools/VulkanSDK/1.4.350.0/Include','/c']
for name in ['control','GltfLoader']:
 with (out/(name+'-compile.log')).open('wb') as log:
  p=subprocess.run(bat+flags+[str(out/(name+'.cpp')),'/Fo'+str(out/(name+'.obj'))],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 assert p.returncode==0,(out/(name+'-compile.log')).read_text(errors='replace')[-4000:]
 print('compiled',name,flush=True)
response=(root/'build/runs/20261107-161237-cpu-asset-load-stages-3ff597/link.rsp').read_text()
response=re.sub(r'^"[^\"]+profile\.obj"',lambda m:'"'+str(out/'control.obj')+'" "'+str(out/'GltfLoader.obj')+'"',response)
response=re.sub(r'/(out|implib|pdb|MAP):"[^\"]+"',lambda m:'/'+m[1]+':"'+str(out/('control.'+{'out':'exe','implib':'lib','pdb':'pdb','MAP':'map'}[m[1]]))+'"',response)+' bcrypt.lib psapi.lib'
(out/'link.rsp').write_text(response)
with (out/'link.log').open('wb') as log:p=subprocess.run(bat+['link','@'+str(out/'link.rsp')],cwd=root/'build/ninja-msvc-release',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(out/'link.log').read_text(errors='replace')[-4000:]
assert source==inputs(root)
print(json.dumps({'status':'compiled','productionInputsUnchanged':True,'executableSha256':digest(out/'control.exe')}),flush=True)
