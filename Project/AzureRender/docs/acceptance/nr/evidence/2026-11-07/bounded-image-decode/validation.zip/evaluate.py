from pathlib import Path
import json,os,sys,subprocess,time,ctypes,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
assert check(root/'build',run=out,planned=2*1024**2,diagnostic=True)['allowed']
source=json.loads((out/'source-inputs.json').read_text())
assert source==inputs(root)
prior=root/'build/runs/20261107-162522-binary-material-images-621f66'
expected=[r for name in ['candidate-floor.json','candidate.json'] for r in json.loads((prior/name).read_text()) if r['kind']=='binding']
frozen=json.loads((prior/'input-references.json').read_text())['files']
assert all(digest(Path(p))==h for p,h in frozen.items())
(out/'input-references.json').write_text(json.dumps(frozen,indent=2))
class Power(ctypes.Structure):
 _fields_=[('ac',ctypes.c_ubyte),('flags',ctypes.c_ubyte),('percent',ctypes.c_ubyte),('system',ctypes.c_ubyte),('life',ctypes.c_uint32),('fullLife',ctypes.c_uint32)]
def state():
 p=Power();assert ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(p))
 return dict(timestamp=time.time(),ac=p.ac,batteryPercent=p.percent)
env=dict(os.environ);env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH']
results=[];started=time.monotonic()
for index,mode in enumerate(['serial','parallel','parallel','serial']):
 assert time.monotonic()-started<300,'Batch budget exhausted'
 local=env.copy()
 if mode=='serial':local['AZURE_DIAG_SERIAL_IMAGES']='1'
 else:local.pop('AZURE_DIAG_SERIAL_IMAGES',None)
 label=f'{index+1}-{mode}';before=state()
 command=[str(out/'control.exe'),str(out/'targets.json'),str(out/(label+'.json'))]
 (out/(label+'-command.json')).write_text(json.dumps(command,indent=2))
 print('Starting',label,flush=True)
 with (out/(label+'.log')).open('wb') as log:
  p=subprocess.run(command,cwd=out,env=local,stdout=log,stderr=subprocess.STDOUT,timeout=min(120,max(1,300-(time.monotonic()-started))),creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 assert p.returncode==0,(out/(label+'.log')).read_text(errors='replace')[-2500:]
 rows=json.loads((out/(label+'.json')).read_text())
 bindings=[r for r in rows if r['kind']=='binding']
 assert len(bindings)==len(expected)==16
 assert all(a['path']==b['path'] and a['signature']==b['signature'] for a,b in zip(bindings,expected))
 result=dict(label=label,mode=mode,totalMs=sum(r['totalMs'] for r in rows),cpuMs=sum(r['cpuMs'] for r in rows),peakWorkingSetBytes=max(r.get('peakWorkingSetBytes',0) for r in rows),before=before,after=state(),materials=16,allFrozenMaterialSignaturesEqual=True)
 results.append(result);(out/'samples.json').write_text(json.dumps(results,indent=2));print(json.dumps(result),flush=True)
assert all(digest(Path(p))==h for p,h in frozen.items())
assert source==inputs(root)
means={mode:{key:sum(r[key] for r in results if r['mode']==mode)/2 for key in ['totalMs','cpuMs','peakWorkingSetBytes']} for mode in ['serial','parallel']}
reduction=1-means['parallel']['totalMs']/means['serial']['totalMs']
result=dict(status='passed' if reduction>=.30 else 'isolated-below-threshold',wallReduction=reduction,means=means,samples=results,productionSourceUnchanged=True,frozenInputCount=len(frozen),allFrozenMaterialSignaturesEqual=True,executableSha256=digest(out/'control.exe'),scope='CPU asset loading only; battery state recorded; no frame-time, GPU, AC qualification, or overall acceptance claim')
(out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
