from pathlib import Path
import json,zipfile,sys
out=Path(__file__).resolve().parent;root=out.parents[2];other=root/'build/runs/20261107-062311-scene-lighting-specialization-5eb462';e=root/'docs/acceptance/nr/evidence/2026-11-07/current-gpu-cost';e.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
frozen=json.loads((out/'frozen-inputs.json').read_text());assert inputs(root)==frozen['source'] and all(digest(Path(p))==h for p,h in frozen['products'].items())
profile=json.loads((out/'events/profile.json').read_text());control=json.loads((other/'compare-state.json').read_text());assert control['status']=='compared'
z=e/'measurements.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for prefix,folder in [('capture',out),('view-mode',other)]:
  for p in folder.rglob('*'):
   if p.is_file() and p.suffix.lower() in ['.py','.json','.log','.frag','.glsl','.spv'] and '__pycache__' not in p.parts:archive.write(p,prefix+'/'+str(p.relative_to(folder)))
state=json.loads((out/'state.json').read_text());times=control['summary'];b=sum(r['matchedEventMs'] for r in times if r['mode']=='baseline')/2;c=sum(r['matchedEventMs'] for r in times if r['mode']=='candidate')/2
summary=dict(schemaVersion=1,status='diagnosed-candidate-deferred',sourceBase='35cc28f',capture=state,profile=profile,localControl=control,matchedBaselineMs=b,matchedCandidateMs=c,matchedReduction=1-c/b,nativeBatchQualified=False,productionChanged=False,formalAcceptance=False,limitations=['The capture extent is 1280x720 and is used only for event attribution.','Only inspected events have shader identities; uninspected group is not a single program.','Scene-only control had baseline drift and does not qualify as native performance evidence.','View-mode control changes high precision intermediate bytes; one final display output matches exactly.','Matched event reduction is below the 20 percent gate.','No additional native image, native timing or formal run was launched for this candidate.'])
(e/'results.json').write_text(json.dumps(summary,indent=2));manifest=dict(schemaVersion=1,sourceBase='35cc28f',status=summary['status'],capture=dict(path=state['capture'],bytes=state['bytes'],sha256=state['captureSha256']),archive=dict(file=z.name,bytes=z.stat().st_size,sha256=digest(z)),results=dict(file='results.json',sha256=digest(e/'results.json')),productionUnchanged=True,formalAcceptance=False)
(e/'manifest.json').write_text(json.dumps(manifest,indent=2))
registry=root/'docs/development/artifact-manifest.json';data=json.loads(registry.read_text(encoding='utf-8-sig'));path='runs/'+out.name
assert not any(r['path']==path for r in data['preservedRuns']);data['preservedRuns'].append(dict(path=path,pathBase='build',purpose='当前 GPU 单帧成本定位及后续局部控制输入。',retention='性能候选完成且捕获已核验归档后清理。',pinMarker='.keep',capture=dict(path='current_frame320.rdc',bytes=state['bytes'],sha256=state['captureSha256'])))
registry.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(out/'.keep').write_text('Current GPU attribution input; registered in docs/development/artifact-manifest.json\n')
print(json.dumps(dict(status=summary['status'],matchedReduction=summary['matchedReduction'],archive=manifest['archive'])),flush=True)
