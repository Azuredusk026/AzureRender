from pathlib import Path
import json,subprocess,sys,time,os
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
frozen=json.loads((out/'frozen-inputs.json').read_text());assert inputs(root)==frozen['source']
assert all(digest(Path(p))==v for p,v in frozen['products'].items())
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'profile_current.py')]
with (out/'profile-driver.log').open('wb') as log:r=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=360)
state=json.loads((out/'profile-state.json').read_text());assert r.returncode==0 and state['status']=='profiled',state
assert inputs(root)==frozen['source'] and all(digest(Path(p))==v for p,v in frozen['products'].items())
programs={digest(p):p.name for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv')}
profile=json.loads((out/'events/profile.json').read_text())
for key,value in profile['shaders'].items():value['programFile']=programs.get(value['sha256'])
(out/'events/profile.json').write_text(json.dumps(profile,indent=2))
used=sum(p.stat().st_size for p in out.rglob('*') if p.is_file());assert used<=2**31,used
(out/'profile-result.json').write_text(json.dumps(dict(status='profiled',seconds=time.monotonic()-start,sourceBase='35cc28f',diagnosticExtent=[1280,720],formalAcceptance=False,sourceUnchanged=True,productsUnchanged=True,usedBytes=used,groups=profile['groups']),indent=2))
print(json.dumps(dict(status='profiled',seconds=time.monotonic()-start,usedBytes=used,groups=profile['groups'][:12])),flush=True)
