from pathlib import Path
root=Path.cwd();out=Path(__file__).resolve().parent;a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54'
s=(a/'capture_current_gpu_events.py').read_text()
s=s.replace("a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'current-gpu-events';out.mkdir(exist_ok=True)","out=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc'")
s=s.replace("sourceBase='0694263'","sourceBase='35cc28f'").replace("'1920','--height','1080'","'1280','--height','720'")
start=s.index('    if pid:\n');end=s.index('    control.QueueCapture',start);s=s[:start]+s[end:]
s=s.replace("    control.QueueCapture(320,1);deadline=time.monotonic()+600","    control.QueueCapture(320,1);deadline=time.monotonic()+600")
(out/'capture_current.py').write_text(s)
p=(a/'profile_current_gpu_events.py').read_text().replace("a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'current-gpu-events'","out=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc'").replace("sourceBase='0694263'","sourceBase='35cc28f'")
(out/'profile_current.py').write_text(p)
