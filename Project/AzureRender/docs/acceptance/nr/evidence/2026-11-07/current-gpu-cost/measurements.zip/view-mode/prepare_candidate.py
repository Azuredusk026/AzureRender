from pathlib import Path
import json,subprocess,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];private=out/'candidate-source';private.mkdir(exist_ok=True)
source=root/'shaders'
for name in ['mesh.frag','unlit_opaque.glsl','unlit_blend.glsl']:
 text=(source/name).read_text().replace('camera.clusterLighting.x','1.0')
 (private/name).write_text(text)
profile=json.loads((root/'build/runs/20261107-061745-current-gpu-cost-2de6bc/events/profile.json').read_text())
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());reports=[]
names={v['programFile'] for v in profile['shaders'].values() if (v.get('programFile')or'').startswith(('mesh','character_snapshot'))}
for name in sorted(names):
 program=next(p for p in manifest['programs'] if p['output']==name);assert program['source']=='mesh.frag'
 command=[manifest['compiler'],*[f'-D{d}' for d in program['defines']],f'-I{private}',f'-I{source}',str(private/'mesh.frag'),'-o',str(out/name)]
 r=subprocess.run(command,capture_output=True,text=True);reports.append(dict(file=name,command=command,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr))
 (out/'candidate-build.json').write_text(json.dumps(reports,indent=2));assert r.returncode==0,r.stderr
print(json.dumps(dict(status='built',programs=sorted(names))),flush=True)
