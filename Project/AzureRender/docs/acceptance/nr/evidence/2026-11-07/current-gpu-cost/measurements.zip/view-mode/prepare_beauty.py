from pathlib import Path
import shutil
out=Path(__file__).resolve().parent;root=out.parents[2];saved=out/'scene-only';saved.mkdir()
for p in list(out.glob('*.spv'))+[out/'compare-state.json',out/'compare-results.json',out/'candidate-build.json']:
 shutil.copy2(p,saved/p.name)
shutil.copytree(out/'candidate-source',saved/'candidate-source')
script=(out/'prepare_candidate.py').read_text().replace(".replace('camera.clusterLighting.x','1.0')",".replace('camera.clusterLighting.x','1.0').replace('camera.qaParameters.x','0.0').replace('camera.qaParameters.y','0.0').replace('camera.qaParameters.z','1.0')")
(out/'prepare_beauty_candidate.py').write_text(script)
compare=(out/'compare.py').read_text().replace("scene lighting value fixed to its observed input","scene lighting and beauty mode fixed to observed input")
compare=compare.replace("assert lighting==1.0,lighting","assert lighting==1.0,lighting\n  qa=list(struct.unpack('<4f',bytes(c.GetBufferData(descriptor.resource,descriptor.byteOffset+128,16))));assert qa[0]==0 and qa[1]==0 and qa[2]>=0.5,qa")
compare=compare.replace("sceneLighting=lighting,errors=errors","sceneLighting=lighting,qaParameters=qa,errors=errors")
# Warm the driver before recording the first measured baseline.
compare=compare.replace("report['status']='baseline-read';report['timings']=[dict(mode='baseline',milliseconds=durations())];save()","durations();report['status']='baseline-read';report['timings']=[dict(mode='baseline',milliseconds=durations())];save()")
(out/'compare_beauty.py').write_text(compare)
launcher=(out/'run_compare.py').read_text().replace("str(out/'compare.py')","str(out/'compare_beauty.py')")
(out/'run_beauty_compare.py').write_text(launcher)
