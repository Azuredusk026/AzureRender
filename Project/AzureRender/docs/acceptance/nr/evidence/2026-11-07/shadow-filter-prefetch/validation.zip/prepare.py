from pathlib import Path
import json,subprocess,sys,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
assert check(root/'build',run=out,planned=16*1024**2)['allowed']
source=inputs(root);(out/'source-inputs.json').write_text(json.dumps(source,indent=2))
s=(root/'shaders/mesh.frag').read_text();needle='    for(int y=-bound;y<=bound;y+=2)for(int x=-bound;x<=bound;x+=2){'
assert s.count(needle)==1
start=s.index(needle);end=s.index('    return visible/max(totalWeight,1e-6);',start)
old=s[start:end];lines=old.splitlines();assert len(lines)==9,lines
weights,plane,weight,skip,gather,visible,total=lines[1:8]
assert skip.strip()=='if(weight<=0)continue;'
def renamed(line,tag):
 for name in ['weights','planeDepths','weight','depths']:line=re.sub(r'\b'+name+r'\b',name+tag,line)
 return line
bodyA='\n'.join(renamed(line,'A') for line in [weights,plane,weight])
bodyB='\n'.join('    '+renamed(line,'B').replace('vec2(x,y)','vec2(x+2,y)').replace('ivec2(x,y)','ivec2(x+2,y)') for line in [weights,plane,weight])
loadA=renamed(gather,'A').replace('        vec4 depthsA=','        if(activeA)depthsA=')
loadB='    '+renamed(gather,'B').replace('vec2(x,y)','vec2(x+2,y)').replace('ivec2(x,y)','ivec2(x+2,y)').replace('        vec4 depthsB=','        if(activeB)depthsB=')
consumeA='\n'.join('    '+renamed(line,'A') for line in [visible,total])
consumeB='\n'.join('    '+renamed(line,'B') for line in [visible,total])
new=needle.replace('x+=2','x+=4')+'\n'+bodyA+'''
        bool activeA=!(weightA<=0);vec4 depthsA=vec4(0);
'''+loadA+'''
        if(x+2<=bound){
'''+bodyB+'''
            bool activeB=!(weightB<=0);vec4 depthsB=vec4(0);
'''+loadB+'''
            if(activeA){
'''+consumeA+'''
            }
            if(activeB){
'''+consumeB+'''
            }
        }else if(activeA){
'''+consumeA+'''
        }
    }
'''
s=s[:start]+new+s[end:];(out/'mesh.frag').write_text(s)
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());programs={p['output']:p for p in manifest['programs']}
previous=root/'build/runs/20261107-221043-shadow-filter-range-culling-d81a60/candidate'
rows=[]
for row in json.loads((previous/'candidate-build.json').read_text()):
 name=row['file'];p=programs[name];command=[manifest['compiler'],*[f'-D{d}' for d in p['defines']],f'-I{out}',f'-I{root/"shaders"}',str(out/'mesh.frag'),'-o',str(out/name)]
 r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr
 v=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe',str(out/name)],capture_output=True,text=True);assert v.returncode==0,v.stderr
 rows.append(dict(file=name,command=command,baselineSha256=digest(root/'build/ninja-msvc-release/shaders'/name),candidateSha256=digest(out/name)))
(out/'candidate-build.json').write_text(json.dumps(rows,indent=2))
compare=(previous/'compare.py').read_text();needle="out=Path('"+previous.as_posix()+"')";assert compare.count(needle)==1;compare=compare.replace(needle,"out=Path('"+out.as_posix()+"')")
assert previous.as_posix() not in compare.replace("assert out==Path('"+previous.as_posix()+"')",'')
compare=compare.replace("assert out==Path('"+previous.as_posix()+"')","assert out==Path('"+out.as_posix()+"')")
compare=compare.replace('Exact same-8x8-tile filter comparison classification with adjacent-query bound reuse; original weights and summation order retained.','Two adjacent filter depth reads issued before their ordered consumption; original weights, receiver expressions and accumulation order retained.')
(out/'compare.py').write_text(compare)
runner=(previous/'run_compare.py').read_text().replace('root=out.parents[3]','root=out.parents[2]').replace('run=out.parent,planned=16*1024**2','run=out,planned=16*1024**2');(out/'run_compare.py').write_text(runner)
assert source==inputs(root)
print(json.dumps(dict(status='prepared',programs=len(rows),productionSourceUnchanged=True)),flush=True)
