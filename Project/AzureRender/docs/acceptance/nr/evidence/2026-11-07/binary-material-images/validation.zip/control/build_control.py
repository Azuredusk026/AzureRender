from pathlib import Path
import subprocess,os,json,re,sys
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261107-161237-cpu-asset-load-stages-3ff597';name=sys.argv[1]
env=dict(os.environ);env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9');env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH']
bat=['cmd','/d','/c',str(root/'tools/msvc_env.bat')]
flags=['cl','/nologo','/O2','/MD','/EHsc','/std:c++17','/utf-8','/DNDEBUG','/DNOMINMAX','/I'+str(root/'src'),'/I'+str(root/'src/assets'),'/I'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'),'/ID:/Tools/VulkanSDK/1.4.350.0/Include','/c']
sources=[('control',out/'control.cpp'),(name+'-MaterialData',out/'baseline-MaterialData.cpp' if name=='baseline' else root/'src/assets/MaterialData.cpp')]
for stem,path in sources:
 with (out/(stem+'-compile.log')).open('wb') as log:p=subprocess.run(bat+flags+[str(path),'/Fo'+str(out/(stem+'.obj'))],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 assert p.returncode==0,(out/(stem+'-compile.log')).read_text(errors='replace')[-4000:]
response=(prior/'link.rsp').read_text().replace(str(prior/'profile.obj'),str(out/'control.obj')+'" "'+str(prior/'GltfLoader.obj')+'" "'+str(out/(name+'-MaterialData.obj')))
response=re.sub(r'/(out|implib|pdb|MAP):"[^"]+"',lambda m:'/'+m[1]+':"'+str(out/(name+'.'+{'out':'exe','implib':'lib','pdb':'pdb','MAP':'map'}[m[1]]))+'"',response)+' bcrypt.lib'
(out/(name+'-link.rsp')).write_text(response)
with (out/(name+'-link.log')).open('wb') as log:p=subprocess.run(bat+['link','@'+str(out/(name+'-link.rsp'))],cwd=root/'build/ninja-msvc-release',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(out/(name+'-link.log')).read_text(errors='replace')[-4000:]
print('Built '+name,flush=True)
with (out/(name+'-driver.log')).open('wb') as log:p=subprocess.run([str(out/(name+'.exe')),str(out/'targets.json'),str(out/(name+'.json'))],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
assert p.returncode==0,(out/(name+'-driver.log')).read_text(errors='replace')[-4000:]
print('Evaluated '+name,flush=True)
