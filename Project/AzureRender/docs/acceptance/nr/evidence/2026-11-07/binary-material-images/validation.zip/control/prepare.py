from pathlib import Path
import json,re
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261107-161237-cpu-asset-load-stages-3ff597'
(out/'baseline-MaterialData.cpp').write_bytes((root/'src/assets/MaterialData.cpp').read_bytes())
targets=json.loads((prior/'targets.json').read_text());(out/'targets.json').write_text(json.dumps([targets[-1]],indent=2))
source=(prior/'detail.cpp').read_text().replace('#include <chrono>','#include <chrono>\n#include "assets/MaterialSurfaceProfile.hpp"\n#include <windows.h>\n#include <bcrypt.h>\n#include <array>')
helper='''
std::string sha256(const void* data,std::size_t bytes){
 BCRYPT_ALG_HANDLE algorithm=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;
 if(BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)throw std::runtime_error("SHA256 provider failed");
 if(BCryptCreateHash(algorithm,&hash,nullptr,0,nullptr,0,0)<0)throw std::runtime_error("SHA256 hash failed");
 const auto updated=BCryptHashData(hash,const_cast<PUCHAR>(static_cast<const UCHAR*>(data)),static_cast<ULONG>(bytes),0);
 std::array<UCHAR,32> result{};const auto finished=BCryptFinishHash(hash,result.data(),32,0);BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(algorithm,0);
 if(updated<0||finished<0)throw std::runtime_error("SHA256 update failed");
 std::string text;for(auto value:result){text+="0123456789abcdef"[value>>4];text+="0123456789abcdef"[value&15];}return text;
}
nlohmann::json signature(const AssetMaterial& m){
 nlohmann::json pixels=nlohmann::json::array();
 for(const auto* p:{&m.baseColorPixels,&m.normalPixels,&m.metallicRoughnessPixels,&m.specularEmissivePixels,&m.styleMaskPixels,&m.matcapPixels,&m.hairDataPixels,&m.faceSdf.pixels,&m.shadowColorLutPixels,&m.projectedHairRamp.parameterPixels,&m.projectedHairRamp.line.pixels,&m.outlineSurface.maskPixels,&m.transmissionPixels})pixels.push_back({{"bytes",p->size()},{"sha256",sha256(p->data(),p->size())}});
 const auto packed=azurerender::packMaterialSurfaceProfile(m);nlohmann::json settings=nlohmann::json::array();for(const auto& s:m.textureSettings)settings.push_back(s.describe());
 return {{"pixels",pixels},{"packedSha256",sha256(&packed,sizeof(packed))},{"mips",m.authoredMipLevels},{"settings",settings},
 {"class",int(m.materialClass)},{"features",m.materialFeatures},{"alphaMode",int(m.alphaMode)},{"alphaCutoff",m.alphaCutoff},{"doubleSided",m.doubleSided}};
}
'''
source=source.replace('int main(',helper+'\nint main(')
source=source.replace('rows.push_back({{"kind","binding"}', 'const auto interpretationMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();const auto fingerprint=signature(material);\n            rows.push_back({{"signature",fingerprint},{"kind","binding"}')
source=source.replace('{"totalMs",std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()}', '{"totalMs",interpretationMs}')
(out/'control.cpp').write_text(source,encoding='utf-8')
print('Saved baseline source and 14 native bindings')
