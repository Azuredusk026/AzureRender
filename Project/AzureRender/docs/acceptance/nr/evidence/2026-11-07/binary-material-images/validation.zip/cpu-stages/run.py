from pathlib import Path
import subprocess,os,re,json,time,sys
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
assert check(root/'build',run=out,planned=32*1024**2,diagnostic=True)['allowed']
env=dict(os.environ);env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9');env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH']
prefix=['cmd','/d','/c',str(root/'tools/msvc_env.bat')];build=root/'build/ninja-msvc-release';si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
source=inputs(root);products={str(build/p):digest(build/p) for p in ['AzurePlayer.exe','AzureRenderCore.lib','AzureRuntime.lib']}
commands=[('compile',prefix+['cl','/nologo','/O2','/MD','/EHsc','/std:c++17','/utf-8','/DNDEBUG','/DNOMINMAX','/I'+str(root/'src'),'/I'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'),'/ID:/Tools/VulkanSDK/1.4.350.0/Include','/c',str(out/'profile.cpp'),'/Fo'+str(out/'profile.obj')])]
response=(root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/link.rsp').read_text()
response=re.sub(r'^"[^"]+AzureRenderApp\.obj"', lambda m:'"'+str(out/'profile.obj')+'"',response)
response=response.replace(r'CMakeFiles\AzurePlayer.dir\src\player\main.cpp.obj','')
response=re.sub(r'/(out|implib|pdb|MAP):"[^"]+"',lambda m:'/'+m[1]+':"'+str(out/('profile.'+{'out':'exe','implib':'lib','pdb':'pdb','MAP':'map'}[m[1]]))+'"',response)
(out/'link.rsp').write_text(response);commands.append(('link',prefix+['link','@'+str(out/'link.rsp')]))
for kind,command in commands:
    previous=out/(kind+'.log')
    if previous.exists():previous.rename(out/(kind+'-attempt-'+str(time.time_ns())+'.log'))
    with (out/(kind+'.log')).open('wb') as log:p=subprocess.run(command,cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180,startupinfo=si)
    assert p.returncode==0,(out/(kind+'.log')).read_text(errors='replace')[-5000:]
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
command=[str(out/'profile.exe'),str(project),str(out/'profile.json')];(out/'command.json').write_text(json.dumps(command,indent=2));print('CPU profile started',flush=True)
with (out/'driver.log').open('wb') as log:p=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240,startupinfo=si,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
assert source==inputs(root) and all(digest(Path(path))==h for path,h in products.items())
print('CPU profile exit '+str(p.returncode),flush=True);assert p.returncode==0
