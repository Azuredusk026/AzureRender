#include "runtime/LevelSession.hpp"
#include "assets/MaterialData.hpp"
#include "render/DeformedBounds.hpp"
#include <nlohmann/json.hpp>
#include <chrono>
#include <fstream>
#include <iostream>
using namespace azurerender;
using Clock=std::chrono::steady_clock;
double ms(Clock::time_point start){return std::chrono::duration<double,std::milli>(Clock::now()-start).count();}
int main(int argc,char** argv)try{
    if(argc!=3)throw std::invalid_argument("Expected project and report paths");
    const auto start=Clock::now();ProjectStartup startup(Project::load(std::filesystem::u8path(argv[1])));
    nlohmann::json report={{"projectStartupMs",ms(start)},{"rows",nlohmann::json::array()}};
    const scene::ResourceLayout layout(startup.level().scene.renderDescription());
    for(std::size_t index=0;index<layout.paths.size();++index){
        auto begin=Clock::now();auto asset=loadGltfAsset(layout.paths[index]);const auto load=ms(begin);
        begin=Clock::now();applyMaterialBindings(asset,layout.materials[index]);const auto bindings=ms(begin);
        begin=Clock::now();auto bounds=JointBounds::build(asset);const auto boundTime=ms(begin);
        report["rows"].push_back({{"index",index},{"path",layout.paths[index]},{"materialBindings",layout.materials[index].size()},
            {"loadGltfMs",load},{"bindingsMs",bindings},{"jointBoundsMs",boundTime},{"vertices",asset.vertices.size()}});
        std::ofstream(argv[2])<<report.dump(2);if(index%32==0)std::cout<<"resource="<<index<<" load="<<load<<" bindings="<<bindings<<std::endl;
    }
    report["totalMs"]=ms(start);report["status"]="profiled";std::ofstream(argv[2])<<report.dump(2);
    std::cout<<"PASS: CPU-only resource preparation, resources="<<layout.paths.size()<<std::endl;
}catch(const std::exception& error){std::cerr<<error.what()<<std::endl;return 1;}
