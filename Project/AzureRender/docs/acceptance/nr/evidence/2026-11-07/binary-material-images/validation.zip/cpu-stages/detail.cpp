#include "assets/MaterialData.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
extern "C" double* azure_diag_times();
using namespace azurerender;
int main(int argc,char** argv)try{
    if(argc!=3)return 2;std::ifstream stream(argv[1]);nlohmann::json targets;stream>>targets;
    nlohmann::json rows=nlohmann::json::array();
    for(const auto& target:targets){
        std::fill_n(azure_diag_times(),4,0.);auto start=std::chrono::steady_clock::now();
        auto asset=loadGltfAsset(target.at("path").get<std::string>());
        const auto elapsed=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
        rows.push_back({{"kind","model"},{"path",target.at("path")},{"totalMs",elapsed},{"imageDecodeMs",azure_diag_times()[0]},
            {"materialMs",azure_diag_times()[1]},{"pixelConversionMs",azure_diag_times()[2]},{"importMs",azure_diag_times()[3]}});
        for(const auto& binding:target.at("bindings")){
            const auto document=MaterialData::load(std::filesystem::u8path(binding.at("path").get<std::string>()));
            std::fill_n(azure_diag_times(),4,0.);start=std::chrono::steady_clock::now();
            const auto slots=materialSlotIds(asset);const auto at=std::find(slots.begin(),slots.end(),binding.at("slot").get<std::string>());
            if(at==slots.end())throw std::runtime_error("Missing source slot");
            auto prepared=document;
            if(prepared.typeId=="azure.profile"){
                prepared.authoringGraph=nullptr;prepared.surface["nodes"]=nlohmann::json::array();
                for(const auto& node:asset.nodes)prepared.surface["nodes"].push_back({{"name",node.name}});
            }
            const auto material=prepared.interpret([&](const std::string& id){return std::filesystem::u8path(binding.at("textures").at(id).get<std::string>());},&asset.materials.at(at-slots.begin()));
            rows.push_back({{"kind","binding"},{"path",binding.at("path")},{"type",document.typeId},
                {"totalMs",std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()},
                {"imageDecodeMs",azure_diag_times()[0]},{"materialMs",azure_diag_times()[1]},{"pixelConversionMs",azure_diag_times()[2]}});
        }
        std::ofstream(argv[2])<<rows.dump(2);std::cout<<"Completed "<<target.at("path")<<std::endl;
    }
}catch(const std::exception& error){std::cerr<<error.what()<<std::endl;return 1;}
