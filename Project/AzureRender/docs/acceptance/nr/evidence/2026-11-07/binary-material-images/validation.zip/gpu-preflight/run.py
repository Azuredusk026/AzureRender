from pathlib import Path
import subprocess,json,sys,time
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from artifact_budget import check
from gpu_environment import wait_and_record,RunEnvironmentMonitor,environment_errors
assert check(root/'build',run=out,planned=12*1024**2,diagnostic=True)['allowed']
source=inputs(root);products={str(p):digest(p) for p in [root/'build/ninja-msvc-release/AzurePlayer.exe',*sorted((root/'build/ninja-msvc-release/shaders').glob('*.spv'))]}
environment=wait_and_record(out/'environment.json',timeout=45)
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with RunEnvironmentMonitor(environment,path=out/'environment.json'):
    with (out/'driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'replay.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=240)
assert source==inputs(root) and all(digest(Path(p))==h for p,h in products.items())
result=json.loads((out/'replay-state.json').read_text());summary=dict(status=result['status'],seconds=time.monotonic()-start,processExitCode=p.returncode,environmentErrors=environment_errors(environment),sourceAndProductsUnchanged=True,outputsEqual=result.get('outputsEqual'),error=result.get('error'))
(out/'result.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
