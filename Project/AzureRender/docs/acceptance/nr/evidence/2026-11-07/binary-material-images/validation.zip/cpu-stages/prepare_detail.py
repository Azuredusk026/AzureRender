from pathlib import Path
import json,re,subprocess,os,sys
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
assert check(root/'build',run=out,planned=24*1024**2,diagnostic=True)['allowed']
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4';description=json.loads((project/'joint-materials.azureproject').read_text())
assets={}
for mount in description['mounts']:
    for p in (project/mount['path']).rglob('*.azmeta'):
        d=json.loads(p.read_text(encoding='utf-8-sig'));assets[d['id']]=Path(str(p)[:-7]).resolve()
level=json.loads((project/'scene/joint-dynamic-loop-v2.azurelevel').read_text());hero=next(n for n in level['nodes'] if n.get('resourceId')=='hero' and n.get('materialSlots'))
rows=json.loads((out/'profile.json').read_text())['rows'];targets=[]
for index in [60,8,290,363]:
    row=rows[index];target=dict(path=row['path'],bindings=[])
    if index==363:
        for slot,uuid in hero['materialSlots'].items():
            path=assets[uuid];material=json.loads(path.read_text());textures={}
            for value in material.get('textures',{}).values():
                identity=value if isinstance(value,str) else value.get('asset')
                if identity:textures[identity]=str(assets[identity])
            target['bindings'].append(dict(path=str(path),slot=slot,textures=textures))
    targets.append(target)
(out/'targets.json').write_text(json.dumps(targets,indent=2))
text=(root/'src/assets/GltfLoader.cpp').read_text()
prefix='#include <chrono>\nnamespace { double azDiag[4]{}; struct AzDiagScope {unsigned i;std::chrono::steady_clock::time_point start=std::chrono::steady_clock::now();~AzDiagScope(){azDiag[i]+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();}};}\nextern "C" double* azure_diag_times(){return azDiag;}\n'
for index,pattern in enumerate([r'(bool decodeGltfImage\([\s\S]*?void\* userData\) \{)',r'(AssetMaterial loadMaterial\([\s\S]*?imageSettings=nullptr\) \{)',r'(std::vector<std::uint8_t> decodeImageRgba\([\s\S]*?bool normalUsage=false\) \{)',r'(LoadedAsset importGltfModel\(tinygltf::Model& model,[\s\S]*?imageSettings\)\{)']):
    text,count=re.subn(pattern,lambda m:m[1]+'\n AzDiagScope azScope{'+str(index)+'};',text,count=1);assert count==1,index
(out/'GltfLoader.cpp').write_text(prefix+text,encoding='utf-8')
env=dict(os.environ);env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9');env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH']
bat=['cmd','/d','/c',str(root/'tools/msvc_env.bat')]
flags=['cl','/nologo','/O2','/MD','/EHsc','/std:c++17','/utf-8','/DNDEBUG','/DNOMINMAX','/I'+str(root/'src'),'/I'+str(root/'src/assets'),'/I'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'),'/ID:/Tools/VulkanSDK/1.4.350.0/Include','/c']
source=inputs(root)
for name in ['detail','GltfLoader']:
    with (out/(name+'-compile.log')).open('wb') as log:p=subprocess.run(bat+flags+[str(out/(name+'.cpp')),'/Fo'+str(out/(name+'.obj'))],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    assert p.returncode==0,(out/(name+'-compile.log')).read_text(errors='replace')[-4000:]
response=(out/'link.rsp').read_text().replace(str(out/'profile.obj'),str(out/'detail.obj')+'" "'+str(out/'GltfLoader.obj'))
response=response.replace(str(out/'profile.'),str(out/'detail.'));(out/'detail-link.rsp').write_text(response)
with (out/'detail-link.log').open('wb') as log:p=subprocess.run(bat+['link','@'+str(out/'detail-link.rsp')],cwd=root/'build/ninja-msvc-release',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(out/'detail-link.log').read_text(errors='replace')[-4000:]
print('Detailed CPU sample started',flush=True)
with (out/'detail-driver.log').open('wb') as log:p=subprocess.run([str(out/'detail.exe'),str(out/'targets.json'),str(out/'detail.json')],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
assert p.returncode==0,(out/'detail-driver.log').read_text(errors='replace')[-4000:]
assert source==inputs(root)
print('PASS detailed CPU sample',flush=True)
