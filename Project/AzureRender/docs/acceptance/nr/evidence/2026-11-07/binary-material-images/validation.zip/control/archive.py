from pathlib import Path
import json,zipfile,subprocess,xml.etree.ElementTree as ET,sys
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261107-161237-cpu-asset-load-stages-3ff597';gpu=root/'build/runs/20261107-160838-residency-replay-cost-b28f56'
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
target=root/'docs/acceptance/nr/evidence/2026-11-07/binary-material-images';target.mkdir(parents=True,exist_ok=True)
comparison=json.loads((out/'comparison.json').read_text());assert comparison['status']=='passed'
checks=[]
for config in ['release','debug']:
    path=out/(config+'-checks.xml');cases=ET.parse(path).findall('.//testcase')
    assert len(cases)==8 and all(c.find('failure') is None for c in cases)
    checks.append(dict(configuration=config,tests=len(cases),sha256=digest(path)))
a=[r for r in json.loads((out/'baseline-floor.json').read_text()) if r['kind']=='binding'];b=[r for r in json.loads((out/'candidate-floor.json').read_text()) if r['kind']=='binding']
assert len(a)==len(b)==2 and all(x['signature']==y['signature'] for x,y in zip(a,b))
members={}
for label,directory in [('control',out),('cpu-stages',prior),('gpu-preflight',gpu)]:
    for path in directory.iterdir():
        if path.is_file() and path.suffix.lower() in {'.json','.cpp','.py','.md','.log','.xml','.rsp'}:members[label+'/'+path.name]=path
for rel in ['src/assets/MaterialData.cpp','tests/TextureMaterialImportTests.cpp']:
    members['source/'+rel]=root/rel
archive=target/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
    for name,path in members.items():z.write(path,name)
stage=json.loads((prior/'profile.json').read_text());rows=stage['rows']
result=dict(status='implemented-functional-and-local-cost-checks-passed',sourceBase=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    comparison=comparison,additionalFloorSignaturesIdentical=True,all16MaterialSignaturesIdentical=True,checks=checks,
    originalCpuStageObservation=dict(projectStartupMs=stage['projectStartupMs'],resources=len(rows),loadGltfMs=sum(r['loadGltfMs'] for r in rows),bindingsMs=sum(r['bindingsMs'] for r in rows),jointBoundsMs=sum(r['jointBoundsMs'] for r in rows),scope='One CPU-only serial preparation observation under background activity; not paired native frame timing'),
    sourceInputs=inputs(root),productionPlayers={c:digest(root/('build/ninja-msvc-'+c)/'AzurePlayer.exe') for c in ['release','debug']},
    nativeImageStatus='pending-next-qualified-consolidated-batch',frameBenefit='not-measured',overallVisual='failed-user-review',overallPerformance='pending-original-conditions',
    gpuReplay=json.loads((gpu/'result.json').read_text()),
    sourceReference='https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html#binary-gltf-layout',
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=digest(archive),members={name:digest(path) for name,path in members.items()}))
(target/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(checks=16,materialSignatures=16,reduction=comparison['reduction'],archiveBytes=archive.stat().st_size)))
