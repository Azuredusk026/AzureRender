#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <map>
#include <mutex>
#include <string>
namespace azure_diag {
struct Entry { unsigned id,usage,properties,flushes=0; VkDeviceSize size; };
static std::mutex mutex;
static std::map<VkBuffer,Entry> entries;
static unsigned nextId=0;
inline unsigned mask(){const auto* value=std::getenv("AZURE_DIAG_DEVICE_USAGE");return value?static_cast<unsigned>(std::strtoul(value,nullptr,0)):0;}
inline std::filesystem::path directory(){const auto* value=std::getenv("AZURE_DIAG_UPLOAD_DIR");return value?std::filesystem::path(value):std::filesystem::path{};}
inline void remember(const azurerender::rhi::GpuBuffer& buffer,VkBufferUsageFlags usage,bool mapped,VmaAllocator allocator){
    if(!mapped||!(usage&0x1fcU)||directory().empty())return;
    std::lock_guard<std::mutex> lock(mutex);VkMemoryPropertyFlags flags{};vmaGetAllocationMemoryProperties(allocator,buffer.allocation,&flags);
    entries.emplace(buffer.buffer,Entry{nextId++,usage,flags,0,buffer.size});
}
inline void forget(VkBuffer buffer){std::lock_guard<std::mutex> lock(mutex);entries.erase(buffer);}
inline void dump(const azurerender::rhi::GpuBuffer& buffer,VkDeviceSize offset,VkDeviceSize size){
    std::lock_guard<std::mutex> lock(mutex);const auto found=entries.find(buffer.buffer);if(found==entries.end())return;
    auto& e=found->second;const auto count=size==VK_WHOLE_SIZE?buffer.size-offset:size;
    if(offset>buffer.size||count>buffer.size-offset||count>64*1024*1024)throw std::runtime_error("Invalid private upload audit range");
    const auto dir=directory();std::filesystem::create_directories(dir);const auto stem=std::to_string(e.id)+"-"+std::to_string(offset)+"-"+std::to_string(count);
    std::ofstream file(dir/(stem+".bin"),std::ios::binary|std::ios::trunc);file.write(static_cast<const char*>(buffer.mapped)+offset,static_cast<std::streamsize>(count));if(!file)throw std::runtime_error("Private upload audit write failed");
    std::ofstream meta(dir/(stem+".txt"));meta<<e.id<<' '<<e.usage<<' '<<e.properties<<' '<<e.size<<' '<<offset<<' '<<count<<' '<<++e.flushes<<'\n';
}
}
