from pathlib import Path
import subprocess,sys,json,os,time
import numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest;from run_playable_performance import freeze_products;from artifact_budget import check
assert check(root/'build',run=out,planned=256*1024**2)['allowed'];source=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe');player=out/'AzurePlayer.exe';private=json.loads((out/'private-inputs.json').read_text());assert digest(player)==private['executableSha256'];products[str(player)]=digest(player)
parent=root/'build/runs/20261107-141433-mapped-device-buffers-67ee70';frozen=json.loads((parent/'image/frozen-inputs.json').read_text())['project']
def mounted():
 result={};shared={}
 for p in frozen:
  path=Path(p);st=path.stat();key=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
  if key not in shared:shared[key]=digest(path)
  result[p]=shared[key]
 return result
assert mounted()==frozen;(out/'frozen-inputs.json').write_text(json.dumps(dict(source=source,products=products,project=frozen),indent=2));print('Frozen one private binary and 1729 project files',flush=True)
template=json.loads((parent/'image/command.json').read_text());reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames';results=[]
for mode,mask in [('host','0'),('device','0x1fc')]:
 folder=out/mode;folder.mkdir();command=list(template);command[0]=str(player);command.extend(['--resource-root',str(root/'build/ninja-msvc-release')]);command[command.index('--capture-dir')+1]=str(folder/'frames');command[command.index('--runtime-report')+1]=str(folder/'runtime.json');(folder/'command.json').write_text(json.dumps(command,indent=2));env=dict(os.environ);env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',AZURE_DIAG_DEVICE_USAGE=mask,AZURE_DIAG_UPLOAD_DIR=str(folder/'uploads'));env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH'];si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
 with (folder/'stdout.log').open('wb') as stdout,(folder/'stderr.log').open('wb') as stderr:p=subprocess.run(command,cwd=folder,env=env,startupinfo=si,stdout=stdout,stderr=stderr,timeout=900)
 assert p.returncode==0,(folder/'stderr.log').read_text(errors='replace')[-4000:]
 frames=[]
 for path in sorted((folder/'frames').glob('frame_*.png')):
  current=np.asarray(Image.open(path).convert('RGB'));original=np.asarray(Image.open(reference/path.name).convert('RGB'));delta=np.abs(current.astype(np.int16)-original.astype(np.int16));row=dict(frame=path.name,sha256=digest(path),changedPixels=int(np.any(delta,axis=2).sum()),maxByte=int(delta.max()))
  if mode=='device':
   host=np.asarray(Image.open(out/'host/frames'/path.name).convert('RGB'));row['changedFromHost']=int(np.any(current!=host,axis=2).sum())
  frames.append(row)
 log=(folder/'stdout.log').read_text(errors='replace')+(folder/'stderr.log').read_text(errors='replace');zero='Allocator after unload: buffers=0 images=0' in log;clean=not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-']);row=dict(mode=mode,mask=mask,seconds=time.monotonic()-start,executableSha256=digest(player),frames=frames,zeroAllocator=zero,validationClean=clean,uploadFiles=len(list((folder/'uploads').glob('*.bin'))));results.append(row);(out/'pair-results.json').write_text(json.dumps(results,indent=2));print(json.dumps(row),flush=True)
 assert len(frames)==4 and zero and clean
 if mode=='host' and any(r['changedPixels'] for r in frames):break
assert inputs(root)==source and all(digest(Path(p))==h for p,h in products.items()) and mounted()==frozen
(out/'pair-invariants.json').write_text(json.dumps(dict(sourceAndProductsUnchanged=True,allMountedBytesUnchanged=True,oneExecutable=True,gpuTimingEnabled=False),indent=2));print('Pair input and production invariants verified',flush=True)
