from pathlib import Path
import json,zipfile,hashlib,numpy as np
out=Path(__file__).resolve().parent;root=out.parents[2];pair=json.loads((out/'pair-results.json').read_text());assert len(pair)==2 and all(all(f['changedPixels']==0 for f in r['frames']) for r in pair);rows=json.loads((out/'upload-comparison.json').read_text())
for r in rows:
 a=(out/'host/uploads'/r['file']).read_bytes();b=(out/'device/uploads'/r['file']).read_bytes();active=433504 if r['bytes']==834272 else len(a);assert a[:active]==b[:active];r['checkedActiveBytes']=active;r['activeBytesIdentical']=True
e=root/'docs/acceptance/nr/evidence/2026-11-07/residency-runtime-control';e.mkdir(parents=True,exist_ok=True)
changed={r['file'] for r in rows if r['changedBytes']}
with zipfile.ZipFile(e/'control.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.rglob('*'):
  if not p.is_file() or p.suffix in ['.exe','.obj','.pdb','.map','.lib','.png']:continue
  if p.parent==out/'device/uploads' and p.suffix=='.bin' and p.name not in changed:continue
  z.write(p,p.relative_to(out))
p=e/'control.zip';r=dict(status='both-policies-compatible-with-upload-readback',pair=pair,uploadRanges=rows,sourceAndProductsInvariant=json.loads((out/'pair-invariants.json').read_text()),failedUninstrumentedCandidateExplained=False,observationMayAffectOrderingOrScheduling=True,productionChanged=False,nextHypothesis='Remove per-upload reading and locking; isolate explicit host-write publication in the same binary',archive=dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));(e/'results.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(status=r['status'],archiveBytes=p.stat().st_size)))
