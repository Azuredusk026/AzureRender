from pathlib import Path
import json,subprocess,sys
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release';host=root/'build/runs/20261107-042805-host-scene-preparation-34e27e'
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
manifest=json.loads((build/'build-provenance.json').read_text());verify(root,manifest);source=inputs(root)
original=json.loads((host/'compile.json').read_text())['command'];rows=[]
for name in ['GeometryControls','MotionPoseDataReference']:
 command=list(original)
 for i,v in enumerate(command):
  if v.startswith('/Fo'):command[i]='/Fo'+str(out/(name+'.obj'))
  elif v.startswith('/Fd'):command[i]='/Fd'+str(out/(name+'.pdb'))
 command[-1]=str(out/(name+'.cpp'))
 with (out/(name+'-compile.log')).open('wb') as log:r=subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 rows.append(dict(name=name,command=command,exitCode=r.returncode));(out/'controls-compile.json').write_text(json.dumps(rows,indent=2))
 assert r.returncode==0,(out/(name+'-compile.log')).read_text(errors='replace')[-4000:]
rsp=(host/'link.rsp').read_text().replace('"'+str(host/'AzureRenderApp.obj')+'" ','').replace('CMakeFiles\\AzurePlayer.dir\\src\\player\\main.cpp.obj','')
rsp=' '.join('"'+str(out/(name+'.obj'))+'"' for name in ['GeometryControls','MotionPoseDataReference'])+' '+rsp.replace(str(host/'AzurePlayer'),str(out/'GeometryControls'))
(out/'controls-link.rsp').write_text(rsp)
with (out/'controls-link.log').open('wb') as log:r=subprocess.run(['D:/Tools/VS2022BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/link.exe','@'+str(out/'controls-link.rsp')],cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(out/'controls-link.log').read_text(errors='replace')[-4000:]
assert source==inputs(root);verify(root,manifest)
(out/'controls-build.json').write_text(json.dumps(dict(executableSha256=digest(out/'GeometryControls.exe'),productionUnchanged=True,compile=rows),indent=2))
print('Independent frozen-reference controls linked; production preserved',flush=True)
