from pathlib import Path
import json,os,shutil,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2]
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
manifest=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text());verify(root,manifest);source=inputs(root)
hero=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/content-character/hero-idle-opaque-overlays.glb'
camera=root/'build/runs/20261107-042805-host-scene-preparation-34e27e/image/frames/capture_manifest.json'
shutil.copy2(camera,out/'native-camera.json')
frozen={str(p):digest(p) for p in [hero,camera,out/'native-camera.json',out/'motion-identities.json',out/'GeometryControls.exe',out/'GeometryControls.cpp',out/'MotionPoseDataReference.cpp',out/'MotionPoseDataReference.hpp']}
command=[str(out/'GeometryControls.exe'),str(hero),str(out/'motion-identities.json'),str(out/'native-camera.json')]
env=os.environ.copy();env['PATH']=str(root/'build/ninja-msvc-release')+';'+env.get('PATH','');start=time.monotonic()
with (out/'controls-output.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(r.returncode,(out/'controls-output.log').read_text(errors='replace')[-4000:])
result=json.loads((out/'controls-output.log').read_text().splitlines()[-1]);assert result['indexBytesEqual'] and result['worldPositionBytesEqual'] and result['motionWordsEqualToFrozenImplementation']
assert source==inputs(root) and all(digest(Path(p))==h for p,h in frozen.items());verify(root,manifest)
result.update(sourceBase='adfdc00-with-dynamic-geometry-preparation',seconds=time.monotonic()-start,command=command,inputs=frozen,productionUnchanged=True)
(out/'controls-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
