from pathlib import Path
import json
out=Path(__file__).resolve().parent;root=out.parents[2]
for suffix in ['hpp','cpp']:
 source=(out/f'original-source/src/render/MotionPoseData.{suffix}').read_text()
 source=source.replace('namespace azurerender {','namespace azurerender::motion_reference {')
 source=source.replace('#include "MotionPoseData.hpp"','#include "MotionPoseDataReference.hpp"').replace('#include "LinearMath.hpp"','#include "render/LinearMath.hpp"')
 (out/('MotionPoseDataReference.'+suffix)).write_text(source)
scene=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/scene/joint-dynamic-loop-v2.azurelevel'
doc=json.loads(scene.read_text());nodes=doc.get('scene',doc)['nodes'];ids=[n['id'] for n in nodes if n.get('resourceId')]
if len(ids)<871:ids=[n['id'] for n in nodes]
assert len(set(ids))==len(ids) and len(ids)>=871
(out/'motion-identities.json').write_text(json.dumps(dict(source=str(scene),scope='871 ordered project node identifiers; controlled static shapes plus actual hero joints',ids=ids[:871]),indent=2))
print('Prepared independent frozen motion implementation and project identity fixture')
