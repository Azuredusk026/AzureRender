from pathlib import Path
import json,shutil,sys,zipfile
out=Path(__file__).resolve().parent;root=out.parents[2]
evidence=root/'docs/acceptance/nr/evidence/2026-11-07/dynamic-geometry-preparation';evidence.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
build=root/'build/ninja-msvc-release';provenance=json.loads((build/'build-provenance.json').read_text());verify(root,provenance)
before=json.loads((out/'baseline-products.json').read_text());source=inputs(root)
changes={p:h for p,h in source.items() if before['source'].get(p)!=h}
programs={p.name:digest(p) for p in (build/'shaders').glob('*.spv')};assert programs==before['programs'] and len(programs)==663
pair={r:json.loads((out/('performance-'+r)/'results.json').read_text()) for r in ['baseline','candidate']}
image=json.loads((out/'image/results.json').read_text());assert image['status']=='passed'
controls=json.loads((out/'controls-results.json').read_text())
summary=dict(schemaVersion=1,status='adopted-diagnostic-cpu-improvement',sourceBase='adfdc00',localControl=controls,
 serialControl=json.loads((out/'serial-controls-results.json').read_text()),qualification=json.loads((out/'qualification.json').read_text()),
 native=dict(baseline=pair['baseline'],candidate=pair['candidate'],savedCpuMeanMs=pair['baseline']['cpu']['mean']-pair['candidate']['cpu']['mean'],savedCpuP95Ms=pair['baseline']['cpu']['p95']-pair['candidate']['cpu']['p95'],cpuMeanReduction=1-pair['candidate']['cpu']['mean']/pair['baseline']['cpu']['mean'],all663ProgramsByteIdentical=True,gpuBenefitClaimed=False,formalAcceptance=False),
 image=image,checks=json.loads((out/'build-checks.json').read_text()),batch=json.loads((out/'validation-batch.json').read_text()),
 required=dict(cpuP95Ms=8,gpuP95Ms=16.6,samples=1800,stablePowerWatts=80,overallVisual='failed-user-review'),
 limitations=['Motion local control uses actual 871 object identities with controlled joint and morph shapes, not a complete captured native pose set.','Motion local control covers history staging and packing; renderer material and draw preparation are outside its timing.','Serial and final parallel implementations each received an associated build and seven checks.','Candidate telemetry includes one software thermal slowdown observation.','The required all-observation 80 W condition remains failed.','Short native samples do not satisfy formal performance acceptance.'])
candidate=out/'candidate-source'
tests=['tests/TransparentTopologyTests.cpp','tests/MotionPoseDataTests.cpp']
for name in list(changes)+tests:
 p=candidate/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,p)
(out/'final-build-provenance.json').write_text(json.dumps(provenance,indent=2))
archive=evidence/'measurements.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(out.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(out)
  if any(v in rel.parts for v in ['baseline','__pycache__','.azure','shaders']):continue
  if p.suffix.lower() in ['.py','.json','.log','.xml','.cpp','.hpp','.inc','.diff','.azureproject','.azurelevel']:z.write(p,str(rel))
summary['archive']=dict(file=archive.name,bytes=archive.stat().st_size,sha256=digest(archive))
(evidence/'results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
manifest=dict(schemaVersion=1,kind='NativeOptimizationEvidence',sourceBase='adfdc00',status=summary['status'],sourceChanges=changes,tests={name:digest(root/name) for name in tests},configuration='Release',buildProvenanceSha256=digest(build/'build-provenance.json'),buildScope=provenance['buildScope'],playerSha256=digest(build/'AzurePlayer.exe'),programCount=663,allProgramsByteIdentical=True,results=dict(file='results.json',sha256=digest(evidence/'results.json')),archive=summary['archive'],phaseChecksPassed=True,formalPerformanceAccepted=False,overallVisualAccepted=False)
(evidence/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps(dict(status=summary['status'],savedCpuMeanMs=summary['native']['savedCpuMeanMs'],savedCpuP95Ms=summary['native']['savedCpuP95Ms'],archive=summary['archive']),ensure_ascii=False),flush=True)
