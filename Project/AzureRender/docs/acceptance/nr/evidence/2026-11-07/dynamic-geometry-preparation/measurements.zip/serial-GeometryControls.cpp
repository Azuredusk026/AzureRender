#include "render/TransparentTopology.hpp"
#include "render/MotionPoseData.hpp"
#include "MotionPoseDataReference.hpp"
#include "render/MaterialPipelinePolicy.hpp"
#include "assets/AssetDeformation.hpp"
#include "scene/TransformMath.hpp"
#include <chrono>
#include <cstring>
#include <fstream>
#include <iostream>
#include <nlohmann/json.hpp>
using namespace azurerender;
using namespace azurerender::internal;
namespace reference=azurerender::motion_reference;
struct OriginalScratch {
    std::vector<Vector3> positions;std::vector<std::uint8_t> prepared;
    std::vector<std::uint32_t> order;std::vector<float> depths;DepthOrderWorkspace sort;
};
void originalGeometry(const LoadedAsset& mesh,const AssetPose& pose,const Matrix4& model,
    const std::vector<TransparentPrimitiveRange>& ranges,const Vector3& camera,const Vector3& forward,
    std::vector<std::uint32_t>& output,OriginalScratch& scratch){
    scratch.positions.resize(mesh.vertices.size());scratch.prepared.assign(mesh.vertices.size(),0);
    const auto vertex=[&](std::uint32_t index){if(scratch.prepared.at(index))return scratch.positions[index];
        scratch.positions[index]=transformPosition(model,deformedVertexPosition(mesh,index,&pose,{0,0}));
        scratch.prepared[index]=1;return scratch.positions[index];};
    std::size_t offset=0;
    for(const auto& range:ranges){const auto count=range.indexCount/3;scratch.order.resize(count);scratch.depths.resize(count);
        for(std::uint32_t triangle=0;triangle<count;++triangle){scratch.order[triangle]=triangle;const auto base=range.firstIndex+triangle*3;
            const auto a=vertex(mesh.indices[base]),b=vertex(mesh.indices[base+1]),c=vertex(mesh.indices[base+2]);
            const Vector3 center={(a[0]+b[0]+c[0])*(1.F/3.F),(a[1]+b[1]+c[1])*(1.F/3.F),(a[2]+b[2]+c[2])*(1.F/3.F)};
            scratch.depths[triangle]=dot(subtract(center,camera),forward);}
        stableDepthOrder(scratch.order,scratch.depths,scratch.sort);
        for(std::uint32_t triangle=0;triangle<count;++triangle){const auto base=range.firstIndex+scratch.order[triangle]*3;
            for(unsigned corner=0;corner<3;++corner)output[offset+triangle*3+corner]=mesh.indices[base+corner];}
        offset+=range.indexCount;
    }
}
reference::MotionPoseState referencePose(const MotionPoseState& value){
    reference::MotionPoseState result;result.identity.node=value.identity.node;result.identity.geometry=value.identity.geometry;result.identity.replica=value.identity.replica;
    result.model=value.model;result.joints=value.joints;result.morphWeights=value.morphWeights;result.legacyMorph=value.legacyMorph;
    result.vertexCount=value.vertexCount;result.morphTableBase=value.morphTableBase;return result;
}
int main(int argc,char** argv){try{
    if(argc!=4)return 2;
    auto mesh=loadGltfAsset(argv[1]);PreparedAssetAnimations curves(mesh);std::ifstream identitiesFile(argv[2]),cameraFile(argv[3]);
    const auto identityData=nlohmann::json::parse(identitiesFile),cameraData=nlohmann::json::parse(cameraFile);
    const auto names=identityData.at("ids").get<std::vector<std::string>>();
    const Vector3 camera=cameraData.at("qaCameraPosition").get<Vector3>();
    const Vector3 target=cameraData.at("qaCameraTarget").get<Vector3>();const auto forward=normalize(subtract(target,camera));
    const auto model=scene::composeTrs({1.2F,-.5F,.8F},{17,-11,3},{.95F,1.1F,.9F});
    std::vector<TransparentPrimitiveRange> ranges;std::size_t total=0;
    for(const auto& primitive:mesh.primitives){const auto& material=mesh.materials[primitive.materialIndex];
        if(material.alphaMode==AssetAlphaMode::Blend&&!opaqueSurfaceOverlay(material)){ranges.push_back({primitive.firstIndex,primitive.indexCount});total+=primitive.indexCount;}}
    if(!total)throw std::runtime_error("Actual hero transparent input is empty");
    const auto topology=prepareTransparentTopology(mesh.indices,mesh.vertices.size(),ranges);
    OriginalScratch oldScratch;TransparentTopologyWorkspace compact;std::vector<std::uint32_t> oldIndices(total),newIndices(total);
    MotionPoseHistory currentHistory;reference::MotionPoseHistory originalHistory;
    std::vector<MotionPoseState> poses(names.size());std::vector<reference::MotionPoseState> oldPoses(names.size());
    for(std::size_t i=0;i<poses.size();++i){auto& pose=poses[i];pose.identity.node=names[i];pose.identity.geometry=static_cast<unsigned>(i%374);
        pose.vertexCount=3;pose.joints={motionIdentityMatrix()};pose.model[12]=float(i)*.01F;}
    poses[0].vertexCount=static_cast<unsigned>(mesh.vertices.size());poses[0].morphWeights={.1F,.2F};poses[0].morphTableBase=16;
    double geometryBefore=0,geometryAfter=0,motionBefore=0,motionAfter=0;unsigned measured=0;std::uint64_t submission=0;
    const auto elapsed=[](auto begin){return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();};
    for(unsigned frame=0;frame<20;++frame){
        auto pose=sampleAnimationPose(mesh,0,float(310+frame)/60.F,true,&curves);poses[0].joints=pose.jointMatrices;
        poses[0].model=model;poses[0].model[12]+=.01F*float(frame);
        for(std::size_t i=0;i<poses.size();++i)oldPoses[i]=referencePose(poses[i]);
        for(unsigned round=0;round<4;++round){
            const auto geometry=[&](bool candidate){const auto begin=std::chrono::steady_clock::now();
                if(candidate)writeSortedTransparentIndices(topology,[&](std::uint32_t index){return transformPosition(model,deformedVertexPosition(mesh,index,&pose,{0,0}));},camera,forward,newIndices.data(),compact);
                else originalGeometry(mesh,pose,model,ranges,camera,forward,oldIndices,oldScratch);
                return elapsed(begin);};
            double a,b;if(round&1){a=geometry(false);b=geometry(true);}else{b=geometry(true);a=geometry(false);}
            if(oldIndices!=newIndices)throw std::runtime_error("Transparent index bytes differ");
            for(std::size_t i=0;i<topology.vertices.size();++i)
                if(std::memcmp(compact.worldPositions[i].data(),oldScratch.positions[topology.vertices[i]].data(),sizeof(Vector3)))throw std::runtime_error("World position bytes differ");
            MotionPoseView view;view.cameraPosition=camera;reference::MotionPoseView oldView;oldView.cameraPosition=camera;
            PackedMotionPoseFrame packed;reference::PackedMotionPoseFrame oldPacked;++submission;
            const auto motion=[&](bool candidate){const auto begin=std::chrono::steady_clock::now();
                if(candidate){currentHistory.stageReusable(poses,view);packed=currentHistory.pack(motionIdentityMatrix(),submission-1,128ULL*1024*1024);if(!currentHistory.commit(submission))throw std::runtime_error("Candidate commit failed");}
                else{originalHistory.stage(oldPoses,oldView);oldPacked=originalHistory.pack(reference::motionIdentityMatrix(),submission-1,128ULL*1024*1024);if(!originalHistory.commit(submission))throw std::runtime_error("Original commit failed");}
                return elapsed(begin);};
            double c,d;if(round&1){c=motion(false);d=motion(true);}else{d=motion(true);c=motion(false);}
            if(packed.words!=oldPacked.words||packed.validObjects!=oldPacked.validObjects)throw std::runtime_error("Motion words differ from frozen implementation");
            if(frame>=2){geometryBefore+=a;geometryAfter+=b;motionBefore+=c;motionAfter+=d;++measured;}
        }
    }
    std::cout<<nlohmann::json{{"status","controlled"},{"rounds",measured},{"animationInputs",20},{"vertices",mesh.vertices.size()},
        {"transparentIndices",total},{"compactVertices",topology.vertices.size()},{"motionObjects",poses.size()},
        {"geometryBaselineMs",geometryBefore/measured},{"geometryCandidateMs",geometryAfter/measured},{"geometryReduction",1-geometryAfter/geometryBefore},
        {"motionBaselineMs",motionBefore/measured},{"motionCandidateMs",motionAfter/measured},{"motionReduction",1-motionAfter/motionBefore},
        {"indexBytesEqual",true},{"worldPositionBytesEqual",true},{"motionWordsEqualToFrozenImplementation",true},
        {"scope","Actual hero asset/animation, explicit nonidentity model and native camera; motion uses 871 project identifiers, controlled static shapes and actual hero joints; full native cost remains separate"}}.dump()<<'\n';
    return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
