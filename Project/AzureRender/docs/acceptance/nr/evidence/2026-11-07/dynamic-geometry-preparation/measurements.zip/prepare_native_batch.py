from pathlib import Path
import json
out=Path(__file__).resolve().parent;root=out.parents[2];previous=root/'build/runs/20261107-042805-host-scene-preparation-34e27e'
for name in ['capture','measure_baseline','measure_candidate']:
 s=(previous/(name+'.py')).read_text().replace('723286a-with-host-scene-caches','adfdc00-with-dynamic-geometry-preparation').replace('723286a','adfdc00').replace('Owned runtime scene snapshot and render description caches','Compact transparent preparation and reusable motion history')
 (out/(name+'.py')).write_text(s)
control=json.loads((out/'controls-results.json').read_text());cpu=json.loads((previous/'performance-candidate/results.json').read_text())['cpu']['mean']
affected=2.650+1.808
qualification=dict(kind='AffectedPreparationHotspot',affectedMeanMs=affected,referenceCpuMeanMs=cpu,affectedCpuFraction=affected/cpu,
 measuredGeometryReduction=control['geometryReduction'],measuredMotionCoreReduction=control['motionReduction'],
 expectedReducedWorkFractionAtLeast=.20,qualified=affected/cpu>=.25 and control['geometryReduction']>=.20 and control['motionReduction']>=.20,
 scope='Matched renderer preparation source, actual hero/animation geometry controls and separate ordered motion-core load; local motion does not include material input or draw construction; native whole-frame benefit remains pending')
assert qualification['qualified'];(out/'qualification.json').write_text(json.dumps(qualification,indent=2))
print('Prepared one source-qualified native batch')
