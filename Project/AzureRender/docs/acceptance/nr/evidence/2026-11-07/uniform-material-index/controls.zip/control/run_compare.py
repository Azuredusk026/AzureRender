from pathlib import Path
import subprocess,sys,json,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest;from artifact_budget import check
assert check(root/'build',run=out,planned=8388608,diagnostic=True)['allowed'];frozen=inputs(root);products={str(p):digest(p) for p in [root/'build/ninja-msvc-release/AzurePlayer.exe',*sorted((root/'build/ninja-msvc-release/shaders').glob('*.spv'))]};si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'compare-driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'compare.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=240)
assert inputs(root)==frozen and all(digest(Path(path))==value for path,value in products.items());result=json.loads((out/'compare-state.json').read_text());assert p.returncode==0,result
print(json.dumps(dict(status=result['status'],seconds=time.monotonic()-start,matchedDrawCount=result['matchedDrawCount'],allTargetsEqual=result['allTargetsEqual'],comparisons=result['comparisons'],summary=result['summary'])),flush=True)
