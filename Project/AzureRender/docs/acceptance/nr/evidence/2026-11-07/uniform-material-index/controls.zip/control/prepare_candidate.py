from pathlib import Path
import re,json,subprocess
root=Path.cwd();out=root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25';source=root/'shaders';private=out/'candidate-source';private.mkdir();text=(source/'mesh.frag').read_text();text,count=re.subn(r'nonuniformEXT\((material\.textureBase \+ [0-8]u)\)',r'\1',text);assert count==9,count;(private/'mesh.frag').write_text(text)
profile=json.loads((out/'profile.json').read_text());assert any(row['value']==1 for row in profile['recordedDynamicIndexFeature'])
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());programs={row['output']:row for row in manifest['programs']};names=sorted({v['programFile'] for v in profile['shaders'].values() if programs[v['programFile']]['source']=='mesh.frag'});rows=[]
for name in names:
 p=programs[name];command=[manifest['compiler'],*[f'-D{d}' for d in p['defines']],f'-I{private}',f'-I{source}',str(private/'mesh.frag'),'-o',str(out/name)];r=subprocess.run(command,capture_output=True,text=True);rows.append(dict(file=name,command=command,exitCode=r.returncode,stdout=r.stdout,stderr=r.stderr));(out/'candidate-build.json').write_text(json.dumps(rows,indent=2));assert r.returncode==0,r.stderr
print(json.dumps(dict(programs=names,uniformIndexReplacements=count)),flush=True)
