from pathlib import Path
import json,subprocess,os,time,sys
root=Path.cwd();out=root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25';old=root/'build/runs/20261107-042805-host-scene-preparation-34e27e';sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest;from artifact_budget import check
assert check(root/'build',run=out,planned=33554432,diagnostic=True)['allowed']
source=inputs(root);private=(root/'src/app/AzureRenderApp.cpp').read_text();needle='deviceFeatures.samplerAnisotropy=supportedSampler.samplerAnisotropy;';assert needle in private
private=private.replace(needle,needle+'\n    deviceFeatures.shaderSampledImageArrayDynamicIndexing=supportedSampler.shaderSampledImageArrayDynamicIndexing;')
(out/'AzureRenderApp.cpp').write_text(private)
command=json.loads((old/'compile.json').read_text())['command'];command=[v.replace(str(old),str(out)) for v in command]
link=(old/'link.rsp').read_text().replace(str(old),str(out));(out/'link.rsp').write_text(link)
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9')
rows=[]
for name,cmd,cwd in [('compile',['cmd','/d','/c',str(root/'tools/msvc_env.bat'),*command],root),('link',['cmd','/d','/c',str(root/'tools/msvc_env.bat'),'D:/Tools/VS2022BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/link.exe','@'+str(out/'link.rsp')],root/'build/ninja-msvc-release')]:
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 rows.append(dict(kind=name,exitCode=r.returncode,seconds=time.monotonic()-start,command=cmd));(out/'private-build.json').write_text(json.dumps(rows,indent=2));print(json.dumps({k:v for k,v in rows[-1].items() if k!='command'}),flush=True);assert r.returncode==0,(out/(name+'.log')).read_text(errors='replace')[-3000:]
assert inputs(root)==source
(out/'private-build-inputs.json').write_text(json.dumps(dict(source=source,overlay=dict(original='src/app/AzureRenderApp.cpp',originalSha256=digest(root/'src/app/AzureRenderApp.cpp'),privateSha256=digest(out/'AzureRenderApp.cpp')),playerSha256=digest(out/'AzurePlayer.exe'),intent='Enable supported core sampled-image dynamic indexing on a private diagnostic device; production source unchanged'),indent=2))
