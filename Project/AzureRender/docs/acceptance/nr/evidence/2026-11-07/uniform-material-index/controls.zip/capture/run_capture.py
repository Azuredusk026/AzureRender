from pathlib import Path
import json,subprocess,sys,time,os
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from run_playable_performance import freeze_products
verify(root,json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text()))
private=root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25';overlay=json.loads((private/'private-build-inputs.json').read_text());assert digest(private/'AzurePlayer.exe')==overlay['playerSha256'];assert digest(private/'AzureRenderApp.cpp')==overlay['overlay']['privateSha256']
source=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
frozen=json.loads((root/'build/runs/20261107-052311-dynamic-geometry-preparation-e7a5c3/image/frozen-inputs.json').read_text())['project']
def mounted():
 result={};shared={}
 for p in frozen:
  path=Path(p);st=path.stat();key=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
  if key not in shared:shared[key]=digest(path)
  result[p]=shared[key]
 return result
assert mounted()==frozen
(out/'frozen-inputs.json').write_text(json.dumps(dict(source=source,products=products,project=frozen),indent=2))
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
env=os.environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None)
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'capture_current.py')]
with (out/'capture-driver.log').open('wb') as log:
 r=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=660)
state=json.loads((out/'state.json').read_text());assert r.returncode==0 and state['status']=='captured',state
assert digest(private/'AzurePlayer.exe')==overlay['playerSha256'] and digest(private/'AzureRenderApp.cpp')==overlay['overlay']['privateSha256']
assert inputs(root)==source and all(digest(Path(p))==v for p,v in products.items()) and mounted()==frozen
used=sum(p.stat().st_size for p in out.rglob('*') if p.is_file());assert used<=2**31,used
(out/'capture-result.json').write_text(json.dumps(dict(status='captured',seconds=time.monotonic()-start,sourceBase='80f74e6-private-dynamic-index-feature',diagnosticExtent=[1280,720],formalAcceptance=False,sourceUnchanged=True,productsUnchanged=True,mountedInputsUnchanged=True,usedBytes=used,capture=state),indent=2))
print(json.dumps(dict(status='captured',seconds=time.monotonic()-start,usedBytes=used)),flush=True)
