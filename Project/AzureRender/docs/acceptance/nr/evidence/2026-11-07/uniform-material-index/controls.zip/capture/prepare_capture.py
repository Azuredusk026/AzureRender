from pathlib import Path
import json,sys,shutil
root=Path.cwd();out=root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea';old=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc';private=root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25'
s=(old/'capture_current.py').read_text().replace('20261107-061745-current-gpu-cost-2de6bc',out.name).replace("sourceBase='35cc28f'","sourceBase='80f74e6-private-dynamic-index-feature'")
s=s.replace("player=root/'build/ninja-msvc-release/AzurePlayer.exe';args=['--project'", "player=root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/AzurePlayer.exe';args=['--resource-root',str(root/'build/ninja-msvc-release'),'--project'")
s=s.replace("('VK_LAYER_PATH'", "('PATH',str(root/'build/ninja-msvc-release')+';'+__import__('os').environ.get('PATH','')),('VK_LAYER_PATH'")
(out/'capture_current.py').write_text(s)
s=(old/'run_capture.py').read_text().replace("sourceBase='35cc28f'","sourceBase='80f74e6-private-dynamic-index-feature'")
s=s.replace("source=inputs(root);products=", "private=root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25';overlay=json.loads((private/'private-build-inputs.json').read_text());assert digest(private/'AzurePlayer.exe')==overlay['playerSha256'];assert digest(private/'AzureRenderApp.cpp')==overlay['overlay']['privateSha256']\nsource=inputs(root);products=")
s=s.replace("assert inputs(root)==source and", "assert digest(private/'AzurePlayer.exe')==overlay['playerSha256'] and digest(private/'AzureRenderApp.cpp')==overlay['overlay']['privateSha256']\nassert inputs(root)==source and")
(out/'run_capture.py').write_text(s)
print('Prepared one legal-device capture with frozen production programs and shared assets')
