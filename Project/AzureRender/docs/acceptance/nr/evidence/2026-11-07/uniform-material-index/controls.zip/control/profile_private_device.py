from pathlib import Path
import sys,json,hashlib,traceback,collections,time
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25';g=root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea';state=json.loads((g/'state.json').read_text());cap=None;c=None;report=dict(status='starting');start=time.monotonic()
def fields(o):return {str(o.GetChild(i).name):o.GetChild(i) for i in range(o.NumChildren())}
def rid(o):return str(o.AsResourceId())
def scan(o,trail=''):
 path=trail+'/'+str(o.name)
 if 'shaderSampledImageArrayDynamicIndexing' in str(o.name):feature.append(dict(path=path,value=int(o.data.basic.u)))
 for i in range(o.NumChildren()):scan(o.GetChild(i),path)
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded;sf=c.GetStructuredFile();pipelines={};objects={};bound={};draws={};feature=[]
 for index,ch in enumerate(sf.chunks):
  name=str(ch.name)
  if 'Device' in name and name in ['vkCreateDevice','System::DriverInitialisation','Internal::Initialise']:scan(ch)
  if name=='vkCreateGraphicsPipelines':
   f=fields(ch);info=fields(f['CreateInfo']);stages={}
   for j in range(info['pStages'].NumChildren()):
    stage=fields(info['pStages'].GetChild(j));stages[str(int(stage['stage'].data.basic.u))]=rid(stage['module']);objects[rid(stage['module'])]=stage['module'].AsResourceId()
   objects[rid(f['Pipeline'])]=f['Pipeline'].AsResourceId();blend=fields(info['pColorBlendState']);depth=fields(info['pDepthStencilState']);pipelines[rid(f['Pipeline'])]=dict(stages=stages,renderPass=rid(info['renderPass']),colorAttachments=int(blend['attachmentCount'].data.basic.u),depthWrite=bool(depth['depthWriteEnable'].data.basic.u))
  elif name=='vkCmdBindPipeline':
   f=fields(ch);bound[(rid(f['commandBuffer']),int(f['pipelineBindPoint'].data.basic.u))]=rid(f['pipeline'])
  elif name in ['vkCmdDraw','vkCmdDrawIndexed','vkCmdDrawIndexedIndirect','vkCmdDrawIndirect']:
   f=fields(ch);draws[index]=bound.get((rid(f['commandBuffer']),0),'unbound')
 actions={};parents={}
 def walk(items,parent=None):
  for a in items:actions[int(a.eventId)]=a;parents[int(a.eventId)]=parent;walk(a.children,int(a.eventId))
 walk(c.GetRootActions());c.FetchCounters([rd.GPUCounter.EventGPUDuration]);measured=c.FetchCounters([rd.GPUCounter.EventGPUDuration]);measurements=[];rows=[];groups=collections.defaultdict(lambda:dict(events=0,milliseconds=0.0));unmapped=[];shaders={};programs=collections.defaultdict(list)
 for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv'):programs[hashlib.sha256(p.read_bytes()).hexdigest()].append(p.name)
 for value in measured:
  event=int(value.eventId);a=actions[event];kind='dispatch' if a.flags&rd.ActionFlags.Dispatch else 'draw' if a.flags&rd.ActionFlags.Drawcall else 'other';measurements.append(dict(event=event,seconds=float(value.value.d),kind=kind,shader='uninspected'))
  if kind!='draw' or a.children:continue
  current=event;pipeline=None
  while current is not None and pipeline is None:
   for api in reversed(actions[current].events):
    if int(api.chunkIndex) in draws:pipeline=draws[int(api.chunkIndex)];break
   current=parents[current]
  if pipeline not in pipelines:unmapped.append(event);continue
  p=pipelines[pipeline];fragment=p['stages'].get('16','ResourceId::0');file=None
  if fragment!='ResourceId::0':
   if fragment not in shaders:
    entry=rd.ShaderEntryPoint();entry.name='main';entry.stage=rd.ShaderStage.Pixel;r=c.GetShader(objects[pipeline],objects[fragment],entry);assert r
    sha=hashlib.sha256(bytes(r.rawBytes)).hexdigest();names=programs.get(sha,[]);assert names,(fragment,sha)
    shaders[fragment]=dict(sha256=sha,programFile=sorted(names)[0],matchingPrograms=sorted(names),pipeline=pipeline)
   file=shaders[fragment]['programFile']
  measurements[-1]['shader']=fragment;row=dict(event=event,pipeline=pipeline,fragment=fragment,program=file,milliseconds=float(value.value.d)*1000,**{k:v for k,v in p.items() if k!='stages'});rows.append(row);key=file or fragment;group=groups[key];group['events']+=1;group['milliseconds']+=row['milliseconds']
 assert not unmapped,unmapped
 report=dict(status='profiled',seconds=time.monotonic()-start,captureSha256=state['captureSha256'],scope='Full recorded pipeline bindings and direct shader reflection, with two replay duration sweeps and no SetFrameEvent inspection loops. Native frame acceptance remains separate.',recordedDynamicIndexFeature=feature,deviceChunkNames=sorted({str(ch.name) for ch in sf.chunks if 'Device' in str(ch.name) or 'Init' in str(ch.name)})[:40],mappedDrawEvents=len(rows),shaders=shaders,measurements=measurements,rows=rows,groups=sorted([dict(program=k,**v) for k,v in groups.items()],key=lambda r:r['milliseconds'],reverse=True),sumEventMs=sum(v['seconds']*1000 for v in measurements))
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'profile.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='profiled' else 1)
