from pathlib import Path
import json,sys,subprocess
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs
assert check(root/'build',run=out,planned=24*1024**2,diagnostic=True)['allowed']
(out/'source-inputs.json').write_text(json.dumps(inputs(root),indent=2))
helper=(root/'shaders/shadow_compare.glsl').read_text();needle='    return clamp(vec4(radius+.5)-sqrt(x*x+y*y),vec4(0),vec4(1));';assert needle in helper
body='''    vec4 squared=x*x+y*y;
    float edge=radius+.5;
    // 2^-18 relative margin covers the inherited reciprocal/inverse-square-root error.
    float outerSquared=edge*edge*1.000003814697265625;
    if(all(greaterThan(squared,vec4(outerSquared))))return vec4(0);
    return clamp(vec4(edge)-sqrt(squared),vec4(0),vec4(1));'''
normal=helper.replace(needle,body)
folder=out/'counts';folder.mkdir(exist_ok=True)
counter=normal.replace('vec4 shadowDiskQuadWeights(', 'uint azQuadTotal=0u,azQuadSkipped=0u;\nvec4 shadowDiskQuadWeights(',1)
counter=counter.replace('    vec4 squared=x*x+y*y;', '    ++azQuadTotal;vec4 squared=x*x+y*y;',1)
counter=counter.replace('if(all(greaterThan(squared,vec4(outerSquared))))return vec4(0);', 'if(all(greaterThan(squared,vec4(outerSquared)))){++azQuadSkipped;return vec4(0);}',1)
(out/'shadow_compare.glsl').write_text(normal);(folder/'shadow_compare.glsl').write_text(counter)
text=(root/'shaders/mesh.frag').read_text();(out/'mesh.frag').write_text(text)
assert text.count('void main()')==1
text=text.replace('void main()','void azOriginalMain()',1)+'\nvoid main(){azOriginalMain();outputColor=vec4(float(azQuadTotal),float(azQuadSkipped),0,1);}\n'
(folder/'mesh.frag').write_text(text)
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());programs={p['output']:p for p in manifest['programs']}
prior=root/'build/runs/20261107-122133-material-contribution-cost-c567b5'
names=sorted({r['file'] for r in json.loads((prior/'control-builds.json').read_text())});rows=[]
for name in names:
 for kind,where in [('candidate',out),('counts',folder)]:
  if kind=='counts' and not name.startswith('character_snapshot'):continue
  p=programs[name];command=[manifest['compiler'],*[f'-D{d}' for d in p['defines']],f'-I{where}',f'-I{root/"shaders"}',str(where/'mesh.frag'),'-o',str(where/name)]
  r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr
  validator=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(where/name)];v=subprocess.run(validator,capture_output=True,text=True);assert v.returncode==0,v.stderr
  rows.append(dict(kind=kind,file=name,command=command,validationCommand=validator,exitCode=r.returncode,stdout=r.stdout,stderr=r.stderr))
(out/'builds.json').write_text(json.dumps(rows,indent=2))
(folder/'builds.json').write_text(json.dumps([r for r in rows if r['kind']=='counts'],indent=2))
prior=root/'build/runs/20261107-195033-shadow-range-work-f9476d'
script=(prior/'capture_ranges.py').read_text().replace("root/'build/runs/20261107-195033-shadow-range-work-f9476d'", "root/'build/runs/20261107-201233-shadow-disk-work-9d2d90/counts'")
script=script.replace('Functional counts in the final visible opaque snapshot. Counts exclude overwritten/occluded fragments and do not measure GPU time.','Functional disk-weight invocation and conservative empty-quad counts for final visible opaque snapshot pixels; excludes overdraw and other passes; no GPU timing.')
(folder/'capture_ranges.py').write_text(script)
runner=(prior/'run.py').read_text().replace('out=Path(__file__).resolve().parent',"run=Path(__file__).resolve().parent;out=run/'counts'").replace('run=out,planned=20','run=run,planned=20')
(out/'run_counts.py').write_text(runner)
print('Compiled',len(rows),'private programs; production remains unchanged',flush=True)
