from pathlib import Path
import sys,json,subprocess,time
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs
from gpu_environment import wait_and_record,RunEnvironmentMonitor,environment_errors
assert check(root/'build',run=out,planned=3*1024**2,diagnostic=True)['allowed']
source=inputs(root);environment=wait_and_record(out/'evaluation-environment.json',timeout=30)
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with RunEnvironmentMonitor(environment,path=out/'evaluation-environment.json'):
 with (out/'evaluation-driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'evaluate.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=300)
assert source==inputs(root);result=json.loads((out/'evaluation.json').read_text());result.update(processExitCode=p.returncode,seconds=time.monotonic()-start,productionSourceUnchanged=True,environmentErrors=environment_errors(environment))
(out/'evaluation.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:result.get(k) for k in ['status','allOutputsEqual','phases','baselineBracketRatio','allEventsMsSaved','matchedEventsMsSaved','matchedEventsMsReduction','seconds','environmentErrors','error']}),flush=True)
