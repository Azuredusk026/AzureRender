from pathlib import Path
import renderdoc as rd
import json,sys,hashlib,traceback,time
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-201233-shadow-disk-work-9d2d90'
prior=root/'build/runs/20261107-122133-material-contribution-cost-c567b5';profile=json.loads((prior/'profile.json').read_text())
state=json.loads((root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea/state.json').read_text())
report=dict(status='starting',scope='Same-capture full-attachment compatibility and local GPU replay cost. Captured 1280x720/private dynamic-index device feature; no native-frame or 80W qualification.',captureSha256=state['captureSha256']);cap=None;c=None
def save():(out/'evaluation.json').write_text(json.dumps(report,indent=2))
def outputs(events):
 rows=[]
 for event in events:
  c.SetFrameEvent(event,True)
  for slot,target in enumerate(c.GetPipelineState().GetOutputTargets()):
   if target.resource==rd.ResourceId.Null():continue
   data=bytes(c.GetTextureData(target.resource,rd.Subresource()))
   rows.append(dict(event=event,slot=slot,resource=str(target.resource),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 return rows
def sweep():
 values={int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
 return dict(allEventsMs=sum(values.values()),matchedEventsMs=sum(v for e,v in values.items() if e in matched))
def measure(label):
 row=dict(label=label,warmup=[],samples=[]);report['timings'].append(row);save()
 for attempt in range(8):
  value=sweep();row['warmup'].append(value);save()
  last=[r['allEventsMs'] for r in row['warmup'][-3:]]
  if len(last)==3 and max(last)/min(last)<=1.03:break
 else:raise RuntimeError('Continuous replay did not stabilize within eight sweeps: '+label)
 for repeat in range(3):row['samples'].append(sweep());save()
 return row
try:
 assert json.loads((out/'counts-summary.json').read_text())['skipFraction']>=.25
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 names={r['file'] for r in json.loads((out/'builds.json').read_text()) if r['kind']=='candidate'}
 shaders={k:v for k,v in profile['shaders'].items() if v['programFile'] in names};originals=[]
 matched={r['event'] for r in profile['rows'] if r['fragment'] in shaders}
 events=sorted({max(r['event'] for r in profile['rows'] if r['fragment']==key) for key in shaders})
 report.update(matchedPrograms=len(shaders),matchedDraws=len(matched),events=events,timings=[]);save()
 for key,entry in shaders.items():
  event=next(r['event'] for r in profile['rows'] if r['fragment']==key);c.SetFrameEvent(event,True);pipe=c.GetPipelineState()
  reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel);assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==entry['sha256']
  program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/entry['programFile']).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
  assert program!=rd.ResourceId.Null(),errors
  originals.append((pipe.GetShader(rd.ShaderStage.Pixel),program))
 report['baselineOutputs']=outputs(events);save()
 measure('baseline-before')
 for old,new in originals:c.ReplaceResource(old,new)
 report['candidateOutputs']=outputs(events);report['allOutputsEqual']=report['baselineOutputs']==report['candidateOutputs'];save()
 if not report['allOutputsEqual']:raise RuntimeError('Strict full-attachment hashes differ; candidate timing not started')
 measure('candidate')
 for old,new in originals:c.RemoveReplacement(old)
 report['restoredOutputs']=outputs(events);assert report['restoredOutputs']==report['baselineOutputs']
 measure('baseline-after')
 phases=[dict(label=r['label'],allEventsMs=sum(s['allEventsMs'] for s in r['samples'])/3,matchedEventsMs=sum(s['matchedEventsMs'] for s in r['samples'])/3) for r in report['timings']]
 report['phases']=phases
 for field in ['allEventsMs','matchedEventsMs']:
  baseline=(phases[0][field]+phases[2][field])/2
  report[field+'Baseline']=baseline;report[field+'Saved']=baseline-phases[1][field];report[field+'Reduction']=1-phases[1][field]/baseline
 report['baselineBracketRatio']=max(phases[0]['matchedEventsMs'],phases[2]['matchedEventsMs'])/min(phases[0]['matchedEventsMs'],phases[2]['matchedEventsMs'])
 report['status']='measured' if report['baselineBracketRatio']<=1.05 else 'unstable-bracket'
 report['debugMessages']=[str(m.description) for m in c.GetDebugMessages()];save()
 for old,new in originals:c.FreeTargetResource(new)
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='measured' else 1)
