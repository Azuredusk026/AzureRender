from pathlib import Path
import struct,json,hashlib,subprocess,collections
root=Path.cwd();out=root/'build/runs/20261107-123742-specialization-precision-analysis-44eb97';native=root/'build/runs/20261107-113035-computed-material-view-490b2c/candidate-programs';local=root/'build/runs/20261107-111830-computed-specialization-cost-b26603';rows=[]
for path in sorted((local/'dynamic-programs').glob('*.spv')):
 baseline=path.read_bytes();nativeBytes=(native/path.name).read_bytes();special=(local/path.name).read_bytes();words=list(struct.unpack('<%dI'%(len(baseline)//4),baseline));at=5;spec=None;instructions=[]
 while at<len(words):
  wc,op=words[at]>>16,words[at]&65535;assert wc>0
  if op==71 and wc>=4 and words[at+2]==1 and words[at+3]==4:spec=words[at+1]
  instructions.append((at,wc,op));at+=wc
 assert spec is not None
 changes=[]
 for at,wc,op in instructions:
  if op in [48,49] and words[at+2]==spec:words[at]=(wc<<16)|48;changes.append(at)
 patched=struct.pack('<%dI'%len(words),*words);dis=out/(path.stem+'.spvasm');r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-dis.exe',str(path),'-o',str(dis)],capture_output=True,text=True);assert r.returncode==0,r.stderr;text=dis.read_text();ops=collections.Counter(op for _,_,op in instructions)
 rows.append(dict(program=path.name,nativeCandidateMatchesDynamicDefault=baseline==nativeBytes,defaultBooleanOnlyMatchesSpecialized=patched==special,specializationLiteralWordOffsets=changes,instructions=len(instructions),defaultDx=ops[207],defaultDy=ops[208],fineDx=ops[210],fineDy=ops[211],implicitLod=ops[87],noContractionDecorations=text.count('NoContraction'),baselineSha256=hashlib.sha256(baseline).hexdigest(),nativeCandidateSha256=hashlib.sha256(nativeBytes).hexdigest(),specializedSha256=hashlib.sha256(special).hexdigest()))
(out/'frontend-comparison.json').write_text(json.dumps(dict(status='analyzed',scope='Offline SPIR-V frontend comparison only; derivative and contraction hypotheses remain unconfirmed at GPU instruction level.',rows=rows),indent=2));print(json.dumps(rows),flush=True)
