from pathlib import Path
root=Path.cwd();out=root/'build/runs/20261107-123742-specialization-precision-analysis-44eb97';q3=root/'build/runs/20261107-111830-computed-specialization-cost-b26603';s=(q3/'compare.py').read_text().replace(q3.name,out.name)
# Remove the redundant dynamic-default shader controls and every timing sweep.
s=s.replace("  dynamicProgram,dynamicErrors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/'dynamic-programs'/entry['programFile']).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert dynamicProgram!=rd.ResourceId.Null(),dynamicErrors\n  dynamicCompiled[key]=(shader,dynamicProgram)\n",'')
a=s.index(' for shader,program in dynamicCompiled.values():c.ReplaceResource(shader,program)');b=s.index(' for shader,program in compiled.values():c.ReplaceResource(shader,program)',a);s=s[:a]+s[b:]
a=s.index(" report.update(status='candidate-read',comparisons=comparisons)");b=s.index("except Exception:",a)
s=s[:a]+''' report.update(status='compared',comparisons=comparisons,allTargetsEqual=all(r['equal'] for r in comparisons),performanceCountersRun=False,scope='Functional-only explicit fine derivative control; no GPU timing counters are fetched, original captured inputs and Q3 early-depth eligibility are retained. Battery supply does not qualify performance acceptance.');save()
'''+s[b:]
(out/'compare_functional.py').write_text(s)
s=(q3/'run_compare.py').read_text().replace(q3.name,out.name).replace("out/'compare.py'","out/'compare_functional.py'").replace("state['summary']","state.get('comparisons')")
# Record current power separately from the source/product fingerprint.
s=s.replace('source=inputs(root);products=',"import ctypes\npower=(ctypes.c_ubyte*12)();assert ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(power));(out/'functional-power.json').write_text(json.dumps(dict(ac=int(power[0]),batteryPercent=int(power[2]),saver=int(power[3]),performanceCountersRun=False)))\nsource=inputs(root);products=")
(out/'run_functional.py').write_text(s)
print('Prepared one attachment-only comparison, with zero performance counter calls')
