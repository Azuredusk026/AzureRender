from pathlib import Path
import struct,json,subprocess
root=Path.cwd();out=root/'build/runs/20261107-123742-specialization-precision-analysis-44eb97';dest=out/'complete-fine';dest.mkdir();rows=[]
for p in sorted(out.glob('*.spv')):
 w=list(struct.unpack('<%dI'%(p.stat().st_size//4),p.read_bytes()));at=5;inst=[];types=set();images={};sampledTypes={};vectors={}
 while at<len(w):
  wc,op=w[at]>>16,w[at]&65535;v=w[at:at+wc];inst.append((op,v));
  if 19<=op<=39:types.add(v[1])
  if op==25:images[v[1]]=dict(dim=v[3],arrayed=v[5])
  if op==27:sampledTypes[v[1]]=v[2]
  if op==23:vectors[v[1]]=(v[2],v[3])
  at+=wc
 resultTypes={v[2]:v[1] for op,v in inst if len(v)>=3 and v[1] in types and not 19<=op<=39};nextid=w[3];result=w[:5];converted=0;skipped=[]
 for op,v in inst:
  if op==87:
   coordinate=v[4];coordinateType=resultTypes[coordinate];sampledType=resultTypes[v[3]];image=images[sampledTypes[sampledType]];mask=v[5] if len(v)>5 else 0
   assert image['dim']==1 and not image['arrayed'] and vectors[coordinateType][1]==2,(p.name,image,coordinateType)
   if mask&3:skipped.append(mask);result+=v;continue
   dx,dy=nextid,nextid+1;nextid+=2;result +=[(4<<16)|210,coordinateType,dx,coordinate,(4<<16)|211,coordinateType,dy,coordinate];new=v[:5]+[mask|4,dx,dy]+v[6:];new[0]=(len(new)<<16)|88;result+=new;converted+=1
  else:result+=v
 result[3]=nextid;target=dest/p.name;target.write_bytes(struct.pack('<%dI'%len(result),*result));r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(target)],capture_output=True,text=True);rows.append(dict(program=p.name,convertedImplicitSamples=converted,skippedImageOperandMasks=skipped,validatorExitCode=r.returncode,stderr=r.stderr));assert r.returncode==0,r.stderr
(dest/'program-validation.json').write_text(json.dumps(rows,indent=2))
s=(out/'compare_functional.py').read_text().replace("out=root/'build/runs/20261107-123742-specialization-precision-analysis-44eb97'","out=root/'build/runs/20261107-123742-specialization-precision-analysis-44eb97/complete-fine'").replace('Functional-only explicit fine derivative control','Functional-only explicit and implicit fine derivative control');(dest/'compare_functional.py').write_text(s)
s=(out/'run_functional.py').read_text();(dest/'run_functional.py').write_text(s)
print(json.dumps(rows),flush=True)
