from pathlib import Path
import json,struct,subprocess,hashlib
root=Path.cwd();out=root/'build/runs/20261107-123742-specialization-precision-analysis-44eb97';native=root/'build/runs/20261107-113035-computed-material-view-490b2c/candidate-programs';q3=root/'build/runs/20261107-111830-computed-specialization-cost-b26603';rows=[]
for path in sorted((q3/'dynamic-programs').glob('*.spv')):
 # Retain the Q3 early-depth control as an independent, recorded property.
 data=(q3/path.name).read_bytes();w=list(struct.unpack('<%dI'%(len(data)//4),data));at=5;fine=0;capability=False
 while at<len(w):
  wc,op=w[at]>>16,w[at]&65535;assert wc
  if op==17 and w[at+1]==51:capability=True
  if op in [207,208]:w[at]=(wc<<16)|(210 if op==207 else 211);fine+=1
  at+=wc
 if not capability:w[5:5]=[(2<<16)|17,51]
 target=out/path.name;target.write_bytes(struct.pack('<%dI'%len(w),*w));v=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(target)],capture_output=True,text=True);rows.append(dict(program=path.name,fineDerivativeInstructions=fine,validatorExitCode=v.returncode,stdout=v.stdout,stderr=v.stderr,sha256=hashlib.sha256(target.read_bytes()).hexdigest()));assert v.returncode==0,v.stderr
(out/'fine-derivative-programs.json').write_text(json.dumps(rows,indent=2));print(json.dumps(dict(validatedPrograms=len(rows),fineInstructionsPerProgram=[r['fineDerivativeInstructions'] for r in rows])))
