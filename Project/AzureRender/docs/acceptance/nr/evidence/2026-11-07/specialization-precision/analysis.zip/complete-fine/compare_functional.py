from pathlib import Path
import json,hashlib,sys,traceback,struct
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-123742-specialization-precision-analysis-44eb97/complete-fine';a=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc'
state=json.loads((a/'state.json').read_text());profile=json.loads((a/'events/profile.json').read_text());report=dict(status='starting',sourceBase='9979c70-GPU-programs-identical-to-35cc28f',scope='Current 720p replay; fixed observed view mode plus early tests only for validated opaque/transparent main lighting draws; native acceptance is separate',captureSha256=state['captureSha256']);cap=None;c=None
def save():(out/'compare-state.json').write_text(json.dumps(report,indent=2))
def durations():return {int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
try:
 save();cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 shaders={k:v for k,v in profile['shaders'].items() if (v.get('programFile')or'').startswith(('mesh','character_snapshot'))};compiled={};dynamicCompiled={};rows=[]
 for key,entry in shaders.items():
  event=next(r['event'] for r in profile['measurements'] if r['shader']==key);c.SetFrameEvent(event,True);pipe=c.GetPipelineState();shader=pipe.GetShader(rd.ShaderStage.Pixel)
  reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel);assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==entry['sha256']
  descriptor=pipe.GetConstantBlock(rd.ShaderStage.Pixel,0,0).descriptor
  lighting=struct.unpack('<f',bytes(c.GetBufferData(descriptor.resource,descriptor.byteOffset+64,4)))[0];assert lighting==1.0,lighting
  qa=list(struct.unpack('<4f',bytes(c.GetBufferData(descriptor.resource,descriptor.byteOffset+128,16))));assert qa[0]==0 and qa[1]==0 and qa[2]==1.0,qa
  traceMode=struct.unpack('<f',bytes(c.GetBufferData(descriptor.resource,descriptor.byteOffset+512,4)))[0]
  assert entry['programFile'].startswith('character_snapshot') or traceMode==2.0,(entry['programFile'],traceMode)
  program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/entry['programFile']).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert program!=rd.ResourceId.Null(),errors
  compiled[key]=(shader,program);rows.append(dict(shader=key,file=entry['programFile'],event=event,sceneLighting=lighting,qaParameters=qa,traceMode=traceMode,errors=errors))
 eligibility=[]
 for row in json.loads((root/'build/runs/20261107-105935-gpu-structure-cost-4249bd/lighting-inputs.json').read_text())['rows']:
  c.SetFrameEvent(row['event'],True);raw=bytes(c.GetVulkanPipelineState().pushconsts);alpha=struct.unpack_from('<I',raw,4)[0];opacity=struct.unpack_from('<f',raw,140)[0]
  assert alpha==2 or alpha==0 and opacity==1.0,(row['event'],alpha,opacity)
  eligibility.append(dict(event=row['event'],alphaMode=alpha,nodeOpacity=opacity))
 report.update(status='compiled',programs=rows,earlyEligibility=eligibility);save()
 draws=sorted((r for r in profile['measurements'] if r['kind']=='draw'),key=lambda x:x['seconds'],reverse=True)
 events=[15752,24600,26527,max(r['event'] for r in draws)]
 controls={}
 for event in events:
  c.SetFrameEvent(event,True)
  for index,target in enumerate(c.GetPipelineState().GetOutputTargets()):
   if target.resource!=rd.ResourceId.Null():controls[(event,index)]=(target.resource,bytes(c.GetTextureData(target.resource,rd.Subresource())))
 for shader,program in compiled.values():c.ReplaceResource(shader,program)
 comparisons=[]
 for (event,index),(resource,data) in controls.items():
  c.SetFrameEvent(event,True);value=bytes(c.GetTextureData(resource,rd.Subresource()));comparisons.append(dict(event=event,target=index,bytes=len(data),equal=value==data,baselineSha256=hashlib.sha256(data).hexdigest(),candidateSha256=hashlib.sha256(value).hexdigest()))
 report.update(status='compared',comparisons=comparisons,allTargetsEqual=all(r['equal'] for r in comparisons),performanceCountersRun=False,scope='Functional-only explicit and implicit fine derivative control; no GPU timing counters are fetched, original captured inputs and Q3 early-depth eligibility are retained. Battery supply does not qualify performance acceptance.');save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='compared' else 1)
