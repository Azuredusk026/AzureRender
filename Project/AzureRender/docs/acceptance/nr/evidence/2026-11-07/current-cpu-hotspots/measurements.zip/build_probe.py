from pathlib import Path
import ctypes,json,subprocess,sys,time,difflib
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';t=root/'build/runs/20261106-220323-autonomous-cleanup-performance-70496b'
manifest=json.loads((build/'build-provenance.json').read_text());verify(root,manifest);frozen=inputs(root)
source=(root/'src/scenes/CharacterSceneRenderer.cpp').read_text(encoding='utf-8');original=source
def replace(before,after):
 global source
 assert source.count(before)==1,(before,source.count(before));source=source.replace(before,after)
replace('void CharacterSceneRenderer::updateFrame(const SceneFrameData& frame) {','void CharacterSceneRenderer::updateFrame(const SceneFrameData& frame) {\n    current_probe::Session diagSession(frame.timeSeconds,frame.captureFps);current_probe::Lap diagUpdate("update.");')
for before,after in [('    updateUniformBuffer(frame);','    diagUpdate.mark("copyInput");\n    updateUniformBuffer(frame);\n    diagUpdate.mark("uniforms");'),('    rebuildSceneInstances();','    rebuildSceneInstances();\n    diagUpdate.mark("instances");'),('    prepareTransparentIndices();','    prepareTransparentIndices();\n    diagUpdate.mark("transparent");'),('    buildSceneState();','    buildSceneState();\n    diagUpdate.mark("sceneState");'),('    prepareOutlineMaskResources(nodeOpacities,recordingBuffers);','    diagUpdate.mark("recordingPreparation");\n    prepareOutlineMaskResources(nodeOpacities,recordingBuffers);\n    diagUpdate.mark("outlineResources");'),('    visibleInstances_.clear();\n    prepareMotion();','    diagUpdate.mark("snapshot");\n    visibleInstances_.clear();\n    prepareMotion();\n    diagUpdate.mark("motion");')]:replace(before,after)
replace('void CharacterSceneRenderer::rebuildSceneInstances() {','void CharacterSceneRenderer::rebuildSceneInstances() {\n    current_probe::Lap diagInstances("instances.");')
replace('    sceneInstances_.clear();\n    if (scene_.nodes.size()','    diagInstances.mark("meshBounds");\n    sceneInstances_.clear();\n    if (scene_.nodes.size()')
replace('        std::vector<std::size_t> nodeMeshKeys;','        diagInstances.mark("nodeWorld");\n        std::vector<std::size_t> nodeMeshKeys;')
replace('    materialOriginInstances_=','    diagInstances.mark("instanceModels");\n    materialOriginInstances_=')
replace('    prepareInstancePoses();','    diagInstances.mark("materialOrigins");\n    prepareInstancePoses();\n    diagInstances.mark("poses");')
replace('    visibleInstances_.clear();\n    if (cullingEnabled_)', '    diagInstances.mark("gpuCulling");\n    visibleInstances_.clear();\n    if (cullingEnabled_)')
replace('    prepareObjectShadows();','    diagInstances.mark("visibility");\n    prepareObjectShadows();\n    diagInstances.mark("objectShadows");')
replace('    allocator_->flush(instanceBuffers_[currentFrame_],0,instanceBuffers_[currentFrame_].size);','    allocator_->flush(instanceBuffers_[currentFrame_],0,instanceBuffers_[currentFrame_].size);\n    diagInstances.mark("upload");')
replace('    for (auto& instance : sceneInstances_) {\n        const auto& mesh','    for (auto& instance : sceneInstances_) {\n        current_probe::Lap diagPose("pose.");\n        const auto& mesh')
replace('        const auto& pose=*preparedPose;','        diagPose.mark("sample");\n        const auto& pose=*preparedPose;')
replace('        auto bounds = jointBounds_.at(instance.meshKey).evaluate','        diagPose.mark("weightsAndJoints");\n        auto bounds = jointBounds_.at(instance.meshKey).evaluate')
replace('        instancePoses_.push_back({','        diagPose.mark("bounds");\n        instancePoses_.push_back({')
replace('        morphWeightBase+=static_cast<std::uint32_t>(weights.size());','        morphWeightBase+=static_cast<std::uint32_t>(weights.size());\n        diagPose.mark("dispatch");')
source='#include "StageProbe.hpp"\n'+source
(out/'CharacterSceneRenderer.cpp').write_text(source,encoding='utf-8')
(out/'renderer.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),source.splitlines(True),fromfile='production',tofile='private-probe')),encoding='utf-8')
frame=(root/'src/app/AzureRenderFrame.cpp').read_text(encoding='utf-8');expected=subprocess.check_output(['git','show','a295e09:Project/AzureRender/src/app/AzureRenderFrame.cpp'],cwd=root).decode('utf-8');assert frame==expected
(out/'AzureRenderFrame.cpp').write_bytes((t/'cpu-phase-probe/AzureRenderFrame.cpp').read_bytes())
commands={'AzureRenderFrame':json.loads((t/'cpu-phase-probe/build.json').read_text())['command'],'CharacterSceneRenderer':None}
api=ctypes.WinDLL('shell32').CommandLineToArgvW;api.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)];api.restype=ctypes.POINTER(ctypes.c_wchar_p);free=ctypes.WinDLL('kernel32').LocalFree;free.argtypes=[ctypes.c_void_p]
c=ctypes.c_int();ptr=api(json.loads((a/'cpu-stage-cost/refined-original-compile-command.json').read_text()),ctypes.byref(c))
try:commands['CharacterSceneRenderer']=[ptr[i] for i in range(c.value)]
finally:free(ptr)
rows=[]
for name,args in commands.items():
 args=list(args)
 for i,v in enumerate(args):
  if v.startswith('/Fo'):args[i]='/Fo'+str(out/(name+'.obj'))
  elif v.startswith('/Fd'):args[i]='/Fd'+str(out/(name+'.pdb'))
 args[-1]=str(out/(name+'.cpp'));args.insert(-2,'/I'+str(root/('src/app' if name=='AzureRenderFrame' else 'src/scenes')))
 start=time.monotonic()
 with (out/(name+'-compile.log')).open('wb') as log:r=subprocess.run(args,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 rows.append(dict(name=name,command=args,exitCode=r.returncode,seconds=time.monotonic()-start));(out/'compile.json').write_text(json.dumps(rows,indent=2))
 assert r.returncode==0,(out/(name+'-compile.log')).read_text(errors='replace')[-2000:]
 print(name+' compiled',flush=True)
rsp=(t/'cpu-phase-probe/link.rsp').read_text().replace(str(t/'cpu-phase-probe'),str(out));rsp='"'+str(out/'CharacterSceneRenderer.obj')+'" '+rsp;(out/'link.rsp').write_text(rsp)
with (out/'link.log').open('wb') as log:r=subprocess.run(['D:/Tools/VS2022BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/link.exe','@'+str(out/'link.rsp')],cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert r.returncode==0,(out/'link.log').read_text(errors='replace')[-2500:]
assert inputs(root)==frozen;verify(root,manifest)
(out/'build.json').write_text(json.dumps(dict(sourceBase='cb82fcf',productionUnchanged=True,sourceInputs=frozen,privatePlayerSha256=digest(out/'AzurePlayer.exe'),compile=rows),indent=2));print('Private probe linked; production preserved',flush=True)
