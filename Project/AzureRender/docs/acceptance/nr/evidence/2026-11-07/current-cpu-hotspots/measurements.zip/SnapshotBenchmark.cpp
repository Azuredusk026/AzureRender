#include "runtime/LevelSession.hpp"
#include "scene/SceneDescription.hpp"
#include <chrono>
#include <iostream>
namespace azurerender{scene::SceneDescription indexedRenderDescription(const SceneDocument&);}
using namespace azurerender;
bool shadow(const std::optional<ecs::ObjectShadowComponent>& x,const std::optional<ecs::ObjectShadowComponent>& y){if(x.has_value()!=y.has_value())return false;if(!x)return true;return std::tie(x->enabled,x->center,x->halfExtents,x->normalBias,x->lightBias,x->filterRadiusX,x->filterRadiusY,x->atlasPage,x->receiverPixelOffsetX,x->receiverPixelOffsetY,x->surfaceNormalBias)==std::tie(y->enabled,y->center,y->halfExtents,y->normalBias,y->lightBias,y->filterRadiusX,y->filterRadiusY,y->atlasPage,y->receiverPixelOffsetX,y->receiverPixelOffsetY,y->surfaceNormalBias);}
bool equal(const scene::SceneDescription& a,const scene::SceneDescription& b){
 if(a.resources.size()!=b.resources.size()||a.nodes.size()!=b.nodes.size()||a.lights.size()!=b.lights.size())return false;
 for(std::size_t i=0;i<a.resources.size();++i){const auto& x=a.resources[i];const auto& y=b.resources[i];if(x.id!=y.id||x.path!=y.path||x.materials.size()!=y.materials.size())return false;
  for(const auto& p:x.materials){auto f=y.materials.find(p.first);if(f==y.materials.end()||p.second.path!=f->second.path||p.second.fingerprint!=f->second.fingerprint||p.second.textures!=f->second.textures)return false;}}
 for(std::size_t i=0;i<a.nodes.size();++i){const auto& x=a.nodes[i];const auto& y=b.nodes[i];if(x.id!=y.id||x.resourceId!=y.resourceId||x.parentId!=y.parentId||x.translation!=y.translation||x.rotation!=y.rotation||x.scale!=y.scale||x.visible!=y.visible||!shadow(x.objectShadow,y.objectShadow))return false;}
 for(std::size_t i=0;i<a.lights.size();++i){const auto& x=a.lights[i];const auto& y=b.lights[i];if(x.id!=y.id||x.nodeId!=y.nodeId||x.position!=y.position||x.color!=y.color||x.intensity!=y.intensity||x.radius!=y.radius||x.enabled!=y.enabled||nlohmann::json(x.shape)!=nlohmann::json(y.shape))return false;}
 return nlohmann::json(a.reflectionProbe)==nlohmann::json(b.reflectionProbe)&&nlohmann::json(a.irradianceVolume)==nlohmann::json(b.irradianceVolume)&&nlohmann::json(a.viewFog)==nlohmann::json(b.viewFog);
}
int main(int argc,char** argv){
 if(argc!=2)return 2;ProjectStartup startup(Project::load(std::filesystem::u8path(argv[1])));const auto& document=startup.level().scene;
 auto a=document.renderDescription();auto b=indexedRenderDescription(document);if(!equal(a,b))return 3;
 std::size_t materialNodes=0,slots=0;for(const auto& n:document.nodes){materialNodes+=!n.materialSlots.empty();slots+=n.materialSlots.size();}
 double before=0,after=0;std::size_t checksum=0;constexpr unsigned rounds=80;
 const auto measure=[&](bool indexed){const auto start=std::chrono::steady_clock::now();{auto r=indexed?indexedRenderDescription(document):document.renderDescription();checksum+=r.nodes.size()+r.resources.size();}return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();};
 for(unsigned i=0;i<rounds;++i){if(i&1){before+=measure(false);after+=measure(true);}else{after+=measure(true);before+=measure(false);}}
 std::cout<<nlohmann::json{{"scope","Actual prepared native scene; one render-description operation; GPU frame excluded"},{"nodes",document.nodes.size()},{"resources",document.resources.size()},{"materialNodes",materialNodes},{"slots",slots},{"rounds",rounds},{"baselineMs",before/rounds},{"candidateMs",after/rounds},{"reduction",1-after/before},{"identical",true},{"checksum",checksum}}.dump()<<'\n';
}
