from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2]
text=(root/'build/runs/20261107-013603-static-transparent-preparation-049ee8/measure_baseline.py').read_text()
text=text.replace("/'performance-baseline'","/'native'").replace("parent/'baseline/AzurePlayer.exe'","parent/'AzurePlayer.exe'").replace('95f0f38','cb82fcf-private-cpu-hotspots')
text=text[:text.index("\nfrozenBaseline=")]
text=text.replace("'420'","'340'").replace('==420','==340').replace('==120','==40').replace('samples=120','samples=40').replace('120samples','40samples').replace("summary['instrumented']=False","summary['instrumented']=True")
marker="frozen=inputs(root);products="
assert marker in text
text=text.replace(marker,"privateFiles={str(p):digest(p) for p in Path(__file__).resolve().parent.glob('*') if p.suffix in {'.cpp','.hpp','.exe'}};frozen=inputs(root);products=")
text+='''
assert all(digest(Path(p))==h for p,h in privateFiles.items())
renderer=[];host=[]
for line in log.splitlines():
 if '[cpu-current]' in line:renderer.append(json.loads(line[line.index('{'):]))
 if '[cpu-stages]' in line and 'host-frame' in line:host.append(json.loads(line[line.index('{'):]))
assert len(renderer)==len(host)==20,(len(renderer),len(host))
assert len({r['frame'] for r in renderer})==20
stage={k:stats([r['stagesMs'][k] for r in renderer]) for k in renderer[0]['stagesMs']}
import math
assert all(math.isfinite(v) and v>=0 for r in renderer for v in r['stagesMs'].values())
summary.update(privateFiles=privateFiles,rendererRows=renderer,hostRows=host,rendererStages=stage,hostStages={k:stats([r[k] for r in host]) for k in host[0] if k.endswith('Ms')},scope='Single current CPU stage attribution,340total frames;20instrumented observations; original formal acceptance unchanged')
(out/'results.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(dict(rendererStages=stage,hostStages=summary['hostStages'],environmentPassed=summary['environmentPassed'])),flush=True)
'''
(out/'measure.py').write_text(text)
print('Prepared one current CPU stage collection')
