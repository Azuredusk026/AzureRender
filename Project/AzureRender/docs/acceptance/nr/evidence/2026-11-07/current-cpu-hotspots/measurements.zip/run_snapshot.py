from pathlib import Path
import json,subprocess,os,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2]
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
manifest=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text());verify(root,manifest);source=inputs(root)
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
env=os.environ.copy();env['PATH']=str(root/'build/ninja-msvc-release')+';'+env.get('PATH','')
start=time.monotonic()
with (out/'snapshot-output.log').open('wb') as log:r=subprocess.run([str(out/'SnapshotBenchmark.exe'),str(project)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(r.returncode,(out/'snapshot-output.log').read_text(errors='replace')[-2500:])
result=json.loads((out/'snapshot-output.log').read_text().splitlines()[-1]);result.update(seconds=time.monotonic()-start,sourceBase='cb82fcf',privatePlayerSha256=digest(out/'SnapshotBenchmark.exe'),productionUnchanged=True)
assert inputs(root)==source;verify(root,manifest)
(out/'snapshot-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
