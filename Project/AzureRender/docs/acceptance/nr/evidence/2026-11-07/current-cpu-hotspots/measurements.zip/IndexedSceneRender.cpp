#include "runtime/SceneDocument.hpp"
#include "scene/SceneDescription.hpp"

#include <stdexcept>
#include <unordered_set>

namespace azurerender {
scene::SceneDescription indexedRenderDescription(const SceneDocument& document) {
    const auto& resources=document.resources;const auto& reflectionProbe=document.reflectionProbe;const auto& irradianceVolume=document.irradianceVolume;const auto& viewFog=document.viewFog;
    scene::SceneDescription result;
    reflectionProbe.validate();
    result.reflectionProbe = reflectionProbe;
    irradianceVolume.validate();
    result.irradianceVolume = irradianceVolume;
    viewFog.validate();
    result.viewFog = viewFog;
    result.resources.reserve(document.resources.size());
    for (const azurerender::SceneResource& resource :
         document.resources) {
        result.resources.push_back(
            {resource.id, resource.path.u8string()});
    }
    std::unordered_map<std::string,std::size_t> sourceIndices,variantIndices;
    std::unordered_set<std::string> outputIds;
    sourceIndices.reserve(resources.size());outputIds.reserve(resources.size()+document.nodes.size());variantIndices.reserve(document.nodes.size());
    for(std::size_t i=0;i<resources.size();++i){sourceIndices.emplace(resources[i].id,i);outputIds.insert(resources[i].id);}
    result.nodes.reserve(document.nodes.size());
    std::unordered_map<std::string,std::string> firstMaterialVariant;
    for (const azurerender::SceneNode& node : document.nodes) {
        azurerender::scene::SceneNodeDesc desc{};
        desc.id = node.id;
        desc.resourceId = node.resourceId;
        desc.parentId = node.parentId;
        desc.translation = node.translation;
        desc.rotation = node.rotation;
        desc.scale = node.scale;
        desc.visible = node.visible;
        if(node.objectShadow)node.objectShadow->validate();
        desc.objectShadow = node.objectShadow;
        if(!node.materialSlots.empty()){
            if(node.resolvedMaterials.size()!=node.materialSlots.size())throw std::invalid_argument("Material bindings must be resolved before rendering");
            const auto resource=sourceIndices.find(node.resourceId);
            if(resource==sourceIndices.end())throw std::invalid_argument("Material override requires a model resource");
            desc.resourceId=node.resourceId+"::materials::"+node.id;
            if(!outputIds.insert(desc.resourceId).second)
                throw std::invalid_argument("Generated material resource identity collides with an existing resource");
            variantIndices.emplace(desc.resourceId,result.resources.size());
            result.resources.push_back({desc.resourceId,resources[resource->second].path.u8string(),node.resolvedMaterials});
            firstMaterialVariant.emplace(node.resourceId,desc.resourceId);
        }
        result.nodes.push_back(std::move(desc));
    }
    std::unordered_set<std::string> referencedResources,replacedBases;
    for(const auto& node:result.nodes)referencedResources.insert(node.resourceId);
    for(std::size_t index=0;index<resources.size();++index){
        const auto& id=resources[index].id;const auto variant=firstMaterialVariant.find(id);
        if(variant==firstMaterialVariant.end()||referencedResources.count(id))continue;
        const auto position=variantIndices.at(variant->second);
        auto found=result.resources.begin()+static_cast<std::ptrdiff_t>(position);
        // Keep primary geometry ordering for animation and renderer preparation.
        std::swap(result.resources[index],*found);variantIndices.at(variant->second)=index;replacedBases.insert(id);
    }
    result.resources.erase(std::remove_if(result.resources.begin(),result.resources.end(),[&](const auto& resource){return replacedBases.count(resource.id)!=0;}),result.resources.end());
    std::unordered_map<std::string, std::size_t> nodeIndices;
    nodeIndices.reserve(document.nodes.size());
    for (std::size_t index = 0; index < document.nodes.size(); ++index) {
        nodeIndices.emplace(document.nodes[index].id, index);
    }
    std::vector<azurerender::internal::Matrix4> nodeWorld(
        document.nodes.size());
    std::vector<std::uint8_t> nodeState(document.nodes.size(), 0);
    const auto resolveNodeWorld = [&](const std::size_t index,
        auto&& self) -> const azurerender::internal::Matrix4& {
        if (nodeState[index] == 2) {
            return nodeWorld[index];
        }
        if (nodeState[index] == 1) {
            throw std::runtime_error(
                "Scene transform hierarchy contains a cycle");
        }
        nodeState[index] = 1;
        const azurerender::SceneNode& node = document.nodes[index];
        const azurerender::internal::Matrix4 local =
            azurerender::scene::composeTrs(
                node.translation, node.rotation, node.scale);
        const auto parent = nodeIndices.find(node.parentId);
        if (!node.parentId.empty() && parent != nodeIndices.end()) {
            nodeWorld[index] = azurerender::internal::multiply(
                self(parent->second, self), local);
        } else {
            nodeWorld[index] = local;
        }
        nodeState[index] = 2;
        return nodeWorld[index];
    };
    result.lights.reserve(document.lights.size());
    for (const azurerender::SceneLight& light : document.lights) {
        const auto node = nodeIndices.find(light.nodeId);
        if (node == nodeIndices.end()) {
            throw std::runtime_error(
                "Scene light references missing node: " + light.nodeId);
        }
        const auto& world = resolveNodeWorld(node->second, resolveNodeWorld);
        const auto position = azurerender::internal::transformPosition(
            world, {0.0F, 0.0F, 0.0F});
        result.lights.push_back({
            light.id,
            light.nodeId,
            position,
            light.color,
            light.intensity,
            light.radius,
            light.enabled,
            light.shape,
        });
        auto& shape = result.lights.back().shape;
        shape.validate();
        const auto local = shape.direction;
        float lengthSquared = 0;
        for (unsigned axis = 0; axis < 3; ++axis) {
            shape.direction[axis] = world[axis]*local[0] + world[axis+4]*local[1] + world[axis+8]*local[2];
            lengthSquared += shape.direction[axis]*shape.direction[axis];
        }
        if (!(lengthSquared > 1e-12F)) throw std::runtime_error("Degenerate light node transform");
        for (auto& value : shape.direction) value /= std::sqrt(lengthSquared);
    }
    return result;
}
}  // namespace azurerender
