from pathlib import Path
import json,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release'
source=(root/'src/runtime/SceneRenderSnapshot.cpp').read_text(encoding='utf-8')
source=source.replace('scene::SceneDescription SceneDocument::renderDescription() const {','scene::SceneDescription indexedRenderDescription(const SceneDocument& document) {\n    const auto& resources=document.resources;const auto& reflectionProbe=document.reflectionProbe;const auto& irradianceVolume=document.irradianceVolume;const auto& viewFog=document.viewFog;').replace('this->','document.')
source=source.replace('    result.nodes.reserve(document.nodes.size());','    std::unordered_map<std::string,std::size_t> sourceIndices,variantIndices;\n    std::unordered_set<std::string> outputIds;\n    sourceIndices.reserve(resources.size());outputIds.reserve(resources.size()+document.nodes.size());variantIndices.reserve(document.nodes.size());\n    for(std::size_t i=0;i<resources.size();++i){sourceIndices.emplace(resources[i].id,i);outputIds.insert(resources[i].id);}\n    result.nodes.reserve(document.nodes.size());')
source=source.replace('const auto resource=std::find_if(resources.begin(),resources.end(),[&](const auto& item){return item.id==node.resourceId;});','const auto resource=sourceIndices.find(node.resourceId);').replace('if(resource==resources.end())','if(resource==sourceIndices.end())').replace('if(std::any_of(result.resources.begin(),result.resources.end(),[&](const auto& item){return item.id==desc.resourceId;}))','if(!outputIds.insert(desc.resourceId).second)').replace('result.resources.push_back({desc.resourceId,resource->path.u8string(),node.resolvedMaterials});','variantIndices.emplace(desc.resourceId,result.resources.size());\n            result.resources.push_back({desc.resourceId,resources[resource->second].path.u8string(),node.resolvedMaterials});')
source=source.replace('const auto found=std::find_if(result.resources.begin(),result.resources.end(),[&](const auto& item){return item.id==variant->second;});','const auto position=variantIndices.at(variant->second);\n        auto found=result.resources.begin()+static_cast<std::ptrdiff_t>(position);').replace('std::swap(result.resources[index],*found);replacedBases.insert(id);','std::swap(result.resources[index],*found);variantIndices.at(variant->second)=index;replacedBases.insert(id);')
(out/'IndexedSceneRender.cpp').write_text(source,encoding='utf-8')
args=json.loads((out/'compile.json').read_text())[0]['command'];rows=[]
for name in ['IndexedSceneRender','SnapshotBenchmark']:
 cmd=list(args)
 for i,v in enumerate(cmd):
  if v.startswith('/Fo'):cmd[i]='/Fo'+str(out/(name+'.obj'))
  elif v.startswith('/Fd'):cmd[i]='/Fd'+str(out/(name+'.pdb'))
 cmd[-1]=str(out/(name+'.cpp'))
 with (out/(name+'-compile.log')).open('wb') as log:r=subprocess.run(cmd,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 rows.append(dict(name=name,command=cmd,exitCode=r.returncode));(out/'snapshot-build.json').write_text(json.dumps(rows,indent=2))
 assert r.returncode==0,(out/(name+'-compile.log')).read_text(errors='replace')[-2000:]
rsp=(out/'link.rsp').read_text()
for name in ['CharacterSceneRenderer','AzureRenderFrame']:rsp=rsp.replace('"'+str(out/(name+'.obj'))+'" ','')
rsp=rsp.replace('CMakeFiles\\AzurePlayer.dir\\src\\player\\main.cpp.obj','').replace(str(out/'AzurePlayer'),str(out/'SnapshotBenchmark'))
rsp='"'+str(out/'IndexedSceneRender.obj')+'" "'+str(out/'SnapshotBenchmark.obj')+'" '+rsp
(out/'snapshot-link.rsp').write_text(rsp)
with (out/'snapshot-link.log').open('wb') as log:r=subprocess.run(['D:/Tools/VS2022BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/link.exe','@'+str(out/'snapshot-link.rsp')],cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(out/'snapshot-link.log').read_text(errors='replace')[-2000:]
print('Snapshot prototype built',flush=True)
