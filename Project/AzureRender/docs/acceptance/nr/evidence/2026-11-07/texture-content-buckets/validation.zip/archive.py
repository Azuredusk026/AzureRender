from pathlib import Path
import json,hashlib,subprocess,zipfile,xml.etree.ElementTree as ET,sys
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from artifact_budget import check
assert check(root/'build',run=out,planned=2*1024**2,diagnostic=True)['allowed']
target=root/'docs/acceptance/nr/evidence/2026-11-07/texture-content-buckets';target.mkdir(parents=True,exist_ok=True)
bench=json.loads((out/'benchmark.json').read_text());assert bench['status']=='passed'
checks=[]
for config in ['release','debug']:
    p=out/(config+'-checks.xml');cases=ET.parse(p).findall('.//testcase')
    assert len(cases)==4 and all(c.find('failure') is None for c in cases)
    checks.append(dict(configuration=config,tests=len(cases),sha256=digest(p)))
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log','.xml','.cpp'}}
members['source/SampledTextureCache.cpp']=root/'src/render/SampledTextureCache.cpp'
members['source/SampledTextureCacheTests.cpp']=root/'tests/SampledTextureCacheTests.cpp'
members['sceneLoad/capture_manifest.json']=root/'build/runs/20261107-153334-focused-device-buffers-92cea3/image/frames/capture_manifest.json'
archive=target/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
    for name,p in members.items():z.write(p,name)
result=dict(status='implemented-local-benefit-verified',sourceBase=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    checks=checks,benchmark=bench,sourceInputs=inputs(root),
    productionPlayers={config:digest(root/('build/ninja-msvc-'+config)/'AzurePlayer.exe') for config in ['release','debug']},
    originalSceneLoad=dict(cpuPrepareMs=75652.4,materialUploadMs=20517.2,hashMs=7489.0246,mipMs=9564.5849,pipelinesMs=535.292),
    originalSceneLoadScope='Previous f015e5d candidate observation; not a paired full-scene timing',
    nativeImageStatus='pending-next-qualified-consolidated-batch',frameBenefit='not-measured',
    overallVisualStatus='failed-user-review',overallPerformanceStatus='pending-original-conditions',
    archive=dict(path=archive.name,sha256=digest(archive),bytes=archive.stat().st_size,members={n:digest(p) for n,p in members.items()}))
(target/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(checks=8,hashReduction=bench['hashReduction'],archiveBytes=archive.stat().st_size)))
