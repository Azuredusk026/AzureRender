from pathlib import Path
import subprocess,os,json,time,statistics,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent
env=dict(os.environ);env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9')
prefix=['cmd','/d','/c',str(root/'tools/msvc_env.bat')]
rows=[]
for name,source in [('baseline',out/'baseline.cpp'),('candidate',root/'src/render/SampledTextureCache.cpp')]:
    exe=out/(name+'.exe')
    command=prefix+['cl','/nologo','/O2','/MD','/EHsc','/std:c++17','/I'+str(root/'src'),'/ID:/Tools/VulkanSDK/1.4.350.0/Include',str(out/'benchmark.cpp'),str(source),str(root/'src/rhi/NullRhi.cpp'),'/Fe:'+str(exe),'/link','/LIBPATH:D:/Tools/VulkanSDK/1.4.350.0/Lib','vulkan-1.lib']
    with (out/(name+'-compile.log')).open('wb') as log:p=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    assert p.returncode==0,(out/(name+'-compile.log')).read_text(errors='replace')[-5000:]
    rows.append(dict(name=name,sourceSha256=hashlib.sha256(source.read_bytes()).hexdigest(),command=command,samples=[]))
    print('Built '+name,flush=True)
# Alternating complete runs reduce ordering effects. Each run checks real cache identities.
for round in range(3):
    for row in rows if round%2==0 else rows[::-1]:
        p=subprocess.run([str(out/(row['name']+'.exe'))],cwd=out,env=env,capture_output=True,text=True,timeout=90)
        (out/(row['name']+'-'+str(round)+'.log')).write_text(p.stdout+p.stderr)
        assert p.returncode==0,p.stdout+p.stderr
        row['samples'].extend(json.loads(line) for line in p.stdout.splitlines())
        print(row['name']+' round '+str(round)+' completed',flush=True)
for row in rows:
    row['medianHashMs']=statistics.median(s['hashMs'] for s in row['samples'])
    row['medianWallMs']=statistics.median(s['wallMs'] for s in row['samples'])
result=dict(status='passed' if rows[1]['medianHashMs']<=rows[0]['medianHashMs']*.5 else 'insufficient',runs=rows,hashReduction=1-rows[1]['medianHashMs']/rows[0]['medianHashMs'],wallReduction=1-rows[1]['medianWallMs']/rows[0]['medianWallMs'],scope='Local cached 2048-square RGBA input; 32 exact hits per sample, 15 samples per policy; no frame speed claim')
(out/'benchmark.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='runs'}),flush=True)
