#include "render/SampledTextureCache.hpp"
#include "rhi/NullRhi.hpp"
#include <iostream>
#include <vector>
#include <chrono>
using namespace azurerender;
int main(){
    rhi::NullRhi backend;SampledTextureCache cache(backend.allocator(),backend);
    std::vector<std::uint8_t> pixels(2048*2048*4);
    std::uint32_t state=17;
    for(auto& pixel:pixels){state=state*1664525U+1013904223U;pixel=state>>24;}
    SampledTextureUpload request;request.width=request.height=2048;request.mipLevels=1;
    const auto binding=cache.acquire(pixels,request);
    for(unsigned round=0;round<5;++round){
        const auto before=cache.statistics();const auto start=std::chrono::steady_clock::now();
        for(unsigned i=0;i<32;++i){if(cache.acquire(pixels,request).view!=binding.view)return 2;}
        const auto after=cache.statistics();
        std::cout<<"{\"round\":"<<round<<",\"bytes\":"<<(pixels.size()*32)
            <<",\"hashMs\":"<<after.hashMs-before.hashMs<<",\"matchMs\":"<<after.matchMs-before.matchMs
            <<",\"wallMs\":"<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()<<"}\n";
        if(after.hits-before.hits!=32||after.uniqueTextures!=1)return 3;
    }
}
