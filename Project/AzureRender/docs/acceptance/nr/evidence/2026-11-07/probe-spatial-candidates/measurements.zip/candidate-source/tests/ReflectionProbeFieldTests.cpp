#include "render/ReflectionProbeFieldJson.hpp"
#include "render/ReflectionProbeSpatialGrid.hpp"
#include <iostream>
#include <functional>
using namespace azurerender;
void check(bool x,const char* message){if(!x)throw std::runtime_error(message);}
void rejects(const std::function<void()>& call){try{call();}catch(const std::exception&){return;}throw std::runtime_error("Invalid probe field accepted");}
void checkSpatialGrid(){
    ReflectionProbeField field;
    for(unsigned index=0;index<32;++index){
        ReflectionProbeVolume p;p.arrayLayer=index%2;
        const float x=float(index%8)*8-24,y=float(index/8)*8-12;
        p.halfExtents={3,3,3};p.fade=.25F+float(index%4)*.2F;
        p.worldToLocal={{{1,0,0,-x},{0,1,0,-y},{0,0,1,0}}};
        if(index%3==0){p.worldToLocal={{{0,0,1,0},{0,1,0,-y},{-1,0,0,x}}};p.shape=ReflectionProbeVolume::Shape::Sphere;}
        if(index==7)p.worldToLocal[0][1]=.00002F;
        field.probes.push_back(p);
    }
    auto grid=ReflectionProbeSpatialGrid::build(field);check(grid.has_value(),"Valid sparse field requires an index");
    std::uint32_t random=1234567;unsigned covered=0;
    const auto verify=[&](const std::array<float,3>& position){
        const auto mask=grid->candidateMask(position);
        for(unsigned i=0;i<field.probes.size();++i){
            const auto local=field.probes[i].local(position,true);bool inside=true;
            for(unsigned axis=0;axis<3;++axis)inside=inside&&std::abs(local[axis])<=field.probes[i].halfExtents[axis];
            if(inside){++covered;check((mask&(std::uint32_t{1}<<i))!=0,"Spatial index excluded a possible volume contribution");}
        }
    };
    for(unsigned sample=0;sample<20000;++sample){
        std::array<float,3> position{};
        for(auto& value:position){random=random*1664525U+1013904223U;value=float(random&65535U)/65535.F*100-40;}
        verify(position);
    }
    const auto origin=grid->origin(),inverse=grid->inverseCell();
    for(unsigned axis=0;axis<3;++axis)for(unsigned cell=0;cell<=grid->dimensions()[axis];++cell){
        std::array<float,3> point{0,0,0};point[axis]=origin[axis]+float(cell)/inverse[axis];
        verify(point);point[axis]=std::nextafter(point[axis],-std::numeric_limits<float>::infinity());verify(point);
        point[axis]=std::nextafter(point[axis],std::numeric_limits<float>::infinity());verify(point);
    }
    check(covered>100,"Sparse field checks require actual volume hits");
    check((grid->candidateMask({32,12,0})&0x80000000U)!=0,"The32nd probe must preserve its unsigned high bit");
    check(grid->candidateMask({std::numeric_limits<float>::infinity(),0,0})==0xffffffffU,"Nonfinite lookup must use the complete field");
    check(grid->candidateMask({std::numeric_limits<float>::quiet_NaN(),0,0})==0xffffffffU,"NaN lookup must use the complete field");
    check(grid->candidateMask({1000000,0,0})==0xffffffffU,"Out-of-grid lookup must use the complete field");
    const ReflectionProbeField::Row atlas{1,1,0,0};
    const auto legacy=field.gpuRows(atlas,true),rows=grid->gpuRows(atlas,true);
    check(rows[3][1]==float(legacy.size())&&rows[3][2]==1.F&&rows[3][0]==legacy[3][0],"Spatial row metadata must preserve the fold convention");
    for(std::size_t index=0;index<legacy.size();++index)if(index!=3)check(rows[index]==legacy[index],"Spatial rows must preserve every original probe parameter");
    for(std::size_t index=0;index<grid->masks().size();++index){
        const auto& row=rows[legacy.size()+3+index/2];const unsigned half=unsigned(index%2)*2;
        const auto decoded=std::uint32_t(row[half])|(std::uint32_t(row[half+1])<<16U);
        check(decoded==grid->masks()[index],"Packed numeric halves must preserve all32 bits");
    }
    check(grid->gpuRows(atlas,true,legacy.size()*16)==legacy,"Limited device storage must preserve the complete legacy rows");
    rejects([&]{(void)ReflectionProbeSpatialGrid::build(field,{0,16,32});});
    rejects([&]{(void)ReflectionProbeSpatialGrid::build(field,{64,64,64});});
    auto huge=field;huge.probes.resize(1);huge.probes[0].halfExtents.fill(std::numeric_limits<float>::max());
    check(!ReflectionProbeSpatialGrid::build(huge),"Unrepresentable bounds must retain the complete-set fallback");
    auto empty=field;empty.probes.clear();check(!ReflectionProbeSpatialGrid::build(empty),"Empty fields require no spatial allocation");
    auto single=field;single.probes.resize(1);check(reflectionProbeSpatialRows(single,atlas,true)==single.gpuRows(atlas,true),"Small fields retain the direct traversal");
    std::cout<<"Spatial conservative hits="<<covered<<", cells="<<grid->masks().size()<<'\n';
}
int main()try{
    checkSpatialGrid();
    ReflectionProbeField field;ReflectionProbeVolume p;p.halfExtents={2,2,2};p.inverseBlendWidths={1,1,1};p.arrayLayer=1;
    field.probes={p};field.validate(2);
    auto q=field.query({0,0,0},{1,0,0},{0,1,0},1);
    check(q.size()==1&&q[0].weight==1&&q[0].layer==1,"Inner box consumes environment");
    q=field.query({1.5F,0,0},{1,0,0},{0,1,0},1);
    check(q.size()==2&&q[0].weight==.5F&&q[1].weight==.5F,"Boundary leaves fallback");
    check(q[0].direction==std::array<float,3>{2,0,0},"Projection uses local boundary");
    field.probes[0].fade=.25F;q=field.query({0,0,0},{0,0,1},{0,1,0},1);
    check(q.size()==2&&q[0].weight==.25F&&q[1].weight==.75F,"Fade multiplies coverage");
    field.probes.push_back(p);q=field.query({0,0,0},{0,0,1},{0,1,0},1);
    check(q.size()==2&&q[0].weight==.25F&&q[1].weight==.75F,"Order consumes remaining weight");
    field.probes={p};field.probes[0].shape=ReflectionProbeVolume::Shape::Sphere;
    check(field.query({1.5F,1.5F,0},{0,0,1},{0,1,0},1).size()==1,"Sphere outside falls back");
    field.probes[0].projection=false;q=field.query({0,0,0},{.2F,.3F,.4F},{0,1,0},1);
    check(q[0].direction==std::array<float,3>{.2F,.3F,.4F},"Unprojected direction remains world aligned");
    auto bad=field;bad.probes[0].arrayLayer=2;rejects([&]{bad.validate(2);});
    bad=field;bad.probes.resize(33);rejects([&]{bad.validate(2);});
    bad=field;bad.probes[0].halfExtents[0]=0;rejects([&]{bad.validate(2);});
    bad=field;bad.probes[0].worldToLocal[0][0]=2;rejects([&]{bad.validate(2);});
    rejects([&]{(void)field.query({0,0,0},{0,0,0},{0,1,0},1);});
    field.probes={p};field.adaptation=1;field.probes[0].luminanceSH={0,0,0,2};
    q=field.query({0,0,0},{0,0,1},{0,1,0},1);
    check(std::abs(q[0].radianceScale-.5F)<1e-6F,"Luminance adapts source environment");
    field.worldToField={{{-1,0,0},{0,1,0},{0,0,1}}};field.probes[0].projection=false;
    q=field.query({1,0,0},{1,0,0},{0,1,0},1);
    check(q[0].direction==std::array<float,3>{-1,0,0},"Explicit field coordinate mapping");
    nlohmann::json saved=field;auto restored=saved.get<ReflectionProbeField>();
    check(nlohmann::json(restored)==saved,"Complete field JSON roundtrip");
    for(const auto& key:{"schemaVersion","probes","defaultLayer","adaptation"}){
        auto badJson=saved;badJson.erase(key);rejects([&]{(void)badJson.get<ReflectionProbeField>();});}
    auto invalid=saved;invalid["schemaVersion"]=2;rejects([&]{(void)invalid.get<ReflectionProbeField>();});
    invalid=saved;invalid["probes"][0]["arrayLayer"]=-1;rejects([&]{(void)invalid.get<ReflectionProbeField>();});
    invalid=saved;invalid["probes"][0]["projection"]=1;rejects([&]{(void)invalid.get<ReflectionProbeField>();});
    invalid=saved;invalid["worldToField"][0].push_back(0);rejects([&]{(void)invalid.get<ReflectionProbeField>();});
    invalid=saved;invalid["probes"][0]["halfExtents"].push_back(1);rejects([&]{(void)invalid.get<ReflectionProbeField>();});
    std::cout<<"PASS: ordered volumes, blend, projection, luminance, fallback and bounds\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
