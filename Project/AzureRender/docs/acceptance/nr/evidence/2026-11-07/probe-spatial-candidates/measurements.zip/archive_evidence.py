from pathlib import Path
import json,zipfile,hashlib,sys
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'))
from build_provenance import digest
from artifact_budget import check
folder=root/'docs/acceptance/nr/evidence/2026-11-07/probe-spatial-candidates';folder.mkdir(parents=True,exist_ok=True)
archive=folder/'measurements.zip';members={}
paths=[p for p in out.rglob('*') if p.is_file() and p.suffix in ['.json','.csv','.log','.py','.xml','.cpp','.hpp','.glsl','.patch'] and 'isolated-candidate' not in p.parts and 'baseline' not in p.parts]
paths.append(out/'candidate-source/CMakeLists.txt')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(paths)):
  name=p.relative_to(out).as_posix();data=p.read_bytes();z.writestr(name,data);members[name]=hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert all(hashlib.sha256(z.read(name)).hexdigest()==value for name,value in members.items())
read=lambda p:json.loads((out/p).read_text(encoding='utf-8-sig'))
summary=dict(status='isolated-not-adopted-production-restored',sourceBase='725dfdd',candidate=read('isolation.json'),estimate=read('candidate-estimate.json'),build=read('release-build.json'),checks=read('batch-checks.json'),image=read('image/results.json'),pair=read('paired-results.json'),restoration=read('restoration.json'),performanceExecution=read('performance-execution.json'),blockedPreflight=read('blocked-preflight-execution.json'),environmentAction='Observed Slay the Spire2 window and minimized with native Minimize button; process retained; three subsequent GPU observations were0percent',formalPerformancePassed=False,visualAcceptance='failed-user-review',budget=check(root/'build',run=out,planned=0),archive=dict(path='measurements.zip',bytes=archive.stat().st_size,sha256=digest(archive),memberHashes=members))
(folder/'results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=summary['status'],archiveBytes=archive.stat().st_size,members=len(members),budget=summary['budget'])))
