from pathlib import Path
import subprocess,os,time,json
out=Path(__file__).resolve().parent;root=out.parents[2]
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
command=['cmd','/d','/c',str(root/'tools/msvc_env.bat'),str(root/'build/reinstall-environment/venv/Scripts/python.exe'),'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(root/'build/ninja-msvc-release'),'--config','Release','--test-target','AzureReflectionProbeFieldTests','--test-target','AzureReflectionProbeFieldGpuTests','--test-target','AzureRenderReflectionProbeTests']
start=time.monotonic()
with (out/'release-build.log').open('wb') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
summary=dict(command=command,exitCode=result.returncode,seconds=time.monotonic()-start);(out/'release-build.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
assert result.returncode==0,(out/'release-build.log').read_text(errors='replace')[-5000:]
