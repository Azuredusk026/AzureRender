from pathlib import Path
import subprocess,json,os,time,re
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release'
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
rows=json.loads((out/'batch-checks.json').read_text()) if (out/'batch-checks.json').exists() else []
for label,filter,pattern in [('cpu',None,r'^AzureRender\.(ReflectionProbe|ReflectionProbeField)$'),('nvidia','*nv-vk64*',r'^AzureRender\.ReflectionProbeFieldGpu(\..+)?$'),('intel','*igvk64*',r'^AzureRender\.ReflectionProbeFieldGpu(\..+)?$')]:
 if any(row['scope']==label and row['exitCode']==0 for row in rows):continue
 env=os.environ.copy();env['PATH']=str(build)+';'+env['PATH'];env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None)
 if filter:
  env['VK_LOADER_DRIVERS_SELECT']=filter
  v=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/vulkaninfoSDK.exe','--summary'],env=env,capture_output=True,text=True,timeout=60)
  (out/(label+'-devices.log')).write_text(v.stdout+v.stderr)
  names=re.findall(r'deviceName\s*=\s*(.+)',v.stdout);assert v.returncode==0 and names,(v.returncode,v.stdout[-1000:],v.stderr)
  assert all(('NVIDIA' in name if label=='nvidia' else 'Intel' in name) for name in names),names
 else:names=[]
 command=[ctest,'--test-dir',str(build),'-R',pattern,'--output-on-failure','--no-tests=error','--output-junit',str(out/(label+'-checks.xml'))]
 start=time.monotonic()
 with (out/(label+'-checks.log')).open('wb') as log:v=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 row=dict(scope=label,devices=names,filter=filter,command=command,exitCode=v.returncode,seconds=time.monotonic()-start);rows.append(row);(out/'batch-checks.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
 assert v.returncode==0,(out/(label+'-checks.log')).read_text(errors='replace')[-5000:]
