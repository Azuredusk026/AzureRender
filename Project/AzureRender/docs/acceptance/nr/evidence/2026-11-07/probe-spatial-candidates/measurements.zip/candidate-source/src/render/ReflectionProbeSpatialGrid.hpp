#pragma once

#include "render/ReflectionProbeField.hpp"
#include <optional>

namespace azurerender {

// Immutable field-coordinate broad phase. Candidate bits retain authoring
// order; the original volume test and mixture still decide each contribution.
class ReflectionProbeSpatialGrid final {
public:
    using Dimensions=std::array<unsigned,3>;
    static constexpr Dimensions defaultDimensions{32,16,32};
    static constexpr std::size_t maxCells=65536;

    static std::optional<ReflectionProbeSpatialGrid> build(
        const ReflectionProbeField& field,Dimensions dimensions=defaultDimensions) {
        field.validate(256);
        std::size_t cellCount=1;
        for(const auto value:dimensions) {
            if(value==0||value>64)throw std::invalid_argument("Invalid reflection spatial dimension");
            cellCount*=value;
        }
        if(cellCount>maxCells)throw std::invalid_argument("Reflection spatial cell budget exceeded");
        if(field.probes.empty())return {};
        ReflectionProbeSpatialGrid result;
        result.field_=field;result.dimensions_=dimensions;
        const double infinity=std::numeric_limits<double>::infinity();
        std::array<double,3> low{infinity,infinity,infinity},high{-infinity,-infinity,-infinity};
        for(const auto& probe:field.probes) {
            const auto& r=probe.worldToLocal;
            const double a=r[0][0],b=r[0][1],c=r[0][2],d=r[1][0],e=r[1][1],f=r[1][2],g=r[2][0],h=r[2][1],i=r[2][2];
            const double determinant=a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g);
            if(!std::isfinite(determinant)||std::abs(determinant)<.5)return {};
            const std::array<std::array<double,3>,3> inverse{{
                {(e*i-f*h)/determinant,(c*h-b*i)/determinant,(b*f-c*e)/determinant},
                {(f*g-d*i)/determinant,(a*i-c*g)/determinant,(c*d-a*f)/determinant},
                {(d*h-e*g)/determinant,(b*g-a*h)/determinant,(a*e-b*d)/determinant}}};
            for(unsigned axis=0;axis<3;++axis) {
                double center=0,extent=0;
                for(unsigned local=0;local<3;++local) {
                    center-=inverse[axis][local]*r[local][3];
                    extent+=std::abs(inverse[axis][local])*probe.halfExtents[local];
                }
                low[axis]=std::min(low[axis],center-extent);
                high[axis]=std::max(high[axis],center+extent);
            }
        }
        constexpr double errorFactor=64*double(std::numeric_limits<float>::epsilon());
        std::array<double,3> step{};
        for(unsigned axis=0;axis<3;++axis) {
            const double padding=errorFactor*(1+std::max(std::abs(low[axis]),std::abs(high[axis])));
            const float origin=std::nextafter(static_cast<float>(low[axis]-padding),-std::numeric_limits<float>::infinity());
            const float end=std::nextafter(static_cast<float>(high[axis]+padding),std::numeric_limits<float>::infinity());
            const float cell=static_cast<float>((double(end)-origin)/dimensions[axis]);
            const float inverse=1.F/cell;
            if(!std::isfinite(origin)||!std::isfinite(end)||!std::isfinite(cell)||cell<=0
                ||!std::isfinite(inverse)||inverse<=0)return {};
            result.origin_[axis]=origin;result.inverseCell_[axis]=inverse;
            step[axis]=1/double(inverse);
        }
        result.masks_.resize(cellCount);
        for(unsigned z=0;z<dimensions[2];++z)for(unsigned y=0;y<dimensions[1];++y)for(unsigned x=0;x<dimensions[0];++x) {
            const std::array<unsigned,3> index{x,y,z};
            std::array<double,3> center{},half{};
            for(unsigned axis=0;axis<3;++axis) {
                center[axis]=result.origin_[axis]+(index[axis]+.5)*step[axis];
                // One-cell halo covers a rounded lookup crossing a cell face.
                half[axis]=1.5*step[axis];
            }
            std::uint32_t mask=0;
            for(std::size_t probeIndex=0;probeIndex<field.probes.size();++probeIndex) {
                const auto& probe=field.probes[probeIndex];bool intersects=true;
                for(unsigned local=0;local<3;++local) {
                    const auto& row=probe.worldToLocal[local];
                    double localCenter=row[3],radius=0,magnitude=std::abs(double(row[3]));
                    for(unsigned axis=0;axis<3;++axis) {
                        localCenter+=row[axis]*center[axis];radius+=std::abs(double(row[axis]))*half[axis];
                        magnitude+=std::abs(double(row[axis]))*(std::abs(center[axis])+half[axis]);
                    }
                    const double error=errorFactor*(1+magnitude+probe.halfExtents[local]);
                    if(std::abs(localCenter)>radius+probe.halfExtents[local]+error){intersects=false;break;}
                }
                if(intersects)mask|=std::uint32_t{1}<<probeIndex;
            }
            result.masks_[x+dimensions[0]*(y+dimensions[1]*z)]=mask;
        }
        return result;
    }

    [[nodiscard]] std::uint32_t fullMask() const noexcept {
        return field_.probes.size()==32?std::numeric_limits<std::uint32_t>::max()
            :(std::uint32_t{1}<<field_.probes.size())-1;
    }
    [[nodiscard]] std::uint32_t candidateMask(const std::array<float,3>& fieldPosition) const noexcept {
        std::array<unsigned,3> index{};
        for(unsigned axis=0;axis<3;++axis) {
            const float coordinate=(fieldPosition[axis]-origin_[axis])*inverseCell_[axis];
            if(!std::isfinite(coordinate)||coordinate<0||coordinate>=float(dimensions_[axis]))return fullMask();
            index[axis]=static_cast<unsigned>(coordinate);
        }
        return masks_[index[0]+dimensions_[0]*(index[1]+dimensions_[1]*index[2])];
    }
    [[nodiscard]] const std::vector<std::uint32_t>& masks() const noexcept{return masks_;}
    [[nodiscard]] const std::array<float,3>& origin() const noexcept{return origin_;}
    [[nodiscard]] const std::array<float,3>& inverseCell() const noexcept{return inverseCell_;}
    [[nodiscard]] const Dimensions& dimensions() const noexcept{return dimensions_;}

    [[nodiscard]] std::vector<ReflectionProbeField::Row> gpuRows(
        const ReflectionProbeField::Row& atlas,bool positiveZero,std::size_t maximumBytes=0) const {
        auto rows=field_.gpuRows(atlas,positiveZero);
        const auto count=rows.size()+3+(masks_.size()+1)/2;
        if(maximumBytes&&count>maximumBytes/sizeof(ReflectionProbeField::Row))return rows;
        const auto offset=rows.size();rows.reserve(count);
        // Row3: positive-zero flag, header offset, layout version, reserved.
        rows[3][1]=static_cast<float>(offset);rows[3][2]=1.F;
        rows.push_back({origin_[0],origin_[1],origin_[2],0});
        rows.push_back({inverseCell_[0],inverseCell_[1],inverseCell_[2],0});
        rows.push_back({float(dimensions_[0]),float(dimensions_[1]),float(dimensions_[2]),0});
        for(std::size_t index=0;index<masks_.size();index+=2) {
            const auto first=masks_[index],second=index+1<masks_.size()?masks_[index+1]:0;
            // Exact numeric halves avoid floating-point NaN payload encodings.
            rows.push_back({float(first&65535U),float(first>>16U),float(second&65535U),float(second>>16U)});
        }
        return rows;
    }
private:
    ReflectionProbeField field_;
    Dimensions dimensions_{};
    std::array<float,3> origin_{},inverseCell_{};
    std::vector<std::uint32_t> masks_;
};

inline std::vector<ReflectionProbeField::Row> reflectionProbeSpatialRows(
    const ReflectionProbeField& field,const ReflectionProbeField::Row& atlas,bool positiveZero,std::size_t maximumBytes=0) {
    if(field.probes.size()>=4)if(auto grid=ReflectionProbeSpatialGrid::build(field))return grid->gpuRows(atlas,positiveZero,maximumBytes);
    return field.gpuRows(atlas,positiveZero);
}
}
