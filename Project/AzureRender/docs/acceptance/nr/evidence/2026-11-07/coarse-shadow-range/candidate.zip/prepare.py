from pathlib import Path
import json,subprocess,sys,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from artifact_budget import check
assert check(root/'build',run=out,planned=24*1024**2,diagnostic=True)['allowed']
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());programs={p['output']:p for p in manifest['programs']};names=[r['file'] for r in json.loads((root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/candidate-build.json').read_text())]
source=(root/'shaders/mesh.frag').read_text();assert source.count('lo,hi)/8')==2
source=source.replace('lo,hi)/8','lo,hi)/32');needle='shadowBounds.values[ty*(extent.x/8)+tx]';assert source.count(needle)==1;source=source.replace(needle,'shadowBounds.values[(ty*4)*(extent.x/8)+tx*4]');(out/'mesh.frag').write_text(source)
rows=[]
for name in [*names,'shadow_bounds.comp.spv']:
 p=programs[name];file=out/('shadow_bounds.comp' if name.endswith('.comp.spv') else 'mesh.frag');command=[manifest['compiler'],*[f'-D{d}' for d in p['defines']],f'-I{out}',f'-I{root/"shaders"}',str(file),'-o',str(out/name)];r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr
 v=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(out/name)],capture_output=True,text=True);assert v.returncode==0,v.stderr
 rows.append(dict(file=name,command=command,baselineSha256=hashlib.sha256((root/'build/ninja-msvc-release/shaders'/name).read_bytes()).hexdigest(),candidateSha256=hashlib.sha256((out/name).read_bytes()).hexdigest()))
(out/'candidate-build.json').write_text(json.dumps(rows,indent=2));print('Validated',len(rows),'isolated programs')
