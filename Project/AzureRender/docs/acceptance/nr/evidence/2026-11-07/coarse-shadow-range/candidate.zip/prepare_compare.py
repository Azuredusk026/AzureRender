from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2];template=root/'build/runs/20261107-135008-optimized-material-cost-e1c8e5'
s=(template/'compare.py').read_text().replace('20261107-135008-optimized-material-cost-e1c8e5',out.name)
s=s.replace('Eleven original captured modules optimized using SPIRV-Tools -O; specialization IDs and bindings preserved.','Coarse conservative shadow ranges in the existing bounds allocation; exact filtering retained.')
insert='''
 def fields(o):return {str(o.GetChild(i).name):o.GetChild(i) for i in range(o.NumChildren())}
 computeMatches=0
 for chunk in c.GetStructuredFile().chunks:
  if str(chunk.name)!='vkCreateComputePipelines':continue
  f=fields(chunk);info=fields(f['CreateInfo']);stage=fields(info['stage']);pipeline=f['Pipeline'].AsResourceId();shader=stage['module'].AsResourceId();entry=rd.ShaderEntryPoint();entry.name='main';entry.stage=rd.ShaderStage.Compute
  reflection=c.GetShader(pipeline,shader,entry)
  if reflection and hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==hashlib.sha256((root/'build/ninja-msvc-release/shaders/shadow_bounds.comp.spv').read_bytes()).hexdigest():
   key=str(shader)
   if key in compiled:continue
   program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/'shadow_bounds.comp.spv').read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Compute);assert program!=rd.ResourceId.Null(),errors;compiled[key]=(shader,program);computeMatches+=1
 assert computeMatches>0
 report['computeMatches']=computeMatches
'''
assert ' selected=[]' in s;s=s.replace(' selected=[]',insert+' selected=[]')
s=s.replace('report.update(status=\'candidate-read\',comparisons=comparisons);save();durations()',"report.update(status='candidate-read',comparisons=comparisons);save();assert all(r['equal'] for r in comparisons),'Attachment compatibility failed';durations()")
s=s.replace("def durations():return {int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}",'''def durations():
 previous=[]
 for attempt in range(8):
  values={int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])};previous.append(sum(values.values()))
  if len(previous)>=3 and max(previous[-3:])/min(previous[-3:])<=1.03:return values
 raise RuntimeError('Replay duration unstable: '+str(previous))''')
(out/'compare.py').write_text(s);(out/'run_compare.py').write_text((template/'run_compare.py').read_text())
