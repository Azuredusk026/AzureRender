from pathlib import Path
import json,zipfile,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];r=json.loads((out/'result.json').read_text());b=[x['matchedEventMs'] for x in r['summary'] if x['mode']=='baseline'];c=[x['matchedEventMs'] for x in r['summary'] if x['mode']=='candidate'];r.update(status='compatible-insufficient-benefit',baselineMatchedDriftFraction=max(b)/min(b)-1,matchedReduction=1-(sum(c)/len(c))/(sum(b)/len(b)),nativeBatchStarted=False)
e=root/'docs/acceptance/nr/evidence/2026-11-07/coarse-shadow-range';e.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(e/'candidate.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.iterdir():
  if p.is_file():z.write(p,p.name)
p=e/'candidate.zip';r['archive']=dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest());(e/'results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
