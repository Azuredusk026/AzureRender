from pathlib import Path
import renderdoc as rd
import sys,json,zlib,hashlib,traceback
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-203000-hair-attachment-precision-35f604'
capture=root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc'
report=dict(status='starting',variants=[],scope='Functional output-conversion controls in existing frozen capture; no native frame or performance claim.');cap=None;c=None
def save():(out/'capture-state.json').write_text(json.dumps(report,indent=2))
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(capture),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 c.SetFrameEvent(493,True);original=c.GetPipelineState().GetShader(rd.ShaderStage.Pixel)
 reflection=c.GetPipelineState().GetShaderReflection(rd.ShaderStage.Pixel)
 report['originalShaderSha256']=hashlib.sha256(bytes(reflection.rawBytes)).hexdigest();assert report['originalShaderSha256']=='5b076fb5ca571c93b5c2d5036ff97b84e0a96d34a81e932c4b4698821a28c4ca'
 def snapshot(name,event):
  c.SetFrameEvent(event,True);target=c.GetPipelineState().GetOutputTargets()[0].resource;raw=bytes(c.GetTextureData(target,rd.Subresource()));bpp=len(raw)//(2560*1440);assert bpp in [4,8]
  crop=b''.join(raw[(y*2560+1140)*bpp:(y*2560+1430)*bpp] for y in range(130,440));(out/(name+'.zlib')).write_bytes(zlib.compress(crop,6))
  return dict(event=event,bytesPerPixel=bpp,sha256=hashlib.sha256(crop).hexdigest())
 report['baseline']=snapshot('baseline-final',567);save()
 for variant in json.loads((out/'variants.json').read_text()):
  replacement,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/(variant['name']+'.spv')).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert replacement!=rd.ResourceId.Null(),errors
  c.ReplaceResource(original,replacement);row=dict(name=variant['name'],hdr=snapshot(variant['name']+'-hdr',493),final=snapshot(variant['name']+'-final',567));report['variants'].append(row);save()
  c.RemoveReplacement(original);c.FreeTargetResource(replacement)
 report['restored']=snapshot('restored-final',567);assert report['restored']==report['baseline']
 report['debugMessages']=[str(m.description) for m in c.GetDebugMessages()];report['status']='captured';save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='captured' else 1)
