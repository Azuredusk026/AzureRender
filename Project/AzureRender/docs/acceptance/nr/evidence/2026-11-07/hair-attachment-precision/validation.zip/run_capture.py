from pathlib import Path
import sys,json,subprocess,time
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs
assert check(root/'build',run=out,planned=5*1024**2,diagnostic=True)['allowed']
source=inputs(root);si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'capture-driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'capture_precision.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=180)
assert source==inputs(root);report=json.loads((out/'capture-state.json').read_text());report.update(processExitCode=p.returncode,seconds=time.monotonic()-start,productionSourceUnchanged=True)
(out/'capture-state.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:report.get(k) for k in ['status','seconds','productionSourceUnchanged','debugMessages','error']}),flush=True)
