from pathlib import Path
import json,sys,zlib,hashlib,numpy as np
from PIL import Image
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
assert check(root/'build',run=out,planned=2*1024**2,diagnostic=True)['allowed']
prior=root/'build/runs/20261107-191143-hair-gradient-region-08b1f9'
native=root/'build/runs/20261023-033116-postvs-linear-verification-591bef/e950-linear-target.bin'
maskFile=root/'build/runs/20261023-105023-character-composite-contribution-diagnosis-acb8e5/native-hair-visible-mask.png'
box=[1140,130,1430,440];x0,y0,x1,y1=box;w=x1-x0;h=y1-y0
raw=native.read_bytes();words=np.frombuffer(raw,dtype='<u4').reshape(1440,2560)[::-1][y0:y1,x0:x1]
channels=[]
for shift,bits in [(0,6),(11,6),(22,5)]:
 value=(words>>shift)&((1<<(bits+5))-1);exponent=(value>>bits).astype('int32');mantissa=(value&((1<<bits)-1)).astype('float64')
 assert (exponent!=31).all()
 channels.append(np.where(exponent==0,np.ldexp(mantissa,-14-bits),np.ldexp(1+mantissa/(1<<bits),exponent-15))*.25)
reference=np.stack(channels,axis=-1)
mask=np.asarray(Image.open(maskFile).convert('L'))[y0:y1,x0:x1]!=0;assert int(mask.sum())==17017
hdr=np.frombuffer(zlib.decompress((prior/'original-hdr.zlib').read_bytes()),dtype='<f2').astype('float64').reshape(h,w,4)[:,:,:3]*.25
frozen=np.frombuffer(zlib.decompress((prior/'original-final.zlib').read_bytes()),dtype='uint8').reshape(h,w,4)[:,:,[2,1,0]]
def srgb(x):
 x=np.maximum(x,0);encoded=np.where(x<=.0031308,12.92*x,1.055*np.power(x,1/2.4)-.055)
 return np.rint(np.clip(encoded,0,1)*255).astype('int32')
expected=srgb(reference)
def stats(rgb):
 d=np.abs(rgb.astype('int32')-expected);samples=d[mask];pixels=samples.max(axis=1)
 return dict(overOne=int((pixels>1).sum()),maxByteError=int(samples.max()),meanByteError=float(samples.mean()),channelOverOne=[int((samples[:,c]>1).sum()) for c in range(3)],exactPixels=int((pixels==0).sum()))
rows={'frozen':stats(frozen),'cpuHdrConversion':stats(srgb(hdr))}
def quantize(x,mode):
 result=[]
 for c,bits in enumerate([6,6,5]):
  values=np.maximum(x[:,:,c],0);_,e=np.frexp(values);step=np.ldexp(np.ones_like(values),np.maximum(e-1-bits,-14-bits))
  units=values/step
  q=np.rint(units) if mode=='nearest' else np.floor(units) if mode=='floor' else np.ceil(units)
  result.append(q*step)
 return np.stack(result,axis=-1)
for mode in ['nearest','floor','ceil']:
 q=quantize(hdr*4,mode)*.25
 rows[mode]=stats(srgb(q));rows[mode]['exactNativeLinearPixels']=int(np.all(q==reference,axis=2)[mask].sum())
baseline=np.abs(frozen.astype('int32')-expected)[mask];bad=baseline.max(axis=1)>1
rows['frozen']['badPixelDominantChannel']=[int((baseline[bad].argmax(axis=1)==c).sum()) for c in range(3)]
result=dict(status='analysed',scope='CPU attachment-precision hypothesis on frozen hair region; no shader modification, native run or quality pass claim.',engineHdrDisplayScale=.25,box=box,maskPixels=int(mask.sum()),hdrToFrozenOverOne=int((np.abs(srgb(hdr)-frozen).max(axis=2)[mask]>1).sum()),rows=rows,inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [native,maskFile,prior/'original-hdr.zlib',prior/'original-final.zlib']})
(out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['rows']),flush=True);print('HDR to frozen over-one',result['hdrToFrozenOverOne'],flush=True)
