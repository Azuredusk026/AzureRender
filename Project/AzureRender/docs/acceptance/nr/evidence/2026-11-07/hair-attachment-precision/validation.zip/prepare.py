from pathlib import Path
import re,json,sys,subprocess,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs
assert check(root/'build',run=out,planned=12*1024**2,diagnostic=True)['allowed']
(out/'source-inputs.json').write_text(json.dumps(inputs(root),indent=2))
prior=root/'build/runs/20261107-191143-hair-gradient-region-08b1f9'
constants='''
%az_maskRG = OpConstant %uint 4294836224
%az_maskB = OpConstant %uint 4294705152
%az_masks = OpConstantComposite %v3uint %az_maskRG %az_maskRG %az_maskB
%az_zero = OpConstant %float 0
%az_highRG = OpConstant %float 65024
%az_highB = OpConstant %float 64512
%az_high = OpConstantComposite %v3float %az_highRG %az_highRG %az_highB
%az_zero3 = OpConstantComposite %v3float %az_zero %az_zero %az_zero
%az_minNormal = OpConstant %float 0.00006103515625
%az_minNormal3 = OpConstantComposite %v3float %az_minNormal %az_minNormal %az_minNormal
%az_invStepRG = OpConstant %float 1048576
%az_invStepB = OpConstant %float 524288
%az_stepRG = OpConstant %float 0.00000095367431640625
%az_stepB = OpConstant %float 0.0000019073486328125
%az_invSteps = OpConstantComposite %v3float %az_invStepRG %az_invStepRG %az_invStepB
%az_steps = OpConstantComposite %v3float %az_stepRG %az_stepRG %az_stepB
'''
rows=[]
for name,source in [('rtz',prior/'original-hair.spvasm'),('fine-rtz',prior/'fine.spvasm')]:
 text=source.read_text();assert 'OpName %outputColor "outputColor"' in text
 function=re.search(r'%main = OpFunction[\s\S]*?OpFunctionEnd',text);assert function
 main=function[0];returns=main.count('OpReturn\n');assert returns==1,returns
 block='''
%az_source = OpLoad %v4float %outputColor
%az_rgb = OpVectorShuffle %v3float %az_source %az_source 0 1 2
%az_clamped = OpExtInst %v3float %1 FClamp %az_rgb %az_zero3 %az_high
%az_bits = OpBitcast %v3uint %az_clamped
%az_trimmed = OpBitwiseAnd %v3uint %az_bits %az_masks
%az_normal = OpBitcast %v3float %az_trimmed
%az_scaled = OpFMul %v3float %az_clamped %az_invSteps
%az_floor = OpExtInst %v3float %1 Floor %az_scaled
%az_denorm = OpFMul %v3float %az_floor %az_steps
%az_small = OpFOrdLessThan %v3bool %az_clamped %az_minNormal3
%az_rgbRtz = OpSelect %v3float %az_small %az_denorm %az_normal
%az_alpha = OpCompositeExtract %float %az_source 3
%az_result = OpCompositeConstruct %v4float %az_rgbRtz %az_alpha
OpStore %outputColor %az_result
OpReturn
'''
 main=main.replace('OpReturn\n',block,1);text=text[:function.start()]+constants+main+text[function.end():]
 assembly=out/(name+'.spvasm');assembly.write_text(text)
 command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-as.exe','--target-env','vulkan1.0' if name=='rtz' else 'vulkan1.1',str(assembly),'-o',str(out/(name+'.spv'))]
 r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr
 validate=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0' if name=='rtz' else 'vulkan1.1',str(out/(name+'.spv'))]
 r=subprocess.run(validate,capture_output=True,text=True);assert r.returncode==0,r.stderr
 rows.append(dict(name=name,source=str(source),command=command,validationCommand=validate,sha256=hashlib.sha256((out/(name+'.spv')).read_bytes()).hexdigest()))
(out/'variants.json').write_text(json.dumps(rows,indent=2));print('Prepared two output-conversion controls; production remains unchanged',flush=True)
