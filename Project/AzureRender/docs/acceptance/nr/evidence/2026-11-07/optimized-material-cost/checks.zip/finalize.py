from pathlib import Path
import json,zipfile,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];r=json.loads((out/'result.json').read_text());b=[x['matchedEventMs'] for x in r['summary'] if x['mode']=='baseline'];r.update(status='not-qualified',baselineMatchedDriftFraction=max(b)/min(b)-1,benefitQualified=False,nativeBatchStarted=False,processExitCorrection='Explicit sys.exit after resource shutdown; replay process exited successfully')
e=root/'docs/acceptance/nr/evidence/2026-11-07/optimized-material-cost';e.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(e/'checks.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.iterdir():
  if p.is_file() and p.suffix!='.spv':z.write(p,p.name)
p=e/'checks.zip';r['archive']=dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest());(e/'results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
