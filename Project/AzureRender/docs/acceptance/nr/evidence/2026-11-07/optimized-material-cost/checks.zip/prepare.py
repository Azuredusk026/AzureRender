from pathlib import Path
import json,shutil
out=Path(__file__).resolve().parent;root=out.parents[2];old=root/'build/runs/20261107-133026-material-spirv-optimization-4b47ef';template=root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25'
rows=json.loads((old/'candidate-build.json').read_text());(out/'candidate-build.json').write_text(json.dumps(rows,indent=2))
for row in rows:shutil.copy2(old/row['file'],out/row['file'])
source=(template/'compare.py').read_text().replace("out=root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25'","out=root/'build/runs/20261107-135008-optimized-material-cost-e1c8e5'").replace("profile=json.loads((out/'profile.json').read_text())","profile=json.loads((root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/profile.json').read_text())").replace('Eleven captured material modules; only nine per-draw push-constant texture index expressions change. Lighting, floating-point formulas and early-depth policies are preserved.','Eleven original captured modules optimized using SPIRV-Tools -O; specialization IDs and bindings preserved.')
assert 'sys.exit(' in source
(out/'compare.py').write_text(source)
