from pathlib import Path
import json,hashlib,sys,traceback
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-135008-optimized-material-cost-e1c8e5';g=root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea';state=json.loads((g/'state.json').read_text());profile=json.loads((root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/profile.json').read_text());report=dict(status='starting',scope='Eleven original captured modules optimized using SPIRV-Tools -O; specialization IDs and bindings preserved.',captureSha256=state['captureSha256']);cap=None;c=None

def save():(out/'compare-state.json').write_text(json.dumps(report,indent=2))
def durations():return {int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
try:
 assert any(row['value']==1 for row in profile['recordedDynamicIndexFeature']);save();cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 files={row['file'] for row in json.loads((out/'candidate-build.json').read_text())};shaders={k:v for k,v in profile['shaders'].items() if v['programFile'] in files};compiled={};programRows=[]
 for key,entry in shaders.items():
  event=next(r['event'] for r in profile['rows'] if r['fragment']==key);c.SetFrameEvent(event,True);pipe=c.GetPipelineState();shader=pipe.GetShader(rd.ShaderStage.Pixel);r=pipe.GetShaderReflection(rd.ShaderStage.Pixel);assert hashlib.sha256(bytes(r.rawBytes)).hexdigest()==entry['sha256']
  program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/entry['programFile']).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert program!=rd.ResourceId.Null(),errors
  compiled[key]=(shader,program);programRows.append(dict(shader=key,file=entry['programFile'],event=event,errors=errors))
 selected=[]
 for prefix in ['character_snapshot_object_bindless_clipmap_field_early.frag','mesh_object_bindless_clipmap_field_early.frag','mesh_object_bindless_clipmap_field_lighting.frag']:
  selected.append(max((r for r in profile['rows'] if (r['program']or'').startswith(prefix)),key=lambda r:r['milliseconds'])['event'])
 selected.append(max(r['event'] for r in profile['rows']));controls={}
 for event in selected:
  c.SetFrameEvent(event,True)
  for index,target in enumerate(c.GetPipelineState().GetOutputTargets()):
   if target.resource!=rd.ResourceId.Null():controls[(event,index)]=(target.resource,bytes(c.GetTextureData(target.resource,rd.Subresource())))
 durations();durations();durations();report.update(status='baseline-read',programs=programRows,controlEvents=selected,timings=[dict(mode='baseline',milliseconds=durations())]);save()
 for shader,program in compiled.values():c.ReplaceResource(shader,program)
 comparisons=[]
 for (event,index),(resource,data) in controls.items():
  c.SetFrameEvent(event,True);value=bytes(c.GetTextureData(resource,rd.Subresource()));comparisons.append(dict(event=event,target=index,bytes=len(data),equal=value==data,baselineSha256=hashlib.sha256(data).hexdigest(),candidateSha256=hashlib.sha256(value).hexdigest()))
 report.update(status='candidate-read',comparisons=comparisons);save();durations()
 for unused in range(2):report['timings'].append(dict(mode='candidate',milliseconds=durations()));save()
 for shader,program in compiled.values():c.RemoveReplacement(shader)
 durations();report['timings'].append(dict(mode='baseline',milliseconds=durations()));matched={r['event'] for r in profile['rows'] if r['fragment'] in shaders};report['summary']=[dict(mode=r['mode'],allEventMs=sum(r['milliseconds'].values()),matchedEventMs=sum(ms for e,ms in r['milliseconds'].items() if e in matched)) for r in report['timings']];report.update(status='compared',matchedDrawCount=len(matched),allTargetsEqual=all(r['equal'] for r in comparisons));save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='compared' else 1)
