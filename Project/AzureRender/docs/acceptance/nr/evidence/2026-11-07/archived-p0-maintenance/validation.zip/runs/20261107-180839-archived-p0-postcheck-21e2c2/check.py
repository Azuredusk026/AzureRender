from pathlib import Path
import json, os, subprocess, sys, time, xml.etree.ElementTree as ET

root = Path.cwd()
out = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'tools'))
from artifact_budget import check
from build_provenance import digest, inputs

assert check(root / 'build', run=out, planned=2*1024**2, diagnostic=True)['allowed']
source = inputs(root)
frozen = json.loads((root / 'docs/acceptance/nr/evidence/2026-11-07/binary-material-images/results.json').read_text(encoding='utf-8'))['sourceInputs']
assert source == frozen
env = dict(os.environ)
env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0', VCPKG_ROOT='D:/Tools/vcpkg', DOTNET_ROOT='D:/Tools/dotnet9', CMAKE_BUILD_PARALLEL_LEVEL='3')
cmake = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
ctest = str(Path(cmake).with_name('ctest.exe'))
rows = []
for config in ['Debug', 'Release']:
    build = root / ('build/ninja-msvc-' + config.lower())
    before = {p.name: digest(p) for p in (build/'shaders').glob('*.spv')}
    commands = [
        ('build', ['cmd', '/d', '/c', str(root/'tools/msvc_env.bat'), cmake, '--build', str(build), '--target', 'AzureRender', 'AzurePlayer', 'AzureRenderCore', 'AzureMaterialDocumentTests', '--parallel', '3']),
        ('checks', [ctest, '--test-dir', str(build), '-R', '^AzureAssets\\.MaterialDocument$', '--output-on-failure', '--no-tests=error', '--output-junit', str(out/(config.lower()+'-checks.xml'))]),
    ]
    for kind, command in commands:
        start = time.monotonic()
        with (out/(config.lower()+'-'+kind+'.log')).open('wb') as log:
            p = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=600)
        rows.append(dict(configuration=config, kind=kind, command=command, exitCode=p.returncode, seconds=time.monotonic()-start))
        (out/'checks.json').write_text(json.dumps(rows, indent=2)+'\n', encoding='utf-8')
        print(config, kind, p.returncode, flush=True)
        assert p.returncode == 0, (out/(config.lower()+'-'+kind+'.log')).read_text(errors='replace')[-4000:]
    cases = ET.parse(out/(config.lower()+'-checks.xml')).findall('.//testcase')
    assert len(cases) == 1 and all(c.find('failure') is None for c in cases)
    assert len(before) == 663 and before == {p.name: digest(p) for p in (build/'shaders').glob('*.spv')}
assert inputs(root) == source
print('PASS: both main builds, two scoped checks, all source and shader bytes unchanged', flush=True)
