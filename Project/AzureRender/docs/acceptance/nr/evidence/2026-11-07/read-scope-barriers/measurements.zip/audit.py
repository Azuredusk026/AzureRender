from pathlib import Path
import json,sys,traceback,collections
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-062757-read-scope-barriers-3c24e5';a=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc';state=json.loads((a/'state.json').read_text());cap=None;c=None;report=dict(status='starting',sourceBase='35cc28f',captureSha256=state['captureSha256'])
def children(o):return {str(o.GetChild(i).name):o.GetChild(i) for i in range(o.NumChildren())}
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 rows=[];counts=collections.Counter();sf=c.GetStructuredFile()
 for index,chunk in enumerate(sf.chunks):
  if str(chunk.name)!='vkCmdPipelineBarrier':continue
  fields=children(chunk)
  buffers=fields.get('pBufferMemoryBarriers')
  if buffers is None:raise ValueError(str(list(fields)))
  if not buffers.NumChildren():continue
  destination=fields.get('dstStageMask') or fields.get('destStageMask')
  if destination is None:raise ValueError(str(list(fields)))
  row=dict(chunk=index,commandBuffer=str(fields['commandBuffer'].AsResourceId()),srcStageMask=int(fields['srcStageMask'].data.basic.u),dstStageMask=int(destination.data.basic.u),buffers=[])
  for i in range(buffers.NumChildren()):
   f=children(buffers.GetChild(i));row['buffers'].append(dict(buffer=str(f['buffer'].AsResourceId()),offset=int(f['offset'].data.basic.u),size=int(f['size'].data.basic.u),srcAccessMask=int(f['srcAccessMask'].data.basic.u),dstAccessMask=int(f['dstAccessMask'].data.basic.u)))
  rows.append(row);counts[row['commandBuffer']]+=len(row['buffers'])
 report.update(status='audited',bufferBarrierCalls=len(rows),bufferBarrierEntries=sum(len(r['buffers']) for r in rows),commandBuffers=dict(counts),rows=rows)
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'audit-results.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='audited' else 1)
