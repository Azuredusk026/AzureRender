from pathlib import Path
import json,shutil,sys,zipfile
out=Path(__file__).resolve().parent;root=out.parents[2];e=root/'docs/acceptance/nr/evidence/2026-11-07/read-scope-barriers';e.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
build=root/'build/ninja-msvc-release';provenance=json.loads((build/'build-provenance.json').read_text());verify(root,provenance)
before=json.loads((out/'baseline-products.json').read_text());changes={p:h for p,h in inputs(root).items() if before['source'].get(p)!=h}
programs={p.name:digest(p) for p in (build/'shaders').glob('*.spv')};assert programs==before['programs'] and len(programs)==663
pair={r:json.loads((out/('performance-'+r)/'results.json').read_text()) for r in ['baseline','candidate']};image=json.loads((out/'image/results.json').read_text());assert image['status']=='passed'
record={}
for role in pair:
 s=json.loads((out/('performance-'+role)/'timing.json').read_text())['submission'];record[role]=dict(frames=s['frames'],scope='All 420 recorded frames including warmup; native CPU/GPU summary uses final 120 samples',recordingMeanMs=s['recordingMilliseconds']/s['frames'],graphPreparationMeanMs=s['graphPreparationMilliseconds']/s['frames'],workerWaitMeanMs=s['workerWaitMilliseconds']/s['frames'],graphExecutionMeanMs=s['graphExecutionMilliseconds']/s['frames'])
summary=dict(schemaVersion=1,status='adopted-diagnostic-cpu-improvement',sourceBase='956f501',localControl=json.loads((out/'controls-results.json').read_text()),qualification=json.loads((out/'qualification.json').read_text()),recording=record,
 native=dict(baseline=pair['baseline'],candidate=pair['candidate'],savedCpuMeanMs=pair['baseline']['cpu']['mean']-pair['candidate']['cpu']['mean'],savedCpuP95Ms=pair['baseline']['cpu']['p95']-pair['candidate']['cpu']['p95'],cpuMeanReduction=1-pair['candidate']['cpu']['mean']/pair['baseline']['cpu']['mean'],all663ProgramsByteIdentical=True,gpuBenefitClaimed=False,formalAcceptance=False),
 image=image,checks=json.loads((out/'build-checks.json').read_text()),batch=json.loads((out/'validation-batch.json').read_text()),required=dict(cpuP95Ms=8,gpuP95Ms=16.6,samples=1800,stablePowerWatts=80,overallVisual='failed-user-review'),
 limitations=['Projected 15 barrier calls and 768 entries belong to the private range-based input control; native candidate API counts were not captured.','The local backend timer excludes read-scope preparation, graph compilation and GPU driver cost.','Recording stage averages cover all 420 frames; native CPU and GPU comparison uses final 120 samples.','Candidate telemetry includes one software thermal slowdown observation.','All-observation 80 W stability remains failed.','Formal frame budgets and overall visual acceptance remain failed.'])
tests=['tests/RenderGraphTests.cpp','tests/BufferBarrierBatchTests.cpp'];candidate=out/'candidate-source'
for name in list(changes)+tests:
 p=candidate/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,p)
(out/'final-build-provenance.json').write_text(json.dumps(provenance,indent=2))
archive=e/'measurements.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(out.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(out)
  if any(v in rel.parts for v in ['baseline','__pycache__','.azure','shaders']):continue
  if p.suffix.lower() in ['.py','.json','.log','.xml','.cpp','.hpp','.inc','.diff','.azureproject','.azurelevel']:z.write(p,str(rel))
summary['archive']=dict(file=archive.name,bytes=archive.stat().st_size,sha256=digest(archive));(e/'results.json').write_text(json.dumps(summary,indent=2))
manifest=dict(schemaVersion=1,kind='NativeOptimizationEvidence',sourceBase='956f501',status=summary['status'],sourceChanges=changes,tests={name:digest(root/name) for name in tests},configuration='Release',buildProvenanceSha256=digest(build/'build-provenance.json'),buildScope=provenance['buildScope'],playerSha256=digest(build/'AzurePlayer.exe'),programCount=663,allProgramsByteIdentical=True,results=dict(file='results.json',sha256=digest(e/'results.json')),archive=summary['archive'],phaseChecksPassed=True,formalPerformanceAccepted=False,overallVisualAccepted=False)
(e/'manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(dict(status=summary['status'],native=summary['native']['savedCpuMeanMs'],recording=record,archive=summary['archive'])),flush=True)
