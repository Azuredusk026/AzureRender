#include "runtime/LevelSession.hpp"
#include "render/RenderContext.hpp"
#include <chrono>
#include <iostream>
#include <fstream>
#include <unordered_set>
#include <map>
#include <algorithm>
using namespace azurerender;
using namespace azurerender::rhi;
static std::size_t apiCalls=0,entries=0,checksum=0;
extern "C" VKAPI_ATTR void VKAPI_CALL vkCmdPipelineBarrier(VkCommandBuffer,VkPipelineStageFlags a,VkPipelineStageFlags b,VkDependencyFlags,
    std::uint32_t,const VkMemoryBarrier*,std::uint32_t count,const VkBufferMemoryBarrier* barriers,std::uint32_t,const VkImageMemoryBarrier*){
    ++apiCalls;entries+=count;checksum+=a+b;for(unsigned i=0;i<count;++i)checksum+=std::size_t(barriers[i].buffer)+barriers[i].dstAccessMask;
}
#include "BarrierReference.inc"
#include "BarrierCandidate.inc"
using Windows=std::vector<std::vector<BufferBarrierDesc>>;
Windows coalesce(Windows windows){
    struct State{std::size_t window=0,index=0;bool reading=false;VkPipelineStageFlags stages=0;VkAccessFlags access=0;};
    std::map<std::tuple<VkBuffer,VkDeviceSize,VkDeviceSize>,State> states;
    std::vector<std::vector<bool>> keep;for(const auto& w:windows)keep.emplace_back(w.size(),true);
    constexpr VkAccessFlags writes=VK_ACCESS_SHADER_WRITE_BIT|VK_ACCESS_TRANSFER_WRITE_BIT|VK_ACCESS_HOST_WRITE_BIT|VK_ACCESS_MEMORY_WRITE_BIT|VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT|VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
    for(std::size_t w=0;w<windows.size();++w)for(std::size_t i=0;i<windows[w].size();++i){auto& value=windows[w][i];auto& state=states[{value.buffer,value.offset,value.size}];
        if((value.dstAccessMask&writes)!=0){if(state.reading){value.srcStageMask=state.stages;value.srcAccessMask=state.access;}state={};}
        else if(state.reading){auto& first=windows[state.window][state.index];first.dstStageMask|=value.dstStageMask;first.dstAccessMask|=value.dstAccessMask;
            state.stages|=value.dstStageMask;state.access|=value.dstAccessMask;keep[w][i]=false;}
        else state={w,i,true,value.dstStageMask,value.dstAccessMask};
    }
    for(std::size_t w=0;w<windows.size();++w){std::size_t to=0;for(std::size_t i=0;i<windows[w].size();++i)if(keep[w][i])windows[w][to++]=windows[w][i];windows[w].resize(to);}
    return windows;
}
int main(int argc,char**argv)try{
    if(argc!=3)return 2;nlohmann::json audit;std::ifstream(argv[1])>>audit;Windows windows;std::size_t previous=0;
    for(const auto& row:audit["rows"]){const auto chunk=row["chunk"].get<std::size_t>();if(windows.empty()||chunk!=previous+1)windows.emplace_back();previous=chunk;
        for(const auto& item:row["buffers"]){const auto label=item["buffer"].get<std::string>();const auto id=std::stoull(label.substr(label.find_last_of(':')+1));
            BufferBarrierDesc b;b.buffer=reinterpret_cast<VkBuffer>(std::uintptr_t(id));b.offset=item["offset"];b.size=item["size"];
            b.srcStageMask=row["srcStageMask"];b.dstStageMask=row["dstStageMask"];b.srcAccessMask=item["srcAccessMask"];b.dstAccessMask=item["dstAccessMask"];windows.back().push_back(b);}}
    const auto optimized=coalesce(windows);const auto command=reinterpret_cast<VkCommandBuffer>(std::uintptr_t(900));
    const auto emit=[&](bool candidate){for(const auto& window:candidate?optimized:windows)if(candidate)candidateBarriers(command,window.data(),window.size());else referenceBarriers(command,window.data(),window.size());};
    emit(false);const auto beforeCalls=apiCalls,beforeEntries=entries;apiCalls=entries=0;emit(true);const auto afterCalls=apiCalls,afterEntries=entries;apiCalls=entries=0;
    double before=0,after=0;constexpr unsigned rounds=200;
    const auto measure=[&](bool candidate){const auto start=std::chrono::steady_clock::now();emit(candidate);return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();};
    for(unsigned i=0;i<rounds;++i){if(i&1){before+=measure(false);after+=measure(true);}else{after+=measure(true);before+=measure(false);}}
    ProjectStartup startup(Project::load(std::filesystem::u8path(argv[2])));const auto description=startup.level().scene.renderDescription();
    double copy=0,empty=0;const auto prepare=[&](bool include){const auto start=std::chrono::steady_clock::now();{RenderContext context;context.sceneWorldCoordinates=true;if(include)context.scene=description;
        auto frozen=context;frozen.scene={};checksum+=frozen.scene.nodes.size()+context.scene.nodes.size()+frozen.maxFramesInFlight;}
        return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();};
    for(unsigned i=0;i<rounds;++i){if(i&1){copy+=prepare(true);empty+=prepare(false);}else{empty+=prepare(false);copy+=prepare(true);}}
    std::cout<<nlohmann::json{{"scope","Actual captured barrier ranges grouped by consecutive API windows; production literal baseline and private candidate; backend CPU conversion excludes GPU/driver latency and graph compile; coalescing is prepared outside this timing"},
        {"rounds",rounds},{"windows",windows.size()},{"baselineCalls",beforeCalls},{"candidateCalls",afterCalls},{"baselineEntries",beforeEntries},{"candidateEntries",afterEntries},
        {"backendBaselineMs",before/rounds},{"backendCandidateMs",after/rounds},{"backendReduction",1-after/before},
        {"sceneNodes",description.nodes.size()},{"sceneResources",description.resources.size()},{"contextBaselineMs",copy/rounds},{"contextCandidateMs",empty/rounds},
        {"contextScope","Native description value copy into frame context, subsequent context copy and discarded scene; excludes unrelated context setup"},{"checksum",checksum}}.dump()<<'\n';return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
