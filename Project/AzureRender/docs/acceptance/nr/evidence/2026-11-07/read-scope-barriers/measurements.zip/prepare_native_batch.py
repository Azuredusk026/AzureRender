from pathlib import Path
import json
out=Path(__file__).resolve().parent;root=out.parents[2];previous=root/'build/runs/20261107-052311-dynamic-geometry-preparation-e7a5c3'
for name in ['capture','measure_baseline','measure_candidate','validate_batch']:
 s=(previous/(name+'.py')).read_text().replace('adfdc00-with-dynamic-geometry-preparation','956f501-with-read-scope-barriers').replace('adfdc00','956f501').replace('Compact transparent preparation and reusable motion history','Complete buffer read scopes, grouped stage pairs and recording context preparation')
 (out/(name+'.py')).write_text(s)
control=json.loads((out/'controls-results.json').read_text());timing=json.loads((previous/'performance-candidate/timing.json').read_text());submission=timing['submission'];record=submission['recordingMilliseconds']/submission['frames'];cpu=json.loads((previous/'performance-candidate/results.json').read_text())['cpu']['mean']
saved=control['backendBaselineMs']-control['backendCandidateMs']+control['contextBaselineMs']-control['contextCandidateMs']
qualification=dict(kind='AffectedCommandRecordingHotspot',affectedMeanMs=record,referenceCpuMeanMs=cpu,affectedCpuFraction=record/cpu,measuredLocalConversionAndCopySavedMs=saved,expectedReducedWorkFraction=saved/record,baselineBarrierCalls=1525,candidateControlBarrierCalls=15,qualified=record/cpu>=.25 and saved/record>=.20,scope='Actual recorded resource ranges and native description; CPU conversion and two discarded scene copies only. Driver recording latency, graph compilation and per-frame read-scope preparation are outside the local timing. The production graph already walks the same uses; its modified work and all driver effects remain subject to native measurement.')
assert qualification['qualified'];(out/'qualification.json').write_text(json.dumps(qualification,indent=2))
print(json.dumps(qualification),flush=True)
