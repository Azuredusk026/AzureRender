from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2]
s=(out/'original-source/src/rhi/VulkanRhi.cpp').read_text();first=s.index('void VulkanCommandRecorder::bufferBarriers(');last=s.index('\n}',first)+2
body=s[first:last].replace('void VulkanCommandRecorder::bufferBarriers(', 'void referenceBarriers(VkCommandBuffer commandBuffer_,')
(out/'BarrierReference.inc').write_text(body+'\n')
original=(root/'build/runs/20261107-052311-dynamic-geometry-preparation-e7a5c3/build_controls.py').read_text()
original=original.replace("['GeometryControls','MotionPoseDataReference']","['CommandControls']").replace('GeometryControls','CommandControls')
(out/'build_controls.py').write_text(original)
