from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2];target=root/'src/rhi/VulkanRhi.cpp'
source=target.read_text();first=source.index('void VulkanCommandRecorder::bufferBarriers(');last=source.index('\n}',first)+2
body=(out/'BarrierCandidate.inc').read_text().replace('void candidateBarriers(VkCommandBuffer commandBuffer_,','void VulkanCommandRecorder::bufferBarriers(').rstrip()
source=source[:first]+body+source[last:];source=source.replace('#include <vector>','#include <vector>\n#include <unordered_set>')
target.write_text(source)
