from pathlib import Path
import json,shutil,sys
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release';sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from artifact_budget import check
verify(root,json.loads((build/'build-provenance.json').read_text()))
products=[build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]
budget=check(root/'build',run=out,planned=sum(p.stat().st_size for p in products));assert budget['allowed'],budget
baseline=out/'baseline';baseline.mkdir();(baseline/'shaders').mkdir()
for p in products:shutil.copy2(p,baseline/('shaders/'+p.name if p.suffix=='.spv' else p.name))
for name in ['src/render/RenderGraph.cpp','src/render/RenderGraph.hpp','src/rhi/VulkanRhi.cpp','src/app/AzureRenderApp.cpp','src/app/AzureRenderApp.hpp','src/app/AzureRenderFrame.cpp','tests/RenderGraphTests.cpp','tests/BufferBarrierBatchTests.cpp']:
 target=out/'original-source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,target)
(out/'baseline-products.json').write_text(json.dumps(dict(sourceBase='956f501',source=inputs(root),playerSha256=digest(products[0]),programs={p.name:digest(p) for p in products[1:]}),indent=2))
print('Frozen production products and command preparation source',flush=True)
