from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2]
s=(root/'build/runs/20261107-052311-dynamic-geometry-preparation-e7a5c3/build_and_check.py').read_text()
first=s.index('targets=');end=s.index('\ncommands=',first)
s=s[:first]+"targets=['AzureRenderRenderGraphTests','AzureBufferBarrierBatchTests','AzureRenderNullRhiPassTests','AzureStaticSkinningRecordingTests','AzureNodeOpacityRecordingTests','AzureDepthOnlyShadowRecordingTests']"+s[end:]
s=s.replace('TransparentTopology|MotionPoseData|StableDepthOrder|MotionVectorTarget|TemporalViewState|MotionPoseGpu|MotionVectorGpu','RenderGraph|BufferBarrierBatch|NullRhiPass|StaticSkinningRecording|NodeOpacityRecording|DepthOnlyShadowRecording')
(out/'build_and_check.py').write_text(s)
