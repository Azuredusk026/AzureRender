from pathlib import Path
import json,subprocess,time
out=Path(__file__).resolve().parent;si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'audit-driver.log').open('wb') as log:r=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'audit.py')],stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=180)
p=json.loads((out/'audit-results.json').read_text());assert r.returncode==0 and p['status']=='audited',p
print(json.dumps(dict(status=p['status'],seconds=time.monotonic()-start,bufferBarrierCalls=p['bufferBarrierCalls'],bufferBarrierEntries=p['bufferBarrierEntries'],commandBuffers=p['commandBuffers'])),flush=True)
