from pathlib import Path
import json,os,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
manifest=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text());verify(root,manifest);source=inputs(root)
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
selected=[project,out/'audit-results.json',out/'CommandControls.exe',out/'CommandControls.cpp',out/'BarrierReference.inc',out/'BarrierCandidate.inc']
frozen={str(p):digest(p) for p in selected};command=[str(out/'CommandControls.exe'),str(out/'audit-results.json'),str(project)]
env=os.environ.copy();env['PATH']=str(root/'build/ninja-msvc-release')+';'+env.get('PATH','');start=time.monotonic()
with (out/'controls-output.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0,(out/'controls-output.log').read_text(errors='replace')[-4000:]
result=json.loads((out/'controls-output.log').read_text().splitlines()[-1]);assert source==inputs(root) and all(digest(Path(p))==h for p,h in frozen.items());verify(root,manifest)
result.update(sourceBase='956f501',seconds=time.monotonic()-start,command=command,inputs=frozen,productionUnchanged=True)
(out/'controls-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
