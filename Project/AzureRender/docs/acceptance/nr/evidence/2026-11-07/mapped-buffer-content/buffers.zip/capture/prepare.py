from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2];old=root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea';s=(old/'capture_current.py').read_text().replace(old.name,out.name)
s=s.replace("root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/AzurePlayer.exe'","root/'build/runs/20261107-141433-mapped-device-buffers-67ee70/candidate-products/release-AzurePlayer.exe'")
s=s.replace(",'--gpu-timing','--gpu-timing-output',str(out/'runtime-timing.json')",'')
s=s.replace('80f74e6-private-dynamic-index-feature','fbc0c99-private-mapped-device-buffers').replace('Actual current capture and replay event diagnosis; independent of native performance acceptance','One buffer-content diagnosis capture; GPU timing disabled; production remains restored')
loop='\n'.join(['while time.monotonic()<deadline and control.Connected():','        control.ReceiveMessage(None);time.sleep(.02)','        if sum(p.stat().st_size for p in out.glob("*") if p.is_file())>2**31:','            if pid:subprocess.run(["taskkill","/PID",str(pid),"/T","/F"],capture_output=True)','            raise RuntimeError("Capture exceeded the 2 GiB task quota")'])
s=s.replace('while time.monotonic()<deadline and control.Connected():control.ReceiveMessage(None);time.sleep(.02)',loop)
(out/'capture_current.py').write_text(s)
