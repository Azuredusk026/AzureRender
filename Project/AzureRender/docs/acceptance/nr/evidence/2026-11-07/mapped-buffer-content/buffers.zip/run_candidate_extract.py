from pathlib import Path
import subprocess,json,time
out=Path(__file__).resolve().parent;si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'candidate-driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'extract_candidate.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=180)
r=json.loads((out/'candidate.json').read_text());print(json.dumps(dict(status=r['status'],error=r.get('error'),seconds=time.monotonic()-start,totalBytes=r.get('totalBytes'),buffers=len(r.get('rows',[])))),flush=True)
