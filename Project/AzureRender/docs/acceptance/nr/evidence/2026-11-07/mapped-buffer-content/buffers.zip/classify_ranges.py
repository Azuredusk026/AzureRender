from pathlib import Path
import json,struct
out=Path(__file__).resolve().parent;a=json.loads((out/'baseline.json').read_text());b=json.loads((out/'candidate.json').read_text());am={r['index']:r for r in a['rows']};bm={r['index']:r for r in b['rows']}
def data(side,index):return (out/(side+'-buffers')/(am if side=='baseline' else bm)[index]['file']).read_bytes()
commands=list(struct.iter_unpack('<IIIiI',data('baseline',791)));physical=max(c[4] for c in commands)+1;assert physical==871 and all(c[1]<=1 and c[4]<physical for c in commands)
instances=data('baseline',766);stride=496;aliases=[]
for index in range(physical,physical+3):
 row=instances[index*stride:(index+1)*stride];assert struct.unpack_from('<I',row,428)[0]&1
 matches=[i for i in range(physical) if instances[i*stride:i*stride+428]==row[:428]];assert matches;aliases.append(dict(index=index,physicalMatches=matches))
used=(physical+len(aliases))*stride;assert used==433504
regions=[dict(index=766,kind='instance records',stride=stride,activeRecords=physical+len(aliases),activeBytes=used),dict(index=790,kind='culling bounds',stride=32,activeRecords=physical,activeBytes=physical*32)]
for row in regions:
 old=data('baseline',row['index']);new=data('candidate',row['index']);assert old[:row['activeBytes']]==new[:row['activeBytes']];row.update(activeBytesIdentical=True,capacityBytes=len(old),tailBytes=len(old)-row['activeBytes'])
r=dict(status='active-ranges-identical',physicalInstances=physical,indirectCommands=len(commands),materialAliases=aliases,regions=regions,scope='Captured frame 320 at corresponding draw ordinal 2829; this does not establish the inputs of the failing native frame 3');(out/'active-ranges.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
