from pathlib import Path
import json,struct,math
out=Path(__file__).resolve().parent;a=json.loads((out/'baseline.json').read_text());b=json.loads((out/'candidate.json').read_text());assert a['status']==b['status']=='extracted';bm={r['index']:r for r in b['rows']};rows=[]
for r in a['rows']:
 s=bm[r['index']];old=(out/'baseline-buffers'/r['file']).read_bytes();new=(out/'candidate-buffers'/s['file']).read_bytes();assert len(old)==len(new) and r['usage']==s['usage'];changed=[i for i,(x,y) in enumerate(zip(old,new)) if x!=y];words=sorted({i//4 for i in changed});examples=[]
 for i in words[:40]:
  x=old[i*4:i*4+4];y=new[i*4:i*4+4]
  if len(x)!=4:continue
  xf=struct.unpack('<f',x)[0];yf=struct.unpack('<f',y)[0];examples.append(dict(word=i,byteOffset=i*4,oldHex=x.hex(),newHex=y.hex(),oldFloat=xf if math.isfinite(xf) else str(xf),newFloat=yf if math.isfinite(yf) else str(yf)))
 rows.append(dict(index=r['index'],bytes=len(old),usage=r['usage'],baselineMemoryType=r['memoryTypeIndex'],candidateMemoryType=s['memoryTypeIndex'],identical=not changed,changedBytes=len(changed),changedWords=len(words),examples=examples))
result=dict(status='compared',scope='Untyped words and their float reinterpretations are diagnostic encodings; field semantics require the source layout',baselineEvent=a['lastEvent'],candidateEvent=b['lastEvent'],rows=rows,identicalBuffers=sum(r['identical'] for r in rows),changedBuffers=sum(not r['identical'] for r in rows));(out/'comparison.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(identical=result['identicalBuffers'],changed=result['changedBuffers'],rows=[{k:v for k,v in r.items() if k!='examples'} for r in rows]),indent=2))
