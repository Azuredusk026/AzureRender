from pathlib import Path
import json,zipfile,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];capture=root/'build/runs/20261107-145514-mapped-buffer-capture-e067af';e=root/'docs/acceptance/nr/evidence/2026-11-07/mapped-buffer-content';e.mkdir(parents=True,exist_ok=True);r=json.loads((out/'comparison.json').read_text());active=json.loads((out/'active-ranges.json').read_text());assert active['status']=='active-ranges-identical'
changed={row['index'] for row in r['rows'] if not row['identical']};candidate=json.loads((out/'candidate.json').read_text());wanted={row['file'] for row in candidate['rows'] if row['index'] in changed}
with zipfile.ZipFile(e/'buffers.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.rglob('*'):
  if not p.is_file():continue
  if p.parent==out/'candidate-buffers' and p.name not in wanted:continue
  z.write(p,p.relative_to(out))
 for name in ['state.json','results.json','capture_current.py','prepare.py','run_capture.py','frozen-inputs.json']:
  z.write(capture/name,'capture/'+name)
p=e/'buffers.zip';result=dict(status='frame320-active-ranges-identical',wholeBuffersIdentical=r['identicalBuffers'],wholeBuffersWithTailDifferences=r['changedBuffers'],all37MemoryTypes=dict(baseline=2,candidate=4),activeRanges=active,capture=json.loads((capture/'results.json').read_text()),originalDynamicIndexFeatureDifference=True,originalGpuTimingEnabled=True,candidateGpuTimingEnabled=False,failedNativeFrame3Explained=False,productionChanged=False,archive=dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));(e/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(status=result['status'],archiveBytes=p.stat().st_size)))
