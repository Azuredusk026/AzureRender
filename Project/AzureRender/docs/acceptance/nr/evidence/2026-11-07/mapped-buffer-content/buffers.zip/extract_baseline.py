from pathlib import Path
import renderdoc as rd
import json,sys,traceback,hashlib
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-144729-mapped-buffer-content-bd6089';capture=root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea';state=json.loads((capture/'state.json').read_text());cap=None;c=None;report=dict(status='starting',captureSha256=state['captureSha256'])
def fields(o):return {str(o.GetChild(i).name):o.GetChild(i) for i in range(o.NumChildren())}
def save():(out/'baseline.json').write_text(json.dumps(report,indent=2))
try:
 save()
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 report['status']='capture-opened';save()
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 report['status']='controller-opened';save()
 allocations={};bindings={};creates=[]
 for chunk in c.GetStructuredFile().chunks:
  name=str(chunk.name);f=fields(chunk)
  if name=='vkAllocateMemory':
   info=fields(f['AllocateInfo']);allocations[str(f['Memory'].AsResourceId())]=int(info['memoryTypeIndex'].data.basic.u)
  elif name=='vkBindBufferMemory':bindings[str(f['buffer'].AsResourceId())]=str(f['memory'].AsResourceId())
  elif name=='vkCreateBuffer':
   info=fields(f['CreateInfo']);creates.append(dict(buffer=str(f['Buffer'].AsResourceId()),resource=f['Buffer'].AsResourceId(),bytes=int(info['size'].data.basic.u),usage=int(info['usage'].data.basic.u)))
 def events(items):
  for a in items:
   yield int(a.eventId)
   yield from events(a.children)
 last=21311;c.SetFrameEvent(last,True);report['status']='representative-event-replayed';save();rows=[];directory=out/'baseline-buffers';directory.mkdir(exist_ok=True)
 for i,row in enumerate(creates):
  memoryType=allocations.get(bindings.get(row['buffer']))
  if memoryType!=2 or not row['usage']&0x1fc:continue
  data=bytes(c.GetBufferData(row['resource'],0,0));assert len(data)==row['bytes'],(i,row['buffer'],len(data),row['bytes']);name=f'{i:04d}-{row["bytes"]}.bin';(directory/name).write_bytes(data);rows.append(dict(index=i,buffer=row['buffer'],bytes=len(data),usage=row['usage'],memoryTypeIndex=memoryType,file=name,sha256=hashlib.sha256(data).hexdigest()))
 report.update(status='extracted',lastEvent=last,createdBuffers=len(creates),rows=rows,totalBytes=sum(r['bytes'] for r in rows))
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 (out/'baseline.json').write_text(json.dumps(report,indent=2))
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='extracted' else 1)
