from pathlib import Path
import renderdoc as rd
import json,sys,traceback,hashlib
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-144729-mapped-buffer-content-bd6089';capture=root/'build/runs/20261107-145514-mapped-buffer-capture-e067af';state=json.loads((capture/'state.json').read_text());cap=None;c=None;report=dict(status='starting',captureSha256=state['captureSha256'])
def fields(o):return {str(o.GetChild(i).name):o.GetChild(i) for i in range(o.NumChildren())}
def save():(out/'candidate.json').write_text(json.dumps(report,indent=2))
try:
 save()
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 report['status']='capture-opened';save()
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 report['status']='controller-opened';save()
 baseline=json.loads((out/'baseline.json').read_text());wanted={r['index']:r for r in baseline['rows']};allocations={};bindings={};creates=[]
 for chunk in c.GetStructuredFile().chunks:
  name=str(chunk.name);f=fields(chunk)
  if name=='vkAllocateMemory':
   info=fields(f['AllocateInfo']);allocations[str(f['Memory'].AsResourceId())]=int(info['memoryTypeIndex'].data.basic.u)
  elif name=='vkBindBufferMemory':bindings[str(f['buffer'].AsResourceId())]=str(f['memory'].AsResourceId())
  elif name=='vkCreateBuffer':
   info=fields(f['CreateInfo']);creates.append(dict(buffer=str(f['Buffer'].AsResourceId()),resource=f['Buffer'].AsResourceId(),bytes=int(info['size'].data.basic.u),usage=int(info['usage'].data.basic.u)))
 def events(items):
  for a in items:
   yield int(a.eventId)
   yield from events(a.children)
 profile=json.loads((root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/profile.json').read_text());ordinal=next(i for i,r in enumerate(profile['rows']) if r['event']==21311)
 def draws(items):
  for a in items:
   if a.flags&rd.ActionFlags.Drawcall and not a.children:yield a
   yield from draws(a.children)
 actions=list(draws(c.GetRootActions()));assert len(actions)==len(profile['rows']),(len(actions),len(profile['rows']));assert len(creates)==baseline['createdBuffers']
 last=int(actions[ordinal].eventId);c.SetFrameEvent(last,True);reflection=c.GetPipelineState().GetShaderReflection(rd.ShaderStage.Pixel);assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==profile['shaders'][profile['rows'][ordinal]['fragment']]['sha256']
 report['status']='representative-event-replayed';report['drawOrdinal']=ordinal;save();rows=[];directory=out/'candidate-buffers';directory.mkdir(exist_ok=True)
 for i,row in enumerate(creates):
  memoryType=allocations.get(bindings.get(row['buffer']))
  if i not in wanted:continue
  assert row['bytes']==wanted[i]['bytes'] and row['usage']==wanted[i]['usage'],(i,row,wanted[i])
  data=bytes(c.GetBufferData(row['resource'],0,0));assert len(data)==row['bytes'],(i,row['buffer'],len(data),row['bytes']);name=f'{i:04d}-{row["bytes"]}.bin';(directory/name).write_bytes(data);rows.append(dict(index=i,buffer=row['buffer'],bytes=len(data),usage=row['usage'],memoryTypeIndex=memoryType,file=name,sha256=hashlib.sha256(data).hexdigest()))
 report.update(status='extracted',lastEvent=last,createdBuffers=len(creates),rows=rows,totalBytes=sum(r['bytes'] for r in rows))
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 (out/'candidate.json').write_text(json.dumps(report,indent=2))
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='extracted' else 1)
