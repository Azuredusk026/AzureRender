from pathlib import Path
import json,subprocess,sys,time,os
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from run_playable_performance import freeze_products
from artifact_budget import check
assert check(root/'build',run=out,planned=2130706432)['allowed']
parent=root/'build/runs/20261107-141433-mapped-device-buffers-67ee70';player=parent/'candidate-products/release-AzurePlayer.exe';expected=json.loads((parent/'candidate-files.json').read_text())[str(root/'build/ninja-msvc-release/AzurePlayer.exe')];assert digest(player)==expected
source=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe');products[str(player)]=expected
frozen=json.loads((parent/'image/frozen-inputs.json').read_text())['project']
def mounted():
 result={};shared={}
 for p in frozen:
  path=Path(p);st=path.stat();key=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
  if key not in shared:shared[key]=digest(path)
  result[p]=shared[key]
 return result
assert mounted()==frozen
(out/'frozen-inputs.json').write_text(json.dumps(dict(source=source,products=products,project=frozen),indent=2));print('Private candidate and 1729 mounted inputs frozen; timing disabled',flush=True)
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;env=dict(os.environ);env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);start=time.monotonic()
with (out/'driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'capture_current.py')],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=660)
r=json.loads((out/'state.json').read_text());assert p.returncode==0 and r['status']=='captured',r
assert inputs(root)==source and all(digest(Path(p))==h for p,h in products.items()) and mounted()==frozen
used=sum(p.stat().st_size for p in out.rglob('*') if p.is_file());assert used<=2**31
(out/'results.json').write_text(json.dumps(dict(status='captured',seconds=time.monotonic()-start,capture=r,sourceAndProductsUnchanged=True,allMountedBytesUnchanged=True,gpuTimingEnabled=False,usedBytes=used),indent=2));print(json.dumps(dict(status='captured',seconds=time.monotonic()-start,usedBytes=used)),flush=True)
