from pathlib import Path
import json,sys
out=Path(__file__).resolve().parent;root=out.parents[2];e=root/'docs/acceptance/nr/evidence/2026-11-07/unlit-blend-fast-path'
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
build=root/'build/ninja-msvc-release';record=json.loads((build/'build-provenance.json').read_text());verify(root,record)
before=json.loads((out/'baseline-products.json').read_text());after=inputs(root)
assert isinstance(after,dict)
changes={p:h for p,h in after.items() if before['source'].get(p)!=h}
programs={p.name:digest(p) for p in (build/'shaders').glob('*.spv')};changed={p:h for p,h in programs.items() if before['programs'].get(p)!=h}
manifest=dict(schemaVersion=1,kind='NativeOptimizationEvidence',sourceBase='9004b9c',status='DiagnosticGpuImprovementFormalConditionsPending',
 scope='Unlit Blend beauty, authored emission attenuation and reflection surface preparation',
 sourceChanges=changes,configuration='Release',buildProvenance=dict(path=str(build/'build-provenance.json'),sha256=digest(build/'build-provenance.json'),scope=record['buildScope']),
 playerSha256=digest(build/'AzurePlayer.exe'),programCount=len(programs),changedPrograms=changed,
 results=dict(path='results.json',sha256=digest(e/'results.json')),archive=dict(path='measurements.zip',sha256=digest(e/'measurements.zip')),
 retainedInputs='Shared mounted project and frozen historical capture; their complete byte inventories are in the evidence archive',
 phaseChecksPassed=True,overallVisualAccepted=False,formalPerformanceAccepted=False,cpuP95BudgetMs=8,gpuP95BudgetMs=16.6)
(e/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print(json.dumps(dict(sourceChanges=list(changes),changedPrograms=len(changed),programs=len(programs))))
