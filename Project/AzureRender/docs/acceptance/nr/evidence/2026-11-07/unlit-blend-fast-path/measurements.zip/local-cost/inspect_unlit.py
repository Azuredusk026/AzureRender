from pathlib import Path
import json,hashlib,struct,sys,traceback
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-035807-unlit-shading-cost-89a05b';a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54/current-gpu-events'
state=json.loads((a/'state.json').read_text());report=dict(status='starting',sourceBase='9004b9c',captureSha256=state['captureSha256'],scope='Existing frozen capture, only shader-byte-matched unlit blend paths qualify as current local controls');cap=None;controller=None
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,controller=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 profile=json.loads((a/'events/profile.json').read_text());selected=sorted((r for r in profile['measurements'] if r['kind']=='draw'),key=lambda r:r['seconds'],reverse=True)[:600]
 products={r['shader']:r for r in json.loads((a/'shader-products.json').read_text())};rows=[]
 report['api']={k:getattr(rd.ReplayController,k).__doc__ for k in ['BuildTargetShader','ReplaceResource','RemoveReplacement','GetTextureData','FetchCounters']}
 for event in selected:
  controller.SetFrameEvent(event['event'],True);vk=controller.GetVulkanPipelineState();pipe=controller.GetPipelineState();push=bytes(vk.pushconsts)
  if len(push)<144:continue
  alpha,cls,features,material=struct.unpack_from('<I',push,4)[0],struct.unpack_from('<I',push,112)[0],struct.unpack_from('<I',push,116)[0],struct.unpack_from('<I',push,124)[0]>>1
  if alpha!=2 or not(features&262144):continue
  sid=str(vk.fragmentShader.resourceId);p=products.get(sid);current=[]
  if p:
   current=[n for n in p['files'] if (root/'build/ninja-msvc-release/shaders'/Path(n).name).is_file() and hashlib.sha256((root/'build/ninja-msvc-release/shaders'/Path(n).name).read_bytes()).hexdigest()==p['sha256']]
  reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
  if 'reflection' not in report:
   report['reflection']=[dict(index=i,name=r.name,binding=r.fixedBindNumber,set=r.fixedBindSetOrSpace,isTexture=r.isTexture) for i,r in enumerate(reflection.readOnlyResources)]
   report['boundReadOnly']=[dict(index=u.access.index,resource=str(u.descriptor.resource),offset=u.descriptor.byteOffset,size=u.descriptor.byteSize) for u in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel)]
   report['reflectionWrite']=[dict(index=i,name=r.name,binding=r.fixedBindNumber,set=r.fixedBindSetOrSpace,isTexture=r.isTexture) for i,r in enumerate(reflection.readWriteResources)]
  indices={i for i,r in enumerate(reflection.readOnlyResources) if r.fixedBindNumber==27}
  used=next((u for u in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel) if u.access.index in indices),None)
  if used is None:
   indices={i for i,r in enumerate(reflection.readWriteResources) if r.fixedBindNumber==27}
   used=next((u for u in pipe.GetReadWriteResources(rd.ShaderStage.Pixel) if u.access.index in indices),None)
  row15=None;binding=None
  if used:
   b=used.descriptor;offset=b.byteOffset+material*352+15*16;data=bytes(controller.GetBufferData(b.resource,offset,16));assert len(data)==16
   row15=list(struct.unpack('<4f',data));binding=dict(resource=str(b.resource),offset=int(b.byteOffset),length=int(b.byteSize),profileStride=352,index=material)
  rows.append(dict(event=event['event'],historicalMs=event['seconds']*1000,shader=sid,alphaMode=alpha,materialClass=cls,features=features,material=material,programMatches=current,profileRow15=row15,profileBinding=binding,specializationIds=list(vk.fragmentShader.specializationIds),specializationDataHex=bytes(vk.fragmentShader.specializationData).hex()))
 report.update(status='inspected',rows=rows,matchedDraws=sum(bool(r['programMatches']) for r in rows),historicalMatchedMs=sum(r['historicalMs'] for r in rows if r['programMatches']))
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if controller:controller.Shutdown()
 if cap:cap.Shutdown()
 (out/'inspect-state.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='inspected' else 1)

