from pathlib import Path
import json,os,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];rows=[]
assert all(r['exitCode']==0 for r in json.loads((out/'build-checks.json').read_text()))
for name,deadline in [('public_checks',1800),('capture',900),('measure_baseline',1000),('measure_candidate',1000)]:
 command=[sys.executable,'-X','utf8',str(out/(name+'.py'))];start=time.monotonic()
 with (out/(name+'-runner.log')).open('wb') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=deadline)
 rows.append(dict(name=name,exitCode=r.returncode,seconds=time.monotonic()-start,command=command))
 (out/'validation-batch.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
 assert r.returncode==0,(out/(name+'-runner.log')).read_text(errors='replace')[-6000:]
