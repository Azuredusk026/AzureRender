from pathlib import Path
import json,os,subprocess,time,sys
out=Path(__file__).resolve().parent;root=out.parents[2];player=root/'build/ninja-msvc-release/AzurePlayer.exe'
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
from run_playable_performance import freeze_products
frozen=inputs(root);products=freeze_products(root,player,player.with_name('AzureRender.exe'))
env=os.environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
cases=['blend','node-opacity','scroll','soft-half','coverage-soft','view-mask']
jobs=[('plain-unlit','test_unlit_surface_gpu.py',[]),
 ('texture-layers','test_unlit_texture_layers_gpu.py',[value for case in cases for value in ['--case',case]]),
 ('emission-attenuation','test_material_overlays_gpu.py',[]),
 ('snapshot-msaa','test_opaque_surface_overlays_gpu.py',['--anti-aliasing','4'])]
rows=[]
for name,script,extra in jobs:
 command=[sys.executable,'-X','utf8',str(root/'tools'/script),'--executable',str(player),'--output',str(out/name),'--expected-validation','disabled',*extra]
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 rows.append(dict(name=name,command=command,exitCode=r.returncode,seconds=time.monotonic()-start))
 (out/'public-checks.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
 assert r.returncode==0,(out/(name+'.log')).read_text(errors='replace')[-4000:]
assert frozen==inputs(root) and all(digest(Path(p))==h for p,h in products.items())
print('One public contract batch passed; inputs and runtime products unchanged',flush=True)
