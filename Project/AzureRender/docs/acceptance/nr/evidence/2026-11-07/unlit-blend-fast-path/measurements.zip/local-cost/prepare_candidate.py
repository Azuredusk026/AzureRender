from pathlib import Path
import json,subprocess,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2]
source=root/'shaders';private=out/'candidate-source';private.mkdir(exist_ok=True)
mesh=(source/'mesh.frag').read_text()
mesh=mesh.replace('#include "unlit_opaque.glsl"','#include "unlit_opaque.glsl"\n#include "blend_early.glsl"')
mesh=mesh.replace('if(azureWritePlainUnlitBeauty(baseColor,geometricNormal,platformMask))return;',
    'if(azureWritePlainUnlitBeauty(baseColor,geometricNormal,platformMask))return;\n#if !defined(AZURE_OPAQUE_SNAPSHOT)\n    if(azureWriteUnlitBlendBeauty(baseColor,geometricNormal,platformMask,vec3(0),1.0))return;\n#endif')
needle='    float metallic = clamp(packedMaterial.b, 0.0, 1.0);'
mesh=mesh.replace(needle,'#if defined(AZURE_OPAQUE_SNAPSHOT)\n    if(azureWriteUnlitBlendBeauty(baseColor,geometricNormal,platformMask,shadedNormal,roughness))return;\n#endif\n'+needle)
(private/'mesh.frag').write_text(mesh)
(private/'blend_early.glsl').write_bytes((out/'blend_early.glsl').read_bytes())
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text())
reports=[]
for name in ['mesh_object_bindless_clipmap_field.frag.spv','character_snapshot_object_bindless_clipmap_field.frag.spv']:
 program=next(p for p in manifest['programs'] if p['output']==name)
 command=[manifest['compiler'],*[f'-D{d}' for d in program['defines']],f'-I{private}',f'-I{source}',str(private/'mesh.frag'),'-o',str(out/name)]
 r=subprocess.run(command,capture_output=True,text=True)
 reports.append(dict(command=command,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr))
 (out/'candidate-build.json').write_text(json.dumps(reports,indent=2))
 assert r.returncode==0,r.stderr
 print(name,hashlib.sha256((out/name).read_bytes()).hexdigest())
