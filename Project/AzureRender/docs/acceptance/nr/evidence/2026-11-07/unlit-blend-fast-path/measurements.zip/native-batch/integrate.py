from pathlib import Path
import hashlib,json,shutil,subprocess,sys
out=Path(__file__).resolve().parent;root=out.parents[2]
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
source=root/'build/runs/20261107-035807-unlit-shading-cost-89a05b'
assert json.loads((source/'compare-state.json').read_text())['allTargetsEqual']
baseline=out/'baseline';baseline.mkdir();(baseline/'shaders').mkdir()
products=[root/'build/ninja-msvc-release/AzurePlayer.exe',*sorted((root/'build/ninja-msvc-release/shaders').glob('*.spv'))]
assert len(products)==664
before=inputs(root)
for p in products:shutil.copy2(p,baseline/('shaders/'+p.name if p.suffix=='.spv' else p.name))
record=dict(sourceBase='9004b9c',source=before,playerSha256=digest(products[0]),programs={p.name:digest(p) for p in products[1:]})
(out/'baseline-products.json').write_text(json.dumps(record,indent=2))
mesh=(source/'candidate-source/mesh.frag').read_text().replace('#include "blend_early.glsl"','#include "unlit_blend.glsl"')
(root/'shaders/mesh.frag').write_text(mesh)
(root/'shaders/unlit_blend.glsl').write_bytes((source/'candidate-source/blend_early.glsl').read_bytes())
cmake=root/'CMakeLists.txt';text=cmake.read_text()
needle='"${SHADER_SOURCE_DIR}/unlit_surface_sample.glsl" "${SHADER_SOURCE_DIR}/unlit_opaque.glsl"'
assert text.count(needle)==1
cmake.write_text(text.replace(needle,needle+' "${SHADER_SOURCE_DIR}/unlit_blend.glsl"'))
print('Integrated byte-controlled private shader; baseline runtime and 663 programs isolated')
