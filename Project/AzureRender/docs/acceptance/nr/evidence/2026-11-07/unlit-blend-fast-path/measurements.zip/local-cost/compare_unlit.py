from pathlib import Path
import hashlib,json,sys,traceback,time
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-035807-unlit-shading-cost-89a05b'
a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54/current-gpu-events'
state=json.loads((a/'state.json').read_text());scope=json.loads((out/'inspect-state.json').read_text())
report=dict(status='starting',scope='Frozen replay local control; native acceptance remains separate',captureSha256=state['captureSha256']);cap=None;c=None;replacements=[]
def save(): (out/'compare-state.json').write_text(json.dumps(report,indent=2))
def durations():
 return {int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
try:
 save();cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 report['status']='loaded';save();compiled={}
 for event in [26298,17185]:
  c.SetFrameEvent(event,True);pipe=c.GetPipelineState();original=pipe.GetShader(rd.ShaderStage.Pixel)
  row=next(r for r in scope['rows'] if r['event']==event);name=row['programMatches'][0]
  program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/name).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
  assert program!=rd.ResourceId.Null(),errors
  compiled[str(original)]=(original,program)
  replacements.append(dict(original=str(original),replacement=str(program),file=name,errors=errors))
 report['replacements']=replacements;save()
 controls={};events=[17193,26298,26452]
 for event in events:
  c.SetFrameEvent(event,True)
  for index,target in enumerate(c.GetPipelineState().GetOutputTargets()):
   if target.resource==rd.ResourceId.Null():continue
   controls[(event,index)]=(target.resource,bytes(c.GetTextureData(target.resource,rd.Subresource())))
 report['status']='baseline-read';report['timings']=[];save()
 report['timings'].append(dict(mode='baseline',milliseconds=durations()));save()
 for original,program in compiled.values():c.ReplaceResource(original,program)
 comparisons=[]
 for (event,index),(resource,data) in controls.items():
  c.SetFrameEvent(event,True);value=bytes(c.GetTextureData(resource,rd.Subresource()))
  same=value==data
  first=[]
  if not same:
   for i,(x,y) in enumerate(zip(data,value)):
    if x!=y:first.append(dict(offset=i,baseline=x,candidate=y))
    if len(first)==16:break
  comparisons.append(dict(event=event,target=index,bytes=len(data),candidateBytes=len(value),equal=same,baselineSha256=hashlib.sha256(data).hexdigest(),candidateSha256=hashlib.sha256(value).hexdigest(),firstDifferences=first))
 report['comparisons']=comparisons;report['status']='candidate-read';save()
 for unused in range(2):report['timings'].append(dict(mode='candidate',milliseconds=durations()));save()
 for original,unused in compiled.values():c.RemoveReplacement(original)
 report['timings'].append(dict(mode='baseline',milliseconds=durations()))
 matched={r['event'] for r in scope['rows'] if r['programMatches']}
 report['summary']=[dict(mode=r['mode'],allEventMs=sum(r['milliseconds'].values()),matchedEventMs=sum(ms for event,ms in r['milliseconds'].items() if event in matched)) for r in report['timings']]
 report['status']='compared';report['allTargetsEqual']=all(r['equal'] for r in comparisons);save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='compared' else 1)
