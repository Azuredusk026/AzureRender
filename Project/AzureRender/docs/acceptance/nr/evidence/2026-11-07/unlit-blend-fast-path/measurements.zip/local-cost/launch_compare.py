from pathlib import Path
import hashlib,json,os,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2]
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
from run_playable_performance import freeze_products
a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54/current-gpu-events';state=json.loads((a/'state.json').read_text());capture=Path(state['capture'])
def stream_hash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while block:=f.read(4*1024*1024):h.update(block)
 return h.hexdigest()
assert stream_hash(capture)==state['captureSha256']
source=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'compare_unlit.py')]
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'compare-driver.log').open('wb') as log:r=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=300)
report=json.loads((out/'compare-state.json').read_text());assert r.returncode==0 and report['status']=='compared',report
assert inputs(root)==source and all(digest(Path(p))==v for p,v in products.items())
assert stream_hash(capture)==state['captureSha256']
(out/'compare-results.json').write_text(json.dumps(dict(status='compared',seconds=time.monotonic()-start,command=command,productionUnchanged=True,captureBytesUnchanged=True,sourceInputs=source,products=products),indent=2))
print(json.dumps({k:report[k] for k in ['status','summary','allTargetsEqual']}),flush=True)

