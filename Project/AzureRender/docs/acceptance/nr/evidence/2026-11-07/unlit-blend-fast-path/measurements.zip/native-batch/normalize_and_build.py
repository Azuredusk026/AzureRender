from pathlib import Path
import json,os,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'));from build_provenance import digest,verify
old=json.loads((build/'build-provenance.json').read_text());verify(root,old)
path=root/'shaders/unlit_blend.glsl';before=digest(path);path.write_bytes(path.read_bytes().rstrip(b'\r\n')+b'\n')
plan=root/'docs/plans/2026-11-07-unlit-shading-cost.md';plan.write_bytes(plan.read_bytes().rstrip(b'\r\n')+b'\n')
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
command=['cmd','/d','/c',str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config','Release','--runtime-only']
start=time.monotonic()
with (out/'normalization-build.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
assert r.returncode==0,(out/'normalization-build.log').read_text(errors='replace')[-3000:]
assert all(digest(Path(p))==h for p,h in old['products'].items()),'Whitespace normalization must preserve every compiled product'
report=dict(kind='terminal-blank-line-normalization',path='shaders/unlit_blend.glsl',beforeSha256=before,afterSha256=digest(path),command=command,exitCode=r.returncode,seconds=time.monotonic()-start,allPriorProductsByteIdentical=True,verifiedProducts=old['products'],priorBuildScope=old['buildScope'],testAndRuntimeEvidenceReusedByExactProductBytes=True)
(out/'source-normalization.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:report[k] for k in ['kind','exitCode','seconds','allPriorProductsByteIdentical']}),flush=True)
