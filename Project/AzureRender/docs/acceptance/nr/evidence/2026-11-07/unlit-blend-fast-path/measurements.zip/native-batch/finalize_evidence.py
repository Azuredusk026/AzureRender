from pathlib import Path
import hashlib,json,statistics,struct,subprocess,sys,zipfile
out=Path(__file__).resolve().parent;root=out.parents[2];cost=root/'build/runs/20261107-035807-unlit-shading-cost-89a05b'
evidence=root/'docs/acceptance/nr/evidence/2026-11-07/unlit-blend-fast-path';evidence.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'tools'));from build_provenance import digest,verify
verify(root,json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text()))
def text_sha(p):
 data=p.read_bytes();pe=struct.unpack_from('<I',data,60)[0];n=struct.unpack_from('<H',data,pe+6)[0];optional=struct.unpack_from('<H',data,pe+20)[0]
 for i in range(n):
  at=pe+24+optional+i*40
  if data[at:at+8].rstrip(b'\0')==b'.text':
   size,offset=struct.unpack_from('<II',data,at+16);return hashlib.sha256(data[offset:offset+size]).hexdigest()
 raise ValueError('Missing PE code section')
pair={role:json.loads((out/('performance-'+role)/'results.json').read_text()) for role in ['baseline','candidate']}
image=json.loads((out/'image/results.json').read_text());assert image['status']=='passed'
replay=json.loads((cost/'compare-state.json').read_text());assert replay['allTargetsEqual']
rows=replay['summary'];replay_means={role:{key:statistics.mean(r[key] for r in rows if r['mode']==role) for key in ['allEventMs','matchedEventMs']} for role in ['baseline','candidate']}
env={}
for role in pair:
 v=json.loads((out/('performance-'+role)/'environment.json').read_text());samples=v['runObservations']
 env[role]={key:dict(min=min(r[key] for r in samples),median=statistics.median(r[key] for r in samples),max=max(r[key] for r in samples)) for key in ['temperature','powerLimitWatts','graphicsClockMHz','memoryClockMHz']}
baseline_text=text_sha(out/'baseline/AzurePlayer.exe');candidate_text=text_sha(root/'build/ninja-msvc-release/AzurePlayer.exe');assert baseline_text==candidate_text
gpu=pair['baseline']['gpu']['frameMs'];candidate=pair['candidate']['gpu']['frameMs']
summary=dict(schemaVersion=1,status='adopted-diagnostic-gpu-improvement',sourceBase='9004b9c',implementation=['CMakeLists.txt','shaders/mesh.frag','shaders/unlit_blend.glsl'],
 replay=dict(captureSha256=replay['captureSha256'],means=replay_means,savedMatchedMs=replay_means['baseline']['matchedEventMs']-replay_means['candidate']['matchedEventMs'],allEightTargetsByteIdentical=True,scope='Shader-byte-matched historical replay; same draw inputs; event durations, separate from native acceptance'),
 native=dict(baseline=pair['baseline'],candidate=pair['candidate'],savedGpuMeanMs=gpu['mean']-candidate['mean'],savedGpuP95Ms=gpu['p95']-candidate['p95'],gpuMeanReduction=1-candidate['mean']/gpu['mean'],
  cpuCodeByteIdentical=True,cpuTextSha256=baseline_text,cpuBenefitClaimed=False,environmentDistribution=env,formalAcceptance=False),
 image=image,buildChecks=json.loads((out/'build-checks.json').read_text()),publicChecks=json.loads((out/'public-checks.json').read_text()),
 required=dict(cpuP95Ms=8,gpuP95Ms=16.6,samples=1800,stablePowerWatts=80,overallVisual='failed-user-review'),
 sourceObservation=json.loads((out/'source-observation.json').read_text()),
 limitations=['Power stability and complete frame budgets remain failed.','Short native rounds are diagnostic; current visual acceptance remains unpassed.','Historical replay total is not the current native GPU frame duration.'],
 references=['https://learn.microsoft.com/en-us/windows/win32/direct3dhlsl/dx-graphics-hlsl-optimize'])
summary['finalSourceNormalization']=json.loads((out/'source-normalization.json').read_text())
archive=evidence/'measurements.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for label,folder in [('local-cost',cost),('native-batch',out)]:
  for p in sorted(folder.rglob('*')):
   if not p.is_file():continue
   rel=p.relative_to(folder)
   if any(v in rel.parts for v in ['baseline','__pycache__','.azure','shaders']):continue
   if p.suffix.lower() not in ['.py','.json','.log','.xml','.glsl','.frag','.gltf','.azureproject','.azurelevel','.azmeta']:continue
   z.write(p,str(Path(label)/rel))
summary['archive']=dict(file=archive.name,bytes=archive.stat().st_size,sha256=digest(archive))
(evidence/'results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(dict(status=summary['status'],gpuMeanBefore=gpu['mean'],gpuMeanAfter=candidate['mean'],gpuP95Before=gpu['p95'],gpuP95After=candidate['p95'],savedGpuMeanMs=summary['native']['savedGpuMeanMs'],archive=summary['archive']),ensure_ascii=False),flush=True)
