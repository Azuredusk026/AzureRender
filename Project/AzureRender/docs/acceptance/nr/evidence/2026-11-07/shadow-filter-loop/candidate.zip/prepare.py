from pathlib import Path
import json,subprocess,sys,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from artifact_budget import check
assert check(root/'build',run=out,planned=24*1024**2,diagnostic=True)['allowed']
s=(root/'shaders/mesh.frag').read_text()
old='vec4 depths=shadowTexelQuad(mainShadowDepth,sharedDepthSampler,base+ivec2(x,y),lo,hi)'
new='vec4 depths=interior?textureGather(AZ_TEX_SHADOW,(vec2(base+ivec2(x,y))+1.0)/vec2(extent)).wzxy:shadowTexelQuad(mainShadowDepth,sharedDepthSampler,base+ivec2(x,y),lo,hi)'
assert s.count(old)==2
# Parentheses retain the original subtraction of the receiver plane.
s=s.replace(old,new.replace('=interior?', '=(interior?')+')')
needle='for(int y=-bound;y<=bound;y+=2)for(int x=-bound;x<=bound;x+=2){';assert s.count(needle)==1
s=s.replace(needle,needle+'''
        vec2 offset=vec2(x,y)-fraction;
        vec2 nearest=max(abs(offset+vec2(.5))-vec2(.5),vec2(0));
        float outer=radius+.5;
        if(dot(nearest,nearest)>outer*outer+.001)continue;
''')
start=s.index('        vec4 planeDepths=',s.index(needle));end=s.index('\n',start);line=s[start:end];s=s[:start]+s[end:];marker='        if(weight<=0)continue;';assert s.count(marker)==1;s=s.replace(marker,marker+'\n'+line)
(out/'mesh.frag').write_text(s)
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());programs={p['output']:p for p in manifest['programs']};names=[r['file'] for r in json.loads((root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/candidate-build.json').read_text())];rows=[]
for name in names:
 p=programs[name];command=[manifest['compiler'],*[f'-D{d}' for d in p['defines']],f'-I{out}',f'-I{root/"shaders"}',str(out/'mesh.frag'),'-o',str(out/name)];r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr
 v=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(out/name)],capture_output=True,text=True);assert v.returncode==0,v.stderr
 rows.append(dict(file=name,command=command,baselineSha256=hashlib.sha256((root/'build/ninja-msvc-release/shaders'/name).read_bytes()).hexdigest(),candidateSha256=hashlib.sha256((out/name).read_bytes()).hexdigest()))
(out/'candidate-build.json').write_text(json.dumps(rows,indent=2))
template=root/'build/runs/20261107-135742-coarse-shadow-range-e77123';compare=(template/'compare.py').read_text().replace(template.name,out.name);a=compare.index(' def fields(o):');b=compare.index(' selected=[]',a);compare=compare[:a]+compare[b:];compare=compare.replace('Coarse conservative shadow ranges in the existing bounds allocation; exact filtering retained.','Exact interior gathers, conservative zero-quad rejection and delayed receiver plane work; original bounds retained.');(out/'compare.py').write_text(compare);(out/'run_compare.py').write_text((template/'run_compare.py').read_text());print('Validated eleven isolated filter-loop programs')
