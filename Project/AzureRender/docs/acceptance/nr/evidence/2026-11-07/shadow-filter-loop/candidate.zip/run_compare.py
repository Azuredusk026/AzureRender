from pathlib import Path
import subprocess,sys,json,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from artifact_budget import check
from gpu_environment import wait_and_record,RunEnvironmentMonitor,environment_errors
assert check(root/'build',run=out,planned=16*1024**2,diagnostic=True)['allowed']
environment=wait_and_record(out/'environment.json',timeout=60)
source=inputs(root);products={str(p):digest(p) for p in [root/'build/ninja-msvc-release/AzurePlayer.exe',*sorted((root/'build/ninja-msvc-release/shaders').glob('*.spv'))]};si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with RunEnvironmentMonitor(environment,path=out/'environment.json'):
 with (out/'driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'compare.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=240)
assert inputs(root)==source and all(digest(Path(path))==value for path,value in products.items())
report=json.loads((out/'compare-state.json').read_text());assert p.returncode==0 and report['status']=='compared',report
errors=environment_errors(environment);summary=dict(status=report['status'],seconds=time.monotonic()-start,allTargetsEqual=report['allTargetsEqual'],summary=report['summary'],environmentErrors=errors,sourceAndProductsUnchanged=True,replayProcessExitCode=p.returncode);(out/'result.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
