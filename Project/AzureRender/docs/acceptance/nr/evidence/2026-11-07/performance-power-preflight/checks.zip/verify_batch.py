from pathlib import Path
import subprocess,json,os,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'))
from gpu_environment import power_snapshot,snapshot,wait_and_record
from build_provenance import digest
from artifact_budget import check
assert check(root/'build',run=out,planned=8*1024**2,diagnostic=True)['allowed']
before={str(p):digest(p) for config in ['release','debug'] for p in [root/f'build/ninja-msvc-{config}/AzurePlayer.exe',root/f'build/ninja-msvc-{config}/AzureRender.exe',*sorted((root/f'build/ninja-msvc-{config}/shaders').glob('*.spv'))]}
power=power_snapshot();device=snapshot();result=dict(status='checking',power=power,device=device)
start=time.monotonic()
if power['acLineStatus']!=1:
 try:wait_and_record(out/'live-preflight.json',read=lambda:device)
 except RuntimeError as error:result.update(livePreflight='rejected-before-workload',reason=str(error),preflightSeconds=time.monotonic()-start)
 else:raise AssertionError('Battery preflight accepted')
env=dict(os.environ);env['PATH']='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin;D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja;'+env['PATH'];env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
rows=[]
for config in ['Release','Debug']:
 command=[str(root/'tools/msvc_env.bat'),str(root/'build/reinstall-environment/venv/Scripts/python.exe'),'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(root/('build/ninja-msvc-'+config.lower())),'--config',config,'--runtime-only']
 start=time.monotonic()
 with (out/(config.lower()+'-provenance.log')).open('wb') as log:p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 rows.append(dict(config=config,exitCode=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0
assert all(digest(Path(p))==value for p,value in before.items())
result.update(status='checked',builds=rows,allRuntimeAnd663ProgramsByteIdentical=True,gpuWorkloadsStarted=False,tests=dict(environment=23,performanceBudget=12));(out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
