from pathlib import Path
import json,zipfile,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];e=root/'docs/acceptance/nr/evidence/2026-11-07/performance-power-preflight';e.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(e/'checks.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.iterdir():
  if p.is_file():z.write(p,p.name)
result=json.loads((out/'results.json').read_text());result['device'].pop('rawXml');result['sourceBase']='84b2897';p=e/'checks.zip';result['archive']=dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest());(e/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(status=result['status'],power=result['power'],tests=result['tests'])))
