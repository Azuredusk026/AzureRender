
#include "packed-position-prototype.hpp"
#include "scene/TransformMath.hpp"
#include <chrono>
#include <iostream>
#include <cstring>
int main(int argc,char** argv){
 if(argc!=2)return 2;
 auto asset=loadGltfAsset(argv[1]);PreparedAssetAnimations prepared(asset);
 const auto model=azurerender::scene::composeTrs({1.2F,-.5F,.8F},{17,-11,3},{.95F,1.1F,.9F});
 std::vector<azurerender::internal::Vector3>a(asset.vertices.size()),b(a.size());double oldMs=0,newMs=0;unsigned rounds=0;
 for(float time:{0.F,.5F,1.5F}){
  auto pose=sampleAnimationPose(asset,0,time,true,&prepared);PackedPositions packed(asset,&pose,{0,0},model);
  for(unsigned round=0;round<8;++round){
   const auto run=[&](bool candidate){const auto start=std::chrono::steady_clock::now();
    for(std::size_t i=0;i<a.size();++i){if(candidate)b[i]=packed(i);else a[i]=azurerender::internal::transformPosition(model,azurerender::deformedVertexPosition(asset,i,&pose,{0,0}));}
    return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();};
   if(round&1){oldMs+=run(false);newMs+=run(true);}else{newMs+=run(true);oldMs+=run(false);}
   if(std::memcmp(a.data(),b.data(),a.size()*sizeof(a[0]))){std::cerr<<"Different vertex bytes\n";return 1;}++rounds;
  }
 }
 std::cout<<"{\"vertices\":"<<a.size()<<",\"rounds\":"<<rounds<<",\"baselineMs\":"<<oldMs/rounds<<",\"candidateMs\":"<<newMs/rounds<<",\"reduction\":"<<1-newMs/oldMs<<",\"identical\":true}\n";
}
