#include "render/StaticTransparentIndexCache.hpp"
#include <iostream>
#include <limits>
#include <stdexcept>

using namespace azurerender;
void check(bool value,const char* message){if(!value)throw std::runtime_error(message);}
int main()try{
    int geometry=0,otherGeometry=0,pose=0,otherPose=0;
    StaticTransparentIndexKey key;key.geometry=&geometry;key.pose=&pose;
    key.model[0]=key.model[5]=key.model[10]=key.model[15]=1;key.cameraForward={0,0,-1};
    const std::vector<std::uint32_t> indices{7,3,9,4,8,2};
    StaticTransparentIndexCache cache(32,2);
    cache.beginFrame(2);check(!cache.find(0,key,indices.size()),"Empty entries must miss");
    check(cache.remember(0,key,indices.data(),indices.size()),"A fitting immutable value must be retained");cache.endFrame();
    cache.beginFrame(2);const auto* hit=cache.find(0,key,indices.size());
    check(hit&&*hit==indices,"A new frame must retrieve identical ordered indices");
    check(cache.statistics().hits==1&&cache.statistics().reusedIndices==6,"Reuse counters must measure actual indices");
    auto changed=key;
    for(unsigned condition=0;condition<6;++condition){
        changed=key;
        if(condition==0)changed.geometry=&otherGeometry;
        if(condition==1)changed.pose=&otherPose;
        if(condition==2)changed.model[12]=1;
        if(condition==3)changed.cameraPosition[0]=1;
        if(condition==4)changed.cameraForward[0]=1;
        if(condition==5)changed.morph[1]=1;
        check(!cache.find(0,changed,indices.size()),"Every sorted-output dependency must invalidate independently");
    }
    changed=key;changed.morph[0]=-0.F;check(!cache.find(0,changed,6),"Negative zero must retain exact input semantics");
    check(!cache.find(0,key,3),"Changed index count must invalidate a value");
    check(!cache.remember(1,key,indices.data(),indices.size()),"Combined cached capacity must obey the byte quota");
    check(cache.bytes()<=32&&cache.statistics().rejectedStores==1,"Rejected values must retain a bounded cache");cache.endFrame();
    cache.beginFrame(1);check(cache.find(0,key,6)!=nullptr,"Shrinking the instance list retains surviving values");
    const auto* aliased=cache.find(0,key,6);
    changed=key;changed.cameraPosition[0]=2;
    check(cache.remember(0,changed,aliased->data()+1,5),"Overlapping owned input must be copied safely");
    const auto* shifted=cache.find(0,changed,5);
    check(shifted&&*shifted==std::vector<std::uint32_t>({3,9,4,8,2}),"Value replacement must preserve the full requested order");cache.endFrame();
    cache.beginFrame(1);cache.endFrame();check(cache.bytes()==0,"Unused and invisible entries must release retained storage");
    cache.beginFrame(1);changed=key;changed.model[0]=std::numeric_limits<float>::infinity();
    check(!cache.remember(0,changed,indices.data(),6),"Nonfinite transforms must use full preparation");
    changed=key;changed.cameraPosition[0]=std::numeric_limits<float>::quiet_NaN();
    check(!cache.remember(0,changed,indices.data(),6),"NaN camera input must use full preparation");
    changed=key;changed.pose=nullptr;check(!cache.remember(0,changed,indices.data(),6),"Missing immutable identity must remain uncached");
    cache.beginFrame(3);check(!cache.enabled()&&!cache.remember(0,key,indices.data(),6),"Oversized instance lists must use the bounded fallback");
    StaticTransparentIndexCache disabled(0);disabled.beginFrame(1);check(!disabled.enabled(),"Zero capacity disables the cache");
    StaticTransparentIndexCache bounded(1024,std::numeric_limits<std::size_t>::max());bounded.beginFrame(4097);
    check(!bounded.enabled(),"The absolute metadata entry ceiling must remain bounded");
    cache.beginFrame(1);check(cache.remember(0,key,indices.data(),6),"Fallback frames must permit subsequent ordinary use");
    cache.clear();check(!cache.enabled()&&cache.bytes()==0,"Unload must retire every cached value");
    std::cout<<"Exact dependencies, replacement, aliasing, visibility and quotas passed\n";
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
