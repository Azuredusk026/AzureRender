from pathlib import Path
import hashlib,json,shutil,struct,subprocess,sys,time
out=Path(__file__).resolve().parent
root=out.parents[2];repo=root.parents[1]
owned=['CMakeLists.txt','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','src/scene/SceneTransformCache.hpp','src/render/StaticTransparentIndexCache.hpp','tests/SceneTransformCacheTests.cpp','tests/StaticTransparentIndexCacheTests.cpp','tests/TransparentPreparationRecordingTests.cpp']
new=owned[3:]
snap=out/'candidate-source';snap.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def code(p):
 b=p.read_bytes();pe=struct.unpack_from('<I',b,0x3c)[0];n=struct.unpack_from('<H',b,pe+6)[0];opt=struct.unpack_from('<H',b,pe+20)[0]
 for i in range(n):
  s=pe+24+opt+40*i
  if b[s:s+8].rstrip(b'\0')==b'.text':
   count,offset=struct.unpack_from('<II',b,s+16);return hashlib.sha256(b[offset:offset+count]).hexdigest()
 raise AssertionError('Missing code section')
record={'status':'isolated-not-adopted','reason':'One paired native CPU window did not improve; no formal performance claim','candidateSourceHashes':{},'sourceBase':'95f0f38'}
for name in owned:
 p=root/name;target=snap/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);record['candidateSourceHashes'][name]=sha(p)
player=root/'build/ninja-msvc-release/AzurePlayer.exe';shutil.copy2(player,out/'isolated-candidate.exe');record['candidatePlayerSha256']=sha(player)
(out/'candidate-record.json').write_text(json.dumps(record,indent=2))
for name in owned[:3]:
 data=subprocess.check_output(['git','show','95f0f38:Project/AzureRender/'+name],cwd=repo);(root/name).write_bytes(data)
for name in new:
 p=(root/name).resolve();assert p.is_relative_to(root.resolve()) and p.is_file()
 assert subprocess.run(['git','ls-files','--error-unmatch','Project/AzureRender/'+name],cwd=repo,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
 assert sha(p)==sha(snap/name);p.unlink()
cmd=['cmd','/d','/c',str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(root/'build/ninja-msvc-release'),'--config','Release','--runtime-only']
start=time.monotonic()
with (out/'restore-build.log').open('wb') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=900)
assert r.returncode==0,r.returncode
baseline=json.loads((out/'baseline-products.json').read_text())
assert {p.name:sha(p) for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv')}==baseline['programs']
assert code(player)==code(out/'baseline/AzurePlayer.exe')
verify=cmd[:cmd.index('build')]+['verify','--source',str(root),'--build-dir',str(root/'build/ninja-msvc-release'),'--config','Release']
with (out/'restore-provenance.log').open('wb') as log:v=subprocess.run(verify,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=90)
assert v.returncode==0
record.update(restoredSourceByteIdentical=True,restoredProgramsByteIdentical=len(baseline['programs']),restoredPlayerCodeSectionIdentical=True,restoredPlayerSha256=sha(player),restoredCodeSectionSha256=code(player),buildSeconds=time.monotonic()-start,buildCommand=cmd,provenanceVerified=True)
(out/'restoration.json').write_text(json.dumps(record,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='candidateSourceHashes'},indent=2))
