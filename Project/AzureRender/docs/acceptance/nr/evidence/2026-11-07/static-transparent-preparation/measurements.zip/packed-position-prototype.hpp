
#pragma once
#include "assets/AssetDeformation.hpp"
#include <emmintrin.h>
class PackedPositions {
 const LoadedAsset& asset_;const AssetPose* pose_;std::array<float,2> morph_;azurerender::internal::Matrix4 model_;bool packed_=true;
 static __m128 xyz(const float* value){return _mm_and_ps(_mm_loadu_ps(value),_mm_castsi128_ps(_mm_set_epi32(0,-1,-1,-1)));}
 static __m128 transform(const std::array<float,16>& m,__m128 p){
  auto x=_mm_shuffle_ps(p,p,_MM_SHUFFLE(0,0,0,0)),y=_mm_shuffle_ps(p,p,_MM_SHUFFLE(1,1,1,1)),z=_mm_shuffle_ps(p,p,_MM_SHUFFLE(2,2,2,2));
  return _mm_add_ps(_mm_add_ps(_mm_add_ps(_mm_mul_ps(xyz(m.data()),x),_mm_mul_ps(xyz(m.data()+4),y)),_mm_mul_ps(xyz(m.data()+8),z)),xyz(m.data()+12));
 }
 static azurerender::internal::Vector3 values(__m128 v){alignas(16)float a[4];_mm_store_ps(a,v);return {a[0],a[1],a[2]};}
 static bool finite(const azurerender::internal::Vector3& v){return std::isfinite(v[0])&&std::isfinite(v[1])&&std::isfinite(v[2]);}
public:
 PackedPositions(const LoadedAsset& asset,const AssetPose* pose,std::array<float,2> morph,const azurerender::internal::Matrix4& model):asset_(asset),pose_(pose),morph_(morph),model_(model){
  for(float f:model_)packed_=packed_&&std::isfinite(f);
  if(pose_)for(const auto& matrix:pose_->jointMatrices)for(float f:matrix)packed_=packed_&&std::isfinite(f);
 }
 azurerender::internal::Vector3 operator()(std::size_t index)const{
  using namespace azurerender;using namespace azurerender::internal;
  if(!packed_)return transformPosition(model_,deformedVertexPosition(asset_,index,pose_,morph_));
  const auto position=morphedVertexAttribute(asset_,index,pose_,morph_,0);const auto& vertex=asset_.vertices.at(index);
  bool supported=finite(position);for(float w:vertex.weights)supported=supported&&std::isfinite(w);
  if(!supported)return transformPosition(model_,deformedVertexPosition(asset_,index,pose_,morph_));
  __m128 p=_mm_set_ps(0,position[2],position[1],position[0]);
  if(pose_&&!pose_->jointMatrices.empty()){
   __m128 sum=_mm_setzero_ps();
   for(unsigned joint=0;joint<4;++joint)if(vertex.weights[joint]!=0){auto v=transform(pose_->jointMatrices.at(vertex.joints[joint]),p);sum=_mm_add_ps(sum,_mm_mul_ps(v,_mm_set1_ps(vertex.weights[joint])));}
   p=sum;
  }
  const auto skinned=values(p);if(!finite(skinned))return transformPosition(model_,skinned);
  return values(transform(model_,p));
 }
};
