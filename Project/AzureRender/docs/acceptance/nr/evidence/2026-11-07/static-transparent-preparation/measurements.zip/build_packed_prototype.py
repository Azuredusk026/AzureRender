from pathlib import Path
import subprocess,json,os
out=Path(__file__).resolve().parent;root=out.parents[2]
old=root/'build/runs/20261106-220323-autonomous-cleanup-performance-70496b/cpu-phase-probe';v=json.loads((old/'build.json').read_text());args=v['command']
args=[a.replace(str(old/'AzureRenderFrame.obj'),str(out/'packed-position-benchmark.obj')).replace(str(old/'AzureRenderFrame.pdb'),str(out/'packed-position-benchmark.pdb')).replace(str(old/'AzureRenderFrame.cpp'),str(out/'packed-position-benchmark.cpp')) for a in args if a!='/showIncludes']
with (out/'packed-compile.log').open('wb') as log:r=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0,(out/'packed-compile.log').read_text(errors='replace')[-4000:]
s=(old/'link.rsp').read_text().replace(str(old/'AzureRenderFrame.obj'),str(out/'packed-position-benchmark.obj')).replace('CMakeFiles\\AzurePlayer.dir\\src\\player\\main.cpp.obj','').replace(str(old/'AzurePlayer'),str(out/'packed-position-benchmark'))
(out/'packed-position-benchmark.rsp').write_text(s)
with (out/'packed-link.log').open('wb') as log:r=subprocess.run([v['link'][0],'@'+str(out/'packed-position-benchmark.rsp')],cwd=root/'build/ninja-msvc-release',stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0,(out/'packed-link.log').read_text(errors='replace')[-4000:]
env=os.environ.copy();env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH']
with (out/'packed-output.log').open('wb') as log:r=subprocess.run([str(out/'packed-position-benchmark.exe'),str(root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/content-character/hero-idle-opaque-overlays.glb')],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(out/'packed-output.log').read_text(errors='replace')[-2000:]
print((out/'packed-output.log').read_text(errors='replace')[-2500:])
