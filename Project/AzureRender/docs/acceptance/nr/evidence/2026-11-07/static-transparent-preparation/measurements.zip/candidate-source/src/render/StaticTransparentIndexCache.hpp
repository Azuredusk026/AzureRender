#pragma once

#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <new>
#include <vector>

namespace azurerender {

// Geometry and pose are immutable identities within one renderer load epoch.
// Addresses are compared only; the renderer owns and retires those objects.
struct StaticTransparentIndexKey {
    const void* geometry=nullptr;
    const void* pose=nullptr;
    std::array<float,16> model{};
    std::array<float,3> cameraPosition{},cameraForward{};
    std::array<float,2> morph{};

    [[nodiscard]] bool finite() const noexcept {
        if(!geometry||!pose)return false;
        for(const auto& values:{cameraPosition,cameraForward})for(const auto value:values)if(!std::isfinite(value))return false;
        for(const auto value:model)if(!std::isfinite(value))return false;
        for(const auto value:morph)if(!std::isfinite(value))return false;
        return true;
    }
    [[nodiscard]] bool same(const StaticTransparentIndexKey& other) const noexcept {
        return geometry==other.geometry&&pose==other.pose
            &&std::memcmp(model.data(),other.model.data(),model.size()*sizeof(float))==0
            &&std::memcmp(cameraPosition.data(),other.cameraPosition.data(),cameraPosition.size()*sizeof(float))==0
            &&std::memcmp(cameraForward.data(),other.cameraForward.data(),cameraForward.size()*sizeof(float))==0
            &&std::memcmp(morph.data(),other.morph.data(),morph.size()*sizeof(float))==0;
    }
};

// Best-effort CPU values. GPU uploads retain the caller's frame-slot fence
// contract. Capacity and allocation failures leave the full preparation usable.
class StaticTransparentIndexCache final {
public:
    struct Statistics {std::size_t hits=0,misses=0,reusedIndices=0,storedIndices=0,rejectedStores=0;};
    explicit StaticTransparentIndexCache(std::size_t byteBudget=16U*1024U*1024U,std::size_t entryLimit=4096)
        : byteBudget_(byteBudget),entryLimit_(entryLimit<=4096?entryLimit:4096) {}

    void beginFrame(std::size_t entries) noexcept {
        stats_={};
        if(byteBudget_==0||entries>entryLimit_){clear();return;}
        try{entries_.resize(entries);}catch(const std::bad_alloc&){clear();return;}
        usedBytes_=0;enabled_=true;
        for(auto& entry:entries_){entry.seen=false;usedBytes_+=entry.indices.capacity()*sizeof(std::uint32_t);}
    }
    [[nodiscard]] const std::vector<std::uint32_t>* find(
        std::size_t slot,const StaticTransparentIndexKey& key,std::size_t count) noexcept {
        if(!enabled_||slot>=entries_.size())return nullptr;
        auto& entry=entries_[slot];
        if(key.finite()&&entry.valid&&entry.indices.size()==count&&entry.key.same(key)) {
            entry.seen=true;++stats_.hits;stats_.reusedIndices+=count;return &entry.indices;
        }
        ++stats_.misses;return nullptr;
    }
    bool remember(std::size_t slot,const StaticTransparentIndexKey& key,
        const std::uint32_t* values,std::size_t count) noexcept {
        if(!enabled_||slot>=entries_.size()||!values||!count||!key.finite())return false;
        auto& entry=entries_[slot];const auto oldBytes=entry.indices.capacity()*sizeof(std::uint32_t);
        const auto available=byteBudget_-(usedBytes_-oldBytes);
        if(count>available/sizeof(std::uint32_t)||count>entry.indices.max_size()){++stats_.rejectedStores;return false;}
        try {
            if(count>entry.indices.capacity()) {
                std::vector<std::uint32_t> candidate(values,values+count);
                if(candidate.capacity()>available/sizeof(std::uint32_t)){++stats_.rejectedStores;return false;}
                entry.indices.swap(candidate);
            } else {
                if(count>entry.indices.size())entry.indices.resize(count);
                std::memmove(entry.indices.data(),values,count*sizeof(std::uint32_t));
                entry.indices.resize(count);
            }
        } catch(const std::bad_alloc&){++stats_.rejectedStores;return false;}
        usedBytes_=usedBytes_-oldBytes+entry.indices.capacity()*sizeof(std::uint32_t);
        entry.key=key;entry.valid=true;entry.seen=true;stats_.storedIndices+=count;
        return true;
    }
    void endFrame() noexcept {
        for(auto& entry:entries_)if(!entry.seen&&entry.valid) {
            usedBytes_-=entry.indices.capacity()*sizeof(std::uint32_t);entry=Entry{};
        }
    }
    void clear() noexcept {std::vector<Entry>{}.swap(entries_);usedBytes_=0;enabled_=false;stats_={};}
    [[nodiscard]] const Statistics& statistics() const noexcept{return stats_;}
    [[nodiscard]] std::size_t bytes() const noexcept{return usedBytes_;}
    [[nodiscard]] bool enabled() const noexcept{return enabled_;}
private:
    struct Entry {StaticTransparentIndexKey key;std::vector<std::uint32_t> indices;bool valid=false,seen=false;};
    std::size_t byteBudget_,entryLimit_,usedBytes_=0;
    bool enabled_=false;
    std::vector<Entry> entries_;
    Statistics stats_;
};
}
