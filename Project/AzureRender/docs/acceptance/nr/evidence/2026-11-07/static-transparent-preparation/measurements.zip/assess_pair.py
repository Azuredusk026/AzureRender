from pathlib import Path
import subprocess,json,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2]
assert json.loads((out/'image/results.json').read_text())['status']=='passed'
work=json.loads((out/'image/transparency-workload.json').read_text());world=json.loads((out/'image/transform-workload.json').read_text());assert world['avoidedWorldFraction']>=.2,world
rows=[]
for role in ['baseline','candidate']:
 start=time.monotonic()
 with (out/('performance-'+role+'-runner.log')).open('wb') as log:r=subprocess.run([sys.executable,'-X','utf8',str(out/('measure_'+role+'.py'))],cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=1000)
 row=dict(role=role,exitCode=r.returncode,seconds=time.monotonic()-start);rows.append(row);(out/'performance-execution.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
 assert r.returncode==0,(out/('performance-'+role+'-runner.log')).read_text(errors='replace')[-4000:]
a=json.loads((out/'performance-baseline/results.json').read_text());b=json.loads((out/'performance-candidate/results.json').read_text())
r=dict(sourceBase='95f0f38',cpuBaseline=a['cpu'],cpuCandidate=b['cpu'],cpuMeanSavedMs=a['cpu']['mean']-b['cpu']['mean'],cpuP95SavedMs=a['cpu']['p95']-b['cpu']['p95'],cpuMeanReduction=1-b['cpu']['mean']/a['cpu']['mean'],gpuBaseline=a['gpu'],gpuCandidate=b['gpu'],environmentPassed=a['environmentPassed'] and b['environmentPassed'],formalSamplesSatisfied=False,visualAcceptance='failed-user-review',workload=work,transformWorkload=world)
(out/'paired-results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
