#include "scenes/CharacterSceneRenderer.hpp"
#include "rhi/NullRhi.hpp"
#include <nlohmann/json.hpp>
#include <iostream>
#include <sstream>
#include <map>

using namespace azurerender;
namespace {
void check(bool value,const char* message){if(!value)throw std::runtime_error(message);}
class ObservedAllocator final:public rhi::IGpuAllocator {
public:
    struct Allocation {rhi::GpuBuffer buffer;VkBufferUsageFlags usage;};
    std::map<VkBuffer,Allocation> buffers;
    explicit ObservedAllocator(rhi::IGpuAllocator& owner):owner_(owner){}
    rhi::GpuBuffer createBuffer(VkDeviceSize size,VkBufferUsageFlags usage,bool visible) override {
        auto buffer=owner_.createBuffer(size,usage,visible);buffers.emplace(buffer.buffer,Allocation{buffer,usage});return buffer;
    }
    void destroyBuffer(rhi::GpuBuffer& buffer) noexcept override {buffers.erase(buffer.buffer);owner_.destroyBuffer(buffer);}
    rhi::GpuImage createImage(const VkImageCreateInfo& info,bool visible) override{return owner_.createImage(info,visible);}
    rhi::GpuImage createImage2D(std::uint32_t width,std::uint32_t height,VkFormat format,VkImageUsageFlags usage,std::uint32_t mips,bool visible) override {
        return owner_.createImage2D(width,height,format,usage,mips,visible);
    }
    void destroyImage(rhi::GpuImage& image) noexcept override{owner_.destroyImage(image);}
    void flush(const rhi::GpuBuffer& buffer,VkDeviceSize offset,VkDeviceSize size) override{owner_.flush(buffer,offset,size);}
    void invalidate(const rhi::GpuBuffer& buffer,VkDeviceSize offset,VkDeviceSize size) override{owner_.invalidate(buffer,offset,size);}
    const rhi::GpuAllocatorStatistics& statistics() const noexcept override{return owner_.statistics();}
private:rhi::IGpuAllocator& owner_;
};
struct Result {nlohmann::json manifest;std::vector<std::uint32_t> indices;};
void verify(const char* shaders,bool bindless){
    rhi::NullRhi backend;ObservedAllocator allocator(backend.allocator());CharacterSceneRenderer renderer;
    RenderContext context;context.rhi=&backend;context.allocator=&allocator;context.shaderDirectory=shaders;
    context.renderExtent={128,96};context.bindlessTextures=bindless;context.cullingEnabled=true;context.sceneWorldCoordinates=true;
    context.sceneColorFormat=VK_FORMAT_R16G16B16A16_SFLOAT;context.depthFormat=VK_FORMAT_D32_SFLOAT;
    auto& limits=context.descriptorLimits;limits.maxImageDimension2D=4096;limits.maxPerStageResources=4096;
    limits.maxPerStageDescriptorSamplers=limits.maxDescriptorSetSamplers=4096;
    limits.maxPerStageDescriptorSampledImages=limits.maxDescriptorSetSampledImages=4096;
    const std::string root=AZURERENDER_TEST_SOURCE_DIR,path=root+"/assets_public/scene_inspector/assets/cube.gltf";
    context.rampAtlasPath=root+"/assets_public/toon_ramp_atlas.ppm";
    auto asset=std::make_shared<LoadedAsset>(loadGltfAsset(path));
    for(auto& material:asset->materials){material.alphaMode=AssetAlphaMode::Blend;material.materialFeatures=0;}
    for(auto& node:asset->nodes)node.opacity=1;
    std::map<std::string,std::shared_ptr<const LoadedAsset>> prepared{{path,asset}};context.preparedMeshes=&prepared;
    context.scene.resources.push_back({"mesh",path});scene::SceneNodeDesc node;node.id="object";node.resourceId="mesh";context.scene.nodes.push_back(node);
    RenderSettings settings;settings.faceSdfFeature=false;settings.showcasePlatformFeature=false;settings.morphWeights={0,0};
    settings.characterPresentation.backgroundEnabled=false;context.renderSettings=&settings;
    renderer.onLoad(context);
    SceneFrameData frame;frame.renderSettings=&settings;frame.swapchainWidth=128;frame.swapchainHeight=96;
    frame.cameraPosition[0]=0;frame.cameraPosition[1]=0;frame.cameraPosition[2]=4;
    const auto execute=[&](unsigned slot){
        frame.currentFrame=slot;context.currentFrame=slot;renderer.updateFrame(frame);
        rhi::NullCommandRecorder recorder;context.commands=&recorder;renderer.recordScene(context);context.commands=nullptr;
        std::ostringstream fields;renderer.appendCaptureManifestFields(fields);
        Result result;result.manifest=nlohmann::json::parse("{"+fields.str()+"\"fixture\":true}");
        const auto requested=result.manifest.at("transparentIndexRequests").get<std::size_t>();
        const auto hidden=result.manifest.at("transparentHiddenIndices").get<std::size_t>();
        if(requested>hidden){
            const auto found=std::find_if(recorder.calls.rbegin(),recorder.calls.rend(),[](const auto& call){return call.name=="bindIndexBuffer";});
            check(found!=recorder.calls.rend(),"Visible transparent geometry must bind an index buffer");
            const auto handle=reinterpret_cast<VkBuffer>(std::uintptr_t(std::stoull(found->detail,nullptr,16)));
            const auto& allocation=allocator.buffers.at(handle);
            check(allocation.usage==VK_BUFFER_USAGE_INDEX_BUFFER_BIT,"Transparent recording must consume the prepared frame index storage");
            check(allocation.buffer.size>=requested*sizeof(std::uint32_t),"Prepared index storage must cover all stable offsets");
            const auto* values=static_cast<const std::uint32_t*>(allocation.buffer.mapped);
            result.indices.assign(values,values+requested);
        }
        return result;
    };
    const auto first=execute(0);const auto count=first.manifest.at("transparentIndexRequests").get<std::size_t>();
    check(count>0&&first.manifest.at("transparentComputedIndices")==count,"First visible frame must execute complete preparation");
    const auto second=execute(1);
    check(second.manifest.at("transparentIndexCacheHits")==1&&second.manifest.at("transparentReusedIndices")==count
        &&second.manifest.at("transparentComputedIndices")==0,"An unchanged fixed pose must reuse the actual prepared index slice");
    check(first.indices==second.indices,"Different frame slots must receive identical complete ordered indices");
    frame.cameraPosition[2]=-4;const auto reverse=execute(0);
    check(reverse.manifest.at("transparentComputedIndices")==count&&reverse.manifest.at("transparentIndexCacheHits")==0,
        "Camera movement must invalidate actual renderer preparation");
    check(reverse.indices!=first.indices,"Opposite views must produce independently sorted geometry");
    check(execute(1).indices==reverse.indices,"The changed view must be reusable on the next frame slot");
    auto moved=std::make_shared<scene::SceneDescription>(context.scene);moved->nodes[0].translation[0]=.25F;frame.sceneSnapshot=moved;
    check(execute(0).manifest.at("transparentComputedIndices")==count,"Model movement must invalidate renderer preparation");
    settings.morphWeights[0]=.25F;
    check(execute(1).manifest.at("transparentComputedIndices")==count,"Legacy morph inputs must participate in exact renderer matching");
    auto hidden=std::make_shared<scene::SceneDescription>(*moved);hidden->nodes[0].translation[0]=10000;frame.sceneSnapshot=hidden;
    const auto invisible=execute(0);
    check(invisible.manifest.at("transparentHiddenIndices")==count&&invisible.manifest.at("transparentComputedIndices")==0
        &&invisible.manifest.at("transparentReusedIndices")==0,"Invisible geometry must preserve offsets while omitting unused CPU work");
    check(invisible.manifest.at("transparentIndexCacheBytes")==0,"Invisible cache entries must release their retained values");
    frame.sceneSnapshot=moved;check(execute(1).manifest.at("transparentComputedIndices")==count,"Reappearing geometry must prepare current inputs");
    NodeAnimationFrame animation;animation.node="object";frame.animations.push_back(animation);
    const auto animated=execute(0);
    check(animated.manifest.at("transparentComputedIndices")==count&&animated.manifest.at("transparentIndexCacheHits")==0,
        "Presented dynamic poses must retain the complete preparation path");
    check(execute(1).manifest.at("transparentComputedIndices")==count,"Dynamic frames must never borrow fixed-pose indices");
    renderer.onUnload(context);check(allocator.statistics().liveBuffers==0&&allocator.statistics().liveImages==0,"Unloading must retire every GPU resource");
    renderer.onLoad(context);frame.animations.clear();frame.sceneSnapshot.reset();settings.morphWeights={0,0};frame.cameraPosition[2]=4;
    const auto reloaded=execute(0);check(reloaded.manifest.at("transparentComputedIndices")==count&&reloaded.indices==first.indices,
        "A new load epoch must rebuild fixed-pose indices with independent lifetime");
    renderer.onUnload(context);check(allocator.statistics().liveBuffers==0&&allocator.statistics().liveImages==0,"Reload cleanup must remain complete");
}
}
int main(int argc,char** argv)try{
    if(argc!=2)throw std::invalid_argument("Expected shader directory");verify(argv[1],false);verify(argv[1],true);
    std::cout<<"Actual transparent preparation, frame slots, views, visibility, poses and lifetimes passed\n";
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
