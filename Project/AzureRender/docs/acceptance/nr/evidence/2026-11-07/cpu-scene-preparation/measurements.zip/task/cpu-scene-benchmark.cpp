#include "runtime/RuntimeLifecycle.hpp"
#include "runtime/camera/GameCameraService.hpp"
#include "scene/SceneDescription.hpp"
#include "cpu-baseline-runtime.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
#include <nlohmann/json.hpp>
using namespace azurerender;
GameCameraSelection baselineCamera(RuntimeLifecycle& runtime,const scene::SceneDescription& scene){
    GameCameraSelection result;std::int64_t priority=-1;
    const auto matrices=scene::resolveNodeWorldTransforms(scene);
    for(std::size_t i=0;i<scene.nodes.size();++i){
        const auto& node=scene.nodes[i];
        const auto* camera=runtime.world().tryGet<game::GameCamera>(runtime.entity(node.id));
        if(!camera||!camera->enabled||camera->priority<priority
            ||(camera->priority==priority&&!result.node.empty()&&node.id>=result.node))continue;
        CameraViewDescriptor view;
        try{view=gameCameraView(*camera,matrices[i]);}catch(const std::exception& e){result.diagnostic=node.id+": "+e.what();continue;}
        result.view=view;result.node=node.id;priority=camera->priority;
    }
    if(!result.view&&result.diagnostic.empty())result.diagnostic="No enabled GameCamera";
    return result;
}
int main(int argc,char** argv){
 if(argc!=2)return 2;
 nlohmann::json input;std::ifstream file(argv[1]);file>>input;
 SceneDocument document;document.sceneId=input.at("id").get<std::string>();
 for(const auto& r:input.at("resources"))document.resources.push_back({r.at("id").get<std::string>(),r.value("type",std::string("model")),r.value("path",std::string("assets:/models/")+r.value("asset",std::string("mesh"))+".gltf")});
 for(const auto& n:input.at("nodes")){
  SceneNode node;node.id=n.at("id");node.name=n.value("name",std::string{});node.parentId=n.value("parentId",std::string{});node.resourceId=n.value("resourceId",std::string{});
  if(n.contains("components")){
   const auto& components=n.at("components");
   if(components.contains("azure.transform")){
    const auto& t=components.at("azure.transform").at("data");
    if(t.contains("translation"))node.translation=t.at("translation").get<std::array<float,3>>();
    if(t.contains("rotation"))node.rotation=t.at("rotation").get<std::array<float,3>>();
    if(t.contains("scale"))node.scale=t.at("scale").get<std::array<float,3>>();
   }
   if(components.contains("azure.renderable"))node.visible=components.at("azure.renderable").at("data").value("visible",true);
  }
  document.nodes.push_back(std::move(node));
 }
 for(const auto& l:input.at("lights")){SceneLight light;light.id=l.at("id");light.nodeId=l.at("nodeId");document.lights.push_back(light);}
 baseline::RuntimeLifecycle old;old.loadScene(document);RuntimeLifecycle current;current.loadScene(document);
 for(const auto& n:input.at("nodes"))if(n.contains("components")&&n.at("components").contains("azure.camera")){
  game::GameCamera camera;const auto& c=n.at("components").at("azure.camera").at("data");camera.priority=c.value("priority",0U);camera.fieldOfView=c.value("fieldOfView",60.F);camera.farPlane=c.value("farPlane",1000.F);camera.projectionOffsetX=c.value("projectionOffsetX",0.F);camera.projectionOffsetY=c.value("projectionOffsetY",0.F);
  current.world().addComponent(current.entity(n.at("id")),camera);
 }
 SceneDocument retained;current.snapshotScene(retained);auto description=document.renderDescription();
 double before=0,after=0,cameraBefore=0,cameraAfter=0;std::size_t checksum=0;
 const auto timed=[](auto&& operation){const auto begin=std::chrono::steady_clock::now();operation();return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();};
 for(unsigned round=0;round<160;++round){
  const auto a=[&]{before+=timed([&]{auto result=old.snapshotScene();checksum+=result.nodes.size()+result.lights.size();});};
  const auto b=[&]{after+=timed([&]{current.snapshotScene(retained);checksum+=retained.nodes.size()+retained.lights.size();});};
  const auto c=[&]{cameraBefore+=timed([&]{auto result=baselineCamera(current,description);checksum+=result.node.size();});};
  const auto d=[&]{cameraAfter+=timed([&]{auto result=resolveGameCamera(current,description);checksum+=result.node.size();});};
  if(round&1){a();b();c();d();}else{b();a();d();c();}
 }
 const auto a=old.snapshotScene();const auto c=baselineCamera(current,description),d=resolveGameCamera(current,description);
 if(a.nodes.size()!=retained.nodes.size()||c.node!=d.node||!c.view||!d.view||c.view->position!=d.view->position||c.view->target!=d.view->target||c.view->up!=d.view->up)return 1;
 for(std::size_t i=0;i<a.nodes.size();++i)if(a.nodes[i].id!=retained.nodes[i].id||a.nodes[i].translation!=retained.nodes[i].translation||a.nodes[i].rotation!=retained.nodes[i].rotation||a.nodes[i].scale!=retained.nodes[i].scale||a.nodes[i].visible!=retained.nodes[i].visible)return 1;
 std::cout<<nlohmann::json{{"scope","native-shaped CPU control; document material resolution and Player frame excluded"},{"rounds",160},{"nodes",document.nodes.size()},{"resources",document.resources.size()},{"snapshotBaselineMs",before/160},{"snapshotCandidateMs",after/160},{"cameraBaselineMs",cameraBefore/160},{"cameraCandidateMs",cameraAfter/160},{"combinedReduction",1-(after+cameraAfter)/(before+cameraBefore)},{"identical",true},{"checksum",checksum}}.dump(2)<<'\n';
}
