from pathlib import Path
import json,os,subprocess,time
out=Path(__file__).resolve().parent;root=out.parents[2]
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
python=str(root/'build/reinstall-environment/venv/Scripts/python.exe');build=root/'build/ninja-msvc-release'
targets=['AzureRuntimeLifecycleTests','AzureCameraSystemTests','AzureRenderEcsTests','AzureSceneRenderSnapshotTests']
commands=[['cmd','/d','/c',str(root/'tools/msvc_env.bat'),python,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config','Release',*[arg for target in targets for arg in ['--test-target',target]]],['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe','--test-dir',str(build),'-R','^(AzureEngine.RuntimeLifecycle|AzureRuntime.CameraSystem|AzureRender.Ecs|AzureRuntime.SceneRenderSnapshot)$','--output-on-failure','--no-tests=error','--output-junit',str(out/'cpu-batch-checks.xml')]]
rows=[]
for kind,command,deadline in zip(['build','checks'],commands,[900,180]):
 start=time.monotonic()
 with (out/('cpu-batch-'+kind+'.log')).open('wb') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=deadline)
 row=dict(kind=kind,exitCode=result.returncode,seconds=time.monotonic()-start,command=command);rows.append(row);(out/'cpu-batch-build-check-results.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
 assert result.returncode==0,(out/('cpu-batch-'+kind+'.log')).read_text(errors='replace')[-5000:]
