from pathlib import Path
import ctypes,json,os,shutil,subprocess,sys,time
OUT=Path(__file__).resolve().parent
E=OUT.parents[2]
sys.path.insert(0,str(E/'tools'))
from build_provenance import inputs,digest
probe=OUT/'cpu-phase-probe'
probe.mkdir(exist_ok=True)
old=E/'build/runs/20261105-125529-automatic-acceptance-3d5b54'
current=(E/'src/app/AzureRenderFrame.cpp').read_bytes()
base=subprocess.check_output(['git','show','a295e09:Project/AzureRender/src/app/AzureRenderFrame.cpp'],cwd=E)
assert current.replace(b'\r\n',b'\n')==base.replace(b'\r\n',b'\n')
shutil.copy2(old/'cpu-long-run-growth/source/AzureRenderFrame.cpp',probe/'AzureRenderFrame.cpp')
frozen=inputs(E)
command=json.loads((old/'cpu-long-run-growth/original-compile-commands.json').read_text())['AzureRenderFrame']
api=ctypes.WinDLL('shell32').CommandLineToArgvW
api.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
api.restype=ctypes.POINTER(ctypes.c_wchar_p)
free=ctypes.WinDLL('kernel32').LocalFree;free.argtypes=[ctypes.c_void_p]
count=ctypes.c_int();pointer=api(command,ctypes.byref(count));assert pointer
try:args=[pointer[i] for i in range(count.value)]
finally:free(pointer)
for i,value in enumerate(args):
    if value.startswith('/Fo'):args[i]='/Fo'+str(probe/'AzureRenderFrame.obj')
    elif value.startswith('/Fd'):args[i]='/Fd'+str(probe/'AzureRenderFrame.pdb')
args[-1]=str(probe/'AzureRenderFrame.cpp')
args.insert(-2,'/I'+str(E/'src/app'))
with (probe/'compile.log').open('wb') as log:
    r=subprocess.run(args,cwd=E/'build/ninja-msvc-release',stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert r.returncode==0,(probe/'compile.log').read_text(errors='replace')[-2000:]
original=old/'private-profile-map-2fad7ef'
rsp=(original/'link.rsp').read_text().replace(str(original),str(probe))
rsp='"'+str(probe/'AzureRenderFrame.obj')+'" '+rsp
(probe/'link.rsp').write_text(rsp)
link=['D:/Tools/VS2022BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/link.exe','@'+str(probe/'link.rsp')]
with (probe/'link.log').open('wb') as log:
    r=subprocess.run(link,cwd=E/'build/ninja-msvc-release',stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert r.returncode==0,(probe/'link.log').read_text(errors='replace')[-2000:]
assert inputs(E)==frozen
(probe/'build.json').write_text(json.dumps(dict(sourceBase='c61ed88',scope='One private host translation unit; current batch runtime library; stage20-frame window only',sourceInputs=frozen,privateFrameSha256=digest(probe/'AzureRenderFrame.cpp'),privatePlayerSha256=digest(probe/'AzurePlayer.exe'),command=args,link=link),indent=2))
print('Current CPU phase probe built without changing production sources or executables',flush=True)
