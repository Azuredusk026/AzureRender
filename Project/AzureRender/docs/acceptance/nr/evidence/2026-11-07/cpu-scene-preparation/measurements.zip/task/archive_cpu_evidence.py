from pathlib import Path
import json,hashlib,zipfile,datetime,sys
out=Path(__file__).resolve().parent;root=out.parents[2]
sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import digest
folder=root/'docs/acceptance/nr/evidence/2026-11-07/cpu-scene-preparation';folder.mkdir(parents=True,exist_ok=True)
paths=set()
for p in out.iterdir():
 if p.is_file() and p.suffix in ['.py','.cpp','.hpp','.json','.xml','.log','.rsp'] and ('cpu' in p.name):paths.add(p)
for name in ['cpu-phase-probe','cpu-native-baseline','cpu-native-candidate','image-cpu-batch']:
 for p in (out/name).rglob('*'):
  if p.is_file() and p.suffix in ['.json','.csv','.log','.cpp','.rsp'] and p.name!='measurements.zip':paths.add(p)
paths.add(root/'build/ninja-msvc-release/build-provenance.json')
memberHashes={}
archive=folder/'measurements.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(paths):
  name='task/'+p.relative_to(out).as_posix() if p.is_relative_to(out) else 'production/build-provenance.json'
  data=p.read_bytes();memberHashes[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert all(hashlib.sha256(z.read(name)).hexdigest()==value for name,value in memberHashes.items())
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
baseline=read(out/'cpu-native-baseline/results.json');candidate=read(out/'cpu-native-candidate/results.json');probe=read(out/'cpu-phase-probe/native/results.json')
sourcePaths=['src/app/AzureRenderApp.cpp','src/app/AzureRenderApp.hpp','src/ecs/World.hpp','src/runtime/RuntimeLifecycle.hpp','src/runtime/GameRuntime.cpp','src/runtime/GameRuntime.hpp','src/runtime/camera/GameCameraService.cpp','tests/CameraSystemTests.cpp','tests/RuntimeLifecycleTests.cpp','tests/EcsTests.cpp']
summary=dict(status='implementation-and-diagnostic-complete',sourceBase='c61ed88',sourceHashes={p:digest(root/p) for p in sourcePaths},baselinePlayerSha256=baseline['executableSha256'],candidatePlayerSha256=candidate['executableSha256'],visualAcceptance='failed-user-review',formalPerformancePassed=False,cpuBudgetMs=8,gpuBudgetMs=16.6,formalSamplesRequired=1800,shortSamples=120,privateProbe=dict(playerSha256=probe['privateInstrumentedPlayerSha256'],cpu=probe['cpu'],hostStages=probe['hostStages'],sampleFrames=20,powerStable=probe['powerProfileStable']),microbenchmark=read(out/'cpu-scene-benchmark.json'),pair=read(out/'cpu-paired-results.json'),nativeBaseline=baseline,nativeCandidate=candidate,image=read(out/'image-cpu-batch/results.json'),buildChecks=read(out/'cpu-batch-build-check-results.json'),assessment=read(out/'cpu-native-assessment.json'),logTimestamps=read(out/'cpu-batch-wall-times.json'),budget=check(root/'build',run=out,planned=0),archive=dict(path='measurements.zip',bytes=archive.stat().st_size,sha256=digest(archive),memberHashes=memberHashes))
summary['implementationSeconds']=(out/'cpu-batch-build.log').stat().st_ctime-(root/'docs/plans/2026-11-06-cpu-scene-preparation.md').stat().st_ctime
summary['scopeChecksReusedAfterHostExceptionBoundaryFix']=True
summary['cancelledBuildScope']={'log':'task/cpu-batch-final-build.log','reason':'Unrelated default targets cancelled; final scoped runtime-and-four-tests build passed. Tests were not rerun for the host-only exception boundary fix.'}
(folder/'results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=summary['status'],archiveBytes=archive.stat().st_size,members=len(memberHashes),cpu=summary['pair'],budget=summary['budget']),ensure_ascii=False))
