from pathlib import Path
import subprocess,json,os,time
out=Path(__file__).resolve().parent;root=out.parents[2]
v=json.loads((out/'cpu-phase-probe/build.json').read_text());args=v['command']
args=[arg.replace(str(out/'cpu-phase-probe/AzureRenderFrame.obj'),str(out/'cpu-scene-benchmark.obj')).replace(str(out/'cpu-phase-probe/AzureRenderFrame.pdb'),str(out/'cpu-scene-benchmark.pdb')).replace(str(out/'cpu-phase-probe/AzureRenderFrame.cpp'),str(out/'cpu-scene-benchmark.cpp')) for arg in args if arg!='/showIncludes']
args.insert(-2,'/I'+str(root/'src/runtime'))
with (out/'cpu-scene-benchmark-compile.log').open('wb') as log: result=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert result.returncode==0,(out/'cpu-scene-benchmark-compile.log').read_text(errors='replace')[-5000:]
rsp=(out/'cpu-phase-probe/link.rsp').read_text().replace(str(out/'cpu-phase-probe/AzureRenderFrame.obj'),str(out/'cpu-scene-benchmark.obj')).replace('CMakeFiles\\AzurePlayer.dir\\src\\player\\main.cpp.obj','').replace(str(out/'cpu-phase-probe/AzurePlayer'),str(out/'cpu-scene-benchmark'))
(out/'cpu-scene-benchmark-link.rsp').write_text(rsp)
with (out/'cpu-scene-benchmark-link.log').open('wb') as log: result=subprocess.run([v['link'][0],'@'+str(out/'cpu-scene-benchmark-link.rsp')],cwd=root/'build/ninja-msvc-release',stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert result.returncode==0,(out/'cpu-scene-benchmark-link.log').read_text(errors='replace')[-5000:]
env=os.environ.copy();env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH']
command=[str(out/'cpu-scene-benchmark.exe'),str(root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/scene/joint-dynamic-loop-v2.azurelevel')]
result=subprocess.run(command,cwd=out,env=env,capture_output=True,text=True,timeout=60)
(out/'cpu-scene-benchmark-output.log').write_text(result.stdout+result.stderr);assert result.returncode==0,result.stdout+result.stderr
summary=json.loads(result.stdout);(out/'cpu-scene-benchmark.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
