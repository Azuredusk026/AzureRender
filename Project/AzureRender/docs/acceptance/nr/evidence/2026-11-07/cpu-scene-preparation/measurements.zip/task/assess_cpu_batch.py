from pathlib import Path
import subprocess,sys,json,time
out=Path(__file__).resolve().parent;root=out.parents[2];rows=[]
for name in ['capture_cpu_batch.py','measure_cpu_baseline.py','measure_cpu_candidate.py']:
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as log: result=subprocess.run([sys.executable,str(out/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=1100)
 row=dict(script=name,exitCode=result.returncode,seconds=time.monotonic()-start);rows.append(row);(out/'cpu-native-assessment.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
 assert result.returncode==0,(out/(name+'.log')).read_text(errors='replace')[-4000:]
a=json.loads((out/'cpu-native-baseline/results.json').read_text());b=json.loads((out/'cpu-native-candidate/results.json').read_text())
summary=dict(baseline=a['cpu'],candidate=b['cpu'],meanSavedMs=a['cpu']['mean']-b['cpu']['mean'],p95SavedMs=a['cpu']['p95']-b['cpu']['p95'],meanReduction=1-b['cpu']['mean']/a['cpu']['mean'],environmentPassed=a['environmentPassed'] and b['environmentPassed'],baselineEnvironment=a['environmentPassed'],candidateEnvironment=b['environmentPassed'],formalSampleCountSatisfied=False,visualAcceptance='failed-user-review',cpuBudgetPassed=b['cpu']['p95']<=8,sourceProductsFrozen=True)
(out/'cpu-paired-results.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
