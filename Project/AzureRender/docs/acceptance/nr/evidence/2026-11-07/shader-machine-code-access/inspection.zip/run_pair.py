from pathlib import Path
import subprocess,json,time
out=Path(__file__).resolve().parent;si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'pair-driver.log').open('wb') as log:r=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'compare_representations.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=120)
result=json.loads((out/'paired-representation.json').read_text());assert r.returncode==0 and result['status']=='compared',result;print(json.dumps(dict(seconds=time.monotonic()-start,**result)),flush=True)
