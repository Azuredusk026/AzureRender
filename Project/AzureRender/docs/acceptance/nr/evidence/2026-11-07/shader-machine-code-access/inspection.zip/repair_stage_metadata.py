from pathlib import Path
out=Path('build/runs/20261107-125749-shader-machine-code-access-0338ca');s=(out/'compare_representations.py').read_text();s=s.replace("ref=p.GetShaderReflection(stage);text=c.DisassembleShader(pipeline,ref,target);name=label+", "ref=p.GetShaderReflection(stage);reportedStage=str(ref.stage);ref.stage=stage;text=c.DisassembleShader(pipeline,ref,target);name=label+")
s=s.replace("reflectionSha256=hashlib.sha256(bytes(ref.rawBytes)).hexdigest(),file=name,text=text", "reflectionSha256=hashlib.sha256(bytes(ref.rawBytes)).hexdigest(),reportedReflectionStage=reportedStage,requestedStage=str(stage),file=name,text=text")
(out/'compare_representations.py').write_text(s)
