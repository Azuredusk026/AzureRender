from pathlib import Path
import json,sys,hashlib,traceback
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-125749-shader-machine-code-access-0338ca';g=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc';state=json.loads((g/'state.json').read_text());profile=json.loads((g/'events/profile.json').read_text());cap=None;c=None;report={}
def fields(o):return {str(o.GetChild(i).name):o.GetChild(i) for i in range(o.NumChildren())}
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded;target='KHR_pipeline_executable_properties';assert target in c.GetDisassemblyTargets(True)
 shaderKey=next(k for k,v in profile['shaders'].items() if v.get('programFile')=='mesh_object_bindless_clipmap_field_early.frag.spv');shader=None;pipeline=None
 for ch in c.GetStructuredFile().chunks:
  if str(ch.name)!='vkCreateGraphicsPipelines':continue
  f=fields(ch);info=fields(f['CreateInfo'])
  for j in range(info['pStages'].NumChildren()):
   stage=fields(info['pStages'].GetChild(j))
   if int(stage['stage'].data.basic.u)==16 and str(stage['module'].AsResourceId())==shaderKey:
    # Select the ordinary-material specialization used by the main hotspot.
    spec=fields(stage['SpecializationInfo']) if 'SpecializationInfo' in stage else {}
    shader=stage['module'].AsResourceId();pipeline=f['Pipeline'].AsResourceId();break
  if pipeline:break
 assert pipeline is not None
 entry=rd.ShaderEntryPoint();entry.name='main';entry.stage=rd.ShaderStage.Pixel;reflection=c.GetShader(pipeline,shader,entry);assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==profile['shaders'][shaderKey]['sha256']
 text=c.DisassembleShader(pipeline,reflection,target);assert isinstance(text,str) and len(text)<=1024**2;(out/'baseline-driver.txt').write_text(text)
 report=dict(status='read',target=target,shader=shaderKey,pipeline=str(pipeline),bytes=len(text.encode()),prefix=text[:2500],captureSha256=state['captureSha256'],performanceCountersRun=False,frameEventsReplayed=0)
except Exception:report=dict(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'driver-representation.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='read' else 1)
