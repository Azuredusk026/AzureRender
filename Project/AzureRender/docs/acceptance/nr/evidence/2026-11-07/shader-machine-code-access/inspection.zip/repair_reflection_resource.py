from pathlib import Path
import shutil
out=Path('build/runs/20261107-125749-shader-machine-code-access-0338ca');shutil.copy2(out/'paired-representation.json',out/'initial-paired-representation.json');s=(out/'compare_representations.py').read_text();s=s.replace("ref=p.GetShaderReflection(stage);reportedStage=str(ref.stage);ref.stage=stage;", "ref=p.GetShaderReflection(stage);reportedStage=str(ref.stage);reportedResource=str(ref.resourceId);ref.stage=stage;ref.resourceId=shader if stage==rd.ShaderStage.Pixel else p.GetShader(rd.ShaderStage.Vertex);")
s=s.replace("reportedReflectionStage=reportedStage,requestedStage=str(stage)","reportedReflectionStage=reportedStage,reportedReflectionResource=reportedResource,requestedReflectionResource=str(ref.resourceId),requestedStage=str(stage)")
(out/'compare_representations.py').write_text(s)
