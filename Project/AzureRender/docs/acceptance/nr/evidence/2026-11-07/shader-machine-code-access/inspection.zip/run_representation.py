from pathlib import Path
import subprocess,json,time
out=Path(__file__).resolve().parent;root=out.parents[2];si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'representation-driver.log').open('wb') as log:r=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'read_driver_representation.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=90)
result=json.loads((out/'driver-representation.json').read_text());assert r.returncode==0 and result['status']=='read',result;print(json.dumps(dict(seconds=time.monotonic()-start,**result)),flush=True)
