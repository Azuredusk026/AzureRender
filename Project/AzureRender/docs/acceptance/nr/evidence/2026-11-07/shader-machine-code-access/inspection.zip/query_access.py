from pathlib import Path
import json,sys,traceback
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-125749-shader-machine-code-access-0338ca';g=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc';state=json.loads((g/'state.json').read_text());cap=None;c=None;report={}
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 report=dict(status='queried',renderdocVersion=str(rd.GetVersionString()),captureSha256=state['captureSha256'],targetsWithPipeline=list(c.GetDisassemblyTargets(True)),targetsWithoutPipeline=list(c.GetDisassemblyTargets(False)),getTargetsDocumentation=str(rd.ReplayController.GetDisassemblyTargets.__doc__),disassembleDocumentation=str(rd.ReplayController.DisassembleShader.__doc__),performanceCountersRun=False,frameEventsReplayed=0)
except Exception:report=dict(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'access.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='queried' else 1)
