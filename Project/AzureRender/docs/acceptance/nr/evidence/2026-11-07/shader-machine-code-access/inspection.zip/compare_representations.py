from pathlib import Path
import json,sys,hashlib,traceback,struct
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-125749-shader-machine-code-access-0338ca';g=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc';state=json.loads((g/'state.json').read_text());profile=json.loads((g/'events/profile.json').read_text());cap=None;c=None;report={}
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded;target='KHR_pipeline_executable_properties';shaderKey=next(k for k,v in profile['shaders'].items() if v.get('programFile')=='mesh_object_bindless_clipmap_field_early.frag.spv');event=max((r for r in profile['measurements'] if r['shader']==shaderKey),key=lambda r:r['seconds'])['event'];c.SetFrameEvent(event,True);p=c.GetPipelineState();pipeline=p.GetGraphicsPipelineObject();shader=p.GetShader(rd.ShaderStage.Pixel);reflection=p.GetShaderReflection(rd.ShaderStage.Pixel);vk=c.GetVulkanPipelineState();data=bytes(vk.fragmentShader.specializationData);spec={v.name:struct.unpack_from('<I',data,v.byteOffset)[0] for b in reflection.constantBlocks if b.compileConstants for v in b.variables};assert spec['azureOrdinaryOpaque']==1,spec
 rows=[]
 for label in ['baseline','specialized']:
  if label=='specialized':
   programFile=root/'build/runs/20261107-111830-computed-specialization-cost-b26603/mesh_object_bindless_clipmap_field_early.frag.spv';program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,programFile.read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert program!=rd.ResourceId.Null(),errors;c.ReplaceResource(shader,program);c.SetFrameEvent(event,True);p=c.GetPipelineState();pipeline=p.GetGraphicsPipelineObject()
  for stage in [rd.ShaderStage.Vertex,rd.ShaderStage.Pixel]:
   ref=p.GetShaderReflection(stage);reportedStage=str(ref.stage);reportedResource=str(ref.resourceId);ref.stage=stage;ref.resourceId=shader if stage==rd.ShaderStage.Pixel else p.GetShader(rd.ShaderStage.Vertex);text=c.DisassembleShader(pipeline,ref,target);name=label+'-'+str(stage)+'.txt';(out/name).write_text(text);rows.append(dict(mode=label,stage=str(stage),pipeline=str(pipeline),shader=str(p.GetShader(stage)),reflectionSha256=hashlib.sha256(bytes(ref.rawBytes)).hexdigest(),reportedReflectionStage=reportedStage,reportedReflectionResource=reportedResource,requestedReflectionResource=str(ref.resourceId),requestedStage=str(stage),file=name,text=text))
 report=dict(status='compared',event=event,specialization=spec,rows=rows,performanceCountersRun=False,scope='Driver pipeline executable properties for the same captured ordinary main draw, before and after fragment specialization. Text may contain only statistics; no machine instructions are assumed available.')
except Exception:report=dict(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'paired-representation.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='compared' else 1)
