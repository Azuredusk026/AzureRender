from pathlib import Path
import subprocess,json,time,sys
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
source=inputs(root);products={p.name:digest(p) for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv')};si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'driver.log').open('wb') as log:r=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'query_access.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=90)
result=json.loads((out/'access.json').read_text());assert r.returncode==0 and result['status']=='queried',result;assert inputs(root)==source and {p.name:digest(p) for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv')}==products;print(json.dumps(dict(seconds=time.monotonic()-start,**result)),flush=True)
