from pathlib import Path
import json,zipfile,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];rows=json.loads((out/'pair-results.json').read_text());assert len(rows)==1 and rows[0]['mode']=='unfenced' and all(r['changedPixels']==0 for r in rows[0]['frames']);props=[list(map(int,line.split())) for line in (out/'unfenced/allocation-properties.txt').read_text().splitlines()];assert props and all(r[2]==7 for r in props)
e=root/'docs/acceptance/nr/evidence/2026-11-07/host-write-publication';e.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(e/'control.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.rglob('*'):
  if p.is_file() and p.suffix not in ['.png','.exe','.obj','.pdb','.map','.lib']:z.write(p,p.relative_to(out))
p=e/'control.zip';r=dict(status='failure-not-reproduced-no-publication-candidate-run',control=rows[0],mappedTypedAllocations=len(props),allActualProperties=7,explicitPublicationEnabled=False,uploadDataReadingEnabled=False,rootCauseQualified=False,productionChanged=False,invariants=json.loads((out/'pair-invariants.json').read_text()),archive=dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));(e/'results.json').write_text(json.dumps(r,indent=2));print(r['status'])
