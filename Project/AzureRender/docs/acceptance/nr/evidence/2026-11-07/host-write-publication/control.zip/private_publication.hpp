#include <atomic>
#include <array>
#include <cstdlib>
#include <fstream>
#include <string>
#include <immintrin.h>
namespace azure_diag {
inline unsigned setting(const char* name){const auto* value=std::getenv(name);return value?static_cast<unsigned>(std::strtoul(value,nullptr,0)):0;}
static const unsigned usageMask=setting("AZURE_DIAG_DEVICE_USAGE");
static const bool publish=setting("AZURE_DIAG_WRITE_FENCE")!=0;
static const std::string reportPath=[](){const auto* value=std::getenv("AZURE_DIAG_PROPERTY_FILE");return value?std::string(value):std::string{};}();
struct Record {VkBufferUsageFlags usage{};VkMemoryPropertyFlags properties{};VkDeviceSize size{};};
static std::array<Record,2048> records{};
static std::atomic<unsigned> count{0};
inline void remember(const azurerender::rhi::GpuBuffer& buffer,VkBufferUsageFlags usage,bool mapped,VmaAllocator allocator){
    if(!mapped||!(usage&0x1fcU))return;
    const auto index=count.fetch_add(1,std::memory_order_relaxed);if(index>=records.size())return;
    auto& entry=records[index];entry.usage=usage;entry.size=buffer.size;vmaGetAllocationMemoryProperties(allocator,buffer.allocation,&entry.properties);
}
struct Writer {~Writer(){if(reportPath.empty())return;std::ofstream file(reportPath);for(unsigned i=0;i<count.load()&&i<records.size();++i)file<<i<<' '<<records[i].usage<<' '<<records[i].properties<<' '<<records[i].size<<'\n';}};
static Writer writer;
}
