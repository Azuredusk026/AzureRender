from pathlib import Path
import json,subprocess,os,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest;from artifact_budget import check
assert check(root/'build',run=out,planned=256*1024**2)['allowed'];frozen=inputs(root);old=root/'build/runs/20261107-042805-host-scene-preparation-34e27e'
s=(root/'src/rhi/GpuAllocator.cpp').read_text();s=s.replace('#include <vk_mem_alloc.h>','#include <vk_mem_alloc.h>\n#include "private_publication.hpp"')
needle='allocationInfo.usage = VMA_MEMORY_USAGE_AUTO_PREFER_HOST;';assert s.count(needle)==2;s=s.replace(needle,'allocationInfo.usage = (usage & azure_diag::usageMask) != 0 ? VMA_MEMORY_USAGE_AUTO_PREFER_DEVICE : VMA_MEMORY_USAGE_AUTO_PREFER_HOST;',1)
s=s.replace('result.size = size;','result.size = size;\n    azure_diag::remember(result,usage,hostVisible,allocator_);',1)
needle='    check(\n        vmaFlushAllocation';assert needle in s;s=s.replace(needle,'    if(azure_diag::publish)_mm_sfence();\n'+needle,1);(out/'GpuAllocator.cpp').write_text(s)
command=json.loads((old/'compile.json').read_text())['command'];command=[v.replace(str(old),str(out)).replace('AzureRenderApp.obj','GpuAllocator.obj').replace('AzureRenderApp.pdb','GpuAllocator.pdb').replace('AzureRenderApp.cpp','GpuAllocator.cpp') for v in command];command.insert(1,'/D_CRT_SECURE_NO_WARNINGS=1');command.insert(1,'/I'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include/vma'))
link=(root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/link.rsp').read_text();first=link.index(' /nologo');link='"'+str(out/'GpuAllocator.obj')+'"'+link[first:];link=link.replace('20261107-120518-uniform-texture-index-cost-ebdc25',out.name);(out/'link.rsp').write_text(link)
env=dict(os.environ);env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9');rows=[]
for kind,cmd,cwd in [('compile',['cmd','/d','/c',str(root/'tools/msvc_env.bat'),*command],root),('link',['cmd','/d','/c',str(root/'tools/msvc_env.bat'),'D:/Tools/VS2022BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/link.exe','@'+str(out/'link.rsp')],root/'build/ninja-msvc-release')]:
 start=time.monotonic()
 with (out/(kind+'.log')).open('wb') as log:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 rows.append(dict(kind=kind,exitCode=p.returncode,seconds=time.monotonic()-start,command=cmd));(out/'build.json').write_text(json.dumps(rows,indent=2));print(json.dumps({k:v for k,v in rows[-1].items() if k!='command'}),flush=True);assert p.returncode==0,(out/(kind+'.log')).read_text(errors='replace')[-4000:]
assert inputs(root)==frozen
(out/'private-inputs.json').write_text(json.dumps(dict(source=frozen,overlaySha256=digest(out/'GpuAllocator.cpp'),headerSha256=digest(out/'private_publication.hpp'),executableSha256=digest(out/'AzurePlayer.exe')),indent=2))
