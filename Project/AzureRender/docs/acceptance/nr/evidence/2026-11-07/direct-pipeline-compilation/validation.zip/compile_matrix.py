from pathlib import Path
import json, subprocess, sys, hashlib, time
root = Path.cwd()
out = Path(__file__).resolve().parent
sys.path.insert(0, str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs, digest
assert check(root/'build',run=out,planned=8*1024**2,diagnostic=True)['allowed']
source = inputs(root)
vertex = root/'build/ninja-msvc-release/shaders/mesh_object_compute.vert.spv'
fragment = root/'build/ninja-msvc-release/shaders/mesh_object_bindless_clipmap_field_early.frag.spv'
tool = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
cases = {
    'base': [],
    'standard-O': None,
    'ssa': ['--ssa-rewrite'],
    'scalar-ssa': ['--scalar-replacement=100','--ssa-rewrite','--eliminate-dead-code-aggressive'],
    'control-flow': ['--eliminate-dead-branches','--merge-blocks','--cfg-cleanup'],
    'loads': ['--combine-access-chains','--redundancy-elimination','--reduce-load-size'],
    'conservative': ['--eliminate-dead-functions','--scalar-replacement=100','--ssa-rewrite','--ccp','--eliminate-dead-branches','--eliminate-dead-code-aggressive','--simplify-instructions','--merge-blocks','--cfg-cleanup'],
}
result = dict(scope='Compilation-only private pipeline fixture; no queue submissions or timing counters',rows=[],probeSha256=digest(out/'probe.exe'),probeSourceSha256=digest(out/'probe.cpp'),sourceInputs=source,vertexSha256=digest(vertex),fragmentSha256=digest(fragment))
for name, passes in cases.items():
    candidate = fragment if name=='base' else out/'optimized.frag.spv' if passes is None else out/(name+'.frag.spv')
    if passes:
        command = [str(tool/'spirv-opt.exe'),str(fragment),*passes,'-o',str(candidate)]
        p = subprocess.run(command,capture_output=True,text=True,timeout=60)
        assert p.returncode==0,p.stderr
    validate = subprocess.run([str(tool/'spirv-val.exe'),'--target-env','vulkan1.0',str(candidate)],capture_output=True,text=True,timeout=30)
    assert validate.returncode==0,validate.stderr
    command = [str(out/'probe.exe'),str(vertex),str(candidate),str(out/(name+'.json'))]
    start = time.monotonic()
    with (out/(name+'.stdout')).open('wb') as stdout, (out/(name+'.stderr')).open('wb') as stderr:
        p = subprocess.run(command,stdout=stdout,stderr=stderr,timeout=60)
    assert p.returncode==0,(name,p.returncode,(out/(name+'.stderr')).read_text()[:2000])
    report = json.loads((out/(name+'.json')).read_text())
    assert report['queueSubmissions']==0 and not report['validationErrors']
    assert not (out/(name+'.stderr')).stat().st_size, name+' validation warning'
    fs = [e for e in report['executables'] if e['stage']==16]
    assert len(fs)==1
    metrics = {s['name']:s['value'] for s in fs[0]['statistics']}
    row = dict(name=name,passes=passes,inputSha256=digest(candidate),spirvBytes=candidate.stat().st_size,registers=metrics['Register Count'],binaryBytes=metrics['Binary Size'],internalRepresentations=len(fs[0]['representations']),seconds=time.monotonic()-start)
    result['rows'].append(row)
    (out/'matrix.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(row),flush=True)
assert inputs(root)==source
print('PASS: all private compilation fixtures validated; production unchanged',flush=True)
