from pathlib import Path
import json, subprocess, hashlib, sys
root=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from artifact_budget import check
assert check(root/'build',run=out,planned=2*1024**2,diagnostic=True)['allowed']
before=inputs(root)
source=(root/'shaders/mesh.frag').read_text(encoding='utf-8')
old='''    vec3 lightDirection = showcasePreset == 1.0
        ? normalize(vec3(0.62, 0.68, 0.38))
        : normalize(vec3(0.48, 0.82, 0.32));
    if (camera.mainLightDirection.w > 0.5) lightDirection = camera.mainLightDirection.xyz;
    vec3 sceneShadowDirection=lightDirection;'''
early='''    vec3 sceneShadowDirection = showcasePreset == 1.0
        ? normalize(vec3(0.62, 0.68, 0.38))
        : normalize(vec3(0.48, 0.82, 0.32));
    if (camera.mainLightDirection.w > 0.5) sceneShadowDirection = camera.mainLightDirection.xyz;
    float earlyCascadeShadowVisibility=1.0;
#if defined(AZURE_EXTENDED_MATERIAL_LIGHTING)
    bool earlyObjectMainShadow=materialSurfaceProfiles.profiles[material.materialPadding>>1U].rows[21].w>.5;
#else
    const bool earlyObjectMainShadow=false;
#endif
    if(azureOrdinaryOpaque&&!earlyObjectMainShadow)
        earlyCascadeShadowVisibility=sampleShadowMap(max(dot(geometricNormal,sceneShadowDirection),0.0));
'''
assert source.count(old)==1
candidate=source.replace(old,'    vec3 lightDirection=sceneShadowDirection;')
anchor='    vec3 tangent = normalize(\n'
assert candidate.count(anchor)==1
candidate=candidate.replace(anchor,early+anchor)
old_call='sampleShadowMap(max(dot(geometricNormal, sceneShadowDirection),0.0))'
assert candidate.count(old_call)==2
candidate=candidate.replace(old_call,'(azureOrdinaryOpaque?earlyCascadeShadowVisibility:sampleShadowMap(max(dot(geometricNormal, sceneShadowDirection),0.0)))')
(out/'early-shadow.frag').write_text(candidate,encoding='utf-8')
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
defines=['-DAZURE_ORDINARY_EARLY_DEPTH=1','-DAZURE_PROBE_FIELD=1','-DAZURE_IRRADIANCE_CLIPMAP=1','-DAZURE_OBJECT_SHADOW=1','-DAZURE_BINDLESS=1']
rows=[]
for name,path in [('original-compile',root/'shaders/mesh.frag'),('early-shadow',out/'early-shadow.frag')]:
    command=[str(sdk/'glslc.exe'),*defines,'-I'+str(root/'shaders'),str(path),'-o',str(out/(name+'.spv'))]
    p=subprocess.run(command,capture_output=True,text=True,timeout=60)
    (out/(name+'-compile.log')).write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stderr
    p=subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/(name+'.spv'))],capture_output=True,text=True,timeout=30);assert p.returncode==0,p.stderr
    if name=='original-compile':assert digest(out/(name+'.spv'))==digest(root/'build/ninja-msvc-release/shaders/mesh_object_bindless_clipmap_field_early.frag.spv')
    with (out/(name+'-probe.stdout')).open('wb') as stdout,(out/(name+'-probe.stderr')).open('wb') as stderr:
        p=subprocess.run([str(out/'probe.exe'),str(root/'build/ninja-msvc-release/shaders/mesh_object_compute.vert.spv'),str(out/(name+'.spv')),str(out/(name+'-report.json'))],stdout=stdout,stderr=stderr,timeout=60)
    assert p.returncode==0,(out/(name+'-probe.stderr')).read_text()
    report=json.loads((out/(name+'-report.json')).read_text());assert not report['validationErrors']
    fs=next(e for e in report['executables'] if e['stage']==16)
    row=dict(name=name,command=command,sha256=digest(out/(name+'.spv')),statistics=fs['statistics'],internalRepresentations=len(fs['representations']))
    rows.append(row);print(name,{s['name']:s['value'] for s in fs['statistics']},flush=True)
assert inputs(root)==before
(out/'early-shadow-results.json').write_text(json.dumps(dict(rows=rows,productionUnchanged=True,queueSubmissions=0),indent=2)+'\n',encoding='utf-8')
