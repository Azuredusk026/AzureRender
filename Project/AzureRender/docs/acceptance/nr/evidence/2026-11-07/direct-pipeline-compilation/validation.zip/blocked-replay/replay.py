from pathlib import Path
import renderdoc as rd
import sys,json,hashlib,traceback,collections,time
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-181416-residency-replay-idle-dd800b'
profile=json.loads((root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/profile.json').read_text())
states={name:json.loads((root/'build/runs'/folder/'state.json').read_text()) for name,folder in [('host','20261107-120731-uniform-texture-index-capture-4c96ea'),('local','20261107-145514-mapped-buffer-capture-e067af')]}
selected=[14996,21311,23091,25069];ordinals=[next(i for i,r in enumerate(profile['rows']) if r['event']==e) for e in selected]
result=dict(status='starting',captures=states,rounds=[],scope='Cross-capture descriptive diagnosis; captured executables and query commands differ; no causal frame-benefit or native acceptance claim')
def save():(out/'replay-state.json').write_text(json.dumps(result,indent=2))
def fields(o):return {str(o.GetChild(i).name):o.GetChild(i) for i in range(o.NumChildren())}
def rid(o):return str(o.AsResourceId())
def walk(items):
    for a in items:
        if a.flags&rd.ActionFlags.Drawcall and not a.children:yield a
        yield from walk(a.children)
cap=None;c=None
try:
 for index,name in enumerate(['host','local','host']):
    state=states[name];cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
    status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
    actions=list(walk(c.GetRootActions()));assert len(actions)==len(profile['rows'])==3394
    row=dict(name=name,index=index,draws=len(actions),outputs=[],warmup=[],samples=[]);result['rounds'].append(row);save()
    # Direct reflection validates every recorded graphics pipeline without replaying each draw.
    expected={v['sha256'] for v in profile['shaders'].values()};seen=set();pipelineCount=0
    for ch in c.GetStructuredFile().chunks:
        if str(ch.name)!='vkCreateGraphicsPipelines':continue
        f=fields(ch);info=fields(f['CreateInfo']);pipelineCount+=1
        for j in range(info['pStages'].NumChildren()):
            stage=fields(info['pStages'].GetChild(j))
            if int(stage['stage'].data.basic.u)!=16:continue
            entry=rd.ShaderEntryPoint();entry.name='main';entry.stage=rd.ShaderStage.Pixel
            reflection=c.GetShader(f['Pipeline'].AsResourceId(),stage['module'].AsResourceId(),entry)
            sha=hashlib.sha256(bytes(reflection.rawBytes)).hexdigest();assert sha in expected;seen.add(sha)
    assert seen==expected
    row.update(fragmentPrograms=len(seen),graphicsPipelines=pipelineCount)
    if index<2:
        for ordinal in ordinals:
            event=int(actions[ordinal].eventId);c.SetFrameEvent(event,True)
            for slot,target in enumerate(c.GetPipelineState().GetOutputTargets()):
                if target.resource==rd.ResourceId.Null():continue
                data=bytes(c.GetTextureData(target.resource,rd.Subresource()))
                row['outputs'].append(dict(drawOrdinal=ordinal,event=event,slot=slot,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        save()
    def sweep():
        values={int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
        groups=collections.defaultdict(float)
        for action,old in zip(actions,profile['rows']):groups[old['program'] or 'depth-only']+=values.get(int(action.eventId),0)
        return dict(allEventsMs=sum(values.values()),drawMs=sum(groups.values()),groups=dict(groups))
    for attempt in range(8):
        current=sweep();row['warmup'].append(current);save()
        recent=[v['drawMs'] for v in row['warmup'][-3:]]
        if len(recent)==3 and max(recent)/min(recent)<=1.03:break
    else:raise RuntimeError('Draw timing did not stabilize within eight continuous sweeps')
    for unused in range(3):row['samples'].append(sweep());save()
    c.Shutdown();c=None;cap.Shutdown();cap=None
 result['outputsEqual']={ (r['drawOrdinal'],r['slot']):(r['bytes'],r['sha256']) for r in result['rounds'][0]['outputs']}=={(r['drawOrdinal'],r['slot']):(r['bytes'],r['sha256']) for r in result['rounds'][1]['outputs']}
 result['status']='measured';save()
except Exception:result.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if result['status']=='measured' else 1)
