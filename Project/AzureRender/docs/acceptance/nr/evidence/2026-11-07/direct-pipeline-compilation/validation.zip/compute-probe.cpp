#include <vulkan/vulkan.h>
#include <nlohmann/json.hpp>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using nlohmann::json;
void check(VkResult result,const char* operation){if(result!=VK_SUCCESS)throw std::runtime_error(std::string(operation)+": "+std::to_string(result));}
int main(int argc,char** argv)try{
    if(argc!=3)throw std::runtime_error("Expected SPIR-V input and output report");
    VkApplicationInfo application{VK_STRUCTURE_TYPE_APPLICATION_INFO};application.apiVersion=VK_API_VERSION_1_3;
    VkInstanceCreateInfo instanceInfo{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};instanceInfo.pApplicationInfo=&application;
    VkInstance instance{};check(vkCreateInstance(&instanceInfo,nullptr,&instance),"create instance");
    std::uint32_t count=0;check(vkEnumeratePhysicalDevices(instance,&count,nullptr),"enumerate devices");
    std::vector<VkPhysicalDevice> devices(count);check(vkEnumeratePhysicalDevices(instance,&count,devices.data()),"get devices");
    VkPhysicalDevice physical{};VkPhysicalDeviceProperties properties{};
    for(auto candidate:devices){vkGetPhysicalDeviceProperties(candidate,&properties);if(properties.vendorID==0x10de){physical=candidate;break;}}
    if(!physical)throw std::runtime_error("No NVIDIA device");
    check(vkEnumerateDeviceExtensionProperties(physical,nullptr,&count,nullptr),"enumerate extensions");
    std::vector<VkExtensionProperties> extensions(count);check(vkEnumerateDeviceExtensionProperties(physical,nullptr,&count,extensions.data()),"get extensions");
    bool available=std::any_of(extensions.begin(),extensions.end(),[](const auto& e){return std::string(e.extensionName)==VK_KHR_PIPELINE_EXECUTABLE_PROPERTIES_EXTENSION_NAME;});
    if(!available)throw std::runtime_error("Executable properties extension unavailable");
    VkPhysicalDevicePipelineExecutablePropertiesFeaturesKHR executableFeature{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PIPELINE_EXECUTABLE_PROPERTIES_FEATURES_KHR};
    VkPhysicalDeviceFeatures2 features{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};features.pNext=&executableFeature;vkGetPhysicalDeviceFeatures2(physical,&features);
    if(!executableFeature.pipelineExecutableInfo)throw std::runtime_error("Executable feature unavailable");
    vkGetPhysicalDeviceQueueFamilyProperties(physical,&count,nullptr);std::vector<VkQueueFamilyProperties> families(count);vkGetPhysicalDeviceQueueFamilyProperties(physical,&count,families.data());
    auto family=std::find_if(families.begin(),families.end(),[](auto& q){return (q.queueFlags&VK_QUEUE_COMPUTE_BIT)!=0;});
    if(family==families.end())throw std::runtime_error("Compute queue unavailable");
    float priority=1;VkDeviceQueueCreateInfo queue{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};queue.queueFamilyIndex=static_cast<unsigned>(family-families.begin());queue.queueCount=1;queue.pQueuePriorities=&priority;
    const char* extension=VK_KHR_PIPELINE_EXECUTABLE_PROPERTIES_EXTENSION_NAME;
    VkDeviceCreateInfo deviceInfo{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};deviceInfo.pNext=&executableFeature;deviceInfo.queueCreateInfoCount=1;deviceInfo.pQueueCreateInfos=&queue;deviceInfo.enabledExtensionCount=1;deviceInfo.ppEnabledExtensionNames=&extension;deviceInfo.pEnabledFeatures=&features.features;
    VkDevice device{};check(vkCreateDevice(physical,&deviceInfo,nullptr,&device),"create device");
    auto queryProperties=reinterpret_cast<PFN_vkGetPipelineExecutablePropertiesKHR>(vkGetDeviceProcAddr(device,"vkGetPipelineExecutablePropertiesKHR"));
    auto queryStatistics=reinterpret_cast<PFN_vkGetPipelineExecutableStatisticsKHR>(vkGetDeviceProcAddr(device,"vkGetPipelineExecutableStatisticsKHR"));
    auto queryRepresentations=reinterpret_cast<PFN_vkGetPipelineExecutableInternalRepresentationsKHR>(vkGetDeviceProcAddr(device,"vkGetPipelineExecutableInternalRepresentationsKHR"));
    if(!queryProperties||!queryStatistics||!queryRepresentations)throw std::runtime_error("Required executable query missing");
    VkDescriptorSetLayoutBinding bindings[2]={{0,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_COMPUTE_BIT,nullptr},{1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT,nullptr}};
    VkDescriptorSetLayoutCreateInfo setInfo{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};setInfo.bindingCount=2;setInfo.pBindings=bindings;
    VkDescriptorSetLayout set{};check(vkCreateDescriptorSetLayout(device,&setInfo,nullptr,&set),"create descriptor layout");
    VkPipelineLayoutCreateInfo layoutInfo{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};layoutInfo.setLayoutCount=1;layoutInfo.pSetLayouts=&set;
    VkPipelineLayout layout{};check(vkCreatePipelineLayout(device,&layoutInfo,nullptr,&layout),"create pipeline layout");
    std::ifstream input(argv[1],std::ios::binary|std::ios::ate);if(!input)throw std::runtime_error("Input open failed");auto size=input.tellg();if(size<=0||size>4*1024*1024||size%4)throw std::runtime_error("Invalid SPIR-V size");
    input.seekg(0);std::vector<std::uint32_t> words(static_cast<std::size_t>(size)/4);if(!input.read(reinterpret_cast<char*>(words.data()),size))throw std::runtime_error("Input read failed");
    VkShaderModuleCreateInfo moduleInfo{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};moduleInfo.codeSize=static_cast<std::size_t>(size);moduleInfo.pCode=words.data();
    VkShaderModule shader{};check(vkCreateShaderModule(device,&moduleInfo,nullptr,&shader),"create shader");
    VkComputePipelineCreateInfo pipelineInfo{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};pipelineInfo.layout=layout;pipelineInfo.flags=VK_PIPELINE_CREATE_CAPTURE_STATISTICS_BIT_KHR|VK_PIPELINE_CREATE_CAPTURE_INTERNAL_REPRESENTATIONS_BIT_KHR;pipelineInfo.stage={VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};pipelineInfo.stage.stage=VK_SHADER_STAGE_COMPUTE_BIT;pipelineInfo.stage.module=shader;pipelineInfo.stage.pName="main";
    VkPipeline pipeline{};check(vkCreateComputePipelines(device,VK_NULL_HANDLE,1,&pipelineInfo,nullptr,&pipeline),"create pipeline");
    VkPipelineInfoKHR info{VK_STRUCTURE_TYPE_PIPELINE_INFO_KHR};info.pipeline=pipeline;check(queryProperties(device,&info,&count,nullptr),"enumerate executables");if(count>32)throw std::runtime_error("Executable count exceeds budget");
    std::vector<VkPipelineExecutablePropertiesKHR> executables(count);for(auto& e:executables)e.sType=VK_STRUCTURE_TYPE_PIPELINE_EXECUTABLE_PROPERTIES_KHR;check(queryProperties(device,&info,&count,executables.data()),"query executables");
    json report={{"device",properties.deviceName},{"driverVersion",properties.driverVersion},{"creationFlags",pipelineInfo.flags},{"queueSubmissions",0},{"pipelineInput",argv[1]},{"executables",json::array()}};
    for(unsigned index=0;index<count;++index){
        const auto& e=executables[index];VkPipelineExecutableInfoKHR executable{VK_STRUCTURE_TYPE_PIPELINE_EXECUTABLE_INFO_KHR};executable.pipeline=pipeline;executable.executableIndex=index;
        std::uint32_t n=0;check(queryStatistics(device,&executable,&n,nullptr),"enumerate statistics");if(n>64)throw std::runtime_error("Statistic count exceeds budget");
        std::vector<VkPipelineExecutableStatisticKHR> statistics(n);for(auto& s:statistics)s.sType=VK_STRUCTURE_TYPE_PIPELINE_EXECUTABLE_STATISTIC_KHR;check(queryStatistics(device,&executable,&n,statistics.data()),"query statistics");
        json row={{"index",index},{"stage",e.stages},{"name",e.name},{"description",e.description},{"subgroupSize",e.subgroupSize},{"statistics",json::array()},{"representations",json::array()}};
        for(const auto& s:statistics){json value=nullptr;switch(s.format){case VK_PIPELINE_EXECUTABLE_STATISTIC_FORMAT_BOOL32_KHR:value=s.value.b32!=0;break;case VK_PIPELINE_EXECUTABLE_STATISTIC_FORMAT_INT64_KHR:value=s.value.i64;break;case VK_PIPELINE_EXECUTABLE_STATISTIC_FORMAT_UINT64_KHR:value=s.value.u64;break;case VK_PIPELINE_EXECUTABLE_STATISTIC_FORMAT_FLOAT64_KHR:value=s.value.f64;break;default:break;}row["statistics"].push_back({{"name",s.name},{"description",s.description},{"format",s.format},{"value",value}});}
        check(queryRepresentations(device,&executable,&n,nullptr),"enumerate representations");if(n>16)throw std::runtime_error("Representation count exceeds budget");
        if(n){std::vector<VkPipelineExecutableInternalRepresentationKHR> representations(n);for(auto& v:representations)v.sType=VK_STRUCTURE_TYPE_PIPELINE_EXECUTABLE_INTERNAL_REPRESENTATION_KHR;check(queryRepresentations(device,&executable,&n,representations.data()),"representation metadata");for(auto& v:representations)row["representations"].push_back({{"name",v.name},{"description",v.description},{"text",v.isText!=0},{"bytes",v.dataSize}});}
        report["executables"].push_back(row);
    }
    vkDestroyPipeline(device,pipeline,nullptr);vkDestroyShaderModule(device,shader,nullptr);vkDestroyPipelineLayout(device,layout,nullptr);vkDestroyDescriptorSetLayout(device,set,nullptr);vkDestroyDevice(device,nullptr);vkDestroyInstance(instance,nullptr);
    std::ofstream output(argv[2]);output<<report.dump(2)<<'\n';if(!output)throw std::runtime_error("Report write failed");std::cout<<report.dump()<<'\n';return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
