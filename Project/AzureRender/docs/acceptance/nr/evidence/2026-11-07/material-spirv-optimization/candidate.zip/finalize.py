from pathlib import Path
import json,sys,zipfile,hashlib,subprocess
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from build_provenance import verify,digest
comparison=json.loads((out/'comparison.json').read_text());assert comparison['status']=='compared' and len(comparison['comparisons'])==9
base=json.loads((root/'build/runs/20261107-113035-computed-material-view-490b2c/baseline-products.json').read_text())
checks={}
for config in ['release','debug']:
 build=root/('build/ninja-msvc-'+config);verify(root,json.loads((build/'build-provenance.json').read_text()));programs={p.name:digest(p) for p in (build/'shaders').glob('*.spv')};assert programs==base['programs'];checks[config]=dict(provenanceVerified=True,originalProgramCount=len(programs),allProgramsByteIdentical=True)
rows=json.loads((out/'candidate-build.json').read_text());before=sum(r['before']['instructions'] for r in rows);after=sum(r['after']['instructions'] for r in rows)
evidence=root/'docs/acceptance/nr/evidence/2026-11-07/material-spirv-optimization';evidence.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(evidence/'candidate.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.iterdir():
  if p.is_file():z.write(p,p.name)
archive=evidence/'candidate.zip';result=dict(schemaVersion=1,status='functional-readbacks-equal-shutdown-timeout',sourceBase='2f0aa85',programCount=11,baselineInstructions=before,candidateInstructions=after,instructionReductionFraction=1-after/before,allNineTargetsEqual=comparison['allTargetsEqual'],replayProcessExitQualified=False,replayShutdownTimeoutSeconds=240,gpuCountersCollected=False,performanceBenefitQualified=False,nativeFourFrameQualified=False,production=checks,nextTrigger='AC power restored; first resolve or isolate replay teardown before timing qualification',archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=digest(archive)))
(evidence/'results.json').write_text(json.dumps(result,indent=2));(out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
