from pathlib import Path
import json,hashlib,sys,traceback
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-133026-material-spirv-optimization-4b47ef';capture=root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea';profile=json.loads((root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/profile.json').read_text());state=json.loads((capture/'state.json').read_text());report=dict(status='starting',scope='Functional readback only; no GPU counters or performance conclusions',captureSha256=state['captureSha256']);cap=None;c=None
def save():(out/'comparison.json').write_text(json.dumps(report,indent=2))
try:
 save();cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 files={r['file'] for r in json.loads((out/'candidate-build.json').read_text())};compiled=[]
 for key,entry in profile['shaders'].items():
  if entry['programFile'] not in files:continue
  event=next(r['event'] for r in profile['rows'] if r['fragment']==key);c.SetFrameEvent(event,True);pipe=c.GetPipelineState();reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel);assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==entry['sha256']
  program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/entry['programFile']).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert program!=rd.ResourceId.Null(),errors
  compiled.append((pipe.GetShader(rd.ShaderStage.Pixel),program))
 assert len(compiled)==11
 controls={};selected=[14996,21311,23091,25069]
 for event in selected:
  c.SetFrameEvent(event,True)
  for index,target in enumerate(c.GetPipelineState().GetOutputTargets()):
   if target.resource!=rd.ResourceId.Null():controls[(event,index)]=(target.resource,bytes(c.GetTextureData(target.resource,rd.Subresource())))
 report.update(status='baseline-read',controlEvents=selected,modules=len(compiled));save()
 for shader,program in compiled:c.ReplaceResource(shader,program)
 comparisons=[]
 for (event,index),(resource,data) in controls.items():
  c.SetFrameEvent(event,True);value=bytes(c.GetTextureData(resource,rd.Subresource()));comparisons.append(dict(event=event,target=index,bytes=len(data),equal=value==data,changedBytes=sum(a!=b for a,b in zip(data,value)),baselineSha256=hashlib.sha256(data).hexdigest(),candidateSha256=hashlib.sha256(value).hexdigest()))
 for shader,program in compiled:c.RemoveReplacement(shader)
 report.update(status='compared',comparisons=comparisons,allTargetsEqual=all(r['equal'] for r in comparisons));save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
