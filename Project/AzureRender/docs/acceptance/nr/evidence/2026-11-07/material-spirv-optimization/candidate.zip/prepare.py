from pathlib import Path
import json, subprocess, struct, hashlib, sys, collections
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
assert check(root/'build',run=out,planned=24*1024**2,diagnostic=True)['allowed']
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
files=[r['file'] for r in json.loads((root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/candidate-build.json').read_text())]
def stats(data):
 w=struct.unpack('<%dI'%(len(data)//4),data);i=5;ops=collections.Counter();spec=[];precise=0
 while i<len(w):
  n=w[i]>>16;op=w[i]&65535;assert n>0
  ops[op]+=1
  if op==71 and w[i+2]==1:spec.append(w[i+3])
  if op==71 and w[i+2]==42:precise+=1
  i+=n
 return dict(bytes=len(data),instructions=sum(ops.values()),specIds=sorted(spec),noContraction=precise,opcodes=dict(ops))
rows=[]
for file in files:
 src=root/'build/ninja-msvc-release/shaders'/file;dst=out/file
 command=[str(sdk/'spirv-opt.exe'),'-O','--preserve-bindings','--preserve-spec-constants',str(src),'-o',str(dst)]
 p=subprocess.run(command,capture_output=True,text=True);assert p.returncode==0,p.stderr
 v=subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(dst)],capture_output=True,text=True);assert v.returncode==0,v.stderr
 a=src.read_bytes();b=dst.read_bytes();before=stats(a);after=stats(b);assert before['specIds']==after['specIds']
 rows.append(dict(file=file,command=command,baselineSha256=hashlib.sha256(a).hexdigest(),candidateSha256=hashlib.sha256(b).hexdigest(),before=before,after=after,validation=v.returncode))
(out/'candidate-build.json').write_text(json.dumps(rows,indent=2))
print(json.dumps([dict(file=r['file'],before=r['before']['instructions'],after=r['after']['instructions'],specIds=r['after']['specIds'],noContraction=[r['before']['noContraction'],r['after']['noContraction']]) for r in rows],indent=2))
