from pathlib import Path
import subprocess,sys,json,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from artifact_budget import check
assert check(root/'build',run=out,planned=8*1024**2,diagnostic=True)['allowed']
frozen=inputs(root);products={str(p):digest(p) for p in [root/'build/ninja-msvc-release/AzurePlayer.exe',*sorted((root/'build/ninja-msvc-release/shaders').glob('*.spv'))]};si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'compare.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=240)
unchanged=inputs(root)==frozen and all(digest(Path(path))==value for path,value in products.items());result=json.loads((out/'comparison.json').read_text());assert p.returncode==0 and result['status']=='compared' and unchanged,result
(out/'functional-check.json').write_text(json.dumps(dict(status='checked',sourcesAndProductsUnchanged=unchanged,gpuCountersCollected=False,executionSeconds=time.monotonic()-start,allTargetsEqual=result['allTargetsEqual']),indent=2))
print(json.dumps(result),flush=True)
