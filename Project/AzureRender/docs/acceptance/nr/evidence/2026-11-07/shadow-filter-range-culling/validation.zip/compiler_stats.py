from pathlib import Path
import subprocess,json,sys,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
assert check(root/'build',run=out,planned=1024**2)['allowed']
source=inputs(root);probe=root/'build/runs/20261107-181940-direct-pipeline-executables-144edf/probe.exe'
vertex=root/'build/ninja-msvc-release/shaders/mesh_object_compute.vert.spv';name='mesh_object_bindless_clipmap_field_early.frag.spv'
rows=[]
for label,fragment in [('baseline',root/'build/ninja-msvc-release/shaders'/name),('candidate',out/'candidate'/name)]:
 command=[str(probe),str(vertex),str(fragment),str(out/(label+'-compiler.json'))]
 start=time.monotonic()
 with (out/(label+'-compiler.stdout')).open('wb') as stdout,(out/(label+'-compiler.stderr')).open('wb') as stderr:
  result=subprocess.run(command,cwd=root,stdout=stdout,stderr=stderr,timeout=60)
 assert result.returncode==0
 report=json.loads((out/(label+'-compiler.json')).read_text());assert report['queueSubmissions']==0 and not report['validationErrors']
 fs=[e for e in report['executables'] if e['stage']==16];assert len(fs)==1
 metrics={s['name']:s['value'] for s in fs[0]['statistics']}
 row=dict(mode=label,command=command,probeSha256=digest(probe),fragmentSha256=digest(fragment),registers=metrics['Register Count'],binaryBytes=metrics['Binary Size'],localMemoryRaw=metrics['Local Memory Size'],seconds=time.monotonic()-start,queueSubmissions=0,validationErrors=report['validationErrors'])
 rows.append(row);print(json.dumps(row),flush=True)
assert inputs(root)==source
(out/'compiler-summary.json').write_text(json.dumps(dict(status='queried',rows=rows,scope='Private pipeline compilation only; local-memory raw high bits remain uninterpreted; actual occupancy/stalls are not measured.',productionSourceUnchanged=True),indent=2))
