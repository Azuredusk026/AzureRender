from pathlib import Path
import json,subprocess,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;folder=out/'candidate';folder.mkdir(exist_ok=True)
sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
assert check(root/'build',run=out,planned=16*1024**2)['allowed']
source=inputs(root);s=(root/'shaders/mesh.frag').read_text()
needle='    for(int y=-bound;y<=bound;y+=2)for(int x=-bound;x<=bound;x+=2){'
assert s.count(needle)==1
s=s.replace(needle,'    int azCachedIndex=-1;vec2 azCachedRange=vec2(0);\n'+needle,1)
needle='        vec4 depths=shadowTexelQuad(mainShadowDepth,sharedDepthSampler,base+ivec2(x,y),lo,hi);\n        visible+=dot(weights,step(planeDepths,depths));'
assert s.count(needle)==1
s=s.replace(needle,'''        vec4 azCompared;bool azKnown=false;
        ivec2 azFirst=clamp(base+ivec2(x,y),lo,hi)/8;
        ivec2 azLast=clamp(base+ivec2(x+1,y+1),lo,hi)/8;
        if(all(equal(azFirst,azLast))&&!any(isnan(planeDepths))&&!any(isinf(planeDepths))){
            int azIndex=azFirst.y*(extent.x/8)+azFirst.x;
            if(azCachedIndex!=azIndex){azCachedRange=shadowBounds.values[azIndex];azCachedIndex=azIndex;}
            if(max(max(planeDepths.x,planeDepths.y),max(planeDepths.z,planeDepths.w))<=azCachedRange.x){azCompared=vec4(1);azKnown=true;}
            else if(min(min(planeDepths.x,planeDepths.y),min(planeDepths.z,planeDepths.w))>azCachedRange.y){azCompared=vec4(0);azKnown=true;}
        }
        if(!azKnown){
            vec4 depths=shadowTexelQuad(mainShadowDepth,sharedDepthSampler,base+ivec2(x,y),lo,hi);
            azCompared=step(planeDepths,depths);
        }
        visible+=dot(weights,azCompared);''',1)
(folder/'mesh.frag').write_text(s)
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());programs={p['output']:p for p in manifest['programs']}
old=root/'build/runs/20261107-140503-shadow-filter-loop-8fc25c'
rows=[]
for oldrow in json.loads((old/'candidate-build.json').read_text()):
 name=oldrow['file'];p=programs[name]
 command=[manifest['compiler'],*[f'-D{d}' for d in p['defines']],f'-I{folder}',f'-I{root/"shaders"}',str(folder/'mesh.frag'),'-o',str(folder/name)]
 r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr
 v=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe',str(folder/name)],capture_output=True,text=True);assert v.returncode==0,v.stderr
 rows.append(dict(file=name,command=command,baselineSha256=digest(root/'build/ninja-msvc-release/shaders'/name),candidateSha256=digest(folder/name)))
(folder/'candidate-build.json').write_text(json.dumps(rows,indent=2))
compare=(old/'compare.py').read_text();needle="out=root/'build/runs/"+old.name+"'";assert compare.count(needle)==1;compare=compare.replace(needle,"out=Path('"+folder.as_posix()+"')",1);assert old.name not in compare
compare=compare.replace('Exact interior gathers, conservative zero-quad rejection and delayed receiver plane work; original bounds retained.','Exact same-8x8-tile filter comparison classification with adjacent-query bound reuse; original weights and summation order retained.')
# Persist boundaries before potentially slow driver calls.
compare=compare.replace(' for shader,program in compiled.values():c.ReplaceResource(shader,program)'," report['status']='replacing';save()\n for shader,program in compiled.values():c.ReplaceResource(shader,program)")
(folder/'compare.py').write_text(compare)
runner=(old/'run_compare.py').read_text().replace('root=out.parents[2]','root=out.parents[3]').replace('run=out,planned=16*1024**2,diagnostic=True','run=out.parent,planned=16*1024**2')
(folder/'run_compare.py').write_text(runner)
assert source==inputs(root)
print(json.dumps(dict(status='prepared',programs=len(rows),sourceUnchanged=True)),flush=True)
