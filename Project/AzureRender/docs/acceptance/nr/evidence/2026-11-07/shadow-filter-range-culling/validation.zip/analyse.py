from pathlib import Path
import json,zlib,hashlib,sys
import numpy as np
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
receipt=json.loads((out/'inspection.json').read_text());assert receipt['status']=='inspected'
raw=zlib.decompress((out/'counts.bin.zlib').read_bytes());assert hashlib.sha256(raw).hexdigest()==receipt['counts']['sha256']
assert len(raw)==1280*720*8
values=np.frombuffer(raw,dtype='<f2').reshape(-1,4)
assert np.isfinite(values).all() and (values>=0).all() and np.equal(values,np.floor(values)).all()
assert (values[:,1]<=values[:,0]).all() and (values[:,2]+values[:,3]<=values[:,1]).all()
totals=values.sum(axis=0,dtype=np.float64).astype(np.int64)
assert totals[0]>0
report=dict(status='attributed',scope=receipt['scope'],visiblePixels=int(len(values)),filterPixels=int((values[:,0]>0).sum()),filterQuads=int(totals[0]),singleTileQuads=int(totals[1]),provablyLitQuads=int(totals[2]),provablyDarkQuads=int(totals[3]),potentialSavedDepthGatherFraction=float((totals[2]+totals[3])/totals[0]),coverageFraction=float(totals[1]/totals[0]),productionIntegrated=False,performanceMeasured=False,limitations=['Only four opaque snapshot programs and final visible pixels; overdraw and later main-pass pixels are outside this count.','Additional range reads, branch divergence, register pressure and cache locality must be included in actual candidate timing.','No pixel compatibility or native frame-time acceptance is claimed.'])
(out/'counts-summary.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report),flush=True)
