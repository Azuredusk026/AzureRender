from pathlib import Path
import json,subprocess,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
assert check(root/'build',run=out,planned=32*1024**2)['allowed']
(out/'source-inputs.json').write_text(json.dumps(inputs(root),indent=2))
old=root/'build/runs/20261107-195033-shadow-range-work-f9476d'
text=(root/'shaders/mesh.frag').read_text()
text=text.replace('float sampleCascadeShadow(', 'vec4 azFilterCounts=vec4(0);\nfloat sampleCascadeShadow(',1)
needle='        if(weight<=0)continue;'
assert text.count(needle)==1
text=text.replace(needle,needle+'''
        azFilterCounts.x+=1.0;
        ivec2 azFirst=clamp(base+ivec2(x,y),lo,hi)/8;
        ivec2 azLast=clamp(base+ivec2(x+1,y+1),lo,hi)/8;
        if(all(equal(azFirst,azLast))){
            azFilterCounts.y+=1.0;
            vec2 azRange=shadowBounds.values[azFirst.y*(extent.x/8)+azFirst.x];
            if(max(max(planeDepths.x,planeDepths.y),max(planeDepths.z,planeDepths.w))<=azRange.x)azFilterCounts.z+=1.0;
            if(min(min(planeDepths.x,planeDepths.y),min(planeDepths.z,planeDepths.w))>azRange.y)azFilterCounts.w+=1.0;
        }
''',1)
assert text.count('void main()')==1
text=text.replace('void main()','void azOriginalMain()',1)+'\nvoid main(){azOriginalMain();outputColor=azFilterCounts;}\n'
(out/'mesh.frag').write_text(text)
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());programs={p['output']:p for p in manifest['programs']}
rows=[]
for row in json.loads((old/'builds.json').read_text()):
 name=row['file'];p=programs[name]
 command=[manifest['compiler'],*[f'-D{d}' for d in p['defines']],f'-I{out}',f'-I{root/"shaders"}',str(out/'mesh.frag'),'-o',str(out/name)]
 r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr
 v=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe',str(out/name)],capture_output=True,text=True);assert v.returncode==0,v.stderr
 rows.append(dict(file=name,command=command,sha256=digest(out/name)))
(out/'builds.json').write_text(json.dumps(rows,indent=2))
script=(old/'capture_ranges.py').read_text().replace("root/'build/runs/20261107-195033-shadow-range-work-f9476d'",'Path(__file__).resolve().parent')
script=script.replace('Functional counts in the final visible opaque snapshot. Counts exclude overwritten/occluded fragments and do not measure GPU time.','Per-visible-pixel filter quads: total, single 8x8 bound, provably lit, provably dark. Diagnostic reads are additional work. No GPU performance claim.')
(out/'capture_counts.py').write_text(script)
print(json.dumps(dict(status='prepared',programs=len(rows),sourceUnchanged=inputs(root)==json.loads((out/'source-inputs.json').read_text()))),flush=True)
