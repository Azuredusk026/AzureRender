from pathlib import Path
import sys,json,traceback
_diag_out=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261107-221043-shadow-filter-range-culling-d81a60')
(_diag_out/'boot.json').write_text(json.dumps(dict(fileGlobalPresent='__file__' in globals(),fileGlobal=globals().get('__file__'))))
def _diag_exception(t,v,tb):
 (_diag_out/'python-error.txt').write_text(''.join(traceback.format_exception(t,v,tb)))
sys.excepthook=_diag_exception
from pathlib import Path
import renderdoc as rd
import json,sys,traceback,hashlib,zlib
root=Path('D:/Projects/FYP/Project/AzureRender');out=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261107-221043-shadow-filter-range-culling-d81a60')
prior=root/'build/runs/20261107-122133-material-contribution-cost-c567b5';profile=json.loads((prior/'profile.json').read_text())
state=json.loads((root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea/state.json').read_text())
report=dict(status='starting',scope='Per-visible-pixel filter quads: total, single 8x8 bound, provably lit, provably dark. Diagnostic reads are additional work. No GPU performance claim.',capture=state);cap=None;c=None
def checkpoint(stage):
 (out/'stage.json').write_text(json.dumps(dict(stage=stage)))
try:
 checkpoint('open-file')
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 checkpoint('open-capture')
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 checkpoint('build-targets')
 names={r['file'] for r in json.loads((out/'builds.json').read_text())}
 shaders={k:v for k,v in profile['shaders'].items() if v['programFile'] in names}
 rows=[r for r in profile['rows'] if r['fragment'] in shaders];assert rows
 report['matchedDraws']=len(rows);originals=[]
 for key,entry in shaders.items():
  event=next(r['event'] for r in rows if r['fragment']==key);c.SetFrameEvent(event,True);pipe=c.GetPipelineState()
  reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel);assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==entry['sha256']
  program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/entry['programFile']).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
  assert program!=rd.ResourceId.Null(),errors
  original=pipe.GetShader(rd.ShaderStage.Pixel);originals.append((original,program))
 checkpoint('read-baseline')
 event=max(r['event'] for r in rows);c.SetFrameEvent(event,True);pipe=c.GetPipelineState();target=pipe.GetOutputTargets()[0].resource
 texture=next(t for t in c.GetTextures() if t.resourceId==target)
 report['target']={k:str(getattr(texture,k)) for k in ['resourceId','width','height','format','byteSize']}
 report['event']=event
 original=bytes(c.GetTextureData(target,rd.Subresource()));report['originalTargetSha256']=hashlib.sha256(original).hexdigest()
 checkpoint('replace')
 for old,new in originals:c.ReplaceResource(old,new)
 checkpoint('candidate-data')
 c.SetFrameEvent(event,True)
 data=bytes(c.GetTextureData(target,rd.Subresource()));compressed=zlib.compress(data,6);assert len(compressed)<=16*1024**2
 (out/'counts.bin.zlib').write_bytes(compressed);report['counts']=dict(rawBytes=len(data),compressedBytes=len(compressed),sha256=hashlib.sha256(data).hexdigest())
 report['debugMessages']=[str(m.description) for m in c.GetDebugMessages()]
 checkpoint('restore')
 for old,new in originals:c.RemoveReplacement(old);c.FreeTargetResource(new)
 c.SetFrameEvent(event,True)
 restored=bytes(c.GetTextureData(target,rd.Subresource()));assert hashlib.sha256(restored).hexdigest()==report['originalTargetSha256']
 report.update(status='inspected',restoredTargetIdentical=True)
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 (out/'inspection.json').write_text(json.dumps(report,indent=2))
 checkpoint('shutdown')
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='inspected' else 1)
