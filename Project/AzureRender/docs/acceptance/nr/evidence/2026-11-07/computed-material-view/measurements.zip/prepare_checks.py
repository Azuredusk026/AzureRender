from pathlib import Path
r=Path.cwd();p=r/'tests/DepthPrefillRecordingTests.cpp';s=p.read_text()
s=s.replace('bool multisample){','bool multisample,bool screenNormal=false){')
s=s.replace('material.materialFeatures=features;}','material.materialFeatures=features;material.nprDiffuse.screenLightingNormal=screenNormal;}')
s=s.replace('const auto handle=call.detail.substr(0,call.detail.find(\' \'));\n            (ordinaryProgram?', 'const auto handle=call.detail.substr(0,call.detail.find(\' \'));\n            if(call.detail.find("4:1/")!=std::string::npos){allCovered.insert(handle);continue;}\n            if(mode==AssetAlphaMode::Blend){allCovered.insert(handle);continue;}\n            (ordinaryProgram?')
s=s.replace('require(ordinaryProgram||call.detail.find("fragmentSpec=1:0/2:")!=std::string::npos,','require(mode==AssetAlphaMode::Blend||ordinaryProgram||call.detail.find("fragmentSpec=1:0/2:")!=std::string::npos,')
s=s.replace('8*(generation+1):0),"Fixed-class','(screenNormal?4:8)*(generation+1):0),"Fixed-class')
s=s.replace('(!multisample&&fixedClass&&opacity==1.F),"Fixed-class submissions','(!multisample&&fixedClass&&opacity==1.F&&(!screenNormal||pass.name=="character-main")),"Fixed-class submissions')
s=s.replace('        verify(argv[1],indexed,AssetAlphaMode::Mask,MaterialFeatureGeometryShadow,1,false);','        verify(argv[1],indexed,AssetAlphaMode::Opaque,MaterialFeatureSqrtAlphaShadow,1,false,true);\n        verify(argv[1],indexed,AssetAlphaMode::Mask,MaterialFeatureGeometryShadow,1,false);')
p.write_text(s)
# Reuse the public recording fixture with dedicated mode and lifecycle assertions.
s=s.replace('std::set<std::string> prefill,covered,ordinaryCovered,classCovered,earlyModules;','std::set<std::string> prefill,covered,ordinaryCovered,classCovered,earlyModules;')
start=s.index('        unsigned checked=0;');end=s.index('    }\n    renderer.onUnload',start)
s=s[:start]+'''        for(unsigned state=0;state<8;++state){
            settings.sceneLightingEnabled=state!=1;
            settings.screenSpaceReflection.enabled=state!=2;
            settings.screenSpaceReflection.algorithm=state==6?ScreenSpaceReflectionAlgorithm::Projected:ScreenSpaceReflectionAlgorithm::Linear;
            frame.qaIsolationMode=state==3?6:0;frame.qaEffectMode=state==4?5:0;frame.qaEffectEnabled=state!=5;
            renderer.updateFrame(frame);
            std::set<std::string> specialized,allMaterial;
            for(const auto& call:backend.calls)if(call.name=="createGraphicsPipeline"&&call.detail.find("fragmentSpec=")!=std::string::npos){
                const auto handle=call.detail.substr(0,call.detail.find(' '));
                if(call.detail.find("4:1/")!=std::string::npos)specialized.insert(handle);
                allMaterial.insert(handle);
            }
            bool observed=false;
            for(const auto& pass:graph.passes())if(pass.name=="character-main"||pass.name=="character-opaque-depth"){
                rhi::NullCommandRecorder commands;pass.recordCommands(commands);std::string pipeline;
                for(const auto& call:commands.calls){
                    if(call.name=="bindPipeline")pipeline=call.detail;
                    if(call.name=="drawIndexed"&&allMaterial.count(pipeline)){
                        observed=true;
                        require((specialized.count(pipeline)!=0)==(!multisample&&(state==0||state==7)),"Computed view must follow current uniform values and recover after fallback");
                    }
                }
            }
            require(observed,"Both workflows must record material draws");
        }
''' +s[end:]
# Avoid duplicating coverage/count tests in the mode fixture.
a=s.index('        const bool ordinary=');b=s.index('        for(unsigned state=',a);s=s[:a]+s[b:]
s=s.replace('    for(const auto& handle:allCovered)require','    for(const auto& call:backend.calls)if(call.name=="createGraphicsPipeline"&&call.detail.find("4:1/")!=std::string::npos)allCovered.insert(call.detail.substr(0,call.detail.find(\' \')));\n    for(const auto& handle:allCovered)require')
s=s.replace('Depth prefill: two workflows, descriptors, opacity, alpha modes, flags, MSAA fallback and owned recreation passed','Computed material view: uniform modes, two workflows, coverage, depth and owned recreation passed')
(r/'tests/ComputedMaterialViewRecordingTests.cpp').write_text(s)
p=r/'CMakeLists.txt';t=p.read_text();marker='    add_executable(AzureDepthPrefillRecordingTests tests/DepthPrefillRecordingTests.cpp)';block='''    add_executable(AzureComputedMaterialViewRecordingTests tests/ComputedMaterialViewRecordingTests.cpp)
    target_link_libraries(AzureComputedMaterialViewRecordingTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureComputedMaterialViewRecordingTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureComputedMaterialViewRecordingTests AzureRenderShaders)
    add_test(NAME AzureRender.ComputedMaterialViewRecording COMMAND AzureComputedMaterialViewRecordingTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.ComputedMaterialViewRecording PROPERTIES TIMEOUT 120)
''';assert marker in t;p.write_text(t.replace(marker,block+marker))
p=r/'src/scenes/CharacterSceneRenderer.hpp';t=p.read_text().replace('#include <vector>','#include <vector>\n#include <unordered_map>');p.write_text(t)
print('Prepared batched coverage, mode-switch and ownership checks')
