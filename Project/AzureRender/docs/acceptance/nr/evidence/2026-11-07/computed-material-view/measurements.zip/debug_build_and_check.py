from pathlib import Path
import json,subprocess,os,time
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-debug'
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
targets=['AzureMaterialClassEarlyDepthTests','AzureComputedMaterialViewRecordingTests','AzureDepthPrefillRecordingTests','AzureMaterialPipelinePolicyTests','AzurePreviousTransformSnapshotTests','AzureSceneTransformCacheTests','AzureCameraSystemTests','AzureRuntimeSceneSnapshotCacheTests','AzureRuntimeRenderSnapshotCacheTests','AzureRuntimeLifecycleTests','AzureRenderSceneGraphTests','AzureRenderNullRhiPassTests','AzureObjectShadowRecordingTests','AzurePhysicsInputTests']
commands=[['cmd','/d','/c',str(root/'tools/msvc_env.bat'),str(root/'build/reinstall-environment/venv/Scripts/python.exe'),'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config','Debug',*[a for t in targets for a in ['--test-target',t]]],['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe','--test-dir',str(build),'-R','^(AzureEngine\\.(PreviousTransformSnapshot|RuntimeSceneSnapshotCache|RuntimeRenderSnapshotCache|RuntimeLifecycle|PhysicsInput)|AzureRender\\.(MaterialClassEarlyDepth|ComputedMaterialViewRecording|DepthPrefillRecording|MaterialPipelinePolicy|SceneTransformCache|SceneGraph|NullRhiPass|ObjectShadowRecording)|AzureRuntime\\.CameraSystem)$','--output-on-failure','--no-tests=error','--output-junit',str(out/'debug-checks.xml')]]
rows=[]
for kind,command,deadline in zip(['build','checks'],commands,[1200,240]):
 start=time.monotonic()
 with (out/('debug-'+kind+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=deadline)
 row=dict(kind=kind,exitCode=r.returncode,seconds=time.monotonic()-start,command=command);rows.append(row);(out/'debug-build-checks.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
 assert r.returncode==0,(out/('debug-'+kind+'.log')).read_text(errors='replace')[-6000:]

import xml.etree.ElementTree as ET
assert int(ET.parse(out/"debug-checks.xml").getroot().attrib["tests"])==14, "Expected all fourteen selected checks"
