from pathlib import Path
import json,sys,shutil,zipfile,re
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from build_provenance import digest
restored=json.loads((out/'restoration.json').read_text());assert restored['status']=='restored'
e=root/'docs/acceptance/nr/evidence/2026-11-07/computed-material-view';e.mkdir(parents=True,exist_ok=True)
qualification=json.loads((root/'build/runs/20261107-111830-computed-specialization-cost-b26603/qualification.json').read_text());(out/'qualification.json').write_text(json.dumps(qualification,indent=2))
image=json.loads((out/'image/results.json').read_text());control=json.loads((out/'image-dynamic-control/results.json').read_text());assert image['status']=='failed' and control['status']=='passed'
assert not (out/'performance-candidate').exists()
startup={}
for label,folder in [('candidate','image'),('dynamicControl','image-dynamic-control')]:
 log=(out/folder/'stderr.log').read_text();found=re.search(r'Scene load pipelines: ([0-9.]+) ms',log);startup[label]=dict(totalSeconds=(image if label=='candidate' else control)['seconds'],pipelineCreationMilliseconds=float(found.group(1)) if found else None)
archive=e/'measurements.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file() and not any(part in ['baseline','candidate-programs','__pycache__','.azure'] for part in p.relative_to(out).parts) and p.suffix.lower() in ['.py','.json','.log','.xml','.cpp','.hpp','.inc','.frag','.glsl','.txt']:
   z.write(p,str(p.relative_to(out)))
result=dict(schemaVersion=1,status='isolated-native-zero-pixel-failure',sourceBase='acf9826',qualification=qualification,candidateImage=image,dynamicSelectionOffControl=control,diagnosis='With unchanged original uniform inputs and retained early-depth changes, forcing specialized pipeline selection off restores all four frozen RGB images. Selection is a demonstrated cause of this compatibility failure; the exact floating-point transformation remains unconfirmed.',startup=startup,baseline=json.loads((out/'performance-baseline/results.json').read_text()),candidatePerformanceRun=False,publicGpuFixtureBatchRun=False,formalPerformanceRun=False,restoration=restored,originalCandidateChecks=json.loads((out/'build-checks.json').read_text()),originalCandidateDebugChecks=json.loads((out/'debug-build-checks.json').read_text()),restoreChecks=json.loads((out/'restore-checks.json').read_text()),required=dict(nativeRgbChangedPixels=0,cpuP95Ms=8,gpuP95Ms=16.6,formalSamples=1800,overallVisualAccepted=False),archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=digest(archive)))
(e/'results.json').write_text(json.dumps(result,indent=2));manifest=dict(schemaVersion=1,kind='NativeOptimizationEvidence',status=result['status'],sourceBase='acf9826',candidatePlayerSha256=digest(out/'candidate-player.exe'),candidateSource={str(p.relative_to(out/'candidate-source')):digest(p) for p in (out/'candidate-source').rglob('*') if p.is_file()},changedProgramCount=image['changedProgramCount'],programCount=663,results=dict(file='results.json',sha256=digest(e/'results.json')),archive=result['archive'],productionSourceRestored=True,productionProgramsRestored=True,releasePlayerCodeRestored=True,formalAcceptance=False);(e/'manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(dict(status=result['status'],startup=startup,archive=result['archive'])),flush=True)
