from pathlib import Path
import shutil
r=Path.cwd();o=r/'build/runs/20261107-113035-computed-material-view-490b2c'
for name in ['build-checks.json','release-checks.xml','release-build.log','release-checks.log','build-runner.log']:
 shutil.copy2(o/name,o/('initial-'+name))
for name in ['DepthPrefillRecordingTests.cpp','ComputedMaterialViewRecordingTests.cpp']:
 p=r/'tests'/name;s=p.read_text().replace('require(mode==AssetAlphaMode::Blend||ordinaryProgram||','const bool blendProgram=call.detail.find(" blend=1 ")!=std::string::npos;\n            require(blendProgram||ordinaryProgram||').replace('if(mode==AssetAlphaMode::Blend){allCovered.insert(handle);continue;}','if(blendProgram){allCovered.insert(handle);continue;}');p.write_text(s)
print('Classified blend-owned early-depth programs separately from opaque specializations')
