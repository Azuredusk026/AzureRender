from pathlib import Path
import json,sys,shutil,subprocess,os,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
assert json.loads((out/'image-dynamic-control/results.json').read_text())['status']=='passed'
# The failed candidate and its shaders remain reproducible outside production.
shutil.copytree(root/'build/ninja-msvc-release/shaders',out/'candidate-programs')
for p in (out/'original-source').rglob('*'):
 if p.is_file():
  target=root/p.relative_to(out/'original-source');shutil.copy2(p,target);os.utime(target,None)
p=root/'tests/ComputedMaterialViewRecordingTests.cpp';assert digest(p)==digest(out/'candidate-source/tests/ComputedMaterialViewRecordingTests.cpp');p.unlink()
base=json.loads((out/'baseline-products.json').read_text());assert inputs(root)==base['source'],'Restored source differs from frozen baseline'
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
targets=['AzureMaterialClassEarlyDepthTests','AzureDepthPrefillRecordingTests','AzureMaterialPipelinePolicyTests','AzurePreviousTransformSnapshotTests','AzureSceneTransformCacheTests','AzureCameraSystemTests','AzureRuntimeSceneSnapshotCacheTests','AzureRuntimeRenderSnapshotCacheTests','AzureRuntimeLifecycleTests','AzureRenderSceneGraphTests','AzureRenderNullRhiPassTests','AzureObjectShadowRecordingTests','AzurePhysicsInputTests'];rows=[]
cmake='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe';ctest=str(Path(cmake).with_name('ctest.exe'))
for config in ['Release','Debug']:
 build=root/('build/ninja-msvc-'+config.lower())
 jobs=[('configure',['cmd','/d','/c',str(root/'tools/msvc_env.bat'),cmake,'-S',str(root),'-B',str(build)],300),('build',['cmd','/d','/c',str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config',config,*[v for t in targets for v in ['--test-target',t]]],1200),('checks',[ctest,'--test-dir',str(build),'-R',r'^(AzureEngine\.(PreviousTransformSnapshot|RuntimeSceneSnapshotCache|RuntimeRenderSnapshotCache|RuntimeLifecycle|PhysicsInput)|AzureRender\.(MaterialClassEarlyDepth|DepthPrefillRecording|MaterialPipelinePolicy|SceneTransformCache|SceneGraph|NullRhiPass|ObjectShadowRecording)|AzureRuntime\.CameraSystem)$','--output-on-failure','--no-tests=error','--output-junit',str(out/('restored-'+config.lower()+'-checks.xml'))],300)]
 for name,command,deadline in jobs:
  start=time.monotonic()
  with (out/('restored-'+config.lower()+'-'+name+'.log')).open('wb') as log:p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=deadline)
  rows.append(dict(configuration=config,kind=name,exitCode=p.returncode,seconds=time.monotonic()-start));(out/'restore-checks.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True);assert p.returncode==0
 verify(root,json.loads((build/'build-provenance.json').read_text()))
 assert {p.name:digest(p) for p in (build/'shaders').glob('*.spv')}==base['programs']
assert inputs(root)==base['source']
# Executable code section comparison is independent of PE debug metadata.
import pefile
def code(path):
 pe=pefile.PE(str(path));return next(s.get_data() for s in pe.sections if s.Name.rstrip(b'\0')==b'.text')
result=dict(status='restored',allSourceInputsIdentical=True,releaseAll663ProgramsIdentical=True,debugAll663ProgramsIdentical=True,releasePlayerCodeIdentical=code(root/'build/ninja-msvc-release/AzurePlayer.exe')==code(out/'baseline/AzurePlayer.exe'))
assert result['releasePlayerCodeIdentical'];(out/'restoration.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
