from pathlib import Path
import shutil
r=Path.cwd();o=r/'build/runs/20261107-113035-computed-material-view-490b2c'
for name in ['build-checks.json','release-checks.xml','release-build.log','release-checks.log','build-runner.log']:shutil.copy2(o/name,o/('classification-'+name))
for name in ['DepthPrefillRecordingTests.cpp','ComputedMaterialViewRecordingTests.cpp']:
 p=r/'tests'/name;s=p.read_text().replace('material.nprDiffuse.screenLightingNormal=screenNormal;}','material.nprDiffuse.screenLightingNormal=screenNormal;if(screenNormal){material.materialProfileVersion=2;material.nprDiffuse.present=true;material.materialFeatures|=MaterialFeatureNprDiffuse;}}')
 # The snapshot intentionally omits screen-normal color and prefill.
 s=s.replace('(mode==AssetAlphaMode::Opaque&&opacity>0),"Both workflows','(mode==AssetAlphaMode::Opaque&&opacity>0&&(!screenNormal||pass.name=="character-main")),"Both workflows')
 if name.startswith('Computed'):s=s.replace('context.cullingEnabled=false;','context.cullingEnabled=false;context.computeShaders=true;')
 p.write_text(s)
p=r/'tests/MaterialClassEarlyDepthTests.cpp';shutil.copy2(p,o/'original-source/tests/MaterialClassEarlyDepthTests.cpp');s=p.read_text()
s=s.replace('const bool ordinary=mode==AssetAlphaMode::Opaque&&!screenNormal;','const bool ordinary=mode==AssetAlphaMode::Opaque;')
s=s.replace('8*(generation+1):0),"Covered material-class','(screenNormal?4:8)*(generation+1):0),"Covered material-class')
s=s.replace('(!multisample&&ordinary&&opacity==1.F),"Both color','(!multisample&&ordinary&&opacity==1.F&&(!screenNormal||pass.name=="character-main")),"Both color')
s=s.replace('const auto handle=call.detail.substr(0,call.detail.find(\' \'));ordinaryCovered.insert(handle);allCovered.insert(handle);','const auto handle=call.detail.substr(0,call.detail.find(\' \'));allCovered.insert(handle);if(call.detail.find("4:1/")==std::string::npos)ordinaryCovered.insert(handle);')
p.write_text(s)
p=o/'build_and_check.py';s=p.read_text().replace("targets=['AzureComputed", "targets=['AzureMaterialClassEarlyDepthTests','AzureComputed").replace('ComputedMaterialViewRecording|DepthPrefillRecording','MaterialClassEarlyDepth|ComputedMaterialViewRecording|DepthPrefillRecording').replace('==13','==14').replace('all thirteen','all fourteen');p.write_text(s)
print('Aligned fixtures with compute capability and version-two screen-normal contract')
