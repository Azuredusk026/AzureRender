from pathlib import Path
import json,shutil,sys,subprocess,os,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest;from artifact_budget import check
assert check(root/'build',run=out,planned=134217728)['allowed']
base=json.loads((out/'baseline-products.json').read_text());now=inputs(root);candidate=out/'candidate-source'
for name,value in now.items():
 if base['source'].get(name)!=value:
  dst=candidate/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,dst)
for name in ['DepthPrefillRecordingTests.cpp','ComputedMaterialViewRecordingTests.cpp','MaterialClassEarlyDepthTests.cpp']:
 dst=candidate/'tests'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/'tests'/name,dst)
shutil.copy2(root/'build/ninja-msvc-release/AzurePlayer.exe',out/'candidate-player.exe');shutil.copy2(root/'build/ninja-msvc-release/build-provenance.json',out/'candidate-build-provenance.json')
p=root/'src/scenes/CharacterSceneRenderer.cpp';s=p.read_text();needle='computedMaterialViewActive_=rasterizationSamples_==VK_SAMPLE_COUNT_1_BIT';assert needle in s;p.write_text(s.replace(needle,'computedMaterialViewActive_=false&&rasterizationSamples_==VK_SAMPLE_COUNT_1_BIT'))
s=(out/'capture.py').read_text().replace("parent/'image'","parent/'image-dynamic-control'").replace("and cache_manifest['computedMaterialViewActive']","and not cache_manifest['computedMaterialViewActive']").replace("'Strict computed-view specialization and main-color early depth;","'Root-cause control: computed-view pipeline selection forced off, original uniform inputs and early-depth paths retained;")
(out/'capture_dynamic_control.py').write_text(s)
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
command=['cmd','/d','/c',str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(root/'build/ninja-msvc-release'),'--config','Release','--runtime-only'];start=time.monotonic()
with (out/'dynamic-control-build.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
print(json.dumps(dict(kind='control-build',exitCode=r.returncode,seconds=time.monotonic()-start)),flush=True);assert r.returncode==0
with (out/'dynamic-control-capture.log').open('wb') as log:r=subprocess.run([sys.executable,'-X','utf8',str(out/'capture_dynamic_control.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=1000)
print(json.dumps(dict(kind='control-capture',exitCode=r.returncode)),flush=True)
