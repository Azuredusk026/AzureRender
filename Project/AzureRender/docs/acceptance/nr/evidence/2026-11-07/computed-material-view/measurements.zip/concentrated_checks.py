from pathlib import Path
import subprocess,sys,json,time,shutil
out=Path(__file__).resolve().parent;root=out.parents[2]
s=(out/'build_and_check.py').read_text().replace('ninja-msvc-release','ninja-msvc-debug').replace("'Release'","'Debug'").replace("'release-","'debug-").replace("'build-checks.json'","'debug-build-checks.json'").replace('out/"release-checks.xml"','out/"debug-checks.xml"')
(out/'debug_build_and_check.py').write_text(s)
jobs=[('debug-build',[sys.executable,'-X','utf8',str(out/'debug_build_and_check.py')],1800),('budget',[sys.executable,'-X','utf8',str(root/'tools/artifact_budget.py'),'--run',str(out),'--planned-bytes','134217728'],60),('module-boundaries',[sys.executable,'-X','utf8',str(root/'tools/check_module_boundaries.py'),'--source',str(root),'--build-dir',str(root/'build/ninja-msvc-release')],180),('native-capture',[sys.executable,'-X','utf8',str(out/'capture.py')],1000)]
rows=[]
for name,command,deadline in jobs:
 start=time.monotonic()
 with (out/(name+'-runner.log')).open('wb') as log:p=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=deadline)
 rows.append(dict(name=name,exitCode=p.returncode,seconds=time.monotonic()-start));(out/'concentrated-checks.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
 assert p.returncode==0,(out/(name+'-runner.log')).read_text(errors='replace')[-5000:]
print('Associated Debug/Release checks and frozen native capture passed')
