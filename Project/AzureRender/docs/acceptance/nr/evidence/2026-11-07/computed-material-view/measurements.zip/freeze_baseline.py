from pathlib import Path
import sys,shutil,json,subprocess
root=Path.cwd();out=root/'build/runs/20261107-113035-computed-material-view-490b2c';sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import digest,inputs
assert check(root/'build',run=out,planned=536870912)['allowed']
base=out/'baseline';base.mkdir();shutil.copy2(root/'build/ninja-msvc-release/AzurePlayer.exe',base/'AzurePlayer.exe');shutil.copytree(root/'build/ninja-msvc-release/shaders',base/'shaders')
files=['src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','src/scenes/CharacterMaterialSampling.inc','src/render/MaterialPipelinePolicy.hpp','shaders/mesh.frag','shaders/unlit_opaque.glsl','shaders/unlit_blend.glsl','tests/DepthPrefillRecordingTests.cpp','CMakeLists.txt']
for file in files:
 dst=out/'original-source'/file;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/file,dst)
(out/'baseline-products.json').write_text(json.dumps(dict(sourceBase='acf9826',source=inputs(root),playerSha256=digest(base/'AzurePlayer.exe'),programs={p.name:digest(p) for p in (base/'shaders').glob('*.spv')}),indent=2))
for name in ['measure_baseline.py','measure_candidate.py','capture.py']:
 text=(root/'build/runs/20261107-082148-stable-frame-preparation-dcf3f3'/name).read_text().replace('aca7dfc','acf9826')
 (out/name).write_text(text)
print('Frozen player, source and 663 programs')
