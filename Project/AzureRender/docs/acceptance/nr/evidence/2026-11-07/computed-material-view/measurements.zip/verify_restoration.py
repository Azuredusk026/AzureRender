from pathlib import Path
import json,struct,sys
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
base=json.loads((out/'baseline-products.json').read_text());rows=json.loads((out/'restore-checks.json').read_text());assert len(rows)==6 and all(r['exitCode']==0 for r in rows)
def code(path):
 data=path.read_bytes();pe=struct.unpack_from('<I',data,0x3c)[0];assert data[pe:pe+4]==b'PE\0\0';sections=struct.unpack_from('<H',data,pe+6)[0];optional=struct.unpack_from('<H',data,pe+20)[0];at=pe+24+optional
 for i in range(sections):
  row=at+40*i
  if data[row:row+8].rstrip(b'\0')==b'.text':
   size,offset=struct.unpack_from('<II',data,row+16);return data[offset:offset+size]
 raise ValueError('PE .text section missing')
import hashlib,xml.etree.ElementTree as ET
result=dict(status='restored',allSourceInputsIdentical=inputs(root)==base['source'],configurations={})
for config in ['Release','Debug']:
 build=root/('build/ninja-msvc-'+config.lower());verify(root,json.loads((build/'build-provenance.json').read_text()));programs={p.name:digest(p) for p in (build/'shaders').glob('*.spv')};count=int(ET.parse(out/('restored-'+config.lower()+'-checks.xml')).getroot().attrib['tests']);assert programs==base['programs'] and count==13
 result['configurations'][config]=dict(programCount=len(programs),allProgramsByteIdentical=True,checksPassed=count,playerCodeSha256=hashlib.sha256(code(build/'AzurePlayer.exe')).hexdigest())
result['releasePlayerCodeIdentical']=code(root/'build/ninja-msvc-release/AzurePlayer.exe')==code(out/'baseline/AzurePlayer.exe');assert result['releasePlayerCodeIdentical'] and result['allSourceInputsIdentical']
(out/'restoration.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
