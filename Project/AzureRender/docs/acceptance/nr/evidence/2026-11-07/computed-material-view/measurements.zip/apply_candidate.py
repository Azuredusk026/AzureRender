from pathlib import Path
root=Path.cwd()
def edit(name,before,after):
 p=root/name;t=p.read_text();assert before in t,name+': '+before[:60];p.write_text(t.replace(before,after))
# The specialization stays a driver constant, including the dynamic default.
source=root/'shaders';private=root/'build/runs/20261107-111830-computed-specialization-cost-b26603/dynamic-source'
for name in ['mesh.frag','unlit_opaque.glsl','unlit_blend.glsl']:
 (source/name).write_text((private/name).read_text())
edit('src/render/MaterialPipelinePolicy.hpp','inline bool fullyCoveredClassMaterial(const AssetMaterial& material,float nodeOpacity) noexcept {','inline bool fullyCoveredClassMaterial(const AssetMaterial& material,float nodeOpacity,bool snapshot=true) noexcept {')
edit('src/render/MaterialPipelinePolicy.hpp','&&!material.nprDiffuse.screenLightingNormal&&!opaqueSurfaceOverlay(material)','&&(!snapshot||!material.nprDiffuse.screenLightingNormal)&&!opaqueSurfaceOverlay(material)')
edit('src/render/MaterialPipelinePolicy.hpp','struct MaterialFeatureSpecialization {','// Match the exact values uploaded to the camera uniform, including QA state.\ninline bool computedMaterialView(float lighting,float isolation,float effect,float enabled,float reflection) noexcept {\n    return lighting==1.F&&isolation==0.F&&effect==0.F&&enabled==1.F&&reflection==2.F;\n}\nstruct MaterialFeatureSpecialization {')
edit('src/scenes/CharacterSceneRenderer.hpp','    VkPipeline createMaterialDepthPipeline(const rhi::GraphicsPipelineDesc&);','    VkPipeline createMaterialDepthPipeline(const rhi::GraphicsPipelineDesc&);\n    VkPipeline createMaterialViewPipeline(const rhi::GraphicsPipelineDesc&);\n    std::unordered_map<VkPipeline,VkPipeline> computedMaterialPipelines_;\n    bool computedMaterialViewActive_=false;')
inc='src/scenes/CharacterMaterialSampling.inc'
edit(inc,'    const auto scene=rhi_->createGraphicsPipeline(desc);','    const auto scene=createMaterialViewPipeline(desc);')
edit(inc,'variants[policy-1]=rhi_->createGraphicsPipeline(variant);','variants[policy-1]=createMaterialViewPipeline(variant);')
edit(inc,'VkPipeline CharacterSceneRenderer::createCoverageGraphicsPipeline', '''VkPipeline CharacterSceneRenderer::createMaterialViewPipeline(const rhi::GraphicsPipelineDesc& desc) {
    const auto scene=rhi_->createGraphicsPipeline(desc);
    if(rasterizationSamples_!=VK_SAMPLE_COUNT_1_BIT)return scene;
    VkPipeline computed=VK_NULL_HANDLE;
    try {
        auto specialized=desc;specialized.fragmentSpecialization.push_back({4,VK_TRUE});
        computed=rhi_->createGraphicsPipeline(specialized);
        computedMaterialPipelines_.emplace(scene,computed);
    }catch(...){if(computed)rhi_->destroyPipeline(computed);rhi_->destroyPipeline(scene);throw;}
    return scene;
}
VkPipeline CharacterSceneRenderer::createCoverageGraphicsPipeline''')
edit(inc,'        return it->second[depthPolicy-1];','        scene=it->second[depthPolicy-1];')
edit(inc,'    return scene;\n}\nvoid CharacterSceneRenderer::destroyMaterialLightingPipelines()', '''    if(computedMaterialViewActive_){
        const auto found=computedMaterialPipelines_.find(scene);
        if(found!=computedMaterialPipelines_.end())return found->second;
    }
    return scene;
}
void CharacterSceneRenderer::destroyMaterialLightingPipelines()''')
edit(inc,'    if(rhi_){\n        for(auto* group:', '    computedMaterialViewActive_=false;\n    if(rhi_){\n        for(const auto& variant:computedMaterialPipelines_)rhi_->destroyPipeline(variant.second);\n        for(auto* group:')
edit(inc,'    materialDepthPipelines_.clear();','    computedMaterialPipelines_.clear();\n    materialDepthPipelines_.clear();')
edit(inc,'std::array<bool,kMaterialClassVariantCount> coveredClasses{};','std::array<bool,kMaterialClassVariantCount> coveredClasses{},coveredMainClasses{};')
edit(inc,'coveredClasses[index]=coveredClasses[index]||fullyCoveredClassMaterial(material,1.F);','coveredClasses[index]=coveredClasses[index]||fullyCoveredClassMaterial(material,1.F);\n                coveredMainClasses[index]=coveredMainClasses[index]||fullyCoveredClassMaterial(material,1.F,false);')
edit(inc,'const bool early=(needed||std::any_of(coveredClasses.begin(),coveredClasses.end(),[](bool value){return value;}))','const bool early=(needed||std::any_of(coveredMainClasses.begin(),coveredMainClasses.end(),[](bool value){return value;}))')
edit(inc,'if(early&&coveredClasses[index]){auto covered=desc;covered.fragmentShader=earlyColorModule;','if(early&&coveredMainClasses[index]){auto covered=desc;covered.fragmentShader=earlyColorModule;')
edit(inc,'&&fullyCoveredClassMaterial(material,nodeOpacity)){','&&fullyCoveredClassMaterial(material,nodeOpacity,snapshot)){')
cpp='src/scenes/CharacterSceneRenderer.cpp'
edit(cpp,'        createFacingPipelines(blendPipelines_,materialDesc);','''        VkShaderModule blendEarlyModule=VK_NULL_HANDLE;
        if(rasterizationSamples_==VK_SAMPLE_COUNT_1_BIT){
            blendEarlyModule=createMaterialShaderModule(sceneFragmentVariant(materialFragmentPath,false,false,false,false,false,true));
            materialDesc.fragmentShader=blendEarlyModule;
        }
        createFacingPipelines(blendPipelines_,materialDesc);''')
edit(cpp,'        if(viewFog_)viewFog_->initializePipelines','        materialDesc.fragmentShader=fragmentModule;\n        if(blendEarlyModule)destroyMaterialShaderModule(blendEarlyModule);\n        if(viewFog_)viewFog_->initializePipelines')
edit(cpp,'    std::memcpy(\n        uniformBuffers_[currentFrame_].mapped,','''    computedMaterialViewActive_=rasterizationSamples_==VK_SAMPLE_COUNT_1_BIT
        &&computedMaterialView(uniform.clusterLighting[0],uniform.qaParameters[0],uniform.qaParameters[1],
            uniform.qaParameters[2],uniform.screenReflectionTrace[0]);
    std::memcpy(
        uniformBuffers_[currentFrame_].mapped,''')
edit(cpp,'         << "  \\"loadedResourceIdentityEntries', '         << "  \\"loadedResourceIdentityEntries') if False else None
edit(cpp,'         << "  \\"sceneTransformCachedNodes', '         << "  \\"sceneTransformCachedNodes') if False else None
needle='         << "  \\"sceneTransformCachedNodes'
p=root/cpp;t=p.read_text();at=t.index('         << "  \\"sceneTransformCachedNodes') if needle in t else -1
# JSON fields are inserted using the literal source line.
line=next(x for x in t.splitlines(True) if 'sceneTransformCachedNodes' in x)
t=t.replace(line,'         << "  \\"computedMaterialViewActive\\": " << (computedMaterialViewActive_?"true":"false") << ",\\n"\n'.replace('\\\\','\\')+line)
p.write_text(t)
print('Applied strict material-view specialization and pass-specific coverage')
