from pathlib import Path
import json,subprocess,sys,time,os
out=Path(__file__).resolve().parent;root=out.parents[2]
assert json.loads((out/'image/results.json').read_text())['status']=='passed','Native zero-pixel gate is required'
env=os.environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
player=str(root/'build/ninja-msvc-release/AzurePlayer.exe')
jobs=[('budget',[sys.executable,'-X','utf8',str(root/'tools/artifact_budget.py'),'--run',str(out),'--planned-bytes','268435456'],60),('native-candidate',[sys.executable,'-X','utf8',str(out/'measure_candidate.py')],1000),('material-lighting',[sys.executable,'-X','utf8',str(root/'tools/test_material_lighting_gpu.py'),'--executable',player,'--output',str(out/'material-lighting'),'--expected-validation','disabled'],600),('blend-depth',[sys.executable,'-X','utf8',str(root/'tools/test_blend_depth_gpu.py'),'--executable',player,'--output',str(out/'blend-depth'),'--expected-validation','disabled'],600)]
rows=[]
for name,command,deadline in jobs:
 start=time.monotonic()
 with (out/(name+'-runner.log')).open('wb') as log:p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=deadline)
 rows.append(dict(name=name,exitCode=p.returncode,seconds=time.monotonic()-start));(out/'performance-compatibility-checks.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
 assert p.returncode==0,(out/(name+'-runner.log')).read_text(errors='replace')[-5000:]
