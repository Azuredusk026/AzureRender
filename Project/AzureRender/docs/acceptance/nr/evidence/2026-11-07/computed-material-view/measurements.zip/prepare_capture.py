from pathlib import Path
import json
r=Path.cwd();o=r/'build/runs/20261107-113035-computed-material-view-490b2c';p=o/'capture.py';s=p.read_text()
s=s.replace('shader_same=shader_before==shader_after\nassert len(shader_before)==663 and shader_same','''shader_changed=sorted(k for k in shader_before if shader_before[k]!=shader_after.get(k))
expected={p['output'] for p in json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text())['programs'] if p['source']=='mesh.frag'}
shader_same=set(shader_before)==set(shader_after) and set(shader_changed)==expected
assert len(shader_before)==663 and shader_same
(out/'changed-programs.json').write_text(json.dumps(shader_changed,indent=2))''')
s=s.replace('cache_active=cache_state.get(\'sceneTransformCachedNodes\')==1679 and cache_state.get(\'sceneTransformReusedWorld\',0)>0',"cache_active=cache_state.get('sceneTransformCachedNodes')==1679 and cache_state.get('sceneTransformReusedWorld',0)>0 and cache_manifest['computedMaterialViewActive']")
s=s.replace("'all663ProgramsByteIdentical':shader_same","'programSetAndExpectedChangesVerified':shader_same,'changedProgramCount':len(shader_changed),'computedMaterialViewActive':cache_manifest['computedMaterialViewActive']")
s=s.replace('Generational transform history and exact hierarchy matrix reuse','Strict computed-view specialization and main-color early depth').replace('acf9826-with-stable-frame-preparation','acf9826-with-computed-material-view')
p.write_text(s)
# Retained cost controls now have a durable archive and receipts.
for name in ['20261107-105440-computed-lighting-cost-1bdaec','20261107-105935-gpu-structure-cost-4249bd','20261107-111435-computed-early-cost-243eb9','20261107-111830-computed-specialization-cost-b26603']:
 (r/'build/runs'/name/'.finished').touch()
print('Prepared zero-pixel native gate and exact changed-program inventory')
