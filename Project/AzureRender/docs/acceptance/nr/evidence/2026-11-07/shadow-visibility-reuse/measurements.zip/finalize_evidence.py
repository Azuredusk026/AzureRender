from pathlib import Path
import json,hashlib,subprocess,sys,zipfile
out=Path(__file__).resolve().parent;root=out.parents[2];destination=root/'docs/acceptance/nr/evidence/2026-11-07/shadow-visibility-reuse';destination.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads((out/p).read_text())
summary=dict(status='isolated-not-adopted-production-restored',sourceBase='8c78732',candidateAdopted=False,initialBuildChecks=read('build-checks.json'),samplerFixChecks=read('sampler-build-checks.json'),intelChecks=read('intel-checks.json'),image=read('image/results.json'),marker=read('marker-image/results.json'),pair=read('paired-results.json'),restoration=read('restoration.json'),formalPerformancePassed=False,visualAcceptance='failed-user-review')
files=[p for p in out.rglob('*') if p.is_file() and p.suffix.lower() in {'.py','.json','.log','.cpp','.hpp','.inc','.glsl','.frag','.vert','.xml','.csv','.txt','.diff','.rsp'}]
archive=destination/'measurements.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for p in sorted(files):z.write(p,p.relative_to(out).as_posix())
summary['archive']=dict(path=archive.relative_to(root).as_posix(),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(files))
assert zipfile.ZipFile(archive).testzip() is None
(destination/'results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
p=root/'docs/development/artifact-manifest.json';m=json.loads(p.read_text(encoding='utf-8'));m['milestones'].insert(0,dict(path=out.relative_to(root/'build').as_posix(),name='同帧阴影可见度候选评估',status='DiagnosticIsolated',sourceBase='8c78732',evidence='docs/acceptance/nr/shadow-visibility-reuse.md',candidateAdopted=False,restoredProgramsByteIdentical=663,restoredPlayerCodeSectionIdentical=True,formalPerformancePassed=False));p.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert subprocess.run([sys.executable,'-X','utf8',str(root/'tools/artifact_cleanup.py'),'--finish',str(out)],cwd=root).returncode==0
print(json.dumps(summary['archive']),flush=True)
