#include "ShadowVisibilitySurface.hpp"
#include <stdexcept>
namespace azurerender {
namespace {constexpr VkImageUsageFlags usage=VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT|VK_IMAGE_USAGE_SAMPLED_BIT|VK_IMAGE_USAGE_TRANSFER_SRC_BIT;}
bool ShadowVisibilitySurface::supported(rhi::IRhi& backend,VkExtent2D extent,unsigned slots,std::uint64_t byteLimit){
 if(!extent.width||!extent.height||!slots||slots>8)return false;
 const auto pixels=std::uint64_t(extent.width)*extent.height;
 if(pixels>byteLimit/(20ULL*slots))return false;
 for(auto format:{VK_FORMAT_R32_SFLOAT,VK_FORMAT_R32G32B32A32_UINT})
  if(!backend.supportsSampledImage(format,false)||!(backend.imageSampleCounts(format,usage)&VK_SAMPLE_COUNT_1_BIT))return false;
 return true;
}
ShadowVisibilitySurface::ShadowVisibilitySurface(rhi::IRhi& backend,VkExtent2D extent,unsigned slots,std::uint64_t byteLimit):rhi_(backend){
 if(!supported(backend,extent,slots,byteLimit))throw std::invalid_argument("Shadow visibility surface exceeds format or byte capabilities");
 try{
  visibility_.resize(slots);identity_.resize(slots);
  for(unsigned slot=0;slot<slots;++slot)for(unsigned kind=0;kind<2;++kind){
   auto& t=kind?identity_[slot]:visibility_[slot];const auto format=kind?VK_FORMAT_R32G32B32A32_UINT:VK_FORMAT_R32_SFLOAT;
   t.image=backend.allocator().createImage2D(extent.width,extent.height,format,usage);
   t.view=backend.createImageView(t.image.image,format,VK_IMAGE_ASPECT_COLOR_BIT,1);
  }
  rhi::SamplerDesc sampler;sampler.filter=VK_FILTER_NEAREST;sampler.mipmapLinear=false;
  sampler.addressU=sampler.addressV=VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;sampler_=backend.createSampler(sampler);
  bytes_=std::uint64_t(extent.width)*extent.height*20*slots;
 }catch(...){clear();throw;}
}
ShadowVisibilitySurface::~ShadowVisibilitySurface(){clear();}
void ShadowVisibilitySurface::clear() noexcept{
 if(sampler_)rhi_.destroySampler(sampler_);sampler_=VK_NULL_HANDLE;
 for(auto* list:{&visibility_,&identity_})for(auto& t:*list){if(t.view)rhi_.destroyImageView(t.view);rhi_.allocator().destroyImage(t.image);t={};}
 visibility_.clear();identity_.clear();bytes_=0;
}
}
