from pathlib import Path
import subprocess,json,os,time,re
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release'
env=os.environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']='*igvk64*'
v=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/vulkaninfoSDK.exe','--summary'],env=env,capture_output=True,text=True,timeout=60)
(out/'intel-devices.log').write_text(v.stdout+v.stderr);names=re.findall(r'deviceName\s*=\s*(.+)',v.stdout);assert v.returncode==0 and names and all('Intel' in n for n in names),names
command=['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe','--test-dir',str(build),'-R','^AzureRender\\.(ShadowVisibilitySurfaceGpu|SceneMultisamplingGpu|ShaderSpecializationGpu)$','--output-on-failure','--no-tests=error','--output-junit',str(out/'intel-checks.xml')]
start=time.monotonic()
with (out/'intel-checks.log').open('wb') as log:v=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
record=dict(command=command,exitCode=v.returncode,seconds=time.monotonic()-start,devices=names,filter='*igvk64*');(out/'intel-checks.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
assert v.returncode==0,(out/'intel-checks.log').read_text(errors='replace')[-4000:]
