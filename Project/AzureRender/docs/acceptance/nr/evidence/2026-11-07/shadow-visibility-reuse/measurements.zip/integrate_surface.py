from pathlib import Path
root=Path(__file__).resolve().parents[3]
p=root/'src/scenes/CharacterSceneRenderer.cpp';s=p.read_text(encoding='utf-8')
def edit(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
edit('    bindlessTextures_ = access.mode==ResourceAccessMode::Indexed;', '''    auto visibilityRequirements=objectShadowPrepared_?objectRequirements:requirements;
    visibilityRequirements.sampledImageSlots+=2;visibilityRequirements.fixedSampledImageSlots+=2;
    visibilityRequirements.fragmentColorAttachments=std::max<std::uint64_t>(4,visibilityRequirements.fragmentColorAttachments);
    shadowVisibilityCapable_=context.fragmentPrimitiveIdentity&&limits.maxColorAttachments>=4
        &&ResourceAccessProfile::select(capabilities,visibilityRequirements).mode==access.mode
        &&ShadowVisibilitySurface::supported(*rhi_,context.renderExtent,static_cast<unsigned>(kMaxFramesInFlight));
    bindlessTextures_ = access.mode==ResourceAccessMode::Indexed;''')
edit('    rhi::RenderPassDesc pass;pass.attachments=', '''    if(shadowVisibilityCapable_&&context.rasterizationSamples==VK_SAMPLE_COUNT_1_BIT
        &&ShadowVisibilitySurface::supported(*rhi_,context.renderExtent,static_cast<unsigned>(kMaxFramesInFlight)))
        shadowVisibility_=std::make_unique<ShadowVisibilitySurface>(*rhi_,context.renderExtent,static_cast<unsigned>(kMaxFramesInFlight));
    rhi::RenderPassDesc pass;pass.attachments=''')
edit('    pass.depthAttachment=2;pass.externalReadDependency=true;overlayDepthPass_=rhi_->createRenderPass(pass);', '''    if(shadowVisibility_){
        pass.attachments.push_back({VK_FORMAT_R32_SFLOAT,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,true,true,false});
        pass.attachments.push_back({VK_FORMAT_R32G32B32A32_UINT,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,true,true,false});
    }
    pass.depthAttachment=2;pass.externalReadDependency=true;overlayDepthPass_=rhi_->createRenderPass(pass);''')
edit('        overlayDepthFramebuffers_[frame]=rhi_->createFramebuffer({overlayDepthPass_,{color.view,target.view,overlayDepthViews_[frame]},context.renderExtent.width,context.renderExtent.height});', '''        std::vector<VkImageView> attachments{color.view,target.view,overlayDepthViews_[frame]};
        if(shadowVisibility_){attachments.push_back(shadowVisibility_->visibility(static_cast<unsigned>(frame)).view);attachments.push_back(shadowVisibility_->identity(static_cast<unsigned>(frame)).view);}
        overlayDepthFramebuffers_[frame]=rhi_->createFramebuffer({overlayDepthPass_,attachments,context.renderExtent.width,context.renderExtent.height});''')
edit('    if(overlayDepthPass_)rhi_->destroyRenderPass(overlayDepthPass_);overlayDepthPass_=VK_NULL_HANDLE;', '    shadowVisibility_.reset();\n    if(overlayDepthPass_)rhi_->destroyRenderPass(overlayDepthPass_);overlayDepthPass_=VK_NULL_HANDLE;')
edit('    const auto prepass=graph.addGraphicsPass("character-opaque-depth",overlayBegin,', '''    if(shadowVisibility_){overlayBegin.clearValues.push_back(ShadowVisibilitySurface::visibilityClear());overlayBegin.clearValues.push_back(ShadowVisibilitySurface::identityClear());}
    const auto prepass=graph.addGraphicsPass("character-opaque-depth",overlayBegin,''')
edit('    graph.use(prepass,resources.shadow,RenderGraphUsage::Sampled,false);', '''    std::array<RenderGraph::ResourceId,2> shadowVisibilityResources{};
    if(shadowVisibility_){
        const auto slot=context.currentFrame;
        for(unsigned kind=0;kind<2;++kind){rhi::ImageBarrierDesc initial;initial.image=kind?shadowVisibility_->identity(slot).image.image:shadowVisibility_->visibility(slot).image.image;
            shadowVisibilityResources[kind]=graph.importImage(kind?"character-shadow-identity":"character-shadow-visibility",initial);
            graph.attachment(prepass,shadowVisibilityResources[kind],RenderGraphUsage::ColorAttachment,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);}
    }
    graph.use(prepass,resources.shadow,RenderGraphUsage::Sampled,false);''')
edit('    graph.use(main,snapshotColor,RenderGraphUsage::Sampled,false);', '''    graph.use(main,snapshotColor,RenderGraphUsage::Sampled,false);
    if(shadowVisibility_)for(auto resource:shadowVisibilityResources)graph.use(main,resource,RenderGraphUsage::Sampled,false);''')
edit('        depthDesc.colorAttachmentCount=2;\n        depthDesc.colorWriteMasks.assign(2,0xf);', '''        depthDesc.colorAttachmentCount=shadowVisibility_?4U:2U;
        depthDesc.colorWriteMasks.assign(depthDesc.colorAttachmentCount,0);depthDesc.colorWriteMasks[0]=0xf;depthDesc.colorWriteMasks[1]=0xf;''')
edit('initializeMaterialClassPipelines(context,integralBase,depthDesc);','initializeMaterialClassPipelines(context,integralBase,depthDesc,meshVertexPath(objectShadowPrepared_?"mesh_object":"mesh"));')
edit('desc.colorWriteMasks={0,VK_COLOR_COMPONENT_R_BIT};','desc.colorWriteMasks.assign(desc.colorAttachmentCount,0);desc.colorWriteMasks[1]=VK_COLOR_COMPONENT_R_BIT;')
edit('auto prefill=desc;prefill.colorWriteMasks={0,0};','auto prefill=desc;prefill.colorWriteMasks.assign(prefill.colorAttachmentCount,0);')
edit('                shell.colorAttachmentCount=2;', '                shell.colorAttachmentCount=shadowVisibility_?4U:2U;')
edit('                shell.colorWriteMasks={0,VK_COLOR_COMPONENT_R_BIT};','                shell.colorWriteMasks.assign(shell.colorAttachmentCount,0);shell.colorWriteMasks[1]=VK_COLOR_COMPONENT_R_BIT;')
edit('frameCount * (textureSlots + 4 +','frameCount * (textureSlots + 4 + (shadowVisibilityCapable_?2U:0U) +')
edit('descriptorCount * ((outlineProjectionEnabled_?16U:15U)+','descriptorCount * ((outlineProjectionEnabled_?16U:15U)+(shadowVisibilityCapable_?2U:0U)+')
before='        descriptorSetLayout_=rhi_->createDescriptorSetLayout(bindings);'
assert s.count(before)==2
s=s.replace(before,'''        if(shadowVisibilityCapable_){bindings.push_back({38,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_FRAGMENT_BIT});bindings.push_back({39,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_FRAGMENT_BIT});}
        descriptorSetLayout_=rhi_->createDescriptorSetLayout(bindings);''')
# Scene-image descriptor writes serve both fixed and indexed paths.
edit('    const auto writeSceneImages=[this](VkDescriptorSet set){', '''    const auto writeVisibility=[&](VkDescriptorSet set,unsigned frame){if(!shadowVisibility_)return;
        rhi_->writeDescriptorImage({set,38,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,shadowVisibility_->visibility(frame).view,overlaySceneDepth_[frame].sampler,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL});
        rhi_->writeDescriptorImage({set,39,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,shadowVisibility_->identity(frame).view,overlaySceneDepth_[frame].sampler,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL});
    };
    const auto writeSceneImages=[this](VkDescriptorSet set){''')
before='            writeSceneImages(uniformWrite.set);\n            if(viewFog_){'
assert s.count(before)==2
s=s.replace(before,'            writeSceneImages(uniformWrite.set);writeVisibility(uniformWrite.set,static_cast<unsigned>(frame));\n            if(viewFog_){')
p.write_text(s,encoding='utf-8')
print('Surface, attachments, resource dependencies and descriptors integrated')
