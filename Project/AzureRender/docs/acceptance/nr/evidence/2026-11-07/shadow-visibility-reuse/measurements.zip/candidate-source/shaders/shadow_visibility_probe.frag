#version 450
#extension GL_GOOGLE_include_directive : require
#include "shadow_visibility_identity.glsl"
layout(push_constant) uniform Probe {float depth;float visibility;uint firstIndex;uint material;} probe;
layout(location=0) flat in uvec2 source;
layout(location=0) out float visibility;
layout(location=1) out uvec4 identity;
#if defined(AZURE_SHADOW_VISIBILITY_CONSUMER)
layout(binding=38) uniform sampler2D visibilityInput;
layout(binding=39) uniform usampler2D identityInput;
#endif
void main(){
    identity=azureShadowIdentity(gl_FragCoord.z,source,uint(gl_PrimitiveID),probe.material);
    visibility=probe.visibility;
#if defined(AZURE_SHADOW_VISIBILITY_CONSUMER)
    ivec2 pixel=ivec2(gl_FragCoord.xy);float previous=texelFetch(visibilityInput,pixel,0).r;
    if(azureShadowVisibilityMatches(identity,texelFetch(identityInput,pixel,0),previous))visibility=previous;
#endif
}
