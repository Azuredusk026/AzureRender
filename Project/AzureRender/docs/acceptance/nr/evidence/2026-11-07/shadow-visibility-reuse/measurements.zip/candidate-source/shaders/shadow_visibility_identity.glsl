#ifndef AZURE_SHADOW_VISIBILITY_IDENTITY_GLSL
#define AZURE_SHADOW_VISIBILITY_IDENTITY_GLSL
uvec4 azureShadowIdentity(float depth,uvec2 source,uint triangle,uint material) {
    if(isnan(depth)||isinf(depth)||source.y==0xffffffffu||triangle>(0xfffffffeu-source.y)/3u)
        return uvec4(0xffffffffu);
    return uvec4(floatBitsToUint(depth),source.x,source.y+triangle*3u,material);
}
bool azureShadowVisibilityMatches(uvec4 requested,uvec4 stored,float visibility) {
    return requested.z!=0xffffffffu&&all(equal(requested,stored))
        &&!isnan(visibility)&&!isinf(visibility)&&visibility>=0.0&&visibility<=1.0;
}
#endif
