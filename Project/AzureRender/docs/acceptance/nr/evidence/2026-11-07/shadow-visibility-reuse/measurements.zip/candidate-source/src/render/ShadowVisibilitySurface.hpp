#pragma once
#include "rhi/Rhi.hpp"
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>
namespace azurerender {
struct ShadowVisibilityIdentity {
 std::array<std::uint32_t,4> words{UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX};
 bool valid() const noexcept{return words[2]!=UINT32_MAX;}
};
inline ShadowVisibilityIdentity shadowVisibilityIdentity(float depth,std::uint32_t instance,
 std::uint32_t firstIndex,std::uint32_t triangle,std::uint32_t material) noexcept {
 ShadowVisibilityIdentity result;
 if(!std::isfinite(depth)||firstIndex==UINT32_MAX||triangle>(UINT32_MAX-1-firstIndex)/3)return result;
 std::memcpy(&result.words[0],&depth,4);result.words[1]=instance;result.words[2]=firstIndex+triangle*3;result.words[3]=material;return result;
}
inline bool shadowVisibilityHit(const ShadowVisibilityIdentity& requested,const ShadowVisibilityIdentity& stored,float value) noexcept {
 return requested.valid()&&requested.words==stored.words&&std::isfinite(value)&&value>=0&&value<=1;
}
// One view/load owns these surfaces. The consumer clears its current frame slot
// in the snapshot render pass and declares the subsequent sampled dependency.
class ShadowVisibilitySurface final {
public:
 static constexpr std::uint64_t kMaximumBytes=256ULL*1024*1024;
 struct Texture {rhi::GpuImage image{};VkImageView view=VK_NULL_HANDLE;};
 static bool supported(rhi::IRhi&,VkExtent2D,unsigned slots,std::uint64_t byteLimit=kMaximumBytes);
 ShadowVisibilitySurface(rhi::IRhi&,VkExtent2D,unsigned slots,std::uint64_t byteLimit=kMaximumBytes);
 ~ShadowVisibilitySurface();
 ShadowVisibilitySurface(const ShadowVisibilitySurface&)=delete;
 ShadowVisibilitySurface& operator=(const ShadowVisibilitySurface&)=delete;
 const Texture& visibility(unsigned slot) const{return visibility_.at(slot);}
 const Texture& identity(unsigned slot) const{return identity_.at(slot);}
 VkSampler sampler() const noexcept{return sampler_;}
 std::uint64_t bytes() const noexcept{return bytes_;}
 static VkClearValue visibilityClear() noexcept {VkClearValue v{};v.color.float32[0]=-1;return v;}
 static VkClearValue identityClear() noexcept {VkClearValue v{};for(auto& x:v.color.uint32)x=UINT32_MAX;return v;}
private:
 void clear() noexcept;
 rhi::IRhi& rhi_;
 VkSampler sampler_=VK_NULL_HANDLE;
 std::vector<Texture> visibility_,identity_;
 std::uint64_t bytes_=0;
};
}
