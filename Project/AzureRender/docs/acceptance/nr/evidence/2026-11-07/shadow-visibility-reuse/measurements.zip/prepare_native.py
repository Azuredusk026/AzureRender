from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2]
s=(root/'build/runs/20261107-013603-static-transparent-preparation-049ee8/capture_candidate.py').read_text()
s=s[:s.index('\nmanifest=')]
begin=s.index('shader_before=');end=s.index('\nlogs=',begin)
s=s[:begin]+'''shader_before=json.loads((out.parent/'baseline-products.json').read_text())['programs'];shader_after={p.name:digest(p) for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv')};shader_same=all(shader_after.get(k)==v for k,v in shader_before.items())
assert len(shader_before)==663 and shader_same
'''+s[end:]
s=s.replace('95f0f38-with-static-transparent-preparation','8c78732-with-shadow-visibility-reuse').replace('productionShaders535ByteIdentical','legacy663ProgramsByteIdentical').replace('Static transparent preparation candidate','Same-frame shadow visibility candidate')
s+='''
manifest=json.loads((out/'frames/capture_manifest.json').read_text());work={k:manifest[k] for k in ['shadowVisibilityPrepared','shadowVisibilityBytes','shadowVisibilityIdentityVersion','ordinaryOpaqueSnapshotPipelineCount']}
assert work['shadowVisibilityPrepared'] and work['shadowVisibilityBytes']<=256*1024*1024 and work['ordinaryOpaqueSnapshotPipelineCount']>0,work
(out/'shadow-visibility-workload.json').write_text(json.dumps(work,indent=2));print(json.dumps(work),flush=True)
'''
(out/'capture.py').write_text(s)
print('Prepared one frozen native four-frame comparison')
