from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2];old=root/'build/runs/20261107-013603-static-transparent-preparation-049ee8'
for role in ['baseline','candidate']:
 s=(old/('measure_'+role+'.py')).read_text().replace('95f0f38','8c78732').replace('static-transparent-preparation','shadow-visibility-reuse')
 begin=s.index('\nfrozenBaseline=')
 s=s[:begin]+'''\nfrozenBaseline=json.loads((out.parent/'baseline-products.json').read_text());assert digest(out.parent/'baseline/AzurePlayer.exe')==frozenBaseline['playerSha256'];current={p.name:digest(p) for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv')};assert all(current.get(k)==v for k,v in frozenBaseline['programs'].items())
'''
 (out/('measure_'+role+'.py')).write_text(s)
print('Prepared one native 300warmup+120sample pair')
