from pathlib import Path
import concurrent.futures,hashlib,json,shutil,subprocess,time
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release'
directory=out/'marker-root/shaders';directory.mkdir(parents=True)
original=(root/'shaders/mesh.frag').read_text(encoding='utf-8')
source=original.replace('float sampleShadowMap(float normalDotLight) {','bool azureDiagnosticShadowHit=false;\nfloat sampleShadowMap(float normalDotLight) {')
needle='if(azureShadowVisibilityMatches(requestedShadow,texelFetch(cachedShadowIdentity,cachePixel,0),storedVisibility))return storedVisibility;'
assert source.count(needle)==1
source=source.replace(needle,'if(azureShadowVisibilityMatches(requestedShadow,texelFetch(cachedShadowIdentity,cachePixel,0),storedVisibility)){azureDiagnosticShadowHit=true;return storedVisibility;}')
source=source.replace('    outputColor = vec4(qaColor, outputAlpha);','    outputColor = vec4(qaColor, outputAlpha);\n    if(azureDiagnosticShadowHit)outputColor=vec4(64,0,64,1);')
private=out/'marker-mesh.frag';private.write_text(source,encoding='utf-8')
manifest=json.loads((build/'shader-reload.json').read_text());hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (build/'shaders').glob('*.spv')}
for p in (build/'shaders').glob('*.spv'):shutil.copy2(p,directory/p.name)
programs=[p for p in manifest['programs'] if p['source']=='mesh.frag' and 'AZURE_SHADOW_VISIBILITY_REUSE=1' in p['defines'] and 'AZURE_OPAQUE_SNAPSHOT=1' not in p['defines']]
assert programs
def compile(program):
 command=[manifest['compiler'],'-I'+str(root/'shaders'),*['-D'+d for d in program['defines']],str(private),'-o',str(directory/program['output'])]
 value=subprocess.run(command,capture_output=True,text=True,timeout=90);assert value.returncode==0,value.stderr
 return dict(program=program['output'],command=command,sha256=hashlib.sha256((directory/program['output']).read_bytes()).hexdigest())
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(compile,programs))
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (build/'shaders').glob('*.spv')}==hashes
(out/'marker-programs.json').write_text(json.dumps(dict(scope='Private branch marker; original production sources and programs retained',sourceSha256=hashlib.sha256(private.read_bytes()).hexdigest(),programs=rows),indent=2))
print(json.dumps(dict(markerPrograms=len(rows),productionProgramsUnchanged=len(hashes))),flush=True)
