from pathlib import Path
import hashlib,json,shutil,struct,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];repo=root.parents[1]
tracked=['CMakeLists.txt','src/app/AzureRenderApp.cpp','src/render/RenderContext.hpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','src/scenes/CharacterMaterialSampling.inc','shaders/mesh.vert','shaders/mesh.frag','tests/support/VulkanComputeFixture.hpp']
new=['src/render/ShadowVisibilitySurface.hpp','src/render/ShadowVisibilitySurface.cpp','shaders/shadow_visibility_identity.glsl','shaders/shadow_visibility_probe.vert','shaders/shadow_visibility_probe.frag','tests/ShadowVisibilitySurfaceTests.cpp','tests/ShadowVisibilitySurfaceGpuTests.cpp','tests/ShadowVisibilityRecordingTests.cpp']
snap=out/'candidate-source';snap.mkdir();isolated=out/'isolated-candidate';isolated.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def code(p):
 b=p.read_bytes();pe=struct.unpack_from('<I',b,0x3c)[0];n=struct.unpack_from('<H',b,pe+6)[0];opt=struct.unpack_from('<H',b,pe+20)[0]
 for i in range(n):
  s=pe+24+opt+40*i
  if b[s:s+8].rstrip(b'\0')==b'.text':
   count,offset=struct.unpack_from('<II',b,s+16);return hashlib.sha256(b[offset:offset+count]).hexdigest()
 raise AssertionError('Missing code section')
record=dict(status='isolated-not-adopted',sourceBase='8c78732',reason='Whole-frame GPU benefit not established; one pair mean slower0.530ms, P95 slower0.206ms; branch marker executed; original formal criteria retained',candidateSourceHashes={})
for name in tracked+new:
 p=root/name;t=snap/name;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t);record['candidateSourceHashes'][name]=sha(p)
build=root/'build/ninja-msvc-release'
for name in ['AzurePlayer.exe','AzureRender.exe']:shutil.copy2(build/name,isolated/name)
shutil.copytree(build/'shaders',isolated/'shaders');programs={p.name:sha(p) for p in (isolated/'shaders').glob('*.spv')};record['candidatePrograms']=programs;record['candidatePlayerSha256']=sha(isolated/'AzurePlayer.exe')
(out/'candidate-record.json').write_text(json.dumps(record,indent=2))
baseline=json.loads((out/'baseline-products.json').read_text())
for name in tracked:(root/name).write_bytes(subprocess.check_output(['git','show','8c78732:Project/AzureRender/'+name],cwd=repo))
for name in new:
 p=(root/name).resolve();assert p.is_relative_to(root.resolve()) and p.is_file() and sha(p)==sha(snap/name)
 assert subprocess.run(['git','ls-files','--error-unmatch','Project/AzureRender/'+name],cwd=repo,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0;p.unlink()
for name in programs.keys()-baseline['programs'].keys():
 p=(build/'shaders'/name).resolve();assert p.parent==(build/'shaders').resolve() and p.is_file() and sha(p)==programs[name];p.unlink()
cmd=['cmd','/d','/c',str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config','Release','--runtime-only']
start=time.monotonic()
with (out/'restore-build.log').open('wb') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
assert r.returncode==0,r.returncode
assert {p.name:sha(p) for p in (build/'shaders').glob('*.spv')}==baseline['programs']
assert code(build/'AzurePlayer.exe')==code(out/'baseline/AzurePlayer.exe')
verify=cmd[:cmd.index('build')]+['verify','--source',str(root),'--build-dir',str(build),'--config','Release']
with (out/'restore-provenance.log').open('wb') as log:v=subprocess.run(verify,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=90)
assert v.returncode==0
record.update(restoredSourceByteIdentical=True,restoredProgramsByteIdentical=len(baseline['programs']),restoredPlayerCodeSectionIdentical=True,restoredPlayerSha256=sha(build/'AzurePlayer.exe'),restoredCodeSectionSha256=code(build/'AzurePlayer.exe'),buildSeconds=time.monotonic()-start,buildCommand=cmd,provenanceVerified=True)
(out/'restoration.json').write_text(json.dumps(record,indent=2));print(json.dumps({k:v for k,v in record.items() if k not in ['candidateSourceHashes','candidatePrograms']},indent=2))
