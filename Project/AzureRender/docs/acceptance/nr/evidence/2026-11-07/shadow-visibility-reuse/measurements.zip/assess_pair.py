from pathlib import Path
import json,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2]
assert json.loads((out/'image/results.json').read_text())['status']=='passed'
assert json.loads((out/'marker-image/results.json').read_text())['status']=='branch-execution-confirmed'
rows=[]
for role in ['baseline','candidate']:
 start=time.monotonic()
 with (out/('performance-'+role+'-runner.log')).open('wb') as log:r=subprocess.run([sys.executable,'-X','utf8',str(out/('measure_'+role+'.py'))],cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=1000)
 row=dict(role=role,exitCode=r.returncode,seconds=time.monotonic()-start);rows.append(row);(out/'performance-execution.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
 assert r.returncode==0,(out/('performance-'+role+'-runner.log')).read_text(errors='replace')[-3000:]
a=json.loads((out/'performance-baseline/results.json').read_text());b=json.loads((out/'performance-candidate/results.json').read_text())
v=dict(sourceBase='8c78732',cpuBaseline=a['cpu'],cpuCandidate=b['cpu'],cpuMeanSavedMs=a['cpu']['mean']-b['cpu']['mean'],gpuBaseline=a['gpu'],gpuCandidate=b['gpu'],gpuMeanSavedMs=a['gpu']['frameMs']['mean']-b['gpu']['frameMs']['mean'],gpuP95SavedMs=a['gpu']['frameMs']['p95']-b['gpu']['frameMs']['p95'],gpuMeanReduction=1-b['gpu']['frameMs']['mean']/a['gpu']['frameMs']['mean'],environmentPassed=a['environmentPassed'] and b['environmentPassed'],formalSamplesSatisfied=False,visualAcceptance='failed-user-review')
(out/'paired-results.json').write_text(json.dumps(v,indent=2));print(json.dumps(v),flush=True)
