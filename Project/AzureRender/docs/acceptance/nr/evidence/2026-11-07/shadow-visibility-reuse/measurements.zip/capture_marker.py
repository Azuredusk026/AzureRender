from pathlib import Path
import json,subprocess,os,sys,time
import numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;root=out.parents[2];destination=out/'marker-image';destination.mkdir()
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
from run_playable_performance import freeze_products
assert json.loads((out/'image/results.json').read_text())['status']=='passed'
source=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
private={str(p):digest(p) for p in (out/'marker-root/shaders').glob('*.spv')};project=json.loads((out/'image/frozen-inputs.json').read_text())['project']
command=json.loads((out/'image/command.json').read_text());command[command.index('--capture-dir')+1]=str(destination/'frames');command[command.index('--runtime-report')+1]=str(destination/'runtime.json');command+=['--resource-root',str(out/'marker-root')]
(destination/'command.json').write_text(json.dumps(command,indent=2));(destination/'frozen-inputs.json').write_text(json.dumps(dict(source=source,products=products,project=project,privatePrograms=private),indent=2))
env=os.environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
start=time.monotonic();si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
with (destination/'stdout.log').open('wb') as stdout,(destination/'stderr.log').open('wb') as stderr:r=subprocess.run(command,cwd=destination,env=env,startupinfo=si,stdout=stdout,stderr=stderr,timeout=900)
rows=[]
for path in sorted((destination/'frames').glob('frame_*.png')):
 current=np.asarray(Image.open(path).convert('RGB')).astype(np.int16);baseline=np.asarray(Image.open(out/'image/frames'/path.name).convert('RGB')).astype(np.int16)
 delta=np.abs(current-baseline);changed=np.any(delta,axis=2);strong=delta.max(axis=2)>=32
 rows.append(dict(frame=path.name,sha256=digest(path),pixels=int(changed.size),changedPixels=int(changed.sum()),largeByteDifferencePixels=int(strong.sum()),influencedFraction=float(strong.mean()),maxByteDifference=int(delta.max())))
assert r.returncode==0 and len(rows)==4 and all(row['largeByteDifferencePixels']>100000 for row in rows),(r.returncode,rows)
assert inputs(root)==source and all(digest(Path(p))==v for p,v in products.items())
assert all(digest(Path(p))==v for p,v in private.items()) and all(digest(Path(p))==v for p,v in project.items())
logs=(destination/'stdout.log').read_text(errors='replace')+(destination/'stderr.log').read_text(errors='replace')
assert 'Allocator after unload: buffers=0 images=0' in logs
result=dict(status='branch-execution-confirmed',seconds=time.monotonic()-start,frames=rows,productionSourceAndProgramsUnchanged=True,projectBytesUnchanged=True,zeroAllocator=True,scope='Private HDR magenta branch marker; influenced pixels include compositing and post-processing, and do not represent exact cache-hit counts; production four frozen RGB frames remain unchanged')
(destination/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
