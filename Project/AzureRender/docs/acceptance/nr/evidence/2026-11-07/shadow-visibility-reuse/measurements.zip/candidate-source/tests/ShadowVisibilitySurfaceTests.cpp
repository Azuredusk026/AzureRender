#include "render/ShadowVisibilitySurface.hpp"
#include "rhi/NullRhi.hpp"
#include <cmath>
#include <iostream>
#include <limits>
using namespace azurerender;
namespace {void require(bool v,const char* m){if(!v)throw std::runtime_error(m);}}
int main()try{
 rhi::NullRhi backend;
 require(ShadowVisibilitySurface::supported(backend,{1920,1080},2),"Native surface must fit the budget");
 require(ShadowVisibilitySurface::supported(backend,{2560,1440},2),"Frozen reference surface must fit");
 require(!ShadowVisibilitySurface::supported(backend,{3840,2160},2),"Over-budget surface must use the full algorithm");
 require(!ShadowVisibilitySurface::supported(backend,{0,1080},2),"Empty surface rejected");
 require(!ShadowVisibilitySurface::supported(backend,{64,48},0),"Empty slot count rejected");
 require(!ShadowVisibilitySurface::supported(backend,{UINT32_MAX,UINT32_MAX},8),"Budget arithmetic cannot wrap");
 require(!ShadowVisibilitySurface::supported(backend,{64,48},9),"Frame slot count bounded");
 backend.unavailableSampledFormats.insert(VK_FORMAT_R32G32B32A32_UINT);
 require(!ShadowVisibilitySurface::supported(backend,{64,48},2),"Integer identity format required");
 backend.unavailableSampledFormats.clear();
 auto identity=shadowVisibilityIdentity(.25F,7,123,11,19);
 require(identity.words==std::array<std::uint32_t,4>{0x3e800000U,7,156,19},"Identity must cover the full source triangle");
 require(shadowVisibilityHit(identity,identity,.125F),"Exact identity and finite visibility hit");
 for(unsigned field=0;field<4;++field){auto other=identity;++other.words[field];require(!shadowVisibilityHit(identity,other,1),"Every identity field participates");}
 require(!shadowVisibilityHit(identity,identity,-1),"Clear sentinel cannot hit");
 require(!shadowVisibilityHit(identity,identity,1.01F),"Visibility outside range cannot hit");
 require(!shadowVisibilityHit(identity,identity,std::numeric_limits<float>::quiet_NaN()),"NaN cannot hit");
 require(shadowVisibilityIdentity(0.F,0,0,0,0).words!=shadowVisibilityIdentity(-0.F,0,0,0,0).words,"Depth identity retains signed zero bits");
 require(!shadowVisibilityIdentity(.5F,0,UINT32_MAX,0,0).valid(),"Invalid source index sentinel is rejected");
 require(!shadowVisibilityIdentity(.5F,0,UINT32_MAX-1,1,0).valid(),"Triangle addition cannot wrap");
 require(!shadowVisibilityIdentity(std::numeric_limits<float>::infinity(),0,0,0,0).valid(),"Infinite depth cannot produce an identity");
 const auto before=backend.allocator().statistics().liveImages;
 {ShadowVisibilitySurface surface(backend,{64,48},2);require(surface.bytes()==64U*48U*20U*2U,"Surface byte accounting");
  require(surface.visibility(0).image.image!=surface.visibility(1).image.image,"Each slot owns its surface");
  require(surface.identity(0).image.image!=surface.identity(1).image.image,"Each slot owns its identity");
  require(backend.allocator().statistics().liveImages==before+4,"Two images per slot");
  bool rejected=false;try{surface.identity(2);}catch(const std::out_of_range&){rejected=true;}require(rejected,"Slot bounds checked");}
 require(backend.allocator().statistics().liveImages==before,"Surface images released");
 require(ShadowVisibilitySurface::visibilityClear().color.float32[0]==-1,"Clear visibility rejects reuse");
 std::cout<<"Shadow visibility identity, budget and lifetime passed\n";
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
