from pathlib import Path
import sys,json,hashlib,subprocess,shutil,os
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_cleanup import inspect_tree,is_link
from artifact_budget import check,evaluate
from build_provenance import inputs,digest
assert root==Path('D:/Projects/FYP/Project/AzureRender')
clone=root/'build/q1-ramp-source';targets=[clone/'Project/AzureRender/build'/name for name in ['ninja-msvc-debug','ninja-msvc-release']]
def clone_state():
 diff=subprocess.check_output(['git','-C',str(clone),'diff','--binary'],stderr=subprocess.DEVNULL)
 modified=subprocess.check_output(['git','-C',str(clone),'diff','--name-only','-z']).decode('utf-8').split('\0')
 other=subprocess.check_output(['git','-C',str(clone),'ls-files','--others','--exclude-standard','-z']).decode('utf-8').split('\0')
 return dict(head=subprocess.check_output(['git','-C',str(clone),'rev-parse','HEAD'],text=True).strip(),diffSha256=hashlib.sha256(diff).hexdigest(),gitPointerSha256=digest(clone/'.git'),sourceFiles={n:digest(clone/n) for n in sorted(set(modified+other)) if n and (clone/n).is_file()})
state=clone_state();rows=[]
mounts=json.loads((root/'build/runs/20261107-210538-radiance-recomposition-e85c9c/image/frozen-inputs.json').read_text())['project']
assert not any(str(clone).lower() in p.lower() for p in mounts)
for target in targets:
 assert target.resolve()==target and root/'build/ninja-msvc-debug'!=target and root/'build/ninja-msvc-release'!=target
 assert not (target/'.keep').exists()
 assert not subprocess.check_output(['git','-C',str(clone),'ls-files','--',target.relative_to(clone).as_posix()])
 size,newest=inspect_tree(target);rows.append(dict(path=str(target),relative=target.relative_to(root).as_posix(),bytes=size,newest=newest))
cUsage=shutil.disk_usage('C:/');archiveBudget=evaluate(total=cUsage.total,free=cUsage.free,used=0,planned=(1900+32)*1024**2)
assert archiveBudget['allowed'],archiveBudget
assert check(root/'build',run=out,planned=3*1024**2)['allowed']
source=inputs(root)
main=json.loads((root/'build/runs/20261107-210538-radiance-recomposition-e85c9c/image/frozen-inputs.json').read_text())['products'];main={p:h for p,h in main.items() if '/ninja-msvc-' in p.replace('\\','/')}
assert all(digest(Path(p))==h for p,h in main.items())
record=dict(status='read-only-preflight-passed',clone=str(clone),cloneState=state,targets=rows,sourceInputs=source,mainProducts=main,archiveVolumeBudget=archiveBudget,currentMountsReferenceClone=False,scope='Only ignored generated build subdirectories; all modified and untracked source files in the linked worktree remain in place.')
(out/'preflight.json').write_text(json.dumps(record,indent=2))
text=(root/'build/maintenance/pack_preserved.py').read_text()
text=text.replace("a=p.parse_args()", "p.add_argument('--max-bytes',type=int,default=1900*1024**2);a=p.parse_args()")
needle="with out.open('xb') as raw, zstandard.ZstdCompressor"
assert needle in text
limit='''class LimitedSink:
 def __init__(self,raw):self.raw=raw;self.used=0
 def write(self,data):
  if self.used+len(data)>a.max_bytes:raise RuntimeError('Compressed archive exceeds declared byte quota')
  result=self.raw.write(data);self.used+=result;return result
 def flush(self):return self.raw.flush()
'''
text=text.replace(needle,limit+'\n'+needle,1).replace('.stream_writer(raw,closefd=False)', '.stream_writer(LimitedSink(raw),closefd=False)',1)
(out/'pack.py').write_text(text)
archive=Path('C:/Users/admin/.codex/archives/AzureRender/20261107/q1-debug-generated.tar.zst')
command=[sys.executable,'-X','utf8',str(out/'pack.py'),str(root),str(archive),rows[0]['relative'],'--max-bytes',str(1900*1024**2)]
(out/'archive-command.json').write_text(json.dumps(command,indent=2))
print(json.dumps({'status':record['status'],'targets':rows,'cloneSourceFilesPreserved':len(state['sourceFiles']),'archive':str(archive),'CFreeGiB':round(cUsage.free/2**30,2)}),flush=True)
