from pathlib import Path
import json,subprocess,time
out=Path(__file__).resolve().parent;command=json.loads((out/'archive-command.json').read_text())
started=time.monotonic()
with (out/'debug-archive.log').open('wb') as log:
 result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=600)
assert result.returncode==0,(out/'debug-archive.log').read_text(errors='replace')[-2500:]
archive=Path(command[5]);receipt=json.loads(archive.with_suffix(archive.suffix+'.receipt.json').read_text());assert receipt['status']=='verified'
(out/'debug-archive-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(dict(status=receipt['status'],files=receipt['files'],logicalBytes=receipt['logicalBytes'],archiveBytes=receipt['archiveBytes'],seconds=time.monotonic()-started)),flush=True)
