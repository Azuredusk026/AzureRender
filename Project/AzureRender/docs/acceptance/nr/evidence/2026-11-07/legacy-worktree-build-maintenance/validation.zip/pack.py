"""Pack preserved development directories, verify every tar payload, never prune."""
import argparse, hashlib, json, os, sys, tarfile, time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('output',type=Path);p.add_argument('inputs',nargs='+');p.add_argument('--max-bytes',type=int,default=1900*1024**2);a=p.parse_args()
root=a.root.resolve();out=a.output.resolve();vendor=root/'build/maintenance/reinstall-2026-10-29/environment/python-vendor';sys.path.insert(0,str(vendor));import zstandard
if out.exists():raise SystemExit('Output exists')
inputs=[(root/x).resolve() for x in a.inputs]
for source in inputs:
 if root not in source.parents or source==out or source in out.parents or not source.is_dir():raise SystemExit('Invalid source/output boundary')
records={};hashes={};count=0;logical=0;payload=0;started=time.time()
def digest_file(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
class HashReader:
 def __init__(self,fh):self.fh=fh;self.h=hashlib.sha256()
 def read(self,n=-1):
  b=self.fh.read(n);self.h.update(b);return b
out.parent.mkdir(parents=True,exist_ok=True)
class LimitedSink:
 def __init__(self,raw):self.raw=raw;self.used=0
 def write(self,data):
  if self.used+len(data)>a.max_bytes:raise RuntimeError('Compressed archive exceeds declared byte quota')
  result=self.raw.write(data);self.used+=result;return result
 def flush(self):return self.raw.flush()

with out.open('xb') as raw, zstandard.ZstdCompressor(level=6,threads=2).stream_writer(LimitedSink(raw),closefd=False) as compressed, tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT,dereference=False) as archive:
 for source in inputs:
  for base,dirs,files in os.walk(source,followlinks=False):
   dirs.sort();files.sort()
   for path in [Path(base),*(Path(base,n) for n in files)]:
    stat=path.lstat()
    if getattr(stat,'st_file_attributes',0)&1024:raise RuntimeError('Reparse point '+str(path))
    name=path.relative_to(root).as_posix();info=archive.gettarinfo(str(path),arcname=name)
    if info.isdir():archive.addfile(info);continue
    if not(info.isfile() or info.islnk()):raise RuntimeError('Unsupported type '+name)
    record={'size':stat.st_size,'mtime':stat.st_mtime_ns,'inode':stat.st_ino,'device':stat.st_dev}
    if info.isfile():
     with path.open('rb') as sourcefile:
      reader=HashReader(sourcefile);archive.addfile(info,reader);record['sha256']=reader.h.hexdigest()
     hashes[name]=record['sha256'];payload+=stat.st_size
    else:
     archive.addfile(info);record['link']=info.linkname
    after=path.stat()
    if (after.st_size,after.st_mtime_ns)!=(stat.st_size,stat.st_mtime_ns):raise RuntimeError('Source changed '+name)
    records[name]=record;count+=1;logical+=stat.st_size
    if count%10000==0:print(json.dumps({'phase':'pack','files':count,'logicalGiB':round(logical/2**30,2),'payloadGiB':round(payload/2**30,2),'seconds':round(time.time()-started)}),flush=True)
manifest=out.with_suffix(out.suffix+'.manifest.json');manifest.write_text(json.dumps(records,separators=(',',':')),encoding='utf-8')
print(json.dumps({'phase':'verify','files':count,'archiveGiB':round(out.stat().st_size/2**30,3)}),flush=True)
verified=set();links=0
with out.open('rb') as raw,zstandard.ZstdDecompressor().stream_reader(raw) as uncompressed,tarfile.open(fileobj=uncompressed,mode='r|') as archive:
 for member in archive:
  if member.isdir():continue
  if member.name not in records:raise RuntimeError('Unexpected member '+member.name)
  record=records[member.name]
  if member.islnk():
   if member.linkname!=record.get('link') or member.linkname not in verified:raise RuntimeError('Invalid hardlink '+member.name)
   links+=1
  elif member.isfile():
   h=hashlib.sha256();fh=archive.extractfile(member)
   for b in iter(lambda:fh.read(4*1024*1024),b''):h.update(b)
   if member.size!=record['size'] or h.hexdigest()!=record.get('sha256'):raise RuntimeError('Payload mismatch '+member.name)
  else:raise RuntimeError('Unexpected archive type')
  verified.add(member.name)
  if len(verified)%20000==0:print(json.dumps({'phase':'verify','files':len(verified)}),flush=True)
if len(verified)!=count:raise RuntimeError('Missing archive entries')
receipt={'status':'verified','root':str(root),'inputs':a.inputs,'files':count,'hardlinks':links,'logicalBytes':logical,'payloadBytes':payload,'archiveBytes':out.stat().st_size,'archiveSha256':digest_file(out),'manifestSha256':digest_file(manifest),'seconds':time.time()-started}
out.with_suffix(out.suffix+'.receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
