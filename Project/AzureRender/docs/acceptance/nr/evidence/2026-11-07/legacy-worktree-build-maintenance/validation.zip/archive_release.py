from pathlib import Path
import json,subprocess,time,sys,shutil
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import evaluate
first=json.loads((out/'debug-archive-receipt.json').read_text());usage=shutil.disk_usage('C:/')
budget=evaluate(total=usage.total,free=usage.free,used=first['archiveBytes'],planned=544*1024**2);assert budget['allowed'],budget
command=json.loads((out/'archive-command.json').read_text());command[5]=str(Path('C:/Users/admin/.codex/archives/AzureRender/20261107/q1-release-generated.tar.zst'));command[6]=command[6].replace('ninja-msvc-debug','ninja-msvc-release');command[-1]=str(512*1024**2)
(out/'release-archive-command.json').write_text(json.dumps(command,indent=2));started=time.monotonic()
with (out/'release-archive.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=600)
assert result.returncode==0,(out/'release-archive.log').read_text(errors='replace')[-2500:]
archive=Path(command[5]);receipt=json.loads(archive.with_suffix(archive.suffix+'.receipt.json').read_text());assert receipt['status']=='verified'
(out/'release-archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(dict(status=receipt['status'],files=receipt['files'],logicalBytes=receipt['logicalBytes'],archiveBytes=receipt['archiveBytes'],seconds=time.monotonic()-started)),flush=True)
