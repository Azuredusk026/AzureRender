from pathlib import Path
import subprocess,sys,os,json,hashlib,shutil,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
before=json.loads((out/'preflight.json').read_text())
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
python=str(root/'build/reinstall-environment/venv/Scripts/python.exe')
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
results=[]
for config in ['Debug','Release']:
 build=root/('build/ninja-msvc-'+config.lower())
 command=[str(root/'tools/msvc_env.bat'),python,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config',config,'--test-target','AzureMaterialDocumentTests']
 for label,args in [('build',command),('ctest',[ctest,'--test-dir',str(build),'-C',config,'-R','^AzureAssets.MaterialDocument$','--output-on-failure'])]:
  start=time.monotonic()
  with (out/(config.lower()+'-'+label+'.log')).open('w',encoding='utf-8') as log:
   result=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  row=dict(configuration=config,check=label,exitCode=result.returncode,seconds=time.monotonic()-start)
  results.append(row);print(json.dumps(row),flush=True)
  assert result.returncode==0,row
assert inputs(root)==before['sourceInputs']
assert all(digest(Path(p))==h for p,h in before['mainProducts'].items())
clone=Path(before['clone']);assert all(digest(clone/n)==h for n,h in before['cloneState']['sourceFiles'].items())
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--','src','tests','tools/endfield_native','tools/test_native_character_surfaces.py','docs/acceptance/p5'],stderr=subprocess.DEVNULL)).hexdigest()
assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
report=dict(status='passed',checks=results,sourceInputsUnchanged=True,mainProductsUnchanged=True,cloneSourceFilesPreserved=len(before['cloneState']['sourceFiles']),protectedDiffSha256=protected,volumeFreeBytes=shutil.disk_usage(root).free)
(out/'postcheck.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report),flush=True)
