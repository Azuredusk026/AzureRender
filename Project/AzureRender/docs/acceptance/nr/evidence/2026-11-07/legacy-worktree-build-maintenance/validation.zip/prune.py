"""Prune only the two externally archived, ignored builds in the inactive q1 worktree."""
from pathlib import Path
import sys,json,subprocess,hashlib,shutil,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_cleanup import remove_artifact,is_link
from build_provenance import inputs,digest
assert root==Path('D:/Projects/FYP/Project/AzureRender')
before=json.loads((out/'preflight.json').read_text());preview=json.loads((out/'verified-preview.json').read_text());assert preview['status']=='verified-candidates'
clone=root/'build/q1-ramp-source';expected={clone/'Project/AzureRender/build'/name for name in ['ninja-msvc-debug','ninja-msvc-release']}
actual={Path(r['path']) for r in preview['items']};assert actual==expected and len(actual)==2
assert not actual.intersection({root/'build/ninja-msvc-debug',root/'build/ninja-msvc-release'})
def clone_state():
 diff=subprocess.check_output(['git','-C',str(clone),'diff','--binary'],stderr=subprocess.DEVNULL)
 modified=subprocess.check_output(['git','-C',str(clone),'diff','--name-only','-z'],stderr=subprocess.DEVNULL).decode('utf-8').split('\0');other=subprocess.check_output(['git','-C',str(clone),'ls-files','--others','--exclude-standard','-z']).decode('utf-8').split('\0')
 return dict(head=subprocess.check_output(['git','-C',str(clone),'rev-parse','HEAD'],text=True).strip(),diffSha256=hashlib.sha256(diff).hexdigest(),gitPointerSha256=digest(clone/'.git'),sourceFiles={n:digest(clone/n) for n in sorted(set(modified+other)) if n and (clone/n).is_file()})
assert clone_state()==before['cloneState'] and inputs(root)==before['sourceInputs']
assert all(digest(Path(p))==h for p,h in before['mainProducts'].items())
repo=root.parents[1];tracked=set()
for tree in [repo,clone]:
 tracked.update((tree/p).resolve() for p in subprocess.check_output(['git','-C',str(tree),'ls-files','-z']).decode('utf-8').split('\0') if p)
for row in preview['items']:
 target=Path(row['path']);assert target.resolve()==target and not (target/'.keep').exists()
 assert digest(Path(row['archive']))==row['archiveSha256'] and digest(Path(row['manifest']))==row['manifestSha256']
 size,newest=remove_artifact(root/'build',target,tracked)
 original=next(r for r in before['targets'] if r['path']==str(target));assert size==row['bytes'] and newest==original['newest']
usageBefore=shutil.disk_usage(root/'build').free;result=dict(status='applying',items=[],beforeFreeBytes=usageBefore,archivesVerified=True)
(out/'prune-result.json').write_text(json.dumps(result,indent=2))
for row in preview['items']:
 target=Path(row['path']);print('Pruning verified generated build: '+str(target),flush=True)
 size,_=remove_artifact(root/'build',target,tracked,apply=True);assert not target.exists()
 result['items'].append(dict(path=str(target),bytes=size,files=row['files']));(out/'prune-result.json').write_text(json.dumps(result,indent=2))
assert clone_state()==before['cloneState'] and inputs(root)==before['sourceInputs']
assert all(digest(Path(p))==h for p,h in before['mainProducts'].items())
h=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--','src','tests','tools/endfield_native','tools/test_native_character_surfaces.py','docs/acceptance/p5'],stderr=subprocess.DEVNULL)).hexdigest();assert h==preview['protectedDiffSha256']
after=shutil.disk_usage(root/'build').free;result.update(status='pruned',afterFreeBytes=after,actualFreeIncreaseBytes=after-usageBefore,sourceWorktreePreserved=True,mainProductsUnchanged=True,protectedDiffSha256=h)
(out/'prune-result.json').write_text(json.dumps(result,indent=2));(root/'build/maintenance/20261107-q1-legacy-build-applied.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
