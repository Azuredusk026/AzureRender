from pathlib import Path
import sys,json,subprocess,hashlib,os
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_cleanup import is_link
from build_provenance import inputs,digest
before=json.loads((out/'preflight.json').read_text());clone=Path(before['clone']);assert clone==root/'build/q1-ramp-source'
def clone_state():
 diff=subprocess.check_output(['git','-C',str(clone),'diff','--binary'],stderr=subprocess.DEVNULL)
 modified=subprocess.check_output(['git','-C',str(clone),'diff','--name-only','-z'],stderr=subprocess.DEVNULL).decode('utf-8').split('\0')
 other=subprocess.check_output(['git','-C',str(clone),'ls-files','--others','--exclude-standard','-z']).decode('utf-8').split('\0')
 return dict(head=subprocess.check_output(['git','-C',str(clone),'rev-parse','HEAD'],text=True).strip(),diffSha256=hashlib.sha256(diff).hexdigest(),gitPointerSha256=digest(clone/'.git'),sourceFiles={n:digest(clone/n) for n in sorted(set(modified+other)) if n and (clone/n).is_file()})
assert clone_state()==before['cloneState']
assert subprocess.run(['git','-C',str(clone),'diff','--cached','--quiet']).returncode==0
assert inputs(root)==before['sourceInputs'] and all(digest(Path(p))==h for p,h in before['mainProducts'].items())
rows=[]
for name,commandFile,target in zip(['debug','release'],['archive-command.json','release-archive-command.json'],before['targets']):
 command=json.loads((out/commandFile).read_text());archive=Path(command[5]);receipt=json.loads((out/(name+'-archive-receipt.json')).read_text());assert receipt['status']=='verified'
 manifest=archive.with_suffix(archive.suffix+'.manifest.json');assert digest(archive)==receipt['archiveSha256'] and digest(manifest)==receipt['manifestSha256']
 records=json.loads(manifest.read_text());base=Path(target['path']);prefix=base.relative_to(root).as_posix()+'/'
 assert len(records)==receipt['files'] and all(p.startswith(prefix) for p in records)
 current={}
 for path,dirs,files in os.walk(base,followlinks=False):
  parent=Path(path);assert not is_link(parent)
  for child in dirs:assert not is_link(parent/child)
  for child in files:
   p=parent/child;assert not is_link(p);current[p.relative_to(root).as_posix()]=p
 assert set(current)==set(records)
 for member,path in current.items():
  record=records[member];assert 'link' not in record
  stat=path.stat();assert stat.st_size==record['size'] and stat.st_mtime_ns==record['mtime'] and digest(path)==record['sha256']
 assert not (base/'.keep').exists() and not subprocess.check_output(['git','-C',str(clone),'ls-files','--',base.relative_to(clone).as_posix()])
 rows.append(dict(path=str(base),files=len(current),bytes=sum(r['size'] for r in records.values()),archive=str(archive),archiveSha256=receipt['archiveSha256'],manifest=str(manifest),manifestSha256=receipt['manifestSha256']))
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--','src','tests','tools/endfield_native','tools/test_native_character_surfaces.py','docs/acceptance/p5'],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
result=dict(status='verified-candidates',items=rows,sourceWorktreePreserved=True,cloneState=before['cloneState'],mainProductsUnchanged=True,protectedDiffSha256=protected)
(out/'verified-preview.json').write_text(json.dumps(result,indent=2));(root/'build/maintenance/20261107-q1-legacy-build-preview.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(status=result['status'],items=rows,cloneSourceFilesPreserved=len(before['cloneState']['sourceFiles']))),flush=True)
