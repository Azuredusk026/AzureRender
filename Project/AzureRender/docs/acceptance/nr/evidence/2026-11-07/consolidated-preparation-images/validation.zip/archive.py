from pathlib import Path
import json,zipfile,sys
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
native=json.loads((out/'image/results.json').read_text());assert native['status']=='passed'
expected=json.loads((root/'docs/acceptance/nr/evidence/2026-11-07/binary-material-images/results.json').read_text(encoding='utf-8'))['sourceInputs'];assert inputs(root)==expected
target=root/'docs/acceptance/nr/evidence/2026-11-07/consolidated-preparation-images';target.mkdir(parents=True,exist_ok=True)
members={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and p.suffix in {'.py','.json','.log'}}
archive=target/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
    for name,path in members.items():z.write(path,name)
result=dict(status='passed-original-four-frame-rgb-zero-gate',native=native,sourceBase='e6c5b3e',all1615SourceInputsMatchAcceptedCandidate=True,
    sceneLoad=json.loads((out/'image/frames/capture_manifest.json').read_text())['sceneLoad'],
    diagnosticBudget=json.loads((out/'budget-after.json').read_text()),framePerformance='not-measured',overallVisual='failed-user-review',
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=digest(archive),members={n:digest(p) for n,p in members.items()}))
(target/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=result['status'],archiveBytes=archive.stat().st_size)))
