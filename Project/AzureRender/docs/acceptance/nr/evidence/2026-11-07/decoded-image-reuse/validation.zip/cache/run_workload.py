from pathlib import Path
import subprocess,os,json,re,sys,time
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
assert check(root/'build',run=out,planned=16*1024**2,diagnostic=True)['allowed']
requests=json.loads((out/'requests.json').read_text());assert len(requests)==1568 and all(r['origin']['mode'] in ['range','embedded-uri'] for r in requests)
env=dict(os.environ);env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9');env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH'];bat=['cmd','/d','/c',str(root/'tools/msvc_env.bat')]
flags=['cl','/nologo','/O2','/MD','/EHsc','/std:c++17','/utf-8','/DNDEBUG','/DNOMINMAX','/I'+str(root/'src'),'/I'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'),'/ID:/Tools/VulkanSDK/1.4.350.0/Include','/c']
with (out/'workload-compile.log').open('wb') as log:p=subprocess.run(bat+flags+[str(out/'workload.cpp'),'/Fo'+str(out/'workload.obj')],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(out/'workload-compile.log').read_text(errors='replace')[-4000:]
response=(root/'build/runs/20261107-161237-cpu-asset-load-stages-3ff597/link.rsp').read_text();response=re.sub(r'^"[^"]+profile\.obj"',lambda m:'"'+str(out/'workload.obj')+'"',response)
response=re.sub(r'/(out|implib|pdb|MAP):"[^"]+"',lambda m:'/'+m[1]+':"'+str(out/('workload.'+{'out':'exe','implib':'lib','pdb':'pdb','MAP':'map'}[m[1]]))+'"',response)+' bcrypt.lib';(out/'workload-link.rsp').write_text(response)
with (out/'workload-link.log').open('wb') as log:p=subprocess.run(bat+['link','@'+str(out/'workload-link.rsp')],cwd=root/'build/ninja-msvc-release',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(out/'workload-link.log').read_text(errors='replace')[-4000:]
source=inputs(root);products={str(root/'build/ninja-msvc-release'/p):digest(root/'build/ninja-msvc-release'/p) for p in ['AzurePlayer.exe','AzureRenderCore.lib']}
for name,budget in [('disabled',0),('bounded',128*1024**2)]:
    command=[str(out/'workload.exe'),str(out/'requests.json'),str(budget),str(out/(name+'.json'))];(out/(name+'-command.json')).write_text(json.dumps(command,indent=2));print('Evaluating '+name,flush=True)
    with (out/(name+'-driver.log')).open('wb') as log:p=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    assert p.returncode==0,(out/(name+'-driver.log')).read_text(errors='replace')[-4000:]
a=json.loads((out/'disabled.json').read_text());b=json.loads((out/'bounded.json').read_text());assert a['rows']==b['rows'] and len(a['rows'])==1568
assert b['statistics']['peakRetainedBytes']<=128*1024**2 and a['statistics']['hits']==0
assert source==inputs(root) and all(digest(Path(p))==h for p,h in products.items())
reduction=1-b['acquireMs']/a['acquireMs'];result=dict(status='qualified' if reduction>=.3 else 'insufficient',requests=1568,allDecodedBytesMipsAndMetadataEqual=True,disabledMs=a['acquireMs'],boundedMs=b['acquireMs'],reduction=reduction,boundedStatistics=b['statistics'],sourceAndProductsUnchanged=True,scope='One same-binary CPU workload pair in recorded resource order; input read and signature hashing excluded from acquire timing; no frame benefit claim')
(out/'workload-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
