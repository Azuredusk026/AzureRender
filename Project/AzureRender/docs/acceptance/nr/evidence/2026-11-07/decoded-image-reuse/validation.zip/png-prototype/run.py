from pathlib import Path
import subprocess,json,os,re,sys,time,statistics
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from artifact_budget import check
assert check(root/'build',run=out,planned=24*1024**2,diagnostic=True)['allowed']
targets=json.loads((root/'build/runs/20261107-162522-binary-material-images-621f66/targets.json').read_text());paths={Path(p) for t in targets for b in t['bindings'] for p in b['textures'].values()};eligible=[]
for p in paths:
    with p.open('rb') as stream:header=stream.read(33)
    if len(header)>=33 and header[:8]==b'\x89PNG\r\n\x1a\n' and header[24]==8 and header[25] in (2,6) and header[28]==0:eligible.append(p)
eligible.sort(key=lambda p:p.stat().st_size,reverse=True);corpus=eligible[:6]+eligible[-2:];assert len(set(corpus))==8
(out/'corpus.json').write_text(json.dumps([str(p) for p in corpus],indent=2));source=inputs(root);original={str(p):digest(p) for p in corpus}
env=dict(os.environ);env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9');env['PATH']=str(root/'build/ninja-msvc-release')+';'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin')+';'+env['PATH']
bat=['cmd','/d','/c',str(root/'tools/msvc_env.bat')];flags=['cl','/nologo','/O2','/MD','/EHsc','/std:c++17','/utf-8','/DNDEBUG','/DNOMINMAX','/I'+str(root/'src'),'/I'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'),'/ID:/Tools/VulkanSDK/1.4.350.0/Include','/c']
for name in ['measure','png']:
    with (out/(name+'-compile.log')).open('wb') as log:p=subprocess.run(bat+flags+[str(out/(name+'.cpp')),'/Fo'+str(out/(name+'.obj'))],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    assert p.returncode==0,(out/(name+'-compile.log')).read_text(errors='replace')[-4000:]
response=(root/'build/runs/20261107-161237-cpu-asset-load-stages-3ff597/link.rsp').read_text()
response=re.sub(r'^"[^"]+profile\.obj"',lambda m:'"'+str(out/'measure.obj')+'" "'+str(out/'png.obj')+'"',response)
response=re.sub(r'/(out|implib|pdb|MAP):"[^"]+"',lambda m:'/'+m[1]+':"'+str(out/('measure.'+{'out':'exe','implib':'lib','pdb':'pdb','MAP':'map'}[m[1]]))+'"',response)+' "'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/lib/libpng16.lib')+'"'
(out/'link.rsp').write_text(response)
with (out/'link.log').open('wb') as log:p=subprocess.run(bat+['link','@'+str(out/'link.rsp')],cwd=root/'build/ninja-msvc-release',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(out/'link.log').read_text(errors='replace')[-4000:];print('PNG prototype built',flush=True)
with (out/'driver.log').open('wb') as log:p=subprocess.run([str(out/'measure.exe'),str(out/'corpus.json'),str(out/'measurements.json')],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
assert p.returncode==0,(out/'driver.log').read_text(errors='replace')[-4000:]
rows=json.loads((out/'measurements.json').read_text());baseline=sum(statistics.median(s['ms'] for s in r['samples'] if not s['candidate']) for r in rows);candidate=sum(statistics.median(s['ms'] for s in r['samples'] if s['candidate']) for r in rows)
assert source==inputs(root) and all(digest(Path(p))==h for p,h in original.items())
result=dict(status='qualified-local-prototype' if candidate<=baseline*.7 else 'insufficient-local-benefit',images=len(rows),allBytesAndMetadataEqual=True,baselineMedianSumMs=baseline,candidateMedianSumMs=candidate,reduction=1-candidate/baseline,inputHashes=original,sourceAndInputsUnchanged=True,scope='Eight native PNG inputs, three alternating pairs per image, existing libpng 1.6.58; no frame benefit claim')
(out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
