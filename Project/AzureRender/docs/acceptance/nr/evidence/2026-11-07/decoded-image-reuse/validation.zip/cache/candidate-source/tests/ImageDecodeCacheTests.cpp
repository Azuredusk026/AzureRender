#include "assets/AssetLoadCache.hpp"
#include <stb_image_write.h>
#include <algorithm>
#include <chrono>
#include <fstream>
#include <iostream>
using namespace azurerender;
namespace {
void require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
template<class F>void reject(F action){bool failed=false;try{action();}catch(const std::exception&){failed=true;}require(failed,"Invalid or cancelled decode must fail");}
std::vector<unsigned char> image(unsigned char value){
    const unsigned char pixels[]={value,21,37,255,17,31,47,255};std::vector<unsigned char> bytes;
    const auto write=[](void* context,void* data,int size){auto& out=*static_cast<std::vector<unsigned char>*>(context);auto* first=static_cast<unsigned char*>(data);out.insert(out.end(),first,first+size);};
    require(stbi_write_png_to_func(write,&bytes,2,1,4,pixels,8)!=0,"Cannot encode cache fixture");return bytes;
}
void identity_and_recovery(){
    ImageDecodeCache cache(1024*1024);const auto bytes=image(13);const auto first=cache.acquire(bytes),same=cache.acquire(std::vector<unsigned char>(bytes));
    require(first==same&&first->rgba8[0]==13,"Equal owned input bytes must share an immutable decoded result");
    const auto changed=cache.acquire(image(14));require(changed!=first&&changed->rgba8[0]==14,"Changed encoded content must decode independently");
    const auto retained=cache.statistics().retainedBytes;reject([&]{cache.acquire({1,2,3});});
    require(cache.statistics().retainedBytes==retained&&cache.acquire(bytes)==first,"Decode failure must preserve existing cache entries");
    reject([&]{cache.acquire(bytes,[]{return true;});});unsigned checks=0;
    reject([&]{cache.acquire(bytes,[&]{return ++checks==2;});});
    require(cache.acquire(bytes)==first,"Cancellation must leave cached content usable");
    cache.clear();require(cache.statistics().retainedBytes==0&&cache.statistics().requests==0&&first->rgba8[0]==13,"Clear must preserve consumer-owned images and reset cache statistics");
    require(cache.acquire(bytes)!=first,"Cleared cache must create a new decoded owner");
}
void eviction_and_oversize(){
    const auto a=image(10),b=image(20),c=image(30);const auto limit=2*(std::max({a.size(),b.size(),c.size()})+8);
    ImageDecodeCache cache(limit);const auto first=cache.acquire(a),second=cache.acquire(b);
    require(cache.acquire(a)==first,"Recent access must retain identity");cache.acquire(c);
    require(cache.acquire(a)==first&&cache.acquire(b)!=second&&second->rgba8[0]==20,"Eviction must follow recent use and preserve borrowed owners");
    require(cache.statistics().retainedBytes<=limit&&cache.statistics().peakRetainedBytes<=limit,"Retained payload must respect its capacity");
    ImageDecodeCache small(1),disabled(0);require(small.acquire(a)!=small.acquire(a)&&small.statistics().retainedBytes==0,"Oversized inputs must decode without retention");
    require(disabled.acquire(a)->rgba8==first->rgba8&&disabled.statistics().retainedBytes==0,"Zero capacity must retain normal decode behavior");
}
void material_workflow(){
    auto path=std::filesystem::temp_directory_path()/("azure-decode-cache-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count())+".png");
    auto cleanup=std::unique_ptr<void,std::function<void(void*)>>(&path,[&](void*){std::error_code error;std::filesystem::remove(path,error);});
    const auto bytes=image(127);{std::ofstream file(path,std::ios::binary);file.write(reinterpret_cast<const char*>(bytes.data()),bytes.size());}
    auto data=MaterialData::defaults("azure.profile");data.textures["0"]={{"asset","00000000-0000-4000-8000-000000000001"},{"usage","albedo"}};
    data.surface["textures"]=nlohmann::json::array({{{"source",0}}});data.surface["materials"][0]["pbrMetallicRoughness"]={{"baseColorTexture",{{"index",0}}}};
    const auto resolve=[&](const auto&){return path;};ImageDecodeCache cache(1024*1024);
    const auto first=interpretMaterialData(data,resolve,nullptr,cache),baseline=data.interpret(resolve);
    require(first.baseColorPixels==baseline.baseColorPixels,"Cached material interpretation must preserve ordinary decoding");
    data.surface["materials"][0]["pbrMetallicRoughness"]["baseColorFactor"]={.5,.75,.25,.5};
    const auto tinted=interpretMaterialData(data,resolve,nullptr,cache),reference=data.interpret(resolve);
    require(tinted.baseColorPixels==reference.baseColorPixels&&tinted.baseColorPixels!=first.baseColorPixels&&cache.statistics().hits==1,"Independent material factors must preserve shared raw pixels");
    require(cache.acquire(bytes)->rgba8[0]==127,"Material interpretation must retain immutable source samples");
}
}
int main(int argc,char** argv)try{
    identity_and_recovery();eviction_and_oversize();material_workflow();
    require(argc==2,"Expected public model fixture");ImageDecodeCache cache(1024*1024);
    const auto first=loadGltfAsset(argv[1],cache),second=loadGltfAsset(argv[1],cache);
    require(first.vertices.size()==second.vertices.size()&&first.indices==second.indices&&cache.statistics().hits>0,"Independent model loads must share decoded image inputs");
    std::cout<<"PASS immutable identity, failure/cancellation, bounded LRU, oversize, material and model workflows\n";return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
