#include "assets/image/ImageCodec.hpp"
#include <nlohmann/json.hpp>
#include <fstream>
#include <iostream>
#include <chrono>
using namespace azurerender;
DecodedImage candidatePng(const std::vector<unsigned char>&);
int main(int argc,char** argv)try{
    if(argc!=3)return 2;std::ifstream corpus(argv[1]);nlohmann::json paths;corpus>>paths;nlohmann::json rows=nlohmann::json::array();
    for(const auto& path:paths){
        std::ifstream stream(std::filesystem::u8path(path.get<std::string>()),std::ios::binary|std::ios::ate);const auto size=stream.tellg();stream.seekg(0);std::vector<unsigned char> bytes(static_cast<std::size_t>(size));stream.read(reinterpret_cast<char*>(bytes.data()),size);if(!stream)throw std::runtime_error("Cannot read corpus image");
        auto baseline=decodeImageBytes(bytes),candidate=candidatePng(bytes);
        if(baseline.rgba8!=candidate.rgba8||baseline.width!=candidate.width||baseline.height!=candidate.height||baseline.sourceChannels!=candidate.sourceChannels||baseline.precision!=candidate.precision||baseline.colorSpace!=candidate.colorSpace||baseline.sourceLosses!=candidate.sourceLosses)throw std::runtime_error("PNG decode result differs");
        nlohmann::json samples=nlohmann::json::array();
        for(unsigned round=0;round<3;++round)for(unsigned order=0;order<2;++order){
            const bool useCandidate=(round+order)%2;const auto start=std::chrono::steady_clock::now();auto image=useCandidate?candidatePng(bytes):decodeImageBytes(bytes);const auto elapsed=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
            if(image.rgba8!=baseline.rgba8)throw std::runtime_error("Repeated PNG bytes differ");samples.push_back({{"candidate",useCandidate},{"ms",elapsed}});
        }
        rows.push_back({{"path",path},{"pixels",baseline.rgba8.size()},{"channels",baseline.sourceChannels},{"equal",true},{"samples",samples}});std::ofstream(argv[2])<<rows.dump(2);std::cout<<"Compared "<<path<<std::endl;
    }
}catch(const std::exception& error){std::cerr<<error.what()<<std::endl;return 1;}
