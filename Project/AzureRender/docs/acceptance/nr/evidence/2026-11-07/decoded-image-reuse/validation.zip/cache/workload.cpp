#include "assets/image/ImageDecodeCache.hpp"
#include <windows.h>
#include <bcrypt.h>
#include <array>
#include <chrono>
#include <fstream>
#include <iostream>
using namespace azurerender;
std::string sha256(const void* data,std::size_t bytes){
    BCRYPT_ALG_HANDLE algorithm=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;
    if(BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0||BCryptCreateHash(algorithm,&hash,nullptr,0,nullptr,0,0)<0)throw std::runtime_error("SHA256 initialization failed");
    const auto updated=BCryptHashData(hash,const_cast<PUCHAR>(static_cast<const UCHAR*>(data)),static_cast<ULONG>(bytes),0);std::array<UCHAR,32> result{};
    const auto finished=BCryptFinishHash(hash,result.data(),32,0);BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(algorithm,0);if(updated<0||finished<0)throw std::runtime_error("SHA256 failed");
    std::string text;for(auto value:result){text+="0123456789abcdef"[value>>4];text+="0123456789abcdef"[value&15];}return text;
}
std::string signature(const DecodedImage& image){
    nlohmann::json metadata={{"width",image.width},{"height",image.height},{"channels",image.sourceChannels},{"precision",int(image.precision)},
        {"colorSpace",int(image.colorSpace)},{"compression",image.sourceCompression},{"losses",image.sourceLosses},
        {"rgba8",sha256(image.rgba8.data(),image.rgba8.size())},{"rgba16",sha256(image.rgba16.data(),image.rgba16.size()*2)},
        {"rgba32",sha256(image.rgba32.data(),image.rgba32.size()*4)},{"mips",nlohmann::json::array()}};
    for(const auto& mip:image.mipLevels)metadata["mips"].push_back({{"width",mip.width},{"height",mip.height},{"sha256",sha256(mip.rgba8.data(),mip.rgba8.size())}});
    const auto text=metadata.dump();return sha256(text.data(),text.size());
}
int main(int argc,char** argv)try{
    if(argc!=4)return 2;std::ifstream file(argv[1]);nlohmann::json requests;file>>requests;ImageDecodeCache cache(std::stoull(argv[2]));
    nlohmann::json report={{"rows",nlohmann::json::array()},{"acquireMs",0.0}};const auto start=std::chrono::steady_clock::now();unsigned index=0;
    for(const auto& request:requests){
        const auto& origin=request.at("origin");std::vector<unsigned char> bytes;
        std::ifstream input(std::filesystem::u8path(origin.at("path").get<std::string>()),std::ios::binary);
        if(origin.at("mode")=="range"){
            input.seekg(origin.at("offset").get<std::streamoff>());bytes.resize(origin.at("length").get<std::size_t>());
            input.read(reinterpret_cast<char*>(bytes.data()),bytes.size());if(!input)throw std::runtime_error("Cannot read image reference");
        }else{
            const std::string text{std::istreambuf_iterator<char>(input),{}};nlohmann::json document;
            if(text.compare(0,4,"glTF")==0){std::uint32_t length=0;for(unsigned i=0;i<4;++i)length|=std::uint32_t(static_cast<unsigned char>(text.at(12+i)))<<(i*8);document=nlohmann::json::parse(text.substr(20,length));}
            else document=nlohmann::json::parse(text);
            const auto uri=document.at("images").at(origin.at("imageIndex").get<unsigned>()).at("uri").get<std::string>();const auto payload=uri.substr(uri.find(',')+1);
            const std::string alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";unsigned value=0;int bits=-8;
            for(unsigned char ch:payload){if(ch=='=')break;const auto part=alphabet.find(ch);if(part==std::string::npos)throw std::runtime_error("Invalid embedded base64");value=(value<<6)|static_cast<unsigned>(part);bits+=6;if(bits>=0){bytes.push_back(static_cast<unsigned char>(value>>bits));bits-=8;}}
        }
        if(sha256(bytes.data(),bytes.size())!=request.at("sha256"))throw std::runtime_error("Image input digest changed");
        const auto begin=std::chrono::steady_clock::now();const auto decoded=cache.acquire(bytes);const auto elapsed=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
        report["acquireMs"]=report["acquireMs"].get<double>()+elapsed;report["rows"].push_back({{"source",request.at("source")},{"signature",signature(*decoded)}});
        if(++index%128==0){std::ofstream(argv[3])<<report.dump(2);std::cout<<"Decoded "<<index<<" inputs"<<std::endl;}
    }
    const auto stats=cache.statistics();report["statistics"]={{"requests",stats.requests},{"hits",stats.hits},{"misses",stats.misses},{"retainedBytes",stats.retainedBytes},{"peakRetainedBytes",stats.peakRetainedBytes},{"decodeMs",stats.decodeMs}};
    report["wallMs"]=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();report["status"]="completed";std::ofstream(argv[3])<<report.dump(2);std::cout<<"PASS completed image workload"<<std::endl;
}catch(const std::exception& error){std::cerr<<error.what()<<std::endl;return 1;}
