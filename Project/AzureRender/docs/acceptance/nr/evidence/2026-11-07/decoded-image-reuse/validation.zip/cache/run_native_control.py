from pathlib import Path
import subprocess,os,re,json,sys
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261107-162522-binary-material-images-621f66';sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
env=dict(os.environ);env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9');env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH'];bat=['cmd','/d','/c',str(root/'tools/msvc_env.bat')]
flags=['cl','/nologo','/O2','/MD','/EHsc','/std:c++17','/utf-8','/DNDEBUG','/DNOMINMAX','/I'+str(root/'src'),'/I'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'),'/ID:/Tools/VulkanSDK/1.4.350.0/Include','/c'];source=inputs(root)
with (out/'native-control-compile.log').open('wb') as log:p=subprocess.run(bat+flags+[str(out/'native-control.cpp'),'/Fo'+str(out/'native-control.obj')],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(out/'native-control-compile.log').read_text(errors='replace')[-3000:]
response=(root/'build/runs/20261107-161237-cpu-asset-load-stages-3ff597/link.rsp').read_text();response=re.sub(r'^"[^"]+profile\.obj"',lambda m:'"'+str(out/'native-control.obj')+'"',response)
response=re.sub(r'/(out|implib|pdb|MAP):"[^"]+"',lambda m:'/'+m[1]+':"'+str(out/('native-control.'+{'out':'exe','implib':'lib','pdb':'pdb','MAP':'map'}[m[1]]))+'"',response)+' bcrypt.lib';(out/'native-control-link.rsp').write_text(response)
with (out/'native-control-link.log').open('wb') as log:p=subprocess.run(bat+['link','@'+str(out/'native-control-link.rsp')],cwd=root/'build/ninja-msvc-release',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(out/'native-control-link.log').read_text(errors='replace')[-3000:]
command=[str(out/'native-control.exe'),str(out/'native-targets.json'),str(out/'native-control.json')];(out/'native-control-command.json').write_text(json.dumps(command,indent=2))
with (out/'native-control-driver.log').open('wb') as log:p=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
assert p.returncode==0,(out/'native-control-driver.log').read_text(errors='replace')[-3000:]
baseline=[r for name in ['candidate-floor.json','candidate.json'] for r in json.loads((prior/name).read_text()) if r['kind']=='binding'];candidate=[r for r in json.loads((out/'native-control.json').read_text()) if r['kind']=='binding']
assert len(baseline)==len(candidate)==16 and all(x['path']==y['path'] and x['signature']==y['signature'] for x,y in zip(baseline,candidate))
frozen=json.loads((prior/'input-references.json').read_text())['files'];assert all(digest(Path(p))==h for p,h in frozen.items());assert source==inputs(root)
result=dict(status='passed',materials=16,allPixelAndPackedSignaturesEqual=True,all115FrozenInputsEqual=True,sourceInputsUnchanged=True,executableSha256=digest(out/'native-control.exe'),scope='Data-only cached model and material paths in current production library; shader packing, 13 pixel fields, import settings, mip/render policy; dummy stage timer fields excluded; no native frame claim')
(out/'native-control-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
