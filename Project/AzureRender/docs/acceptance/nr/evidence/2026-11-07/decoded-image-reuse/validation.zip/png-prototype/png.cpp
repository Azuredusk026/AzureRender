#include "assets/image/ImageCodec.hpp"
#include <png.h>
#include <memory>
#include <cstring>
#include <cstdio>
#include <stdexcept>
using namespace azurerender;
namespace {
struct Input {const std::vector<unsigned char>& bytes;std::size_t offset=0;char error[256]{};std::vector<unsigned char> pixels;std::vector<png_bytep> rows;};
void failure(png_structp png,png_const_charp message){auto* input=static_cast<Input*>(png_get_error_ptr(png));std::snprintf(input->error,sizeof(input->error),"%s",message);png_longjmp(png,1);}
void warning(png_structp,png_const_charp){}
void read(png_structp png,png_bytep target,png_size_t count){auto* input=static_cast<Input*>(png_get_io_ptr(png));if(count>input->bytes.size()-input->offset)png_error(png,"Truncated PNG");std::memcpy(target,input->bytes.data()+input->offset,count);input->offset+=count;}
}
DecodedImage candidatePng(const std::vector<unsigned char>& bytes){
    // Heap state remains valid across the decoder's longjmp error path.
    const auto input=std::make_unique<Input>(Input{bytes});
    auto* png=png_create_read_struct(PNG_LIBPNG_VER_STRING,input.get(),failure,warning);if(!png)throw std::runtime_error("Cannot create PNG decoder");
    auto* info=png_create_info_struct(png);if(!info){png_destroy_read_struct(&png,nullptr,nullptr);throw std::runtime_error("Cannot create PNG info");}
    if(setjmp(png_jmpbuf(png))){png_destroy_read_struct(&png,&info,nullptr);throw std::runtime_error(input->error);}
    png_set_read_fn(png,input.get(),read);png_set_user_limits(png,8192,8192);png_set_chunk_malloc_max(png,64*1024*1024);
    png_read_info(png,info);const auto width=png_get_image_width(png,info),height=png_get_image_height(png,info);
    const auto color=png_get_color_type(png,info);if(png_get_bit_depth(png,info)!=8||(color!=PNG_COLOR_TYPE_RGB&&color!=PNG_COLOR_TYPE_RGBA)||png_get_interlace_type(png,info)!=PNG_INTERLACE_NONE)png_error(png,"Prototype PNG scope mismatch");
    if(!width||!height||std::uint64_t(width)*height*4>256ULL*1024*1024)png_error(png,"PNG dimensions exceed budget");
    const bool transparency=png_get_valid(png,info,PNG_INFO_tRNS)!=0;const auto channels=color==PNG_COLOR_TYPE_RGBA||transparency?4U:3U;
    if(transparency)png_set_tRNS_to_alpha(png);else if(color==PNG_COLOR_TYPE_RGB)png_set_add_alpha(png,255,PNG_FILLER_AFTER);
    png_read_update_info(png,info);if(png_get_rowbytes(png,info)!=std::size_t(width)*4)png_error(png,"PNG row size differs from RGBA8");
    input->pixels.resize(std::size_t(width)*height*4);input->rows.resize(height);
    for(unsigned y=0;y<height;++y)input->rows[y]=input->pixels.data()+std::size_t(y)*width*4;
    png_read_image(png,input->rows.data());png_read_end(png,info);png_destroy_read_struct(&png,&info,nullptr);
    DecodedImage result;result.width=width;result.height=height;result.sourceChannels=channels;result.rgba8=std::move(input->pixels);return result;
}
