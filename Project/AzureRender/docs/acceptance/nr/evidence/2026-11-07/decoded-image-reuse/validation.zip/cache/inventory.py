from pathlib import Path
import json,hashlib,struct,base64,io,collections,time
from PIL import Image
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261107-161237-cpu-asset-load-stages-3ff597';control=root/'build/runs/20261107-162522-binary-material-images-621f66';rows=json.loads((prior/'profile.json').read_text())['rows'];bindings={}
for name in ['targets.json','floor-targets.json']:
 for target in json.loads((control/name).read_text()):bindings[str(Path(target['path']).resolve())]=target['bindings']
requests=[];sources={};start=time.monotonic()
def request(data,label,origin):
 digest=hashlib.sha256(data).hexdigest();decoded=None;kind='unknown'
 try:
  with Image.open(io.BytesIO(data)) as image:
   width,height=image.size;kind=image.format;decoded=width*height*4*(2 if kind=='PNG' and len(data)>25 and data[24]==16 else 1)
   if kind=='DDS':
    levels=max(1,struct.unpack_from('<I',data,28)[0]);w,h=width,height
    for unused in range(levels):decoded+=w*h*4;w=max(1,w//2);h=max(1,h//2)
 except Exception:pass
 requests.append(dict(source=label,sha256=digest,encodedBytes=len(data),decodedBytes=decoded,format=kind,origin=origin))
def external(path,label):
 data=path.read_bytes();sources[str(path)]=hashlib.sha256(data).hexdigest();request(data,label,dict(mode='range',path=str(path),offset=0,length=len(data)))
for row in rows:
 path=Path(row['path']);data=path.read_bytes();sources[str(path)]=hashlib.sha256(data).hexdigest();binary=b''
 if data[:4]==b'glTF':
  length,kind=struct.unpack_from('<II',data,12);assert kind==0x4e4f534a;document=json.loads(data[20:20+length]);offset=20+length
  if offset<len(data):
   length,kind=struct.unpack_from('<II',data,offset);assert kind==0x004e4942;binaryFileOffset=offset+8;binary=data[offset+8:offset+8+length]
 else:document=json.loads(data)
 for index,image in enumerate(document.get('images',[])):
  label=str(row['index'])+':model:'+str(index)
  if 'bufferView' in image:
   view=document['bufferViews'][image['bufferView']];assert view.get('buffer',0)==0
   offset=view.get('byteOffset',0);request(binary[offset:offset+view['byteLength']],label,dict(mode='range',path=str(path),offset=binaryFileOffset+offset,length=view['byteLength']))
  elif image.get('uri','').startswith('data:'):request(base64.b64decode(image['uri'].split(',',1)[1]),label,dict(mode='embedded-uri',path=str(path),imageIndex=index))
  elif image.get('uri'):external((path.parent/image['uri']).resolve(),label)
 for binding in sorted(bindings.get(str(path.resolve()),[]),key=lambda b:b['slot']):
  material=json.loads(Path(binding['path']).read_text());sources[binding['path']]=hashlib.sha256(Path(binding['path']).read_bytes()).hexdigest()
  for index,value in sorted(material.get('textures',{}).items(),key=lambda item:int(item[0])):
   identity=value if isinstance(value,str) else value['asset'];external(Path(binding['textures'][identity]),str(row['index'])+':binding:'+binding['slot']+':'+index)
 if row['index']%64==0:print('Inspected resource '+str(row['index']),flush=True)
simulations=[]
for budget in [0,32*1024**2,64*1024**2,128*1024**2,256*1024**2]:
 cache=collections.OrderedDict();resident=0;peak=0;hits=0;savedDecoded=0;missDecoded=0
 for r in requests:
  if r['decodedBytes'] is None:continue
  if r['sha256'] in cache:
   hits+=1;savedDecoded+=r['decodedBytes'];cache.move_to_end(r['sha256']);continue
  missDecoded+=r['decodedBytes'];cost=r['encodedBytes']+r['decodedBytes']
  if cost>budget:continue
  while resident+cost>budget:
   _,old=cache.popitem(last=False);resident-=old
  cache[r['sha256']]=cost;resident+=cost;peak=max(peak,resident)
 simulations.append(dict(budgetBytes=budget,hits=hits,retainedPeakBytes=peak,savedDecodedBytes=savedDecoded,missDecodedBytes=missDecoded,decodedWorkReduction=savedDecoded/(savedDecoded+missDecoded)))
result=dict(status='inventoried',seconds=time.monotonic()-start,resources=len(rows),requests=len(requests),estimatedRequests=sum(r['decodedBytes'] is not None for r in requests),formats=dict(collections.Counter(r['format'] for r in requests)),simulations=simulations,scope='Read-only recorded resource order plus explicit material bindings; SHA256 equality approximates encoded-byte identity; decoded byte work is not elapsed decode time')
(out/'requests.json').write_text(json.dumps(requests,indent=2));(out/'source-hashes.json').write_text(json.dumps(sources,indent=2));(out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
