from pathlib import Path
import subprocess,os,json,time,sys,xml.etree.ElementTree as ET
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import digest
assert check(root/'build',run=out,planned=4*1024**2,diagnostic=True)['allowed']
targets=['AzureSampledTextureCacheTests','AzureImageDecodeCacheTests','AzureImageCodecTests','AzureMaterialDocumentTests','AzureMaterialGraphTests','AzureTextureMaterialImportTests','AzureTextureContainerTests','AzureCharacterRepairTests','AzureShadowColorLutTests','AzureMaterialCoverageTests','AzureMaterialTextureSharingTests']
env=dict(os.environ);env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
prefix=['cmd','/d','/c',str(root/'tools/msvc_env.bat')];ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';rows=[]
for config in ['Release','Debug']:
    build=root/('build/ninja-msvc-'+config.lower());before={p.name:digest(p) for p in (build/'shaders').glob('*.spv')}
    for kind,command,timeout in [('build',prefix+[str(root/'build/reinstall-environment/venv/Scripts/python.exe'),'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config',config,*[a for t in targets for a in ['--test-target',t]]],600),('checks',[ctest,'--test-dir',str(build),'-R','^Azure(Render\\.(SampledTextureCache|CharacterRepair|MaterialCoverage|MaterialTextureSharing)|Assets\\.(ImageDecodeCache|ImageFormats|MaterialDocument|MaterialGraph|TextureMaterialImport|TextureContainers|ShadowColorLut))$','--output-on-failure','--no-tests=error','--output-junit',str(out/('second-'+config.lower()+'-checks.xml'))],300)]:
        start=time.monotonic()
        with (out/('second-'+config.lower()+'-'+kind+'.log')).open('wb') as log:p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
        rows.append(dict(configuration=config,kind=kind,command=command,exitCode=p.returncode,seconds=time.monotonic()-start));(out/'checks.json').write_text(json.dumps(rows,indent=2));print(config+' '+kind+' exit '+str(p.returncode),flush=True)
        assert p.returncode==0,(out/('second-'+config.lower()+'-'+kind+'.log')).read_text(errors='replace')[-7000:]
    cases=ET.parse(out/('second-'+config.lower()+'-checks.xml')).findall('.//testcase');assert len(cases)==11 and all(c.find('failure') is None for c in cases)
    assert len(before)==663 and before=={p.name:digest(p) for p in (build/'shaders').glob('*.spv')}
print('PASS: twenty-two affected checks, all shader bytes unchanged',flush=True)
