#pragma once
#include "assets/image/ImageCodec.hpp"
#include <cstddef>
#include <memory>
namespace azurerender {
// Sequential loading-thread service. Budget covers retained encoded and decoded
// payloads; callers may retain immutable results independently of the cache.
class ImageDecodeCache final {
public:
    struct Statistics {
        std::size_t requests=0,hits=0,misses=0,retainedBytes=0,peakRetainedBytes=0;
        double decodeMs=0;
    };
    explicit ImageDecodeCache(std::size_t budgetBytes);
    ~ImageDecodeCache();
    std::shared_ptr<const DecodedImage> acquire(const std::vector<unsigned char>&,
        const AssetCancellation& cancelled={});
    Statistics statistics() const noexcept;
    void clear() noexcept;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};
}
