from pathlib import Path
import json
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261107-162522-binary-material-images-621f66'
source=(prior/'control.cpp').read_text().replace('#include "assets/MaterialData.hpp"','#include "assets/AssetLoadCache.hpp"')
source=source.replace('extern "C" double* azure_diag_times();','extern "C" double* azure_diag_times(){static double values[4]{};return values;}')
source=source.replace('nlohmann::json rows=nlohmann::json::array();','nlohmann::json rows=nlohmann::json::array();ImageDecodeCache decodeCache(128ULL*1024*1024);',1)
source=source.replace('loadGltfAsset(target.at("path").get<std::string>())','loadGltfAsset(target.at("path").get<std::string>(),decodeCache)')
source=source.replace('const auto material=prepared.interpret(', 'const auto material=interpretMaterialData(prepared,')
source=source.replace('&asset.materials.at(at-slots.begin()));','&asset.materials.at(at-slots.begin()),decodeCache);')
(out/'native-control.cpp').write_text(source)
targets=json.loads((prior/'floor-targets.json').read_text())+json.loads((prior/'targets.json').read_text());(out/'native-targets.json').write_text(json.dumps(targets,indent=2))
print('Prepared data-only native material compatibility control')
