#include "assets/image/ImageDecodeCache.hpp"
#include "foundation/ByteContentBucket.hpp"
#include <algorithm>
#include <chrono>
#include <list>
#include <string>
#include <unordered_map>
namespace azurerender {
struct ImageDecodeCache::Impl {
    struct Bucket {std::size_t operator()(const std::string& bytes) const noexcept{return byteContentBucket(bytes.data(),bytes.size());}};
    using Order=std::list<const std::string*>;
    struct Entry {std::shared_ptr<const DecodedImage> image;std::size_t bytes;Order::iterator position;};
    std::size_t budget;
    Statistics stats;
    Order order;
    std::unordered_map<std::string,Entry,Bucket> entries;
    explicit Impl(std::size_t value):budget(value){}
};
ImageDecodeCache::ImageDecodeCache(std::size_t budget):impl_(std::make_unique<Impl>(budget)){}
ImageDecodeCache::~ImageDecodeCache()=default;
ImageDecodeCache::Statistics ImageDecodeCache::statistics() const noexcept{return impl_->stats;}
void ImageDecodeCache::clear() noexcept{impl_->order.clear();impl_->entries.clear();impl_->stats={};}
std::shared_ptr<const DecodedImage> ImageDecodeCache::acquire(const std::vector<unsigned char>& bytes,const AssetCancellation& cancel){
    const auto check=[&]{if(cancel&&cancel())throw std::runtime_error("Image decode cancelled");};
    check();auto& cache=*impl_;++cache.stats.requests;
    std::string key;if(!bytes.empty())key.assign(reinterpret_cast<const char*>(bytes.data()),bytes.size());
    const auto found=cache.entries.find(key);
    if(found!=cache.entries.end()){
        check();cache.order.splice(cache.order.begin(),cache.order,found->second.position);
        ++cache.stats.hits;return found->second.image;
    }
    ++cache.stats.misses;const auto start=std::chrono::steady_clock::now();
    auto decoded=std::make_shared<const DecodedImage>(decodeImageBytes(bytes,cancel));
    cache.stats.decodeMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
    check();std::size_t cost=bytes.size()+decoded->rgba8.size()+decoded->rgba16.size()*2+decoded->rgba32.size()*4+decoded->sourceCompression.size();
    for(const auto& level:decoded->mipLevels)cost+=level.rgba8.size();
    for(const auto& loss:decoded->sourceLosses)cost+=loss.size();
    if(cost>cache.budget)return decoded;
    while(cache.stats.retainedBytes>cache.budget-cost){
        const auto victim=cache.entries.find(*cache.order.back());cache.stats.retainedBytes-=victim->second.bytes;
        cache.order.pop_back();cache.entries.erase(victim);
    }
    const auto inserted=cache.entries.emplace(std::move(key),Impl::Entry{decoded,cost,{}}).first;
    try{cache.order.push_front(&inserted->first);}catch(...){cache.entries.erase(inserted);throw;}
    inserted->second.position=cache.order.begin();cache.stats.retainedBytes+=cost;
    cache.stats.peakRetainedBytes=std::max(cache.stats.peakRetainedBytes,cache.stats.retainedBytes);return decoded;
}
}
