#pragma once
#include "assets/GltfLoader.hpp"
#include "assets/MaterialData.hpp"
#include "assets/image/ImageDecodeCache.hpp"
// Explicit optional loading service; existing entry points retain their ABI.
LoadedAsset loadGltfAsset(const std::string&,azurerender::ImageDecodeCache&);
std::vector<AssetMaterial> loadEmbeddedGltfMaterials(const std::string&,bool,
    const std::vector<nlohmann::json>&,azurerender::ImageDecodeCache*);
namespace azurerender {
AssetMaterial interpretMaterialData(const MaterialData&,
    const std::function<std::filesystem::path(const std::string&)>&,
    const AssetMaterial*,ImageDecodeCache&);
void applyMaterialBindings(LoadedAsset&,const std::map<std::string,MaterialBinding>&,ImageDecodeCache&);
}
