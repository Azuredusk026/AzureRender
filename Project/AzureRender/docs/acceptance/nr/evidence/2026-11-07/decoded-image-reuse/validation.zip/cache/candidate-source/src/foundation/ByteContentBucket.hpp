#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
namespace azurerender {
// Process-local bucket only. Actual byte equality must decide content reuse.
// Native word order is deliberate; this value is not a persisted fingerprint.
inline std::uint32_t byteContentBucket(const void* data,std::size_t size) noexcept {
    const auto* bytes=static_cast<const unsigned char*>(data);std::uint32_t hash=2166136261U;std::size_t offset=0;
    for(;size-offset>=sizeof(std::uint32_t);offset+=sizeof(std::uint32_t)){
        std::uint32_t word;std::memcpy(&word,bytes+offset,sizeof(word));hash=(hash^word)*16777619U;
    }
    for(;offset<size;++offset)hash=(hash^bytes[offset])*16777619U;return hash;
}
}
