from pathlib import Path
import json,zipfile,sys,subprocess,xml.etree.ElementTree as ET
root=Path.cwd();out=Path(__file__).resolve().parent;png=root/'build/runs/20261107-163811-png-decode-cost-cba48c';sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from artifact_budget import check
assert check(root/'build',run=out,planned=3*1024**2,diagnostic=True)['allowed']
expected=json.loads((root/'docs/acceptance/nr/evidence/2026-11-07/binary-material-images/results.json').read_text(encoding='utf-8'))['sourceInputs'];assert inputs(root)==expected
restored=[];candidate=[]
for config in ['release','debug']:
    for prefix,collection,count in [('restore-',restored,9),('second-',candidate,11)]:
        path=out/(prefix+config+'-checks.xml');cases=ET.parse(path).findall('.//testcase');assert len(cases)==count and all(c.find('failure') is None for c in cases)
        collection.append(dict(configuration=config,tests=count,sha256=digest(path)))
target=root/'docs/acceptance/nr/evidence/2026-11-07/decoded-image-reuse';target.mkdir(parents=True,exist_ok=True);members={}
for label,directory in [('cache',out),('png-prototype',png)]:
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix.lower() in {'.py','.json','.md','.cpp','.hpp','.log','.xml','.rsp','.txt'}:members[label+'/'+path.relative_to(directory).as_posix()]=path
archive=target/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
    for name,path in members.items():z.write(path,name)
result=dict(status='isolated-production-restored',sourceBase='e6c5b3e',currentInputsEqualAll1615AcceptedInputs=True,
    first=json.loads((out/'first-workload-result.json').read_text()),corrected=json.loads((out/'workload-result.json').read_text()),
    png=json.loads((png/'result.json').read_text()),inventory=json.loads((out/'result.json').read_text()),candidateChecks=candidate,restorationChecks=restored,
    interpretation='Neither local workload pair met the declared 30% threshold. Second decoder durations drifted; cause unverified. No cache or libpng prototype is enabled in production.',
    productionPlayers={c:digest(root/('build/ninja-msvc-'+c)/'AzurePlayer.exe') for c in ['release','debug']},
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=digest(archive),members={n:digest(p) for n,p in members.items()}))
(target/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=result['status'],restorationChecks=18,archiveBytes=archive.stat().st_size)))
