#include "assets/AssetLoadCache.hpp"
#include <chrono>
#include "assets/MaterialSurfaceProfile.hpp"
#include <windows.h>
#include <bcrypt.h>
#include <array>
#include <fstream>
#include <iostream>
extern "C" double* azure_diag_times(){static double values[4]{};return values;}
using namespace azurerender;

std::string sha256(const void* data,std::size_t bytes){
 BCRYPT_ALG_HANDLE algorithm=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;
 if(BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)throw std::runtime_error("SHA256 provider failed");
 if(BCryptCreateHash(algorithm,&hash,nullptr,0,nullptr,0,0)<0)throw std::runtime_error("SHA256 hash failed");
 const auto updated=BCryptHashData(hash,const_cast<PUCHAR>(static_cast<const UCHAR*>(data)),static_cast<ULONG>(bytes),0);
 std::array<UCHAR,32> result{};const auto finished=BCryptFinishHash(hash,result.data(),32,0);BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(algorithm,0);
 if(updated<0||finished<0)throw std::runtime_error("SHA256 update failed");
 std::string text;for(auto value:result){text+="0123456789abcdef"[value>>4];text+="0123456789abcdef"[value&15];}return text;
}
nlohmann::json signature(const AssetMaterial& m){
 nlohmann::json pixels=nlohmann::json::array();
 for(const auto* p:{&m.baseColorPixels,&m.normalPixels,&m.metallicRoughnessPixels,&m.specularEmissivePixels,&m.styleMaskPixels,&m.matcapPixels,&m.hairDataPixels,&m.faceSdf.pixels,&m.shadowColorLutPixels,&m.projectedHairRamp.parameterPixels,&m.projectedHairRamp.line.pixels,&m.outlineSurface.maskPixels,&m.transmissionPixels})pixels.push_back({{"bytes",p->size()},{"sha256",sha256(p->data(),p->size())}});
 const auto packed=azurerender::packMaterialSurfaceProfile(m);nlohmann::json settings=nlohmann::json::array();for(const auto& s:m.textureSettings)settings.push_back(s.describe());
 return {{"pixels",pixels},{"packedSha256",sha256(&packed,sizeof(packed))},{"mips",m.authoredMipLevels},{"settings",settings},
 {"class",int(m.materialClass)},{"features",m.materialFeatures},{"alphaMode",int(m.alphaMode)},{"alphaCutoff",m.alphaCutoff},{"doubleSided",m.doubleSided}};
}

int main(int argc,char** argv)try{
    if(argc!=3)return 2;std::ifstream stream(argv[1]);nlohmann::json targets;stream>>targets;
    nlohmann::json rows=nlohmann::json::array();ImageDecodeCache decodeCache(128ULL*1024*1024);
    for(const auto& target:targets){
        std::fill_n(azure_diag_times(),4,0.);auto start=std::chrono::steady_clock::now();
        auto asset=loadGltfAsset(target.at("path").get<std::string>(),decodeCache);
        const auto elapsed=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
        rows.push_back({{"kind","model"},{"path",target.at("path")},{"totalMs",elapsed},{"imageDecodeMs",azure_diag_times()[0]},
            {"materialMs",azure_diag_times()[1]},{"pixelConversionMs",azure_diag_times()[2]},{"importMs",azure_diag_times()[3]}});
        for(const auto& binding:target.at("bindings")){
            const auto document=MaterialData::load(std::filesystem::u8path(binding.at("path").get<std::string>()));
            std::fill_n(azure_diag_times(),4,0.);start=std::chrono::steady_clock::now();
            const auto slots=materialSlotIds(asset);const auto at=std::find(slots.begin(),slots.end(),binding.at("slot").get<std::string>());
            if(at==slots.end())throw std::runtime_error("Missing source slot");
            auto prepared=document;
            if(prepared.typeId=="azure.profile"){
                prepared.authoringGraph=nullptr;prepared.surface["nodes"]=nlohmann::json::array();
                for(const auto& node:asset.nodes)prepared.surface["nodes"].push_back({{"name",node.name}});
            }
            const auto material=interpretMaterialData(prepared,[&](const std::string& id){return std::filesystem::u8path(binding.at("textures").at(id).get<std::string>());},&asset.materials.at(at-slots.begin()),decodeCache);
            const auto interpretationMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();const auto fingerprint=signature(material);
            rows.push_back({{"signature",fingerprint},{"kind","binding"},{"path",binding.at("path")},{"type",document.typeId},
                {"totalMs",interpretationMs},
                {"imageDecodeMs",azure_diag_times()[0]},{"materialMs",azure_diag_times()[1]},{"pixelConversionMs",azure_diag_times()[2]}});
        }
        std::ofstream(argv[2])<<rows.dump(2);std::cout<<"Completed "<<target.at("path")<<std::endl;
    }
}catch(const std::exception& error){std::cerr<<error.what()<<std::endl;return 1;}
