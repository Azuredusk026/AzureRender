from pathlib import Path
import json,hashlib,sys,traceback
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-122133-material-contribution-cost-c567b5';g=root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea';state=json.loads((g/'state.json').read_text());profile=json.loads((out/'profile.json').read_text());report=dict(status='starting',scope='Output-changing component ablations bound shader cost, including compiler elimination of dependent work. These are not compatible optimizations and do not authorize native acceptance.',captureSha256=state['captureSha256']);cap=None;c=None

def save():(out/'control-state.json').write_text(json.dumps(report,indent=2))
def durations():return {int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
try:
 save();cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 files={r['file'] for r in json.loads((out/'control-builds.json').read_text())};shaders={k:v for k,v in profile['shaders'].items() if v['programFile'] in files};original={};compiled={kind:{} for kind in ['surface-shadow','irradiance','reflection-field','direct-lights']}
 for key,entry in shaders.items():
  event=next(r['event'] for r in profile['rows'] if r['fragment']==key);c.SetFrameEvent(event,True);pipe=c.GetPipelineState();shader=pipe.GetShader(rd.ShaderStage.Pixel);r=pipe.GetShaderReflection(rd.ShaderStage.Pixel);assert hashlib.sha256(bytes(r.rawBytes)).hexdigest()==entry['sha256'];original[key]=shader
  for kind in compiled:
   program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/kind/entry['programFile']).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert program!=rd.ResourceId.Null(),errors;compiled[kind][key]=program
 matched={r['event'] for r in profile['rows'] if r['fragment'] in shaders};report.update(status='compiled',matchedDraws=len(matched),timings=[]);save()
 durations();durations();baseline=durations()
 for kind,programs in compiled.items():
  row=dict(control=kind,baselineBefore=baseline,candidate=[]);report['timings'].append(row);save()
  for key,program in programs.items():c.ReplaceResource(original[key],program)
  durations()
  for unused in range(2):row['candidate'].append(durations());save()
  for shader in original.values():c.RemoveReplacement(shader)
  durations();baseline=durations();row['baselineAfter']=baseline;save()
 report['summary']=[]
 def stats(t):return dict(allEventMs=sum(t.values()),matchedEventMs=sum(ms for e,ms in t.items() if e in matched))
 for row in report['timings']:
  b=[stats(row['baselineBefore']),stats(row['baselineAfter'])];k=[stats(t) for t in row['candidate']];bm=sum(v['matchedEventMs'] for v in b)/2;cm=sum(v['matchedEventMs'] for v in k)/2
  report['summary'].append(dict(control=row['control'],baseline=b,candidate=k,baselineMatchedMs=bm,candidateMatchedMs=cm,savedMatchedMs=bm-cm,matchedReduction=1-cm/bm))
 report['status']='measured';save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='measured' else 1)
