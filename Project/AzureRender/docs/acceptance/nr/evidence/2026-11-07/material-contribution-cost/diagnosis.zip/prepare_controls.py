from pathlib import Path
import json,subprocess,shutil
root=Path.cwd();out=root/'build/runs/20261107-122133-material-contribution-cost-c567b5';prior=root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25';source=root/'shaders';base=(source/'mesh.frag').read_text();manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());programs={p['output']:p for p in manifest['programs']};names=[r['file'] for r in json.loads((prior/'candidate-build.json').read_text())];rows=[]
for kind in ['surface-shadow','irradiance','reflection-field','direct-lights']:
 folder=out/kind;folder.mkdir();text=base
 if kind=='surface-shadow':text=text.replace('float sampleShadowMap(float normalDotLight) {','float sampleShadowMap(float normalDotLight) {\n    return 1.0;')
 elif kind=='irradiance':text=text.replace('vec4 evaluateIrradianceVolume(vec3 position,vec3 normal,bool surfaceReceiver) {','vec4 evaluateIrradianceVolume(vec3 position,vec3 normal,bool surfaceReceiver) {\n    return vec4(0);')
 elif kind=='reflection-field':
  helper=(source/'reflection_probe_field.glsl').read_text();needle='vec4 reflectionProbeFieldRadiance(sampler2DArray source,vec3 position,vec3 direction,vec3 normal,float luminance,float lod){';assert needle in helper;(folder/'reflection_probe_field.glsl').write_text(helper.replace(needle,needle+'\n    return vec4(0);'))
 else:
  needle='lightOffset < lightRange.y';assert needle in text;text=text.replace(needle,'lightOffset < 0U')
 (folder/'mesh.frag').write_text(text)
 for name in names:
  p=programs[name];command=[manifest['compiler'],*[f'-D{d}' for d in p['defines']],f'-I{folder}',f'-I{source}',str(folder/'mesh.frag'),'-o',str(folder/name)];r=subprocess.run(command,capture_output=True,text=True);rows.append(dict(control=kind,file=name,exitCode=r.returncode,command=command,stdout=r.stdout,stderr=r.stderr));(out/'control-builds.json').write_text(json.dumps(rows,indent=2));assert r.returncode==0,r.stderr
shutil.copy2(prior/'profile.json',out/'profile.json');print(json.dumps(dict(status='built',controls=4,programs=len(rows))),flush=True)
