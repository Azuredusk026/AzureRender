from pathlib import Path
import shutil
root=Path.cwd();out=root/'build/runs/20261107-122133-material-contribution-cost-c567b5'
for name in ['control-state.json','control-runner.log','control-driver.log']:shutil.copy2(out/name,out/('initial-'+name))
s=(out/'control.py').read_text().replace('import json,hashlib,sys,traceback','import json,hashlib,sys,traceback,time')
s=s.replace("cap=None;c=None","cap=None;c=None;telemetry=[]\nsys.path.insert(0,str(root/'tools'));from gpu_environment import snapshot")
old='def durations():return {int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}'
new='''def raw_durations():return {int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
def durations():
 previous=[]
 for attempt in range(8):
  values=raw_durations();total=sum(values.values());env={k:v for k,v in snapshot().items() if k!='rawXml'};telemetry.append(dict(phase=phase,attempt=attempt,totalMs=total,environment=env));(out/'warm-environment.json').write_text(json.dumps(telemetry,indent=2));previous.append(total)
  if len(previous)>=3 and max(previous[-3:])/min(previous[-3:])<=1.03:return values
 raise RuntimeError('Replay duration did not stabilize within eight sweeps: '+str(previous))
''';assert old in s;s=s.replace(old,new)
s=s.replace("durations();durations();baseline=durations()","phase='initial-baseline';time.sleep(2);baseline=durations()")
s=s.replace("row=dict(control=kind,baselineBefore=baseline,candidate=[])","phase=kind+'-candidate';row=dict(control=kind,baselineBefore=baseline,candidate=[])")
s=s.replace("  durations()\n  for unused", "  time.sleep(2);durations()\n  for unused")
s=s.replace("  durations();baseline=durations();row['baselineAfter']=baseline;save()", "  phase=kind+'-restored-baseline';time.sleep(2);baseline=durations();row['baselineAfter']=baseline;save()")
s=s.replace("matchedReduction=1-cm/bm))", "matchedReduction=1-cm/bm,bracketStable=max(v['matchedEventMs'] for v in b)/min(v['matchedEventMs'] for v in b)<=1.05))")
s=s.replace("report['status']='measured'", "report['status']='measured';report['warmupPolicy']='Three consecutive replay totals within 3%, at most eight sweeps; paired baseline bracket within 5%; compact GPU telemetry recorded'")
(out/'control_warm.py').write_text(s)
s=(out/'run_control.py').read_text().replace("out/'control.py'","out/'control_warm.py'").replace('timeout=300','timeout=300').replace("out/'control-driver.log'","out/'warm-control-driver.log'");(out/'run_warm_control.py').write_text(s)
print('Prepared one warm-cache stability recheck with GPU telemetry and bounded replay sweeps')
