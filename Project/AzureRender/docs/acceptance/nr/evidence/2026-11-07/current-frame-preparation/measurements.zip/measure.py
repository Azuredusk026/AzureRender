from pathlib import Path
import sys,json,time,subprocess,csv,hashlib
root=Path(__file__).resolve().parents[3];a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=Path(__file__).resolve().parent/'native';out.mkdir()
sys.path.insert(0,str(root/'tools'))
from gpu_environment import wait_and_record,RunEnvironmentMonitor,environment_errors,snapshot
import ctypes
class HostPower(ctypes.Structure):
 _fields_=[("ac",ctypes.c_ubyte),("batteryFlag",ctypes.c_ubyte),("batteryPercent",ctypes.c_ubyte),("saver",ctypes.c_ubyte),("life",ctypes.c_ulong),("fullLife",ctypes.c_ulong)]
def read_with_power():
 value=snapshot();power=HostPower();assert ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(power));value["hostPower"]={"ac":power.ac,"batteryPercent":power.batteryPercent,"saver":power.saver};return value
def stable_power(rows):
 return all(r.get("hostPower",{}).get("ac")==1 and r.get("hostPower",{}).get("saver")==0 and r.get("powerLimitWatts")==80 for r in rows)
from run_playable_performance import memory_snapshot,stats,freeze_products
from build_provenance import inputs,digest
privateFiles={str(p):digest(p) for p in Path(__file__).resolve().parent.glob('*') if p.suffix in {'.cpp','.hpp','.inc','.exe'}};frozen=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
project_frozen=json.loads((a/'prepared-resource-paths/image/frozen-inputs.json').read_text())['project'];assert all(digest(Path(path))==value for path,value in project_frozen.items())
(out/'frozen-inputs.json').write_text(json.dumps(dict(source=frozen,products=products,project=project_frozen),indent=2))
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
command=[str(Path(__file__).resolve().parent/'AzurePlayer.exe'),'--resource-root',str(root/'build/ninja-msvc-release'),'--project',str(project),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--smoke-frames','330','--gpu-timing','--gpu-timing-output',str(out/'timing.json'),'--runtime-report',str(out/'runtime.json')]
(out/'task.json').write_text(json.dumps(dict(scope='One attribution run after three adopted CPU batches; no candidate pair,300warmup+20stage-samples; original1800-sample formal acceptance remains separate',gate='docs/plans/2026-10-17-native-playable-restoration.md',sourceBase='f676f29-private-aggregate-preparation',warmup=300,samples=20,deadlineSeconds=900,command=command,scopeBoundary='P8 fixture memory ceilings are not asserted for this native-content workload; native memory and device status are recorded directly'),indent=2))
environment=wait_and_record(out/'environment.json',read=read_with_power,timeout=45);assert all(r['hostPower']['ac']==1 and r['hostPower']['saver']==0 for r in environment['startup']),'AC startup condition failed';observations=[];surfaceInterventions=[];start=time.monotonic();si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
with RunEnvironmentMonitor(environment,path=out/'environment.json',read=read_with_power),(out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 env=__import__('os').environ.copy();env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH'];env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
 child=subprocess.Popen(command,cwd=out,env=env,stdout=stdout,stderr=stderr,startupinfo=si)
 try:
  while child.poll() is None:
   try:row=memory_snapshot(child.pid)
   except OSError:
    if child.poll() is not None:break
    raise
   row['seconds']=time.monotonic()-start;observations.append(row)
   if time.monotonic()-start>900:raise TimeoutError('Native joint performance exceeded original diagnostic budget')
   time.sleep(.05)
 finally:
  if child.poll() is None:child.kill();child.wait()
  (out/'memory.json').write_text(json.dumps(observations,indent=2));(out/'surface-interventions.json').write_text(json.dumps(surfaceInterventions,indent=2))
(out/'environment.json').write_text(json.dumps(environment,indent=2));assert child.returncode==0,child.returncode

logs=(out/'stdout.log').read_text(errors='replace')+(out/'stderr.log').read_text(errors='replace');assert 'Allocator after unload: buffers=0 images=0' in logs
assert inputs(root)==frozen;assert all(digest(Path(p))==h for p,h in products.items());assert all(digest(Path(p))==h for p,h in project_frozen.items());assert all(digest(Path(p))==h for p,h in privateFiles.items())
groups={'host-frame':[],'current-renderer':[]}
for line in logs.splitlines():
 if '[cpu-stages]' in line or '[cpu-current]' in line:
  value=json.loads(line[line.index('{'):]);groups[value['kind']].append(value)
assert all(len(v)==20 for v in groups.values()),{k:len(v) for k,v in groups.items()}
host={key:stats([r[key] for r in groups['host-frame']]) for key in groups['host-frame'][0] if key.endswith('Ms')}
renderer={key:stats([r['stagesMs'][key] for r in groups['current-renderer']]) for key in groups['current-renderer'][0]['stagesMs']}
result=dict(status='attributed',sourceBase='f676f29',stageFrames=20,hostStages=host,rendererStages=renderer,rows=groups,sourceInputsUnchanged=True,productionProductsUnchanged=True,mountedProjectBytesUnchanged=True,privateFilesUnchanged=True,seconds=time.monotonic()-start,zeroAllocator=True,environmentFailures=environment_errors(environment),diagnosticOnly=True,formalAcceptance=False,scope='Private current-source aggregate host/renderer stage timers only. No per-instance pose timer loop. Not a compatible optimization or whole-frame performance acceptance.')
(out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
