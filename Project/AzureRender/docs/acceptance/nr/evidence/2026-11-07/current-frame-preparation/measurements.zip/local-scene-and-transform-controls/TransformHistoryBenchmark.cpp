#include "runtime/LevelSession.hpp"
#include "runtime/RuntimeLifecycle.hpp"
#include "PreviousTransformSnapshot.cpp"
#include <chrono>
#include <iostream>
using namespace azurerender;
int main(int argc,char** argv)try{
 if(argc!=2)return 2;ProjectStartup project(Project::load(std::filesystem::u8path(argv[1])));const auto scene=project.level().scene;
 RuntimeLifecycle runtime;runtime.loadScene(scene);runtime.start();std::map<std::string,ecs::TransformComponent> reference;PreviousTransformSnapshot candidate;
 std::size_t checksum=0;double beforeCapture=0,afterCapture=0,beforeLookup=0,afterLookup=0;constexpr unsigned rounds=800;
 using Clock=std::chrono::steady_clock;const auto time=[&](auto&& f){const auto start=Clock::now();f();return std::chrono::duration<double,std::milli>(Clock::now()-start).count();};
 for(unsigned i=0;i<rounds+16;++i){auto entity=runtime.entity(scene.nodes.back().id);runtime.world().tryGet<ecs::TransformComponent>(entity)->translation[0]=scene.nodes.back().translation[0]+float(i%7)*.1F;
  const auto oldCapture=[&]{reference.clear();runtime.world().each<ecs::TransformComponent>([&](auto e,const auto& transform){reference[runtime.nodeId(e)]=transform;});};
  const auto newCapture=[&]{candidate.capture(runtime);};
  double a=0,b=0,c=0,d=0;if(i&1){a=time(oldCapture);b=time(newCapture);}else{b=time(newCapture);a=time(oldCapture);}
  SceneDocument oldScene=scene,newScene=scene;constexpr float alpha=.375F;
  const auto oldLookup=[&]{for(auto& node:oldScene.nodes){const auto p=reference.find(node.id);if(p==reference.end())continue;for(unsigned axis=0;axis<3;++axis){node.translation[axis]=p->second.translation[axis]+(node.translation[axis]-p->second.translation[axis])*alpha;node.rotation[axis]=p->second.rotation[axis]+std::remainder(node.rotation[axis]-p->second.rotation[axis],360.F)*alpha;}}};
  const auto newLookup=[&]{for(auto& node:newScene.nodes){const auto* p=candidate.find(node.id);if(!p)continue;for(unsigned axis=0;axis<3;++axis){node.translation[axis]=p->translation[axis]+(node.translation[axis]-p->translation[axis])*alpha;node.rotation[axis]=p->rotation[axis]+std::remainder(node.rotation[axis]-p->rotation[axis],360.F)*alpha;}}};
  if(i&1){c=time(oldLookup);d=time(newLookup);}else{d=time(newLookup);c=time(oldLookup);}
  for(std::size_t n=0;n<scene.nodes.size();++n){if(oldScene.nodes[n].translation!=newScene.nodes[n].translation||oldScene.nodes[n].rotation!=newScene.nodes[n].rotation)throw std::runtime_error("Interpolated transform differs");checksum+=newScene.nodes[n].id.size();}
  if(i>=16){beforeCapture+=a;afterCapture+=b;beforeLookup+=c;afterLookup+=d;}
 }
 std::cout<<nlohmann::json{{"nodes",scene.nodes.size()},{"rounds",rounds},{"captureBaselineMs",beforeCapture/rounds},{"captureCandidateMs",afterCapture/rounds},{"interpolateBaselineMs",beforeLookup/rounds},{"interpolateCandidateMs",afterLookup/rounds},{"outputsEqual",true},{"checksum",checksum},{"scope","Actual native runtime transform capture and render interpolation only; input copying and other simulation systems excluded."}}.dump()<<'\n';
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
