from pathlib import Path
import json,subprocess,sys,os,time
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release';y=out.parent/'20261107-042805-host-scene-preparation-34e27e'
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
manifest=json.loads((build/'build-provenance.json').read_text());verify(root,manifest);source=inputs(root)
command=json.loads((y/'compile.json').read_text())['command'];command=list(command)
for i,v in enumerate(command):
 if v.startswith('/Fo'):command[i]='/Fo'+str(out/'ScenePreparationBenchmark.obj')
 elif v.startswith('/Fd'):command[i]='/Fd'+str(out/'ScenePreparationBenchmark.pdb')
command[-1]=str(out/'ScenePreparationBenchmark.cpp')
with (out/'compile.log').open('wb') as log:r=subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(out/'compile.log').read_text(errors='replace')[-4000:]
rsp=(y/'link.rsp').read_text().replace('"'+str(y/'AzureRenderApp.obj')+'" ','').replace('CMakeFiles\\AzurePlayer.dir\\src\\player\\main.cpp.obj','');rsp='"'+str(out/'ScenePreparationBenchmark.obj')+'" '+rsp.replace(str(y/'AzurePlayer'),str(out/'ScenePreparationBenchmark'));(out/'link.rsp').write_text(rsp)
with (out/'link.log').open('wb') as log:r=subprocess.run(['D:/Tools/VS2022BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/link.exe','@'+str(out/'link.rsp')],cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(out/'link.log').read_text(errors='replace')[-3000:]
env=os.environ.copy();env['PATH']=str(build)+';'+env.get('PATH','');project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject';start=time.monotonic()
with (out/'output.log').open('wb') as log:r=subprocess.run([str(out/'ScenePreparationBenchmark.exe'),str(project)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0,(out/'output.log').read_text(errors='replace')[-3000:]
d=json.loads((out/'output.log').read_text().splitlines()[-1]);assert inputs(root)==source;verify(root,manifest);d.update(sourceBase='f676f29',sourceInputsUnchanged=True,productionProductsUnchanged=True,seconds=time.monotonic()-start,executableSha256=digest(out/'ScenePreparationBenchmark.exe'),compileCommand=command)
(out/'results.json').write_text(json.dumps(d,indent=2));print(json.dumps(d),flush=True)
