#pragma once
#include "render/DeformedBounds.hpp"
#include <cstring>
#include <memory>
namespace azurerender {
// Source geometry, material policies and bind pose remain immutable for this
// owner-thread object's lifetime. Recreate it with the loaded resource.
class MeshPoseBoundsCache final {
public:
 MeshPoseBoundsCache(const LoadedAsset& asset,const JointBounds& joints,std::shared_ptr<const AssetPose> bind)
  :asset_(asset),joints_(joints),bind_(std::move(bind)),margin_(materialDisplacementMargin(asset)){
   if(!bind_)throw std::invalid_argument("Mesh bounds require an owned bind pose");}
 scene::AxisAlignedBounds reference(const std::array<float,2>& morph){
  if(!same(reference_,morph)){reference_.bounds=expandBounds(joints_.evaluate(asset_,morph,asset_.jointMatrices),margin_);reference_.key=morph;reference_.valid=true;}
  return reference_.bounds;}
 scene::AxisAlignedBounds bindPose(const std::array<float,2>& morph){
  if(!same(bindBounds_,morph)){bindBounds_.bounds=expandBounds(joints_.evaluate(asset_,morph,bind_->jointMatrices,bind_.get()),margin_);bindBounds_.key=morph;bindBounds_.valid=true;}
  return bindBounds_.bounds;}
 float displacementMargin() const noexcept{return margin_;}
private:
 struct Slot{bool valid=false;std::array<float,2> key{};scene::AxisAlignedBounds bounds{};};
 static bool same(const Slot& slot,const std::array<float,2>& key) noexcept{return slot.valid&&std::memcmp(slot.key.data(),key.data(),sizeof(key))==0;}
 const LoadedAsset& asset_;const JointBounds& joints_;std::shared_ptr<const AssetPose> bind_;float margin_;Slot reference_,bindBounds_;
};
}
