#include "runtime/LevelSession.hpp"
#include "assets/MaterialData.hpp"
#include "MeshPoseBoundsCache.hpp"
#include <chrono>
#include <iostream>
using namespace azurerender;
struct Resource{LoadedAsset asset;JointBounds joints;std::shared_ptr<const AssetPose> pose;std::unique_ptr<MeshPoseBoundsCache> cache;std::size_t staticInstances=0;};
int main(int argc,char** argv)try{
 if(argc!=2)return 2;ProjectStartup project(Project::load(std::filesystem::u8path(argv[1])));const auto scene=project.level().scene.renderDescription();const scene::ResourceLayout layout(scene);
 std::vector<std::unique_ptr<Resource>> resources;std::size_t staticInstances=0,primaryInstances=0;
 for(std::size_t key=0;key<layout.paths.size();++key){
  if(key==0){for(const auto& node:scene.nodes)if(node.visible&&layout.meshKey(node.resourceId)==0)++primaryInstances;continue;}
  auto r=std::make_unique<Resource>();r->asset=loadGltfAsset(layout.paths[key]);applyMaterialBindings(r->asset,layout.materials.at(key));r->joints=JointBounds::build(r->asset);r->pose=std::make_shared<const AssetPose>(bindAnimationPose(r->asset));
  if(r->asset.animations.empty())for(const auto& node:scene.nodes)if(node.visible&&layout.meshKey(node.resourceId)==key)++r->staticInstances;
  staticInstances+=r->staticInstances;r->cache=std::make_unique<MeshPoseBoundsCache>(r->asset,r->joints,r->pose);resources.push_back(std::move(r));
 }
 std::vector<scene::AxisAlignedBounds> reference,candidate;double before=0,after=0;std::size_t checksum=0;constexpr unsigned rounds=600;
 using Clock=std::chrono::steady_clock;const auto time=[&](auto&& f){const auto start=Clock::now();f();return std::chrono::duration<double,std::milli>(Clock::now()-start).count();};
 const auto baseline=[&](std::array<float,2> morph){reference.clear();for(const auto& r:resources){
  reference.push_back(expandBounds(r->joints.evaluate(r->asset,morph,r->asset.jointMatrices),materialDisplacementMargin(r->asset)));
  for(std::size_t n=0;n<r->staticInstances;++n)reference.push_back(expandBounds(r->joints.evaluate(r->asset,morph,r->pose->jointMatrices,r->pose.get()),materialDisplacementMargin(r->asset)));}checksum+=reference.size();};
 const auto cached=[&](std::array<float,2> morph){candidate.clear();for(const auto& r:resources){candidate.push_back(r->cache->reference(morph));for(std::size_t n=0;n<r->staticInstances;++n)candidate.push_back(r->cache->bindPose(morph));}checksum+=candidate.size();};
 for(unsigned i=0;i<rounds+16;++i){double a=0,b=0;if(i&1){a=time([&]{baseline({0,0});});b=time([&]{cached({0,0});});}else{b=time([&]{cached({0,0});});a=time([&]{baseline({0,0});});}
  if(reference.size()!=candidate.size()||std::memcmp(reference.data(),candidate.data(),reference.size()*sizeof(scene::AxisAlignedBounds)))throw std::runtime_error("Cached bound bytes differ");if(i>=16){before+=a;after+=b;}}
 for(auto morph:{std::array<float,2>{.25F,-.125F},std::array<float,2>{-0.F,0.F},std::array<float,2>{0,0}}){baseline(morph);cached(morph);if(std::memcmp(reference.data(),candidate.data(),reference.size()*sizeof(scene::AxisAlignedBounds)))throw std::runtime_error("Changed morph bound bytes differ");}
 std::cout<<nlohmann::json{{"resources",resources.size()},{"staticAdditionalInstances",staticInstances},{"excludedPrimaryInstances",primaryInstances},{"nativeExpectedTotalBindInstances",860},{"scopeMatchesNativeBindCount",staticInstances+primaryInstances==860},{"rounds",rounds},{"baselineMs",before/rounds},{"candidateMs",after/rounds},{"savedMs",(before-after)/rounds},{"boundsByteIdentical",true},{"checksum",checksum},{"scope","Actual additional 373 native resources with material bindings; reference bounds and unanimated instance bind bounds only. Primary synthetic platform, dynamic animation pose bounds, gizmos and world bounds excluded."}}.dump()<<'\n';
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
