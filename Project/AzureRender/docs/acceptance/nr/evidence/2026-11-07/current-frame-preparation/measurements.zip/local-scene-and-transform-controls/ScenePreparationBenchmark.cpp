#include "runtime/LevelSession.hpp"
#include "SceneTransformCache.hpp"
#include <chrono>
#include <cstring>
#include <iostream>
using namespace azurerender;
using Clock=std::chrono::steady_clock;
int main(int argc,char** argv)try{
 if(argc!=2)return 2;ProjectStartup project(Project::load(std::filesystem::u8path(argv[1])));
 const auto base=project.level().scene.renderDescription();auto first=std::make_shared<const scene::SceneDescription>(base);
 auto changed=base;changed.nodes.back().translation[0]+=.125F;auto second=std::make_shared<const scene::SceneDescription>(changed);
 scene::SceneDescription copy;std::shared_ptr<const scene::SceneDescription> borrowed;scene::SceneTransformCache cache;
 std::vector<internal::Matrix4> reference;std::size_t checksum=0;double copyMs=0,borrowMs=0,resolveMs=0,cacheMs=0;constexpr unsigned rounds=1200;
 const auto measure=[&](auto&& action){auto start=Clock::now();action();return std::chrono::duration<double,std::milli>(Clock::now()-start).count();};
 nlohmann::json results=nlohmann::json::array();
 for(bool dynamic:{false,true}){
  copyMs=borrowMs=resolveMs=cacheMs=0;
  for(unsigned i=0;i<rounds+16;++i){const auto source=dynamic&&(i&1)?second:first;double a=0,b=0,c=0,d=0;
   const auto copyInput=[&]{copy.nodes=source->nodes;copy.lights=source->lights;copy.reflectionProbe=source->reflectionProbe;copy.irradianceVolume=source->irradianceVolume;checksum+=copy.nodes.size();};
   const auto borrowInput=[&]{borrowed=source;checksum+=borrowed->nodes.size();};
   const auto complete=[&]{reference=scene::resolveNodeWorldTransforms(*source);checksum+=reference.size();};
   const auto memoized=[&]{checksum+=cache.resolve(*source).size();};
   if(i&1){a=measure(copyInput);b=measure(borrowInput);c=measure(complete);d=measure(memoized);}else{b=measure(borrowInput);a=measure(copyInput);d=measure(memoized);c=measure(complete);}
   const auto& world=cache.resolve(*source);if(reference.size()!=world.size()||std::memcmp(reference.data(),world.data(),world.size()*sizeof(internal::Matrix4)))throw std::runtime_error("World matrix bytes differ");
   if(copy.nodes.size()!=borrowed->nodes.size()||copy.nodes.back().translation!=borrowed->nodes.back().translation)throw std::runtime_error("Borrowed scene inputs differ");
   if(i>=16){copyMs+=a;borrowMs+=b;resolveMs+=c;cacheMs+=d;}
  }
  results.push_back({{"dynamicLastNode",dynamic},{"rounds",rounds},{"copyMs",copyMs/rounds},{"borrowMs",borrowMs/rounds},{"resolveMs",resolveMs/rounds},{"memoizedMs",cacheMs/rounds},{"worldByteIdentical",true}});
 }
 if(first->nodes.back().translation!=base.nodes.back().translation)throw std::runtime_error("Owned input lifetime changed");
 std::cout<<nlohmann::json{{"nodes",base.nodes.size()},{"resources",base.resources.size()},{"results",results},{"checksum",checksum},{"scope","Actual native scene; persistent node/light/probe description copy and whole-scene matrix resolution only. No runtime or GPU frame claim."},{"historicalCache","Existing isolated SceneTransformCache implementation reused as a private local control; not adopted into production."}}.dump()<<'\n';
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
