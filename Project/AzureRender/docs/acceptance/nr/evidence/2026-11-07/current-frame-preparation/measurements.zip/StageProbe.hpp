#pragma once
#include <chrono>
#include <map>
#include <string>
#include <nlohmann/json.hpp>
#include "diagnostics/RuntimeDiagnostics.hpp"
namespace current_probe {
using Clock=std::chrono::steady_clock;
inline thread_local bool active=false;
inline thread_local std::map<std::string,double> values;
inline thread_local std::map<std::string,std::size_t> counts;
struct Lap {
 std::string prefix;Clock::time_point last;
 explicit Lap(std::string p):prefix(std::move(p)){if(active)last=Clock::now();}
 void mark(const char* name){if(!active)return;const auto now=Clock::now();auto key=prefix+name;values[key]+=std::chrono::duration<double,std::milli>(now-last).count();++counts[key];last=Clock::now();}
};
struct Session {
 unsigned long long frame;Clock::time_point begin;
 Session(double time,unsigned fps):frame(static_cast<unsigned long long>(std::llround(time*fps))+1){active=frame>=310&&frame<330;if(active){values.clear();counts.clear();begin=Clock::now();}}
 ~Session(){if(!active)return;auto total=std::chrono::duration<double,std::milli>(Clock::now()-begin).count();nlohmann::json r={{"kind","current-renderer"},{"frame",frame},{"stagesMs",values},{"calls",counts},{"totalMs",total}};active=false;azurerender::RuntimeDiagnostics::instance().info("cpu-current",r.dump());}
};
}
