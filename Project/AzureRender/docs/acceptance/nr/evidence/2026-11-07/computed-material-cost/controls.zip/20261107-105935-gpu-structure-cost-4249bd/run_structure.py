from pathlib import Path
import subprocess,json,sys,time
out=Path(__file__).resolve().parent;si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'driver.log').open('wb') as log:r=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'read_structure.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=180)
d=json.loads((out/'structure-inspection.json').read_text());print(json.dumps(dict(exitCode=r.returncode,seconds=time.monotonic()-start,status=d['status'],error=d.get('error'))));assert r.returncode==0
