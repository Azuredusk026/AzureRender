from pathlib import Path
import json,sys,traceback
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-105935-gpu-structure-cost-4249bd';g=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc';state=json.loads((g/'state.json').read_text());cap=None;c=None;report={}
def dump(o,depth=0):
 d=dict(name=str(o.name),type=str(o.type.basetype),count=o.NumChildren())
 if o.NumChildren() and depth<5:d['children']=[dump(o.GetChild(i),depth+1) for i in range(min(4,o.NumChildren()))]
 elif not o.NumChildren():
  try:d['u']=int(o.data.basic.u)
  except Exception:pass
  if 'Resource' in str(o.type.basetype):d['resource']=str(o.AsResourceId())
 return d
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded;sf=c.GetStructuredFile();wanted=['vkCreateGraphicsPipelines','vkCreateShaderModule','vkCmdBindPipeline','vkCmdDrawIndexed','vkCmdDrawIndexedIndirect','vkCmdExecuteCommands'];chunks={}
 for i,ch in enumerate(sf.chunks):
  name=str(ch.name)
  if name in wanted and name not in chunks:chunks[name]=dict(index=i,fields=[dump(ch.GetChild(j)) for j in range(ch.NumChildren())])
 actions={}
 def walk(items):
  for a in items:actions[int(a.eventId)]=a;walk(a.children)
 walk(c.GetRootActions());profile=json.loads((g/'events/profile.json').read_text());selected=[r for r in profile['measurements'] if r['shader']=='uninspected' and r['kind']=='draw'][:8];samples=[]
 for r in selected:
  a=actions[r['event']];samples.append(dict(event=r['event'],name=a.GetName(sf),children=len(a.children),api=[dict(event=int(ev.eventId),chunk=int(ev.chunkIndex),name=str(sf.chunks[ev.chunkIndex].name)) for ev in a.events]))
 report=dict(status='inspected',chunks=chunks,actions=samples,bufferCount=len(sf.buffers),structuredChunks=len(sf.chunks))
except Exception:report=dict(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'structure-inspection.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='inspected' else 1)
