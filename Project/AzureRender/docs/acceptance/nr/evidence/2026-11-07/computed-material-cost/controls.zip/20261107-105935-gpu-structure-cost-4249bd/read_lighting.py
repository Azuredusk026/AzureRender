from pathlib import Path
import json,sys,traceback,struct
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-105935-gpu-structure-cost-4249bd';g=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc';state=json.loads((g/'state.json').read_text());cap=None;c=None;report={}
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded;rows=[]
 selected=[r for r in json.loads((out/'classification.json').read_text())['rows'] if r.get('program')=='mesh_object_bindless_clipmap_field_lighting.frag.spv']
 for row in selected:
  c.SetFrameEvent(row['event'],True);v=c.GetVulkanPipelineState();raw=bytes(v.pushconsts);words=list(struct.unpack('<32I',raw[:128]));rows.append(dict(event=row['event'],milliseconds=row['milliseconds'],depthWrite=row['depthWrite'],pushBytes=len(raw),alphaMode=words[1],materialClass=words[28],features=words[29],profileVersion=words[30],materialIndex=words[31]>>1,words=words))
 report=dict(status='decoded',rows=rows)
except Exception:report=dict(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'lighting-inputs.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='decoded' else 1)
