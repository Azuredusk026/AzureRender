from pathlib import Path
import json,subprocess,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];private=out/'candidate-source';private.mkdir(exist_ok=True)
source=root/'shaders'
mapping={'camera.clusterLighting.x':'azureViewLighting()','camera.qaParameters.x':'azureViewIsolation()','camera.qaParameters.y':'azureViewEffect()','camera.qaParameters.z':'azureViewEffectEnabled()','camera.screenReflectionTrace.x':'azureViewReflectionMode()'}
helpers='''
layout(constant_id=4) const bool azureComputedSceneView=true;
float azureViewLighting(){return azureComputedSceneView?1.0:camera.clusterLighting.x;}
float azureViewIsolation(){return azureComputedSceneView?0.0:camera.qaParameters.x;}
float azureViewEffect(){return azureComputedSceneView?0.0:camera.qaParameters.y;}
float azureViewEffectEnabled(){return azureComputedSceneView?1.0:camera.qaParameters.z;}
float azureViewReflectionMode(){return azureComputedSceneView?2.0:camera.screenReflectionTrace.x;}
'''
dynamic=out/'dynamic-source';dynamic.mkdir(exist_ok=True);(out/'dynamic-programs').mkdir(exist_ok=True)
for name in ['mesh.frag','unlit_opaque.glsl','unlit_blend.glsl']:
 text=(source/name).read_text()
 for before,after in mapping.items():text=text.replace(before,after)
 if name=='mesh.frag':text=text.replace('} camera;','} camera;'+helpers)
 (private/name).write_text(text);(dynamic/name).write_text(text.replace('azureComputedSceneView=true','azureComputedSceneView=false'))
profile=json.loads((root/'build/runs/20261107-061745-current-gpu-cost-2de6bc/events/profile.json').read_text())
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());reports=[]
names={v['programFile'] for v in profile['shaders'].values() if (v.get('programFile')or'').startswith(('mesh','character_snapshot'))}
for name in sorted(names):
 program=next(p for p in manifest['programs'] if p['output']==name);assert program['source']=='mesh.frag'
 command=[manifest['compiler'],*[f'-D{d}' for d in program['defines']],f'-I{private}',f'-I{source}',str(private/'mesh.frag'),'-o',str(out/name)]
 if name=='mesh_object_bindless_clipmap_field_lighting.frag.spv':command.insert(1,'-DAZURE_ORDINARY_EARLY_DEPTH=1')
 r=subprocess.run(command,capture_output=True,text=True);reports.append(dict(file=name,command=command,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr))
 (out/'candidate-build.json').write_text(json.dumps(reports,indent=2));assert r.returncode==0,r.stderr
 dynamic_command=[manifest['compiler'],*[f'-D{d}' for d in program['defines']],f'-I{dynamic}',f'-I{source}',str(dynamic/'mesh.frag'),'-o',str(out/'dynamic-programs'/name)]
 d=subprocess.run(dynamic_command,capture_output=True,text=True);assert d.returncode==0,d.stderr
print(json.dumps(dict(status='built',programs=sorted(names))),flush=True)
