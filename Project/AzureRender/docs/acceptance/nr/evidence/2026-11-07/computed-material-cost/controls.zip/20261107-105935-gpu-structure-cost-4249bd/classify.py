from pathlib import Path
import json,sys,traceback,collections,time
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-105935-gpu-structure-cost-4249bd';g=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc';state=json.loads((g/'state.json').read_text());profile=json.loads((g/'events/profile.json').read_text());cap=None;c=None;report=dict(status='starting');start=time.monotonic()
def fields(o):return {str(o.GetChild(i).name):o.GetChild(i) for i in range(o.NumChildren())}
def rid(o):return str(o.AsResourceId())
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded;sf=c.GetStructuredFile();pipelines={};bound={};draws={};dispatches={}
 for index,ch in enumerate(sf.chunks):
  name=str(ch.name)
  if name=='vkCreateGraphicsPipelines':
   f=fields(ch);info=fields(f['CreateInfo']);stages={}
   for j in range(info['pStages'].NumChildren()):
    stage=fields(info['pStages'].GetChild(j));stages[str(int(stage['stage'].data.basic.u))]=rid(stage['module'])
   blend=fields(info['pColorBlendState']);depth=fields(info['pDepthStencilState']);pipelines[rid(f['Pipeline'])]=dict(stages=stages,renderPass=rid(info['renderPass']),colorAttachments=int(blend['attachmentCount'].data.basic.u),depthWrite=bool(depth['depthWriteEnable'].data.basic.u))
  elif name=='vkCmdBindPipeline':
   f=fields(ch);bound[(rid(f['commandBuffer']),int(f['pipelineBindPoint'].data.basic.u))]=rid(f['pipeline'])
  elif name in ['vkCmdDraw','vkCmdDrawIndexed','vkCmdDrawIndexedIndirect','vkCmdDrawIndirect']:
   f=fields(ch);draws[index]=bound.get((rid(f['commandBuffer']),0),'unbound')
  elif name.startswith('vkCmdDispatch'):
   f=fields(ch);dispatches[index]=bound.get((rid(f['commandBuffer']),1),'unbound')
 actions={};parents={}
 def walk(items,parent=None):
  for a in items:actions[int(a.eventId)]=a;parents[int(a.eventId)]=parent;walk(a.children,int(a.eventId))
 walk(c.GetRootActions());rows=[];mismatches=[];groups=collections.defaultdict(lambda:dict(events=0,milliseconds=0.0));unmapped=[]
 for value in profile['measurements']:
  if value['kind']!='draw':continue
  event=value['event'];a=actions[event]
  if a.children:continue
  current=event;pipeline=None
  while current is not None and pipeline is None:
   for api in reversed(actions[current].events):
    if int(api.chunkIndex) in draws:pipeline=draws[int(api.chunkIndex)];break
   current=parents[current]
  if pipeline not in pipelines:unmapped.append(dict(event=event,pipeline=pipeline));continue
  p=pipelines[pipeline];fragment=p['stages'].get('16','ResourceId::0');vertex=p['stages'].get('1','ResourceId::0')
  if value['shader']!='uninspected' and value['shader']!=fragment:mismatches.append(dict(event=event,expected=value['shader'],actual=fragment))
  file=profile['shaders'].get(fragment,{}).get('programFile')
  row=dict(event=event,pipeline=pipeline,fragment=fragment,vertex=vertex,program=file,milliseconds=value['seconds']*1000,**{k:v for k,v in p.items() if k!='stages'});rows.append(row)
  key=json.dumps([file or fragment,vertex,p['renderPass'],p['colorAttachments'],p['depthWrite']]);group=groups[key];group['events']+=1;group['milliseconds']+=row['milliseconds']
 report=dict(status='classified',seconds=time.monotonic()-start,sourceCaptureSha256=state['captureSha256'],scope='Recorded structured API bindings joined to existing 720p leaf draw event durations. No new duration samples or SetFrameEvent replay loops.',pipelines=len(pipelines),drawChunks=len(draws),mappedLeafEvents=len(rows),unmapped=unmapped,knownShaderMismatches=mismatches,groups=sorted([dict(key=json.loads(k),**v) for k,v in groups.items()],key=lambda v:v['milliseconds'],reverse=True),rows=rows,getShaderDocumentation=str(rd.ReplayController.GetShader.__doc__))
 assert not mismatches,mismatches[:3]
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'classification.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='classified' else 1)
