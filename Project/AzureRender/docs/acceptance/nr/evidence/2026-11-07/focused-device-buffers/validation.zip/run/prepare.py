from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2];old=root/'build/runs/20261107-141433-mapped-device-buffers-67ee70'
s=(old/'build_and_check.py').read_text().replace('AzureGpuBufferResidencyGpuTests','AzureGpuBufferPolicyGpuTests').replace('GpuBufferResidencyGpu','GpuBufferPolicyGpu');(out/'build_and_check.py').write_text(s)
s=(old/'check_intel.py').read_text().replace('GpuBufferResidencyGpu','GpuBufferPolicyGpu');(out/'check_intel.py').write_text(s)
s=(old/'capture.py').read_text().replace('fbc0c99-with-mapped-device-buffers','6a47408-focused-device-buffers').replace('Usage-aware device-preferred coherent mapped buffers; original four frozen RGB references and overall visual acceptance unchanged','Allocator-internal device preference with unchanged public headers; original frozen RGB zero-pixel gate');(out/'capture.py').write_text(s)
