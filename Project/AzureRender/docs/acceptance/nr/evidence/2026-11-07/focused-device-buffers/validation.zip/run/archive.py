from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET,subprocess
root=Path.cwd();run=Path(__file__).resolve().parent
out=root/'docs/acceptance/nr/evidence/2026-11-07/focused-device-buffers';out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
native=json.loads((run/'image/results.json').read_text())
assert native['status']=='passed'
checks=[]
for name in ['release-checks.xml','debug-checks.xml','release-intel-checks.xml','debug-intel-checks.xml']:
    tree=ET.parse(run/name);cases=tree.findall('.//testcase')
    assert len(cases) in (5,6) and all(c.find('failure') is None and c.find('error') is None for c in cases)
    checks.append(dict(file=name,tests=len(cases),sha256=sha(run/name)))
assert sum(c['tests'] for c in checks)==22
files={}
for p in run.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.py','.json','.log','.xml','.txt'} and 'baseline' not in p.parts:
        files['run/'+p.relative_to(run).as_posix()]=p
for rel in ['src/rhi/GpuAllocator.cpp','tests/GpuBufferPolicyGpuTests.cpp','CMakeLists.txt']:
    files['source/'+rel]=root/rel
archive=out/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
    for name,p in sorted(files.items()):z.write(p,name)
result=dict(status='implemented-functional-checks-passed-performance-pending',sourceBase=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    executableSha256=native['executableSha256'],checks=checks,native=native,
    power=json.loads((run/'power-preflight.json').read_text()),
    performance=dict(status='not-measured',requiredPowerLimitWatts=80,reason='Observed power limit differs from original condition; prior driver request denied permissions',cpuP95BudgetMs=8,gpuP95BudgetMs=16.6),
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members={n:sha(p) for n,p in files.items()}),
    acceptance=dict(overallVisual='failed-user-review',overallPerformance='pending-original-conditions',previousResidencyFailureRootCause='unverified'))
(out/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(checks=22,archiveBytes=archive.stat().st_size,status=result['status'])))
