from pathlib import Path
import json,subprocess,os,time,sys
out=Path(__file__).resolve().parent;root=out.parents[2];old=root/'build/runs/20261107-042805-host-scene-preparation-34e27e';env=dict(os.environ);env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9');env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH']
command=json.loads((old/'compile.json').read_text())['command'];command=[v.replace(str(old),str(out)).replace('AzureRenderApp.obj','PolicyTest.obj').replace('AzureRenderApp.pdb','PolicyTest.pdb') for v in command];command[-1]=str(root/'tests/GpuBufferPolicyGpuTests.cpp')
link=(root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25/link.rsp').read_text();start=link.index(' /nologo');link='"'+str(out/'PolicyTest.obj')+'"'+link[start:];needle='CMakeFiles\\AzurePlayer.dir\\src\\player\\main.cpp.obj';assert needle in link;link=link.replace(needle,'');link=link.replace('20261107-120518-uniform-texture-index-cost-ebdc25',out.name);(out/'red-link.rsp').write_text(link)
for kind,cmd,cwd in [('compile',['cmd','/d','/c',str(root/'tools/msvc_env.bat'),*command],root),('link',['cmd','/d','/c',str(root/'tools/msvc_env.bat'),'D:/Tools/VS2022BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/link.exe','@'+str(out/'red-link.rsp')],root/'build/ninja-msvc-release')]:
 with (out/('red-'+kind+'.log')).open('wb') as log:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 assert p.returncode==0,(out/('red-'+kind+'.log')).read_text(errors='replace')[-3000:]
p=subprocess.run([str(out/'AzurePlayer.exe')],cwd=out,env=env,capture_output=True,text=True,timeout=120);(out/'red.log').write_text(p.stdout+p.stderr);assert p.returncode!=0 and 'GPU-read buffer must use available local mapped memory' in p.stderr
(out/'red.json').write_text(json.dumps(dict(exitCode=p.returncode,expectedFailure=True,diagnostic=p.stderr),indent=2));print(p.stderr,flush=True)
