from pathlib import Path
import subprocess,json,time,hashlib,os,sys
from PIL import Image
import numpy as np
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';r=root/'build/runs/20261103-234012-character-reference-stages-5abe6c';out=Path(__file__).resolve().parent/'image';out.mkdir()
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from run_playable_performance import freeze_products
from artifact_budget import check
assert check(root/'build',run=out.parent,planned=512*1024**2)['allowed']
source=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
command=json.loads((r/'snapshot-shell-order-regression/release-joint/command.json').read_text());command[command.index('--capture-dir')+1]=str(out/'frames');command[command.index('--runtime-report')+1]=str(out/'runtime.json');project=Path(command[command.index('--project')+1]);description=json.loads(project.read_text())
def project_inputs():
 paths={project.resolve()}
 for mount in description['mounts']:
  directory=(project.parent/mount['path']).resolve()
  for current,dirs,files in os.walk(directory):
   dirs[:]=[d for d in dirs if d!='.azure']
   paths.update((Path(current)/f).resolve() for f in files if not f.endswith('.tmp'))
 result={};shared={}
 for path in sorted(paths):
  stat=path.stat();key=(stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns)
  if key not in shared:shared[key]=digest(path)
  result[str(path)]=shared[key]
 return result
project_before=project_inputs();(out/'frozen-inputs.json').write_text(json.dumps({'source':source,'products':products,'project':project_before,'scope':'All mounted project file bytes, excluding generated .azure caches and .tmp staging; hardlink digests reused by file identity'},indent=2));(out/'command.json').write_text(json.dumps(command,indent=2));print('Native inputs frozen:',len(project_before),'project files',flush=True)
env=os.environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';start=time.monotonic();si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:process=subprocess.run(command,cwd=out,env=env,startupinfo=si,stdout=stdout,stderr=stderr,timeout=900)
rows=[]
for path in sorted((out/'frames').glob('frame_*.png')):
 current=np.array(Image.open(path).convert('RGB'));row={'frame':path.name,'sha256':digest(path)}
 for label,folder in [('frozen',r/'snapshot-shell-order-regression/release-joint/frames'),('liveBaseline',a/'restored-joint/frames')]:
  old=np.array(Image.open(folder/path.name).convert('RGB'));delta=np.abs(current.astype(np.int16)-old.astype(np.int16));row[label]={'identical':bool(np.array_equal(current,old)),'changedPixels':int(np.any(delta,axis=2).sum()),'maxByteDifference':int(delta.max())}
 rows.append(row)
shader_before=json.loads((out.parent/'baseline-products.json').read_text())['release']['programs'];shader_after={p.name:digest(p) for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv')}
shader_same=shader_before==shader_after
assert len(shader_before)==663 and shader_same

logs=(out/'stdout.log').read_text(errors='replace')+(out/'stderr.log').read_text(errors='replace');zero='Allocator after unload: buffers=0 images=0' in logs;clean=not any(s in logs for s in ['Validation Error:','SYNC-HAZARD','VUID-'])
source_same=inputs(root)==source;product_same=all(digest(Path(p))==v for p,v in products.items());project_same=project_inputs()==project_before
cache_manifest=json.loads((out/'frames/capture_manifest.json').read_text())
cache_state={key:value for key,value in cache_manifest.items() if key.startswith('sceneTransform')}
cache_active=cache_state.get('sceneTransformCachedNodes')==1679 and cache_state.get('sceneTransformReusedWorld',0)>0
passed=cache_active and process.returncode==0 and len(rows)==4 and all(row['frozen']['identical'] for row in rows) and shader_same and zero and clean and source_same and product_same and project_same
result={'sceneTransformCache':cache_state,'status':'passed' if passed else 'failed','sourceBase':'fbc0c99-with-mapped-device-buffers','executableSha256':digest(Path(command[0])),'exitCode':process.returncode,'seconds':time.monotonic()-start,'frames':rows,'all663ProgramsByteIdentical':shader_same,'zeroAllocator':zero,'validationLogClean':clean,'sourceInputsUnchanged':source_same,'productsUnchanged':product_same,'allMountedProjectBytesUnchanged':project_same,'projectFileCount':len(project_before),'visualAcceptance':'failed-user-review','scope':'Usage-aware device-preferred coherent mapped buffers; original four frozen RGB references and overall visual acceptance unchanged'};(out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
if not passed:raise SystemExit(1)


