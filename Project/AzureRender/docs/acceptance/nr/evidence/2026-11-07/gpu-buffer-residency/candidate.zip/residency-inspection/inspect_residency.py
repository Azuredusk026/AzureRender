from pathlib import Path
import renderdoc as rd
import json,sys,traceback,collections
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-140754-gpu-buffer-residency-d8f5f3';capture=root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea';state=json.loads((capture/'state.json').read_text());cap=None;c=None;report=dict(status='starting')
def fields(o):return {str(o.GetChild(i).name):o.GetChild(i) for i in range(o.NumChildren())}
def scalar(o):
 if o.NumChildren():return {str(o.GetChild(i).name):scalar(o.GetChild(i)) for i in range(o.NumChildren())}
 return dict(resource=str(o.AsResourceId()),uint=int(o.data.basic.u),text=str(o.AsString()))
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 chunks=c.GetStructuredFile().chunks;allocations={};bindings={};creates={};memoryCalls=collections.Counter()
 for ch in chunks:
  name=str(ch.name)
  if 'Memory' in name or 'Initial' in name:memoryCalls[name]+=1
  f=fields(ch)
  if name=='vkAllocateMemory':
   info=fields(f['AllocateInfo']);allocations[str(f['Memory'].AsResourceId())]=dict(size=int(info['allocationSize'].data.basic.u),memoryTypeIndex=int(info['memoryTypeIndex'].data.basic.u))
  elif name=='vkBindBufferMemory':
   bindings[str(f['buffer'].AsResourceId())]=dict(memory=str(f['memory'].AsResourceId()),offset=int(f['memoryOffset'].data.basic.u))
  elif name=='vkCreateBuffer':
   info=fields(f['CreateInfo']);creates[str(f['Buffer'].AsResourceId())]=dict(bytes=int(info['size'].data.basic.u),usage=int(info['usage'].data.basic.u))
 rows=[]
 for key,entry in creates.items():
  binding=bindings.get(key,{});allocation=allocations.get(binding.get('memory'),{});rows.append(dict(buffer=key,**entry,**binding,**allocation))
 report.update(status='inspected',memoryCalls=dict(memoryCalls),allocations=allocations,buffers=rows,apiDocs=dict(readOnly=rd.PipeState.GetReadOnlyResources.__doc__,readWrite=rd.PipeState.GetReadWriteResources.__doc__))
 c.SetFrameEvent(21311,True);p=c.GetPipelineState();items=p.GetReadOnlyResources(rd.ShaderStage.Pixel);report['readOnlyShapes']=[dict(type=type(x).__name__,attributes=[a for a in dir(x) if not a.startswith('_')]) for x in items[:2]]
 report['boundBuffers']=[]
 for item in [*items,*p.GetReadWriteResources(rd.ShaderStage.Pixel)]:
  key=str(item.descriptor.resource)
  if key not in creates:continue
  binding=bindings.get(key,{});allocation=allocations.get(binding.get('memory'),{})
  report['boundBuffers'].append(dict(buffer=key,**creates[key],**binding,**allocation,access={a:str(getattr(item.access,a)) for a in dir(item.access) if not a.startswith('_') and a not in ['acquire','append','disown','next','own','this','thisown']},descriptor={a:str(getattr(item.descriptor,a)) for a in ['byteOffset','byteSize'] if hasattr(item.descriptor,a)}))
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 (out/'residency.json').write_text(json.dumps(report,indent=2))
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='inspected' else 1)
