from pathlib import Path
import subprocess,json,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from gpu_environment import snapshot
before=snapshot();command=['nvidia-smi','-pl','80'];p=subprocess.run(command,capture_output=True,text=True,timeout=20);after=snapshot()
r=dict(command=command,exitCode=p.returncode,stdout=p.stdout,stderr=p.stderr,before={k:v for k,v in before.items() if k!='rawXml'},after={k:v for k,v in after.items() if k!='rawXml'},requestedFactoryDefaultWatts=80,previousLimitWatts=before.get('powerLimitWatts'),changedByCommand=p.returncode==0)
(out/'power-request.json').write_text(json.dumps(r,indent=2));print(json.dumps(dict(exitCode=p.returncode,stdout=p.stdout,stderr=p.stderr,beforeWatts=before.get('powerLimitWatts'),afterWatts=after.get('powerLimitWatts'))),flush=True)
