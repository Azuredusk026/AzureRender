from pathlib import Path
import json,struct,hashlib,subprocess,sys
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from build_provenance import verify,digest
def code(path):
 data=path.read_bytes();pe=struct.unpack_from('<I',data,0x3c)[0];sections=struct.unpack_from('<H',data,pe+6)[0];optional=struct.unpack_from('<H',data,pe+20)[0];at=pe+24+optional
 for i in range(sections):
  row=at+40*i
  if data[row:row+8].rstrip(b'\0')==b'.text':
   size,offset=struct.unpack_from('<II',data,row+16);return data[offset:offset+size]
 raise ValueError('Missing PE code section')
rows=json.loads((out/'restored-checks.json').read_text());assert len(rows)==6 and all(r['exitCode']==0 for r in rows)
base=json.loads((out/'baseline-products.json').read_text());result=dict(status='restored',configurations={})
for config in ['release','debug']:
 build=root/('build/ninja-msvc-'+config);verify(root,json.loads((build/'build-provenance.json').read_text()));programs={p.name:digest(p) for p in (build/'shaders').glob('*.spv')};assert programs==base[config]['programs']
 result['configurations'][config]=dict(programsByteIdentical=True,programCount=len(programs),playerCodeSha256=hashlib.sha256(code(build/'AzurePlayer.exe')).hexdigest())
result['releasePlayerCodeByteIdentical']=code(root/'build/ninja-msvc-release/AzurePlayer.exe')==code(out/'baseline/release-AzurePlayer.exe');assert result['releasePlayerCodeByteIdentical']
diff=subprocess.check_output(['git','diff','--binary','--','src','tests','tools/endfield_native','tools/test_native_character_surfaces.py','docs/acceptance/p5'],cwd=root,stderr=subprocess.DEVNULL);result['protectedUserDiffSha256']=hashlib.sha256(diff).hexdigest();assert result['protectedUserDiffSha256']=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
(out/'restoration.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
