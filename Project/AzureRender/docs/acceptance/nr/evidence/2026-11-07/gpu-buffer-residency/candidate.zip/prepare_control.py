from pathlib import Path
out=Path(__file__).resolve().parent
s=(out/'capture.py').read_text().replace("parent/'image'","parent/'baseline-control'")
s=s.replace("command=json.loads((r/", "command=json.loads((r/")
needle="command[command.index('--capture-dir')+1]"
s=s.replace(needle,"command[0]=str(out.parent/'baseline/release-AzurePlayer.exe');"+needle,1)
s=s.replace("env=os.environ.copy();", "env=os.environ.copy();env['PATH']=str(root/'build/ninja-msvc-release')+';'+env['PATH'];")
s=s.replace("'fbc0c99-with-mapped-device-buffers'","'saved-original-player-same-current-inputs'")
s=s.replace("products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')","products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe');old_player=out.parent/'baseline/release-AzurePlayer.exe';products[str(old_player)]=digest(old_player);assert digest(old_player)==json.loads((out.parent/'baseline-products.json').read_text())['release']['player']")
(out/'capture_control.py').write_text(s)
