from pathlib import Path
import subprocess,json,os,time
out=Path(__file__).resolve().parent;root=out.parents[2];build=(root/'build/ninja-msvc-debug').resolve();cache=(build/'AzureVolumeImageUploadGpuTests.ilk').resolve();assert cache.is_relative_to(build) and cache.suffix=='.ilk';removed=dict(path=str(cache),existed=cache.exists(),bytes=cache.stat().st_size if cache.exists() else 0)
if cache.exists():cache.unlink()
(out/'debug-link-cache-repair.json').write_text(json.dumps(removed,indent=2))
rows=json.loads((out/'restored-checks.json').read_text());(out/'restored-checks-first-attempt.json').write_text(json.dumps(rows,indent=2));failed=rows.pop();assert failed['configuration']=='Debug' and failed['kind']=='build' and failed['exitCode']!=0
releaseCheck=next(r for r in rows if r['configuration']=='Release' and r['kind']=='checks');check=[str(x).replace('ninja-msvc-release','ninja-msvc-debug').replace('restored-release-checks.xml','restored-debug-checks.xml') for x in releaseCheck['command']]
env=dict(os.environ);env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
for kind,command,timeout in [('build',failed['command'],900),('checks',check,360)]:
 start=time.monotonic()
 with (out/('restored-debug-'+kind+'-repaired.log')).open('wb') as log:p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 row=dict(configuration='Debug',kind=kind,exitCode=p.returncode,seconds=time.monotonic()-start,command=command);rows.append(row);(out/'restored-checks.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True);assert p.returncode==0
