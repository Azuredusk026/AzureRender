from pathlib import Path
import json,zipfile,hashlib,shutil
from PIL import Image
out=Path(__file__).resolve().parent;root=out.parents[2];restore=json.loads((out/'restoration.json').read_text());assert restore['status']=='restored';image=json.loads((out/'image/results.json').read_text());control=json.loads((out/'baseline-control-fixed/results.json').read_text());assert image['status']=='failed' and control['status']=='passed'
e=root/'docs/acceptance/nr/evidence/2026-11-07/gpu-buffer-residency';e.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(e/'candidate.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.rglob('*'):
  if not p.is_file() or p.suffix in ['.png','.exe','.bin','.rdc']:continue
  if p.is_relative_to(out/'baseline') or p.is_relative_to(out/'candidate-products'):continue
  z.write(p,p.relative_to(out))
def cut(path):
 im=Image.open(path).convert('RGB');canvas=Image.new('RGB',(60,65));canvas.paste(im.crop((900,0,960,20)),(0,0));canvas.paste(im.crop((900,620,960,665)),(0,20));return canvas
preview=Image.new('RGB',(120,65));preview.paste(cut(out/'baseline-control-fixed/frames/frame_000003.png'),(0,0));preview.paste(cut(out/'image/frames/frame_000003.png'),(60,0));preview.resize((480,260),Image.Resampling.NEAREST).save(e/'difference-regions.png')
p=e/'candidate.zip';report=dict(schemaVersion=1,status='isolated-restored',sourceBase='fbc0c99',candidateChecks=dict(release=6,debug=6,intelRelease=5,intelDebug=5),realGpuReadProperties=7,realReadbackProperties=6,originalHostVisibleBuffers=37,originalFragmentBoundHostBuffers=7,nativeCandidate=image,nativeOriginalControl=control,restoration=restore,powerRequest=json.loads((out/'power-request.json').read_text()),nativeTimingStarted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',retryTrigger='Explain and resolve the fourteen byte-level pixel changes; original stable 80W condition for timing',archive=dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()),differencePreview=dict(file='difference-regions.png',left='original control',right='candidate',originalRegions=[[900,0,960,20],[900,620,960,665]],scale=4))
(e/'results.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(status=report['status'],archiveBytes=p.stat().st_size,restored=restore['releasePlayerCodeByteIdentical'])))
