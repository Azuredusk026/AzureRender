from pathlib import Path
out=Path(__file__).resolve().parent;s=(out/'capture_control.py').read_text().replace("parent/'baseline-control'","parent/'baseline-control-fixed'")
needle="command[0]=str(out.parent/'baseline/release-AzurePlayer.exe');";assert needle in s;s=s.replace(needle,needle+"command.extend(['--resource-root',str(root/'build/ninja-msvc-release')]);")
s=s.replace('rows=[]',"assert process.returncode==0,(out/'stderr.log').read_text(errors='replace')[-4000:]\nrows=[]",1)
(out/'capture_control_fixed.py').write_text(s)
