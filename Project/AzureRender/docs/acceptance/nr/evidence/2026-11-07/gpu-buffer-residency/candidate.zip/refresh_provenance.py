from pathlib import Path
import subprocess,json,os,time,sys
out=Path(__file__).resolve().parent;root=out.parents[2];env=dict(os.environ);env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3');sys.path.insert(0,str(root/'tools'));from build_provenance import digest
rows=[]
for r in json.loads((out/'checks.json').read_text()):
 if r['kind']!='build':continue
 config=r['configuration'].lower();build=root/('build/ninja-msvc-'+config);before={str(p):digest(p) for p in [build/'AzurePlayer.exe',build/'AzureRender.exe',*sorted((build/'shaders').glob('*.spv'))]};start=time.monotonic()
 with (out/(config+'-provenance-refresh.log')).open('wb') as log:p=subprocess.run(r['command'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 assert p.returncode==0 and all(digest(Path(p))==h for p,h in before.items());rows.append(dict(configuration=config,exitCode=p.returncode,seconds=time.monotonic()-start,allRuntimeProductsIdentical=True))
(out/'provenance-refresh.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows),flush=True)
