from pathlib import Path
import shutil,json,hashlib,subprocess
out=Path(__file__).resolve().parent;root=out.parents[2]
files=['CMakeLists.txt','src/rhi/GpuAllocator.cpp','src/rhi/GpuAllocator.hpp','tests/GpuBufferResidencyGpuTests.cpp','docs/plans/2026-11-07-gpu-buffer-residency.md'];rows={}
for name in files:
 p=root/name;target=out/'candidate-source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);rows[name]=hashlib.sha256(p.read_bytes()).hexdigest()
for config in ['release','debug']:
 p=root/('build/ninja-msvc-'+config)/'AzurePlayer.exe';target=out/'candidate-products'/(config+'-AzurePlayer.exe');target.parent.mkdir(exist_ok=True);shutil.copy2(p,target);rows[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
inspection=root/'build/runs/20261107-140754-gpu-buffer-residency-d8f5f3';target=out/'residency-inspection';target.mkdir(exist_ok=True)
for p in inspection.iterdir():
 if p.is_file():shutil.copy2(p,target/p.name)
(out/'candidate-files.json').write_text(json.dumps(rows,indent=2));print('Preserved candidate sources, executables and original residency inspection')
