from pathlib import Path
import subprocess,sys,os,json,time,hashlib,struct,xml.etree.ElementTree as ET
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from build_provenance import digest
files=['CMakeLists.txt','src/rhi/GpuAllocator.cpp','src/rhi/GpuAllocator.hpp']
assert (out/'candidate-source/tests/GpuBufferResidencyGpuTests.cpp').is_file()
subprocess.run(['git','restore','--source=HEAD','--worktree','--',*files],cwd=root,check=True)
new=root/'tests/GpuBufferResidencyGpuTests.cpp';assert new.read_bytes()==(out/'candidate-source/tests/GpuBufferResidencyGpuTests.cpp').read_bytes();new.unlink()
for name in files:os.utime(root/name,None)
env=dict(os.environ);env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3');cmake='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe';ctest=str(Path(cmake).with_name('ctest.exe'));python=str(root/'build/reinstall-environment/venv/Scripts/python.exe');targets=['AzureShadowTileBoundsGpuTests','AzureDepthPyramidGpuTests','AzureVolumeImageUploadGpuTests','AzureObjectShadowFilteringGpuTests','AzureObjectShadowAtlasTests'];rows=[]
for config in ['Release','Debug']:
 build=root/('build/ninja-msvc-'+config.lower());prefix=['cmd','/d','/c',str(root/'tools/msvc_env.bat')]
 commands=[('configure',prefix+[cmake,'-S',str(root),'-B',str(build)],180),('build',prefix+[python,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config',config,*[a for t in targets for a in ['--test-target',t]]],900),('checks',[ctest,'--test-dir',str(build),'-R','^AzureRender\\.(ShadowTileBoundsGpu|DepthPyramidGpu|VolumeImageUploadGpu|ObjectShadowFilteringGpu|ObjectShadowAtlas)$','--output-on-failure','--no-tests=error','--output-junit',str(out/('restored-'+config.lower()+'-checks.xml'))],360)]
 for kind,command,timeout in commands:
  start=time.monotonic()
  with (out/('restored-'+config.lower()+'-'+kind+'.log')).open('wb') as log:p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
  row=dict(configuration=config,kind=kind,exitCode=p.returncode,seconds=time.monotonic()-start,command=command);rows.append(row);(out/'restored-checks.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True);assert p.returncode==0,(out/('restored-'+config.lower()+'-'+kind+'.log')).read_text(errors='replace')[-4000:]
 assert int(ET.parse(out/('restored-'+config.lower()+'-checks.xml')).getroot().attrib['tests'])==5
 baseline=json.loads((out/'baseline-products.json').read_text())[config.lower()];assert {p.name:digest(p) for p in (build/'shaders').glob('*.spv')}==baseline['programs']
