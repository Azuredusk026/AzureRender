from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2];template=root/'build/runs/20261107-082148-stable-frame-preparation-dcf3f3'
s=(template/'capture.py').read_text().replace("['programs'];shader_after", "['release']['programs'];shader_after")
s=s.replace('aca7dfc-with-stable-frame-preparation','fbc0c99-with-mapped-device-buffers').replace('Generational transform history and exact hierarchy matrix reuse; original four frozen native RGB references, zero-pixel gate unchanged; full user visual acceptance remains failed','Usage-aware device-preferred coherent mapped buffers; original four frozen RGB references and overall visual acceptance unchanged')
s=s.replace("source=inputs(root);products=", "from artifact_budget import check\nassert check(root/'build',run=out.parent,planned=512*1024**2)['allowed']\nsource=inputs(root);products=")
(out/'capture.py').write_text(s)
