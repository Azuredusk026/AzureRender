from pathlib import Path
import subprocess,json,time,sys
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
source=inputs(root);products={p.name:digest(p) for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv')};si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'inspect_residency.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=90)
assert inputs(root)==source and {p.name:digest(p) for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv')}==products
r=json.loads((out/'residency.json').read_text());print(json.dumps(dict(status=r['status'],error=r.get('error'),seconds=time.monotonic()-start,memoryCalls=r.get('memoryCalls'),readOnlyShapes=r.get('readOnlyShapes'))),flush=True)
