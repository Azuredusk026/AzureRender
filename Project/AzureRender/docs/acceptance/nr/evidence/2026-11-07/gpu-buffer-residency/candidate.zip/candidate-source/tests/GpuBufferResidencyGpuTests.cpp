#include "support/VulkanComputeFixture.hpp"
#include <array>
#include <cstring>
#include <iostream>
using namespace azurerender;
namespace {
void require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
bool localMappingAvailable(test::VulkanComputeFixture& host,VkBuffer buffer){
    VkMemoryRequirements requirements{};vkGetBufferMemoryRequirements(host.device,buffer,&requirements);
    VkPhysicalDeviceMemoryProperties properties{};vkGetPhysicalDeviceMemoryProperties(host.physical,&properties);
    constexpr VkMemoryPropertyFlags wanted=VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT
        |VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
    for(unsigned i=0;i<properties.memoryTypeCount;++i)
        if((requirements.memoryTypeBits&(1U<<i))&&(properties.memoryTypes[i].propertyFlags&wanted)==wanted)return true;
    return false;
}
void exercise(test::VulkanComputeFixture& host,VkBufferUsageFlags usage){
    constexpr VkDeviceSize bytes=4096;
    auto source=host.allocator.createBuffer(bytes,usage|VK_BUFFER_USAGE_TRANSFER_SRC_BIT,true);
    rhi::GpuBuffer readback{};
    try{
        const auto flags=host.allocator.memoryProperties(source);
        require(source.mapped&&(flags&VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)
            &&(flags&VK_MEMORY_PROPERTY_HOST_COHERENT_BIT),"Mapped coherent upload contract failed");
        if(localMappingAvailable(host,source.buffer))
            require((flags&VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)!=0,"GPU-read buffer must prefer available local mapped memory");
        std::array<std::uint32_t,bytes/4> values{};
        for(unsigned i=0;i<values.size();++i)values[i]=(i*2654435761U)^usage;
        std::memcpy(source.mapped,values.data(),bytes);host.allocator.flush(source,0,bytes);
        readback=host.allocator.createBuffer(bytes,VK_BUFFER_USAGE_TRANSFER_DST_BIT,true);
        host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer native){
            commands.bufferBarrier({source.buffer,0,bytes,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT});
            VkBufferCopy region{0,0,bytes};vkCmdCopyBuffer(native,source.buffer,readback.buffer,1,&region);
            commands.bufferBarrier({readback.buffer,0,bytes,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
        });
        host.allocator.invalidate(readback,0,bytes);
        require(std::memcmp(readback.mapped,values.data(),bytes)==0,"Mapped upload and GPU readback bytes differ");
        std::cout<<"usage="<<usage<<" properties="<<flags<<" readbackProperties="<<host.allocator.memoryProperties(readback)<<'\n';
        host.allocator.destroyBuffer(readback);host.allocator.destroyBuffer(source);
        bool rejected=false;try{(void)host.allocator.memoryProperties(source);}catch(const std::invalid_argument&){rejected=true;}
        require(rejected,"Retired allocation query must be rejected");
    }catch(...){host.allocator.destroyBuffer(readback);host.allocator.destroyBuffer(source);throw;}
}
}
int main()try{
    test::VulkanComputeFixture host;
    for(const auto usage:{VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
        VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,VK_BUFFER_USAGE_INDEX_BUFFER_BIT,VK_BUFFER_USAGE_INDIRECT_BUFFER_BIT})exercise(host,usage);
    require(host.errors==0&&!host.allocator.statistics().liveBuffers,"Residency validation or allocation retirement failed");
    std::cout<<"PASS: mapped GPU-read usages, real copies, properties and retirement\n";return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
