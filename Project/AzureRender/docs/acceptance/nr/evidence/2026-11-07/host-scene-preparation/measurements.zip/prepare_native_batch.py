from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2];old=root/'build/runs/20261107-041924-unlit-blend-fast-path-6d9663'
s=(old/'capture.py').read_text();start=s.index('shader_before=');end=s.index('\nlogs=',start)
s=s[:start]+'''shader_before=json.loads((out.parent/'baseline-products.json').read_text())['programs'];shader_after={p.name:digest(p) for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv')}
shader_same=shader_before==shader_after
assert len(shader_before)==663 and shader_same
'''+s[end:]
s=s.replace('9004b9c-with-unlit-blend-fast-path','723286a-with-host-scene-caches').replace('onlyMeshFragmentProgramsChanged','all663ProgramsByteIdentical').replace('Unlit blend early output candidate','Owned runtime scene snapshot and render description caches')
(out/'capture.py').write_text(s)
for role in ['baseline','candidate']:
 s=(old/('measure_'+role+'.py')).read_text().replace('9004b9c-with-unlit-blend-fast-path','723286a-with-host-scene-caches').replace('9004b9c','723286a')
 (out/('measure_'+role+'.py')).write_text(s)
print('Prepared one native four-frame control and one short CPU pair')
