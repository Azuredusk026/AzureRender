#include "runtime/LevelSession.hpp"
#include "runtime/GameRuntime.hpp"
#include "runtime/RuntimeRenderSnapshotCache.hpp"
#include "resources/PreparedResourcePaths.hpp"
#include <chrono>
#include <iostream>
using namespace azurerender;
bool shadow(const std::optional<ecs::ObjectShadowComponent>& x,const std::optional<ecs::ObjectShadowComponent>& y){if(x.has_value()!=y.has_value())return false;if(!x)return true;return std::tie(x->enabled,x->center,x->halfExtents,x->normalBias,x->lightBias,x->filterRadiusX,x->filterRadiusY,x->atlasPage,x->receiverPixelOffsetX,x->receiverPixelOffsetY,x->surfaceNormalBias)==std::tie(y->enabled,y->center,y->halfExtents,y->normalBias,y->lightBias,y->filterRadiusX,y->filterRadiusY,y->atlasPage,y->receiverPixelOffsetX,y->receiverPixelOffsetY,y->surfaceNormalBias);}
bool equal(const scene::SceneDescription& a,const scene::SceneDescription& b){
 if(a.resources.size()!=b.resources.size()||a.nodes.size()!=b.nodes.size()||a.lights.size()!=b.lights.size())return false;
 for(std::size_t i=0;i<a.resources.size();++i){const auto& x=a.resources[i];const auto& y=b.resources[i];if(x.id!=y.id||x.path!=y.path||x.materials.size()!=y.materials.size())return false;
  for(const auto& p:x.materials){auto f=y.materials.find(p.first);if(f==y.materials.end()||p.second.path!=f->second.path||p.second.fingerprint!=f->second.fingerprint||p.second.textures!=f->second.textures)return false;}}
 for(std::size_t i=0;i<a.nodes.size();++i){const auto& x=a.nodes[i];const auto& y=b.nodes[i];if(x.id!=y.id||x.resourceId!=y.resourceId||x.parentId!=y.parentId||x.translation!=y.translation||x.rotation!=y.rotation||x.scale!=y.scale||x.visible!=y.visible||!shadow(x.objectShadow,y.objectShadow))return false;}
 for(std::size_t i=0;i<a.lights.size();++i){const auto& x=a.lights[i];const auto& y=b.lights[i];if(x.id!=y.id||x.nodeId!=y.nodeId||x.position!=y.position||x.color!=y.color||x.intensity!=y.intensity||x.radius!=y.radius||x.enabled!=y.enabled||nlohmann::json(x.shape)!=nlohmann::json(y.shape))return false;}
 return nlohmann::json(a.reflectionProbe)==nlohmann::json(b.reflectionProbe)&&nlohmann::json(a.irradianceVolume)==nlohmann::json(b.irradianceVolume)&&nlohmann::json(a.viewFog)==nlohmann::json(b.viewFog);
}

int main(int argc,char** argv){try{
 if(argc!=3)return 2;ProjectStartup startup(Project::load(std::filesystem::u8path(argv[1])));
 const auto& document=startup.level().scene;RuntimeLifecycle runtime;runtime.loadScene(document);runtime.start();
 GameRuntime game(runtime);game.advance(1.0/60);game.advance(1.0/120);
 PreparedResourcePaths paths{ResourceLocator(std::filesystem::u8path(argv[2]))};
 RuntimeSceneSnapshotCache snapshots;RuntimeRenderSnapshotCache descriptions;SceneDocument original,cached;
 unsigned baselinePreparations=0,cachedPreparations=0;
 const auto prepare=[&](const SceneDocument& value){
  auto result=value.renderDescription();std::vector<std::string> requested;
  requested.reserve(result.resources.size());for(const auto& resource:result.resources)requested.push_back(resource.path);
  auto resolved=paths.resolve(requested);for(std::size_t i=0;i<resolved.size();++i)result.resources[i].path.swap(resolved[i]);return result;
 };
 const auto baseline=[&](){++baselinePreparations;game.renderScene(original);return std::make_shared<const scene::SceneDescription>(prepare(original));};
 const auto candidate=[&](){game.renderScene(cached,snapshots);return descriptions.prepare(cached,snapshots.sourceIdentity(cached),[&](const auto& value){++cachedPreparations;return prepare(value);});};
 auto reference=baseline();auto first=candidate();if(!equal(*reference,*first))throw std::runtime_error("Initial cache output differs");
 for(unsigned i=0;i<4;++i){baseline();candidate();}
 double before=0,after=0;std::size_t checksum=0;constexpr unsigned rounds=100;
 const auto measure=[&](bool useCache){const auto start=std::chrono::steady_clock::now();{
  auto value=useCache?candidate():baseline();checksum+=value->nodes.size()+value->resources.size();
 }return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();};
 const auto entity=runtime.entity(document.nodes.back().id);auto* transform=runtime.world().tryGet<ecs::TransformComponent>(entity);
 for(unsigned i=0;i<rounds;++i){
  transform->translation[0]=document.nodes.back().translation[0]+float(i%7)*.01F;
  if(i&1){before+=measure(false);after+=measure(true);}else{after+=measure(true);before+=measure(false);}
  if(i%10==0){auto a=baseline();auto b=candidate();if(!equal(*a,*b))throw std::runtime_error("Dynamic cache output differs");}
 }
 std::cout<<nlohmann::json{{"scope","Actual native document and same ECS state; game scene snapshot, render description and resource resolution only; simulation/camera/GPU excluded"},
  {"rounds",rounds},{"nodes",document.nodes.size()},{"resources",document.resources.size()},
  {"baselineMs",before/rounds},{"candidateMs",after/rounds},{"reduction",1-after/before},
  {"outputsEqual",true},{"retainedFrameUnchanged",equal(*reference,*first)},{"baselinePreparations",baselinePreparations},{"cachedPreparations",cachedPreparations},
  {"pooledFrames",descriptions.pooledFrameCount()},{"checksum",checksum}}.dump()<<'\n';return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
