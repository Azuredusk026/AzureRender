from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2]
old=(root/'build/runs/20261107-024335-current-cpu-hotspots-5b7d2c/SnapshotBenchmark.cpp').read_text()
helpers=old[old.index('bool shadow('):old.index('int main(')]
source='''#include "runtime/LevelSession.hpp"
#include "runtime/GameRuntime.hpp"
#include "runtime/RuntimeRenderSnapshotCache.hpp"
#include "resources/PreparedResourcePaths.hpp"
#include <chrono>
#include <iostream>
using namespace azurerender;
'''+helpers+r'''
int main(int argc,char** argv){try{
 if(argc!=3)return 2;ProjectStartup startup(Project::load(std::filesystem::u8path(argv[1])));
 const auto& document=startup.level().scene;RuntimeLifecycle runtime;runtime.loadScene(document);runtime.start();
 GameRuntime game(runtime);game.advance(1.0/60);game.advance(1.0/120);
 PreparedResourcePaths paths{ResourceLocator(std::filesystem::u8path(argv[2]))};
 RuntimeSceneSnapshotCache snapshots;RuntimeRenderSnapshotCache descriptions;SceneDocument original,cached;
 unsigned baselinePreparations=0,cachedPreparations=0;
 const auto prepare=[&](const SceneDocument& value){
  auto result=value.renderDescription();std::vector<std::string> requested;
  requested.reserve(result.resources.size());for(const auto& resource:result.resources)requested.push_back(resource.path);
  auto resolved=paths.resolve(requested);for(std::size_t i=0;i<resolved.size();++i)result.resources[i].path.swap(resolved[i]);return result;
 };
 const auto baseline=[&](){++baselinePreparations;game.renderScene(original);return std::make_shared<const scene::SceneDescription>(prepare(original));};
 const auto candidate=[&](){game.renderScene(cached,snapshots);return descriptions.prepare(cached,snapshots.sourceIdentity(cached),[&](const auto& value){++cachedPreparations;return prepare(value);});};
 auto reference=baseline();auto first=candidate();if(!equal(*reference,*first))throw std::runtime_error("Initial cache output differs");
 for(unsigned i=0;i<4;++i){baseline();candidate();}
 double before=0,after=0;std::size_t checksum=0;constexpr unsigned rounds=100;
 const auto measure=[&](bool useCache){const auto start=std::chrono::steady_clock::now();{
  auto value=useCache?candidate():baseline();checksum+=value->nodes.size()+value->resources.size();
 }return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();};
 const auto entity=runtime.entity(document.nodes.back().id);auto* transform=runtime.world().tryGet<ecs::TransformComponent>(entity);
 for(unsigned i=0;i<rounds;++i){
  transform->translation[0]=document.nodes.back().translation[0]+float(i%7)*.01F;
  if(i&1){before+=measure(false);after+=measure(true);}else{after+=measure(true);before+=measure(false);}
  if(i%10==0){auto a=baseline();auto b=candidate();if(!equal(*a,*b))throw std::runtime_error("Dynamic cache output differs");}
 }
 std::cout<<nlohmann::json{{"scope","Actual native document and same ECS state; game scene snapshot, render description and resource resolution only; simulation/camera/GPU excluded"},
  {"rounds",rounds},{"nodes",document.nodes.size()},{"resources",document.resources.size()},
  {"baselineMs",before/rounds},{"candidateMs",after/rounds},{"reduction",1-after/before},
  {"outputsEqual",true},{"retainedFrameUnchanged",equal(*reference,*first)},{"baselinePreparations",baselinePreparations},{"cachedPreparations",cachedPreparations},
  {"pooledFrames",descriptions.pooledFrameCount()},{"checksum",checksum}}.dump()<<'\n';return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
'''
(out/'NativeCacheBenchmark.cpp').write_text(source)
print('Prepared actual-native same-state operation control')
