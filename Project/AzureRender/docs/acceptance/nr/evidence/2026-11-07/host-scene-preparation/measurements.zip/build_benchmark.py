from pathlib import Path
import json,subprocess,sys
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,verify,digest
manifest=json.loads((build/'build-provenance.json').read_text());verify(root,manifest);source=inputs(root)
command=json.loads((out/'compile.json').read_text())['command']
for i,v in enumerate(command):
 if v.startswith('/Fo'):command[i]='/Fo'+str(out/'NativeCacheBenchmark.obj')
 elif v.startswith('/Fd'):command[i]='/Fd'+str(out/'NativeCacheBenchmark.pdb')
command[-1]=str(out/'NativeCacheBenchmark.cpp')
with (out/'benchmark-compile.log').open('wb') as log:r=subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(out/'benchmark-compile.log').read_text(errors='replace')[-4000:]
rsp=(out/'link.rsp').read_text().replace('"'+str(out/'AzureRenderApp.obj')+'" ','').replace('CMakeFiles\\AzurePlayer.dir\\src\\player\\main.cpp.obj','')
rsp='"'+str(out/'NativeCacheBenchmark.obj')+'" '+rsp.replace(str(out/'AzurePlayer'),str(out/'NativeCacheBenchmark'))
(out/'benchmark-link.rsp').write_text(rsp)
with (out/'benchmark-link.log').open('wb') as log:r=subprocess.run(['D:/Tools/VS2022BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/link.exe','@'+str(out/'benchmark-link.rsp')],cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(out/'benchmark-link.log').read_text(errors='replace')[-4000:]
assert source==inputs(root);verify(root,manifest)
(out/'benchmark-build.json').write_text(json.dumps(dict(command=command,sourceInputsUnchanged=True,productionProductsUnchanged=True,executableSha256=digest(out/'NativeCacheBenchmark.exe')),indent=2))
print('Private native operation control linked; production preserved',flush=True)
