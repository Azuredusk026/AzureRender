from pathlib import Path
import ctypes,json,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
manifest=json.loads((build/'build-provenance.json').read_text());verify(root,manifest);frozen=inputs(root)
ninja='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
listing=subprocess.check_output([ninja,'-C',str(build),'-t','commands',r'CMakeFiles\AzurePlayerHost.dir\src\app\AzureRenderApp.cpp.obj'],text=True)
entries=[r for r in listing.splitlines() if r.rstrip().replace('\\','/').endswith('/src/app/AzureRenderApp.cpp') and 'AZURE_WITH_EDITOR=0' in r]
assert len(entries)==1,len(entries)
api=ctypes.WinDLL('shell32').CommandLineToArgvW;api.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)];api.restype=ctypes.POINTER(ctypes.c_wchar_p)
free=ctypes.WinDLL('kernel32').LocalFree;free.argtypes=[ctypes.c_void_p];count=ctypes.c_int();ptr=api(entries[0],ctypes.byref(count))
try:command=[ptr[i] for i in range(count.value)]
finally:free(ptr)
for i,value in enumerate(command):
 if value.startswith('/Fo'):command[i]='/Fo'+str(out/'AzureRenderApp.obj')
 elif value.startswith('/Fd'):command[i]='/Fd'+str(out/'AzureRenderApp.pdb')
command[-1]=str(out/'AzureRenderApp.cpp');command.insert(-2,'/I'+str(root/'src/app'))
start=time.monotonic()
with (out/'compile.log').open('wb') as log:r=subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=300)
(out/'compile.json').write_text(json.dumps(dict(command=command,exitCode=r.returncode,seconds=time.monotonic()-start),indent=2));assert r.returncode==0,(out/'compile.log').read_text(errors='replace')[-3000:]
q=root/'build/runs/20261107-024335-current-cpu-hotspots-5b7d2c';rsp=(q/'link.rsp').read_text()
for name in ['CharacterSceneRenderer','AzureRenderFrame']:rsp=rsp.replace('"'+str(q/(name+'.obj'))+'" ','')
rsp='"'+str(out/'AzureRenderApp.obj')+'" '+rsp.replace(str(q),str(out));(out/'link.rsp').write_text(rsp)
with (out/'link.log').open('wb') as log:r=subprocess.run(['D:/Tools/VS2022BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/link.exe','@'+str(out/'link.rsp')],cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert r.returncode==0,(out/'link.log').read_text(errors='replace')[-3000:]
assert inputs(root)==frozen;verify(root,manifest)
(out/'build.json').write_text(json.dumps(dict(sourceBase='9004b9c-with-unlit-blend-fast-path',productionUnchanged=True,source=frozen,privatePlayerSha256=digest(out/'AzurePlayer.exe')),indent=2))
print('One private host attribution linked; production source and products unchanged',flush=True)
