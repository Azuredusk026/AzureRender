from pathlib import Path
import json
out=Path(__file__).resolve().parent;root=out.parents[2]
source=(root/'src/app/AzureRenderApp.cpp').read_text();original=source
def replace(a,b):
 global source
 assert source.count(a)==1,(a,source.count(a));source=source.replace(a,b)
replace('    const double currentTime = frontend_->timeSeconds();','''    const bool hostProbe=submissionCounters_.frameAttempts>=310&&submissionCounters_.frameAttempts<330;
    auto hostProbeLast=std::chrono::steady_clock::time_point{};
    nlohmann::json hostProbeStages;
    if(hostProbe)hostProbeLast=std::chrono::steady_clock::now();
    const auto hostMark=[&](const char* name){if(hostProbe){const auto now=std::chrono::steady_clock::now();hostProbeStages[name]=std::chrono::duration<double,std::milli>(now-hostProbeLast).count();hostProbeLast=std::chrono::steady_clock::now();}};
    const double currentTime = frontend_->timeSeconds();''')
replace('    double elapsed=0;','    hostMark("input");\n    double elapsed=0;')
replace('{elapsed=game?game->advance(rawDeltaSeconds):runtime_.beginFrame(rawDeltaSeconds);if(presentationRuntime_)presentationRuntime_->update(elapsed);}',
 '{elapsed=game?game->advance(rawDeltaSeconds):runtime_.beginFrame(rawDeltaSeconds);hostMark("advance");if(presentationRuntime_)presentationRuntime_->update(elapsed);hostMark("presentation");}')
replace('    std::shared_ptr<const azurerender::scene::SceneDescription> gameDescription;','    hostMark("gameSnapshot");\n    std::shared_ptr<const azurerender::scene::SceneDescription> gameDescription;')
replace('    std::optional<azurerender::CameraViewDescriptor> gameView;','    hostMark("descriptionAndResources");\n    std::optional<azurerender::CameraViewDescriptor> gameView;')
replace('    if(auto* presentation=activePresentation())frame.animations=presentation->animations();','    hostMark("camera");\n    if(auto* presentation=activePresentation())frame.animations=presentation->animations();')
replace('    pausedTimeOffset_ +=','    hostMark("animationAndObservation");\n    pausedTimeOffset_ +=')
replace('    fixedSimulationStarted_ = true;','    hostMark("commitSnapshot");\n    fixedSimulationStarted_ = true;')
replace('    frame.renderSettings = &effectiveRenderSettings_;','    hostMark("settings");\n    frame.renderSettings = &effectiveRenderSettings_;')
replace('    frame.swapchainHeight = sceneRenderExtent_.height;','''    frame.swapchainHeight = sceneRenderExtent_.height;
    hostMark("frameFields");
    if(hostProbe)azurerender::RuntimeDiagnostics::instance().info("cpu-host-prepare",nlohmann::json{{"frame",submissionCounters_.frameAttempts},{"stagesMs",hostProbeStages}}.dump());''')
(out/'AzureRenderApp.cpp').write_text(source)
import difflib
(out/'probe.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),source.splitlines(True))))
print('Prepared one private host-stage attribution without production mutations')
