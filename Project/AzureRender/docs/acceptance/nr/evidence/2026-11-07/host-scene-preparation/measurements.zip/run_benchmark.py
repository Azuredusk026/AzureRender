from pathlib import Path
import json,os,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2]
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
manifest=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text());verify(root,manifest);source=inputs(root)
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
env=os.environ.copy();env['PATH']=str(root/'build/ninja-msvc-release')+';'+env.get('PATH','')
command=[str(out/'NativeCacheBenchmark.exe'),str(project),str(root)];start=time.monotonic()
with (out/'benchmark-output.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(out/'benchmark-output.log').read_text(errors='replace')[-4000:]
result=json.loads((out/'benchmark-output.log').read_text().splitlines()[-1]);assert result['outputsEqual'] and result['retainedFrameUnchanged'] and result['cachedPreparations']==1
assert source==inputs(root);verify(root,manifest)
host=json.loads((out/'native/results.json').read_text())['hostStages']
affected=host['gameSnapshot']['mean']+host['descriptionAndResources']['mean']
result.update(command=command,seconds=time.monotonic()-start,sourceBase='723286a-with-host-scene-caches',productionUnchanged=True,
 affectedHostStagesMeanMs=affected,estimatedCpuSavedMs=affected*result['reduction'],estimateScope='Applying the same-operation reduction to the measured host stages; actual whole-frame gain remains pending')
(out/'benchmark-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
