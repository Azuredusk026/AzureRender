from pathlib import Path
import json,hashlib,sys,traceback,struct
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-065740-surface-radiance-cost-d3896e';a=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc';state=json.loads((a/'state.json').read_text());profile=json.loads((a/'events/profile.json').read_text());cap=None;c=None
report=dict(status='starting',sourceBase='521e002',scope='Upper-bound cost ablation on current matching fragment programs; output intentionally omits SSR and is not a compatibility candidate',captureSha256=state['captureSha256'],formalAcceptance=False,outputCompatibilityClaimed=False)
def save():(out/'compare-state.json').write_text(json.dumps(report,indent=2))
def durations():return {int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 name='mesh_object_bindless_clipmap_field_early.frag.spv';key=next(k for k,v in profile['shaders'].items() if v.get('programFile')==name);entry=profile['shaders'][key];rows=[];shader=None
 for event in [r for r in profile['measurements'] if r['shader']==key]:
  c.SetFrameEvent(event['event'],True);pipe=c.GetPipelineState();vk=c.GetVulkanPipelineState();reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel);assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==entry['sha256']
  push=bytes(vk.pushconsts);cls,features=struct.unpack_from('<II',push,112);data=bytes(vk.fragmentShader.specializationData)
  specialization={v.name:struct.unpack_from('<I',data,v.byteOffset)[0] for block in reflection.constantBlocks if block.compileConstants for v in block.variables}
  if specialization.get('azureOrdinaryOpaque')!=1:continue
  descriptor=pipe.GetConstantBlock(rd.ShaderStage.Pixel,0,0).descriptor;camera=bytes(c.GetBufferData(descriptor.resource,descriptor.byteOffset,144));lighting=struct.unpack_from('<f',camera,64)[0];qa=struct.unpack_from('<4f',camera,128);assert lighting==1 and qa[0]==qa[1]==0
  rows.append(dict(event=event['event'],classId=cls,features=features,specialization=specialization));shader=pipe.GetShader(rd.ShaderStage.Pixel)
 assert shader is not None and rows
 program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/name).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert program!=rd.ResourceId.Null(),errors
 report.update(status='compiled',rows=rows,programSha256=entry['sha256']);save();durations();timings=[dict(mode='baseline',milliseconds=durations())]
 c.ReplaceResource(shader,program)
 for unused in range(2):timings.append(dict(mode='ablation',milliseconds=durations()))
 c.RemoveReplacement(shader);timings.append(dict(mode='baseline',milliseconds=durations()))
 matched={r['event'] for r in rows};report.update(status='compared',timings=timings,summary=[dict(mode=r['mode'],allEventMs=sum(r['milliseconds'].values()),matchedEventMs=sum(v for e,v in r['milliseconds'].items() if e in matched)) for r in timings]);save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='compared' else 1)
