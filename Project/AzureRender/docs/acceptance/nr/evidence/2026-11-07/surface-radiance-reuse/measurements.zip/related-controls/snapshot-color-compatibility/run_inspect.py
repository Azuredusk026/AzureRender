from pathlib import Path
import json,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from run_playable_performance import freeze_products
source=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe');start=time.monotonic()
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
with (out/'inspect-driver.log').open('wb') as log:r=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'read_capture.py')],stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=180)
state=json.loads((out/'inspect-state.json').read_text());assert r.returncode==0 and state['status']=='inspected',state
assert source==inputs(root) and all(digest(Path(p))==v for p,v in products.items())
(out/'inspect-results.json').write_text(json.dumps(dict(status='inspected',seconds=time.monotonic()-start,productionUnchanged=True),indent=2))
r=subprocess.run([sys.executable,'-X','utf8',str(out/'analyze.py')],cwd=root);assert r.returncode==0
