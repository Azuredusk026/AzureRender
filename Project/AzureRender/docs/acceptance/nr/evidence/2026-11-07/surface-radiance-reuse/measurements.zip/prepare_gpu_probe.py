from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2];old=root/'build/runs/20261107-030141-shadow-visibility-reuse-90fb90/candidate-source/tests/ShadowVisibilitySurfaceGpuTests.cpp'
s=old.read_text().replace('ShadowVisibilitySurface','SurfaceRadianceCache').replace('ShadowVisibilityIdentity','SurfaceRadianceIdentity').replace('shadowVisibilityIdentity','surfaceRadianceIdentity').replace('visibility','value').replace('shadow_value','surface_radiance')
s=s.replace('float depth=.25F,value=.125F','float depth=.25F,value=1000.03125F')
def edit(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
start=s.index('  rhi::RenderPassDesc desc;');end=s.index('  pass=rhi.createRenderPass(desc);',start)
s=s[:start]+'''  rhi::RenderPassDesc desc;
  for(unsigned kind=0;kind<4;++kind)desc.attachments.push_back({SurfaceRadianceCache::format(kind),VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,true,true,false});
  desc.attachments.push_back({VK_FORMAT_D32_SFLOAT,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,true,true,true});desc.depthAttachment=4;desc.externalReadDependency=true;
'''+s[end:]
s=s.replace('cache.value(slot).view,cache.identity(slot).view,depthView','cache.texture(slot,0).view,cache.texture(slot,1).view,cache.texture(slot,2).view,cache.texture(slot,3).view,depthView')
start=s.index('  setLayout=rhi.createDescriptorSetLayout(');end=s.index('\n  rhi::PushConstantRangeDesc',start)
s=s[:start]+'''  std::vector<rhi::DescriptorBindingDesc> bindings;for(unsigned kind=0;kind<4;++kind)bindings.push_back({38+kind,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_FRAGMENT_BIT});
  setLayout=rhi.createDescriptorSetLayout(bindings);'''+s[end:]
s=s.replace('poolDesc.sizes={{VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,2}}','poolDesc.sizes={{VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,4}}').replace('pipeline.colorAttachmentCount=2','pipeline.colorAttachmentCount=4')
s=s.replace('readValues=host.allocator.createBuffer(extent.width*extent.height*4','readValues=host.allocator.createBuffer(extent.width*extent.height*16')
s=s.replace('{SurfaceRadianceCache::valueClear(),SurfaceRadianceCache::identityClear(),clearDepth}','{SurfaceRadianceCache::clearValue(0),SurfaceRadianceCache::clearValue(1),SurfaceRadianceCache::clearValue(2),SurfaceRadianceCache::clearValue(3),clearDepth}')
start=s.index(' void bind(unsigned slot)');end=s.index('\n void read(',start)
s=s[:start]+''' void bind(unsigned slot){for(unsigned kind=0;kind<4;++kind)rhi.writeDescriptorImage({set,38+kind,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
  source->texture(slot,kind).view,source->sampler(),VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL});}'''+s[end:]
s=s.replace('cache.identity(slot).image.image:cache.value(slot).image.image','cache.texture(slot,3).image.image:cache.texture(slot,0).image.image').replace('readValues.mapped)[i]','readValues.mapped)[4*i]')
s=s.replace('r.read(*r.source,0,.125F,&identity)','r.read(*r.source,0,1000.03125F,&identity)').replace('r.read(*r.source,1,-1)','r.read(*r.source,1,0)').replace('r.read(*r.target,0,.125F)','r.read(*r.target,0,1000.53125F)')
s=s.replace('Shadow value GPU','Radiance cache GPU').replace('GPU value sample mismatch','GPU radiance precision/composition mismatch')
(root/'tests/SurfaceRadianceCacheGpuTests.cpp').write_text(s)
print('Independent Vulkan precision, identity, coplanar winner and frame-slot probe prepared',flush=True)
