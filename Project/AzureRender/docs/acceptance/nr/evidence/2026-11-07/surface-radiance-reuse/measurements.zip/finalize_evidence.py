from pathlib import Path
import json,sys,zipfile,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];e=root/'docs/acceptance/nr/evidence/2026-11-07/surface-radiance-reuse';e.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
restore=json.loads((out/'restoration.json').read_text());assert restore['status']=='restored' and restore['playerCodeSectionIdentical']
baseline=json.loads((out/'baseline-products.json').read_text());candidate=json.loads((out/'candidate-record.json').read_text());image=json.loads((out/'image/results.json').read_text());assert image['status']=='failed'
provenance=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text());verify(root,provenance);assert inputs(root)==baseline['source']
assert json.loads((out/'candidate-build-provenance.json').read_text())['source']==json.loads((out/'image/frozen-inputs.json').read_text())['source']
related={'snapshot-color-compatibility':root/'build/runs/20261107-064529-snapshot-color-compatibility-afc6ae','surface-radiance-cost':root/'build/runs/20261107-065740-surface-radiance-cost-d3896e','uniform-material-index':root/'build/runs/20261107-064818-uniform-material-index-daae08'}
raw={}
for key,folder in related.items():
 raw[key]={str(p.relative_to(folder)):dict(bytes=p.stat().st_size,sha256=digest(p)) for p in folder.rglob('*') if p.is_file() and p.suffix in ['.bin','.spv']}
(out/'diagnostic-data-inputs.json').write_text(json.dumps(raw,indent=2))
archive=e/'measurements.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(out.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(out)
  if any(v in rel.parts for v in ['baseline','candidate-programs','__pycache__','.azure']):continue
  if p.suffix.lower() in ['.py','.json','.log','.xml','.cpp','.hpp','.inc','.diff','.frag','.vert','.glsl','.txt','.png']:z.write(p,str(rel))
 for key,folder in related.items():
  for p in sorted(folder.rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts and p.suffix.lower() in ['.py','.json','.log','.cpp','.hpp','.glsl','.frag','.vert']:z.write(p,str(Path('related-controls')/key/p.relative_to(folder)))
summary=dict(schemaVersion=1,status='isolated-native-zero-pixel-gate-failed',sourceBase='521e002',production='521e002 runtime inputs restored exactly',candidateProgramsAdded=47,existing663ProgramsByteIdentical=True,cacheBytesAt1440=471859200,required=dict(cpuP95Ms=8,gpuP95Ms=16.6,formalSamples=1800,frozenNativeRgbChangedPixels=0,overallVisual='failed-user-review'),costControl=json.loads((related['surface-radiance-cost']/'compare-results.json').read_text()),qualification=json.loads((out/'qualification.json').read_text()),image=image,checks=json.loads((out/'build-checks.json').read_text()),restoration=restore,performancePairExecuted=False,formalPerformanceAccepted=False,overallVisualAccepted=False,precisionCause='Unconfirmed: producer/consumer arithmetic, intermediate precision and compiler contraction require independent investigation.',implementationBoundary='Exact depth/instance/triangle/material identity, full FP32 payloads, nearest integer sampling, quad-uniform reuse with full-quads/quad-derivatives/maximal-reconvergence support. Unsupported capability and format use complete shading.',limitations=['Output-changing ablation is a cost upper-bound experiment, not a compatible optimization.','Four-frame candidate image time was 272.719 seconds; the earlier original four-frame batch took 125.094 seconds. Sources and cold shader caches differ, so this is an observed startup cost rather than a controlled compilation benchmark.','Mechanism GPU probe passed on RTX 4060 Laptop; unsupported-quad recording fallback is a NullRhi check, not dual-device native acceptance.','Native image RGB zero-pixel gate failed; the planned performance pair was skipped.','Formal frame budgets, power qualification and overall appearance remain pending.'],archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=digest(archive)))
(e/'results.json').write_text(json.dumps(summary,indent=2))
manifest=dict(schemaVersion=1,kind='NativeOptimizationEvidence',sourceBase='521e002',status=summary['status'],candidateSourceHashes=candidate['sourceHashes'],candidatePlayerSha256=candidate['playerSha256'],candidateBuildProvenanceSha256=digest(out/'candidate-build-provenance.json'),restoredBuildProvenanceSha256=digest(root/'build/ninja-msvc-release/build-provenance.json'),retainedTest=dict(path='tests/DepthPrefillRecordingTests.cpp',sha256=digest(root/'tests/DepthPrefillRecordingTests.cpp')),sourceCapture=dict(path='build/runs/20261107-061745-current-gpu-cost-2de6bc/current_frame320.rdc',sha256='9079f51daf9e3d39a3de717a64f226080a86e013d379ea2e5a7eedcbf47ee103',preserved=True),results=dict(file='results.json',sha256=digest(e/'results.json')),archive=summary['archive'])
(e/'manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(dict(status=summary['status'],archive=summary['archive'],restored=restore['status'])),flush=True)
