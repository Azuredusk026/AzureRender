from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2]
s=(root/'build/runs/20261107-062757-read-scope-barriers-3c24e5/build_and_check.py').read_text();first=s.index('targets=');end=s.index('\ncommands=',first)
s=s[:first]+"targets=['AzureSurfaceRadianceCacheTests','AzureSurfaceRadianceCacheGpuTests','AzureSurfaceRadianceRecordingTests','AzureDepthPrefillRecordingTests','AzureDepthOnlyShadowRecordingTests','AzureMaterialPipelinePolicyTests','AzureRenderNullRhiPassTests']"+s[end:]
s=s.replace('RenderGraph|BufferBarrierBatch|NullRhiPass|StaticSkinningRecording|NodeOpacityRecording|DepthOnlyShadowRecording','SurfaceRadianceCache|SurfaceRadianceCacheGpu|SurfaceRadianceRecording|DepthPrefillRecording|DepthOnlyShadowRecording|MaterialPipelinePolicy|NullRhiPass')
(out/'build_and_check.py').write_text(s)
