from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent;report=json.loads((out/'inspect-state.json').read_text());assert report['status']=='inspected',report
snapshot=np.fromfile(out/'snapshot.bin',dtype='<f2').reshape(720,1280,4)
rw=report['sources']['reflection']['width'];rh=report['sources']['reflection']['height']
reflection=np.fromfile(out/'reflection.bin',dtype='<f4').reshape(rh,rw,4)
zero=reflection[:,:,3]==0;conservative=zero.copy()
for y in [-1,0,1]:
 for x in [-1,0,1]:conservative&=np.roll(np.roll(zero,y,axis=0),x,axis=1)
conservative[[0,-1],:]=False;conservative[:,[0,-1]]=False
assert 1280%rw==0 and 720%rh==0
conservative=np.repeat(np.repeat(conservative,720//rh,axis=0),1280//rw,axis=1)
rows=[]
for row in report['rows']:
 before=np.fromfile(out/row['files'][0]['file'],dtype='<u2').reshape(720,1280,4);after=np.fromfile(out/row['files'][1]['file'],dtype='<u2').reshape(720,1280,4)
 written=np.any(before[:,:,:3]!=after[:,:,:3],axis=2);same=np.all(after[:,:,:3]==snapshot.view('<u2')[:,:,:3],axis=2);eligible=written&conservative
 delta=np.abs(after.view('<f2').astype(np.float32)[:,:,:3]-snapshot.astype(np.float32)[:,:,:3])
 rows.append(dict(event=row['event'],observedColorWrites=int(written.sum()),conservativeZeroReflectionWrites=int(eligible.sum()),snapshotRgbBytesEqual=int((eligible&same).sum()),snapshotRgbBytesDifferent=int((eligible&~same).sum()),maxAbsoluteColorDifference=float(delta[eligible].max()) if eligible.any() else None))
result=dict(status='analyzed',scope=report['scope'],captureSha256=report['captureSha256'],conservativeZeroReflectionPixels=int(conservative.sum()),rows=rows,formalAcceptance=False,productionChanged=False)
(out/'analysis-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
