from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2]
s=(root/'build/runs/20261107-030141-shadow-visibility-reuse-90fb90/candidate-source/tests/ShadowVisibilityRecordingTests.cpp').read_text()
s=s.replace('shadowVisibility','surfaceRadiance').replace('Shadow visibility','Surface radiance').replace('maxColorAttachments=4','maxColorAttachments=6').replace('settings.faceSdfFeature=false','settings.sceneLightingEnabled=true;settings.faceSdfFeature=false')
s=s.replace('128*96*20*2','128*96*64*2').replace('write.binding==38||write.binding==39','write.binding>=38&&write.binding<=41').replace('enabled?5U:3U','enabled?7U:3U')
s=s.replace('require(prepass->renderPass.clearValues[3].color.float32[0]==-1,"Visibility begins invalid");require(prepass->renderPass.clearValues[4].color.uint32[0]==UINT32_MAX,"Identity begins invalid");','require(prepass->renderPass.clearValues[6].color.uint32[0]==UINT32_MAX,"Identity begins invalid");')
s=s.replace('masks=15/15/1/15/','masks=15/15/15/15/15/15/').replace('Ordinary snapshot enables both cache outputs','Ordinary snapshot enables all cache outputs')
(root/'tests/SurfaceRadianceRecordingTests.cpp').write_text(s)
print('Fixed/indexed and vertex/compute recording contracts prepared',flush=True)
