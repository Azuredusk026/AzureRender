#version 450
#extension GL_EXT_shader_quad_control : require
#extension GL_EXT_maximal_reconvergence : require
layout(quad_derivatives) in;
layout(full_quads) in;
layout(location=0) out vec4 color;
void main() [[maximally_reconverges]] {color=vec4(subgroupQuadAll(gl_FragCoord.x>0)?1.0:0.0);}
