from pathlib import Path
import os,json,time,subprocess
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release'
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
targets=['AzureSurfaceRadianceCacheTests','AzureSurfaceRadianceCacheGpuTests','AzureSurfaceRadianceRecordingTests','AzureDepthPrefillRecordingTests','AzureDepthOnlyShadowRecordingTests','AzureMaterialPipelinePolicyTests','AzureRenderNullRhiPassTests']
commands=[['cmd','/d','/c',str(root/'tools/msvc_env.bat'),str(root/'build/reinstall-environment/venv/Scripts/python.exe'),'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config','Release',*[arg for target in targets for arg in ['--test-target',target]]],['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe','--test-dir',str(build),'-R','^AzureRender\.(SurfaceRadianceCache|SurfaceRadianceCacheGpu|SurfaceRadianceRecording|DepthPrefillRecording|DepthOnlyShadowRecording|MaterialPipelinePolicy|NullRhiPass)$','--output-on-failure','--no-tests=error','--output-junit',str(out/'release-checks.xml')]]
rows=[]
for kind,command,deadline in zip(['build','checks'],commands,[1200,240]):
 start=time.monotonic()
 with (out/('release-'+kind+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=deadline)
 row=dict(kind=kind,exitCode=r.returncode,seconds=time.monotonic()-start,command=command);rows.append(row);(out/'build-checks.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
 assert r.returncode==0,(out/('release-'+kind+'.log')).read_text(errors='replace')[-6000:]

