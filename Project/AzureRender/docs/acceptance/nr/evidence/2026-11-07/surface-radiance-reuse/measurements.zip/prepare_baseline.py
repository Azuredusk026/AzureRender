from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2]
s=(root/'build/runs/20261107-062757-read-scope-barriers-3c24e5/freeze_baseline.py').read_text()
start=s.index("for name in [");end=s.index(':\n target=',start)
names=['CMakeLists.txt','src/render/RenderContext.hpp','src/app/AzureRenderApp.cpp','src/app/AzureRenderApp.hpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','src/scenes/CharacterMaterialSampling.inc','shaders/mesh.vert','shaders/mesh.frag','src/render/MaterialPipelinePolicy.hpp']
s=s[:start]+'for name in '+repr(names)+s[end:];s=s.replace('956f501','521e002')
(out/'freeze_baseline.py').write_text(s)
