from pathlib import Path
import json,subprocess
out=Path(__file__).resolve().parent;root=out.parents[2];private=out/'candidate-source';private.mkdir()
mesh=(root/'shaders/mesh.frag').read_text();needle='    if(azureWritePlainUnlitBeauty(baseColor,geometricNormal,platformMask))return;'
hook='''    if(azureOrdinaryOpaque&&camera.clusterLighting.x>.5
        &&int(floor(camera.qaParameters.x+.5))==0&&int(floor(camera.qaParameters.y+.5))==0){
        // Cost-only ablation: the source color omits current SSR composition.
        // This program is never a production or compatibility candidate.
        outputColor=texelFetch(opaqueSceneColor,ivec2(AZURE_FRAGMENT_COORD.xy),0);
        outputNormal=vec4(geometricNormal*.5+.5,0);azureWriteDisplayMask(1.0);return;
    }
'''
assert needle in mesh;mesh=mesh.replace(needle,hook+needle);(private/'mesh.frag').write_text(mesh)
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());name='mesh_object_bindless_clipmap_field_early.frag.spv';p=next(p for p in manifest['programs'] if p['output']==name)
command=[manifest['compiler'],*[f'-D{d}' for d in p['defines']],f'-I{private}',f'-I{root/"shaders"}',str(private/'mesh.frag'),'-o',str(out/name)]
r=subprocess.run(command,capture_output=True,text=True);(out/'candidate-build.json').write_text(json.dumps(dict(command=command,exitCode=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2));assert r.returncode==0,r.stderr
