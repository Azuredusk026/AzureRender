from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time,os,struct
out=Path(__file__).resolve().parent;root=out.parents[2];build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'));from build_provenance import digest,inputs,verify
before=json.loads((out/'baseline-products.json').read_text());assert inputs(root)==before['source']
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VK_LOADER_DRIVERS_SELECT='*nv-vk64*');env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None)
targets=['AzureDepthPrefillRecordingTests','AzureDepthOnlyShadowRecordingTests','AzureMaterialPipelinePolicyTests','AzureRenderNullRhiPassTests'];command=['cmd','/d','/c',str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config','Release',*[a for t in targets for a in ['--test-target',t]]]
with (out/'restore-configure.log').open('wb') as log:r=subprocess.run(['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe','-S',str(root),'-B',str(build)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(out/'restore-configure.log').read_text(errors='replace')
start=time.monotonic()
with (out/'restore-build.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
assert r.returncode==0,r.returncode
checks=['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe','--test-dir',str(build),'-R','^AzureRender\\.(DepthPrefillRecording|DepthOnlyShadowRecording|MaterialPipelinePolicy|NullRhiPass)$','--output-on-failure','--no-tests=error','--output-junit',str(out/'restore-checks.xml')]
with (out/'restore-checks.log').open('wb') as log:r=subprocess.run(checks,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
assert r.returncode==0,(out/'restore-checks.log').read_text(errors='replace')
def code(path):
 b=path.read_bytes();pe=struct.unpack_from('<I',b,0x3c)[0];n=struct.unpack_from('<H',b,pe+6)[0];opt=struct.unpack_from('<H',b,pe+20)[0]
 for i in range(n):
  s=pe+24+opt+40*i
  if b[s:s+8].rstrip(b'\0')==b'.text':
   count,offset=struct.unpack_from('<II',b,s+16);return hashlib.sha256(b[offset:offset+count]).hexdigest()
 raise AssertionError('Missing code section')
assert {p.name:digest(p) for p in (build/'shaders').glob('*.spv')}==before['programs']
assert code(build/'AzurePlayer.exe')==code(out/'baseline/AzurePlayer.exe')
provenance=json.loads((build/'build-provenance.json').read_text());verify(root,provenance)
result=dict(status='restored',sourceInputsByteIdentical=inputs(root)==before['source'],all663ProgramsByteIdentical=True,playerCodeSectionIdentical=True,playerSha256=digest(build/'AzurePlayer.exe'),playerCodeSectionSha256=code(build/'AzurePlayer.exe'),seconds=time.monotonic()-start,buildCommand=command,checkCommand=checks,checksPassed=4,retainedTestCorrection='Depth prefill recording separately verifies existing ordinary and fixed-class early-depth pipelines, material eligibility, opacity and MSAA. The class implementation is present in the frozen baseline source.',provenanceVerified=True)
(out/'restoration.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
