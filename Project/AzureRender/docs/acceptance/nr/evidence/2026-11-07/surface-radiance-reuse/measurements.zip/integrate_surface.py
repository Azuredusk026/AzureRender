from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[2];p=root/'src/scenes/CharacterSceneRenderer.cpp';s=p.read_text()
def edit(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
edit('    bindlessTextures_ = access.mode==ResourceAccessMode::Indexed;', '''    auto radianceRequirements=objectShadowPrepared_?objectRequirements:requirements;
    radianceRequirements.sampledImageSlots+=4;radianceRequirements.fixedSampledImageSlots+=4;
    radianceRequirements.fragmentColorAttachments=std::max<std::uint64_t>(6,radianceRequirements.fragmentColorAttachments);
    const auto plainOrdinary=[](const LoadedAsset& mesh){return std::any_of(mesh.materials.begin(),mesh.materials.end(),[](const AssetMaterial& material){
        return ordinaryOpaqueMaterial(material)&&!extendedMaterialLighting(material)&&!material.coverageTexture.present;});};
    bool hasRadianceMaterial=plainOrdinary(asset_);for(const auto& resource:additionalResources_)hasRadianceMaterial|=plainOrdinary(resource->asset);
    surfaceRadianceCapable_=hasRadianceMaterial&&context.fragmentPrimitiveIdentity&&limits.maxColorAttachments>=6
        &&context.renderSettings&&context.renderSettings->sceneLightingEnabled
        &&ResourceAccessProfile::select(capabilities,radianceRequirements).mode==access.mode
        &&SurfaceRadianceCache::supported(*rhi_,context.renderExtent,static_cast<unsigned>(kMaxFramesInFlight));
    bindlessTextures_ = access.mode==ResourceAccessMode::Indexed;''')
edit('    rhi::RenderPassDesc pass;pass.attachments=', '''    if(surfaceRadianceCapable_&&context.rasterizationSamples==VK_SAMPLE_COUNT_1_BIT
        &&SurfaceRadianceCache::supported(*rhi_,context.renderExtent,static_cast<unsigned>(kMaxFramesInFlight)))
        surfaceRadiance_=std::make_unique<SurfaceRadianceCache>(*rhi_,context.renderExtent,static_cast<unsigned>(kMaxFramesInFlight));
    rhi::RenderPassDesc pass;pass.attachments=''')
edit('    pass.depthAttachment=2;pass.externalReadDependency=true;overlayDepthPass_=rhi_->createRenderPass(pass);', '''    if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)
        pass.attachments.push_back({SurfaceRadianceCache::format(kind),VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,true,true,false});
    pass.depthAttachment=2;pass.externalReadDependency=true;overlayDepthPass_=rhi_->createRenderPass(pass);''')
edit('        overlayDepthFramebuffers_[frame]=rhi_->createFramebuffer({overlayDepthPass_,{color.view,target.view,overlayDepthViews_[frame]},context.renderExtent.width,context.renderExtent.height});', '''        std::vector<VkImageView> attachments{color.view,target.view,overlayDepthViews_[frame]};
        if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)attachments.push_back(surfaceRadiance_->texture(static_cast<unsigned>(frame),kind).view);
        overlayDepthFramebuffers_[frame]=rhi_->createFramebuffer({overlayDepthPass_,attachments,context.renderExtent.width,context.renderExtent.height});''')
edit('    if(overlayDepthPass_)rhi_->destroyRenderPass(overlayDepthPass_);overlayDepthPass_=VK_NULL_HANDLE;', '    surfaceRadiance_.reset();\n    if(overlayDepthPass_)rhi_->destroyRenderPass(overlayDepthPass_);overlayDepthPass_=VK_NULL_HANDLE;')
edit('    const auto prepass=graph.addGraphicsPass("character-opaque-depth",overlayBegin,', '''    if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)overlayBegin.clearValues.push_back(SurfaceRadianceCache::clearValue(kind));
    const auto prepass=graph.addGraphicsPass("character-opaque-depth",overlayBegin,''')
edit('    graph.use(prepass,resources.shadow,RenderGraphUsage::Sampled,false);', '''    std::array<RenderGraph::ResourceId,SurfaceRadianceCache::kAttachments> radianceResources{};
    if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind){
        rhi::ImageBarrierDesc initial;initial.image=surfaceRadiance_->texture(context.currentFrame,kind).image.image;
        radianceResources[kind]=graph.importImage("character-surface-radiance-"+std::to_string(kind),initial);
        graph.attachment(prepass,radianceResources[kind],RenderGraphUsage::ColorAttachment,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
    }
    graph.use(prepass,resources.shadow,RenderGraphUsage::Sampled,false);''')
edit('    graph.use(main,snapshotColor,RenderGraphUsage::Sampled,false);', '''    graph.use(main,snapshotColor,RenderGraphUsage::Sampled,false);
    if(surfaceRadiance_)for(auto resource:radianceResources)graph.use(main,resource,RenderGraphUsage::Sampled,false);''')
edit('        depthDesc.colorAttachmentCount=2;\n        depthDesc.colorWriteMasks.assign(2,0xf);', '''        depthDesc.colorAttachmentCount=surfaceRadiance_?6U:2U;
        depthDesc.colorWriteMasks.assign(depthDesc.colorAttachmentCount,0);depthDesc.colorWriteMasks[0]=0xf;depthDesc.colorWriteMasks[1]=0xf;''')
edit('initializeMaterialClassPipelines(context,integralBase,depthDesc);','initializeMaterialClassPipelines(context,integralBase,depthDesc,meshVertexPath(objectShadowPrepared_?"mesh_object":"mesh"));')
edit('desc.colorWriteMasks={0,VK_COLOR_COMPONENT_R_BIT};','desc.colorWriteMasks.assign(desc.colorAttachmentCount,0);desc.colorWriteMasks[1]=VK_COLOR_COMPONENT_R_BIT;')
edit('auto prefill=desc;prefill.colorWriteMasks={0,0};','auto prefill=desc;prefill.colorWriteMasks.assign(prefill.colorAttachmentCount,0);')
edit('                shell.colorAttachmentCount=2;', '                shell.colorAttachmentCount=surfaceRadiance_?6U:2U;')
edit('                shell.colorWriteMasks={0,VK_COLOR_COMPONENT_R_BIT};','                shell.colorWriteMasks.assign(shell.colorAttachmentCount,0);shell.colorWriteMasks[1]=VK_COLOR_COMPONENT_R_BIT;')
edit('frameCount * (textureSlots + 4 +','frameCount * (textureSlots + 4 + (surfaceRadianceCapable_?4U:0U) +')
edit('descriptorCount * ((outlineProjectionEnabled_?16U:15U)+','descriptorCount * ((outlineProjectionEnabled_?16U:15U)+(surfaceRadianceCapable_?4U:0U)+')
before='        descriptorSetLayout_=rhi_->createDescriptorSetLayout(bindings);';assert s.count(before)==2
s=s.replace(before,'''        if(surfaceRadianceCapable_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)
            bindings.push_back({38U+kind,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_FRAGMENT_BIT});
        descriptorSetLayout_=rhi_->createDescriptorSetLayout(bindings);''')
edit('    const auto writeSceneImages=[this](VkDescriptorSet set){', '''    const auto writeRadiance=[&](VkDescriptorSet set,unsigned frame){if(!surfaceRadiance_)return;
        for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)
            rhi_->writeDescriptorImage({set,38U+kind,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,surfaceRadiance_->texture(frame,kind).view,surfaceRadiance_->sampler(),VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL});
    };
    const auto writeSceneImages=[this](VkDescriptorSet set){''')
before='            writeSceneImages(uniformWrite.set);\n            if(viewFog_){';assert s.count(before)==2
s=s.replace(before,'            writeSceneImages(uniformWrite.set);writeRadiance(uniformWrite.set,static_cast<unsigned>(frame));\n            if(viewFog_){')
# Both direct and graph recording share the same clear and sampled dependency.
edit('    context.commands->beginRenderPass(begin);', '''    if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)begin.clearValues.push_back(SurfaceRadianceCache::clearValue(kind));
    context.commands->beginRenderPass(begin);''')
anchor='    if(snapshotMultisampling_)snapshotMultisampling_->recordResolve(*context.commands,context.currentFrame,context.currentFrame);'
edit(anchor,anchor+'''\n    if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)
        context.commands->imageBarrier({surfaceRadiance_->texture(context.currentFrame,kind).image.image,
            VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,1,
            VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT});
''')
# The reserved first vertex push word carries exact source index identity.
edit('            if(displaced)std::memcpy(&morph.weights[0],&global,4);', '''            if(displaced)std::memcpy(&morph.weights[0],&global,4);''') if False else None
needle='                morph.nodeOpacity=run.opacity;\n                commands.pushConstants(pipelineLayout_,VK_SHADER_STAGE_VERTEX_BIT|VK_SHADER_STAGE_FRAGMENT_BIT,sizeof(material),&morph,sizeof(morph));'
assert s.count(needle)==1
s=s.replace(needle,'''                if(surfaceRadiance_){const auto first=primitive.firstIndex<=UINT32_MAX&&primitive.indexCount<=UINT32_MAX-primitive.firstIndex
                    ?static_cast<std::uint32_t>(primitive.firstIndex):UINT32_MAX;std::memcpy(&morph.weights[0],&first,4);}
'''+needle)
needle='    morphConstants.gizmoTransform=primitiveGizmoTransform(gizmo,&primitive-mesh.primitives.data());'
assert s.count(needle)==1
s=s.replace(needle,needle+'''\n    if(surfaceRadiance_){const auto first=primitive.firstIndex<=UINT32_MAX&&primitive.indexCount<=UINT32_MAX-primitive.firstIndex
        ?static_cast<std::uint32_t>(primitive.firstIndex):UINT32_MAX;std::memcpy(&morphConstants.weights[0],&first,4);}
''')
edit('         << "  \\"ordinaryOpaquePipelineCount\\": "', '         << "  \\"ordinaryOpaquePipelineCount\\": "') if False else None
p.write_text(s)
print('Radiance resources, attachments, identities and descriptors integrated',flush=True)
