from pathlib import Path
import json,hashlib,sys,traceback,struct
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261107-064529-snapshot-color-compatibility-afc6ae';a=root/'build/runs/20261107-061745-current-gpu-cost-2de6bc';state=json.loads((a/'state.json').read_text());profile=json.loads((a/'events/profile.json').read_text());cap=None;c=None
report=dict(status='starting',captureSha256=state['captureSha256'],sourceBase='35cc28f',scope='Existing current-program capture, two ordinary opaque draws; observed output correspondence does not establish exact geometry identity')
def descriptor(pipe,binding):
 reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
 for declarations,used in [(reflection.readOnlyResources,pipe.GetReadOnlyResources(rd.ShaderStage.Pixel)),(reflection.readWriteResources,pipe.GetReadWriteResources(rd.ShaderStage.Pixel))]:
  indices={i for i,r in enumerate(declarations) if r.fixedBindNumber==binding}
  match=next((r.descriptor for r in used if r.access.index in indices),None)
  if match is not None:return match
 raise ValueError('Missing binding '+str(binding))
def save():(out/'inspect-state.json').write_text(json.dumps(report,indent=2))
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 textures={str(t.resourceId):t for t in c.GetTextures()};rows=[];sources={};actions={}
 def walk(items):
  for action in items:actions[action.eventId]=action;walk(action.children)
 walk(c.GetRootActions())
 drawEvents=sorted(k for k,v in actions.items() if not v.children and v.flags&rd.ActionFlags.Drawcall)
 selected=sorted((r for r in profile['measurements'] if profile['shaders'].get(r['shader'],{}).get('programFile')=='mesh_object_bindless_clipmap_field_early.frag.spv'),key=lambda r:r['seconds'],reverse=True)
 for event in selected:
  c.SetFrameEvent(event['event'],True);pipe=c.GetPipelineState();vk=c.GetVulkanPipelineState();push=bytes(vk.pushconsts)
  if len(push)<144:continue
  alpha=struct.unpack_from('<I',push,4)[0];cls,features=struct.unpack_from('<II',push,112)
  if alpha!=0 or cls!=0 or features&~40:continue
  reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel);expected=profile['shaders'][event['shader']]['sha256'];assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==expected
  target=pipe.GetOutputTargets()[0].resource;info=textures[str(target)];assert info.width==1280 and info.height==720
  if not sources:
   for name,binding in [('snapshot',19),('reflection',37)]:
    d=descriptor(pipe,binding);tex=textures[str(d.resource)];data=bytes(c.GetTextureData(d.resource,rd.Subresource()));path=out/(name+'.bin');path.write_bytes(data)
    sources[name]=dict(resource=str(d.resource),file=path.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),width=tex.width,height=tex.height,format=str(tex.format.Name()))
  action=actions[event['event']];leaves=[]
  def drawLeaves(item):
   if not item.children and item.flags&rd.ActionFlags.Drawcall:leaves.append(item.eventId)
   for child in item.children:drawLeaves(child)
  drawLeaves(action);actual=max(leaves) if leaves else event['event']
  previous=max(k for k in drawEvents if k<event['event'])
  c.SetFrameEvent(previous,True);before=bytes(c.GetTextureData(target,rd.Subresource()));c.SetFrameEvent(actual,True);after=bytes(c.GetTextureData(target,rd.Subresource()))
  files=[]
  for name,data in [('before',before),('after',after)]:
   path=out/(str(event['event'])+'-'+name+'.bin');path.write_bytes(data);files.append(dict(file=path.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
  rows.append(dict(event=event['event'],previousDrawEvent=previous,actualDrawEvent=actual,historicalReplayMs=event['seconds']*1000,alphaMode=alpha,materialClass=cls,features=features,shader=event['shader'],shaderSha256=expected,format=str(info.format.Name()),files=files))
  if len(rows)==2:break
 assert len(rows)==2
 used=sum(p.stat().st_size for p in out.rglob('*') if p.is_file());assert used<64*1024**2,used
 report.update(status='inspected',sources=sources,rows=rows,usedBytes=used)
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 save()
sys.exit(0 if report['status']=='inspected' else 1)
