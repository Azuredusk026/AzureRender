from pathlib import Path
import json,subprocess,shutil
root=Path.cwd();out=root/'build/runs/20261107-121752-light-sample-branch-cost-a7ce0f';old=root/'build/runs/20261107-120518-uniform-texture-index-cost-ebdc25';private=out/'candidate-source';private.mkdir();text=(root/'shaders/mesh.frag').read_text();start=text.index('    float distanceToLight=sqrt(distanceSquared);');end=text.index('    attenuation*=lightInfluenceBoxWeight',start)
text=text[:start]+'''    vec3 pointDirection;
    float attenuation;
    if(light.coneType.y>1.5){pointDirection=-light.directionOuter.xyz;attenuation=1.0;}
    else {
        float distanceToLight=sqrt(distanceSquared);
        float lightRadius=max(light.positionRadius.w,.001);
        attenuation=localLightDistanceWeight(distanceSquared,lightRadius,light.coneType.z,light.coneType.w);
        pointDirection=toLight/max(distanceToLight,.001);
        if(light.coneType.y>.5) {
            float cone=clamp((dot(-pointDirection,light.directionOuter.xyz)-light.directionOuter.w)
                /max(light.coneType.x-light.directionOuter.w,.000001),0.0,1.0);
            if(light.coneType.x==light.directionOuter.w)cone=step(light.directionOuter.w,dot(-pointDirection,light.directionOuter.xyz));
            attenuation*=cone*cone;
        }
    }
'''+text[end:]
needle='        SceneLightSample sampled=sampleSceneLight(light,worldPosition,false);';assert needle in text;text=text.replace(needle,'''        if(!sceneCharacter&&!characterLightComposition&&lightInfluenceBoxWeight(worldPosition,
            light.boxRows[0],light.boxRows[1],light.boxRows[2],light.boxParameters)==0.0)continue;
'''+needle)
(private/'mesh.frag').write_text(text);shutil.copy2(old/'profile.json',out/'profile.json');manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());rows=[]
for before in json.loads((old/'candidate-build.json').read_text()):
 name=before['file'];p=next(v for v in manifest['programs'] if v['output']==name);command=[manifest['compiler'],*[f'-D{d}' for d in p['defines']],f'-I{private}',f'-I{root/"shaders"}',str(private/'mesh.frag'),'-o',str(out/name)];r=subprocess.run(command,capture_output=True,text=True);rows.append(dict(file=name,exitCode=r.returncode,command=command,stdout=r.stdout,stderr=r.stderr));(out/'candidate-build.json').write_text(json.dumps(rows,indent=2));assert r.returncode==0
for name in ['compare.py','run_compare.py']:
 s=(old/name).read_text().replace(old.name,out.name).replace('Eleven captured material modules; only nine per-draw push-constant texture index expressions change. Lighting, floating-point formulas and early-depth policies are preserved.','Eleven captured material modules; directional light distance work is bypassed and ordinary zero influence-box lights are skipped before incident-light sampling. Nonzero formulas, accumulation and early-depth policies are preserved.');(out/name).write_text(s)
print('Compiled eleven bounded light-sampling controls')
