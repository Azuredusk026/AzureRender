from pathlib import Path
import ast,json,subprocess,sys
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import digest,inputs
assert check(root/'build',run=out,planned=2*1024**2,diagnostic=True)['allowed']
for name in ['inputs.json','replay-state.json','results.json','environment.json','driver.log','replay.py']:(out/('texels-'+name)).write_bytes((out/name).read_bytes())
tree=ast.parse((out/'initial-prepare.py').read_text());templates={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['hlsl','glsl']}
expressions={
 'implicit':('baseTex.SampleBias(sourceSampler,uv,cb1[26].x)','texture(baseTex,uv)'),
 'physical-two':('baseTex.SampleLevel(sourceSampler,uv,2.0)','textureLod(baseTex,uv,3.0)'),
 'fine':('baseTex.SampleGrad(sourceSampler,uv,ddx_fine(uv)*.5,ddy_fine(uv)*.5)','textureGrad(baseTex,uv,dFdxFine(uv),dFdyFine(uv))'),
 'flipped-quad':('baseTex.SampleGrad(sourceSampler,uv,ddx_coarse(uv)*.5,ddy_coarse(uv)*.5)','textureGrad(baseTex,uv,subgroupQuadBroadcast(dFdxFine(uv),2u),subgroupQuadBroadcast(dFdyFine(uv),0u))'),
}
cases=[];names=[]
for group,(native,candidate) in expressions.items():
 for channel in ['r','g','b']:
  name=group+'-'+channel;names.append(name)
  for shift in [0,18]:
    key=name+'-'+str(shift);hp=out/(key+'.hlsl');gp=out/(key+'.frag');spv=out/(key+'.spv')
    hp.write_text(templates['hlsl'].replace('EXPR','('+native+').'+channel).replace('SHIFT',str(shift)+'u'),encoding='utf-8')
    glsl=templates['glsl'].replace('EXPR','('+candidate+').'+channel).replace('SHIFT',str(shift)+'u')
    if group=='flipped-quad':glsl=glsl.replace('#version 450','#version 450\n#extension GL_KHR_shader_subgroup_quad : require')
    gp.write_text(glsl,encoding='utf-8')
    p=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe','--target-env=vulkan1.1',str(gp),'-o',str(spv)],capture_output=True,text=True,timeout=20);assert p.returncode==0,p.stderr
    p=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.1',str(spv)],capture_output=True,text=True,timeout=20);assert p.returncode==0,p.stderr
    cases.append(dict(name=name,shift=shift,key=key,hlsl=hp.name,spirv=spv.name,sha256=digest(spv)))
locked=json.loads((out/'initial-inputs.json').read_text());locked.update(cases=cases,sourceInputs=inputs(root));(out/'inputs.json').write_text(json.dumps(locked,indent=2)+'\n',encoding='utf-8')
script=(out/'initial-replay.py').read_text().replace('points=[(1322,263),(1324,289),(1322,320),(1258,215)]','points=[(1322,263)]').replace("['u','v','dx-u','dx-v','dy-u','dy-v','lod']",repr(names))
anchor="result['captures'].append(row);save()"
metadata='''result['captures'].append(row)
    row['readOnlyResources']=[]
    textures={str(t.resourceId):t for t in controller.GetTextures()}
    for resource in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel):
        description=dict(fields=[str(n) for n in dir(resource) if not str(n).startswith('_')])
        descriptor=getattr(resource,'descriptor',None)
        if descriptor is not None:
            identity=str(descriptor.resource);texture=textures.get(identity)
            description.update(resource=identity,descriptorType=str(descriptor.type))
            access=getattr(resource,'access',None)
            if access is not None:description['index']=access.index
            if texture:description.update(format=str(texture.format.Name()),width=texture.width,height=texture.height,mips=texture.mips)
        row['readOnlyResources'].append(description)
    save()'''
assert script.count(anchor)==1;script=script.replace(anchor,metadata)
(out/'replay.py').write_text(script,encoding='utf-8');print('Prepared pre-attachment sample bits and bound-resource metadata',flush=True)
