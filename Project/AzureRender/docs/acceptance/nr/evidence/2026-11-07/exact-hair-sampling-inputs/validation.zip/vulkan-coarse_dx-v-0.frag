#version 450
layout(location=2) in vec2 unusedUv;
layout(binding=1) uniform sampler2D baseTex;
layout(location=0) out vec4 color;layout(location=1) out vec4 normal;
void main(){
precise vec2 pixel=gl_FragCoord.xy;
precise vec2 delta=pixel-vec2(1322.5,263.5);
precise vec2 xTerm=vec2(uintBitsToFloat(992999680u),uintBitsToFloat(3111149568u))*delta.x;
precise vec2 yTerm=vec2(uintBitsToFloat(3124765696u),uintBitsToFloat(3132975616u))*delta.y;
precise vec2 first=vec2(uintBitsToFloat(1062760141u),uintBitsToFloat(1062637231u))+xTerm;
precise vec2 uv=first+yTerm;
uint v=floatBitsToUint(dFdx(uv).y)>>0u;
vec4 value=vec4(float(v&63u),float((v>>6u)&63u),float((v>>12u)&63u),64)/64;
if(gl_PrimitiveID!=4087&&gl_PrimitiveID!=13254&&gl_PrimitiveID!=1620&&gl_PrimitiveID!=9704)discard;
color=value;normal=vec4(0);}
