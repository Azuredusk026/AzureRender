from pathlib import Path
import subprocess,json,sys,time
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
from gpu_environment import snapshot
assert check(root/'build',run=out,planned=4*1024**2,diagnostic=True)['allowed']
source=inputs(root);products={str(p):digest(p) for p in [root/'build/ninja-msvc-release/AzurePlayer.exe',*sorted((root/'build/ninja-msvc-release/shaders').glob('*.spv'))]}
environment=dict(scope='Functional pixel data only; battery is recorded; no performance timing',before=snapshot());(out/'environment.json').write_text(json.dumps(environment,indent=2)+'\n',encoding='utf-8')
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0;start=time.monotonic()
with (out/'driver.log').open('wb') as log:
    p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'replay.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=300)
environment['after']=snapshot();(out/'environment.json').write_text(json.dumps(environment,indent=2)+'\n',encoding='utf-8')
state=json.loads((out/'replay-state.json').read_text());assert source==inputs(root) and all(digest(Path(p))==h for p,h in products.items())
result=dict(status=state['status'],processExitCode=p.returncode,seconds=time.monotonic()-start,productionUnchanged=True,sourceInputs=source,products=products)
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ['sourceInputs','products']}),flush=True)
assert p.returncode==0 and state['status']=='exported',state.get('error')
