from pathlib import Path
import json,subprocess,sys
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import digest,inputs
assert check(root/'build',run=out,planned=2*1024**2,diagnostic=True)['allowed']
for name in ['inputs.json','replay-state.json','results.json','environment.json','driver.log','replay.py']:(out/('affine-'+name)).write_bytes((out/name).read_bytes())
cases=[('implicit','baseTex.SampleBias(sourceSampler,uv,cb1[26].x)','texture(baseTex,uv)',None)]
for level in range(5):cases.append(('level-'+str(level),f'baseTex.SampleLevel(sourceSampler,uv,{level}.0)',f'textureLod(baseTex,uv,{level}.0)',None))
cases += [
 ('fine','baseTex.SampleGrad(sourceSampler,uv,ddx_fine(uv)*.5,ddy_fine(uv)*.5)','textureGrad(baseTex,uv,dFdxFine(uv),dFdyFine(uv))',None),
 ('coarse','baseTex.SampleGrad(sourceSampler,uv,ddx_coarse(uv)*.5,ddy_coarse(uv)*.5)','textureGrad(baseTex,uv,dFdxCoarse(uv),dFdyCoarse(uv))',None),
 ('flipped-quad','baseTex.SampleGrad(sourceSampler,uv,ddx_coarse(uv)*.5,ddy_coarse(uv)*.5)','textureGrad(baseTex,uv,subgroupQuadBroadcast(dFdxFine(uv),2u),subgroupQuadBroadcast(dFdyFine(uv),0u))',None),
 ('affine-native','baseTex.SampleBias(sourceSampler,uv,cb1[26].x)','texture(baseTex,uv)','native-coarse'),
 ('affine-vulkan','baseTex.SampleBias(sourceSampler,uv,cb1[26].x)','texture(baseTex,uv)','vulkan-coarse'),
]
rows=[]
for name,native,candidate,group in cases:
    hlsl='''Texture2D<float4> baseTex:register(t16);SamplerState sourceSampler:register(s2);
cbuffer Globals:register(b1){float4 cb1[141];};
float4 main(float4 position:SV_Position,float2 uv:TEXCOORD0,uint primitive:SV_PrimitiveID):SV_Target0{
PREAMBLE
float4 value=EXPR;if(primitive!=4087&&primitive!=13254&&primitive!=1620&&primitive!=9704)discard;return value;}
'''
    glsl='''#version 450
EXTENSION
layout(location=2) in vec2 uv;layout(binding=1) uniform sampler2D baseTex;
layout(location=0) out vec4 color;layout(location=1) out vec4 normal;
void main(){PREAMBLE
vec4 value=EXPR;if(gl_PrimitiveID!=4087&&gl_PrimitiveID!=13254&&gl_PrimitiveID!=1620&&gl_PrimitiveID!=9704)discard;
color=value;normal=vec4(0);}
'''
    prefixes={}
    for language in ['hlsl','glsl']:
        extension='hlsl' if language=='hlsl' else 'frag'
        if group:
            text=(out/(group+'_u-0.'+extension)).read_text()
            prefix=text[text.index('precise '):text.index('uint v=')]
        else:prefix=''
        prefixes[language]=prefix
    hlsl=hlsl.replace('PREAMBLE',prefixes['hlsl']).replace('EXPR',native)
    glsl=glsl.replace('PREAMBLE',prefixes['glsl']).replace('EXPR',candidate).replace('EXTENSION','#extension GL_KHR_shader_subgroup_quad : require' if name=='flipped-quad' else '')
    if group:hlsl=hlsl.replace('float2 uv:TEXCOORD0','float2 unusedUv:TEXCOORD0');glsl=glsl.replace('in vec2 uv;','in vec2 unusedUv;')
    hp=out/('sample-'+name+'.hlsl');gp=out/('sample-'+name+'.frag');spv=out/('sample-'+name+'.spv');hp.write_text(hlsl,encoding='utf-8');gp.write_text(glsl,encoding='utf-8')
    p=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe','--target-env=vulkan1.1',str(gp),'-o',str(spv)],capture_output=True,text=True,timeout=20);assert p.returncode==0,p.stderr
    p=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.1',str(spv)],capture_output=True,text=True,timeout=20);assert p.returncode==0,p.stderr
    rows.append(dict(name=name,key=name,shift=0,hlsl=hp.name,spirv=spv.name,sha256=digest(spv)))
locked=json.loads((out/'initial-inputs.json').read_text());locked.update(cases=rows,sourceInputs=inputs(root));(out/'inputs.json').write_text(json.dumps(locked,indent=2)+'\n',encoding='utf-8')
script=(out/'initial-replay.py').read_text()
script=script.replace("digits=[int(round(v*64)) for v in value[:3]];assert all(0<=d<=63 for d in digits)","digits=[]")
script=script.replace("values.append(dict(pixel=[x,y],raw=value,word=digits[0]|digits[1]<<6|digits[2]<<12))","values.append(dict(pixel=[x,y],raw=value))")
start=script.index("    row['decoded']=[]");end=script.index('    controller.Shutdown();',start);script=script[:start]+script[end:]
(out/'replay.py').write_text(script,encoding='utf-8');print('Prepared eleven actual-sampling controls',flush=True)
