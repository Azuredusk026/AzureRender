Texture2D<float4> baseTex:register(t16);SamplerState sourceSampler:register(s2);
cbuffer Globals:register(b1){float4 cb1[141];};
float4 main(float4 position:SV_Position,float2 uv:TEXCOORD0,uint primitive:SV_PrimitiveID):SV_Target0{

float4 value=baseTex.SampleGrad(sourceSampler,uv,ddx_coarse(uv)*.5,ddy_coarse(uv)*.5);if(primitive!=4087&&primitive!=13254&&primitive!=1620&&primitive!=9704)discard;return value;}
