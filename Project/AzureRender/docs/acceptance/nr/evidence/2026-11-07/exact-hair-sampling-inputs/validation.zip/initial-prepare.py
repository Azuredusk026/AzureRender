from pathlib import Path
import json, subprocess, sys
root=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import digest,inputs
assert check(root/'build',run=out,planned=4*1024**2,diagnostic=True)['allowed']
expressions={
 'u':('uv.x','uv.x'), 'v':('uv.y','uv.y'),
 'dx-u':('ddx(uv).x','dFdx(uv).x'), 'dx-v':('ddx(uv).y','dFdx(uv).y'),
 'dy-u':('ddy(uv).x','dFdy(uv).x'), 'dy-v':('ddy(uv).y','dFdy(uv).y'),
 'lod':('baseTex.CalculateLevelOfDetailUnclamped(sourceSampler,uv)+cb1[26].x','textureQueryLod(baseTex,uv).y'),
}
hlsl='''Texture2D<float4> baseTex:register(t16);SamplerState sourceSampler:register(s2);
cbuffer Globals:register(b1){float4 cb1[141];};
float4 main(float4 position:SV_Position,float2 uv:TEXCOORD0,uint primitive:SV_PrimitiveID):SV_Target0{
 uint v=asuint(EXPR)>>SHIFT;
 float4 value=float4(v&63u,(v>>6u)&63u,(v>>12u)&63u,64)/64;
 if(primitive!=4087&&primitive!=13254&&primitive!=1620&&primitive!=9704)discard;return value;
}'''
glsl='''#version 450
layout(location=2) in vec2 uv;
layout(binding=1) uniform sampler2D baseTex;
layout(location=0) out vec4 color;layout(location=1) out vec4 normal;
void main(){uint v=floatBitsToUint(EXPR)>>SHIFT;
vec4 value=vec4(float(v&63u),float((v>>6u)&63u),float((v>>12u)&63u),64)/64;
if(gl_PrimitiveID!=4087&&gl_PrimitiveID!=13254&&gl_PrimitiveID!=1620&&gl_PrimitiveID!=9704)discard;
color=value;normal=vec4(0);}
'''
cases=[]
for name,(native,candidate) in expressions.items():
 for shift in [0,18]:
    key=name+'-'+str(shift);hp=out/(key+'.hlsl');gp=out/(key+'.frag');spv=out/(key+'.spv')
    hp.write_text(hlsl.replace('EXPR',native).replace('SHIFT',str(shift)+'u'),encoding='utf-8')
    gp.write_text(glsl.replace('EXPR',candidate).replace('SHIFT',str(shift)+'u'),encoding='utf-8')
    p=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe',str(gp),'-o',str(spv)],capture_output=True,text=True,timeout=20);assert p.returncode==0,p.stderr
    p=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(spv)],capture_output=True,text=True,timeout=20);assert p.returncode==0,p.stderr
    cases.append(dict(name=name,shift=shift,key=key,hlsl=hp.name,spirv=spv.name,sha256=digest(spv)))
captures=[dict(label='native',path=str(root/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc'),event=950),dict(label='candidate',path=str(root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc'),event=493)]
for capture in captures:capture['sha256']=digest(Path(capture['path']))
(out/'inputs.json').write_text(json.dumps(dict(cases=cases,captures=captures,sourceInputs=inputs(root)),indent=2)+'\n',encoding='utf-8')
print('Prepared fourteen full-bit probes; original captures retained',flush=True)
