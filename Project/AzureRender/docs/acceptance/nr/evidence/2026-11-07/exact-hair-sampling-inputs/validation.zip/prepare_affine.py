from pathlib import Path
import ast,json,subprocess,sys
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import digest,inputs
assert check(root/'build',run=out,planned=2*1024**2,diagnostic=True)['allowed']
tree=ast.parse((out/'initial-prepare.py').read_text())
templates={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ['hlsl','glsl','expressions']}
derivatives=json.loads((out/'derivatives-replay-state.json').read_text())
initial=json.loads((out/'initial-replay-state.json').read_text())
uv=initial['captures'][0]['decoded'][0]['values']
cases=[];names=[];controls=[]
for group,row in zip(['native-coarse','vulkan-coarse'],derivatives['captures']):
    values=row['decoded'][0]['values']
    dx=[values['dxc-'+c]['bits'] for c in ['u','v']]
    dy=[values['dyc-'+c]['bits']^(0x80000000 if row['label']=='native' else 0) for c in ['u','v']]
    controls.append(dict(name=group,origin=[uv[c]['bits'] for c in ['u','v']],displayDxBits=dx,displayDyBits=dy))
    for name,(native,candidate) in templates['expressions'].items():
     logical=group+'_'+name;names.append(logical)
     for shift in [0,18]:
        key=logical+'-'+str(shift);codes={}
        for language,expression,vector,convert in [('hlsl',native,'float2','asfloat'),('glsl',candidate,'vec2','uintBitsToFloat')]:
            constant=lambda b:convert+'('+str(b)+'u)'
            position='float2(position.x,1440.0-position.y)' if language=='hlsl' else 'gl_FragCoord.xy'
            preamble='precise '+vector+' pixel='+position+';\n'
            preamble+='precise '+vector+' delta=pixel-'+vector+'(1322.5,263.5);\n'
            preamble+='precise '+vector+' xTerm='+vector+'('+','.join(map(constant,dx))+')*delta.x;\n'
            preamble+='precise '+vector+' yTerm='+vector+'('+','.join(map(constant,dy))+')*delta.y;\n'
            preamble+='precise '+vector+' first='+vector+'('+','.join(constant(uv[c]['bits']) for c in ['u','v'])+')+xTerm;\n'
            preamble+='precise '+vector+' uv=first+yTerm;\n'
            code=templates[language].replace('EXPR',expression).replace('SHIFT',str(shift)+'u')
            if language=='hlsl':code=code.replace('float2 uv:TEXCOORD0','float2 unusedUv:TEXCOORD0').replace('SV_Target0{','SV_Target0{\n'+preamble)
            else:code=code.replace('in vec2 uv;','in vec2 unusedUv;').replace('void main(){','void main(){\n'+preamble)
            codes[language]=code
        hp=out/(key+'.hlsl');gp=out/(key+'.frag');spv=out/(key+'.spv')
        hp.write_text(codes['hlsl'],encoding='utf-8');gp.write_text(codes['glsl'],encoding='utf-8')
        p=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe',str(gp),'-o',str(spv)],capture_output=True,text=True,timeout=20);assert p.returncode==0,p.stderr
        p=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(spv)],capture_output=True,text=True,timeout=20);assert p.returncode==0,p.stderr
        cases.append(dict(name=logical,shift=shift,key=key,hlsl=hp.name,spirv=spv.name,sha256=digest(spv)))
locked=json.loads((out/'initial-inputs.json').read_text());locked.update(cases=cases,affineControls=controls,sourceInputs=inputs(root));(out/'inputs.json').write_text(json.dumps(locked,indent=2)+'\n',encoding='utf-8')
script=(out/'initial-replay.py').read_text().replace('points=[(1322,263),(1324,289),(1322,320),(1258,215)]','points=[(1322,263)]').replace("['u','v','dx-u','dx-v','dy-u','dy-v','lod']",repr(names));(out/'replay.py').write_text(script,encoding='utf-8')
print('Prepared two shared affine-coordinate controls with exact float bit inputs',flush=True)
