from pathlib import Path
import renderdoc as rd
import json,struct,traceback,sys
out=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261107-184515-exact-hair-sampling-inputs-97a383')
inputs=json.loads((out/'inputs.json').read_text());points=[(1322,263),(1324,289),(1322,320),(1258,215)]
result=dict(status='started',purpose='Functional input probe only; no timing counters',captures=[])
def save():(out/'replay-state.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
cap=None;controller=None;original=None;built=[]
try:
 for item in inputs['captures']:
    cap=rd.OpenCaptureFile();assert cap.OpenFile(item['path'],'',None)==rd.ResultCode.Succeeded
    status,controller=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
    controller.SetFrameEvent(item['event'],True);pipe=controller.GetPipelineState();original=pipe.GetShader(rd.ShaderStage.Pixel);target=pipe.GetOutputTargets()[0].resource
    row=dict(label=item['label'],capture=item['path'],event=item['event'],modes=[]);result['captures'].append(row);save()
    for case in inputs['cases']:
        native=item['label']=='native';code=(out/case['hlsl']).read_bytes() if native else (out/case['spirv']).read_bytes()
        replacement,errors=controller.BuildTargetShader('main',rd.ShaderEncoding.HLSL if native else rd.ShaderEncoding.SPIRV,code,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
        assert replacement!=rd.ResourceId.Null(),errors;built.append(replacement)
        controller.ReplaceResource(original,replacement);controller.SetFrameEvent(item['event'],True)
        values=[]
        for x,y in points:
            value=list(controller.PickPixel(target,x,1439-y if native else y,rd.Subresource(),rd.CompType.Typeless).floatValue)
            digits=[int(round(v*64)) for v in value[:3]];assert all(0<=d<=63 for d in digits)
            values.append(dict(pixel=[x,y],raw=value,word=digits[0]|digits[1]<<6|digits[2]<<12))
        row['modes'].append(dict(name=case['name'],shift=case['shift'],values=values));save()
        controller.RemoveReplacement(original);controller.FreeTargetResource(replacement);built.remove(replacement)
    row['decoded']=[]
    for index,pixel in enumerate(points):
        decoded={}
        for name in ['u','v','dx-u','dx-v','dy-u','dy-v','lod']:
            halves={v['shift']:v['values'][index]['word'] for v in row['modes'] if v['name']==name}
            bits=halves[0]|(halves[18]<<18);assert bits<=0xffffffff
            decoded[name]=dict(bits=bits,float=struct.unpack('<f',struct.pack('<I',bits))[0])
        row['decoded'].append(dict(pixel=pixel,values=decoded))
    controller.Shutdown();controller=None;cap.Shutdown();cap=None;original=None;save()
 result['status']='exported';save()
except Exception:result.update(status='failed',error=traceback.format_exc());save()
finally:
 if controller:
    if original:controller.RemoveReplacement(original)
    for shader in built:controller.FreeTargetResource(shader)
    controller.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if result['status']=='exported' else 1)
