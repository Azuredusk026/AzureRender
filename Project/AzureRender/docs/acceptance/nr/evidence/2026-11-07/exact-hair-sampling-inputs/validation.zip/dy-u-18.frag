#version 450
layout(location=2) in vec2 uv;
layout(binding=1) uniform sampler2D baseTex;
layout(location=0) out vec4 color;layout(location=1) out vec4 normal;
void main(){uint v=floatBitsToUint(dFdy(uv).x)>>18u;
vec4 value=vec4(float(v&63u),float((v>>6u)&63u),float((v>>12u)&63u),64)/64;
if(gl_PrimitiveID!=4087&&gl_PrimitiveID!=13254&&gl_PrimitiveID!=1620&&gl_PrimitiveID!=9704)discard;
color=value;normal=vec4(0);}
