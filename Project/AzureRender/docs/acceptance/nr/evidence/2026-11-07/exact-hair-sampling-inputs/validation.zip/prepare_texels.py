from pathlib import Path
import ast,json,subprocess,sys
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import digest,inputs
assert check(root/'build',run=out,planned=2*1024**2,diagnostic=True)['allowed']
for name in ['inputs.json','replay-state.json','results.json','environment.json','driver.log','replay.py']:(out/('samples-'+name)).write_bytes((out/name).read_bytes())
tree=ast.parse((out/'initial-prepare.py').read_text());templates={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['hlsl','glsl']}
cases=[];names=[]
for x,y in [(432,428),(433,428),(432,429),(433,429)]:
 for channel in ['r','g','b']:
  name=f'texel-{x}-{y}-{channel}';names.append(name)
  for shift in [0,18]:
    key=name+'-'+str(shift);hp=out/(key+'.hlsl');gp=out/(key+'.frag');spv=out/(key+'.spv')
    hp.write_text(templates['hlsl'].replace('EXPR',f'baseTex.Load(int3({x},{y},2)).{channel}').replace('SHIFT',str(shift)+'u'),encoding='utf-8')
    gp.write_text(templates['glsl'].replace('EXPR',f'texelFetch(baseTex,ivec2({x},{y}),2).{channel}').replace('SHIFT',str(shift)+'u'),encoding='utf-8')
    p=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe',str(gp),'-o',str(spv)],capture_output=True,text=True,timeout=20);assert p.returncode==0,p.stderr
    p=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(spv)],capture_output=True,text=True,timeout=20);assert p.returncode==0,p.stderr
    cases.append(dict(name=name,shift=shift,key=key,hlsl=hp.name,spirv=spv.name,sha256=digest(spv)))
locked=json.loads((out/'initial-inputs.json').read_text());locked.update(cases=cases,sourceInputs=inputs(root));(out/'inputs.json').write_text(json.dumps(locked,indent=2)+'\n',encoding='utf-8')
script=(out/'initial-replay.py').read_text().replace('points=[(1322,263),(1324,289),(1322,320),(1258,215)]','points=[(1322,263)]').replace("['u','v','dx-u','dx-v','dy-u','dy-v','lod']",repr(names))
anchor="result['captures'].append(row);save()"
metadata='''result['captures'].append(row)
    row['resourceMethods']=[str(n) for n in dir(pipe) if 'Resource' in str(n) or 'Descriptor' in str(n) or 'Sampler' in str(n)]
    textures={str(t.resourceId):t for t in controller.GetTextures()}
    texture=textures[str(target)];row['outputTexture']=dict(format=str(texture.format.Name()),width=texture.width,height=texture.height)
    if item['label']=='native':
        stage=controller.GetD3D11PipelineState().pixelShader
        row['pixelStageFields']=[str(n) for n in dir(stage) if not str(n).startswith('_')]
    save()'''
assert script.count(anchor)==1;script=script.replace(anchor,metadata)
(out/'replay.py').write_text(script,encoding='utf-8');print('Prepared full-bit source texel controls for the disputed bilinear footprint',flush=True)
