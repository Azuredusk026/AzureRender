#version 450
#extension GL_KHR_shader_subgroup_quad : require
layout(location=2) in vec2 uv;layout(binding=1) uniform sampler2D baseTex;
layout(location=0) out vec4 color;layout(location=1) out vec4 normal;
void main(){
vec4 value=textureGrad(baseTex,uv,subgroupQuadBroadcast(dFdxFine(uv),2u),subgroupQuadBroadcast(dFdyFine(uv),0u));if(gl_PrimitiveID!=4087&&gl_PrimitiveID!=13254&&gl_PrimitiveID!=1620&&gl_PrimitiveID!=9704)discard;
color=value;normal=vec4(0);}
