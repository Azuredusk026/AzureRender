Texture2D<float4> baseTex:register(t16);SamplerState sourceSampler:register(s2);
cbuffer Globals:register(b1){float4 cb1[141];};
float4 main(float4 position:SV_Position,float2 unusedUv:TEXCOORD0,uint primitive:SV_PrimitiveID):SV_Target0{
precise float2 pixel=float2(position.x,1440.0-position.y);
precise float2 delta=pixel-float2(1322.5,263.5);
precise float2 xTerm=float2(asfloat(992999680u),asfloat(3111149568u))*delta.x;
precise float2 yTerm=float2(asfloat(3124765696u),asfloat(3132975616u))*delta.y;
precise float2 first=float2(asfloat(1062760141u),asfloat(1062637231u))+xTerm;
precise float2 uv=first+yTerm;

 uint v=asuint(ddx(uv).x)>>18u;
 float4 value=float4(v&63u,(v>>6u)&63u,(v>>12u)&63u,64)/64;
 if(primitive!=4087&&primitive!=13254&&primitive!=1620&&primitive!=9704)discard;return value;
}