from pathlib import Path
import sys,json,time
import numpy as np
from PIL import Image
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));import test_scene_visibility_gpu as test
base=a/'instance-lookup-debug-visibility';tail=a/'instance-lookup-debug-visibility-tail';tail.mkdir();out=a/'instance-lookup-debug-visibility-functional';exe=root/'build/ninja-msvc-debug/AzurePlayer.exe';start=time.monotonic()
test.capture(exe,tail,'beauty',isolation='beauty',disable_outline=False)
used=[]
def actual_capture(executable,unused_root,name,*,flags=(),isolation='albedo',disable_outline=True,**fixture):
 folder=tail if name=='beauty' else base;log=(folder/(name+'.log')).read_text(encoding='utf-8');assert 'VUID-' not in log and 'Validation Error' not in log;assert 'Allocator after unload: buffers=0 images=0' in log
 manifest=json.loads((folder/(name+'-capture')/'capture_manifest.json').read_text());assert manifest.get('qaDisableFaceCulling')==('--qa-disable-face-culling' in flags);assert manifest.get('qaDisableDepthTest')==('--qa-disable-depth-test' in flags);assert manifest.get('cameraFar')==fixture.get('camera_far',500);used.append(dict(name=name,folder=str(folder),scope='Actual completed production capture, original footer and metadata checks retained'))
 return np.asarray(Image.open(folder/(name+'-capture')/'frame_000000.png').convert('RGB'),dtype=np.int16)
test.capture=actual_capture;result=test.run(exe,out);result.update(scope='Original image assertions evaluated on 26 completed captures plus one remaining beauty capture; full-suite 300-second timing gate remains failed',formalSuiteStatus='failed-timeout',completeOriginalImageAssertions=True,actualCaptures=used,tailSeconds=time.monotonic()-start);(out/'functional-results.json').write_text(json.dumps(result,indent=2));print('Functional assertions checked from actual captures:',len(used),'original full-suite timing: failed')
