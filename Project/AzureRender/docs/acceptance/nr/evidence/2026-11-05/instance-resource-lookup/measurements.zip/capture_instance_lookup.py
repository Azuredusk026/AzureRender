from pathlib import Path
import subprocess,json,time,hashlib
from PIL import Image
import numpy as np
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;r=root/'build/runs/20261103-234012-character-reference-stages-5abe6c';out=a/'instance-lookup-joint';out.mkdir();cmd=json.loads((r/'snapshot-shell-order-regression/release-joint/command.json').read_text());cmd[cmd.index('--capture-dir')+1]=str(out/'frames');cmd[cmd.index('--runtime-report')+1]=str(out/'runtime.json');(out/'command.json').write_text(json.dumps(cmd,indent=2));start=time.monotonic();si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
before=hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:p=subprocess.run(cmd,cwd=out,startupinfo=si,stdout=stdout,stderr=stderr,timeout=900)
assert p.returncode==0,p.returncode
rows=[]
for f in sorted((out/'frames').glob('frame_*.png')):
 current=np.array(Image.open(f).convert('RGB'));row=dict(frame=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
 for label,folder in [('frozen',r/'snapshot-shell-order-regression/release-joint/frames'),('liveBaseline',a/'restored-joint/frames')]:
  old=np.array(Image.open(folder/f.name).convert('RGB'));d=np.abs(current.astype(np.int16)-old.astype(np.int16));row[label]=dict(identical=bool(np.array_equal(current,old)),changedPixels=int(np.any(d,axis=2).sum()),maxByteDifference=int(d.max()))
 rows.append(row)
shaderBefore=json.loads((a/'baseline-products/manifest.json').read_text())['shaders'];shaders={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv')};assert shaders==shaderBefore and len(shaders)==535
log=(out/'stdout.log').read_text(errors='replace')+(out/'stderr.log').read_text(errors='replace');assert 'Allocator after unload: buffers=0 images=0' in log
assert hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()==before
result=dict(status='passed' if len(rows)==4 and all(x['frozen']['identical'] for x in rows) else 'failed-strict-byte-comparison',visualAcceptance='failed-user-review',executableSha256=before,seconds=time.monotonic()-start,zeroAllocator=True,productionShaderBytesUnchanged=True,validationClean=not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-']),frames=rows);(out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
