from pathlib import Path
import subprocess,json,time,os,re,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;out=a/'render-camera-snapshot';ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9');env['PATH']=';'.join(['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin','D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja',env['PATH']])
(out/'full-cpu-task.json').write_text(json.dumps(dict(scope='Complete non-GPU regression for changed public runtime camera API and shared host frame inputs',sourceBase='5c61efb',gpuStatus='Deferred by user while PBZ.exe occupies device',commandBudgetSecondsPerConfiguration=1200,environment='MSVC environment wrapper and explicit CMake/CTest/Ninja PATH; original earlier two path failures retained in prior baseline evidence'),indent=2))
for tag in ['release','debug']:
 build=root/('build/ninja-msvc-'+tag);assert json.loads((out/(tag+'-targeted.json')).read_text())['exitCode']==0
 listing=json.loads(subprocess.check_output([ctest,'--test-dir',str(build),'--show-only=json-v1'],env=env,text=True));expected=sum(not any(p['name']=='LABELS' and any(re.search('gpu',label) for label in p['value']) for p in t['properties']) for t in listing['tests']);assert expected==292,expected
 cmd=[ctest,'--test-dir',str(build),'-LE','gpu','--output-on-failure','--no-tests=error','--output-junit',str(out/(tag+'-full-cpu.xml')),'-j','2'];start=time.monotonic()
 with (out/(tag+'-full-cpu.log')).open('wb') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 (out/(tag+'-full-cpu.json')).write_text(json.dumps(dict(exitCode=r.returncode,expectedChecks=expected,seconds=time.monotonic()-start,command=cmd),indent=2));print(tag,'fullCPU exit',r.returncode,flush=True)
 t=ET.parse(out/(tag+'-full-cpu.xml'));assert len(t.findall('.//testcase'))==expected and not t.findall('.//failure') and not t.findall('.//error') and r.returncode==0
