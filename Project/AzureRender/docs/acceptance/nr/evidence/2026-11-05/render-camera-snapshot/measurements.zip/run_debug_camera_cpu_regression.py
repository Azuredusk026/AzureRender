from pathlib import Path
import subprocess,json,time,os,xml.etree.ElementTree as ET,sys
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;out=a/'render-camera-snapshot';sys.path.insert(0,str(root/'tools'));from build_provenance import inputs
frozen=inputs(root);env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9');env['PATH']=';'.join(['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin','D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja',env['PATH']]);ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
cmd=[ctest,'--test-dir',str(root/'build/ninja-msvc-debug'),'-LE','gpu','--output-on-failure','--no-tests=error','--output-junit',str(out/'debug-full-cpu.xml'),'-j','1'];start=time.monotonic();timedOut=False
(out/'full-cpu-debug-task.json').write_text(json.dumps(dict(scope='Complete Debug non-GPU regression with serial scheduling; original per-test deadlines unchanged',sourceBase='5c61efb',expectedChecks=292,commandBudgetSeconds=1200,trigger='Release original full batch289/292; same3 failed cases passed independently under original deadlines. Serial scheduling is a diagnostic scope, not a source fix claim.',gpuStatus='Deferred by user'),indent=2))
with (out/'debug-full-cpu.log').open('wb') as log:
 child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:code=child.wait(timeout=1200)
 except subprocess.TimeoutExpired:
  timedOut=True;subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True);child.wait();code=child.returncode
result=dict(exitCode=code,timedOut=timedOut,seconds=time.monotonic()-start,expectedChecks=292,command=cmd,sourceInputsUnchanged=inputs(root)==frozen);(out/'debug-full-cpu.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
assert code==0 and not timedOut and result['sourceInputsUnchanged'];t=ET.parse(out/'debug-full-cpu.xml');assert len(t.findall('.//testcase'))==292 and not t.findall('.//failure') and not t.findall('.//error')
