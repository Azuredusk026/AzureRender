from pathlib import Path
import json,sys,traceback,collections
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'pixel-cost-diagnosis';out.mkdir(exist_ok=True);capture=rd.OpenCaptureFile();controller=None;report=dict(status='starting')
try:
 assert capture.OpenFile(str(a/'native-joint-rdc-profile/joint_frame320.rdc'),'',None)==rd.ResultCode.Succeeded
 status,controller=capture.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 structured=controller.GetStructuredFile();actions={};parents={}
 def walk(items,parent=None):
  for x in items:
   actions[x.eventId]=x;parents[x.eventId]=parent;walk(x.children,x.eventId)
 walk(controller.GetRootActions())
 counters=json.loads((a/'command-state-diagnosis-v2/pixel-counters.json').read_text());rows={}
 for x in counters:
  action=actions[x['eventId']]
  row=rows.setdefault(x['eventId'],dict(event=x['eventId'],name=action.GetName(structured),parent=parents[x['eventId']],hasChildren=bool(action.children),flags=str(action.flags),shader='uninspected'))
  row['ps' if x['counter']==12 else 'samplesPassed']=x['value']
 chosen=sorted((v for v in rows.values() if not v['hasChildren']),key=lambda x:x.get('ps',0),reverse=True)[:96]
 shaders={}
 for row in chosen:
  controller.SetFrameEvent(row['event'],True);pipe=controller.GetPipelineState();sid=str(pipe.GetShader(rd.ShaderStage.Pixel));row['shader']=sid
  if sid not in shaders:
   r=pipe.GetShaderReflection(rd.ShaderStage.Pixel);shaders[sid]=dict(files=[f.filename for f in r.debugInfo.files] if r else [])
  row['colorTargets']=[str(t.resource) for t in pipe.GetOutputTargets()];row['depthTarget']=str(pipe.GetDepthTarget().resource)
 begin=[];counts=collections.defaultdict(collections.Counter)
 for c in structured.chunks:
  n=str(c.name)
  if n=='vkBeginCommandBuffer':begin.append(dict(name=n,fields=[dict(name=str(c.GetChild(i).name),value=int(c.GetChild(i).data.basic.u)) for i in range(c.NumChildren())]))
  if n.startswith('vkCmd'):
   cb=c.FindChild('commandBuffer')
   if cb is not None:counts[str(int(cb.data.basic.u))][n]+=1
 report.update(status='inspected',scope='Generic PS invocations and sample counts; leaf actions for totals; top96 fragment events have shader identities',leafPS=sum(v.get('ps',0) for v in rows.values() if not v['hasChildren']),leafSamplesPassed=sum(v.get('samplesPassed',0) for v in rows.values() if not v['hasChildren']),events=list(rows.values()),shaders=shaders,begins=begin,byCommandBuffer={k:dict(v) for k,v in counts.items()})
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if controller:controller.Shutdown()
 capture.Shutdown();(out/'results.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='inspected' else 1)
