from pathlib import Path
import sys,json,traceback,collections
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'command-state-diagnosis-v2';out.mkdir(exist_ok=True);capture=rd.OpenCaptureFile();controller=None;report=dict(status='starting',scope='Recorded API state counts and supported counters; no performance duration claim')
try:
 assert capture.OpenFile(str(a/'native-joint-rdc-profile/joint_frame320.rdc'),'',None)==rd.ResultCode.Succeeded
 status,controller=capture.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 structured=controller.GetStructuredFile();counts=collections.Counter(str(c.name) for c in structured.chunks);selected=[c for c in structured.chunks if str(c.name).endswith('vkCmdBindPipeline')];samples=[]
 for c in selected[:2]:samples.append(dict(name=str(c.name),children=[dict(name=str(c.GetChild(i).name),type=str(c.GetChild(i).type.basetype),value=int(c.GetChild(i).data.basic.u)) for i in range(c.NumChildren())]))
 state={};redundant=0;byBuffer=collections.Counter();pipelineCalls=0;parseFailures=[]
 for c in structured.chunks:
  name=str(c.name)
  if not any(name.endswith(s) for s in ['vkCmdBindPipeline','vkBeginCommandBuffer','vkCmdExecuteCommands']):continue
  cb=c.FindChild('commandBuffer')
  if cb is None:
   for field in ['CommandBuffer','commandbuffer']:
    cb=c.FindChild(field)
    if cb is not None:break
  if cb is None:parseFailures.append(dict(name=name,fields=[str(c.GetChild(i).name) for i in range(c.NumChildren())]));continue
  cb=int(cb.data.basic.u)
  if name.endswith('vkBeginCommandBuffer') or name.endswith('vkCmdExecuteCommands'):
   state.pop((cb,0),None);state.pop((cb,1),None);continue
  point=c.FindChild('pipelineBindPoint');pipeline=c.FindChild('pipeline')
  if point is None or pipeline is None:parseFailures.append(name);continue
  key=(cb,int(point.data.basic.u));value=int(pipeline.data.basic.u);pipelineCalls+=1
  if state.get(key)==value:redundant+=1;byBuffer[str(cb)]+=1
  state[key]=value
 pixels=[]
 for value in controller.FetchCounters([rd.GPUCounter.PSInvocations,rd.GPUCounter.SamplesPassed]):
  pixels.append(dict(eventId=int(value.eventId),counter=int(value.counter),value=int(value.value.u64)))
 (out/'pixel-counters.json').write_text(json.dumps(pixels,indent=2))
 counters=[]
 for counter in controller.EnumerateCounters():
  d=controller.DescribeCounter(counter);counters.append(dict(id=int(counter),name=str(d.name),description=str(d.description),type=str(d.resultType),unit=str(d.unit)))
 report.update(status='inspected',chunks=len(structured.chunks),apiCounts={k:v for k,v in counts.items() if any(x in k for x in ['BindPipeline','BindDescriptorSets','DrawIndexed','ExecuteCommands'])},pipelineCalls=pipelineCalls,repeatedSamePipeline=redundant,repeatByBuffer=dict(byBuffer),parseFailures=parseFailures,samples=samples,counters=counters)
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if controller:controller.Shutdown()
 capture.Shutdown();(out/'results.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='inspected' else 1)
