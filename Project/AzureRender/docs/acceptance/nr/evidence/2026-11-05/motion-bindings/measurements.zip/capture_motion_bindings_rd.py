from pathlib import Path
import sys,time,json,traceback,subprocess,hashlib,ctypes
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'motion-bindings-rdc';out.mkdir(exist_ok=True);report=dict(status='starting',scope='Actual API binding count; independent of runtime P95');control=None;pid=None
try:
 player=root/'build/ninja-msvc-release/AzurePlayer.exe';args=['--project',str(root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--smoke-frames','325','--gpu-timing','--gpu-timing-output',str(out/'runtime-timing.json')];report['command']=[str(player)]+args;report['executableSha256']=hashlib.sha256(player.read_bytes()).hexdigest();report['captureFrame']=320
 modifications=[]
 for name,value in [('VK_LAYER_PATH','D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64;D:/Tools/VulkanSDK/1.4.350.0/Bin'),('VK_INSTANCE_LAYERS','VK_LAYER_RENDERDOC_Capture'),('ENABLE_VULKAN_RENDERDOC_CAPTURE','1')]:
  item=rd.EnvironmentModification();item.name=name;item.value=value;item.mod=rd.EnvMod.Set;item.sep=rd.EnvSep.Platform;modifications.append(item)
 options=rd.CaptureOptions();options.apiValidation=False;options.allowFullscreen=False
 launch=rd.ExecuteAndInject(str(player),str(out),subprocess.list2cmdline(args),modifications,str(out/'joint'),options,False);assert launch.result==rd.ResultCode.Succeeded,str(launch.result)
 control=rd.CreateTargetControl('',launch.ident,'AzureRender joint GPU stage diagnosis',False);assert control
 if hasattr(control,'GetPID'):pid=control.GetPID()
 if pid:
  callback=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
  @callback
  def hide(hwnd,param):
   owner=ctypes.c_ulong();ctypes.windll.user32.GetWindowThreadProcessId(hwnd,ctypes.byref(owner))
   if owner.value==pid:ctypes.windll.user32.ShowWindow(hwnd,0)
   return True
  ctypes.windll.user32.EnumWindows(hide,0)
 control.QueueCapture(320,1);report.update(status='capturing',pid=pid);(out/'state.json').write_text(json.dumps(report,indent=2));deadline=time.monotonic()+900
 while time.monotonic()<deadline and control.Connected():
  control.ReceiveMessage(None);time.sleep(.02)
 files=list(out.glob('*.rdc'));assert len(files)==1,'Expected one completed frame capture: '+str(files)
 control.Shutdown();control=None;report.update(status='waiting-for-idle-profiler',capture=str(files[0]),bytes=files[0].stat().st_size);(out/'state.json').write_text(json.dumps(report,indent=2))
 deadline=time.monotonic()+900
 while not (a/'instance-lookup-build/debug-targeted.json').exists():
  assert time.monotonic()<deadline,'Debug CPU checks did not finish before profiling deadline';time.sleep(2)
 assert json.loads((a/'instance-lookup-build/debug-targeted.json').read_text())['exitCode']==0
 capture=rd.OpenCaptureFile();controller=None
 try:
  assert capture.OpenFile(str(files[0]),'',None)==rd.ResultCode.Succeeded
  status,controller=capture.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
  structured=controller.GetStructuredFile();from collections import Counter
  counts=Counter(str(c.name) for c in structured.chunks);state={};repeated=0;parseFailures=[]
  for c in structured.chunks:
   name=str(c.name)
   if name not in ['vkCmdBindPipeline','vkBeginCommandBuffer','vkCmdExecuteCommands']:continue
   cb=c.FindChild('commandBuffer')
   if cb is None:cb=c.FindChild('CommandBuffer')
   if cb is None:parseFailures.append(name);continue
   cb=int(cb.data.basic.u)
   if name in ['vkBeginCommandBuffer','vkCmdExecuteCommands']:
    state.pop((cb,0),None);state.pop((cb,1),None);continue
   point=c.FindChild('pipelineBindPoint');pipeline=c.FindChild('pipeline');key=(cb,int(point.data.basic.u));value=int(pipeline.data.basic.u)
   repeated+=state.get(key)==value;state[key]=value
  report.update(status='inspected',apiCounts={k:v for k,v in counts.items() if k in ['vkCmdBindPipeline','vkCmdBindDescriptorSets','vkCmdDrawIndexed','vkCmdDrawIndexedIndirect','vkCmdExecuteCommands']},repeatedSamePipeline=repeated,parseFailures=parseFailures)
  assert not parseFailures;assert counts['vkCmdBindPipeline']<804 and counts['vkCmdDrawIndexed']==2791
  assert hashlib.sha256(player.read_bytes()).hexdigest()==report['executableSha256']
 finally:
  if controller:controller.Shutdown()
  capture.Shutdown()

except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if control:control.Shutdown()
 (out/'state.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='inspected' else 1)
