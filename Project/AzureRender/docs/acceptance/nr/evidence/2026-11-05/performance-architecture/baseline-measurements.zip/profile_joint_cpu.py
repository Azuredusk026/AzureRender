from pathlib import Path
import subprocess,json,time
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;out=a/'native-joint-cpu-stacks';out.mkdir()
r=root/'build/runs/20261103-234012-character-reference-stages-5abe6c';sample=r/'sample_native_stack.exe'
command=[str(root/'build/ninja-msvc-release/AzurePlayer.exe'),'--project',str(r/'qualified-lit-surfaces-joint-v4/joint-materials.azureproject'),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--smoke-frames','300','--gpu-timing','--gpu-timing-output',str(out/'timing.json')]
(out/'task.json').write_text(json.dumps(dict(scope='CPU source diagnosis, sampled runs do not qualify formal performance',evidence='Original 2100-frame run: work P95 56.46 ms, recorded graph average only 5.83 ms; runtime trace frames zero and report serialization occurs after main loop',hypothesis='CPU cost resides in per-frame scene/asset snapshot or update outside command recording; collect actual native stacks before modifying implementation',deadlineSeconds=600,command=command),indent=2));si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 child=subprocess.Popen(command,cwd=out,startupinfo=si,stdout=stdout,stderr=stderr)
 try:
  while child.poll() is None:
   log=(out/'stderr.log').read_text(errors='replace')
   if 'Outline mask allocated: frame=1' in log:break
   if time.monotonic()-start>450:raise TimeoutError('No steady-frame entry before sampling deadline')
   time.sleep(.1)
  assert child.poll() is None,'Host exited before steady-frame sampling'
  for i in range(6):
   if child.poll() is not None:break
   with (out/f'stack-{i}.log').open('wb') as log:result=subprocess.run([str(sample),str(child.pid),str(root/'build/ninja-msvc-release')],stdout=log,stderr=subprocess.STDOUT,timeout=30)
   print('stack',i,'exit',result.returncode,flush=True);time.sleep(.2)
  result=child.wait(timeout=max(30,600-(time.monotonic()-start)));(out/'result.json').write_text(json.dumps(dict(exitCode=result,seconds=time.monotonic()-start),indent=2));assert result==0,result
 finally:
  if child.poll() is None:child.kill();child.wait()
