from pathlib import Path
import sys,json,hashlib,traceback
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'native-joint-rdc-profile';report=json.loads((out/'capture-state.json').read_text());report.pop('error',None)
try:
 report['status']='profiling';(out/'state.json').write_text(json.dumps(report,indent=2));sys.path.insert(0,str(root/'tools'));from native_render.renderdoc_profile import profile_capture
 capture=Path(report['capture']);result=profile_capture(rd,capture,out/'events',shader_event_limit=64);report.update(status='profiled',events=result['events'],sumEventMs=result['sumEventMs'],captureSha256=hashlib.sha256(capture.read_bytes()).hexdigest())
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:(out/'state.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='profiled' else 1)
