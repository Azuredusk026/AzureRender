from pathlib import Path
import json,re,bisect,ctypes,collections
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;out=a/'current-frame-cpu-stacks';module=json.loads((out/'module.json').read_text());base=int(module['base'],16);s=(a/'private-profile-map-current/AzurePlayer.map').read_text(errors='replace');preferred=int(re.search(r'Preferred load address is\s+([0-9a-fA-F]+)',s).group(1),16);symbols={}
for line in s.splitlines():
 m=re.match(r'\s+[0-9a-fA-F]{4}:[0-9a-fA-F]{8}\s+(\S+)\s+([0-9a-fA-F]{16})\s',line)
 if m:symbols.setdefault(int(m[2],16)-preferred,[]).append(m[1])
keys=sorted(symbols);api=ctypes.WinDLL('dbghelp').UnDecorateSymbolName;api.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_uint,ctypes.c_uint];api.restype=ctypes.c_uint;cache={}
def undecorate(name):
 if name in cache:return cache[name]
 out=ctypes.create_string_buffer(16384);ok=api(name.encode(),out,len(out),0);v=out.value.decode(errors='replace') if ok else name;cache[name]=v;return v
rows=[];leaves=collections.Counter()
for path in sorted(out.glob('stack-*.log')):
 text=path.read_text(errors='replace');frames=[];previous=None
 for address in re.findall(r'AzurePlayer!([0-9a-fA-F]+)',text):
  rva=int(address,16)-base
  if rva==previous:continue
  previous=rva;index=bisect.bisect_right(keys,rva)-1
  assert index>=0
  names=[undecorate(n) for n in symbols[keys[index]]];frames.append(dict(address=address,rva=hex(rva),offset=rva-keys[index],symbols=names))
 if frames:leaves[frames[0]['symbols'][0]]+=1
 rows.append(dict(path=path.name,header=text.splitlines()[0],frames=frames))
report=dict(status='symbolized',scope='Jittered CPU stack samples, with actual module base and byte-identical current shipping.text; leaf counts are sample observations, not measured exclusive function times',module=module,preferredBase=hex(preferred),samples=len(rows),leaves=dict(leaves),stacks=rows);(out/'symbolized-stacks.json').write_text(json.dumps(report,indent=2));print('Samples',len(rows));print(json.dumps(dict(leaves),indent=2))
