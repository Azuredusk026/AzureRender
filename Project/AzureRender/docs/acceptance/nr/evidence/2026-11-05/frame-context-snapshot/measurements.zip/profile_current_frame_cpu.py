from pathlib import Path
import subprocess,json,time,ctypes,hashlib
from ctypes import wintypes
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;out=a/'current-frame-cpu-stacks';out.mkdir();r=root/'build/runs/20261103-234012-character-reference-stages-5abe6c';sample=r/'sample_native_stack.exe'
command=[str(root/'build/ninja-msvc-release/AzurePlayer.exe'),'--project',str(r/'qualified-lit-surfaces-joint-v4/joint-materials.azureproject'),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--smoke-frames','300','--gpu-timing','--gpu-timing-output',str(out/'timing.json')]
(out/'task.json').write_text(json.dumps(dict(scope='Actual current CPU stacks; sampled run is diagnostic, not performance qualification',sourceBase='552f986',integrationRed='Full native CPU work P95 33.84812ms exceeds original8ms target',hypothesis='Remaining cost is outside command recording; collect jittered actual stacks after resource/identity/binding optimizations before next frame data architecture change',deadlineSeconds=600,maximumSamples=24,spacingSeconds=[.011,.071,.137,.193,.257],command=command),indent=2));si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic();sha=hashlib.sha256(Path(command[0]).read_bytes()).hexdigest();records=[]
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 child=subprocess.Popen(command,cwd=out,startupinfo=si,stdout=stdout,stderr=stderr)
 try:
  while child.poll() is None:
   if 'Outline mask allocated: frame=1' in (out/'stderr.log').read_text(errors='replace'):break
   assert time.monotonic()-start<450,'No steady-frame entry before diagnostic deadline';time.sleep(.1)
  assert child.poll() is None,'Host exited before steady-frame sampling'
  kernel=ctypes.WinDLL('kernel32',use_last_error=True);psapi=ctypes.WinDLL('psapi',use_last_error=True);kernel.OpenProcess.restype=wintypes.HANDLE;kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];handle=kernel.OpenProcess(0x410,False,child.pid);assert handle
  try:
   modules=(ctypes.c_void_p*2048)();needed=wintypes.DWORD();psapi.EnumProcessModulesEx.argtypes=[wintypes.HANDLE,ctypes.POINTER(ctypes.c_void_p),wintypes.DWORD,ctypes.POINTER(wintypes.DWORD),wintypes.DWORD];assert psapi.EnumProcessModulesEx(handle,modules,ctypes.sizeof(modules),ctypes.byref(needed),3)
   name=ctypes.create_unicode_buffer(1024);psapi.GetModuleFileNameExW.argtypes=[wintypes.HANDLE,ctypes.c_void_p,wintypes.LPWSTR,wintypes.DWORD];assert psapi.GetModuleFileNameExW(handle,modules[0],name,1024);assert Path(name.value).name=='AzurePlayer.exe';(out/'module.json').write_text(json.dumps(dict(pid=child.pid,base=hex(modules[0]),path=name.value,sha256=sha),indent=2))
  finally:kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle(handle)
  for i in range(24):
   if child.poll() is not None:break
   with (out/('stack-%02d.log'%i)).open('wb') as log:result=subprocess.run([str(sample),str(child.pid),str(root/'build/ninja-msvc-release')],stdout=log,stderr=subprocess.STDOUT,timeout=30)
   records.append(dict(index=i,seconds=time.monotonic()-start,exitCode=result.returncode));time.sleep([.011,.071,.137,.193,.257][i%5])
  result=child.wait(timeout=max(30,600-(time.monotonic()-start)));(out/'result.json').write_text(json.dumps(dict(exitCode=result,seconds=time.monotonic()-start,samples=records),indent=2));assert result==0,result;assert hashlib.sha256(Path(command[0]).read_bytes()).hexdigest()==sha;print('CPU stacks collected',len(records),flush=True)
 finally:
  if child.poll() is None:child.kill();child.wait()
