from pathlib import Path
import sys,json,hashlib,traceback
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'shader-optimization-control';capture=rd.OpenCaptureFile();controller=None;replacements=[];report=dict(status='starting',scope='Private compiler optimization cost and output control; independent of formal runtime P95')
try:
 assert capture.OpenFile(str(a/'native-joint-rdc-profile/joint_frame320.rdc'),'',None)==rd.ResultCode.Succeeded
 status,controller=capture.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 profile=json.loads((a/'native-joint-rdc-profile/events/profile.json').read_text());costs=json.loads((a/'native-joint-rdc-profile/shader-costs.json').read_text());task=json.loads((out/'task.json').read_text());targets={r['name']:r for r in task['programs']};shaderTargets=[]
 for ident,info in costs['shaders'].items():
  names=[n for n in info['programs'] if n in targets]
  if not names:continue
  assert len(names)==1;name=names[0];event=next(v['event'] for v in profile['measurements'] if v['shader']==ident);controller.SetFrameEvent(event,True);pipeline=controller.GetPipelineState();original=pipeline.GetShader(rd.ShaderStage.Pixel);reflection=pipeline.GetShaderReflection(rd.ShaderStage.Pixel);assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==targets[name]['originalSha256'];shaderTargets.append((original,name))
 assert len(shaderTargets)==4,len(shaderTargets)
 def measure(label):
  values=[dict(event=int(v.eventId),seconds=float(v.value.d)) for v in controller.FetchCounters([rd.GPUCounter.EventGPUDuration])];(out/(label+'.json')).write_text(json.dumps(values,indent=2));return dict(label=label,events=len(values),sumEventMs=sum(v['seconds']*1000 for v in values))
 actions=[]
 def walk(items):
  for action in items:
   if action.flags&rd.ActionFlags.Drawcall and not action.children:actions.append(action)
   walk(action.children)
 walk(controller.GetRootActions());last=max(actions,key=lambda x:x.eventId)
 def output_image(label):
  controller.SetFrameEvent(last.eventId,True);pipe=controller.GetPipelineState();resource=pipe.GetOutputTargets()[0].resource
  texture=next(t for t in controller.GetTextures() if t.resourceId==resource)
  data=bytes(controller.GetTextureData(resource,rd.Subresource(0,0,0)))
  assert len(data)==texture.width*texture.height*4 and texture.format.compByteWidth==1
  save=rd.TextureSave();save.resourceId=resource;save.destType=rd.FileType.PNG
  result=controller.SaveTexture(save,str(out/(label+'.png')));assert result==rd.ResultCode.Succeeded,str(result)
  return data
 def difference(first,second):
  assert len(first)==len(second);changed=0;above=0;maximum=0;total=0
  for i in range(0,len(first),4):
   values=[abs(first[i+c]-second[i+c]) for c in range(3)];m=max(values);changed+=m>0;above+=m>1;maximum=max(maximum,m);total+=sum(values)
  return dict(changedPixels=changed,changedOverOneBytePixels=above,maxChannelByteDifference=maximum,meanRgbByteDifference=total/(len(first)//4*3))
 report['status']='baseline';(out/'state.json').write_text(json.dumps(report,indent=2));results=[measure('baseline-before')];baselineImage=output_image('baseline-before')
 for original,name in shaderTargets:
  replacement,errors=controller.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/'programs'/name).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert replacement!=rd.ResourceId.Null(),errors;replacements.append((original,replacement));controller.ReplaceResource(original,replacement)
 report['status']='control';(out/'state.json').write_text(json.dumps(report,indent=2));results.append(measure('optimized'))
 optimizedImage=output_image('optimized')
 for original,replacement in replacements:controller.RemoveReplacement(original)
 results.append(measure('baseline-after'));afterImage=output_image('baseline-after');report['imageDifference']=difference(baselineImage,optimizedImage);report['baselineImageDrift']=difference(baselineImage,afterImage);report.update(status='profiled',measurements=results,changedPrograms=[n for r,n in shaderTargets],onlyVariable=task['onlyVariable']);report['baselineDriftFraction']=abs(results[2]['sumEventMs']-results[0]['sumEventMs'])/results[0]['sumEventMs'];report['controlDifferenceMs']=(results[0]['sumEventMs']+results[2]['sumEventMs'])/2-results[1]['sumEventMs']
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if controller:
  for original,replacement in replacements:
   try:controller.RemoveReplacement(original);controller.FreeTargetResource(replacement)
   except Exception:pass
  controller.Shutdown()
 capture.Shutdown();(out/'state.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='profiled' else 1)
