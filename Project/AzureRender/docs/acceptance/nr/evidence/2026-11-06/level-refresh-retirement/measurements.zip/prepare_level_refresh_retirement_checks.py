from pathlib import Path
import json
a=Path(__file__).resolve().parent;out=a/'level-refresh-retirement'
selection=json.loads((a/'loaded-resource-identities/selected.json').read_text())
for name,target in [('AzureEngine.LevelRefreshRetirement','AzureLevelRefreshRetirementTests'),('AzureEngine.AssetLevel','AzureAssetLevelTests'),('AzureEngine.ProjectStartup','AzureProjectStartupTests'),('AzureEngine.PresentationRuntime','AzurePresentationRuntimeTests'),('AzureEngine.PlayableQuest','AzurePlayableQuestTests'),('AzureEngine.ScriptRuntime','AzureScriptRuntimeTests'),('AzureEngine.SystemComposition','AzureSystemCompositionTests'),('AzureGame.PlatformerFlow','AzurePlatformerFlowTests')]:
 selection['names'].append(name);selection['targets'].append(target)
(out/'selected.json').write_text(json.dumps(selection,indent=2))
s=(a/'validate_loaded_resource_identities.py').read_text().replace("out=a/'loaded-resource-identities'","out=a/'level-refresh-retirement'")
(a/'validate_level_refresh_retirement.py').write_text(s)
s=(a/'capture_loaded_resource_identities.py').read_text().replace("out=a/'loaded-resource-identities/image'","out=a/'level-refresh-retirement/image'").replace("'sourceBase':'e0ecf1a'","'sourceBase':'48b04c7'").replace('Loaded immutable resource identity map candidate','Unchanged level-refresh data retirement candidate')
(a/'capture_level_refresh_retirement.py').write_text(s)
s=(a/'measure_loaded_resource_identities.py').read_text().replace("out=a/'loaded-resource-identities/performance'","out=a/'level-refresh-retirement/performance'").replace("sourceBase='e0ecf1a'","sourceBase='48b04c7'").replace('Loaded immutable resource-identity candidate-only','Unchanged level-refresh retirement candidate-only')
(a/'measure_level_refresh_retirement.py').write_text(s)
