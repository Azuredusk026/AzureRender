from pathlib import Path
import json,hashlib,zipfile,subprocess,xml.etree.ElementTree as ET,re,sys
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;task=a/'level-refresh-retirement'
out=root/'docs/acceptance/nr/evidence/2026-11-06/level-refresh-retirement';out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
image=json.loads((task/'image/results.json').read_text());timing=json.loads((task/'performance/results.json').read_text())
assert image['status']=='passed' and image['zeroAllocator'] and len(image['frames'])==4 and image['productionShaders535ByteIdentical']
red=(task/'main-release-red.log').read_text();red_rows=re.findall(r'cycle=(\d) mainPollLargeFreeBytes=(\d+) retainedLargeBytes=(\d+)',red)
assert len(red_rows)==3 and int(red_rows[-1][1])==7681302 and int((task/'main-release-red-exit.txt').read_text())!=0
test_hashes=json.loads((task/'test-source-hashes.json').read_text());assert all(digest(root/name)==value for name,value in test_hashes.items())
canonical=root/'docs/acceptance/nr/evidence/2026-11-05/runtime-node-identity/measurements.zip'
with zipfile.ZipFile(canonical) as z:
 pngs={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.endswith('.png')}
 assert all(row['sha256'] in pngs for row in image['frames'])
snapshot=task/'source';snapshot.mkdir(exist_ok=True)
names=['CMakeLists.txt','src/runtime/LevelSession.cpp','src/runtime/LevelSession.hpp','tests/LevelRefreshRetirementTests.cpp']
for name in names:
 p=snapshot/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/name).read_bytes())
(snapshot/'production.diff').write_bytes(subprocess.check_output(['git','diff','--',*names],cwd=root))
selection=json.loads((task/'selected.json').read_text());checks={};cycles={};unchanged_gpu={}
for tag in ['release','debug']:
 proof=json.loads((root/f'build/ninja-msvc-{tag}/build-provenance.json').read_text());verify(root,proof)
 result=json.loads((task/f'engine-{tag}-checks.json').read_text());assert result['exitCode']==0
 cases=list(ET.parse(task/f'engine-{tag}-checks.xml').iter('testcase'));assert len(cases)==28 and all(not c.findall('failure') and not c.findall('skipped') for c in cases)
 assert sorted(c.attrib['name'] for c in cases)==sorted(selection['names'])
 build=json.loads((task/f'engine-{tag}-build.json').read_text());assert build['status']=='passed' and build['productionShaders535ByteIdentical']
 checks[tag]=dict(cpuChecks=28,buildSeconds=build['seconds'],checksSeconds=result['seconds'],productCount=build['productCount'],productionShaders535ByteIdentical=True)
 matches=re.findall(r'cycle=(\d) mainPollLargeFreeBytes=(\d+) retainedLargeBytes=(\d+)',(task/f'engine-{tag}-checks-full.log').read_text(errors='replace'));assert len(matches)==3 and all(int(row[1])==0 for row in matches) and len({int(row[2]) for row in matches})==1
 cycles[tag]=[dict(cycle=int(i),mainPollLargeFreeBytes=int(freed),retainedLargeBytes=int(held)) for i,freed,held in matches]
 old=json.loads((a/f'loaded-resource-identities/engine-{tag}-provenance.json').read_text())
 for target in ['AzureSkinningGpuTests','AzureMotionVectorGpuTests','AzureSharedMotionGpuTests']:
  p=root/f'build/ninja-msvc-{tag}/{target}.exe';assert digest(p)==old['products'][str(p.resolve())]
  unchanged_gpu[tag+'/'+target]=digest(p)
before=json.loads((a/'loaded-resource-identities/image/frozen-inputs.json').read_text())['source'];current=inputs(root)
for name,value in before.items():
 if name.startswith(('src/rhi/','src/render/','src/scenes/','shaders/')):assert current[name]==value,name
old_gpu=json.loads((a/'loaded-resource-identities/gpu/gpu-checks.json').read_text());assert old_gpu['status']=='passed'
files=[p for p in task.rglob('*') if p.is_file() and p.suffix.lower() in {'.json','.log','.csv','.cpp','.hpp','.diff','.xml','.txt'}]
files += [a/name for name in ['prepare_level_refresh_retirement_checks.py','validate_level_refresh_retirement.py','capture_level_refresh_retirement.py','measure_level_refresh_retirement.py','archive_level_refresh_retirement.py']]
members={}
with zipfile.ZipFile(out/'measurements.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  name=p.relative_to(a).as_posix();data=p.read_bytes();assert name not in members;members[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
with zipfile.ZipFile(out/'measurements.zip') as z:assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==members
receipt=dict(schemaVersion=1,status='implemented-compatible-unchanged-refresh-retirement-verified-full-budgets-failed',sourceBase='48b04c7',productionAdoption=True,buildAndCpu=checks,redCycles=[dict(cycle=int(i),mainPollLargeFreeBytes=int(freed),retainedLargeBytes=int(held)) for i,freed,held in red_rows],greenCycles=cycles,shutdownObservedLargeAllocationsReleased=True,testScope='Large>=512KiB allocations inside actual main-thread poll; 1MiB serialized level field, three unchanged refreshes; not every allocation or an original frame-time gate',testSourceHashes=test_hashes,gpuMechanismEvidenceReused=dict(receipt='docs/acceptance/nr/evidence/2026-11-06/loaded-resource-identities/results.json',checks=12,executableBytesUnchanged=unchanged_gpu,renderRhiSceneAndShaderSourceSubsetUnchanged=True,scope='Same six GPU executables and requested shader bytes; no new device-mechanism run claimed'),nativeImage=image,nativeTiming=timing,timingBenefitQualified=False,fullVisualAcceptance='failed-user-review',fullPerformance='failed',canonicalPngArchive=canonical.relative_to(root).as_posix(),archiveMembers=members,archiveSha256=digest(out/'measurements.zip'))
(out/'results.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');(out/'.gitattributes').write_text('* -text -whitespace\n')
print(json.dumps(dict(members=len(members),archiveBytes=(out/'measurements.zip').stat().st_size,cpuP95=timing['cpu']['p95'],gpuP95=timing['gpu']['frameMs']['p95'],environmentPassed=timing['environmentPassed'],greenCycles=cycles),indent=2))
