from pathlib import Path
import subprocess,json,hashlib,shutil,time,sys
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'shadow-receiver-native-control';out.mkdir(exist_ok=True);(out/'source').mkdir(exist_ok=True);(out/'reconstructed').mkdir(exist_ok=True)
sys.path.insert(0,str(root/'tools'));from build_provenance import digest,inputs
source_before=inputs(root);production=root/'build/ninja-msvc-release/shaders';before={p.name:digest(p) for p in production.glob('*.spv')};assert len(before)==535
for name in ['resource-a','resource-b']:
 directory=out/name/'shaders';directory.mkdir(parents=True,exist_ok=True)
 for p in production.glob('*.spv'):shutil.copy2(p,directory/p.name)
source=(root/'shaders/mesh.frag').read_text();signature='float sampleCascadeShadow(int cascade,float normalDotLight,vec2 depthGradient,float normalCurvature) {';assert source.count(signature)==1
control_source=out/'source/mesh.frag';control_source.write_text(source.replace(signature,signature+'\n    return 1.0; // Private receiver-path cost control.\n',1))
programs=json.loads((a/'shader-optimization-control/task.json').read_text())['programs'];rows=[];start=time.monotonic()
for item in programs:
 name=item['name'];original=production/name;row={'name':name,'productionSha256':digest(original)};assert row['productionSha256']==item['originalSha256']
 for variant in ['reconstructed','control']:
  target=out/'reconstructed'/name if variant=='reconstructed' else out/'resource-b/shaders'/name
  command=[v for v in item['command'] if v not in ['-O','-fpreserve-bindings']]
  command[command.index('-MF')+1]=str(target)+'.d';command[command.index('-o')+1]=str(target)
  source_index=next(i for i,v in enumerate(command) if v.endswith('mesh.frag'));command[source_index]=str(root/'shaders/mesh.frag' if variant=='reconstructed' else control_source)
  result=subprocess.run(command,capture_output=True,timeout=120);(out/(name+'.'+variant+'.compile.log')).write_bytes(result.stdout+result.stderr);assert result.returncode==0,(name,variant,result.stderr)
  check=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(target)];result=subprocess.run(check,capture_output=True,timeout=30);(out/(name+'.'+variant+'.validate.log')).write_bytes(result.stdout+result.stderr);assert result.returncode==0,(name,variant,result.stderr)
  row[variant]={'sha256':digest(target),'bytes':target.stat().st_size,'compileCommand':command,'validationCommand':check,'spirvValidationPassed':True}
 assert row['reconstructed']['sha256']==row['productionSha256'],row
 assert row['control']['sha256']!=row['productionSha256']
 rows.append(row);print('Production byte reconstruction and control validation passed:',name,flush=True)
assert inputs(root)==source_before and before=={p.name:digest(p) for p in production.glob('*.spv')}
result={'status':'private-programs-ready','sourceBase':'9f04eb8','onlyVariable':'Four common fragment programs return full visibility from sampleCascadeShadow; dependent receiver calculations may become dead code; shadow-map generation and other programs remain','production535Unchanged':True,'sourceUnchanged':True,'seconds':time.monotonic()-start,'programs':rows,'allPrivateAByteIdentical':all(digest(p)==before[p.name] for p in (out/'resource-a/shaders').glob('*.spv')),'changedPrivateBPrograms':[p.name for p in (out/'resource-b/shaders').glob('*.spv') if digest(p)!=before[p.name]]};assert sorted(result['changedPrivateBPrograms'])==sorted(item['name'] for item in programs)
(out/'programs.json').write_text(json.dumps(result,indent=2));print('All535 production SPVs unchanged; privateB changes exactly4programs',flush=True)
