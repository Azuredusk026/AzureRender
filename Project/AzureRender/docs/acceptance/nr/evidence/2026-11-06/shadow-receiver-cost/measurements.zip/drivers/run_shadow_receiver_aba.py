from pathlib import Path
import sys,subprocess,json,time
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'shadow-receiver-native-control';rows=[];start=time.monotonic()
for label in ['a-before','b-control','a-after']:
 command=[sys.executable,'-X','utf8',str(a/'measure_shadow_receiver_one.py'),label]
 with (out/(label+'-driver.log')).open('wb') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=540)
 (out/(label+'-driver.json')).write_text(json.dumps({'exitCode':r.returncode,'command':command},indent=2))
 assert r.returncode==0,label
 result=json.loads((out/label/'results.json').read_text());assert result['sceneExtent']==[1920,1080]
 rows.append(result);print(label,'GPU mean',result['gpu']['frameMs']['mean'],'P95',result['gpu']['frameMs']['p95'],'environment passed',result['environmentPassed'],flush=True)
a0,b,a1=rows;first=a0['gpu']['frameMs']['mean'];last=a1['gpu']['frameMs']['mean'];control=b['gpu']['frameMs']['mean'];baseline=(first+last)/2;drift=abs(last-first)/first;valid=drift<=.05 and all(row['environmentPassed'] for row in rows)
result={'status':'measured-valid-comparison' if valid else 'measured-comparison-conditions-failed','sourceBase':'9f04eb8','scope':'Private420-frame native receiver-path A/B/A diagnostic, not formal1800sample acceptance or a production quality candidate','baselineDriftFraction':drift,'baselineDriftLimit':.05,'baselineMeanFrameMs':baseline,'controlMeanFrameMs':control,'differenceMs':baseline-control,'differenceFraction':(baseline-control)/baseline,'seconds':time.monotonic()-start,'rows':rows};(out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
