from pathlib import Path
import time,json,subprocess,sys
r=Path.cwd();a=r/'build/runs/20261105-125529-automatic-acceptance-3d5b54';o=a/'early-depth-counter-control';deadline=time.monotonic()+900
for p in [o/'engine-debug-checks.json',o/'image/results.json']:
 while not p.exists():
  assert time.monotonic()<deadline,'Build/image gate wait budget exhausted'
  time.sleep(1)
assert json.loads((o/'engine-debug-checks.json').read_text())['exitCode']==0
assert json.loads((o/'image/results.json').read_text())['status']=='passed'
code=subprocess.call([sys.executable,'-X','utf8',str(a/'run_adopted_early_depth_gpu_checks.py')]);assert code==0
raise SystemExit(subprocess.call([sys.executable,'-X','utf8',str(a/'measure_adopted_early_depth.py')]))
