from pathlib import Path
import sys,time,json,traceback,subprocess,hashlib,ctypes
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'early-depth-counter-control';out.mkdir(exist_ok=True)
report=dict(status='starting',sourceBase='f224da9-isolated-ordinary-early-depth',scope='Actual current capture and replay event diagnosis; independent of native performance acceptance');control=None;pid=None
def save(): (out/'state.json').write_text(json.dumps(report,indent=2))
try:
    player=a/'ordinary-early-depth/isolated-candidate/runtime-release/AzurePlayer.exe';args=['--resource-root',str(player.parent),'--project',str(root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--smoke-frames','325','--gpu-timing','--gpu-timing-output',str(out/'runtime-timing.json')]
    report.update(command=[str(player)]+args,executableSha256=hashlib.sha256(player.read_bytes()).hexdigest(),captureFrame=320,renderdocVersion=str(rd.GetVersionString()));save()
    modifications=[]
    import os
    path=rd.EnvironmentModification();path.name='PATH';path.value=str(root/'build/ninja-msvc-release')+os.pathsep+os.environ.get('PATH','');path.mod=rd.EnvMod.Set;path.sep=rd.EnvSep.Platform;modifications.append(path)
    for name,value in [('VK_LAYER_PATH','D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64;D:/Tools/VulkanSDK/1.4.350.0/Bin'),('VK_INSTANCE_LAYERS','VK_LAYER_RENDERDOC_Capture'),('ENABLE_VULKAN_RENDERDOC_CAPTURE','1'),('VK_LOADER_DRIVERS_SELECT','*nv-vk64*')]:
        item=rd.EnvironmentModification();item.name=name;item.value=value;item.mod=rd.EnvMod.Set;item.sep=rd.EnvSep.Platform;modifications.append(item)
    options=rd.CaptureOptions();options.apiValidation=False;options.allowFullscreen=False
    launch=rd.ExecuteAndInject(str(player),str(out),subprocess.list2cmdline(args),modifications,str(out/'current'),options,False);assert launch.result==rd.ResultCode.Succeeded,str(launch.result)
    control=rd.CreateTargetControl('',launch.ident,'AzureRender current GPU event diagnosis',False);assert control
    if hasattr(control,'GetPID'):pid=control.GetPID()
    report.update(status='capturing',pid=pid);save()
    control.QueueCapture(320,1);deadline=time.monotonic()+600
    while time.monotonic()<deadline and control.Connected():control.ReceiveMessage(None);time.sleep(.02)
    assert not control.Connected(),'Capture target exceeded 600-second deadline'
    files=list(out.glob('*.rdc'));assert len(files)==1,'Expected one completed capture'
    control.Shutdown();control=None
    report.update(status='captured',capture=str(files[0]),bytes=files[0].stat().st_size,captureSha256=hashlib.sha256(files[0].read_bytes()).hexdigest());save()
    assert hashlib.sha256(player.read_bytes()).hexdigest()==report['executableSha256']
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
    if control:control.Shutdown()
    save()
sys.exit(0 if report['status']=='captured' else 1)
