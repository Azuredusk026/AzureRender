from pathlib import Path
import sys,json,time,subprocess,csv,hashlib
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;out=a/'early-depth-counter-control/performance';out.mkdir();resource_root=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'))
from gpu_environment import wait_and_record,RunEnvironmentMonitor,environment_errors,snapshot
import ctypes
class HostPower(ctypes.Structure):
 _fields_=[("ac",ctypes.c_ubyte),("batteryFlag",ctypes.c_ubyte),("batteryPercent",ctypes.c_ubyte),("saver",ctypes.c_ubyte),("life",ctypes.c_ulong),("fullLife",ctypes.c_ulong)]
def read_with_power():
 value=snapshot();power=HostPower();assert ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(power));value["hostPower"]={"ac":power.ac,"batteryPercent":power.batteryPercent,"saver":power.saver};return value
def stable_power(rows):
 return all(r.get("hostPower",{}).get("ac")==1 and r.get("hostPower",{}).get("saver")==0 and r.get("powerLimitWatts")==80 for r in rows)
from run_playable_performance import memory_snapshot,stats,freeze_products
from build_provenance import inputs,digest
frozen=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
project_frozen=json.loads((a/'idle-gpu-joint/frozen-inputs.json').read_text())['project'];assert all(digest(Path(path))==value for path,value in project_frozen.items())
private_shader_frozen={str(p):digest(p) for p in (resource_root/'shaders').glob('*.spv')};assert len(private_shader_frozen)==663
(out/'frozen-inputs.json').write_text(json.dumps(dict(source=frozen,products=products,project=project_frozen,privateShaders=private_shader_frozen),indent=2))
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
command=[str(root/'build/ninja-msvc-release/AzurePlayer.exe'),'--project',str(project),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--smoke-frames','2100','--gpu-timing','--gpu-timing-output',str(out/'timing.json'),'--runtime-report',str(out/'runtime.json')]
(out/'task.json').write_text(json.dumps(dict(scope='Current full-quality production candidate; original300warmup and1800measured frames; candidate-only budget verification, no paired native speedup claim',gate='docs/plans/2026-10-17-native-playable-restoration.md',sourceBase='1eee6d6',warmup=300,samples=1800,deadlineSeconds=600,command=command,scopeBoundary='P8 fixture memory ceilings are not asserted for this native-content workload; native memory and device status are recorded directly'),indent=2))
environment=wait_and_record(out/'environment.json',read=read_with_power);assert stable_power(environment['startup']),'AC/80W startup condition failed';observations=[];surfaceInterventions=[];start=time.monotonic();si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
with RunEnvironmentMonitor(environment,path=out/'environment.json',read=read_with_power),(out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 env=__import__('os').environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
 child=subprocess.Popen(command,cwd=out,env=env,stdout=stdout,stderr=stderr,startupinfo=si)
 try:
  while child.poll() is None:
   try:row=memory_snapshot(child.pid)
   except OSError:
    if child.poll() is not None:break
    raise
   row['seconds']=time.monotonic()-start;observations.append(row)
   if time.monotonic()-start>600:raise TimeoutError('Native joint performance exceeded original formal candidate budget')
   time.sleep(.05)
 finally:
  if child.poll() is None:child.kill();child.wait()
  (out/'memory.json').write_text(json.dumps(observations,indent=2));(out/'surface-interventions.json').write_text(json.dumps(surfaceInterventions,indent=2))
(out/'environment.json').write_text(json.dumps(environment,indent=2));assert child.returncode==0,child.returncode
v=json.loads((out/'timing.json').read_text());rows=list(csv.DictReader((out/'timing.csv').open()));assert len(rows)==2100,len(rows)
columns={k:stats([float(row[k]) for row in rows[300:]]) for k in rows[0] if k.endswith('Ms')}
assert len(v['cpuFrame']['workSamplesMs'][300:])==1800
log=(out/'stdout.log').read_text(errors='replace')+(out/'stderr.log').read_text(errors='replace');assert 'Allocator after unload: buffers=0 images=0' in log
assert inputs(root)==frozen,'Source changed during native performance collection'
assert all(digest(Path(path))==value for path,value in private_shader_frozen.items()),'Private shader bytes changed'
assert all(digest(Path(path))==value for path,value in project_frozen.items()),'Mounted project file bytes changed'
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items()),'Products changed during native performance collection'
summary=dict(status='measured',sourceBase='1eee6d6',visualAcceptance='failed-user-review',seconds=time.monotonic()-start,warmup=300,samples=1800,gpu=columns,cpu=stats(v['cpuFrame']['workSamplesMs'][300:]),wait=stats(v['cpuFrame']['waitSamplesMs'][300:]),sceneExtent=[v['sceneWidth'],v['sceneHeight']],framePacing=v.get('framePacing'),allocator=v.get('allocator'),peakWorkingSetBytes=max(r['peak'] for r in observations),environmentFailures=environment_errors(environment),zeroAllocator=True,validationClean=not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-']))
summary['allMountedProjectBytesUnchanged']=True
summary['originalLimitsNumericallyMet']=summary['gpu']['frameMs']['p95']<=16.6 and summary['cpu']['p95']<=8
summary['powerProfileStable']=stable_power(environment['startup']+environment['runObservations']+[environment['final']]);summary['environmentPassed']=not summary['environmentFailures'] and summary['powerProfileStable']
summary.update(diagnosticOnly=False,resourceRoot=str(resource_root),productionShaderFilesUnchangedDuringRun=True,timingBenefitQualified=False,timingScope='Current candidate only; No paired native speedup claim; original1800sample budgets evaluated with environmental qualification')
(out/'results.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))

work={key:v[key] for key in ['computeSkinningPreparedDispatches','computeSkinningPreparedVertices','staticSkinningReusedInstances','staticSkinningReusedVertices']}
assert work['staticSkinningReusedInstances']>0 and work['staticSkinningReusedVertices']>0
work['equivalentUncachedVertexRequests']=work['computeSkinningPreparedVertices']+work['staticSkinningReusedVertices']
(out/'workload.json').write_text(json.dumps(work,indent=2));print(json.dumps(work),flush=True)
