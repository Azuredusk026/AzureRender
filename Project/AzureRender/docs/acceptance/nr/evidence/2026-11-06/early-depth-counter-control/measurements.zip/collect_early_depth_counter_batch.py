from pathlib import Path
import renderdoc as rd,json,sys,ctypes,time,hashlib,traceback
root=Path('D:/Projects/FYP/Project/AzureRender');a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'early-depth-counter-control';result=dict(status='starting',administrator=bool(ctypes.windll.shell32.IsUserAnAdmin()),batches=[]);controller=None;capture=None;start=time.monotonic()
def save(): (out/'counter-batch.json').write_text(json.dumps(result,indent=2))
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
try:
 assert result['administrator'];base=json.loads((a/'current-gpu-events/state.json').read_text());early=json.loads((out/'state.json').read_text());assert early['status']=='captured'
 baselineSelected={23277,16036,20664,26298,16855,24579,7015};selectedIndices=None
 for tag,state in [('baseline-before',base),('early-depth',early),('baseline-after',base)]:
  result['status']='collecting-'+tag;save();assert sha(Path(state['capture']))==state['captureSha256']
  capture=rd.OpenCaptureFile();assert capture.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
  status,controller=capture.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
  inventory={controller.DescribeCounter(c).name:(c,controller.DescribeCounter(c)) for c in controller.EnumerateCounters()}
  wanted=['dram__bytes.sum','smsp__inst_executed.sum','gpu__time_duration.sum','smsp__warp_issue_stalled_long_scoreboard_per_warp_active.avg.pct']
  counters=[rd.GPUCounter.EventGPUDuration,rd.GPUCounter.PSInvocations,rd.GPUCounter.SamplesPassed]+[inventory[n][0] for n in wanted]
  descriptions={int(c):controller.DescribeCounter(c) for c in counters};structured=controller.GetStructuredFile();actions={};parents={}
  def walk(items,parent=None):
   for action in items:actions[action.eventId]=action;parents[action.eventId]=parent;walk(action.children,action.eventId)
  walk(controller.GetRootActions());rows={}
  for m in controller.FetchCounters(counters):
   e=int(m.eventId);action=actions[e];row=rows.setdefault(e,dict(event=e,name=action.GetName(structured),hasChildren=bool(action.children),flags=str(action.flags),numIndices=int(action.numIndices),numInstances=int(action.numInstances),indexOffset=int(action.indexOffset),baseVertex=int(action.baseVertex),instanceOffset=int(action.instanceOffset),metrics={}))
   d=descriptions[int(m.counter)];row['metrics'][d.name]=int(m.value.u64) if m.counter in [rd.GPUCounter.PSInvocations,rd.GPUCounter.SamplesPassed] else float(m.value.d)
  ordered=[rows[e] for e in sorted(rows) if not rows[e]['hasChildren']]
  if selectedIndices is None:selectedIndices=[i for i,row in enumerate(ordered) if row['event'] in baselineSelected];assert len(selectedIndices)==len(baselineSelected)
  shaders=[]
  for i in selectedIndices:
   row=ordered[i];controller.SetFrameEvent(row['event'],True);pipe=controller.GetPipelineState();action=actions[row['event']];stage=rd.ShaderStage.Compute if action.flags&rd.ActionFlags.Dispatch else rd.ShaderStage.Pixel;ref=pipe.GetShaderReflection(stage)
   shaders.append(dict(leafIndex=i,event=row['event'],shader=str(pipe.GetShader(stage)),stage=str(stage),sha256=hashlib.sha256(bytes(ref.rawBytes)).hexdigest() if ref else None,depthTarget=str(pipe.GetDepthTarget().resource),colorTargets=[str(t.resource) for t in pipe.GetOutputTargets()] if stage==rd.ShaderStage.Pixel else []))
  batch=dict(tag=tag,captureSha256=state['captureSha256'],sourceBase=state['sourceBase'],counterDescriptions=[dict(id=k,name=d.name,description=d.description,type=str(d.resultType),unit=str(d.unit)) for k,d in descriptions.items()],rows=ordered,selectedShaders=shaders)
  (out/(tag+'-counters.json')).write_text(json.dumps(batch,indent=2));result['batches'].append(dict(tag=tag,events=len(ordered),file=tag+'-counters.json'));controller.Shutdown();controller=None;capture.Shutdown();capture=None;save()
 result.update(status='collected',seconds=time.monotonic()-start);save()
except Exception:result.update(status='failed',error=traceback.format_exc(),seconds=time.monotonic()-start);save()
finally:
 if controller:controller.Shutdown()
 if capture:capture.Shutdown()
sys.exit(0 if result['status']=='collected' else 1)
