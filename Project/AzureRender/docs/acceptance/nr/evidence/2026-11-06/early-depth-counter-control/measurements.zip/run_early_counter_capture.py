from pathlib import Path
import subprocess,json,time,hashlib,sys
r=Path.cwd();a=r/'build/runs/20261105-125529-automatic-acceptance-3d5b54';o=a/'early-depth-counter-control';sys.path.insert(0,str(r/'tools'));from build_provenance import inputs,verify
frozen=inputs(r);manifests=[json.loads((r/f'build/ninja-msvc-{c}/build-provenance.json').read_text()) for c in ['release','debug']]
for m in manifests:verify(r,m)
private=a/'ordinary-early-depth/isolated-candidate';v=json.loads((private/'manifest.json').read_text());project=json.loads((a/'idle-gpu-joint/frozen-inputs.json').read_text())['project']
def valid():
 assert all(hashlib.sha256((private/n).read_bytes()).hexdigest()==h for n,h in v['files'].items());assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in project.items());assert inputs(r)==frozen
 for m in manifests:verify(r,m)
valid();(o/'frozen-inputs.json').write_text(json.dumps(dict(source=frozen,private=v,project=project),indent=2));command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(a/'capture_early_counter_control.py')];start=time.monotonic();si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
with (o/'capture-driver.log').open('wb') as log:
 child=subprocess.Popen(command,cwd=r,stdout=log,stderr=subprocess.STDOUT,startupinfo=si)
 try:code=child.wait(timeout=600)
 except subprocess.TimeoutExpired:
  subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True);raise
valid();result=dict(exitCode=code,seconds=time.monotonic()-start,sourceAndProductsUnchanged=True,privateManifestVerified=True,projectBytesUnchanged=True,command=command);(o/'capture-result.json').write_text(json.dumps(result,indent=2));assert code==0,(o/'state.json').read_text();print(json.dumps(result),flush=True)
