from pathlib import Path
import subprocess,json,time,sys
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'transparent-world-position';sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify
source=inputs(root);manifest=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text());verify(root,manifest)
for tag in ['a-before','b-candidate','a-after']:
 command=[str(root/'build/reinstall-environment/venv/Scripts/python.exe'),'-X','utf8',str(a/'measure_transparent_world_position_one.py'),tag]
 with (out/(tag+'-driver.log')).open('wb') as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 assert result.returncode==0,(tag,(out/(tag+'-driver.log')).read_text(errors='replace')[-1500:])
 r=json.loads((out/'performance'/tag/'results.json').read_text());print(tag,'CPUmean',r['cpu']['mean'],'GPUmean',r['gpu']['frameMs']['mean'],'environment',r['environmentPassed'],flush=True)
rows=[json.loads((out/'performance'/tag/'results.json').read_text()) for tag in ['a-before','b-candidate','a-after']]
a0,b,a1=rows;mean=(a0['cpu']['mean']+a1['cpu']['mean'])/2;drift=abs(a0['cpu']['mean']-a1['cpu']['mean'])/mean;gain=(mean-b['cpu']['mean'])/mean
assert inputs(root)==source;verify(root,manifest)
report=dict(status='measured',sourceBase='4abd900',cpuBaselineMean=mean,cpuCandidateMean=b['cpu']['mean'],baselineRelativeDrift=drift,diagnosticCpuRelativeReduction=gain,diagnosticBenefitQualified=all(r['environmentPassed'] for r in rows) and drift<=.05 and gain>max(.02,drift),rows=rows,sourceInputsUnchanged=True,productsVerified=True,scope='Predeclared420frame paired diagnostic; no formal1800sample acceptance claim')
(out/'paired-cost-results.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='rows'}),flush=True)
