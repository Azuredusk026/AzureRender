from pathlib import Path
import sys,json,time,subprocess,csv,hashlib,os
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;out=a/'cpu-long-run-growth/high-qos-native';out.mkdir();resource_root=root/'build/ninja-msvc-release';private_exe=a/'cpu-long-run-growth/private-link/AzurePlayer.exe'
sys.path.insert(0,str(root/'tools'))
from gpu_environment import wait_and_record,RunEnvironmentMonitor,environment_errors,snapshot
import ctypes
class HostPower(ctypes.Structure):
 _fields_=[("ac",ctypes.c_ubyte),("batteryFlag",ctypes.c_ubyte),("batteryPercent",ctypes.c_ubyte),("saver",ctypes.c_ubyte),("life",ctypes.c_ulong),("fullLife",ctypes.c_ulong)]
def read_with_power():
 value=snapshot();power=HostPower();assert ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(power));value["hostPower"]={"ac":power.ac,"batteryPercent":power.batteryPercent,"saver":power.saver};return value
def stable_power(rows):
 return all(r.get("hostPower",{}).get("ac")==1 and r.get("hostPower",{}).get("saver")==0 and r.get("powerLimitWatts")==80 for r in rows)
from run_playable_performance import memory_snapshot,stats,freeze_products
from build_provenance import inputs,digest
private_files={str(p):digest(p) for p in (a/'cpu-long-run-growth/source').glob('*.cpp')};private_files[str(private_exe)]=digest(private_exe);frozen=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
project_frozen=json.loads((a/'idle-gpu-joint/frozen-inputs.json').read_text())['project'];assert all(digest(Path(path))==value for path,value in project_frozen.items())
private_shader_frozen={str(p):digest(p) for p in (resource_root/'shaders').glob('*.spv')};assert len(private_shader_frozen)==663
(out/'frozen-inputs.json').write_text(json.dumps(dict(source=frozen,products=products,project=project_frozen,privateShaders=private_shader_frozen),indent=2))
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
command=[str(private_exe),'--project',str(project),'--resource-root',str(resource_root),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--smoke-frames','2100','--gpu-timing','--gpu-timing-output',str(out/'timing.json'),'--runtime-report',str(out/'runtime.json')]
(out/'task.json').write_text(json.dumps(dict(scope='Private instrumented CPU stages2100frames; timing output is diagnostic with log overhead; original NR12 full-quality1800-sample acceptance unchanged',gate='docs/plans/2026-10-17-native-playable-restoration.md',sourceBase='a295e09',warmup=300,samples=1800,deadlineSeconds=600,command=command,scopeBoundary='P8 fixture memory ceilings are not asserted for this native-content workload; native memory and device status are recorded directly'),indent=2))

class PdhUnion(ctypes.Union):
 _fields_=[('longValue',ctypes.c_long),('doubleValue',ctypes.c_double),('largeValue',ctypes.c_longlong)]
class PdhValue(ctypes.Structure):
 _fields_=[('status',ctypes.c_ulong),('value',PdhUnion)]
pdh=ctypes.WinDLL('pdh');handle=ctypes.c_void_p();pdh.PdhOpenQueryW.argtypes=[ctypes.c_wchar_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_void_p)];pdh.PdhAddEnglishCounterW.argtypes=[ctypes.c_void_p,ctypes.c_wchar_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_void_p)];pdh.PdhCollectQueryData.argtypes=[ctypes.c_void_p];pdh.PdhGetFormattedCounterValue.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.POINTER(ctypes.c_ulong),ctypes.POINTER(PdhValue)];pdh.PdhCloseQuery.argtypes=[ctypes.c_void_p]
assert pdh.PdhOpenQueryW(None,0,ctypes.byref(handle))==0;counters={};counterSetup={}
for name,path in [('processorPerformance',r'\Processor Information(_Total)\% Processor Performance'),('processorFrequencyMHz',r'\Processor Information(_Total)\Processor Frequency'),('processorUtilization',r'\Processor Information(_Total)\% Processor Time'),('processorQueue',r'\System\Processor Queue Length')]:
 counter=ctypes.c_void_p();status=pdh.PdhAddEnglishCounterW(handle,path,0,ctypes.byref(counter));counterSetup[name]=dict(path=path,status=int(status))
 if status==0:counters[name]=counter
pdh.PdhCollectQueryData(handle);cpuObservations=[]
def observeCpu(seconds):
 row=dict(seconds=seconds,collectStatus=int(pdh.PdhCollectQueryData(handle)))
 for name,counter in counters.items():
  value=PdhValue();kind=ctypes.c_ulong();status=pdh.PdhGetFormattedCounterValue(counter,0x200,ctypes.byref(kind),ctypes.byref(value));row[name]=value.value.doubleValue if status==0 and value.status in [0,1] else None
 cpuObservations.append(row)


class ProcessPowerState(ctypes.Structure):
 _fields_=[('Version',ctypes.c_ulong),('ControlMask',ctypes.c_ulong),('StateMask',ctypes.c_ulong)]
def set_owned_high_qos(pid):
 kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p;kernel.CloseHandle.argtypes=[ctypes.c_void_p];kernel.GetProcessId.argtypes=[ctypes.c_void_p];kernel.GetProcessId.restype=ctypes.c_ulong
 kernel.GetProcessInformation.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_ulong];kernel.SetProcessInformation.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_ulong]
 handle=kernel.OpenProcess(0x600,False,pid);assert handle,'Cannot open owned child process'
 result=dict(pid=pid,scope='Only the owned test child process; process lifetime execution-speed policy; no global power, priority, affinity or driver changes')
 try:
  assert kernel.GetProcessId(handle)==pid
  before=ProcessPowerState(1,0,0);assert kernel.GetProcessInformation(handle,4,ctypes.byref(before),ctypes.sizeof(before)),ctypes.get_last_error()
  requested=ProcessPowerState(1,before.ControlMask|1,before.StateMask&~1);assert kernel.SetProcessInformation(handle,4,ctypes.byref(requested),ctypes.sizeof(requested)),ctypes.get_last_error()
  after=ProcessPowerState(1,0,0);assert kernel.GetProcessInformation(handle,4,ctypes.byref(after),ctypes.sizeof(after)),ctypes.get_last_error()
  result.update(status='applied',before={k:getattr(before,k) for k,_ in ProcessPowerState._fields_},after={k:getattr(after,k) for k,_ in ProcessPowerState._fields_});(out/'execution-qos.json').write_text(json.dumps(result,indent=2));assert after.ControlMask&1 and not after.StateMask&1
 finally:kernel.CloseHandle(handle)

environment=wait_and_record(out/'environment.json',read=read_with_power);assert stable_power(environment['startup']),'AC/80W startup condition failed';observations=[];surfaceInterventions=[];start=time.monotonic();si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
with RunEnvironmentMonitor(environment,path=out/'environment.json',read=read_with_power),(out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 env=__import__('os').environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';env['PATH']=str(root/'build/ninja-msvc-release')+os.pathsep+env.get('PATH','')
 child=subprocess.Popen(command,cwd=out,env=env,stdout=stdout,stderr=stderr,startupinfo=si)
 try:
  set_owned_high_qos(child.pid)
  while child.poll() is None:
   try:row=memory_snapshot(child.pid)
   except OSError:
    if child.poll() is not None:break
    raise
   row['seconds']=time.monotonic()-start;observations.append(row)
   if len(observations)%20==0:observeCpu(row['seconds'])
   if time.monotonic()-start>600:raise TimeoutError('Native joint performance exceeded original diagnostic budget')
   time.sleep(.05)
 finally:
  if child.poll() is None:child.kill();child.wait()
  (out/'memory.json').write_text(json.dumps(observations,indent=2));(out/'surface-interventions.json').write_text(json.dumps(surfaceInterventions,indent=2))
pdh.PdhCloseQuery(handle);(out/'cpu-environment.json').write_text(json.dumps(dict(setup=counterSetup,observations=cpuObservations),indent=2))
(out/'environment.json').write_text(json.dumps(environment,indent=2));assert child.returncode==0,child.returncode
v=json.loads((out/'timing.json').read_text());assert v['cpuFrame']['attempts']==v['cpuFrame']['completedFrames']==2100,'Frame attempt/step identity cannot be aligned';rows=list(csv.DictReader((out/'timing.csv').open()));assert len(rows)==2100,len(rows)
columns={k:stats([float(row[k]) for row in rows[300:]]) for k in rows[0] if k.endswith('Ms')}
assert len(v['cpuFrame']['workSamplesMs'][300:])==1800
log=(out/'stdout.log').read_text(errors='replace')+(out/'stderr.log').read_text(errors='replace');assert 'Allocator after unload: buffers=0 images=0' in log
assert inputs(root)==frozen,'Source changed during native performance collection'
assert all(digest(Path(path))==value for path,value in private_shader_frozen.items()),'Private shader bytes changed'
assert all(digest(Path(path))==value for path,value in project_frozen.items()),'Mounted project file bytes changed'
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items()),'Products changed during native performance collection'
summary=dict(status='measured',sourceBase='a295e09',visualAcceptance='failed-user-review',seconds=time.monotonic()-start,warmup=300,samples=1800,gpu=columns,cpu=stats(v['cpuFrame']['workSamplesMs'][300:]),wait=stats(v['cpuFrame']['waitSamplesMs'][300:]),sceneExtent=[v['sceneWidth'],v['sceneHeight']],framePacing=v.get('framePacing'),allocator=v.get('allocator'),peakWorkingSetBytes=max(r['peak'] for r in observations),environmentFailures=environment_errors(environment),zeroAllocator=True,validationClean=not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-']))
summary['allMountedProjectBytesUnchanged']=True
summary['originalLimitsNumericallyMet']=summary['gpu']['frameMs']['p95']<=16.6 and summary['cpu']['p95']<=8
summary['powerProfileStable']=stable_power(environment['startup']+environment['runObservations']+[environment['final']]);summary['environmentPassed']=not summary['environmentFailures'] and summary['powerProfileStable']
assert all(digest(Path(p))==v for p,v in private_files.items());summary.update(diagnosticOnly=True,instrumented=True,privateFilesUnchanged=True,privateFiles=private_files,resourceRoot=str(resource_root),productionShaderFilesUnchanged=True)
(out/'results.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))

records=[]
for line in (out/'stderr.log').read_text(errors='replace').splitlines():
 if '[cpu-stages]' in line and '[code=0] ' in line:records.append(json.loads(line.split('[code=0] ',1)[1]))
assert len([r for r in records if r['kind']=='host-frame'])==80
(out/'stage-results.json').write_text(json.dumps(dict(status='measured',sourceBase='a295e09',scope='Same private executable and frozen inputs as baseline; only owned-child HighQoS execution-speed request changes; four20-frame bands; native thermal/frame acceptance separate',records=records),indent=2));print('CPU growth stages collected:',len(records),flush=True)
