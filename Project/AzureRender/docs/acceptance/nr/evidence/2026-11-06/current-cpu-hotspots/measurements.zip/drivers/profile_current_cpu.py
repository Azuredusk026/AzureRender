from pathlib import Path
import subprocess,json,time
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;out=a/'current-cpu-diagnosis';out.mkdir(exist_ok=True)
r=root/'build/runs/20261103-234012-character-reference-stages-5abe6c';sample=r/'sample_native_stack.exe'
command=[str(root/'build/ninja-msvc-release/AzurePlayer.exe'),'--project',str(r/'qualified-lit-surfaces-joint-v4/joint-materials.azureproject'),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--smoke-frames','600','--gpu-timing','--gpu-timing-output',str(out/'timing.json')]
(out/'task.json').write_text(json.dumps(dict(scope='CPU source diagnosis, sampled runs do not qualify formal performance',evidence='Current2fad7ef native420frame diagnostic CPU P95 23.911795ms, GPU P95 33.927736ms; source unchanged, no hypothesis of a specific call before sampling',hypothesis='Identify repeated current runtime paths before selecting next bounded CPU candidate; stack counts do not constitute timing attribution',deadlineSeconds=600,command=command),indent=2));
import sys,os,hashlib
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
from run_playable_performance import freeze_products
source=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe');manifest=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text());verify(root,manifest)
(out/'frozen-inputs.json').write_text(json.dumps(dict(source=source,products=products,samplerSha256=digest(sample),samplerSourceSha256=digest(r/'sample_native_stack.cpp')),indent=2))
env=os.environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 child=subprocess.Popen(command,cwd=out,env=env,startupinfo=si,stdout=stdout,stderr=stderr)
 try:
  while child.poll() is None:
   log=(out/'stderr.log').read_text(errors='replace')
   if 'Outline mask allocated: frame=1' in log:break
   if time.monotonic()-start>450:raise TimeoutError('No steady-frame entry before sampling deadline')
   time.sleep(.1)
  assert child.poll() is None,'Host exited before steady-frame sampling'
  for i in range(12):
   if child.poll() is not None:break
   with (out/f'stack-{i}.log').open('wb') as log:result=subprocess.run([str(sample),str(child.pid),str(root/'build/ninja-msvc-release')],stdout=log,stderr=subprocess.STDOUT,timeout=30)
   print('stack',i,'exit',result.returncode,flush=True);time.sleep(.2)
  result=child.wait(timeout=max(30,600-(time.monotonic()-start)));(out/'result.json').write_text(json.dumps(dict(exitCode=result,seconds=time.monotonic()-start),indent=2));assert result==0,result
 finally:
  if child.poll() is None:child.kill();child.wait()

assert inputs(root)==source,'Source inputs changed during native sampling'
assert all(digest(Path(p))==v for p,v in products.items()),'Products changed during native sampling'
verify(root,manifest)
record=json.loads((out/'result.json').read_text());record.update(status='sampled',sourceBase='2fad7ef',sourceInputsUnchanged=True,productsUnchanged=True,scope='Native sampled600frame diagnostic; no causal timing or formal performance claim',stacks=len(list(out.glob('stack-*.log'))));(out/'result.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
