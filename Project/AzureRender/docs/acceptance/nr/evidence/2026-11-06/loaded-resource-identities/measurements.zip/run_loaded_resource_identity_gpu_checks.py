from pathlib import Path
import subprocess,json,time,os,sys,re,hashlib,shutil,xml.etree.ElementTree as ET
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'loaded-resource-identities/gpu';sys.path.insert(0,str(root/'tools'))
from gpu_environment import wait_and_record,snapshot
from build_provenance import inputs,verify
out.mkdir(exist_ok=True);source=inputs(root);manifests={c:json.loads((root/('build/ninja-msvc-'+c+'/build-provenance.json')).read_text()) for c in ['release','debug']}
for m in manifests.values():verify(root,m)
environment=snapshot();(out/'startup-environment.json').write_text(json.dumps(environment,indent=2));print('Device environment recorded; functional synchronization/output checks, no performance qualification',flush=True)
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';vkinfo='D:/Tools/VulkanSDK/1.4.350.0/Bin/vulkaninfoSDK.exe';rows=json.loads((out/'gpu-checks.json').read_text()).get('rows',[]) if (out/'gpu-checks.json').exists() else []
expected={'AzureRender.SkinningGpu','AzureRender.MotionVectorGpu','AzureRender.SharedMotionGpu'}
for config in ['release','debug']:
 for gpu,pattern,marker in [('nvidia','*nv-vk64*','NVIDIA'),('intel','*igvk64*','Intel')]:
  tag=config+'-'+gpu
  if any(row['configuration']==config and row['device']==gpu and row['exitCode']==0 for row in rows):
   print(tag,'retained prior passing group',flush=True);continue
  env=os.environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']=pattern
  enumeration=subprocess.run([vkinfo,'--summary'],env=env,capture_output=True,timeout=60);raw=enumeration.stdout+enumeration.stderr;(out/(tag+'-devices.log')).write_bytes(raw)
  text=raw.decode('utf-8',errors='replace');names=re.findall(r'deviceName\s*=\s*([^\r\n]+)',text);identities=re.findall(r'deviceUUID\s*=\s*([^\r\n]+)',text);assert enumeration.returncode==0 and names and len(set(identities))==1 and len(identities)==len(names) and all(marker.lower() in name.lower() for name in names),(names,identities)
  cmd=[ctest,'--test-dir',str(root/('build/ninja-msvc-'+config)),'-R','^AzureRender.(SkinningGpu|MotionVectorGpu|SharedMotionGpu)$','--output-on-failure','--no-tests=error','--output-junit',str(out/(tag+'-tests.xml'))];start=time.monotonic()
  with (out/(tag+'-tests.log')).open('wb') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
  shutil.copy2(root/('build/ninja-msvc-'+config+'/Testing/Temporary/LastTest.log'),out/(tag+'-tests-full.log'))
  actual={case.attrib['name'] for case in ET.parse(out/(tag+'-tests.xml')).iter('testcase')};assert actual==expected,actual
  row={'configuration':config,'device':gpu,'enumeratedDevice':names[0].strip(),'deviceUUIDs':sorted(set(identities)),'enumerationEntries':len(names),'filter':pattern,'exitCode':r.returncode,'seconds':time.monotonic()-start,'actualChecks':sorted(actual),'command':cmd};rows.append(row);(out/'gpu-checks.json').write_text(json.dumps({'status':'running','rows':rows},indent=2));print(tag,'exit',r.returncode,'seconds',round(row['seconds'],2),flush=True)
  assert r.returncode==0
assert inputs(root)==source
for m in manifests.values():verify(root,m)
(out/'gpu-checks.json').write_text(json.dumps({'status':'passed','scope':'3 actual GPU cases x2configurations x2devices; synchronization validation and zero-resource assertions inside each original case; skinning includes actual normalized output reuse/cancel/dynamic overwrite and raw81word equivalence; individual/bulk barriers remain covered','rows':rows,'sourceInputsUnchanged':True,'allRecordedProductsVerified':True},indent=2));print('All12device checks passed; source/products verified',flush=True)
