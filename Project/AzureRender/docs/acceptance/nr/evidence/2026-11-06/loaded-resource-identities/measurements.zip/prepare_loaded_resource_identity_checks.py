from pathlib import Path
import json
a=Path(__file__).resolve().parent;out=a/'loaded-resource-identities'
selection=json.loads((a/'loaded-bind-pose/selected.json').read_text());selection['names'].append('AzureRender.ObjectShadowAtlas');selection['targets'].append('AzureObjectShadowAtlasTests')
(out/'selected.json').write_text(json.dumps(selection,indent=2))
s=(a/'validate_loaded_bind_pose.py').read_text().replace("out=a/'loaded-bind-pose'","out=a/'loaded-resource-identities'")
(a/'validate_loaded_resource_identities.py').write_text(s)
s=(a/'capture_loaded_bind_pose.py').read_text().replace("out=a/'loaded-bind-pose/image'","out=a/'loaded-resource-identities/image'").replace("'sourceBase':'121011c'","'sourceBase':'e0ecf1a'").replace('Loaded immutable bind-pose reuse candidate','Loaded immutable resource identity map candidate')
s+='\nidentity={"loadedResourceIdentityEntries":manifest["loadedResourceIdentityEntries"],"uniqueMeshes":manifest["uniqueMeshes"]}\nassert identity["loadedResourceIdentityEntries"]>=identity["uniqueMeshes"]>0\n(out/"identity-workload.json").write_text(json.dumps(identity,indent=2))\nprint(json.dumps(identity),flush=True)\n'
(a/'capture_loaded_resource_identities.py').write_text(s)
s=(a/'measure_loaded_bind_pose.py').read_text().replace("out=a/'loaded-bind-pose/performance'","out=a/'loaded-resource-identities/performance'").replace("sourceBase='121011c'","sourceBase='e0ecf1a'").replace('Loaded immutable bind-pose candidate-only','Loaded immutable resource-identity candidate-only')
(a/'measure_loaded_resource_identities.py').write_text(s)
s=(a/'run_loaded_bind_pose_gpu_checks.py').read_text().replace("out=a/'loaded-bind-pose/gpu'","out=a/'loaded-resource-identities/gpu'")
(a/'run_loaded_resource_identity_gpu_checks.py').write_text(s)
