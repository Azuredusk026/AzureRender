from pathlib import Path
import json,hashlib,zipfile,subprocess,xml.etree.ElementTree as ET,re,sys
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;task=a/'loaded-resource-identities'
out=root/'docs/acceptance/nr/evidence/2026-11-06/loaded-resource-identities';out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify
image=json.loads((task/'image/results.json').read_text());timing=json.loads((task/'performance/results.json').read_text());gpu=json.loads((task/'gpu/gpu-checks.json').read_text());identity=json.loads((task/'image/identity-workload.json').read_text())
assert image['status']=='passed' and image['zeroAllocator'] and len(image['frames'])==4 and image['productionShaders535ByteIdentical']
assert gpu['status']=='passed' and len(gpu['rows'])==4 and all(len(row['actualChecks'])==3 and row['exitCode']==0 for row in gpu['rows'])
assert identity['loadedResourceIdentityEntries']>0 and identity['uniqueMeshes']>0
for name in ['alias-allocation-red','reuse-identity-red']:
 assert int((task/(name+'-exit.txt')).read_text())!=0
assert 'Unused loaded resource aliases must not scale per-frame layout allocations' in (task/'alias-allocation-red.log').read_text(errors='replace')
assert 'Reused scenes must resolve their current resource identities' in (task/'reuse-identity-red.log').read_text(errors='replace')
test_hashes=json.loads((task/'modified-test-source-hashes.json').read_text());assert all(digest(root/name)==value for name,value in test_hashes.items())
canonical=root/'docs/acceptance/nr/evidence/2026-11-05/runtime-node-identity/measurements.zip'
with zipfile.ZipFile(canonical) as z:
 pngs={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.endswith('.png')}
 assert all(row['sha256'] in pngs for row in image['frames'])
snapshot=task/'source';snapshot.mkdir(exist_ok=True)
names=['src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','tests/OpaqueTransparencyScratchTests.cpp','tests/StaticSkinningRecordingTests.cpp']
for name in names:
 p=snapshot/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/name).read_bytes())
(snapshot/'production.diff').write_bytes(subprocess.check_output(['git','diff','--',*names],cwd=root))
selection=json.loads((task/'selected.json').read_text());checks={};allocations={}
for tag in ['release','debug']:
 proof=json.loads((root/f'build/ninja-msvc-{tag}/build-provenance.json').read_text());verify(root,proof)
 results=json.loads((task/f'engine-{tag}-checks.json').read_text());assert results['exitCode']==0
 cases=list(ET.parse(task/f'engine-{tag}-checks.xml').iter('testcase'));assert len(cases)==20 and all(not c.findall('failure') and not c.findall('skipped') for c in cases)
 assert sorted(c.attrib['name'] for c in cases)==sorted(selection['names'])
 build=json.loads((task/f'engine-{tag}-build.json').read_text());assert build['status']=='passed' and build['productionShaders535ByteIdentical']
 checks[tag]=dict(cpuChecks=20,buildSeconds=build['seconds'],checksSeconds=results['seconds'],productCount=build['productCount'],productionShaders535ByteIdentical=True)
 matches=re.findall(r'bindless=(\d) ordinaryAllocationBytes=(\d+) alias1024AllocationBytes=(\d+)',(task/f'engine-{tag}-checks-full.log').read_text(errors='replace'));assert len(matches)==2
 allocations[tag]=[dict(indexed=bool(int(mode)),ordinaryBytes=int(base),alias1024Bytes=int(alias),deltaBytes=int(alias)-int(base)) for mode,base,alias in matches]
 assert {r['indexed'] for r in allocations[tag]}=={False,True} and all(r['deltaBytes']<=4096 for r in allocations[tag])
files=[p for p in task.rglob('*') if p.is_file() and p.suffix.lower() in {'.json','.log','.csv','.cpp','.hpp','.diff','.xml','.txt'}]
files += [a/name for name in ['prepare_loaded_resource_identity_checks.py','validate_loaded_resource_identities.py','capture_loaded_resource_identities.py','measure_loaded_resource_identities.py','run_loaded_resource_identity_gpu_checks.py','archive_loaded_resource_identities.py']]
members={}
with zipfile.ZipFile(out/'measurements.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  name=p.relative_to(a).as_posix();data=p.read_bytes();assert name not in members;members[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
with zipfile.ZipFile(out/'measurements.zip') as z:assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==members
receipt=dict(schemaVersion=1,status='implemented-compatible-loaded-resource-identities-allocation-invariant-verified-full-budgets-failed',sourceBase='e0ecf1a',productionAdoption=True,buildAndCpu=checks,allocationControls=allocations,modifiedTestSourceHashes=test_hashes,testSourceScope='Modified test files frozen separately; runtime provenance source scope excludes tests',gpuMechanisms=gpu,nativeImage=image,nativeIdentities=identity,nativeTiming=timing,timingBenefitQualified=False,fullVisualAcceptance='failed-user-review',fullPerformance='failed',canonicalPngArchive=canonical.relative_to(root).as_posix(),archiveMembers=members,archiveSha256=digest(out/'measurements.zip'))
(out/'results.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');(out/'.gitattributes').write_text('* -text -whitespace\n')
print(json.dumps(dict(members=len(members),archiveBytes=(out/'measurements.zip').stat().st_size,cpuP95=timing['cpu']['p95'],gpuP95=timing['gpu']['frameMs']['p95'],environmentPassed=timing['environmentPassed'],allocations=allocations),indent=2))
