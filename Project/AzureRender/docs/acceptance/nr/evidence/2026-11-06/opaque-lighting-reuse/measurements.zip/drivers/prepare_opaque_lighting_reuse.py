from pathlib import Path
import subprocess,json,hashlib,shutil,time,sys
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'opaque-lighting-reuse-prototype';out.mkdir(exist_ok=True);(out/'source').mkdir(exist_ok=True);(out/'reconstructed').mkdir(exist_ok=True)
sys.path.insert(0,str(root/'tools'));from build_provenance import digest,inputs
source_before=inputs(root);production=root/'build/ninja-msvc-release/shaders';before={p.name:digest(p) for p in production.glob('*.spv')};assert len(before)==535
for name in ['resource-a','resource-b']:
 directory=out/name/'shaders';directory.mkdir(parents=True,exist_ok=True)
 for p in production.glob('*.spv'):shutil.copy2(p,directory/p.name)
source=(root/'shaders/mesh.frag').read_text();signature='    if(azureWritePlainUnlitBeauty(baseColor,geometricNormal,platformMask))return;';assert source.count(signature)==1
reuse=r"""
#if !defined(AZURE_OPAQUE_SNAPSHOT)
    uint cacheFeatures=AZURE_MATERIAL_FEATURES;
    bool cacheUniformEligible=AZURE_ALPHA_MODE==0 && AZURE_MATERIAL_CLASS==0U
        && (cacheFeatures&~0xc0000028U)==0U && material.nodeOpacity==1.0
        && camera.clusterLighting.x>.5 && camera.screenReflectionTrace.x>1.5
        && int(floor(camera.qaParameters.x+.5))==0 && int(floor(camera.qaParameters.y+.5))==0
        && camera.qaParameters.z>.5 && platformMask<.5
        && (material.materialPadding&AZURE_SELECTED_PADDING)==0U;
    if(cacheUniformEligible) {
        vec2 cacheUv=AZURE_FRAGMENT_COORD.xy/vec2(textureSize(opaqueSceneColor,0));
        bool noReflection=sampleComputedScreenReflection(cacheUv).a==0.0;
        if(subgroupAll(noReflection)) {
            ivec2 cachePixel=clamp(ivec2(AZURE_FRAGMENT_COORD.xy),ivec2(0),textureSize(opaqueSceneColor,0)-1);
            outputColor=texelFetch(opaqueSceneColor,cachePixel,0);
            outputNormal=vec4(geometricNormal*.5+.5,0.0);
            azureWriteDisplayMask(1.0);
            return;
        }
    }
#endif
"""
control_source=out/'source/mesh.frag';control_source.write_text(source.replace('#version 450','#version 450\n#extension GL_KHR_shader_subgroup_basic : require\n#extension GL_KHR_shader_subgroup_vote : require',1).replace(signature,signature+reuse,1))
programs=[p for p in json.loads((a/'shader-optimization-control/task.json').read_text())['programs'] if not p['name'].startswith('character_snapshot')];rows=[];start=time.monotonic()
for item in programs:
 name=item['name'];original=production/name;row={'name':name,'productionSha256':digest(original)};assert row['productionSha256']==item['originalSha256']
 for variant in ['reconstructed','control']:
  target=out/'reconstructed'/name if variant=='reconstructed' else out/'resource-b/shaders'/name
  command=[v for v in item['command'] if v not in ['-O','-fpreserve-bindings']]
  if variant=='control':command.insert(1,'--target-env=vulkan1.1')
  command[command.index('-MF')+1]=str(target)+'.d';command[command.index('-o')+1]=str(target)
  source_index=next(i for i,v in enumerate(command) if v.endswith('mesh.frag'));command[source_index]=str(root/'shaders/mesh.frag' if variant=='reconstructed' else control_source)
  result=subprocess.run(command,capture_output=True,timeout=120);(out/(name+'.'+variant+'.compile.log')).write_bytes(result.stdout+result.stderr);assert result.returncode==0,(name,variant,result.stderr)
  check=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.1' if variant=='control' else 'vulkan1.0',str(target)];result=subprocess.run(check,capture_output=True,timeout=30);(out/(name+'.'+variant+'.validate.log')).write_bytes(result.stdout+result.stderr);assert result.returncode==0,(name,variant,result.stderr)
  row[variant]={'sha256':digest(target),'bytes':target.stat().st_size,'compileCommand':command,'validationCommand':check,'spirvValidationPassed':True}
 assert row['reconstructed']['sha256']==row['productionSha256'],row
 assert row['control']['sha256']!=row['productionSha256']
 rows.append(row);print('Production byte reconstruction and control validation passed:',name,flush=True)
assert inputs(root)==source_before and before=={p.name:digest(p) for p in production.glob('*.spv')}
result={'status':'private-programs-ready','sourceBase':'a5f4d86','onlyVariable':'Two main ordinary fragment programs try subgroup-coherent reuse of same-frame opaque lighting when computedSSR contribution is zero; requiredVulkan1.1/SPIRV1.3 target; snapshots, shadow reception and other production programs remain','production535Unchanged':True,'sourceUnchanged':True,'seconds':time.monotonic()-start,'programs':rows,'allPrivateAByteIdentical':all(digest(p)==before[p.name] for p in (out/'resource-a/shaders').glob('*.spv')),'changedPrivateBPrograms':[p.name for p in (out/'resource-b/shaders').glob('*.spv') if digest(p)!=before[p.name]]};assert sorted(result['changedPrivateBPrograms'])==sorted(item['name'] for item in programs)
(out/'programs.json').write_text(json.dumps(result,indent=2));print('All535 production SPVs unchanged; privateB changes exactly2programs',flush=True)
