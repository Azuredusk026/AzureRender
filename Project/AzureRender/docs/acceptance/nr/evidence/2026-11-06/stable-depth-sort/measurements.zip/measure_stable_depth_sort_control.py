from pathlib import Path
import sys,json,time,subprocess,csv,hashlib,os
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;out=a/'stable-depth-sort-control/native';out.mkdir();resource_root=root/'build/ninja-msvc-release';private_exe=a/'stable-depth-sort-control/private-link/AzurePlayer.exe'
sys.path.insert(0,str(root/'tools'))
from gpu_environment import wait_and_record,RunEnvironmentMonitor,environment_errors,snapshot
import ctypes
class HostPower(ctypes.Structure):
 _fields_=[("ac",ctypes.c_ubyte),("batteryFlag",ctypes.c_ubyte),("batteryPercent",ctypes.c_ubyte),("saver",ctypes.c_ubyte),("life",ctypes.c_ulong),("fullLife",ctypes.c_ulong)]
def read_with_power():
 value=snapshot();power=HostPower();assert ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(power));value["hostPower"]={"ac":power.ac,"batteryPercent":power.batteryPercent,"saver":power.saver};return value
def stable_power(rows):
 return all(r.get("hostPower",{}).get("ac")==1 and r.get("hostPower",{}).get("saver")==0 and r.get("powerLimitWatts")==80 for r in rows)
from run_playable_performance import memory_snapshot,stats,freeze_products
from build_provenance import inputs,digest
private_files={str(p):digest(p) for p in (a/'stable-depth-sort-control/source').glob('*.cpp')};private_files[str(private_exe)]=digest(private_exe);frozen=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
project_frozen=json.loads((a/'idle-gpu-joint/frozen-inputs.json').read_text())['project'];assert all(digest(Path(path))==value for path,value in project_frozen.items())
private_shader_frozen={str(p):digest(p) for p in (resource_root/'shaders').glob('*.spv')};assert len(private_shader_frozen)==663
(out/'frozen-inputs.json').write_text(json.dumps(dict(source=frozen,products=products,project=project_frozen,privateShaders=private_shader_frozen),indent=2))
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
command=[str(private_exe),'--project',str(project),'--resource-root',str(resource_root),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--smoke-frames','420','--gpu-timing','--gpu-timing-output',str(out/'timing.json'),'--runtime-report',str(out/'runtime.json')]
(out/'task.json').write_text(json.dumps(dict(scope='Private instrumented CPU stages420frames; timing output is diagnostic with log overhead; original NR12 full-quality1800-sample acceptance unchanged',gate='docs/plans/2026-10-17-native-playable-restoration.md',sourceBase='8f4c330',warmup=300,samples=120,deadlineSeconds=300,command=command,scopeBoundary='P8 fixture memory ceilings are not asserted for this native-content workload; native memory and device status are recorded directly'),indent=2))
environment=wait_and_record(out/'environment.json',read=read_with_power);assert stable_power(environment['startup']),'AC/80W startup condition failed';observations=[];surfaceInterventions=[];start=time.monotonic();si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
with RunEnvironmentMonitor(environment,path=out/'environment.json',read=read_with_power),(out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 env=__import__('os').environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';env['PATH']=str(root/'build/ninja-msvc-release')+os.pathsep+env.get('PATH','')
 child=subprocess.Popen(command,cwd=out,env=env,stdout=stdout,stderr=stderr,startupinfo=si)
 try:
  while child.poll() is None:
   try:row=memory_snapshot(child.pid)
   except OSError:
    if child.poll() is not None:break
    raise
   row['seconds']=time.monotonic()-start;observations.append(row)
   if time.monotonic()-start>300:raise TimeoutError('Native joint performance exceeded original diagnostic budget')
   time.sleep(.05)
 finally:
  if child.poll() is None:child.kill();child.wait()
  (out/'memory.json').write_text(json.dumps(observations,indent=2));(out/'surface-interventions.json').write_text(json.dumps(surfaceInterventions,indent=2))
(out/'environment.json').write_text(json.dumps(environment,indent=2));assert child.returncode==0,child.returncode
v=json.loads((out/'timing.json').read_text());assert v['cpuFrame']['attempts']==v['cpuFrame']['completedFrames']==420,'Frame attempt/step identity cannot be aligned';rows=list(csv.DictReader((out/'timing.csv').open()));assert len(rows)==420,len(rows)
columns={k:stats([float(row[k]) for row in rows[300:]]) for k in rows[0] if k.endswith('Ms')}
assert len(v['cpuFrame']['workSamplesMs'][300:])==120
log=(out/'stdout.log').read_text(errors='replace')+(out/'stderr.log').read_text(errors='replace');assert 'Allocator after unload: buffers=0 images=0' in log
assert inputs(root)==frozen,'Source changed during native performance collection'
assert all(digest(Path(path))==value for path,value in private_shader_frozen.items()),'Private shader bytes changed'
assert all(digest(Path(path))==value for path,value in project_frozen.items()),'Mounted project file bytes changed'
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in products.items()),'Products changed during native performance collection'
summary=dict(status='measured',sourceBase='8f4c330',visualAcceptance='failed-user-review',seconds=time.monotonic()-start,warmup=300,samples=120,gpu=columns,cpu=stats(v['cpuFrame']['workSamplesMs'][300:]),wait=stats(v['cpuFrame']['waitSamplesMs'][300:]),sceneExtent=[v['sceneWidth'],v['sceneHeight']],framePacing=v.get('framePacing'),allocator=v.get('allocator'),peakWorkingSetBytes=max(r['peak'] for r in observations),environmentFailures=environment_errors(environment),zeroAllocator=True,validationClean=not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-']))
summary['allMountedProjectBytesUnchanged']=True
summary['originalLimitsNumericallyMet']=summary['gpu']['frameMs']['p95']<=16.6 and summary['cpu']['p95']<=8
summary['powerProfileStable']=stable_power(environment['startup']+environment['runObservations']+[environment['final']]);summary['environmentPassed']=not summary['environmentFailures'] and summary['powerProfileStable']
assert all(digest(Path(p))==v for p,v in private_files.items());summary.update(diagnosticOnly=True,instrumented=True,privateFilesUnchanged=True,privateFiles=private_files,resourceRoot=str(resource_root),productionShaderFilesUnchanged=True)
(out/'results.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))

records=[]
for line in (out/'stderr.log').read_text(errors='replace').splitlines():
 if '[cpu-depth-order-control]' in line:records.append(json.loads(line.split('[code=0] ',1)[1]))
assert len(records)==20 and all(r['allIndicesAndDrawMetadataIdentical'] for r in records)
result=dict(status='measured',sourceBase='8f4c330',scope='Same frozen actual frame inputs, alternating order, final index and draw metadata identity; local cost only; private reference and verification overhead in native frame timing',records=records,means={k:sum(r[k] for r in records)/20 for k in ['referenceMs','radixMs','radixWorldMs','triangles','staticSharedPoseTriangles','uniqueReferencedVertices','usedIndices']})
(out/'control-results.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='records'}),flush=True)
