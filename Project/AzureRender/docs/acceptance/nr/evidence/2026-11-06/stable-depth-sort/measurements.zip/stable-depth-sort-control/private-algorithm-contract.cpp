
#include <vector>
#include <array>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <stdexcept>
static void azurePrivateDepthOrder(std::vector<std::uint32_t>& order,const std::vector<float>& depths){
    bool finite=true,sorted=true;
    for(std::size_t i=0;i<order.size();++i){
        if(order[i]>=depths.size())throw std::out_of_range("Depth index is outside its input");
        finite=finite&&std::isfinite(depths[order[i]]);
        if(i&&depths[order[i-1]]<depths[order[i]])sorted=false;
    }
    if(!finite||order.size()<256){std::stable_sort(order.begin(),order.end(),[&](auto x,auto y){return depths[x]>depths[y];});return;}
    if(sorted)return;
    const auto key=[&](std::uint32_t i){const float value=depths[i];std::uint32_t bits=0;if(value!=0)std::memcpy(&bits,&value,sizeof(bits));return (bits&0x80000000U)?bits:(bits^0x7fffffffU);};
    std::vector<std::uint32_t> scratch(order.size());
    for(unsigned shift=0;shift<32;shift+=8){
        std::array<std::size_t,256> offsets{};
        for(auto i:order)++offsets[(key(i)>>shift)&255U];
        std::size_t begin=0;for(auto& count:offsets){const auto size=count;count=begin;begin+=size;}
        for(auto i:order)scratch[offsets[(key(i)>>shift)&255U]++]=i;
        order.swap(scratch);
    }
}

#include <random>
#include <numeric>
#include <iostream>
#include <limits>
int main(){try{
 std::mt19937 random(7331);std::size_t cases=0;
 for(std::size_t count:{0U,1U,2U,31U,255U,256U,257U,4096U,32768U,65536U})for(unsigned shape=0;shape<6;++shape){
  std::vector<float> depth(count);std::vector<std::uint32_t> order(count);std::iota(order.begin(),order.end(),0U);
  for(std::size_t i=0;i<count;++i){std::uint32_t bits=random()&0xfeffffffU;std::memcpy(&depth[i],&bits,4);
   if(shape==1)depth[i]=float(i%13)-6;
   if(shape==2)depth[i]=i%2?0.F:-0.F;
   if(shape==3)depth[i]=float(count-i);
   if(shape==4)depth[i]=float(i);
   if(shape==5)depth[i]=std::numeric_limits<float>::quiet_NaN();
  }
  std::shuffle(order.begin(),order.end(),random);auto expected=order;const auto original=depth;
  std::stable_sort(expected.begin(),expected.end(),[&](auto x,auto y){return depth[x]>depth[y];});azurePrivateDepthOrder(order,depth);
  if(order!=expected||(!depth.empty()&&std::memcmp(original.data(),depth.data(),depth.size()*4)))throw std::runtime_error("Private stable depth oracle mismatch");++cases;
 }
 std::vector<std::uint32_t> bad{0,2};const auto prior=bad;bool rejected=false;try{azurePrivateDepthOrder(bad,{1,2});}catch(const std::out_of_range&){rejected=true;}
 if(!rejected||bad!=prior)throw std::runtime_error("Invalid depth index must reject without mutation");std::cout<<"Stable depth oracle passed "<<cases<<" distributions and invalid input\n";
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
