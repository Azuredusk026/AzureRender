from pathlib import Path
import time,json,sys,subprocess
r=Path.cwd();a=r/'build/runs/20261105-125529-automatic-acceptance-3d5b54';o=a/'stable-depth-sort-control';deadline=time.monotonic()+900
for p in [o/'engine-debug-checks.json',o/'image/results.json']:
 while not p.exists():
  assert time.monotonic()<deadline,'Build/image gate wait deadline exhausted'
  time.sleep(1)
assert json.loads((o/'engine-debug-checks.json').read_text())['exitCode']==0
assert json.loads((o/'image/results.json').read_text())['status']=='passed'
raise SystemExit(subprocess.call([sys.executable,'-X','utf8',str(a/'run_stable_depth_sort_gpu_checks.py')]))
