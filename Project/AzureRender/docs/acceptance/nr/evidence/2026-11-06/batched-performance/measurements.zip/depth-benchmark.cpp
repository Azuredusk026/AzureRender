
#include "render/StableDepthOrder.hpp"
#include "old-depth-order.hpp"
#include <chrono>
#include <iostream>
#include <numeric>
#include <random>
int main(){
 std::mt19937 random(7331);
 for(unsigned count:{4096U,32768U,65536U})for(unsigned shape=0;shape<2;++shape){
  std::vector<float> depths(count);for(auto& value:depths)value=shape?float(random()%100000)/100.F:3.F+float(random()%4096)/8192.F;
  std::vector<std::uint32_t> oldOrder(count),newOrder(count);azurerender::DepthOrderWorkspace work;
  double oldMs=0,newMs=0;
  for(unsigned round=0;round<40;++round){
   std::iota(oldOrder.begin(),oldOrder.end(),0U);std::iota(newOrder.begin(),newOrder.end(),0U);
   const auto oldRun=[&]{auto start=std::chrono::steady_clock::now();baseline::stableDepthOrder(oldOrder,depths);oldMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();};
   const auto newRun=[&]{auto start=std::chrono::steady_clock::now();azurerender::stableDepthOrder(newOrder,depths,work);newMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();};
   if(round&1){oldRun();newRun();}else{newRun();oldRun();}
   if(oldOrder!=newOrder)return 1;
  }
  std::cout<<"{\"count\":"<<count<<",\"shape\":"<<shape<<",\"rounds\":40,\"baselineMs\":"<<oldMs/40<<",\"candidateMs\":"<<newMs/40<<",\"reduction\":"<<1-newMs/oldMs<<",\"keyEvaluations\":"<<work.keyEvaluations<<",\"scatterPasses\":"<<work.scatterPasses<<",\"skippedPasses\":"<<work.skippedPasses<<",\"identical\":true}\n";
 }
}
