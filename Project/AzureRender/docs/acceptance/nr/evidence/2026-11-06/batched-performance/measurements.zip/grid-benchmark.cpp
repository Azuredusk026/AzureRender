
#include "render/ClusteredLightGrid.hpp"
#include "old-cluster-grid.hpp"
#include <chrono>
#include <iostream>
int main(){
 const azurerender::ClusterGridDesc desc{16,9,24,.1F,100.F,1.5F,2.F};
 azurerender::ClusteredLightGrid reused(desc);
 std::vector<azurerender::RenderLight> lights(16);
 for(unsigned i=0;i<lights.size();++i){auto& l=lights[i];l.stableId=i;l.radius=4.F;l.clusterPosition[0]=float(i%4)-1.5F;l.clusterPosition[1]=float(i%3)-1.F;l.clusterPosition[2]=5.F+float(i)*3;if(i==0)l.shape.type=azurerender::LightKind::Directional;}
 std::vector<std::uint32_t> oldIndices,newIndices;
 std::vector<std::array<std::uint32_t,2>> oldHeaders,newHeaders;
 double oldMs=0,newMs=0;
 for(unsigned round=0;round<80;++round){
  const auto oldRun=[&]{auto start=std::chrono::steady_clock::now();baseline::ClusteredLightGrid grid({16,9,24,.1F,100.F,1.5F,2.F});grid.assign(lights);oldIndices=grid.gpuIndexData();oldHeaders=grid.gpuHeaderData();oldMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();};
  const auto newRun=[&]{auto start=std::chrono::steady_clock::now();reused.configure(desc);reused.assign(lights);reused.gpuIndexData(newIndices);reused.gpuHeaderData(newHeaders);newMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();};
  if(round&1){oldRun();newRun();}else{newRun();oldRun();}
  if(oldIndices!=newIndices||oldHeaders!=newHeaders)return 1;
 }
 std::cout<<"{\"rounds\":80,\"clusters\":3456,\"lights\":16,\"references\":"<<newIndices.size()<<",\"baselineMs\":"<<oldMs/80<<",\"candidateMs\":"<<newMs/80<<",\"reduction\":"<<1-newMs/oldMs<<",\"identical\":true}\n";
}
