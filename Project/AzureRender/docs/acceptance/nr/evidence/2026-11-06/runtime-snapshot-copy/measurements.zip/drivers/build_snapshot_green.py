from pathlib import Path
import subprocess,os,json,time
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'runtime-snapshot-copy';env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3');env['PATH']=';'.join(['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin','D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja',env['PATH']]);cmd=['cmake','--build',str(root/'build/ninja-msvc-release'),'--target','AzureRuntimeLifecycleTests'];start=time.monotonic()
with (out/'green.log').open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
(out/'green.json').write_text(json.dumps({'exitCode':r.returncode,'seconds':time.monotonic()-start,'command':cmd},indent=2));print('graph control build exit',r.returncode,flush=True)
if r.returncode==0:
 with (out/'green-test.log').open('wb') as log:case=subprocess.run([str(root/'build/ninja-msvc-release/AzureRuntimeLifecycleTests.exe')],stdout=log,stderr=subprocess.STDOUT,timeout=30)
 (out/'green-test.json').write_text(json.dumps({'exitCode':case.returncode},indent=2));print('snapshot test exit',case.returncode,flush=True)
 if case.returncode:raise SystemExit(case.returncode)
