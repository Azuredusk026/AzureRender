from pathlib import Path
import subprocess,json,os,time,hashlib
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;out=a/'runtime-snapshot-validation';env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3');env['PATH']=';'.join(['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin','D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja',env['PATH']]);python=str(root/'build/reinstall-environment/venv/Scripts/python.exe');ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';base=json.loads((a/'baseline-products/manifest.json').read_text())['shaders']
selection=json.loads((out/'selected.json').read_text());
for configuration in ['Release','Debug']:
 tag=configuration.lower();build=root/('build/ninja-msvc-'+tag);cmd=[python,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config',configuration,*[item for t in selection['targets'] for item in ['--test-target',t]]];start=time.monotonic()
 with (out/('engine-'+tag+'-build.log')).open('wb') as log:
  child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  try:code=child.wait(timeout=900)
  except subprocess.TimeoutExpired:
   subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True);child.wait();(out/('engine-'+tag+'-build.json')).write_text(json.dumps(dict(status='timeout',budgetSeconds=900,command=cmd),indent=2));raise
 assert code==0,(out/('engine-'+tag+'-build.log')).read_text(errors='replace')[-2000:]
 manifest=json.loads((build/'build-provenance.json').read_text());assert manifest['buildScope']['kind']=='runtime-and-tests';assert set(manifest['buildScope']['testProducts'])==set(selection['targets']);assert 'AzureShaderModulePrototypes' in manifest['buildScope']['targets']
 values={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (build/'shaders').glob('*.spv')};assert values==base and len(values)==535
 productNames={Path(p).name for p in manifest['products']};assert all(n in productNames for n in ['AzurePlayer.exe','AzureRender.exe','AzureMaterialValidator.exe','AzureGameLauncher.exe','bloom-cached.spv'])
 result=dict(status='passed',exitCode=code,seconds=time.monotonic()-start,command=cmd,buildScope=manifest['buildScope'],productCount=len(manifest['products']),productionShaders535ByteIdentical=True,scope='Actual incremental engine build and complete runtime/selected product fingerprint validation; not a cold-build performance comparison');(out/('engine-'+tag+'-build.json')).write_text(json.dumps(result,indent=2));print(configuration,'actual scoped build passed',result['seconds'],'seconds',flush=True)
 cmd=[ctest,'--test-dir',str(build),'-R','^('+'|'.join(selection['names'])+')$','--output-on-failure','--no-tests=error','--output-junit',str(out/('engine-'+tag+'-checks.xml'))];start=time.monotonic()
 with (out/('engine-'+tag+'-checks.log')).open('wb') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 (out/('engine-'+tag+'-checks.json')).write_text(json.dumps(dict(exitCode=r.returncode,seconds=time.monotonic()-start,command=cmd,expectedChecks=len(selection['names'])),indent=2));assert r.returncode==0;print(configuration,'snapshot affected checks passed',flush=True)
