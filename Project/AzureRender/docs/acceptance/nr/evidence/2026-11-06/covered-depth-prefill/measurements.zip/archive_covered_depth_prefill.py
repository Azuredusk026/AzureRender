from pathlib import Path
import json,hashlib,zipfile,subprocess,xml.etree.ElementTree as ET,sys
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;task=a/'covered-depth-prefill'
out=root/'docs/acceptance/nr/evidence/2026-11-06/covered-depth-prefill';out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
image=json.loads((task/'image/results.json').read_text());timing=json.loads((task/'performance/results.json').read_text());gpu=json.loads((task/'gpu/gpu-checks.json').read_text())
assert image['status']=='passed' and image['zeroAllocator'] and len(image['frames'])==4 and image['productionShaders535ByteIdentical']
assert gpu['status']=='passed' and len(gpu['rows'])==4 and all(row['exitCode']==0 for row in gpu['rows'])
red=(task/'policy-red-build.log').read_text(errors='replace');assert 'C3861' in red and 'fullyCoveredPrefill' in red
canonical=root/'docs/acceptance/nr/evidence/2026-11-05/runtime-node-identity/measurements.zip'
with zipfile.ZipFile(canonical) as z:
    pngs={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.endswith('.png')}
    assert all(row['sha256'] in pngs for row in image['frames'])
names=['CMakeLists.txt','src/render/MaterialPipelinePolicy.hpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/DepthOnlyShadowRecordingTests.cpp','tests/DepthOnlyGpuTests.cpp','tests/OutlineCoverageRecordingTests.cpp','tests/DepthPrefillRecordingTests.cpp']
snapshot=task/'source';snapshot.mkdir(exist_ok=True)
for name in names:
    p=snapshot/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/name).read_bytes())
(snapshot/'production.diff').write_bytes(subprocess.check_output(['git','diff','--',*names],cwd=root))
test_hashes={name:digest(root/name) for name in names if name.startswith('tests/')}
selection=json.loads((task/'selected.json').read_text());checks={}
for tag in ['release','debug']:
    proof=json.loads((root/f'build/ninja-msvc-{tag}/build-provenance.json').read_text());verify(root,proof)
    result=json.loads((task/f'engine-{tag}-checks.json').read_text());assert result['exitCode']==0
    cases=list(ET.parse(task/f'engine-{tag}-checks.xml').iter('testcase'));assert len(cases)==32 and all(not c.findall('failure') and not c.findall('skipped') for c in cases)
    assert sorted(c.attrib['name'] for c in cases)==sorted(selection['names'])
    build=json.loads((task/f'engine-{tag}-build.json').read_text());assert build['status']=='passed' and build['productionShaders535ByteIdentical']
    checks[tag]=dict(cpuChecks=32,buildSeconds=build['seconds'],checksSeconds=result['seconds'],productCount=build['productCount'],productionShaders535ByteIdentical=True)
files=[p for p in task.rglob('*') if p.is_file() and p.suffix.lower() in {'.json','.log','.csv','.cpp','.hpp','.diff','.xml','.txt'}]
files += [a/name for name in ['validate_covered_depth_prefill.py','run_covered_depth_prefill_gpu_checks.py','capture_covered_depth_prefill.py','measure_covered_depth_prefill.py','archive_covered_depth_prefill.py']]
members={}
with zipfile.ZipFile(out/'measurements.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        name=p.relative_to(a).as_posix();data=p.read_bytes();assert name not in members;members[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
with zipfile.ZipFile(out/'measurements.zip') as z:assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==members
receipt=dict(schemaVersion=1,status='implemented-compatible-covered-depth-prefill-full-budgets-failed',sourceBase='e8f95f3',productionAdoption=True,buildAndCpu=checks,testSourceHashes=test_hashes,gpu=gpu,nativeImage=image,nativeTiming=timing,timingBenefitQualified=False,fullVisualAcceptance='failed-user-review',fullPerformance='failed',canonicalPngArchive=canonical.relative_to(root).as_posix(),archiveMembers=members,archiveSha256=digest(out/'measurements.zip'),coverage='Opaque node opacity exactly one, single sample; main and snapshot, three facing variants; fixed/bindless descriptors, alpha/fade/MSAA fallback, recreate/unload; actual D16/D32 depth and 0/2/3 masked colors on both devices')
(out/'results.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');(out/'.gitattributes').write_text('* -text -whitespace\n')
print(json.dumps(dict(members=len(members),archiveBytes=(out/'measurements.zip').stat().st_size,cpuP95=timing['cpu']['p95'],gpuP95=timing['gpu']['frameMs']['p95'],environmentPassed=timing['environmentPassed']),indent=2))
