from pathlib import Path
import subprocess,json,hashlib,re
root=Path.cwd();out=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54/opaque-coverage-specialization/spirv-final';out.mkdir(exist_ok=True);sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin');rows=[]
for name in ['mesh_object_bindless_clipmap_field.frag.spv','character_snapshot_object_bindless_clipmap_field.frag.spv']:
    source=root/'build/ninja-msvc-release/shaders'/name
    for covered in [False,True]:
        tag=name+('.covered' if covered else '.runtime');dest=out/(tag+'.spv')
        cmd=[str(sdk/'spirv-opt.exe'),str(source),'--set-spec-const-default-value','0:true 4:'+str(covered).lower(),'--freeze-spec-const','--fold-spec-const-op-composite','-O','-o',str(dest)]
        r=subprocess.run(cmd,capture_output=True);(out/(tag+'.log')).write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout,r.stderr)
        dis=subprocess.check_output([str(sdk/'spirv-dis.exe'),str(dest)],text=True);(out/(tag+'.spvasm')).write_text(dis)
        valid=subprocess.run([str(sdk/'spirv-val.exe'),str(dest)],capture_output=True);(out/(tag+'.validation.log')).write_bytes(valid.stdout+valid.stderr)
        kills=len(re.findall(r'\bOp(?:Kill|TerminateInvocation|DemoteToHelperInvocationEXT)\b',dis))
        rows.append(dict(shader=name,covered=covered,sourceSha256=hashlib.sha256(source.read_bytes()).hexdigest(),optimizedSha256=hashlib.sha256(dest.read_bytes()).hexdigest(),clipInstructions=kills,valid=valid.returncode==0,command=cmd))
passed=all(row['valid'] and (row['clipInstructions']==0 if row['covered'] else row['clipInstructions']==1) for row in rows)
(out/'results.json').write_text(json.dumps(dict(status='passed' if passed else 'failed',scope='Private offline specialization of actual production words; production shader files unchanged by this diagnostic; driver early-depth behavior requires actual capture',rows=rows),indent=2));print(json.dumps(rows,indent=2));assert passed
