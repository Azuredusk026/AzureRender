from pathlib import Path
import sys,json,traceback,collections
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'opaque-coverage-specialization/gpu-events';state=json.loads((out/'state.json').read_text());report=dict(status='starting',sourceBase='8c5118a',captureSha256=state['captureSha256'],renderdocVersion=str(rd.GetVersionString()));capture=None;controller=None
try:
    sys.path.insert(0,str(root/'tools'));from native_render.renderdoc_profile import profile_capture
    result=profile_capture(rd,Path(state['capture']),out/'events',shader_event_limit=128)
    report.update(status='timed',sumEventMs=result['sumEventMs'],events=result['events']);(out/'profile-state.json').write_text(json.dumps(report,indent=2))
    capture=rd.OpenCaptureFile();assert capture.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
    status,controller=capture.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
    structured=controller.GetStructuredFile();actions={};parents={}
    def walk(items,parent=None):
        for action in items:actions[action.eventId]=action;parents[action.eventId]=parent;walk(action.children,action.eventId)
    walk(controller.GetRootActions());rows={}
    for value in controller.FetchCounters([rd.GPUCounter.PSInvocations,rd.GPUCounter.SamplesPassed]):
        action=actions[value.eventId];row=rows.setdefault(value.eventId,dict(event=int(value.eventId),parent=parents[value.eventId],hasChildren=bool(action.children),name=action.GetName(structured),shader='uninspected'))
        row['ps' if value.counter==rd.GPUCounter.PSInvocations else 'samplesPassed']=int(value.value.u64)
    times={row['event']:row for row in result['measurements']}
    selected={row['event'] for row in sorted((v for v in rows.values() if not v['hasChildren']),key=lambda x:x.get('ps',0),reverse=True)[:96]}
    selected.update(row['event'] for row in sorted(result['measurements'],key=lambda x:x['seconds'],reverse=True)[:128] if row['kind']=='draw')
    shaders={}
    for event in sorted(selected):
        if event not in rows:continue
        controller.SetFrameEvent(event,True);pipeline=controller.GetPipelineState();sid=str(pipeline.GetShader(rd.ShaderStage.Pixel));row=rows[event];row['shader']=sid
        if sid not in shaders:
            r=pipeline.GetShaderReflection(rd.ShaderStage.Pixel);shaders[sid]=dict(files=[f.filename for f in r.debugInfo.files] if r else [],hasFragmentShader=bool(r))
        row.update(depthTarget=str(pipeline.GetDepthTarget().resource),colorTargets=[str(t.resource) for t in pipeline.GetOutputTargets()])
    groups=collections.defaultdict(lambda:dict(events=0,ps=0,samplesPassed=0,milliseconds=0.0))
    for event,row in rows.items():
        row['milliseconds']=times.get(event,{}).get('seconds',0)*1000
        if not row['hasChildren']:
            key=json.dumps([row['shader'],row.get('depthTarget','uninspected'),row.get('colorTargets',[])])
            g=groups[key];g['events']+=1;g['ps']+=row.get('ps',0);g['samplesPassed']+=row.get('samplesPassed',0);g['milliseconds']+=row['milliseconds']
    chunks=collections.Counter(str(c.name) for c in structured.chunks)
    report.update(status='profiled',scope='Replay durations and generic counters; leaf-only pixel totals; shader/target inspection limited to top PS and timing events; native P95 acceptance is separate',leafPS=sum(v.get('ps',0) for v in rows.values() if not v['hasChildren']),leafSamplesPassed=sum(v.get('samplesPassed',0) for v in rows.values() if not v['hasChildren']),pixelEvents=list(rows.values()),targetGroups=[dict(key=json.loads(k),**v) for k,v in groups.items()],shaders=shaders,apiCounts={k:v for k,v in chunks.items() if any(x in k for x in ['BindPipeline','BindDescriptorSets','DrawIndexed','ExecuteCommands'])})
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
    if controller:controller.Shutdown()
    if capture:capture.Shutdown()
    (out/'profile-state.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='profiled' else 1)
