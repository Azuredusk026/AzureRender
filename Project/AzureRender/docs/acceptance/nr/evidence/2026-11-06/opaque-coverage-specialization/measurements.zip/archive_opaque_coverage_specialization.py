from pathlib import Path
import json,hashlib,zipfile,sys,struct,io,xml.etree.ElementTree as ET
from PIL import Image
import numpy as np
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;task=a/'opaque-coverage-specialization';out=root/'docs/acceptance/nr/evidence/2026-11-06/opaque-coverage-specialization';out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
isolated=json.loads((task/'isolated-candidate/manifest.json').read_text());assert inputs(root)==isolated['sourceInputs']
for name,value in isolated['sourceFiles'].items():assert digest(root/name)==value
for name,value in isolated['copiedRuntimeFiles'].items():assert digest(task/'isolated-candidate'/name)==value
image=json.loads((task/'image/results.json').read_text());timing=json.loads((task/'performance/results.json').read_text());gpu=json.loads((task/'gpu/gpu-checks.json').read_text());spirv=json.loads((task/'spirv-final/results.json').read_text());profile=json.loads((task/'gpu-events/profile-state.json').read_text());materials=json.loads((task/'gpu-events/material-state.json').read_text())
assert image['status']=='failed' and [r['frozen']['changedPixels'] for r in image['frames']]==[0,0,9,7] and all(r['frozen']['maxByteDifference']<=1 for r in image['frames'])
assert image['zeroAllocator'] and image['validationLogClean'] and spirv['status']=='passed' and gpu['status']=='passed' and len(gpu['rows'])==4 and all(r['exitCode']==0 and len(r['actualChecks'])==6 for r in gpu['rows'])
selection=json.loads((task/'selected.json').read_text());checks={};shader_changes={}
for tag in ['release','debug']:
    proof=json.loads((root/f'build/ninja-msvc-{tag}/build-provenance.json').read_text());verify(root,proof)
    cases=list(ET.parse(task/f'engine-{tag}-checks.xml').iter('testcase'));assert len(cases)==32 and all(not c.findall('failure') and not c.findall('skipped') for c in cases)
    assert sorted(c.attrib['name'] for c in cases)==sorted(selection['names'])
    checks[tag]=dict(cpuChecks=32,build=json.loads((task/f'engine-{tag}-build.json').read_text()),tests=json.loads((task/f'engine-{tag}-checks.json').read_text()))
    shader_changes[tag]=json.loads((task/f'engine-{tag}-shader-changes.json').read_text());assert shader_changes[tag]['count']==388
assert shader_changes['release']['changed']==shader_changes['debug']['changed']
canonical=root/'docs/acceptance/nr/evidence/2026-11-05/runtime-node-identity/measurements.zip';original=json.loads((a/'covered-depth-prefill/image/results.json').read_text())['frames'];patches=json.loads((task/'image/differences.json').read_text());rgb=[]
with zipfile.ZipFile(canonical) as z:
    pngs={hashlib.sha256(z.read(n)).hexdigest():n for n in z.namelist() if n.endswith('.png')}
    for frame,patch,base in zip(image['frames'],patches,original):
        assert frame['frame']==patch['frame']==base['frame'];data=z.read(pngs[base['sha256']]);array=np.array(Image.open(io.BytesIO(data)).convert('RGB'));before=hashlib.sha256(array.tobytes()).hexdigest()
        for pixel in patch['pixels']:
            assert array[pixel['y'],pixel['x']].tolist()==pixel['before'];array[pixel['y'],pixel['x']]=pixel['after']
        actual=np.array(Image.open(task/'image/frames'/frame['frame']).convert('RGB'));assert np.array_equal(array,actual)
        rgb.append(dict(frame=frame['frame'],basePngSha256=base['sha256'],baseCanonicalMember=pngs[base['sha256']],baseRgbSha256=before,candidateRgbSha256=hashlib.sha256(actual.tobytes()).hexdigest(),changedPixels=len(patch['pixels']),allRgbBytesLosslesslyReconstructed=True))
(task/'image/rgb-patch-proof.json').write_text(json.dumps(dict(status='passed',scope='Lossless full RGB reconstruction from canonical PNG plus all actual changed pixel values; candidate PNG compression bytes remain retained at original build run',frames=rgb),indent=2))
baseline=json.loads((a/'current-gpu-events/profile-state.json').read_text());assert profile['status']=='profiled' and materials['status']=='inspected' and profile['leafSamplesPassed']==baseline['leafSamplesPassed']==64679603
old=next(r for r in json.loads((a/'current-gpu-events/material-state.json').read_text())['rows'] if r['event']==16036);new=next(r for r in materials['rows'] if r['event']==16036)
assert old['material']==new['material'] and old['pixelCounters']['samplesPassed']==new['pixelCounters']['samplesPassed']==93542
assert old['pixelCounters']['ps']==371593 and new['pixelCounters']['ps']==93542
data=bytes.fromhex(new['specializationDataHex']);specialization={f['name']:struct.unpack_from('<I',data,f['byteOffset'])[0] for b in new['specializationReflection'] for f in b['variables']};assert specialization['azureFullyCoveredNode']==1
files=[p for p in task.rglob('*') if p.is_file() and p.suffix.lower() in {'.json','.log','.csv','.cpp','.hpp','.inc','.frag','.diff','.xml','.txt','.spvasm','.spv'} and not p.is_relative_to(task/'isolated-candidate/runtime-release')]
scripts=['validate_opaque_coverage_specialization.py','run_opaque_coverage_specialization_gpu_checks.py','check_opaque_coverage_spirv.py','capture_opaque_coverage_specialization.py','measure_opaque_coverage_specialization.py','capture_opaque_coverage_gpu_events.py','launch_opaque_coverage_gpu_events.py','profile_opaque_coverage_gpu_events.py','launch_profile_opaque_coverage_gpu_events.py','inspect_opaque_coverage_materials.py','launch_inspect_opaque_coverage_materials.py','archive_opaque_coverage_specialization.py'];files +=[a/name for name in scripts];members={}
with zipfile.ZipFile(out/'measurements.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        name=p.relative_to(a).as_posix();data=p.read_bytes();assert name not in members;members[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
with zipfile.ZipFile(out/'measurements.zip') as z:assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==members
receipt=dict(schemaVersion=1,status='isolated-prototype-zero-pixel-gate-failed',productionAdoption=False,sourceBase='8c5118a',buildAndCpu=checks,gpu=gpu,shaderChangesPerConfiguration=388,unaffectedShadersPerConfiguration=147,offlineSpirv=spirv,nativeImage=image,losslessRgbPatchEvidence=dict(canonicalArchive=canonical.relative_to(root).as_posix(),frames=rgb),nativeTiming=timing,timingBenefitQualified=False,fragmentWork=dict(baselineCapture='docs/acceptance/nr/evidence/2026-11-06/current-gpu-events/results.json',baselinePS=baseline['leafPS'],candidatePS=profile['leafPS'],samplesPassed=profile['leafSamplesPassed'],scope='Observed leaf invocation counts in actual captures; helper counts and replay timing are separate from native P95',example=dict(event=16036,baselinePS=371593,candidatePS=93542,samplesPassed=93542,material=new['material'],specialization=specialization)),candidateCapture=json.loads((task/'gpu-events/capture-result.json').read_text()),candidateProfile=json.loads((task/'gpu-events/profile-result.json').read_text()),retainedCandidateManifest=isolated,nextProbe=json.loads((task/'early-depth-probe/results.json').read_text()),fullVisualAcceptance='failed-user-review',fullPerformance='failed',archiveMembers=members,archiveSha256=digest(out/'measurements.zip'))
(out/'results.json').write_text(json.dumps(receipt,indent=2)+'\n');(out/'.gitattributes').write_text('* -text -whitespace\n');print(json.dumps(dict(members=len(members),archiveBytes=(out/'measurements.zip').stat().st_size,visualPixels=[0,0,9,7],cpuP95=timing['cpu']['p95'],gpuP95=timing['gpu']['frameMs']['p95'],environmentPassed=timing['environmentPassed'],productionAdoption=False),indent=2))
