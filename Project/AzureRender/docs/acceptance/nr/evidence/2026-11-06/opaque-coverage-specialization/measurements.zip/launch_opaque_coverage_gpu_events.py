from pathlib import Path
import subprocess,json,sys,time,os
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'opaque-coverage-specialization/gpu-events';out.mkdir(exist_ok=True);sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from run_playable_performance import freeze_products
from gpu_environment import snapshot
source=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
verify(root,json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text()))
project=json.loads((a/'covered-depth-prefill/image/frozen-inputs.json').read_text())['project'];assert all(digest(Path(p))==v for p,v in project.items())
q=Path('D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe');identity={str(p):digest(p) for p in [q,q.parent/'renderdoc.dll',q.parent/'python38.dll']}
(out/'frozen-inputs.json').write_text(json.dumps(dict(source=source,products=products,project=project,tool=identity),indent=2));(out/'environment.json').write_text(json.dumps(snapshot(),indent=2))
cmd=[str(q),'--python',str(a/'capture_opaque_coverage_gpu_events.py')];si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'capture-driver.log').open('wb') as log:
    child=subprocess.Popen(cmd,cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si)
    try:code=child.wait(timeout=660)
    except subprocess.TimeoutExpired:
        state=json.loads((out/'state.json').read_text()) if (out/'state.json').exists() else {}
        if state.get('status')=='capturing' and state.get('pid'):subprocess.run(['taskkill','/PID',str(state['pid']),'/T','/F'],capture_output=True)
        child.kill();child.wait();raise
state=json.loads((out/'state.json').read_text());assert code==0 and state['status']=='captured',state
assert inputs(root)==source and all(digest(Path(p))==v for p,v in products.items()) and all(digest(Path(p))==v for p,v in project.items())
(out/'capture-result.json').write_text(json.dumps(dict(status='captured',command=cmd,exitCode=code,seconds=time.monotonic()-start,sourceUnchanged=True,productsUnchanged=True,projectBytesUnchanged=True,capture=state),indent=2));print(json.dumps(state),flush=True)
