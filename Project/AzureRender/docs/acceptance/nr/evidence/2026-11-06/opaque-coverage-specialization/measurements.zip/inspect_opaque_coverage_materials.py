from pathlib import Path
import json,sys,traceback,struct,hashlib
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'opaque-coverage-specialization/gpu-events';state=json.loads((out/'state.json').read_text());capture=rd.OpenCaptureFile();controller=None;report=dict(status='starting',captureSha256=state['captureSha256'])
try:
    assert capture.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
    status,controller=capture.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
    profile=json.loads((out/'events/profile.json').read_text());pixels={v['event']:v for v in json.loads((out/'profile-state.json').read_text())['pixelEvents']}
    selected=sorted((v for v in profile['measurements'] if v['kind']=='draw'),key=lambda v:v['seconds'],reverse=True)[:32];selected += [v for v in profile['measurements'] if v['event'] in {23277,23276,16036,22830,22805} and v not in selected];rows=[]
    for item in selected:
        controller.SetFrameEvent(item['event'],True);vk=controller.GetVulkanPipelineState();pipeline=controller.GetPipelineState();fragment=vk.fragmentShader;push=bytes(vk.pushconsts)
        row=dict(event=item['event'],milliseconds=item['seconds']*1000,shader=str(fragment.resourceId),pipeline=str(vk.graphics.pipelineResourceId),specializationIds=list(fragment.specializationIds),specializationDataHex=bytes(fragment.specializationData).hex(),pushConstantsHex=push.hex(),vertexBuffers=[str(v.resourceId) for v in vk.vertexInput.vertexBuffers],indexBuffer=str(vk.inputAssembly.indexBuffer.resourceId),pixelCounters=pixels.get(item['event']))
        if len(push)>=144:
            row['material']=dict(alphaMode=struct.unpack_from('<I',push,4)[0],materialClass=struct.unpack_from('<I',push,112)[0],features=struct.unpack_from('<I',push,116)[0],profileVersion=struct.unpack_from('<I',push,120)[0],textureBase=struct.unpack_from('<I',push,136)[0],nodeOpacity=struct.unpack_from('<f',push,140)[0])
        r=pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
        row['specializationReflection']=[dict(name=b.name,variables=[dict(name=v.name,byteOffset=v.byteOffset) for v in b.variables]) for b in r.constantBlocks if b.compileConstants] if r else []
        rows.append(row)
    report.update(status='inspected',scope='Top32 candidate replay draw events plus five frozen baseline identifiers when present; actual specialization data and push constants; shader identity alone does not distinguish pipeline specialization',rows=rows)
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
    if controller:controller.Shutdown()
    capture.Shutdown();(out/'material-state.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='inspected' else 1)
