from pathlib import Path
import json,hashlib,zipfile,subprocess,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;task=a/'loaded-bind-pose'
out=root/'docs/acceptance/nr/evidence/2026-11-06/loaded-bind-pose';out.mkdir(parents=True,exist_ok=True)
image=json.loads((task/'image/results.json').read_text());timing=json.loads((task/'performance/results.json').read_text());gpu=json.loads((task/'gpu/gpu-checks.json').read_text());work=json.loads((task/'image/bind-pose-workload.json').read_text())
assert image['status']=='passed' and image['zeroAllocator'] and len(image['frames'])==4
assert gpu['status']=='passed' and len(gpu['rows'])==4 and all(len(row['actualChecks'])==3 and row['exitCode']==0 for row in gpu['rows'])
assert work==dict(bindPoseCacheEntries=374,bindPoseCachedCopies=860)
assert "key 'bindPoseCacheEntries' not found" in (task/'reuse-red.log').read_text(errors='replace')
assert int((task/'reuse-red-exit.txt').read_text())!=0
canonical=root/'docs/acceptance/nr/evidence/2026-11-05/runtime-node-identity/measurements.zip'
with zipfile.ZipFile(canonical) as z:
 images={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.endswith('.png')}
 assert all(row['sha256'] in images for row in image['frames'])
snapshot=task/'source';snapshot.mkdir(exist_ok=True)
for name in ['CMakeLists.txt','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','tests/StaticSkinningRecordingTests.cpp']:
 p=snapshot/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/name).read_bytes())
(snapshot/'production.diff').write_bytes(subprocess.check_output(['git','diff','--','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','tests/StaticSkinningRecordingTests.cpp'],cwd=root))
selection=json.loads((task/'selected.json').read_text());build={}
for tag in ['release','debug']:
 checks=json.loads((task/f'engine-{tag}-checks.json').read_text());assert checks['exitCode']==0
 cases=list(ET.parse(task/f'engine-{tag}-checks.xml').iter('testcase'));assert len(cases)==19 and all(not c.findall('failure') and not c.findall('skipped') for c in cases)
 assert sorted(c.attrib['name'] for c in cases)==sorted(selection['names'])
 build[tag]=dict(build=json.loads((task/f'engine-{tag}-build.json').read_text()),checks=checks)
files=[p for p in task.rglob('*') if p.is_file() and p.suffix.lower() in {'.json','.log','.csv','.cpp','.hpp','.diff','.xml','.txt'}]
files += [a/'prepare_loaded_bind_pose_checks.py',a/'validate_loaded_bind_pose.py',a/'capture_loaded_bind_pose.py',a/'measure_loaded_bind_pose.py',a/'run_loaded_bind_pose_gpu_checks.py',Path(__file__)]
members={}
with zipfile.ZipFile(out/'measurements.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  name=p.relative_to(a).as_posix();data=p.read_bytes();assert name not in members;members[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
with zipfile.ZipFile(out/'measurements.zip') as z:assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==members
receipt=dict(schemaVersion=1,status='implemented-compatible-loaded-bind-pose-reuse-full-frame-budgets-failed',sourceBase='121011c',productionAdoption=True,buildAndCpu=build,gpuMechanisms=gpu,nativeImage=image,bindPoseWorkload=work,nativeTiming=timing,timingBenefitQualified=False,fullVisualAcceptance='failed-user-review',fullPerformance='failed',canonicalPngArchive=canonical.relative_to(root).as_posix(),canonicalPngArchiveSha256=hashlib.sha256(canonical.read_bytes()).hexdigest(),archiveMembers=members,archiveSha256=hashlib.sha256((out/'measurements.zip').read_bytes()).hexdigest())
(out/'results.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');(out/'.gitattributes').write_text('* -text -whitespace\n')
print(json.dumps(dict(members=len(members),archiveBytes=(out/'measurements.zip').stat().st_size,cpuP95=timing['cpu']['p95'],gpuP95=timing['gpu']['frameMs']['p95'],environmentPassed=timing['environmentPassed'],bindPoseWorkload=work),indent=2))
