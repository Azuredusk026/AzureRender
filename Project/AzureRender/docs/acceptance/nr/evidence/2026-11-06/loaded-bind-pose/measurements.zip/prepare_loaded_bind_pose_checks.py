from pathlib import Path
import json
a=Path(__file__).resolve().parent;out=a/'loaded-bind-pose'
selection=json.loads((a/'stable-instance-grouping/selected.json').read_text())
for name,target in [('AzureRender.AnimationPose','AzureAnimationPoseTests'),('AzureRender.ExpressionPose','AzureExpressionPoseTests'),('AzureAssets.MorphTargets','AzureMorphTargetTests'),('AzureRender.MotionPoseData','AzureMotionPoseDataTests')]:
 selection['names'].append(name);selection['targets'].append(target)
(out/'selected.json').write_text(json.dumps(selection,indent=2))
s=(a/'validate_stable_instance_grouping.py').read_text().replace("out=a/'stable-instance-grouping'","out=a/'loaded-bind-pose'")
(a/'validate_loaded_bind_pose.py').write_text(s)
s=(a/'capture_stable_instance_grouping.py').read_text().replace("out=a/'stable-instance-grouping/image'","out=a/'loaded-bind-pose/image'").replace("'sourceBase':'389ab83'","'sourceBase':'121011c'").replace('Stable scene-node grouping candidate','Loaded immutable bind-pose reuse candidate')
s+='\nbind_pose={key:manifest[key] for key in ["bindPoseCacheEntries","bindPoseCachedCopies"]}\nassert bind_pose["bindPoseCacheEntries"]>0 and bind_pose["bindPoseCachedCopies"]>0\n(out/"bind-pose-workload.json").write_text(json.dumps(bind_pose,indent=2))\nprint(json.dumps(bind_pose),flush=True)\n'
(a/'capture_loaded_bind_pose.py').write_text(s)
s=(a/'measure_stable_instance_grouping.py').read_text().replace("out=a/'stable-instance-grouping/performance'","out=a/'loaded-bind-pose/performance'").replace("sourceBase='389ab83'","sourceBase='121011c'").replace('Stable scene-node grouping candidate-only','Loaded immutable bind-pose candidate-only')
(a/'measure_loaded_bind_pose.py').write_text(s)
s=(a/'run_static_skinning_gpu_checks.py').read_text().replace("out=a/'static-skinning-output/gpu'","out=a/'loaded-bind-pose/gpu'")
(a/'run_loaded_bind_pose_gpu_checks.py').write_text(s)
