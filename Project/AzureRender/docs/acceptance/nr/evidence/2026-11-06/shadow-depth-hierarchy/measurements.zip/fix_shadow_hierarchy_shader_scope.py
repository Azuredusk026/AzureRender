from pathlib import Path
import subprocess,json,re,hashlib
a=Path(__file__).resolve().parent;root=a.parents[2];out=a/'shadow-depth-hierarchy'
cmd=['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe','-C',str(root/'build/ninja-msvc-release'),'-t','commands']
rows=subprocess.check_output(cmd,text=True).splitlines();mapping={}
for row in rows:
 if '/shaders/mesh.frag' in row.replace('\\','/'):
  match=re.search(r' -o ([^\s"]+\.spv)',row);assert match,row
  mapping[Path(match[1]).name]=row
assert len(mapping)==388
mapping['shadow_bounds.comp.spv']=next(row for row in rows if '/shaders/shadow_bounds.comp' in row.replace('\\','/'))
(out/'shader-source-scope.json').write_text(json.dumps(dict(sourceBase='9a9d9aa',sourceFiles=['shaders/mesh.frag','shaders/shadow_bounds.comp','shaders/shadow_bounds_layout.glsl'],allowedOutputCount=len(mapping),commands=mapping,scope='Exact Ninja producer commands identify all variants of the changed source; unrelated shader outputs retain baseline bytes'),indent=2))
p=a/'validate_shadow_hierarchy.py';s=p.read_text();old="assert all(name=='shadow_bounds.comp.spv' or (name.startswith('mesh') and name.endswith('.frag.spv')) for name in changed),sorted(changed)"
assert old in s
s=s.replace(old,"allowed=set(json.loads((out/'shader-source-scope.json').read_text())['commands']);assert set(changed)<=allowed,sorted(set(changed)-allowed)")
p.write_text(s)
print('Changed-source output scope:',len(mapping),'exact compiler commands; unrelated outputs keep strict baseline byte checks')
