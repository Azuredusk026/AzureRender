from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET,sys
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;task=a/'shadow-depth-hierarchy'
out=root/'docs/acceptance/nr/evidence/2026-11-06/shadow-depth-hierarchy';out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify,digest
image=json.loads((task/'image/results.json').read_text());timing=json.loads((task/'performance/results.json').read_text());restore=json.loads((task/'restore-source.json').read_text())
assert image['status']=='passed' and image['zeroAllocator'] and len(image['frames'])==4 and image['intentionalShaderChangeCount']==385
assert inputs(root)==restore['restoredSource'] and restore['allProductionSourceInputsExactlyPreCandidate'] and restore['restoredTestsMatchHeadAfterEolNormalization']
canonical=root/'docs/acceptance/nr/evidence/2026-11-05/runtime-node-identity/measurements.zip'
with zipfile.ZipFile(canonical) as z:
 pngs={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.endswith('.png')}
 assert all(row['sha256'] in pngs for row in image['frames'])
checks={};gpu={}
for scope in ['candidate','restored']:
 folder=task if scope=='candidate' else task/'restored';checks[scope]={}
 for tag in ['release','debug']:
  cases=list(ET.parse(folder/f'engine-{tag}-checks.xml').iter('testcase'))
  assert len(cases)==20 and all(not c.findall('failure') and not c.findall('skipped') for c in cases)
  log=json.loads((folder/f'engine-{tag}-checks.json').read_text());assert log['exitCode']==0
  proof=json.loads((folder/f'engine-{tag}-build.json').read_text());assert proof['status']=='passed'
  checks[scope][tag]=dict(count=20,exitCode=log['exitCode'],buildSeconds=proof['seconds'],checksSeconds=log['seconds'],productCount=proof['productCount'])
  if scope=='restored':
   assert proof['productionShaders535ByteIdentical'];verify(root,json.loads((root/f'build/ninja-msvc-{tag}/build-provenance.json').read_text()))
 gpu[scope]=json.loads((folder/'gpu/gpu-checks.json').read_text());assert gpu[scope]['status']=='passed' and len(gpu[scope]['rows'])==4
 assert all(row['exitCode']==0 and len(row['actualChecks'])==6 for row in gpu[scope]['rows'])
shader_changes={tag:json.loads((task/f'engine-{tag}-shader-changes.json').read_text()) for tag in ['release','debug']}
assert shader_changes['release']['changed']==shader_changes['debug']['changed'] and shader_changes['release']['count']==385
isolated=task/'isolated-candidate/runtime-release'
preserved=json.loads((task/'isolated-candidate/runtime-products.json').read_text());assert all(digest(isolated/name)==value for name,value in preserved.items())
files=[p for p in task.rglob('*') if p.is_file() and 'runtime-release' not in p.relative_to(task).parts and p.suffix.lower() in {'.json','.log','.csv','.cpp','.hpp','.glsl','.comp','.frag','.diff','.xml','.txt'}]
files += [a/name for name in ['prepare_shadow_hierarchy_checks.py','fix_shadow_hierarchy_shader_scope.py','validate_shadow_hierarchy.py','prepare_shadow_hierarchy_native.py','capture_shadow_hierarchy.py','measure_shadow_hierarchy.py','run_shadow_hierarchy_gpu_checks.py','isolate_shadow_hierarchy.py','resume_shadow_hierarchy_restore.py','prepare_shadow_hierarchy_restored.py','validate_shadow_hierarchy_restored.py','run_shadow_hierarchy_restored_gpu.py','archive_shadow_hierarchy.py']]
members={}
with zipfile.ZipFile(out/'measurements.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  name=p.relative_to(a).as_posix();data=p.read_bytes();assert name not in members;members[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
with zipfile.ZipFile(out/'measurements.zip') as z:assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==members
receipt=dict(schemaVersion=1,status='isolated-candidate-production-source-and-shaders-restored',sourceBase='9a9d9aa',productionAdoption=False,checks=checks,gpuMechanisms=gpu,nativeImage=image,nativeTiming=timing,timingBenefitQualified=False,shaderChanges=dict(candidateChangedCount=385,unaffectedCount=150,changedBytesMatchAcrossConfigurations=True,producerCommandCount=389),restoration=dict(runtimeInputsExactlyPreCandidate=True,testTextMatchesHeadAfterEolNormalization=True,productionShaders535ExactlyPreCandidateEachConfiguration=True,restoredOriginalGpuChecks=24,scope='Restored runtime source and shader bytes plus fresh CPU/GPU checks; native image evidence for identical original source is cited from loaded-bind-pose, no new restored native frames claimed'),primarySource=json.loads((task/'research/source.json').read_text()),fullVisualAcceptance='failed-user-review',fullPerformance='failed',canonicalPngArchive=canonical.relative_to(root).as_posix(),archiveMembers=members,archiveSha256=digest(out/'measurements.zip'))
(out/'results.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');(out/'.gitattributes').write_text('* -text -whitespace\n')
print(json.dumps(dict(members=len(members),archiveBytes=(out/'measurements.zip').stat().st_size,status=receipt['status'],cpuChecksPerConfigurationPerScope=20,candidateGpuChecks=24,restoredGpuChecks=24),indent=2))
