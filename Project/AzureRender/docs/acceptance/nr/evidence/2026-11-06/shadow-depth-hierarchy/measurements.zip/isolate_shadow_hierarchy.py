from pathlib import Path
import json,hashlib,subprocess,shutil,sys
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;out=a/'shadow-depth-hierarchy';isolated=out/'isolated-candidate';isolated.mkdir(exist_ok=True)
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
names=['CMakeLists.txt','src/render/ShadowTileBounds.hpp','shaders/mesh.frag','shaders/shadow_bounds.comp','shaders/shadow_bounds_layout.glsl','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp']
candidate=inputs(root)
for tag in ['release','debug']:
 m=json.loads((root/f'build/ninja-msvc-{tag}/build-provenance.json').read_text());verify(root,m)
 shutil.copy2(root/f'build/ninja-msvc-{tag}/build-provenance.json',isolated/f'candidate-{tag}-provenance.json')
for name in names:
 p=isolated/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,p)
(isolated/'candidate.diff').write_bytes(subprocess.check_output(['git','diff','--',*names],cwd=root))
products=isolated/'runtime-release';products.mkdir(exist_ok=True);shutil.copy2(root/'build/ninja-msvc-release/AzurePlayer.exe',products/'AzurePlayer.exe');shutil.copytree(root/'build/ninja-msvc-release/shaders',products/'shaders',dirs_exist_ok=True)
(isolated/'runtime-products.json').write_text(json.dumps({p.relative_to(products).as_posix():digest(p) for p in products.rglob('*') if p.is_file()},indent=2))
baseline=json.loads((a/'loaded-bind-pose/performance/frozen-inputs.json').read_text())['source']
restored={}
for name in names:
 p=root/name
 if name=='shaders/shadow_bounds_layout.glsl':
  assert name not in baseline
  assert p.resolve().is_relative_to(root.resolve()) and p.parent.resolve()==(root/'shaders').resolve()
  p.unlink();continue
 data=subprocess.check_output(['git','show','HEAD:Project/AzureRender/'+name],cwd=root)
 target=baseline[name];variants=[data,data.replace(b'\r\n',b'\n'),data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')]
 match=next((v for v in variants if hashlib.sha256(v).hexdigest()==target),None)
 assert match is not None,(name,target)
 p.write_bytes(match);restored[name]=digest(p)
assert inputs(root)==baseline,'Restored production source differs from pre-candidate accepted source'
(out/'restore-source.json').write_text(json.dumps(dict(status='restored-exact-pre-candidate-source',sourceBase='9a9d9aa',candidateSource=candidate,restoredSource=baseline,restoredOwnedPaths=restored,removedOwnedPath='shaders/shadow_bounds_layout.glsl',allProductionSourceInputsExactlyPreCandidate=True,reason='20CPU/config+24GPU+4frozenRGB exact; candidate-only GPU32.21058ms mean is unqualified under thermal/headroom failures; no production adoption'),indent=2))
print('Candidate source/products preserved; every production input matches pre-candidate raw bytes')
