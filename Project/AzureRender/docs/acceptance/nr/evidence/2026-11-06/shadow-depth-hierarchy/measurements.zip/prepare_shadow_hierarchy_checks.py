from pathlib import Path
import json
a=Path(__file__).resolve().parent;out=a/'shadow-depth-hierarchy'
selection=json.loads((a/'loaded-bind-pose/selected.json').read_text())
selection['names'].append('AzureRender.ObjectShadowAtlas');selection['targets'].append('AzureObjectShadowAtlasTests')
selection['targets'] += ['AzureShadowTileBoundsGpuTests','AzureShadowFilteringGpuTests','AzureObjectShadowFilteringGpuTests']
(out/'selected.json').write_text(json.dumps(selection,indent=2))
s=(a/'validate_loaded_bind_pose.py').read_text().replace("out=a/'loaded-bind-pose'","out=a/'shadow-depth-hierarchy'")
s=s.replace('assert values==base and len(values)==535',"assert set(values)==set(base) and len(values)==535\n changed={name:dict(before=base[name],after=values[name]) for name in values if values[name]!=base[name]}\n assert 'shadow_bounds.comp.spv' in changed and 'mesh.frag.spv' in changed\n assert all(name=='shadow_bounds.comp.spv' or (name.startswith('mesh') and name.endswith('.frag.spv')) for name in changed),sorted(changed)\n (out/('engine-'+tag+'-shader-changes.json')).write_text(json.dumps(dict(sourceBase='9a9d9aa',count=len(changed),changed=changed,unchangedCount=535-len(changed)),indent=2))")
s=s.replace('productionShaders535ByteIdentical=True','productionShaderCount=535,shaderChanges=changed,unaffectedShadersByteIdentical=True')
(a/'validate_shadow_hierarchy.py').write_text(s)
