#ifndef AZURE_SHADOW_BOUNDS_LAYOUT_GLSL
#define AZURE_SHADOW_BOUNDS_LAYOUT_GLSL
uint shadowFineBoundsCount(ivec2 extent) {
    ivec2 size=extent/8;return uint(size.x*size.y);
}
ivec2 shadowCoarseBoundsSize(ivec2 extent) {return (extent+31)/32;}
uint shadowDepthBoundsCount(ivec2 extent) {
    ivec2 size=shadowCoarseBoundsSize(extent);
    return shadowFineBoundsCount(extent)+uint(size.x*size.y);
}
#endif
