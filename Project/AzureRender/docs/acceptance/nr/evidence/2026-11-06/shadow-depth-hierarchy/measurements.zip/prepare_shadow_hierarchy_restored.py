from pathlib import Path
import shutil
a=Path(__file__).resolve().parent;out=a/'shadow-depth-hierarchy/restored';out.mkdir(exist_ok=True)
shutil.copy2(a/'shadow-depth-hierarchy/selected.json',out/'selected.json')
s=(a/'validate_loaded_bind_pose.py').read_text().replace("out=a/'loaded-bind-pose'","out=a/'shadow-depth-hierarchy/restored'")
(a/'validate_shadow_hierarchy_restored.py').write_text(s)
s=(a/'run_shadow_hierarchy_gpu_checks.py').read_text().replace("out=a/'shadow-depth-hierarchy/gpu'","out=a/'shadow-depth-hierarchy/restored/gpu'")
s=s.replace('fine/coarse shadow extrema, partial tiles, original PCSS/object math included','restored original one-level depth bounds and PCSS/object math included')
(a/'run_shadow_hierarchy_restored_gpu.py').write_text(s)
