from pathlib import Path
import json,hashlib,subprocess,sys,tempfile,os
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;out=a/'shadow-depth-hierarchy';isolated=out/'isolated-candidate'
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
candidate=json.loads((isolated/'candidate-release-provenance.json').read_text())['source']
baseline=json.loads((a/'loaded-bind-pose/performance/frozen-inputs.json').read_text())['source']
candidate_tests=json.loads((out/'candidate-source-hashes.json').read_text())
names=['CMakeLists.txt','src/render/ShadowTileBounds.hpp','shaders/mesh.frag','shaders/shadow_bounds.comp','shaders/shadow_bounds_layout.glsl','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp'];restored={}
for name in names:
 p=root/name
 if name=='shaders/shadow_bounds_layout.glsl':
  assert name not in baseline and p.resolve().is_relative_to(root.resolve()) and p.parent.resolve()==(root/'shaders').resolve()
  if p.exists():assert digest(p)==candidate[name];p.unlink()
  continue
 data=subprocess.check_output(['git','show','HEAD:Project/AzureRender/'+name],cwd=root)
 variants=[data,data.replace(b'\r\n',b'\n'),data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')]
 if name in baseline:
  match=next((v for v in variants if hashlib.sha256(v).hexdigest()==baseline[name]),None)
 else:
  assert name.startswith('tests/')
  match=data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
 assert match is not None,name
 expected=hashlib.sha256(match).hexdigest()
 if digest(p)==expected:restored[name]=expected;continue
 assert digest(p)==candidate.get(name,candidate_tests.get(name)),name
 with tempfile.NamedTemporaryFile(dir=p.parent,prefix='.shadow-depth-restore-',suffix='.tmp',delete=False) as f:
  temp=Path(f.name);f.write(match)
 assert temp.resolve().parent==p.resolve().parent and p.resolve().is_relative_to(root.resolve())
 os.replace(temp,p);restored[name]=digest(p)
assert inputs(root)==baseline,'Restored production source differs from pre-candidate source'
for name in names:
 if name.startswith('tests/'):
  assert (root/name).read_bytes().replace(b'\r\n',b'\n')==subprocess.check_output(['git','show','HEAD:Project/AzureRender/'+name],cwd=root).replace(b'\r\n',b'\n')
(out/'restore-source.json').write_text(json.dumps(dict(status='restored-exact-pre-candidate-source',sourceBase='9a9d9aa',candidateSource=candidate,restoredSource=baseline,restoredOwnedPaths=restored,removedOwnedPath='shaders/shadow_bounds_layout.glsl',allProductionSourceInputsExactlyPreCandidate=True,restoredTestsMatchHeadAfterEolNormalization=True,testScope='Runtime provenance inputs omit tests; candidate test bytes were separately frozen and source snapshots retained. Restored test text is verified against HEAD.',reason='20CPU/config+24GPU+4frozenRGB exact; candidate-only GPU32.21058ms mean unqualified under thermal/headroom failures; no production adoption',recovery='Absolute versus relative source keys corrected; a truncating header open returnedEINVAL, then verified bytes were atomically replaced. Test files are verified separately from runtime provenance inputs.'),indent=2))
print('Every production input matches the pre-candidate raw bytes; candidate preserved separately')
