#include "support/VulkanComputeFixture.hpp"
#include "render/ShadowTileBounds.hpp"
#include "resources/BinaryFile.hpp"
#include <cstring>
#include <cmath>
using namespace azurerender;
void verify(unsigned extent,const char* shader){
    test::VulkanComputeFixture host;auto& backend=*host.backend;
    auto image=host.allocator.createImage2D(extent,extent,VK_FORMAT_D32_SFLOAT,VK_IMAGE_USAGE_TRANSFER_DST_BIT|VK_IMAGE_USAGE_SAMPLED_BIT|VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT);
    auto staging=host.allocator.createBuffer(extent*extent*sizeof(float),VK_BUFFER_USAGE_TRANSFER_SRC_BIT,true);
    auto view=backend.createImageView(image.image,VK_FORMAT_D32_SFLOAT,VK_IMAGE_ASPECT_DEPTH_BIT,1);
    rhi::SamplerDesc settings;settings.filter=VK_FILTER_NEAREST;auto sampler=backend.createSampler(settings);
    auto cleanup=std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*){backend.destroySampler(sampler);backend.destroyImageView(view);host.allocator.destroyBuffer(staging);host.allocator.destroyImage(image);});
    std::vector<float> values(extent*extent);
    for(unsigned y=0;y<extent;++y)for(unsigned x=0;x<extent;++x)values[y*extent+x]=y<extent/2?(x<extent/2?.9F:.2F):1.F;
    if(extent>9)values[7*extent+9]=.1F; // One texel must survive conservative reduction.
    if(extent>47)values[33*extent+47]=.05F;
    std::memcpy(staging.mapped,values.data(),values.size()*sizeof(float));host.allocator.flush(staging,0,staging.size);
    ShadowTileBounds bounds(backend);bounds.initialize(readBinaryFile(shader),view,sampler,extent);
    host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer native){
        commands.bufferBarrier({staging.buffer,0,staging.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT});
        commands.imageBarrier({image.image,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,VK_ACCESS_TRANSFER_WRITE_BIT,VK_IMAGE_ASPECT_DEPTH_BIT});
        VkBufferImageCopy copy{};copy.imageSubresource={VK_IMAGE_ASPECT_DEPTH_BIT,0,0,1};copy.imageExtent={extent,extent,1};vkCmdCopyBufferToImage(native,staging.buffer,image.image,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,&copy);
        commands.imageBarrier({image.image,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL,1,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT,VK_IMAGE_ASPECT_DEPTH_BIT});
        bounds.record(commands);
        commands.bufferBarrier({bounds.buffer().buffer,0,bounds.buffer().size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
    });
    host.allocator.invalidate(bounds.buffer(),0,bounds.buffer().size);
    const auto actual=static_cast<const float*>(bounds.buffer().mapped);
    const auto fine=extent/8,coarse=(extent+31)/32;
    if(bounds.fineBoundsBytes()!=fine*fine*2*sizeof(float)||bounds.coarseBoundsOffset()!=bounds.fineBoundsBytes()||bounds.depthBoundsBytes()!=(fine*fine+coarse*coarse)*2*sizeof(float))
        throw std::runtime_error("Fine and coarse depth ranges require explicit contiguous ownership");
    const float expected[]={.9F,.9F,.1F,.9F,.2F,.2F,.2F,.2F,.9F,.9F,.9F,.9F,.2F,.2F,.2F,.2F,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
    if(extent==32)for(unsigned i=0;i<32;++i)if(std::abs(actual[i]-expected[i])>1e-6F)throw std::runtime_error("Depth bounds lose a thin blocker, cross a tile boundary or exclude visible texels");
    for(unsigned edge:{8U,32U}){
        const auto count=(extent+edge-1)/edge;
        const auto offset=edge==8?0:bounds.coarseBoundsOffset()/sizeof(float);
        for(unsigned y=0;y<count;++y)for(unsigned x=0;x<count;++x){
            float minimum=1,maximum=0;
            for(unsigned py=y*edge;py<std::min((y+1)*edge,extent);++py)
                for(unsigned px=x*edge;px<std::min((x+1)*edge,extent);++px){
                    minimum=std::min(minimum,values[py*extent+px]);maximum=std::max(maximum,values[py*extent+px]);
                }
            if(actual[offset+2*(y*count+x)]!=minimum||actual[offset+2*(y*count+x)+1]!=maximum)
                throw std::runtime_error("Fine/coarse bounds differ from exact CPU depth extrema");
        }
    }
    if(host.errors.load())throw std::runtime_error("Vulkan validation errors");
}
int main(int argc,char** argv)try{
    if(argc!=2)throw std::invalid_argument("Expected production shadow bounds shader");
    for(unsigned extent:{8U,24U,32U,64U})verify(extent,argv[1]);
    std::cout<<"Fine/coarse production depth bounds: original thin blocker, exact extrema, multiple coarse tiles and partial edges passed\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
