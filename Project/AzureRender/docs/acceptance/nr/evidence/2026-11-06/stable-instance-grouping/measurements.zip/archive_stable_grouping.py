from pathlib import Path
import json,hashlib,zipfile,re,subprocess
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;task=a/'stable-instance-grouping'
out=root/'docs/acceptance/nr/evidence/2026-11-06/stable-instance-grouping';out.mkdir(parents=True,exist_ok=True)
image=json.loads((task/'image/results.json').read_text());timing=json.loads((task/'performance/results.json').read_text())
assert image['status']=='passed' and image['zeroAllocator'] and len(image['frames'])==4
canonical=root/'docs/acceptance/nr/evidence/2026-11-05/runtime-node-identity/measurements.zip'
with zipfile.ZipFile(canonical) as z:
 images={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.endswith('.png')}
 assert all(row['sha256'] in images for row in image['frames'])
snapshot=task/'source';snapshot.mkdir(exist_ok=True)
for name in ['CMakeLists.txt','src/scenes/CharacterSceneRenderer.cpp','src/scene/SceneNodeGrouping.hpp','tests/SceneNodeGroupingTests.cpp']:
 p=snapshot/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/name).read_bytes())
(snapshot/'production.diff').write_bytes(subprocess.check_output(['git','diff','--','CMakeLists.txt','src/scenes/CharacterSceneRenderer.cpp'],cwd=root))
selection=json.loads((task/'selected.json').read_text());build={};bench={}
import xml.etree.ElementTree as ET
for tag in ['release','debug']:
 checks=json.loads((task/f'engine-{tag}-checks.json').read_text());assert checks['exitCode']==0
 cases=list(ET.parse(task/f'engine-{tag}-checks.xml').iter('testcase'));assert len(cases)==15 and all(not c.findall('failure') and not c.findall('skipped') for c in cases)
 assert sorted(c.attrib['name'] for c in cases)==sorted(selection['names'])
 log=(task/f'engine-{tag}-checks-full.log').read_text(errors='replace');m=re.search(r'referenceMs=([\d.]+) candidateMs=([\d.]+) checksum=(\d+)',log);assert m
 bench[tag]=dict(referenceMs=float(m[1]),candidateMs=float(m[2]),checksum=int(m[3]),nodes=65536,meshes=1024,repetitions=8,scope='Synthetic algorithm timing only, independent output-order oracle, no full-frame causal performance claim')
 build[tag]=dict(build=json.loads((task/f'engine-{tag}-build.json').read_text()),checks=checks)
files=[p for p in task.rglob('*') if p.is_file() and p.suffix.lower() in {'.json','.log','.csv','.cpp','.hpp','.diff','.xml'}]
files += [a/'prepare_stable_grouping_checks.py',a/'validate_stable_instance_grouping.py',a/'capture_stable_instance_grouping.py',a/'measure_stable_instance_grouping.py',Path(__file__)]
files.append(snapshot/'CMakeLists.txt');members={}
with zipfile.ZipFile(out/'measurements.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  name=p.relative_to(a).as_posix();data=p.read_bytes();members[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
with zipfile.ZipFile(out/'measurements.zip') as z:assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==members
receipt=dict(schemaVersion=1,status='implemented-compatible-stable-ordering-full-frame-budgets-failed',sourceBase='389ab83',productionAdoption=True,buildAndCpu=build,syntheticAlgorithmTiming=bench,nativeImage=image,nativeTiming=timing,timingBenefitQualified=False,fullVisualAcceptance='failed-user-review',fullPerformance='failed',canonicalPngArchive=str(canonical.relative_to(root)).replace('\\','/'),canonicalPngArchiveSha256=hashlib.sha256(canonical.read_bytes()).hexdigest(),archiveMembers=members,archiveSha256=hashlib.sha256((out/'measurements.zip').read_bytes()).hexdigest())
(out/'results.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');(out/'.gitattributes').write_text('* -text -whitespace\n')
print(json.dumps(dict(members=len(members),archiveBytes=(out/'measurements.zip').stat().st_size,cpuP95=timing['cpu']['p95'],gpuP95=timing['gpu']['frameMs']['p95'],environmentPassed=timing['environmentPassed'],synthetic=bench),indent=2))
