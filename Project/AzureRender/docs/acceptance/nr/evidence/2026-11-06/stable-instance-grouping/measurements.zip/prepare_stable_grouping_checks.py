from pathlib import Path
import json
a=Path(__file__).resolve().parent
selection=json.loads((a/'static-skinning-output/selected.json').read_text())
selection['names'].append('AzureRender.SceneNodeGrouping');selection['targets'].append('AzureSceneNodeGroupingTests')
(a/'stable-instance-grouping/selected.json').write_text(json.dumps(selection,indent=2))
s=(a/'validate_static_skinning_output.py').read_text().replace("out=a/'static-skinning-output'","out=a/'stable-instance-grouping'")
(a/'validate_stable_instance_grouping.py').write_text(s)
s=(a/'capture_static_skinning_output.py').read_text().replace("out=a/'static-skinning-output/image'","out=a/'stable-instance-grouping/image'").replace("'sourceBase':'76e91b3'","'sourceBase':'389ab83'").replace('Static immutable skinning-output reuse candidate','Stable scene-node grouping candidate')
(a/'capture_stable_instance_grouping.py').write_text(s)
s=(a/'measure_static_skinning_output.py').read_text().replace("out=a/'static-skinning-output/performance'","out=a/'stable-instance-grouping/performance'").replace("sourceBase='76e91b3'","sourceBase='389ab83'").replace('Static skinning-output reuse candidate-only','Stable scene-node grouping candidate-only')
(a/'measure_stable_instance_grouping.py').write_text(s)
