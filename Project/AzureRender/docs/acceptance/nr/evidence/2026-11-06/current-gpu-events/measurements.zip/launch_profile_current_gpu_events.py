from pathlib import Path
import subprocess,json,sys,time
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'current-gpu-events';sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
frozen=json.loads((out/'frozen-inputs.json').read_text());state=json.loads((out/'state.json').read_text());assert state['status']=='captured'
assert digest(Path(state['capture']))==state['captureSha256']
for name in ['products','project','tool']:assert all(digest(Path(p))==v for p,v in frozen[name].items())
assert inputs(root)==frozen['source']
cmd=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(a/'profile_current_gpu_events.py')];si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'profile-driver.log').open('wb') as log:
    child=subprocess.Popen(cmd,cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si)
    try:code=child.wait(timeout=300)
    except subprocess.TimeoutExpired:child.kill();child.wait();raise
v=json.loads((out/'profile-state.json').read_text());assert code==0 and v['status']=='profiled',v
assert inputs(root)==frozen['source']
for name in ['products','project','tool']:assert all(digest(Path(p))==value for p,value in frozen[name].items())
(out/'profile-result.json').write_text(json.dumps(dict(status='profiled',command=cmd,exitCode=code,seconds=time.monotonic()-start,sourceUnchanged=True,productsUnchanged=True,projectBytesUnchanged=True,toolBytesUnchanged=True),indent=2));print(json.dumps({k:v[k] for k in ['status','sumEventMs','events','leafPS','leafSamplesPassed','targetGroups','shaders']}),flush=True)
