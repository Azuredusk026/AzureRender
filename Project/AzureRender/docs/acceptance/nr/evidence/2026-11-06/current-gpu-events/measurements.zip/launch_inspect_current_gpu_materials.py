from pathlib import Path
import subprocess,json,sys,time
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'current-gpu-events';sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
frozen=json.loads((out/'frozen-inputs.json').read_text());state=json.loads((out/'state.json').read_text());assert state['status']=='captured'
assert digest(Path(state['capture']))==state['captureSha256']
for name in ['products','project','tool']:assert all(digest(Path(p))==v for p,v in frozen[name].items())
assert inputs(root)==frozen['source']
cmd=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(a/'inspect_current_gpu_materials.py')];si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
with (out/'material-driver.log').open('wb') as log:
    child=subprocess.Popen(cmd,cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si)
    try:code=child.wait(timeout=120)
    except subprocess.TimeoutExpired:child.kill();child.wait();raise
v=json.loads((out/'material-state.json').read_text());assert code==0 and v['status']=='inspected',v
assert inputs(root)==frozen['source']
for name in ['products','project','tool']:assert all(digest(Path(p))==value for p,value in frozen[name].items())
(out/'material-result.json').write_text(json.dumps(dict(status='inspected',command=cmd,exitCode=code,seconds=time.monotonic()-start,sourceUnchanged=True,productsUnchanged=True,projectBytesUnchanged=True,toolBytesUnchanged=True),indent=2));print('Current material states inspected and frozen inputs verified',flush=True)
