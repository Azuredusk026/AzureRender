from pathlib import Path
import json,hashlib,zipfile,sys,struct
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;task=a/'current-gpu-events';out=root/'docs/acceptance/nr/evidence/2026-11-06/current-gpu-events';out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
frozen=json.loads((task/'frozen-inputs.json').read_text());assert inputs(root)==frozen['source']
for name in ['products','project','tool']:assert all(digest(Path(p))==v for p,v in frozen[name].items())
verify(root,json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text()))
capture=json.loads((task/'capture-result.json').read_text());profile=json.loads((task/'profile-state.json').read_text());material=json.loads((task/'material-state.json').read_text());events=json.loads((task/'events/profile.json').read_text());mapping=json.loads((task/'shader-products.json').read_text())
assert capture['status']=='captured' and profile['status']=='profiled' and material['status']=='inspected'
assert capture['capture']['captureSha256']==digest(Path(capture['capture']['capture']))==material['captureSha256']==profile['captureSha256']
assert len(material['rows'])==32 and profile['events']==3424 and profile['leafPS']==27853535 and profile['leafSamplesPassed']==64679603
assert all(row['files'] and all(digest(root/'build/ninja-msvc-release/shaders'/name)==row['sha256'] for name in row['files']) for row in mapping)
decoded=[]
for row in material['rows']:
    raw=bytes.fromhex(row['specializationDataHex']);specialization={v['name']:struct.unpack_from('<I',raw,v['byteOffset'])[0] for b in row['specializationReflection'] for v in b['variables']}
    decoded.append(dict(event=row['event'],milliseconds=row['milliseconds'],shader=row['shader'],pipeline=row['pipeline'],material=row.get('material'),specialization=specialization,ps=row['pixelCounters'].get('ps'),samplesPassed=row['pixelCounters'].get('samplesPassed')))
(task/'material-summary.json').write_text(json.dumps(decoded,indent=2))
example=next(row for row in decoded if row['event']==23277);assert example['ps']==185347 and example['samplesPassed']==52 and example['material']['alphaMode']==0 and example['material']['nodeOpacity']==1 and example['specialization']['azureOrdinaryOpaque']==1
files=[p for p in task.rglob('*') if p.is_file() and p.suffix in {'.json','.log','.csv'}]
scripts=['capture_current_gpu_events.py','launch_current_gpu_events.py','profile_current_gpu_events.py','launch_profile_current_gpu_events.py','inspect_current_gpu_materials.py','launch_inspect_current_gpu_materials.py','archive_current_gpu_events.py'];files +=[a/name for name in scripts]
members={}
with zipfile.ZipFile(out/'measurements.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        name=p.relative_to(a).as_posix();data=p.read_bytes();assert name not in members;members[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
with zipfile.ZipFile(out/'measurements.zip') as z:assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==members
receipt=dict(schemaVersion=1,status='current-capture-profiled-next-hypothesis-unverified',sourceBase='0694263',capture=capture,profileResult=json.loads((task/'profile-result.json').read_text()),materialResult=json.loads((task/'material-result.json').read_text()),sumReplayEventMs=profile['sumEventMs'],eventCount=profile['events'],leafPS=profile['leafPS'],leafSamplesPassed=profile['leafSamplesPassed'],shaderInspectionLimit=128,pixelInspectionScope='Top96 PS events plus top128 timed draws; uninspected target group mixes other draws and dispatches',shaderProducts=mapping,selectedProgramTimingGroups=events['groups'],occludedOrdinaryOpaqueExample=example,nextHypothesis='Compile-time fully-covered node qualification for ordinary opaque material, preserving fading fallback; no early-depth performance benefit established yet',sourceInputsUnchanged=True,productsUnchanged=True,projectBytesUnchanged=True,fullVisualAcceptance='failed-user-review',fullPerformance='failed',nativeTimingEvidence='docs/acceptance/nr/evidence/2026-11-06/covered-depth-prefill/results.json',sources=[dict(url='https://github.com/baldurk/renderdoc/blob/v1.46/docs/python_api/renderdoc/counters.rst',scope='Official counter API reference'),dict(url='https://github.com/baldurk/renderdoc/blob/v1.46/renderdoc/api/replay/vk_pipestate.h',scope='Official Vulkan pipeline and specialization field contracts; no third-party implementation copied')],archiveMembers=members,archiveSha256=digest(out/'measurements.zip'))
(out/'results.json').write_text(json.dumps(receipt,indent=2)+'\n');(out/'.gitattributes').write_text('* -text -whitespace\n');print(json.dumps(dict(archiveBytes=(out/'measurements.zip').stat().st_size,members=len(members),example=example),indent=2))
