from pathlib import Path
import json,hashlib,zipfile
root=Path(__file__).resolve().parents[3]; a=Path(__file__).resolve().parent; task=a/'instance-preparation-cost'
out=root/'docs/acceptance/nr/evidence/2026-11-06/instance-preparation-cost';out.mkdir(parents=True,exist_ok=True)
stages=json.loads((task/'native/stage-results.json').read_text());native=json.loads((task/'native/results.json').read_text())
assert len(stages['rawRows'])==100 and stages['sourceProductsAndPrivateFilesUnchanged'] and stages['zeroAllocator'] and stages['validationClean']
files=[p for p in task.rglob('*') if p.is_file() and p.suffix.lower() in {'.json','.log','.csv','.cpp','.diff','.rsp','.map','.patch'}]
files += [a/'build_instance_preparation_diagnostic.py',a/'measure_instance_preparation_cost.py',Path(__file__)]
members={}
with zipfile.ZipFile(out/'measurements.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  name=p.relative_to(a).as_posix();data=p.read_bytes();members[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
with zipfile.ZipFile(out/'measurements.zip') as z:
 assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==members
receipt=dict(schemaVersion=1,status='measured-private-cpu-stages',sourceBase='a269247',productionAdoption=False,scope=stages['scope'],recordCount=len(stages['rawRows']),groups=stages['groups'],native=native,archiveMembers=members,archiveSha256=hashlib.sha256((out/'measurements.zip').read_bytes()).hexdigest(),fullVisualAcceptance='failed-user-review',fullPerformance='failed',next='One instance grouping candidate with exact stable resource/source ordering; uploads not selected as dominant cost')
(out/'results.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
(out/'.gitattributes').write_text('* -text -whitespace\n')
print(json.dumps(dict(members=len(members),archiveBytes=(out/'measurements.zip').stat().st_size,recordCount=100,environmentPassed=native['environmentPassed'])))
