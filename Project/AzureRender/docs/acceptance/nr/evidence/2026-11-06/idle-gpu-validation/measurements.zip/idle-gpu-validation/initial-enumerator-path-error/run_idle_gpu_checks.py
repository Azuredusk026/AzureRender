from pathlib import Path
import subprocess,json,time,os,sys,re,hashlib,shutil,xml.etree.ElementTree as ET
root=Path.cwd();a=root/'build/runs/20261105-125529-automatic-acceptance-3d5b54';out=a/'idle-gpu-validation';sys.path.insert(0,str(root/'tools'))
from gpu_environment import wait_and_record,snapshot
from build_provenance import inputs,verify
source=inputs(root);manifests={c:json.loads((root/('build/ninja-msvc-'+c+'/build-provenance.json')).read_text()) for c in ['release','debug']}
for m in manifests.values():verify(root,m)
environment=wait_and_record(out/'startup-environment.json');print('GPU stable idle gate passed',flush=True)
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';vkinfo='D:/Tools/VulkanSDK/1.4.350.0/Bin/vulkaninfo.exe';rows=[]
expected={'AzureRender.SkinningGpu','AzureRender.MotionVectorGpu','AzureRender.SharedMotionGpu'}
for config in ['release','debug']:
 for gpu,pattern,marker in [('nvidia','*nv-vk64*','NVIDIA'),('intel','*igvk64*','Intel')]:
  tag=config+'-'+gpu;env=os.environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None);env['VK_LOADER_DRIVERS_SELECT']=pattern
  enumeration=subprocess.run([vkinfo,'--summary'],env=env,capture_output=True,timeout=60);raw=enumeration.stdout+enumeration.stderr;(out/(tag+'-devices.log')).write_bytes(raw)
  names=re.findall(r'deviceName\s*=\s*([^\r\n]+)',raw.decode('utf-8',errors='replace'));assert enumeration.returncode==0 and len(names)==1 and marker.lower() in names[0].lower(),names
  cmd=[ctest,'--test-dir',str(root/('build/ninja-msvc-'+config)),'-R','^AzureRender.(SkinningGpu|MotionVectorGpu|SharedMotionGpu)$','--output-on-failure','--no-tests=error','--output-junit',str(out/(tag+'-tests.xml'))];start=time.monotonic()
  with (out/(tag+'-tests.log')).open('wb') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
  shutil.copy2(root/('build/ninja-msvc-'+config+'/Testing/Temporary/LastTest.log'),out/(tag+'-tests-full.log'))
  actual={case.attrib['name'] for case in ET.parse(out/(tag+'-tests.xml')).iter('testcase')};assert actual==expected,actual
  row={'configuration':config,'device':gpu,'enumeratedDevice':names[0].strip(),'filter':pattern,'exitCode':r.returncode,'seconds':time.monotonic()-start,'actualChecks':sorted(actual),'command':cmd};rows.append(row);(out/'gpu-checks.json').write_text(json.dumps({'status':'running','rows':rows},indent=2));print(tag,'exit',r.returncode,'seconds',round(row['seconds'],2),flush=True)
  assert r.returncode==0
assert inputs(root)==source
for m in manifests.values():verify(root,m)
(out/'gpu-checks.json').write_text(json.dumps({'status':'passed','scope':'3 actual GPU cases x2configurations x2devices; synchronization validation and zero-resource assertions inside each original case; skinning adds byte comparison of individual/bulk buffer barriers','rows':rows,'sourceInputsUnchanged':True,'allRecordedProductsVerified':True},indent=2));print('All12device checks passed; source/products verified',flush=True)
