from pathlib import Path
import renderdoc as rd,json,sys,traceback,time,ctypes,hashlib
out=Path(r"D:\Projects\FYP\Project\AzureRender\build\runs\20261105-125529-automatic-acceptance-3d5b54\performance-bottlenecks" )/'admin-counter-control';rd.SetDebugLogFile(str(out/'nv-sdk-diagnostic.log'));capture=rd.OpenCaptureFile();controller=None;result={}
try:
 result['administrator']=bool(ctypes.windll.shell32.IsUserAnAdmin());assert result['administrator'],'Elevated token required'
 (out/'progress.json').write_text(json.dumps(dict(status='waiting-native-image',administrator=True)))
 image=out.parents[1]/'animation-curve-validation/image/results.json';deadline=time.monotonic()+360
 while not image.exists():
  assert time.monotonic()<deadline,'Image gate wait budget exhausted'
  time.sleep(1)
 assert json.loads(image.read_text())['status']=='passed','Native image gate failed'
 (out/'progress.json').write_text(json.dumps(dict(status='waiting-functional-gpu-checks',administrator=True)))
 checks=out.parents[1]/'animation-curve-validation/gpu/gpu-checks.json';deadline=time.monotonic()+600
 while not checks.exists() or json.loads(checks.read_text()).get('status')!='passed':
  assert time.monotonic()<deadline,'Functional GPU gate wait budget exhausted'
  time.sleep(1)
 (out/'progress.json').write_text(json.dumps(dict(status='opening-frozen-capture',administrator=True)))
 state=json.loads(Path(r"D:\Projects\FYP\Project\AzureRender\build\runs\20261105-125529-automatic-acceptance-3d5b54\current-gpu-events\state.json").read_text());result['captureSha256']=state['captureSha256'];assert hashlib.sha256(Path(state['capture']).read_bytes()).hexdigest()==result['captureSha256'];assert capture.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,controller=capture.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded,str(status)
 values=[]
 for c in controller.EnumerateCounters():
  d=controller.DescribeCounter(c);values.append(dict(id=int(c),name=d.name,description=d.description,type=str(d.resultType),unit=str(d.unit)))
 result.update(status='collecting',counters=values,count=len(values));(out/'nv-hardware-counters.json').write_text(json.dumps(result,indent=2))
 wanted=['dram__bytes.sum','pcie__read_bytes.sum','pcie__write_bytes.sum','smsp__inst_executed.sum','gpu__time_duration.sum','l1tex__t_sector_hit_rate.avg.pct','lts__t_sector_hit_rate.avg.pct','smsp__warp_issue_stalled_long_scoreboard_per_warp_active.avg.pct','smsp__warp_issue_stalled_math_pipe_throttle_per_warp_active.avg.pct','smsp__warp_issue_stalled_tex_throttle_per_warp_active.avg.pct']
 ids={v['name']:v['id'] for v in values};assert all(n in ids for n in wanted)
 (out/'progress.json').write_text(json.dumps(dict(status='fetching-vendor-counters',administrator=True)))
 countermap={int(c):c for c in controller.EnumerateCounters()};sampled=controller.FetchCounters([rd.GPUCounter.EventGPUDuration]+[countermap[ids[n]] for n in wanted]);result.update(status='collected',selected=[v for v in values if v['name'] in wanted],measurements=[dict(event=int(v.eventId),counter=int(v.counter),value=float(v.value.d)) for v in sampled]);assert len(result['measurements'])>0,'No NVIDIA hardware counter samples returned'
 result['debugMessages']=[dict(description=m.description,severity=str(m.severity),source=str(m.source),event=int(m.eventId)) for m in controller.GetDebugMessages()];result['vendorSampleCount']=sum(v['counter']>=3000000 for v in result['measurements']);result['genericSampleCount']=sum(v['counter']<3000000 for v in result['measurements']);result['status']='collected' if result['vendorSampleCount'] else 'vendor-samples-unavailable';result.pop('counters');result.pop('count')
except Exception:result.update(status='failed',error=traceback.format_exc())
finally:
 if controller:
  log=Path(rd.GetLogFile())
  if log.exists(): (out/'nv-sdk-retained.log').write_bytes(log.read_bytes())
  controller.Shutdown()
 capture.Shutdown();(out/'nv-hardware-counters.json').write_text(json.dumps(result,indent=2))
sys.exit(0 if result.get('status')=='collected' else 1)
