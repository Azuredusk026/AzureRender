from pathlib import Path
import time,json,subprocess,sys
r=Path.cwd();a=r/'build/runs/20261105-125529-automatic-acceptance-3d5b54';p=a/'animation-curve-validation/engine-debug-checks.json';deadline=time.monotonic()+600
while not p.exists():
 assert time.monotonic()<deadline,'Debug checks wait deadline exceeded'
 time.sleep(1)
assert json.loads(p.read_text())['exitCode']==0
raise SystemExit(subprocess.call([sys.executable,'-X','utf8',str(a/'run_animation_curves_gpu_checks.py')]))
