from pathlib import Path
r=Path.cwd()
p=r/'tests/AnimationCurveTests.cpp';s=p.read_text();s=s.replace('    std::cout<<',r"""
    for(const auto& curve : {AnimationCurve{{0,2},{1,3},1,CurveInterpolation::Step,false},
                            AnimationCurve{{0,2},{1,3},1,CurveInterpolation::Linear,false},q}){
        PreparedAnimationCurve prepared(curve);
        for(float t : {-1.F,0.F,.25F,1.F,2.F,3.F})check(prepared.sample(t)==sampleCurve(curve,t));
        bool invalidTime=false;try{prepared.sample(std::numeric_limits<float>::infinity());}catch(const std::invalid_argument&){invalidTime=true;}check(invalidTime);
    }
    AnimationCurve editable{{0,2},{1,3},1};PreparedAnimationCurve frozen(editable);
    editable.values[0]=std::numeric_limits<float>::quiet_NaN();
    check(frozen.sample(1)[0]==2);bool rawRejected=false;
    try{sampleCurve(editable,1);}catch(const std::invalid_argument&){rawRejected=true;}check(rawRejected);
    bool prepareRejected=false;try{PreparedAnimationCurve invalid(editable);}catch(const std::invalid_argument&){prepareRejected=true;}check(prepareRejected);
    std::cout<<""");p.write_text(s)
p=r/'tests/NodeOpacityTests.cpp';s=p.read_text();marker='        std::cout << "Node opacity defaults'
i=s.index(marker);s=s[:i]+r"""
        for(const auto* input : {&asset,&step,&cubic,&mixedAsset,&signAsset}){
            PreparedAssetAnimations prepared(*input);
            for(float time : {-1.F,0.F,.25F,1.F,2.F,5.F})for(bool loop : {false,true}){
                const auto raw=sampleAnimationPose(*input,0,time,loop);
                const auto cached=sampleAnimationPose(*input,0,time,loop,&prepared);
                check(raw.nodeWorldMatrices==cached.nodeWorldMatrices&&raw.nodeWorldOpacities==cached.nodeWorldOpacities
                    &&raw.jointMatrices==cached.jointMatrices&&raw.morphWeights==cached.morphWeights,"Prepared sample must preserve resolved outputs");
                for(std::size_t n=0;n<raw.local.size();++n)check(raw.local[n].translation==cached.local[n].translation
                    &&raw.local[n].rotation==cached.local[n].rotation&&raw.local[n].scale==cached.local[n].scale
                    &&raw.local[n].opacity==cached.local[n].opacity,"Prepared sample must preserve local outputs");
            }
            bool mismatch=false;auto another=*input;
            try{sampleAnimationPose(another,0,1,false,&prepared);}catch(const std::invalid_argument&){mismatch=true;}
            check(mismatch,"Prepared animation must reject another resource binding");
        }
        auto editableAsset=asset;PreparedAssetAnimations frozenAnimations(editableAsset);
        const auto frozenPose=sampleAnimationPose(editableAsset,0,1,false,&frozenAnimations);
        editableAsset.animations[0].samplers[0].curve.values[0]=std::numeric_limits<float>::quiet_NaN();
        bool rawRejected=false;try{sampleAnimationPose(editableAsset,0,1,false);}catch(const std::invalid_argument&){rawRejected=true;}
        check(rawRejected,"Mutable curve sampling must retain full validation");
        check(sampleAnimationPose(editableAsset,0,1,false,&frozenAnimations).nodeWorldOpacities==frozenPose.nodeWorldOpacities,
            "Prepared data must own an independent animation snapshot");
        bool rebuildRejected=false;try{PreparedAssetAnimations invalid(editableAsset);}catch(const std::invalid_argument&){rebuildRejected=true;}
        check(rebuildRejected,"Rebuilding must validate current curve input");
"""+s[i:];p.write_text(s)
