from pathlib import Path
import renderdoc as rd,json,sys,traceback
out=Path(r"D:\Projects\FYP\Project\AzureRender\build\runs\20261105-125529-automatic-acceptance-3d5b54\performance-bottlenecks");rd.SetDebugLogFile(str(out/'nv-sdk-diagnostic.log'));capture=rd.OpenCaptureFile();controller=None;result={}
try:
 state=json.loads(Path(r"D:\Projects\FYP\Project\AzureRender\build\runs\20261105-125529-automatic-acceptance-3d5b54\current-gpu-events\state.json").read_text());result['captureSha256']=state['captureSha256'];assert capture.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,controller=capture.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded,str(status)
 values=[]
 for c in controller.EnumerateCounters():
  d=controller.DescribeCounter(c);values.append(dict(id=int(c),name=d.name,description=d.description,type=str(d.resultType),unit=str(d.unit)))
 result.update(status='collecting',counters=values,count=len(values));(out/'nvperf-2025-dram-control.json').write_text(json.dumps(result,indent=2))
 wanted=['dram__bytes.sum','pcie__read_bytes.sum','pcie__write_bytes.sum','smsp__inst_executed.sum','l1tex__t_sector_hit_rate.avg.pct','lts__t_sector_hit_rate.avg.pct','smsp__warp_issue_stalled_long_scoreboard_per_warp_active.avg.pct','smsp__warp_issue_stalled_math_pipe_throttle_per_warp_active.avg.pct','smsp__warp_issue_stalled_tex_throttle_per_warp_active.avg.pct']
 ids={v['name']:v['id'] for v in values};assert all(n in ids for n in wanted)
 countermap={int(c):c for c in controller.EnumerateCounters()};sampled=controller.FetchCounters([countermap[ids['dram__bytes.sum']]]);result.update(status='collected',selected=[v for v in values if v['name'] in wanted],measurements=[dict(event=int(v.eventId),counter=int(v.counter),value=float(v.value.d)) for v in sampled]);result['scope']='Single DRAM counter control after mixed counter configuration returned no vendor samples'
 result['debugMessages']=[dict(description=m.description,severity=str(m.severity),source=str(m.source),event=int(m.eventId)) for m in controller.GetDebugMessages()];result['vendorSampleCount']=sum(v['counter']>=3000000 for v in result['measurements']);result['genericSampleCount']=sum(v['counter']<3000000 for v in result['measurements']);result['status']='collected' if result['vendorSampleCount'] else 'vendor-samples-unavailable';result.pop('counters');result.pop('count')
except Exception:result.update(status='failed',error=traceback.format_exc())
finally:
 if controller:
  log=Path(rd.GetLogFile())
  if log.exists(): (out/'nv-sdk-retained.log').write_bytes(log.read_bytes())
  controller.Shutdown()
 capture.Shutdown();(out/'nvperf-2025-dram-control.json').write_text(json.dumps(result,indent=2))
sys.exit(0 if result.get('status')=='collected' else 1)
