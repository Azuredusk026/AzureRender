from pathlib import Path
import renderdoc as rd,json,sys,traceback
out=Path(r"D:\Projects\FYP\Project\AzureRender\build\runs\20261105-125529-automatic-acceptance-3d5b54\performance-bottlenecks");capture=rd.OpenCaptureFile();controller=None;result={}
try:
 state=json.loads(Path(r"D:\Projects\FYP\Project\AzureRender\build\runs\20261105-125529-automatic-acceptance-3d5b54\current-gpu-events\state.json").read_text());result['captureSha256']=state['captureSha256'];assert capture.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,controller=capture.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded,str(status)
 values=[]
 for c in controller.EnumerateCounters():
  d=controller.DescribeCounter(c);values.append(dict(id=int(c),name=d.name,description=d.description,type=str(d.resultType),unit=str(d.unit)))
 result.update(status='enumerated',counters=values,count=len(values))
except Exception:result.update(status='failed',error=traceback.format_exc())
finally:
 if controller:controller.Shutdown()
 capture.Shutdown();(out/'nv-counter-inventory.json').write_text(json.dumps(result,indent=2))
sys.exit(0 if result.get('status')=='enumerated' else 1)
