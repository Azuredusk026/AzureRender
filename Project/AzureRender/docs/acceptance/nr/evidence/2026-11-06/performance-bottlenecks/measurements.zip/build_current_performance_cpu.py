from pathlib import Path
import subprocess,json,time,ctypes,sys
root=Path(__file__).resolve().parents[3];a=Path(__file__).resolve().parent;o=a/'performance-bottlenecks/cpu';build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
source=inputs(root);manifest=json.loads((build/'build-provenance.json').read_text());verify(root,manifest)
(o/'production-before.json').write_text(json.dumps(dict(source=source,products=manifest['products'],playerSha256=digest(build/'AzurePlayer.exe')),indent=2))
api=ctypes.WinDLL('shell32').CommandLineToArgvW;api.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)];api.restype=ctypes.POINTER(ctypes.c_wchar_p);free=ctypes.WinDLL('kernel32').LocalFree;free.argtypes=[ctypes.c_void_p]
commands=json.loads((o/'original-compile-commands.json').read_text());rows=[];objects=[]
for name,command in commands.items():
 count=ctypes.c_int();pointer=api(command,ctypes.byref(count));assert pointer
 try:args=[pointer[i] for i in range(count.value)]
 finally:free(pointer)
 output=o/'private-link'/f'{name}.obj';objects.append(output)
 for i,value in enumerate(args):
  if value.startswith('/Fo'):args[i]='/Fo'+str(output)
  elif value.startswith('/Fd'):args[i]='/Fd'+str(o/'private-link'/f'{name}.pdb')
 assert Path(args[-1]).name==name+'.cpp';args[-1]=str(o/'source'/f'{name}.cpp');args.insert(-2,'/I'+str(root/('src/scenes' if name=='CharacterSceneRenderer' else 'src/app')))
 start=time.monotonic()
 with (o/(name+'-compile.log')).open('wb') as log:r=subprocess.run(args,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 rows.append(dict(name=name,command=args,exitCode=r.returncode,seconds=time.monotonic()-start));(o/'compile-results.json').write_text(json.dumps(rows,indent=2))
 assert r.returncode==0,(o/(name+'-compile.log')).read_text(errors='replace')[-2500:]
 print(name,'private compile passed',flush=True)
old=a/'private-profile-map-2fad7ef';rsp=(old/'link.rsp').read_text().replace(str(old),str(o/'private-link'));rsp='/nologo '+' '.join('"'+str(p)+'"' for p in objects)+' '+rsp;(o/'private-link/link.rsp').write_text(rsp)
command=['D:/Tools/VS2022BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/link.exe','@'+str(o/'private-link/link.rsp')]
with (o/'private-link/link.log').open('wb') as log:r=subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert r.returncode==0,(o/'private-link/link.log').read_text(errors='replace')[-3000:]
assert inputs(root)==source;verify(root,manifest)
(o/'build-result.json').write_text(json.dumps(dict(status='private-diagnostic-built',sourceBase='f224da9-with-ordinary-early-depth-candidate',privateExecutableSha256=digest(o/'private-link/AzurePlayer.exe'),productionExecutableUnchanged=True,productionSourceAndProductsVerified=True,command=command,compile=rows),indent=2));print('Private executable linked; production source/products verified',flush=True)
