from pathlib import Path
import json,urllib.request,time
root=Path(__file__).resolve().parents[3];out=Path(__file__).resolve().parent/'performance-bottlenecks'
headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25'}
def request(identifier,method,params,timeout=600):
 payload=dict(jsonrpc='2.0',id=identifier,method=method,params=params)
 with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:7664/mcp',json.dumps(payload).encode(),headers=headers),timeout=timeout) as result:
  if result.headers.get('Mcp-Session-Id'):headers['Mcp-Session-Id']=result.headers['Mcp-Session-Id']
  raw=result.read().decode();(out/('nsight-response-'+str(identifier)+'.txt')).write_text(raw)
  if raw.lstrip().startswith('{'):return json.loads(raw)
  for line in raw.splitlines():
   if line.startswith('data:') and line[5:].strip():return json.loads(line[5:].strip())
  raise ValueError('Empty Nsight response')
def call(identifier,name,arguments):
 raw=request(identifier,'tools/call',dict(name=name,arguments=arguments));(out/('nsight-'+identifier+'.json')).write_text(json.dumps(raw,indent=2))
 if 'error' in raw:raise RuntimeError(raw['error'])
 v=raw['result'];print(identifier,'isError',v.get('isError'),flush=True)
 if v.get('structuredContent') is not None:return v['structuredContent']
 for c in v.get('content',[]):
  if c['type']=='text':
   try:return json.loads(c['text'])
   except ValueError:pass
 return v
