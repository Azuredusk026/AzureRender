"""Qualify captured frame identity and retain the original region gates."""
from pathlib import Path
from hashlib import sha256
from io import BytesIO
from zipfile import ZipFile
import json,runpy
import cv2,numpy as np

O=Path(__file__).resolve().parent
W=O.parents[2]
M=O.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e'
q=json.loads((W/'docs/acceptance/nr/evidence/2026-11-19/reflection-confidence-lod/qualification.json').read_bytes())
scoring=runpy.run_path(str(M/'score-joint-native-floor.py'),run_name='score_frames')
reference=cv2.cvtColor(cv2.imread(q['reference']),cv2.COLOR_BGR2RGB)
rows=[];arrays={}
with ZipFile(W/'docs/acceptance/nr/evidence/2026-11-19/reflection-confidence-lod/validation.zip') as z:
    oldCrops=np.load(BytesIO(z.read('target-crops.npz')),allow_pickle=False)
    for frame in (0,1):
        f=O/f'capture/frames/frame_{frame:06d}.png'
        image=cv2.imread(str(f),cv2.IMREAD_UNCHANGED)
        assert image.shape==(1440,2560,4)
        expected=q['reports']['nvidia']['rows'][frame]['control']
        rgbaRaw=sha256(image.tobytes()).hexdigest()
        rgb=cv2.cvtColor(image,cv2.COLOR_BGRA2RGB)
        regions={}
        for name,(x,y,u,v) in q['rectangles'].items():
            cut=rgb[y:v,x:u];gold=reference[y:v,x:u]
            result=scoring['measure'](cut,gold)
            if name in ('centerFloor','cyanRing'):
                arrays['reference_'+name]=gold
                arrays[f'frame{frame}_{name}']=cut
            if name in ('centerFloor','cyanRing'):
                baseline=oldCrops[f'nvidia__{frame}__control__{name}']
                result['changedVsFe5Control']=int(np.any(cut!=baseline,axis=-1).sum())
                arrays[f'frame{frame}_{name}']=cut
                arrays[f'reference_{name}']=gold
            regions[name]=result
        rows.append(dict(frameIndex=frame,pngSha256=sha256(f.read_bytes()).hexdigest(),
            bgraRawSha256=rgbaRaw,rgbSha256=sha256(rgb.tobytes()).hexdigest(),
            expectedFe5Control=expected,fullFrameMatchesFe5Control=rgbaRaw==expected['raw'],regions=regions))
        print(frame,'full frame exact:',rgbaRaw==expected['raw'],
            {r:(regions[r]['ssim'],regions[r]['medianLumaRelativeError']) for r in ('centerFloor','cyanRing')})
np.savez_compressed(O/'target-crops.npz',**arrays)
manifest=json.loads((O/'capture/frames/capture_manifest.json').read_bytes())
actual={k:manifest[k] for k in q['reports']['nvidia']['control']['camera']}
assert actual==q['reports']['nvidia']['control']['camera']
result=dict(status='qualified-frozen-frame-images',rows=rows,camera=actual,
    baseline='fe5ba3b',referenceSha256=q['referenceSha256'],
    originalGates=q['regionalGates'],
    sourceFingerprint=json.loads((O/'request.json').read_bytes())['playerSha256'],
    frozenFourFrames=dict(scope='reused unchanged host/shader evidence; two diagnostic frames checked here',
        evidence=str(W/'docs/acceptance/nr/evidence/2026-11-16/projected-history-layer-frozen/qualification.json')))
(O/'frame-identity.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
