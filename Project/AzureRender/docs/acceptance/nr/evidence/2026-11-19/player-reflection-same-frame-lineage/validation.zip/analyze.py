"""Compare actual same-frame stage values at aligned floor positions."""
from pathlib import Path
from hashlib import sha256
from io import BytesIO
from zipfile import ZipFile
import json,zlib,struct
import numpy as np
import cv2

O=Path(__file__).resolve().parent
W=O.parents[2]
OLD=O.parent/'20261119-181852-nr-same-frame-reflection-lineage-ffb239'
read=lambda p:json.loads(p.read_bytes())
p=read(O/'player/result.json');n=read(OLD/'native/result.json')
assert p['status']==n['status']=='qualified-same-frame-stage-readbacks'
assert p['frameNumber']==1 and n['frameNumber']==3534
f=read(O/'frame-identity.json');request=read(O/'request.json')
assert all(row['fullFrameMatchesFe5Control'] for row in f['rows'])
sources={};arrays={};metadata={}
REGIONS={'centerFloor':[505,495,775,585],'cyanRing':[520,530,635,590]}

def decode_words(words):
    result=[]
    for shift,mantissa in ((0,6),(11,6),(22,5)):
        v=words>>shift;e=((v>>mantissa)&31).astype(np.int32)
        m=(v&((1<<mantissa)-1))/float(1<<mantissa)
        assert np.all(e<31)
        result.append(np.where(e==0,np.ldexp(m,-14),np.ldexp(1+m,e-15)))
    return np.stack(result,axis=-1)

def image(root,record,key):
    encoded=(root/record['file']).read_bytes()
    assert sha256(encoded).hexdigest()==record['encodedSha256']
    raw=zlib.decompress(encoded)
    assert sha256(raw).hexdigest()==record['sha256']
    sources[key]=record
    x,y,u,v=record['rect'];fmt=record['format']
    if fmt=='R11G11B10_FLOAT':a=decode_words(np.frombuffer(raw,'<u4').reshape(v-y,u-x))
    else:
        dtype,channels,divisor={'R8_UNORM':('u1',1,255),'R32_FLOAT':('<f4',1,1),
            'R16G16_UNORM':('<u2',2,65535),'R32G32B32A32_FLOAT':('<f4',4,1),
            'R16G16B16A16_FLOAT':('<f2',4,1)}[fmt]
        a=np.frombuffer(raw,dtype).reshape(v-y,u-x,channels).astype('f8')/divisor
    if record['nativeStorageFlip']:a=a[::-1];y,v=record['height']-v,record['height']-y
    arrays[key]=a
    metadata[key]={'bounds':[x,y,u,v],'format':fmt,'resource':record['resource'],'event':record['event']}
    return a

def select(report,stage,prefix):
    return next(levels[0] for key,levels in report['stages'][stage]['textures'].items() if key.startswith(prefix))

for label,report,root in (('native',n,OLD/'native'),('player',p,O/'player')):
    image(root,select(report,'trace','write:0:' if label=='native' else 'write:9:'),label+'_trace')
    image(root,select(report,'trace','write:2:' if label=='native' else 'write:11:'),label+'_traceConfidence')
    image(root,select(report,'filter','read:2:'),label+'_filterInput')
    image(root,select(report,'filter','read:0:'),label+'_depth')
    image(root,report['stages']['filterOutput'],label+'_filtered')
    assert len(report['consumers'])==1
    consumer=report['consumers'][0]
    image(root,consumer['filterReadback'],label+'_consumedFiltered')
    image(root,consumer['hdrAfter'],label+'_hdr')
    assert report['stages']['filterOutput']['fullSha256']==consumer['filterReadback']['fullSha256']
    assert report['stages']['filterOutput']['sha256']==consumer['filterReadback']['sha256']
image(OLD/'native',n['stages']['consumerConfidence'],'native_consumerConfidence')

ref=read(W/'docs/acceptance/nr/evidence/2026-11-19/reflection-confidence-lod/qualification.json')
rgb=lambda path:cv2.cvtColor(cv2.imread(str(path)),cv2.COLOR_BGR2RGB)
nativeDisplay=rgb(ref['reference']);playerDisplay=rgb(O/'capture/frames/frame_000001.png')
rgbDigest=sha256(playerDisplay.tobytes()).hexdigest()
displayMatches=[c for c in p['finalCandidates'] if c['rgbSha256']==rgbDigest]
assert len(displayMatches)==1,'Capture final texture does not match frame PNG'

def crop(key,rect):
    x,y,u,v=rect;a=arrays[key];l,t,r,b=metadata[key]['bounds']
    assert l<=x<u<=r and t<=y<v<=b,(key,rect,metadata[key])
    return a[y-t:v-t,x-l:u-l]

def reconstruct(depth,rect,inverse):
    x,y,u,v=rect
    xx,yy=np.meshgrid((np.arange(x,u)+.5)*2/1280-1,(np.arange(y,v)+.5)*2/720-1)
    clip=np.stack([xx,yy,depth,np.ones_like(depth)],axis=-1)
    vec=clip@inverse
    return -vec[...,2]/vec[...,3]

nr=np.frombuffer(bytes.fromhex(n['stages']['trace']['constants'][0]['hex']),'<f4').reshape(-1,4)[12:16].astype('f8')
pr=np.frombuffer(bytes.fromhex(p['stages']['trace']['constants'][0]['hex']),'<f4').reshape(-1,4)[6:10].astype('f8')
compress=lambda a:a/(1+np.max(a,axis=-1,keepdims=True))
weights=np.array([.2126,.7152,.0722])
regionArrays={};results={}
for name,rect in REGIONS.items():
    x,y,u,v=rect
    nd,pd=[reconstruct(crop(label+'_depth',rect)[...,0],rect,matrix) for label,matrix in (('native',nr),('player',pr))]
    nc,pc=[crop(label+'_traceConfidence',rect)[...,0] for label in ('native','player')]
    valid=np.isfinite(nd)&np.isfinite(pd)&(abs(nd-pd)<=.02)&(nc>0)&(pc>0)
    regionArrays[name+'_depth']=np.stack([nd,pd],axis=-1)
    regionArrays[name+'_confidence']=np.stack([nc,pc],axis=-1)
    stages={}
    for stage,suffix in (('trace','trace'),('filterInput','filterInput'),('filtered','filtered')):
        values=[crop(label+'_'+suffix,rect)[...,:3] for label in ('native','player')]
        if stage=='filtered':values=list(map(compress,values))
        stages[stage]=np.stack(values,axis=-2)
    for stage in ('hdr','display'):
        displayRect=[x*2,y*2,u*2,v*2]
        if stage=='hdr':
            values=[compress(crop(label+'_hdr',displayRect)[...,:3]) for label in ('native','player')]
        else:values=[a[y*2:v*2,x*2:u*2]/255 for a in (nativeDisplay,playerDisplay)]
        stages[stage]=np.stack([a[1::2,1::2] for a in values],axis=-2)
    for stage,a in stages.items():regionArrays[name+'_'+stage]=a
    results[name]={'bounds':rect,'pixels':int(valid.size),'matchedDepthAndBothHit':int(valid.sum()),'stages':{}}
    for stage,a in stages.items():
        luma=a@weights;luma=luma[valid]
        results[name]['stages'][stage]={'lumaCorrelation':float(np.corrcoef(luma.T)[0,1]),
            'medianNativePlayer':np.median(luma,axis=0).tolist(),
            'meanAbsoluteLumaDifference':float(np.mean(abs(luma[:,0]-luma[:,1])))}
    results[name]['rawToFilterChangedNativePlayer']=[int(np.any(stages['trace'][...,i,:]!=stages['filterInput'][...,i,:],axis=-1)[valid].sum()) for i in (0,1)]

witnesses=[]
for xy in request['points']:
    x,y=xy;hx,hy=x//2,y//2;coords=[[hx,hy],[hx+1,hy],[hx,hy+1],[hx+1,hy+1]]
    row={'displayXY':xy,'filterXY':coords,'weights':[9/16,3/16,3/16,1/16]}
    for label,report in (('native',n),('player',p)):
        taps=np.array([crop(label+'_filtered',[xx,yy,xx+1,yy+1])[0,0] for xx,yy in coords])
        value=np.array(row['weights'])@taps
        consumer=report['consumers'][0]
        history=next(h for h in next(r for r in report['pixelHistory'] if r['displayXY']==xy)['records']
            if h['event']==consumer['event'] and not h['failed'])
        actual=crop(label+'_hdr',[x,y,x+1,y+1])[0,0]
        historyColorUsable=bool(np.allclose(actual[:3],history['after'][:3],rtol=0,atol=0))
        if label=='native':assert historyColorUsable
        item={'taps':taps.tolist(),'bilinear':value.tolist(),'pixelHistoryShaderOutput':history['shaderOut'],
            'pixelHistoryColorUsable':historyColorUsable,'quantizedHdr':actual.tolist(),
            'depth':float(reconstruct(crop(label+'_depth',[hx,hy,hx+1,hy+1])[...,0],
                [hx,hy,hx+1,hy+1],nr if label=='native' else pr)[0,0])}
        if label=='native':
            conf=np.array([crop('native_consumerConfidence',[xx,yy,xx+1,yy+1])[0,0,0] for xx,yy in coords])
            item['confidenceTaps']=conf.tolist();item['bilinearConfidence']=float(np.array(row['weights'])@conf)
        row[label]=item
    row['depthMatched']=abs(row['native']['depth']-row['player']['depth'])<=.02
    witnesses.append(row)
debug=p['consumerDebug'];state=debug['finalState']
assert debug['status']=='traced' and debug['event']==p['consumers'][0]['event']
assembly=(O/'player/consumer.asm').read_text()
assert 'float4 _17687 = sampleComputedScreenReflection(param@343);' in assembly
assert 'float3 _17723 = GLSL.std.450::FMix(_17717, _17719, _17722);' in assembly
assert 'float3 _17727 = _17725 * _17726;' in assembly
assert '*outputColor = _18629;' in assembly
semantic={name:state[identity][:size] for name,identity,size in (
    ('sampledReflection','_17687',4),('probeIncident','_17717',3),('mixedIncident','_17723',3),
    ('materialResponse','_17725',3),('reflectedContribution','_17727',3),
    ('previousAmbientSpecular','_17729',3),('beautyBeforeMix','_17731',3),
    ('beautyAfterMix','_17732',3),('shaderOutput','_18629',4))}
sampled=np.array(semantic['sampledReflection']);probe=np.array(semantic['probeIncident'])
mixed=np.array(semantic['mixedIncident']);response=np.array(semantic['materialResponse'])
np.testing.assert_allclose(sampled,witnesses[0]['player']['bilinear'],rtol=0,atol=1e-6)
for key,identity in zip(('tap00','tap10','tap01','tap11'),('_5162','_5164','_5170','_5173')):
    semantic[key]=state[identity]
np.testing.assert_allclose(np.array([semantic[k] for k in ('tap00','tap10','tap01','tap11')]),
    witnesses[0]['player']['taps'],rtol=0,atol=0)
np.testing.assert_allclose(mixed,probe*(1-sampled[3])+sampled[:3]*sampled[3],rtol=0,atol=1e-6)
np.testing.assert_allclose(semantic['reflectedContribution'],response*mixed,rtol=0,atol=1e-6)
np.testing.assert_allclose(semantic['beautyAfterMix'],np.array(semantic['beautyBeforeMix'])+
    np.array(semantic['reflectedContribution'])-semantic['previousAmbientSpecular'],rtol=0,atol=1e-6)
np.testing.assert_array_equal(np.array(semantic['shaderOutput'],dtype='f2').astype('f8'),
    witnesses[0]['player']['quantizedHdr'])
nativeDebug=read(OLD/'native-sampling.json')['debug']
nativeSample=np.array(nativeDebug['colorSample'])
counterfactual=np.array(semantic['beautyBeforeMix'])+response*nativeSample-semantic['previousAmbientSpecular']
nativeOutput=np.array(witnesses[0]['native']['pixelHistoryShaderOutput'][:3])
before=np.abs(np.array(semantic['beautyAfterMix'])-nativeOutput)
after=np.abs(counterfactual-nativeOutput)
semantic['nativeIncidentSubstitutionAtMix']=counterfactual.tolist()
semantic['nativeIncidentSubstitutionScope']='Diagnostic substitution at one mix node, not an implemented or rendered repair.'
semantic['absoluteRgbResidualBeforeAfter']=[before.tolist(),after.tolist()]
semantic['meanAbsoluteRgbResidualReduction']=float(1-after.mean()/before.mean())
np.savez_compressed(O/'stage-regions.npz',**regionArrays)
result={'status':'same-frame-stage-lineage-captured','acceptedVisualChange':False,
    'frameIdentity':{'native':3534,'player':1,'playerDisplayResource':displayMatches[0]['resource'],
        'playerDisplayRgbSha256':rgbDigest,'fe5ControlFramesExact':True},
    'bindings':{'native':{'trace':n['traceEvent'],'filter':n['filterEvent'],'consumer':n['consumers'][0]['event']},
        'player':{'trace':p['traceEvent'],'filter':p['filterEvent'],'consumer':p['consumers'][0]['event'],
            'traceShader':p['stages']['trace']['shaderSha256'],'filterShader':p['stages']['filter']['shaderSha256'],
            'consumerShader':p['consumers'][0]['shaderSha256'],'filteredResource':p['filterOutputResource']}},
    'regions':results,'witnesses':witnesses,'inputRecords':sources,'playerConsumerWitness':semantic,
    'inverseProjectionNativePlayer':[nr.tolist(),pr.tolist()],
    'scope':'Same-depth both-hit diagnostic metrics; they do not replace original regional SSIM, brightness or frozen-frame gates.'}
(O/'stage-analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'identity':result['frameIdentity'],
    'matchedPoints':{k:v['matchedDepthAndBothHit'] for k,v in results.items()},
    'consumerWitnessResidualReduction':semantic['meanAbsoluteRgbResidualReduction']},indent=2))
