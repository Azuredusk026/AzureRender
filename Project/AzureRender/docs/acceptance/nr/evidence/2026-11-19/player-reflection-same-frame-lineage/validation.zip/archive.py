"""Retain the source-bound same-frame attribution and its independent verifier."""
from pathlib import Path
from hashlib import file_digest,sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,subprocess,shutil,sys,sqlite3
import cv2,numpy as np

O=Path(__file__).resolve().parent;W=O.parents[2]
OLD=O.parent/'20261119-181852-nr-same-frame-reflection-lineage-ffb239'
E=W/'docs/acceptance/nr/evidence/2026-11-19/player-reflection-same-frame-lineage'
read=lambda p:json.loads(p.read_bytes())
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import artifact_budget
budget=artifact_budget.check(W/'build',run=O,planned=16_000_000)
assert budget['allowed'],budget
E.mkdir(parents=True,exist_ok=True)
req=read(O/'request.json');receipt=read(O/'capture/receipt.json')
assert sha(Path(receipt['capture']['path']))==receipt['capture']['sha256']
assert sha(Path(req['captureRequest']['source']['path']))==req['playerSha256']
host=Path(req['captureRequest']['source']['path']).parent
assert {p.name:sha(p) for p in (host/'shaders').glob('*.spv')}==req['shaders']
for name,source in {'player-result.json':O/'player/result.json','player-consumer.asm':O/'player/consumer.asm',
    'capture-receipt.json':O/'capture/receipt.json','native-sampling.json':OLD/'native-sampling.json'}.items():
    shutil.copyfile(source,O/name)
tapRecords={}
for name,root,record in (
    ('nativeOutput',OLD/'native',read(OLD/'native/result.json')['stages']['filterOutput']),
    ('nativeConfidence',OLD/'native',read(OLD/'native/result.json')['stages']['consumerConfidence']),
    ('playerOutput',O/'player',read(O/'player/result.json')['stages']['filterOutput'])):
    target=name+'.zlib';shutil.copyfile(root/record['file'],O/target)
    tapRecords[name]=dict(record,archiveFile=target)
write(O/'tap-source-records.json',tapRecords)
sourceFiles={'ProjectedScreenReflectionGpu.cpp':W/'src/render/ProjectedScreenReflectionGpu.cpp',
    'native-reflection-temporal.md':W/'docs/acceptance/nr/reflection-temporal.md',
    'native-reflection-bindings.md':W/'docs/acceptance/nr/native-reflection-bindings.md'}
for name,path in sourceFiles.items():shutil.copyfile(path,O/name)
from io import BytesIO
oldEvidence=W/'docs/acceptance/nr/evidence/2026-11-19/reflection-stage-lineage'
oldQualification=read(oldEvidence/'qualification.json')
oldArchive=oldEvidence/'validation.zip'
assert sha(oldArchive)==oldQualification['validation']['archiveSha256']
with ZipFile(oldArchive) as z:
    oldValues=np.load(BytesIO(z.read('stage-points.npz')),allow_pickle=False)
    i=np.flatnonzero((oldValues['centerFloor_xy']==[632,568]).all(axis=1))
    assert len(i)==1
    oldColour=oldValues['centerFloor_firstTrace'][i[0],1]
currentValues=np.load(O/'stage-regions.npz',allow_pickle=False)
currentColour=currentValues['centerFloor_trace'][568-495,632-505,1]
np.testing.assert_array_equal(oldColour,currentColour)
write(O/'content-control.json',dict(filterXY=[632,568],displayXY=[1265,1137],
    previousComponentColour=oldColour.tolist(),currentJointColour=currentColour.tolist(),
    exact=True,previousEvidenceSha256=sha(oldArchive),
    scope='The same ray-colour discrepancy existed in the prior environment component. Receiving-surface depth alignment does not establish identical reflected objects across the whole region.'))
runtime=read(O/'capture/runtime.json')
assert not runtime['presentationErrors'] and not runtime['scriptErrors']
write(O/'runtime-summary.json',{k:runtime[k] for k in ('presentationErrors','scriptErrors','renderProgress','fixedSteps')})
conn=sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True);conn.row_factory=sqlite3.Row
jobs=[dict(r) for r in conn.execute('select id,task,state,exit_code,reason,wait_seconds,run_seconds from jobs where output=?',(str(O),))]
assert len(jobs)==2 and all(j['state']=='succeeded' and j['exit_code']==0 for j in jobs)
write(O/'queue.json',jobs)
members=['worker.py','batch.py','score_frames.py','analyze.py','archive.py','verify.py','measure_reference.py',
    'stage-regions.npz','target-crops.npz','stage-analysis.json','frame-identity.json','request.json',
    'player-result.json','player-consumer.asm','capture-receipt.json','native-sampling.json',
    'task-card.json','queue.json','runtime-summary.json','content-control.json',
    'read_worklist.py','worklist.json','worklist.zlib','hdr-before.zlib','tap-source-records.json',
    'nativeOutput.zlib','nativeConfidence.zlib','playerOutput.zlib',*sourceFiles]
write(O/'manifest.json',{name:sha(O/name) for name in members})
verification=subprocess.run([sys.executable,str(O/'verify.py')],capture_output=True,text=True,check=True)
(O/'verification.log').write_text(verification.stdout,encoding='utf-8');members+=['manifest.json','verification.log']
with ZipFile(E/'validation.zip','w',ZIP_DEFLATED,compresslevel=9) as archive:
    for name in members:archive.write(O/name,name)
assert (E/'validation.zip').stat().st_size<8*2**20
with ZipFile(E/'validation.zip') as z:
    assert z.testzip() is None
    assert all(sha256(z.read(n)).hexdigest()==sha(O/n) for n in members)
    fresh=O/'isolated-verification';fresh.mkdir(exist_ok=True);z.extractall(fresh)
check=subprocess.run([sys.executable,str(fresh/'verify.py')],capture_output=True,text=True,check=True)
(O/'isolated-verification.log').write_text(check.stdout,encoding='utf-8')
analysis=read(O/'stage-analysis.json');frames=read(O/'frame-identity.json')
stageValues=np.load(O/'stage-regions.npz',allow_pickle=False)
baseline=read(W/'docs/acceptance/nr/evidence/2026-11-19/reflection-confidence-lod/qualification.json')
nativeDisplay=cv2.cvtColor(cv2.imread(baseline['reference']),cv2.COLOR_BGR2RGB)
playerDisplay=cv2.cvtColor(cv2.imread(str(O/'capture/frames/frame_000001.png')),cv2.COLOR_BGR2RGB)
images={}
for region in ('centerFloor','cyanRing'):
    x,y,u,v=analysis['regions'][region]['bounds'];width,height=(u-x)*2,(v-y)*2
    columns=[]
    for stage,title in (('trace','RAY COLOR'),('filterInput','BOUND FILTER INPUT'),('filtered','FILTERED COLOR'),('display','FINAL DISPLAY')):
        panels=[]
        for device,label in enumerate(('NATIVE','PLAYER')):
            if stage=='display':rgb=(nativeDisplay if device==0 else playerDisplay)[y*2:v*2,x*2:u*2]
            else:
                raw=stageValues[region+'_'+stage][...,device,:]
                rgb=np.clip(np.rint(raw*255),0,255).astype('u1')
                rgb=cv2.resize(rgb,(width,height),interpolation=cv2.INTER_NEAREST)
            panel=np.full((height+28,width,3),24,'u1');panel[28:]=rgb
            cv2.putText(panel,label,(6,19),cv2.FONT_HERSHEY_SIMPLEX,.45,(235,235,235),1,cv2.LINE_AA)
            panels.append(panel)
        header=np.full((30,width,3),24,'u1')
        cv2.putText(header,title,(6,21),cv2.FONT_HERSHEY_SIMPLEX,.4,(235,235,235),1,cv2.LINE_AA)
        columns.append(np.concatenate((header,*panels),axis=0))
    name=region+'-stages.png'
    cv2.imwrite(str(E/name),cv2.cvtColor(np.concatenate(columns,axis=1),cv2.COLOR_RGB2BGR))
    images[name]=sha(E/name)
q=dict(status='same-frame-input-deficit-attributed-with-consumer-witness',diagnosticUnitComplete=True,
    visualAcceptancePassed=False,productionChanged=False,baseCommit=req['baseCommit'],
    previousEvidenceCommit='8f3db21',source=dict(playerSha256=req['playerSha256'],
        traceShader=req['playerTraceShader'],filterShader=req['filterShader'],
        projectSha256=req['projectSha256'],levelSha256=req['levelSha256'],
        capture=receipt['capture'],binaryAnd895ShadersExact=True),
    maintenance=req.get('maintenance',read(O/'task-card.json')['maintenance']),
    analysis=analysis,frames=frames,queue=jobs,
    conclusion=dict(earliestObservedDeficit='ray color; retained in actual filter input',
        consumerMixVerifiedAt=[1265,1137],globalConsumerParityProven=False,
        nextHypothesis='Qualify the projected producer history, sampling positions and missing reflection-specific temporal composition before grouped candidate validation.'),
    limitations=['Vulkan pixel-history colours contain unavailable-value sentinels; actual texture readback and a complete read-only shader trace qualify the traced anchor instead.',
        'Only one Player consumer invocation was traced. Four neighbourhoods were read from the actual bound texture.',
        'The joint Player scene contains an actor absent from the native reference. Receiving-depth alignment does not prove reflected-object equivalence.',
        'Native ideal interpolation and full-display reference differences retain their prior scope.',
        'Native-incident substitution at the mix node is diagnostic and is not an implemented repair.',
        'Full history colour and mip readbacks remain in the managed task; the compact archive retains source hashes and aligned stage data.'],
    gates=dict(ssimMinimum=.95,luminanceRelativeMaximum=.1,newOverOneMaximum=0,frozenFourFrames='pixel-identical'),
    worklist=read(O/'worklist.json'),contentControl=read(O/'content-control.json'),
    budget=budget,images=images,verification=[verification.stdout.strip(),check.stdout.strip()],
    validation=dict(archiveSha256=sha(E/'validation.zip'),files={name:sha(O/name) for name in members}))
write(E/'qualification.json',q)
print(verification.stdout.strip());print(check.stdout.strip());print('Archive bytes:',(E/'validation.zip').stat().st_size)
