"""Independently recompute same-frame stage attribution without GPU captures."""
from pathlib import Path
from hashlib import sha256
import json
import numpy as np
from measure_reference import measure

O=Path(__file__).resolve().parent
read=lambda n:json.loads((O/n).read_bytes())
manifest=read('manifest.json')
for name,digest in manifest.items():assert sha256((O/name).read_bytes()).hexdigest()==digest,name
a=read('stage-analysis.json');p=read('player-result.json');f=read('frame-identity.json')
work=read('worklist.json')
assert work['status']=='qualified-same-capture-worklist-and-consumer-before'
assert work['traceEvent']==p['traceEvent'] and work['traceShader']==p['stages']['trace']['shaderSha256']
import zlib
raw=zlib.decompress((O/'worklist.zlib').read_bytes())
assert sha256(raw).hexdigest()==work['sha256']==work['beforeSha256']
words=np.frombuffer(raw,'<u4')[:work['dispatch'][0]]
tiles=np.stack([words>>16,words&65535],axis=-1)
assert len(np.unique(tiles,axis=0))==work['activeTiles']==160*90
assert ((tiles[:,0]<160)&(tiles[:,1]<90)).all()
assert all(w['covered'] for w in work['anchors'])
before=work['consumerBefore']
payload=zlib.decompress((O/before['file']).read_bytes())
assert sha256(payload).hexdigest()==before['sha256']
assert before['event']==p['consumers'][0]['event']-1
assert before['resource']==p['consumerHdrTarget']
req=read('request.json');receipt=read('capture-receipt.json')
assert receipt['status']=='captured' and receipt['capture_frame']==p['frameNumber']==1
assert receipt['source']['sha256']==req['playerSha256']
for name,digest in req['diagnosticScripts'].items():assert sha256((O/name).read_bytes()).hexdigest()==digest
assert p['stages']['trace']['shaderSha256']==req['playerTraceShader']
assert p['stages']['filter']['shaderSha256']==req['filterShader']
assert p['consumers'][0]['filterReadback']['fullSha256']==p['stages']['filterOutput']['fullSha256']
assert any(b['resource']==p['filterOutputResource'] for b in p['consumers'][0]['bindings'].values())
assert any(c['rgbSha256']==a['frameIdentity']['playerDisplayRgbSha256'] and
           c['resource']==a['frameIdentity']['playerDisplayResource'] for c in p['finalCandidates'])
assert f['rows'][1]['rgbSha256']==a['frameIdentity']['playerDisplayRgbSha256']
data=np.load(O/'stage-regions.npz',allow_pickle=False)
control=read('content-control.json')
np.testing.assert_array_equal(control['currentJointColour'],data['centerFloor_trace'][568-495,632-505,1])
np.testing.assert_array_equal(control['previousComponentColour'],control['currentJointColour'])
tapRecords=read('tap-source-records.json');tapImages={}
for name,record in tapRecords.items():
    encoded=(O/record['archiveFile']).read_bytes()
    assert sha256(encoded).hexdigest()==record['encodedSha256']
    raw=zlib.decompress(encoded);assert sha256(raw).hexdigest()==record['sha256']
    x,y,u,v=record['rect']
    if name=='nativeOutput':
        words=np.frombuffer(raw,'<u4').reshape(v-y,u-x);channels=[]
        for shift,mantissa in ((0,6),(11,6),(22,5)):
            value=words>>shift;exponent=((value>>mantissa)&31).astype('i4')
            fraction=(value&((1<<mantissa)-1))/float(1<<mantissa)
            channels.append(np.where(exponent==0,np.ldexp(fraction,-14),np.ldexp(1+fraction,exponent-15)))
        values=np.stack(channels,axis=-1)
    elif name=='nativeConfidence':values=np.frombuffer(raw,'u1').reshape(v-y,u-x,1)/255.
    else:values=np.frombuffer(raw,'<f4').reshape(v-y,u-x,4)
    if record['nativeStorageFlip']:values=values[::-1];y,v=record['height']-v,record['height']-y
    tapImages[name]=(values,[x,y,u,v])
weights=np.array([.2126,.7152,.0722])
for region,expected in a['regions'].items():
    depth=data[region+'_depth'];confidence=data[region+'_confidence']
    valid=np.isfinite(depth).all(axis=-1)&(abs(depth[...,0]-depth[...,1])<=.02)&(confidence>0).all(axis=-1)
    assert int(valid.sum())==expected['matchedDepthAndBothHit']
    for stage,stats in expected['stages'].items():
        values=data[region+'_'+stage][valid]@weights
        np.testing.assert_allclose(np.corrcoef(values.T)[0,1],stats['lumaCorrelation'],rtol=0,atol=1e-12)
        np.testing.assert_allclose(np.median(values,axis=0),stats['medianNativePlayer'],rtol=0,atol=1e-12)
        np.testing.assert_allclose(abs(values[:,0]-values[:,1]).mean(),stats['meanAbsoluteLumaDifference'],rtol=0,atol=1e-12)
    changed=[int(np.any(data[region+'_trace'][...,i,:]!=data[region+'_filterInput'][...,i,:],axis=-1)[valid].sum()) for i in (0,1)]
    assert changed==expected['rawToFilterChangedNativePlayer']
for witness in a['witnesses']:
    assert witness['depthMatched']
    for device in ('native','player'):
        s=witness[device]
        values,bounds=tapImages[device+'Output'];x,y,_,_=bounds
        rawTaps=np.array([values[yy-y,xx-x] for xx,yy in witness['filterXY']])
        np.testing.assert_array_equal(rawTaps,s['taps'])
        np.testing.assert_allclose(np.array(witness['weights'])@s['taps'],s['bilinear'],rtol=0,atol=1e-12)
        if device=='native':
            values,bounds=tapImages['nativeConfidence'];x,y,_,_=bounds
            np.testing.assert_array_equal([values[yy-y,xx-x,0] for xx,yy in witness['filterXY']],s['confidenceTaps'])
            np.testing.assert_allclose(np.array(witness['weights'])@s['confidenceTaps'],s['bilinearConfidence'],rtol=0,atol=1e-12)
v=a['playerConsumerWitness'];state=p['consumerDebug']['finalState']
nativeWitness=read('native-sampling.json')
np.testing.assert_array_equal(a['witnesses'][0]['native']['pixelHistoryShaderOutput'],nativeWitness['witnesses'][0]['actualShaderOutput'])
nativeIncident=np.array(nativeWitness['debug']['colorSample'])
np.testing.assert_allclose(v['nativeIncidentSubstitutionAtMix'],
    np.array(v['beautyBeforeMix'])+np.array(v['materialResponse'])*nativeIncident-v['previousAmbientSpecular'],rtol=0,atol=1e-12)
assembly=(O/'player-consumer.asm').read_text()
assert 'float4 _17687 = sampleComputedScreenReflection(param@343);' in assembly
assert 'float3 _17723 = GLSL.std.450::FMix(_17717, _17719, _17722);' in assembly
np.testing.assert_array_equal(v['sampledReflection'],state['_17687'])
np.testing.assert_array_equal(v['mixedIncident'],state['_17723'][:3])
np.testing.assert_array_equal(v['shaderOutput'],state['_18629'])
sample=np.array(v['sampledReflection']);response=np.array(v['materialResponse'])
np.testing.assert_allclose(sample,a['witnesses'][0]['player']['bilinear'],rtol=0,atol=1e-6)
np.testing.assert_allclose(v['mixedIncident'],np.array(v['probeIncident'])*(1-sample[3])+sample[:3]*sample[3],rtol=0,atol=1e-6)
np.testing.assert_allclose(v['reflectedContribution'],response*np.array(v['mixedIncident']),rtol=0,atol=1e-6)
np.testing.assert_allclose(v['beautyAfterMix'],np.array(v['beautyBeforeMix'])+
    np.array(v['reflectedContribution'])-v['previousAmbientSpecular'],rtol=0,atol=1e-6)
np.testing.assert_array_equal(np.array(v['shaderOutput'],dtype='f2').astype('f8'),a['witnesses'][0]['player']['quantizedHdr'])
native=read('native-sampling.json')['debug']['colorSample']
counter=np.array(v['beautyBeforeMix'])+response*np.array(native)-v['previousAmbientSpecular']
np.testing.assert_allclose(counter,v['nativeIncidentSubstitutionAtMix'],rtol=0,atol=1e-12)
ref=np.array(a['witnesses'][0]['native']['pixelHistoryShaderOutput'][:3])
reduction=1-np.mean(abs(counter-ref))/np.mean(abs(np.array(v['beautyAfterMix'])-ref))
np.testing.assert_allclose(reduction,v['meanAbsoluteRgbResidualReduction'],rtol=0,atol=1e-12)
targets=np.load(O/'target-crops.npz',allow_pickle=False)
control=read('content-control.json')
np.testing.assert_array_equal(control['previousComponentColour'],control['currentJointColour'])
np.testing.assert_array_equal(control['currentJointColour'],data['centerFloor_trace'][568-495,632-505,1])
for frame in f['rows']:
    assert frame['fullFrameMatchesFe5Control'] and frame['bgraRawSha256']==frame['expectedFe5Control']['raw']
    for region in ('centerFloor','cyanRing'):
        scored=measure(targets[f"frame{frame['frameIndex']}_{region}"],targets['reference_'+region])
        for field in ('ssim','medianLumaRelativeError'):
            np.testing.assert_allclose(scored[field],frame['regions'][region][field],rtol=0,atol=1e-10)
print('PASS: captured frame identity and bindings; two depth masks and ten stage metrics; four tap neighbourhoods; traced mix, response and half-float output; four regional image scores.')
print('OPEN: original visual and frozen-frame gates; native full-display equivalence; root repair candidate validation.')
