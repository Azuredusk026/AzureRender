SPIR-V 1.0 module, <id> bound of 18665

Generator: Shaderc over Glslang from Google - Contact David Neto, dneto@google.com
Generator Version: 11

Capability(Shader);
Capability(ImageQuery);
Capability(ShaderNonUniform);
Capability(RuntimeDescriptorArray);
Capability(SampledImageArrayNonUniformIndexing);

Extension("SPV_EXT_descriptor_indexing");


MemoryModel(Logical, GLSL450);

EntryPoint(Fragment, main, "main", {
    instanceObjectShadow, 
    gl_FragCoord, 
    worldPosition, 
    worldNormal, 
    outputDisplayMask, 
    worldTangent, 
    instanceFaceFrame, 
    gl_FrontFacing, 
    textureCoordinate, 
    shadowPositions, 
    vertexColorRgb, 
    vertexColorAlpha, 
    outputColor, 
    outputNormal, 
    opacityCoordinate, 
    instanceFaceDirection, 
    eyebrowRegion
  });

ExecutionMode(main, OriginUpperLeft);
ExecutionMode(main, EarlyFragmentTests);

Source(GLSL, 450);
SourceExtension("GL_EXT_nonuniform_qualifier");
SourceExtension("GL_EXT_samplerless_texture_functions");
SourceExtension("GL_GOOGLE_cpp_style_line_directive");
SourceExtension("GL_GOOGLE_include_directive");




struct CharacterDiffuseIllumination {
  float3 ambient;
  float3 direct;
}
struct CharacterDiffuseResponse {
  float3 color;
  float litMask;
  float aoMask;
}
struct SpecularRampCoordinates {
  float2 uv;
  float lobe;
  float distribution;
}
struct LineLightGeometry {
  float3 direction;
  float factor;
}
struct CharacterProjectedHairCoordinates {
  float2 uv;
  float edgeFade;
  float secondaryLobe;
}
struct CharacterProjectedHairEnergy {
  float3 q;
  float3 primary;
  float3 secondary;
}
struct CharacterEyeCoordinates {
  float2 baseUv;
  float3 lightingNormal;
  float2 matcapUv;
  float whiteMask;
}
struct IrradianceClipmapLayerSample {
  float3 amplitude;
  float4 red;
  float4 green;
  float4 blue;
}
struct IrradianceClipmapResult {
  float4x3 coefficients;
  float3x3 alpha;
}
struct ObjectShadowRecord {
  float4x4 worldToUnit;
  float4 biasAndFilter;
  float4 atlasRect;
  float4 receiverSampling;
}
struct ClusterLight {
  float4 positionRadius;
  float4 colorIntensity;
  float4 directionOuter;
  float4 coneType;
  float4[3] boxRows;
  float4 boxParameters;
  float4 characterResponse;
}
struct SceneLightSample {
  float3 incoming;
  float3 direction;
  float distanceSquared;
  float attenuation;
}
struct ProjectedHairProfile {
  float4 shiftsIntensityRange;
  float4 edgeNormalDirection;
  float4 secondaryColor;
  float4 objectX;
  float4 objectY;
  float4 objectZ;
}
struct EyeSurfaceProfile {
  float4 shape;
  float4 highlight;
  float4 scattering;
  float4 matcap;
  float4 directWeights;
  float4 uvScaleOffset;
}
struct ProjectedHairIncident {
  float3 radiance;
  float4 response;
  float4 mainRadiance;
  float specularScale;
  float ambientOcclusion;
  float characterVisibility;
}
struct PackedMaterialSurfaceProfile {
  float4[22] rows;
}
const float2x2 _4296 = {{0.0000, 0.0000}, {0.0000, 0.0000}};
const float2[12] _4741 = {{0.5000, 0.0000}, {-0.5000, 0.0000}, {0.0000, 0.5000}, {0.0000, -0.5000}, {1.0000, 0.0000}, {-1.0000, 0.0000}, {0.0000, 1.0000}, {0.0000, -1.0000}, {0.7071, 0.7071}, {-0.7071, 0.7071}, {0.7071, -0.7071}, {-0.7071, -0.7071}};
UniformConstant StorageImage<float, 2D>* computedScreenReflection : [[DescriptorSet(0), Binding(37), NonWritable]];
struct ReflectionField : [[BufferBlock]] {
  float4[] probeFieldRows : [[Offset(0), NonWritable]] : [[ArrayStride(16)]];
}
Uniform ReflectionField* ReflectionField_var : [[DescriptorSet(0), Binding(33), NonWritable]];
const float3x3 _5780 = {{0.0000, 0.0000, 0.0000}, {0.0000, 0.0000, 0.0000}, {0.0000, 0.0000, 0.0000}};
struct ClusterHeaderBuffer : [[BufferBlock]] {
  uint2[] clusters : [[Offset(0), NonWritable]] : [[ArrayStride(8)]];
}
Uniform ClusterHeaderBuffer* clusterHeaderData : [[DescriptorSet(0), Binding(15), NonWritable]];
const uint4[16] _6643 = {{3201081267, 1063955090, 3211864058, 3201061344}, {1040121934, 3212706305, 1064440302, 3208959771}, {1062876132, 1057349892, 3183535000, 3211652203}, {3194671333, 1064906152, 1051762308, 1050048288}, {3209018472, 1059231696, 3211425662, 1055545736}, {1061876180, 3206286094, 3209740500, 3210808912}, {3205757713, 1062266235, 3200514852, 1049474200}, {3210003689, 3205389102, 1064931168, 1061267692}, {1062128548, 1058465561, 1055059832, 3212419372}, {1056005468, 1063372016, 1057592576, 3203566922}, {3198206253, 3211988469, 3196561928, 3201728006}, {3211914230, 3198645051, 1061863138, 1044609992}, {3191700082, 3212547147, 3195515288, 1065303976}, {3211725472, 1052196876, 3209717972, 1063916682}, {3212796835, 1032676071, 1045209904, 1061769832}, {1050459336, 1064547749, 1041451160, 3188745312}};
struct ShadowBounds : [[BufferBlock]] {
  float2[] values : [[Offset(0), NonWritable]] : [[ArrayStride(8)]];
}
Uniform ShadowBounds* shadowBounds : [[DescriptorSet(0), Binding(20), NonWritable]];
struct CameraData : [[Block]] {
  float4 cameraPosition : [[Offset(0)]];
  float4 cameraForward : [[Offset(16)]];
  float4 clusterGrid : [[Offset(32)]];
  float4 clusterDepth : [[Offset(48)]];
  float4 clusterLighting : [[Offset(64)]];
  float4 cascadeSplits : [[Offset(80)]];
  float4 renderingParameters : [[Offset(96)]];
  float4 showcaseParameters : [[Offset(112)]];
  float4 qaParameters : [[Offset(128)]];
  float4 faceLightDirection : [[Offset(144)]];
  float4 faceSdfParameters : [[Offset(160)]];
  float4 faceSdfShadowColor : [[Offset(176)]];
  float4 mainLightDirection : [[Offset(192)]];
  float4 cascadeDepthRanges : [[Offset(208)]];
  float4 skyRight : [[Offset(224)]];
  float4 skyUp : [[Offset(240)]];
  float4 skyForward : [[Offset(256)]];
  float4 skyColor : [[Offset(272)]];
  float4 skyParameters : [[Offset(288)]];
  float4 probeCenter : [[Offset(304)]];
  float4 probeHalfExtents : [[Offset(320)]];
  float4 probeCapture : [[Offset(336)]];
  float4 probeParameters : [[Offset(352)]];
  float4 irradianceOriginSpacing : [[Offset(368)]];
  float4 irradianceDimensionsEnabled : [[Offset(384)]];
  float4 irradianceParameters : [[Offset(400)]];
  float4 cameraRight : [[Offset(416)]];
  float4 cameraUp : [[Offset(432)]];
  float4x4 screenReflectionWorldToClip : [[ColMajor, MatrixStride(16), Offset(448)]];
  float4 screenReflectionTrace : [[Offset(512)]];
  float4 screenReflectionQuality : [[Offset(528)]];
  float4 nprDirectionBias : [[Offset(544)]];
  float4 nprGainFloor : [[Offset(560)]];
  float4 nprAmbientColor : [[Offset(576)]];
  float4 nprComposition : [[Offset(592)]];
  float4 nprMainRadiance : [[Offset(608)]];
  float4 nprLightingParameters : [[Offset(624)]];
  float4 cascadeWorldDiameters : [[Offset(640)]];
  float4 unlitTimeExposure : [[Offset(656)]];
  float4 unlitColorGain : [[Offset(672)]];
  uint4 referenceControl : [[Offset(768)]];
}
Uniform CameraData* camera : [[DescriptorSet(0), Binding(0)]];
bool azureOrdinaryOpaque = SpecConstantFalse() : [[SpecId(0)]];
struct MaterialData : [[Block]] {
  float alphaCutoff : [[Offset(0)]];
  int alphaMode : [[Offset(4)]];
  float emissiveStrength : [[Offset(8)]];
  float showcasePlatform : [[Offset(12)]];
  float4 aoColor : [[Offset(16)]];
  float4 lamShadowColor : [[Offset(32)]];
  float4 matcapColor : [[Offset(48)]];
  float4 hairParameters : [[Offset(64)]];
  float4 styleParameters : [[Offset(80)]];
  float4 featureParameters : [[Offset(96)]];
  uint materialClass : [[Offset(112)]];
  uint materialFeatures : [[Offset(116)]];
  uint materialProfileVersion : [[Offset(120)]];
  uint materialPadding : [[Offset(124)]];
  uint textureBase : [[Offset(136)]];
  float nodeOpacity : [[Offset(140)]];
}
PushConstant MaterialData* material;
Input uint* instanceObjectShadow : [[Location(15), Flat]];
UniformConstant Image<float, 2D>* referenceObjectVisibility : [[DescriptorSet(0), Binding(45)]];
Input float4* gl_FragCoord : [[BuiltIn(FragCoord)]];
UniformConstant Image<uint, 2D>* referenceObjectIds : [[DescriptorSet(0), Binding(46)]];
UniformConstant Image<float, 2D>* mainShadowDepth : [[DescriptorSet(0), Binding(9)]];
UniformConstant sampler* sharedDepthSampler : [[DescriptorSet(0), Binding(28)]];
Input float3* worldPosition : [[Location(3)]];
Input float3* worldNormal : [[Location(0)]];
UniformConstant Image<float, 2D>* objectShadowDepth : [[DescriptorSet(0), Binding(29)]];
struct PackedMaterialSurfaceProfile {
  float4[22] rows : [[Offset(0)]] : [[ArrayStride(16)]];
}
struct MaterialSurfaceProfiles : [[BufferBlock]] {
  PackedMaterialSurfaceProfile[] profiles : [[Offset(0), NonWritable]] : [[ArrayStride(352)]];
}
Uniform MaterialSurfaceProfiles* materialSurfaceProfiles : [[DescriptorSet(0), Binding(27), NonWritable]];
Output float4* outputDisplayMask : [[Location(2)]];
Input float4* worldTangent : [[Location(1)]];
UniformConstant SampledImage<float, 2D>[]* textureArray : [[DescriptorSet(0), Binding(1)]];
Private float2* projectedHairUvDx;
Private float2* projectedHairUvDy;
Private float3* projectedHairNormalDx;
Private float3* projectedHairNormalDy;
Private float4* projectedHairTangentDx;
Private float4* projectedHairTangentDy;
Private float3* projectedHairPositionDx;
Private float3* projectedHairPositionDy;
Input float4x4* instanceFaceFrame : [[Location(10), Flat]];
Input bool* gl_FrontFacing : [[BuiltIn(FrontFacing)]];
const uint azureFixedMaterialFeatureMask = 0 : [[SpecId(2)]];
const uint _8296 = uint _8296(azureFixedMaterialFeatureMask);
const uint azureFixedMaterialFeatureValue = 0 : [[SpecId(3)]];
Input float2* textureCoordinate : [[Location(2)]];
const uint _8331 = uint _8331(azureFixedMaterialFeatureMask);
const CharacterProjectedHairEnergy _8376 = {{0.0000, 0.0000, 0.0000}, {0.0000, 0.0000, 0.0000}, {0.0000, 0.0000, 0.0000}};
const uint _8407 = uint _8407(azureFixedMaterialFeatureMask);
const ProjectedHairIncident _8522 = {{1.0000, 1.0000, 1.0000}, {0.0000, 0.0000, 0.0000, 0.0000}, {0.0000, 0.0000, 0.0000, 0.0000}, 1.0000, 1.0000, 1.0000};
const uint _8638 = uint _8638(azureFixedMaterialFeatureMask);
const float3[10] _8800 = {{0.4500, 0.4500, 0.4500}, {0.9600, 0.5800, 0.4800}, {1.0000, 0.7800, 0.6600}, {0.8200, 0.2000, 0.4200}, {0.2000, 0.5800, 0.9200}, {0.7800, 0.8200, 0.8800}, {0.4500, 0.9200, 0.9600}, {0.7400, 0.3400, 0.9200}, {1.0000, 0.3200, 0.0800}, {0.1200, 0.7800, 0.5800}};
const uint _8812 = uint _8812(azureFixedMaterialFeatureMask);
const uint azureFixedMaterialClass = 4294967295 : [[SpecId(1)]];
const bool _8844 = azureFixedMaterialClass != 4294967295;
Input float4[4]* shadowPositions : [[Location(4)]];
Private float* shadowReceiverCurvature;
Private float2[4]* shadowReceiverGradients;
struct IrradianceCells : [[BufferBlock]] {
  float4[] irradianceCells : [[Offset(0), NonWritable]] : [[ArrayStride(16)]];
}
Uniform IrradianceCells* IrradianceCells_var : [[DescriptorSet(0), Binding(24), NonWritable]];
UniformConstant SampledImage<float, 3D>[6]* irradianceClipmapTextures : [[DescriptorSet(0), Binding(32)]];
UniformConstant SampledImage<float, 2D>* overlaySceneDepth : [[DescriptorSet(0), Binding(18)]];
Input float3* vertexColorRgb : [[Location(8), Component(1)]];
Input float* vertexColorAlpha : [[Location(0), Component(3)]];
const uint _10745 = uint _10745(azureFixedMaterialFeatureMask);
const bool _10766 = azureFixedMaterialClass != 4294967295;
const bool _10782 = azureFixedMaterialClass != 4294967295;
Output float4* outputColor : [[Location(0)]];
Output float4* outputNormal : [[Location(1)]];
const uint _10936 = uint _10936(azureFixedMaterialFeatureMask);
const bool _10957 = azureFixedMaterialClass != 4294967295;
const bool _10973 = azureFixedMaterialClass != 4294967295;
struct ClusterIndexBuffer : [[BufferBlock]] {
  uint[] indices : [[Offset(0), NonWritable]] : [[ArrayStride(4)]];
}
Uniform ClusterIndexBuffer* clusterIndexData : [[DescriptorSet(0), Binding(16), NonWritable]];
struct ClusterLight {
  float4 positionRadius : [[Offset(0)]];
  float4 colorIntensity : [[Offset(16)]];
  float4 directionOuter : [[Offset(32)]];
  float4 coneType : [[Offset(48)]];
  float4[3] boxRows : [[Offset(64)]] : [[ArrayStride(16)]];
  float4 boxParameters : [[Offset(112)]];
  float4 characterResponse : [[Offset(128)]];
}
struct SceneLightBuffer : [[BufferBlock]] {
  ClusterLight[] lights : [[Offset(0), NonWritable]] : [[ArrayStride(144)]];
}
Uniform SceneLightBuffer* sceneLightData : [[DescriptorSet(0), Binding(14), NonWritable]];
const uint _11434 = uint _11434(azureFixedMaterialFeatureMask);
Input float3* opacityCoordinate : [[Location(14)]];
const bool _11494 = azureFixedMaterialClass != 4294967295;
const uint _11532 = uint _11532(azureFixedMaterialFeatureMask);
const uint _11568 = uint _11568(azureFixedMaterialFeatureMask);
const bool _11708 = azureFixedMaterialClass != 4294967295;
const uint _11981 = uint _11981(azureFixedMaterialFeatureMask);
const bool _12020 = azureFixedMaterialClass != 4294967295;
const bool _12200 = azureFixedMaterialClass != 4294967295;
const bool _12294 = azureFixedMaterialClass != 4294967295;
const bool _12311 = azureFixedMaterialClass != 4294967295;
const bool _12329 = azureFixedMaterialClass != 4294967295;
const bool _12369 = azureFixedMaterialClass != 4294967295;
const bool _12386 = azureFixedMaterialClass != 4294967295;
const bool _12407 = azureFixedMaterialClass != 4294967295;
const bool _12424 = azureFixedMaterialClass != 4294967295;
const bool _12442 = azureFixedMaterialClass != 4294967295;
const bool _12467 = azureFixedMaterialClass != 4294967295;
const bool _12773 = azureFixedMaterialClass != 4294967295;
const bool _12793 = azureFixedMaterialClass != 4294967295;
const bool _12893 = azureFixedMaterialClass != 4294967295;
const bool _12910 = azureFixedMaterialClass != 4294967295;
const bool _12928 = azureFixedMaterialClass != 4294967295;
const bool _13029 = azureFixedMaterialClass != 4294967295;
const bool _13046 = azureFixedMaterialClass != 4294967295;
const bool _13064 = azureFixedMaterialClass != 4294967295;
const bool _13082 = azureFixedMaterialClass != 4294967295;
const bool _13122 = azureFixedMaterialClass != 4294967295;
const bool _13297 = azureFixedMaterialClass != 4294967295;
Input float4* instanceFaceDirection : [[Location(9), Flat]];
const bool _13735 = azureFixedMaterialClass != 4294967295;
const uint _15138 = uint _15138(azureFixedMaterialFeatureMask);
const bool _15478 = azureFixedMaterialClass != 4294967295;
const bool _15497 = azureFixedMaterialClass != 4294967295;
const bool _15531 = azureFixedMaterialClass != 4294967295;
const bool _15549 = azureFixedMaterialClass != 4294967295;
const bool _15648 = azureFixedMaterialClass != 4294967295;
const bool _15743 = azureFixedMaterialClass != 4294967295;
const bool _15761 = azureFixedMaterialClass != 4294967295;
const bool _15780 = azureFixedMaterialClass != 4294967295;
const uint _17334 = uint _17334(azureFixedMaterialFeatureMask);
UniformConstant SampledImage<float, 2DArray>* reflectionProbeTexture : [[DescriptorSet(0), Binding(23)]];
UniformConstant SampledImage<float, 2D>* opaqueSceneColor : [[DescriptorSet(0), Binding(19)]];
const bool _18276 = azureFixedMaterialClass != 4294967295;
const bool _18326 = azureFixedMaterialClass != 4294967295;
Input float* eyebrowRegion : [[Location(8)]];

void main() {
  float2* alphaUvDx;
  float2* alphaUvDy;
  bool* param;
  uint* param@2;
  int* _11467;
  float3* param@3;
  float* param@4;
  bool* eyeRadial;
  uint* _11490;
  uint* _11495;
  uint* param@5;
  float4* baseColor;
  int* _11520;
  bool* param@6;
  uint* param@7;
  float2* param@8;
  float2* param@9;
  float2* param@10;
  int* _11556;
  bool* param@11;
  uint* param@12;
  float2* param@13;
  float2* param@14;
  float2* param@15;
  float2* param@16;
  EyeSurfaceProfile* eyeProfile;
  uint* param@17;
  float2* originalUv;
  float3x3* worldToView;
  CharacterEyeCoordinates* eyeCoordinates;
  float2* param@18;
  float3* param@19;
  float3* param@20;
  float4* param@21;
  float3x3* param@22;
  float* param@23;
  float* param@24;
  bool* eyeNpr;
  bool* multiplyComposite;
  uint* param@25;
  bool* overlayMaterial;
  uint* _11704;
  uint* _11709;
  uint* param@26;
  bool* browOverlay;
  uint* param@27;
  float* basePower;
  float* platformMask;
  float* platformRadius;
  float* contactShadow;
  float* platformRing;
  float* showcasePreset;
  float3* platformPresetTint;
  float* signalRing;
  float* tickAngle;
  float* ticks;
  int* _11870;
  float3* geometricNormal;
  float4* param@28;
  float3* param@29;
  float* param@30;
  float4* param@31;
  float3* param@32;
  float* param@33;
  float3* param@34;
  float* param@35;
  float3* tangent;
  float3* bitangent;
  float3x3* tangentToWorld;
  float4* normalSample;
  float3* sampledNormal;
  float3* shadedNormal;
  float4* hairData;
  bool* param@36;
  uint* param@37;
  float4* _11990;
  float* hairActive;
  uint* _12016;
  uint* _12021;
  float* _12030;
  uint* param@38;
  bool* projectedHair;
  uint* param@39;
  bool* strandDiffuse;
  uint* param@40;
  uint* projectedHairFlags;
  bool* projectedLighting;
  float* projectedDiffuseScale;
  float* _12089;
  uint* param@41;
  float* hairBasePeak;
  float3* hairBaseHue;
  float3* hairBaseNormal;
  float2* param@42;
  ProjectedHairProfile* p;
  uint* param@43;
  float2* param@44;
  float* param@45;
  float* param@46;
  float4* packedMaterial;
  float* physicalAo;
  uint* param@47;
  float4* specularEmissive;
  float* styleStrength;
  float* diffuseBandThreshold;
  bool* sceneCharacter;
  uint* _12196;
  uint* _12201;
  uint* param@48;
  uint* param@49;
  float* bandEnabled;
  float* styleMask;
  uint* param@50;
  uint* param@51;
  float* normalVariance;
  float3* dx;
  float3* dy;
  float* roughness;
  float* metallic;
  float* specularLevel;
  uint* _12290;
  uint* _12295;
  uint* _12307;
  uint* _12312;
  uint* _12325;
  uint* _12330;
  float2* inputProfile;
  float* _12352;
  uint* _12365;
  uint* _12370;
  uint* _12382;
  uint* _12387;
  uint* _12403;
  uint* _12408;
  uint* _12420;
  uint* _12425;
  uint* _12438;
  uint* _12443;
  uint* _12463;
  uint* _12468;
  int* qaEffectMode;
  bool* qaEffectDisabled;
  bool* nprDiffuse;
  uint* param@52;
  float* normalSource;
  float4* clip;
  int2* extent;
  int2* pixel;
  float4* surface;
  float4* param@53;
  float3* offset;
  float3* lightDirection;
  float3* sceneShadowDirection;
  bool* independentNprMain;
  ClusterLight* characterMain;
  float3* fillDirection;
  float3* viewDirection;
  float3* halfDirection;
  float3* reflectionDirection;
  float* diffuse;
  float* fillDiffuse;
  float* shadowVisibility;
  float* param@54;
  float* nprMainShadowVisibility;
  float* keyVisibility;
  uint* _12769;
  uint* _12774;
  uint* _12789;
  uint* _12794;
  float3* keyColor;
  float3* fillColor;
  float3* rimColor;
  float* specularPower;
  float* specularLobe;
  float4* nprParameters;
  float4* rampProfile;
  float* aoSource;
  float* nprBaseAo;
  float* _12862;
  float* _12870;
  bool* specularRamp;
  uint* _12889;
  uint* _12894;
  uint* _12906;
  uint* _12911;
  uint* _12924;
  uint* _12929;
  float3* f0;
  float* param@55;
  float3* rampReflectance;
  float3* rampSample;
  float* rampSpecularLobe;
  SpecularRampCoordinates* coordinates;
  float3* param@56;
  float3* param@57;
  float3* param@58;
  float3* param@59;
  float* param@60;
  float* param@61;
  float* param@62;
  float* param@63;
  float2* uv;
  float3* param@64;
  float3* param@65;
  float* param@66;
  float* normalDotView;
  bool* microfacetSurface;
  uint* _13025;
  uint* _13030;
  uint* _13042;
  uint* _13047;
  uint* _13060;
  uint* _13065;
  uint* _13078;
  uint* _13083;
  float3* fresnel;
  bool* fittedEnvironment;
  uint* _13118;
  uint* _13123;
  float3* environmentResponse;
  float3* _13135;
  float3* _13139;
  float3* param@67;
  float* param@68;
  float* param@69;
  float3* diffuseColor;
  float3* environmentDiffuse;
  float3* param@70;
  float* envMipCount;
  float* specularMip;
  float3* environmentSpecular;
  float3* param@71;
  float3* ambientDiffuse;
  float* environmentLuminance;
  float3* hairAmbientDiffuse;
  float* platformAmbientVisibility;
  float3* ambientSpecular;
  float* toonEnabled;
  float* toonWeight;
  float* rampThresholdOffset;
  float* rampCoordinate;
  float4* faceSdfSample;
  float* faceSdfEligible;
  uint* _13293;
  uint* _13298;
  float* _13307;
  uint* param@72;
  float* faceSdfEnabled;
  float* faceCoordinate;
  float* _13345;
  float* lateralLight;
  float* frontLight;
  float* faceSideBlend;
  float* orientedCoordinate;
  float* faceThreshold;
  float* faceSoftness;
  float* faceIllumination;
  float* faceSdfWeight;
  bool* dualFaceSdf;
  uint* param@73;
  bool* signedMainRamp;
  float3* eyeLight;
  float3* side;
  float3* front;
  float3* projected;
  float3* param@74;
  float3* param@75;
  float* param@76;
  uint* param@77;
  float4* rampInput;
  float3* param@78;
  float3* param@79;
  float* param@80;
  float3* faceLightingNormal;
  float3* param@81;
  float3* param@82;
  float4* param@83;
  float3x3* headFrame;
  float* localLightX;
  float* geometryMix;
  float4* param@84;
  float* param@85;
  float3x3* param@86;
  float3* param@87;
  float* param@88;
  float4* classRampRgba;
  float4* _13550;
  float4* _13564;
  float* param@89;
  float3* classRamp;
  float3* indirectDiffuseNormal;
  float3* param@90;
  float* normalMode;
  float3* param@91;
  float3* param@92;
  float3* param@93;
  float* param@94;
  float3* param@95;
  float3* nprAmbientResponse;
  float3* _13638;
  float4* param@96;
  float* param@97;
  float4* param@98;
  float* param@99;
  float* param@100;
  float* param@101;
  float3* param@102;
  float3* param@103;
  float* characterSceneVisibility;
  float* _13665;
  float3* localCharacterDiffuse;
  bool* localCharacterResponseReady;
  float* projectedVisibility;
  float* projectedOcclusion;
  float* hairViewAlpha;
  uint* encoded;
  uint* _13695;
  uint* param@104;
  float3* param@105;
  float* param@106;
  float* param@107;
  CharacterDiffuseResponse* hairDiffuseResponse;
  float3* param@108;
  float3* param@109;
  float3* param@110;
  float* param@111;
  float* param@112;
  float* param@113;
  float3* indirectChroma;
  uint* _13731;
  uint* _13736;
  float3* param@114;
  float* param@115;
  uint* param@116;
  float* rampLuminance;
  float3* diffuseResponse;
  float* ambientRampVisibility;
  float* diffuseScale;
  float* _13775;
  float3* directDiffuse;
  uint* gridX;
  uint* gridY;
  uint* gridZ;
  float2* screenUv;
  uint* clusterX;
  uint* clusterY;
  float* nearDepth;
  float* farDepth;
  float* viewDepth;
  float* logarithmicDepth;
  uint* clusterZ;
  uint* clusterIndex;
  float3* clusteredDiffuse;
  float3* sceneMainDiffuse;
  float3* clusteredSpecular;
  float3* sceneHairPrimary;
  float3* sceneHairSecondary;
  float3* sceneRim;
  float3* mainHairPrimary;
  float3* mainHairSecondary;
  bool* mainHairAvailable;
  float3* eyeHostDiffuse;
  float3* eyeHostMatcap;
  float4* eyeMatcap;
  float* eyeViewRampAlpha;
  float3* eyeDiffuseMultiplier;
  float* eyeAlphaMultiplier;
  float4* _13924;
  float* viewCoordinate;
  float4* param@117;
  float* param@118;
  float3* param@119;
  float3* param@120;
  float* param@121;
  float* param@122;
  CharacterDiffuseResponse* eyeDiffuseResponse;
  float4* param@123;
  float* param@124;
  float3* param@125;
  float3* param@126;
  float* param@127;
  float* param@128;
  float4* param@129;
  float* param@130;
  float* param@131;
  bool* attenuateEmission;
  uint* param@132;
  bool* characterLightComposition;
  uint* baseReceiverBit;
  uint* receiverRange;
  uint* _14060;
  uint2* lightRange;
  uint* param@133;
  uint* param@134;
  float4* characterBlend;
  uint* sceneLightCount;
  uint* lightOffset;
  uint* lightIndex;
  ClusterLight* light;
  uint* receiverBit;
  bool* colorBlend;
  bool* materialRim;
  bool* screenRim;
  bool* specularOnly;
  SceneLightSample* blendSample;
  ClusterLight* param@135;
  float3* param@136;
  bool* param@137;
  float* weight;
  float* param@138;
  float* param@139;
  float2* param@140;
  bool* transparentHairHighlights;
  int* _14234;
  bool* transparentNprHighlights;
  int* _14271;
  SceneLightSample* sampled;
  ClusterLight* param@141;
  float3* param@142;
  bool* param@143;
  float3* toLight;
  float3* pointDirection;
  float* distanceSquared;
  float* attenuation;
  float3* localLightingNormal;
  float* pointDiffuse;
  float3* radiance;
  bool* facingRim;
  float3* radial;
  float3* _14410;
  float3* param@144;
  float3* param@145;
  float3* param@146;
  float3* param@147;
  float* param@148;
  float* param@149;
  float3* param@150;
  float3* param@151;
  float3* param@152;
  float3* param@153;
  float3* param@154;
  float2* screenNormal;
  float* normalSquared;
  float2* _14478;
  float2* extent@2;
  float2* offset@2;
  float2* halfPixel;
  float2* depthUv;
  float* sceneDepth;
  float* surfaceDepth;
  float3* param@155;
  float* param@156;
  float3* param@157;
  float3* param@158;
  float3* param@159;
  float3* param@160;
  float* param@161;
  float* param@162;
  bool* characterLight;
  LineLightGeometry* line;
  float3* param@163;
  float3* param@164;
  float* param@165;
  float* _14599;
  float2* localResponse;
  float3* wrapNormal;
  float3* characterRadiance;
  float3* _14635;
  float3* param@166;
  float* param@167;
  float2* param@168;
  float* param@169;
  float4* ramp;
  float3* illumination;
  float* selection;
  float* _14709;
  float4* param@170;
  float4* param@171;
  float* param@172;
  float* param@173;
  float* param@174;
  float* param@175;
  float3* param@176;
  float3* localDiffuseResponse;
  float* localCoordinate;
  float4* localDistanceSample;
  float3* param@177;
  float3* param@178;
  float4* param@179;
  float* coordinate;
  uint* param@180;
  float* _14769;
  float* param@181;
  float4* param@182;
  float* param@183;
  float4* param@184;
  float* param@185;
  float* param@186;
  float* param@187;
  float3* param@188;
  float3* param@189;
  bool* composedMain;
  float4* ramp@2;
  CharacterDiffuseResponse* response;
  float4* param@190;
  float* param@191;
  float3* param@192;
  float3* param@193;
  float* param@194;
  float* param@195;
  float4* param@196;
  float* param@197;
  float* param@198;
  float* localCoordinate@2;
  float4* distanceValue;
  float3* param@199;
  float3* param@200;
  float4* param@201;
  float4* localRamp;
  float* param@202;
  float* visibility;
  float3* response@2;
  float3* _14950;
  float4* param@203;
  float* param@204;
  float4* param@205;
  float* param@206;
  float* param@207;
  float* param@208;
  float3* param@209;
  float3* param@210;
  bool* composedMain@2;
  float3* contribution;
  float3* pointHalfDirection;
  float* pointSpecular;
  float3* pointResponse;
  float3* _15030;
  float3* param@211;
  float* param@212;
  float* param@213;
  float* param@214;
  float* param@215;
  float* param@216;
  bool* composedRamp;
  float3* hairRadiance;
  float3* _15108;
  bool* composedHair;
  bool* integrateIncident;
  bool* param@217;
  uint* param@218;
  ProjectedHairIncident* incident;
  CharacterProjectedHairEnergy* energy;
  float2* unusedLine;
  float3* param@219;
  float3* param@220;
  bool* param@221;
  bool* param@222;
  ProjectedHairIncident* param@223;
  float2* param@224;
  float3* param@225;
  float3* param@226;
  bool* param@227;
  float3* highlightNormal;
  float2* param@228;
  float2* lobes;
  float3* param@229;
  float3* param@230;
  float3* param@231;
  float3* param@232;
  float3* param@233;
  float3* param@234;
  float3* param@235;
  float* param@236;
  float* param@237;
  float2* bands;
  float* visibility@2;
  float2* rampExtent;
  float* hairRamp;
  uint* param@238;
  float* width;
  float3* energy@2;
  float3* _15358;
  float* shadowRegion;
  float* shadowSystemWeight;
  float* shadowWeight;
  uint* param@239;
  uint* _15474;
  uint* _15479;
  float* _15488;
  uint* _15493;
  uint* _15498;
  float3* lamShadowTint;
  float* aoClassWeight;
  uint* _15527;
  uint* _15532;
  float* _15541;
  uint* _15545;
  uint* _15550;
  float3* aoShadowTint;
  float3* hairAoColor;
  float3* _15583;
  float3* hairAoTint;
  float3* tintedDiffuse;
  float* hairDiffusePeak;
  float* hairDiffuseFloor;
  float3* huePreservedHair;
  float* faceActive;
  uint* _15644;
  uint* _15649;
  float3* directSpecular;
  float3* _15686;
  float3* param@240;
  float* param@241;
  float* param@242;
  float* param@243;
  float* param@244;
  float* param@245;
  float* dielectricSpecularWeight;
  uint* _15739;
  uint* _15744;
  float* _15753;
  uint* _15757;
  uint* _15762;
  float* _15771;
  uint* _15776;
  uint* _15781;
  float* rimNormalDotView;
  float* _15837;
  float* rim;
  float3* rimLighting;
  float3* kkSpecular;
  float3* secondaryKkSpecular;
  float3* hairHighlightNormal;
  float2* param@246;
  float* hairShift;
  float3* hairStrandDirection;
  float3* secondaryHairStrand;
  float3* hairHalf;
  float* tangentDotHalf;
  float* secondaryTangentDotHalf;
  float* kkSine;
  float* secondaryKkSine;
  float* kkPower;
  float* secondaryKkPower;
  float* kkLobe;
  float* secondaryKkLobe;
  float* kkBand;
  float* secondaryKkBand;
  float* hairViewVisibility;
  float3* kkTint;
  float3* secondaryKkTint;
  float2* rampSize;
  float* kkRamp;
  uint* param@247;
  float* rampWidth;
  CharacterProjectedHairEnergy* energy@3;
  float3* param@248;
  float3* param@249;
  bool* param@250;
  float3* lightEnergy;
  float* outputAlpha;
  int* _16168;
  float* _16176;
  float* sceneDepth@2;
  float* overlayDepth;
  float* fade;
  float3* emissive;
  uint* param@251;
  float3* matcapAccent;
  uint* param@252;
  float3* cameraForward;
  float3* cameraRight;
  float3* cameraUp;
  float2* matcapUv;
  float2* matcapTexel;
  float* matcapMask;
  float3* matcapTint;
  uint* param@253;
  float3* beautyColor;
  int* qaIsolationMode;
  float3* sceneReflectionRadiance;
  float3* sceneReflectionResponse;
  float3* reflectionDiffuseIncident;
  float3* param@254;
  bool* overlayDisabled;
  float* overlayVisible;
  float* angle;
  float3* envNormal;
  float3* envReflection;
  float* lastMip;
  float3* _16575;
  float3* param@255;
  float3* param@256;
  uint* param@257;
  float3* _16699;
  float4* volume;
  float3* param@258;
  float3* param@259;
  bool* param@260;
  float3* blended;
  float3* _16738;
  float* visibility@3;
  float3* incident@2;
  float4* mainRadiance;
  float* hairShadowScale;
  PackedMaterialSurfaceProfile* profile;
  CharacterDiffuseResponse* response@3;
  PackedMaterialSurfaceProfile* profile@2;
  float4* param@261;
  float* param@262;
  float4* param@263;
  float* param@264;
  float* param@265;
  float* param@266;
  float3* param@267;
  float3* param@268;
  PackedMaterialSurfaceProfile* profile@3;
  float3* envNormal@2;
  float* angle@2;
  float3* param@269;
  float4* volume@2;
  float3* param@270;
  float3* param@271;
  bool* param@272;
  CharacterDiffuseIllumination* illumination@2;
  float3* param@273;
  float3* param@274;
  float4* param@275;
  float4* param@276;
  float4* param@277;
  float4* param@278;
  float* param@279;
  float* param@280;
  float* param@281;
  float* param@282;
  float3* combinedAmbient;
  float3* combinedDirect;
  float3* eyeMainDirect;
  float4* param@283;
  float4* param@284;
  float* param@285;
  float* param@286;
  float* param@287;
  float* param@288;
  float3* param@289;
  float* saturation;
  float3* param@290;
  float3* param@291;
  float* param@292;
  float3* param@293;
  float* param@294;
  float3* param@295;
  float* param@296;
  float* viewAlpha;
  float3* param@297;
  float3* param@298;
  float* fullDiffuse;
  float* param@299;
  float* param@300;
  float* param@301;
  float* param@302;
  float4* rampIllumination;
  float3* mainSpecular;
  float3* param@303;
  float3* param@304;
  float* param@305;
  float* param@306;
  float4* param@307;
  float* param@308;
  float* weight@2;
  float* scale;
  float3* specularIllumination;
  float3* primaryMain;
  float3* secondaryMain;
  bool* param@309;
  uint* param@310;
  ProjectedHairIncident* sampleLighting;
  CharacterProjectedHairEnergy* energy@4;
  float2* unusedLine@2;
  float3* param@311;
  float3* param@312;
  bool* param@313;
  bool* param@314;
  ProjectedHairIncident* param@315;
  float2* param@316;
  float3* primary;
  float3* secondary;
  float2* line@2;
  float3* param@317;
  float3* param@318;
  bool* param@319;
  bool* param@320;
  float2* param@321;
  float3* dark;
  float3* adjusted;
  float3* mainDiffuse;
  float3* adjustedMain;
  float3* param@322;
  float* param@323;
  float3* difference;
  float3* mainColor;
  float* saturation@2;
  float3* param@324;
  float3* param@325;
  float* param@326;
  float3* adjustedMain@2;
  float3* param@327;
  float* param@328;
  float3* adjustedPrimary;
  float3* param@329;
  float* param@330;
  float3* adjustedSecondary;
  float3* param@331;
  float* param@332;
  float3* param@333;
  float* param@334;
  float* lastMip@2;
  float* lod;
  float* param@335;
  float* param@336;
  float3* param@337;
  float3* radiance@2;
  float3* param@338;
  float3* param@339;
  float3* param@340;
  float* param@341;
  float* param@342;
  float3* blended@2;
  float4* screenReflection;
  float2* param@343;
  float4x4* param@344;
  float3* param@345;
  float3* param@346;
  float3* param@347;
  float3* param@348;
  float3* param@349;
  float* param@350;
  float4* param@351;
  float4* param@352;
  float3* radiance@3;
  float3* blended@3;
  uint* param@353;
  float2* uv@2;
  float2* mapUv;
  float2* offset@3;
  float2* param@354;
  float* param@355;
  float* depth;
  float* fullDepth;
  float2* param@356;
  float* quarterDepth;
  float2* param@357;
  float2* safeUv;
  float2* param@358;
  float2* param@359;
  float* param@360;
  float* param@361;
  float* param@362;
  int2* extent@3;
  float2* pixel@2;
  int2* first;
  float2* f;
  int* tap;
  int2* p@2;
  int2* period;
  float3[4]* taps;
  float3* background;
  float3* param@363;
  float3* param@364;
  float3* param@365;
  float* param@366;
  float* param@367;
  uint* param@368;
  uint* param@369;
  uint* param@370;
  PackedMaterialSurfaceProfile* p@3;
  float4* layered;
  PackedMaterialSurfaceProfile* param@371;
  float4* param@372;
  float4* ramp@3;
  float3* illumination@3;
  float4* param@373;
  float4* param@374;
  float* param@375;
  float* param@376;
  float* param@377;
  float* param@378;
  float3* param@379;
  float4* param@380;
  float* param@381;
  float3* param@382;
  float3* param@383;
  float3* param@384;
  float* param@385;
  float* radianceScale;
  float3* qaColor;
  uint* _18272;
  uint* _18277;
  uint* param@386;
  uint* _18322;
  uint* _18327;
  float3* _18336;
  float3* _18353;
  uint* param@387;
  float3* _18419;
  float3* param@388;
  float3* param@389;
  uint* param@390;
  float2* uv@3;
  float* sceneDepth@3;
  float3* scene;
  float3* hsv;
  float3* param@391;
  float3* param@392;
  float* compositeCoverage;
  float* _18500;
  int* _18533;
  float2* compositeProfile;
  int2* pixel@3;
  float* receiverCode;
  bool* receiverMatches;
  bool* _18578;
  float* param@393;
  uint* param@394;
  float4* param@395;
  bool* param@396;
  float* innerOutlineParticipation;
  float3* innerOutlineNormal;
  prepareShadowReceiver();
  *alphaUvDx = {0.0000, 0.0000};
  *alphaUvDy = {0.0000, 0.0000};
  uint* _11432 = &material.materialFeatures;
  uint _11433 = *_11432;
  uint _11435 = _11433 & _11434;
  uint _11436 = _11435 | azureFixedMaterialFeatureValue;
  *param = azureOrdinaryOpaque;
  *param@2 = _11436;
  uint _11439 = azureSpecializedMaterialFeatures(param, param@2);
  uint _11441 = _11439 & 1073741824;
  bool _11442 = _11441 != 0;
  
  if(_11442) {
    float2 _11445 = *textureCoordinate;
    float2 _11446 = DPdx(_11445);
    *alphaUvDx = _11446;
    float2 _11447 = *textureCoordinate;
    float2 _11448 = DPdy(_11447);
    *alphaUvDy = _11448;
  }

  
  if(false) {
    float2 _11451 = *textureCoordinate;
    float2 _11452 = DPdx(_11451);
    *projectedHairUvDx = _11452;
    float2 _11453 = *textureCoordinate;
    float2 _11454 = DPdy(_11453);
    *projectedHairUvDy = _11454;
    float3 _11455 = *worldNormal;
    float3 _11456 = DPdx(_11455);
    *projectedHairNormalDx = _11456;
    float3 _11457 = *worldNormal;
    float3 _11458 = DPdy(_11457);
    *projectedHairNormalDy = _11458;
    float4 _11459 = *worldTangent;
    float4 _11460 = DPdx(_11459);
    *projectedHairTangentDx = _11460;
    float4 _11461 = *worldTangent;
    float4 _11462 = DPdy(_11461);
    *projectedHairTangentDy = _11462;
    float3 _11463 = *worldPosition;
    float3 _11464 = DPdx(_11463);
    *projectedHairPositionDx = _11464;
    float3 _11465 = *worldPosition;
    float3 _11466 = DPdy(_11465);
    *projectedHairPositionDy = _11466;
  }

  
  if(azureOrdinaryOpaque) {
    *_11467 = 0;
  } else {
    int* _11471 = &material.alphaMode;
    int _11472 = *_11471;
    *_11467 = _11472;
  }

  int _11473 = *_11467;
  bool _11474 = _11473 != 2;
  
  if(_11474) {
    float3 _11479 = *opacityCoordinate;
    *param@3 = _11479;
    float* _11481 = &material.nodeOpacity;
    float _11482 = *_11481;
    *param@4 = _11482;
    bool _11483 = azureNodeOpacityCovered(param@3, param@4);
    bool _11484 = !_11483;
  }

  bool _11485 = Phi(_11474, _11484);
  
  if(_11485) {
    Kill();
  }

  
  if(azureOrdinaryOpaque) {
    *_11490 = 0;
  } else {
    
    if(_11494) {
      *_11495 = azureFixedMaterialClass;
    } else {
      uint* _11499 = &material.materialClass;
      uint _11500 = *_11499;
      *_11495 = _11500;
    }

    uint _11501 = *_11495;
    *_11490 = _11501;
  }

  uint _11502 = *_11490;
  bool _11503 = _11502 == 6;
  
  if(_11503) {
    *param@5 = 131072;
    float _11508 = materialFeatureEnabled(param@5);
    bool _11509 = _11508 > 0.5000;
  }

  bool _11510 = Phi(_11503, _11509);
  *eyeRadial = _11510;
  uint* _11512 = &material.textureBase;
  uint _11513 = *_11512;
  uint _11514 = _11513 + 0;
  uint _11515 = CopyObject(_11514) : [[NonUniform]];
  SampledImage<float, 2D>* _11516 = &textureArray[_11515] : [[NonUniform]];
  SampledImage<float, 2D> _11517 = *_11516 : [[NonUniform]];
  float2 _11518 = *textureCoordinate;
  float4 _11519 = ImageSampleImplicitLod(_11517, _11518);
  *baseColor = _11519;
  
  if(azureOrdinaryOpaque) {
    *_11520 = 0;
  } else {
    int* _11524 = &material.alphaMode;
    int _11525 = *_11524;
    *_11520 = _11525;
  }

  int _11526 = *_11520;
  bool _11527 = _11526 == 1;
  
  if(_11527) {
    uint* _11530 = &material.materialFeatures;
    uint _11531 = *_11530;
    uint _11533 = _11531 & _11532;
    uint _11534 = _11533 | azureFixedMaterialFeatureValue;
    *param@6 = azureOrdinaryOpaque;
    *param@7 = _11534;
    uint _11537 = azureSpecializedMaterialFeatures(param@6, param@7);
    uint _11538 = _11537 & 1073741824;
    bool _11539 = _11538 != 0;
  }

  bool _11540 = Phi(_11527, _11539);
  
  if(_11540) {
    uint* _11543 = &material.textureBase;
    uint _11544 = *_11543;
    uint _11545 = _11544 + 0;
    uint _11546 = CopyObject(_11545) : [[NonUniform]];
    SampledImage<float, 2D>* _11547 = &textureArray[_11546];
    float2 _11549 = *textureCoordinate;
    *param@8 = _11549;
    float2 _11551 = *alphaUvDx;
    *param@9 = _11551;
    float2 _11553 = *alphaUvDy;
    *param@10 = _11553;
    float _11554 = azureTemporalMaskAlpha(_11547, param@8, param@9, param@10);
    float* _11555 = &baseColor.w;
    *_11555 = _11554;
  }

  
  if(azureOrdinaryOpaque) {
    *_11556 = 0;
  } else {
    int* _11560 = &material.alphaMode;
    int _11561 = *_11560;
    *_11556 = _11561;
  }

  int _11562 = *_11556;
  bool _11563 = _11562 == 2;
  
  if(_11563) {
    uint* _11566 = &material.materialFeatures;
    uint _11567 = *_11566;
    uint _11569 = _11567 & _11568;
    uint _11570 = _11569 | azureFixedMaterialFeatureValue;
    *param@11 = azureOrdinaryOpaque;
    *param@12 = _11570;
    uint _11573 = azureSpecializedMaterialFeatures(param@11, param@12);
    uint _11574 = _11573 & 1073741824;
    bool _11575 = _11574 != 0;
  }

  bool _11576 = Phi(_11563, _11575);
  
  if(_11576) {
    uint* _11579 = &material.textureBase;
    uint _11580 = *_11579;
    uint _11581 = _11580 + 0;
    uint _11582 = CopyObject(_11581) : [[NonUniform]];
    float* _11583 = &camera.cameraRight.w;
    float _11584 = *_11583;
    float* _11585 = &camera.cameraUp.w;
    float _11586 = *_11585;
    float2 _11587 = CompositeConstruct({_11584, _11586});
    SampledImage<float, 2D>* _11588 = &textureArray[_11582];
    float2 _11590 = *textureCoordinate;
    *param@13 = _11590;
    float2 _11592 = *alphaUvDx;
    *param@14 = _11592;
    float2 _11594 = *alphaUvDy;
    *param@15 = _11594;
    *param@16 = _11587;
    float _11596 = azureTemporalBlendAlpha(_11588, param@13, param@14, param@15, param@16);
    float* _11597 = &baseColor.w;
    *_11597 = _11596;
  }

  bool _11598 = *eyeRadial;
  
  if(_11598) {
    uint* _11603 = &material.materialPadding;
    uint _11604 = *_11603;
    uint _11605 = _11604 >> 1;
    *param@17 = _11605;
    EyeSurfaceProfile _11607 = loadEyeSurfaceProfile(param@17);
    *eyeProfile = _11607;
    float2 _11609 = *textureCoordinate;
    float4* _11610 = &eyeProfile.uvScaleOffset;
    float4 _11611 = *_11610;
    float2 _11612 = _11611.xy;
    float2 _11613 = _11609 * _11612;
    float4* _11614 = &eyeProfile.uvScaleOffset;
    float4 _11615 = *_11614;
    float2 _11616 = _11615.zw;
    float2 _11617 = _11613 + _11616;
    *originalUv = _11617;
    float4* _11619 = &camera.cameraRight;
    float4 _11620 = *_11619;
    float3 _11621 = _11620.xyz;
    float4* _11622 = &camera.cameraUp;
    float4 _11623 = *_11622;
    float3 _11624 = _11623.xyz;
    float4* _11625 = &camera.cameraForward;
    float4 _11626 = *_11625;
    float3 _11627 = _11626.xyz;
    float3 _11628 = -_11627;
    float _11629 = _11621.x;
    float _11630 = _11621.y;
    float _11631 = _11621.z;
    float _11632 = _11624.x;
    float _11633 = _11624.y;
    float _11634 = _11624.z;
    float _11635 = _11628.x;
    float _11636 = _11628.y;
    float _11637 = _11628.z;
    float3 _11638 = CompositeConstruct({_11629, _11630, _11631});
    float3 _11639 = CompositeConstruct({_11632, _11633, _11634});
    float3 _11640 = CompositeConstruct({_11635, _11636, _11637});
    float3x3 _11641 = CompositeConstruct({_11638, _11639, _11640});
    float3x3 _11642 = Transpose(_11641);
    *worldToView = _11642;
    float4* _11645 = &camera.cameraPosition;
    float4 _11646 = *_11645;
    float3 _11647 = _11646.xyz;
    float3 _11648 = *worldPosition;
    float3 _11649 = _11647 - _11648;
    float2 _11651 = *originalUv;
    *param@18 = _11651;
    *param@19 = _11649;
    float3 _11654 = *worldNormal;
    *param@20 = _11654;
    float4 _11656 = *worldTangent;
    *param@21 = _11656;
    float3x3 _11658 = *worldToView;
    *param@22 = _11658;
    float* _11660 = &eyeProfile.shape.x;
    float _11661 = *_11660;
    *param@23 = _11661;
    float* _11663 = &eyeProfile.shape.y;
    float _11664 = *_11663;
    *param@24 = _11664;
    CharacterEyeCoordinates _11665 = characterEyeCoordinates(param@18, param@19, param@20, param@21, param@22, param@23, param@24);
    *eyeCoordinates = _11665;
    uint* _11666 = &material.textureBase;
    uint _11667 = *_11666;
    uint _11668 = _11667 + 0;
    uint _11669 = CopyObject(_11668) : [[NonUniform]];
    SampledImage<float, 2D>* _11670 = &textureArray[_11669] : [[NonUniform]];
    SampledImage<float, 2D> _11671 = *_11670 : [[NonUniform]];
    float2* _11672 = &eyeCoordinates.baseUv;
    float2 _11673 = *_11672;
    float4 _11674 = ImageSampleImplicitLod(_11671, _11673);
    *baseColor = _11674;
  }

  bool _11676 = *eyeRadial;
  
  if(_11676) {
    float* _11679 = &camera.clusterLighting.x;
    float _11680 = *_11679;
    bool _11681 = _11680 > 0.5000;
  }

  bool _11682 = Phi(_11676, _11681);
  
  if(_11682) {
    float* _11685 = &camera.nprLightingParameters.x;
    float _11686 = *_11685;
    bool _11687 = _11686 > 0.5000;
  }

  bool _11688 = Phi(_11682, _11687);
  
  if(_11688) {
    uint* _11691 = &material.materialPadding;
    uint _11692 = *_11691;
    uint _11693 = _11692 >> 1;
    float* _11694 = &materialSurfaceProfiles.profiles[_11693].rows[6].w;
    float _11695 = *_11694;
    bool _11696 = _11695 > 0.5000;
  }

  bool _11697 = Phi(_11688, _11696);
  *eyeNpr = _11697;
  *param@25 = 32768;
  float _11701 = materialFeatureEnabled(param@25);
  bool _11702 = _11701 > 0.5000;
  *multiplyComposite = _11702;
  
  if(azureOrdinaryOpaque) {
    *_11704 = 0;
  } else {
    
    if(_11708) {
      *_11709 = azureFixedMaterialClass;
    } else {
      uint* _11713 = &material.materialClass;
      uint _11714 = *_11713;
      *_11709 = _11714;
    }

    uint _11715 = *_11709;
    *_11704 = _11715;
  }

  uint _11716 = *_11704;
  bool _11717 = _11716 == 7;
  
  if(_11717) {
    *param@26 = 16;
    float _11721 = materialFeatureEnabled(param@26);
    bool _11722 = _11721 > 0.5000;
  }

  bool _11723 = Phi(_11717, _11722);
  bool _11724 = *multiplyComposite;
  bool _11725 = _11723 || _11724;
  *overlayMaterial = _11725;
  bool _11727 = *overlayMaterial;
  
  if(_11727) {
    *param@27 = 64;
    float _11732 = materialFeatureEnabled(param@27);
    bool _11733 = _11732 > 0.5000;
  }

  bool _11734 = Phi(_11727, _11733);
  *browOverlay = _11734;
  bool _11735 = *browOverlay;
  
  if(_11735) {
    float* _11739 = &material.featureParameters.w;
    float _11740 = *_11739;
    float _11741 = GLSL.std.450::FMax(_11740, 0.0010);
    *basePower = _11741;
    float4 _11742 = *baseColor;
    float3 _11743 = _11742.xyz;
    float3 _11744 = GLSL.std.450::FMax(_11743, {0.0000, 0.0000, 0.0000});
    float _11745 = *basePower;
    float3 _11746 = CompositeConstruct({_11745, _11745, _11745});
    float3 _11747 = GLSL.std.450::Pow(_11744, _11746);
    float3 _11748 = GLSL.std.450::FClamp(_11747, {0.0000, 0.0000, 0.0000}, {1.0000, 1.0000, 1.0000});
    float* _11749 = &baseColor.x;
    float _11750 = _11748.x;
    *_11749 = _11750;
    float* _11751 = &baseColor.y;
    float _11752 = _11748.y;
    *_11751 = _11752;
    float* _11753 = &baseColor.z;
    float _11754 = _11748.z;
    *_11753 = _11754;
  }

  float* _11756 = &material.showcasePlatform;
  float _11757 = *_11756;
  float _11758 = GLSL.std.450::FClamp(_11757, 0.0000, 1.0000);
  *platformMask = _11758;
  float2 _11760 = *textureCoordinate;
  float2 _11761 = _11760 - {0.5000, 0.5000};
  float _11762 = GLSL.std.450::Length(_11761);
  float _11763 = _11762 * 2.0000;
  *platformRadius = _11763;
  float _11765 = *platformRadius;
  float _11766 = GLSL.std.450::SmoothStep(0.1000, 0.6200, _11765);
  float _11767 = 1.0000 - _11766;
  *contactShadow = _11767;
  float _11770 = *platformRadius;
  float _11771 = GLSL.std.450::SmoothStep(0.6800, 0.9800, _11770);
  *platformRing = _11771;
  float* _11773 = &camera.showcaseParameters.x;
  float _11774 = *_11773;
  float _11775 = _11774 + 0.5000;
  float _11776 = GLSL.std.450::Floor(_11775);
  *showcasePreset = _11776;
  *platformPresetTint = {1.0000, 1.0000, 1.0000};
  float _11778 = *showcasePreset;
  bool _11779 = _11778 == 1.0000;
  
  if(_11779) {
    *platformPresetTint = {0.7200, 0.7600, 0.7700};
  } else {
    float _11787 = *showcasePreset;
    bool _11788 = _11787 == 2.0000;
    
    if(_11788) {
      *platformPresetTint = {1.1600, 1.1400, 1.1000};
    }

  }

  float _11799 = *platformRing;
  float3 _11800 = CompositeConstruct({_11799, _11799, _11799});
  float3 _11801 = GLSL.std.450::FMix({0.5200, 0.5200, 0.5200}, {1.0800, 1.0800, 1.0800}, _11800);
  float _11803 = *contactShadow;
  float3 _11804 = CompositeConstruct({_11803, _11803, _11803});
  float3 _11805 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, {0.6000, 0.6000, 0.6000}, _11804);
  float3 _11806 = _11801 * _11805;
  float3 _11807 = *platformPresetTint;
  float3 _11808 = _11806 * _11807;
  float _11809 = *platformMask;
  float3 _11810 = CompositeConstruct({_11809, _11809, _11809});
  float3 _11811 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, _11808, _11810);
  float4 _11812 = *baseColor;
  float3 _11813 = _11812.xyz;
  float3 _11814 = _11813 * _11811;
  float* _11815 = &baseColor.x;
  float _11816 = _11814.x;
  *_11815 = _11816;
  float* _11817 = &baseColor.y;
  float _11818 = _11814.y;
  *_11817 = _11818;
  float* _11819 = &baseColor.z;
  float _11820 = _11814.z;
  *_11819 = _11820;
  float _11821 = *showcasePreset;
  bool _11822 = _11821 == 1.0000;
  float _11823 = *platformMask;
  bool _11824 = _11823 > 0.0000;
  bool _11825 = _11822 && _11824;
  
  if(_11825) {
    float _11829 = *platformRadius;
    float _11830 = GLSL.std.450::SmoothStep(0.7200, 0.7500, _11829);
    float _11832 = *platformRadius;
    float _11833 = GLSL.std.450::SmoothStep(0.7800, 0.8100, _11832);
    float _11834 = 1.0000 - _11833;
    float _11835 = _11830 * _11834;
    *signalRing = _11835;
    float* _11837 = &textureCoordinate.y;
    float _11838 = *_11837;
    float _11839 = _11838 - 0.5000;
    float* _11840 = &textureCoordinate.x;
    float _11841 = *_11840;
    float _11842 = _11841 - 0.5000;
    float _11843 = GLSL.std.450::Atan2(_11839, _11842);
    *tickAngle = _11843;
    float _11846 = *tickAngle;
    float _11848 = _11846 * 12.0000;
    float _11849 = GLSL.std.450::Cos(_11848);
    float _11850 = GLSL.std.450::FAbs(_11849);
    float _11851 = GLSL.std.450::SmoothStep(0.7800, 0.9400, _11850);
    *ticks = _11851;
    float _11855 = *signalRing;
    float3 _11856 = {0.3400, 0.1050, 0.0120} * _11855;
    float _11857 = *ticks;
    float3 _11858 = _11856 * _11857;
    float _11859 = *platformMask;
    float3 _11860 = _11858 * _11859;
    float4 _11861 = *baseColor;
    float3 _11862 = _11861.xyz;
    float3 _11863 = _11862 + _11860;
    float* _11864 = &baseColor.x;
    float _11865 = _11863.x;
    *_11864 = _11865;
    float* _11866 = &baseColor.y;
    float _11867 = _11863.y;
    *_11866 = _11867;
    float* _11868 = &baseColor.z;
    float _11869 = _11863.z;
    *_11868 = _11869;
  }

  
  if(azureOrdinaryOpaque) {
    *_11870 = 0;
  } else {
    int* _11874 = &material.alphaMode;
    int _11875 = *_11874;
    *_11870 = _11875;
  }

  int _11876 = *_11870;
  bool _11877 = _11876 == 1;
  
  if(_11877) {
    float* _11880 = &baseColor.w;
    float _11881 = *_11880;
    float* _11882 = &material.alphaCutoff;
    float _11883 = *_11882;
    bool _11884 = _11881 < _11883;
  }

  bool _11885 = Phi(_11877, _11884);
  
  if(_11885) {
    Kill();
  }

  float3 _11890 = *worldNormal;
  float3 _11891 = GLSL.std.450::Normalize(_11890);
  *geometricNormal = _11891;
  bool _11892 = *gl_FrontFacing;
  bool _11893 = !_11892;
  
  if(_11893) {
    float3 _11896 = *geometricNormal;
    float3 _11897 = -_11896;
    *geometricNormal = _11897;
  }

  float4 _11899 = *baseColor;
  *param@28 = _11899;
  float3 _11901 = *geometricNormal;
  *param@29 = _11901;
  float _11903 = *platformMask;
  *param@30 = _11903;
  bool _11904 = azureWritePlainUnlitBeauty(param@28, param@29, param@30);
  
  if(_11904) {
    return;
  }

  float4 _11909 = *baseColor;
  *param@31 = _11909;
  float3 _11911 = *geometricNormal;
  *param@32 = _11911;
  float _11913 = *platformMask;
  *param@33 = _11913;
  *param@34 = {0.0000, 0.0000, 0.0000};
  *param@35 = 1.0000;
  bool _11916 = azureWriteUnlitBlendBeauty(param@31, param@32, param@33, param@34, param@35);
  
  if(_11916) {
    return;
  }

  float4 _11921 = *worldTangent;
  float3 _11922 = _11921.xyz;
  float3 _11923 = *geometricNormal;
  float3 _11924 = *geometricNormal;
  float4 _11925 = *worldTangent;
  float3 _11926 = _11925.xyz;
  float _11927 = Dot(_11924, _11926);
  float3 _11928 = _11923 * _11927;
  float3 _11929 = _11922 - _11928;
  float3 _11930 = GLSL.std.450::Normalize(_11929);
  *tangent = _11930;
  float3 _11932 = *geometricNormal;
  float3 _11933 = *tangent;
  float3 _11934 = GLSL.std.450::Cross(_11932, _11933);
  float3 _11935 = GLSL.std.450::Normalize(_11934);
  float* _11936 = &worldTangent.w;
  float _11937 = *_11936;
  float3 _11938 = _11935 * _11937;
  *bitangent = _11938;
  float3 _11940 = *tangent;
  float3 _11941 = *bitangent;
  float3 _11942 = *geometricNormal;
  float _11943 = _11940.x;
  float _11944 = _11940.y;
  float _11945 = _11940.z;
  float _11946 = _11941.x;
  float _11947 = _11941.y;
  float _11948 = _11941.z;
  float _11949 = _11942.x;
  float _11950 = _11942.y;
  float _11951 = _11942.z;
  float3 _11952 = CompositeConstruct({_11943, _11944, _11945});
  float3 _11953 = CompositeConstruct({_11946, _11947, _11948});
  float3 _11954 = CompositeConstruct({_11949, _11950, _11951});
  float3x3 _11955 = CompositeConstruct({_11952, _11953, _11954});
  *tangentToWorld = _11955;
  uint* _11957 = &material.textureBase;
  uint _11958 = *_11957;
  uint _11959 = _11958 + 1;
  uint _11960 = CopyObject(_11959) : [[NonUniform]];
  SampledImage<float, 2D>* _11961 = &textureArray[_11960] : [[NonUniform]];
  SampledImage<float, 2D> _11962 = *_11961 : [[NonUniform]];
  float2 _11963 = *textureCoordinate;
  float4 _11964 = ImageSampleImplicitLod(_11962, _11963);
  *normalSample = _11964;
  float4 _11966 = *normalSample;
  float3 _11967 = _11966.xyz;
  float3 _11968 = _11967 * 2.0000;
  float3 _11969 = CompositeConstruct({1.0000, 1.0000, 1.0000});
  float3 _11970 = _11968 - _11969;
  *sampledNormal = _11970;
  float3x3 _11972 = *tangentToWorld;
  float3 _11973 = *sampledNormal;
  float3 _11974 = _11972 * _11973;
  float3 _11975 = GLSL.std.450::Normalize(_11974);
  *shadedNormal = _11975;
  
  if(false) {
    uint* _11979 = &material.materialFeatures;
    uint _11980 = *_11979;
    uint _11982 = _11980 & _11981;
    uint _11983 = _11982 | azureFixedMaterialFeatureValue;
    *param@36 = azureOrdinaryOpaque;
    *param@37 = _11983;
    uint _11986 = azureSpecializedMaterialFeatures(param@36, param@37);
    uint _11987 = _11986 & 2155872256;
    bool _11988 = _11987 == 2155872256;
  }

  bool _11989 = Phi(false, _11988);
  
  if(_11989) {
    uint* _11993 = &material.textureBase;
    uint _11994 = *_11993;
    uint _11995 = _11994 + 6;
    uint _11996 = CopyObject(_11995) : [[NonUniform]];
    SampledImage<float, 2D>* _11997 = &textureArray[_11996] : [[NonUniform]];
    SampledImage<float, 2D> _11998 = *_11997 : [[NonUniform]];
    float2 _11999 = *textureCoordinate;
    float2 _12000 = *projectedHairUvDx;
    float2 _12001 = _12000 * 0.2500;
    float2 _12002 = *projectedHairUvDy;
    float2 _12003 = _12002 * 0.2500;
    float4 _12004 = ImageSampleExplicitLod(_11998, _11999, Grad(_12001, _12003));
    *_11990 = _12004;
  } else {
    uint* _12006 = &material.textureBase;
    uint _12007 = *_12006;
    uint _12008 = _12007 + 6;
    uint _12009 = CopyObject(_12008) : [[NonUniform]];
    SampledImage<float, 2D>* _12010 = &textureArray[_12009] : [[NonUniform]];
    SampledImage<float, 2D> _12011 = *_12010 : [[NonUniform]];
    float2 _12012 = *textureCoordinate;
    float4 _12013 = ImageSampleImplicitLod(_12011, _12012);
    *_11990 = _12013;
  }

  float4 _12014 = *_11990;
  *hairData = _12014;
  
  if(azureOrdinaryOpaque) {
    *_12016 = 0;
  } else {
    
    if(_12020) {
      *_12021 = azureFixedMaterialClass;
    } else {
      uint* _12025 = &material.materialClass;
      uint _12026 = *_12025;
      *_12021 = _12026;
    }

    uint _12027 = *_12021;
    *_12016 = _12027;
  }

  uint _12028 = *_12016;
  bool _12029 = _12028 == 3;
  
  if(_12029) {
    *param@38 = 2;
    float _12034 = materialFeatureEnabled(param@38);
    *_12030 = _12034;
  } else {
    *_12030 = 0.0000;
  }

  float _12036 = *_12030;
  *hairActive = _12036;
  float _12038 = *hairActive;
  bool _12039 = _12038 > 0.0000;
  
  if(_12039) {
    *param@39 = 65536;
    float _12044 = materialFeatureEnabled(param@39);
    bool _12045 = _12044 > 0.5000;
  }

  bool _12046 = Phi(_12039, _12045);
  *projectedHair = _12046;
  bool _12048 = *projectedHair;
  
  if(_12048) {
    uint* _12051 = &material.materialPadding;
    uint _12052 = *_12051;
    uint _12053 = _12052 >> 1;
    *param@40 = _12053;
    ProjectedHairProfile _12055 = loadProjectedHairSurfaceProfile(param@40);
    float _12056 = _12055.secondaryColor.w;
    bool _12057 = _12056 > 0.5000;
  }

  bool _12058 = Phi(_12048, _12057);
  *strandDiffuse = _12058;
  uint* _12060 = &material.materialPadding;
  uint _12061 = *_12060;
  uint _12062 = _12061 >> 1;
  float* _12063 = &materialSurfaceProfiles.profiles[_12062].rows[6].w;
  float _12064 = *_12063;
  float _12065 = _12064 + 0.5000;
  uint _12066 = ConvertFToU(_12065);
  *projectedHairFlags = _12066;
  bool _12068 = *strandDiffuse;
  
  if(_12068) {
    float* _12071 = &camera.clusterLighting.x;
    float _12072 = *_12071;
    bool _12073 = _12072 > 0.5000;
  }

  bool _12074 = Phi(_12068, _12073);
  
  if(_12074) {
    float* _12077 = &camera.nprLightingParameters.x;
    float _12078 = *_12077;
    bool _12079 = _12078 > 0.5000;
  }

  bool _12080 = Phi(_12074, _12079);
  
  if(_12080) {
    uint _12083 = *projectedHairFlags;
    uint _12084 = _12083 & 3;
    bool _12085 = _12084 != 0;
  }

  bool _12086 = Phi(_12080, _12085);
  *projectedLighting = _12086;
  bool _12088 = *projectedHair;
  
  if(_12088) {
    uint* _12092 = &material.materialPadding;
    uint _12093 = *_12092;
    uint _12094 = _12093 >> 1;
    *param@41 = _12094;
    ProjectedHairProfile _12096 = loadProjectedHairSurfaceProfile(param@41);
    float _12097 = _12096.objectX.w;
    *_12089 = _12097;
  } else {
    *_12089 = 1.0000;
  }

  float _12099 = *_12089;
  *projectedDiffuseScale = _12099;
  float* _12101 = &baseColor.x;
  float _12102 = *_12101;
  float* _12103 = &baseColor.y;
  float _12104 = *_12103;
  float _12105 = GLSL.std.450::FMax(_12102, _12104);
  float* _12106 = &baseColor.z;
  float _12107 = *_12106;
  float _12108 = GLSL.std.450::FMax(_12107, 0.0010);
  float _12109 = GLSL.std.450::FMax(_12105, _12108);
  *hairBasePeak = _12109;
  float4 _12111 = *baseColor;
  float3 _12112 = _12111.xyz;
  float _12113 = *hairBasePeak;
  float3 _12114 = CompositeConstruct({_12113, _12113, _12113});
  float3 _12115 = _12112 / _12114;
  *hairBaseHue = _12115;
  float3x3 _12117 = *tangentToWorld;
  float4 _12119 = *hairData;
  float2 _12120 = _12119.xy;
  *param@42 = _12120;
  float3 _12121 = decodePackedHairNormal(param@42);
  float3 _12122 = _12117 * _12121;
  float3 _12123 = GLSL.std.450::Normalize(_12122);
  *hairBaseNormal = _12123;
  float3 _12124 = *shadedNormal;
  float3 _12125 = *hairBaseNormal;
  float _12126 = *hairActive;
  float _12128 = _12126 * 0.1400;
  float3 _12129 = CompositeConstruct({_12128, _12128, _12128});
  float3 _12130 = GLSL.std.450::FMix(_12124, _12125, _12129);
  float3 _12131 = GLSL.std.450::Normalize(_12130);
  *shadedNormal = _12131;
  bool _12132 = *projectedHair;
  
  if(_12132) {
    uint* _12136 = &material.materialPadding;
    uint _12137 = *_12136;
    uint _12138 = _12137 >> 1;
    *param@43 = _12138;
    ProjectedHairProfile _12140 = loadProjectedHairSurfaceProfile(param@43);
    *p = _12140;
    float4 _12142 = *hairData;
    float2 _12143 = _12142.xy;
    *param@44 = _12143;
    float* _12145 = &p.edgeNormalDirection.w;
    float _12146 = *_12145;
    *param@45 = _12146;
    float* _12148 = &p.objectY.w;
    float _12149 = *_12148;
    *param@46 = _12149;
    float3 _12150 = projectedHairNormal(param@44, param@45, param@46);
    bool _12151 = *gl_FrontFacing;
    float _12152 = Select(_12151, 1.0000, -1.0000);
    float3 _12153 = _12150 * _12152;
    *shadedNormal = _12153;
  }

  bool _12154 = *eyeRadial;
  
  if(_12154) {
    float3* _12157 = &eyeCoordinates.lightingNormal;
    float3 _12158 = *_12157;
    *shadedNormal = _12158;
  }

  uint* _12160 = &material.textureBase;
  uint _12161 = *_12160;
  uint _12162 = _12161 + 2;
  uint _12163 = CopyObject(_12162) : [[NonUniform]];
  SampledImage<float, 2D>* _12164 = &textureArray[_12163] : [[NonUniform]];
  SampledImage<float, 2D> _12165 = *_12164 : [[NonUniform]];
  float2 _12166 = *textureCoordinate;
  float4 _12167 = ImageSampleImplicitLod(_12165, _12166);
  *packedMaterial = _12167;
  float* _12169 = &packedMaterial.x;
  float _12170 = *_12169;
  *param@47 = 128;
  float _12173 = materialFeatureEnabled(param@47);
  float _12174 = GLSL.std.450::FMix(1.0000, _12170, _12173);
  *physicalAo = _12174;
  uint* _12176 = &material.textureBase;
  uint _12177 = *_12176;
  uint _12178 = _12177 + 3;
  uint _12179 = CopyObject(_12178) : [[NonUniform]];
  SampledImage<float, 2D>* _12180 = &textureArray[_12179] : [[NonUniform]];
  SampledImage<float, 2D> _12181 = *_12180 : [[NonUniform]];
  float2 _12182 = *textureCoordinate;
  float4 _12183 = ImageSampleImplicitLod(_12181, _12182);
  *specularEmissive = _12183;
  float* _12185 = &camera.renderingParameters.y;
  float _12186 = *_12185;
  *styleStrength = _12186;
  float* _12188 = &camera.renderingParameters.z;
  float _12189 = *_12188;
  *diffuseBandThreshold = _12189;
  float* _12191 = &camera.clusterLighting.x;
  float _12192 = *_12191;
  bool _12193 = _12192 > 0.5000;
  
  if(_12193) {
    
    if(azureOrdinaryOpaque) {
      *_12196 = 0;
    } else {
      
      if(_12200) {
        *_12201 = azureFixedMaterialClass;
      } else {
        uint* _12205 = &material.materialClass;
        uint _12206 = *_12205;
        *_12201 = _12206;
      }

      uint _12207 = *_12201;
      *_12196 = _12207;
    }

    uint _12209 = *_12196;
    *param@48 = _12209;
    uint* _12211 = &material.materialProfileVersion;
    uint _12212 = *_12211;
    *param@49 = _12212;
    bool _12213 = sceneCharacterSurface(param@48, param@49);
  }

  bool _12214 = Phi(_12193, _12213);
  *sceneCharacter = _12214;
  bool _12215 = *sceneCharacter;
  float _12216 = *diffuseBandThreshold;
  bool _12217 = _12216 < 0.0000;
  bool _12218 = _12215 && _12217;
  
  if(_12218) {
    *diffuseBandThreshold = 0.4000;
  }

  float _12222 = *diffuseBandThreshold;
  float _12223 = GLSL.std.450::Step(0.0000, _12222);
  *bandEnabled = _12223;
  uint* _12225 = &material.textureBase;
  uint _12226 = *_12225;
  uint _12227 = _12226 + 4;
  uint _12228 = CopyObject(_12227) : [[NonUniform]];
  SampledImage<float, 2D>* _12229 = &textureArray[_12228] : [[NonUniform]];
  SampledImage<float, 2D> _12230 = *_12229 : [[NonUniform]];
  float2 _12231 = *textureCoordinate;
  float4 _12232 = ImageSampleImplicitLod(_12230, _12231);
  float _12233 = _12232.x;
  float _12234 = GLSL.std.450::SmoothStep(0.0800, 0.6200, _12233);
  float _12235 = *styleStrength;
  float _12236 = _12234 * _12235;
  *styleMask = _12236;
  *param@50 = 2048;
  float _12239 = materialFeatureEnabled(param@50);
  bool _12240 = _12239 > 0.5000;
  bool _12241 = !_12240;
  
  if(_12241) {
    *param@51 = 8192;
    float _12245 = materialFeatureEnabled(param@51);
    bool _12246 = _12245 > 0.5000;
  }

  bool _12247 = Phi(_12240, _12246);
  
  if(_12247) {
    *styleMask = 0.0000;
  }

  float* _12251 = &normalSample.w;
  float _12252 = *_12251;
  float _12253 = 1.0000 - _12252;
  float _12254 = GLSL.std.450::FMax(_12253, 0.0000);
  *normalVariance = _12254;
  float3 _12256 = *shadedNormal;
  float3 _12257 = DPdx(_12256);
  *dx = _12257;
  float3 _12259 = *shadedNormal;
  float3 _12260 = DPdy(_12259);
  *dy = _12260;
  float3 _12261 = *dx;
  float3 _12262 = *dx;
  float _12263 = Dot(_12261, _12262);
  float3 _12264 = *dy;
  float3 _12265 = *dy;
  float _12266 = Dot(_12264, _12265);
  float _12267 = _12263 + _12266;
  float _12268 = GLSL.std.450::FMin(_12267, 0.2500);
  float _12269 = *normalVariance;
  float _12270 = _12269 + _12268;
  *normalVariance = _12270;
  float* _12272 = &packedMaterial.y;
  float _12273 = *_12272;
  float* _12274 = &packedMaterial.y;
  float _12275 = *_12274;
  float _12276 = _12273 * _12275;
  float _12277 = *normalVariance;
  float _12278 = _12277 * 0.2500;
  float _12279 = _12276 + _12278;
  float _12280 = GLSL.std.450::Sqrt(_12279);
  float _12281 = GLSL.std.450::FClamp(_12280, 0.0800, 1.0000);
  *roughness = _12281;
  float* _12283 = &packedMaterial.z;
  float _12284 = *_12283;
  float _12285 = GLSL.std.450::FClamp(_12284, 0.0000, 1.0000);
  *metallic = _12285;
  float* _12287 = &specularEmissive.w;
  float _12288 = *_12287;
  float _12289 = GLSL.std.450::FClamp(_12288, 0.0000, 1.0000);
  *specularLevel = _12289;
  
  if(azureOrdinaryOpaque) {
    *_12290 = 0;
  } else {
    
    if(_12294) {
      *_12295 = azureFixedMaterialClass;
    } else {
      uint* _12299 = &material.materialClass;
      uint _12300 = *_12299;
      *_12295 = _12300;
    }

    uint _12301 = *_12295;
    *_12290 = _12301;
  }

  uint _12302 = *_12290;
  bool _12303 = _12302 == 0;
  bool _12304 = !_12303;
  
  if(_12304) {
    
    if(azureOrdinaryOpaque) {
      *_12307 = 0;
    } else {
      
      if(_12311) {
        *_12312 = azureFixedMaterialClass;
      } else {
        uint* _12316 = &material.materialClass;
        uint _12317 = *_12316;
        *_12312 = _12317;
      }

      uint _12318 = *_12312;
      *_12307 = _12318;
    }

    uint _12319 = *_12307;
    bool _12320 = _12319 == 4;
  }

  bool _12321 = Phi(_12303, _12320);
  bool _12322 = !_12321;
  
  if(_12322) {
    
    if(azureOrdinaryOpaque) {
      *_12325 = 0;
    } else {
      
      if(_12329) {
        *_12330 = azureFixedMaterialClass;
      } else {
        uint* _12334 = &material.materialClass;
        uint _12335 = *_12334;
        *_12330 = _12335;
      }

      uint _12336 = *_12330;
      *_12325 = _12336;
    }

    uint _12337 = *_12325;
    bool _12338 = _12337 == 5;
  }

  bool _12339 = Phi(_12321, _12338);
  
  if(_12339) {
    uint* _12343 = &material.materialPadding;
    uint _12344 = *_12343;
    uint _12345 = _12344 >> 1;
    float4* _12346 = &materialSurfaceProfiles.profiles[_12345].rows[5];
    float4 _12347 = *_12346;
    float2 _12348 = _12347.zw;
    *inputProfile = _12348;
    float* _12349 = &inputProfile.x;
    float _12350 = *_12349;
    bool _12351 = _12350 > 0.5000;
    
    if(_12351) {
      float* _12355 = &packedMaterial.w;
      float _12356 = *_12355;
      *_12352 = _12356;
    } else {
      float* _12358 = &specularEmissive.w;
      float _12359 = *_12358;
      *_12352 = _12359;
    }

    float _12360 = *_12352;
    float* _12361 = &inputProfile.y;
    float _12362 = *_12361;
    float _12363 = _12360 * _12362;
    float _12364 = GLSL.std.450::FClamp(_12363, 0.0000, 1.0000);
    *specularLevel = _12364;
  }

  
  if(azureOrdinaryOpaque) {
    *_12365 = 0;
  } else {
    
    if(_12369) {
      *_12370 = azureFixedMaterialClass;
    } else {
      uint* _12374 = &material.materialClass;
      uint _12375 = *_12374;
      *_12370 = _12375;
    }

    uint _12376 = *_12370;
    *_12365 = _12376;
  }

  uint _12377 = *_12365;
  bool _12378 = _12377 == 1;
  bool _12379 = !_12378;
  
  if(_12379) {
    
    if(azureOrdinaryOpaque) {
      *_12382 = 0;
    } else {
      
      if(_12386) {
        *_12387 = azureFixedMaterialClass;
      } else {
        uint* _12391 = &material.materialClass;
        uint _12392 = *_12391;
        *_12387 = _12392;
      }

      uint _12393 = *_12387;
      *_12382 = _12393;
    }

    uint _12394 = *_12382;
    bool _12395 = _12394 == 2;
  }

  bool _12396 = Phi(_12378, _12395);
  
  if(_12396) {
    float _12399 = *metallic;
    float _12401 = GLSL.std.450::FMin(_12399, 0.0150);
    *metallic = _12401;
    float _12402 = *roughness;
    
    if(azureOrdinaryOpaque) {
      *_12403 = 0;
    } else {
      
      if(_12407) {
        *_12408 = azureFixedMaterialClass;
      } else {
        uint* _12412 = &material.materialClass;
        uint _12413 = *_12412;
        *_12408 = _12413;
      }

      uint _12414 = *_12408;
      *_12403 = _12414;
    }

    uint _12415 = *_12403;
    bool _12416 = _12415 == 2;
    float _12417 = Select(_12416, 0.5800, 0.5200);
    float _12418 = GLSL.std.450::FMax(_12402, _12417);
    *roughness = _12418;
    float _12419 = *specularLevel;
    
    if(azureOrdinaryOpaque) {
      *_12420 = 0;
    } else {
      
      if(_12424) {
        *_12425 = azureFixedMaterialClass;
      } else {
        uint* _12429 = &material.materialClass;
        uint _12430 = *_12429;
        *_12425 = _12430;
      }

      uint _12431 = *_12425;
      *_12420 = _12431;
    }

    uint _12432 = *_12420;
    bool _12433 = _12432 == 2;
    float _12435 = Select(_12433, 0.2200, 0.3200);
    float _12436 = GLSL.std.450::FMin(_12419, _12435);
    *specularLevel = _12436;
  } else {
    
    if(azureOrdinaryOpaque) {
      *_12438 = 0;
    } else {
      
      if(_12442) {
        *_12443 = azureFixedMaterialClass;
      } else {
        uint* _12447 = &material.materialClass;
        uint _12448 = *_12447;
        *_12443 = _12448;
      }

      uint _12449 = *_12443;
      *_12438 = _12449;
    }

    uint _12450 = *_12438;
    bool _12451 = _12450 == 3;
    
    if(_12451) {
      float _12454 = *metallic;
      float _12455 = GLSL.std.450::FMin(_12454, 0.0400);
      *metallic = _12455;
      float _12456 = *roughness;
      float _12458 = GLSL.std.450::FMax(_12456, 0.4400);
      *roughness = _12458;
      float _12459 = *specularLevel;
      float _12461 = GLSL.std.450::FMin(_12459, 0.3000);
      *specularLevel = _12461;
    } else {
      
      if(azureOrdinaryOpaque) {
        *_12463 = 0;
      } else {
        
        if(_12467) {
          *_12468 = azureFixedMaterialClass;
        } else {
          uint* _12472 = &material.materialClass;
          uint _12473 = *_12472;
          *_12468 = _12473;
        }

        uint _12474 = *_12468;
        *_12463 = _12474;
      }

      uint _12475 = *_12463;
      bool _12476 = _12475 == 6;
      
      if(_12476) {
        *metallic = 0.0000;
      }

    }

  }

  bool _12479 = *strandDiffuse;
  
  if(_12479) {
    *metallic = 0.0000;
  }

  float* _12483 = &camera.qaParameters.y;
  float _12484 = *_12483;
  float _12485 = _12484 + 0.5000;
  float _12486 = GLSL.std.450::Floor(_12485);
  int _12487 = ConvertFToS(_12486);
  *qaEffectMode = _12487;
  float* _12489 = &camera.qaParameters.z;
  float _12490 = *_12489;
  bool _12491 = _12490 < 0.5000;
  *qaEffectDisabled = _12491;
  float* _12493 = &camera.clusterLighting.x;
  float _12494 = *_12493;
  bool _12495 = _12494 > 0.5000;
  
  if(_12495) {
    *param@52 = 524288;
    float _12500 = materialFeatureEnabled(param@52);
    bool _12501 = _12500 > 0.5000;
  }

  bool _12502 = Phi(_12495, _12501);
  
  if(_12502) {
    int _12505 = *qaEffectMode;
    bool _12506 = _12505 == 1;
    bool _12507 = *qaEffectDisabled;
    bool _12508 = _12506 && _12507;
    bool _12509 = !_12508;
  }

  bool _12510 = Phi(_12502, _12509);
  *nprDiffuse = _12510;
  bool _12511 = *nprDiffuse;
  
  if(_12511) {
    uint* _12515 = &material.materialPadding;
    uint _12516 = *_12515;
    uint _12517 = _12516 >> 1;
    float* _12518 = &materialSurfaceProfiles.profiles[_12517].rows[3].z;
    float _12519 = *_12518;
    *normalSource = _12519;
    float _12520 = *normalSource;
    bool _12521 = _12520 > 1.5000;
    
    if(_12521) {
      float4x4* _12525 = &camera.screenReflectionWorldToClip;
      float4x4 _12526 = *_12525;
      float3 _12527 = *worldPosition;
      float _12528 = _12527.x;
      float _12529 = _12527.y;
      float _12530 = _12527.z;
      float4 _12531 = CompositeConstruct({_12528, _12529, _12530, 1.0000});
      float4 _12532 = _12526 * _12531;
      *clip = _12532;
      float* _12533 = &clip.w;
      float _12534 = *_12533;
      bool _12535 = _12534 > 0.0000;
      
      if(_12535) {
        SampledImage<float, 2D> _12539 = *overlaySceneDepth;
        Image<float, 2D> _12540 = Image(_12539);
        int2 _12541 = ImageQuerySizeLod(_12540, 0);
        *extent = _12541;
        float4 _12543 = *clip;
        float2 _12544 = _12543.xy;
        float* _12545 = &clip.w;
        float _12546 = *_12545;
        float2 _12547 = CompositeConstruct({_12546, _12546});
        float2 _12548 = _12544 / _12547;
        float2 _12549 = _12548 * 0.5000;
        float2 _12550 = CompositeConstruct({0.5000, 0.5000});
        float2 _12551 = _12549 + _12550;
        int2 _12552 = *extent;
        float2 _12553 = ConvertSToF(_12552);
        float2 _12554 = _12551 * _12553;
        float2 _12555 = GLSL.std.450::Floor(_12554);
        int2 _12556 = ConvertFToS(_12555);
        *pixel = _12556;
        int2 _12557 = *pixel;
        bool _12558 = _12557 >= {0, 0};
        bool _12559 = All(_12558);
        
        if(_12559) {
          int2 _12562 = *pixel;
          int2 _12563 = *extent;
          bool _12564 = _12562 < _12563;
          bool _12565 = All(_12564);
        }

        bool _12566 = Phi(_12559, _12565);
        
        if(_12566) {
          SampledImage<float, 2D> _12570 = *overlaySceneDepth;
          int2 _12571 = *pixel;
          Image<float, 2D> _12572 = Image(_12570);
          float4 _12573 = ImageFetch(_12572, _12571, Lod(0));
          *surface = _12573;
          float4 _12574 = *surface;
          bool _12576 = IsNan(_12574);
          bool _12577 = Any(_12576);
          bool _12578 = !_12577;
          
          if(_12578) {
            float4 _12581 = *surface;
            bool _12582 = IsInf(_12581);
            bool _12583 = Any(_12582);
            bool _12584 = !_12583;
          }

          bool _12585 = Phi(_12578, _12584);
          
          if(_12585) {
            float* _12588 = &surface.x;
            float _12589 = *_12588;
            bool _12590 = _12589 > 0.0000;
          }

          bool _12591 = Phi(_12585, _12590);
          
          if(_12591) {
            float* _12594 = &surface.x;
            float _12595 = *_12594;
            bool _12597 = _12595 < 100000.0000;
          }

          bool _12598 = Phi(_12591, _12597);
          
          if(_12598) {
            float4 _12602 = *surface;
            *param@53 = _12602;
            float3 _12603 = decodeReflectionSurfaceNormal(param@53);
            *shadedNormal = _12603;
          }

        }

      }

    } else {
      float _12605 = *normalSource;
      bool _12606 = _12605 > 0.5000;
      
      if(_12606) {
        float3 _12610 = *worldPosition;
        float4* _12611 = &instanceFaceFrame[3];
        float4 _12612 = *_12611;
        float3 _12613 = _12612.xyz;
        float3 _12614 = _12610 - _12613;
        *offset = _12614;
        float* _12615 = &offset.x;
        float _12616 = *_12615;
        float* _12617 = &offset.z;
        float _12618 = *_12617;
        float3 _12619 = CompositeConstruct({_12616, 0.0001, _12618});
        float3 _12620 = GLSL.std.450::Normalize(_12619);
        *shadedNormal = _12620;
      }

    }

  }

  float _12622 = *showcasePreset;
  bool _12623 = _12622 == 1.0000;
  bool _12632 = CompositeConstruct({_12623, _12623, _12623});
  float3 _12633 = Select(_12632, {0.6227, 0.6830, 0.3817}, {0.4788, 0.8179, 0.3192});
  *lightDirection = _12633;
  float* _12634 = &camera.mainLightDirection.w;
  float _12635 = *_12634;
  bool _12636 = _12635 > 0.5000;
  
  if(_12636) {
    float4* _12639 = &camera.mainLightDirection;
    float4 _12640 = *_12639;
    float3 _12641 = _12640.xyz;
    *lightDirection = _12641;
  }

  float3 _12643 = *lightDirection;
  *sceneShadowDirection = _12643;
  *independentNprMain = false;
  bool _12645 = *sceneCharacter;
  bool _12646 = *nprDiffuse;
  bool _12647 = _12645 || _12646;
  
  if(_12647) {
    float* _12650 = &camera.clusterLighting.x;
    float _12651 = *_12650;
    bool _12652 = _12651 > 0.5000;
  }

  bool _12653 = Phi(_12647, _12652);
  
  if(_12653) {
    float* _12656 = &camera.nprLightingParameters.y;
    float _12657 = *_12656;
    bool _12658 = _12657 >= 0.0000;
  }

  bool _12659 = Phi(_12653, _12658);
  
  if(_12659) {
    float* _12662 = &camera.nprLightingParameters.y;
    float _12663 = *_12662;
    float* _12664 = &camera.clusterGrid.w;
    float _12665 = *_12664;
    bool _12666 = _12663 < _12665;
  }

  bool _12667 = Phi(_12659, _12666);
  
  if(_12667) {
    float* _12671 = &camera.nprLightingParameters.y;
    float _12672 = *_12671;
    uint _12673 = ConvertFToU(_12672);
    ClusterLight* _12674 = &sceneLightData.lights[_12673];
    ClusterLight _12675 = *_12674;
    float4 _12676 = _12675.positionRadius;
    float4* _12677 = &characterMain.positionRadius;
    *_12677 = _12676;
    float4 _12678 = _12675.colorIntensity;
    float4* _12679 = &characterMain.colorIntensity;
    *_12679 = _12678;
    float4 _12680 = _12675.directionOuter;
    float4* _12681 = &characterMain.directionOuter;
    *_12681 = _12680;
    float4 _12682 = _12675.coneType;
    float4* _12683 = &characterMain.coneType;
    *_12683 = _12682;
    float4[3] _12684 = _12675.boxRows;
    float4[3]* _12685 = &characterMain.boxRows;
    float4 _12686 = _12684[0];
    float4* _12687 = &_12685[0];
    *_12687 = _12686;
    float4 _12688 = _12684[1];
    float4* _12689 = &_12685[1];
    *_12689 = _12688;
    float4 _12690 = _12684[2];
    float4* _12691 = &_12685[2];
    *_12691 = _12690;
    float4 _12692 = _12675.boxParameters;
    float4* _12693 = &characterMain.boxParameters;
    *_12693 = _12692;
    float4 _12694 = _12675.characterResponse;
    float4* _12695 = &characterMain.characterResponse;
    *_12695 = _12694;
    float* _12696 = &characterMain.directionOuter.w;
    float _12697 = *_12696;
    bool _12698 = _12697 < 0.5000;
    *independentNprMain = _12698;
    bool _12699 = *independentNprMain;
    
    if(_12699) {
      float4* _12702 = &characterMain.directionOuter;
      float4 _12703 = *_12702;
      float3 _12704 = _12703.xyz;
      float3 _12705 = -_12704;
      *lightDirection = _12705;
    }

  }

  float _12707 = *showcasePreset;
  bool _12708 = _12707 == 1.0000;
  bool _12717 = CompositeConstruct({_12708, _12708, _12708});
  float3 _12718 = Select(_12717, {-0.5747, 0.2873, -0.7663}, {-0.7255, 0.3978, -0.5616});
  *fillDirection = _12718;
  float4* _12720 = &camera.cameraPosition;
  float4 _12721 = *_12720;
  float3 _12722 = _12721.xyz;
  float3 _12723 = *worldPosition;
  float3 _12724 = _12722 - _12723;
  float3 _12725 = GLSL.std.450::Normalize(_12724);
  *viewDirection = _12725;
  float3 _12727 = *lightDirection;
  float3 _12728 = *viewDirection;
  float3 _12729 = _12727 + _12728;
  float3 _12730 = GLSL.std.450::Normalize(_12729);
  *halfDirection = _12730;
  float3 _12732 = *viewDirection;
  float3 _12733 = -_12732;
  float3 _12734 = *shadedNormal;
  float3 _12735 = GLSL.std.450::Reflect(_12733, _12734);
  *reflectionDirection = _12735;
  float3 _12737 = *shadedNormal;
  float3 _12738 = *lightDirection;
  float _12739 = Dot(_12737, _12738);
  float _12740 = GLSL.std.450::FMax(_12739, 0.0000);
  *diffuse = _12740;
  float3 _12742 = *shadedNormal;
  float3 _12743 = *fillDirection;
  float _12744 = Dot(_12742, _12743);
  float _12745 = GLSL.std.450::FMax(_12744, 0.0000);
  *fillDiffuse = _12745;
  float3 _12747 = *geometricNormal;
  float3 _12748 = *sceneShadowDirection;
  float _12749 = Dot(_12747, _12748);
  float _12750 = GLSL.std.450::FMax(_12749, 0.0000);
  *param@54 = _12750;
  float _12752 = sampleShadowMap(param@54);
  *shadowVisibility = _12752;
  int _12753 = *qaEffectMode;
  bool _12754 = _12753 == 2;
  bool _12755 = *qaEffectDisabled;
  bool _12756 = _12754 && _12755;
  
  if(_12756) {
    *shadowVisibility = 1.0000;
  }

  bool _12760 = *independentNprMain;
  float _12761 = *shadowVisibility;
  float _12762 = Select(_12760, 1.0000, _12761);
  *nprMainShadowVisibility = _12762;
  float _12764 = *shadowVisibility;
  float _12765 = *showcasePreset;
  bool _12766 = _12765 == 1.0000;
  float _12767 = Select(_12766, 0.8800, 0.7200);
  float _12768 = GLSL.std.450::FMix(1.0000, _12764, _12767);
  *keyVisibility = _12768;
  
  if(azureOrdinaryOpaque) {
    *_12769 = 0;
  } else {
    
    if(_12773) {
      *_12774 = azureFixedMaterialClass;
    } else {
      uint* _12778 = &material.materialClass;
      uint _12779 = *_12778;
      *_12774 = _12779;
    }

    uint _12780 = *_12774;
    *_12769 = _12780;
  }

  uint _12781 = *_12769;
  bool _12782 = _12781 == 2;
  
  if(_12782) {
    float _12785 = *keyVisibility;
    float _12787 = GLSL.std.450::FMax(_12785, 0.8400);
    *keyVisibility = _12787;
  } else {
    
    if(azureOrdinaryOpaque) {
      *_12789 = 0;
    } else {
      
      if(_12793) {
        *_12794 = azureFixedMaterialClass;
      } else {
        uint* _12798 = &material.materialClass;
        uint _12799 = *_12798;
        *_12794 = _12799;
      }

      uint _12800 = *_12794;
      *_12789 = _12800;
    }

    uint _12801 = *_12789;
    bool _12802 = _12801 == 1;
    
    if(_12802) {
      float _12805 = *keyVisibility;
      float _12806 = GLSL.std.450::FMax(_12805, 0.5800);
      *keyVisibility = _12806;
    }

  }

  *keyColor = {1.0400, 0.9800, 0.9400};
  *fillColor = {0.5800, 0.7600, 1.0000};
  *rimColor = {0.2000, 0.3400, 0.5200};
  float _12814 = *showcasePreset;
  bool _12815 = _12814 == 1.0000;
  
  if(_12815) {
    *keyColor = {1.0400, 0.9800, 0.9000};
    *fillColor = {0.3800, 0.5300, 0.6100};
    *rimColor = {0.2000, 0.5500, 0.6400};
  } else {
    float _12827 = *showcasePreset;
    bool _12828 = _12827 == 2.0000;
    
    if(_12828) {
      *keyColor = {1.0000, 1.0000, 1.0000};
      *fillColor = {0.7200, 0.7800, 0.8500};
      *rimColor = {0.6200, 0.6800, 0.7400};
    }

  }

  float _12835 = *roughness;
  float _12836 = GLSL.std.450::FMix(96.0000, 6.0000, _12835);
  *specularPower = _12836;
  float3 _12838 = *shadedNormal;
  float3 _12839 = *halfDirection;
  float _12840 = Dot(_12838, _12839);
  float _12841 = GLSL.std.450::FMax(_12840, 0.0000);
  float _12842 = *specularPower;
  float _12843 = GLSL.std.450::Pow(_12841, _12842);
  *specularLobe = _12843;
  uint* _12845 = &material.materialPadding;
  uint _12846 = *_12845;
  uint _12847 = _12846 >> 1;
  float4* _12848 = &materialSurfaceProfiles.profiles[_12847].rows[0];
  float4 _12849 = *_12848;
  *nprParameters = _12849;
  uint* _12851 = &material.materialPadding;
  uint _12852 = *_12851;
  uint _12853 = _12852 >> 1;
  float4* _12854 = &materialSurfaceProfiles.profiles[_12853].rows[4];
  float4 _12855 = *_12854;
  *rampProfile = _12855;
  float* _12857 = &nprParameters.z;
  float _12858 = *_12857;
  *aoSource = _12858;
  float _12860 = *aoSource;
  bool _12861 = _12860 > 1.5000;
  
  if(_12861) {
    float* _12865 = &packedMaterial.x;
    float _12866 = *_12865;
    *_12862 = _12866;
  } else {
    float _12868 = *aoSource;
    bool _12869 = _12868 > 0.5000;
    
    if(_12869) {
      float* _12873 = &baseColor.w;
      float _12874 = *_12873;
      *_12870 = _12874;
    } else {
      *_12870 = 1.0000;
    }

    float _12876 = *_12870;
    *_12862 = _12876;
  }

  float _12877 = *_12862;
  *nprBaseAo = _12877;
  bool _12879 = *nprDiffuse;
  
  if(_12879) {
    float* _12882 = &rampProfile.w;
    float _12883 = *_12882;
    float _12884 = GLSL.std.450::FAbs(_12883);
    bool _12885 = _12884 > 0.5000;
  }

  bool _12886 = Phi(_12879, _12885);
  
  if(_12886) {
    
    if(azureOrdinaryOpaque) {
      *_12889 = 0;
    } else {
      
      if(_12893) {
        *_12894 = azureFixedMaterialClass;
      } else {
        uint* _12898 = &material.materialClass;
        uint _12899 = *_12898;
        *_12894 = _12899;
      }

      uint _12900 = *_12894;
      *_12889 = _12900;
    }

    uint _12901 = *_12889;
    bool _12902 = _12901 == 0;
    bool _12903 = !_12902;
    
    if(_12903) {
      
      if(azureOrdinaryOpaque) {
        *_12906 = 0;
      } else {
        
        if(_12910) {
          *_12911 = azureFixedMaterialClass;
        } else {
          uint* _12915 = &material.materialClass;
          uint _12916 = *_12915;
          *_12911 = _12916;
        }

        uint _12917 = *_12911;
        *_12906 = _12917;
      }

      uint _12918 = *_12906;
      bool _12919 = _12918 == 4;
    }

    bool _12920 = Phi(_12902, _12919);
    bool _12921 = !_12920;
    
    if(_12921) {
      
      if(azureOrdinaryOpaque) {
        *_12924 = 0;
      } else {
        
        if(_12928) {
          *_12929 = azureFixedMaterialClass;
        } else {
          uint* _12933 = &material.materialClass;
          uint _12934 = *_12933;
          *_12929 = _12934;
        }

        uint _12935 = *_12929;
        *_12924 = _12935;
      }

      uint _12936 = *_12924;
      bool _12937 = _12936 == 5;
    }

    bool _12938 = Phi(_12920, _12937);
  }

  bool _12939 = Phi(_12886, _12938);
  *specularRamp = _12939;
  float _12942 = *specularLevel;
  *param@55 = _12942;
  float _12943 = dielectricF0(param@55);
  float3 _12944 = CompositeConstruct({_12943, _12943, _12943});
  float4 _12945 = *baseColor;
  float3 _12946 = _12945.xyz;
  float _12947 = *metallic;
  float3 _12948 = CompositeConstruct({_12947, _12947, _12947});
  float3 _12949 = GLSL.std.450::FMix(_12944, _12946, _12948);
  *f0 = _12949;
  float3 _12951 = *f0;
  *rampReflectance = _12951;
  *rampSample = {1.0000, 1.0000, 1.0000};
  *rampSpecularLobe = 0.0000;
  bool _12954 = *specularRamp;
  
  if(_12954) {
    float4* _12959 = &camera.cameraForward;
    float4 _12960 = *_12959;
    float3 _12961 = _12960.xyz;
    float3 _12962 = -_12961;
    float* _12963 = &packedMaterial.y;
    float _12964 = *_12963;
    float _12965 = GLSL.std.450::FClamp(_12964, 0.0000, 1.0000);
    float _12966 = *nprMainShadowVisibility;
    float* _12967 = &camera.nprGainFloor.z;
    float _12968 = *_12967;
    float _12969 = GLSL.std.450::FMix(_12966, 1.0000, _12968);
    float3 _12971 = *shadedNormal;
    *param@56 = _12971;
    float3 _12973 = *viewDirection;
    *param@57 = _12973;
    *param@58 = _12962;
    float3 _12976 = *lightDirection;
    *param@59 = _12976;
    *param@60 = _12965;
    float _12979 = *metallic;
    *param@61 = _12979;
    *param@62 = _12969;
    float* _12982 = &rampProfile.z;
    float _12983 = *_12982;
    *param@63 = _12983;
    SpecularRampCoordinates _12984 = specularRampCoordinates(param@56, param@57, param@58, param@59, param@60, param@61, param@62, param@63);
    *coordinates = _12984;
    float2* _12986 = &coordinates.uv;
    float2 _12987 = *_12986;
    *uv = _12987;
    float* _12988 = &rampProfile.w;
    float _12989 = *_12988;
    bool _12990 = _12989 < 0.0000;
    
    if(_12990) {
      float* _12993 = &uv.y;
      float _12994 = *_12993;
      float _12995 = 1.0000 - _12994;
      float* _12996 = &uv.y;
      *_12996 = _12995;
    }

    uint* _12997 = &material.textureBase;
    uint _12998 = *_12997;
    uint _12999 = _12998 + 5;
    uint _13000 = CopyObject(_12999) : [[NonUniform]];
    SampledImage<float, 2D>* _13001 = &textureArray[_13000] : [[NonUniform]];
    SampledImage<float, 2D> _13002 = *_13001 : [[NonUniform]];
    float2 _13003 = *uv;
    float4 _13004 = ImageSampleExplicitLod(_13002, _13003, Lod(0.0000));
    float3 _13005 = _13004.xyz;
    *rampSample = _13005;
    float* _13006 = &coordinates.lobe;
    float _13007 = *_13006;
    *rampSpecularLobe = _13007;
    float3 _13009 = *f0;
    *param@64 = _13009;
    float3 _13011 = *rampSample;
    *param@65 = _13011;
    float* _13013 = &rampProfile.z;
    float _13014 = *_13013;
    *param@66 = _13014;
    float3 _13015 = specularRampEnvironment(param@64, param@65, param@66);
    *f0 = _13015;
  }

  bool _13016 = *strandDiffuse;
  
  if(_13016) {
    *f0 = {0.0000, 0.0000, 0.0000};
  }

  float3 _13020 = *shadedNormal;
  float3 _13021 = *viewDirection;
  float _13022 = Dot(_13020, _13021);
  float _13023 = GLSL.std.450::FMax(_13022, 0.0000);
  *normalDotView = _13023;
  
  if(azureOrdinaryOpaque) {
    *_13025 = 0;
  } else {
    
    if(_13029) {
      *_13030 = azureFixedMaterialClass;
    } else {
      uint* _13034 = &material.materialClass;
      uint _13035 = *_13034;
      *_13030 = _13035;
    }

    uint _13036 = *_13030;
    *_13025 = _13036;
  }

  uint _13037 = *_13025;
  bool _13038 = _13037 == 0;
  bool _13039 = !_13038;
  
  if(_13039) {
    
    if(azureOrdinaryOpaque) {
      *_13042 = 0;
    } else {
      
      if(_13046) {
        *_13047 = azureFixedMaterialClass;
      } else {
        uint* _13051 = &material.materialClass;
        uint _13052 = *_13051;
        *_13047 = _13052;
      }

      uint _13053 = *_13047;
      *_13042 = _13053;
    }

    uint _13054 = *_13042;
    bool _13055 = _13054 == 4;
  }

  bool _13056 = Phi(_13038, _13055);
  bool _13057 = !_13056;
  
  if(_13057) {
    
    if(azureOrdinaryOpaque) {
      *_13060 = 0;
    } else {
      
      if(_13064) {
        *_13065 = azureFixedMaterialClass;
      } else {
        uint* _13069 = &material.materialClass;
        uint _13070 = *_13069;
        *_13065 = _13070;
      }

      uint _13071 = *_13065;
      *_13060 = _13071;
    }

    uint _13072 = *_13060;
    bool _13073 = _13072 == 5;
  }

  bool _13074 = Phi(_13056, _13073);
  bool _13075 = !_13074;
  
  if(_13075) {
    
    if(azureOrdinaryOpaque) {
      *_13078 = 0;
    } else {
      
      if(_13082) {
        *_13083 = azureFixedMaterialClass;
      } else {
        uint* _13087 = &material.materialClass;
        uint _13088 = *_13087;
        *_13083 = _13088;
      }

      uint _13089 = *_13083;
      *_13078 = _13089;
    }

    uint _13090 = *_13078;
    bool _13091 = _13090 == 9;
  }

  bool _13092 = Phi(_13074, _13091);
  *microfacetSurface = _13092;
  float3 _13094 = *f0;
  float3 _13095 = *f0;
  float3 _13096 = CompositeConstruct({1.0000, 1.0000, 1.0000});
  float3 _13097 = _13096 - _13095;
  float _13098 = *normalDotView;
  float _13099 = 1.0000 - _13098;
  float _13100 = GLSL.std.450::Pow(_13099, 5.0000);
  float3 _13101 = _13097 * _13100;
  float3 _13102 = _13094 + _13101;
  *fresnel = _13102;
  bool _13103 = *strandDiffuse;
  
  if(_13103) {
    *fresnel = {0.0000, 0.0000, 0.0000};
  }

  float* _13107 = &camera.clusterLighting.x;
  float _13108 = *_13107;
  bool _13109 = _13108 > 0.5000;
  
  if(_13109) {
    float* _13112 = &camera.clusterLighting.w;
    float _13113 = *_13112;
    bool _13114 = _13113 > 0.5000;
  }

  bool _13115 = Phi(_13109, _13114);
  
  if(_13115) {
    
    if(azureOrdinaryOpaque) {
      *_13118 = 0;
    } else {
      
      if(_13122) {
        *_13123 = azureFixedMaterialClass;
      } else {
        uint* _13127 = &material.materialClass;
        uint _13128 = *_13127;
        *_13123 = _13128;
      }

      uint _13129 = *_13123;
      *_13118 = _13129;
    }

    uint _13130 = *_13118;
    bool _13131 = _13130 == 0;
  }

  bool _13132 = Phi(_13115, _13131);
  *fittedEnvironment = _13132;
  bool _13134 = *fittedEnvironment;
  
  if(_13134) {
    bool _13138 = *specularRamp;
    
    if(_13138) {
      float3 _13142 = *f0;
      *_13139 = _13142;
    } else {
      float4 _13145 = *baseColor;
      float3 _13146 = _13145.xyz;
      float _13147 = *metallic;
      float3 _13148 = CompositeConstruct({_13147, _13147, _13147});
      float3 _13149 = GLSL.std.450::FMix({0.0400, 0.0400, 0.0400}, _13146, _13148);
      *_13139 = _13149;
    }

    float3 _13151 = *_13139;
    *param@67 = _13151;
    float _13153 = *roughness;
    *param@68 = _13153;
    float _13155 = *normalDotView;
    *param@69 = _13155;
    float3 _13156 = ggxMultiscatterEnvironment(param@67, param@68, param@69);
    *_13135 = _13156;
  } else {
    float3 _13158 = *fresnel;
    *_13135 = _13158;
  }

  float3 _13159 = *_13135;
  *environmentResponse = _13159;
  float4 _13161 = *baseColor;
  float3 _13162 = _13161.xyz;
  float _13163 = *metallic;
  float _13164 = 1.0000 - _13163;
  float3 _13165 = _13162 * _13164;
  float _13166 = *projectedDiffuseScale;
  float3 _13167 = _13165 * _13166;
  *diffuseColor = _13167;
  SampledImage<float, 2D>* _13169 = &textureArray[0];
  SampledImage<float, 2D> _13170 = *_13169;
  float3 _13172 = *shadedNormal;
  *param@70 = _13172;
  float2 _13173 = directionToEquirectangular(param@70);
  float4 _13174 = ImageSampleExplicitLod(_13170, _13173, Lod(6.0000));
  float3 _13175 = _13174.xyz;
  *environmentDiffuse = _13175;
  *envMipCount = 7.0000;
  float _13179 = *roughness;
  float _13180 = *envMipCount;
  float _13181 = _13180 - 1.0000;
  float _13182 = _13179 * _13181;
  float _13183 = *envMipCount;
  float _13184 = _13183 - 1.0000;
  float _13185 = GLSL.std.450::FClamp(_13182, 0.0000, _13184);
  *specularMip = _13185;
  SampledImage<float, 2D>* _13187 = &textureArray[0];
  SampledImage<float, 2D> _13188 = *_13187;
  float3 _13190 = *reflectionDirection;
  *param@71 = _13190;
  float2 _13191 = directionToEquirectangular(param@71);
  float _13192 = *specularMip;
  float4 _13193 = ImageSampleExplicitLod(_13188, _13191, Lod(_13192));
  float3 _13194 = _13193.xyz;
  *environmentSpecular = _13194;
  float3 _13195 = *environmentSpecular;
  float _13199 = *roughness;
  float _13200 = *roughness;
  float _13201 = _13199 * _13200;
  float _13202 = _13201 * 0.6500;
  float3 _13203 = CompositeConstruct({_13202, _13202, _13202});
  float3 _13204 = GLSL.std.450::FMix(_13195, {0.1800, 0.2200, 0.2600}, _13203);
  *environmentSpecular = _13204;
  float3 _13206 = *diffuseColor;
  float3 _13208 = *environmentDiffuse;
  float3 _13209 = _13208 * 0.8200;
  float3 _13210 = {0.3200, 0.3200, 0.3200} + _13209;
  float3 _13211 = _13206 * _13210;
  *ambientDiffuse = _13211;
  float3 _13213 = *environmentDiffuse;
  float _13218 = Dot(_13213, {0.2126, 0.7152, 0.0722});
  *environmentLuminance = _13218;
  float3 _13220 = *diffuseColor;
  float _13221 = *environmentLuminance;
  float _13222 = GLSL.std.450::FMin(_13221, 0.8000);
  float _13223 = _13222 * 0.2600;
  float _13224 = 0.4200 + _13223;
  float3 _13225 = _13220 * _13224;
  *hairAmbientDiffuse = _13225;
  float3 _13226 = *ambientDiffuse;
  float3 _13227 = *hairAmbientDiffuse;
  float _13228 = *hairActive;
  float3 _13229 = CompositeConstruct({_13228, _13228, _13228});
  float3 _13230 = GLSL.std.450::FMix(_13226, _13227, _13229);
  *ambientDiffuse = _13230;
  float _13231 = *showcasePreset;
  bool _13232 = _13231 == 1.0000;
  float _13233 = Select(_13232, 0.8500, 1.0000);
  float3 _13234 = *ambientDiffuse;
  float3 _13235 = _13234 * _13233;
  *ambientDiffuse = _13235;
  float _13237 = *shadowVisibility;
  float _13238 = GLSL.std.450::FMix(0.4400, 1.0000, _13237);
  float _13239 = *platformMask;
  float _13240 = GLSL.std.450::FMix(1.0000, _13238, _13239);
  *platformAmbientVisibility = _13240;
  float _13241 = *platformAmbientVisibility;
  float3 _13242 = *ambientDiffuse;
  float3 _13243 = _13242 * _13241;
  *ambientDiffuse = _13243;
  float3 _13245 = *environmentSpecular;
  float3 _13246 = *fresnel;
  float3 _13247 = _13245 * _13246;
  float _13249 = *roughness;
  float _13250 = GLSL.std.450::FMix(0.7000, 0.2000, _13249);
  float3 _13251 = _13247 * _13250;
  *ambientSpecular = _13251;
  float4 _13252 = *baseColor;
  float3 _13253 = _13252.xyz;
  float _13254 = *metallic;
  float3 _13255 = _13253 * _13254;
  float _13257 = *roughness;
  float _13258 = GLSL.std.450::FMix(0.0600, 0.0150, _13257);
  float3 _13259 = _13255 * _13258;
  float3 _13260 = *ambientSpecular;
  float3 _13261 = _13260 + _13259;
  *ambientSpecular = _13261;
  int _13263 = *qaEffectMode;
  bool _13264 = _13263 == 1;
  bool _13265 = *qaEffectDisabled;
  bool _13266 = _13264 && _13265;
  float _13267 = *bandEnabled;
  float _13268 = Select(_13266, 0.0000, _13267);
  *toonEnabled = _13268;
  float _13270 = *toonEnabled;
  float* _13271 = &material.styleParameters.x;
  float _13272 = *_13271;
  float _13273 = _13270 * _13272;
  float _13274 = GLSL.std.450::FClamp(_13273, 0.0000, 1.0000);
  *toonWeight = _13274;
  float _13276 = *diffuseBandThreshold;
  float _13277 = GLSL.std.450::FMax(_13276, 0.0000);
  float _13278 = 0.4000 - _13277;
  *rampThresholdOffset = _13278;
  float _13280 = *diffuse;
  float _13281 = *rampThresholdOffset;
  float _13282 = _13280 + _13281;
  float _13283 = *styleMask;
  float* _13285 = &material.styleParameters.y;
  float _13286 = *_13285;
  float _13287 = GLSL.std.450::FMix(0.0400, 0.1300, _13286);
  float _13288 = _13283 * _13287;
  float _13289 = _13282 - _13288;
  float _13290 = GLSL.std.450::FClamp(_13289, 0.0000, 1.0000);
  *rampCoordinate = _13290;
  *faceSdfSample = {0.0000, 0.0000, 0.0000, 0.0000};
  
  if(azureOrdinaryOpaque) {
    *_13293 = 0;
  } else {
    
    if(_13297) {
      *_13298 = azureFixedMaterialClass;
    } else {
      uint* _13302 = &material.materialClass;
      uint _13303 = *_13302;
      *_13298 = _13303;
    }

    uint _13304 = *_13298;
    *_13293 = _13304;
  }

  uint _13305 = *_13293;
  bool _13306 = _13305 == 2;
  
  if(_13306) {
    *param@72 = 4;
    float _13311 = materialFeatureEnabled(param@72);
    *_13307 = _13311;
  } else {
    *_13307 = 0.0000;
  }

  float _13313 = *_13307;
  *faceSdfEligible = _13313;
  float* _13315 = &camera.faceSdfParameters.x;
  float _13316 = *_13315;
  float* _13318 = &instanceFaceDirection.w;
  float _13319 = *_13318;
  float _13320 = _13316 * _13319;
  float _13321 = *faceSdfEligible;
  float _13322 = _13320 * _13321;
  *faceSdfEnabled = _13322;
  int _13323 = *qaEffectMode;
  bool _13324 = _13323 == 8;
  bool _13325 = *qaEffectDisabled;
  bool _13326 = _13324 && _13325;
  
  if(_13326) {
    *faceSdfEnabled = 0.0000;
  }

  float _13329 = *faceSdfEnabled;
  bool _13330 = _13329 > 0.0000;
  
  if(_13330) {
    uint* _13333 = &material.textureBase;
    uint _13334 = *_13333;
    uint _13335 = _13334 + 7;
    uint _13336 = CopyObject(_13335) : [[NonUniform]];
    SampledImage<float, 2D>* _13337 = &textureArray[_13336] : [[NonUniform]];
    SampledImage<float, 2D> _13338 = *_13337 : [[NonUniform]];
    float2 _13339 = *textureCoordinate;
    float4 _13340 = ImageSampleImplicitLod(_13338, _13339);
    *faceSdfSample = _13340;
  }

  float* _13342 = &camera.faceSdfParameters.w;
  float _13343 = *_13342;
  bool _13344 = _13343 > 0.5000;
  
  if(_13344) {
    float* _13348 = &faceSdfSample.x;
    float _13349 = *_13348;
    float _13350 = 1.0000 - _13349;
    *_13345 = _13350;
  } else {
    float* _13352 = &faceSdfSample.x;
    float _13353 = *_13352;
    *_13345 = _13353;
  }

  float _13354 = *_13345;
  *faceCoordinate = _13354;
  float* _13356 = &instanceFaceDirection.x;
  float _13357 = *_13356;
  *lateralLight = _13357;
  float* _13359 = &instanceFaceDirection.z;
  float _13360 = *_13359;
  float _13361 = -_13360;
  float _13362 = GLSL.std.450::FMax(_13361, 0.0000);
  *frontLight = _13362;
  float _13365 = *lateralLight;
  float _13366 = GLSL.std.450::SmoothStep(-0.6000, 0.6000, _13365);
  *faceSideBlend = _13366;
  float _13368 = *faceCoordinate;
  float _13369 = 1.0000 - _13368;
  float _13370 = *faceCoordinate;
  float _13371 = *faceSideBlend;
  float _13372 = GLSL.std.450::FMix(_13369, _13370, _13371);
  *orientedCoordinate = _13372;
  float* _13374 = &camera.faceSdfParameters.y;
  float _13375 = *_13374;
  float _13376 = *frontLight;
  float _13377 = _13376 * 0.3400;
  float _13378 = _13375 - _13377;
  float _13379 = *lateralLight;
  float _13380 = GLSL.std.450::FAbs(_13379);
  float _13381 = 1.0000 - _13380;
  float _13382 = _13381 * 0.0400;
  float _13383 = _13378 + _13382;
  float _13384 = GLSL.std.450::FClamp(_13383, 0.0800, 0.9200);
  *faceThreshold = _13384;
  float* _13386 = &camera.faceSdfParameters.z;
  float _13387 = *_13386;
  float _13388 = GLSL.std.450::FMax(_13387, 0.1800);
  *faceSoftness = _13388;
  float _13390 = *faceThreshold;
  float _13391 = *faceSoftness;
  float _13392 = _13390 - _13391;
  float _13393 = *faceThreshold;
  float _13394 = *faceSoftness;
  float _13395 = _13393 + _13394;
  float _13396 = *orientedCoordinate;
  float _13397 = GLSL.std.450::SmoothStep(_13392, _13395, _13396);
  *faceIllumination = _13397;
  float _13399 = *faceSdfEnabled;
  float* _13400 = &faceSdfSample.w;
  float _13401 = *_13400;
  float _13402 = _13399 * _13401;
  float _13403 = _13402 * 0.8200;
  *faceSdfWeight = _13403;
  float _13404 = *rampCoordinate;
  float _13405 = *faceIllumination;
  float _13406 = GLSL.std.450::FMix(0.4400, 0.7400, _13405);
  float _13407 = *faceSdfWeight;
  float _13408 = GLSL.std.450::FMix(_13404, _13406, _13407);
  *rampCoordinate = _13408;
  float _13410 = *faceSdfEnabled;
  bool _13411 = _13410 > 0.0000;
  
  if(_13411) {
    *param@73 = 2048;
    float _13415 = materialFeatureEnabled(param@73);
    bool _13416 = _13415 > 0.5000;
  }

  bool _13417 = Phi(_13411, _13416);
  *dualFaceSdf = _13417;
  *signedMainRamp = false;
  bool _13419 = *eyeNpr;
  
  if(_13419) {
    float3 _13423 = *lightDirection;
    *eyeLight = _13423;
    uint* _13424 = &material.materialPadding;
    uint _13425 = *_13424;
    uint _13426 = _13425 >> 1;
    float* _13427 = &materialSurfaceProfiles.profiles[_13426].rows[6].y;
    float _13428 = *_13427;
    bool _13429 = _13428 > 0.5000;
    
    if(_13429) {
      float4* _13433 = &instanceFaceFrame[0];
      float4 _13434 = *_13433;
      float3 _13435 = _13434.xyz;
      *side = _13435;
      float4* _13437 = &instanceFaceFrame[2];
      float4 _13438 = *_13437;
      float3 _13439 = _13438.xyz;
      *front = _13439;
      float3 _13441 = *side;
      float3 _13442 = *eyeLight;
      float3 _13443 = *side;
      float _13444 = Dot(_13442, _13443);
      float3 _13445 = _13441 * _13444;
      float3 _13446 = *front;
      float3 _13447 = *eyeLight;
      float3 _13448 = *front;
      float _13449 = Dot(_13447, _13448);
      float3 _13450 = _13446 * _13449;
      float3 _13451 = _13445 + _13450;
      *projected = _13451;
      float3 _13452 = *projected;
      float3 _13453 = *projected;
      float _13454 = Dot(_13452, _13453);
      bool _13455 = _13454 > 0.0000;
      
      if(_13455) {
        float3 _13458 = *projected;
        float3 _13459 = GLSL.std.450::Normalize(_13458);
        *eyeLight = _13459;
      }

    }

    *signedMainRamp = true;
    float3 _13461 = *shadedNormal;
    *param@74 = _13461;
    float3 _13463 = *eyeLight;
    *param@75 = _13463;
    *param@76 = 0.0000;
    float _13465 = characterMainRampCoordinate(param@74, param@75, param@76);
    *rampCoordinate = _13465;
  }

  *param@77 = 524288;
  float _13467 = materialFeatureEnabled(param@77);
  bool _13468 = _13467 > 0.5000;
  bool _13469 = *dualFaceSdf;
  bool _13470 = !_13469;
  bool _13471 = _13468 && _13470;
  
  if(_13471) {
    uint* _13475 = &material.materialPadding;
    uint _13476 = *_13475;
    uint _13477 = _13476 >> 1;
    float4* _13478 = &materialSurfaceProfiles.profiles[_13477].rows[1];
    float4 _13479 = *_13478;
    *rampInput = _13479;
    float* _13480 = &rampInput.y;
    float _13481 = *_13480;
    bool _13482 = _13481 > 0.5000;
    *signedMainRamp = _13482;
    bool _13483 = *signedMainRamp;
    
    if(_13483) {
      float3 _13487 = *shadedNormal;
      *param@78 = _13487;
      float3 _13489 = *lightDirection;
      *param@79 = _13489;
      float* _13491 = &rampInput.z;
      float _13492 = *_13491;
      *param@80 = _13492;
      float _13493 = characterMainRampCoordinate(param@78, param@79, param@80);
      *rampCoordinate = _13493;
    }

  }

  float3 _13495 = *shadedNormal;
  *faceLightingNormal = _13495;
  bool _13496 = *dualFaceSdf;
  
  if(_13496) {
    int _13499 = *qaEffectMode;
    bool _13500 = _13499 == 1;
    bool _13501 = *qaEffectDisabled;
    bool _13502 = _13500 && _13501;
    float _13503 = Select(_13502, 0.0000, 1.0000);
    *toonWeight = _13503;
    float3 _13505 = *lightDirection;
    *param@81 = _13505;
    float3 _13507 = *shadedNormal;
    *param@82 = _13507;
    float _13509 = dualFaceRampCoordinate(param@81, param@82, param@83);
    float4 _13510 = *param@83;
    *faceSdfSample = _13510;
    *rampCoordinate = _13509;
    float4x4 _13512 = *instanceFaceFrame;
    float4 _13513 = _13512[0];
    float3 _13514 = _13513.xyz;
    float4 _13515 = _13512[1];
    float3 _13516 = _13515.xyz;
    float4 _13517 = _13512[2];
    float3 _13518 = _13517.xyz;
    float3x3 _13519 = CompositeConstruct({_13514, _13516, _13518});
    *headFrame = _13519;
    float3x3 _13521 = *headFrame;
    float3x3 _13522 = Transpose(_13521);
    float3 _13523 = *lightDirection;
    float3 _13524 = _13522 * _13523;
    float _13525 = _13524.x;
    *localLightX = _13525;
    uint* _13527 = &material.textureBase;
    uint _13528 = *_13527;
    uint _13529 = _13528 + 4;
    uint _13530 = CopyObject(_13529) : [[NonUniform]];
    SampledImage<float, 2D>* _13531 = &textureArray[_13530] : [[NonUniform]];
    SampledImage<float, 2D> _13532 = *_13531 : [[NonUniform]];
    float2 _13533 = *textureCoordinate;
    float4 _13534 = ImageSampleExplicitLod(_13532, _13533, Lod(0.0000));
    float _13535 = _13534.y;
    *geometryMix = _13535;
    float4 _13537 = *faceSdfSample;
    *param@84 = _13537;
    float _13539 = *localLightX;
    *param@85 = _13539;
    float3x3 _13541 = *headFrame;
    *param@86 = _13541;
    float3 _13543 = *shadedNormal;
    *param@87 = _13543;
    float _13545 = *geometryMix;
    *param@88 = _13545;
    float3 _13546 = faceSdfWorldNormal(param@84, param@85, param@86, param@87, param@88);
    *faceLightingNormal = _13546;
    float _13547 = *rampCoordinate;
    *faceIllumination = _13547;
    *faceSdfWeight = 0.0000;
  }

  bool _13549 = *dualFaceSdf;
  
  if(_13549) {
    uint* _13553 = &material.textureBase;
    uint _13554 = *_13553;
    uint _13555 = _13554 + 5;
    uint _13556 = CopyObject(_13555) : [[NonUniform]];
    SampledImage<float, 2D>* _13557 = &textureArray[_13556] : [[NonUniform]];
    SampledImage<float, 2D> _13558 = *_13557 : [[NonUniform]];
    float _13559 = *rampCoordinate;
    float2 _13560 = CompositeConstruct({_13559, 0.5000});
    float4 _13561 = ImageSampleExplicitLod(_13558, _13560, Lod(0.0000));
    *_13550 = _13561;
  } else {
    bool _13563 = *signedMainRamp;
    
    if(_13563) {
      uint* _13567 = &material.textureBase;
      uint _13568 = *_13567;
      uint _13569 = _13568 + 4;
      uint _13570 = CopyObject(_13569) : [[NonUniform]];
      SampledImage<float, 2D>* _13571 = &textureArray[_13570] : [[NonUniform]];
      SampledImage<float, 2D> _13572 = *_13571 : [[NonUniform]];
      float _13573 = *rampCoordinate;
      float2 _13574 = CompositeConstruct({_13573, 0.5000});
      float4 _13575 = ImageSampleExplicitLod(_13572, _13574, Lod(0.0000));
      *_13564 = _13575;
    } else {
      float _13578 = *rampCoordinate;
      *param@89 = _13578;
      float4 _13579 = materialDiffuseRampRgba(param@89);
      *_13564 = _13579;
    }

    float4 _13580 = *_13564;
    *_13550 = _13580;
  }

  float4 _13581 = *_13550;
  *classRampRgba = _13581;
  float4 _13583 = *classRampRgba;
  float3 _13584 = _13583.xyz;
  *classRamp = _13584;
  float3 _13586 = *shadedNormal;
  *indirectDiffuseNormal = _13586;
  bool _13587 = *eyeNpr;
  
  if(_13587) {
    float3 _13591 = *shadedNormal;
    *param@90 = _13591;
    float3 _13592 = worldHorizontalDiffuseNormal(param@90);
    *indirectDiffuseNormal = _13592;
  }

  bool _13593 = *nprDiffuse;
  
  if(_13593) {
    uint* _13597 = &material.materialPadding;
    uint _13598 = *_13597;
    uint _13599 = _13598 >> 1;
    float* _13600 = &materialSurfaceProfiles.profiles[_13599].rows[0].w;
    float _13601 = *_13600;
    *normalMode = _13601;
    float _13602 = *normalMode;
    bool _13603 = _13602 > 1.5000;
    
    if(_13603) {
      bool _13606 = *dualFaceSdf;
      
      if(_13606) {
        uint* _13609 = &material.textureBase;
        uint _13610 = *_13609;
        uint _13611 = _13610 + 4;
        uint _13612 = CopyObject(_13611) : [[NonUniform]];
        SampledImage<float, 2D>* _13613 = &textureArray[_13612] : [[NonUniform]];
        SampledImage<float, 2D> _13614 = *_13613 : [[NonUniform]];
        float2 _13615 = *textureCoordinate;
        float4 _13616 = ImageSampleExplicitLod(_13614, _13615, Lod(0.0000));
        float3 _13618 = *worldPosition;
        *param@91 = _13618;
        float4* _13620 = &instanceFaceFrame[3];
        float4 _13621 = *_13620;
        float3 _13622 = _13621.xyz;
        *param@92 = _13622;
        float3 _13624 = *geometricNormal;
        *param@93 = _13624;
        float _13626 = _13616.y;
        *param@94 = _13626;
        float3 _13627 = faceFrameRadialHorizontalDiffuseNormal(param@91, param@92, param@93, param@94);
        *indirectDiffuseNormal = _13627;
      }

    } else {
      float _13629 = *normalMode;
      bool _13630 = _13629 > 0.5000;
      
      if(_13630) {
        float3 _13634 = *shadedNormal;
        *param@95 = _13634;
        float3 _13635 = worldHorizontalDiffuseNormal(param@95);
        *indirectDiffuseNormal = _13635;
      }

    }

  }

  bool _13637 = *nprDiffuse;
  
  if(_13637) {
    float4 _13642 = *baseColor;
    *param@96 = _13642;
    float _13644 = *metallic;
    *param@97 = _13644;
    float4 _13646 = *classRampRgba;
    *param@98 = _13646;
    float _13648 = *nprBaseAo;
    *param@99 = _13648;
    float _13650 = *nprMainShadowVisibility;
    *param@100 = _13650;
    float _13652 = *nprMainShadowVisibility;
    *param@101 = _13652;
    float3 _13654 = *shadedNormal;
    *param@102 = _13654;
    float3 _13656 = *viewDirection;
    *param@103 = _13656;
    float3 _13657 = materialNprDiffuse(param@96, param@97, param@98, param@99, param@100, param@101, param@102, param@103);
    *_13638 = _13657;
  } else {
    float3 _13659 = *diffuseColor;
    *_13638 = _13659;
  }

  float3 _13660 = *_13638;
  *nprAmbientResponse = _13660;
  float* _13662 = &camera.nprLightingParameters.x;
  float _13663 = *_13662;
  bool _13664 = _13663 > 0.5000;
  
  if(_13664) {
    float _13668 = *nprMainShadowVisibility;
    float* _13669 = &camera.nprGainFloor.z;
    float _13670 = *_13669;
    float _13671 = GLSL.std.450::FMix(_13668, 1.0000, _13670);
    *_13665 = _13671;
  } else {
    float _13673 = *shadowVisibility;
    *_13665 = _13673;
  }

  float _13674 = *_13665;
  *characterSceneVisibility = _13674;
  float3 _13676 = *diffuseColor;
  *localCharacterDiffuse = _13676;
  *localCharacterResponseReady = false;
  *projectedVisibility = 1.0000;
  float _13680 = *physicalAo;
  *projectedOcclusion = _13680;
  *hairViewAlpha = 1.0000;
  bool _13682 = *projectedLighting;
  
  if(_13682) {
    uint* _13686 = &material.materialPadding;
    uint _13687 = *_13686;
    uint _13688 = _13687 >> 1;
    float* _13689 = &materialSurfaceProfiles.profiles[_13688].rows[6].x;
    float _13690 = *_13689;
    uint _13691 = ConvertFToU(_13690);
    uint _13692 = _13691 >> 1;
    *encoded = _13692;
    uint _13693 = *encoded;
    bool _13694 = _13693 == 0;
    
    if(_13694) {
      *_13695 = 3;
    } else {
      uint _13699 = *encoded;
      uint _13700 = _13699 - 1;
      *_13695 = _13700;
    }

    uint _13702 = *_13695;
    *param@104 = _13702;
    float3 _13704 = *shadedNormal;
    *param@105 = _13704;
    float _13706 = *characterSceneVisibility;
    *param@106 = _13706;
    float _13708 = *nprMainShadowVisibility;
    *param@107 = _13708;
    float _13709 = materialCharacterVisibility(param@104, param@105, param@106, param@107);
    *projectedVisibility = _13709;
    float _13710 = *projectedVisibility;
    float _13711 = *projectedOcclusion;
    float _13712 = _13711 * _13710;
    *projectedOcclusion = _13712;
    float4 _13715 = *baseColor;
    float3 _13716 = _13715.xyz;
    *param@108 = _13716;
    float3 _13718 = *shadedNormal;
    *param@109 = _13718;
    float3 _13720 = *lightDirection;
    *param@110 = _13720;
    float _13722 = *projectedOcclusion;
    *param@111 = _13722;
    float _13724 = *characterSceneVisibility;
    *param@112 = _13724;
    CharacterDiffuseResponse _13726 = projectedHairDiffuseResponse(param@108, param@109, param@110, param@111, param@112, param@113);
    float _13727 = *param@113;
    *hairViewAlpha = _13727;
    *hairDiffuseResponse = _13726;
    float3* _13728 = &hairDiffuseResponse.color;
    float3 _13729 = *_13728;
    *localCharacterDiffuse = _13729;
    *localCharacterResponseReady = true;
  }

  
  if(azureOrdinaryOpaque) {
    *_13731 = 0;
  } else {
    
    if(_13735) {
      *_13736 = azureFixedMaterialClass;
    } else {
      uint* _13740 = &material.materialClass;
      uint _13741 = *_13740;
      *_13736 = _13741;
    }

    uint _13742 = *_13736;
    *_13731 = _13742;
  }

  float3 _13744 = *classRamp;
  *param@114 = _13744;
  float _13746 = *toonWeight;
  *param@115 = _13746;
  uint _13748 = *_13731;
  *param@116 = _13748;
  float3 _13749 = toonIndirectChroma(param@114, param@115, param@116);
  *indirectChroma = _13749;
  float3 _13751 = *classRamp;
  float _13752 = Dot(_13751, {0.2126, 0.7152, 0.0722});
  *rampLuminance = _13752;
  float _13754 = *diffuse;
  float3 _13755 = CompositeConstruct({_13754, _13754, _13754});
  float3 _13756 = *classRamp;
  float _13757 = *toonWeight;
  float3 _13758 = CompositeConstruct({_13757, _13757, _13757});
  float3 _13759 = GLSL.std.450::FMix(_13755, _13756, _13758);
  *diffuseResponse = _13759;
  float _13761 = *showcasePreset;
  bool _13762 = _13761 == 1.0000;
  float _13763 = Select(_13762, 0.7200, 0.7200);
  float _13764 = *rampLuminance;
  float _13765 = GLSL.std.450::FMix(_13763, 0.9800, _13764);
  float _13766 = *toonWeight;
  float _13767 = GLSL.std.450::FMix(1.0000, _13765, _13766);
  *ambientRampVisibility = _13767;
  float _13768 = *ambientRampVisibility;
  float3 _13769 = *indirectChroma;
  float3 _13770 = _13769 * _13768;
  float3 _13771 = *ambientDiffuse;
  float3 _13772 = _13771 * _13770;
  *ambientDiffuse = _13772;
  bool _13774 = *strandDiffuse;
  
  if(_13774) {
    *_13775 = 1.0000;
  } else {
    float _13779 = *toonWeight;
    float _13780 = GLSL.std.450::FMix(0.6200, 0.6800, _13779);
    *_13775 = _13780;
  }

  float _13781 = *_13775;
  *diffuseScale = _13781;
  float3 _13783 = *diffuseColor;
  float3 _13784 = *diffuseResponse;
  float _13785 = *diffuseScale;
  float3 _13786 = _13784 * _13785;
  float3 _13787 = *keyColor;
  float3 _13788 = _13786 * _13787;
  float* _13789 = &camera.showcaseParameters.y;
  float _13790 = *_13789;
  float3 _13791 = _13788 * _13790;
  float _13792 = *keyVisibility;
  float3 _13793 = _13791 * _13792;
  float _13794 = *fillDiffuse;
  float* _13795 = &camera.showcaseParameters.z;
  float _13796 = *_13795;
  float _13797 = _13794 * _13796;
  float3 _13798 = *fillColor;
  float3 _13799 = _13798 * _13797;
  float3 _13800 = *indirectChroma;
  float3 _13801 = _13799 * _13800;
  float3 _13802 = _13793 + _13801;
  float3 _13803 = _13783 * _13802;
  *directDiffuse = _13803;
  float _13804 = *hairActive;
  float _13805 = GLSL.std.450::FMix(1.0000, 0.7200, _13804);
  float3 _13806 = *directDiffuse;
  float3 _13807 = _13806 * _13805;
  *directDiffuse = _13807;
  float* _13809 = &camera.clusterGrid.x;
  float _13810 = *_13809;
  uint _13811 = ConvertFToU(_13810);
  uint _13812 = GLSL.std.450::UMax(_13811, 1);
  *gridX = _13812;
  float* _13814 = &camera.clusterGrid.y;
  float _13815 = *_13814;
  uint _13816 = ConvertFToU(_13815);
  uint _13817 = GLSL.std.450::UMax(_13816, 1);
  *gridY = _13817;
  float* _13819 = &camera.clusterGrid.z;
  float _13820 = *_13819;
  uint _13821 = ConvertFToU(_13820);
  uint _13822 = GLSL.std.450::UMax(_13821, 1);
  *gridZ = _13822;
  float4 _13824 = *gl_FragCoord;
  float2 _13825 = _13824.xy;
  float4* _13826 = &camera.clusterDepth;
  float4 _13827 = *_13826;
  float2 _13828 = _13827.zw;
  float2 _13829 = GLSL.std.450::FMax(_13828, {1.0000, 1.0000});
  float2 _13830 = _13825 / _13829;
  *screenUv = _13830;
  float* _13832 = &screenUv.x;
  float _13833 = *_13832;
  float _13834 = GLSL.std.450::FClamp(_13833, 0.0000, 1.0000);
  uint _13835 = *gridX;
  float _13836 = ConvertUToF(_13835);
  float _13837 = _13834 * _13836;
  uint _13838 = ConvertFToU(_13837);
  uint _13839 = *gridX;
  uint _13840 = _13839 - 1;
  uint _13841 = GLSL.std.450::UMin(_13838, _13840);
  *clusterX = _13841;
  float* _13843 = &screenUv.y;
  float _13844 = *_13843;
  float _13845 = GLSL.std.450::FClamp(_13844, 0.0000, 1.0000);
  uint _13846 = *gridY;
  float _13847 = ConvertUToF(_13846);
  float _13848 = _13845 * _13847;
  uint _13849 = ConvertFToU(_13848);
  uint _13850 = *gridY;
  uint _13851 = _13850 - 1;
  uint _13852 = GLSL.std.450::UMin(_13849, _13851);
  *clusterY = _13852;
  float* _13854 = &camera.clusterDepth.x;
  float _13855 = *_13854;
  float _13856 = GLSL.std.450::FMax(_13855, 0.0010);
  *nearDepth = _13856;
  float* _13858 = &camera.clusterDepth.y;
  float _13859 = *_13858;
  float _13860 = *nearDepth;
  float _13861 = _13860 + 0.0010;
  float _13862 = GLSL.std.450::FMax(_13859, _13861);
  *farDepth = _13862;
  float3 _13864 = *worldPosition;
  float4* _13865 = &camera.cameraPosition;
  float4 _13866 = *_13865;
  float3 _13867 = _13866.xyz;
  float3 _13868 = _13864 - _13867;
  float4* _13869 = &camera.cameraForward;
  float4 _13870 = *_13869;
  float3 _13871 = _13870.xyz;
  float _13872 = Dot(_13868, _13871);
  float _13873 = *nearDepth;
  float _13874 = GLSL.std.450::FMax(_13872, _13873);
  *viewDepth = _13874;
  float _13876 = *viewDepth;
  float _13877 = *nearDepth;
  float _13878 = _13876 / _13877;
  float _13879 = GLSL.std.450::Log(_13878);
  float _13880 = *farDepth;
  float _13881 = *nearDepth;
  float _13882 = _13880 / _13881;
  float _13883 = GLSL.std.450::Log(_13882);
  float _13884 = _13879 / _13883;
  *logarithmicDepth = _13884;
  float _13886 = *logarithmicDepth;
  float _13887 = GLSL.std.450::FClamp(_13886, 0.0000, 1.0000);
  uint _13888 = *gridZ;
  float _13889 = ConvertUToF(_13888);
  float _13890 = _13887 * _13889;
  uint _13891 = ConvertFToU(_13890);
  uint _13892 = *gridZ;
  uint _13893 = _13892 - 1;
  uint _13894 = GLSL.std.450::UMin(_13891, _13893);
  *clusterZ = _13894;
  uint _13896 = *clusterZ;
  uint _13897 = *gridY;
  uint _13898 = _13896 * _13897;
  uint _13899 = *clusterY;
  uint _13900 = _13898 + _13899;
  uint _13901 = *gridX;
  uint _13902 = _13900 * _13901;
  uint _13903 = *clusterX;
  uint _13904 = _13902 + _13903;
  *clusterIndex = _13904;
  *clusteredDiffuse = {0.0000, 0.0000, 0.0000};
  *sceneMainDiffuse = {0.0000, 0.0000, 0.0000};
  *clusteredSpecular = {0.0000, 0.0000, 0.0000};
  *sceneHairPrimary = {0.0000, 0.0000, 0.0000};
  *sceneHairSecondary = {0.0000, 0.0000, 0.0000};
  *sceneRim = {0.0000, 0.0000, 0.0000};
  *mainHairPrimary = {0.0000, 0.0000, 0.0000};
  *mainHairSecondary = {0.0000, 0.0000, 0.0000};
  *mainHairAvailable = false;
  *eyeHostDiffuse = {0.0000, 0.0000, 0.0000};
  *eyeHostMatcap = {0.0000, 0.0000, 0.0000};
  *eyeMatcap = {0.0000, 0.0000, 0.0000, 0.0000};
  *eyeViewRampAlpha = 0.0000;
  *eyeDiffuseMultiplier = {0.0000, 0.0000, 0.0000};
  *eyeAlphaMultiplier = 1.0000;
  bool _13920 = *eyeRadial;
  
  if(_13920) {
    bool _13923 = *eyeNpr;
    
    if(_13923) {
      uint* _13927 = &material.textureBase;
      uint _13928 = *_13927;
      uint _13929 = _13928 + 5;
      uint _13930 = CopyObject(_13929) : [[NonUniform]];
      SampledImage<float, 2D>* _13931 = &textureArray[_13930] : [[NonUniform]];
      SampledImage<float, 2D> _13932 = *_13931 : [[NonUniform]];
      float2* _13933 = &eyeCoordinates.matcapUv;
      float2 _13934 = *_13933;
      float4 _13935 = ImageSampleImplicitLod(_13932, _13934);
      *_13924 = _13935;
    } else {
      uint* _13937 = &material.textureBase;
      uint _13938 = *_13937;
      uint _13939 = _13938 + 5;
      uint _13940 = CopyObject(_13939) : [[NonUniform]];
      SampledImage<float, 2D>* _13941 = &textureArray[_13940] : [[NonUniform]];
      SampledImage<float, 2D> _13942 = *_13941 : [[NonUniform]];
      float2* _13943 = &eyeCoordinates.matcapUv;
      float2 _13944 = *_13943;
      float4 _13945 = ImageSampleExplicitLod(_13942, _13944, Lod(0.0000));
      *_13924 = _13945;
    }

    float4 _13946 = *_13924;
    *eyeMatcap = _13946;
    float3 _13948 = *shadedNormal;
    float4* _13949 = &camera.cameraForward;
    float4 _13950 = *_13949;
    float3 _13951 = _13950.xyz;
    float3 _13952 = -_13951;
    float _13953 = Dot(_13948, _13952);
    float _13954 = _13953 * 0.5000;
    float _13955 = _13954 + 0.5000;
    *viewCoordinate = _13955;
    uint* _13956 = &material.textureBase;
    uint _13957 = *_13956;
    uint _13958 = _13957 + 4;
    uint _13959 = CopyObject(_13958) : [[NonUniform]];
    SampledImage<float, 2D>* _13960 = &textureArray[_13959] : [[NonUniform]];
    SampledImage<float, 2D> _13961 = *_13960 : [[NonUniform]];
    float _13962 = *viewCoordinate;
    float2 _13963 = CompositeConstruct({_13962, 0.5000});
    float4 _13964 = ImageSampleExplicitLod(_13961, _13963, Lod(0.0000));
    float _13965 = _13964.w;
    *eyeViewRampAlpha = _13965;
    float4 _13967 = *baseColor;
    *param@117 = _13967;
    float* _13969 = &eyeCoordinates.whiteMask;
    float _13970 = *_13969;
    *param@118 = _13970;
    float4* _13972 = &eyeProfile.highlight;
    float4 _13973 = *_13972;
    float3 _13974 = _13973.xyz;
    *param@119 = _13974;
    float4* _13976 = &eyeProfile.scattering;
    float4 _13977 = *_13976;
    float3 _13978 = _13977.xyz;
    *param@120 = _13978;
    float3 _13979 = characterEyeDiffuseMultiplier(param@117, param@118, param@119, param@120);
    *eyeDiffuseMultiplier = _13979;
    float* _13981 = &baseColor.w;
    float _13982 = *_13981;
    *param@121 = _13982;
    float* _13984 = &eyeProfile.shape.z;
    float _13985 = *_13984;
    *param@122 = _13985;
    float _13986 = characterEyeAlphaMultiplier(param@121, param@122);
    *eyeAlphaMultiplier = _13986;
    bool _13987 = *eyeNpr;
    
    if(_13987) {
      uint* _13991 = &material.materialPadding;
      uint _13992 = *_13991;
      uint _13993 = _13992 >> 1;
      float4 _13995 = *baseColor;
      *param@123 = _13995;
      float* _13997 = &eyeCoordinates.whiteMask;
      float _13998 = *_13997;
      *param@124 = _13998;
      float4* _14000 = &eyeProfile.highlight;
      float4 _14001 = *_14000;
      float3 _14002 = _14001.xyz;
      *param@125 = _14002;
      float4* _14004 = &eyeProfile.scattering;
      float4 _14005 = *_14004;
      float3 _14006 = _14005.xyz;
      *param@126 = _14006;
      float _14008 = *metallic;
      *param@127 = _14008;
      float* _14010 = &materialSurfaceProfiles.profiles[_13993].rows[6].x;
      float _14011 = *_14010;
      *param@128 = _14011;
      float4 _14013 = *classRampRgba;
      *param@129 = _14013;
      float _14015 = *eyeViewRampAlpha;
      *param@130 = _14015;
      float _14017 = *characterSceneVisibility;
      *param@131 = _14017;
      CharacterDiffuseResponse _14018 = characterEyeNprResponse(param@123, param@124, param@125, param@126, param@127, param@128, param@129, param@130, param@131);
      *eyeDiffuseResponse = _14018;
      float3* _14019 = &eyeDiffuseResponse.color;
      float3 _14020 = *_14019;
      *localCharacterDiffuse = _14020;
      *localCharacterResponseReady = true;
    }

  }

  float* _14022 = &camera.nprLightingParameters.x;
  float _14023 = *_14022;
  bool _14024 = _14023 > 0.5000;
  
  if(_14024) {
    *param@132 = 16777216;
    float _14028 = materialFeatureEnabled(param@132);
    bool _14029 = _14028 > 0.5000;
  }

  bool _14030 = Phi(_14024, _14029);
  
  if(_14030) {
    uint* _14033 = &material.materialPadding;
    uint _14034 = *_14033;
    uint _14035 = _14034 >> 1;
    float* _14036 = &materialSurfaceProfiles.profiles[_14035].rows[15].w;
    float _14037 = *_14036;
    bool _14038 = _14037 > 1.5000;
  }

  bool _14039 = Phi(_14030, _14038);
  *attenuateEmission = _14039;
  bool _14041 = *nprDiffuse;
  bool _14042 = *projectedLighting;
  bool _14043 = _14041 || _14042;
  bool _14044 = *eyeNpr;
  bool _14045 = _14043 || _14044;
  
  if(_14045) {
    float* _14048 = &camera.nprLightingParameters.x;
    float _14049 = *_14048;
    bool _14050 = _14049 > 0.5000;
  }

  bool _14051 = Phi(_14045, _14050);
  *characterLightComposition = _14051;
  bool _14053 = *sceneCharacter;
  bool _14054 = *nprDiffuse;
  bool _14055 = _14053 || _14054;
  uint _14056 = Select(_14055, 2, 1);
  *baseReceiverBit = _14056;
  uint _14058 = *baseReceiverBit;
  bool _14059 = _14058 == 2;
  
  if(_14059) {
    *_14060 = 1;
  } else {
    bool _14064 = *attenuateEmission;
    uint _14065 = Select(_14064, 2, 0);
    *_14060 = _14065;
  }

  uint _14066 = *_14060;
  *receiverRange = _14066;
  uint _14069 = *clusterIndex;
  *param@133 = _14069;
  uint _14071 = *receiverRange;
  *param@134 = _14071;
  uint2 _14072 = azureClusterLightRange(param@133, param@134);
  *lightRange = _14072;
  *characterBlend = {0.0000, 0.0000, 0.0000, 1.0000};
  float* _14076 = &camera.clusterGrid.w;
  float _14077 = *_14076;
  float _14078 = GLSL.std.450::FMax(_14077, 0.0000);
  uint _14079 = ConvertFToU(_14078);
  *sceneLightCount = _14079;
  *lightOffset = 0;

  while(true) {
    uint _14086 = *lightOffset;
    uint* _14087 = &lightRange.y;
    uint _14088 = *_14087;
    bool _14089 = _14086 < _14088;
    if(!_14089) break;
    uint* _14091 = &lightRange.x;
    uint _14092 = *_14091;
    uint _14093 = *lightOffset;
    uint _14094 = _14092 + _14093;
    uint* _14095 = &clusterIndexData.indices[_14094];
    uint _14096 = *_14095;
    *lightIndex = _14096;
    uint _14097 = *lightIndex;
    uint _14098 = *sceneLightCount;
    bool _14099 = _14097 >= _14098;
    
    if(_14099) {
      goto loop_continue1;
    }

    uint _14104 = *lightIndex;
    ClusterLight* _14105 = &sceneLightData.lights[_14104];
    ClusterLight _14106 = *_14105;
    float4 _14107 = _14106.positionRadius;
    float4* _14108 = &light.positionRadius;
    *_14108 = _14107;
    float4 _14109 = _14106.colorIntensity;
    float4* _14110 = &light.colorIntensity;
    *_14110 = _14109;
    float4 _14111 = _14106.directionOuter;
    float4* _14112 = &light.directionOuter;
    *_14112 = _14111;
    float4 _14113 = _14106.coneType;
    float4* _14114 = &light.coneType;
    *_14114 = _14113;
    float4[3] _14115 = _14106.boxRows;
    float4[3]* _14116 = &light.boxRows;
    float4 _14117 = _14115[0];
    float4* _14118 = &_14116[0];
    *_14118 = _14117;
    float4 _14119 = _14115[1];
    float4* _14120 = &_14116[1];
    *_14120 = _14119;
    float4 _14121 = _14115[2];
    float4* _14122 = &_14116[2];
    *_14122 = _14121;
    float4 _14123 = _14106.boxParameters;
    float4* _14124 = &light.boxParameters;
    *_14124 = _14123;
    float4 _14125 = _14106.characterResponse;
    float4* _14126 = &light.characterResponse;
    *_14126 = _14125;
    uint _14128 = *baseReceiverBit;
    *receiverBit = _14128;
    float* _14130 = &light.characterResponse.x;
    float _14131 = *_14130;
    bool _14132 = _14131 == 2.0000;
    bool _14133 = !_14132;
    
    if(_14133) {
      float* _14136 = &light.characterResponse.x;
      float _14137 = *_14136;
      bool _14138 = _14137 == 3.0000;
    }

    bool _14139 = Phi(_14132, _14138);
    *colorBlend = _14139;
    bool _14140 = *colorBlend;
    bool _14141 = *attenuateEmission;
    bool _14142 = _14140 && _14141;
    
    if(_14142) {
      *receiverBit = 2;
    }

    float* _14145 = &light.boxParameters.w;
    float _14146 = *_14145;
    uint _14147 = ConvertFToU(_14146);
    uint _14148 = *receiverBit;
    uint _14149 = _14147 & _14148;
    bool _14150 = _14149 == 0;
    
    if(_14150) {
      goto loop_continue1;
    }

    float* _14155 = &light.characterResponse.x;
    float _14156 = *_14155;
    bool _14157 = _14156 == 6.0000;
    *materialRim = _14157;
    float* _14159 = &light.characterResponse.x;
    float _14160 = *_14159;
    bool _14161 = _14160 == 4.0000;
    bool _14162 = *materialRim;
    bool _14163 = _14161 || _14162;
    *screenRim = _14163;
    float* _14165 = &light.characterResponse.x;
    float _14166 = *_14165;
    bool _14167 = _14166 == 5.0000;
    *specularOnly = _14167;
    bool _14168 = *colorBlend;
    
    if(_14168) {
      bool _14171 = *characterLightComposition;
      bool _14172 = *attenuateEmission;
      bool _14173 = _14171 || _14172;
      
      if(_14173) {
        float* _14177 = &light.characterResponse.x;
        float _14178 = *_14177;
        bool _14179 = _14178 == 3.0000;
        ClusterLight _14181 = *light;
        *param@135 = _14181;
        float3 _14183 = *worldPosition;
        *param@136 = _14183;
        *param@137 = _14179;
        SceneLightSample _14185 = sampleSceneLight(param@135, param@136, param@137);
        *blendSample = _14185;
        float* _14186 = &blendSample.attenuation;
        float _14187 = *_14186;
        bool _14188 = _14187 > 0.0001;
        
        if(_14188) {
          float3 _14192 = *geometricNormal;
          float3* _14193 = &blendSample.direction;
          float3 _14194 = *_14193;
          float _14195 = Dot(_14192, _14194);
          float* _14197 = &blendSample.attenuation;
          float _14198 = *_14197;
          *param@138 = _14198;
          *param@139 = _14195;
          float4* _14201 = &light.characterResponse;
          float4 _14202 = *_14201;
          float2 _14203 = _14202.yz;
          *param@140 = _14203;
          float _14204 = characterColorBlendWeight(param@138, param@139, param@140);
          *weight = _14204;
          bool _14205 = *attenuateEmission;
          bool _14206 = !_14205;
          
          if(_14206) {
            float4 _14209 = *characterBlend;
            float3 _14210 = _14209.xyz;
            float4* _14211 = &light.colorIntensity;
            float4 _14212 = *_14211;
            float3 _14213 = _14212.xyz;
            float* _14214 = &light.colorIntensity.w;
            float _14215 = *_14214;
            float3 _14216 = _14213 * _14215;
            float _14217 = *weight;
            float3 _14218 = CompositeConstruct({_14217, _14217, _14217});
            float3 _14219 = GLSL.std.450::FMix(_14210, _14216, _14218);
            float* _14220 = &characterBlend.x;
            float _14221 = _14219.x;
            *_14220 = _14221;
            float* _14222 = &characterBlend.y;
            float _14223 = _14219.y;
            *_14222 = _14223;
            float* _14224 = &characterBlend.z;
            float _14225 = _14219.z;
            *_14224 = _14225;
          }

          float _14226 = *weight;
          float _14227 = 1.0000 - _14226;
          float* _14228 = &characterBlend.w;
          float _14229 = *_14228;
          float _14230 = _14229 * _14227;
          float* _14231 = &characterBlend.w;
          *_14231 = _14230;
        }

      }

      goto loop_continue1;
    }

    
    if(azureOrdinaryOpaque) {
      *_14234 = 0;
    } else {
      int* _14238 = &material.alphaMode;
      int _14239 = *_14238;
      *_14234 = _14239;
    }

    int _14240 = *_14234;
    bool _14241 = _14240 == 2;
    bool _14242 = *projectedLighting;
    bool _14243 = _14241 && _14242;
    
    if(_14243) {
      uint _14246 = *projectedHairFlags;
      uint _14247 = _14246 & 3;
      bool _14248 = _14247 == 2;
    }

    bool _14249 = Phi(_14243, _14248);
    *transparentHairHighlights = _14249;
    bool _14251 = *nprDiffuse;
    
    if(_14251) {
      uint* _14254 = &material.materialPadding;
      uint _14255 = *_14254;
      uint _14256 = _14255 >> 1;
      float* _14257 = &materialSurfaceProfiles.profiles[_14256].rows[3].w;
      float _14258 = *_14257;
      bool _14259 = _14258 > 0.5000;
    }

    bool _14260 = Phi(_14251, _14259);
    *transparentNprHighlights = _14260;
    bool _14261 = *screenRim;
    bool _14262 = *specularOnly;
    bool _14263 = _14261 || _14262;
    
    if(_14263) {
      bool _14266 = *characterLightComposition;
      bool _14267 = !_14266;
      bool _14268 = !_14267;
      
      if(_14268) {
        
        if(azureOrdinaryOpaque) {
          *_14271 = 0;
        } else {
          int* _14275 = &material.alphaMode;
          int _14276 = *_14275;
          *_14271 = _14276;
        }

        int _14277 = *_14271;
        bool _14278 = _14277 == 2;
        bool _14279 = *transparentHairHighlights;
        bool _14280 = !_14279;
        bool _14281 = _14278 && _14280;
        bool _14282 = *transparentNprHighlights;
        bool _14283 = !_14282;
        bool _14284 = _14281 && _14283;
      }

      bool _14285 = Phi(_14267, _14284);
    }

    bool _14286 = Phi(_14263, _14285);
    
    if(_14286) {
      goto loop_continue1;
    }

    ClusterLight _14292 = *light;
    *param@141 = _14292;
    float3 _14294 = *worldPosition;
    *param@142 = _14294;
    *param@143 = false;
    SceneLightSample _14296 = sampleSceneLight(param@141, param@142, param@143);
    *sampled = _14296;
    bool _14297 = *sceneCharacter;
    bool _14298 = !_14297;
    bool _14299 = *characterLightComposition;
    bool _14300 = !_14299;
    bool _14301 = _14298 && _14300;
    
    if(_14301) {
      float* _14304 = &sampled.attenuation;
      float _14305 = *_14304;
      bool _14306 = _14305 == 0.0000;
    }

    bool _14307 = Phi(_14301, _14306);
    
    if(_14307) {
      goto loop_continue1;
    }

    float3* _14312 = &sampled.incoming;
    float3 _14313 = *_14312;
    *toLight = _14313;
    float3* _14315 = &sampled.direction;
    float3 _14316 = *_14315;
    *pointDirection = _14316;
    float* _14318 = &sampled.distanceSquared;
    float _14319 = *_14318;
    *distanceSquared = _14319;
    float* _14321 = &sampled.attenuation;
    float _14322 = *_14321;
    *attenuation = _14322;
    bool _14324 = *dualFaceSdf;
    
    if(_14324) {
      float* _14327 = &light.coneType.y;
      float _14328 = *_14327;
      bool _14329 = _14328 <= 1.5000;
    }

    bool _14330 = Phi(_14324, _14329);
    float3 _14331 = *faceLightingNormal;
    float3 _14332 = *shadedNormal;
    bool _14333 = CompositeConstruct({_14330, _14330, _14330});
    float3 _14334 = Select(_14333, _14331, _14332);
    *localLightingNormal = _14334;
    float3 _14336 = *localLightingNormal;
    float3 _14337 = *pointDirection;
    float _14338 = Dot(_14336, _14337);
    float _14339 = GLSL.std.450::FMax(_14338, 0.0000);
    *pointDiffuse = _14339;
    float4* _14341 = &light.colorIntensity;
    float4 _14342 = *_14341;
    float3 _14343 = _14342.xyz;
    float* _14344 = &light.colorIntensity.w;
    float _14345 = *_14344;
    float3 _14346 = _14343 * _14345;
    float _14347 = *attenuation;
    float3 _14348 = _14346 * _14347;
    *radiance = _14348;
    float* _14349 = &light.coneType.y;
    float _14350 = *_14349;
    bool _14351 = _14350 > 1.5000;
    
    if(_14351) {
      float* _14354 = &light.directionOuter.w;
      float _14355 = *_14354;
      bool _14356 = _14355 > 0.5000;
    }

    bool _14357 = Phi(_14351, _14356);
    
    if(_14357) {
      float _14360 = *shadowVisibility;
      float3 _14361 = *radiance;
      float3 _14362 = _14361 * _14360;
      *radiance = _14362;
    }

    bool _14363 = *screenRim;
    
    if(_14363) {
      bool _14367 = *materialRim;
      
      if(_14367) {
        bool _14370 = *transparentHairHighlights;
        bool _14371 = !_14370;
        
        if(_14371) {
          bool _14374 = *nprDiffuse;
          
          if(_14374) {
            uint* _14377 = &material.materialPadding;
            uint _14378 = *_14377;
            uint _14379 = _14378 >> 1;
            float* _14380 = &materialSurfaceProfiles.profiles[_14379].rows[1].x;
            float _14381 = *_14380;
            bool _14382 = _14381 > 0.5000;
          }

          bool _14383 = Phi(_14374, _14382);
        }

        bool _14384 = Phi(_14370, _14383);
      }

      bool _14385 = Phi(_14367, _14384);
      *facingRim = _14385;
      float3 _14387 = *worldPosition;
      float4* _14388 = &instanceFaceFrame[3];
      float4 _14389 = *_14388;
      float3 _14390 = _14389.xyz;
      float3 _14391 = _14387 - _14390;
      *radial = _14391;
      float* _14392 = &radial.y;
      *_14392 = 0.0001;
      float3 _14393 = *radial;
      float3 _14394 = GLSL.std.450::Normalize(_14393);
      *radial = _14394;
      bool _14395 = *facingRim;
      
      if(_14395) {
        int _14398 = *qaEffectMode;
        bool _14399 = _14398 == 4;
        bool _14400 = *qaEffectDisabled;
        bool _14401 = _14399 && _14400;
        bool _14402 = !_14401;
        float _14403 = *attenuation;
        bool _14404 = _14403 > 0.0001;
        bool _14405 = _14402 && _14404;
        
        if(_14405) {
          float3 _14408 = *radiance;
          bool _14409 = *transparentHairHighlights;
          
          if(_14409) {
            float4 _14413 = *baseColor;
            float3 _14414 = _14413.xyz;
            *_14410 = _14414;
          } else {
            float4 _14417 = *baseColor;
            float3 _14418 = _14417.xyz;
            *param@144 = _14418;
            float3 _14420 = *shadedNormal;
            *param@145 = _14420;
            float3 _14422 = *viewDirection;
            *param@146 = _14422;
            float3 _14423 = materialNprLitAlbedo(param@144, param@145, param@146);
            *_14410 = _14423;
          }

          float3 _14425 = *_14410;
          *param@147 = _14425;
          float* _14427 = &light.characterResponse.z;
          float _14428 = *_14427;
          *param@148 = _14428;
          float* _14430 = &light.characterResponse.y;
          float _14431 = *_14430;
          *param@149 = _14431;
          float3 _14433 = *shadedNormal;
          *param@150 = _14433;
          float3 _14435 = *viewDirection;
          *param@151 = _14435;
          float3 _14437 = *pointDirection;
          *param@152 = _14437;
          float4* _14439 = &camera.cameraForward;
          float4 _14440 = *_14439;
          float3 _14441 = _14440.xyz;
          *param@153 = _14441;
          float3 _14443 = *radial;
          *param@154 = _14443;
          float3 _14444 = characterFacingRimResponse(param@147, param@148, param@149, param@150, param@151, param@152, param@153, param@154);
          float3 _14445 = _14408 * _14444;
          float3 _14446 = *sceneRim;
          float3 _14447 = _14446 + _14445;
          *sceneRim = _14447;
        }

      } else {
        int _14449 = *qaEffectMode;
        bool _14450 = _14449 == 4;
        bool _14451 = *qaEffectDisabled;
        bool _14452 = _14450 && _14451;
        bool _14453 = !_14452;
        float _14454 = *attenuation;
        bool _14455 = _14454 > 0.0001;
        bool _14456 = _14453 && _14455;
        
        if(_14456) {
          float3 _14460 = *shadedNormal;
          float4* _14461 = &camera.cameraRight;
          float4 _14462 = *_14461;
          float3 _14463 = _14462.xyz;
          float _14464 = Dot(_14460, _14463);
          float3 _14465 = *shadedNormal;
          float4* _14466 = &camera.cameraUp;
          float4 _14467 = *_14466;
          float3 _14468 = _14467.xyz;
          float _14469 = Dot(_14465, _14468);
          float _14470 = -_14469;
          float2 _14471 = CompositeConstruct({_14464, _14470});
          *screenNormal = _14471;
          float2 _14473 = *screenNormal;
          float2 _14474 = *screenNormal;
          float _14475 = Dot(_14473, _14474);
          *normalSquared = _14475;
          float _14476 = *normalSquared;
          bool _14477 = _14476 > 0.0000;
          
          if(_14477) {
            float2 _14481 = *screenNormal;
            float _14482 = *normalSquared;
            float _14483 = GLSL.std.450::InverseSqrt(_14482);
            float2 _14484 = _14481 * _14483;
            *_14478 = _14484;
          } else {
            *_14478 = {0.0000, 0.0000};
          }

          float2 _14486 = *_14478;
          *screenNormal = _14486;
          SampledImage<float, 2D> _14488 = *overlaySceneDepth;
          Image<float, 2D> _14489 = Image(_14488);
          int2 _14490 = ImageQuerySizeLod(_14489, 0);
          float2 _14491 = ConvertSToF(_14490);
          *extent@2 = _14491;
          float2 _14493 = *screenNormal;
          float* _14494 = &extent@2.y;
          float _14495 = *_14494;
          float* _14496 = &extent@2.x;
          float _14497 = *_14496;
          float _14498 = _14495 / _14497;
          float2 _14499 = CompositeConstruct({_14498, 1.0000});
          float2 _14500 = _14493 * _14499;
          float* _14502 = &light.characterResponse.y;
          float _14503 = *_14502;
          float _14504 = 0.0060 * _14503;
          float2 _14505 = _14500 * _14504;
          *offset@2 = _14505;
          float2 _14507 = *extent@2;
          float2 _14508 = CompositeConstruct({0.5000, 0.5000});
          float2 _14509 = _14508 / _14507;
          *halfPixel = _14509;
          float4 _14511 = *gl_FragCoord;
          float2 _14512 = _14511.xy;
          float2 _14513 = *extent@2;
          float2 _14514 = _14512 / _14513;
          float2 _14515 = *offset@2;
          float2 _14516 = _14514 + _14515;
          float2 _14517 = *halfPixel;
          float2 _14518 = *halfPixel;
          float2 _14519 = CompositeConstruct({1.0000, 1.0000});
          float2 _14520 = _14519 - _14518;
          float2 _14521 = GLSL.std.450::FClamp(_14516, _14517, _14520);
          *depthUv = _14521;
          SampledImage<float, 2D> _14523 = *overlaySceneDepth;
          float2 _14524 = *depthUv;
          float4 _14525 = ImageSampleExplicitLod(_14523, _14524, Lod(0.0000));
          float _14526 = _14525.x;
          *sceneDepth = _14526;
          float3 _14528 = *worldPosition;
          float4* _14529 = &camera.cameraPosition;
          float4 _14530 = *_14529;
          float3 _14531 = _14530.xyz;
          float3 _14532 = _14528 - _14531;
          float4* _14533 = &camera.cameraForward;
          float4 _14534 = *_14533;
          float3 _14535 = _14534.xyz;
          float _14536 = Dot(_14532, _14535);
          *surfaceDepth = _14536;
          float3 _14537 = *radiance;
          float4 _14539 = *baseColor;
          float3 _14540 = _14539.xyz;
          *param@155 = _14540;
          float* _14542 = &light.characterResponse.z;
          float _14543 = *_14542;
          *param@156 = _14543;
          float3 _14545 = *shadedNormal;
          *param@157 = _14545;
          float3 _14547 = *pointDirection;
          *param@158 = _14547;
          float4* _14549 = &camera.cameraForward;
          float4 _14550 = *_14549;
          float3 _14551 = _14550.xyz;
          *param@159 = _14551;
          float3 _14553 = *radial;
          *param@160 = _14553;
          float _14555 = *sceneDepth;
          *param@161 = _14555;
          float _14557 = *surfaceDepth;
          *param@162 = _14557;
          float3 _14558 = characterScreenRimResponse(param@155, param@156, param@157, param@158, param@159, param@160, param@161, param@162);
          float3 _14559 = _14537 * _14558;
          float3 _14560 = *sceneRim;
          float3 _14561 = _14560 + _14559;
          *sceneRim = _14561;
        }

      }

      goto loop_continue1;
    }

    float* _14564 = &light.characterResponse.x;
    float _14565 = *_14564;
    bool _14566 = _14565 == 1.0000;
    
    if(_14566) {
      bool _14569 = *sceneCharacter;
      bool _14570 = *nprDiffuse;
      bool _14571 = _14569 || _14570;
    }

    bool _14572 = Phi(_14566, _14571);
    *characterLight = _14572;
    bool _14573 = *characterLight;
    
    if(_14573) {
      float* _14576 = &light.characterResponse.w;
      float _14577 = *_14576;
      bool _14578 = _14577 > 0.0000;
    }

    bool _14579 = Phi(_14573, _14578);
    
    if(_14579) {
      float3 _14585 = *toLight;
      *param@163 = _14585;
      float4* _14587 = &light.directionOuter;
      float4 _14588 = *_14587;
      float3 _14589 = _14588.xyz;
      *param@164 = _14589;
      float* _14591 = &light.characterResponse.w;
      float _14592 = *_14591;
      *param@165 = _14592;
      LineLightGeometry _14593 = lineLightGeometry(param@163, param@164, param@165);
      *line = _14593;
      float* _14594 = &line.factor;
      float _14595 = *_14594;
      float* _14596 = &light.coneType.z;
      float _14597 = *_14596;
      bool _14598 = _14597 < 1.5000;
      
      if(_14598) {
        float _14602 = *distanceSquared;
        float _14603 = _14602 + 1.0000;
        *_14599 = _14603;
      } else {
        *_14599 = 1.0000;
      }

      float _14605 = *_14599;
      float _14606 = _14595 * _14605;
      float3 _14607 = *radiance;
      float3 _14608 = _14607 * _14606;
      *radiance = _14608;
      float3* _14609 = &line.direction;
      float3 _14610 = *_14609;
      *pointDirection = _14610;
      float3 _14611 = *localLightingNormal;
      float3 _14612 = *pointDirection;
      float _14613 = Dot(_14611, _14612);
      float _14614 = GLSL.std.450::FMax(_14613, 0.0000);
      *pointDiffuse = _14614;
    }

    float4* _14616 = &light.characterResponse;
    float4 _14617 = *_14616;
    float2 _14618 = _14617.yz;
    *localResponse = _14618;
    bool _14619 = *nprDiffuse;
    
    if(_14619) {
      uint* _14622 = &material.materialPadding;
      uint _14623 = *_14622;
      uint _14624 = _14623 >> 1;
      float* _14625 = &materialSurfaceProfiles.profiles[_14624].rows[3].y;
      float _14626 = *_14625;
      float* _14627 = &localResponse.x;
      float _14628 = *_14627;
      float _14629 = _14628 * _14626;
      float* _14630 = &localResponse.x;
      *_14630 = _14629;
    }

    float3 _14632 = *localLightingNormal;
    *wrapNormal = _14632;
    bool _14634 = *characterLight;
    
    if(_14634) {
      float3 _14638 = *wrapNormal;
      float3 _14639 = *pointDirection;
      float _14640 = Dot(_14638, _14639);
      float3 _14642 = *radiance;
      *param@166 = _14642;
      *param@167 = _14640;
      float2 _14645 = *localResponse;
      *param@168 = _14645;
      float _14647 = *characterSceneVisibility;
      *param@169 = _14647;
      float3 _14648 = characterLocalLightRadiance(param@166, param@167, param@168, param@169);
      *_14635 = _14648;
    } else {
      float3 _14650 = *radiance;
      *_14635 = _14650;
    }

    float3 _14651 = *_14635;
    *characterRadiance = _14651;
    bool _14652 = *specularOnly;
    bool _14653 = !_14652;
    
    if(_14653) {
      bool _14656 = *eyeRadial;
      bool _14657 = *eyeNpr;
      bool _14658 = !_14657;
      bool _14659 = _14656 && _14658;
      
      if(_14659) {
        float* _14662 = &camera.clusterLighting.x;
        float _14663 = *_14662;
        bool _14664 = _14663 > 0.5000;
      }

      bool _14665 = Phi(_14659, _14664);
      
      if(_14665) {
        uint* _14669 = &material.textureBase;
        uint _14670 = *_14669;
        uint _14671 = _14670 + 4;
        uint _14672 = CopyObject(_14671) : [[NonUniform]];
        SampledImage<float, 2D>* _14673 = &textureArray[_14672] : [[NonUniform]];
        SampledImage<float, 2D> _14674 = *_14673 : [[NonUniform]];
        float3 _14675 = *shadedNormal;
        float3 _14676 = *pointDirection;
        float _14677 = Dot(_14675, _14676);
        float _14678 = _14677 * 0.5000;
        float _14679 = _14678 + 0.5000;
        float2 _14680 = CompositeConstruct({_14679, 0.5000});
        float4 _14681 = ImageSampleExplicitLod(_14674, _14680, Lod(0.0000));
        *ramp = _14681;
        float3 _14683 = *radiance;
        float _14684 = *pointDiffuse;
        float3 _14685 = _14683 * _14684;
        *illumination = _14685;
        float4 _14686 = *baseColor;
        float3 _14687 = _14686.xyz;
        float3 _14688 = *eyeDiffuseMultiplier;
        float3 _14689 = _14687 * _14688;
        float4 _14690 = *ramp;
        float3 _14691 = _14690.xyz;
        float3 _14692 = _14689 * _14691;
        float3 _14693 = *illumination;
        float3 _14694 = _14692 * _14693;
        float _14695 = *eyeAlphaMultiplier;
        float3 _14696 = _14694 * _14695;
        float3 _14697 = *eyeHostDiffuse;
        float3 _14698 = _14697 + _14696;
        *eyeHostDiffuse = _14698;
        float* _14700 = &light.coneType.y;
        float _14701 = *_14700;
        bool _14702 = _14701 > 1.5000;
        
        if(_14702) {
          float* _14705 = &light.directionOuter.w;
          float _14706 = *_14705;
          bool _14707 = _14706 > 0.5000;
        }

        bool _14708 = Phi(_14702, _14707);
        
        if(_14708) {
          float _14712 = *shadowVisibility;
          float _14713 = 1.0000 - _14712;
          *_14709 = _14713;
        } else {
          *_14709 = 0.0000;
        }

        float _14715 = *_14709;
        *selection = _14715;
        float4 _14717 = *eyeMatcap;
        *param@170 = _14717;
        float4* _14719 = &eyeProfile.matcap;
        float4 _14720 = *_14719;
        *param@171 = _14720;
        float _14722 = *eyeViewRampAlpha;
        *param@172 = _14722;
        float* _14724 = &ramp.w;
        float _14725 = *_14724;
        *param@173 = _14725;
        float _14727 = *selection;
        *param@174 = _14727;
        float* _14729 = &eyeProfile.shape.w;
        float _14730 = *_14729;
        *param@175 = _14730;
        float3 _14732 = *illumination;
        *param@176 = _14732;
        float3 _14733 = characterEyeMatcap(param@170, param@171, param@172, param@173, param@174, param@175, param@176);
        float3 _14734 = *eyeHostMatcap;
        float3 _14735 = _14734 + _14733;
        *eyeHostMatcap = _14735;
      }

      float _14737 = *pointDiffuse;
      float3 _14738 = CompositeConstruct({_14737, _14737, _14737});
      *localDiffuseResponse = _14738;
      bool _14739 = *dualFaceSdf;
      
      if(_14739) {
        float3 _14745 = *pointDirection;
        *param@177 = _14745;
        float3 _14747 = *localLightingNormal;
        *param@178 = _14747;
        float _14749 = dualFaceRampCoordinate(param@177, param@178, param@179);
        float4 _14750 = *param@179;
        *localDistanceSample = _14750;
        *localCoordinate = _14749;
        uint* _14751 = &material.textureBase;
        uint _14752 = *_14751;
        uint _14753 = _14752 + 5;
        uint _14754 = CopyObject(_14753) : [[NonUniform]];
        SampledImage<float, 2D>* _14755 = &textureArray[_14754] : [[NonUniform]];
        SampledImage<float, 2D> _14756 = *_14755 : [[NonUniform]];
        float _14757 = *localCoordinate;
        float2 _14758 = CompositeConstruct({_14757, 0.5000});
        float4 _14759 = ImageSampleExplicitLod(_14756, _14758, Lod(0.0000));
        float3 _14760 = _14759.xyz;
        *localDiffuseResponse = _14760;
      } else {
        bool _14762 = *sceneCharacter;
        
        if(_14762) {
          *param@180 = 8192;
          float _14767 = materialFeatureEnabled(param@180);
          bool _14768 = _14767 > 0.5000;
          
          if(_14768) {
            float3 _14772 = *shadedNormal;
            float3 _14773 = *pointDirection;
            float _14774 = Dot(_14772, _14773);
            float _14775 = _14774 * 0.5000;
            float _14776 = _14775 + 0.5000;
            *_14769 = _14776;
          } else {
            float _14778 = *pointDiffuse;
            *_14769 = _14778;
          }

          float _14779 = *_14769;
          *coordinate = _14779;
          float _14780 = *pointDiffuse;
          float3 _14781 = CompositeConstruct({_14780, _14780, _14780});
          float _14783 = *coordinate;
          *param@181 = _14783;
          float3 _14784 = materialDiffuseRamp(param@181);
          float _14785 = *toonWeight;
          float3 _14786 = CompositeConstruct({_14785, _14785, _14785});
          float3 _14787 = GLSL.std.450::FMix(_14781, _14784, _14786);
          *localDiffuseResponse = _14787;
        }

      }

      bool _14788 = *characterLight;
      
      if(_14788) {
        bool _14791 = *localCharacterResponseReady;
        bool _14792 = !_14791;
        
        if(_14792) {
          bool _14795 = *nprDiffuse;
          
          if(_14795) {
            float4 _14799 = *baseColor;
            *param@182 = _14799;
            float _14801 = *metallic;
            *param@183 = _14801;
            float4 _14803 = *classRampRgba;
            *param@184 = _14803;
            float _14805 = *nprBaseAo;
            *param@185 = _14805;
            float _14807 = *characterSceneVisibility;
            *param@186 = _14807;
            float _14809 = *nprMainShadowVisibility;
            *param@187 = _14809;
            float3 _14811 = *shadedNormal;
            *param@188 = _14811;
            float3 _14813 = *viewDirection;
            *param@189 = _14813;
            float3 _14814 = materialNprDiffuse(param@182, param@183, param@184, param@185, param@186, param@187, param@188, param@189);
            *localCharacterDiffuse = _14814;
          }

          *localCharacterResponseReady = true;
        }

        float3 _14815 = *localCharacterDiffuse;
        float3 _14816 = *characterRadiance;
        float3 _14817 = _14815 * _14816;
        float3 _14818 = *clusteredDiffuse;
        float3 _14819 = _14818 + _14817;
        *clusteredDiffuse = _14819;
      } else {
        bool _14821 = *eyeNpr;
        
        if(_14821) {
          uint _14825 = *lightIndex;
          float _14826 = ConvertUToF(_14825);
          float* _14827 = &camera.nprLightingParameters.y;
          float _14828 = *_14827;
          bool _14829 = _14826 == _14828;
          *composedMain = _14829;
          bool _14830 = *composedMain;
          bool _14831 = !_14830;
          
          if(_14831) {
            uint* _14835 = &material.textureBase;
            uint _14836 = *_14835;
            uint _14837 = _14836 + 4;
            uint _14838 = CopyObject(_14837) : [[NonUniform]];
            SampledImage<float, 2D>* _14839 = &textureArray[_14838] : [[NonUniform]];
            SampledImage<float, 2D> _14840 = *_14839 : [[NonUniform]];
            float3 _14841 = *shadedNormal;
            float3 _14842 = *pointDirection;
            float _14843 = Dot(_14841, _14842);
            float _14844 = _14843 * 0.5000;
            float _14845 = _14844 + 0.5000;
            float2 _14846 = CompositeConstruct({_14845, 0.5000});
            float4 _14847 = ImageSampleExplicitLod(_14840, _14846, Lod(0.0000));
            *ramp@2 = _14847;
            uint* _14849 = &material.materialPadding;
            uint _14850 = *_14849;
            uint _14851 = _14850 >> 1;
            float* _14852 = &light.coneType.y;
            float _14853 = *_14852;
            bool _14854 = _14853 > 1.5000;
            
            if(_14854) {
              float* _14857 = &light.directionOuter.w;
              float _14858 = *_14857;
              bool _14859 = _14858 > 0.5000;
            }

            bool _14860 = Phi(_14854, _14859);
            float _14861 = *shadowVisibility;
            float _14862 = Select(_14860, _14861, 1.0000);
            float4 _14864 = *baseColor;
            *param@190 = _14864;
            float* _14866 = &eyeCoordinates.whiteMask;
            float _14867 = *_14866;
            *param@191 = _14867;
            float4* _14869 = &eyeProfile.highlight;
            float4 _14870 = *_14869;
            float3 _14871 = _14870.xyz;
            *param@192 = _14871;
            float4* _14873 = &eyeProfile.scattering;
            float4 _14874 = *_14873;
            float3 _14875 = _14874.xyz;
            *param@193 = _14875;
            float _14877 = *metallic;
            *param@194 = _14877;
            float* _14879 = &materialSurfaceProfiles.profiles[_14851].rows[6].x;
            float _14880 = *_14879;
            *param@195 = _14880;
            float4 _14882 = *ramp@2;
            *param@196 = _14882;
            float _14884 = *eyeViewRampAlpha;
            *param@197 = _14884;
            *param@198 = _14862;
            CharacterDiffuseResponse _14886 = characterEyeNprResponse(param@190, param@191, param@192, param@193, param@194, param@195, param@196, param@197, param@198);
            *response = _14886;
            float3* _14887 = &response.color;
            float3 _14888 = *_14887;
            float3 _14889 = *radiance;
            float3 _14890 = _14888 * _14889;
            float* _14891 = &light.coneType.y;
            float _14892 = *_14891;
            bool _14893 = _14892 > 1.5000;
            float _14894 = *pointDiffuse;
            float _14895 = Select(_14893, 1.0000, _14894);
            float3 _14896 = _14890 * _14895;
            float3 _14897 = *clusteredDiffuse;
            float3 _14898 = _14897 + _14896;
            *clusteredDiffuse = _14898;
          }

        } else {
          bool _14900 = *nprDiffuse;
          
          if(_14900) {
            float3 _14904 = *shadedNormal;
            float3 _14905 = *pointDirection;
            float _14906 = Dot(_14904, _14905);
            float _14907 = _14906 * 0.5000;
            float _14908 = _14907 + 0.5000;
            *localCoordinate@2 = _14908;
            bool _14909 = *dualFaceSdf;
            
            if(_14909) {
              float3 _14914 = *pointDirection;
              *param@199 = _14914;
              float3 _14916 = *localLightingNormal;
              *param@200 = _14916;
              float _14918 = dualFaceRampCoordinate(param@199, param@200, param@201);
              float4 _14919 = *param@201;
              *distanceValue = _14919;
              *localCoordinate@2 = _14918;
              uint* _14921 = &material.textureBase;
              uint _14922 = *_14921;
              uint _14923 = _14922 + 5;
              uint _14924 = CopyObject(_14923) : [[NonUniform]];
              SampledImage<float, 2D>* _14925 = &textureArray[_14924] : [[NonUniform]];
              SampledImage<float, 2D> _14926 = *_14925 : [[NonUniform]];
              float _14927 = *localCoordinate@2;
              float2 _14928 = CompositeConstruct({_14927, 0.5000});
              float4 _14929 = ImageSampleExplicitLod(_14926, _14928, Lod(0.0000));
              *localRamp = _14929;
            } else {
              float _14932 = *localCoordinate@2;
              *param@202 = _14932;
              float4 _14933 = materialDiffuseRampRgba(param@202);
              *localRamp = _14933;
            }

            float* _14935 = &light.coneType.y;
            float _14936 = *_14935;
            bool _14937 = _14936 > 1.5000;
            
            if(_14937) {
              float* _14940 = &light.directionOuter.w;
              float _14941 = *_14940;
              bool _14942 = _14941 > 0.5000;
            }

            bool _14943 = Phi(_14937, _14942);
            float _14944 = *shadowVisibility;
            float _14945 = Select(_14943, _14944, 1.0000);
            *visibility = _14945;
            float* _14947 = &light.coneType.y;
            float _14948 = *_14947;
            bool _14949 = _14948 > 1.5000;
            
            if(_14949) {
              float4 _14954 = *baseColor;
              *param@203 = _14954;
              float _14956 = *metallic;
              *param@204 = _14956;
              float4 _14958 = *localRamp;
              *param@205 = _14958;
              float _14960 = *nprBaseAo;
              *param@206 = _14960;
              float _14962 = *visibility;
              *param@207 = _14962;
              float _14964 = *nprMainShadowVisibility;
              *param@208 = _14964;
              float3 _14966 = *shadedNormal;
              *param@209 = _14966;
              float3 _14968 = *viewDirection;
              *param@210 = _14968;
              float3 _14969 = materialNprDiffuse(param@203, param@204, param@205, param@206, param@207, param@208, param@209, param@210);
              *_14950 = _14969;
            } else {
              float3 _14971 = *nprAmbientResponse;
              float _14972 = *pointDiffuse;
              float3 _14973 = _14971 * _14972;
              *_14950 = _14973;
            }

            float3 _14974 = *_14950;
            *response@2 = _14974;
            float* _14976 = &camera.nprLightingParameters.x;
            float _14977 = *_14976;
            bool _14978 = _14977 > 0.5000;
            
            if(_14978) {
              uint _14981 = *lightIndex;
              float _14982 = ConvertUToF(_14981);
              float* _14983 = &camera.nprLightingParameters.y;
              float _14984 = *_14983;
              bool _14985 = _14982 == _14984;
            }

            bool _14986 = Phi(_14978, _14985);
            *composedMain@2 = _14986;
            bool _14987 = *composedMain@2;
            bool _14988 = !_14987;
            
            if(_14988) {
              float3 _14991 = *response@2;
              float3 _14992 = *radiance;
              float3 _14993 = _14991 * _14992;
              float3 _14994 = *clusteredDiffuse;
              float3 _14995 = _14994 + _14993;
              *clusteredDiffuse = _14995;
            }

          } else {
            float3 _14998 = *diffuseColor;
            float3 _14999 = *radiance;
            float3 _15000 = _14998 * _14999;
            float3 _15001 = *localDiffuseResponse;
            float3 _15002 = _15000 * _15001;
            float _15003 = *diffuseScale;
            float3 _15004 = _15002 * _15003;
            *contribution = _15004;
            float3 _15005 = *contribution;
            float3 _15006 = *clusteredDiffuse;
            float3 _15007 = _15006 + _15005;
            *clusteredDiffuse = _15007;
            uint _15008 = *lightIndex;
            float _15009 = ConvertUToF(_15008);
            float* _15010 = &camera.nprLightingParameters.y;
            float _15011 = *_15010;
            bool _15012 = _15009 == _15011;
            
            if(_15012) {
              float3 _15015 = *contribution;
              *sceneMainDiffuse = _15015;
            }

          }

        }

      }

    }

    float3 _15017 = *pointDirection;
    float3 _15018 = *viewDirection;
    float3 _15019 = _15017 + _15018;
    float3 _15020 = GLSL.std.450::Normalize(_15019);
    *pointHalfDirection = _15020;
    float3 _15022 = *shadedNormal;
    float3 _15023 = *pointHalfDirection;
    float _15024 = Dot(_15022, _15023);
    float _15025 = GLSL.std.450::FMax(_15024, 0.0000);
    float _15026 = *specularPower;
    float _15027 = GLSL.std.450::Pow(_15025, _15026);
    *pointSpecular = _15027;
    bool _15029 = *microfacetSurface;
    
    if(_15029) {
      float3 _15033 = *shadedNormal;
      float3 _15034 = *pointHalfDirection;
      float _15035 = Dot(_15033, _15034);
      float _15036 = GLSL.std.450::FMax(_15035, 0.0000);
      float3 _15037 = *viewDirection;
      float3 _15038 = *pointHalfDirection;
      float _15039 = Dot(_15037, _15038);
      float _15040 = GLSL.std.450::FMax(_15039, 0.0000);
      float3 _15042 = *f0;
      *param@211 = _15042;
      float _15044 = *roughness;
      *param@212 = _15044;
      float _15046 = *pointDiffuse;
      *param@213 = _15046;
      float _15048 = *normalDotView;
      *param@214 = _15048;
      *param@215 = _15036;
      *param@216 = _15040;
      float3 _15051 = directSurfaceSpecular(param@211, param@212, param@213, param@214, param@215, param@216);
      *_15030 = _15051;
    } else {
      float3 _15053 = *f0;
      float _15054 = *pointSpecular;
      float3 _15055 = _15053 * _15054;
      float _15056 = *pointDiffuse;
      float3 _15057 = _15055 * _15056;
      float _15058 = *roughness;
      float _15059 = GLSL.std.450::FMix(0.7000, 0.1200, _15058);
      float3 _15060 = _15057 * _15059;
      *_15030 = _15060;
    }

    float3 _15061 = *_15030;
    *pointResponse = _15061;
    bool _15063 = *specularRamp;
    
    if(_15063) {
      float* _15066 = &camera.nprLightingParameters.x;
      float _15067 = *_15066;
      bool _15068 = _15067 > 0.5000;
    }

    bool _15069 = Phi(_15063, _15068);
    
    if(_15069) {
      uint _15072 = *lightIndex;
      float _15073 = ConvertUToF(_15072);
      float* _15074 = &camera.nprLightingParameters.y;
      float _15075 = *_15074;
      bool _15076 = _15073 == _15075;
    }

    bool _15077 = Phi(_15069, _15076);
    *composedRamp = _15077;
    bool _15078 = *composedRamp;
    bool _15079 = !_15078;
    
    if(_15079) {
      float3 _15082 = *pointResponse;
      float3 _15083 = *radiance;
      float3 _15084 = _15082 * _15083;
      float* _15085 = &light.boxParameters.z;
      float _15086 = *_15085;
      float3 _15087 = _15084 * _15086;
      float3 _15088 = *clusteredSpecular;
      float3 _15089 = _15088 + _15087;
      *clusteredSpecular = _15089;
    }

    bool _15090 = *sceneCharacter;
    float _15091 = *hairActive;
    bool _15092 = _15091 > 0.0000;
    bool _15093 = _15090 && _15092;
    
    if(_15093) {
      int _15096 = *qaEffectMode;
      bool _15097 = _15096 == 3;
      bool _15098 = *qaEffectDisabled;
      bool _15099 = _15097 && _15098;
      bool _15100 = !_15099;
    }

    bool _15101 = Phi(_15093, _15100);
    
    if(_15101) {
      bool _15105 = *characterLight;
      bool _15106 = *specularOnly;
      bool _15107 = _15105 || _15106;
      
      if(_15107) {
        float3 _15111 = *characterRadiance;
        float _15112 = *pointDiffuse;
        float3 _15113 = _15111 * _15112;
        float* _15114 = &light.boxParameters.z;
        float _15115 = *_15114;
        float3 _15116 = _15113 * _15115;
        *_15108 = _15116;
      } else {
        float3 _15118 = *radiance;
        *_15108 = _15118;
      }

      float3 _15119 = *_15108;
      *hairRadiance = _15119;
      bool _15120 = *projectedHair;
      
      if(_15120) {
        bool _15124 = *projectedLighting;
        
        if(_15124) {
          uint _15127 = *lightIndex;
          float _15128 = ConvertUToF(_15127);
          float* _15129 = &camera.nprLightingParameters.y;
          float _15130 = *_15129;
          bool _15131 = _15128 == _15130;
        }

        bool _15132 = Phi(_15124, _15131);
        *composedHair = _15132;
        
        if(false) {
          uint* _15136 = &material.materialFeatures;
          uint _15137 = *_15136;
          uint _15139 = _15137 & _15138;
          uint _15140 = _15139 | azureFixedMaterialFeatureValue;
          *param@217 = azureOrdinaryOpaque;
          *param@218 = _15140;
          uint _15143 = azureSpecializedMaterialFeatures(param@217, param@218);
          uint _15144 = _15143 & 8388608;
          bool _15145 = _15144 != 0;
        }

        bool _15146 = Phi(false, _15145);
        bool _15147 = *composedHair;
        bool _15148 = !_15147;
        bool _15149 = _15146 && _15148;
        
        if(_15149) {
          bool _15152 = *characterLight;
          bool _15153 = *specularOnly;
          bool _15154 = _15152 || _15153;
        }

        bool _15155 = Phi(_15149, _15154);
        *integrateIncident = _15155;
        bool _15156 = *integrateIncident;
        
        if(_15156) {
          float3 _15160 = *radiance;
          bool _15161 = *characterLight;
          float _15162 = Select(_15161, 2.0000, 1.0000);
          float2 _15163 = *localResponse;
          float _15164 = *characterSceneVisibility;
          float _15165 = _15163.x;
          float _15166 = _15163.y;
          float4 _15167 = CompositeConstruct({_15162, _15165, _15166, _15164});
          float* _15168 = &light.boxParameters.z;
          float _15169 = *_15168;
          ProjectedHairIncident _15170 = CompositeConstruct({_15160, _15167, {0.0000, 0.0000, 0.0000, 0.0000}, _15169, 1.0000, 1.0000});
          *incident = _15170;
          float* _15172 = &light.coneType.y;
          float _15173 = *_15172;
          bool _15174 = _15173 > 1.5000;
          float3 _15177 = *viewDirection;
          *param@219 = _15177;
          float3 _15179 = *pointDirection;
          *param@220 = _15179;
          *param@221 = _15174;
          *param@222 = false;
          ProjectedHairIncident _15183 = *incident;
          *param@223 = _15183;
          CharacterProjectedHairEnergy _15185 = projectedHairResponseWeighted(param@219, param@220, param@221, param@222, param@223, param@224);
          float2 _15186 = *param@224;
          *unusedLine = _15186;
          *energy = _15185;
          *hairRadiance = {1.0000, 1.0000, 1.0000};
        } else {
          float* _15188 = &light.coneType.y;
          float _15189 = *_15188;
          bool _15190 = _15189 > 1.5000;
          float3 _15192 = *viewDirection;
          *param@225 = _15192;
          float3 _15194 = *pointDirection;
          *param@226 = _15194;
          *param@227 = _15190;
          CharacterProjectedHairEnergy _15196 = projectedHairDirect(param@225, param@226, param@227);
          *energy = _15196;
        }

        bool _15197 = *projectedLighting;
        
        if(_15197) {
          uint _15200 = *lightIndex;
          float _15201 = ConvertUToF(_15200);
          float* _15202 = &camera.nprLightingParameters.y;
          float _15203 = *_15202;
          bool _15204 = _15201 == _15203;
        }

        bool _15205 = Phi(_15197, _15204);
        
        if(_15205) {
          *mainHairAvailable = true;
          float3* _15208 = &energy.primary;
          float3 _15209 = *_15208;
          *mainHairPrimary = _15209;
          float3* _15210 = &energy.secondary;
          float3 _15211 = *_15210;
          *mainHairSecondary = _15211;
        } else {
          float3* _15213 = &energy.primary;
          float3 _15214 = *_15213;
          float3 _15215 = *hairRadiance;
          float3 _15216 = _15214 * _15215;
          float* _15217 = &material.featureParameters.y;
          float _15218 = *_15217;
          float3 _15219 = _15216 * _15218;
          float3 _15220 = *sceneHairPrimary;
          float3 _15221 = _15220 + _15219;
          *sceneHairPrimary = _15221;
          float* _15222 = &light.coneType.y;
          float _15223 = *_15222;
          bool _15224 = _15223 > 1.5000;
          
          if(_15224) {
            float3* _15227 = &energy.secondary;
            float3 _15228 = *_15227;
            float3 _15229 = *hairRadiance;
            float3 _15230 = _15228 * _15229;
            float* _15231 = &material.featureParameters.y;
            float _15232 = *_15231;
            float3 _15233 = _15230 * _15232;
            float3 _15234 = *sceneHairSecondary;
            float3 _15235 = _15234 + _15233;
            *sceneHairSecondary = _15235;
          }

        }

      } else {
        float3x3 _15238 = *tangentToWorld;
        float4 _15240 = *hairData;
        float2 _15241 = _15240.zw;
        *param@228 = _15241;
        float3 _15242 = decodePackedHairNormal(param@228);
        float3 _15243 = _15238 * _15242;
        float3 _15244 = GLSL.std.450::Normalize(_15243);
        *highlightNormal = _15244;
        float3x3 _15246 = *tangentToWorld;
        float4* _15247 = &material.matcapColor;
        float4 _15248 = *_15247;
        float3 _15249 = _15248.xyz;
        float3 _15250 = _15246 * _15249;
        float3 _15252 = *shadedNormal;
        *param@229 = _15252;
        float3 _15254 = *tangent;
        *param@230 = _15254;
        float3 _15256 = *bitangent;
        *param@231 = _15256;
        float3 _15258 = *highlightNormal;
        *param@232 = _15258;
        float3 _15260 = *viewDirection;
        *param@233 = _15260;
        float3 _15262 = *pointDirection;
        *param@234 = _15262;
        *param@235 = _15250;
        float* _15265 = &material.hairParameters.x;
        float _15266 = *_15265;
        *param@236 = _15266;
        float* _15268 = &material.hairParameters.w;
        float _15269 = *_15268;
        *param@237 = _15269;
        float2 _15270 = characterHairLobes(param@229, param@230, param@231, param@232, param@233, param@234, param@235, param@236, param@237);
        *lobes = _15270;
        float2 _15274 = *lobes;
        float2 _15275 = Fwidth(_15274);
        float2 _15277 = GLSL.std.450::FMax(_15275, {0.1200, 0.1200});
        float2 _15278 = {0.5000, 0.4300} - _15277;
        float2 _15279 = *lobes;
        float2 _15280 = Fwidth(_15279);
        float2 _15281 = GLSL.std.450::FMax(_15280, {0.1200, 0.1200});
        float2 _15282 = {0.5000, 0.4300} + _15281;
        float2 _15283 = *lobes;
        float2 _15284 = GLSL.std.450::SmoothStep(_15278, _15282, _15283);
        *bands = _15284;
        float3 _15287 = *geometricNormal;
        float3 _15288 = *viewDirection;
        float _15289 = Dot(_15287, _15288);
        float _15290 = GLSL.std.450::SmoothStep(-0.2000, 0.4500, _15289);
        *visibility@2 = _15290;
        SampledImage<float, 2D>* _15292 = &textureArray[1];
        SampledImage<float, 2D> _15293 = *_15292;
        Image<float, 2D> _15294 = Image(_15293);
        int2 _15295 = ImageQuerySizeLod(_15294, 0);
        float2 _15296 = ConvertSToF(_15295);
        *rampExtent = _15296;
        SampledImage<float, 2D>* _15298 = &textureArray[1];
        SampledImage<float, 2D> _15299 = *_15298;
        float* _15300 = &lobes.x;
        float _15301 = *_15300;
        float* _15302 = &rampExtent.x;
        float _15303 = *_15302;
        float _15304 = 0.5000 / _15303;
        float* _15305 = &rampExtent.x;
        float _15306 = *_15305;
        float _15307 = 0.5000 / _15306;
        float _15308 = 1.0000 - _15307;
        float _15309 = GLSL.std.450::FClamp(_15301, _15304, _15308);
        float* _15310 = &material.hairParameters.z;
        float _15311 = *_15310;
        float _15312 = _15311 + 0.5000;
        float* _15313 = &rampExtent.y;
        float _15314 = *_15313;
        float _15315 = _15312 / _15314;
        float2 _15316 = CompositeConstruct({_15309, _15315});
        float4 _15317 = ImageSampleExplicitLod(_15299, _15316, Lod(0.0000));
        float3 _15318 = _15317.xyz;
        float _15319 = Dot(_15318, {0.2126, 0.7152, 0.0722});
        *hairRamp = _15319;
        *param@238 = 512;
        float _15322 = materialFeatureEnabled(param@238);
        bool _15323 = _15322 > 0.5000;
        
        if(_15323) {
          uint* _15327 = &material.textureBase;
          uint _15328 = *_15327;
          uint _15329 = _15328 + 5;
          uint _15330 = CopyObject(_15329) : [[NonUniform]];
          SampledImage<float, 2D>* _15331 = &textureArray[_15330] : [[NonUniform]];
          SampledImage<float, 2D> _15332 = *_15331 : [[NonUniform]];
          Image<float, 2D> _15333 = Image(_15332) : [[NonUniform]];
          int2 _15334 = ImageQuerySizeLod(_15333, 0);
          int _15335 = _15334.x;
          float _15336 = ConvertSToF(_15335);
          *width = _15336;
          uint* _15337 = &material.textureBase;
          uint _15338 = *_15337;
          uint _15339 = _15338 + 5;
          uint _15340 = CopyObject(_15339) : [[NonUniform]];
          SampledImage<float, 2D>* _15341 = &textureArray[_15340] : [[NonUniform]];
          SampledImage<float, 2D> _15342 = *_15341 : [[NonUniform]];
          float* _15343 = &lobes.x;
          float _15344 = *_15343;
          float _15345 = *width;
          float _15346 = _15345 - 1.0000;
          float _15347 = _15344 * _15346;
          float _15348 = _15347 + 0.5000;
          float _15349 = *width;
          float _15350 = _15348 / _15349;
          float2 _15351 = CompositeConstruct({_15350, 0.5000});
          float4 _15352 = ImageSampleExplicitLod(_15342, _15351, Lod(0.0000));
          float _15353 = _15352.x;
          *hairRamp = _15353;
        }

        bool _15355 = *characterLight;
        bool _15356 = *specularOnly;
        bool _15357 = _15355 || _15356;
        
        if(_15357) {
          float3 _15361 = *characterRadiance;
          float* _15362 = &light.boxParameters.z;
          float _15363 = *_15362;
          float3 _15364 = _15361 * _15363;
          *_15358 = _15364;
        } else {
          float3 _15366 = *radiance;
          *_15358 = _15366;
        }

        float3 _15367 = *_15358;
        float _15368 = *pointDiffuse;
        float3 _15369 = _15367 * _15368;
        float* _15370 = &material.hairParameters.y;
        float _15371 = *_15370;
        float3 _15372 = _15369 * _15371;
        float* _15373 = &material.featureParameters.y;
        float _15374 = *_15373;
        float3 _15375 = _15372 * _15374;
        float _15376 = *hairRamp;
        float3 _15377 = _15375 * _15376;
        *energy@2 = _15377;
        float4 _15378 = *baseColor;
        float3 _15379 = _15378.xyz;
        float3 _15381 = CompositeConstruct({0.1800, 0.1800, 0.1800});
        float3 _15382 = GLSL.std.450::FMix(_15379, {1.0000, 0.6800, 0.7400}, _15381);
        float* _15383 = &bands.x;
        float _15384 = *_15383;
        float3 _15385 = _15382 * _15384;
        float _15386 = *visibility@2;
        float _15387 = GLSL.std.450::FMix(0.5800, 1.0000, _15386);
        float3 _15388 = _15385 * _15387;
        float3 _15389 = _15388 * 0.5800;
        float3 _15390 = *energy@2;
        float3 _15391 = _15389 * _15390;
        float3 _15392 = *sceneHairPrimary;
        float3 _15393 = _15392 + _15391;
        *sceneHairPrimary = _15393;
        float4 _15394 = *baseColor;
        float3 _15395 = _15394.xyz;
        float3 _15397 = CompositeConstruct({0.1200, 0.1200, 0.1200});
        float3 _15398 = GLSL.std.450::FMix(_15395, {0.7200, 0.8800, 1.0000}, _15397);
        float* _15399 = &bands.y;
        float _15400 = *_15399;
        float3 _15401 = _15398 * _15400;
        float _15402 = *visibility@2;
        float _15403 = GLSL.std.450::FMix(0.3500, 0.7200, _15402);
        float3 _15404 = _15401 * _15403;
        float3 _15405 = _15404 * 0.2200;
        float3 _15406 = *energy@2;
        float3 _15407 = _15405 * _15406;
        float3 _15408 = *sceneHairSecondary;
        float3 _15409 = _15408 + _15407;
        *sceneHairSecondary = _15409;
      }

    }

    bool _15410 = *sceneCharacter;
    bool _15411 = *specularOnly;
    bool _15412 = !_15411;
    bool _15413 = _15410 && _15412;
    
    if(_15413) {
      int _15416 = *qaEffectMode;
      bool _15417 = _15416 == 4;
      bool _15418 = *qaEffectDisabled;
      bool _15419 = _15417 && _15418;
      bool _15420 = !_15419;
    }

    bool _15421 = Phi(_15413, _15420);
    
    if(_15421) {
      float3 _15424 = *radiance;
      float _15425 = *normalDotView;
      float _15426 = 1.0000 - _15425;
      float _15428 = GLSL.std.450::Pow(_15426, 3.2000);
      float3 _15429 = _15424 * _15428;
      float3 _15431 = *shadedNormal;
      float3 _15432 = *pointDirection;
      float _15433 = Dot(_15431, _15432);
      float _15434 = GLSL.std.450::SmoothStep(-0.2500, 0.6500, _15433);
      float3 _15435 = _15429 * _15434;
      float* _15436 = &material.styleParameters.w;
      float _15437 = *_15436;
      float3 _15438 = _15435 * _15437;
      float3 _15439 = _15438 * 0.1200;
      float3 _15440 = *sceneRim;
      float3 _15441 = _15440 + _15439;
      *sceneRim = _15441;
    }

loop_continue1:
    uint _15442 = *lightOffset;
    uint _15443 = _15442 + 1;
    *lightOffset = _15443;
  }

  float3 _15444 = *clusteredDiffuse;
  float _15445 = *hairActive;
  float _15446 = GLSL.std.450::FMix(1.0000, 0.7200, _15445);
  float3 _15447 = _15444 * _15446;
  float3 _15448 = *directDiffuse;
  float3 _15449 = _15448 + _15447;
  *directDiffuse = _15449;
  float _15451 = *rampLuminance;
  float _15452 = GLSL.std.450::SmoothStep(0.3800, 0.6600, _15451);
  float _15453 = 1.0000 - _15452;
  *shadowRegion = _15453;
  float _15455 = *bandEnabled;
  float* _15456 = &material.styleParameters.x;
  float _15457 = *_15456;
  float _15458 = _15455 * _15457;
  float _15459 = GLSL.std.450::FClamp(_15458, 0.0000, 1.0000);
  *shadowSystemWeight = _15459;
  float _15461 = *shadowRegion;
  float _15462 = *shadowVisibility;
  float _15463 = 1.0000 - _15462;
  float _15464 = _15463 * 0.7200;
  float _15465 = GLSL.std.450::FMax(_15461, _15464);
  float _15466 = *shadowSystemWeight;
  float _15467 = _15465 * _15466;
  float* _15468 = &material.styleParameters.y;
  float _15469 = *_15468;
  float _15470 = _15467 * _15469;
  *param@239 = 1;
  float _15472 = materialFeatureEnabled(param@239);
  float _15473 = _15470 * _15472;
  *shadowWeight = _15473;
  
  if(azureOrdinaryOpaque) {
    *_15474 = 0;
  } else {
    
    if(_15478) {
      *_15479 = azureFixedMaterialClass;
    } else {
      uint* _15483 = &material.materialClass;
      uint _15484 = *_15483;
      *_15479 = _15484;
    }

    uint _15485 = *_15479;
    *_15474 = _15485;
  }

  uint _15486 = *_15474;
  bool _15487 = _15486 == 2;
  
  if(_15487) {
    *_15488 = 0.2800;
  } else {
    
    if(azureOrdinaryOpaque) {
      *_15493 = 0;
    } else {
      
      if(_15497) {
        *_15498 = azureFixedMaterialClass;
      } else {
        uint* _15502 = &material.materialClass;
        uint _15503 = *_15502;
        *_15498 = _15503;
      }

      uint _15504 = *_15498;
      *_15493 = _15504;
    }

    uint _15505 = *_15493;
    bool _15506 = _15505 == 1;
    float _15507 = Select(_15506, 0.6200, 1.0000);
    *_15488 = _15507;
  }

  float _15508 = *_15488;
  float _15509 = *shadowWeight;
  float _15510 = _15509 * _15508;
  *shadowWeight = _15510;
  float4* _15512 = &material.lamShadowColor;
  float4 _15513 = *_15512;
  float3 _15514 = _15513.xyz;
  float* _15515 = &material.lamShadowColor.w;
  float _15516 = *_15515;
  float _15517 = *shadowWeight;
  float _15518 = _15516 * _15517;
  float _15519 = *showcasePreset;
  bool _15520 = _15519 == 1.0000;
  float _15522 = Select(_15520, 0.3600, 0.3600);
  float _15523 = _15518 * _15522;
  float3 _15524 = CompositeConstruct({_15523, _15523, _15523});
  float3 _15525 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, _15514, _15524);
  *lamShadowTint = _15525;
  
  if(azureOrdinaryOpaque) {
    *_15527 = 0;
  } else {
    
    if(_15531) {
      *_15532 = azureFixedMaterialClass;
    } else {
      uint* _15536 = &material.materialClass;
      uint _15537 = *_15536;
      *_15532 = _15537;
    }

    uint _15538 = *_15532;
    *_15527 = _15538;
  }

  uint _15539 = *_15527;
  bool _15540 = _15539 == 2;
  
  if(_15540) {
    *_15541 = 0.1000;
  } else {
    
    if(azureOrdinaryOpaque) {
      *_15545 = 0;
    } else {
      
      if(_15549) {
        *_15550 = azureFixedMaterialClass;
      } else {
        uint* _15554 = &material.materialClass;
        uint _15555 = *_15554;
        *_15550 = _15555;
      }

      uint _15556 = *_15550;
      *_15545 = _15556;
    }

    uint _15557 = *_15545;
    bool _15558 = _15557 == 1;
    float _15559 = Select(_15558, 0.2800, 1.0000);
    *_15541 = _15559;
  }

  float _15560 = *_15541;
  *aoClassWeight = _15560;
  float4* _15562 = &material.aoColor;
  float4 _15563 = *_15562;
  float3 _15564 = _15563.xyz;
  float* _15565 = &material.aoColor.w;
  float _15566 = *_15565;
  float _15567 = *shadowWeight;
  float _15568 = *styleMask;
  float _15569 = _15568 * 0.4200;
  float _15570 = _15567 + _15569;
  float _15571 = GLSL.std.450::FClamp(_15570, 0.0000, 1.0000);
  float _15572 = _15571 * 0.3800;
  float _15573 = 0.1000 + _15572;
  float _15574 = _15566 * _15573;
  float _15575 = *aoClassWeight;
  float _15576 = _15574 * _15575;
  float3 _15577 = CompositeConstruct({_15576, _15576, _15576});
  float3 _15578 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, _15564, _15577);
  *aoShadowTint = _15578;
  float* _15580 = &material.aoColor.w;
  float _15581 = *_15580;
  bool _15582 = _15581 > 0.0100;
  
  if(_15582) {
    float4* _15586 = &material.aoColor;
    float4 _15587 = *_15586;
    float3 _15588 = _15587.xyz;
    *_15583 = _15588;
  } else {
    *_15583 = {0.2550, 0.2550, 0.2550};
  }

  float3 _15592 = *_15583;
  *hairAoColor = _15592;
  float3 _15594 = *hairAoColor;
  float _15595 = *hairActive;
  float _15596 = *physicalAo;
  float _15597 = 1.0000 - _15596;
  float _15598 = _15595 * _15597;
  float _15599 = _15598 * 0.6500;
  float3 _15600 = CompositeConstruct({_15599, _15599, _15599});
  float3 _15601 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, _15594, _15600);
  *hairAoTint = _15601;
  float3 _15602 = *hairAoTint;
  float3 _15603 = *aoShadowTint;
  float3 _15604 = _15603 * _15602;
  *aoShadowTint = _15604;
  float3 _15606 = *ambientDiffuse;
  float3 _15607 = *aoShadowTint;
  float3 _15608 = _15606 * _15607;
  float _15609 = *physicalAo;
  float3 _15610 = _15608 * _15609;
  float3 _15611 = *directDiffuse;
  float3 _15612 = *lamShadowTint;
  float3 _15613 = _15611 * _15612;
  float3 _15614 = _15610 + _15613;
  *tintedDiffuse = _15614;
  float* _15616 = &tintedDiffuse.x;
  float _15617 = *_15616;
  float* _15618 = &tintedDiffuse.y;
  float _15619 = *_15618;
  float _15620 = GLSL.std.450::FMax(_15617, _15619);
  float* _15621 = &tintedDiffuse.z;
  float _15622 = *_15621;
  float _15623 = GLSL.std.450::FMax(_15620, _15622);
  *hairDiffusePeak = _15623;
  float _15625 = *hairBasePeak;
  float _15627 = *rampLuminance;
  float _15628 = GLSL.std.450::FMix(0.2400, 0.4200, _15627);
  float _15629 = _15625 * _15628;
  *hairDiffuseFloor = _15629;
  float _15630 = *hairDiffusePeak;
  float _15631 = *hairDiffuseFloor;
  float _15632 = GLSL.std.450::FMax(_15630, _15631);
  *hairDiffusePeak = _15632;
  float3 _15634 = *hairBaseHue;
  float _15635 = *hairDiffusePeak;
  float3 _15636 = _15634 * _15635;
  *huePreservedHair = _15636;
  float3 _15637 = *tintedDiffuse;
  float3 _15638 = *huePreservedHair;
  float _15639 = *hairActive;
  float _15640 = _15639 * 0.8000;
  float3 _15641 = CompositeConstruct({_15640, _15640, _15640});
  float3 _15642 = GLSL.std.450::FMix(_15637, _15638, _15641);
  *tintedDiffuse = _15642;
  
  if(azureOrdinaryOpaque) {
    *_15644 = 0;
  } else {
    
    if(_15648) {
      *_15649 = azureFixedMaterialClass;
    } else {
      uint* _15653 = &material.materialClass;
      uint _15654 = *_15653;
      *_15649 = _15654;
    }

    uint _15655 = *_15649;
    *_15644 = _15655;
  }

  uint _15656 = *_15644;
  bool _15657 = _15656 == 2;
  bool _15658 = *dualFaceSdf;
  bool _15659 = !_15658;
  bool _15660 = _15657 && _15659;
  float _15661 = Select(_15660, 1.0000, 0.0000);
  *faceActive = _15661;
  float _15664 = *faceActive;
  float3 _15665 = CompositeConstruct({_15664, _15664, _15664});
  float3 _15666 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, {0.8600, 0.7700, 0.7400}, _15665);
  float3 _15667 = *tintedDiffuse;
  float3 _15668 = _15667 * _15666;
  *tintedDiffuse = _15668;
  float4* _15669 = &camera.faceSdfShadowColor;
  float4 _15670 = *_15669;
  float3 _15671 = _15670.xyz;
  float _15672 = *faceIllumination;
  float _15673 = 1.0000 - _15672;
  float _15674 = *faceSdfWeight;
  float _15675 = _15673 * _15674;
  float* _15676 = &camera.faceSdfShadowColor.w;
  float _15677 = *_15676;
  float _15678 = _15675 * _15677;
  float _15679 = _15678 * 0.5500;
  float3 _15680 = CompositeConstruct({_15679, _15679, _15679});
  float3 _15681 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, _15671, _15680);
  float3 _15682 = *tintedDiffuse;
  float3 _15683 = _15682 * _15681;
  *tintedDiffuse = _15683;
  bool _15685 = *microfacetSurface;
  
  if(_15685) {
    float3 _15689 = *shadedNormal;
    float3 _15690 = *halfDirection;
    float _15691 = Dot(_15689, _15690);
    float _15692 = GLSL.std.450::FMax(_15691, 0.0000);
    float3 _15693 = *viewDirection;
    float3 _15694 = *halfDirection;
    float _15695 = Dot(_15693, _15694);
    float _15696 = GLSL.std.450::FMax(_15695, 0.0000);
    float3 _15698 = *f0;
    *param@240 = _15698;
    float _15700 = *roughness;
    *param@241 = _15700;
    float _15702 = *diffuse;
    *param@242 = _15702;
    float _15704 = *normalDotView;
    *param@243 = _15704;
    *param@244 = _15692;
    *param@245 = _15696;
    float3 _15707 = directSurfaceSpecular(param@240, param@241, param@242, param@243, param@244, param@245);
    float3 _15708 = *keyColor;
    float3 _15709 = _15707 * _15708;
    float* _15710 = &camera.showcaseParameters.y;
    float _15711 = *_15710;
    float3 _15712 = _15709 * _15711;
    *_15686 = _15712;
  } else {
    float3 _15714 = *f0;
    float _15715 = *specularLobe;
    float3 _15716 = _15714 * _15715;
    float _15717 = *diffuse;
    float3 _15718 = _15716 * _15717;
    float _15719 = *roughness;
    float _15720 = GLSL.std.450::FMix(0.7000, 0.1200, _15719);
    float3 _15721 = _15718 * _15720;
    *_15686 = _15721;
  }

  float3 _15722 = *_15686;
  float _15723 = *keyVisibility;
  float3 _15724 = _15722 * _15723;
  float* _15725 = &material.styleParameters.z;
  float _15726 = *_15725;
  float3 _15727 = _15724 * _15726;
  *directSpecular = _15727;
  float3 _15728 = *clusteredSpecular;
  float* _15729 = &material.styleParameters.z;
  float _15730 = *_15729;
  float3 _15731 = _15728 * _15730;
  float3 _15732 = *directSpecular;
  float3 _15733 = _15732 + _15731;
  *directSpecular = _15733;
  float* _15734 = &material.styleParameters.z;
  float _15735 = *_15734;
  float3 _15736 = *ambientSpecular;
  float3 _15737 = _15736 * _15735;
  *ambientSpecular = _15737;
  
  if(azureOrdinaryOpaque) {
    *_15739 = 0;
  } else {
    
    if(_15743) {
      *_15744 = azureFixedMaterialClass;
    } else {
      uint* _15748 = &material.materialClass;
      uint _15749 = *_15748;
      *_15744 = _15749;
    }

    uint _15750 = *_15744;
    *_15739 = _15750;
  }

  uint _15751 = *_15739;
  bool _15752 = _15751 == 1;
  
  if(_15752) {
    *_15753 = 0.0500;
  } else {
    
    if(azureOrdinaryOpaque) {
      *_15757 = 0;
    } else {
      
      if(_15761) {
        *_15762 = azureFixedMaterialClass;
      } else {
        uint* _15766 = &material.materialClass;
        uint _15767 = *_15766;
        *_15762 = _15767;
      }

      uint _15768 = *_15762;
      *_15757 = _15768;
    }

    uint _15769 = *_15757;
    bool _15770 = _15769 == 2;
    
    if(_15770) {
      *_15771 = 0.0300;
    } else {
      
      if(azureOrdinaryOpaque) {
        *_15776 = 0;
      } else {
        
        if(_15780) {
          *_15781 = azureFixedMaterialClass;
        } else {
          uint* _15785 = &material.materialClass;
          uint _15786 = *_15785;
          *_15781 = _15786;
        }

        uint _15787 = *_15781;
        *_15776 = _15787;
      }

      uint _15788 = *_15776;
      bool _15789 = _15788 == 3;
      float _15790 = Select(_15789, 0.0800, 1.0000);
      *_15771 = _15790;
    }

    float _15791 = *_15771;
    *_15753 = _15791;
  }

  float _15792 = *_15753;
  *dielectricSpecularWeight = _15792;
  float _15793 = *dielectricSpecularWeight;
  float3 _15794 = *ambientSpecular;
  float3 _15795 = _15794 * _15793;
  *ambientSpecular = _15795;
  float _15796 = *dielectricSpecularWeight;
  float3 _15797 = *directSpecular;
  float3 _15798 = _15797 * _15796;
  *directSpecular = _15798;
  float3 _15799 = *ambientSpecular;
  float3 _15800 = *ambientSpecular;
  float4 _15801 = *baseColor;
  float3 _15802 = _15801.xyz;
  float3 _15803 = CompositeConstruct({0.1800, 0.1800, 0.1800});
  float3 _15804 = GLSL.std.450::FMix(_15802, {1.0000, 1.0000, 1.0000}, _15803);
  float3 _15805 = _15800 * _15804;
  float _15806 = *hairActive;
  float3 _15807 = CompositeConstruct({_15806, _15806, _15806});
  float3 _15808 = GLSL.std.450::FMix(_15799, _15805, _15807);
  *ambientSpecular = _15808;
  float _15810 = *styleMask;
  float _15811 = *toonWeight;
  float _15812 = _15810 * _15811;
  float _15813 = GLSL.std.450::FMix(1.0000, 1.3000, _15812);
  float _15814 = *hairActive;
  float _15815 = GLSL.std.450::FMix(1.0000, 0.7200, _15814);
  float _15816 = _15813 * _15815;
  float3 _15817 = *directSpecular;
  float3 _15818 = _15817 * _15816;
  *directSpecular = _15818;
  float _15820 = *styleMask;
  float _15821 = *toonWeight;
  float _15822 = _15820 * _15821;
  float _15823 = GLSL.std.450::FMix(1.0000, 1.1200, _15822);
  float _15824 = *hairActive;
  float _15825 = GLSL.std.450::FMix(1.0000, 0.6800, _15824);
  float _15826 = _15823 * _15825;
  float3 _15827 = *ambientSpecular;
  float3 _15828 = _15827 * _15826;
  *ambientSpecular = _15828;
  int _15829 = *qaEffectMode;
  bool _15830 = _15829 == 5;
  bool _15831 = *qaEffectDisabled;
  bool _15832 = _15830 && _15831;
  
  if(_15832) {
    *ambientSpecular = {0.0000, 0.0000, 0.0000};
    *directSpecular = {0.0000, 0.0000, 0.0000};
  }

  bool _15836 = *dualFaceSdf;
  
  if(_15836) {
    float3 _15840 = *faceLightingNormal;
    float3 _15841 = *viewDirection;
    float _15842 = Dot(_15840, _15841);
    float _15843 = GLSL.std.450::FAbs(_15842);
    *_15837 = _15843;
  } else {
    float _15845 = *normalDotView;
    *_15837 = _15845;
  }

  float _15846 = *_15837;
  *rimNormalDotView = _15846;
  float _15848 = *rimNormalDotView;
  float _15849 = 1.0000 - _15848;
  float _15850 = GLSL.std.450::Pow(_15849, 3.2000);
  float3 _15851 = *faceLightingNormal;
  float3 _15852 = *fillDirection;
  float3 _15853 = -_15852;
  float _15854 = Dot(_15851, _15853);
  float _15855 = GLSL.std.450::SmoothStep(-0.2500, 0.6500, _15854);
  float _15856 = _15850 * _15855;
  *rim = _15856;
  float3 _15858 = *rimColor;
  float4 _15859 = *baseColor;
  float3 _15860 = _15859.xyz;
  float3 _15861 = CompositeConstruct({0.2200, 0.2200, 0.2200});
  float3 _15862 = GLSL.std.450::FMix(_15858, _15860, _15861);
  float _15863 = *rim;
  float3 _15864 = _15862 * _15863;
  float* _15865 = &camera.showcaseParameters.w;
  float _15866 = *_15865;
  float3 _15867 = _15864 * _15866;
  float _15868 = *bandEnabled;
  float3 _15869 = _15867 * _15868;
  float* _15870 = &material.styleParameters.w;
  float _15871 = *_15870;
  float3 _15872 = _15869 * _15871;
  float _15873 = *platformMask;
  float _15874 = 1.0000 - _15873;
  float3 _15875 = _15872 * _15874;
  *rimLighting = _15875;
  float _15876 = *hairActive;
  float _15877 = GLSL.std.450::FMix(1.0000, 0.2200, _15876);
  float3 _15878 = *rimLighting;
  float3 _15879 = _15878 * _15877;
  *rimLighting = _15879;
  float3 _15880 = *rimLighting;
  float3 _15881 = *rimLighting;
  float3 _15882 = *hairBaseHue;
  float3 _15883 = _15881 * _15882;
  float _15884 = *hairActive;
  float _15885 = _15884 * 0.7500;
  float3 _15886 = CompositeConstruct({_15885, _15885, _15885});
  float3 _15887 = GLSL.std.450::FMix(_15880, _15883, _15886);
  *rimLighting = _15887;
  int _15888 = *qaEffectMode;
  bool _15889 = _15888 == 4;
  bool _15890 = *qaEffectDisabled;
  bool _15891 = _15889 && _15890;
  
  if(_15891) {
    *rimLighting = {0.0000, 0.0000, 0.0000};
  }

  *kkSpecular = {0.0000, 0.0000, 0.0000};
  *secondaryKkSpecular = {0.0000, 0.0000, 0.0000};
  float _15896 = *hairActive;
  bool _15897 = _15896 > 0.0000;
  bool _15898 = *projectedHair;
  bool _15899 = !_15898;
  bool _15900 = _15897 && _15899;
  
  if(_15900) {
    float3x3 _15904 = *tangentToWorld;
    float4 _15906 = *hairData;
    float2 _15907 = _15906.zw;
    *param@246 = _15907;
    float3 _15908 = decodePackedHairNormal(param@246);
    float3 _15909 = _15904 * _15908;
    float3 _15910 = GLSL.std.450::Normalize(_15909);
    *hairHighlightNormal = _15910;
    float3 _15912 = *hairHighlightNormal;
    float3 _15913 = *tangent;
    float _15914 = Dot(_15912, _15913);
    float _15915 = _15914 * 0.1600;
    *hairShift = _15915;
    float3 _15917 = *bitangent;
    float3 _15918 = *shadedNormal;
    float _15919 = *hairShift;
    float3 _15920 = _15918 * _15919;
    float3 _15921 = _15917 + _15920;
    float3 _15922 = GLSL.std.450::Normalize(_15921);
    *hairStrandDirection = _15922;
    float3 _15924 = *bitangent;
    float3 _15925 = *shadedNormal;
    float _15926 = *hairShift;
    float* _15927 = &material.hairParameters.w;
    float _15928 = *_15927;
    float _15929 = _15926 + _15928;
    float3 _15930 = _15925 * _15929;
    float3 _15931 = _15924 + _15930;
    float3 _15932 = GLSL.std.450::Normalize(_15931);
    *secondaryHairStrand = _15932;
    float3 _15934 = *lightDirection;
    float3 _15935 = *viewDirection;
    float3x3 _15936 = *tangentToWorld;
    float4* _15937 = &material.matcapColor;
    float4 _15938 = *_15937;
    float3 _15939 = _15938.xyz;
    float3 _15940 = _15936 * _15939;
    float3 _15941 = _15935 + _15940;
    float3 _15942 = GLSL.std.450::Normalize(_15941);
    float3 _15943 = _15934 + _15942;
    float3 _15944 = GLSL.std.450::Normalize(_15943);
    *hairHalf = _15944;
    float3 _15946 = *hairStrandDirection;
    float3 _15947 = *hairHalf;
    float _15948 = Dot(_15946, _15947);
    *tangentDotHalf = _15948;
    float3 _15950 = *secondaryHairStrand;
    float3 _15951 = *hairHalf;
    float _15952 = Dot(_15950, _15951);
    *secondaryTangentDotHalf = _15952;
    float _15954 = *tangentDotHalf;
    float _15955 = *tangentDotHalf;
    float _15956 = _15954 * _15955;
    float _15957 = 1.0000 - _15956;
    float _15958 = GLSL.std.450::FMax(_15957, 0.0000);
    float _15959 = GLSL.std.450::Sqrt(_15958);
    *kkSine = _15959;
    float _15961 = *secondaryTangentDotHalf;
    float _15962 = *secondaryTangentDotHalf;
    float _15963 = _15961 * _15962;
    float _15964 = 1.0000 - _15963;
    float _15965 = GLSL.std.450::FMax(_15964, 0.0000);
    float _15966 = GLSL.std.450::Sqrt(_15965);
    *secondaryKkSine = _15966;
    float* _15968 = &material.hairParameters.x;
    float _15969 = *_15968;
    float _15970 = _15969 * 0.4000;
    float _15971 = GLSL.std.450::FClamp(_15970, 80.0000, 220.0000);
    *kkPower = _15971;
    float _15973 = *kkPower;
    float _15974 = _15973 * 0.4200;
    float _15975 = GLSL.std.450::FClamp(_15974, 38.0000, 96.0000);
    *secondaryKkPower = _15975;
    float _15977 = *kkSine;
    float _15978 = *kkPower;
    float _15979 = GLSL.std.450::Pow(_15977, _15978);
    *kkLobe = _15979;
    float _15981 = *secondaryKkSine;
    float _15982 = *secondaryKkPower;
    float _15983 = GLSL.std.450::Pow(_15981, _15982);
    *secondaryKkLobe = _15983;
    float _15985 = *kkLobe;
    float _15986 = Fwidth(_15985);
    float _15987 = GLSL.std.450::FMax(_15986, 0.1200);
    float _15988 = 0.5000 - _15987;
    float _15989 = *kkLobe;
    float _15990 = Fwidth(_15989);
    float _15991 = GLSL.std.450::FMax(_15990, 0.1200);
    float _15992 = 0.5000 + _15991;
    float _15993 = *kkLobe;
    float _15994 = GLSL.std.450::SmoothStep(_15988, _15992, _15993);
    *kkBand = _15994;
    float _15996 = *secondaryKkLobe;
    float _15997 = Fwidth(_15996);
    float _15998 = GLSL.std.450::FMax(_15997, 0.1200);
    float _15999 = 0.4300 - _15998;
    float _16000 = *secondaryKkLobe;
    float _16001 = Fwidth(_16000);
    float _16002 = GLSL.std.450::FMax(_16001, 0.1200);
    float _16003 = 0.4300 + _16002;
    float _16004 = *secondaryKkLobe;
    float _16005 = GLSL.std.450::SmoothStep(_15999, _16003, _16004);
    *secondaryKkBand = _16005;
    float3 _16007 = *geometricNormal;
    float3 _16008 = *viewDirection;
    float _16009 = Dot(_16007, _16008);
    float _16010 = GLSL.std.450::SmoothStep(-0.2000, 0.4500, _16009);
    *hairViewVisibility = _16010;
    float4 _16012 = *baseColor;
    float3 _16013 = _16012.xyz;
    float3 _16014 = CompositeConstruct({0.1800, 0.1800, 0.1800});
    float3 _16015 = GLSL.std.450::FMix(_16013, {1.0000, 0.6800, 0.7400}, _16014);
    *kkTint = _16015;
    float3 _16016 = *kkTint;
    float _16017 = *kkBand;
    float3 _16018 = _16016 * _16017;
    float _16019 = *hairViewVisibility;
    float _16020 = GLSL.std.450::FMix(0.5800, 1.0000, _16019);
    float3 _16021 = _16018 * _16020;
    float* _16022 = &material.hairParameters.y;
    float _16023 = *_16022;
    float3 _16024 = _16021 * _16023;
    float3 _16025 = _16024 * 0.5800;
    float _16026 = *hairActive;
    float3 _16027 = _16025 * _16026;
    float* _16028 = &material.featureParameters.y;
    float _16029 = *_16028;
    float3 _16030 = _16027 * _16029;
    float _16031 = *bandEnabled;
    float3 _16032 = _16030 * _16031;
    *kkSpecular = _16032;
    float4 _16034 = *baseColor;
    float3 _16035 = _16034.xyz;
    float3 _16036 = CompositeConstruct({0.1200, 0.1200, 0.1200});
    float3 _16037 = GLSL.std.450::FMix(_16035, {0.7200, 0.8800, 1.0000}, _16036);
    *secondaryKkTint = _16037;
    float3 _16038 = *secondaryKkTint;
    float _16039 = *secondaryKkBand;
    float3 _16040 = _16038 * _16039;
    float _16041 = *hairViewVisibility;
    float _16042 = GLSL.std.450::FMix(0.3500, 0.7200, _16041);
    float3 _16043 = _16040 * _16042;
    float* _16044 = &material.hairParameters.y;
    float _16045 = *_16044;
    float3 _16046 = _16043 * _16045;
    float3 _16047 = _16046 * 0.2200;
    float _16048 = *hairActive;
    float3 _16049 = _16047 * _16048;
    float* _16050 = &material.featureParameters.y;
    float _16051 = *_16050;
    float3 _16052 = _16049 * _16051;
    float _16053 = *bandEnabled;
    float3 _16054 = _16052 * _16053;
    *secondaryKkSpecular = _16054;
    SampledImage<float, 2D>* _16056 = &textureArray[1];
    SampledImage<float, 2D> _16057 = *_16056;
    Image<float, 2D> _16058 = Image(_16057);
    int2 _16059 = ImageQuerySizeLod(_16058, 0);
    float2 _16060 = ConvertSToF(_16059);
    *rampSize = _16060;
    SampledImage<float, 2D>* _16062 = &textureArray[1];
    SampledImage<float, 2D> _16063 = *_16062;
    float _16064 = *kkLobe;
    float* _16065 = &rampSize.x;
    float _16066 = *_16065;
    float _16067 = 0.5000 / _16066;
    float* _16068 = &rampSize.x;
    float _16069 = *_16068;
    float _16070 = 0.5000 / _16069;
    float _16071 = 1.0000 - _16070;
    float _16072 = GLSL.std.450::FClamp(_16064, _16067, _16071);
    float* _16073 = &material.hairParameters.z;
    float _16074 = *_16073;
    float _16075 = _16074 + 0.5000;
    float* _16076 = &rampSize.y;
    float _16077 = *_16076;
    float _16078 = _16075 / _16077;
    float2 _16079 = CompositeConstruct({_16072, _16078});
    float4 _16080 = ImageSampleExplicitLod(_16063, _16079, Lod(0.0000));
    float3 _16081 = _16080.xyz;
    float _16082 = Dot(_16081, {0.2126, 0.7152, 0.0722});
    *kkRamp = _16082;
    *param@247 = 512;
    float _16084 = materialFeatureEnabled(param@247);
    bool _16085 = _16084 > 0.5000;
    
    if(_16085) {
      uint* _16089 = &material.textureBase;
      uint _16090 = *_16089;
      uint _16091 = _16090 + 5;
      uint _16092 = CopyObject(_16091) : [[NonUniform]];
      SampledImage<float, 2D>* _16093 = &textureArray[_16092] : [[NonUniform]];
      SampledImage<float, 2D> _16094 = *_16093 : [[NonUniform]];
      Image<float, 2D> _16095 = Image(_16094) : [[NonUniform]];
      int2 _16096 = ImageQuerySizeLod(_16095, 0);
      int _16097 = _16096.x;
      float _16098 = ConvertSToF(_16097);
      *rampWidth = _16098;
      uint* _16099 = &material.textureBase;
      uint _16100 = *_16099;
      uint _16101 = _16100 + 5;
      uint _16102 = CopyObject(_16101) : [[NonUniform]];
      SampledImage<float, 2D>* _16103 = &textureArray[_16102] : [[NonUniform]];
      SampledImage<float, 2D> _16104 = *_16103 : [[NonUniform]];
      float _16105 = *kkLobe;
      float _16106 = GLSL.std.450::FClamp(_16105, 0.0000, 1.0000);
      float _16107 = *rampWidth;
      float _16108 = _16107 - 1.0000;
      float _16109 = _16106 * _16108;
      float _16110 = _16109 + 0.5000;
      float _16111 = *rampWidth;
      float _16112 = _16110 / _16111;
      float2 _16113 = CompositeConstruct({_16112, 0.5000});
      float4 _16114 = ImageSampleExplicitLod(_16104, _16113, Lod(0.0000));
      float _16115 = _16114.x;
      *kkRamp = _16115;
    }

    float _16116 = *kkRamp;
    float3 _16117 = *kkSpecular;
    float3 _16118 = _16117 * _16116;
    *kkSpecular = _16118;
    float _16119 = *kkRamp;
    float3 _16120 = *secondaryKkSpecular;
    float3 _16121 = _16120 * _16119;
    *secondaryKkSpecular = _16121;
    float3 _16122 = *kkSpecular;
    float* _16123 = &material.matcapColor.w;
    float _16124 = *_16123;
    float3 _16125 = CompositeConstruct({_16124, _16124, _16124});
    float3 _16126 = GLSL.std.450::FMin(_16122, _16125);
    *kkSpecular = _16126;
  }

  bool _16127 = *projectedHair;
  
  if(_16127) {
    float3 _16132 = *viewDirection;
    *param@248 = _16132;
    float3 _16134 = *lightDirection;
    *param@249 = _16134;
    *param@250 = true;
    CharacterProjectedHairEnergy _16136 = projectedHairDirect(param@248, param@249, param@250);
    *energy@3 = _16136;
    float3 _16138 = *keyColor;
    float* _16139 = &camera.showcaseParameters.y;
    float _16140 = *_16139;
    float3 _16141 = _16138 * _16140;
    float _16142 = *keyVisibility;
    float3 _16143 = _16141 * _16142;
    float* _16144 = &material.featureParameters.y;
    float _16145 = *_16144;
    float3 _16146 = _16143 * _16145;
    float _16147 = *bandEnabled;
    float3 _16148 = _16146 * _16147;
    *lightEnergy = _16148;
    float3* _16149 = &energy@3.primary;
    float3 _16150 = *_16149;
    float3 _16151 = *lightEnergy;
    float3 _16152 = _16150 * _16151;
    float* _16153 = &material.matcapColor.w;
    float _16154 = *_16153;
    float3 _16155 = CompositeConstruct({_16154, _16154, _16154});
    float3 _16156 = GLSL.std.450::FMin(_16152, _16155);
    *kkSpecular = _16156;
    float3* _16157 = &energy@3.secondary;
    float3 _16158 = *_16157;
    float3 _16159 = *lightEnergy;
    float3 _16160 = _16158 * _16159;
    *secondaryKkSpecular = _16160;
  }

  int _16161 = *qaEffectMode;
  bool _16162 = _16161 == 3;
  bool _16163 = *qaEffectDisabled;
  bool _16164 = _16162 && _16163;
  
  if(_16164) {
    *kkSpecular = {0.0000, 0.0000, 0.0000};
    *secondaryKkSpecular = {0.0000, 0.0000, 0.0000};
  }

  
  if(azureOrdinaryOpaque) {
    *_16168 = 0;
  } else {
    int* _16172 = &material.alphaMode;
    int _16173 = *_16172;
    *_16168 = _16173;
  }

  int _16174 = *_16168;
  bool _16175 = _16174 == 2;
  
  if(_16175) {
    float* _16179 = &baseColor.w;
    float _16180 = *_16179;
    *_16176 = _16180;
  } else {
    *_16176 = 1.0000;
  }

  float _16182 = *_16176;
  *outputAlpha = _16182;
  bool _16183 = *browOverlay;
  
  if(_16183) {
    SampledImage<float, 2D> _16187 = *overlaySceneDepth;
    float4 _16188 = *gl_FragCoord;
    float2 _16189 = _16188.xy;
    float4* _16190 = &camera.clusterDepth;
    float4 _16191 = *_16190;
    float2 _16192 = _16191.zw;
    float2 _16193 = _16189 / _16192;
    float4 _16194 = ImageSampleImplicitLod(_16187, _16193);
    float _16195 = _16194.x;
    *sceneDepth@2 = _16195;
    float3 _16197 = *worldPosition;
    float4* _16198 = &camera.cameraPosition;
    float4 _16199 = *_16198;
    float3 _16200 = _16199.xyz;
    float3 _16201 = _16197 - _16200;
    float4* _16202 = &camera.cameraForward;
    float4 _16203 = *_16202;
    float3 _16204 = _16203.xyz;
    float _16205 = Dot(_16201, _16204);
    *overlayDepth = _16205;
    float _16207 = *sceneDepth@2;
    float _16208 = *overlayDepth;
    float _16209 = _16207 - _16208;
    float* _16210 = &material.featureParameters.z;
    float _16211 = *_16210;
    float _16212 = GLSL.std.450::FMax(_16211, 0.0001);
    float _16213 = _16209 / _16212;
    float _16214 = GLSL.std.450::FClamp(_16213, 0.0000, 1.0000);
    *fade = _16214;
    float* _16215 = &material.featureParameters.y;
    float _16216 = *_16215;
    float _16217 = *fade;
    float _16218 = _16216 * _16217;
    *outputAlpha = _16218;
  }

  float4 _16220 = *specularEmissive;
  float3 _16221 = _16220.xyz;
  float* _16222 = &material.emissiveStrength;
  float _16223 = *_16222;
  float3 _16224 = _16221 * _16223;
  float3 _16225 = _16224 * 6.0000;
  float* _16226 = &material.featureParameters.z;
  float _16227 = *_16226;
  float3 _16228 = _16225 * _16227;
  *param@251 = 8;
  float _16230 = materialFeatureEnabled(param@251);
  float3 _16231 = _16228 * _16230;
  *emissive = _16231;
  int _16232 = *qaEffectMode;
  bool _16233 = _16232 == 6;
  bool _16234 = *qaEffectDisabled;
  bool _16235 = _16233 && _16234;
  
  if(_16235) {
    *emissive = {0.0000, 0.0000, 0.0000};
  }

  *matcapAccent = {0.0000, 0.0000, 0.0000};
  *param@252 = 4;
  float _16240 = materialFeatureEnabled(param@252);
  bool _16241 = _16240 > 0.5000;
  
  if(_16241) {
    float* _16244 = &material.matcapColor.w;
    float _16245 = *_16244;
    bool _16246 = _16245 != 0.0000;
  }

  bool _16247 = Phi(_16241, _16246);
  
  if(_16247) {
    float3 _16251 = *worldPosition;
    float4* _16252 = &camera.cameraPosition;
    float4 _16253 = *_16252;
    float3 _16254 = _16253.xyz;
    float3 _16255 = _16251 - _16254;
    float3 _16256 = GLSL.std.450::Normalize(_16255);
    *cameraForward = _16256;
    float3 _16258 = *cameraForward;
    float3 _16259 = GLSL.std.450::Cross(_16258, {0.0000, 1.0000, 0.0000});
    float3 _16260 = GLSL.std.450::Normalize(_16259);
    *cameraRight = _16260;
    float3 _16262 = *cameraRight;
    float3 _16263 = *cameraForward;
    float3 _16264 = GLSL.std.450::Cross(_16262, _16263);
    float3 _16265 = GLSL.std.450::Normalize(_16264);
    *cameraUp = _16265;
    float3 _16267 = *shadedNormal;
    float3 _16268 = *cameraRight;
    float _16269 = Dot(_16267, _16268);
    float _16270 = _16269 * 0.5000;
    float _16271 = _16270 + 0.5000;
    float3 _16272 = *shadedNormal;
    float3 _16273 = *cameraUp;
    float _16274 = Dot(_16272, _16273);
    float _16275 = _16274 * 0.5000;
    float _16276 = 0.5000 - _16275;
    float2 _16277 = CompositeConstruct({_16271, _16276});
    float2 _16282 = GLSL.std.450::FClamp(_16277, {0.0020, 0.0020}, {0.9980, 0.9980});
    *matcapUv = _16282;
    uint* _16284 = &material.textureBase;
    uint _16285 = *_16284;
    uint _16286 = _16285 + 5;
    uint _16287 = CopyObject(_16286) : [[NonUniform]];
    SampledImage<float, 2D>* _16288 = &textureArray[_16287] : [[NonUniform]];
    SampledImage<float, 2D> _16289 = *_16288 : [[NonUniform]];
    Image<float, 2D> _16290 = Image(_16289) : [[NonUniform]];
    int2 _16291 = ImageQuerySizeLod(_16290, 0);
    float2 _16292 = ConvertSToF(_16291);
    float2 _16293 = CompositeConstruct({5.0000, 5.0000});
    float2 _16294 = _16293 / _16292;
    *matcapTexel = _16294;
    uint* _16296 = &material.textureBase;
    uint _16297 = *_16296;
    uint _16298 = _16297 + 5;
    uint _16299 = CopyObject(_16298) : [[NonUniform]];
    SampledImage<float, 2D>* _16300 = &textureArray[_16299] : [[NonUniform]];
    SampledImage<float, 2D> _16301 = *_16300 : [[NonUniform]];
    float2 _16302 = *matcapUv;
    float4 _16303 = ImageSampleImplicitLod(_16301, _16302);
    float _16304 = _16303.x;
    float _16305 = _16304 * 0.2000;
    uint* _16306 = &material.textureBase;
    uint _16307 = *_16306;
    uint _16308 = _16307 + 5;
    uint _16309 = CopyObject(_16308) : [[NonUniform]];
    SampledImage<float, 2D>* _16310 = &textureArray[_16309] : [[NonUniform]];
    SampledImage<float, 2D> _16311 = *_16310 : [[NonUniform]];
    float2 _16312 = *matcapUv;
    float* _16313 = &matcapTexel.x;
    float _16314 = *_16313;
    float2 _16315 = CompositeConstruct({_16314, 0.0000});
    float2 _16316 = _16312 + _16315;
    float4 _16317 = ImageSampleImplicitLod(_16311, _16316);
    float _16318 = _16317.x;
    float _16320 = _16318 * 0.1250;
    float _16321 = _16305 + _16320;
    uint* _16322 = &material.textureBase;
    uint _16323 = *_16322;
    uint _16324 = _16323 + 5;
    uint _16325 = CopyObject(_16324) : [[NonUniform]];
    SampledImage<float, 2D>* _16326 = &textureArray[_16325] : [[NonUniform]];
    SampledImage<float, 2D> _16327 = *_16326 : [[NonUniform]];
    float2 _16328 = *matcapUv;
    float* _16329 = &matcapTexel.x;
    float _16330 = *_16329;
    float2 _16331 = CompositeConstruct({_16330, 0.0000});
    float2 _16332 = _16328 - _16331;
    float4 _16333 = ImageSampleImplicitLod(_16327, _16332);
    float _16334 = _16333.x;
    float _16335 = _16334 * 0.1250;
    float _16336 = _16321 + _16335;
    uint* _16337 = &material.textureBase;
    uint _16338 = *_16337;
    uint _16339 = _16338 + 5;
    uint _16340 = CopyObject(_16339) : [[NonUniform]];
    SampledImage<float, 2D>* _16341 = &textureArray[_16340] : [[NonUniform]];
    SampledImage<float, 2D> _16342 = *_16341 : [[NonUniform]];
    float2 _16343 = *matcapUv;
    float* _16344 = &matcapTexel.y;
    float _16345 = *_16344;
    float2 _16346 = CompositeConstruct({0.0000, _16345});
    float2 _16347 = _16343 + _16346;
    float4 _16348 = ImageSampleImplicitLod(_16342, _16347);
    float _16349 = _16348.x;
    float _16350 = _16349 * 0.1250;
    float _16351 = _16336 + _16350;
    uint* _16352 = &material.textureBase;
    uint _16353 = *_16352;
    uint _16354 = _16353 + 5;
    uint _16355 = CopyObject(_16354) : [[NonUniform]];
    SampledImage<float, 2D>* _16356 = &textureArray[_16355] : [[NonUniform]];
    SampledImage<float, 2D> _16357 = *_16356 : [[NonUniform]];
    float2 _16358 = *matcapUv;
    float* _16359 = &matcapTexel.y;
    float _16360 = *_16359;
    float2 _16361 = CompositeConstruct({0.0000, _16360});
    float2 _16362 = _16358 - _16361;
    float4 _16363 = ImageSampleImplicitLod(_16357, _16362);
    float _16364 = _16363.x;
    float _16365 = _16364 * 0.1250;
    float _16366 = _16351 + _16365;
    uint* _16367 = &material.textureBase;
    uint _16368 = *_16367;
    uint _16369 = _16368 + 5;
    uint _16370 = CopyObject(_16369) : [[NonUniform]];
    SampledImage<float, 2D>* _16371 = &textureArray[_16370] : [[NonUniform]];
    SampledImage<float, 2D> _16372 = *_16371 : [[NonUniform]];
    float2 _16373 = *matcapUv;
    float2 _16374 = *matcapTexel;
    float2 _16375 = _16373 + _16374;
    float4 _16376 = ImageSampleImplicitLod(_16372, _16375);
    float _16377 = _16376.x;
    float _16379 = _16377 * 0.0750;
    float _16380 = _16366 + _16379;
    uint* _16381 = &material.textureBase;
    uint _16382 = *_16381;
    uint _16383 = _16382 + 5;
    uint _16384 = CopyObject(_16383) : [[NonUniform]];
    SampledImage<float, 2D>* _16385 = &textureArray[_16384] : [[NonUniform]];
    SampledImage<float, 2D> _16386 = *_16385 : [[NonUniform]];
    float2 _16387 = *matcapUv;
    float2 _16388 = *matcapTexel;
    float2 _16389 = _16387 - _16388;
    float4 _16390 = ImageSampleImplicitLod(_16386, _16389);
    float _16391 = _16390.x;
    float _16392 = _16391 * 0.0750;
    float _16393 = _16380 + _16392;
    uint* _16394 = &material.textureBase;
    uint _16395 = *_16394;
    uint _16396 = _16395 + 5;
    uint _16397 = CopyObject(_16396) : [[NonUniform]];
    SampledImage<float, 2D>* _16398 = &textureArray[_16397] : [[NonUniform]];
    SampledImage<float, 2D> _16399 = *_16398 : [[NonUniform]];
    float2 _16400 = *matcapUv;
    float* _16401 = &matcapTexel.x;
    float _16402 = *_16401;
    float* _16403 = &matcapTexel.y;
    float _16404 = *_16403;
    float _16405 = -_16404;
    float2 _16406 = CompositeConstruct({_16402, _16405});
    float2 _16407 = _16400 + _16406;
    float4 _16408 = ImageSampleImplicitLod(_16399, _16407);
    float _16409 = _16408.x;
    float _16410 = _16409 * 0.0750;
    float _16411 = _16393 + _16410;
    uint* _16412 = &material.textureBase;
    uint _16413 = *_16412;
    uint _16414 = _16413 + 5;
    uint _16415 = CopyObject(_16414) : [[NonUniform]];
    SampledImage<float, 2D>* _16416 = &textureArray[_16415] : [[NonUniform]];
    SampledImage<float, 2D> _16417 = *_16416 : [[NonUniform]];
    float2 _16418 = *matcapUv;
    float* _16419 = &matcapTexel.x;
    float _16420 = *_16419;
    float _16421 = -_16420;
    float* _16422 = &matcapTexel.y;
    float _16423 = *_16422;
    float2 _16424 = CompositeConstruct({_16421, _16423});
    float2 _16425 = _16418 + _16424;
    float4 _16426 = ImageSampleImplicitLod(_16417, _16425);
    float _16427 = _16426.x;
    float _16428 = _16427 * 0.0750;
    float _16429 = _16411 + _16428;
    *matcapMask = _16429;
    float4 _16431 = *baseColor;
    float3 _16432 = _16431.xyz;
    float4* _16433 = &material.matcapColor;
    float4 _16434 = *_16433;
    float3 _16435 = _16434.xyz;
    float3 _16436 = CompositeConstruct({0.1000, 0.1000, 0.1000});
    float3 _16437 = GLSL.std.450::FMix(_16432, _16435, _16436);
    *matcapTint = _16437;
    float _16438 = *matcapMask;
    float3 _16439 = *matcapTint;
    float3 _16440 = _16439 * _16438;
    float* _16441 = &material.matcapColor.w;
    float _16442 = *_16441;
    float3 _16443 = _16440 * _16442;
    float* _16444 = &material.featureParameters.w;
    float _16445 = *_16444;
    float3 _16446 = _16443 * _16445;
    *param@253 = 4;
    float _16448 = materialFeatureEnabled(param@253);
    float3 _16449 = _16446 * _16448;
    float _16450 = *bandEnabled;
    float3 _16451 = _16449 * _16450;
    float3 _16452 = _16451 * 0.0550;
    *matcapAccent = _16452;
  }

  float3 _16454 = *tintedDiffuse;
  float3 _16455 = *ambientSpecular;
  float3 _16456 = _16454 + _16455;
  float3 _16457 = *directSpecular;
  float3 _16458 = _16456 + _16457;
  float3 _16459 = *rimLighting;
  float3 _16460 = _16458 + _16459;
  float3 _16461 = *kkSpecular;
  float3 _16462 = _16460 + _16461;
  float3 _16463 = *secondaryKkSpecular;
  float3 _16464 = _16462 + _16463;
  float3 _16465 = *matcapAccent;
  float3 _16466 = _16464 + _16465;
  float3 _16467 = *emissive;
  float3 _16468 = _16466 + _16467;
  *beautyColor = _16468;
  float* _16470 = &camera.qaParameters.x;
  float _16471 = *_16470;
  float _16472 = _16471 + 0.5000;
  float _16473 = GLSL.std.450::Floor(_16472);
  int _16474 = ConvertFToS(_16473);
  *qaIsolationMode = _16474;
  *sceneReflectionRadiance = {0.0000, 0.0000, 0.0000};
  float3 _16477 = *environmentResponse;
  *sceneReflectionResponse = _16477;
  SampledImage<float, 2D>* _16479 = &textureArray[0];
  SampledImage<float, 2D> _16480 = *_16479;
  float3 _16482 = *indirectDiffuseNormal;
  *param@254 = _16482;
  float2 _16483 = directionToEquirectangular(param@254);
  SampledImage<float, 2D>* _16484 = &textureArray[0];
  SampledImage<float, 2D> _16485 = *_16484;
  Image<float, 2D> _16486 = Image(_16485);
  int _16487 = ImageQueryLevels(_16486);
  int _16488 = _16487 - 1;
  float _16489 = ConvertSToF(_16488);
  float4 _16490 = ImageSampleExplicitLod(_16480, _16483, Lod(_16489));
  float3 _16491 = _16490.xyz;
  float* _16492 = &camera.clusterLighting.y;
  float _16493 = *_16492;
  float3 _16494 = _16491 * _16493;
  *reflectionDiffuseIncident = _16494;
  int _16496 = *qaEffectMode;
  bool _16497 = _16496 == 9;
  bool _16498 = *qaEffectDisabled;
  bool _16499 = _16497 && _16498;
  *overlayDisabled = _16499;
  bool _16501 = *overlayMaterial;
  bool _16502 = *overlayDisabled;
  bool _16503 = !_16502;
  bool _16504 = _16501 && _16503;
  float _16505 = Select(_16504, 1.0000, 0.0000);
  *overlayVisible = _16505;
  float3 _16506 = *beautyColor;
  float4 _16507 = *baseColor;
  float3 _16508 = _16507.xyz;
  float _16509 = *overlayVisible;
  float3 _16510 = CompositeConstruct({_16509, _16509, _16509});
  float3 _16511 = GLSL.std.450::FMix(_16506, _16508, _16510);
  *beautyColor = _16511;
  bool _16512 = *overlayMaterial;
  bool _16513 = *overlayDisabled;
  bool _16514 = _16512 && _16513;
  
  if(_16514) {
    *outputAlpha = 0.0000;
  }

  float* _16517 = &camera.clusterLighting.x;
  float _16518 = *_16517;
  bool _16519 = _16518 > 0.5000;
  
  if(_16519) {
    float* _16523 = &camera.clusterLighting.z;
    float _16524 = *_16523;
    *angle = _16524;
    float3 _16526 = *indirectDiffuseNormal;
    *envNormal = _16526;
    float3 _16528 = *reflectionDirection;
    *envReflection = _16528;
    float _16529 = *angle;
    float _16530 = GLSL.std.450::Cos(_16529);
    float _16531 = *angle;
    float _16532 = GLSL.std.450::Sin(_16531);
    float _16533 = *angle;
    float _16534 = GLSL.std.450::Sin(_16533);
    float _16535 = -_16534;
    float _16536 = *angle;
    float _16537 = GLSL.std.450::Cos(_16536);
    float2 _16538 = CompositeConstruct({_16530, _16532});
    float2 _16539 = CompositeConstruct({_16535, _16537});
    float2x2 _16540 = CompositeConstruct({_16538, _16539});
    float3 _16541 = *envNormal;
    float2 _16542 = _16541.xz;
    float2 _16543 = _16540 * _16542;
    float* _16544 = &envNormal.x;
    float _16545 = _16543.x;
    *_16544 = _16545;
    float* _16546 = &envNormal.z;
    float _16547 = _16543.y;
    *_16546 = _16547;
    float _16548 = *angle;
    float _16549 = GLSL.std.450::Cos(_16548);
    float _16550 = *angle;
    float _16551 = GLSL.std.450::Sin(_16550);
    float _16552 = *angle;
    float _16553 = GLSL.std.450::Sin(_16552);
    float _16554 = -_16553;
    float _16555 = *angle;
    float _16556 = GLSL.std.450::Cos(_16555);
    float2 _16557 = CompositeConstruct({_16549, _16551});
    float2 _16558 = CompositeConstruct({_16554, _16556});
    float2x2 _16559 = CompositeConstruct({_16557, _16558});
    float3 _16560 = *envReflection;
    float2 _16561 = _16560.xz;
    float2 _16562 = _16559 * _16561;
    float* _16563 = &envReflection.x;
    float _16564 = _16562.x;
    *_16563 = _16564;
    float* _16565 = &envReflection.z;
    float _16566 = _16562.y;
    *_16565 = _16566;
    SampledImage<float, 2D>* _16568 = &textureArray[0];
    SampledImage<float, 2D> _16569 = *_16568;
    Image<float, 2D> _16570 = Image(_16569);
    int _16571 = ImageQueryLevels(_16570);
    int _16572 = _16571 - 1;
    float _16573 = ConvertSToF(_16572);
    *lastMip = _16573;
    bool _16574 = *nprDiffuse;
    
    if(_16574) {
      float3 _16578 = *nprAmbientResponse;
      *_16575 = _16578;
    } else {
      float3 _16580 = *diffuseColor;
      float _16581 = *physicalAo;
      float3 _16582 = _16580 * _16581;
      *_16575 = _16582;
    }

    float3 _16583 = *_16575;
    SampledImage<float, 2D>* _16584 = &textureArray[0];
    SampledImage<float, 2D> _16585 = *_16584;
    float3 _16587 = *envNormal;
    *param@255 = _16587;
    float2 _16588 = directionToEquirectangular(param@255);
    float _16589 = *lastMip;
    float4 _16590 = ImageSampleExplicitLod(_16585, _16588, Lod(_16589));
    float3 _16591 = _16590.xyz;
    float3 _16592 = _16583 * _16591;
    float* _16593 = &camera.clusterLighting.y;
    float _16594 = *_16593;
    float3 _16595 = _16592 * _16594;
    *ambientDiffuse = _16595;
    SampledImage<float, 2D>* _16596 = &textureArray[0];
    SampledImage<float, 2D> _16597 = *_16596;
    float3 _16599 = *envReflection;
    *param@256 = _16599;
    float2 _16600 = directionToEquirectangular(param@256);
    float _16601 = *roughness;
    float _16602 = *lastMip;
    float _16603 = _16601 * _16602;
    float4 _16604 = ImageSampleExplicitLod(_16597, _16600, Lod(_16603));
    float3 _16605 = _16604.xyz;
    float* _16606 = &camera.clusterLighting.y;
    float _16607 = *_16606;
    float3 _16608 = _16605 * _16607;
    *sceneReflectionRadiance = _16608;
    bool _16609 = *sceneCharacter;
    
    if(_16609) {
      float* _16612 = &material.styleParameters.z;
      float _16613 = *_16612;
      float _16614 = *dielectricSpecularWeight;
      float _16615 = _16613 * _16614;
      float3 _16616 = *sceneReflectionResponse;
      float3 _16617 = _16616 * _16615;
      *sceneReflectionResponse = _16617;
    }

    int _16618 = *qaEffectMode;
    bool _16619 = _16618 == 5;
    bool _16620 = *qaEffectDisabled;
    bool _16621 = _16619 && _16620;
    
    if(_16621) {
      *sceneReflectionResponse = {0.0000, 0.0000, 0.0000};
    }

    float3 _16624 = *sceneReflectionResponse;
    float3 _16625 = *sceneReflectionRadiance;
    float3 _16626 = _16624 * _16625;
    *ambientSpecular = _16626;
    float3 _16627 = *clusteredDiffuse;
    *directDiffuse = _16627;
    float3 _16628 = *clusteredSpecular;
    *directSpecular = _16628;
    int _16629 = *qaEffectMode;
    bool _16630 = _16629 == 5;
    bool _16631 = *qaEffectDisabled;
    bool _16632 = _16630 && _16631;
    
    if(_16632) {
      *directSpecular = {0.0000, 0.0000, 0.0000};
    }

    float4 _16635 = *specularEmissive;
    float3 _16636 = _16635.xyz;
    float* _16637 = &material.emissiveStrength;
    float _16638 = *_16637;
    float3 _16639 = _16636 * _16638;
    *param@257 = 8;
    float _16641 = materialFeatureEnabled(param@257);
    float3 _16642 = _16639 * _16641;
    *emissive = _16642;
    *rimLighting = {0.0000, 0.0000, 0.0000};
    *kkSpecular = {0.0000, 0.0000, 0.0000};
    *secondaryKkSpecular = {0.0000, 0.0000, 0.0000};
    bool _16643 = *sceneCharacter;
    
    if(_16643) {
      bool _16646 = *nprDiffuse;
      bool _16647 = !_16646;
      
      if(_16647) {
        float3 _16650 = *indirectChroma;
        float3 _16651 = *ambientDiffuse;
        float3 _16652 = _16651 * _16650;
        *ambientDiffuse = _16652;
      }

      float* _16653 = &material.styleParameters.z;
      float _16654 = *_16653;
      float _16655 = *dielectricSpecularWeight;
      float _16656 = _16654 * _16655;
      float3 _16657 = *directSpecular;
      float3 _16658 = _16657 * _16656;
      *directSpecular = _16658;
      int _16659 = *qaEffectMode;
      bool _16660 = _16659 == 5;
      bool _16661 = *qaEffectDisabled;
      bool _16662 = _16660 && _16661;
      
      if(_16662) {
        *ambientSpecular = {0.0000, 0.0000, 0.0000};
        *directSpecular = {0.0000, 0.0000, 0.0000};
      }

      float3 _16665 = *sceneHairPrimary;
      float* _16666 = &material.matcapColor.w;
      float _16667 = *_16666;
      float3 _16668 = CompositeConstruct({_16667, _16667, _16667});
      float3 _16669 = GLSL.std.450::FMin(_16665, _16668);
      *kkSpecular = _16669;
      float3 _16670 = *sceneHairSecondary;
      *secondaryKkSpecular = _16670;
      float3 _16671 = *sceneRim;
      *rimLighting = _16671;
    }

    bool _16672 = *sceneCharacter;
    bool _16673 = !_16672;
    bool _16674 = *nprDiffuse;
    bool _16675 = _16673 && _16674;
    
    if(_16675) {
      float3 _16678 = *sceneRim;
      *rimLighting = _16678;
    }

    float3 _16679 = *directDiffuse;
    float3 _16680 = *directSpecular;
    float3 _16681 = _16679 + _16680;
    float3 _16682 = *ambientDiffuse;
    float3 _16683 = _16681 + _16682;
    float3 _16684 = *ambientSpecular;
    float3 _16685 = _16683 + _16684;
    float3 _16686 = *emissive;
    float3 _16687 = _16685 + _16686;
    float3 _16688 = *kkSpecular;
    float3 _16689 = _16687 + _16688;
    float3 _16690 = *secondaryKkSpecular;
    float3 _16691 = _16689 + _16690;
    float3 _16692 = *rimLighting;
    float3 _16693 = _16691 + _16692;
    *beautyColor = _16693;
    bool _16694 = *overlayMaterial;
    
    if(_16694) {
      float _16697 = *overlayVisible;
      bool _16698 = _16697 > 0.5000;
      
      if(_16698) {
        float4 _16702 = *baseColor;
        float3 _16703 = _16702.xyz;
        *_16699 = _16703;
      } else {
        *_16699 = {0.0000, 0.0000, 0.0000};
      }

      float3 _16705 = *_16699;
      *beautyColor = _16705;
    }

  }

  float* _16706 = &camera.irradianceDimensionsEnabled.w;
  float _16707 = *_16706;
  bool _16708 = _16707 > 0.5000;
  
  if(_16708) {
    bool _16712 = *nprDiffuse;
    bool _16713 = *projectedLighting;
    bool _16714 = _16712 || _16713;
    bool _16715 = *eyeNpr;
    bool _16716 = _16714 || _16715;
    bool _16717 = !_16716;
    float3 _16719 = *worldPosition;
    *param@258 = _16719;
    float3 _16721 = *indirectDiffuseNormal;
    *param@259 = _16721;
    *param@260 = _16717;
    float4 _16723 = evaluateIrradianceVolume(param@258, param@259, param@260);
    *volume = _16723;
    float3 _16724 = *reflectionDiffuseIncident;
    float4 _16725 = *volume;
    float3 _16726 = _16725.xyz;
    float* _16727 = &volume.w;
    float _16728 = *_16727;
    float3 _16729 = CompositeConstruct({_16728, _16728, _16728});
    float3 _16730 = GLSL.std.450::FMix(_16724, _16726, _16729);
    *reflectionDiffuseIncident = _16730;
    float3 _16732 = *ambientDiffuse;
    float* _16733 = &volume.w;
    float _16734 = *_16733;
    float _16735 = 1.0000 - _16734;
    float3 _16736 = _16732 * _16735;
    bool _16737 = *nprDiffuse;
    
    if(_16737) {
      float3 _16741 = *nprAmbientResponse;
      *_16738 = _16741;
    } else {
      float3 _16743 = *diffuseColor;
      float _16744 = *physicalAo;
      float3 _16745 = _16743 * _16744;
      *_16738 = _16745;
    }

    float3 _16746 = *_16738;
    float4 _16747 = *volume;
    float3 _16748 = _16747.xyz;
    float3 _16749 = _16746 * _16748;
    float3 _16750 = _16736 + _16749;
    *blended = _16750;
    float3 _16751 = *blended;
    float3 _16752 = *ambientDiffuse;
    float3 _16753 = _16751 - _16752;
    float3 _16754 = *beautyColor;
    float3 _16755 = _16754 + _16753;
    *beautyColor = _16755;
    float3 _16756 = *blended;
    *ambientDiffuse = _16756;
  }

  bool _16757 = *nprDiffuse;
  bool _16758 = *projectedLighting;
  bool _16759 = _16757 || _16758;
  bool _16760 = *eyeNpr;
  bool _16761 = _16759 || _16760;
  
  if(_16761) {
    float* _16764 = &camera.nprLightingParameters.x;
    float _16765 = *_16764;
    bool _16766 = _16765 > 0.5000;
  }

  bool _16767 = Phi(_16761, _16766);
  
  if(_16767) {
    float _16771 = *nprMainShadowVisibility;
    float* _16772 = &camera.nprGainFloor.z;
    float _16773 = *_16772;
    float _16774 = GLSL.std.450::FMix(_16771, 1.0000, _16773);
    *visibility@3 = _16774;
    float4* _16776 = &camera.nprAmbientColor;
    float4 _16777 = *_16776;
    float3 _16778 = _16777.xyz;
    *incident@2 = _16778;
    float4* _16781 = &camera.nprMainRadiance;
    float4 _16782 = *_16781;
    *mainRadiance = _16782;
    *hairShadowScale = 1.0000;
    bool _16784 = *eyeNpr;
    
    if(_16784) {
      uint* _16788 = &material.materialPadding;
      uint _16789 = *_16788;
      uint _16790 = _16789 >> 1;
      PackedMaterialSurfaceProfile* _16791 = &materialSurfaceProfiles.profiles[_16790];
      PackedMaterialSurfaceProfile _16792 = *_16791;
      float4[22] _16793 = _16792.rows;
      float4[22]* _16794 = &profile.rows;
      float4 _16795 = _16793[0];
      float4* _16796 = &_16794[0];
      *_16796 = _16795;
      float4 _16797 = _16793[1];
      float4* _16798 = &_16794[1];
      *_16798 = _16797;
      float4 _16799 = _16793[2];
      float4* _16800 = &_16794[2];
      *_16800 = _16799;
      float4 _16801 = _16793[3];
      float4* _16802 = &_16794[3];
      *_16802 = _16801;
      float4 _16803 = _16793[4];
      float4* _16804 = &_16794[4];
      *_16804 = _16803;
      float4 _16805 = _16793[5];
      float4* _16806 = &_16794[5];
      *_16806 = _16805;
      float4 _16807 = _16793[6];
      float4* _16808 = &_16794[6];
      *_16808 = _16807;
      float4 _16809 = _16793[7];
      float4* _16810 = &_16794[7];
      *_16810 = _16809;
      float4 _16811 = _16793[8];
      float4* _16812 = &_16794[8];
      *_16812 = _16811;
      float4 _16813 = _16793[9];
      float4* _16814 = &_16794[9];
      *_16814 = _16813;
      float4 _16815 = _16793[10];
      float4* _16816 = &_16794[10];
      *_16816 = _16815;
      float4 _16817 = _16793[11];
      float4* _16818 = &_16794[11];
      *_16818 = _16817;
      float4 _16819 = _16793[12];
      float4* _16820 = &_16794[12];
      *_16820 = _16819;
      float4 _16821 = _16793[13];
      float4* _16822 = &_16794[13];
      *_16822 = _16821;
      float4 _16823 = _16793[14];
      float4* _16824 = &_16794[14];
      *_16824 = _16823;
      float4 _16825 = _16793[15];
      float4* _16826 = &_16794[15];
      *_16826 = _16825;
      float4 _16827 = _16793[16];
      float4* _16828 = &_16794[16];
      *_16828 = _16827;
      float4 _16829 = _16793[17];
      float4* _16830 = &_16794[17];
      *_16830 = _16829;
      float4 _16831 = _16793[18];
      float4* _16832 = &_16794[18];
      *_16832 = _16831;
      float4 _16833 = _16793[19];
      float4* _16834 = &_16794[19];
      *_16834 = _16833;
      float4 _16835 = _16793[20];
      float4* _16836 = &_16794[20];
      *_16836 = _16835;
      float4 _16837 = _16793[21];
      float4* _16838 = &_16794[21];
      *_16838 = _16837;
      CharacterDiffuseResponse _16840 = *eyeDiffuseResponse;
      *response@3 = _16840;
      float4* _16841 = &profile.rows[7];
      float4 _16842 = *_16841;
      float3 _16843 = _16842.xyz;
      *incident@2 = _16843;
      float4* _16844 = &profile.rows[8];
      float4 _16845 = *_16844;
      float3 _16846 = _16845.xyz;
      float* _16847 = &mainRadiance.x;
      float _16848 = _16846.x;
      *_16847 = _16848;
      float* _16849 = &mainRadiance.y;
      float _16850 = _16846.y;
      *_16849 = _16850;
      float* _16851 = &mainRadiance.z;
      float _16852 = _16846.z;
      *_16851 = _16852;
    } else {
      bool _16854 = *projectedLighting;
      
      if(_16854) {
        uint* _16858 = &material.materialPadding;
        uint _16859 = *_16858;
        uint _16860 = _16859 >> 1;
        PackedMaterialSurfaceProfile* _16861 = &materialSurfaceProfiles.profiles[_16860];
        PackedMaterialSurfaceProfile _16862 = *_16861;
        float4[22] _16863 = _16862.rows;
        float4[22]* _16864 = &profile@2.rows;
        float4 _16865 = _16863[0];
        float4* _16866 = &_16864[0];
        *_16866 = _16865;
        float4 _16867 = _16863[1];
        float4* _16868 = &_16864[1];
        *_16868 = _16867;
        float4 _16869 = _16863[2];
        float4* _16870 = &_16864[2];
        *_16870 = _16869;
        float4 _16871 = _16863[3];
        float4* _16872 = &_16864[3];
        *_16872 = _16871;
        float4 _16873 = _16863[4];
        float4* _16874 = &_16864[4];
        *_16874 = _16873;
        float4 _16875 = _16863[5];
        float4* _16876 = &_16864[5];
        *_16876 = _16875;
        float4 _16877 = _16863[6];
        float4* _16878 = &_16864[6];
        *_16878 = _16877;
        float4 _16879 = _16863[7];
        float4* _16880 = &_16864[7];
        *_16880 = _16879;
        float4 _16881 = _16863[8];
        float4* _16882 = &_16864[8];
        *_16882 = _16881;
        float4 _16883 = _16863[9];
        float4* _16884 = &_16864[9];
        *_16884 = _16883;
        float4 _16885 = _16863[10];
        float4* _16886 = &_16864[10];
        *_16886 = _16885;
        float4 _16887 = _16863[11];
        float4* _16888 = &_16864[11];
        *_16888 = _16887;
        float4 _16889 = _16863[12];
        float4* _16890 = &_16864[12];
        *_16890 = _16889;
        float4 _16891 = _16863[13];
        float4* _16892 = &_16864[13];
        *_16892 = _16891;
        float4 _16893 = _16863[14];
        float4* _16894 = &_16864[14];
        *_16894 = _16893;
        float4 _16895 = _16863[15];
        float4* _16896 = &_16864[15];
        *_16896 = _16895;
        float4 _16897 = _16863[16];
        float4* _16898 = &_16864[16];
        *_16898 = _16897;
        float4 _16899 = _16863[17];
        float4* _16900 = &_16864[17];
        *_16900 = _16899;
        float4 _16901 = _16863[18];
        float4* _16902 = &_16864[18];
        *_16902 = _16901;
        float4 _16903 = _16863[19];
        float4* _16904 = &_16864[19];
        *_16904 = _16903;
        float4 _16905 = _16863[20];
        float4* _16906 = &_16864[20];
        *_16906 = _16905;
        float4 _16907 = _16863[21];
        float4* _16908 = &_16864[21];
        *_16908 = _16907;
        float* _16909 = &profile@2.rows[5].w;
        float _16910 = *_16909;
        *hairShadowScale = _16910;
        CharacterDiffuseResponse _16911 = *hairDiffuseResponse;
        *response@3 = _16911;
        float4* _16912 = &profile@2.rows[10];
        float4 _16913 = *_16912;
        float3 _16914 = _16913.xyz;
        *incident@2 = _16914;
        float4* _16915 = &profile@2.rows[11];
        float4 _16916 = *_16915;
        float3 _16917 = _16916.xyz;
        float* _16918 = &mainRadiance.x;
        float _16919 = _16917.x;
        *_16918 = _16919;
        float* _16920 = &mainRadiance.y;
        float _16921 = _16917.y;
        *_16920 = _16921;
        float* _16922 = &mainRadiance.z;
        float _16923 = _16917.z;
        *_16922 = _16923;
      } else {
        float4 _16926 = *baseColor;
        *param@261 = _16926;
        float _16928 = *metallic;
        *param@262 = _16928;
        float4 _16930 = *classRampRgba;
        *param@263 = _16930;
        float _16932 = *nprBaseAo;
        *param@264 = _16932;
        float _16934 = *visibility@3;
        *param@265 = _16934;
        float _16936 = *nprMainShadowVisibility;
        *param@266 = _16936;
        float3 _16938 = *shadedNormal;
        *param@267 = _16938;
        float3 _16940 = *viewDirection;
        *param@268 = _16940;
        CharacterDiffuseResponse _16941 = materialNprDiffuseResponse(param@261, param@262, param@263, param@264, param@265, param@266, param@267, param@268);
        *response@3 = _16941;
        uint* _16943 = &material.materialPadding;
        uint _16944 = *_16943;
        uint _16945 = _16944 >> 1;
        PackedMaterialSurfaceProfile* _16946 = &materialSurfaceProfiles.profiles[_16945];
        PackedMaterialSurfaceProfile _16947 = *_16946;
        float4[22] _16948 = _16947.rows;
        float4[22]* _16949 = &profile@3.rows;
        float4 _16950 = _16948[0];
        float4* _16951 = &_16949[0];
        *_16951 = _16950;
        float4 _16952 = _16948[1];
        float4* _16953 = &_16949[1];
        *_16953 = _16952;
        float4 _16954 = _16948[2];
        float4* _16955 = &_16949[2];
        *_16955 = _16954;
        float4 _16956 = _16948[3];
        float4* _16957 = &_16949[3];
        *_16957 = _16956;
        float4 _16958 = _16948[4];
        float4* _16959 = &_16949[4];
        *_16959 = _16958;
        float4 _16960 = _16948[5];
        float4* _16961 = &_16949[5];
        *_16961 = _16960;
        float4 _16962 = _16948[6];
        float4* _16963 = &_16949[6];
        *_16963 = _16962;
        float4 _16964 = _16948[7];
        float4* _16965 = &_16949[7];
        *_16965 = _16964;
        float4 _16966 = _16948[8];
        float4* _16967 = &_16949[8];
        *_16967 = _16966;
        float4 _16968 = _16948[9];
        float4* _16969 = &_16949[9];
        *_16969 = _16968;
        float4 _16970 = _16948[10];
        float4* _16971 = &_16949[10];
        *_16971 = _16970;
        float4 _16972 = _16948[11];
        float4* _16973 = &_16949[11];
        *_16973 = _16972;
        float4 _16974 = _16948[12];
        float4* _16975 = &_16949[12];
        *_16975 = _16974;
        float4 _16976 = _16948[13];
        float4* _16977 = &_16949[13];
        *_16977 = _16976;
        float4 _16978 = _16948[14];
        float4* _16979 = &_16949[14];
        *_16979 = _16978;
        float4 _16980 = _16948[15];
        float4* _16981 = &_16949[15];
        *_16981 = _16980;
        float4 _16982 = _16948[16];
        float4* _16983 = &_16949[16];
        *_16983 = _16982;
        float4 _16984 = _16948[17];
        float4* _16985 = &_16949[17];
        *_16985 = _16984;
        float4 _16986 = _16948[18];
        float4* _16987 = &_16949[18];
        *_16987 = _16986;
        float4 _16988 = _16948[19];
        float4* _16989 = &_16949[19];
        *_16989 = _16988;
        float4 _16990 = _16948[20];
        float4* _16991 = &_16949[20];
        *_16991 = _16990;
        float4 _16992 = _16948[21];
        float4* _16993 = &_16949[21];
        *_16993 = _16992;
        float* _16994 = &profile@3.rows[10].w;
        float _16995 = *_16994;
        bool _16996 = _16995 > 0.5000;
        
        if(_16996) {
          float4* _16999 = &profile@3.rows[10];
          float4 _17000 = *_16999;
          float3 _17001 = _17000.xyz;
          *incident@2 = _17001;
          float4* _17002 = &profile@3.rows[11];
          float4 _17003 = *_17002;
          float3 _17004 = _17003.xyz;
          float* _17005 = &mainRadiance.x;
          float _17006 = _17004.x;
          *_17005 = _17006;
          float* _17007 = &mainRadiance.y;
          float _17008 = _17004.y;
          *_17007 = _17008;
          float* _17009 = &mainRadiance.z;
          float _17010 = _17004.z;
          *_17009 = _17010;
        }

      }

    }

    float* _17011 = &camera.nprGainFloor.w;
    float _17012 = *_17011;
    bool _17013 = _17012 > 0.5000;
    
    if(_17013) {
      float3 _17017 = *indirectDiffuseNormal;
      *envNormal@2 = _17017;
      float* _17019 = &camera.clusterLighting.z;
      float _17020 = *_17019;
      *angle@2 = _17020;
      float _17021 = *angle@2;
      float _17022 = GLSL.std.450::Cos(_17021);
      float _17023 = *angle@2;
      float _17024 = GLSL.std.450::Sin(_17023);
      float _17025 = *angle@2;
      float _17026 = GLSL.std.450::Sin(_17025);
      float _17027 = -_17026;
      float _17028 = *angle@2;
      float _17029 = GLSL.std.450::Cos(_17028);
      float2 _17030 = CompositeConstruct({_17022, _17024});
      float2 _17031 = CompositeConstruct({_17027, _17029});
      float2x2 _17032 = CompositeConstruct({_17030, _17031});
      float3 _17033 = *envNormal@2;
      float2 _17034 = _17033.xz;
      float2 _17035 = _17032 * _17034;
      float* _17036 = &envNormal@2.x;
      float _17037 = _17035.x;
      *_17036 = _17037;
      float* _17038 = &envNormal@2.z;
      float _17039 = _17035.y;
      *_17038 = _17039;
      SampledImage<float, 2D>* _17040 = &textureArray[0];
      SampledImage<float, 2D> _17041 = *_17040;
      float3 _17043 = *envNormal@2;
      *param@269 = _17043;
      float2 _17044 = directionToEquirectangular(param@269);
      SampledImage<float, 2D>* _17045 = &textureArray[0];
      SampledImage<float, 2D> _17046 = *_17045;
      Image<float, 2D> _17047 = Image(_17046);
      int _17048 = ImageQueryLevels(_17047);
      int _17049 = _17048 - 1;
      float _17050 = ConvertSToF(_17049);
      float4 _17051 = ImageSampleExplicitLod(_17041, _17044, Lod(_17050));
      float3 _17052 = _17051.xyz;
      float* _17053 = &camera.clusterLighting.y;
      float _17054 = *_17053;
      float3 _17055 = _17052 * _17054;
      *incident@2 = _17055;
      float* _17056 = &camera.irradianceDimensionsEnabled.w;
      float _17057 = *_17056;
      bool _17058 = _17057 > 0.5000;
      
      if(_17058) {
        float3 _17063 = *worldPosition;
        *param@270 = _17063;
        float3 _17065 = *indirectDiffuseNormal;
        *param@271 = _17065;
        *param@272 = false;
        float4 _17067 = evaluateIrradianceVolume(param@270, param@271, param@272);
        *volume@2 = _17067;
        float3 _17068 = *incident@2;
        float4 _17069 = *volume@2;
        float3 _17070 = _17069.xyz;
        float* _17071 = &volume@2.w;
        float _17072 = *_17071;
        float3 _17073 = CompositeConstruct({_17072, _17072, _17072});
        float3 _17074 = GLSL.std.450::FMix(_17068, _17070, _17073);
        *incident@2 = _17074;
      }

    }

    float _17076 = *physicalAo;
    float* _17077 = &camera.nprLightingParameters.z;
    float _17078 = *_17077;
    float _17079 = _17076 * _17078;
    float3 _17081 = *indirectDiffuseNormal;
    *param@273 = _17081;
    float3 _17083 = *incident@2;
    *param@274 = _17083;
    float4 _17085 = *mainRadiance;
    *param@275 = _17085;
    float4* _17087 = &camera.nprDirectionBias;
    float4 _17088 = *_17087;
    *param@276 = _17088;
    float4* _17090 = &camera.nprGainFloor;
    float4 _17091 = *_17090;
    *param@277 = _17091;
    float4* _17093 = &camera.nprComposition;
    float4 _17094 = *_17093;
    *param@278 = _17094;
    float* _17096 = &camera.nprAmbientColor.w;
    float _17097 = *_17096;
    *param@279 = _17097;
    *param@280 = _17079;
    float* _17100 = &response@3.litMask;
    float _17101 = *_17100;
    *param@281 = _17101;
    float _17103 = *visibility@3;
    *param@282 = _17103;
    CharacterDiffuseIllumination _17104 = characterDiffuseIllumination(param@273, param@274, param@275, param@276, param@277, param@278, param@279, param@280, param@281, param@282);
    *illumination@2 = _17104;
    float3* _17106 = &response@3.color;
    float3 _17107 = *_17106;
    float3* _17108 = &illumination@2.ambient;
    float3 _17109 = *_17108;
    float3 _17110 = _17107 * _17109;
    *combinedAmbient = _17110;
    float3* _17112 = &response@3.color;
    float3 _17113 = *_17112;
    float3* _17114 = &illumination@2.direct;
    float3 _17115 = *_17114;
    float3 _17116 = _17113 * _17115;
    float3 _17117 = *clusteredDiffuse;
    float3 _17118 = _17116 + _17117;
    bool _17119 = *projectedLighting;
    float3 _17120 = *sceneMainDiffuse;
    bool _17121 = CompositeConstruct({_17119, _17119, _17119});
    float3 _17122 = Select(_17121, _17120, {0.0000, 0.0000, 0.0000});
    float3 _17123 = _17118 - _17122;
    *combinedDirect = _17123;
    bool _17124 = *eyeNpr;
    
    if(_17124) {
      float _17127 = *eyeAlphaMultiplier;
      float3 _17128 = *combinedAmbient;
      float3 _17129 = _17128 * _17127;
      *combinedAmbient = _17129;
      float3* _17131 = &response@3.color;
      float3 _17132 = *_17131;
      float3* _17133 = &illumination@2.direct;
      float3 _17134 = *_17133;
      float3 _17135 = _17132 * _17134;
      float _17136 = *eyeAlphaMultiplier;
      float3 _17137 = _17135 * _17136;
      *eyeMainDirect = _17137;
      float3* _17138 = &illumination@2.ambient;
      float3 _17139 = *_17138;
      float3* _17140 = &illumination@2.direct;
      float3 _17141 = *_17140;
      float3 _17142 = _17139 + _17141;
      float4 _17144 = *eyeMatcap;
      *param@283 = _17144;
      float4* _17146 = &eyeProfile.matcap;
      float4 _17147 = *_17146;
      *param@284 = _17147;
      float _17149 = *eyeViewRampAlpha;
      *param@285 = _17149;
      float* _17151 = &classRampRgba.w;
      float _17152 = *_17151;
      *param@286 = _17152;
      float _17154 = *visibility@3;
      *param@287 = _17154;
      float* _17156 = &eyeProfile.shape.w;
      float _17157 = *_17156;
      *param@288 = _17157;
      *param@289 = _17142;
      float3 _17159 = characterEyeMatcap(param@283, param@284, param@285, param@286, param@287, param@288, param@289);
      float* _17160 = &eyeCoordinates.whiteMask;
      float _17161 = *_17160;
      float _17162 = 1.0000 - _17161;
      float3 _17163 = _17159 * _17162;
      *eyeHostMatcap = _17163;
      float3 _17165 = *combinedAmbient;
      float3 _17166 = *eyeMainDirect;
      float3 _17167 = _17165 + _17166;
      float3 _17168 = *eyeHostMatcap;
      float3 _17169 = _17167 + _17168;
      *param@290 = _17169;
      float _17171 = characterEyeMainSaturation(param@290);
      *saturation = _17171;
      float3 _17173 = *combinedAmbient;
      *param@291 = _17173;
      float _17175 = *saturation;
      *param@292 = _17175;
      float3 _17176 = characterDiffuseSaturation(param@291, param@292);
      *combinedAmbient = _17176;
      float3 _17178 = *eyeMainDirect;
      *param@293 = _17178;
      float _17180 = *saturation;
      *param@294 = _17180;
      float3 _17181 = characterDiffuseSaturation(param@293, param@294);
      float3 _17182 = *clusteredDiffuse;
      float _17183 = *eyeAlphaMultiplier;
      float3 _17184 = _17182 * _17183;
      float3 _17185 = _17181 + _17184;
      *combinedDirect = _17185;
      float3 _17187 = *eyeHostMatcap;
      *param@295 = _17187;
      float _17189 = *saturation;
      *param@296 = _17189;
      float3 _17190 = characterDiffuseSaturation(param@295, param@296);
      *eyeHostMatcap = _17190;
    }

    float3* _17191 = &response@3.color;
    float3 _17192 = *_17191;
    float3* _17193 = &illumination@2.direct;
    float3 _17194 = *_17193;
    float3 _17195 = _17192 * _17194;
    *sceneMainDiffuse = _17195;
    float3 _17196 = *combinedAmbient;
    float3 _17197 = *combinedDirect;
    float3 _17198 = _17196 + _17197;
    float3 _17199 = *ambientDiffuse;
    float3 _17200 = _17198 - _17199;
    float3 _17201 = *directDiffuse;
    float3 _17202 = _17200 - _17201;
    float3 _17203 = *beautyColor;
    float3 _17204 = _17203 + _17202;
    *beautyColor = _17204;
    float3 _17205 = *combinedAmbient;
    *ambientDiffuse = _17205;
    float3 _17206 = *combinedDirect;
    *directDiffuse = _17206;
    bool _17207 = *specularRamp;
    
    if(_17207) {
      int _17210 = *qaEffectMode;
      bool _17211 = _17210 == 5;
      bool _17212 = *qaEffectDisabled;
      bool _17213 = _17211 && _17212;
      bool _17214 = !_17213;
    }

    bool _17215 = Phi(_17207, _17214);
    
    if(_17215) {
      uint* _17219 = &material.textureBase;
      uint _17220 = *_17219;
      uint _17221 = _17220 + 4;
      uint _17222 = CopyObject(_17221) : [[NonUniform]];
      SampledImage<float, 2D>* _17223 = &textureArray[_17222] : [[NonUniform]];
      SampledImage<float, 2D> _17224 = *_17223 : [[NonUniform]];
      float4* _17225 = &camera.cameraForward;
      float4 _17226 = *_17225;
      float3 _17227 = _17226.xyz;
      float3 _17228 = -_17227;
      float3 _17230 = *shadedNormal;
      *param@297 = _17230;
      *param@298 = _17228;
      float _17232 = specularRampDot(param@297, param@298);
      float _17233 = _17232 * 0.5000;
      float _17234 = _17233 + 0.5000;
      float2 _17235 = CompositeConstruct({_17234, 0.5000});
      float4 _17236 = ImageSampleExplicitLod(_17224, _17235, Lod(0.0000));
      float _17237 = _17236.w;
      *viewAlpha = _17237;
      float _17240 = *viewAlpha;
      *param@299 = _17240;
      float* _17242 = &response@3.aoMask;
      float _17243 = *_17242;
      *param@300 = _17243;
      float* _17245 = &response@3.litMask;
      float _17246 = *_17245;
      *param@301 = _17246;
      float _17248 = *visibility@3;
      *param@302 = _17248;
      float _17249 = specularRampFullDiffuse(param@299, param@300, param@301, param@302);
      *fullDiffuse = _17249;
      float3* _17251 = &illumination@2.ambient;
      float3 _17252 = *_17251;
      float3* _17253 = &illumination@2.direct;
      float3 _17254 = *_17253;
      float3 _17255 = _17252 + _17254;
      float* _17256 = &mainRadiance.w;
      float _17257 = *_17256;
      bool _17258 = _17257 > 0.0000;
      int _17259 = Select(_17258, 1, 0);
      float _17260 = ConvertSToF(_17259);
      float _17261 = _17255.x;
      float _17262 = _17255.y;
      float _17263 = _17255.z;
      float4 _17264 = CompositeConstruct({_17261, _17262, _17263, _17260});
      *rampIllumination = _17264;
      float3 _17267 = *rampReflectance;
      *param@303 = _17267;
      float3 _17269 = *rampSample;
      *param@304 = _17269;
      float _17271 = *rampSpecularLobe;
      *param@305 = _17271;
      float _17273 = *fullDiffuse;
      *param@306 = _17273;
      float4 _17275 = *rampIllumination;
      *param@307 = _17275;
      float* _17277 = &camera.nprLightingParameters.w;
      float _17278 = *_17277;
      *param@308 = _17278;
      float3 _17279 = specularRampMain(param@303, param@304, param@305, param@306, param@307, param@308);
      float* _17280 = &material.styleParameters.z;
      float _17281 = *_17280;
      float3 _17282 = _17279 * _17281;
      float _17283 = *dielectricSpecularWeight;
      float3 _17284 = _17282 * _17283;
      *mainSpecular = _17284;
      float3 _17285 = *mainSpecular;
      float3 _17286 = *directSpecular;
      float3 _17287 = _17286 + _17285;
      *directSpecular = _17287;
      float3 _17288 = *mainSpecular;
      float3 _17289 = *beautyColor;
      float3 _17290 = _17289 + _17288;
      *beautyColor = _17290;
    }

    bool _17291 = *projectedLighting;
    
    if(_17291) {
      float _17295 = *hairViewAlpha;
      float* _17296 = &response@3.aoMask;
      float _17297 = *_17296;
      float _17298 = _17295 * _17297;
      float* _17299 = &response@3.litMask;
      float _17300 = *_17299;
      float _17301 = *visibility@3;
      float _17302 = GLSL.std.450::FMix(_17298, _17300, _17301);
      *weight@2 = _17302;
      float _17304 = *hairShadowScale;
      float _17305 = *weight@2;
      float _17306 = GLSL.std.450::FMix(_17304, 1.0000, _17305);
      float _17307 = *weight@2;
      float _17308 = 0.5000 * _17307;
      float _17309 = 0.5000 + _17308;
      float _17310 = _17306 * _17309;
      *scale = _17310;
      float3* _17312 = &illumination@2.ambient;
      float3 _17313 = *_17312;
      float3* _17314 = &illumination@2.direct;
      float3 _17315 = *_17314;
      float3 _17316 = _17313 + _17315;
      float _17317 = *scale;
      float3 _17318 = _17316 * _17317;
      float* _17319 = &material.featureParameters.y;
      float _17320 = *_17319;
      float3 _17321 = _17318 * _17320;
      *specularIllumination = _17321;
      float3 _17323 = *mainHairPrimary;
      float3 _17324 = *specularIllumination;
      float3 _17325 = _17323 * _17324;
      *primaryMain = _17325;
      float3 _17327 = *mainHairSecondary;
      float3 _17328 = *specularIllumination;
      float3 _17329 = _17327 * _17328;
      *secondaryMain = _17329;
      
      if(false) {
        uint* _17332 = &material.materialFeatures;
        uint _17333 = *_17332;
        uint _17335 = _17333 & _17334;
        uint _17336 = _17335 | azureFixedMaterialFeatureValue;
        *param@309 = azureOrdinaryOpaque;
        *param@310 = _17336;
        uint _17339 = azureSpecializedMaterialFeatures(param@309, param@310);
        uint _17340 = _17339 & 8388608;
        bool _17341 = _17340 != 0;
      }

      bool _17342 = Phi(false, _17341);
      bool _17343 = *mainHairAvailable;
      bool _17344 = _17342 && _17343;
      
      if(_17344) {
        float3 _17348 = *incident@2;
        float _17349 = *visibility@3;
        float4 _17350 = CompositeConstruct({3.0000, 0.0000, 0.0000, _17349});
        float4 _17351 = *mainRadiance;
        float _17352 = *physicalAo;
        float _17353 = *projectedVisibility;
        ProjectedHairIncident _17354 = CompositeConstruct({_17348, _17350, _17351, 1.0000, _17352, _17353});
        *sampleLighting = _17354;
        float3 _17358 = *viewDirection;
        *param@311 = _17358;
        float3 _17360 = *lightDirection;
        *param@312 = _17360;
        *param@313 = true;
        *param@314 = false;
        ProjectedHairIncident _17364 = *sampleLighting;
        *param@315 = _17364;
        CharacterProjectedHairEnergy _17366 = projectedHairResponseWeighted(param@311, param@312, param@313, param@314, param@315, param@316);
        float2 _17367 = *param@316;
        *unusedLine@2 = _17367;
        *energy@4 = _17366;
        float3* _17368 = &energy@4.primary;
        float3 _17369 = *_17368;
        *primaryMain = _17369;
        float3* _17370 = &energy@4.secondary;
        float3 _17371 = *_17370;
        *secondaryMain = _17371;
      }

      float3 _17373 = *sceneHairPrimary;
      float3 _17374 = *primaryMain;
      float3 _17375 = _17373 + _17374;
      float* _17376 = &material.matcapColor.w;
      float _17377 = *_17376;
      float3 _17378 = CompositeConstruct({_17377, _17377, _17377});
      float3 _17379 = GLSL.std.450::FMin(_17375, _17378);
      *primary = _17379;
      float3 _17381 = *sceneHairSecondary;
      float3 _17382 = *secondaryMain;
      float3 _17383 = _17381 + _17382;
      *secondary = _17383;
      uint _17384 = *projectedHairFlags;
      uint _17385 = _17384 & 8;
      bool _17386 = _17385 != 0;
      
      if(_17386) {
        float3 _17389 = *primaryMain;
        float* _17390 = &material.matcapColor.w;
        float _17391 = *_17390;
        float3 _17392 = CompositeConstruct({_17391, _17391, _17391});
        float3 _17393 = GLSL.std.450::FMin(_17389, _17392);
        *mainHairPrimary = _17393;
        float3 _17394 = *secondaryMain;
        *mainHairSecondary = _17394;
      }

      float3 _17395 = *primary;
      float3 _17396 = *secondary;
      float3 _17397 = _17395 + _17396;
      float3 _17398 = *kkSpecular;
      float3 _17399 = _17397 - _17398;
      float3 _17400 = *secondaryKkSpecular;
      float3 _17401 = _17399 - _17400;
      float3 _17402 = *beautyColor;
      float3 _17403 = _17402 + _17401;
      *beautyColor = _17403;
      float3 _17404 = *primary;
      *kkSpecular = _17404;
      float3 _17405 = *secondary;
      *secondaryKkSpecular = _17405;
    }

  }

  bool _17406 = *projectedHair;
  
  if(_17406) {
    uint* _17409 = &material.materialPadding;
    uint _17410 = *_17409;
    uint _17411 = _17410 >> 1;
    float* _17412 = &materialSurfaceProfiles.profiles[_17411].rows[8].z;
    float _17413 = *_17412;
    bool _17414 = _17413 > 0.5000;
  }

  bool _17415 = Phi(_17406, _17414);
  
  if(_17415) {
    float* _17418 = &camera.clusterLighting.x;
    float _17419 = *_17418;
    bool _17420 = _17419 < 0.5000;
    bool _17421 = !_17420;
    
    if(_17421) {
      float* _17424 = &camera.mainLightDirection.w;
      float _17425 = *_17424;
      bool _17426 = _17425 > 0.5000;
    }

    bool _17427 = Phi(_17420, _17426);
  }

  bool _17428 = Phi(_17415, _17427);
  
  if(_17428) {
    float3 _17433 = *viewDirection;
    *param@317 = _17433;
    float3 _17435 = *lightDirection;
    *param@318 = _17435;
    *param@319 = true;
    *param@320 = true;
    CharacterProjectedHairEnergy _17439 = projectedHairResponse(param@317, param@318, param@319, param@320, param@321);
    float2 _17440 = *param@321;
    *line@2 = _17440;
    float3 _17442 = *ambientDiffuse;
    float* _17443 = &line@2.x;
    float _17444 = *_17443;
    float3 _17445 = _17442 * _17444;
    *dark = _17445;
    float3 _17447 = *dark;
    float _17448 = Dot(_17447, {0.2127, 0.7152, 0.0722});
    float3 _17449 = CompositeConstruct({_17448, _17448, _17448});
    float3 _17450 = *dark;
    float* _17451 = &line@2.y;
    float _17452 = *_17451;
    float3 _17453 = CompositeConstruct({_17452, _17452, _17452});
    float3 _17454 = GLSL.std.450::FMix(_17449, _17450, _17453);
    *adjusted = _17454;
    float3 _17455 = *adjusted;
    float3 _17456 = *ambientDiffuse;
    float3 _17457 = _17455 - _17456;
    float3 _17458 = *beautyColor;
    float3 _17459 = _17458 + _17457;
    *beautyColor = _17459;
    float3 _17460 = *adjusted;
    *ambientDiffuse = _17460;
    uint* _17461 = &material.materialPadding;
    uint _17462 = *_17461;
    uint _17463 = _17462 >> 1;
    float* _17464 = &materialSurfaceProfiles.profiles[_17463].rows[8].w;
    float _17465 = *_17464;
    bool _17466 = _17465 > 0.5000;
    
    if(_17466) {
      float* _17470 = &camera.clusterLighting.x;
      float _17471 = *_17470;
      bool _17472 = _17471 > 0.5000;
      float3 _17473 = *sceneMainDiffuse;
      float3 _17474 = *directDiffuse;
      bool _17475 = CompositeConstruct({_17472, _17472, _17472});
      float3 _17476 = Select(_17475, _17473, _17474);
      *mainDiffuse = _17476;
      float3 _17478 = *mainDiffuse;
      float* _17479 = &line@2.x;
      float _17480 = *_17479;
      float3 _17481 = _17478 * _17480;
      *param@322 = _17481;
      float* _17484 = &line@2.y;
      float _17485 = *_17484;
      *param@323 = _17485;
      float3 _17486 = characterDiffuseSaturation(param@322, param@323);
      *adjustedMain = _17486;
      float3 _17487 = *adjustedMain;
      *sceneMainDiffuse = _17487;
      float3 _17489 = *adjustedMain;
      float3 _17490 = *mainDiffuse;
      float3 _17491 = _17489 - _17490;
      *difference = _17491;
      float3 _17492 = *difference;
      float3 _17493 = *directDiffuse;
      float3 _17494 = _17493 + _17492;
      *directDiffuse = _17494;
      float3 _17495 = *difference;
      float3 _17496 = *beautyColor;
      float3 _17497 = _17496 + _17495;
      *beautyColor = _17497;
    }

  }

  bool _17498 = *projectedLighting;
  
  if(_17498) {
    uint _17501 = *projectedHairFlags;
    uint _17502 = _17501 & 8;
    bool _17503 = _17502 != 0;
  }

  bool _17504 = Phi(_17498, _17503);
  
  if(_17504) {
    float* _17507 = &camera.nprLightingParameters.x;
    float _17508 = *_17507;
    bool _17509 = _17508 > 0.5000;
  }

  bool _17510 = Phi(_17504, _17509);
  
  if(_17510) {
    float3 _17514 = *ambientDiffuse;
    float3 _17515 = *sceneMainDiffuse;
    float3 _17516 = _17514 + _17515;
    float3 _17517 = *mainHairPrimary;
    float3 _17518 = _17516 + _17517;
    float3 _17519 = *mainHairSecondary;
    float3 _17520 = _17518 + _17519;
    *mainColor = _17520;
    float3 _17523 = *mainColor;
    *param@324 = _17523;
    float _17524 = characterMainBrightnessSaturation(param@324);
    *saturation@2 = _17524;
    float3 _17526 = *mainColor;
    *param@325 = _17526;
    float _17528 = *saturation@2;
    *param@326 = _17528;
    float3 _17529 = characterDiffuseSaturation(param@325, param@326);
    float3 _17530 = *mainColor;
    float3 _17531 = _17529 - _17530;
    float3 _17532 = *beautyColor;
    float3 _17533 = _17532 + _17531;
    *beautyColor = _17533;
    float3 _17536 = *sceneMainDiffuse;
    *param@327 = _17536;
    float _17538 = *saturation@2;
    *param@328 = _17538;
    float3 _17539 = characterDiffuseSaturation(param@327, param@328);
    *adjustedMain@2 = _17539;
    float3 _17542 = *mainHairPrimary;
    *param@329 = _17542;
    float _17544 = *saturation@2;
    *param@330 = _17544;
    float3 _17545 = characterDiffuseSaturation(param@329, param@330);
    *adjustedPrimary = _17545;
    float3 _17548 = *mainHairSecondary;
    *param@331 = _17548;
    float _17550 = *saturation@2;
    *param@332 = _17550;
    float3 _17551 = characterDiffuseSaturation(param@331, param@332);
    *adjustedSecondary = _17551;
    float3 _17553 = *ambientDiffuse;
    *param@333 = _17553;
    float _17555 = *saturation@2;
    *param@334 = _17555;
    float3 _17556 = characterDiffuseSaturation(param@333, param@334);
    *ambientDiffuse = _17556;
    float3 _17557 = *adjustedMain@2;
    float3 _17558 = *sceneMainDiffuse;
    float3 _17559 = _17557 - _17558;
    float3 _17560 = *directDiffuse;
    float3 _17561 = _17560 + _17559;
    *directDiffuse = _17561;
    float3 _17562 = *adjustedPrimary;
    float3 _17563 = *mainHairPrimary;
    float3 _17564 = _17562 - _17563;
    float3 _17565 = *kkSpecular;
    float3 _17566 = _17565 + _17564;
    *kkSpecular = _17566;
    float3 _17567 = *adjustedSecondary;
    float3 _17568 = *mainHairSecondary;
    float3 _17569 = _17567 - _17568;
    float3 _17570 = *secondaryKkSpecular;
    float3 _17571 = _17570 + _17569;
    *secondaryKkSpecular = _17571;
  }

  float* _17573 = &camera.probeParameters.x;
  float _17574 = *_17573;
  bool _17575 = _17574 > 0.5000;
  
  if(_17575) {
    SampledImage<float, 2DArray> _17580 = *reflectionProbeTexture;
    Image<float, 2DArray> _17581 = Image(_17580);
    int _17582 = ImageQueryLevels(_17581);
    int _17583 = _17582 - 1;
    float _17584 = ConvertSToF(_17583);
    *lastMip@2 = _17584;
    float* _17586 = &camera.probeCenter.w;
    float _17587 = *_17586;
    float* _17588 = &camera.probeHalfExtents.w;
    float _17589 = *_17588;
    float* _17590 = &camera.probeCapture.w;
    float _17591 = *_17590;
    float3 _17592 = CompositeConstruct({_17587, _17589, _17591});
    float _17594 = *roughness;
    *param@335 = _17594;
    float _17596 = *lastMip@2;
    *param@336 = _17596;
    *param@337 = _17592;
    float _17598 = reflectionProbeLod(param@335, param@336, param@337);
    *lod = _17598;
    float3 _17600 = *reflectionDiffuseIncident;
    float _17601 = Dot(_17600, {0.2127, 0.7152, 0.0722});
    float3 _17603 = *worldPosition;
    *param@338 = _17603;
    float3 _17605 = *reflectionDirection;
    *param@339 = _17605;
    float3 _17607 = *indirectDiffuseNormal;
    *param@340 = _17607;
    *param@341 = _17601;
    float _17610 = *lod;
    *param@342 = _17610;
    float4 _17611 = reflectionProbeFieldRadiance(reflectionProbeTexture, param@338, param@339, param@340, param@341, param@342);
    float3 _17612 = _17611.xyz;
    *radiance@2 = _17612;
    float3 _17613 = *radiance@2;
    *sceneReflectionRadiance = _17613;
    float3 _17615 = *environmentResponse;
    float3 _17616 = *radiance@2;
    float3 _17617 = _17615 * _17616;
    *blended@2 = _17617;
    bool _17618 = *sceneCharacter;
    
    if(_17618) {
      float* _17621 = &material.styleParameters.z;
      float _17622 = *_17621;
      float _17623 = *dielectricSpecularWeight;
      float _17624 = _17622 * _17623;
      float3 _17625 = *blended@2;
      float3 _17626 = _17625 * _17624;
      *blended@2 = _17626;
    }

    int _17627 = *qaEffectMode;
    bool _17628 = _17627 == 5;
    bool _17629 = *qaEffectDisabled;
    bool _17630 = _17628 && _17629;
    
    if(_17630) {
      *blended@2 = {0.0000, 0.0000, 0.0000};
    }

    float* _17633 = &camera.clusterLighting.x;
    float _17634 = *_17633;
    bool _17635 = _17634 > 0.5000;
    
    if(_17635) {
      float3 _17638 = *sceneReflectionResponse;
      float3 _17639 = *radiance@2;
      float3 _17640 = _17638 * _17639;
      *blended@2 = _17640;
    }

    float3 _17641 = *blended@2;
    float3 _17642 = *ambientSpecular;
    float3 _17643 = _17641 - _17642;
    float3 _17644 = *beautyColor;
    float3 _17645 = _17644 + _17643;
    *beautyColor = _17645;
    float3 _17646 = *blended@2;
    *ambientSpecular = _17646;
  }

  float* _17647 = &camera.clusterLighting.x;
  float _17648 = *_17647;
  bool _17649 = _17648 > 0.5000;
  
  if(_17649) {
    float* _17653 = &camera.screenReflectionTrace.x;
    float _17654 = *_17653;
    bool _17655 = _17654 > 0.5000;
  }

  bool _17656 = Phi(_17649, _17655);
  bool _17657 = *microfacetSurface;
  bool _17658 = _17656 && _17657;
  bool _17659 = *overlayMaterial;
  bool _17660 = !_17659;
  bool _17661 = _17658 && _17660;
  
  if(_17661) {
    int _17664 = *qaEffectMode;
    bool _17665 = _17664 == 5;
    bool _17666 = *qaEffectDisabled;
    bool _17667 = _17665 && _17666;
    bool _17668 = !_17667;
  }

  bool _17669 = Phi(_17661, _17668);
  
  if(_17669) {
    float* _17672 = &camera.screenReflectionTrace.x;
    float _17673 = *_17672;
    bool _17674 = _17673 > 1.5000;
    
    if(_17674) {
      float4 _17678 = *gl_FragCoord;
      float2 _17679 = _17678.xy;
      SampledImage<float, 2D> _17681 = *opaqueSceneColor;
      Image<float, 2D> _17682 = Image(_17681);
      int2 _17683 = ImageQuerySizeLod(_17682, 0);
      float2 _17684 = ConvertSToF(_17683);
      float2 _17685 = _17679 / _17684;
      *param@343 = _17685;
      float4 _17687 = sampleComputedScreenReflection(param@343);
      *screenReflection = _17687;
    } else {
      float4x4* _17691 = &camera.screenReflectionWorldToClip;
      float4x4 _17692 = *_17691;
      *param@344 = _17692;
      float4* _17694 = &camera.cameraPosition;
      float4 _17695 = *_17694;
      float3 _17696 = _17695.xyz;
      *param@345 = _17696;
      float4* _17698 = &camera.cameraForward;
      float4 _17699 = *_17698;
      float3 _17700 = _17699.xyz;
      *param@346 = _17700;
      float3 _17702 = *worldPosition;
      *param@347 = _17702;
      float3 _17704 = *shadedNormal;
      *param@348 = _17704;
      float3 _17706 = *reflectionDirection;
      *param@349 = _17706;
      float _17708 = *roughness;
      *param@350 = _17708;
      float4* _17710 = &camera.screenReflectionTrace;
      float4 _17711 = *_17710;
      *param@351 = _17711;
      float4* _17713 = &camera.screenReflectionQuality;
      float4 _17714 = *_17713;
      *param@352 = _17714;
      float4 _17715 = traceScreenSpaceReflection(opaqueSceneColor, overlaySceneDepth, param@344, param@345, param@346, param@347, param@348, param@349, param@350, param@351, param@352);
      *screenReflection = _17715;
    }

    float3 _17717 = *sceneReflectionRadiance;
    float4 _17718 = *screenReflection;
    float3 _17719 = _17718.xyz;
    float* _17720 = &screenReflection.w;
    float _17721 = *_17720;
    float3 _17722 = CompositeConstruct({_17721, _17721, _17721});
    float3 _17723 = GLSL.std.450::FMix(_17717, _17719, _17722);
    *radiance@3 = _17723;
    float3 _17725 = *sceneReflectionResponse;
    float3 _17726 = *radiance@3;
    float3 _17727 = _17725 * _17726;
    *blended@3 = _17727;
    float3 _17728 = *blended@3;
    float3 _17729 = *ambientSpecular;
    float3 _17730 = _17728 - _17729;
    float3 _17731 = *beautyColor;
    float3 _17732 = _17731 + _17730;
    *beautyColor = _17732;
    float3 _17733 = *blended@3;
    *ambientSpecular = _17733;
  }

  *param@353 = 1024;
  float _17736 = materialFeatureEnabled(param@353);
  bool _17737 = _17736 > 0.5000;
  
  if(_17737) {
    float4 _17741 = *gl_FragCoord;
    float2 _17742 = _17741.xy;
    float4* _17743 = &camera.clusterDepth;
    float4 _17744 = *_17743;
    float2 _17745 = _17744.zw;
    float2 _17746 = _17742 / _17745;
    *uv@2 = _17746;
    float2 _17748 = *textureCoordinate;
    float4* _17749 = &material.styleParameters;
    float4 _17750 = *_17749;
    float2 _17751 = _17750.xy;
    float2 _17752 = _17748 * _17751;
    float4* _17753 = &material.styleParameters;
    float4 _17754 = *_17753;
    float2 _17755 = _17754.zw;
    float2 _17756 = _17752 + _17755;
    *mapUv = _17756;
    uint* _17758 = &material.textureBase;
    uint _17759 = *_17758;
    uint _17760 = _17759 + 4;
    uint _17761 = CopyObject(_17760) : [[NonUniform]];
    SampledImage<float, 2D>* _17762 = &textureArray[_17761] : [[NonUniform]];
    SampledImage<float, 2D> _17763 = *_17762 : [[NonUniform]];
    float2 _17764 = *mapUv;
    float4 _17765 = ImageSampleImplicitLod(_17763, _17764);
    float2 _17767 = _17765.xy;
    *param@354 = _17767;
    float* _17769 = &material.hairParameters.z;
    float _17770 = *_17769;
    *param@355 = _17770;
    float2 _17771 = sceneRefractionOffset(param@354, param@355);
    *offset@3 = _17771;
    float3 _17773 = *worldPosition;
    float4* _17774 = &camera.cameraPosition;
    float4 _17775 = *_17774;
    float3 _17776 = _17775.xyz;
    float3 _17777 = _17773 - _17776;
    float4* _17778 = &camera.cameraForward;
    float4 _17779 = *_17778;
    float3 _17780 = _17779.xyz;
    float _17781 = Dot(_17777, _17780);
    *depth = _17781;
    SampledImage<float, 2D> _17783 = *overlaySceneDepth;
    float2 _17784 = *uv@2;
    float2 _17785 = *offset@3;
    float2 _17786 = _17784 + _17785;
    *param@356 = _17786;
    float2 _17788 = sceneRefractionMirrorUv(param@356);
    float4 _17789 = ImageSampleImplicitLod(_17783, _17788);
    float _17790 = _17789.x;
    *fullDepth = _17790;
    SampledImage<float, 2D> _17792 = *overlaySceneDepth;
    float2 _17793 = *uv@2;
    float2 _17794 = *offset@3;
    float2 _17795 = _17794 * 0.2500;
    float2 _17796 = _17793 + _17795;
    *param@357 = _17796;
    float2 _17798 = sceneRefractionMirrorUv(param@357);
    float4 _17799 = ImageSampleImplicitLod(_17792, _17798);
    float _17800 = _17799.x;
    *quarterDepth = _17800;
    float2 _17803 = *uv@2;
    *param@358 = _17803;
    float2 _17805 = *offset@3;
    *param@359 = _17805;
    float _17807 = *fullDepth;
    *param@360 = _17807;
    float _17809 = *quarterDepth;
    *param@361 = _17809;
    float _17811 = *depth;
    *param@362 = _17811;
    float2 _17812 = sceneRefractionUv(param@358, param@359, param@360, param@361, param@362);
    *safeUv = _17812;
    SampledImage<float, 2D> _17814 = *opaqueSceneColor;
    Image<float, 2D> _17815 = Image(_17814);
    int2 _17816 = ImageQuerySizeLod(_17815, 0);
    *extent@3 = _17816;
    float2 _17818 = *safeUv;
    int2 _17819 = *extent@3;
    float2 _17820 = ConvertSToF(_17819);
    float2 _17821 = _17818 * _17820;
    float2 _17822 = CompositeConstruct({0.5000, 0.5000});
    float2 _17823 = _17821 - _17822;
    *pixel@2 = _17823;
    float2 _17825 = *pixel@2;
    float2 _17826 = GLSL.std.450::Floor(_17825);
    int2 _17827 = ConvertFToS(_17826);
    *first = _17827;
    float2 _17829 = *pixel@2;
    float2 _17830 = GLSL.std.450::Fract(_17829);
    *f = _17830;
    *tap = 0;

    while(true) {
      int _17837 = *tap;
      bool _17838 = _17837 < 4;
      if(!_17838) break;
      int2 _17840 = *first;
      int _17841 = *tap;
      int _17842 = SMod(_17841, 2);
      int _17843 = *tap;
      int _17844 = _17843 / 2;
      int2 _17845 = CompositeConstruct({_17842, _17844});
      int2 _17846 = _17840 + _17845;
      *p@2 = _17846;
      int2 _17848 = *extent@3;
      int2 _17849 = CompositeConstruct({2, 2});
      int2 _17850 = _17848 * _17849;
      *period = _17850;
      int2 _17851 = *p@2;
      float2 _17852 = ConvertSToF(_17851);
      int2 _17853 = *period;
      float2 _17854 = ConvertSToF(_17853);
      float2 _17855 = FMod(_17852, _17854);
      int2 _17856 = ConvertFToS(_17855);
      *p@2 = _17856;
      int2 _17857 = *p@2;
      int2 _17858 = *period;
      int2 _17859 = CompositeConstruct({1, 1});
      int2 _17860 = _17858 - _17859;
      int2 _17861 = *p@2;
      int2 _17862 = _17860 - _17861;
      int2 _17863 = GLSL.std.450::SMin(_17857, _17862);
      *p@2 = _17863;
      int _17867 = *tap;
      SampledImage<float, 2D> _17868 = *opaqueSceneColor;
      int2 _17869 = *p@2;
      Image<float, 2D> _17870 = Image(_17868);
      float4 _17871 = ImageFetch(_17870, _17869, Lod(0));
      float3 _17872 = _17871.xyz;
      float3* _17873 = &taps[_17867];
      *_17873 = _17872;
      int _17874 = *tap;
      int _17875 = _17874 + 1;
      *tap = _17875;
    }

    float3* _17877 = &taps[0];
    float3 _17878 = *_17877;
    float3* _17879 = &taps[1];
    float3 _17880 = *_17879;
    float* _17881 = &f.x;
    float _17882 = *_17881;
    float3 _17883 = CompositeConstruct({_17882, _17882, _17882});
    float3 _17884 = GLSL.std.450::FMix(_17878, _17880, _17883);
    float3* _17885 = &taps[2];
    float3 _17886 = *_17885;
    float3* _17887 = &taps[3];
    float3 _17888 = *_17887;
    float* _17889 = &f.x;
    float _17890 = *_17889;
    float3 _17891 = CompositeConstruct({_17890, _17890, _17890});
    float3 _17892 = GLSL.std.450::FMix(_17886, _17888, _17891);
    float* _17893 = &f.y;
    float _17894 = *_17893;
    float3 _17895 = CompositeConstruct({_17894, _17894, _17894});
    float3 _17896 = GLSL.std.450::FMix(_17884, _17892, _17895);
    *background = _17896;
    float4* _17897 = &material.matcapColor;
    float4 _17898 = *_17897;
    float3 _17899 = _17898.xyz;
    float* _17900 = &material.hairParameters.y;
    float _17901 = *_17900;
    float3 _17902 = _17899 * _17901;
    float3 _17903 = *background;
    float3 _17904 = _17903 * _17902;
    *background = _17904;
    float3 _17905 = *directDiffuse;
    float3 _17906 = *ambientDiffuse;
    float3 _17907 = _17905 + _17906;
    float3 _17908 = *directSpecular;
    float3 _17909 = *ambientSpecular;
    float3 _17910 = _17908 + _17909;
    *param@363 = _17907;
    *param@364 = _17910;
    float3 _17914 = *background;
    *param@365 = _17914;
    float _17916 = *outputAlpha;
    *param@366 = _17916;
    float* _17918 = &material.hairParameters.x;
    float _17919 = *_17918;
    *param@367 = _17919;
    float3 _17920 = sceneRefractionSurface(param@363, param@364, param@365, param@366, param@367);
    float3 _17921 = *emissive;
    float3 _17922 = _17920 + _17921;
    *beautyColor = _17922;
  }

  *param@368 = 262144;
  float _17924 = materialFeatureEnabled(param@368);
  bool _17925 = _17924 > 0.5000;
  
  if(_17925) {
    float4 _17928 = *specularEmissive;
    float3 _17929 = _17928.xyz;
    float* _17930 = &material.emissiveStrength;
    float _17931 = *_17930;
    float3 _17932 = _17929 * _17931;
    *param@369 = 8;
    float _17934 = materialFeatureEnabled(param@369);
    float3 _17935 = _17932 * _17934;
    *emissive = _17935;
    int _17936 = *qaEffectMode;
    bool _17937 = _17936 == 6;
    bool _17938 = *qaEffectDisabled;
    bool _17939 = _17937 && _17938;
    
    if(_17939) {
      *emissive = {0.0000, 0.0000, 0.0000};
    }

    *directDiffuse = {0.0000, 0.0000, 0.0000};
    *ambientDiffuse = {0.0000, 0.0000, 0.0000};
    *directSpecular = {0.0000, 0.0000, 0.0000};
    *ambientSpecular = {0.0000, 0.0000, 0.0000};
    *kkSpecular = {0.0000, 0.0000, 0.0000};
    *secondaryKkSpecular = {0.0000, 0.0000, 0.0000};
    *rimLighting = {0.0000, 0.0000, 0.0000};
    float4 _17942 = *baseColor;
    float3 _17943 = _17942.xyz;
    float3 _17944 = *emissive;
    float3 _17945 = _17943 + _17944;
    *beautyColor = _17945;
    *param@370 = 16777216;
    float _17947 = materialFeatureEnabled(param@370);
    bool _17948 = _17947 > 0.5000;
    
    if(_17948) {
      uint* _17952 = &material.materialPadding;
      uint _17953 = *_17952;
      uint _17954 = _17953 >> 1;
      PackedMaterialSurfaceProfile* _17955 = &materialSurfaceProfiles.profiles[_17954];
      PackedMaterialSurfaceProfile _17956 = *_17955;
      float4[22] _17957 = _17956.rows;
      float4[22]* _17958 = &p@3.rows;
      float4 _17959 = _17957[0];
      float4* _17960 = &_17958[0];
      *_17960 = _17959;
      float4 _17961 = _17957[1];
      float4* _17962 = &_17958[1];
      *_17962 = _17961;
      float4 _17963 = _17957[2];
      float4* _17964 = &_17958[2];
      *_17964 = _17963;
      float4 _17965 = _17957[3];
      float4* _17966 = &_17958[3];
      *_17966 = _17965;
      float4 _17967 = _17957[4];
      float4* _17968 = &_17958[4];
      *_17968 = _17967;
      float4 _17969 = _17957[5];
      float4* _17970 = &_17958[5];
      *_17970 = _17969;
      float4 _17971 = _17957[6];
      float4* _17972 = &_17958[6];
      *_17972 = _17971;
      float4 _17973 = _17957[7];
      float4* _17974 = &_17958[7];
      *_17974 = _17973;
      float4 _17975 = _17957[8];
      float4* _17976 = &_17958[8];
      *_17976 = _17975;
      float4 _17977 = _17957[9];
      float4* _17978 = &_17958[9];
      *_17978 = _17977;
      float4 _17979 = _17957[10];
      float4* _17980 = &_17958[10];
      *_17980 = _17979;
      float4 _17981 = _17957[11];
      float4* _17982 = &_17958[11];
      *_17982 = _17981;
      float4 _17983 = _17957[12];
      float4* _17984 = &_17958[12];
      *_17984 = _17983;
      float4 _17985 = _17957[13];
      float4* _17986 = &_17958[13];
      *_17986 = _17985;
      float4 _17987 = _17957[14];
      float4* _17988 = &_17958[14];
      *_17988 = _17987;
      float4 _17989 = _17957[15];
      float4* _17990 = &_17958[15];
      *_17990 = _17989;
      float4 _17991 = _17957[16];
      float4* _17992 = &_17958[16];
      *_17992 = _17991;
      float4 _17993 = _17957[17];
      float4* _17994 = &_17958[17];
      *_17994 = _17993;
      float4 _17995 = _17957[18];
      float4* _17996 = &_17958[18];
      *_17996 = _17995;
      float4 _17997 = _17957[19];
      float4* _17998 = &_17958[19];
      *_17998 = _17997;
      float4 _17999 = _17957[20];
      float4* _18000 = &_17958[20];
      *_18000 = _17999;
      float4 _18001 = _17957[21];
      float4* _18002 = &_17958[21];
      *_18002 = _18001;
      PackedMaterialSurfaceProfile _18005 = *p@3;
      *param@371 = _18005;
      float4 _18007 = azureSampleUnlitSurface(param@371, param@372);
      float4 _18008 = *param@372;
      *baseColor = _18008;
      *layered = _18007;
      float4 _18009 = *layered;
      float3 _18010 = _18009.xyz;
      *beautyColor = _18010;
      float* _18011 = &layered.w;
      float _18012 = *_18011;
      *outputAlpha = _18012;
      float4 _18013 = *layered;
      float3 _18014 = _18013.xyz;
      *emissive = _18014;
      int _18015 = *qaEffectMode;
      bool _18016 = _18015 == 6;
      bool _18017 = *qaEffectDisabled;
      bool _18018 = _18016 && _18017;
      
      if(_18018) {
        *beautyColor = {0.0000, 0.0000, 0.0000};
        *emissive = {0.0000, 0.0000, 0.0000};
      }

    }

  }

  bool _18021 = *eyeRadial;
  
  if(_18021) {
    float* _18024 = &camera.clusterLighting.x;
    float _18025 = *_18024;
    bool _18026 = _18025 < 0.5000;
    
    if(_18026) {
      uint* _18030 = &material.textureBase;
      uint _18031 = *_18030;
      uint _18032 = _18031 + 4;
      uint _18033 = CopyObject(_18032) : [[NonUniform]];
      SampledImage<float, 2D>* _18034 = &textureArray[_18033] : [[NonUniform]];
      SampledImage<float, 2D> _18035 = *_18034 : [[NonUniform]];
      float3 _18036 = *shadedNormal;
      float3 _18037 = *lightDirection;
      float _18038 = Dot(_18036, _18037);
      float _18039 = _18038 * 0.5000;
      float _18040 = _18039 + 0.5000;
      float2 _18041 = CompositeConstruct({_18040, 0.5000});
      float4 _18042 = ImageSampleExplicitLod(_18035, _18041, Lod(0.0000));
      *ramp@3 = _18042;
      float3 _18044 = *keyColor;
      float* _18045 = &camera.showcaseParameters.y;
      float _18046 = *_18045;
      float3 _18047 = _18044 * _18046;
      float _18048 = *keyVisibility;
      float3 _18049 = _18047 * _18048;
      float3 _18050 = *shadedNormal;
      float3 _18051 = *lightDirection;
      float _18052 = Dot(_18050, _18051);
      float _18053 = GLSL.std.450::FMax(_18052, 0.0000);
      float3 _18054 = _18049 * _18053;
      *illumination@3 = _18054;
      float4 _18055 = *baseColor;
      float3 _18056 = _18055.xyz;
      float3 _18057 = *eyeDiffuseMultiplier;
      float3 _18058 = _18056 * _18057;
      float4 _18059 = *ramp@3;
      float3 _18060 = _18059.xyz;
      float3 _18061 = _18058 * _18060;
      float3 _18062 = *illumination@3;
      float3 _18063 = _18061 * _18062;
      float _18064 = *eyeAlphaMultiplier;
      float3 _18065 = _18063 * _18064;
      *eyeHostDiffuse = _18065;
      float _18066 = *shadowVisibility;
      float _18067 = 1.0000 - _18066;
      float4 _18069 = *eyeMatcap;
      *param@373 = _18069;
      float4* _18071 = &eyeProfile.matcap;
      float4 _18072 = *_18071;
      *param@374 = _18072;
      float _18074 = *eyeViewRampAlpha;
      *param@375 = _18074;
      float* _18076 = &ramp@3.w;
      float _18077 = *_18076;
      *param@376 = _18077;
      *param@377 = _18067;
      float* _18080 = &eyeProfile.shape.w;
      float _18081 = *_18080;
      *param@378 = _18081;
      float3 _18083 = *illumination@3;
      *param@379 = _18083;
      float3 _18084 = characterEyeMatcap(param@373, param@374, param@375, param@376, param@377, param@378, param@379);
      *eyeHostMatcap = _18084;
    }

    bool _18085 = *eyeNpr;
    bool _18086 = !_18085;
    
    if(_18086) {
      float3 _18089 = *eyeHostDiffuse;
      *directDiffuse = _18089;
      *ambientDiffuse = {0.0000, 0.0000, 0.0000};
    }

    float3 _18090 = *eyeHostMatcap;
    *directSpecular = _18090;
    *ambientSpecular = {0.0000, 0.0000, 0.0000};
    *kkSpecular = {0.0000, 0.0000, 0.0000};
    *secondaryKkSpecular = {0.0000, 0.0000, 0.0000};
    bool _18091 = *eyeNpr;
    float3 _18092 = *sceneRim;
    bool _18093 = CompositeConstruct({_18091, _18091, _18091});
    float3 _18094 = Select(_18093, _18092, {0.0000, 0.0000, 0.0000});
    *rimLighting = _18094;
    float4 _18096 = *baseColor;
    *param@380 = _18096;
    float* _18098 = &eyeCoordinates.whiteMask;
    float _18099 = *_18098;
    *param@381 = _18099;
    float4* _18101 = &eyeProfile.highlight;
    float4 _18102 = *_18101;
    float3 _18103 = _18102.xyz;
    *param@382 = _18103;
    float4* _18105 = &eyeProfile.scattering;
    float4 _18106 = *_18105;
    float3 _18107 = _18106.xyz;
    *param@383 = _18107;
    float4* _18109 = &eyeProfile.directWeights;
    float4 _18110 = *_18109;
    float3 _18111 = _18110.xyz;
    *param@384 = _18111;
    float* _18113 = &eyeProfile.shape.z;
    float _18114 = *_18113;
    *param@385 = _18114;
    float3 _18115 = characterEyeDirect(param@380, param@381, param@382, param@383, param@384, param@385);
    *emissive = _18115;
    float3 _18116 = *directDiffuse;
    float3 _18117 = *ambientDiffuse;
    float3 _18118 = _18116 + _18117;
    float3 _18119 = *directSpecular;
    float3 _18120 = _18118 + _18119;
    float3 _18121 = *emissive;
    float3 _18122 = _18120 + _18121;
    float3 _18123 = *rimLighting;
    float3 _18124 = _18122 + _18123;
    *beautyColor = _18124;
    *outputAlpha = 1.0000;
  }

  bool _18125 = *multiplyComposite;
  
  if(_18125) {
    float4 _18128 = *baseColor;
    float3 _18129 = _18128.xyz;
    *beautyColor = _18129;
  }

  float* _18130 = &characterBlend.w;
  float _18131 = *_18130;
  bool _18132 = _18131 < 1.0000;
  
  if(_18132) {
    float3 _18135 = *beautyColor;
    float* _18136 = &characterBlend.w;
    float _18137 = *_18136;
    float3 _18138 = _18135 * _18137;
    float4 _18139 = *characterBlend;
    float3 _18140 = _18139.xyz;
    float3 _18141 = _18138 + _18140;
    *beautyColor = _18141;
    float3 _18142 = *directDiffuse;
    float* _18143 = &characterBlend.w;
    float _18144 = *_18143;
    float3 _18145 = _18142 * _18144;
    float4 _18146 = *characterBlend;
    float3 _18147 = _18146.xyz;
    float3 _18148 = _18145 + _18147;
    *directDiffuse = _18148;
    float* _18149 = &characterBlend.w;
    float _18150 = *_18149;
    float3 _18151 = *ambientDiffuse;
    float3 _18152 = _18151 * _18150;
    *ambientDiffuse = _18152;
    float* _18153 = &characterBlend.w;
    float _18154 = *_18153;
    float3 _18155 = *directSpecular;
    float3 _18156 = _18155 * _18154;
    *directSpecular = _18156;
    float* _18157 = &characterBlend.w;
    float _18158 = *_18157;
    float3 _18159 = *ambientSpecular;
    float3 _18160 = _18159 * _18158;
    *ambientSpecular = _18160;
    float* _18161 = &characterBlend.w;
    float _18162 = *_18161;
    float3 _18163 = *kkSpecular;
    float3 _18164 = _18163 * _18162;
    *kkSpecular = _18164;
    float* _18165 = &characterBlend.w;
    float _18166 = *_18165;
    float3 _18167 = *secondaryKkSpecular;
    float3 _18168 = _18167 * _18166;
    *secondaryKkSpecular = _18168;
    float* _18169 = &characterBlend.w;
    float _18170 = *_18169;
    float3 _18171 = *rimLighting;
    float3 _18172 = _18171 * _18170;
    *rimLighting = _18172;
    float* _18173 = &characterBlend.w;
    float _18174 = *_18173;
    float3 _18175 = *emissive;
    float3 _18176 = _18175 * _18174;
    *emissive = _18176;
  }

  float _18178 = azureMaterialRadianceScale();
  *radianceScale = _18178;
  float _18179 = *radianceScale;
  bool _18180 = _18179 != 1.0000;
  
  if(_18180) {
    float _18183 = *radianceScale;
    float3 _18184 = *beautyColor;
    float3 _18185 = _18184 * _18183;
    *beautyColor = _18185;
    float _18186 = *radianceScale;
    float3 _18187 = *directDiffuse;
    float3 _18188 = _18187 * _18186;
    *directDiffuse = _18188;
    float _18189 = *radianceScale;
    float3 _18190 = *ambientDiffuse;
    float3 _18191 = _18190 * _18189;
    *ambientDiffuse = _18191;
    float _18192 = *radianceScale;
    float3 _18193 = *directSpecular;
    float3 _18194 = _18193 * _18192;
    *directSpecular = _18194;
    float _18195 = *radianceScale;
    float3 _18196 = *ambientSpecular;
    float3 _18197 = _18196 * _18195;
    *ambientSpecular = _18197;
    float _18198 = *radianceScale;
    float3 _18199 = *kkSpecular;
    float3 _18200 = _18199 * _18198;
    *kkSpecular = _18200;
    float _18201 = *radianceScale;
    float3 _18202 = *secondaryKkSpecular;
    float3 _18203 = _18202 * _18201;
    *secondaryKkSpecular = _18203;
    float _18204 = *radianceScale;
    float3 _18205 = *rimLighting;
    float3 _18206 = _18205 * _18204;
    *rimLighting = _18206;
    float _18207 = *radianceScale;
    float3 _18208 = *emissive;
    float3 _18209 = _18208 * _18207;
    *emissive = _18209;
  }

  float3 _18211 = *beautyColor;
  *qaColor = _18211;
  int _18212 = *qaIsolationMode;
  bool _18213 = _18212 == 1;
  
  if(_18213) {
    float4 _18216 = *baseColor;
    float3 _18217 = _18216.xyz;
    *qaColor = _18217;
  } else {
    int _18219 = *qaIsolationMode;
    bool _18220 = _18219 == 2;
    
    if(_18220) {
      float _18223 = *diffuse;
      float3 _18224 = CompositeConstruct({_18223, _18223, _18223});
      float3 _18225 = *classRamp;
      float _18226 = *toonWeight;
      float3 _18227 = CompositeConstruct({_18226, _18226, _18226});
      float3 _18228 = GLSL.std.450::FMix(_18224, _18225, _18227);
      *qaColor = _18228;
    } else {
      int _18230 = *qaIsolationMode;
      bool _18231 = _18230 == 3;
      
      if(_18231) {
        float _18234 = *shadowVisibility;
        float3 _18235 = CompositeConstruct({_18234, _18234, _18234});
        *qaColor = _18235;
      } else {
        int _18237 = *qaIsolationMode;
        bool _18238 = _18237 == 4;
        
        if(_18238) {
          float3 _18241 = *kkSpecular;
          float3 _18242 = *secondaryKkSpecular;
          float3 _18243 = _18241 + _18242;
          float3 _18244 = _18243 * 3.0000;
          *qaColor = _18244;
        } else {
          int _18246 = *qaIsolationMode;
          bool _18247 = _18246 == 5;
          
          if(_18247) {
            float3 _18250 = *rimLighting;
            float3 _18251 = _18250 * 3.0000;
            *qaColor = _18251;
          } else {
            int _18253 = *qaIsolationMode;
            bool _18254 = _18253 == 6;
            
            if(_18254) {
              float3 _18257 = *ambientSpecular;
              float3 _18258 = *directSpecular;
              float3 _18259 = _18257 + _18258;
              float3 _18260 = _18259 * 3.0000;
              *qaColor = _18260;
            } else {
              int _18262 = *qaIsolationMode;
              bool _18263 = _18262 == 7;
              
              if(_18263) {
                float3 _18266 = *emissive;
                *qaColor = _18266;
              } else {
                int _18268 = *qaIsolationMode;
                bool _18269 = _18268 == 8;
                
                if(_18269) {
                  
                  if(azureOrdinaryOpaque) {
                    *_18272 = 0;
                  } else {
                    
                    if(_18276) {
                      *_18277 = azureFixedMaterialClass;
                    } else {
                      uint* _18281 = &material.materialClass;
                      uint _18282 = *_18281;
                      *_18277 = _18282;
                    }

                    uint _18283 = *_18277;
                    *_18272 = _18283;
                  }

                  uint _18285 = *_18272;
                  *param@386 = _18285;
                  float3 _18286 = materialClassColor(param@386);
                  *qaColor = _18286;
                } else {
                  int _18288 = *qaIsolationMode;
                  bool _18289 = _18288 == 9;
                  
                  if(_18289) {
                    float _18292 = *styleMask;
                    float3 _18293 = CompositeConstruct({_18292, _18292, _18292});
                    *qaColor = _18293;
                  } else {
                    int _18295 = *qaIsolationMode;
                    bool _18296 = _18295 == 10;
                    
                    if(_18296) {
                      float3 _18299 = *ambientDiffuse;
                      *qaColor = _18299;
                    } else {
                      int _18301 = *qaIsolationMode;
                      bool _18302 = _18301 == 11;
                      
                      if(_18302) {
                        float3 _18305 = *directDiffuse;
                        *qaColor = _18305;
                      } else {
                        int _18307 = *qaIsolationMode;
                        bool _18308 = _18307 == 12;
                        
                        if(_18308) {
                          float3 _18311 = *lamShadowTint;
                          float3 _18312 = *aoShadowTint;
                          float3 _18313 = _18311 * _18312;
                          float3 _18314 = {1.0000, 1.0000, 1.0000} - _18313;
                          float3 _18315 = _18314 * 5.0000;
                          float3 _18316 = GLSL.std.450::FClamp(_18315, {0.0000, 0.0000, 0.0000}, {1.0000, 1.0000, 1.0000});
                          *qaColor = _18316;
                        } else {
                          int _18318 = *qaIsolationMode;
                          bool _18319 = _18318 == 13;
                          
                          if(_18319) {
                            
                            if(azureOrdinaryOpaque) {
                              *_18322 = 0;
                            } else {
                              
                              if(_18326) {
                                *_18327 = azureFixedMaterialClass;
                              } else {
                                uint* _18331 = &material.materialClass;
                                uint _18332 = *_18331;
                                *_18327 = _18332;
                              }

                              uint _18333 = *_18327;
                              *_18322 = _18333;
                            }

                            uint _18334 = *_18322;
                            bool _18335 = _18334 == 2;
                            
                            if(_18335) {
                              float _18339 = *faceIllumination;
                              float3 _18340 = CompositeConstruct({_18339, _18339, _18339});
                              float* _18341 = &faceSdfSample.w;
                              float _18342 = *_18341;
                              float3 _18343 = CompositeConstruct({_18342, _18342, _18342});
                              float3 _18344 = GLSL.std.450::FMix({0.0400, 0.0400, 0.0400}, _18340, _18343);
                              *_18336 = _18344;
                            } else {
                              *_18336 = {0.0000, 0.0000, 0.0000};
                            }

                            float3 _18346 = *_18336;
                            *qaColor = _18346;
                          } else {
                            int _18348 = *qaIsolationMode;
                            bool _18349 = _18348 == 14;
                            
                            if(_18349) {
                              bool _18352 = *overlayMaterial;
                              
                              if(_18352) {
                                float4 _18356 = *baseColor;
                                float3 _18357 = _18356.xyz;
                                *_18353 = _18357;
                              } else {
                                *_18353 = {0.0000, 0.0000, 0.0000};
                              }

                              float3 _18359 = *_18353;
                              *qaColor = _18359;
                            } else {
                              int _18361 = *qaIsolationMode;
                              bool _18362 = _18361 == 16;
                              
                              if(_18362) {
                                float _18366 = *eyebrowRegion;
                                bool _18367 = _18366 > 0.5000;
                                float _18368 = Select(_18367, 1.0000, 0.0000);
                                float3 _18369 = CompositeConstruct({_18368, _18368, _18368});
                                *qaColor = _18369;
                                bool _18370 = *overlayMaterial;
                                
                                if(_18370) {
                                  float _18373 = *eyebrowRegion;
                                  bool _18374 = _18373 > 0.5000;
                                  float _18375 = Select(_18374, 1.0000, 0.0000);
                                  *outputAlpha = _18375;
                                }

                              } else {
                                int _18377 = *qaIsolationMode;
                                bool _18378 = _18377 == 17;
                                
                                if(_18378) {
                                  float _18381 = *roughness;
                                  float3 _18382 = CompositeConstruct({_18381, _18381, _18381});
                                  *qaColor = _18382;
                                } else {
                                  int _18384 = *qaIsolationMode;
                                  bool _18385 = _18384 == 18;
                                  
                                  if(_18385) {
                                    float _18388 = *metallic;
                                    float3 _18389 = CompositeConstruct({_18388, _18388, _18388});
                                    *qaColor = _18389;
                                  } else {
                                    int _18391 = *qaIsolationMode;
                                    bool _18392 = _18391 == 19;
                                    
                                    if(_18392) {
                                      float3 _18395 = *directSpecular;
                                      *qaColor = _18395;
                                    } else {
                                      int _18397 = *qaIsolationMode;
                                      bool _18398 = _18397 == 20;
                                      
                                      if(_18398) {
                                        float3 _18401 = *ambientSpecular;
                                        *qaColor = _18401;
                                      } else {
                                        int _18403 = *qaIsolationMode;
                                        bool _18404 = _18403 == 21;
                                        
                                        if(_18404) {
                                          float3 _18407 = *shadedNormal;
                                          float3 _18408 = _18407 * 0.5000;
                                          float3 _18409 = CompositeConstruct({0.5000, 0.5000, 0.5000});
                                          float3 _18410 = _18408 + _18409;
                                          *qaColor = _18410;
                                        } else {
                                          int _18412 = *qaIsolationMode;
                                          bool _18413 = _18412 == 22;
                                          
                                          if(_18413) {
                                            *param@387 = 4096;
                                            float _18417 = materialFeatureEnabled(param@387);
                                            bool _18418 = _18417 > 0.5000;
                                            
                                            if(_18418) {
                                              uint* _18422 = &material.textureBase;
                                              uint _18423 = *_18422;
                                              uint _18424 = _18423 + 8;
                                              uint _18425 = CopyObject(_18424) : [[NonUniform]];
                                              SampledImage<float, 2D>* _18426 = &textureArray[_18425];
                                              float4 _18428 = *baseColor;
                                              float3 _18429 = _18428.xyz;
                                              *param@388 = _18429;
                                              float3 _18430 = sampleShadowColorLut(_18426, param@388);
                                              *_18419 = _18430;
                                            } else {
                                              *_18419 = {0.0000, 0.0000, 0.0000};
                                            }

                                            float3 _18432 = *_18419;
                                            *qaColor = _18432;
                                          } else {
                                            int _18434 = *qaIsolationMode;
                                            bool _18436 = _18434 == 23;
                                            
                                            if(_18436) {
                                              float3 _18440 = *shadedNormal;
                                              *param@389 = _18440;
                                              float _18441 = materialObjectVisibility(param@389);
                                              float3 _18442 = CompositeConstruct({_18441, _18441, _18441});
                                              *qaColor = _18442;
                                            }

                                          }

                                        }

                                      }

                                    }

                                  }

                                }

                              }

                            }

                          }

                        }

                      }

                    }

                  }

                }

              }

            }

          }

        }

      }

    }

  }

  *param@390 = 256;
  float _18445 = materialFeatureEnabled(param@390);
  bool _18446 = _18445 > 0.5000;
  
  if(_18446) {
    float4 _18450 = *gl_FragCoord;
    float2 _18451 = _18450.xy;
    float4* _18452 = &camera.clusterDepth;
    float4 _18453 = *_18452;
    float2 _18454 = _18453.zw;
    float2 _18455 = _18451 / _18454;
    *uv@3 = _18455;
    SampledImage<float, 2D> _18457 = *overlaySceneDepth;
    float2 _18458 = *uv@3;
    float4 _18459 = ImageSampleImplicitLod(_18457, _18458);
    float _18460 = _18459.x;
    *sceneDepth@3 = _18460;
    float _18461 = *sceneDepth@3;
    float* _18462 = &material.featureParameters.z;
    float _18463 = *_18462;
    float _18464 = GLSL.std.450::FMax(_18463, 0.0010);
    float _18465 = _18461 / _18464;
    float _18466 = 1.0000 - _18465;
    float _18467 = GLSL.std.450::FClamp(_18466, 0.0000, 1.0000);
    float* _18468 = &material.featureParameters.y;
    float _18469 = *_18468;
    float _18470 = _18467 * _18469;
    *outputAlpha = _18470;
    bool _18471 = *overlayDisabled;
    
    if(_18471) {
      *outputAlpha = 0.0000;
    }

    SampledImage<float, 2D> _18475 = *opaqueSceneColor;
    float2 _18476 = *uv@3;
    float4 _18477 = ImageSampleImplicitLod(_18475, _18476);
    float3 _18478 = _18477.xyz;
    *scene = _18478;
    float3 _18481 = *scene;
    *param@391 = _18481;
    float3 _18482 = rgbToHsv(param@391);
    float* _18483 = &material.featureParameters.x;
    float _18484 = *_18483;
    float* _18485 = &material.styleParameters.w;
    float _18486 = *_18485;
    float* _18487 = &material.featureParameters.w;
    float _18488 = *_18487;
    float3 _18489 = CompositeConstruct({_18484, _18486, _18488});
    float3 _18490 = _18482 * _18489;
    *hsv = _18490;
    float3 _18492 = *hsv;
    *param@392 = _18492;
    float3 _18493 = hsvToRgb(param@392);
    float4* _18494 = &material.styleParameters;
    float4 _18495 = *_18494;
    float3 _18496 = _18495.xyz;
    float3 _18497 = _18493 * _18496;
    *qaColor = _18497;
  }

  bool _18499 = *overlayDisabled;
  
  if(_18499) {
    *_18500 = 0.0000;
  } else {
    float _18504 = *outputAlpha;
    float* _18505 = &material.nodeOpacity;
    float _18506 = *_18505;
    float _18507 = _18504 * _18506;
    float _18508 = GLSL.std.450::FClamp(_18507, 0.0000, 1.0000);
    *_18500 = _18508;
  }

  float _18509 = *_18500;
  *compositeCoverage = _18509;
  float3 _18510 = *qaColor;
  float _18511 = *outputAlpha;
  float _18512 = _18510.x;
  float _18513 = _18510.y;
  float _18514 = _18510.z;
  float4 _18515 = CompositeConstruct({_18512, _18513, _18514, _18511});
  *outputColor = _18515;
  uint* _18516 = &material.materialPadding;
  uint _18517 = *_18516;
  uint _18518 = _18517 & 1;
  bool _18519 = _18518 != 0;
  
  if(_18519) {
    float4 _18522 = *outputColor;
    float3 _18523 = _18522.xyz;
    float3 _18524 = CompositeConstruct({0.4200, 0.4200, 0.4200});
    float3 _18525 = GLSL.std.450::FMix(_18523, {0.9600, 0.6200, 0.1000}, _18524);
    float* _18526 = &outputColor.x;
    float _18527 = _18525.x;
    *_18526 = _18527;
    float* _18528 = &outputColor.y;
    float _18529 = _18525.y;
    *_18528 = _18529;
    float* _18530 = &outputColor.z;
    float _18531 = _18525.z;
    *_18530 = _18531;
    float* _18532 = &outputColor.w;
    *_18532 = 1.0000;
  }

  
  if(azureOrdinaryOpaque) {
    *_18533 = 0;
  } else {
    int* _18537 = &material.alphaMode;
    int _18538 = *_18537;
    *_18533 = _18538;
  }

  int _18539 = *_18533;
  bool _18540 = _18539 == 2;
  
  if(_18540) {
    float* _18543 = &material.nodeOpacity;
    float _18544 = *_18543;
    float* _18545 = &outputColor.w;
    float _18546 = *_18545;
    float _18547 = _18546 * _18544;
    float* _18548 = &outputColor.w;
    *_18548 = _18547;
  }

  bool _18549 = *multiplyComposite;
  
  if(_18549) {
    uint* _18553 = &material.materialPadding;
    uint _18554 = *_18553;
    uint _18555 = _18554 >> 1;
    float4* _18556 = &materialSurfaceProfiles.profiles[_18555].rows[20];
    float4 _18557 = *_18556;
    float2 _18558 = _18557.xy;
    *compositeProfile = _18558;
    float* _18559 = &compositeProfile.x;
    float _18560 = *_18559;
    bool _18561 = _18560 > 0.5000;
    
    if(_18561) {
      float4 _18565 = *gl_FragCoord;
      float2 _18566 = _18565.xy;
      int2 _18567 = ConvertFToS(_18566);
      *pixel@3 = _18567;
      SampledImage<float, 2D> _18569 = *opaqueSceneColor;
      int2 _18570 = *pixel@3;
      Image<float, 2D> _18571 = Image(_18569);
      float4 _18572 = ImageFetch(_18571, _18570, Lod(0));
      float _18573 = _18572.w;
      *receiverCode = _18573;
      float* _18575 = &compositeProfile.x;
      float _18576 = *_18575;
      bool _18577 = _18576 < 1.5000;
      
      if(_18577) {
        float _18581 = *receiverCode;
        bool _18582 = _18581 <= 0.5000;
        *_18578 = _18582;
      } else {
        float _18584 = *receiverCode;
        bool _18585 = _18584 > 1.5000;
        *_18578 = _18585;
      }

      bool _18586 = *_18578;
      *receiverMatches = _18586;
      bool _18587 = *receiverMatches;
      bool _18588 = !_18587;
      bool _18589 = !_18588;
      
      if(_18589) {
        SampledImage<float, 2D> _18592 = *overlaySceneDepth;
        int2 _18593 = *pixel@3;
        Image<float, 2D> _18594 = Image(_18592);
        float4 _18595 = ImageFetch(_18594, _18593, Lod(0));
        float _18596 = _18595.x;
        bool _18597 = _18596 >= 100000.0000;
      }

      bool _18598 = Phi(_18588, _18597);
      
      if(_18598) {
        Kill();
      }

    }

    float* _18602 = &compositeProfile.y;
    float _18603 = *_18602;
    float _18604 = *compositeCoverage;
    float _18605 = _18604 * _18603;
    *compositeCoverage = _18605;
    float4 _18606 = *outputColor;
    float3 _18607 = _18606.xyz;
    float _18608 = *compositeCoverage;
    float3 _18609 = CompositeConstruct({_18608, _18608, _18608});
    float3 _18610 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, _18607, _18609);
    float* _18611 = &outputColor.x;
    float _18612 = _18610.x;
    *_18611 = _18612;
    float* _18613 = &outputColor.y;
    float _18614 = _18610.y;
    *_18613 = _18614;
    float* _18615 = &outputColor.z;
    float _18616 = _18610.z;
    *_18615 = _18616;
    float* _18617 = &outputColor.w;
    *_18617 = 0.0000;
  }

  float* _18619 = &outputColor.w;
  float _18620 = *_18619;
  *param@393 = _18620;
  azureWriteDisplayMask(param@393);
  *param@394 = 67108864;
  float _18624 = materialFeatureEnabled(param@394);
  bool _18625 = _18624 > 0.5000;
  float4 _18627 = *outputColor;
  *param@395 = _18627;
  *param@396 = _18625;
  float4 _18629 = azureMaterialOutputPrecision(param@395, param@396);
  *outputColor = _18629;
  float _18631 = *platformMask;
  float _18632 = 1.0000 - _18631;
  bool _18633 = *overlayMaterial;
  float _18634 = Select(_18633, 0.0000, 1.0000);
  float _18635 = _18632 * _18634;
  float* _18636 = &material.featureParameters.x;
  float _18637 = *_18636;
  float _18638 = _18635 * _18637;
  float _18639 = *hairActive;
  float* _18640 = &material.matcapColor.w;
  float _18641 = *_18640;
  float _18642 = GLSL.std.450::FClamp(_18641, 0.0000, 1.0000);
  float _18643 = GLSL.std.450::FMax(_18639, _18642);
  float _18644 = GLSL.std.450::FMix(1.0000, 0.6800, _18643);
  float _18645 = _18638 * _18644;
  *innerOutlineParticipation = _18645;
  float* _18646 = &camera.clusterLighting.x;
  float _18647 = *_18646;
  bool _18648 = _18647 > 0.5000;
  bool _18649 = *sceneCharacter;
  bool _18650 = !_18649;
  bool _18651 = _18648 && _18650;
  
  if(_18651) {
    *innerOutlineParticipation = 0.0000;
  }

  float3 _18655 = *geometricNormal;
  *innerOutlineNormal = _18655;
  float3 _18656 = *innerOutlineNormal;
  float3 _18657 = _18656 * 0.5000;
  float3 _18658 = CompositeConstruct({0.5000, 0.5000, 0.5000});
  float3 _18659 = _18657 + _18658;
  float _18660 = *innerOutlineParticipation;
  float _18661 = _18659.x;
  float _18662 = _18659.y;
  float _18663 = _18659.z;
  float4 _18664 = CompositeConstruct({_18661, _18662, _18663, _18660});
  *outputNormal = _18664;
  return;
}

bool azureNodeOpacityCovered(float3* coordinate@2, float* opacity) {
  uint3* cell;
  uint* hash;
  float _1026 = *opacity;
  bool _1028 = _1026 >= 1.0000;
  
  if(_1028) {
    return true;
  }

  float _1033 = *opacity;
  bool _1035 = _1033 <= 0.0000;
  
  if(_1035) {
    return false;
  }

  float3 _1043 = *coordinate@2;
  float3 _1045 = _1043 * 256.0000;
  float3 _1046 = GLSL.std.450::Floor(_1045);
  int3 _1048 = ConvertFToS(_1046);
  uint3 _1049 = Bitcast(_1048);
  *cell = _1049;
  uint* _1052 = &cell.x;
  uint _1053 = *_1052;
  uint _1055 = _1053 * 1597334677;
  uint* _1057 = &cell.y;
  uint _1058 = *_1057;
  uint _1060 = _1058 * 3812015801;
  uint _1061 = _1055 ^ _1060;
  uint* _1063 = &cell.z;
  uint _1064 = *_1063;
  uint _1066 = _1064 * 2798796415;
  uint _1067 = _1061 ^ _1066;
  *hash = _1067;
  uint _1068 = *hash;
  uint _1070 = _1068 >> 16;
  uint _1071 = *hash;
  uint _1072 = _1071 ^ _1070;
  *hash = _1072;
  uint _1074 = *hash;
  uint _1075 = _1074 * 2246822519;
  *hash = _1075;
  uint _1076 = *hash;
  uint _1077 = _1076 >> 13;
  uint _1078 = *hash;
  uint _1079 = _1078 ^ _1077;
  *hash = _1079;
  uint _1080 = *hash;
  uint _1082 = _1080 >> 8;
  float _1083 = ConvertUToF(_1082);
  float _1085 = _1083 * 0.0000;
  float _1086 = *opacity;
  bool _1087 = _1085 < _1086;
  return _1087;
}

float shadowReceiverBias(float* normalDotLight, float* worldTexel) {
  float* sine;
  float _1091 = *normalDotLight;
  float _1092 = *normalDotLight;
  float _1093 = _1091 * _1092;
  float _1094 = 1.0000 - _1093;
  float _1095 = GLSL.std.450::FMax(_1094, 0.0000);
  float _1096 = GLSL.std.450::Sqrt(_1095);
  *sine = _1096;
  float _1098 = *normalDotLight;
  float _1099 = 1.0000 - _1098;
  float _1100 = 0.0030 * _1099;
  float _1102 = GLSL.std.450::FMax(_1100, 0.0010);
  float _1104 = *worldTexel;
  float _1105 = 2.0000 * _1104;
  float _1106 = *sine;
  float _1107 = _1105 * _1106;
  float _1108 = GLSL.std.450::FMax(_1102, _1107);
  return _1108;
}

float shadowReceiverPlaneWeight(float* normalCurvature, float* filterWorldRadius) {
  float _1113 = *normalCurvature;
  float _1114 = *filterWorldRadius;
  float _1115 = _1113 * _1114;
  float _1116 = GLSL.std.450::SmoothStep(0.0100, 0.0500, _1115);
  float _1117 = 1.0000 - _1116;
  return _1117;
}

float shadowContactRadius(float* tileTexels, float* maximumRadius) {
  float _1121 = *tileTexels;
  float _1122 = 3.0000 * _1121;
  float _1124 = _1122 / 1024.0000;
  float _1125 = *maximumRadius;
  float _1126 = GLSL.std.450::FMin(_1124, _1125);
  return _1126;
}

float4 shadowTexelQuad(Image<float, 2D>* depthMap, sampler* depthSampler, int2* base, int2* lo, int2* hi) {
  float2* uv@4;
  int2 _1129 = *base;
  int2 _1130 = *lo;
  bool _1132 = _1129 >= _1130;
  bool _1133 = All(_1132);
  
  if(_1133) {
    int2 _1136 = *base;
    int2 _1139 = _1136 + {1, 1};
    int2 _1140 = *hi;
    bool _1141 = _1139 <= _1140;
    bool _1142 = All(_1141);
  }

  bool _1143 = Phi(_1133, _1142);
  
  if(_1143) {
    int2 _1147 = *base;
    float2 _1148 = ConvertSToF(_1147);
    float2 _1149 = CompositeConstruct({1.0000, 1.0000});
    float2 _1150 = _1148 + _1149;
    Image<float, 2D> _1151 = *depthMap;
    sampler _1152 = *depthSampler;
    SampledImage<float, 2D> _1153 = SampledImage(_1151, _1152);
    Image<float, 2D> _1155 = Image(_1153);
    int2 _1156 = ImageQuerySizeLod(_1155, 0);
    float2 _1157 = ConvertSToF(_1156);
    float2 _1158 = _1150 / _1157;
    *uv@4 = _1158;
    Image<float, 2D> _1159 = *depthMap;
    sampler _1160 = *depthSampler;
    SampledImage<float, 2D> _1161 = SampledImage(_1159, _1160);
    float2 _1162 = *uv@4;
    float4 _1163 = ImageGather(_1161, _1162, 0);
    float4 _1164 = _1163.wzxy;
    return _1164;
  }

  Image<float, 2D> _1166 = *depthMap;
  sampler _1167 = *depthSampler;
  SampledImage<float, 2D> _1168 = SampledImage(_1166, _1167);
  int2 _1169 = *base;
  int2 _1170 = *lo;
  int2 _1171 = *hi;
  int2 _1172 = GLSL.std.450::SClamp(_1169, _1170, _1171);
  Image<float, 2D> _1173 = Image(_1168);
  float4 _1174 = ImageFetch(_1173, _1172, Lod(0));
  float _1175 = _1174.x;
  Image<float, 2D> _1176 = *depthMap;
  sampler _1177 = *depthSampler;
  SampledImage<float, 2D> _1178 = SampledImage(_1176, _1177);
  int2 _1179 = *base;
  int2 _1181 = _1179 + {1, 0};
  int2 _1182 = *lo;
  int2 _1183 = *hi;
  int2 _1184 = GLSL.std.450::SClamp(_1181, _1182, _1183);
  Image<float, 2D> _1185 = Image(_1178);
  float4 _1186 = ImageFetch(_1185, _1184, Lod(0));
  float _1187 = _1186.x;
  Image<float, 2D> _1188 = *depthMap;
  sampler _1189 = *depthSampler;
  SampledImage<float, 2D> _1190 = SampledImage(_1188, _1189);
  int2 _1191 = *base;
  int2 _1193 = _1191 + {0, 1};
  int2 _1194 = *lo;
  int2 _1195 = *hi;
  int2 _1196 = GLSL.std.450::SClamp(_1193, _1194, _1195);
  Image<float, 2D> _1197 = Image(_1190);
  float4 _1198 = ImageFetch(_1197, _1196, Lod(0));
  float _1199 = _1198.x;
  Image<float, 2D> _1200 = *depthMap;
  sampler _1201 = *depthSampler;
  SampledImage<float, 2D> _1202 = SampledImage(_1200, _1201);
  int2 _1203 = *base;
  int2 _1204 = _1203 + {1, 1};
  int2 _1205 = *lo;
  int2 _1206 = *hi;
  int2 _1207 = GLSL.std.450::SClamp(_1204, _1205, _1206);
  Image<float, 2D> _1208 = Image(_1202);
  float4 _1209 = ImageFetch(_1208, _1207, Lod(0));
  float _1210 = _1209.x;
  float4 _1211 = CompositeConstruct({_1175, _1187, _1199, _1210});
  return _1211;
}

float4 shadowDiskQuadWeights(float2* offset@4, float* radius) {
  float4* x;
  float4* y;
  float* _1215 = &offset@4.x;
  float _1216 = *_1215;
  float4 _1218 = CompositeConstruct({_1216, _1216, _1216, _1216});
  float4 _1219 = _1218 + {0.0000, 1.0000, 0.0000, 1.0000};
  *x = _1219;
  float* _1221 = &offset@4.y;
  float _1222 = *_1221;
  float4 _1224 = CompositeConstruct({_1222, _1222, _1222, _1222});
  float4 _1225 = _1224 + {0.0000, 0.0000, 1.0000, 1.0000};
  *y = _1225;
  float _1226 = *radius;
  float _1228 = _1226 + 0.5000;
  float4 _1229 = CompositeConstruct({_1228, _1228, _1228, _1228});
  float4 _1230 = *x;
  float4 _1231 = *x;
  float4 _1232 = _1230 * _1231;
  float4 _1233 = *y;
  float4 _1234 = *y;
  float4 _1235 = _1233 * _1234;
  float4 _1236 = _1232 + _1235;
  float4 _1237 = GLSL.std.450::Sqrt(_1236);
  float4 _1238 = _1229 - _1237;
  float4 _1241 = GLSL.std.450::FClamp(_1238, {0.0000, 0.0000, 0.0000, 0.0000}, {1.0000, 1.0000, 1.0000, 1.0000});
  return _1241;
}

float4 shadowBlockerGridWeights(int2* offset@5, float2* fraction) {
  float2* x@2;
  float* _1249;
  float* _1261;
  float2* y@2;
  float* _1273;
  float* _1284;
  int* _1245 = &offset@5.x;
  int _1246 = *_1245;
  bool _1248 = _1246 == -2;
  
  if(_1248) {
    float* _1252 = &fraction.x;
    float _1253 = *_1252;
    float _1254 = 1.0000 - _1253;
    *_1249 = _1254;
  } else {
    *_1249 = 1.0000;
  }

  float _1256 = *_1249;
  int* _1257 = &offset@5.x;
  int _1258 = *_1257;
  bool _1260 = _1258 == 2;
  
  if(_1260) {
    float* _1264 = &fraction.x;
    float _1265 = *_1264;
    *_1261 = _1265;
  } else {
    *_1261 = 1.0000;
  }

  float _1267 = *_1261;
  float2 _1268 = CompositeConstruct({_1256, _1267});
  *x@2 = _1268;
  int* _1270 = &offset@5.y;
  int _1271 = *_1270;
  bool _1272 = _1271 == -2;
  
  if(_1272) {
    float* _1276 = &fraction.y;
    float _1277 = *_1276;
    float _1278 = 1.0000 - _1277;
    *_1273 = _1278;
  } else {
    *_1273 = 1.0000;
  }

  float _1280 = *_1273;
  int* _1281 = &offset@5.y;
  int _1282 = *_1281;
  bool _1283 = _1282 == 2;
  
  if(_1283) {
    float* _1287 = &fraction.y;
    float _1288 = *_1287;
    *_1284 = _1288;
  } else {
    *_1284 = 1.0000;
  }

  float _1290 = *_1284;
  float2 _1291 = CompositeConstruct({_1280, _1290});
  *y@2 = _1291;
  float2 _1292 = *x@2;
  float4 _1293 = _1292.xyxy;
  float2 _1294 = *y@2;
  float4 _1295 = _1294.xxyy;
  float4 _1296 = _1293 * _1295;
  return _1296;
}

float3 sampleShadowColorLut(SampledImage<float, 2D>* lut, float3* linearColor) {
  float3* value;
  float3* encoded@2;
  float* dimension;
  float* slice;
  float* first@2;
  float2* uv@5;
  float2* next;
  float3 _1300 = *linearColor;
  float3 _1302 = GLSL.std.450::FMax(_1300, {0.0000, 0.0000, 0.0000});
  *value = _1302;
  float3 _1305 = *value;
  float3 _1308 = GLSL.std.450::Pow(_1305, {0.4167, 0.4167, 0.4167});
  float3 _1309 = _1308 * 1.0550;
  float3 _1311 = CompositeConstruct({0.0550, 0.0550, 0.0550});
  float3 _1312 = _1309 - _1311;
  float3 _1314 = *value;
  float3 _1315 = _1314 * 12.9200;
  float3 _1316 = *value;
  bool _1320 = _1316 <= {0.0031, 0.0031, 0.0031};
  float3 _1321 = Select(_1320, _1315, _1312);
  float3 _1322 = CompositeConstruct({0.0000, 0.0000, 0.0000});
  float3 _1323 = CompositeConstruct({1.0000, 1.0000, 1.0000});
  float3 _1324 = GLSL.std.450::FClamp(_1321, _1322, _1323);
  *encoded@2 = _1324;
  SampledImage<float, 2D> _1326 = *lut;
  Image<float, 2D> _1327 = Image(_1326);
  int2 _1328 = ImageQuerySizeLod(_1327, 0);
  int _1329 = _1328.y;
  float _1330 = ConvertSToF(_1329);
  *dimension = _1330;
  float* _1332 = &encoded@2.z;
  float _1333 = *_1332;
  float _1334 = *dimension;
  float _1335 = _1334 - 1.0000;
  float _1336 = _1333 * _1335;
  *slice = _1336;
  float _1338 = *slice;
  float _1339 = GLSL.std.450::Floor(_1338);
  *first@2 = _1339;
  float _1341 = *first@2;
  float _1342 = *dimension;
  float _1343 = _1341 * _1342;
  float* _1344 = &encoded@2.x;
  float _1345 = *_1344;
  float _1346 = *dimension;
  float _1347 = _1346 - 1.0000;
  float _1348 = _1345 * _1347;
  float _1349 = _1343 + _1348;
  float _1350 = _1349 + 0.5000;
  float _1351 = *dimension;
  float _1352 = *dimension;
  float _1353 = _1351 * _1352;
  float _1354 = _1350 / _1353;
  float* _1355 = &encoded@2.y;
  float _1356 = *_1355;
  float _1357 = *dimension;
  float _1358 = _1357 - 1.0000;
  float _1359 = _1356 * _1358;
  float _1360 = _1359 + 0.5000;
  float _1361 = *dimension;
  float _1362 = _1360 / _1361;
  float2 _1363 = CompositeConstruct({_1354, _1362});
  *uv@5 = _1363;
  float2 _1365 = *uv@5;
  float _1366 = *dimension;
  float _1367 = 1.0000 / _1366;
  float2 _1368 = CompositeConstruct({_1367, 0.0000});
  float2 _1369 = _1365 + _1368;
  *next = _1369;
  SampledImage<float, 2D> _1370 = *lut;
  float2 _1371 = *uv@5;
  float4 _1372 = ImageSampleExplicitLod(_1370, _1371, Lod(0.0000));
  float3 _1373 = _1372.xyz;
  SampledImage<float, 2D> _1374 = *lut;
  float2 _1375 = *next;
  float4 _1376 = ImageSampleExplicitLod(_1374, _1375, Lod(0.0000));
  float3 _1377 = _1376.xyz;
  float _1378 = *slice;
  float _1379 = GLSL.std.450::Fract(_1378);
  float3 _1380 = CompositeConstruct({_1379, _1379, _1379});
  float3 _1381 = GLSL.std.450::FMix(_1373, _1377, _1380);
  return _1381;
}

float2 faceSdfSampleUv(float2* uv@6, float* localLightX@2) {
  float* _1386;
  float _1384 = *localLightX@2;
  bool _1385 = _1384 > 0.0000;
  
  if(_1385) {
    float* _1389 = &uv@6.x;
    float _1390 = *_1389;
    *_1386 = _1390;
  } else {
    float* _1392 = &uv@6.x;
    float _1393 = *_1392;
    float _1394 = 1.0000 - _1393;
    *_1386 = _1394;
  }

  float _1395 = *_1386;
  float* _1396 = &uv@6.y;
  float _1397 = *_1396;
  float2 _1398 = CompositeConstruct({_1395, _1397});
  return _1398;
}

float3 faceSdfNormal(float4* lightmap, float* localLightX@3) {
  float* nx;
  float* _1402 = &lightmap.z;
  float _1403 = *_1402;
  float _1404 = _1403 * 2.0000;
  float _1405 = _1404 - 1.0000;
  float _1406 = *localLightX@3;
  bool _1407 = _1406 > 0.0000;
  float _1409 = Select(_1407, 1.0000, -1.0000);
  float _1410 = _1405 * _1409;
  *nx = _1410;
  float _1411 = *nx;
  float _1413 = *nx;
  float _1414 = GLSL.std.450::FAbs(_1413);
  float _1415 = 1.0000 - _1414;
  float3 _1416 = CompositeConstruct({_1411, 0.0001, _1415});
  float3 _1417 = GLSL.std.450::Normalize(_1416);
  return _1417;
}

float3 faceSdfWorldNormal(float4* lightmap@2, float* localLightX@4, float3x3* headFrame@2, float3* geometryNormal, float* geometryMix@2) {
  float3* worldNormal@2;
  float4* param@397;
  float* param@398;
  float3* blendedNormal;
  float3* _1440;
  float3x3 _1421 = *headFrame@2;
  float4 _1423 = *lightmap@2;
  *param@397 = _1423;
  float _1425 = *localLightX@4;
  *param@398 = _1425;
  float3 _1426 = faceSdfNormal(param@397, param@398);
  float3 _1427 = _1421 * _1426;
  float3 _1428 = GLSL.std.450::Normalize(_1427);
  *worldNormal@2 = _1428;
  float3 _1430 = *worldNormal@2;
  float3 _1431 = *geometryNormal;
  float _1432 = *geometryMix@2;
  float3 _1433 = CompositeConstruct({_1432, _1432, _1432});
  float3 _1434 = GLSL.std.450::FMix(_1430, _1431, _1433);
  *blendedNormal = _1434;
  float3 _1435 = *blendedNormal;
  float3 _1436 = *blendedNormal;
  float _1437 = Dot(_1435, _1436);
  bool _1439 = _1437 > 0.0000;
  
  if(_1439) {
    float3 _1443 = *blendedNormal;
    float3 _1444 = GLSL.std.450::Normalize(_1443);
    *_1440 = _1444;
  } else {
    float3 _1446 = *geometryNormal;
    *_1440 = _1446;
  }

  float3 _1447 = *_1440;
  return _1447;
}

float faceSdfRampCoordinate(float4* lightmap@3, float* geometryMix@3, float3* localLight, float3* localCamera, float* geometricNdotL, float3* adjustment) {
  float3* horizontal;
  float2* lightPlane;
  float2* _1463;
  float2* cameraPlane;
  float2* _1477;
  float* back;
  float* halfWrap;
  float* threshold;
  float* p@4;
  float* sdf;
  float* geometry;
  float* _1451 = &localLight.x;
  float _1452 = *_1451;
  float* _1453 = &localLight.z;
  float _1454 = *_1453;
  float3 _1455 = CompositeConstruct({_1452, 0.0001, _1454});
  float3 _1456 = GLSL.std.450::Normalize(_1455);
  *horizontal = _1456;
  float3 _1458 = *localLight;
  float2 _1459 = _1458.xz;
  float _1460 = GLSL.std.450::Length(_1459);
  bool _1462 = _1460 > 0.0000;
  
  if(_1462) {
    float3 _1466 = *localLight;
    float2 _1467 = _1466.xz;
    float2 _1468 = GLSL.std.450::Normalize(_1467);
    *_1463 = _1468;
  } else {
    *_1463 = {0.0000, 1.0000};
  }

  float2 _1471 = *_1463;
  *lightPlane = _1471;
  float3 _1473 = *localCamera;
  float2 _1474 = _1473.xz;
  float _1475 = GLSL.std.450::Length(_1474);
  bool _1476 = _1475 > 0.0000;
  
  if(_1476) {
    float3 _1480 = *localCamera;
    float2 _1481 = _1480.xz;
    float2 _1482 = GLSL.std.450::Normalize(_1481);
    *_1477 = _1482;
  } else {
    *_1477 = {0.0000, 1.0000};
  }

  float2 _1484 = *_1477;
  *cameraPlane = _1484;
  float2 _1486 = *lightPlane;
  float2 _1487 = *cameraPlane;
  float _1488 = Dot(_1486, _1487);
  float _1489 = -_1488;
  float _1490 = GLSL.std.450::FClamp(_1489, 0.0000, 1.0000);
  float* _1491 = &horizontal.z;
  float _1492 = *_1491;
  float _1493 = -_1492;
  float _1494 = GLSL.std.450::FClamp(_1493, 0.0000, 1.0000);
  float _1495 = _1490 * _1494;
  float* _1496 = &adjustment.x;
  float _1497 = *_1496;
  float _1498 = 1.0000 - _1497;
  float _1499 = _1495 * _1498;
  *back = _1499;
  float* _1501 = &horizontal.z;
  float _1502 = *_1501;
  float _1503 = *back;
  float _1504 = _1503 * 0.5000;
  float* _1505 = &horizontal.z;
  float _1506 = *_1505;
  float* _1507 = &horizontal.z;
  float _1508 = *_1507;
  float _1509 = _1506 * _1508;
  float _1510 = 1.0000 - _1509;
  float _1511 = _1504 * _1510;
  float _1512 = _1502 + _1511;
  float* _1513 = &adjustment.z;
  float _1514 = *_1513;
  float _1515 = _1512 + _1514;
  float _1516 = GLSL.std.450::FClamp(_1515, -1.0000, 1.0000);
  float _1517 = 0.5000 * _1516;
  *halfWrap = _1517;
  float _1519 = *halfWrap;
  float _1520 = 0.5000 - _1519;
  float _1522 = GLSL.std.450::FClamp(_1520, 0.0010, 0.9990);
  *threshold = _1522;
  float _1524 = *threshold;
  float _1525 = 2.0000 * _1524;
  float _1526 = _1525 - 1.0000;
  float _1527 = GLSL.std.450::FMax(_1526, 0.0000);
  float _1528 = *threshold;
  float _1529 = 2.0000 * _1528;
  float _1530 = GLSL.std.450::FMin(_1529, 1.0000);
  float* _1531 = &lightmap@3.x;
  float _1532 = *_1531;
  float* _1533 = &lightmap@3.y;
  float _1534 = *_1533;
  float _1535 = _1532 + _1534;
  float _1536 = 0.5000 * _1535;
  float _1537 = GLSL.std.450::SmoothStep(_1527, _1530, _1536);
  *p@4 = _1537;
  float _1539 = *p@4;
  float _1540 = *halfWrap;
  float _1541 = *halfWrap;
  float _1542 = GLSL.std.450::Ceil(_1541);
  float _1543 = _1540 * _1542;
  float _1544 = _1539 + _1543;
  float _1545 = GLSL.std.450::FAbs(_1544);
  float _1546 = 2.0000 * _1545;
  float _1547 = _1546 - 1.0000;
  *sdf = _1547;
  float _1549 = *geometricNdotL;
  float* _1550 = &adjustment.y;
  float _1551 = *_1550;
  float* _1552 = &adjustment.x;
  float _1553 = *_1552;
  float _1554 = _1551 * _1553;
  float _1555 = _1549 + _1554;
  float _1556 = GLSL.std.450::FClamp(_1555, -1.0000, 1.0000);
  *geometry = _1556;
  float _1557 = *sdf;
  float _1558 = *geometry;
  float _1559 = *geometryMix@3;
  float _1560 = GLSL.std.450::FMix(_1557, _1558, _1559);
  float _1561 = 0.5000 * _1560;
  float _1562 = 0.5000 + _1561;
  float _1563 = GLSL.std.450::FClamp(_1562, 0.0000, 1.0000);
  return _1563;
}

float dielectricF0(float* specular) {
  float _1567 = *specular;
  float _1568 = GLSL.std.450::FClamp(_1567, 0.0000, 1.0000);
  float _1569 = 0.0800 * _1568;
  return _1569;
}

float sceneRefractionWeight(float* alpha, float* contribution@2) {
  float _1572 = *alpha;
  float _1573 = 1.0000 - _1572;
  float _1574 = *contribution@2;
  float _1575 = 1.0000 - _1574;
  float _1576 = GLSL.std.450::FMax(_1575, 0.0100);
  float _1577 = _1573 / _1576;
  float _1578 = GLSL.std.450::FClamp(_1577, 0.0000, 1.0000);
  return _1578;
}

float2 sceneRefractionOffset(float2* map, float* strength) {
  float2 _1581 = *map;
  float2 _1582 = _1581 * 2.0000;
  float2 _1583 = CompositeConstruct({1.0000, 1.0000});
  float2 _1584 = _1582 - _1583;
  float _1585 = *strength;
  float2 _1586 = _1584 * _1585;
  return _1586;
}

float2 sceneRefractionUv(float2* uv@7, float2* offset@6, float* fullDepth@2, float* quarterDepth@2, float* surfaceDepth@2) {
  float _1589 = *fullDepth@2;
  float _1590 = *surfaceDepth@2;
  bool _1591 = _1589 >= _1590;
  
  if(_1591) {
    float2 _1594 = *uv@7;
    float2 _1595 = *offset@6;
    float2 _1596 = _1594 + _1595;
    return _1596;
  }

  float _1598 = *quarterDepth@2;
  float _1599 = *surfaceDepth@2;
  bool _1600 = _1598 >= _1599;
  
  if(_1600) {
    float2 _1603 = *uv@7;
    float2 _1604 = *offset@6;
    float2 _1606 = _1604 * 0.2500;
    float2 _1607 = _1603 + _1606;
    return _1607;
  }

  float2 _1609 = *uv@7;
  return _1609;
}

float2 sceneRefractionMirrorUv(float2* uv@8) {
  float2 _1612 = *uv@8;
  float2 _1613 = CompositeConstruct({2.0000, 2.0000});
  float2 _1614 = FMod(_1612, _1613);
  float2 _1615 = CompositeConstruct({1.0000, 1.0000});
  float2 _1616 = _1614 - _1615;
  float2 _1617 = GLSL.std.450::FAbs(_1616);
  float2 _1618 = CompositeConstruct({1.0000, 1.0000});
  float2 _1619 = _1618 - _1617;
  return _1619;
}

float3 sceneRefractionSurface(float3* diffuse@2, float3* specular@2, float3* background@2, float* alpha@2, float* contribution@3) {
  float* param@399;
  float* param@400;
  float3 _1622 = *diffuse@2;
  float3 _1623 = *specular@2;
  float3 _1624 = *background@2;
  float _1626 = *alpha@2;
  *param@399 = _1626;
  float _1628 = *contribution@3;
  *param@400 = _1628;
  float _1629 = sceneRefractionWeight(param@399, param@400);
  float3 _1630 = CompositeConstruct({_1629, _1629, _1629});
  float3 _1631 = GLSL.std.450::FMix(_1623, _1624, _1630);
  float3 _1632 = _1622 + _1631;
  return _1632;
}

float3 toonIndirectChroma(float3* ramp@4, float* toonWeight@2, uint* materialClass) {
  float* peak;
  uint _1635 = *materialClass;
  bool _1636 = _1635 != 1;
  uint _1637 = *materialClass;
  bool _1638 = _1637 != 2;
  bool _1639 = _1636 && _1638;
  
  if(_1639) {
    return {1.0000, 1.0000, 1.0000};
  }

  float* _1645 = &ramp@4.x;
  float _1646 = *_1645;
  float* _1647 = &ramp@4.y;
  float _1648 = *_1647;
  float _1649 = GLSL.std.450::FMax(_1646, _1648);
  float* _1650 = &ramp@4.z;
  float _1651 = *_1650;
  float _1652 = GLSL.std.450::FMax(_1649, _1651);
  *peak = _1652;
  float _1653 = *peak;
  bool _1655 = _1653 <= 0.0001;
  
  if(_1655) {
    return {1.0000, 1.0000, 1.0000};
  }

  float3 _1659 = *ramp@4;
  float _1660 = *peak;
  float3 _1661 = CompositeConstruct({_1660, _1660, _1660});
  float3 _1662 = _1659 / _1661;
  float _1663 = *toonWeight@2;
  float _1664 = GLSL.std.450::FClamp(_1663, 0.0000, 1.0000);
  float _1665 = 0.5000 * _1664;
  float3 _1666 = CompositeConstruct({_1665, _1665, _1665});
  float3 _1667 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, _1662, _1666);
  return _1667;
}

float3 directSurfaceSpecular(float3* f0@2, float* roughness@2, float* nl, float* nv, float* nh, float* vh) {
  float* alpha@3;
  float* alphaSquared;
  float* denominator;
  float* distribution;
  float* lambdaView;
  float* lambdaLight;
  float* visibility@4;
  float3* fresnel@2;
  float _1670 = *nl;
  bool _1671 = _1670 <= 0.0000;
  float _1672 = *nv;
  bool _1673 = _1672 <= 0.0000;
  bool _1674 = _1671 || _1673;
  
  if(_1674) {
    return {0.0000, 0.0000, 0.0000};
  }

  float _1679 = *roughness@2;
  float _1680 = *roughness@2;
  float _1681 = _1679 * _1680;
  float _1682 = GLSL.std.450::FMax(_1681, 0.0010);
  *alpha@3 = _1682;
  float _1684 = *alpha@3;
  float _1685 = *alpha@3;
  float _1686 = _1684 * _1685;
  *alphaSquared = _1686;
  float _1688 = *nh;
  float _1689 = *nh;
  float _1690 = _1688 * _1689;
  float _1691 = *alphaSquared;
  float _1692 = _1691 - 1.0000;
  float _1693 = _1690 * _1692;
  float _1694 = _1693 + 1.0000;
  *denominator = _1694;
  float _1696 = *alphaSquared;
  float _1698 = *denominator;
  float _1699 = 3.1416 * _1698;
  float _1700 = *denominator;
  float _1701 = _1699 * _1700;
  float _1702 = _1696 / _1701;
  *distribution = _1702;
  float _1704 = *nl;
  float _1705 = *nv;
  float _1706 = *nv;
  float _1707 = _1705 * _1706;
  float _1708 = *alphaSquared;
  float _1709 = 1.0000 - _1708;
  float _1710 = _1707 * _1709;
  float _1711 = *alphaSquared;
  float _1712 = _1710 + _1711;
  float _1713 = GLSL.std.450::Sqrt(_1712);
  float _1714 = _1704 * _1713;
  *lambdaView = _1714;
  float _1716 = *nv;
  float _1717 = *nl;
  float _1718 = *nl;
  float _1719 = _1717 * _1718;
  float _1720 = *alphaSquared;
  float _1721 = 1.0000 - _1720;
  float _1722 = _1719 * _1721;
  float _1723 = *alphaSquared;
  float _1724 = _1722 + _1723;
  float _1725 = GLSL.std.450::Sqrt(_1724);
  float _1726 = _1716 * _1725;
  *lambdaLight = _1726;
  float _1728 = *lambdaView;
  float _1729 = *lambdaLight;
  float _1730 = _1728 + _1729;
  float _1732 = GLSL.std.450::FMax(_1730, 0.0000);
  float _1733 = 0.5000 / _1732;
  *visibility@4 = _1733;
  float3 _1735 = *f0@2;
  float3 _1736 = *f0@2;
  float3 _1737 = {1.0000, 1.0000, 1.0000} - _1736;
  float _1738 = *vh;
  float _1739 = GLSL.std.450::FClamp(_1738, 0.0000, 1.0000);
  float _1740 = 1.0000 - _1739;
  float _1742 = GLSL.std.450::Pow(_1740, 5.0000);
  float3 _1743 = _1737 * _1742;
  float3 _1744 = _1735 + _1743;
  *fresnel@2 = _1744;
  float _1745 = *distribution;
  float _1746 = *visibility@4;
  float _1747 = _1745 * _1746;
  float3 _1748 = *fresnel@2;
  float3 _1749 = _1748 * _1747;
  float _1750 = *nl;
  float3 _1751 = _1749 * _1750;
  return _1751;
}

float characterMainRampCoordinate(float3* normal, float3* incoming, float* bias) {
  float3 _1754 = *normal;
  float3 _1755 = *incoming;
  float _1756 = Dot(_1754, _1755);
  float _1757 = *bias;
  float _1758 = _1756 + _1757;
  float _1759 = GLSL.std.450::FClamp(_1758, -1.0000, 1.0000);
  float _1760 = _1759 * 0.5000;
  float _1761 = _1760 + 0.5000;
  return _1761;
}

float3 characterDiffuseViewTint(float3* base@2, float3* normal@2, float3* view, float4* tint) {
  float* weight@3;
  float3 _1765 = *normal@2;
  float3 _1766 = *view;
  float _1767 = Dot(_1765, _1766);
  float _1768 = GLSL.std.450::FClamp(_1767, 0.0000, 1.0000);
  float _1769 = 1.0000 - _1768;
  float* _1770 = &tint.w;
  float _1771 = *_1770;
  float _1772 = _1769 * _1771;
  float _1773 = GLSL.std.450::FClamp(_1772, 0.0000, 1.0000);
  *weight@3 = _1773;
  float3 _1774 = *base@2;
  float4 _1775 = *tint;
  float3 _1776 = _1775.xyz;
  float _1777 = *weight@3;
  float3 _1778 = CompositeConstruct({_1777, _1777, _1777});
  float3 _1779 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, _1776, _1778);
  float3 _1780 = _1774 * _1779;
  return _1780;
}

float3 worldHorizontalDiffuseNormal(float3* normal@3) {
  float* _1783 = &normal@3.x;
  float _1784 = *_1783;
  float* _1785 = &normal@3.z;
  float _1786 = *_1785;
  float3 _1787 = CompositeConstruct({_1784, 0.0001, _1786});
  float3 _1788 = GLSL.std.450::Normalize(_1787);
  return _1788;
}

float3 faceFrameRadialHorizontalDiffuseNormal(float3* worldPosition@2, float3* frameOrigin, float3* geometryNormal@2, float* geometryMix@4) {
  float3* radial@2;
  float3* param@401;
  float3* geometry@2;
  float3* param@402;
  float3* blended@4;
  float3* _1811;
  float3 _1792 = *worldPosition@2;
  float3 _1793 = *frameOrigin;
  float3 _1794 = _1792 - _1793;
  *param@401 = _1794;
  float3 _1796 = worldHorizontalDiffuseNormal(param@401);
  *radial@2 = _1796;
  float3 _1799 = *geometryNormal@2;
  *param@402 = _1799;
  float3 _1800 = worldHorizontalDiffuseNormal(param@402);
  *geometry@2 = _1800;
  float3 _1802 = *radial@2;
  float3 _1803 = *geometry@2;
  float _1804 = *geometryMix@4;
  float3 _1805 = CompositeConstruct({_1804, _1804, _1804});
  float3 _1806 = GLSL.std.450::FMix(_1802, _1803, _1805);
  *blended@4 = _1806;
  float3 _1807 = *blended@4;
  float3 _1808 = *blended@4;
  float _1809 = Dot(_1807, _1808);
  bool _1810 = _1809 > 0.0000;
  
  if(_1810) {
    float3 _1814 = *blended@4;
    float3 _1815 = GLSL.std.450::Normalize(_1814);
    *_1811 = _1815;
  } else {
    float3 _1817 = *geometry@2;
    *_1811 = _1817;
  }

  float3 _1818 = *_1811;
  return _1818;
}

float characterDiffuseLuma(float3* color) {
  float3 _1821 = *color;
  float _1826 = Dot(_1821, {0.2127, 0.7152, 0.0722});
  return _1826;
}

float3 characterLocalLightRadiance(float3* incident@3, float* normalDotLight@2, float2* response@4, float* sceneVisibility) {
  float* denominator@2;
  float* compression;
  float* wrapped;
  float* _1830 = &incident@3.x;
  float _1831 = *_1830;
  float* _1832 = &incident@3.y;
  float _1833 = *_1832;
  float _1834 = GLSL.std.450::FMax(_1831, _1833);
  float* _1835 = &incident@3.z;
  float _1836 = *_1835;
  float _1837 = GLSL.std.450::FMax(_1834, _1836);
  float _1838 = *sceneVisibility;
  float _1839 = 0.2500 * _1838;
  float _1840 = 0.5000 + _1839;
  float _1841 = _1837 * _1840;
  float _1842 = GLSL.std.450::FMax(_1841, 1.0000);
  *denominator@2 = _1842;
  float* _1844 = &response@4.y;
  float _1845 = *_1844;
  float _1846 = 1.0000 - _1845;
  float* _1847 = &response@4.y;
  float _1848 = *_1847;
  float _1849 = *denominator@2;
  float _1850 = _1848 / _1849;
  float _1851 = _1846 + _1850;
  *compression = _1851;
  float* _1853 = &response@4.x;
  float _1854 = *_1853;
  float _1855 = *normalDotLight@2;
  float _1856 = _1855 + 0.5000;
  float _1857 = GLSL.std.450::FClamp(_1856, 0.0000, 1.0000);
  float* _1858 = &response@4.x;
  float _1859 = *_1858;
  float _1860 = 1.0000 - _1859;
  float _1861 = _1857 * _1860;
  float _1862 = _1854 + _1861;
  *wrapped = _1862;
  float3 _1863 = *incident@3;
  float _1864 = *compression;
  float _1865 = *wrapped;
  float _1866 = _1864 * _1865;
  float3 _1867 = _1863 * _1866;
  return _1867;
}

float3 characterDiffuseSaturation(float3* color@2, float* amount) {
  float3* param@403;
  float3 _1871 = *color@2;
  *param@403 = _1871;
  float _1872 = characterDiffuseLuma(param@403);
  float3 _1873 = CompositeConstruct({_1872, _1872, _1872});
  float3 _1874 = *color@2;
  float _1875 = *amount;
  float3 _1876 = CompositeConstruct({_1875, _1875, _1875});
  float3 _1877 = GLSL.std.450::FMix(_1873, _1874, _1876);
  return _1877;
}

float characterMainBrightnessSaturation(float3* color@3) {
  float* high;
  float3* param@404;
  float3 _1882 = *color@3;
  *param@404 = _1882;
  float _1883 = characterDiffuseLuma(param@404);
  float _1884 = _1883 - 0.5000;
  float _1885 = GLSL.std.450::FClamp(_1884, 0.0000, 0.5000);
  *high = _1885;
  float _1886 = *high;
  float _1887 = *high;
  float _1888 = _1886 * _1887;
  float _1889 = 1.0000 + _1888;
  return _1889;
}

CharacterDiffuseIllumination characterDiffuseIllumination(float3* normal@4, float3* indirectRadiance, float4* mainRadiance@2, float4* directionBias, float4* gainFloor, float4* composition, float* indoorMix, float* ambientOcclusion, float* litMask, float* visibility@5) {
  float* directional;
  float3* incident@4;
  float* shadowWeight@2;
  float3* shadow;
  float3* ambient;
  float3* direct;
  float3* param@405;
  float* param@406;
  float3 _1893 = *normal@4;
  float4 _1894 = *directionBias;
  float3 _1895 = _1894.xyz;
  float _1896 = Dot(_1893, _1895);
  float* _1897 = &directionBias.w;
  float _1898 = *_1897;
  float _1899 = _1896 + _1898;
  float _1900 = GLSL.std.450::FClamp(_1899, 0.0000, 1.0000);
  float* _1901 = &gainFloor.x;
  float _1902 = *_1901;
  float _1903 = _1900 * _1902;
  float* _1904 = &gainFloor.y;
  float _1905 = *_1904;
  float _1906 = _1903 + _1905;
  *directional = _1906;
  float _1908 = *directional;
  float3 _1909 = *indirectRadiance;
  float _1910 = *litMask;
  float* _1911 = &composition.z;
  float _1912 = *_1911;
  float _1913 = _1910 * _1912;
  float3 _1914 = CompositeConstruct({_1913, _1913, _1913});
  float3 _1915 = GLSL.std.450::FMix(_1909, {1.0000, 1.0000, 1.0000}, _1914);
  float3 _1916 = _1915 * _1908;
  *incident@4 = _1916;
  float _1920 = *ambientOcclusion;
  float _1921 = 0.3500 * _1920;
  float _1922 = 0.6500 + _1921;
  float _1924 = GLSL.std.450::FMin(_1922, 1.5000);
  float _1925 = *ambientOcclusion;
  float _1928 = GLSL.std.450::FClamp(_1925, 1.2500, 1.7500);
  float _1929 = *indoorMix;
  float _1930 = GLSL.std.450::FMix(_1924, _1928, _1929);
  *shadowWeight@2 = _1930;
  float3 _1932 = *incident@4;
  float _1933 = *shadowWeight@2;
  float3 _1934 = _1932 * _1933;
  float* _1935 = &composition.y;
  float _1936 = *_1935;
  float3 _1937 = _1934 * _1936;
  *shadow = _1937;
  float3 _1939 = *incident@4;
  float _1940 = *ambientOcclusion;
  float _1941 = GLSL.std.450::FClamp(_1940, 0.0000, 1.5000);
  float3 _1942 = _1939 * _1941;
  float4 _1943 = *mainRadiance@2;
  float3 _1944 = _1943.xyz;
  float* _1945 = &composition.w;
  float _1946 = *_1945;
  float3 _1947 = CompositeConstruct({_1946, _1946, _1946});
  float3 _1948 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, _1944, _1947);
  float3 _1949 = _1942 * _1948;
  float* _1950 = &composition.x;
  float _1951 = *_1950;
  float3 _1952 = _1949 * _1951;
  *ambient = _1952;
  float4 _1954 = *mainRadiance@2;
  float3 _1955 = _1954.xyz;
  float* _1956 = &mainRadiance@2.w;
  float _1957 = *_1956;
  float3 _1958 = _1955 * _1957;
  *param@405 = _1958;
  float _1961 = *litMask;
  *param@406 = _1961;
  float3 _1962 = characterDiffuseSaturation(param@405, param@406);
  float* _1963 = &composition.x;
  float _1964 = *_1963;
  float3 _1965 = _1962 * _1964;
  *direct = _1965;
  float3 _1966 = *shadow;
  float3 _1967 = *ambient;
  float _1968 = *visibility@5;
  float3 _1969 = CompositeConstruct({_1968, _1968, _1968});
  float3 _1970 = GLSL.std.450::FMix(_1966, _1967, _1969);
  float3 _1971 = *direct;
  float _1972 = *visibility@5;
  float3 _1973 = _1971 * _1972;
  CharacterDiffuseIllumination _1974 = CompositeConstruct({_1970, _1973});
  return _1974;
}

CharacterDiffuseResponse characterDiffuseColorResponse(float3* lit, float3* shadow@2, float3* indoorLit, float4* ramp@5, float* litMask@2, float* aoMask, float* shadowMix, float* sceneVisibility@2) {
  float3* shadowColor;
  float3* param@407;
  float* param@408;
  float3* untinted;
  float* chroma;
  float3* tinted;
  float3* indoor;
  float3* outdoor;
  float3* param@409;
  float3* param@410;
  float3 _1978 = *shadow@2;
  float3 _1979 = _1978 * 0.6500;
  *param@407 = _1979;
  *param@408 = 1.2000;
  float3 _1983 = characterDiffuseSaturation(param@407, param@408);
  float3 _1984 = *shadow@2;
  float _1985 = *shadowMix;
  float3 _1986 = CompositeConstruct({_1985, _1985, _1985});
  float3 _1987 = GLSL.std.450::FMix(_1983, _1984, _1986);
  *shadowColor = _1987;
  float3 _1989 = *shadowColor;
  float3 _1990 = *lit;
  float _1991 = *litMask@2;
  float3 _1992 = CompositeConstruct({_1991, _1991, _1991});
  float3 _1993 = GLSL.std.450::FMix(_1989, _1990, _1992);
  *untinted = _1993;
  float* _1995 = &ramp@5.x;
  float _1996 = *_1995;
  float* _1997 = &ramp@5.y;
  float _1998 = *_1997;
  float _1999 = GLSL.std.450::FMax(_1996, _1998);
  float* _2000 = &ramp@5.z;
  float _2001 = *_2000;
  float _2002 = GLSL.std.450::FMax(_1999, _2001);
  float* _2003 = &ramp@5.x;
  float _2004 = *_2003;
  float* _2005 = &ramp@5.y;
  float _2006 = *_2005;
  float _2007 = GLSL.std.450::FMin(_2004, _2006);
  float* _2008 = &ramp@5.z;
  float _2009 = *_2008;
  float _2010 = GLSL.std.450::FMin(_2007, _2009);
  float _2011 = _2002 - _2010;
  *chroma = _2011;
  float3 _2013 = *untinted;
  float _2014 = *chroma;
  float _2015 = 1.0000 - _2014;
  float3 _2016 = CompositeConstruct({_2015, _2015, _2015});
  float4 _2017 = *ramp@5;
  float3 _2018 = _2017.xyz;
  float _2019 = *chroma;
  float3 _2020 = _2018 * _2019;
  float3 _2021 = _2016 + _2020;
  float3 _2022 = _2013 * _2021;
  *tinted = _2022;
  float3 _2024 = *shadow@2;
  float3 _2025 = *indoorLit;
  float _2026 = *aoMask;
  float3 _2027 = CompositeConstruct({_2026, _2026, _2026});
  float3 _2028 = GLSL.std.450::FMix(_2024, _2025, _2027);
  *indoor = _2028;
  float3 _2030 = *tinted;
  float3 _2032 = *untinted;
  *param@409 = _2032;
  float _2033 = characterDiffuseLuma(param@409);
  float3 _2035 = *tinted;
  *param@410 = _2035;
  float _2036 = characterDiffuseLuma(param@410);
  float _2037 = GLSL.std.450::FMax(_2036, 0.0010);
  float _2038 = _2033 / _2037;
  float _2039 = GLSL.std.450::FClamp(_2038, 0.0000, 1.5000);
  float3 _2040 = _2030 * _2039;
  *outdoor = _2040;
  float3 _2041 = *indoor;
  float3 _2042 = *outdoor;
  float _2043 = *sceneVisibility@2;
  float3 _2044 = CompositeConstruct({_2043, _2043, _2043});
  float3 _2045 = GLSL.std.450::FMix(_2041, _2042, _2044);
  float _2046 = *litMask@2;
  float _2047 = *aoMask;
  CharacterDiffuseResponse _2048 = CompositeConstruct({_2045, _2046, _2047});
  return _2048;
}

CharacterDiffuseResponse characterDiffuseWeightedResponse(float3* litAlbedo, float3* shadowAlbedo, float* metallic@2, float* shadowScale, float4* ramp@6, float* litMask@3, float* aoMask@2, float* shadowMix@2, float* sceneVisibility@3) {
  float3* lit@2;
  float3* shadow@3;
  float3* param@411;
  float* param@412;
  float3* param@413;
  float3* param@414;
  float3* param@415;
  float4* param@416;
  float* param@417;
  float* param@418;
  float* param@419;
  float* param@420;
  float3 _2052 = *litAlbedo;
  float _2054 = *metallic@2;
  float _2055 = 1.0000 - _2054;
  float _2056 = 0.9600 * _2055;
  float3 _2057 = _2052 * _2056;
  *lit@2 = _2057;
  float3 _2059 = *shadowAlbedo;
  float _2060 = *metallic@2;
  float _2061 = 1.0000 - _2060;
  float _2062 = 0.9600 * _2061;
  float _2063 = *shadowScale;
  float _2064 = _2062 * _2063;
  float3 _2065 = _2059 * _2064;
  *shadow@3 = _2065;
  float3 _2067 = *lit@2;
  *param@411 = _2067;
  *param@412 = 1.2000;
  float3 _2069 = characterDiffuseSaturation(param@411, param@412);
  float3 _2071 = *lit@2;
  *param@413 = _2071;
  float3 _2073 = *shadow@3;
  *param@414 = _2073;
  *param@415 = _2069;
  float4 _2076 = *ramp@6;
  *param@416 = _2076;
  float _2078 = *litMask@3;
  *param@417 = _2078;
  float _2080 = *aoMask@2;
  *param@418 = _2080;
  float _2082 = *shadowMix@2;
  *param@419 = _2082;
  float _2084 = *sceneVisibility@3;
  *param@420 = _2084;
  CharacterDiffuseResponse _2085 = characterDiffuseColorResponse(param@413, param@414, param@415, param@416, param@417, param@418, param@419, param@420);
  return _2085;
}

CharacterDiffuseResponse characterDiffuseResponse(float3* litAlbedo@2, float3* shadowAlbedo@2, float* metallic@3, float* shadowScale@2, float4* ramp@7, float* baseAo, float2* shadowMask, float* cameraFacing, float* characterVisibility, float* sceneVisibility@4) {
  float* cameraWeight;
  float* mask;
  float* visibility@6;
  float* litMask@4;
  float* aoMask@3;
  float* shadowMix@3;
  float3* param@421;
  float3* param@422;
  float* param@423;
  float* param@424;
  float4* param@425;
  float* param@426;
  float* param@427;
  float* param@428;
  float* param@429;
  float _2089 = *cameraFacing;
  float _2091 = _2089 - 0.7500;
  float _2093 = _2091 / -0.5000;
  float _2094 = GLSL.std.450::FClamp(_2093, 0.0000, 1.0000);
  *cameraWeight = _2094;
  float _2095 = *cameraWeight;
  float _2096 = *cameraWeight;
  float _2097 = _2095 * _2096;
  float _2098 = *cameraWeight;
  float _2099 = 2.0000 * _2098;
  float _2100 = 3.0000 - _2099;
  float _2101 = _2097 * _2100;
  *cameraWeight = _2101;
  float* _2103 = &shadowMask.x;
  float _2104 = *_2103;
  float* _2105 = &shadowMask.y;
  float _2106 = *_2105;
  float _2107 = *cameraWeight;
  float _2108 = _2106 * _2107;
  float _2109 = GLSL.std.450::FMax(_2104, _2108);
  *mask = _2109;
  float _2111 = *characterVisibility;
  float _2112 = *mask;
  float _2113 = GLSL.std.450::FMix(1.0000, _2111, _2112);
  *visibility@6 = _2113;
  float _2115 = *visibility@6;
  float _2116 = *baseAo;
  float _2117 = GLSL.std.450::FMin(_2115, _2116);
  float* _2118 = &ramp@7.w;
  float _2119 = *_2118;
  float _2120 = GLSL.std.450::FMin(_2117, _2119);
  *litMask@4 = _2120;
  float _2122 = *baseAo;
  float _2123 = *visibility@6;
  float _2124 = _2122 * _2123;
  *aoMask@3 = _2124;
  float _2126 = *baseAo;
  float* _2127 = &shadowMask.x;
  float _2128 = *_2127;
  float _2129 = 1.0000 - _2128;
  float _2130 = *visibility@6;
  float* _2131 = &shadowMask.x;
  float _2132 = *_2131;
  float _2133 = _2130 * _2132;
  float _2134 = _2129 + _2133;
  float _2135 = _2126 * _2134;
  float* _2136 = &ramp@7.w;
  float _2137 = *_2136;
  float _2138 = _2135 + _2137;
  float _2139 = GLSL.std.450::FClamp(_2138, 0.0000, 1.0000);
  *shadowMix@3 = _2139;
  float3 _2141 = *litAlbedo@2;
  *param@421 = _2141;
  float3 _2143 = *shadowAlbedo@2;
  *param@422 = _2143;
  float _2145 = *metallic@3;
  *param@423 = _2145;
  float _2147 = *shadowScale@2;
  *param@424 = _2147;
  float4 _2149 = *ramp@7;
  *param@425 = _2149;
  float _2151 = *litMask@4;
  *param@426 = _2151;
  float _2153 = *aoMask@3;
  *param@427 = _2153;
  float _2155 = *shadowMix@3;
  *param@428 = _2155;
  float _2157 = *sceneVisibility@4;
  *param@429 = _2157;
  CharacterDiffuseResponse _2158 = characterDiffuseWeightedResponse(param@421, param@422, param@423, param@424, param@425, param@426, param@427, param@428, param@429);
  return _2158;
}

float specularRampDot(float3* a, float3* b) {
  float* xy;
  float* result;
  float* _2162 = &a.x;
  float _2163 = *_2162;
  float* _2164 = &b.x;
  float _2165 = *_2164;
  float _2166 = _2163 * _2165;
  float* _2167 = &a.y;
  float _2168 = *_2167;
  float* _2169 = &b.y;
  float _2170 = *_2169;
  float _2171 = _2168 * _2170;
  float _2172 = _2166 + _2171;
  *xy = _2172;
  float _2174 = *xy;
  float* _2175 = &a.z;
  float _2176 = *_2175;
  float* _2177 = &b.z;
  float _2178 = *_2177;
  float _2179 = _2176 * _2178;
  float _2180 = _2174 + _2179;
  *result = _2180;
  float _2181 = *result;
  return _2181;
}

float3 specularRampDirection(float3* value@2, float3* fallbackValue) {
  float* squared;
  float3* _2190;
  float3 _2185 = *value@2;
  float3 _2186 = *value@2;
  float _2187 = Dot(_2185, _2186);
  *squared = _2187;
  float _2188 = *squared;
  bool _2189 = _2188 > 0.0000;
  
  if(_2189) {
    float3 _2193 = *value@2;
    float _2194 = *squared;
    float _2195 = GLSL.std.450::InverseSqrt(_2194);
    float3 _2196 = _2193 * _2195;
    *_2190 = _2196;
  } else {
    float3 _2198 = *fallbackValue;
    *_2190 = _2198;
  }

  float3 _2199 = *_2190;
  return _2199;
}

SpecularRampCoordinates specularRampCoordinates(float3* normal@5, float3* view@2, float3* camera@2, float3* light@2, float* roughness@3, float* metallic@4, float* visibility@7, float* iridescence) {
  float3* adjusted@2;
  float3* q;
  float3* param@430;
  float3* param@431;
  float3* param@432;
  float3* param@433;
  float3* halfVector;
  float3* param@434;
  float3* param@435;
  float* nh@2;
  float3* param@436;
  float3* param@437;
  float* nv@2;
  float3* param@438;
  float3* param@439;
  float* alpha@4;
  float* alpha2;
  float* difference@2;
  float* denominator@3;
  float* distribution@2;
  float* _2279;
  float* lobe;
  float* _2203 = &camera@2.x;
  float _2204 = *_2203;
  float* _2205 = &light@2.y;
  float _2206 = *_2205;
  float _2207 = *visibility@7;
  float _2208 = GLSL.std.450::FMix(0.5000, _2206, _2207);
  float* _2209 = &camera@2.z;
  float _2210 = *_2209;
  float3 _2211 = CompositeConstruct({_2204, _2208, _2210});
  *adjusted@2 = _2211;
  float3 _2215 = *camera@2;
  *param@430 = _2215;
  *param@431 = {0.0000, 0.0000, 1.0000};
  float3 _2217 = specularRampDirection(param@430, param@431);
  float3 _2219 = *adjusted@2;
  *param@432 = _2219;
  *param@433 = _2217;
  float3 _2221 = specularRampDirection(param@432, param@433);
  *q = _2221;
  float3 _2223 = *light@2;
  float _2224 = *visibility@7;
  float3 _2225 = _2223 * _2224;
  float3 _2226 = *q;
  float3 _2227 = _2226 * 2.0000;
  float3 _2228 = _2225 + _2227;
  float3 _2229 = *view@2;
  float _2230 = *visibility@7;
  float _2231 = _2230 + 2.0000;
  float3 _2232 = _2229 * _2231;
  float3 _2233 = _2228 + _2232;
  *param@434 = _2233;
  float3 _2236 = *view@2;
  *param@435 = _2236;
  float3 _2237 = specularRampDirection(param@434, param@435);
  *halfVector = _2237;
  float3 _2240 = *normal@5;
  *param@436 = _2240;
  float3 _2242 = *halfVector;
  *param@437 = _2242;
  float _2243 = specularRampDot(param@436, param@437);
  *nh@2 = _2243;
  float3 _2246 = *normal@5;
  *param@438 = _2246;
  float3 _2248 = *view@2;
  *param@439 = _2248;
  float _2249 = specularRampDot(param@438, param@439);
  float _2250 = GLSL.std.450::FClamp(_2249, 0.0000, 1.0000);
  *nv@2 = _2250;
  float _2252 = *roughness@3;
  float _2253 = *roughness@3;
  float _2254 = _2252 * _2253;
  float _2256 = GLSL.std.450::FMax(_2254, 0.0078);
  *alpha@4 = _2256;
  float _2258 = *alpha@4;
  float _2259 = *alpha@4;
  float _2260 = _2258 * _2259;
  *alpha2 = _2260;
  float _2262 = *nh@2;
  float _2263 = *alpha2;
  float _2264 = _2262 * _2263;
  float _2265 = *nh@2;
  float _2266 = _2264 - _2265;
  *difference@2 = _2266;
  float _2268 = *difference@2;
  float _2269 = *nh@2;
  float _2270 = _2268 * _2269;
  float _2271 = _2270 + 1.0000;
  *denominator@3 = _2271;
  float _2272 = *denominator@3;
  float _2273 = *denominator@3;
  float _2274 = _2273 * _2272;
  *denominator@3 = _2274;
  float _2276 = *alpha2;
  float _2277 = *denominator@3;
  bool _2278 = _2276 == _2277;
  
  if(_2278) {
    *_2279 = 1.0000;
  } else {
    float _2283 = *alpha2;
    float _2284 = *denominator@3;
    float _2285 = _2283 / _2284;
    *_2279 = _2285;
  }

  float _2286 = *_2279;
  *distribution@2 = _2286;
  float _2288 = *distribution@2;
  float _2289 = _2288 * 0.5000;
  float _2290 = *nv@2;
  float _2291 = 2.0000 * _2290;
  float _2292 = *alpha@4;
  float _2293 = _2291 + _2292;
  float _2294 = _2293 + 0.0001;
  float _2295 = _2289 / _2294;
  float _2296 = _2295 - 0.0001;
  float _2298 = GLSL.std.450::FClamp(_2296, 0.0000, 20.0000);
  *lobe = _2298;
  float _2299 = *distribution@2;
  float _2300 = *alpha2;
  float _2301 = _2300 + 0.0001;
  float _2302 = _2299 * _2301;
  float _2303 = *nv@2;
  float _2304 = *nv@2;
  float _2305 = _2303 * _2304;
  float _2306 = *iridescence;
  float _2307 = GLSL.std.450::FMix(_2302, _2305, _2306);
  float _2308 = *roughness@3;
  float _2309 = *metallic@4;
  float _2310 = 1.0000 - _2309;
  float _2311 = _2308 * _2310;
  float2 _2312 = CompositeConstruct({_2307, _2311});
  float _2313 = *lobe;
  float _2314 = *distribution@2;
  SpecularRampCoordinates _2315 = CompositeConstruct({_2312, _2313, _2314});
  return _2315;
}

float specularRampFullDiffuse(float* viewAlpha@2, float* aoMask@4, float* litMask@5, float* visibility@8) {
  float _2318 = *viewAlpha@2;
  float _2319 = *aoMask@4;
  float _2320 = _2318 * _2319;
  float _2321 = *litMask@5;
  float _2322 = *visibility@8;
  float _2323 = GLSL.std.450::FMix(_2320, _2321, _2322);
  return _2323;
}

float3 specularRampMain(float3* reflectance, float3* ramp@8, float* lobe@2, float* fullDiffuse@2, float4* mainRadiance@3, float* floorValue) {
  float3 _2326 = *reflectance;
  float3 _2327 = *ramp@8;
  float3 _2328 = _2326 * _2327;
  float _2329 = *lobe@2;
  float3 _2330 = _2328 * _2329;
  float4 _2331 = *mainRadiance@3;
  float3 _2332 = _2331.xyz;
  float3 _2333 = _2330 * _2332;
  float* _2334 = &mainRadiance@3.w;
  float _2335 = *_2334;
  float3 _2336 = _2333 * _2335;
  float _2337 = *fullDiffuse@2;
  float _2338 = 0.5000 * _2337;
  float _2339 = 0.5000 + _2338;
  float3 _2340 = _2336 * _2339;
  float _2341 = *floorValue;
  float _2342 = *fullDiffuse@2;
  float _2343 = GLSL.std.450::FMix(_2341, 1.0000, _2342);
  float3 _2344 = _2340 * _2343;
  return _2344;
}

float3 specularRampEnvironment(float3* reflectance@2, float3* ramp@9, float* iridescence@2) {
  float3 _2347 = *reflectance@2;
  float3 _2348 = *reflectance@2;
  float3 _2349 = *ramp@9;
  float3 _2350 = _2348 * _2349;
  float _2351 = *iridescence@2;
  float3 _2352 = CompositeConstruct({_2351, _2351, _2351});
  float3 _2353 = GLSL.std.450::FMix(_2347, _2350, _2352);
  return _2353;
}

float3 ggxMultiscatterEnvironment(float3* f0@3, float* roughness@4, float* ndotv) {
  float* r;
  float* v;
  float* r2;
  float* r6;
  float* v2;
  float* v3;
  float* a@2;
  float* b@2;
  float _2357 = *roughness@4;
  float _2358 = GLSL.std.450::FClamp(_2357, 0.0000, 1.0000);
  *r = _2358;
  float _2360 = *ndotv;
  float _2361 = GLSL.std.450::FClamp(_2360, 0.0000, 1.0000);
  *v = _2361;
  float _2363 = *r;
  float _2364 = *r;
  float _2365 = _2363 * _2364;
  *r2 = _2365;
  float _2367 = *r2;
  float _2368 = *r2;
  float _2369 = _2367 * _2368;
  float _2370 = *r2;
  float _2371 = _2369 * _2370;
  *r6 = _2371;
  float _2373 = *v;
  float _2374 = *v;
  float _2375 = _2373 * _2374;
  *v2 = _2375;
  float _2377 = *v2;
  float _2378 = *v;
  float _2379 = _2377 * _2378;
  *v3 = _2379;
  float _2382 = *v;
  float _2383 = 3.3271 * _2382;
  float _2385 = _2383 + 0.0365;
  float _2387 = *v;
  float _2388 = -9.0476 * _2387;
  float _2390 = _2388 + 9.0632;
  float _2391 = *r2;
  float _2392 = _2390 * _2391;
  float _2393 = _2385 + _2392;
  float _2395 = *v2;
  float _2396 = 3.5968 * _2395;
  float _2398 = *v3;
  float _2399 = 1.3677 * _2398;
  float _2400 = _2396 - _2399;
  float _2401 = _2400 + 1.0000;
  float _2403 = *v2;
  float _2404 = -16.3174 * _2403;
  float _2406 = _2404 + 9.0440;
  float _2408 = *v3;
  float _2409 = 9.2295 * _2408;
  float _2410 = _2406 + _2409;
  float _2411 = *r2;
  float _2412 = _2410 * _2411;
  float _2413 = _2401 + _2412;
  float _2416 = *v2;
  float _2417 = 19.7886 * _2416;
  float _2418 = 5.5659 + _2417;
  float _2420 = *v3;
  float _2421 = 20.2123 * _2420;
  float _2422 = _2418 - _2421;
  float _2423 = *r6;
  float _2424 = _2422 * _2423;
  float _2425 = _2413 + _2424;
  float _2426 = _2393 / _2425;
  *a@2 = _2426;
  float _2429 = *v;
  float _2430 = -1.2851 * _2429;
  float _2432 = _2430 + 0.9904;
  float _2435 = *v;
  float _2436 = 0.7559 * _2435;
  float _2437 = 1.2968 - _2436;
  float _2438 = *r2;
  float _2439 = _2437 * _2438;
  float _2440 = _2432 + _2439;
  float _2442 = *v;
  float _2443 = 2.9234 * _2442;
  float _2445 = *v3;
  float _2446 = 59.4188 * _2445;
  float _2447 = _2443 + _2446;
  float _2448 = _2447 + 1.0000;
  float _2451 = *v;
  float _2452 = 27.0302 * _2451;
  float _2453 = 20.3225 - _2452;
  float _2455 = *v3;
  float _2456 = 222.5920 * _2455;
  float _2457 = _2453 + _2456;
  float _2458 = *r2;
  float _2459 = _2457 * _2458;
  float _2460 = _2448 + _2459;
  float _2462 = *v;
  float _2463 = 626.1300 * _2462;
  float _2465 = *v3;
  float _2466 = 316.6270 * _2465;
  float _2467 = _2463 + _2466;
  float _2469 = _2467 + 121.5630;
  float _2470 = *r6;
  float _2471 = _2469 * _2470;
  float _2472 = _2460 + _2471;
  float _2473 = _2440 / _2472;
  *b@2 = _2473;
  float3 _2474 = *f0@3;
  float _2475 = *a@2;
  float3 _2476 = _2474 * _2475;
  float _2477 = *b@2;
  float3 _2478 = CompositeConstruct({_2477, _2477, _2477});
  float3 _2479 = _2476 + _2478;
  float _2480 = *a@2;
  float _2481 = 1.0000 - _2480;
  float _2482 = *b@2;
  float _2483 = _2481 - _2482;
  float _2484 = *a@2;
  float _2485 = *b@2;
  float _2486 = _2484 + _2485;
  float _2487 = _2483 / _2486;
  float3 _2488 = *f0@3;
  float3 _2489 = _2488 * _2487;
  float3 _2490 = {1.0000, 1.0000, 1.0000} + _2489;
  float3 _2491 = _2479 * _2490;
  return _2491;
}

float reflectionProbeLod(float* roughness@5, float* lastMip@3, float3* mapping) {
  float* r@2;
  float* _2500;
  float _2495 = *roughness@5;
  float _2496 = GLSL.std.450::FClamp(_2495, 0.0000, 1.0000);
  *r@2 = _2496;
  float* _2497 = &mapping.z;
  float _2498 = *_2497;
  bool _2499 = _2498 > 0.0000;
  
  if(_2499) {
    float* _2503 = &mapping.x;
    float _2504 = *_2503;
    float _2505 = *r@2;
    float* _2506 = &mapping.z;
    float _2507 = *_2506;
    float _2508 = GLSL.std.450::FMax(_2505, _2507);
    float _2509 = GLSL.std.450::Log2(_2508);
    float _2510 = _2504 * _2509;
    float* _2511 = &mapping.y;
    float _2512 = *_2511;
    float _2513 = _2510 + _2512;
    float _2514 = *lastMip@3;
    float _2515 = GLSL.std.450::FClamp(_2513, 0.0000, _2514);
    *_2500 = _2515;
  } else {
    float _2517 = *r@2;
    float _2518 = *lastMip@3;
    float _2519 = _2517 * _2518;
    *_2500 = _2519;
  }

  float _2520 = *_2500;
  return _2520;
}

float2 reflectionSurfaceSign(float2* v@2) {
  float2 _2525 = *v@2;
  bool _2527 = _2525 >= {0.0000, 0.0000};
  float2 _2528 = Select(_2527, {1.0000, 1.0000}, {-1.0000, -1.0000});
  return _2528;
}

float3 decodeReflectionSurfaceNormal(float4* surface@2) {
  float2* p@5;
  float3* n;
  float2* param@440;
  float4 _2532 = *surface@2;
  float2 _2533 = _2532.yz;
  float2 _2534 = _2533 * 2.0000;
  float2 _2535 = CompositeConstruct({1.0000, 1.0000});
  float2 _2536 = _2534 - _2535;
  *p@5 = _2536;
  float2 _2538 = *p@5;
  float* _2539 = &p@5.x;
  float _2540 = *_2539;
  float _2541 = GLSL.std.450::FAbs(_2540);
  float _2542 = 1.0000 - _2541;
  float* _2543 = &p@5.y;
  float _2544 = *_2543;
  float _2545 = GLSL.std.450::FAbs(_2544);
  float _2546 = _2542 - _2545;
  float _2547 = _2538.x;
  float _2548 = _2538.y;
  float3 _2549 = CompositeConstruct({_2547, _2548, _2546});
  *n = _2549;
  float* _2550 = &n.z;
  float _2551 = *_2550;
  bool _2552 = _2551 < 0.0000;
  
  if(_2552) {
    float3 _2555 = *n;
    float2 _2556 = _2555.yx;
    float2 _2557 = GLSL.std.450::FAbs(_2556);
    float2 _2558 = CompositeConstruct({1.0000, 1.0000});
    float2 _2559 = _2558 - _2557;
    float3 _2561 = *n;
    float2 _2562 = _2561.xy;
    *param@440 = _2562;
    float2 _2563 = reflectionSurfaceSign(param@440);
    float2 _2564 = _2559 * _2563;
    float* _2565 = &n.x;
    float _2566 = _2564.x;
    *_2565 = _2566;
    float* _2567 = &n.y;
    float _2568 = _2564.y;
    *_2567 = _2568;
  }

  float3 _2569 = *n;
  float3 _2570 = GLSL.std.450::Normalize(_2569);
  return _2570;
}

float3 characterFacingRimResponse(float3* base@3, float* tint@2, float* width@2, float3* normal@6, float3* view@3, float3* light@3, float3* cameraAxis, float3* radial@3) {
  float3* planar;
  float* squared@2;
  float3* _2587;
  float* edge;
  float* band;
  float* visibility@9;
  float3 _2574 = *light@3;
  float3 _2575 = *cameraAxis;
  float3 _2576 = *light@3;
  float3 _2577 = *cameraAxis;
  float _2578 = Dot(_2576, _2577);
  float3 _2579 = _2575 * _2578;
  float3 _2580 = _2574 - _2579;
  *planar = _2580;
  float3 _2582 = *planar;
  float3 _2583 = *planar;
  float _2584 = Dot(_2582, _2583);
  *squared@2 = _2584;
  float _2585 = *squared@2;
  bool _2586 = _2585 > 0.0000;
  
  if(_2586) {
    float3 _2590 = *planar;
    float _2591 = *squared@2;
    float _2592 = GLSL.std.450::InverseSqrt(_2591);
    float3 _2593 = _2590 * _2592;
    *_2587 = _2593;
  } else {
    *_2587 = {0.0000, 0.0000, 0.0000};
  }

  float3 _2595 = *_2587;
  *planar = _2595;
  float3 _2597 = *normal@6;
  float3 _2598 = *view@3;
  float _2599 = Dot(_2597, _2598);
  float _2600 = GLSL.std.450::FAbs(_2599);
  float _2601 = 1.0000 - _2600;
  *edge = _2601;
  float _2603 = *edge;
  float _2606 = *width@2;
  float _2607 = 0.6000 * _2606;
  float _2608 = 0.8000 - _2607;
  float _2609 = _2603 - _2608;
  float _2612 = *width@2;
  float _2613 = 0.2000 * _2612;
  float _2614 = 0.1000 + _2613;
  float _2615 = _2609 / _2614;
  float _2616 = GLSL.std.450::FClamp(_2615, 0.0000, 1.0000);
  *band = _2616;
  float _2617 = *band;
  float _2618 = *band;
  float _2619 = _2617 * _2618;
  float _2620 = *band;
  float _2621 = 2.0000 * _2620;
  float _2622 = 3.0000 - _2621;
  float _2623 = _2619 * _2622;
  *band = _2623;
  float3 _2625 = *radial@3;
  float3 _2626 = *light@3;
  float _2627 = Dot(_2625, _2626);
  float _2628 = _2627 + 1.0000;
  float _2629 = GLSL.std.450::FClamp(_2628, 0.0000, 1.0000);
  *visibility@9 = _2629;
  float _2630 = *tint@2;
  float3 _2631 = *base@3;
  float3 _2632 = _2631 * 0.9600;
  float3 _2633 = CompositeConstruct({0.5000, 0.5000, 0.5000});
  float3 _2634 = _2632 - _2633;
  float3 _2635 = _2634 * _2630;
  float3 _2636 = CompositeConstruct({0.5000, 0.5000, 0.5000});
  float3 _2637 = _2636 + _2635;
  float _2638 = *band;
  float _2639 = *visibility@9;
  float _2640 = _2638 * _2639;
  float3 _2641 = *normal@6;
  float3 _2642 = *planar;
  float _2643 = Dot(_2641, _2642);
  float _2644 = GLSL.std.450::FClamp(_2643, 0.0000, 1.0000);
  float _2645 = _2640 * _2644;
  float3 _2646 = _2637 * _2645;
  return _2646;
}

float3 characterScreenRimResponse(float3* base@4, float* tint@3, float3* normal@7, float3* light@4, float3* cameraAxis@2, float3* radial@4, float* sceneDepth@4, float* surfaceDepth@3) {
  float3* planar@2;
  float* squared@3;
  float3* _2663;
  float* facing;
  float* depth@2;
  float* visibility@10;
  float3 _2650 = *light@4;
  float3 _2651 = *cameraAxis@2;
  float3 _2652 = *light@4;
  float3 _2653 = *cameraAxis@2;
  float _2654 = Dot(_2652, _2653);
  float3 _2655 = _2651 * _2654;
  float3 _2656 = _2650 - _2655;
  *planar@2 = _2656;
  float3 _2658 = *planar@2;
  float3 _2659 = *planar@2;
  float _2660 = Dot(_2658, _2659);
  *squared@3 = _2660;
  float _2661 = *squared@3;
  bool _2662 = _2661 > 0.0000;
  
  if(_2662) {
    float3 _2666 = *planar@2;
    float _2667 = *squared@3;
    float _2668 = GLSL.std.450::InverseSqrt(_2667);
    float3 _2669 = _2666 * _2668;
    *_2663 = _2669;
  } else {
    *_2663 = {0.0000, 0.0000, 0.0000};
  }

  float3 _2671 = *_2663;
  *planar@2 = _2671;
  float3 _2673 = *normal@7;
  float3 _2674 = *planar@2;
  float _2675 = Dot(_2673, _2674);
  float _2676 = GLSL.std.450::FClamp(_2675, 0.0000, 1.0000);
  *facing = _2676;
  float _2678 = *sceneDepth@4;
  float _2679 = *surfaceDepth@3;
  float _2680 = _2678 - _2679;
  float _2681 = _2680 - 0.1000;
  float _2683 = _2681 * 10.0000;
  float _2684 = GLSL.std.450::FClamp(_2683, 0.0000, 1.0000);
  *depth@2 = _2684;
  float3 _2686 = *radial@4;
  float3 _2687 = *light@4;
  float _2688 = Dot(_2686, _2687);
  float _2689 = _2688 + 1.0000;
  float _2690 = GLSL.std.450::FClamp(_2689, 0.0000, 1.0000);
  *visibility@10 = _2690;
  float _2691 = *tint@3;
  float3 _2692 = *base@4;
  float3 _2693 = _2692 * 0.9600;
  float3 _2694 = CompositeConstruct({0.5000, 0.5000, 0.5000});
  float3 _2695 = _2693 - _2694;
  float3 _2696 = _2695 * _2691;
  float3 _2697 = CompositeConstruct({0.5000, 0.5000, 0.5000});
  float3 _2698 = _2697 + _2696;
  float _2699 = *depth@2;
  float _2700 = *depth@2;
  float _2701 = _2699 * _2700;
  float _2702 = *depth@2;
  float _2703 = 2.0000 * _2702;
  float _2704 = 3.0000 - _2703;
  float _2705 = _2701 * _2704;
  float _2706 = *visibility@10;
  float _2707 = _2705 * _2706;
  float _2708 = *facing;
  float _2709 = _2707 * _2708;
  float3 _2710 = _2698 * _2709;
  return _2710;
}

float characterColorBlendWeight(float* attenuation@2, float* normalDotLight@3, float2* weights) {
  float* facing@2;
  float* smoothFacing;
  float _2714 = *normalDotLight@3;
  float _2715 = _2714 + 0.5000;
  float _2716 = GLSL.std.450::FClamp(_2715, 0.0000, 1.0000);
  *facing@2 = _2716;
  float _2718 = *facing@2;
  float _2719 = *facing@2;
  float _2720 = _2718 * _2719;
  float _2721 = *facing@2;
  float _2722 = 2.0000 * _2721;
  float _2723 = 3.0000 - _2722;
  float _2724 = _2720 * _2723;
  *smoothFacing = _2724;
  float _2725 = *attenuation@2;
  float* _2726 = &weights.x;
  float _2727 = *_2726;
  float _2728 = _2725 * _2727;
  float _2729 = *smoothFacing;
  float* _2730 = &weights.y;
  float _2731 = *_2730;
  float _2732 = GLSL.std.450::FMix(1.0000, _2729, _2731);
  float _2733 = _2728 * _2732;
  return _2733;
}

LineLightGeometry lineLightGeometry(float3* incoming@2, float3* axis, float* length) {
  float* squared@4;
  float3* centre;
  float3* _2743;
  float3* perpendicular;
  float* perpendicularSquared;
  float3* direction;
  float3* _2777;
  float3* a@3;
  float3* b@3;
  float* lengthA;
  float* lengthB;
  float* numerator;
  float* denominator@4;
  float3 _2737 = *incoming@2;
  float3 _2738 = *incoming@2;
  float _2739 = Dot(_2737, _2738);
  *squared@4 = _2739;
  float _2741 = *squared@4;
  bool _2742 = _2741 > 0.0000;
  
  if(_2742) {
    float3 _2746 = *incoming@2;
    float _2747 = *squared@4;
    float _2748 = GLSL.std.450::InverseSqrt(_2747);
    float3 _2749 = _2746 * _2748;
    *_2743 = _2749;
  } else {
    *_2743 = {0.0000, 0.0000, 1.0000};
  }

  float3 _2751 = *_2743;
  *centre = _2751;
  float _2752 = *length;
  bool _2753 = _2752 <= 0.0000;
  
  if(_2753) {
    float3 _2756 = *centre;
    float _2757 = *squared@4;
    float _2758 = 1.0000 + _2757;
    float _2759 = 1.0000 / _2758;
    LineLightGeometry _2760 = CompositeConstruct({_2756, _2759});
    return _2760;
  }

  float3 _2763 = *incoming@2;
  float3 _2764 = *axis;
  float3 _2765 = *incoming@2;
  float3 _2766 = *axis;
  float _2767 = Dot(_2765, _2766);
  float3 _2768 = _2764 * _2767;
  float3 _2769 = _2763 - _2768;
  *perpendicular = _2769;
  float3 _2771 = *perpendicular;
  float3 _2772 = *perpendicular;
  float _2773 = Dot(_2771, _2772);
  *perpendicularSquared = _2773;
  float _2775 = *perpendicularSquared;
  bool _2776 = _2775 > 0.0000;
  
  if(_2776) {
    float3 _2780 = *perpendicular;
    float _2781 = *perpendicularSquared;
    float _2782 = GLSL.std.450::InverseSqrt(_2781);
    float3 _2783 = _2780 * _2782;
    *_2777 = _2783;
  } else {
    float3 _2785 = *centre;
    *_2777 = _2785;
  }

  float3 _2786 = *_2777;
  *direction = _2786;
  float3 _2788 = *incoming@2;
  float3 _2789 = *axis;
  float _2790 = *length;
  float _2791 = _2790 * 0.5000;
  float3 _2792 = _2789 * _2791;
  float3 _2793 = _2788 - _2792;
  *a@3 = _2793;
  float3 _2795 = *incoming@2;
  float3 _2796 = *axis;
  float _2797 = *length;
  float _2798 = _2797 * 0.5000;
  float3 _2799 = _2796 * _2798;
  float3 _2800 = _2795 + _2799;
  *b@3 = _2800;
  float3 _2802 = *a@3;
  float3 _2803 = *a@3;
  float _2804 = Dot(_2802, _2803);
  float _2805 = GLSL.std.450::Sqrt(_2804);
  float _2806 = GLSL.std.450::FMax(_2805, 0.0000);
  *lengthA = _2806;
  float3 _2808 = *b@3;
  float3 _2809 = *b@3;
  float _2810 = Dot(_2808, _2809);
  float _2811 = GLSL.std.450::Sqrt(_2810);
  float _2812 = GLSL.std.450::FMax(_2811, 0.0000);
  *lengthB = _2812;
  float3 _2814 = *direction;
  float3 _2815 = *a@3;
  float _2816 = Dot(_2814, _2815);
  float _2817 = *lengthA;
  float _2818 = _2816 / _2817;
  float3 _2819 = *direction;
  float3 _2820 = *b@3;
  float _2821 = Dot(_2819, _2820);
  float _2822 = *lengthB;
  float _2823 = _2821 / _2822;
  float _2824 = _2818 + _2823;
  float _2825 = 0.5000 * _2824;
  float _2826 = GLSL.std.450::FClamp(_2825, 0.0000, 1.0000);
  *numerator = _2826;
  float _2828 = *lengthA;
  float _2829 = *lengthB;
  float _2830 = _2828 * _2829;
  float3 _2831 = *a@3;
  float3 _2832 = *b@3;
  float _2833 = Dot(_2831, _2832);
  float _2834 = _2830 + _2833;
  float _2835 = 0.5000 * _2834;
  float _2836 = _2835 + 1.0000;
  float _2837 = GLSL.std.450::FMax(_2836, 1.0000);
  *denominator@4 = _2837;
  float3 _2838 = *direction;
  float _2839 = *numerator;
  float _2840 = *denominator@4;
  float _2841 = _2839 / _2840;
  LineLightGeometry _2842 = CompositeConstruct({_2838, _2841});
  return _2842;
}

float lightInfluenceBoxWeight(float3* position, float4* row0, float4* row1, float4* row2, float4* parameters) {
  float4* point;
  float3* coordinates@2;
  float* edge@2;
  float* inner;
  float* weight@4;
  float* _2845 = &parameters.x;
  float _2846 = *_2845;
  bool _2847 = _2846 < 0.5000;
  
  if(_2847) {
    return 1.0000;
  }

  float3 _2852 = *position;
  float _2853 = _2852.x;
  float _2854 = _2852.y;
  float _2855 = _2852.z;
  float4 _2856 = CompositeConstruct({_2853, _2854, _2855, 1.0000});
  *point = _2856;
  float4 _2858 = *row0;
  float4 _2859 = *point;
  float _2860 = Dot(_2858, _2859);
  float4 _2861 = *row1;
  float4 _2862 = *point;
  float _2863 = Dot(_2861, _2862);
  float4 _2864 = *row2;
  float4 _2865 = *point;
  float _2866 = Dot(_2864, _2865);
  float3 _2867 = CompositeConstruct({_2860, _2863, _2866});
  float3 _2868 = GLSL.std.450::FAbs(_2867);
  *coordinates@2 = _2868;
  float* _2870 = &coordinates@2.x;
  float _2871 = *_2870;
  float* _2872 = &coordinates@2.y;
  float _2873 = *_2872;
  float _2874 = GLSL.std.450::FMax(_2871, _2873);
  float* _2875 = &coordinates@2.z;
  float _2876 = *_2875;
  float _2877 = GLSL.std.450::FMax(_2874, _2876);
  *edge@2 = _2877;
  float* _2878 = &parameters.y;
  float _2879 = *_2878;
  bool _2880 = _2879 == 1.0000;
  
  if(_2880) {
    float _2883 = *edge@2;
    bool _2884 = _2883 < 1.0000;
    float _2885 = Select(_2884, 1.0000, 0.0000);
    return _2885;
  }

  float* _2888 = &parameters.y;
  float _2889 = *_2888;
  float _2890 = 1.0000 + _2889;
  float _2891 = _2890 * 0.5000;
  *inner = _2891;
  float _2893 = *edge@2;
  float _2894 = *inner;
  float _2895 = _2893 - _2894;
  float _2896 = *inner;
  float _2897 = 1.0000 - _2896;
  float _2898 = _2895 / _2897;
  float _2899 = GLSL.std.450::FClamp(_2898, 0.0000, 1.0000);
  float _2900 = 1.0000 - _2899;
  *weight@4 = _2900;
  float _2901 = *weight@4;
  float _2902 = *weight@4;
  float _2903 = _2901 * _2902;
  return _2903;
}

float localLightDistanceWeight(float* distanceSquared@2, float* radius@2, float* model, float* exponent) {
  float* squaredDistance;
  float* safeRadius;
  float* normalizedSquared;
  float* window;
  float* window@2;
  float _2907 = *distanceSquared@2;
  float _2908 = GLSL.std.450::FMax(_2907, 0.0000);
  *squaredDistance = _2908;
  float _2910 = *radius@2;
  float _2911 = GLSL.std.450::FMax(_2910, 0.0010);
  *safeRadius = _2911;
  float _2913 = *squaredDistance;
  float _2914 = *safeRadius;
  float _2915 = *safeRadius;
  float _2916 = _2914 * _2915;
  float _2917 = _2913 / _2916;
  *normalizedSquared = _2917;
  float _2918 = *model;
  bool _2919 = _2918 > 1.5000;
  
  if(_2919) {
    float _2922 = *normalizedSquared;
    float _2923 = GLSL.std.450::FClamp(_2922, 0.0000, 1.0000);
    float _2924 = 1.0000 - _2923;
    float _2925 = GLSL.std.450::FMax(_2924, 0.0000);
    float _2926 = *exponent;
    float _2927 = GLSL.std.450::Pow(_2925, _2926);
    return _2927;
  }

  float _2929 = *model;
  bool _2930 = _2929 > 0.5000;
  
  if(_2930) {
    float _2934 = *normalizedSquared;
    float _2935 = *normalizedSquared;
    float _2936 = _2934 * _2935;
    float _2937 = 1.0000 - _2936;
    float _2938 = GLSL.std.450::FMax(_2937, 0.0000);
    *window = _2938;
    float _2939 = *window;
    float _2940 = *window;
    float _2941 = _2939 * _2940;
    float _2942 = *squaredDistance;
    float _2943 = _2942 + 1.0000;
    float _2944 = _2941 / _2943;
    return _2944;
  }

  float _2947 = *squaredDistance;
  float _2948 = GLSL.std.450::Sqrt(_2947);
  float _2949 = *safeRadius;
  float _2950 = _2948 / _2949;
  float _2951 = 1.0000 - _2950;
  float _2952 = GLSL.std.450::FMax(_2951, 0.0000);
  *window@2 = _2952;
  float _2953 = *window@2;
  float _2954 = *window@2;
  float _2955 = _2953 * _2954;
  float _2956 = *squaredDistance;
  float _2958 = _2956 * 0.1200;
  float _2959 = 1.0000 + _2958;
  float _2960 = _2955 / _2959;
  return _2960;
}

float2 characterHairLobes(float3* normal@8, float3* tangent@2, float3* bitangent@2, float3* highlightNormal@2, float3* view@4, float3* light@5, float3* viewOffset, float* power, float* strandShift) {
  float* shift;
  float3* primary@2;
  float3* secondary@2;
  float3* halfVector@2;
  float2* projection;
  float2* sine@2;
  float* exponent@2;
  float3 _2964 = *highlightNormal@2;
  float3 _2965 = *tangent@2;
  float _2966 = Dot(_2964, _2965);
  float _2968 = _2966 * 0.1600;
  *shift = _2968;
  float3 _2970 = *bitangent@2;
  float3 _2971 = *normal@8;
  float _2972 = *shift;
  float3 _2973 = _2971 * _2972;
  float3 _2974 = _2970 + _2973;
  float3 _2975 = GLSL.std.450::Normalize(_2974);
  *primary@2 = _2975;
  float3 _2977 = *bitangent@2;
  float3 _2978 = *normal@8;
  float _2979 = *shift;
  float _2980 = *strandShift;
  float _2981 = _2979 + _2980;
  float3 _2982 = _2978 * _2981;
  float3 _2983 = _2977 + _2982;
  float3 _2984 = GLSL.std.450::Normalize(_2983);
  *secondary@2 = _2984;
  float3 _2986 = *light@5;
  float3 _2987 = *view@4;
  float3 _2988 = *viewOffset;
  float3 _2989 = _2987 + _2988;
  float3 _2990 = GLSL.std.450::Normalize(_2989);
  float3 _2991 = _2986 + _2990;
  float3 _2992 = GLSL.std.450::Normalize(_2991);
  *halfVector@2 = _2992;
  float3 _2994 = *primary@2;
  float3 _2995 = *halfVector@2;
  float _2996 = Dot(_2994, _2995);
  float3 _2997 = *secondary@2;
  float3 _2998 = *halfVector@2;
  float _2999 = Dot(_2997, _2998);
  float2 _3000 = CompositeConstruct({_2996, _2999});
  *projection = _3000;
  float2 _3002 = *projection;
  float2 _3003 = *projection;
  float2 _3004 = _3002 * _3003;
  float2 _3005 = {1.0000, 1.0000} - _3004;
  float2 _3006 = GLSL.std.450::FMax(_3005, {0.0000, 0.0000});
  float2 _3007 = GLSL.std.450::Sqrt(_3006);
  *sine@2 = _3007;
  float _3009 = *power;
  float _3011 = _3009 * 0.4000;
  float _3014 = GLSL.std.450::FClamp(_3011, 80.0000, 220.0000);
  *exponent@2 = _3014;
  float2 _3015 = *sine@2;
  float _3016 = *exponent@2;
  float _3017 = *exponent@2;
  float _3019 = _3017 * 0.4200;
  float _3022 = GLSL.std.450::FClamp(_3019, 38.0000, 96.0000);
  float2 _3023 = CompositeConstruct({_3016, _3022});
  float2 _3024 = GLSL.std.450::Pow(_3015, _3023);
  return _3024;
}

bool sceneCharacterSurface(uint* materialClass@2, uint* profileVersion) {
  uint _3027 = *profileVersion;
  bool _3028 = _3027 >= 2;
  uint _3029 = *materialClass@2;
  bool _3030 = _3029 >= 1;
  bool _3031 = _3028 && _3030;
  uint _3032 = *materialClass@2;
  bool _3033 = _3032 <= 6;
  bool _3034 = _3031 && _3033;
  return _3034;
}

float3 characterProjectedSafeNormalize(float3* value@3, float3* fallback) {
  float* length2;
  float3* _3043;
  float3 _3038 = *value@3;
  float3 _3039 = *value@3;
  float _3040 = Dot(_3038, _3039);
  *length2 = _3040;
  float _3041 = *length2;
  bool _3042 = _3041 > 0.0000;
  
  if(_3042) {
    float3 _3046 = *value@3;
    float _3047 = *length2;
    float _3048 = GLSL.std.450::InverseSqrt(_3047);
    float3 _3049 = _3046 * _3048;
    *_3043 = _3049;
  } else {
    float3 _3051 = *fallback;
    *_3043 = _3051;
  }

  float3 _3052 = *_3043;
  return _3052;
}

float3 characterProjectedVirtualHalf(float3* view@5, float3* light@6, float3* objectX, float3* objectY, float3* objectZ, float* blend) {
  float3* local;
  float3* virtualLight;
  float3* param@441;
  float3* param@442;
  float3* halfVector@3;
  float3 _3056 = *view@5;
  float3 _3057 = *objectX;
  float _3058 = Dot(_3056, _3057);
  float* _3059 = &light@6.y;
  float _3060 = *_3059;
  float _3061 = *blend;
  float _3062 = GLSL.std.450::FMix(0.5000, _3060, _3061);
  float3 _3063 = *view@5;
  float3 _3064 = *objectZ;
  float _3065 = Dot(_3063, _3064);
  float3 _3066 = CompositeConstruct({_3058, _3062, _3065});
  *local = _3066;
  float3 _3068 = *objectX;
  float* _3069 = &local.x;
  float _3070 = *_3069;
  float3 _3071 = _3068 * _3070;
  float3 _3072 = *objectY;
  float* _3073 = &local.y;
  float _3074 = *_3073;
  float3 _3075 = _3072 * _3074;
  float3 _3076 = _3071 + _3075;
  float3 _3077 = *objectZ;
  float* _3078 = &local.z;
  float _3079 = *_3078;
  float3 _3080 = _3077 * _3079;
  float3 _3081 = _3076 + _3080;
  float3 _3082 = _3081 * 2.0000;
  float _3083 = *blend;
  float3 _3084 = *light@6;
  float3 _3085 = _3084 * _3083;
  float3 _3086 = _3082 + _3085;
  *param@441 = _3086;
  *param@442 = {0.0000, 0.0000, 1.0000};
  float3 _3089 = characterProjectedSafeNormalize(param@441, param@442);
  *virtualLight = _3089;
  float3 _3091 = *virtualLight;
  float3 _3092 = *view@5;
  float3 _3093 = _3091 + _3092;
  *halfVector@3 = _3093;
  float3 _3094 = *halfVector@3;
  float3 _3095 = *halfVector@3;
  float3 _3096 = *halfVector@3;
  float _3097 = Dot(_3095, _3096);
  float _3098 = GLSL.std.450::FMax(_3097, 0.0001);
  float _3099 = GLSL.std.450::InverseSqrt(_3098);
  float3 _3100 = _3094 * _3099;
  return _3100;
}

float3 characterProjectedHairNormal(float2* encoded@3, float* scale@2, float3* normal@9, float4* tangent@3) {
  float2* xy@2;
  float* z;
  float3* bitangent@3;
  float3* param@443;
  float3* param@444;
  float3* param@445;
  float3* param@446;
  float* _3104 = &encoded@3.x;
  float _3105 = *_3104;
  float _3106 = _3105 * 2.0000;
  float _3107 = _3106 - 1.0000;
  float* _3108 = &encoded@3.y;
  float _3109 = *_3108;
  float _3110 = _3109 * 2.0000;
  float _3111 = 1.0000 - _3110;
  float2 _3112 = CompositeConstruct({_3107, _3111});
  *xy@2 = _3112;
  float2 _3114 = *xy@2;
  float2 _3115 = *xy@2;
  float _3116 = Dot(_3114, _3115);
  float _3117 = GLSL.std.450::FMin(_3116, 1.0000);
  float _3118 = 1.0000 - _3117;
  float _3119 = GLSL.std.450::FMax(_3118, 0.0000);
  float _3120 = GLSL.std.450::Sqrt(_3119);
  *z = _3120;
  float3 _3122 = *normal@9;
  float4 _3123 = *tangent@3;
  float3 _3124 = _3123.xyz;
  float3 _3125 = GLSL.std.450::Cross(_3122, _3124);
  float* _3126 = &tangent@3.w;
  float _3127 = *_3126;
  float3 _3128 = _3125 * _3127;
  *bitangent@3 = _3128;
  float4 _3129 = *tangent@3;
  float3 _3130 = _3129.xyz;
  float* _3131 = &xy@2.x;
  float _3132 = *_3131;
  float3 _3133 = _3130 * _3132;
  float _3134 = *scale@2;
  float3 _3135 = _3133 * _3134;
  float3 _3136 = *bitangent@3;
  float* _3137 = &xy@2.y;
  float _3138 = *_3137;
  float3 _3139 = _3136 * _3138;
  float _3140 = *scale@2;
  float3 _3141 = _3139 * _3140;
  float3 _3142 = _3135 + _3141;
  float3 _3143 = *normal@9;
  float _3144 = *z;
  float3 _3145 = _3143 * _3144;
  float3 _3146 = _3142 + _3145;
  float3 _3148 = *normal@9;
  *param@443 = _3148;
  *param@444 = {0.0000, 0.0000, 1.0000};
  float3 _3150 = characterProjectedSafeNormalize(param@443, param@444);
  *param@445 = _3146;
  *param@446 = _3150;
  float3 _3153 = characterProjectedSafeNormalize(param@445, param@446);
  return _3153;
}

float3 characterProjectedHairStrand(float3* normal@10, float4* tangent@4, float* parameterR, float3* objectX@2, float3* objectY@2, float3* objectZ@2, float* directionX) {
  float3* axis@2;
  float3* param@447;
  float3* param@448;
  float* orientation;
  float3* blend@2;
  float3 _3157 = *objectX@2;
  float _3158 = *directionX;
  float3 _3159 = _3157 * _3158;
  float3 _3160 = *objectY@2;
  float3 _3161 = _3159 + _3160;
  *param@447 = _3161;
  *param@448 = {0.0000, 1.0000, 0.0000};
  float3 _3165 = characterProjectedSafeNormalize(param@447, param@448);
  *axis@2 = _3165;
  float3 _3167 = *objectX@2;
  float3 _3168 = *objectY@2;
  float3 _3169 = GLSL.std.450::Cross(_3167, _3168);
  float3 _3170 = *objectZ@2;
  float _3171 = Dot(_3169, _3170);
  bool _3172 = _3171 < 0.0000;
  float _3173 = Select(_3172, -1.0000, 1.0000);
  *orientation = _3173;
  float _3175 = *orientation;
  float3 _3176 = *normal@10;
  float3 _3177 = *axis@2;
  float3 _3178 = GLSL.std.450::Cross(_3176, _3177);
  float3 _3179 = _3178 * _3175;
  float4 _3180 = *tangent@4;
  float3 _3181 = _3180.xyz;
  float _3182 = *parameterR;
  float3 _3183 = CompositeConstruct({_3182, _3182, _3182});
  float3 _3184 = GLSL.std.450::FMix(_3179, _3181, _3183);
  *blend@2 = _3184;
  float _3185 = *orientation;
  float3 _3186 = *normal@10;
  float3 _3187 = *blend@2;
  float3 _3188 = GLSL.std.450::Cross(_3186, _3187);
  float3 _3189 = _3188 * _3185;
  float* _3190 = &tangent@4.w;
  float _3191 = *_3190;
  float _3192 = *orientation;
  float _3193 = _3191 * _3192;
  float _3194 = *parameterR;
  float _3195 = GLSL.std.450::FMix(1.0000, _3193, _3194);
  float3 _3196 = _3189 * _3195;
  return _3196;
}

float characterProjectedHairSine(float* projection@2) {
  float _3199 = *projection@2;
  float _3200 = *projection@2;
  float _3201 = _3199 * _3200;
  float _3202 = 1.0000 - _3201;
  float _3203 = GLSL.std.450::FMax(_3202, 0.0000);
  float _3204 = GLSL.std.450::Sqrt(_3203);
  float _3205 = GLSL.std.450::FMax(_3204, 0.0001);
  return _3205;
}

CharacterProjectedHairCoordinates characterProjectedHairCoordinates(float3* halfVector@4, float3* highlightNormal@3, float3* view@6, float4* sourceParameters, float4* tangent@5, float3* objectX@3, float3* objectY@3, float3* objectZ@3, float* primaryShift, float* secondaryShift, float* range2, float* edgeFadePower, float* directionX@2) {
  float3* normal@11;
  float3* param@449;
  float3* param@450;
  float3* viewDirection@2;
  float3* param@451;
  float3* param@452;
  float3* halfDirection@2;
  float3* param@453;
  float3* param@454;
  float3* strand;
  float3* param@455;
  float4* param@456;
  float* param@457;
  float3* param@458;
  float3* param@459;
  float3* param@460;
  float* param@461;
  float3* fallback@2;
  float3* param@462;
  float3* param@463;
  float3* primary@3;
  float3* param@464;
  float3* param@465;
  float3* secondary@3;
  float3* param@466;
  float3* param@467;
  float2* normalProjection;
  float2* viewProjection;
  float* normalLength2;
  float* viewLength2;
  float* edge@3;
  float* cosine;
  float* projection@3;
  float* u;
  float* param@468;
  float* exponent@3;
  float* lobe2;
  float* param@469;
  float* _3345;
  float3 _3210 = *highlightNormal@3;
  *param@449 = _3210;
  *param@450 = {0.0000, 0.0000, 1.0000};
  float3 _3212 = characterProjectedSafeNormalize(param@449, param@450);
  *normal@11 = _3212;
  float3 _3215 = *view@6;
  *param@451 = _3215;
  *param@452 = {0.0000, 0.0000, 1.0000};
  float3 _3217 = characterProjectedSafeNormalize(param@451, param@452);
  *viewDirection@2 = _3217;
  float3 _3220 = *halfVector@4;
  *param@453 = _3220;
  *param@454 = {0.0000, 0.0000, 1.0000};
  float3 _3222 = characterProjectedSafeNormalize(param@453, param@454);
  *halfDirection@2 = _3222;
  float3 _3225 = *normal@11;
  *param@455 = _3225;
  float4 _3227 = *tangent@5;
  *param@456 = _3227;
  float* _3229 = &sourceParameters.x;
  float _3230 = *_3229;
  *param@457 = _3230;
  float3 _3232 = *objectX@3;
  *param@458 = _3232;
  float3 _3234 = *objectY@3;
  *param@459 = _3234;
  float3 _3236 = *objectZ@3;
  *param@460 = _3236;
  float _3238 = *directionX@2;
  *param@461 = _3238;
  float3 _3239 = characterProjectedHairStrand(param@455, param@456, param@457, param@458, param@459, param@460, param@461);
  *strand = _3239;
  float4 _3243 = *tangent@5;
  float3 _3244 = _3243.xyz;
  *param@462 = _3244;
  *param@463 = {1.0000, 0.0000, 0.0000};
  float3 _3246 = characterProjectedSafeNormalize(param@462, param@463);
  *fallback@2 = _3246;
  float3 _3248 = *strand;
  float3 _3249 = *normal@11;
  float _3250 = *primaryShift;
  float3 _3251 = _3249 * _3250;
  float3 _3252 = _3248 + _3251;
  *param@464 = _3252;
  float3 _3255 = *fallback@2;
  *param@465 = _3255;
  float3 _3256 = characterProjectedSafeNormalize(param@464, param@465);
  *primary@3 = _3256;
  float3 _3258 = *strand;
  float3 _3259 = *normal@11;
  float _3260 = *secondaryShift;
  float3 _3261 = _3259 * _3260;
  float3 _3262 = _3258 + _3261;
  *param@466 = _3262;
  float3 _3265 = *fallback@2;
  *param@467 = _3265;
  float3 _3266 = characterProjectedSafeNormalize(param@466, param@467);
  *secondary@3 = _3266;
  float3 _3268 = *normal@11;
  float3 _3269 = *objectX@3;
  float _3270 = Dot(_3268, _3269);
  float3 _3271 = *normal@11;
  float3 _3272 = *objectZ@3;
  float _3273 = Dot(_3271, _3272);
  float2 _3274 = CompositeConstruct({_3270, _3273});
  *normalProjection = _3274;
  float3 _3276 = *viewDirection@2;
  float3 _3277 = *objectX@3;
  float _3278 = Dot(_3276, _3277);
  float3 _3279 = *viewDirection@2;
  float3 _3280 = *objectZ@3;
  float _3281 = Dot(_3279, _3280);
  float2 _3282 = CompositeConstruct({_3278, _3281});
  *viewProjection = _3282;
  float2 _3284 = *normalProjection;
  float2 _3285 = *normalProjection;
  float _3286 = Dot(_3284, _3285);
  *normalLength2 = _3286;
  float2 _3288 = *viewProjection;
  float2 _3289 = *viewProjection;
  float _3290 = Dot(_3288, _3289);
  *viewLength2 = _3290;
  *edge@3 = 0.0000;
  float _3292 = *normalLength2;
  bool _3293 = _3292 > 0.0000;
  float _3294 = *viewLength2;
  bool _3295 = _3294 > 0.0000;
  bool _3296 = _3293 && _3295;
  
  if(_3296) {
    float2 _3300 = *normalProjection;
    float2 _3301 = *viewProjection;
    float _3302 = Dot(_3300, _3301);
    float _3303 = *normalLength2;
    float _3304 = *viewLength2;
    float _3305 = _3303 * _3304;
    float _3306 = GLSL.std.450::InverseSqrt(_3305);
    float _3307 = _3302 * _3306;
    float _3308 = GLSL.std.450::FClamp(_3307, 0.0000, 1.0000);
    *cosine = _3308;
    float _3309 = *cosine;
    float _3310 = *edgeFadePower;
    float _3311 = GLSL.std.450::Pow(_3309, _3310);
    *edge@3 = _3311;
  }

  float3 _3313 = *primary@3;
  float3 _3314 = *halfDirection@2;
  float _3315 = Dot(_3313, _3314);
  float _3316 = GLSL.std.450::FClamp(_3315, -1.0000, 1.0000);
  *projection@3 = _3316;
  float* _3318 = &sourceParameters.y;
  float _3319 = *_3318;
  float _3321 = *projection@3;
  *param@468 = _3321;
  float _3322 = characterProjectedHairSine(param@468);
  float _3324 = GLSL.std.450::Pow(_3322, 200.0000);
  float _3325 = _3319 * _3324;
  float _3326 = GLSL.std.450::FClamp(_3325, 0.0000, 1.0000);
  *u = _3326;
  float _3328 = *range2;
  float _3329 = 1.0000 - _3328;
  float _3330 = GLSL.std.450::FMax(_3329, 0.0000);
  float _3331 = _3330 * 200.0000;
  float _3332 = GLSL.std.450::Trunc(_3331);
  *exponent@3 = _3332;
  float3 _3334 = *secondary@3;
  float3 _3335 = *halfDirection@2;
  float _3336 = Dot(_3334, _3335);
  float _3337 = GLSL.std.450::FClamp(_3336, -1.0000, 1.0000);
  *param@469 = _3337;
  float _3339 = characterProjectedHairSine(param@469);
  float _3340 = *exponent@3;
  float _3341 = GLSL.std.450::Pow(_3339, _3340);
  *lobe2 = _3341;
  float _3342 = *u;
  float _3343 = *projection@3;
  bool _3344 = _3343 > 0.0000;
  
  if(_3344) {
    float _3348 = *edge@3;
    float _3349 = *edge@3;
    float _3350 = _3348 * _3349;
    *_3345 = _3350;
  } else {
    *_3345 = 0.0000;
  }

  float _3352 = *_3345;
  float2 _3353 = CompositeConstruct({_3342, _3352});
  float _3354 = *edge@3;
  float _3355 = *lobe2;
  CharacterProjectedHairCoordinates _3356 = CompositeConstruct({_3353, _3354, _3355});
  return _3356;
}

CharacterProjectedHairEnergy characterProjectedHairEnergy(CharacterProjectedHairCoordinates* coordinates@3, float3* rampSample@2, float4* sourceParameters@2, float* intensity, float3* secondaryColor) {
  float3* q@2;
  float3* primary@4;
  float3* secondary@4;
  float3 _3360 = *rampSample@2;
  float* _3361 = &coordinates@3.uv.x;
  float _3362 = *_3361;
  float3 _3363 = _3360 * _3362;
  float* _3364 = &coordinates@3.edgeFade;
  float _3365 = *_3364;
  float3 _3366 = _3363 * _3365;
  *q@2 = _3366;
  float3 _3368 = *q@2;
  float* _3369 = &sourceParameters@2.y;
  float _3370 = *_3369;
  float3 _3371 = _3368 * _3370;
  float3 _3373 = _3371 * 0.0400;
  float _3374 = *intensity;
  float3 _3375 = _3373 * _3374;
  float3 _3376 = _3375 * 5.0000;
  *primary@4 = _3376;
  float* _3378 = &sourceParameters@2.w;
  float _3379 = *_3378;
  float3 _3380 = *secondaryColor;
  float3 _3381 = _3380 * _3379;
  float* _3382 = &coordinates@3.edgeFade;
  float _3383 = *_3382;
  float3 _3384 = _3381 * _3383;
  float* _3385 = &coordinates@3.secondaryLobe;
  float _3386 = *_3385;
  float3 _3387 = _3384 * _3386;
  float* _3388 = &q@2.x;
  float _3389 = *_3388;
  float* _3390 = &q@2.y;
  float _3391 = *_3390;
  float _3392 = GLSL.std.450::FMax(_3389, _3391);
  float* _3393 = &q@2.z;
  float _3394 = *_3393;
  float _3395 = GLSL.std.450::FMax(_3392, _3394);
  float _3396 = 1.0000 - _3395;
  float3 _3397 = _3387 * _3396;
  *secondary@4 = _3397;
  float3 _3398 = *q@2;
  float3 _3399 = *primary@4;
  float3 _3400 = *secondary@4;
  CharacterProjectedHairEnergy _3401 = CompositeConstruct({_3398, _3399, _3400});
  return _3401;
}

float2 characterProjectedHairLine(float3* strand@2, float3* normal@12, float3* halfVector@5, float* u@2, float* lineSample, float* parameterG, float3* q@3, float4* shape, float2* color@4) {
  float3* shifted;
  float3* param@470;
  float3* param@471;
  float* lobe@3;
  float* param@472;
  float* alternating;
  float* weight@5;
  float* base@5;
  float* factor;
  float3 _3405 = *strand@2;
  float3 _3406 = *normal@12;
  float* _3407 = &shape.y;
  float _3408 = *_3407;
  float3 _3409 = _3406 * _3408;
  float3 _3410 = _3405 + _3409;
  *param@470 = _3410;
  *param@471 = {1.0000, 0.0000, 0.0000};
  float3 _3413 = characterProjectedSafeNormalize(param@470, param@471);
  *shifted = _3413;
  float3 _3415 = *shifted;
  float3 _3416 = *halfVector@5;
  float _3417 = Dot(_3415, _3416);
  *param@472 = _3417;
  float _3419 = characterProjectedHairSine(param@472);
  float* _3420 = &shape.z;
  float _3421 = *_3420;
  float _3422 = 1.0000 - _3421;
  float _3423 = GLSL.std.450::FMax(_3422, 0.0000);
  float _3424 = _3423 * 200.0000;
  float _3425 = GLSL.std.450::Trunc(_3424);
  float _3426 = GLSL.std.450::Pow(_3419, _3425);
  *lobe@3 = _3426;
  float _3428 = *u@2;
  float* _3429 = &shape.x;
  float _3430 = *_3429;
  float _3431 = _3428 * _3430;
  float _3432 = GLSL.std.450::Fract(_3431);
  float _3433 = _3432 - 0.5000;
  float _3434 = GLSL.std.450::FMax(_3433, 0.0000);
  float _3435 = GLSL.std.450::Ceil(_3434);
  *alternating = _3435;
  float _3437 = *alternating;
  float _3438 = *lineSample;
  float _3439 = 1.0000 - _3438;
  float* _3440 = &color@4.x;
  float _3441 = *_3440;
  float _3442 = GLSL.std.450::FMix(_3437, _3439, _3441);
  *weight@5 = _3442;
  float _3444 = *weight@5;
  float* _3445 = &shape.w;
  float _3446 = *_3445;
  float _3447 = GLSL.std.450::FMix(1.0000, _3444, _3446);
  *base@5 = _3447;
  float _3449 = *parameterG;
  float _3450 = *base@5;
  float* _3451 = &q@3.x;
  float _3452 = *_3451;
  float* _3453 = &q@3.y;
  float _3454 = *_3453;
  float _3455 = GLSL.std.450::FMax(_3452, _3454);
  float* _3456 = &q@3.z;
  float _3457 = *_3456;
  float _3458 = GLSL.std.450::FMax(_3455, _3457);
  float _3459 = GLSL.std.450::FMix(_3450, 1.0000, _3458);
  float _3460 = _3459 - 1.0000;
  float _3461 = _3449 * _3460;
  float _3462 = *lobe@3;
  float _3463 = _3461 * _3462;
  float _3464 = 1.0000 + _3463;
  *factor = _3464;
  float _3465 = *factor;
  float* _3466 = &color@4.y;
  float _3467 = *_3466;
  float _3468 = *factor;
  float _3469 = GLSL.std.450::FMix(_3467, 1.0000, _3468);
  float2 _3470 = CompositeConstruct({_3465, _3469});
  return _3470;
}

float3 characterEyeSafeNormalize(float3* value@4) {
  float* length2@2;
  float3* _3480;
  float3 _3474 = *value@4;
  float3 _3475 = *value@4;
  float _3476 = Dot(_3474, _3475);
  *length2@2 = _3476;
  float _3477 = *length2@2;
  bool _3479 = _3477 > 0.0000;
  
  if(_3479) {
    float3 _3483 = *value@4;
    float _3484 = *length2@2;
    float _3485 = GLSL.std.450::InverseSqrt(_3484);
    float3 _3486 = _3483 * _3485;
    *_3480 = _3486;
  } else {
    *_3480 = {0.0000, 0.0000, 1.0000};
  }

  float3 _3488 = *_3480;
  return _3488;
}

CharacterEyeCoordinates characterEyeCoordinates(float2* originalUv@2, float3* view@7, float3* normal@13, float4* tangent@6, float3x3* worldToView@2, float* parallaxScale, float* normalScale) {
  float2* fracUv;
  float* radius2;
  float* white;
  float* weight@6;
  float3* crossed;
  float3* parallaxBitangent;
  float* normalLength;
  float3* projectedView;
  float3* param@473;
  float2* shifted@2;
  float2* radial@5;
  float3* matcapLocal;
  float3* lightingLocal;
  float3* bitangent@4;
  float3x3* sourceFrame;
  float3* lightNormal;
  float3* param@474;
  float3* matcapNormal;
  float3* param@475;
  float2 _3492 = *originalUv@2;
  float2 _3493 = GLSL.std.450::Fract(_3492);
  *fracUv = _3493;
  float2 _3495 = *fracUv;
  float2 _3497 = _3495 - {0.5000, 0.5000};
  float2 _3498 = *fracUv;
  float2 _3499 = _3498 - {0.5000, 0.5000};
  float _3500 = Dot(_3497, _3499);
  *radius2 = _3500;
  float _3502 = *radius2;
  float _3503 = GLSL.std.450::Step(0.2500, _3502);
  *white = _3503;
  float _3505 = *radius2;
  float _3506 = 0.2500 - _3505;
  float _3507 = _3506 * 5.0000;
  float _3508 = GLSL.std.450::FClamp(_3507, 0.0000, 1.0000);
  *weight@6 = _3508;
  float _3509 = *weight@6;
  float _3510 = *weight@6;
  float _3511 = _3509 * _3510;
  float _3512 = *weight@6;
  float _3513 = 2.0000 * _3512;
  float _3514 = 3.0000 - _3513;
  float _3515 = _3511 * _3514;
  *weight@6 = _3515;
  float3 _3517 = *normal@13;
  float4 _3518 = *tangent@6;
  float3 _3519 = _3518.xyz;
  float3 _3520 = GLSL.std.450::Cross(_3517, _3519);
  *crossed = _3520;
  float3 _3522 = *crossed;
  float* _3523 = &tangent@6.w;
  float _3524 = *_3523;
  bool _3525 = _3524 > 0.0000;
  float _3526 = Select(_3525, 1.0000, -1.0000);
  float3 _3527 = _3522 * _3526;
  *parallaxBitangent = _3527;
  float3 _3529 = *normal@13;
  float _3530 = GLSL.std.450::Length(_3529);
  float _3531 = GLSL.std.450::FMax(_3530, 0.0000);
  *normalLength = _3531;
  float4 _3533 = *tangent@6;
  float3 _3534 = _3533.xyz;
  float3 _3535 = *view@7;
  float _3536 = Dot(_3534, _3535);
  float3 _3537 = *parallaxBitangent;
  float3 _3538 = *view@7;
  float _3539 = Dot(_3537, _3538);
  float3 _3540 = *normal@13;
  float3 _3541 = *view@7;
  float _3542 = Dot(_3540, _3541);
  float3 _3543 = CompositeConstruct({_3536, _3539, _3542});
  float _3544 = *normalLength;
  float3 _3545 = CompositeConstruct({_3544, _3544, _3544});
  float3 _3546 = _3543 / _3545;
  *param@473 = _3546;
  float3 _3548 = characterEyeSafeNormalize(param@473);
  *projectedView = _3548;
  float2 _3550 = *originalUv@2;
  float3 _3551 = *projectedView;
  float2 _3552 = _3551.xy;
  float2 _3554 = _3552 * {1.0000, 0.2500};
  float _3555 = *parallaxScale;
  float2 _3556 = _3554 * _3555;
  float _3557 = *weight@6;
  float2 _3558 = _3556 * _3557;
  float2 _3559 = _3550 - _3558;
  *shifted@2 = _3559;
  float2 _3561 = *fracUv;
  float2 _3562 = _3561 * 2.0000;
  float2 _3563 = CompositeConstruct({1.0000, 1.0000});
  float2 _3564 = _3562 - _3563;
  *radial@5 = _3564;
  float2 _3566 = *radial@5;
  float2 _3567 = -_3566;
  float _3568 = *normalScale;
  float2 _3569 = _3567 * _3568;
  float2 _3570 = *radial@5;
  float2 _3571 = *radial@5;
  float _3572 = Dot(_3570, _3571);
  float _3573 = 1.0000 - _3572;
  float _3574 = GLSL.std.450::FMax(_3573, 0.0000);
  float _3575 = GLSL.std.450::Sqrt(_3574);
  float _3576 = _3569.x;
  float _3577 = _3569.y;
  float3 _3578 = CompositeConstruct({_3576, _3577, _3575});
  *matcapLocal = _3578;
  float3 _3580 = *matcapLocal;
  float3 _3583 = _3580 * {-0.1250, -0.1250, 1.0000};
  float _3584 = *white;
  float3 _3585 = CompositeConstruct({_3584, _3584, _3584});
  float3 _3586 = GLSL.std.450::FMix(_3583, {0.0000, 0.0000, 1.0000}, _3585);
  *lightingLocal = _3586;
  float3 _3588 = *crossed;
  float* _3589 = &tangent@6.w;
  float _3590 = *_3589;
  float3 _3591 = _3588 * _3590;
  *bitangent@4 = _3591;
  float4 _3593 = *tangent@6;
  float3 _3594 = _3593.xyz;
  float3 _3595 = *bitangent@4;
  float3 _3596 = *normal@13;
  float _3597 = _3594.x;
  float _3598 = _3594.y;
  float _3599 = _3594.z;
  float _3600 = _3595.x;
  float _3601 = _3595.y;
  float _3602 = _3595.z;
  float _3603 = _3596.x;
  float _3604 = _3596.y;
  float _3605 = _3596.z;
  float3 _3606 = CompositeConstruct({_3597, _3598, _3599});
  float3 _3607 = CompositeConstruct({_3600, _3601, _3602});
  float3 _3608 = CompositeConstruct({_3603, _3604, _3605});
  float3x3 _3609 = CompositeConstruct({_3606, _3607, _3608});
  *sourceFrame = _3609;
  float3x3 _3611 = *sourceFrame;
  float3 _3612 = *lightingLocal;
  float3 _3613 = _3611 * _3612;
  *param@474 = _3613;
  float3 _3615 = characterEyeSafeNormalize(param@474);
  *lightNormal = _3615;
  float3x3 _3617 = *worldToView@2;
  float3x3 _3618 = *sourceFrame;
  float3x3 _3619 = _3617 * _3618;
  float3 _3620 = *matcapLocal;
  float3 _3621 = _3619 * _3620;
  *param@475 = _3621;
  float3 _3623 = characterEyeSafeNormalize(param@475);
  *matcapNormal = _3623;
  float2 _3624 = *shifted@2;
  float3 _3625 = *lightNormal;
  float3 _3626 = *matcapNormal;
  float2 _3627 = _3626.xy;
  float2 _3628 = _3627 * 0.5000;
  float2 _3629 = CompositeConstruct({0.5000, 0.5000});
  float2 _3630 = _3628 + _3629;
  float _3631 = *white;
  CharacterEyeCoordinates _3632 = CompositeConstruct({_3624, _3625, _3630, _3631});
  return _3632;
}

float3 characterEyeDiffuseMultiplier(float4* base@6, float* white@2, float3* highlight, float3* scattering) {
  float3 _3635 = *highlight;
  float _3636 = *white@2;
  float3 _3637 = CompositeConstruct({_3636, _3636, _3636});
  float3 _3638 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, _3635, _3637);
  float3 _3639 = *scattering;
  float* _3640 = &base@6.w;
  float _3641 = *_3640;
  float3 _3642 = CompositeConstruct({_3641, _3641, _3641});
  float3 _3643 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, _3639, _3642);
  float3 _3644 = _3638 * _3643;
  return _3644;
}

CharacterDiffuseResponse characterEyeNprResponse(float4* base@7, float* white@3, float3* highlight@2, float3* scattering@2, float* metallic@5, float* shadowScale@3, float4* ramp@10, float* viewRampAlpha, float* sceneVisibility@5) {
  float3* lit@3;
  float4* param@476;
  float* param@477;
  float3* param@478;
  float3* param@479;
  float3* shadow@4;
  float3* param@480;
  float3* param@481;
  float3* param@482;
  float4* param@483;
  float* param@484;
  float* param@485;
  float* param@486;
  float* param@487;
  float4 _3648 = *base@7;
  float3 _3649 = _3648.xyz;
  float4 _3651 = *base@7;
  *param@476 = _3651;
  float _3653 = *white@3;
  *param@477 = _3653;
  float3 _3655 = *highlight@2;
  *param@478 = _3655;
  float3 _3657 = *scattering@2;
  *param@479 = _3657;
  float3 _3658 = characterEyeDiffuseMultiplier(param@476, param@477, param@478, param@479);
  float3 _3659 = _3649 * _3658;
  float _3660 = *metallic@5;
  float _3661 = 1.0000 - _3660;
  float _3662 = 0.9600 * _3661;
  float3 _3663 = _3659 * _3662;
  *lit@3 = _3663;
  float4 _3665 = *base@7;
  float3 _3666 = _3665.xyz;
  float _3667 = *metallic@5;
  float _3668 = 1.0000 - _3667;
  float _3669 = 0.9600 * _3668;
  float _3670 = *shadowScale@3;
  float _3671 = _3669 * _3670;
  float3 _3672 = _3666 * _3671;
  *shadow@4 = _3672;
  float* _3673 = &ramp@10.w;
  float _3674 = *_3673;
  float _3675 = GLSL.std.450::FMin(_3674, 1.0000);
  float* _3676 = &ramp@10.w;
  float _3677 = *_3676;
  float _3678 = *viewRampAlpha;
  float _3679 = _3677 + _3678;
  float _3680 = GLSL.std.450::FClamp(_3679, 0.0000, 1.0000);
  float3 _3682 = *lit@3;
  *param@480 = _3682;
  float3 _3684 = *shadow@4;
  *param@481 = _3684;
  float3 _3686 = *lit@3;
  *param@482 = _3686;
  float4 _3688 = *ramp@10;
  *param@483 = _3688;
  *param@484 = _3675;
  float _3691 = *viewRampAlpha;
  *param@485 = _3691;
  *param@486 = _3680;
  float _3694 = *sceneVisibility@5;
  *param@487 = _3694;
  CharacterDiffuseResponse _3695 = characterDiffuseColorResponse(param@480, param@481, param@482, param@483, param@484, param@485, param@486, param@487);
  return _3695;
}

float characterEyeMainSaturation(float3* color@5) {
  float* high@2;
  float3* param@488;
  float3 _3700 = *color@5;
  *param@488 = _3700;
  float _3701 = characterDiffuseLuma(param@488);
  float _3702 = _3701 - 0.5000;
  float _3703 = GLSL.std.450::FClamp(_3702, 0.0000, 0.5000);
  *high@2 = _3703;
  float _3704 = *high@2;
  float _3705 = *high@2;
  float _3706 = _3704 * _3705;
  float _3707 = 1.0000 + _3706;
  return _3707;
}

float characterEyeAlphaMultiplier(float* alpha@5, float* premultiply) {
  float _3710 = *alpha@5;
  float _3711 = *premultiply;
  float _3712 = GLSL.std.450::FMix(1.0000, _3710, _3711);
  return _3712;
}

float3 characterEyeMatcap(float4* sampleValue, float4* color@6, float* viewRampAlpha@2, float* lightRampAlpha, float* shadowSelect, float* shadowFloor, float3* illumination@4) {
  float* ramp@11;
  float* intensity@2;
  float _3716 = *viewRampAlpha@2;
  float _3717 = *lightRampAlpha;
  float _3718 = GLSL.std.450::FMin(_3717, 1.0000);
  float _3719 = *shadowSelect;
  float _3720 = GLSL.std.450::FMix(_3716, _3718, _3719);
  *ramp@11 = _3720;
  float _3722 = *ramp@11;
  float _3723 = 0.5000 * _3722;
  float _3724 = _3723 + 0.5000;
  float _3725 = *ramp@11;
  float _3726 = *shadowFloor;
  float _3727 = 1.0000 - _3726;
  float _3728 = _3725 * _3727;
  float _3729 = *shadowFloor;
  float _3730 = _3728 + _3729;
  float _3731 = _3724 * _3730;
  *intensity@2 = _3731;
  float4 _3732 = *sampleValue;
  float3 _3733 = _3732.xyz;
  float* _3734 = &color@6.w;
  float _3735 = *_3734;
  float3 _3736 = _3733 * _3735;
  float* _3737 = &sampleValue.w;
  float _3738 = *_3737;
  float4 _3739 = *color@6;
  float3 _3740 = _3739.xyz;
  float3 _3741 = _3740 * _3738;
  float3 _3742 = _3736 + _3741;
  float _3743 = *intensity@2;
  float3 _3744 = _3742 * _3743;
  float3 _3745 = *illumination@4;
  float3 _3746 = _3744 * _3745;
  return _3746;
}

float3 characterEyeDirect(float4* base@8, float* white@4, float3* highlight@3, float3* scattering@3, float3* weights@2, float* premultiply@2) {
  float* param@489;
  float* param@490;
  float4 _3749 = *base@8;
  float3 _3750 = _3749.xyz;
  float* _3751 = &weights@2.x;
  float _3752 = *_3751;
  float3 _3753 = _3750 * _3752;
  float _3754 = *white@4;
  float3 _3755 = *highlight@3;
  float3 _3756 = _3755 * _3754;
  float* _3757 = &weights@2.y;
  float _3758 = *_3757;
  float3 _3759 = _3756 * _3758;
  float3 _3760 = _3753 + _3759;
  float* _3761 = &base@8.w;
  float _3762 = *_3761;
  float3 _3763 = *scattering@3;
  float3 _3764 = _3763 * _3762;
  float* _3765 = &weights@2.z;
  float _3766 = *_3765;
  float3 _3767 = _3764 * _3766;
  float3 _3768 = _3760 + _3767;
  float* _3770 = &base@8.w;
  float _3771 = *_3770;
  *param@489 = _3771;
  float _3773 = *premultiply@2;
  *param@490 = _3773;
  float _3774 = characterEyeAlphaMultiplier(param@489, param@490);
  float3 _3775 = _3768 * _3774;
  return _3775;
}

bool azureUniformMaterialFrame(float3* nx@2, float3* ny, float3* tx, float3* ty) {
  float3 _3778 = *nx@2;
  float _3779 = GLSL.std.450::Length(_3778);
  float3 _3780 = *ny;
  float _3781 = GLSL.std.450::Length(_3780);
  float _3782 = _3779 + _3781;
  float3 _3783 = *tx;
  float _3784 = GLSL.std.450::Length(_3783);
  float _3785 = _3782 + _3784;
  float3 _3786 = *ty;
  float _3787 = GLSL.std.450::Length(_3786);
  float _3788 = _3785 + _3787;
  bool _3789 = _3788 <= 0.0000;
  return _3789;
}

float azureTemporalMaskAlpha(SampledImage<float, 2D>* source, float2* uv@9, float2* dx@2, float2* dy@2) {
  SampledImage<float, 2D> _3792 = *source;
  float2 _3793 = *uv@9;
  float2 _3794 = *dx@2;
  float2 _3795 = _3794 * 0.2500;
  float2 _3796 = *dy@2;
  float2 _3797 = _3796 * 0.2500;
  float4 _3798 = ImageSampleExplicitLod(_3792, _3793, Grad(_3795, _3797));
  float _3799 = _3798.w;
  return _3799;
}

float azureTemporalBlendAlpha(SampledImage<float, 2D>* source@2, float2* uv@10, float2* dx@3, float2* dy@3, float2* jitter) {
  float* alpha@6;
  int* y@3;
  int* x@3;
  float2* offset@7;
  *alpha@6 = 0.0000;
  *y@3 = 0;

  while(true) {
    int _3809 = *y@3;
    bool _3811 = _3809 < 4;
    if(!_3811) break;
    *x@3 = 0;

    while(true) {
      int _3818 = *x@3;
      bool _3819 = _3818 < 4;
      if(!_3819) break;
      int _3821 = *x@3;
      float _3822 = ConvertSToF(_3821);
      int _3823 = *y@3;
      float _3824 = ConvertSToF(_3823);
      float2 _3825 = CompositeConstruct({_3822, _3824});
      float2 _3826 = CompositeConstruct({0.5000, 0.5000});
      float2 _3827 = _3825 + _3826;
      float2 _3828 = _3827 * 0.2500;
      float2 _3829 = CompositeConstruct({0.5000, 0.5000});
      float2 _3830 = _3828 - _3829;
      float2 _3831 = *jitter;
      float2 _3832 = _3830 + _3831;
      *offset@7 = _3832;
      SampledImage<float, 2D> _3833 = *source@2;
      float2 _3834 = *uv@10;
      float2 _3835 = *dx@3;
      float* _3836 = &offset@7.x;
      float _3837 = *_3836;
      float2 _3838 = _3835 * _3837;
      float2 _3839 = _3834 + _3838;
      float2 _3840 = *dy@3;
      float* _3841 = &offset@7.y;
      float _3842 = *_3841;
      float2 _3843 = _3840 * _3842;
      float2 _3844 = _3839 + _3843;
      float2 _3845 = *dx@3;
      float2 _3846 = _3845 * 0.2500;
      float2 _3847 = *dy@3;
      float2 _3848 = _3847 * 0.2500;
      float4 _3849 = ImageSampleExplicitLod(_3833, _3844, Grad(_3846, _3848));
      float _3850 = _3849.w;
      float _3851 = *alpha@6;
      float _3852 = _3851 + _3850;
      *alpha@6 = _3852;
      int _3853 = *x@3;
      int _3854 = _3853 + 1;
      *x@3 = _3854;
    }

    int _3855 = *y@3;
    int _3856 = _3855 + 1;
    *y@3 = _3856;
  }

  float _3857 = *alpha@6;
  float _3859 = _3857 * 0.0625;
  return _3859;
}

float azureUnsignedMaterialFloat(float* value@5, uint* mantissa) {
  uint* word;
  uint* magnitude;
  uint* maximum;
  uint* exponent@4;
  uint* significand;
  uint* count;
  float _3863 = *value@5;
  uint _3864 = Bitcast(_3863);
  *word = _3864;
  uint _3866 = *word;
  uint _3868 = _3866 & 2147483647;
  *magnitude = _3868;
  uint _3869 = *magnitude;
  bool _3871 = _3869 > 2139095040;
  
  if(_3871) {
    float _3875 = Bitcast(2143289344);
    return _3875;
  }

  uint _3877 = *word;
  uint _3879 = _3877 & 2147483648;
  bool _3880 = _3879 != 0;
  
  if(_3880) {
    return 0.0000;
  }

  uint _3884 = *magnitude;
  bool _3885 = _3884 == 2139095040;
  
  if(_3885) {
    float _3888 = *value@5;
    return _3888;
  }

  uint _3891 = *mantissa;
  bool _3892 = _3891 == 6;
  uint _3895 = Select(_3892, 1199439872, 1199308800);
  *maximum = _3895;
  uint _3896 = *magnitude;
  uint _3897 = *maximum;
  bool _3898 = _3896 > _3897;
  
  if(_3898) {
    uint _3901 = *maximum;
    float _3902 = Bitcast(_3901);
    return _3902;
  }

  uint _3905 = *magnitude;
  uint _3907 = _3905 >> 23;
  *exponent@4 = _3907;
  uint _3908 = *exponent@4;
  bool _3910 = _3908 < 113;
  
  if(_3910) {
    uint _3913 = *exponent@4;
    uint _3914 = *mantissa;
    uint _3915 = 113 - _3914;
    bool _3916 = _3913 < _3915;
    
    if(_3916) {
      return 0.0000;
    }

    uint _3921 = *magnitude;
    uint _3923 = _3921 & 8388607;
    uint _3925 = _3923 | 8388608;
    *significand = _3925;
    uint _3927 = *significand;
    uint _3929 = *exponent@4;
    uint _3930 = 136 - _3929;
    uint _3931 = *mantissa;
    uint _3932 = _3930 - _3931;
    uint _3933 = _3927 >> _3932;
    *count = _3933;
    uint _3934 = *count;
    float _3935 = ConvertUToF(_3934);
    uint _3936 = *mantissa;
    uint _3937 = 113 - _3936;
    uint _3938 = _3937 << 23;
    float _3939 = Bitcast(_3938);
    float _3940 = _3935 * _3939;
    return _3940;
  }

  uint _3942 = *magnitude;
  uint _3943 = *mantissa;
  uint _3944 = 23 - _3943;
  uint _3945 = 1 << _3944;
  uint _3946 = _3945 - 1;
  uint _3947 = ~_3946;
  uint _3948 = _3942 & _3947;
  float _3949 = Bitcast(_3948);
  return _3949;
}

float4 azureMaterialOutputPrecision(float4* color@7, bool* enabled) {
  float* param@491;
  uint* param@492;
  float* param@493;
  uint* param@494;
  float* param@495;
  uint* param@496;
  bool _3952 = *enabled;
  bool _3953 = !_3952;
  
  if(_3953) {
    float4 _3956 = *color@7;
    return _3956;
  }

  float* _3959 = &color@7.x;
  float _3960 = *_3959;
  *param@491 = _3960;
  *param@492 = 6;
  float _3962 = azureUnsignedMaterialFloat(param@491, param@492);
  float* _3964 = &color@7.y;
  float _3965 = *_3964;
  *param@493 = _3965;
  *param@494 = 6;
  float _3967 = azureUnsignedMaterialFloat(param@493, param@494);
  float* _3970 = &color@7.z;
  float _3971 = *_3970;
  *param@495 = _3971;
  *param@496 = 5;
  float _3973 = azureUnsignedMaterialFloat(param@495, param@496);
  float* _3974 = &color@7.w;
  float _3975 = *_3974;
  float4 _3976 = CompositeConstruct({_3962, _3967, _3973, _3975});
  return _3976;
}

uint azureSpecializedMaterialFeatures(bool* defaults, uint* submitted) {
  uint* _3980;
  bool _3979 = *defaults;
  
  if(_3979) {
    uint _3983 = *submitted;
    uint _3985 = _3983 & 3221225512;
    *_3980 = _3985;
  } else {
    uint _3987 = *submitted;
    *_3980 = _3987;
  }

  uint _3988 = *_3980;
  return _3988;
}

float irradianceQuerySignedNoise(float2* pixel@4, float* phase) {
  float2* shifted@3;
  float* horizontal@2;
  float* gradient;
  float* scaled;
  float _3992 = *phase;
  float _3993 = GLSL.std.450::Trunc(_3992);
  float2 _3994 = CompositeConstruct({_3993, _3993});
  float _3996 = Bitcast(1074089951);
  float _3998 = Bitcast(1083948663);
  float2 _3999 = CompositeConstruct({_3996, _3998});
  float2 _4000 = *pixel@4;
  float2 _4001 = GLSL.std.450::Floor(_4000);
  float2 _4002 = GLSL.std.450::Fma(_3994, _3999, _4001);
  *shifted@3 = _4002;
  float* _4004 = &shifted@3.x;
  float _4005 = *_4004;
  float _4007 = Bitcast(1032417603);
  float _4008 = _4005 * _4007;
  *horizontal@2 = _4008;
  float* _4010 = &shifted@3.y;
  float _4011 = *_4010;
  float _4013 = Bitcast(1002390928);
  float _4014 = *horizontal@2;
  float _4015 = GLSL.std.450::Fma(_4011, _4013, _4014);
  *gradient = _4015;
  float _4017 = *gradient;
  float _4018 = GLSL.std.450::Fract(_4017);
  float _4020 = Bitcast(1112796802);
  float _4021 = _4018 * _4020;
  *scaled = _4021;
  float _4022 = *scaled;
  float _4023 = GLSL.std.450::Fract(_4022);
  float _4024 = GLSL.std.450::Fma(_4023, 2.0000, -1.0000);
  return _4024;
}

float2 irradianceQueryPixel(float2* pixel@5, float* viewportHeight, uint* flags) {
  float2* cell@2;
  float2 _4028 = *pixel@5;
  float2 _4029 = GLSL.std.450::Floor(_4028);
  *cell@2 = _4029;
  uint _4030 = *flags;
  uint _4031 = _4030 & 2;
  bool _4032 = _4031 != 0;
  
  if(_4032) {
    float _4035 = *viewportHeight;
    float _4036 = _4035 - 1.0000;
    float* _4037 = &cell@2.y;
    float _4038 = *_4037;
    float _4039 = _4036 - _4038;
    float* _4040 = &cell@2.y;
    *_4040 = _4039;
  }

  float2 _4041 = *cell@2;
  return _4041;
}

float3 irradianceQueryPosition(float3* surface@3, float3* normal@14, float2* pixel@6, float3* parameters@2, float3* direction@2) {
  float3* offset@8;
  float3* amplitude;
  float2* param@497;
  float* param@498;
  float* _4044 = &parameters@2.x;
  float _4045 = *_4044;
  bool _4046 = _4045 == 0.0000;
  
  if(_4046) {
    float* _4049 = &parameters@2.y;
    float _4050 = *_4049;
    bool _4051 = _4050 == 0.0000;
  }

  bool _4052 = Phi(_4046, _4051);
  
  if(_4052) {
    float3 _4055 = *surface@3;
    return _4055;
  }

  float3 _4058 = *normal@14;
  float* _4059 = &parameters@2.x;
  float _4060 = *_4059;
  float3 _4061 = CompositeConstruct({_4060, _4060, _4060});
  float3 _4062 = *surface@3;
  float3 _4063 = GLSL.std.450::Fma(_4058, _4061, _4062);
  *offset@8 = _4063;
  float* _4065 = &parameters@2.y;
  float _4066 = *_4065;
  float3 _4067 = CompositeConstruct({_4066, _4066, _4066});
  float3 _4068 = *direction@2;
  float3 _4069 = _4067 * _4068;
  *amplitude = _4069;
  float2 _4071 = *pixel@6;
  *param@497 = _4071;
  float* _4073 = &parameters@2.z;
  float _4074 = *_4073;
  *param@498 = _4074;
  float _4075 = irradianceQuerySignedNoise(param@497, param@498);
  float3 _4076 = CompositeConstruct({_4075, _4075, _4075});
  float3 _4077 = *amplitude;
  float3 _4078 = *offset@8;
  float3 _4079 = GLSL.std.450::Fma(_4076, _4077, _4078);
  return _4079;
}

bool screenReflectionProjectClip(float4* clip@2, float2* uv@11) {
  float* _4082 = &clip@2.w;
  float _4083 = *_4082;
  bool _4084 = _4083 <= 0.0000;
  bool _4085 = !_4084;
  
  if(_4085) {
    float* _4088 = &clip@2.z;
    float _4089 = *_4088;
    bool _4090 = _4089 < 0.0000;
  }

  bool _4091 = Phi(_4084, _4090);
  bool _4092 = !_4091;
  
  if(_4092) {
    float* _4095 = &clip@2.z;
    float _4096 = *_4095;
    float* _4097 = &clip@2.w;
    float _4098 = *_4097;
    bool _4099 = _4096 > _4098;
  }

  bool _4100 = Phi(_4091, _4099);
  
  if(_4100) {
    return false;
  }

  float4 _4104 = *clip@2;
  float2 _4105 = _4104.xy;
  float* _4106 = &clip@2.w;
  float _4107 = *_4106;
  float2 _4108 = CompositeConstruct({_4107, _4107});
  float2 _4109 = _4105 / _4108;
  float2 _4110 = _4109 * 0.5000;
  float2 _4111 = CompositeConstruct({0.5000, 0.5000});
  float2 _4112 = _4110 + _4111;
  *uv@11 = _4112;
  float2 _4113 = *uv@11;
  bool _4114 = _4113 >= {0.0000, 0.0000};
  bool _4115 = All(_4114);
  
  if(_4115) {
    float2 _4118 = *uv@11;
    bool _4119 = _4118 <= {1.0000, 1.0000};
    bool _4120 = All(_4119);
  }

  bool _4121 = Phi(_4115, _4120);
  return _4121;
}

float screenReflectionConfidence(float2* uv@12, float* roughness@6, float* distance, float4* trace, float4* quality) {
  float* edge@4;
  float* _4125 = &uv@12.x;
  float _4126 = *_4125;
  float* _4127 = &uv@12.x;
  float _4128 = *_4127;
  float _4129 = 1.0000 - _4128;
  float _4130 = GLSL.std.450::FMin(_4126, _4129);
  float* _4131 = &uv@12.y;
  float _4132 = *_4131;
  float* _4133 = &uv@12.y;
  float _4134 = *_4133;
  float _4135 = 1.0000 - _4134;
  float _4136 = GLSL.std.450::FMin(_4132, _4135);
  float _4137 = GLSL.std.450::FMin(_4130, _4136);
  *edge@4 = _4137;
  float* _4138 = &quality.z;
  float _4139 = *_4138;
  float _4140 = *edge@4;
  float _4141 = GLSL.std.450::SmoothStep(0.0000, _4139, _4140);
  float* _4142 = &quality.y;
  float _4143 = *_4142;
  float _4144 = _4143 * 0.7500;
  float* _4145 = &quality.y;
  float _4146 = *_4145;
  float _4147 = *roughness@6;
  float _4148 = GLSL.std.450::SmoothStep(_4144, _4146, _4147);
  float _4149 = 1.0000 - _4148;
  float _4150 = _4141 * _4149;
  float* _4151 = &trace.y;
  float _4152 = *_4151;
  float _4153 = _4152 * 0.7500;
  float* _4154 = &trace.y;
  float _4155 = *_4154;
  float _4156 = *distance;
  float _4157 = GLSL.std.450::SmoothStep(_4153, _4155, _4156);
  float _4158 = 1.0000 - _4157;
  float _4159 = _4150 * _4158;
  float* _4160 = &quality.w;
  float _4161 = *_4160;
  float _4162 = _4159 * _4161;
  return _4162;
}

float3 screenReflectionRadiance(SampledImage<float, 2D>* source@3, SampledImage<float, 2D>* depth@3, float2* uv@13, float* hitDepth, float* thickness) {
  int2* extent@4;
  float2* pixel@7;
  int2* base@9;
  float2* fraction@2;
  float3* radiance@4;
  float* total;
  int* y@4;
  int* x@4;
  int2* p@6;
  float* w;
  float* _4215;
  float* _4227;
  float3* _4268;
  SampledImage<float, 2D> _4166 = *source@3;
  Image<float, 2D> _4167 = Image(_4166);
  int2 _4168 = ImageQuerySizeLod(_4167, 0);
  *extent@4 = _4168;
  float2 _4170 = *uv@13;
  int2 _4171 = *extent@4;
  float2 _4172 = ConvertSToF(_4171);
  float2 _4173 = _4170 * _4172;
  float2 _4174 = CompositeConstruct({0.5000, 0.5000});
  float2 _4175 = _4173 - _4174;
  *pixel@7 = _4175;
  float2 _4177 = *pixel@7;
  float2 _4178 = GLSL.std.450::Floor(_4177);
  int2 _4179 = ConvertFToS(_4178);
  *base@9 = _4179;
  float2 _4181 = *pixel@7;
  float2 _4182 = GLSL.std.450::Fract(_4181);
  *fraction@2 = _4182;
  *radiance@4 = {0.0000, 0.0000, 0.0000};
  *total = 0.0000;
  *y@4 = 0;

  while(true) {
    int _4191 = *y@4;
    bool _4192 = _4191 < 2;
    if(!_4192) break;
    *x@4 = 0;

    while(true) {
      int _4199 = *x@4;
      bool _4200 = _4199 < 2;
      if(!_4200) break;
      int2 _4202 = *base@9;
      int _4203 = *x@4;
      int _4204 = *y@4;
      int2 _4205 = CompositeConstruct({_4203, _4204});
      int2 _4206 = _4202 + _4205;
      int2 _4208 = *extent@4;
      int2 _4209 = CompositeConstruct({1, 1});
      int2 _4210 = _4208 - _4209;
      int2 _4211 = GLSL.std.450::SClamp(_4206, {0, 0}, _4210);
      *p@6 = _4211;
      int _4213 = *x@4;
      bool _4214 = _4213 == 0;
      
      if(_4214) {
        float* _4218 = &fraction@2.x;
        float _4219 = *_4218;
        float _4220 = 1.0000 - _4219;
        *_4215 = _4220;
      } else {
        float* _4222 = &fraction@2.x;
        float _4223 = *_4222;
        *_4215 = _4223;
      }

      float _4224 = *_4215;
      int _4225 = *y@4;
      bool _4226 = _4225 == 0;
      
      if(_4226) {
        float* _4230 = &fraction@2.y;
        float _4231 = *_4230;
        float _4232 = 1.0000 - _4231;
        *_4227 = _4232;
      } else {
        float* _4234 = &fraction@2.y;
        float _4235 = *_4234;
        *_4227 = _4235;
      }

      float _4236 = *_4227;
      float _4237 = _4224 * _4236;
      *w = _4237;
      SampledImage<float, 2D> _4238 = *depth@3;
      int2 _4239 = *p@6;
      Image<float, 2D> _4240 = Image(_4238);
      float4 _4241 = ImageFetch(_4240, _4239, Lod(0));
      float _4242 = _4241.x;
      float _4243 = *hitDepth;
      float _4244 = _4242 - _4243;
      float _4245 = GLSL.std.450::FAbs(_4244);
      float _4246 = *thickness;
      bool _4247 = _4245 <= _4246;
      
      if(_4247) {
        SampledImage<float, 2D> _4250 = *source@3;
        int2 _4251 = *p@6;
        Image<float, 2D> _4252 = Image(_4250);
        float4 _4253 = ImageFetch(_4252, _4251, Lod(0));
        float3 _4254 = _4253.xyz;
        float _4255 = *w;
        float3 _4256 = _4254 * _4255;
        float3 _4257 = *radiance@4;
        float3 _4258 = _4257 + _4256;
        *radiance@4 = _4258;
        float _4259 = *w;
        float _4260 = *total;
        float _4261 = _4260 + _4259;
        *total = _4261;
      }

      int _4262 = *x@4;
      int _4263 = _4262 + 1;
      *x@4 = _4263;
    }

    int _4264 = *y@4;
    int _4265 = _4264 + 1;
    *y@4 = _4265;
  }

  float _4266 = *total;
  bool _4267 = _4266 > 0.0000;
  
  if(_4267) {
    float3 _4271 = *radiance@4;
    float _4272 = *total;
    float3 _4273 = CompositeConstruct({_4272, _4272, _4272});
    float3 _4274 = _4271 / _4273;
    *_4268 = _4274;
  } else {
    SampledImage<float, 2D> _4276 = *source@3;
    float2 _4277 = *uv@13;
    float4 _4278 = ImageSampleImplicitLod(_4276, _4277);
    float3 _4279 = _4278.xyz;
    *_4268 = _4279;
  }

  float3 _4280 = *_4268;
  return _4280;
}

float2x2 screenReflectionFootprint(float4x4* worldToClip, float3* hit, float3* rayDirection, float* distance@2, float* roughness@7, int2* extent@5) {
  float4* clip@3;
  float3* ray;
  float3* reference;
  float3* tangent@7;
  float3* bitangent@5;
  float3* row0@2;
  float3* row1@2;
  float3* rowW;
  float3* dx@4;
  float3* dy@4;
  float* radius@3;
  float2* a@4;
  float2* b@4;
  float* aa;
  float* bb;
  float* ab;
  float* major;
  float4x4 _4284 = *worldToClip;
  float3 _4285 = *hit;
  float _4286 = _4285.x;
  float _4287 = _4285.y;
  float _4288 = _4285.z;
  float4 _4289 = CompositeConstruct({_4286, _4287, _4288, 1.0000});
  float4 _4290 = _4284 * _4289;
  *clip@3 = _4290;
  float* _4291 = &clip@3.w;
  float _4292 = *_4291;
  bool _4293 = _4292 <= 0.0000;
  
  if(_4293) {
    return _4296;
  }

  float3 _4299 = *rayDirection;
  float3 _4300 = GLSL.std.450::Normalize(_4299);
  *ray = _4300;
  float* _4302 = &ray.z;
  float _4303 = *_4302;
  float _4304 = GLSL.std.450::FAbs(_4303);
  bool _4306 = _4304 < 0.9000;
  bool _4307 = CompositeConstruct({_4306, _4306, _4306});
  float3 _4308 = Select(_4307, {0.0000, 0.0000, 1.0000}, {0.0000, 1.0000, 0.0000});
  *reference = _4308;
  float3 _4310 = *ray;
  float3 _4311 = *reference;
  float3 _4312 = GLSL.std.450::Cross(_4310, _4311);
  float3 _4313 = GLSL.std.450::Normalize(_4312);
  *tangent@7 = _4313;
  float3 _4315 = *ray;
  float3 _4316 = *tangent@7;
  float3 _4317 = GLSL.std.450::Cross(_4315, _4316);
  *bitangent@5 = _4317;
  float* _4319 = &worldToClip[0].x;
  float _4320 = *_4319;
  float* _4321 = &worldToClip[1].x;
  float _4322 = *_4321;
  float* _4323 = &worldToClip[2].x;
  float _4324 = *_4323;
  float3 _4325 = CompositeConstruct({_4320, _4322, _4324});
  *row0@2 = _4325;
  float* _4327 = &worldToClip[0].y;
  float _4328 = *_4327;
  float* _4329 = &worldToClip[1].y;
  float _4330 = *_4329;
  float* _4331 = &worldToClip[2].y;
  float _4332 = *_4331;
  float3 _4333 = CompositeConstruct({_4328, _4330, _4332});
  *row1@2 = _4333;
  float* _4335 = &worldToClip[0].w;
  float _4336 = *_4335;
  float* _4337 = &worldToClip[1].w;
  float _4338 = *_4337;
  float* _4339 = &worldToClip[2].w;
  float _4340 = *_4339;
  float3 _4341 = CompositeConstruct({_4336, _4338, _4340});
  *rowW = _4341;
  float3 _4343 = *row0@2;
  float* _4344 = &clip@3.x;
  float _4345 = *_4344;
  float* _4346 = &clip@3.w;
  float _4347 = *_4346;
  float _4348 = _4345 / _4347;
  float3 _4349 = *rowW;
  float3 _4350 = _4349 * _4348;
  float3 _4351 = _4343 - _4350;
  int* _4352 = &extent@5.x;
  int _4353 = *_4352;
  float _4354 = ConvertSToF(_4353);
  float _4355 = 0.5000 * _4354;
  float* _4356 = &clip@3.w;
  float _4357 = *_4356;
  float _4358 = _4355 / _4357;
  float3 _4359 = _4351 * _4358;
  *dx@4 = _4359;
  float3 _4361 = *row1@2;
  float* _4362 = &clip@3.y;
  float _4363 = *_4362;
  float* _4364 = &clip@3.w;
  float _4365 = *_4364;
  float _4366 = _4363 / _4365;
  float3 _4367 = *rowW;
  float3 _4368 = _4367 * _4366;
  float3 _4369 = _4361 - _4368;
  int* _4370 = &extent@5.y;
  int _4371 = *_4370;
  float _4372 = ConvertSToF(_4371);
  float _4373 = 0.5000 * _4372;
  float* _4374 = &clip@3.w;
  float _4375 = *_4374;
  float _4376 = _4373 / _4375;
  float3 _4377 = _4369 * _4376;
  *dy@4 = _4377;
  float _4379 = *distance@2;
  float _4380 = *roughness@7;
  float _4381 = _4379 * _4380;
  float _4382 = *roughness@7;
  float _4383 = _4381 * _4382;
  *radius@3 = _4383;
  float3 _4385 = *dx@4;
  float3 _4386 = *tangent@7;
  float _4387 = Dot(_4385, _4386);
  float3 _4388 = *dy@4;
  float3 _4389 = *tangent@7;
  float _4390 = Dot(_4388, _4389);
  float2 _4391 = CompositeConstruct({_4387, _4390});
  float _4392 = *radius@3;
  float2 _4393 = _4391 * _4392;
  *a@4 = _4393;
  float3 _4395 = *dx@4;
  float3 _4396 = *bitangent@5;
  float _4397 = Dot(_4395, _4396);
  float3 _4398 = *dy@4;
  float3 _4399 = *bitangent@5;
  float _4400 = Dot(_4398, _4399);
  float2 _4401 = CompositeConstruct({_4397, _4400});
  float _4402 = *radius@3;
  float2 _4403 = _4401 * _4402;
  *b@4 = _4403;
  float2 _4405 = *a@4;
  float2 _4406 = *a@4;
  float _4407 = Dot(_4405, _4406);
  *aa = _4407;
  float2 _4409 = *b@4;
  float2 _4410 = *b@4;
  float _4411 = Dot(_4409, _4410);
  *bb = _4411;
  float2 _4413 = *a@4;
  float2 _4414 = *b@4;
  float _4415 = Dot(_4413, _4414);
  *ab = _4415;
  float _4417 = *aa;
  float _4418 = *bb;
  float _4419 = _4417 + _4418;
  float _4420 = *aa;
  float _4421 = *bb;
  float _4422 = _4420 - _4421;
  float _4423 = *aa;
  float _4424 = *bb;
  float _4425 = _4423 - _4424;
  float _4426 = _4422 * _4425;
  float _4428 = *ab;
  float _4429 = 4.0000 * _4428;
  float _4430 = *ab;
  float _4431 = _4429 * _4430;
  float _4432 = _4426 + _4431;
  float _4433 = GLSL.std.450::Sqrt(_4432);
  float _4434 = _4419 + _4433;
  float _4435 = 0.5000 * _4434;
  float _4436 = GLSL.std.450::FMax(0.0000, _4435);
  float _4437 = GLSL.std.450::Sqrt(_4436);
  *major = _4437;
  float2 _4438 = *a@4;
  float2 _4439 = *b@4;
  float _4440 = _4438.x;
  float _4441 = _4438.y;
  float _4442 = _4439.x;
  float _4443 = _4439.y;
  float2 _4444 = CompositeConstruct({_4440, _4441});
  float2 _4445 = CompositeConstruct({_4442, _4443});
  float2x2 _4446 = CompositeConstruct({_4444, _4445});
  float _4448 = *major;
  float _4449 = GLSL.std.450::FMax(_4448, 0.0000);
  float _4450 = 8.0000 / _4449;
  float _4451 = GLSL.std.450::FMin(1.0000, _4450);
  float2x2 _4452 = _4446 * _4451;
  return _4452;
}

float screenReflectionPlaneDepth(float* depth@4, bool* perspective) {
  float* _4456;
  bool _4455 = *perspective;
  
  if(_4455) {
    float _4459 = *depth@4;
    float _4460 = GLSL.std.450::FMax(_4459, 0.0000);
    float _4461 = 1.0000 / _4460;
    *_4456 = _4461;
  } else {
    float _4463 = *depth@4;
    *_4456 = _4463;
  }

  float _4464 = *_4456;
  return _4464;
}

float screenReflectionPlaneGradient(float* before, float* center, float* after) {
  float* a@5;
  float* b@5;
  float* gradient@2;
  float _4468 = *center;
  float _4469 = *before;
  float _4470 = _4468 - _4469;
  *a@5 = _4470;
  float _4472 = *after;
  float _4473 = *center;
  float _4474 = _4472 - _4473;
  *b@5 = _4474;
  float _4476 = *a@5;
  float _4477 = GLSL.std.450::FAbs(_4476);
  float _4478 = *b@5;
  float _4479 = GLSL.std.450::FAbs(_4478);
  bool _4480 = _4477 < _4479;
  float _4481 = *a@5;
  float _4482 = *b@5;
  float _4483 = Select(_4480, _4481, _4482);
  *gradient@2 = _4483;
  float _4484 = *gradient@2;
  float _4485 = GLSL.std.450::FAbs(_4484);
  float _4486 = *center;
  float _4487 = GLSL.std.450::FAbs(_4486);
  float _4488 = _4487 * 0.1000;
  bool _4489 = _4485 <= _4488;
  float _4490 = *gradient@2;
  float _4491 = Select(_4489, _4490, 0.0000);
  return _4491;
}

float2 screenReflectionDepthGradient(SampledImage<float, 2D>* depth@5, int2* center@2, float* hitDepth@2, bool* perspective@2) {
  int2* last;
  float* q@4;
  float* param@499;
  bool* param@500;
  float* left;
  float* param@501;
  bool* param@502;
  float* right;
  float* param@503;
  bool* param@504;
  float* up;
  float* param@505;
  bool* param@506;
  float* down;
  float* param@507;
  bool* param@508;
  float* param@509;
  float* param@510;
  float* param@511;
  float* param@512;
  float* param@513;
  float* param@514;
  SampledImage<float, 2D> _4495 = *depth@5;
  Image<float, 2D> _4496 = Image(_4495);
  int2 _4497 = ImageQuerySizeLod(_4496, 0);
  int2 _4498 = CompositeConstruct({1, 1});
  int2 _4499 = _4497 - _4498;
  *last = _4499;
  float _4502 = *hitDepth@2;
  *param@499 = _4502;
  bool _4504 = *perspective@2;
  *param@500 = _4504;
  float _4505 = screenReflectionPlaneDepth(param@499, param@500);
  *q@4 = _4505;
  SampledImage<float, 2D> _4507 = *depth@5;
  int2 _4508 = *center@2;
  int2 _4509 = _4508 - {1, 0};
  int2 _4510 = *last;
  int2 _4511 = GLSL.std.450::SClamp(_4509, {0, 0}, _4510);
  Image<float, 2D> _4512 = Image(_4507);
  float4 _4513 = ImageFetch(_4512, _4511, Lod(0));
  float _4515 = _4513.x;
  *param@501 = _4515;
  bool _4517 = *perspective@2;
  *param@502 = _4517;
  float _4518 = screenReflectionPlaneDepth(param@501, param@502);
  *left = _4518;
  SampledImage<float, 2D> _4520 = *depth@5;
  int2 _4521 = *center@2;
  int2 _4522 = _4521 + {1, 0};
  int2 _4523 = *last;
  int2 _4524 = GLSL.std.450::SClamp(_4522, {0, 0}, _4523);
  Image<float, 2D> _4525 = Image(_4520);
  float4 _4526 = ImageFetch(_4525, _4524, Lod(0));
  float _4528 = _4526.x;
  *param@503 = _4528;
  bool _4530 = *perspective@2;
  *param@504 = _4530;
  float _4531 = screenReflectionPlaneDepth(param@503, param@504);
  *right = _4531;
  SampledImage<float, 2D> _4533 = *depth@5;
  int2 _4534 = *center@2;
  int2 _4535 = _4534 - {0, 1};
  int2 _4536 = *last;
  int2 _4537 = GLSL.std.450::SClamp(_4535, {0, 0}, _4536);
  Image<float, 2D> _4538 = Image(_4533);
  float4 _4539 = ImageFetch(_4538, _4537, Lod(0));
  float _4541 = _4539.x;
  *param@505 = _4541;
  bool _4543 = *perspective@2;
  *param@506 = _4543;
  float _4544 = screenReflectionPlaneDepth(param@505, param@506);
  *up = _4544;
  SampledImage<float, 2D> _4546 = *depth@5;
  int2 _4547 = *center@2;
  int2 _4548 = _4547 + {0, 1};
  int2 _4549 = *last;
  int2 _4550 = GLSL.std.450::SClamp(_4548, {0, 0}, _4549);
  Image<float, 2D> _4551 = Image(_4546);
  float4 _4552 = ImageFetch(_4551, _4550, Lod(0));
  float _4554 = _4552.x;
  *param@507 = _4554;
  bool _4556 = *perspective@2;
  *param@508 = _4556;
  float _4557 = screenReflectionPlaneDepth(param@507, param@508);
  *down = _4557;
  float _4559 = *left;
  *param@509 = _4559;
  float _4561 = *q@4;
  *param@510 = _4561;
  float _4563 = *right;
  *param@511 = _4563;
  float _4564 = screenReflectionPlaneGradient(param@509, param@510, param@511);
  float _4566 = *up;
  *param@512 = _4566;
  float _4568 = *q@4;
  *param@513 = _4568;
  float _4570 = *down;
  *param@514 = _4570;
  float _4571 = screenReflectionPlaneGradient(param@512, param@513, param@514);
  float2 _4572 = CompositeConstruct({_4564, _4571});
  return _4572;
}

float4 screenReflectionFilteredRadiance(SampledImage<float, 2D>* source@4, SampledImage<float, 2D>* depth@6, float4x4* worldToClip@2, float2* uv@14, float3* hit@2, float3* rayDirection@2, float* distance@3, float* roughness@8, float* hitDepth@3, float* thickness@2) {
  float3* center@3;
  float2* param@515;
  float* param@516;
  float* param@517;
  int2* extent@6;
  float2x2* axes;
  float4x4* param@518;
  float3* param@519;
  float3* param@520;
  float* param@521;
  float* param@522;
  int2* param@523;
  float* aa@2;
  float* bb@2;
  float* ab@2;
  float* major@2;
  bool* perspective@3;
  int2* anchor;
  float2* gradient@3;
  int2* param@524;
  float* param@525;
  bool* param@526;
  float* planeDepth;
  float* param@527;
  bool* param@528;
  float2* pixel@8;
  float3* radiance@5;
  float* covered;
  int* tap@2;
  int2* p@7;
  float2[12]* indexable;
  float* prediction;
  float* expected;
  float* _4783;
  float* weight@7;
  float* blend@3;
  float2 _4577 = *uv@14;
  *param@515 = _4577;
  float _4579 = *hitDepth@3;
  *param@516 = _4579;
  float _4581 = *thickness@2;
  *param@517 = _4581;
  float3 _4582 = screenReflectionRadiance(source@4, depth@6, param@515, param@516, param@517);
  *center@3 = _4582;
  float _4583 = *roughness@8;
  bool _4584 = _4583 <= 0.0000;
  
  if(_4584) {
    float3 _4587 = *center@3;
    float _4588 = _4587.x;
    float _4589 = _4587.y;
    float _4590 = _4587.z;
    float4 _4591 = CompositeConstruct({_4588, _4589, _4590, 1.0000});
    return _4591;
  }

  SampledImage<float, 2D> _4594 = *source@4;
  Image<float, 2D> _4595 = Image(_4594);
  int2 _4596 = ImageQuerySizeLod(_4595, 0);
  *extent@6 = _4596;
  float4x4 _4600 = *worldToClip@2;
  *param@518 = _4600;
  float3 _4602 = *hit@2;
  *param@519 = _4602;
  float3 _4604 = *rayDirection@2;
  *param@520 = _4604;
  float _4606 = *distance@3;
  *param@521 = _4606;
  float _4608 = *roughness@8;
  *param@522 = _4608;
  int2 _4610 = *extent@6;
  *param@523 = _4610;
  float2x2 _4611 = screenReflectionFootprint(param@518, param@519, param@520, param@521, param@522, param@523);
  *axes = _4611;
  float2* _4613 = &axes[0];
  float2 _4614 = *_4613;
  float2* _4615 = &axes[0];
  float2 _4616 = *_4615;
  float _4617 = Dot(_4614, _4616);
  *aa@2 = _4617;
  float2* _4619 = &axes[1];
  float2 _4620 = *_4619;
  float2* _4621 = &axes[1];
  float2 _4622 = *_4621;
  float _4623 = Dot(_4620, _4622);
  *bb@2 = _4623;
  float2* _4625 = &axes[0];
  float2 _4626 = *_4625;
  float2* _4627 = &axes[1];
  float2 _4628 = *_4627;
  float _4629 = Dot(_4626, _4628);
  *ab@2 = _4629;
  float _4631 = *aa@2;
  float _4632 = *bb@2;
  float _4633 = _4631 + _4632;
  float _4634 = *aa@2;
  float _4635 = *bb@2;
  float _4636 = _4634 - _4635;
  float _4637 = *aa@2;
  float _4638 = *bb@2;
  float _4639 = _4637 - _4638;
  float _4640 = _4636 * _4639;
  float _4641 = *ab@2;
  float _4642 = 4.0000 * _4641;
  float _4643 = *ab@2;
  float _4644 = _4642 * _4643;
  float _4645 = _4640 + _4644;
  float _4646 = GLSL.std.450::Sqrt(_4645);
  float _4647 = _4633 + _4646;
  float _4648 = 0.5000 * _4647;
  float _4649 = GLSL.std.450::FMax(0.0000, _4648);
  float _4650 = GLSL.std.450::Sqrt(_4649);
  *major@2 = _4650;
  float _4651 = *major@2;
  bool _4652 = _4651 <= 0.5000;
  
  if(_4652) {
    float3 _4655 = *center@3;
    float _4656 = _4655.x;
    float _4657 = _4655.y;
    float _4658 = _4655.z;
    float4 _4659 = CompositeConstruct({_4656, _4657, _4658, 1.0000});
    return _4659;
  }

  float* _4662 = &worldToClip@2[0].w;
  float _4663 = *_4662;
  float* _4664 = &worldToClip@2[1].w;
  float _4665 = *_4664;
  float* _4666 = &worldToClip@2[2].w;
  float _4667 = *_4666;
  float3 _4668 = CompositeConstruct({_4663, _4665, _4667});
  float* _4669 = &worldToClip@2[0].w;
  float _4670 = *_4669;
  float* _4671 = &worldToClip@2[1].w;
  float _4672 = *_4671;
  float* _4673 = &worldToClip@2[2].w;
  float _4674 = *_4673;
  float3 _4675 = CompositeConstruct({_4670, _4672, _4674});
  float _4676 = Dot(_4668, _4675);
  bool _4677 = _4676 > 0.0000;
  *perspective@3 = _4677;
  float2 _4679 = *uv@14;
  int2 _4680 = *extent@6;
  float2 _4681 = ConvertSToF(_4680);
  float2 _4682 = _4679 * _4681;
  float2 _4683 = GLSL.std.450::Floor(_4682);
  int2 _4684 = ConvertFToS(_4683);
  int2 _4685 = *extent@6;
  int2 _4686 = CompositeConstruct({1, 1});
  int2 _4687 = _4685 - _4686;
  int2 _4688 = GLSL.std.450::SClamp(_4684, {0, 0}, _4687);
  *anchor = _4688;
  int2 _4691 = *anchor;
  *param@524 = _4691;
  float _4693 = *hitDepth@3;
  *param@525 = _4693;
  bool _4695 = *perspective@3;
  *param@526 = _4695;
  float2 _4696 = screenReflectionDepthGradient(depth@6, param@524, param@525, param@526);
  *gradient@3 = _4696;
  float _4699 = *hitDepth@3;
  *param@527 = _4699;
  bool _4701 = *perspective@3;
  *param@528 = _4701;
  float _4702 = screenReflectionPlaneDepth(param@527, param@528);
  *planeDepth = _4702;
  float2 _4704 = *uv@14;
  int2 _4705 = *extent@6;
  float2 _4706 = ConvertSToF(_4705);
  float2 _4707 = _4704 * _4706;
  float2 _4708 = CompositeConstruct({0.5000, 0.5000});
  float2 _4709 = _4707 - _4708;
  *pixel@8 = _4709;
  float3 _4711 = *center@3;
  float3 _4712 = _4711 * 0.2000;
  *radiance@5 = _4712;
  *covered = 0.2000;
  *tap@2 = 0;

  while(true) {
    int _4720 = *tap@2;
    bool _4722 = _4720 < 12;
    if(!_4722) break;
    float2 _4724 = *pixel@8;
    float2x2 _4725 = *axes;
    int _4742 = *tap@2;
    *indexable = _4741;
    float2* _4745 = &indexable[_4742];
    float2 _4746 = *_4745;
    float2 _4747 = _4725 * _4746;
    float2 _4748 = _4724 + _4747;
    float2 _4749 = CompositeConstruct({0.5000, 0.5000});
    float2 _4750 = _4748 + _4749;
    float2 _4751 = GLSL.std.450::Floor(_4750);
    int2 _4752 = ConvertFToS(_4751);
    *p@7 = _4752;
    int2 _4753 = *p@7;
    bool _4754 = _4753 < {0, 0};
    bool _4755 = Any(_4754);
    bool _4756 = !_4755;
    
    if(_4756) {
      int2 _4759 = *p@7;
      int2 _4760 = *extent@6;
      bool _4761 = _4759 >= _4760;
      bool _4762 = Any(_4761);
    }

    bool _4763 = Phi(_4755, _4762);
    
    if(_4763) {
      goto loop_continue2;
    }

    float _4768 = *planeDepth;
    float2 _4769 = *gradient@3;
    int2 _4770 = *p@7;
    int2 _4771 = *anchor;
    int2 _4772 = _4770 - _4771;
    float2 _4773 = ConvertSToF(_4772);
    float _4774 = Dot(_4769, _4773);
    float _4775 = _4768 + _4774;
    *prediction = _4775;
    float _4776 = *prediction;
    bool _4777 = _4776 <= 0.0000;
    
    if(_4777) {
      goto loop_continue2;
    }

    bool _4782 = *perspective@3;
    
    if(_4782) {
      float _4786 = *prediction;
      float _4787 = 1.0000 / _4786;
      *_4783 = _4787;
    } else {
      float _4789 = *prediction;
      *_4783 = _4789;
    }

    float _4790 = *_4783;
    *expected = _4790;
    SampledImage<float, 2D> _4791 = *depth@6;
    int2 _4792 = *p@7;
    Image<float, 2D> _4793 = Image(_4791);
    float4 _4794 = ImageFetch(_4793, _4792, Lod(0));
    float _4795 = _4794.x;
    float _4796 = *expected;
    float _4797 = _4795 - _4796;
    float _4798 = GLSL.std.450::FAbs(_4797);
    float _4799 = *thickness@2;
    bool _4800 = _4798 > _4799;
    
    if(_4800) {
      goto loop_continue2;
    }

    int _4805 = *tap@2;
    bool _4806 = _4805 < 4;
    float _4807 = Select(_4806, 0.1000, 0.0500);
    *weight@7 = _4807;
    SampledImage<float, 2D> _4808 = *source@4;
    int2 _4809 = *p@7;
    Image<float, 2D> _4810 = Image(_4808);
    float4 _4811 = ImageFetch(_4810, _4809, Lod(0));
    float3 _4812 = _4811.xyz;
    float _4813 = *weight@7;
    float3 _4814 = _4812 * _4813;
    float3 _4815 = *radiance@5;
    float3 _4816 = _4815 + _4814;
    *radiance@5 = _4816;
    float _4817 = *weight@7;
    float _4818 = *covered;
    float _4819 = _4818 + _4817;
    *covered = _4819;
loop_continue2:
    int _4820 = *tap@2;
    int _4821 = _4820 + 1;
    *tap@2 = _4821;
  }

  float _4823 = *major@2;
  float _4824 = GLSL.std.450::SmoothStep(0.5000, 1.0000, _4823);
  *blend@3 = _4824;
  float3 _4825 = *center@3;
  float3 _4826 = *radiance@5;
  float _4827 = *covered;
  float3 _4828 = CompositeConstruct({_4827, _4827, _4827});
  float3 _4829 = _4826 / _4828;
  float _4830 = *blend@3;
  float3 _4831 = CompositeConstruct({_4830, _4830, _4830});
  float3 _4832 = GLSL.std.450::FMix(_4825, _4829, _4831);
  float _4833 = *covered;
  float _4834 = *blend@3;
  float _4835 = GLSL.std.450::FMix(1.0000, _4833, _4834);
  float _4836 = _4832.x;
  float _4837 = _4832.y;
  float _4838 = _4832.z;
  float4 _4839 = CompositeConstruct({_4836, _4837, _4838, _4835});
  return _4839;
}

float4 traceScreenSpaceReflection(SampledImage<float, 2D>* source@5, SampledImage<float, 2D>* depth@7, float4x4* worldToClip@3, float3* cameraPosition, float3* cameraForward@2, float3* worldPosition@3, float3* normal@15, float3* rayDirection@3, float* roughness@9, float4* trace@2, float4* quality@2) {
  float3* origin;
  float4* clipOrigin;
  float4* clipDirection;
  float* depthOrigin;
  float* depthDirection;
  float* previousDistance;
  float2* uv@15;
  float4* param@529;
  float2* param@530;
  float* previousDelta;
  int* steps;
  int* i;
  float* distance@4;
  float4* param@531;
  float2* param@532;
  float* surfaceDepth@4;
  float* delta;
  float* low;
  float* high@3;
  float2* highUv;
  float* highSurfaceDepth;
  float* highDelta;
  int* refine;
  float* middle;
  float2* candidateUv;
  float4* param@533;
  float2* param@534;
  float* candidateDepth;
  float* separation;
  float3* point@2;
  float* confidence;
  float2* param@535;
  float* param@536;
  float* param@537;
  float4* param@538;
  float4* param@539;
  float4* filtered;
  float4x4* param@540;
  float2* param@541;
  float3* param@542;
  float3* param@543;
  float* param@544;
  float* param@545;
  float* param@546;
  float* param@547;
  float* _4842 = &trace@2.x;
  float _4843 = *_4842;
  bool _4844 = _4843 < 0.5000;
  bool _4845 = !_4844;
  
  if(_4845) {
    float _4848 = *roughness@9;
    float* _4849 = &quality@2.y;
    float _4850 = *_4849;
    bool _4851 = _4848 >= _4850;
  }

  bool _4852 = Phi(_4844, _4851);
  
  if(_4852) {
    return {0.0000, 0.0000, 0.0000, 0.0000};
  }

  float3 _4857 = *worldPosition@3;
  float3 _4858 = *normal@15;
  float* _4859 = &trace@2.w;
  float _4860 = *_4859;
  float3 _4861 = _4858 * _4860;
  float3 _4862 = _4857 + _4861;
  *origin = _4862;
  float4x4 _4864 = *worldToClip@3;
  float3 _4865 = *origin;
  float _4866 = _4865.x;
  float _4867 = _4865.y;
  float _4868 = _4865.z;
  float4 _4869 = CompositeConstruct({_4866, _4867, _4868, 1.0000});
  float4 _4870 = _4864 * _4869;
  *clipOrigin = _4870;
  float4x4 _4872 = *worldToClip@3;
  float3 _4873 = *rayDirection@3;
  float _4874 = _4873.x;
  float _4875 = _4873.y;
  float _4876 = _4873.z;
  float4 _4877 = CompositeConstruct({_4874, _4875, _4876, 0.0000});
  float4 _4878 = _4872 * _4877;
  *clipDirection = _4878;
  float3 _4880 = *origin;
  float3 _4881 = *cameraPosition;
  float3 _4882 = _4880 - _4881;
  float3 _4883 = *cameraForward@2;
  float _4884 = Dot(_4882, _4883);
  *depthOrigin = _4884;
  float3 _4886 = *rayDirection@3;
  float3 _4887 = *cameraForward@2;
  float _4888 = Dot(_4886, _4887);
  *depthDirection = _4888;
  *previousDistance = 0.0000;
  float4 _4892 = *clipOrigin;
  *param@529 = _4892;
  bool _4894 = screenReflectionProjectClip(param@529, param@530);
  float2 _4895 = *param@530;
  *uv@15 = _4895;
  bool _4896 = !_4894;
  
  if(_4896) {
    return {0.0000, 0.0000, 0.0000, 0.0000};
  }

  float _4901 = *depthOrigin;
  SampledImage<float, 2D> _4902 = *depth@7;
  float2 _4903 = *uv@15;
  float4 _4904 = ImageSampleImplicitLod(_4902, _4903);
  float _4905 = _4904.x;
  float _4906 = _4901 - _4905;
  *previousDelta = _4906;
  float _4907 = *previousDelta;
  bool _4908 = _4907 >= 0.0000;
  
  if(_4908) {
    return {0.0000, 0.0000, 0.0000, 0.0000};
  }

  float* _4913 = &quality@2.x;
  float _4914 = *_4913;
  float _4915 = _4914 + 0.5000;
  int _4916 = ConvertFToS(_4915);
  int _4919 = GLSL.std.450::SClamp(_4916, 8, 256);
  *steps = _4919;
  *i = 1;

  while(true) {
    int _4926 = *i;
    bool _4927 = _4926 <= 256;
    if(!_4927) break;
    int _4928 = *i;
    int _4929 = *steps;
    bool _4930 = _4928 > _4929;
    
    if(_4930) {
      break;
    }

    float* _4935 = &trace@2.y;
    float _4936 = *_4935;
    int _4937 = *i;
    float _4938 = ConvertSToF(_4937);
    float _4939 = _4936 * _4938;
    int _4940 = *steps;
    float _4941 = ConvertSToF(_4940);
    float _4942 = _4939 / _4941;
    *distance@4 = _4942;
    float4 _4943 = *clipOrigin;
    float4 _4944 = *clipDirection;
    float _4945 = *distance@4;
    float4 _4946 = _4944 * _4945;
    float4 _4947 = _4943 + _4946;
    *param@531 = _4947;
    bool _4950 = screenReflectionProjectClip(param@531, param@532);
    float2 _4951 = *param@532;
    *uv@15 = _4951;
    bool _4952 = !_4950;
    
    if(_4952) {
      return {0.0000, 0.0000, 0.0000, 0.0000};
    }

    SampledImage<float, 2D> _4957 = *depth@7;
    float2 _4958 = *uv@15;
    float4 _4959 = ImageSampleImplicitLod(_4957, _4958);
    float _4960 = _4959.x;
    *surfaceDepth@4 = _4960;
    float _4962 = *depthOrigin;
    float _4963 = *depthDirection;
    float _4964 = *distance@4;
    float _4965 = _4963 * _4964;
    float _4966 = _4962 + _4965;
    float _4967 = *surfaceDepth@4;
    float _4968 = _4966 - _4967;
    *delta = _4968;
    float _4969 = *previousDelta;
    bool _4970 = _4969 < 0.0000;
    float _4971 = *delta;
    bool _4972 = _4971 >= 0.0000;
    bool _4973 = _4970 && _4972;
    
    if(_4973) {
      float _4977 = *previousDistance;
      *low = _4977;
      float _4979 = *distance@4;
      *high@3 = _4979;
      float2 _4981 = *uv@15;
      *highUv = _4981;
      float _4983 = *surfaceDepth@4;
      *highSurfaceDepth = _4983;
      float _4985 = *delta;
      *highDelta = _4985;
      *refine = 0;

      while(true) {
        int _4992 = *refine;
        bool _4994 = _4992 < 6;
        if(!_4994) break;
        float _4996 = *low;
        float _4997 = *high@3;
        float _4998 = _4996 + _4997;
        float _4999 = _4998 * 0.5000;
        *middle = _4999;
        float4 _5000 = *clipOrigin;
        float4 _5001 = *clipDirection;
        float _5002 = *middle;
        float4 _5003 = _5001 * _5002;
        float4 _5004 = _5000 + _5003;
        *param@533 = _5004;
        bool _5008 = screenReflectionProjectClip(param@533, param@534);
        float2 _5009 = *param@534;
        *candidateUv = _5009;
        bool _5010 = !_5008;
        
        if(_5010) {
          return {0.0000, 0.0000, 0.0000, 0.0000};
        }

        SampledImage<float, 2D> _5015 = *depth@7;
        float2 _5016 = *candidateUv;
        float4 _5017 = ImageSampleImplicitLod(_5015, _5016);
        float _5018 = _5017.x;
        *candidateDepth = _5018;
        float _5020 = *depthOrigin;
        float _5021 = *depthDirection;
        float _5022 = *middle;
        float _5023 = _5021 * _5022;
        float _5024 = _5020 + _5023;
        float _5025 = *candidateDepth;
        float _5026 = _5024 - _5025;
        *separation = _5026;
        float _5027 = *separation;
        bool _5028 = _5027 >= 0.0000;
        
        if(_5028) {
          float _5031 = *middle;
          *high@3 = _5031;
          float2 _5032 = *candidateUv;
          *highUv = _5032;
          float _5033 = *candidateDepth;
          *highSurfaceDepth = _5033;
          float _5034 = *separation;
          *highDelta = _5034;
        } else {
          float _5036 = *middle;
          *low = _5036;
        }

        int _5037 = *refine;
        int _5038 = _5037 + 1;
        *refine = _5038;
      }

      float3 _5040 = *origin;
      float3 _5041 = *rayDirection@3;
      float _5042 = *high@3;
      float3 _5043 = _5041 * _5042;
      float3 _5044 = _5040 + _5043;
      *point@2 = _5044;
      float2 _5045 = *highUv;
      *uv@15 = _5045;
      float _5046 = *highSurfaceDepth;
      *surfaceDepth@4 = _5046;
      float _5047 = *highDelta;
      *delta = _5047;
      float _5048 = *surfaceDepth@4;
      bool _5049 = _5048 <= 0.0000;
      float _5050 = *delta;
      bool _5051 = _5050 < 0.0000;
      bool _5052 = _5049 || _5051;
      bool _5053 = !_5052;
      
      if(_5053) {
        float _5056 = *delta;
        float* _5057 = &trace@2.z;
        float _5058 = *_5057;
        bool _5059 = _5056 > _5058;
      }

      bool _5060 = Phi(_5052, _5059);
      
      if(_5060) {
        return {0.0000, 0.0000, 0.0000, 0.0000};
      }

      float2 _5066 = *uv@15;
      *param@535 = _5066;
      float _5068 = *roughness@9;
      *param@536 = _5068;
      float _5070 = *high@3;
      *param@537 = _5070;
      float4 _5072 = *trace@2;
      *param@538 = _5072;
      float4 _5074 = *quality@2;
      *param@539 = _5074;
      float _5075 = screenReflectionConfidence(param@535, param@536, param@537, param@538, param@539);
      *confidence = _5075;
      float4x4 _5078 = *worldToClip@3;
      *param@540 = _5078;
      float2 _5080 = *uv@15;
      *param@541 = _5080;
      float3 _5082 = *point@2;
      *param@542 = _5082;
      float3 _5084 = *rayDirection@3;
      *param@543 = _5084;
      float _5086 = *high@3;
      *param@544 = _5086;
      float _5088 = *roughness@9;
      *param@545 = _5088;
      float _5090 = *surfaceDepth@4;
      *param@546 = _5090;
      float* _5092 = &trace@2.z;
      float _5093 = *_5092;
      *param@547 = _5093;
      float4 _5094 = screenReflectionFilteredRadiance(source@5, depth@7, param@540, param@541, param@542, param@543, param@544, param@545, param@546, param@547);
      *filtered = _5094;
      float4 _5095 = *filtered;
      float3 _5096 = _5095.xyz;
      float _5097 = *confidence;
      float* _5098 = &filtered.w;
      float _5099 = *_5098;
      float _5100 = _5097 * _5099;
      float _5101 = _5096.x;
      float _5102 = _5096.y;
      float _5103 = _5096.z;
      float4 _5104 = CompositeConstruct({_5101, _5102, _5103, _5100});
      return _5104;
    }

    float _5106 = *delta;
    *previousDelta = _5106;
    float _5107 = *distance@4;
    *previousDistance = _5107;
    int _5108 = *i;
    int _5109 = _5108 + 1;
    *i = _5109;
  }

  return {0.0000, 0.0000, 0.0000, 0.0000};
}

float4 sampleComputedScreenReflection(float2* uv@16) {
  int2* size;
  float2* pixel@9;
  int2* first@3;
  float2* f@2;
  int* tap@3;
  float4[4]* taps@2;
  StorageImage<float, 2D> _5116 = *computedScreenReflection;
  int2 _5117 = ImageQuerySize(_5116);
  *size = _5117;
  float2 _5119 = *uv@16;
  int2 _5120 = *size;
  float2 _5121 = ConvertSToF(_5120);
  float2 _5122 = _5119 * _5121;
  float2 _5123 = CompositeConstruct({0.5000, 0.5000});
  float2 _5124 = _5122 - _5123;
  *pixel@9 = _5124;
  float2 _5126 = *pixel@9;
  float2 _5127 = GLSL.std.450::Floor(_5126);
  int2 _5128 = ConvertFToS(_5127);
  *first@3 = _5128;
  float2 _5130 = *pixel@9;
  float2 _5131 = GLSL.std.450::Fract(_5130);
  *f@2 = _5131;
  *tap@3 = 0;

  while(true) {
    int _5138 = *tap@3;
    bool _5139 = _5138 < 4;
    if(!_5139) break;
    int _5144 = *tap@3;
    StorageImage<float, 2D> _5145 = *computedScreenReflection;
    int2 _5146 = *first@3;
    int _5147 = *tap@3;
    int _5148 = SMod(_5147, 2);
    int _5149 = *tap@3;
    int _5150 = _5149 / 2;
    int2 _5151 = CompositeConstruct({_5148, _5150});
    int2 _5152 = _5146 + _5151;
    int2 _5153 = *size;
    int2 _5154 = CompositeConstruct({1, 1});
    int2 _5155 = _5153 - _5154;
    int2 _5156 = GLSL.std.450::SClamp(_5152, {0, 0}, _5155);
    float4 _5157 = ImageRead(_5145, _5156);
    float4* _5158 = &taps@2[_5144];
    *_5158 = _5157;
    int _5159 = *tap@3;
    int _5160 = _5159 + 1;
    *tap@3 = _5160;
  }

  float4* _5161 = &taps@2[0];
  float4 _5162 = *_5161;
  float4* _5163 = &taps@2[1];
  float4 _5164 = *_5163;
  float* _5165 = &f@2.x;
  float _5166 = *_5165;
  float4 _5167 = CompositeConstruct({_5166, _5166, _5166, _5166});
  float4 _5168 = GLSL.std.450::FMix(_5162, _5164, _5167);
  float4* _5169 = &taps@2[2];
  float4 _5170 = *_5169;
  float4* _5172 = &taps@2[3];
  float4 _5173 = *_5172;
  float* _5174 = &f@2.x;
  float _5175 = *_5174;
  float4 _5176 = CompositeConstruct({_5175, _5175, _5175, _5175});
  float4 _5177 = GLSL.std.450::FMix(_5170, _5173, _5176);
  float* _5178 = &f@2.y;
  float _5179 = *_5178;
  float4 _5180 = CompositeConstruct({_5179, _5179, _5179, _5179});
  float4 _5181 = GLSL.std.450::FMix(_5168, _5177, _5180);
  return _5181;
}

float2 octahedralEnvironmentUv(float3* direction@3, float4* atlas, bool* positiveZero) {
  float3* n@2;
  float3* signs;
  float* denominator@5;
  float3* oct;
  float2* _5209;
  float2* uv@17;
  float3 _5185 = *direction@3;
  float3 _5186 = GLSL.std.450::Normalize(_5185);
  *n@2 = _5186;
  float3 _5188 = *n@2;
  float3 _5189 = GLSL.std.450::FSign(_5188);
  *signs = _5189;
  float3 _5191 = *n@2;
  float3 _5192 = *signs;
  float _5193 = Dot(_5191, _5192);
  *denominator@5 = _5193;
  float3 _5195 = *n@2;
  float _5196 = *denominator@5;
  float3 _5197 = CompositeConstruct({_5196, _5196, _5196});
  float3 _5198 = _5195 / _5197;
  *oct = _5198;
  float* _5199 = &oct.z;
  float _5200 = *_5199;
  bool _5201 = _5200 < 0.0000;
  
  if(_5201) {
    float3 _5204 = *oct;
    float2 _5205 = _5204.yx;
    float2 _5206 = GLSL.std.450::FAbs(_5205);
    float2 _5207 = {1.0000, 1.0000} - _5206;
    bool _5208 = *positiveZero;
    
    if(_5208) {
      float3 _5212 = *n@2;
      float2 _5213 = _5212.xy;
      bool _5214 = _5213 >= {0.0000, 0.0000};
      float2 _5215 = Select(_5214, {1.0000, 1.0000}, {-1.0000, -1.0000});
      *_5209 = _5215;
    } else {
      float3 _5217 = *signs;
      float2 _5218 = _5217.xy;
      *_5209 = _5218;
    }

    float2 _5219 = *_5209;
    float2 _5220 = _5207 * _5219;
    float* _5221 = &oct.x;
    float _5222 = _5220.x;
    *_5221 = _5222;
    float* _5223 = &oct.y;
    float _5224 = _5220.y;
    *_5223 = _5224;
  }

  float3 _5226 = *oct;
  float2 _5227 = _5226.xy;
  float2 _5228 = GLSL.std.450::Fma(_5227, {0.5000, 0.5000}, {0.5000, 0.5000});
  *uv@17 = _5228;
  float2 _5229 = *uv@17;
  float4 _5230 = *atlas;
  float2 _5231 = _5230.xy;
  float4 _5232 = *atlas;
  float2 _5233 = _5232.zw;
  float2 _5234 = GLSL.std.450::Fma(_5229, _5231, _5233);
  return _5234;
}

float probeFieldAdapt(float4* sh, float3* normal@16, float* luminance) {
  float* reference@2;
  float* ratio;
  float4 _5238 = *sh;
  float3 _5239 = *normal@16;
  float _5240 = _5239.x;
  float _5241 = _5239.y;
  float _5242 = _5239.z;
  float4 _5243 = CompositeConstruct({_5240, _5241, _5242, 1.0000});
  float _5244 = Dot(_5238, _5243);
  float _5245 = GLSL.std.450::FMax(_5244, 0.0001);
  *reference@2 = _5245;
  float _5247 = *luminance;
  float _5248 = *luminance;
  float _5249 = *reference@2;
  float _5250 = _5248 / _5249;
  float _5251 = GLSL.std.450::FAbs(_5250);
  float _5252 = GLSL.std.450::FMin(_5251, 1.0000);
  float _5253 = 2.0000 * _5252;
  float _5254 = _5247 + _5253;
  float _5255 = *reference@2;
  float _5256 = _5255 + 2.0000;
  float _5257 = _5254 / _5256;
  *ratio = _5257;
  float _5258 = *ratio;
  float _5259 = _5258 - 1.0000;
  float* _5265 = &ReflectionField_var.probeFieldRows[1].z;
  float _5266 = *_5265;
  float _5267 = GLSL.std.450::Fma(_5259, _5266, 1.0000);
  return _5267;
}

float4 reflectionProbeFieldRadiance(SampledImage<float, 2DArray>* source@6, float3* position@2, float3* direction@4, float3* normal@17, float* luminance@2, float* lod@2) {
  float3x3* fieldMapping;
  float3* color@8;
  float* remaining;
  uint* i@2;
  uint* first@4;
  float4* extent@7;
  float4* blend@4;
  float4* flags@2;
  float3* local@2;
  float3* edges;
  float* box;
  float* radius@4;
  float3* radial@6;
  float2* squared@5;
  float* distanceSquared@3;
  float* sphere;
  float* weight@8;
  float3* sampleDirection;
  float3* ray@2;
  float3* distances;
  int* axis@3;
  float* _5513;
  float2* uv@18;
  float3* param@548;
  float4* param@549;
  bool* param@550;
  float3* radiance@6;
  float4* param@551;
  float3* param@552;
  float* param@553;
  float2* uv@19;
  float3* param@554;
  float4* param@555;
  bool* param@556;
  float3* radiance@7;
  float4* param@557;
  float3* param@558;
  float* param@559;
  float4* _5272 = &ReflectionField_var.probeFieldRows[4];
  float4 _5273 = *_5272;
  float3 _5274 = _5273.xyz;
  float4* _5276 = &ReflectionField_var.probeFieldRows[5];
  float4 _5277 = *_5276;
  float3 _5278 = _5277.xyz;
  float4* _5279 = &ReflectionField_var.probeFieldRows[6];
  float4 _5280 = *_5279;
  float3 _5281 = _5280.xyz;
  float _5282 = _5274.x;
  float _5283 = _5274.y;
  float _5284 = _5274.z;
  float _5285 = _5278.x;
  float _5286 = _5278.y;
  float _5287 = _5278.z;
  float _5288 = _5281.x;
  float _5289 = _5281.y;
  float _5290 = _5281.z;
  float3 _5291 = CompositeConstruct({_5282, _5283, _5284});
  float3 _5292 = CompositeConstruct({_5285, _5286, _5287});
  float3 _5293 = CompositeConstruct({_5288, _5289, _5290});
  float3x3 _5294 = CompositeConstruct({_5291, _5292, _5293});
  float3x3 _5295 = Transpose(_5294);
  *fieldMapping = _5295;
  float3x3 _5296 = *fieldMapping;
  float3 _5297 = *position@2;
  float3 _5298 = _5296 * _5297;
  *position@2 = _5298;
  float3x3 _5299 = *fieldMapping;
  float3 _5300 = *direction@4;
  float3 _5301 = _5299 * _5300;
  *direction@4 = _5301;
  float3x3 _5302 = *fieldMapping;
  float3 _5303 = *normal@17;
  float3 _5304 = _5302 * _5303;
  *normal@17 = _5304;
  *color@8 = {0.0000, 0.0000, 0.0000};
  *remaining = 1.0000;
  *i@2 = 0;

  while(true) {
    uint _5313 = *i@2;
    float* _5314 = &ReflectionField_var.probeFieldRows[1].x;
    float _5315 = *_5314;
    uint _5316 = ConvertFToU(_5315);
    bool _5317 = _5313 < _5316;
    float _5318 = *remaining;
    bool _5319 = _5318 > 0.0100;
    bool _5320 = _5317 && _5319;
    if(!_5320) break;
    uint _5323 = *i@2;
    uint _5324 = 7 * _5323;
    uint _5325 = 7 + _5324;
    *first@4 = _5325;
    uint _5327 = *first@4;
    uint _5328 = _5327 + 1;
    float4* _5329 = &ReflectionField_var.probeFieldRows[_5328];
    float4 _5330 = *_5329;
    *extent@7 = _5330;
    uint _5332 = *first@4;
    uint _5333 = _5332 + 5;
    float4* _5334 = &ReflectionField_var.probeFieldRows[_5333];
    float4 _5335 = *_5334;
    *blend@4 = _5335;
    uint _5337 = *first@4;
    uint _5338 = _5337 + 6;
    float4* _5339 = &ReflectionField_var.probeFieldRows[_5338];
    float4 _5340 = *_5339;
    *flags@2 = _5340;
    uint _5342 = *first@4;
    uint _5343 = _5342 + 2;
    float4* _5344 = &ReflectionField_var.probeFieldRows[_5343];
    float4 _5345 = *_5344;
    float3 _5346 = *position@2;
    float _5347 = _5346.x;
    float _5348 = _5346.y;
    float _5349 = _5346.z;
    float4 _5350 = CompositeConstruct({_5347, _5348, _5349, 1.0000});
    float _5351 = Dot(_5345, _5350);
    uint _5352 = *first@4;
    uint _5353 = _5352 + 3;
    float4* _5354 = &ReflectionField_var.probeFieldRows[_5353];
    float4 _5355 = *_5354;
    float3 _5356 = *position@2;
    float _5357 = _5356.x;
    float _5358 = _5356.y;
    float _5359 = _5356.z;
    float4 _5360 = CompositeConstruct({_5357, _5358, _5359, 1.0000});
    float _5361 = Dot(_5355, _5360);
    uint _5362 = *first@4;
    uint _5363 = _5362 + 4;
    float4* _5364 = &ReflectionField_var.probeFieldRows[_5363];
    float4 _5365 = *_5364;
    float3 _5366 = *position@2;
    float _5367 = _5366.x;
    float _5368 = _5366.y;
    float _5369 = _5366.z;
    float4 _5370 = CompositeConstruct({_5367, _5368, _5369, 1.0000});
    float _5371 = Dot(_5365, _5370);
    float3 _5372 = CompositeConstruct({_5351, _5361, _5371});
    *local@2 = _5372;
    float3 _5373 = *local@2;
    float3 _5374 = GLSL.std.450::FAbs(_5373);
    float4 _5375 = *extent@7;
    float3 _5376 = _5375.xyz;
    bool _5377 = _5374 > _5376;
    bool _5378 = Any(_5377);
    
    if(_5378) {
      goto loop_continue3;
    }

    float4 _5383 = *extent@7;
    float3 _5384 = _5383.xyz;
    float3 _5385 = *local@2;
    float3 _5386 = GLSL.std.450::FAbs(_5385);
    float3 _5387 = _5384 - _5386;
    float4 _5388 = *blend@4;
    float3 _5389 = _5388.xyz;
    float3 _5390 = _5387 * _5389;
    *edges = _5390;
    float* _5392 = &edges.x;
    float _5393 = *_5392;
    float* _5394 = &edges.y;
    float _5395 = *_5394;
    float* _5396 = &edges.z;
    float _5397 = *_5396;
    float _5398 = GLSL.std.450::FMin(_5395, _5397);
    float _5399 = GLSL.std.450::FMin(_5393, _5398);
    *box = _5399;
    float* _5401 = &extent@7.x;
    float _5402 = *_5401;
    float _5403 = _5402 * 0.1000;
    *radius@4 = _5403;
    float3 _5405 = *local@2;
    float3 _5406 = GLSL.std.450::FAbs(_5405);
    float3 _5407 = _5406 * 0.1000;
    *radial@6 = _5407;
    float3 _5409 = *radial@6;
    float2 _5410 = _5409.xy;
    float3 _5411 = *radial@6;
    float2 _5412 = _5411.xy;
    float2 _5413 = _5410 * _5412;
    *squared@5 = _5413;
    float* _5415 = &radial@6.z;
    float _5416 = *_5415;
    float* _5417 = &radial@6.z;
    float _5418 = *_5417;
    float* _5419 = &squared@5.x;
    float _5420 = *_5419;
    float* _5421 = &squared@5.y;
    float _5422 = *_5421;
    float _5423 = _5420 + _5422;
    float _5424 = GLSL.std.450::Fma(_5416, _5418, _5423);
    *distanceSquared@3 = _5424;
    float _5426 = *radius@4;
    float _5427 = *radius@4;
    float _5428 = *distanceSquared@3;
    float _5429 = -_5428;
    float _5430 = GLSL.std.450::Fma(_5426, _5427, _5429);
    float* _5431 = &blend@4.x;
    float _5432 = *_5431;
    float _5433 = _5430 * _5432;
    *sphere = _5433;
    float _5434 = *sphere;
    float* _5435 = &blend@4.x;
    float _5436 = *_5435;
    float _5437 = _5434 * _5436;
    *sphere = _5437;
    float _5438 = *sphere;
    float* _5439 = &flags@2.y;
    float _5440 = *_5439;
    float _5441 = 1.0000 - _5440;
    float _5442 = _5438 * _5441;
    *sphere = _5442;
    float _5443 = *sphere;
    float _5445 = _5443 * 100.0000;
    *sphere = _5445;
    float _5447 = *box;
    float* _5448 = &flags@2.y;
    float _5449 = *_5448;
    float _5450 = *sphere;
    float _5451 = GLSL.std.450::Fma(_5447, _5449, _5450);
    float _5452 = GLSL.std.450::FClamp(_5451, 0.0000, 1.0000);
    float* _5453 = &flags@2.w;
    float _5454 = *_5453;
    float _5455 = _5452 * _5454;
    *weight@8 = _5455;
    float _5456 = *weight@8;
    bool _5457 = _5456 <= 0.0000;
    
    if(_5457) {
      goto loop_continue3;
    }

    float3 _5462 = *direction@4;
    *sampleDirection = _5462;
    float* _5463 = &flags@2.x;
    float _5464 = *_5463;
    bool _5465 = _5464 > 0.5000;
    
    if(_5465) {
      uint _5469 = *first@4;
      uint _5470 = _5469 + 2;
      float4* _5471 = &ReflectionField_var.probeFieldRows[_5470];
      float4 _5472 = *_5471;
      float3 _5473 = _5472.xyz;
      float3 _5474 = *direction@4;
      float _5475 = Dot(_5473, _5474);
      uint _5476 = *first@4;
      uint _5477 = _5476 + 3;
      float4* _5478 = &ReflectionField_var.probeFieldRows[_5477];
      float4 _5479 = *_5478;
      float3 _5480 = _5479.xyz;
      float3 _5481 = *direction@4;
      float _5482 = Dot(_5480, _5481);
      uint _5483 = *first@4;
      uint _5484 = _5483 + 4;
      float4* _5485 = &ReflectionField_var.probeFieldRows[_5484];
      float4 _5486 = *_5485;
      float3 _5487 = _5486.xyz;
      float3 _5488 = *direction@4;
      float _5489 = Dot(_5487, _5488);
      float3 _5490 = CompositeConstruct({_5475, _5482, _5489});
      *ray@2 = _5490;
      *distances = {340282306073709670000000000000000000000.0000, 340282306073709670000000000000000000000.0000, 340282306073709670000000000000000000000.0000};
      *axis@3 = 0;

      while(true) {
        int _5500 = *axis@3;
        bool _5501 = _5500 < 3;
        if(!_5501) break;
        int _5502 = *axis@3;
        float* _5503 = &ray@2[_5502];
        float _5504 = *_5503;
        bool _5505 = _5504 != 0.0000;
        
        if(_5505) {
          int _5508 = *axis@3;
          int _5509 = *axis@3;
          float* _5510 = &ray@2[_5509];
          float _5511 = *_5510;
          bool _5512 = _5511 > 0.0000;
          
          if(_5512) {
            int _5516 = *axis@3;
            float* _5517 = &extent@7[_5516];
            float _5518 = *_5517;
            *_5513 = _5518;
          } else {
            int _5520 = *axis@3;
            float* _5521 = &extent@7[_5520];
            float _5522 = *_5521;
            float _5523 = -_5522;
            *_5513 = _5523;
          }

          float _5524 = *_5513;
          int _5525 = *axis@3;
          float* _5526 = &local@2[_5525];
          float _5527 = *_5526;
          float _5528 = _5524 - _5527;
          int _5529 = *axis@3;
          float* _5530 = &ray@2[_5529];
          float _5531 = *_5530;
          float _5532 = _5528 / _5531;
          float* _5533 = &distances[_5508];
          *_5533 = _5532;
        }

        int _5534 = *axis@3;
        int _5535 = _5534 + 1;
        *axis@3 = _5535;
      }

      float3 _5536 = *ray@2;
      float* _5537 = &distances.x;
      float _5538 = *_5537;
      float* _5539 = &distances.y;
      float _5540 = *_5539;
      float* _5541 = &distances.z;
      float _5542 = *_5541;
      float _5543 = GLSL.std.450::FMin(_5540, _5542);
      float _5544 = GLSL.std.450::FMin(_5538, _5543);
      float3 _5545 = CompositeConstruct({_5544, _5544, _5544});
      float3 _5546 = *local@2;
      float3 _5547 = GLSL.std.450::Fma(_5536, _5545, _5546);
      *sampleDirection = _5547;
    }

    float* _5549 = &ReflectionField_var.probeFieldRows[3].x;
    float _5550 = *_5549;
    bool _5551 = _5550 > 0.5000;
    float3 _5553 = *sampleDirection;
    *param@548 = _5553;
    float4* _5555 = &ReflectionField_var.probeFieldRows[2];
    float4 _5556 = *_5555;
    *param@549 = _5556;
    *param@550 = _5551;
    float2 _5558 = octahedralEnvironmentUv(param@548, param@549, param@550);
    *uv@18 = _5558;
    SampledImage<float, 2DArray> _5560 = *source@6;
    float2 _5561 = *uv@18;
    float* _5562 = &extent@7.w;
    float _5563 = *_5562;
    float _5564 = _5561.x;
    float _5565 = _5561.y;
    float3 _5566 = CompositeConstruct({_5564, _5565, _5563});
    float _5567 = *lod@2;
    float4 _5568 = ImageSampleExplicitLod(_5560, _5566, Lod(_5567));
    float3 _5569 = _5568.xyz;
    float* _5570 = &blend@4.w;
    float _5571 = *_5570;
    float3 _5572 = _5569 * _5571;
    *radiance@6 = _5572;
    uint _5573 = *first@4;
    float4* _5575 = &ReflectionField_var.probeFieldRows[_5573];
    float4 _5576 = *_5575;
    *param@551 = _5576;
    float3 _5578 = *normal@17;
    *param@552 = _5578;
    float _5580 = *luminance@2;
    *param@553 = _5580;
    float _5581 = probeFieldAdapt(param@551, param@552, param@553);
    float3 _5582 = *radiance@6;
    float3 _5583 = _5582 * _5581;
    *radiance@6 = _5583;
    float3 _5584 = *radiance@6;
    float _5585 = *weight@8;
    float3 _5586 = _5584 * _5585;
    float _5587 = *remaining;
    float3 _5588 = CompositeConstruct({_5587, _5587, _5587});
    float3 _5589 = *color@8;
    float3 _5590 = GLSL.std.450::Fma(_5586, _5588, _5589);
    *color@8 = _5590;
    float _5591 = *weight@8;
    float _5592 = 1.0000 - _5591;
    float _5593 = *remaining;
    float _5594 = _5593 * _5592;
    *remaining = _5594;
loop_continue3:
    uint _5595 = *i@2;
    uint _5596 = _5595 + 1;
    *i@2 = _5596;
  }

  float _5597 = *remaining;
  bool _5598 = _5597 > 0.0100;
  
  if(_5598) {
    float* _5602 = &ReflectionField_var.probeFieldRows[3].x;
    float _5603 = *_5602;
    bool _5604 = _5603 > 0.5000;
    float3 _5606 = *direction@4;
    *param@554 = _5606;
    float4* _5608 = &ReflectionField_var.probeFieldRows[2];
    float4 _5609 = *_5608;
    *param@555 = _5609;
    *param@556 = _5604;
    float2 _5611 = octahedralEnvironmentUv(param@554, param@555, param@556);
    *uv@19 = _5611;
    SampledImage<float, 2DArray> _5613 = *source@6;
    float2 _5614 = *uv@19;
    float* _5615 = &ReflectionField_var.probeFieldRows[1].y;
    float _5616 = *_5615;
    float _5617 = _5614.x;
    float _5618 = _5614.y;
    float3 _5619 = CompositeConstruct({_5617, _5618, _5616});
    float _5620 = *lod@2;
    float4 _5621 = ImageSampleExplicitLod(_5613, _5619, Lod(_5620));
    float3 _5622 = _5621.xyz;
    *radiance@7 = _5622;
    float4* _5624 = &ReflectionField_var.probeFieldRows[0];
    float4 _5625 = *_5624;
    *param@557 = _5625;
    float3 _5627 = *normal@17;
    *param@558 = _5627;
    float _5629 = *luminance@2;
    *param@559 = _5629;
    float _5630 = probeFieldAdapt(param@557, param@558, param@559);
    float3 _5631 = *radiance@7;
    float3 _5632 = _5631 * _5630;
    *radiance@7 = _5632;
    float3 _5633 = *radiance@7;
    float _5634 = *remaining;
    float3 _5635 = CompositeConstruct({_5634, _5634, _5634});
    float3 _5636 = *color@8;
    float3 _5637 = GLSL.std.450::Fma(_5633, _5635, _5636);
    *color@8 = _5637;
  }

  float3 _5638 = *color@8;
  float* _5639 = &ReflectionField_var.probeFieldRows[1].w;
  float _5640 = *_5639;
  float3 _5641 = _5638 * _5640;
  float _5642 = *remaining;
  float _5643 = _5641.x;
  float _5644 = _5641.y;
  float _5645 = _5641.z;
  float4 _5646 = CompositeConstruct({_5643, _5644, _5645, _5642});
  return _5646;
}

IrradianceClipmapLayerSample sampleIrradianceClipmapLayer(SampledImage<float, 3D>* amplitude@2, SampledImage<float, 3D>* directional@2, float3* dimensions, float3* position@3, float* spacing) {
  float3* uv@20;
  IrradianceClipmapLayerSample* result@2;
  float3 _5650 = *position@3;
  float _5651 = *spacing;
  float3 _5652 = CompositeConstruct({_5651, _5651, _5651});
  float3 _5653 = _5650 / _5652;
  float3 _5654 = CompositeConstruct({0.5000, 0.5000, 0.5000});
  float3 _5655 = _5653 + _5654;
  float3 _5656 = *dimensions;
  float3 _5657 = _5655 / _5656;
  float3 _5658 = GLSL.std.450::Fract(_5657);
  *uv@20 = _5658;
  SampledImage<float, 3D> _5661 = *amplitude@2;
  float3 _5662 = *uv@20;
  float4 _5663 = ImageSampleExplicitLod(_5661, _5662, Lod(0.0000));
  float3 _5664 = _5663.xyz;
  float3* _5665 = &result@2.amplitude;
  *_5665 = _5664;
  float* _5666 = &uv@20.y;
  float _5667 = *_5666;
  float* _5668 = &dimensions.y;
  float _5669 = *_5668;
  float _5670 = 0.5000 / _5669;
  float* _5671 = &dimensions.y;
  float _5672 = *_5671;
  float _5673 = 0.5000 / _5672;
  float _5674 = 1.0000 - _5673;
  float _5675 = GLSL.std.450::FClamp(_5667, _5670, _5674);
  float _5676 = _5675 / 3.0000;
  float* _5677 = &uv@20.y;
  *_5677 = _5676;
  SampledImage<float, 3D> _5678 = *directional@2;
  float3 _5679 = *uv@20;
  float4 _5680 = ImageSampleExplicitLod(_5678, _5679, Lod(0.0000));
  float4* _5681 = &result@2.red;
  *_5681 = _5680;
  SampledImage<float, 3D> _5682 = *directional@2;
  float3 _5683 = *uv@20;
  float3 _5686 = _5683 + {0.0000, 0.3333, 0.0000};
  float4 _5687 = ImageSampleExplicitLod(_5682, _5686, Lod(0.0000));
  float4* _5688 = &result@2.green;
  *_5688 = _5687;
  SampledImage<float, 3D> _5689 = *directional@2;
  float3 _5690 = *uv@20;
  float3 _5693 = _5690 + {0.0000, 0.6667, 0.0000};
  float4 _5694 = ImageSampleExplicitLod(_5689, _5693, Lod(0.0000));
  float4* _5695 = &result@2.blue;
  *_5695 = _5694;
  IrradianceClipmapLayerSample _5696 = *result@2;
  return _5696;
}

IrradianceClipmapResult evaluateIrradianceClipmap(SampledImage<float, 3D>[6]* textures, float4[13]* parameters@3, float3* world) {
  float3* position@4;
  int* i@3;
  float3* distance@5;
  float3* fade@2;
  float3* fades;
  IrradianceClipmapResult* result@3;
  float4x3* coefficients;
  float3* weights@3;
  int* i@4;
  IrradianceClipmapLayerSample[3]* samples;
  float3* param@560;
  float3* param@561;
  float* param@562;
  float3* param@563;
  float3* param@564;
  float* param@565;
  float3* param@566;
  float3* param@567;
  float* param@568;
  float* alpha@7;
  int* i@5;
  float* remapped;
  float* u@3;
  float* v@3;
  int* c;
  float4* color@9;
  int* i@6;
  float4* direction@5;
  float4* _5981;
  float4* _5990;
  float4* defaults@2;
  int* c@2;
  float4* _5700 = &parameters@3[1];
  float4 _5701 = *_5700;
  float3 _5702 = *world;
  float _5703 = _5702.x;
  float _5704 = _5702.y;
  float _5705 = _5702.z;
  float4 _5706 = CompositeConstruct({_5703, _5704, _5705, 1.0000});
  float _5707 = Dot(_5701, _5706);
  float4* _5708 = &parameters@3[2];
  float4 _5709 = *_5708;
  float3 _5710 = *world;
  float _5711 = _5710.x;
  float _5712 = _5710.y;
  float _5713 = _5710.z;
  float4 _5714 = CompositeConstruct({_5711, _5712, _5713, 1.0000});
  float _5715 = Dot(_5709, _5714);
  float4* _5716 = &parameters@3[3];
  float4 _5717 = *_5716;
  float3 _5718 = *world;
  float _5719 = _5718.x;
  float _5720 = _5718.y;
  float _5721 = _5718.z;
  float4 _5722 = CompositeConstruct({_5719, _5720, _5721, 1.0000});
  float _5723 = Dot(_5717, _5722);
  float3 _5724 = CompositeConstruct({_5707, _5715, _5723});
  *position@4 = _5724;
  *i@3 = 0;

  while(true) {
    int _5731 = *i@3;
    bool _5732 = _5731 < 3;
    if(!_5732) break;
    float3 _5734 = *position@4;
    int _5736 = *i@3;
    int _5737 = 2 * _5736;
    int _5738 = 7 + _5737;
    float4* _5739 = &parameters@3[_5738];
    float4 _5740 = *_5739;
    float3 _5741 = _5740.xyz;
    float3 _5742 = _5734 - _5741;
    float3 _5743 = GLSL.std.450::FAbs(_5742);
    *distance@5 = _5743;
    int _5745 = *i@3;
    int _5746 = 2 * _5745;
    int _5747 = 8 + _5746;
    float4* _5748 = &parameters@3[_5747];
    float4 _5749 = *_5748;
    float3 _5750 = _5749.xyz;
    *fade@2 = _5750;
    int _5752 = *i@3;
    float* _5753 = &distance@5.x;
    float _5754 = *_5753;
    float* _5755 = &distance@5.z;
    float _5756 = *_5755;
    float _5757 = GLSL.std.450::FMax(_5754, _5756);
    float* _5758 = &fade@2.x;
    float _5759 = *_5758;
    float _5760 = _5757 - _5759;
    float* _5761 = &fade@2.z;
    float _5762 = *_5761;
    float _5763 = _5760 / _5762;
    float _5764 = GLSL.std.450::FClamp(_5763, 0.0000, 1.0000);
    float* _5765 = &distance@5.y;
    float _5766 = *_5765;
    float* _5767 = &fade@2.y;
    float _5768 = *_5767;
    float _5769 = _5766 - _5768;
    float* _5770 = &fade@2.z;
    float _5771 = *_5770;
    float _5772 = _5769 / _5771;
    float _5773 = GLSL.std.450::FClamp(_5772, 0.0000, 1.0000);
    float _5774 = GLSL.std.450::FMax(_5764, _5773);
    float* _5775 = &fades[_5752];
    *_5775 = _5774;
    int _5776 = *i@3;
    int _5777 = _5776 + 1;
    *i@3 = _5777;
  }

  float3x3* _5781 = &result@3.alpha;
  *_5781 = _5780;
  float4* _5784 = &parameters@3[4];
  float4 _5785 = *_5784;
  float4* _5786 = &parameters@3[5];
  float4 _5787 = *_5786;
  float4* _5788 = &parameters@3[6];
  float4 _5789 = *_5788;
  float _5790 = _5785.x;
  float _5791 = _5785.y;
  float _5792 = _5785.z;
  float _5793 = _5785.w;
  float _5794 = _5787.x;
  float _5795 = _5787.y;
  float _5796 = _5787.z;
  float _5797 = _5787.w;
  float _5798 = _5789.x;
  float _5799 = _5789.y;
  float _5800 = _5789.z;
  float _5801 = _5789.w;
  float4 _5802 = CompositeConstruct({_5790, _5791, _5792, _5793});
  float4 _5803 = CompositeConstruct({_5794, _5795, _5796, _5797});
  float4 _5804 = CompositeConstruct({_5798, _5799, _5800, _5801});
  float4x3 _5805 = CompositeConstruct({_5802, _5803, _5804});
  *coefficients = _5805;
  float* _5806 = &parameters@3[0].w;
  float _5807 = *_5806;
  bool _5808 = _5807 > 0.5000;
  
  if(_5808) {
    float* _5811 = &fades.z;
    float _5812 = *_5811;
    bool _5813 = _5812 < 1.0000;
  }

  bool _5814 = Phi(_5808, _5813);
  
  if(_5814) {
    float* _5818 = &fades.x;
    float _5819 = *_5818;
    float _5820 = 1.0000 - _5819;
    float* _5821 = &fades.x;
    float _5822 = *_5821;
    float* _5823 = &fades.y;
    float _5824 = *_5823;
    float _5825 = 1.0000 - _5824;
    float _5826 = _5822 * _5825;
    float* _5827 = &fades.y;
    float _5828 = *_5827;
    float* _5829 = &fades.z;
    float _5830 = *_5829;
    float _5831 = 1.0000 - _5830;
    float _5832 = _5828 * _5831;
    float3 _5833 = CompositeConstruct({_5820, _5826, _5832});
    *weights@3 = _5833;
    *i@4 = 0;

    while(true) {
      int _5840 = *i@4;
      bool _5841 = _5840 < 3;
      if(!_5841) break;
      int _5845 = *i@4;
      float3* _5846 = &samples[_5845].amplitude;
      *_5846 = {0.0000, 0.0000, 0.0000};
      int _5847 = *i@4;
      int _5848 = *i@4;
      int _5849 = *i@4;
      float4* _5850 = &samples[_5849].blue;
      *_5850 = {0.0000, 0.0000, 0.0000, 0.0000};
      float4* _5851 = &samples[_5848].green;
      *_5851 = {0.0000, 0.0000, 0.0000, 0.0000};
      float4* _5852 = &samples[_5847].red;
      *_5852 = {0.0000, 0.0000, 0.0000, 0.0000};
      int _5853 = *i@4;
      int _5854 = _5853 + 1;
      *i@4 = _5854;
    }

    float* _5855 = &weights@3.x;
    float _5856 = *_5855;
    bool _5857 = _5856 > 0.0000;
    
    if(_5857) {
      SampledImage<float, 3D>* _5860 = &textures[0];
      SampledImage<float, 3D>* _5861 = &textures[1];
      float4* _5863 = &parameters@3[0];
      float4 _5864 = *_5863;
      float3 _5865 = _5864.xyz;
      *param@560 = _5865;
      float3 _5867 = *position@4;
      *param@561 = _5867;
      float* _5869 = &parameters@3[7].w;
      float _5870 = *_5869;
      *param@562 = _5870;
      IrradianceClipmapLayerSample _5871 = sampleIrradianceClipmapLayer(_5860, _5861, param@560, param@561, param@562);
      IrradianceClipmapLayerSample* _5872 = &samples[0];
      *_5872 = _5871;
    }

    float* _5873 = &weights@3.y;
    float _5874 = *_5873;
    bool _5875 = _5874 > 0.0000;
    
    if(_5875) {
      SampledImage<float, 3D>* _5879 = &textures[2];
      SampledImage<float, 3D>* _5880 = &textures[3];
      float4* _5882 = &parameters@3[0];
      float4 _5883 = *_5882;
      float3 _5884 = _5883.xyz;
      *param@563 = _5884;
      float3 _5886 = *position@4;
      *param@564 = _5886;
      float* _5888 = &parameters@3[9].w;
      float _5889 = *_5888;
      *param@565 = _5889;
      IrradianceClipmapLayerSample _5890 = sampleIrradianceClipmapLayer(_5879, _5880, param@563, param@564, param@565);
      IrradianceClipmapLayerSample* _5891 = &samples[1];
      *_5891 = _5890;
    }

    float* _5892 = &weights@3.z;
    float _5893 = *_5892;
    bool _5894 = _5893 > 0.0000;
    
    if(_5894) {
      SampledImage<float, 3D>* _5898 = &textures[4];
      SampledImage<float, 3D>* _5899 = &textures[5];
      float4* _5901 = &parameters@3[0];
      float4 _5902 = *_5901;
      float3 _5903 = _5902.xyz;
      *param@566 = _5903;
      float3 _5905 = *position@4;
      *param@567 = _5905;
      float* _5907 = &parameters@3[11].w;
      float _5908 = *_5907;
      *param@568 = _5908;
      IrradianceClipmapLayerSample _5909 = sampleIrradianceClipmapLayer(_5898, _5899, param@566, param@567, param@568);
      IrradianceClipmapLayerSample* _5910 = &samples[2];
      *_5910 = _5909;
    }

    float* _5912 = &fades.z;
    float _5913 = *_5912;
    *alpha@7 = _5913;
    *i@5 = 0;

    while(true) {
      int _5920 = *i@5;
      bool _5921 = _5920 < 3;
      if(!_5921) break;
      int _5922 = *i@5;
      float* _5923 = &weights@3[_5922];
      float _5924 = *_5923;
      int _5925 = *i@5;
      float* _5926 = &samples[_5925].red.w;
      float _5927 = *_5926;
      float _5928 = _5924 * _5927;
      float _5929 = *alpha@7;
      float _5930 = _5929 + _5928;
      *alpha@7 = _5930;
      int _5931 = *i@5;
      int _5932 = *i@5;
      float* _5933 = &samples[_5932].red.w;
      float _5934 = *_5933;
      int _5935 = *i@5;
      float* _5936 = &samples[_5935].green.w;
      float _5937 = *_5936;
      int _5938 = *i@5;
      float* _5939 = &samples[_5938].blue.w;
      float _5940 = *_5939;
      float3 _5941 = CompositeConstruct({_5934, _5937, _5940});
      float3* _5942 = &result@3.alpha[_5931];
      *_5942 = _5941;
      int _5943 = *i@5;
      int _5944 = _5943 + 1;
      *i@5 = _5944;
    }

    float _5946 = *alpha@7;
    float _5947 = 2.0000 * _5946;
    float _5948 = _5947 - 1.0000;
    float _5949 = GLSL.std.450::FClamp(_5948, 0.0000, 1.0000);
    *remapped = _5949;
    float _5951 = *remapped;
    float* _5952 = &fades.z;
    float _5953 = *_5952;
    float _5954 = _5951 - _5953;
    *u@3 = _5954;
    float _5956 = *remapped;
    float* _5957 = &fades.z;
    float _5958 = *_5957;
    float _5959 = _5956 + _5958;
    float _5960 = 0.5000 * _5959;
    *v@3 = _5960;
    *c = 0;

    while(true) {
      int _5967 = *c;
      bool _5968 = _5967 < 3;
      if(!_5968) break;
      *color@9 = {0.0000, 0.0000, 0.0000, 0.0000};
      *i@6 = 0;

      while(true) {
        int _5976 = *i@6;
        bool _5977 = _5976 < 3;
        if(!_5977) break;
        int _5979 = *c;
        bool _5980 = _5979 == 0;
        
        if(_5980) {
          int _5984 = *i@6;
          float4* _5985 = &samples[_5984].red;
          float4 _5986 = *_5985;
          *_5981 = _5986;
        } else {
          int _5988 = *c;
          bool _5989 = _5988 == 1;
          
          if(_5989) {
            int _5993 = *i@6;
            float4* _5994 = &samples[_5993].green;
            float4 _5995 = *_5994;
            *_5990 = _5995;
          } else {
            int _5997 = *i@6;
            float4* _5998 = &samples[_5997].blue;
            float4 _5999 = *_5998;
            *_5990 = _5999;
          }

          float4 _6000 = *_5990;
          *_5981 = _6000;
        }

        float4 _6001 = *_5981;
        *direction@5 = _6001;
        int _6002 = *i@6;
        float* _6003 = &weights@3[_6002];
        float _6004 = *_6003;
        int _6005 = *i@6;
        int _6006 = *c;
        float* _6007 = &samples[_6005].amplitude[_6006];
        float _6008 = *_6007;
        float _6009 = _6004 * _6008;
        float4 _6010 = *direction@5;
        float3 _6011 = _6010.xyz;
        float3 _6012 = _6011 * 4.0000;
        float3 _6013 = CompositeConstruct({2.0000, 2.0000, 2.0000});
        float3 _6014 = _6012 - _6013;
        float _6015 = _6014.x;
        float _6016 = _6014.y;
        float _6017 = _6014.z;
        float4 _6018 = CompositeConstruct({_6015, _6016, _6017, 1.0000});
        float4 _6019 = _6018 * _6009;
        float4 _6020 = *color@9;
        float4 _6021 = _6020 + _6019;
        *color@9 = _6021;
        int _6022 = *i@6;
        int _6023 = _6022 + 1;
        *i@6 = _6023;
      }

      int _6025 = *c;
      int _6026 = 4 + _6025;
      float4* _6027 = &parameters@3[_6026];
      float4 _6028 = *_6027;
      *defaults@2 = _6028;
      float _6029 = *v@3;
      float4 _6030 = *defaults@2;
      float4 _6031 = _6030 * _6029;
      float4 _6032 = *color@9;
      float4 _6033 = _6032 + _6031;
      *color@9 = _6033;
      float _6034 = *u@3;
      float _6035 = 0.5000 * _6034;
      float* _6036 = &defaults@2.w;
      float _6037 = *_6036;
      float _6038 = _6035 * _6037;
      float* _6039 = &color@9.y;
      float _6040 = *_6039;
      float _6041 = _6040 + _6038;
      float* _6042 = &color@9.y;
      *_6042 = _6041;
      float _6044 = *u@3;
      float _6045 = 0.3750 * _6044;
      float* _6046 = &defaults@2.y;
      float _6047 = *_6046;
      float _6048 = _6045 * _6047;
      float* _6049 = &color@9.w;
      float _6050 = *_6049;
      float _6051 = _6050 + _6048;
      float* _6052 = &color@9.w;
      *_6052 = _6051;
      int _6053 = *c;
      float4 _6054 = *color@9;
      float4* _6055 = &coefficients[_6053];
      *_6055 = _6054;
      int _6056 = *c;
      int _6057 = _6056 + 1;
      *c = _6057;
    }

  }

  *c@2 = 0;

  while(true) {
    int _6064 = *c@2;
    bool _6065 = _6064 < 3;
    if(!_6065) break;
    int _6066 = *c@2;
    float4* _6067 = &parameters@3[1];
    float4 _6068 = *_6067;
    float3 _6069 = _6068.xyz;
    int _6070 = *c@2;
    float* _6071 = &coefficients[_6070].x;
    float _6072 = *_6071;
    float3 _6073 = _6069 * _6072;
    float4* _6074 = &parameters@3[2];
    float4 _6075 = *_6074;
    float3 _6076 = _6075.xyz;
    int _6077 = *c@2;
    float* _6078 = &coefficients[_6077].y;
    float _6079 = *_6078;
    float3 _6080 = _6076 * _6079;
    float3 _6081 = _6073 + _6080;
    float4* _6082 = &parameters@3[3];
    float4 _6083 = *_6082;
    float3 _6084 = _6083.xyz;
    int _6085 = *c@2;
    float* _6086 = &coefficients[_6085].z;
    float _6087 = *_6086;
    float3 _6088 = _6084 * _6087;
    float3 _6089 = _6081 + _6088;
    int _6090 = *c@2;
    float* _6091 = &coefficients[_6090].w;
    float _6092 = *_6091;
    float _6093 = _6089.x;
    float _6094 = _6089.y;
    float _6095 = _6089.z;
    float4 _6096 = CompositeConstruct({_6093, _6094, _6095, _6092});
    float4* _6097 = &result@3.coefficients[_6066];
    *_6097 = _6096;
    int _6098 = *c@2;
    int _6099 = _6098 + 1;
    *c@2 = _6099;
  }

  IrradianceClipmapResult _6100 = *result@3;
  return _6100;
}

uint2 azureClusterLightRange(uint* cluster, uint* receiverRange@2) {
  uint _6107 = *cluster;
  uint _6108 = _6107 * 4;
  uint _6109 = *receiverRange@2;
  uint _6110 = _6108 + _6109;
  uint2* _6112 = &clusterHeaderData.clusters[_6110];
  uint2 _6113 = *_6112;
  return _6113;
}

bool objectShadowLoadRecord(uint* depthPairCount, uint* index, ObjectShadowRecord* record) {
  uint* start;
  uint4* header;
  uint* param@569;
  uint* param@570;
  uint* i@7;
  float4[7]* rows;
  uint* param@571;
  uint* param@572;
  uint _6116 = *index;
  bool _6117 = _6116 == 0;
  
  if(_6117) {
    return false;
  }

  uint _6122 = *depthPairCount;
  uint _6123 = _6122 + 1;
  uint _6125 = _6123 & 4294967294;
  *start = _6125;
  uint _6130 = *start;
  *param@569 = _6130;
  float2 _6131 = objectShadowRecordPair(param@569);
  uint _6132 = *start;
  uint _6133 = _6132 + 1;
  *param@570 = _6133;
  float2 _6135 = objectShadowRecordPair(param@570);
  float _6136 = _6131.x;
  float _6137 = _6131.y;
  float _6138 = _6135.x;
  float _6139 = _6135.y;
  float4 _6140 = CompositeConstruct({_6136, _6137, _6138, _6139});
  uint4 _6141 = Bitcast(_6140);
  *header = _6141;
  uint* _6142 = &header.x;
  uint _6143 = *_6142;
  bool _6144 = _6143 != 2;
  bool _6145 = !_6144;
  
  if(_6145) {
    uint* _6148 = &header.y;
    uint _6149 = *_6148;
    uint* _6150 = &header.z;
    uint _6151 = *_6150;
    bool _6152 = _6149 > _6151;
  }

  bool _6153 = Phi(_6144, _6152);
  bool _6154 = !_6153;
  
  if(_6154) {
    uint* _6157 = &header.z;
    uint _6158 = *_6157;
    bool _6159 = _6158 > 8;
  }

  bool _6160 = Phi(_6153, _6159);
  bool _6161 = !_6160;
  
  if(_6161) {
    uint _6164 = *index;
    uint* _6165 = &header.y;
    uint _6166 = *_6165;
    bool _6167 = _6164 > _6166;
  }

  bool _6168 = Phi(_6160, _6167);
  
  if(_6168) {
    return false;
  }

  uint _6172 = *index;
  uint _6173 = _6172 - 1;
  uint _6175 = _6173 * 14;
  uint _6176 = 2 + _6175;
  uint _6177 = *start;
  uint _6178 = _6177 + _6176;
  *start = _6178;
  *i@7 = 0;

  while(true) {
    uint _6185 = *i@7;
    bool _6186 = _6185 < 7;
    if(!_6186) break;
    uint _6190 = *i@7;
    uint _6191 = *start;
    uint _6192 = *i@7;
    uint _6193 = _6192 * 2;
    uint _6194 = _6191 + _6193;
    *param@571 = _6194;
    float2 _6196 = objectShadowRecordPair(param@571);
    uint _6197 = *start;
    uint _6198 = *i@7;
    uint _6199 = _6198 * 2;
    uint _6200 = _6197 + _6199;
    uint _6201 = _6200 + 1;
    *param@572 = _6201;
    float2 _6203 = objectShadowRecordPair(param@572);
    float _6204 = _6196.x;
    float _6205 = _6196.y;
    float _6206 = _6203.x;
    float _6207 = _6203.y;
    float4 _6208 = CompositeConstruct({_6204, _6205, _6206, _6207});
    float4* _6209 = &rows[_6190];
    *_6209 = _6208;
    uint _6210 = *i@7;
    uint _6211 = _6210 + 1;
    *i@7 = _6211;
  }

  float4* _6212 = &rows[0];
  float4 _6213 = *_6212;
  float4* _6214 = &rows[1];
  float4 _6215 = *_6214;
  float4* _6216 = &rows[2];
  float4 _6217 = *_6216;
  float4* _6218 = &rows[3];
  float4 _6219 = *_6218;
  float _6220 = _6213.x;
  float _6221 = _6213.y;
  float _6222 = _6213.z;
  float _6223 = _6213.w;
  float _6224 = _6215.x;
  float _6225 = _6215.y;
  float _6226 = _6215.z;
  float _6227 = _6215.w;
  float _6228 = _6217.x;
  float _6229 = _6217.y;
  float _6230 = _6217.z;
  float _6231 = _6217.w;
  float _6232 = _6219.x;
  float _6233 = _6219.y;
  float _6234 = _6219.z;
  float _6235 = _6219.w;
  float4 _6236 = CompositeConstruct({_6220, _6221, _6222, _6223});
  float4 _6237 = CompositeConstruct({_6224, _6225, _6226, _6227});
  float4 _6238 = CompositeConstruct({_6228, _6229, _6230, _6231});
  float4 _6239 = CompositeConstruct({_6232, _6233, _6234, _6235});
  float4x4 _6240 = CompositeConstruct({_6236, _6237, _6238, _6239});
  float4x4* _6241 = &record.worldToUnit;
  *_6241 = _6240;
  float4* _6242 = &rows[4];
  float4 _6243 = *_6242;
  float4* _6244 = &record.biasAndFilter;
  *_6244 = _6243;
  float4* _6245 = &rows[5];
  float4 _6246 = *_6245;
  float4* _6247 = &record.atlasRect;
  *_6247 = _6246;
  float4* _6248 = &rows[6];
  float4 _6249 = *_6248;
  float4* _6250 = &record.receiverSampling;
  *_6250 = _6249;
  return true;
}

float3 objectShadowReceiverPosition(float3* position@5, float2* offset@9, float4x4* worldToClip@4, float3* cameraRight@2, float3* cameraUp@2, float2* extent@8) {
  float* w@2;
  float2* scale@3;
  float2* shift@2;
  float4x4 _6254 = *worldToClip@4;
  float3 _6255 = *position@5;
  float _6256 = _6255.x;
  float _6257 = _6255.y;
  float _6258 = _6255.z;
  float4 _6259 = CompositeConstruct({_6256, _6257, _6258, 1.0000});
  float4 _6260 = _6254 * _6259;
  float _6261 = _6260.w;
  *w@2 = _6261;
  float4x4 _6263 = *worldToClip@4;
  float3 _6264 = *cameraRight@2;
  float _6265 = _6264.x;
  float _6266 = _6264.y;
  float _6267 = _6264.z;
  float4 _6268 = CompositeConstruct({_6265, _6266, _6267, 0.0000});
  float4 _6269 = _6263 * _6268;
  float _6270 = _6269.x;
  float4x4 _6271 = *worldToClip@4;
  float3 _6272 = *cameraUp@2;
  float _6273 = _6272.x;
  float _6274 = _6272.y;
  float _6275 = _6272.z;
  float4 _6276 = CompositeConstruct({_6273, _6274, _6275, 0.0000});
  float4 _6277 = _6271 * _6276;
  float _6278 = _6277.y;
  float2 _6279 = CompositeConstruct({_6270, _6278});
  float2 _6280 = *extent@8;
  float2 _6281 = _6279 * _6280;
  *scale@3 = _6281;
  float _6282 = *w@2;
  bool _6283 = _6282 <= 0.0000;
  bool _6284 = !_6283;
  
  if(_6284) {
    float2 _6287 = *scale@3;
    float2 _6288 = GLSL.std.450::FAbs(_6287);
    bool _6290 = _6288 < {0.0000, 0.0000};
    bool _6291 = Any(_6290);
  }

  bool _6292 = Phi(_6283, _6291);
  
  if(_6292) {
    float3 _6295 = *position@5;
    return _6295;
  }

  float _6298 = *w@2;
  float _6299 = 2.0000 * _6298;
  float2 _6300 = *offset@9;
  float2 _6301 = _6300 * _6299;
  float2 _6302 = *scale@3;
  float2 _6303 = _6301 / _6302;
  *shift@2 = _6303;
  float3 _6304 = *position@5;
  float3 _6305 = *cameraRight@2;
  float* _6306 = &shift@2.x;
  float _6307 = *_6306;
  float3 _6308 = _6305 * _6307;
  float3 _6309 = _6304 + _6308;
  float3 _6310 = *cameraUp@2;
  float* _6311 = &shift@2.y;
  float _6312 = *_6311;
  float3 _6313 = _6310 * _6312;
  float3 _6314 = _6309 + _6313;
  return _6314;
}

float3 objectShadowReceiver(ObjectShadowRecord* record@2, float3* position@6, float3* normal@18) {
  float3* light@7;
  float* weight@9;
  float3* biased;
  float3* projected@2;
  float* _6318 = &record@2.worldToUnit[0].z;
  float _6319 = *_6318;
  float* _6320 = &record@2.worldToUnit[1].z;
  float _6321 = *_6320;
  float* _6322 = &record@2.worldToUnit[2].z;
  float _6323 = *_6322;
  float3 _6324 = CompositeConstruct({_6319, _6321, _6323});
  float3 _6325 = GLSL.std.450::Normalize(_6324);
  *light@7 = _6325;
  float3 _6327 = *normal@18;
  float3 _6328 = *light@7;
  float _6329 = Dot(_6327, _6328);
  float _6330 = GLSL.std.450::FClamp(_6329, 0.0000, 0.9000);
  float _6331 = 1.0000 - _6330;
  *weight@9 = _6331;
  float3 _6333 = *position@6;
  float3 _6334 = *light@7;
  float* _6335 = &record@2.biasAndFilter.y;
  float _6336 = *_6335;
  float3 _6337 = _6334 * _6336;
  float _6338 = *weight@9;
  float3 _6339 = _6337 * _6338;
  float3 _6340 = _6333 - _6339;
  float3 _6341 = *normal@18;
  float* _6342 = &record@2.biasAndFilter.x;
  float _6343 = *_6342;
  float3 _6344 = _6341 * _6343;
  float _6345 = *weight@9;
  float3 _6346 = _6344 * _6345;
  float3 _6347 = _6340 + _6346;
  *biased = _6347;
  float4x4* _6349 = &record@2.worldToUnit;
  float4x4 _6350 = *_6349;
  float3 _6351 = *biased;
  float _6352 = _6351.x;
  float _6353 = _6351.y;
  float _6354 = _6351.z;
  float4 _6355 = CompositeConstruct({_6352, _6353, _6354, 1.0000});
  float4 _6356 = _6350 * _6355;
  float3 _6357 = _6356.xyz;
  *projected@2 = _6357;
  float3 _6358 = *projected@2;
  float2 _6359 = _6358.xy;
  float* _6360 = &projected@2.z;
  float _6361 = *_6360;
  float _6362 = 1.0000 - _6361;
  float _6363 = GLSL.std.450::FMax(_6362, 0.0100);
  float _6364 = _6359.x;
  float _6365 = _6359.y;
  float3 _6366 = CompositeConstruct({_6364, _6365, _6363});
  return _6366;
}

float objectShadowDistribution(float* count@2, float* positiveDelta, float* receiver) {
  float* x@5;
  float* q@5;
  float* cube;
  float* ratio@2;
  float _6369 = *count@2;
  bool _6370 = _6369 == 0.0000;
  
  if(_6370) {
    return 1.0000;
  }

  float _6375 = *count@2;
  float _6377 = _6375 / 64.0000;
  float _6378 = 2.0000 * _6377;
  float _6379 = _6378 - 1.0000;
  *x@5 = _6379;
  float _6381 = *x@5;
  float _6382 = GLSL.std.450::FAbs(_6381);
  float _6383 = 1.0000 - _6382;
  *q@5 = _6383;
  float _6385 = *q@5;
  float _6386 = *q@5;
  float _6387 = _6385 * _6386;
  float _6388 = *q@5;
  float _6389 = _6387 * _6388;
  *cube = _6389;
  float _6391 = *positiveDelta;
  float _6392 = *count@2;
  float _6393 = _6391 / _6392;
  float _6394 = *receiver;
  float _6395 = _6393 / _6394;
  float _6396 = GLSL.std.450::FClamp(_6395, 0.0000, 1.0000);
  *ratio@2 = _6396;
  float _6397 = *x@5;
  float _6398 = GLSL.std.450::FSign(_6397);
  float _6399 = 0.5000 * _6398;
  float _6400 = *cube;
  float _6401 = *ratio@2;
  float _6402 = *q@5;
  float _6403 = *cube;
  float _6404 = _6402 - _6403;
  float _6405 = _6401 * _6404;
  float _6406 = _6400 + _6405;
  float _6407 = 1.0000 - _6406;
  float _6408 = _6399 * _6407;
  float _6409 = 0.5000 - _6408;
  return _6409;
}

float objectShadowUnorm8(float* visibility@11) {
  float _6412 = *visibility@11;
  float _6413 = GLSL.std.450::FClamp(_6412, 0.0000, 1.0000);
  float _6415 = _6413 * 255.0000;
  float _6416 = _6415 + 0.5000;
  float _6417 = GLSL.std.450::Floor(_6416);
  float _6418 = _6417 / 255.0000;
  return _6418;
}

float objectShadowPageTexel(Image<float, 2D>* depth@8, sampler* sharedSampler, int2* pixel@10, int2* lo@2, int2* hi@2) {
  int2 _6421 = *pixel@10;
  int2 _6422 = *lo@2;
  bool _6423 = _6421 < _6422;
  bool _6424 = Any(_6423);
  bool _6425 = !_6424;
  
  if(_6425) {
    int2 _6428 = *pixel@10;
    int2 _6429 = *hi@2;
    bool _6430 = _6428 >= _6429;
    bool _6431 = Any(_6430);
  }

  bool _6432 = Phi(_6424, _6431);
  
  if(_6432) {
    return 1.0000;
  }

  Image<float, 2D> _6436 = *depth@8;
  sampler _6437 = *sharedSampler;
  SampledImage<float, 2D> _6438 = SampledImage(_6436, _6437);
  int2 _6439 = *pixel@10;
  Image<float, 2D> _6440 = Image(_6438);
  float4 _6441 = ImageFetch(_6440, _6439, Lod(0));
  float _6442 = _6441.x;
  return _6442;
}

float4 objectShadowGather(Image<float, 2D>* depth@9, sampler* sharedSampler@2, float2* uv@21, int2* lo@3, int2* hi@3) {
  float2* extent@9;
  float2* coordinate@3;
  int2* base@10;
  int2* param@573;
  int2* param@574;
  int2* param@575;
  int2* param@576;
  int2* param@577;
  int2* param@578;
  int2* param@579;
  int2* param@580;
  int2* param@581;
  int2* param@582;
  int2* param@583;
  int2* param@584;
  Image<float, 2D> _6446 = *depth@9;
  sampler _6447 = *sharedSampler@2;
  SampledImage<float, 2D> _6448 = SampledImage(_6446, _6447);
  Image<float, 2D> _6449 = Image(_6448);
  int2 _6450 = ImageQuerySizeLod(_6449, 0);
  float2 _6451 = ConvertSToF(_6450);
  *extent@9 = _6451;
  float2 _6453 = *uv@21;
  float2 _6454 = *extent@9;
  float2 _6455 = _6453 * _6454;
  float2 _6456 = CompositeConstruct({0.5000, 0.5000});
  float2 _6457 = _6455 - _6456;
  *coordinate@3 = _6457;
  float2 _6459 = *coordinate@3;
  float2 _6460 = _6459 * 256.0000;
  float2 _6461 = GLSL.std.450::RoundEven(_6460);
  float2 _6462 = CompositeConstruct({256.0000, 256.0000});
  float2 _6463 = _6461 / _6462;
  float2 _6464 = GLSL.std.450::Floor(_6463);
  int2 _6465 = ConvertFToS(_6464);
  *base@10 = _6465;
  int2 _6466 = *base@10;
  int2 _6467 = *lo@3;
  bool _6468 = _6466 >= _6467;
  bool _6469 = All(_6468);
  
  if(_6469) {
    int2 _6472 = *base@10;
    int2 _6473 = CompositeConstruct({1, 1});
    int2 _6474 = _6472 + _6473;
    int2 _6475 = *hi@3;
    bool _6476 = _6474 < _6475;
    bool _6477 = All(_6476);
  }

  bool _6478 = Phi(_6469, _6477);
  
  if(_6478) {
    Image<float, 2D> _6481 = *depth@9;
    sampler _6482 = *sharedSampler@2;
    SampledImage<float, 2D> _6483 = SampledImage(_6481, _6482);
    int2 _6484 = *base@10;
    float2 _6485 = ConvertSToF(_6484);
    float2 _6486 = CompositeConstruct({1.0000, 1.0000});
    float2 _6487 = _6485 + _6486;
    float2 _6488 = *extent@9;
    float2 _6489 = _6487 / _6488;
    float4 _6490 = ImageGather(_6483, _6489, 0);
    return _6490;
  }

  int2 _6492 = *base@10;
  int2 _6493 = _6492 + {0, 1};
  *param@573 = _6493;
  int2 _6496 = *lo@3;
  *param@574 = _6496;
  int2 _6498 = *hi@3;
  *param@575 = _6498;
  float _6499 = objectShadowPageTexel(depth@9, sharedSampler@2, param@573, param@574, param@575);
  int2 _6500 = *base@10;
  int2 _6501 = _6500 + {1, 1};
  *param@576 = _6501;
  int2 _6504 = *lo@3;
  *param@577 = _6504;
  int2 _6506 = *hi@3;
  *param@578 = _6506;
  float _6507 = objectShadowPageTexel(depth@9, sharedSampler@2, param@576, param@577, param@578);
  int2 _6508 = *base@10;
  int2 _6509 = _6508 + {1, 0};
  *param@579 = _6509;
  int2 _6512 = *lo@3;
  *param@580 = _6512;
  int2 _6514 = *hi@3;
  *param@581 = _6514;
  float _6515 = objectShadowPageTexel(depth@9, sharedSampler@2, param@579, param@580, param@581);
  int2 _6517 = *base@10;
  *param@582 = _6517;
  int2 _6519 = *lo@3;
  *param@583 = _6519;
  int2 _6521 = *hi@3;
  *param@584 = _6521;
  float _6522 = objectShadowPageTexel(depth@9, sharedSampler@2, param@582, param@583, param@584);
  float4 _6523 = CompositeConstruct({_6499, _6507, _6515, _6522});
  return _6523;
}

float2 objectShadowFilter(Image<float, 2D>* depth@10, sampler* sharedSampler@3, float2* uv@22, float* receiver@2, int2* gridPixel, float4* rect, float2* radius@5) {
  int2* extent@10;
  int2* lo@4;
  int2* hi@4;
  uint* phase@2;
  float2* rotation;
  uint4[16]* indexable@2;
  float* count@3;
  float* sumDelta;
  int* i@8;
  float2* offset@10;
  uint4[16]* indexable@3;
  float2* rotated;
  float2* tapUv;
  float4* reversed;
  float2* param@585;
  int2* param@586;
  int2* param@587;
  float* param@588;
  float* param@589;
  float* param@590;
  Image<float, 2D> _6527 = *depth@10;
  sampler _6528 = *sharedSampler@3;
  SampledImage<float, 2D> _6529 = SampledImage(_6527, _6528);
  Image<float, 2D> _6530 = Image(_6529);
  int2 _6531 = ImageQuerySizeLod(_6530, 0);
  *extent@10 = _6531;
  float4 _6533 = *rect;
  float2 _6534 = _6533.xy;
  int2 _6535 = *extent@10;
  float2 _6536 = ConvertSToF(_6535);
  float2 _6537 = _6534 * _6536;
  float2 _6538 = GLSL.std.450::Round(_6537);
  int2 _6539 = ConvertFToS(_6538);
  *lo@4 = _6539;
  float4 _6541 = *rect;
  float2 _6542 = _6541.xy;
  float4 _6543 = *rect;
  float2 _6544 = _6543.zw;
  float2 _6545 = _6542 + _6544;
  int2 _6546 = *extent@10;
  float2 _6547 = ConvertSToF(_6546);
  float2 _6548 = _6545 * _6547;
  float2 _6549 = GLSL.std.450::Round(_6548);
  int2 _6550 = ConvertFToS(_6549);
  *hi@4 = _6550;
  int* _6552 = &gridPixel.x;
  int _6553 = *_6552;
  int _6554 = _6553 & 3;
  int _6555 = _6554 << 2;
  int* _6556 = &gridPixel.y;
  int _6557 = *_6556;
  int _6558 = _6557 & 3;
  int _6559 = _6555 | _6558;
  uint _6560 = Bitcast(_6559);
  *phase@2 = _6560;
  uint _6644 = *phase@2;
  *indexable@2 = _6643;
  uint4* _6647 = &indexable@2[_6644];
  uint4 _6648 = *_6647;
  float4 _6649 = Bitcast(_6648);
  float2 _6650 = _6649.xy;
  *rotation = _6650;
  *count@3 = 0.0000;
  *sumDelta = 0.0000;
  *i@8 = 0;

  while(true) {
    int _6659 = *i@8;
    bool _6661 = _6659 < 16;
    if(!_6661) break;
    int _6663 = *i@8;
    *indexable@3 = _6643;
    uint4* _6665 = &indexable@3[_6663];
    uint4 _6666 = *_6665;
    float4 _6667 = Bitcast(_6666);
    float2 _6668 = _6667.zw;
    *offset@10 = _6668;
    float* _6670 = &offset@10.x;
    float _6671 = *_6670;
    float* _6672 = &rotation.x;
    float _6673 = *_6672;
    float _6674 = _6671 * _6673;
    float* _6675 = &offset@10.y;
    float _6676 = *_6675;
    float* _6677 = &rotation.y;
    float _6678 = *_6677;
    float _6679 = _6676 * _6678;
    float _6680 = _6674 - _6679;
    float* _6681 = &offset@10.y;
    float _6682 = *_6681;
    float* _6683 = &rotation.x;
    float _6684 = *_6683;
    float _6685 = _6682 * _6684;
    float* _6686 = &offset@10.x;
    float _6687 = *_6686;
    float* _6688 = &rotation.y;
    float _6689 = *_6688;
    float _6690 = _6687 * _6689;
    float _6691 = _6685 + _6690;
    float2 _6692 = CompositeConstruct({_6680, _6691});
    *rotated = _6692;
    float2 _6694 = *uv@22;
    float2 _6695 = *rotated;
    float2 _6696 = *radius@5;
    int2 _6697 = *extent@10;
    float2 _6698 = ConvertSToF(_6697);
    float2 _6699 = _6696 / _6698;
    float2 _6700 = _6695 * _6699;
    float2 _6701 = _6694 + _6700;
    *tapUv = _6701;
    float2 _6704 = *tapUv;
    *param@585 = _6704;
    int2 _6706 = *lo@4;
    *param@586 = _6706;
    int2 _6708 = *hi@4;
    *param@587 = _6708;
    float4 _6709 = objectShadowGather(depth@10, sharedSampler@3, param@585, param@586, param@587);
    float4 _6710 = CompositeConstruct({1.0000, 1.0000, 1.0000, 1.0000});
    float4 _6711 = _6710 - _6709;
    *reversed = _6711;
    float _6712 = *receiver@2;
    float4 _6713 = CompositeConstruct({_6712, _6712, _6712, _6712});
    float4 _6714 = *reversed;
    float4 _6715 = GLSL.std.450::Step(_6713, _6714);
    float _6716 = Dot(_6715, {1.0000, 1.0000, 1.0000, 1.0000});
    float _6717 = *count@3;
    float _6718 = _6717 + _6716;
    *count@3 = _6718;
    float4 _6719 = *reversed;
    float _6720 = *receiver@2;
    float4 _6721 = CompositeConstruct({_6720, _6720, _6720, _6720});
    float4 _6722 = _6719 - _6721;
    float4 _6723 = GLSL.std.450::FMax(_6722, {0.0000, 0.0000, 0.0000, 0.0000});
    float _6724 = Dot(_6723, {1.0000, 1.0000, 1.0000, 1.0000});
    float _6725 = *sumDelta;
    float _6726 = _6725 + _6724;
    *sumDelta = _6726;
    int _6727 = *i@8;
    int _6728 = _6727 + 1;
    *i@8 = _6728;
  }

  float _6730 = *count@3;
  *param@588 = _6730;
  float _6732 = *sumDelta;
  *param@589 = _6732;
  float _6734 = *receiver@2;
  *param@590 = _6734;
  float _6735 = objectShadowDistribution(param@588, param@589, param@590);
  float _6736 = *count@3;
  float2 _6737 = CompositeConstruct({_6735, _6736});
  return _6737;
}

float objectShadowVisibility(Image<float, 2D>* depth@11, sampler* sharedSampler@4, ObjectShadowRecord* record@3, float3* position@7, float3* normal@19, int2* gridPixel@2) {
  float3* receiver@3;
  ObjectShadowRecord* param@591;
  float3* param@592;
  float3* param@593;
  float2* uv@23;
  float2* param@594;
  float* param@595;
  int2* param@596;
  float4* param@597;
  float2* param@598;
  float* param@599;
  ObjectShadowRecord _6742 = *record@3;
  *param@591 = _6742;
  float3 _6744 = *position@7;
  *param@592 = _6744;
  float3 _6746 = *normal@19;
  *param@593 = _6746;
  float3 _6747 = objectShadowReceiver(param@591, param@592, param@593);
  *receiver@3 = _6747;
  float3 _6748 = *receiver@3;
  float2 _6749 = _6748.xy;
  bool _6750 = _6749 <= {0.0000, 0.0000};
  bool _6751 = Any(_6750);
  bool _6752 = !_6751;
  
  if(_6752) {
    float3 _6755 = *receiver@3;
    float2 _6756 = _6755.xy;
    bool _6757 = _6756 >= {1.0000, 1.0000};
    bool _6758 = Any(_6757);
  }

  bool _6759 = Phi(_6751, _6758);
  bool _6760 = !_6759;
  
  if(_6760) {
    float* _6763 = &receiver@3.z;
    float _6764 = *_6763;
    bool _6765 = _6764 >= 1.0000;
  }

  bool _6766 = Phi(_6759, _6765);
  
  if(_6766) {
    return 1.0000;
  }

  float4* _6771 = &record@3.atlasRect;
  float4 _6772 = *_6771;
  float2 _6773 = _6772.xy;
  float3 _6774 = *receiver@3;
  float2 _6775 = _6774.xy;
  float4* _6776 = &record@3.atlasRect;
  float4 _6777 = *_6776;
  float2 _6778 = _6777.zw;
  float2 _6779 = _6775 * _6778;
  float2 _6780 = _6773 + _6779;
  *uv@23 = _6780;
  float2 _6782 = *uv@23;
  *param@594 = _6782;
  float* _6784 = &receiver@3.z;
  float _6785 = *_6784;
  *param@595 = _6785;
  int2 _6787 = *gridPixel@2;
  *param@596 = _6787;
  float4* _6789 = &record@3.atlasRect;
  float4 _6790 = *_6789;
  *param@597 = _6790;
  float4* _6792 = &record@3.biasAndFilter;
  float4 _6793 = *_6792;
  float2 _6794 = _6793.zw;
  *param@598 = _6794;
  float2 _6795 = objectShadowFilter(depth@11, sharedSampler@4, param@594, param@595, param@596, param@597, param@598);
  float _6797 = _6795.x;
  *param@599 = _6797;
  float _6798 = objectShadowUnorm8(param@599);
  return _6798;
}

float2 objectShadowRecordPair(uint* index@2) {
  uint _6805 = *index@2;
  float2* _6807 = &shadowBounds.values[_6805];
  float2 _6808 = *_6807;
  return _6808;
}

float materialObjectVisibility(float3* surfaceNormal) {
  int* _6822;
  int2* extent@11;
  int2* pixel@11;
  int2* extent@12;
  ObjectShadowRecord* record@4;
  uint* param@600;
  uint* param@601;
  ObjectShadowRecord* param@602;
  float3* receiverPosition;
  float3* param@603;
  float2* param@604;
  float4x4* param@605;
  float3* param@606;
  float3* param@607;
  float2* param@608;
  float3* receiverNormal;
  float3* _6950;
  ObjectShadowRecord* param@609;
  float3* param@610;
  float3* param@611;
  int2* param@612;
  uint* _6816 = &camera.referenceControl.w;
  uint _6817 = *_6816;
  bool _6818 = _6817 != 0;
  
  if(_6818) {
    
    if(azureOrdinaryOpaque) {
      *_6822 = 0;
    } else {
      int* _6830 = &material.alphaMode;
      int _6831 = *_6830;
      *_6822 = _6831;
    }

    int _6832 = *_6822;
    bool _6833 = _6832 != 2;
  }

  bool _6834 = Phi(_6818, _6833);
  
  if(_6834) {
    uint _6839 = *instanceObjectShadow;
    bool _6840 = _6839 != 0;
  }

  bool _6841 = Phi(_6834, _6840);
  
  if(_6841) {
    Image<float, 2D> _6846 = *referenceObjectVisibility;
    int2 _6847 = ImageQuerySizeLod(_6846, 0);
    *extent@11 = _6847;
    float4 _6851 = *gl_FragCoord;
    float2 _6852 = _6851.xy;
    int2 _6853 = ConvertFToS(_6852);
    *pixel@11 = _6853;
    int* _6854 = &extent@11.y;
    int _6855 = *_6854;
    int _6856 = _6855 - 1;
    int* _6857 = &pixel@11.y;
    int _6858 = *_6857;
    int _6859 = _6856 - _6858;
    int* _6860 = &pixel@11.y;
    *_6860 = _6859;
    int2 _6861 = *pixel@11;
    bool _6862 = _6861 >= {0, 0};
    bool _6863 = All(_6862);
    
    if(_6863) {
      int2 _6866 = *pixel@11;
      int2 _6867 = *extent@11;
      bool _6868 = _6866 < _6867;
      bool _6869 = All(_6868);
    }

    bool _6870 = Phi(_6863, _6869);
    
    if(_6870) {
      Image<uint, 2D> _6876 = *referenceObjectIds;
      int2 _6877 = *pixel@11;
      uint4 _6878 = ImageFetch(_6876, _6877, Lod(0));
      uint _6879 = _6878.x;
      uint _6880 = *instanceObjectShadow;
      bool _6881 = _6879 == _6880;
    }

    bool _6882 = Phi(_6870, _6881);
    
    if(_6882) {
      Image<float, 2D> _6885 = *referenceObjectVisibility;
      int2 _6886 = *pixel@11;
      float4 _6887 = ImageFetch(_6885, _6886, Lod(0));
      float _6888 = _6887.y;
      return _6888;
    }

  }

  Image<float, 2D> _6892 = *mainShadowDepth;
  sampler _6894 = *sharedDepthSampler;
  SampledImage<float, 2D> _6895 = SampledImage(_6892, _6894);
  Image<float, 2D> _6896 = Image(_6895);
  int2 _6897 = ImageQuerySizeLod(_6896, 0);
  int2 _6898 = CompositeConstruct({8, 8});
  int2 _6899 = _6897 / _6898;
  *extent@12 = _6899;
  int* _6900 = &extent@12.x;
  int _6901 = *_6900;
  int* _6902 = &extent@12.y;
  int _6903 = *_6902;
  int _6904 = _6901 * _6903;
  uint _6905 = Bitcast(_6904);
  *param@600 = _6905;
  uint _6909 = *instanceObjectShadow;
  *param@601 = _6909;
  bool _6911 = objectShadowLoadRecord(param@600, param@601, param@602);
  ObjectShadowRecord _6912 = *param@602;
  *record@4 = _6912;
  bool _6913 = !_6911;
  
  if(_6913) {
    return 1.0000;
  }

  float3 _6924 = *worldPosition;
  *param@603 = _6924;
  float4* _6926 = &record@4.receiverSampling;
  float4 _6927 = *_6926;
  float2 _6928 = _6927.xy;
  *param@604 = _6928;
  float4x4* _6931 = &camera.screenReflectionWorldToClip;
  float4x4 _6932 = *_6931;
  *param@605 = _6932;
  float4* _6934 = &camera.cameraRight;
  float4 _6935 = *_6934;
  float3 _6936 = _6935.xyz;
  *param@606 = _6936;
  float4* _6938 = &camera.cameraUp;
  float4 _6939 = *_6938;
  float3 _6940 = _6939.xyz;
  *param@607 = _6940;
  float4* _6942 = &camera.clusterDepth;
  float4 _6943 = *_6942;
  float2 _6944 = _6943.zw;
  *param@608 = _6944;
  float3 _6945 = objectShadowReceiverPosition(param@603, param@604, param@605, param@606, param@607, param@608);
  *receiverPosition = _6945;
  float* _6947 = &record@4.receiverSampling.z;
  float _6948 = *_6947;
  bool _6949 = _6948 > 0.5000;
  
  if(_6949) {
    float3 _6953 = *surfaceNormal;
    *_6950 = _6953;
  } else {
    float3 _6956 = *worldNormal;
    float3 _6957 = GLSL.std.450::Normalize(_6956);
    *_6950 = _6957;
  }

  float3 _6958 = *_6950;
  *receiverNormal = _6958;
  float* _6961 = &gl_FragCoord.x;
  float _6962 = *_6961;
  int _6963 = ConvertFToS(_6962);
  float* _6964 = &camera.clusterDepth.w;
  float _6965 = *_6964;
  float* _6966 = &gl_FragCoord.y;
  float _6967 = *_6966;
  float _6968 = _6965 - _6967;
  int _6969 = ConvertFToS(_6968);
  int2 _6970 = CompositeConstruct({_6963, _6969});
  ObjectShadowRecord _6972 = *record@4;
  *param@609 = _6972;
  float3 _6974 = *receiverPosition;
  *param@610 = _6974;
  float3 _6976 = *receiverNormal;
  *param@611 = _6976;
  *param@612 = _6970;
  float _6978 = objectShadowVisibility(objectShadowDepth, sharedDepthSampler, param@609, param@610, param@611, param@612);
  return _6978;
}

float materialCharacterVisibility(uint* source@7, float3* normal@20, float* sceneVisibility@6, float* mainShadow) {
  float3* param@613;
  float* _6991;
  uint _6981 = *source@7;
  bool _6982 = _6981 == 2;
  
  if(_6982) {
    float3 _6986 = *normal@20;
    *param@613 = _6986;
    float _6987 = materialObjectVisibility(param@613);
    return _6987;
  }

  uint _6989 = *source@7;
  bool _6990 = _6989 == 1;
  
  if(_6990) {
    float _6994 = *mainShadow;
    *_6991 = _6994;
  } else {
    uint _6996 = *source@7;
    bool _6997 = _6996 == 3;
    float _6998 = *sceneVisibility@6;
    float _6999 = Select(_6997, 1.0000, _6998);
    *_6991 = _6999;
  }

  float _7000 = *_6991;
  return _7000;
}

SceneLightSample sampleSceneLight(ClusterLight* light@8, float3* position@8, bool* projectedDistance) {
  float3* toLight@2;
  float* distanceSquared@4;
  float* distanceToLight;
  float* lightRadius;
  float* attenuation@3;
  float* param@614;
  float* param@615;
  float* param@616;
  float* param@617;
  float3* pointDirection@2;
  float* cone;
  float3* param@618;
  float4* param@619;
  float4* param@620;
  float4* param@621;
  float4* param@622;
  float4* _7004 = &light@8.positionRadius;
  float4 _7005 = *_7004;
  float3 _7006 = _7005.xyz;
  float3 _7007 = *position@8;
  float3 _7008 = _7006 - _7007;
  *toLight@2 = _7008;
  bool _7009 = *projectedDistance;
  
  if(_7009) {
    float4* _7012 = &light@8.directionOuter;
    float4 _7013 = *_7012;
    float3 _7014 = _7013.xyz;
    float3 _7015 = *toLight@2;
    float4* _7016 = &light@8.directionOuter;
    float4 _7017 = *_7016;
    float3 _7018 = _7017.xyz;
    float _7019 = Dot(_7015, _7018);
    float3 _7020 = _7014 * _7019;
    *toLight@2 = _7020;
  }

  float3 _7022 = *toLight@2;
  float3 _7023 = *toLight@2;
  float _7024 = Dot(_7022, _7023);
  *distanceSquared@4 = _7024;
  float _7026 = *distanceSquared@4;
  float _7027 = GLSL.std.450::Sqrt(_7026);
  *distanceToLight = _7027;
  float* _7029 = &light@8.positionRadius.w;
  float _7030 = *_7029;
  float _7031 = GLSL.std.450::FMax(_7030, 0.0010);
  *lightRadius = _7031;
  float _7034 = *distanceSquared@4;
  *param@614 = _7034;
  float _7036 = *lightRadius;
  *param@615 = _7036;
  float* _7038 = &light@8.coneType.z;
  float _7039 = *_7038;
  *param@616 = _7039;
  float* _7041 = &light@8.coneType.w;
  float _7042 = *_7041;
  *param@617 = _7042;
  float _7043 = localLightDistanceWeight(param@614, param@615, param@616, param@617);
  *attenuation@3 = _7043;
  float3 _7045 = *toLight@2;
  float _7046 = *distanceToLight;
  float _7047 = GLSL.std.450::FMax(_7046, 0.0010);
  float3 _7048 = CompositeConstruct({_7047, _7047, _7047});
  float3 _7049 = _7045 / _7048;
  *pointDirection@2 = _7049;
  float* _7050 = &light@8.coneType.y;
  float _7051 = *_7050;
  bool _7052 = _7051 > 1.5000;
  
  if(_7052) {
    float4* _7055 = &light@8.directionOuter;
    float4 _7056 = *_7055;
    float3 _7057 = _7056.xyz;
    float3 _7058 = -_7057;
    *pointDirection@2 = _7058;
    *attenuation@3 = 1.0000;
  } else {
    float* _7060 = &light@8.coneType.y;
    float _7061 = *_7060;
    bool _7062 = _7061 > 0.5000;
    
    if(_7062) {
      float3 _7066 = *pointDirection@2;
      float3 _7067 = -_7066;
      float4* _7068 = &light@8.directionOuter;
      float4 _7069 = *_7068;
      float3 _7070 = _7069.xyz;
      float _7071 = Dot(_7067, _7070);
      float* _7072 = &light@8.directionOuter.w;
      float _7073 = *_7072;
      float _7074 = _7071 - _7073;
      float* _7075 = &light@8.coneType.x;
      float _7076 = *_7075;
      float* _7077 = &light@8.directionOuter.w;
      float _7078 = *_7077;
      float _7079 = _7076 - _7078;
      float _7080 = GLSL.std.450::FMax(_7079, 0.0000);
      float _7081 = _7074 / _7080;
      float _7082 = GLSL.std.450::FClamp(_7081, 0.0000, 1.0000);
      *cone = _7082;
      float* _7083 = &light@8.coneType.x;
      float _7084 = *_7083;
      float* _7085 = &light@8.directionOuter.w;
      float _7086 = *_7085;
      bool _7087 = _7084 == _7086;
      
      if(_7087) {
        float* _7090 = &light@8.directionOuter.w;
        float _7091 = *_7090;
        float3 _7092 = *pointDirection@2;
        float3 _7093 = -_7092;
        float4* _7094 = &light@8.directionOuter;
        float4 _7095 = *_7094;
        float3 _7096 = _7095.xyz;
        float _7097 = Dot(_7093, _7096);
        float _7098 = GLSL.std.450::Step(_7091, _7097);
        *cone = _7098;
      }

      float _7099 = *cone;
      float _7100 = *cone;
      float _7101 = _7099 * _7100;
      float _7102 = *attenuation@3;
      float _7103 = _7102 * _7101;
      *attenuation@3 = _7103;
    }

  }

  float3 _7105 = *position@8;
  *param@618 = _7105;
  float4* _7107 = &light@8.boxRows[0];
  float4 _7108 = *_7107;
  *param@619 = _7108;
  float4* _7110 = &light@8.boxRows[1];
  float4 _7111 = *_7110;
  *param@620 = _7111;
  float4* _7113 = &light@8.boxRows[2];
  float4 _7114 = *_7113;
  *param@621 = _7114;
  float4* _7116 = &light@8.boxParameters;
  float4 _7117 = *_7116;
  *param@622 = _7117;
  float _7118 = lightInfluenceBoxWeight(param@618, param@619, param@620, param@621, param@622);
  float _7119 = *attenuation@3;
  float _7120 = _7119 * _7118;
  *attenuation@3 = _7120;
  float3 _7121 = *toLight@2;
  float3 _7122 = *pointDirection@2;
  float _7123 = *distanceSquared@4;
  float _7124 = *attenuation@3;
  SceneLightSample _7125 = CompositeConstruct({_7121, _7122, _7123, _7124});
  return _7125;
}

float2 azureUnlitLayerUv(float2* uv@24, float4* scaleOffset, float4* rotation@2, float2* speed, float* timeSeconds) {
  float2* d;
  float2* rotated@2;
  float2 _7129 = *uv@24;
  float2 _7130 = *speed;
  float _7131 = *timeSeconds;
  float2 _7132 = _7130 * _7131;
  float2 _7133 = _7129 + _7132;
  float2 _7134 = CompositeConstruct({0.5000, 0.5000});
  float2 _7135 = _7133 - _7134;
  *d = _7135;
  float* _7137 = &d.x;
  float _7138 = *_7137;
  float* _7139 = &rotation@2.x;
  float _7140 = *_7139;
  float _7141 = _7138 * _7140;
  float* _7142 = &d.y;
  float _7143 = *_7142;
  float* _7144 = &rotation@2.z;
  float _7145 = *_7144;
  float _7146 = _7143 * _7145;
  float _7147 = _7141 + _7146;
  float* _7148 = &d.x;
  float _7149 = *_7148;
  float* _7150 = &rotation@2.y;
  float _7151 = *_7150;
  float _7152 = _7149 * _7151;
  float* _7153 = &d.y;
  float _7154 = *_7153;
  float* _7155 = &rotation@2.w;
  float _7156 = *_7155;
  float _7157 = _7154 * _7156;
  float _7158 = _7152 + _7157;
  float2 _7159 = CompositeConstruct({_7147, _7158});
  float2 _7160 = CompositeConstruct({0.5000, 0.5000});
  float2 _7161 = _7159 + _7160;
  *rotated@2 = _7161;
  float2 _7162 = *rotated@2;
  float4 _7163 = *scaleOffset;
  float2 _7164 = _7163.xy;
  float2 _7165 = _7162 * _7164;
  float4 _7166 = *scaleOffset;
  float2 _7167 = _7166.zw;
  float2 _7168 = _7165 + _7167;
  return _7168;
}

float4 azureUnlitLayerSample(float4* rgba, float* mode) {
  float4* _7173;
  float _7171 = *mode;
  bool _7172 = _7171 > 0.5000;
  
  if(_7172) {
    float* _7176 = &rgba.x;
    float _7177 = *_7176;
    float4 _7178 = CompositeConstruct({1.0000, 1.0000, 1.0000, _7177});
    *_7173 = _7178;
  } else {
    float4 _7180 = *rgba;
    *_7173 = _7180;
  }

  float4 _7181 = *_7173;
  return _7181;
}

float azureUnlitSoftIntersection(float* sceneViewZ, float* effectViewZ, float* distance@6, float* bias@2) {
  float _7184 = *sceneViewZ;
  float _7185 = GLSL.std.450::FAbs(_7184);
  float _7186 = *effectViewZ;
  float _7187 = GLSL.std.450::FAbs(_7186);
  float _7188 = _7185 - _7187;
  float _7189 = *bias@2;
  float _7190 = _7188 + _7189;
  float _7191 = *distance@6;
  float _7192 = _7190 / _7191;
  float _7193 = GLSL.std.450::FClamp(_7192, 0.0000, 1.0000);
  return _7193;
}

float azureUnlitViewDepthFade(float* effectViewZ@2, float4* range, float* enabled@2) {
  float* depth@12;
  float _7196 = *enabled@2;
  bool _7197 = _7196 < 0.5000;
  
  if(_7197) {
    return 1.0000;
  }

  float _7202 = *effectViewZ@2;
  float _7203 = GLSL.std.450::FAbs(_7202);
  *depth@12 = _7203;
  float _7204 = *depth@12;
  float* _7205 = &range.x;
  float _7206 = *_7205;
  float _7207 = _7204 - _7206;
  float* _7208 = &range.y;
  float _7209 = *_7208;
  float* _7210 = &range.x;
  float _7211 = *_7210;
  float _7212 = _7209 - _7211;
  float _7213 = _7207 / _7212;
  float _7214 = GLSL.std.450::FClamp(_7213, 0.0000, 1.0000);
  float* _7215 = &range.w;
  float _7216 = *_7215;
  float _7217 = *depth@12;
  float _7218 = _7216 - _7217;
  float* _7219 = &range.w;
  float _7220 = *_7219;
  float* _7221 = &range.z;
  float _7222 = *_7221;
  float _7223 = _7220 - _7222;
  float _7224 = _7218 / _7223;
  float _7225 = GLSL.std.450::FClamp(_7224, 0.0000, 1.0000);
  float _7226 = _7214 * _7225;
  return _7226;
}

float azureUnlitViewCoverage(float* normalDotView@2, float4* parameters@4) {
  float* power@2;
  float _7230 = *normalDotView@2;
  float* _7231 = &parameters@4.x;
  float _7232 = *_7231;
  float _7233 = _7230 + _7232;
  float _7234 = GLSL.std.450::FClamp(_7233, 0.0000, 1.0000);
  float* _7235 = &parameters@4.y;
  float _7236 = *_7235;
  float _7237 = GLSL.std.450::Pow(_7234, _7236);
  *power@2 = _7237;
  float _7238 = *power@2;
  float _7239 = 1.0000 - _7238;
  float _7240 = *power@2;
  float* _7241 = &parameters@4.z;
  float _7242 = *_7241;
  float _7243 = GLSL.std.450::FMix(_7239, _7240, _7242);
  float* _7244 = &parameters@4.w;
  float _7245 = *_7244;
  float _7246 = GLSL.std.450::FMix(1.0000, _7243, _7245);
  return _7246;
}

float azureUnlitCoverageLayer(float4* value@6, float* mode@2, float2* remap) {
  float4* param@623;
  float* param@624;
  float4 _7250 = *value@6;
  *param@623 = _7250;
  float _7252 = *mode@2;
  *param@624 = _7252;
  float4 _7253 = azureUnlitLayerSample(param@623, param@624);
  float _7254 = _7253.w;
  float* _7255 = &remap.x;
  float _7256 = *_7255;
  float _7257 = _7254 - _7256;
  float* _7258 = &remap.y;
  float _7259 = *_7258;
  float _7260 = _7257 * _7259;
  float _7261 = GLSL.std.450::FClamp(_7260, 0.0000, 1.0000);
  return _7261;
}

float2 azureUnlitBaseUvDistortion(float4* sampleValue@2, float* channels, float4* remap@2) {
  float2* _7266;
  float _7264 = *channels;
  bool _7265 = _7264 > 0.5000;
  
  if(_7265) {
    float4 _7269 = *sampleValue@2;
    float2 _7270 = _7269.xy;
    *_7266 = _7270;
  } else {
    float4 _7272 = *sampleValue@2;
    float2 _7273 = _7272.xx;
    *_7266 = _7273;
  }

  float2 _7274 = *_7266;
  float4 _7275 = *remap@2;
  float2 _7276 = _7275.xy;
  float2 _7277 = _7274 * _7276;
  float4 _7278 = *remap@2;
  float2 _7279 = _7278.zw;
  float2 _7280 = _7277 + _7279;
  return _7280;
}

float4 azureUnlitLayerColor(float4* base@11, float4* second, float4[22]* rows@2, float* soft, float* exposureGain, float* saturation@3, float3* colorGain, float4* vertexColor, float* normalDotView@3, float4* coverage) {
  float4* param@625;
  float* param@626;
  float4* param@627;
  float* param@628;
  float4* param@629;
  float* param@630;
  float2* param@631;
  float* param@632;
  float4* param@633;
  float* luminance@3;
  float3* mapped;
  float4 _7284 = *base@11;
  *param@625 = _7284;
  float* _7286 = &rows@2[9].x;
  float _7287 = *_7286;
  *param@626 = _7287;
  float4 _7288 = azureUnlitLayerSample(param@625, param@626);
  float4* _7289 = &rows@2[6];
  float4 _7290 = *_7289;
  float4 _7291 = _7288 * _7290;
  *base@11 = _7291;
  float* _7292 = &rows@2[11].y;
  float _7293 = *_7292;
  bool _7294 = _7293 > 0.5000;
  
  if(_7294) {
    float4 _7297 = *vertexColor;
    float4 _7298 = *base@11;
    float4 _7299 = _7298 * _7297;
    *base@11 = _7299;
  }

  float* _7300 = &rows@2[9].z;
  float _7301 = *_7300;
  bool _7302 = _7301 > 0.5000;
  
  if(_7302) {
    float4 _7306 = *second;
    *param@627 = _7306;
    float* _7308 = &rows@2[9].y;
    float _7309 = *_7308;
    *param@628 = _7309;
    float4 _7310 = azureUnlitLayerSample(param@627, param@628);
    *second = _7310;
    float* _7311 = &rows@2[9].z;
    float _7312 = *_7311;
    bool _7313 = _7312 < 1.5000;
    
    if(_7313) {
      float4 _7316 = *second;
      float4 _7317 = *base@11;
      float4 _7318 = _7317 * _7316;
      *base@11 = _7318;
    } else {
      float4 _7320 = *second;
      float3 _7321 = _7320.xyz;
      float4* _7322 = &rows@2[7];
      float4 _7323 = *_7322;
      float3 _7324 = _7323.xyz;
      float3 _7325 = _7321 * _7324;
      float* _7326 = &base@11.w;
      float _7327 = *_7326;
      float* _7328 = &second.w;
      float _7329 = *_7328;
      float _7330 = _7327 + _7329;
      float* _7331 = &rows@2[7].w;
      float _7332 = *_7331;
      float _7333 = _7330 * _7332;
      float _7334 = GLSL.std.450::FClamp(_7333, 0.0000, 1.0000);
      float3 _7335 = _7325 * _7334;
      float4 _7336 = *base@11;
      float3 _7337 = _7336.xyz;
      float3 _7338 = _7337 + _7335;
      float* _7339 = &base@11.x;
      float _7340 = _7338.x;
      *_7339 = _7340;
      float* _7341 = &base@11.y;
      float _7342 = _7338.y;
      *_7341 = _7342;
      float* _7343 = &base@11.z;
      float _7344 = _7338.z;
      *_7343 = _7344;
    }

  }

  float* _7345 = &rows@2[11].w;
  float _7346 = *_7345;
  bool _7347 = _7346 > 0.5000;
  
  if(_7347) {
    float4 _7352 = *coverage;
    *param@629 = _7352;
    float* _7354 = &rows@2[15].z;
    float _7355 = *_7354;
    *param@630 = _7355;
    float4* _7357 = &rows@2[16];
    float4 _7358 = *_7357;
    float2 _7359 = _7358.xy;
    *param@631 = _7359;
    float _7360 = azureUnlitCoverageLayer(param@629, param@630, param@631);
    float* _7361 = &base@11.w;
    float _7362 = *_7361;
    float _7363 = _7362 * _7360;
    float* _7364 = &base@11.w;
    *_7364 = _7363;
  }

  float* _7365 = &rows@2[11].z;
  float _7366 = *_7365;
  bool _7367 = _7366 > 0.5000;
  
  if(_7367) {
    float* _7370 = &base@11.w;
    float _7371 = *_7370;
    float _7372 = GLSL.std.450::FClamp(_7371, 0.0000, 1.0000);
    float _7374 = *normalDotView@3;
    *param@632 = _7374;
    float4* _7376 = &rows@2[12];
    float4 _7377 = *_7376;
    *param@633 = _7377;
    float _7378 = azureUnlitViewCoverage(param@632, param@633);
    float _7379 = _7372 * _7378;
    float* _7380 = &base@11.w;
    *_7380 = _7379;
  }

  float4 _7381 = *base@11;
  float3 _7382 = _7381.xyz;
  float* _7383 = &rows@2[8].x;
  float _7384 = *_7383;
  float3 _7385 = CompositeConstruct({_7384, _7384, _7384});
  float3 _7386 = _7382 - _7385;
  float3 _7387 = GLSL.std.450::FMax(_7386, {0.0000, 0.0000, 0.0000});
  float* _7388 = &rows@2[8].y;
  float _7389 = *_7388;
  float3 _7390 = _7387 * _7389;
  float4 _7391 = *base@11;
  float3 _7392 = _7391.xyz;
  float3 _7393 = _7392 + _7390;
  float* _7394 = &base@11.x;
  float _7395 = _7393.x;
  *_7394 = _7395;
  float* _7396 = &base@11.y;
  float _7397 = _7393.y;
  *_7396 = _7397;
  float* _7398 = &base@11.z;
  float _7399 = _7393.z;
  *_7398 = _7399;
  float4 _7400 = *base@11;
  float3 _7401 = _7400.xyz;
  float _7402 = *exposureGain;
  float* _7403 = &rows@2[8].z;
  float _7404 = *_7403;
  float _7405 = GLSL.std.450::FMix(1.0000, _7402, _7404);
  float3 _7406 = _7401 * _7405;
  float3 _7409 = GLSL.std.450::FClamp(_7406, {0.0000, 0.0000, 0.0000}, {1000.0000, 1000.0000, 1000.0000});
  float* _7410 = &base@11.x;
  float _7411 = _7409.x;
  *_7410 = _7411;
  float* _7412 = &base@11.y;
  float _7413 = _7409.y;
  *_7412 = _7413;
  float* _7414 = &base@11.z;
  float _7415 = _7409.z;
  *_7414 = _7415;
  float4 _7417 = *base@11;
  float3 _7418 = _7417.xyz;
  float _7422 = Dot(_7418, {0.2127, 0.7152, 0.0722});
  *luminance@3 = _7422;
  float _7424 = *luminance@3;
  float _7425 = *saturation@3;
  float4 _7426 = *base@11;
  float3 _7427 = _7426.xyz;
  float _7428 = *luminance@3;
  float3 _7429 = CompositeConstruct({_7428, _7428, _7428});
  float3 _7430 = _7427 - _7429;
  float3 _7431 = _7430 * _7425;
  float3 _7432 = CompositeConstruct({_7424, _7424, _7424});
  float3 _7433 = _7432 + _7431;
  float3 _7434 = *colorGain;
  float3 _7435 = _7433 * _7434;
  *mapped = _7435;
  float4 _7436 = *base@11;
  float3 _7437 = _7436.xyz;
  float3 _7438 = *mapped;
  float* _7439 = &rows@2[8].w;
  float _7440 = *_7439;
  float3 _7441 = CompositeConstruct({_7440, _7440, _7440});
  float3 _7442 = GLSL.std.450::FMix(_7437, _7438, _7441);
  float* _7443 = &base@11.x;
  float _7444 = _7442.x;
  *_7443 = _7444;
  float* _7445 = &base@11.y;
  float _7446 = _7442.y;
  *_7445 = _7446;
  float* _7447 = &base@11.z;
  float _7448 = _7442.z;
  *_7447 = _7448;
  float* _7449 = &base@11.w;
  float _7450 = *_7449;
  float _7451 = *soft;
  float _7452 = _7450 * _7451;
  float _7453 = GLSL.std.450::FClamp(_7452, 0.0000, 1.0000);
  float* _7454 = &base@11.w;
  *_7454 = _7453;
  float4 _7455 = *base@11;
  return _7455;
}

float azureMaterialRadianceScale() {
  uint* _7466 = &material.materialPadding;
  uint _7467 = *_7466;
  uint _7468 = _7467 >> 1;
  float* _7470 = &materialSurfaceProfiles.profiles[_7468].rows[19].w;
  float _7471 = *_7470;
  return _7471;
}

void azureWriteDisplayMask(float* coverage@2) {
  float* sceneWeight;
  uint* _7475 = &material.materialPadding;
  uint _7476 = *_7475;
  uint _7477 = _7476 >> 1;
  float* _7479 = &materialSurfaceProfiles.profiles[_7477].rows[21].x;
  float _7480 = *_7479;
  float _7481 = 1.0000 - _7480;
  *sceneWeight = _7481;
  float _7484 = *sceneWeight;
  float _7485 = *coverage@2;
  float4 _7486 = CompositeConstruct({_7484, 0.0000, 0.0000, _7485});
  *outputDisplayMask = _7486;
  return;
}

ProjectedHairProfile loadProjectedHairSurfaceProfile(uint* index@3) {
  PackedMaterialSurfaceProfile* p@8;
  uint _7488 = *index@3;
  PackedMaterialSurfaceProfile* _7490 = &materialSurfaceProfiles.profiles[_7488];
  PackedMaterialSurfaceProfile _7491 = *_7490;
  float4[22] _7492 = _7491.rows;
  float4[22]* _7493 = &p@8.rows;
  float4 _7494 = _7492[0];
  float4* _7495 = &_7493[0];
  *_7495 = _7494;
  float4 _7496 = _7492[1];
  float4* _7497 = &_7493[1];
  *_7497 = _7496;
  float4 _7498 = _7492[2];
  float4* _7499 = &_7493[2];
  *_7499 = _7498;
  float4 _7500 = _7492[3];
  float4* _7501 = &_7493[3];
  *_7501 = _7500;
  float4 _7502 = _7492[4];
  float4* _7503 = &_7493[4];
  *_7503 = _7502;
  float4 _7504 = _7492[5];
  float4* _7505 = &_7493[5];
  *_7505 = _7504;
  float4 _7506 = _7492[6];
  float4* _7507 = &_7493[6];
  *_7507 = _7506;
  float4 _7508 = _7492[7];
  float4* _7509 = &_7493[7];
  *_7509 = _7508;
  float4 _7510 = _7492[8];
  float4* _7511 = &_7493[8];
  *_7511 = _7510;
  float4 _7512 = _7492[9];
  float4* _7513 = &_7493[9];
  *_7513 = _7512;
  float4 _7514 = _7492[10];
  float4* _7516 = &_7493[10];
  *_7516 = _7514;
  float4 _7517 = _7492[11];
  float4* _7518 = &_7493[11];
  *_7518 = _7517;
  float4 _7519 = _7492[12];
  float4* _7520 = &_7493[12];
  *_7520 = _7519;
  float4 _7521 = _7492[13];
  float4* _7522 = &_7493[13];
  *_7522 = _7521;
  float4 _7523 = _7492[14];
  float4* _7525 = &_7493[14];
  *_7525 = _7523;
  float4 _7526 = _7492[15];
  float4* _7527 = &_7493[15];
  *_7527 = _7526;
  float4 _7528 = _7492[16];
  float4* _7529 = &_7493[16];
  *_7529 = _7528;
  float4 _7530 = _7492[17];
  float4* _7532 = &_7493[17];
  *_7532 = _7530;
  float4 _7533 = _7492[18];
  float4* _7535 = &_7493[18];
  *_7535 = _7533;
  float4 _7536 = _7492[19];
  float4* _7537 = &_7493[19];
  *_7537 = _7536;
  float4 _7538 = _7492[20];
  float4* _7540 = &_7493[20];
  *_7540 = _7538;
  float4 _7541 = _7492[21];
  float4* _7542 = &_7493[21];
  *_7542 = _7541;
  float4* _7543 = &p@8.rows[0];
  float4 _7544 = *_7543;
  float4* _7545 = &p@8.rows[1];
  float4 _7546 = *_7545;
  float4* _7547 = &p@8.rows[2];
  float4 _7548 = *_7547;
  float4* _7549 = &p@8.rows[3];
  float4 _7550 = *_7549;
  float4* _7551 = &p@8.rows[4];
  float4 _7552 = *_7551;
  float4* _7553 = &p@8.rows[5];
  float4 _7554 = *_7553;
  ProjectedHairProfile _7555 = CompositeConstruct({_7544, _7546, _7548, _7550, _7552, _7554});
  return _7555;
}

EyeSurfaceProfile loadEyeSurfaceProfile(uint* index@4) {
  PackedMaterialSurfaceProfile* p@9;
  uint _7559 = *index@4;
  PackedMaterialSurfaceProfile* _7560 = &materialSurfaceProfiles.profiles[_7559];
  PackedMaterialSurfaceProfile _7561 = *_7560;
  float4[22] _7562 = _7561.rows;
  float4[22]* _7563 = &p@9.rows;
  float4 _7564 = _7562[0];
  float4* _7565 = &_7563[0];
  *_7565 = _7564;
  float4 _7566 = _7562[1];
  float4* _7567 = &_7563[1];
  *_7567 = _7566;
  float4 _7568 = _7562[2];
  float4* _7569 = &_7563[2];
  *_7569 = _7568;
  float4 _7570 = _7562[3];
  float4* _7571 = &_7563[3];
  *_7571 = _7570;
  float4 _7572 = _7562[4];
  float4* _7573 = &_7563[4];
  *_7573 = _7572;
  float4 _7574 = _7562[5];
  float4* _7575 = &_7563[5];
  *_7575 = _7574;
  float4 _7576 = _7562[6];
  float4* _7577 = &_7563[6];
  *_7577 = _7576;
  float4 _7578 = _7562[7];
  float4* _7579 = &_7563[7];
  *_7579 = _7578;
  float4 _7580 = _7562[8];
  float4* _7581 = &_7563[8];
  *_7581 = _7580;
  float4 _7582 = _7562[9];
  float4* _7583 = &_7563[9];
  *_7583 = _7582;
  float4 _7584 = _7562[10];
  float4* _7585 = &_7563[10];
  *_7585 = _7584;
  float4 _7586 = _7562[11];
  float4* _7587 = &_7563[11];
  *_7587 = _7586;
  float4 _7588 = _7562[12];
  float4* _7589 = &_7563[12];
  *_7589 = _7588;
  float4 _7590 = _7562[13];
  float4* _7591 = &_7563[13];
  *_7591 = _7590;
  float4 _7592 = _7562[14];
  float4* _7593 = &_7563[14];
  *_7593 = _7592;
  float4 _7594 = _7562[15];
  float4* _7595 = &_7563[15];
  *_7595 = _7594;
  float4 _7596 = _7562[16];
  float4* _7597 = &_7563[16];
  *_7597 = _7596;
  float4 _7598 = _7562[17];
  float4* _7599 = &_7563[17];
  *_7599 = _7598;
  float4 _7600 = _7562[18];
  float4* _7601 = &_7563[18];
  *_7601 = _7600;
  float4 _7602 = _7562[19];
  float4* _7603 = &_7563[19];
  *_7603 = _7602;
  float4 _7604 = _7562[20];
  float4* _7605 = &_7563[20];
  *_7605 = _7604;
  float4 _7606 = _7562[21];
  float4* _7607 = &_7563[21];
  *_7607 = _7606;
  float4* _7608 = &p@9.rows[0];
  float4 _7609 = *_7608;
  float4* _7610 = &p@9.rows[1];
  float4 _7611 = *_7610;
  float4* _7612 = &p@9.rows[2];
  float4 _7613 = *_7612;
  float4* _7614 = &p@9.rows[3];
  float4 _7615 = *_7614;
  float4* _7616 = &p@9.rows[4];
  float4 _7617 = *_7616;
  float4* _7618 = &p@9.rows[5];
  float4 _7619 = *_7618;
  EyeSurfaceProfile _7620 = CompositeConstruct({_7609, _7611, _7613, _7615, _7617, _7619});
  return _7620;
}

float3 projectedHairNormal(float2* encoded@4, float* scale@4, float* tangentSign) {
  float2* param@634;
  float* param@635;
  float3* param@636;
  float4* param@637;
  float4 _7624 = *worldTangent;
  float3 _7625 = _7624.xyz;
  float* _7626 = &worldTangent.w;
  float _7627 = *_7626;
  float _7628 = *tangentSign;
  float _7629 = _7627 * _7628;
  float _7630 = _7625.x;
  float _7631 = _7625.y;
  float _7632 = _7625.z;
  float4 _7633 = CompositeConstruct({_7630, _7631, _7632, _7629});
  float2 _7635 = *encoded@4;
  *param@634 = _7635;
  float _7637 = *scale@4;
  *param@635 = _7637;
  float3 _7639 = *worldNormal;
  *param@636 = _7639;
  *param@637 = _7633;
  float3 _7641 = characterProjectedHairNormal(param@634, param@635, param@636, param@637);
  return _7641;
}

CharacterProjectedHairEnergy projectedHairSample(float3* view@8, float3* light@9, bool* directional@3, bool* evaluateLine, float2* uv@25, float2* screenOffset, bool* integrated, ProjectedHairIncident* incident@5, float2* line@3) {
  ProjectedHairProfile* p@10;
  uint* param@638;
  float4* parameters@5;
  float4* _7653;
  float4* packedNormals;
  float4* _7686;
  float3* basisNormal;
  float4* basisTangent;
  float3* position@9;
  float3* param@639;
  float3* param@640;
  float4* tangent@8;
  float3* normal@21;
  float2* param@641;
  float* param@642;
  float3* param@643;
  float4* param@644;
  float3x3* frame;
  float3* objectX@4;
  float3* objectY@4;
  float3* objectZ@4;
  float4* adapter;
  bool* virtualLight@2;
  float3* halfVector@6;
  float3* _7841;
  float3* param@645;
  float3* param@646;
  float3* param@647;
  float3* param@648;
  float3* param@649;
  float* param@650;
  float3* param@651;
  float3* param@652;
  CharacterProjectedHairCoordinates* coordinates@4;
  float3* param@653;
  float3* param@654;
  float3* param@655;
  float4* param@656;
  float4* param@657;
  float3* param@658;
  float3* param@659;
  float3* param@660;
  float* param@661;
  float* param@662;
  float* param@663;
  float* param@664;
  float* param@665;
  float3* ramp@12;
  CharacterProjectedHairEnergy* energy@5;
  CharacterProjectedHairCoordinates* param@666;
  float3* param@667;
  float4* param@668;
  float* param@669;
  float3* param@670;
  PackedMaterialSurfaceProfile* packed;
  float4* uvTransform;
  float2* lineUv;
  float* sampleValue@3;
  float* _8001;
  float3* strand@3;
  float3* param@671;
  float4* param@672;
  float* param@673;
  float3* param@674;
  float3* param@675;
  float3* param@676;
  float* param@677;
  float3* param@678;
  float3* param@679;
  float3* param@680;
  float* param@681;
  float* param@682;
  float* param@683;
  float3* param@684;
  float4* param@685;
  float2* param@686;
  float3* surface@4;
  float2* param@687;
  float* param@688;
  float3* param@689;
  float4* param@690;
  float* cosine@2;
  float* ao;
  float* visibility@12;
  float4* diffuseRamp;
  float* viewAlpha@3;
  float* litMask@6;
  float* aoMask@5;
  CharacterDiffuseIllumination* illumination@5;
  float3* param@691;
  float3* param@692;
  float4* param@693;
  float4* param@694;
  float4* param@695;
  float4* param@696;
  float* param@697;
  float* param@698;
  float* param@699;
  float* param@700;
  float* mask@2;
  float* scale@5;
  float3* weight@10;
  float3* radiance@8;
  float3* param@701;
  float* param@702;
  float2* param@703;
  float* param@704;
  uint* _7646 = &material.materialPadding;
  uint _7647 = *_7646;
  uint _7648 = _7647 >> 1;
  *param@638 = _7648;
  ProjectedHairProfile _7650 = loadProjectedHairSurfaceProfile(param@638);
  *p@10 = _7650;
  bool _7652 = *integrated;
  
  if(_7652) {
    uint* _7659 = &material.textureBase;
    uint _7660 = *_7659;
    uint _7661 = _7660 + 7;
    uint _7662 = CopyObject(_7661) : [[NonUniform]];
    SampledImage<float, 2D>* _7663 = &textureArray[_7662] : [[NonUniform]];
    SampledImage<float, 2D> _7664 = *_7663 : [[NonUniform]];
    float2 _7665 = *uv@25;
    float2 _7668 = *projectedHairUvDx;
    float2 _7669 = _7668 * 0.2500;
    float2 _7671 = *projectedHairUvDy;
    float2 _7672 = _7671 * 0.2500;
    float4 _7673 = ImageSampleExplicitLod(_7664, _7665, Grad(_7669, _7672));
    *_7653 = _7673;
  } else {
    uint* _7675 = &material.textureBase;
    uint _7676 = *_7675;
    uint _7677 = _7676 + 7;
    uint _7678 = CopyObject(_7677) : [[NonUniform]];
    SampledImage<float, 2D>* _7679 = &textureArray[_7678] : [[NonUniform]];
    SampledImage<float, 2D> _7680 = *_7679 : [[NonUniform]];
    float2 _7681 = *uv@25;
    float4 _7682 = ImageSampleImplicitLod(_7680, _7681);
    *_7653 = _7682;
  }

  float4 _7683 = *_7653;
  *parameters@5 = _7683;
  bool _7685 = *integrated;
  
  if(_7685) {
    uint* _7689 = &material.textureBase;
    uint _7690 = *_7689;
    uint _7691 = _7690 + 6;
    uint _7692 = CopyObject(_7691) : [[NonUniform]];
    SampledImage<float, 2D>* _7693 = &textureArray[_7692] : [[NonUniform]];
    SampledImage<float, 2D> _7694 = *_7693 : [[NonUniform]];
    float2 _7695 = *uv@25;
    float2 _7696 = *projectedHairUvDx;
    float2 _7697 = _7696 * 0.2500;
    float2 _7698 = *projectedHairUvDy;
    float2 _7699 = _7698 * 0.2500;
    float4 _7700 = ImageSampleExplicitLod(_7694, _7695, Grad(_7697, _7699));
    *_7686 = _7700;
  } else {
    uint* _7702 = &material.textureBase;
    uint _7703 = *_7702;
    uint _7704 = _7703 + 6;
    uint _7705 = CopyObject(_7704) : [[NonUniform]];
    SampledImage<float, 2D>* _7706 = &textureArray[_7705] : [[NonUniform]];
    SampledImage<float, 2D> _7707 = *_7706 : [[NonUniform]];
    float2 _7708 = *uv@25;
    float4 _7709 = ImageSampleImplicitLod(_7707, _7708);
    *_7686 = _7709;
  }

  float4 _7710 = *_7686;
  *packedNormals = _7710;
  float3 _7712 = *worldNormal;
  *basisNormal = _7712;
  float4 _7714 = *worldTangent;
  *basisTangent = _7714;
  bool _7715 = *integrated;
  
  if(_7715) {
    float3 _7720 = *projectedHairNormalDx;
    float* _7721 = &screenOffset.x;
    float _7722 = *_7721;
    float3 _7723 = _7720 * _7722;
    float3 _7725 = *projectedHairNormalDy;
    float* _7726 = &screenOffset.y;
    float _7727 = *_7726;
    float3 _7728 = _7725 * _7727;
    float3 _7729 = _7723 + _7728;
    float3 _7730 = *basisNormal;
    float3 _7731 = _7730 + _7729;
    *basisNormal = _7731;
    float4 _7734 = *projectedHairTangentDx;
    float* _7735 = &screenOffset.x;
    float _7736 = *_7735;
    float4 _7737 = _7734 * _7736;
    float4 _7739 = *projectedHairTangentDy;
    float* _7740 = &screenOffset.y;
    float _7741 = *_7740;
    float4 _7742 = _7739 * _7741;
    float4 _7743 = _7737 + _7742;
    float4 _7744 = *basisTangent;
    float4 _7745 = _7744 + _7743;
    *basisTangent = _7745;
    float3 _7747 = *worldPosition;
    float3 _7749 = *projectedHairPositionDx;
    float* _7750 = &screenOffset.x;
    float _7751 = *_7750;
    float3 _7752 = _7749 * _7751;
    float3 _7753 = _7747 + _7752;
    float3 _7755 = *projectedHairPositionDy;
    float* _7756 = &screenOffset.y;
    float _7757 = *_7756;
    float3 _7758 = _7755 * _7757;
    float3 _7759 = _7753 + _7758;
    *position@9 = _7759;
    float4* _7760 = &camera.cameraPosition;
    float4 _7761 = *_7760;
    float3 _7762 = _7761.xyz;
    float3 _7763 = *position@9;
    float3 _7764 = _7762 - _7763;
    *param@639 = _7764;
    float3 _7767 = *view@8;
    *param@640 = _7767;
    float3 _7768 = characterProjectedSafeNormalize(param@639, param@640);
    *view@8 = _7768;
  }

  float4 _7770 = *basisTangent;
  float3 _7771 = _7770.xyz;
  float* _7772 = &basisTangent.w;
  float _7773 = *_7772;
  float* _7774 = &p@10.objectY.w;
  float _7775 = *_7774;
  float _7776 = _7773 * _7775;
  float _7777 = _7771.x;
  float _7778 = _7771.y;
  float _7779 = _7771.z;
  float4 _7780 = CompositeConstruct({_7777, _7778, _7779, _7776});
  *tangent@8 = _7780;
  float4 _7783 = *packedNormals;
  float2 _7784 = _7783.zw;
  *param@641 = _7784;
  float* _7786 = &p@10.edgeNormalDirection.y;
  float _7787 = *_7786;
  *param@642 = _7787;
  float3 _7789 = *basisNormal;
  *param@643 = _7789;
  float4 _7791 = *tangent@8;
  *param@644 = _7791;
  float3 _7792 = characterProjectedHairNormal(param@641, param@642, param@643, param@644);
  *normal@21 = _7792;
  float4x4 _7796 = *instanceFaceFrame;
  float4 _7797 = _7796[0];
  float3 _7798 = _7797.xyz;
  float4 _7799 = _7796[1];
  float3 _7800 = _7799.xyz;
  float4 _7801 = _7796[2];
  float3 _7802 = _7801.xyz;
  float3x3 _7803 = CompositeConstruct({_7798, _7800, _7802});
  *frame = _7803;
  float3x3 _7805 = *frame;
  float4* _7806 = &p@10.objectX;
  float4 _7807 = *_7806;
  float3 _7808 = _7807.xyz;
  float3 _7809 = _7805 * _7808;
  float3 _7810 = GLSL.std.450::Normalize(_7809);
  *objectX@4 = _7810;
  float3x3 _7812 = *frame;
  float4* _7813 = &p@10.objectY;
  float4 _7814 = *_7813;
  float3 _7815 = _7814.xyz;
  float3 _7816 = _7812 * _7815;
  float3 _7817 = GLSL.std.450::Normalize(_7816);
  *objectY@4 = _7817;
  float3x3 _7819 = *frame;
  float4* _7820 = &p@10.objectZ;
  float4 _7821 = *_7820;
  float3 _7822 = _7821.xyz;
  float3 _7823 = _7819 * _7822;
  float3 _7824 = GLSL.std.450::Normalize(_7823);
  *objectZ@4 = _7824;
  uint* _7826 = &material.materialPadding;
  uint _7827 = *_7826;
  uint _7828 = _7827 >> 1;
  float4* _7829 = &materialSurfaceProfiles.profiles[_7828].rows[6];
  float4 _7830 = *_7829;
  *adapter = _7830;
  float* _7832 = &adapter.x;
  float _7833 = *_7832;
  uint _7834 = ConvertFToU(_7833);
  uint _7835 = _7834 & 1;
  bool _7836 = _7835 != 0;
  *virtualLight@2 = _7836;
  bool _7838 = *virtualLight@2;
  bool _7839 = *directional@3;
  bool _7840 = _7838 && _7839;
  
  if(_7840) {
    float3 _7845 = *view@8;
    *param@645 = _7845;
    float3 _7847 = *light@9;
    *param@646 = _7847;
    float3 _7849 = *objectX@4;
    *param@647 = _7849;
    float3 _7851 = *objectY@4;
    *param@648 = _7851;
    float3 _7853 = *objectZ@4;
    *param@649 = _7853;
    float* _7855 = &adapter.y;
    float _7856 = *_7855;
    *param@650 = _7856;
    float3 _7857 = characterProjectedVirtualHalf(param@645, param@646, param@647, param@648, param@649, param@650);
    *_7841 = _7857;
  } else {
    float3 _7859 = *view@8;
    float3 _7860 = *light@9;
    float3 _7861 = _7859 + _7860;
    *param@651 = _7861;
    float3 _7864 = *normal@21;
    *param@652 = _7864;
    float3 _7865 = characterProjectedSafeNormalize(param@651, param@652);
    *_7841 = _7865;
  }

  float3 _7866 = *_7841;
  *halfVector@6 = _7866;
  float3 _7869 = *halfVector@6;
  *param@653 = _7869;
  float3 _7871 = *normal@21;
  *param@654 = _7871;
  float3 _7873 = *view@8;
  *param@655 = _7873;
  float4 _7875 = *parameters@5;
  *param@656 = _7875;
  float4 _7877 = *tangent@8;
  *param@657 = _7877;
  float3 _7879 = *objectX@4;
  *param@658 = _7879;
  float3 _7881 = *objectY@4;
  *param@659 = _7881;
  float3 _7883 = *objectZ@4;
  *param@660 = _7883;
  float* _7885 = &p@10.shiftsIntensityRange.x;
  float _7886 = *_7885;
  *param@661 = _7886;
  float* _7888 = &p@10.shiftsIntensityRange.y;
  float _7889 = *_7888;
  *param@662 = _7889;
  float* _7891 = &p@10.shiftsIntensityRange.w;
  float _7892 = *_7891;
  *param@663 = _7892;
  float* _7894 = &p@10.edgeNormalDirection.x;
  float _7895 = *_7894;
  *param@664 = _7895;
  float* _7897 = &p@10.edgeNormalDirection.z;
  float _7898 = *_7897;
  *param@665 = _7898;
  CharacterProjectedHairCoordinates _7899 = characterProjectedHairCoordinates(param@653, param@654, param@655, param@656, param@657, param@658, param@659, param@660, param@661, param@662, param@663, param@664, param@665);
  *coordinates@4 = _7899;
  uint* _7901 = &material.textureBase;
  uint _7902 = *_7901;
  uint _7903 = _7902 + 5;
  uint _7904 = CopyObject(_7903) : [[NonUniform]];
  SampledImage<float, 2D>* _7905 = &textureArray[_7904] : [[NonUniform]];
  SampledImage<float, 2D> _7906 = *_7905 : [[NonUniform]];
  float2* _7907 = &coordinates@4.uv;
  float2 _7908 = *_7907;
  float4 _7909 = ImageSampleExplicitLod(_7906, _7908, Lod(0.0000));
  float3 _7910 = _7909.xyz;
  *ramp@12 = _7910;
  CharacterProjectedHairCoordinates _7914 = *coordinates@4;
  *param@666 = _7914;
  float3 _7916 = *ramp@12;
  *param@667 = _7916;
  float4 _7918 = *parameters@5;
  *param@668 = _7918;
  float* _7920 = &p@10.shiftsIntensityRange.z;
  float _7921 = *_7920;
  *param@669 = _7921;
  float4* _7923 = &p@10.secondaryColor;
  float4 _7924 = *_7923;
  float3 _7925 = _7924.xyz;
  *param@670 = _7925;
  CharacterProjectedHairEnergy _7926 = characterProjectedHairEnergy(param@666, param@667, param@668, param@669, param@670);
  *energy@5 = _7926;
  *line@3 = {1.0000, 1.0000};
  uint* _7928 = &material.materialPadding;
  uint _7929 = *_7928;
  uint _7930 = _7929 >> 1;
  PackedMaterialSurfaceProfile* _7931 = &materialSurfaceProfiles.profiles[_7930];
  PackedMaterialSurfaceProfile _7932 = *_7931;
  float4[22] _7933 = _7932.rows;
  float4[22]* _7934 = &packed.rows;
  float4 _7935 = _7933[0];
  float4* _7936 = &_7934[0];
  *_7936 = _7935;
  float4 _7937 = _7933[1];
  float4* _7938 = &_7934[1];
  *_7938 = _7937;
  float4 _7939 = _7933[2];
  float4* _7940 = &_7934[2];
  *_7940 = _7939;
  float4 _7941 = _7933[3];
  float4* _7942 = &_7934[3];
  *_7942 = _7941;
  float4 _7943 = _7933[4];
  float4* _7944 = &_7934[4];
  *_7944 = _7943;
  float4 _7945 = _7933[5];
  float4* _7946 = &_7934[5];
  *_7946 = _7945;
  float4 _7947 = _7933[6];
  float4* _7948 = &_7934[6];
  *_7948 = _7947;
  float4 _7949 = _7933[7];
  float4* _7950 = &_7934[7];
  *_7950 = _7949;
  float4 _7951 = _7933[8];
  float4* _7952 = &_7934[8];
  *_7952 = _7951;
  float4 _7953 = _7933[9];
  float4* _7954 = &_7934[9];
  *_7954 = _7953;
  float4 _7955 = _7933[10];
  float4* _7956 = &_7934[10];
  *_7956 = _7955;
  float4 _7957 = _7933[11];
  float4* _7958 = &_7934[11];
  *_7958 = _7957;
  float4 _7959 = _7933[12];
  float4* _7960 = &_7934[12];
  *_7960 = _7959;
  float4 _7961 = _7933[13];
  float4* _7962 = &_7934[13];
  *_7962 = _7961;
  float4 _7963 = _7933[14];
  float4* _7964 = &_7934[14];
  *_7964 = _7963;
  float4 _7965 = _7933[15];
  float4* _7966 = &_7934[15];
  *_7966 = _7965;
  float4 _7967 = _7933[16];
  float4* _7968 = &_7934[16];
  *_7968 = _7967;
  float4 _7969 = _7933[17];
  float4* _7970 = &_7934[17];
  *_7970 = _7969;
  float4 _7971 = _7933[18];
  float4* _7972 = &_7934[18];
  *_7972 = _7971;
  float4 _7973 = _7933[19];
  float4* _7974 = &_7934[19];
  *_7974 = _7973;
  float4 _7975 = _7933[20];
  float4* _7976 = &_7934[20];
  *_7976 = _7975;
  float4 _7977 = _7933[21];
  float4* _7978 = &_7934[21];
  *_7978 = _7977;
  bool _7979 = *evaluateLine;
  
  if(_7979) {
    float* _7982 = &packed.rows[8].z;
    float _7983 = *_7982;
    bool _7984 = _7983 > 0.5000;
  }

  bool _7985 = Phi(_7979, _7984);
  
  if(_7985) {
    float4* _7989 = &packed.rows[9];
    float4 _7990 = *_7989;
    *uvTransform = _7990;
    float2 _7992 = *uv@25;
    float4 _7993 = *uvTransform;
    float2 _7994 = _7993.xy;
    float2 _7995 = _7992 * _7994;
    float4 _7996 = *uvTransform;
    float2 _7997 = _7996.zw;
    float2 _7998 = _7995 + _7997;
    *lineUv = _7998;
    bool _8000 = *integrated;
    
    if(_8000) {
      uint* _8004 = &material.textureBase;
      uint _8005 = *_8004;
      uint _8006 = _8005 + 8;
      uint _8007 = CopyObject(_8006) : [[NonUniform]];
      SampledImage<float, 2D>* _8008 = &textureArray[_8007] : [[NonUniform]];
      SampledImage<float, 2D> _8009 = *_8008 : [[NonUniform]];
      float2 _8010 = *lineUv;
      float2 _8011 = *projectedHairUvDx;
      float4 _8012 = *uvTransform;
      float2 _8013 = _8012.xy;
      float2 _8014 = _8011 * _8013;
      float2 _8015 = _8014 * 0.2500;
      float2 _8016 = *projectedHairUvDy;
      float4 _8017 = *uvTransform;
      float2 _8018 = _8017.xy;
      float2 _8019 = _8016 * _8018;
      float2 _8020 = _8019 * 0.2500;
      float4 _8021 = ImageSampleExplicitLod(_8009, _8010, Grad(_8015, _8020));
      float _8022 = _8021.x;
      *_8001 = _8022;
    } else {
      uint* _8024 = &material.textureBase;
      uint _8025 = *_8024;
      uint _8026 = _8025 + 8;
      uint _8027 = CopyObject(_8026) : [[NonUniform]];
      SampledImage<float, 2D>* _8028 = &textureArray[_8027] : [[NonUniform]];
      SampledImage<float, 2D> _8029 = *_8028 : [[NonUniform]];
      float2 _8030 = *lineUv;
      float4 _8031 = ImageSampleImplicitLod(_8029, _8030);
      float _8032 = _8031.x;
      *_8001 = _8032;
    }

    float _8033 = *_8001;
    *sampleValue@3 = _8033;
    float3 _8036 = *normal@21;
    *param@671 = _8036;
    float4 _8038 = *tangent@8;
    *param@672 = _8038;
    float* _8040 = &parameters@5.x;
    float _8041 = *_8040;
    *param@673 = _8041;
    float3 _8043 = *objectX@4;
    *param@674 = _8043;
    float3 _8045 = *objectY@4;
    *param@675 = _8045;
    float3 _8047 = *objectZ@4;
    *param@676 = _8047;
    float* _8049 = &p@10.edgeNormalDirection.z;
    float _8050 = *_8049;
    *param@677 = _8050;
    float3 _8051 = characterProjectedHairStrand(param@671, param@672, param@673, param@674, param@675, param@676, param@677);
    *strand@3 = _8051;
    float3 _8053 = *strand@3;
    *param@678 = _8053;
    float3 _8055 = *normal@21;
    *param@679 = _8055;
    float3 _8057 = *halfVector@6;
    *param@680 = _8057;
    float* _8059 = &uv@25.x;
    float _8060 = *_8059;
    *param@681 = _8060;
    float _8062 = *sampleValue@3;
    *param@682 = _8062;
    float* _8064 = &parameters@5.y;
    float _8065 = *_8064;
    *param@683 = _8065;
    float3* _8067 = &energy@5.q;
    float3 _8068 = *_8067;
    *param@684 = _8068;
    float4* _8070 = &packed.rows[7];
    float4 _8071 = *_8070;
    *param@685 = _8071;
    float4* _8073 = &packed.rows[8];
    float4 _8074 = *_8073;
    float2 _8075 = _8074.xy;
    *param@686 = _8075;
    float2 _8076 = characterProjectedHairLine(param@678, param@679, param@680, param@681, param@682, param@683, param@684, param@685, param@686);
    *line@3 = _8076;
  }

  bool _8077 = *virtualLight@2;
  
  if(_8077) {
    float* _8080 = &adapter.z;
    float _8081 = *_8080;
    float3* _8082 = &energy@5.primary;
    float3 _8083 = *_8082;
    float3 _8084 = _8083 * _8081;
    float3* _8085 = &energy@5.primary;
    *_8085 = _8084;
    float* _8086 = &adapter.z;
    float _8087 = *_8086;
    float3* _8088 = &energy@5.secondary;
    float3 _8089 = *_8088;
    float3 _8090 = _8089 * _8087;
    float3* _8091 = &energy@5.secondary;
    *_8091 = _8090;
  }

  bool _8092 = *integrated;
  
  if(_8092) {
    float* _8095 = &incident@5.response.x;
    float _8096 = *_8095;
    bool _8097 = _8096 > 0.5000;
  }

  bool _8098 = Phi(_8092, _8097);
  
  if(_8098) {
    float4 _8103 = *packedNormals;
    float2 _8104 = _8103.xy;
    *param@687 = _8104;
    float* _8106 = &p@10.edgeNormalDirection.w;
    float _8107 = *_8106;
    *param@688 = _8107;
    float3 _8109 = *basisNormal;
    *param@689 = _8109;
    float4 _8111 = *tangent@8;
    *param@690 = _8111;
    float3 _8112 = characterProjectedHairNormal(param@687, param@688, param@689, param@690);
    bool _8115 = *gl_FrontFacing;
    float _8116 = Select(_8115, 1.0000, -1.0000);
    float3 _8117 = _8112 * _8116;
    *surface@4 = _8117;
    float3 _8119 = *surface@4;
    float3 _8120 = *light@9;
    float _8121 = Dot(_8119, _8120);
    *cosine@2 = _8121;
    float* _8122 = &incident@5.response.x;
    float _8123 = *_8122;
    bool _8125 = _8123 > 2.5000;
    
    if(_8125) {
      float* _8129 = &incident@5.ambientOcclusion;
      float _8130 = *_8129;
      float* _8131 = &incident@5.characterVisibility;
      float _8132 = *_8131;
      float _8133 = _8130 * _8132;
      *ao = _8133;
      float* _8135 = &incident@5.response.w;
      float _8136 = *_8135;
      *visibility@12 = _8136;
      uint* _8138 = &material.textureBase;
      uint _8139 = *_8138;
      uint _8140 = _8139 + 4;
      uint _8141 = CopyObject(_8140) : [[NonUniform]];
      SampledImage<float, 2D>* _8142 = &textureArray[_8141] : [[NonUniform]];
      SampledImage<float, 2D> _8143 = *_8142 : [[NonUniform]];
      float _8144 = *cosine@2;
      float _8145 = _8144 * 0.5000;
      float _8146 = _8145 + 0.5000;
      float2 _8147 = CompositeConstruct({_8146, 0.5000});
      float4 _8148 = ImageSampleExplicitLod(_8143, _8147, Lod(0.0000));
      *diffuseRamp = _8148;
      uint* _8150 = &material.textureBase;
      uint _8151 = *_8150;
      uint _8152 = _8151 + 4;
      uint _8153 = CopyObject(_8152) : [[NonUniform]];
      SampledImage<float, 2D>* _8154 = &textureArray[_8153] : [[NonUniform]];
      SampledImage<float, 2D> _8155 = *_8154 : [[NonUniform]];
      float3 _8156 = *surface@4;
      float4* _8157 = &camera.cameraForward;
      float4 _8158 = *_8157;
      float3 _8159 = _8158.xyz;
      float3 _8160 = -_8159;
      float _8161 = Dot(_8156, _8160);
      float _8162 = _8161 * 0.5000;
      float _8163 = _8162 + 0.5000;
      float2 _8164 = CompositeConstruct({_8163, 0.5000});
      float4 _8165 = ImageSampleExplicitLod(_8155, _8164, Lod(0.0000));
      float _8166 = _8165.w;
      *viewAlpha@3 = _8166;
      float* _8168 = &parameters@5.z;
      float _8169 = *_8168;
      float _8170 = *ao;
      float _8171 = GLSL.std.450::FMin(_8169, _8170);
      float* _8172 = &diffuseRamp.w;
      float _8173 = *_8172;
      float _8174 = GLSL.std.450::FMin(_8171, _8173);
      *litMask@6 = _8174;
      float* _8176 = &parameters@5.z;
      float _8177 = *_8176;
      float _8178 = *ao;
      float _8179 = _8177 * _8178;
      *aoMask@5 = _8179;
      float* _8186 = &incident@5.ambientOcclusion;
      float _8187 = *_8186;
      float* _8189 = &camera.nprLightingParameters.z;
      float _8190 = *_8189;
      float _8191 = _8187 * _8190;
      float3 _8193 = *surface@4;
      *param@691 = _8193;
      float3* _8195 = &incident@5.radiance;
      float3 _8196 = *_8195;
      *param@692 = _8196;
      float4* _8198 = &incident@5.mainRadiance;
      float4 _8199 = *_8198;
      *param@693 = _8199;
      float4* _8201 = &camera.nprDirectionBias;
      float4 _8202 = *_8201;
      *param@694 = _8202;
      float4* _8204 = &camera.nprGainFloor;
      float4 _8205 = *_8204;
      *param@695 = _8205;
      float4* _8207 = &camera.nprComposition;
      float4 _8208 = *_8207;
      *param@696 = _8208;
      float* _8210 = &camera.nprAmbientColor.w;
      float _8211 = *_8210;
      *param@697 = _8211;
      *param@698 = _8191;
      float _8214 = *litMask@6;
      *param@699 = _8214;
      float _8216 = *visibility@12;
      *param@700 = _8216;
      CharacterDiffuseIllumination _8217 = characterDiffuseIllumination(param@691, param@692, param@693, param@694, param@695, param@696, param@697, param@698, param@699, param@700);
      *illumination@5 = _8217;
      float _8219 = *viewAlpha@3;
      float _8220 = *aoMask@5;
      float _8221 = _8219 * _8220;
      float _8222 = *litMask@6;
      float _8223 = *visibility@12;
      float _8224 = GLSL.std.450::FMix(_8221, _8222, _8223);
      *mask@2 = _8224;
      uint* _8226 = &material.materialPadding;
      uint _8227 = *_8226;
      uint _8228 = _8227 >> 1;
      float* _8229 = &materialSurfaceProfiles.profiles[_8228].rows[5].w;
      float _8230 = *_8229;
      float _8231 = *mask@2;
      float _8232 = GLSL.std.450::FMix(_8230, 1.0000, _8231);
      float _8233 = *mask@2;
      float _8234 = 0.5000 * _8233;
      float _8235 = 0.5000 + _8234;
      float _8236 = _8232 * _8235;
      *scale@5 = _8236;
      float3* _8238 = &illumination@5.ambient;
      float3 _8239 = *_8238;
      float3* _8240 = &illumination@5.direct;
      float3 _8241 = *_8240;
      float3 _8242 = _8239 + _8241;
      float _8243 = *scale@5;
      float* _8245 = &material.featureParameters.y;
      float _8246 = *_8245;
      float _8247 = _8243 * _8246;
      float3 _8248 = _8242 * _8247;
      *weight@10 = _8248;
    } else {
      float3* _8251 = &incident@5.radiance;
      float3 _8252 = *_8251;
      *radiance@8 = _8252;
      float* _8253 = &incident@5.response.x;
      float _8254 = *_8253;
      bool _8255 = _8254 > 1.5000;
      
      if(_8255) {
        float3 _8259 = *radiance@8;
        *param@701 = _8259;
        float _8261 = *cosine@2;
        *param@702 = _8261;
        float4* _8263 = &incident@5.response;
        float4 _8264 = *_8263;
        float2 _8265 = _8264.yz;
        *param@703 = _8265;
        float* _8267 = &incident@5.response.w;
        float _8268 = *_8267;
        *param@704 = _8268;
        float3 _8269 = characterLocalLightRadiance(param@701, param@702, param@703, param@704);
        *radiance@8 = _8269;
      }

      float3 _8270 = *radiance@8;
      float _8271 = *cosine@2;
      float _8272 = GLSL.std.450::FMax(_8271, 0.0000);
      float* _8273 = &incident@5.specularScale;
      float _8274 = *_8273;
      float _8275 = _8272 * _8274;
      float3 _8276 = _8270 * _8275;
      *weight@10 = _8276;
    }

    float3 _8277 = *weight@10;
    float3* _8278 = &energy@5.primary;
    float3 _8279 = *_8278;
    float3 _8280 = _8279 * _8277;
    float3* _8281 = &energy@5.primary;
    *_8281 = _8280;
    float3 _8282 = *weight@10;
    float3* _8283 = &energy@5.secondary;
    float3 _8284 = *_8283;
    float3 _8285 = _8284 * _8282;
    float3* _8286 = &energy@5.secondary;
    *_8286 = _8285;
  }

  CharacterProjectedHairEnergy _8287 = *energy@5;
  return _8287;
}

CharacterProjectedHairEnergy projectedHairResponseWeighted(float3* view@9, float3* light@10, bool* directional@4, bool* evaluateLine@2, ProjectedHairIncident* incident@6, float2* line@4) {
  bool* param@705;
  uint* param@706;
  float3* param@707;
  float3* param@708;
  bool* param@709;
  bool* param@710;
  float2* param@711;
  float2* param@712;
  bool* param@713;
  ProjectedHairIncident* param@714;
  float2* param@715;
  bool* temporalSamples;
  bool* param@716;
  uint* param@717;
  float3* param@718;
  float3* param@719;
  float3* param@720;
  float3* param@721;
  float3* param@722;
  float3* param@723;
  bool* param@724;
  bool* param@725;
  float2* param@726;
  float2* param@727;
  bool* param@728;
  ProjectedHairIncident* param@729;
  float2* param@730;
  CharacterProjectedHairEnergy* total@2;
  float2* lineMoments;
  int* y@5;
  int* x@6;
  float2* offset@11;
  bool* param@731;
  uint* param@732;
  float2* uv@26;
  CharacterProjectedHairEnergy* contribution@4;
  float2* modulation;
  float3* param@733;
  float3* param@734;
  bool* param@735;
  bool* param@736;
  float2* param@737;
  float2* param@738;
  bool* param@739;
  ProjectedHairIncident* param@740;
  float2* param@741;
  float* _8496;
  bool _8290 = !true;
  
  if(_8290) {
    uint* _8293 = &material.materialFeatures;
    uint _8294 = *_8293;
    uint _8297 = _8294 & _8296;
    uint _8299 = _8297 | azureFixedMaterialFeatureValue;
    *param@705 = azureOrdinaryOpaque;
    *param@706 = _8299;
    uint _8302 = azureSpecializedMaterialFeatures(param@705, param@706);
    uint _8303 = _8302 & 8388608;
    bool _8304 = _8303 == 0;
  }

  bool _8305 = Phi(true, _8304);
  
  if(_8305) {
    float3 _8311 = *view@9;
    *param@707 = _8311;
    float3 _8313 = *light@10;
    *param@708 = _8313;
    bool _8315 = *directional@4;
    *param@709 = _8315;
    bool _8317 = *evaluateLine@2;
    *param@710 = _8317;
    float2 _8319 = *textureCoordinate;
    *param@711 = _8319;
    *param@712 = {0.0000, 0.0000};
    *param@713 = false;
    ProjectedHairIncident _8323 = *incident@6;
    *param@714 = _8323;
    CharacterProjectedHairEnergy _8325 = projectedHairSample(param@707, param@708, param@709, param@710, param@711, param@712, param@713, param@714, param@715);
    float2 _8326 = *param@715;
    *line@4 = _8326;
    return _8325;
  }

  uint* _8329 = &material.materialFeatures;
  uint _8330 = *_8329;
  uint _8332 = _8330 & _8331;
  uint _8333 = _8332 | azureFixedMaterialFeatureValue;
  *param@716 = azureOrdinaryOpaque;
  *param@717 = _8333;
  uint _8336 = azureSpecializedMaterialFeatures(param@716, param@717);
  uint _8337 = _8336 & 2147483648;
  bool _8338 = _8337 != 0;
  *temporalSamples = _8338;
  bool _8339 = *temporalSamples;
  
  if(_8339) {
    float3 _8343 = *projectedHairNormalDx;
    *param@718 = _8343;
    float3 _8345 = *projectedHairNormalDy;
    *param@719 = _8345;
    float4 _8347 = *projectedHairTangentDx;
    float3 _8348 = _8347.xyz;
    *param@720 = _8348;
    float4 _8350 = *projectedHairTangentDy;
    float3 _8351 = _8350.xyz;
    *param@721 = _8351;
    bool _8352 = azureUniformMaterialFrame(param@718, param@719, param@720, param@721);
    bool _8353 = !_8352;
  }

  bool _8354 = Phi(_8339, _8353);
  
  if(_8354) {
    float3 _8358 = *view@9;
    *param@722 = _8358;
    float3 _8360 = *light@10;
    *param@723 = _8360;
    bool _8362 = *directional@4;
    *param@724 = _8362;
    bool _8364 = *evaluateLine@2;
    *param@725 = _8364;
    float2 _8366 = *textureCoordinate;
    *param@726 = _8366;
    *param@727 = {0.0000, 0.0000};
    *param@728 = true;
    ProjectedHairIncident _8370 = *incident@6;
    *param@729 = _8370;
    CharacterProjectedHairEnergy _8372 = projectedHairSample(param@722, param@723, param@724, param@725, param@726, param@727, param@728, param@729, param@730);
    float2 _8373 = *param@730;
    *line@4 = _8373;
    return _8372;
  }

  *total@2 = _8376;
  *lineMoments = {0.0000, 0.0000};
  *y@5 = 0;

  while(true) {
    int _8384 = *y@5;
    bool _8385 = _8384 < 4;
    if(!_8385) break;
    *x@6 = 0;

    while(true) {
      int _8392 = *x@6;
      bool _8393 = _8392 < 4;
      if(!_8393) break;
      int _8395 = *x@6;
      float _8396 = ConvertSToF(_8395);
      int _8397 = *y@5;
      float _8398 = ConvertSToF(_8397);
      float2 _8399 = CompositeConstruct({_8396, _8398});
      float2 _8400 = CompositeConstruct({0.5000, 0.5000});
      float2 _8401 = _8399 + _8400;
      float2 _8402 = _8401 * 0.2500;
      float2 _8403 = CompositeConstruct({0.5000, 0.5000});
      float2 _8404 = _8402 - _8403;
      *offset@11 = _8404;
      uint* _8405 = &material.materialFeatures;
      uint _8406 = *_8405;
      uint _8408 = _8406 & _8407;
      uint _8409 = _8408 | azureFixedMaterialFeatureValue;
      *param@731 = azureOrdinaryOpaque;
      *param@732 = _8409;
      uint _8412 = azureSpecializedMaterialFeatures(param@731, param@732);
      uint _8413 = _8412 & 2147483648;
      bool _8414 = _8413 != 0;
      
      if(_8414) {
        float* _8417 = &camera.cameraRight.w;
        float _8418 = *_8417;
        float* _8419 = &camera.cameraUp.w;
        float _8420 = *_8419;
        float2 _8421 = CompositeConstruct({_8418, _8420});
        float2 _8422 = *offset@11;
        float2 _8423 = _8422 + _8421;
        *offset@11 = _8423;
      }

      float2 _8425 = *textureCoordinate;
      float2 _8426 = *projectedHairUvDx;
      float* _8427 = &offset@11.x;
      float _8428 = *_8427;
      float2 _8429 = _8426 * _8428;
      float2 _8430 = _8425 + _8429;
      float2 _8431 = *projectedHairUvDy;
      float* _8432 = &offset@11.y;
      float _8433 = *_8432;
      float2 _8434 = _8431 * _8433;
      float2 _8435 = _8430 + _8434;
      *uv@26 = _8435;
      float3 _8439 = *view@9;
      *param@733 = _8439;
      float3 _8441 = *light@10;
      *param@734 = _8441;
      bool _8443 = *directional@4;
      *param@735 = _8443;
      bool _8445 = *evaluateLine@2;
      *param@736 = _8445;
      float2 _8447 = *uv@26;
      *param@737 = _8447;
      float2 _8449 = *offset@11;
      *param@738 = _8449;
      *param@739 = true;
      ProjectedHairIncident _8452 = *incident@6;
      *param@740 = _8452;
      CharacterProjectedHairEnergy _8454 = projectedHairSample(param@733, param@734, param@735, param@736, param@737, param@738, param@739, param@740, param@741);
      float2 _8455 = *param@741;
      *modulation = _8455;
      *contribution@4 = _8454;
      float3* _8456 = &contribution@4.q;
      float3 _8457 = *_8456;
      float3* _8458 = &total@2.q;
      float3 _8459 = *_8458;
      float3 _8460 = _8459 + _8457;
      float3* _8461 = &total@2.q;
      *_8461 = _8460;
      float3* _8462 = &contribution@4.primary;
      float3 _8463 = *_8462;
      float3* _8464 = &total@2.primary;
      float3 _8465 = *_8464;
      float3 _8466 = _8465 + _8463;
      float3* _8467 = &total@2.primary;
      *_8467 = _8466;
      float3* _8468 = &contribution@4.secondary;
      float3 _8469 = *_8468;
      float3* _8470 = &total@2.secondary;
      float3 _8471 = *_8470;
      float3 _8472 = _8471 + _8469;
      float3* _8473 = &total@2.secondary;
      *_8473 = _8472;
      float* _8474 = &modulation.x;
      float _8475 = *_8474;
      float* _8476 = &modulation.x;
      float _8477 = *_8476;
      float* _8478 = &modulation.y;
      float _8479 = *_8478;
      float _8480 = _8477 * _8479;
      float2 _8481 = CompositeConstruct({_8475, _8480});
      float2 _8482 = *lineMoments;
      float2 _8483 = _8482 + _8481;
      *lineMoments = _8483;
      int _8484 = *x@6;
      int _8485 = _8484 + 1;
      *x@6 = _8485;
    }

    int _8486 = *y@5;
    int _8487 = _8486 + 1;
    *y@5 = _8487;
  }

  float* _8488 = &lineMoments.x;
  float _8489 = *_8488;
  float _8490 = _8489 * 0.0625;
  float* _8491 = &lineMoments.x;
  float _8492 = *_8491;
  float _8493 = GLSL.std.450::FAbs(_8492);
  bool _8495 = _8493 > 0.0000;
  
  if(_8495) {
    float* _8499 = &lineMoments.y;
    float _8500 = *_8499;
    float* _8501 = &lineMoments.x;
    float _8502 = *_8501;
    float _8503 = _8500 / _8502;
    *_8496 = _8503;
  } else {
    *_8496 = 1.0000;
  }

  float _8505 = *_8496;
  float2 _8506 = CompositeConstruct({_8490, _8505});
  *line@4 = _8506;
  float3* _8507 = &total@2.q;
  float3 _8508 = *_8507;
  float3 _8509 = _8508 * 0.0625;
  float3* _8510 = &total@2.q;
  *_8510 = _8509;
  float3* _8511 = &total@2.primary;
  float3 _8512 = *_8511;
  float3 _8513 = _8512 * 0.0625;
  float3* _8514 = &total@2.primary;
  *_8514 = _8513;
  float3* _8515 = &total@2.secondary;
  float3 _8516 = *_8515;
  float3 _8517 = _8516 * 0.0625;
  float3* _8518 = &total@2.secondary;
  *_8518 = _8517;
  CharacterProjectedHairEnergy _8519 = *total@2;
  return _8519;
}

CharacterProjectedHairEnergy projectedHairResponse(float3* view@10, float3* light@11, bool* directional@5, bool* evaluateLine@3, float2* line@5) {
  float3* param@742;
  float3* param@743;
  bool* param@744;
  bool* param@745;
  ProjectedHairIncident* param@746;
  float2* param@747;
  float3 _8524 = *view@10;
  *param@742 = _8524;
  float3 _8526 = *light@11;
  *param@743 = _8526;
  bool _8528 = *directional@5;
  *param@744 = _8528;
  bool _8530 = *evaluateLine@3;
  *param@745 = _8530;
  *param@746 = _8522;
  CharacterProjectedHairEnergy _8533 = projectedHairResponseWeighted(param@742, param@743, param@744, param@745, param@746, param@747);
  float2 _8534 = *param@747;
  *line@5 = _8534;
  return _8533;
}

CharacterProjectedHairEnergy projectedHairDirect(float3* view@11, float3* light@12, bool* directional@6) {
  float2* line@6;
  float3* param@748;
  float3* param@749;
  bool* param@750;
  bool* param@751;
  float2* param@752;
  float3 _8539 = *view@11;
  *param@748 = _8539;
  float3 _8541 = *light@12;
  *param@749 = _8541;
  bool _8543 = *directional@6;
  *param@750 = _8543;
  *param@751 = false;
  CharacterProjectedHairEnergy _8546 = projectedHairResponse(param@748, param@749, param@750, param@751, param@752);
  float2 _8547 = *param@752;
  *line@6 = _8547;
  return _8546;
}

CharacterDiffuseResponse projectedHairDiffuseResponse(float3* base@12, float3* normal@22, float3* light@13, float* ao@2, float* visibility@13, float* viewAlpha@4) {
  PackedMaterialSurfaceProfile* profile@4;
  float4* ramp@13;
  float* characterVisibility@2;
  bool* param@753;
  uint* param@754;
  float* _8648;
  float* litMask@7;
  float* aoMask@6;
  float3* shadow@5;
  float3* param@755;
  float* param@756;
  CharacterDiffuseResponse* response@5;
  float3* param@757;
  float3* param@758;
  float* param@759;
  float* param@760;
  float4* param@761;
  float* param@762;
  float* param@763;
  float* param@764;
  float* param@765;
  uint* _8551 = &material.materialPadding;
  uint _8552 = *_8551;
  uint _8553 = _8552 >> 1;
  PackedMaterialSurfaceProfile* _8554 = &materialSurfaceProfiles.profiles[_8553];
  PackedMaterialSurfaceProfile _8555 = *_8554;
  float4[22] _8556 = _8555.rows;
  float4[22]* _8557 = &profile@4.rows;
  float4 _8558 = _8556[0];
  float4* _8559 = &_8557[0];
  *_8559 = _8558;
  float4 _8560 = _8556[1];
  float4* _8561 = &_8557[1];
  *_8561 = _8560;
  float4 _8562 = _8556[2];
  float4* _8563 = &_8557[2];
  *_8563 = _8562;
  float4 _8564 = _8556[3];
  float4* _8565 = &_8557[3];
  *_8565 = _8564;
  float4 _8566 = _8556[4];
  float4* _8567 = &_8557[4];
  *_8567 = _8566;
  float4 _8568 = _8556[5];
  float4* _8569 = &_8557[5];
  *_8569 = _8568;
  float4 _8570 = _8556[6];
  float4* _8571 = &_8557[6];
  *_8571 = _8570;
  float4 _8572 = _8556[7];
  float4* _8573 = &_8557[7];
  *_8573 = _8572;
  float4 _8574 = _8556[8];
  float4* _8575 = &_8557[8];
  *_8575 = _8574;
  float4 _8576 = _8556[9];
  float4* _8577 = &_8557[9];
  *_8577 = _8576;
  float4 _8578 = _8556[10];
  float4* _8579 = &_8557[10];
  *_8579 = _8578;
  float4 _8580 = _8556[11];
  float4* _8581 = &_8557[11];
  *_8581 = _8580;
  float4 _8582 = _8556[12];
  float4* _8583 = &_8557[12];
  *_8583 = _8582;
  float4 _8584 = _8556[13];
  float4* _8585 = &_8557[13];
  *_8585 = _8584;
  float4 _8586 = _8556[14];
  float4* _8587 = &_8557[14];
  *_8587 = _8586;
  float4 _8588 = _8556[15];
  float4* _8589 = &_8557[15];
  *_8589 = _8588;
  float4 _8590 = _8556[16];
  float4* _8591 = &_8557[16];
  *_8591 = _8590;
  float4 _8592 = _8556[17];
  float4* _8593 = &_8557[17];
  *_8593 = _8592;
  float4 _8594 = _8556[18];
  float4* _8595 = &_8557[18];
  *_8595 = _8594;
  float4 _8596 = _8556[19];
  float4* _8597 = &_8557[19];
  *_8597 = _8596;
  float4 _8598 = _8556[20];
  float4* _8599 = &_8557[20];
  *_8599 = _8598;
  float4 _8600 = _8556[21];
  float4* _8601 = &_8557[21];
  *_8601 = _8600;
  uint* _8603 = &material.textureBase;
  uint _8604 = *_8603;
  uint _8605 = _8604 + 4;
  uint _8606 = CopyObject(_8605) : [[NonUniform]];
  SampledImage<float, 2D>* _8607 = &textureArray[_8606] : [[NonUniform]];
  SampledImage<float, 2D> _8608 = *_8607 : [[NonUniform]];
  float3 _8609 = *normal@22;
  float3 _8610 = *light@13;
  float _8611 = Dot(_8609, _8610);
  float _8612 = _8611 * 0.5000;
  float _8613 = _8612 + 0.5000;
  float2 _8614 = CompositeConstruct({_8613, 0.5000});
  float4 _8615 = ImageSampleExplicitLod(_8608, _8614, Lod(0.0000));
  *ramp@13 = _8615;
  uint* _8616 = &material.textureBase;
  uint _8617 = *_8616;
  uint _8618 = _8617 + 4;
  uint _8619 = CopyObject(_8618) : [[NonUniform]];
  SampledImage<float, 2D>* _8620 = &textureArray[_8619] : [[NonUniform]];
  SampledImage<float, 2D> _8621 = *_8620 : [[NonUniform]];
  float3 _8622 = *normal@22;
  float4* _8623 = &camera.cameraForward;
  float4 _8624 = *_8623;
  float3 _8625 = _8624.xyz;
  float3 _8626 = -_8625;
  float _8627 = Dot(_8622, _8626);
  float _8628 = _8627 * 0.5000;
  float _8629 = _8628 + 0.5000;
  float2 _8630 = CompositeConstruct({_8629, 0.5000});
  float4 _8631 = ImageSampleExplicitLod(_8621, _8630, Lod(0.0000));
  float _8632 = _8631.w;
  *viewAlpha@4 = _8632;
  
  if(false) {
    uint* _8636 = &material.materialFeatures;
    uint _8637 = *_8636;
    uint _8639 = _8637 & _8638;
    uint _8640 = _8639 | azureFixedMaterialFeatureValue;
    *param@753 = azureOrdinaryOpaque;
    *param@754 = _8640;
    uint _8643 = azureSpecializedMaterialFeatures(param@753, param@754);
    uint _8645 = _8643 & 2155872256;
    bool _8646 = _8645 == 2155872256;
  }

  bool _8647 = Phi(false, _8646);
  
  if(_8647) {
    uint* _8651 = &material.textureBase;
    uint _8652 = *_8651;
    uint _8653 = _8652 + 7;
    uint _8654 = CopyObject(_8653) : [[NonUniform]];
    SampledImage<float, 2D>* _8655 = &textureArray[_8654] : [[NonUniform]];
    SampledImage<float, 2D> _8656 = *_8655 : [[NonUniform]];
    float2 _8657 = *textureCoordinate;
    float2 _8658 = *projectedHairUvDx;
    float2 _8659 = _8658 * 0.2500;
    float2 _8660 = *projectedHairUvDy;
    float2 _8661 = _8660 * 0.2500;
    float4 _8662 = ImageSampleExplicitLod(_8656, _8657, Grad(_8659, _8661));
    float _8663 = _8662.z;
    *_8648 = _8663;
  } else {
    uint* _8665 = &material.textureBase;
    uint _8666 = *_8665;
    uint _8667 = _8666 + 7;
    uint _8668 = CopyObject(_8667) : [[NonUniform]];
    SampledImage<float, 2D>* _8669 = &textureArray[_8668] : [[NonUniform]];
    SampledImage<float, 2D> _8670 = *_8669 : [[NonUniform]];
    float2 _8671 = *textureCoordinate;
    float4 _8672 = ImageSampleImplicitLod(_8670, _8671);
    float _8673 = _8672.z;
    *_8648 = _8673;
  }

  float _8674 = *_8648;
  *characterVisibility@2 = _8674;
  float _8676 = *characterVisibility@2;
  float _8677 = *ao@2;
  float _8678 = GLSL.std.450::FMin(_8676, _8677);
  float* _8679 = &ramp@13.w;
  float _8680 = *_8679;
  float _8681 = GLSL.std.450::FMin(_8678, _8680);
  *litMask@7 = _8681;
  float _8683 = *characterVisibility@2;
  float _8684 = *ao@2;
  float _8685 = _8683 * _8684;
  *aoMask@6 = _8685;
  float3 _8687 = *base@12;
  float* _8688 = &profile@4.rows[10].w;
  float _8689 = *_8688;
  float3 _8690 = _8687 * _8689;
  *param@755 = _8690;
  float* _8693 = &profile@4.rows[11].w;
  float _8694 = *_8693;
  *param@756 = _8694;
  float3 _8695 = characterDiffuseSaturation(param@755, param@756);
  *shadow@5 = _8695;
  float _8698 = *viewAlpha@4;
  float _8699 = *aoMask@6;
  float _8700 = _8698 * _8699;
  float* _8701 = &ramp@13.w;
  float _8702 = *_8701;
  float _8703 = _8700 + _8702;
  float _8704 = GLSL.std.450::FClamp(_8703, 0.0000, 1.0000);
  float3 _8706 = *base@12;
  *param@757 = _8706;
  float3 _8708 = *shadow@5;
  *param@758 = _8708;
  *param@759 = 0.0000;
  float* _8711 = &profile@4.rows[5].w;
  float _8712 = *_8711;
  *param@760 = _8712;
  float4 _8714 = *ramp@13;
  *param@761 = _8714;
  float _8716 = *litMask@7;
  *param@762 = _8716;
  float _8718 = *aoMask@6;
  *param@763 = _8718;
  *param@764 = _8704;
  float _8721 = *visibility@13;
  *param@765 = _8721;
  CharacterDiffuseResponse _8722 = characterDiffuseWeightedResponse(param@757, param@758, param@759, param@760, param@761, param@762, param@763, param@764, param@765);
  *response@5 = _8722;
  float* _8723 = &profile@4.rows[3].w;
  float _8724 = *_8723;
  float _8725 = _8724 / 0.9600;
  float3* _8726 = &response@5.color;
  float3 _8727 = *_8726;
  float3 _8728 = _8727 * _8725;
  float3* _8729 = &response@5.color;
  *_8729 = _8728;
  CharacterDiffuseResponse _8730 = *response@5;
  return _8730;
}

float2 directionToEquirectangular(float3* direction@6) {
  float3* normalizedDirection;
  float3 _8734 = *direction@6;
  float3 _8735 = GLSL.std.450::Normalize(_8734);
  *normalizedDirection = _8735;
  float* _8736 = &normalizedDirection.z;
  float _8737 = *_8736;
  float* _8738 = &normalizedDirection.x;
  float _8739 = *_8738;
  float _8740 = GLSL.std.450::Atan2(_8737, _8739);
  float _8742 = _8740 / 6.2832;
  float _8743 = _8742 + 0.5000;
  float* _8744 = &normalizedDirection.y;
  float _8745 = *_8744;
  float _8746 = GLSL.std.450::FClamp(_8745, -1.0000, 1.0000);
  float _8747 = GLSL.std.450::Acos(_8746);
  float _8748 = _8747 / 3.1416;
  float2 _8749 = CompositeConstruct({_8743, _8748});
  return _8749;
}

float3 decodePackedHairNormal(float2* encodedNormal) {
  float2* xy@3;
  float* z@2;
  float* _8753 = &encodedNormal.x;
  float _8754 = *_8753;
  float _8755 = _8754 * 2.0000;
  float _8756 = _8755 - 1.0000;
  float* _8757 = &encodedNormal.y;
  float _8758 = *_8757;
  float _8759 = _8758 * 2.0000;
  float _8760 = 1.0000 - _8759;
  float2 _8761 = CompositeConstruct({_8756, _8760});
  *xy@3 = _8761;
  float2 _8763 = *xy@3;
  float2 _8764 = *xy@3;
  float _8765 = Dot(_8763, _8764);
  float _8766 = 1.0000 - _8765;
  float _8767 = GLSL.std.450::FMax(_8766, 0.0010);
  float _8768 = GLSL.std.450::Sqrt(_8767);
  *z@2 = _8768;
  float2 _8769 = *xy@3;
  float _8770 = *z@2;
  float _8771 = _8769.x;
  float _8772 = _8769.y;
  float3 _8773 = CompositeConstruct({_8771, _8772, _8770});
  float3 _8774 = GLSL.std.450::Normalize(_8773);
  return _8774;
}

float3 materialClassColor(uint* materialClass@3) {
  float3[10]* indexable@4;
  uint _8801 = *materialClass@3;
  uint _8803 = GLSL.std.450::UMin(_8801, 9);
  *indexable@4 = _8800;
  float3* _8806 = &indexable@4[_8803];
  float3 _8807 = *_8806;
  return _8807;
}

float materialFeatureEnabled(uint* feature) {
  bool* param@766;
  uint* param@767;
  uint* _8810 = &material.materialFeatures;
  uint _8811 = *_8810;
  uint _8813 = _8811 & _8812;
  uint _8814 = _8813 | azureFixedMaterialFeatureValue;
  *param@766 = azureOrdinaryOpaque;
  *param@767 = _8814;
  uint _8817 = azureSpecializedMaterialFeatures(param@766, param@767);
  uint _8818 = *feature;
  uint _8819 = _8817 & _8818;
  bool _8820 = _8819 != 0;
  float _8821 = Select(_8820, 1.0000, 0.0000);
  return _8821;
}

float3 sampleToonRamp(float* coordinate@4) {
  float2* atlasSize;
  float* minimumU;
  float* maximumU;
  float* row;
  uint* _8838;
  uint* _8845;
  float2* uv@27;
  SampledImage<float, 2D>* _8825 = &textureArray[1];
  SampledImage<float, 2D> _8826 = *_8825;
  Image<float, 2D> _8827 = Image(_8826);
  int2 _8828 = ImageQuerySizeLod(_8827, 0);
  float2 _8829 = ConvertSToF(_8828);
  *atlasSize = _8829;
  float* _8831 = &atlasSize.x;
  float _8832 = *_8831;
  float _8833 = 0.5000 / _8832;
  *minimumU = _8833;
  float _8835 = *minimumU;
  float _8836 = 1.0000 - _8835;
  *maximumU = _8836;
  
  if(azureOrdinaryOpaque) {
    *_8838 = 0;
  } else {
    
    if(_8844) {
      *_8845 = azureFixedMaterialClass;
    } else {
      uint* _8849 = &material.materialClass;
      uint _8850 = *_8849;
      *_8845 = _8850;
    }

    uint _8851 = *_8845;
    *_8838 = _8851;
  }

  uint _8852 = *_8838;
  uint _8853 = GLSL.std.450::UMin(_8852, 9);
  float _8854 = ConvertUToF(_8853);
  *row = _8854;
  float _8856 = *minimumU;
  float _8857 = *maximumU;
  float _8858 = *coordinate@4;
  float _8859 = GLSL.std.450::FClamp(_8858, 0.0000, 1.0000);
  float _8860 = GLSL.std.450::FMix(_8856, _8857, _8859);
  float _8861 = *row;
  float _8862 = _8861 + 0.5000;
  float* _8863 = &atlasSize.y;
  float _8864 = *_8863;
  float _8865 = _8862 / _8864;
  float2 _8866 = CompositeConstruct({_8860, _8865});
  *uv@27 = _8866;
  SampledImage<float, 2D>* _8867 = &textureArray[1];
  SampledImage<float, 2D> _8868 = *_8867;
  float2 _8869 = *uv@27;
  float4 _8870 = ImageSampleImplicitLod(_8868, _8869);
  float3 _8871 = _8870.xyz;
  return _8871;
}

float3 materialDiffuseRamp(float* coordinate@5) {
  uint* param@768;
  float* width@3;
  float* param@769;
  *param@768 = 8192;
  float _8876 = materialFeatureEnabled(param@768);
  bool _8877 = _8876 > 0.5000;
  
  if(_8877) {
    uint* _8881 = &material.textureBase;
    uint _8882 = *_8881;
    uint _8883 = _8882 + 4;
    uint _8884 = CopyObject(_8883) : [[NonUniform]];
    SampledImage<float, 2D>* _8885 = &textureArray[_8884] : [[NonUniform]];
    SampledImage<float, 2D> _8886 = *_8885 : [[NonUniform]];
    Image<float, 2D> _8887 = Image(_8886) : [[NonUniform]];
    int2 _8888 = ImageQuerySizeLod(_8887, 0);
    int _8889 = _8888.x;
    float _8890 = ConvertSToF(_8889);
    *width@3 = _8890;
    uint* _8891 = &material.textureBase;
    uint _8892 = *_8891;
    uint _8893 = _8892 + 4;
    uint _8894 = CopyObject(_8893) : [[NonUniform]];
    SampledImage<float, 2D>* _8895 = &textureArray[_8894] : [[NonUniform]];
    SampledImage<float, 2D> _8896 = *_8895 : [[NonUniform]];
    float _8897 = *coordinate@5;
    float _8898 = GLSL.std.450::FClamp(_8897, 0.0000, 1.0000);
    float _8899 = *width@3;
    float _8900 = _8899 - 1.0000;
    float _8901 = _8898 * _8900;
    float _8902 = _8901 + 0.5000;
    float _8903 = *width@3;
    float _8904 = _8902 / _8903;
    float2 _8905 = CompositeConstruct({_8904, 0.5000});
    float4 _8906 = ImageSampleExplicitLod(_8896, _8905, Lod(0.0000));
    float3 _8907 = _8906.xyz;
    return _8907;
  }

  float _8910 = *coordinate@5;
  *param@769 = _8910;
  float3 _8911 = sampleToonRamp(param@769);
  return _8911;
}

float4 materialDiffuseRampRgba(float* coordinate@6) {
  uint* param@770;
  float* width@4;
  float* param@771;
  *param@770 = 8192;
  float _8915 = materialFeatureEnabled(param@770);
  bool _8916 = _8915 > 0.5000;
  
  if(_8916) {
    uint* _8920 = &material.textureBase;
    uint _8921 = *_8920;
    uint _8922 = _8921 + 4;
    uint _8923 = CopyObject(_8922) : [[NonUniform]];
    SampledImage<float, 2D>* _8924 = &textureArray[_8923] : [[NonUniform]];
    SampledImage<float, 2D> _8925 = *_8924 : [[NonUniform]];
    Image<float, 2D> _8926 = Image(_8925) : [[NonUniform]];
    int2 _8927 = ImageQuerySizeLod(_8926, 0);
    int _8928 = _8927.x;
    float _8929 = ConvertSToF(_8928);
    *width@4 = _8929;
    uint* _8930 = &material.textureBase;
    uint _8931 = *_8930;
    uint _8932 = _8931 + 4;
    uint _8933 = CopyObject(_8932) : [[NonUniform]];
    SampledImage<float, 2D>* _8934 = &textureArray[_8933] : [[NonUniform]];
    SampledImage<float, 2D> _8935 = *_8934 : [[NonUniform]];
    float _8936 = *coordinate@6;
    float _8937 = GLSL.std.450::FClamp(_8936, 0.0000, 1.0000);
    float _8938 = *width@4;
    float _8939 = _8938 - 1.0000;
    float _8940 = _8937 * _8939;
    float _8941 = _8940 + 0.5000;
    float _8942 = *width@4;
    float _8943 = _8941 / _8942;
    float2 _8944 = CompositeConstruct({_8943, 0.5000});
    float4 _8945 = ImageSampleExplicitLod(_8935, _8944, Lod(0.0000));
    return _8945;
  }

  float _8948 = *coordinate@6;
  *param@771 = _8948;
  float3 _8949 = materialDiffuseRamp(param@771);
  float _8950 = _8949.x;
  float _8951 = _8949.y;
  float _8952 = _8949.z;
  float4 _8953 = CompositeConstruct({_8950, _8951, _8952, 1.0000});
  return _8953;
}

float3 materialNprLitAlbedo(float3* base@13, float3* normal@23, float3* view@12) {
  uint* profileIndex;
  float4* tint@4;
  float3* param@772;
  float3* param@773;
  float3* param@774;
  float4* param@775;
  uint* _8957 = &material.materialPadding;
  uint _8958 = *_8957;
  uint _8959 = _8958 >> 1;
  *profileIndex = _8959;
  uint _8961 = *profileIndex;
  float4* _8962 = &materialSurfaceProfiles.profiles[_8961].rows[2];
  float4 _8963 = *_8962;
  *tint@4 = _8963;
  float3 _8965 = *base@13;
  *param@772 = _8965;
  float3 _8967 = *normal@23;
  *param@773 = _8967;
  float3 _8969 = *view@12;
  *param@774 = _8969;
  float4 _8971 = *tint@4;
  *param@775 = _8971;
  float3 _8972 = characterDiffuseViewTint(param@772, param@773, param@774, param@775);
  return _8972;
}

CharacterDiffuseResponse materialNprDiffuseResponse(float4* base@14, float* metallic@6, float4* ramp@14, float* baseAo@2, float* visibility@14, float* mainShadow@2, float3* normal@24, float3* view@13) {
  PackedMaterialSurfaceProfile* profile@5;
  float4* parameters@6;
  float2* mask@3;
  float2* _9034;
  float2* _9041;
  float3* shadow@6;
  uint* param@776;
  float3* _9061;
  float3* param@777;
  float3* param@778;
  float* param@779;
  float3* shadowNormal;
  float3* _9100;
  float* characterVisibility@3;
  uint* param@780;
  float3* param@781;
  float* param@782;
  float* param@783;
  float3* param@784;
  float3* param@785;
  float3* param@786;
  float3* param@787;
  float3* param@788;
  float* param@789;
  float* param@790;
  float4* param@791;
  float* param@792;
  float2* param@793;
  float* param@794;
  float* param@795;
  float* param@796;
  uint* _8976 = &material.materialPadding;
  uint _8977 = *_8976;
  uint _8978 = _8977 >> 1;
  PackedMaterialSurfaceProfile* _8979 = &materialSurfaceProfiles.profiles[_8978];
  PackedMaterialSurfaceProfile _8980 = *_8979;
  float4[22] _8981 = _8980.rows;
  float4[22]* _8982 = &profile@5.rows;
  float4 _8983 = _8981[0];
  float4* _8984 = &_8982[0];
  *_8984 = _8983;
  float4 _8985 = _8981[1];
  float4* _8986 = &_8982[1];
  *_8986 = _8985;
  float4 _8987 = _8981[2];
  float4* _8988 = &_8982[2];
  *_8988 = _8987;
  float4 _8989 = _8981[3];
  float4* _8990 = &_8982[3];
  *_8990 = _8989;
  float4 _8991 = _8981[4];
  float4* _8992 = &_8982[4];
  *_8992 = _8991;
  float4 _8993 = _8981[5];
  float4* _8994 = &_8982[5];
  *_8994 = _8993;
  float4 _8995 = _8981[6];
  float4* _8996 = &_8982[6];
  *_8996 = _8995;
  float4 _8997 = _8981[7];
  float4* _8998 = &_8982[7];
  *_8998 = _8997;
  float4 _8999 = _8981[8];
  float4* _9000 = &_8982[8];
  *_9000 = _8999;
  float4 _9001 = _8981[9];
  float4* _9002 = &_8982[9];
  *_9002 = _9001;
  float4 _9003 = _8981[10];
  float4* _9004 = &_8982[10];
  *_9004 = _9003;
  float4 _9005 = _8981[11];
  float4* _9006 = &_8982[11];
  *_9006 = _9005;
  float4 _9007 = _8981[12];
  float4* _9008 = &_8982[12];
  *_9008 = _9007;
  float4 _9009 = _8981[13];
  float4* _9010 = &_8982[13];
  *_9010 = _9009;
  float4 _9011 = _8981[14];
  float4* _9012 = &_8982[14];
  *_9012 = _9011;
  float4 _9013 = _8981[15];
  float4* _9014 = &_8982[15];
  *_9014 = _9013;
  float4 _9015 = _8981[16];
  float4* _9016 = &_8982[16];
  *_9016 = _9015;
  float4 _9017 = _8981[17];
  float4* _9018 = &_8982[17];
  *_9018 = _9017;
  float4 _9019 = _8981[18];
  float4* _9020 = &_8982[18];
  *_9020 = _9019;
  float4 _9021 = _8981[19];
  float4* _9022 = &_8982[19];
  *_9022 = _9021;
  float4 _9023 = _8981[20];
  float4* _9024 = &_8982[20];
  *_9024 = _9023;
  float4 _9025 = _8981[21];
  float4* _9026 = &_8982[21];
  *_9026 = _9025;
  float4* _9028 = &profile@5.rows[0];
  float4 _9029 = *_9028;
  *parameters@6 = _9029;
  float* _9031 = &parameters@6.y;
  float _9032 = *_9031;
  bool _9033 = _9032 > 1.5000;
  
  if(_9033) {
    *_9034 = {1.0000, 0.0000};
  } else {
    float* _9038 = &parameters@6.y;
    float _9039 = *_9038;
    bool _9040 = _9039 > 0.5000;
    
    if(_9040) {
      uint* _9044 = &material.textureBase;
      uint _9045 = *_9044;
      uint _9046 = _9045 + 4;
      uint _9047 = CopyObject(_9046) : [[NonUniform]];
      SampledImage<float, 2D>* _9048 = &textureArray[_9047] : [[NonUniform]];
      SampledImage<float, 2D> _9049 = *_9048 : [[NonUniform]];
      float2 _9050 = *textureCoordinate;
      float4 _9051 = ImageSampleExplicitLod(_9049, _9050, Lod(0.0000));
      float2 _9052 = _9051.yz;
      *_9041 = _9052;
    } else {
      *_9041 = {0.0000, 0.0000};
    }

    float2 _9054 = *_9041;
    *_9034 = _9054;
  }

  float2 _9055 = *_9034;
  *mask@3 = _9055;
  *param@776 = 4096;
  float _9059 = materialFeatureEnabled(param@776);
  bool _9060 = _9059 > 0.5000;
  
  if(_9060) {
    uint* _9064 = &material.textureBase;
    uint _9065 = *_9064;
    uint _9066 = _9065 + 8;
    uint _9067 = CopyObject(_9066) : [[NonUniform]];
    SampledImage<float, 2D>* _9068 = &textureArray[_9067];
    float4 _9070 = *base@14;
    float3 _9071 = _9070.xyz;
    *param@777 = _9071;
    float3 _9072 = sampleShadowColorLut(_9068, param@777);
    *_9061 = _9072;
  } else {
    float4 _9074 = *base@14;
    float3 _9075 = _9074.xyz;
    *_9061 = _9075;
  }

  float3 _9076 = *_9061;
  *shadow@6 = _9076;
  float* _9077 = &profile@5.rows[6].x;
  float _9078 = *_9077;
  float _9079 = GLSL.std.450::FAbs(_9078);
  bool _9080 = _9079 > 0.0000;
  
  if(_9080) {
    float* _9083 = &profile@5.rows[6].x;
    float _9084 = *_9083;
    float _9085 = _9084 + 1.0000;
    float3 _9087 = *shadow@6;
    *param@778 = _9087;
    *param@779 = _9085;
    float3 _9089 = characterDiffuseSaturation(param@778, param@779);
    *shadow@6 = _9089;
  }

  float* _9091 = &profile@5.rows[3].z;
  float _9092 = *_9091;
  bool _9093 = _9092 > 0.5000;
  
  if(_9093) {
    float* _9096 = &profile@5.rows[3].z;
    float _9097 = *_9096;
    bool _9098 = _9097 < 1.5000;
  }

  bool _9099 = Phi(_9093, _9098);
  
  if(_9099) {
    float3 _9103 = *worldNormal;
    float3 _9104 = GLSL.std.450::Normalize(_9103);
    *_9100 = _9104;
  } else {
    float3 _9106 = *normal@24;
    *_9100 = _9106;
  }

  float3 _9107 = *_9100;
  *shadowNormal = _9107;
  float* _9109 = &profile@5.rows[3].x;
  float _9110 = *_9109;
  uint _9111 = ConvertFToU(_9110);
  *param@780 = _9111;
  float3 _9114 = *shadowNormal;
  *param@781 = _9114;
  float _9116 = *visibility@14;
  *param@782 = _9116;
  float _9118 = *mainShadow@2;
  *param@783 = _9118;
  float _9119 = materialCharacterVisibility(param@780, param@781, param@782, param@783);
  *characterVisibility@3 = _9119;
  float4 _9121 = *base@14;
  float3 _9122 = _9121.xyz;
  *param@784 = _9122;
  float3 _9124 = *normal@24;
  *param@785 = _9124;
  float3 _9126 = *view@13;
  *param@786 = _9126;
  float3 _9127 = materialNprLitAlbedo(param@784, param@785, param@786);
  float3 _9128 = *normal@24;
  float3 _9129 = *view@13;
  float _9130 = Dot(_9128, _9129);
  *param@787 = _9127;
  float3 _9133 = *shadow@6;
  *param@788 = _9133;
  float _9135 = *metallic@6;
  *param@789 = _9135;
  float* _9137 = &parameters@6.x;
  float _9138 = *_9137;
  *param@790 = _9138;
  float4 _9140 = *ramp@14;
  *param@791 = _9140;
  float _9142 = *baseAo@2;
  *param@792 = _9142;
  float2 _9144 = *mask@3;
  *param@793 = _9144;
  *param@794 = _9130;
  float _9147 = *characterVisibility@3;
  *param@795 = _9147;
  float _9149 = *visibility@14;
  *param@796 = _9149;
  CharacterDiffuseResponse _9150 = characterDiffuseResponse(param@787, param@788, param@789, param@790, param@791, param@792, param@793, param@794, param@795, param@796);
  return _9150;
}

float3 materialNprDiffuse(float4* base@15, float* metallic@7, float4* ramp@15, float* baseAo@3, float* visibility@15, float* mainShadow@3, float3* normal@25, float3* view@14) {
  float4* param@797;
  float* param@798;
  float4* param@799;
  float* param@800;
  float* param@801;
  float* param@802;
  float3* param@803;
  float3* param@804;
  float4 _9154 = *base@15;
  *param@797 = _9154;
  float _9156 = *metallic@7;
  *param@798 = _9156;
  float4 _9158 = *ramp@15;
  *param@799 = _9158;
  float _9160 = *baseAo@3;
  *param@800 = _9160;
  float _9162 = *visibility@15;
  *param@801 = _9162;
  float _9164 = *mainShadow@3;
  *param@802 = _9164;
  float3 _9166 = *normal@25;
  *param@803 = _9166;
  float3 _9168 = *view@14;
  *param@804 = _9168;
  CharacterDiffuseResponse _9169 = materialNprDiffuseResponse(param@797, param@798, param@799, param@800, param@801, param@802, param@803, param@804);
  float3 _9170 = _9169.color;
  return _9170;
}

float4 shadowPlaneQuad(int2* base@16, int2* lo@5, int2* hi@5, float2* uv@28, float2* extent@13, float2* gradient@4) {
  float2* first@5;
  float2* last@2;
  float4* x@7;
  float4* y@6;
  int2 _9174 = *base@16;
  int2 _9175 = *lo@5;
  int2 _9176 = *hi@5;
  int2 _9177 = GLSL.std.450::SClamp(_9174, _9175, _9176);
  float2 _9178 = ConvertSToF(_9177);
  float2 _9179 = CompositeConstruct({0.5000, 0.5000});
  float2 _9180 = _9178 + _9179;
  float2 _9181 = *extent@13;
  float2 _9182 = _9180 / _9181;
  *first@5 = _9182;
  int2 _9184 = *base@16;
  int2 _9185 = _9184 + {1, 1};
  int2 _9186 = *lo@5;
  int2 _9187 = *hi@5;
  int2 _9188 = GLSL.std.450::SClamp(_9185, _9186, _9187);
  float2 _9189 = ConvertSToF(_9188);
  float2 _9190 = CompositeConstruct({0.5000, 0.5000});
  float2 _9191 = _9189 + _9190;
  float2 _9192 = *extent@13;
  float2 _9193 = _9191 / _9192;
  *last@2 = _9193;
  float* _9195 = &first@5.x;
  float _9196 = *_9195;
  float* _9197 = &last@2.x;
  float _9198 = *_9197;
  float* _9199 = &first@5.x;
  float _9200 = *_9199;
  float* _9201 = &last@2.x;
  float _9202 = *_9201;
  float4 _9203 = CompositeConstruct({_9196, _9198, _9200, _9202});
  float* _9204 = &uv@28.x;
  float _9205 = *_9204;
  float4 _9206 = CompositeConstruct({_9205, _9205, _9205, _9205});
  float4 _9207 = _9203 - _9206;
  *x@7 = _9207;
  float* _9209 = &first@5.y;
  float _9210 = *_9209;
  float* _9211 = &first@5.y;
  float _9212 = *_9211;
  float* _9213 = &last@2.y;
  float _9214 = *_9213;
  float* _9215 = &last@2.y;
  float _9216 = *_9215;
  float4 _9217 = CompositeConstruct({_9210, _9212, _9214, _9216});
  float* _9218 = &uv@28.y;
  float _9219 = *_9218;
  float4 _9220 = CompositeConstruct({_9219, _9219, _9219, _9219});
  float4 _9221 = _9217 - _9220;
  *y@6 = _9221;
  float4 _9222 = *x@7;
  float* _9223 = &gradient@4.x;
  float _9224 = *_9223;
  float4 _9225 = _9222 * _9224;
  float4 _9226 = *y@6;
  float* _9227 = &gradient@4.y;
  float _9228 = *_9227;
  float4 _9229 = _9226 * _9228;
  float4 _9230 = _9225 + _9229;
  return _9230;
}

float sampleCascadeShadow(int* cascade, float* normalDotLight@4, float2* depthGradient, float* normalCurvature@2) {
  float3* p@11;
  float2* localUv;
  int2* extent@14;
  int2* tile;
  int2* origin@2;
  int2* lo@6;
  int2* hi@6;
  float2* uv@29;
  float* depthRange;
  float* worldTexel@2;
  float* maximumRadius@2;
  float* param@805;
  float* param@806;
  float* receiver@4;
  float* param@807;
  float* param@808;
  float2* centre@2;
  int2* base@17;
  float2* fraction@3;
  float2* depthPerTexel;
  int* reach;
  int2* tileLow;
  int2* tileHigh;
  float* minimumDepth;
  float* maximumDepth;
  int* ty@2;
  int* tx@2;
  float2* range@2;
  float* planeMargin;
  bool* interior;
  float* sum;
  float* blockers;
  int* y@7;
  int* x@8;
  float4* weights@4;
  int2* param@809;
  float2* param@810;
  float4* plane;
  float4* _9519;
  int2* param@811;
  int2* param@812;
  int2* param@813;
  float2* param@814;
  float2* param@815;
  float2* param@816;
  float4* depths;
  int2* param@817;
  int2* param@818;
  int2* param@819;
  float4* mass;
  float* separation@2;
  float* _9601;
  float* contactRadius;
  float* param@820;
  float* param@821;
  float* radius@6;
  float* visible;
  float* totalWeight;
  int* bound;
  int* y@8;
  int* x@9;
  float4* weights@5;
  float2* param@822;
  float* param@823;
  float4* planeDepths;
  float4* _9679;
  int2* param@824;
  int2* param@825;
  int2* param@826;
  float2* param@827;
  float2* param@828;
  float2* param@829;
  float* weight@11;
  float4* depths@2;
  int2* param@830;
  int2* param@831;
  int2* param@832;
  int _9236 = *cascade;
  float4* _9237 = &shadowPositions[_9236];
  float4 _9238 = *_9237;
  float3 _9239 = _9238.xyz;
  int _9240 = *cascade;
  float* _9241 = &shadowPositions[_9240].w;
  float _9242 = *_9241;
  float3 _9243 = CompositeConstruct({_9242, _9242, _9242});
  float3 _9244 = _9239 / _9243;
  *p@11 = _9244;
  float3 _9246 = *p@11;
  float2 _9247 = _9246.xy;
  float2 _9248 = _9247 * 0.5000;
  float2 _9249 = CompositeConstruct({0.5000, 0.5000});
  float2 _9250 = _9248 + _9249;
  *localUv = _9250;
  float* _9251 = &p@11.z;
  float _9252 = *_9251;
  bool _9253 = _9252 <= 0.0000;
  bool _9254 = !_9253;
  
  if(_9254) {
    float* _9257 = &p@11.z;
    float _9258 = *_9257;
    bool _9259 = _9258 >= 1.0000;
  }

  bool _9260 = Phi(_9253, _9259);
  bool _9261 = !_9260;
  
  if(_9261) {
    float2 _9264 = *localUv;
    bool _9265 = _9264 < {0.0000, 0.0000};
    bool _9266 = Any(_9265);
  }

  bool _9267 = Phi(_9260, _9266);
  bool _9268 = !_9267;
  
  if(_9268) {
    float2 _9271 = *localUv;
    bool _9272 = _9271 > {1.0000, 1.0000};
    bool _9273 = Any(_9272);
  }

  bool _9274 = Phi(_9267, _9273);
  
  if(_9274) {
    return 1.0000;
  }

  Image<float, 2D> _9279 = *mainShadowDepth;
  sampler _9280 = *sharedDepthSampler;
  SampledImage<float, 2D> _9281 = SampledImage(_9279, _9280);
  Image<float, 2D> _9282 = Image(_9281);
  int2 _9283 = ImageQuerySizeLod(_9282, 0);
  *extent@14 = _9283;
  int2 _9285 = *extent@14;
  int2 _9286 = CompositeConstruct({2, 2});
  int2 _9287 = _9285 / _9286;
  *tile = _9287;
  int _9289 = *cascade;
  int _9290 = SMod(_9289, 2);
  int _9291 = *cascade;
  int _9292 = _9291 / 2;
  int2 _9293 = CompositeConstruct({_9290, _9292});
  int2 _9294 = *tile;
  int2 _9295 = _9293 * _9294;
  *origin@2 = _9295;
  int2 _9297 = *origin@2;
  int2 _9298 = _9297 + {1, 1};
  *lo@6 = _9298;
  int2 _9300 = *origin@2;
  int2 _9301 = *tile;
  int2 _9302 = _9300 + _9301;
  int2 _9304 = _9302 - {2, 2};
  *hi@6 = _9304;
  int2 _9306 = *origin@2;
  float2 _9307 = ConvertSToF(_9306);
  float2 _9308 = *localUv;
  int2 _9309 = *tile;
  float2 _9310 = ConvertSToF(_9309);
  float2 _9311 = _9308 * _9310;
  float2 _9312 = _9307 + _9311;
  int2 _9313 = *extent@14;
  float2 _9314 = ConvertSToF(_9313);
  float2 _9315 = _9312 / _9314;
  *uv@29 = _9315;
  int _9317 = *cascade;
  float* _9318 = &camera.cascadeDepthRanges[_9317];
  float _9319 = *_9318;
  *depthRange = _9319;
  int _9322 = *cascade;
  float* _9323 = &camera.cascadeWorldDiameters[_9322];
  float _9324 = *_9323;
  int* _9325 = &tile.x;
  int _9326 = *_9325;
  float _9327 = ConvertSToF(_9326);
  float _9328 = _9324 / _9327;
  *worldTexel@2 = _9328;
  float* _9330 = &camera.renderingParameters.w;
  float _9331 = *_9330;
  float _9333 = GLSL.std.450::FClamp(_9331, 1.0000, 16.0000);
  *maximumRadius@2 = _9333;
  float _9334 = *worldTexel@2;
  float _9335 = *maximumRadius@2;
  float _9336 = _9334 * _9335;
  float _9338 = *normalCurvature@2;
  *param@805 = _9338;
  *param@806 = _9336;
  float _9340 = shadowReceiverPlaneWeight(param@805, param@806);
  float2 _9341 = *depthGradient;
  float2 _9342 = _9341 * _9340;
  *depthGradient = _9342;
  float* _9344 = &p@11.z;
  float _9345 = *_9344;
  float _9347 = *normalDotLight@4;
  *param@807 = _9347;
  float _9349 = *worldTexel@2;
  *param@808 = _9349;
  float _9350 = shadowReceiverBias(param@807, param@808);
  float _9351 = *depthRange;
  float _9352 = _9350 / _9351;
  float _9353 = _9345 - _9352;
  *receiver@4 = _9353;
  float2 _9355 = *uv@29;
  int2 _9356 = *extent@14;
  float2 _9357 = ConvertSToF(_9356);
  float2 _9358 = _9355 * _9357;
  float2 _9359 = CompositeConstruct({0.5000, 0.5000});
  float2 _9360 = _9358 - _9359;
  *centre@2 = _9360;
  float2 _9362 = *centre@2;
  float2 _9363 = GLSL.std.450::Floor(_9362);
  int2 _9364 = ConvertFToS(_9363);
  *base@17 = _9364;
  float2 _9366 = *centre@2;
  float2 _9367 = GLSL.std.450::Fract(_9366);
  *fraction@3 = _9367;
  float2 _9369 = *depthGradient;
  int2 _9370 = *extent@14;
  float2 _9371 = ConvertSToF(_9370);
  float2 _9372 = _9369 / _9371;
  *depthPerTexel = _9372;
  float _9374 = *maximumRadius@2;
  float _9375 = _9374 + 0.5000;
  float _9376 = GLSL.std.450::Ceil(_9375);
  int _9377 = ConvertFToS(_9376);
  *reach = _9377;
  int2 _9379 = *base@17;
  int _9380 = *reach;
  int2 _9381 = CompositeConstruct({_9380, _9380});
  int2 _9382 = _9379 - _9381;
  int2 _9383 = *lo@6;
  int2 _9384 = *hi@6;
  int2 _9385 = GLSL.std.450::SClamp(_9382, _9383, _9384);
  int2 _9386 = CompositeConstruct({8, 8});
  int2 _9387 = _9385 / _9386;
  *tileLow = _9387;
  int2 _9389 = *base@17;
  int _9390 = *reach;
  int _9391 = _9390 + 1;
  int2 _9392 = CompositeConstruct({_9391, _9391});
  int2 _9393 = _9389 + _9392;
  int2 _9394 = *lo@6;
  int2 _9395 = *hi@6;
  int2 _9396 = GLSL.std.450::SClamp(_9393, _9394, _9395);
  int2 _9397 = CompositeConstruct({8, 8});
  int2 _9398 = _9396 / _9397;
  *tileHigh = _9398;
  *minimumDepth = 1.0000;
  *maximumDepth = 0.0000;
  int* _9402 = &tileLow.y;
  int _9403 = *_9402;
  *ty@2 = _9403;

  while(true) {
    int _9409 = *ty@2;
    int* _9410 = &tileHigh.y;
    int _9411 = *_9410;
    bool _9412 = _9409 <= _9411;
    if(!_9412) break;
    int* _9414 = &tileLow.x;
    int _9415 = *_9414;
    *tx@2 = _9415;

    while(true) {
      int _9421 = *tx@2;
      int* _9422 = &tileHigh.x;
      int _9423 = *_9422;
      bool _9424 = _9421 <= _9423;
      if(!_9424) break;
      int _9426 = *ty@2;
      int* _9427 = &extent@14.x;
      int _9428 = *_9427;
      int _9429 = _9428 / 8;
      int _9430 = _9426 * _9429;
      int _9431 = *tx@2;
      int _9432 = _9430 + _9431;
      float2* _9433 = &shadowBounds.values[_9432];
      float2 _9434 = *_9433;
      *range@2 = _9434;
      float _9435 = *minimumDepth;
      float* _9436 = &range@2.x;
      float _9437 = *_9436;
      float _9438 = GLSL.std.450::FMin(_9435, _9437);
      *minimumDepth = _9438;
      float _9439 = *maximumDepth;
      float* _9440 = &range@2.y;
      float _9441 = *_9440;
      float _9442 = GLSL.std.450::FMax(_9439, _9441);
      *maximumDepth = _9442;
      int _9443 = *tx@2;
      int _9444 = _9443 + 1;
      *tx@2 = _9444;
    }

    int _9445 = *ty@2;
    int _9446 = _9445 + 1;
    *ty@2 = _9446;
  }

  int _9448 = *reach;
  float _9449 = ConvertSToF(_9448);
  float _9450 = _9449 + 2.0000;
  float* _9451 = &depthPerTexel.x;
  float _9452 = *_9451;
  float _9453 = GLSL.std.450::FAbs(_9452);
  float* _9454 = &depthPerTexel.y;
  float _9455 = *_9454;
  float _9456 = GLSL.std.450::FAbs(_9455);
  float _9457 = _9453 + _9456;
  float _9458 = _9450 * _9457;
  *planeMargin = _9458;
  float _9459 = *receiver@4;
  float _9460 = *planeMargin;
  float _9461 = _9459 + _9460;
  float _9462 = *minimumDepth;
  bool _9463 = _9461 <= _9462;
  
  if(_9463) {
    return 1.0000;
  }

  float _9467 = *receiver@4;
  float _9468 = *planeMargin;
  float _9469 = _9467 - _9468;
  float _9470 = *maximumDepth;
  bool _9471 = _9469 > _9470;
  
  if(_9471) {
    return 0.0000;
  }

  int2 _9476 = *base@17;
  int2 _9478 = _9476 - {17, 17};
  int2 _9479 = *lo@6;
  bool _9480 = _9478 >= _9479;
  bool _9481 = All(_9480);
  
  if(_9481) {
    int2 _9484 = *base@17;
    int2 _9486 = _9484 + {18, 18};
    int2 _9487 = *hi@6;
    bool _9488 = _9486 <= _9487;
    bool _9489 = All(_9488);
  }

  bool _9490 = Phi(_9481, _9489);
  *interior = _9490;
  *sum = 0.0000;
  *blockers = 0.0000;
  *y@7 = -2;

  while(true) {
    int _9499 = *y@7;
    bool _9500 = _9499 <= 2;
    if(!_9500) break;
    *x@8 = -2;

    while(true) {
      int _9507 = *x@8;
      bool _9508 = _9507 <= 2;
      if(!_9508) break;
      int _9510 = *x@8;
      int _9511 = *y@7;
      int2 _9512 = CompositeConstruct({_9510, _9511});
      *param@809 = _9512;
      float2 _9515 = *fraction@3;
      *param@810 = _9515;
      float4 _9516 = shadowBlockerGridWeights(param@809, param@810);
      *weights@4 = _9516;
      bool _9518 = *interior;
      
      if(_9518) {
        int _9522 = *x@8;
        float _9523 = ConvertSToF(_9522);
        int _9524 = *y@7;
        float _9525 = ConvertSToF(_9524);
        float2 _9526 = CompositeConstruct({_9523, _9525});
        float2 _9527 = *fraction@3;
        float2 _9528 = _9526 - _9527;
        float2 _9529 = *depthPerTexel;
        float _9530 = Dot(_9528, _9529);
        float* _9531 = &depthPerTexel.x;
        float _9532 = *_9531;
        float* _9533 = &depthPerTexel.y;
        float _9534 = *_9533;
        float* _9535 = &depthPerTexel.x;
        float _9536 = *_9535;
        float* _9537 = &depthPerTexel.y;
        float _9538 = *_9537;
        float _9539 = _9536 + _9538;
        float4 _9540 = CompositeConstruct({0.0000, _9532, _9534, _9539});
        float4 _9541 = CompositeConstruct({_9530, _9530, _9530, _9530});
        float4 _9542 = _9541 + _9540;
        *_9519 = _9542;
      } else {
        int2 _9544 = *base@17;
        int _9545 = *x@8;
        int _9546 = *y@7;
        int2 _9547 = CompositeConstruct({_9545, _9546});
        int2 _9548 = _9544 + _9547;
        int2 _9549 = *extent@14;
        float2 _9550 = ConvertSToF(_9549);
        *param@811 = _9548;
        int2 _9553 = *lo@6;
        *param@812 = _9553;
        int2 _9555 = *hi@6;
        *param@813 = _9555;
        float2 _9557 = *uv@29;
        *param@814 = _9557;
        *param@815 = _9550;
        float2 _9560 = *depthGradient;
        *param@816 = _9560;
        float4 _9561 = shadowPlaneQuad(param@811, param@812, param@813, param@814, param@815, param@816);
        *_9519 = _9561;
      }

      float4 _9562 = *_9519;
      *plane = _9562;
      int2 _9564 = *base@17;
      int _9565 = *x@8;
      int _9566 = *y@7;
      int2 _9567 = CompositeConstruct({_9565, _9566});
      int2 _9568 = _9564 + _9567;
      *param@817 = _9568;
      int2 _9571 = *lo@6;
      *param@818 = _9571;
      int2 _9573 = *hi@6;
      *param@819 = _9573;
      float4 _9574 = shadowTexelQuad(mainShadowDepth, sharedDepthSampler, param@817, param@818, param@819);
      float4 _9575 = *plane;
      float4 _9576 = _9574 - _9575;
      *depths = _9576;
      float _9578 = *receiver@4;
      float4 _9579 = CompositeConstruct({_9578, _9578, _9578, _9578});
      float4 _9580 = *depths;
      float4 _9581 = GLSL.std.450::Step(_9579, _9580);
      float4 _9582 = {1.0000, 1.0000, 1.0000, 1.0000} - _9581;
      float4 _9583 = *weights@4;
      float4 _9584 = _9582 * _9583;
      *mass = _9584;
      float4 _9585 = *depths;
      float4 _9586 = *mass;
      float _9587 = Dot(_9585, _9586);
      float _9588 = *sum;
      float _9589 = _9588 + _9587;
      *sum = _9589;
      float4 _9590 = *mass;
      float _9591 = Dot({1.0000, 1.0000, 1.0000, 1.0000}, _9590);
      float _9592 = *blockers;
      float _9593 = _9592 + _9591;
      *blockers = _9593;
      int _9594 = *x@8;
      int _9595 = _9594 + 2;
      *x@8 = _9595;
    }

    int _9596 = *y@7;
    int _9597 = _9596 + 2;
    *y@7 = _9597;
  }

  float _9599 = *blockers;
  bool _9600 = _9599 > 0.0000;
  
  if(_9600) {
    float _9604 = *receiver@4;
    float _9605 = *sum;
    float _9606 = *blockers;
    float _9607 = _9605 / _9606;
    float _9608 = _9604 - _9607;
    float _9609 = GLSL.std.450::FMax(_9608, 0.0000);
    float _9610 = *depthRange;
    float _9611 = _9609 * _9610;
    *_9601 = _9611;
  } else {
    *_9601 = 0.0000;
  }

  float _9613 = *_9601;
  *separation@2 = _9613;
  int* _9615 = &tile.x;
  int _9616 = *_9615;
  float _9617 = ConvertSToF(_9616);
  *param@820 = _9617;
  float _9620 = *maximumRadius@2;
  *param@821 = _9620;
  float _9621 = shadowContactRadius(param@820, param@821);
  *contactRadius = _9621;
  float _9623 = *contactRadius;
  float _9624 = *separation@2;
  float _9626 = _9624 * 0.0350;
  float _9627 = *worldTexel@2;
  float _9628 = GLSL.std.450::FMax(_9627, 0.0000);
  float _9629 = _9626 / _9628;
  float _9630 = _9623 + _9629;
  float _9631 = *contactRadius;
  float _9632 = *maximumRadius@2;
  float _9633 = GLSL.std.450::FClamp(_9630, _9631, _9632);
  *radius@6 = _9633;
  *visible = 0.0000;
  *totalWeight = 0.0000;
  float _9637 = *radius@6;
  float _9638 = _9637 + 0.5000;
  float _9639 = GLSL.std.450::Ceil(_9638);
  int _9640 = ConvertFToS(_9639);
  *bound = _9640;
  int _9642 = *bound;
  int _9643 = -_9642;
  *y@8 = _9643;

  while(true) {
    int _9649 = *y@8;
    int _9650 = *bound;
    bool _9651 = _9649 <= _9650;
    if(!_9651) break;
    int _9653 = *bound;
    int _9654 = -_9653;
    *x@9 = _9654;

    while(true) {
      int _9660 = *x@9;
      int _9661 = *bound;
      bool _9662 = _9660 <= _9661;
      if(!_9662) break;
      int _9664 = *x@9;
      float _9665 = ConvertSToF(_9664);
      int _9666 = *y@8;
      float _9667 = ConvertSToF(_9666);
      float2 _9668 = CompositeConstruct({_9665, _9667});
      float2 _9669 = *fraction@3;
      float2 _9670 = _9668 - _9669;
      *param@822 = _9670;
      float _9673 = *radius@6;
      *param@823 = _9673;
      float4 _9674 = shadowDiskQuadWeights(param@822, param@823);
      *weights@5 = _9674;
      float _9676 = *receiver@4;
      float4 _9677 = CompositeConstruct({_9676, _9676, _9676, _9676});
      bool _9678 = *interior;
      
      if(_9678) {
        int _9682 = *x@9;
        float _9683 = ConvertSToF(_9682);
        int _9684 = *y@8;
        float _9685 = ConvertSToF(_9684);
        float2 _9686 = CompositeConstruct({_9683, _9685});
        float2 _9687 = *fraction@3;
        float2 _9688 = _9686 - _9687;
        float2 _9689 = *depthPerTexel;
        float _9690 = Dot(_9688, _9689);
        float* _9691 = &depthPerTexel.x;
        float _9692 = *_9691;
        float* _9693 = &depthPerTexel.y;
        float _9694 = *_9693;
        float* _9695 = &depthPerTexel.x;
        float _9696 = *_9695;
        float* _9697 = &depthPerTexel.y;
        float _9698 = *_9697;
        float _9699 = _9696 + _9698;
        float4 _9700 = CompositeConstruct({0.0000, _9692, _9694, _9699});
        float4 _9701 = CompositeConstruct({_9690, _9690, _9690, _9690});
        float4 _9702 = _9701 + _9700;
        *_9679 = _9702;
      } else {
        int2 _9704 = *base@17;
        int _9705 = *x@9;
        int _9706 = *y@8;
        int2 _9707 = CompositeConstruct({_9705, _9706});
        int2 _9708 = _9704 + _9707;
        int2 _9709 = *extent@14;
        float2 _9710 = ConvertSToF(_9709);
        *param@824 = _9708;
        int2 _9713 = *lo@6;
        *param@825 = _9713;
        int2 _9715 = *hi@6;
        *param@826 = _9715;
        float2 _9717 = *uv@29;
        *param@827 = _9717;
        *param@828 = _9710;
        float2 _9720 = *depthGradient;
        *param@829 = _9720;
        float4 _9721 = shadowPlaneQuad(param@824, param@825, param@826, param@827, param@828, param@829);
        *_9679 = _9721;
      }

      float4 _9722 = *_9679;
      float4 _9723 = _9677 + _9722;
      *planeDepths = _9723;
      float4 _9725 = *weights@5;
      float _9726 = Dot(_9725, {1.0000, 1.0000, 1.0000, 1.0000});
      *weight@11 = _9726;
      float _9727 = *weight@11;
      bool _9728 = _9727 <= 0.0000;
      
      if(_9728) {
        goto loop_continue4;
      }

      int2 _9733 = *base@17;
      int _9734 = *x@9;
      int _9735 = *y@8;
      int2 _9736 = CompositeConstruct({_9734, _9735});
      int2 _9737 = _9733 + _9736;
      *param@830 = _9737;
      int2 _9740 = *lo@6;
      *param@831 = _9740;
      int2 _9742 = *hi@6;
      *param@832 = _9742;
      float4 _9743 = shadowTexelQuad(mainShadowDepth, sharedDepthSampler, param@830, param@831, param@832);
      *depths@2 = _9743;
      float4 _9744 = *weights@5;
      float4 _9745 = *planeDepths;
      float4 _9746 = *depths@2;
      float4 _9747 = GLSL.std.450::Step(_9745, _9746);
      float _9748 = Dot(_9744, _9747);
      float _9749 = *visible;
      float _9750 = _9749 + _9748;
      *visible = _9750;
      float _9751 = *weight@11;
      float _9752 = *totalWeight;
      float _9753 = _9752 + _9751;
      *totalWeight = _9753;
loop_continue4:
      int _9754 = *x@9;
      int _9755 = _9754 + 2;
      *x@9 = _9755;
    }

    int _9756 = *y@8;
    int _9757 = _9756 + 2;
    *y@8 = _9757;
  }

  float _9758 = *visible;
  float _9759 = *totalWeight;
  float _9760 = GLSL.std.450::FMax(_9759, 0.0000);
  float _9761 = _9758 / _9760;
  return _9761;
}

void prepareShadowReceiver() {
  float3* receiverNormal@2;
  float3* p@12;
  float2* uv@30;
  float2* dx@5;
  float2* dy@5;
  float* zx;
  float* zy;
  float* determinant;
  float2* _9832;
  float3* p@13;
  float2* uv@31;
  float2* dx@6;
  float2* dy@6;
  float* zx@2;
  float* zy@2;
  float* determinant@2;
  float2* _9904;
  float3* p@14;
  float2* uv@32;
  float2* dx@7;
  float2* dy@7;
  float* zx@3;
  float* zy@3;
  float* determinant@3;
  float2* _9976;
  float3* p@15;
  float2* uv@33;
  float2* dx@8;
  float2* dy@8;
  float* zx@4;
  float* zy@4;
  float* determinant@4;
  float2* _10048;
  float3 _9765 = *worldNormal;
  float3 _9766 = GLSL.std.450::Normalize(_9765);
  *receiverNormal@2 = _9766;
  float3 _9769 = *receiverNormal@2;
  float3 _9770 = DPdx(_9769);
  float _9771 = GLSL.std.450::Length(_9770);
  float3 _9772 = *receiverNormal@2;
  float3 _9773 = DPdy(_9772);
  float _9774 = GLSL.std.450::Length(_9773);
  float _9775 = GLSL.std.450::FMax(_9771, _9774);
  float3 _9776 = *worldPosition;
  float3 _9777 = DPdx(_9776);
  float _9778 = GLSL.std.450::Length(_9777);
  float3 _9779 = *worldPosition;
  float3 _9780 = DPdy(_9779);
  float _9781 = GLSL.std.450::Length(_9780);
  float _9782 = GLSL.std.450::FMax(_9778, _9781);
  float _9783 = GLSL.std.450::FMax(_9782, 0.0000);
  float _9784 = _9775 / _9783;
  *shadowReceiverCurvature = _9784;
  float4* _9786 = &shadowPositions[0];
  float4 _9787 = *_9786;
  float3 _9788 = _9787.xyz;
  float* _9789 = &shadowPositions[0].w;
  float _9790 = *_9789;
  float3 _9791 = CompositeConstruct({_9790, _9790, _9790});
  float3 _9792 = _9788 / _9791;
  *p@12 = _9792;
  float3 _9794 = *p@12;
  float2 _9795 = _9794.xy;
  float2 _9796 = _9795 * 0.5000;
  float2 _9797 = CompositeConstruct({0.5000, 0.5000});
  float2 _9798 = _9796 + _9797;
  float2 _9799 = _9798 * 0.5000;
  *uv@30 = _9799;
  float2 _9801 = *uv@30;
  float2 _9802 = DPdx(_9801);
  *dx@5 = _9802;
  float2 _9804 = *uv@30;
  float2 _9805 = DPdy(_9804);
  *dy@5 = _9805;
  float* _9807 = &p@12.z;
  float _9808 = *_9807;
  float _9809 = DPdx(_9808);
  *zx = _9809;
  float* _9811 = &p@12.z;
  float _9812 = *_9811;
  float _9813 = DPdy(_9812);
  *zy = _9813;
  float* _9815 = &dx@5.x;
  float _9816 = *_9815;
  float* _9817 = &dy@5.y;
  float _9818 = *_9817;
  float _9819 = _9816 * _9818;
  float* _9820 = &dx@5.y;
  float _9821 = *_9820;
  float* _9822 = &dy@5.x;
  float _9823 = *_9822;
  float _9824 = _9821 * _9823;
  float _9825 = _9819 - _9824;
  *determinant = _9825;
  float _9829 = *determinant;
  float _9830 = GLSL.std.450::FAbs(_9829);
  bool _9831 = _9830 > 0.0000;
  
  if(_9831) {
    float _9835 = *zx;
    float* _9836 = &dy@5.y;
    float _9837 = *_9836;
    float _9838 = _9835 * _9837;
    float _9839 = *zy;
    float* _9840 = &dx@5.y;
    float _9841 = *_9840;
    float _9842 = _9839 * _9841;
    float _9843 = _9838 - _9842;
    float _9844 = *zy;
    float* _9845 = &dx@5.x;
    float _9846 = *_9845;
    float _9847 = _9844 * _9846;
    float _9848 = *zx;
    float* _9849 = &dy@5.x;
    float _9850 = *_9849;
    float _9851 = _9848 * _9850;
    float _9852 = _9847 - _9851;
    float2 _9853 = CompositeConstruct({_9843, _9852});
    float _9854 = *determinant;
    float2 _9855 = CompositeConstruct({_9854, _9854});
    float2 _9856 = _9853 / _9855;
    *_9832 = _9856;
  } else {
    *_9832 = {0.0000, 0.0000};
  }

  float2 _9858 = *_9832;
  float2* _9859 = &shadowReceiverGradients[0];
  *_9859 = _9858;
  float4* _9861 = &shadowPositions[1];
  float4 _9862 = *_9861;
  float3 _9863 = _9862.xyz;
  float* _9864 = &shadowPositions[1].w;
  float _9865 = *_9864;
  float3 _9866 = CompositeConstruct({_9865, _9865, _9865});
  float3 _9867 = _9863 / _9866;
  *p@13 = _9867;
  float3 _9869 = *p@13;
  float2 _9870 = _9869.xy;
  float2 _9871 = _9870 * 0.5000;
  float2 _9872 = CompositeConstruct({0.5000, 0.5000});
  float2 _9873 = _9871 + _9872;
  float2 _9874 = _9873 * 0.5000;
  *uv@31 = _9874;
  float2 _9876 = *uv@31;
  float2 _9877 = DPdx(_9876);
  *dx@6 = _9877;
  float2 _9879 = *uv@31;
  float2 _9880 = DPdy(_9879);
  *dy@6 = _9880;
  float* _9882 = &p@13.z;
  float _9883 = *_9882;
  float _9884 = DPdx(_9883);
  *zx@2 = _9884;
  float* _9886 = &p@13.z;
  float _9887 = *_9886;
  float _9888 = DPdy(_9887);
  *zy@2 = _9888;
  float* _9890 = &dx@6.x;
  float _9891 = *_9890;
  float* _9892 = &dy@6.y;
  float _9893 = *_9892;
  float _9894 = _9891 * _9893;
  float* _9895 = &dx@6.y;
  float _9896 = *_9895;
  float* _9897 = &dy@6.x;
  float _9898 = *_9897;
  float _9899 = _9896 * _9898;
  float _9900 = _9894 - _9899;
  *determinant@2 = _9900;
  float _9901 = *determinant@2;
  float _9902 = GLSL.std.450::FAbs(_9901);
  bool _9903 = _9902 > 0.0000;
  
  if(_9903) {
    float _9907 = *zx@2;
    float* _9908 = &dy@6.y;
    float _9909 = *_9908;
    float _9910 = _9907 * _9909;
    float _9911 = *zy@2;
    float* _9912 = &dx@6.y;
    float _9913 = *_9912;
    float _9914 = _9911 * _9913;
    float _9915 = _9910 - _9914;
    float _9916 = *zy@2;
    float* _9917 = &dx@6.x;
    float _9918 = *_9917;
    float _9919 = _9916 * _9918;
    float _9920 = *zx@2;
    float* _9921 = &dy@6.x;
    float _9922 = *_9921;
    float _9923 = _9920 * _9922;
    float _9924 = _9919 - _9923;
    float2 _9925 = CompositeConstruct({_9915, _9924});
    float _9926 = *determinant@2;
    float2 _9927 = CompositeConstruct({_9926, _9926});
    float2 _9928 = _9925 / _9927;
    *_9904 = _9928;
  } else {
    *_9904 = {0.0000, 0.0000};
  }

  float2 _9930 = *_9904;
  float2* _9931 = &shadowReceiverGradients[1];
  *_9931 = _9930;
  float4* _9933 = &shadowPositions[2];
  float4 _9934 = *_9933;
  float3 _9935 = _9934.xyz;
  float* _9936 = &shadowPositions[2].w;
  float _9937 = *_9936;
  float3 _9938 = CompositeConstruct({_9937, _9937, _9937});
  float3 _9939 = _9935 / _9938;
  *p@14 = _9939;
  float3 _9941 = *p@14;
  float2 _9942 = _9941.xy;
  float2 _9943 = _9942 * 0.5000;
  float2 _9944 = CompositeConstruct({0.5000, 0.5000});
  float2 _9945 = _9943 + _9944;
  float2 _9946 = _9945 * 0.5000;
  *uv@32 = _9946;
  float2 _9948 = *uv@32;
  float2 _9949 = DPdx(_9948);
  *dx@7 = _9949;
  float2 _9951 = *uv@32;
  float2 _9952 = DPdy(_9951);
  *dy@7 = _9952;
  float* _9954 = &p@14.z;
  float _9955 = *_9954;
  float _9956 = DPdx(_9955);
  *zx@3 = _9956;
  float* _9958 = &p@14.z;
  float _9959 = *_9958;
  float _9960 = DPdy(_9959);
  *zy@3 = _9960;
  float* _9962 = &dx@7.x;
  float _9963 = *_9962;
  float* _9964 = &dy@7.y;
  float _9965 = *_9964;
  float _9966 = _9963 * _9965;
  float* _9967 = &dx@7.y;
  float _9968 = *_9967;
  float* _9969 = &dy@7.x;
  float _9970 = *_9969;
  float _9971 = _9968 * _9970;
  float _9972 = _9966 - _9971;
  *determinant@3 = _9972;
  float _9973 = *determinant@3;
  float _9974 = GLSL.std.450::FAbs(_9973);
  bool _9975 = _9974 > 0.0000;
  
  if(_9975) {
    float _9979 = *zx@3;
    float* _9980 = &dy@7.y;
    float _9981 = *_9980;
    float _9982 = _9979 * _9981;
    float _9983 = *zy@3;
    float* _9984 = &dx@7.y;
    float _9985 = *_9984;
    float _9986 = _9983 * _9985;
    float _9987 = _9982 - _9986;
    float _9988 = *zy@3;
    float* _9989 = &dx@7.x;
    float _9990 = *_9989;
    float _9991 = _9988 * _9990;
    float _9992 = *zx@3;
    float* _9993 = &dy@7.x;
    float _9994 = *_9993;
    float _9995 = _9992 * _9994;
    float _9996 = _9991 - _9995;
    float2 _9997 = CompositeConstruct({_9987, _9996});
    float _9998 = *determinant@3;
    float2 _9999 = CompositeConstruct({_9998, _9998});
    float2 _10000 = _9997 / _9999;
    *_9976 = _10000;
  } else {
    *_9976 = {0.0000, 0.0000};
  }

  float2 _10002 = *_9976;
  float2* _10003 = &shadowReceiverGradients[2];
  *_10003 = _10002;
  float4* _10005 = &shadowPositions[3];
  float4 _10006 = *_10005;
  float3 _10007 = _10006.xyz;
  float* _10008 = &shadowPositions[3].w;
  float _10009 = *_10008;
  float3 _10010 = CompositeConstruct({_10009, _10009, _10009});
  float3 _10011 = _10007 / _10010;
  *p@15 = _10011;
  float3 _10013 = *p@15;
  float2 _10014 = _10013.xy;
  float2 _10015 = _10014 * 0.5000;
  float2 _10016 = CompositeConstruct({0.5000, 0.5000});
  float2 _10017 = _10015 + _10016;
  float2 _10018 = _10017 * 0.5000;
  *uv@33 = _10018;
  float2 _10020 = *uv@33;
  float2 _10021 = DPdx(_10020);
  *dx@8 = _10021;
  float2 _10023 = *uv@33;
  float2 _10024 = DPdy(_10023);
  *dy@8 = _10024;
  float* _10026 = &p@15.z;
  float _10027 = *_10026;
  float _10028 = DPdx(_10027);
  *zx@4 = _10028;
  float* _10030 = &p@15.z;
  float _10031 = *_10030;
  float _10032 = DPdy(_10031);
  *zy@4 = _10032;
  float* _10034 = &dx@8.x;
  float _10035 = *_10034;
  float* _10036 = &dy@8.y;
  float _10037 = *_10036;
  float _10038 = _10035 * _10037;
  float* _10039 = &dx@8.y;
  float _10040 = *_10039;
  float* _10041 = &dy@8.x;
  float _10042 = *_10041;
  float _10043 = _10040 * _10042;
  float _10044 = _10038 - _10043;
  *determinant@4 = _10044;
  float _10045 = *determinant@4;
  float _10046 = GLSL.std.450::FAbs(_10045);
  bool _10047 = _10046 > 0.0000;
  
  if(_10047) {
    float _10051 = *zx@4;
    float* _10052 = &dy@8.y;
    float _10053 = *_10052;
    float _10054 = _10051 * _10053;
    float _10055 = *zy@4;
    float* _10056 = &dx@8.y;
    float _10057 = *_10056;
    float _10058 = _10055 * _10057;
    float _10059 = _10054 - _10058;
    float _10060 = *zy@4;
    float* _10061 = &dx@8.x;
    float _10062 = *_10061;
    float _10063 = _10060 * _10062;
    float _10064 = *zx@4;
    float* _10065 = &dy@8.x;
    float _10066 = *_10065;
    float _10067 = _10064 * _10066;
    float _10068 = _10063 - _10067;
    float2 _10069 = CompositeConstruct({_10059, _10068});
    float _10070 = *determinant@4;
    float2 _10071 = CompositeConstruct({_10070, _10070});
    float2 _10072 = _10069 / _10071;
    *_10048 = _10072;
  } else {
    *_10048 = {0.0000, 0.0000};
  }

  float2 _10074 = *_10048;
  float2* _10075 = &shadowReceiverGradients[3];
  *_10075 = _10074;
  return;
}

float sampleShadowMap(float* normalDotLight@5) {
  float* depth@13;
  int* c@3;
  int* _10103;
  int* _10111;
  float* result@4;
  int* param@833;
  float* param@834;
  float2* param@835;
  float* param@836;
  float* previous;
  float* _10141;
  float* blend@5;
  int* param@837;
  float* param@838;
  float2* param@839;
  float* param@840;
  float* _10076 = &camera.clusterLighting.x;
  float _10077 = *_10076;
  bool _10078 = _10077 > 0.5000;
  
  if(_10078) {
    float* _10081 = &camera.mainLightDirection.w;
    float _10082 = *_10081;
    bool _10083 = _10082 < 0.5000;
  }

  bool _10084 = Phi(_10078, _10083);
  
  if(_10084) {
    return 1.0000;
  }

  float3 _10089 = *worldPosition;
  float4* _10090 = &camera.cameraPosition;
  float4 _10091 = *_10090;
  float3 _10092 = _10091.xyz;
  float3 _10093 = _10089 - _10092;
  float4* _10094 = &camera.cameraForward;
  float4 _10095 = *_10094;
  float3 _10096 = _10095.xyz;
  float _10097 = Dot(_10093, _10096);
  *depth@13 = _10097;
  float _10099 = *depth@13;
  float* _10100 = &camera.cascadeSplits.x;
  float _10101 = *_10100;
  bool _10102 = _10099 <= _10101;
  
  if(_10102) {
    *_10103 = 0;
  } else {
    float _10107 = *depth@13;
    float* _10108 = &camera.cascadeSplits.y;
    float _10109 = *_10108;
    bool _10110 = _10107 <= _10109;
    
    if(_10110) {
      *_10111 = 1;
    } else {
      float _10115 = *depth@13;
      float* _10116 = &camera.cascadeSplits.z;
      float _10117 = *_10116;
      bool _10118 = _10115 <= _10117;
      int _10119 = Select(_10118, 2, 3);
      *_10111 = _10119;
    }

    int _10120 = *_10111;
    *_10103 = _10120;
  }

  int _10121 = *_10103;
  *c@3 = _10121;
  int _10123 = *c@3;
  int _10125 = *c@3;
  *param@833 = _10125;
  float _10127 = *normalDotLight@5;
  *param@834 = _10127;
  float2* _10129 = &shadowReceiverGradients[_10123];
  float2 _10130 = *_10129;
  *param@835 = _10130;
  float _10132 = *shadowReceiverCurvature;
  *param@836 = _10132;
  float _10133 = sampleCascadeShadow(param@833, param@834, param@835, param@836);
  *result@4 = _10133;
  int _10134 = *c@3;
  bool _10135 = _10134 < 3;
  
  if(_10135) {
    int _10139 = *c@3;
    bool _10140 = _10139 == 0;
    
    if(_10140) {
      float* _10144 = &camera.clusterDepth.x;
      float _10145 = *_10144;
      *_10141 = _10145;
    } else {
      int _10147 = *c@3;
      int _10148 = _10147 - 1;
      float* _10149 = &camera.cascadeSplits[_10148];
      float _10150 = *_10149;
      *_10141 = _10150;
    }

    float _10151 = *_10141;
    *previous = _10151;
    float _10153 = *previous;
    int _10154 = *c@3;
    float* _10155 = &camera.cascadeSplits[_10154];
    float _10156 = *_10155;
    float _10157 = GLSL.std.450::FMix(_10153, _10156, 0.9000);
    int _10158 = *c@3;
    float* _10159 = &camera.cascadeSplits[_10158];
    float _10160 = *_10159;
    float _10161 = *depth@13;
    float _10162 = GLSL.std.450::SmoothStep(_10157, _10160, _10161);
    *blend@5 = _10162;
    float _10163 = *blend@5;
    bool _10164 = _10163 > 0.0000;
    
    if(_10164) {
      float _10167 = *result@4;
      int _10168 = *c@3;
      int _10169 = _10168 + 1;
      int _10170 = *c@3;
      int _10171 = _10170 + 1;
      *param@837 = _10169;
      float _10174 = *normalDotLight@5;
      *param@838 = _10174;
      float2* _10176 = &shadowReceiverGradients[_10171];
      float2 _10177 = *_10176;
      *param@839 = _10177;
      float _10179 = *shadowReceiverCurvature;
      *param@840 = _10179;
      float _10180 = sampleCascadeShadow(param@837, param@838, param@839, param@840);
      float _10181 = *blend@5;
      float _10182 = GLSL.std.450::FMix(_10167, _10180, _10181);
      *result@4 = _10182;
    }

  }

  float _10183 = *result@4;
  return _10183;
}

float3 rgbToHsv(float3* c@4) {
  float* hi@7;
  float* lo@7;
  float* chroma@2;
  float* h;
  float* _10257;
  float* _10187 = &c@4.x;
  float _10188 = *_10187;
  float* _10189 = &c@4.y;
  float _10190 = *_10189;
  float* _10191 = &c@4.z;
  float _10192 = *_10191;
  float _10193 = GLSL.std.450::FMax(_10190, _10192);
  float _10194 = GLSL.std.450::FMax(_10188, _10193);
  *hi@7 = _10194;
  float* _10196 = &c@4.x;
  float _10197 = *_10196;
  float* _10198 = &c@4.y;
  float _10199 = *_10198;
  float* _10200 = &c@4.z;
  float _10201 = *_10200;
  float _10202 = GLSL.std.450::FMin(_10199, _10201);
  float _10203 = GLSL.std.450::FMin(_10197, _10202);
  *lo@7 = _10203;
  float _10205 = *hi@7;
  float _10206 = *lo@7;
  float _10207 = _10205 - _10206;
  *chroma@2 = _10207;
  *h = 0.0000;
  float _10209 = *chroma@2;
  bool _10210 = _10209 > 0.0000;
  
  if(_10210) {
    float _10213 = *hi@7;
    float* _10214 = &c@4.x;
    float _10215 = *_10214;
    bool _10216 = _10213 == _10215;
    
    if(_10216) {
      float* _10219 = &c@4.y;
      float _10220 = *_10219;
      float* _10221 = &c@4.z;
      float _10222 = *_10221;
      float _10223 = _10220 - _10222;
      float _10224 = *chroma@2;
      float _10225 = _10223 / _10224;
      *h = _10225;
    } else {
      float _10227 = *hi@7;
      float* _10228 = &c@4.y;
      float _10229 = *_10228;
      bool _10230 = _10227 == _10229;
      
      if(_10230) {
        float* _10233 = &c@4.z;
        float _10234 = *_10233;
        float* _10235 = &c@4.x;
        float _10236 = *_10235;
        float _10237 = _10234 - _10236;
        float _10238 = *chroma@2;
        float _10239 = _10237 / _10238;
        float _10240 = 2.0000 + _10239;
        *h = _10240;
      } else {
        float* _10242 = &c@4.x;
        float _10243 = *_10242;
        float* _10244 = &c@4.y;
        float _10245 = *_10244;
        float _10246 = _10243 - _10245;
        float _10247 = *chroma@2;
        float _10248 = _10246 / _10247;
        float _10249 = 4.0000 + _10248;
        *h = _10249;
      }

    }

    float _10250 = *h;
    float _10252 = _10250 / 6.0000;
    float _10253 = GLSL.std.450::Fract(_10252);
    *h = _10253;
  }

  float _10254 = *h;
  float _10255 = *hi@7;
  bool _10256 = _10255 > 0.0000;
  
  if(_10256) {
    float _10260 = *chroma@2;
    float _10261 = *hi@7;
    float _10262 = _10260 / _10261;
    *_10257 = _10262;
  } else {
    *_10257 = 0.0000;
  }

  float _10264 = *_10257;
  float _10265 = *hi@7;
  float3 _10266 = CompositeConstruct({_10254, _10264, _10265});
  return _10266;
}

float3 hsvToRgb(float3* hsv@2) {
  float3* triangle;
  float* _10270 = &hsv@2.x;
  float _10271 = *_10270;
  float3 _10272 = CompositeConstruct({_10271, _10271, _10271});
  float3 _10274 = _10272 + {0.0000, 0.6667, 0.3333};
  float3 _10275 = GLSL.std.450::Fract(_10274);
  float3 _10276 = _10275 * 6.0000;
  float3 _10277 = CompositeConstruct({3.0000, 3.0000, 3.0000});
  float3 _10278 = _10276 - _10277;
  float3 _10279 = GLSL.std.450::FAbs(_10278);
  float3 _10280 = CompositeConstruct({1.0000, 1.0000, 1.0000});
  float3 _10281 = _10279 - _10280;
  float3 _10282 = CompositeConstruct({0.0000, 0.0000, 0.0000});
  float3 _10283 = CompositeConstruct({1.0000, 1.0000, 1.0000});
  float3 _10284 = GLSL.std.450::FClamp(_10281, _10282, _10283);
  *triangle = _10284;
  float* _10285 = &hsv@2.z;
  float _10286 = *_10285;
  float3 _10287 = *triangle;
  float* _10288 = &hsv@2.y;
  float _10289 = *_10288;
  float _10290 = GLSL.std.450::FClamp(_10289, 0.0000, 1.0000);
  float3 _10291 = CompositeConstruct({_10290, _10290, _10290});
  float3 _10292 = GLSL.std.450::FMix({1.0000, 1.0000, 1.0000}, _10287, _10291);
  float3 _10293 = _10292 * _10286;
  return _10293;
}

float4 evaluateIrradianceVolume(float3* position@10, float3* normal@26, bool* surfaceReceiver) {
  uint* queryFlags;
  float2* pixel@12;
  float2* param@841;
  float* param@842;
  uint* param@843;
  float3* direction@7;
  float3* param@844;
  float3* param@845;
  float2* param@846;
  float3* param@847;
  float3* param@848;
  int* i@9;
  float4[13]* parameters@7;
  IrradianceClipmapResult* result@5;
  float4[13]* param@849;
  float3* param@850;
  float4* basis;
  float* _10297 = &camera.irradianceDimensionsEnabled.w;
  float _10298 = *_10297;
  bool _10299 = _10298 < 0.5000;
  
  if(_10299) {
    return {0.0000, 0.0000, 0.0000, 0.0000};
  }

  bool _10303 = *surfaceReceiver;
  
  if(_10303) {
    float* _10307 = &camera.irradianceDimensionsEnabled.w;
    float _10308 = *_10307;
    float _10309 = _10308 + 0.5000;
    uint _10310 = ConvertFToU(_10309);
    *queryFlags = _10310;
    float4 _10313 = *gl_FragCoord;
    float2 _10314 = _10313.xy;
    *param@841 = _10314;
    float* _10316 = &camera.clusterDepth.w;
    float _10317 = *_10316;
    *param@842 = _10317;
    uint _10319 = *queryFlags;
    *param@843 = _10319;
    float2 _10320 = irradianceQueryPixel(param@841, param@842, param@843);
    *pixel@12 = _10320;
    *direction@7 = {1.0000, 1.0000, 1.0000};
    uint _10322 = *queryFlags;
    uint _10323 = _10322 & 4;
    bool _10324 = _10323 != 0;
    
    if(_10324) {
      float4* _10331 = &IrradianceCells_var.irradianceCells[1];
      float4 _10332 = *_10331;
      float3 _10333 = _10332.xyz;
      float4* _10334 = &IrradianceCells_var.irradianceCells[2];
      float4 _10335 = *_10334;
      float3 _10336 = _10335.xyz;
      float3 _10337 = _10333 + _10336;
      float4* _10338 = &IrradianceCells_var.irradianceCells[3];
      float4 _10339 = *_10338;
      float3 _10340 = _10339.xyz;
      float3 _10341 = _10337 + _10340;
      *direction@7 = _10341;
    }

    float3 _10344 = *position@10;
    *param@844 = _10344;
    float3 _10346 = *normal@26;
    *param@845 = _10346;
    float2 _10348 = *pixel@12;
    *param@846 = _10348;
    float4* _10350 = &camera.irradianceParameters;
    float4 _10351 = *_10350;
    float3 _10352 = _10351.yzw;
    *param@847 = _10352;
    float3 _10354 = *direction@7;
    *param@848 = _10354;
    float3 _10355 = irradianceQueryPosition(param@844, param@845, param@846, param@847, param@848);
    *position@10 = _10355;
  }

  *i@9 = 0;

  while(true) {
    int _10362 = *i@9;
    bool _10363 = _10362 < 13;
    if(!_10363) break;
    int _10365 = *i@9;
    int _10366 = *i@9;
    float4* _10367 = &IrradianceCells_var.irradianceCells[_10366];
    float4 _10368 = *_10367;
    float4* _10369 = &parameters@7[_10365];
    *_10369 = _10368;
    int _10370 = *i@9;
    int _10371 = _10370 + 1;
    *i@9 = _10371;
  }

  float4[13] _10375 = *parameters@7;
  *param@849 = _10375;
  float3 _10377 = *position@10;
  *param@850 = _10377;
  IrradianceClipmapResult _10378 = evaluateIrradianceClipmap(irradianceClipmapTextures, param@849, param@850);
  *result@5 = _10378;
  float3 _10380 = *normal@26;
  float _10381 = _10380.x;
  float _10382 = _10380.y;
  float _10383 = _10380.z;
  float4 _10384 = CompositeConstruct({_10381, _10382, _10383, 1.0000});
  *basis = _10384;
  float4* _10385 = &result@5.coefficients[0];
  float4 _10386 = *_10385;
  float4 _10387 = *basis;
  float _10388 = Dot(_10386, _10387);
  float4* _10389 = &result@5.coefficients[1];
  float4 _10390 = *_10389;
  float4 _10391 = *basis;
  float _10392 = Dot(_10390, _10391);
  float4* _10393 = &result@5.coefficients[2];
  float4 _10394 = *_10393;
  float4 _10395 = *basis;
  float _10396 = Dot(_10394, _10395);
  float3 _10397 = CompositeConstruct({_10388, _10392, _10396});
  float3 _10398 = GLSL.std.450::FMax(_10397, {0.0000, 0.0000, 0.0000});
  float* _10399 = &camera.irradianceParameters.x;
  float _10400 = *_10399;
  float3 _10401 = _10398 * _10400;
  float _10402 = _10401.x;
  float _10403 = _10401.y;
  float _10404 = _10401.z;
  float4 _10405 = CompositeConstruct({_10402, _10403, _10404, 1.0000});
  return _10405;
}

float dualFaceRampCoordinate(float3* direction@8, float3* normal@27, float4* distanceSample) {
  float3x3* headFrame@3;
  float3* localLight@2;
  float3* localCamera@2;
  float2* param@851;
  float* param@852;
  float* geometryMask;
  float4* param@853;
  float* param@854;
  float3* param@855;
  float3* param@856;
  float* param@857;
  float3* param@858;
  float4x4 _10409 = *instanceFaceFrame;
  float4 _10410 = _10409[0];
  float3 _10411 = _10410.xyz;
  float4 _10412 = _10409[1];
  float3 _10413 = _10412.xyz;
  float4 _10414 = _10409[2];
  float3 _10415 = _10414.xyz;
  float3x3 _10416 = CompositeConstruct({_10411, _10413, _10415});
  *headFrame@3 = _10416;
  float3x3 _10418 = *headFrame@3;
  float3x3 _10419 = Transpose(_10418);
  float3 _10420 = *direction@8;
  float3 _10421 = _10419 * _10420;
  *localLight@2 = _10421;
  float3x3 _10423 = *headFrame@3;
  float3x3 _10424 = Transpose(_10423);
  float4* _10425 = &camera.cameraForward;
  float4 _10426 = *_10425;
  float3 _10427 = _10426.xyz;
  float3 _10428 = -_10427;
  float3 _10429 = _10424 * _10428;
  *localCamera@2 = _10429;
  uint* _10430 = &material.textureBase;
  uint _10431 = *_10430;
  uint _10432 = _10431 + 7;
  uint _10433 = CopyObject(_10432) : [[NonUniform]];
  SampledImage<float, 2D>* _10434 = &textureArray[_10433] : [[NonUniform]];
  SampledImage<float, 2D> _10435 = *_10434 : [[NonUniform]];
  float2 _10437 = *textureCoordinate;
  *param@851 = _10437;
  float* _10439 = &localLight@2.x;
  float _10440 = *_10439;
  *param@852 = _10440;
  float2 _10441 = faceSdfSampleUv(param@851, param@852);
  float4 _10442 = ImageSampleExplicitLod(_10435, _10441, Lod(0.0000));
  *distanceSample = _10442;
  uint* _10444 = &material.textureBase;
  uint _10445 = *_10444;
  uint _10446 = _10445 + 4;
  uint _10447 = CopyObject(_10446) : [[NonUniform]];
  SampledImage<float, 2D>* _10448 = &textureArray[_10447] : [[NonUniform]];
  SampledImage<float, 2D> _10449 = *_10448 : [[NonUniform]];
  float2 _10450 = *textureCoordinate;
  float4 _10451 = ImageSampleExplicitLod(_10449, _10450, Lod(0.0000));
  float _10452 = _10451.y;
  *geometryMask = _10452;
  float3 _10453 = *normal@27;
  float3 _10454 = *direction@8;
  float _10455 = Dot(_10453, _10454);
  float4 _10457 = *distanceSample;
  *param@853 = _10457;
  float _10459 = *geometryMask;
  *param@854 = _10459;
  float3 _10461 = *localLight@2;
  *param@855 = _10461;
  float3 _10463 = *localCamera@2;
  *param@856 = _10463;
  *param@857 = _10455;
  float4* _10467 = &material.hairParameters;
  float4 _10468 = *_10467;
  float3 _10469 = _10468.xyz;
  *param@858 = _10469;
  float _10470 = faceSdfRampCoordinate(param@853, param@854, param@855, param@856, param@857, param@858);
  return _10470;
}

float4 azureSampleUnlitSurface(PackedMaterialSurfaceProfile* p@16, float4* baseColor@2) {
  float* tau;
  float2* baseUv;
  float2* param@859;
  float4* param@860;
  float4* param@861;
  float2* param@862;
  float* param@863;
  float4* noise;
  float2* param@864;
  float4* param@865;
  float4* param@866;
  float2* param@867;
  float* param@868;
  float4* param@869;
  float* param@870;
  float4* param@871;
  float4* layerBase;
  float4* second@2;
  float2* param@872;
  float4* param@873;
  float4* param@874;
  float2* param@875;
  float* param@876;
  float* soft@2;
  float* effectDepth;
  float* sceneDepth@5;
  float* param@877;
  float* param@878;
  float* param@879;
  float* param@880;
  float* param@881;
  float4* param@882;
  float* param@883;
  float4* coverage@3;
  float2* param@884;
  float4* param@885;
  float4* param@886;
  float2* param@887;
  float* param@888;
  float3* projectiveRow;
  float3* viewDirection@3;
  float3* _10665;
  float4* layered@2;
  float4* param@889;
  float4* param@890;
  float4[22]* param@891;
  float* param@892;
  float* param@893;
  float* param@894;
  float3* param@895;
  float4* param@896;
  float* param@897;
  float4* param@898;
  float4* param@899;
  float* param@900;
  float* _10474 = &p@16.rows[5].x;
  float _10475 = *_10474;
  float* _10477 = &camera.unlitTimeExposure.x;
  float _10478 = *_10477;
  float _10479 = _10475 * _10478;
  float* _10480 = &p@16.rows[5].y;
  float _10481 = *_10480;
  float _10482 = _10479 + _10481;
  *tau = _10482;
  float2 _10485 = *textureCoordinate;
  *param@859 = _10485;
  float4* _10487 = &p@16.rows[0];
  float4 _10488 = *_10487;
  *param@860 = _10488;
  float4* _10490 = &p@16.rows[1];
  float4 _10491 = *_10490;
  *param@861 = _10491;
  float4* _10493 = &p@16.rows[2];
  float4 _10494 = *_10493;
  float2 _10495 = _10494.xy;
  *param@862 = _10495;
  float _10497 = *tau;
  *param@863 = _10497;
  float2 _10498 = azureUnlitLayerUv(param@859, param@860, param@861, param@862, param@863);
  *baseUv = _10498;
  float* _10499 = &p@16.rows[16].z;
  float _10500 = *_10499;
  bool _10501 = _10500 > 0.5000;
  
  if(_10501) {
    uint* _10505 = &material.textureBase;
    uint _10506 = *_10505;
    uint _10507 = _10506 + 3;
    uint _10508 = CopyObject(_10507) : [[NonUniform]];
    SampledImage<float, 2D>* _10509 = &textureArray[_10508] : [[NonUniform]];
    SampledImage<float, 2D> _10510 = *_10509 : [[NonUniform]];
    float2 _10512 = *textureCoordinate;
    *param@864 = _10512;
    float4* _10514 = &p@16.rows[17];
    float4 _10515 = *_10514;
    *param@865 = _10515;
    float4* _10517 = &p@16.rows[18];
    float4 _10518 = *_10517;
    *param@866 = _10518;
    float4* _10520 = &p@16.rows[19];
    float4 _10521 = *_10520;
    float2 _10522 = _10521.xy;
    *param@867 = _10522;
    float _10524 = *tau;
    *param@868 = _10524;
    float2 _10525 = azureUnlitLayerUv(param@864, param@865, param@866, param@867, param@868);
    float4 _10526 = ImageSampleImplicitLod(_10510, _10525);
    *noise = _10526;
    float4 _10528 = *noise;
    *param@869 = _10528;
    float* _10530 = &p@16.rows[19].z;
    float _10531 = *_10530;
    *param@870 = _10531;
    float4* _10533 = &p@16.rows[20];
    float4 _10534 = *_10533;
    *param@871 = _10534;
    float2 _10535 = azureUnlitBaseUvDistortion(param@869, param@870, param@871);
    float2 _10536 = *baseUv;
    float2 _10537 = _10536 + _10535;
    *baseUv = _10537;
  }

  uint* _10539 = &material.textureBase;
  uint _10540 = *_10539;
  uint _10541 = _10540 + 0;
  uint _10542 = CopyObject(_10541) : [[NonUniform]];
  SampledImage<float, 2D>* _10543 = &textureArray[_10542] : [[NonUniform]];
  SampledImage<float, 2D> _10544 = *_10543 : [[NonUniform]];
  float2 _10545 = *baseUv;
  float4 _10546 = ImageSampleImplicitLod(_10544, _10545);
  *layerBase = _10546;
  *second@2 = {1.0000, 1.0000, 1.0000, 1.0000};
  float* _10548 = &p@16.rows[9].z;
  float _10549 = *_10548;
  bool _10550 = _10549 > 0.5000;
  
  if(_10550) {
    uint* _10553 = &material.textureBase;
    uint _10554 = *_10553;
    uint _10555 = _10554 + 4;
    uint _10556 = CopyObject(_10555) : [[NonUniform]];
    SampledImage<float, 2D>* _10557 = &textureArray[_10556] : [[NonUniform]];
    SampledImage<float, 2D> _10558 = *_10557 : [[NonUniform]];
    float2 _10560 = *textureCoordinate;
    *param@872 = _10560;
    float4* _10562 = &p@16.rows[3];
    float4 _10563 = *_10562;
    *param@873 = _10563;
    float4* _10565 = &p@16.rows[4];
    float4 _10566 = *_10565;
    *param@874 = _10566;
    float4* _10568 = &p@16.rows[2];
    float4 _10569 = *_10568;
    float2 _10570 = _10569.zw;
    *param@875 = _10570;
    float _10572 = *tau;
    *param@876 = _10572;
    float2 _10573 = azureUnlitLayerUv(param@872, param@873, param@874, param@875, param@876);
    float4 _10574 = ImageSampleImplicitLod(_10558, _10573);
    *second@2 = _10574;
  }

  *soft@2 = 1.0000;
  float3 _10577 = *worldPosition;
  float4* _10578 = &camera.cameraPosition;
  float4 _10579 = *_10578;
  float3 _10580 = _10579.xyz;
  float3 _10581 = _10577 - _10580;
  float4* _10582 = &camera.cameraForward;
  float4 _10583 = *_10582;
  float3 _10584 = _10583.xyz;
  float _10585 = Dot(_10581, _10584);
  *effectDepth = _10585;
  float* _10586 = &p@16.rows[9].w;
  float _10587 = *_10586;
  bool _10588 = _10587 > 0.5000;
  
  if(_10588) {
    SampledImage<float, 2D> _10593 = *overlaySceneDepth;
    float4 _10594 = *gl_FragCoord;
    float2 _10595 = _10594.xy;
    float4* _10596 = &camera.clusterDepth;
    float4 _10597 = *_10596;
    float2 _10598 = _10597.zw;
    float2 _10599 = _10595 / _10598;
    float4 _10600 = ImageSampleImplicitLod(_10593, _10599);
    float _10601 = _10600.x;
    *sceneDepth@5 = _10601;
    float _10603 = *sceneDepth@5;
    *param@877 = _10603;
    float _10605 = *effectDepth;
    *param@878 = _10605;
    float* _10607 = &p@16.rows[5].z;
    float _10608 = *_10607;
    *param@879 = _10608;
    float* _10610 = &p@16.rows[5].w;
    float _10611 = *_10610;
    *param@880 = _10611;
    float _10612 = azureUnlitSoftIntersection(param@877, param@878, param@879, param@880);
    *soft@2 = _10612;
  }

  float _10614 = *effectDepth;
  *param@881 = _10614;
  float4* _10616 = &p@16.rows[10];
  float4 _10617 = *_10616;
  *param@882 = _10617;
  float* _10619 = &p@16.rows[11].x;
  float _10620 = *_10619;
  *param@883 = _10620;
  float _10621 = azureUnlitViewDepthFade(param@881, param@882, param@883);
  float _10622 = *soft@2;
  float _10623 = _10622 * _10621;
  *soft@2 = _10623;
  *coverage@3 = {1.0000, 1.0000, 1.0000, 1.0000};
  float* _10625 = &p@16.rows[11].w;
  float _10626 = *_10625;
  bool _10627 = _10626 > 0.5000;
  
  if(_10627) {
    uint* _10630 = &material.textureBase;
    uint _10631 = *_10630;
    uint _10632 = _10631 + 8;
    uint _10633 = CopyObject(_10632) : [[NonUniform]];
    SampledImage<float, 2D>* _10634 = &textureArray[_10633] : [[NonUniform]];
    SampledImage<float, 2D> _10635 = *_10634 : [[NonUniform]];
    float2 _10637 = *textureCoordinate;
    *param@884 = _10637;
    float4* _10639 = &p@16.rows[13];
    float4 _10640 = *_10639;
    *param@885 = _10640;
    float4* _10642 = &p@16.rows[14];
    float4 _10643 = *_10642;
    *param@886 = _10643;
    float4* _10645 = &p@16.rows[15];
    float4 _10646 = *_10645;
    float2 _10647 = _10646.xy;
    *param@887 = _10647;
    float _10649 = *tau;
    *param@888 = _10649;
    float2 _10650 = azureUnlitLayerUv(param@884, param@885, param@886, param@887, param@888);
    float4 _10651 = ImageSampleImplicitLod(_10635, _10650);
    *coverage@3 = _10651;
  }

  float* _10653 = &camera.screenReflectionWorldToClip[0].w;
  float _10654 = *_10653;
  float* _10655 = &camera.screenReflectionWorldToClip[1].w;
  float _10656 = *_10655;
  float* _10657 = &camera.screenReflectionWorldToClip[2].w;
  float _10658 = *_10657;
  float3 _10659 = CompositeConstruct({_10654, _10656, _10658});
  *projectiveRow = _10659;
  float3 _10661 = *projectiveRow;
  float3 _10662 = *projectiveRow;
  float _10663 = Dot(_10661, _10662);
  bool _10664 = _10663 < 0.0000;
  
  if(_10664) {
    float4* _10668 = &camera.cameraForward;
    float4 _10669 = *_10668;
    float3 _10670 = _10669.xyz;
    float3 _10671 = -_10670;
    *_10665 = _10671;
  } else {
    float4* _10673 = &camera.cameraPosition;
    float4 _10674 = *_10673;
    float3 _10675 = _10674.xyz;
    float3 _10676 = *worldPosition;
    float3 _10677 = _10675 - _10676;
    float3 _10678 = GLSL.std.450::Normalize(_10677);
    *_10665 = _10678;
  }

  float3 _10679 = *_10665;
  *viewDirection@3 = _10679;
  float3 _10683 = *vertexColorRgb;
  float _10685 = *vertexColorAlpha;
  float _10686 = _10683.x;
  float _10687 = _10683.y;
  float _10688 = _10683.z;
  float4 _10689 = CompositeConstruct({_10686, _10687, _10688, _10685});
  float3 _10690 = *worldNormal;
  float3 _10691 = *viewDirection@3;
  float _10692 = Dot(_10690, _10691);
  float4 _10694 = *layerBase;
  *param@889 = _10694;
  float4 _10696 = *second@2;
  *param@890 = _10696;
  float4[22]* _10698 = &p@16.rows;
  float4[22] _10699 = *_10698;
  *param@891 = _10699;
  float _10701 = *soft@2;
  *param@892 = _10701;
  float* _10703 = &camera.unlitTimeExposure.y;
  float _10704 = *_10703;
  *param@893 = _10704;
  float* _10706 = &camera.unlitTimeExposure.z;
  float _10707 = *_10706;
  *param@894 = _10707;
  float4* _10709 = &camera.unlitColorGain;
  float4 _10710 = *_10709;
  float3 _10711 = _10710.xyz;
  *param@895 = _10711;
  *param@896 = _10689;
  *param@897 = _10692;
  float4 _10715 = *coverage@3;
  *param@898 = _10715;
  float4 _10716 = azureUnlitLayerColor(param@889, param@890, param@891, param@892, param@893, param@894, param@895, param@896, param@897, param@898);
  *layered@2 = _10716;
  float4 _10718 = *layerBase;
  *param@899 = _10718;
  float* _10720 = &p@16.rows[9].x;
  float _10721 = *_10720;
  *param@900 = _10721;
  float4 _10722 = azureUnlitLayerSample(param@899, param@900);
  float4* _10723 = &p@16.rows[6];
  float4 _10724 = *_10723;
  float4 _10725 = _10722 * _10724;
  *baseColor@2 = _10725;
  float* _10726 = &p@16.rows[11].y;
  float _10727 = *_10726;
  bool _10728 = _10727 > 0.5000;
  
  if(_10728) {
    float3 _10731 = *vertexColorRgb;
    float _10732 = *vertexColorAlpha;
    float _10733 = _10731.x;
    float _10734 = _10731.y;
    float _10735 = _10731.z;
    float4 _10736 = CompositeConstruct({_10733, _10734, _10735, _10732});
    float4 _10737 = *baseColor@2;
    float4 _10738 = _10737 * _10736;
    *baseColor@2 = _10738;
  }

  float4 _10739 = *layered@2;
  return _10739;
}

bool azureWritePlainUnlitBeauty(float4* baseColor@3, float3* geometricNormal@2, float* platformMask@2) {
  uint* features;
  bool* param@901;
  uint* param@902;
  int* _10751;
  uint* _10762;
  uint* _10767;
  uint* _10778;
  uint* _10783;
  int* isolation;
  int* effect;
  bool* disabled;
  float3* emission;
  float* radianceScale@2;
  float* participation;
  float* param@903;
  uint* _10743 = &material.materialFeatures;
  uint _10744 = *_10743;
  uint _10746 = _10744 & _10745;
  uint _10747 = _10746 | azureFixedMaterialFeatureValue;
  *param@901 = azureOrdinaryOpaque;
  *param@902 = _10747;
  uint _10750 = azureSpecializedMaterialFeatures(param@901, param@902);
  *features = _10750;
  
  if(azureOrdinaryOpaque) {
    *_10751 = 0;
  } else {
    int* _10755 = &material.alphaMode;
    int _10756 = *_10755;
    *_10751 = _10756;
  }

  int _10757 = *_10751;
  bool _10758 = _10757 != 0;
  bool _10759 = !_10758;
  
  if(_10759) {
    
    if(azureOrdinaryOpaque) {
      *_10762 = 0;
    } else {
      
      if(_10766) {
        *_10767 = azureFixedMaterialClass;
      } else {
        uint* _10771 = &material.materialClass;
        uint _10772 = *_10771;
        *_10767 = _10772;
      }

      uint _10773 = *_10767;
      *_10762 = _10773;
    }

    uint _10774 = *_10762;
    bool _10775 = _10774 != 0;
    
    if(_10775) {
      
      if(azureOrdinaryOpaque) {
        *_10778 = 0;
      } else {
        
        if(_10782) {
          *_10783 = azureFixedMaterialClass;
        } else {
          uint* _10787 = &material.materialClass;
          uint _10788 = *_10787;
          *_10783 = _10788;
        }

        uint _10789 = *_10783;
        *_10778 = _10789;
      }

      uint _10790 = *_10778;
      bool _10791 = _10790 != 8;
    }

    bool _10792 = Phi(_10775, _10791);
  }

  bool _10793 = Phi(_10758, _10792);
  bool _10794 = !_10793;
  
  if(_10794) {
    uint _10797 = *features;
    uint _10799 = _10797 & 262144;
    bool _10800 = _10799 == 0;
  }

  bool _10801 = Phi(_10793, _10800);
  bool _10802 = !_10801;
  
  if(_10802) {
    uint _10805 = *features;
    uint _10807 = _10805 & 1073479639;
    bool _10808 = _10807 != 0;
  }

  bool _10809 = Phi(_10801, _10808);
  
  if(_10809) {
    return false;
  }

  float* _10814 = &camera.qaParameters.x;
  float _10815 = *_10814;
  float _10816 = _10815 + 0.5000;
  float _10817 = GLSL.std.450::Floor(_10816);
  int _10818 = ConvertFToS(_10817);
  *isolation = _10818;
  float* _10820 = &camera.qaParameters.y;
  float _10821 = *_10820;
  float _10822 = _10821 + 0.5000;
  float _10823 = GLSL.std.450::Floor(_10822);
  int _10824 = ConvertFToS(_10823);
  *effect = _10824;
  float* _10826 = &camera.qaParameters.z;
  float _10827 = *_10826;
  bool _10828 = _10827 < 0.5000;
  *disabled = _10828;
  int _10829 = *isolation;
  bool _10830 = _10829 != 0;
  
  if(_10830) {
    return false;
  }

  uint* _10835 = &material.textureBase;
  uint _10836 = *_10835;
  uint _10837 = _10836 + 3;
  uint _10838 = CopyObject(_10837) : [[NonUniform]];
  SampledImage<float, 2D>* _10839 = &textureArray[_10838] : [[NonUniform]];
  SampledImage<float, 2D> _10840 = *_10839 : [[NonUniform]];
  float2 _10841 = *textureCoordinate;
  float4 _10842 = ImageSampleImplicitLod(_10840, _10841);
  float3 _10843 = _10842.xyz;
  float* _10844 = &material.emissiveStrength;
  float _10845 = *_10844;
  float3 _10846 = _10843 * _10845;
  uint _10847 = *features;
  uint _10848 = _10847 & 8;
  bool _10849 = _10848 != 0;
  float _10850 = Select(_10849, 1.0000, 0.0000);
  float3 _10851 = _10846 * _10850;
  *emission = _10851;
  int _10852 = *effect;
  bool _10853 = _10852 == 6;
  bool _10854 = *disabled;
  bool _10855 = _10853 && _10854;
  
  if(_10855) {
    *emission = {0.0000, 0.0000, 0.0000};
  }

  float4 _10859 = *baseColor@3;
  float3 _10860 = _10859.xyz;
  float3 _10861 = *emission;
  float3 _10862 = _10860 + _10861;
  float _10863 = _10862.x;
  float _10864 = _10862.y;
  float _10865 = _10862.z;
  float4 _10866 = CompositeConstruct({_10863, _10864, _10865, 1.0000});
  *outputColor = _10866;
  float _10868 = azureMaterialRadianceScale();
  *radianceScale@2 = _10868;
  float _10869 = *radianceScale@2;
  bool _10870 = _10869 != 1.0000;
  
  if(_10870) {
    float _10873 = *radianceScale@2;
    float4 _10874 = *outputColor;
    float3 _10875 = _10874.xyz;
    float3 _10876 = _10875 * _10873;
    float* _10878 = &outputColor.x;
    float _10879 = _10876.x;
    *_10878 = _10879;
    float* _10880 = &outputColor.y;
    float _10881 = _10876.y;
    *_10880 = _10881;
    float* _10882 = &outputColor.z;
    float _10883 = _10876.z;
    *_10882 = _10883;
  }

  uint* _10884 = &material.materialPadding;
  uint _10885 = *_10884;
  uint _10886 = _10885 & 1;
  bool _10887 = _10886 != 0;
  
  if(_10887) {
    float4 _10890 = *outputColor;
    float3 _10891 = _10890.xyz;
    float3 _10894 = CompositeConstruct({0.4200, 0.4200, 0.4200});
    float3 _10895 = GLSL.std.450::FMix(_10891, {0.9600, 0.6200, 0.1000}, _10894);
    float* _10896 = &outputColor.x;
    float _10897 = _10895.x;
    *_10896 = _10897;
    float* _10898 = &outputColor.y;
    float _10899 = _10895.y;
    *_10898 = _10899;
    float* _10900 = &outputColor.z;
    float _10901 = _10895.z;
    *_10900 = _10901;
  }

  float _10903 = *platformMask@2;
  float _10904 = 1.0000 - _10903;
  float* _10905 = &material.featureParameters.x;
  float _10906 = *_10905;
  float _10907 = _10904 * _10906;
  float* _10909 = &material.matcapColor.w;
  float _10910 = *_10909;
  float _10911 = GLSL.std.450::FClamp(_10910, 0.0000, 1.0000);
  float _10912 = GLSL.std.450::FMix(1.0000, 0.6800, _10911);
  float _10913 = _10907 * _10912;
  *participation = _10913;
  float* _10914 = &camera.clusterLighting.x;
  float _10915 = *_10914;
  bool _10916 = _10915 > 0.5000;
  
  if(_10916) {
    *participation = 0.0000;
  }

  float3 _10920 = *geometricNormal@2;
  float3 _10921 = _10920 * 0.5000;
  float3 _10922 = CompositeConstruct({0.5000, 0.5000, 0.5000});
  float3 _10923 = _10921 + _10922;
  float _10924 = *participation;
  float _10925 = _10923.x;
  float _10926 = _10923.y;
  float _10927 = _10923.z;
  float4 _10928 = CompositeConstruct({_10925, _10926, _10927, _10924});
  *outputNormal = _10928;
  *param@903 = 1.0000;
  azureWriteDisplayMask(param@903);
  return true;
}

bool azureWriteUnlitBlendBeauty(float4* baseColor@4, float3* geometricNormal@3, float* platformMask@3, float3* snapshotNormal, float* roughness@10) {
  uint* features@2;
  bool* param@904;
  uint* param@905;
  int* _10942;
  uint* _10953;
  uint* _10958;
  uint* _10969;
  uint* _10974;
  int* isolation@2;
  int* effect@2;
  float3* color@10;
  uint* param@906;
  float* alpha@8;
  PackedMaterialSurfaceProfile* p@17;
  float4* layered@3;
  PackedMaterialSurfaceProfile* param@907;
  float4* param@908;
  uint* gridX@2;
  uint* gridY@2;
  uint* gridZ@2;
  float2* screenUv@2;
  uint* clusterX@2;
  uint* clusterY@2;
  float* nearDepth@2;
  float* farDepth@2;
  float* viewDepth@2;
  float* logarithmicDepth@2;
  uint* clusterZ@2;
  uint2* range@3;
  uint* param@909;
  uint* param@910;
  uint* count@4;
  float* attenuation@4;
  uint* offset@12;
  uint* index@5;
  ClusterLight* light@14;
  bool* blend@6;
  SceneLightSample* lightSample;
  ClusterLight* param@911;
  float3* param@912;
  bool* param@913;
  float* weight@12;
  float* param@914;
  float* param@915;
  float2* param@916;
  float* radianceScale@3;
  float* param@917;
  float* participation@2;
  uint* _10934 = &material.materialFeatures;
  uint _10935 = *_10934;
  uint _10937 = _10935 & _10936;
  uint _10938 = _10937 | azureFixedMaterialFeatureValue;
  *param@904 = azureOrdinaryOpaque;
  *param@905 = _10938;
  uint _10941 = azureSpecializedMaterialFeatures(param@904, param@905);
  *features@2 = _10941;
  
  if(azureOrdinaryOpaque) {
    *_10942 = 0;
  } else {
    int* _10946 = &material.alphaMode;
    int _10947 = *_10946;
    *_10942 = _10947;
  }

  int _10948 = *_10942;
  bool _10949 = _10948 != 2;
  bool _10950 = !_10949;
  
  if(_10950) {
    
    if(azureOrdinaryOpaque) {
      *_10953 = 0;
    } else {
      
      if(_10957) {
        *_10958 = azureFixedMaterialClass;
      } else {
        uint* _10962 = &material.materialClass;
        uint _10963 = *_10962;
        *_10958 = _10963;
      }

      uint _10964 = *_10958;
      *_10953 = _10964;
    }

    uint _10965 = *_10953;
    bool _10966 = _10965 != 0;
    
    if(_10966) {
      
      if(azureOrdinaryOpaque) {
        *_10969 = 0;
      } else {
        
        if(_10973) {
          *_10974 = azureFixedMaterialClass;
        } else {
          uint* _10978 = &material.materialClass;
          uint _10979 = *_10978;
          *_10974 = _10979;
        }

        uint _10980 = *_10974;
        *_10969 = _10980;
      }

      uint _10981 = *_10969;
      bool _10982 = _10981 != 8;
    }

    bool _10983 = Phi(_10966, _10982);
  }

  bool _10984 = Phi(_10949, _10983);
  bool _10985 = !_10984;
  
  if(_10985) {
    uint _10988 = *features@2;
    uint _10989 = _10988 & 262144;
    bool _10990 = _10989 == 0;
  }

  bool _10991 = Phi(_10984, _10990);
  bool _10992 = !_10991;
  
  if(_10992) {
    uint _10995 = *features@2;
    uint _10997 = _10995 & 1056702423;
    bool _10998 = _10997 != 0;
  }

  bool _10999 = Phi(_10991, _10998);
  
  if(_10999) {
    return false;
  }

  float* _11004 = &camera.qaParameters.x;
  float _11005 = *_11004;
  float _11006 = _11005 + 0.5000;
  float _11007 = GLSL.std.450::Floor(_11006);
  int _11008 = ConvertFToS(_11007);
  *isolation@2 = _11008;
  float* _11010 = &camera.qaParameters.y;
  float _11011 = *_11010;
  float _11012 = _11011 + 0.5000;
  float _11013 = GLSL.std.450::Floor(_11012);
  int _11014 = ConvertFToS(_11013);
  *effect@2 = _11014;
  int _11015 = *isolation@2;
  bool _11016 = _11015 != 0;
  int _11017 = *effect@2;
  bool _11018 = _11017 != 0;
  bool _11019 = _11016 || _11018;
  
  if(_11019) {
    return false;
  }

  float4 _11024 = *baseColor@4;
  float3 _11025 = _11024.xyz;
  uint* _11026 = &material.textureBase;
  uint _11027 = *_11026;
  uint _11028 = _11027 + 3;
  uint _11029 = CopyObject(_11028) : [[NonUniform]];
  SampledImage<float, 2D>* _11030 = &textureArray[_11029] : [[NonUniform]];
  SampledImage<float, 2D> _11031 = *_11030 : [[NonUniform]];
  float2 _11032 = *textureCoordinate;
  float4 _11033 = ImageSampleImplicitLod(_11031, _11032);
  float3 _11034 = _11033.xyz;
  float* _11035 = &material.emissiveStrength;
  float _11036 = *_11035;
  float3 _11037 = _11034 * _11036;
  *param@906 = 8;
  float _11039 = materialFeatureEnabled(param@906);
  float3 _11040 = _11037 * _11039;
  float3 _11041 = _11025 + _11040;
  *color@10 = _11041;
  float* _11043 = &baseColor@4.w;
  float _11044 = *_11043;
  *alpha@8 = _11044;
  uint _11045 = *features@2;
  uint _11047 = _11045 & 16777216;
  bool _11048 = _11047 != 0;
  
  if(_11048) {
    uint* _11052 = &material.materialPadding;
    uint _11053 = *_11052;
    uint _11054 = _11053 >> 1;
    PackedMaterialSurfaceProfile* _11055 = &materialSurfaceProfiles.profiles[_11054];
    PackedMaterialSurfaceProfile _11056 = *_11055;
    float4[22] _11057 = _11056.rows;
    float4[22]* _11058 = &p@17.rows;
    float4 _11059 = _11057[0];
    float4* _11060 = &_11058[0];
    *_11060 = _11059;
    float4 _11061 = _11057[1];
    float4* _11062 = &_11058[1];
    *_11062 = _11061;
    float4 _11063 = _11057[2];
    float4* _11064 = &_11058[2];
    *_11064 = _11063;
    float4 _11065 = _11057[3];
    float4* _11066 = &_11058[3];
    *_11066 = _11065;
    float4 _11067 = _11057[4];
    float4* _11068 = &_11058[4];
    *_11068 = _11067;
    float4 _11069 = _11057[5];
    float4* _11070 = &_11058[5];
    *_11070 = _11069;
    float4 _11071 = _11057[6];
    float4* _11072 = &_11058[6];
    *_11072 = _11071;
    float4 _11073 = _11057[7];
    float4* _11074 = &_11058[7];
    *_11074 = _11073;
    float4 _11075 = _11057[8];
    float4* _11076 = &_11058[8];
    *_11076 = _11075;
    float4 _11077 = _11057[9];
    float4* _11078 = &_11058[9];
    *_11078 = _11077;
    float4 _11079 = _11057[10];
    float4* _11080 = &_11058[10];
    *_11080 = _11079;
    float4 _11081 = _11057[11];
    float4* _11082 = &_11058[11];
    *_11082 = _11081;
    float4 _11083 = _11057[12];
    float4* _11084 = &_11058[12];
    *_11084 = _11083;
    float4 _11085 = _11057[13];
    float4* _11086 = &_11058[13];
    *_11086 = _11085;
    float4 _11087 = _11057[14];
    float4* _11088 = &_11058[14];
    *_11088 = _11087;
    float4 _11089 = _11057[15];
    float4* _11090 = &_11058[15];
    *_11090 = _11089;
    float4 _11091 = _11057[16];
    float4* _11092 = &_11058[16];
    *_11092 = _11091;
    float4 _11093 = _11057[17];
    float4* _11094 = &_11058[17];
    *_11094 = _11093;
    float4 _11095 = _11057[18];
    float4* _11096 = &_11058[18];
    *_11096 = _11095;
    float4 _11097 = _11057[19];
    float4* _11098 = &_11058[19];
    *_11098 = _11097;
    float4 _11099 = _11057[20];
    float4* _11100 = &_11058[20];
    *_11100 = _11099;
    float4 _11101 = _11057[21];
    float4* _11102 = &_11058[21];
    *_11102 = _11101;
    PackedMaterialSurfaceProfile _11105 = *p@17;
    *param@907 = _11105;
    float4 _11107 = azureSampleUnlitSurface(param@907, param@908);
    float4 _11108 = *param@908;
    *baseColor@4 = _11108;
    *layered@3 = _11107;
    float4 _11109 = *layered@3;
    float3 _11110 = _11109.xyz;
    *color@10 = _11110;
    float* _11111 = &layered@3.w;
    float _11112 = *_11111;
    *alpha@8 = _11112;
    float* _11113 = &camera.nprLightingParameters.x;
    float _11114 = *_11113;
    bool _11115 = _11114 > 0.5000;
    
    if(_11115) {
      float* _11118 = &p@17.rows[15].w;
      float _11119 = *_11118;
      bool _11120 = _11119 > 1.5000;
    }

    bool _11121 = Phi(_11115, _11120);
    
    if(_11121) {
      float* _11125 = &camera.clusterGrid.x;
      float _11126 = *_11125;
      uint _11127 = ConvertFToU(_11126);
      uint _11128 = GLSL.std.450::UMax(_11127, 1);
      *gridX@2 = _11128;
      float* _11130 = &camera.clusterGrid.y;
      float _11131 = *_11130;
      uint _11132 = ConvertFToU(_11131);
      uint _11133 = GLSL.std.450::UMax(_11132, 1);
      *gridY@2 = _11133;
      float* _11135 = &camera.clusterGrid.z;
      float _11136 = *_11135;
      uint _11137 = ConvertFToU(_11136);
      uint _11138 = GLSL.std.450::UMax(_11137, 1);
      *gridZ@2 = _11138;
      float4 _11140 = *gl_FragCoord;
      float2 _11141 = _11140.xy;
      float4* _11142 = &camera.clusterDepth;
      float4 _11143 = *_11142;
      float2 _11144 = _11143.zw;
      float2 _11145 = GLSL.std.450::FMax(_11144, {1.0000, 1.0000});
      float2 _11146 = _11141 / _11145;
      *screenUv@2 = _11146;
      float* _11148 = &screenUv@2.x;
      float _11149 = *_11148;
      float _11151 = GLSL.std.450::FClamp(_11149, 0.0000, 1.0000);
      uint _11152 = *gridX@2;
      float _11153 = ConvertUToF(_11152);
      float _11154 = _11151 * _11153;
      uint _11155 = ConvertFToU(_11154);
      uint _11156 = *gridX@2;
      uint _11157 = _11156 - 1;
      uint _11158 = GLSL.std.450::UMin(_11155, _11157);
      *clusterX@2 = _11158;
      float* _11160 = &screenUv@2.y;
      float _11161 = *_11160;
      float _11162 = GLSL.std.450::FClamp(_11161, 0.0000, 1.0000);
      uint _11163 = *gridY@2;
      float _11164 = ConvertUToF(_11163);
      float _11165 = _11162 * _11164;
      uint _11166 = ConvertFToU(_11165);
      uint _11167 = *gridY@2;
      uint _11168 = _11167 - 1;
      uint _11169 = GLSL.std.450::UMin(_11166, _11168);
      *clusterY@2 = _11169;
      float* _11171 = &camera.clusterDepth.x;
      float _11172 = *_11171;
      float _11173 = GLSL.std.450::FMax(_11172, 0.0010);
      *nearDepth@2 = _11173;
      float* _11175 = &camera.clusterDepth.y;
      float _11176 = *_11175;
      float _11177 = *nearDepth@2;
      float _11178 = _11177 + 0.0010;
      float _11179 = GLSL.std.450::FMax(_11176, _11178);
      *farDepth@2 = _11179;
      float3 _11181 = *worldPosition;
      float4* _11182 = &camera.cameraPosition;
      float4 _11183 = *_11182;
      float3 _11184 = _11183.xyz;
      float3 _11185 = _11181 - _11184;
      float4* _11186 = &camera.cameraForward;
      float4 _11187 = *_11186;
      float3 _11188 = _11187.xyz;
      float _11189 = Dot(_11185, _11188);
      float _11190 = *nearDepth@2;
      float _11191 = GLSL.std.450::FMax(_11189, _11190);
      *viewDepth@2 = _11191;
      float _11193 = *viewDepth@2;
      float _11194 = *nearDepth@2;
      float _11195 = _11193 / _11194;
      float _11196 = GLSL.std.450::Log(_11195);
      float _11197 = *farDepth@2;
      float _11198 = *nearDepth@2;
      float _11199 = _11197 / _11198;
      float _11200 = GLSL.std.450::Log(_11199);
      float _11201 = _11196 / _11200;
      *logarithmicDepth@2 = _11201;
      float _11203 = *logarithmicDepth@2;
      float _11204 = GLSL.std.450::FClamp(_11203, 0.0000, 1.0000);
      uint _11205 = *gridZ@2;
      float _11206 = ConvertUToF(_11205);
      float _11207 = _11204 * _11206;
      uint _11208 = ConvertFToU(_11207);
      uint _11209 = *gridZ@2;
      uint _11210 = _11209 - 1;
      uint _11211 = GLSL.std.450::UMin(_11208, _11210);
      *clusterZ@2 = _11211;
      uint _11214 = *clusterZ@2;
      uint _11215 = *gridY@2;
      uint _11216 = _11214 * _11215;
      uint _11217 = *clusterY@2;
      uint _11218 = _11216 + _11217;
      uint _11219 = *gridX@2;
      uint _11220 = _11218 * _11219;
      uint _11221 = *clusterX@2;
      uint _11222 = _11220 + _11221;
      *param@909 = _11222;
      *param@910 = 3;
      uint2 _11225 = azureClusterLightRange(param@909, param@910);
      *range@3 = _11225;
      float* _11227 = &camera.clusterGrid.w;
      float _11228 = *_11227;
      float _11229 = GLSL.std.450::FMax(_11228, 0.0000);
      uint _11230 = ConvertFToU(_11229);
      *count@4 = _11230;
      *attenuation@4 = 1.0000;
      *offset@12 = 0;

      while(true) {
        uint _11238 = *offset@12;
        uint* _11239 = &range@3.y;
        uint _11240 = *_11239;
        bool _11241 = _11238 < _11240;
        if(!_11241) break;
        uint* _11247 = &range@3.x;
        uint _11248 = *_11247;
        uint _11249 = *offset@12;
        uint _11250 = _11248 + _11249;
        uint* _11251 = &clusterIndexData.indices[_11250];
        uint _11252 = *_11251;
        *index@5 = _11252;
        uint _11253 = *index@5;
        uint _11254 = *count@4;
        bool _11255 = _11253 >= _11254;
        
        if(_11255) {
          goto loop_continue5;
        }

        uint _11266 = *index@5;
        ClusterLight* _11268 = &sceneLightData.lights[_11266];
        ClusterLight _11269 = *_11268;
        float4 _11270 = _11269.positionRadius;
        float4* _11271 = &light@14.positionRadius;
        *_11271 = _11270;
        float4 _11272 = _11269.colorIntensity;
        float4* _11273 = &light@14.colorIntensity;
        *_11273 = _11272;
        float4 _11274 = _11269.directionOuter;
        float4* _11275 = &light@14.directionOuter;
        *_11275 = _11274;
        float4 _11276 = _11269.coneType;
        float4* _11277 = &light@14.coneType;
        *_11277 = _11276;
        float4[3] _11278 = _11269.boxRows;
        float4[3]* _11280 = &light@14.boxRows;
        float4 _11281 = _11278[0];
        float4* _11282 = &_11280[0];
        *_11282 = _11281;
        float4 _11283 = _11278[1];
        float4* _11284 = &_11280[1];
        *_11284 = _11283;
        float4 _11285 = _11278[2];
        float4* _11286 = &_11280[2];
        *_11286 = _11285;
        float4 _11287 = _11269.boxParameters;
        float4* _11288 = &light@14.boxParameters;
        *_11288 = _11287;
        float4 _11289 = _11269.characterResponse;
        float4* _11290 = &light@14.characterResponse;
        *_11290 = _11289;
        float* _11292 = &light@14.characterResponse.x;
        float _11293 = *_11292;
        bool _11294 = _11293 == 2.0000;
        bool _11295 = !_11294;
        
        if(_11295) {
          float* _11298 = &light@14.characterResponse.x;
          float _11299 = *_11298;
          bool _11300 = _11299 == 3.0000;
        }

        bool _11301 = Phi(_11294, _11300);
        *blend@6 = _11301;
        bool _11302 = *blend@6;
        bool _11303 = !_11302;
        bool _11304 = !_11303;
        
        if(_11304) {
          float* _11307 = &light@14.boxParameters.w;
          float _11308 = *_11307;
          uint _11309 = ConvertFToU(_11308);
          uint _11310 = _11309 & 2;
          bool _11311 = _11310 == 0;
        }

        bool _11312 = Phi(_11303, _11311);
        
        if(_11312) {
          goto loop_continue5;
        }

        float* _11318 = &light@14.characterResponse.x;
        float _11319 = *_11318;
        bool _11320 = _11319 == 3.0000;
        ClusterLight _11322 = *light@14;
        *param@911 = _11322;
        float3 _11324 = *worldPosition;
        *param@912 = _11324;
        *param@913 = _11320;
        SceneLightSample _11326 = sampleSceneLight(param@911, param@912, param@913);
        *lightSample = _11326;
        float* _11327 = &lightSample.attenuation;
        float _11328 = *_11327;
        bool _11329 = _11328 > 0.0001;
        
        if(_11329) {
          float3 _11333 = *geometricNormal@3;
          float3* _11334 = &lightSample.direction;
          float3 _11335 = *_11334;
          float _11336 = Dot(_11333, _11335);
          float* _11338 = &lightSample.attenuation;
          float _11339 = *_11338;
          *param@914 = _11339;
          *param@915 = _11336;
          float4* _11342 = &light@14.characterResponse;
          float4 _11343 = *_11342;
          float2 _11344 = _11343.yz;
          *param@916 = _11344;
          float _11345 = characterColorBlendWeight(param@914, param@915, param@916);
          *weight@12 = _11345;
          float _11346 = *weight@12;
          float _11347 = 1.0000 - _11346;
          float _11348 = *attenuation@4;
          float _11349 = _11348 * _11347;
          *attenuation@4 = _11349;
        }

loop_continue5:
        uint _11350 = *offset@12;
        uint _11351 = _11350 + 1;
        *offset@12 = _11351;
      }

      float _11352 = *attenuation@4;
      bool _11353 = _11352 < 1.0000;
      
      if(_11353) {
        float3 _11356 = *color@10;
        float _11357 = *attenuation@4;
        float3 _11358 = _11356 * _11357;
        float3 _11359 = _11358 + {0.0000, 0.0000, 0.0000};
        *color@10 = _11359;
      }

    }

  }

  float _11361 = azureMaterialRadianceScale();
  *radianceScale@3 = _11361;
  float _11362 = *radianceScale@3;
  bool _11363 = _11362 != 1.0000;
  
  if(_11363) {
    float _11366 = *radianceScale@3;
    float3 _11367 = *color@10;
    float3 _11368 = _11367 * _11366;
    *color@10 = _11368;
  }

  float3 _11369 = *color@10;
  float _11370 = *alpha@8;
  float _11371 = _11369.x;
  float _11372 = _11369.y;
  float _11373 = _11369.z;
  float4 _11374 = CompositeConstruct({_11371, _11372, _11373, _11370});
  *outputColor = _11374;
  uint* _11375 = &material.materialPadding;
  uint _11376 = *_11375;
  uint _11377 = _11376 & 1;
  bool _11378 = _11377 != 0;
  
  if(_11378) {
    float4 _11381 = *outputColor;
    float3 _11382 = _11381.xyz;
    float3 _11383 = CompositeConstruct({0.4200, 0.4200, 0.4200});
    float3 _11384 = GLSL.std.450::FMix(_11382, {0.9600, 0.6200, 0.1000}, _11383);
    float* _11385 = &outputColor.x;
    float _11386 = _11384.x;
    *_11385 = _11386;
    float* _11387 = &outputColor.y;
    float _11388 = _11384.y;
    *_11387 = _11388;
    float* _11389 = &outputColor.z;
    float _11390 = _11384.z;
    *_11389 = _11390;
    float* _11391 = &outputColor.w;
    *_11391 = 1.0000;
  }

  float* _11392 = &material.nodeOpacity;
  float _11393 = *_11392;
  float* _11394 = &outputColor.w;
  float _11395 = *_11394;
  float _11396 = _11395 * _11393;
  float* _11397 = &outputColor.w;
  *_11397 = _11396;
  float* _11399 = &outputColor.w;
  float _11400 = *_11399;
  *param@917 = _11400;
  azureWriteDisplayMask(param@917);
  float _11403 = *platformMask@3;
  float _11404 = 1.0000 - _11403;
  float* _11405 = &material.featureParameters.x;
  float _11406 = *_11405;
  float _11407 = _11404 * _11406;
  float* _11408 = &material.matcapColor.w;
  float _11409 = *_11408;
  float _11410 = GLSL.std.450::FClamp(_11409, 0.0000, 1.0000);
  float _11411 = GLSL.std.450::FMix(1.0000, 0.6800, _11410);
  float _11412 = _11407 * _11411;
  *participation@2 = _11412;
  float* _11413 = &camera.clusterLighting.x;
  float _11414 = *_11413;
  bool _11415 = _11414 > 0.5000;
  
  if(_11415) {
    *participation@2 = 0.0000;
  }

  float3 _11418 = *geometricNormal@3;
  float3 _11419 = _11418 * 0.5000;
  float3 _11420 = CompositeConstruct({0.5000, 0.5000, 0.5000});
  float3 _11421 = _11419 + _11420;
  float _11422 = *participation@2;
  float _11423 = _11421.x;
  float _11424 = _11421.y;
  float _11425 = _11421.z;
  float4 _11426 = CompositeConstruct({_11423, _11424, _11425, _11422});
  *outputNormal = _11426;
  return true;
}


