"""Complete the storage-buffer and pre-consumer evidence from the same capture."""
import os,sys,json,zlib,struct,hashlib,traceback
from pathlib import Path

KEY='AZR_PLAYER_WORKLIST_ROOT'
O=Path(os.environ[KEY]) if KEY in os.environ else Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
sha=lambda b:hashlib.sha256(b).hexdigest()

def worker():
    import renderdoc as rd
    source=read(O/'player/result.json');request=read(O/'request.json')
    cap=rd.OpenCaptureFile();ctl=None;r={'status':'incomplete'}
    try:
        assert cap.OpenFile(str(O/'capture/capture_frame1.rdc'),'',None)==rd.ResultCode.Succeeded
        options=rd.ReplayOptions();options.forceGPUVendor=rd.GPUVendor.nVidia;options.forceGPUDeviceID=0x28e0
        status,ctl=cap.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and ctl and not ctl.GetAPIProperties().degraded
        assert ctl.GetFrameInfo().frameNumber==1
        event=source['traceEvent'];ctl.SetFrameEvent(event,True)
        pipe=ctl.GetPipelineState();ref=pipe.GetShaderReflection(rd.ShaderStage.Compute)
        assert sha(bytes(ref.rawBytes))==request['playerTraceShader']
        used=[(u,ref.readWriteResources[u.access.index]) for u in pipe.GetReadWriteResources(rd.ShaderStage.Compute)]
        u,d=next((u,d) for u,d in used if d.name=='worklist')
        descriptor=u.descriptor
        buffers={b.resourceId:b for b in ctl.GetBuffers()};b=buffers[descriptor.resource]
        size=min(descriptor.byteSize,b.length-descriptor.byteOffset)
        assert 0<size<=1_000_000 and size%4==0
        after=bytes(ctl.GetBufferData(b.resourceId,descriptor.byteOffset,size))
        ctl.SetFrameEvent(event-1,True)
        before=bytes(ctl.GetBufferData(b.resourceId,descriptor.byteOffset,size))
        assert before==after
        def walk(rows):
            for row in rows:
                yield row
                yield from walk(row.children)
        action=next(a for a in walk(ctl.GetRootActions()) if a.eventId==event)
        groups=list(action.dispatchDimension);assert groups[1:]==[1,1]
        words=struct.unpack('<'+'I'*(len(after)//4),after)
        active=words[:groups[0]]
        tiles=[(v>>16,v&65535) for v in active]
        assert len(set(tiles))==len(tiles)
        assert all(x<160 and y<90 for x,y in tiles)
        assert len(tiles)==160*90
        (O/'worklist.zlib').write_bytes(zlib.compress(after,6))
        r.update(frameNumber=1,traceEvent=event,traceShader=sha(bytes(ref.rawBytes)),
            resource=str(b.resourceId),binding=d.fixedBindNumber,apiCategory='readWriteResources',
            declaredSourceType='StructuredBuffer<uint>',offset=descriptor.byteOffset,bytes=len(after),
            sha256=sha(after),beforeSha256=sha(before),file='worklist.zlib',dispatch=groups,
            activeTiles=len(tiles),uniqueTiles=len(set(tiles)),fullTraceCoverage=True,
            localSize=[8,8,1],traceExtent=[1280,720],
            anchors=[dict(displayXY=xy,tile=[xy[0]//16,xy[1]//16],
                covered=(xy[0]//16,xy[1]//16) in tiles) for xy in request['points']])
        consumer=source['consumers'][0]
        ctl.SetFrameEvent(consumer['event'],True)
        target=ctl.GetPipelineState().GetOutputTargets()[0].resource
        texture=next(t for t in ctl.GetTextures() if t.resourceId==target)
        assert texture.format.Name()=='R16G16B16A16_FLOAT'
        ctl.SetFrameEvent(consumer['event']-1,True)
        raw=bytes(ctl.GetTextureData(target,rd.Subresource()))
        assert len(raw)==2560*1440*8
        rect=[996,956,1585,1405];x,y,u,v=rect
        cropped=b''.join(raw[(j*2560+x)*8:(j*2560+u)*8] for j in range(y,v))
        (O/'hdr-before.zlib').write_bytes(zlib.compress(cropped,6))
        r['consumerBefore']=dict(event=consumer['event']-1,resource=str(target),format=texture.format.Name(),
            width=2560,height=1440,rect=rect,file='hdr-before.zlib',sha256=sha(cropped),fullSha256=sha(raw),
            pixels=[list(struct.unpack_from('<4e',raw,(yy*2560+xx)*8)) for xx,yy in request['points']])
        r['status']='qualified-same-capture-worklist-and-consumer-before'
    except BaseException:
        r['error']=traceback.format_exc()
    finally:
        write(O/'worklist.json',r)
        if ctl:ctl.Shutdown()
        cap.Shutdown()
    os._exit(0 if r['status'].startswith('qualified') else 1)

if KEY in os.environ:worker()
else:
    import subprocess
    sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
    import artifact_budget,artifact_maintenance as art
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==O
    budget=artifact_budget.check(O.parents[2]/'build',run=O,planned=3_000_000)
    assert budget['allowed'],budget
    env=art.managed_environment(O/'tmp');env[KEY]=str(O)
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    with (O/'worklist-replay.log').open('wb') as log:
        process=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(O/'read_worklist.py')],
            env=env,cwd=O,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=120)
    result=read(O/'worklist.json')
    assert process.returncode==0 and result['status'].startswith('qualified'),result.get('error')
    print(result['status'],result['dispatch'],result['activeTiles'])
