"""Join recorded leaf counters with actual descriptor eligibility, by stage."""
from pathlib import Path
import json,hashlib,re,subprocess,zipfile

run=Path(__file__).resolve().parent
repo=Path('D:/Projects/FYP');engine=repo/'Project/AzureRender'
capture=engine/'build/runs/20261111-001050-quad-feature-device-capture-4798d1'
current=engine/'build/runs/20261119-180745-mainline-joint-consumer-attribution-b0a9c4'

def read(p):return json.loads(Path(p).read_bytes())
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def empty():return dict(draws=0,invocations=0,passedSamples=0,zeroInvocationDraws=0,recordedReplayEventMs=0.)
def add(t,ev):
    t['draws']+=1;t['invocations']+=ev['ps'];t['passedSamples']+=ev['samplesPassed']
    t['zeroInvocationDraws']+=ev['ps']==0;t['recordedReplayEventMs']+=ev['milliseconds']

metadata=read(run/'eligibility-metadata.json');assert metadata['status']=='inspected',metadata
groups=read(capture/'pipeline-scope.json')['groups']
pixels={p['event']:p for p in read(capture/'profile-state.json')['pixelEvents']}
descriptors={p['pipeline']:p for p in metadata['pipelines']}
canonical=re.compile(r'^(mesh|character_snapshot)(_object)?_bindless(_clipmap)?(_field)?(_early)?(_lighting)?(_coverage)?\.frag\.spv$')
totals={};eligible={};reasons={};eventRows=[];programs=set()
seen=set()
for group in groups:
    desc=descriptors.get(group['pipeline'])
    if not desc:continue
    stage='snapshot-color' if desc['program'].startswith('character_snapshot') else 'main-color'
    spec={p['id']:p['valueU32'] for p in desc['specialization']}
    kind='ordinary' if spec.get(0)==1 else 'fixed' if spec.get(1,4294967295)!=4294967295 else 'dynamic'
    reason='eligible-material-descriptor'
    if kind=='dynamic':reason='dynamic-material-fallback'
    elif desc['alphaBlend']:reason='alpha-blend-fallback'
    elif not desc['depthTest']:reason='depth-test-fallback'
    elif desc['depthFunction'] not in ['CompareFunction.Less','CompareFunction.LessEqual','CompareFunction.Equal']:reason='depth-compare-fallback'
    elif not canonical.fullmatch(desc['program']):reason='program-fallback'
    ok=reason=='eligible-material-descriptor'
    if ok:programs.add(desc['program'])
    for event in desc['events']:
        assert event not in seen;seen.add(event)
        ev=pixels[event];assert not ev['hasChildren']
        add(totals.setdefault(stage+'/'+kind,empty()),ev)
        add(reasons.setdefault(reason,empty()),ev)
        if ok:add(eligible.setdefault(stage+'/'+kind,empty()),ev)
        eventRows.append(dict(event=event,pipeline=group['pipeline'],stage=stage,materialKind=kind,
            descriptorEligible=ok,reason=reason,invocations=ev['ps'],passedSamples=ev['samplesPassed'],recordedReplayEventMs=ev['milliseconds']))
assert len(seen)==1006,len(seen)
eligiblePs=sum(v['invocations'] for v in eligible.values())
fixedMain=eligible.get('main-color/fixed',empty())
mainPs=sum(v['invocations'] for k,v in eligible.items() if k.startswith('main-color/'))
currentAnalysis=read(current/'analysis.json');now=read(current/'timing.json');old=read(capture/'runtime-timing.json')
oldInputs=read(capture/'frozen-project-inputs.json');currentInputs=read(current/'input-verification.json')['files']
assert oldInputs==currentInputs and len(oldInputs)==1729
sourceFiles=['shaders/mesh.frag','src/render/ComputedMaterialView.hpp','src/scenes/CharacterComputedMaterialView.inc','src/scenes/CharacterMaterialSampling.inc','CMakeLists.txt']
sourceDigests={}
for name in sourceFiles:
    data=subprocess.check_output(['git','show','e1fea0a:Project/AzureRender/'+name],cwd=repo)
    path=run/'source'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    assert (engine/name).read_bytes().replace(b'\r\n',b'\n')==data.replace(b'\r\n',b'\n'),name
    sourceDigests[name]=digest(path)
shader=(run/'source/shaders/mesh.frag').read_text()
body=shader[shader.index('void prepareShadowReceiver()'):shader.index('float sampleShadowMap(')]
assert all(('const int i='+str(i)) in body for i in range(4))
assert body.count('dFdx(uv)')==body.count('dFdy(uv)')==body.count('dFdx(p.z)')==body.count('dFdy(p.z)')==4
write(run/'event-classification.json',eventRows)
sharedKeys=['sceneTriangles','uniqueMeshes','snapshotRasterizationSamples','objectShadowPrepared','conservativeOcclusionPrepared','irradianceResourceKind','irradianceQueryScope','materialClassFeatureSpecializations']
assert all(now[k]==old[k] for k in sharedKeys)
nativeScope=dict(baseline=currentAnalysis['baseline'],sampleCount=240,gpu=currentAnalysis['gpuFrame'],passes=currentAnalysis['passes'],
    mainAndSnapshot=currentAnalysis['mainAndSnapshot'],perMaterialInvocationCounts=None,
    scopeWarning='Native timings are current 1080p evidence. Per-material counters are historical 720p evidence; no rescaling or per-class native timing inference.')
result=dict(baseline='e1fea0ae8f2a362311949abc8bf219e0ee2009a1',
    decision='RejectCurrentAdoptionBatch', productionConfiguration='unchanged; AZURE_ENABLE_COMPUTED_MATERIAL_VIEW=OFF',
    sourceSha256=sourceDigests,
    historicalCounterScope=dict(source='73300ab',dimensions=[1280,720],captureSha256=metadata['captureSha256'],frame=320,
        inputCount=1729,inputsMatchCurrent=True,structuralInputsMatch=sharedKeys,
        guard='Descriptor eligibility assumes supported device, current-view eligibility, loaded-material policy and optional programs. Per-pixel counts remain historical.'),
    observedMaterialTotals=totals, descriptorEligible=eligible, fallbackReasons=reasons,
    eligiblePrograms=sorted(programs),eligibleInvocations=eligiblePs,
    quadDepthSkipInvocationUpperBound=dict(
        mechanism='Only non-ordinary main-color alpha-mask draws can discard complete hidden quads',
        upperBoundIncludesAllFixedMainInvocations=True,
        invocations=fixedMain['invocations'],fractionOfEligibleMainInvocations=fixedMain['invocations']/mainPs,
        fractionOfEligibleCombinedInvocations=fixedMain['invocations']/eligiblePs,
        warning='Loose upper bound for this mechanism in the recorded frame, not an instruction-time or whole-candidate savings bound. Retains even passed samples in the bound.'),
    repeatedOperations=dict(cascadesPerSurvivingInvocation=4,sourceDerivativeCallsPerCascade=4,
        scalarDerivativeResultsPerCascade=6,sourceDerivativeCallsPerSurvivingInvocation=16,
        scalarDerivativeResultsPerSurvivingInvocation=24,
        sourceDerivativeResultUpperBound=eligiblePs*24,
        guaranteedCrossPassDerivativeEliminations=0,
        reusedPixelIdentityMeasured=False,
        overlapUpperBound=min(sum(v['invocations'] for k,v in eligible.items() if k.startswith('main-color/')),sum(v['invocations'] for k,v in eligible.items() if k.startswith('snapshot-color/'))),
        warning='Invocation sums across passes are work counts, not unique pixels. No guaranteed redundant-pixel overlap or hardware instruction-time saving is inferred.'),
    catalog=dict(active=897,fullAdditional=128,fullTotal=1025,limit=1024,
        observedDescriptorSubsetAdditional=len(programs),observedDescriptorSubsetTotal=897+len(programs),
        subsetScope='Canonical program names observed in this material/descriptor domain; excludes other projects, view modes and device fallback paths. Enumeration only, no build or coverage claim.'),
    nativeScope=nativeScope,
    nativeTimeUpperBounds=dict(fullTargetPassesMs=currentAnalysis['mainAndSnapshot']['mean'],
        quadDepthSkipOnlyMs=currentAnalysis['passes']['character-main']['mean'],
        meaning='Deliberately loose zero-to-entire-pass ceilings; no expected gain or per-material cost is established.'),
    admission=dict(currentHotspotLocated=True,currentScopedWorkReductionProven=False,currentExpectedWholeFrameSavingProven=False,
        fullCatalogFits=False,subsetCatalogEnumerationFits=897+len(programs)<=1024,
        qualifiedForImplementation=False,
        reason='Full family violates capacity. Descriptor-scoped subset can fit by enumeration but lacks current matching material cost and expected >=20% workload or >=3 ms GPU benefit. Historical gains are directional evidence only.'),
    retryConditions=['Source-matched current per-material cost or auditable operation evidence meets the AGENT.md gate',
        'Scoped shader family fits 1024 while preserving documented material/view/device fallback',
        'One associated implementation and concentrated compatibility, appearance and same-source paired timing batch'],
    diagnosticScope='One descriptor-inspection hypothesis; initial embedded-script bootstrap failure repaired before effective capture replay; no new candidate frame timing')
write(run/'analysis.json',result)
print(json.dumps({k:result[k] for k in ['observedMaterialTotals','descriptorEligible','fallbackReasons','quadDepthSkipInvocationUpperBound','catalog','admission']},ensure_ascii=False,indent=2))
