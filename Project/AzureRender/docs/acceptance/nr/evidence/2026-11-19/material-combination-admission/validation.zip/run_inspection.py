from pathlib import Path
import hashlib,json,os,subprocess

run=Path(__file__).resolve().parent
capture=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261111-001050-quad-feature-device-capture-4798d1/current_frame320.rdc')
with capture.open('rb') as f:before=hashlib.file_digest(f,'sha256').hexdigest()
assert before=='35077c571bcb70bc99688bfb97eec1b291bd6567df7482746fd3f5db49f339b3'
env=os.environ.copy();env['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(run/'inspect_eligibility.py')]
(run/'diagnostic-command.json').write_text(json.dumps(dict(command=command,purpose='Historical descriptor eligibility only',timeout=240),indent=2),encoding='utf-8')
with (run/'inspection.log').open('wb') as log:
    result=subprocess.run(command,env=env,cwd=run,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=240)
assert result.returncode==0,result.returncode
assert json.loads((run/'eligibility-metadata.json').read_text())['status']=='inspected'
with capture.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==before
print('Historical descriptor eligibility inspected; no new frame timing')
