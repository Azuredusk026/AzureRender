"""Inspect descriptor eligibility in the resident historical capture only."""
from pathlib import Path
import hashlib,json,traceback,sys
import renderdoc as rd

run=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261119-182752-material-combination-admission-b54fae')
source=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261111-001050-quad-feature-device-capture-4798d1')
scope=json.loads((source/'pipeline-scope.json').read_text())
capture=json.loads((source/'state.json').read_text())
report=dict(status='starting',sourceBase='73300ab',captureSha256=capture['captureSha256'],
    purpose='Test whether material-specialized draw totals include alpha-blended fallback pipelines; inspect existing capture descriptors, reuse recorded leaf counters',
    timingScope='No new native or replay timings; metadata only',pipelines=[])
cap=None;controller=None

def attrs(value):
    result={}
    for name in dir(value):
        if name.startswith('_') or name in ('this','thisown'):continue
        try:v=getattr(value,name)
        except Exception:continue
        if callable(v):continue
        if isinstance(v,(bool,int,float,str)):result[name]=v
        else:result[name]=str(v)
    return result

def flag(value,*names):
    for name in names:
        if hasattr(value,name):return bool(getattr(value,name))
    raise ValueError('Missing flag '+str(names)+' in '+str(attrs(value)))

try:
    (run/'eligibility-metadata.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    cap=rd.OpenCaptureFile()
    assert cap.OpenFile(capture['capture'],'',None)==rd.ResultCode.Succeeded
    status,controller=cap.OpenCapture(rd.ReplayOptions(),None)
    assert status==rd.ResultCode.Succeeded,status
    for group in scope['groups']:
        shader=next((s for s in group.get('shaders',[]) if s['stage']=='ShaderStage.Pixel'),None)
        if not shader:continue
        names=[n for n in shader['programFiles'] if n.startswith(('mesh_object_bindless','character_snapshot_object_bindless'))]
        if not names:continue
        event=group['representativeEvent']
        controller.SetFrameEvent(event,True)
        pipe=controller.GetPipelineState()
        assert str(pipe.GetGraphicsPipelineObject())==group['pipeline']
        vk=controller.GetVulkanPipelineState()
        blends=pipe.GetColorBlends()
        ds=vk.depthStencil
        row=dict(pipeline=group['pipeline'],event=event,program=names[0],events=group['events'],
            specialization=group.get('specialization',[]),depthStencil=attrs(ds),
            blends=[attrs(v) for v in blends],alphaBlend=any(flag(v,'enabled','blendEnable') for v in blends),
            depthTest=flag(ds,'depthTestEnable','depthEnable'),
            depthFunction=str(getattr(ds,'depthFunction')))
        report['pipelines'].append(row)
        (run/'eligibility-metadata.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    report.update(status='inspected',pipelineCount=len(report['pipelines']))
except Exception:
    report.update(status='failed',error=traceback.format_exc())
finally:
    if controller:controller.Shutdown()
    if cap:cap.Shutdown()
    (run/'eligibility-metadata.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
sys.exit(0 if report['status']=='inspected' else 1)
