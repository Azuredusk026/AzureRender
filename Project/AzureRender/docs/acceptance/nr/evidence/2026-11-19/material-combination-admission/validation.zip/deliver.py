from pathlib import Path
import hashlib,json,re,sqlite3,subprocess,zipfile,time

run=Path(__file__).resolve().parent;repo=Path('D:/Projects/FYP');engine=repo/'Project/AzureRender'
capture=engine/'build/runs/20261111-001050-quad-feature-device-capture-4798d1'
native=engine/'build/runs/20261119-180745-mainline-joint-consumer-attribution-b0a9c4'
destination=engine/'docs/acceptance/nr/evidence/2026-11-19/material-combination-admission'
destination.mkdir(parents=True,exist_ok=True)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
analysis=json.loads((run/'analysis.json').read_bytes())
assert analysis['decision']=='RejectCurrentAdoptionBatch'
assert analysis['fallbackReasons']['eligible-material-descriptor']['draws']==954
assert analysis['eligibleInvocations']==2029250
assert analysis['quadDepthSkipInvocationUpperBound']['fractionOfEligibleCombinedInvocations']<.20
assert analysis['catalog']['observedDescriptorSubsetTotal']==907
events=json.loads((run/'event-classification.json').read_bytes())
assert len(events)==len({p['event'] for p in events})==1006
assert sum(p['invocations'] for p in events if p['descriptorEligible'])==2029250
protected=json.loads((run/'protected-workspace.json').read_bytes())
assert all(digest(repo/n)==h for n,h in protected.items())
write(run/'protected-workspace-verification.json',dict(files=len(protected),changed=[]))
with sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True) as db:
    db.row_factory=sqlite3.Row
    jobs=[dict(v) for v in db.execute('SELECT * FROM jobs WHERE id IN (2239,2241) ORDER BY id')]
assert len(jobs)==2 and jobs[0]['state']=='failed' and jobs[1]['state']=='succeeded'
write(run/'dispatch.json',jobs)
elapsed=time.time()-run.stat().st_ctime
write(run/'execution-budget.json',dict(defaultExplorationSeconds=1800,elapsedSinceReservationSeconds=elapsed,
    defaultWallBudgetExceeded=elapsed>1800,includesQueueAndDiagnosticSetup=True,
    disposition='Exploration closed; no additional candidate measurements; retain explicit retry conditions',
    guardedDiagnosticTimeoutSeconds=270,effectiveInspectionCount=1))
doc=engine/'docs/acceptance/nr/material-combination-admission.md'
text=doc.read_text(encoding='utf-8')
assert all(s in text for s in ['2,029,250','132,190','6.51%','907','1,025'])
long=[]
for i,line in enumerate(text.splitlines(),1):
    for sentence in re.split('[。！？]',line):
        if len(re.findall('[\u4e00-\u9fff]',sentence))>45:long.append(i)
assert not long,long
mapping={n:run/n for n in ['analyze.py','inspect_eligibility.py','run_inspection.py','deliver.py','budget.json',
    'eligibility-metadata.json','event-classification.json','analysis.json','historical-qualification-scopes.json',
    'diagnostic-command.json','inspection.log','process.log','dispatch.json','execution-budget.json','protected-workspace-verification.json',
    'setup-error/observed-error.json','setup-error/process.log','setup-error/diagnostic-command.json']}
for p in (run/'source').rglob('*'):
    if p.is_file():mapping[p.relative_to(run).as_posix()]=p
for n in ['pipeline-scope.json','profile-state.json','state.json','runtime-timing.json','frozen-project-inputs.json']:
    mapping['historical/'+n]=capture/n
for n in ['analysis.json','timing.json','input-verification.json']:
    mapping['native/'+n]=native/n
manifest={n:dict(sha256=digest(p),bytes=p.stat().st_size) for n,p in mapping.items()}
archive=destination/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in mapping.items():z.write(p,n)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(mapping)+1
    for n,m in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==m['sha256']
summary=dict(schemaVersion=1,**analysis,run=str(run),dispatchIds=[2239,2241],successfulDiagnostic=2241,
    inspectionPipelineCount=34,protectedFiles=len(protected),runtimeChanges=False,
    executionBudget=json.loads((run/'execution-budget.json').read_bytes()),
    checks=dict(leafCountersJoined=True,uniqueMaterialEvents=1006,sourceInputsMatched=True,
        nativePerMaterialInvocationCounts=False,currentCandidateFrameTiming=False,
        localLinks=True,chineseSentenceLength=True,archiveManifestVerified=True),
    archive=dict(path='validation.zip',sha256=digest(archive),members=len(mapping)+1,bytes=archive.stat().st_size),
    currentNativeArchiveSha256='b92571bd53dea3dac657dc1f9a8d155bae76fe52fdc83dce23542afb3f5e6c44')
write(destination/'results.json',summary)
links=re.findall(r'\]\(([^)]+)\)',text)
assert all((doc.parent/n).exists() for n in links),links
print(json.dumps(dict(decision=summary['decision'],eligibleInvocations=summary['eligibleInvocations'],
    joinedEvents=1006,protectedFiles=len(protected),archive=summary['archive'],links=len(links)),ensure_ascii=False,indent=2))
