"""One bounded native profile; preserve source and input provenance."""
from pathlib import Path
import hashlib, json, os, subprocess, sys, time, zipfile

run = Path(__file__).resolve().parent
repo = Path('D:/Projects/FYP')
engine = repo / 'Project/AzureRender'
source = Path('D:/Projects/FYP-worktrees/performance-editor-36871ff-candidate/Project/AzureRender')
build = source / 'build/mainline-qualification-release'
binary = build / 'AzurePlayer.exe'
owner = '01a1d0a8-a74c-7cc0-85e8-540a6653098a'
sys.path.insert(0, str(engine / 'tools'))
import shared_resources as shared

def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)

def write(name, data):
    (run/name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

def main():
    assert digest(binary) == '50bbae05ede60c6aebc301b388d2f8a75914eb7391ab1f459ea766f653d82e39'
    baseline = git('rev-parse', '5fccef9').decode().strip()
    source_base = git('rev-parse', '803e42a').decode().strip()
    mismatches, hashes = [], {}
    for entry in git('ls-tree', '-rz', source_base, '--', 'Project/AzureRender/src', 'Project/AzureRender/shaders', 'Project/AzureRender/third_party').split(b'\0'):
        if not entry: continue
        header, name = entry.split(b'\t', 1)
        rel = name.decode().removeprefix('Project/AzureRender/')
        p = source/rel
        if not p.is_file():
            mismatches.append(rel); continue
        raw = p.read_bytes()
        normalized = raw.replace(b'\r\n', b'\n')
        blobs = [hashlib.sha1(b'blob '+str(len(v)).encode()+b'\0'+v).hexdigest() for v in (raw, normalized)]
        if header.split()[-1].decode() not in blobs: mismatches.append(rel)
        hashes[rel] = hashlib.sha256(raw).hexdigest()
    write('source-inputs.json', dict(baseline=baseline, builtSourceBase=source_base, mismatches=mismatches, files=hashes,
        baselineDifferences=git('diff', '--name-only', source_base, baseline, '--', 'Project/AzureRender/src', 'Project/AzureRender/shaders').decode().splitlines()))
    assert not mismatches, mismatches
    token = shared.acquire_inputs(engine/'build', run, ['20261103-234012-character-reference-stages-5abe6c'], owner)
    write('input-lease.json', dict(token=token, owner=owner))
    try:
        with zipfile.ZipFile(engine/'docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope/validation.zip') as z:
            frozen = json.loads(z.read('run/frozen-project-inputs.json'))
        errors = [name for name, expected in frozen.items() if digest(name) != expected]
        write('input-verification.json', dict(count=len(frozen), errors=errors, files=frozen))
        assert not errors, errors
        shaders = {str(p.relative_to(build)):digest(p) for p in (build/'shaders').rglob('*.spv')}
        assert len(shaders) == 897, len(shaders)
        write('product.json', dict(binary=str(binary), sha256=digest(binary), shaders=shaders,
            cacheComputedMaterialView=[line for line in (build/'CMakeCache.txt').read_text().splitlines() if line.startswith('AZURE_ENABLE_COMPUTED_MATERIAL_VIEW:')]))
        query = ['C:/Windows/System32/nvidia-smi.exe','--query-gpu=driver_version,name,temperature.gpu,power.draw,clocks.gr,clocks.mem,pstate','--format=csv,noheader']
        before = subprocess.check_output(query, text=True).strip()
        assert before.startswith('595.79'), before
        command = [str(binary), '--resource-root', str(build), '--project', str(engine/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'),
            '--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','60','--smoke-frames','360',
            '--gpu-timing','--gpu-pass-timing','--gpu-timing-output',str(run/'timing.json')]
        write('command.json', dict(command=command, baseline=baseline, purpose='Current-source native pass attribution; no candidate comparison or formal FPS claim', frames=360, analysisWarmup=120))
        env = os.environ.copy()
        env['VK_LOADER_DRIVERS_SELECT'] = '*nv-vk64*'
        for k in list(env):
            if k.startswith('AZURE_DIAGNOSTIC_'): del env[k]
        started = time.time()
        with (run/'player.log').open('wb') as log:
            result = subprocess.run(command, cwd=build, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=480)
        write('environment.json', dict(before=before, after=subprocess.check_output(query,text=True).strip(), exitCode=result.returncode, elapsed=time.time()-started))
        assert result.returncode == 0, result.returncode
        assert digest(binary) == '50bbae05ede60c6aebc301b388d2f8a75914eb7391ab1f459ea766f653d82e39'
        assert all(digest(name) == h for name,h in frozen.items())
        print('Native attribution completed', flush=True)
    finally:
        shared.release_inputs(engine/'build', token, owner)

if __name__ == '__main__': main()
