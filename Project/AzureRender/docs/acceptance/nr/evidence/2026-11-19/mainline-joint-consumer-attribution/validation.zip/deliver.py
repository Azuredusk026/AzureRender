from pathlib import Path
from hashlib import sha256
import csv, json, re, sqlite3, subprocess, zipfile

run = Path(__file__).resolve().parent
repo = Path('D:/Projects/FYP')
engine = repo/'Project/AzureRender'
destination = engine/'docs/acceptance/nr/evidence/2026-11-19/mainline-joint-consumer-attribution'
destination.mkdir(parents=True, exist_ok=True)

def digest(p): return sha256(Path(p).read_bytes()).hexdigest()
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

with sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True) as db:
    db.row_factory=sqlite3.Row
    jobs=[dict(row) for row in db.execute('SELECT * FROM jobs WHERE id IN (2234,2235) ORDER BY id')]
assert len(jobs)==2 and jobs[0]['state']=='failed' and jobs[1]['state']=='succeeded'
write(run/'dispatch.json',jobs)
analysis=json.loads((run/'analysis.json').read_bytes())
assert analysis['gpuFrame']['samples']==240 and analysis['cpuWork']['samples']==240
assert analysis['candidate']['hotspotGate'] and analysis['candidate']['currentWorkReduction'] is None
assert analysis['catalogScope']['expectedOptInCount']==1025
assert not json.loads((run/'source-inputs.json').read_bytes())['mismatches']
assert not json.loads((run/'input-verification.json').read_bytes())['errors']
assert 'Allocator after unload: buffers=0 images=0' in (run/'player.log').read_text()
assert json.loads((run/'environment.json').read_bytes())['exitCode']==0
protected=json.loads((run/'protected-workspace.json').read_bytes())
changed=[n for n,h in protected.items() if not (repo/n).is_file() or digest(repo/n)!=h]
write(run/'protected-workspace-verification.json',dict(files=len(protected),changed=changed))
assert not changed, changed
doc=engine/'docs/acceptance/nr/mainline-joint-consumer-attribution.md'
# The archive is published below; every other local link must already resolve.
links=re.findall(r'\]\(([^)]+)\)',doc.read_text(encoding='utf-8'))
missing=[n for n in links if not n.startswith('http') and not (doc.parent/n).exists() and not n.endswith(('results.json','validation.zip'))]
assert not missing,missing
selection=['diagnose.py','analyze.py','deliver.py','budget.json','command.json','environment.json','source-inputs.json','product.json',
    'input-verification.json','reused-build-receipt.json','candidate-catalog-scope.json','analysis.json','player.log','process.log','timing.csv','timing.json',
    'timing.passes.jsonl','dispatch.json','protected-workspace-verification.json',
    'startup-timeout/command.json','startup-timeout/player.log','startup-timeout/process.log']
manifest={n:dict(sha256=digest(run/n),bytes=(run/n).stat().st_size) for n in selection}
archive=destination/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in selection:z.write(run/name,name)
    z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(selection)|{'manifest.json'}
    for name,meta in manifest.items(): assert sha256(z.read(name)).hexdigest()==meta['sha256'],name
summary=dict(schemaVersion=1, baseline=analysis['baseline'], unitState='AttributionComplete',
    candidateState='NotQualifiedForImplementation', runtimeChanges=False,
    run=str(run), dispatchIds=[2234,2235], successfulDispatch=2235,
    gpuFrame=analysis['gpuFrame'], cpuWork=analysis['cpuWork'], passes=analysis['passes'],
    mainAndSnapshot=analysis['mainAndSnapshot'],
    passScope='character-opaque-depth measures the entire snapshot color-and-depth pass',
    candidate=analysis['candidate'], catalogScope=analysis['catalogScope'],
    sourceInputCount=890, frozenInputCount=1729, activeShaderPrograms=897,
    executableSha256='50bbae05ede60c6aebc301b388d2f8a75914eb7391ab1f459ea766f653d82e39',
    driver='595.79', startup=dict(firstTimeoutSeconds=180,retryTimeoutSeconds=480,retryElapsedSeconds=analysis['environment']['elapsed']),
    protectedWorkspace=dict(files=len(protected),changed=changed),
    archive=dict(path='validation.zip',sha256=digest(archive),bytes=archive.stat().st_size,members=len(selection)+1,verified=True),
    evidenceScope='One bounded native profiling diagnostic and candidate review; existing mainline acceptance is reused within its recorded source and input scope')
write(destination/'results.json',summary)
for name in links: assert (doc.parent/name).exists(),name
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo).decode().splitlines()
owned={str(p.relative_to(repo)).replace('\\','/') for p in [doc,engine/'README.md',destination/'results.json',archive]}
assert set(staged)<=owned,staged
print(json.dumps(dict(evidence=str(destination),archive=summary['archive'],protected=len(protected),links=len(links)),ensure_ascii=False,indent=2))
