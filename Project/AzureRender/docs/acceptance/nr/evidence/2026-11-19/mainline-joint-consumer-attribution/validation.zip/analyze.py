from pathlib import Path
import csv, hashlib, json, statistics

run = Path(__file__).resolve().parent

def stats(values):
    values = sorted(values)
    rank = .95*(len(values)-1)
    i = int(rank)
    return dict(samples=len(values), mean=statistics.mean(values), p95=values[i]+(values[min(i+1,len(values)-1)]-values[i])*(rank-i), min=values[0], max=values[-1])

frames = list(csv.DictReader((run/'timing.csv').open()))
frames = [f for f in frames if int(f['frame']) > 120]
assert len(frames) >= 200, len(frames)
ids = {int(f['frame']) for f in frames}
passes = {}
for line in (run/'timing.passes.jsonl').read_text().splitlines():
    row = json.loads(line)
    if row['frame'] not in ids: continue
    for p in row['passes']:
        assert p['available'], p
        passes.setdefault(p['name'], []).append(p['milliseconds'])
gpu = stats([float(f['frameMs']) for f in frames])
stage = {name:dict(**stats(values), frameShare=statistics.mean(values)/gpu['mean']) for name,values in passes.items()}
assert all(v['samples'] == gpu['samples'] for v in stage.values())
dominant = sum(stage[name]['mean'] for name in ['character-main','character-opaque-depth'])
timing = json.loads((run/'timing.json').read_text())
cpu = timing['cpuFrame']
assert cpu['sampleOffsetFrame'] == 0
cpu_work = stats(cpu['workSamplesMs'][120:])
cpu_wait = stats(cpu['waitSamplesMs'][120:])
result = dict(baseline='5fccef930dcff848238a0d919cb5a139bde1372d', warmup=120,
    gpuFrame=gpu, passes=dict(sorted(stage.items(),key=lambda item:-item[1]['mean'])),
    mainAndSnapshot=dict(mean=dominant, frameShare=dominant/gpu['mean']),
    environment=json.loads((run/'environment.json').read_text()),
    sourceFiles=890, inputFiles=1729, shaderPrograms=897,
    cpuWork=cpu_work, cpuWait=cpu_wait,
    cpuRecordingAllFramesMs=timing['submission']['recordingMilliseconds']/timing['submission']['frames'],
    submission=timing['submission'],
    materialView={k:v for k,v in timing.items() if k.startswith('computedMaterialView')},
    catalogScope=json.loads((run/'candidate-catalog-scope.json').read_text()),
    candidate=dict(name='普通与固定材质组合管线', state='NotQualifiedForImplementation',
        hotspotGate=dominant/gpu['mean']>=.25,
        currentWorkReduction=None, currentWholeFrameExpectedSavingMs=None,
        combinedStageTwentyPercentMs=dominant*.20,
        stageScope='character-opaque-depth includes the snapshot color and depth work; it is not an isolated color-shading measurement',
        historicalWholeFrameSavingMs=(19.0752064+19.0762069333)/2-15.9369157333,
        historicalSource='01cc6b2', historicalApplicableToCurrent=False,
        associatedChanges=['existing AZURE_ENABLE_COMPUTED_MATERIAL_VIEW opt-in and scoped material pipeline selection; no new rendering mechanism'],
        qualityCost='Exact output required for the same current source and driver; historical exact output is contextual evidence',
        complexityCost='128 optional shader programs plus per-material pipelines and eligibility/fallback; startup and process memory require paired measurement',
        passConditions=['Current-source program and shader fingerprints verified', 'Current cost matches eligible material and input scope',
            'Expected workload reduction >=20% for a hotspot >=25% of GPU frame, or expected whole-frame GPU saving >=3 ms',
            'Single-source A/B/A with matched project, driver, viewport and fixed frame step; stable reference endpoints',
            'Affected appearance, fallback devices, descriptors, depth modes and resource release pass',
            'Net GPU gain with acceptable CPU, pipeline preparation, memory and shader catalog costs']),
    excludedCandidates=['zero-sample draw pruning: historical total snapshot upper bound 0.120832 ms at 720p, not current predicted saving',
        'shadow-gradient and repeated-sampling probes: use archived dispositions', 'surface radiance cache: archived regression, additional attachments and memory'])
(run/'analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(gpu=gpu, dominant=result['mainAndSnapshot'], stages=list(result['passes'].items())[:5]),ensure_ascii=False,indent=2))
