from pathlib import Path
import json
import re

run = Path(__file__).resolve().parent

def load(role):
    data = json.loads((run / (role + "-summary.json")).read_bytes())
    assert len(data["data"]) == 1
    fields = re.findall(r"(\w+)=([0-9.]+)", data["data"][0])
    data["preparedReads"] = {name: float(value) if "." in value else int(value) for name, value in fields}
    return data

reference = load("reference")
candidate = load("candidate")
r = reference["preparedReads"]
c = candidate["preparedReads"]
assert r["hits"] > 0 and r["hitReadMs"] > 2000
assert c["hits"] == 0 and c["hitBytes"] == 0
assert r["bytes"] - c["bytes"] == r["hitBytes"]
assert r["requests"] - c["requests"] == r["hits"]
assert c["readMs"] < r["readMs"]*.5
identity = ("requests","hits","uniqueTextures","requestedBytes","residentBytes","referencedPixelBytes",
            "releasedIdentityBytes","releasedIdentityStorageBytes","channelSavedBytes","compactedTextures")
assert all(reference["cache"][name] == candidate["cache"][name] for name in identity)
assert reference["sceneLoad"]["decodedMaterialPixelBytes"] == candidate["sceneLoad"]["decodedMaterialPixelBytes"]
summary = dict(reference=reference,candidate=candidate,identity=list(identity),readsRemoved=r["hits"],
               bytesAvoided=r["hitBytes"],readMsSaved=r["readMs"]-c["readMs"],
               uploadStageMsSaved=reference["sceneLoad"]["materialUploadMs"]-candidate["sceneLoad"]["materialUploadMs"])
(run/"pair.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps({k:summary[k] for k in ("readsRemoved","bytesAvoided","readMsSaved","uploadStageMsSaved")},indent=2))
