from pathlib import Path
import hashlib
import json
import re
import sqlite3
import xml.etree.ElementTree as ET
import zipfile

run = Path(__file__).resolve().parent
repo = Path("D:/Projects/FYP")
engine = repo / "Project/AzureRender"
dest = engine / "docs/acceptance/nr/evidence/2026-11-19/prepared-texture-cache-hit-cost"
dest.mkdir(parents=True, exist_ok=True)

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

pair = read(run/"pair.json")
assert pair["readsRemoved"] == 1094 and pair["bytesAvoided"] == 4698494780
assert pair["readMsSaved"] > 3000 and pair["uploadStageMsSaved"] > 3000
assert len(pair["identity"]) == 10
assert pair["candidate"]["preparedReads"]["hits"] == 0
for role in ("reference","candidate"):
    text = (run / (role + "-player.log")).read_text(encoding="utf-8",errors="replace")
    assert "Allocator after unload: buffers=0 images=0" in text
    assert "Rendered frames: 4" in text
release = read(run/"release-product.json")
assert digest(engine/"src/render/SampledTextureCache.cpp") == release["cacheSource"]
assert digest(engine/"src/render/SampledTextureCache.hpp") == release["cacheHeader"]
assert "PreparedReadProfile" not in (engine/"src/render/SampledTextureCache.cpp").read_text()
gpu = read(run/"gpu-coverage/summary.json")
assert gpu["status"] == "passed" and len(gpu["cases"]) == 4
assert gpu["programSha256"] == release["player"] == digest(engine/"build/ninja-msvc-release/AzurePlayer.exe")
cpu = ET.parse(run/"cpu.xml").getroot()
assert len(list(cpu.iter("testcase"))) == 2 and not list(cpu.iter("failure")) and not list(cpu.iter("skipped"))
protected = read(run/"protected-workspace.json")
assert len(protected) == 29 and all(digest(repo/n) == h for n,h in protected.items())
with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro",uri=True) as db:
    db.row_factory = sqlite3.Row
    jobs = [dict(row) for row in db.execute("SELECT id,task,kind,state,exit_code,reason,run_seconds FROM jobs WHERE id in (2255,2258,2259,2260,2261,2262,2263) ORDER BY id")]
assert jobs[0]["state"] == "budget-stopped" and all(j["state"] == "succeeded" for j in jobs[1:])
write(run/"jobs.json",jobs)
files = {name:run/name for name in [
    "task.py","compare.py","archive.py","diagnostic.patch","candidate-diagnostic.patch","pair.json","jobs.json",
    "scratch-reclaim.log","cpu.xml","gpu-coverage/summary.json"]}
files.update({role + "-" + name:run/(role+"-"+name) for role in ["reference","candidate"]
              for name in ["player.log","summary.json","command.json","timing.json","build.log","build-command.json","product.json"]})
files.update({name:run/name for name in ["release-product.json","release-build-command.json","release-build.log"]})
files["release-regression.log"] = run.parent/"process.log"
manifest = {name:dict(sha256=digest(path),bytes=path.stat().st_size) for name,path in files.items()}
zip_path = dest/"validation.zip"
with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in files.items():z.write(path,name)
    z.writestr("manifest.json",json.dumps(manifest,indent=2))
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None and len(z.namelist()) == len(files)+1
    assert all(hashlib.sha256(z.read(name)).hexdigest() == meta["sha256"] for name,meta in manifest.items())
write(dest/"results.json", dict(
    baseline="63523adb05b1244410d439f2573cee47edc18da7", perfScope="One instrumented material-load comparison of the joint scene, not startup or FPS acceptance",
    pair=pair, release=release, cpuChecks=2, gpuCaptures=4, jobs=jobs, protectedFiles=29,
    budgetRecovery="Cleared verified prior-run NuGet HTTP cache using the SDK cache command; resumed guarded Release build and verified final Player",
    inputProof=dict(candidatePreAndPostHashes=1729,sameSceneCommands=True),
    archive=dict(sha256=digest(zip_path),members=len(files)+1,bytes=zip_path.stat().st_size)))
doc = engine/"docs/acceptance/nr/prepared-texture-cache-hit-cost.md"
text = doc.read_text(encoding="utf-8")
assert all((doc.parent/p).exists() for p in re.findall(r"\]\(([^)]+)\)",text))
assert all(len(re.findall(r"[\u4e00-\u9fff]",sentence))<=45 for sentence in re.split(r"[。！？\n]",text))
print("Verified pair, two CPU tests, four GPU captures, 29 protected files, and",len(files)+1,"archive members")
