from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

run = Path(__file__).resolve().parent
engine = Path("D:/Projects/FYP/Project/AzureRender")
build = engine / "build/ninja-msvc-release"
player = build / "AzurePlayer.exe"
project = engine / "build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject"
python = build.parent / "reinstall-environment/venv/Scripts/python.exe"
mode, role = sys.argv[1:3]
env = os.environ.copy()
env["DOTNET_ROOT"] = "D:/Tools/dotnet9"
env["PATH"] = env["DOTNET_ROOT"] + os.pathsep + "D:/Tools/Python311" + os.pathsep + env["PATH"]
env["VK_LOADER_DRIVERS_SELECT"] = "*nv-vk64*"

def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def write(name, data):
    (run / name).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

if mode == "build":
    cmd = [str(engine/"tools/msvc_env.bat"), "cmake", "--build", str(build), "--target", "AzurePlayer",
           "AzureSampledTextureCacheTests", "-j", "3"]
    write(role + "-build-command.json", cmd)
    with (run/(role+"-build.log")).open("wb") as log:
        subprocess.run(cmd, cwd=engine, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=360, check=True)
    write(role+"-product.json", dict(player=digest(player), cacheSource=digest(engine/"src/render/SampledTextureCache.cpp"),
        cacheHeader=digest(engine/"src/render/SampledTextureCache.hpp")))
elif mode == "scene":
    original = json.loads((run/(role+"-product.json")).read_bytes())
    assert original["player"] == digest(player)
    frozen_path=engine/"build/runs/20261119-180745-mainline-joint-consumer-attribution-b0a9c4/input-verification.json"
    frozen=json.loads(frozen_path.read_bytes())["files"]
    assert len(frozen)==1729
    assert all(digest(Path(name))==expected for name,expected in frozen.items())
    query = ["C:/Windows/System32/nvidia-smi.exe","--query-gpu=driver_version,name,temperature.gpu","--format=csv,noheader"]
    before = subprocess.check_output(query,text=True).strip()
    assert before.startswith("595.79"), before
    cmd=[str(player),"--resource-root",str(build),"--project",str(project),"--width","1920","--height","1080",
         "--qa-camera","scene","--qa-light","scene","--fixed-frame-step","--capture-fps","60","--smoke-frames","4",
         "--gpu-timing","--gpu-timing-output",str(run/(role+"-timing.json"))]
    write(role+"-command.json",cmd)
    started=time.perf_counter()
    with (run/(role+"-player.log")).open("wb") as log:
        subprocess.run(cmd,cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=420,check=True)
    text=(run/(role+"-player.log")).read_text(encoding="utf-8",errors="replace")
    assert "Allocator after unload: buffers=0 images=0" in text
    assert not re.search(r"VUID-|Validation (?:Error|Warning)|\[error\]",text)
    assert original["player"] == digest(player)
    assert all(digest(Path(name))==expected for name,expected in frozen.items())
    timing=json.loads((run/(role+"-timing.json")).read_bytes())
    assert timing["samples"] >= 4
    write(role+"-summary.json",dict(elapsed=time.perf_counter()-started,before=before,
        after=subprocess.check_output(query,text=True).strip(),sceneLoad=timing["sceneLoad"],
        cache=timing["materialTextureCache"],data=[s for s in text.splitlines() if s.startswith("Prepared read profile:")]))
elif mode == "tests":
    cmd=["D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe",
         "--test-dir",str(build),"-R","^AzureRender[.](SampledTextureCache|TextureMipCoverage)$",
         "--output-on-failure","--output-junit",str(run/"cpu.xml")]
    subprocess.run(cmd,cwd=engine,env=env,timeout=60,check=True)
    cmd=[str(python),str(engine/"tools/test_material_coverage_mips_gpu.py"),"--executable",str(player),
         "--output",str(run/"gpu-coverage"),"--expected-validation","disabled","--case","ring-4"]
    subprocess.run(cmd,cwd=engine,env=env,timeout=180,check=True)
else:
    raise ValueError(mode)
