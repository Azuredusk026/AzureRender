"""Verify retained source and exact target-region metrics without scene assets."""
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
import json
import sys

import numpy as np

def verify(folder):
    qualification=json.loads((folder/'qualification.json').read_bytes())
    archive=folder/'validation.zip'
    assert sha256(archive.read_bytes()).hexdigest()==qualification['validation']['archiveSha256']
    with ZipFile(archive) as z:
        assert z.testzip() is None
        for name,digest in qualification['validation']['files'].items():
            assert sha256(z.read(name)).hexdigest()==digest,name
        scoring={'__file__':str(folder/'score.py'),'__name__':'confidence_evidence_scoring'}
        exec(compile(z.read('score.py'),'score.py','exec'),scoring)
        with np.load(BytesIO(z.read(qualification['crops'])),allow_pickle=False) as crops:
            count=0
            for device,report in qualification['reports'].items():
                for row in report['rows']:
                    for region in ('centerFloor','cyanRing'):
                        original=crops[f'reference__{region}']
                        control=crops[f'{device}__{row["frame"]}__control__{region}']
                        candidate=crops[f'{device}__{row["frame"]}__candidate__{region}']
                        expected=row['metrics'][region]
                        for label,data in (('control',control),('candidate',candidate)):
                            actual=scoring['measure'](data,original)
                            assert abs(actual['ssim']-expected[label]['ssim'])<1e-7
                            assert abs(actual['medianLumaRelativeError']-expected[label]['medianLumaRelativeError'])<1e-9
                        before=np.abs(control.astype(np.int16)-original).max(2)
                        after=np.abs(candidate.astype(np.int16)-original).max(2)
                        assert int(((before<=1)&(after>1)).sum())==expected['newOverOne']
                        assert int(((before>1)&(after<=1)).sum())==expected['recovered']
                        assert int(np.any(control!=candidate,2).sum())==expected['changed']
                        count+=1
    assert qualification['accepted'] is False
    print(f'PASS: source digests, {count} paired target-region checks, SSIM, luminance and newly out-of-tolerance pixels.')

if __name__=='__main__':
    verify(Path(sys.argv[1]))
