"""Archive the paired confidence experiment with self-contained target crops."""
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json
import os
import runpy
import sqlite3
import sys

import cv2
import numpy as np

O = Path(__file__).resolve().parent
W = O.parents[2]
M = O.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e'
E = W/'docs/acceptance/nr/evidence/2026-11-19/reflection-confidence-lod'
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()

def restore(meta,folder,frame):
    donor=Path(meta['donor'])
    assert h(donor)==meta['donorSha256']
    original=cv2.imread(str(donor),cv2.IMREAD_UNCHANGED)
    archive=folder/f'frame_{frame:06d}-xor.zip'
    assert h(archive)==meta['archive']
    with ZipFile(archive) as z:
        original^=np.frombuffer(z.read('bgra-xor'),np.uint8).reshape(original.shape)
    assert sha256(original.tobytes()).hexdigest()==meta['raw']
    return cv2.cvtColor(original,cv2.COLOR_BGRA2RGB)

def main():
    q=read(O/'qualification.json')
    assert len(q['reports'])==2 and q['retainedShaderCatalogExact']
    assert q['accepted'] is False
    # Further evidence is bounded by the original 64 MiB reservation.
    sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
    import artifact_budget
    budget=artifact_budget.check(W/'build',run=O,planned=5_000_000)
    assert budget['allowed'],budget
    scoring=runpy.run_path(str(M/'score-joint-native-floor.py'),run_name='archive_scoring')
    reference=scoring['img'](Path(q['reference']))
    assert h(Path(q['reference']))==q['referenceSha256']
    bounds=read(W/'docs/acceptance/nr/evidence/2026-11-16/joint-scene-native-floor/results.json')['rectangles']
    crops={}
    for region in ('centerFloor','cyanRing'):
        x,y,u,v=bounds[region]
        crops[f'reference__{region}']=reference[y:v,x:u]
    for device,report in q['reports'].items():
        for row in report['rows']:
            for label in ('control','candidate'):
                image=restore(row[label],O/f'{device}-{label}',row['frame'])
                for region in ('centerFloor','cyanRing'):
                    x,y,u,v=bounds[region]
                    crop=image[y:v,x:u]
                    crops[f'{device}__{row["frame"]}__{label}__{region}']=crop
                    actual=scoring['measure'](crop,crops[f'reference__{region}'])
                    expected=row['metrics'][region][label]
                    assert actual==expected,(device,row['frame'],region,label)
    payload=BytesIO()
    np.savez_compressed(payload,**crops)
    with sqlite3.connect('D:/Projects/FYP-coordination/resources/dispatch.sqlite3') as db:
        db.row_factory=sqlite3.Row
        jobs=[dict(row) for row in db.execute(
            'SELECT * FROM jobs WHERE task LIKE ? ORDER BY id',('nr-confidence-lod-%',))]
    program_sources={name:h(W/name) for name in (
        'shaders/reflection_spatial_filter.comp','shaders/projected_reflection_trace.hlsl',
        'src/render/ReflectionSpatialFilter.cpp','src/render/ProjectedScreenReflectionGpu.cpp')}
    frozen=W/'docs/acceptance/nr/evidence/2026-11-16/projected-history-layer-frozen/qualification.json'
    freeze=read(frozen)
    q.update(rectangles=bounds,sourceFiles=program_sources,resourceJobs=jobs,evidenceBudget=budget,
             crops='target-crops.npz',
             frozen=dict(existingEvidence=str(frozen),sha256=h(frozen),
                         sameDriverExact=freeze['sameDriverExact'],originalFrozenExact=freeze['originalFrozenExact'],
                         candidateAdopted=False,productionFingerprintRestored=True,
                         policy='Candidate rejected before integration. Original cross-driver gate stays open.'))
    files={'experiment.py':(O/'experiment.py').read_bytes(),
           'archive.py':Path(__file__).read_bytes(),
           'verify.py':(O/'verify.py').read_bytes(),
           'score.py':(M/'score-joint-native-floor.py').read_bytes(),
           'control.comp':(O/'control.comp').read_bytes(),
           'candidate.comp':(O/'candidate.comp').read_bytes(),
           'candidate.diff':(O/'candidate.diff').read_bytes(),
           'build.json':(O/'build.json').read_bytes(),
           'target-crops.npz':payload.getvalue()}
    for device,report in q['reports'].items():
        for label in ('control','candidate'):
            folder=O/f'{device}-{label}'
            for name in ('command.json','player.log','frames/capture_manifest.json','frames/gpu_capabilities.json'):
                files[f'{device}-{label}/{name}']=(folder/name).read_bytes()
            runtime=read(folder/'runtime.json')
            files[f'{device}-{label}/runtime-errors.json']=json.dumps(
                {k:runtime[k] for k in ('scriptErrors','presentationErrors')},indent=2).encode()
    E.mkdir(parents=True,exist_ok=True)
    archive=E/'validation.zip'
    with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in files.items():
            z.writestr(name,data)
    q['validation']=dict(archiveSha256=h(archive),
                         files={name:sha256(data).hexdigest() for name,data in files.items()})
    (E/'qualification.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
    for device in q['reports']:
        (E/f'{device}-comparison.png').write_bytes((O/f'{device}-comparison.png').read_bytes())
    print(json.dumps({'evidence':str(E),'archiveBytes':archive.stat().st_size,
                      'archiveSha256':h(archive),'actualBytes':budget['usedBytes']},indent=2))

if __name__=='__main__':
    main()
