"""Single-variable confidence LOD interpolation in the archived joint scene."""
from contextlib import contextmanager
from hashlib import file_digest, sha256
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import difflib
import json
import os
import re
import runpy
import subprocess
import sys

import cv2
import numpy as np

O = Path(__file__).resolve().parent
W = O.parents[2]
M = O.parent / '20261114-150229-face-native-geometry-mask-sampling-d5d93e'
R = O.parent / '20261114-125923-body-lit-outline-depth-order-a29b63'
G = O.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
HOST = R / 'msaa-release'
KEY = 'reflection_spatial_filter.comp.spv'
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import artifact_budget
import artifact_maintenance as art
S = runpy.run_path(str(M / 'projected-reflection-32-step-candidate.py'), run_name='confidence_scoring')
read = lambda p: json.loads(p.read_bytes())
write = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n', encoding='utf8')

def sha(path):
    with path.open('rb') as f:
        return file_digest(f, 'sha256').hexdigest()

def lease():
    current = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert current['state'] == 'held' and Path(current['output']) == O
    budget = artifact_budget.check(W / 'build', run=O, planned=18_000_000)
    assert budget['allowed'], budget
    return budget

def build():
    budget = lease()
    source = W / 'shaders/reflection_spatial_filter.comp'
    original = source.read_text(encoding='utf8')
    line = '        confidence=clamp(textureLod(confidencePyramid,uv,floor(lod)).r,0,1);'
    assert original.count(line) == 1
    replacement = """        float low=floor(lod),high=min(low+1.,parameters.rows[0].z);
        float lo=textureLod(confidencePyramid,uv,low).r;
        float hi=textureLod(confidencePyramid,uv,high).r;
        float blended=mix(lo,hi,lod-low);
        // The projected path uses material channel one for the footprint.
        confidence=clamp(parameters.rows[3].y==1.?blended:lo,0,1);"""
    candidate = original.replace(line, replacement)
    assert candidate.replace(replacement, line) == original
    (O / 'control.comp').write_text(original, encoding='utf8')
    (O / 'candidate.comp').write_text(candidate, encoding='utf8')
    (O / 'candidate.diff').write_text(''.join(difflib.unified_diff(
        original.splitlines(True), candidate.splitlines(True), fromfile='control', tofile='confidence-lod')),
        encoding='utf8')
    sdk = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
    outputs = {}
    for name in ('control', 'candidate'):
        binary = O / f'{name}.spv'
        command = [str(sdk / 'glslc.exe'), str(O / f'{name}.comp'), '-o', str(binary)]
        subprocess.run(command, check=True, timeout=45)
        subprocess.run([str(sdk / 'spirv-val.exe'), '--target-env', 'vulkan1.3', str(binary)],
                       check=True, timeout=30)
        outputs[name] = dict(source=sha(O / f'{name}.comp'), program=sha(binary), command=command)
    assert outputs['control']['program'] == sha(HOST / 'shaders' / KEY)
    assert outputs['candidate']['program'] != outputs['control']['program']
    write(O / 'build.json', dict(sourceCommit='ba471af147a1151c0287c58e1293f72df0ae7175',
          worktreeSource=sha(source), budget=budget, outputs=outputs, compiler=sha(sdk/'glslc.exe'),
          variable='confidence LOD fractional interpolation only; color LOD and all ray/history inputs fixed'))
    print('Compiled and validated the exact control and the single-variable candidate.', flush=True)

@contextmanager
def selected_program(candidate):
    target = HOST / 'shaders' / KEY
    expected = read(O / 'build.json')['outputs']['control']['program']
    assert sha(target) == expected
    backup = O / 'retained-filter.spv'
    assert not backup.exists()
    target.replace(backup)
    try:
        os.link(O / ('candidate.spv' if candidate else 'control.spv'), target)
        yield
    finally:
        backup.replace(target)
        assert sha(target) == expected

def capture(device, label):
    folder = O / f'{device}-{label}'
    folder.mkdir()
    reference = M / f'projected-reflection-32-step-candidate/baseline-{device}'
    args = read(reference / 'command.json')
    assert sha(Path(args[0])) == S['PLAYER_SHA']
    for flag, path in (('--capture-dir', folder / 'frames'),
                       ('--runtime-report', folder / 'runtime.json'), ('--capture-frames', '2')):
        args[args.index(flag)+1] = str(path)
    frames = S['invoke'](device, args, folder)
    actual = read(frames / 'capture_manifest.json')
    old = read(reference / 'frames/capture_manifest.json')
    camera_fields = ('qaCameraPosition', 'qaCameraTarget', 'cameraLens', 'cameraUp',
                    'gradeSettings', 'bloomSettings', 'nprLighting', 'screenReflectionProducer',
                    'screenReflectionLevels', 'sceneTriangles', 'skinnedVertices', 'transparentTriangles',
                    'width', 'height', 'fps')
    assert all(actual[k] == old[k] for k in camera_fields)
    assert actual['capturedFrames'] == 2
    runtime = read(folder / 'runtime.json')
    assert not runtime['presentationErrors'] and not runtime['scriptErrors']
    pngs = sorted(frames.glob('frame_*.png'))
    assert len(pngs) == 2
    result = []
    for png in pngs:
        original = reference / 'frames' / png.name
        image = cv2.imread(str(png), cv2.IMREAD_UNCHANGED)
        assert image.shape == (1440, 2560, 4)
        donor = cv2.imread(str(original), cv2.IMREAD_UNCHANGED)
        encoded = np.bitwise_xor(donor, image)
        archive = folder / (png.stem + '-xor.zip')
        with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=6) as z:
            z.writestr('bgra-xor', encoded.tobytes())
        with ZipFile(archive) as z:
            restored = donor ^ np.frombuffer(z.read('bgra-xor'), np.uint8).reshape(image.shape)
        assert np.array_equal(restored, image)
        result.append((image, dict(png=sha(png), raw=sha256(image.tobytes()).hexdigest(),
            archive=sha(archive), donor=str(original), donorSha256=sha(original),
            archivedControlPixelDifferences=int(np.any(image != donor, 2).sum()))))
        assert png.resolve() == png and not png.is_symlink()
        png.unlink()
    manifest = {key:actual[key] for key in camera_fields}
    return result, dict(camera=manifest, gpu=read(frames/'gpu_capabilities.json'),
                        manifest=sha(frames/'capture_manifest.json'), command=args)

def metrics(old, new, native):
    result = {}
    for name, (x,y,u,v) in S['regions'].items():
        a,b,g = (cv2.cvtColor(im, cv2.COLOR_BGRA2RGB)[y:v,x:u]
                 if im.shape[2] == 4 else im[y:v,x:u] for im in (old,new,native))
        before,after = (np.abs(im.astype(np.int16)-g).max(2) for im in (a,b))
        energy = lambda im: float(np.std(cv2.Laplacian(cv2.cvtColor(im,cv2.COLOR_RGB2GRAY).astype('f4'),cv2.CV_32F)))
        result[name] = dict(control=S['score'](a,g), candidate=S['score'](b,g),
            changed=int(np.any(a!=b,2).sum()), newOverOne=int(((before<=1)&(after>1)).sum()),
            recovered=int(((before>1)&(after<=1)).sum()), controlOverOne=int((before>1).sum()),
            candidateOverOne=int((after>1).sum()), highFrequency=[energy(im) for im in (g,a,b)])
    return result

def run():
    lease()
    frozen = S['catalog']['retained_catalog'](R)
    assert {p.name:sha(p) for p in (HOST/'shaders').glob('*.spv')} == frozen
    project = Path(S['sources']()['project'])
    provenance = S['sources']()
    gold = S['img'](S['inputs_phase']['replay'])
    with art.database(W/'build') as db:
        original = art.rows(db)[R.name]
    assert original['status'] == 'closed'
    art.resume(W/'build', R.name)
    summary = {}
    try:
        for device in ('nvidia','intel'):
            with selected_program(False):
                control, a = capture(device,'control')
            with selected_program(True):
                candidate, b = capture(device,'candidate')
            assert a['camera'] == b['camera'] and a['gpu']['driver_version'] == b['gpu']['driver_version']
            rows = []
            for i, ((old, oldmeta), (new, newmeta)) in enumerate(zip(control,candidate)):
                paired = metrics(old,new,gold)
                rows.append(dict(frame=i,control=oldmeta,candidate=newmeta,metrics=paired))
                print(device, i, {k:{'ssim':[paired[k][s]['ssim'] for s in ('control','candidate')],
                    'new':paired[k]['newOverOne']} for k in ('centerFloor','cyanRing')}, flush=True)
                if i == 1:
                    images = []
                    for data in (gold,cv2.cvtColor(old,cv2.COLOR_BGRA2RGB),cv2.cvtColor(new,cv2.COLOR_BGRA2RGB)):
                        images.append(np.concatenate([cv2.resize(data[y:v,x:u],(540,220))
                            for x,y,u,v in (S['regions'][r] for r in ('centerFloor','cyanRing'))],axis=0))
                    cv2.imwrite(str(O/f'{device}-comparison.png'),
                                cv2.cvtColor(np.concatenate(images,axis=1),cv2.COLOR_RGB2BGR))
            summary[device] = dict(control=a,candidate=b,rows=rows)
            write(O/'qualification.json',dict(status='measured-confidence-lod-interpolation',reports=summary))
    finally:
        art.seal(W/'build',R)
        (R/'.finished').touch()
    with art.database(W/'build') as db:
        after = art.rows(db)[R.name]
    assert after['status']=='closed' and after['manifestSha256']==original['manifestSha256']
    assert frozen == {p.name:sha(p) for p in (HOST/'shaders').glob('*.spv')}
    assert S['sources']() == provenance
    rows = [row for report in summary.values() for row in report['rows']]
    accepted = all(row['metrics'][region]['candidate']['ssim'] >= .95 and
        row['metrics'][region]['candidate']['medianLumaRelativeError'] <= .10 and
        row['metrics'][region]['newOverOne'] == 0 for row in rows for region in ('centerFloor','cyanRing'))
    write(O/'qualification.json',dict(status='measured-confidence-lod-interpolation',
        accepted=accepted, baseCommit='ba471af147a1151c0287c58e1293f72df0ae7175',
        source=provenance,reference=str(S['inputs_phase']['replay']),referenceSha256=sha(S['inputs_phase']['replay']),
        build=read(O/'build.json'),reports=summary,retainedShaderCatalogExact=True,
        retainedHostSha256=sha(S['PLAYER']),regionalGates=dict(ssim=.95,lumaRelative=.10,newOverOne=0),
        frozenRegression='Production source, host and all 895 retained shaders restored exactly. Candidate rejected if any gate fails.'))
    print('Candidate adopted:', accepted, flush=True)

if __name__ == '__main__':
    {'build':build,'run':run}[sys.argv[1]]()
