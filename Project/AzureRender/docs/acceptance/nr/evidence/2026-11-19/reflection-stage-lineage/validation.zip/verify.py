"""Recompute archived stage diagnostics without private captures or GPU replay."""
from pathlib import Path
from hashlib import sha256
import json
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
STAGES=('firstTrace','actualFilterInput0','actualFilterOutput','finalDisplay')
WEIGHTS=np.array([.2126,.7152,.0722])

def correlate(a,b):
    return float(np.corrcoef(a,b)[0,1])

def recompute():
    points=np.load(HERE/'stage-points.npz',allow_pickle=False)
    result={}
    for region in ('centerFloor','cyanRing'):
        xy=points[region+'_xy']
        depth=points[region+'_forwardDepth']
        confidence=points[region+'_traceConfidence']
        good=np.isfinite(depth).all(axis=1)&(abs(depth[:,0]-depth[:,1])<=.02)&(confidence>0).all(axis=1)
        assert good.any()
        assert len(set(map(tuple,xy)))==len(xy)
        assert ((xy[:,0]-3)%17==0).all() and ((xy[:,1]-7)%11==0).all()
        stages={}
        for stage in STAGES:
            rgb=points[region+'_'+stage][good]
            assert np.isfinite(rgb).all()
            luma=rgb@WEIGHTS
            stages[stage]={
                'lumaCorrelation':correlate(luma[:,0],luma[:,1]),
                'meanAbsoluteLumaDifference':float(abs(luma[:,0]-luma[:,1]).mean()),
                'medianLumaNativePlayer':np.median(luma,axis=0).tolist(),
                'lumaP10P90NativePlayer':np.quantile(luma,[.1,.9],axis=0).T.tolist()}
        first=points[region+'_firstTrace'][good]
        actual=points[region+'_actualFilterInput0'][good]
        filtered=points[region+'_actualFilterOutput'][good]@WEIGHTS
        final=points[region+'_finalDisplay'][good]@WEIGHTS
        residualCorrelation=correlate(filtered[:,1]-filtered[:,0],final[:,1]-final[:,0])
        goodIndices=np.flatnonzero(good)
        # Two largest absolute final differences, plus the largest difference
        # outside the overlapping ring for centerFloor. The ring uses its third.
        order=goodIndices[np.argsort(-abs(final[:,1]-final[:,0]),kind='stable')]
        witnessIndices=order[:3]
        if region=='centerFloor':
            ring=(xy[:,0]>=520)&(xy[:,0]<635)&(xy[:,1]>=530)&(xy[:,1]<590)
            exclusive=[k for k in order if not ring[k]]
            assert exclusive
            witnessIndices=np.array([*order[:2],exclusive[0]])
        witnesses=[]
        for k in witnessIndices:
            witnesses.append({'filterXY':xy[k].tolist(),
                'displayXY':(xy[k]*2+1).tolist(),
                'forwardMetersNativePlayer':depth[k].tolist(),
                'traceConfidenceNativePlayer':confidence[k].tolist(),
                'filterLodNativePlayer':points[region+'_filterLod'][k].tolist(),
                'stages':{s:{'rgbNativePlayer':points[region+'_'+s][k].tolist(),
                    'lumaNativePlayer':(points[region+'_'+s][k]@WEIGHTS).tolist()} for s in STAGES}})
        result[region]={'archivedGridPoints':len(xy),'matchedPoints':int(good.sum()),
            'rawToActualFilterInputChangedNativePlayer':np.any(first!=actual,axis=-1).sum(axis=0).tolist(),
            'filteredToFinalResidualCorrelation':residualCorrelation,
            'stages':stages,'witnesses':witnesses,
            'baselineDisplayComparison':{}}
        archived=points[region+'_archivedDisplayCrop']
        for device in ('nvidia','intel'):
            for frame in (0,1):
                baseline=points[region+f'_baseline_{device}_{frame}']
                delta=abs(archived.astype(np.int16)-baseline.astype(np.int16))
                result[region]['baselineDisplayComparison'][f'{device}_frame_{frame}']={
                    'changedPixels':int(np.any(delta!=0,axis=-1).sum()),
                    'maxChannelDifference':int(delta.max()),
                    'meanAbsoluteRgbDifference':float(delta.mean())}
    return result

def close(a,b,path=''):
    if isinstance(a,dict):
        assert a.keys()==b.keys(),path
        for key in a: close(a[key],b[key],path+'/'+key)
    elif isinstance(a,list):
        assert len(a)==len(b),path
        for i,(x,y) in enumerate(zip(a,b)): close(x,y,path+f'/{i}')
    elif isinstance(a,(int,float)):
        assert np.isclose(a,b,rtol=1e-11,atol=1e-12), (path,a,b)
    else:
        assert a==b,path

if __name__=='__main__':
    result=recompute()
    if '--write' in sys.argv:
        (HERE/'metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({r:{'matchedPoints':v['matchedPoints'],
            'filteredToFinalResidualCorrelation':v['filteredToFinalResidualCorrelation'],
            'witnessXY':[w['displayXY'] for w in v['witnesses']]} for r,v in result.items()},indent=2))
    else:
        manifest=json.loads((HERE/'manifest.json').read_bytes())
        for name,digest in manifest.items():
            assert sha256((HERE/name).read_bytes()).hexdigest()==digest,name
        close(result,json.loads((HERE/'metrics.json').read_bytes()))
        print('PASS: archive hashes, two geometry masks, all stage statistics and six witness chains.')
