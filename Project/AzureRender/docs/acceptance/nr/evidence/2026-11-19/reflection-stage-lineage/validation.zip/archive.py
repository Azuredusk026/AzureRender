"""Seal the bounded archive-only stage attribution evidence."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import json
import shutil
import subprocess
import sys

O=Path(__file__).resolve().parent
W=O.parents[2]
E=W/'docs/acceptance/nr/evidence/2026-11-19/reflection-stage-lineage'
E.mkdir(parents=True,exist_ok=True)
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
source=json.loads((O/'sources.json').read_bytes())
for name,metadata in source['sources'].items():
    assert digest(Path(name))==metadata['fileSha256'],name
members=['analyze_stage_lineage.py','archive.py','verify.py','stage-points.npz','sources.json','metrics.json']
write(O/'manifest.json',{n:digest(O/n) for n in members})
verification=subprocess.run([sys.executable,str(O/'verify.py')],capture_output=True,text=True,check=True)
(O/'verification.log').write_text(verification.stdout,encoding='utf-8')
members+=['manifest.json','verification.log']
with ZipFile(E/'validation.zip','w',ZIP_DEFLATED,compresslevel=9) as archive:
    for name in members:
        archive.write(O/name,name)
with ZipFile(E/'validation.zip') as archive:
    assert archive.testzip() is None
    assert all(sha256(archive.read(n)).hexdigest()==digest(O/n) for n in members)
    recovery=O/'isolated-verification'
    recovery.mkdir(exist_ok=True)
    archive.extractall(recovery)
retest=subprocess.run([sys.executable,str(recovery/'verify.py')],capture_output=True,text=True,check=True)
(O/'isolated-verification.log').write_text(retest.stdout,encoding='utf-8')
for name in ('centerFloor-stages.png','cyanRing-stages.png'):
    shutil.copyfile(O/name,E/name)
metrics=json.loads((O/'metrics.json').read_bytes())
qualification={'status':'diagnosed-archived-input-deficit-with-current-baseline-evidence-gap',
    'accepted':False,'baseCommit':'fe5ba3b982cdd739b6396c09256aca7f96a6ccde',
    'newGpuJobs':0,'productionChanged':False,'source':source,'metrics':metrics,
    'regionalGates':{'ssimMinimum':.95,'luminanceRelativeErrorMaximum':.1,
        'newOutOfTolerancePixelsMaximum':0,'frozenFourFrames':'pixel-identical'},
    'conclusion':{'earliestObservedDeficit':'first archived ray color; retained in actual bound filter input',
        'consumerExclusiveCauseProven':False,'currentBaselineEndToEndProven':False,
        'repairCandidateQualified':False,
        'nextRequiredEvidence':source['missingEvidence']},
    'verification':{'sourceArchive':verification.stdout.strip(),
        'isolatedExtract':retest.stdout.strip(),
        'originalSourceFilesRehashed':len(source['sources'])},
    'validation':{'archiveSha256':digest(E/'validation.zip'),
        'files':{n:digest(O/n) for n in members}},
    'images':{n:digest(E/n) for n in ('centerFloor-stages.png','cyanRing-stages.png')}}
write(E/'qualification.json',qualification)
print(verification.stdout.strip())
print(retest.stdout.strip())
print('Evidence bytes:',sum(p.stat().st_size for p in E.iterdir() if p.is_file()))
