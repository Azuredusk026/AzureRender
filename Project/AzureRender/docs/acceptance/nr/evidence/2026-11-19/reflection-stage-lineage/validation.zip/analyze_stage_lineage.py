from pathlib import Path
from hashlib import sha256
import json
import runpy
import zlib
import numpy as np
import cv2
import sys
from io import BytesIO
from zipfile import ZipFile

O=Path(__file__).resolve().parent
W=O.parents[2]
M=O.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e'
N=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261028-155222-native-floor-reflection-source-9dcd8c')
V=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261031-122504-projected-footprint-quality-5daf40/capture-inputs-v2')
B=runpy.run_path(str(M/'score-native-floor-reflection-inputs.py'),run_name='stage_data')
sources={}
def read(p):
    raw=p.read_bytes()
    sources[str(p.resolve())]={'fileSha256':sha256(raw).hexdigest(),'bytes':len(raw)}
    return json.loads(raw)
def get(path,digest,dtype,shape):
    raw=path.read_bytes()
    sources[str(path.resolve())]={'fileSha256':sha256(raw).hexdigest(),'bytes':len(raw)}
    if path.suffix=='.zlib':
        raw=zlib.decompress(raw)
    assert sha256(raw).hexdigest()==digest,(path,digest)
    sources[str(path.resolve())]['decodedSha256']=digest
    return np.frombuffer(raw,dtype).reshape(shape)
decode=B['decode_reflected_color']
CROP=B['CROP']
decode_luma=lambda a:a@np.array([.2126,.7152,.0722])
compress=lambda a:a/(1+np.max(a,axis=-1,keepdims=True))

vm=read(V/'summary.json')
vf={v['name']:v['data'] for v in vm['inputs']+vm['outputs'] if 'data' in v}
fm=read(M/'projected-history-filter-input-replay/results.json')
nr=read(N/'native-reflection-filter.json')
ns=read(Path('D:/Projects/FYP/Project/AzureRender/docs/acceptance/nr/evidence/2026-10-28/reflection-filter-source.json'))
def native(number,dtype,channels=0):
    row,=[t for t in nr['textures'] if t['id']==number]
    d=row['levels'][0]
    return get(N/d['path'],d['sha256'],dtype,(720,1280,channels) if channels else (720,1280))[::-1]
nf0=decode(native(16552,'<u4'))
nfinal=decode(native(15925,'<u4'))
nfoot=native(16501,'<u2',2)[...,1]/65535*6
def player(name,dtype,channels=0,filter_input=False):
    if filter_input:
        d=fm['inputs'][name]['mips'][0]
        return get(M/'projected-history-filter-input-replay'/d['file'],d['sha256'],dtype,
                   (720,1280,channels) if channels else (720,1280))
    d=vf[name]
    return get(V/d['file'],d['sha256'],dtype,(720,1280,channels) if channels else (720,1280))
ptrace=decode(player('outputColor','<u4'))
pf0=decode(player('color','<u4',filter_input=True))
pfoot=player('footprint','<u2',2,True)[...,1]/65535*6
prgba=read(M/'projected-history-player-lineage/results.json')['filteredColorControl']
samples=get(M/'projected-history-player-lineage/filter-samples.bin',prgba['sampleSha256'],
            [('x','<u2'),('y','<u2'),('rgba','<f4',(4,))],(-1,))
nc=get(M/'projected-history-coordinates/native/trace-color.bin',
       read(M/'projected-history-coordinates/native/results.json')['control'][0],'<u4',(220,290))
ntrace=decode(nc)
rd=read(M/'native-floor-reflection-inputs/results.json')
dd={r['name']:r for r in rd['files']}
nd=get(M/'native-floor-reflection-inputs/current-depth.bin',dd['current-depth']['sha256'],'<f4',(220,290))
nm=read(B['NATIVE']/'event-8702.json')
nrows=[[v['float32'] for v in block['variables']] for block in nm['blocks']]
nv=np.array(nrows[0][12:16])
pv=np.array(vm['frameRows'][6:10])
nx=-B['reconstruct'](nd,CROP,nv)[...,2]
px=-B['reconstruct'](player('currentDepth','<f4')[480:700,500:790],CROP,pv)[...,2]
valid=np.isfinite(nx)&np.isfinite(px)&(abs(nx-px)<=.02)
nconf=get(M/'native-floor-reflection-inputs/trace-confidence.bin',dd['trace-confidence']['sha256'],'u1',(220,290))/255
pconf=player('outputConfidence','u1')[480:700,500:790]/255
nativepng=B['ROOT']/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame3534-replayed.png'
playerpng=V.parent/'capture-indexed/frames/frame_000001.png'
def image(p):
    raw=p.read_bytes()
    sources[str(p.resolve())]={'fileSha256':sha256(raw).hexdigest(),'bytes':len(raw)}
    return cv2.cvtColor(cv2.imdecode(np.frombuffer(raw,'u1'),cv2.IMREAD_COLOR),cv2.COLOR_BGR2RGB)
beauty_n,beauty_p=(image(p) for p in (nativepng,playerpng))
baselineFolder=W/'docs/acceptance/nr/evidence/2026-11-19/reflection-confidence-lod'
baselineQualification=read(baselineFolder/'qualification.json')
baselineArchive=baselineFolder/'validation.zip'
archiveBytes=baselineArchive.read_bytes()
assert sha256(archiveBytes).hexdigest()==baselineQualification['validation']['archiveSha256']
sources[str(baselineArchive.resolve())]={'fileSha256':sha256(archiveBytes).hexdigest(),'bytes':len(archiveBytes)}
with ZipFile(BytesIO(archiveBytes)) as archive:
    cropBytes=archive.read('target-crops.npz')
    assert sha256(cropBytes).hexdigest()==baselineQualification['validation']['files']['target-crops.npz']
    baselineCrops=np.load(BytesIO(cropBytes),allow_pickle=False)

arrays={}
regions={}
for region in ('centerFloor','cyanRing'):
    x,y,u,v=B['REGIONS'][region]
    mask=(samples['x']>=x)&(samples['x']<u)&(samples['y']>=y)&(samples['y']<v)
    pts=samples[mask]
    X,Y=pts['x'].astype(int),pts['y'].astype(int)
    good=valid[Y-480,X-500]&(nconf[Y-480,X-500]>0)&(pconf[Y-480,X-500]>0)
    raw_n=ntrace[Y-480,X-500]
    stages=[
        ('firstTrace',raw_n,ptrace[Y,X]),
        ('actualFilterInput0',nf0[Y,X],pf0[Y,X]),
        ('actualFilterOutput',compress(nfinal[Y,X]),compress(pts['rgba'][:,:3])),
        ('finalDisplay',beauty_n[Y*2+1,X*2+1]/255,beauty_p[Y*2+1,X*2+1]/255)]
    arrays[region+'_xy']=np.stack([X,Y],axis=-1)
    arrays[region+'_forwardDepth']=np.stack([nx[Y-480,X-500],px[Y-480,X-500]],axis=-1)
    arrays[region+'_traceConfidence']=np.stack([nconf[Y-480,X-500],pconf[Y-480,X-500]],axis=-1)
    arrays[region+'_filterLod']=np.stack([nfoot[Y,X],pfoot[Y,X]],axis=-1)
    for stage,a,b in stages:
        arrays[region+'_'+stage]=np.stack([a,b],axis=1)
    dense_good=valid[y-480:v-480,x-500:u-500]&(nconf[y-480:v-480,x-500:u-500]>0)&(pconf[y-480:v-480,x-500:u-500]>0)
    regions[region]={'halfResolutionBounds':[x,y,u,v],
        'denseMatchedPoints':int(dense_good.sum()),
        'denseRawToActualFilterInputChanged':[
            int(np.any(ntrace[y-480:v-480,x-500:u-500]!=nf0[y:v,x:u],axis=-1)[dense_good].sum()),
            int(np.any(ptrace[y:v,x:u]!=pf0[y:v,x:u],axis=-1)[dense_good].sum())]}
    arrays[region+'_archivedDisplayCrop']=beauty_p[y*2:v*2,x*2:u*2]
    for device in ('nvidia','intel'):
        for frame in (0,1):
            arrays[region+f'_baseline_{device}_{frame}']=baselineCrops[f'{device}__{frame}__control__{region}']

    # Paired columns only: the compressed reflection stages and display bytes
    # have separate color domains and are not cross-column brightness controls.
    columns=[]
    for title,a,b in (
        ('FIRST TRACE (COMPRESSED RGB)',ntrace[y-480:v-480,x-500:u-500],ptrace[y:v,x:u]),
        ('BOUND FILTER INPUT MIP 0',nf0[y:v,x:u],pf0[y:v,x:u]),
        ('ARCHIVED FINAL DISPLAY',beauty_n[y*2:v*2,x*2:u*2]/255,beauty_p[y*2:v*2,x*2:u*2]/255),
        ('FE5BA3B NVIDIA FRAME 1',beauty_n[y*2:v*2,x*2:u*2]/255,baselineCrops[f'nvidia__1__control__{region}']/255)):
        pair=[]
        for label,data in (('NATIVE',a),('PLAYER',b)):
            rgb=np.clip(np.rint(data*255),0,255).astype('u1')
            rgb=cv2.resize(rgb,((u-x)*2,(v-y)*2),interpolation=cv2.INTER_NEAREST)
            canvas=np.full((rgb.shape[0]+30,rgb.shape[1],3),24,'u1')
            canvas[30:]=rgb
            cv2.putText(canvas,label,(8,21),cv2.FONT_HERSHEY_SIMPLEX,.5,(235,235,235),1,cv2.LINE_AA)
            pair.append(canvas)
        column=np.concatenate(pair,axis=0)
        header=np.full((32,column.shape[1],3),24,'u1')
        cv2.putText(header,title,(6,22),cv2.FONT_HERSHEY_SIMPLEX,.4,(235,235,235),1,cv2.LINE_AA)
        columns.append(np.concatenate((header,column),axis=0))
    cv2.imwrite(str(O/f'{region}-stages.png'),cv2.cvtColor(np.concatenate(columns,axis=1),cv2.COLOR_RGB2BGR))
    print(region,len(X),'matched',int(good.sum()),'lodN',np.quantile(nfoot[Y[good],X[good]],[0,.5,1]),'lodP',np.quantile(pfoot[Y[good],X[good]],[0,.5,1]))
    for label,a,b in stages:
        av,bv=decode_luma(a)[good],decode_luma(b)[good]
        print(label,'corr',np.corrcoef(av,bv)[0,1],'mae',np.abs(av-bv).mean(),
              'median',(np.median(av),np.median(bv)),'rangeN',np.quantile(av,[.1,.9]),'rangeP',np.quantile(bv,[.1,.9]))
    print('raw→filterinputChanged',[int(np.any(a!=b,axis=-1)[good].sum()) for a,b in [(raw_n,nf0[Y,X]),(ptrace[Y,X],pf0[Y,X])]])

np.savez_compressed(O/'stage-points.npz',**arrays)
sources[str((M/'score-native-floor-reflection-inputs.py').resolve())]={'fileSha256':sha256((M/'score-native-floor-reflection-inputs.py').read_bytes()).hexdigest()}
provenance={
    'baseline':'fe5ba3b','unit':'archived-reflection-stage-lineage',
    'baselineScope':'The stage readbacks belong to the older archived component capture, not a fe5ba3b GPU capture. Current baseline display crops are compared separately.',
    'currentBaselineTraceShader':baselineQualification['source']['baselineShader'],
    'sources':sources,'regions':regions,
    'coordinateContract':{
        'nativeStorageRows':'y_storage=719-y_display',
        'playerStorageRows':'y_storage=y_display',
        'filterResolution':[1280,720],'displayResolution':[2560,1440],
        'displayAnchor':'[2*x+1,2*y+1]',
        'matchedMask':'finite forward depths; abs(native-player)<=0.02 metres; both trace confidence>0',
        'finalConsumerLimit':'Display anchors do not reconstruct four neighbouring filter taps or the material blend.',
        'nativeInverseProjection':nv.tolist(),'playerInverseProjection':pv.tolist()},
    'bindings':{
        'native':{'traceEvent':8702,'filterEvent':8811,'inputColor':16552,'outputColor':15925,
                  'consumerEvent':8912,'consumerConfidence':15777,'confidenceBytesArchived':False},
        'player':{'traceEvent':21668,'filterEvent':21729,'inputColor':9454,'outputColor':9490,
                  'outputSamples':len(samples),'outputSamplesSha256':prgba['sampleSha256'],
                  'fullOutputSha256':prgba['fullOutputSha256'] if 'fullOutputSha256' in prgba else prgba.get('sha256'),
                  'fullOutputBytesArchived':False}},
    'stages':['firstTrace','actualFilterInput0','actualFilterOutput','finalDisplay'],
    'colorContract':{'firstTrace':'R11G11B10 decoded compressed RGB',
        'actualFilterInput0':'actual bound mip zero; R11G11B10 decoded compressed RGB',
        'actualFilterOutput':'HDR mapped to c/(1+max(c)); native packed output; Player float samples',
        'finalDisplay':'PNG sRGB bytes/255; display anchor only'},
    'scope':'Archive diagnosis; sparse-grid metrics are not regional SSIM or acceptance results.',
    'missingEvidence':[
        'Current fe5ba3b same-frame trace/filter/consumer readbacks; the older final archive is not pixel-identical to baseline.',
        'Native resource 15777 bytes at actual final consumer 8912.',
        'Four adjacent Player filter outputs and confidence values per final display anchor.',
        'Same-position consumer material/probe/BRDF factors and postprocessing contribution.'
    ]}
(O/'sources.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Saved source-indexed points; dense counts:',regions)
