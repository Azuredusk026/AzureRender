from pathlib import Path
import hashlib
import json
import re
import sqlite3
import subprocess
import xml.etree.ElementTree as ET
import zipfile

run = Path(__file__).resolve().parent
repo = Path("D:/Projects/FYP")
engine = repo / "Project/AzureRender"
evidence = engine / "docs/acceptance/nr/evidence/2026-11-19/alpha-mip-coverage-cost"
evidence.mkdir(parents=True, exist_ok=True)

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

probe = read(run / "final.json")
assert probe["passes"] and probe["fullChainBytesEqual"] and len(probe["cases"]) == 5
assert not read(run / "red.json")["passes"]
cpu = ET.parse(run / "cpu.xml").getroot()
assert [(c.attrib["name"], c.attrib["status"]) for c in cpu.iter("testcase")] == [
    ("AzureRender.TextureMipCoverage", "run"), ("AzureRender.SampledTextureCache", "run")]
assert not list(cpu.iter("failure")) and not list(cpu.iter("skipped"))
alpha = read(run / "gpu-alpha/summary.json")
material = read(run / "gpu-material/summary.json")
assert alpha["status"] == material["status"] == "passed"
assert len(alpha["captures"]) == 9 and len(material["cases"]) == 4
products = read(run / "release-products.json")
assert alpha["playerSha256"] == material["programSha256"] == products["AzurePlayer"]
protected = read(run / "protected-workspace.json")
assert len(protected) == 29 and all(digest(repo / n) == v for n, v in protected.items())
source = engine / "src/assets/TextureMipChain.hpp"
baseline = subprocess.check_output(["git", "show", "9b0b705:Project/AzureRender/src/assets/TextureMipChain.hpp"], cwd=repo)
assert (run / "baseline.hpp").read_bytes() == baseline
with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro", uri=True) as db:
    db.row_factory = sqlite3.Row
    jobs = [dict(row) for row in db.execute("SELECT id,task,kind,state,exit_code,run_seconds FROM jobs WHERE output=? ORDER BY id", (str(run),))]
assert any(job["id"] == 2252 and job["state"] == "succeeded" for job in jobs), jobs
write(run / "dispatch-receipts.json", jobs)
logs = ["probe.cpp", "baseline.hpp", "run_probe.py", "build_release.py", "verify_gpu.py", "archive.py", "unit.json",
        "red.csv", "red.json", "red-dispatch.log", "green.json", "final.csv", "final.json", "final-probe-dispatch.log",
        "build-command.json", "build-missing-sdk.log", "release-build.log", "release-products.json",
        "cpu.xml", "gpu-commands.json", "gpu-environment.json", "gpu-alpha/summary.json", "gpu-material/summary.json",
        "dispatch-receipts.json", "process.log"]
files = {name: run / name for name in logs}
files["candidate/TextureMipChain.hpp"] = source
archive = evidence / "validation.zip"
manifest = {n: dict(sha256=digest(p), bytes=p.stat().st_size) for n, p in files.items()}
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n, p in files.items():
        z.write(p, n)
    z.writestr("manifest.json", json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(files) + 1
    assert all(hashlib.sha256(z.read(n)).hexdigest() == v["sha256"] for n, v in manifest.items())
write(evidence / "results.json", dict(
    baseline="9b0b705", scope="CPU alpha coverage mip generation, not end-to-end load or frame timing",
    sourceSha256=digest(source), referenceSha256=digest(run / "baseline.hpp"), releaseProducts=products,
    probe=probe, cpuChecks=2, gpuCaptures=13, alphaMaximumRelativeError=max(x["relativeError"] for x in alpha["captures"]),
    gpu=read(run / "gpu-environment.json"), localWorkspaceBuild=True, protectedFiles=len(protected), dispatch=jobs,
    recovered=[dict(stage="managed build", fix="select existing SDK 9.0.319 in child PATH"),
               dict(stage="CTest launch", fix="call ctest.exe directly to preserve regex alternation")],
    archive=dict(sha256=digest(archive), members=len(files)+1, bytes=archive.stat().st_size)))
doc = engine / "docs/acceptance/nr/alpha-mip-coverage-cost.md"
text = doc.read_text(encoding="utf-8")
assert all((doc.parent / link).exists() for link in re.findall(r"\]\(([^)]+)\)", text))
assert all(len(re.findall(r"[\u4e00-\u9fff]", part)) <= 45 for part in re.split(r"[。！？\n]", text))
print(f"Verified five exact mip chains, two CPU tests, thirteen captures, {len(files)+1} archive members, and 29 protected files")
