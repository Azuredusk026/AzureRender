from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

run = Path(__file__).resolve().parent
engine = Path("D:/Projects/FYP/Project/AzureRender")
player = engine / "build/ninja-msvc-release/AzurePlayer.exe"
products = json.loads((run / "release-products.json").read_bytes())
def fingerprint():
    return hashlib.sha256(player.read_bytes()).hexdigest()
assert fingerprint() == products["AzurePlayer"]
env = os.environ.copy()
env["VK_LOADER_DRIVERS_SELECT"] = "*nv-vk64*"
query = subprocess.check_output(["C:/Windows/System32/nvidia-smi.exe", "--query-gpu=driver_version,name",
                                 "--format=csv,noheader"], text=True).strip()
(run / "gpu-environment.json").write_text(json.dumps(dict(device=query), indent=2), encoding="utf-8")
common = ["--executable", str(player)]
commands = [
    [sys.executable, str(engine / "tools/test_alpha_mip_coverage_gpu.py"), *common,
     "--output", str(run / "gpu-alpha"), "--validation", "disabled"],
    [sys.executable, str(engine / "tools/test_material_coverage_mips_gpu.py"), *common,
     "--output", str(run / "gpu-material"), "--expected-validation", "disabled", "--case", "ring-4"]
]
(run / "gpu-commands.json").write_text(json.dumps(commands, indent=2), encoding="utf-8")
for command in commands:
    subprocess.run(command, cwd=engine, env=env, check=True, timeout=420)
assert fingerprint() == products["AzurePlayer"]
