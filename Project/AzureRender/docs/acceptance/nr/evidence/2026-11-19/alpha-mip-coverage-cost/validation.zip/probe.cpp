#define azurerender baseline
#include "baseline.hpp"
#undef azurerender
#include "assets/TextureMipChain.hpp"

#include <chrono>
#include <iomanip>
#include <iostream>

using Clock = std::chrono::steady_clock;

int main() {
    std::cout << std::fixed << std::setprecision(6);
    for (unsigned shape = 0; shape < 5; ++shape) {
        const unsigned width = shape == 1 ? 2048 : shape == 2 ? 1001 : shape == 3 ? 1 : 512;
        const unsigned height = shape == 1 ? 2048 : shape == 2 ? 513 : shape == 3 ? 513 : 512;
        const bool bilinear = shape != 4;
        const float cutoff = shape == 2 ? .373F : .5F;
        const bool linear = shape % 2 == 0;
        std::vector<std::uint8_t> pixels(std::size_t(width) * height * 4, 255);
        for (unsigned y = 0; y < height; ++y) {
            for (unsigned x = 0; x < width; ++x) {
                const auto i = (std::size_t(y) * width + x) * 4;
                pixels[i] = std::uint8_t(x);
                pixels[i + 1] = std::uint8_t(y);
                pixels[i + 2] = std::uint8_t(x + y);
                pixels[i + 3] = shape == 2 ? std::uint8_t(x * 3 + y * 11)
                    : std::uint8_t(((x * 100 + y * 19) % 3200 < 900) * 255);
            }
        }
        const auto ref = [&] {
            return baseline::buildTextureMipChain(pixels, width, height,
                linear ? baseline::TextureFilterSemantic::Linear : baseline::TextureFilterSemantic::Srgb,
                cutoff, bilinear);
        };
        const auto candidate = [&] {
            return azurerender::buildTextureMipChain(pixels, width, height,
                linear ? azurerender::TextureFilterSemantic::Linear : azurerender::TextureFilterSemantic::Srgb,
                cutoff, bilinear);
        };
        const auto expected = ref();
        const auto verify = [&](const auto& value) {
            if (value.levels != expected.levels || value.pixels != expected.pixels) {
                throw std::runtime_error("Mip chain bytes or level count changed");
            }
        };
        verify(candidate());
        const auto timeMs = [&](const auto& call) {
            const auto start = Clock::now();
            const auto value = call();
            const auto ms = std::chrono::duration<double, std::milli>(Clock::now() - start).count();
            verify(value);
            return ms;
        };
        for (unsigned round = 0; round < 7; ++round) {
            double referenceMs, candidateMs;
            if (round % 2 == 0) {
                referenceMs = timeMs(ref);
                candidateMs = timeMs(candidate);
            } else {
                candidateMs = timeMs(candidate);
                referenceMs = timeMs(ref);
            }
            std::cout << shape << ',' << width << ',' << height << ',' << bilinear << ','
                      << round << ',' << referenceMs << ',' << candidateMs << '\n';
        }
    }
}
