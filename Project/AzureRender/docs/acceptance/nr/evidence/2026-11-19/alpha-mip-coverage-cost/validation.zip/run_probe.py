from pathlib import Path
import csv
import json
import statistics
import subprocess
import sys

run = Path(__file__).resolve().parent
engine = Path("D:/Projects/FYP/Project/AzureRender")
stage = sys.argv[1]
exe = run / (stage + ".exe")
args = [str(engine / "tools/msvc_env.bat"), "cl", "/nologo", "/EHsc", "/std:c++17", "/O2", "/Ob2",
        "/DNDEBUG", "/I" + str(engine / "src"), str(run / "probe.cpp"), "/Fe:" + str(exe),
        "/Fo:" + str(run / (stage + ".obj"))]
with (run / (stage + "-build.log")).open("wb") as log:
    subprocess.run(args, cwd=run, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
result = subprocess.check_output([str(exe)], cwd=run, timeout=90)
(run / (stage + ".csv")).write_bytes(result)
cases = {}
for row in csv.reader(result.decode().splitlines()):
    case, width, height, bilinear, rep, reference, candidate = row
    cases.setdefault(case, dict(width=int(width), height=int(height), bilinear=bool(int(bilinear)), pairs=[]))["pairs"].append(
        [float(reference), float(candidate)])
for case in cases.values():
    assert len(case["pairs"]) == 7
    reference, candidate = (statistics.median(col) for col in zip(*case["pairs"]))
    case.update(referenceMedianMs=reference, candidateMedianMs=candidate, reduction=1-candidate/reference)
report = dict(stage=stage, fullChainBytesEqual=True, cases=cases,
              passes=all(cases[k]["reduction"] >= .20 for k in ["0", "1", "2"]))
(run / (stage + ".json")).write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps({k: {m: c[m] for m in ("referenceMedianMs", "candidateMedianMs", "reduction")}
                  for k, c in cases.items()}, indent=2))
if not report["passes"]:
    raise SystemExit("Three representative mixed-alpha cases must each remove at least 20% of CPU mip time")
