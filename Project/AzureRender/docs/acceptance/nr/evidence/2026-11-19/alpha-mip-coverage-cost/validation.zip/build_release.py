from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

run = Path(__file__).resolve().parent
engine = Path("D:/Projects/FYP/Project/AzureRender")
build = engine / "build/ninja-msvc-release"
batch = engine / "tools/msvc_env.bat"
targets = ["AzurePlayer", "AzureTextureMipCoverageTests", "AzureSampledTextureCacheTests"]
env = os.environ.copy()
env["DOTNET_ROOT"] = "D:/Tools/dotnet9"
env["PATH"] = env["DOTNET_ROOT"] + os.pathsep + "D:/Tools/Python311" + os.pathsep + env["PATH"]
sdk = subprocess.check_output([env["DOTNET_ROOT"] + "/dotnet.exe", "--version"], cwd=engine, env=env, text=True)
print("Managed SDK:", sdk.strip(), flush=True)
command = [str(batch), "cmake", "--build", str(build), "--target", *targets, "-j", "3"]
(run / "build-command.json").write_text(json.dumps(command, indent=2), encoding="utf-8")
if "--tests-only" not in sys.argv:
    subprocess.run(command, cwd=engine, env=env, check=True, timeout=720)
ctest = "D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe"
command = [ctest, "--test-dir", str(build), "-R", "^AzureRender[.](TextureMipCoverage|SampledTextureCache)$",
           "--output-on-failure", "--output-junit", str(run / "cpu.xml")]
subprocess.run(command, cwd=engine, env=env, check=True, timeout=70)
artifacts = {name: hashlib.sha256((build / (name + ".exe")).read_bytes()).hexdigest() for name in targets}
(run / "release-products.json").write_text(json.dumps(artifacts, indent=2), encoding="utf-8")
