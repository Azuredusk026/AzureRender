"""Recompute hit, history address, color and validity from the sealed evidence."""
import hashlib
import itertools
import json
import math
from pathlib import Path
import struct
import sys

ROOT = Path(__file__).resolve().parent
SLOTS = {
    'native': ['read:1:texture1','read:2:texture2','read:3:texture3','read:4:texture4','write:0:uav0','write:1:uav1','write:2:uav2'],
    'player': ['read:2:previousColor','read:3:previousDepth','read:4:currentDepth','read:5:motionInput','write:9:outputColor','write:10:outputFootprint','write:11:outputConfidence'],
}


def read(name):
    return json.loads((ROOT/name).read_bytes())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def unpack(fmt, texel):
    return struct.unpack(fmt,bytes.fromhex(texel['raw']))


def rgba(texel):
    return unpack('<4e',texel)


def depth(texel):
    return unpack('<f',texel)[0]


def r11g11b10(texel):
    bits, = unpack('<I',texel)
    values = []
    for offset,width in ((0,11),(11,11),(22,10)):
        mant_bits = width-5
        mant = ((bits>>offset)&((1<<mant_bits)-1))/(1<<mant_bits)
        exp = (bits>>(offset+mant_bits))&31
        values.append(math.ldexp((1+mant) if exp else mant, (exp or 1)-15))
    return values


def compressed(rgb):
    return [c/(1+max(rgb)) for c in rgb]


def luma(rgb):
    return sum(c*w for c,w in zip(rgb,(.2126,.7152,.0722)))


def texel_candidates(uv16, extent):
    axes=[]
    for packed,size in zip(uv16,extent):
        clamp=lambda i: min(size-1,max(i,0))
        lo=clamp(math.floor((packed-.5)*size/65535))
        hi=clamp(math.floor((packed+.5)*size/65535))
        axes.append(range(lo,hi+1))
    return {tuple(pixel) for pixel in itertools.product(*axes)}


def current_world(uv,z,matrix,native):
    u,v=(n/65535 for n in uv)
    position=(2*u-1, (2*v-1)*(-1 if native else 1), z, 1)
    xyzr=[sum(c[j]*p for c,p in zip(matrix,position)) for j in range(4)]
    return [c/xyzr[3] for c in xyzr[:3]]


def close_color(expected, observed):
    return all(abs(a-b)<=math.ldexp(1,max(-14,math.floor(math.log2(a)))-bits)+3e-7
               for a,b,bits in zip(expected,observed,(6,6,5)))


def anchors(req,label):
    data=read(label+'.json')
    owner=read(label+'-owners.json')
    job=req[label]
    native=label=='native'
    point=data['attachments']
    assert data['status']=='qualified' and owner['status']=='observed'
    assert data['captureSha256']==job['captureSha256']==owner['capture']
    assert data['frame']==job['frame']==owner['frame']
    assert data['event']==job['trace']['event'] and data['shader']==job['expectedProgram']
    assert data['bindings']==job['trace']['bindings'] and data['constants']==job['trace']['constants']
    assert data['restoration']==point
    for name,slot in zip(point,SLOTS[label]):
        assert point[name]['sha256']==job['trace']['textures'][slot][0]['fullSha256']
        assert point[name]['resource']==job['trace']['bindings'][slot]['resource']
    for name,probe in data['probes'].items():
        assert probe['shader']==job['probes'][name]
        for output in ('rayColor','confidence'):
            assert probe['outputs'][output]==point[output]
        assert probe['outputs']['footprint']['sha256']!=point['footprint']['sha256']
    constants=[]
    for c in data['constants']:
        raw=bytes.fromhex(c['hex'])
        assert sha(raw)==c['sha256'] and len(raw)==c['bytes']
        constants.append(list(struct.iter_unpack('<4f',raw)))
    mat=constants[0]
    if native:
        a,b=constants[1][2][2:]
        current,previous=mat[24:28],mat[61:65]
        history_blend=constants[2][2][2]
    else:
        a,b=mat[24][2:]
        current,previous=mat[14:18],mat[18:22]
        history_blend=mat[27][2]
        assert mat[27][3]==1
    assert history_blend==0
    distance=lambda q: 1/(a*q+b)
    rows=[]
    for index,(row,own) in enumerate(zip(data['anchors'],owner['witnesses'])):
        assert job['points'][index]==row['display']==own['anchor']
        for key in ('hitUv','historyUv','rayDepth'):
            px=data['probes'][key]['texels'][index]
            assert px['xy']==row['attachment']
            value=unpack('<HH',px)
            if key=='rayDepth':
                assert value[0]==value[1]>0
                ray_16=value[0]
            else:
                assert list(value)==row[key+'16']
        for sample,attachment,uv in (('hitSurface','currentDepth','hitUv16'),('hitMotion','motion','hitUv16'),
                         ('historyDepth','historyDepth','historyUv16'),('historyColor','historyColor','historyUv16')):
            assert {tuple(t['xy']) for t in row[sample]}==texel_candidates(row[uv],point[attachment]['extent'])
        hit, prior, motion=(row[k][0] for k in ('hitSurface','historyDepth','hitMotion'))
        assert len(row['hitSurface'])==len(row['historyDepth'])==len(row['hitMotion'])==1
        d=depth(prior)
        conf,=unpack('<B',row['confidence'])
        assert conf==255 and d>0
        if native:
            packed,=unpack('<I',motion)
            components=[((packed>>k)&1023)/1023 for k in (0,10)]
            dx,dy=[math.copysign(abs(c*2-1)**4,c-.5) for c in components]
        else:
            dx,dy,previous_device,motion_response=unpack('<4f',motion)
            assert 0<=previous_device<=1 and motion_response==1
        for h,t,delta in zip(row['hitUv16'],row['historyUv16'],(dx,dy)):
            assert abs((h-t)/65535-delta)<=2/65535
        ray_z=ray_16/65535
        world=current_world(row['hitUv16'],ray_z,current,native)
        old_world=current_world(row['historyUv16'],d,previous,native)
        world_error=math.dist(world,old_world)
        limit=max(.25,.01*distance(ray_z)**2)
        assert world_error<limit
        rgb=r11g11b10(row['rayColor'])
        available=[p for p in row['historyColor'] if close_color(compressed(rgba(p)[:3]),rgb)]
        assert len(available)==1, (label,row,rgb,[(c['xy'],compressed(rgba(c)[:3])) for c in row['historyColor']])
        draw=own['draw']
        assert draw and draw['rawBefore']!=draw['rawAfter']==own['pixel']['raw']
        assert any(v['event']==draw['event'] and v['passed'] for v in own['candidates'])
        if native:
            assert own['pixel']['raw'][:8]==hit['raw']
        else:
            assert abs(unpack('<4f',own['pixel'])[0]-distance(depth(hit)))<.00002
            assert own['pixel']['xy']==[2*c+1 for c in hit['xy']]
        history=available[0]
        x,y=history['xy']
        rows.append(dict(anchor=row['display'], receiverDepthM=distance(depth(row['receiverDepth'])),
                         hitSurfaceDepthM=distance(depth(hit)), rayDepthM=distance(ray_z), previousDepthM=distance(d),
                         worldReprojectionErrorM=world_error, worldReprojectionThresholdM=limit,
                         confidence=conf, hitDraw=draw['event'],
                         hitFullResStorage=own['pixel']['xy'], historyStorage=history['xy'],
                         historyDisplay=[x,1439-y if native else y], historyRgb=list(rgba(history)[:3]),
                         rayRgb=rgb, rayLuma=luma(rgb)))
    assert len(rows)==4
    return rows


def fixture():
    report=read('fixture.json')
    assert report['status']=='passed'
    cases=('history-response-tracked','history-response-background')
    blobs=[]
    for name,exit_code,hits in zip(cases,(0,1),(2432,0)):
        test=report['cases'][name]
        assert test['exitCode']==exit_code and test['result']['redHits']==hits
        details=test['result']
        assert details['validationErrors']==details['liveBuffers']==details['liveImages']==0
        assert details['regionPixels']==2432 and details['minimumFraction']==.75
        files=[(ROOT/'fixture'/name/(str(i)+'.bin')).read_bytes() for i in range(3)]
        assert [dict(sha256=sha(raw),bytes=len(raw)) for raw in files]==report['outputs'][name]
        blobs.append(files)
    assert blobs[0][:2]==blobs[1][:2]
    assert sum(c>0 for c in blobs[0][2])>2432 and not any(blobs[1][2])


def cross_source(results):
    samples=read('cross-source.json')
    addresses={tuple(a['historyDisplay']) for group in results.values() for a in group}
    colors={}
    for label,item in samples.items():
        attachment=read(label+'.json')['attachments']['historyColor']
        assert item['fullSha256']==attachment['sha256']
        w,h=attachment['extent']
        assert {tuple(row['display']) for row in item['samples']}==addresses
        colors[label]={}
        for row in item['samples']:
            x,y=row['display']
            assert 0<=x<w and 0<=y<h
            assert row['storage']==[x,h-1-y if label=='native' else y]
            colors[label][x,y]=list(rgba(row)[:3])
    output=[]
    for n,p in zip(results['native'],results['player']):
        a,b=tuple(n['historyDisplay']),tuple(p['historyDisplay'])
        A,B,C,D=(luma(compressed(colors[s][addr])) for s,addr in
                  [('native',a),('native',b),('player',a),('player',b)])
        assert colors['native'][a]==n['historyRgb'] and colors['player'][b]==p['historyRgb']
        address=((A-B)+(C-D))/2
        source=((A-C)+(B-D))/2
        assert math.isclose(A-D,address+source,abs_tol=1e-9)
        output.append(dict(anchor=n['anchor'],nativeAtNative=A,nativeAtPlayer=B,
                           playerAtNative=C,playerAtPlayer=D,
                           addressContribution=address,sourceContribution=source))
    return output



def main():
    req=read('request.json')
    results={name:anchors(req,name) for name in ('native','player')}
    fixture()
    for n,p in zip(results['native'],results['player']):
        assert n['anchor']==p['anchor']
        assert abs(n['receiverDepthM']-p['receiverDepthM'])<.02
    first,last=results['native'][0],results['player'][0]
    assert first['historyDisplay']==[1264,615] and last['historyDisplay']==[1263,623]
    assert first['rayLuma']>5*last['rayLuma']
    results['crossSource']=cross_source(results)
    output=json.dumps(results, indent=2)
    if len(sys.argv)==2 and sys.argv[1]=='--record':
        (ROOT/'computed.json').write_text(output+'\n',encoding='utf-8')
    else:
        assert results==read('computed.json')
    for n,p in zip(results['native'],results['player']):
        print(n['anchor'],n['hitDraw'],p['hitDraw'],
              *(round(r[k],6) for k in ('hitSurfaceDepthM','rayLuma','worldReprojectionErrorM') for r in (n,p)),
              n['historyDisplay'],p['historyDisplay'])
    print('PASS: 8 anchors, 6 neutral probes, exact attachment restoration and single-variable GPU control')


if __name__=='__main__':
    main()

