"""Resolve full-resolution geometry witnesses and run an independent mirror control."""
import json
import os
from pathlib import Path
import struct
from hashlib import file_digest
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def load(name):
    return json.loads((ROOT/name).read_bytes())


def save(name, data):
    (ROOT/name).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def sha(path):
    with path.open('rb') as source:
        return file_digest(source, 'sha256').hexdigest()


def probes():
    assert Path(json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())['output']).resolve() == ROOT
    qrenderdoc = Path('D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe')
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = 0
    with (ROOT/'owners.log').open('wb') as log:
        subprocess.run([str(qrenderdoc),'--python',str(ROOT/'owners.py')], timeout=175,
                       cwd=ROOT, env=dict(os.environ, AZR_ANCHOR_RUN=str(ROOT)),
                       stdout=log, stderr=subprocess.STDOUT, startupinfo=startup, check=True)


def fixture():
    build = Path('D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-release')
    exe = build/'AzureProjectedReflectionCameraGpuTests.exe'
    shader = ROOT/'baseline.spv'
    assert sha(shader) == load('request.json')['player']['expectedProgram']
    receipt = dict(executableSha256=sha(exe), shaderSha256=sha(shader), cases={})
    for mode,expected in (('history-response-tracked',0), ('history-response-background',1)):
        out = ROOT/mode
        args = [str(exe),str(shader),str(out),mode]
        result = subprocess.run(args,capture_output=True,timeout=55,cwd=ROOT)
        (ROOT/(mode+'.log')).write_bytes(result.stdout+result.stderr)
        view = json.loads((out/'result.json').read_bytes())
        receipt['cases'][mode] = dict(command=args, exitCode=result.returncode, result=view)
        save('fixture.json', receipt)
        assert result.returncode == expected
        assert view['validationErrors'] == view['liveBuffers'] == view['liveImages'] == 0
        assert view['regionPixels'] == 2432 and view['minimumFraction'] == .75
        if expected == 0:
            assert view['redHits'] >= .75*view['regionPixels']
        else:
            assert view['redHits'] == 0
    names = ('history-response-tracked','history-response-background')
    raw = [[(ROOT/m/(str(i)+'.bin')).read_bytes() for i in range(3)] for m in names]
    assert any(raw[0][2]) and not any(raw[1][2])
    # The inactive confidence changes the published footprint; ray geometry and color production remain active.
    assert raw[0][0] == raw[1][0]
    receipt['outputs'] = {name:[dict(sha256=sha(ROOT/name/(str(i)+'.bin')),bytes=len(data))
                               for i,data in enumerate(blobs)] for name,blobs in zip(names,raw)}
    receipt['status'] = 'passed'
    save('fixture.json',receipt)


if __name__ == '__main__':
    failures = []
    for action in (fixture, probes):
        try:
            action()
        except Exception as error:
            failures.append(repr(error))
    save('supplement.json',dict(failures=failures))
    sys.exit(bool(failures))
