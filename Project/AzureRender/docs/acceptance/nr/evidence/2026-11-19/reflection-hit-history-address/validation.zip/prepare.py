"""Prepare bounded probes for the two retained reflection dispatches."""
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import struct
import subprocess
import sys

OUT = Path(__file__).resolve().parent
WORK = OUT.parents[2]
RUNS = OUT.parent
NATIVE = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261029-052336-native-hierarchical-reflection-52b603')
SDK = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
PYTHON = Path('D:/Projects/FYP/Project/AzureRender/build/reinstall-environment/venv/Scripts/python.exe')
QRENDERDOC = Path('D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe')
BASE = 'f7f9e072f4975a580fba87c65e0579e15710dc6b'
SOURCES = {'native': RUNS/'20261119-181852-nr-same-frame-reflection-lineage-ffb239',
           'player': RUNS/'20261119-220148-nr-player-same-frame-capture-31bfb3'}
PROBES = {'hitUv': (154, 8, 0x100046), 'historyUv': (320, 2, 0x100046),
          'rayDepth': (154, 8, 0x100aa6)}
sys.path.insert(0, str(RUNS/'20261112-053111-intel-reference-visibility-sources-5238e2'/'native-normal-explicit-mips'))
from dxbc_util import checksum, chunks, dest, inst, instructions, opcode, opcodes, rebuild, words


def read(p):
    return json.loads(p.read_bytes())


def write(p, d):
    p.write_text(json.dumps(d, indent=2) + '\n', encoding='utf-8')


def digest(data):
    return sha256(data).hexdigest()


def file_hash(path):
    with open(path, 'rb') as f:
        return file_digest(f, 'sha256').hexdigest()


def patch_native(code, name):
    assert checksum(code) == code[4:20]
    rows = chunks(code)
    index, = (i for i, (kind, _) in enumerate(rows) if kind == b'SHEX')
    original = words(rows[index][1])
    program = original.copy()
    offsets = {i+4:(at, op, size) for i, at, op, size in instructions(program) if i is not None}
    instruction, register, swizzle = PROBES[name]
    sample, op, _ = offsets[instruction]
    assert op == opcode('SAMPLE_L') and program[sample+5:sample+7] == [0x100046, register]
    store, op, size = offsets[327]
    assert op == opcodes['D3D11_SB_OPCODE_STORE_UAV_TYPED']
    assert program[store+1:store+size] == [0x11e0f2, 1, 0x100546, 0, 0x100046, 4]
    assembly = (NATIVE/'event-8702.asm').read_text(encoding='utf-8-sig')
    _, tail = assembly.split(str(instruction) + ':')
    assert 'r13.' not in tail
    move = inst('MOV', dest(13, 3), [swizzle, register])
    program[store+size-2:store+size] = [0x100046, 13]
    program[sample:sample] = move
    program[1] = len(program)
    restored = program.copy()
    del restored[sample:sample+len(move)]
    restored[store+size-2:store+size] = original[store+size-2:store+size]
    restored[1] = original[1]
    assert restored == original
    rows[index] = (b'SHEX', struct.pack('<{}I'.format(len(program)), *program))
    patched = rebuild(code, rows)
    assert checksum(patched) == patched[4:20]
    return patched


def patch_player(source, name):
    declaration = b'uint4 r0,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13;'
    point = b'float4 v320=previousColor.SampleLevel(' if name == 'historyUv' else b'float4 v154=motionInput.SampleLevel('
    store = b'outputFootprint[outputPixel]=asfloat(r4.xyxx);'
    for part in (declaration, point, store):
        assert source.count(part) == 1
    value = {'hitUv': b'asfloat(r8.xy)', 'historyUv': b'asfloat(r2.xy)', 'rayDepth': b'asfloat(r8.zz)'}[name]
    return source.replace(declaration, declaration+b'\nfloat2 probeValue=float2(0,0);').replace(
        point, b'probeValue='+value+b';\n'+point).replace(
        store, b'outputFootprint[outputPixel]=float4(probeValue, 0, 0);')


def compile_player(name, source):
    path = OUT/(name+'.hlsl')
    binary = OUT/(name+'.spv')
    path.write_bytes(source)
    flags = ['-spirv','-T','cs_6_0','-E','main','-HV','2018','-fspv-target-env=vulkan1.1',
             '-fvk-b-shift','0','0','-fvk-t-shift','1','0','-fvk-s-shift','8','0','-fvk-u-shift','9','0','-Od']
    subprocess.run([str(SDK/'dxc.exe'), *flags, '-Fo', str(binary), str(path)], check=True, timeout=30)
    subprocess.run([str(SDK/'spirv-val.exe'), '--target-env', 'vulkan1.1', str(binary)], check=True, timeout=30)
    return file_hash(binary)


def prepare():
    task = dict(baseline=BASE, hypothesis='History address and source radiance explain prefilter anchor disagreement.',
                acceptance='Verify capture and bindings, preserve color/confidence, restore original bytes, verify history color and validity independently.',
                budgetBytes=67108864, captureCreation=False)
    write(OUT/'task-card.json', task)
    source = subprocess.check_output(['git','show','6738365:Project/AzureRender/shaders/projected_reflection_trace.hlsl'],cwd=WORK)
    native = (NATIVE/'event-8702.dxbc').read_bytes()
    controls = {'native': digest(native), 'player': compile_player('baseline', source)}
    jobs = {}
    for label, folder in SOURCES.items():
        archive = read(folder/(label+'-result.json'))
        stage = archive['stages']['trace']
        assert controls[label] == stage['shaderSha256']
        jobs[label] = dict(capture=archive['capture'], points=archive['points'], frame=archive['frameNumber'],
                           trace=stage, expectedProgram=controls[label], probes={})
        if label == 'player':
            receipt = read(folder/'capture-receipt.json')['artifacts'][0]
            jobs[label]['captureExpectedSha256'] = receipt['sha256']
        for name in PROBES:
            if label == 'native':
                path = OUT/(name+'.dxbc')
                path.write_bytes(patch_native(native, name))
                hashed = file_hash(path)
            else:
                hashed = compile_player(name, patch_player(source, name))
            jobs[label]['probes'][name] = hashed
    jobs['toolFingerprints'] = {p.name:file_hash(p) for p in (SDK/'dxc.exe', SDK/'dxcompiler.dll', SDK/'spirv-val.exe', QRENDERDOC)}
    jobs['playerSourceSha256'] = digest(source)
    jobs['evidenceBase'] = BASE
    jobs['productionSource'] = '6738365'
    write(OUT/'request.json', jobs)


def replay():
    assert Path(read(Path('D:/Projects/FYP-coordination/resources/current.json'))['output']).resolve() == OUT
    jobs = read(OUT/'request.json')
    for label in SOURCES:
        job = jobs[label]
        capture = Path(job['capture'])
        job['captureBytes'] = capture.stat().st_size
        job['captureSha256'] = file_hash(capture)
        assert job.get('captureExpectedSha256', job['captureSha256']) == job['captureSha256']
    write(OUT/'request.json', jobs)
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = 0
    with (OUT/'replay.log').open('wb') as log:
        subprocess.run([str(QRENDERDOC),'--python',str(OUT/'replay.py')], check=True, timeout=240,
                       cwd=OUT, env=dict(os.environ, AZR_ANCHOR_RUN=str(OUT)),
                       stdout=log, stderr=subprocess.STDOUT, startupinfo=startup)


if __name__ == '__main__':
    {'prepare':prepare,'replay':replay}[sys.argv[1]]()

