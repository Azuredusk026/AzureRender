"""Extract eight cross-address texel pairs from hash-matched full history images."""
from pathlib import Path
import json
import zlib
from verify import ROOT, read, sha, anchors

PORTABLE = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261031-060648-ray-vulkan-a27711/frozen-inputs-portable')
PLAYER = ROOT.parent/'20261119-220148-nr-player-same-frame-capture-31bfb3'/'player'
req=read('request.json')
addresses={tuple(a['historyDisplay']) for label in ('native','player') for a in anchors(req,label)}
out={}
for label,path,decode in (('native',PORTABLE/'previousColor.bin',lambda a:a),
                          ('player',PLAYER/'trace-0-0.zlib',zlib.decompress)):
    raw=decode(path.read_bytes())
    attachment=read(label+'.json')['attachments']['historyColor']
    assert sha(raw)==attachment['sha256']
    w,h=attachment['extent']
    assert len(raw)==w*h*8
    out[label]=dict(fullSha256=sha(raw), samples=[])
    for x,y in sorted(addresses):
        ty=h-1-y if label=='native' else y
        begin=(ty*w+x)*8
        out[label]['samples'].append(dict(display=[x,y],storage=[x,ty],raw=raw[begin:begin+8].hex()))
(ROOT/'cross-source.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
