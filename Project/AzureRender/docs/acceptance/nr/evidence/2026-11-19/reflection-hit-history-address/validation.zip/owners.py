"""Read geometry events from the existing captures at witnessed hit texels."""
import json
import os
import math
from hashlib import sha256
from pathlib import Path
import struct
import traceback
import renderdoc as rd

ROOT=Path(os.environ['AZR_ANCHOR_RUN'])


def load(name):
    return json.loads((ROOT/name).read_bytes())


def save(name, data):
    (ROOT/name).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


def sane(v):
    return float(v) if math.isfinite(v) and abs(v) < 1e20 else None


def follow(label):
    job=load('request.json')[label]
    r=load(label+'.json')
    geometry=r['geometryInputs'][0]
    observer=8690 if label=='native' else 21054
    cap=rd.OpenCaptureFile()
    ctl=None
    report=dict(event=observer, capture=r['captureSha256'], resource=geometry['resource'],
                frame=r['frame'], format=geometry['format'], witnesses=[])
    out=label+'-owners.json'
    try:
        assert cap.OpenFile(job['capture'],'',None)==rd.ResultCode.Succeeded
        opt=rd.ReplayOptions()
        opt.forceGPUVendor=rd.GPUVendor.nVidia
        opt.forceGPUDeviceID=0x28e0
        status,ctl=cap.OpenCapture(opt,None)
        assert status==rd.ResultCode.Succeeded and ctl.GetFrameInfo().frameNumber==job['frame']
        textures={str(t.resourceId):t for t in ctl.GetTextures()}
        actions={a.eventId:a for a in walk(ctl.GetRootActions())}
        names={str(d.resourceId):d.name for d in ctl.GetResources()}
        surface=textures[geometry['resource']]
        rid=surface.resourceId
        bpp=geometry['snapshot']['bytesPerPixel']
        ctl.SetFrameEvent(observer,True)
        raw=bytes(ctl.GetTextureData(rid,rd.Subresource()))
        assert sha256(raw).hexdigest()==geometry['snapshot']['sha256']
        for anchor, witness in zip(r['anchors'],geometry['witnesses']):
            matched=witness['pixels'] if label=='player' else [
                t for t in witness['pixels'] if t['raw'][:8] in {x['raw'] for x in anchor['hitSurface']}]
            assert len(matched)==1
            sample=matched[0]
            x,y=sample['xy']
            wanted=bytes.fromhex(sample['raw'])
            start=(surface.width*y+x)*bpp
            assert raw[start:start+bpp]==wanted
            ctl.SetFrameEvent(observer,True)
            history=ctl.PixelHistory(rid,x,y,rd.Subresource(),rd.CompType.Typeless)
            rows=[]
            for h in history:
                if h.eventId>observer:
                    continue
                rows.append(dict(event=h.eventId, primitive=h.primitiveID, passed=h.Passed(),
                    depthBefore=sane(h.preMod.depth), depthAfter=sane(h.postMod.depth)))
            verified=None
            for event in sorted({row['event'] for row in rows if row['passed']},reverse=True):
                action=actions.get(event)
                if action is None or not action.flags&rd.ActionFlags.Drawcall:
                    continue
                def pixel(at):
                    ctl.SetFrameEvent(at,True)
                    data=bytes(ctl.GetTextureData(rid, rd.Subresource()))
                    return data[start:start+bpp]
                after=pixel(event)
                if after!=wanted:
                    continue
                before=pixel(event-1)
                if before==after:
                    continue
                ctl.SetFrameEvent(event,True)
                pipe=ctl.GetPipelineState()
                index=pipe.GetIBuffer()
                shader=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
                ids=[v.resourceId for v in pipe.GetVBuffers()]
                markers=[]
                a=action.parent
                while a:
                    if a.customName:
                        markers.append(a.customName)
                    a=a.parent
                verified=dict(event=event, indexBuffer=str(index.resourceId),indexBufferName=names.get(str(index.resourceId)),
                    indexBufferOffset=index.byteOffset, firstIndex=action.indexOffset, vertexOffset=action.vertexOffset,
                    indices=action.numIndices, instances=action.numInstances, instanceOffset=action.instanceOffset,
                    vertexBuffers=[dict(resource=str(v),name=names.get(str(v))) for v in ids],
                    pixelShaderSha256=sha256(bytes(shader.rawBytes)).hexdigest() if shader else None,
                    passMarkers=markers, rawBefore=before.hex(), rawAfter=after.hex(),
                    modifyingPrimitives=[row['primitive'] for row in rows if row['event']==event and row['passed']])
                break
            report['witnesses'].append(dict(anchor=anchor['display'], pixel=sample, candidates=rows, draw=verified))
            save(out,report)
        report['status']='observed'
    except Exception:
        report['error']=traceback.format_exc()
        raise
    finally:
        save(out,report)
        if ctl is not None:
            ctl.Shutdown()
        cap.Shutdown()


failures=[]
for label in ('native','player'):
    try:
        follow(label)
    except Exception:
        failures.append([label,traceback.format_exc()])
save('owners-status.json',dict(failures=failures))
os._exit(bool(failures))
