"""Replay retained captures; verify probe neutrality and read the sampled texels."""
import math
import os
from hashlib import sha256
import json
from pathlib import Path
import struct
import traceback
import renderdoc as rd

ROOT = Path(os.environ['AZR_ANCHOR_RUN'])
REQUEST = json.loads((ROOT/'request.json').read_bytes())
SLOTS = {
    'native': ('read:1:texture1','read:2:texture2','read:3:texture3','read:4:texture4',
               'write:0:uav0','write:1:uav1','write:2:uav2'),
    'player': ('read:2:previousColor','read:3:previousDepth','read:4:currentDepth','read:5:motionInput',
               'write:9:outputColor','write:10:outputFootprint','write:11:outputConfidence'),
}


def write(p, row):
    (ROOT/p).write_text(json.dumps(row, indent=2) + '\n', encoding='utf-8')


def digest(raw):
    return sha256(raw).hexdigest()


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


def binding_rows(pipe, stage, reflected):
    for kind, descriptors, declarations in (
        ('read', pipe.GetReadOnlyResources(stage), reflected.readOnlyResources),
        ('write', pipe.GetReadWriteResources(stage), reflected.readWriteResources),
    ):
        for use in descriptors:
            declaration = declarations[use.access.index]
            d = use.descriptor
            if d.resource == rd.ResourceId.Null():
                continue
            key = '{}:{}:{}'.format(kind, declaration.fixedBindNumber, declaration.name)
            yield key, (d.resource, d.firstMip, d.numMips)


def texel(snapshot, x, y):
    data, meta = snapshot
    w, h = meta['extent']
    assert 0 <= x < w and 0 <= y < h
    n = meta['bytesPerPixel']
    pos = n*(w*y+x)
    return dict(xy=[x,y], raw=data[pos:pos+n].hex())


def candidates(raw, size):
    lo = max(0, int(math.floor((raw-.5)*size/65535)))
    hi = min(size-1, int(math.floor((raw+.5)*size/65535)))
    return range(min(lo,size-1), max(0,hi)+1)


def samples(snapshot, uv16):
    w, h = snapshot[1]['extent']
    return [texel(snapshot,x,y) for y in candidates(uv16[1],h) for x in candidates(uv16[0],w)]


def use_rows(ctl, resource, event):
    return [dict(event=u.eventId, kind=str(u.usage)) for u in ctl.GetUsage(resource) if u.eventId <= event]


def producer_inputs(ctl, resources, event):
    ctl.SetFrameEvent(event, True)
    pipe = ctl.GetPipelineState()
    shader = pipe.GetShaderReflection(rd.ShaderStage.Compute)
    if shader is None:
        return []
    return [dict(key=k, resource=str(t), mip=mip, format=resources[str(t)].format.Name(),
                 extent=[resources[str(t)].width, resources[str(t)].height])
            for k,(t,mip,_) in binding_rows(pipe,rd.ShaderStage.Compute,shader)
            if k.startswith('read:') and str(t) in resources]


def replay(label):
    job = REQUEST[label]
    stage = job['trace']
    event = stage['event']
    cap = rd.OpenCaptureFile()
    ctl = None
    result = dict(status='started', label=label, frame=job['frame'], event=event,
                  captureSha256=job['captureSha256'], shader=job['expectedProgram'])
    write(label+'.json', result)
    try:
        assert cap.OpenFile(job['capture'],'',None) == rd.ResultCode.Succeeded
        opts = rd.ReplayOptions()
        opts.forceGPUVendor = rd.GPUVendor.nVidia
        opts.forceGPUDeviceID = 0x28e0
        status, ctl = cap.OpenCapture(opts,None)
        assert status == rd.ResultCode.Succeeded and not ctl.GetAPIProperties().degraded
        assert ctl.GetFrameInfo().frameNumber == job['frame']
        ctl.SetFrameEvent(event,True)
        pipe = ctl.GetPipelineState()
        compute = rd.ShaderStage.Compute
        shader = pipe.GetShaderReflection(compute)
        original = pipe.GetShader(compute)
        assert digest(bytes(shader.rawBytes)) == job['expectedProgram']
        bound = dict(binding_rows(pipe,compute,shader))
        assert set(bound) == set(stage['bindings'])
        for k,(t,mip,count) in bound.items():
            expected = stage['bindings'][k]
            assert (str(t),mip,count) == (expected['resource'],expected['firstMip'],expected['mipCount'])
        result['bindings'] = stage['bindings']
        result['constants'] = stage['constants']
        resources = {str(t.resourceId):t for t in ctl.GetTextures()}

        def snapshot(resource, mip=0):
            t = resources[str(resource)]
            data = bytes(ctl.GetTextureData(resource,rd.Subresource(mip,0,0)))
            w,h = max(1,t.width>>mip),max(1,t.height>>mip)
            assert len(data) % (w*h) == 0
            meta = dict(resource=str(resource), mip=mip, extent=[w,h], format=t.format.Name(),
                        bytesPerPixel=len(data)//(w*h), sha256=digest(data))
            return data, meta

        names = ('historyColor','historyDepth','currentDepth','motion','rayColor','footprint','confidence')
        slots = dict(zip(names,SLOTS[label]))
        bound_ids = {n:bound[k][0] for n,k in slots.items()}
        bindings = {n:snapshot(bound[k][0],bound[k][1]) for n,k in slots.items()}
        for n, (_, meta) in bindings.items():
            assert meta['sha256'] == stage['textures'][slots[n]][0]['fullSha256'], (n,meta)
        result['attachments'] = {n:meta for n,(_,meta) in bindings.items()}
        result['usages'] = {n:use_rows(ctl,bound_ids[n],event) for n in ('historyColor','historyDepth','currentDepth','motion')}
        result['preparationInputs'] = {}
        for use in result['usages']['currentDepth']:
            if use['event'] < event:
                entries = producer_inputs(ctl,resources,use['event'])
                if entries:
                    result['preparationInputs'][str(use['event'])] = entries
        ctl.SetFrameEvent(event,True)
        points = [(x//2,719-y//2 if label=='native' else y//2) for x,y in job['points']]
        result['probes'] = {}
        encoding = rd.ShaderEncoding.DXBC if label=='native' else rd.ShaderEncoding.SPIRV
        extension = '.dxbc' if label=='native' else '.spv'
        for name, expected_hash in job['probes'].items():
            code = (ROOT/(name+extension)).read_bytes()
            assert digest(code) == expected_hash
            target, error = ctl.BuildTargetShader(shader.entryPoint,encoding,code,rd.ShaderCompileFlags(),compute)
            assert target != rd.ResourceId.Null(), error
            try:
                ctl.ReplaceResource(original,target)
                ctl.SetFrameEvent(event,True)
                current = {n:snapshot(bound_ids[n]) for n in ('rayColor','footprint','confidence')}
                assert current['rayColor'][1] == bindings['rayColor'][1]
                assert current['confidence'][1] == bindings['confidence'][1]
                assert current['footprint'][1]['sha256'] != bindings['footprint'][1]['sha256']
                result['probes'][name] = dict(shader=expected_hash, outputs={n:m for n,(_,m) in current.items()},
                    texels=[texel(current['footprint'],x,y) for x,y in points])
            finally:
                ctl.RemoveReplacement(original)
                ctl.FreeTargetResource(target)
        ctl.SetFrameEvent(event,True)
        result['restoration'] = {n:snapshot(bound_ids[n])[1] for n in names}
        assert result['restoration'] == result['attachments']
        result['anchors'] = []
        for i,(x,y) in enumerate(points):
            hit = struct.unpack('<HH',bytes.fromhex(result['probes']['hitUv']['texels'][i]['raw']))
            history = struct.unpack('<HH',bytes.fromhex(result['probes']['historyUv']['texels'][i]['raw']))
            result['anchors'].append(dict(display=job['points'][i], attachment=[x,y], hitUv16=hit, historyUv16=history,
                receiverDepth=texel(bindings['currentDepth'],x,y),
                hitSurface=samples(bindings['currentDepth'],hit),
                hitMotion=samples(bindings['motion'],hit),
                historyColor=samples(bindings['historyColor'],history),
                historyDepth=samples(bindings['historyDepth'],history),
                rayColor=texel(bindings['rayColor'],x,y), confidence=texel(bindings['confidence'],x,y)))
        result['status'] = 'readback-verified'
        write(label+'.json',result)
        actions = {a.eventId:a for a in walk(ctl.GetRootActions())}
        # The Player preparation consumes a full-resolution surface descriptor.
        # The native depth reducer's producer inputs will identify its full-resolution depth.
        producer_event = max(int(key) for key in result['preparationInputs'])
        source_inputs = result['preparationInputs'][str(producer_event)]
        if label=='player':
            picked = [v for v in source_inputs if v['key'].endswith(':sourceSurface')]
        else:
            picked = [v for v in source_inputs if v['extent']==[2560,1440] and
                      ('DEPTH' in v['format'] or v['format'].startswith(('D32','D24','R32','R24')))]
        result['geometryInputs'] = picked
        write(label+'.json',result)
        for source in picked[:1]:
            t = resources[source['resource']]
            uses = use_rows(ctl,t.resourceId,producer_event)
            source['lastUsages'] = uses[-24:]
            latest = [(u,actions.get(u['event'])) for u in reversed(uses) if u['event'] < producer_event]
            source['actions'] = [dict(use=u, name=action.customName, copySource=str(action.copySource),
                                      copyDestination=str(action.copyDestination), flags=str(action.flags))
                                 for u,action in latest[:12] if action is not None]
            ctl.SetFrameEvent(producer_event-1,True)
            source_snapshot = snapshot(t.resourceId)
            source['snapshot'] = source_snapshot[1]
            source['witnesses'] = []
            for anchor in result['anchors']:
                row = dict(anchor=anchor['display'], pixels=[])
                for point in anchor['hitSurface']:
                    x,y = point['xy']
                    # Prepared half-resolution depth uses the centre texel of each 2x2 block.
                    pixels = [(2*x+1,2*y+1)] if label=='player' else [(2*x+dx,2*y+dy) for dy in range(2) for dx in range(2)]
                    row['pixels'].extend(texel(source_snapshot,*p) for p in pixels)
                source['witnesses'].append(row)
            write(label+'.json',result)
        result['status'] = 'qualified'
    except Exception:
        result['error'] = traceback.format_exc()
        raise
    finally:
        write(label+'.json',result)
        if ctl is not None:
            ctl.Shutdown()
        cap.Shutdown()


errors = []
for tag in ('native','player'):
    try:
        replay(tag)
    except Exception:
        errors.append([tag,traceback.format_exc()])
write('replay-status.json',dict(errors=errors))
os._exit(1 if errors else 0)
