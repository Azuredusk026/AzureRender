"""Freeze the existing control; collect one bounded same-frame GPU batch."""
from pathlib import Path
from hashlib import file_digest
from zipfile import ZipFile
import json,os,sys,subprocess,time

O=Path(__file__).resolve().parent
W=O.parents[2]
MAIN=Path('D:/Projects/FYP/Project/AzureRender')
HOST=O.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/msaa-release'
read=lambda p:json.loads(Path(p).read_bytes())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
def sha(p):
    with Path(p).open('rb') as f:return file_digest(f,'sha256').hexdigest()
sys.path.insert(0,str(MAIN/'tools'))
import artifact_budget,artifact_maintenance as art

def freeze():
    q=read(W/'docs/acceptance/nr/evidence/2026-11-19/reflection-confidence-lod/qualification.json')
    assert sha(HOST/'AzurePlayer.exe')==q['retainedHostSha256']
    shaders={p.name:sha(p) for p in (HOST/'shaders').glob('*.spv')}
    assert len(shaders)==895
    assert shaders['projected_reflection_trace.comp.spv']==q['source']['baselineShader']
    assert shaders['reflection_spatial_filter.comp.spv']==q['build']['outputs']['control']['program']
    with ZipFile(W/'docs/acceptance/nr/evidence/2026-11-19/reflection-confidence-lod/validation.zip') as z:
        args=json.loads(z.read('nvidia-control/command.json'))
    assert Path(args[0])==HOST/'AzurePlayer.exe'
    project=Path(args[args.index('--project')+1])
    level=Path(q['source']['level'])
    assert sha(project)==q['source']['projectSha256'] and sha(level)==q['source']['levelSha256']
    for flag,value in (('--capture-dir',O/'capture/frames'),('--runtime-report',O/'capture/runtime.json')):
        args[args.index(flag)+1]=str(value)
    environment=dict(VK_LAYER_PATH='D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64;D:/Tools/VulkanSDK/1.4.350.0/Bin',
        VK_INSTANCE_LAYERS='VK_LAYER_RENDERDOC_Capture;VK_LAYER_KHRONOS_validation',
        VK_LAYER_VALIDATE_SYNC='1',ENABLE_VULKAN_RENDERDOC_CAPTURE='1',DOTNET_ROOT='D:/Tools/dotnet9',
        VK_DRIVER_FILES=str(O.parent/'20261112-231945-projected-hair-reference-grid-4b775d/nv-vk64-active-absolute.json'))
    native=MAIN/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame3534.rdc'
    req=dict(baseCommit='fe5ba3b982cdd739b6396c09256aca7f96a6ccde',evidenceCommit='4676be7',
        points=[[1265,1137],[1231,1137],[1537,1137],[1231,1071]],
        playerTraceShader=q['source']['baselineShader'],filterShader=q['build']['outputs']['control']['program'],
        shaders=shaders,playerSha256=sha(HOST/'AzurePlayer.exe'),projectSha256=sha(project),levelSha256=sha(level),
        nativeCapture=str(native),nativeCaptureBytes=native.stat().st_size,
        captureRequest=dict(format='RenderDocRequest/1',operation='capture',
            source=dict(path=str(HOST/'AzurePlayer.exe'),bytes=(HOST/'AzurePlayer.exe').stat().st_size,sha256=sha(HOST/'AzurePlayer.exe')),
            output=str(O/'capture'),arguments=args[1:],working_directory=str(W),
            frame=1,timeout=420,environment=environment))
    write(O/'request.json',req)
    return req

if __name__=='__main__':
    req=freeze()
    if '--prepare' in sys.argv:
        print('Frozen player, 895 shader hashes, project, level, camera and command.')
        sys.exit(0)
    current=read('D:/Projects/FYP-coordination/resources/current.json')
    assert current['state']=='held' and Path(current['output'])==O
    budget=artifact_budget.check(W/'build',run=O,planned=70_000_000 if '--native-only' in sys.argv or (O/'capture/compressed-capture.json').exists() else 1_850_000_000)
    assert budget['allowed'],budget
    write(O/'budget.json',budget)
    (O/'capture').mkdir(exist_ok=True)
    assert not list((O/'capture').glob('*.rdc')),'A prior capture must be reused, not overwritten'
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    env=art.managed_environment(O/'tmp')
    env['AZR_SAME_FRAME_ROOT']=str(O)
    if '--native-only' in sys.argv:env['AZR_NATIVE_ONLY']='1'
    with (O/'worker.log').open('wb') as log:
        p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(O/'worker.py')],
            cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=900)
    assert req['shaders']=={f.name:sha(f) for f in (HOST/'shaders').glob('*.spv')}
    assert req['playerSha256']==sha(HOST/'AzurePlayer.exe')
    write(O/'batch.json',dict(exitCode=p.returncode,productionUnchanged=True))
    assert p.returncode==0,(O/'worker-error.json').read_text() if (O/'worker-error.json').exists() else p.returncode
