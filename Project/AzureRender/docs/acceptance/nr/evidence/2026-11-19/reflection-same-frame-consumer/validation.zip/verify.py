"""Verify retained same-frame evidence without private captures or a GPU."""
from pathlib import Path
from hashlib import sha256
import json
import numpy as np
from measure_reference import measure

O=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
for name,digest in read(O/'manifest.json').items():
    assert sha256((O/name).read_bytes()).hexdigest()==digest,name
n=read(O/'native-sampling.json')
r=read(O/'native-result.json')
f=read(O/'frame-identity.json')
assert n['frame']==r['frameNumber']==3534
assert r['traceEvent']==8702 and r['filterEvent']==8811
assert r['status']=='qualified-same-frame-stage-readbacks'
data=np.load(O/'native-stage-values.npz',allow_pickle=False)

def decode(words):
    result=[]
    for shift,mantissa in ((0,6),(11,6),(22,5)):
        v=words>>shift;e=((v>>mantissa)&31).astype(np.int32)
        m=(v&((1<<mantissa)-1))/float(1<<mantissa)
        assert (e<31).all()
        result.append(np.where(e==0,np.ldexp(m,-14),np.ldexp(1+m,e-15)))
    return np.stack(result,axis=-1)

def image(name):
    record=n['records'][name];entry=record['inputRecord']
    raw=data[('filtered' if name=='consumedFiltered' else name)+'_packed'].tobytes()
    assert sha256(raw).hexdigest()==record['sha256']
    x,y,u,v=entry['rect'];fmt=entry['format']
    if fmt=='R11G11B10_FLOAT':a=decode(np.frombuffer(raw,'<u4').reshape(v-y,u-x))
    elif fmt=='R8_UNORM':a=np.frombuffer(raw,'u1').reshape(v-y,u-x,1)/255.
    elif fmt=='R32_FLOAT':a=np.frombuffer(raw,'<f4').reshape(v-y,u-x,1)
    else:raise ValueError(fmt)
    if entry['nativeStorageFlip']:a=a[::-1]
    return a,record['bounds']

def at(pair,x,y):
    a,b=pair
    return a[y-b[1],x-b[0]]

decoded={name:image(name) for name in n['records']}
assert n['records']['filtered']['fullSha256']==n['records']['consumedFiltered']['fullSha256']
assert n['records']['filtered']['fullSha256']=='5273b1514da46c6ff8a0d6c457d9ffc5cfde855dbc4e80af7d3a9dd43c0aab98'
for witness in n['witnesses']:
    values=np.array([at(decoded['filtered'],*xy) for xy in witness['filterXY']])
    conf=np.array([at(decoded['confidence'],*xy)[0] for xy in witness['filterXY']])
    np.testing.assert_array_equal(values,witness['colorTaps'])
    np.testing.assert_array_equal(conf,witness['confidenceTaps'])
    np.testing.assert_allclose(witness['weights'],[9/16,3/16,3/16,1/16],rtol=0,atol=0)
    np.testing.assert_allclose(np.array(witness['weights'])@values,witness['reconstructedColor'],rtol=0,atol=1e-12)
    np.testing.assert_allclose(np.array(witness['weights'])@conf,witness['reconstructedConfidence'],rtol=0,atol=1e-12)
    np.testing.assert_array_equal(at(decoded['consumerHdr'],*witness['displayXY']),witness['actualHdr'])
for key,levels in r['stages']['trace']['textures'].items():
    if not key.startswith('read:'):continue
    assert sha256(data['traceInput_'+key.replace(':','_')].tobytes()).hexdigest()==levels[0]['sha256']
debug=n['debug'];d=r['consumerDebug']['nativeTextureWindows']
np.testing.assert_array_equal(debug['colorSample'],d['2196']['r3'][:3])
np.testing.assert_array_equal(debug['incidentAfterMix'],d['2199']['r4'][:3])
np.testing.assert_allclose(np.array(debug['probeBeforeMix'])*(1-debug['confidenceSample'])+
    np.array(debug['colorSample'])*debug['confidenceSample'],debug['incidentAfterMix'],rtol=0,atol=1e-6)
residual=np.array(debug['colorSample'])-n['witnesses'][0]['reconstructedColor']
np.testing.assert_array_equal(residual,debug['actualMinusIdealInterpolation'])
assert debug['interpolationWithinOneEMinusSix']==bool(abs(residual).max()<=1e-6)
assert debug['interpolationWithinOneEMinusSix'] is False
targets=np.load(O/'target-crops.npz',allow_pickle=False)
checks=0
for row in f['rows']:
    assert row['fullFrameMatchesFe5Control'] and row['bgraRawSha256']==row['expectedFe5Control']['raw']
    frame=row['frameIndex']
    for region,expected in row['regions'].items():
        if region=='complete':continue
        actual=measure(targets[f'frame{frame}_{region}'],targets['reference_'+region])
        for metric in ('ssim','medianLumaRelativeError','meanAbsByte','peak'):
            np.testing.assert_allclose(actual[metric],expected[metric],rtol=0,atol=1e-10)
        checks+=1
for name,digest in read(O/'manifest.json').items():
    assert sha256((O/name).read_bytes()).hexdigest()==digest,name
print('PASS: two frame identities, %d regional scores, four native tap neighbourhoods, raw input hashes and witnessed native blend.'%checks)
print('OPEN: Player same-frame stage readbacks; native ideal-interpolation residual is retained.')
