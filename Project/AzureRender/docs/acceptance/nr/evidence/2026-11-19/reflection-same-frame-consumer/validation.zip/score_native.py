"""Verify native same-frame sampling and the witnessed consumer blend."""
from pathlib import Path
from hashlib import sha256
import json,zlib,struct
import numpy as np

O=Path(__file__).resolve().parent
P=O/'native'
read=lambda p:json.loads(p.read_bytes())
r=read(P/'result.json')
assert r['status']=='qualified-same-frame-stage-readbacks' and r['frameNumber']==3534
arrays={};records={}

def decode(words):
    result=[]
    for shift,mantissa in ((0,6),(11,6),(22,5)):
        v=words>>shift;e=((v>>mantissa)&31).astype(np.int32)
        m=(v&((1<<mantissa)-1))/float(1<<mantissa)
        assert (e<31).all()
        result.append(np.where(e==0,np.ldexp(m,-14),np.ldexp(1+m,e-15)))
    return np.stack(result,axis=-1)

def image(entry,name):
    packed=(P/entry['file']).read_bytes()
    assert sha256(packed).hexdigest()==entry['encodedSha256']
    raw=zlib.decompress(packed)
    assert sha256(raw).hexdigest()==entry['sha256']
    x,y,u,v=entry['rect'];fmt=entry['format']
    if fmt=='R11G11B10_FLOAT':value=decode(np.frombuffer(raw,'<u4').reshape(v-y,u-x))
    elif fmt=='R8_UNORM':value=np.frombuffer(raw,'u1').reshape(v-y,u-x)[...,None]/255.
    elif fmt=='R32_FLOAT':value=np.frombuffer(raw,'<f4').reshape(v-y,u-x,1)
    else:raise ValueError(fmt)
    if entry['nativeStorageFlip']:value=value[::-1];y,v=entry['height']-v,entry['height']-y
    arrays[name]=value
    arrays[name+'_packed']=np.frombuffer(raw,'u1')
    records[name]={'bounds':[x,y,u,v],'resource':entry['resource'],'event':entry['event'],
        'sourceFile':entry['file'],'sha256':entry['sha256'],'fullSha256':entry['fullSha256'],
        'inputRecord':entry}
    return value,records[name]['bounds']

filtered,bounds=image(r['stages']['filterOutput'],'filtered')
confidence,cbounds=image(r['stages']['consumerConfidence'],'confidence')
inputRecord=next(v for k,v in r['stages']['filter']['textures'].items() if k.startswith('read:2:'))[0]
image(inputRecord,'filterInput0')
traceRecord=next(v for k,v in r['stages']['trace']['textures'].items() if k.startswith('write:0:'))[0]
image(traceRecord,'traceOutput0')
depthRecord=next(v for k,v in r['stages']['filter']['textures'].items() if k.startswith('read:0:'))[0]
image(depthRecord,'depth')
consumer=r['consumers'][0]
hdr,hbounds=image(consumer['hdrAfter'],'consumerHdr')
consumed,readBounds=image(consumer['filterReadback'],'consumedFiltered')
assert records['filtered']['fullSha256']==records['consumedFiltered']['fullSha256']
assert records['filtered']['fullSha256']=='5273b1514da46c6ff8a0d6c457d9ffc5cfde855dbc4e80af7d3a9dd43c0aab98'
weights=np.array([9,3,3,1])/16
witnesses=[]
def at(a,b,x,y):return a[y-b[1],x-b[0]].tolist()
for row in r['pixelHistory']:
    x,y=row['displayXY'];hx,hy=x//2,y//2
    xy=[[hx,hy],[hx+1,hy],[hx,hy+1],[hx+1,hy+1]]
    colors=np.array([at(filtered,bounds,*p) for p in xy])
    conf=np.array([at(confidence,cbounds,*p) for p in xy])
    h=next(h for h in row['records'] if h['event']==consumer['event'] and not h['failed'])
    witnesses.append(dict(displayXY=[x,y],filterXY=xy,weights=weights.tolist(),
        colorTaps=colors.tolist(),confidenceTaps=conf[:,0].tolist(),
        reconstructedColor=(weights@colors).tolist(),reconstructedConfidence=float(weights@conf[:,0]),
        actualHdr=at(hdr,hbounds,x,y),actualShaderOutput=h['shaderOut'],
        actualQuantizedHdr=h['after']))
debug=r['consumerDebug'];assert debug['status']=='traced'
states=debug['nativeTextureWindows']
alpha=states['2196']['r0'][2]
sampled=states['2196']['r3'][:3]
probe=states['2196']['r4'][:3]
mixed=states['2199']['r4'][:3]
interpolationResidual=np.array(sampled)-np.array(witnesses[0]['reconstructedColor'])
np.testing.assert_allclose(alpha,witnesses[0]['reconstructedConfidence'],rtol=0,atol=1e-6)
np.testing.assert_allclose(mixed,np.array(probe)*(1-alpha)+np.array(sampled)*alpha,rtol=0,atol=1e-6)
traceInputs={}
for key,levels in r['stages']['trace']['textures'].items():
    if not key.startswith('read:'):continue
    entry=levels[0];raw=zlib.decompress((P/entry['file']).read_bytes())
    assert sha256(raw).hexdigest()==entry['sha256']
    arrays['traceInput_'+key.replace(':','_')]=np.frombuffer(raw,'u1')
    traceInputs[key]=entry
for name in ('traceOutput0','filterInput0','filtered','confidence','depth','consumerHdr'):
    assert np.isfinite(arrays[name]).all()
compact={name:value for name,value in arrays.items()
    if (name.endswith('_packed') or name.startswith('traceInput_')) and name!='consumedFiltered_packed'}
assert records['filtered']['sha256']==records['consumedFiltered']['sha256']
np.savez_compressed(O/'native-stage-values.npz',**compact)
summary=dict(status='native-consumer-measured-with-interpolation-residual',frame=3534,records=records,
    filterEvent=8811,consumerEvent=8912,witnesses=witnesses,traceInputs=traceInputs,
    debug=dict(event=debug['event'],instructions=debug['instructions'],
        confidenceSample=alpha,colorSample=sampled,probeBeforeMix=probe,incidentAfterMix=mixed,
        textureInstructions=[2194,2195],mixInstructions=[2196,2197,2198],
        actualMinusIdealInterpolation=interpolationResidual.tolist(),
        interpolationWithinOneEMinusSix=bool(np.max(abs(interpolationResidual))<=1e-6)),
    conclusion='At the traced native anchor confidence is one; the sampled reflection color is preserved by the incident-light blend. Material response and postprocessing are subsequent stages.',
    limitation='Current Player same-frame stage inputs are unavailable; this does not prove parity or root cause in the Player.')
(O/'native-sampling.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print('PASS: four native neighbourhoods, exact retained filter output, traced confidence and incident-light blend.')
print('OPEN: ideal four-tap interpolation residual:',interpolationResidual.tolist())
for w in witnesses:print(w['displayXY'],w['reconstructedColor'],w['reconstructedConfidence'],w['actualQuantizedHdr'])
