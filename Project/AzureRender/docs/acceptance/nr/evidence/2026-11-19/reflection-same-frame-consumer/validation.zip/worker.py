"""Read-only RenderDoc capture/replay; execute only inside the shared GPU lease."""
import os,sys,json,time,traceback,hashlib,struct,zlib,math,re
from pathlib import Path
import renderdoc as rd

O=Path(os.environ['AZR_SAME_FRAME_ROOT'])
request=json.loads((O/'request.json').read_bytes())
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools/native_render')
from renderdoc_worker import capture_target
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
def progress(stage):write(O/'progress.json',dict(stage=stage,time=time.time()))
points=request['points']
total=0

class TargetEnvironment:
    def __getattr__(self,name):return getattr(rd,name)
    def ExecuteAndInject(self,*args):
        args=list(args);environment=list(args[3])
        for name,value in request['captureRequest']['environment'].items():
            item=rd.EnvironmentModification();item.name=name;item.value=value;item.mod=rd.EnvMod.Set;environment.append(item)
        args[3]=environment
        return rd.ExecuteAndInject(*args)

def walk(rows):
    for row in rows:
        yield row
        yield from walk(row.children)

def replay(label,capturePath):
    global total
    out=O/label;out.mkdir(exist_ok=True)
    cap=rd.OpenCaptureFile();ctl=None
    report=dict(status='incomplete',capture=str(capturePath),points=points,stages={},consumers=[])
    write(out/'result.json',report)
    try:
        if str(capturePath).endswith('.zlib'):
            metadata=read(O/'capture/compressed-capture.json')
            encoded=Path(capturePath).read_bytes()
            assert sha(encoded)==metadata['encodedSha256']
            memory=zlib.decompress(encoded)
            assert len(memory)==metadata['sourceBytes'] and sha(memory)==metadata['sourceSha256']
            assert cap.OpenBuffer(memory,'rdc',None)==rd.ResultCode.Succeeded
            del encoded,memory
        else:
            assert cap.OpenFile(str(capturePath),'',None)==rd.ResultCode.Succeeded
        options=rd.ReplayOptions();options.forceGPUVendor=rd.GPUVendor.nVidia;options.forceGPUDeviceID=0x28e0
        status,ctl=cap.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and ctl is not None,str(status)
        props=ctl.GetAPIProperties()
        assert not props.degraded
        native=label=='native'
        report['api']=str(props.pipelineType)
        report['vendor']=str(props.vendor)
        report['frameNumber']=ctl.GetFrameInfo().frameNumber
        textures={str(t.resourceId):t for t in ctl.GetTextures()}
        actions=list(walk(ctl.GetRootActions()))
        actionById={a.eventId:a for a in actions}
        report['actionCount']=len(actions)
        def publish(name,raw):
            global total
            data=zlib.compress(raw,6);total+=len(data)
            assert total<70_000_000,'Readback output budget exceeded'
            path=out/(name+'.zlib');path.write_bytes(data)
            return dict(file=path.name,sha256=sha(raw),bytes=len(raw),encodedSha256=sha(data),encodedBytes=len(data))
        def texdata(resource,event,name,full=False,mip=0):
            ctl.SetFrameEvent(event,True)
            t=textures[str(resource)]
            raw=bytes(ctl.GetTextureData(t.resourceId,rd.Subresource(mip,0,0)))
            w,h=max(1,t.width>>mip),max(1,t.height>>mip)
            assert len(raw)%(w*h)==0
            bpp=len(raw)//(w*h)
            if full:
                rect=[0,0,w,h];data=raw
            else:
                scale=w/1280.
                x,u=max(0,int(498*scale)),min(w,int(792*scale)+1)
                y,v=max(0,int(478*scale)),min(h,int(702*scale)+1)
                if native:y,v=h-v,h-y
                rect=[x,y,u,v]
                data=b''.join(raw[(j*w+x)*bpp:(j*w+u)*bpp] for j in range(y,v))
            entry=dict(event=event,resource=str(resource),format=t.format.Name(),width=w,height=h,
                mip=mip,rect=rect,nativeStorageFlip=native,bytesPerPixel=bpp,fullSha256=sha(raw))
            entry.update(publish(name,data))
            return entry
        def bindings(stage):
            p=ctl.GetPipelineState();ref=p.GetShaderReflection(stage)
            if ref is None:return {},None
            found={}
            for kind,useds,declarations in (
                ('read',p.GetReadOnlyResources(stage),ref.readOnlyResources),
                ('write',p.GetReadWriteResources(stage),ref.readWriteResources)):
                for used in useds:
                    dec=declarations[used.access.index];d=used.descriptor
                    if d.resource==rd.ResourceId.Null():continue
                    row=dict(kind=kind,name=dec.name,bind=dec.fixedBindNumber,resource=str(d.resource),
                        firstMip=d.firstMip,mipCount=d.numMips)
                    found[kind+':'+str(dec.fixedBindNumber)+':'+dec.name]=row
            return found,ref
        def compute(event,name,select=None,allmips=False):
            ctl.SetFrameEvent(event,True);p=ctl.GetPipelineState()
            bound,ref=bindings(rd.ShaderStage.Compute)
            entry=dict(event=event,shaderSha256=sha(bytes(ref.rawBytes)),bindings=bound,constants=[],textures={})
            for i,b in enumerate(ref.constantBlocks):
                d=p.GetConstantBlock(rd.ShaderStage.Compute,i,0).descriptor
                data=bytes(ctl.GetBufferData(d.resource,d.byteOffset,b.byteSize))
                entry['constants'].append(dict(index=i,name=b.name,resource=str(d.resource),offset=d.byteOffset,
                    bytes=len(data),sha256=sha(data),hex=data.hex()))
            unique=set()
            for key,b in bound.items():
                if b['resource'] not in textures:continue
                if select is not None and b['name'] not in select:continue
                signature=(b['resource'],b['firstMip'])
                if signature in unique:continue
                unique.add(signature)
                t=textures[b['resource']]
                levels=range(min(t.mips,b['mipCount'])) if allmips else (b['firstMip'],)
                entry['textures'][key]=[texdata(t.resourceId,event,name+'-'+str(len(entry['textures']))+'-'+str(mip),
                    full=(b['name']=='previousColor'),mip=mip) for mip in levels]
            report['stages'][name]=entry;write(out/'result.json',report)
            return entry
        if native:
            traceEvent,filterEvent=8702,8811
        else:
            expected=request['playerTraceShader'];expectedFilter=request['filterShader']
            traced=[];filtered=[]
            for a in actions:
                if not a.flags&rd.ActionFlags.Dispatch:continue
                ctl.SetFrameEvent(a.eventId,True)
                ref=ctl.GetPipelineState().GetShaderReflection(rd.ShaderStage.Compute)
                if ref is None:continue
                digest=sha(bytes(ref.rawBytes))
                if digest==expected:traced.append(a.eventId)
                if digest==expectedFilter:filtered.append(a.eventId)
            assert len(traced)==1 and len(filtered)==1,(traced,filtered)
            traceEvent,filterEvent=traced[0],filtered[0]
        report['traceEvent']=traceEvent;report['filterEvent']=filterEvent
        progress(label+'-trace-inputs')
        trace=compute(traceEvent,'trace',None)
        progress(label+'-filter-inputs-output')
        filtered=compute(filterEvent,'filter',None,True)
        ctl.SetFrameEvent(filterEvent,True)
        p=ctl.GetPipelineState()
        # The filter result is a complete packed HDR texture on D3D11 and
        # a complete float RGBA storage image on the frozen Vulkan path.
        outputs=[v for v in filtered['bindings'].values() if v['kind']=='write' and v['resource'] in textures]
        if native:
            output=textures['ResourceId::15925'].resourceId
            extra={}
            for identity in (16552,15861):
                t=textures['ResourceId::'+str(identity)]
                usages=[u for u in ctl.GetUsage(t.resourceId) if traceEvent<=u.eventId<=filterEvent]
                extra[str(identity)]=[dict(event=u.eventId,usage=str(u.usage)) for u in usages]
            report['intermediateResourceUsages']=extra
            report['stages']['consumerConfidence']=texdata(textures['ResourceId::15777'].resourceId,8912,'consumer-confidence')
            consumerEvents=[8912]
        else:
            assert len(outputs)==1,outputs
            output=textures[outputs[0]['resource']].resourceId
            consumerEvents=[u.eventId for u in ctl.GetUsage(output) if u.eventId>filterEvent and
                'PS_' in str(u.usage)]
            assert consumerEvents,'No fragment consumers of actual filter output'
        report['filterOutputResource']=str(output)
        report['stages']['filterOutput']=texdata(output,filterEvent,'actual-filter-output')
        report['filterOutputUsage']=[dict(event=u.eventId,usage=str(u.usage)) for u in ctl.GetUsage(output)]
        # Find the actual HDR output from a reader of the filter result.
        ctl.SetFrameEvent(consumerEvents[0],True)
        targets=ctl.GetPipelineState().GetOutputTargets()
        assert targets and str(targets[0].resource) in textures
        target=targets[0].resource
        report['consumerHdrTarget']=str(target)
        report['pixelHistory']=[]
        ctl.SetFrameEvent(actions[-1].eventId,True)
        for x,y in points:
            progress(label+'-pixel-history-'+str(x)+'-'+str(y))
            history=ctl.PixelHistory(target,x,1439-y if native else y,rd.Subresource(),rd.CompType.Typeless)
            records=[]
            for h in history:
                if h.eventId<filterEvent:continue
                failed=any(getattr(h,k,False) for k in ('depthTestFailed','stencilTestFailed','backfaceCulled','shaderDiscarded'))
                records.append(dict(event=h.eventId,primitive=int(h.primitiveID),failed=failed,
                    before=list(h.preMod.col.floatValue),shaderOut=list(h.shaderOut.col.floatValue),after=list(h.postMod.col.floatValue)))
            report['pixelHistory'].append(dict(displayXY=[x,y],records=records))
            write(out/'result.json',report)
        actualEvents=sorted({h['event'] for row in report['pixelHistory'] for h in row['records'] if not h['failed']})
        for event in actualEvents:
            if event not in actionById or not actionById[event].flags&rd.ActionFlags.Drawcall:continue
            ctl.SetFrameEvent(event,True)
            b,ref=bindings(rd.ShaderStage.Pixel)
            uses=any(v['resource']==str(output) for v in b.values())
            if not uses:continue
            p=ctl.GetPipelineState()
            entry=dict(event=event,shaderSha256=sha(bytes(ref.rawBytes)),bindings=b,
                outputTargets=[str(t.resource) for t in p.GetOutputTargets()],constants=[])
            entry['samplers']=[]
            for access in ctl.GetDescriptorAccess():
                if access.stage==rd.ShaderStage.Pixel and access.type==rd.DescriptorType.Sampler:
                    sampler=ctl.GetSamplerDescriptors(access.descriptorStore,[rd.DescriptorRange(access)])[0]
                    entry['samplers'].append(dict(slot=access.index,minify=str(sampler.filter.minify),
                        magnify=str(sampler.filter.magnify),mip=str(sampler.filter.mip),
                        address=[str(sampler.addressU),str(sampler.addressV),str(sampler.addressW)]))
            for i,block in enumerate(ref.constantBlocks):
                d=p.GetConstantBlock(rd.ShaderStage.Pixel,i,0).descriptor
                if d.resource==rd.ResourceId.Null():continue
                data=bytes(ctl.GetBufferData(d.resource,d.byteOffset,block.byteSize))
                entry['constants'].append(dict(index=i,name=block.name,resource=str(d.resource),offset=d.byteOffset,
                    bytes=len(data),sha256=sha(data),hex=data.hex()))
            if not native:entry['pushConstants']=bytes(ctl.GetVulkanPipelineState().pushconsts).hex()
            entry['filterReadback']=texdata(output,event,'consumer-filter-'+str(event))
            entry['hdrAfter']=texdata(target,event,'consumer-hdr-'+str(event))
            report['consumers'].append(entry)
            write(out/'result.json',report)
        assert report['consumers'],'No witnessed consumer with the actual filter result bound'
        # Debug one witnessed invocation without replacing any shader or resource.
        report['consumerDebug']={'status':'unavailable','displayXY':points[0]}
        try:
            events={c['event'] for c in report['consumers']}
            h=next(h for h in report['pixelHistory'][0]['records'] if not h['failed'] and h['event'] in events)
            event=h['event'];x,y=points[0]
            ctl.SetFrameEvent(event,True)
            p=ctl.GetPipelineState();ref=p.GetShaderReflection(rd.ShaderStage.Pixel)
            assembly=ctl.DisassembleShader(p.GetGraphicsPipelineObject(),ref,'')
            (out/'consumer.asm').write_text(assembly,encoding='utf-8')
            b,_=bindings(rd.ShaderStage.Pixel)
            special={v['bind'] for v in b.values() if v['resource'] in (str(output),'ResourceId::15777')}
            selected=set()
            if native:
                for line in assembly.splitlines():
                    match=re.match(r'\s*(\d+):',line)
                    if match and any(re.search(r'\bt'+str(slot)+r'\b',line) for slot in special):
                        pc=int(match.group(1));selected.update(range(max(0,pc-2),pc+9))
            inputs=rd.DebugPixelInputs();inputs.primitive=h['primitive']
            trace=ctl.DebugPixel(x,1439-y if native else y,inputs)
            assert trace and trace.debugger,'No supported pixel debugger'
            state={};snapshots={};semantic=[];count=0;start=time.monotonic()
            wanted=('screenReflection','sceneReflectionResponse','sceneReflectionRadiance','ambientSpecular',
                'beautyColor','environmentResponse','radiance','blended')
            try:
                while True:
                    block=ctl.ContinueDebug(trace.debugger)
                    if not block:break
                    for step in block:
                        pc=int(step.nextInstruction)
                        for update in step.changes:
                            a=update.after
                            if not a.name:continue
                            values=[float(v) if math.isfinite(v) else None for v in list(a.value.f32v)[:4]]
                            state[a.name]=values
                            if any(w in a.name for w in wanted):
                                semantic.append(dict(pc=pc,name=a.name,values=values))
                        if native and pc in selected:snapshots[str(pc)]=dict(state)
                        count+=1
                    if count>150000 or time.monotonic()-start>90:
                        raise RuntimeError('Bounded read-only shader trace limit reached')
            finally:ctl.FreeTrace(trace)
            report['consumerDebug']=dict(status='traced',event=event,displayXY=[x,y],primitive=h['primitive'],
                shaderSha256=sha(bytes(ref.rawBytes)),instructions=count,semanticUpdates=semantic,
                nativeTextureWindows=snapshots,finalState=state if not native else {})
        except BaseException:
            report['consumerDebug']['error']=traceback.format_exc()
        write(out/'result.json',report)
        ctl.SetFrameEvent(actions[-1].eventId,True)
        report['lastEvent']=actions[-1].eventId
        report['finalCandidates']=[]
        for identity,t in textures.items():
            if (t.width,t.height)!=(2560,1440):continue
            fmt=t.format.Name()
            if not fmt.startswith(('R8G8B8A8','B8G8R8A8')):continue
            raw=bytes(ctl.GetTextureData(t.resourceId,rd.Subresource()))
            if len(raw)!=2560*1440*4:continue
            if native:raw=b''.join(raw[j*2560*4:(j+1)*2560*4] for j in range(1439,-1,-1))
            rgb=bytearray(2560*1440*3)
            rgb[0::3]=raw[2::4] if fmt.startswith('B8') else raw[0::4]
            rgb[1::3]=raw[1::4]
            rgb[2::3]=raw[0::4] if fmt.startswith('B8') else raw[2::4]
            report['finalCandidates'].append(dict(resource=identity,format=fmt,rgbSha256=sha(rgb),
                pixels=[list(rgb[(y*2560+x)*3:(y*2560+x)*3+3]) for x,y in points]))
        report['status']='qualified-same-frame-stage-readbacks'
    except BaseException:
        report['error']=traceback.format_exc()
        raise
    finally:
        write(out/'result.json',report)
        if ctl is not None:ctl.Shutdown()
        cap.Shutdown()
    return report

code=1
try:
    lease=read('D:/Projects/FYP-coordination/resources/current.json')
    assert lease['state']=='held' and Path(lease['output'])==O
    if os.environ.get('AZR_NATIVE_ONLY')=='1':
        progress('native-reference-only')
    elif (O/'capture/compressed-capture.json').exists():
        metadata=read(O/'capture/compressed-capture.json')
        progress('replaying-recovered-compressed-player')
        replay('player',O/'capture'/metadata['file'])
    else:
        progress('capturing-frozen-player')
        receipt=dict(format='RenderDocEvidence/1',operation='capture',source=request['captureRequest']['source'],
            status='failed',artifacts=[],tool_version=rd.GetVersionString(),started_unix=time.time())
        try:capture_target(TargetEnvironment(),request['captureRequest'],receipt)
        finally:write(O/'capture/receipt.json',receipt)
        assert receipt['status']=='captured'
        replay('player',receipt['capture']['path'])
    replay('native',request['nativeCapture'])
    progress('completed');code=0
except BaseException:
    write(O/'worker-error.json',dict(error=traceback.format_exc()))
os._exit(code)
