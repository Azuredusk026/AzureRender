"""Archive verified reference data and explicit current-capture failure scope."""
from pathlib import Path
from hashlib import file_digest,sha256
from zipfile import ZipFile,ZIP_DEFLATED
import json,sys,shutil,subprocess

O=Path(__file__).resolve().parent
W=O.parents[2]
E=W/'docs/acceptance/nr/evidence/2026-11-19/reflection-same-frame-consumer'
read=lambda p:json.loads(p.read_bytes())
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(p):
    with p.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import artifact_budget
budget=artifact_budget.check(W/'build',run=O,planned=20_000_000)
assert budget['allowed'],budget
E.mkdir(parents=True,exist_ok=True)
shutil.copyfile(O/'native/result.json',O/'native-result.json')
shutil.copyfile(O/'native/consumer.asm',O/'native-consumer.asm')
shutil.copyfile(O/'player/result.json',O/'player-incomplete-result.json')
shutil.copyfile(O/'capture/compressed-capture.json',O/'invalid-capture-identity.json')
members=['worker.py','batch.py','score_frames.py','score_native.py','archive.py','verify.py','measure_reference.py',
    'native-stage-values.npz','target-crops.npz','native-sampling.json','native-result.json','native-consumer.asm',
    'frame-identity.json','request.json','queue-receipts.json','player-incomplete-result.json',
    'invalid-capture-identity.json','startup-failure.log','batch.json']
write(O/'manifest.json',{n:sha(O/n) for n in members})
v=subprocess.run([sys.executable,str(O/'verify.py')],capture_output=True,text=True,check=True)
(O/'verification.log').write_text(v.stdout,encoding='utf-8')
members+=['manifest.json','verification.log']
with ZipFile(E/'validation.zip','w',ZIP_DEFLATED,compresslevel=9) as z:
    for name in members:z.write(O/name,name)
assert (E/'validation.zip').stat().st_size<8*2**20
with ZipFile(E/'validation.zip') as z:
    assert z.testzip() is None
    assert all(sha256(z.read(n)).hexdigest()==sha(O/n) for n in members)
    independent=O/'isolated-verification';independent.mkdir(exist_ok=True)
    z.extractall(independent)
retest=subprocess.run([sys.executable,str(independent/'verify.py')],capture_output=True,text=True,check=True)
(O/'isolated-verification.log').write_text(retest.stdout,encoding='utf-8')
req=read(O/'request.json');native=read(O/'native-sampling.json');frames=read(O/'frame-identity.json')
actual=Path(req['nativeCapture'])
q=dict(status='partial-same-frame-reference-qualified-player-stage-capture-blocked',accepted=False,
    baseCommit=req['baseCommit'],coordinateEvidenceCommit='4676be7',productionChanged=False,
    binaryAnd895ShadersRestoredExact=read(O/'batch.json')['productionUnchanged'],
    source=dict(playerSha256=req['playerSha256'],traceShader=req['playerTraceShader'],filterShader=req['filterShader'],
        projectSha256=req['projectSha256'],levelSha256=req['levelSha256'],
        nativeCapture=dict(path=str(actual),bytes=actual.stat().st_size,sha256=sha(actual))),
    native=native,frames=frames,queue=read(O/'queue-receipts.json'),
    budget=dict(capturePlannedBytes=1_850_000_000,stoppedCaptureBytes=2_063_455_666,
        managedPoolLimit=16*2**30,runLimit=2*2**30,archivePreflight=budget,
        invalidCaptureRemovedAfterVerifiedCompression=True),
    gates=dict(ssimMinimum=.95,luminanceRelativeMaximum=.1,newOverOneMaximum=0,frozenFourFrames='pixel-identical'),
    limitations=[
        'Player same-frame trace, bound filter inputs, four neighbouring outputs and consumer invocation were not acquired.',
        'The new Player file was stopped by managed-pool-limit before a valid RenderDoc capture completed.',
        'Native ideal interpolation has a measured red residual of 0.00048828125; exact sampler-coordinate or precision cause is open.',
        'Native final RGB candidates do not hash-match the archived reference PNG; resource 15929 matches the four retained anchors.',
        'Native final RGB candidates do not hash-match the archived reference PNG; resource 15929 matches the four retained display anchors.',
        'Native prior-color data is a same-position crop, not a new per-ray hit-address trace.',
        'Four-frame compatibility reuses unchanged-binary evidence; original cross-driver image differences remain open.'
    ],
    nextRequiredEvidence='A valid bounded Player capture of this exact source, followed by the existing readback worker; coordinate shared-pool headroom before retry.',
    verification=dict(local=v.stdout.strip(),isolated=retest.stdout.strip()),
    validation=dict(archiveSha256=sha(E/'validation.zip'),files={n:sha(O/n) for n in members}))
write(E/'qualification.json',q)
print(v.stdout.strip());print(retest.stdout.strip())
print('Archive bytes:',(E/'validation.zip').stat().st_size)
