from pathlib import Path
import hashlib,json,subprocess,sys,zipfile,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,digest
builds=json.loads((out/'production-builds.json').read_text());checks=json.loads((out/'production-tests.json').read_text())
assert len(builds)==2 and len(checks)==6 and all(r['exitCode']==0 for r in builds+checks)
nvidia=json.loads((out/'nvidia-calibration.json').read_text());intel=json.loads((out/'intel-calibration.json').read_text())
assert nvidia['exactPixels']==17017 and nvidia['maximumByteError']==0 and intel['withinOnePixels']==16842 and intel['maximumByteError']==33
assert all(r['validationErrors']==0 and r['zeroAllocator'] for r in [nvidia,intel])
prepared=json.loads((out/'calibration-preparation.json').read_text());assert all(digest(Path(p))==sha for p,sha in prepared['inputHashes'].items())
proof=[]
for config in ['release','debug']:
 path=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(path.read_text()));proof.append(dict(configuration=config,status='passed',sha256=digest(path)))
protectedPaths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protectedPaths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/screen-object-visibility';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.cpp','.comp','.vert','.frag','.spv','.spvasm','.bin','.json','.log','.xml'] and p.stat().st_size<2*2**20}
sources=['src/render/ScreenObjectVisibility.hpp','src/render/ScreenObjectVisibility.cpp','shaders/screen_object_visibility.vert','shaders/screen_object_visibility.frag','tests/ScreenObjectVisibilityTests.cpp','tests/ScreenObjectVisibilityGpuTests.cpp','CMakeLists.txt']
for path in sources:members['production/'+path]=root/path
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in sorted(members.items()):archive.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as archive:
 assert archive.testzip() is None
 for name,path in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='public-mechanism-verified-calibration-pending',sourceBase='093410c',builds=builds,scopedChecks=checks,nvidiaSourceRegion=nvidia,intelSourceRegion=intel,intelPreciseControl=json.loads((out/'intel-precise-result.json').read_text()),productionSources={p:digest(root/p) for p in sources},readOnlyInputs=prepared['inputHashes'],productionProvenance=proof,userDiffSha256=protected,sceneIntegrated=False,fullHairColorPassed=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',nextConditions=['Intel source region arithmetic contract','Current scene input production and integration','Full hair color and original frame budgets'],evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=name,bytes=p.stat().st_size,sha256=digest(p)) for name,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
documents=['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-screen-object-visibility.md','docs/acceptance/nr/screen-object-visibility.md'];links=0
for name in documents:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' in target or target.startswith('#'):continue
  target=target.split('#')[0]
  assert (p.parent/target).resolve().exists(),(name,target);links+=1
print(json.dumps(dict(status=report['status'],scopedChecks=6,nvidiaExact=17017,intelPending=175,evidenceBytes=report['evidenceBytes'],verifiedLinks=links,userDiffPreserved=True)))
