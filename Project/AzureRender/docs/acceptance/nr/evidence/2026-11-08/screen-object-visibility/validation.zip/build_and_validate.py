from pathlib import Path
import os,sys,subprocess,json,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'))
before=inputs(root);rows=[]
for config in ['Release','Debug']:
 build=root/('build/ninja-msvc-'+config.lower())
 command=[str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config',config,'--test-target','AzureScreenObjectVisibilityTests','--test-target','AzureScreenObjectVisibilityGpuTests']
 start=time.monotonic()
 with (out/(config.lower()+'-production-build.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 rows.append(dict(configuration=config,command=command,exitCode=r.returncode,seconds=time.monotonic()-start));(out/'production-builds.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
 assert r.returncode==0,config+' production build failed';assert inputs(root)==before
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';checks=[]
for config in ['Release','Debug']:
 build=root/('build/ninja-msvc-'+config.lower())
 for device,driver,pattern in [('contract',None,r'^AzureRender.ScreenObjectVisibility$'),('nvidia','*nv-vk64*',r'^AzureRender.ScreenObjectVisibilityGpu$'),('intel','*igvk64*',r'^AzureRender.ScreenObjectVisibilityGpu$')]:
  selected=env.copy();selected['PATH']=str(build)+';'+selected['PATH']
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LOADER_DRIVERS_SELECT']:selected.pop(key,None)
  if driver:selected['VK_LOADER_DRIVERS_SELECT']=driver
  label=config.lower()+'-'+device;command=[ctest,'--test-dir',str(build),'-R',pattern,'-V','--timeout','120','--output-junit',str(out/(label+'.xml'))]
  start=time.monotonic()
  with (out/(label+'-tests.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=selected,stdout=log,stderr=subprocess.STDOUT,timeout=150)
  checks.append(dict(configuration=config,device=device,command=command,exitCode=r.returncode,seconds=time.monotonic()-start));(out/'production-tests.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks[-1]),flush=True)
  assert r.returncode==0,label+' failed'
 assert inputs(root)==before
print('Production contracts and six scoped checks passed',flush=True)
