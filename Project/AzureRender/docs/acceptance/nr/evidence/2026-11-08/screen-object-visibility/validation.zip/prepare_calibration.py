from pathlib import Path
import json,os,sys,subprocess
import numpy as np
from PIL import Image
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
before=inputs(root)
data=root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f'
maskPath=root/'build/runs/20261023-105023-character-composite-contribution-diagnosis-acb8e5/native-hair-visible-mask.png'
visibility=root/'build/runs/20261027-002548-native-hair-layer-region-closure-61c105/native-screen-visibility.bin'
mask=np.asarray(Image.open(maskPath).convert('L'))[130:440,1140:1430]!=0;y,x=np.nonzero(mask);assert len(x)==17017
x=x+1140;y=1439-(y+130)
depth=np.fromfile(data/'native-t0.bin',dtype='<f4').reshape(1440,2560);ids=np.fromfile(data/'native-t5.bin',dtype='<u4').reshape(1440,2560);assert (ids[y,x]==258).all()
np.column_stack([x,y,depth[y,x],np.zeros(len(x))]).astype('<f4').tofile(out/'queries.bin')
np.fromfile(visibility,dtype='u1').reshape(1440,2560,2)[y,x,1].astype('<u4').tofile(out/'expected.bin')
c0=np.fromfile(data/'producer-cb0.bin',dtype='<f4').reshape(-1,4);c3=np.fromfile(data/'producer-cb3.bin',dtype='<f4').reshape(-1,4)
projection=np.zeros((4,4),dtype='<f4');projection[:,:3]=c3[128:132,:3];projection[3,3]=1
config=dict(extent=[2560,1440],atlasExtent=[4096,2048],depth=str(data/'native-t0.bin'),normals=str(data/'native-t6.bin'),atlas=str(data/'native-t2.bin'),queries=str(out/'queries.bin'),expected=str(out/'expected.bin'),clipToWorld=c0[24:28].flatten().tolist(),record=dict(projection=projection.flatten().tolist(),lightDirection=c3[203,:3].tolist(),lightBias=float(c3[188,0]),normalBias=float(c3[188,1]),atlasRect=c3[218].tolist(),filterRadiusUv=[float(4*c3[233,0])]*2))
(out/'calibration-inputs.json').write_text(json.dumps(config,indent=2))
sources=[data/'producer-cb0.bin',data/'producer-cb3.bin',data/'native-t0.bin',data/'native-t2.bin',data/'native-t5.bin',data/'native-t6.bin',maskPath,visibility]
env=os.environ.copy();env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'))
bat=[str(root/'tools/msvc_env.bat')]
compile=bat+['cl.exe','/nologo','/O2','/MD','/EHsc','/std:c++17','/utf-8','/DNOMINMAX','/DNDEBUG',f'/I{root/"src"}',f'/I{root/"tests"}',f'/I{root/"build/ninja-msvc-debug/vcpkg_installed/x64-windows/include"}','/ID:/Tools/VulkanSDK/1.4.350.0/Include','/c',str(out/'calibration.cpp'),f'/Fo{out/"calibration.obj"}']
link=bat+['link.exe',str(out/'calibration.obj'),f'/OUT:{out/"calibration.exe"}','/INCREMENTAL:NO',str(root/'build/ninja-msvc-release/AzureRenderCore.lib'),str(root/'build/ninja-msvc-release/AzureFoundation.lib'),'D:/Tools/VulkanSDK/1.4.350.0/Lib/vulkan-1.lib','kernel32.lib','user32.lib','advapi32.lib']
for name,command in [('calibration-compile',compile),('calibration-link',link)]:
 r=subprocess.run(command,cwd=out,env=env,capture_output=True,timeout=180);(out/(name+'.log')).write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr).decode(errors='replace')[-2500:]
assert inputs(root)==before
(out/'calibration-preparation.json').write_text(json.dumps(dict(sourceInputs=before,inputHashes={str(p):digest(p) for p in sources},compile=compile,link=link),indent=2));print('Prepared typed public calibration: 17017 pixels')
