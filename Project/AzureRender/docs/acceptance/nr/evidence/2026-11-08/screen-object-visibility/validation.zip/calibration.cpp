#define main syntheticVisibilityMain
#include "ScreenObjectVisibilityGpuTests.cpp"
#undef main
#include "resources/BinaryFile.hpp"
#include <nlohmann/json.hpp>
#include <fstream>
int main(int argc,char** argv)try{
    if(argc!=3)throw std::runtime_error("Expected typed calibration and shader directory");
    const auto config=nlohmann::json::parse(std::ifstream(argv[1]));
    const auto root=std::filesystem::path(argv[1]).parent_path();
    test::VulkanComputeFixture host(true);auto& backend=*host.backend;
    unsigned exact=0,within=0,maximum=0,pixels=0;std::vector<std::array<unsigned,4>> mismatches;
    {
        Inputs uploaded(host);const unsigned width=config["extent"][0],height=config["extent"][1];
        ScreenObjectVisibilityInputs inputs;inputs.extent={width,height};
        auto depth=readBinaryFile(config["depth"].get<std::string>()),normals=readBinaryFile(config["normals"].get<std::string>()),atlas=readBinaryFile(config["atlas"].get<std::string>());
        auto queries=readBinaryFile(config["queries"].get<std::string>()),expected=readBinaryFile(config["expected"].get<std::string>());
        if(queries.size()%16||expected.size()!=queries.size()/4)throw std::runtime_error("Invalid calibration points");
        pixels=static_cast<unsigned>(queries.size()/16);const auto* points=reinterpret_cast<const float*>(queries.data());const auto* reference=reinterpret_cast<const unsigned*>(expected.data());
        std::vector<std::uint8_t> ids(width*height);
        for(unsigned i=0;i<pixels;++i){const unsigned x=static_cast<unsigned>(points[i*4]),y=static_cast<unsigned>(points[i*4+1]);if(x>=width||y>=height)throw std::runtime_error("Calibration point out of bounds");ids[y*width+x]=1;}
        inputs.depth=uploaded.upload(width,height,VK_FORMAT_R32_SFLOAT,depth.data(),depth.size());
        inputs.normals=uploaded.upload(width,height,VK_FORMAT_A2B10G10R10_UNORM_PACK32,normals.data(),normals.size());
        inputs.objectIds=uploaded.upload(width,height,VK_FORMAT_R8_UINT,ids.data(),ids.size());
        inputs.atlas=uploaded.upload(config["atlasExtent"][0],config["atlasExtent"][1],VK_FORMAT_R16_UNORM,atlas.data(),atlas.size());
        ScreenObjectVisibilityView view;view.clipToWorld=config["clipToWorld"].get<std::array<float,16>>();view.pixelOffset={0,0};
        ScreenObjectVisibilityRecord record;record.worldToUnitShadow=config["record"]["projection"].get<std::array<float,16>>();
        record.lightDirection=config["record"]["lightDirection"].get<std::array<float,3>>();record.lightBias=config["record"]["lightBias"];record.normalBias=config["record"]["normalBias"];
        record.atlasRect=config["record"]["atlasRect"].get<std::array<float,4>>();record.filterRadiusUv=config["record"]["filterRadiusUv"].get<std::array<float,2>>();
        ScreenObjectVisibilityGpu owner(backend,{width,height},1,ScreenObjectVisibilityShaders::load(argv[2]));
        auto readback=host.allocator.createBuffer(width*height*2,VK_BUFFER_USAGE_TRANSFER_DST_BIT,true);
        try{
            host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer native){
                owner.record(commands,0,inputs,view,{record});auto output=owner.output(0);
                commands.imageBarrier({output.image,output.layout,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,1,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_SHADER_READ_BIT,VK_ACCESS_TRANSFER_READ_BIT});
                VkBufferImageCopy copy{};copy.imageSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};copy.imageExtent={width,height,1};vkCmdCopyImageToBuffer(native,output.image,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,readback.buffer,1,&copy);
                commands.imageBarrier({output.image,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,output.layout,1,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_ACCESS_TRANSFER_READ_BIT,VK_ACCESS_SHADER_READ_BIT});
                commands.bufferBarrier({readback.buffer,0,readback.size,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
            });
            host.allocator.invalidate(readback,0,readback.size);const auto* bytes=static_cast<const std::uint8_t*>(readback.mapped);
            std::vector<std::uint8_t> selected;selected.reserve(pixels*2);
            for(unsigned i=0;i<pixels;++i){const unsigned x=static_cast<unsigned>(points[i*4]),y=static_cast<unsigned>(points[i*4+1]);const auto offset=(y*width+x)*2;
                if(bytes[offset]!=255)throw std::runtime_error("Invalid scene visibility channel");const unsigned error=static_cast<unsigned>(std::abs(int(bytes[offset+1])-int(reference[i])));exact+=error==0;within+=error<=1;maximum=std::max(maximum,error);
                if(error&&mismatches.size()<16)mismatches.push_back({x,y,reference[i],bytes[offset+1]});selected.push_back(bytes[offset]);selected.push_back(bytes[offset+1]);}
            std::ofstream raw(root/(std::string(host.properties.vendorID==0x10de?"nvidia":"intel")+"-calibration-rg8.bin"),std::ios::binary);raw.write(reinterpret_cast<const char*>(selected.data()),selected.size());
        }catch(...){host.allocator.destroyBuffer(readback);throw;}
        host.allocator.destroyBuffer(readback);
    }
    const bool zero=!host.allocator.statistics().liveImages&&!host.allocator.statistics().liveBuffers;
    nlohmann::json result={{"device",host.properties.deviceName},{"pixels",pixels},{"exactPixels",exact},{"withinOnePixels",within},{"maximumByteError",maximum},{"mismatches",mismatches},{"validationErrors",host.errors.load()},{"zeroAllocator",zero}};
    const auto prefix=host.properties.vendorID==0x10de?"nvidia":"intel";std::ofstream(root/(std::string(prefix)+"-calibration.json"))<<result.dump(2);std::cout<<result.dump(2)<<std::endl;
    return within==pixels&&!host.errors.load()&&zero?0:1;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
