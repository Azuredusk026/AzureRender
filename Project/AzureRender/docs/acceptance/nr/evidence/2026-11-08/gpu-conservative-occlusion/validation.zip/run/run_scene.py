from pathlib import Path
import subprocess,os,json,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
capture=root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea/current_frame320.rdc';sha=digest(capture);before=inputs(root)
assert sha=='5cbfc0ecf9fa24a7a8d8949ed54c3fc3691b7a1a58075d68f63f257b34ca6942'
env=os.environ.copy();temporary=out/'tmp';temporary.mkdir(exist_ok=True);env.update(TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary),VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
with (out/'scene-fixture.log').open('wb') as log:r=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'read_scene.py')],cwd=out,env=env,startupinfo=si,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert digest(capture)==sha and inputs(root)==before
print((out/'scene-fixture.json').read_text(),flush=True);raise SystemExit(r.returncode)
