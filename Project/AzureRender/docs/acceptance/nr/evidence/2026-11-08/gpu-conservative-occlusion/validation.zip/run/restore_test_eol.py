from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;name='tests/DepthPrefillRecordingTests.cpp'
head=subprocess.check_output(['git','show','HEAD:Project/AzureRender/'+name]);data=head.replace(b'\n',b'\r\n');(root/name).write_bytes(data)
receipt=out/'scene-withdrawal.json';report=json.loads(receipt.read_text());report['restoredHashes'][name]=hashlib.sha256(data).hexdigest();receipt.write_text(json.dumps(report,indent=2))
subprocess.run(['git','diff','--exit-code','HEAD','--',name],check=True)
