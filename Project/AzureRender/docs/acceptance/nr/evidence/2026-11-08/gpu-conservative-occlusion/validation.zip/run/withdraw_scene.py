from pathlib import Path
import json,sys,subprocess,hashlib,zipfile
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from artifact_maintenance import real_path
assert root==Path('D:/Projects/FYP/Project/AzureRender') and subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='engine-dev'
assert subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()=='a6d16c1'
target=out/'candidate-source';target.mkdir(exist_ok=True);before=inputs(root)
files=['src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','src/render/SceneInstanceSnapshot.hpp','tests/DepthPrefillRecordingTests.cpp']
prior=json.loads((out/'baseline.json').read_text())['productionProvenance']['release']['source']
archive=root/'docs/acceptance/nr/evidence/2026-11-08/gpu-transparent-index-sort/validation.zip'
restored={};staged={}
with zipfile.ZipFile(archive) as z:
 for name in files:
  path=real_path(root/name);assert path.is_relative_to(root)
  saved=target/name;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(path.read_bytes());assert digest(saved)==digest(path)
  head=subprocess.check_output(['git','show','HEAD:Project/AzureRender/'+name])
  choices=[head,head.replace(b'\n',b'\r\n')]
  if name=='src/render/SceneInstanceSnapshot.hpp':
   inverse=path.read_bytes()
   for line in [b'    VkBuffer conservativeIndirect=VK_NULL_HANDLE;',b'    std::vector<std::size_t> conservativeOffsets;',b'    std::vector<std::uint32_t> conservativeSlots;']:
    assert line in inverse
    inverse=inverse.replace(line+b'\r\n',b'').replace(line+b'\n',b'')
   choices.append(inverse)
  if 'source/'+name in z.namelist():choices.append(z.read('source/'+name))
  expected=prior.get(name)
  data=next((v for v in choices if hashlib.sha256(v).hexdigest()==expected),None) if expected else head
  assert data is not None,('Cannot restore exact source bytes',name,expected)
  staged[name]=data
for name,data in staged.items():(root/name).write_bytes(data);restored[name]=digest(root/name)
include=real_path(root/'src/scenes/CharacterOcclusionPass.inc');assert include.is_relative_to(root/'src/scenes')
destination=(target/'src/scenes/CharacterOcclusionPass.inc').resolve();assert destination.is_relative_to(target.resolve()) and not destination.exists()
include.rename(destination)
subprocess.run(['git','diff','--exit-code','HEAD','--',*files],check=True,stdout=subprocess.DEVNULL)
(target/'candidate-inputs.json').write_text(json.dumps(before,indent=2))
(out/'scene-withdrawal.json').write_text(json.dumps(dict(status='withdrawn-no-net-frame-benefit',sourceBase='a6d16c1',restoredHashes=restored,exactSourceHashesRestored=True,prototypeIncludeSha256=digest(destination),candidateSourceInputSetSha256=hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest()),indent=2))
print('Scene candidate preserved in managed task; exact production source bytes restored',flush=True)
