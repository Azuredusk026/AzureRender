from pathlib import Path
import json,sys,subprocess,hashlib,zipfile,re,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
checks=[];proof=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,sha256=digest(p)))
 for label in ['nvidia','intel']:
  for case in ET.parse(out/(config+'-'+label+'.xml')).getroot().findall('testcase'):
   assert case.attrib['status']=='run' and case.find('failure') is None
   output=case.findtext('system-out') or ''
   if case.attrib['name'].endswith('Gpu'):assert 'commands=16432' in output and 'conflicts=0 validationErrors=0 liveBuffers=0 liveImages=0' in output
   checks.append(dict(configuration=config,label=label,name=case.attrib['name'],seconds=case.attrib['time'],output=output.strip()))
assert len(checks)==12
native=json.loads((out/'native-final.json').read_text());assert len(native['rows'])==2 and all(r['result']['conflicts']==0 and r['result']['culled']==268 for r in native['rows'])
withdrawal=json.loads((out/'scene-withdrawal.json').read_text());assert withdrawal['exactSourceHashesRestored']
assert all(digest(root/name)==sha for name,sha in withdrawal['restoredHashes'].items())
for name in ['results-v1.json','results.json']:
 image=json.loads((out/'image'/name).read_text());assert len(image['frames'])==4 and all(r['changedPixels']==0 and r['sha256']==r['referenceSha256'] for r in image['frames'])
v1=json.loads((out/'cost-results-v1.json').read_text());v2=json.loads((out/'cost-results-v2.json').read_text());assert v1['sourceAndProductsUnchanged'] and v2['sourceAndProductsUnchanged']
assert v2['gpuSavedMs']<=0
boundaries=json.loads((out/'module-boundaries.json').read_text());assert boundaries['status']=='passed' and not boundaries['violations']
prior=json.loads((out/'baseline.json').read_text());unchanged={}
for config,products in prior['products'].items():
 programs={name:sha for name,sha in products.items() if name.endswith('.spv') and Path(name).parent.name=='shaders'}
 assert len(programs)==669 and all(digest(Path(name))==sha for name,sha in programs.items());unchanged[config]=len(programs)
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
sources=['CMakeLists.txt','src/render/GpuConservativeOcclusion.hpp','src/render/GpuConservativeOcclusion.cpp','shaders/conservative_occlusion.comp','tests/GpuConservativeOcclusionTests.cpp','tests/GpuConservativeOcclusionGpuTests.cpp']
members={}
for p in out.rglob('*'):
 if not p.is_file() or 'tmp' in p.relative_to(out).parts:continue
 if p.suffix not in ['.py','.json','.log','.xml','.csv','.cpp','.hpp','.inc','.f32','.spv']:continue
 if p.stat().st_size>5*2**20:continue
 members['run/'+p.relative_to(out).as_posix()]=p
for name in sources:members['source/'+name]=root/name
for config in ['release','debug']:
 for name in ['conservative_occlusion.comp','depth_pyramid.comp']:members[f'program/{config}/{name}.spv']=root/f'build/ninja-msvc-{config}/shaders/{name}.spv'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/gpu-conservative-occlusion';evidence.mkdir(parents=True,exist_ok=True);package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='bounded-mechanism-ready-scene-candidate-withdrawn',sourceBase='a6d16c1',sourceHashes={name:digest(root/name) for name in sources},checks=checks,native=native,unchangedPrograms=unchanged,moduleBoundaries=boundaries,productionProvenance=proof,userDiffSha256=protected,sceneWithdrawal=withdrawal,candidateCosts=dict(mappedReads=v1,gpuSummary=v2),sceneIntegrated=False,candidateNativeImagesExact=True,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package))
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest=root/'docs/development/artifact-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'));data['milestones']=[m for m in data['milestones'] if m['path']!='runs/'+out.name];data['milestones'].insert(0,dict(path='runs/'+out.name,name='保守层级深度剔除机制',status='MechanismReadySceneCandidateWithdrawn',sourceBase='a6d16c1',evidence='docs/acceptance/nr/gpu-conservative-occlusion.md',checksPassed=12,sceneIntegrated=False,candidateNativeImagesExact=True,productionSceneRestored=True,formalPerformancePassed=False));manifest.write_text(json.dumps(data,indent=2,ensure_ascii=False).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md']:
 p=root/name;text=p.read_text(encoding='utf-8');prefix='docs/acceptance/nr/' if name=='README.md' else '../acceptance/nr/'
 marker='gpu-draw-stage-cost.md)';start=text.index(marker);end=text.index('\n',start)
 line='[保守剔除机制]('+prefix+'gpu-conservative-occlusion.md)通过双设备检查，场景候选的整帧收益未成立。\n'
 if line not in text:p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-conservative-depth-culling.md','docs/development/gpu-conservative-occlusion.md','docs/acceptance/nr/gpu-conservative-occlusion.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],checks=len(checks),evidenceBytes=package.stat().st_size,userDiffPreserved=True)))
