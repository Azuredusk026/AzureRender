from pathlib import Path
import json,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest
products={config:{str(p):digest(p) for p in [*(root/f'build/ninja-msvc-{config}').glob('*.exe'),*(root/f'build/ninja-msvc-{config}/shaders').glob('*.spv')]} for config in ['release','debug']}
prior={config:json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text()) for config in ['release','debug']}
(out/'baseline.json').write_text(json.dumps(dict(sourceBase='a6d16c1',products=products,productionProvenance=prior),indent=2))
