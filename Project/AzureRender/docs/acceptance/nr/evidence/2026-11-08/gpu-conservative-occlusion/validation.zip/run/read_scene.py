from pathlib import Path
import json,os,traceback,hashlib
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261108-113315-conservative-depth-culling-079a96';prior=root/'build/runs/20261108-111838-gpu-draw-stage-cost-4bb6b2'
cap=None;c=None;report=dict(status='starting')
try:
 bounds=json.loads((prior/'bounds.json').read_text());coverage=json.loads((prior/'depth-coverage.json').read_text());analysis=json.loads((prior/'analysis.json').read_text());statistics={r['event']:r for r in analysis['rows']}
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea/current_frame320.rdc'),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 c.SetFrameEvent(coverage['event'],True);target=c.GetPipelineState().GetDepthTarget().resource
 raw=bytes(c.GetTextureData(target,rd.Subresource()));assert hashlib.sha256(raw).hexdigest()==coverage['depthSha256']
 fixture=out/'native-fixture';fixture.mkdir(exist_ok=True);(fixture/'depth.f32').write_bytes(raw)
 rows=[]
 for row in bounds['rows']:
  box=row['ndcBounds']
  if box is None:continue
  rows.append(dict(event=row['event'],minimum=box[:3],maximum=box[3:],pixelInvocations=statistics[row['event']]['pixelInvocations'],baselineMs=row['baselineMs']))
 report=dict(status='read',width=coverage['width'],height=coverage['height'],viewport=coverage['viewport'],depthSha256=coverage['depthSha256'],captureSha256=analysis['captureSha256'],ordinaryMainBaselineMs=5.058095999999993,rows=rows)
 (fixture/'bounds.json').write_text(json.dumps(report,indent=2))
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'scene-fixture.json').write_text(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2));os._exit(0 if report['status']=='read' else 1)
