from pathlib import Path
import json,os,sys,subprocess
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
before=inputs(root);paths=[build/'AzureGpuConservativeOcclusionGpuTests.exe',build/'shaders/conservative_occlusion.comp.spv',build/'shaders/depth_pyramid.comp.spv',out/'native-fixture/depth.f32',out/'native-fixture/bounds.json'];hashes={str(p):digest(p) for p in paths}
env=os.environ.copy();env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'),TMPDIR=str(out/'tmp'));rows=[]
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
for label,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 env['VK_LOADER_DRIVERS_SELECT']=driver;command=[str(paths[0]),str(build/'shaders'),str(out/'native-fixture')]
 with (out/('native-final-'+label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 text=(out/('native-final-'+label+'.log')).read_text(errors='replace');assert r.returncode==0,text
 result=json.loads(next(line for line in text.splitlines() if line.startswith('{')));assert result['conflicts']==0
 rows.append(dict(device=label,command=command,exitCode=r.returncode,result=result));print(json.dumps(rows[-1]),flush=True)
assert inputs(root)==before and all(digest(Path(p))==sha for p,sha in hashes.items())
(out/'native-final.json').write_text(json.dumps(dict(rows=rows,sourceAndProductsUnchanged=True,hashes=hashes),indent=2))
