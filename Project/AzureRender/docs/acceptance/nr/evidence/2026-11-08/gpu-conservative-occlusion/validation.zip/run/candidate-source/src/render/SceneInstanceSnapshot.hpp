#pragma once

#include "scene/RenderBatching.hpp"
#include "render/RenderSettings.hpp"
#include "render/ObjectShadow.hpp"
#include "render/MaterialOriginInstances.hpp"
#include <array>
#include <cmath>
#include <memory>
#include <utility>
#include <vector>

namespace azurerender {
struct RecordingGizmoState {
    std::int32_t selectedPrimitive = -1;
    bool active = false;
    std::array<float, 3> translation{};
    std::array<float, 3> rotation{};
    std::array<float, 3> scale{1, 1, 1};
};
struct RecordingBufferSet {
    std::vector<VkBuffer> vertices;
    std::vector<VkBuffer> indices;
    std::vector<VkBuffer> vertexColors;
    VkBuffer transparentIndices = VK_NULL_HANDLE;
    VkBuffer conservativeIndirect=VK_NULL_HANDLE;
    std::vector<std::size_t> conservativeOffsets;
    std::vector<std::uint32_t> conservativeSlots;
    bool multiDrawIndirect = false;
    std::uint32_t maxDrawIndirectCount = 1;
    std::vector<std::vector<std::size_t>> transparentPrimitives;
    VkImage outlineMaskImage=VK_NULL_HANDLE;
    VkFramebuffer outlineMaskFramebuffer=VK_NULL_HANDLE;
    VkExtent2D outlineMaskExtent{};
    std::vector<std::uint32_t> outlineMaskTiles;
};

// Published only as const storage. Visible entries use indices rather than
// pointers into the mutable frame preparation arrays.
struct SceneInstanceSnapshot final {
    const RenderSettings settings;
    const VkBuffer indirectBuffer;
    const std::uint32_t frameIndex;
    const RecordingGizmoState gizmo;
    const RecordingBufferSet buffers;
    const std::vector<scene::SceneInstance> instances;
    const std::vector<std::uint32_t> visibleIndices;
    const std::vector<std::array<std::uint32_t, 3>> opaqueSpans;
    const std::vector<std::array<std::uint32_t, 3>> visibleSpans;
    const std::vector<std::array<std::uint32_t, 3>> shadowSpans;
    const std::vector<std::vector<std::array<std::uint32_t,3>>> shadowViewSpans;
    const std::vector<std::size_t> indirectOffsets;
    const std::vector<std::size_t> transparentOffsets;
    const std::vector<std::vector<float>> nodeWorldOpacities;
    const std::vector<ObjectShadowPage> objectShadowPages;
    const std::shared_ptr<const MaterialOriginInstances> materialOrigins;

    SceneInstanceSnapshot(std::vector<scene::SceneInstance> source,
        std::vector<std::uint32_t> visible,
        std::vector<std::array<std::uint32_t, 3>> opaque,
        std::vector<std::array<std::uint32_t, 3>> shadow,
        std::vector<std::size_t> indirect, std::vector<std::size_t> transparent,
        std::vector<std::array<std::uint32_t, 3>> visibleBatches = {},
        RenderSettings renderSettings = {}, VkBuffer indirectHandle = VK_NULL_HANDLE,
        std::uint32_t frame = 0, RecordingGizmoState gizmoState = {},
        RecordingBufferSet bufferSet = {},
        std::vector<std::vector<std::array<std::uint32_t,3>>> shadowViews = {},
        std::vector<std::vector<float>> nodeOpacities = {},
        std::vector<ObjectShadowPage> objectPages = {},
        std::shared_ptr<const MaterialOriginInstances> originInstances = {})
        : settings(std::move(renderSettings)), indirectBuffer(indirectHandle), frameIndex(frame),
          gizmo(std::move(gizmoState)), buffers(std::move(bufferSet)), instances(std::move(source)), visibleIndices(std::move(visible)),
          opaqueSpans(std::move(opaque)), visibleSpans(std::move(visibleBatches)), shadowSpans(std::move(shadow)),
          shadowViewSpans(std::move(shadowViews)),
          indirectOffsets(std::move(indirect)), transparentOffsets(std::move(transparent)),
          nodeWorldOpacities(std::move(nodeOpacities)),objectShadowPages(std::move(objectPages)),
          materialOrigins(std::move(originInstances)) {}

    void validateForRecording() const {
        if(materialOrigins&&materialOrigins->physicalCount()!=instances.size())
            throw std::logic_error("Snapshot material origins do not match physical instances");
        if(objectShadowPages.size()>kObjectShadowCapacity)throw std::logic_error("Snapshot object shadow capacity exceeded");
        std::array<bool,kObjectShadowCapacity> occupied{};
        for(const auto& page:objectShadowPages){
            if(page.instanceIndex>=instances.size()||page.page>=kObjectShadowCapacity||occupied[page.page])
                throw std::logic_error("Snapshot object shadow identity invalid");
            occupied[page.page]=true;
        }
        if (buffers.maxDrawIndirectCount == 0)
            throw std::logic_error("Snapshot indirect batch limit is zero");
        if (buffers.vertices.size() != buffers.indices.size())
            throw std::logic_error("Snapshot vertex/index resource counts differ");
        if(!buffers.vertexColors.empty()&&buffers.vertexColors.size()!=buffers.vertices.size())
            throw std::logic_error("Snapshot vertex color resource count differs");
        if(buffers.outlineMaskImage!=VK_NULL_HANDLE
            &&(buffers.outlineMaskFramebuffer==VK_NULL_HANDLE||!buffers.outlineMaskExtent.width
                ||!buffers.outlineMaskExtent.height||buffers.outlineMaskTiles.size()!=instances.size()))
            throw std::logic_error("Snapshot outline mask ownership incomplete");
        for (const auto index : visibleIndices)
            if (index >= instances.size()) throw std::out_of_range("Snapshot visible index");
        if (transparentOffsets.size() != instances.size())
            throw std::logic_error("Snapshot transparent offsets incomplete");
        if (!nodeWorldOpacities.empty() && nodeWorldOpacities.size() != instances.size())
            throw std::logic_error("Snapshot node opacity instances incomplete");
        for (const auto& nodes : nodeWorldOpacities)
            for (const float opacity : nodes)
                if (!std::isfinite(opacity) || opacity < 0 || opacity > 1)
                    throw std::logic_error("Snapshot node opacity outside [0,1]");
        if (indirectBuffer != VK_NULL_HANDLE && indirectOffsets.size() != instances.size())
            throw std::logic_error("Snapshot indirect offsets incomplete");
        for (std::size_t i = 0; i < instances.size(); ++i)
            if (instances[i].sourceIndex != i || instances[i].meshKey >= buffers.vertices.size())
                throw std::logic_error("Snapshot instance resource mapping invalid");
        const auto validateSpans = [this](const auto& spans) {
            for (const auto& span : spans) {
                if (span[1] > instances.size() || span[2] > instances.size() - span[1])
                    throw std::out_of_range("Snapshot draw span");
                for (std::size_t i = span[1]; i < static_cast<std::size_t>(span[1]) + span[2]; ++i)
                    if (instances[i].meshKey != span[0])
                        throw std::logic_error("Snapshot draw span mixes mesh resources");
            }
        };
        validateSpans(opaqueSpans);
        validateSpans(visibleSpans);
        validateSpans(shadowSpans);
        for(const auto& spans:shadowViewSpans) validateSpans(spans);
    }
};

}  // namespace azurerender
