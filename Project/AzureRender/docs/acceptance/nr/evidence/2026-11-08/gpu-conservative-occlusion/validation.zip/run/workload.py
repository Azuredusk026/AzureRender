from pathlib import Path
import json,os,sys,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from artifact_maintenance import guarded_run
build=root/'build/ninja-msvc-release';verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}
lock=json.loads((out.parent/'20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text());assert all(digest(Path(p))==sha for p,sha in lock.items())
project=out.parent/'20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
command=[str(build/'AzurePlayer.exe'),'--project',str(project),'--resource-root',str(build),'--width','2560','--height','1440','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','24','--smoke-frames','8','--runtime-report',str(out/'workload-runtime.json'),'--gpu-timing','--gpu-timing-output',str(out/'workload-state.json')]
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','AZURE_CPU_WORK_REPORT']:os.environ.pop(key,None)
execution=guarded_run(root/'build',out.name,command,300);(out/'workload-execution.json').write_text(json.dumps(execution,indent=2))
assert execution['status']=='exited' and execution['exitCode']==0
data=json.loads((out/'workload-state.json').read_text());found=[]
def walk(value):
 if isinstance(value,dict):
  if 'conservativeOcclusionPrepared' in value:found.append({k:v for k,v in value.items() if k.startswith('conservativeOcclusion')})
  for child in value.values():walk(child)
 elif isinstance(value,list):
  for child in value:walk(child)
walk(data);log=(out/'process.log').read_text(errors='replace');(out/'workload-process.log').write_text(log)
report=dict(status='observed',metadata=found,sourceInputsUnchanged=inputs(root)==before,productsUnchanged=all(digest(Path(p))==sha for p,sha in products.items()),projectInputsUnchanged=all(digest(Path(p))==sha for p,sha in lock.items()),zeroAllocator='Allocator after unload: buffers=0 images=0' in log,validationLogClean=not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-']),formalPerformancePassed=False)
(out/'workload.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
assert found and all(report[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','zeroAllocator','validationLogClean'])
