from pathlib import Path
import os,sys,subprocess,json,ctypes,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from artifact_maintenance import guarded_run,active_processes
from artifact_budget import check
inventory=json.loads((out/'current-cache-inventory.json').read_text());project=Path(inventory['project']);cache=Path(inventory['cacheRoot'])
assert cache.resolve().is_relative_to(root/'build/runs/20261103-234012-character-reference-stages-5abe6c') and inventory['uniqueLargeLegacyFiles']>0
assert check(root/'build',run=out,planned=128*2**20)['allowed']
busy=active_processes(root);assert not busy,busy
build=root/'build/ninja-msvc-release';verify(root,json.loads((build/'build-provenance.json').read_text()));source=inputs(root)
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}
lock=json.loads((root/'build/runs/20261107-171836-consolidated-preparation-images-374280/image/frozen-inputs.json').read_text())['project'];assert all(digest(Path(p))==sha for p,sha in lock.items())
paths=[Path(p) for p in subprocess.check_output(['rg','--files','--hidden','--no-ignore',str(cache)],text=True,encoding='utf-8').splitlines()];assert len(paths)==864
before={str(p):dict(bytes=p.stat().st_size,links=p.stat().st_nlink) for p in paths}
def free_bytes():
 value=ctypes.c_ulonglong();assert ctypes.windll.kernel32.GetDiskFreeSpaceExW('D:\\',ctypes.byref(value),None,None);return value.value
free_before=free_bytes();command=[str(out/'CompactAssetSnapshots.exe'),str(project),str(out/'compaction-records.json')]
baseline=dict(cacheBefore=before,freeBytesBefore=free_before,sourceInputs=source,products=products,busyProcesses=busy,command=command)
(out/'compaction-baseline.json').write_text(json.dumps(baseline,indent=2))
os.environ.update(TEMP=str(out/'test-tmp'),TMP=str(out/'test-tmp'));os.environ['PATH']=str(build)+';'+os.environ['PATH'];start=time.monotonic()
execution=guarded_run(root/'build',out.name,command,240);free_after=free_bytes()
assert execution['exitCode']==0,(out/'process.log').read_text(errors='replace')[-2000:]
records=json.loads((out/'compaction-records.json').read_text());assert len(records['records'])==864 and all(r['roundTripExact'] for r in records['records'])
after_paths=[Path(p) for p in subprocess.check_output(['rg','--files','--hidden','--no-ignore',str(cache)],text=True,encoding='utf-8').splitlines()];assert set(map(str,after_paths))==set(before)
after={str(p):dict(bytes=p.stat().st_size,links=p.stat().st_nlink) for p in after_paths}
unchanged=inputs(root)==source and all(digest(Path(p))==sha for p,sha in products.items()) and all(digest(Path(p))==sha for p,sha in lock.items())
formats={}
for row in records['records']:formats[row['format']]=formats.get(row['format'],0)+1
report=dict(status='compacted-and-verified',execution=execution,seconds=time.monotonic()-start,cacheBeforeBytes=sum(x['bytes'] for x in before.values()),cacheAfterBytes=sum(x['bytes'] for x in after.values()),actualVolumeFreedBytes=free_after-free_before,freeBytesBefore=free_before,freeBytesAfter=free_after,formats=formats,recordsVerified=864,projectInputsVerified=len(lock),productionAndProjectInputsUnchanged=unchanged,privateExecutableSha256=digest(out/'CompactAssetSnapshots.exe'),projectDataVolume='D:',externalProjectStorageUsed=False)
(out/'compaction-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True);assert unchanged
