from pathlib import Path
import os,sys,subprocess,json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;rows=[]
temp=out/'test-tmp';temp.mkdir(exist_ok=True)
for config in ['release','debug']:
 env=os.environ.copy();env.update(TEMP=str(temp),TMP=str(temp));env['PATH']=str(root/('build/ninja-msvc-'+config))+';'+env['PATH']
 command=['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe','--test-dir',str(root/('build/ninja-msvc-'+config)),'-R',r'^AzureAssets.GenerationManifest$','--output-on-failure','--timeout','120','--output-junit',str(out/(config+'-generation-tests.xml'))]
 with (out/(config+'-generation-tests.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
 rows.append(dict(configuration=config,command=command,exitCode=r.returncode));(out/'generation-tests.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
 assert r.returncode==0,(out/(config+'-generation-tests.log')).read_text(errors='replace')[-2000:]
