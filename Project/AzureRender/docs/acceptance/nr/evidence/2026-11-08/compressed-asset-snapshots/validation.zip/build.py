from pathlib import Path
import os,sys,subprocess,json,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'),CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',*sys.argv[1:]],env=env).returncode)
config='Debug' if '--debug' in sys.argv else 'Release';red='--red' in sys.argv
if red:
 command=['cmake','--build',str(root/'build/ninja-msvc-release'),'--target','AzureAssetSourceCacheTests','--parallel','3']
else:
 command=[sys.executable,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(root/('build/ninja-msvc-'+config.lower())),'--config',config]
 for target in ['AzureAssetSourceCacheTests','AzureAssetLevelTests','AzureGenerationManifestTests','AzureProjectStartupTests']:command+=['--test-target',target]
label='red' if red else config.lower();start=time.monotonic()
with (out/(label+'-build.log')).open('wb') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=600)
(out/(label+'-build.json')).write_text(json.dumps(dict(command=command,exitCode=r.returncode,seconds=time.monotonic()-start),indent=2));assert r.returncode==0,(out/(label+'-build.log')).read_text(errors='replace')[-4500:]
if red:
 command=[str(root/'build/ninja-msvc-release/AzureAssetSourceCacheTests.exe')]
 with (out/'red-test.log').open('wb') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=60)
 (out/'red-test.json').write_text(json.dumps(dict(command=command,exitCode=r.returncode),indent=2));print((out/'red-test.log').read_text(),flush=True);assert r.returncode!=0
else:print(config+' runtime and scoped tests built',flush=True)
