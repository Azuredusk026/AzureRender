from pathlib import Path
import os,sys,subprocess,json,re,ctypes
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',TEMP=str(out/'test-tmp'),TMP=str(out/'test-tmp'),VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],env=env).returncode)
def split(command):
 count=ctypes.c_int();f=ctypes.windll.shell32.CommandLineToArgvW;f.restype=ctypes.POINTER(ctypes.c_wchar_p);f.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
 result=f(command,ctypes.byref(count));values=[result[i] for i in range(count.value)];ctypes.windll.kernel32.LocalFree(result);return values
ninja=re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.+)$',(build/'CMakeCache.txt').read_text(),re.M).group(1)
commands=subprocess.check_output([ninja,'-C',str(build),'-t','commands','AzureAssetSourceCacheTests.exe'],text=True,encoding='utf-8').splitlines();command=split(next(c for c in commands if c.rstrip().endswith('AssetSourceCacheTests.cpp')))
command=[v for v in command if v!='/showIncludes'];command[-1]=str(out/'compact.cpp')
for i,v in enumerate(command):
 if v.startswith('/Fo'):command[i]='/Fo'+str(out/'compact.obj')
 elif v.startswith('/Fd'):command[i]='/Fd'+str(out/'compact.pdb')
with (out/'compactor-compile.log').open('wb') as log:r=subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0,(out/'compactor-compile.log').read_text(errors='replace')[-4000:]
rule=re.search(r'^build AzureAssetSourceCacheTests\.exe: (\S+)',(build/'build.ninja').read_text(),re.M).group(1);expanded=json.loads(subprocess.check_output([ninja,'-C',str(build),'-t','compdb','-x',rule],text=True,encoding='utf-8'));assert len(expanded)==1
link=split(expanded[0]['command'].split(' -- ',1)[1].split(' && ',1)[0])
for i,v in enumerate(link):
 if v.lower().endswith('assetsourcecachetests.cpp.obj'):link[i]=str(out/'compact.obj')
 elif v.lower().startswith('/out:'):link[i]='/out:'+str(out/'CompactAssetSnapshots.exe')
 elif v.lower().startswith('/implib:'):link[i]='/implib:'+str(out/'compact.lib')
 elif v.lower().startswith('/pdb:'):link[i]='/pdb:'+str(out/'compact-link.pdb')
link=[v for v in link if not v.lower().startswith(('/debug','/incremental'))];link[1:1]=['/DEBUG:NONE','/INCREMENTAL:NO']
with (out/'compactor-link.log').open('wb') as log:r=subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0,(out/'compactor-link.log').read_text(errors='replace')[-4000:]
(out/'compactor-build.json').write_text(json.dumps(dict(compile=command,link=link),indent=2));print('Private compactor built against the verified public asset database',flush=True)
