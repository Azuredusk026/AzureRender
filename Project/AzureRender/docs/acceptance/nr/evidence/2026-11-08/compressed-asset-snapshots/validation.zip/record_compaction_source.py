from pathlib import Path
import json,hashlib,shutil
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;baseline=json.loads((out/'compaction-baseline.json').read_text())['sourceInputs']
cpp=(root/'src/runtime/AssetSourceCache.cpp').read_text();marker=cpp.index('namespace {\ntemplate<class Validate>');start=cpp.index('    if(envelope.size()<24',marker);end=cpp.index('\n}\n}\nstd::optional<std::string> decodeAssetSourceCache',start)
body=cpp[start:end].replace('const auto source=envelope.substr(24);if(!validate(source))return std::nullopt;return retain?std::string(source):std::string{};','const auto source=envelope.substr(24);if(hash(source)!=sourceHash)return std::nullopt;return std::string(source);').replace('if(method==0){if(payload.size()!=plainBytes||!validate(payload))return std::nullopt;return retain?std::string(payload):std::string{};}','if(method==0){if(payload.size()!=plainBytes||hash(payload)!=sourceHash)return std::nullopt;return std::string(payload);}')
body=body.replace('||!validate(source))','||hash(source)!=sourceHash)').replace('return retain?std::move(source):std::string{};','return source;')
reconstructed=cpp[:marker]+'std::optional<std::string> decodeAssetSourceCache(std::string_view envelope,std::uint64_t fingerprint,std::uint64_t sourceHash){\n'+body+'\n}\n}\n'
header=(root/'src/runtime/AssetSourceCache.hpp').read_text().split('// Warm publication')[0]+'}\n'
database=(root/'src/runtime/AssetDatabase.cpp').read_text().replace('        if(!legacyLarge&&assetSourceCacheMatches(prior,record.fingerprint,source))return;','        if(!legacyLarge){const auto decoded=decodeAssetSourceCache(prior,record.fingerprint,record.contentHash);\n            if(decoded&&*decoded==source)return;}')
for name,text in [('src/runtime/AssetSourceCache.cpp',reconstructed),('src/runtime/AssetSourceCache.hpp',header),('src/runtime/AssetDatabase.cpp',database)]:
 raw=text.encode();assert hashlib.sha256(raw).hexdigest()==baseline[name],name
 p=out/'compaction-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
folder=out/'pre-warm-optimization';folder.mkdir(exist_ok=True)
for name in ['tests.json','corpus-results.json','corpus-execution.json','release-tests.log','debug-tests.log','release-tests.xml','debug-tests.xml']:shutil.copyfile(out/name,folder/name)
path=out/'verify.py';text=path.read_text().replace(r'^AzureEngine\.(AssetSourceCache|AssetLevel|GenerationManifest|ProjectStartup)$',r'^(AzureEngine\.(AssetSourceCache|AssetLevel|ProjectStartup)|AzureAssets\.GenerationManifest)$');path.write_text(text)
print('Compaction source reconstructed and matched to all three recorded source hashes',flush=True)
