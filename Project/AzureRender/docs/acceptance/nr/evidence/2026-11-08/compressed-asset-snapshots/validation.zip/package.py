from pathlib import Path
import json,sys,hashlib,subprocess,zipfile,re,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
tests=json.loads((out/'tests.json').read_text());assert len(tests)==2 and all(r['exitCode']==0 for r in tests)
proof=[]
for config in ['release','debug']:
 cases=list(ET.parse(out/(config+'-tests.xml')).iter('testcase'));assert len(cases)==4 and all(not any(c.tag in ['failure','error','skipped'] for c in case) for case in cases)
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,provenanceSha256=digest(p)))
compaction=json.loads((out/'compaction-results.json').read_text());assert compaction['recordsVerified']==864 and compaction['productionAndProjectInputsUnchanged'] and compaction['actualVolumeFreedBytes']==677437440
records=json.loads((out/'compaction-records.json').read_text())['records'];assert all(r['roundTripExact'] for r in records)
baseline=json.loads((out/'compaction-baseline.json').read_text())
for name in ['src/runtime/AssetDatabase.cpp','src/runtime/AssetSourceCache.cpp','src/runtime/AssetSourceCache.hpp']:assert digest(out/'compaction-source'/name)==baseline['sourceInputs'][name]
sourceFiles=['src/runtime/AssetSourceCache.hpp','src/runtime/AssetSourceCache.cpp','src/runtime/AssetDatabase.cpp','tests/AssetSourceCacheTests.cpp','CMakeLists.txt','vcpkg.json']
corpus=json.loads((out/'corpus-results.json').read_text());assert all(r['roundTripExact'] for r in corpus)
before=json.loads((out/'pre-warm-optimization/corpus-results.json').read_text());assert [r['encodedBytes'] for r in before]==[r['encodedBytes'] for r in corpus]
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
assert digest(out/'AssetDatabase-original.cpp')==json.loads((out/'baseline.json').read_text())['assetDatabaseRawSha256']
croot=Path('C:/Users/admin/.codex/archives/AzureRender');cfiles=[p for p in croot.rglob('*') if p.is_file()] if croot.exists() else [];assert not cfiles
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/compressed-asset-snapshots';evidence.mkdir(parents=True,exist_ok=True)
members={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and p.suffix in ['.py','.cpp','.hpp','.json','.log','.xml'] and 'test-tmp' not in p.parts}
for name in sourceFiles:members['final-source/'+name]=root/name
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='compressed-asset-snapshots-deployed',sourceBase='ae7bc80',checksPassed=8,productionProvenance=proof,corpus=json.loads((out/'corpus-execution.json').read_text()),corpusResults=corpus,currentProjectCompaction=compaction,compactionEncodingStableInFinalSource=True,assetDatabasePreexistingSemanticDiffBytes=0,otherUserDiffSha256=protected,cProjectArchiveFiles=0,cProjectArchiveBytes=0,projectDataVolume='D:',candidateAdopted=True,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=n,bytes=p.stat().st_size,sha256=digest(p)) for n,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest=root/'docs/development/artifact-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'));data['milestones'].insert(0,dict(path='runs/'+out.name,name='资产源文件快照压缩',status='CompressedAssetSnapshotsDeployed',sourceBase='ae7bc80',evidence='docs/acceptance/nr/compressed-asset-snapshots.md',checksPassed=8,actualVolumeFreedBytes=compaction['actualVolumeFreedBytes'],snapshotsVerified=864,externalProjectStorageUsed=False,formalPerformancePassed=False));manifest.write_text(json.dumps(data,indent=2,ensure_ascii=False).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md']:
 p=root/name;text=p.read_text(encoding='utf-8');needle='[准备批次评估]';start=text.index(needle);end=text.index('\n',start)
 line='[资产快照压缩]('+('docs/acceptance/nr/' if name=='README.md' else '../acceptance/nr/')+'compressed-asset-snapshots.md)已部署，当前 864 份快照逐字节通过，实际释放约 646 MiB。\n'
 p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-compressed-asset-snapshots.md','docs/acceptance/nr/compressed-asset-snapshots.md','docs/development/asset-source-cache.md','docs/development/artifact-retention.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],checksPassed=8,actualVolumeFreedBytes=compaction['actualVolumeFreedBytes'],evidenceBytes=package.stat().st_size,cProjectArchiveBytes=0,userChangesPreserved=True)))
