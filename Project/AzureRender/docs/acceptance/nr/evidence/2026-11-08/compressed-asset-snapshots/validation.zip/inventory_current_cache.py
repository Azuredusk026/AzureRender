from pathlib import Path
import json,subprocess,os,struct
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
frozen=json.loads((root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/command.json').read_text());project=Path(frozen[frozen.index('--project')+1]);cache=project.parent/'.azure/cache'
paths=subprocess.check_output(['rg','--files','--hidden','--no-ignore',str(cache)],text=True,encoding='utf-8').splitlines()
items=[];counts={};total=0
for name in paths:
 p=Path(name);s=p.stat();total+=s.st_size
 if p.suffix!='.azcache':continue
 with p.open('rb') as f:header=f.read(40)
 kind=header[:8].decode('ascii',errors='replace');counts[kind]=counts.get(kind,0)+1
 if kind=='AZCACHE1' and len(header)>=24:
  plain=struct.unpack_from('<Q',header,16)[0]
  if s.st_nlink==1 and 65536<=plain<=256*2**20 and s.st_size==plain+24:items.append(dict(path=str(p),bytes=s.st_size,links=s.st_nlink))
report=dict(project=str(project),cacheRoot=str(cache),files=len(paths),logicalBytes=total,formats=counts,uniqueLargeLegacyFiles=len(items),uniqueLargeLegacyBytes=sum(x['bytes'] for x in items),eligible=items)
(out/'current-cache-inventory.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='eligible'}),flush=True)
