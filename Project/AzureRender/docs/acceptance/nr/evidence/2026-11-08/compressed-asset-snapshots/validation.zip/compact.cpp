#include "runtime/AssetDatabase.hpp"
#include <fstream>
#include <iostream>
#include <chrono>
using namespace azurerender;
int main(int argc,char** argv)try{
    if(argc!=3)throw std::runtime_error("Expected one project path and a result path");
    const auto started=std::chrono::steady_clock::now();AssetDatabase database(Project::load(std::filesystem::u8path(argv[1])));database.refresh();
    nlohmann::json rows=nlohmann::json::array();
    for(const auto& entry:database.records()){
        const auto& record=entry.second;const auto decoded=database.readSource(record.id);
        std::ifstream source(record.path,std::ios::binary|std::ios::ate);if(!source)throw std::runtime_error("Cannot read source");
        const auto size=source.tellg();if(size<0||std::uint64_t(size)!=decoded.size())throw std::runtime_error("Source length differs");
        std::string original(decoded.size(),'\0');source.seekg(0);source.read(original.data(),original.size());if(!source||decoded!=original)throw std::runtime_error("Snapshot source bytes differ");
        const auto cache=database.cacheFile(record.id);std::ifstream file(cache,std::ios::binary);std::string header(8,'\0');file.read(header.data(),header.size());if(!file)throw std::runtime_error("Cannot read cache header");
        rows.push_back({{"id",record.id},{"source",record.path.u8string()},{"sourceBytes",decoded.size()},{"cache",cache.u8string()},{"cacheBytes",std::filesystem::file_size(cache)},{"format",header},{"fingerprint",record.fingerprint},{"contentHash",record.contentHash},{"roundTripExact",true}});
    }
    nlohmann::json result={{"status","compacted"},{"records",rows},{"seconds",std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count()}};
    std::ofstream(std::filesystem::u8path(argv[2]))<<result.dump(2)<<'\n';std::cout<<"Compacted and verified "<<rows.size()<<" asset snapshots\n";return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
