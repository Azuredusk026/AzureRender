from pathlib import Path
import os,sys,subprocess,json,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
before=inputs(root);temp=out/'test-tmp';temp.mkdir(exist_ok=True)
env=os.environ.copy();env.update(TEMP=str(temp),TMP=str(temp))
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';rows=[]
for config in ['release','debug']:
 build=root/('build/ninja-msvc-'+config);verify(root,json.loads((build/'build-provenance.json').read_text()))
 env['PATH']=str(build)+';'+os.environ['PATH']
 command=[ctest,'--test-dir',str(build),'-R',r'^(AzureEngine\.(AssetSourceCache|AssetLevel|ProjectStartup)|AzureAssets\.GenerationManifest)$','--output-on-failure','--timeout','120','--output-junit',str(out/(config+'-tests.xml'))];start=time.monotonic()
 with (out/(config+'-tests.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 row=dict(configuration=config,command=command,exitCode=r.returncode,seconds=time.monotonic()-start);rows.append(row);(out/'tests.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
 assert r.returncode==0,(out/(config+'-tests.log')).read_text(errors='replace')[-4000:]
lock=json.loads((root/'build/runs/20261107-171836-consolidated-preparation-images-374280/image/frozen-inputs.json').read_text())['project']
corpus=[]
for extension in ['.glb','.dds','.png']:
 selected=max((Path(p) for p in lock if Path(p).suffix==extension and 65536<=Path(p).stat().st_size<=256*2**20),key=lambda p:p.stat().st_size)
 assert digest(selected)==lock[str(selected)];corpus.append(selected)
command=[str(root/'build/ninja-msvc-release/AzureAssetSourceCacheTests.exe'),'--corpus',*[str(p) for p in corpus]];start=time.monotonic()
with (out/'corpus-results.json').open('wb') as stdout,(out/'corpus-errors.log').open('wb') as stderr:r=subprocess.run(command,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=120)
assert r.returncode==0,(out/'corpus-errors.log').read_text(errors='replace')
results=json.loads((out/'corpus-results.json').read_text());unchanged=all(digest(p)==lock[str(p)] for p in corpus)
report=dict(command=command,exitCode=r.returncode,seconds=time.monotonic()-start,sourceInputsUnchanged=inputs(root)==before,corpusInputsUnchanged=unchanged,corpusHashes={str(p):lock[str(p)] for p in corpus},sourceBytes=sum(row['sourceBytes'] for row in results),legacyBytes=sum(row['legacyBytes'] for row in results),encodedBytes=sum(row['encodedBytes'] for row in results))
report['diskReductionPercent']=100*(1-report['encodedBytes']/report['legacyBytes'])
(out/'corpus-execution.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(**report,results=results)),flush=True)
assert report['sourceInputsUnchanged'] and unchanged and all(row['roundTripExact'] for row in results)
