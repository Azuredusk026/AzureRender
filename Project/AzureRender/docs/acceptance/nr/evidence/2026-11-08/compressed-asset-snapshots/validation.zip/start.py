from pathlib import Path
import subprocess,json,sys,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest
path='src/runtime/AssetDatabase.cpp';assert subprocess.check_output(['git','diff','--binary','--',path],stderr=subprocess.DEVNULL)==b''
(out/'AssetDatabase-original.cpp').write_bytes((root/path).read_bytes())
prior=root/'build/ninja-msvc-release/build-provenance.json';(out/'baseline-provenance.json').write_bytes(prior.read_bytes())
(out/'baseline.json').write_text(json.dumps(dict(sourceBase='ae7bc80',assetDatabaseRawSha256=digest(root/path),assetDatabasePreexistingSemanticDiffBytes=0,projectDataVolume='D:'),indent=2))
state=root/'build/maintenance/storage-work-priority.json';state.write_text(json.dumps(dict(activeTask='compressed-asset-snapshots',status='implementing',performanceTask=str(out.relative_to(root)),storageCommit='254cd03',projectDataVolume='D:',maintenanceUnit='day'),indent=2)+'\n')
