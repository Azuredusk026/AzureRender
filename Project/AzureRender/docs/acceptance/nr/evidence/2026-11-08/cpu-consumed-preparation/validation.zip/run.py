from pathlib import Path
import json,os,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,inputs,digest
from artifact_maintenance import guarded_run
verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
assert before==json.loads((out/'source-inputs.json').read_text())
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}
lock=json.loads((root/'build/runs/20261107-171836-consolidated-preparation-images-374280/image/frozen-inputs.json').read_text())['project'];assert all(digest(Path(p))==sha for p,sha in lock.items())
frozen=json.loads((root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/command.json').read_text());project=frozen[frozen.index('--project')+1]
command=[str(out/'CpuStagesPlayer.exe'),'--project',project,'--resource-root',str(build),'--width','2560','--height','1440','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--smoke-frames','8','--gpu-timing','--gpu-timing-output',str(out/'timing.json'),'--runtime-report',str(out/'runtime.json')]
os.environ.update(TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'),AZURE_CPU_WORK_REPORT=str(out/'cpu-work.json'),VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
(out/'command.json').write_text(json.dumps(dict(command=command,scope='Eight-frame CPU consumed-work diagnosis. No formal performance qualification or image capture.',exeSha256=digest(out/'CpuStagesPlayer.exe')),indent=2))
result=guarded_run(root/'build',out.name,command,240)
unchanged=inputs(root)==before and all(digest(Path(p))==sha for p,sha in products.items()) and all(digest(Path(p))==sha for p,sha in lock.items())
log=(out/'process.log').read_text(errors='replace');result.update(productionAndProjectInputsUnchanged=unchanged,validationLogClean=not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-']),zeroAllocator='Allocator after unload: buffers=0 images=0' in log,formalPerformancePassed=False)
(out/'execution.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True);assert result['exitCode']==0 and unchanged and result['validationLogClean'] and result['zeroAllocator']
print((out/'cpu-work.json').read_text(),flush=True)
