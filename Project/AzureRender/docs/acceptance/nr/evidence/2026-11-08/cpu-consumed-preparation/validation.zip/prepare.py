from pathlib import Path
import json,sys,subprocess,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
source=inputs(root);s=(root/'src/scenes/CharacterSceneRenderer.cpp').read_text()
prefix=r'''
#include <array>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <filesystem>
#include <nlohmann/json.hpp>
namespace azCpuOps {
enum Stage {Update,Instances,Poses,Bounds,Margin,MaterialFrame,InstanceUpload,Transparent,TransparentVisible,TransparentHidden,Motion,MotionPoseFill,MotionHistory,MotionBindings,MotionDraws,Count};
const std::array<const char*,Count> names{"update","instances","poses","bounds","margin","materialFrame","instanceUpload","transparent","transparentVisible","transparentHidden","motion","motionPoseFill","motionHistory","motionBindings","motionDraws"};
struct Counter{unsigned long long ns=0,calls=0;};std::array<Counter,Count> counters;
unsigned frames=0,selected=0;bool sampling=false;std::array<unsigned long long,2> vertices{},indices{},instances{};
void beginFrame(){++frames;sampling=frames>=3&&frames<=8;if(sampling)++selected;}
struct Scope{Stage stage;bool active;std::chrono::steady_clock::time_point start;
explicit Scope(Stage s):stage(s),active(sampling){if(active)start=std::chrono::steady_clock::now();}
void stop(){if(!active)return;auto& c=counters[stage];c.ns+=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();++c.calls;active=false;}
~Scope(){stop();}};
template<class F>auto measure(Stage stage,F&& f)->decltype(f()){Scope scope(stage);return f();}
void dump(){const auto* path=std::getenv("AZURE_CPU_WORK_REPORT");if(!path||!selected)return;
nlohmann::json r={{"frames",frames},{"selectedFrames",selected},{"verticesByVisibleHidden",vertices},{"indicesByVisibleHidden",indices},{"transparentInstancesByVisibleHidden",instances}};
for(unsigned i=0;i<Count;++i){auto c=counters[i];r["stages"][names[i]]={{"calls",c.calls},{"totalMs",double(c.ns)/1e6},{"perFrameMs",double(c.ns)/1e6/selected}};}
std::ofstream(std::filesystem::u8path(path))<<r.dump(2)<<'\n';}
}
'''
def body_range(text,signature):
 start=text.index(signature);opening=text.index('{',start);depth=1;i=opening+1
 while depth:
  if text[i]=='{':depth+=1
  elif text[i]=='}':depth-=1
  i+=1
 return opening,i-1
def entry(text,signature,code):
 opening,_=body_range(text,signature);return text[:opening+1]+'\n'+code+text[opening+1:]
s=entry(s,'void CharacterSceneRenderer::updateFrame(','azCpuOps::beginFrame();azCpuOps::Scope whole(azCpuOps::Update);')
for name,stage in [('rebuildSceneInstances','Instances'),('prepareInstancePoses','Poses'),('prepareTransparentIndices','Transparent')]:s=entry(s,'void CharacterSceneRenderer::'+name+'(','azCpuOps::Scope stageScope(azCpuOps::'+stage+');')
for expression in ['jointBounds_.at(0).evaluate(asset_, renderSettings_->morphWeights, asset_.jointMatrices)','jointBounds_.at(meshBounds.size()).evaluate(resource->asset, renderSettings_->morphWeights, resource->asset.jointMatrices)','jointBounds_.at(instance.meshKey).evaluate(mesh, morph, pose.jointMatrices,&pose)']:
 assert s.count(expression)==1;s=s.replace(expression,'azCpuOps::measure(azCpuOps::Bounds,[&]{return '+expression+';})')
for expression,stage in [('materialDisplacementMargin(mesh)','Margin'),('resolveMaterialFrame(mesh)','MaterialFrame')]:
 assert expression in s;s=s.replace(expression,'azCpuOps::measure(azCpuOps::'+stage+',[&]{return '+expression+';})')
needle='    auto* destination = static_cast<InstanceGpuData*>(';assert s.count(needle)==1;s=s.replace(needle,'    azCpuOps::Scope upload(azCpuOps::InstanceUpload);\n'+needle)
needle='    const Vector3 cameraForward = normalize(subtract(cameraTarget_, cameraPosition_));'
assert s.count(needle)==1;s=s.replace(needle,'    std::vector<unsigned char> cpuVisible(sceneInstances_.size());for(const auto* p:visibleInstances_)cpuVisible.at(p->sourceIndex)=1;\n'+needle)
needle='        if (transparentPrimitives.empty()) continue;';assert s.count(needle)==1
s=s.replace(needle,needle+r'''
        const bool cpuConsumed=cpuVisible.at(instance.sourceIndex)!=0;
        azCpuOps::Scope cohort(cpuConsumed?azCpuOps::TransparentVisible:azCpuOps::TransparentHidden);
        if(azCpuOps::sampling){const unsigned bucket=cpuConsumed?0:1;azCpuOps::vertices[bucket]+=transparentTopologies_[instance.meshKey].vertices.size();++azCpuOps::instances[bucket];for(const auto* p:transparentPrimitives)azCpuOps::indices[bucket]+=p->indexCount;}
''')
s=entry(s,'void CharacterSceneRenderer::onUnload(','azCpuOps::dump();')
motion=(root/'src/scenes/CharacterMotionPass.inc').read_text();motion=entry(motion,'void CharacterSceneRenderer::prepareMotion(','azCpuOps::Scope wholeMotion(azCpuOps::Motion);')
for old,new in [
 ('    auto& poses=motionPoseScratch_;','    azCpuOps::Scope fillTimer(azCpuOps::MotionPoseFill);\n    auto& poses=motionPoseScratch_;'),
 ('    MotionPoseView view;','    fillTimer.stop();azCpuOps::Scope historyTimer(azCpuOps::MotionHistory);\n    MotionPoseView view;'),
 ('    MotionVectorInputs inputs;','    historyTimer.stop();azCpuOps::Scope bindingTimer(azCpuOps::MotionBindings);\n    MotionVectorInputs inputs;'),
 ('    // Match the colour order:','    bindingTimer.stop();azCpuOps::Scope drawTimer(azCpuOps::MotionDraws);\n    // Match the colour order:')]:
 assert motion.count(old)==1;motion=motion.replace(old,new)
(out/'CharacterMotionPass.inc').write_text(motion)
needle='#include "CharacterMotionPass.inc"';assert s.count(needle)==1;s=s.replace(needle,'#include "'+(out/'CharacterMotionPass.inc').as_posix()+'"')
(out/'CharacterSceneRenderer.cpp').write_text(prefix+s)
build=root/'build/ninja-msvc-release';cache=(build/'CMakeCache.txt').read_text();ninja=re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.+)$',cache,re.M).group(1)
commands=subprocess.check_output([ninja,'-C',str(build),'-t','commands','AzurePlayer.exe'],text=True,encoding='utf-8').splitlines();compile_command=next(c for c in commands if c.rstrip().endswith('CharacterSceneRenderer.cpp'))
rule=re.search(r'^build AzurePlayer\.exe: (\S+)',(build/'build.ninja').read_text(),re.M).group(1)
expanded=json.loads(subprocess.check_output([ninja,'-C',str(build),'-t','compdb','-x',rule],text=True,encoding='utf-8'));assert len(expanded)==1
(out/'compile-command.txt').write_text(compile_command);(out/'link-command.txt').write_text(expanded[0]['command']);(out/'source-inputs.json').write_text(json.dumps(source,indent=2));assert inputs(root)==source
print('Prepared eight-frame CPU work-scope diagnosis; production remains unchanged',flush=True)
