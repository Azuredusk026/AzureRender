from pathlib import Path
import subprocess,os,sys,json,ctypes,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9')
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',*sys.argv[1:]],env=env).returncode)
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
before=inputs(root)
def split(command):
 count=ctypes.c_int();f=ctypes.windll.shell32.CommandLineToArgvW;f.restype=ctypes.POINTER(ctypes.c_wchar_p);f.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
 result=f(command,ctypes.byref(count));values=[result[i] for i in range(count.value)];ctypes.windll.kernel32.LocalFree(result);return values
command=split((out/'compile-command.txt').read_text())
for i,v in enumerate(command):
 if v.startswith('/Fo'):command[i]='/Fo'+str(out/'CharacterSceneRenderer.obj')
 elif v.startswith('/Fd'):command[i]='/Fd'+str(out/'CharacterSceneRenderer.pdb')
command=[v for v in command if v!='/showIncludes'];command[-1]=str(out/'CharacterSceneRenderer.cpp');command.insert(1,'/I'+str(root/'src/scenes'))
start=time.monotonic()
if '--link-only' not in sys.argv:
 with (out/'compile.log').open('wb') as log:result=subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 assert result.returncode==0,(out/'compile.log').read_text(errors='replace')[-5000:]
else:
 assert (out/'CharacterSceneRenderer.obj').stat().st_mtime_ns >= (out/'CharacterSceneRenderer.cpp').stat().st_mtime_ns
link=split((out/'link-command.txt').read_text().split(' -- ',1)[1].split(' && ',1)[0])
for i,v in enumerate(link):
 if v.lower().startswith('/out:'):link[i]='/out:'+str(out/'CpuStagesPlayer.exe')
 elif v.lower().startswith('/implib:'):link[i]='/implib:'+str(out/'CpuStagesPlayer.lib')
 elif v.lower().startswith('/pdb:'):link[i]='/pdb:'+str(out/'CpuStagesPlayer.pdb')
link=[v for v in link if not v.lower().startswith(('/debug','/incremental'))];link[1:1]=[str(out/'CharacterSceneRenderer.obj'),'/DEBUG:NONE','/INCREMENTAL:NO']
with (out/'link.log').open('wb') as log:result=subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert result.returncode==0,(out/'link.log').read_text(errors='replace')[-5000:]
assert inputs(root)==before
(out/'build.json').write_text(json.dumps(dict(compile=command,link=link,executableSha256=digest(out/'CpuStagesPlayer.exe'),productionInputsUnchanged=True,seconds=time.monotonic()-start),indent=2))
print(json.dumps(dict(status='built',seconds=time.monotonic()-start,productionInputsUnchanged=True)))
