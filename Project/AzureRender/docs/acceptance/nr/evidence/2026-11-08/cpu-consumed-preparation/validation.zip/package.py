from pathlib import Path
import json,hashlib,sys,subprocess,zipfile,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
execution=json.loads((out/'execution.json').read_text());work=json.loads((out/'cpu-work.json').read_text())
assert execution['exitCode']==0 and execution['productionAndProjectInputsUnchanged'] and execution['validationLogClean'] and execution['zeroAllocator']
assert work['frames']==8 and work['selectedFrames']==6 and inputs(root)==json.loads((out/'source-inputs.json').read_text())
analysis=dict(hiddenTransparentVertexShare=work['verticesByVisibleHidden'][1]/sum(work['verticesByVisibleHidden']),hiddenTransparentIndexShare=work['indicesByVisibleHidden'][1]/sum(work['indicesByVisibleHidden']),motionBindingAndHistoryMs=sum(work['stages'][k]['perFrameMs'] for k in ['motionBindings','motionHistory']))
analysis['motionBindingAndHistoryUpdateShare']=analysis['motionBindingAndHistoryMs']/work['stages']['update']['perFrameMs']
proof=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,status='passed',sha256=digest(p)))
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/cpu-consumed-preparation';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.cpp','.inc','.json','.log','.txt','.csv'] and p.stat().st_size<2*2**20}
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in sorted(members.items()):archive.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as archive:
 assert archive.testzip() is None
 for name,path in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='preparation-consumed-scope-below-batch-gate',sourceBase='254cd03',execution=execution,work=work,analysis=analysis,productionProvenance=proof,userDiffSha256=protected,candidateAdopted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=name,bytes=p.stat().st_size,sha256=digest(p)) for name,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-cpu-consumed-preparation.md','docs/acceptance/nr/cpu-consumed-preparation.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],analysis=analysis,evidenceBytes=report['evidenceBytes'],mainInputsUnchanged=True,userDiffPreserved=True)))
