#include "render/SurfaceLightingCache.hpp"
#include "rhi/NullRhi.hpp"
#include <iostream>
#include <limits>
using namespace azurerender;
namespace {void require(bool value,const char* text){if(!value)throw std::runtime_error(text);}}
int main()try{
    rhi::NullRhi backend;
    require(SurfaceLightingCache::supported(backend,{2560,1440},2),"1440p two-slot cache fits");
    require(!SurfaceLightingCache::supported(backend,{3840,2160},2),"4K falls back within default budget");
    require(!SurfaceLightingCache::supported(backend,{UINT32_MAX,UINT32_MAX},8),"Budget cannot wrap");
    for(auto slots:{0U,9U})require(!SurfaceLightingCache::supported(backend,{64,48},slots),"Slot bound");
    require(!SurfaceLightingCache::supported(backend,{0,48},2),"Empty extent");
    require(!SurfaceLightingCache::supported(backend,{8193,1},2),"Extent bound");
    backend.unavailableSampledFormats.insert(VK_FORMAT_R32G32B32A32_UINT);
    require(!SurfaceLightingCache::supported(backend,{64,48},2),"Identity format is required");
    backend.unavailableSampledFormats.clear();
    const auto key=surfaceLightingIdentity(.25F,7,123,11,19);
    require(key.words==std::array<std::uint32_t,4>{0x3e800000U,7,156,19},"Full identity");
    require(surfaceLightingIdentity(0.F,0,0,0,0).words!=surfaceLightingIdentity(-0.F,0,0,0,0).words,"Signed depth zero");
    require(!surfaceLightingIdentity(.5F,0,UINT32_MAX-1,1,0).valid(),"Triangle index overflow");
    require(!surfaceLightingIdentity(std::numeric_limits<float>::infinity(),0,0,0,0).valid(),"Infinite depth");
    require(!surfaceLightingIdentity(std::numeric_limits<float>::quiet_NaN(),0,0,0,0).valid(),"NaN depth");
    const auto before=backend.allocator().statistics().liveImages;
    {
        SurfaceLightingCache cache(backend,{64,48},2);
        require(cache.bytes()==64U*48U*32U*2U,"Two attachment byte accounting");
        require(backend.allocator().statistics().liveImages==before+4,"Two images per slot");
        for(unsigned kind=0;kind<2;++kind)
            require(cache.texture(0,kind).image.image!=cache.texture(1,kind).image.image,"Independent frame slots");
        bool rejected=false;try{cache.texture(2,0);}catch(const std::out_of_range&){rejected=true;}require(rejected,"Slot bounds");
        rejected=false;try{SurfaceLightingCache::format(2);}catch(const std::out_of_range&){rejected=true;}require(rejected,"Format bounds");
        require(SurfaceLightingCache::clearValue(0).color.float32[3]==0.F,"Empty lighting invalid");
        require(SurfaceLightingCache::clearValue(1).color.uint32[2]==UINT32_MAX,"Empty identity invalid");
    }
    require(backend.allocator().statistics().liveImages==before,"Cache released");
    std::cout<<"Lighting cache identity, formats, budget and lifetime passed\n";
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
