from pathlib import Path
import json,os,traceback,time,array,math,hashlib
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261108-093510-surface-lighting-reuse-3223fa'
state=json.loads((root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea/state.json').read_text());analysis=json.loads((root/'build/runs/20261108-092305-shadow-cost-scope-ef3182/eligibility-analysis.json').read_text())
selected=sorted(analysis['eligibleEvents'],key=lambda r:r['baselineMs'],reverse=True)[:3]
cap=None;c=None;report=dict(status='starting');started=time.monotonic()
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded;textures={str(t.resourceId):t for t in c.GetTextures()}
 def fields(o):return {str(o.GetChild(i).name):o.GetChild(i) for i in range(o.NumChildren())}
 pipelineMetadata={};wanted={r['pipeline'] for r in analysis['eligibleEvents']}
 for ch in c.GetStructuredFile().chunks:
  if str(ch.name)!='vkCreateGraphicsPipelines':continue
  f=fields(ch);pipeline=str(f['Pipeline'].AsResourceId())
  if pipeline not in wanted:continue
  info=fields(f['CreateInfo']);blend=fields(info['pColorBlendState']);depth=fields(info['pDepthStencilState'])
  masks=[int(fields(blend['pAttachments'].GetChild(i))['colorWriteMask'].data.basic.u) for i in range(blend['pAttachments'].NumChildren())]
  pipelineMetadata[pipeline]=dict(colorWriteMasks=masks,depthWrite=bool(depth['depthWriteEnable'].data.basic.u),depthCompare=int(depth['depthCompareOp'].data.basic.u))
 first=selected[0]['event'];c.SetFrameEvent(first,True);pipe=c.GetPipelineState();reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel);matches=[]
 for getter,resources in [(pipe.GetReadOnlyResources,reflection.readOnlyResources),(pipe.GetReadWriteResources,reflection.readWriteResources)]:
  for used in getter(rd.ShaderStage.Pixel):
   if resources[used.access.index].fixedBindNumber==37:matches.append(used.descriptor.resource)
 assert len(matches)==1,matches
 resource=matches[0];texture=textures[str(resource)];rw,rh=texture.width,texture.height
 target=pipe.GetOutputTargets()[0].resource;targetDesc=textures[str(target)];w,h=targetDesc.width,targetDesc.height
 report['reflectionExtent']=[rw,rh];report['target']=dict(width=w,height=h,format=targetDesc.format.Name())
 raw=bytes(c.GetTextureData(resource,rd.Subresource()));assert texture.format.Name()=='R32G32B32A32_FLOAT' and len(raw)==rw*rh*16
 values=array.array('f');values.frombytes(raw);alpha=values[3::4];assert all(math.isfinite(v) and v>=0 for v in alpha)
 zero=bytearray(v==0 for v in alpha);safe=bytearray(w*h)
 for y in range(h):
  sy=math.floor((y+.5)/h*rh-.5)
  for x in range(w):
   sx=math.floor((x+.5)/w*rw-.5)
   if all(zero[max(0,min(rh-1,sy+dy))*rw+max(0,min(rw-1,sx+dx))] for dy in [-1,0,1,2] for dx in [-1,0,1,2]):safe[y*w+x]=1
 quad=bytearray(w*h)
 for y in range(0,h-1,2):
  for x in range(0,w-1,2):
   i=y*w+x
   if safe[i] and safe[i+1] and safe[i+w] and safe[i+w+1]:quad[i]=quad[i+1]=quad[i+w]=quad[i+w+1]=1
 del values,raw
 rows=[]
 for row in selected:
  event=row['event'];c.SetFrameEvent(event-1,True);beforePipe=c.GetPipelineState();target=beforePipe.GetOutputTargets()[0].resource;desc=textures[str(target)]
  assert desc.width==w and desc.height==h
  before=bytes(c.GetTextureData(target,rd.Subresource()));c.SetFrameEvent(event,True);after=bytes(c.GetTextureData(target,rd.Subresource()));assert len(before)==len(after) and len(before)%(w*h)==0
  stride=len(before)//(w*h);assert stride in [4,8,16]
  changed=eligible=0
  a=memoryview(before);b=memoryview(after)
  for i in range(w*h):
   if a[i*stride:(i+1)*stride]!=b[i*stride:(i+1)*stride]:changed+=1;eligible+=quad[i]!=0
  rows.append(dict(**row,pipelineMetadata=pipelineMetadata[row['pipeline']],targetFormat=desc.format.Name(),colorChangedPixels=changed,conservativeZeroReflectionPixels=eligible,conservativeZeroFraction=eligible/max(changed,1)))
 report=dict(status='read',seconds=time.monotonic()-started,captureSha256=state['captureSha256'],width=w,height=h,reflectionWidth=rw,reflectionHeight=rh,resource=str(resource),alphaZeroPixels=zero.count(1),reflectionPixels=rw*rh,conservativeZeroQuadPixels=quad.count(1),allPixels=w*h,selectedEvents=rows,pipelineMetadata=pipelineMetadata,newGpuTimingExecuted=False,fragmentCoverageNotMeasured=True)
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'confidence-scope.json').write_text(json.dumps(report,indent=2));os._exit(0 if report['status']=='read' else 1)
