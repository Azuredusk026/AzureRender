from pathlib import Path
import json,hashlib,sys,subprocess,zipfile,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
baseline=json.loads((out/'baseline.json').read_text());assert inputs(root)==baseline['sourceInputs']
proof=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,sha256=digest(p)))
confidence=json.loads((out/'confidence-scope.json').read_text());assert confidence['status']=='read' and confidence['newGpuTimingExecuted']==False
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/surface-lighting-reuse';evidence.mkdir(parents=True,exist_ok=True)
members={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and p.suffix in ['.py','.json','.log','.cpp','.hpp','.frag','.vert','.inc','.txt'] and 'tmp' not in p.relative_to(out).parts}
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='proposal-isolated-coverage-evidence-insufficient',sourceBase='17df0c6',confidenceScope=confidence,productionProvenance=proof,userDiffSha256=protected,candidateImplemented=False,newGpuTimingExecuted=False,nativeBatchStarted=False,candidateAdopted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package))
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest=root/'docs/development/artifact-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'));data['milestones']=[m for m in data['milestones'] if m['path']!='runs/'+out.name];data['milestones'].insert(0,dict(path='runs/'+out.name,name='零反射完整照明复用提案',status='CoverageEvidenceInsufficient',sourceBase='17df0c6',evidence='docs/acceptance/nr/surface-lighting-reuse.md',candidateImplemented=False,newGpuTimingExecuted=False));manifest.write_text(json.dumps(data,indent=2,ensure_ascii=False).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md']:
 p=root/name;text=p.read_text(encoding='utf-8');start=text.index('shadow-cost-scope.md)');end=text.index('\n',start)
 line='[零反射复用提案]('+('docs/acceptance/nr/' if name=='README.md' else '../acceptance/nr/')+'surface-lighting-reuse.md)保存反射贡献范围，实际材质覆盖依据尚未成立。\n'
 if line not in text:p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-surface-lighting-reuse.md','docs/acceptance/nr/surface-lighting-reuse.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],evidenceBytes=package.stat().st_size,productionUnchanged=True)))
