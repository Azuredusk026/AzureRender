from pathlib import Path
import json,sys,hashlib,zipfile,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest
checks=json.loads((out/'checks.json').read_text());defaults=json.loads((out/'default-checks.json').read_text())
assert len(checks)==4 and len(defaults)==2 and all(r['exitCode']==0 for r in checks+defaults)
received=out/'native-metadata/results.json'
native=json.loads(received.read_text()) if received.exists() else dict(status='bounded-native-unresolved',firstExecution=json.loads((out/'native/execution.json').read_text()),completionExecution=json.loads((out/'native-completion/execution.json').read_text()),actualMatchRatesEstablished=False)
if received.exists():assert all(native[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationTextClean','zeroAllocator'])
retained=json.loads((out/'retained-programs-check.json').read_text());assert not retained['changed']
cases=[]
for name in ['nvidia.xml','intel.xml','release-default.xml','debug-default.xml']:
 for case in ET.parse(out/name).getroot().findall('testcase'):
  assert case.find('failure') is None
  cases.append(dict(receipt=name,name=case.attrib['name'],skipped=case.find('skipped') is not None))
assert len(cases)==12 and sum(r['skipped'] for r in cases)==1
cleanup=[json.loads((out/n).read_text()) for n in ['release-program-cleanup.json','debug-program-cleanup.json','disabled-tests-cleanup.json']]
assert all(r['status']=='applied' for r in cleanup)
sources=['CMakeLists.txt','src/render/SurfaceRadianceCache.hpp','src/render/SurfaceRadianceCache.cpp','shaders/surface_radiance.glsl','shaders/surface_radiance_statistics.glsl','shaders/surface_radiance_probe.frag','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterMaterialSampling.inc','src/app/AzureRenderApp.cpp','tests/SurfaceRadianceStatisticsTests.cpp','tests/SurfaceRadianceCacheGpuTests.cpp','tests/SurfaceRadianceViewGpuTests.cpp','tests/support/VulkanComputeFixture.hpp']
members={}
for p in out.rglob('*'):
 if not p.is_file():continue
 relative=p.relative_to(out)
 if any(part in {'tmp','__pycache__'} for part in relative.parts):continue
 if p.suffix not in ['.py','.json','.log','.xml','.cpp','.hpp','.inc','.glsl','.txt']:continue
 if not 0<p.stat().st_size<=2*2**20:continue
 members['run/'+relative.as_posix()]=p
for name in sources:members['source/'+name]=root/name
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/radiance-consumption-counters';evidence.mkdir(parents=True,exist_ok=True);archive=evidence/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert archive.stat().st_size<8*2**20
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='diagnostic-mechanism-validated',sourceBase='157c757',sourceHashes={n:digest(root/n) for n in sources},native=native,checks=checks,defaultChecks=defaults,cases=cases,retainedNormalPrograms=720,defaultPrograms=673,diagnosticPrograms=754,diagnosticsEnabledByDefault=False,reuseEnabledByDefault=False,counterBytesPerFrameSlot=24,cleanup=dict(files=sum(r['files'] for r in cleanup),logicalBytes=sum(r['logicalBytes'] for r in cleanup),volumeObservedDeltaBytes=sum(r['freeAfterBytes']-r['freeBeforeBytes'] for r in cleanup)),formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=archive.stat().st_size,evidenceSha256=digest(archive))
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
summary='原生消费比例仍待取得。\n两次有界诊断的停止收据独立保存。'
if received.exists():
 s=native['statistics'];r=native['rates']
 summary=f"原生回收 {s['frames']} 个有效帧槽。\n合格访问为 {s['eligibleRequests']} 次。\n逐片元命中率为 {r['pixelMatchFraction']:.4%}。\n完整四像素组接受率为 {r['quadAcceptanceFraction']:.4%}。"
text=f'''# 照明复用消费计数验收

## 结果与范围

本单元入口为 `157c757`。
计数机制通过所属 CPU、GPU 及双设备视图检查。
默认配置关闭照明复用及消费计数。
整体画质保持 `failed-user-review`。

CPU 八毫秒及 GPU 16.6 毫秒预算继续有效。
原子计数具有侵入性，数量用于工作量归因。
正式一千八百帧、十五轮及人工复核仍待验收。

## 数据与生命周期

资源契约见[同帧照明复用](../../development/surface-radiance-cache.md)。
每帧槽计数缓冲为二十四字节。
主机在所属完成栅栏后读取并清零。
累计数量只包含已经回收且有写入的帧槽。

计数包含生产写入、访问、合格访问及两种命中。
辅助片元保持排除，覆盖重叠按实际调用计量。
逐片元身份与完整四像素组接受分别计量。
缓冲溢出具有持续标志。

## 原生诊断

首次诊断在三百秒预算处停止。
日志停留于资源加载后的管线准备阶段。
该次未形成帧计数结果。
完成诊断采用一次六百秒预算。

三十二帧在约四百四十七秒内正常完成。
世界状态报告的接口错误另有定位收据。
最终补采使用已有 GPU 报告及共享管线缓存。
补采耗时约二百一十五秒，计时字段仅供诊断。

{summary}

输入来源、命令及执行预算随收据保存。
项目输入锁覆盖一千七百二十九项。
本单元采用三十二帧，保持既有联合场景及相机。
消费比例与唯一像素规模按独立指标解释。

逐片元命中为全部合格访问。
约 14.94% 的合格访问因整组检查执行完整着色。
该比例单独不足以证明 GPU 帧收益。
辅助片元及附件成本继续作为后续方案的依据。

## 所属检查

五项 NVIDIA 所属 CTest 通过。
Intel 缓存夹具因设备能力返回跳过代码。
两个设备各完成十组视图的字节比较。
同步验证错误及卸载分配器残留均为零。

GPU 图案覆盖完全命中与混合失配。
混合图案具有一半逐片元命中，整组接受为零。
计数溢出及帧槽复用各有实际检查。
CPU 检查覆盖归零、空记录及释放。

主 Debug 与 Release 各通过三项默认检查。
默认着色程序为六百七十三份，摘要保持一致。
诊断构建共七百五十四份程序。
普通缓存及默认程序共七百二十份保持原字节。

## 产物与接续

本批关闭入口后的专用生成物按摘要清单回收。
默认主构建及用户已有改动保持所属范围。
所有日志、临时文件和证据均位于 D 卷。
普通任务保留一天，精简证据限制为八 MiB。

实际收益使用关闭计数的普通程序评估。
新的整帧批次依据热点成本及操作量门槛组织。
原画质、严格四帧及正式帧预算保持有效。

[结果收据](evidence/2026-11-08/radiance-consumption-counters/results.json)记录来源与范围。
[精简证据](evidence/2026-11-08/radiance-consumption-counters/validation.zip)保存实现及检查。
'''
(root/'docs/acceptance/nr/radiance-consumption-counters.md').write_text(text,encoding='utf-8',newline='\n')
p=root/'docs/plans/2026-11-08-radiance-consumption-counters.md'
p.write_text(p.read_text(encoding='utf-8')+'\n## 结果\n\n计数机制与所属设备检查通过。\n\n'+summary+'\n\n默认主构建保持关闭，两种配置的所属检查通过。\n详见[消费计数验收](../acceptance/nr/radiance-consumption-counters.md)。\n',encoding='utf-8',newline='\n')
for name,anchor,extra in [
 ('README.md','[照明缓存接入](docs/acceptance/nr/radiance-cache-precision-integration.md)通过严格四帧及设备回退检查，短时 GPU 均值增加约 0.72 毫秒，实验选项默认关闭。','[消费计数](docs/acceptance/nr/radiance-consumption-counters.md)提供实际访问与整组接受诊断，计数及复用选项默认关闭。'),
 ('docs/plans/azure-engine-plan.md','下一项先核定实际复用覆盖及附件成本，再组织有效的着色批次。','[消费计数](../acceptance/nr/radiance-consumption-counters.md)完成帧槽、GPU 图案及设备回退检查。\n'+summary+'\n后续性能批次按实际覆盖及附件成本选择。'),
 ('docs/plans/2026-11-06-performance-bottlenecks.md','后续先建立实际命中覆盖及附件成本依据。','[消费计数](../acceptance/nr/radiance-consumption-counters.md)提供实际访问及整组接受的诊断机制。\n'+summary)]:
 p=root/name;s=p.read_text(encoding='utf-8');assert anchor in s
 s=s.replace(anchor,anchor+'\n'+extra if name=='README.md' else extra,1)
 p.write_text(s,encoding='utf-8',newline='\n')
p=root/'docs/development/artifact-manifest.json';data=json.loads(p.read_text(encoding='utf-8'))
data['milestones'].insert(0,dict(path='runs/'+out.name,name='照明复用消费计数',status='DiagnosticMechanismValidated',sourceBase='157c757',evidence='docs/acceptance/nr/radiance-consumption-counters.md',checksPassed=11,checksSkipped=1,pairedViewFlowsPassed=2,nativeStatus=native['status'],diagnosticsEnabledByDefault=False,reclaimedFiles=report['cleanup']['files'],formalPerformancePassed=False))
p.write_text(json.dumps(data,ensure_ascii=False,indent=2).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
p=root/'CHANGELOG.md';s=p.read_text(encoding='utf-8')
p.write_text(s.replace('# Changelog\n','# Changelog\n\n## 照明复用消费计数 2026-11-08\n\n- 增加生产、访问、逐片元命中及完整四像素组接受计数。\n- 所属帧槽、GPU 图案及双设备视图检查通过。\n- 默认入口保持关闭，专用生成物按清单回收。\n- 范围及剩余项见[消费计数验收](docs/acceptance/nr/radiance-consumption-counters.md)。\n',1),encoding='utf-8',newline='\n')
print(json.dumps(dict(nativeStatus=native['status'],checks=len(cases),skipped=1,evidenceBytes=archive.stat().st_size,cleanup=report['cleanup'])))
