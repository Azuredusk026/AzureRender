from pathlib import Path
import json,os,sys,subprocess,hashlib,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
expected=json.loads((out/'retained-programs.json').read_text());changed=[name for name,sha in expected.items() if hashlib.sha256((build/'shaders'/name).read_bytes()).hexdigest()!=sha]
(out/'retained-programs-check.json').write_text(json.dumps(dict(retainedPrograms=len(expected),changed=changed,allPrograms=len(list((build/'shaders').glob('*.spv')))),indent=2));assert not changed,changed
env=os.environ.copy();env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'),TMPDIR=str(out/'tmp'))
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';rows=[]
for label,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 env['VK_LOADER_DRIVERS_SELECT']=driver
 pattern=r'^AzureRender\.(SurfaceRadianceCache|SurfaceRadianceStatistics|SurfaceRadianceCacheGpu|SurfaceRadianceRecording|DepthPrefillRecording)$' if label=='nvidia' else r'^AzureRender\.SurfaceRadianceCacheGpu$'
 command=[ctest,'--test-dir',str(build),'-R',pattern,'--output-on-failure','--no-tests=error','--output-junit',str(out/(label+'.xml'))]
 started=time.monotonic()
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 rows.append(dict(device=label,kind='ctest',command=command,exitCode=r.returncode,seconds=time.monotonic()-started));print(json.dumps(rows[-1]),flush=True);(out/'checks.json').write_text(json.dumps(rows,indent=2))
 if r.returncode:print((out/(label+'.log')).read_text(errors='replace')[-5000:]);raise SystemExit(r.returncode)
 folder=out/('view-'+label);folder.mkdir(exist_ok=True)
 command=[str(build/'AzureSurfaceRadianceViewGpuTests.exe'),str(build/'shaders'),str(folder)];started=time.monotonic()
 with (out/('view-'+label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
 row=dict(device=label,kind='view',command=command,exitCode=r.returncode,seconds=time.monotonic()-started);rows.append(row)
 if r.returncode:print((out/('view-'+label+'.log')).read_text(errors='replace')[-5000:]);raise SystemExit(r.returncode)
 data=json.loads((folder/(label+'-summary.json')).read_text());assert data['validationErrors']==0 and data['zeroAllocator']
 active=[c for c in data['checks'] if c['requested'] and c['lighting']==0 and c['phase']<7]
 if label=='nvidia':
  assert active and all(c['metadata']['surfaceRadianceStatistics']['enabled'] and c['metadata']['surfaceRadianceStatistics']['frames']>0 and c['metadata']['surfaceRadianceStatistics']['consumerVisits']>0 and not c['metadata']['surfaceRadianceStatistics']['overflow'] for c in active)
 else:assert all(not c['metadata']['surfaceRadianceStatistics']['enabled'] for c in data['checks'])
 row.update(recordedStates=len(data['checks']),activeDiagnosticStates=len(active),validationErrors=0,zeroAllocator=True)
 print(json.dumps(row),flush=True);(out/'checks.json').write_text(json.dumps(rows,indent=2))
