from pathlib import Path
import json,subprocess,hashlib,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent
names=['CMakeLists.txt','src/render/SurfaceRadianceCache.hpp','src/render/SurfaceRadianceCache.cpp','shaders/surface_radiance.glsl','shaders/surface_radiance_probe.frag','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterMaterialSampling.inc','src/app/AzureRenderApp.cpp','tests/SurfaceRadianceCacheGpuTests.cpp','tests/SurfaceRadianceViewGpuTests.cpp','tests/support/VulkanComputeFixture.hpp']
for name in names:
 p=out/'original-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show','157c757:Project/AzureRender/'+name]))
with zipfile.ZipFile(root/'docs/acceptance/nr/evidence/2026-11-08/radiance-cache-precision-integration/validation.zip') as z:old=json.loads(z.read('run/measured-release-provenance.json'))
programs={Path(name).name:sha for name,sha in old['products'].items() if name.endswith('.spv') and 'shaders' in Path(name).parts};assert len(programs)==720
(out/'retained-programs.json').write_text(json.dumps(programs,indent=2))
previous=out.parent/'20261108-174124-radiance-cache-precision-integration-ad0b15/build.py'
s=previous.read_text().replace("'-DAZURE_ENABLE_SURFACE_RADIANCE_REUSE=ON'","'-DAZURE_ENABLE_SURFACE_RADIANCE_REUSE=ON','-DAZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS=ON'")
s=s.replace("['AzureSurfaceRadianceViewGpuTests','AzureSurfaceRadianceCacheTests','AzureSurfaceRadianceCacheGpuTests','AzureSurfaceRadianceRecordingTests','AzureDepthPrefillRecordingTests','AzureBeautyCompositionGpuTests']","['AzureSurfaceRadianceStatisticsTests','AzureSurfaceRadianceViewGpuTests','AzureSurfaceRadianceCacheTests','AzureSurfaceRadianceCacheGpuTests','AzureSurfaceRadianceRecordingTests','AzureDepthPrefillRecordingTests']")
(out/'build.py').write_text(s);print('Frozen entry snapshots and 720 retained program hashes; scoped diagnostic build prepared')
