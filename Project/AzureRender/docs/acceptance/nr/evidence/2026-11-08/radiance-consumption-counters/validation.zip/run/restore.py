from pathlib import Path
import sys,subprocess
out=Path('build/runs/20261108-191723-radiance-consumption-counters-ec40da')
for config in ['Release','Debug']:
 r=subprocess.run([sys.executable,'-X','utf8',str(out/'final_build.py'),config]);assert r.returncode==0
r=subprocess.run([sys.executable,'-X','utf8',str(out/'final_checks.py')]);assert r.returncode==0
r=subprocess.run([sys.executable,'-X','utf8',str(out/'cleanup_tests.py')]);assert r.returncode==0
