from pathlib import Path
import json,sys,hashlib,subprocess
root=Path.cwd().resolve();out=root/'build/runs/20261108-191723-radiance-consumption-counters-ec40da';sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,digest
report=json.loads((root/'docs/acceptance/nr/evidence/2026-11-08/radiance-consumption-counters/results.json').read_text(encoding='utf-8'))
assert all(digest(root/name)==sha for name,sha in report['sourceHashes'].items())
rows=[]
for config in ['release','debug']:
 build=root/('build/ninja-msvc-'+config);verify(root,json.loads((build/'build-provenance.json').read_text()))
 cache=(build/'CMakeCache.txt').read_text();assert all('AZURE_ENABLE_SURFACE_RADIANCE_'+name+':BOOL=OFF' in cache for name in ['REUSE','DIAGNOSTICS'])
 assert len(json.loads((build/'shader-reload.json').read_text())['programs'])==673
 commands=(build/'build.ninja').read_text();assert 'AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1' not in commands and 'AZURE_SURFACE_RADIANCE_PROGRAMS=1' not in commands
 rows.append(dict(configuration=config,verified=True,programs=673,diagnosticCompilationUnits=0))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
sha=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest();assert sha=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
result=dict(status='verified',builds=rows,protectedUserDiffSha256=sha,sourceHashesMatch=True,nativeSourceAndProductsUnchanged=report['native']['sourceInputsUnchanged'] and report['native']['productsUnchanged'],cDriveProjectSkillAbsent=not Path('C:/Users/admin/.codex/skills/azurerender-artifact-maintenance').exists())
(out/'audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
