from pathlib import Path
import json,hashlib,subprocess,shutil,sys,stat
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;config=sys.argv[1].lower();build=root/('build/ninja-msvc-'+config)
assert 'AZURE_ENABLE_SURFACE_RADIANCE_REUSE:BOOL=OFF' in (build/'CMakeCache.txt').read_text()
baseline=json.loads((out/(config+'-baseline-shaders.json')).read_text());catalog=json.loads((build/'shader-reload.json').read_text())
assert {p['output'] for p in catalog['programs']}==set(baseline)
proof=json.loads((out/('measured-'+config+'-provenance.json')).read_text()) if config=='release' else {'products':{}};paths=sorted((build/'shaders').glob('*.spv'));paths=[p for p in paths if p.name not in baseline]
measured=json.loads((out/('measured-'+config+'-catalog.json')).read_text()) if config=='release' else catalog;expected={p['output'] for p in measured['programs']}-set(baseline)
assert {p.name for p in paths}==expected and len(expected)==(81 if config=='release' else 0)
rows=[]
for p in paths:
 assert p.resolve().parent==(build/'shaders').resolve()
 for parent in [p,*p.parents]:assert not parent.stat().st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT
 sha=hashlib.sha256(p.read_bytes()).hexdigest();assert proof['products'][str(p.resolve())]==sha
 rows.append(dict(path=str(p.resolve()),relative=p.relative_to(root).as_posix(),bytes=p.stat().st_size,sha256=sha))
assert not rows or not subprocess.check_output(['git','ls-files','--',*[r['relative'] for r in rows]]).strip()
receipt=root/('build/maintenance/radiance-statistics-program-cleanup-'+config+'.json');receipt.write_text(json.dumps(dict(status='planned',paths=rows),indent=2));freeBefore=shutil.disk_usage(root).free
for row in rows:
 p=Path(row['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];p.unlink()
report=dict(status='applied',files=len(rows),logicalBytes=sum(r['bytes'] for r in rows),freeBeforeBytes=freeBefore,freeAfterBytes=shutil.disk_usage(root).free,paths=rows)
receipt.write_text(json.dumps(report,indent=2));(out/(config+'-program-cleanup.json')).write_text(json.dumps(report,indent=2));print('Removed',len(rows),'experimental programs; retained all',len(baseline),'baseline programs')
