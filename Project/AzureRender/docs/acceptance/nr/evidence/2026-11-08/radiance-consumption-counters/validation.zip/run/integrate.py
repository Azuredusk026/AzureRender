from pathlib import Path
import json,subprocess,hashlib,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent
def edit(name,fn):
 p=root/name;s=p.read_text(encoding='utf-8');v=fn(s);assert v!=s,name
 q=p.with_name(p.name+'.counter-tmp');q.write_text(v,encoding='utf-8',newline='\n');q.replace(p)
def cmake(s):
 marker='option(AZURE_ENABLE_SURFACE_RADIANCE_REUSE "Enable experimental same-frame surface-radiance reuse" OFF)'
 s=s.replace(marker,marker+'\noption(AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS "Enable intrusive radiance consumption counters" OFF)\nif(AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS AND NOT AZURE_ENABLE_SURFACE_RADIANCE_REUSE)\n    message(FATAL_ERROR "Radiance diagnostics require AZURE_ENABLE_SURFACE_RADIANCE_REUSE")\nendif()',1)
 s=s.replace('COMPILE_DEFINITIONS "$<$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_REUSE}>:AZURE_SURFACE_RADIANCE_PROGRAMS=1>")','COMPILE_DEFINITIONS "$<$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_REUSE}>:AZURE_SURFACE_RADIANCE_PROGRAMS=1>"\n    "$<$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS}>:AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1>")',1)
 s=s.replace('"${SHADER_SOURCE_DIR}/surface_radiance_identity.glsl"','"${SHADER_SOURCE_DIR}/surface_radiance_identity.glsl" "${SHADER_SOURCE_DIR}/surface_radiance_statistics.glsl"')
 s=s.replace('OR "AZURE_SURFACE_RADIANCE_CONSUMER=1" IN_LIST SHADER_DEFINES)','OR "AZURE_SURFACE_RADIANCE_CONSUMER=1" IN_LIST SHADER_DEFINES OR "AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1" IN_LIST SHADER_DEFINES)',1)
 marker='compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.frag" DEFINES AZURE_SURFACE_RADIANCE_CONSUMER=1 OUTPUT_NAME surface_radiance_consumer.frag)'
 s=s.replace(marker,marker+'\nif(AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS)\ncompile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.frag" DEFINES AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1 OUTPUT_NAME surface_radiance_probe_stats.frag)\ncompile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.frag" DEFINES AZURE_SURFACE_RADIANCE_CONSUMER=1 AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1 OUTPUT_NAME surface_radiance_consumer_stats.frag)\nendif()',1)
 marker='        compile_shader("${SHADER_SOURCE_DIR}/${_radiance_source}" DEFINES ${_radiance_defines} AZURE_SURFACE_RADIANCE_REUSE=1 OUTPUT_NAME "${_radiance_output}")'
 s=s.replace(marker,marker+'\n        if(AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS AND _radiance_source STREQUAL "mesh.frag")\n            string(REPLACE "_radiance.frag" "_radiance_stats.frag" _radiance_stats_output "${_radiance_output}")\n            compile_shader("${SHADER_SOURCE_DIR}/${_radiance_source}" DEFINES ${_radiance_defines} AZURE_SURFACE_RADIANCE_REUSE=1 AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1 OUTPUT_NAME "${_radiance_stats_output}")\n        endif()',1)
 marker='    add_executable(AzureSurfaceRadianceCacheTests tests/SurfaceRadianceCacheTests.cpp)'
 s=s.replace(marker,'    add_executable(AzureSurfaceRadianceStatisticsTests tests/SurfaceRadianceStatisticsTests.cpp)\n    target_link_libraries(AzureSurfaceRadianceStatisticsTests PRIVATE AzureRenderCore)\n    add_test(NAME AzureRender.SurfaceRadianceStatistics COMMAND AzureSurfaceRadianceStatisticsTests)\n'+marker,1)
 marker='    target_link_libraries(AzureSurfaceRadianceViewGpuTests PRIVATE AzureRenderCore)'
 s=s.replace(marker,marker+'\n    target_compile_definitions(AzureSurfaceRadianceViewGpuTests PRIVATE AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS=$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS}>)',1)
 marker='    target_link_libraries(AzureSurfaceRadianceCacheGpuTests PRIVATE AzureRenderCore)'
 s=s.replace(marker,marker+'\n    target_compile_definitions(AzureSurfaceRadianceCacheGpuTests PRIVATE AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS=$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS}>)',1)
 return s
edit('CMakeLists.txt',cmake)
def renderer(s):
 s='#if defined(AZURE_SURFACE_RADIANCE_DIAGNOSTICS)\nstatic constexpr bool kSurfaceRadianceDiagnostics=true;\n#else\nstatic constexpr bool kSurfaceRadianceDiagnostics=false;\n#endif\n'+s
 s=s.replace('    radianceRequirements.sampledImageSlots+=4;', '    if(kSurfaceRadianceDiagnostics){++radianceRequirements.fragmentBuffers;++radianceRequirements.descriptorSetBuffers;}\n    radianceRequirements.sampledImageSlots+=4;',1)
 s=s.replace('    currentFrame_ = frame.currentFrame;','    currentFrame_ = frame.currentFrame;\n    if(surfaceRadiance_)surfaceRadiance_->beginStatisticsFrame(static_cast<unsigned>(currentFrame_));',1)
 s=s.replace('static_cast<unsigned>(kMaxFramesInFlight));}\n        catch(const std::exception& error){RuntimeDiagnostics::instance().info("render",std::string("Surface radiance allocation fallback:', 'static_cast<unsigned>(kMaxFramesInFlight),SurfaceRadianceCache::kMaximumBytes,kSurfaceRadianceDiagnostics);}\n        catch(const std::exception& error){RuntimeDiagnostics::instance().info("render",std::string("Surface radiance allocation fallback:',1)
 s=s.replace('+(viewFog_?1U:0U))}', '+(viewFog_?1U:0U)+(surfaceRadianceCapable_&&kSurfaceRadianceDiagnostics?1U:0U))}')
 needle='            bindings.push_back({38U+kind,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_FRAGMENT_BIT});'
 s=s.replace(needle,needle+'\n        if(surfaceRadianceCapable_&&kSurfaceRadianceDiagnostics)bindings.push_back({42,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT});')
 needle='    const auto writeSceneImages=[this](VkDescriptorSet set){'
 s=s.replace(needle,needle,1)
 needle='surfaceRadiance_->sampler(),VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL});\n    };'
 s=s.replace(needle,'surfaceRadiance_->sampler(),VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL});\n        if(surfaceRadiance_->statisticsEnabled()){const auto& buffer=surfaceRadiance_->statisticsBuffer(frame);\n            rhi_->writeDescriptorBuffer({set,42,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,buffer.buffer,buffer.size});}\n    };',1)
 needle='    std::array<RenderGraph::ResourceId,SurfaceRadianceCache::kAttachments> radianceResources{};'
 s=s.replace(needle,'''    std::optional<RenderGraph::ResourceId> radianceStatisticsResource;
    if(surfaceRadiance_&&surfaceRadiance_->statisticsEnabled()){
        const auto& buffer=surfaceRadiance_->statisticsBuffer(context.currentFrame);rhi::BufferBarrierDesc initial{};
        initial.buffer=buffer.buffer;initial.size=buffer.size;initial.dstStageMask=VK_PIPELINE_STAGE_HOST_BIT;initial.dstAccessMask=VK_ACCESS_HOST_WRITE_BIT;
        radianceStatisticsResource=graph.importBuffer("character-radiance-statistics",initial);
        graph.use(prepass,*radianceStatisticsResource,RenderGraphUsage::FragmentStorage,true);
    }
'''+needle,1)
 s=s.replace('}, [frozenContext, mainCounters, stageCounters](rhi::ICommandRecorder& commands)', '}, [this,frozenContext, mainCounters, stageCounters](rhi::ICommandRecorder& commands)',1)
 needle='        if (context.gpuTimingEnabled)\n            commands.writeTimestamp(context.timestampQueryPool, 2, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);'
 s=s.replace(needle,'        if(surfaceRadiance_)surfaceRadiance_->recordStatisticsReady(commands,static_cast<unsigned>(context.currentFrame));\n'+needle,1)
 needle='    graph.use(main,snapshotColor,RenderGraphUsage::Sampled,false);'
 s=s.replace(needle,needle+'\n    if(radianceStatisticsResource)graph.use(main,*radianceStatisticsResource,RenderGraphUsage::FragmentStorage,true);',1)
 needle='    instanceSnapshot_->validateForRecording();\n    for(const auto* buffer:'
 s=s.replace(needle,'''    instanceSnapshot_->validateForRecording();
    if(surfaceRadiance_&&surfaceRadiance_->statisticsEnabled()){const auto& buffer=surfaceRadiance_->statisticsBuffer(context.currentFrame);
        context.commands->bufferBarrier({buffer.buffer,0,buffer.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
            VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});}
    for(const auto* buffer:''',1)
 needle='    if(screenReflectionPrepared()&&reflectionActive_[context.currentFrame]){'
 s=s.replace(needle,'''    if(surfaceRadiance_&&surfaceRadiance_->statisticsEnabled()){const auto& buffer=surfaceRadiance_->statisticsBuffer(context.currentFrame);
        context.commands->bufferBarrier({buffer.buffer,0,buffer.size,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
            VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});}
'''+needle,1)
 needle='    commands.endRenderPass();\n    if (context.gpuTimingEnabled) {\n        commands.writeTimestamp(context.timestampQueryPool, 2'
 s=s.replace(needle,'    commands.endRenderPass();\n    if(surfaceRadiance_)surfaceRadiance_->recordStatisticsReady(commands,static_cast<unsigned>(context.currentFrame));\n    if (context.gpuTimingEnabled) {\n        commands.writeTimestamp(context.timestampQueryPool, 2',1)
 needle='    json << "  \\"uniqueMeshes\\": "'
 # Capture fields are emitted from the current retired statistics snapshot.
 needle='    json << "  \\"uniqueMeshes\\": "'.replace('\\\\','\\')
 pos=s.index('    json << "  \\"uniqueMeshes\\": "'.replace('\\\\','\\')) if needle in s else s.index('    json << "  \\"uniqueMeshes\\": "')
 return s
edit('src/scenes/CharacterSceneRenderer.cpp',renderer)
edit('src/scenes/CharacterMaterialSampling.inc',lambda s:s.replace('const auto cached=path.find("_radiance.frag.spv");','const auto cached=path.find("_radiance");\n            const auto cachedEnd=path.rfind(".frag.spv");',1).replace('if(cached!=std::string::npos)path.erase(cached,9);','if(cached!=std::string::npos&&cachedEnd!=std::string::npos)path.erase(cached,cachedEnd-cached);',1).replace('file.insert(file.rfind(".frag.spv"),"_radiance");return createMaterialShaderModule(file);','file.insert(file.rfind(".frag.spv"),kSurfaceRadianceDiagnostics?"_radiance_stats":"_radiance");return createMaterialShaderModule(file);',1))
edit('src/app/AzureRenderApp.cpp',lambda s:s.replace('        if(fragmentQuadControl_){enabledExtensions.push_back', '#if defined(AZURE_SURFACE_RADIANCE_DIAGNOSTICS)\n        fragmentQuadControl_&=supportedSampler.fragmentStoresAndAtomics==VK_TRUE;\n        deviceFeatures.fragmentStoresAndAtomics=fragmentQuadControl_?VK_TRUE:VK_FALSE;\n#endif\n        if(fragmentQuadControl_){enabledExtensions.push_back',1))
edit('tests/support/VulkanComputeFixture.hpp',lambda s:s.replace('bool quadControl=false) {','bool quadControl=false,bool fragmentAtomics=false) {',1).replace('            used.geometryShader=primitiveIdentity?VK_TRUE:VK_FALSE;','            used.geometryShader=primitiveIdentity?VK_TRUE:VK_FALSE;\n            if(fragmentAtomics&&!features.fragmentStoresAndAtomics)throw VulkanFeatureUnavailable("Fragment storage atomics are unavailable");\n            used.fragmentStoresAndAtomics=fragmentAtomics?VK_TRUE:VK_FALSE;',1))
edit('tests/SurfaceRadianceViewGpuTests.cpp',lambda s:s.replace('true,false,false,true,true);','true,false,false,true,true,AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS!=0);',1))
print('Diagnostic build option, capabilities, binding, and frame-slot barriers integrated')
