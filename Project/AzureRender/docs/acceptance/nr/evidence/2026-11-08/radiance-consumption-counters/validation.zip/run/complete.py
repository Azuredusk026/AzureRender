from pathlib import Path
root=Path.cwd()
def edit(name,fn):
 p=root/name;s=p.read_text(encoding='utf-8');v=fn(s);assert v!=s,name
 q=p.with_name(p.name+'.counter-tmp');q.write_text(v,encoding='utf-8',newline='\n');q.replace(p)
def renderer(s):
 block='''    if(surfaceRadiance_&&surfaceRadiance_->statisticsEnabled()){const auto& buffer=surfaceRadiance_->statisticsBuffer(context.currentFrame);
        context.commands->bufferBarrier({buffer.buffer,0,buffer.size,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
            VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});}
'''
 assert s.count(block)==1;s=s.replace(block,'',1);pos=s.index('void CharacterSceneRenderer::recordScene(')
 s=s[:pos]+s[pos:].replace('    if(screenReflectionPrepared()&&reflectionActive_[context.currentFrame]){',block+'    if(screenReflectionPrepared()&&reflectionActive_[context.currentFrame]){',1)
 pos=s.index('    json << ',s.index('void CharacterSceneRenderer::appendCaptureManifestFields('))
 prefix=r'''    const auto statistics=surfaceRadiance_?surfaceRadiance_->statistics():SurfaceRadianceCache::Statistics{};
    json << "  \"surfaceRadianceStatistics\": {\"enabled\": " << (surfaceRadiance_&&surfaceRadiance_->statisticsEnabled()?"true":"false")
         << ", \"bytes\": " << (surfaceRadiance_?surfaceRadiance_->statisticsBytes():0)
         << ", \"frames\": " << statistics.frames << ", \"producerStores\": " << statistics.producerStores
         << ", \"consumerVisits\": " << statistics.consumerVisits << ", \"eligibleRequests\": " << statistics.eligibleRequests
         << ", \"pixelMatches\": " << statistics.pixelMatches << ", \"quadMatches\": " << statistics.quadMatches
         << ", \"overflow\": " << (statistics.overflow?"true":"false") << "},\n";
'''
 return s[:pos]+prefix+s[pos:]
edit('src/scenes/CharacterSceneRenderer.cpp',renderer)
def probe(s):
 s=s.replace('#include "surface_radiance_identity.glsl"','#include "surface_radiance_identity.glsl"\n#include "surface_radiance_statistics.glsl"',1)
 needle='    if(subgroupQuadAll(identity.z!=0xffffffffu&&all(equal(identity,stored)))){'
 s=s.replace(needle,'''#if defined(AZURE_SURFACE_RADIANCE_DIAGNOSTICS)
    azureRadianceCount(1u);azureRadianceCount(2u);
    bool matched=identity.z!=0xffffffffu&&all(equal(identity,stored));bool accepted=subgroupQuadAll(matched);
    if(matched)azureRadianceCount(3u);if(accepted)azureRadianceCount(4u);
    if(accepted){
#else
'''+needle+'\n#endif',1)
 needle='    if(!azureSurfaceRadianceFinite(outputA))identity=uvec4(0xffffffffu);'
 s=s.replace(needle,needle+'\n#if defined(AZURE_SURFACE_RADIANCE_DIAGNOSTICS)\n    if(identity.z!=0xffffffffu)azureRadianceCount(0u);\n#endif',1)
 return s
edit('shaders/surface_radiance_probe.frag',probe)
def gpu(s):
 s=s.replace(' explicit Resources(test::VulkanComputeFixture& h):host(h),rhi(*h.backend){}',' bool diagnostics=false;\n explicit Resources(test::VulkanComputeFixture& h,bool statistics=false):host(h),rhi(*h.backend),diagnostics(statistics){}',1)
 s=s.replace('source=std::make_unique<SurfaceRadianceCache>(rhi,extent,2);','source=std::make_unique<SurfaceRadianceCache>(rhi,extent,2,SurfaceRadianceCache::kMaximumBytes,diagnostics);',1)
 s=s.replace('  setLayout=rhi.createDescriptorSetLayout(bindings);','  if(diagnostics)bindings.push_back({42,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT});\n  setLayout=rhi.createDescriptorSetLayout(bindings);',1)
 s=s.replace('poolDesc.sizes={{VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,4}};pool=', 'poolDesc.sizes={{VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,4}};if(diagnostics)poolDesc.sizes.push_back({VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1});pool=',1)
 s=s.replace('  vertex=rhi.createShaderModule','  if(diagnostics){const auto& counter=source->statisticsBuffer(0);rhi.writeDescriptorBuffer({set,42,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,counter.buffer,counter.size});}\n  const std::string suffix=diagnostics?"_stats":"";\n  vertex=rhi.createShaderModule',1)
 s=s.replace('shaders+"/surface_radiance_probe.frag.spv"','shaders+"/surface_radiance_probe"+suffix+".frag.spv"',1).replace('shaders+"/surface_radiance_consumer.frag.spv"','shaders+"/surface_radiance_consumer"+suffix+".frag.spv"',1)
 needle='   VkClearValue clearDepth{};clearDepth.depthStencil={1,0};'
 s=s.replace(needle,'''   if(diagnostics){const auto& counter=source->statisticsBuffer(0);commands.bufferBarrier({counter.buffer,0,counter.size,
    VK_PIPELINE_STAGE_HOST_BIT|VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
    VK_ACCESS_HOST_WRITE_BIT|VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});}
'''+needle,1)
 s=s.replace('   if(sampled)commands.bindDescriptorSet(layout,set);','   if(sampled||diagnostics)commands.bindDescriptorSet(layout,set);',1)
 s=s.replace('if(vertices)vkCmdDraw(raw,vertices,1,0,instance);commands.endRenderPass();','if(vertices)vkCmdDraw(raw,vertices,1,0,instance);commands.endRenderPass();\n   if(diagnostics)source->recordStatisticsReady(commands,0);',1)
 s=s.replace('host(true,false,false,true,true);','host(true,false,false,true,true,AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS!=0);',1)
 needle=' require(host.allocator.statistics().liveBuffers==0'
 block='''#if AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS
 {Resources r(host,true);r.initialize(argv[1]);Probe p;r.bind(0);r.source->beginStatisticsFrame(0);
  r.draw(0,p,7,3);p.value=.75F;r.draw(2,p,7,3,true);r.source->beginStatisticsFrame(0);
  const auto full=r.source->statistics();const auto pixels=extent.width*extent.height;
  require(full.frames==1&&full.producerStores==pixels&&full.consumerVisits==pixels&&full.eligibleRequests==pixels
   &&full.pixelMatches==pixels&&full.quadMatches==pixels&&!full.overflow,"GPU full-hit statistics are exact");
  p.value=-2.F;r.draw(0,p,7,3);p.value=.75F;r.draw(2,p,7,3,true);r.source->beginStatisticsFrame(0);
  const auto mixed=r.source->statistics();require(mixed.frames==2&&mixed.pixelMatches-full.pixelMatches==pixels/2
   &&mixed.quadMatches==full.quadMatches&&mixed.consumerVisits-full.consumerVisits==pixels,"GPU partial-quad statistics distinguish pixel matches from acceptance");
  auto& counter=r.source->statisticsBuffer(0);std::array<std::uint32_t,6> saturated{UINT32_MAX,0,0,0,0,0};
  std::memcpy(counter.mapped,saturated.data(),24);host.allocator.flush(counter,0,24);p.value=1;r.draw(0,p,7,3);r.source->beginStatisticsFrame(0);
  require(r.source->statistics().overflow,"GPU counter overflow is observable");
 }
#endif
'''
 return s.replace(needle,block+needle,1)
edit('tests/SurfaceRadianceCacheGpuTests.cpp',gpu)
print('Retirement visibility, capture metadata, and exact GPU counter controls completed')
