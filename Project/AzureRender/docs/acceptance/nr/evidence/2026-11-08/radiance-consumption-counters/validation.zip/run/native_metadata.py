from pathlib import Path
import json,sys,os
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from artifact_maintenance import guarded_run
checks=json.loads((out/'checks.json').read_text());assert len(checks)==4 and all(row['exitCode']==0 for row in checks)
verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}
lock=json.loads((out.parent/'20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text());assert all(digest(Path(p))==sha for p,sha in lock.items())
folder=out/'native-metadata';folder.mkdir(exist_ok=True);assert not (folder/'runtime.json').exists()
project=out.parent/'20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
command=[str(build/'AzurePlayer.exe'),'--project',str(project),'--width','2560','--height','1440','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','24','--smoke-frames','32','--gpu-timing-output',str(folder/'gpu.json')]
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','AZURE_CPU_WORK_REPORT']:os.environ.pop(key,None)
for key in ['TEMP','TMP','TMPDIR','SQLITE_TMPDIR']:os.environ[key]=str(out/'tmp')
(folder/'command.json').write_text(json.dumps(command,indent=2));execution=guarded_run(root/'build',out.name,command,300);(folder/'execution.json').write_text(json.dumps(execution,indent=2))
assert execution['status']=='exited' and execution['exitCode']==0,execution
data=json.loads((folder/'gpu.json').read_text());log=(out/'process.log').read_text(errors='replace');(folder/'process.log').write_text(log)
statistics=data['surfaceRadianceStatistics'];assert data['surfaceRadiancePrepared'] and statistics['enabled'] and statistics['frames']>0 and not statistics['overflow'],statistics
assert 0<=statistics['quadMatches']<=statistics['pixelMatches']<=statistics['eligibleRequests']<=statistics['consumerVisits']
requests=statistics['eligibleRequests'];visits=statistics['consumerVisits']
rates=dict(eligibleFraction=requests/visits if visits else None,pixelMatchFraction=statistics['pixelMatches']/requests if requests else None,quadAcceptanceFraction=statistics['quadMatches']/requests if requests else None,matchingFragmentsRejectedByQuad=statistics['pixelMatches']-statistics['quadMatches'])
report=dict(status='measured-consumption',execution=execution,renderedFrames=32,capturedFrames=0,statistics=statistics,rates=rates,cacheBytes=data['surfaceRadianceBytes'],sceneExtent=[data['sceneWidth'],data['sceneHeight']],sourceInputsUnchanged=inputs(root)==before,productsUnchanged=all(digest(Path(p))==sha for p,sha in products.items()),projectInputsUnchanged=all(digest(Path(p))==sha for p,sha in lock.items()),validationTextClean=not any(word in log for word in ['Validation Error:','SYNC-HAZARD','VUID-']),zeroAllocator='Allocator after unload: buffers=0 images=0' in log,scope='Intrusive fragment counters, retired nonempty frame slots, real invocations excluding helpers; no performance timing or unique-pixel claim',formalPerformancePassed=False,overallVisualAcceptance='failed-user-review')
(folder/'results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
assert all(report[key] for key in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationTextClean','zeroAllocator'])
