from pathlib import Path
import json,sys,os,subprocess,time,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import verify
env=os.environ.copy();env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'),TMPDIR=str(out/'tmp'));rows=[]
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
for config in ['release','debug']:
 build=root/('build/ninja-msvc-'+config);assert 'AZURE_ENABLE_SURFACE_RADIANCE_REUSE:BOOL=OFF' in (build/'CMakeCache.txt').read_text()
 verify(root,json.loads((build/'build-provenance.json').read_text()))
 baseline=json.loads((out/(config+'-baseline-shaders.json')).read_text());actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (build/'shaders').glob('*.spv')};assert actual==baseline
 command=[ctest,'--test-dir',str(build),'-R',r'^AzureRender\.(SurfaceRadianceCache|SurfaceRadianceStatistics|DepthPrefillRecording)$','--output-on-failure','--no-tests=error','--output-junit',str(out/(config+'-default.xml'))]
 started=time.monotonic()
 with (out/(config+'-default-checks.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 rows.append(dict(configuration=config,command=command,exitCode=r.returncode,seconds=time.monotonic()-started,retainedExactPrograms=len(actual)));(out/'default-checks.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
 assert r.returncode==0,(out/(config+'-default-checks.log')).read_text(errors='replace')[-3000:]
