from pathlib import Path
import subprocess,json,re,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
assert not subprocess.check_output(['git','diff','--name-only','--cached']).strip()
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
userHash=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest()
assert userHash=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8',userHash
report=json.loads((root/'docs/acceptance/nr/evidence/2026-11-08/radiance-consumption-counters/results.json').read_text(encoding='utf-8'))
sources=list(report['sourceHashes'])
docs=['README.md','CHANGELOG.md','docs/development/artifact-manifest.json','docs/development/surface-radiance-cache.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-06-performance-bottlenecks.md','docs/plans/2026-11-08-radiance-consumption-counters.md','docs/acceptance/nr/radiance-consumption-counters.md','docs/acceptance/nr/evidence/2026-11-08/radiance-consumption-counters/results.json','docs/acceptance/nr/evidence/2026-11-08/radiance-consumption-counters/validation.zip']
paths=list(dict.fromkeys(sources+docs))
for name in docs:
 if not name.endswith('.md'):continue
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',(root/name).read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert ((root/name).parent/target.split('#')[0]).resolve().exists(),(name,target)
for name in ['audit.json','default-checks.json']:assert (out/name).is_file()
subprocess.run(['git','diff','--check'],check=True,stderr=subprocess.DEVNULL)
subprocess.run(['git','add','--',*paths],check=True,stderr=subprocess.DEVNULL)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines()
assert set(staged)=={'Project/AzureRender/'+p for p in paths}
subprocess.run(['git','diff','--cached','--check'],check=True)
(out/'staged-stat.log').write_text(subprocess.check_output(['git','diff','--cached','--stat'],text=True))
title='feat(nr-performance): 增加照明复用消费计数及有界诊断'
subprocess.run(['git','commit','-m',title],check=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
(out/'commit.json').write_text(json.dumps(dict(commit=commit,title=title,files=staged,protectedUserDiffSha256=userHash),ensure_ascii=False,indent=2))
print(commit)
