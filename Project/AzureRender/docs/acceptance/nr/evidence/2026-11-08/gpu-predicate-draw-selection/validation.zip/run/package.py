from pathlib import Path
import json,sys,subprocess,hashlib,zipfile,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify
checks=json.loads((out/'checks.json').read_text());programs=json.loads((out/'programs.json').read_text())
assert len(checks)==4 and all(r['exitCode']==0 for r in checks)
cases=[]
for config in ['release','debug']:
 build=root/('build/ninja-msvc-'+config);verify(root,json.loads((build/'build-provenance.json').read_text()))
 for device in ['nvidia','intel']:
  for c in ET.parse(out/(config+'-'+device+'.xml')).getroot().findall('testcase'):
   assert c.find('failure') is None and c.find('skipped') is None
   output=c.findtext('system-out') or ''
   if c.attrib['name'].endswith('Gpu'):
    assert 'cases=5 commands=655 regions=2 validationErrors=0 liveBuffers=0 liveImages=0' in output
    assert ('NVIDIA' if device=='nvidia' else 'Intel') in output
   cases.append(dict(configuration=config,device=device,name=c.attrib['name'],seconds=c.attrib['time']))
assert len(cases)==6
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
userHash=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest()
assert userHash=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
sources=['CMakeLists.txt','src/render/GpuPredicateDrawSelection.hpp','src/render/GpuPredicateDrawSelection.cpp','shaders/predicate_draw_selection.comp','tests/GpuPredicateDrawSelectionTests.cpp','tests/GpuPredicateDrawSelectionGpuTests.cpp']
members={}
for p in out.iterdir():
 if p.is_file() and p.suffix in {'.py','.json','.log','.xml','.txt'} and 0<p.stat().st_size<2*2**20:members['run/'+p.name]=p
for name in sources:members['source/'+name]=root/name
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/gpu-predicate-draw-selection';evidence.mkdir(parents=True,exist_ok=True);archive=evidence/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert archive.stat().st_size<8*2**20
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='mechanism-validated-scene-integration-pending',sourceBase='a62b206',sourceHashes={name:digest(root/name) for name in sources},checks=checks,cases=cases,programs=programs,gpuFlows=4,casesPerGpuFlow=5,sourceCommandsPerGpuFlow=655,checkedOutputCommands=5240,zeroSynchronizationErrors=True,zeroAllocatorResidue=True,protectedUserDiffSha256=userHash,sceneRendererModified=False,nativeSceneRuns=0,performanceTimingRuns=0,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=archive.stat().st_size,evidenceSha256=digest(archive))
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'docs/development/artifact-manifest.json';d=json.loads(p.read_text(encoding='utf-8'))
d['milestones'].insert(0,dict(path='runs/'+out.name,name='GPU 绘制路径选择',status='MechanismValidatedSceneIntegrationPending',sourceBase='a62b206',evidence='docs/acceptance/nr/gpu-predicate-draw-selection.md',checksPassed=6,gpuFlowsPassed=4,nativeSceneRuns=0,formalPerformancePassed=False))
p.write_text(json.dumps(d,ensure_ascii=False,indent=2).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
p=root/'docs/plans/2026-11-08-radiance-frame-selection.md';s=p.read_text(encoding='utf-8')
for text in ['先验证缺失接口及契约用例的预期失败。','实现容量、别名、字节范围及票据核验。','保持每项命令的五个字段与次序。','核对零谓词、非零谓词及关闭许可。','两个设备各检查 GPU 产生的谓词及真实输出。','同步规则、来源收据与文档一并提交。']:s=s.replace('- [ ] '+text,'- [x] '+text,1)
s+='\n## 命令选择结果\n\n公共选择器通过六项所属 CTest。\n两种配置的四个真实 GPU 流程全部通过。\n原有六百七十三份程序保持原字节。\n同帧资格绘制及轻量消费接入继续执行。\n\n详见[选择器验收](../acceptance/nr/gpu-predicate-draw-selection.md)。\n'
p.write_text(s,encoding='utf-8',newline='\n')
for name,anchor,extra in [('README.md','[资产快照压缩](docs/acceptance/nr/compressed-asset-snapshots.md)','[GPU 绘制选择](docs/acceptance/nr/gpu-predicate-draw-selection.md)通过六项所属检查，同帧资格与轻量照明接入继续实施。\n'),('docs/plans/azure-engine-plan.md','后续性能批次按实际覆盖及附件成本选择。','\n[GPU 绘制选择](../acceptance/nr/gpu-predicate-draw-selection.md)通过六项所属检查。\n当前按[管线选择计划](2026-11-08-radiance-frame-selection.md)接入同帧资格与轻量消费。')]:
 p=root/name;s=p.read_text(encoding='utf-8');assert anchor in s
 s=s.replace(anchor,extra+anchor if name=='README.md' else anchor+extra,1);p.write_text(s,encoding='utf-8',newline='\n')
p=root/'CHANGELOG.md';s=p.read_text(encoding='utf-8');p.write_text(s.replace('# Changelog\n','# Changelog\n\n## GPU 绘制路径选择 2026-11-08\n\n- 新增默认关闭许可的 GPU 双区域间接命令选择器。\n- 帧槽、所属对象和一次性票据具有明确核验。\n- 六项所属检查通过，场景轻量照明接入继续实施。\n- 范围见[选择器验收](docs/acceptance/nr/gpu-predicate-draw-selection.md)。\n',1),encoding='utf-8',newline='\n')
print(json.dumps(dict(status=report['status'],ctests=6,gpuFlows=4,checkedOutputCommands=5240,evidenceBytes=archive.stat().st_size)))
