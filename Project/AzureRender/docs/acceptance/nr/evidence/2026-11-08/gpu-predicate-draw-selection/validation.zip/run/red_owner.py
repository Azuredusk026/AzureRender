from pathlib import Path
import subprocess,sys,os,json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;env=os.environ.copy();env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'),TMPDIR=str(out/'tmp'),VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0')
command=[str(root/'tools/msvc_env.bat'),'cmake','--build',str(root/'build/ninja-msvc-release'),'--target','AzureGpuPredicateDrawSelectionTests','-j','3']
with (out/'red-owner-build.log').open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0
r=subprocess.run([str(root/'build/ninja-msvc-release/AzureGpuPredicateDrawSelectionTests.exe')],env=env,capture_output=True,text=True);(out/'red-owner.log').write_text(r.stdout+r.stderr)
assert r.returncode!=0 and 'Invalid draw selection accepted' in r.stderr
(out/'red-owner.json').write_text(json.dumps(dict(exitCode=r.returncode,expectedCrossOwnerTicketRejectionMissing=True),indent=2));print(r.stderr.strip())
