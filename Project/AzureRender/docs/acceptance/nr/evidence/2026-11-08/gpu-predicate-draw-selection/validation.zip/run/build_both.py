from pathlib import Path
import subprocess,sys
out=Path(__file__).resolve().parent
for config in ['Release','Debug']:
 r=subprocess.run([sys.executable,'-X','utf8',str(out/'build.py'),config]);assert r.returncode==0
