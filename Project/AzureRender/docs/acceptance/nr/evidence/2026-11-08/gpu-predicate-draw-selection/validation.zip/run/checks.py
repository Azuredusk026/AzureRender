from pathlib import Path
import json,os,sys,subprocess,hashlib,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import verify
env=os.environ.copy();env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'),TMPDIR=str(out/'tmp'),SQLITE_TMPDIR=str(out/'tmp'))
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
rows=[];programs=[]
for config in ['release','debug']:
 build=root/('build/ninja-msvc-'+config);proof=json.loads((build/'build-provenance.json').read_text());verify(root,proof)
 entry=json.loads((out/('entry-'+config+'-provenance.json')).read_text())
 expected={Path(p).name:sha for p,sha in entry['products'].items() if p.endswith('.spv') and 'shaders' in Path(p).parts}
 actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (build/'shaders').glob('*.spv')}
 assert len(expected)==673 and all(actual[n]==sha for n,sha in expected.items())
 assert set(actual)-set(expected)=={'predicate_draw_selection.comp.spv'}
 programs.append(dict(configuration=config,retainedExactPrograms=673,actualPrograms=674,sourceVerified=True))
 for label,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  env['VK_LOADER_DRIVERS_SELECT']=driver
  pattern=r'^AzureRender\.GpuPredicateDrawSelection(Gpu)?$' if label=='nvidia' else r'^AzureRender\.GpuPredicateDrawSelectionGpu$'
  command=[ctest,'--test-dir',str(build),'-R',pattern,'--output-on-failure','--no-tests=error','--output-junit',str(out/(config+'-'+label+'.xml'))]
  started=time.monotonic()
  with (out/(config+'-'+label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  rows.append(dict(configuration=config,device=label,command=command,exitCode=r.returncode,seconds=time.monotonic()-started))
  (out/'checks.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
  if r.returncode:print((out/(config+'-'+label+'.log')).read_text(errors='replace')[-5000:]);raise SystemExit(r.returncode)
(out/'programs.json').write_text(json.dumps(programs,indent=2))
