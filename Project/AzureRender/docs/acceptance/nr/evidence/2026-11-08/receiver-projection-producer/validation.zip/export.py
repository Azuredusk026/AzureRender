import renderdoc as rd
from pathlib import Path
import json,traceback,os,hashlib,struct
root=Path(r'D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261108-080203-receiver-projection-producer-222952'
source=root/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc'
report=dict(status='running',source=str(source));cap=rd.OpenCaptureFile();controller=None;code=1
(out/'export-result.json').write_text(json.dumps(report,indent=2))
try:
    assert cap.OpenFile(str(source),'',None)==rd.ResultCode.Succeeded
    result,controller=cap.OpenCapture(rd.ReplayOptions(),None);assert result==rd.ResultCode.Succeeded
    actions={}
    def walk(items):
        for action in items:actions[action.eventId]=action;walk(action.children)
    walk(controller.GetRootActions());controller.SetFrameEvent(699,True)
    pipeline=controller.GetPipelineState();reflection=pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
    target=next(used.descriptor.resource for used in pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel) if reflection.readOnlyResources[used.access.index].fixedBindNumber==0)
    report['depthResource']=str(target);usage=controller.GetUsage(target)
    report['usage']=[dict(event=u.eventId,usage=str(u.usage)) for u in usage]
    writers=[u.eventId for u in usage if u.eventId<699 and u.usage==rd.ResourceUsage.DepthStencilTarget]
    if not writers:
        colors=[u.eventId for u in usage if u.eventId<699 and u.usage==rd.ResourceUsage.ColorTarget]
        if colors:
            producer=max(colors);controller.SetFrameEvent(producer,True);pipeline=controller.GetPipelineState();pixel=pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
            (out/('depth-pass-'+str(producer)+'.asm')).write_text(controller.DisassembleShader(pipeline.GetGraphicsPipelineObject(),pixel,''),encoding='utf-8')
            report['depthColorProducer']=producer;report['depthPassInputs']=[];textures={str(t.resourceId):t for t in controller.GetTextures()}
            for used in pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel):
                resource=used.descriptor.resource;texture=textures.get(str(resource));history=controller.GetUsage(resource)
                candidates=[u.eventId for u in history if u.eventId<producer and u.usage==rd.ResourceUsage.DepthStencilTarget]
                report['depthPassInputs'].append(dict(slot=pixel.readOnlyResources[used.access.index].fixedBindNumber,resource=str(resource),format=texture.format.Name() if texture else None,width=texture.width if texture else None,height=texture.height if texture else None,depthWriters=candidates))
                if candidates and texture and texture.width==2560 and texture.height==1440:writers=candidates;report['depthRasterResource']=str(resource)
            for i,block in enumerate(pixel.constantBlocks):
                if not block.bufferBacked:continue
                descriptor=pipeline.GetConstantBlock(rd.ShaderStage.Pixel,i,0).descriptor
                if descriptor.resource and 0<descriptor.byteSize<=65536:(out/('depth-pass-'+str(producer)+'-cb'+str(block.fixedBindNumber)+'.bin')).write_bytes(bytes(controller.GetBufferData(descriptor.resource,descriptor.byteOffset,descriptor.byteSize)))
    if not writers:
        copies=[u.eventId for u in usage if u.eventId<699 and u.usage in [rd.ResourceUsage.CopyDst,rd.ResourceUsage.ResolveDst]]
        assert copies,'No depth writer or source copy located'
        copy=actions[max(copies)];report['copyEvent']=copy.eventId;report['copiedFrom']=str(copy.copySource)
        writers=[u.eventId for u in controller.GetUsage(copy.copySource) if u.eventId<copy.eventId and u.usage==rd.ResourceUsage.DepthStencilTarget]
    assert writers
    report['writers']=[dict(event=e,indices=actions[e].numIndices) for e in writers]
    for item in report['writers']:
        controller.SetFrameEvent(item['event'],True);state=controller.GetD3D11PipelineState();depth=state.outputMerger.depthStencilState;raster=state.rasterizer.state
        item['depthState']={name:str(getattr(depth,name)) for name in dir(depth) if name.startswith('depth') and not callable(getattr(depth,name))}
        item['rasterState']={name:str(getattr(raster,name)) for name in ['depthBias','slopeScaledDepthBias','depthBiasClamp'] if hasattr(raster,name)}
    matching=[e for e in writers if actions[e].numIndices==43044]
    selected=matching if matching else [writers[-1]]
    if writers[-1] not in selected:selected.append(writers[-1])
    report['exports']=[]
    queries=list(struct.iter_unpack('<4f',(root/'build/runs/20261108-041637-object-receiver-origin-7a2735/region-queries.bin').read_bytes()))
    for event in selected:
        controller.SetFrameEvent(event,True);pipeline=controller.GetPipelineState();vertex=pipeline.GetShaderReflection(rd.ShaderStage.Vertex);assert vertex
        text=controller.DisassembleShader(pipeline.GetGraphicsPipelineObject(),vertex,'')
        (out/('writer-'+str(event)+'.asm')).write_text(text,encoding='utf-8')
        item=dict(event=event,indices=actions[event].numIndices,vertexShader=str(pipeline.GetShader(rd.ShaderStage.Vertex)),buffers=[])
        rasterResource=textures[report['depthRasterResource']].resourceId;rawDepth=bytes(controller.GetTextureData(rasterResource,rd.Subresource()));stride=len(rawDepth)//(2560*1440)
        assert len(rawDepth)==2560*1440*stride and stride>=4
        for mode in ['nativeRows','imageRows']:
            depth=bytearray()
            for x,y,z,objectId in queries:
                row=int(y) if mode=='nativeRows' else 1439-int(y);offset=(row*2560+int(x))*stride;depth.extend(rawDepth[offset:offset+4])
            (out/('writer-'+str(event)+'-'+mode+'-depths.bin')).write_bytes(depth)
        item['depthPixelStride']=stride
        for i,block in enumerate(vertex.constantBlocks):
            if not block.bufferBacked:continue
            descriptor=pipeline.GetConstantBlock(rd.ShaderStage.Vertex,i,0).descriptor
            if not descriptor.resource or not 0<descriptor.byteSize<=65536:continue
            raw=bytes(controller.GetBufferData(descriptor.resource,descriptor.byteOffset,descriptor.byteSize));name='writer-'+str(event)+'-cb'+str(block.fixedBindNumber)+'.bin';(out/name).write_bytes(raw)
            item['buffers'].append(dict(slot=block.fixedBindNumber,name=block.name,bytes=len(raw),file=name,sha256=hashlib.sha256(raw).hexdigest(),variableCount=len(block.variables),variables=[dict(name=v.name,offset=v.byteOffset) for v in block.variables[:96]] if block.fixedBindNumber==0 else []))
        report['exports'].append(item)
    report['status']='exported';code=0
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
    if controller:controller.Shutdown()
    cap.Shutdown();(out/'export-result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
os._exit(code)
