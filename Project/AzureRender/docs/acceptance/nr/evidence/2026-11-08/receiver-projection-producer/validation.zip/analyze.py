from pathlib import Path
import json,numpy as np,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;model=out.parent/'20261108-041637-object-receiver-origin-7a2735';linear=out.parent/'20261108-065642-receiver-linear-depth-ecc3b4'
c0=np.fromfile(out/'writer-440-cb0.bin',dtype='<f4').reshape(-1,4);c1=np.fromfile(out/'writer-440-cb1.bin',dtype='<f4').reshape(-1,4)
queries=np.fromfile(model/'region-queries.bin',dtype='<f4').reshape(-1,4);depth=np.fromfile(linear/'linear-depths.bin',dtype='<f4').astype('f8')
native=(float(c0[11,2])/depth-float(c0[10,2])).astype('<f4');error=native.astype('f8')-queries[:,2]
report=dict(pixels=len(queries),projectionZCoefficient=float(c0[10,2]),projectionZTranslation=float(c0[11,2]),cameraRelativeOrigin=c0[44].tolist(),jitter=c1[19].tolist(),depthBranchControl=c1[4].tolist(),exactDepthPixels=int((native==queries[:,2]).sum()),depthAbsErrorMedian=float(np.median(abs(error))),depthAbsErrorP95=float(np.quantile(abs(error),.95)),depthAbsErrorMaximum=float(abs(error).max()),producerCameraMatchesReceiver=(out/'writer-440-cb0.bin').read_bytes()==(out.parent/'20261027-022702-object-visibility-depth-reconstruction-c7312f/producer-cb0.bin').read_bytes())
queries[:,2]=native;queries.tofile(out/'producer-remapped-queries.bin');(out/'projection-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
raw=json.loads((out/'export-result.json').read_text())
for item in raw['exports']:
 for block in item['buffers']:
  block['variableCount']=len(block['variables']);block['variables']=block['variables'][:96] if block['slot']==0 else []
(out/'export-summary.json').write_text(json.dumps(raw,indent=2))
