from pathlib import Path
import json,hashlib,sys,subprocess,zipfile,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
baseline=json.loads((out/'export-baseline.json').read_text());execution=json.loads((out/'export-execution.json').read_text());assert execution['exitCode']==0 and execution['sourceUnchanged'] and inputs(root)==baseline['sourceInputs']
gpu=json.loads((out/'base-projection-result.json').read_text());assert gpu['pixels']==17017 and gpu['withinOnePixels']==16817 and gpu['maximumVisibilityByteError']==39 and gpu['validationErrors']==0 and gpu['zeroAllocator']
analysis=json.loads((out/'base-projection-analysis.json').read_text());assert all(v['exactNativePixels']==17017 for v in analysis['nativeDepthStages'].values())
proof=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,sha256=digest(p)))
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/receiver-projection-producer';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.json','.log','.bin','.spv','.asm'] and p.stat().st_size<2*2**20}
model=out.parent/'20261108-041637-object-receiver-origin-7a2735';linear=out.parent/'20261108-065642-receiver-linear-depth-ecc3b4'
for name in ['region-queries.bin','region-expected.bin','receiver.cpp','gpu-preparation.json']:members['borrowed-model/'+name]=model/name
for name in ['linear-depths.bin','current-camera.bin']:members['borrowed-linear-depth/'+name]=linear/name
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='receiver-producer-depth-precision-pending',sourceBase='d0778a4',captureDate='2026-10-22',captureSha256=baseline['sourceSha256'],resourceBindings=json.loads((out/'export-result.json').read_text()),exportExecution=execution,baseProjection=analysis,mappedGpuVisibility=gpu,productionProvenance=proof,userDiffSha256=protected,candidateAdopted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=n,bytes=p.stat().st_size,sha256=digest(p)) for n,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest=root/'docs/development/artifact-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'));data['milestones'].insert(0,dict(path='runs/'+out.name,name='接收深度生产投影核验',status='ReceiverProducerDepthPrecisionPending',sourceBase='d0778a4',evidence='docs/acceptance/nr/receiver-projection-producer.md',mappedVisibilityOverOneByte=200,candidateAdopted=False,formalPerformancePassed=False));manifest.write_text(json.dumps(data,indent=2,ensure_ascii=False).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md']:
 p=root/name;text=p.read_text(encoding='utf-8');needle='[线性深度核对]';start=text.index(needle);end=text.index('\n',start)
 line='[生产投影核对]('+('docs/acceptance/nr/' if name=='README.md' else '../acceptance/nr/')+'receiver-projection-producer.md)定位原生深度写入链，完整区域仍有 200 处超差。\n'
 p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-receiver-projection-producer.md','docs/acceptance/nr/receiver-projection-producer.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],evidenceBytes=package.stat().st_size,sourceUnchanged=True,userDiffPreserved=True)))
