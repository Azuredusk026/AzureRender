Shader hash 2525faee-8b735cab-97558aca-15d5921a

ps_5_0
      dcl_globalFlags refactoringAllowed
      dcl_constantbuffer cb0[3], immediateIndexed
      dcl_sampler s0, mode_default
      dcl_resource_texture2d (float,float,float,float) t0
      dcl_input_ps linear v1.xy
      dcl_output o0.xyzw
   0: sample_l(texture2d)(float,float,float,float) o0.xyzw, v1.xyxx, t0.xyzw, s0, cb0[2].x
   1: ret
