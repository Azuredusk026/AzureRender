Shader hash a9d19b38-8f1febdc-c6b7952f-b6649b75

vs_5_0
      dcl_globalFlags refactoringAllowed
      dcl_constantbuffer cb0[82], immediateIndexed
      dcl_constantbuffer cb1[20], immediateIndexed
      dcl_constantbuffer cb2[4091], dynamicIndexed
      dcl_input v0.xyz
      dcl_input v1.xyzw
      dcl_input v2.xy
      dcl_input v3.xy
      dcl_input v4.xyz
      dcl_input_sgv v5.x, instanceid
      dcl_output_siv o0.xyzw, position
      dcl_output o1.xy
      dcl_output o1.zw
      dcl_output o2.xyzw
      dcl_output o3.xyz
      dcl_output o4.xyz
      dcl_output o5.x
      dcl_temps 3
   0: ishl r0.x, v5.x, l(4)
   1: mul r0.yzw, v0.yyyy, cb2[r0.x + 1].xxyz
   2: mad r0.yzw, cb2[r0.x + 0].xxyz, v0.xxxx, r0.yyzw
   3: mad r0.yzw, cb2[r0.x + 2].xxyz, v0.zzzz, r0.yyzw
   4: add r1.xyz, -cb0[44].xyzx, cb2[r0.x + 3].xyzx
   5: add r0.yzw, r0.yyzw, r1.xxyz
   6: mul r1.xyzw, r0.zzzz, cb0[33].xyzw
   7: mad r1.xyzw, cb0[32].xyzw, r0.yyyy, r1.xyzw
   8: mad r1.xyzw, cb0[34].xyzw, r0.wwww, r1.xyzw
   9: add r1.xyzw, r1.xyzw, cb0[35].xyzw
  10: mul r2.xy, r1.wwww, cb1[19].zwzz
  11: mad o0.xy, -r2.xyxx, l(2.000000, -2.000000, 0.000000, 0.000000), r1.xyxx
  12: mov o0.zw, r1.zzzw
  13: mov o3.xyz, r1.xywx
  14: mov o1.xy, v2.xyxx
  15: mov o1.zw, v3.xxxy
  16: mov o2.xyzw, v1.xyzw
  17: lt r1.xy, cb2[r0.x + 10].xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
  18: movc r1.xzw, r1.xxxx, v0.xxyz, v4.xxyz
  19: mul r2.xyz, r1.zzzz, cb2[r0.x + 7].xyzx
  20: mad r2.xyz, cb2[r0.x + 6].xyzx, r1.xxxx, r2.xyzx
  21: mad r1.xzw, cb2[r0.x + 8].xxyz, r1.wwww, r2.xxyz
  22: add r2.xyz, -cb0[81].xyzx, cb2[r0.x + 9].xyzx
  23: add r1.xzw, r1.xxzw, r2.xxyz
  24: add r2.xyz, cb0[44].xyzx, -cb0[81].xyzx
  25: add r0.xyz, r0.yzwy, r2.xyzx
  26: movc r0.xyz, r1.yyyy, r0.xyzx, r1.xzwx
  27: mul r1.xyz, r0.yyyy, cb0[58].xywx
  28: mad r0.xyw, cb0[57].xyxw, r0.xxxx, r1.xyxz
  29: mad r0.xyz, cb0[59].xywx, r0.zzzz, r0.xywx
  30: add o4.xyz, r0.xyzx, cb0[60].xywx
  31: mov o5.x, v5.x
  32: ret
