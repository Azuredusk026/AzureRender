from pathlib import Path
import json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
driver=(out.parent/'20261108-061129-receiver-device-depth-357a94/run_export.py').read_text()
driver=driver.replace("source=root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-current-gpu_frame2.rdc'","source=root/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc'")
(out/'run_export.py').write_text(driver)
state=root/'build/maintenance/storage-work-priority.json';state.write_text(json.dumps(dict(activeTask='receiver-projection-producer',status='source-attribution',performanceTask=str(out.relative_to(root)),storageCommit='d0778a4',projectDataVolume='D:',maintenanceUnit='day'),indent=2)+'\n')
