from pathlib import Path
import json,numpy as np,os,subprocess,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;model=out.parent/'20261108-041637-object-receiver-origin-7a2735';linear=out.parent/'20261108-065642-receiver-linear-depth-ecc3b4'
nativeCB=np.fromfile(out/'writer-422-cb0.bin',dtype='<f4').reshape(-1,4).astype('f8');nativeP=nativeCB[32:36].T
camera=np.fromfile(linear/'current-camera.bin',dtype='<f4').astype('f8');currentInverse=np.linalg.inv(camera[112:128].reshape(4,4).T)
queries=np.fromfile(model/'region-queries.bin',dtype='<f4').reshape(-1,4);depth=np.fromfile(linear/'linear-depths.bin',dtype='<f4').astype('f8')
x=queries[:,0].astype('f8');imageY=1439-queries[:,1].astype('f8')
clip=np.column_stack([2*(x+.5)/2560-1,2*(imageY+.5)/1440-1,np.zeros(len(x)),np.ones(len(x))]);h=clip@currentInverse.T
ray=h[:,:3]/h[:,3,None]-camera[:3];viewZ=ray@camera[4:7]
world=camera[:3]+ray*(depth/viewZ)[:,None]
origin=np.array([-300,300,-300]);nativeWorld=world*np.array([-1,1,1])+origin
relative=nativeWorld-nativeCB[44,:3];nativeClip=np.column_stack([relative,np.ones(len(x))])@nativeP.T
mapped=(nativeClip[:,2]/nativeClip[:,3]).astype('<f4');error=mapped.astype('f8')-queries[:,2]
report=dict(pixels=len(x),writerEvent=422,nativeProjection=nativeP.tolist(),nativeCameraOrigin=nativeCB[44].tolist(),currentDepthRayOffset=[.5,.5],exactNativeDepthPixels=int((mapped==queries[:,2]).sum()),depthAbsErrorMedian=float(np.median(abs(error))),depthAbsErrorP95=float(np.quantile(abs(error),.95)),depthAbsErrorMaximum=float(abs(error).max()))
report['nativeDepthStages']={}
for event in [422,440,478]:
 a=np.fromfile(out/('writer-'+str(event)+'-nativeRows-depths.bin'),dtype='<f4');report['nativeDepthStages'][str(event)]=dict(exactNativePixels=int((a==queries[:,2]).sum()))
(out/'base-projection-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
queries[:,2]=mapped;queries.tofile(out/'base-remapped-queries.bin')
config=json.loads((out.parent/'20261108-061129-receiver-device-depth-357a94/gpu-inputs.json').read_text());config.update(queryBinary=str(out/'base-remapped-queries.bin'),resultPrefix='base-projection-')
(out/'gpu-inputs.json').write_text(json.dumps(config,indent=2));(out/'receiver.spv').write_bytes((model/'receiver.spv').read_bytes())
env=os.environ.copy();env.update(TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'),VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
command=[str(model/'receiver.exe'),str(out)];start=time.monotonic()
with (out/'gpu.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
(out/'gpu-execution.json').write_text(json.dumps(dict(command=command,exitCode=r.returncode,seconds=time.monotonic()-start),indent=2))
gpu=json.loads((out/'base-projection-result.json').read_text());print(json.dumps({k:v for k,v in gpu.items() if k!='rows'}),flush=True)
assert gpu['validationErrors']==0 and gpu['zeroAllocator'] and r.returncode in [0,1]
