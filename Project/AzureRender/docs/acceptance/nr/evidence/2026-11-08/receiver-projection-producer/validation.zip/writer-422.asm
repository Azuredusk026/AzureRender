Shader hash 76f1fad3-9a474e31-01cedbcc-ba2d1ffa

vs_5_0
      dcl_globalFlags refactoringAllowed
      dcl_constantbuffer cb0[82], immediateIndexed
      dcl_constantbuffer cb1[20], immediateIndexed
      dcl_constantbuffer cb2[4091], dynamicIndexed
      dcl_constantbuffer cb3[11], immediateIndexed
      dcl_resource_structured t0, 16
      dcl_input v0.xyz
      dcl_input v1.xy
      dcl_input v2.xyz
      dcl_input v3.xyzw
      dcl_input v4.xyz
      dcl_input v5.xyzw
      dcl_input v6.xyzw
      dcl_input_sgv v7.x, instanceid
      dcl_output_siv o0.xyzw, position
      dcl_output o1.xy
      dcl_output o2.xyz
      dcl_output o3.xyz
      dcl_output o4.xyzw
      dcl_output o5.xyz
      dcl_output o6.xyz
      dcl_output o7.x
      dcl_temps 13
   0: and r0.x, v2.x, l(2.000000)
   1: ult r0.y, l(0), r0.x
   2: if_nz r0.x
   3:   and r0.x, v2.x, l(1023)
   4:   ubfe r0.zw, l(0, 0, 10, 10), l(0, 0, 10, 20), v2.xxxx
   5:   utof r0.xzw, r0.xxzw
   6:   ge r1.x, r0.x, l(512.000000)
   7:   add r1.y, r0.x, l(-1024.000000)
   8:   movc r1.x, r1.x, r1.y, r0.x
   9:   ge r2.xy, r0.zwzz, l(512.000000, 512.000000, 0.000000, 0.000000)
  10:   add r2.zw, r0.zzzw, l(0.000000, 0.000000, -1024.000000, -1024.000000)
  11:   movc r1.yz, r2.xxyx, r2.zzwz, r0.zzwz
  12:   mul r0.xzw, r1.xxyz, l(0.001957, 0.000000, 0.001957, 0.001957)
  13:   add r2.xyz, -abs(r0.xzxx), l(1.000000, 1.000000, 1.000000, 0.000000)
  14:   add r3.z, -abs(r0.z), r2.x
  15:   lt r1.w, r3.z, l(0)
  16:   ge r1.xy, r1.xyxx, l(0, 0, 0, 0)
  17:   movc r1.xy, r1.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
  18:   mul r1.xy, r1.xyxx, r2.yzyy
  19:   movc r3.xy, r1.wwww, r1.xyxx, r0.xzxx
  20:   dp3 r0.x, r3.xyzx, r3.xyzx
  21:   rsq r0.x, r0.x
  22:   mul r1.xyw, r0.xxxx, r3.xyxz
  23:   mad r2.xyz, r3.yzxy, r0.xxxx, -r1.wxyw
  24:   dp3 r0.x, r2.xyzx, r1.xywx
  25:   add r2.xyz, -r0.xxxx, r2.xyzx
  26:   dp3 r0.x, r2.xyzx, r2.xyzx
  27:   rsq r0.x, r0.x
  28:   mul r2.xyz, r0.xxxx, r2.xyzx
  29:   lt r0.x, r1.z, l(0)
  30:   movc r0.x, r0.x, l(-1.000000), l(1.000000)
  31:   dp2 r0.z, r0.wwww, r0.xxxx
  32:   add r3.x, -r0.z, l(1.000000)
  33:   add r0.z, -abs(r3.x), l(1.000000)
  34:   mul r3.y, r0.z, r0.x
  35:   dp2 r0.x, r3.xyxx, r3.xyxx
  36:   rsq r0.x, r0.x
  37:   mul r0.xz, r0.xxxx, r3.xxyx
  38:   mul r3.xyz, r1.wxyw, r2.yzxy
  39:   mad r3.xyz, r1.ywxy, r2.zxyz, -r3.xyzx
  40:   dp3 r0.w, r3.xyzx, r3.xyzx
  41:   rsq r0.w, r0.w
  42:   mul r3.xyz, r0.wwww, r3.xyzx
  43:   mul r3.xyz, r0.zzzz, r3.xyzx
  44:   mad r0.xzw, r0.xxxx, r2.xxyz, r3.xxyz
  45:   ushr r1.z, v2.x, l(31)
  46:   utof r1.z, r1.z
  47:   mad r1.z, r1.z, l(2.000000), l(-1.000000)
  48: else
  49:   mov r0.xzw, l(0, 0, 0, 0)
  50:   mov r1.z, l(0)
  51:   mov r1.xyw, v2.xyxz
  52: endif
  53: movc r0.xzw, r0.yyyy, r0.xxzw, v3.xxyz
  54: movc o4.w, r0.y, r1.z, v3.w
  55: ishl r0.y, v7.x, l(4)
  56: and r2.xy, l(32, -49, 0, 0), cb2[r0.y + 4].wwww
  57: ieq r2.xz, r2.xxyx, l(0, 0, 0, 0)
  58: or r1.z, r2.z, r2.x
  59: if_z r1.z
  60:   iadd r2.xz, l(3, 0, 3, 0), cb2[r0.y + 5].xxyx
  61:   imad r3.xyzw, v6.xyzw, l(3, 3, 3, 3), r2.xxxx
  62:   imad r4.xyzw, v6.xyzw, l(3, 3, 3, 3), r2.zzzz
  63:   iadd r2.xz, r3.xxxx, l(1, 0, 2, 0)
  64:   iadd r5.xy, r4.xxxx, l(1, 2, 0, 0)
  65:   uge r2.yw, r2.yyyy, l(0, 2, 0, 4)
  66:   if_nz r2.y
  67:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r6.xyzw, r5.y, l(0), t0.xyzw
  68:     iadd r5.zw, r4.yyyy, l(0, 0, 2, 1)
  69:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r5.z, l(0), t0.xyzw
  70:     mul r7.xyzw, r7.xyzw, v5.yyyy
  71:     mad r6.xyzw, r6.xyzw, v5.xxxx, r7.xyzw
  72:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r5.x, l(0), t0.xyzw
  73:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r8.xyzw, r5.w, l(0), t0.xyzw
  74:     mul r8.xyzw, r8.xyzw, v5.yyyy
  75:     mad r7.xyzw, r7.xyzw, v5.xxxx, r8.xyzw
  76:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r8.xyzw, r4.x, l(0), t0.xyzw
  77:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r9.xyzw, r4.y, l(0), t0.xyzw
  78:     mul r9.xyzw, r9.xyzw, v5.yyyy
  79:     mad r8.xyzw, r8.xyzw, v5.xxxx, r9.xyzw
  80:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r9.xyzw, r2.z, l(0), t0.xyzw
  81:     iadd r5.zw, r3.yyyy, l(0, 0, 2, 1)
  82:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r5.z, l(0), t0.xyzw
  83:     mul r10.xyzw, r10.xyzw, v5.yyyy
  84:     mad r9.xyzw, r9.xyzw, v5.xxxx, r10.xyzw
  85:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r2.x, l(0), t0.xyzw
  86:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r11.xyzw, r5.w, l(0), t0.xyzw
  87:     mul r11.xyzw, r11.xyzw, v5.yyyy
  88:     mad r10.xyzw, r10.xyzw, v5.xxxx, r11.xyzw
  89:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r11.xyzw, r3.x, l(0), t0.xyzw
  90:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r12.xyzw, r3.y, l(0), t0.xyzw
  91:     mul r12.xyzw, r12.xyzw, v5.yyyy
  92:     mad r11.xyzw, r11.xyzw, v5.xxxx, r12.xyzw
  93:   else
  94:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r6.xyzw, r5.y, l(0), t0.xyzw
  95:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r5.x, l(0), t0.xyzw
  96:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r8.xyzw, r4.x, l(0), t0.xyzw
  97:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r9.xyzw, r2.z, l(0), t0.xyzw
  98:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r2.x, l(0), t0.xyzw
  99:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r11.xyzw, r3.x, l(0), t0.xyzw
 100:   endif
 101:   if_nz r2.w
 102:     iadd r2.xyzw, r4.zwzw, l(2, 2, 1, 1)
 103:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r5.xyzw, r2.x, l(0), t0.xyzw
 104:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r12.xyzw, r2.y, l(0), t0.xyzw
 105:     mul r12.xyzw, r12.xyzw, v5.wwww
 106:     mad r5.xyzw, r5.xyzw, v5.zzzz, r12.xyzw
 107:     add r6.xyzw, r5.xyzw, r6.xyzw
 108:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r5.xyzw, r2.z, l(0), t0.xyzw
 109:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r2.xyzw, r2.w, l(0), t0.xyzw
 110:     mul r2.xyzw, r2.xyzw, v5.wwww
 111:     mad r2.xyzw, r5.xyzw, v5.zzzz, r2.xyzw
 112:     add r7.xyzw, r2.xyzw, r7.xyzw
 113:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r2.xyzw, r4.z, l(0), t0.xyzw
 114:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.xyzw, r4.w, l(0), t0.xyzw
 115:     mul r4.xyzw, r4.xyzw, v5.wwww
 116:     mad r2.xyzw, r2.xyzw, v5.zzzz, r4.xyzw
 117:     add r8.xyzw, r2.xyzw, r8.xyzw
 118:     iadd r2.xyzw, r3.zwzw, l(2, 2, 1, 1)
 119:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.xyzw, r2.x, l(0), t0.xyzw
 120:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r5.xyzw, r2.y, l(0), t0.xyzw
 121:     mul r5.xyzw, r5.xyzw, v5.wwww
 122:     mad r4.xyzw, r4.xyzw, v5.zzzz, r5.xyzw
 123:     add r9.xyzw, r4.xyzw, r9.xyzw
 124:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.xyzw, r2.z, l(0), t0.xyzw
 125:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r2.xyzw, r2.w, l(0), t0.xyzw
 126:     mul r2.xyzw, r2.xyzw, v5.wwww
 127:     mad r2.xyzw, r4.xyzw, v5.zzzz, r2.xyzw
 128:     add r10.xyzw, r2.xyzw, r10.xyzw
 129:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r2.xyzw, r3.z, l(0), t0.xyzw
 130:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r3.xyzw, r3.w, l(0), t0.xyzw
 131:     mul r3.xyzw, r3.xyzw, v5.wwww
 132:     mad r2.xyzw, r2.xyzw, v5.zzzz, r3.xyzw
 133:     add r11.xyzw, r2.xyzw, r11.xyzw
 134:   endif
 135:   dp3 r1.z, r11.xyzx, r0.xzwx
 136:   dp3 r2.x, r10.xyzx, r0.xzwx
 137:   dp3 r0.w, r9.xyzx, r0.xzwx
 138:   dp3 r2.y, r11.xyzx, r1.xywx
 139:   dp3 r2.z, r10.xyzx, r1.xywx
 140:   dp3 r1.w, r9.xyzx, r1.xywx
 141:   mov r3.xyz, v0.xyzx
 142:   mov r3.w, l(1.000000)
 143:   dp4 r2.w, r11.xyzw, r3.xyzw
 144:   dp4 r4.x, r10.xyzw, r3.xyzw
 145:   dp4 r4.y, r9.xyzw, r3.xyzw
 146:   dp4 r5.x, r8.xyzw, r3.xyzw
 147:   dp4 r5.y, r7.xyzw, r3.xyzw
 148:   dp4 r5.z, r6.xyzw, r3.xyzw
 149:   mov r0.x, r1.z
 150:   mov r0.z, r2.x
 151:   mov r1.xy, r2.yzyy
 152: else
 153:   mov r5.xyz, v4.xyzx
 154:   mov r2.w, v0.x
 155:   mov r4.xy, v0.yzyy
 156: endif
 157: mul r2.xyz, r4.xxxx, cb2[r0.y + 1].xyzx
 158: mad r2.xyz, cb2[r0.y + 0].xyzx, r2.wwww, r2.xyzx
 159: mad r2.xyz, cb2[r0.y + 2].xyzx, r4.yyyy, r2.xyzx
 160: add r3.xyz, -cb0[44].xyzx, cb2[r0.y + 3].xyzx
 161: add r2.xyz, r2.xyzx, r3.xyzx
 162: mul r3.xyzw, r2.yyyy, cb0[33].xyzw
 163: mad r3.xyzw, cb0[32].xyzw, r2.xxxx, r3.xyzw
 164: mad r3.xyzw, cb0[34].xyzw, r2.zzzz, r3.xyzw
 165: add r3.xyzw, r3.xyzw, cb0[35].xyzw
 166: mul r4.zw, r3.wwww, cb1[19].zzzw
 167: mad o0.xy, -r4.zwzz, l(2.000000, -2.000000, 0.000000, 0.000000), r3.xyxx
 168: mul r6.xyz, r1.yyyy, cb2[r0.y + 1].xyzx
 169: mad r1.xyz, cb2[r0.y + 0].xyzx, r1.xxxx, r6.xyzx
 170: mad r1.xyz, cb2[r0.y + 2].xyzx, r1.wwww, r1.xyzx
 171: mul r6.xyz, r0.zzzz, cb2[r0.y + 1].xyzx
 172: mad r6.xyz, cb2[r0.y + 0].xyzx, r0.xxxx, r6.xyzx
 173: mad r0.xzw, cb2[r0.y + 2].xxyz, r0.wwww, r6.xxyz
 174: lt r1.w, cb2[r0.y + 10].x, l(1.000000)
 175: mad o1.xy, v1.xyxx, cb3[10].xyxx, cb3[10].zwzz
 176: dp3 r4.z, r1.xyzx, r1.xyzx
 177: max r4.z, r4.z, l(0.000000)
 178: rsq r4.z, r4.z
 179: mul o3.xyz, r1.xyzx, r4.zzzz
 180: dp3 r1.x, r0.xzwx, r0.xzwx
 181: max r1.x, r1.x, l(0.000000)
 182: rsq r1.x, r1.x
 183: mul o4.xyz, r0.xzwx, r1.xxxx
 184: movc r0.x, r1.w, r2.w, r5.x
 185: movc r0.zw, r1.wwww, r4.xxxy, r5.yyyz
 186: mul r1.xyz, r0.zzzz, cb2[r0.y + 7].xyzx
 187: mad r1.xyz, cb2[r0.y + 6].xyzx, r0.xxxx, r1.xyzx
 188: mad r0.xzw, cb2[r0.y + 8].xxyz, r0.wwww, r1.xxyz
 189: add r1.xyz, -cb0[81].xyzx, cb2[r0.y + 9].xyzx
 190: add r0.xyz, r0.xzwx, r1.xyzx
 191: mul r1.xyz, r0.yyyy, cb0[58].xywx
 192: mad r0.xyw, cb0[57].xyxw, r0.xxxx, r1.xyxz
 193: mad r0.xyz, cb0[59].xywx, r0.zzzz, r0.xywx
 194: add o6.xyz, r0.xyzx, cb0[60].xywx
 195: mov o0.zw, r3.zzzw
 196: mov o2.xyz, r2.xyzx
 197: mov o5.xyz, r3.xywx
 198: mov o7.x, v7.x
 199: ret
