from pathlib import Path
out=Path(__file__).resolve().parent
s=(out/'debug_native.py').read_text().replace("build/ninja-msvc-debug","build/ninja-msvc-release").replace('debug-native','sync-native')
s=s.replace("'--smoke-frames','8'","'--smoke-frames','4','--disable-bindless'")
s=s.replace("os.environ['VK_VALIDATION_VALIDATE_SYNC']='1'","os.environ['VK_VALIDATION_VALIDATE_SYNC']='1'\nos.environ['VK_LOADER_LAYERS_ENABLE']='VK_LAYER_KHRONOS_validation'\nos.environ['VK_LOADER_DEBUG']='error,warn,layer'")
s=s.replace('command,360','command,300')
s=s.replace("validationLayerEnabled='Validation layer: enabled' in log", "validationLayerEnabled=any('Insert instance layer' in line and 'VK_LAYER_KHRONOS_validation' in line for line in log.splitlines()),fixedDescriptors='Character texture access: fixed' in log")
s=s.replace("['validationLayerEnabled','sourceInputsUnchanged'","['validationLayerEnabled','fixedDescriptors','sourceInputsUnchanged'")
(out/'sync_native.py').write_text(s)
print('Prepared one bounded native sync check with fixed descriptor tables')
