from pathlib import Path
run=Path(__file__).resolve().parent
old=Path('build/runs/20261108-113315-conservative-depth-culling-079a96/candidate-source')
def replace(s,a,b):
 assert s.count(a)==1,(a[:100],s.count(a))
 return s.replace(a,b)
h=(old/'src/scenes/CharacterSceneRenderer.hpp').read_text()
h=replace(h,'#include "render/GpuConservativeOcclusion.hpp"','#include "render/GpuConservativeOcclusion.hpp"\n#include "render/DepthPrepassSplit.hpp"')
h=h.replace(',MainPrefill,Occlusion}',',MainPrefill}')
h=replace(h,'rhi::GpuBuffer source{};rhi::GpuImage depth{};\n        VkImageView view{};VkFramebuffer framebuffer{};','rhi::GpuBuffer source{};')
h=replace(h,'VkRenderPass conservativeRenderPass_{};\n    VkExtent2D conservativeExtent_{};VkFormat conservativeDepthFormat_{},conservativeColorFormat_{};', 'std::shared_ptr<const rhi::RenderPassDesc> mainPassDescription_;\n    std::unique_ptr<DepthPrepassSplit> mainDepthSplit_;\n    VkExtent2D conservativeExtent_{};')
h=replace(h,'rhi::RenderPassBeginDesc conservativeDepthPass(unsigned) const;\n    void recordConservativeHierarchy(rhi::ICommandRecorder&,unsigned);\n    void publishConservativeColorClears(rhi::ICommandRecorder&,unsigned);','bool mainDepthSplitActive(const RenderContext&) const;\n    rhi::RenderPassBeginDesc conservativeDepthPass(const RenderContext&) const;\n    void recordConservativeHierarchy(rhi::ICommandRecorder&,const RenderContext&);')
s=(old/'src/scenes/CharacterSceneRenderer.cpp').read_text()
start=s.index('    std::optional<RenderGraph::ResourceId> conservativeIndirectResource;')
end=s.index('    const auto prepass=graph.addGraphicsPass("character-opaque-depth"',start)
s=s[:start]+s[end:]
start=s.index('    const auto main = graph.addGraphicsPass("character-main"')
block='''    std::optional<RenderGraph::ResourceId> conservativeIndirectResource,conservativeReady;
    if(mainDepthSplitActive(context)){
        const auto slot=context.currentFrame;auto& frame=conservativeFrames_[slot];const auto ticket=frame.ticket;
        const auto prepare=graph.addGraphicsPass("character-main-depth",conservativeDepthPass(context),
            [this,frozenContext,frozenInstances,mainCounters](rhi::ICommandRecorder& commands){
                recordDepthCoverage(*frozenContext,*frozenInstances,commands,DepthCoverageMode::MainPrefill,
                    frozenContext->submissionCounters?mainCounters.get():nullptr);
            });
        graph.attachment(prepare,resources.color,RenderGraphUsage::ColorAttachment,VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL);
        graph.attachment(prepare,resources.normal,RenderGraphUsage::ColorAttachment,VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL);
        if(context.displayMaskEnabled)graph.attachment(prepare,resources.displayMask,RenderGraphUsage::ColorAttachment,VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL);
        graph.attachment(prepare,resources.depth,RenderGraphUsage::DepthAttachment,VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL);
        for(const auto resource:{jointResource,morphTargetResource,morphWeightResource,instanceResource})graph.use(prepare,resource,RenderGraphUsage::VertexStorage,false);
        if(skinnedResource)graph.use(prepare,*skinnedResource,RenderGraphUsage::VertexStorage,false);
        for(std::uint32_t key=0;key<meshResourceCount_;++key){graph.use(prepare,vertexResources[key],RenderGraphUsage::VertexBuffer,false);graph.use(prepare,indexResources[key],RenderGraphUsage::IndexBuffer,false);}
        const auto hierarchy=graph.addResource("character-conservative-hierarchy");
        const auto reduce=graph.addCommandPass("character-depth-hierarchy",[this,frozenContext](rhi::ICommandRecorder& commands){recordConservativeHierarchy(commands,*frozenContext);});
        graph.use(reduce,resources.depth,RenderGraphUsage::ComputeSampled,false);graph.write(reduce,hierarchy);
        const auto input=importHostStorage("character-occlusion-source",frame.source);
        const auto& output=frame.commands->output(0);rhi::BufferBarrierDesc result{};result.buffer=output.buffer;result.size=output.size;
        result.dstStageMask=VK_PIPELINE_STAGE_DRAW_INDIRECT_BIT;result.dstAccessMask=VK_ACCESS_INDIRECT_COMMAND_READ_BIT;
        conservativeIndirectResource=graph.importBuffer("character-occlusion-output",result);
        auto* owner=frame.commands.get();const auto cull=graph.addCommandPass("character-occlusion",[owner,ticket](rhi::ICommandRecorder& commands){owner->record(commands,*ticket);});
        graph.read(cull,hierarchy);graph.use(cull,input,RenderGraphUsage::Storage,false);graph.use(cull,*conservativeIndirectResource,RenderGraphUsage::Storage,true);
        // The split owner publishes sampling-to-depth-loading and color WAW.
        // Logical reads order this explicit transition before the color pass.
        const auto resume=graph.addCommandPass("character-main-depth-resume",[this,frozenContext](rhi::ICommandRecorder& commands){
            const auto& context=*frozenContext;std::vector<VkImage> colors(context.sceneColorImages.begin(),context.sceneColorImages.begin()+mainPassDescription_->attachments.size()-1);
            mainDepthSplit_->beforeColor(commands,context.sceneDepthImage,colors);
        });
        graph.read(resume,hierarchy);graph.read(resume,*conservativeIndirectResource);graph.read(resume,resources.depth);
        conservativeReady=graph.addResource("character-main-depth-ready");graph.write(resume,*conservativeReady);
    }
'''
s=s[:start]+block+s[start:]
s=replace(s,'    if(conservativeIndirectResource)graph.use(main,*conservativeIndirectResource,RenderGraphUsage::IndirectBuffer,false);','    if(conservativeIndirectResource)graph.use(main,*conservativeIndirectResource,RenderGraphUsage::IndirectBuffer,false);\n    if(conservativeReady)graph.read(main,*conservativeReady);')
s=replace(s,'    recordConservativeOcclusion(context,*instanceSnapshot_);\n','')
s=replace(s,'    recordMainPass(context);','    recordConservativeOcclusion(context,*instanceSnapshot_);\n    recordMainPass(context);')
s=replace(s,'    conservativeExtent_=context.renderExtent;conservativeDepthFormat_=context.depthFormat;conservativeColorFormat_=context.sceneColorFormat;','    conservativeExtent_=context.renderExtent;mainPassDescription_=context.scenePassDescription;')
s=replace(s,'    conservativeAllowed_=context.depthTestEnabled&&context.rasterizationSamples==VK_SAMPLE_COUNT_1_BIT','    conservativeAllowed_=bool(mainPassDescription_)&&context.depthTestEnabled&&context.rasterizationSamples==VK_SAMPLE_COUNT_1_BIT')
s=replace(s,'(pyramidPixels+std::uint64_t(context.renderExtent.width)*context.renderExtent.height)*4*kMaxFramesInFlight','pyramidPixels*4*kMaxFramesInFlight')
s=replace(s,'    const bool occlusion=mode==DepthCoverageMode::Occlusion;\n    const bool prefill=mainPrefill||occlusion||mode==DepthCoverageMode::SnapshotPrefill;','    const bool prefill=mainPrefill||mode==DepthCoverageMode::SnapshotPrefill;')
s=s.replace('            if(occlusion&&!fullyCoveredClassMaterial(m,1.F))continue;\n','').replace('                if(occlusion&&!fullyCoveredPrefill(m,run.opacity))return;\n','')
s=replace(s,'    renderPassInfo.renderPass = context.sceneRenderPass;','    renderPassInfo.renderPass = mainDepthSplitActive(context)?mainDepthSplit_->colorPass():context.sceneRenderPass;')
s=replace(s,'    if(settings.sceneLightingEnabled&&context.depthTestEnabled)\n        recordDepthCoverage(context,*snapshot,commands,DepthCoverageMode::MainPrefill,counters);','    if(settings.sceneLightingEnabled&&context.depthTestEnabled&&!mainDepthSplitActive(context))\n        recordDepthCoverage(context,*snapshot,commands,DepthCoverageMode::MainPrefill,counters);')
s=replace(s,'globalMaterialBase, counters, snapshot,false,context.depthTestEnabled);','globalMaterialBase, counters, snapshot,false,mainDepthSplitActive(context));')
inc=(old/'src/scenes/CharacterOcclusionPass.inc').read_text()
a=inc.index('        if(frame.framebuffer)');b=inc.index('    conservativeClipMatrices_.clear();',a)
inc=inc[:a]+'''        allocator_->destroyBuffer(frame.source);frame={};
    }
    mainDepthSplit_.reset();mainPassDescription_.reset();
'''+inc[b:]
a=inc.index('        if(!conservativeRenderPass_)');b=inc.index('        if(sources.size()>frame.capacity)',a)
inc=inc[:a]+'''        if(!mainDepthSplit_)mainDepthSplit_=std::make_unique<DepthPrepassSplit>(*rhi_,*mainPassDescription_);
        if(!frame.pyramid){
            unsigned levels=1;for(auto side=std::max(conservativeExtent_.width,conservativeExtent_.height);side>1;side/=2)++levels;
            frame.pyramid=std::make_unique<DepthPyramidGpu>(*rhi_,conservativeExtent_,levels,1,readBinaryFile(shaderDirectory_+"/depth_pyramid.comp.spv"));
        }
'''+inc[b:]
a=inc.index('rhi::RenderPassBeginDesc CharacterSceneRenderer::conservativeDepthPass')
inc=inc[:a]+'''bool CharacterSceneRenderer::mainDepthSplitActive(const RenderContext& context)const{
    if(!mainDepthSplit_||!conservativeFrames_.at(context.currentFrame).ticket||!context.depthTestEnabled
        ||context.rasterizationSamples!=VK_SAMPLE_COUNT_1_BIT||context.scenePassDescription!=mainPassDescription_
        ||!context.sceneFramebuffer||!context.sceneDepthImage||!context.sceneDepthView)return false;
    const auto colors=mainPassDescription_->attachments.size()-1;
    if(colors>context.sceneColorImages.size())return false;
    for(std::size_t i=0;i<colors;++i)if(!context.sceneColorImages[i])return false;
    return context.renderExtent.width==conservativeExtent_.width&&context.renderExtent.height==conservativeExtent_.height;
}
rhi::RenderPassBeginDesc CharacterSceneRenderer::conservativeDepthPass(const RenderContext& context)const{
    auto result=mainPassDescription(context);result.renderPass=mainDepthSplit_->depthPass();return result;
}
void CharacterSceneRenderer::recordConservativeHierarchy(rhi::ICommandRecorder& commands,const RenderContext& context){
    conservativeFrames_.at(context.currentFrame).pyramid->record(commands,0,context.sceneDepthView,DepthReduction::Maximum,{},VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL);
}
void CharacterSceneRenderer::recordConservativeOcclusion(const RenderContext& context,const SceneInstanceSnapshot& snapshot){
    if(!mainDepthSplitActive(context))return;
    auto& frame=conservativeFrames_.at(context.currentFrame);auto& commands=*context.commands;
    commands.beginRenderPass(conservativeDepthPass(context));
    recordDepthCoverage(context,snapshot,commands,DepthCoverageMode::MainPrefill,context.submissionCounters);commands.endRenderPass();
    commands.imageBarrier({context.sceneDepthImage,VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL,VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL,1,
        VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT|VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
        VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT,VK_IMAGE_ASPECT_DEPTH_BIT});
    recordConservativeHierarchy(commands,context);
    commands.bufferBarrier({frame.source.buffer,0,frame.source.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT});
    frame.commands->record(commands,*frame.ticket);const auto& output=frame.commands->output(0);
    commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_DRAW_INDIRECT_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_INDIRECT_COMMAND_READ_BIT});
    std::vector<VkImage> colors(context.sceneColorImages.begin(),context.sceneColorImages.begin()+mainPassDescription_->attachments.size()-1);
    mainDepthSplit_->beforeColor(commands,context.sceneDepthImage,colors);
}
'''
for name,content in [('src/scenes/CharacterSceneRenderer.hpp',h),('src/scenes/CharacterSceneRenderer.cpp',s),('src/scenes/CharacterOcclusionPass.inc',inc),('src/render/SceneInstanceSnapshot.hpp',(old/'src/render/SceneInstanceSnapshot.hpp').read_text())]:
 Path(name).write_text(content,newline='\n')
print('Applied main depth reuse adapter')
