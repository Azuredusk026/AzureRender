from pathlib import Path
import subprocess,os,sys,json,ctypes,time,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';folder=out/'cost-baseline';folder.mkdir(exist_ok=True)
if '--inside' not in sys.argv:
 temporary=out/'tmp/cost-build';temporary.mkdir(parents=True,exist_ok=True);env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary))
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],cwd=root,env=env).returncode)
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
before=inputs(root);source=(root/'src/scenes/CharacterSceneRenderer.cpp').read_text();needle='    prepareConservativeOcclusion();';assert source.count(needle)==1
(folder/'CharacterSceneRenderer.cpp').write_text(source.replace(needle,'    conservativeFrames_[currentFrame_].ticket.reset();'))
cache=(build/'CMakeCache.txt').read_text();ninja=re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.+)$',cache,re.M).group(1)
commands=subprocess.check_output([ninja,'-C',str(build),'-t','commands','AzurePlayer.exe'],text=True,encoding='utf-8').splitlines()
compileCommand=next(c for c in commands if c.rstrip().endswith('CharacterSceneRenderer.cpp'))
rule=re.search(r'^build AzurePlayer\.exe: (\S+)',(build/'build.ninja').read_text(),re.M).group(1)
expanded=json.loads(subprocess.check_output([ninja,'-C',str(build),'-t','compdb','-x',rule],text=True,encoding='utf-8'));assert len(expanded)==1
def split(command):
 count=ctypes.c_int();f=ctypes.windll.shell32.CommandLineToArgvW;f.restype=ctypes.POINTER(ctypes.c_wchar_p);f.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
 result=f(command,ctypes.byref(count));values=[result[i] for i in range(count.value)];ctypes.windll.kernel32.LocalFree(result);return values
command=[v for v in split(compileCommand) if v!='/showIncludes'];command[-1]=str(folder/'CharacterSceneRenderer.cpp')
for i,v in enumerate(command):
 if v.startswith('/Fo'):command[i]='/Fo'+str(folder/'CharacterSceneRenderer.obj')
 elif v.startswith('/Fd'):command[i]='/Fd'+str(folder/'CharacterSceneRenderer.pdb')
command[1:1]=['/I'+str(root/'src/scenes'),'/I'+str(root/'src/render')]
with (folder/'compile.log').open('wb') as log:r=subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert r.returncode==0,(folder/'compile.log').read_text(errors='replace')[-5000:]
link=split(expanded[0]['command'].split(' -- ',1)[1].split(' && ',1)[0])
for i,v in enumerate(link):
 if v.lower().startswith('/out:'):link[i]='/out:'+str(folder/'ProbePlayer.exe')
 elif v.lower().startswith('/implib:'):link[i]='/implib:'+str(folder/'ProbePlayer.lib')
 elif v.lower().startswith('/pdb:'):link[i]='/pdb:'+str(folder/'ProbePlayer.pdb')
link=[v for v in link if not v.lower().startswith(('/debug','/incremental'))];link[1:1]=[str(folder/'CharacterSceneRenderer.obj'),'/DEBUG:NONE','/INCREMENTAL:NO']
with (folder/'link.log').open('wb') as log:r=subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert r.returncode==0,(folder/'link.log').read_text(errors='replace')[-5000:]
assert inputs(root)==before
(out/'cost-build.json').write_text(json.dumps(dict(compile=command,link=link,privateSourceSha256=digest(folder/'CharacterSceneRenderer.cpp'),productionSourceSha256=digest(root/'src/scenes/CharacterSceneRenderer.cpp'),exeSha256=digest(folder/'ProbePlayer.exe'),sourceInputsUnchanged=True),indent=2))
print('Current-runtime baseline with conservative preparation disabled was built',flush=True)
