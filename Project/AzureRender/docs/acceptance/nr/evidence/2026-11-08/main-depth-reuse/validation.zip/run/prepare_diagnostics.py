from pathlib import Path
out=Path(__file__).resolve().parent;old=out.parent/'20261108-113315-conservative-depth-culling-079a96'
for name in ['workload.py','capture.py','cost.py','build_cost_baseline.py']:
 s=(old/name).read_text()
 s=s.replace("k.startswith('conservativeOcclusion')","k.startswith('conservativeOcclusion') or k=='mainDepthSplitRecorded'")
 if name=='capture.py':s=s.replace("assert workload['conservativeOcclusionPrepared']", "assert workload['mainDepthSplitRecorded'] and workload['conservativeOcclusionPrepared']")
 (out/name).write_text(s)
print('Prepared bounded scene diagnostics with current runtime provenance')
