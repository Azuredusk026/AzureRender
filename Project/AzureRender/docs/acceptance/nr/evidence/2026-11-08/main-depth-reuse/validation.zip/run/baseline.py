from pathlib import Path
import json,subprocess,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
names=['src/rhi/Rhi.hpp','src/rhi/VulkanRhi.cpp','src/rhi/NullRhi.hpp','src/rhi/NullRhi.cpp','src/render/RenderContext.hpp','src/render/DepthPyramid.hpp','src/render/DepthPyramid.cpp','src/render/RenderViewService.cpp','src/render/SceneInstanceSnapshot.hpp','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderApp.hpp','src/app/AzureRenderApp.cpp','src/app/AzureRenderFrame.cpp','src/scenes/CharacterSceneRenderer.hpp','src/scenes/CharacterSceneRenderer.cpp','tests/DepthPyramidTests.cpp','tests/DepthPrefillRecordingTests.cpp','CMakeLists.txt']
for name in names:
 target=out/'original-source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/name).read_bytes())
products={config:{str(p):digest(p) for p in [*(root/f'build/ninja-msvc-{config}').glob('*.exe'),*(root/f'build/ninja-msvc-{config}/shaders').glob('*.spv')]} for config in ['release','debug']}
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
import hashlib
user=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest();assert user=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
(out/'baseline.json').write_text(json.dumps(dict(sourceBase='707a593',source=inputs(root),products=products,userDiffSha256=user,protectedPaths=protected,rawHashes={name:digest(root/name) for name in names}),indent=2))
