from pathlib import Path
old=Path('build/runs/20261108-113315-conservative-depth-culling-079a96/candidate-source/tests/DepthPrefillRecordingTests.cpp').read_text()
start=old.index('void verifyConservativeOcclusion(');end=old.index('\n}\nint main',start)
fixture=old[start:end]
fixture=fixture.replace('    renderer.onLoad(context);SceneFrameData frame;', '''    rhi::RenderPassDesc source;source.depthAttachment=1;
    source.attachments={{VK_FORMAT_R16G16B16A16_SFLOAT,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,true,true,false},
        {VK_FORMAT_D32_SFLOAT,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL,true,true,true},
        {VK_FORMAT_R16G16B16A16_SFLOAT,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,true,true,false}};
    source.externalReadDependency=true;context.scenePassDescription=std::make_shared<const rhi::RenderPassDesc>(source);
    context.sceneFramebuffer=reinterpret_cast<VkFramebuffer>(std::uintptr_t(1));
    context.sceneDepthImage=reinterpret_cast<VkImage>(std::uintptr_t(2));context.sceneDepthView=reinterpret_cast<VkImageView>(std::uintptr_t(3));
    context.sceneColorImages={reinterpret_cast<VkImage>(std::uintptr_t(4)),reinterpret_cast<VkImage>(std::uintptr_t(5)),VK_NULL_HANDLE};
    renderer.onLoad(context);SceneFrameData frame;''')
fixture=fixture.replace('unsigned depthDraws=0,indirect=0,producers=0;', '''unsigned depthDraws=0,indirect=0,producers=0,duplicatePrefill=0;
        std::set<std::string> prefill;
        for(const auto& call:backend.calls)if(call.name=="createGraphicsPipeline"&&call.detail.find("depthBias=1.000000/0.000000")!=std::string::npos&&call.detail.find(" masks=0/0/")!=std::string::npos)
            prefill.insert(call.detail.substr(0,call.detail.find(' ')));''')
fixture=fixture.replace('"character-occluder-depth"','"character-main-depth"')
fixture=fixture.replace('&&pass.name!="character-main")','&&pass.name!="character-main-depth-resume"&&pass.name!="character-main")')
fixture=fixture.replace('            if(pass.name=="character-main")for(const auto& call:recorder.calls)if(call.name=="drawIndexedIndirect")++indirect;', '''            if(pass.name=="character-main"){std::string pipeline;for(const auto& call:recorder.calls){
                if(call.name=="bindPipeline")pipeline=call.detail;
                if(call.name=="drawIndexedIndirect")++indirect;
                if(call.name=="drawIndexed"&&prefill.count(pipeline))++duplicatePrefill;
            }}''')
fixture=fixture.replace('require(producers==3,"Conservative depth, hierarchy and command producers must be present");','require(producers==4,"Main depth, hierarchy, command and depth resume producers must be present");')
fixture=fixture.replace('require(depthDraws==300*opaque->primitives.size(),"Partial node opacity must not contribute safe occluder depth");','require(depthDraws==301*opaque->primitives.size(),"Main depth must preserve opaque and faded prefill exactly once");\n        require(duplicatePrefill==0,"Color phase must consume prepared depth without another prefill");')
fixture=fixture.replace('        require(indirect>0,"Qualified main draws must consume conservative indirect output");', '''        require(indirect>0,"Qualified main draws must consume conservative indirect output");
        auto incomplete=context;incomplete.sceneDepthImage=VK_NULL_HANDLE;RenderGraph fallback;
        SceneGraphResources fallbackResources{fallback.addResource("color"),fallback.addResource("depth"),fallback.addResource("normal"),fallback.addResource("shadow")};
        renderer.registerPasses(fallback,fallbackResources,incomplete);require(fallback.compile(error),error.c_str());
        for(const auto& pass:fallback.passes()){
            require(pass.name!="character-main-depth"&&pass.name!="character-occlusion","Absent borrowed target must retain the original path");
            if(pass.name=="character-main"){rhi::NullCommandRecorder recorder;pass.recordCommands(recorder);
                for(const auto& call:recorder.calls)require(call.name!="drawIndexedIndirect","Fallback must not consume unproduced conservative output");}
        }''')
p=Path('tests/DepthPrefillRecordingTests.cpp');s=p.read_text();s=s.replace('\n}\nint main','\n'+fixture+'\n}\nint main');s=s.replace('    std::cout<<"Depth prefill:','    verifyConservativeOcclusion(argv[1]);\n    std::cout<<"Depth prefill:');p.write_text(s,newline='\n')
print('Updated main depth scene fixture')
