from pathlib import Path
import json,os,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from artifact_maintenance import guarded_run
build=root/'build/ninja-msvc-debug';verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}
project=out.parent/'20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
command=[str(build/'AzurePlayer.exe'),'--project',str(project),'--resource-root',str(build),'--width','2560','--height','1440','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','24','--smoke-frames','8','--gpu-timing','--gpu-timing-output',str(out/'debug-native-state.json')]
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['PATH']=str(build)+';'+os.environ['PATH']
os.environ['VK_VALIDATION_VALIDATE_SYNC']='1'
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','AZURE_CPU_WORK_REPORT']:os.environ.pop(key,None)
execution=guarded_run(root/'build',out.name,command,360);(out/'debug-native-execution.json').write_text(json.dumps(execution,indent=2))
log=(out/'process.log').read_text(errors='replace');(out/'debug-native-process.log').write_text(log)
assert execution['status']=='exited' and execution['exitCode']==0,execution
data=json.loads((out/'debug-native-state.json').read_text());metadata={k:v for k,v in data.items() if k.startswith('conservativeOcclusion') or k=='mainDepthSplitRecorded'}
result=dict(execution=execution,metadata=metadata,syncValidationRequested=True,validationLayerEnabled='Validation layer: enabled' in log,sourceInputsUnchanged=inputs(root)==before,productsUnchanged=all(digest(Path(p))==sha for p,sha in products.items()),zeroAllocator='Allocator after unload: buffers=0 images=0' in log,validationLogClean=not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-']),formalPerformancePassed=False)
(out/'debug-native.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
assert metadata['mainDepthSplitRecorded'] and metadata['conservativeOcclusionPrepared']
assert all(result[k] for k in ['validationLayerEnabled','sourceInputsUnchanged','productsUnchanged','zeroAllocator','validationLogClean'])
