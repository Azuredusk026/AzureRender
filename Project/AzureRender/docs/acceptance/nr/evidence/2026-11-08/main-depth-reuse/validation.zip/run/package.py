from pathlib import Path
import hashlib,json,subprocess,sys,zipfile,re,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
proof=[];checks=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';manifest=json.loads(p.read_text());verify(root,manifest);proof.append(dict(configuration=config,sha256=digest(p)))
 for label in ['nvidia','intel']:
  for case in ET.parse(out/(config+'-'+label+'.xml')).getroot().findall('testcase'):
   assert case.attrib['status']=='run' and case.find('failure') is None
   checks.append(dict(configuration=config,label=label,name=case.attrib['name'],seconds=case.attrib['time'],output=(case.findtext('system-out') or '').strip()))
assert len(checks)==22
native=json.loads((out/'sync-native.json').read_text());assert native['syncValidationRequested'] and native['validationLayerEnabled'] and native['fixedDescriptors']
debugAttempt=json.loads((out/'debug-native-execution.json').read_text());assert debugAttempt['status']=='budget-stopped'
assert all(native[k] for k in ['sourceInputsUnchanged','productsUnchanged','zeroAllocator','validationLogClean']) and native['metadata']['mainDepthSplitRecorded']
image=json.loads((out/'image/results.json').read_text());assert len(image['frames'])==4 and all(r['changedPixels']==0 and r['sha256']==r['referenceSha256'] for r in image['frames'])
cost=json.loads((out/'cost-results-v1.json').read_text());assert cost['bracketStable'] and cost['gpuSavedMs']>0 and cost['sourceAndProductsUnchanged']
measured=json.loads((out/'measured-build-provenance.json').read_text());current=inputs(root)
changed=[name for name in sorted(current.keys()|measured['source'].keys()) if current.get(name)!=measured['source'].get(name)]
assert changed==['src/render/DepthPrepassSplit.cpp','src/scenes/CharacterSceneRenderer.cpp'],changed
name='src/render/DepthPrepassSplit.cpp';value=(root/name).read_text();value=value.replace('            if(original.format!=VK_FORMAT_D16_UNORM&&original.format!=VK_FORMAT_X8_D24_UNORM_PACK32&&original.format!=VK_FORMAT_D32_SFLOAT)\n                throw std::invalid_argument("Depth split requires a depth-only format");\n','')
assert value==(out/'measured-source'/name).read_text()
name='src/scenes/CharacterSceneRenderer.cpp';value=(root/name).read_text();value=value.replace('    conservativeAllowed_=bool(mainPassDescription_)&&context.computeShaders&&context.gpuCulling\n        &&context.depthTestEnabled&&context.rasterizationSamples==VK_SAMPLE_COUNT_1_BIT','    conservativeAllowed_=bool(mainPassDescription_)&&context.depthTestEnabled&&context.rasterizationSamples==VK_SAMPLE_COUNT_1_BIT')
assert value==(out/'measured-source'/name).read_text()
guardScope=dict(changedSourceFiles=changed,changesLimitedToQualificationGuards=True,measuredDepthFormat='VK_FORMAT_D32_SFLOAT',finalQualifiedPathActive=native['metadata']['mainDepthSplitRecorded'],nativeFourFrameEvidenceReused=True)
baseline=json.loads((out/'baseline.json').read_text());unchanged={}
for config,products in baseline['products'].items():
 programs={name:sha for name,sha in products.items() if name.endswith('.spv') and Path(name).parent.name=='shaders'}
 assert len(programs)==670 and all(digest(Path(name))==sha for name,sha in programs.items());unchanged[config]=len(programs)
lock=json.loads((out.parent/'20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text());assert all(digest(Path(name))==sha for name,sha in lock.items())
name='src/app/AzureRenderPipeline.cpp';value=(root/name).read_bytes()
value=value.replace(b'#include "rhi/RenderPassDescription.hpp"\n',b'').replace(b'    scenePassDescription_.reset();\n    try{scenePassDescription_=std::make_shared<const azurerender::rhi::RenderPassDesc>(azurerender::rhi::describeRenderPass(createInfo));}\n    catch(const std::invalid_argument&){/* Optional split metadata is unavailable. */}\n',b'')
assert value==(out/'original-source'/name).read_bytes()
protected=[name for name in baseline['protectedPaths'] if name!='src/app/AzureRenderPipeline.cpp']
user=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest();assert user==baseline['userDiffSha256']
boundaries=json.loads((out/'module-boundaries.json').read_text());assert boundaries['status']=='passed' and not boundaries['violations']
sources=['CMakeLists.txt','src/rhi/Rhi.hpp','src/rhi/VulkanRhi.cpp','src/rhi/RenderPassDescription.hpp','src/render/DepthPrepassSplit.hpp','src/render/DepthPrepassSplit.cpp','src/render/DepthPyramid.hpp','src/render/DepthPyramid.cpp','src/render/RenderContext.hpp','src/render/RenderViewService.cpp','src/render/SceneInstanceSnapshot.hpp','src/scenes/CharacterSceneRenderer.hpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterOcclusionPass.inc','src/app/AzureRenderApp.hpp','src/app/AzureRenderApp.cpp','src/app/AzureRenderFrame.cpp','src/app/AzureRenderPipeline.cpp','tests/DepthPrepassSplitTests.cpp','tests/DepthPrepassSplitGpuTests.cpp','tests/DepthPyramidTests.cpp','tests/DepthPrefillRecordingTests.cpp','tests/RenderViewSubmissionTests.cpp','shaders/depth_prepass_test.vert','shaders/depth_prepass_test.frag']
members={}
for path in out.rglob('*'):
 if not path.is_file() or 'tmp' in path.relative_to(out).parts:continue
 if path.suffix not in ['.py','.json','.log','.xml','.csv','.cpp','.hpp','.inc']:continue
 if path.stat().st_size>2*2**20:continue
 members['run/'+path.relative_to(out).as_posix()]=path
for name in sources:members['source/'+name]=root/name
for config in ['release','debug']:
 for name in ['depth_prepass_test.vert','depth_prepass_test.frag','depth_pyramid.comp','conservative_occlusion.comp']:
  members[f'program/{config}/{name}.spv']=root/f'build/ninja-msvc-{config}/shaders/{name}.spv'
members['reference/frozen-project-inputs.json']=out.parent/'20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json'
folder=Path(image['execution']['command'][image['execution']['command'].index('--capture-dir')+1])
members['image/frame_000000.png']=folder/'frame_000000.png'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/main-depth-reuse';evidence.mkdir(parents=True,exist_ok=True);package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(members.items()):z.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,path in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='integrated-local-cost-improved-formal-budget-pending',sourceBase='707a593',sourceHashes={name:digest(root/name) for name in sources},checks=checks,nativeSynchronization=native,nativeDebugAttempt=debugAttempt,nativeDebugFullyCompleted=False,image=image,localCost=cost,imageEvidenceScope=guardScope,unchangedPrograms=unchanged,moduleBoundaries=boundaries,productionProvenance=proof,userDiffSha256=user,pipelineUserRawBytesPreserved=True,projectInputsVerified=len(lock),sceneIntegrated=True,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package))
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'docs/development/artifact-manifest.json';data=json.loads(p.read_text(encoding='utf-8'));data['milestones']=[m for m in data['milestones'] if m['path']!='runs/'+out.name]
data['milestones'].insert(0,dict(path='runs/'+out.name,name='主通道深度预填复用',status='IntegratedLocalCostImprovedFormalBudgetPending',sourceBase='707a593',evidence='docs/acceptance/nr/main-depth-reuse.md',checksPassed=22,sceneIntegrated=True,nativeImagesExact=True,gpuSavedMs=cost['gpuSavedMs'],formalPerformancePassed=False))
p.write_text(json.dumps(data,ensure_ascii=False,indent=2).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-main-depth-reuse.md','docs/development/depth-prepass-split.md','docs/development/gpu-conservative-occlusion.md','docs/acceptance/nr/main-depth-reuse.md','docs/acceptance/nr/gpu-conservative-occlusion.md']:
 path=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (path.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],checks=len(checks),evidenceBytes=package.stat().st_size,gpuSavedMs=cost['gpuSavedMs'],userDiffPreserved=True),ensure_ascii=False))
