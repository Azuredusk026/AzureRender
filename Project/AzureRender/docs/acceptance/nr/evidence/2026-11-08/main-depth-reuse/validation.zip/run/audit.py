from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();out=Path(__file__).resolve().parent;baseline=json.loads((out/'baseline.json').read_text())
name='src/app/AzureRenderPipeline.cpp';value=(root/name).read_bytes();original=(out/'original-source'/name).read_bytes()
value=value.replace(b'#include "rhi/RenderPassDescription.hpp"\n',b'')
value=value.replace(b'    scenePassDescription_.reset();\n    try{scenePassDescription_=std::make_shared<const azurerender::rhi::RenderPassDesc>(azurerender::rhi::describeRenderPass(createInfo));}\n    catch(const std::invalid_argument&){/* Optional split metadata is unavailable. */}\n',b'')
assert value==original,'User pipeline bytes differ outside owned insertions'
protected=['docs/acceptance/p5','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
print(json.dumps(dict(pipelineUserBytesPreserved=True,otherProtectedDiffSha256=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest(),baselineKeys=list(baseline))))
