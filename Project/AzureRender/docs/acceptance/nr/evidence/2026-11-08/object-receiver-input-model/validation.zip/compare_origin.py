from pathlib import Path
import json,re,sys
import numpy as np
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
source=inputs(root)
data=root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f'
traces=root/'build/runs/20261027-031252-hair-residual-fragment-diagnosis-13e962'
visibility=root/'build/runs/20261027-002548-native-hair-layer-region-closure-61c105/native-screen-visibility.bin'
paths=[data/name for name in ['producer-cb0.bin','producer-cb1.bin','producer-cb3.bin','native-t0.bin','native-t2.bin','native-t6.bin']]+[visibility]
hashes={str(p):digest(p) for p in paths}
cb0=np.fromfile(data/'producer-cb0.bin',dtype='<f4').reshape(-1,4);cb1=np.fromfile(data/'producer-cb1.bin',dtype='<f4').reshape(-1,4);cb3=np.fromfile(data/'producer-cb3.bin',dtype='<f4').reshape(-1,4)
depth=np.fromfile(data/'native-t0.bin',dtype='<f4').reshape(1440,2560);normals=np.fromfile(data/'native-t6.bin',dtype='<u4').reshape(1440,2560)
atlas=np.fromfile(data/'native-t2.bin',dtype='<u2').reshape(2048,4096).astype(np.float32)/np.float32(65535)
mask=np.fromfile(visibility,dtype='u1').reshape(1440,2560,2)
bits=np.array([[int(v) for v in re.findall(r'(\d+)u',line)] for line in (root/'shaders/object_shadow.glsl').read_text().splitlines() if 'uvec4(' in line and len(re.findall(r'(\d+)u',line))==4],dtype=np.uint32);disk=bits.view(np.float32)
F=np.float32
def fma(a,b,c):return (np.asarray(a,dtype=np.float64)*np.asarray(b,dtype=np.float64)+np.asarray(c,dtype=np.float64)).astype(np.float32)
origin=np.array([-300,300,-300],dtype=np.float32)
def reconstruct(x,y):
    pixel=np.array([x,1439-y],dtype=np.float32);ndc=fma(pixel*cb1[0,2:],F(2),F(-1))
    value=fma(cb0[24],ndc[0],-ndc[1]*cb0[25]);value=fma(cb0[26],depth[1439-y,x],value);value=(value+cb0[27]).astype(np.float32)
    return (value[:3]/value[3]).astype(np.float32)
def normal(x,y):
    word=normals[1439-y,x];q=fma(np.array([word&1023,(word>>10)&1023],dtype=np.float32)/F(1023),F(2),F(-1))
    value=np.array([q[0],F(1)-np.abs(q).sum(dtype=np.float32),q[1]],dtype=np.float32)
    if value[1]<0:value[[0,2]]=(F(1)-np.abs(q[::-1]))*np.where(q>=0,F(1),F(-1))
    return value/np.sqrt((value*value).sum(dtype=np.float32))
def evaluate(position,n,x,y,relative=False):
    light=cb3[203,:3];weight=F(1)-np.clip((n*light).sum(dtype=np.float32),F(0),F(.9));bias=(weight*cb3[188,:2]).astype(np.float32)
    p=fma(-light,bias[0],position);p=fma(n,bias[1],p)
    q=fma(cb3[128,:3],p[0],p[1]*cb3[129,:3]);q=fma(cb3[130,:3],p[2],q)
    translation=cb3[131,:3] if not relative else (origin.astype(np.float64)@cb3[128:131,:3].astype(np.float64)+cb3[131,:3].astype(np.float64)).astype(np.float32)
    q=(q+translation).astype(np.float32);q[2]=max(q[2],F(.01));uv=fma(q[:2],cb3[218,2:],cb3[218,:2])
    phase=((x&3)<<2)|((1439-y)&3);rot=disk[phase,:2];count=0;delta=F(0)
    for entry in disk[:,2:]:
        rotated=np.array([F(entry[0]*rot[0])-F(entry[1]*rot[1]),F(entry[1]*rot[0])+F(entry[0]*rot[1])],dtype=np.float32)
        tap=fma(rotated,F(4)*cb3[233,0],uv);base=np.floor(tap*np.array([4096,2048],dtype=np.float32)-F(.5)).astype(int)
        values=atlas[base[1]:base[1]+2,base[0]:base[0]+2].reshape(-1);difference=(values-q[2]).astype(np.float32)
        count+=int((difference>=0).sum());delta=F(delta+np.maximum(difference,F(0)).sum(dtype=np.float32))
    a=F(2)*F(count)/F(64)-F(1);t=F(1)-np.abs(a);cube=F(F(t*t)*t);ratio=np.clip(F(F(delta/F(max(count,1)))/q[2]),F(0),F(1));v=F(.5)-F(.5)*np.sign(a)*(F(1)-(cube+ratio*(t-cube)))
    return dict(unorm8=int(np.floor(F(v*F(255))+F(.5))),count=count,projected=q.tolist())
rows=[]
for x,y in [(1322,263),(1324,289),(1322,320),(1258,215)]:
    path=traces/f'candidate-{x}-{y}.json';hashes[str(path)]=digest(path);trace=json.loads(path.read_text());values={entry['name']:entry['var'] for entry in trace['changes']}
    p=np.array(values['receiverPosition']['value'],dtype=np.float32)*np.array([-1,1,1],dtype=np.float32);n=np.array(values['receiverNormal']['value'],dtype=np.float32)*np.array([-1,1,1],dtype=np.float32)
    absolute=(p+origin).astype(np.float32);nativePosition=reconstruct(x,y);nativeNormal=normal(x,y)
    rows.append(dict(pixel=[x,y],referenceVisibility=int(mask[1439-y,x,1]),currentReceiver=p.tolist(),roundedAbsoluteReceiver=absolute.tolist(),sourceDepthReconstruction=nativePosition.tolist(),worldDifferenceMicrometers=((absolute.astype(np.float64)-nativePosition.astype(np.float64))*1e6).tolist(),sourceModel=evaluate(nativePosition,nativeNormal,x,y),relativeModel=evaluate(p,n,x,y,True),absoluteModel=evaluate(absolute,n,x,y),absoluteWithSourceNormal=evaluate(absolute,nativeNormal,x,y)))
assert inputs(root)==source and all(digest(Path(path))==sha for path,sha in hashes.items())
report=dict(status='offline-numeric-control',rows=rows,sourceInputs=source,readOnlyInputs=hashes,productionUnchanged=True,scope='CPU float32/FMA numeric control using captured depth, normal and matrix values; not GPU filtering, image acceptance, or a production change.')
(out/'origin-control.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(status=report['status'],rows=rows),indent=2))
