from pathlib import Path
import json,os,re,subprocess,sys
import numpy as np
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
assert check(root/'build',run=out,planned=16*2**20)['allowed'];before=inputs(root)
data=root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f'
depth=np.fromfile(data/'native-t0.bin',dtype='<f4').reshape(1440,2560);ids=np.fromfile(data/'native-t5.bin',dtype='<u4').reshape(1440,2560)
maskPath=root/'build/runs/20261027-002548-native-hair-layer-region-closure-61c105/native-screen-visibility.bin';mask=np.fromfile(maskPath,dtype='u1').reshape(1440,2560,2)
queries=[]
for x,y in [(1322,263),(1324,289),(1322,320),(1258,215)]:
    objectIndex=int(np.log2(np.float32(ids[1439-y,x]))-8);assert objectIndex==0
    queries.append(dict(pixel=[x,y],input=[x,1439-y,float(depth[1439-y,x]),objectIndex],expected=int(mask[1439-y,x,1])))
config=dict(cb0=str(data/'producer-cb0.bin'),cb1=str(data/'producer-cb1.bin'),cb3=str(data/'producer-cb3.bin'),depth=str(data/'native-t2.bin'),normals=str(data/'native-t6.bin'),queries=queries)
(out/'gpu-inputs.json').write_text(json.dumps(config,indent=2))
rows=[]
for line in (root/'shaders/object_shadow.glsl').read_text().splitlines():
    values=re.findall(r'(\d+)u',line)
    if 'uvec4(' in line and len(values)==4:rows.append('uvec4('+','.join(value+'u' for value in values)+')')
assert len(rows)==16;shader=(out/'receiver.comp').read_text();assert shader.count('DISK_VALUES')==1
(out/'receiver-compiled.comp').write_text(shader.replace('DISK_VALUES',',\n'.join(rows)))
command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe',str(out/'receiver-compiled.comp'),'-o',str(out/'receiver.spv')]
result=subprocess.run(command,capture_output=True,text=True,timeout=30);assert result.returncode==0,result.stderr
validation=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(out/'receiver.spv')];subprocess.run(validation,capture_output=True,check=True,timeout=10)
env=os.environ.copy();env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9');bat=[str(root/'tools/msvc_env.bat')]
compile=bat+['cl.exe','/nologo','/O2','/MD','/EHsc','/std:c++17','/utf-8','/DNOMINMAX','/DNDEBUG',f'/I{root/"src"}',f'/I{root/"tests"}',f'/I{root/"build/ninja-msvc-debug/vcpkg_installed/x64-windows/include"}','/ID:/Tools/VulkanSDK/1.4.350.0/Include','/c',str(out/'receiver.cpp'),f'/Fo{out/"receiver.obj"}']
with (out/'compile.log').open('wb') as log:result=subprocess.run(compile,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert result.returncode==0,(out/'compile.log').read_text(errors='replace')[-2500:]
link=bat+['link.exe',str(out/'receiver.obj'),f'/OUT:{out/"receiver.exe"}','/INCREMENTAL:NO',str(root/'build/ninja-msvc-release/AzureRenderCore.lib'),str(root/'build/ninja-msvc-release/AzureFoundation.lib'),'D:/Tools/VulkanSDK/1.4.350.0/Lib/vulkan-1.lib','kernel32.lib','user32.lib','advapi32.lib']
with (out/'link.log').open('wb') as log:result=subprocess.run(link,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert result.returncode==0,(out/'link.log').read_text(errors='replace')[-2500:]
assert inputs(root)==before
(out/'gpu-preparation.json').write_text(json.dumps(dict(status='prepared',sourceInputs=before,shaderCommand=command,validation=validation,compile=compile,link=link,inputHashes={value:digest(Path(value)) for key,value in config.items() if key!='queries'},shaderSha256=digest(out/'receiver.spv')),indent=2));print(json.dumps(dict(status='prepared',queries=4,productionUnchanged=True)),flush=True)
