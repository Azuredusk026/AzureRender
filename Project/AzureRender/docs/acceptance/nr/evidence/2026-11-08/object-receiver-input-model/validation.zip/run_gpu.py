from pathlib import Path
import json,os,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import guarded_run
from build_provenance import inputs,digest
before=inputs(root);prepared=json.loads((out/'gpu-preparation.json').read_text());assert before==prepared['sourceInputs']
products={str(path):digest(path) for path in [root/'build/ninja-msvc-release/AzurePlayer.exe',*sorted((root/'build/ninja-msvc-release/shaders').glob('*.spv'))]}
os.environ['PATH']=str(root/'build/ninja-msvc-release')+';'+os.environ['PATH'];os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
execution=guarded_run(root/'build',out.name,[str(out/'receiver.exe'),str(out)],120);(out/'gpu-execution.json').write_text(json.dumps(execution,indent=2))
assert execution['exitCode']==0,(out/'process.log').read_text(errors='replace')[-3000:]
assert inputs(root)==before and all(digest(Path(path))==sha for path,sha in products.items()) and all(digest(Path(path))==sha for path,sha in prepared['inputHashes'].items())
config=json.loads((out/'gpu-inputs.json').read_text());report=json.loads((out/(config.get('resultPrefix','gpu-')+'result.json')).read_text());print(json.dumps(report,indent=2),flush=True)
