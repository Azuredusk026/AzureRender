from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,digest
region=json.loads((out/'region-result.json').read_text());quantization=json.loads((out/'quantization-result.json').read_text());assert region['pixels']==17017 and region['withinOnePixels']==17017 and quantization['exactPixels']==17017 and quantization['maximumVisibilityByteError']==0
assert region['validationErrors']==quantization['validationErrors']==0 and region['zeroAllocator'] and quantization['zeroAllocator']
cpu=json.loads((out/'origin-control.json').read_text());gpu=json.loads((out/'gpu-preparation.json').read_text());assert all(digest(Path(path))==sha for path,sha in cpu['readOnlyInputs'].items()) and all(digest(Path(path))==sha for path,sha in gpu['inputHashes'].items())
proof=[]
for config in ['release','debug']:
 path=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(path.read_text()));proof.append(dict(configuration=config,status='passed',sha256=digest(path)))
protectedPaths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protectedPaths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/object-receiver-input-model';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.cpp','.comp','.vert','.frag','.spv','.bin','.json','.log'] and p.stat().st_size<2*2**20}
for key in ['cb0','cb1','cb3']:members['source-input/'+key+'.bin']=Path(json.loads((out/'gpu-inputs.json').read_text())[key])
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in sorted(members.items()):archive.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as archive:
 assert archive.testzip() is None
 for name,path in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='source-input-visibility-and-attachment-verified',sourceBase='18b66cf',cpuControlRows=cpu['rows'],fourPointGpu=json.loads((out/'gpu-result.json').read_text()),fullRegion=region,actualAttachment=quantization,regionInputs=json.loads((out/'region-inputs.json').read_text()),readOnlyInputs=cpu['readOnlyInputs']|gpu['inputHashes'],productionProvenance=proof,userDiffSha256=protected,productionIntegrated=False,fullHairColorPassed=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=name,bytes=p.stat().st_size,sha256=digest(p)) for name,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps(dict(status=report['status'],sourceVisibilityPixelsExact=17017,evidenceBytes=report['evidenceBytes'],productionUnchanged=True,userDiffPreserved=True)))
