#version 450
layout(binding=0,std430) readonly buffer Values {vec4 v[];} source;
layout(push_constant) uniform Parameters {uint count,width;} parameters;
layout(location=0) out vec4 outputColor;
void main(){uint index=uint(gl_FragCoord.y)*parameters.width+uint(gl_FragCoord.x);float value=index<parameters.count?source.v[index*4].w:0;outputColor=vec4(value,value,0,1);}
