from pathlib import Path
import json,sys
import numpy as np
from PIL import Image
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest
data=root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f'
maskPath=root/'build/runs/20261023-105023-character-composite-contribution-diagnosis-acb8e5/native-hair-visible-mask.png'
mask=np.asarray(Image.open(maskPath).convert('L'))[130:440,1140:1430]!=0;y,x=np.nonzero(mask);assert len(x)==17017
x=x+1140;y=y+130;nativeY=1439-y
depth=np.fromfile(data/'native-t0.bin',dtype='<f4').reshape(1440,2560);ids=np.fromfile(data/'native-t5.bin',dtype='<u4').reshape(1440,2560);assert (ids[nativeY,x]==258).all()
query=np.column_stack([x,nativeY,depth[nativeY,x],np.zeros(len(x))]).astype('<f4');query.tofile(out/'region-queries.bin')
visibility=root/'build/runs/20261027-002548-native-hair-layer-region-closure-61c105/native-screen-visibility.bin';native=np.fromfile(visibility,dtype='u1').reshape(1440,2560,2);native[nativeY,x,1].astype('<u4').tofile(out/'region-expected.bin')
config=json.loads((out/'gpu-inputs.json').read_text());config.pop('queries',None);config.update(queryBinary=str(out/'region-queries.bin'),expectedBinary=str(out/'region-expected.bin'),resultPrefix='region-')
(out/'gpu-inputs.json').write_text(json.dumps(config,indent=2));(out/'region-inputs.json').write_text(json.dumps(dict(maskPixels=len(x),box=[1140,130,1430,440],maskPath=str(maskPath),maskSha256=digest(maskPath),queriesSha256=digest(out/'region-queries.bin'),expectedSha256=digest(out/'region-expected.bin'),nativeVisibilitySha256=digest(visibility)),indent=2));print(json.dumps(dict(status='region-prepared',pixels=len(x))))
