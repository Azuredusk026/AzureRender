from pathlib import Path
import json,os,subprocess,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import guarded_run
from build_provenance import inputs,digest
before=inputs(root);prepared=json.loads((out/'gpu-preparation.json').read_text());env=os.environ.copy();env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9')
builds=[]
for kind in ['vert','frag']:
 command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe',str(out/('quantize.'+kind)),'-o',str(out/('quantize.'+kind+'.spv'))];subprocess.run(command,check=True,capture_output=True,timeout=30)
 validation=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(out/('quantize.'+kind+'.spv'))];subprocess.run(validation,check=True,capture_output=True,timeout=10);builds.append(dict(command=command,validation=validation))
compile=[arg.replace(str(out/'receiver.cpp'),str(out/'quantize.cpp')).replace(str(out/'receiver.obj'),str(out/'quantize.obj')) for arg in prepared['compile']]
with (out/'quantize-compile.log').open('wb') as log:r=subprocess.run(compile,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(out/'quantize-compile.log').read_text(errors='replace')[-2500:]
link=[arg.replace(str(out/'receiver.obj'),str(out/'quantize.obj')).replace(str(out/'receiver.exe'),str(out/'quantize.exe')) for arg in prepared['link']]
with (out/'quantize-link.log').open('wb') as log:r=subprocess.run(link,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0,(out/'quantize-link.log').read_text(errors='replace')[-2500:]
products={str(p):digest(p) for p in [root/'build/ninja-msvc-release/AzurePlayer.exe',*sorted((root/'build/ninja-msvc-release/shaders').glob('*.spv')),out/'region-output.bin',out/'region-expected.bin']}
os.environ['PATH']=str(root/'build/ninja-msvc-release')+';'+os.environ['PATH'];os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
execution=guarded_run(root/'build',out.name,[str(out/'quantize.exe'),str(out)],120);(out/'quantize-execution.json').write_text(json.dumps(dict(execution=execution,builds=builds,compile=compile,link=link),indent=2));assert execution['exitCode']==0,(out/'process.log').read_text(errors='replace')[-2500:]
assert inputs(root)==before and all(digest(Path(path))==sha for path,sha in products.items())
print((out/'quantization-result.json').read_text(),flush=True)
