from pathlib import Path
import os,json,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import guarded_run
from build_provenance import inputs,digest
before=inputs(root);commands=[];os.environ['PATH']=str(root/'build/ninja-msvc-release')+';'+os.environ['PATH'];os.environ['TEMP']=os.environ['TMP']=str(root/'build/maintenance/test-tmp')
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
for name,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 os.environ['VK_LOADER_DRIVERS_SELECT']=driver;r=guarded_run(root/'build',out.name,[str(out/'calibration.exe'),str(out/'calibration-inputs.json'),str(root/'build/ninja-msvc-release/shaders')],120)
 (out/(name+'-calibration.log')).write_bytes((out/'process.log').read_bytes());commands.append(dict(device=name,**r));assert (out/(name+'-calibration.json')).is_file()
 report=json.loads((out/(name+'-calibration.json')).read_text());assert report['validationErrors']==0 and report['zeroAllocator'];print(json.dumps(dict(device=name,exitCode=r['exitCode'],exact=report['exactPixels'],withinOne=report['withinOnePixels'],maximum=report['maximumByteError'])),flush=True)
 if name=='nvidia':assert r['exitCode']==0 and report['exactPixels']==17017
 assert inputs(root)==before
(out/'calibration-execution.json').write_text(json.dumps(commands,indent=2));(out/'calibration-source-inputs.json').write_text(json.dumps(before,indent=2))
