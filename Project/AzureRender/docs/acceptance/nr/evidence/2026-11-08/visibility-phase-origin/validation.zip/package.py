from pathlib import Path
import json,hashlib,sys,subprocess,zipfile,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs,verify
builds=json.loads((out/'production-builds.json').read_text());checks=json.loads((out/'production-tests.json').read_text());assert len(builds)==2 and len(checks)==6 and all(r['exitCode']==0 for r in builds+checks)
assert 'Object visibility phase origin did not mirror image rows' in (out/'red-test.log').read_text(encoding='utf-8-sig')
nvidia=json.loads((out/'nvidia-calibration.json').read_text());intel=json.loads((out/'intel-calibration.json').read_text());assert nvidia['exactPixels']==17017 and intel['withinOnePixels']==16842
assert all(r['validationErrors']==0 and r['zeroAllocator'] for r in [nvidia,intel]);assert inputs(root)==json.loads((out/'calibration-source-inputs.json').read_text())
config=json.loads((out/'calibration-inputs.json').read_text());read_only={k:digest(Path(config[k])) for k in ['depth','normals','atlas','queries','expected']}
proof=[]
for config_name in ['release','debug']:
 p=root/f'build/ninja-msvc-{config_name}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config_name,status='passed',sha256=digest(p)))
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
sources=['src/render/ScreenObjectVisibility.hpp','src/render/ScreenObjectVisibility.cpp','shaders/screen_object_visibility.frag','tests/ScreenObjectVisibilityTests.cpp','tests/ScreenObjectVisibilityGpuTests.cpp']
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/visibility-phase-origin';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.cpp','.json','.log','.bin','.xml'] and p.stat().st_size<2*2**20}
for name in sources:members['source/'+name]=root/name
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in sorted(members.items()):archive.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as archive:
 assert archive.testzip() is None
 for name,path in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='phase-origin-mechanism-verified',sourceBase='a6d4e72',builds=builds,checks=checks,checkedPixelsPerGpuCase=1672,nvidiaDefaultRegion=nvidia,intelDefaultRegion=intel,readOnlyInputHashes=read_only,productionProvenance=proof,userDiffSha256=protected,sceneIntegrated=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=name,bytes=p.stat().st_size,sha256=digest(p)) for name,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-visibility-phase-origin.md','docs/acceptance/nr/visibility-phase-origin.md','docs/acceptance/nr/screen-object-visibility.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],checks=6,nvidiaDefaultExact=17017,intelPending=175,evidenceBytes=report['evidenceBytes'],userDiffPreserved=True)))
