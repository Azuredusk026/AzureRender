from pathlib import Path
import os,json,subprocess
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;old=root/'build/runs/20261108-045252-screen-object-visibility-ca2907'
(out/'calibration.cpp').write_bytes((old/'calibration.cpp').read_bytes());(out/'calibration-inputs.json').write_bytes((old/'calibration-inputs.json').read_bytes())
record=json.loads((old/'calibration-preparation.json').read_text());env=os.environ.copy();env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'))
commands={}
for name in ['compile','link']:
 command=[value.replace(str(old),str(out)) for value in record[name]]
 with (out/('calibration-'+name+'.log')).open('wb') as log:r=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 assert r.returncode==0,(out/('calibration-'+name+'.log')).read_text(errors='replace')[-2000:]
 commands[name]=command
(out/'calibration-build.json').write_text(json.dumps(commands,indent=2));print('Built calibration against current public phase interface',flush=True)
