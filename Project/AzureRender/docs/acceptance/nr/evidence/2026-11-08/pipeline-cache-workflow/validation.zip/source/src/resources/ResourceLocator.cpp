#include "ResourceLocator.hpp"
#include "foundation/Environment.hpp"

#include "diagnostics/RuntimeDiagnostics.hpp"

#include <cstdlib>
#include <algorithm>
#include <stdexcept>

#ifdef _WIN32
#include <windows.h>
#endif

namespace azurerender {

namespace {

std::filesystem::path processExecutableDirectory() {
#ifdef _WIN32
    std::wstring buffer(32768, L'\0');
    const DWORD length = GetModuleFileNameW(
        nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
    if (length != 0) {
        buffer.resize(length);
        return std::filesystem::path(buffer).parent_path();
    }
#else
    std::error_code error;
    const auto path = std::filesystem::read_symlink("/proc/self/exe", error);
    if (!error) {
        return path.parent_path();
    }
#endif
    return std::filesystem::current_path();
}

void appendUnique(
    std::vector<std::filesystem::path>& roots,
    std::filesystem::path root) {
    if (root.empty()) return;
    root = std::filesystem::weakly_canonical(root);
    if (std::find(roots.begin(), roots.end(), root) == roots.end()) {
        roots.push_back(std::move(root));
    }
}

}  // namespace

std::filesystem::path ResourceLocator::executableDirectory() { return processExecutableDirectory(); }
std::filesystem::path ResourceLocator::installationRoot() const {
    const auto executable=processExecutableDirectory();
    const auto root=std::filesystem::weakly_canonical(executable/"..");
    if(std::filesystem::is_regular_file(root/"share/AzureRender/runtime-build.json"))return root;
    return {};
}
ResourceLocator::ResourceLocator(std::filesystem::path explicitRoot) {
    if (explicitRoot.empty()) {
        if (const auto environment = environmentPath("AZURERENDER_RESOURCE_ROOT")) {
            explicitRoot = *environment;
        }
    }
    if (!explicitRoot.empty()) {
        appendUnique(roots_, std::move(explicitRoot));
    }
    const auto executable = processExecutableDirectory();
    appendUnique(roots_, executable);
    appendUnique(roots_, executable / "../share/AzureRender");
    // An installation has a closed resource boundary; missing files stay missing.
    const bool installed=std::filesystem::is_regular_file(executable/"../share/AzureRender/runtime-build.json");
    if(!installed) {
#ifdef AZURERENDER_DEVELOPMENT_ROOT
        appendUnique(roots_, AZURERENDER_DEVELOPMENT_ROOT);
#endif
        appendUnique(roots_, std::filesystem::current_path());
    }
}

std::filesystem::path ResourceLocator::find(
    const std::filesystem::path& relative,
    const char* type) const {
    for (const auto& root : roots_) {
        const auto candidate = root / relative;
        if (std::filesystem::exists(candidate)) {
            return candidate;
        }
    }
    std::string searched;
    for (const auto& root : roots_) {
        searched += "\n  " + (root / relative).u8string();
    }
    throw std::runtime_error(
        std::string("Missing ") + type + " resource '" + relative.u8string()
        + "'; searched:" + searched);
}

std::filesystem::path ResourceLocator::shaderDirectory() const {
    return find("shaders", "shader directory");
}

std::filesystem::path ResourceLocator::publicAsset(
    const std::filesystem::path& relative) const {
    return find(std::filesystem::path("assets_public") / relative, "asset");
}

std::filesystem::path ResourceLocator::rampProfile() const {
    return publicAsset("toon_ramp_profiles.json");
}

std::filesystem::path ResourceLocator::rampAtlas() const {
    return publicAsset("toon_ramp_atlas.ppm");
}

std::filesystem::path ResourceLocator::showcaseLooks() const {
    return publicAsset("showcase_looks.json");
}

std::filesystem::path ResourceLocator::captureDirectory() const {
    for (const auto& root : roots_) {
        const auto candidate = root / "captures";
        if (std::filesystem::exists(candidate) || root == roots_.front()) {
            return candidate;
        }
    }
    return std::filesystem::current_path() / "captures";
}

std::filesystem::path ResourceLocator::generatedCacheDirectory(const std::filesystem::path& projectFile) const {
    if(projectFile.empty())return {};
#ifdef AZURERENDER_DEVELOPMENT_ROOT
    const std::filesystem::path development=AZURERENDER_DEVELOPMENT_ROOT;
    if(installationRoot().empty()&&std::filesystem::is_regular_file(development/"CMakeLists.txt"))
        return development/"build"/"cache";
#endif
    return std::filesystem::absolute(projectFile).parent_path()/".azure"/"cache";
}

std::filesystem::path ResourceLocator::resolveAsset(
    const std::filesystem::path& requested) const {
    if (requested.empty()) {
        return publicAsset("test_model.gltf");
    }
    if (requested.is_absolute() && std::filesystem::exists(requested)) {
        return requested;
    }
    if (std::filesystem::exists(requested)) {
        return std::filesystem::weakly_canonical(requested);
    }
    return publicAsset(requested);
}

}  // namespace azurerender
