from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,digest,inputs
proofs=[]
for config in ['release','debug']:
 receipt=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(receipt.read_text()))
 proofs.append(dict(configuration=config,sha256=digest(receipt),status='passed'))
protectedPaths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protectedPaths],stderr=subprocess.DEVNULL)).hexdigest()
assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
native=json.loads((out/'native-results.json').read_text());tests=json.loads((out/'production-tests.json').read_text())
assert len(native)==2 and all(r['status']=='passed' and r['allInputsUnchanged'] for r in native)
assert len(tests)==6 and all(r['exitCode']==0 for r in tests)
assert 'Ran 51 tests' in (out/'tool-tests.log').read_text() and '\nOK\n' in (out/'tool-tests.log').read_text()
assert all(json.loads((out/'cross-lock-result.json').read_text()).values())
owned=['CMakeLists.txt','src/app/AzureRenderApp.cpp','src/app/AzureRenderApp.hpp','src/resources/ResourceLocator.cpp','src/resources/ResourceLocator.hpp','src/rhi/VulkanRhi.cpp','src/rhi/VulkanRhi.hpp','src/rhi/PipelineCacheStore.cpp','src/rhi/PipelineCacheStore.hpp','src/rhi/VulkanPipelineCache.cpp','src/rhi/VulkanPipelineCache.hpp','tests/PipelineCacheStoreTests.cpp','tests/VulkanPipelineCacheTests.cpp','tests/ResourceLocatorTests.cpp','tools/artifact_pipeline_cache.py','tools/artifact_cache_cleanup.py','tools/artifact_maintenance.py','tools/test_artifact_pipeline_cache.py','tools/test_artifact_cache_cleanup.py']
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/pipeline-cache-workflow';evidence.mkdir(parents=True,exist_ok=True)
members={}
for path in out.iterdir():
 if path.is_file() and path.suffix in {'.py','.cpp','.json','.log','.xml'} and path.stat().st_size<2*2**20:members['run/'+path.name]=path
for name in owned:members['source/'+name]=root/name
for config in ['release','debug']:
 for name in ['build-provenance.json','Testing/Temporary/LastTest.log']:
  path=root/f'build/ninja-msvc-{config}'/name
  if path.is_file():members['build/'+config+'/'+name]=path
members['maintenance/daily-current.json']=root/'build/maintenance/daily-maintenance-latest.json'
members['maintenance/daily-budget.json']=root/'build/maintenance/cache-cleanup-daily-budget.json'
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in sorted(members.items()):archive.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as archive:
 assert archive.testzip() is None
 for name,path in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest(path)
cacheRoot=root/'build/cache/vulkan';cacheFiles=[dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=digest(p)) for p in cacheRoot.glob('*.azpc')]
cold=native[0]['timingsMilliseconds']['pipelines'];warm=native[1]['timingsMilliseconds']['pipelines']
daily=json.loads((out/'daily-full-slice.json').read_text());after=json.loads((root/'build/maintenance/daily-maintenance-latest.json').read_text())
report=dict(schemaVersion=1,status='accepted-bounded-pipeline-cache',sourceBase='8b6caac',prototype=json.loads((out/'result.json').read_text()),native=native,scopedChecks=12,scopedTests=tests,toolChecks=51,buildProvenance=proofs,userDiffSha256=protected,
 pipelineTaskReductionPercent=100*(1-warm/cold),pipelineTaskSavedMilliseconds=cold-warm,cacheFiles=cacheFiles,
 dailyMaintenance=dict(first=daily,remainingBudgetPass=after,removedFiles=daily['caches']['files']+after['caches']['files'],logicalBytes=daily['caches']['logicalBytes']+after['caches']['logicalBytes']),
 currentSourceInputs=inputs(root),formalFramePerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),
 members=[dict(path=name,bytes=p.stat().st_size,sha256=digest(p)) for name,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(status=report['status'],scopedChecks=12,toolChecks=51,cacheBytes=sum(p['bytes'] for p in cacheFiles),pipelineTaskReductionPercent=report['pipelineTaskReductionPercent'],dailyRemovedFiles=report['dailyMaintenance']['removedFiles'],evidenceBytes=report['evidenceBytes'],protectedDiff=protected)))
