from pathlib import Path
import subprocess,sys,os,json,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9')
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],env=env).returncode)
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
before=inputs(root);command=['cl.exe','/nologo','/std:c++17','/O2','/EHsc','/MD','/utf-8','/ID:/Tools/VulkanSDK/1.4.350.0/Include','/I'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'),'/Fo'+str(out/'cache_probe.obj'),'/Fe'+str(out/'cache_probe.exe'),str(out/'cache_probe.cpp'),'/link','/INCREMENTAL:NO','D:/Tools/VulkanSDK/1.4.350.0/Lib/vulkan-1.lib']
with (out/'build.log').open('wb') as log:result=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert result.returncode==0,(out/'build.log').read_text(errors='replace')[-4000:]
env=os.environ.copy();env['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';env['AZURE_PIPELINE_CACHE_FILE']=str(out/'application-cache.bin')
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
rows=[]
for mode in ['cold','warm']:
 env['AZURE_PIPELINE_CACHE_MODE']=mode
 run=[str(out/'cache_probe.exe'),str(root/'build/ninja-msvc-release/shaders/mesh_object_compute.vert.spv'),str(root/'build/ninja-msvc-release/shaders/mesh_object_bindless_clipmap_field_early.frag.spv'),str(out/(mode+'.json'))]
 start=time.monotonic()
 with (out/(mode+'.log')).open('wb') as log:result=subprocess.run(run,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 assert result.returncode==0,(out/(mode+'.log')).read_text(errors='replace')[-4000:]
 row=json.loads((out/(mode+'.json')).read_text());rows.append(row);print(json.dumps(row),flush=True)
 assert row['queueSubmissions']==0 and not row['validationErrors']
assert inputs(root)==before
(out/'result.json').write_text(json.dumps(dict(status='measured',rows=rows,compile=command,productionInputsUnchanged=True,cacheSha256=digest(out/'application-cache.bin')),indent=2))
