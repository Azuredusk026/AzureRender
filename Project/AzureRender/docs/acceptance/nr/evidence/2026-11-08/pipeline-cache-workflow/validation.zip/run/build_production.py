from pathlib import Path
import os,sys,subprocess,json,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
before=inputs(root);rows=[]
targets=['AzurePipelineCacheStoreTests','AzureVulkanPipelineCacheTests','AzureTemporalViewGpuTests','AzureRenderResourceLocatorTests']
for config in ['Release','Debug']:
 build=root/('build/ninja-msvc-'+config.lower());command=[str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(build),'--config',config]
 for name in targets:command+=['--test-target',name]
 start=time.monotonic()
 with (out/(config.lower()+'-build.log')).open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 rows.append(dict(configuration=config,command=command,exitCode=result.returncode,seconds=time.monotonic()-start));(out/'production-builds.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
 assert result.returncode==0,config+' build failed';assert inputs(root)==before
