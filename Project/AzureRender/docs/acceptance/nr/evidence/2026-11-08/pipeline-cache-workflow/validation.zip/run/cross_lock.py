from pathlib import Path
import ctypes as c
from ctypes import wintypes as w
import json,sys
out=Path(__file__).resolve().parent;root=Path.cwd().resolve();sys.path.insert(0,str(root/'tools'))
from artifact_pipeline_cache import pool_lock,clean
class Overlapped(c.Structure):
 _fields_=[('Internal',c.c_size_t),('InternalHigh',c.c_size_t),('Offset',w.DWORD),('OffsetHigh',w.DWORD),('hEvent',w.HANDLE)]
kernel=c.WinDLL('kernel32',use_last_error=True)
kernel.CreateFileW.argtypes=[w.LPCWSTR,w.DWORD,w.DWORD,w.LPVOID,w.DWORD,w.DWORD,w.HANDLE];kernel.CreateFileW.restype=w.HANDLE
kernel.LockFileEx.argtypes=[w.HANDLE,w.DWORD,w.DWORD,w.DWORD,w.DWORD,c.POINTER(Overlapped)];kernel.LockFileEx.restype=w.BOOL
kernel.UnlockFileEx.argtypes=[w.HANDLE,w.DWORD,w.DWORD,w.DWORD,c.POINTER(Overlapped)];kernel.UnlockFileEx.restype=w.BOOL
kernel.CloseHandle.argtypes=[w.HANDLE];kernel.CloseHandle.restype=w.BOOL
build=out/'lock-fixture/build';directory=build/'cache/vulkan';directory.mkdir(parents=True,exist_ok=True)
handle=kernel.CreateFileW(str(directory/'.pool.lock'),0xc0000000,3,None,4,0x80,None)
assert handle!=c.c_void_p(-1).value
state=Overlapped();nativeBlocksPython=False;pythonBlocksNative=False
try:
 assert kernel.LockFileEx(handle,3,0,1,0,c.byref(state))
 try:nativeBlocksPython=clean(build,apply=True,tracked=set())['status']=='busy'
 finally:assert kernel.UnlockFileEx(handle,0,1,0,c.byref(state))
 with pool_lock(directory) as locked:
  assert locked
  acquired=kernel.LockFileEx(handle,3,0,1,0,c.byref(state));pythonBlocksNative=not acquired and c.get_last_error()==33
  if acquired:kernel.UnlockFileEx(handle,0,1,0,c.byref(state))
finally:kernel.CloseHandle(handle)
report=dict(nativeLockBlocksMaintenance=nativeBlocksPython,maintenanceLockBlocksNativeWriter=pythonBlocksNative)
(out/'cross-lock-result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report));assert all(report.values())
