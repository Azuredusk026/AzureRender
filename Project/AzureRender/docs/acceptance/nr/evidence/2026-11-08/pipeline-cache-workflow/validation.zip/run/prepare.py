from pathlib import Path
import sys,json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs
before=inputs(root)
s=(root/'build/runs/20261107-181940-direct-pipeline-executables-144edf/probe.cpp').read_text()
s='#include <chrono>\n#include <filesystem>\n#include <cstdlib>\n'+s
needle='executableFeature.pNext=&feature12;';assert s.count(needle)==1
s=s.replace(needle,'VkPhysicalDeviceVulkan13Features feature13{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES};feature12.pNext=&feature13;'+needle)
needle='    VkPipeline pipeline{};VkShaderModule fragment{};VkRenderPass renderPass{};';assert s.count(needle)==1
setup=r'''
    const char* modeValue=std::getenv("AZURE_PIPELINE_CACHE_MODE");const std::string cacheMode=modeValue?modeValue:"cold";
    const char* fileValue=std::getenv("AZURE_PIPELINE_CACHE_FILE");if(!fileValue)throw std::runtime_error("Cache path required");
    std::filesystem::path cachePath=std::filesystem::u8path(fileValue);std::vector<char> initialData;
    if(cacheMode=="warm"){
        const auto bytes=std::filesystem::file_size(cachePath);if(!bytes||bytes>16*1024*1024)throw std::runtime_error("Cache size exceeds probe budget");
        initialData.resize(static_cast<std::size_t>(bytes));std::ifstream input(cachePath,std::ios::binary);if(!input.read(initialData.data(),static_cast<std::streamsize>(bytes)))throw std::runtime_error("Cache read failed");
    }
    VkPipelineCacheCreateInfo cacheInfo{VK_STRUCTURE_TYPE_PIPELINE_CACHE_CREATE_INFO};cacheInfo.initialDataSize=initialData.size();cacheInfo.pInitialData=initialData.data();
    VkPipelineCache pipelineCache{};check(vkCreatePipelineCache(device,&cacheInfo,nullptr,&pipelineCache),"create cache");
    VkPipelineCreationFeedback feedback{};VkPipelineCreationFeedbackCreateInfo feedbackInfo{VK_STRUCTURE_TYPE_PIPELINE_CREATION_FEEDBACK_CREATE_INFO};feedbackInfo.pPipelineCreationFeedback=&feedback;
    VkResult creationResult=VK_SUCCESS;double creationMs=0;bool noCompileRequested=false;
'''
s=s.replace(needle,setup+'\n'+needle)
needle='check(vkCreateGraphicsPipelines(device,VK_NULL_HANDLE,1,&gp,nullptr,&pipeline),"create graphics pipeline");';assert s.count(needle)==1
s=s.replace(needle,r'''gp.flags=0;gp.pNext=&feedbackInfo;
        noCompileRequested=cacheMode=="warm"&&feature13.pipelineCreationCacheControl;
        if(noCompileRequested)gp.flags|=VK_PIPELINE_CREATE_FAIL_ON_PIPELINE_COMPILE_REQUIRED_BIT;
        const auto creationStart=std::chrono::steady_clock::now();
        creationResult=vkCreateGraphicsPipelines(device,pipelineCache,1,&gp,nullptr,&pipeline);
        creationMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-creationStart).count();
        if(creationResult!=VK_SUCCESS&&creationResult!=VK_PIPELINE_COMPILE_REQUIRED)check(creationResult,"create graphics pipeline");''')
start=s.index('    VkPipelineInfoKHR info{');end=s.index('    vkDestroyPipeline(device,pipeline,nullptr);',start)
report=r'''
    std::size_t cacheBytes=0;check(vkGetPipelineCacheData(device,pipelineCache,&cacheBytes,nullptr),"cache size");
    if(cacheBytes>16*1024*1024)throw std::runtime_error("Generated cache exceeds probe budget");
    std::vector<char> persisted(cacheBytes);check(vkGetPipelineCacheData(device,pipelineCache,&cacheBytes,persisted.data()),"cache data");
    if(cacheMode=="cold"){std::ofstream file(cachePath,std::ios::binary);file.write(persisted.data(),static_cast<std::streamsize>(cacheBytes));if(!file)throw std::runtime_error("Cache save failed");}
    const bool feedbackValid=(feedback.flags&VK_PIPELINE_CREATION_FEEDBACK_VALID_BIT)!=0;
    json report={{"device",properties.deviceName},{"driverVersion",properties.driverVersion},{"mode",cacheMode},{"initialBytes",initialData.size()},{"persistedBytes",cacheBytes},{"creationResult",creationResult},{"creationMs",creationMs},{"feedbackValid",feedbackValid},{"feedbackFlags",feedback.flags},{"applicationCacheHit",feedbackValid&&(feedback.flags&VK_PIPELINE_CREATION_FEEDBACK_APPLICATION_PIPELINE_CACHE_HIT_BIT)!=0},{"noCompileRequested",noCompileRequested},{"driverDurationNs",feedback.duration},{"queueSubmissions",0}};
'''
s=s[:start]+report+s[end:]
s=s.replace('vkDestroyDevice(device,nullptr);','vkDestroyPipelineCache(device,pipelineCache,nullptr);vkDestroyDevice(device,nullptr);')
s=s.replace('Private compilation fixture with explicit ordinary-opaque specialization; no native pipeline identity or frame timing claim','Private application-cache reuse fixture with ordinary-opaque specialization; no queue submissions or full native startup timing claim')
(out/'cache_probe.cpp').write_text(s);assert inputs(root)==before
print(json.dumps(dict(status='prepared',productionInputsUnchanged=True)))
