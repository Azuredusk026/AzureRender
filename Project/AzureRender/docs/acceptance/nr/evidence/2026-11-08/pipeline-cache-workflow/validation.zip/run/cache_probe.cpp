#include <chrono>
#include <filesystem>
#include <cstdlib>
#include <vulkan/vulkan.h>
#include <nlohmann/json.hpp>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using nlohmann::json;
std::vector<std::string> validationErrors;
VkBool32 VKAPI_CALL validation(VkDebugUtilsMessageSeverityFlagBitsEXT severity,VkDebugUtilsMessageTypeFlagsEXT,const VkDebugUtilsMessengerCallbackDataEXT* data,void*){if(severity&VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT)validationErrors.emplace_back(data->pMessage);std::cerr<<data->pMessage<<'\n';return VK_FALSE;}

void check(VkResult result,const char* operation){if(result!=VK_SUCCESS)throw std::runtime_error(std::string(operation)+": "+std::to_string(result));}
int main(int argc,char** argv)try{
    if(argc!=3&&argc!=4&&argc!=5)throw std::runtime_error("Expected compute input/report or vertex/fragment/report"); const bool graphics=argc>=4;const bool uniformProfiles=argc==5;
    VkApplicationInfo application{VK_STRUCTURE_TYPE_APPLICATION_INFO};application.apiVersion=VK_API_VERSION_1_3;
    VkInstanceCreateInfo instanceInfo{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};instanceInfo.pApplicationInfo=&application;
    const char* validationLayer="VK_LAYER_KHRONOS_validation";const char* debugExtension=VK_EXT_DEBUG_UTILS_EXTENSION_NAME;
    instanceInfo.enabledLayerCount=1;instanceInfo.ppEnabledLayerNames=&validationLayer;instanceInfo.enabledExtensionCount=1;instanceInfo.ppEnabledExtensionNames=&debugExtension;
    VkDebugUtilsMessengerCreateInfoEXT debug{VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT};debug.messageSeverity=VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT|VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT;debug.messageType=VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT|VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT|VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT;debug.pfnUserCallback=validation;instanceInfo.pNext=&debug;
    VkInstance instance{};check(vkCreateInstance(&instanceInfo,nullptr,&instance),"create instance");VkDebugUtilsMessengerEXT messenger{};auto createMessenger=reinterpret_cast<PFN_vkCreateDebugUtilsMessengerEXT>(vkGetInstanceProcAddr(instance,"vkCreateDebugUtilsMessengerEXT"));auto destroyMessenger=reinterpret_cast<PFN_vkDestroyDebugUtilsMessengerEXT>(vkGetInstanceProcAddr(instance,"vkDestroyDebugUtilsMessengerEXT"));if(!createMessenger||!destroyMessenger)throw std::runtime_error("Debug entry missing");check(createMessenger(instance,&debug,nullptr,&messenger),"create messenger");
    std::uint32_t count=0;check(vkEnumeratePhysicalDevices(instance,&count,nullptr),"enumerate devices");
    std::vector<VkPhysicalDevice> devices(count);check(vkEnumeratePhysicalDevices(instance,&count,devices.data()),"get devices");
    VkPhysicalDevice physical{};VkPhysicalDeviceProperties properties{};
    for(auto candidate:devices){vkGetPhysicalDeviceProperties(candidate,&properties);if(properties.vendorID==0x10de){physical=candidate;break;}}
    if(!physical)throw std::runtime_error("No NVIDIA device");
    check(vkEnumerateDeviceExtensionProperties(physical,nullptr,&count,nullptr),"enumerate extensions");
    std::vector<VkExtensionProperties> extensions(count);check(vkEnumerateDeviceExtensionProperties(physical,nullptr,&count,extensions.data()),"get extensions");
    bool available=std::any_of(extensions.begin(),extensions.end(),[](const auto& e){return std::string(e.extensionName)==VK_KHR_PIPELINE_EXECUTABLE_PROPERTIES_EXTENSION_NAME;});
    if(!available)throw std::runtime_error("Executable properties extension unavailable");
    VkPhysicalDevicePipelineExecutablePropertiesFeaturesKHR executableFeature{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PIPELINE_EXECUTABLE_PROPERTIES_FEATURES_KHR};
    VkPhysicalDeviceFeatures2 features{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};VkPhysicalDeviceVulkan12Features feature12{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES};VkPhysicalDeviceVulkan13Features feature13{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES};feature12.pNext=&feature13;executableFeature.pNext=&feature12;features.pNext=&executableFeature;vkGetPhysicalDeviceFeatures2(physical,&features);
    if(!executableFeature.pipelineExecutableInfo)throw std::runtime_error("Executable feature unavailable");
    vkGetPhysicalDeviceQueueFamilyProperties(physical,&count,nullptr);std::vector<VkQueueFamilyProperties> families(count);vkGetPhysicalDeviceQueueFamilyProperties(physical,&count,families.data());
    auto family=std::find_if(families.begin(),families.end(),[](auto& q){return (q.queueFlags&(VK_QUEUE_COMPUTE_BIT|VK_QUEUE_GRAPHICS_BIT))==(VK_QUEUE_COMPUTE_BIT|VK_QUEUE_GRAPHICS_BIT);});
    if(family==families.end())throw std::runtime_error("Compute queue unavailable");
    float priority=1;VkDeviceQueueCreateInfo queue{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};queue.queueFamilyIndex=static_cast<unsigned>(family-families.begin());queue.queueCount=1;queue.pQueuePriorities=&priority;
    const char* extension=VK_KHR_PIPELINE_EXECUTABLE_PROPERTIES_EXTENSION_NAME;
    VkDeviceCreateInfo deviceInfo{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};deviceInfo.pNext=&executableFeature;deviceInfo.queueCreateInfoCount=1;deviceInfo.pQueueCreateInfos=&queue;deviceInfo.enabledExtensionCount=1;deviceInfo.ppEnabledExtensionNames=&extension;deviceInfo.pEnabledFeatures=&features.features;
    VkDevice device{};check(vkCreateDevice(physical,&deviceInfo,nullptr,&device),"create device");
    auto queryProperties=reinterpret_cast<PFN_vkGetPipelineExecutablePropertiesKHR>(vkGetDeviceProcAddr(device,"vkGetPipelineExecutablePropertiesKHR"));
    auto queryStatistics=reinterpret_cast<PFN_vkGetPipelineExecutableStatisticsKHR>(vkGetDeviceProcAddr(device,"vkGetPipelineExecutableStatisticsKHR"));
    auto queryRepresentations=reinterpret_cast<PFN_vkGetPipelineExecutableInternalRepresentationsKHR>(vkGetDeviceProcAddr(device,"vkGetPipelineExecutableInternalRepresentationsKHR"));
    if(!queryProperties||!queryStatistics||!queryRepresentations)throw std::runtime_error("Required executable query missing");
    VkDescriptorSetLayoutBinding bindings[2]={{0,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_COMPUTE_BIT,nullptr},{1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT,nullptr}};
    std::vector<VkDescriptorSetLayoutBinding> graphicsBindings;
    if(graphics){
        const auto add=[&](unsigned binding,VkDescriptorType type,unsigned n,VkShaderStageFlags stage){graphicsBindings.push_back({binding,type,n,stage,nullptr});};
        add(0,VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,1,VK_SHADER_STAGE_VERTEX_BIT|VK_SHADER_STAGE_FRAGMENT_BIT);
        add(1,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,4096,VK_SHADER_STAGE_FRAGMENT_BIT);
        for(unsigned binding:{10u,13u,17u,21u,22u,30u})add(binding,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_VERTEX_BIT);
        for(unsigned binding:{14u,15u,16u,20u,24u,27u,33u,34u})add(binding,uniformProfiles&&binding==27?VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER:VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT);
        for(unsigned binding:{18u,19u,23u,26u,35u,36u})add(binding,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_FRAGMENT_BIT);
        add(31,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,512,VK_SHADER_STAGE_VERTEX_BIT);
        add(32,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,6,VK_SHADER_STAGE_FRAGMENT_BIT);
        add(9,VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE,1,VK_SHADER_STAGE_FRAGMENT_BIT);add(29,VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE,1,VK_SHADER_STAGE_FRAGMENT_BIT);
        add(28,VK_DESCRIPTOR_TYPE_SAMPLER,1,VK_SHADER_STAGE_FRAGMENT_BIT);add(37,VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,1,VK_SHADER_STAGE_FRAGMENT_BIT);
    }
    VkDescriptorSetLayoutCreateInfo setInfo{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};setInfo.bindingCount=2;setInfo.pBindings=bindings;if(graphics){setInfo.bindingCount=static_cast<unsigned>(graphicsBindings.size());setInfo.pBindings=graphicsBindings.data();}
    VkDescriptorSetLayout set{};check(vkCreateDescriptorSetLayout(device,&setInfo,nullptr,&set),"create descriptor layout");
    VkPipelineLayoutCreateInfo layoutInfo{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};layoutInfo.setLayoutCount=1;layoutInfo.pSetLayouts=&set;VkPushConstantRange push{VK_SHADER_STAGE_VERTEX_BIT|VK_SHADER_STAGE_FRAGMENT_BIT,0,212};if(graphics){layoutInfo.pushConstantRangeCount=1;layoutInfo.pPushConstantRanges=&push;}
    VkPipelineLayout layout{};check(vkCreatePipelineLayout(device,&layoutInfo,nullptr,&layout),"create pipeline layout");
    std::ifstream input(argv[1],std::ios::binary|std::ios::ate);if(!input)throw std::runtime_error("Input open failed");auto size=input.tellg();if(size<=0||size>4*1024*1024||size%4)throw std::runtime_error("Invalid SPIR-V size");
    input.seekg(0);std::vector<std::uint32_t> words(static_cast<std::size_t>(size)/4);if(!input.read(reinterpret_cast<char*>(words.data()),size))throw std::runtime_error("Input read failed");
    VkShaderModuleCreateInfo moduleInfo{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};moduleInfo.codeSize=static_cast<std::size_t>(size);moduleInfo.pCode=words.data();
    VkShaderModule shader{};check(vkCreateShaderModule(device,&moduleInfo,nullptr,&shader),"create shader");
    VkComputePipelineCreateInfo pipelineInfo{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};pipelineInfo.layout=layout;pipelineInfo.flags=VK_PIPELINE_CREATE_CAPTURE_STATISTICS_BIT_KHR|VK_PIPELINE_CREATE_CAPTURE_INTERNAL_REPRESENTATIONS_BIT_KHR;pipelineInfo.stage={VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};pipelineInfo.stage.stage=VK_SHADER_STAGE_COMPUTE_BIT;pipelineInfo.stage.module=shader;pipelineInfo.stage.pName="main";

    const char* modeValue=std::getenv("AZURE_PIPELINE_CACHE_MODE");const std::string cacheMode=modeValue?modeValue:"cold";
    const char* fileValue=std::getenv("AZURE_PIPELINE_CACHE_FILE");if(!fileValue)throw std::runtime_error("Cache path required");
    std::filesystem::path cachePath=std::filesystem::u8path(fileValue);std::vector<char> initialData;
    if(cacheMode=="warm"){
        const auto bytes=std::filesystem::file_size(cachePath);if(!bytes||bytes>16*1024*1024)throw std::runtime_error("Cache size exceeds probe budget");
        initialData.resize(static_cast<std::size_t>(bytes));std::ifstream input(cachePath,std::ios::binary);if(!input.read(initialData.data(),static_cast<std::streamsize>(bytes)))throw std::runtime_error("Cache read failed");
    }
    VkPipelineCacheCreateInfo cacheInfo{VK_STRUCTURE_TYPE_PIPELINE_CACHE_CREATE_INFO};cacheInfo.initialDataSize=initialData.size();cacheInfo.pInitialData=initialData.data();
    VkPipelineCache pipelineCache{};check(vkCreatePipelineCache(device,&cacheInfo,nullptr,&pipelineCache),"create cache");
    VkPipelineCreationFeedback feedback{};VkPipelineCreationFeedbackCreateInfo feedbackInfo{VK_STRUCTURE_TYPE_PIPELINE_CREATION_FEEDBACK_CREATE_INFO};feedbackInfo.pPipelineCreationFeedback=&feedback;
    VkResult creationResult=VK_SUCCESS;double creationMs=0;bool noCompileRequested=false;

    VkPipeline pipeline{};VkShaderModule fragment{};VkRenderPass renderPass{};
    if(!graphics)check(vkCreateComputePipelines(device,VK_NULL_HANDLE,1,&pipelineInfo,nullptr,&pipeline),"create pipeline");
    else{
        std::ifstream f(argv[2],std::ios::binary|std::ios::ate);if(!f)throw std::runtime_error("Fragment open failed");auto bytes=f.tellg();if(bytes<=0||bytes>4*1024*1024||bytes%4)throw std::runtime_error("Invalid fragment size");f.seekg(0);std::vector<std::uint32_t> code(static_cast<std::size_t>(bytes)/4);if(!f.read(reinterpret_cast<char*>(code.data()),bytes))throw std::runtime_error("Fragment read failed");moduleInfo.codeSize=static_cast<std::size_t>(bytes);moduleInfo.pCode=code.data();check(vkCreateShaderModule(device,&moduleInfo,nullptr,&fragment),"create fragment");
        VkAttachmentDescription attachments[4]{};const VkFormat formats[4]={VK_FORMAT_R8G8B8A8_SRGB,VK_FORMAT_R32G32B32A32_SFLOAT,VK_FORMAT_R8_UNORM,VK_FORMAT_D32_SFLOAT};
        for(unsigned i=0;i<4;++i){attachments[i].format=formats[i];attachments[i].samples=VK_SAMPLE_COUNT_1_BIT;attachments[i].loadOp=VK_ATTACHMENT_LOAD_OP_DONT_CARE;attachments[i].storeOp=VK_ATTACHMENT_STORE_OP_DONT_CARE;attachments[i].stencilLoadOp=VK_ATTACHMENT_LOAD_OP_DONT_CARE;attachments[i].stencilStoreOp=VK_ATTACHMENT_STORE_OP_DONT_CARE;attachments[i].initialLayout=VK_IMAGE_LAYOUT_UNDEFINED;attachments[i].finalLayout=i==3?VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL:VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;}
        VkAttachmentReference colors[3]={{0,VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL},{1,VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL},{2,VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL}},depth{3,VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
        VkSubpassDescription subpass{};subpass.pipelineBindPoint=VK_PIPELINE_BIND_POINT_GRAPHICS;subpass.colorAttachmentCount=3;subpass.pColorAttachments=colors;subpass.pDepthStencilAttachment=&depth;
        VkRenderPassCreateInfo passInfo{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};passInfo.attachmentCount=4;passInfo.pAttachments=attachments;passInfo.subpassCount=1;passInfo.pSubpasses=&subpass;check(vkCreateRenderPass(device,&passInfo,nullptr,&renderPass),"create render pass");
        VkPipelineShaderStageCreateInfo stages[2]{};for(auto& stage:stages){stage.sType=VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;stage.pName="main";}stages[0].stage=VK_SHADER_STAGE_VERTEX_BIT;stages[0].module=shader;stages[1].stage=VK_SHADER_STAGE_FRAGMENT_BIT;stages[1].module=fragment;
        VkBool32 ordinary=VK_TRUE;VkSpecializationMapEntry spec{0,0,sizeof(ordinary)};VkSpecializationInfo specialization{1,&spec,sizeof(ordinary),&ordinary};stages[1].pSpecializationInfo=&specialization;
        VkVertexInputBindingDescription vb[2]={{0,108,VK_VERTEX_INPUT_RATE_VERTEX},{1,0,VK_VERTEX_INPUT_RATE_VERTEX}};
        const VkFormat af[10]={VK_FORMAT_R32G32B32_SFLOAT,VK_FORMAT_R32G32B32_SFLOAT,VK_FORMAT_R32G32B32A32_SFLOAT,VK_FORMAT_R32G32_SFLOAT,VK_FORMAT_R32G32B32A32_UINT,VK_FORMAT_R32G32B32A32_SFLOAT,VK_FORMAT_R32G32B32_SFLOAT,VK_FORMAT_R32G32B32_SFLOAT,VK_FORMAT_R32_SFLOAT,VK_FORMAT_R32G32B32A32_SFLOAT};const unsigned offsets[10]={0,12,24,40,48,64,80,92,104,0};VkVertexInputAttributeDescription va[10]{};for(unsigned i=0;i<10;++i)va[i]={i,i==9?1u:0u,af[i],offsets[i]};
        VkPipelineVertexInputStateCreateInfo vi{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};vi.vertexBindingDescriptionCount=2;vi.pVertexBindingDescriptions=vb;vi.vertexAttributeDescriptionCount=10;vi.pVertexAttributeDescriptions=va;
        VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};ia.topology=VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
        VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};vp.viewportCount=1;vp.scissorCount=1;
        VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};rs.polygonMode=VK_POLYGON_MODE_FILL;rs.cullMode=VK_CULL_MODE_BACK_BIT;rs.frontFace=VK_FRONT_FACE_COUNTER_CLOCKWISE;rs.lineWidth=1;
        VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};ms.rasterizationSamples=VK_SAMPLE_COUNT_1_BIT;
        VkPipelineDepthStencilStateCreateInfo ds{VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO};ds.depthTestEnable=VK_TRUE;ds.depthWriteEnable=VK_TRUE;ds.depthCompareOp=VK_COMPARE_OP_LESS;
        VkPipelineColorBlendAttachmentState ba[3]{};for(auto& a:ba)a.colorWriteMask=15;ba[2].colorWriteMask=VK_COLOR_COMPONENT_R_BIT;VkPipelineColorBlendStateCreateInfo blend{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};blend.attachmentCount=3;blend.pAttachments=ba;
        VkDynamicState dynamic[2]={VK_DYNAMIC_STATE_VIEWPORT,VK_DYNAMIC_STATE_SCISSOR};VkPipelineDynamicStateCreateInfo dyn{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};dyn.dynamicStateCount=2;dyn.pDynamicStates=dynamic;
        VkGraphicsPipelineCreateInfo gp{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};gp.flags=pipelineInfo.flags;gp.stageCount=2;gp.pStages=stages;gp.pVertexInputState=&vi;gp.pInputAssemblyState=&ia;gp.pViewportState=&vp;gp.pRasterizationState=&rs;gp.pMultisampleState=&ms;gp.pDepthStencilState=&ds;gp.pColorBlendState=&blend;gp.pDynamicState=&dyn;gp.layout=layout;gp.renderPass=renderPass;gp.flags=0;gp.pNext=&feedbackInfo;
        noCompileRequested=cacheMode=="warm"&&feature13.pipelineCreationCacheControl;
        if(noCompileRequested)gp.flags|=VK_PIPELINE_CREATE_FAIL_ON_PIPELINE_COMPILE_REQUIRED_BIT;
        const auto creationStart=std::chrono::steady_clock::now();
        creationResult=vkCreateGraphicsPipelines(device,pipelineCache,1,&gp,nullptr,&pipeline);
        creationMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-creationStart).count();
        if(creationResult!=VK_SUCCESS&&creationResult!=VK_PIPELINE_COMPILE_REQUIRED)check(creationResult,"create graphics pipeline");
    }

    std::size_t cacheBytes=0;check(vkGetPipelineCacheData(device,pipelineCache,&cacheBytes,nullptr),"cache size");
    if(cacheBytes>16*1024*1024)throw std::runtime_error("Generated cache exceeds probe budget");
    std::vector<char> persisted(cacheBytes);check(vkGetPipelineCacheData(device,pipelineCache,&cacheBytes,persisted.data()),"cache data");
    if(cacheMode=="cold"){std::ofstream file(cachePath,std::ios::binary);file.write(persisted.data(),static_cast<std::streamsize>(cacheBytes));if(!file)throw std::runtime_error("Cache save failed");}
    const bool feedbackValid=(feedback.flags&VK_PIPELINE_CREATION_FEEDBACK_VALID_BIT)!=0;
    json report={{"device",properties.deviceName},{"driverVersion",properties.driverVersion},{"mode",cacheMode},{"initialBytes",initialData.size()},{"persistedBytes",cacheBytes},{"creationResult",creationResult},{"creationMs",creationMs},{"feedbackValid",feedbackValid},{"feedbackFlags",feedback.flags},{"applicationCacheHit",feedbackValid&&(feedback.flags&VK_PIPELINE_CREATION_FEEDBACK_APPLICATION_PIPELINE_CACHE_HIT_BIT)!=0},{"noCompileRequested",noCompileRequested},{"driverDurationNs",feedback.duration},{"queueSubmissions",0}};
    vkDestroyPipeline(device,pipeline,nullptr);if(renderPass)vkDestroyRenderPass(device,renderPass,nullptr);if(fragment)vkDestroyShaderModule(device,fragment,nullptr);vkDestroyShaderModule(device,shader,nullptr);vkDestroyPipelineLayout(device,layout,nullptr);vkDestroyDescriptorSetLayout(device,set,nullptr);vkDestroyPipelineCache(device,pipelineCache,nullptr);vkDestroyDevice(device,nullptr);destroyMessenger(instance,messenger,nullptr);vkDestroyInstance(instance,nullptr);report["validationErrors"]=validationErrors;
    if(graphics){report["fragmentInput"]=argv[2];report["scope"]="Private application-cache reuse fixture with ordinary-opaque specialization; no queue submissions or full native startup timing claim";}std::ofstream output(argv[graphics?3:2]);output<<report.dump(2)<<'\n';if(!output)throw std::runtime_error("Report write failed");std::cout<<report.dump()<<'\n';return validationErrors.empty()?0:2;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
