from pathlib import Path
import os,sys,tempfile,time,unittest
from unittest.mock import patch
root=Path.cwd().resolve();sys.path.insert(0,str(root/'tools'))
import artifact_pipeline_cache as cache
import artifact_maintenance as maintenance
class DailyBoundaries(unittest.TestCase):
 def setUp(self):
  base=Path(__file__).resolve().parent/'edge-fixtures';base.mkdir(exist_ok=True)
  self.temp=tempfile.TemporaryDirectory(dir=base);self.build=Path(self.temp.name)/'build';self.directory=self.build/'cache/vulkan';self.directory.mkdir(parents=True)
 def tearDown(self):self.temp.cleanup()
 def test_nested_cache_repository_is_protected(self):
  (self.directory.parent/'.git').write_text('gitdir: fixture')
  old=self.directory/'vk1-10de-28a0-1-000102030405060708090a0b0c0d0e0f.azpc';old.write_bytes(b'cache');stamp=time.time()-8*86400;os.utime(old,(stamp,stamp))
  result=cache.clean(self.build,apply=True,tracked=set())
  self.assertEqual(result['status'],'protected-repository');self.assertTrue(old.exists())
 def test_active_work_defers_daily_without_expired_tasks(self):
  with patch.object(maintenance,'active_processes',return_value=[dict(pid=777,name='AzurePlayer.exe')]),patch.object(cache,'clean',return_value={}) as clean:
   result=maintenance.daily(self.build,apply=True)
  self.assertEqual(result['managed']['status'],'deferred-active-work');clean.assert_not_called()
if __name__=='__main__':unittest.main()
