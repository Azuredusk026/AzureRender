from pathlib import Path
import json,os,sys,shutil,re
import numpy as np
from PIL import Image
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from artifact_maintenance import guarded_run
from build_provenance import digest,inputs
assert check(root/'build',run=out,planned=48*2**20)['allowed']
source=inputs(root);build=root/'build/ninja-msvc-release'
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}
lock=json.loads((root/'build/runs/20261107-171836-consolidated-preparation-images-374280/image/frozen-inputs.json').read_text())
assert all(Path(p).is_file() and digest(Path(p))==sha for p,sha in lock['project'].items())
reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint'
os.environ['PATH']=str(build)+';'+os.environ['PATH'];os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
rows=[]
for label,count in [('cold',4),('warm',1)]:
 image=out/('native-'+label);image.mkdir(exist_ok=True)
 command=json.loads((reference/'command.json').read_text());command[0]=str(build/'AzurePlayer.exe')
 for flag,value in [('--capture-frames',str(count)),('--capture-dir',str(image/'frames')),('--runtime-report',str(image/'runtime.json'))]:command[command.index(flag)+1]=value
 command+=['--resource-root',str(build)]
 (out/(label+'-command.json')).write_text(json.dumps(command,indent=2))
 execution=guarded_run(root/'build',out.name,command,600)
 shutil.copyfile(out/'process.log',out/(label+'-native.log'));frames=[]
 for path in sorted((image/'frames').glob('frame_*.png')):
  current=np.array(Image.open(path).convert('RGB'));old=np.array(Image.open(reference/'frames'/path.name).convert('RGB'));delta=np.abs(current.astype(np.int16)-old.astype(np.int16))
  frames.append(dict(frame=path.name,sha256=digest(path),changedPixels=int(np.any(delta,axis=2).sum()),maximumByteError=int(delta.max())))
 log=(out/(label+'-native.log')).read_text(errors='replace')
 cacheLines=[line for line in log.splitlines() if 'Pipeline cache ' in line]
 timings={name:float(value) for name,value in re.findall(r'Scene load ([\w-]+): ([\d.]+) ms',log)}
 unchanged=inputs(root)==source and all(digest(Path(p))==sha for p,sha in products.items()) and all(digest(Path(p))==sha for p,sha in lock['project'].items())
 passed=execution['exitCode']==0 and len(frames)==count and all(f['changedPixels']==0 for f in frames) and unchanged and 'Allocator after unload: buffers=0 images=0' in log and not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-'])
 rows.append(dict(label=label,status='passed' if passed else 'failed',execution=execution,frames=frames,timingsMilliseconds=timings,cacheLog=cacheLines,allInputsUnchanged=unchanged,formalPerformanceQualified=False))
 (out/'native-results.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
 assert passed,label+' native compatibility failed'
 assert 'state=stored' in '\n'.join(cacheLines),'Native cache did not persist'
 if label=='warm':assert any('state=loaded' in line for line in cacheLines),'Native cache did not load'
