from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
before=inputs(root);ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';rows=[]
for config in ['Release','Debug']:
 build=root/('build/ninja-msvc-'+config.lower())
 selections=[('cpu',None,r'^AzureRender\.(PipelineCacheStore|ResourceLocator)$'),('intel','*igvk64*',r'^AzureRender\.(VulkanPipelineCache|TemporalViewGpu)$'),('nvidia','*nv-vk64*',r'^AzureRender\.(VulkanPipelineCache|TemporalViewGpu)$')]
 for device,driver,pattern in selections:
  env=os.environ.copy();env['PATH']=str(build)+';'+env['PATH']
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
  if driver:env['VK_LOADER_DRIVERS_SELECT']=driver
  label=config.lower()+'-'+device;command=[ctest,'--test-dir',str(build),'-R',pattern,'--output-on-failure','--output-junit',str(out/(label+'.xml'))]
  start=time.monotonic()
  with (out/(label+'-tests.log')).open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
  rows.append(dict(configuration=config,device=device,command=command,exitCode=result.returncode,seconds=time.monotonic()-start))
  (out/'production-tests.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True)
  assert result.returncode==0,label+' failed'
 assert inputs(root)==before
print('12 scoped checks passed',flush=True)
