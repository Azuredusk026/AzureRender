from pathlib import Path
import json,os,traceback,time,struct,math,hashlib
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261108-111838-gpu-draw-stage-cost-4bb6b2'
analysis=json.loads((out/'analysis.json').read_text());bounds=json.loads((out/'bounds.json').read_text());event=min(r['event'] for r in analysis['rows'] if r['category'].startswith('main-'))-1
cap=None;c=None;report=dict(status='starting');started=time.monotonic()
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea/current_frame320.rdc'),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 c.SetFrameEvent(event,True);state=c.GetPipelineState();target=state.GetDepthTarget().resource;viewport=state.GetViewport(0)
 texture=next(t for t in c.GetTextures() if t.resourceId==target);assert texture.format.compCount==1 and texture.format.compByteWidth==4
 raw=bytes(c.GetTextureData(target,rd.Subresource()));assert len(raw)==texture.width*texture.height*4
 depth=struct.unpack('<'+'f'*(len(raw)//4),raw);rows=[]
 for row in bounds['rows']:
  b=row['ndcBounds'];result=dict(event=row['event'],outsideFrustum=row['outsideFrustum'],baselineMs=row['baselineMs'],conservativeDepthOccluded=False)
  if b and not row['outsideFrustum']:
   xs=sorted([viewport.x+(b[a]*.5+.5)*viewport.width for a in [0,3]])
   ys=sorted([viewport.y+(b[a]*.5+.5)*viewport.height for a in [1,4]])
   x0=max(0,int(math.floor(xs[0]))-1);x1=min(texture.width,int(math.ceil(xs[1]))+1)
   y0=max(0,int(math.floor(ys[0]))-1);y1=min(texture.height,int(math.ceil(ys[1]))+1)
   if x1>x0 and y1>y0 and 0<=b[2]<=b[5]<=1:
    farthest=max(depth[y*texture.width+x] for y in range(y0,y1) for x in range(x0,x1))
    result.update(rect=[x0,y0,x1,y1],nearestDepth=b[2],farthestOccluder=farthest,conservativeDepthOccluded=b[2]-1e-5>farthest)
  rows.append(result)
 report=dict(status='read',seconds=time.monotonic()-started,event=event,target=str(target),width=texture.width,height=texture.height,format=str(texture.format.Name()),depthSha256=hashlib.sha256(raw).hexdigest(),viewport={key:getattr(viewport,key) for key in ['x','y','width','height','minDepth','maxDepth']},rows=rows,newGpuTimingExecuted=False)
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'depth-coverage.json').write_text(json.dumps(report,indent=2));os._exit(0 if report['status']=='read' else 1)
