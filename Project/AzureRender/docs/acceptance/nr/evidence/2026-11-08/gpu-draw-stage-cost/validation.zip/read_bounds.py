from pathlib import Path
import json,os,traceback,time,struct,math
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261108-111838-gpu-draw-stage-cost-4bb6b2'
analysis=json.loads((out/'analysis.json').read_text());selected=sorted([r for r in analysis['rows'] if r['category']=='main-ordinary-early'],key=lambda r:r['baselineMs'],reverse=True)
cap=None;c=None;report=dict(status='starting');started=time.monotonic()
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea/current_frame320.rdc'),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 actions={}
 def walk(items):
  for action in items:actions[action.eventId]=action;walk(action.children)
 walk(c.GetRootActions());rows=[]
 for item in selected:
  action=actions[item['event']]
  if action.numInstances!=1:
   rows.append(dict(event=item['event'],baselineMs=item['baselineMs'],instanceCount=action.numInstances,ndcBounds=None,outsideFrustum=False,skipped='multi-instance'));continue
  c.SetFrameEvent(item['event'],True);mesh=c.GetPostVSData(0,0,rd.MeshDataStage.VSOut)
  assert mesh.format.compCount==4 and mesh.format.compByteWidth==4 and mesh.vertexByteStride>=16
  count=mesh.numIndices
  if mesh.indexByteStride:
   raw=bytes(c.GetBufferData(mesh.indexResourceId,mesh.indexByteOffset,count*mesh.indexByteStride))
   indices=list(struct.unpack('<'+('I' if mesh.indexByteStride==4 else 'H')*count,raw));indices=[i+mesh.baseVertex for i in indices]
  else:indices=list(range(count))
  assert indices and min(indices)>=0
  raw=bytes(c.GetBufferData(mesh.vertexResourceId,mesh.vertexByteOffset,(max(indices)+1)*mesh.vertexByteStride))
  positions=[struct.unpack_from('<4f',raw,i*mesh.vertexByteStride) for i in set(indices)]
  assert all(math.isfinite(v) for p in positions for v in p)
  planes=[all(p[3]+p[0]<0 for p in positions),all(p[3]-p[0]<0 for p in positions),all(p[3]+p[1]<0 for p in positions),all(p[3]-p[1]<0 for p in positions),all(p[2]<0 for p in positions),all(p[3]-p[2]<0 for p in positions)]
  bounds=None
  if all(p[3]>0 for p in positions):bounds=[min(p[a]/p[3] for p in positions) for a in range(3)]+[max(p[a]/p[3] for p in positions) for a in range(3)]
  rows.append(dict(event=item['event'],baselineMs=item['baselineMs'],instanceCount=action.numInstances,uniqueVertices=len(positions),numIndices=count,outsideFrustum=any(planes),outsidePlanes=planes,ndcBounds=bounds))
 report=dict(status='read',seconds=time.monotonic()-started,rows=rows,newGpuTimingExecuted=False)
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'bounds.json').write_text(json.dumps(report,indent=2));os._exit(0 if report['status']=='read' else 1)
