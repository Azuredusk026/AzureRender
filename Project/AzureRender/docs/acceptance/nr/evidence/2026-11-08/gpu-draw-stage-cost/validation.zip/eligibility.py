from pathlib import Path
import json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
analysis=json.loads((out/'analysis.json').read_text());coverage=json.loads((out/'depth-coverage.json').read_text());bounds=json.loads((out/'bounds.json').read_text())
assert coverage['status']==bounds['status']=='read' and len(coverage['rows'])==len(bounds['rows'])==508
table={r['event']:r for r in analysis['rows']}
occluded=[r for r in coverage['rows'] if r['conservativeDepthOccluded']]
conflicts=[dict(coverage=r,statistics=table[r['event']]) for r in coverage['rows'] if (r['conservativeDepthOccluded'] or r['outsideFrustum']) and table[r['event']]['pixelInvocations']>0]
outside=[r for r in coverage['rows'] if r['outsideFrustum']]
baseline=next(r['baselineMs'] for r in analysis['groups'] if r['category']=='main-ordinary-early')
cost=sum(r['baselineMs'] for r in occluded+outside)
report=dict(status='bounded-culling-proposal' if not conflicts else 'coverage-conflicts',ordinaryMainBaselineMs=baseline,occludedEvents=len(occluded),occludedBaselineMs=sum(r['baselineMs'] for r in occluded),outsideFrustumEvents=len(outside),outsideFrustumBaselineMs=sum(r['baselineMs'] for r in outside),candidateBaselineMs=cost,potentialHotspotWorkReduction=cost/baseline,conflicts=conflicts,scope='Exact post-VS vertex bounds, expanded pixel rectangles, pre-color depth, 1e-5 depth margin; production conservative world bounds and hierarchy costs remain unmeasured',newGpuTimingExecuted=False,formalPerformancePassed=False)
(out/'eligibility.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
assert not conflicts
