from pathlib import Path
import subprocess,os,json,time,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
before=inputs(root);capture=root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea/current_frame320.rdc';sha=digest(capture)
assert sha=='5cbfc0ecf9fa24a7a8d8949ed54c3fc3691b7a1a58075d68f63f257b34ca6942'
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
env=os.environ.copy();temporary=out/'tmp';temporary.mkdir(exist_ok=True);env.update(TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary),VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'read_bounds.py')];start=time.monotonic()
with (out/'bounds.log').open('wb') as log:r=subprocess.run(command,cwd=out,env=env,startupinfo=si,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert inputs(root)==before and digest(capture)==sha
result=json.loads((out/'bounds.json').read_text());print(json.dumps(dict(exitCode=r.returncode,status=result['status'],seconds=time.monotonic()-start,error=result.get('error'),rows=len(result.get('rows',[])))),flush=True)
(out/'bounds-execution.json').write_text(json.dumps(dict(command=command,exitCode=r.returncode,sourceInputsUnchanged=True,captureSha256=sha,seconds=time.monotonic()-start),indent=2))
raise SystemExit(r.returncode)
