from pathlib import Path
import json,os,traceback,time
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261108-111838-gpu-draw-stage-cost-4bb6b2'
capture=root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea/current_frame320.rdc'
cap=None;c=None;report=dict(status='starting');started=time.monotonic()
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(capture),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 descriptions={};selected=[]
 for counter in c.EnumerateCounters():
  if not 2<=int(counter)<=13:continue
  d=c.DescribeCounter(counter);descriptions[int(counter)]=dict(id=int(counter),name=str(d.name),description=str(d.description),unit=str(d.unit),resultType=str(d.resultType),byteWidth=d.resultByteWidth)
  selected.append(counter)
 assert selected,'No generic pipeline statistics available'
 rows=[]
 for measurement in c.FetchCounters(selected):
  description=descriptions[int(measurement.counter)]
  value=int(measurement.value.u64 if description['byteWidth']==8 else measurement.value.u32)
  rows.append(dict(event=measurement.eventId,counter=int(measurement.counter),name=description['name'],value=value))
 assert rows,'No pipeline statistics returned'
 report=dict(status='read',seconds=time.monotonic()-started,counters=list(descriptions.values()),rows=rows,newGpuTimingExecuted=False)
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'counters.json').write_text(json.dumps(report,indent=2))
 os._exit(0 if report['status']=='read' else 1)
