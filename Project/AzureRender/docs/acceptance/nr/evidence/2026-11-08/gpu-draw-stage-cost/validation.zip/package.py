from pathlib import Path
import json,sys,subprocess,hashlib,zipfile,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
analysis=json.loads((out/'analysis.json').read_text());eligibility=json.loads((out/'eligibility.json').read_text());assert not eligibility['conflicts'] and eligibility['potentialHotspotWorkReduction']>.2
proof=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,sha256=digest(p)))
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.json','.log']}
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/gpu-draw-stage-cost';evidence.mkdir(parents=True,exist_ok=True);package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='bounded-culling-proposal',sourceBase='0ac1a44',captureSha256=analysis['captureSha256'],counterEventCount=analysis['counterEventCount'],matchedEvents=analysis['matchedEvents'],groups=analysis['groups'],eligibility=eligibility,productionProvenance=proof,userDiffSha256=protected,sourceInputSetSha256=hashlib.sha256(json.dumps(inputs(root),sort_keys=True).encode()).hexdigest(),newGpuTimingExecuted=False,nativeBatchStarted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package))
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest=root/'docs/development/artifact-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'));data['milestones'].insert(0,dict(path='runs/'+out.name,name='GPU 绘制阶段归因',status='BoundedCullingProposal',sourceBase='0ac1a44',evidence='docs/acceptance/nr/gpu-draw-stage-cost.md',matchedEvents=1009,newGpuTimingExecuted=False));manifest.write_text(json.dumps(data,indent=2,ensure_ascii=False).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md']:
 p=root/name;text=p.read_text(encoding='utf-8');prefix='docs/acceptance/nr/' if name=='README.md' else '../acceptance/nr/'
 marker='gpu-transparent-index-sort.md)';start=text.index(marker);end=text.index('\n',start)
 line='[绘制阶段归因]('+prefix+'gpu-draw-stage-cost.md)定位保守遮挡候选，调用统计与实际片元结果保持一致。\n'
 assert line not in text;p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-gpu-draw-stage-cost.md','docs/acceptance/nr/gpu-draw-stage-cost.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],evidenceBytes=package.stat().st_size,userDiffPreserved=True)))
