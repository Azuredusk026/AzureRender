from pathlib import Path
from collections import defaultdict
import json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;runs=out.parent
counters=json.loads((out/'counters.json').read_text());assert counters['status']=='read'
table=defaultdict(dict)
for row in counters['rows']:
 assert row['counter'] not in table[row['event']]
 table[row['event']][row['counter']]=row['value']
scope=json.loads((runs/'20261108-092305-shadow-cost-scope-ef3182/eligibility-analysis.json').read_text())
profile=json.loads((runs/'20261107-122133-material-contribution-cost-c567b5/profile.json').read_text())
timing=json.loads((runs/'20261107-135517-replay-continuity-check-ceda91/control-state.json').read_text());assert timing['status']=='measured'
control=next(r for r in timing['timings'] if r['control']=='surface-shadow')
category={event:row['category'] for row in scope['groups'] for event in row['events']}
groups=defaultdict(lambda:dict(events=0,baselineMs=0.,ablationSavedMs=0.,inputVertices=0,inputPrimitives=0,vertexInvocations=0,pixelInvocations=0,samplesPassed=0,zeroPixelEvents=0,zeroPixelBaselineMs=0.,zeroPixelAblationSavedMs=0.,zeroSampleEvents=0,zeroSampleBaselineMs=0.))
rows=[]
for row in profile['rows']:
 if row['event'] not in category:continue
 event=row['event'];values=table[event];assert all(key in values for key in [2,3,7,8,12])
 key=str(event);b=(control['baselineBefore'][key]+control['baselineAfter'][key])/2;c=sum(t[key] for t in control['candidate'])/len(control['candidate'])
 result=dict(event=event,category=category[event],pipeline=row['pipeline'],program=row['program'],baselineMs=b,ablationSavedMs=b-c,inputVertices=values[2],inputPrimitives=values[3],samplesPassed=values[7],vertexInvocations=values[8],pixelInvocations=values[12]);rows.append(result)
 group=groups[category[event]];group['events']+=1;group['baselineMs']+=b;group['ablationSavedMs']+=b-c
 for name in ['inputVertices','inputPrimitives','samplesPassed','vertexInvocations','pixelInvocations']:group[name]+=result[name]
 if values[12]==0:
  group['zeroPixelEvents']+=1;group['zeroPixelBaselineMs']+=b;group['zeroPixelAblationSavedMs']+=b-c
 if values[7]==0:group['zeroSampleEvents']+=1;group['zeroSampleBaselineMs']+=b
assert len(rows)==1009
summary=[dict(category=key,**value) for key,value in groups.items()];summary.sort(key=lambda r:r['baselineMs'],reverse=True)
top=sorted(rows,key=lambda r:r['baselineMs'],reverse=True)[:20]
zeroVertex=[r for r in rows if r['category']=='main-ordinary-early' and r['vertexInvocations']==0]
zeroPixelTop=sorted([r for r in rows if r['category']=='main-ordinary-early' and r['pixelInvocations']==0],key=lambda r:r['baselineMs'],reverse=True)[:32]
report=dict(status='analyzed',captureSha256=scope['captureSha256'],counterEventCount=len(table),matchedEvents=len(rows),scope='pipeline-statistics-at-recorded-draws; qualified historical durations are context only',groups=summary,topEvents=top,zeroPixelTop=zeroPixelTop,ordinaryMainZeroVertexEvents=len(zeroVertex),ordinaryMainZeroVertexBaselineMs=sum(r['baselineMs'] for r in zeroVertex),rows=rows,newGpuTimingExecuted=False)
(out/'analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(zeroVertexEvents=len(zeroVertex),zeroVertexBaselineMs=sum(r['baselineMs'] for r in zeroVertex),zeroPixelTop=zeroPixelTop[:8]),indent=2),flush=True)
