from pathlib import Path
import json,sys,hashlib,subprocess,zipfile,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify
image=json.loads((out/'image-legal-blend/results.json').read_text());initial=json.loads((out/'image/results.json').read_text())
assert all(r['changedPixels']==0 and r['sha256']==r['referenceSha256'] for r in image['frames'])
assert all(image[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationLogClean','zeroAllocator'])
assert image['metadata']['surfaceRadianceSelection']['fastFrames']==0
cases=[];masked=[]
for name in ['nvidia.xml','intel.xml','blend-release-nvidia.xml','blend-release-intel.xml','blend-debug-nvidia.xml','blend-debug-intel.xml','release-default.xml','debug-default.xml']:
 for c in ET.parse(out/name).getroot().findall('testcase'):
  assert c.find('failure') is None
  cases.append(dict(receipt=name,name=c.attrib['name'],skipped=c.find('skipped') is not None,seconds=c.attrib['time']))
  if name.startswith('blend-') and c.attrib['name'].endswith('Gpu'):
   assert 'Masked integer attachment blending passed on ' in (c.findtext('system-out') or '')
   masked.append(name)
assert len(cases)==24 and sum(c['skipped'] for c in cases)==3
views=[]
for device in ['nvidia','intel']:
 d=json.loads((out/('view-'+device)/(device+'-summary.json')).read_text())
 assert d['status']=='passed' and d['validationErrors']==0 and d['zeroAllocator'] and len(d['checks'])==30
 views.append(dict(device=device,states=30,pairedComparisons=15,validationErrors=0,zeroAllocator=True))
for config in ['release','debug']:
 build=root/('build/ninja-msvc-'+config);verify(root,json.loads((build/'build-provenance.json').read_text()))
 baseline=json.loads((out/(config+'-baseline-shaders.json')).read_text())
 assert {p.name:digest(p) for p in (build/'shaders').glob('*.spv')}==baseline and len(baseline)==674
 cache=(build/'CMakeCache.txt').read_text()
 assert all('AZURE_ENABLE_SURFACE_RADIANCE_'+key+':BOOL=OFF' in cache for key in ['REUSE','DIAGNOSTICS','FRAME_SELECTION'])
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
userHash=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest()
assert userHash=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
sources=(out/'owned-entry-files.txt').read_text().splitlines()+['src/rhi/VulkanRhi.cpp','shaders/surface_radiance_selection_commit.comp','shaders/surface_radiance_validation.frag','src/scenes/CharacterRadianceSelection.inc','tests/SurfaceRadianceFrameSelectionTests.cpp']
assert len(set(sources))==18
cleanup=[json.loads((out/n).read_text()) for n in ['release-program-cleanup.json','debug-program-cleanup.json','disabled-tests-cleanup.json','identical-png-cleanup.json']]
assert all(r['status']=='applied' for r in cleanup)
members={}
for p in out.rglob('*'):
 if not p.is_file():continue
 relative=p.relative_to(out)
 if any(part in {'tmp','__pycache__'} for part in relative.parts):continue
 if p.suffix not in {'.py','.json','.log','.xml','.cpp','.hpp','.inc','.frag','.comp','.glsl','.spvasm','.txt','.gltf'}:continue
 if not 0<p.stat().st_size<=2*2**20:continue
 members['run/'+relative.as_posix()]=p
for name in sources:members['source/'+name]=root/name
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/radiance-validation-path';evidence.mkdir(parents=True,exist_ok=True);archive=evidence/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert archive.stat().st_size<8*2**20
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
analysis=json.loads((out/'program-analysis.json').read_text())
report=dict(schemaVersion=1,status='mechanism-validated-native-full-fallback-default-disabled',sourceBase='5fdd002',sourceHashes={name:digest(root/name) for name in sources},image=image,initialImage=initial,cases=cases,maskedBlendFlows=masked,views=views,programAnalysis=dict(minimumStaticInstructionReduction=analysis['minimumStaticInstructionReduction'],maximumFastImplicitLodOperations=analysis['maximumFastImplicitLodOperations'],scope=analysis['scope']),defaultPrograms=674,experimentalPrograms=740,frameSelectionEnabledByDefault=False,nativeLightweightActivationPassed=False,performanceTimingRuns=0,formalPerformanceResolution=[1920,1080],strictCompatibilityResolution=[2560,1440],cleanup=dict(files=sum(r['files'] for r in cleanup),logicalBytes=sum(r['logicalBytes'] for r in cleanup),volumeObservedDeltaBytes=sum(r['freeAfterBytes']-r['freeBeforeBytes'] for r in cleanup)),protectedUserDiffSha256=userHash,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=archive.stat().st_size,evidenceSha256=digest(archive),archivedPngCopies=0)
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'docs/development/artifact-manifest.json';d=json.loads(p.read_text(encoding='utf-8'))
d['milestones'].insert(0,dict(path='runs/'+out.name,name='同帧资格核验与照明消费',status='MechanismValidatedNativeFullFallbackDefaultDisabled',sourceBase='5fdd002',evidence='docs/acceptance/nr/radiance-validation-path.md',checksPassed=21,checksSkipped=3,pairedViewFlowsPassed=2,nativeFourFramesExact=True,nativeLightweightActivationPassed=False,performanceTimingRuns=0,reclaimedFiles=report['cleanup']['files'],formalPerformancePassed=False))
p.write_text(json.dumps(d,ensure_ascii=False,indent=2).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
p=root/'docs/plans/2026-11-08-radiance-frame-selection.md';s=p.read_text(encoding='utf-8')
for text in ['独立轻量片元程序只消费已生成的照明数据。','核对几何、节点透明度及特殊材质的资格边界。','处理图记录和直接记录共用相同依赖契约。','全部匹配、故意失配及特殊材质各验证回退。','窗口与独立视图核对输出、同步及释放。']:s=s.replace('- [ ] '+text,'- [x] '+text,1)
s+='\n## 原生激活结果\n\n[资格核验](../acceptance/nr/radiance-validation-path.md)保持严格四帧零差异。\n整数附件混合规则修正后的原生日志无验证错误。\n原生退役槽均使用完整着色，帧收益计时保持未启动。\n实验入口默认关闭，独立深度副本进入下一单元。\n'
p.write_text(s,encoding='utf-8',newline='\n')
for name,anchor,extra in [('README.md','[GPU 绘制选择](docs/acceptance/nr/gpu-predicate-draw-selection.md)通过六项所属检查，同帧资格与轻量照明接入继续实施。','[同帧资格核验](docs/acceptance/nr/radiance-validation-path.md)通过严格四帧及安全回退检查，原生轻量激活继续验收，实验入口默认关闭。'),('docs/plans/azure-engine-plan.md','当前按[管线选择计划](2026-11-08-radiance-frame-selection.md)接入同帧资格与轻量消费。','[同帧资格核验](../acceptance/nr/radiance-validation-path.md)保持严格四帧零差异。\n原生槽均选择完整回退，实验入口默认关闭。\n下一单元使用独立深度副本核对共面遮挡顺序。')]:
 p=root/name;s=p.read_text(encoding='utf-8');assert anchor in s;p.write_text(s.replace(anchor,extra,1),encoding='utf-8',newline='\n')
p=root/'CHANGELOG.md';s=p.read_text(encoding='utf-8');p.write_text(s.replace('# Changelog\n','# Changelog\n\n## 同帧资格核验 2026-11-08\n\n- 增加纯深度核验、GPU 完成标记及轻量照明管线。\n- 修正零颜色写入附件的混合状态，双设备相关检查通过。\n- 原生四帧保持一致，实际选择均为完整回退，实验入口默认关闭。\n- 接续范围见[资格核验验收](docs/acceptance/nr/radiance-validation-path.md)。\n',1),encoding='utf-8',newline='\n')
print(json.dumps(dict(status=report['status'],ctests=24,passed=21,skipped=3,cleanup=report['cleanup'],evidenceBytes=archive.stat().st_size)))
