from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;env=os.environ.copy();env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'),TMPDIR=str(out/'tmp'),SQLITE_TMPDIR=str(out/'tmp'))
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';rows=[]
for config in ['release','debug']:
 if config=='debug':
  r=subprocess.run([sys.executable,'-X','utf8',str(out/'build.py'),'Debug'],env=env);assert r.returncode==0
 for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  env['VK_LOADER_DRIVERS_SELECT']=driver;pattern=r'^AzureRender\.(SurfaceRadianceFrameSelection|SurfaceRadianceCacheGpu)$' if device=='nvidia' else r'^AzureRender\.SurfaceRadianceCacheGpu$'
  command=[ctest,'--test-dir',str(root/('build/ninja-msvc-'+config)),'-R',pattern,'--output-on-failure','--no-tests=error','--output-junit',str(out/('blend-'+config+'-'+device+'.xml'))]
  started=time.monotonic()
  with (out/('blend-'+config+'-'+device+'.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
  row=dict(configuration=config,device=device,command=command,exitCode=r.returncode,seconds=time.monotonic()-started);rows.append(row);(out/'blend-checks.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
  if r.returncode:print((out/('blend-'+config+'-'+device+'.log')).read_text(errors='replace')[-3000:]);raise SystemExit(r.returncode)
