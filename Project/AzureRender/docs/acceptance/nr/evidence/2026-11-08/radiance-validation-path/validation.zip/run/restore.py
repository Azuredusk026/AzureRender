from pathlib import Path
import sys,subprocess
out=Path(__file__).resolve().parent
for config in ['Release','Debug']:
 r=subprocess.run([sys.executable,'-X','utf8',str(out/'final_build.py'),config]);assert r.returncode==0
for script in ['final_checks.py','cleanup_tests.py']:
 r=subprocess.run([sys.executable,'-X','utf8',str(out/script)]);assert r.returncode==0
