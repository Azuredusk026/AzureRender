from pathlib import Path
root=Path.cwd()
def write(name,s):
 p=root/name;t=p.with_name(p.name+'.selection-tmp');t.write_text(s,encoding='utf-8',newline='\n');t.replace(p)
p='src/scenes/CharacterSceneRenderer.hpp';s=(root/p).read_text();a='    std::string radianceSelectionFallback_;';s=s.replace(a,a+'''
    VkRenderPass radianceValidationPass_=VK_NULL_HANDLE;
    std::array<VkFramebuffer,kMaxFramesInFlight> radianceValidationFrames_{};
    std::array<VkImageView,kMaxFramesInFlight> radianceValidationViews_{};
    rhi::RenderPassBeginDesc radianceValidationDescription(const RenderContext&);
''',1);write(p,s)
p='src/scenes/CharacterSceneRenderer.cpp';s=(root/p).read_text();a='    createScreenReflectionResources(context);';s=s.replace(a,'''    if(surfaceRadiance_&&kSurfaceRadianceFrameSelection&&context.scenePassDescription){
        auto depth=context.scenePassDescription->attachments.at(context.scenePassDescription->depthAttachment);
        depth.clear=false;depth.load=true;depth.store=true;depth.initialLayout=depth.finalLayout=VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
        rhi::RenderPassDesc validation;validation.attachments={depth};validation.depthAttachment=0;
        radianceValidationPass_=rhi_->createRenderPass(validation);
    }
'''+a,1)
s=s.replace('context.commands->beginRenderPass(mainPassDescription(context));\n        recordDepthCoverage(context,*instanceSnapshot_', 'context.commands->beginRenderPass(radianceValidationDescription(context));\n        recordDepthCoverage(context,*instanceSnapshot_',1)
a='    const auto main = graph.addGraphicsPass("character-main",';i=s.index(a)
s=s[:i]+'''    std::optional<RenderGraph::ResourceId> radianceSelectedResource;
    if(radianceSelectionActive(context)){
        const auto& predicate=surfaceRadiance_->selectionBuffer(static_cast<unsigned>(context.currentFrame));
        const auto flag=importHostStorage("character-radiance-predicate",predicate);
        const auto validate=graph.addGraphicsPass("character-radiance-validation",radianceValidationDescription(context),
            [this,frozenContext,frozenInstances](rhi::ICommandRecorder& commands){
                recordDepthCoverage(*frozenContext,*frozenInstances,commands,DepthCoverageMode::RadianceValidation);
            });
        graph.read(validate,*conservativeReady);graph.use(validate,*conservativeIndirectResource,RenderGraphUsage::IndirectBuffer,false);
        graph.attachment(validate,resources.depth,RenderGraphUsage::DepthAttachment,VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL);
        graph.use(validate,flag,RenderGraphUsage::FragmentStorage,true);
        graph.use(validate,radianceResources[3],RenderGraphUsage::Sampled,false);
        for(auto resource:{jointResource,morphTargetResource,morphWeightResource,instanceResource})graph.use(validate,resource,RenderGraphUsage::VertexStorage,false);
        if(skinnedResource)graph.use(validate,*skinnedResource,RenderGraphUsage::VertexStorage,false);
        for(std::uint32_t key=0;key<meshResourceCount_;++key){graph.use(validate,vertexResources[key],RenderGraphUsage::VertexBuffer,false);graph.use(validate,indexResources[key],RenderGraphUsage::IndexBuffer,false);}
        auto& frame=conservativeFrames_[context.currentFrame];const auto& output=frame.selection->output(0);
        rhi::BufferBarrierDesc initial{};initial.buffer=output.buffer;initial.size=output.size;initial.dstStageMask=VK_PIPELINE_STAGE_DRAW_INDIRECT_BIT;initial.dstAccessMask=VK_ACCESS_INDIRECT_COMMAND_READ_BIT;
        radianceSelectedResource=graph.importBuffer("character-radiance-selected-commands",initial);
        const auto choose=graph.addCommandPass("character-radiance-selection",[this,frozenContext](rhi::ICommandRecorder& commands){recordRadianceSelection(commands,*frozenContext);});
        graph.use(choose,flag,RenderGraphUsage::Storage,false);graph.use(choose,*conservativeIndirectResource,RenderGraphUsage::Storage,false);
        graph.use(choose,*radianceSelectedResource,RenderGraphUsage::Storage,true);
    }
'''+s[i:]
a='    if(conservativeReady)graph.read(main,*conservativeReady);';s=s.replace(a,a+'\n    if(radianceSelectedResource)graph.use(main,*radianceSelectedResource,RenderGraphUsage::IndirectBuffer,false);',1)
a='    const auto statistics=surfaceRadiance_?surfaceRadiance_->statistics():SurfaceRadianceCache::Statistics{};';s=s.replace(a,'''    const auto selected=surfaceRadiance_?surfaceRadiance_->selectionStatistics():SurfaceRadianceCache::SelectionStatistics{};
    json << "  \\"surfaceRadianceSelection\\": {\\"enabled\\": " << (surfaceRadiance_&&surfaceRadiance_->selectionEnabled()?"true":"false")
         << ", \\"prepared\\": " << (conservativeFrames_[currentFrame_].selectionTicket?"true":"false")
         << ", \\"frames\\": " << selected.frames << ", \\"fastFrames\\": " << selected.fastFrames << ", \\"fullFrames\\": " << selected.fullFrames
         << ", \\"lastFallback\\": " << (selected.lastFallback?"true":"false") << ", \\"fallback\\": " << std::quoted(radianceSelectionFallback_) << "},\\n";
'''+a,1)
# Normalize the Python literal's C++ escaped quotes.
s=s.replace('\\\\"','\\"');write(p,s)
p='src/scenes/CharacterMaterialSampling.inc';s=(root/p).read_text();s=s.replace('auto validation=fast;validation.fragmentShader=validationModule;validation.depthWrite=false;\n                    validation.colorWriteMasks.assign(validation.colorAttachmentCount,0);\n                    ordinaryRadianceValidationPipelines_[facing]=rhi_->createGraphicsPipeline(validation);','''if(radianceValidationPass_){auto validation=fast;validation.fragmentShader=validationModule;validation.depthWrite=false;
                        validation.renderPass=radianceValidationPass_;validation.colorAttachmentCount=0;validation.colorWriteMasks.clear();
                        ordinaryRadianceValidationPipelines_[facing]=rhi_->createGraphicsPipeline(validation);}''',1);write(p,s)
p='src/scenes/CharacterOcclusionPass.inc';s=(root/p).read_text();a='void CharacterSceneRenderer::destroyConservativeOcclusion(){';s=s.replace(a,a+'''
    for(auto& framebuffer:radianceValidationFrames_){if(framebuffer)rhi_->destroyFramebuffer(framebuffer);framebuffer=VK_NULL_HANDLE;}
    radianceValidationViews_={};if(radianceValidationPass_)rhi_->destroyRenderPass(radianceValidationPass_);radianceValidationPass_=VK_NULL_HANDLE;
''',1);write(p,s)
p='src/scenes/CharacterRadianceSelection.inc';s=(root/p).read_text().replace('const bool permitted=frame.ticket&&qaIsolationMode_', 'const bool permitted=radianceValidationPass_&&frame.ticket&&qaIsolationMode_',1)
s+='''
rhi::RenderPassBeginDesc CharacterSceneRenderer::radianceValidationDescription(const RenderContext& context){
    auto& framebuffer=radianceValidationFrames_.at(context.currentFrame);auto& view=radianceValidationViews_.at(context.currentFrame);
    if(view!=context.sceneDepthView){if(framebuffer)rhi_->destroyFramebuffer(framebuffer);framebuffer=VK_NULL_HANDLE;view=VK_NULL_HANDLE;
        framebuffer=rhi_->createFramebuffer({radianceValidationPass_,{context.sceneDepthView},context.renderExtent.width,context.renderExtent.height});view=context.sceneDepthView;}
    return {radianceValidationPass_,framebuffer,context.renderExtent,{}};
}
'''
write(p,s)
print('Connected depth-only validation, graph dependencies, direct recording and retired selection metadata')
