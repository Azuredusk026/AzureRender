from pathlib import Path
import os,sys,subprocess,json,re,collections,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';folder=out/'program-analysis';folder.mkdir(exist_ok=True)
env=os.environ.copy();env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'),TMPDIR=str(out/'tmp'))
optimizer='D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-opt.exe';disassembler='D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-dis.exe'
def inspect(path,label):
 p=folder/(label+'.spv');command=[optimizer,'--target-env=vulkan1.3','--set-spec-const-default-value','0:true','--freeze-spec-const','-O',str(path),'-o',str(p)]
 result=subprocess.run(command,env=env,capture_output=True,text=True,timeout=30);assert result.returncode==0,result.stderr
 assembly=subprocess.check_output([disassembler,str(p)],env=env,text=True,timeout=30);functions={};calls={};current=None;entry=re.search(r'OpEntryPoint Fragment (%\S+)',assembly).group(1)
 for line in assembly.splitlines():
  match=re.search(r'^\s*(%\S+) = OpFunction\b',line)
  if match:current=match.group(1);functions[current]=[];calls[current]=[]
  if current is not None:
   op=re.search(r'\bOp[A-Za-z0-9_]+\b',line)
   if op:functions[current].append(op.group())
   if 'OpFunctionCall' in line:calls[current].append(line.split('OpFunctionCall',1)[1].split()[1])
   if 'OpFunctionEnd' in line:current=None
 reachable=set();pending=[entry]
 while pending:
  f=pending.pop()
  if f not in reachable:reachable.add(f);pending+=calls[f]
 counts=collections.Counter(op for f in reachable for op in functions[f])
 return dict(source=str(path),sourceSha256=hashlib.sha256(path.read_bytes()).hexdigest(),command=command,optimizedBytes=p.stat().st_size,reachableInstructions=sum(counts.values()),reachableFunctions=len(reachable),opcodes=dict(sorted(counts.items()))),assembly
rows=[]
for fast in sorted((build/'shaders').glob('*_radiance_fast.frag.spv')):
 base=fast.with_name(fast.name.replace('_radiance_fast.frag.spv','.frag.spv'));a,assembly=inspect(fast,fast.stem+'-fast');b,_=inspect(base,fast.stem+'-full')
 row=dict(program=fast.name,fast=a,full=b,staticInstructionReduction=1-a['reachableInstructions']/b['reachableInstructions']);rows.append(row)
 if len(rows)==1:(folder/'representative-fast.spvasm').write_text(assembly)
assert len(rows)==16,len(rows)
report=dict(scope='Private SPIR-V static analysis only; ordinary specialization 0=true; no GPU timing or native workload claim',programs=rows,minimumStaticInstructionReduction=min(r['staticInstructionReduction'] for r in rows),maximumFastImplicitLodOperations=max(r['fast']['opcodes'].get('OpImageSampleImplicitLod',0) for r in rows),productionProgramsModified=False)
(out/'program-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='programs'}))
