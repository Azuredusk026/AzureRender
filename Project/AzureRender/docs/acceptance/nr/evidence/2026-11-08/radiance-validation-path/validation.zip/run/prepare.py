from pathlib import Path
import shutil
root=Path.cwd();out=root/'build/runs/20261108-210615-radiance-validation-path-f6e4f5'
names=['CMakeLists.txt','src/render/SurfaceRadianceCache.hpp','src/render/SurfaceRadianceCache.cpp','src/scenes/CharacterSceneRenderer.hpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterMaterialSampling.inc','src/scenes/CharacterOcclusionPass.inc','src/render/SceneInstanceSnapshot.hpp','src/app/AzureRenderApp.cpp','shaders/mesh.frag','shaders/surface_radiance.glsl','tests/SurfaceRadianceCacheGpuTests.cpp','tests/SurfaceRadianceViewGpuTests.cpp']
for name in names:
 p=out/'original-source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,p)
(out/'owned-entry-files.txt').write_text('\n'.join(names))
def write(name,s):
 p=root/name;t=p.with_name(p.name+'.selection-tmp');t.write_text(s,encoding='utf-8',newline='\n');t.replace(p)
p='src/render/SurfaceRadianceCache.hpp';s=(root/p).read_text()
s=s.replace('bool diagnostics=false);','bool diagnostics=false,bool selection=false);',1)
a='    static constexpr unsigned kAttachments=4;';s=s.replace(a,'    struct SelectionStatistics {std::uint64_t frames=0,fastFrames=0,fullFrames=0;bool lastFallback=true;};\n'+a,1)
a='    Statistics statistics() const noexcept{return statistics_;}';s=s.replace(a,a+'''
    bool selectionEnabled() const noexcept{return !selectionFrames_.empty();}
    std::uint64_t selectionBytes() const noexcept{return selectionFrames_.size()*4ULL;}
    const rhi::GpuBuffer& selectionBuffer(unsigned slot)const{return selectionFrames_.at(slot).buffer;}
    void beginSelectionFrame(unsigned slot,bool permitted=false);
    void recordSelectionReady(rhi::ICommandRecorder&,unsigned slot);
    SelectionStatistics selectionStatistics()const noexcept{return selectionStatistics_;}
''',1)
a='    Statistics statistics_{};';s=s.replace(a,a+'\n    std::vector<StatisticsFrame> selectionFrames_;\n    SelectionStatistics selectionStatistics_{};',1);write(p,s)
p='src/render/SurfaceRadianceCache.cpp';s=(root/p).read_text().replace('bool diagnostics):rhi_(backend)', 'bool diagnostics,bool selection):rhi_(backend)',1)
a='    }catch(...){clear();throw;}';s=s.replace(a,'''        if(selection){
            selectionFrames_.resize(slots);const std::uint32_t fallback=1;
            for(auto& frame:selectionFrames_){
                frame.buffer=backend.allocator().createBuffer(4,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
                if(!frame.buffer.mapped)throw std::runtime_error("Radiance selection requires mapped frame predicates");
                std::memcpy(frame.buffer.mapped,&fallback,4);backend.allocator().flush(frame.buffer,0,4);
            }
        }
'''+a,1)
a='void SurfaceRadianceCache::clear() noexcept {';s=s.replace(a,'''void SurfaceRadianceCache::beginSelectionFrame(unsigned slot,bool permitted){
    if(!selectionEnabled())return;auto& frame=selectionFrames_.at(slot);
    if(frame.recorded){
        rhi_.allocator().invalidate(frame.buffer,0,4);std::uint32_t fallback=1;std::memcpy(&fallback,frame.buffer.mapped,4);
        ++selectionStatistics_.frames;selectionStatistics_.lastFallback=fallback!=0;
        if(fallback)++selectionStatistics_.fullFrames;else ++selectionStatistics_.fastFrames;
    }
    const std::uint32_t fallback=permitted?0U:1U;std::memcpy(frame.buffer.mapped,&fallback,4);
    rhi_.allocator().flush(frame.buffer,0,4);frame.recorded=false;
}
void SurfaceRadianceCache::recordSelectionReady(rhi::ICommandRecorder& commands,unsigned slot){
    if(!selectionEnabled())return;auto& frame=selectionFrames_.at(slot);
    commands.bufferBarrier({frame.buffer.buffer,0,4,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,
        VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});frame.recorded=true;
}
'''+a+'\n    for(auto& frame:selectionFrames_)rhi_.allocator().destroyBuffer(frame.buffer);\n    selectionFrames_.clear();selectionStatistics_={};',1);write(p,s)
p='shaders/surface_radiance.glsl';s=(root/p).read_text();a='bool azureWriteSurfaceRadiance(vec3 geometricNormal){';i=s.index(a);value=s.index('    vec4 a=texelFetch(surfaceRadianceA,pixel,0)',i);end=s.index('\n}',value)
body=s[value:end].replace('azureWriteDisplayMask(1.0);return true;','azureWriteDisplayMask(1.0);')
s=s[:i]+'''void azureWriteCachedSurfaceRadiance(ivec2 pixel,vec3 geometricNormal){
'''+body+'''
}
#if !defined(AZURE_SURFACE_RADIANCE_FAST)
'''+s[i:value]+'''    azureWriteCachedSurfaceRadiance(pixel,geometricNormal);return true;'''+s[end:]
s=s.replace('\n#endif\n#endif\n', '\n#endif\n#endif\n#endif\n',1) if False else s
# Close the consumer-only guard before the snapshot/consumer branch and reuse guard.
s=s.rsplit('\n#endif\n#endif',1)[0]+'\n#endif\n#endif\n#endif\n';write(p,s)
p='shaders/mesh.frag';s=(root/p).read_text().replace('#if defined(AZURE_SURFACE_RADIANCE_REUSE) && !defined(AZURE_OPAQUE_SNAPSHOT)','#if defined(AZURE_SURFACE_RADIANCE_REUSE) && !defined(AZURE_OPAQUE_SNAPSHOT) && !defined(AZURE_SURFACE_RADIANCE_FAST)',1)
a='    if(azureWriteSurfaceRadiance(geometricNormal))return;';assert a in s
s=s.replace(a,'''#if defined(AZURE_SURFACE_RADIANCE_FAST)
    azureWriteCachedSurfaceRadiance(ivec2(gl_FragCoord.xy),geometricNormal);return;
#else
'''+a+'\n#endif',1);write(p,s)
print('Prepared optional cache predicates and validation/consumer shader boundary')
