from pathlib import Path
import json,hashlib,shutil,subprocess,stat
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;paths=[]
names=['AzureSurfaceRadianceCacheGpuTests','AzureSurfaceRadianceRecordingTests','AzureSurfaceRadianceViewGpuTests']
processes=subprocess.run(['powershell','-NoProfile','-Command',"Get-Process -Name AzureSurfaceRadianceCacheGpuTests,AzureSurfaceRadianceRecordingTests,AzureSurfaceRadianceViewGpuTests -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id"],capture_output=True,text=True)
assert processes.returncode in (0,1) and not processes.stdout.strip() and not processes.stderr.strip()
for config in ['release','debug']:
 build=root/('build/ninja-msvc-'+config);assert 'AZURE_ENABLE_SURFACE_RADIANCE_REUSE:BOOL=OFF' in (build/'CMakeCache.txt').read_text();proof=json.loads((build/'build-provenance.json').read_text())
 for name in names:
  paths.extend(p for p in [build/(name+suffix) for suffix in ['.exe','.pdb']] if p.is_file())
  folder=build/'CMakeFiles'/(name+'.dir');paths.extend(p for p in folder.rglob('*') if p.is_file())
 assert not any(str(p.resolve()) in proof['products'] for p in paths)
rows=[]
for p in paths:
 assert p.resolve().is_relative_to(root/'build') and p.is_file()
 for parent in [p,*p.parents]:assert not parent.stat().st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT
 rows.append(dict(path=str(p.resolve()),relative=p.relative_to(root).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
assert not subprocess.check_output(['git','ls-files','--',*[r['relative'] for r in rows]]).strip()
receipt=root/'build/maintenance/radiance-frame-selection-disabled-tests-cleanup.json';receipt.write_text(json.dumps(dict(status='planned',paths=rows),indent=2));freeBefore=shutil.disk_usage(root).free
for row in rows:
 p=Path(row['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];p.unlink()
report=dict(status='applied',files=len(rows),logicalBytes=sum(r['bytes'] for r in rows),freeBeforeBytes=freeBefore,freeAfterBytes=shutil.disk_usage(root).free,paths=rows);report['actualFreedBytes']=report['freeAfterBytes']-freeBefore
receipt.write_text(json.dumps(report,indent=2));(out/'disabled-tests-cleanup.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='paths'}))
