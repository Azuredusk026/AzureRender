from pathlib import Path
root=Path.cwd()
def write(name,s):
 p=root/name;t=p.with_name(p.name+'.selection-tmp');t.write_text(s,encoding='utf-8',newline='\n');t.replace(p)
p='src/render/SurfaceRadianceCache.cpp';s=(root/p).read_text();a='        ++selectionStatistics_.frames;selectionStatistics_.lastFallback=fallback!=0;\n        if(fallback)++selectionStatistics_.fullFrames;else ++selectionStatistics_.fastFrames;';s=s.replace(a,'''        if(fallback&2U){++selectionStatistics_.frames;selectionStatistics_.lastFallback=(fallback&1U)!=0;
            if(fallback&1U)++selectionStatistics_.fullFrames;else ++selectionStatistics_.fastFrames;}''',1)
a='commands.bufferBarrier({frame.buffer.buffer,0,4,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,';assert a in s;s=s.replace(a,'commands.bufferBarrier({frame.buffer.buffer,0,4,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,',1);write(p,s)
p='tests/SurfaceRadianceFrameSelectionTests.cpp';s=(root/p).read_text();a='  rhi::NullCommandRecorder commands;cache.recordSelectionReady(commands,0);';s=s.replace(a,'''  rhi::NullCommandRecorder commands;cache.recordSelectionReady(commands,0);
  cache.beginSelectionFrame(0,true);require(cache.selectionStatistics().frames==0,"Unsubmitted command recordings have no GPU completion marker");
  const std::uint32_t completed=2;std::memcpy(cache.selectionBuffer(0).mapped,&completed,4);cache.recordSelectionReady(commands,0);''',1);write(p,s)
p='src/scenes/CharacterSceneRenderer.hpp';s=(root/p).read_text().replace('    VkRenderPass radianceValidationPass_=VK_NULL_HANDLE;', '    VkRenderPass radianceValidationPass_=VK_NULL_HANDLE;\n    VkPipeline radianceCommitPipeline_=VK_NULL_HANDLE;',1);write(p,s)
p='CMakeLists.txt';s=(root/p).read_text();a='compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_validation.frag")';s=s.replace(a,a+'\ncompile_shader("${SHADER_SOURCE_DIR}/surface_radiance_selection_commit.comp")',1);write(p,s)
p='src/scenes/CharacterSceneRenderer.cpp';s=(root/p).read_text().replace('bindings.push_back({43,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT});','bindings.push_back({43,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT|VK_SHADER_STAGE_COMPUTE_BIT});')
s=s.replace('graph.use(choose,flag,RenderGraphUsage::Storage,false);','graph.use(choose,flag,RenderGraphUsage::Storage,true);',1)
s=s.replace('context.scenePassDescription){\n        auto depth=', 'context.scenePassDescription&&context.scenePassDescription->depthAttachment>=0){\n        auto depth=',1);write(p,s)
p='src/scenes/CharacterMaterialSampling.inc';s=(root/p).read_text();a='            if(kSurfaceRadianceFrameSelection)validationModule=rhi_->createShaderModule(readBinaryFile(shaderDirectory_+"/surface_radiance_validation.frag.spv"));';s=s.replace(a,a+'''
            if(kSurfaceRadianceFrameSelection){auto commit=rhi_->createShaderModule(readBinaryFile(shaderDirectory_+"/surface_radiance_selection_commit.comp.spv"));
                try{radianceCommitPipeline_=rhi_->createComputePipeline({commit,pipelineLayout_});}catch(...){rhi_->destroyShaderModule(commit);throw;}
                rhi_->destroyShaderModule(commit);}
''',1)
a='    if(!rhi_)return;\n    for(auto* variants:';s=s.replace(a,'    if(!rhi_)return;\n    if(radianceCommitPipeline_)rhi_->destroyPipeline(radianceCommitPipeline_);radianceCommitPipeline_=VK_NULL_HANDLE;\n    for(auto* variants:',1);write(p,s)
p='src/scenes/CharacterRadianceSelection.inc';s=(root/p).read_text();a='    surfaceRadiance_->recordSelectionReady(commands,static_cast<unsigned>(context.currentFrame));';s=s.replace(a,'''    commands.bufferBarrier({predicate.buffer,0,4,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
        VK_ACCESS_SHADER_READ_BIT,VK_ACCESS_SHADER_WRITE_BIT});
    commands.bindComputePipeline(radianceCommitPipeline_);
    commands.bindComputeDescriptorSet(pipelineLayout_,descriptorSets_.at(bindlessTextures_?context.currentFrame:context.currentFrame*totalMaterialCount()));
    commands.dispatch(1,1,1);
'''+a,1);write(p,s)
p='tests/SurfaceRadianceCacheGpuTests.cpp';s=(root/p).read_text().replace('VkPipeline validate{};VkShaderModule validation{};','VkPipeline validate{},commit{};VkShaderModule validation{},commitModule{};',1)
a='  if(validate)rhi.destroyPipeline(validate);if(validation)rhi.destroyShaderModule(validation);';s=s.replace(a,a+'\n  if(commit)rhi.destroyPipeline(commit);if(commitModule)rhi.destroyShaderModule(commitModule);',1)
s=s.replace('bindings.push_back({43,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT});','bindings.push_back({43,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT|VK_SHADER_STAGE_COMPUTE_BIT});',1)
a='pipeline.colorWriteMasks.assign(4,0);validate=rhi.createGraphicsPipeline(pipeline);}';s=s.replace(a,'''pipeline.colorWriteMasks.assign(4,0);validate=rhi.createGraphicsPipeline(pipeline);
   commitModule=rhi.createShaderModule(readBinaryFile(shaders+"/surface_radiance_selection_commit.comp.spv"));commit=rhi.createComputePipeline({commitModule,layout});}''',1)
a='   if(selection&&validateOnly)source->recordSelectionReady(commands,0);';s=s.replace(a,'''   if(selection&&validateOnly){const auto& flag=source->selectionBuffer(0);commands.bufferBarrier({flag.buffer,0,4,
    VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});
    commands.bindComputePipeline(commit);commands.bindComputeDescriptorSet(layout,set);commands.dispatch(1,1,1);source->recordSelectionReady(commands,0);}''',1);write(p,s)
print('Added one GPU completion mark per selected frame; cancelled recordings remain uncounted')
