from pathlib import Path
root=Path.cwd();out=root/'build/runs/20261108-210615-radiance-validation-path-f6e4f5'
def write(name,s):
 p=root/name;t=p.with_name(p.name+'.selection-tmp');t.write_text(s,encoding='utf-8',newline='\n');t.replace(p)
p='CMakeLists.txt';s=(root/p).read_text();a='option(AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS "Enable intrusive radiance consumption counters" OFF)';assert a in s
s=s.replace(a,a+'\noption(AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION "Enable experimental validated radiance consumer selection" OFF)\nif(AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION AND NOT AZURE_ENABLE_SURFACE_RADIANCE_REUSE)\n    message(FATAL_ERROR "Radiance frame selection requires AZURE_ENABLE_SURFACE_RADIANCE_REUSE")\nendif()',1)
a='"$<$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS}>:AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1>")';s=s.replace(a,'"$<$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS}>:AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1>"\n    "$<$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION}>:AZURE_SURFACE_RADIANCE_FRAME_SELECTION=1>")',1)
a='compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.vert")';s=s.replace(a,'''if(AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION)
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_validation.frag")
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_validation.frag" DEFINES AZURE_SURFACE_RADIANCE_PROBE=1 OUTPUT_NAME surface_radiance_validation_probe.frag)
endif()
'''+a,1)
a='        if(AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS AND _radiance_source STREQUAL "mesh.frag")';s=s.replace(a,'''        if(AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION AND _radiance_source STREQUAL "mesh.frag" AND NOT "AZURE_OPAQUE_SNAPSHOT=1" IN_LIST _radiance_defines)
            string(REPLACE "_radiance.frag" "_radiance_fast.frag" _radiance_fast_output "${_radiance_output}")
            compile_shader("${SHADER_SOURCE_DIR}/${_radiance_source}" DEFINES ${_radiance_defines} AZURE_SURFACE_RADIANCE_REUSE=1 AZURE_SURFACE_RADIANCE_FAST=1 OUTPUT_NAME "${_radiance_fast_output}")
        endif()
'''+a,1)
a='    add_executable(AzureSurfaceRadianceStatisticsTests tests/SurfaceRadianceStatisticsTests.cpp)';s=s.replace(a,'''    add_executable(AzureSurfaceRadianceFrameSelectionTests tests/SurfaceRadianceFrameSelectionTests.cpp)
    target_link_libraries(AzureSurfaceRadianceFrameSelectionTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.SurfaceRadianceFrameSelection COMMAND AzureSurfaceRadianceFrameSelectionTests)
'''+a,1)
a='AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS=$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS}>)';s=s.replace(a,'AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS=$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS}> AZURE_TEST_SURFACE_RADIANCE_FRAME_SELECTION=$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION}>)');write(p,s)
p='src/app/AzureRenderApp.cpp';s=(root/p).read_text().replace('#if defined(AZURE_SURFACE_RADIANCE_DIAGNOSTICS)\n        fragmentQuadControl_', '#if defined(AZURE_SURFACE_RADIANCE_DIAGNOSTICS) || defined(AZURE_SURFACE_RADIANCE_FRAME_SELECTION)\n        fragmentQuadControl_',1);write(p,s)
p='src/scenes/CharacterSceneRenderer.hpp';s=(root/p).read_text();s='#include "render/GpuPredicateDrawSelection.hpp"\n'+s
s=s.replace('std::array<VkPipeline,4> ordinaryEarlyDepthPipelines_{},ordinaryEarlyDepthSnapshotPipelines_{};', 'std::array<VkPipeline,4> ordinaryEarlyDepthPipelines_{},ordinaryEarlyDepthSnapshotPipelines_{};\n    std::array<VkPipeline,4> ordinaryRadiancePipelines_{},ordinaryRadianceValidationPipelines_{};',1)
s=s.replace('SnapshotDepth,SnapshotColor,SnapshotPrefill,MainPrefill','SnapshotDepth,SnapshotColor,SnapshotPrefill,MainPrefill,RadianceValidation',1)
a='        std::unique_ptr<GpuConservativeOcclusion> commands;';s=s.replace(a,a+'\n        std::unique_ptr<GpuPredicateDrawSelection> selection;\n        std::optional<GpuPredicateDrawSelection::Ticket> selectionTicket;',1)
a='    void prepareConservativeOcclusion();';s=s.replace(a,a+'''
    void prepareRadianceSelection();
    bool radianceSelectionActive(const RenderContext&) const;
    static bool radianceSelectionMaterial(const AssetMaterial&) noexcept;
    void recordRadianceSelection(rhi::ICommandRecorder&,const RenderContext&);
    std::string radianceSelectionFallback_;
''',1);write(p,s)
p='src/render/SceneInstanceSnapshot.hpp';s=(root/p).read_text();a='    VkBuffer conservativeIndirect=VK_NULL_HANDLE;';s=s.replace(a,a+'\n    VkBuffer radianceSelectionIndirect=VK_NULL_HANDLE;\n    VkDeviceSize radianceFastOffset=0;',1);write(p,s)
p='src/scenes/CharacterSceneRenderer.cpp';s=(root/p).read_text();a='#include "animation/PresentedPose.hpp"';s=s.replace(a,'''#if defined(AZURE_SURFACE_RADIANCE_FRAME_SELECTION)
static constexpr bool kSurfaceRadianceFrameSelection=true;
#else
static constexpr bool kSurfaceRadianceFrameSelection=false;
#endif
'''+a,1)
a='if(kSurfaceRadianceDiagnostics){++radianceRequirements.fragmentBuffers;++radianceRequirements.descriptorSetBuffers;}';s=s.replace(a,a+'\n    if(kSurfaceRadianceFrameSelection){++radianceRequirements.fragmentBuffers;++radianceRequirements.descriptorSetBuffers;}',1)
s=s.replace('SurfaceRadianceCache::kMaximumBytes,kSurfaceRadianceDiagnostics)', 'SurfaceRadianceCache::kMaximumBytes,kSurfaceRadianceDiagnostics,kSurfaceRadianceFrameSelection)',1)
s=s.replace('    prepareConservativeOcclusion();','    prepareConservativeOcclusion();\n    prepareRadianceSelection();',1)
a='        recordingBuffers.conservativeIndirect=occlusion.commands->output(0).buffer;';s=s.replace(a,a+'''\n        if(occlusion.selectionTicket){recordingBuffers.radianceSelectionIndirect=occlusion.selection->output(0).buffer;recordingBuffers.radianceFastOffset=occlusion.selection->fastOffset();}''',1)
s=s.replace('+(surfaceRadianceCapable_&&kSurfaceRadianceDiagnostics?1U:0U))}', '+(surfaceRadianceCapable_&&kSurfaceRadianceDiagnostics?1U:0U)+(surfaceRadianceCapable_&&kSurfaceRadianceFrameSelection?1U:0U))}')
a='        if(surfaceRadianceCapable_&&kSurfaceRadianceDiagnostics)bindings.push_back({42,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT});';s=s.replace(a,a+'\n        if(surfaceRadianceCapable_&&kSurfaceRadianceFrameSelection)bindings.push_back({43,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT});')
a='            rhi_->writeDescriptorBuffer({set,42,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,buffer.buffer,buffer.size});}';s=s.replace(a,a+'\n        if(surfaceRadiance_->selectionEnabled()){const auto& buffer=surfaceRadiance_->selectionBuffer(frame);rhi_->writeDescriptorBuffer({set,43,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,buffer.buffer,4});}',1)
a='#include "CharacterOcclusionPass.inc"';s=s.replace(a,a+'\n#include "CharacterRadianceSelection.inc"',1)
write(p,s)
print('Declared experimental frame-selection configuration, descriptors and shared frame resources')
