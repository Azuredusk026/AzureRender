from pathlib import Path
root=Path.cwd()
def write(name,s):
 p=root/name;t=p.with_name(p.name+'.selection-tmp');t.write_text(s,encoding='utf-8',newline='\n');t.replace(p)
p='tests/SurfaceRadianceViewGpuTests.cpp';s=(root/p).read_text().replace('AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS!=0','(AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS||AZURE_TEST_SURFACE_RADIANCE_FRAME_SELECTION)!=0',1);write(p,s)
p='tests/SurfaceRadianceCacheGpuTests.cpp';s=(root/p).read_text();s=s.replace('bool diagnostics=false;', 'bool diagnostics=false,selection=false;VkPipeline validate{};VkShaderModule validation{};',1)
s=s.replace('explicit Resources(test::VulkanComputeFixture& h,bool statistics=false):host(h),rhi(*h.backend),diagnostics(statistics){}','explicit Resources(test::VulkanComputeFixture& h,bool statistics=false,bool frameSelection=false):host(h),rhi(*h.backend),diagnostics(statistics),selection(frameSelection){}',1)
a='  for(auto frame:frames)if(frame)rhi.destroyFramebuffer(frame);';s=s.replace(a,a+'\n  if(validate)rhi.destroyPipeline(validate);if(validation)rhi.destroyShaderModule(validation);',1)
s=s.replace('SurfaceRadianceCache::kMaximumBytes,diagnostics);','SurfaceRadianceCache::kMaximumBytes,diagnostics,selection);',1)
a='  if(diagnostics)bindings.push_back({42,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT});';s=s.replace(a,a+'\n  if(selection)bindings.push_back({43,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT});',1)
a='if(diagnostics)poolDesc.sizes.push_back({VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1});';s=s.replace(a,'if(diagnostics||selection)poolDesc.sizes.push_back({VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,(diagnostics?1U:0U)+(selection?1U:0U)});',1)
a='  if(diagnostics){const auto& counter=source->statisticsBuffer(0);rhi.writeDescriptorBuffer({set,42,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,counter.buffer,counter.size});}';s=s.replace(a,a+'\n  if(selection){const auto& flag=source->selectionBuffer(0);rhi.writeDescriptorBuffer({set,43,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,flag.buffer,4});}',1)
a='produce=rhi.createGraphicsPipeline(pipeline);pipeline.fragmentShader=consumer;consume=rhi.createGraphicsPipeline(pipeline);';s=s.replace(a,a+'''
  if(selection){validation=rhi.createShaderModule(readBinaryFile(shaders+"/surface_radiance_validation_probe.frag.spv"));
   pipeline.fragmentShader=validation;pipeline.depthWrite=false;pipeline.colorWriteMasks.assign(4,0);validate=rhi.createGraphicsPipeline(pipeline);}
''',1)
s=s.replace('bool sampled=false){','bool sampled=false,bool validateOnly=false){',1)
a='   VkClearValue clearDepth{};';s=s.replace(a,'''   if(selection){const auto& flag=source->selectionBuffer(0);commands.bufferBarrier({flag.buffer,0,4,
    VK_PIPELINE_STAGE_HOST_BIT|VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
    VK_ACCESS_HOST_WRITE_BIT|VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});}
'''+a,1)
s=s.replace('commands.bindPipeline(sampled?consume:produce);','commands.bindPipeline(validateOnly?validate:sampled?consume:produce);',1)
s=s.replace('if(sampled||diagnostics)commands.bindDescriptorSet(layout,set);','if(sampled||diagnostics||validateOnly)commands.bindDescriptorSet(layout,set);',1)
a='   if(diagnostics)source->recordStatisticsReady(commands,0);';s=s.replace(a,a+'\n   if(selection&&validateOnly)source->recordSelectionReady(commands,0);',1)
s=s.replace('AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS!=0','(AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS||AZURE_TEST_SURFACE_RADIANCE_FRAME_SELECTION)!=0',1)
a=' require(host.allocator.statistics().liveBuffers==0';i=s.index(a)
s=s[:i]+'''#if AZURE_TEST_SURFACE_RADIANCE_FRAME_SELECTION
 {Resources r(host,false,true);r.initialize(argv[1]);Probe p;r.bind(0);
  r.source->beginSelectionFrame(0,true);r.draw(0,p,7,3);r.draw(2,p,7,3,false,true);
  r.source->beginSelectionFrame(0,true);auto selected=r.source->selectionStatistics();
  require(selected.frames==1&&selected.fastFrames==1&&!selected.lastFallback,"Actual matching fragments preserve the fast predicate");
  p.value=-2;r.draw(0,p,7,3);r.draw(2,p,7,3,false,true);
  r.source->beginSelectionFrame(0,true);selected=r.source->selectionStatistics();
  require(selected.frames==2&&selected.fullFrames==1&&selected.lastFallback,"Any real identity mismatch requests complete shading");
  p.value=0;r.draw(0,p,7,0);r.draw(2,p,7,3,false,true);
  r.source->beginSelectionFrame(0);selected=r.source->selectionStatistics();
  require(selected.fullFrames==2&&selected.lastFallback,"Missing production is fail closed");
 }
#endif
'''+s[i:];write(p,s)
print('Added real-fragment validation predicates and cache-owned retirement checks')
