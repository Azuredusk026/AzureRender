from pathlib import Path
import os,subprocess,json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;env=os.environ.copy();env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'),TMPDIR=str(out/'tmp'),VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
command=[str(root/'tools/msvc_env.bat'),'cmake','--build',str(root/'build/ninja-msvc-release'),'--target','AzureSurfaceRadianceCacheGpuTests','-j','3']
with (out/'red-blend-build.log').open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0
with (out/'red-blend.log').open('wb') as log:r=subprocess.run([str(root/'build/ninja-msvc-release/AzureSurfaceRadianceCacheGpuTests.exe'),str(root/'build/ninja-msvc-release/shaders')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
text=(out/'red-blend.log').read_text(errors='replace');assert r.returncode!=0 and 'renderPass-06041' in text and 'Vulkan validation must remain clean' in text
(out/'red-blend.json').write_text(json.dumps(dict(exitCode=r.returncode,expectedUnwrittenIntegerAttachmentBlendFailure=True),indent=2));print('Reproduced zero-mask integer attachment blend validation error')
