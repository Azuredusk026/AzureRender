from pathlib import Path
root=Path.cwd()
def write(name,s):
 p=root/name;t=p.with_name(p.name+'.selection-tmp');t.write_text(s,encoding='utf-8',newline='\n');t.replace(p)
p='src/scenes/CharacterMaterialSampling.inc';s=(root/p).read_text();a='    VkShaderModule identityVertex=VK_NULL_HANDLE;';s=s.replace(a,a+'\n    VkShaderModule validationModule=VK_NULL_HANDLE;',1)
a='            const auto cachedModule=[&](VkShaderModule module){';s=s.replace(a,'            const auto cachedModule=[&](VkShaderModule module,bool fast=false){',1)
a='kSurfaceRadianceDiagnostics?"_radiance_stats":"_radiance"';s=s.replace(a,'fast?"_radiance_fast":kSurfaceRadianceDiagnostics?"_radiance_stats":"_radiance"',1)
a='            cachedColor=cachedModule(earlyColorModule);cachedSnapshot=cachedModule(earlySnapshotModule);';s=s.replace(a,'''            cachedColor=cachedModule(earlyColorModule,kSurfaceRadianceFrameSelection);cachedSnapshot=cachedModule(earlySnapshotModule);
            if(kSurfaceRadianceFrameSelection)validationModule=rhi_->createShaderModule(readBinaryFile(shaderDirectory_+"/surface_radiance_validation.frag.spv"));''',1)
a='                if(identityVertex){covered.vertexShader=identityVertex;covered.fragmentShader=cachedColor;}\n                ordinaryEarlyDepthPipelines_[facing]=createMaterialGraphicsPipeline(covered);}';assert a in s;s=s.replace(a,'''                if(identityVertex&&!kSurfaceRadianceFrameSelection){covered.vertexShader=identityVertex;covered.fragmentShader=cachedColor;}
                ordinaryEarlyDepthPipelines_[facing]=createMaterialGraphicsPipeline(covered);
                if(identityVertex&&kSurfaceRadianceFrameSelection){
                    auto fast=covered;fast.vertexShader=identityVertex;fast.fragmentShader=cachedColor;
                    ordinaryRadiancePipelines_[facing]=rhi_->createGraphicsPipeline(fast);
                    auto validation=fast;validation.fragmentShader=validationModule;validation.depthWrite=false;
                    validation.colorWriteMasks.assign(validation.colorAttachmentCount,0);
                    ordinaryRadianceValidationPipelines_[facing]=rhi_->createGraphicsPipeline(validation);
                }
            }''',1)
a='    }catch(...){if(identityVertex)rhi_->destroyShaderModule(identityVertex);destroyMaterialClassPipelines();throw;}';assert a in s;s=s.replace(a,'    }catch(...){if(validationModule)rhi_->destroyShaderModule(validationModule);if(identityVertex)rhi_->destroyShaderModule(identityVertex);destroyMaterialClassPipelines();throw;}',1)
a='    if(identityVertex)rhi_->destroyShaderModule(identityVertex);';s=s.replace(a,'    if(validationModule)rhi_->destroyShaderModule(validationModule);\n'+a,1)
a='&ordinaryEarlyDepthPipelines_,&ordinaryEarlyDepthSnapshotPipelines_}';assert a in s;s=s.replace(a,'&ordinaryEarlyDepthPipelines_,&ordinaryEarlyDepthSnapshotPipelines_,&ordinaryRadiancePipelines_,&ordinaryRadianceValidationPipelines_}',1);write(p,s)
p='src/scenes/CharacterSceneRenderer.cpp';s=(root/p).read_text();a='    const bool mainPrefill=mode==DepthCoverageMode::MainPrefill;';s=s.replace(a,'    const bool validation=mode==DepthCoverageMode::RadianceValidation;\n'+a,1)
a='            const auto& m=mesh.materials[primitive.materialIndex];if(m.alphaMode==AssetAlphaMode::Blend||m.materialClass==AssetMaterialClass::Overlay)continue;';s=s.replace(a,a+'''
            if(validation){
                if(!radianceSelectionMaterial(m))continue;bool complete=true;
                const auto pi=static_cast<std::size_t>(&primitive-mesh.primitives.data());
                for(std::uint32_t i=0;i<count;++i)complete&=snapshot.buffers.conservativeSlots.at(snapshot.buffers.conservativeOffsets.at(first+i)+pi)!=UINT32_MAX;
                if(!complete)continue;
            }
''',1)
a='commands.bindPipeline(simpleDepth?depthPipeline:materialLightingPipeline(m,depthPipeline));';s=s.replace(a,'commands.bindPipeline(validation?ordinaryRadianceValidationPipelines_[surfaceFacingIndex(m.doubleSided,mirrored)]:(simpleDepth?depthPipeline:materialLightingPipeline(m,depthPipeline)));',1)
a='                commands.drawIndexed(primitive.indexCount,primitive.firstIndex,run.instanceCount,\n                    materialOriginFirstInstance(m,&snapshot,run.firstInstance,run.instanceCount));';assert a in s;s=s.replace(a,'''                if(validation){
                    const auto pi=static_cast<std::size_t>(&primitive-mesh.primitives.data());
                    for(std::uint32_t i=0;i<run.instanceCount;++i){const auto slot=snapshot.buffers.conservativeSlots.at(snapshot.buffers.conservativeOffsets.at(run.firstInstance+i)+pi);
                        commands.drawIndexedIndirect(snapshot.buffers.conservativeIndirect,VkDeviceSize(slot)*20,1,20);}
                }else commands.drawIndexed(primitive.indexCount,primitive.firstIndex,run.instanceCount,
                    materialOriginFirstInstance(m,&snapshot,run.firstInstance,run.instanceCount));''',1)
a='    if(useConservative){\n        const auto& buffers=snapshot->buffers;';assert a in s;s=s.replace(a,'''    if(useConservative){
        const auto& buffers=snapshot->buffers;
        const bool selectRadiance=buffers.radianceSelectionIndirect!=VK_NULL_HANDLE&&radianceSelectionMaterial(material);
        const auto selectedBuffer=selectRadiance?buffers.radianceSelectionIndirect:buffers.conservativeIndirect;''',1)
a='        if(regular&&buffers.multiDrawIndirect){';s=s.replace(a,'        const auto drawRegion=[&](VkDeviceSize base){\n'+a,1)
a='commands.drawIndexedIndirect(buffers.conservativeIndirect,VkDeviceSize(slot(i))*20,count,stride*20)';s=s.replace(a,'commands.drawIndexedIndirect(selectedBuffer,base+VkDeviceSize(slot(i))*20,count,stride*20)',1)
a='commands.drawIndexedIndirect(buffers.conservativeIndirect,VkDeviceSize(slot(i))*20,1,20)';s=s.replace(a,'commands.drawIndexedIndirect(selectedBuffer,base+VkDeviceSize(slot(i))*20,1,20)',1)
a='    }else if (useIndirect) {';s=s.replace(a,'''        };
        drawRegion(0);
        if(selectRadiance){commands.bindPipeline(ordinaryRadiancePipelines_[surfaceFacingIndex(material.doubleSided,mirrored)]);
            if(counters)++counters->pipelineBinds;drawRegion(buffers.radianceFastOffset);}
'''+a,1)
# Every direct path finishes conservative depth before the main render pass.
a='    recordConservativeOcclusion(context,*instanceSnapshot_);';assert a in s;s=s.replace(a,a+'''
    if(radianceSelectionActive(context)){
        const auto& predicate=surfaceRadiance_->selectionBuffer(static_cast<unsigned>(context.currentFrame));
        context.commands->bufferBarrier({predicate.buffer,0,4,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
            VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});
        context.commands->beginRenderPass(mainPassDescription(context));
        recordDepthCoverage(context,*instanceSnapshot_,*context.commands,DepthCoverageMode::RadianceValidation);
        context.commands->endRenderPass();recordRadianceSelection(*context.commands,context);
    }
''',1)
write(p,s)
p='CMakeLists.txt';s=(root/p).read_text().replace('if(shader_source_base STREQUAL "surface_radiance_probe.frag")','if(shader_source_base STREQUAL "surface_radiance_probe.frag" OR shader_source_base STREQUAL "surface_radiance_validation.frag")',1);write(p,s)
p='src/scenes/CharacterSceneRenderer.hpp';s=(root/p).read_text();s=s.replace('#include "render/GpuPredicateDrawSelection.hpp"\n#pragma once','#pragma once\n#include "render/GpuPredicateDrawSelection.hpp"',1);write(p,s)
print('Connected ordinary validation draws, independent lightweight pipelines and ordered two-region submission')
