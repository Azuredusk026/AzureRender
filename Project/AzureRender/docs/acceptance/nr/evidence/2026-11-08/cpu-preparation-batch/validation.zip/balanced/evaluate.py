from pathlib import Path
import json,os,sys,shutil
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from artifact_maintenance import guarded_run
verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}
lock=json.loads((root/'build/runs/20261107-171836-consolidated-preparation-images-374280/image/frozen-inputs.json').read_text())['project'];assert all(digest(Path(p))==sha for p,sha in lock.items())
frozen=json.loads((root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/command.json').read_text());project=frozen[frozen.index('--project')+1]
os.environ.update(TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'),VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
executions=[]
for variant in ['baseline','candidate']:
 folder=out/variant;os.environ['AZURE_CPU_WORK_REPORT']=str(folder/'cpu-work.json')
 command=[str(folder/'ProbePlayer.exe'),'--project',project,'--resource-root',str(build),'--width','2560','--height','1440','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','24','--smoke-frames','40','--gpu-timing','--gpu-timing-output',str(folder/'timing.json'),'--runtime-report',str(folder/'runtime.json')]
 (folder/'command.json').write_text(json.dumps(dict(command=command,exeSha256=digest(folder/'ProbePlayer.exe'),scope='Forty-frame CPU preparation diagnosis; frames 5 through 40, battery supply, no formal frame-budget qualification'),indent=2))
 result=guarded_run(root/'build',out.parent.name,command,240);shutil.copyfile(out.parent/'process.log',folder/'process.log')
 log=(folder/'process.log').read_text(errors='replace');result.update(variant=variant,validationLogClean=not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-']),zeroAllocator='Allocator after unload: buffers=0 images=0' in log)
 (folder/'execution.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
 assert result['exitCode']==0 and result['validationLogClean'] and result['zeroAllocator']
 executions.append(result)
 assert inputs(root)==before and all(digest(Path(p))==sha for p,sha in products.items())
assert all(digest(Path(p))==sha for p,sha in lock.items())
base=json.loads((out/'baseline/cpu-work.json').read_text());candidate=json.loads((out/'candidate/cpu-work.json').read_text())
report=dict(baseline=base,candidate=candidate,updateReductionPercent=100*(1-candidate['stages']['update']/base['stages']['update']),sourceAndProductsUnchanged=True,frozenProjectInputsVerified=len(lock),formalPerformancePassed=False)
(out/'comparison.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
