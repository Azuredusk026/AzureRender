from pathlib import Path
import json,sys,subprocess,shutil
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
paths=['src/render/TransparentTopology.hpp','src/render/MotionVectorPass.hpp','src/render/MotionVectorPass.cpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','tests/TransparentTopologyTests.cpp','tests/MotionRecordingTests.cpp']
for name in paths:
 target=out/'baseline-source'/name;target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(subprocess.check_output(['git','show','HEAD:Project/AzureRender/'+name]))
prior=out.parent/'20261108-055410-cpu-consumed-preparation-023e02'
shutil.copyfile(prior/'CpuStagesPlayer.exe',out/'BaselinePlayer.exe')
(out/'baseline.json').write_text(json.dumps(dict(sourceInputs=inputs(root),baselineExecutableSha256=digest(out/'BaselinePlayer.exe')),indent=2))
state=root/'build/maintenance/storage-work-priority.json'
state.write_text(json.dumps(dict(activeTask='cpu-preparation-batch',status='implementing',performanceTask=str(out.relative_to(root)),storageCommit='254cd03',projectDataVolume='D:',maintenanceUnit='day'),indent=2)+'\n')
