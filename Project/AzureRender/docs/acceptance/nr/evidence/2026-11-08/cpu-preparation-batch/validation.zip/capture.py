from pathlib import Path
import json,os,sys,time
import numpy as np
from PIL import Image
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from artifact_maintenance import guarded_run
result=json.loads((out/'balanced/comparison.json').read_text());assert result['updateReductionPercent']>=20,'Candidate must satisfy the planned update reduction before image capture'
verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]};assert len(products)==666
lock=json.loads((root/'build/runs/20261107-171836-consolidated-preparation-images-374280/image/frozen-inputs.json').read_text())['project'];assert all(digest(Path(p))==sha for p,sha in lock.items())
reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint'
folder=out/'image';folder.mkdir(exist_ok=True)
command=json.loads((reference/'command.json').read_text());command[0]=str(build/'AzurePlayer.exe');command[command.index('--capture-dir')+1]=str(folder/'frames');command[command.index('--runtime-report')+1]=str(folder/'runtime.json')
os.environ.update(TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'),VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','AZURE_CPU_WORK_REPORT']:os.environ.pop(key,None)
(folder/'command.json').write_text(json.dumps(command,indent=2));start=time.monotonic();execution=guarded_run(root/'build',out.name,command,240)
rows=[]
for path in sorted((folder/'frames').glob('frame_*.png')):
 current=np.asarray(Image.open(path).convert('RGB'));old=np.asarray(Image.open(reference/'frames'/path.name).convert('RGB'));delta=np.abs(current.astype('i2')-old.astype('i2'))
 rows.append(dict(frame=path.name,sha256=digest(path),referenceSha256=digest(reference/'frames'/path.name),changedPixels=int(np.any(delta,axis=2).sum()),maximumByteDifference=int(delta.max()),shape=list(current.shape)))
log=(out/'process.log').read_text(errors='replace');(folder/'process.log').write_text(log)
report=dict(execution=execution,seconds=time.monotonic()-start,frames=rows,sourceInputsUnchanged=inputs(root)==before,productionProductsUnchanged=all(digest(Path(p))==sha for p,sha in products.items()),projectInputsUnchanged=all(digest(Path(p))==sha for p,sha in lock.items()),projectFiles=len(lock),validationLogClean=not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-']),zeroAllocator='Allocator after unload: buffers=0 images=0' in log,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review')
(folder/'results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
assert execution['exitCode']==0 and len(rows)==4 and all(r['changedPixels']==0 for r in rows)
assert all(report[k] for k in ['sourceInputsUnchanged','productionProductsUnchanged','projectInputsUnchanged','validationLogClean','zeroAllocator'])
