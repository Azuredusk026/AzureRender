from pathlib import Path
import json,subprocess,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
header=r'''
#pragma once
#include "rhi/Rhi.hpp"
#include <array>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <filesystem>
#include <nlohmann/json.hpp>
namespace azCpuBatch {
enum Stage {Update,Instances,Transparent,Motion,Bindings,Count};
inline const std::array<const char*,Count> names{"update","instances","transparent","motion","bindings"};
inline std::array<unsigned long long,Count> ns{};
inline unsigned frames=0,selected=0;inline bool sampling=false;
inline unsigned long long buffers=0,images=0;
inline std::vector<double> updates;
inline void begin(){++frames;sampling=frames>=5&&frames<=40;if(sampling)++selected;}
struct Scope{Stage stage;bool active=sampling;std::chrono::steady_clock::time_point start;
explicit Scope(Stage s):stage(s){if(active)start=std::chrono::steady_clock::now();}
~Scope(){if(active){const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();ns[stage]+=elapsed;if(stage==Update)updates.push_back(double(elapsed)/1e6);}}};
inline void writeBuffer(azurerender::rhi::IRhi& rhi,const azurerender::rhi::DescriptorBufferWrite& write){if(sampling)++buffers;rhi.writeDescriptorBuffer(write);}
inline void writeImage(azurerender::rhi::IRhi& rhi,const azurerender::rhi::DescriptorImageWrite& write){if(sampling)++images;rhi.writeDescriptorImage(write);}
inline void dump(){const auto* path=std::getenv("AZURE_CPU_WORK_REPORT");if(!path||!selected)return;
nlohmann::json r={{"frames",frames},{"selectedFrames",selected},{"bufferWrites",buffers},{"imageWrites",images},{"updateSamplesMs",updates}};
for(unsigned i=0;i<Count;++i)r["stages"][names[i]]=double(ns[i])/1e6/selected;
std::ofstream(std::filesystem::u8path(path))<<r.dump(2)<<'\n';}
}
'''
(out/'CpuPreparationProbe.hpp').write_text(header)
def entry(text,signature,code):
 start=text.index(signature);opening=text.index('{',start);return text[:opening+1]+'\n'+code+text[opening+1:]
for variant in ['baseline','candidate']:
 folder=out/variant;folder.mkdir(exist_ok=True)
 cpp=(out.parent/'baseline-source/src/scenes/CharacterSceneRenderer.cpp').read_text() if variant=='baseline' else (root/'src/scenes/CharacterSceneRenderer.cpp').read_text()
 if variant=='baseline':
  cpp=cpp.replace('void CharacterSceneRenderer::prepareInstancePoses()','void CharacterSceneRenderer::prepareInstancePoses(const std::vector<float>&)')
  cpp=cpp.replace('    prepareInstancePoses();','    prepareInstancePoses({});')
  cpp=entry(cpp,'void CharacterSceneRenderer::prepareTransparentIndices(','transparencyScratch_.lanes.resize(1);')
  cpp=cpp.replace('output,transparencyScratch_,preparationWorkers_)','output,transparencyScratch_.lanes[0],preparationWorkers_)')
 cpp=entry(cpp,'void CharacterSceneRenderer::updateFrame(','azCpuBatch::begin();azCpuBatch::Scope timer(azCpuBatch::Update);')
 for name,stage in [('rebuildSceneInstances','Instances'),('prepareTransparentIndices','Transparent')]:cpp=entry(cpp,'void CharacterSceneRenderer::'+name+'(','azCpuBatch::Scope timer(azCpuBatch::'+stage+');')
 cpp=entry(cpp,'void CharacterSceneRenderer::onUnload(','azCpuBatch::dump();')
 motion=(root/'src/scenes/CharacterMotionPass.inc').read_text();motion=entry(motion,'void CharacterSceneRenderer::prepareMotion(','azCpuBatch::Scope timer(azCpuBatch::Motion);')
 (folder/'CharacterMotionPass.inc').write_text(motion)
 cpp=cpp.replace('#include "CharacterMotionPass.inc"','#include "'+(folder/'CharacterMotionPass.inc').as_posix()+'"')
 (folder/'CharacterSceneRenderer.cpp').write_text('#include "'+(out/'CpuPreparationProbe.hpp').as_posix()+'"\n'+cpp)
 motionCpp=(out.parent/'baseline-source/src/render/MotionVectorPass.cpp').read_text() if variant=='baseline' else (root/'src/render/MotionVectorPass.cpp').read_text()
 motionCpp=entry(motionCpp,'void MotionVectorPass::prepare(','azCpuBatch::Scope timer(azCpuBatch::Bindings);')
 motionCpp=motionCpp.replace('rhi_.writeDescriptorBuffer(','azCpuBatch::writeBuffer(rhi_,').replace('rhi_.writeDescriptorImage(','azCpuBatch::writeImage(rhi_,')
 (folder/'MotionVectorPass.cpp').write_text('#include "'+(out/'CpuPreparationProbe.hpp').as_posix()+'"\n'+motionCpp)
build=root/'build/ninja-msvc-release';cache=(build/'CMakeCache.txt').read_text();ninja=re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.+)$',cache,re.M).group(1)
commands=subprocess.check_output([ninja,'-C',str(build),'-t','commands','AzurePlayer.exe'],text=True,encoding='utf-8').splitlines()
for name in ['CharacterSceneRenderer','MotionVectorPass']:(out/(name+'-command.txt')).write_text(next(c for c in commands if c.rstrip().endswith(name+'.cpp')))
rule=re.search(r'^build AzurePlayer\.exe: (\S+)',(build/'build.ninja').read_text(),re.M).group(1)
expanded=json.loads(subprocess.check_output([ninja,'-C',str(build),'-t','compdb','-x',rule],text=True,encoding='utf-8'));assert len(expanded)==1
(out/'link-command.txt').write_text(expanded[0]['command'])
