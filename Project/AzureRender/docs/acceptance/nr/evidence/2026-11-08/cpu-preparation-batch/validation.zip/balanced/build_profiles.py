from pathlib import Path
import subprocess,os,sys,json,ctypes,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'))
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],env=env).returncode)
def split(command):
 count=ctypes.c_int();f=ctypes.windll.shell32.CommandLineToArgvW;f.restype=ctypes.POINTER(ctypes.c_wchar_p);f.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)]
 result=f(command,ctypes.byref(count));values=[result[i] for i in range(count.value)];ctypes.windll.kernel32.LocalFree(result);return values
start=time.monotonic();report={}
for variant in ['baseline','candidate']:
 folder=out/variant;compileCommands=[]
 for name in ['CharacterSceneRenderer','MotionVectorPass']:
  command=split((out/(name+'-command.txt')).read_text());command=[v for v in command if v!='/showIncludes'];command[-1]=str(folder/(name+'.cpp'))
  for i,v in enumerate(command):
   if v.startswith('/Fo'):command[i]='/Fo'+str(folder/(name+'.obj'))
   elif v.startswith('/Fd'):command[i]='/Fd'+str(folder/(name+'.pdb'))
  command[1:1]=['/I'+str(root/'src/scenes'),'/I'+str(root/'src/render')]
  with (folder/(name+'-compile.log')).open('wb') as log:r=subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=300)
  assert r.returncode==0,(folder/(name+'-compile.log')).read_text(errors='replace')[-5000:]
  compileCommands.append(command)
 link=split((out/'link-command.txt').read_text().split(' -- ',1)[1].split(' && ',1)[0])
 for i,v in enumerate(link):
  if v.lower().startswith('/out:'):link[i]='/out:'+str(folder/'ProbePlayer.exe')
  elif v.lower().startswith('/implib:'):link[i]='/implib:'+str(folder/'ProbePlayer.lib')
  elif v.lower().startswith('/pdb:'):link[i]='/pdb:'+str(folder/'ProbePlayer.pdb')
 link=[v for v in link if not v.lower().startswith(('/debug','/incremental'))];link[1:1]=[str(folder/'CharacterSceneRenderer.obj'),str(folder/'MotionVectorPass.obj'),'/DEBUG:NONE','/INCREMENTAL:NO']
 with (folder/'link.log').open('wb') as log:r=subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 assert r.returncode==0,(folder/'link.log').read_text(errors='replace')[-5000:]
 report[variant]=dict(compile=compileCommands,link=link)
 print(variant+' built',flush=True)
(out/'profile-build.json').write_text(json.dumps(dict(variants=report,seconds=time.monotonic()-start),indent=2))
