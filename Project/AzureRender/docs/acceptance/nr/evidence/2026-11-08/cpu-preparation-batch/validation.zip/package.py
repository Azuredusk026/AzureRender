from pathlib import Path
import json,sys,hashlib,subprocess,zipfile,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
coarse=json.loads((out/'comparison.json').read_text());balanced=json.loads((out/'balanced/comparison.json').read_text())
assert coarse['updateReductionPercent']<0 and 7<balanced['updateReductionPercent']<8
assert balanced['candidate']['bufferWrites']==balanced['candidate']['imageWrites']==0
original=json.loads((out.parent/'20261108-065642-receiver-linear-depth-ecc3b4/export-baseline.json').read_text())['sourceInputs'];assert inputs(root)==original
restoration=json.loads((out/'restoration.json').read_text())
for row in restoration['files']:
 assert digest(root/row['path'])==row['restoredSha256'];row['candidateSha256']=digest(out/'final-source'/row['path'])
(out/'restoration.json').write_text(json.dumps(restoration,indent=2))
proof=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,provenanceSha256=digest(p)))
 log=(out/('restored-'+config+'-tests.log')).read_text();assert '100% tests passed, 0 tests failed out of 3' in log
for variant in ['baseline','candidate','balanced/baseline','balanced/candidate']:
 execution=json.loads((out/variant/'execution.json').read_text());assert execution['exitCode']==0 and execution['validationLogClean'] and execution['zeroAllocator']
assert '100% tests passed, 0 tests failed out of 3' in (out/'balanced/unit-tests.log').read_text()
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/cpu-preparation-batch';evidence.mkdir(parents=True,exist_ok=True)
members={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and p.suffix in ['.cpp','.hpp','.inc','.py','.json','.log','.txt','.xml','.md']}
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='preparation-batch-below-gate',sourceBase='0a0429c',diagnosticFramesPerVariant=40,selectedFramesPerVariant=36,coarse=coarse,balanced=balanced,expectedUpdateReductionGatePercent=20,candidateAdopted=False,nativeImageBatchStarted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',productionSourceRestored=True,restoredChecks=6,productionProvenance=proof,userDiffSha256=protected,evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=n,bytes=p.stat().st_size,sha256=digest(p)) for n,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest=root/'docs/development/artifact-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'));data['milestones'].insert(0,dict(path='runs/'+out.name,name='CPU 准备批次评估',status='PreparationBatchBelowGate',sourceBase='0a0429c',evidence='docs/acceptance/nr/cpu-preparation-batch.md',updateReductionPercent=balanced['updateReductionPercent'],candidateAdopted=False,nativeImageBatchStarted=False,formalPerformancePassed=False));manifest.write_text(json.dumps(data,indent=2,ensure_ascii=False).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md']:
 p=root/name;text=p.read_text(encoding='utf-8');needle='CPU 的[消费范围]' if name=='README.md' else '不可见透明顶点';start=text.index(needle);end=text.index('\n',start)
 line='[准备批次评估]('+('docs/acceptance/nr/' if name=='README.md' else '../acceptance/nr/')+'cpu-preparation-batch.md)的更新均值降低约 7.46%，未达到本批门槛，候选保持隔离。\n'
 p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-cpu-preparation-batch.md','docs/acceptance/nr/cpu-preparation-batch.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],evidenceBytes=package.stat().st_size,restoredChecks=6,userDiffPreserved=True)))
