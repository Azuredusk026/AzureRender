#pragma once
#include "render/LinearMath.hpp"
#include "render/StableDepthOrder.hpp"
#include "render/RecordingWorkerPool.hpp"
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <vector>

namespace azurerender {
struct TransparentPrimitiveRange {std::uint32_t firstIndex=0,indexCount=0;};
struct TransparentPrimitiveTopology {
    TransparentPrimitiveRange range;
    std::vector<std::uint32_t> localIndices;
};
// The source index storage is immutable and outlives this prepared topology.
struct TransparentTopology {
    const std::uint32_t* sourceIndices=nullptr;
    std::size_t sourceIndexCount=0,sourceVertexCount=0;
    bool prepared=false;
    std::vector<std::uint32_t> vertices;
    std::vector<TransparentPrimitiveTopology> primitives;
};
inline TransparentTopology prepareTransparentTopology(const std::vector<std::uint32_t>& indices,
    std::size_t vertexCount,const std::vector<TransparentPrimitiveRange>& ranges){
    if(vertexCount>UINT32_MAX)throw std::length_error("Transparent vertices exceed index addressing");
    TransparentTopology result;result.sourceIndices=indices.data();result.sourceIndexCount=indices.size();result.sourceVertexCount=vertexCount;
    if(ranges.empty()){result.prepared=true;return result;}
    std::vector<std::uint32_t> remap(vertexCount,UINT32_MAX);result.primitives.reserve(ranges.size());
    for(const auto& range:ranges){
        if(std::uint64_t(range.firstIndex)+range.indexCount>indices.size())throw std::out_of_range("Transparent primitive exceeds source indices");
        TransparentPrimitiveTopology primitive;primitive.range=range;const auto complete=(range.indexCount/3)*3;
        primitive.localIndices.reserve(complete);
        for(std::uint32_t i=0;i<complete;++i){const auto original=indices[range.firstIndex+i];
            if(original>=vertexCount)throw std::out_of_range("Transparent index exceeds source vertices");
            auto& local=remap[original];if(local==UINT32_MAX){local=static_cast<std::uint32_t>(result.vertices.size());result.vertices.push_back(original);}
            primitive.localIndices.push_back(local);
        }
        result.primitives.push_back(std::move(primitive));
    }
    result.prepared=true;return result;
}
struct TransparentTopologyWorkspace {
    std::vector<internal::Vector3> worldPositions;
    std::vector<std::uint32_t> order;
    std::vector<float> depths;
    DepthOrderWorkspace sort;
};
struct TransparentTopologyJob {
    const TransparentTopology* topology=nullptr;
    std::uint32_t* output=nullptr;
};
struct TransparentBatchWorkspace {
    std::vector<TransparentTopologyWorkspace> lanes;
    std::vector<std::vector<internal::Vector3>> positions;
};
inline void writeSortedTransparentPrimitive(const TransparentTopology& topology,
    const TransparentPrimitiveTopology& primitive,const std::vector<internal::Vector3>& positions,
    const internal::Vector3& cameraPosition,const internal::Vector3& cameraForward,
    std::uint32_t* output,TransparentTopologyWorkspace& scratch){
    const auto triangles=primitive.range.indexCount/3;scratch.order.resize(triangles);scratch.depths.resize(triangles);
    for(std::uint32_t triangle=0;triangle<triangles;++triangle){
        scratch.order[triangle]=triangle;const auto base=triangle*3;
        const auto& v0=positions[primitive.localIndices[base]];
        const auto& v1=positions[primitive.localIndices[base+1]];
        const auto& v2=positions[primitive.localIndices[base+2]];
        const internal::Vector3 centroid={(v0[0]+v1[0]+v2[0])*(1.0F/3.0F),
            (v0[1]+v1[1]+v2[1])*(1.0F/3.0F),(v0[2]+v1[2]+v2[2])*(1.0F/3.0F)};
        scratch.depths[triangle]=internal::dot(internal::subtract(centroid,cameraPosition),cameraForward);
    }
    stableDepthOrder(scratch.order,scratch.depths,scratch.sort);
    for(std::uint32_t triangle=0;triangle<triangles;++triangle){const auto base=primitive.range.firstIndex+scratch.order[triangle]*3;
        output[triangle*3]=topology.sourceIndices[base];output[triangle*3+1]=topology.sourceIndices[base+1];output[triangle*3+2]=topology.sourceIndices[base+2];}
}
template<class Position>
void writeSortedTransparentIndices(const TransparentTopology& topology,Position&& position,
    const internal::Vector3& cameraPosition,const internal::Vector3& cameraForward,
    std::uint32_t* output,TransparentTopologyWorkspace& scratch,RecordingWorkerPool* workers=nullptr){
    if(!topology.prepared)throw std::logic_error("Transparent topology is not prepared");
    if(!output)for(const auto& primitive:topology.primitives)
        if(primitive.range.indexCount)throw std::invalid_argument("Transparent output storage is missing");
    scratch.worldPositions.resize(topology.vertices.size());
    const auto fill=[&](std::size_t first,std::size_t last){
        for(std::size_t i=first;i<last;++i)scratch.worldPositions[i]=position(topology.vertices[i]);};
    if(workers&&topology.vertices.size()>=4096){
        const auto tasks=std::min(workers->recordingThreadCount()*3,(topology.vertices.size()+1023)/1024);
        const auto span=(topology.vertices.size()+tasks-1)/tasks;
        std::vector<RecordingWorkerPool::Task> work;work.reserve(tasks);
        for(std::size_t first=0;first<topology.vertices.size();first+=span){const auto last=std::min(first+span,topology.vertices.size());
            work.push_back([&,first,last](std::size_t){fill(first,last);});}
        workers->runWithCaller(std::move(work));
    }else fill(0,topology.vertices.size());
    for(const auto& primitive:topology.primitives){
        writeSortedTransparentPrimitive(topology,primitive,scratch.worldPositions,cameraPosition,cameraForward,output,scratch);
        if(primitive.range.indexCount)output+=primitive.range.indexCount;
    }
}
// Jobs borrow immutable source storage and disjoint output ranges. Position is
// called concurrently as position(jobIndex, vertexIndex). Dispatch and workspace
// ownership stay with the pool owner; worker tasks never dispatch nested work.
template<class Position>
void writeSortedTransparentBatch(const std::vector<TransparentTopologyJob>& jobs,Position&& position,
    const internal::Vector3& cameraPosition,const internal::Vector3& cameraForward,
    TransparentBatchWorkspace& scratch,RecordingWorkerPool* workers=nullptr){
    std::size_t vertices=0;
    for(const auto& job:jobs){
        if(!job.topology||!job.topology->prepared)throw std::invalid_argument("Transparent batch requires prepared topology");
        for(const auto& primitive:job.topology->primitives)
            if(primitive.range.indexCount&&!job.output)throw std::invalid_argument("Transparent batch output storage is missing");
        vertices+=job.topology->vertices.size();
    }
    if(jobs.empty())return;
    const bool parallel=workers&&jobs.size()>1&&vertices>=8192;
    scratch.lanes.resize(parallel?workers->recordingThreadCount():1);
    if(!parallel){
        for(std::size_t i=0;i<jobs.size();++i){const auto& job=jobs[i];
            writeSortedTransparentIndices(*job.topology,[&](std::uint32_t vertex){return position(i,vertex);},
                cameraPosition,cameraForward,job.output,scratch.lanes[0],workers);}
        return;
    }
    scratch.positions.resize(jobs.size());std::vector<std::size_t> offsets(jobs.size()+1);
    for(std::size_t i=0;i<jobs.size();++i){scratch.positions[i].resize(jobs[i].topology->vertices.size());offsets[i+1]=offsets[i]+scratch.positions[i].size();}
    const auto count=std::min(workers->recordingThreadCount()*3,(vertices+1023)/1024);
    const auto span=(vertices+count-1)/count;
    std::vector<RecordingWorkerPool::Task> tasks;tasks.reserve(count);
    for(std::size_t first=0;first<vertices;first+=span){const auto last=std::min(first+span,vertices);
        tasks.push_back([&,first,last](std::size_t){
            auto job=static_cast<std::size_t>(std::upper_bound(offsets.begin(),offsets.end(),first)-offsets.begin()-1);
            auto cursor=first;
            while(cursor<last){const auto end=std::min(last,offsets[job+1]);const auto& topology=*jobs[job].topology;
                for(;cursor<end;++cursor){const auto local=cursor-offsets[job];scratch.positions[job][local]=position(job,topology.vertices[local]);}
                ++job;
            }
        });
    }
    workers->runWithCaller(std::move(tasks));
    tasks.clear();
    for(std::size_t i=0;i<jobs.size();++i){const auto& topology=*jobs[i].topology;auto* output=jobs[i].output;
        for(const auto& primitive:topology.primitives){
            if(primitive.range.indexCount){const auto* selected=&primitive;auto* destination=output;
                tasks.push_back([&,i,selected,destination](std::size_t lane){
                    writeSortedTransparentPrimitive(*jobs[i].topology,*selected,scratch.positions[i],cameraPosition,cameraForward,destination,scratch.lanes[lane]);});
                output+=primitive.range.indexCount;
            }
        }
    }
    workers->runWithCaller(std::move(tasks));
}
}
