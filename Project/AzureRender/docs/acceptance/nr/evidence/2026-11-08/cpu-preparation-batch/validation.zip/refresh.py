from pathlib import Path
import os,sys,subprocess,json,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
config='Debug' if '--debug' in sys.argv else 'Release'
targets=['AzureMotionRecordingTests','AzureTransparentTopologyTests','AzureStaticSkinningRecordingTests','AzureMotionVectorGpuTests']
env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'),CMAKE_BUILD_PARALLEL_LEVEL='3')
command=[str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(root/'tools/build_provenance.py'),'build','--source',str(root),'--build-dir',str(root/('build/ninja-msvc-'+config.lower())),'--config',config]
for target in targets:command+=['--test-target',target]
start=time.monotonic()
with (out/(config.lower()+'-refresh.log')).open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
(out/(config.lower()+'-refresh.json')).write_text(json.dumps(dict(command=command,exitCode=result.returncode,seconds=time.monotonic()-start),indent=2));assert result.returncode==0,(out/(config.lower()+'-refresh.log')).read_text(errors='replace')[-4000:]
print(config+' production provenance refreshed',flush=True)
