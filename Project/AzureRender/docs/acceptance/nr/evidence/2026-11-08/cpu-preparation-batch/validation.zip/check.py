from pathlib import Path
import os,sys,subprocess,json,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;rows=[]
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
for config in ['release','debug']:
 build=root/('build/ninja-msvc-'+config)
 for device,driver,pattern in [('contract',None,r'^AzureRender\.(MotionRecording|TransparentTopology|StaticSkinningRecording)$'),('nvidia','*nv-vk64*',r'^AzureRender.MotionVectorGpu$'),('intel','*igvk64*',r'^AzureRender.MotionVectorGpu$')]:
  env=os.environ.copy();env.update(TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'));env['PATH']=str(build)+';'+env['PATH']
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
  if driver:env['VK_LOADER_DRIVERS_SELECT']=driver
  label=config+'-'+device;command=[ctest,'--test-dir',str(build),'-R',pattern,'--output-on-failure','--timeout','120','--output-junit',str(out/(label+'.xml'))];start=time.monotonic()
  with (out/(label+'-tests.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  row=dict(configuration=config,device=device,command=command,exitCode=r.returncode,seconds=time.monotonic()-start);rows.append(row);(out/'production-tests.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
  assert r.returncode==0,(out/(label+'-tests.log')).read_text(errors='replace')[-2500:]
