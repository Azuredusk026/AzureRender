from pathlib import Path
out=Path(__file__).resolve().parent;b=out/'balanced';b.mkdir(exist_ok=True)
s=(out/'prepare_profiles.py').read_text().replace("out/'baseline-source","out.parent/'baseline-source")
(b/'prepare_profiles.py').write_text(s)
(b/'build_profiles.py').write_bytes((out/'build_profiles.py').read_bytes())
s=(out/'evaluate.py').read_text().replace('out.name,command','out.parent.name,command').replace("out/'process.log'","out.parent/'process.log'")
(b/'evaluate.py').write_text(s)
