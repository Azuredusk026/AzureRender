from pathlib import Path
import json,sys,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
original=json.loads((out.parent/'20261108-065642-receiver-linear-depth-ecc3b4/export-baseline.json').read_text())['sourceInputs']
rows=[]
for saved in sorted((out/'baseline-source').rglob('*')):
 if not saved.is_file():continue
 relative=saved.relative_to(out/'baseline-source');target=root/relative
 assert target.resolve().is_relative_to(root)
 current=out/'final-source'/relative;current.parent.mkdir(parents=True,exist_ok=True)
 if not current.exists():current.write_bytes(target.read_bytes())
 raw=saved.read_bytes();expected=original.get(relative.as_posix(),hashlib.sha256(raw).hexdigest());lf=raw.replace(b'\r\n',b'\n');options=[raw,lf,lf.replace(b'\n',b'\r\n')]
 restored=next((b for b in options if hashlib.sha256(b).hexdigest()==expected),None);assert restored is not None,str(relative)
 rows.append(dict(path=relative.as_posix(),candidateSha256=digest(current),restoredSha256=expected));target.write_bytes(restored)
doc=root/'docs/development/cpu-preparation.md';saved=out/'final-source/cpu-preparation.md';saved.write_bytes(doc.read_bytes())
assert doc.resolve().is_relative_to(root/'docs/development');doc.unlink()
assert inputs(root)==original
(out/'restoration.json').write_text(json.dumps(dict(status='restored',sourceInputsExact=True,files=rows),indent=2));print('Production source and original tests restored byte-for-byte',flush=True)
