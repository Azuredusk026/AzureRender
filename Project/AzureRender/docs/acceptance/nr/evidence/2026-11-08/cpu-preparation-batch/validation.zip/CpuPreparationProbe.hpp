
#pragma once
#include "rhi/Rhi.hpp"
#include <array>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <filesystem>
#include <nlohmann/json.hpp>
namespace azCpuBatch {
enum Stage {Update,Instances,Transparent,Motion,Bindings,Count};
inline const std::array<const char*,Count> names{"update","instances","transparent","motion","bindings"};
inline std::array<unsigned long long,Count> ns{};
inline unsigned frames=0,selected=0;inline bool sampling=false;
inline unsigned long long buffers=0,images=0;
inline std::vector<double> updates;
inline void begin(){++frames;sampling=frames>=5&&frames<=40;if(sampling)++selected;}
struct Scope{Stage stage;bool active=sampling;std::chrono::steady_clock::time_point start;
explicit Scope(Stage s):stage(s){if(active)start=std::chrono::steady_clock::now();}
~Scope(){if(active){const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();ns[stage]+=elapsed;if(stage==Update)updates.push_back(double(elapsed)/1e6);}}};
inline void writeBuffer(azurerender::rhi::IRhi& rhi,const azurerender::rhi::DescriptorBufferWrite& write){if(sampling)++buffers;rhi.writeDescriptorBuffer(write);}
inline void writeImage(azurerender::rhi::IRhi& rhi,const azurerender::rhi::DescriptorImageWrite& write){if(sampling)++images;rhi.writeDescriptorImage(write);}
inline void dump(){const auto* path=std::getenv("AZURE_CPU_WORK_REPORT");if(!path||!selected)return;
nlohmann::json r={{"frames",frames},{"selectedFrames",selected},{"bufferWrites",buffers},{"imageWrites",images},{"updateSamplesMs",updates}};
for(unsigned i=0;i<Count;++i)r["stages"][names[i]]=double(ns[i])/1e6/selected;
std::ofstream(std::filesystem::u8path(path))<<r.dump(2)<<'\n';}
}
