from pathlib import Path
import subprocess,os,sys,json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
if '--inside' not in sys.argv:
 env=os.environ.copy();temporary=out/'tmp';temporary.mkdir(exist_ok=True)
 env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary))
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],cwd=root,env=env).returncode)
cmake='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
with (out/'red-build.log').open('wb') as log:r=subprocess.run([cmake,'--build','build/ninja-msvc-release','--target','AzureDepthPrefillRecordingTests','--parallel','3'],stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert r.returncode==0,(out/'red-build.log').read_text(errors='replace')[-3500:]
with (out/'red.log').open('wb') as log:r=subprocess.run([str(root/'build/ninja-msvc-release/AzureDepthPrefillRecordingTests.exe'),str(root/'build/ninja-msvc-release/shaders')],stdout=log,stderr=subprocess.STDOUT,timeout=60)
message=(out/'red.log').read_text(errors='replace');assert r.returncode!=0 and 'Default isolation pipeline count must follow the build option and material qualification' in message,message[-3500:]
(out/'red.json').write_text(json.dumps(dict(exitCode=r.returncode,expectedDefaultBuildIsolationDisabled=True),indent=2));print(message[-500:])
