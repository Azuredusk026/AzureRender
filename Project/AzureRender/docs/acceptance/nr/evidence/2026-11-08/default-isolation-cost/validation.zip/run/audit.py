from pathlib import Path
import json,sys,hashlib,subprocess
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
measured=json.loads((out/'measured-release-provenance.json').read_text());current=inputs(root)
changes=[name for name in sorted(current.keys()|measured['source'].keys()) if current.get(name)!=measured['source'].get(name)]
assert changes==['CMakeLists.txt','src/scenes/CharacterMaterialSampling.inc'],changes
rows=[]
for configuration in ['release','debug']:
 build=root/f'build/ninja-msvc-{configuration}';manifest=json.loads((build/'build-provenance.json').read_text());verify(root,manifest)
 catalog=json.loads((build/'shader-reload.json').read_text());assert len(catalog['programs'])==catalog['maximumPrograms']==673
 assert 'AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION:BOOL=OFF' in (build/'CMakeCache.txt').read_text()
 programs=sorted((build/'shaders').glob('*.spv'));assert len(programs)==673
 assert all(not p.name.endswith('_isolation0.frag.spv') and digest(p)==measured['products'][str((root/'build/ninja-msvc-release/shaders'/p.name).resolve())] for p in programs)
 assert 'AzureRender.DefaultIsolationViewGpu' not in (build/'CTestTestfile.cmake').read_text()
 rows.append(dict(configuration=configuration,defaultSpecialization=False,programs=673,programBytesUnchanged=True,manifestSha256=digest(build/'build-provenance.json')))
producer=out.parent/'20261108-150504-beauty-shader-specialization-2d2daa';fallback=json.loads((producer/'image-precision-fallback-control/results.json').read_text())
assert fallback['metadata']['defaultIsolationPipelines']==0 and not fallback['metadata']['defaultIsolationSelected']
assert len(fallback['frames'])==4 and all(row['changedPixels']==0 for row in fallback['frames'])
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
user=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest();assert user=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
report=dict(sourceChangesAfterMeasurement=changes,configurations=rows,defaultImageEvidence=dict(scope='Existing native dynamic fallback control, unchanged programs and disabled specialization preparation',frames=fallback['frames'],newCaptureExecuted=False),userDiffSha256=user)
(out/'audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(configurations=rows,userDiffPreserved=True)))
