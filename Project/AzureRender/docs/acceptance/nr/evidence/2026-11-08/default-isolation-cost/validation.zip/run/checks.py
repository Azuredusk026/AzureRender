from pathlib import Path
import json,os,sys,subprocess,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;config=sys.argv[1];assert config in ['Release','Debug']
env=os.environ.copy();temporary=out/'tmp';env.update(TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary))
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
rows=[];ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
for label,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 env['VK_LOADER_DRIVERS_SELECT']=driver
 command=[ctest,'--test-dir',f'build/ninja-msvc-{config.lower()}','-R',r'^AzureRender\.(DepthPrefillRecording|BeautyCompositionGpu)$' if label=='nvidia' else r'^AzureRender\.BeautyCompositionGpu$','--output-on-failure','--no-tests=error','--output-junit',str(out/(config.lower()+'-final-'+label+'.xml'))]
 started=time.monotonic()
 with (out/(config.lower()+'-final-'+label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 rows.append(dict(label=label,command=command,exitCode=r.returncode,seconds=time.monotonic()-started));print(json.dumps(rows[-1]),flush=True)
 (out/(config.lower()+'-final-checks.json')).write_text(json.dumps(rows,indent=2));assert r.returncode==0,(out/(config.lower()+'-final-'+label+'.log')).read_text(errors='replace')[-5000:]
