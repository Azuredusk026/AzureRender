from pathlib import Path
import json,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;producer=out.parent/'20261108-150504-beauty-shader-specialization-2d2daa';sys.path.insert(0,str(root/'tools'));from build_provenance import digest
before=json.loads((producer/'production-provenance.json').read_text())[0]['source']
names=[name for name in before if name.startswith('src/') and name.endswith(('.cpp','.hpp','.inc'))]
assert all(digest(root/name)==before[name] for name in names)
source=(root/'src/scenes/CharacterSceneRenderer.cpp').read_text();private=(producer/'cost-baseline/CharacterSceneRenderer.cpp').read_text();include='#include "'+(producer/'cost-baseline/CharacterMaterialSampling.inc').as_posix()+'"';assert private.replace(include,'#include "CharacterMaterialSampling.inc"')==source
sampling=(root/'src/scenes/CharacterMaterialSampling.inc').read_text();private=(producer/'cost-baseline/CharacterMaterialSampling.inc').read_text();assert sampling.replace('    prepareDefaultIsolationPipeline(scene,desc);','    // Current-runtime control uses the dynamic isolation pipeline.')==private
source=(producer/'cost.py').read_text();source=source.replace("image=json.loads((out/'image-precision/results.json')","producer=out.parent/'20261108-150504-beauty-shader-specialization-2d2daa'\nimage=json.loads((producer/'image-precision/results.json')")
source=source.replace("out/'cost-baseline/ProbePlayer.exe'","producer/'cost-baseline/ProbePlayer.exe'").replace('Battery diagnosis,','Local diagnosis under recorded current power and thermal conditions,')
(out/'cost.py').write_text(source)
(out/'reference-proof.json').write_text(json.dumps(dict(cppSourcesVerified=len(names),rendererDifference='Default isolation preparation disabled',referenceExe=str(producer/'cost-baseline/ProbePlayer.exe'),referenceExeSha256=digest(producer/'cost-baseline/ProbePlayer.exe'),assetCacheWriterCurrent=True,projectAssetsCopied=False),indent=2))
print('Current C++ sources and private reference verified; assets shared')
