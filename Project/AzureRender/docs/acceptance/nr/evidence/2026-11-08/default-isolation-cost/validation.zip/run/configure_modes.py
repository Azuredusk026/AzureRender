from pathlib import Path
import os,sys,json,subprocess,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
if '--inside' not in sys.argv:
 env=os.environ.copy();temporary=out/'tmp';env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary))
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],cwd=root,env=env).returncode)
cmake='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe';rows=[]
def configure(mode):
 command=[cmake,'-S',str(root),'-B',str(build),'-DAZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION='+mode]
 with (out/('configure-'+mode.lower()+'.log')).open('wb') as log:subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=120,check=True)
 try:
  catalog=json.loads((build/'shader-reload.json').read_text());fast=[r for r in catalog['programs'] if r['output'].endswith('_isolation0.frag.spv')]
  enabled=mode=='ON';assert len(fast)==(64 if enabled else 0) and len(catalog['programs'])==(737 if enabled else 673)
  cache=(build/'CMakeCache.txt').read_text();ninja=re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.+)$',cache,re.M).group(1)
  commands=subprocess.check_output([ninja,'-C',str(build),'-t','commands','AzureRenderCore.lib'],text=True,encoding='utf-8').splitlines();renderer=next(r for r in commands if r.rstrip().endswith('CharacterSceneRenderer.cpp'))
  assert ('AZURE_DEFAULT_ISOLATION_VARIANTS=1' in renderer)==enabled
  registered='AzureRender.DefaultIsolationViewGpu' in (build/'CTestTestfile.cmake').read_text();assert registered==enabled
  rows.append(dict(mode=mode,programs=len(catalog['programs']),specializedPrograms=len(fast),coreDefinitionEnabled=enabled,gpuViewTestRegistered=registered,compileExecuted=False))
 finally:pass
try:configure('ON')
finally:configure('OFF')
(out/'configuration-modes.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
