from pathlib import Path
out=Path(__file__).resolve().parent;producer=out.parent/'20261108-150504-beauty-shader-specialization-2d2daa'
source=(producer/'red.py').read_text().replace('Default isolation must prepare four main-only ordinary pipelines','Default isolation pipeline count must follow the build option and material qualification').replace('expectedMissingDefaultIsolationPipelines=True','expectedDefaultBuildIsolationDisabled=True')
(out/'red.py').write_text(source)
