from pathlib import Path
import json,hashlib,subprocess,shutil,os,stat
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;rows=[];proof=[]
for configuration in ['release','debug']:
 build=root/f'build/ninja-msvc-{configuration}';manifest=json.loads((build/'build-provenance.json').read_text());proof.append(manifest)
 shutil.copyfile(build/'build-provenance.json',out/('measured-'+configuration+'-provenance.json'))
 paths=sorted((build/'shaders').glob('*_isolation0.frag.spv'));assert len(paths)==64
 for p in paths:
  assert p.resolve().parent==(build/'shaders').resolve() and not p.is_symlink()
  for parent in [p.parent,*p.parent.parents]:assert not (parent.stat().st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT)
  sha=hashlib.sha256(p.read_bytes()).hexdigest();assert sha==manifest['products'][str(p.resolve())]
  rows.append(dict(path=str(p.resolve()),relative=p.relative_to(root).as_posix(),sha256=sha,bytes=p.stat().st_size))
assert not subprocess.check_output(['git','ls-files','--',*[row['relative'] for row in rows]]).strip()
for name in ['CMakeLists.txt','src/scenes/CharacterMaterialSampling.inc']:
 blob=subprocess.check_output(['git','show','8220444:Project/AzureRender/'+name]);expected=proof[0]['source'][name]
 candidates=[blob,blob.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')];matching=[b for b in candidates if hashlib.sha256(b).hexdigest()==expected];assert matching,name
 target=out/'measured-source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(matching[0])
current=(root/'src/scenes/CharacterMaterialSampling.inc').read_text();original=(out/'measured-source/src/scenes/CharacterMaterialSampling.inc').read_text()
stripped=current.replace('#if defined(AZURE_DEFAULT_ISOLATION_VARIANTS)\n','').replace('#else\n    (void)scene;(void)desc;\n#endif\n','');assert stripped==original
receipt=root/'build/maintenance/default-isolation-variant-cleanup.json';receipt.write_text(json.dumps(dict(status='planned',paths=rows,ordinaryAssetsTouched=False),indent=2))
freeBefore=shutil.disk_usage(root).free
for row in rows:
 p=Path(row['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];p.unlink()
freeAfter=shutil.disk_usage(root).free
report=dict(status='applied',files=len(rows),logicalBytes=sum(row['bytes'] for row in rows),freeBeforeBytes=freeBefore,freeAfterBytes=freeAfter,actualFreedBytes=freeAfter-freeBefore,paths=rows,enabledBranchSourceUnchanged=True,ordinaryAssetsTouched=False)
receipt.write_text(json.dumps(report,indent=2));(out/'variant-cleanup.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='paths'}))
