from pathlib import Path
import json,hashlib,zipfile,sys,re,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import digest,verify
cost=json.loads((out/'cost-results-v1.json').read_text());assert cost['bracketStable'] and cost['sourceAndProductsUnchanged'] and cost['projectInputsVerified']==1729
assert cost['gpuReductionFraction']<cost['bracketDriftFraction'] and cost['gpuSavedMs']<.1
assert len(set(tuple(row['sceneExtent']) for row in cost['rows']))==1
assert all(row['environment']['acLineStates']==[1] and not row['environment']['thermalSlowdownObserved'] for row in cost['rows'])
checks=[]
for config in ['release','debug']:
 verify(root,json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text()))
 for device in ['nvidia','intel']:
  file=config+'-final-'+device+'.xml'
  for case in ET.parse(out/file).getroot().findall('testcase'):
   assert case.find('failure') is None and case.attrib['status']=='run'
   text=case.findtext('system-out') or '';assert not any(s in text for s in ['Validation Error:','SYNC-HAZARD','VUID-'])
   checks.append(dict(configuration=config,device=device,name=case.attrib['name'],seconds=case.attrib['time'],evidenceFile='run/'+file,outputSha256=hashlib.sha256(text.encode()).hexdigest()))
assert len(checks)==6
for path in [out/'startup-environment.json',*(out/('cost-v1-'+label)/'environment.json' for label in ['baseline-before','candidate','baseline-after'])]:
 data=json.loads(path.read_text())
 def sanitize(value):
  if isinstance(value,dict):return {k:sanitize(v) for k,v in value.items() if k!='rawXml'}
  if isinstance(value,list):return [sanitize(v) for v in value]
  return value
 path.with_name(path.stem+'-summary.json').write_text(json.dumps(sanitize(data),indent=2))
audit=json.loads((out/'audit.json').read_text());configuration=json.loads((out/'configuration-modes.json').read_text());assert configuration[0]['mode']=='ON' and configuration[1]['mode']=='OFF'
cleanup=[json.loads((out/name).read_text()) for name in ['variant-cleanup.json','disabled-test-cleanup.json']]
assert all(row['status']=='applied' for row in cleanup)
sources=['CMakeLists.txt','src/scenes/CharacterMaterialSampling.inc','tests/DepthPrefillRecordingTests.cpp'];members={}
for p in out.rglob('*'):
 if not p.is_file() or 'tmp' in p.relative_to(out).parts:continue
 if p.name in ['startup-environment.json','environment.json']:continue
 if p.suffix not in ['.py','.json','.log','.xml','.csv','.cpp','.inc','.txt']:continue
 if not p.stat().st_size or p.stat().st_size>2*2**20:continue
 members['run/'+p.relative_to(out).as_posix()]=p
for name in sources:members['source/'+name]=root/name
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/default-isolation-cost';evidence.mkdir(parents=True,exist_ok=True);package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(members.items()):z.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,path in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='insignificant-local-cost-default-disabled',sourceBase='8220444',sourceHashes={name:digest(root/name) for name in sources},cost=cost,significantGainObserved=False,defaultSpecializationEnabled=False,experimentalBuildOption='AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION',checks=checks,configurationModes=configuration,productionAudit=audit,
 cleanup=dict(files=sum(row['files'] for row in cleanup),logicalBytes=sum(row['logicalBytes'] for row in cleanup),actualFreedBytes=sum(row['actualFreedBytes'] for row in cleanup)),nativeImageRecaptureExecuted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package))
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'docs/development/artifact-manifest.json';data=json.loads(p.read_text(encoding='utf-8'));data['milestones'].insert(0,dict(path='runs/'+out.name,name='默认隔离策略成本',status='InsignificantLocalCostDefaultDisabled',sourceBase='8220444',evidence='docs/acceptance/nr/default-isolation-cost.md',checksPassed=6,gpuSavedMs=cost['gpuSavedMs'],significantGainObserved=False,defaultSpecializationEnabled=False,reclaimedFiles=report['cleanup']['files'],formalPerformancePassed=False))
p.write_text(json.dumps(data,ensure_ascii=False,indent=2).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-06-performance-bottlenecks.md','docs/plans/2026-11-08-default-isolation-cost.md','docs/plans/2026-11-08-beauty-shader-specialization.md','docs/development/default-isolation-pipelines.md','docs/acceptance/nr/default-isolation-pipelines.md','docs/acceptance/nr/default-isolation-cost.md','docs/acceptance/nr/radiance-precision-boundaries.md']:
 path=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (path.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],checks=len(checks),gpuSavedMs=cost['gpuSavedMs'],reclaimedBytes=report['cleanup']['actualFreedBytes'],evidenceBytes=package.stat().st_size)))
