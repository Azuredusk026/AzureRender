from pathlib import Path
import json,hashlib,shutil,subprocess,stat
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;paths=[]
for config in ['release','debug']:
 build=root/f'build/ninja-msvc-{config}';assert 'AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION:BOOL=OFF' in (build/'CMakeCache.txt').read_text()
 assert 'AzureRender.DefaultIsolationViewGpu' not in (build/'CTestTestfile.cmake').read_text()
 manifest=json.loads((build/'build-provenance.json').read_text())
 for suffix in ['.exe','.pdb','.ilk']:
  p=build/('AzureDefaultIsolationViewGpuTests'+suffix)
  if p.exists():paths.append(p)
 folder=build/'CMakeFiles/AzureDefaultIsolationViewGpuTests.dir'
 for name in ['embed.manifest','intermediate.manifest','manifest.rc','manifest.res','vc140.pdb','tests/DefaultIsolationViewGpuTests.cpp.obj']:
  p=folder/name
  if p.exists():paths.append(p)
 assert not any(str(p.resolve()) in manifest['products'] for p in paths)
rows=[]
for p in paths:
 assert p.is_file() and p.resolve().is_relative_to(root/'build')
 for parent in [p,*p.parents]:assert not (parent.stat().st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT)
 rows.append(dict(path=str(p.resolve()),relative=p.relative_to(root).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
assert not subprocess.check_output(['git','ls-files','--',*[r['relative'] for r in rows]]).strip()
receipt=root/'build/maintenance/disabled-isolation-test-cleanup.json';receipt.write_text(json.dumps(dict(status='planned',paths=rows),indent=2))
freeBefore=shutil.disk_usage(root).free
for row in rows:
 p=Path(row['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];p.unlink()
report=dict(status='applied',files=len(rows),logicalBytes=sum(r['bytes'] for r in rows),freeBeforeBytes=freeBefore,freeAfterBytes=shutil.disk_usage(root).free,paths=rows,rebuildOption='AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION=ON',primaryBuildsTouched=False)
report['actualFreedBytes']=report['freeAfterBytes']-freeBefore;receipt.write_text(json.dumps(report,indent=2));(out/'disabled-test-cleanup.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='paths'}))
