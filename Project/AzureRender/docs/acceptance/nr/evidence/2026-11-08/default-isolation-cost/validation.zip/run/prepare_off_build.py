from pathlib import Path
root=Path.cwd();out=Path(__file__).resolve().parent;prior=out.parent/'20261108-163603-radiance-precision-boundaries-fda484'
source=(prior/'build.py').read_text().replace("['AzureBeautyCompositionGpuTests']","['AzureDepthPrefillRecordingTests','AzureBeautyCompositionGpuTests']");(out/'build.py').write_text(source)
source=(prior/'checks.py').read_text().replace("r'^AzureRender\\.BeautyCompositionGpu$'","r'^AzureRender\\.(DepthPrefillRecording|BeautyCompositionGpu)$' if label=='nvidia' else r'^AzureRender\\.BeautyCompositionGpu$'")
(out/'checks.py').write_text(source)
