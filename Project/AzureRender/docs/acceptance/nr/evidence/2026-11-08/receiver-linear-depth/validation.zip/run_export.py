from pathlib import Path
import os,sys,json,subprocess,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
source=root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-current-gpu_frame2.rdc';before=digest(source);production=inputs(root)
os.environ.update(TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'),VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
(out/'export-baseline.json').write_text(json.dumps(dict(sourceSha256=before,sourceInputs=production),indent=2))
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'export.py')];start=time.monotonic()
try:
    with (out/'export-driver.log').open('wb') as log:r=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=120)
    code=r.returncode
except subprocess.TimeoutExpired:code=-1
report=dict(command=command,exitCode=code,seconds=time.monotonic()-start,sourceSha256=before,sourceUnchanged=digest(source)==before,productionSourceUnchanged=inputs(root)==production)
(out/'export-execution.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
assert code==0 and report['sourceUnchanged'] and report['productionSourceUnchanged'],(out/'export-result.json').read_text() if (out/'export-result.json').exists() else (out/'export-driver.log').read_text(errors='replace')[-1200:]
print((out/'export-result.json').read_text(),flush=True)
