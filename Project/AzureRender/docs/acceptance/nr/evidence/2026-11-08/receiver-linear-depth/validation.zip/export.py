import renderdoc as rd
from pathlib import Path
import json,traceback,os,struct,hashlib
root=Path(r'D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261108-065642-receiver-linear-depth-ecc3b4'
source=root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-current-gpu_frame2.rdc'
report=dict(status='running',source=str(source));cap=rd.OpenCaptureFile();controller=None;exit_code=1
(out/'export-result.json').write_text(json.dumps(report,indent=2))
try:
    assert cap.OpenFile(str(source),'',None)==rd.ResultCode.Succeeded
    report['status']='opening-replay';(out/'export-result.json').write_text(json.dumps(report,indent=2))
    status,controller=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
    report['status']='replayed';(out/'export-result.json').write_text(json.dumps(report,indent=2))
    events=[]
    def walk(actions):
        for action in actions:
            if action.numIndices==43044:events.append(action.eventId)
            walk(action.children)
    walk(controller.GetRootActions());assert events
    event=max(events);controller.SetFrameEvent(event,True);pipeline=controller.GetPipelineState();fragment=pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
    textures={str(t.resourceId):t for t in controller.GetTextures()};report['hairEvents']=events;report['shadeEvent']=event
    def save_depth(label,descriptor,event):
        texture=textures[str(descriptor.resource)];raw=bytes(controller.GetTextureData(texture.resourceId,rd.Subresource()))
        assert texture.width==2560 and texture.height==1440 and len(raw)==2560*1440*4
        (out/(label+'.bin')).write_bytes(raw)
        return dict(event=event,resource=str(texture.resourceId),format=texture.format.Name(),width=texture.width,height=texture.height,bytes=len(raw))
    snapshot=next(used.descriptor.resource for used in pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel) if fragment.readOnlyResources[used.access.index].fixedBindNumber==18)
    texture=textures[str(snapshot)];raw=bytes(controller.GetTextureData(snapshot,rd.Subresource()))
    assert texture.width==2560 and texture.height==1440 and texture.format.Name()=='R32_FLOAT' and len(raw)==2560*1440*4
    queries=(root/'build/runs/20261108-041637-object-receiver-origin-7a2735/region-queries.bin').read_bytes()
    selected=bytearray()
    for x,y,depth,index in struct.iter_unpack('<4f',queries):
        offset=((1439-int(y))*2560+int(x))*4;selected.extend(raw[offset:offset+4])
    (out/'linear-depths.bin').write_bytes(selected)
    report['linearDepth']=dict(resource=str(snapshot),format=texture.format.Name(),width=texture.width,height=texture.height,fullBytes=len(raw),fullSha256=hashlib.sha256(raw).hexdigest(),selectedBytes=len(selected),selectedSha256=hashlib.sha256(selected).hexdigest())
    for index,block in enumerate(fragment.constantBlocks):
        if block.fixedBindNumber==0 and block.bufferBacked:
            descriptor=pipeline.GetConstantBlock(rd.ShaderStage.Pixel,index,0).descriptor
            camera=bytes(controller.GetBufferData(descriptor.resource,descriptor.byteOffset,descriptor.byteSize));assert len(camera)==640
            (out/'current-camera.bin').write_bytes(camera);report['cameraSha256']=hashlib.sha256(camera).hexdigest()
    report['status']='exported';exit_code=0
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
    if controller:controller.Shutdown()
    cap.Shutdown();(out/'export-result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
os._exit(exit_code)
