from pathlib import Path
import json
out=Path(__file__).resolve().parent
prior=out.parent/'20261108-061129-receiver-device-depth-357a94'
driver=(prior/'run_export.py').read_text()
(out/'run_export.py').write_text(driver)
export=(prior/'export.py').read_text()
export=export.replace(str(prior.name),out.name).replace('import json,traceback,os','import json,traceback,os,struct,hashlib')
begin=export.index("    report['mainDepth']=")
end=export.index("    report['status']='exported';exit_code=0")
export=export[:begin]+'''    snapshot=next(used.descriptor.resource for used in pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel) if fragment.readOnlyResources[used.access.index].fixedBindNumber==18)
    texture=textures[str(snapshot)];raw=bytes(controller.GetTextureData(snapshot,rd.Subresource()))
    assert texture.width==2560 and texture.height==1440 and texture.format.Name()=='R32_FLOAT' and len(raw)==2560*1440*4
    queries=(root/'build/runs/20261108-041637-object-receiver-origin-7a2735/region-queries.bin').read_bytes()
    selected=bytearray()
    for x,y,depth,index in struct.iter_unpack('<4f',queries):
        offset=((1439-int(y))*2560+int(x))*4;selected.extend(raw[offset:offset+4])
    (out/'linear-depths.bin').write_bytes(selected)
    report['linearDepth']=dict(resource=str(snapshot),format=texture.format.Name(),width=texture.width,height=texture.height,fullBytes=len(raw),fullSha256=hashlib.sha256(raw).hexdigest(),selectedBytes=len(selected),selectedSha256=hashlib.sha256(selected).hexdigest())
    for index,block in enumerate(fragment.constantBlocks):
        if block.fixedBindNumber==0 and block.bufferBacked:
            descriptor=pipeline.GetConstantBlock(rd.ShaderStage.Pixel,index,0).descriptor
            camera=bytes(controller.GetBufferData(descriptor.resource,descriptor.byteOffset,descriptor.byteSize));assert len(camera)==640
            (out/'current-camera.bin').write_bytes(camera);report['cameraSha256']=hashlib.sha256(camera).hexdigest()
''' +export[end:]
(out/'export.py').write_text(export)
