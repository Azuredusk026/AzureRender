from pathlib import Path
import os,json,subprocess,time
import numpy as np
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
model=out.parent/'20261108-041637-object-receiver-origin-7a2735'
source=out.parent/'20261027-022702-object-visibility-depth-reconstruction-c7312f'
queries=np.fromfile(model/'region-queries.bin',dtype='<f4').reshape(-1,4)
depth=np.fromfile(out/'linear-depths.bin',dtype='<f4');assert len(depth)==len(queries)==17017
camera=np.fromfile(out/'current-camera.bin',dtype='<f4').astype('f8')
native=np.fromfile(source/'producer-cb0.bin',dtype='<f4').reshape(-1,4)[24:28].T.astype('f8')
basis=np.diag([-1.,1,1,1]);basis[:3,3]=[-300,-300,300]
view=np.r_[camera[4:7],-np.dot(camera[4:7],camera[:3])]
L=view@basis@native;H=native[3,:]
x=2*queries[:,0].astype('f8')/2560-1;y=-(2*queries[:,1].astype('f8')/1440-1)
lb=L[0]*x+L[1]*y+L[3];hb=H[0]*x+H[1]*y+H[3]
mapped=((lb-depth.astype('f8')*hb)/(depth.astype('f8')*H[2]-L[2])).astype('<f4')
error=mapped.astype('f8')-queries[:,2]
report=dict(pixels=len(depth),depthRange=[float(depth.min()),float(depth.max())],depthUlp=float(np.spacing(depth[0])),exactNativeDepthPixels=int((mapped==queries[:,2]).sum()),nativeDepthAbsErrorMedian=float(np.median(abs(error))),nativeDepthAbsErrorP95=float(np.quantile(abs(error),.95)),nativeDepthAbsErrorMaximum=float(abs(error).max()),linearRow=L.tolist(),homogeneousRow=H.tolist(),cameraPosition=camera[:3].tolist(),cameraForward=camera[4:7].tolist())
(out/'linear-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
queries[:,2]=mapped;queries.tofile(out/'remapped-queries.bin')
config=json.loads((out.parent/'20261108-061129-receiver-device-depth-357a94/gpu-inputs.json').read_text())
config.update(queryBinary=str(out/'remapped-queries.bin'),resultPrefix='linear-depth-')
(out/'gpu-inputs.json').write_text(json.dumps(config,indent=2));(out/'receiver.spv').write_bytes((model/'receiver.spv').read_bytes())
env=os.environ.copy();env.update(TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'),VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
command=[str(model/'receiver.exe'),str(out)];start=time.monotonic()
with (out/'gpu.log').open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
(out/'gpu-execution.json').write_text(json.dumps(dict(command=command,exitCode=result.returncode,seconds=time.monotonic()-start),indent=2))
print((out/'linear-depth-result.json').read_text(),flush=True)
assert result.returncode in [0,1]
