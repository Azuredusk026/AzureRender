from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;config=sys.argv[1];assert config in ['Release','Debug']
env=os.environ.copy();temporary=out/'tmp';temporary.mkdir(exist_ok=True);env.update(TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary))
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
rows=[];ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
for label,driver,expression in [('nvidia','*nv-vk64*',r'^AzureRender\.(GpuTransparentIndexSort|GpuTransparentIndexSortGpu|NodeOpacityRecording|StaticSkinningRecording|DepthPrefillRecording)$'),('intel','*igvk64*',r'^AzureRender\.GpuTransparentIndexSortGpu$')]:
 env['VK_LOADER_DRIVERS_SELECT']=driver
 command=[ctest,'--test-dir',f'build/ninja-msvc-{config.lower()}','-R',expression,'--output-on-failure','--no-tests=error','--output-junit',str(out/(config.lower()+'-'+label+'.xml'))]
 started=time.monotonic()
 with (out/(config.lower()+'-'+label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 rows.append(dict(label=label,command=command,exitCode=r.returncode,seconds=time.monotonic()-started));print(json.dumps(rows[-1]),flush=True)
 (out/(config.lower()+'-checks.json')).write_text(json.dumps(rows,indent=2));assert r.returncode==0,(out/(config.lower()+'-'+label+'.log')).read_text(errors='replace')
for name in ['transparent_deform.comp','transparent_depth_keys.comp','transparent_index_scatter.comp']:
 command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(root/f'build/ninja-msvc-{config.lower()}/shaders/{name}.spv')]
 subprocess.run(command,cwd=root,env=env,check=True)
print(config+' transparent preparation functional checks passed',flush=True)
