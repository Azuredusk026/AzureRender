from pathlib import Path
import json,sys,subprocess,hashlib,zipfile,re,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
checks=[];proof=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,sha256=digest(p)))
 for label in ['nvidia','intel']:
  for case in ET.parse(out/(config+'-'+label+'.xml')).getroot().findall('testcase'):
   assert case.attrib['status']=='run' and case.find('failure') is None
   output=case.findtext('system-out') or ''
   if case.attrib['name'].endswith('Gpu'):assert 'validationErrors=0 liveBuffers=0 liveImages=0' in output
   checks.append(dict(configuration=config,label=label,name=case.attrib['name'],seconds=case.attrib['time'],output=output.strip()))
assert len(checks)==12
image=json.loads((out/'image/results.json').read_text());assert len(image['frames'])==4 and all(r['changedPixels']==0 for r in image['frames']) and image['gpuPrepared']
assert all(image[k] for k in ['sourceInputsUnchanged','productionProductsUnchanged','projectInputsUnchanged','validationLogClean','zeroAllocator'])
comparison=json.loads((out/'comparison.json').read_text());assert comparison['updateReductionPercent']>=20
boundaries=json.loads((out/'module-boundaries.json').read_text());assert boundaries['status']=='passed' and not boundaries['violations']
prior=json.loads((out/'baseline.json').read_text());unchanged={}
for config,products in prior['products'].items():
 programs={name:sha for name,sha in products.items() if name.endswith('.spv') and Path(name).parent.name=='shaders'}
 assert len(programs)==666 and all(digest(Path(name))==sha for name,sha in programs.items());unchanged[config]=len(programs)
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
sourceNames=['CMakeLists.txt','src/render/GpuTransparentIndexSort.hpp','src/render/GpuTransparentIndexSort.cpp','src/scenes/CharacterSceneRenderer.hpp','src/scenes/CharacterSceneRenderer.cpp','shaders/transparent_deform.comp','shaders/transparent_depth_keys.comp','shaders/transparent_index_scatter.comp','tests/GpuTransparentIndexSortTests.cpp','tests/GpuTransparentIndexSortGpuTests.cpp','tests/StaticSkinningRecordingTests.cpp']
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/gpu-transparent-index-sort';evidence.mkdir(parents=True,exist_ok=True)
(out/'source-inputs.json').write_text(json.dumps(inputs(root),indent=2))
members={}
for p in out.rglob('*'):
 if not p.is_file() or any(part in ['tmp','original-source'] for part in p.relative_to(out).parts):continue
 if p.suffix not in ['.py','.json','.log','.xml','.csv','.hpp','.inc','.cpp']:continue
 if p.stat().st_size>2*2**20:continue
 members['run/'+p.relative_to(out).as_posix()]=p
for name in sourceNames:members['source/'+name]=root/name
for config in ['release','debug']:
 for name in ['transparent_deform.comp','transparent_depth_keys.comp','transparent_index_scatter.comp','stable_key_sort.comp']:
  members[f'program/{config}/{name}.spv']=root/f'build/ninja-msvc-{config}/shaders/{name}.spv'
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='integrated-exact-images-local-cpu-preparation-improved',sourceBase='3b4fa9d',sourceHashes={name:digest(root/name) for name in sourceNames},checks=checks,unchangedPrograms=unchanged,moduleBoundaries=boundaries,productionProvenance=proof,userDiffSha256=protected,image=image,cpuPreparation=comparison,realAsset=json.loads((out/'real-asset-results.json').read_text()),cpuMeasurementScope='36 selected preparation samples per variant; draw binding correction validated separately; no GPU timing claim',sceneIntegrated=True,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package))
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest=root/'docs/development/artifact-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'));data['milestones']=[m for m in data['milestones'] if m['path']!='runs/'+out.name]
data['milestones'].insert(0,dict(path='runs/'+out.name,name='GPU 透明索引准备',status='IntegratedExactImagesLocalCpuImproved',sourceBase='3b4fa9d',evidence='docs/acceptance/nr/gpu-transparent-index-sort.md',checksPassed=12,sceneIntegrated=True,formalPerformancePassed=False))
manifest.write_text(json.dumps(data,indent=2,ensure_ascii=False).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md']:
 p=root/name;text=p.read_text(encoding='utf-8');prefix='docs/acceptance/nr/' if name=='README.md' else '../acceptance/nr/'
 line='[GPU 稳定排序机制]('+prefix+'gpu-stable-key-sort.md)通过六项双配置、双设备检查，透明场景集成继续实施。'
 replacement='[GPU 透明索引准备]('+prefix+'gpu-transparent-index-sort.md)通过十二项所属检查及严格四帧，局部 CPU 准备减少约 0.99 毫秒。'
 assert line in text;p.write_text(text.replace(line,replacement),encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-gpu-transparent-indices.md','docs/acceptance/nr/gpu-transparent-index-sort.md','docs/development/gpu-transparent-index-sort.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],checks=len(checks),evidenceBytes=package.stat().st_size,userDiffPreserved=True)))
