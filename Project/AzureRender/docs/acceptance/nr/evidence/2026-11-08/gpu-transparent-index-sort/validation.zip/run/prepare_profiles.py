from pathlib import Path
import json,subprocess,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
header=r'''
#pragma once
#include <array>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <filesystem>
#include <vector>
#include <nlohmann/json.hpp>
namespace azGpuPrepProbe {
enum Stage{Update,Instances,Transparent,Motion,Count};
inline const std::array<const char*,Count> names{"update","instances","transparent","motion"};
inline std::array<unsigned long long,Count> ns{};
inline unsigned frames=0,selected=0,gpuFrames=0,gpuRecordedFrames=0;
inline unsigned long long gpuVertices=0;inline bool sampling=false;
inline std::vector<double> updates;
inline void begin(){++frames;sampling=frames>=5&&frames<=40;if(sampling)++selected;}
struct Scope{Stage stage;bool active=sampling;std::chrono::steady_clock::time_point start;
explicit Scope(Stage value):stage(value){if(active)start=std::chrono::steady_clock::now();}
~Scope(){if(active){const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();ns[stage]+=elapsed;if(stage==Update)updates.push_back(double(elapsed)/1e6);}}};
inline void dump(){const auto* path=std::getenv("AZURE_CPU_WORK_REPORT");if(!path||!selected)return;
nlohmann::json report={{"frames",frames},{"selectedFrames",selected},{"gpuFrames",gpuFrames},{"gpuRecordedFrames",gpuRecordedFrames},{"gpuVertices",gpuVertices},{"updateSamplesMs",updates}};
for(unsigned i=0;i<Count;++i)report["stages"][names[i]]=double(ns[i])/1e6/selected;
std::ofstream(std::filesystem::u8path(path))<<report.dump(2)<<'\n';}
}
'''
(out/'CpuGpuPreparationProbe.hpp').write_text(header)
def entry(text,signature,code):
 start=text.index(signature);opening=text.index('{',start);return text[:opening+1]+'\n'+code+text[opening+1:]
for variant in ['baseline','candidate']:
 folder=out/variant;folder.mkdir(exist_ok=True)
 cpp=(out/'original-source/src/scenes/CharacterSceneRenderer.cpp').read_text() if variant=='baseline' else (root/'src/scenes/CharacterSceneRenderer.cpp').read_text()
 cpp=entry(cpp,'void CharacterSceneRenderer::updateFrame(','azGpuPrepProbe::begin();azGpuPrepProbe::Scope timer(azGpuPrepProbe::Update);')
 for name,stage in [('rebuildSceneInstances','Instances'),('prepareTransparentIndices','Transparent')]:cpp=entry(cpp,'void CharacterSceneRenderer::'+name+'(','azGpuPrepProbe::Scope timer(azGpuPrepProbe::'+stage+');')
 cpp=entry(cpp,'void CharacterSceneRenderer::onUnload(','azGpuPrepProbe::dump();')
 needle='    prepareTransparentIndices();';assert cpp.count(needle)==1
 cpp=cpp.replace(needle,needle+'\n    if(azGpuPrepProbe::sampling&&gpuTransparentTickets_[currentFrame_]){++azGpuPrepProbe::gpuFrames;azGpuPrepProbe::gpuVertices+=gpuTransparentTickets_[currentFrame_]->vertexCount;}')
 cpp=cpp.replace('owner->record(commands,*ticket);','owner->record(commands,*ticket);if(azGpuPrepProbe::sampling)++azGpuPrepProbe::gpuRecordedFrames;')
 motion=(root/'src/scenes/CharacterMotionPass.inc').read_text();motion=entry(motion,'void CharacterSceneRenderer::prepareMotion(','azGpuPrepProbe::Scope timer(azGpuPrepProbe::Motion);')
 (folder/'CharacterMotionPass.inc').write_text(motion);cpp=cpp.replace('#include "CharacterMotionPass.inc"','#include "'+(folder/'CharacterMotionPass.inc').as_posix()+'"')
 (folder/'CharacterSceneRenderer.cpp').write_text('#include "'+(out/'CpuGpuPreparationProbe.hpp').as_posix()+'"\n'+cpp)
build=root/'build/ninja-msvc-release';cache=(build/'CMakeCache.txt').read_text();ninja=re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.+)$',cache,re.M).group(1)
commands=subprocess.check_output([ninja,'-C',str(build),'-t','commands','AzurePlayer.exe'],text=True,encoding='utf-8').splitlines()
(out/'CharacterSceneRenderer-command.txt').write_text(next(c for c in commands if c.rstrip().endswith('CharacterSceneRenderer.cpp')))
rule=re.search(r'^build AzurePlayer\.exe: (\S+)',(build/'build.ninja').read_text(),re.M).group(1)
expanded=json.loads(subprocess.check_output([ninja,'-C',str(build),'-t','compdb','-x',rule],text=True,encoding='utf-8'));assert len(expanded)==1
(out/'link-command.txt').write_text(expanded[0]['command'])
print('Private baseline and GPU candidate profiles prepared')
