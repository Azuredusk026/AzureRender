from pathlib import Path
import json,sys,subprocess,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
owned=['CMakeLists.txt','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp']
for name in owned:
 p=out/'original-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/name).read_bytes())
products={}
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';m=json.loads(p.read_text());verify(root,m);products[config]=m['products']
(out/'baseline.json').write_text(json.dumps(dict(sourceInputs=inputs(root),products=products,owned={name:digest(root/name) for name in owned}),indent=2));print('Baseline source and products verified')
