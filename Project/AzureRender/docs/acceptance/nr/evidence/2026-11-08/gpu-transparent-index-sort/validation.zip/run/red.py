from pathlib import Path
import subprocess,os,json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;temporary=out/'tmp';temporary.mkdir(exist_ok=True)
env=os.environ.copy();env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary))
command=[str(root/'tools/msvc_env.bat'),'cl','/nologo','/std:c++20','/Zs','/Isrc','/ID:/Tools/VulkanSDK/1.4.350.0/Include','tests/GpuTransparentIndexSortTests.cpp']
with (out/'red.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
log=(out/'red.log').read_text(errors='replace');assert r.returncode!=0 and 'GpuTransparentIndexSort.hpp' in log and 'C1083' in log
(out/'red.json').write_text(json.dumps(dict(exitCode=r.returncode,command=command,expectedMissingPublicContract=True),indent=2));print(log[-1200:])
