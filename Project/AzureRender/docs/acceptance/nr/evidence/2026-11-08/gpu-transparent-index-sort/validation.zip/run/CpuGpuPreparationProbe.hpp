
#pragma once
#include <array>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <filesystem>
#include <vector>
#include <nlohmann/json.hpp>
namespace azGpuPrepProbe {
enum Stage{Update,Instances,Transparent,Motion,Count};
inline const std::array<const char*,Count> names{"update","instances","transparent","motion"};
inline std::array<unsigned long long,Count> ns{};
inline unsigned frames=0,selected=0,gpuFrames=0,gpuRecordedFrames=0;
inline unsigned long long gpuVertices=0;inline bool sampling=false;
inline std::vector<double> updates;
inline void begin(){++frames;sampling=frames>=5&&frames<=40;if(sampling)++selected;}
struct Scope{Stage stage;bool active=sampling;std::chrono::steady_clock::time_point start;
explicit Scope(Stage value):stage(value){if(active)start=std::chrono::steady_clock::now();}
~Scope(){if(active){const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();ns[stage]+=elapsed;if(stage==Update)updates.push_back(double(elapsed)/1e6);}}};
inline void dump(){const auto* path=std::getenv("AZURE_CPU_WORK_REPORT");if(!path||!selected)return;
nlohmann::json report={{"frames",frames},{"selectedFrames",selected},{"gpuFrames",gpuFrames},{"gpuRecordedFrames",gpuRecordedFrames},{"gpuVertices",gpuVertices},{"updateSamplesMs",updates}};
for(unsigned i=0;i<Count;++i)report["stages"][names[i]]=double(ns[i])/1e6/selected;
std::ofstream(std::filesystem::u8path(path))<<report.dump(2)<<'\n';}
}
