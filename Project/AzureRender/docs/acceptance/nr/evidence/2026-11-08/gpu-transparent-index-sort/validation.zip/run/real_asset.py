from pathlib import Path
import subprocess,os,json,sys,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
source=inputs(root);build=root/'build/ninja-msvc-release';asset=out.parent/'20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/content-character/hero-strand-line-013925.glb';sha=digest(asset)
assert sha=='f91eb2c9cce2009d5c8753170e465b2c6151ddb5368859fa784fb0a8b7ee11f8'
products={str(p):digest(p) for p in [build/'AzureGpuTransparentIndexSortGpuTests.exe',*[build/'shaders'/name for name in ['transparent_deform.comp.spv','transparent_depth_keys.comp.spv','transparent_index_scatter.comp.spv','stable_key_sort.comp.spv']]]}
env=os.environ.copy();env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'),TMPDIR=str(out/'tmp'))
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
rows=[]
for label,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 env['VK_LOADER_DRIVERS_SELECT']=driver;command=[str(build/'AzureGpuTransparentIndexSortGpuTests.exe'),str(build/'shaders'),str(asset)];started=time.monotonic()
 with (out/('real-'+label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 rows.append(dict(device=label,command=command,exitCode=r.returncode,seconds=time.monotonic()-started));print(json.dumps(rows[-1]),flush=True)
 (out/'real-asset-results.json').write_text(json.dumps(dict(asset=str(asset),assetSha256=sha,products=products,rows=rows),indent=2))
 assert r.returncode==0,(out/('real-'+label+'.log')).read_text(errors='replace')
assert inputs(root)==source and digest(asset)==sha and all(digest(Path(p))==value for p,value in products.items())
