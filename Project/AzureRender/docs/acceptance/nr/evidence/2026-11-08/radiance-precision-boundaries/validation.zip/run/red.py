from pathlib import Path
import subprocess,json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe',str(root/'shaders/beauty_composition_test.comp'),'-o',str(out/'missing-library.comp.spv')]
r=subprocess.run(command,capture_output=True,timeout=30);(out/'red.log').write_bytes(r.stdout+r.stderr)
assert r.returncode!=0 and b'beauty_composition.glsl' in r.stderr and b'include' in r.stderr.lower(),r.stderr
(out/'red.json').write_text(json.dumps(dict(command=command,exitCode=r.returncode,expectedMissingSharedCompositionContract=True),indent=2));print(r.stderr.decode(errors='replace')[-700:])
