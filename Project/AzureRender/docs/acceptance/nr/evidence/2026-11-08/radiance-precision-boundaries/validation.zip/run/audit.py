from pathlib import Path
import json,sys,hashlib,subprocess
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import digest,verify
baseline=json.loads((out/'baseline-programs.json').read_text());rows=[]
for old in baseline['configurations']:
 build=root/('build/ninja-msvc-'+old['configuration']);manifest=json.loads((build/'build-provenance.json').read_text());verify(root,manifest)
 assert all(digest(build/'shaders'/name)==sha for name,sha in old['programs'].items())
 current={p.name for p in (build/'shaders').glob('*.spv')};assert current-set(old['programs'])=={'beauty_composition_test.comp.spv'}
 rows.append(dict(configuration=old['configuration'],existingProgramsUnchanged=736,newPrograms=1,manifestSha256=digest(build/'build-provenance.json')))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
user=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest();assert user==baseline['userDiffSha256']
(out/'audit.json').write_text(json.dumps(dict(configurations=rows,userDiffSha256=user,originalFourFrameProgramsUnchanged=True,nativeSceneRerunRequired=False),indent=2));print(json.dumps(rows))
