from pathlib import Path
import json,sys,hashlib,subprocess
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import digest
rows=[]
for configuration in ['release','debug']:
 build=root/f'build/ninja-msvc-{configuration}';manifest=json.loads((build/'build-provenance.json').read_text());programs={p.name:digest(p) for p in (build/'shaders').glob('*.spv')}
 assert len(programs)==736
 assert all(sha==manifest['products'][str((build/'shaders'/name).resolve())] for name,sha in programs.items())
 rows.append(dict(configuration=configuration,programs=programs))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
user=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest();assert user=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
(out/'baseline-programs.json').write_text(json.dumps(dict(configurations=rows,userDiffSha256=user),indent=2));print('Both current 736-program inventories frozen; protected user diff unchanged')
