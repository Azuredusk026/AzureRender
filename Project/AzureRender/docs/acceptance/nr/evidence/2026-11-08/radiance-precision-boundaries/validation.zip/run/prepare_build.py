from pathlib import Path
root=Path.cwd();out=Path(__file__).resolve().parent;prior=out.parent/'20261108-150504-beauty-shader-specialization-2d2daa'
source=(prior/'build.py').read_text();start=source.index('for target in [');end=source.index(':\n command+=',start)
source=source[:start]+"for target in ['AzureBeautyCompositionGpuTests']"+source[end:];(out/'build.py').write_text(source)
source=(prior/'final_checks.py').read_text().replace('DefaultIsolationViewGpu','BeautyCompositionGpu');(out/'checks.py').write_text(source)
