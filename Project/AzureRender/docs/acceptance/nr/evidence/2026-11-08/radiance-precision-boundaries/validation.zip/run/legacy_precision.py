from pathlib import Path
import json,zipfile,hashlib,subprocess
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
archive=root/'docs/acceptance/nr/evidence/2026-11-08/radiance-receiver-entry/validation.zip';z=zipfile.ZipFile(archive);metadata=json.loads(z.read('preparation.json'))
old=zipfile.ZipFile(root/'docs/acceptance/nr/evidence/2026-11-07/surface-radiance-reuse/measurements.zip');differences=json.loads(old.read('image/pixel-differences.json'))
recent=zipfile.ZipFile(root/'docs/acceptance/nr/evidence/2026-11-08/default-isolation-pipelines/validation.zip');other=json.loads(recent.read('run/image/difference-pixels.json'))
byFrame={row['frame']:row['pixels'] for row in other};matches=[]
for row in differences:
 for p in row['differences']:
  candidates=[q for q in byFrame[row['frame']] if (p['x'],p['y'])==(q['x'],q['y'])]
  assert len(candidates)==1 and p['baseline']==candidates[0]['expected'] and p['candidate']==candidates[0]['actual']
  matches.append(dict(frame=row['frame'],**p))
assert len(matches)==5
(out/'correlation.json').write_text(json.dumps(dict(matches=matches,commonPixelSamples=5,legacyPixelSamples=5,isolationPixelSamples=6,sameDirectionsAndValues=True,causalityEstablished=False),indent=2))
folders={}
for variant in ['base','precise']:
 folder=out/'legacy'/variant;source=folder/'source';programs=folder/'shaders';source.mkdir(parents=True,exist_ok=True);programs.mkdir(exist_ok=True);folders[variant]=(source,programs)
 for name in z.namelist():
  if name.startswith('source/') and name.endswith(('.frag','.vert','.glsl')):(source/Path(name).name).write_bytes(z.read(name))
 # The current shared includes consume the dynamic isolation alias.
 mesh=source/'mesh.frag';lines=mesh.read_text().splitlines(keepends=True);assert lines[0].startswith('#version ')
 lines.insert(1,'#define AZURE_QA_ISOLATION camera.qaParameters.x\n');mesh.write_text(''.join(lines))
 if variant=='precise':
  path=source/'surface_radiance_identity.glsl';text=path.read_text();needle='    return a.rgb+(blended-vec3(a.a,b.a,c.a));';assert text.count(needle)==1
  text=text.replace('#define AZURE_SURFACE_RADIANCE_IDENTITY_GLSL','#define AZURE_SURFACE_RADIANCE_IDENTITY_GLSL\n#include "beauty_composition.glsl"').replace(needle,'    return azureBeautyReplace(a.rgb,blended,vec3(a.a,b.a,c.a));');path.write_text(text)
rows=[]
for row in metadata['builds']:
 variants={}
 for variant,(source,programs) in folders.items():
  target=programs/row['file'];args=[row['command'][0],'--target-env=vulkan1.3',*[v for v in row['command'] if v.startswith('-D')],'-I'+str(source),'-I'+str(root/'shaders'),str(source/'mesh.frag'),'-o',str(target)]
  r=subprocess.run(args,capture_output=True,timeout=30);(programs/(row['file']+'.compile.log')).write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr.decode(errors='replace')[-1500:]
  subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.3',str(target)],check=True,capture_output=True,timeout=30)
  sha=hashlib.sha256(target.read_bytes()).hexdigest();variants[variant]=dict(sha256=sha,bytes=target.stat().st_size,command=args)
  if variant=='base':assert sha==row['sha256'],('Archived compiler control differs',row['file'],sha,row['sha256'])
 producer=row['file'].startswith('character_snapshot');same=variants['base']['sha256']==variants['precise']['sha256'];assert same==producer,(row['file'],same)
 rows.append(dict(program=row['file'],producer=producer,producerBytesPreserved=same,variants=variants));print(json.dumps(dict(program=row['file'],producer=producer,bytesUnchanged=same)),flush=True)
assert len(rows)==32
representative=next(row for row in rows if not row['producer']);counts={}
for variant in ['base','precise']:
 text=subprocess.check_output(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-dis.exe',str(folders[variant][1]/representative['program'])],text=True)
 counts[variant]=text.count(' NoContraction')
assert counts['precise']==counts['base']+2,counts
report=dict(sourceBase='b4fff22',archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),rows=rows,producerProgramsUnchanged=sum(row['producer'] for row in rows),consumerProgramsWithPreciseBoundary=sum(not row['producer'] for row in rows),representativeNoContraction=counts,queueSubmissions=0,nativeBatchStarted=False,wholeFrameBenefitMeasured=False,legacyCandidateStillIsolated=True)
(out/'legacy-precision.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='rows'}))
