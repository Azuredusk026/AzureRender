from pathlib import Path
import json,zipfile,hashlib,sys,xml.etree.ElementTree as ET,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import digest,verify
checks=[]
for config in ['release','debug']:
 verify(root,json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text()))
 for device in ['nvidia','intel']:
  file=config+'-final-'+device+'.xml';cases=ET.parse(out/file).getroot().findall('testcase');assert len(cases)==1
  case=cases[0];text=case.findtext('system-out') or '';assert case.find('failure') is None and case.attrib['status']=='run'
  assert '567 ordered components' in text and not any(s in text for s in ['Validation Error:','SYNC-HAZARD','VUID-'])
  assert ('NVIDIA' if device=='nvidia' else 'Intel') in text
  checks.append(dict(configuration=config,device=device,name=case.attrib['name'],seconds=case.attrib['time'],outputSha256=hashlib.sha256(text.encode()).hexdigest(),evidenceFile='run/'+file))
audit=json.loads((out/'audit.json').read_text());legacy=json.loads((out/'legacy-precision.json').read_text());correlation=json.loads((out/'correlation.json').read_text());boundaries=json.loads((out/'module-boundaries.json').read_text());assert boundaries['status']=='passed' and not boundaries['violations']
assert all(row['existingProgramsUnchanged']==736 for row in audit['configurations']);assert legacy['producerProgramsUnchanged']==legacy['consumerProgramsWithPreciseBoundary']==16
assert correlation['sameDirectionsAndValues'] and correlation['commonPixelSamples']==5
sources=['CMakeLists.txt','shaders/mesh.frag','shaders/beauty_composition.glsl','shaders/beauty_composition_test.comp','tests/BeautyCompositionGpuTests.cpp']
members={}
for p in out.rglob('*'):
 if not p.is_file() or 'tmp' in p.relative_to(out).parts:continue
 if p.suffix not in ['.py','.json','.xml','.log','.glsl','.frag','.vert']:continue
 if not p.stat().st_size or p.stat().st_size>2*2**20:continue
 members['run/'+p.relative_to(out).as_posix()]=p
for name in sources:members['source/'+name]=root/name
name='mesh_object_bindless_clipmap_field_early_radiance.frag.spv'
for variant in ['base','precise']:members[f'program/{variant}/{name}']=out/f'legacy/{variant}/shaders'/name
members['program/beauty_composition_test.comp.spv']=root/'build/ninja-msvc-release/shaders/beauty_composition_test.comp.spv'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/radiance-precision-boundaries';evidence.mkdir(parents=True,exist_ok=True);package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(members.items()):z.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,path in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='shared-precision-ready-legacy-native-pending',sourceBase='b4fff22',sourceHashes={name:digest(root/name) for name in sources},checks=checks,casesPerCheck=63,orderedComponentsPerCheck=567,inputBytes=12096,outputBytes=3024,
 correlation=correlation,programAudit=audit,legacyPreparation={k:v for k,v in legacy.items() if k!='rows'},moduleBoundaries=boundaries,legacyNativeRepairValidated=False,newNativeSceneRuns=0,newPerformanceMeasurements=0,wholeFrameBenefitMeasured=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package))
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'docs/development/artifact-manifest.json';data=json.loads(p.read_text(encoding='utf-8'));data['milestones'].insert(0,dict(path='runs/'+out.name,name='照明组合精度边界',status='SharedPrecisionReadyLegacyNativePending',sourceBase='b4fff22',evidence='docs/acceptance/nr/radiance-precision-boundaries.md',checksPassed=4,existingProgramsUnchangedPerConfiguration=736,legacyNativeRepairValidated=False,newNativeSceneRuns=0,newPerformanceMeasurements=0))
p.write_text(json.dumps(data,ensure_ascii=False,indent=2).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-radiance-precision-boundaries.md','docs/development/beauty-composition.md','docs/development/default-isolation-pipelines.md','docs/acceptance/nr/radiance-precision-boundaries.md']:
 path=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (path.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],checks=len(checks),existingProgramsUnchanged=736,evidenceBytes=package.stat().st_size)))
