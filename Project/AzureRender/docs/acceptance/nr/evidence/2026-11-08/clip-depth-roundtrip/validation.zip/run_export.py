from pathlib import Path
import os,sys,json,subprocess,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
sources=[root/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc',root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-current-gpu_frame2.rdc']
hashes={str(p):digest(p) for p in sources};production=inputs(root);(out/'export-baseline.json').write_text(json.dumps(dict(sourceHashes=hashes,sourceInputs=production),indent=2))
env=os.environ.copy();env.update(TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'),VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'export.py')];start=time.monotonic()
with (out/'export-driver.log').open('wb') as log:r=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=120)
report=dict(command=command,exitCode=r.returncode,seconds=time.monotonic()-start,sourceInputsUnchanged=inputs(root)==production,capturesUnchanged=all(digest(p)==hashes[str(p)] for p in sources));(out/'export-execution.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
data=json.loads((out/'export-result.json').read_text());print(json.dumps(data if data['status']=='failed' else dict(status=data['status'],sources=[dict(label=s['label'],event=s['event'],vertices=s['vertexCount'],indices=s['indexCount'],stride=s['stride'],layout=s['layout']) for s in data['sources']])),flush=True)
assert r.returncode==0 and report['sourceInputsUnchanged'] and report['capturesUnchanged']
