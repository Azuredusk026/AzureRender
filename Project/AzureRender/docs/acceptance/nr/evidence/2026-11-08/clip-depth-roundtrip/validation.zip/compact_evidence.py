from pathlib import Path
import json,numpy as np,hashlib
out=Path(__file__).resolve().parent;meta=json.loads((out/'export-result.json').read_text());arrays={}
nativeIndices=np.fromfile(out/'native-indices.bin',dtype='<u4');currentIndices=np.fromfile(out/'current-base-indices.bin',dtype='<u4')
arrays['nativeIndices']=nativeIndices;arrays['currentIndices']=currentIndices
for row in meta['sources']:
 label=row['label'];raw=(out/(label+'-vertices.bin')).read_bytes();values=np.frombuffer(raw,dtype='<f4').reshape(-1,row['stride']//4)
 arrays[label+'Clip']=values[:,:4].copy()
 expected=nativeIndices if label.startswith('native') else currentIndices
 assert np.array_equal(np.fromfile(out/(label+'-indices.bin'),dtype='<u4'),expected)
 if label=='native':arrays['nativeRelative']=values[:,6:9].copy()
 if label=='current-base':arrays['currentWorld']=values[:,8:11].copy()
arrays['currentDepth']=np.fromfile(out/'current-base-region-depths.bin',dtype='<f4')
assert np.array_equal(arrays['currentDepth'],np.fromfile(out/'current-region-depths.bin',dtype='<f4'))
folder=out/'compact';folder.mkdir(exist_ok=True);np.savez_compressed(folder/'arrays.npz',**arrays)
manifest={name:dict(shape=list(value.shape),dtype=value.dtype.str,sha256=hashlib.sha256(value.tobytes()).hexdigest()) for name,value in arrays.items()}
(folder/'arrays.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(dict(compactBytes=(folder/'arrays.npz').stat().st_size,arrays=len(arrays))),flush=True)
