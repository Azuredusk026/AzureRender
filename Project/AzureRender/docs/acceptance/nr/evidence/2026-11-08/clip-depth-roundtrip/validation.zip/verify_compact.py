from pathlib import Path
import json,numpy as np,hashlib
out=Path(__file__).resolve().parent;data=np.load(out/'compact/arrays.npz');manifest=json.loads((out/'compact/arrays.json').read_text())
for name,entry in manifest.items():assert hashlib.sha256(data[name].tobytes()).hexdigest()==entry['sha256']
nativeIndices=data['nativeIndices'];currentIndices=data['currentIndices'];assert np.array_equal(nativeIndices,currentIndices.reshape(-1,3)[:,[2,1,0]].reshape(-1))
paired=json.loads((out/'paired-clip-analysis.json').read_text())
for a,b in [('native','current-base'),('native-line','current'),('native-color','current-color')]:
 n=data[a+'Clip'][nativeIndices].astype('f8');c=data[b+'Clip'][currentIndices].reshape(-1,3,4)[:,[2,1,0],:].reshape(-1,4).astype('f8');pixels=(c[:,:2]/c[:,3,None]-n[:,:2]/n[:,3,None])*[1280,720]
 assert float(np.linalg.norm(pixels,axis=1).max())==paired[a+'-vs-'+b]['screenMax']
source=out/'borrowed-projection' if (out/'borrowed-projection').is_dir() else out.parent/'20261108-080203-receiver-projection-producer-222952';cb0=np.fromfile(source/'writer-422-cb0.bin',dtype='<f4').reshape(-1,4);cb1=np.fromfile(source/'writer-422-cb1.bin',dtype='<f4').reshape(-1,4)
def fma(a,b,c):return (a.astype('f8')*b.astype('f8')+c.astype('f8')).astype('<f4')
p=data['nativeRelative'];clip=p[:,1,None]*cb0[33];clip=fma(p[:,0,None],cb0[32],clip);clip=fma(p[:,2,None],cb0[34],clip);clip=(clip+cb0[35]).astype('<f4');shift=clip[:,3,None]*cb1[19,2:4];clip[:,:2]=fma(-shift,np.array([2,-2],dtype='<f4'),clip[:,:2]);assert np.array_equal(clip,data['nativeClip'])
print('Compact source reproduces all six clip ranges and all 11564 native projections',flush=True)
