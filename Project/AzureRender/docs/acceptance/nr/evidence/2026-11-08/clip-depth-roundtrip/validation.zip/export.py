import renderdoc as rd
from pathlib import Path
import json,traceback,os,struct,hashlib
root=Path(r'D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261108-082005-clip-depth-roundtrip-9fcd35'
sources=[('native',root/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc',422),('native-line',root/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc',440),('native-color',root/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc',950),('current-base',root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-current-gpu_frame2.rdc',378),('current',root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-current-gpu_frame2.rdc',392),('current-color',root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-current-gpu_frame2.rdc',493)]
report=dict(status='running',sources=[]);code=1
try:
    for label,path,event in sources:
        cap=rd.OpenCaptureFile();controller=None
        try:
            assert cap.OpenFile(str(path),'',None)==rd.ResultCode.Succeeded
            result,controller=cap.OpenCapture(rd.ReplayOptions(),None);assert result==rd.ResultCode.Succeeded
            controller.SetFrameEvent(event,True);pipeline=controller.GetPipelineState();reflection=pipeline.GetShaderReflection(rd.ShaderStage.Vertex)
            mesh=controller.GetPostVSData(0,0,rd.MeshDataStage.VSOut)
            count=mesh.numIndices;stride=mesh.vertexByteStride;assert count==43044 and 16<=stride<=512
            if mesh.indexResourceId:
                size=mesh.indexByteStride;assert size in [1,2,4]
                raw=bytes(controller.GetBufferData(mesh.indexResourceId,mesh.indexByteOffset,count*size));assert len(raw)==count*size
                indices=[index[0]+mesh.baseVertex for index in struct.iter_unpack({1:'<B',2:'<H',4:'<I'}[size],raw)]
            else:indices=list(range(count))
            assert min(indices)>=0 and max(indices)<1000000
            vertexCount=max(indices)+1;assert vertexCount*stride<=64*1024*1024
            raw=bytes(controller.GetBufferData(mesh.vertexResourceId,mesh.vertexByteOffset,vertexCount*stride));assert len(raw)==vertexCount*stride
            signature=[dict(name=s.semanticIdxName,varName=getattr(s,'varName',''),register=getattr(s,'regIndex',None),compCount=s.compCount,varType=int(s.varType),systemValue=str(s.systemValue)) for s in reflection.outputSignature]
            positions=[s for s in signature if s['systemValue']=='ShaderBuiltin.Position'];assert len(positions)==1
            ordered=positions+[s for s in signature if s is not positions[0]];offset=0;layout=[]
            for field in ordered:
                layout.append(dict(**field,offset=offset));offset+=4*field['compCount']
            packedSignature=offset==stride
            if not packedSignature:
                for field in layout:
                    if field['systemValue']!='ShaderBuiltin.Position':field['offset']=None
            (out/(label+'-vertices.bin')).write_bytes(raw)
            (out/(label+'-indices.bin')).write_bytes(b''.join(struct.pack('<I',i) for i in indices))
            packed=b''.join(raw[i*stride:i*stride+16] for i in indices);(out/(label+'-indexed-clips.bin')).write_bytes(packed)
            item=dict(label=label,source=str(path),event=event,indexCount=count,vertexCount=vertexCount,stride=stride,baseVertex=mesh.baseVertex,flipY=mesh.flipY,packedSignature=packedSignature,layout=layout,vertexBytes=len(raw),vertexSha256=hashlib.sha256(raw).hexdigest(),indexedClipSha256=hashlib.sha256(packed).hexdigest())
            if label.startswith('native'):
                state=controller.GetD3D11PipelineState();item['cullMode']=str(state.rasterizer.state.cullMode);item['depthReadOnly']=str(getattr(state.outputMerger,'depthReadOnly',None));item['frontCCW']=str(state.rasterizer.state.frontCCW)
            if label in ['current-base','current']:
                resource=pipeline.GetDepthTarget().resource;texture=next(t for t in controller.GetTextures() if t.resourceId==resource)
                item['depthTarget']=dict(resource=str(resource),width=texture.width,height=texture.height,format=texture.format.Name())
                if texture.width==2560 and texture.height==1440:
                    depthRaw=bytes(controller.GetTextureData(resource,rd.Subresource()));assert len(depthRaw)==2560*1440*4
                    selected=bytearray()
                    for x,y,z,objectId in struct.iter_unpack('<4f',(root/'build/runs/20261108-041637-object-receiver-origin-7a2735/region-queries.bin').read_bytes()):
                        offset=((1439-int(y))*2560+int(x))*4;selected.extend(depthRaw[offset:offset+4])
                    (out/(label+'-region-depths.bin')).write_bytes(selected)
            report['sources'].append(item)
        finally:
            if controller:controller.Shutdown()
            cap.Shutdown()
    report['status']='exported';code=0
except Exception:report.update(status='failed',error=traceback.format_exc())
(out/'export-result.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='sources'}),flush=True);os._exit(code)
