from pathlib import Path
import json,hashlib,sys,subprocess,zipfile,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
baseline=json.loads((out/'export-baseline.json').read_text());execution=json.loads((out/'export-execution.json').read_text());assert execution['exitCode']==0 and execution['sourceInputsUnchanged'] and execution['capturesUnchanged'] and inputs(root)==baseline['sourceInputs']
math=json.loads((out/'projection-math-analysis.json').read_text());assert math['nativeAssemblyExactVertices']==11564 and math['nativeAssemblyExactComponents']==46256
paired=json.loads((out/'paired-clip-analysis.json').read_text());assert paired['depthChanges']['baseToShell']==0
for label in ['native-vs-current-base','native-line-vs-current','native-color-vs-current-color']:assert paired[label]['screenMax']<.001
proof=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,sha256=digest(p)))
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/clip-depth-roundtrip';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.json','.log']}
for p in (out/'compact').iterdir():members['compact/'+p.name]=p
source=out.parent/'20261108-080203-receiver-projection-producer-222952'
for name in ['writer-422-cb0.bin','writer-422-cb1.bin']:members['borrowed-projection/'+name]=source/name
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='vertex-input-precision-attributed',sourceBase='e401f51',sourceHashes=baseline['sourceHashes'],exportExecution=execution,vertexSources=json.loads((out/'export-result.json').read_text()),pairedClipAnalysis=paired,projectionMath=math,productionProvenance=proof,userDiffSha256=protected,candidateAdopted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=n,bytes=p.stat().st_size,sha256=digest(p)) for n,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest=root/'docs/development/artifact-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'));data['milestones']=[m for m in data['milestones'] if m['path']!='runs/'+out.name];data['milestones'].insert(0,dict(path='runs/'+out.name,name='顶点深度精度核验',status='VertexInputPrecisionAttributed',sourceBase='e401f51',evidence='docs/acceptance/nr/clip-depth-roundtrip.md',nativeProjectionExactVertices=11564,candidateAdopted=False,formalPerformancePassed=False));manifest.write_text(json.dumps(data,indent=2,ensure_ascii=False).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md']:
 p=root/name;text=p.read_text(encoding='utf-8');needle='[生产投影核对]';start=text.index(needle);end=text.index('\n',start)
 line='[顶点精度核对]('+('docs/acceptance/nr/' if name=='README.md' else '../acceptance/nr/')+'clip-depth-roundtrip.md)逐位复现原生 11564 个顶点，当前变换输入的精度继续待核定。\n'
 if line not in text:p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-clip-depth-roundtrip.md','docs/acceptance/nr/clip-depth-roundtrip.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],evidenceBytes=package.stat().st_size,sourceUnchanged=True,userDiffPreserved=True)))
