from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent
report=json.loads((out/'export-result.json').read_text());native=np.fromfile(out/'native-indexed-clips.bin',dtype='<f4').reshape(-1,4);current=np.fromfile(out/'current-indexed-clips.bin',dtype='<f4').reshape(-1,4)
ni=np.fromfile(out/'native-indices.bin',dtype='<u4');ci=np.fromfile(out/'current-indices.bin',dtype='<u4')
result=dict(indexCount=len(ni),indexSequenceExact=bool(np.array_equal(ni,ci)),indexValuesEqual=int((ni==ci).sum()),nativeClipRange=[native.min(0).tolist(),native.max(0).tolist()],currentClipRange=[current.min(0).tolist(),current.max(0).tolist()],currentFlipY=report['sources'][1]['flipY'],orders={})
for label,order in [('same',[0,1,2]),('reverse',[0,2,1])]:
 c=current.reshape(-1,3,4)[:,order,:].reshape(-1,4).astype('f8');n=native.astype('f8');a=n[:,:2]/n[:,3,None];b=c[:,:2]/c[:,3,None]
 pixels=(b-a)*np.array([1280,720]);w=c[:,3]-n[:,3]
 result['orders'][label]=dict(screenErrorMedianPixels=float(np.median(np.linalg.norm(pixels,axis=1))),screenErrorP95Pixels=float(np.quantile(np.linalg.norm(pixels,axis=1),.95)),screenErrorMaximumPixels=float(np.linalg.norm(pixels,axis=1).max()),clipWAbsErrorMedian=float(np.median(abs(w))),clipWAbsErrorMaximum=float(abs(w).max()),clipWExact=int((w==0).sum()))
(out/'clip-analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
