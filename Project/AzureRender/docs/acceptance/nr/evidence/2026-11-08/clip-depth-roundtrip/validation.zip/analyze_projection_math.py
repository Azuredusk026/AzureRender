from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent;source=out.parent/'20261108-080203-receiver-projection-producer-222952'
cb0=np.fromfile(source/'writer-422-cb0.bin',dtype='<f4').reshape(-1,4);cb1=np.fromfile(source/'writer-422-cb1.bin',dtype='<f4').reshape(-1,4)
native=np.fromfile(out/'native-vertices.bin',dtype='<f4').reshape(-1,23);current=np.fromfile(out/'current-base-vertices.bin',dtype='<f4').reshape(-1,16)
nativeRelative=native[:,6:9];currentWorld=current[:,8:11]
camera=np.array([0,.8800048828125,3.29998779296875],dtype='<f4');relative=((currentWorld-camera)*np.array([-1,1,1],dtype='<f4')).astype('<f4')
def fma(a,b,c):return (a.astype('f8')*b.astype('f8')+c.astype('f8')).astype('<f4')
def clip(position):
 result=(position[:,1,None]*cb0[33]).astype('<f4');result=fma(position[:,0,None],cb0[32],result);result=fma(position[:,2,None],cb0[34],result);result=(result+cb0[35]).astype('<f4')
 shift=(result[:,3,None]*cb1[19,2:4]).astype('<f4');result[:,:2]=fma(-shift,np.array([2,-2],dtype='<f4'),result[:,:2]);return result
reference=clip(nativeRelative);mapped=clip(relative)
nativeWorld=(nativeRelative.astype('f8')+camera.astype('f8')*[-1,1,1])*[-1,1,1]
worldError=currentWorld.astype('f8')-nativeWorld
fit=np.linalg.lstsq(np.column_stack([nativeWorld,np.ones(len(nativeWorld))]),currentWorld.astype('f8'),rcond=None)[0]
residual=currentWorld.astype('f8')-np.column_stack([nativeWorld,np.ones(len(nativeWorld))])@fit
report=dict(vertices=len(native),nativeAssemblyExactComponents=int((reference==native[:,:4]).sum()),nativeAssemblyTotalComponents=int(reference.size),nativeAssemblyExactVertices=int(np.all(reference==native[:,:4],axis=1).sum()),nativeAssemblyMaximumError=np.abs(reference.astype('f8')-native[:,:4]).max(0).tolist(),relativeWorldAbsErrorMaximum=np.abs(relative.astype('f8')-nativeRelative).max(0).tolist(),worldErrorPercentiles=np.quantile(worldError,[0,.5,1],axis=0).tolist(),mappedClipWExact=int((mapped[:,3]==native[:,3]).sum()),mappedClipWAbsErrorMedian=float(np.median(abs(mapped[:,3].astype('f8')-native[:,3]))),mappedClipWAbsErrorMaximum=float(abs(mapped[:,3].astype('f8')-native[:,3]).max()),affineFit=fit.tolist(),affineResidualMaximum=float(np.linalg.norm(residual,axis=1).max()))
(out/'projection-math-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
