from pathlib import Path
import sys,subprocess,zipfile
out=Path(__file__).resolve().parent;root=Path.cwd().resolve()
p=out/'package.py';s=p.read_text();s=s.replace("data['milestones'].insert(0,dict","data['milestones']=[m for m in data['milestones'] if m['path']!='runs/'+out.name];data['milestones'].insert(0,dict");s=s.replace(" p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')"," if line not in text:p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')");p.write_text(s)
subprocess.run([sys.executable,'-X','utf8',str(p)],cwd=root,check=True)
target=out/'compact-proof';target.mkdir(exist_ok=True)
archive=root/'docs/acceptance/nr/evidence/2026-11-08/clip-depth-roundtrip/validation.zip'
with zipfile.ZipFile(archive) as z:
 for name in ['verify_compact.py','paired-clip-analysis.json','compact/arrays.npz','compact/arrays.json','borrowed-projection/writer-422-cb0.bin','borrowed-projection/writer-422-cb1.bin']:z.extract(name,target)
subprocess.run([sys.executable,'-X','utf8',str(target/'verify_compact.py')],cwd=root,check=True)
