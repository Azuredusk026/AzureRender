from pathlib import Path
import json,hashlib,sys,subprocess,zipfile,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
export=json.loads((out/'export-execution.json').read_text());baseline=json.loads((out/'export-baseline.json').read_text());assert export['exitCode']==0 and export['sourceUnchanged'] and inputs(root)==baseline['sourceInputs']
source=root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-current-gpu_frame2.rdc';assert digest(source)==baseline['sourceSha256']
gpu=json.loads((out/'current-depth-result.json').read_text());assert gpu['pixels']==17017 and gpu['withinOnePixels']==16796 and gpu['maximumVisibilityByteError']==39 and gpu['validationErrors']==0 and gpu['zeroAllocator']
proof=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,status='passed',sha256=digest(p)))
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
model=root/'build/runs/20261108-041637-object-receiver-origin-7a2735';evidence=root/'docs/acceptance/nr/evidence/2026-11-08/receiver-device-depth';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.json','.log','.bin','.spv'] and p.stat().st_size<2*2**20}
for name in ['region-queries.bin','region-expected.bin','receiver.cpp','gpu-preparation.json']:members['borrowed-model/'+name]=model/name
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in sorted(members.items()):archive.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as archive:
 assert archive.testzip() is None
 for name,path in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='source-depth-production-precision-pending',sourceBase='2d69a86',captureDate='2026-10-27',captureSha256=baseline['sourceSha256'],exportExecution=export,resourceBindings=json.loads((out/'export-result.json').read_text()),depthAnalysis=json.loads((out/'depth-analysis.json').read_text()),depthMapping=json.loads((out/'depth-remapping.json').read_text()),mappedGpuVisibility=gpu,borrowedModel=dict(executableSha256=digest(model/'receiver.exe'),shaderSha256=digest(model/'receiver.spv')),rawDepthHashes={name:digest(out/name) for name in ['main-device-depth.bin','snapshot-device-depth.bin']},productionProvenance=proof,userDiffSha256=protected,candidateAdopted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=name,bytes=p.stat().st_size,sha256=digest(p)) for name,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-receiver-device-depth.md','docs/acceptance/nr/receiver-device-depth.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],mappedVisibilityOverOneByte=221,evidenceBytes=report['evidenceBytes'],sourceCaptureUnchanged=True,userDiffPreserved=True)))
