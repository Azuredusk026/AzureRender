from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent;model=out.parent/'20261108-041637-object-receiver-origin-7a2735'
analysis=json.loads((out/'depth-analysis.json').read_text());matrix=np.array(analysis['nativeClipToCurrentClip'])
queries=np.fromfile(model/'region-queries.bin',dtype='<f4').reshape(-1,4);depth=np.fromfile(out/'main-imageRows-depths.bin',dtype='<f4')
x=2*queries[:,0].astype('f8')/2560-1;y=-(2*queries[:,1].astype('f8')/1440-1)
base_z=matrix[2,0]*x+matrix[2,1]*y+matrix[2,3];base_w=matrix[3,0]*x+matrix[3,1]*y+matrix[3,3]
mapped=((base_z-depth.astype('f8')*base_w)/(depth*matrix[3,2]-matrix[2,2])).astype('<f4');error=mapped.astype('f8')-queries[:,2]
ratio=np.spacing(depth)/np.spacing(queries[:,2]);main=np.fromfile(out/'main-device-depth.bin',dtype='<f4');snapshot=np.fromfile(out/'snapshot-device-depth.bin',dtype='<f4')
result=dict(pixels=len(queries),sourceDepthMin=float(queries[:,2].min()),sourceDepthMax=float(queries[:,2].max()),mappedExactDepthPixels=int((mapped==queries[:,2]).sum()),depthAbsErrorMedian=float(np.median(abs(error))),depthAbsErrorMaximum=float(abs(error).max()),currentDepthUlp=float(np.spacing(depth[0])),nativeDepthUlp=float(np.spacing(queries[0,2])),depthUlpRatios={str(int(r)):int((ratio==r).sum()) for r in np.unique(ratio)},fullImageDepthEqualPixels=int((main==snapshot).sum()),fullImagePixels=int(main.size))
queries[:,2]=mapped;queries.tofile(out/'remapped-queries.bin');(out/'depth-remapping.json').write_text(json.dumps(result,indent=2))
