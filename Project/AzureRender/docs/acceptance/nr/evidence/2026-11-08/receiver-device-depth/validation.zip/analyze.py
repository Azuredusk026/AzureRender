from pathlib import Path
import json,sys
import numpy as np
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest
old=root/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f';model=root/'build/runs/20261108-041637-object-receiver-origin-7a2735'
queries=np.fromfile(model/'region-queries.bin',dtype='<f4').reshape(-1,4);reference=np.fromfile(model/'region-output.bin',dtype='<f4').reshape(-1,16)
x=queries[:,0].astype(int);nativeY=queries[:,1].astype(int);imageY=1439-nativeY
camera=np.fromfile(out/'current-camera.bin',dtype='<f4');M=camera[112:128].reshape(4,4).T;inverse=np.linalg.inv(M.astype('f8'));nativeM=np.fromfile(old/'producer-cb0.bin',dtype='<f4').reshape(-1,4)[24:28].T
origin=np.array([-300,300,-300]);basis=np.diag([-1.,1,1,1]);basis[:3,3]=[origin[0],-origin[1],-origin[2]]
projectNativeToCurrent=M.astype('f8')@basis@nativeM.astype('f8')
report=dict(currentCameraSha256=digest(out/'current-camera.bin'),previousCameraSha256=digest(old/'candidate-cb0.bin'),currentWorldToClip=M.tolist(),nativeClipToWorld=nativeM.tolist(),nativeClipToCurrentClip=projectNativeToCurrent.tolist(),regions={},controls=[])
selected={}
for label in ['main','snapshot']:
 full=np.fromfile(out/(label+'-device-depth.bin'),dtype='<f4').reshape(1440,2560)
 for rowMode,rows in [('imageRows',imageY),('nativeRows',nativeY)]:
  depth=full[rows,x];selected[label+'-'+rowMode]=depth
  for offset in [(0.5,0.5),(0.,1.)]:
   ndc=np.column_stack([2*(x+offset[0])/2560-1,2*(imageY+offset[1])/1440-1,depth,np.ones(len(x))]);h=ndc@inverse.T;world=h[:,:3]/h[:,3,None];world=world*np.array([-1,1,1])+origin
   error=np.linalg.norm(world-reference[:,:3],axis=1);key=label+'-'+rowMode+'-'+str(offset)
   report['regions'][key]=dict(backgroundPixels=int((depth==1).sum()),depthRange=[float(depth.min()),float(depth.max())],worldErrorMedianMeters=float(np.median(error)),worldErrorP95Meters=float(np.quantile(error,.95)),worldErrorMaximumMeters=float(error.max()))
  depth.astype('<f4').tofile(out/(label+'-'+rowMode+'-depths.bin'))
for cx,cy in [(1322,263),(1324,289),(1322,320),(1258,215)]:
 i=np.flatnonzero((x==cx)&(imageY==cy))[0];report['controls'].append(dict(pixel=[cx,cy],nativeDepth=float(queries[i,2]),referenceWorld=reference[i,:3].tolist(),currentDepths={k:float(v[i]) for k,v in selected.items()}))
report['mainSnapshotRegionEqualPixels']=int((selected['main-imageRows']==selected['snapshot-imageRows']).sum())
(out/'depth-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
