from pathlib import Path
import hashlib,json,os,subprocess,sys,zipfile,zlib
import numpy as np
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
assert check(root/'build',run=out,planned=48*2**20)['allowed'];before=inputs(root)
archive=root/'docs/acceptance/nr/evidence/2026-11-07/shadow-disk-work/validation.zip'
assert digest(archive)=='d8775bdd43f40e269660ea7415ed9e22554dfc90218905bf1a1ee47e30621b63'
with zipfile.ZipFile(archive) as package:raw=zlib.decompress(package.read('counts/counts.bin.zlib'))
captured=np.frombuffer(raw,dtype='<f2').astype(np.float32).reshape(-1,4)
assert captured.shape==(921600,4) and captured[:,0].sum(dtype=np.float64)==11917189 and captured[:,1].sum(dtype=np.float64)==4232176
shapes,ids=np.unique(captured[:,:2],axis=0,return_inverse=True);assert len(shapes)<256
table=[None]*len(shapes);table[0]=dict(calls=0,skips=0,parameters=[-1,0,0,0])
fractions=np.array([(x/32,y/32) for y in range(32) for x in range(32)],dtype=np.float32)
for calls,low,high in [(64,6,6.5),(81,6.501,7.5),(100,7.501,8)]:
 bound=int(np.sqrt(calls))-1;offsets=np.array([(x,y) for y in range(-bound,bound+1,2) for x in range(-bound,bound+1,2)],dtype=np.float32)
 xy=offsets[None,:,None,:]+np.array([[0,0],[1,0],[0,1],[1,1]],dtype=np.float32)[None,None,:,:]-fractions[:,None,None,:]
 minimum=(xy*xy).sum(axis=-1,dtype=np.float32).min(axis=-1)
 radii=np.linspace(low,high,513,dtype=np.float32);edge=radii+np.float32(.5);outer=(edge*edge)*np.float32(1.000003814697265625)
 skips=(minimum[None,:,:]>outer[:,None,None]).sum(axis=-1)
 for index,(total,skipped) in enumerate(shapes):
  if total!=calls:continue
  found=np.argwhere(skips==skipped);assert len(found),(calls,int(skipped))
  r,f=found[len(found)//2];radius=radii[r];fraction=fractions[f]
  assert int(np.ceil(radius+.5))+1==int(np.sqrt(calls))
  table[index]=dict(calls=int(total),skips=int(skipped),parameters=[float(radius),float(fraction[0]),float(fraction[1]),0])
assert all(row is not None for row in table)
(out/'shape-ids.bin').write_bytes(ids.astype('u1').tobytes());(out/'parameters.json').write_text(json.dumps(table,indent=2))
builds=[];compiler='D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe';validator='D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe'
for mode,defines in [('baseline',[]),('candidate',['-DCANDIDATE=1']),('counts',['-DCOUNTS=1'])]:
 command=[compiler,*defines,str(out/'kernel.comp'),'-o',str(out/(mode+'.spv'))];subprocess.run(command,check=True,capture_output=True,timeout=30)
 validation=[validator,'--target-env','vulkan1.0',str(out/(mode+'.spv'))];subprocess.run(validation,check=True,capture_output=True,timeout=10)
 builds.append(dict(mode=mode,command=command,validation=validation,sha256=digest(out/(mode+'.spv'))))
env=os.environ.copy();env.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg',DOTNET_ROOT='D:/Tools/dotnet9')
bat=[str(root/'tools/msvc_env.bat')]
command=bat+['cl.exe','/nologo','/O2','/MD','/EHsc','/std:c++17','/utf-8','/DNOMINMAX','/DNDEBUG',f'/I{root/"src"}',f'/I{root/"tests"}',f'/I{root/"build/ninja-msvc-debug/vcpkg_installed/x64-windows/include"}','/ID:/Tools/VulkanSDK/1.4.350.0/Include','/c',str(out/'kernel.cpp'),f'/Fo{out/"kernel.obj"}']
with (out/'compile.log').open('wb') as log:result=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert result.returncode==0,(out/'compile.log').read_text(errors='replace')[-2500:]
command=bat+['link.exe',str(out/'kernel.obj'),f'/OUT:{out/"kernel.exe"}','/INCREMENTAL:NO',str(root/'build/ninja-msvc-release/AzureRenderCore.lib'),str(root/'build/ninja-msvc-release/AzureFoundation.lib'),'D:/Tools/VulkanSDK/1.4.350.0/Lib/vulkan-1.lib','kernel32.lib','user32.lib','advapi32.lib']
with (out/'link.log').open('wb') as log:result=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert result.returncode==0,(out/'link.log').read_text(errors='replace')[-2500:]
assert inputs(root)==before
report=dict(status='prepared',sourceInputs=before,capturedPixels=len(ids),capturedCalls=11917189,capturedSkips=4232176,representativeShapes=len(table),shapeIdsSha256=digest(out/'shape-ids.bin'),builds=builds,scope='Captured per-pixel loop counts and empty-quad counts, with representative radius/fraction inputs. Not captured sample coordinates, full shadow shading, or native frame performance.')
(out/'preparation.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['sourceInputs','builds']}),flush=True)
