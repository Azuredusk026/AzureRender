#include "support/VulkanComputeFixture.hpp"
#include "resources/BinaryFile.hpp"
#include <nlohmann/json.hpp>
#include <array>
#include <cstring>
#include <fstream>
#include <algorithm>
#include <cmath>
using namespace azurerender;
using Value=std::array<float,4>;
int main(int argc,char** argv)try{
 if(argc!=2)throw std::runtime_error("Expected fixture directory");const std::filesystem::path root=argv[1];
 auto ids=readBinaryFile((root/"shape-ids.bin").u8string());nlohmann::json table;std::ifstream(root/"parameters.json")>>table;
 std::vector<Value> source;source.reserve(ids.size());for(unsigned char id:ids)source.push_back(table.at(id).at("parameters").get<Value>());
 const auto bytes=source.size()*sizeof(Value);test::VulkanComputeFixture host(true);auto& backend=*host.backend;
 auto staging=host.allocator.createBuffer(bytes,VK_BUFFER_USAGE_TRANSFER_SRC_BIT,true);
 auto input=host.allocator.createBuffer(bytes,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT|VK_BUFFER_USAGE_TRANSFER_DST_BIT,false);
 auto output=host.allocator.createBuffer(bytes,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT|VK_BUFFER_USAGE_TRANSFER_SRC_BIT,false);
 auto readback=host.allocator.createBuffer(bytes,VK_BUFFER_USAGE_TRANSFER_DST_BIT,true);
 std::memcpy(staging.mapped,source.data(),bytes);host.allocator.flush(staging,0,bytes);
 VkDescriptorSetLayout setLayout{};VkDescriptorPool pool{};VkPipelineLayout layout{};VkQueryPool timer{};VkPipeline pipelines[3]{};
 auto cleanup=std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*){if(timer)vkDestroyQueryPool(host.device,timer,nullptr);for(auto pipeline:pipelines)if(pipeline)backend.destroyPipeline(pipeline);if(layout)backend.destroyPipelineLayout(layout);if(pool)backend.destroyDescriptorPool(pool);if(setLayout)backend.destroyDescriptorSetLayout(setLayout);host.allocator.destroyBuffer(readback);host.allocator.destroyBuffer(output);host.allocator.destroyBuffer(input);host.allocator.destroyBuffer(staging);});
 setLayout=backend.createDescriptorSetLayout({{0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},{1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT}});
 rhi::DescriptorPoolDesc descriptorPool;descriptorPool.maxSets=1;descriptorPool.sizes={{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,2}};pool=backend.createDescriptorPool(descriptorPool);
 auto set=backend.allocateDescriptorSets(pool,setLayout,1).front();backend.writeDescriptorBuffer({set,0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,input.buffer,input.size});backend.writeDescriptorBuffer({set,1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,output.buffer,output.size});
 rhi::PushConstantRangeDesc push{VK_SHADER_STAGE_COMPUTE_BIT,4};layout=backend.createPipelineLayout(setLayout,&push);
 const char* names[]={"baseline.spv","candidate.spv","counts.spv"};for(unsigned i=0;i<3;++i){auto shader=backend.createShaderModule(readBinaryFile((root/names[i]).u8string()));pipelines[i]=backend.createComputePipeline({shader,layout});backend.destroyShaderModule(shader);}
 VkQueryPoolCreateInfo query{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};query.queryType=VK_QUERY_TYPE_TIMESTAMP;query.queryCount=16;test::vkRequire(vkCreateQueryPool(host.device,&query,nullptr,&timer),"vkCreateQueryPool");
 host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer native){commands.bufferBarrier({staging.buffer,0,bytes,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT});VkBufferCopy copy{0,0,bytes};vkCmdCopyBuffer(native,staging.buffer,input.buffer,1,&copy);commands.bufferBarrier({input.buffer,0,bytes,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT});});
 std::vector<Value> reference;std::uint64_t observedCalls=0,observedSkips=0;nlohmann::json phases=nlohmann::json::array();
 for(int phase=-1;phase<4;++phase){const unsigned mode=phase<0?2:(phase==1||phase==2?1:0);
  host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer native){
   commands.bufferBarrier({output.buffer,0,bytes,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT|VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT|VK_ACCESS_TRANSFER_READ_BIT,VK_ACCESS_SHADER_WRITE_BIT});
   commands.bindComputeDescriptorSet(layout,set);const auto count=static_cast<std::uint32_t>(ids.size());commands.pushConstants(layout,VK_SHADER_STAGE_COMPUTE_BIT,0,&count,4);
   auto dispatch=[&]{commands.dispatch((count+63)/64,1,1);commands.bufferBarrier({output.buffer,0,bytes,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});};
   if(phase>=0){commands.bindComputePipeline(pipelines[0]);for(unsigned i=0;i<256;++i)dispatch();}
   commands.bindComputePipeline(pipelines[mode]);vkCmdResetQueryPool(native,timer,0,16);
   for(unsigned sample=0;sample<8;++sample){vkCmdWriteTimestamp(native,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,timer,sample*2);for(unsigned repeat=0;repeat<8;++repeat)dispatch();vkCmdWriteTimestamp(native,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,timer,sample*2+1);}
   commands.bufferBarrier({output.buffer,0,bytes,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT});commands.bufferBarrier({readback.buffer,0,bytes,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_HOST_READ_BIT,VK_ACCESS_TRANSFER_WRITE_BIT});
   VkBufferCopy copy{0,0,bytes};vkCmdCopyBuffer(native,output.buffer,readback.buffer,1,&copy);commands.bufferBarrier({readback.buffer,0,bytes,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
  });
  host.allocator.invalidate(readback,0,bytes);const auto* actual=static_cast<const Value*>(readback.mapped);
  if(phase<0){for(std::size_t i=0;i<ids.size();++i){const auto& expected=table.at(static_cast<unsigned char>(ids[i]));if(actual[i][0]!=expected.at("calls").get<float>()||actual[i][1]!=expected.at("skips").get<float>())throw std::runtime_error("Representative input changed the captured per-pixel branch counts");observedCalls+=static_cast<unsigned>(actual[i][0]);observedSkips+=static_cast<unsigned>(actual[i][1]);}continue;}
  if(phase==0)reference.assign(actual,actual+ids.size());else if(std::memcmp(reference.data(),actual,bytes)!=0)throw std::runtime_error("Candidate output differs from the independent baseline GPU output");
  std::uint64_t times[16]{};test::vkRequire(vkGetQueryPoolResults(host.device,timer,0,16,sizeof(times),times,8,VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT),"vkGetQueryPoolResults");
  const auto mask=host.timestampBits==64?~std::uint64_t(0):(std::uint64_t(1)<<host.timestampBits)-1;std::vector<double> samples;
  for(unsigned i=0;i<8;++i)samples.push_back(double((times[2*i+1]-times[2*i])&mask)*host.properties.limits.timestampPeriod/1e6/8);
  phases.push_back({{"phase",phase},{"candidate",mode==1},{"samplesMilliseconds",samples}});
 }
 if(host.errors.load())throw std::runtime_error("Vulkan validation failed");
 nlohmann::json result={{"status","passed"},{"device",host.properties.deviceName},{"pixels",ids.size()},{"observedCalls",observedCalls},{"observedSkips",observedSkips},{"allOutputsBitExact",true},{"validationErrors",host.errors.load()},{"samples",phases},{"warmupDispatchesPerPhase",256},{"dispatchesPerTimestampSample",8},{"scope","Standalone disk-weight computation with captured per-pixel call/skip counts and representative geometry. Device-local input/output, readback after timestamps. Excludes shadow texture reads, rasterization, native frame budgets and formal power qualification."}};
 cleanup.reset();if(host.allocator.statistics().liveBuffers||host.allocator.statistics().liveImages)throw std::runtime_error("Kernel fixture leaked allocations");result["zeroAllocator"]=true;std::ofstream(root/"kernel-result.json")<<result.dump(2);std::cout<<result.dump(2)<<std::endl;return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<std::endl;return 1;}
