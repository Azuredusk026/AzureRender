from pathlib import Path
import json,os,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import guarded_run
from build_provenance import inputs,digest
before=inputs(root);prepared=json.loads((out/'preparation.json').read_text());assert before==prepared['sourceInputs']
products={str(p):digest(p) for p in [root/'build/ninja-msvc-release/AzurePlayer.exe',*sorted((root/'build/ninja-msvc-release/shaders').glob('*.spv'))]}
os.environ['PATH']=str(root/'build/ninja-msvc-release')+';'+os.environ['PATH'];os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
command=[str(out/'kernel.exe'),str(out)];result=guarded_run(root/'build',out.name,command,120)
(out/'execution.json').write_text(json.dumps(result,indent=2));assert result['exitCode']==0,(out/'process.log').read_text(errors='replace')[-3000:]
assert inputs(root)==before and all(digest(Path(path))==sha for path,sha in products.items())
report=json.loads((out/'kernel-result.json').read_text());assert report['observedCalls']==11917189 and report['observedSkips']==4232176 and report['allOutputsBitExact'] and report['validationErrors']==0 and report['zeroAllocator']
means=[sum(r['samplesMilliseconds'])/len(r['samplesMilliseconds']) for r in report['samples']]
base=(means[0]+means[3])/2;candidate=(means[1]+means[2])/2
summary=dict(status='measured',device=report['device'],phaseMeansMilliseconds=means,baselineMilliseconds=base,candidateMilliseconds=candidate,reductionPercent=100*(1-candidate/base),savedMilliseconds=base-candidate,baselineEndpointDriftPercent=100*abs(means[3]-means[0])/min(means[0],means[3]),branchCountsExact=True,outputsBitExact=True,productionUnchanged=True,formalPerformancePassed=False,scope=prepared['scope'])
(out/'kernel-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
