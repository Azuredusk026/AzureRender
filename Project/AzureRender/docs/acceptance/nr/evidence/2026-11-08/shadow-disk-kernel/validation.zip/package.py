from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,digest
summary=json.loads((out/'kernel-summary.json').read_text());assert summary['productionUnchanged'] and summary['outputsBitExact'] and summary['branchCountsExact'] and summary['reductionPercent']<0
proof=[]
for config in ['release','debug']:
 path=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(path.read_text()));proof.append(dict(configuration=config,status='passed',sha256=digest(path)))
protectedPaths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protectedPaths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/shadow-disk-kernel';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.cpp','.comp','.spv','.bin','.json','.log'] and p.stat().st_size<2*2**20}
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in sorted(members.items()):archive.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as archive:
 assert archive.testzip() is None
 for name,path in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='isolated-kernel-slower-no-native-batch',sourceBase='b1451cf',summary=summary,kernel=json.loads((out/'kernel-result.json').read_text()),execution=json.loads((out/'execution.json').read_text()),productionProvenance=proof,userDiffSha256=protected,nativeBatchExecuted=False,productionIntegrated=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=name,bytes=p.stat().st_size,sha256=digest(p)) for name,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=report['status'],evidenceBytes=report['evidenceBytes'],sourceAndProductsUnchanged=True,userDiffPreserved=True)))
