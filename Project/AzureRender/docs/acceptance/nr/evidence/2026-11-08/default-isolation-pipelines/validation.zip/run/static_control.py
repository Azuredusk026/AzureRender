from pathlib import Path
import subprocess,json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;commands=json.loads((out/'compile-commands.json').read_text());rows=[]
folder=out/'production-control';folder.mkdir(exist_ok=True)
for name,command in commands.items():
 target=folder/name;args=list(command);args[args.index('-o')+1]=str(target)
 subprocess.run(args,check=True,capture_output=True,timeout=60)
 assert target.read_bytes()==(out/'program/base'/name).read_bytes(),name
 rows.append(dict(program=name,originalBytesUnchanged=True))
name='mesh_object_bindless_clipmap_field_early.frag.spv';args=list(commands[name]);target=folder/'mesh_object_bindless_clipmap_field_early_isolation0.frag.spv';args.insert(1,'-DAZURE_STATIC_ISOLATION=1');args[args.index('-o')+1]=str(target)
subprocess.run(args,check=True,capture_output=True,timeout=60)
subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(target)],check=True,capture_output=True,timeout=30)
report=folder/'pipeline.json';r=subprocess.run([str(out/'probe.exe'),str(root/'build/ninja-msvc-release/shaders/mesh_object_compute.vert.spv'),str(target),str(report),'ordinary','main'],capture_output=True,timeout=60)
(folder/'pipeline.stdout').write_bytes(r.stdout);(folder/'pipeline.stderr').write_bytes(r.stderr);assert r.returncode==0 and not r.stderr,r.stderr.decode(errors='replace')[-2000:]
data=json.loads(report.read_text());fragment=next(e for e in data['executables'] if e['stage']==16);metrics={s['name']:s['value'] for s in fragment['statistics']};assert metrics['Register Count']==96,metrics
result=dict(rows=rows,registers=metrics['Register Count'],binaryBytes=metrics['Binary Size'],defaultSpecialization=0,queueSubmissions=data['queueSubmissions'],validationErrors=data['validationErrors']);(out/'production-control.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
