from pathlib import Path
import json,difflib,os,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
report=json.loads((out/'image-precision/results.json').read_text())
assert report['metadata']['defaultIsolationSelected'] and not report['metadata']['defaultIsolationFallback']
assert len(report['frames'])==4 and all(row['changedPixels']==0 for row in report['frames'])
path=root/'shaders/mesh.frag';old=path.read_text();candidate=(out/'precision/source/mesh.frag').read_text();a=old.splitlines(keepends=True);b=candidate.splitlines(keepends=True)
result=[];changes=[]
for tag,a0,a1,b0,b1 in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
 if tag=='equal':result.extend(a[a0:a1]);continue
 changes.append(dict(kind=tag,originalLines=[a0+1,a1],candidateLines=[b0+1,b1]))
 result.append('#if defined(AZURE_STATIC_ISOLATION)\n');result.extend(b[b0:b1]);result.append('#else\n');result.extend(a[a0:a1]);result.append('#endif\n')
value=''.join(result);temporary=path.with_name(path.name+'.codex-tmp');assert not temporary.exists();temporary.write_text(value);os.replace(temporary,path)
(out/'precision-integration.json').write_text(json.dumps(dict(changes=changes,beforeSha256=hashlib.sha256(old.encode()).hexdigest(),afterSha256=hashlib.sha256(value.encode()).hexdigest(),fourFramesExact=True),indent=2));print(json.dumps(dict(conditionalRanges=len(changes))))
