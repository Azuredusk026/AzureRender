from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;config=sys.argv[1];assert config in ['Release','Debug']
env=os.environ.copy();temporary=out/'tmp';temporary.mkdir(exist_ok=True);env.update(TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary))
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
rows=[];ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
for label,driver,expression in [('nvidia', '*nv-vk64*', '^AzureRender\\.(DepthPrefillRecording|MaterialClassEarlyDepth|ShaderSpecializationGpu|MaterialPipelinePolicy|RenderView|RenderViewSubmission|ViewFogShaderContract)$'), ('intel', '*igvk64*', '^AzureRender\\.ShaderSpecializationGpu$')]:
 if config=="Release" and label=="nvidia":expression=r"^AzureRender\.DepthPrefillRecording$"
 env['VK_LOADER_DRIVERS_SELECT']=driver
 command=[ctest,'--test-dir',f'build/ninja-msvc-{config.lower()}','-R',expression,'--output-on-failure','--no-tests=error','--output-junit',str(out/(config.lower()+'-'+label+'.xml'))]
 started=time.monotonic()
 with (out/(config.lower()+'-'+label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 rows.append(dict(label=label,command=command,exitCode=r.returncode,seconds=time.monotonic()-started));print(json.dumps(rows[-1]),flush=True)
 (out/(config.lower()+'-checks.json')).write_text(json.dumps(rows,indent=2));assert r.returncode==0,(out/(config.lower()+'-'+label+'.log')).read_text(errors='replace')
