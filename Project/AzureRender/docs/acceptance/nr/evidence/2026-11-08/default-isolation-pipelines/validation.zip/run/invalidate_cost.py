from pathlib import Path
import json,hashlib,csv
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;before=out/'cost-v1-baseline-before';candidate=out/'cost-v1-candidate'
environment=json.loads((before/'environment.json').read_text());execution=json.loads((candidate/'execution.json').read_text());assert execution['exitCode']!=0
samples=list(csv.DictReader((candidate/'timing.csv').open()))
report=dict(schemaVersion=1,status='invalid-external-gpu-contention',wholeFrameBenefitMeasured=False,formalPerformancePassed=False,
 reason='An external graphics process was active during the reference and candidate. The owned candidate was stopped; the after-reference did not run.',
 externalEngineObservation=dict(source='Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine',graphicsUtilizationPercent=20,copyUtilizationPercent=12),
 referenceDeviceMemoryMiB=dict(total=8188,used=7424,free=533),hostPowerStates=sorted(set(r['hostPower']['acLineStatus'] for r in environment['runObservations'])),
 powerLimitsWatts=sorted(set(r['powerLimitWatts'] for r in environment['runObservations'] if r['powerLimitWatts'] is not None)),candidateExecution=execution,
 candidatePartialFrameRows=len(samples),afterReferenceExecuted=False,referenceEnvironmentSha256=hashlib.sha256((before/'environment.json').read_bytes()).hexdigest(),
 unrelatedApplicationsModified=False,productionSourceChangedForMeasurement=False)
(out/'cost-invalid.json').write_text(json.dumps(report,indent=2))
for label in ['baseline-before','candidate']:
 folder=out/('cost-v1-'+label);data=json.loads((folder/'environment.json').read_text())
 for row in data.get('runObservations',[]):row.pop('rawXml',None)
 if data.get('final'):data['final'].pop('rawXml',None)
 (folder/'environment-summary.json').write_text(json.dumps(data,indent=2))
print(json.dumps({k:report[k] for k in ['status','candidatePartialFrameRows','afterReferenceExecuted','hostPowerStates']}))
