from pathlib import Path
import json,subprocess
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;folder=out/'precision';shaders=folder/'shaders';source=folder/'source/mesh.frag'
command=json.loads((out/'compile-commands.json').read_text())['mesh_object_bindless_clipmap_field_early.frag.spv'];rows=[]
for policy in range(4):
 name='mesh_object_bindless_clipmap_field_early'+('_lighting' if policy&1 else '')+('_coverage' if policy&2 else '')+'_isolation0.frag.spv';target=shaders/name
 if not target.exists():
  args=list(command);args[args.index(str(root/'shaders/mesh.frag').replace('\\','/'))]=str(source);args.insert(1,'-DAZURE_STATIC_ISOLATION=1')
  if policy&1:args.insert(1,'-DAZURE_EXTENDED_MATERIAL_LIGHTING=1')
  if policy&2:args.insert(1,'-DAZURE_INDEPENDENT_COVERAGE=1')
  args[args.index('-o')+1]=str(target);subprocess.run(args,check=True,capture_output=True,timeout=60)
 subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(target)],check=True,capture_output=True,timeout=30)
 rows.append(dict(policy=policy,path=str(target),bytes=target.stat().st_size))
(folder/'family.json').write_text(json.dumps(rows,indent=2))
assert len(rows)==4 and all(Path(row['path']).is_file() for row in rows)
image=out/'image-precision';assert (image/'results.json').exists()
fallback=image.with_name('image-precision-fallback-control');assert not fallback.exists();image.rename(fallback)
print(json.dumps(dict(programs=len(rows),fallbackControlPreserved=str(fallback))))
