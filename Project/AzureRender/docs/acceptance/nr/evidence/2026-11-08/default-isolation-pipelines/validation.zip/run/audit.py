from pathlib import Path
import json,hashlib,subprocess,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify
old=json.loads((out.parent/'20261108-124916-main-depth-reuse-2703c1/measured-build-provenance.json').read_text());rows=[]
for configuration in ['release','debug']:
 build=root/f'build/ninja-msvc-{configuration}';manifest=json.loads((build/'build-provenance.json').read_text());verify(root,manifest)
 programs={name:sha for name,sha in old['products'].items() if '/shaders/' in name.replace('\\','/') and name.endswith('.spv')}
 checked=[]
 for name,sha in programs.items():
  path=build/'shaders'/Path(name).name
  assert digest(path)==sha,name
  checked.append(path.name)
 added=sorted(p.name for p in (build/'shaders').glob('*_isolation0.frag.spv'))
 assert len(checked)>=672 and len(added)==64,(len(checked),len(added))
 rows.append(dict(configuration=configuration,existingProgramsUnchanged=len(checked),newPrograms=len(added),programs=added,manifestSha256=digest(build/'build-provenance.json')))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
user=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest();assert user=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
(out/'audit.json').write_text(json.dumps(dict(products=rows,userDiffSha256=user),indent=2));print(json.dumps(dict(products=rows,userDiffSha256=user)))
