from pathlib import Path
import json,subprocess,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;folder=out/'precision';source=folder/'source';shaders=folder/'shaders';source.mkdir(parents=True,exist_ok=True);shaders.mkdir(exist_ok=True)
for p in (out/'source/base').iterdir():(source/p.name).write_bytes((root/'shaders'/p.name).read_bytes())
path=source/'mesh.frag';text=path.read_text()
helper='''vec3 azureBeautySum(vec3 a,vec3 b,vec3 c,vec3 d,vec3 e,vec3 f,vec3 g,vec3 h){
    precise vec3 result=a+b+c+d+e+f+g+h;return result;
}
vec3 azureBeautyReplace(vec3 total,vec3 added,vec3 removed){
    precise vec3 result=total+(added-removed);return result;
}
'''
anchor='void main()';assert text.count(anchor)==1;text=text.replace(anchor,helper+anchor)
old='''    vec3 beautyColor =
        tintedDiffuse
        + ambientSpecular
        + directSpecular
        + rimLighting
        + kkSpecular
        + secondaryKkSpecular
        + matcapAccent
        + emissive;''';assert text.count(old)==1
text=text.replace(old,'    vec3 beautyColor=azureBeautySum(tintedDiffuse,ambientSpecular,directSpecular,rimLighting,kkSpecular,secondaryKkSpecular,matcapAccent,emissive);')
old='''        beautyColor = directDiffuse + directSpecular + ambientDiffuse + ambientSpecular
            + emissive + kkSpecular + secondaryKkSpecular + rimLighting;''';assert text.count(old)==1
text=text.replace(old,'        beautyColor=azureBeautySum(directDiffuse,directSpecular,ambientDiffuse,ambientSpecular,emissive,kkSpecular,secondaryKkSpecular,rimLighting);')
assert text.count('beautyColor+=blended-ambientDiffuse;')==1 and text.count('beautyColor+=blended-ambientSpecular;')==3
text=text.replace('beautyColor+=blended-ambientDiffuse;','beautyColor=azureBeautyReplace(beautyColor,blended,ambientDiffuse);').replace('beautyColor+=blended-ambientSpecular;','beautyColor=azureBeautyReplace(beautyColor,blended,ambientSpecular);')
path.write_text(text)
command=json.loads((out/'compile-commands.json').read_text())['mesh_object_bindless_clipmap_field_early.frag.spv'];rows=[]
for lighting in [False,True]:
 args=list(command);args[args.index(str(root/'shaders/mesh.frag').replace('\\','/'))]=str(path);args.insert(1,'-DAZURE_STATIC_ISOLATION=1')
 if lighting:args.insert(1,'-DAZURE_EXTENDED_MATERIAL_LIGHTING=1')
 name='mesh_object_bindless_clipmap_field_early'+('_lighting' if lighting else '')+'_isolation0.frag.spv';target=shaders/name;args[args.index('-o')+1]=str(target)
 subprocess.run(args,check=True,capture_output=True,timeout=60)
 subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(target)],check=True,capture_output=True,timeout=30)
 report=folder/(name+'.json');result=subprocess.run([str(out/'probe.exe'),str(root/'build/ninja-msvc-release/shaders/mesh_object_compute.vert.spv'),str(target),str(report),'ordinary','main'],capture_output=True,timeout=60)
 (folder/(name+'.stderr')).write_bytes(result.stderr);assert result.returncode==0 and not result.stderr,result.stderr.decode(errors='replace')[-2000:]
 data=json.loads(report.read_text());fragment=next(e for e in data['executables'] if e['stage']==16);metrics={s['name']:s['value'] for s in fragment['statistics']};rows.append(dict(lighting=lighting,registers=metrics['Register Count'],binaryBytes=metrics['Binary Size'],validationErrors=data['validationErrors']))
 assert metrics['Register Count']<=96,rows
(folder/'static.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
source=(out/'build_cost_baseline.py').read_text();start=source.index("sampling=(root/");end=source.index("cache=(build/",start)
replacement='''sampling=(root/'src/scenes/CharacterMaterialSampling.inc').read_text();needle='                file.insert(file.size()-9,"_isolation0");';assert sampling.count(needle)==1
sampling=sampling.replace(needle,needle+'\\n                file="'+(out/'precision/shaders').as_posix()+'/"+file.substr(file.find_last_of(char(47))+1);')
(folder/'CharacterMaterialSampling.inc').write_text(sampling)
(folder/'CharacterSceneRenderer.cpp').write_text(source.replace(include,'#include "'+(folder/'CharacterMaterialSampling.inc').as_posix()+'"'))
'''
source=source[:start]+replacement+source[end:];source=source.replace("folder=out/'cost-baseline'","folder=out/'precision/runtime'").replace("'cost-build.json'","'precision-build.json'").replace('Current-runtime baseline with default isolation preparation disabled was built','Private precision-boundary candidate was built')
(out/'build_precision.py').write_text(source)
