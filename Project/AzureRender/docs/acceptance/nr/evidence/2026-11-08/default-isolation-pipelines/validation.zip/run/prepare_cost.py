from pathlib import Path
out=Path(__file__).resolve().parent;path=out/'cost.py';source=path.read_text().replace("out/'image/results.json'","out/'image-precision/results.json'")
source=source.replace('from artifact_maintenance import guarded_run','from artifact_maintenance import guarded_run\nfrom gpu_environment import RunEnvironmentMonitor\nfor key in [\'TEMP\',\'TMP\',\'TMPDIR\']:os.environ[key]=str(out/\'tmp\')')
old="(folder/'command.json').write_text(json.dumps(dict(command=command,exeSha256=digest(exe)),indent=2));execution=guarded_run(root/'build',out.name,command,300)"
new="""(folder/'command.json').write_text(json.dumps(dict(command=command,exeSha256=digest(exe)),indent=2))
 environment={}
 with RunEnvironmentMonitor(environment,path=folder/'environment.json',interval=2):
  execution=guarded_run(root/'build',out.name,command,300)"""
assert old in source;source=source.replace(old,new)
old="row=dict(label=label,selectedFrames=60,summary=summary,metadata="
new="""observations=environment['runObservations'];assert not environment['monitorErrors']
 environmentSummary=dict(powerLimits=sorted(set(row['powerLimitWatts'] for row in observations if row['powerLimitWatts'] is not None)),acLineStates=sorted(set(row['hostPower']['acLineStatus'] for row in observations)),temperatures=[min(row['temperature'] for row in observations),max(row['temperature'] for row in observations)],graphicsClocks=[min(row['graphicsClockMHz'] for row in observations if row['graphicsClockMHz'] is not None),max(row['graphicsClockMHz'] for row in observations if row['graphicsClockMHz'] is not None)],thermalSlowdownObserved=any(any(value is True for value in row['thermalSlowdown'].values()) for row in observations),samples=len(observations))
 row=dict(label=label,selectedFrames=60,summary=summary,environment=environmentSummary,metadata="""
assert old in source;source=source.replace(old,new);path.write_text(source)
