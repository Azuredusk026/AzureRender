from pathlib import Path
import re,json,subprocess,sys,os,ctypes
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
def replace(s,a,b):
 assert s.count(a)==1,(a[:70],s.count(a));return s.replace(a,b)
p=out/'probe.cpp';s=p.read_text()
s=replace(s,'if(argc!=3&&argc!=4&&argc!=5)throw std::runtime_error("Expected compute input/report or vertex/fragment/report"); const bool graphics=argc>=4;const bool uniformProfiles=argc==5;', 'if(argc<4||argc>6)throw std::runtime_error("Expected vertex/fragment/report/role/target"); const bool graphics=true;const bool uniformProfiles=false;const bool ordinaryMode=argc<5||std::string(argv[4])!="generic";const bool snapshot=argc>=6&&std::string(argv[5])=="snapshot";')
s=replace(s,'const VkFormat formats[4]={VK_FORMAT_R8G8B8A8_SRGB,VK_FORMAT_R32G32B32A32_SFLOAT,VK_FORMAT_R8_UNORM,VK_FORMAT_D32_SFLOAT};','const VkFormat formats[4]={VK_FORMAT_R16G16B16A16_SFLOAT,snapshot?VK_FORMAT_R32G32B32A32_SFLOAT:VK_FORMAT_R8G8B8A8_UNORM,snapshot?VK_FORMAT_D32_SFLOAT:VK_FORMAT_R8_UNORM,VK_FORMAT_D32_SFLOAT};const unsigned colorCount=snapshot?2U:3U,attachmentCount=colorCount+1;')
s=replace(s,'for(unsigned i=0;i<4;++i){attachments[i].format=formats[i];','for(unsigned i=0;i<attachmentCount;++i){attachments[i].format=formats[i];')
s=replace(s,'attachments[i].finalLayout=i==3?','attachments[i].finalLayout=i==colorCount?')
s=replace(s,'}},depth{3,VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};','}},depth{colorCount,VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};')
s=replace(s,'subpass.colorAttachmentCount=3;','subpass.colorAttachmentCount=colorCount;')
s=replace(s,'passInfo.attachmentCount=4;','passInfo.attachmentCount=attachmentCount;')
s=replace(s,'VkBool32 ordinary=VK_TRUE;','VkBool32 ordinary=ordinaryMode?VK_TRUE:VK_FALSE;')
blend=re.findall(r'([A-Za-z]+)\.attachmentCount=3;',s);assert len(blend)==1,blend;s=s.replace(blend[0]+'.attachmentCount=3;',blend[0]+'.attachmentCount=colorCount;')
s=replace(s,'report["scope"]="Private compilation fixture with explicit ordinary-opaque specialization; no native pipeline identity or frame timing claim";', 'report["scope"]="Private compilation fixture with recorded role and target; no native pipeline identity or frame timing claim";report["ordinarySpecialization"]=ordinaryMode;report["target"]=snapshot?"snapshot":"main";')
p.write_text(s)
pending=['mesh.frag'];seen=set()
while pending:
 name=pending.pop()
 if name in seen:continue
 seen.add(name);source=root/'shaders'/name;assert source.is_file();text=source.read_text()
 pending.extend(re.findall(r'^\s*#include\s+"([^"]+)"',text,re.M))
 for variant in ['base','isolation','beauty']:
  target=out/'source'/variant/name;target.parent.mkdir(parents=True,exist_ok=True);value=text
  if variant!='base':value=value.replace('camera.qaParameters.x','0.0')
  if variant=='beauty':value=value.replace('camera.qaParameters.y','0.0')
  target.write_text(value)
cache=(build/'CMakeCache.txt').read_text();ninja=re.search(r'^CMAKE_MAKE_PROGRAM:FILEPATH=(.+)$',cache,re.M)[1]
names=['mesh_object_bindless_clipmap_field_early.frag.spv','mesh_object_bindless_clipmap_field.frag.spv','character_snapshot_object_bindless_clipmap_field_early.frag.spv']
commands={}
for name in names:
 rows=subprocess.check_output([ninja,'-C',str(build),'-t','commands','shaders/'+name],text=True,encoding='utf-8').splitlines();compiler=next(part.strip() for part in rows[-1].split(' && ') if 'glslc.exe' in part)
 # Production paths contain no spaces; remove dependency-output arguments.
 args=compiler.split();assert all('"' not in v for v in args)
 cleaned=[];i=0
 while i<len(args):
  if args[i]=='-MD':i+=1;continue
  if args[i]=='-MF':i+=2;continue
  cleaned.append(args[i]);i+=1
 commands[name]=cleaned
(out/'compile-commands.json').write_text(json.dumps(commands,indent=2));print(json.dumps(dict(sourceFiles=len(seen),sourceBytes=sum((root/'shaders'/name).stat().st_size for name in seen),programs=names)))
