from pathlib import Path
import json,subprocess,os,sys,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
if '--inside' not in sys.argv:
 env=os.environ.copy();temporary=out/'tmp';temporary.mkdir(exist_ok=True);env.update(TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary),VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg')
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],cwd=root,env=env).returncode)
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
before=inputs(root);commands=json.loads((out/'compile-commands.json').read_text());rows=[]
command=['cl.exe','/nologo','/EHsc','/std:c++17','/utf-8','/O2','/ID:/Tools/VulkanSDK/1.4.350.0/Include','/I'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'),'/Fo'+str(out/'probe.obj'),'/Fe'+str(out/'probe.exe'),str(out/'probe.cpp'),'/link','/LIBPATH:D:/Tools/VulkanSDK/1.4.350.0/Lib','vulkan-1.lib']
with (out/'probe-build.log').open('wb') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert r.returncode==0,(out/'probe-build.log').read_text(errors='replace')[-4000:]
os.environ.pop('VK_LOADER_DRIVERS_SELECT',None)
for name,production in commands.items():
 for variant in ['base','isolation','beauty']:
  folder=out/'program'/variant;folder.mkdir(parents=True,exist_ok=True);target=folder/name;command=list(production)
  command[command.index(str(root/'shaders/mesh.frag').replace('\\','/'))]=str(out/'source'/variant/'mesh.frag')
  command[command.index('-o')+1]=str(target)
  with (folder/(name+'.compile.log')).open('wb') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=60)
  assert r.returncode==0,(folder/(name+'.compile.log')).read_text(errors='replace')[-2000:]
  subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(target)],check=True,capture_output=True,timeout=30)
  if variant=='base':assert digest(target)==digest(root/'build/ninja-msvc-release/shaders'/name),'Baseline compiler bytes differ'
  role='generic' if name=='mesh_object_bindless_clipmap_field.frag.spv' else 'ordinary';destination='snapshot' if name.startswith('character_snapshot') else 'main';report=folder/(name+'.json')
  command=[str(out/'probe.exe'),str(root/'build/ninja-msvc-release/shaders/mesh_object_compute.vert.spv'),str(target),str(report),role,destination];started=time.monotonic()
  with (folder/(name+'.stdout')).open('wb') as log,(folder/(name+'.stderr')).open('wb') as err:r=subprocess.run(command,cwd=root,stdout=log,stderr=err,timeout=60)
  assert r.returncode==0,(folder/(name+'.stderr')).read_text(errors='replace')[-2500:]
  data=json.loads(report.read_text());assert data['queueSubmissions']==0 and not data['validationErrors'];assert not (folder/(name+'.stderr')).stat().st_size
  fragment=next(e for e in data['executables'] if e['stage']==16);metrics={s['name']:s['value'] for s in fragment['statistics']}
  row=dict(program=name,variant=variant,role=role,target=destination,registers=metrics['Register Count'],binaryBytes=metrics['Binary Size'],spirvBytes=target.stat().st_size,sha256=digest(target),seconds=time.monotonic()-started);rows.append(row)
  (out/'matrix.json').write_text(json.dumps(dict(rows=rows,queueSubmissions=0,newGpuTimingExecuted=False,sourceInputsUnchanged=inputs(root)==before),indent=2));print(json.dumps(row),flush=True)
assert inputs(root)==before
