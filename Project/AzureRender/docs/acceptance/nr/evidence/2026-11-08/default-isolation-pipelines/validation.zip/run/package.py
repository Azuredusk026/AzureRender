from pathlib import Path
import json,hashlib,subprocess,sys,zipfile,re,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
checks={}
def read_cases(file,configuration,label,allow_failure=False):
 for case in ET.parse(out/file).getroot().findall('testcase'):
  if case.find('failure') is not None:
   assert allow_failure;continue
  assert case.attrib['status']=='run'
  output=(case.findtext('system-out') or '').strip();assert not any(s in output for s in ['Validation Error:','SYNC-HAZARD','VUID-'])
  key=(configuration,label,case.attrib['name']);checks[key]=dict(configuration=configuration,device=label,name=case.attrib['name'],seconds=case.attrib['time'],outputSha256=hashlib.sha256(output.encode()).hexdigest(),evidenceFile='run/'+file)
read_cases('release-initial.xml','release','nvidia',True)
for config in ['release','debug']:
 for device in ['nvidia','intel']:
  read_cases(config+'-'+device+'.xml',config,device)
  read_cases(config+'-final-'+device+'.xml',config,device)
assert len(checks)==20,len(checks)
proof=[]
catalogs=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';manifest=json.loads(p.read_text());verify(root,manifest)
 proof.append(dict(configuration=config,sha256=digest(p),source=manifest['source'],testProducts=manifest['buildScope']['testProducts']))
 catalog=json.loads((p.parent/'shader-reload.json').read_text());new=[row for row in catalog['programs'] if row['output'].endswith('_isolation0.frag.spv')]
 assert len(catalog['programs'])<=catalog['maximumPrograms'] and len(new)==64
 assert len(set(row['output'] for row in catalog['programs']))==len(catalog['programs'])
 for row in new:
  assert row['source']=='mesh.frag' and 'AZURE_STATIC_ISOLATION=1' in row['defines'] and 'AZURE_ORDINARY_EARLY_DEPTH=1' in row['defines']
  assert not any(value in row['defines'] for value in ['AZURE_OPAQUE_SNAPSHOT=1','AZURE_GEOMETRY_SAMPLES=1','AZURE_HAIR_PIXEL_INTEGRAL=1','AZURE_VIEW_FOG=1'])
 catalogs.append(dict(configuration=config,programs=len(catalog['programs']),maximumPrograms=catalog['maximumPrograms'],newPrograms=len(new)))
(out/'production-provenance.json').write_text(json.dumps(proof,indent=2))
(out/'catalog.json').write_text(json.dumps(catalogs,indent=2))
image=json.loads((out/'image-precision/results.json').read_text());equivalence=json.loads((out/'image-equivalence.json').read_text());assert equivalence['fourFramesExact'] and equivalence['rendererSourceEquivalent']
assert len(image['frames'])==4 and all(row['changedPixels']==0 and row['sha256']==row['referenceSha256'] for row in image['frames'])
invalid=json.loads((out/'cost-invalid.json').read_text());assert not invalid['wholeFrameBenefitMeasured'] and not invalid['afterReferenceExecuted']
audit=json.loads((out/'audit.json').read_text());boundaries=json.loads((out/'module-boundaries.json').read_text());assert boundaries['status']=='passed' and not boundaries['violations']
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
user=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest();assert user==audit['userDiffSha256']=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
sources=['CMakeLists.txt','shaders/mesh.frag','shaders/unlit_opaque.glsl','shaders/unlit_blend.glsl','shaders/view_fog_material.glsl','src/scenes/CharacterSceneRenderer.hpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterMaterialSampling.inc','tests/DepthPrefillRecordingTests.cpp','tests/DefaultIsolationViewGpuTests.cpp']
members={};excluded={'views.py','view_probe.cpp','view-build.json','build_view_probe.py','integrate.py','prepare_build.py','prepare_evaluation.py','prepare_final_build.py'}
for p in out.rglob('*'):
 if not p.is_file():continue
 parts=p.relative_to(out).parts
 if 'tmp' in parts or 'view-probe' in parts or p.name in excluded or p.name=='environment.json':continue
 if p.suffix not in ['.py','.json','.log','.xml','.csv','.cpp','.hpp','.inc','.glsl','.frag']:continue
 if p.stat().st_size>2*2**20:continue
 members['run/'+p.relative_to(out).as_posix()]=p
for name in sources:members['source/'+name]=root/name
for p in sorted((out/'precision/shaders').glob('*.spv')):members['program/'+p.name]=p
members['reference/frozen-project-inputs.json']=out.parent/'20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/default-isolation-pipelines';evidence.mkdir(parents=True,exist_ok=True);package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(members.items()):z.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,path in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(path)
control=json.loads((out/'production-control.json').read_text());assert control['registers']==96 and control['queueSubmissions']==0 and not control['validationErrors']
report=dict(schemaVersion=1,status='integrated-register-pressure-reduced-frame-cost-pending',sourceBase='ab7121f',sourceHashes={name:digest(root/name) for name in sources},checks=list(checks.values()),staticControl=control,baselineRegisters=128,candidateRegisters=96,registerReductionFraction=.25,
 image=image,imageProductionBinding=equivalence,wholeFrameCost=invalid,wholeFrameBenefitMeasured=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',
 unchangedPrograms=audit['products'],catalogs=catalogs,moduleBoundaries=boundaries,userDiffSha256=user,evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),imagesStoredByReference=True,taskRetentionDays=1)
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'docs/development/artifact-manifest.json';data=json.loads(p.read_text(encoding='utf-8'));data['milestones']=[m for m in data['milestones'] if m['path']!='runs/'+out.name]
data['milestones'].insert(0,dict(path='runs/'+out.name,name='默认隔离材质管线',status='RegisterPressureReducedFrameCostPending',sourceBase='ab7121f',evidence='docs/acceptance/nr/default-isolation-pipelines.md',checksPassed=20,registerReductionFraction=.25,nativeImagesExact=True,wholeFrameBenefitMeasured=False,formalPerformancePassed=False))
p.write_text(json.dumps(data,ensure_ascii=False,indent=2).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-beauty-shader-specialization.md','docs/development/default-isolation-pipelines.md','docs/acceptance/nr/default-isolation-pipelines.md']:
 path=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (path.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],checks=len(checks),registerReductionFraction=.25,fourFramesExact=True,evidenceBytes=package.stat().st_size,userDiffPreserved=True)))
