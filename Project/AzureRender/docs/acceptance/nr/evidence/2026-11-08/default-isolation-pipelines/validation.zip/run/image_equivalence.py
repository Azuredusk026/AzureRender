from pathlib import Path
import json,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import digest
precision=out/'precision';report=json.loads((out/'image-precision/results.json').read_text());assert report['metadata']['defaultIsolationSelected'] and not report['metadata']['defaultIsolationFallback'] and all(row['changedPixels']==0 for row in report['frames'])
source=(root/'src/scenes/CharacterSceneRenderer.cpp').read_text();private=(precision/'runtime/CharacterSceneRenderer.cpp').read_text();include='#include "'+(precision/'runtime/CharacterMaterialSampling.inc').as_posix()+'"';assert private.replace(include,'#include "CharacterMaterialSampling.inc"')==source
sampling=(root/'src/scenes/CharacterMaterialSampling.inc').read_text();privateSampling=(precision/'runtime/CharacterMaterialSampling.inc').read_text();line='\n                file="'+(precision/'shaders').as_posix()+'/"+file.substr(file.find_last_of(char(47))+1);';assert privateSampling.replace(line,'')==sampling
rows=[]
for p in sorted((precision/'shaders').glob('*.spv')):
 for configuration in ['release','debug']:
  target=root/f'build/ninja-msvc-{configuration}/shaders'/p.name;assert digest(target)==digest(p),target
  rows.append(dict(configuration=configuration,program=p.name,sha256=digest(p)))
assert len(rows)==8
(out/'image-equivalence.json').write_text(json.dumps(dict(programs=rows,privateDifference='Only shader file resolution redirects to byte-identical captured programs',rendererSourceEquivalent=True,imageMetadata=report['metadata'],fourFramesExact=True),indent=2));print('Four captured shader variants match both production builds; renderer differs only in shader file resolution')
