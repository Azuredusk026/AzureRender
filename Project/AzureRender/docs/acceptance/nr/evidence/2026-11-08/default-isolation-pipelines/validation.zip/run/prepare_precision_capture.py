from pathlib import Path
out=Path(__file__).resolve().parent
source=(out/'capture.py').read_text().replace("folder=out/'image'","folder=out/'image-precision'")
source=source.replace("command[0]=str(build/'AzurePlayer.exe')","command[0]=str(out/'precision/runtime/ProbePlayer.exe');command+=['--resource-root',str(build)]")
source=source.replace("[build/'AzurePlayer.exe',*sorted", "[build/'AzurePlayer.exe',out/'precision/runtime/ProbePlayer.exe',*sorted((out/'precision/shaders').glob('*.spv')),*sorted")
(out/'capture_precision.py').write_text(source)
