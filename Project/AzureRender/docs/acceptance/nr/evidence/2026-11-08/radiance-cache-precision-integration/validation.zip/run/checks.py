from pathlib import Path
import os,sys,json,subprocess,time,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;configuration=sys.argv[1];assert configuration in ['Release','Debug']
build=root/'build'/('ninja-msvc-'+configuration.lower());baseline=json.loads((out/(configuration.lower()+'-baseline-shaders.json')).read_text())
changed=[name for name,sha in baseline.items() if hashlib.sha256((build/'shaders'/name).read_bytes()).hexdigest()!=sha]
(out/(configuration.lower()+'-retained-shaders.json')).write_text(json.dumps(dict(originalCount=len(baseline),changedPrograms=changed),indent=2));assert not changed,changed
env=os.environ.copy();env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'),TMPDIR=str(out/'tmp'))
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';rows=[]
for label,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 env['VK_LOADER_DRIVERS_SELECT']=driver
 pattern=r'^AzureRender\.(SurfaceRadianceCache|SurfaceRadianceCacheGpu|SurfaceRadianceRecording|DepthPrefillRecording|BeautyCompositionGpu)$' if label=='nvidia' else r'^AzureRender\.(SurfaceRadianceCacheGpu|BeautyCompositionGpu)$'
 command=[ctest,'--test-dir',str(build),'-R',pattern,'--output-on-failure','--no-tests=error','--output-junit',str(out/(configuration.lower()+'-'+label+'.xml'))]
 started=time.monotonic()
 with (out/(configuration.lower()+'-'+label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 rows.append(dict(device=label,command=command,exitCode=r.returncode,seconds=time.monotonic()-started));print(json.dumps(rows[-1]),flush=True)
 (out/(configuration.lower()+'-checks.json')).write_text(json.dumps(rows,indent=2))
 if r.returncode:print((out/(configuration.lower()+'-'+label+'.log')).read_text(errors='replace')[-6000:]);raise SystemExit(r.returncode)
 view=out/(configuration.lower()+'-view-'+label);view.mkdir(exist_ok=True)
 command=[str(build/'AzureSurfaceRadianceViewGpuTests.exe'),str(build/'shaders'),str(view)]
 started=time.monotonic()
 with (out/(configuration.lower()+'-view-'+label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 rows.append(dict(device=label,kind='paired-view',command=command,exitCode=r.returncode,seconds=time.monotonic()-started));print(json.dumps(rows[-1]),flush=True)
 (out/(configuration.lower()+'-checks.json')).write_text(json.dumps(rows,indent=2))
 if r.returncode:print((out/(configuration.lower()+'-view-'+label+'.log')).read_text(errors='replace')[-6000:]);raise SystemExit(r.returncode)
