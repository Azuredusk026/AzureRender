from pathlib import Path
import shutil,json
root=Path.cwd();out=Path(__file__).resolve().parent
for config in ['release','debug']:
 build=root/('build/ninja-msvc-'+config);shutil.copyfile(build/'build-provenance.json',out/('measured-'+config+'-provenance.json'));shutil.copyfile(build/'shader-reload.json',out/('measured-'+config+'-catalog.json'))
manifest=json.loads((out/'measured-release-provenance.json').read_text())
for name in json.loads((out/'installed.json').read_text()):
 p=root/name;q=out/'measured-source'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
p=root/'CMakeLists.txt';s=p.read_text();s=s.replace('if(AZURE_ENABLE_SURFACE_RADIANCE_REUSE)\n    target_compile_definitions(AzureRenderCore PRIVATE AZURE_SURFACE_RADIANCE_PROGRAMS=1)\nendif()\n','',1)
s=s.replace('if(AZURE_ENABLE_SURFACE_RADIANCE_REUSE)\n    target_compile_definitions(AzureRenderHost PRIVATE AZURE_SURFACE_RADIANCE_PROGRAMS=1)\n    target_compile_definitions(AzurePlayerHost PRIVATE AZURE_SURFACE_RADIANCE_PROGRAMS=1)\nendif()\n','',1)
anchor='option(AZURE_ENABLE_SURFACE_RADIANCE_REUSE "Enable experimental same-frame surface-radiance reuse" OFF)'
s=s.replace(anchor,anchor+'\nset_property(SOURCE src/scenes/CharacterSceneRenderer.cpp src/app/AzureRenderApp.cpp APPEND PROPERTY\n    COMPILE_DEFINITIONS "$<$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_REUSE}>:AZURE_SURFACE_RADIANCE_PROGRAMS=1>")',1)
tmp=p.with_name(p.name+'.radiance-tmp');tmp.write_text(s,encoding='utf-8',newline='\n');tmp.replace(p)
source=(out/'build.py').read_text().replace("'-DAZURE_ENABLE_SURFACE_RADIANCE_REUSE=ON'","'-DAZURE_ENABLE_SURFACE_RADIANCE_REUSE=OFF'")
source=source.replace("['AzureSurfaceRadianceViewGpuTests','AzureSurfaceRadianceCacheTests','AzureSurfaceRadianceCacheGpuTests','AzureSurfaceRadianceRecordingTests','AzureDepthPrefillRecordingTests','AzureBeautyCompositionGpuTests']","['AzureSurfaceRadianceCacheTests','AzureDepthPrefillRecordingTests']")
source=source.replace("str(Path(__file__).resolve())","str(Path(__file__).resolve())")
source=source.replace("configuration.lower()+'-build.log'","configuration.lower()+'-default-build.log'").replace("configuration.lower()+'-build.json'","configuration.lower()+'-default-build.json'")
# Remove generated experimental programs after OFF configuration and before provenance.
source=source.replace("r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT);results.append", "r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)\n  if command[0]=='cmake' and r.returncode==0:\n   cleanup=subprocess.run([sys.executable,'-X','utf8',str(out/'cleanup_programs.py'),configuration],cwd=root,stdout=log,stderr=subprocess.STDOUT)\n   assert cleanup.returncode==0\n  results.append")
(out/'final_build.py').write_text(source);print('Measured source preserved; default OFF build prepared with file-scoped feature definitions')
