from pathlib import Path
import re,json
root=Path.cwd();run=Path(__file__).resolve().parent;p=run/'proposed'
def read(name):return (p/name).read_text(encoding='utf-8')
def save(name,s):
 q=p/name;q.write_text(s,encoding='utf-8',newline='\n')
pattern=re.compile(r'^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',re.M|re.S)
s=read('CMakeLists.txt')
s=pattern.sub(lambda m:m[1]+'endforeach()\nif(AZURE_ENABLE_SURFACE_RADIANCE_REUSE)\n'+m[2],s,count=1)
s=s.replace('endforeach()\nadd_custom_target(AzureRenderShaders','endforeach()\nendif()\nadd_custom_target(AzureRenderShaders',1)
s=s.replace('option(AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION', 'option(AZURE_ENABLE_SURFACE_RADIANCE_REUSE "Enable experimental same-frame surface-radiance reuse" OFF)\noption(AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION',1)
s=s.replace('compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.vert")','if(AZURE_ENABLE_SURFACE_RADIANCE_REUSE)\ncompile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.vert")',1)
s=s.replace('OUTPUT_NAME surface_radiance_consumer.frag)','OUTPUT_NAME surface_radiance_consumer.frag)\nendif()',1)
s=s.replace('if(_radiance_selected)','if(_radiance_selected AND NOT "AZURE_STATIC_ISOLATION=1" IN_LIST _radiance_defines)',1)
s=s.replace('    add_executable(AzureSurfaceRadianceCacheGpuTests','    if(AZURE_ENABLE_SURFACE_RADIANCE_REUSE)\n    add_executable(AzureSurfaceRadianceCacheGpuTests',1)
s=s.replace('    target_link_libraries(AzureOpaqueTransparencyScratchTests','    endif()\n    target_link_libraries(AzureOpaqueTransparencyScratchTests',1)
s=s.replace('if(AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION)\n    target_compile_definitions', 'if(AZURE_ENABLE_SURFACE_RADIANCE_REUSE)\n    target_compile_definitions(AzureRenderCore PRIVATE AZURE_SURFACE_RADIANCE_PROGRAMS=1)\nendif()\nif(AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION)\n    target_compile_definitions',1)
s=s.replace('target_compile_definitions(AzurePlayerHost PUBLIC AZURE_WITH_EDITOR=0)','target_compile_definitions(AzurePlayerHost PUBLIC AZURE_WITH_EDITOR=0)\nif(AZURE_ENABLE_SURFACE_RADIANCE_REUSE)\n    target_compile_definitions(AzureRenderHost PRIVATE AZURE_SURFACE_RADIANCE_PROGRAMS=1)\n    target_compile_definitions(AzurePlayerHost PRIVATE AZURE_SURFACE_RADIANCE_PROGRAMS=1)\nendif()',1)
s=s.replace('    if(shader_source_base STREQUAL "mesh.frag" OR shader_source_base STREQUAL "beauty_composition_test.comp")','    if(shader_source_base MATCHES "^surface_radiance_probe\\.frag$")\n        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/surface_radiance_identity.glsl" "${SHADER_SOURCE_DIR}/beauty_composition.glsl")\n    endif()\n    if(shader_source_base STREQUAL "mesh.frag" OR shader_source_base STREQUAL "beauty_composition_test.comp")',1)
save('CMakeLists.txt',s)
s=read('src/scenes/CharacterSceneRenderer.hpp');s=pattern.sub(lambda m:m[1]+m[2],s);save('src/scenes/CharacterSceneRenderer.hpp',s)
s=read('src/scenes/CharacterSceneRenderer.cpp');s=pattern.sub('    if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)overlayBegin.clearValues.push_back(SurfaceRadianceCache::clearValue(kind));\n',s)
s=s.replace('    auto radianceRequirements=', '#if defined(AZURE_SURFACE_RADIANCE_PROGRAMS)\n    auto radianceRequirements=',1)
s=s.replace('    bindlessTextures_ = access.mode==ResourceAccessMode::Indexed;','#else\n    surfaceRadianceCapable_=false;\n#endif\n    bindlessTextures_ = access.mode==ResourceAccessMode::Indexed;',1);save('src/scenes/CharacterSceneRenderer.cpp',s)
s=read('shaders/mesh.frag')
def main_merge(m):
 return m[1].split('void main()')[0]+m[2].replace('{\n#if defined(AZURE_SURFACE_RADIANCE_REUSE)', '{\n    prepareShadowReceiver();\n#if defined(AZURE_SURFACE_RADIANCE_REUSE)',1)
s=pattern.sub(main_merge,s);save('shaders/mesh.frag',s)
s=read('shaders/surface_radiance_identity.glsl');s='#include "beauty_composition.glsl"\n'+s;s=s.replace('a.rgb+(blended-vec3(a.a,b.a,c.a))','azureBeautyReplace(a.rgb,blended,vec3(a.a,b.a,c.a))');save('shaders/surface_radiance_identity.glsl',s)
s=read('src/app/AzureRenderApp.cpp')
s=s.replace('    fragmentPrimitiveIdentity_=supportedSampler.geometryShader==VK_TRUE;', '#if defined(AZURE_SURFACE_RADIANCE_PROGRAMS)\n    fragmentPrimitiveIdentity_=supportedSampler.geometryShader==VK_TRUE;',1)
s=s.replace('    deviceFeatures.geometryShader=fragmentPrimitiveIdentity_?VK_TRUE:VK_FALSE;', '    deviceFeatures.geometryShader=fragmentPrimitiveIdentity_?VK_TRUE:VK_FALSE;\n#endif',1)
s=s.replace('    VkPhysicalDeviceShaderQuadControlFeaturesKHR quadControl', '#if defined(AZURE_SURFACE_RADIANCE_PROGRAMS)\n    VkPhysicalDeviceShaderQuadControlFeaturesKHR quadControl',1)
s=s.replace('    auto exactDepthBias=azurerender::rhi::queryExactDepthBias(physicalDevice_);','#endif\n    auto exactDepthBias=azurerender::rhi::queryExactDepthBias(physicalDevice_);',1);save('src/app/AzureRenderApp.cpp',s)
installed=[]
for q in p.rglob('*'):
 if not q.is_file():continue
 name=q.relative_to(p);s=q.read_text(encoding='utf-8');assert not re.search(r'^<<<<<<<|^=======|^>>>>>>>',s,re.M),str(name)
 target=root/name
 if target.exists() and not str(name).startswith('tests\\SurfaceRadiance'):
  original=run/'original-source'/name
  assert original.exists() and target.read_bytes()==original.read_bytes(),str(name)
 tmp=target.with_name(target.name+'.radiance-tmp');tmp.write_text(s,encoding='utf-8',newline='\n');tmp.replace(target);installed.append(str(name))
(run/'installed.json').write_text(json.dumps(installed,indent=2));print('Installed',len(installed),'owned files')
