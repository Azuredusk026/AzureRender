from pathlib import Path
import json,sys,hashlib,zipfile,re,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import digest
image=json.loads((out/'image/results.json').read_text());cost=json.loads((out/'cost-results-v1.json').read_text());audit=json.loads((out/'audit.json').read_text());modes=json.loads((out/'configuration-modes.json').read_text())
assert all(r['changedPixels']==0 for r in image['frames']) and cost['bracketStable'] and cost['gpuSavedMs']<0
checks=[];views=[]
for config in ['release','debug']:
 for label in ['nvidia','intel']:
  for case in ET.parse(out/(config+'-'+label+'.xml')).getroot().findall('testcase'):
   assert case.find('failure') is None
   checks.append(dict(configuration=config,device=label,name=case.attrib['name'],skipped=case.find('skipped') is not None,seconds=case.attrib['time']))
  data=json.loads((out/(config+'-view-'+label)/(label+'-summary.json')).read_text());assert data['status']=='passed' and data['validationErrors']==0 and data['zeroAllocator']
  assert len(data['checks'])==20;views.append(dict(configuration=config,device=label,quadCapable=data['quadCapable'],recordedStates=20,pairedComparisons=10,status=data['status']))
 for case in ET.parse(out/(config+'-default.xml')).getroot().findall('testcase'):
  assert case.find('failure') is None and case.find('skipped') is None;checks.append(dict(configuration=config,mode='default',name=case.attrib['name'],skipped=False,seconds=case.attrib['time']))
assert len(checks)==18 and sum(r['skipped'] for r in checks)==2
cleanup=[json.loads((out/name).read_text()) for name in ['release-program-cleanup.json','debug-program-cleanup.json','disabled-tests-cleanup.json']];assert all(r['status']=='applied' for r in cleanup)
sources=[name.replace('\\','/') for name in json.loads((out/'installed.json').read_text())]+['tests/SurfaceRadianceViewGpuTests.cpp']
for path in [out/'startup-environment.json',*(out/('cost-v1-'+label)/'environment.json' for label in ['baseline-before','candidate','baseline-after'])]:
 def sanitize(value):
  if isinstance(value,dict):return {k:sanitize(v) for k,v in value.items() if k!='rawXml'}
  if isinstance(value,list):return [sanitize(v) for v in value]
  return value
 path.with_name(path.stem+'-summary.json').write_text(json.dumps(sanitize(json.loads(path.read_text())),indent=2))
members={}
for p in out.rglob('*'):
 if not p.is_file():continue
 relative=p.relative_to(out)
 if any(part in {'tmp','__pycache__','merge','proposed'} for part in relative.parts):continue
 if p.name in ['startup-environment.json','environment.json']:continue
 if p.suffix not in ['.py','.json','.log','.xml','.csv','.cpp','.inc','.hpp','.txt','.glsl','.frag','.vert']:continue
 if not p.stat().st_size or p.stat().st_size>2*2**20:continue
 members['run/'+relative.as_posix()]=p
for name in sources:members['source/'+name]=root/name
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/radiance-cache-precision-integration';evidence.mkdir(parents=True,exist_ok=True);archive=evidence/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(members.items()):z.write(path,name)
assert archive.stat().st_size<8*2**20
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,path in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='exact-math-local-regression-default-disabled',sourceBase='9a11cf5',sourceHashes={name:digest(root/name) for name in sources},image=image,cost=cost,defaultReuseEnabled=False,experimentalBuildOption='AZURE_ENABLE_SURFACE_RADIANCE_REUSE',significantGainObserved=False,finalChecks=checks,views=views,productionAudit=audit,configurationModes=modes,
 cleanup=dict(files=sum(r['files'] for r in cleanup),logicalBytes=sum(r['logicalBytes'] for r in cleanup),volumeObservedDeltaBytes=sum(r['freeAfterBytes']-r['freeBeforeBytes'] for r in cleanup)),formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=archive.stat().st_size,evidenceSha256=digest(archive),archivedPngCopies=0)
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'docs/development/artifact-manifest.json';data=json.loads(p.read_text(encoding='utf-8'));data['milestones'].insert(0,dict(path='runs/'+out.name,name='照明缓存精度与成本',status='ExactMathLocalRegressionDefaultDisabled',sourceBase='9a11cf5',evidence='docs/acceptance/nr/radiance-cache-precision-integration.md',checksPassed=16,checksSkipped=2,pairedViewFlowsPassed=4,nativeFourFramesExact=True,gpuSavedMs=cost['gpuSavedMs'],defaultReuseEnabled=False,reclaimedFiles=report['cleanup']['files'],formalPerformancePassed=False));p.write_text(json.dumps(data,ensure_ascii=False,indent=2).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
def update(name,old,new):
 p=root/name;s=p.read_text(encoding='utf-8');assert old in s,name;p.write_text(s.replace(old,new,1),encoding='utf-8',newline='\n')
update('README.md','照明复用的[接收面核对](docs/acceptance/nr/radiance-receiver-entry.md)保持原像素差异，候选继续隔离。','照明复用的[接收面核对](docs/acceptance/nr/radiance-receiver-entry.md)保存入口位置与图像来源。')
update('README.md','[共享照明组合](docs/acceptance/nr/radiance-precision-boundaries.md)通过四项小数据 GPU 检查，既有渲染程序保持原字节，照明复用的原生修复继续待验收。','[共享照明组合](docs/acceptance/nr/radiance-precision-boundaries.md)通过四项小数据 GPU 检查，既有渲染程序保持原字节。\n[照明缓存接入](docs/acceptance/nr/radiance-cache-precision-integration.md)通过严格四帧及设备回退检查，短时 GPU 均值增加约 0.72 毫秒，实验选项默认关闭。')
update('docs/plans/azure-engine-plan.md','照明复用候选的消费者已具备具体精度边界，当前原生接入及画面继续待验证。','[照明缓存接入](../acceptance/nr/radiance-cache-precision-integration.md)通过严格四帧及两种配置的设备检查。\n短时 GPU 均值增加约 0.72 毫秒，实验选项默认关闭。\n下一项先核定实际复用覆盖及附件成本，再组织有效的着色批次。')
update('docs/plans/azure-engine-plan.md','四帧与原候选摘要一致，原有一字节差异继续待定位，候选保持隔离。','该记录保存入口及图像来源，当前配置见[同帧照明复用](../development/surface-radiance-cache.md)。')
update('docs/plans/2026-11-06-performance-bottlenecks.md','## 当前状态\n','## 当前状态\n\n[照明缓存接入](../acceptance/nr/radiance-cache-precision-integration.md)保持严格四帧零差异。\n本地短时参考 GPU 均值约为 29.98 毫秒。\n候选增加约 0.72 毫秒，实验选项默认关闭。\n后续先建立实际命中覆盖及附件成本依据。\n')
update('docs/acceptance/nr/surface-radiance-reuse.md','候选处于隔离状态，原生零像素门槛未通过。\n生产运行输入以 `521e002` 的已验证实现为准。','本记录保存 2026-11-07 的隔离候选。\n该批原生零像素门槛未通过。\n当前配置与判断见[精度及成本验收](radiance-cache-precision-integration.md)。')
update('docs/plans/2026-11-08-radiance-cache-precision-integration.md','范围为旧同帧照明缓存与当前运行时的接入。','范围为同帧照明缓存与当前运行时的接入。')
p=root/'docs/plans/2026-11-08-radiance-cache-precision-integration.md';p.write_text(p.read_text(encoding='utf-8')+'\n## 结果\n\n严格四帧、设备回退及资源释放检查通过。\n短时 GPU 均值增加约 0.72 毫秒，实验选项默认关闭。\n最终主构建保持原 673 个程序的字节。\n详见[精度与成本验收](../acceptance/nr/radiance-cache-precision-integration.md)。\n',encoding='utf-8',newline='\n')
update('CHANGELOG.md','# Changelog\n','# Changelog\n\n## 照明缓存精度与成本 2026-11-08\n\n- 同帧照明缓存通过严格四帧及真实设备回退检查。\n- 本地 GPU 均值增加约 0.72 毫秒，实验选项默认关闭。\n- 主构建保留 673 个原字节程序，本批实验生成物按清单回收。\n- 原画质及帧预算继续验收，见[专项记录](docs/acceptance/nr/radiance-cache-precision-integration.md)。\n')
print(json.dumps(dict(status=report['status'],finalChecks=len(checks),skipped=2,viewFlows=4,gpuSavedMs=cost['gpuSavedMs'],reclaimedLogicalBytes=report['cleanup']['logicalBytes'],evidenceBytes=archive.stat().st_size)))
