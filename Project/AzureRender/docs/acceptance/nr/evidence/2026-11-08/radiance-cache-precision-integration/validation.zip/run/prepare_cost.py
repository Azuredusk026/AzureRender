from pathlib import Path
import json,sys,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;producer=out.parent/'20261108-150504-beauty-shader-specialization-2d2daa';sys.path.insert(0,str(root/'tools'))
from build_provenance import digest
before=json.loads((producer/'production-provenance.json').read_text())[0]['source'];names=[name for name in before if name.startswith('src/') and name.endswith(('.cpp','.hpp','.inc'))]
different=[]
for name in names:
 p=out/'original-source'/name
 if not p.exists():p=root/name
 if digest(p)!=before[name]:different.append(name)
assert different==['src/scenes/CharacterMaterialSampling.inc'],different
original=(out/'original-source/src/scenes/CharacterSceneRenderer.cpp').read_text();private=(producer/'cost-baseline/CharacterSceneRenderer.cpp').read_text();include='#include "'+(producer/'cost-baseline/CharacterMaterialSampling.inc').as_posix()+'"';assert private.replace(include,'#include "CharacterMaterialSampling.inc"')==original
original=(out/'original-source/src/scenes/CharacterMaterialSampling.inc').read_text();original=re.sub(r'#if defined\(AZURE_DEFAULT_ISOLATION_VARIANTS\)\n(.*?)#else\n    \(void\)scene;\(void\)desc;\n#endif\n',lambda m:m[1],original,count=1,flags=re.S)
assert original.replace('    prepareDefaultIsolationPipeline(scene,desc);','    // Current-runtime control uses the dynamic isolation pipeline.')==(producer/'cost-baseline/CharacterMaterialSampling.inc').read_text()
assert digest(producer/'cost-baseline/ProbePlayer.exe')=='38bd2280e62b3787bdc0a2b63f1d4918285783f54f3aa5e222396c31cec89390'
(out/'reference-proof.json').write_text(json.dumps(dict(cppSourcesVerified=len(names),entrySnapshot='9a11cf5',referenceExe=str(producer/'cost-baseline/ProbePlayer.exe'),referenceExeSha256=digest(producer/'cost-baseline/ProbePlayer.exe'),difference='Current entry compile-time-disabled isolation preparation versus reference call-disabled preparation; radiance integration is the candidate change',assetCacheWriterCurrent=True,projectAssetsCopied=False),indent=2))
s=(out.parent/'20261108-165547-default-isolation-cost-5c0521/cost.py').read_text()
s=s.replace("image=json.loads((producer/'image-precision/results.json').read_text());assert len(image['frames'])==4 and all(r['changedPixels']==0 for r in image['frames'])","image=json.loads((out/'image/results.json').read_text());assert len(image['frames'])==4 and all(r['changedPixels']==0 for r in image['frames']) and image['metadata']['surfaceRadiancePrepared']")
s=s.replace("assert bool(data['defaultIsolationSelected'])==(label=='candidate')","assert bool(data.get('surfaceRadiancePrepared',False))==(label=='candidate')")
s=s.replace("('conservativeOcclusion','defaultIsolation')","('conservativeOcclusion','defaultIsolation','surfaceRadiance')")
(out/'cost.py').write_text(s)
s=(out.parent/'20261108-165547-default-isolation-cost-5c0521/run.py').read_text();(out/'run_cost.py').write_text(s)
print('Coherent current-writer reference verified against entry source snapshot; cost gated on exact four frames')
