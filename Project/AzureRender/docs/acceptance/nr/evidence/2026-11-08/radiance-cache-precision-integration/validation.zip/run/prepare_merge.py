from pathlib import Path
import zipfile,subprocess,json,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;z=zipfile.ZipFile(root/'docs/acceptance/nr/evidence/2026-11-07/surface-radiance-reuse/measurements.zip');rows=[]
names=['CMakeLists.txt','shaders/mesh.frag','shaders/mesh.vert','src/app/AzureRenderApp.cpp','src/app/AzureRenderApp.hpp','src/render/MaterialPipelinePolicy.hpp','src/render/RenderContext.hpp','src/scenes/CharacterMaterialSampling.inc','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','tests/support/VulkanComputeFixture.hpp']
for name in names:
 current=(root/name).read_bytes();folder=out/'merge'/name;folder.parent.mkdir(parents=True,exist_ok=True)
 (out/'original-source'/name).parent.mkdir(parents=True,exist_ok=True);(out/'original-source'/name).write_bytes(current)
 base=z.read('original-fixture.hpp' if name=='tests/support/VulkanComputeFixture.hpp' else 'original-source/'+name)
 candidate=z.read('candidate-source/'+name)
 for suffix,value in [('current',current),('base',base),('candidate',candidate)]:folder.with_name(folder.name+'.'+suffix).write_bytes(value.replace(b'\r\n',b'\n'))
 result=subprocess.run(['git','merge-file','-p',str(folder.with_name(folder.name+'.current')),str(folder.with_name(folder.name+'.base')),str(folder.with_name(folder.name+'.candidate'))],capture_output=True)
 assert result.returncode>=0 and result.returncode<128,result.stderr
 target=out/'proposed'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(result.stdout)
 rows.append(dict(path=name,conflicts=result.returncode,currentSha256=hashlib.sha256(current).hexdigest(),stderr=result.stderr.decode(errors='replace')))
new=['src/render/SurfaceRadianceCache.hpp','src/render/SurfaceRadianceCache.cpp','shaders/surface_radiance.glsl','shaders/surface_radiance_identity.glsl','shaders/surface_radiance_probe.frag','shaders/surface_radiance_probe.vert','tests/SurfaceRadianceCacheTests.cpp','tests/SurfaceRadianceCacheGpuTests.cpp','tests/SurfaceRadianceRecordingTests.cpp']
for name in new:
 assert not (root/name).exists();target=out/'proposed'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read('candidate-source/'+name))
# Tests are installed first so the missing resource contract can be observed.
for name in new:
 if name.startswith('tests/'):(root/name).write_bytes((out/'proposed'/name).read_bytes())
(out/'merge-report.json').write_text(json.dumps(rows,indent=2));print(json.dumps([dict(path=r['path'],conflicts=r['conflicts']) for r in rows],indent=2))
