from pathlib import Path
import sys,json,os,subprocess
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from gpu_environment import wait_and_record
temporary=out/'tmp';temporary.mkdir(exist_ok=True)
for key in ['TEMP','TMP','TMPDIR','SQLITE_TMPDIR']:os.environ[key]=str(temporary)
try:
 ready=wait_and_record(out/'startup-environment.json',timeout=30)
except Exception as error:
 (out/'environment-deferred.json').write_text(json.dumps(dict(status='deferred',reason=str(error),nativeBatchStarted=False),indent=2));print('Environment not ready; no native batch started',flush=True);raise SystemExit(2)
print(json.dumps(dict(status='idle-window-ready',samples=len(ready['startup']),powerLimitWatts=ready['startup'][-1]['powerLimitWatts'])),flush=True)
raise SystemExit(subprocess.run([sys.executable,'-X','utf8',str(out/'cost.py'),'v1'],cwd=root,env=os.environ.copy()).returncode)
