from pathlib import Path
import os,sys,subprocess,json,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'),TMPDIR=str(out/'tmp'),VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],cwd=root,env=env).returncode)
def configure(mode):
 command=['cmake','-S',str(root),'-B',str(build),'-DAZURE_ENABLE_SURFACE_RADIANCE_REUSE='+mode]
 with (out/('configure-'+mode.lower()+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0
 catalog=json.loads((build/'shader-reload.json').read_text());text=(build/'build.ninja').read_text()
 blocks=[b.splitlines()[0] for b in re.split(r'(?m)(?=^build )',text) if 'DEFINES =' in b and 'AZURE_SURFACE_RADIANCE_PROGRAMS=1' in b]
 assert len(catalog['programs'])==(720 if mode=='ON' else 673)
 assert len(blocks)==(3 if mode=='ON' else 0),blocks
 if mode=='ON':assert sum('AzureRenderApp.cpp' in b for b in blocks)==2 and sum('CharacterSceneRenderer.cpp' in b for b in blocks)==1
 return dict(mode=mode,programs=len(catalog['programs']),featureCompilationUnits=blocks)
rows=[]
try:rows.append(configure('ON'))
finally:rows.append(configure('OFF'));(out/'configuration-modes.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows))
