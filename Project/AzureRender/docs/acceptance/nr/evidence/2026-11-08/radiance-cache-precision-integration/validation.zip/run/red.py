from pathlib import Path
import subprocess,os,json
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;temporary=out/'tmp';temporary.mkdir(exist_ok=True)
env=os.environ.copy();env.update(TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary),VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg')
command=[str(root/'tools/msvc_env.bat'),'cl','/nologo','/EHsc','/std:c++17','/Zs','/Isrc','/ID:/Tools/VulkanSDK/1.4.350.0/Include','/Ibuild/ninja-msvc-debug/vcpkg_installed/x64-windows/include','tests/SurfaceRadianceCacheTests.cpp']
with (out/'red.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
text=(out/'red.log').read_text(errors='replace');assert r.returncode!=0 and 'SurfaceRadianceCache.hpp' in text and 'C1083' in text,text[-2000:]
(out/'red.json').write_text(json.dumps(dict(exitCode=r.returncode,expectedMissingSurfaceRadianceContract=True),indent=2));print(text[-600:])
