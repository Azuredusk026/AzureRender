from pathlib import Path
root=Path.cwd();run=Path(__file__).resolve().parent
def edit(name,transform):
 p=root/name;s=p.read_text(encoding='utf-8');v=transform(s);assert s!=v,name
 temp=p.with_name(p.name+'.radiance-tmp');temp.write_text(v,encoding='utf-8',newline='\n');temp.replace(p)
edit('tests/support/VulkanComputeFixture.hpp',lambda s:s.replace('// Standalone compute host.', 'class VulkanFeatureUnavailable : public std::runtime_error {public:using std::runtime_error::runtime_error;};\n\n// Standalone compute host.',1).replace('throw std::runtime_error("Fragment primitive identity is unavailable")','throw VulkanFeatureUnavailable("Fragment primitive identity is unavailable")').replace('throw std::runtime_error("Quad control and reconvergence are unavailable")','throw VulkanFeatureUnavailable("Quad control and reconvergence are unavailable")'))
edit('tests/SurfaceRadianceCacheGpuTests.cpp',lambda s:s.replace('}catch(const std::exception& e)', '}catch(const test::VulkanFeatureUnavailable& e){std::cout<<e.what()<<"; experimental GPU path unavailable\\n";return 77;}catch(const std::exception& e)',1))
s=(root/'tests/DefaultIsolationViewGpuTests.cpp').read_text(encoding='utf-8')
s=s.replace('#include <sstream>','#include <sstream>\n#include <map>\n#include <cstring>')
s=s.replace('    test::VulkanComputeFixture host(true);','    std::unique_ptr<test::VulkanComputeFixture> owner;bool capable=true;\n    try{owner=std::make_unique<test::VulkanComputeFixture>(true,false,false,true,true);}\n    catch(const test::VulkanFeatureUnavailable&){capable=false;owner=std::make_unique<test::VulkanComputeFixture>(true);}\n    auto& host=*owner;')
s=s.replace('receipt["device"]=host.properties.deviceName;','receipt["device"]=host.properties.deviceName;receipt["quadCapable"]=capable;\n    std::map<unsigned,std::vector<std::uint8_t>> reference;')
s=s.replace('    {\n        RenderViewService service','    for(bool requested:{false,true}){\n        base.fragmentPrimitiveIdentity=base.fragmentQuadControl=capable&&requested;\n        RenderViewService service',1)
s=s.replace('        descriptor.settings.faceSdfFeature=', '        descriptor.settings.sceneLightingEnabled=true;\n        descriptor.settings.faceSdfFeature=',1)
start=s.index('            const auto file=output/("phase-"');end=s.index('            std::ostringstream metadata',start)
s=s[:start]+'''            const unsigned key=lighting*8+phase;
            if(!requested)reference[key]=pixels;
            else require(reference.at(key)==pixels,"Cache and complete-shading RGB bytes must match");
'''+s[end:]
start=s.index('            const bool candidate=true;');end=s.index('            receipt["checks"].push_back',start)
s=s[:start]+'''            const bool expectedCache=capable&&requested&&lighting==0;
            require(state["surfaceRadiancePrepared"].get<bool>()==expectedCache,"View must select capability and material fallback");
            require(state["surfaceRadianceBytes"].get<std::uint64_t>()==(expectedCache?(phase==7?64U*40U:48U*48U)*64U*2U:0U),"View cache accounting must follow resize");
'''+s[end:]
s=s.replace('{{"phase",phase}', '{{"requested",requested},{"phase",phase}')
s=s.replace('std::ofstream(output/"summary.json")','std::ofstream(output/(std::string(host.properties.deviceName).find("Intel")!=std::string::npos?"intel-summary.json":"nvidia-summary.json"))')
(root/'tests/SurfaceRadianceViewGpuTests.cpp').write_text(s,encoding='utf-8',newline='\n')
def cmake(s):
 s=s.replace('set_tests_properties(AzureRender.SurfaceRadianceCacheGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)','set_tests_properties(AzureRender.SurfaceRadianceCacheGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120 SKIP_RETURN_CODE 77)',1)
 text='''    add_executable(AzureSurfaceRadianceViewGpuTests tests/SurfaceRadianceViewGpuTests.cpp)
    target_link_libraries(AzureSurfaceRadianceViewGpuTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureSurfaceRadianceViewGpuTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureSurfaceRadianceViewGpuTests AzureRenderShaders)
'''
 s=s.replace('    add_executable(AzureSurfaceRadianceRecordingTests',text+'    add_executable(AzureSurfaceRadianceRecordingTests',1)
 return s
edit('CMakeLists.txt',cmake)
edit('src/scenes/CharacterSceneRenderer.cpp',lambda s:s.replace('        surfaceRadiance_=std::make_unique<SurfaceRadianceCache>(*rhi_,context.renderExtent,static_cast<unsigned>(kMaxFramesInFlight));','''        try{surfaceRadiance_=std::make_unique<SurfaceRadianceCache>(*rhi_,context.renderExtent,static_cast<unsigned>(kMaxFramesInFlight));}
        catch(const std::exception& error){RuntimeDiagnostics::instance().info("render",std::string("Surface radiance allocation fallback: ")+error.what());}''',1))
edit(str(run.relative_to(root)/'build.py'),lambda s:s.replace("'AzureSurfaceRadianceCacheTests','AzureSurfaceRadianceCacheGpuTests'","'AzureSurfaceRadianceViewGpuTests','AzureSurfaceRadianceCacheTests','AzureSurfaceRadianceCacheGpuTests'",1))
print('Explicit unsupported-feature result and paired public-view integration prepared')
