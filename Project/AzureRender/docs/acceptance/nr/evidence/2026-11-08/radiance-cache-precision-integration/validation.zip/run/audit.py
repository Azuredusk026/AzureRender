from pathlib import Path
import json,sys,hashlib,subprocess
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
measured=json.loads((out/'measured-release-provenance.json').read_text());current=inputs(root)
changes=[name for name in sorted(current.keys()|measured['source'].keys()) if current.get(name)!=measured['source'].get(name)];assert changes==['CMakeLists.txt'],changes
rows=[]
for config in ['release','debug']:
 build=root/('build/ninja-msvc-'+config);proof=json.loads((build/'build-provenance.json').read_text());verify(root,proof)
 catalog=json.loads((build/'shader-reload.json').read_text());baseline=json.loads((out/(config+'-baseline-shaders.json')).read_text())
 assert len(catalog['programs'])==673 and len(list((build/'shaders').glob('*.spv')))==673
 assert all(digest(build/'shaders'/name)==sha for name,sha in baseline.items())
 assert 'AZURE_ENABLE_SURFACE_RADIANCE_REUSE:BOOL=OFF' in (build/'CMakeCache.txt').read_text()
 assert not any('AZURE_SURFACE_RADIANCE_PROGRAMS=1' in line for line in (build/'build.ninja').read_text().splitlines() if 'DEFINES =' in line)
 rows.append(dict(configuration=config,programs=673,programBytesUnchanged=True,featureEnabled=False,provenanceSha256=digest(build/'build-provenance.json')))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
user=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest();assert user=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
image=json.loads((out/'image/results.json').read_text());assert len(image['frames'])==4 and all(row['changedPixels']==0 for row in image['frames'])
report=dict(sourceChangesAfterMeasurement=changes,changeScope='CMake feature definition scope; all measured C++ and shader sources unchanged',configurations=rows,userDiffSha256=user,nativeFourFramesExact=True,defaultImageScope='Retained byte-identical programs and compile-time-disabled resource/feature selection; no additional default native capture',newDefaultNativeCaptureExecuted=False)
(out/'audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(defaultConfigurations=rows,userDiffPreserved=True)))
