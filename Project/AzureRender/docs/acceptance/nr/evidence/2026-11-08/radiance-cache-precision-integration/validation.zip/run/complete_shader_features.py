from pathlib import Path
root=Path.cwd();run=Path(__file__).resolve().parent
def edit(name,transform):
 p=root/name;s=p.read_text(encoding='utf-8');v=transform(s);assert v!=s,name
 tmp=p.with_name(p.name+'.radiance-tmp');tmp.write_text(v,encoding='utf-8',newline='\n');tmp.replace(p)
edit('src/app/AzureRenderApp.cpp',lambda s:s.replace('    const auto hasExtension=[&](const char* name)', '    VkPhysicalDeviceShaderDemoteToHelperInvocationFeatures demote{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SHADER_DEMOTE_TO_HELPER_INVOCATION_FEATURES};\n    const auto hasExtension=[&](const char* name)',1).replace('quadControl.pNext=&reconvergence;VkPhysicalDeviceFeatures2 available','quadControl.pNext=&reconvergence;reconvergence.pNext=&demote;VkPhysicalDeviceFeatures2 available',1).replace('fragmentQuadControl_=quadControl.shaderQuadControl&&reconvergence.shaderMaximalReconvergence;','fragmentQuadControl_=quadControl.shaderQuadControl&&reconvergence.shaderMaximalReconvergence&&demote.shaderDemoteToHelperInvocation;',1).replace('reconvergence.pNext=vulkan12Features.pNext;vulkan12Features.pNext=&quadControl;','demote.pNext=vulkan12Features.pNext;vulkan12Features.pNext=&quadControl;',1))
edit('tests/support/VulkanComputeFixture.hpp',lambda s:s.replace('            std::vector<const char*> optionalExtensions;', '            VkPhysicalDeviceShaderDemoteToHelperInvocationFeatures demote{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SHADER_DEMOTE_TO_HELPER_INVOCATION_FEATURES};\n            std::vector<const char*> optionalExtensions;',1).replace('quad.pNext=&reconvergence;VkPhysicalDeviceFeatures2 available','quad.pNext=&reconvergence;reconvergence.pNext=&demote;VkPhysicalDeviceFeatures2 available',1).replace('!quad.shaderQuadControl||!reconvergence.shaderMaximalReconvergence','!quad.shaderQuadControl||!reconvergence.shaderMaximalReconvergence||!demote.shaderDemoteToHelperInvocation',1).replace('reconvergence.pNext=const_cast<void*>(deviceInfo.pNext);deviceInfo.pNext=&quad;','demote.pNext=const_cast<void*>(deviceInfo.pNext);deviceInfo.pNext=&quad;',1))
old='''    const auto plainOrdinary=[](const LoadedAsset& mesh){return std::any_of(mesh.materials.begin(),mesh.materials.end(),[](const AssetMaterial& material){
        return ordinaryOpaqueMaterial(material)&&!extendedMaterialLighting(material)&&!material.coverageTexture.present;});};'''
new='''    const auto plainOrdinary=[](const LoadedAsset& mesh){return std::any_of(mesh.primitives.begin(),mesh.primitives.end(),[&](const AssetPrimitive& primitive){
        if(!primitive.indexCount||primitive.materialIndex>=mesh.materials.size())return false;
        const auto& material=mesh.materials[primitive.materialIndex];
        return ordinaryOpaqueMaterial(material)&&!extendedMaterialLighting(material)&&!material.coverageTexture.present;});};'''
edit('src/scenes/CharacterSceneRenderer.cpp',lambda s:s.replace(old,new,1))
print('Complete SPIR-V feature chain and referenced-material eligibility prepared')
