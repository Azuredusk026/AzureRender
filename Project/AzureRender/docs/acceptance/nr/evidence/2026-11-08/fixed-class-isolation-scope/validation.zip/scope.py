from pathlib import Path
import json,zipfile,collections,hashlib,struct
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
source=root/'docs/acceptance/nr/evidence/2026-11-08/shadow-cost-scope/validation.zip';z=zipfile.ZipFile(source)
scope=json.loads(z.read('eligibility-analysis.json'));profile=json.loads(z.read('borrowed/20261107-122133-material-contribution-cost-c567b5/profile.json'));cost=json.loads(z.read('borrowed/20261107-135517-replay-continuity-check-ceda91/control-state.json'))
control=next(row for row in cost['timings'] if row['control']=='surface-shadow');keys=set(control['baselineBefore']);assert keys==set(control['baselineAfter'])
frameTotal=sum((control['baselineBefore'][k]+control['baselineAfter'][k])/2 for k in keys)
manifest=root/'build/runs/20261108-150504-beauty-shader-specialization-2d2daa/image-precision/frames-155321/capture_manifest.json';data=json.loads(manifest.read_text());policies={row['class']:row for row in data['materialClassFeatureSpecializations']}
(out/'class-policies.json').write_text(json.dumps(list(policies.values()),indent=2))
groups=collections.defaultdict(lambda:dict(events=[],baselineMs=0.));scopeEvents={e for row in scope['groups'] for e in row['events']}
for row in profile['rows']:
 if row['event'] not in scopeEvents:continue
 state=scope['pipelineStates'][row['pipeline']];constants=state['constants'];classification='ordinary' if state['ordinary'] else 'dynamic' if constants['1']==0xffffffff else 'fixed'
 if classification=='fixed':
  policy=policies[constants['1']];assert constants['2']==policy['fixedMask'] and constants['3']==policy['fixedValue']
 key=(classification,row['program'],constants['1'],constants['2'],constants['3']);entry=groups[key];entry['events'].append(row['event']);k=str(row['event']);entry['baselineMs']+=(control['baselineBefore'][k]+control['baselineAfter'][k])/2
rows=[dict(classification=k[0],program=k[1],materialClass=k[2],fixedMask=k[3],fixedValue=k[4],**v) for k,v in groups.items()];rows.sort(key=lambda r:r['baselineMs'],reverse=True)
summary={kind:dict(draws=sum(len(row['events']) for row in rows if row['classification']==kind),milliseconds=sum(row['baselineMs'] for row in rows if row['classification']==kind)) for kind in ['ordinary','fixed','dynamic']}
for item in summary.values():item['historicalFrameFraction']=item['milliseconds']/frameTotal
report=dict(sourceBase='437e0f3',captureSha256=scope['captureSha256'],historicalFrameTotalMs=frameTotal,groups=rows,summary=summary,currentClassPoliciesMatchCapture=True,sourceZipSha256=hashlib.sha256(source.read_bytes()).hexdigest(),newGpuTimingExecuted=False,queueSubmissions=0)
(out/'scope.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(historicalFrameTotalMs=frameTotal,summary=summary,groups=[{k:v for k,v in row.items() if k!='events'} for row in rows]),indent=2))
