from pathlib import Path
import json,zipfile,hashlib,sys,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
producer=out.parent/'20261108-150504-beauty-shader-specialization-2d2daa';proof=json.loads((producer/'production-provenance.json').read_text());assert all(inputs(root)==row['source'] for row in proof)
scope=json.loads((out/'scope.json').read_text());fixed=scope['summary']['fixed'];assert fixed['historicalFrameFraction']<.25 and scope['currentClassPoliciesMatchCapture']
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/fixed-class-isolation-scope';evidence.mkdir(parents=True,exist_ok=True);package=evidence/'validation.zip'
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.json']}
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(members.items()):z.write(path,name)
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,path in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='scope-below-independent-admission',sourceBase='437e0f3',scope=scope,runtimeSourceUnchanged=True,newGpuTimingExecuted=False,newPipelineQueries=0,newBuilds=0,nativeBatchStarted=False,candidateImplemented=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package))
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'docs/development/artifact-manifest.json';data=json.loads(p.read_text(encoding='utf-8'));data['milestones'].insert(0,dict(path='runs/'+out.name,name='固定类别隔离范围',status='ScopeBelowIndependentAdmission',sourceBase='437e0f3',evidence='docs/acceptance/nr/fixed-class-isolation-scope.md',historicalScopeFraction=fixed['historicalFrameFraction'],candidateImplemented=False,newGpuTimingExecuted=False))
p.write_text(json.dumps(data,ensure_ascii=False,indent=2).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-fixed-class-isolation-scope.md','docs/acceptance/nr/fixed-class-isolation-scope.md']:
 path=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (path.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],scopeFraction=fixed['historicalFrameFraction'],evidenceBytes=package.stat().st_size)))
