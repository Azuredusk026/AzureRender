from pathlib import Path
import os,sys,subprocess,json,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
if '--inside' not in sys.argv:
 env=os.environ.copy();temporary=out/'tmp';temporary.mkdir(exist_ok=True);env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary),VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',*sys.argv[1:]],cwd=root,env=env).returncode)
configuration=sys.argv[-1];assert configuration in ['Release','Debug']
command=[sys.executable,'-X','utf8','tools/build_provenance.py','build','--build-dir',f'build/ninja-msvc-{configuration.lower()}','--config',configuration,'--test-target','AzureGpuStableKeySortTests','--test-target','AzureGpuStableKeySortGpuTests']
started=time.monotonic()
with (out/(configuration.lower()+'-build.log')).open('wb') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
(out/(configuration.lower()+'-build.json')).write_text(json.dumps(dict(command=command,exitCode=r.returncode,seconds=time.monotonic()-started),indent=2));print(configuration+' build exit '+str(r.returncode),flush=True)
raise SystemExit(r.returncode)
