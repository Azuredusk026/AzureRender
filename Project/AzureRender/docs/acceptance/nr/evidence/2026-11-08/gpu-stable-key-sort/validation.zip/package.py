from pathlib import Path
import json,sys,subprocess,hashlib,zipfile,re,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
proof=[];checks=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,sha256=digest(p)))
 for label in ['nvidia','intel']:
  xml=ET.parse(out/(config+'-'+label+'.xml')).getroot()
  for case in xml.findall('testcase'):
   assert case.attrib['status']=='run' and case.find('failure') is None
   output=case.findtext('system-out') or ''
   if case.attrib['name'].endswith('Gpu'):
    assert 'records=22325' in output and 'validationErrors=0 liveBuffers=0 liveImages=0' in output
   checks.append(dict(configuration=config,label=label,name=case.attrib['name'],seconds=case.attrib['time'],output=output.strip()))
assert len(checks)==6
prior=json.loads((out.parent/'20261108-093510-surface-lighting-reuse-3223fa/baseline.json').read_text());unchangedPrograms={}
for config,products in prior['products'].items():
 programs={name:sha for name,sha in products.items() if name.endswith('.spv') and Path(name).parent.name=='shaders'};assert len(programs)==665
 assert all(digest(Path(name))==sha for name,sha in programs.items());unchangedPrograms[config]=len(programs)
boundaries=json.loads((out/'module-boundaries.json').read_text());assert boundaries['status']=='passed' and not boundaries['violations']
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/gpu-stable-key-sort';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.json','.log','.xml']}
sourceNames=['src/render/GpuStableKeySort.hpp','src/render/GpuStableKeySort.cpp','shaders/stable_key_sort.comp','tests/GpuStableKeySortTests.cpp','tests/GpuStableKeySortGpuTests.cpp']
for name in sourceNames:members['source/'+name]=root/name
for config in ['release','debug']:members['program/'+config+'.spv']=root/f'build/ninja-msvc-{config}/shaders/stable_key_sort.comp.spv'
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='bounded-stable-sort-mechanism-ready-integration-pending',sourceBase='16f6f18',sourceHashes={name:digest(root/name) for name in sourceNames},checks=checks,unchangedPrograms=unchangedPrograms,moduleBoundaries=boundaries,productionProvenance=proof,userDiffSha256=protected,sourceInputs=inputs(root),sceneIntegrated=False,nativeBatchStarted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package))
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest=root/'docs/development/artifact-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'));data['milestones']=[m for m in data['milestones'] if m['path']!='runs/'+out.name];data['milestones'].insert(0,dict(path='runs/'+out.name,name='GPU 分段稳定排序机制',status='MechanismReadyIntegrationPending',sourceBase='16f6f18',evidence='docs/acceptance/nr/gpu-stable-key-sort.md',checksPassed=6,sceneIntegrated=False));manifest.write_text(json.dumps(data,indent=2,ensure_ascii=False).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md']:
 p=root/name;text=p.read_text(encoding='utf-8');start=text.index('cpu-preparation-batch.md)');end=text.index('\n',start)
 line='[GPU 稳定排序机制]('+('docs/acceptance/nr/' if name=='README.md' else '../acceptance/nr/')+'gpu-stable-key-sort.md)通过六项双配置、双设备检查，透明场景集成继续实施。\n'
 if line not in text:p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-transparent-deformation-plan.md','docs/acceptance/nr/gpu-stable-key-sort.md','docs/development/gpu-stable-key-sort.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],checks=len(checks),evidenceBytes=package.stat().st_size,userDiffPreserved=True)))
