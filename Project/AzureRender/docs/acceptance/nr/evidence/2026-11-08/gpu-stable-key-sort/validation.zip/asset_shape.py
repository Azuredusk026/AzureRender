from pathlib import Path
import json,struct,collections
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
lock=json.loads((out.parent/'20261107-171836-consolidated-preparation-images-374280/image/frozen-inputs.json').read_text())['project']
rows=[]
for name,sha in lock.items():
 p=Path(name)
 if p.suffix.lower()!='.glb':continue
 with p.open('rb') as f:
  header=f.read(20);magic,version,size,jsonSize,kind=struct.unpack('<5I',header);assert magic==0x46546c67 and kind==0x4e4f534a
  data=json.loads(f.read(jsonSize))
 ranges=[];vertexCount=0
 for mesh in data.get('meshes',[]):
  for prim in mesh.get('primitives',[]):
   vertices=data['accessors'][prim['attributes']['POSITION']]['count'];vertexCount+=vertices
   if prim.get('targets'):ranges.append(dict(vertices=vertices,targets=len(prim['targets']),weights=mesh.get('weights',[])))
 rows.append(dict(path=name,sha256=sha,nodes=len(data.get('nodes',[])),animations=len(data.get('animations',[])),skins=len(data.get('skins',[])),vertices=vertexCount,ranges=ranges))
(out/'asset-shapes.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(dict(glbs=len(rows),morphGlbs=[r for r in rows if r['ranges']]),ensure_ascii=False),flush=True)
