from pathlib import Path
import json,os,subprocess,time,numpy as np,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;model=out.parent/'20261108-041637-object-receiver-origin-7a2735';sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
source=inputs(root);shader=(model/'receiver-compiled.comp').read_text();shader=shader.replace('results.v[index*4+2]=vec4(q,delta);','results.v[index*4+2]=h;').replace('results.v[index*4+3]=vec4(uv,roundEven(visible*255),weight);','results.v[index*4+3]=vec4(1/h.w,ndc.x,roundEven(visible*255),weight);')
(out/'homogeneous-probe.comp').write_text(shader)
command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe',str(out/'homogeneous-probe.comp'),'-o',str(out/'receiver.spv')];r=subprocess.run(command,cwd=root,capture_output=True,text=True);assert r.returncode==0,r.stderr
validation=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(out/'receiver.spv')];r=subprocess.run(validation,cwd=root,capture_output=True,text=True);assert r.returncode==0,r.stderr
(out/'probe-build.json').write_text(json.dumps(dict(compile=command,validation=validation,shaderSha256=digest(out/'receiver.spv'),fields=dict(homogeneous=[8,9,10,11],reciprocal=12,ndcX=13,quantizedVisibility=14)),indent=2))
config=json.loads((model/'gpu-inputs.json').read_text());config['queryBinary']=str(model/'region-queries.bin');config['expectedBinary']=str(model/'region-expected.bin')
rows=[]
for label,driver,baseline in [('nvidia','*nv-vk64*',model/'region-output.bin'),('intel','*igvk64*',out.parent/'20261108-045252-screen-object-visibility-ca2907/intel-probe-output.bin')]:
 config['resultPrefix']=label+'-';(out/'gpu-inputs.json').write_text(json.dumps(config,indent=2));env=os.environ.copy();env.update(TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'),VK_LOADER_DRIVERS_SELECT=driver)
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
 command=[str(model/'receiver.exe'),str(out)];start=time.monotonic()
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 result=json.loads((out/(label+'-result.json')).read_text());assert result['validationErrors']==0 and result['zeroAllocator']
 actual=np.fromfile(out/(label+'-output.bin'),dtype='<f4').reshape(-1,16);old=np.fromfile(baseline,dtype='<f4').reshape(-1,16)
 rows.append(dict(device=label,command=command,exitCode=r.returncode,seconds=time.monotonic()-start,worldsUnchanged=int(np.all(actual[:,:3]==old[:,:3],axis=1).sum()),visibilitiesUnchanged=int((actual[:,3]==old[:,3]).sum()),pixels=len(actual),validationErrors=result['validationErrors'],zeroAllocator=result['zeroAllocator']))
 print(json.dumps(rows[-1]),flush=True)
assert inputs(root)==source
(out/'probe-execution.json').write_text(json.dumps(rows,indent=2))
