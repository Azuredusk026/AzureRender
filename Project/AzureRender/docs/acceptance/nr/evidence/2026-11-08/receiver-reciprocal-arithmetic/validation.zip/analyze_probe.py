from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent;source=out.parent/'20261027-022702-object-visibility-depth-reconstruction-c7312f';model=out.parent/'20261108-041637-object-receiver-origin-7a2735'
c0=np.fromfile(source/'producer-cb0.bin',dtype='<f4').reshape(-1,4);c1=np.fromfile(source/'producer-cb1.bin',dtype='<f4').reshape(-1,4);query=np.fromfile(model/'region-queries.bin',dtype='<f4').reshape(-1,4)
def fma(a,b,c):return (np.asarray(a,dtype='f8')*np.asarray(b,dtype='f8')+np.asarray(c,dtype='f8')).astype('<f4')
hReference=np.fromfile(out/'homogeneous-reference.bin',dtype='<f4').reshape(-1,4);nv=np.fromfile(out/'nvidia-output.bin',dtype='<f4').reshape(-1,16);intel=np.fromfile(out/'intel-output.bin',dtype='<f4').reshape(-1,16)
report={}
for name,data in [('nvidia',nv),('intel',intel)]:
 h=data[:,8:12];reciprocal=data[:,12];rn=(1/h[:,3].astype('f8')).astype('<f4');refined=fma(fma(-h[:,3],reciprocal,np.float32(1)),reciprocal,reciprocal)
 product=(h[:,:3]*reciprocal[:,None]).astype('<f4');rnProduct=(h[:,:3]*rn[:,None]).astype('<f4');division=(h[:,:3].astype('f8')/h[:,3,None].astype('f8')).astype('<f4')
 ulp=reciprocal.view('<i4').astype('i8')-rn.view('<i4').astype('i8')
 report[name]=dict(hExactComponentsVsCpu=(h==hReference).sum(0).tolist(),hMaxErrorVsCpu=np.abs(h.astype('f8')-hReference).max(0).tolist(),reciprocalRnExact=int((reciprocal==rn).sum()),reciprocalRnUlpHistogram={str(int(v)):int((ulp==v).sum()) for v in np.unique(ulp)},refinedReciprocalRnExact=int((refined==rn).sum()),worldFromStoredReciprocalExact=int(np.all(product==data[:,:3],axis=1).sum()),worldFromRnReciprocalExact=int(np.all(rnProduct==data[:,:3],axis=1).sum()),worldFromRnDivisionExact=int(np.all(division==data[:,:3],axis=1).sum()))
report['deviceDifference']=dict(hExactComponents=(nv[:,8:12]==intel[:,8:12]).sum(0).tolist(),hMaxError=np.abs(nv[:,8:12].astype('f8')-intel[:,8:12]).max(0).tolist(),reciprocalExact=int((nv[:,12]==intel[:,12]).sum()))
(out/'probe-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
