from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent;source=out.parent/'20261027-022702-object-visibility-depth-reconstruction-c7312f';model=out.parent/'20261108-041637-object-receiver-origin-7a2735';intel=out.parent/'20261108-045252-screen-object-visibility-ca2907'
c0=np.fromfile(source/'producer-cb0.bin',dtype='<f4').reshape(-1,4);c1=np.fromfile(source/'producer-cb1.bin',dtype='<f4').reshape(-1,4);queries=np.fromfile(model/'region-queries.bin',dtype='<f4').reshape(-1,4)
def fma(a,b,c):return (np.asarray(a,dtype='f8')*np.asarray(b,dtype='f8')+np.asarray(c,dtype='f8')).astype('<f4')
ndc=fma((queries[:,:2]*c1[0,2:4]).astype('<f4'),np.float32(2),np.float32(-1))
h=fma(c0[24],ndc[:,0,None],(-ndc[:,1,None]*c0[25]).astype('<f4'));h=fma(c0[26],queries[:,2,None],h);h=(h+c0[27]).astype('<f4')
reciprocal=(1/h[:,3].astype('f8')).astype('<f4');residual=fma(-h[:,3],reciprocal,np.float32(1));refined=fma(residual,reciprocal,reciprocal)
worlds={'divisionRN':(h[:,:3].astype('f8')/h[:,3,None].astype('f8')).astype('<f4'),'reciprocalMulRN':(h[:,:3]*reciprocal[:,None]).astype('<f4'),'refinedReciprocalMul':(h[:,:3]*refined[:,None]).astype('<f4')}
report=dict(pixels=len(queries),hWRange=[float(h[:,3].min()),float(h[:,3].max())],reciprocalRefinementChanged=int((reciprocal!=refined).sum()),comparisons={})
for label,path in [('nvidia',model/'region-output.bin'),('intel',intel/'intel-probe-output.bin'),('intelPrecise',intel/'intel-precise-output.bin')]:
 actual=np.fromfile(path,dtype='<f4').reshape(-1,16)[:,:3]
 for method,world in worlds.items():
  error=world.astype('f8')-actual
  report['comparisons'][label+'-'+method]=dict(exactWorlds=int(np.all(world==actual,axis=1).sum()),exactComponents=int((world==actual).sum()),maximumComponentError=float(abs(error).max()),medianWorldError=float(np.median(np.linalg.norm(error,axis=1))))
h.tofile(out/'homogeneous-reference.bin');worlds['reciprocalMulRN'].tofile(out/'reciprocal-world-reference.bin');(out/'world-reference.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
root=out.parents[2];(root/'build/maintenance/storage-work-priority.json').write_text(json.dumps(dict(activeTask='receiver-reciprocal-arithmetic',status='source-attribution',performanceTask=str(out.relative_to(root)),storageCommit='d0778a4',projectDataVolume='D:',maintenanceUnit='day'),indent=2)+'\n')
