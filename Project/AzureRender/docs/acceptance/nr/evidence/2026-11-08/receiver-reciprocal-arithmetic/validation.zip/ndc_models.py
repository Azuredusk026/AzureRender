from pathlib import Path
import numpy as np,json,itertools
out=Path(__file__).resolve().parent
source=out.parent/'20261027-022702-object-visibility-depth-reconstruction-c7312f'
model=out.parent/'20261108-041637-object-receiver-origin-7a2735'
c0=np.fromfile(source/'producer-cb0.bin',dtype='<f4').reshape(-1,4)
c1=np.fromfile(source/'producer-cb1.bin',dtype='<f4').reshape(-1,4)
query=np.fromfile(model/'region-queries.bin',dtype='<f4').reshape(-1,4)
gpu=np.fromfile(out/'intel-output.bin',dtype='<f4').reshape(-1,16)
def fma(a,b,c):return (np.asarray(a,dtype='f8')*np.asarray(b,dtype='f8')+np.asarray(c,dtype='f8')).astype('<f4')
ndc={
 'separate':fma(query[:,:2]*c1[0,2:4],np.float32(2),np.float32(-1)),
 'contracted':fma(query[:,:2],c1[0,2:4]*np.float32(2),np.float32(-1)),
 'unfused':((query[:,:2]*c1[0,2:4])*np.float32(2)-np.float32(1)).astype('<f4')}
result={}
for name,n in ndc.items():
 h=fma(c0[24],n[:,0,None],-n[:,1,None]*c0[25])
 h=fma(c0[26],query[:,2,None],h);h=(h+c0[27]).astype('<f4')
 result[name]=dict(ndcXExact=int((n[:,0]==gpu[:,13]).sum()),hExactComponents=(h==gpu[:,8:12]).sum(0).tolist(),hExactVectors=int(np.all(h==gpu[:,8:12],axis=1).sum()))
(out/'ndc-models.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
