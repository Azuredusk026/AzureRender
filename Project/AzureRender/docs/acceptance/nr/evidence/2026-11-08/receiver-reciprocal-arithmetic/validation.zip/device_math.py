from pathlib import Path
import subprocess,os,json,re,numpy as np,itertools
out=Path(__file__).resolve().parent;root=out.parents[2];model=out.parent/'20261108-041637-object-receiver-origin-7a2735';source=out.parent/'20261027-022702-object-visibility-depth-reconstruction-c7312f'
env=os.environ.copy();env.update(TEMP=str(root/'build/maintenance/test-tmp'),TMP=str(root/'build/maintenance/test-tmp'),VK_LOADER_DRIVERS_SELECT='*igvk64*')
command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/vulkaninfoSDK.exe']
with (out/'intel-vulkaninfo.txt').open('wb') as stdout,(out/'intel-vulkaninfo-errors.log').open('wb') as stderr:r=subprocess.run(command,cwd=out,env=env,stdout=stdout,stderr=stderr,timeout=60)
assert r.returncode==0
text=(out/'intel-vulkaninfo.txt').read_text(errors='replace');features={name:re.findall(r'\b'+name+r'\s*=\s*(\w+)',text) for name in ['shaderFloat64','shaderInt64','shaderRoundingModeRTEFloat32','shaderFloatControls2']}
c0=np.fromfile(source/'producer-cb0.bin',dtype='<f4').reshape(-1,4);c1=np.fromfile(source/'producer-cb1.bin',dtype='<f4').reshape(-1,4);q=np.fromfile(model/'region-queries.bin',dtype='<f4').reshape(-1,4);gpu=np.fromfile(out/'intel-output.bin',dtype='<f4').reshape(-1,16)
def fused(a,b,c):return (np.asarray(a,dtype='f8')*np.asarray(b,dtype='f8')+np.asarray(c,dtype='f8')).astype('<f4')
def unfused(a,b,c):return ((a*b).astype('<f4')+c).astype('<f4')
ndc=fused(q[:,:2]*c1[0,2:4],np.float32(2),np.float32(-1));models={}
for a,b in itertools.product(['fused','unfused'],repeat=2):
 first=(fused if a=='fused' else unfused)(c0[24],ndc[:,0,None],-ndc[:,1,None]*c0[25]);h=(fused if b=='fused' else unfused)(c0[26],q[:,2,None],first);h=(h+c0[27]).astype('<f4')
 models[a+'-'+b]=dict(exactComponents=(h==gpu[:,8:12]).sum(0).tolist(),exactVectors=int(np.all(h==gpu[:,8:12],axis=1).sum()))
result=dict(command=command,features=features,intelHomogeneousModels=models);(out/'device-math.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)

