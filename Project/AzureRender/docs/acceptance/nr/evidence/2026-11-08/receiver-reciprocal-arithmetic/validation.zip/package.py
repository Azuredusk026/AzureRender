from pathlib import Path
import json,hashlib,sys,subprocess,zipfile,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
proof=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,sha256=digest(p)))
execution=json.loads((out/'probe-execution.json').read_text())
assert all(row['worldsUnchanged']==17017 and row['visibilitiesUnchanged']==17017 and row['validationErrors']==0 and row['zeroAllocator'] for row in execution)
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/receiver-reciprocal-arithmetic';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.json','.log','.comp','.bin','.spv']}
model=out.parent/'20261108-041637-object-receiver-origin-7a2735';source=out.parent/'20261027-022702-object-visibility-depth-reconstruction-c7312f'
for name in ['region-queries.bin','region-output.bin']:members['borrowed/'+name]=model/name
for name in ['producer-cb0.bin','producer-cb1.bin']:members['borrowed/'+name]=source/name
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='homogeneous-and-reciprocal-differences-attributed',sourceBase='1d47d65',execution=execution,arithmetic=json.loads((out/'probe-analysis.json').read_text()),worldReference=json.loads((out/'world-reference.json').read_text()),deviceMath=json.loads((out/'device-math.json').read_text()),ndcModels=json.loads((out/'ndc-models.json').read_text()),productionProvenance=proof,userDiffSha256=protected,candidateAdopted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=n,bytes=p.stat().st_size,sha256=digest(p)) for n,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest=root/'docs/development/artifact-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'));data['milestones']=[m for m in data['milestones'] if m['path']!='runs/'+out.name];data['milestones'].insert(0,dict(path='runs/'+out.name,name='接收运算精度核验',status='ArithmeticDifferencesAttributed',sourceBase='1d47d65',evidence='docs/acceptance/nr/receiver-reciprocal-arithmetic.md',candidateAdopted=False,formalPerformancePassed=False));manifest.write_text(json.dumps(data,indent=2,ensure_ascii=False).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md']:
 p=root/name;text=p.read_text(encoding='utf-8');start=text.index('[顶点精度核对]');end=text.index('\n',start)
 line='[接收运算核对]('+('docs/acceptance/nr/' if name=='README.md' else '../acceptance/nr/')+'receiver-reciprocal-arithmetic.md)区分齐次计算及倒数误差，兼容实现继续待验收。\n'
 if line not in text:p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-receiver-reciprocal-arithmetic.md','docs/acceptance/nr/receiver-reciprocal-arithmetic.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],evidenceBytes=package.stat().st_size,userDiffPreserved=True)))
