from pathlib import Path
import json,os,time,traceback,struct,math,hashlib
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261108-143637-snapshot-shared-occlusion-0435de';source=out.parent/'20261108-111838-gpu-draw-stage-cost-4bb6b2'
analysis=json.loads((source/'analysis.json').read_text());bounds=json.loads((source/'bounds.json').read_text());profile=json.loads((out.parent/'20261107-122133-material-contribution-cost-c567b5/profile.json').read_text())
byEvent={row['event']:row for row in profile['rows']};selected={row['event']:row['category'] for row in analysis['rows'] if row['category'] in ['main-ordinary-early','snapshot-ordinary-early']}
firstSnapshot=min(row['event'] for row in analysis['rows'] if row['category'].startswith('snapshot-'));firstMain=min(row['event'] for row in analysis['rows'] if row['category'].startswith('main-'))
for row in profile['rows']:
 if row['fragment']=='ResourceId::0' or (row.get('program') or '').startswith('character_snapshot_depth'):
  if row['renderPass']=='ResourceId::10055' and row['event']<firstSnapshot:selected[row['event']]='snapshot-prefill'
  if row['renderPass']=='ResourceId::209' and row['event']<firstMain:selected[row['event']]='main-prefill'
cap=None;c=None;started=time.monotonic();report=dict(status='starting')
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(out.parent/'20261107-120731-uniform-texture-index-capture-4c96ea/current_frame320.rdc'),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 c.SetFrameEvent(firstSnapshot-1,True);pipe=c.GetPipelineState();target=pipe.GetDepthTarget().resource;viewport=pipe.GetViewport(0)
 texture=next(t for t in c.GetTextures() if t.resourceId==target);assert texture.format.compCount==1 and texture.format.compByteWidth==4
 raw=bytes(c.GetTextureData(target,rd.Subresource()));assert len(raw)==texture.width*texture.height*4
 (out/'snapshot-prefill-depth.f32').write_bytes(raw);depth=struct.unpack('<'+'f'*(len(raw)//4),raw)
 coverage=[]
 for row in bounds['rows']:
  b=row['ndcBounds'];result=dict(event=row['event'],outsideFrustum=row['outsideFrustum'],snapshotDepthOccluded=False)
  if b and not row['outsideFrustum']:
   xs=sorted(viewport.x+(b[a]*.5+.5)*viewport.width for a in [0,3]);ys=sorted(viewport.y+(b[a]*.5+.5)*viewport.height for a in [1,4])
   x0=max(0,int(math.floor(xs[0]))-1);x1=min(texture.width,int(math.ceil(xs[1]))+1);y0=max(0,int(math.floor(ys[0]))-1);y1=min(texture.height,int(math.ceil(ys[1]))+1)
   if x1>x0 and y1>y0 and 0<=b[2]<=b[5]<=1:
    farthest=max(depth[y*texture.width+x] for y in range(y0,y1) for x in range(x0,x1));result.update(rect=[x0,y0,x1,y1],nearestDepth=b[2],farthestOccluder=farthest,snapshotDepthOccluded=b[2]-1e-5>farthest)
  coverage.append(result)
 actions={}
 def walk(items):
  for action in items:actions[action.eventId]=action;walk(action.children)
 walk(c.GetRootActions());rows=[]
 for event,category in sorted(selected.items()):
  c.SetFrameEvent(event,True);state=c.GetPipelineState();vk=c.GetVulkanPipelineState();action=actions[event]
  vertices=state.GetVBuffers();indices=state.GetIBuffer();assert vertices
  v=vertices[0];data=bytes(vk.pushconsts);assert len(data)>=144
  assert getattr(action,'baseVertex',0)==0
  key=[str(v.resourceId),v.byteOffset,v.byteStride,str(indices.resourceId),indices.byteOffset,indices.byteStride,action.indexOffset,action.numIndices,action.instanceOffset,action.numInstances]
  rows.append(dict(event=event,category=category,key=key,features=struct.unpack_from('<I',data,116)[0],materialClass=struct.unpack_from('<I',data,112)[0],nodeOpacity=struct.unpack_from('<f',data,140)[0],program=byEvent[event].get('program')))
  if len(rows)%100==0:(out/'read-progress.json').write_text(json.dumps(dict(completed=len(rows),total=len(selected),event=event,seconds=time.monotonic()-started)))
 report=dict(status='read',seconds=time.monotonic()-started,rows=rows,coverage=coverage,depth=dict(event=firstSnapshot-1,target=str(target),width=texture.width,height=texture.height,format=str(texture.format.Name()),sha256=hashlib.sha256(raw).hexdigest()),newGpuTimingExecuted=False)
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'shared-scope.json').write_text(json.dumps(report,indent=2));os._exit(0 if report['status']=='read' else 1)
