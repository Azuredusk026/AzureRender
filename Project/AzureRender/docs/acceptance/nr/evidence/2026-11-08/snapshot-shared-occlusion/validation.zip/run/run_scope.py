from pathlib import Path
import subprocess,os,sys,json,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
before=inputs(root);capture=out.parent/'20261107-120731-uniform-texture-index-capture-4c96ea/current_frame320.rdc';sha=digest(capture);assert sha=='5cbfc0ecf9fa24a7a8d8949ed54c3fc3691b7a1a58075d68f63f257b34ca6942'
temporary=out/'tmp';temporary.mkdir(exist_ok=True);env=os.environ.copy();env.update(TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary),VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'read_scope.py')];started=time.monotonic()
with (out/'scope.log').open('wb') as log:r=subprocess.run(command,cwd=out,env=env,startupinfo=si,stdout=log,stderr=subprocess.STDOUT,timeout=240)
result=json.loads((out/'shared-scope.json').read_text());receipt=dict(exitCode=r.returncode,status=result['status'],seconds=time.monotonic()-started,sourceInputsUnchanged=inputs(root)==before,captureSha256=sha,captureUnchanged=digest(capture)==sha,newGpuTimingExecuted=False,command=command)
(out/'scope-execution.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True);print(result.get('error',''))
assert all(receipt[k] for k in ['sourceInputsUnchanged','captureUnchanged']) and r.returncode==0
