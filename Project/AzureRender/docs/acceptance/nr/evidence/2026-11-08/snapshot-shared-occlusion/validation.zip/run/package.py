from pathlib import Path
import json,sys,hashlib,zipfile,subprocess,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest,verify
analysis=json.loads((out/'eligibility.json').read_text());data=json.loads((out/'shared-scope.json').read_text());execution=json.loads((out/'scope-execution.json').read_text())
assert analysis['status']=='incremental-scope-below-admission' and analysis['optimisticIncrementalUpperFraction']<.2
assert len(data['rows'])==1439 and not analysis['snapshotUnsafePrefillRows'] and not analysis['completeSpanNonzeroPixelConflicts']
assert execution['sourceInputsUnchanged'] and execution['captureUnchanged'] and not execution['newGpuTimingExecuted']
proof=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,sha256=digest(p)))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
user=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)).hexdigest();assert user=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
sources=inputs(root);identity=hashlib.sha256(json.dumps(sources,sort_keys=True).encode()).hexdigest()
members={'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.json','.log','.f32']}
for source in ['20261108-111838-gpu-draw-stage-cost-4bb6b2/bounds.json','20261107-135517-replay-continuity-check-ceda91/control-state.json']:
 members['reference/'+source]=out.parent/source
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/snapshot-shared-occlusion';evidence.mkdir(parents=True,exist_ok=True);package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
summary={k:v for k,v in analysis.items() if k!='qualifiedEventCosts'}
report=dict(schemaVersion=1,status='incremental-scope-below-admission',sourceBase='27d2160',analysis=summary,execution=execution,rowsRead=1439,sourceInputMapSha256=identity,productionProvenance=proof,userDiffSha256=user,productionRuntimeUnchanged=True,candidateImplemented=False,nativeTestsStarted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package))
(evidence/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=root/'docs/development/artifact-manifest.json';m=json.loads(p.read_text());m['milestones']=[r for r in m['milestones'] if r['path']!='runs/'+out.name];m['milestones'].insert(0,dict(path='runs/'+out.name,name='多阶段遮挡消费范围',status='IncrementalScopeBelowAdmission',sourceBase='27d2160',evidence='docs/acceptance/nr/snapshot-shared-occlusion.md',candidateImplemented=False,incrementalUpperMs=analysis['optimisticIncrementalUpperMs'],newGpuTimingExecuted=False));p.write_text(json.dumps(m,ensure_ascii=False,indent=2).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-snapshot-shared-occlusion.md','docs/acceptance/nr/snapshot-shared-occlusion.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],rowsRead=1439,incrementalUpperMs=analysis['optimisticIncrementalUpperMs'],evidenceBytes=package.stat().st_size,userDiffPreserved=True)))
