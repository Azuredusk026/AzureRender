from pathlib import Path
import json,collections
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;runs=out.parent
data=json.loads((out/'shared-scope.json').read_text());assert data['status']=='read'
timing=json.loads((runs/'20261107-135517-replay-continuity-check-ceda91/control-state.json').read_text());control=next(r for r in timing['timings'] if r['control']=='surface-shadow')
def cost(event):return (control['baselineBefore'][str(event)]+control['baselineAfter'][str(event)])/2
analysis=json.loads((runs/'20261108-111838-gpu-draw-stage-cost-4bb6b2/analysis.json').read_text());stats={row['event']:row for row in analysis['rows']}
groups=collections.defaultdict(list)
for row in data['rows']:groups[row['category']].append(row)
main={row['event']:row for row in groups['main-ordinary-early']}
candidate=[row for row in data['coverage'] if row['snapshotDepthOccluded'] or row['outsideFrustum']]
keys={tuple(main[row['event']]['key']) for row in candidate}
allMainKeys={tuple(row['key']) for row in main.values()}
extra={category:[row for row in groups[category] if tuple(row['key']) in keys] for category in ['snapshot-ordinary-early','main-prefill']}
def geometry(key):return tuple(key[:3]+[key[3],key[5],key[4]+key[6]*key[5],key[7]])
culledInstances=collections.defaultdict(set)
for key in keys:
 assert key[9]==1
 culledInstances[geometry(list(key))].add(key[8])
spanExtra={}
spanConflicts=[]
for category in ['snapshot-ordinary-early','main-prefill']:
 complete=[];partial=[]
 for row in groups[category]:
  key=row['key'];known=culledInstances[geometry(key)];hits=sum(i in known for i in range(key[8],key[8]+key[9]))
  if hits and hits==key[9]:complete.append(row)
  elif hits:partial.append(row)
 spanExtra[category]=dict(completeEvents=len(complete),completeCostMs=sum(cost(r['event']) for r in complete),partialEvents=len(partial),partialWholeDrawCostMs=sum(cost(r['event']) for r in partial))
 if category=='snapshot-ordinary-early':spanConflicts.extend(dict(event=r['event'],pixelInvocations=stats[r['event']]['pixelInvocations']) for r in complete if stats[r['event']]['pixelInvocations'])
mainPrefill=[row for row in groups['main-prefill'] if tuple(row['key']) in allMainKeys]
targetRows=groups['main-ordinary-early']+groups['snapshot-ordinary-early']+mainPrefill
targetCost=sum(cost(row['event']) for row in targetRows);incremental=sum(cost(row['event']) for rows in extra.values() for row in rows)
unsafe=[row for row in groups['snapshot-prefill'] if row['features']&((1<<8)|(1<<15))]
conflicts=[dict(event=row['event'],pixelInvocations=stats[row['event']]['pixelInvocations']) for row in extra['snapshot-ordinary-early'] if stats[row['event']]['pixelInvocations']]
knownTotal=sum((value+control['baselineAfter'][event])/2 for event,value in control['baselineBefore'].items())
perStage={category:dict(events=len(rows),baselineMs=sum(cost(row['event']) for row in rows),candidateEvents=sum(tuple(row['key']) in keys for row in rows),candidateCostMs=sum(cost(row['event']) for row in rows if tuple(row['key']) in keys)) for category,rows in groups.items()}
report=dict(status='scope-admitted' if not unsafe and not conflicts and targetCost/knownTotal>=.25 and incremental/targetCost>=.2 else 'incremental-scope-below-admission',captureSha256='5cbfc0ecf9fa24a7a8d8949ed54c3fc3691b7a1a58075d68f63f257b34ca6942',stages=perStage,depth=data['depth'],snapshotUnsafePrefillEvents=len(unsafe),snapshotUnsafePrefillRows=unsafe,occludedMainCandidates=sum(r['snapshotDepthOccluded'] for r in data['coverage']),frustumOutsideMainCandidates=sum(r['outsideFrustum'] for r in data['coverage']),snapshotNonzeroPixelConflicts=conflicts,targetGroupBaselineMs=targetCost,recordedEventTotalMs=knownTotal,targetGroupShare=targetCost/knownTotal,incrementalPotentialMs=incremental,incrementalPotentialFraction=incremental/targetCost,extraStages={k:dict(events=len(v),baselineMs=sum(cost(r['event']) for r in v)) for k,v in extra.items()},existingMainColorGainNotCountedAsIncremental=True,scope='Historical qualified per-event durations and exact draw binding keys; source is pre-snapshot-color depth. Costs are upper bounds; production static qualification and hierarchy overhead remain separate.',newGpuTimingExecuted=False,nativeSceneTestsStarted=False,formalPerformancePassed=False)
optimistic=sum(r['completeCostMs']+r['partialWholeDrawCostMs'] for r in spanExtra.values());report.update(instanceSpanCorrespondence=spanExtra,optimisticIncrementalUpperMs=optimistic,optimisticIncrementalUpperFraction=optimistic/targetCost)
report['completeSpanNonzeroPixelConflicts']=spanConflicts
report['qualifiedEventCosts']={str(row['event']):dict(beforeMs=control['baselineBefore'][str(row['event'])],afterMs=control['baselineAfter'][str(row['event'])],meanMs=cost(row['event'])) for row in data['rows']}
report['status']='scope-admitted' if not unsafe and not conflicts and targetCost/knownTotal>=.25 and optimistic/targetCost>=.2 else 'incremental-scope-below-admission'
(out/'eligibility.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
