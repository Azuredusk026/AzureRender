from pathlib import Path
import json,collections,struct
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;runs=out.parent
profile=json.loads((runs/'20261107-122133-material-contribution-cost-c567b5/profile.json').read_text())
timing=json.loads((runs/'20261107-135517-replay-continuity-check-ceda91/control-state.json').read_text())
control=next(r for r in timing['timings'] if r['control']=='surface-shadow')
scope=json.loads((out/'scope-analysis.json').read_text());events={e for r in scope['groups'] for e in r['events']}
specializations=json.loads((out/'pipeline-specialization.json').read_text())['applied']
states={}
for pipeline,value in specializations.items():
 variables=[v for b in value['blocks'] for v in b['variables']];assert len(variables)==len(value['specializationIds'])
 data=bytes.fromhex(value['dataHex']);constants={str(key):struct.unpack_from('<I',data,var['byteOffset'])[0] for key,var in zip(value['specializationIds'],variables)}
 states[pipeline]=dict(constants=constants,ordinary=constants.get('0',0)!=0,materialClass=constants.get('1',0xffffffff))
groups=collections.defaultdict(lambda:dict(events=[],baselineMs=0.,candidateMs=0.));eligible=[]
for row in profile['rows']:
 if row['event'] not in events:continue
 event=str(row['event']);program=row['program'];state=states[row['pipeline']]
 snapshot=program.startswith('character_snapshot');early='_early' in program
 category=('snapshot-' if snapshot else 'main-')+('ordinary-' if state['ordinary'] else 'class-')+('early' if early else 'other')
 entry=groups[category];entry['events'].append(row['event'])
 b=(control['baselineBefore'][event]+control['baselineAfter'][event])/2;c=sum(t[event] for t in control['candidate'])/len(control['candidate'])
 entry['baselineMs']+=b;entry['candidateMs']+=c
 if not snapshot and state['ordinary'] and early:eligible.append(dict(event=row['event'],baselineMs=b,candidateMs=c,pipeline=row['pipeline'],program=program))
rows=[]
for name,g in groups.items():g.update(category=name,savedMs=g['baselineMs']-g['candidateMs']);rows.append(g)
rows.sort(key=lambda r:r['savedMs'],reverse=True)
main=[r for r in rows if r['category'].startswith('main')]
eligibleSaved=sum(r['baselineMs']-r['candidateMs'] for r in eligible)
report=dict(captureSha256=scope['captureSha256'],width=1280,height=720,scope='captured-pipeline-specialization-qualified-ablation-subtotals',groups=rows,pipelineStates=states,ordinaryEarlyMainEvents=len(eligible),ordinaryEarlyMainAblationSavedMs=eligibleSaved,allMatchedSavedMs=scope['summary']['savedMatchedMs'],allMainAblationSavedMs=sum(r['savedMs'] for r in main),allMainBaselineMs=sum(r['baselineMs'] for r in main),eligibleEvents=eligible,surfaceCacheMatchingNotObserved=True,bandwidthCostNotMeasured=True,newGpuTimingExecuted=False)
(out/'eligibility-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['groups','pipelineStates','eligibleEvents']}));print(json.dumps([dict(category=r['category'],events=len(r['events']),baselineMs=r['baselineMs'],savedMs=r['savedMs']) for r in rows]))
