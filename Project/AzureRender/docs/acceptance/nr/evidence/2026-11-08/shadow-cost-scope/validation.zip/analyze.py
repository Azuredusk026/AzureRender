from pathlib import Path
from collections import defaultdict
import json,hashlib,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;runs=out.parent
profilePath=runs/'20261107-122133-material-contribution-cost-c567b5/profile.json'
timingPath=runs/'20261107-135517-replay-continuity-check-ceda91/control-state.json'
buildsPath=runs/'20261107-122133-material-contribution-cost-c567b5/control-builds.json'
profile=json.loads(profilePath.read_text());timing=json.loads(timingPath.read_text());files={r['file'] for r in json.loads(buildsPath.read_text())}
assert timing['status']=='measured'
control=next(r for r in timing['timings'] if r['control']=='surface-shadow')
summary=next(r for r in timing['summary'] if r['control']=='surface-shadow');assert summary['bracketStable']
groups=defaultdict(lambda:dict(events=[],baselineMs=0.,candidateMs=0.))
for row in profile['rows']:
 if row['program'] not in files:continue
 event=str(row['event']);entry=groups[row['program']];entry['events'].append(row['event'])
 entry['baselineMs']+=(control['baselineBefore'][event]+control['baselineAfter'][event])/2
 entry['candidateMs']+=sum(t[event] for t in control['candidate'])/len(control['candidate'])
result=[]
for name,g in groups.items():
 g.update(program=name,savedMs=g['baselineMs']-g['candidateMs'],snapshot='_depth' in name or 'snapshot' in name)
 g['reduction']=1-g['candidateMs']/g['baselineMs'];result.append(g)
result.sort(key=lambda r:r['savedMs'],reverse=True)
assert sum(len(g['events']) for g in result)==1009
assert abs(sum(g['baselineMs'] for g in result)-summary['baselineMatchedMs'])<1e-9
assert abs(sum(g['savedMs'] for g in result)-summary['savedMatchedMs'])<1e-9
report=dict(scope='existing-qualified-output-changing-ablation',captureSha256=profile['captureSha256'],summary=summary,groups=result,inputs=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [profilePath,timingPath,buildsPath]],nativeBatchStarted=False,newGpuTimingExecuted=False)
(out/'scope-analysis.json').write_text(json.dumps(report,indent=2))
print(json.dumps([dict(program=r['program'],events=len(r['events']),baselineMs=r['baselineMs'],savedMs=r['savedMs'],reduction=r['reduction']) for r in result]),flush=True)
