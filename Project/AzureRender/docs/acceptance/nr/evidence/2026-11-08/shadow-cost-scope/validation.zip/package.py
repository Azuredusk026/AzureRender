from pathlib import Path
import json,hashlib,sys,subprocess,zipfile,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify
proof=[]
for config in ['release','debug']:
 p=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(p.read_text()));proof.append(dict(configuration=config,sha256=digest(p)))
analysis=json.loads((out/'scope-analysis.json').read_text());eligibility=json.loads((out/'eligibility-analysis.json').read_text());specialization=json.loads((out/'pipeline-specialization.json').read_text());assert specialization['status']=='read' and len(specialization['applied'])==35
assert sum(len(r['events']) for r in eligibility['groups'])==1009
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/shadow-cost-scope';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.json','.log']}
for r in analysis['inputs']:
 p=Path(r['path']);assert digest(p)==r['sha256'];members['borrowed/'+p.parent.name+'/'+p.name]=p
legacy=out.parent/'20261107-030141-shadow-visibility-reuse-90fb90/candidate-source/src/scenes/CharacterMaterialSampling.inc';members['borrowed/cache-material-policy.inc']=legacy
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.write(p,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest(p)
report=dict(schemaVersion=1,status='shadow-cost-material-scope-attributed',sourceBase='ca47eed',eligibility=eligibility,productionProvenance=proof,userDiffSha256=protected,newGpuTimingExecuted=False,nativeBatchStarted=False,candidateAdopted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=n,bytes=p.stat().st_size,sha256=digest(p)) for n,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest=root/'docs/development/artifact-manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'));data['milestones']=[m for m in data['milestones'] if m['path']!='runs/'+out.name];data['milestones'].insert(0,dict(path='runs/'+out.name,name='阴影成本材质范围',status='MaterialCostScopeAttributed',sourceBase='ca47eed',evidence='docs/acceptance/nr/shadow-cost-scope.md',newGpuTimingExecuted=False,candidateAdopted=False));manifest.write_text(json.dumps(data,indent=2,ensure_ascii=False).replace('"diagnosticRetentionDays": [\n      3,\n      7\n    ]','"diagnosticRetentionDays": [3, 7]')+'\n',encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md']:
 p=root/name;text=p.read_text(encoding='utf-8');start=text.index('shadow-disk-kernel.md)');end=text.index('\n',start)
 line='[材质范围核对]('+('docs/acceptance/nr/' if name=='README.md' else '../acceptance/nr/')+'shadow-cost-scope.md)按三十五份实际管线常量分组，历史缓存支持范围对应约 1.47 毫秒控制差值。\n'
 if line not in text:p.write_text(text[:end+1]+line+text[end+1:],encoding='utf-8')
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-08-shadow-cost-scope.md','docs/acceptance/nr/shadow-cost-scope.md']:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target)
print(json.dumps(dict(status=report['status'],evidenceBytes=package.stat().st_size,pipelines=35,draws=1009,newGpuTimingExecuted=False)))
