from pathlib import Path
import json,os,traceback,time
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261108-092305-shadow-cost-scope-ef3182'
state=json.loads((root/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea/state.json').read_text())
profile=json.loads((root/'build/runs/20261107-122133-material-contribution-cost-c567b5/profile.json').read_text())
scope=json.loads((out/'scope-analysis.json').read_text());events={e for r in scope['groups'] for e in r['events']}
wanted={r['pipeline'] for r in profile['rows'] if r['event'] in events};cap=None;c=None;report=dict(status='starting');started=time.monotonic()
def fields(o):return {str(o.GetChild(i).name):o.GetChild(i) for i in range(o.NumChildren())}
def describe(o,depth=0):
 value=dict(name=str(o.name),children=o.NumChildren(),type=str(o.type.name),baseType=str(o.type.basetype),u=int(o.data.basic.u),byteSize=int(o.type.byteSize))
 if depth<3 and o.NumChildren():value['fields']=[describe(o.GetChild(i),depth+1) for i in range(min(o.NumChildren(),16))]
 return value
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 sf=c.GetStructuredFile();entries={}
 for ch in sf.chunks:
  if str(ch.name)!='vkCreateGraphicsPipelines':continue
  f=fields(ch);pipeline=str(f['Pipeline'].AsResourceId())
  if pipeline not in wanted:continue
  info=fields(f['CreateInfo'])
  for j in range(info['pStages'].NumChildren()):
   stage=fields(info['pStages'].GetChild(j))
   if int(stage['stage'].data.basic.u)==16:
    entries[pipeline]=describe(stage['pSpecializationInfo'])
 assert set(entries)==wanted
 applied={}
 for pipeline in sorted(wanted):
  row=next(r for r in profile['rows'] if r['pipeline']==pipeline and r['event'] in events)
  c.SetFrameEvent(row['event'],True);shader=c.GetVulkanPipelineState().fragmentShader
  assert str(shader.resourceId)==row['fragment']
  applied[pipeline]=dict(event=row['event'],specializationIds=list(shader.specializationIds),dataHex=bytes(shader.specializationData).hex(),blocks=[dict(name=b.name,compileConstants=b.compileConstants,variables=[dict(name=v.name,byteOffset=v.byteOffset) for v in b.variables]) for b in shader.reflection.constantBlocks if b.compileConstants])
 report=dict(status='read',seconds=time.monotonic()-started,captureSha256=state['captureSha256'],pipelines=entries,applied=applied,bufferCount=len(sf.buffers),newGpuTimingExecuted=False)
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'pipeline-specialization.json').write_text(json.dumps(report,indent=2))
 os._exit(0 if report['status']=='read' else 1)
