from pathlib import Path
import json,hashlib,sys,subprocess,shutil,zipfile,re
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify
check=(out/'all-artifact-tests.log').read_text(encoding='utf-8-sig');assert 'Ran 66 tests' in check and 'OK (skipped=1)' in check
after=json.loads((out/'post-cleanup-verification.json').read_text());assert after['productionProductsUnchanged'] and after['userDiffPreserved'] and after['cProjectArchiveBytes']==0
baseline=json.loads((out/'apply-baseline.json').read_text());assert all(digest(Path(path))==sha for path,sha in baseline['products'].items())
policy=json.loads((root/'build/maintenance/asset-copy-cleanup-policy.json').read_text());assert digest(Path(policy['catalog']))==baseline['catalogSha256'] and digest(Path(policy['lock']))==baseline['inputLockSha256']
source=root/'tools/skills/azurerender-artifact-maintenance';deployed=Path('C:/Users/admin/.codex/skills/azurerender-artifact-maintenance')
skill=[]
for name in ['SKILL.md','agents/openai.yaml','scripts/maintain.py','references/legacy-recovery.md']:
 shutil.copyfile(source/name,deployed/name);assert digest(source/name)==digest(deployed/name);skill.append(dict(path=name,sha256=digest(source/name),bytes=(source/name).stat().st_size))
proof=[]
for config in ['release','debug']:
 path=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(path.read_text()));proof.append(dict(configuration=config,status='passed',sha256=digest(path)))
protectedPaths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protectedPaths],stderr=subprocess.DEVNULL)).hexdigest();assert protected==baseline['userDiffSha256']
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/daily-asset-copies';evidence.mkdir(parents=True,exist_ok=True)
members={p.name:p for p in out.iterdir() if p.is_file() and p.suffix in ['.py','.json','.log'] and p.stat().st_size<2*2**20}
for name in ['asset-copy-cleanup-policy.json','20261108-large-run-model-copies.json','20261108-large-run-model-copies-source-map.json','asset-copy-cleanup-daily-budget.json']:members['maintenance/'+name]=root/'build/maintenance'/name
for name in ['artifact_asset_cleanup.py','artifact_maintenance.py','test_artifact_asset_cleanup.py','test_artifact_maintenance.py']:members['source/'+name]=root/'tools'/name
for row in skill:members['skill/'+row['path']]=source/row['path']
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in sorted(members.items()):archive.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as archive:
 assert archive.testzip() is None
 for name,path in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,status='daily-model-copy-maintenance-deployed',sourceBase='a89558b',cleanup=after,artifactChecks=dict(total=66,passed=65,skipped=1,skipReason='Host does not permit symbolic-link creation; real hard-link fixture passed'),trackingCost=json.loads((out/'tracking-cost.json').read_text()),dailyExecution=json.loads((out/'daily-report.json').read_text()),productionBuilds=json.loads((out/'production-builds.json').read_text()),productionProvenance=proof,userDiffSha256=protected,skillFiles=skill,policy=policy,projectDataVolume='D:',overallVisualAcceptance='failed-user-review',formalPerformancePassed=False,evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=name,bytes=p.stat().st_size,sha256=digest(p)) for name,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
documents=['README.md','docs/development/artifact-retention.md','docs/acceptance/nr/daily-asset-copies.md','docs/plans/2026-11-08-daily-asset-copies.md'];links=0
for name in documents:
 p=root/name
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' in target or target.startswith('#'):continue
  assert (p.parent/target.split('#')[0]).resolve().exists(),(name,target);links+=1
print(json.dumps(dict(status=report['status'],removedModelFiles=313,actualVolumeFreedGiB=after['volumeFreedBytes']/2**30,evidenceBytes=report['evidenceBytes'],verifiedLinks=links,userDiffPreserved=True,mainProductsUnchanged=True)))
