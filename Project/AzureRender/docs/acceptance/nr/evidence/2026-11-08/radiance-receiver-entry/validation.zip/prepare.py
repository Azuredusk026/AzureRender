from pathlib import Path
import difflib,json,shutil,subprocess,sys,zipfile
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from build_provenance import inputs,digest
assert check(root/'build',run=out,planned=280*2**20)['allowed']
before=inputs(root);old=root/'build/runs/20261107-070333-surface-radiance-reuse-bdfb96'
player=old/'isolated-candidate.exe';assert digest(player)=='e894558008aca8bbbb81f4c55a5a1bfef65d4be2b7fc2a1cb01e86dc8c5e6037'
archive=root/'docs/acceptance/nr/evidence/2026-11-07/surface-radiance-reuse/measurements.zip'
assert digest(archive)=='6efaffa9603acca29275d20951a46631f46bec96df3f4f5c459760a81851797b'
normalize=lambda data:data.decode('utf-8').replace('\r\r\n','\n').replace('\r\n','\n')
source=out/'source';source.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as package:
 for name in package.namelist():
  if name.startswith('candidate-source/shaders/'):
   (source/Path(name).name).write_text(normalize(package.read(name)),encoding='utf-8')
 original=normalize(package.read('original-source/shaders/mesh.frag'))
current=(root/'shaders/mesh.frag').read_text();candidate=(source/'mesh.frag').read_text()
start=original.index('float sampleShadowMap(float normalDotLight) {');end=original.index('\n}\n',start)+2;oldBlock=original[start:end]
start=current.index('vec2 shadowReceiverGradients[4];');end=current.index('\n}\n',current.index('float sampleShadowMap(float normalDotLight) {',start))+2;newBlock=current[start:end]
assert candidate.count(oldBlock)==1
candidate=candidate.replace(oldBlock,newBlock)
entry='    vec2 alphaUvDx=vec2(0),alphaUvDy=vec2(0);';assert candidate.count(entry)==1
candidate=candidate.replace(entry,'    prepareShadowReceiver();\n'+entry)
assert current==original.replace(oldBlock,newBlock).replace(entry,'    prepareShadowReceiver();\n'+entry),'The production fragment has unrelated source differences'
(source/'mesh.frag').write_text(candidate,encoding='utf-8')
(out/'entry.patch').write_text(''.join(difflib.unified_diff(normalize(zipfile.ZipFile(archive).read('candidate-source/shaders/mesh.frag')).splitlines(True),candidate.splitlines(True),fromfile='original-candidate',tofile='receiver-entry')),encoding='utf-8')
shaders=out/'shaders';shaders.mkdir(exist_ok=True)
base=list((root/'build/ninja-msvc-release/shaders').glob('*.spv'));additional=list((old/'candidate-programs').glob('*.spv'))
assert len(base)==663 and len(additional)==47
for path in [*base,*additional]:shutil.copyfile(path,shaders/path.name)
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());programs={p['output']:p for p in manifest['programs']};builds=[]
for path in sorted(additional):
 if path.suffix!='.spv' or not path.name.endswith('.frag.spv') or path.name.startswith('surface_radiance_'):continue
 name=path.name.replace('_radiance.frag.spv','.frag.spv');program=programs[name]
 command=[manifest['compiler'],'--target-env=vulkan1.3',*[f'-D{d}' for d in program['defines']],'-DAZURE_SURFACE_RADIANCE_REUSE=1',f'-I{source}',f'-I{root/"shaders"}',str(source/'mesh.frag'),'-o',str(shaders/path.name)]
 result=subprocess.run(command,capture_output=True,text=True,timeout=30);assert result.returncode==0,result.stderr
 validation=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.3',str(shaders/path.name)]
 result=subprocess.run(validation,capture_output=True,text=True,timeout=10);assert result.returncode==0,result.stderr
 builds.append(dict(file=path.name,base=name,command=command,validation=validation,sha256=digest(shaders/path.name)))
assert len(builds)==32 and inputs(root)==before
assert all(digest(path)==digest(shaders/path.name) for path in base)
proof=dict(sourceInputs=before,player=str(player),playerSha256=digest(player),archiveSha256=digest(archive),basePrograms={path.name:digest(path) for path in base},candidatePrograms={path.name:digest(shaders/path.name) for path in additional},builds=builds,shaderBytes=sum(path.stat().st_size for path in shaders.glob('*.spv')),productionUnchanged=True)
(out/'preparation.json').write_text(json.dumps(proof,indent=2));print(json.dumps(dict(status='prepared',recompiledPrograms=len(builds),shaderBytes=proof['shaderBytes'],productionUnchanged=True)),flush=True)
