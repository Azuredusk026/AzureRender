from pathlib import Path
import json,os,re,sys,shutil
import numpy as np
from PIL import Image
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_budget import check
from artifact_maintenance import guarded_run
from build_provenance import inputs,digest
preparation=json.loads((out/'preparation.json').read_text());source=inputs(root);assert source==preparation['sourceInputs']
assert check(root/'build',run=out,planned=48*2**20)['allowed']
build=root/'build/ninja-msvc-release';products={str(path):digest(path) for path in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}
products[preparation['player']]=preparation['playerSha256'];products.update({str(out/'shaders'/name):sha for name,sha in (preparation['basePrograms']|preparation['candidatePrograms']).items()})
lock=json.loads((root/'build/runs/20261107-171836-consolidated-preparation-images-374280/image/frozen-inputs.json').read_text())['project']
assert all(Path(path).is_file() and digest(Path(path))==sha for path,sha in lock.items())
reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint'
image=out/'image';image.mkdir(exist_ok=True);command=json.loads((reference/'command.json').read_text());command[0]=preparation['player']
for flag,value in [('--capture-dir',str(image/'frames')),('--runtime-report',str(image/'runtime.json'))]:command[command.index(flag)+1]=value
command+=['--resource-root',str(out)]
(out/'frozen-inputs.json').write_text(json.dumps(dict(source=source,products=products,project=lock),indent=2));(out/'command.json').write_text(json.dumps(command,indent=2))
os.environ['PATH']=str(build)+';'+os.environ['PATH'];os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
execution=guarded_run(root/'build',out.name,command,600);rows=[]
for path in sorted((image/'frames').glob('frame_*.png')):
 current=np.array(Image.open(path).convert('RGB'));old=np.array(Image.open(reference/'frames'/path.name).convert('RGB'));delta=np.abs(current.astype(np.int16)-old.astype(np.int16))
 positions=np.argwhere(np.any(delta,axis=2))
 rows.append(dict(frame=path.name,sha256=digest(path),changedPixels=int(len(positions)),maximumByteError=int(delta.max()),positions=positions[:32].tolist()))
log=(out/'process.log').read_text(errors='replace');zero='Allocator after unload: buffers=0 images=0' in log;clean=not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-'])
manifest=json.loads((image/'frames/capture_manifest.json').read_text());prepared=manifest.get('surfaceRadiancePrepared',False)
unchanged=inputs(root)==source and all(digest(Path(path))==sha for path,sha in products.items()) and all(digest(Path(path))==sha for path,sha in lock.items())
valid=execution['exitCode']==0 and len(rows)==4 and zero and clean and prepared and unchanged
passed=valid and all(not row['changedPixels'] for row in rows)
report=dict(status='compatible' if passed else 'isolated-zero-pixel-gate-failed' if valid else 'invalid-execution',execution=execution,frames=rows,surfaceRadiancePrepared=prepared,cacheBytes=manifest.get('surfaceRadianceBytes'),zeroAllocator=zero,validationLogClean=clean,allInputsUnchanged=unchanged,formalPerformanceQualified=False,performancePairExecuted=False)
(out/'native-result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
raise SystemExit(0 if passed else 1)
