from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify
result=json.loads((out/'native-result.json').read_text());assert result['status']=='isolated-zero-pixel-gate-failed' and result['allInputsUnchanged']
original=json.loads((root/'docs/acceptance/nr/evidence/2026-11-07/surface-radiance-reuse/results.json').read_text())['image']['frames']
assert all(a['sha256']==b['sha256'] for a,b in zip(result['frames'],original))
proof=[]
for config in ['release','debug']:
 path=root/f'build/ninja-msvc-{config}/build-provenance.json';verify(root,json.loads(path.read_text()));proof.append(dict(configuration=config,sha256=digest(path),status='passed'))
protectedPaths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protectedPaths],stderr=subprocess.DEVNULL)).hexdigest();assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
evidence=root/'docs/acceptance/nr/evidence/2026-11-08/radiance-receiver-entry';evidence.mkdir(parents=True,exist_ok=True)
members={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and (p.parent==out or p.parent==out/'source' or p.name in ['runtime.json','capture_manifest.json']) and p.suffix in ['.py','.cpp','.glsl','.frag','.vert','.json','.log','.patch'] and p.stat().st_size<2*2**20}
package=evidence/'validation.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in sorted(members.items()):archive.write(path,name)
assert package.stat().st_size<8*2**20
with zipfile.ZipFile(package) as archive:
 assert archive.testzip() is None
 for name,path in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest(path)
report=dict(schemaVersion=1,sourceBase='136dd99',result=result,programsRecompiled=32,allFourFramesIdenticalToOriginalCandidate=True,productionBuildProvenance=proof,protectedUserDiffSha256=protected,productionIntegrated=False,performancePairExecuted=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceBytes=package.stat().st_size,evidenceSha256=digest(package),members=[dict(path=name,bytes=p.stat().st_size,sha256=digest(p)) for name,p in sorted(members.items())])
(evidence/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps(dict(status=result['status'],originalCandidateFramesIdentical=True,evidenceBytes=report['evidenceBytes'],productionProvenancePassed=True,userDiffPreserved=True)))
