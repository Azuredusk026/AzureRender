from pathlib import Path
import sys,json,zipfile,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,digest,inputs
def read(name):return json.loads((out/name).read_text())
for config in ['debug','release']:
    proof=read(config+'-build-provenance.json');verify(root,proof)
    assert proof==json.loads((root/('build/ninja-msvc-'+config)/'build-provenance.json').read_text())
assert all(digest(root/p)==h for p,h in read('protected-files.json').items())
lock=read('frozen-project-inputs.json')
assert len(lock)==1729 and all(digest(Path(p))==h for p,h in lock.items())
capture=read('capture-results.json');build=read('build-results.json')
assert capture['exitCode']==0 and len(capture['frames'])==4
assert all(capture[k] for k in ['validationClean','allocatorZero','sourceUnchanged','programsUnchanged','projectInputsUnchanged'])
reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames'
duplicates=[]
for frame in capture['frames']:
    path=out/'frames'/frame['name'];original=reference/frame['name']
    assert frame['changedPixels']==frame['maximumByteError']==0
    assert digest(path)==digest(original)==frame['sha256']==frame['referenceSha256']
    duplicates.append(dict(path=str(path),original=str(original),bytes=path.stat().st_size,sha256=digest(path)))
(out/'duplicate-frame-inventory.json').write_text(json.dumps(duplicates,indent=2))
result=dict(status='reference-position-frame-main-integration-qualified',runtimeSourceCommit='585440f',sourceBranchCommit='7eabe70',documentationCommit='7a7b98c',build=build,originalFour=capture,descriptiveMemory=read('memory-results.json'),protectedFilesExact=13,projectInputsExact=1729,sourceProofsFresh=True,childFullPlaneScope='7372800 R32 values belong to the source branch diagnostic; root independently verifies 3330800 position components and 675328 depth/coverage values',overall='failed-user-review',formalPerformanceAccepted=False)
(out/'results.json').write_text(json.dumps(result,indent=2))
dest=root/'docs/acceptance/nr/evidence/2026-11-11/reference-position-frame-main-integration';dest.mkdir(parents=True,exist_ok=True)
archive=dest/'validation.zip';members={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.iterdir()):
        if p.is_file() and p.suffix in ['.json','.py','.log','.xml','.csv','.bin']:
            members[p.name]=digest(p);z.write(p,p.name)
    z.writestr('member-sha256.json',json.dumps(members,indent=2))
assert archive.stat().st_size<8*1024*1024
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in members.items())
verification=dict(bytes=archive.stat().st_size,members=len(members)+1,sha256=digest(archive),memberHashesVerified=True)
(dest/'archive-verification.json').write_text(json.dumps(verification,indent=2))
(dest/'results.json').write_text(json.dumps(result,indent=2))
for item in duplicates:
    p=Path(item['path']);assert p.parent.resolve()==(out/'frames').resolve()
    assert digest(p)==digest(Path(item['original']))==item['sha256'];p.unlink()
(out/'identical-frames-reclaimed.json').write_text(json.dumps(dict(bytes=sum(x['bytes'] for x in duplicates),files=len(duplicates),archive=verification),indent=2))
print(json.dumps(verification))
