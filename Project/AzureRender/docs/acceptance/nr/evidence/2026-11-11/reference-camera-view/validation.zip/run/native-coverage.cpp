#define main syntheticDepthCoverageMain
#include "native-synthetic.cpp"
#undef main
#include "resources/BinaryFile.hpp"
#include "render/ReferenceCameraDepth.hpp"
#include <nlohmann/json.hpp>
#include <fstream>
int main(int argc,char** argv)try{
    if(argc!=4)throw std::invalid_argument("Expected shader directory, native surface config and output prefix");
    const auto c=nlohmann::json::parse(std::ifstream(argv[2]));test::VulkanComputeFixture host(true);auto& backend=*host.backend;
    {
        DepthInputs inputs(host);const auto positions=readBinaryFile(c["positions"].get<std::string>()),uv=readBinaryFile(c["uv"].get<std::string>()),indices=readBinaryFile(c["indices"].get<std::string>()),profileBytes=readBinaryFile(c["profile"].get<std::string>());
        if(positions.size()%16||uv.size()!=positions.size()/2||indices.size()%12||profileBytes.size()!=80)throw std::invalid_argument("Native depth surface sizes differ");
        ReferenceClipProjectionProfile profile;std::memcpy(&profile.parameters,profileBytes.data(),80);
        std::vector<std::vector<char>> mips;for(const auto& name:c["mips"])mips.push_back(readBinaryFile(name.get<std::string>()));
        rhi::SamplerDesc sampled;sampled.filter=VK_FILTER_LINEAR;sampled.mipmapLinear=false;sampled.maxLod=1000;sampled.mipLodBias=0;
        const auto texture=inputs.texture(c["width"],c["height"],VK_FORMAT_BC7_UNORM_BLOCK,mips,sampled);
        const auto p=inputs.buffer(positions.data(),positions.size(),VK_BUFFER_USAGE_VERTEX_BUFFER_BIT),u=inputs.buffer(uv.data(),uv.size(),VK_BUFFER_USAGE_VERTEX_BUFFER_BIT),i=inputs.buffer(indices.data(),indices.size(),VK_BUFFER_USAGE_INDEX_BUFFER_BIT);
        ReferenceDepthGeometry geometry{p.buffer,i.buffer,static_cast<unsigned>(positions.size()/16),static_cast<unsigned>(indices.size()/4)};
        geometry.surface.cullMode=VK_CULL_MODE_BACK_BIT;geometry.surface.frontFace=VK_FRONT_FACE_CLOCKWISE;
        geometry.surface.alpha=ReferenceDepthAlpha{u.buffer,texture.first,texture.second};geometry.surface.alpha->channel=c.value("channel",0U);geometry.surface.alpha->cutoff=c["cutoff"];geometry.surface.alpha->lodBias=c["lodBias"];
        geometry.surface.schemaVersion=2;geometry.surface.alpha->lodPolicy=ReferenceDepthAlphaLodPolicy::EllipseMajorAxisMirroredCoarseY;
        auto shaders=ReferenceDepthShaders::loadEllipseMasked(argv[1],queryMaterialUvGradientSupport(host.physical));shaders.positionFrame=ReferenceDepthPositionFrameShaders::load(argv[1]);ReferenceCameraView view;view.extent={2560,1440};view.flipNdcY=true;view.projection=profile;const auto frameBytes=readBinaryFile(c["frame"].get<std::string>());if(frameBytes.size()!=32)throw std::invalid_argument("Camera frame layout differs");std::memcpy(&view.frame.parameters,frameBytes.data(),32);PreparedReferenceCameraView camera(view);const auto config=referenceCameraDepthConfig(camera);
        std::array<float,3> minimum{INFINITY,INFINITY,INFINITY},maximum{-INFINITY,-INFINITY,-INFINITY};const auto sourcePositions=reinterpret_cast<const float*>(positions.data());for(std::size_t k=0;k<positions.size()/16;++k)for(unsigned axis=0;axis<3;++axis){minimum[axis]=std::min(minimum[axis],sourcePositions[k*4+axis]);maximum[axis]=std::max(maximum[axis],sourcePositions[k*4+axis]);}if(!camera.intersectsBounds(minimum,maximum))throw std::runtime_error("Reference camera rejected actual geometry bounds");
        ReferenceDepthGpu producer(backend,{2560,1440},1,config,shaders);const auto values=inputs.render(producer,0,camera.descriptor().projection,{geometry});
        std::ofstream image(std::string(argv[3])+"-r32.bin",std::ios::binary);image.write(reinterpret_cast<const char*>(values.data()),2560*1440*4);if(!image)throw std::runtime_error("Native R32 export failed");
        const auto queries=readBinaryFile(c["queries"].get<std::string>());if(queries.size()%16)throw std::invalid_argument("Native queries malformed");const auto q=reinterpret_cast<const float*>(queries.data());std::vector<float> selected;
        for(unsigned k=0;k<queries.size()/16;++k){const unsigned x=static_cast<unsigned>(q[k*4]),y=static_cast<unsigned>(q[k*4+1]);if(x>=2560||y>=1440)throw std::invalid_argument("Native query outside output");selected.push_back(values[2560*1440+y*2560+x]);}
        std::ofstream depth(std::string(argv[3])+"-selected-d32.bin",std::ios::binary);depth.write(reinterpret_cast<const char*>(selected.data()),static_cast<std::streamsize>(selected.size()*4));if(!depth)throw std::runtime_error("Native D32 export failed");
    }
    if(host.errors.load()||host.allocator.statistics().liveBuffers||host.allocator.statistics().liveImages)throw std::runtime_error("Native masked depth validation or cleanup failed");
    std::cout<<host.properties.deviceName<<": native BC7 alpha, front-face winding and masked depth production, validation and cleanup passed\n";return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
