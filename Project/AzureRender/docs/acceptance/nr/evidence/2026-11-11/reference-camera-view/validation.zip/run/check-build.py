from pathlib import Path
import subprocess,json,sys,hashlib
out=Path(__file__).parent;root=out.parents[2];c=sys.argv[1];build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if c=='Release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug');frame=out.parent/'20261111-001326-reference-position-frame-482201';actual=out.parent/'20261111-005626-actual-geometry-uv-source-f50f51';config=json.loads((actual/'candidate-config.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,digest in json.loads((out/'frozen-source.json').read_text()).items():assert sha(root/n)==digest,n
command=[str(build/'AzureReferenceCameraViewTests.exe'),config['profile'],str(frame/'native-frame.bin'),config['positions'],config['queries']];r=subprocess.run(command,capture_output=True,text=True,timeout=120);(out/(c.lower()+'-cpu.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
programs=json.loads((root/'docs/acceptance/nr/evidence/2026-11-11/reference-position-frame/program-catalog.json').read_text())['sha256'];assert len(programs)==858
for n,digest in programs.items():assert sha(build/'shaders'/n)==digest,n
before=json.loads((out/'before-player-sha256.json').read_text());assert sha(build/'AzurePlayer.exe')==before[c.lower()]
result={'configuration':c,'command':command,'exitCode':r.returncode,'stdout':r.stdout,'programsExact':858,'playerUnchanged':True,'playerSha256':before[c.lower()],'testSha256':sha(build/'AzureReferenceCameraViewTests.exe')};(out/(c.lower()+'-identity.json')).write_text(json.dumps(result,indent=2)+'\n');print(r.stdout.strip())
