from pathlib import Path
import json,zipfile,hashlib,re
out=Path(__file__).parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=json.loads((out/'results.json').read_text());plan=root/'docs/plans/2026-11-11-reference-camera-view.md';plan.write_text(plan.read_text(encoding='utf-8').replace('- [ ]','- [x]'),encoding='utf-8')
for name,prefix in [('README.md','docs/'),('docs/project-status.md',''),('docs/plans/azure-engine-plan.md','../'),('docs/plans/2026-11-09-native-quality.md','../')]:
 p=root/name;text=p.read_text(encoding='utf-8')
 if '[参考相机视图契约]' not in text:text+='\n[参考相机视图契约]('+prefix+'acceptance/nr/reference-camera-view.md)通过两配置空间查询及双设备深度适配。\n17017 条来源射线的往返误差满足八位子像素门槛，宿主视图选择与绘制绑定继续接入。\n'
 p.write_text(text,encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');anchor='## 2026-11-11 实际主坐标来源'
if '## 2026-11-11 参考相机视图' not in text:text=text.replace(anchor,'## 2026-11-11 参考相机视图\n\n- 统一版本化参考投影、逆投影射线、保守包围盒及深度配置适配。\n- 缓存不可变视图及逆矩阵，纯数学头共用深度约定枚举。\n- 复现极小投影下的非规格化归零误剔除，并补足绝对边界余量。\n- 两配置的 17017 条射线及 11564 个可见顶点通过检查。\n- 实际完整深度平面及可见量与来源控制一致，858 份程序保持相同。\n- 当前 Player 字节保持一致，场景宿主接入与原画质待项继续推进。\n\n'+anchor)
p.write_text(text,encoding='utf-8')
sources=list(result['sourceSha256'])+['docs/runtime/reference-camera-view.md','docs/plans/2026-11-11-reference-camera-view.md','docs/acceptance/nr/reference-camera-view.md']
files={'run/'+p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and p.suffix in {'.py','.json','.log','.cpp','.hpp','.bin'} and 'tmp' not in p.parts};files.update({'source/'+n:root/n for n in sources})
config=json.loads((out/'candidate-config.json').read_text())
for n in ['profile','frame','positions','indices','uv','queries']:files['inputs/'+n+'.bin']=Path(config[n])
base=out.parent/'20261111-005626-actual-geometry-uv-source-f50f51'
for d in ['nvidia','intel']:files['baseline/'+d+'-r32.bin']=base/(d+'-actual-r32.bin');files['baseline/'+d+'-rg8.bin']=base/(d+'-actual-rg8.bin')
dest=root/'docs/acceptance/nr/evidence/2026-11-11/reference-camera-view';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']={'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members)+1};(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n')
for n in [v for v in sources if v.endswith('.md')]:
 p=root/n;text=p.read_text(encoding='utf-8')
 for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(n,sentence)
 for link in re.findall(r'\]\(([^)]+)\)',text):
  if not re.match(r'(https?:|#)',link):assert (p.parent/link.split('#')[0]).exists(),(n,link)
print(json.dumps(result['archive']))
