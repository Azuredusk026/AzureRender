from pathlib import Path
import subprocess,json,hashlib
out=Path(__file__).parent;root=out.parents[2];old=json.loads((out/'cpu-subnormal-red-result.json').read_text());command=[v.replace('cpu-subnormal-red','cpu-subnormal-green') for v in old['command']]
r=subprocess.run(subprocess.list2cmdline(command),shell=True,capture_output=True,text=True);(out/'cpu-subnormal-green-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
r=subprocess.run([str(out/'cpu-subnormal-green.exe')],capture_output=True,text=True);(out/'cpu-subnormal-green.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
path=out/'frozen-source.json';frozen=json.loads(path.read_text());changes={}
for name in ['src/render/ReferenceCameraView.hpp','tests/ReferenceCameraViewTests.cpp']:
 digest=hashlib.sha256((root/name).read_bytes()).hexdigest();changes[name]={'before':frozen[name],'after':digest};frozen[name]=digest
path.write_text(json.dumps(frozen,indent=2)+'\n');(out/'subnormal-culling-correction.json').write_text(json.dumps({'rootCause':'Projection denormals may flush to zero on supported devices; denorm_min margin excludes physically visible uncertainty','correction':'Absolute conservative margin uses64 times minimum normal float in addition to64epsilon operation magnitude','sourceChanges':changes,'redObserved':True,'greenObserved':True,'originalPixelAndColorGatesUnchanged':True},indent=2)+'\n');print(r.stdout.strip())
