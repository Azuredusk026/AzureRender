from pathlib import Path
import subprocess,json
out=Path(__file__).parent;root=out.parents[2];source=root/'tests/ReferenceCameraViewTests.cpp';command=['D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat','cl','/nologo','/utf-8','/std:c++20','/EHsc','/O2','/I'+str(root/'src'),'/ID:/Tools/VulkanSDK/1.4.350.0/Include','/Fe:'+str(out/'cpu-subnormal-red.exe'),'/Fo:'+str(out/'cpu-subnormal-red.obj'),str(source)]
r=subprocess.run(subprocess.list2cmdline(command),shell=True,capture_output=True,text=True);(out/'cpu-subnormal-red-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
r=subprocess.run([str(out/'cpu-subnormal-red.exe')],capture_output=True,text=True);(out/'cpu-subnormal-red.log').write_text(r.stdout+r.stderr);assert r.returncode!=0 and 'Subnormal projection flush uncertainty' in r.stdout+r.stderr
(out/'cpu-subnormal-red-result.json').write_text(json.dumps({'exitCode':r.returncode,'failure':r.stdout+r.stderr,'command':command},indent=2)+'\n');print('Observed false culling when device may flush projected subnormal depth; regression test failed as intended')
