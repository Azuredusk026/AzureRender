from pathlib import Path
import json,zipfile,hashlib,re
out=Path(__file__).parent;root=out.parents[2];base=out.parent/'20261111-004745-actual-geometry-index-source-e0f0ac';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=json.loads((out/'results.json').read_text())
for name,prefix in [('README.md','docs/'),('docs/project-status.md',''),('docs/plans/azure-engine-plan.md','../'),('docs/plans/2026-11-09-native-quality.md','../')]:
 p=root/name;text=p.read_text(encoding='utf-8')
 if '[实际网格主坐标来源]' not in text:text+='\n[实际网格主坐标来源]('+prefix+'acceptance/nr/actual-geometry-uv-source.md)完成双设备的实际位置、索引及 UV 组合核对。\n完整深度平面及可见量与来源控制一致，后续接入统一场景视图。\n'
 p.write_text(text,encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');anchor='## 2026-11-11 实际索引与朝向'
if '## 2026-11-11 实际主坐标来源' not in text:text=text.replace(anchor,'## 2026-11-11 实际主坐标来源\n\n- 实际世界位置、索引及 UV 进入公开参考深度生产器。\n- 定位 2688 个顶点的纵向 UV 差异，并核对完整区域输出。\n- 两设备 7372800 个深度值及各 17017 个可见量与控制一致。\n- NVIDIA 保持全区精确，Intel 九十六处既有超差继续修正。\n\n'+anchor)
p.write_text(text,encoding='utf-8')
files={'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log','.bin'}};files['docs/actual-geometry-uv-source.md']=root/'docs/acceptance/nr/actual-geometry-uv-source.md';files['fixture/native-coverage.cpp']=base/'native-coverage.cpp';files['fixture/native-config.json']=base/'candidate-config.json'
config=json.loads((out/'candidate-config.json').read_text());control=json.loads((base/'candidate-config.json').read_text())
for n in ['positions','indices','profile','uv']:files['inputs/'+n+'.bin']=Path(config[n])
files['inputs/control-uv.bin']=Path(control['uv'])
for d in ['nvidia','intel']:files['baseline/'+d+'-r32.bin']=base/(d+'-actual-r32.bin');files['baseline/'+d+'-rg8.bin']=base/(d+'-actual-rg8.bin')
dest=root/'docs/acceptance/nr/evidence/2026-11-11/actual-geometry-uv-source';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result['sourceTask'].pop('differenceRows');result['archive']={'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members)+1};(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n')
p=root/'docs/acceptance/nr/actual-geometry-uv-source.md';text=p.read_text(encoding='utf-8')
for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,sentence
for link in re.findall(r'\]\(([^)]+)\)',text):assert (p.parent/link).exists(),link
print(json.dumps(result['archive']))
