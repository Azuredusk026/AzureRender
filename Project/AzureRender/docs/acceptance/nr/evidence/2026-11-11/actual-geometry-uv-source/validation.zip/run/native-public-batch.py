from pathlib import Path
import subprocess,sys
out=Path(__file__).parent
raise SystemExit(subprocess.run([sys.executable,str(out/"native-batch.py")],timeout=180).returncode)
