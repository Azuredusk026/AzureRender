from pathlib import Path
import subprocess,json,os,re,numpy as np
out=Path(__file__).parent;root=out.parents[2];runs=root/'build/runs';public=out.parent/'20261111-004745-actual-geometry-index-source-e0f0ac';build=runs/'20261110-030251-hair-main-chroma-public-9e799c/release';calibration=runs/'20261110-003435-visibility-numeric-contract-4f95e7';rows=[]
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(build)+';'+env['PATH'])
 prefix=out/(device+'-actual');command=[str(public/'native-coverage.exe'),str(build/'shaders'),str(out/'candidate-config.json'),str(prefix)]
 (out/(device+'-depth-command.json')).write_text(json.dumps(command,indent=2)+'\n')
 with (out/(device+'-depth.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
 text=(out/(device+'-depth.log')).read_text(errors='replace');assert r.returncode==0 and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I),text[-3000:]
 config=json.loads((calibration/'hair-calibration.json').read_text());config.update(depth=str(prefix)+'-r32.bin',scope='actual',queries=str(out.parent/'20261110-235205-actual-world-depth-source-bcce93/queries.bin'),expected=str(out.parent/'20261110-235205-actual-world-depth-source-bcce93/expected.bin'));path=out/(device+'-visibility.json');path.write_text(json.dumps(config,indent=2)+'\n')
 command=[str(calibration/'calibration.exe'),str(path),str(calibration)];(out/(device+'-visibility-command.json')).write_text(json.dumps(command,indent=2)+'\n')
 with (out/(device+'-visibility.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
 result=json.loads((out/(device+'-actual-result.json')).read_text());text=(out/(device+'-visibility.log')).read_text(errors='replace');assert result['validationErrors']==0 and result['zeroAllocator'] and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I)
 a=np.fromfile(out/(device+'-actual-rg8.bin'),dtype='u1').reshape(-1,2)[:,1];b=np.fromfile(out.parent/'20261111-004745-actual-geometry-index-source-e0f0ac'/(device+'-actual-rg8.bin'),dtype='u1').reshape(-1,2)[:,1];expected=np.fromfile(config['expected'],dtype='<u4');err=abs(a.astype('i4')-expected.astype('i4'));base=abs(b.astype('i4')-expected.astype('i4'))
 q=np.fromfile(config['queries'],dtype='<f4').reshape(-1,4);x=q[:,0].astype(int);y=q[:,1].astype(int);depth=np.fromfile(prefix.with_name(prefix.name+'-r32.bin'),dtype='<f4').reshape(1440,2560)[y,x];d32=np.fromfile(out/(device+'-actual-selected-d32.bin'),dtype='<f4');assert np.array_equal(depth.view('u4'),d32.view('u4'));depth.tofile(out/(device+'-actual-selected-r32.bin'))
 rows.append({'device':device,'visibilityExitCode':r.returncode,'result':result,'failures':int((err>1).sum()),'baselineFailures':int((base>1).sum()),'newFailures':int(((err>1)&(base<=1)).sum()),'closedFailures':int(((err<=1)&(base>1)).sum()),'r32D32Exact':True,'changedVisibilityPixels':int((a!=b).sum()),'failurePixels':[{'uiPixel':[int(x[k]),1439-int(y[k])],'actual':int(a[k]),'expected':int(expected[k])} for k in np.flatnonzero(err>1)]})
 (out/'native-results.json').write_text(json.dumps({'status':'diagnostic-no-production-adoption','overall':'failed-user-review','devices':rows},indent=2)+'\n');print(device,result['exactPixels'],result['withinOnePixels'],result['maximumByteError'],'new',rows[-1]['newFailures'],flush=True)
