from pathlib import Path
import json,re

out=Path(__file__).resolve().parent
root=out.parents[2]
paths=['docs/acceptance/nr/material-ellipse-coverage-policy.md',
    'docs/plans/2026-11-11-material-ellipse-coverage-policy.md',
    'docs/runtime/material-coverage.md']
for name in paths:
    path=root/name
    text=path.read_text(encoding='utf-8')
    for sentence in re.split('[。！？\n]',text):
        assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(name,sentence)
    for paragraph in text.split('\n\n'):
        if not paragraph.startswith('- '):
            assert paragraph.count('。')<=4,(name,paragraph)
    for link in re.findall(r'\]\(([^)]+)\)',text):
        if not link.startswith('https:'):
            assert (path.parent/link.split('#')[0]).exists(),(name,link)
manifest=json.loads((root/'docs/development/artifact-manifest.json').read_text(encoding='utf-8'))
row=next(m for m in manifest['milestones'] if m['path']=='runs/'+out.name)
assert (root/row['evidence']).is_file() and (root/row['results']).is_file()
assert (root/'build'/row['path']).is_dir()
print('Coverage documentation, plan, links and artifact receipt passed')
