from pathlib import Path
import json,zipfile

out=Path(__file__).resolve().parent
folder=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-09/hair-color-visibility-attribution'
data=json.loads((folder/'results.json').read_text())
for key,value in data.items():
    if isinstance(value,dict): print(key,[(k,len(v) if isinstance(v,(list,dict)) else v) for k,v in value.items()])
    elif isinstance(value,list): print(key,len(value), list(value[0]) if value and isinstance(value[0],dict) else '')
with zipfile.ZipFile(folder/'validation.zip') as file:
    print(file.read('analyze_probe.py').decode())
    print(file.read('analyze_native.py').decode())
