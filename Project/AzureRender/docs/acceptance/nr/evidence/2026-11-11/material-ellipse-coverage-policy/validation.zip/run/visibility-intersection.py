from pathlib import Path
import json,runpy

import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
prior=out.parent/'20261111-065045-native-hair-production-coverage-7900c9'
source=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-09/hair-color-visibility-attribution/results.json'
attribution=json.loads(source.read_text())
depth_source=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-11/actual-geometry-uv-source/results.json'
depth_data=json.loads(depth_source.read_text())
intel_depth={tuple(row['uiPixel']) for row in next(d for d in depth_data['devices'] if d['device']=='intel')['failurePixels']}
assert len(intel_depth)==96
baseline=runpy.run_path(str(out.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
mask=baseline['mask']
expected=baseline['expected']
legacy_points={tuple(row['pixel']):row['visibilityByteError'] for row in attribution['actualReceiver']['points']}
resolved={tuple(row['pixel']) for row in attribution['baseline']['points']}-{tuple(row['pixel']) for row in attribution['nativeVisibilityControl']['points']}
assert len(legacy_points)==73 and len(resolved)==42
interior=np.logical_and.reduce([np.roll(mask,(y,x),(0,1)) for y in (-1,0,1) for x in (-1,0,1)])
results={}
for device,count in (('nvidia',43),('intel',597)):
    path=prior/(device+'-hair-coverage-ellipse-crop.png')
    rgb=np.asarray(Image.open(path).convert('RGB')).astype('i4')
    errors=abs(rgb-expected).max(axis=2)
    bad=mask&(errors>1)
    points={(int(x+1140),int(y+130)) for y,x in zip(*np.nonzero(bad))}
    assert len(points)==count
    buckets=dict(legacyVisibilityResolved=len(points&resolved),legacyVisibilityMatched=len(points&legacy_points.keys()),
        legacyVisibilityOverOne=sum(legacy_points.get(p,0)>1 for p in points),
        interiorFailures=int((bad&interior).sum()),strongInteriorFailures=int((bad&interior&(errors>8)).sum()))
    examples=sorted(points&resolved,key=lambda p:int(errors[p[1]-130,p[0]-1140]),reverse=True)[:8]
    strong={(int(x+1140),int(y+130)) for y,x in zip(*np.nonzero(bad&(errors>8)))}
    buckets.update(intelDepthVisibilityIntersection=len(points&intel_depth),strongIntelDepthVisibilityIntersection=len(strong&intel_depth),
        intelPeakInDepthVisibilityFailures=(1375,276) in intel_depth)
    results[device]=dict(failures=count,**buckets,positiveProbePixels=[dict(pixel=p,
        currentColorMaxError=int(errors[p[1]-130,p[0]-1140]),legacyVisibilityError=legacy_points[p]) for p in examples])
report=dict(scope='Spatial intersection with historical intervention. Current effect requires a new production readback.',devices=results)
(out/'visibility-intersection.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
