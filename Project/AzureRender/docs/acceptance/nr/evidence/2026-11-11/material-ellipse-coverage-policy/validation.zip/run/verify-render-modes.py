from pathlib import Path
import json,re,subprocess,sys

out=Path(__file__).resolve().parent
configuration,device=sys.argv[1:]
folder=out/(configuration.lower()+'-'+device+'-ellipse-plane')
case=folder/'ellipse'
base=json.loads((case/'command.json').read_text())
rows=[]
for mode in ('temporal','multisample'):
    frames=folder/(mode+'-frames')
    command=list(base)
    command[command.index('--capture-dir')+1]=str(frames)
    command+=['--anti-aliasing',mode]
    path=folder/(mode+'-rejection.log')
    with path.open('wb') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=90)
    message=path.read_text(errors='replace')
    assert result.returncode!=0 and 'coverageTexture ellipse-major requires single-sample spatial rendering' in message,message[-4000:]
    assert not list(frames.glob('frame_*.png')) and not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)',message),message[-4000:]
    rows.append(dict(mode=mode,exitCode=result.returncode,command=command))
(folder/'render-mode-rejections.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
