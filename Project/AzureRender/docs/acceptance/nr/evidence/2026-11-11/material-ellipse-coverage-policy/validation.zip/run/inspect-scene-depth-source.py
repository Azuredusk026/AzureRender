from pathlib import Path
import json,mmap,struct,zipfile

import numpy as np

out=Path(__file__).resolve().parent
root=out.parents[2]
project=out/'hair-project'
glb=project/'character/hair-coverage.glb'
evidence=root/'docs/acceptance/nr/evidence/2026-11-11/actual-geometry-uv-source/validation.zip'

def bounds(array):
    return [array.min(axis=0).tolist(),array.max(axis=0).tolist()]

def node_matrix(node):
    if 'matrix' in node:
        return np.array(node['matrix'],dtype='f8').reshape(4,4).T
    x,y,z,w=node.get('rotation',[0,0,0,1])
    matrix=np.array([
        [1-2*y*y-2*z*z,2*x*y-2*w*z,2*x*z+2*w*y,0],
        [2*x*y+2*w*z,1-2*x*x-2*z*z,2*y*z-2*w*x,0],
        [2*x*z-2*w*y,2*y*z+2*w*x,1-2*x*x-2*y*y,0],
        [0,0,0,1]],dtype='f8')
    matrix[:3,:3]*=node.get('scale',[1,1,1])
    matrix[:3,3]=node.get('translation',[0,0,0])
    return matrix

with zipfile.ZipFile(evidence) as archive:
    native=np.frombuffer(archive.read('inputs/positions.bin'),dtype='<f4').reshape(-1,4)[:,:3]
    native_uv=np.frombuffer(archive.read('inputs/uv.bin'),dtype='<f4').reshape(-1,2)
    native_indices=np.frombuffer(archive.read('inputs/indices.bin'),dtype='<u4')
    native_profile=archive.read('inputs/profile.bin')
frame_evidence=evidence.parent.parent/'reference-position-frame/validation.zip'
with zipfile.ZipFile(frame_evidence) as archive:
    native_frame=archive.read('run/native-frame.bin')

with glb.open('rb') as file,mmap.mmap(file.fileno(),0,access=mmap.ACCESS_READ) as data:
    assert data[:4]==b'glTF' and struct.unpack_from('<I',data,4)[0]==2
    json_bytes,kind=struct.unpack_from('<II',data,12)
    assert kind==0x4e4f534a
    document=json.loads(data[20:20+json_bytes])
    bin_offset=28+json_bytes
    def accessor(index):
        entry=document['accessors'][index]
        view=document['bufferViews'][entry['bufferView']]
        component={5123:'<u2',5125:'<u4',5126:'<f4'}[entry['componentType']]
        stride=np.dtype(component).itemsize
        columns={'SCALAR':1,'VEC2':2,'VEC3':3}[entry['type']]
        offset=bin_offset+view.get('byteOffset',0)+entry.get('byteOffset',0)
        return np.ndarray((entry['count'],columns),dtype=component,buffer=data,offset=offset,
            strides=(view.get('byteStride',stride*columns),stride)).copy()
    material=9
    rows=[]
    for mesh_index,mesh in enumerate(document['meshes']):
        for primitive_index,primitive in enumerate(mesh['primitives']):
            if primitive.get('material')!=material:
                continue
            positions=accessor(primitive['attributes']['POSITION'])
            uv=accessor(primitive['attributes']['TEXCOORD_0'])
            indices=accessor(primitive['indices']).reshape(-1)
            parents={child:index for index,node in enumerate(document['nodes']) for child in node.get('children',[])}
            def lineage(index):
                nodes=[]
                while index is not None:
                    nodes.append({k:v for k,v in document['nodes'][index].items() if k in ('name','matrix','rotation','translation','scale','skin')})
                    index=parents.get(index)
                return nodes
            nodes=[lineage(index) for index,node in enumerate(document['nodes']) if node.get('mesh')==mesh_index]
            delta=native.astype('f8')-positions if len(positions)==len(native) else None
            transforms=[]
            for chain in nodes:
                matrix=np.identity(4)
                for node in reversed(chain):
                    matrix=matrix@node_matrix(node)
                xyz=positions.astype('f8')
                imported=(xyz[:,0,None]*matrix[:3,0]+xyz[:,1,None]*matrix[:3,1]+xyz[:,2,None]*matrix[:3,2]+matrix[:3,3]).astype('f4')
                equal=imported.view('u4')==native.view('u4')
                transforms.append(dict(worldMatrix=matrix.tolist(),importedVerticesExact=int(np.all(equal,axis=1).sum()),
                    importedComponentsExact=int(equal.sum()),importedMaximumDifference=float(abs(imported-native).max())))
            rows.append(dict(meshIndex=mesh_index,primitiveIndex=primitive_index,nodes=nodes,vertices=len(positions),
                indices=len(indices),positionBounds=bounds(positions),uvBounds=bounds(uv),
                exactIndexSequence=bool(np.array_equal(indices,native_indices)),
                exactUvSequence=bool(np.array_equal(uv,native_uv)),
                directPositionMaxDifference=float(abs(delta).max()) if delta is not None else None,
                exactPositionVertices=int(np.all(delta==0,axis=1).sum()) if delta is not None else None,
                positionDifferenceBounds=bounds(delta) if delta is not None else None,imported=transforms))
level=json.loads((project/'assets/hair-coverage.azurelevel').read_text(encoding='utf-8-sig'))
views=json.loads((project/'config/reference-views.json').read_text(encoding='utf-8-sig'))['views']
camera=next(node['components']['azure.reference-camera']['data'] for node in level['nodes'] if node['id']=='camera')
view=views[camera['view']]
projection=view['projection'];frame=view['frame']
profile_bytes=struct.pack('<20f',*(value for col in projection['columns'] for value in col),*projection['jitter'],0,0)
frame_bytes=struct.pack('<4i4f',*frame['axes'],0,*frame['offset'],0)
assert profile_bytes==native_profile and frame_bytes==native_frame
model_nodes=[{k:v for k,v in node.items() if k in ('id','name','transform','parentId','kind','type','asset')}
    |{'components':list(node.get('components',{}))} for node in level['nodes']]
result=dict(material=document['materials'][material]['name'],sceneModelNodes=model_nodes,
    heroTransform=next(node['components']['azure.transform']['data'] for node in level['nodes'] if node['id']=='hero'),mesh=rows,
    authoredReferenceProfileExact=True,authoredReferenceFrameExact=True,authoredFlipNdcY=view['flipNdcY'],
    native=dict(vertices=len(native),indices=len(native_indices),positionBounds=bounds(native),uvBounds=bounds(native_uv)))
(out/'scene-depth-source-inspection.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:rows[0][k] for k in ('exactIndexSequence','exactUvSequence','exactPositionVertices','imported')},indent=2))
print('Authored reference projection and position-frame bytes match the source')
