from pathlib import Path
import json,struct,hashlib,shutil,subprocess,sys
out=Path(__file__).resolve().parent;root=out.parents[2];prior=out.parent/'20261111-065045-native-hair-production-coverage-7900c9';source=prior/'hair-project';target=out/'hair-project';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();frozen=json.loads((prior/'hair-copy-inputs.json').read_text());inputs=[]
pre=subprocess.run([sys.executable,str(root/'tools/artifact_budget.py'),'--build',str(root/'build'),'--run',str(out),'--planned-bytes',str(sum(v['bytes'] for v in frozen)+64*1024**2)],capture_output=True,text=True);(out/'fixture-preflight.json').write_text(pre.stdout);assert pre.returncode==0,pre.stdout+pre.stderr
for row in frozen:
 p=Path(row['destination']);assert sha(p)==row['sha256'];q=target/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True)
 if p.name=='hair-coverage.glb':
  with p.open('rb') as f:
   magic,version,total,oldSize,kind=struct.unpack('<4s4I',f.read(20));document=json.loads(f.read(oldSize));m=next(v for v in document['materials'] if v['name']=='M_actor_laevat_hair_01');coverage=m['extras']['azureRenderMaterial']['coverageTexture'];assert coverage['schemaVersion']==1 and coverage['channel']=='red';coverage.update(schemaVersion=2,lodPolicy='ellipse-major');payload=json.dumps(document,separators=(',',':'),ensure_ascii=False).encode();payload+=b' '*((-len(payload))%4);tail=hashlib.sha256()
   with q.open('wb') as w:
    w.write(struct.pack('<4s4I',magic,version,total-oldSize+len(payload),len(payload),kind));w.write(payload)
    while chunk:=f.read(4*1024**2):w.write(chunk);tail.update(chunk)
  assert tail.hexdigest()==json.loads((prior/'coverage-inputs.json').read_text())['binaryTail']
 else:shutil.copyfile(p,q);assert sha(q)==row['sha256']
 inputs.append(dict(destination=str(q),bytes=q.stat().st_size,sha256=sha(q)))
(out/'hair-copy-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');(out/'fixture-policy.json').write_text(json.dumps(dict(coverage=coverage,binaryTailSha256=tail.hexdigest(),profileSource='Same project, texture and sampler as the qualified private ellipse diagnosis'),indent=2)+'\n');print('Prepared version-two opt-in asset with frozen binary tail and unchanged textures')
