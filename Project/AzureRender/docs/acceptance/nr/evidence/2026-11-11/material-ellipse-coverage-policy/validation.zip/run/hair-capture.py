from pathlib import Path
import sys,os,json,hashlib,subprocess,re,runpy,numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;configuration=sys.argv[3];build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug');device=sys.argv[1];variant=sys.argv[2];project=out/'hair-project'/(variant+'.azureproject');label=configuration.lower()+'-'+device+'-'+variant;frames=out/(label+'-frames')
for row in json.loads((out/'hair-copy-inputs.json').read_text()):assert hashlib.sha256(Path(row['destination']).read_bytes()).hexdigest()==row['sha256'],row['destination']
env=os.environ.copy()
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
env.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*' if device=='nvidia' else '*igvk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
resource=build
command=[str(build/'AzurePlayer.exe'),'--project',str(project),'--width','2560','--height','1440','--capture-dir',str(frames),'--capture-frames','4','--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--disable-bindless','--disable-compute-skinning','--disable-parallel-recording','--runtime-report',str(out/(label+'-runtime.json')),'--resource-root',str(resource)]
(out/(label+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
with (out/(label+'.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=420)
text=(out/(label+'.log')).read_text(errors='replace');assert r.returncode==0 and not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',text,re.I) and 'Allocator after unload: buffers=0 images=0' in text,text[-5000:]
baseline=runpy.run_path(str(out.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'));mask=baseline['mask'];expected=baseline['expected'];frozen=baseline['frozen'];rows=[]
manifest=json.loads((frames/'capture_manifest.json').read_text());assert manifest['referenceCameraEnabled']==(variant!='hair-receiver'),manifest.get('referenceCameraEnabled')
sources=manifest['materialCoverageSources'];assert len(sources)==1 and sources[0]['lodPolicy']=='ellipse-major' and sources[0]['authoredMipLevels']==10 and sources[0]['sampler']['mipBias']==-1,sources
control=out.parent/'20261111-065045-native-hair-production-coverage-7900c9'/(device+'-hair-coverage-ellipse-frames')
for i in range(4):
 path=frames/f'frame_{i:06d}.png';rgb=np.asarray(Image.open(path).convert('RGB'))[130:440,1140:1430].astype('i4');error=abs(rgb-expected);bad=mask&(error.max(axis=2)>1);difference=abs(rgb-frozen)
 private=np.asarray(Image.open(control/path.name).convert('RGB'))[130:440,1140:1430].astype('i4')
 assert np.array_equal(rgb[mask],private[mask]),(configuration,device,i,int(np.any(rgb[mask]!=private[mask],axis=1).sum()))
 rows.append(dict(frame=i,maskPixels=int(mask.sum()),overOne=int(bad.sum()),maxByteError=int(error[mask].max()),meanAbsoluteByteError=float(error[mask].mean()),vsFrozenDifferentPixels=int((mask&np.any(difference!=0,axis=2)).sum()),vsFrozenMaxByteError=int(difference[mask].max()),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
result=dict(configuration=configuration,device=device,variant=variant,referenceEnabled=manifest['referenceCameraEnabled'],coverageSource=sources[0],cameraUniformBytes=manifest['cameraUniformBytes'],validationClean=True,allocatorZero=True,privateControlExact=True,frames=rows,sourceGate='17017 original native hair pixels; per-channel at most one byte');(out/(label+'-results.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

