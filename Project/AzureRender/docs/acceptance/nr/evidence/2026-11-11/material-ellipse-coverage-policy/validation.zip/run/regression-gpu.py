from pathlib import Path
import subprocess,sys

out=Path(__file__).resolve().parent
configuration,device=sys.argv[1:]
build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
tests=out.parents[2]/'tools'
def check(*args):
    command=[sys.executable,*map(str,args)]
    subprocess.run(command,cwd=out,check=True)

hair_result=out/(configuration.lower()+'-'+device+'-hair-coverage-results.json')
if not hair_result.exists():
    check(out/'hair-capture.py',device,'hair-coverage',configuration)
check(out/'ellipse-plane.py',device,configuration)
if device=='nvidia':
    check(out/'verify-render-modes.py',configuration,device)
    check(tests/'test_material_coverage_mips_gpu.py','--executable',build/'AzurePlayer.exe','--expected-validation','enabled' if configuration=='Debug' else 'disabled',
        '--case','slant-4','--output',out/(configuration.lower()+'-existing-coverage'))
