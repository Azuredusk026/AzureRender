$ErrorActionPreference = 'Stop'
$out = $PSScriptRoot
$root = (Get-Item -LiteralPath $out).Parent.Parent.Parent.FullName
$path = Join-Path $root 'schemas/azure_render_material.schema.json'
$coverageSchema = (Get-Content -LiteralPath $path -Raw | ConvertFrom-Json).properties.coverageTexture | ConvertTo-Json -Depth 20
$cases = @(
    @{ name = 'device'; accepted = $true; coverage = @{ schemaVersion = 1; texture = 0 } }
    @{ name = 'ellipse'; accepted = $true; coverage = @{ schemaVersion = 2; texture = 0; lodPolicy = 'ellipse-major' } }
    @{ name = 'missing-policy'; accepted = $false; coverage = @{ schemaVersion = 2; texture = 0 } }
    @{ name = 'device-policy'; accepted = $false; coverage = @{ schemaVersion = 1; texture = 0; lodPolicy = 'ellipse-major' } }
    @{ name = 'unknown-policy'; accepted = $false; coverage = @{ schemaVersion = 2; texture = 0; lodPolicy = 'other' } }
)
$rows = foreach ($case in $cases) {
    $inputJson = $case.coverage | ConvertTo-Json -Depth 6 -Compress
    $actual = Test-Json -Json $inputJson -Schema $coverageSchema -ErrorAction SilentlyContinue -ErrorVariable validationErrors
    if ($actual -ne $case.accepted) {
        throw "Unexpected material schema result for $($case.name) $($validationErrors | Out-String)"
    }
    @{ name = $case.name; accepted = $actual }
}
$rows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $out 'schema-results.json') -Encoding utf8
$rows | ConvertTo-Json -Compress
