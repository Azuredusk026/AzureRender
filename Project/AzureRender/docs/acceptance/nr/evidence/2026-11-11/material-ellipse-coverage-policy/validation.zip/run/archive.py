from pathlib import Path
import hashlib,json,zipfile

out=Path(__file__).resolve().parent
root=out.parents[2]
destination=root/'docs/acceptance/nr/evidence/2026-11-11/material-ellipse-coverage-policy'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
configurations=('release','debug')
devices=('nvidia','intel')
proof={name:load(out/(name+'-verification.json')) for name in configurations}
assert proof['release']['sha256']==proof['debug']['sha256']
assert all(p['cpuExit']==0 and p['count']==885 and p['validated']==44 for p in proof.values())
assert all(load(out/(name+'-lod-instructions.json'))['programs']==44 for name in configurations)
assert len(load(out/'schema-results.json'))==5
rows=[]
for config in configurations:
    build=load(out/(config+'-final-build-execution.json'))
    assert build['status']=='exited' and build['exitCode']==0
    for device in devices:
        hair=load(out/(config+'-'+device+'-hair-coverage-results.json'))
        plane=load(out/(config+'-'+device+'-ellipse-plane/summary.json'))
        assert hair['privateControlExact'] and hair['validationClean'] and hair['allocatorZero']
        assert len(hair['frames'])==4 and all(f['maskPixels']==17017 for f in hair['frames'])
        assert plane['selectedMip']==1 and plane['opaqueControlExact']
        expected=(43,5) if device=='nvidia' else (597,97)
        assert all((f['overOne'],f['maxByteError'])==expected for f in hair['frames'])
        rows.append(dict(hair=hair,plane=plane))
    failures=load(out/(config+'-nvidia-ellipse-plane/render-mode-rejections.json'))
    assert {f['mode'] for f in failures}=={'temporal','multisample'}
    assert load(out/(config+'-existing-coverage/summary.json'))['status']=='passed'
default=load(out/'default-four-results.json')
assert default['allExact'] and len(default['frames'])==4
config_match={}
for device in devices:
    frames={row['hair']['configuration']:row['hair']['frames'] for row in rows if row['hair']['device']==device}
    config_match[device]=[a['sha256']==b['sha256'] for a,b in zip(frames['Release'],frames['Debug'])]
source=load(out/'scene-depth-source-inspection.json')
assert source['mesh'][0]['exactIndexSequence'] and source['mesh'][0]['exactUvSequence']
assert source['mesh'][0]['imported'][0]['importedComponentsExact']==34692
assert source['authoredReferenceProfileExact'] and source['authoredReferenceFrameExact']
result=dict(status='qualified-opt-in-ellipse-coverage',overall='failed-user-review',baseCommit='dfb1ca3',
    maskPixels=17017,maximumAllowedByteError=1,scope='Single-sample spatial coverage',
    programs={name:{k:v for k,v in data.items() if k!='sha256'} for name,data in proof.items()},
    captures=rows,debugReleasePngExact=config_match,defaultRegression=default,run=out.name,
    sceneMeshSource=source,visibilityProbe=load(out/'visibility-intersection.json'))
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
members={}
next_stage_files={'native-depth-device-worker.py','inspect-iris-source.py','iris-source-inspection.json',
    'verify-next-native-source.py','next-native-source.json'}
for path in out.iterdir():
    if path.is_file() and path.suffix in {'.py','.ps1','.json','.xml','.log'} and path.name not in next_stage_files:
        members['run/'+path.name]=path
for glob in ('*/capture_manifest.json','*/summary.json','*/render-mode-rejections.json','*/*-rejection.log',
    '*/*/command.json','*/*/player.log','*/*/frames/capture_manifest.json'):
    for path in out.glob(glob):
        members['run/'+path.relative_to(out).as_posix()]=path
for name in ('docs/runtime/material-coverage.md','docs/plans/2026-11-11-material-ellipse-coverage-policy.md',
    'docs/acceptance/nr/material-ellipse-coverage-policy.md','schemas/azure_render_material.schema.json'):
    members['source/'+name]=root/name
destination.mkdir(parents=True,exist_ok=True)
manifest={name:dict(bytes=path.stat().st_size,sha256=sha(path)) for name,path in members.items()}
archive=destination/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as file:
    for name,path in sorted(members.items()):file.write(path,name)
    file.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as file:
    assert file.testzip() is None
    for name,metadata in manifest.items():
        assert hashlib.sha256(file.read(name)).hexdigest()==metadata['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']=dict(bytes=archive.stat().st_size,sha256=sha(archive),members=len(members)+1)
(destination/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['archive']))
