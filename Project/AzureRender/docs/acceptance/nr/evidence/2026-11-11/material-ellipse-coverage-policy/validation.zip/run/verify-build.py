from pathlib import Path
import hashlib,json,subprocess,sys

out=Path(__file__).resolve().parent
configuration=sys.argv[1]
build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
prior=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-11/reference-camera-render-binding'
old=json.loads((prior/'program-catalog.json').read_text())['sha256']
private=json.loads((out.parent/'20261111-065045-native-hair-production-coverage-7900c9/ellipse-program-scope.json').read_text())
sha=lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
current={p.name:sha(p) for p in (build/'shaders').glob('*.spv')}
changed=sorted(n for n in old if n in current and current[n]!=old[n])
assert current.keys()==old.keys() and len(current)<=1024
assert changed and set(changed)<={row['output'] for row in private},changed
validator='D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe'
with (out/(configuration.lower()+'-spirv.log')).open('wb') as log:
    for name in changed:
        subprocess.run([validator,'--target-env','vulkan1.2',str(build/'shaders'/name)],stdout=log,stderr=subprocess.STDOUT,check=True)
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
command=[ctest,'--test-dir',str(build),'-R','^AzureRender[.]MaterialCoverage$','--no-tests=error','--output-on-failure','--output-junit',str(out/(configuration.lower()+'-cpu.xml'))]
with (out/(configuration.lower()+'-cpu.log')).open('wb') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=90)
report=dict(configuration=configuration,count=len(current),unchanged=len(current)-len(changed),changed=changed,
    sha256=current,validated=len(changed),cpuExit=result.returncode,playerSha256=sha(build/'AzurePlayer.exe'))
(out/(configuration.lower()+'-verification.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('sha256','changed')}))
assert result.returncode==0,(out/(configuration.lower()+'-cpu.log')).read_text(errors='replace')
