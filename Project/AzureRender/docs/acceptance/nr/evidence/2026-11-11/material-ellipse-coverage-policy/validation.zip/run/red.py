from pathlib import Path
import subprocess,json,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
includes=Path('D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/include');command=['D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat','cl','/nologo','/c','/std:c++17','/utf-8','/EHsc','/I'+str(root/'src'),'/I'+str(includes),'/I'+str(includes/'stb'),'/ID:/Tools/VulkanSDK/1.4.350.0/Include',str(root/'tests/MaterialCoverageTests.cpp'),'/Fo'+str(out/'coverage-red.obj')]
started=time.monotonic()
while True:
 context=s.lease(s.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-coverage-contract-red',out)
 try:context.__enter__();break
 except ValueError as e:
  if 'busy' not in str(e) or time.monotonic()-started>=180:raise
  time.sleep(1)
try:
 r=subprocess.run(subprocess.list2cmdline(command),cwd=out,shell=True,capture_output=True,text=True,timeout=45);(out/'red.log').write_text(r.stdout+r.stderr);assert r.returncode!=0 and 'lodPolicy' in r.stdout and 'MaterialFeatureEllipseMajorCoverage' in r.stdout,r.stdout+r.stderr
 (out/'red-result.json').write_text(json.dumps(dict(baseCommit='dfb1ca3',command=command,exitCode=r.returncode,expected='Missing typed coverage LOD policy and feature bit'),indent=2)+'\n');print('Expected missing typed coverage LOD policy failure observed')
finally:context.__exit__(None,None,None)
