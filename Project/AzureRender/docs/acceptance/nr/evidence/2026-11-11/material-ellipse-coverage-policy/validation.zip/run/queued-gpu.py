from pathlib import Path
import json,os,sys,time

out=Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared

name,device,script,*args=sys.argv[1:]
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:
    os.environ.pop(key,None)
os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*' if device=='nvidia' else '*igvk64*',
    VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
started=time.monotonic()
while True:
    lease=shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-ellipse-'+name,out)
    try:
        lease.__enter__();break
    except ValueError as error:
        if not any(part in str(error) for part in ('busy','still running')):raise
        if time.monotonic()-started>=180:raise TimeoutError('GPU queue wait ended; no command executed')
        time.sleep(1)
try:
    result=shared.maintenance.guarded_run(out.parents[1],out.name,[sys.executable,str(out/script),*args],600)
    (out/(name+'-execution.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result));assert result['status']=='exited' and result['exitCode']==0,result
finally:
    lease.__exit__(None,None,None)
