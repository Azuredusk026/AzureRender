from pathlib import Path
import collections,json,struct,sys

out=Path(__file__).resolve().parent
configuration=sys.argv[1]
build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
proof=json.loads((out/(configuration+'-verification.json')).read_text())
scope={r['output']:r['source'] for r in json.loads((out.parent/'20261111-065045-native-hair-production-coverage-7900c9/ellipse-program-scope.json').read_text())}
rows={}
for name in proof['changed']:
    raw=(build/'shaders'/name).read_bytes()
    words=struct.unpack('<'+'I'*(len(raw)//4),raw)
    assert words[0]==0x07230203
    position=5
    counts=collections.Counter()
    while position<len(words):
        count,operation=divmod(words[position],65536)
        assert count>0 and position+count<=len(words)
        # OpImageSampleExplicitLod operands: result type, result, image, coordinate, image operands.
        if operation==88:
            operands=words[position+5]
            if operands&2:counts['Lod']+=1
            if operands&4:counts['Grad']+=1
        position+=count
    assert counts['Lod'] and counts['Grad'],(name,counts)
    rows[name]=dict(source=scope[name],lod=counts['Lod'],grad=counts['Grad'])
result=dict(programs=len(rows),families=dict(collections.Counter(row['source'] for row in rows.values())),samples=rows)
(out/(configuration+'-lod-instructions.json')).write_text(json.dumps(result,indent=2)+'\n')
print(result['programs'],result['families'])
