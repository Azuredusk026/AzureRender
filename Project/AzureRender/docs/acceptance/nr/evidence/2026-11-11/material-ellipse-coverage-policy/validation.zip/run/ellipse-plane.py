from pathlib import Path
import base64,hashlib,json,math,re,struct,subprocess,sys,uuid

import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
sys.path.insert(0,str(out.parents[2]/'tools'))
from test_material_coverage_mips_gpu import prepare

device,configuration=sys.argv[1:]
build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
folder=out/(configuration.lower()+'-'+device+'-ellipse-plane');folder.mkdir()
rows={};images={}

def dds(path,values):
    header=bytearray(148)
    for off,value in {0:0x20534444,4:124,8:0x2100f,12:64,16:64,20:256,28:7,76:32,80:4,84:0x30315844,108:0x401008,128:28,132:3,140:1}.items():
        struct.pack_into('<I',header,off,value)
    path.write_bytes(header+b''.join(bytes((value,0,0,255))*((64>>level)**2) for level,value in enumerate(values)))

for mode in ('ellipse','opaque-level','transparent-level'):
    case=folder/mode;project,extent,side,_=prepare(case,'slant',4,True)
    path=case/'plane.gltf';asset=json.loads(path.read_text());profile=asset['materials'][0]['extras']['azureRenderMaterial']
    profile['features']=['mirrored-coarse-uv'];asset['images'][0]['uri']='coverage.dds'
    profile['coverageTexture'].update(schemaVersion=2,lodPolicy='ellipse-major')
    if mode!='ellipse':profile['coverageTexture']=dict(schemaVersion=1,texture=0,channel='red')
    dds(case/'coverage.dds',{'ellipse':[0,255,0,0,0,0,0],'opaque-level':[255]*7,'transparent-level':[0]*7}[mode])
    sampler=json.loads((case/'coverage.png.azmeta').read_text())
    sampler['id']=str(uuid.uuid5(uuid.NAMESPACE_URL,'azurerender/ellipse-plane/'+mode+'/coverage.dds'))
    sampler['settings']['texture']['mipBias']=-1
    (case/'coverage.dds.azmeta').write_text(json.dumps(sampler))
    data=bytearray(base64.b64decode(asset['buffers'][0]['uri'].split(',')[1]));offset=asset['bufferViews'][2]['byteOffset']
    # With one world unit per pixel, both axes have length 2.4 texels.
    u=2.4*side/64;v=.01*side/64
    for tile in range(64):struct.pack_into('<8f',data,offset+tile*32,0,0,u,0,2*u,v,u,v)
    asset['buffers'][0]['uri']='data:application/octet-stream;base64,'+base64.b64encode(data).decode()
    path.write_text(json.dumps(asset))
    command=[str(build/'AzurePlayer.exe'),'--project',str(project),'--width',str(extent),'--height',str(extent),'--capture-dir',str(case/'frames'),
        '--capture-frames','1','--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','albedo','--resource-root',str(build)]
    (case/'command.json').write_text(json.dumps(command,indent=2))
    with (case/'player.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    log=(case/'player.log').read_text(errors='replace')
    assert result.returncode==0 and not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log),log[-4000:]
    assert 'Allocator after unload: buffers=0 images=0' in log
    frame=case/'frames/frame_000000.png';images[mode]=np.asarray(Image.open(frame).convert('RGB'))
    sources=json.loads((frame.parent/'capture_manifest.json').read_text())['materialCoverageSources']
    assert len(sources)==1 and sources[0]['lodPolicy']==('ellipse-major' if mode=='ellipse' else 'device') and sources[0]['authoredMipLevels']==7,sources
    rows[mode]={'sha256':hashlib.sha256(frame.read_bytes()).hexdigest(),'source':sources[0]}

assert np.array_equal(images['ellipse'],images['opaque-level']),'Explicit LOD did not select opaque level one'
pixels=int(np.any(images['ellipse']!=images['transparent-level'],axis=2).sum())
assert pixels==64*side*side,(pixels,64*side*side)
report=dict(configuration=configuration,device=device,extent=extent,ellipseLodAfterBias=math.log2(2.4*math.sqrt(2))-1,
    selectedMip=1,positivePixels=pixels,opaqueControlExact=True,cases=rows,validationClean=True,allocatorZero=True)
(folder/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
