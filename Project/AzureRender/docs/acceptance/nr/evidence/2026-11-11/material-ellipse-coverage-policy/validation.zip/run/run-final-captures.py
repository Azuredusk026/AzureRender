from pathlib import Path
import json,subprocess,sys,time

out=Path(__file__).resolve().parent
queue=Path('D:/Projects/FYP-coordination/resources/current.json')

def wait_for_queue_change(blocked_token=None):
    deadline=time.monotonic()+3600
    while time.monotonic()<deadline:
        try:
            state=json.loads(queue.read_text(encoding='utf-8'))
        except (OSError,ValueError):
            time.sleep(2)
            continue
        if state.get('state')!='held' or (state.get('token')!=blocked_token and 'build' not in state.get('task','')):
            return state.get('token')
        time.sleep(2)
    raise TimeoutError('No shared queue change observed in the wait window')

cases=(
    ('debug-nvidia','nvidia','regression-gpu.py','Debug','nvidia'),
    ('debug-intel','intel','regression-gpu.py','Debug','intel'),
    ('default-four','nvidia','default-four.py'),
)
blocked_token=sys.argv[1] if len(sys.argv)>1 else None
for case in cases:
    receipt=out/(case[0]+'-execution.json')
    if receipt.exists():
        result=json.loads(receipt.read_text())
        if result['status']=='exited' and result['exitCode']==0:
            continue
        raise RuntimeError('Previous execution needs investigation: '+case[0])
    while True:
        token=wait_for_queue_change(blocked_token)
        print('Queue request '+case[0],flush=True)
        result=subprocess.run([sys.executable,str(out/'queued-gpu.py'),*case],capture_output=True,text=True)
        print(result.stdout,flush=True,end='')
        if not result.returncode:
            blocked_token=None
            break
        print(result.stderr,flush=True,end='',file=sys.stderr)
        if receipt.exists() or 'GPU queue wait ended; no command executed' not in result.stderr:
            raise RuntimeError('Execution needs investigation: '+case[0])
        try:
            blocked_token=json.loads(queue.read_text(encoding='utf-8')).get('token',token)
        except (OSError,ValueError):
            blocked_token=token
    time.sleep(4)
