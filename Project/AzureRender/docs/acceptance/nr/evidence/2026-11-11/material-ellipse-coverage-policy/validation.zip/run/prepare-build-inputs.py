from pathlib import Path
import json,sys

out=Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared

p=Path('D:/Projects/FYP-coordination/quality-claim.json')
claim=json.loads(p.read_text(encoding='utf-8'))
assert Path(claim['taskPath'])==out
if not claim['inputLease']:
    token=shared.acquire_inputs(shared.DEFAULT_BUILD,out,['20261103-234012-character-reference-stages-5abe6c'],claim['threadId'])
    claim['inputLease']=[token]
    p.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ('20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2'):
    shared.maintenance.resume(out.parents[1],name)
print('Original frame inputs leased; parent build runs resumed')
