from pathlib import Path
import json,zipfile,hashlib,re
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=json.loads((out/'results.json').read_text())
plan=root/'docs/plans/2026-11-11-project-reference-views.md';plan.write_text(plan.read_text(encoding='utf-8').replace('- [ ]','- [x]'),encoding='utf-8')
for name,prefix in [('README.md','docs/'),('docs/project-status.md',''),('docs/plans/azure-engine-plan.md','../'),('docs/plans/2026-11-09-native-quality.md','../')]:
 p=root/name;text=p.read_text(encoding='utf-8')
 if '[项目参考视图配置]' not in text:text+='\n[项目参考视图配置]('+prefix+'acceptance/nr/project-reference-views.md)通过版本、参数位值、保存重开及目录移动核对。\n两配置项目契约及当前原四帧通过，场景选择继续接入。\n'
 p.write_text(text,encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');anchor='## 2026-11-11 参考光栅位置'
if '## 2026-11-11 项目参考视图' not in text:text=text.replace(anchor,'## 2026-11-11 项目参考视图\n\n- 提供严格参考视图 JSON 编解码及具名项目配置的有界读写。\n- 保存、项目重开及目录移动保持实际投影和坐标帧位值。\n- 两配置通过八组 CPU 检查及二十二类非法输入拒绝。\n- 原四帧重新采集后摘要精确一致，全部 859 份程序保持相同。\n- Debug 符号配额失败完成回收和重检，场景绑定与整体外观继续推进。\n\n'+anchor)
p.write_text(text,encoding='utf-8')
sources=list(result['sourceSha256'])+['docs/runtime/project-reference-views.md','docs/plans/2026-11-11-project-reference-views.md','docs/acceptance/nr/project-reference-views.md']
files={'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.ps1','.json','.log','.cpp'}};files.update({'source/'+n:root/n for n in sources})
for name,path in [('native-profile.bin',out.parent/'20261110-165124-reference-depth-source-4d1d7d/native-profile.bin'),('native-frame.bin',out.parent/'20261111-001326-reference-position-frame-482201/native-frame.bin')]:files['inputs/'+name]=path
dest=root/'docs/acceptance/nr/evidence/2026-11-11/project-reference-views';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']=dict(bytes=archive.stat().st_size,sha256=sha(archive),members=len(members)+1);(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n')
for n in [v for v in sources if v.endswith('.md')]:
 p=root/n;text=p.read_text(encoding='utf-8')
 for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(n,sentence)
 for link in re.findall(r'\]\(([^)]+)\)',text):
  if not re.match(r'(https?:|#)',link):assert (p.parent/link.split('#')[0]).exists(),(n,link)
print(json.dumps(result['archive']))
