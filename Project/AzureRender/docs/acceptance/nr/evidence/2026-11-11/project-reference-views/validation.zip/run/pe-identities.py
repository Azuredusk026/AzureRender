from pathlib import Path
import json,hashlib,struct,sys
out=Path(__file__).resolve().parent
def pe(p):
 data=p.read_bytes();at=struct.unpack_from('<I',data,60)[0];assert data[at:at+4]==b'PE\0\0';count=struct.unpack_from('<H',data,at+6)[0];optional=struct.unpack_from('<H',data,at+20)[0];base=at+24+optional;sections={}
 for i in range(count):
  pos=base+i*40;name=data[pos:pos+8].split(b'\0')[0].decode('ascii');size,start=struct.unpack_from('<II',data,pos+16);sections[name]=hashlib.sha256(data[start:start+size]).hexdigest()
 return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),sections=sections)
result={}
for c,parent in [('release','20261110-030251-hair-main-chroma-public-9e799c'),('debug','20261110-031856-hair-main-chroma-debug-668bf2')]:
 result[c]={name:pe(out.parent/parent/c/(name+'.exe')) for name in ['AzureRender','AzurePlayer','AzureGameLauncher'] if (out.parent/parent/c/(name+'.exe')).exists()}
(out/(sys.argv[1]+'-pe-identities.json')).write_text(json.dumps(result,indent=2)+'\n');print(sys.argv[1]+' PE fingerprints saved')
