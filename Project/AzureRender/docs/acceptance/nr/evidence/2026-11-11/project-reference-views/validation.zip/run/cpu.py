from pathlib import Path
import subprocess,json,sys,os,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,v in json.loads((out/'frozen-source.json').read_text()).items():assert sha(root/n)==v,n
for c,parent in [('release','20261110-030251-hair-main-chroma-public-9e799c'),('debug','20261110-031856-hair-main-chroma-debug-668bf2')]:
 build=out.parent/parent/c;env=os.environ.copy();env['PATH']=str(build)+';'+env['PATH']
 commands=[[str(build/'AzureProjectReferenceViewsTests.exe')],[str(build/'AzureProjectReferenceViewsTests.exe'),str(out.parent/'20261110-165124-reference-depth-source-4d1d7d/native-profile.bin'),str(out.parent/'20261111-001326-reference-position-frame-482201/native-frame.bin')],[str(build/'AzureProjectTests.exe')],[str(build/'AzureReferenceCameraViewTests.exe')]]
 for i,command in enumerate(commands):
  label=c+'-'+str(i);r=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,timeout=120);(out/(label+'-cpu.log')).write_text(r.stdout+r.stderr);rows.append(dict(configuration=c,command=command,exitCode=r.returncode,stdout=r.stdout.strip(),binarySha256=sha(Path(command[0]))));(out/'cpu-results.json').write_text(json.dumps(rows,indent=2)+'\n');assert r.returncode==0,r.stdout+r.stderr;print(label,r.stdout.strip(),flush=True)
assert len(rows)==8
