param([Parameter(Mandatory=$true)][string]$Plan)
$ErrorActionPreference='Stop'
$qualityPlan=Get-Content -LiteralPath $Plan -Raw | ConvertFrom-Json
$qualityRoot=(Resolve-Path -LiteralPath $qualityPlan.root).Path.TrimEnd('\')+'\'
$qualityStarted=Get-Date
for($qualityAt=0;$qualityAt -lt $qualityPlan.files.Count;$qualityAt+=10){
    if(((Get-Date)-$qualityStarted).TotalSeconds -gt 120){throw 'Maintenance time budget reached'}
    $qualityQueue=Get-Content -LiteralPath D:/Projects/FYP-coordination/resources/current.json -Raw | ConvertFrom-Json
    if($qualityQueue.state -ne 'held' -or $qualityQueue.owner -ne '01a1c099-8121-7be3-b0b8-7af2f9a06b2a' -or $qualityQueue.task -ne 'quality-debug-symbol-budget'){throw 'Expected exclusive maintenance lease'}
    $qualityEnd=[Math]::Min($qualityAt+10,$qualityPlan.files.Count)
    for($qualityIndex=$qualityAt;$qualityIndex -lt $qualityEnd;$qualityIndex++){
        $qualityFile=$qualityPlan.files[$qualityIndex]
        $qualityPath=(Resolve-Path -LiteralPath $qualityFile.path).Path
        if(-not $qualityPath.StartsWith($qualityRoot,[StringComparison]::OrdinalIgnoreCase) -or (Split-Path $qualityPath -Parent) -ne $qualityRoot.TrimEnd('\') -or -not $qualityPath.EndsWith('Tests.pdb',[StringComparison]::OrdinalIgnoreCase)){throw 'Unexpected symbol path'}
        $qualityHasher=[System.Security.Cryptography.SHA256]::Create()
        try{$qualityHash=[BitConverter]::ToString($qualityHasher.ComputeHash([System.IO.File]::ReadAllBytes($qualityPath))).Replace('-','').ToLowerInvariant()}finally{$qualityHasher.Dispose()}
        if($qualityHash -ne $qualityFile.sha256){throw 'Symbol identity changed'}
        Remove-Item -LiteralPath $qualityPath
    }
}
Write-Output ('Reclaimed '+$qualityPlan.files.Count+' rebuildable test PDB files in bounded batches')
