from pathlib import Path
import json,hashlib,subprocess,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];build=out.parent/'20261110-031856-hair-main-chroma-debug-668bf2/debug';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();label=sys.argv[1] if len(sys.argv)>1 else ''
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
with s.lease(s.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-debug-symbol-budget',out):
 files=sorted(build.glob('*Tests.pdb'));assert 1<=len(files)<=13
 for p in files:
  assert p.resolve().parent==build.resolve() and not p.is_symlink()
  tracked=subprocess.run(['git','ls-files','--',str(p)],cwd=root,capture_output=True,text=True,check=True).stdout;assert not tracked
 protected=list(build.glob('*.exe'))+list(build.glob('*.lib'))+list((build/'shaders').glob('*.spv'));before={str(p):sha(p) for p in protected}
 plan=dict(root=str(build.resolve()),files=[dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=sha(p),rebuild='cmake --build '+str(build)+' --target '+p.stem) for p in files],protectedSha256=before)
 (out/(label+'symbol-reclaim-plan.json')).write_text(json.dumps(plan,indent=2)+'\n');started=time.monotonic()
 r=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','RemoteSigned','-File',str(out/'reclaim-symbols.ps1'),'-Plan',str(out/(label+'symbol-reclaim-plan.json'))],capture_output=True,text=True,timeout=120)
 (out/(label+'symbol-reclaim.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
 assert all(not p.exists() for p in files);assert all(sha(Path(p))==v for p,v in before.items())
 receipt=dict(status='reclaimed-rebuildable-test-symbols',files=len(files),batches=(len(files)+9)//10,logicalBytes=sum(p['bytes'] for p in plan['files']),protectedProductsExact=len(before),seconds=time.monotonic()-started)
 (out/(label+'symbol-reclaim-results.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
