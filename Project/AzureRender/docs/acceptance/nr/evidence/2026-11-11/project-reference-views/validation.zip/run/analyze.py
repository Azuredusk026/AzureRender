from pathlib import Path
import json,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((out/'frozen-source.json').read_text());assert all(sha(root/n)==v for n,v in sources.items())
cpu=json.loads((out/'cpu-results.json').read_text());assert len(cpu)==8 and all(v['exitCode']==0 for v in cpu)
for c in ['release','debug']:
 rows=[r for r in cpu if r['configuration']==c];assert len(rows)==4
 assert '2 reference views' in rows[0]['stdout'] and '3 reference views' in rows[1]['stdout']
 assert all('22 JSON rejections' in rows[i]['stdout'] for i in [0,1]);assert 'Project contracts passed' in rows[2]['stdout']
 assert '16 rejects' in rows[3]['stdout']
 builds=[json.loads((out/(c+'-final-build-execution.json')).read_text())];assert builds[0]['status']=='exited' and builds[0]['exitCode']==0
catalog=json.loads((root/'docs/acceptance/nr/evidence/2026-11-11/reference-raster-projection/program-catalog.json').read_text())['sha256'];assert len(catalog)==859
identities=[]
for c,parent in [('release','20261110-030251-hair-main-chroma-public-9e799c'),('debug','20261110-031856-hair-main-chroma-debug-668bf2')]:
 b=out.parent/parent/c
 assert all(sha(b/'shaders'/n)==v for n,v in catalog.items())
 for row in [r for r in cpu if r['configuration']==c]:assert sha(Path(row['command'][0]))==row['binarySha256']
 names=['AzurePlayer','AzureRender','AzureGameLauncher'] if c=='release' else ['AzurePlayer']
 identities.append(dict(configuration=c,programsExact=859,hosts={n:sha(b/(n+'.exe')) for n in names}))
failure=json.loads((out/'debug-initial-budget-execution.json').read_text());assert failure['status']=='budget-stopped'
reclaims=[json.loads((out/(prefix+'symbol-reclaim-results.json')).read_text()) for prefix in ['', 'second-']];assert [r['files'] for r in reclaims]==[13,3]
four=json.loads((out/'default-four-results.json').read_text());assert four['allExact'] and four['validationClean'] and four['allocatorZero'];execution=json.loads((out/'four-execution.json').read_text());assert execution['status']=='exited' and execution['exitCode']==0
result=dict(status='qualified-project-reference-view-codec-and-persistence',overall='failed-user-review',baseCommit='746ba12',sourceSha256=sources,cpu=cpu,identities=identities,defaultFour=four,fourExecution=execution,debugBudgetFailure=failure,reclaimedTestSymbols=reclaims,symbolLogicalBytesReclaimed=sum(r['logicalBytes'] for r in reclaims),sceneHostBinding='pending',remaining=['Project reference view selection in scene host','Production hair 73 color failures','Intel reference depth/visibility 96 failures','Skin, eyes, GI, reflection and dynamic appearance gates'])
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],cpuChecks=8,oldProgramsExact=859,defaultFourExact=True,symbolLogicalBytesReclaimed=result['symbolLogicalBytesReclaimed']),indent=2))
