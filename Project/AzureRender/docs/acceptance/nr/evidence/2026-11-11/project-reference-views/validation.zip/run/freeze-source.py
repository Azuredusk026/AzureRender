from pathlib import Path
import json,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((out/'frozen-source.json').read_text());(out/'frozen-source.json').write_text(json.dumps({n:sha(root/n) for n in old},indent=2)+'\n')
print('Six final source files fingerprinted; before-host identities retained')
