from pathlib import Path
import json,hashlib,sys
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=['CMakeLists.txt','src/render/ReferenceCameraViewJson.hpp','src/render/ReferenceCameraViewJson.cpp','src/runtime/ProjectReferenceViews.hpp','src/runtime/ProjectReferenceViews.cpp','tests/ProjectReferenceViewsTests.cpp']
(out/'frozen-source.json').write_text(json.dumps({n:sha(root/n) for n in files},indent=2)+'\n')
for n in ['20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2']:s.maintenance.resume(root/'build',n)
(out/'before-player-sha256.json').write_text(json.dumps({c:sha(out.parent/b/c/'AzurePlayer.exe') for c,b in [('release','20261110-030251-hair-main-chroma-public-9e799c'),('debug','20261110-031856-hair-main-chroma-debug-668bf2')]},indent=2)+'\n')
source=(out.parent/'20261111-022111-reference-raster-projection-bc4b9a/build.py').read_text();source=source.replace("'AzureReferenceRasterProjectionGpuTests'","'AzureProjectReferenceViewsTests','AzureProjectTests','AzureReferenceCameraViewTests','AzureRender','AzurePlayer','AzureGameLauncher'");(out/'build.py').write_text(source)
source=(out.parent/'20261111-022111-reference-raster-projection-bc4b9a/queued-build.py').read_text().replace('quality-reference-raster-','quality-project-reference-views-');(out/'queued-build.py').write_text(source)
print('Project codec frozen; two-config affected tests and three actual hosts selected')
