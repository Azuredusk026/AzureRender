from pathlib import Path
import json,sys,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a';cp=Path('D:/Projects/FYP-coordination/quality-claim.json');claim=json.loads(cp.read_text(encoding='utf-8'))
parents=['20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2'];token=s.acquire_inputs(root/'build',out,parents,owner)
for n in parents+['20261111-022111-reference-raster-projection-bc4b9a']:s.maintenance.seal(root/'build',out.parent/n)
for t in claim.get('localInputLease',[]):s.release_inputs(root/'build',t,owner)
claim.update(state='project-reference-views',lastCommit='746ba12',taskPath=str(out),localInputLease=[token],inputLease=[],ownedFiles=['src/render/ReferenceCameraViewJson.hpp','src/render/ReferenceCameraViewJson.cpp','src/runtime/ProjectReferenceViews.hpp','src/runtime/ProjectReferenceViews.cpp','tests/ProjectReferenceViewsTests.cpp','CMakeLists.txt'],pendingCommand='Versioned project reference view persistence with strict numeric validation and save/reopen/move checks')
cp.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'task-card.json').write_text(json.dumps(dict(baseCommit='746ba12',started=time.time(),locationSeconds=600,candidateSeconds=1200,explorationSeconds=1800,buildSeconds=1200,cpuSeconds=180,plannedBytes=100663296,deliverable='Reference camera JSON codec and explicit project sidecar persistence; actual project reopen and directory move; scene binding follows independently',gateSource='AGENT.md public API, versioned configuration, invalid input, save/reopen, failure recovery and module boundary gates'),indent=2)+'\n')
print('Raster unit sealed, leases transferred, project persistence claim recorded')
