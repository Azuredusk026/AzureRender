from pathlib import Path
import sys,json,subprocess,hashlib,os,re
out=Path(__file__).resolve().parent;root=out.parents[2];c=sys.argv[1].lower();parent='20261110-030251-hair-main-chroma-public-9e799c' if c=='release' else '20261110-031856-hair-main-chroma-debug-668bf2';build=out.parent/parent/c;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,v in json.loads((out/'frozen-source.json').read_text()).items():assert sha(root/n)==v,n
commands=[[str(build/'AzureReferenceCameraSelectionTests.exe')],[str(build/'AzureReferenceCameraSelectionTests.exe'),str(out.parent/'20261110-165124-reference-depth-source-4d1d7d/native-profile.bin'),str(out.parent/'20261111-001326-reference-position-frame-482201/native-frame.bin')]]
commands += [[str(build/(n+'.exe'))] for n in ['AzureReferenceCameraMacroTests','AzureCameraSystemTests','AzureComponentRegistryTests','AzureProjectReferenceViewsTests']]
env=os.environ.copy();env['PATH']=str(build)+';'+env['PATH'];rows=[]
for i,command in enumerate(commands):
 r=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,timeout=120);t=r.stdout+r.stderr;(out/(c+'-'+str(i)+'-cpu.log')).write_text(t);row=dict(configuration=c,command=command,exitCode=r.returncode,stdout=r.stdout.strip(),binarySha256=sha(Path(command[0])));rows.append(row);(out/(c+'-cpu-results.json')).write_text(json.dumps(rows,indent=2)+'\n');assert r.returncode==0,t
 if i<2:
  error=float(re.search(r'maximumPixelError=([\d.eE+-]+)',t).group(1));assert error<=1/256;row['maximumPixelError']=error
 print(c+'-'+str(i),r.stdout.strip(),flush=True)
(out/(c+'-cpu-results.json')).write_text(json.dumps(rows,indent=2)+'\n')
