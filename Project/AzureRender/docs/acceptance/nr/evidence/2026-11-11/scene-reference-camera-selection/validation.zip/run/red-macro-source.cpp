#define near
#define far
#include "macro-failed-header.hpp"
int main(){return 0;}
