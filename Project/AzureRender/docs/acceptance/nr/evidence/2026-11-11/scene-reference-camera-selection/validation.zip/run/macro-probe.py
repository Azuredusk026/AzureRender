from pathlib import Path
import sys,subprocess,json
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
with s.lease(s.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-reference-camera-macro-probe',out):
 target=root/'tests/ReferenceCameraMacroTests.cpp'
 if sys.argv[1]=='red':
  target=out/'red-macro-source.cpp';target.write_text('#define near\n#define far\n#include "macro-failed-header.hpp"\nint main(){return 0;}\n')
 command=['D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat','cl','/nologo','/std:c++17','/EHsc','/Zs','/I'+str(root/'src'),str(target)]
 r=subprocess.run(subprocess.list2cmdline(command),shell=True,cwd=root,capture_output=True,text=True);(out/(sys.argv[1]+'-macro.log')).write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);expected=0 if sys.argv[1]=='green' else 2
 if expected==0:assert r.returncode==0
 else:assert r.returncode!=0 and 'C2513' in r.stdout+r.stderr
 (out/(sys.argv[1]+'-macro.json')).write_text(json.dumps(dict(command=command,exitCode=r.returncode,expectedFailure=expected!=0),indent=2)+'\n')
