from pathlib import Path
import json,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];old=json.loads((out/'frozen-source.json').read_text());(out/'frozen-source.json').write_text(json.dumps({n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in old},indent=2)+'\n');print('Final source identities frozen without replacing prior host receipts')
