from pathlib import Path
import json,zipfile,hashlib,re
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=json.loads((out/'results.json').read_text())
plan=root/'docs/plans/2026-11-11-scene-reference-camera-selection.md';plan.write_text(plan.read_text(encoding='utf-8').replace('- [ ]','- [x]'),encoding='utf-8')
for name,prefix in [('README.md','docs/'),('docs/project-status.md',''),('docs/plans/azure-engine-plan.md','../'),('docs/plans/2026-11-09-native-quality.md','../')]:
 p=root/name;text=p.read_text(encoding='utf-8')
 if '[场景参考相机选择]' not in text:text+='\n[场景参考相机选择]('+prefix+'acceptance/nr/scene-reference-camera-selection.md)通过持久锚点、刚性移动及优先级核对。\n两配置十二组检查及当前原四帧通过，光栅与拾取消费继续接入。\n'
 p.write_text(text,encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');anchor='## 2026-11-11 项目参考视图'
if '## 2026-11-11 场景参考相机' not in text:text=text.replace(anchor,'## 2026-11-11 场景参考相机\n\n- 注册独立参考相机组件、具名视图选择及持久刚性锚点。\n- 项目宿主与运行预览装配同一视图集合，失效引用保留诊断。\n- 两配置十二组 CPU 检查通过，实际原生来源移动误差满足门槛。\n- 修正 Win32 宏与局部变量的名称冲突，新增宏回归目标。\n- 全部 859 份程序保持相同，当前原四帧重新采集后摘要精确一致。\n- CPU 合约夹具保留 Debug 代码及运行库，链接符号按预算管理。\n\n'+anchor)
p.write_text(text,encoding='utf-8')
sources=list(result['sourceSha256'])+['docs/runtime/scene-reference-camera.md','docs/plans/2026-11-11-scene-reference-camera-selection.md','docs/acceptance/nr/scene-reference-camera-selection.md']
files={'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log','.cpp','.hpp'}};files.update({'source/'+n:root/n for n in sources})
for name,path in [('native-profile.bin',out.parent/'20261110-165124-reference-depth-source-4d1d7d/native-profile.bin'),('native-frame.bin',out.parent/'20261111-001326-reference-position-frame-482201/native-frame.bin')]:files['inputs/'+name]=path
dest=root/'docs/acceptance/nr/evidence/2026-11-11/scene-reference-camera-selection';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']=dict(bytes=archive.stat().st_size,sha256=sha(archive),members=len(members)+1);(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n')
for n in [v for v in sources if v.endswith('.md')]:
 p=root/n;text=p.read_text(encoding='utf-8')
 for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(n,sentence)
 for link in re.findall(r'\]\(([^)]+)\)',text):
  if not re.match(r'(https?:|#)',link):assert (p.parent/link.split('#')[0]).exists(),(n,link)
print(json.dumps(result['archive']))
