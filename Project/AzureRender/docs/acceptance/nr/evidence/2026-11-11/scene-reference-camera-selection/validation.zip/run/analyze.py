from pathlib import Path
import json,hashlib,re
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sources=json.loads((out/'frozen-source.json').read_text());assert all(sha(root/n)==v for n,v in sources.items())
rows=[];identities=[];catalog=json.loads((root/'docs/acceptance/nr/evidence/2026-11-11/reference-raster-projection/program-catalog.json').read_text())['sha256'];assert len(catalog)==859
for c,parent in [('release','20261110-030251-hair-main-chroma-public-9e799c'),('debug','20261110-031856-hair-main-chroma-debug-668bf2')]:
 data=json.loads((out/(c+'-cpu-results.json')).read_text());assert len(data)==6 and all(r['exitCode']==0 for r in data)
 assert all(r['maximumPixelError']<=1/256 for r in data[:2]);rows+=data;b=out.parent/parent/c
 assert all(sha(Path(r['command'][0]))==r['binarySha256'] for r in data)
 execution=json.loads((out/(c+'-final-build-execution.json')).read_text());assert execution['status']=='exited' and execution['exitCode']==0
 assert all(sha(b/'shaders'/n)==v for n,v in catalog.items());names=['AzurePlayer','AzureRender','AzureGameLauncher'] if c=='release' else ['AzurePlayer'];identities.append(dict(configuration=c,programsExact=859,hosts={n:sha(b/(n+'.exe')) for n in names},build=execution))
assert json.loads((out/'red-macro.json').read_text())['exitCode']!=0 and json.loads((out/'green-macro.json').read_text())['exitCode']==0
four=json.loads((out/'default-four-results.json').read_text());assert four['allExact'] and four['validationClean'] and four['allocatorZero'];execution=json.loads((out/'four-execution.json').read_text());assert execution['status']=='exited' and execution['exitCode']==0
result=dict(status='qualified-scene-reference-camera-selection-and-rigid-calibration',overall='failed-user-review',baseCommit='80719a9',sourceSha256=sources,cpu=rows,identities=identities,maximumPixelError=max(r['maximumPixelError'] for r in rows if 'maximumPixelError' in r),nativeMaximumPixelError=max(rows[i]['maximumPixelError'] for i in [1,7]),pixelErrorBudget=1/256,shaderProgramsAdded=0,defaultFour=four,fourExecution=execution,referenceMacroFix='near local variable renamed to nearPoint; red/green macro probe and two-config actual host integration verified',remaining=['Reference raster and picking consumers','Production hair 73 color failures','Intel reference depth/visibility 96 failures','Skin, eyes, GI, reflection and dynamic appearance gates'])
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],cpuChecks=12,maximumPixelError=result['maximumPixelError'],nativeMaximumPixelError=result['nativeMaximumPixelError'],oldProgramsExact=859,shaderProgramsAdded=0,defaultFourExact=True),indent=2))
