from pathlib import Path
import json,hashlib,sys
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=['CMakeLists.txt','src/render/ReferenceCameraCalibration.hpp','src/render/ReferenceCameraView.hpp','src/ecs/ReferenceCameraComponents.hpp','src/runtime/camera/GameCameraService.hpp','src/runtime/camera/GameCameraService.cpp','src/runtime/GameRuntime.hpp','src/runtime/GameRuntime.cpp','src/runtime/ComponentRegistry.cpp','src/app/AzureRenderApp.cpp','src/editor/EditorSession.cpp','tests/ReferenceCameraSelectionTests.cpp','tests/ReferenceCameraMacroTests.cpp']
(out/'frozen-source.json').write_text(json.dumps({n:sha(root/n) for n in files},indent=2)+'\n')
for n in ['20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2']:s.maintenance.resume(root/'build',n)
old=out.parent/'20261111-023832-project-reference-views-0bb44d'
source=(old/'build.py').read_text();source=source.replace("targets=['AzureProjectReferenceViewsTests','AzureProjectTests','AzureReferenceCameraViewTests','AzurePlayer']","targets=['AzureReferenceCameraSelectionTests','AzureReferenceCameraMacroTests','AzureCameraSystemTests','AzureComponentRegistryTests','AzureProjectReferenceViewsTests','AzurePlayer']")
(out/'build.py').write_text(source);(out/'queued-build.py').write_text((old/'queued-build.py').read_text().replace('quality-project-reference-views-','quality-scene-reference-camera-'))
(out/'before-hosts.json').write_text(json.dumps({c:{n:sha(out.parent/b/c/(n+'.exe')) for n in ['AzurePlayer','AzureRender','AzureGameLauncher'] if (out.parent/b/c/(n+'.exe')).exists()} for c,b in [('release','20261110-030251-hair-main-chroma-public-9e799c'),('debug','20261110-031856-hair-main-chroma-debug-668bf2')]},indent=2)+'\n');print('Eleven scene/pose sources frozen, affected registration/camera/project targets and actual hosts selected')
