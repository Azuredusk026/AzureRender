from pathlib import Path
out=Path(__file__).resolve().parent;prior=out.parent/'20261111-042231-reference-raster-frustum-3ea06a'
for name in ['default-four.py','queued-four.py']:(out/name).write_bytes((prior/name).read_bytes())
print('Original-four driver prepared; project input lease is already active')
