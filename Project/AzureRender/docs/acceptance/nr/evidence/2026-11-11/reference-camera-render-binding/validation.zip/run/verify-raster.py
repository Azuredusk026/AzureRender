from pathlib import Path
import sys,json,hashlib,numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;c=sys.argv[1].lower();device=sys.argv[2];modes=sys.argv[3:] or ['ordinary','reference','orthographic','plain'];rows=[]
expected={'ordinary':[231,154,368,245],'plain':[231,154,368,245],'reference':[150,115,449,284],'orthographic':[156,104,443,295]}
for mode in modes:
 label=c+'-'+device+'-'+mode;p=out/(label+'-frames/frame_000000.png');pixels=np.asarray(Image.open(p).convert('RGB'));assert pixels.shape==(400,600,3)
 foreground=(pixels>128).all(axis=2);want=np.zeros((400,600),dtype=bool);x0,y0,x1,y1=expected[mode];want[y0:y1+1,x0:x1+1]=True;assert np.array_equal(foreground,want),label+' geometry differs from independent rectangle raster expectation'
 assert (pixels[foreground]>=200).all() and (pixels[~foreground]<=100).all(),label+' foreground/background classes overlap'
 manifest=json.loads((out/(label+'-frames/capture_manifest.json')).read_text());assert manifest['cameraUniformBytes']==800 and manifest['referenceCameraPrograms']==(mode!='plain') and manifest['referenceCameraEnabled']==(mode in ['reference','orthographic']) and not manifest['referenceCameraConservativeRetention']
 rows.append(dict(mode=mode,configuration=c,device=device,bounds=expected[mode],exactMaskPixels=int(want.sum()),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),referenceEnabled=manifest['referenceCameraEnabled'],cameraUniformBytes=manifest['cameraUniformBytes']))
if all((out/(c+'-'+device+'-'+m+'-frames/frame_000000.png')).exists() for m in ['ordinary','plain']):
 a=(out/(c+'-'+device+'-ordinary-frames/frame_000000.png')).read_bytes();b=(out/(c+'-'+device+'-plain-frames/frame_000000.png')).read_bytes();assert a==b,'Disabled reference program differs from original program image'
(out/(c+'-'+device+'-raster-verification.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
