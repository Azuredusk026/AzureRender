from pathlib import Path
import subprocess,hashlib,json
out=Path(__file__).resolve().parent;root=out.parents[2]
files=subprocess.run(['git','diff','--name-only','--relative'],cwd=root,capture_output=True,text=True,check=True).stdout.splitlines()
files+=['shaders/reference_camera_fields.glsl','shaders/reference_camera_vertex.glsl','tests/ReferenceCameraBindingTests.cpp']
files=sorted(set(n for n in files if not n.startswith('docs/') and n not in ['README.md','CHANGELOG.md']))
values={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
(out/'frozen-source.json').write_text(json.dumps(values,indent=2)+'\n');print('Frozen '+str(len(files))+' source identities')
