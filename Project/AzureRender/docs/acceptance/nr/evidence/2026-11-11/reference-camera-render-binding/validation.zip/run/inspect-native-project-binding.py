from pathlib import Path
import os,json,stat
out=Path(__file__).resolve().parent;source=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4');project=json.loads((source/'joint-materials.azureproject').read_text());count=0;size=0;reparse=[];truncated=False
for directory,dirs,files in os.walk(source,followlinks=False):
 root=Path(directory)
 for name in dirs[:]:
  p=root/name
  if p.lstat().st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT:reparse.append(str(p.relative_to(source)));dirs.remove(name)
 for name in files:
  p=root/name;count+=1;size+=p.lstat().st_size
  if count>10000 or size>2*1024**3:truncated=True;break
 if truncated:break
mount,tail=project['startupScene'].split(':/');mountdir=next(v['path'] for v in project['mounts'] if v['name']==mount);level=json.loads((source/mountdir/tail).read_text());cameras=[]
for n in level['nodes']:
 c=n.get('components',{});a=c.get('azure.camera')
 if a:cameras.append(dict(node=n['id'],camera=a.get('data'),transform=c.get('azure.transform',{}).get('data')))
result=dict(logicalBytes=size,files=count,boundedScanStopped=truncated,reparseDirectories=reparse[:12],cameras=cameras,startupScene=project['startupScene'],resources=len(level.get('resources',[])));(out/'native-project-binding-inspection.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
