from pathlib import Path
import re
out=Path(__file__).resolve().parent;root=out.parents[2]
names=['docs/plans/2026-11-11-reference-camera-render-binding.md','docs/runtime/reference-camera-render-binding.md','docs/runtime/scene-reference-camera.md','docs/acceptance/nr/reference-camera-render-binding.md']
for name in names:
 p=root/name;text=p.read_text(encoding='utf-8')
 for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(name,sentence)
 for link in re.findall(r'\]\(([^)]+)\)',text):
  if not re.match(r'(https?:|#)',link):assert (p.parent/link.split('#')[0]).exists(),(name,link)
print('Four documents passed Chinese sentence and local-link checks')
