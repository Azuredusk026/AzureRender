from pathlib import Path
import numpy as np,json
from PIL import Image
out=Path(__file__).resolve().parent
for mode in ['ordinary','reference','orthographic']:
 p=out/('release-nvidia-'+mode+'-frames/frame_000000.png');a=np.asarray(Image.open(p).convert('RGB'));mask=(a>200).all(axis=2);y,x=np.where(mask)
 print(mode,dict(whitePixels=len(x),bounds=[int(x.min()),int(y.min()),int(x.max()),int(y.max())] if len(x) else [],colors=np.unique(a.reshape(-1,3),axis=0).tolist()[:12]))
 report=json.loads((out/('release-nvidia-'+mode+'-runtime.json')).read_text());print('renderer',str(report.get('renderer'))[:1600]);
 def inspect(obj):
  if isinstance(obj,dict):
   for k,v in obj.items():
    if 'referenceCamera' in k or k in ['cameraUniformBytes']:print(k,v)
    else:inspect(v)
  elif isinstance(obj,list):
   for v in obj:inspect(v)
 inspect(report)
