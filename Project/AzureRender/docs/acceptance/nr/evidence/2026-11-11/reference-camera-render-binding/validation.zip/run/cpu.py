from pathlib import Path
import sys,subprocess,json,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];c=sys.argv[1].lower();build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if c=='release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
for n,h in json.loads((out/'frozen-source.json').read_text()).items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
rows=[]
commands=[['AzureReferenceCameraBindingTests'],['AzureReferenceCameraSelectionTests'],['AzureReferenceCameraSelectionTests',str(out.parent/'20261110-165124-reference-depth-source-4d1d7d/native-profile.bin'),str(out.parent/'20261111-001326-reference-position-frame-482201/native-frame.bin')],['AzureRenderExtensionRegistryTests']]
for i,args in enumerate(commands):
 command=[str(build/(args[0]+'.exe')),*args[1:]];r=subprocess.run(command,capture_output=True,text=True,timeout=120);(out/(c+'-cpu-'+str(i)+'.log')).write_text(r.stdout+r.stderr);rows.append(dict(command=command,exitCode=r.returncode,stdout=r.stdout.strip()));assert r.returncode==0,r.stdout+r.stderr
(out/(c+'-cpu-results.json')).write_text(json.dumps(rows,indent=2)+'\n');print(c+': four camera/registry checks passed')
