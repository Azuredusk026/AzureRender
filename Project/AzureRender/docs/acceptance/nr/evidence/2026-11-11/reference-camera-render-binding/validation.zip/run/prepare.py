from pathlib import Path
import sys,json,time
out=Path(__file__).resolve().parent;root=out.parents[2]
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a';p=Path('D:/Projects/FYP-coordination/quality-claim.json');claim=json.loads(p.read_text(encoding='utf-8'))
inputs=['20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2','20261111-042231-reference-raster-frustum-3ea06a','20261111-001326-reference-position-frame-482201','20261110-165124-reference-depth-source-4d1d7d']
token=s.acquire_inputs(root/'build',out,inputs,owner)
for name in inputs[:3]:s.maintenance.seal(root/'build',out.parent/name)
for t in claim.get('localInputLease',[]):s.release_inputs(root/'build',t,owner)
for t in claim.get('inputLease',[]):s.release_inputs(s.DEFAULT_BUILD,t,owner)
claim.update(state='reference-camera-render-binding',lastCommit='80199cf',taskPath=str(out),localInputLease=[token],inputLease=[],ownedFiles=['src/render/CameraViewDescriptor.hpp','src/render/CameraProjection.hpp','src/runtime/camera/GameCameraService.cpp','src/scenes/CharacterSceneRenderer.hpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterMaterialUv.inc','shaders/mesh.vert','shaders/outline.vert','CMakeLists.txt'],pendingCommand='Bind reference camera to raster, conservative culling and picking through the shared camera descriptor')
p.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'task-card.json').write_text(json.dumps(dict(baseCommit='80199cf',created=time.time(),locationSeconds=600,candidateSeconds=1200,explorationSeconds=1800,buildSeconds=1800,gpuSeconds=1200,plannedBytes=268435456,gateSource='AGENT.md public interface, actual host consumption, default four exact, two-device GPU validation, shared camera/picking correctness',deliverable='Reference calibration carried by shared camera descriptor, raster vertex family and UBO payload, picking and helper projections, conservative production culling'),indent=2)+'\n')
print('Previous unit sealed; render-binding inputs transferred')
