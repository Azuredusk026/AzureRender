from pathlib import Path
import hashlib,json
out=Path(__file__).resolve().parent;root=out.parents[2];build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((root/'docs/acceptance/nr/evidence/2026-11-11/reference-raster-frustum/program-catalog.json').read_text())['sha256']
current={p.name:sha(p) for p in (build/'shaders').glob('*.spv')};changed=[n for n,h in old.items() if current[n]!=h];added=sorted(set(current)-set(old));result=dict(count=len(current),oldExact=len(old)-len(changed),changed=changed,added=added,sha256=current)
(out/'release-program-catalog.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(count=result['count'],oldExact=result['oldExact'],changed=changed,addedCount=len(added),added=added),indent=2))
assert not changed and len(added)==26 and len(current)<=1024
