from pathlib import Path
import subprocess,json
out=Path(__file__).resolve().parent;root=out.parents[2]
cmd=['D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat','cl','/nologo','/std:c++17','/EHsc','/I'+str(root/'src'),'/ID:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/include',str(root/'tests/ReferenceCameraBindingTests.cpp'),str(root/'src/editor/EditorCameraController.cpp'),str(root/'src/editor/viewport/EditorCameraService.cpp'),'/Fo'+str(out)+'/', '/Fe'+str(out/'cpu-probe.exe')]
cmd.insert(5,'/ID:/Tools/VulkanSDK/1.4.350.0/Include')
cmd.insert(5,'/utf-8')
with (out/'cpu-build.log').open('wb') as log:r=subprocess.run(subprocess.list2cmdline(cmd),shell=True,stdout=log,stderr=subprocess.STDOUT,cwd=out)
assert r.returncode==0,(out/'cpu-build.log').read_text(errors='replace')
r=subprocess.run([str(out/'cpu-probe.exe')],capture_output=True,text=True);(out/'cpu-probe.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr;print(r.stdout)
