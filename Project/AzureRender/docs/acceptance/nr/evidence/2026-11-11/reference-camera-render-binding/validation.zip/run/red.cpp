#include "render/CameraProjection.hpp"
int main(){azurerender::CameraViewDescriptor camera;camera.referenceCalibration=azurerender::ReferenceCameraCalibration{};return azurerender::resolveReferenceCamera(camera).has_value()?0:1;}
