from pathlib import Path
import sys,json
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a';p=Path('D:/Projects/FYP-coordination/quality-claim.json');claim=json.loads(p.read_text(encoding='utf-8'))
t=s.acquire_inputs(root/'build',out,['20261110-195442-actual-vertex-clip-readback-c52555'],owner);claim['localInputLease'].append(t);p.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Actual graphics feedback fixture leased')
