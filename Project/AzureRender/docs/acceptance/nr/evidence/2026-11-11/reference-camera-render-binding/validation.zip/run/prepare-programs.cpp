#include "render/ReferenceFmaShader.hpp"
#include <filesystem>
#include <fstream>
#include <iterator>
#include <iostream>
int main(int argc,char** argv)try{
 if(argc!=3)throw std::invalid_argument("Expected raw and prepared program directories");std::filesystem::create_directories(argv[2]);unsigned count=0;
 for(const auto& entry:std::filesystem::directory_iterator(argv[1])){const auto name=entry.path().filename().string();if(name.find("_reference_camera.vert.spv")==std::string::npos)continue;std::ifstream input(entry.path(),std::ios::binary);std::vector<char> code((std::istreambuf_iterator<char>(input)),{});auto prepared=azurerender::prepareReferenceFmaShader(code);if(prepared.fusedResults!=3)throw std::runtime_error("Unexpected fused-result count: "+name);const auto again=azurerender::prepareReferenceFmaShader(prepared.code);if(again.code!=prepared.code||again.fusedResults!=3)throw std::runtime_error("Non-idempotent reference module preparation");std::ofstream output(std::filesystem::path(argv[2])/name,std::ios::binary);output.write(prepared.code.data(),prepared.code.size());if(!output)throw std::runtime_error("Cannot write prepared module");++count;}
 if(count!=26)throw std::runtime_error("Expected exactly 26 reference vertex programs");std::cout<<count<<" modules: three fused results and idempotent preparation passed\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
