from pathlib import Path
import subprocess,json,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
command=['D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat','cl','/nologo','/std:c++17','/utf-8','/EHsc','/I'+str(root/'src'),str(out/'prepare-programs.cpp'),'/Fo'+str(out/'prepare-programs.obj'),'/Fe'+str(out/'prepare-programs.exe')]
r=subprocess.run(subprocess.list2cmdline(command),shell=True,capture_output=True,text=True,cwd=out);(out/'module-preparation-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
r=subprocess.run([str(out/'prepare-programs.exe'),str(build/'shaders'),str(out/'prepared-programs')],capture_output=True,text=True);(out/'module-preparation.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
rows=[]
for p in sorted((out/'prepared-programs').glob('*.spv')):
 command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.3','--relax-block-layout',str(p)];r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr;rows.append(dict(program=p.name,rawSha256=sha(build/'shaders'/p.name),preparedSha256=sha(p),fusedResults=3,idempotent=True,validationExitCode=r.returncode))
(out/'module-preparation-results.json').write_text(json.dumps(rows,indent=2)+'\n');print('All 26 prepared reference vertex modules passed SPIR-V validation')
