from pathlib import Path
import json,struct,copy
out=Path(__file__).resolve().parent;project=out/'raster-project';assets=project/'assets';assets.mkdir(parents=True,exist_ok=True);(project/'config').mkdir(exist_ok=True)
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
positions=[[-.6,-.4,0],[.6,-.4,0],[.6,.4,0],[-.6,.4,0]];normals=[[0,0,1]]*4;indices=[0,1,2,0,2,3]
blob=b''.join(struct.pack('<3f',*v) for v in positions+normals)+struct.pack('<6H',*indices);(assets/'quad.bin').write_bytes(blob)
gltf=dict(asset=dict(version='2.0'),scene=0,scenes=[dict(nodes=[0])],nodes=[dict(mesh=0)],buffers=[dict(uri='quad.bin',byteLength=len(blob))],bufferViews=[dict(buffer=0,byteOffset=0,byteLength=48,target=34962),dict(buffer=0,byteOffset=48,byteLength=48,target=34962),dict(buffer=0,byteOffset=96,byteLength=12,target=34963)],accessors=[dict(bufferView=0,componentType=5126,count=4,type='VEC3',min=[-.6,-.4,0],max=[.6,.4,0]),dict(bufferView=1,componentType=5126,count=4,type='VEC3'),dict(bufferView=2,componentType=5123,count=6,type='SCALAR')],materials=[dict(name='reference-white',doubleSided=True,pbrMetallicRoughness=dict(baseColorFactor=[1,1,1,1],metallicFactor=0,roughnessFactor=1),extensions={'KHR_materials_unlit':{}})],meshes=[dict(primitives=[dict(attributes=dict(POSITION=0,NORMAL=1),indices=2,material=0)])],extensionsUsed=['KHR_materials_unlit'])
write(assets/'quad.gltf',gltf)
transform={'type':'azure.transform','version':1,'data':{'translation':[0,0,3],'rotation':[0,0,0],'scale':[1,1,1]}}
camera={'type':'azure.camera','version':2,'data':dict(enabled=True,priority=1,orthographic=False,fieldOfView=60,orthographicHeight=10,nearPlane=.1,farPlane=100,projectionOffsetX=0,projectionOffsetY=0)}
binding={'type':'azure.reference-camera','version':1,'data':dict(enabled=True,view='calibrated',anchorPosition=[0,0,3],anchorRight=[1,0,0],anchorUp=[0,1,0],anchorBack=[0,0,1])}
settings=dict(schemaVersion=20,antiAliasing=0,outlinePixels=0,outline=0,background=False,platform=False,faceSdf=False,innerOutline=False,silhouetteOutline=False,toneMapping=False,bloomEnabled=False,skyMode=2,skyColor=[0,0,0],exposure=0)
level=dict(schemaVersion=1,id='reference-raster-fixture',resources=[dict(id='quad',asset='assets:/quad.gltf')],nodes=[dict(id='quad',resourceId='quad'),dict(id='camera',components={'azure.transform':transform,'azure.camera':camera,'azure.reference-camera':binding})],renderSettings=settings)
write(assets/'reference.azurelevel',level)
ordinary=copy.deepcopy(level);ordinary['nodes'][1]['components']['azure.reference-camera']['data']['enabled']=False;write(assets/'ordinary.azurelevel',ordinary)
for name in ['reference','ordinary']:write(project/(name+'.azureproject'),dict(schemaVersion=1,id='reference-raster-fixture',name='Reference raster fixture',mounts=[dict(name='assets',path='assets')],startupScene='assets:/'+name+'.azurelevel'))
view=dict(schemaVersion=1,frame=dict(schemaVersion=1,axes=[1,2,3],offset=[0,0,-3]),projection=dict(schemaVersion=1,columns=[[2.5,0,0,0],[0,3.2,0,0],[0,0,0,-1],[0,0,.1,0]],jitter=[0,0]),extent=[600,400],depthConvention='reversed',flipNdcY=True)
write(project/'config/reference-views.json',dict(schemaVersion=1,views=dict(calibrated=view)))
orthographic=copy.deepcopy(level);orthographic['id']='reference-orthographic-fixture';orthographic['nodes'][1]['components']['azure.camera']['data']['orthographic']=True;orthographic['nodes'][1]['components']['azure.reference-camera']['data']['view']='orthographic';write(assets/'orthographic.azurelevel',orthographic)
orthoView=copy.deepcopy(view);orthoView['projection']['columns']=[[.8,0,0,0],[0,1.2,0,0],[0,0,.01,0],[0,0,.5,1]]
write(project/'orthographic.azureproject',dict(schemaVersion=1,id='reference-orthographic-fixture',name='Reference orthographic fixture',mounts=[dict(name='assets',path='assets')],startupScene='assets:/orthographic.azurelevel'))
write(project/'config/reference-views.json',dict(schemaVersion=1,views=dict(calibrated=view,orthographic=orthoView)))
plain=out/'plain-project';(plain/'assets').mkdir(parents=True,exist_ok=True)
for name in ['quad.gltf','quad.bin','ordinary.azurelevel']:(plain/'assets'/name).write_bytes((assets/name).read_bytes())
write(plain/'plain.azureproject',dict(schemaVersion=1,id='reference-plain-fixture',name='Ordinary camera fixture',mounts=[dict(name='assets',path='assets')],startupScene='assets:/ordinary.azurelevel'))
write(out/'raster-expected.json',dict(extent=[600,400],referenceBounds=[150,114.6666666667,450,285.3333333333],ordinaryBounds=[230.7179676972,153.8119784648,369.2820323028,246.1880215352],positions=positions,view=view))
print('Prepared public project/level/reference sidecar; 108 bytes of local mesh data')
