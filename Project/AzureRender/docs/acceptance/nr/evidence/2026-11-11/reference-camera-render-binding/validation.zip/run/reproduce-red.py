from pathlib import Path
import subprocess,json
out=Path(__file__).resolve().parent;root=out.parents[2];baseline=out/'red-baseline';(baseline/'render').mkdir(parents=True,exist_ok=True)
for name in ['CameraViewDescriptor.hpp','CameraProjection.hpp','ReferenceCameraCalibration.hpp']:
 r=subprocess.run(['git','show','80199cf:Project/AzureRender/src/render/'+name],cwd=root,capture_output=True,check=True);(baseline/'render'/name).write_bytes(r.stdout)
cmd=['D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat','cl','/nologo','/std:c++17','/utf-8','/EHsc','/c','/I'+str(baseline),'/I'+str(root/'src'),'/ID:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/include',str(out/'red.cpp'),'/Fo'+str(out/'baseline-red.obj')]
r=subprocess.run(subprocess.list2cmdline(cmd),shell=True,capture_output=True,text=True);(out/'baseline-api-red.log').write_text(r.stdout+r.stderr);assert r.returncode!=0 and 'referenceCalibration' in r.stdout and 'resolveReferenceCamera' in r.stdout,r.stdout+r.stderr
(out/'baseline-api-red.json').write_text(json.dumps(dict(baseCommit='80199cf',command=cmd,exitCode=r.returncode,expected='Missing shared reference calibration and consumer API'),indent=2)+'\n');print('Committed baseline reproduces missing binding/consumer API failure')
