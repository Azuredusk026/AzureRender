from pathlib import Path
import sys,os,subprocess,json,re
out=Path(__file__).resolve().parent;c=sys.argv[1].lower();device=sys.argv[2];build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if c=='release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
env=os.environ.copy()
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
env.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*' if device=='nvidia' else '*igvk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
results=out/(c+'-'+device+'-raster-results.json');rows=json.loads(results.read_text()) if results.exists() else []
for mode in (sys.argv[3:] or ['ordinary','reference','orthographic','plain']):
 label=c+'-'+device+'-'+mode;frames=out/(label+'-frames');project=out/'plain-project/plain.azureproject' if mode=='plain' else out/'raster-project'/(mode+'.azureproject');command=[str(build/'AzurePlayer.exe'),'--project',str(project),'--width','600','--height','400','--qa-camera','scene','--qa-light','scene','--capture-frames','1','--capture-fps','24','--fixed-frame-step','--capture-dir',str(frames),'--runtime-report',str(out/(label+'-runtime.json')),'--resource-root',str(build)]
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 text=(out/(label+'.log')).read_text(errors='replace');row=dict(mode=mode,configuration=c,device=device,command=command,exitCode=r.returncode,validationClean=not bool(re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',text,re.I)),allocatorZero='Allocator after unload: buffers=0 images=0' in text);rows.append(row);(out/(c+'-'+device+'-raster-results.json')).write_text(json.dumps(rows,indent=2)+'\n');assert r.returncode==0 and row['validationClean'] and row['allocatorZero'],text[-5000:];print(label+' rendered',flush=True)
