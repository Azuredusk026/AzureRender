from pathlib import Path
import json,zipfile,hashlib,re
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=json.loads((out/'results.json').read_text());assert result['status']=='qualified-reference-camera-render-binding'
plan=root/'docs/plans/2026-11-11-reference-camera-render-binding.md';plan.write_text(plan.read_text(encoding='utf-8').replace('- [ ]','- [x]'),encoding='utf-8')
for name,prefix in [('README.md','docs/'),('docs/project-status.md',''),('docs/plans/azure-engine-plan.md','../'),('docs/plans/2026-11-09-native-quality.md','../')]:
 p=root/name;text=p.read_text(encoding='utf-8')
 if '[参考相机生产接入]' not in text:text+='\n[参考相机生产接入]('+prefix+'acceptance/nr/reference-camera-render-binding.md)完成共享标定、光栅、拾取及编辑入口检查。\n两配置、两设备的实际几何掩码和原四帧通过，完整外观按所属门槛继续验收。\n'
 p.write_text(text,encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');anchor='## 2026-11-11 参考光栅混合视锥'
if '## 2026-11-11 参考相机生产接入' not in text:text=text.replace(anchor,'## 2026-11-11 参考相机生产接入\n\n- 在共享相机描述中传递参考标定及锚点。\n- 主视图、深度快照及轮廓消费 112 字节参考参数。\n- 拾取、辅助线及编辑相机入口共用参考投影。\n- 渲染器接口版本为十，参考能力显式声明。\n- 两配置、两设备及原四帧通过；859 份既有程序摘要相同。\n\n'+anchor)
p.write_text(text,encoding='utf-8')
documents=['docs/plans/2026-11-11-reference-camera-render-binding.md','docs/runtime/reference-camera-render-binding.md','docs/runtime/scene-reference-camera.md','docs/acceptance/nr/reference-camera-render-binding.md']
support=['src/render/ReferenceFmaShader.hpp','src/render/ReferenceCameraView.hpp','src/render/ReferenceRasterProjection.hpp','src/render/ReferenceRasterFrustum.hpp','src/render/ReferenceClipProjection.hpp','src/render/ReferencePositionFrame.hpp','shaders/reference_raster_projection.glsl','shaders/reference_clip_projection.glsl','shaders/reference_position_frame.glsl']
sources=sorted(set(list(result['sourceSha256'])+documents+support));files={'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log','.cpp','.hpp'}};files.update({'source/'+n:root/n for n in sources})
for folder in ['raster-project','plain-project','red-baseline']:
 for p in (out/folder).rglob('*'):
  if p.is_file() and p.suffix in {'.json','.azureproject','.azurelevel','.gltf','.bin','.hpp'} and not any(part in {'.azure','cache','generated','Cache'} for part in p.relative_to(out/folder).parts):files['fixture/'+str(p.relative_to(out)).replace('\\','/')]=p
for p in out.glob('*-frames/*'):
 if p.parent.name=='default-four-frames' and p.suffix=='.png':continue
 if p.is_file() and p.suffix in {'.json','.png'}:files['capture/'+p.parent.name+'/'+p.name]=p
build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
for p in (build/'shaders').glob('*_reference_camera.vert.spv'):files['program/'+p.name]=p
for p in (out/'prepared-programs').glob('*.spv'):files['prepared-program/'+p.name]=p
files['input/native-profile.bin']=out.parent/'20261110-165124-reference-depth-source-4d1d7d/native-profile.bin';files['input/native-frame.bin']=out.parent/'20261111-001326-reference-position-frame-482201/native-frame.bin'
dest=root/'docs/acceptance/nr/evidence/2026-11-11/reference-camera-render-binding';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']=dict(bytes=archive.stat().st_size,sha256=sha(archive),members=len(members)+1);(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n');(dest/'program-catalog.json').write_bytes((out/'program-catalog.json').read_bytes())
for name in documents:
 p=root/name;text=p.read_text(encoding='utf-8')
 for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(name,sentence)
 for link in re.findall(r'\]\(([^)]+)\)',text):
  if not re.match(r'(https?:|#)',link):assert (p.parent/link.split('#')[0]).exists(),(name,link)
print(json.dumps(result['archive']))
