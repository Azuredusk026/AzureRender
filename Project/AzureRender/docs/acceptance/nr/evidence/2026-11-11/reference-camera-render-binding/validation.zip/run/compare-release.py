from pathlib import Path
import numpy as np,json
from PIL import Image
out=Path(__file__).resolve().parent;rows=[]
for mode in ['ordinary','reference','orthographic','plain']:
 images=[np.asarray(Image.open(out/('release-'+d+'-'+mode+'-frames/frame_000000.png')).convert('RGB')).astype(np.int16) for d in ['nvidia','intel']];difference=np.abs(images[0]-images[1]);maximum=int(difference.max());assert maximum<=1,(mode,maximum);rows.append(dict(mode=mode,maxRgbDifference=maximum,differingPixels=int(np.any(difference!=0,axis=2).sum())))
(out/'release-device-comparison.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
