from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=json.loads((out/'frozen-source.json').read_text());assert all(sha(root/n)==h for n,h in source.items())
old=json.loads((root/'docs/acceptance/nr/evidence/2026-11-11/reference-raster-frustum/program-catalog.json').read_text())['sha256'];catalogs=[];builds=[];cpu=[];raster=[]
for c,parent in [('release','20261110-030251-hair-main-chroma-public-9e799c'),('debug','20261110-031856-hair-main-chroma-debug-668bf2')]:
 b=out.parent/parent/c;catalog={p.name:sha(p) for p in (b/'shaders').glob('*.spv')};assert len(catalog)==885 and all(catalog[n]==h for n,h in old.items());catalogs.append(catalog)
 execution=json.loads((out/(c+'-final-build-execution.json')).read_text());assert execution['status']=='exited' and execution['exitCode']==0;builds.append(dict(configuration=c,execution=execution,playerSha256=sha(b/'AzurePlayer.exe')))
 checks=json.loads((out/(c+'-cpu-results.json')).read_text());assert len(checks)==4 and all(v['exitCode']==0 for v in checks);cpu+=checks
 for device in ['nvidia','intel']:
  checks=json.loads((out/(c+'-'+device+'-raster-results.json')).read_text());assert len(checks)==4 and all(v['exitCode']==0 and v['validationClean'] and v['allocatorZero'] for v in checks);raster+=checks
  verified=json.loads((out/(c+'-'+device+'-raster-verification.json')).read_text());assert len(verified)==4
assert catalogs[0]==catalogs[1]
prepared=json.loads((out/'module-preparation-results.json').read_text());assert len(prepared)==26 and all(v['fusedResults']==3 and v['idempotent'] and v['validationExitCode']==0 for v in prepared)
identities=[]
for mode in ['ordinary','reference','orthographic','plain']:
 images=[np.asarray(Image.open(out/(c+'-'+device+'-'+mode+'-frames/frame_000000.png')).convert('RGB')) for c in ['release','debug'] for device in ['nvidia','intel']]
 maximum=max(int(np.abs(v.astype(np.int16)-images[0]).max()) for v in images);assert maximum<=1,(mode,maximum);identities.append(dict(mode=mode,endpoints=4,maxRgbDifference=maximum,allowedRgbDifference=1))
four=json.loads((out/'default-four-results.json').read_text());assert four['allExact'] and four['validationClean'] and four['allocatorZero'];execution=json.loads((out/'four-execution.json').read_text());assert execution['status']=='exited' and execution['exitCode']==0
result=dict(status='qualified-reference-camera-render-binding',overall='failed-user-review',baseCommit='80199cf',sourceSha256=source,builds=builds,cpu=cpu,raster=raster,identities=identities,preparedModules=prepared,cameraViewLayoutVersion=3,sceneRendererApiVersion=10,cameraUniformBytes=800,referenceOffset=688,referenceBytes=112,oldProgramsExact=859,addedPrograms=26,programCount=885,defaultFour=four,fourExecution=execution,remaining=['Production hair 73 color failures','Intel reference depth/visibility 96 failures','Reference temporal motion, screen-space reflections and view fog','Skin, eyes, GI, reflection and dynamic appearance gates'])
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');(out/'program-catalog.json').write_text(json.dumps(dict(count=885,sha256=catalogs[0]),indent=2)+'\n');print(json.dumps(dict(status=result['status'],cpuProcesses=len(cpu),rasterProcesses=len(raster),fourExact=True,oldProgramsExact=859,addedPrograms=26),indent=2))
