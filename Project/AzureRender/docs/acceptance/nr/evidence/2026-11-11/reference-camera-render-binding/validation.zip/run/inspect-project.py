from pathlib import Path
import json,sys
out=Path(__file__).resolve().parent;sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
p=Path('D:/Projects/FYP-coordination/quality-claim.json');claim=json.loads(p.read_text(encoding='utf-8'));owner=claim['threadId'];t=s.acquire_inputs(s.DEFAULT_BUILD,out,['20261103-234012-character-reference-stages-5abe6c'],owner);claim['inputLease'].append(t);p.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
project=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject');data=json.loads(project.read_text(encoding='utf-8'));print(json.dumps(data,ensure_ascii=True,indent=2))
