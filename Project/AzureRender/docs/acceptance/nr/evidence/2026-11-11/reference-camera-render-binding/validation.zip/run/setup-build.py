from pathlib import Path
import sys,hashlib,json
out=Path(__file__).resolve().parent;root=out.parents[2]
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
for name in ['20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2']:s.maintenance.resume(root/'build',name)
prior=out.parent/'20261111-042231-reference-raster-frustum-3ea06a'
source=(prior/'build.py').read_text().replace("['AzureReferenceRasterFrustumGpuTests','AzurePlayer']", "['AzureReferenceCameraBindingTests','AzureReferenceCameraSelectionTests','AzurePlayer']")
(out/'build.py').write_text(source)
(out/'queued-build.py').write_text((prior/'queued-build.py').read_text().replace('quality-reference-raster-frustum','quality-reference-camera-render'))
print('Configured incremental host build with internal resource preflight')
