from pathlib import Path
import subprocess,json
out=Path(__file__).resolve().parent;root=out.parents[2]
cmd=['D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat','cl','/nologo','/std:c++17','/EHsc','/c','/I'+str(root/'src'),'/ID:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/include',str(out/'red.cpp'),'/Fo'+str(out/'red.obj')]
r=subprocess.run(subprocess.list2cmdline(cmd),shell=True,capture_output=True,text=True)
(out/'red.log').write_text(r.stdout+r.stderr)
assert r.returncode!=0 and 'referenceCalibration' in r.stdout and 'resolveReferenceCamera' in r.stdout,r.stdout+r.stderr
print('Expected missing binding/consumer API failure observed')
