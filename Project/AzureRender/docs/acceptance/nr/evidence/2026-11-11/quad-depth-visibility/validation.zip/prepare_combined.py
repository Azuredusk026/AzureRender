from pathlib import Path
import json,shutil,textwrap
root=Path.cwd();parent=Path(__file__).resolve().parent;out=parent/'combined';out.mkdir(exist_ok=True)
previous=root/'build/runs/20261110-230807-unrolled-computed-view-local-qualification-cd6bdc';old=(previous/'compare.py').read_text()
shutil.copyfile(previous/'selected_receiver.glsl',out/'selected_receiver.glsl')
(out/'preflight').mkdir(exist_ok=True)
shutil.copyfile(previous/'selected_receiver.glsl',out/'preflight/selected_receiver.glsl')
shutil.copyfile(parent/'candidate.frag',out/'depth-source.frag')
source=root/'shaders';private=out/'candidate-source';private.mkdir(exist_ok=True)
start=old.index(" original=(source/'mesh.frag').read_text();");end=old.index(' parameters={}\n',start)
rewrite=textwrap.dedent(old[start:end]).replace("original=(source/'mesh.frag').read_text()","original=(out/'depth-source.frag').read_text()")
scope=dict(root=root,out=out,source=source,private=private);exec(compile(rewrite,'selected-receiver-source','exec'),scope)
(out/'candidate.frag').write_text(scope['original'])
start=old.index("  if filename.startswith('mesh'):");end=old.index('  shader_source=private/',start);viewBlock=old[start:end]
compare=(parent/'compare.py').read_text().replace("out=root/'build/runs/"+parent.name+"'","out=root/'build/runs/"+parent.name+"/combined'")
marker='  shader_source=private/';assert compare.count(marker)==1
compare=compare.replace(marker,viewBlock+marker)
compare=compare.replace('read existing positive linear opaque snapshot depth;','selected receiver state plus verified ordinary-main default view; read existing positive linear opaque snapshot depth;')
(out/'compare.py').write_text(compare)
for name in ['run_compare.py','analyze.py','preflight.py','replay-profile.json','source-lock.json','protected-files.json']:shutil.copyfile(parent/name,out/name)
p=out/'analyze.py';p.write_text(p.read_text().replace("candidate='quad-depth-visibility'","candidate='quad-depth-selected-default-combination'"))
# Preflight material functions before capture-side value assertions and timing.
card=json.loads((parent/'task-card.json').read_text());card.update(scope='One justified combined control',basis='Standalone depth guard is six-attachment exact and lowers fixed-class cost by about 5.47%; selected receiver/default-view control previously exact but below 20% material admission',hypothesis='Independent opaque ordinary-view and masked depth-visibility work reductions can jointly qualify the complete material hotspot',previousCandidate=str(parent));(out/'task-card.json').write_text(json.dumps(card,indent=2))
print('Prepared one combined control; shader/camera value assertions retained')
