from pathlib import Path
import json,subprocess,sys,time,os
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from artifact_maintenance import managed_environment
from gpu_environment import wait_and_record,RunEnvironmentMonitor
os.environ.update(managed_environment(out/'tmp'))
from run_playable_performance import freeze_products
source=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
wait_and_record(out/'startup-environment.json',timeout=60)
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'compare.py')]
environment={}
with RunEnvironmentMonitor(environment,path=out/'run-environment.json',interval=2):
 with (out/'compare-driver.log').open('wb') as log:r=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=300)
state=json.loads((out/'compare-state.json').read_text());assert r.returncode==0 and state['status']=='compared',state
assert inputs(root)==source and all(digest(Path(p))==v for p,v in products.items())
used=sum(p.stat().st_size for p in out.rglob('*') if p.is_file());assert used<=64*1024**2
(out/'compare-results.json').write_text(json.dumps(dict(status='compared',seconds=time.monotonic()-start,sourceBase='88d84fb',sourceUnchanged=True,productsUnchanged=True,usedBytes=used,allTargetsEqual=state['allTargetsEqual'],summary=state['summary']),indent=2))
print(json.dumps(dict(status='compared',seconds=time.monotonic()-start,allTargetsEqual=state['allTargetsEqual'],summary=state['summary'])),flush=True)
