from pathlib import Path
import json,hashlib,sys,traceback,struct,subprocess,math,re
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261111-021128-quad-depth-visibility-local-qualification-1ea541';a=root/'build/runs/20261111-001050-quad-feature-device-capture-4798d1'
state=json.loads((a/'state.json').read_text());profile=json.loads((out/'replay-profile.json').read_text());report=dict(referenceUsesReplacement=True,status='starting',sourceBase='88d84fb',captureSourceBase='73300ab',scope='Feature-enabled 720p replay; main alpha-cutoff draws with nodeOpacity exactly one; read existing positive linear opaque snapshot depth; conservative relative margin 1e-4; reject only complete quads with no visible nonhelper lane; all surviving quads retain original derivatives and shading; native acceptance separate',captureSha256=state['captureSha256']);cap=None;c=None
full=json.loads((a/'pipeline-scope.json').read_text());byevent={e:g for g in full['groups'] for e in g['events']}
for row in profile['measurements']:
 stage='ShaderStage.Pixel' if row['kind']=='draw' else 'ShaderStage.Compute';row['shader']=next((v['resource'] for v in byevent[row['event']]['shaders'] if v['stage']==stage),'none')

def save():(out/'compare-state.json').write_text(json.dumps(report,indent=2))
def durations():
 for unused in range(16):c.SetFrameEvent(max(r['event'] for r in profile['measurements'] if r['kind']=='draw'),True)
 return {int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
try:
 save();cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 meshProgramNames={p['output'] for p in json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text())['programs'] if p['source']=='mesh.frag' and not any(v in p['defines'] for v in ['AZURE_VIEW_FOG=1','AZURE_HAIR_PIXEL_INTEGRAL=1','AZURE_GEOMETRY_SAMPLES=1'])}
 shaders={k:dict(v,programFile=next(n for n in v['programFiles'] if n in meshProgramNames)) for k,v in profile['shaders'].items() if any(n in meshProgramNames for n in v['programFiles'])};compiled={};baselines={};rows=[]
 manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());source=root/'shaders';private=out/'candidate-source';private.mkdir(exist_ok=True)
 original=(out/'candidate.frag').read_text()
 parameters={}
 for key,entry in shaders.items():
  event=next(r['event'] for r in profile['measurements'] if r['shader']==key);c.SetFrameEvent(event,True);pipe=c.GetPipelineState();shader=pipe.GetShader(rd.ShaderStage.Pixel)
  reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel);assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==entry['sha256']
  baselineProgram,baselineErrors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(root/'build/ninja-msvc-release/shaders'/entry['programFile']).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert baselineProgram!=rd.ResourceId.Null(),baselineErrors
  baselines[key]=(shader,baselineProgram)
  descriptor=pipe.GetConstantBlock(rd.ShaderStage.Pixel,0,0).descriptor
  raw=bytes(c.GetBufferData(descriptor.resource,descriptor.byteOffset+108,4));bits=struct.unpack('<I',raw)[0];radius=struct.unpack('<f',raw)[0];assert math.isfinite(radius)
  filename=entry['programFile'];assert filename not in parameters or parameters[filename]==bits;parameters[filename]=bits
  candidateText=original;viewChanges=[];viewInputs=None
  fragment=c.GetVulkanPipelineState().fragmentShader
  originalSpec=dict(ids=list(fragment.specializationIds),dataHex=bytes(fragment.specializationData).hex());assert str(fragment.resourceId)==str(shader)
  shader_source=private/('combined-'+str(bits)+'-'+filename[:-4]);shader_source.write_text(candidateText)
  specification=next(v for v in manifest['programs'] if v['output']==filename);assert specification['source']=='mesh.frag'
  arguments=[('--target-env=vulkan1.1' if v.startswith('--target-env=') else v) for v in specification['arguments']]
  if not any(v.startswith('--target-env=') for v in arguments):arguments+=['--target-env=vulkan1.1']
  command=[manifest['compiler'],*arguments,*['-D'+d for d in specification['defines']],'-I'+str(source),str(shader_source),'-o',str(out/filename)]
  built=subprocess.run(command,capture_output=True,text=True,timeout=30);(out/(filename+'.build.json')).write_text(json.dumps(dict(command=command,returncode=built.returncode,stdout=built.stdout,stderr=built.stderr),indent=2));assert built.returncode==0,built.stderr
  validated=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe',str(out/filename)],capture_output=True,text=True,timeout=15);assert validated.returncode==0,validated.stderr
  program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/entry['programFile']).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert program!=rd.ResourceId.Null(),errors
  compiled[key]=(shader,program);rows.append(dict(shader=key,file=entry['programFile'],event=event,shadowRadius=radius,shadowRadiusBits=bits,viewInputs=viewInputs,viewChanges=viewChanges,originalSpecialization=originalSpec,referenceSha256=hashlib.sha256((root/'build/ninja-msvc-release/shaders'/filename).read_bytes()).hexdigest(),candidateSha256=hashlib.sha256((out/filename).read_bytes()).hexdigest(),errors=errors))
 for key,(original,unused) in compiled.items():assert str(original)==key,'Original resource identity changed'
 def applyOverrides(mapping):
  for original,unused in compiled.values():c.RemoveReplacement(original)
  for original,replacement in mapping.values():c.ReplaceResource(original,replacement)
 report.update(status='compiled',programs=rows,clearBeforeRoleSwitch=True,consecutiveWarmReplays=16);save()
 draws=sorted((r for r in profile['measurements'] if r['kind']=='draw'),key=lambda x:x['seconds'],reverse=True)
 pixel=json.loads((a/'profile-state.json').read_text());last={}
 for row in pixel['pixelEvents']:
  if not row['hasChildren'] and row['shader'] in shaders:
   colors=tuple(row.get('colorTargets',[]));last[colors]=max(last.get(colors,0),row['event'])
 events=sorted(set(last.values())|{max(r['event'] for r in draws)})
 report['comparedEvents']=events
 applyOverrides(baselines);durations()
 controls={}
 for event in events:
  c.SetFrameEvent(event,True)
  for index,target in enumerate(c.GetPipelineState().GetOutputTargets()):
   if target.resource!=rd.ResourceId.Null():controls[(event,index)]=(target.resource,bytes(c.GetTextureData(target.resource,rd.Subresource())))
 applyOverrides(compiled)
 durations() # Warm candidate pipelines before the retained ABBA batch.
 applyOverrides(baselines)
 durations() # Warm all original pipelines again before the retained baseline.
 report['status']='baseline-read';report['timings']=[dict(mode='baseline',milliseconds=durations())];save()
 applyOverrides(compiled)
 comparisons=[]
 for (event,index),(resource,data) in controls.items():
  c.SetFrameEvent(event,True);value=bytes(c.GetTextureData(resource,rd.Subresource()));comparisons.append(dict(event=event,target=index,bytes=len(data),equal=value==data,changedBytes=sum(x!=y for x,y in zip(data,value)),firstByteDifferences=[(i,x,y) for i,(x,y) in enumerate(zip(data,value)) if x!=y][:12],baselineSha256=hashlib.sha256(data).hexdigest(),candidateSha256=hashlib.sha256(value).hexdigest()))
 report.update(status='candidate-read',comparisons=comparisons);save()
 for unused in range(2):report['timings'].append(dict(mode='candidate',milliseconds=durations()));save()
 applyOverrides(baselines)
 report['timings'].append(dict(mode='baseline',milliseconds=durations()))
 matched={r['event'] for r in profile['measurements'] if r['shader'] in shaders}
 mainMatched={r['event'] for r in profile['measurements'] if r['shader'] in shaders and shaders[r['shader']]['programFile'].startswith('mesh')}
 ordinaryMatched={e for g in full['groups'] if any(v.get('id')==0 and v.get('valueU32')==1 for v in g.get('specialization',[])) for e in g['events'] if e in mainMatched}
 classMatched={e for g in full['groups'] if not any(v.get('id')==0 and v.get('valueU32')==1 for v in g.get('specialization',[])) and any(v.get('id')==1 and v.get('valueU32')!=0xffffffff for v in g.get('specialization',[])) for e in g['events'] if e in matched}
 snapshotMatched=matched-mainMatched
 report['eventScopes']=dict(classSpecialized=sorted(classMatched),materials=sorted(matched),main=sorted(mainMatched),ordinaryMain=sorted(ordinaryMatched),snapshot=sorted(snapshotMatched))
 report['summary']=[dict(mode=r['mode'],classEventMs=sum(ms for e,ms in r['milliseconds'].items() if e in classMatched),mainEventMs=sum(ms for e,ms in r['milliseconds'].items() if e in mainMatched),ordinaryMainEventMs=sum(ms for e,ms in r['milliseconds'].items() if e in ordinaryMatched),snapshotEventMs=sum(ms for e,ms in r['milliseconds'].items() if e in snapshotMatched),allEventMs=sum(r['milliseconds'].values()),matchedEventMs=sum(ms for e,ms in r['milliseconds'].items() if e in matched)) for r in report['timings']]
 report.update(status='compared',allTargetsEqual=all(r['equal'] for r in comparisons));save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='compared' else 1)
