from pathlib import Path
import json,shutil,sys,re
root=Path.cwd();out=Path(__file__).resolve().parent;old=root/'build/runs/20261111-015922-quad-coverage-receiver-local-qualification-2a6dd5'
text=(root/'shaders/mesh.frag').read_text();marker='    azurePreparePrimaryUv(textureCoordinate);';assert text.count(marker)==1
guard='''
#if !defined(AZURE_OPAQUE_SNAPSHOT)
    if(!azureOrdinaryOpaque && AZURE_ALPHA_MODE==1 && material.nodeOpacity==1.0){
        ivec2 depthPixel=ivec2(AZURE_FRAGMENT_COORD.xy),depthExtent=textureSize(overlaySceneDepth,0);
        bool depthInside=all(greaterThanEqual(depthPixel,ivec2(0)))&&all(lessThan(depthPixel,depthExtent));
        float opaqueDepth=depthInside?texelFetch(overlaySceneDepth,depthPixel,0).r:0.0;
        float fragmentDepth=dot(worldPosition-camera.cameraPosition.xyz,camera.cameraForward.xyz);
        bool finiteDepth=!any(isnan(vec2(opaqueDepth,fragmentDepth)))&&!any(isinf(vec2(opaqueDepth,fragmentDepth)));
        float depthMargin=1.e-4*max(1.0,max(abs(opaqueDepth),abs(fragmentDepth)));
        bool depthHidden=depthInside&&finiteDepth&&opaqueDepth>0.0&&opaqueDepth<100000.0&&fragmentDepth>opaqueDepth+depthMargin;
        uint depthVisible=(!depthHidden&&!gl_HelperInvocation)?1u:0u;
        uint quadDepthVisible=subgroupQuadBroadcast(depthVisible,0u)|subgroupQuadBroadcast(depthVisible,1u)|subgroupQuadBroadcast(depthVisible,2u)|subgroupQuadBroadcast(depthVisible,3u);
        if(quadDepthVisible==0u)discard;
    }
#endif
'''
text=text.replace(marker,marker+guard)
text=text.replace('#version 450','#version 450\n#extension GL_KHR_shader_subgroup_quad : require\n#extension GL_EXT_shader_quad_control : require\n#extension GL_EXT_maximal_reconvergence : require\nlayout(quad_derivatives) in;\nlayout(full_quads) in;',1)
annotation='#if defined(AZURE_SURFACE_RADIANCE_REUSE) && !defined(AZURE_OPAQUE_SNAPSHOT)\n    [[maximally_reconverges]]';assert text.count(annotation)==1;text=text.replace(annotation,'#if 1\n    [[maximally_reconverges]]')
(out/'candidate.frag').write_text(text)
compare=(old/'compare.py').read_text().replace(old.name,out.name).replace("sourceBase='f3071a4'","sourceBase='88d84fb'")
scope='Feature-enabled 720p replay; main alpha-cutoff draws with nodeOpacity exactly one; read existing positive linear opaque snapshot depth; conservative relative margin 1e-4; reject only complete quads with no visible nonhelper lane; all surviving quads retain original derivatives and shading; native acceptance separate'
compare=re.sub(r"scope='Feature-enabled 720p replay;[^']+'",lambda m:"scope='"+scope+"'",compare,count=1)
(out/'compare.py').write_text(compare)
for name in ['run_compare.py','analyze.py','preflight.py']:(out/name).write_text((old/name).read_text().replace("sourceBase='f3071a4'","sourceBase='88d84fb'").replace("candidate='quad-coverage-receiver-deferral'","candidate='quad-depth-visibility'"))
shutil.copyfile(old/'replay-profile.json',out/'replay-profile.json');shutil.copyfile(old/'protected-files.json',out/'protected-files.json')
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs
(out/'source-lock.json').write_text(json.dumps(inputs(root),indent=2))
(out/'task-card.json').write_text(json.dumps(dict(sourceBase='88d84fb',scope='Private existing-snapshot whole-quad conservative occlusion control',basis='Prior alpha-only whole-quad guard had no gain; fixed-class fragment invocations exceed passed samples; existing full opaque snapshot is already sampled in main pass',hypothesis='Separate depth-hidden work from alpha-rejected work by conservatively rejecting only wholly occluded quads',qualification='Nonordinary alphaMode Mask, nodeOpacity exactly one, main pass; finite positive same-pixel snapshot depth; own depth exceeds snapshot by relative 1e-4 margin',gates=dict(attachments='all six byte-exact',nativeAdmission='quarter frame hotspot and 20% reduction, or 3ms GPU'),budget=dict(diagnosisMinutes=10,implementationMinutes=20,totalMinutes=30),productionChanges=0),indent=2))
print('Prepared snapshot-depth quad visibility control')
