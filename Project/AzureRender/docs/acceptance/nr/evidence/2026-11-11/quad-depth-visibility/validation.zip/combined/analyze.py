from pathlib import Path
import json,sys,subprocess
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
state=json.loads((out/'compare-state.json').read_text());assert state['status']=='compared'
assert len(state['programs'])==10 and len(state['comparisons'])==6
assert len(state['eventScopes']['materials'])==1006 and len(state['eventScopes']['classSpecialized'])==129
assert inputs(root)==json.loads((out/'source-lock.json').read_text())
assert all(digest(root/p)==h for p,h in json.loads((out/'protected-files.json').read_text()).items())
validation=[]
for item in state['programs']:
    command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.1',str(out/item['file'])]
    r=subprocess.run(command,capture_output=True,text=True,timeout=15);validation.append(dict(command=command,exitCode=r.returncode,output=r.stdout+r.stderr));assert r.returncode==0
(out/'vulkan-validation.json').write_text(json.dumps(validation,indent=2))
assert [v['mode'] for v in state['summary']]==['baseline','candidate','candidate','baseline'];scopes={}
frame=sum(v['allEventMs'] for v in state['summary'] if v['mode']=='baseline')/2
for key in ['allEventMs','matchedEventMs','classEventMs','mainEventMs','ordinaryMainEventMs','snapshotEventMs']:
    a=[v[key] for v in state['summary'] if v['mode']=='baseline'];b=[v[key] for v in state['summary'] if v['mode']=='candidate'];baseline=sum(a)/2;candidate=sum(b)/2
    scopes[key]=dict(referenceMs=baseline,candidateMs=candidate,savedMs=baseline-candidate,reduction=(baseline-candidate)/baseline,share=baseline/frame,referenceDrift=abs(a[1]-a[0])/baseline)
qualified=state['allTargetsEqual'] and (any(v['share']>=.25 and v['reduction']>=.2 for k,v in scopes.items() if k!='allEventMs') or scopes['allEventMs']['savedMs']>=3)
result=dict(status='local-qualified' if qualified else 'isolated-below-native-admission',candidate='quad-depth-selected-default-combination',sourceBase='88d84fb',allSixAttachmentsExact=state['allTargetsEqual'],materials=1006,fixedClassEvents=129,totalEvents=len(state['timings'][0]['milliseconds']),scope=scopes,qualified=qualified,protectedFilesExact=13,sourceUnchanged=True,formalPerformanceAccepted=False)
(out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
