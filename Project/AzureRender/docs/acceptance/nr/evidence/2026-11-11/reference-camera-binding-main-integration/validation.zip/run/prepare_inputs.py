from pathlib import Path
import hashlib,json,sys,zipfile
root=Path.cwd(); out=Path(__file__).resolve().parent
base=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/docs/acceptance/nr/evidence/2026-11-11')
records=[]
for name,wanted,expected in [
 ('conservative-frustum-transport',{'run/legacy-cull_indirect.comp.spv','run/legacy-visibility_prototype.comp.spv'},'09a8e82ea9ab35fe58c2c9f3516605869d014b67b69a4964cd6f2296c2ce2fef'),
 ('reference-raster-frustum',{'input/native-frame.bin','input/native-profile.bin','input/native-world-positions.bin'},'f2a71f7202e5d5621f47b5649cf6148f7db7afb58589cf618d99c237c52fc5ec'),
 ('reference-camera-render-binding',{'run/raster.py','run/verify-raster.py'},'dd3e3388bb5752c16c993d011a03044f31cddc2146f785b41ab3f33fffab1dbe')]:
    source=base/name/'validation.zip'; assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
    with zipfile.ZipFile(source) as z:
        if name=='reference-camera-render-binding':
            wanted|={n for n in z.namelist() if n.startswith(('fixture/plain-project/','fixture/raster-project/'))}
        assert z.testzip() is None
        for n in sorted(wanted):
            rel=Path(n).relative_to(n.split('/')[0]); p=(out/rel).resolve()
            assert out.resolve() in p.parents and not p.exists()
            payload=z.read(n); p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(payload)
            records.append(dict(archive=name,archiveSha256=expected,member=n,sha256=hashlib.sha256(payload).hexdigest(),bytes=len(payload),path=rel.as_posix()))
    catalog=json.loads((base/name/'program-catalog.json').read_text(encoding='utf-8-sig'))
    (out/(name+'-catalog.json')).write_text(json.dumps(catalog,indent=2))
(out/'input-receipts.json').write_text(json.dumps(records,indent=2))
print(json.dumps(dict(files=len(records),bytes=sum(x['bytes'] for x in records))))
