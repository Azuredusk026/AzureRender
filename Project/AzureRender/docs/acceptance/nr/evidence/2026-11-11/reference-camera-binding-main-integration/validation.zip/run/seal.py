from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def encode(x):return (json.dumps(x,indent=2)+'\n').encode()
assert inputs(root)==read(out/'source-lock.json')
assert subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()=='6e88b74'
for c in ['release','debug']:verify(root,read(out/(c+'-build-provenance.json')))
protected=read(out/'protected-files.json');assert len(protected)==13 and all(digest(root/p)==h for p,h in protected.items())
frozen=read(out/'frozen-project-inputs.json');assert len(frozen)==1729 and all(digest(Path(p))==h for p,h in frozen.items())
assert all(digest(out/x['path'])==x['sha256'] for x in read(out/'input-receipts.json'))
build=read(out/'integrated-results.json');assert build['status']=='built-and-checked' and build['gpuProcesses']==16 and build['rasterProcesses']==16 and build['exactMaskPixels']==3840000
assert sum(c['ctest'] for c in build['checks'])==46 and sum(c['supplementalCpuChecks'] for c in build['checks'])==4 and all(c['activePrograms']==886 and c['existingExact']==858 and c['childExact']==885 and c['newReferencePrograms']==26 for c in build['checks'])
capture=read(out/'capture-results.json');assert capture['exitCode']==0 and len(capture['frames'])==4 and all(capture[k] for k in ['validationClean','allocatorZero','sourceUnchanged','programsUnchanged','projectInputsUnchanged'])
manifest=read(out/'capture-manifest.json');assert not manifest['referenceCameraEnabled'] and not manifest['referenceCameraPrograms'] and manifest['cameraUniformBytes']==800 and manifest['computedMaterialViewFallback']=='build-disabled'
assert 'Unsupported capability combination must use reference' in (out/'policy-red.log').read_text(errors='replace')
assert 'eight capability fallbacks' in (out/'policy-green.log').read_text(errors='replace')
gpu=read(out/'gpu-results.json');assert len(gpu)==16 and all(v['passed'] for v in gpu)
raster=read(out/'raster-results.json');assert len(raster)==16 and all(v['allocatorZero'] and v['validationClean'] for v in raster)
assert all('49160 exact draw records' in v['stdout'] for v in gpu if v['mode']=='guard')
assert all('32045 exact mixed-frustum draw records' in v['stdout'] for v in gpu if v['mode']=='mixed-frustum')
references={
    'conservative-frustum-transport':('e931a86','c60c636','09a8e82ea9ab35fe58c2c9f3516605869d014b67b69a4964cd6f2296c2ce2fef'),
    'reference-raster-frustum':('80199cf','48c4959','f2a71f7202e5d5621f47b5649cf6148f7db7afb58589cf618d99c237c52fc5ec'),
    'reference-camera-render-binding':('1a7da41','6e88b74','dd3e3388bb5752c16c993d011a03044f31cddc2146f785b41ab3f33fffab1dbe')
}
dest=root/'docs/acceptance/nr/evidence/2026-11-11/reference-camera-binding-main-integration'
for n,(_,_,h) in references.items():assert digest(dest.parent/n/'validation.zip')==h
original=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames'
duplicates=[]
for frame in capture['frames']:
 p=out/'frames'/frame['name']; ref=original/frame['name']
 assert frame['changedPixels']==frame['maximumByteError']==0 and digest(p)==digest(ref)==frame['sha256']
 duplicates.append(dict(path=str(p),reference=str(ref),sha256=frame['sha256'],bytes=p.stat().st_size))
memory=read(out/'memory-results.json')
result=dict(status='reference-camera-binding-integrated',sourceHead='6e88b74',imports=references,build=build,
   guardDrawRecords=196640,mixedFrustumDrawRecords=128180,originalFour=capture,originalFourCameraUniformBytes=800,
   originalFourUsesOrdinaryCamera=True,memory=memory,staticOptInFallback='reference-camera-programs-use-reference-materials',
   modePairCorrection=read(out/'mode-pair-correction.json'),renderContextLineEndingReceipt=read(out/'render-context-line-ending-receipt.json'),
   projectInputsExact=1729,protectedFilesExact=13,formalPerformancePassed=False,overall='failed-user-review')
(out/'results.json').write_bytes(encode(result));(out/'duplicate-frame-inventory.json').write_bytes(encode(duplicates))
dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={}
def add(z,p,name):
 b=p.read_bytes();assert name not in members
 members[name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());z.writestr(name,b)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(out.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(out)
  if rel.parts[0] in ['tmp','frames']:continue
  if p.suffix in ['.json','.py','.log','.xml','.csv','.hpp','.spv','.bin','.azureproject','.azurelevel','.gltf','.png']:
   add(z,p,'run/'+rel.as_posix())
 for path in ['CMakeLists.txt','src/render/RenderContext.hpp','src/render/ComputedMaterialView.hpp','src/scenes/CharacterComputedMaterialView.inc','src/scenes/CharacterMaterialUv.inc','tests/ComputedMaterialViewTests.cpp','tools/test_shader_catalog.py']:
  add(z,root/path,'source/'+path)
 z.writestr('member-sha256.json',encode(members))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(members)|{'member-sha256.json'}
 assert all(len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in members.items())
assert archive.stat().st_size<8*1024**2
proof=dict(bytes=archive.stat().st_size,members=len(members)+1,sha256=digest(archive),memberHashesVerified=True)
(dest/'archive-verification.json').write_bytes(encode(proof));(dest/'results.json').write_bytes(encode(result))
for row in duplicates:
 p=Path(row['path']);assert p.resolve().parent==(out/'frames').resolve() and digest(p)==digest(Path(row['reference']))==row['sha256'];p.unlink()
(out/'identical-frames-reclaimed.json').write_bytes(encode(dict(files=len(duplicates),bytes=sum(x['bytes'] for x in duplicates),archive=proof)))
print(json.dumps(dict(archive=proof,seconds=capture['seconds'],peakWorkingSetBytes=memory['peakWorkingSetBytes'])))
