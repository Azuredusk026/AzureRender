from pathlib import Path
import json,os,re,shutil,subprocess,sys,time,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,verify,digest
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
for k in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','AZURE_DISABLE_COMPUTED_MATERIAL_VIEW']:os.environ.pop(k,None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(name,data):(out/name).write_text(json.dumps(data,indent=2))
def invoke(name,command,*,timeout=180,env=None):
    path=out/(name+'.log')
    with path.open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=timeout,env=env)
    return path.read_text(errors='replace')
def clean(t):return not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',t,re.I)
before=inputs(root);assert before==read(out/'source-lock.json'); checks=[]; gpu=[]; raster=[]
prior=out.parent/'20261111-052929-material-viewquad-depth-policy-750a8e/default-off'
child=read(out/'reference-camera-render-binding-catalog.json')['sha256'];assert len(child)==885
targets=['AzureConservativeCullingGpuTests','AzureReferenceRasterFrustumGpuTests','AzureVisibilityGpuTests','AzureVisibilityPrototypeTests','AzureReferenceCameraBindingTests','AzureRenderExtensionRegistryTests','AzureReferenceCameraSelectionTests','AzureReferenceCameraMacroTests','AzureCameraSystemTests','AzureComponentRegistryTests','AzureProjectReferenceViewsTests','AzureProjectTests','AzureReferenceRasterProjectionGpuTests','AzureReferenceCameraViewTests','AzureReferencePositionFrameGpuTests','AzureReferenceClipProjectionGpuTests','AzureReferenceDepthGpuTests','AzureReferenceDepthCoverageGpuTests','AzureHotReloadTests','AzureShaderCompilerContractTests','AzureComputedMaterialViewTests','AzureDepthPrefillRecordingTests','AzureMotionRecordingTests','AzureEditorProjectionTests']
selector=r'^(AzureRender\.(ReferenceCameraBinding|ReferenceCameraMacro|ReferenceRasterProjectionGpu|ReferenceCameraView|ReferencePositionFrameGpu|ReferenceClipProjectionGpu|ReferenceDepthGpu|ReferenceDepthCoverageGpu|VisibilityPrototype|ComputedMaterialView|DepthPrefillRecording|MotionRecording|ShaderCompilerContract|ShaderCatalogCompilation|HotReload)|AzureEngine\.(Project|ProjectReferenceViews|ModuleBoundaries|ModuleBoundaryFixtures|ComponentRegistry)|AzureRuntime\.(CameraSystem|ReferenceCameraSelection)|AzureEditor\.EditorProjection)$'
expected_bounds={'ordinary':[231,154,368,245],'plain':[231,154,368,245],'reference':[150,115,449,284],'orthographic':[156,104,443,295]}
for config in ['Release','Debug']:
    c=config.lower();build=root/('build/ninja-msvc-'+c); start=time.monotonic()
    assert 'AZURE_ENABLE_COMPUTED_MATERIAL_VIEW:BOOL=OFF' in (build/'CMakeCache.txt').read_text()
    os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
    cmd=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
    for target in targets:cmd+=['--test-target',target]
    reuse=c=='release'
    if reuse:
        assert before==read(out/'source-lock.json')
        verify(root,read(out/'release-build-provenance.json'))
    else:invoke(c+'-build',cmd,timeout=1000)
    exe=lambda name:str(build/(name+'.exe'))
    shaders=build/'shaders'
    cat=read(build/'shader-reload.json')['programs'];hashes={p['output']:digest(shaders/p['output']) for p in cat}
    base=read(prior/(c+'-program-sha256.json'));assert len(base)==860 and len(cat)==len(hashes)==886
    changed={n for n in base if hashes.get(n)!=base[n]};assert changed=={'cull_indirect.comp.spv','visibility_prototype.comp.spv'},changed
    new=set(hashes)-set(base);assert len(new)==26 and all(n.endswith('_reference_camera.vert.spv') for n in new)
    assert all(hashes.get(n)==h for n,h in child.items())
    assert not list(shaders.glob('*_viewquad.frag.spv'))
    write(c+'-program-sha256.json',hashes)
    shutil.copyfile(build/'build-provenance.json',out/(c+'-build-provenance.json'))
    if not reuse:invoke(c+'-tests',['ctest','--test-dir',str(build),'-C',config,'--output-on-failure','--no-tests=error','-R',selector,'--output-junit',str(out/(c+'-tests.xml'))],timeout=450)
    cases=ET.parse(out/(c+'-tests.xml')).findall('.//testcase');assert len(cases)==23 and not any(x.find('failure') is not None or x.find('skipped') is not None for x in cases),[x.attrib for x in cases]
    invoke(c+'-extension-registry',[exe('AzureRenderExtensionRegistryTests')])
    native=[str(out/('native-'+suffix+'.bin')) for suffix in ['profile','frame','world-positions']]
    log=invoke(c+'-native-selection',[exe('AzureReferenceCameraSelectionTests'),*native[:2]])
    assert '256 rigid-motion points' in log and 'maximumPixelError=' in log,log
    for dev,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
        prefix=c+'-'+dev;env=os.environ|{'VK_LOADER_DRIVERS_SELECT':driver,'PATH':str(build)+';'+os.environ['PATH']}
        assert all(digest(out/x['path'])==x['sha256'] for x in read(out/'input-receipts.json') if x['member'].endswith(('.spv','.bin')))
        pairs=[
          ('guard',[exe('AzureConservativeCullingGpuTests'),str(shaders/'cull_indirect.comp.spv'),str(shaders/'visibility_prototype.comp.spv'),str(out/'legacy-cull_indirect.comp.spv')]),
          ('current-visibility',[exe('AzureVisibilityGpuTests'),str(shaders/'cull_indirect.comp.spv'),str(shaders/'visibility_prototype.comp.spv'),str(out/(prefix+'-current-visibility.json'))]),
          ('legacy-visibility',[exe('AzureVisibilityGpuTests'),str(out/'legacy-cull_indirect.comp.spv'),str(out/'legacy-visibility_prototype.comp.spv'),str(out/(prefix+'-legacy-visibility.json'))]),
          ('mixed-frustum',[exe('AzureReferenceRasterFrustumGpuTests'),str(shaders/'cull_indirect.comp.spv'),*native]),
          ]
        for mode,cmd in pairs:
            log=(out/(prefix+'-'+mode+'.log')).read_text(errors='replace') if reuse and dev=='nvidia' else invoke(prefix+'-'+mode,cmd,env=env)
            assert clean(log),log
            if mode=='mixed-frustum':assert '32045 exact mixed-frustum draw records' in log,log
            gpu.append(dict(config=config,device=dev,mode=mode,passed=True,stdout=log.strip()))
        for mode,bounds in expected_bounds.items():
            label=prefix+'-'+mode; folder=out/(label+'-frames')
            project=out/('plain-project/plain.azureproject' if mode=='plain' else 'raster-project/'+mode+'.azureproject')
            command=[exe('AzurePlayer'),'--project',str(project),'--width','600','--height','400','--qa-camera','scene','--qa-light','scene','--capture-frames','1','--capture-fps','24','--fixed-frame-step','--capture-dir',str(folder),'--runtime-report',str(out/(label+'-runtime.json')),'--resource-root',str(build)]
            log=(out/(label+'.log')).read_text(errors='replace') if reuse and dev=='nvidia' else invoke(label,command,env=env,timeout=300)
            assert clean(log) and 'Allocator after unload: buffers=0 images=0' in log,log
            p=folder/'frame_000000.png'; pixels=np.asarray(Image.open(p).convert('RGB')); assert pixels.shape==(400,600,3)
            foreground=(pixels>128).all(axis=2); want=np.zeros((400,600),dtype=bool);x0,y0,x1,y1=bounds;want[y0:y1+1,x0:x1+1]=True
            assert np.array_equal(foreground,want) and (pixels[foreground]>=200).all() and (pixels[~foreground]<=100).all()
            manifest=read(folder/'capture_manifest.json')
            assert manifest['cameraUniformBytes']==800 and manifest['referenceCameraPrograms']==(mode!='plain') and manifest['referenceCameraEnabled']==(mode in ['reference','orthographic']) and not manifest['referenceCameraConservativeRetention']
            assert manifest['computedMaterialViewFallback']=='build-disabled' and not manifest['computedMaterialViewPipelines']
            raster.append(dict(config=config,device=dev,mode=mode,bounds=bounds,exactMaskPixels=int(want.size),foregroundPixels=int(want.sum()),sha256=digest(p),command=command,allocatorZero=True,validationClean=True))
        endpoints={row['mode']:row for row in raster[-4:]}
        assert endpoints['plain']['sha256']==endpoints['ordinary']['sha256']
        write('gpu-results.json',gpu);write('raster-results.json',raster)
    verify(root,read(build/'build-provenance.json'));assert inputs(root)==before
    checks.append(dict(config=config,ctest=len(cases),supplementalCpuChecks=2,skips=0,activePrograms=len(hashes),existingExact=858,childExact=885,changed=sorted(changed),newReferencePrograms=26,reusedVerifiedReleaseProductsAndCtest=reuse,seconds=time.monotonic()-start))
    write('build-results.json',checks);print(json.dumps(checks[-1]),flush=True)
assert len(gpu)==len(raster)==16
assert read(out/'release-program-sha256.json')==read(out/'debug-program-sha256.json')
for row in raster:
    label=row['config'].lower()+'-'+row['device']+'-'+row['mode']
    x=np.asarray(Image.open(out/(label+'-frames/frame_000000.png')).convert('RGB')).astype('i2')
    peers=[y for y in raster if y['mode']==row['mode'] and y['device']==row['device']]
    assert len(peers)==2 and len({p['sha256'] for p in peers})==1
    if row['device']=='nvidia':
        label=row['config'].lower()+'-intel-'+row['mode']
        y=np.asarray(Image.open(out/(label+'-frames/frame_000000.png')).convert('RGB')).astype('i2')
        assert np.abs(x-y).max()<=1
assert all(digest(root/p)==h for p,h in read(out/'protected-files.json').items())
write('integrated-results.json',dict(status='built-and-checked',checks=checks,gpuProcesses=len(gpu),rasterProcesses=len(raster),exactMaskPixels=sum(x['exactMaskPixels'] for x in raster),crossDeviceRgbErrorAtMost=1,sourceUnchanged=True))
subprocess.run([sys.executable,'-X','utf8','-B',str(out/'capture.py')],check=True,timeout=650)
