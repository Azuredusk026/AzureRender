from pathlib import Path
import subprocess,sys,re,json,hashlib
root=Path.cwd(); commit=sys.argv[1]; name='Project/AzureRender/CHANGELOG.md'
def git(*a):return subprocess.check_output(['git',*a]).decode('utf-8').replace('\r\n','\n')
path=Path('CHANGELOG.md')
ours=git('show',':2:'+name); incoming=git('show',commit+':'+name)
first=re.match(r'# Changelog\n\n(## [\s\S]+?)(?=\n## )',incoming)[1].rstrip()+'\n\n'
assert first.splitlines()[0] not in ours
path.write_text(ours.replace('# Changelog\n\n','# Changelog\n\n'+first,1),encoding='utf-8',newline='')
run=Path(__file__).resolve().parent
lock=json.loads((run/'protected-files.json').read_text())
staged=git('diff','--cached','--name-only').splitlines()
assert all('Project/AzureRender/'+n not in staged and hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in lock.items())
print(first.splitlines()[0])
