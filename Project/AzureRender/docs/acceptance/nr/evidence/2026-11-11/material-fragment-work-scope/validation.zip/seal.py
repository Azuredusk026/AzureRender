from pathlib import Path
import json,sys,zipfile,hashlib,shutil
root=Path.cwd();out=Path(__file__).resolve().parent;producer=root/'build/runs/20261111-001050-quad-feature-device-capture-4798d1';sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
assert inputs(root)==json.loads((out/'source-lock.json').read_text())
protected=json.loads((root/'build/runs/20261111-013805-reference-camera-view-main-integration-38f34e/protected-files.json').read_text());assert all(digest(root/p)==h for p,h in protected.items())
(out/'protected-files.json').write_text(json.dumps(protected,indent=2))
dest=root/'docs/acceptance/nr/evidence/2026-11-11/material-fragment-work-scope';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={}
paths=[(p,p.name) for p in out.iterdir() if p.is_file() and p.suffix in ['.json','.py']]+[(producer/n,'capture/'+n) for n in ['pipeline-scope.json','profile-state.json','state.json']]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,name in sorted(paths,key=lambda x:x[1]):members[name]=dict(bytes=path.stat().st_size,sha256=digest(path));z.write(path,name)
    z.writestr('member-sha256.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and all(len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in members.items())
assert archive.stat().st_size<8*1024*1024
verification=dict(bytes=archive.stat().st_size,members=len(members)+1,sha256=digest(archive),memberHashesVerified=True)
(dest/'archive-verification.json').write_text(json.dumps(verification,indent=2));shutil.copyfile(out/'results.json',dest/'results.json');print(json.dumps(verification))
