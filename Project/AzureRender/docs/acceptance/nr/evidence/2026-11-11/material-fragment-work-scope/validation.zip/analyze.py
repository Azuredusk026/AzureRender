from pathlib import Path
import json,collections,subprocess,hashlib,sys
root=Path.cwd();out=Path(__file__).resolve().parent;producer=root/'build/runs/20261111-001050-quad-feature-device-capture-4798d1';sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
before=inputs(root);full=json.loads((producer/'pipeline-scope.json').read_text());profile=json.loads((producer/'profile-state.json').read_text())
assert full['captureSha256']==profile['captureSha256']
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());byName={p['output']:p for p in manifest['programs']};rows=[];programs={};timedEvents=set()
for group in full['groups']:
    assert not timedEvents.intersection(group['events']);timedEvents.update(group['events'])
    pixel=next((s for s in group['shaders'] if s['stage']=='ShaderStage.Pixel'),None)
    if pixel is None:continue
    names=[n for n in pixel['programFiles'] if n in byName and byName[n]['source']=='mesh.frag' and not any(v in byName[n]['defines'] for v in ['AZURE_VIEW_FOG=1','AZURE_HAIR_PIXEL_INTEGRAL=1','AZURE_GEOMETRY_SAMPLES=1'])]
    if not names:continue
    name=names[0]
    if name not in programs:
        path=root/'build/ninja-msvc-release/shaders'/name;assert digest(path)==pixel['sha256']
        r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-dis.exe',str(path)],capture_output=True,text=True,timeout=15);assert r.returncode==0
        programs[name]=dict(sha256=digest(path),earlyFragmentTests=any('OpExecutionMode' in line and 'EarlyFragmentTests' in line for line in r.stdout.splitlines()),defines=byName[name]['defines'])
    spec={v['id']:v['valueU32'] for v in group.get('specialization',[])}
    ordinary=spec.get(0)==1;fixedClass=spec.get(1,0xffffffff)
    row=dict(pipeline=group['pipeline'],program=name,events=len(group['events']),milliseconds=group['milliseconds'],psInvocations=group['psInvocations'],samplesPassed=group['samplesPassed'],ordinary=ordinary,fixedClass=fixedClass,earlyFragmentTests=programs[name]['earlyFragmentTests'],specialization=group.get('specialization',[]))
    rows.append(row)
assert len(timedEvents)==3453 and sum(r['events'] for r in rows)==1006 and len(programs)==10
totals={}
for name,predicate in [('all-material',lambda r:True),('early',lambda r:r['earlyFragmentTests']),('late',lambda r:not r['earlyFragmentTests']),('ordinary',lambda r:r['ordinary']),('class-specialized',lambda r:not r['ordinary'] and r['fixedClass']!=0xffffffff),('dynamic',lambda r:not r['ordinary'] and r['fixedClass']==0xffffffff)]:
    selected=[r for r in rows if predicate(r)];total={k:sum(r[k] for r in selected) for k in ['events','milliseconds','psInvocations','samplesPassed']}
    total.update(frameShare=total['milliseconds']/full.get('sumEventMs',profile['sumEventMs']),psToPassedRatio=total['psInvocations']/max(1,total['samplesPassed']),positiveInvocationDifference=sum(max(0,r['psInvocations']-r['samplesPassed']) for r in selected));totals[name]=total
result=dict(status='actual-material-fragment-scope',sourceBase='f3071a4',captureSourceBase=full['sourceHead'],captureSha256=full['captureSha256'],totalEvents=3453,materialPipelines=len(rows),programs=programs,groups=rows,totals=totals,scope='Existing complete capture timing and generic counters; positive PS-minus-passed difference is descriptive and includes shader/coverage/helper effects, not a proven removable overdraw count',nativeAdmission=False,sourceUnchanged=inputs(root)==before)
assert result['sourceUnchanged'];(out/'results.json').write_text(json.dumps(result,indent=2));(out/'source-lock.json').write_text(json.dumps(before,indent=2))
print(json.dumps(totals,indent=2));print('Pipeline groups',len(rows))
