"""Read before and after a real draw on the explicitly selected D3D11 GPU."""
import array
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback

import renderdoc as rd

request=json.loads(Path(os.environ['AZURE_NATIVE_DEPTH_REPLAY_REQUEST']).read_text(encoding='utf-8-sig'))
output=Path(request['output'])
vendor=getattr(rd.GPUVendor,request['vendor'])
event=request['event']
report=dict(status='failed',requestedVendor=str(vendor),event=event)
capture=controller=None

def actions(nodes):
    for node in nodes:
        yield node
        yield from actions(node.children)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def depth_component(data,format_name,pixels):
    if format_name=='D32S8_TYPELESS':
        assert len(data)==pixels*8,(len(data),pixels*8)
        words=array.array('I')
        assert sys.byteorder=='little' and words.itemsize==4
        words.frombytes(data)
        return words[::2].tobytes()
    assert len(data)==pixels*4,(len(data),pixels*4)
    return data

try:
    capture=rd.OpenCaptureFile()
    assert capture.OpenFile(request['capture'],'',None)==rd.ResultCode.Succeeded
    available=[device for device in capture.GetAvailableGPUs() if device.vendor==vendor and rd.GraphicsAPI.D3D11 in device.apis]
    assert len(available)==1,[(str(device.vendor),device.deviceID,device.name) for device in available]
    options=rd.ReplayOptions()
    options.forceGPUVendor=vendor
    options.forceGPUDeviceID=available[0].deviceID
    report.update(requestedDeviceId=available[0].deviceID,requestedDeviceName=available[0].name)
    status,controller=capture.OpenCapture(options,None)
    assert status==rd.ResultCode.Succeeded and controller,str(status)
    properties=controller.GetAPIProperties()
    report.update(activeVendor=str(properties.vendor),pipeline=str(properties.pipelineType),degraded=properties.degraded)
    assert properties.vendor==vendor and properties.pipelineType==rd.GraphicsAPI.D3D11 and not properties.degraded
    action=next(a for a in actions(controller.GetRootActions()) if a.eventId==event)
    assert action.flags&rd.ActionFlags.Drawcall
    texture=next(t for t in controller.GetTextures() if t.resourceId==action.depthOut)
    usages=[dict(event=u.eventId,usage=str(u.usage)) for u in controller.GetUsage(action.depthOut) if u.eventId<=event]
    assert any(u['event']==event and 'DepthStencilTarget' in u['usage'] for u in usages),usages[-15:]
    report.update(depthResource=str(action.depthOut),depthFormat=texture.format.Name(),indices=action.numIndices,
        extent=[texture.width,texture.height],uses=usages)
    format_name=texture.format.Name()
    assert [texture.width,texture.height]==[2560,1440] and format_name in ('R32_TYPELESS','D32_FLOAT','R32_FLOAT','D32S8_TYPELESS')
    controller.SetFrameEvent(event-1,True)
    raw_before=bytes(controller.GetTextureData(action.depthOut,rd.Subresource(0,0,0)))
    controller.SetFrameEvent(event,True)
    raw_after=bytes(controller.GetTextureData(action.depthOut,rd.Subresource(0,0,0)))
    report.update(rawDepthBytes=[len(raw_before),len(raw_after)],rawDepthSha256=[digest(raw_before),digest(raw_after)])
    before=depth_component(raw_before,format_name,2560*1440)
    after=depth_component(raw_after,format_name,2560*1440)
    assert len(before)==len(after)==2560*1440*4 and before!=after
    report.update(beforeSha256=digest(before),afterSha256=digest(after),bytes=len(after),
        debugMessages=[message.description for message in controller.GetDebugMessages()])
    with (output/'depth-before.bin').open('xb') as handle:
        handle.write(before)
    with (output/'depth-after.bin').open('xb') as handle:
        handle.write(after)
    visibility_event=request['visibilityEvent']
    controller.SetFrameEvent(visibility_event,True)
    pipeline=controller.GetPipelineState()
    reflection=pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
    stage=pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel)
    textures={str(item.resourceId):item for item in controller.GetTextures()}
    visibility_inputs={}
    expected_extent={0:(2560,1440,4),2:(4096,2048,2),6:(2560,1440,4)}
    for binding in stage:
        slot=reflection.readOnlyResources[binding.access.index].fixedBindNumber
        if slot not in expected_extent:
            continue
        resource=binding.descriptor.resource
        description=textures[str(resource)]
        width,height,texel_bytes=expected_extent[slot]
        assert (description.width,description.height)==(width,height) and slot not in visibility_inputs
        data=bytes(controller.GetTextureData(resource,rd.Subresource(0,0,0)))
        assert len(data)==width*height*texel_bytes
        visibility_inputs[slot]=dict(resource=str(resource),format=description.format.Name(),sha256=digest(data),bytes=len(data))
        if slot==0:
            assert description.format.Name()=='R32_FLOAT'
            report.update(visibilityDepthSha256=digest(data),
                visibilityUses=[dict(event=u.eventId,usage=str(u.usage)) for u in controller.GetUsage(resource) if u.eventId<=visibility_event])
            with (output/'visibility-depth.bin').open('xb') as handle:
                handle.write(data)
    assert set(visibility_inputs)=={0,2,6},visibility_inputs
    report.update(visibilityEvent=visibility_event,visibilityInputs=visibility_inputs)
    hair_event=request['hairColorEvent']
    controller.SetFrameEvent(hair_event,True)
    try:
        targets=controller.GetPipelineState().GetOutputTargets()
        target=targets[0].resource
        description=textures[str(target)]
        assert description.format.Name()=='R11G11B10_FLOAT'
        assert (description.width,description.height)==(2560,1440)
        output_uses=[str(u.usage) for u in controller.GetUsage(target) if u.eventId==hair_event]
        assert any('ColorTarget' in usage for usage in output_uses),output_uses
        color=bytes(controller.GetTextureData(target,rd.Subresource(0,0,0)))
        assert len(color)==2560*1440*4
        pixels=[]
        for y in range(130,440):
            offset=((1439-y)*2560+1140)*4
            pixels.append(color[offset:offset+290*4])
        crop=b''.join(pixels)
        report['hairColor']=dict(event=hair_event,resource=str(target),format=description.format.Name(),
            sha256=digest(color),cropSha256=digest(crop),uses=output_uses)
        with (output/'hair-color-crop.bin').open('xb') as handle:
            handle.write(crop)
    except Exception:
        report['hairColorDiagnostic']=traceback.format_exc()
    report['status']='collected'
except Exception:
    report['failure']=traceback.format_exc()
finally:
    if controller:
        controller.Shutdown()
    if capture:
        capture.Shutdown()
    (output/'replay-result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
os._exit(0 if report['status']=='collected' else 1)
