from pathlib import Path
import json,sys,time

out=Path(__file__).resolve().parent
root=out.parents[2]
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared

claim_path=Path('D:/Projects/FYP-coordination/quality-claim.json')
claim=json.loads(claim_path.read_text(encoding='utf-8'))
owner=claim['threadId']
assert owner=='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
previous=out.parent/'20261111-072757-material-ellipse-coverage-policy-3e26b6'
main_inputs=['20261022-201845-endfield-capture-954719','20261103-234012-character-reference-stages-5abe6c']
original_depth=shared.DEFAULT_BUILD/'runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/native-t0.bin'
if original_depth.is_file():
    main_inputs.append(original_depth.parent.name)
main_lease=shared.acquire_inputs(shared.DEFAULT_BUILD,out,main_inputs,owner)
local_lease=shared.acquire_inputs(root/'build',out,[previous.name,'20261110-112309-hair-relative-projection-control-b9da17'],owner)
for name in (previous.name,'20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2'):
    shared.maintenance.seal(root/'build',out.parent/name)
for token in claim.get('inputLease',[]):
    shared.release_inputs(shared.DEFAULT_BUILD,token,owner)
for token in claim.get('localInputLease',[]):
    shared.release_inputs(root/'build',token,owner)
claim.update(state='native-d3d11-depth-device-source',lastCommit='698e53d',taskPath=str(out),inputLease=[main_lease],
    localInputLease=[local_lease],nativeCaptureLease=main_lease,ownedFiles=[],
    pendingCommand='Replay native frame 10401 on each actual GPU; compare written depth and frozen receiver inputs')
claim_path.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ('native-depth-device-worker.py','next-native-source.json'):
    (out/name).write_bytes((previous/name).read_bytes())
card=dict(baseCommit='698e53d',created=time.time(),locationSeconds=600,candidateSeconds=1200,
    explorationSeconds=1800,gpuSeconds=720,plannedBytes=134217728,nativeEvent=422,visibilityEvent=699,
    sourceFrozenNativeDepth=str(original_depth) if original_depth.is_file() else None,
    deliverable='Actual D3D11 depth writes by hardware GPU with unchanged capture and localized frozen mask comparison')
(out/'task-card.json').write_text(json.dumps(card,indent=2)+'\n')
print(json.dumps(card))
