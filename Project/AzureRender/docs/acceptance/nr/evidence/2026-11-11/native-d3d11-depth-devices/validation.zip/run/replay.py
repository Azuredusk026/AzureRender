from pathlib import Path
import hashlib,json,os,subprocess,sys

out=Path(__file__).resolve().parent
source=json.loads((out/'next-native-source.json').read_text())
device=sys.argv[1]
vendor={'nvidia':'nVidia','intel':'Intel'}[device]
folder=out/(device+'-replay')
folder.mkdir()
capture=Path(source['path'])
def capture_hash():
    with capture.open('rb') as file:
        return hashlib.file_digest(file,'sha256').hexdigest()
assert capture_hash()==source['sha256']
request=folder/'request.json'
request.write_text(json.dumps(dict(output=str(folder),capture=str(capture),vendor=vendor,
    event=source['depthEvent'],visibilityEvent=699,hairColorEvent=source['hairColorEvent']),indent=2)+'\n')
environment=os.environ.copy()
for key in ('VK_LAYER_PATH','VK_INSTANCE_LAYERS','ENABLE_VULKAN_RENDERDOC_CAPTURE','VK_LOADER_DRIVERS_SELECT','VK_DRIVER_FILES','VK_ICD_FILENAMES'):
    environment.pop(key,None)
environment['AZURE_NATIVE_DEPTH_REPLAY_REQUEST']=str(request)
startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'native-depth-device-worker.py')]
(folder/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (folder/'replay.log').open('wb') as log:
    result=subprocess.run(command,cwd=folder,env=environment,startupinfo=startup,stdout=log,stderr=subprocess.STDOUT,timeout=270)
receipt=json.loads((folder/'replay-result.json').read_text())
assert capture_hash()==source['sha256']
assert result.returncode==0 and receipt['status']=='collected',receipt
assert receipt['activeVendor']==receipt['requestedVendor'] and not receipt['degraded'],receipt
print(json.dumps({k:v for k,v in receipt.items() if k not in ('uses','visibilityUses','debugMessages')}))
