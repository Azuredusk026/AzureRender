from pathlib import Path
import json,subprocess,sys,time

out=Path(__file__).resolve().parent
queue=Path('D:/Projects/FYP-coordination/resources/current.json')
blocked=sys.argv[1] if len(sys.argv)>1 else None

def status():
    try:
        return json.loads(queue.read_text(encoding='utf-8'))
    except (OSError,ValueError):
        return {}

for device in ('nvidia','intel'):
    receipt=out/(device+'-execution.json')
    if receipt.exists():
        data=json.loads(receipt.read_text())
        if data['status']=='exited' and data['exitCode']==0:
            continue
        raise RuntimeError('Previous replay needs investigation: '+device)
    while True:
        deadline=time.monotonic()+3600
        while time.monotonic()<deadline:
            state=status()
            if state and (state.get('state')!='held' or state.get('token')!=blocked):
                break
            time.sleep(2)
        else:
            raise TimeoutError('No shared queue change observed')
        print('Queue request '+device,flush=True)
        result=subprocess.run([sys.executable,str(out/'queued-replay.py'),device],capture_output=True,text=True)
        print(result.stdout,flush=True,end='')
        if not result.returncode:
            blocked=None
            break
        print(result.stderr,flush=True,end='',file=sys.stderr)
        if receipt.exists() or 'Native replay queue window ended before execution' not in result.stderr:
            raise RuntimeError('Replay needs investigation: '+device)
        blocked=status().get('token')
    time.sleep(4)
subprocess.run([sys.executable,str(out/'compare-depth.py')],check=True)
