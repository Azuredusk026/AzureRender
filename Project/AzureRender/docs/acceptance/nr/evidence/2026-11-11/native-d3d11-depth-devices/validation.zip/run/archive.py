from pathlib import Path
import hashlib,json,re,zipfile

out=Path(__file__).resolve().parent
root=out.parents[2]
dest=root/'docs/acceptance/nr/evidence/2026-11-11/native-d3d11-depth-devices'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
comparison=load(out/'comparison.json')
assert comparison['maskPixels']==17017 and comparison['writeSetDifferences']==0
assert comparison['devices']['intel']['replayedVsVulkan']['exact']==17014
assert comparison['devices']['intel']['hairColorVsFrozen']['overOne']==580
assert comparison['devices']['intel']['runtimeVsSameDeviceD3D11']['bothOverOneVsFrozen']==562
assert comparison['sharedSameDeviceRuntimeFailures']['count']==27
receipts={}
for device in ('nvidia','intel'):
    process=load(out/(device+'-execution.json'))
    assert process['status']=='exited' and process['exitCode']==0
    replay=load(out/(device+'-replay/replay-result.json'))
    assert replay['status']=='collected' and not replay['degraded'] and replay['activeVendor']==replay['requestedVendor']
    assert replay['rawDepthBytes']==[29491200,29491200]
    assert comparison['devices'][device]['producerMatchesConsumer']['exact']==17017
    receipts[device]=dict(process=process,requestedDevice=replay['requestedDeviceName'],debugMessages=replay['debugMessages'])
old=load(root/'docs/acceptance/nr/evidence/2026-11-11/material-ellipse-coverage-policy/results.json')
assert old['defaultRegression']['allExact']
result=dict(baseCommit='698e53d',productionSourceChanged=False,acceptedFrozenMaximumColorError=1,comparison=comparison,
    source=load(out/'next-native-source.json'),receipts=receipts,previousDefaultFour=old['defaultRegression'])
docs=[root/'docs/acceptance/nr/native-d3d11-depth-devices.md',root/'docs/plans/2026-11-11-native-d3d11-depth-devices.md']
members={'source/'+p.relative_to(root).as_posix():p for p in docs}
for path in out.iterdir():
    if path.is_file() and path.suffix in {'.py','.json','.log'}:
        members['run/'+path.name]=path
for folder in ('nvidia','failed-depth-format-nvidia','nvidia-replay','intel-replay'):
    for path in (out/folder).glob('*'):
        if path.is_file() and (path.suffix in {'.json','.log','.npy'} or path.name=='hair-color-crop.bin'):
            members['run/'+folder+'/'+path.name]=path
dest.mkdir(parents=True,exist_ok=True)
archive=dest/'validation.zip'
manifest={name:dict(bytes=path.stat().st_size,sha256=sha(path)) for name,path in members.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as file:
    for name,path in sorted(members.items()):
        file.write(path,name)
    file.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as file:
    assert file.testzip() is None
    for name,value in manifest.items():
        assert hashlib.sha256(file.read(name)).hexdigest()==value['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']=dict(bytes=archive.stat().st_size,sha256=sha(archive),members=len(members)+1)
(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n')
for path in docs:
    text=path.read_text(encoding='utf-8')
    for sentence in re.split('[。！？\n]',text):
        assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(path,sentence)
    for paragraph in text.split('\n\n'):
        if not paragraph.startswith('- '):
            assert paragraph.count('。')<=4,(path,paragraph)
    for link in re.findall(r'\]\(([^)]+)\)',text):
        if not link.startswith('https:'):
            assert (path.parent/link).exists(),(path,link)
print(json.dumps(result['archive']))
