from pathlib import Path
import hashlib,io,json,runpy,sys,zipfile

import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
root=out.parents[2]
base=runpy.run_path(str(out.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
ys,xs=np.nonzero(base['mask'])
x=xs+1140
y=1439-(ys+130)
assert len(x)==17017
task=json.loads((out/'task-card.json').read_text())
sha=lambda data: hashlib.sha256(data).hexdigest()
def plane(data):
    assert len(data)==2560*1440*4
    return np.frombuffer(data,dtype='<u4').reshape(1440,2560)

with zipfile.ZipFile(root/'docs/acceptance/nr/evidence/2026-11-11/actual-geometry-uv-source/validation.zip') as archive:
    vulkan={device:plane(archive.read('run/'+device+'-actual-r32.bin')) for device in ('nvidia','intel')}
reference_path=task.get('sourceFrozenNativeDepth')
if reference_path:
    raw=Path(reference_path).read_bytes()
    assert sha(raw)=='02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb'
    frozen=plane(raw)[y,x]
else:
    frozen=vulkan['nvidia'][y,x]
assert np.array_equal(frozen,vulkan['nvidia'][y,x])
def compare(a,b):
    ulp=abs(a.astype('i8')-b.astype('i8'))
    return dict(exact=int((ulp==0).sum()),different=int((ulp!=0).sum()),withinOneUlp=int((ulp<=1).sum()),
        maximumUlp=int(ulp.max()),clearMismatches=int(((a==0)!=(b==0)).sum()))

vulkan_between=compare(vulkan['intel'][y,x],vulkan['nvidia'][y,x])
if '--inputs-only' in sys.argv:
    preflight=dict(maskPixels=len(x),frozenNvidiaVulkanExact=True,vulkanBetweenDevices=vulkan_between)
    (out/'inputs-verified.json').write_text(json.dumps(preflight,indent=2)+'\n')
    print(json.dumps(preflight))
    raise SystemExit(0)

def display_rgb(packed):
    channels=[]
    for shift,bits in ((0,6),(11,6),(22,5)):
        value=(packed>>shift)&((1<<(bits+5))-1)
        exponent=(value>>bits).astype('i4')
        fraction=(value&((1<<bits)-1)).astype('f8')
        assert np.all(exponent!=31)
        channels.append(np.where(exponent==0,np.ldexp(fraction,-14-bits),np.ldexp(1+fraction/(1<<bits),exponent-15))*.25)
    linear=np.stack(channels,axis=-1)
    srgb=np.where(linear<=.0031308,12.92*linear,1.055*np.power(linear,1/2.4)-.055)
    return np.rint(np.clip(srgb,0,1)*255).astype('i4')

rows={}
replayed={}
changed_sets={}
same_device_failures={}
previous=out.parent/'20261111-072757-material-ellipse-coverage-policy-3e26b6'
probe_pixels=[(1326,177),(1375,276),(1322,320),(1324,289)]
for device in ('nvidia','intel'):
    folder=out/(device+'-replay')
    receipt=json.loads((folder/'replay-result.json').read_text())
    assert receipt['status']=='collected' and receipt['activeVendor']==receipt['requestedVendor'] and not receipt['degraded']
    after_data=(folder/'depth-after.bin').read_bytes()
    before_data=(folder/'depth-before.bin').read_bytes()
    assert sha(after_data)==receipt['afterSha256'] and sha(before_data)==receipt['beforeSha256']
    after,before=plane(after_data),plane(before_data)
    changed_sets[device]=after!=before
    np.save(folder/'selected-before.npy',before[y,x])
    np.save(folder/'selected-after.npy',after[y,x])
    rows[device]=dict(changedWhole=int((after!=before).sum()),changedMask=int((after[y,x]!=before[y,x]).sum()),
        afterVsFrozen=compare(after[y,x],frozen),activeVendor=receipt['activeVendor'])
    assert rows[device]['changedWhole']>0
    replayed[device]=after[y,x]
    depth_data=(folder/'visibility-depth.bin').read_bytes()
    assert sha(depth_data)==receipt['visibilityDepthSha256']
    replayed[device]=plane(depth_data)[y,x]
    rows[device]['producerMatchesConsumer']=compare(after[y,x],replayed[device])
    rows[device]['visibilityDepthVsFrozen']=compare(replayed[device],frozen)
    rows[device]['visibilityInputFingerprints']=receipt['visibilityInputs']
    rows[device]['replayedVsVulkan']=compare(replayed[device],vulkan[device][y,x])
    if receipt.get('hairColor'):
        color=(folder/'hair-color-crop.bin').read_bytes()
        assert sha(color)==receipt['hairColor']['cropSha256']
        packed=np.frombuffer(color,dtype='<u4').reshape(310,290)[base['mask']]
        native_packed=base['packed'][base['mask']]
        native_display=display_rgb(packed)
        frozen_display=base['expected'][base['mask']]
        difference=abs(native_display-frozen_display).max(axis=1)
        rows[device]['hairColorVsFrozen']=dict(packedExact=int((packed==native_packed).sum()),overOne=int((difference>1).sum()),
            maximumByteError=int(difference.max()),source=receipt['hairColor'])
        runtime_path=previous/('release-'+device+'-hair-coverage-frames/frame_000000.png')
        rgb=np.asarray(Image.open(runtime_path).convert('RGB'))[130:440,1140:1430][base['mask']].astype('i4')
        runtime_vs_frozen=abs(rgb-frozen_display).max(axis=1)
        same_device=abs(rgb-native_display).max(axis=1)
        same_device_failures[device]=same_device>1
        rows[device]['runtimeVsSameDeviceD3D11']=dict(overOne=int((same_device>1).sum()),maximumByteError=int(same_device.max()),
            exact=int((same_device==0).sum()),bothOverOneVsFrozen=int(((runtime_vs_frozen>1)&(difference>1)).sum()),
            runtimeOnlyOverOneVsFrozen=int(((runtime_vs_frozen>1)&(difference<=1)).sum()),
            d3dOnlyOverOneVsFrozen=int(((runtime_vs_frozen<=1)&(difference>1)).sum()))
        if device=='intel':
            prior=root/'docs/acceptance/nr/evidence/2026-11-11/native-hair-coverage-lod/validation.zip'
            with zipfile.ZipFile(prior) as archive:
                data=archive.read('run/intel-hair-coverage-crop.png')
            device_coverage=np.asarray(Image.open(io.BytesIO(data)).convert('RGB'))[base['mask']].astype('i4')
            prior_difference=abs(device_coverage-native_display).max(axis=1)
            rows[device]['runtimeDeviceCoverageVsSameDeviceD3D11']=dict(
                overOne=int((prior_difference>1).sum()),maximumByteError=int(prior_difference.max()),
                exact=int((prior_difference==0).sum()),ellipseChangedPixels=int(np.any(device_coverage!=rgb,axis=1).sum()),
                strongest=[dict(pixel=[int(x[k]),int(1439-y[k])],maximumByteError=int(prior_difference[k]),
                    nativeDeviceRgb=native_display[k].tolist(),runtimeRgb=device_coverage[k].tolist())
                    for k in np.argsort(prior_difference)[-5:][::-1]])
        location=np.flatnonzero(replayed[device]!=vulkan[device][y,x])
        all_probes=sorted(set(probe_pixels)|{(int(x[k]),int(1439-y[k])) for k in location})
        rows[device]['probePixels']=[]
        for ui_x,ui_y in all_probes:
            hit=np.flatnonzero((x==ui_x)&(y==1439-ui_y))
            assert len(hit)==1,(ui_x,ui_y)
            k=hit[0]
            d3d_depth=int(replayed[device][k])
            vulkan_depth=int(vulkan[device][y[k],x[k]])
            rows[device]['probePixels'].append(dict(pixel=[ui_x,ui_y],d3dDepthBits=d3d_depth,
                vulkanDepthBits=vulkan_depth,depthUlp=abs(d3d_depth-vulkan_depth),
                frozenRgb=frozen_display[k].tolist(),nativeDeviceRgb=native_display[k].tolist(),runtimeRgb=rgb[k].tolist()))
    else:
        rows[device]['hairColorDiagnostic']=receipt.get('hairColorDiagnostic')
    np.save(folder/'selected-depth.npy',replayed[device])
result=dict(status='actual-d3d11-depth-replay-compared',scope='Actual event 422 output and visibility depth input at event 699',
    overall='failed-user-review',maskPixels=len(x),devices=rows,betweenDevices=compare(replayed['intel'],replayed['nvidia']),
    frozenVulkanBetweenDevices=vulkan_between,writeSetDifferences=int((changed_sets['intel']!=changed_sets['nvidia']).sum()))
if set(same_device_failures)=={'nvidia','intel'}:
    both=same_device_failures['nvidia']&same_device_failures['intel']
    result['sharedSameDeviceRuntimeFailures']=dict(count=int(both.sum()),
        pixels=[[int(x[k]),int(1439-y[k])] for k in np.flatnonzero(both)])
(out/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
