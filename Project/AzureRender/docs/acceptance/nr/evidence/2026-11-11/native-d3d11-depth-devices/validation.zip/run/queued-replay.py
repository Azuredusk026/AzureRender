from pathlib import Path
import json,subprocess,sys,time

out=Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared

device=sys.argv[1]
confirmation=out/'main-gpu-released.json'
confirmed_until=time.monotonic()+1800
while not confirmation.is_file():
    if time.monotonic()>=confirmed_until:
        raise TimeoutError('Main GPU process retirement was not confirmed')
    time.sleep(2)
started=time.monotonic()
while True:
    lease=shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-native-d3d11-depth-'+device,out)
    try:
        lease.__enter__()
        break
    except ValueError as error:
        if not any(part in str(error) for part in ('busy','still running')):
            raise
        if time.monotonic()-started>=180:
            raise TimeoutError('Native replay queue window ended before execution')
        time.sleep(1)
try:
    result=shared.maintenance.guarded_run(out.parents[1],out.name,[sys.executable,str(out/'replay.py'),device],330)
    (out/(device+'-execution.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
    assert result['status']=='exited' and result['exitCode']==0,result
finally:
    lease.__exit__(None,None,None)
