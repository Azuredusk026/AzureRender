from pathlib import Path
import json,sys

out=Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared

for build in (shared.DEFAULT_BUILD,out.parents[1]):
    with shared.maintenance.database(build) as db:
        data=shared.maintenance.rows(db)
    rows=[{'owner':row.get('owner'),'inputs':row.get('inputs')} for row in data.values()
        if row.get('externalConsumer') and Path(row['externalConsumer'])==out]
    print(json.dumps(dict(build=str(build),leases=rows)))
    if build==out.parents[1]:
        for name in ('20261111-072757-material-ellipse-coverage-policy-3e26b6',
            '20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2'):
            row=data.get(name,{})
            print(json.dumps(dict(name=name,status=row.get('status'),generation=row.get('generation'))))
