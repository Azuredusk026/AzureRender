from pathlib import Path
import json,zipfile,shutil,sys,subprocess
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261111-005441-reference-position-frame-main-integration-59835c';sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
identities=json.loads((prior/'host-identities.json').read_text());baseline={}
for config in ['debug','release']:
    hashes=json.loads((prior/(config+'-program-sha256.json')).read_text());assert len(hashes)==859
    build=root/('build/ninja-msvc-'+config);assert all(digest(build/'shaders'/n)==h for n,h in hashes.items())
    assert all(digest(build/n)==v['sha256'] for n,v in identities[config].items())
    baseline[config]=dict(hosts=identities[config],shaders=hashes)
(out/'baseline-products.json').write_text(json.dumps(baseline,indent=2))
for name in ['baseline-dlls.json','protected-files.json','frozen-project-inputs.json','quality-program-sha256.json']:shutil.copyfile(prior/name,out/name)
critical=['ReferenceCameraView.hpp','ReferenceCameraDepth.hpp','ReferenceDepth.hpp','ReferenceDepthConvention.hpp','ReferenceClipProjection.hpp','ReferencePositionFrame.hpp']
diff=subprocess.run(['git','diff','7d9dd54','HEAD','--',*['src/render/'+n for n in critical],'tests/ReferenceCameraViewTests.cpp'],capture_output=True,text=True,check=True);assert not diff.stdout
(out/'child-scope-review.json').write_text(json.dumps(dict(sourceCommit='7d9dd54',integrationCommit='6721bde',archiveSha256='350c4286cfcea6ebfa0b9c94a535acd7a27b6dd3dba72fe42fc08c8fd9ad714d',members=86,memberHashesVerified=85,criticalSourceDiffEmpty=True,criticalHeaders=critical,gpuReuse='Child complete 7372800-value and 17017-visibility-per-device batch; identical source contracts and all 858 child programs; root native camera queries and affected GPU contracts independently rerun'),indent=2))
with zipfile.ZipFile(root/'docs/acceptance/nr/evidence/2026-11-11/reference-camera-view/validation.zip') as z:
    for name in ['profile','frame','positions','queries']:(out/(name+'.bin')).write_bytes(z.read('inputs/'+name+'.bin'))
shutil.copyfile(prior/'capture.py',out/'capture.py')
(out/'source-lock.json').write_text(json.dumps(inputs(root),indent=2))
print('Baseline 859 programs, actual hosts, source scope and four native CPU fixtures frozen')
