from pathlib import Path
import sys,json,zipfile,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,digest,inputs
def read(name):return json.loads((out/name).read_text())
for config in ['debug','release']:
    proof=read(config+'-build-provenance.json');verify(root,proof)
    assert proof==json.loads((root/('build/ninja-msvc-'+config)/'build-provenance.json').read_text())
assert inputs(root)==read('source-lock.json')
assert all(digest(root/p)==h for p,h in read('protected-files.json').items())
lock=read('frozen-project-inputs.json');assert len(lock)==1729 and all(digest(Path(p))==h for p,h in lock.items())
build=read('build-results.json');assert sum(r['tests'] for r in build['checks'])==20 and len(build['gpuProcesses'])==8
assert all(r['skips']==0 for r in build['checks'])
fresh=(out/'capture-results.json').exists();duplicates=[]
prior=root/'build/runs/20261111-005441-reference-position-frame-main-integration-59835c'
capture=read('capture-results.json') if fresh else json.loads((prior/'capture-results.json').read_text())
assert capture['exitCode']==0 and len(capture['frames'])==4
assert all(capture[k] for k in ['validationClean','allocatorZero','sourceUnchanged','programsUnchanged','projectInputsUnchanged'])
reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames'
if not fresh:
    reuse=read('capture-reuse.json');assert reuse['allPlayerSectionsExact'] and reuse['dllsExact'] and reuse['all859ProgramsExact']
for frame in capture['frames']:
    original=reference/frame['name'];assert frame['changedPixels']==frame['maximumByteError']==0
    assert digest(original)==frame['sha256']==frame['referenceSha256']
    if fresh:
        path=out/'frames'/frame['name'];assert digest(path)==frame['sha256']
        duplicates.append(dict(path=str(path),original=str(original),bytes=path.stat().st_size,sha256=digest(path)))
result=dict(status='reference-camera-view-main-integration-qualified',runtimeSourceCommit='6721bde',sourceBranchCommit='7d9dd54',build=build,originalFour=dict(method='fresh-capture' if fresh else 'identical-player-sections-dependencies-and-programs',result=capture),protectedFilesExact=13,projectInputsExact=1729,sourceProofsFresh=True,childGpuScope=read('child-scope-review.json'),overall='failed-user-review',formalPerformanceAccepted=False)
(out/'results.json').write_text(json.dumps(result,indent=2))
(out/'duplicate-frame-inventory.json').write_text(json.dumps(duplicates,indent=2))
dest=root/'docs/acceptance/nr/evidence/2026-11-11/reference-camera-view-main-integration';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.iterdir()):
        if p.is_file() and p.suffix in ['.json','.py','.log','.xml','.csv','.bin']:
            members[p.name]=dict(bytes=p.stat().st_size,sha256=digest(p));z.write(p,p.name)
    z.writestr('member-sha256.json',json.dumps(members,indent=2))
assert archive.stat().st_size<8*1024*1024
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and all(len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in members.items())
verification=dict(bytes=archive.stat().st_size,members=len(members)+1,sha256=digest(archive),memberHashesVerified=True)
(dest/'archive-verification.json').write_text(json.dumps(verification,indent=2));(dest/'results.json').write_text(json.dumps(result,indent=2))
for item in duplicates:
    p=Path(item['path']);assert p.parent.resolve()==(out/'frames').resolve()
    assert digest(p)==digest(Path(item['original']))==item['sha256'];p.unlink()
(out/'identical-frames-reclaimed.json').write_text(json.dumps(dict(bytes=sum(x['bytes'] for x in duplicates),files=len(duplicates),archive=verification),indent=2))
print(json.dumps(verification))
