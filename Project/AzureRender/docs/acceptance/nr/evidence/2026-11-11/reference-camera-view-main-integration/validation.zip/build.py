from pathlib import Path
import json,os,subprocess,sys,shutil,time,struct,hashlib,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,verify,digest
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
def sections(path):
    b=path.read_bytes();pe=struct.unpack_from('<I',b,0x3c)[0];count=struct.unpack_from('<H',b,pe+6)[0];size=struct.unpack_from('<H',b,pe+20)[0];a={}
    for i in range(count):
        at=pe+24+size+i*40;n=b[at:at+8].rstrip(b'\0').decode();length,offset=struct.unpack_from('<II',b,at+16);a[n]=hashlib.sha256(b[offset:offset+length]).hexdigest()
    return a
before=inputs(root);assert before==json.loads((out/'source-lock.json').read_text());checks=[];gpu=[];identities={}
targets=['AzureReferenceCameraViewTests','AzureReferencePositionFrameGpuTests','AzureReferenceClipProjectionGpuTests','AzureReferenceDepthGpuTests','AzureReferenceDepthCoverageGpuTests','AzureHotReloadTests','AzureShaderCompilerContractTests']
selector=r'^(AzureRender\.(ReferenceCameraView|ReferencePositionFrameGpu|ReferenceClipProjectionGpu|ReferenceDepthGpu|ReferenceDepthCoverageGpu|ShaderCompilerContract|ShaderCatalogCompilation|HotReload)|AzureEngine\.(ModuleBoundaries|ModuleBoundaryFixtures))$'
for config in ['Release','Debug']:
    build=root/('build/ninja-msvc-'+config.lower());os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';start=time.monotonic()
    command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
    for target in targets:command+=['--test-target',target]
    with (out/(config.lower()+'-build.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
    baseline=json.loads((out/'baseline-products.json').read_text())[config.lower()];manifest=json.loads((build/'shader-reload.json').read_text());assert len(manifest['programs'])==859
    hashes={p['output']:digest(build/'shaders'/p['output']) for p in manifest['programs']};child=json.loads((out/'quality-program-sha256.json').read_text())
    assert hashes==baseline['shaders'] and len(child)==858 and all(hashes.get(n)==h for n,h in child.items())
    (out/(config.lower()+'-program-sha256.json')).write_text(json.dumps(hashes,indent=2));shutil.copyfile(build/'build-provenance.json',out/(config.lower()+'-build-provenance.json'))
    identities[config.lower()]={n:dict(sha256=digest(build/n),sections=sections(build/n),allSectionsExact=sections(build/n)==v['sections'],allBytesExact=digest(build/n)==v['sha256']) for n,v in baseline['hosts'].items()}
    command=['ctest','--test-dir',str(build),'-C',config,'--output-on-failure','--no-tests=error','-R',selector,'--output-junit',str(out/(config.lower()+'-tests.xml'))]
    with (out/(config.lower()+'-tests.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=420)
    cases=ET.parse(out/(config.lower()+'-tests.xml')).findall('.//testcase');assert len(cases)==10 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
    with (out/(config.lower()+'-native-camera.log')).open('wb') as log:subprocess.run([str(build/'AzureReferenceCameraViewTests.exe'),*[str(out/(name+'.bin')) for name in ['profile','frame','positions','queries']]],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
    text=(out/(config.lower()+'-native-camera.log')).read_text();assert '16 rejects; nativeRays=17017 visibleVertices=11564' in text,text
    for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
        os.environ['VK_LOADER_DRIVERS_SELECT']=driver
        for target,expected in [('AzureReferenceDepthGpuTests','147840 exact R32/D32 values'),('AzureReferenceDepthCoverageGpuTests','20992 exact masked R32/D32 values')]:
            path=out/(config.lower()+'-'+device+'-'+target+'.log')
            with path.open('wb') as log:subprocess.run([str(build/(target+'.exe')),str(build/'shaders')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
            text=path.read_text(errors='replace');assert expected in text and ('Intel' if device=='intel' else 'NVIDIA') in text
            assert not any(s in text for s in ['VUID-','SYNC-HAZARD','Validation Error:','Validation Warning:']);gpu.append(dict(config=config,device=device,target=target,passed=True))
    verify(root,json.loads((build/'build-provenance.json').read_text()));checks.append(dict(config=config,tests=10,skips=0,seconds=time.monotonic()-start));print(json.dumps(checks[-1]),flush=True)
assert inputs(root)==before and len(gpu)==8
for config,files in json.loads((out/'baseline-dlls.json').read_text()).items():assert all(digest(root/('build/ninja-msvc-'+config)/name)==h for name,h in files.items())
assert all(digest(root/p)==h for p,h in json.loads((out/'protected-files.json').read_text()).items())
(out/'host-identities.json').write_text(json.dumps(identities,indent=2))
result=dict(status='built-and-checked',checks=checks,gpuProcesses=gpu,nativeCpuRays=34034,visibleVertexChecks=23128,exactDepthCoverageValues=675328,sourceUnchanged=True,productsVerified=True,existingProgramsExact=859,childProgramsExact=858,activeProgramCount=859,allHostSectionsExact=all(r['allSectionsExact'] for c in identities.values() for r in c.values()),allHostBytesExact=all(r['allBytesExact'] for c in identities.values() for r in c.values()),dllsExact=True)
(out/'build-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
if not identities['release']['AzurePlayer.exe']['allSectionsExact']:subprocess.run([sys.executable,'-X','utf8','-B',str(out/'capture.py')],check=True,timeout=600)
else:(out/'capture-reuse.json').write_text(json.dumps(dict(source='b699b6b',evidence='reference-position-frame-main-integration',allPlayerSectionsExact=True,dllsExact=True,all859ProgramsExact=True,scope='Frozen original joint four frames; same Player program sections, dependencies and all programs'),indent=2))
