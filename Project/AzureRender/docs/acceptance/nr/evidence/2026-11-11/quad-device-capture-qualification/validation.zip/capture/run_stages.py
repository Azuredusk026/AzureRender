from pathlib import Path
import json,subprocess,sys,time,os
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from artifact_maintenance import managed_environment
from gpu_environment import wait_and_record,RunEnvironmentMonitor
from run_playable_performance import freeze_products
quad=root/'build/runs/20261110-235204-quad-cascade-demand-local-qualification-0b5052'
proof=json.loads((quad/'four-results.json').read_text())
assert proof['exitCode']==0 and proof['featureRequestObserved'] and all(f['sha256']==f['referenceSha256'] and f['changedPixels']==0 for f in proof['frames'])
os.environ.update(managed_environment(out/'tmp'));os.environ['DOTNET_ROOT']='D:/Tools/dotnet9'
os.environ['PATH']=str(root/'build/ninja-msvc-release')+';'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin')+';'+os.environ['PATH']
for key in ['VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LOADER_DEBUG','VK_LAYER_ENABLES','VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
source=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe');private=digest(quad/'AzurePlayer-private-device.exe')
lock=json.loads((out/'frozen-project-inputs.json').read_text());assert len(lock)==1729 and all(digest(Path(p))==v for p,v in lock.items())
wait_and_record(out/'startup-environment.json',timeout=60)
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic();environment={};rows=[]
with RunEnvironmentMonitor(environment,path=out/'run-environment.json',interval=2):
    for script,timeout,key,filename,expected in [
        ('capture_current.py',580,'status','state.json','captured'),
        ('profile_current.py',300,'status','profile-state.json','profiled'),
        ('map_pipelines.py',150,'status','pipeline-scope.json','classified-all-pipelines')]:
        command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/script)]
        step=time.monotonic()
        with (out/(script+'.log')).open('wb') as log:
            p=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=timeout)
        state=json.loads((out/filename).read_text());rows.append(dict(script=script,exitCode=p.returncode,status=state.get(key),seconds=time.monotonic()-step))
        (out/'stage-progress.json').write_text(json.dumps(rows,indent=2));assert p.returncode==0 and state[key]==expected,state
assert inputs(root)==source and all(digest(Path(p))==v for p,v in products.items())
assert digest(quad/'AzurePlayer-private-device.exe')==private and all(digest(Path(p))==v for p,v in lock.items())
used=sum(p.stat().st_size for p in out.rglob('*') if p.is_file());assert used<=2**31,used
(out/'results.json').write_text(json.dumps(dict(status='captured-profiled-and-mapped',sourceBase='73300ab',privateDeviceFeatures=True,sourceUnchanged=True,productsUnchanged=True,mountedInputsUnchanged=True,privateHostUnchanged=True,seconds=time.monotonic()-start,usedBytes=used,steps=rows,formalAcceptance=False),indent=2));print('Feature-enabled capture, full profile and binding map passed',flush=True)
