from pathlib import Path
import subprocess,sys,json,time
root=Path.cwd();out=Path(__file__).resolve().parent;deadline=time.monotonic()+180
command=[sys.executable,'-X','utf8','-B','tools/shared_resources.py','run','--owner','01a1c097-ec33-7790-8c18-08a2b0ddb0c3','--task','quad-feature-device-capture-profile','--run',out.name,'--timeout','1150','--command',sys.executable,'-X','utf8','-B',str(out/'run_stages.py')]
while time.monotonic()<deadline:
 state=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_text())
 if state.get('state')=='released':
  p=subprocess.run(command,capture_output=True,text=True)
  if 'Shared resource busy or inaccessible' not in p.stdout+p.stderr:
   (out/'queued-execution.log').write_text(p.stdout+p.stderr);print(p.stdout,flush=True);raise SystemExit(p.returncode)
 time.sleep(.5)
(out/'queue-timeout.json').write_text(json.dumps(dict(status='not-started-resource-window',waitSeconds=180),indent=2));raise SystemExit(2)
