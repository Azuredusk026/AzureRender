from pathlib import Path
import subprocess,sys,json
out=Path(__file__).parent;build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
with (out/'native-build.log').open('wb') as log:
 for command in json.loads((out/'native-build-commands.json').read_text()):
  r=subprocess.run('D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat '+command,cwd=build,shell=True,stdout=log,stderr=subprocess.STDOUT,timeout=120);assert r.returncode==0,'Public framed native caller build failed'
r=subprocess.run([sys.executable,str(out/'native-batch.py')],timeout=180);assert r.returncode==0
