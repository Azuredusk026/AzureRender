from pathlib import Path
import json,hashlib,zipfile,re
out=Path(__file__).parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=json.loads((out/'results.json').read_text())
for name,prefix in [('README.md','docs/'),('docs/project-status.md',''),('docs/plans/azure-engine-plan.md','../'),('docs/plans/2026-11-09-native-quality.md','../')]:
 p=root/name;text=p.read_text(encoding='utf-8')
 if '[实际索引与正面方向]' not in text:text+='\n[实际索引与正面方向]('+prefix+'acceptance/nr/actual-geometry-index-source.md)通过双设备来源核对。\n两份完整深度平面与来源控制逐位一致，实际 UV 组合继续验收。\n'
 p.write_text(text,encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');anchor='## 2026-11-11 参考坐标帧'
if '## 2026-11-11 实际索引与朝向' not in text:text=text.replace(anchor,'## 2026-11-11 实际索引与朝向\n\n- 将实际 Vulkan 的 43044 个索引及匹配正面方向送入公开深度生产器。\n- 双设备完整深度平面的 7372800 个值与来源控制逐位一致。\n- 全部可见量与控制相同，保留 Intel 九十六处既有超差。\n- 验证及清理通过，运行时源码保持受检状态。\n\n'+anchor)
p.write_text(text,encoding='utf-8')
files={'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log','.bin','.cpp','.hpp'}}
files['docs/actual-geometry-index-source.md']=root/'docs/acceptance/nr/actual-geometry-index-source.md';base=out.parent/'20261111-001326-reference-position-frame-482201';files['baseline/config.json']=base/'candidate-config.json'
for d in ['nvidia','intel']:files['baseline/'+d+'-r32.bin']=base/(d+'-actual-r32.bin');files['baseline/'+d+'-rg8.bin']=base/(d+'-actual-rg8.bin')
config=json.loads((out/'candidate-config.json').read_text())
for n in ['positions','indices','profile','uv']:files['inputs/'+n+'.bin']=Path(config[n])
for p in result['sourceTask']['inputs']:
 if p.endswith('native-index.bin'):files['inputs/native-control-indices.bin']=Path(p)
dest=root/'docs/acceptance/nr/evidence/2026-11-11/actual-geometry-index-source';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']={'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members)+1};(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n')
p=root/'docs/acceptance/nr/actual-geometry-index-source.md';text=p.read_text(encoding='utf-8')
for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,sentence
for link in re.findall(r'\]\(([^)]+)\)',text):assert (p.parent/link).exists(),link
print(json.dumps(result['archive']))
