from pathlib import Path
import numpy as np,json,hashlib
out=Path(__file__).parent;base=out.parent/'20261111-001326-reference-position-frame-482201';result=json.loads((out/'native-results.json').read_text());task=json.loads((out/'task-card.json').read_text())
for name,v in task['inputs'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==v['sha256'],name
for row in result['devices']:
 d=row['device'];a=np.fromfile(out/(d+'-actual-r32.bin'),dtype='<u4');b=np.fromfile(base/(d+'-actual-r32.bin'),dtype='<u4');row['depthPlaneValues']=int(a.size);row['depthPlaneExactValues']=int((a==b).sum());row['maximumDepthPlaneUlp']=int(np.max(abs(a.astype('i8')-b.astype('i8'))));assert row['newFailures']==row['closedFailures']==row['changedVisibilityPixels']==0
result.update(status='qualified-actual-index-source-with-existing-intel-depth-failures',overall='failed-user-review',baseCommit='7eabe70',runtimeSourceChanged=False,indices=43044,triangleCount=14348,matchingFrontFace='clockwise',nativeUvHeldConstant=True,sourceTask=task,execution=json.loads((out/'native-execution.json').read_text()))
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps([{k:v for k,v in r.items() if k not in ['result','failurePixels']} for r in result['devices']],indent=2))
