from pathlib import Path
import json,sys,zipfile,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,digest
for config in ['debug','release']:
    before=json.loads((out/(config+'-before.json')).read_text());after=json.loads((root/('build/ninja-msvc-'+config)/'build-provenance.json').read_text())
    assert after==before;verify(root,after)
protected=json.loads((out/'protected-files.json').read_text());assert len(protected)==13 and all(digest(root/p)==h for p,h in protected.items())
daily=json.loads((out/'daily.log').read_text(encoding='utf-8-sig'));assert daily['externalStorageUsed'] is False
managed=daily['managed'];batches=managed['batches'];items=managed['items']
result=dict(status='verified',sourceBase='076fe6e',dailyStatus=daily['status'],stopReason=managed.get('stopReason'),seconds=daily['seconds'],batches=len(batches),items=len(items),sourceProofsExact=2,protectedFilesExact=13,externalStorageUsed=False)
(out/'results.json').write_text(json.dumps(result,indent=2))
archive=out/'validation.zip';members={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.iterdir()):
        if p.is_file() and p.suffix in ['.json','.py','.log']:
            members[p.name]=dict(bytes=p.stat().st_size,sha256=digest(p));z.write(p,p.name)
    z.writestr('member-sha256.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and all(len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in members.items())
assert archive.stat().st_size<8*1024*1024
print(json.dumps(result,indent=2));print('Evidence bytes',archive.stat().st_size,'sha256',digest(archive))
print('First item keys',list(items[0]) if items else [])
