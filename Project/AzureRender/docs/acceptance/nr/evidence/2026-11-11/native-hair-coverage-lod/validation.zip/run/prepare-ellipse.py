from pathlib import Path
import json,hashlib,subprocess,shutil,sys
out=Path(__file__).resolve().parent;root=out.parents[2];base=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release';source=root/'shaders';private=out/'ellipse-source';private.mkdir(exist_ok=True);target=out/'ellipse-resources/shaders';target.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((root/'docs/acceptance/nr/evidence/2026-11-11/reference-camera-render-binding/program-catalog.json').read_text())['sha256'];programs=json.loads((out/'ellipse-program-scope.json').read_text());assert len(programs)==84
before=json.loads((out/'intel-hair-coverage-analysis.json').read_text());assert before['failures']==597 and before['maximum']==166 and before['coverageSources'][0]['authoredMipLevels']==10
pre=subprocess.run([sys.executable,str(root/'tools/artifact_budget.py'),'--build',str(root/'build'),'--run',str(out),'--planned-bytes',str(sum((base/'shaders'/n).stat().st_size for n in old)+32*1024**2)],capture_output=True,text=True);(out/'ellipse-preflight.json').write_text(pre.stdout);assert pre.returncode==0,pre.stdout+pre.stderr
for name,h in old.items():
 src=base/'shaders'/name;assert sha(src)==h;shutil.copyfile(src,target/name)
patches={'mesh.frag':('azureSamplePrimaryUv(AZ_TEX_METALLIC_ROUGHNESS,textureCoordinate).a','azureSampleEllipseCoverage(AZ_TEX_METALLIC_ROUGHNESS,textureCoordinate)'), 'character_depth.frag':('azureSamplePrimaryUv(BASE,textureCoordinate).a','azureSampleEllipseCoverage(BASE,textureCoordinate)'), 'outline_mask.frag':('azureSamplePrimaryUv(BASE,textureCoordinate).a','azureSampleEllipseCoverage(BASE,textureCoordinate)'), 'shadow.frag':('azureSamplePrimaryUv(AZ_TEX_BASE_COLOR,textureCoordinate).a','azureSampleEllipseCoverage(AZ_TEX_BASE_COLOR,textureCoordinate)'), 'outline_surface_fragment.glsl':('azureSamplePrimaryUv(SHELL_BASE,textureCoordinate).a','azureSampleEllipseCoverage(SHELL_BASE,textureCoordinate)')}
for name,(a,b) in patches.items():
 text=(source/name).read_text(encoding='utf-8');assert a in text,name
 if name=='mesh.frag':a='float coverageAlpha='+a;b='float coverageAlpha='+b;assert text.count(a)==1
 (private/name).write_text(text.replace(a,b),encoding='utf-8')
header=(source/'material_primary_uv.glsl').read_text(encoding='utf-8');at=header.rfind('#endif');header=header[:at]+'''#if defined(AZURE_REFERENCE_MATERIAL_UV) && defined(AZURE_INDEPENDENT_COVERAGE)
#include "texture_footprint.glsl"
float azureSampleEllipseCoverage(sampler2D image,vec2 uv){
    vec2 size=vec2(textureSize(image,0));
    return textureLod(image,uv,azureEllipseMajorAxisLod(azurePrimaryUvDx*size,azurePrimaryUvDy*size)).a;
}
#endif
'''+header[at:];(private/'material_primary_uv.glsl').write_text(header,encoding='utf-8')
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin');commands=[]
with (out/'ellipse-shader-build.log').open('wb') as log:
 for p in programs:
  name=p['source'];file=private/name
  if not file.exists():shutil.copyfile(source/name,file)
  command=[str(sdk/'glslc.exe'),*p['arguments'],*['-D'+x for x in p['defines']],'-I'+str(private),'-I'+str(source),str(file),'-o',str(target/p['output'])];commands.append(command);r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=30);assert r.returncode==0,name
  r=subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(target/p['output'])],stdout=log,stderr=subprocess.STDOUT,timeout=30);assert r.returncode==0,name
current={p.name:sha(p) for p in target.glob('*.spv')};changed=[n for n,h in old.items() if current[n]!=h];assert len(current)==885 and set(changed)<=set(p['output'] for p in programs) and changed
(out/'ellipse-program-identity.json').write_text(json.dumps(dict(count=885,changed=changed,oldExact=885-len(changed),programs=current,commands=commands,samplerBiasContract='https://docs.vulkan.org/refpages/latest/refpages/source/VkSamplerCreateInfo.html'),indent=2)+'\n');shutil.copyfile(out/'hair-project/hair-coverage.azureproject',out/'hair-project/hair-coverage-ellipse.azureproject');print('Private ellipse coverage shaders validated: '+str(len(changed))+' changed programs; '+str(885-len(changed))+' retained exactly')
