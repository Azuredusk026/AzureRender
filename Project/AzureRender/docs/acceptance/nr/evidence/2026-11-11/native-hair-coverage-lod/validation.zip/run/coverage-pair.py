from pathlib import Path
import sys,subprocess,json
out=Path(__file__).resolve().parent;assert (out/'ellipse-program-identity.json').is_file()
for mode in ['hair-coverage','hair-coverage-ellipse']:
 r=subprocess.run([sys.executable,str(out/'hair-capture.py'),sys.argv[1],mode],timeout=420);assert r.returncode==0
