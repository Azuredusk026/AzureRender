from pathlib import Path
import json,hashlib,zipfile,re,runpy,numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda name:json.loads((out/name).read_text());control=load('control-summary.json');programs=load('ellipse-program-identity.json');assert control['matchingDecodedTexels']==349525 and control['matchingPngFrames']==4 and programs['count']==885 and len(programs['changed'])==50
base=runpy.run_path(str(out.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'));mask=base['mask'];rows=[]
for device in ['nvidia','intel']:
 a=load(device+'-hair-coverage-analysis.json');b=load(device+'-hair-coverage-ellipse-analysis.json');assert a['failures']==b['failures'] and b['new']==0 and b['closed']==0 and a['capture']['validationClean'] and b['capture']['validationClean']
 images=[np.asarray(Image.open(out/(device+'-'+mode+'-crop.png')).convert('RGB')) for mode in ['hair-coverage','hair-coverage-ellipse']];changed=int((mask&np.any(images[0]!=images[1],axis=2)).sum());rows.append(dict(device=device,source=a,ellipse=b,changedMaskPixels=changed));assert b['maximum']==(97 if device=='intel' else 5)
assert rows[1]['ellipse']['probePixels'][0]['newError']==2
result=dict(status='qualified-private-coverage-lod-diagnosis',overall='failed-user-review',baseCommit='10c8c32',productionSourceChanged=False,control=control,devices=rows,programCount=885,changedPrivatePrograms=50,retainedProgramsExact=835,maskPixels=17017,maximumAllowedByteError=1,remaining=['Public coverage LOD policy','Actual dynamic reference visibility producer','Intel 96 reference depth failures','Native color and remaining appearance gates']);(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
doc='docs/acceptance/nr/native-hair-coverage-lod.md';files={'source/'+doc:root/doc};files.update({'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.md','.json','.log','.azmeta','.png'}})
for p in (out/'ellipse-source').iterdir():
 if p.is_file():files['shader-source/'+p.name]=p
for p in out.glob('*-frames/capture_manifest.json'):files['capture/'+p.parent.name+'.json']=p
for p in [out/'hair-project/character/native-coverage.dds',out/'hair-project/character/native-coverage.dds.azmeta',out/'hair-project/assets/hair-coverage.azurelevel',out/'hair-project/config/reference-views.json']:files['input/'+p.name]=p
for n in programs['changed']:files['private-program/'+n]=out/'ellipse-resources/shaders'/n
dest=root/'docs/acceptance/nr/evidence/2026-11-11/native-hair-coverage-lod';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']=dict(bytes=archive.stat().st_size,sha256=sha(archive),members=len(members)+1);(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n');p=root/doc;text=p.read_text(encoding='utf-8')
for s in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',s))<=45,s
for link in re.findall(r'\]\(([^)]+)\)',text):
 if not link.startswith('https:'):assert (p.parent/link).exists(),link
print(json.dumps(dict(archive=result['archive'],changedMaskPixels=[v['changedMaskPixels'] for v in rows])))
