from pathlib import Path
import struct,json,hashlib,shutil,subprocess,sys
out=Path(__file__).resolve().parent;root=out.parents[2];prior=out.parent/'20261111-061836-native-hair-reference-raster-d5ebb7';original=prior/'hair-project';fixture=out/'hair-project';asset=original/'character/hair-candidate.glb';target=fixture/'character/hair-coverage.glb';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(asset)==json.loads((prior/'hair-uv-asset.json').read_text())['assetSha256']
files=[]
for row in json.loads((prior/'hair-copy-inputs.json').read_text()):
 p=Path(row['destination']);assert sha(p)==row['sha256'];relative=p.relative_to(original)
 if p.name not in {'hair-receiver.glb','hair-receiver.glb.azmeta','hair-receiver.azureproject','hair-receiver.azurelevel','hair-receiver.azurelevel.azmeta'}:files.append((p,fixture/relative))
files.append((original/'config/reference-views.json',fixture/'config/reference-views.json'))
pre=subprocess.run([sys.executable,str(root/'tools/artifact_budget.py'),'--build',str(root/'build'),'--run',str(out),'--planned-bytes',str(sum(p.stat().st_size for p,_ in files)+asset.stat().st_size+64*1024**2)],capture_output=True,text=True);(out/'source-copy-preflight.json').write_text(pre.stdout);assert pre.returncode==0,pre.stdout+pre.stderr
for p,q in files:q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);assert sha(p)==sha(q)
target.parent.mkdir(parents=True,exist_ok=True);native=out.parent/'20261110-173835-reference-depth-coverage-4b4afc';mips=[];sourceHashes=[]
for level in range(10):
 p=native/f'422-alpha-mip{level}.bin';data=p.read_bytes();blocks=max(1,(512>>level)+3)//4 if level<8 else 1;assert len(data)==blocks*blocks*16,(level,len(data));mips.append(data);sourceHashes.append(dict(level=level,sha256=sha(p),bytes=len(data)))
dds=target.parent/'native-coverage.dds';header=[124,0xA1007,512,512,len(mips[0]),0,10]+[0]*11+[32,4,0x30315844,0,0,0,0,0]+[0x401008,0,0,0,0];assert len(header)==31;dds.write_bytes(b'DDS '+struct.pack('<31I',*header)+struct.pack('<5I',98,3,0,1,0)+b''.join(mips))
textureSettings=dict(schemaVersion=2,usage='mask',colorSpace='linear',filter='linear',magFilter='linear',wrapU='repeat',wrapV='repeat',mipPolicy='generate',anisotropy=1,mipBias=-1,mipFilter='nearest')
dds.with_suffix('.dds.azmeta').write_text(json.dumps(dict(schemaVersion=1,id='30097b3b-8442-4e4a-86a0-37d65537633a',settings=dict(texture=textureSettings),dependencies=[]),indent=2)+'\n')
with asset.open('rb') as input:
 magic,version,total,oldSize,kind=struct.unpack('<4s4I',input.read(20));gltf=json.loads(input.read(oldSize));material=next(v for v in gltf['materials'] if v['name']=='M_actor_laevat_hair_01');profile=material['extras']['azureRenderMaterial'];assert material['alphaMode']=='MASK' and material['alphaCutoff']==.5 and 'coverageTexture' not in profile and 'metallicRoughnessTexture' not in material['pbrMetallicRoughness']
  # The independent texture owns only the cutout; base color stays byte-identical.
 image=len(gltf['images']);gltf['images'].append(dict(uri=dds.name));index=len(gltf['textures']);gltf['textures'].append(dict(source=image));profile['coverageTexture']=dict(schemaVersion=1,texture=index,channel='red');payload=json.dumps(gltf,separators=(',',':'),ensure_ascii=False).encode();payload+=b' '*((-len(payload))%4);tail=hashlib.sha256()
 with target.open('wb') as f:
  f.write(struct.pack('<4s4I',magic,version,total-oldSize+len(payload),len(payload),kind));f.write(payload)
  while chunk:=input.read(4*1024**2):f.write(chunk);tail.update(chunk)
assert tail.hexdigest()==json.loads((prior/'hair-uv-asset.json').read_text())['unchangedBinaryTailSha256']
level=json.loads((original/'assets/hair-uv.azurelevel').read_text());level['resources'][0]['asset']='character:/hair-coverage.glb';project=json.loads((original/'hair-uv.azureproject').read_text());project['startupScene']='assets:/hair-coverage.azurelevel'
for p,v in [(fixture/'hair-coverage.azureproject',project),(fixture/'assets/hair-coverage.azurelevel',level),(out/'coverage-profile.json',profile)]:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
inputs=[q for _,q in files]+[dds,dds.with_suffix('.dds.azmeta'),target,fixture/'hair-coverage.azureproject',fixture/'assets/hair-coverage.azurelevel'];(out/'hair-copy-inputs.json').write_text(json.dumps([dict(destination=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in inputs],indent=2)+'\n');(out/'coverage-inputs.json').write_text(json.dumps(dict(nativeMips=sourceHashes,textureSettings=textureSettings,binaryTail=tail.hexdigest(),assetSha256=sha(target)),indent=2)+'\n')
for name in ['hair-capture.py','queued-hair.py']:(out/name).write_bytes((prior/name).read_bytes())
print('Prepared authored 512x512 coverage with all ten native mips and unchanged geometry/texture binary tail')
