from pathlib import Path
import sys,json,struct,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
p=Path('D:/Projects/FYP-coordination/quality-claim.json');claim=json.loads(p.read_text(encoding='utf-8'));owner=claim['threadId'];prior='20261111-061836-native-hair-reference-raster-d5ebb7';names=[prior,'20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2','20261110-173835-reference-depth-coverage-4b4afc','20261110-112309-hair-relative-projection-control-b9da17']
t=s.acquire_inputs(root/'build',out,names,owner);s.maintenance.seal(root/'build',out.parent/prior)
for v in claim.get('localInputLease',[]):s.release_inputs(root/'build',v,owner)
for v in claim.get('inputLease',[]):s.release_inputs(s.DEFAULT_BUILD,v,owner)
claim.update(state='native-hair-production-coverage',lastCommit='10c8c32',taskPath=str(out),localInputLease=[t],inputLease=[],ownedFiles=[],pendingCommand='Inspect native alpha source and production coverage binding at [1326,177]; qualify one explicit producer factor')
p.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
asset=out.parent/prior/'hair-project/character/hair-candidate.glb'
with asset.open('rb') as f:
 _,_,_,size,_=struct.unpack('<4s4I',f.read(20));g=json.loads(f.read(size))
m=next(v for v in g['materials'] if v['name']=='M_actor_laevat_hair_01');pbr=m.get('pbrMetallicRoughness',{});texture=g['textures'][pbr['baseColorTexture']['index']];source=g['images'][texture['source']] if 'source' in texture else None;result=dict(alphaMode=m.get('alphaMode','OPAQUE'),alphaCutoff=m.get('alphaCutoff',.5),pbr=pbr,alphaSourceTexture=texture,alphaSourceImage=source,sourceSampler=g['samplers'][texture['sampler']] if 'sampler' in texture else None,features=m['extras']['azureRenderMaterial']['features'],ddsTextureExamples=[v for v in g['textures'] if 'extensions' in v][:2]);(out/'production-alpha-source.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
(out/'task-card.json').write_text(json.dumps(dict(baseCommit='10c8c32',created=time.time(),locationSeconds=600,candidateSeconds=1200,explorationSeconds=1800,plannedBytes=536870912,hypothesis='Production peak at [1326,177] matches the known alpha mip boundary; existing independently qualified ellipse coverage can reproduce the correct fragment at this site',gateSource='Frozen 17017 native pixels at one byte, same alpha point source, supported devices and unchanged legacy four frames'),indent=2)+'\n')
