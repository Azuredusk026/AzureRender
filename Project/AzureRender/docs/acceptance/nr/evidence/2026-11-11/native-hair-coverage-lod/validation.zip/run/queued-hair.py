from pathlib import Path
import sys,json,time
out=Path(__file__).resolve().parent;sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
started=time.monotonic();name='-'.join(sys.argv[1:])
while True:
 context=s.lease(s.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-native-hair-'+name,out)
 try:context.__enter__();break
 except ValueError as e:
  if 'busy' not in str(e) or time.monotonic()-started>=180:raise
  time.sleep(1)
try:
 if sys.argv[2]=='hair-coverage-ellipse' and not (out/'ellipse-program-identity.json').is_file():
  prepared=s.maintenance.guarded_run(out.parents[1],out.name,[sys.executable,str(out/'prepare-ellipse.py')],180);(out/'ellipse-build-execution.json').write_text(json.dumps(prepared,indent=2)+'\n');assert prepared['status']=='exited' and prepared['exitCode']==0,prepared
 if sys.argv[2]=='hair-reference' and not (out/'hair-project/hair-reference.azureproject').is_file():
  baseline=json.loads((out/'nvidia-hair-receiver-results.json').read_text());assert all(r['overOne']==73 and r['vsFrozenDifferentPixels']==0 for r in baseline['frames'])
  prepared=s.maintenance.guarded_run(out.parents[1],out.name,[sys.executable,str(out/'prepare-hair-reference.py')],60);(out/'hair-reference-preparation-execution.json').write_text(json.dumps(prepared,indent=2)+'\n');assert prepared['status']=='exited' and prepared['exitCode']==0,prepared
 command=[sys.executable,str(out/'coverage-pair.py'),sys.argv[1]] if sys.argv[2]=='coverage-pair' else [sys.executable,str(out/'hair-capture.py'),*sys.argv[1:]]
 result=s.maintenance.guarded_run(out.parents[1],out.name,command,600);(out/(name+'-execution.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert result['status']=='exited' and result['exitCode']==0
finally:context.__exit__(None,None,None)
