from pathlib import Path
import json
out=Path(__file__).resolve().parent;build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release';data=json.loads((build/'shader-reload.json').read_text());print(list(data));
for key,value in data.items():
 if isinstance(value,list):
  programs=[v for v in value if 'AZURE_INDEPENDENT_COVERAGE=1' in v.get('defines',[]) and 'AZURE_REFERENCE_MATERIAL_UV=1' in v.get('defines',[])];print(key,len(value),len(programs));print(json.dumps(programs[:4],indent=2));(out/'ellipse-program-scope.json').write_text(json.dumps(programs,indent=2)+'\n')
