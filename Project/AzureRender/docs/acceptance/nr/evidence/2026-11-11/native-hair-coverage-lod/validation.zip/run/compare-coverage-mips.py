from pathlib import Path
import struct,json,io,numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;directory=out/'hair-project/character';merged=directory/'hair-base-coverage.dds';native=directory/'native-coverage.dds';raw=merged.read_bytes();values=struct.unpack_from('<31I',raw,4);height,width,levels=values[2],values[3],values[6];fmt=struct.unpack_from('<I',raw,128)[0];assert raw[:4]==b'DDS ' and values[20]==0x30315844 and fmt in [28,29,87,91] and (width,height)==(2048,2048)
alpha=[];offset=148
for i in range(levels):
 w,h=max(1,width>>i),max(1,height>>i);n=w*h*4;alpha.append(np.frombuffer(raw[offset:offset+n],dtype='u1').reshape(h,w,4)[:,:,3]);offset+=n
assert offset==len(raw);source=native.read_bytes();header=list(struct.unpack_from('<31I',source,4));base=148;rows=[]
for level in range(10):
 size=max(1,512>>level);bytes=((size+3)//4)**2*16;local=header.copy();local[2]=local[3]=size;local[4]=bytes;local[6]=1;payload=b'DDS '+struct.pack('<31I',*local)+source[128:148]+source[base:base+bytes];base+=bytes;decoded=np.asarray(Image.open(io.BytesIO(payload)).convert('RGBA'))[:,:,0];a=alpha[level+2];assert a.shape==decoded.shape;err=abs(a.astype('i2')-decoded.astype('i2'));rows.append(dict(nativeMip=level,mergedMip=level+2,size=size,exactTexels=int((err==0).sum()),texels=size*size,maxByteError=int(err.max()),thresholdChanges=int(((a>=128)!=(decoded>=128)).sum())))
assert base==len(source);sampler=merged.with_suffix('.dds.azmeta');result=dict(mergedExtent=[width,height],mergedFormat=fmt,mergedMips=levels,sourceExtent=[512,512],sourceMips=10,mergedSampler=json.loads(sampler.read_text())['settings'].get('texture',{}) if sampler.is_file() else {},comparison=rows);(out/'coverage-mip-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
