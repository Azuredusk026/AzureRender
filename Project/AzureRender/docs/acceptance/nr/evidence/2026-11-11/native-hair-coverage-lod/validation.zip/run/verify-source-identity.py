from pathlib import Path
import hashlib,json
out=Path(__file__).resolve().parent;prior=out.parent/'20261111-061836-native-hair-reference-raster-d5ebb7';rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in range(4):
 old=prior/f'intel-hair-uv-frames/frame_{n:06d}.png';new=out/f'intel-hair-coverage-frames/frame_{n:06d}.png';a,b=sha(old),sha(new);rows.append(dict(frame=n,mergedSha256=a,independentSha256=b,exact=a==b))
(out/'coverage-source-identity.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(dict(exactFrames=sum(v['exact'] for v in rows),frames=len(rows))))
