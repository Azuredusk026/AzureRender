from pathlib import Path
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261111-030712-reference-raster-project-main-integration-2540b6'
text=(prior/'seal.py').read_text()
text=text.replace("==26 and len(build['gpuProcesses'])==4","==34 and len(build['gpuProcesses'])==4")
text=text.replace("status='reference-raster-project-main-integration-qualified',runtimeSourceCommit='b514de0',sourceBranchCommit='80719a9',rasterSourceCommit='746ba12',rasterIntegrationCommit='1e04cd3'","status='scene-reference-camera-main-integration-qualified',runtimeSourceCommit='e1edea9',sourceBranchCommit='6483e03'")
text=text.replace("/reference-raster-project-main-integration';dest", "/scene-reference-camera-main-integration';dest")
assert '==34' in text and "11/scene-reference-camera-main-integration';dest" in text
(out/'seal.py').write_text(text)
print('Prepared source/product/protection and 34-check archive seal')
