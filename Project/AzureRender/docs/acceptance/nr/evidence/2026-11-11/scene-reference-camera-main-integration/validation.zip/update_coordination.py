from pathlib import Path
import json
base=Path('D:/Projects/FYP-coordination');p=base/'assignments.json';a=json.loads(p.read_text(encoding='utf-8'))
for s in a['streams']:
    if s['id']=='performance':s.update(state='raster-project-main-qualified; scene-reference-camera-main-verification; viewquad-production-planned',run='D:/Projects/FYP/Project/AzureRender/build/runs/20261111-034457-scene-reference-camera-main-integration-80b1fd')
    if s['id']=='quality':s.update(state='scene-reference-camera-imported; conservative-reference-culling',integratedSourceHead='6483e03')
for commit in ['d41f927','e329f55','1e04cd3','b514de0','81866ef','e1edea9']:
    if commit not in a['integrationCommits']:a['integrationCommits'].append(commit)
p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=base/'INTEGRATION_STATUS.md';text=p.read_text(encoding='utf-8').replace('主线提交为 `076fe6e`','主线提交为 `e1edea9`')
at='参考相机视图主线接入完成所属验收。'
text=text.replace(at,'光栅位置及项目视图主线验收提交为 `81866ef`。\n双配置二十六项检查、四次设备检查及严格原始四帧通过。\n场景参考相机选择来源 `6483e03` 已接入，主线验证正在执行。\n\n深度可见性组合已通过局部及原生净收益资格。\n完整材质降幅约为 21.21%，短时 GPU 均值降幅约为 13.58%。\n生产接入按独立单元继续，正式帧预算保持待验。\n\n'+at,1)
p.write_text(text,encoding='utf-8')
print('Coordination updated to e1edea9 and current stage')
