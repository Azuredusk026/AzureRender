from pathlib import Path
import json, shutil, sys, zipfile, hashlib
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261111-030712-reference-raster-project-main-integration-2540b6'
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs,verify
baseline={};identities=json.loads((prior/'host-identities.json').read_text())
for config in ['debug','release']:
    hashes=json.loads((prior/(config+'-program-sha256.json')).read_text());assert len(hashes)==860
    build=root/('build/ninja-msvc-'+config)
    assert all(digest(build/'shaders'/n)==h for n,h in hashes.items())
    assert all(digest(build/n)==entry['sha256'] for n,entry in identities[config].items())
    baseline[config]=dict(hosts=identities[config],shaders=hashes)
(out/'baseline-products.json').write_text(json.dumps(baseline,indent=2))
for name in ['baseline-dlls.json','protected-files.json','frozen-project-inputs.json','profile.bin','frame.bin','positions.bin','queries.bin','raster-profile.bin','raster-frame.bin','raster-records.bin','capture.py','quality-program-sha256.json']:
    shutil.copyfile(prior/name,out/name)
archive=root/'docs/acceptance/nr/evidence/2026-11-11/scene-reference-camera-selection/validation.zip'
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    manifest=json.loads(z.read('manifest.json'))
    for name,entry in manifest.items():
        data=z.read(name);assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
(out/'source-review.json').write_text(json.dumps(dict(sourceCommit='6483e03',integrationCommit='e1edea9',archiveBytes=archive.stat().st_size,archiveSha256=digest(archive),members=len(manifest)+1,memberHashesVerified=True,sourceConflicts=False,documentationConflict='Additive CHANGELOG entries retained'),indent=2))
(out/'source-lock.json').write_text(json.dumps(inputs(root),indent=2))
text=(prior/'build.py').read_text().replace("targets=['AzureProjectReferenceViewsTests'","targets=['AzureReferenceCameraSelectionTests','AzureReferenceCameraMacroTests','AzureCameraSystemTests','AzureComponentRegistryTests','AzureProjectReferenceViewsTests'")
text=text.replace('ReferenceRasterProjectionGpu|ReferenceCameraView','ReferenceCameraMacro|ReferenceRasterProjectionGpu|ReferenceCameraView').replace('ModuleBoundaryFixtures))','ModuleBoundaryFixtures|ComponentRegistry)|AzureRuntime.(CameraSystem|ReferenceCameraSelection))')
text=text.replace("reuse=config=='Release' and (out/'fixture-layout-correction.json').exists()","reuse=False")
text=text.replace('len(cases)==13','len(cases)==17').replace('tests=13','tests=17')
marker="    for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:"
extra='''    with (out/(config.lower()+'-native-selection.log')).open('wb') as log:
        subprocess.run([str(build/'AzureReferenceCameraSelectionTests.exe'),str(out/'raster-profile.bin'),str(out/'raster-frame.bin')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
    text=(out/(config.lower()+'-native-selection.log')).read_text();assert '256 rigid-motion points' in text and 'maximumPixelError=' in text,text
'''
assert text.count(marker)==1;text=text.replace(marker,extra+marker)
text=text.replace('existingProgramsExact=859','existingProgramsExact=860')
(out/'build.py').write_text(text)
print('Prepared 17 checks/configuration, native camera selection and four raster device checks')
