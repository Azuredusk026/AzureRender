from pathlib import Path
import json,re,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent
integration=root/'build/runs/20261110-234209-material-uv-main-integration-b62170'
original=(root/'src/app/AzureRenderApp.cpp').read_text()
needle='#if defined(AZURE_SURFACE_RADIANCE_PROGRAMS)\n    VkPhysicalDeviceShaderQuadControlFeaturesKHR'
assert original.count(needle)==1
source=original.replace(needle,'#if 1\n    VkPhysicalDeviceShaderQuadControlFeaturesKHR')
needle='    }\n#endif\n#if defined(AZURE_SHADOW_HISTORY_PROGRAMS)\n    deviceFeatures.fragmentStoresAndAtomics='
assert source.count(needle)==1
source=source.replace(needle,'    }\n    if(!fragmentQuadControl_)throw std::runtime_error("Quad-demand probe requires enabled quad-control features");\n    std::cout << "Quad-demand device probe: quad-control and maximal-reconvergence requested\\n";\n#endif\n#if defined(AZURE_SHADOW_HISTORY_PROGRAMS)\n    deviceFeatures.fragmentStoresAndAtomics=')
(out/'AzureRenderApp-private-device.cpp').write_text(source)
a=json.loads((integration/'current-player-build-commands.json').read_text());compile=a['app']
compile,n=re.subn(r'/Fo\S+',lambda m:'/Fo"'+str(out/'AzureRenderApp-private-device.obj')+'"',compile);assert n==1
compile,n=re.subn(r'/Fd\S+',lambda m:'/Fd"'+str(out/'AzureRenderApp-private-device.pdb')+'"',compile);assert n==1
compile,n=re.subn(r'-c\s+\S+AzureRenderApp\.cpp$',lambda m:'-I"'+str(root/'src/app')+'" -c "'+str(out/'AzureRenderApp-private-device.cpp')+'"',compile);assert n==1
link=json.loads((integration/'expanded-player-link-command.json').read_text())['command'].split(' -- ',1)[1].split(' && ',1)[0]
for flag,path in [('out',out/'AzurePlayer-private-device.exe'),('implib',out/'AzurePlayer-private-device.lib'),('pdb',out/'AzurePlayer-private-device.pdb')]:
    link,n=re.subn('/'+flag+r':\S+',lambda m:'/'+flag+':"'+str(path)+'"',link);assert n==1
link+=' "'+str(out/'AzureRenderApp-private-device.obj')+'"'
assert '@CMakeFiles' not in link
(out/'private-build-commands.json').write_text(json.dumps(dict(compile=compile,link=link,workingDirectory=str(root/'build/ninja-msvc-release')),indent=2))
(out/'task-card.json').write_text(json.dumps(dict(status='cpu-prepared-private-feature-device',sourceBase='73300ab',sourceOriginalSha256=hashlib.sha256((root/'src/app/AzureRenderApp.cpp').read_bytes()).hexdigest(),scope='Private host requests existing quad-control/maximal-reconvergence device features; default rendering programs and source remain untouched',next='Compile under shared queue, then validate original four exact PNGs before allocating a feature-enabled RDC capture',productionSourceChanges=0,derivativeHypothesis='Conservative quad union can omit unused cascade derivative blocks while preserving all required neighbor values',requirements=['full_quads','quad_derivatives','maximally_reconverges','actual enabled feature chain'],reference='https://docs.vulkan.org/features/latest/features/proposals/VK_KHR_shader_quad_control.html'),indent=2))
print('Private feature-device source and two isolated build commands prepared')
