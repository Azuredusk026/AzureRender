from pathlib import Path
import json,os,subprocess,sys,time
import numpy as np
from PIL import Image
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest,verify
from run_playable_performance import freeze_products
os.environ.update(managed_environment(out/'tmp'));os.environ.update(DOTNET_ROOT='D:/Tools/dotnet9',VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0')
if '--inside' not in sys.argv:
    raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
baseline=inputs(root);build=root/'build/ninja-msvc-release';products=freeze_products(root,build/'AzurePlayer.exe',build/'AzureRender.exe')
commands=json.loads((out/'private-build-commands.json').read_text());start=time.monotonic()
with (out/'private-build.log').open('wb') as log:
    for name in ['compile','link']:
        subprocess.run(commands[name],cwd=commands['workingDirectory'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=240)
assert inputs(root)==baseline and all(digest(Path(p))==h for p,h in products.items())
(out/'private-build-results.json').write_text(json.dumps(dict(status='built',seconds=time.monotonic()-start,sourceUnchanged=True,productsUnchanged=True,playerSha256=digest(out/'AzurePlayer-private-device.exe')),indent=2))
os.environ['PATH']=str(build)+';'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin')+';'+os.environ['PATH']
os.environ['AZURERENDER_RESOURCE_ROOT']=str(build)
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(key,None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint'
command=json.loads((reference/'command.json').read_text());command[0]=str(out/'AzurePlayer-private-device.exe');command[command.index('--capture-dir')+1]=str(out/'frames');command[command.index('--runtime-report')+1]=str(out/'runtime.json')
lock=json.loads((out/'frozen-project-inputs.json').read_text());assert len(lock)==1729 and all(digest(Path(p))==h for p,h in lock.items())
(out/'four-command.json').write_text(json.dumps(command,indent=2));start=time.monotonic()
with (out/'four.log').open('wb') as log:
    p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=550)
frames=[]
for image in sorted((out/'frames').glob('frame_*.png')):
    a=np.asarray(Image.open(image).convert('RGB'));b=np.asarray(Image.open(reference/'frames'/image.name).convert('RGB'))
    frames.append(dict(name=image.name,sha256=digest(image),referenceSha256=digest(reference/'frames'/image.name),changedPixels=int(np.any(a!=b,axis=2).sum())))
text=(out/'four.log').read_text(errors='replace')
result=dict(exitCode=p.returncode,seconds=time.monotonic()-start,frames=frames,featureRequestObserved='Quad-demand device probe: quad-control and maximal-reconvergence requested' in text,validationClean=not any(s in text for s in ['VUID-','SYNC-HAZARD','Validation Error:','Validation Warning:']),allocatorZero='Allocator after unload: buffers=0 images=0' in text,sourceUnchanged=inputs(root)==baseline,productsUnchanged=all(digest(Path(p))==h for p,h in products.items()),projectInputsUnchanged=all(digest(Path(p))==h for p,h in lock.items()))
(out/'four-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
assert p.returncode==0 and len(frames)==4 and all(f['changedPixels']==0 and f['sha256']==f['referenceSha256'] for f in frames)
assert all(result[k] for k in ['featureRequestObserved','validationClean','allocatorZero','sourceUnchanged','productsUnchanged','projectInputsUnchanged'])
