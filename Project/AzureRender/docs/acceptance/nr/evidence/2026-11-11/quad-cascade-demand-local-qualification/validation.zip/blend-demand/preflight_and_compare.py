from pathlib import Path
import json,sys,subprocess,time
root=Path.cwd();out=Path(__file__).resolve().parent
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text())
byName={p['output']:p for p in manifest['programs']}
profile=json.loads((out/'replay-profile.json').read_text());full=json.loads((root/'build/runs/20261111-001050-quad-feature-device-capture-4798d1/pipeline-scope.json').read_text())
eligible={p['output'] for p in manifest['programs'] if p['source']=='mesh.frag' and not any(v in p['defines'] for v in ['AZURE_VIEW_FOG=1','AZURE_HAIR_PIXEL_INTEGRAL=1','AZURE_GEOMETRY_SAMPLES=1'])}
names=sorted({next(n for n in v['programFiles'] if n in eligible) for v in profile['shaders'].values() if any(n in eligible for n in v['programFiles'])});assert len(names)==10
rows=[];start=time.monotonic()
for name in names:
    p=byName[name];arguments=[('--target-env=vulkan1.1' if v.startswith('--target-env=') else v) for v in p['arguments']]
    if not any(v.startswith('--target-env=') for v in arguments):arguments+=['--target-env=vulkan1.1']
    destination=out/'preflight'/name
    command=[manifest['compiler'],*arguments,*['-D'+d for d in p['defines']],'-I'+str(root/'shaders'),str(out/'preflight/quad-demand.frag'),'-o',str(destination)]
    r=subprocess.run(command,capture_output=True,text=True,timeout=30)
    row=dict(program=name,command=command,exitCode=r.returncode,stdout=r.stdout,stderr=r.stderr);rows.append(row)
    (out/'preflight-programs.json').write_text(json.dumps(rows,indent=2));assert r.returncode==0,row
    r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.1',str(destination)],capture_output=True,text=True,timeout=15)
    row['validationExitCode']=r.returncode;row['validationOutput']=r.stdout+r.stderr;assert r.returncode==0,row
(out/'preflight-programs.json').write_text(json.dumps(rows,indent=2));print('Ten quad-demand programs compiled and validated in',time.monotonic()-start,'seconds',flush=True)
subprocess.run([sys.executable,'-X','utf8','-B',str(out/'run_compare.py')],check=True,timeout=340)
