from pathlib import Path
import json,zipfile,sys,xml.etree.ElementTree as ET
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,digest,inputs
proof=json.loads((out/'release-build-provenance.json').read_text());verify(root,proof)
assert proof==json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text())
cases=ET.parse(out/'release-tests.xml').findall('.//testcase');assert len(cases)==13 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
assert inputs(root)==json.loads((out/'source-lock.json').read_text())
with zipfile.ZipFile(root/'docs/acceptance/nr/evidence/2026-11-11/reference-raster-projection/validation.zip') as z:
    manifest=json.loads(z.read('manifest.json'));payload=z.read('run/native-records.bin');(out/'raster-records.bin').write_bytes(payload)
    assert digest(out/'raster-records.bin')==manifest['run/native-records.bin']['sha256']
record=dict(status='corrected-task-fixture',wrongSourceMember='inputs/vulkan-vertex.bin',requiredSourceMember='run/native-records.bin',beforeSha256=digest(out/'raster-records-before-layout-fix.bin'),afterSha256=digest(out/'raster-records.bin'),bytes=len(payload),reusedReleaseChecks=13,reusedReleaseNativeCpuLogs=['release-native-camera.log','release-native-project-views.log','release-raster-cpu.log'],productionSourceChanges=0)
(out/'fixture-layout-correction.json').write_text(json.dumps(record,indent=2))
p=out/'prepare.py';text=p.read_text().replace("('vulkan-vertex.bin','raster-records.bin')","('vulkan-vertex.bin','original-vulkan-vertex.bin')")
needle="        (out/b).write_bytes(z.read('inputs/'+a))"
if "    (out/'raster-records.bin').write_bytes(z.read('run/native-records.bin'))" not in text:
    text=text.replace(needle,needle+"\n    (out/'raster-records.bin').write_bytes(z.read('run/native-records.bin'))")
p.write_text(text)
p=out/'build.py';lines=p.read_text().splitlines();result=[]
for line in lines:
    if line.startswith("    command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py'"):
        result.append("    reuse=config=='Release' and (out/'fixture-layout-correction.json').exists()")
        result.append("    if reuse:verify(root,json.loads((out/'release-build-provenance.json').read_text()))")
    if line.startswith("    with (out/(config.lower()+'-build.log'))") or line.startswith("    with (out/(config.lower()+'-tests.log'))"):
        result.append('    if not reuse:');result.append('    '+line);continue
    if line.startswith("    with (out/(config.lower()+'-native-camera.log'))"):
        result.append('    if not reuse:')
        result.append('    '+line);continue
    if line.startswith("    with (out/(config.lower()+'-native-project-views.log'))") or line.startswith("    with (out/(config.lower()+'-raster-cpu.log'))"):
        result.append('    if not reuse:');result.append('    '+line);continue
    line=line.replace('tests=13,skips=0,seconds=', 'tests=13,skips=0,reusedBuildAndChecks=reuse,seconds=')
    result.append(line)
p.write_text('\n'.join(result)+'\n');print(json.dumps(record,indent=2))
