from pathlib import Path
import json,zipfile,shutil,sys
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261111-013805-reference-camera-view-main-integration-38f34e';sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
identities=json.loads((prior/'host-identities.json').read_text());baseline={}
for config in ['debug','release']:
    hashes=json.loads((prior/(config+'-program-sha256.json')).read_text());assert len(hashes)==859
    build=root/('build/ninja-msvc-'+config);assert all(digest(build/'shaders'/n)==h for n,h in hashes.items())
    assert all(digest(build/n)==v['sha256'] for n,v in identities[config].items());baseline[config]=dict(hosts=identities[config],shaders=hashes)
(out/'baseline-products.json').write_text(json.dumps(baseline,indent=2))
for name in ['baseline-dlls.json','protected-files.json','frozen-project-inputs.json','profile.bin','frame.bin','positions.bin','queries.bin','capture.py']:shutil.copyfile(prior/name,out/name)
catalog=json.loads((root/'docs/acceptance/nr/evidence/2026-11-11/reference-raster-projection/program-catalog.json').read_text());assert catalog['count']==859
(out/'quality-program-sha256.json').write_text(json.dumps(catalog['sha256'],indent=2))
with zipfile.ZipFile(root/'docs/acceptance/nr/evidence/2026-11-11/reference-raster-projection/validation.zip') as z:
    for a,b in [('native-profile.bin','raster-profile.bin'),('native-frame.bin','raster-frame.bin'),('vulkan-vertex.bin','original-vulkan-vertex.bin')]:
        (out/b).write_bytes(z.read('inputs/'+a))
    (out/'raster-records.bin').write_bytes(z.read('run/native-records.bin'))
(out/'source-lock.json').write_text(json.dumps(inputs(root),indent=2))
(out/'source-review.json').write_text(json.dumps(dict(sourceCommits=['746ba12','80719a9'],integrationCommits=['1e04cd3','b514de0'],sourceConflicts=False,documentationConflict='Additive CHANGELOG entries retained',archives=[dict(name='reference-raster-projection',bytes=1558965,members=45,memberHashesVerified=44,sha256='8241becb8b3ec01dd6ccd93f8a14bc6ec3679d58ec1648babc87721d5b9f7ecd'),dict(name='project-reference-views',bytes=208901,members=67,memberHashesVerified=66,sha256='d49675c9a47b4170873a54f58d909465ca319eace1197a478384b89e801d32fb')]),indent=2))
text=(prior/'build.py').read_text()
text=text.replace("targets=['AzureReferenceCameraViewTests',","targets=['AzureProjectReferenceViewsTests','AzureProjectTests','AzureReferenceRasterProjectionGpuTests','AzureReferenceCameraViewTests',")
text=text.replace('ReferenceCameraView|ReferencePositionFrameGpu','ReferenceRasterProjectionGpu|ReferenceCameraView|ReferencePositionFrameGpu').replace('ModuleBoundaries|ModuleBoundaryFixtures','Project|ProjectReferenceViews|ModuleBoundaries|ModuleBoundaryFixtures')
text=text.replace("len(manifest['programs'])==859","len(manifest['programs'])==860")
text=text.replace("assert hashes==baseline['shaders'] and len(child)==858", "assert all(hashes.get(n)==h for n,h in baseline['shaders'].items()) and len(child)==859")
text=text.replace('len(cases)==10','len(cases)==13').replace('tests=10','tests=13')
marker="    for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:"
extra='''    with (out/(config.lower()+'-native-project-views.log')).open('wb') as log:subprocess.run([str(build/'AzureProjectReferenceViewsTests.exe'),str(out/'raster-profile.bin'),str(out/'raster-frame.bin')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
    text=(out/(config.lower()+'-native-project-views.log')).read_text();assert '3 reference views' in text and '22 JSON rejections' in text,text
    with (out/(config.lower()+'-raster-cpu.log')).open('wb') as log:subprocess.run([str(build/'AzureReferenceRasterProjectionGpuTests.exe'),'--cpu-only'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
'''
assert text.count(marker)==1;text=text.replace(marker,extra+marker)
text=text.replace("[('AzureReferenceDepthGpuTests','147840 exact R32/D32 values'),('AzureReferenceDepthCoverageGpuTests','20992 exact masked R32/D32 values')]","[('AzureReferenceRasterProjectionGpuTests','44364 records / 177456 exact GPU raster components')]")
text=text.replace("[str(build/(target+'.exe')),str(build/'shaders')]","[str(build/(target+'.exe')),str(build/'shaders/reference_raster_projection_test.comp.spv'),str(out/'raster-profile.bin'),str(out/'raster-frame.bin'),str(out/'raster-records.bin')]")
text=text.replace('len(gpu)==8','len(gpu)==4').replace('exactDepthCoverageValues=675328','exactRasterComponents=709824').replace('childProgramsExact=858,activeProgramCount=859','childProgramsExact=859,activeProgramCount=860')
text=text.replace("source='b699b6b',evidence='reference-position-frame-main-integration'","source='076fe6e',evidence='reference-camera-view-main-integration'")
(out/'build.py').write_text(text)
print('Prepared thirteen checks/configuration, four real raster endpoints and actual camera/project CPU fixtures')
