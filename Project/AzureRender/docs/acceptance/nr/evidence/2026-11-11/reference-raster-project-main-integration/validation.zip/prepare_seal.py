from pathlib import Path
root=Path.cwd();out=Path(__file__).resolve().parent
text=(root/'build/runs/20261111-013805-reference-camera-view-main-integration-38f34e/seal.py').read_text()
text=text.replace("sum(r['tests'] for r in build['checks'])==20 and len(build['gpuProcesses'])==8","sum(r['tests'] for r in build['checks'])==26 and len(build['gpuProcesses'])==4")
text=text.replace("runtimeSourceCommit='6721bde',sourceBranchCommit='7d9dd54'","runtimeSourceCommit='b514de0',sourceBranchCommit='80719a9',rasterSourceCommit='746ba12',rasterIntegrationCommit='1e04cd3'")
text=text.replace("read('child-scope-review.json')","read('source-review.json')")
text=text.replace('reference-camera-view-main-integration-qualified','reference-raster-project-main-integration-qualified')
text=text.replace('2026-11-11/reference-camera-view-main-integration','2026-11-11/reference-raster-project-main-integration')
(out/'seal.py').write_text(text)
