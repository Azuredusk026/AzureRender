from pathlib import Path
import json,os,subprocess,sys,shutil,time,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,verify,digest
os.environ.update(managed_environment(out/'tmp'))
os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1')
if '--inside' not in sys.argv:
    raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside',*sys.argv[1:]]).returncode)
assert (out/'integration-source.json').is_file(), 'Integrate the final qualified source before building'
before=inputs(root);checks=[]
targets=['AzureMaterialUvPolicyTests','AzureMaterialPipelinePolicyTests','AzureMaterialUvImportTests','AzureCharacterRepairTests','AzureMaterialUvGradientsGpuTests','AzureHotReloadTests','AzureShaderCompilerContractTests']
selector=r'^(AzureRender\.(MaterialUvPolicy|MaterialPipelinePolicy|CharacterRepair|ShaderCompilerContract|ShaderCatalogCompilation|HotReload)|AzureAssets\.MaterialUvImport|AzureEngine\.(ModuleBoundaries|ModuleBoundaryFixtures))$'
for config in ['Release','Debug']:
    build=root/('build/ninja-msvc-'+config.lower());os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
    command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
    for target in targets:command+=['--test-target',target]
    start=time.monotonic()
    with (out/(config.lower()+'-build.log')).open('wb') as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=720)
    baseline=json.loads((out/'baseline-products.json').read_text())[config.lower()]['shaders']
    manifest=json.loads((build/'shader-reload.json').read_text());assert len(manifest['programs'])==856
    reference=[p for p in manifest['programs'] if 'AZURE_REFERENCE_MATERIAL_UV=1' in p['defines']];assert len(reference)==168
    hashes={p['output']:digest(build/'shaders'/p['output']) for p in manifest['programs']}
    assert all(hashes.get(name)==sha for name,sha in baseline.items()), 'An existing program changed'
    child=json.loads((out/(config.lower()+'-quality-program-sha256.json')).read_text())
    assert len(child)==855 and all(hashes.get(name)==sha for name,sha in child.items()), 'A qualified child program differs'
    (out/(config.lower()+'-program-sha256.json')).write_text(json.dumps(hashes,indent=2))
    shutil.copyfile(build/'build-provenance.json',out/(config.lower()+'-build-provenance.json'))
    command=['ctest','--test-dir',str(build),'-C',config,'--output-on-failure','--no-tests=error','-R',selector,'--output-junit',str(out/(config.lower()+'-tests.xml'))]
    with (out/(config.lower()+'-tests.log')).open('wb') as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=420)
    cases=ET.parse(out/(config.lower()+'-tests.xml')).findall('.//testcase')
    assert len(cases)==9 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
    for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
        os.environ['VK_LOADER_DRIVERS_SELECT']=driver
        with (out/(config.lower()+'-'+device+'-public-gradient.log')).open('wb') as log:
            subprocess.run([str(build/'AzureMaterialUvGradientsGpuTests.exe'),str(build/'shaders/material_uv_gradients_test.vert.spv'),str(build/'shaders/material_uv_gradients_test.frag.spv')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
        text=(out/(config.lower()+'-'+device+'-public-gradient.log')).read_text(errors='replace')
        assert ('Intel' if device=='intel' else 'NVIDIA') in text
        assert not any(x in text for x in ['VUID-','SYNC-HAZARD','Validation Error:','Validation Warning:'])
    checks.append(dict(config=config,tests=9,skips=0,publicGradientDevices=2,seconds=time.monotonic()-start))
    verify(root,json.loads((build/'build-provenance.json').read_text()));print(json.dumps(checks[-1]),flush=True)
assert inputs(root)==before
assert all(digest(root/p)==h for p,h in json.loads((out/'protected-files.json').read_text()).items())
(out/'build-results.json').write_text(json.dumps(dict(checks=checks,sourceUnchanged=True,oldProgramIdentitiesPerConfiguration=688,qualifiedChildProgramIdentitiesPerConfiguration=855,activeProgramCount=856),indent=2))
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
subprocess.run([sys.executable,'-X','utf8','-B',str(out/'capture.py')],check=True,timeout=600)
