from pathlib import Path
import os,sys,json,subprocess,time
import numpy as np
from PIL import Image
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
before=inputs(root);build=root/'build/ninja-msvc-release';proof=json.loads((build/'build-provenance.json').read_text());verify(root,proof)
rows=[];start=time.monotonic()
for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
    os.environ['VK_LOADER_DRIVERS_SELECT']=driver
    for group,tool,extra in [
        ('footprint','test_material_uv_footprint_gpu.py',[]),
        ('missing','test_material_uv_policy_failure_gpu.py',[]),
        ('shadow','test_material_uv_policy_gpu.py',['--section','coverage','--case','shadow'])]:
        folder=out/('native-'+device+'-'+group)
        command=[sys.executable,'-X','utf8','-B',str(root/'tools'/tool),'--executable',str(build/'AzurePlayer.exe'),'--output',str(folder),'--expected-validation','disabled',*extra]
        with (out/(device+'-'+group+'.log')).open('wb') as log:
            subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=360)
        if group=='footprint':
            result=json.loads((folder/'results.json').read_text());assert result['status']=='passed'
            for policy in ['device','reference']:
                a=np.asarray(Image.open(folder/('indexed-'+policy)/'frames/frame_000000.png').convert('RGB'))
                b=np.asarray(Image.open(folder/('fixed-'+policy)/'frames/frame_000000.png').convert('RGB'))
                assert np.array_equal(a,b)
            assert all(('Intel' if device=='intel' else 'NVIDIA') in r['device'] for r in result['cases'])
            record=dict(changedPixels=result['changedPixels'],maximumByteChange=result['maximumByteChange'],bothDescriptorPoliciesExact=True)
        elif group=='missing':
            result=json.loads((folder/'summary.json').read_text());assert result['status']=='passed' and len(result['cases'])==4
            assert all(c['frames']==0 and c['allocatorAfterUnload']==dict(buffers=0,images=0) for c in result['cases'])
            assert not list(folder.rglob('resources/shaders/*.spv'))
            record=dict(rejectionCases=4,shaderLinksReleased=True)
        else:
            summaries=list(folder.rglob('summary.json'));assert len(summaries)==1
            result=json.loads(summaries[0].read_text());assert result['status']=='passed' and len(result['cases'])==4 and result['groups']==[dict(name='shadow',status='passed',comparison='pixel-exact-reference-and-descriptor-paths')]
            caps=[json.loads(p.read_text()) for p in folder.rglob('gpu_capabilities.json')];assert len(caps)==4 and all(('Intel' if device=='intel' else 'NVIDIA') in c['device_name'] for c in caps)
            record=dict(capturedImages=4,comparedPixelValues=4*256*256,allFourRgbExact=True,summaries=[str(p.relative_to(out)) for p in summaries])
        rows.append(dict(device=device,group=group,passed=True,**record));(out/'native-focus-progress.json').write_text(json.dumps(rows,indent=2))
        assert time.monotonic()-start<1100
        print(json.dumps(rows[-1]),flush=True)
assert inputs(root)==before;verify(root,proof)
assert all(digest(root/p)==h for p,h in json.loads((out/'protected-files.json').read_text()).items())
(out/'native-focus-results.json').write_text(json.dumps(dict(status='passed',groups=rows,sourceUnchanged=True,productsUnchanged=True,protectedFilesExact=13,seconds=time.monotonic()-start),indent=2))
