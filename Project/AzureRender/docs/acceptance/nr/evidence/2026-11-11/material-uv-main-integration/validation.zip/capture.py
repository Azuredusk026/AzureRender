from pathlib import Path
import sys,os,json,subprocess,time
import numpy as np
from PIL import Image
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest,verify
from run_playable_performance import memory_snapshot
os.environ.update(managed_environment(out/'tmp'));os.environ.update(DOTNET_ROOT='D:/Tools/dotnet9',VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer');build=root/'build/ninja-msvc-release';os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','AZURE_CPU_WORK_REPORT']:os.environ.pop(key,None)
verify(root,json.loads((build/'build-provenance.json').read_text()));source=inputs(root)
reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint'
command=json.loads((reference/'command.json').read_text());command[0]=str(build/'AzurePlayer.exe');command[command.index('--capture-dir')+1]=str(out/'frames');command[command.index('--runtime-report')+1]=str(out/'runtime.json')
command+=['--gpu-timing','--gpu-timing-output',str(out/'gpu-timing.json')]
lock=json.loads((out/'frozen-project-inputs.json').read_text());assert len(lock)==1729 and all(digest(Path(p))==v for p,v in lock.items())
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]};(out/'capture-command.json').write_text(json.dumps(dict(command=command,products=products),indent=2));start=time.monotonic()
observations=[]
with (out/'capture.log').open('wb') as log:
 p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
 try:
  while p.poll() is None:
   try:observations.append(dict(seconds=time.monotonic()-start,**memory_snapshot(p.pid)))
   except OSError:
    if p.poll() is not None:break
    raise
   if time.monotonic()-start>550:raise TimeoutError(command)
   time.sleep(.05)
 finally:
  if p.poll() is None:p.kill();p.wait()
(out/'memory-observations.json').write_text(json.dumps(observations,indent=2))
assert observations
memoryReport=dict(peakWorkingSetBytes=max(v['peak'] for v in observations),observationIntervalMs=50,observations=len(observations),allocator=json.loads((out/'gpu-timing.json').read_text()).get('allocator'),scope='Strict four-frame joint capture; descriptive memory observation, separate from the formal P5 workload and steady-state sampling')
(out/'memory-results.json').write_text(json.dumps(memoryReport,indent=2))
frames=[]
for image in sorted((out/'frames').glob('frame_*.png')):
 a=np.asarray(Image.open(image).convert('RGB'));b=np.asarray(Image.open(reference/'frames'/image.name).convert('RGB'));d=np.abs(a.astype('i2')-b.astype('i2'));frames.append(dict(name=image.name,sha256=digest(image),referenceSha256=digest(reference/'frames'/image.name),changedPixels=int(np.any(d,axis=2).sum()),maximumByteError=int(d.max())))
text=(out/'capture.log').read_text(errors='replace');report=dict(exitCode=p.returncode,seconds=time.monotonic()-start,frames=frames,validationClean=not any(t in text for t in ['Validation Error:','Validation Warning:','SYNC-HAZARD','VUID-']),allocatorZero='Allocator after unload: buffers=0 images=0' in text,sourceUnchanged=inputs(root)==source,programsUnchanged=all(digest(Path(k))==v for k,v in products.items()),projectInputsUnchanged=all(digest(Path(k))==v for k,v in lock.items()))
(out/'capture-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
assert p.returncode==0 and len(frames)==4 and all(x['changedPixels']==0 and x['sha256']==x['referenceSha256'] for x in frames)
assert all(report[k] for k in ['validationClean','allocatorZero','sourceUnchanged','programsUnchanged','projectInputsUnchanged'])

subprocess.run([sys.executable,'-X','utf8','-B',str(out/'native_focus.py')],check=True,timeout=1140)
