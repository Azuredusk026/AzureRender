from pathlib import Path
import json,subprocess,sys,os,time
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));source=inputs(root)
(out/'source-lock.json').write_text(json.dumps(source,indent=2))
protected=json.loads((root/'build/runs/20261111-005441-reference-position-frame-main-integration-59835c/protected-files.json').read_text());(out/'protected-files.json').write_text(json.dumps(protected,indent=2))
producer=root/'build/runs/20261111-001050-quad-feature-device-capture-4798d1';state=json.loads((producer/'state.json').read_text());assert digest(Path(state['capture']))==state['captureSha256']
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'scan.py')];start=time.monotonic()
with (out/'driver.log').open('wb') as log:r=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=300)
report=json.loads((out/'scan-state.json').read_text());assert r.returncode==0 and report['status']=='scanned',report.get('error',report['status'])
assert inputs(root)==source and all(digest(root/p)==h for p,h in protected.items())
report.update(sourceUnchanged=True,protectedFilesExact=13,secondsIncludingOpen=time.monotonic()-start)
(out/'results.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
