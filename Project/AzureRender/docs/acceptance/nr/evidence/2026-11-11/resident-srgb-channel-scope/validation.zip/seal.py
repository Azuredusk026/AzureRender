from pathlib import Path
import json,zipfile,hashlib,sys
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
assert inputs(root)==json.loads((out/'source-lock.json').read_text())
assert all(digest(root/p)==h for p,h in json.loads((out/'protected-files.json').read_text()).items())
result=json.loads((out/'results.json').read_text());assert result['scopeTextures']==180 and len(result['rows'])==180
assert result['rgbaMipBytes']==933172756 and result['eligibleTextures']==40
result.update(currentMaterialTexelBytes=1852081920,optimisticMaterialTexelBytes=1852081920-result['potentialSavedBytes'],formalDeviceLocalLimitBytes=1610612736,capacityScope='Texel accounting only; resource allocation peak and formal P5 workload remain separate',captureReadState='Captured initial resource contents at event zero; immutable uploaded sRGB image mip chains',overall='failed-user-review')
(out/'results.json').write_text(json.dumps(result,indent=2))
dest=root/'docs/acceptance/nr/evidence/2026-11-11/resident-srgb-channel-scope';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.iterdir()):
        if p.is_file() and p.suffix in ['.json','.py','.log']:
            members[p.name]=dict(bytes=p.stat().st_size,sha256=digest(p));z.write(p,p.name)
    z.writestr('member-sha256.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and all(len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in members.items())
assert archive.stat().st_size<8*1024*1024
verification=dict(bytes=archive.stat().st_size,members=len(members)+1,sha256=digest(archive),memberHashesVerified=True)
(dest/'archive-verification.json').write_text(json.dumps(verification,indent=2));(dest/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(verification))
