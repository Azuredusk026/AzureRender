from pathlib import Path
import json,hashlib,traceback,sys,time,collections
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261111-013339-resident-srgb-channel-scope-00a65e'
producer=root/'build/runs/20261111-001050-quad-feature-device-capture-4798d1';state=json.loads((producer/'state.json').read_text())
report=dict(status='starting',sourceBase='4bb194a',captureSourceBase='73300ab',captureSha256=state['captureSha256'],scope='All captured single-layer two-dimensional RGBA8 sRGB resources, including any non-material resources; all authored/resident mip levels; upper bound before sampler and view policy qualification',rows=[]);cap=c=None;start=time.monotonic()
def save():(out/'scan-state.json').write_text(json.dumps(report,indent=2))
def constant(channel):
    if channel.count(0)==len(channel):return 'zero'
    if channel.count(255)==len(channel):return 'one'
    return None
try:
    save();cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
    status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
    names={str(r.resourceId):r.name for r in c.GetResources()};textures=list(c.GetTextures())
    inventory=[dict(resource=str(t.resourceId),name=names.get(str(t.resourceId),''),width=t.width,height=t.height,depth=t.depth,mips=t.mips,arraysize=t.arraysize,format=t.format.Name(),bytes=t.byteSize,msSamples=t.msSamp) for t in textures]
    (out/'texture-inventory.json').write_text(json.dumps(inventory,indent=2))
    report['allTextureCount']=len(textures);report['formatCounts']=dict(collections.Counter(t.format.Name() for t in textures));save()
    c.SetFrameEvent(0,True)
    eligible=[t for t in textures if t.format.Name()=='R8G8B8A8_SRGB' and t.depth==1 and t.arraysize==1 and t.msSamp==1]
    report['scopeTextures']=len(eligible);save()
    for texture in eligible:
        row=dict(resource=str(texture.resourceId),name=names.get(str(texture.resourceId),''),width=texture.width,height=texture.height,mips=texture.mips,reportedBytes=texture.byteSize,levels=[])
        # Mapping constants and copied RGB channels operate in the sRGB domain.
        # Alpha may only be constant: original alpha is not sRGB-decoded.
        candidates={i:None for i in range(3)};total=0
        for mip in range(texture.mips):
            data=bytes(c.GetTextureData(texture.resourceId,rd.Subresource(mip,0,0)))
            w=max(1,texture.width>>mip);h=max(1,texture.height>>mip);assert len(data)==w*h*4
            channels=[data[i::4] for i in range(4)];alpha=constant(channels[3]);new={}
            for selected,mapping in candidates.items():
                current=[]
                for channel in channels[:3]:current.append('r' if channel==channels[selected] else constant(channel))
                current.append(alpha)
                if None not in current and (mapping is None or mapping==current):new[selected]=current
            candidates=new;total+=len(data)
            row['levels'].append(dict(mip=mip,width=w,height=h,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),candidateChannels=sorted(candidates)))
            del channels,data
        row.update(rgbaMipBytes=total,uniformMappings=candidates,potentialR8Bytes=total//4,potentialSavedBytes=total*3//4 if candidates else 0)
        report['rows'].append(row);save()
    report.update(status='scanned',seconds=time.monotonic()-start,rgbaMipBytes=sum(r['rgbaMipBytes'] for r in report['rows']),eligibleTextures=sum(bool(r['uniformMappings']) for r in report['rows']),potentialSavedBytes=sum(r['potentialSavedBytes'] for r in report['rows']),actualGpuSavingMeasured=False,productionCandidate=False)
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
    if c:c.Shutdown()
    if cap:cap.Shutdown()
    save()
sys.exit(0 if report['status']=='scanned' else 1)
