from pathlib import Path
import json,hashlib,subprocess,os,re,sys
out=Path(__file__).resolve().parent;root=out.parents[2];c=sys.argv[1].lower();build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if c=='release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for n,v in json.loads((out/'frozen-source.json').read_text()).items():assert sha(root/n)==v,n
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*' if device=='nvidia' else '*igvk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(build)+';'+env['PATH'])
 commands=[('guard',[str(build/'AzureConservativeCullingGpuTests.exe'),str(build/'shaders/cull_indirect.comp.spv'),str(build/'shaders/visibility_prototype.comp.spv'),str(out/'legacy-cull_indirect.comp.spv')]),('current-visibility',[str(build/'AzureVisibilityGpuTests.exe'),str(build/'shaders/cull_indirect.comp.spv'),str(build/'shaders/visibility_prototype.comp.spv'),str(out/(c+'-'+device+'-current-visibility.json'))]),('legacy-visibility',[str(build/'AzureVisibilityGpuTests.exe'),str(out/'legacy-cull_indirect.comp.spv'),str(out/'legacy-visibility_prototype.comp.spv'),str(out/(c+'-'+device+'-legacy-visibility.json'))])]
 for label,command in commands:
  name=c+'-'+device+'-'+label;print('START',name,flush=True)
  with (out/(name+'.log')).open('wb') as log:r=subprocess.run(command,env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  t=(out/(name+'.log')).read_text(errors='replace');row=dict(configuration=c,device=device,scope=label,command=command,exitCode=r.returncode,validationClean=not bool(re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)',t,re.I)));rows.append(row);(out/(c+'-gpu-results.json')).write_text(json.dumps(rows,indent=2)+'\n');assert r.returncode==0 and row['validationClean'],t[-5000:]
  if label=='guard':assert '49160 exact draw records' in t,t[-1000:]
  print('PASS',name,flush=True)
