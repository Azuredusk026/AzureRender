from pathlib import Path
import json,sys
out=Path(__file__).resolve().parent;sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a';cp=Path('D:/Projects/FYP-coordination/quality-claim.json');claim=json.loads(cp.read_text(encoding='utf-8'));token=s.acquire_inputs(s.DEFAULT_BUILD,out,['20261103-234012-character-reference-stages-5abe6c'],owner);claim['inputLease']=[token];cp.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'default-four.py').write_bytes((out.parent/'20261111-001326-reference-position-frame-482201/default-four.py').read_bytes())
source=(out.parent/'20261111-022111-reference-raster-projection-bc4b9a/queued-gpu.py').read_text().replace('quality-reference-raster-gpu','quality-project-reference-four').replace("str(out/'gpu.py')","str(out/'default-four.py')").replace("out/'gpu-execution.json'","out/'four-execution.json'")
source=source.replace('started=time.monotonic()',"import os\nos.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')\nstarted=time.monotonic()")
(out/'queued-four.py').write_text(source);print('Original four source leased and current binary capture configured')
