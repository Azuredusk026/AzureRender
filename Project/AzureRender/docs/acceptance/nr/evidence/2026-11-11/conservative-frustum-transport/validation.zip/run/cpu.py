from pathlib import Path
import json,sys,subprocess,os,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,v in json.loads((out/'frozen-source.json').read_text()).items():assert sha(root/n)==v,n
for c,parent in [('release','20261110-030251-hair-main-chroma-public-9e799c'),('debug','20261110-031856-hair-main-chroma-debug-668bf2')]:
 b=out.parent/parent/c;env=os.environ.copy();env['PATH']=str(b)+';'+env['PATH']
 for target in ['AzureVisibilityPrototypeTests','AzureRenderFrameTaskSchedulerTests']:
  command=[str(b/(target+'.exe'))];r=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,timeout=120);(out/(c+'-'+target+'.log')).write_text(r.stdout+r.stderr);rows.append(dict(configuration=c,command=command,exitCode=r.returncode,stdout=r.stdout.strip(),binarySha256=sha(Path(command[0]))));assert r.returncode==0,r.stdout+r.stderr
(out/'cpu-results.json').write_text(json.dumps(rows,indent=2)+'\n');print('Four CPU regression processes passed')
