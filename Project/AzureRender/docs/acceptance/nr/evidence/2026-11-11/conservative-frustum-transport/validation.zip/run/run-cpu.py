from pathlib import Path
import sys,json
out=Path(__file__).resolve().parent;sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
result=s.maintenance.guarded_run(out.parents[1],out.name,[sys.executable,str(out/'cpu.py')],180);(out/'cpu-execution.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));sys.exit(result.get('exitCode',2) if result.get('status')=='exited' else 2)
