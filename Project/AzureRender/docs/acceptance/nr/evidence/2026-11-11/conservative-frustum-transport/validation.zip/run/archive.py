from pathlib import Path
import json,zipfile,hashlib,re
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=json.loads((out/'results.json').read_text());plan=root/'docs/plans/2026-11-11-conservative-frustum-transport.md';plan.write_text(plan.read_text(encoding='utf-8').replace('- [ ]','- [x]'),encoding='utf-8')
for name,prefix in [('README.md','docs/'),('docs/project-status.md',''),('docs/plans/azure-engine-plan.md','../'),('docs/plans/2026-11-09-native-quality.md','../')]:
 p=root/name;text=p.read_text(encoding='utf-8')
 if '[保守剔除参数]' not in text:text+='\n[保守剔除参数]('+prefix+'acceptance/nr/conservative-frustum-transport.md)通过两配置、两设备及旧模块兼容检查。\n128 字节布局及原四帧通过，参考混合平面继续接入。\n'
 p.write_text(text,encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');anchor='## 2026-11-11 场景参考相机'
if '## 2026-11-11 保守剔除参数' not in text:text=text.replace(anchor,'## 2026-11-11 保守剔除参数\n\n- 在 128 字节推送布局内承载保守余量及参考齐次尺度平面。\n- 管线通过特化常量显式启用，旧模块在默认路径保持兼容。\n- 两配置、两设备共 196640 条绘制记录及表面编号通过精确核对。\n- 857 份既有程序保持相同，两份剔除程序完成布局及能力扩展。\n- 当前原四帧摘要精确一致，预算失败完成回收及预检阻断修正。\n\n'+anchor)
p.write_text(text,encoding='utf-8')
sources=list(result['sourceSha256'])+['docs/runtime/conservative-frustum.md','docs/plans/2026-11-11-conservative-frustum-transport.md','docs/acceptance/nr/conservative-frustum-transport.md'];files={'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.ps1','.json','.log','.cpp','.hpp','.spv'}};files.update({'source/'+n:root/n for n in sources})
dest=root/'docs/acceptance/nr/evidence/2026-11-11/conservative-frustum-transport';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']=dict(bytes=archive.stat().st_size,sha256=sha(archive),members=len(members)+1);(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n');(dest/'program-catalog.json').write_bytes((out/'program-catalog.json').read_bytes())
for n in [v for v in sources if v.endswith('.md')]:
 p=root/n;text=p.read_text(encoding='utf-8')
 for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(n,sentence)
 for link in re.findall(r'\]\(([^)]+)\)',text):
  if not re.match(r'(https?:|#)',link):assert (p.parent/link.split('#')[0]).exists(),(n,link)
print(json.dumps(result['archive']))
