from pathlib import Path
import json,sys,zipfile,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs,verify
for config in ['debug','release']:
    path=root/('build/ninja-msvc-'+config)/'build-provenance.json';verify(root,json.loads(path.read_text()));(out/(config+'-build-provenance.json')).write_bytes(path.read_bytes())
assert inputs(root)==json.loads((out/'baseline-source.json').read_text())
assert all(digest(Path(p))==h for p,h in json.loads((out/'baseline-products.json').read_text()).items())
protected=json.loads((out/'protected-files.json').read_text());assert len(protected)==13 and all(digest(root/p)==h for p,h in protected.items())
lock=json.loads((out/'frozen-project-inputs.json').read_text());assert len(lock)==1729 and all(digest(Path(p))==h for p,h in lock.items())
capture=json.loads((out/'capture-results.json').read_text());cost=json.loads((out/'cost-results.json').read_text());build=json.loads((out/'build-results.json').read_text())
assert cost['privateEfficiencyPassed'] and capture['exitCode']==0 and all(r['changedPixels']==0 and r['sha256']==r['referenceSha256'] for r in capture['frames'])
reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames';duplicates=[]
for frame in capture['frames']:
    p=out/'frames'/frame['name'];original=reference/frame['name'];assert digest(p)==digest(original)==frame['sha256'];duplicates.append(dict(path=str(p),original=str(original),bytes=p.stat().st_size,sha256=digest(p)))
(out/'duplicate-frame-inventory.json').write_text(json.dumps(duplicates,indent=2))
result=dict(status='strict-compatible-effective-private-candidate-production-integration-pending',sourceBase='88d84fb',build=build,capture=capture,cost=cost,shortGpuP95Milliseconds=cost['rows'][1]['summary']['gpu']['p95'],shortCpuWorkP95Milliseconds=cost['rows'][1]['summary']['cpu']['p95'],shortGpuBudgetPassed=cost['rows'][1]['summary']['gpu']['p95']<=16.6,shortCpuBudgetPassed=cost['rows'][1]['summary']['cpu']['p95']<=8,formalPerformancePassed=False,productionAdopted=False,protectedFilesExact=13,projectInputsExact=1729,overall='failed-user-review')
(out/'results.json').write_text(json.dumps(result,indent=2))
dest=root/'docs/acceptance/nr/evidence/2026-11-11/quad-depth-combination-native';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={}
paths=[p for p in out.iterdir() if p.is_file() and p.suffix in ['.json','.py','.log','.cpp']]
paths+=[out/'AzurePlayer-private-device.exe']
for name in ['source','cost-before','cost-candidate','cost-after']:
    paths += [p for p in (out/name).rglob('*') if p.is_file() and p.suffix in ['.json','.csv','.log','.frag','.glsl']]
paths += [p for p in (out/'frames').iterdir() if p.is_file() and p.suffix=='.json']
qualified=root/'build/runs/20261111-021128-quad-depth-visibility-local-qualification-1ea541/combined';actual=json.loads((qualified/'compare-state.json').read_text())['programs']
for p in actual:
    binary=out/'candidate/shaders'/p['file'];assert digest(binary)==p['candidateSha256'];paths.append(binary)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(set(paths)):
        name=p.relative_to(out).as_posix();members[name]=dict(bytes=p.stat().st_size,sha256=digest(p));z.write(p,name)
    z.writestr('member-sha256.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and all(len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in members.items())
assert archive.stat().st_size<8*1024*1024
verification=dict(bytes=archive.stat().st_size,members=len(members)+1,sha256=digest(archive),memberHashesVerified=True,actualPrograms=10,privateExecutableIncluded=True)
(dest/'archive-verification.json').write_text(json.dumps(verification,indent=2));(dest/'results.json').write_text(json.dumps(result,indent=2))
for item in duplicates:
    path=Path(item['path']);assert path.parent.resolve()==(out/'frames').resolve() and digest(path)==digest(Path(item['original']))==item['sha256'];path.unlink()
(out/'identical-frames-reclaimed.json').write_text(json.dumps(dict(files=len(duplicates),bytes=sum(i['bytes'] for i in duplicates),archive=verification),indent=2));print(json.dumps(verification))
