from pathlib import Path
import json,sys,os,subprocess,shutil,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from artifact_maintenance import managed_environment
from artifact_budget import check
from run_playable_performance import freeze_products
os.environ.update(managed_environment(out/'tmp'));os.environ.update(DOTNET_ROOT='D:/Tools/dotnet9',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
build=root/'build/ninja-msvc-release';parent=root/'build/runs/20261111-021128-quad-depth-visibility-local-qualification-1ea541';qualified=parent/'combined';device=root/'build/runs/20261110-235204-quad-cascade-demand-local-qualification-0b5052'
assert json.loads((qualified/'results.json').read_text())['qualified']
verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root);products=freeze_products(root,build/'AzurePlayer.exe',build/'AzureRender.exe')
(out/'baseline-source.json').write_text(json.dumps(before,indent=2));(out/'baseline-products.json').write_text(json.dumps(products,indent=2))
for name in ['protected-files.json','frozen-project-inputs.json']:shutil.copyfile(root/'build/runs/20261111-013805-reference-camera-view-main-integration-38f34e'/name,out/name)
protected=json.loads((out/'protected-files.json').read_text());assert all(digest(root/p)==h for p,h in protected.items())
budget=check(root/'build',run=out,planned=650*1024**2);assert budget['allowed'],budget;(out/'copy-budget.json').write_text(json.dumps(budget,indent=2))
manifest=json.loads((build/'shader-reload.json').read_text());assert len(manifest['programs'])==859
for mode in ['reference','candidate']:
    folder=out/mode/'shaders';folder.mkdir(parents=True,exist_ok=True)
    for p in manifest['programs']:shutil.copyfile(build/'shaders'/p['output'],folder/p['output'])
    shutil.copyfile(build/'shader-reload.json',out/mode/'shader-reload.json')
    (out/(mode+'-programs.json')).write_text(json.dumps({p['output']:digest(folder/p['output']) for p in manifest['programs']},indent=2))
sourceDir=out/'source';sourceDir.mkdir(exist_ok=True)
for mode,pattern in [('main','combined-*-mesh*.frag'),('snapshot','combined-*-character_snapshot*.frag')]:
    files=list((qualified/'candidate-source').glob(pattern));assert files and len({digest(p) for p in files})==1
    shutil.copyfile(files[0],sourceDir/(mode+'.frag'))
shutil.copyfile(qualified/'selected_receiver.glsl',sourceDir/'selected_receiver.glsl')
programs=[p for p in manifest['programs'] if p['source']=='mesh.frag' and not any(t in p['defines'] for t in ['AZURE_GEOMETRY_SAMPLES=1','AZURE_HAIR_PIXEL_INTEGRAL=1','AZURE_REFERENCE_MATERIAL_UV=1','AZURE_VIEW_FOG=1'])];assert len(programs)==256
rows=[];start=time.monotonic()
with (out/'shader-build.log').open('wb') as log:
    for i,p in enumerate(programs):
        assert time.monotonic()-start<240,'Private shader build budget exceeded'
        source=sourceDir/('snapshot.frag' if 'AZURE_OPAQUE_SNAPSHOT=1' in p['defines'] else 'main.frag');destination=out/'candidate/shaders'/p['output']
        arguments=[('--target-env=vulkan1.1' if v.startswith('--target-env=') else v) for v in p['arguments']]
        if not any(v.startswith('--target-env=') for v in arguments):arguments+=['--target-env=vulkan1.1']
        command=[manifest['compiler'],*arguments,*['-D'+v for v in p['defines']],'-I'+str(root/'shaders'),str(source),'-o',str(destination)]
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
        subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.1',str(destination)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=15)
        rows.append(dict(program=p,command=command,source=source.name,sha256=digest(destination)))
        if i%32==0:print('Compiled',i+1,'/',len(programs),flush=True)
(out/'compiled-programs.json').write_text(json.dumps(rows,indent=2))
measured=json.loads((qualified/'compare-state.json').read_text())['programs'];assert len(measured)==10
assert all(digest(out/'candidate/shaders'/p['file'])==p['candidateSha256'] for p in measured)
candidate={p['output']:digest(out/'candidate/shaders'/p['output']) for p in manifest['programs']};(out/'candidate-programs.json').write_text(json.dumps(candidate,indent=2))
private=(device/'AzureRenderApp-private-device.cpp').read_text();marker='#if 1\n    VkPhysicalDeviceShaderQuadControlFeaturesKHR';extra='    if(!fragmentQuadControl_)throw std::runtime_error("Quad-demand probe requires enabled quad-control features");\n    std::cout << "Quad-demand device probe: quad-control and maximal-reconvergence requested\\n";\n'
restored=private.replace(marker,'#if defined(AZURE_SURFACE_RADIANCE_PROGRAMS)\n    VkPhysicalDeviceShaderQuadControlFeaturesKHR').replace(extra,'');assert restored==(root/'src/app/AzureRenderApp.cpp').read_text()
(out/'AzureRenderApp-private-device.cpp').write_text(private)
commands=json.loads((device/'private-build-commands.json').read_text())
for key in ['compile','link']:commands[key]=commands[key].replace(str(device),str(out))
(out/'private-build-commands.json').write_text(json.dumps(commands,indent=2));start=time.monotonic()
with (out/'private-build.log').open('wb') as log:
    for key in ['compile','link']:subprocess.run(commands[key],cwd=commands['workingDirectory'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=240)
assert inputs(root)==before and all(digest(Path(p))==h for p,h in products.items())
assert all(digest(root/p)==h for p,h in protected.items())
result=dict(status='private-built',sourceBase='88d84fb',privateAppChanges='Enable existing optional quad device feature chain and fail clearly unless enabled; production source untouched',privateHostSha256=digest(out/'AzurePlayer-private-device.exe'),compiledPrograms=256,referencePrograms=859,measuredProgramsByteExact=10,sourceUnchanged=True,productsUnchanged=True,protectedFilesExact=13,hostBuildSeconds=time.monotonic()-start)
(out/'build-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
subprocess.run([sys.executable,'-X','utf8','-B',str(out/'capture.py')],check=True,timeout=600)
