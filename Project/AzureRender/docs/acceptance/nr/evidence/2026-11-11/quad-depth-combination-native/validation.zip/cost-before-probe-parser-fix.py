import csv,json,os,subprocess,sys,time
from pathlib import Path
import numpy as np
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest
from artifact_budget import check
from gpu_environment import wait_and_record,RunEnvironmentMonitor
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',DOTNET_ROOT='D:/Tools/dotnet9')
os.environ['PATH']=str(build)+';'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin')+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LOADER_DEBUG','VK_LAYER_ENABLES','AZURE_CPU_WORK_REPORT','AZURERENDER_RESOURCE_ROOT']:os.environ.pop(key,None)
capture=json.loads((out/'capture-results.json').read_text());assert len(capture['frames'])==4 and all(x['changedPixels']==0 and x['sha256']==x['referenceSha256'] for x in capture['frames'])
assert all(capture[k] for k in ['featureRequestObserved','validationClean','allocatorZero','sourceUnchanged','productsUnchanged','privateProgramsUnchanged','projectInputsUnchanged'])
budget=check(root/'build',run=out,planned=128*1024**2);assert budget['allowed'],budget;(out/'cost-budget.json').write_text(json.dumps(budget,indent=2))
before=inputs(root);exe=out/'AzurePlayer-private-device.exe';products={str(exe):digest(exe),**json.loads((out/'baseline-products.json').read_text())}
for mode in ['reference','candidate']:
    for name,h in json.loads((out/(mode+'-programs.json')).read_text()).items():products[str(out/mode/'shaders'/name)]=h
assert all(digest(Path(p))==h for p,h in products.items())
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
lock=json.loads((out/'frozen-project-inputs.json').read_text());assert len(lock)==1729 and all(digest(Path(p))==h for p,h in lock.items())
wait_and_record(out/'startup-environment.json',timeout=60);rows=[]
for label in ['before','candidate','after']:
    folder=out/('cost-'+label);folder.mkdir();runtime=out/('candidate' if label=='candidate' else 'reference')
    probe=subprocess.run([str(exe),'--project',str(project),'--check-resources','--resource-root',str(runtime)],capture_output=True,text=True,timeout=30)
    assert probe.returncode==0 and Path(probe.stdout.splitlines()[0].strip('"')).resolve()==(runtime/'shaders').resolve()
    (folder/'resource-probe.json').write_text(json.dumps(dict(exitCode=probe.returncode,stdout=probe.stdout),indent=2))
    command=[str(exe),'--project',str(project),'--resource-root',str(runtime),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','24','--smoke-frames','120','--gpu-timing','--gpu-timing-output',str(folder/'timing.json')]
    (folder/'command.json').write_text(json.dumps(dict(command=command,executableSha256=products[str(exe)]),indent=2));environment={};start=time.monotonic()
    with RunEnvironmentMonitor(environment,path=folder/'environment.json',interval=2):
        with (folder/'process.log').open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=290)
    assert p.returncode==0,p.returncode
    data=json.loads((folder/'timing.json').read_text());samples=list(csv.DictReader((folder/'timing.csv').open()));selected=[r for r in samples if 61<=int(r['frame'])<=120]
    assert len(selected)==60 and [data['sceneWidth'],data['sceneHeight']]==[1920,1080]
    assert data['mainDepthSplitRecorded'] and not data.get('surfaceRadiancePrepared',False) and not data.get('shadowHistoryPrepared',False)
    log=(folder/'process.log').read_text(errors='replace');assert 'Allocator after unload: buffers=0 images=0' in log and 'Quad-demand device probe: quad-control and maximal-reconvergence requested' in log
    summary={name:dict(mean=float(np.mean([float(r[key]) for r in selected])),p95=float(np.percentile([float(r[key]) for r in selected],95))) for name,key in [('gpu','frameMs'),('main','sceneMs'),('shadow','shadowMs'),('post','postProcessMs')]}
    cpu=data['cpuFrame']['workSamplesMs'];assert len(cpu)==120;summary['cpu']=dict(mean=float(np.mean(cpu[60:])),p95=float(np.percentile(cpu[60:],95)))
    observations=environment['runObservations'];assert observations and not environment['monitorErrors']
    env=dict(acLineStates=sorted(set(r['hostPower']['acLineStatus'] for r in observations)),powerLimits=sorted(set(r['powerLimitWatts'] for r in observations if r['powerLimitWatts'] is not None)),thermalSlowdownObserved=any(any(v is True for v in r['thermalSlowdown'].values()) for r in observations),temperatureRange=[min(r['temperature'] for r in observations),max(r['temperature'] for r in observations)])
    row=dict(label=label,seconds=time.monotonic()-start,summary=summary,environment=env,metadata={k:v for k,v in data.items() if k.startswith(('defaultIsolation','shadowHistory','surfaceRadiance'))});rows.append(row)
    (out/'cost-progress.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
    assert inputs(root)==before and all(digest(Path(p))==h for p,h in products.items())
reference=(rows[0]['summary']['gpu']['mean']+rows[2]['summary']['gpu']['mean'])/2;mainReference=(rows[0]['summary']['main']['mean']+rows[2]['summary']['main']['mean'])/2
drift=abs(rows[0]['summary']['gpu']['mean']-rows[2]['summary']['gpu']['mean'])/reference
reduction=1-rows[1]['summary']['gpu']['mean']/reference;affected=1-rows[1]['summary']['main']['mean']/mainReference
criteria=dict(minimumWholeFrameGain=reduction>=.02,twiceReferenceDrift=reduction>=2*drift,maximumReferenceDrift=drift<=.03,minimumAffectedRangeGain=affected>=.05)
envOk=all(r['environment']['acLineStates']==[1] and not r['environment']['thermalSlowdownObserved'] for r in rows)
report=dict(rows=rows,referenceMeanMs=reference,candidateMeanMs=rows[1]['summary']['gpu']['mean'],reductionFraction=reduction,referenceDriftFraction=drift,affectedRangeReductionFraction=affected,efficiencyCriteria=criteria,shortEnvironmentQualified=envOk,privateEfficiencyPassed=all(criteria.values()) and envOk,formalPerformancePassed=False,sourceAndProgramsUnchanged=True,projectInputsUnchanged=all(digest(Path(p))==h for p,h in lock.items()))
(out/'cost-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
