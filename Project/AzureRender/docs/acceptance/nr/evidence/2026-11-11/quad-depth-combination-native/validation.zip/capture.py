from pathlib import Path
import sys,os,json,subprocess,time
import numpy as np
from PIL import Image
root=Path.cwd();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest
from artifact_budget import check
os.environ.update(managed_environment(out/'tmp'));os.environ.update(DOTNET_ROOT='D:/Tools/dotnet9',VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer')
os.environ['PATH']=str(build)+';'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin')+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','AZURE_CPU_WORK_REPORT','AZURERENDER_RESOURCE_ROOT']:os.environ.pop(key,None)
assert json.loads((out/'build-results.json').read_text())['measuredProgramsByteExact']==10
budget=check(root/'build',run=out,planned=128*1024**2);assert budget['allowed'],budget;(out/'capture-budget.json').write_text(json.dumps(budget,indent=2))
source=inputs(root);products=json.loads((out/'baseline-products.json').read_text());private={str(out/'candidate/shaders'/n):h for n,h in json.loads((out/'candidate-programs.json').read_text()).items()};exe=out/'AzurePlayer-private-device.exe';exeSha=digest(exe)
probe=subprocess.run([str(exe),'--check-resources','--resource-root',str(out/'candidate')],capture_output=True,text=True,timeout=30)
(out/'resource-probe.json').write_text(json.dumps(dict(exitCode=probe.returncode,stdout=probe.stdout,stderr=probe.stderr),indent=2));assert probe.returncode==0 and Path(probe.stdout.splitlines()[0].strip('"')).resolve()==(out/'candidate/shaders').resolve()
reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint'
command=json.loads((reference/'command.json').read_text());command[0]=str(exe);command[command.index('--capture-dir')+1]=str(out/'frames');command[command.index('--runtime-report')+1]=str(out/'runtime.json');command+=['--resource-root',str(out/'candidate')]
lock=json.loads((out/'frozen-project-inputs.json').read_text());assert len(lock)==1729 and all(digest(Path(p))==h for p,h in lock.items())
(out/'capture-command.json').write_text(json.dumps(dict(command=command,exeSha256=exeSha,privatePrograms=private),indent=2));start=time.monotonic()
with (out/'capture.log').open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=550)
frames=[]
for image in sorted((out/'frames').glob('frame_*.png')):
    a=np.asarray(Image.open(image).convert('RGB'));b=np.asarray(Image.open(reference/'frames'/image.name).convert('RGB'));d=np.abs(a.astype('i2')-b.astype('i2'));frames.append(dict(name=image.name,sha256=digest(image),referenceSha256=digest(reference/'frames'/image.name),changedPixels=int(np.any(d,axis=2).sum()),maximumByteError=int(d.max())))
text=(out/'capture.log').read_text(errors='replace');report=dict(exitCode=p.returncode,seconds=time.monotonic()-start,frames=frames,featureRequestObserved='Quad-demand device probe: quad-control and maximal-reconvergence requested' in text,validationClean=not any(t in text for t in ['Validation Error:','Validation Warning:','SYNC-HAZARD','VUID-']),allocatorZero='Allocator after unload: buffers=0 images=0' in text,sourceUnchanged=inputs(root)==source,productsUnchanged=all(digest(Path(k))==v for k,v in products.items()),privateProgramsUnchanged=digest(exe)==exeSha and all(digest(Path(k))==v for k,v in private.items()),projectInputsUnchanged=all(digest(Path(k))==v for k,v in lock.items()))
(out/'capture-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
assert p.returncode==0 and len(frames)==4 and all(x['changedPixels']==0 and x['sha256']==x['referenceSha256'] for x in frames)
assert all(report[k] for k in ['featureRequestObserved','validationClean','allocatorZero','sourceUnchanged','productsUnchanged','privateProgramsUnchanged','projectInputsUnchanged'])
