from pathlib import Path
import sys,json,hashlib,numpy as np,subprocess,zipfile,io
out=Path(__file__).parent;root=out.parents[2];owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
local=['20261110-110844-hair-postvs-clip-source-03c2f0','20261110-112309-hair-relative-projection-control-b9da17','20261110-165124-reference-depth-source-4d1d7d','20261110-173835-reference-depth-coverage-4b4afc','20261110-211719-alpha-ellipse-lod-5c69d6','20261110-003435-visibility-numeric-contract-4f95e7','20261110-003031-reciprocal-compact-profile-4e7929','20261110-030251-hair-main-chroma-public-9e799c']
main=['20261027-022702-object-visibility-depth-reconstruction-c7312f']
localToken='external-input-03747a161fa9466f932aa1fba0e0c990';mainToken=s.acquire_inputs(s.DEFAULT_BUILD,out,main,owner)
archivePath='Project/AzureRender/docs/acceptance/nr/evidence/2026-11-08/screen-object-visibility/validation.zip'
data=subprocess.check_output(['git','show','529f603:'+archivePath],cwd=root)
with zipfile.ZipFile(io.BytesIO(data)) as z:
 assert z.testzip() is None
 for name in ['queries.bin','expected.bin']:(out/name).write_bytes(z.read(name))
(out/'input-recovery.json').write_text(json.dumps({'sourceCommit':'529f603','archive':archivePath,'archiveSha256':hashlib.sha256(data).hexdigest(),'restored':{n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in ['queries.bin','expected.bin']},'originalMainRunReleased':True},indent=2)+'\n')
claimPath=Path('D:/Projects/FYP-coordination/quality-claim.json');old=json.loads(claimPath.read_text(encoding='utf-8'))
for name in ['20261110-214332-material-uv-loop-qualification-cf1d1e','20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2']:
 s.maintenance.seal(root/'build',root/'build/runs'/name)
for token in old['inputLease']:s.release_inputs(s.DEFAULT_BUILD,token,owner)
for token in old['localInputLease']:s.release_inputs(root/'build',token,owner)
old.update(state='actual-world-depth-source-diagnosis',lastCommit='529f603',taskPath=str(out),inputLease=[mainToken],localInputLease=[localToken],ownedFiles=[],pendingCommand='Single-factor actual world position to public reference depth, native UV and alpha held constant')
claimPath.write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
capture=root/'build/runs'/local[0];native=np.fromfile(capture/'native-vertex.bin',dtype='<f4').reshape(-1,33);vulkan=np.fromfile(capture/'vulkan-vertex.bin',dtype='<f4').reshape(-1,64)
assert native.shape[0]==vulkan.shape[0]==11564
assert np.array_equal(native[:,4:6].view('u4'),vulkan[:,12:14].copy().view('u4'))
frame=json.loads((root/'build/runs'/local[1]/'source.json').read_text());position=vulkan[:,16:19].copy();position[:,0]=-position[:,0];position=np.float32(position+np.array(frame['frameOffset'],dtype='f4'));exact=np.sum(position.view('u4')==native[:,6:9].copy().view('u4'),axis=0);assert exact.tolist()==[11564,11429,11564]
packed=np.ones((11564,4),dtype='<f4');packed[:,:3]=position;packed.tofile(out/'actual-world-mapped-positions.bin')
config=json.loads((root/'build/runs'/local[4]/'candidate-config.json').read_text());config.update(positions=str(out/'actual-world-mapped-positions.bin'),queries=str(out/'queries.bin'));(out/'candidate-config.json').write_text(json.dumps(config,indent=2)+'\n')
(out/'task-card.json').write_text(json.dumps({'baseCommit':'529f603','purpose':'One-factor source diagnosis: actual Vulkan world positions mapped into native reference frame, public depth and visibility','explorationSeconds':1800,'gpuSeconds':300,'plannedBytes':67108864,'acceptance':'Original17017pixels max1byte; retain NV0/Intel96 public native-geometry baseline; no production adoption on failure','positionsExactPerComponent':exact.tolist(),'uvBitExact':True,'frameOffset':frame['frameOffset'],'inputsSha256':{str(p):sha(p) for p in [capture/'vulkan-vertex.bin',capture/'native-vertex.bin',Path(config['profile']),Path(config['indices']),Path(config['uv']),out/'actual-world-mapped-positions.bin']},'leases':{'local':localToken,'main':mainToken}},indent=2)+'\n')
print('Position source frozen, 135 Y components differ by one ULP; UV exact; previous UV unit sealed')
