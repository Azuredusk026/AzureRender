from pathlib import Path
import sys,zipfile,json,subprocess,io
out=Path(__file__).parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
with s.maintenance.database(root/'build') as db:
 for name,row in s.maintenance.rows(db).items():
  if row.get('externalConsumer')==str(out):print('LOCAL LEASE',name)
data=subprocess.check_output(['git','show','HEAD:Project/AzureRender/docs/acceptance/nr/evidence/2026-11-08/screen-object-visibility/validation.zip'],cwd=root)
with zipfile.ZipFile(io.BytesIO(data)) as z:
 print([n for n in z.namelist() if any(v in n for v in ['queries','expected','manifest'])])
