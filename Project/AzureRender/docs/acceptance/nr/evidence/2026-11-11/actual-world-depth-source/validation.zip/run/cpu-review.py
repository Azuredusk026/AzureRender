from pathlib import Path
import numpy as np,json,hashlib
out=Path(__file__).parent;config=json.loads((out/'candidate-config.json').read_text());native=np.fromfile(out.parent/'20261110-110844-hair-postvs-clip-source-03c2f0/native-vertex.bin',dtype='<f4').reshape(-1,33);actual=np.fromfile(config['positions'],dtype='<f4').reshape(-1,4);profile=np.fromfile(config['profile'],dtype='<f4').reshape(5,4)
def project(world):
 q=world[:,1,None]*profile[1]
 q=(world[:,0,None].astype('f8')*profile[0]+q.astype('f8')).astype('f4')
 q=(world[:,2,None].astype('f8')*profile[2]+q.astype('f8')).astype('f4')
 q+=profile[3];j=q[:,3,None]*profile[4,:2];q[:,:2]=((-j).astype('f8')*[2,-2]+q[:,:2].astype('f8')).astype('f4');return q
baseline=project(native[:,6:9]);assert np.array_equal(baseline.view('u4'),native[:,:4].copy().view('u4'))
clip=project(actual[:,:3]);snap=lambda c:np.rint((c[:,:2]/c[:,3,None]+1)*[1280,720]*256).astype('i8')
nv=np.fromfile(out.parent/'20261110-211719-alpha-ellipse-lod-5c69d6/nvidia-public-rg8.bin',dtype='u1').reshape(-1,2)[:,1];expected=np.fromfile(out/'expected.bin',dtype='<u4');assert np.array_equal(nv,expected)
result={'scope':'CPU source review only; actual GPU outputs retain acceptance authority','nativeProjectionControlExactComponents':int(baseline.size),'mappedProjectionExactComponents':np.sum(clip.view('u4')==baseline.view('u4'),axis=0).tolist(),'clipMaximumAbsoluteDifference':np.max(abs(clip.astype('f8')-baseline),axis=0).tolist(),'changedEightBitSnappedVertices':int(np.any(snap(clip)!=snap(baseline),axis=1).sum()),'restoredExpectedMatchesQualifiedNvidiaVisibility':17017,'sourceProfileSha256':hashlib.sha256(Path(config['profile']).read_bytes()).hexdigest()}
(out/'cpu-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
