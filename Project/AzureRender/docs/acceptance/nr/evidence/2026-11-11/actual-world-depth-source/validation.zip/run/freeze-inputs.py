from pathlib import Path
import json,hashlib,numpy as np
out=Path(__file__).parent;root=out.parents[2];runs=root/'build/runs';public=runs/'20261110-211719-alpha-ellipse-lod-5c69d6';build=runs/'20261110-030251-hair-main-chroma-public-9e799c/release';calibration=runs/'20261110-003435-visibility-numeric-contract-4f95e7';config=json.loads((out/'candidate-config.json').read_text());visibility=json.loads((calibration/'hair-calibration.json').read_text())
paths=[Path(config[n]) for n in ['positions','indices','profile','uv','queries']]+list(map(Path,config['mips']))+[out/'expected.bin',public/'native-coverage.exe',calibration/'calibration.exe',calibration/'oracle.spv']
paths+=[Path(visibility[n]) for n in ['normals','atlas','profile']]
paths+=[build/'shaders'/n for n in ['reference_depth.vert.spv','reference_depth.frag.spv','reference_depth_masked.vert.spv','reference_depth_masked.frag.spv','reference_depth_ellipse.frag.spv']]
paths+=[public/(d+'-public-rg8.bin') for d in ['nvidia','intel']]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in paths:assert p.is_file(),p
nativeIndices=np.fromfile(runs/'20261110-110844-hair-postvs-clip-source-03c2f0/native-index.bin',dtype='<u2').reshape(-1,3);actualIndices=np.fromfile(runs/'20261110-110844-hair-postvs-clip-source-03c2f0/vulkan-index.bin',dtype='<u4').reshape(-1,3);assert np.array_equal(nativeIndices[:,::-1],actualIndices)
frozen={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths};(out/'frozen-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n');print(len(frozen),'immutable inputs frozen, indexed geometry ordering verified')
