from pathlib import Path
import json,hashlib,zipfile,numpy as np,re
out=Path(__file__).parent;root=out.parents[2];public=out.parent/'20261110-211719-alpha-ellipse-lod-5c69d6';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,metadata in json.loads((out/'frozen-inputs.json').read_text()).items():assert sha(Path(name))==metadata['sha256'],name
result=json.loads((out/'results.json').read_text());assert len(result['devices'])==2
for row in result['devices']:
 device=row['device'];selected=np.fromfile(out/(device+'-actual-selected-r32.bin'),dtype='<f4');baseline=np.fromfile(public/(device+'-public-selected-r32.bin'),dtype='<f4');delta=np.abs(selected.view('u4').astype('i8')-baseline.view('u4').astype('i8'))
 row.update(depthEqualToNativeGeometry=int((delta==0).sum()),depthWithinOneUlpOfNativeGeometry=int((delta<=1).sum()),maximumDepthUlpFromNativeGeometry=int(delta.max()))
assert json.loads((out/'execution.json').read_text())['exitCode']==0
result.update(sourceCommit='529f603',documentationCommit='2f1d390',productionChanged=False,acceptanceMaximumByteError=1,geometrySource='Actual Vulkan VSOut world positions, explicit source-frame mapping; native alpha UV held constant',cpuReview=json.loads((out/'cpu-review.json').read_text()),inputRecovery=json.loads((out/'input-recovery.json').read_text()),inputs=json.loads((out/'frozen-inputs.json').read_text()))
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
dest=root/'docs/acceptance/nr/evidence/2026-11-11/actual-world-depth-source';dest.mkdir(parents=True,exist_ok=True)
files={'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log','.bin'}}
files['docs/actual-world-depth-source.md']=root/'docs/acceptance/nr/actual-world-depth-source.md'
for name in ['native-coverage.cpp','native-synthetic.cpp','private-compute-fixture.hpp','public-native-build-commands.json']:files['fixture/'+name]=public/name
capture=out.parent/'20261110-110844-hair-postvs-clip-source-03c2f0'
for name in ['native-vertex.bin','vulkan-vertex.bin','native-index.bin','vulkan-index.bin']:files['source-capture/'+name]=capture/name
for name in ['profile','uv','indices']:files['inputs/'+name+'.bin']=Path(json.loads((out/'candidate-config.json').read_text())[name])
for device in ['nvidia','intel']:
 for suffix in ['-public-selected-r32.bin','-public-rg8.bin']:files['baseline/'+device+suffix]=public/(device+suffix)
members={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()};archive=dest/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']={'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members)+1};(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'devices':[{k:v for k,v in row.items() if k not in ['result','failurePixels']} for row in result['devices']],'archive':result['archive']},indent=2))
