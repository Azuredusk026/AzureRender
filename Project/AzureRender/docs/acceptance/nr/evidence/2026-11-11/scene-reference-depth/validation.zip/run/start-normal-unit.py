from datetime import date
from pathlib import Path
import json
import shutil
import subprocess
import sys
import time


out = Path(__file__).resolve().parent
root = out.parents[2]
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


claim_path = Path('D:/Projects/FYP-coordination/quality-claim.json')
claim = json.loads(claim_path.read_text(encoding='utf-8'))
owner = claim['threadId']
assert owner == '01a1c099-8121-7be3-b0b8-7af2f9a06b2a' and Path(claim['taskPath']) == out
commit = subprocess.check_output(['git', 'rev-parse', '--short', 'HEAD'], cwd=root, text=True).strip()
assert commit == sys.argv[1]
result = json.loads((root / 'docs/acceptance/nr/evidence/2026-11-11/scene-reference-depth/results.json').read_text())
assert result['originalFour']['allExact'] and result['status'] == 'qualified-scene-reference-depth-producer'

budget = 512 * 1024 * 1024
next_run = Path(subprocess.check_output([sys.executable, str(root / 'tools/artifact_cleanup.py'),
    '--new-run', 'scene-reference-normal', '--planned-bytes', str(budget)], cwd=root, text=True).strip()).resolve(strict=True)
assert next_run.parent == out.parent
prep = out / 'next-input-prep'
for name in ('normal-source.py', 'normal-source-worker.py', 'inspect-normal-inputs.py', 'inspect-normal-vertices.py',
        'normal-source-inspection.json', 'normal-vertex-comparison.json'):
    shutil.copyfile(prep / name, next_run / name)
plan = Path('docs/plans') / (date.today().isoformat() + '-scene-reference-normal.md')
assert not (root / plan).exists()
shutil.copyfile(prep / 'plan.md', root / plan)
main_inputs = ['20261022-201845-endfield-capture-954719', '20261103-234012-character-reference-stages-5abe6c',
    '20261027-022702-object-visibility-depth-reconstruction-c7312f']
local_inputs = [out.name, '20261111-210839-native-d3d11-depth-devices-9e7a22',
    '20261111-072757-material-ellipse-coverage-policy-3e26b6', '20261110-112309-hair-relative-projection-control-b9da17',
    '20261110-030251-hair-main-chroma-public-9e799c', '20261110-031856-hair-main-chroma-debug-668bf2']
main_token = shared.acquire_inputs(shared.DEFAULT_BUILD, next_run, main_inputs, owner)
try:
    local_token = shared.acquire_inputs(root / 'build', next_run, local_inputs, owner)
except Exception:
    shared.release_inputs(shared.DEFAULT_BUILD, main_token, owner)
    raise
new_claim = dict(claim, state='scene-reference-normal-source', lastCommit=commit, taskPath=str(next_run),
    inputLease=[main_token], localInputLease=[local_token], nativeCaptureLease=main_token,
    ownedFiles=[plan.as_posix()], pendingCommand='Read the native packed-normal producer and texture mips in D3D11 replay')
temporary = claim_path.with_suffix('.update.json')
temporary.write_text(json.dumps(new_claim, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
temporary.replace(claim_path)
for token in claim.get('inputLease', []):
    shared.release_inputs(shared.DEFAULT_BUILD, token, owner)
for token in claim.get('localInputLease', []):
    shared.release_inputs(root / 'build', token, owner)
shared.maintenance.seal(root / 'build', out)
(next_run / 'task-card.json').write_text(json.dumps(dict(baseCommit=commit, created=time.time(),
    plannedBytes=budget, frozenHairMaskPixels=17017, frozenReceiverMaskPixels=49384,
    unchangedDefaultFrames=4, deliverable='Live packed normals and object IDs matching the scene reference depth'), indent=2) + '\n')
print(next_run)
