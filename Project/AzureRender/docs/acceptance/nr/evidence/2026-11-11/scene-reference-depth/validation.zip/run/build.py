from pathlib import Path
import subprocess,json,sys
out=Path(__file__).resolve().parent;root=out.parents[2];main=Path('D:/Projects/FYP/Project/AzureRender')
configuration=sys.argv[1];build=root/'build/runs'/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
cmake='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
tests_only='--tests-only' in sys.argv
prefix=configuration.lower()+('-tests-rebuild' if tests_only else '')
preflight=[sys.executable,str(root/'tools/artifact_budget.py'),'--build',str(root/'build'),'--run',str(build.parent),'--planned-bytes',str(33554432 if configuration=='Debug' or tests_only else 134217728)]
pre=subprocess.run(preflight,capture_output=True,text=True);(out/(prefix+'-internal-preflight.log')).write_text(pre.stdout+pre.stderr)
if pre.returncode:raise SystemExit(pre.returncode)
targets=['AzureReferenceCameraViewTests','AzureProjectReferenceViewsTests','AzureRenderExtensionRegistryTests','AzureReferenceCameraBindingTests','AzurePlayer']
if configuration=='Release':targets+=['AzureReferenceDepthGpuTests','AzureReferenceDepthCoverageGpuTests','AzureRender','AzureGameLauncher']
commands=[[cmake,'-S',str(root),'-B',str(build)]]
if tests_only:
 targets=['AzureReferenceCameraViewTests','AzureRenderExtensionRegistryTests']
 commands.clear()
commands.append([cmake,'--build',str(build),'--target',*targets,'--parallel','4'])
(out/(prefix+'-build-commands.json')).write_text(json.dumps(commands,indent=2))
with (out/(prefix+'-build.log')).open('wb') as log:
 for args in commands:
  result=subprocess.run(subprocess.list2cmdline([str(main/'tools/msvc_env.bat')]+args),cwd=root,shell=True,stdout=log,stderr=subprocess.STDOUT)
  if result.returncode:raise SystemExit(result.returncode)
print(configuration+' scene reference depth targets built')

