from pathlib import Path
import hashlib
import json
import subprocess
import zipfile


out = Path(__file__).resolve().parent
root = out.parents[2]
target = root / 'docs/acceptance/nr/evidence/2026-11-11/scene-reference-depth'


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def success(name):
    result = load(out / (name + '-execution.json'))
    assert result['status'] == 'exited' and result['exitCode'] == 0, (name, result)
    return result


labels = ['release-nvidia-indexed-qualified', 'release-intel-fixed-qualified',
    'debug-nvidia-fixed-qualified', 'debug-intel-fixed-qualified']
captures = {label: load(out / (label + '-results.json')) for label in labels}
for label, result in captures.items():
    assert result['capture']['rowOrigin'] == 'bottom-left' and result['capture']['submission'] == 3
    assert result['hardwareAgreement']['exact'] == 3686400 and result['validationClean'] and result['allocatorZero']
    assert result['againstFrozen']['clearMismatches'] == 0
    assert all(frame['priorPixelDifferences'] == 0 for frame in result['frames']), label
    if 'nvidia' in label:
        assert result['againstFrozen']['exact'] == 17017, label
for device in ('intel', 'nvidia'):
    release = next(result for result in captures.values() if result['configuration'] == 'Release' and result['device'] == device)
    debug = next(result for result in captures.values() if result['configuration'] == 'Debug' and result['device'] == device)
    assert release['rasterSha256'] == debug['rasterSha256'], device
    assert [frame['sha256'] for frame in release['frames']] == [frame['sha256'] for frame in debug['frames']], device

first = load(out / 'release-nvidia-fixed-results.json')
origin = load(out / 'release-nvidia-fixed-origin-results.json')
assert first['againstFrozen']['exact'] == 16146 and origin['againstFrozen']['exact'] == 17017
builds = {config: load(out / (config.lower() + '-verification.json')) for config in ('Release', 'Debug')}
assert builds['Release']['sha256'] == builds['Debug']['sha256']
for result in builds.values():
    assert result['count'] == 887 and result['unchanged'] == 879 and result['ctestExit'] == 0
ordinary = load(out / 'release-nvidia-fixed-ordinary-results.json')
assert ordinary['depthCaptureAbsent']
clip = load(out / 'reference-clip-control/summary.json')
assert clip['referenceDepthExact']
duplicate_receipt = load(out / 'duplicate-depth-receipt.json')
assert duplicate_receipt['status'] == 'compacted'
for item in duplicate_receipt['representations']:
    assert digest(Path(item['retained'])) == item['sha256']
default = load(out / 'default-four-results.json')
assert default['allExact']
receipts = {name: success(name) for name in [*labels, 'release-nvidia-fixed', 'release-nvidia-fixed-origin',
    'release-qualified-build', 'debug-final-build', 'release-nvidia-fixed-ordinary', 'clip-control', 'default-four', 'release-depth-gpu']}

target.mkdir(parents=True, exist_ok=True)
tracked = subprocess.check_output(['git', 'diff', '--relative', '--name-only'], cwd=root, text=True).splitlines()
new_sources = ['shaders/reference_scene_depth.frag', 'src/render/SceneReferenceDepthTargets.hpp',
    'src/scenes/CharacterReferenceSceneDepth.inc']
source_files = sorted(name for name in set(tracked + new_sources) if name == 'CMakeLists.txt' or
    name.startswith(('src/', 'shaders/', 'tests/')))
source_sha256 = {name: digest(root / name) for name in source_files}
(out / 'source-fingerprints.json').write_text(json.dumps(source_sha256, indent=2) + '\n')
members = {}
for path in out.iterdir():
    if path.is_file() and path.suffix in {'.py', '.ps1', '.json', '.log', '.xml', '.npy'}:
        members['run/' + path.name] = path
for label in [*labels, 'release-nvidia-fixed', 'release-nvidia-fixed-origin', 'release-nvidia-fixed-ordinary', 'default-four']:
    for name in ('capture_manifest.json', 'gpu_capabilities.json'):
        path = out / (label + '-frames') / name
        if path.is_file():
            members['run/' + label + '/' + name] = path
for label in ('release-nvidia-indexed-qualified', 'release-intel-fixed-qualified', 'release-nvidia-fixed'):
    path = out / (label + '-frames') / 'reference-depth-r32.bin'
    members['run/' + label + '/reference-depth-r32.bin'] = path
for path in (out / 'reference-clip-control').glob('*'):
    if path.is_file() and path.suffix in {'.json', '.log', '.azurelevel', '.azureproject'}:
        members['run/reference-clip-control/' + path.name] = path
docs = ['docs/acceptance/nr/scene-reference-depth.md', 'docs/plans/2026-11-11-scene-reference-depth.md',
    'docs/runtime/scene-reference-depth.md']
for path in docs:
    members['source/' + path] = root / path
hashes = {name: dict(bytes=path.stat().st_size, sha256=digest(path)) for name, path in members.items()}
archive = target / 'validation.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, 9) as file:
    for name, path in sorted(members.items()):
        file.write(path, name)
    file.writestr('manifest.json', json.dumps(hashes, indent=2) + '\n')
with zipfile.ZipFile(archive) as file:
    assert file.testzip() is None
    for name, entry in hashes.items():
        assert hashlib.sha256(file.read(name)).hexdigest() == entry['sha256']
assert archive.stat().st_size <= 8 * 1024 * 1024
result = dict(status='qualified-scene-reference-depth-producer', overall='failed-user-review', baseCommit='1588c84',
    sceneRendererApiVersion=11, acceptedFrozenMaximumColorError=1, frozenHairMaskPixels=17017,
    orientationControl=dict(regularSceneRows=first['againstFrozen'], nativeRows=origin['againstFrozen']),
    captures=captures, builds={key: {k: v for k, v in entry.items() if k != 'sha256'} for key, entry in builds.items()},
    ordinaryCamera=ordinary, referenceClipControl=clip, originalFour=default, receipts=receipts,
    duplicateDepthPlanes=duplicate_receipt,
    sourceSha256=source_sha256,
    archive=dict(bytes=archive.stat().st_size, sha256=digest(archive), members=len(members) + 1))
(target / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result['archive']))
