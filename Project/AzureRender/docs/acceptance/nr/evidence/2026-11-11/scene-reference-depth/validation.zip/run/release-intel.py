from pathlib import Path
import json
import os
import shutil
import sys
import time


out = Path(__file__).resolve().parent
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def run(run_name, receipt, script, *args):
    result = shared.maintenance.guarded_run(out.parents[1], run_name,
        [sys.executable, str(out / script), *args], 900)
    (out / receipt).write_text(json.dumps(result, indent=2) + '\n')
    assert result['status'] == 'exited' and result['exitCode'] == 0, result


for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES', 'VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key, None)
os.environ.update(VK_LOADER_DRIVERS_SELECT='*igvk64*', VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',
    VK_LAYER_VALIDATE_SYNC='1')
token = sys.argv[1]
deadline = time.monotonic() + 1800
queue_status = shared.DEFAULT_QUEUE / 'current.json'
while time.monotonic() < deadline:
    try:
        status = json.loads(queue_status.read_text())
    except (OSError, ValueError):
        time.sleep(1)
        continue
    if status.get('state') == 'released' or status.get('token') != token:
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed queue group has not retired')

parent = '20261110-030251-hair-main-chroma-public-9e799c'
with shared.lease(shared.DEFAULT_QUEUE, '01a1c099-8121-7be3-b0b8-7af2f9a06b2a', 'quality-reference-depth-release-intel', out):
    for name in ('release-build.log', 'release-orientation-build-execution.json'):
        archive=out / ('orientation-' + name)
        if not archive.is_file():
            shutil.copyfile(out / name, archive)
    shared.maintenance.resume(out.parents[1], parent)
    run(parent, 'release-qualified-build-execution.json', 'build.py', 'Release')
    run(out.name, 'release-intel-fixed-qualified-execution.json', 'scene-capture.py', 'Release', 'intel', 'fixed', '--tag=qualified', '--slot-reuse')
print('Release build and Intel Player readback exited normally')
