from pathlib import Path
import json
import re


out = Path(__file__).resolve().parent
root = out.parents[2]
documents = ['docs/acceptance/nr/scene-reference-depth.md', 'docs/plans/2026-11-11-scene-reference-depth.md',
    'docs/runtime/scene-reference-depth.md', 'docs/runtime/project-reference-views.md',
    'docs/runtime/reference-camera-render-binding.md']
for name in documents:
    path = root / name
    text = path.read_text(encoding='utf-8')
    for sentence in re.split('[。！？\n]', text):
        assert len(re.findall('[\u4e00-\u9fff]', sentence)) <= 45, (name, sentence)
    for paragraph in text.split('\n\n'):
        if not paragraph.startswith('- '):
            assert paragraph.count('。') <= 4, (name, paragraph)
    for link in re.findall(r'\]\(([^)]+)\)', text):
        if not link.startswith('https:'):
            assert (path.parent / link.split('#')[0]).exists(), (name, link)
manifest = json.loads((root / 'docs/development/artifact-manifest.json').read_text(encoding='utf-8'))
row = next(item for item in manifest['milestones'] if item['path'] == 'runs/' + out.name)
assert row['sourceBase'] == '1588c84'
assert (root / row['evidence']).is_file() and (root / row['results']).is_file()
assert (root / 'build' / row['path']).is_dir()
print('Scene reference depth documentation, local links, and artifact index passed')
