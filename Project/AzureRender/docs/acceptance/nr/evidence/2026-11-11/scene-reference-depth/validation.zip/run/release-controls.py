from pathlib import Path
import json
import subprocess
import sys
import time


out = Path(__file__).resolve().parent
cases = [
    ('release-nvidia-indexed-qualified', 'scene-capture.py', 'Release', 'nvidia', 'indexed', '--tag=qualified', '--slot-reuse'),
    ('release-nvidia-fixed-ordinary', 'scene-capture.py', 'Release', 'nvidia', 'fixed', '--ordinary'),
    ('clip-control', 'clip-control.py'),
    ('release-depth-gpu', 'verify-build.py', 'Release', '--gpu'),
]
names = set(sys.argv[1:])
if '--debug' in names:
    names.remove('--debug')
    cases = [('debug-' + device + '-fixed-qualified', 'scene-capture.py', 'Debug', device, 'fixed',
        '--tag=qualified', '--slot-reuse') for device in ('nvidia', 'intel')]
assert not names - {name for name, *_ in cases}
receipts = []
for name, script, *args in cases:
    if names and name not in names:
        continue
    command = [sys.executable, str(out / script), *args]
    started = time.monotonic()
    with (out / (name + '-process.log')).open('wb') as log:
        try:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=420)
            exit_code, status = result.returncode, 'exited'
        except subprocess.TimeoutExpired:
            exit_code, status = None, 'timed-out'
    receipt = dict(name=name, command=command, exitCode=exit_code, status=status, seconds=time.monotonic() - started)
    (out / (name + '-execution.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    receipts.append(receipt)
    print(json.dumps(receipt), flush=True)
assert all(row['status'] == 'exited' and row['exitCode'] == 0 for row in receipts)
