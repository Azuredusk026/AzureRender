from pathlib import Path
import json,sys,time

out=Path(__file__).resolve().parent
root=out.parents[2]
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared

claim_path=Path('D:/Projects/FYP-coordination/quality-claim.json')
claim=json.loads(claim_path.read_text(encoding='utf-8'))
owner=claim['threadId']
assert owner=='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
previous=out.parent/'20261111-210839-native-d3d11-depth-devices-9e7a22'
assert Path(claim['taskPath'])==previous
main_inputs=['20261022-201845-endfield-capture-954719','20261103-234012-character-reference-stages-5abe6c',
    '20261027-022702-object-visibility-depth-reconstruction-c7312f']
local_inputs=[previous.name,'20261111-072757-material-ellipse-coverage-policy-3e26b6',
    '20261110-112309-hair-relative-projection-control-b9da17','20261111-053153-reference-camera-render-binding-c3826b',
    '20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2']
main_lease=shared.acquire_inputs(shared.DEFAULT_BUILD,out,main_inputs,owner)
local_lease=shared.acquire_inputs(root/'build',out,local_inputs,owner)
claim.update(state='scene-reference-depth',lastCommit='1588c84',taskPath=str(out),inputLease=[main_lease],
    localInputLease=[local_lease],nativeCaptureLease=main_lease,
    ownedFiles=['tests/ReferenceCameraViewTests.cpp','docs/plans/2026-11-11-scene-reference-depth.md'],
    pendingCommand='Observe missing scene-depth view field failure before applying production implementation')
for token in json.loads(claim_path.read_text(encoding='utf-8')).get('inputLease',[]):
    shared.release_inputs(shared.DEFAULT_BUILD,token,owner)
for token in json.loads(claim_path.read_text(encoding='utf-8')).get('localInputLease',[]):
    shared.release_inputs(root/'build',token,owner)
claim_path.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'task-card.json').write_text(json.dumps(dict(baseCommit='1588c84',created=time.time(),locationSeconds=600,
    candidateSeconds=1200,buildSeconds=1800,gpuSeconds=1200,plannedBytes=536870912,
    deliverable='Opt-in scene reference depth attachment drawn with actual Player meshes, uniforms and coverage',
    frozenMaskPixels=17017,unchangedDefaultFrames=4),indent=2)+'\n')
shared.maintenance.seal(root/'build',previous)
print('Scene fixture and sealed replay source leased')
