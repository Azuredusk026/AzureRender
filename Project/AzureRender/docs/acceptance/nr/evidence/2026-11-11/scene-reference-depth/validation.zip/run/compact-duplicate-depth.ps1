$ErrorActionPreference = 'Stop'
$run = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$labels = @('release-nvidia-fixed', 'release-nvidia-fixed-origin')
$entries = foreach ($label in $labels) {
    $folder = (Resolve-Path -LiteralPath (Join-Path $run ($label + '-frames'))).Path
    if ((Split-Path -Parent $folder) -ne $run) { throw 'Unexpected depth capture directory' }
    $raster = Get-Item -LiteralPath (Join-Path $folder 'reference-depth-r32.bin')
    $hardware = Get-Item -LiteralPath (Join-Path $folder 'reference-depth-d32.bin')
    if ($raster.DirectoryName -ne $folder -or $hardware.DirectoryName -ne $folder -or
        $raster.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint) -or
        $hardware.Attributes.HasFlag([IO.FileAttributes]::ReparsePoint)) { throw 'Depth plane path is outside its capture' }
    $record = Get-Content -LiteralPath (Join-Path $run ($label + '-results.json')) -Raw | ConvertFrom-Json
    $rasterHash = (Get-FileHash -LiteralPath $raster.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    $hardwareHash = (Get-FileHash -LiteralPath $hardware.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($rasterHash -ne $hardwareHash -or $rasterHash -ne $record.rasterSha256 -or
        $hardwareHash -ne $record.hardwareSha256 -or $raster.Length -ne $hardware.Length -or
        $raster.Length -ne 14745600 -or $record.hardwareAgreement.exact -ne 3686400) {
        throw 'Independent attachment verification did not prove a duplicate'
    }
    [ordered]@{capture=$label; retained=$raster.FullName; duplicate=$hardware.FullName;
        bytes=$hardware.Length; sha256=$hardwareHash}
}
$receiptPath = Join-Path $run 'duplicate-depth-receipt.json'
$receipt = [ordered]@{status='verified'; representations=@($entries)}
[IO.File]::WriteAllText($receiptPath, ($receipt | ConvertTo-Json -Depth 4))
foreach ($entry in $entries) { Remove-Item -LiteralPath $entry.duplicate }
$receipt.status = 'compacted'
[IO.File]::WriteAllText($receiptPath, ($receipt | ConvertTo-Json -Depth 4))
$receipt | ConvertTo-Json -Depth 4
