from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
sys.path.insert(0, str(out.parents[2] / 'tools'))
from test_material_coverage_mips_gpu import prepare


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


folder = out / 'reference-clip-control'
reuse = '--reuse-positive' in sys.argv
if reuse:
    project = folder / 'lab.azureproject'
    extent = json.loads((folder / 'visible/capture_manifest.json').read_text())['referenceSceneDepth']['width']
else:
    project, extent, _, _ = prepare(folder, 'slant', 4, False)
scene_path = folder / 'level.azurelevel'
base_scene = json.loads(scene_path.read_text())
assert any(node['id'] == 'camera' for node in base_scene['nodes'])
base_scene['renderSettings']['outlinePixels'] = 0
asset_path = folder / 'plane.gltf'
asset = json.loads(asset_path.read_text())
for material in asset['materials']:
    material['alphaMode'] = 'OPAQUE'
write(asset_path, asset)
config = folder / 'config'
config.mkdir(exist_ok=True)
write(config / 'reference-views.json', dict(schemaVersion=1, views={'clip': dict(schemaVersion=1,
    extent=[extent, extent], depthConvention='reversed', flipNdcY=False, produceSceneDepth=True,
    frame=dict(schemaVersion=1, axes=[1, 2, 3], offset=[0, 0, 0]),
    projection=dict(schemaVersion=1, columns=[[2/extent,0,0,0],[0,-2/extent,0,0],[0,0,.125,0],[0,0,.5,1]], jitter=[0,0]))}))
build = out.parent / '20261110-030251-hair-main-chroma-public-9e799c/release'
planes, images, rows = {}, {}, {}
for name, distance in (('visible', 20), ('device-clipped', 1)):
    scene = json.loads(json.dumps(base_scene))
    camera = next(node for node in scene['nodes'] if node['id'] == 'camera')['components']
    anchor = camera['azure.transform']['data']['translation']
    assert anchor == [0, 0, 5]
    camera['azure.camera']['version'] = 2
    camera['azure.camera']['data']['farPlane'] = distance
    camera['azure.reference-camera'] = dict(type='azure.reference-camera', version=1, data=dict(enabled=True,
        view='clip', anchorPosition=anchor, anchorRight=[1,0,0], anchorUp=[0,1,0], anchorBack=[0,0,1]))
    write(scene_path, scene)
    frames = folder / name
    command = [str(build / 'AzurePlayer.exe'), '--project', str(project), '--width', str(extent), '--height', str(extent),
        '--capture-dir', str(frames), '--capture-frames', '1', '--fixed-frame-step', '--qa-camera', 'scene',
        '--qa-light', 'scene', '--qa-isolation', 'albedo', '--disable-bindless', '--disable-compute-skinning',
        '--disable-parallel-recording', '--resource-root', str(build)]
    write(folder / (name + '-command.json'), command)
    log_path = folder / (name + '.log')
    if not reuse:
        with log_path.open('wb') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        assert result.returncode == 0, log_path
    text = log_path.read_text(errors='replace')
    assert 'Allocator after unload: buffers=0 images=0' in text, text[-5000:]
    assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]', text), text[-5000:]
    manifest = json.loads((frames / 'capture_manifest.json').read_text())
    depth = manifest['referenceSceneDepth']
    assert manifest['referenceCameraEnabled'] and depth['rowOrigin'] == 'bottom-left' and depth['submission'] == 1
    assert not manifest['referenceCameraConservativeRetention']
    raster = (frames / depth['raster']).read_bytes()
    hardware = (frames / depth['hardware']).read_bytes()
    assert raster == hardware and len(raster) == 4 * extent * extent
    planes[name] = np.frombuffer(raster, dtype='<f4')
    images[name] = np.asarray(Image.open(frames / 'frame_000000.png').convert('RGB'))
    rows[name] = dict(farPlane=distance, depthSha256=hashlib.sha256(raster).hexdigest(),
        nonzero=int(np.count_nonzero(planes[name])))

color_changed = int(np.count_nonzero(np.any(images['visible'] != images['device-clipped'], axis=2)))
assert rows['visible']['nonzero'] > 0 and color_changed > 0
assert np.array_equal(planes['visible'], planes['device-clipped']), rows
assert np.all(planes['visible'][planes['visible'] != 0] == .5)
camera['azure.camera']['data']['farPlane'] = 20
scene['renderSettings']['schemaVersion'] = 19
scene['renderSettings']['antiAliasing'] = 4
write(scene_path, scene)
rejected_command = list(command)
rejected_command[rejected_command.index('--capture-dir') + 1] = str(folder / 'multisample-rejection')
write(folder / 'multisample-command.json', rejected_command)
with (folder / 'multisample.log').open('wb') as log:
    rejected = subprocess.run(rejected_command, stdout=log, stderr=subprocess.STDOUT, timeout=180)
diagnostics = (folder / 'multisample.log').read_text(errors='replace')
assert rejected.returncode != 0 and 'Scene reference depth requires prepared single-sample spatial attachments' in diagnostics, diagnostics[-5000:]
assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)', diagnostics), diagnostics[-5000:]
report = dict(extent=extent, controls=rows, deviceColorDifferences=color_changed,
    referenceDepthExact=True, hardwareAgreement=True, multisamplingRejected=True, validationClean=True, allocatorZero=True)
write(folder / 'summary.json', report)
print(json.dumps(report))
