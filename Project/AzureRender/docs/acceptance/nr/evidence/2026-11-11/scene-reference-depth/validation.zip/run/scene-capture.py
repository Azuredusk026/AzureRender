from pathlib import Path
import hashlib
import json
import os
import re
import runpy
import subprocess
import sys
import zipfile

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
root = out.parents[2]
config, device, binding, *options = sys.argv[1:]
assert config in ('Release', 'Debug') and device in ('nvidia', 'intel') and binding in ('fixed', 'indexed')
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if config == 'Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
ordinary = '--ordinary' in options
capture_count = 3 if '--slot-reuse' in options else 2
label = f'{config.lower()}-{device}-{binding}' + ('-ordinary' if ordinary else '')
tag = next((option.split('=', 1)[1] for option in options if option.startswith('--tag=')), None)
if tag:
    label += '-' + tag
frames = out / (label + '-frames')
previous = out.parent / '20261111-072757-material-ellipse-coverage-policy-3e26b6'
native = out.parent / '20261111-210839-native-d3d11-depth-devices-9e7a22'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def compare(actual, expected):
    ulp = np.abs(actual.astype('i8') - expected.astype('i8'))
    return dict(exact=int(np.count_nonzero(ulp == 0)), withinOne=int(np.count_nonzero(ulp <= 1)),
        maximumUlp=int(ulp.max()), clearMismatches=int(np.count_nonzero((actual == 0) != (expected == 0))))


def plane(data):
    assert len(data) == 2560 * 1440 * 4
    return np.frombuffer(data, dtype='<u4').reshape(1440, 2560)


for row in json.loads((out / 'hair-copy-inputs.json').read_text()):
    assert digest(Path(row['destination']).read_bytes()) == row['sha256'], row
if '--reuse' not in options:
    project = 'hair-ordinary.azureproject' if ordinary else 'hair-coverage.azureproject'
    width, height = ('320', '180') if ordinary else ('2560', '1440')
    command = [str(build / 'AzurePlayer.exe'), '--project', str(out / 'hair-project' / project),
        '--width', width, '--height', height, '--capture-dir', str(frames), '--capture-frames', str(capture_count),
        '--fixed-frame-step', '--qa-camera', 'scene', '--qa-light', 'scene', '--qa-isolation', 'beauty',
        '--disable-compute-skinning', '--disable-parallel-recording', '--runtime-report', str(out / (label + '-runtime.json')),
        '--resource-root', str(build)]
    if binding == 'fixed':
        command.append('--disable-bindless')
    (out / (label + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
    env = os.environ.copy()
    for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES', 'VK_LOADER_DRIVERS_SELECT'):
        env.pop(key, None)
    env.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*' if device == 'nvidia' else '*igvk64*',
        VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LAYER_VALIDATE_SYNC='1')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=420)
    assert result.returncode == 0, (label, result.returncode)

log = (out / (label + '.log')).read_text(errors='replace')
assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]', log, re.I), log[-10000:]
assert 'Allocator after unload: buffers=0 images=0' in log, log[-4000:]
assert 'Character texture access: ' + binding + ',' in log, log[-4000:]
manifest = json.loads((frames / 'capture_manifest.json').read_text())
if ordinary:
    assert manifest['referenceCameraPrograms'] and not manifest['referenceCameraEnabled']
    assert 'referenceSceneDepth' not in manifest and not list(frames.glob('reference-depth-*.bin'))
    (out / (label + '-results.json')).write_text(json.dumps(dict(referenceProgramsPrepared=True,
        referenceCameraEnabled=False, depthCaptureAbsent=True, validationClean=True, allocatorZero=True), indent=2) + '\n')
    raise SystemExit(0)
capture = manifest['referenceSceneDepth']
assert manifest['referenceCameraEnabled'] and manifest['rasterizationSamples'] == 1
assert capture['width'] == 2560 and capture['height'] == 1440 and capture['submission'] == capture_count, capture
assert len(manifest['materialCoverageSources']) == 1
assert manifest['materialCoverageSources'][0]['lodPolicy'] == 'ellipse-major'
raster_bytes = (frames / capture['raster']).read_bytes()
hardware_path = frames / capture['hardware']
if '--reuse' in options and not hardware_path.is_file():
    receipt = json.loads((out / 'duplicate-depth-receipt.json').read_text())
    duplicate = next(row for row in receipt['representations'] if row['capture'] == label)
    assert receipt['status'] == 'compacted' and Path(duplicate['duplicate']) == hardware_path
    assert len(raster_bytes) == duplicate['bytes'] and digest(raster_bytes) == duplicate['sha256']
    hardware_bytes = raster_bytes
else:
    hardware_bytes = hardware_path.read_bytes()
raster, hardware = plane(raster_bytes), plane(hardware_bytes)

base = runpy.run_path(str(out.parent / '20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
ys, xs = np.nonzero(base['mask'])
x, ui_y = xs + 1140, ys + 130
native_y = 1439 - ui_y
assert len(x) == 17017
frozen = np.load(native / 'nvidia-replay/selected-depth.npy', allow_pickle=False)
same_native = np.load(native / (device + '-replay/selected-depth.npy'), allow_pickle=False)
with zipfile.ZipFile(root / 'docs/acceptance/nr/evidence/2026-11-11/actual-geometry-uv-source/validation.zip') as archive:
    prior = plane(archive.read('run/' + device + '-actual-r32.bin'))[native_y, x]
bottom_origin = capture.get('rowOrigin') == 'bottom-left'
row, alternate_row = (native_y, ui_y) if bottom_origin else (ui_y, native_y)
candidate = raster[row, x]
rows = []
for i in range(capture_count):
    name = f'frame_{i:06d}.png'
    photo = np.asarray(Image.open(frames / name).convert('RGB'))
    before = np.asarray(Image.open(previous / (config.lower() + '-' + device + '-hair-coverage-frames') / name).convert('RGB'))
    error = abs(photo[ui_y, x].astype('i4') - base['expected'][base['mask']])
    rows.append(dict(frame=i, sha256=digest((frames / name).read_bytes()),
        priorPixelDifferences=int(np.count_nonzero(np.any(photo != before, axis=2))),
        overOne=int(np.count_nonzero(error.max(axis=1) > 1)), maximumByteError=int(error.max())))
changed = np.flatnonzero(candidate != same_native)
strongest = sorted(changed, key=lambda i: abs(int(candidate[i]) - int(same_native[i])), reverse=True)[:30]
report = dict(configuration=config, device=device, binding=binding, capture=capture, frames=rows,
    rasterSha256=digest(raster_bytes), hardwareSha256=digest(hardware_bytes), validationClean=True, allocatorZero=True,
    nonzeroPixels=int(np.count_nonzero(raster)), hardwareAgreement=compare(raster, hardware),
    againstFrozen=compare(candidate, frozen), againstSameNative=compare(candidate, same_native),
    againstPriorVulkan=compare(candidate, prior), alternateOrientationAgainstNative=compare(raster[alternate_row, x], same_native),
    selectedProbes=[dict(pixel=[int(x[i]), int(ui_y[i])], raster=int(candidate[i]),
        sameDeviceNative=int(same_native[i]), priorVulkan=int(prior[i]), frozen=int(frozen[i])) for i in strongest])
(out / (label + '-results.json')).write_text(json.dumps(report, indent=2) + '\n')
np.save(out / (label + '-selected-depth.npy'), candidate)
print(json.dumps(report))
assert report['hardwareAgreement']['exact'] == raster.size
assert np.all(candidate != 0), report['againstFrozen']
