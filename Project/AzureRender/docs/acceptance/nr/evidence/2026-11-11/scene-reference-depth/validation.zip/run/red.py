from pathlib import Path
import json,subprocess,sys,time

out=Path(__file__).resolve().parent
root=out.parents[2]
main=Path('D:/Projects/FYP/Project/AzureRender')
sys.path.insert(0,str(main/'tools'))
import shared_resources as shared

dependencies=main/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'
command=[str(main/'tools/msvc_env.bat'),'cl','/nologo','/c','/std:c++17','/utf-8','/EHsc',
    '/I'+str(root/'src'),'/I'+str(dependencies),'/ID:/Tools/VulkanSDK/1.4.350.0/Include',
    str(root/'tests/ReferenceCameraViewTests.cpp'),'/Fo'+str(out/'reference-depth-red.obj')]
started=time.monotonic()
while True:
    lease=shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-scene-reference-depth-red',out)
    try:
        lease.__enter__()
        break
    except ValueError as error:
        if not any(part in str(error) for part in ('busy','still running')):
            raise
        if time.monotonic()-started>=180:
            raise TimeoutError('Scene depth compile queue wait ended before execution')
        time.sleep(1)
try:
    result=subprocess.run(subprocess.list2cmdline(command),cwd=out,shell=True,capture_output=True,text=True,timeout=50)
    output=result.stdout+result.stderr
    (out/'red.log').write_text(output)
    assert result.returncode!=0 and 'produceSceneDepth' in output and 'C2039' in output,output
    (out/'red-result.json').write_text(json.dumps(dict(baseCommit='1588c84',command=command,
        exitCode=result.returncode,expected='Missing typed scene depth output flag'),indent=2)+'\n')
    print('Expected missing scene depth output flag failure observed')
finally:
    lease.__exit__(None,None,None)
