from pathlib import Path
import hashlib,json,shutil

out=Path(__file__).resolve().parent
previous=out.parent/'20261111-072757-material-ellipse-coverage-policy-3e26b6'
source_root=previous/'hair-project'
target_root=out/'hair-project'
assert not target_root.exists()

def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file,'sha256').hexdigest()

source_rows=json.loads((previous/'hair-copy-inputs.json').read_text())
rows=[]
for item in source_rows:
    source=Path(item['destination'])
    relative=source.relative_to(source_root)
    assert sha(source)==item['sha256']
    target=target_root/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    assert sha(target)==item['sha256']
    rows.append(dict(source=str(source),destination=str(target),sha256=item['sha256'],bytes=target.stat().st_size))
assert sum(item['bytes'] for item in rows)<256*1024*1024
profile=target_root/'config/reference-views.json'
document=json.loads(profile.read_text(encoding='utf-8-sig'))
view=document['views']['native-hair']
assert view['depthConvention']=='reversed' and not view['flipNdcY'] and 'produceSceneDepth' not in view
view['produceSceneDepth']=True
profile.write_text(json.dumps(document,indent=2)+'\n',encoding='utf-8')
row=next(item for item in rows if Path(item['destination'])==profile)
row['inputSha256']=row['sha256']
row['sha256']=sha(profile)
row['bytes']=profile.stat().st_size
assert (target_root/'hair-coverage.azureproject').is_file()
(out/'hair-copy-inputs.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(dict(files=len(rows),bytes=sum(row['bytes'] for row in rows),profile=row)))
