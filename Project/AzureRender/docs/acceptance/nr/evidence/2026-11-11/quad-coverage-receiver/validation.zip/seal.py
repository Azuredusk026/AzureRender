from pathlib import Path
import json,zipfile,hashlib,sys
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
assert inputs(root)==json.loads((out/'source-lock.json').read_text())
assert all(digest(root/p)==h for p,h in json.loads((out/'protected-files.json').read_text()).items())
result=json.loads((out/'results.json').read_text());assert not result['qualified']
dest=root/'docs/acceptance/nr/evidence/2026-11-11/quad-coverage-receiver';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={};duplicates={}
paths=[p for p in out.rglob('*') if p.is_file() and not any(v in p.relative_to(out).parts for v in ['tmp','__pycache__'])]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    saved={}
    for p in sorted(paths):
        name=p.relative_to(out).as_posix();h=digest(p)
        if p.suffix=='.spv' and h in saved:duplicates[name]=saved[h];continue
        members[name]=dict(bytes=p.stat().st_size,sha256=h);z.write(p,name)
        if p.suffix=='.spv':saved[h]=name
    z.writestr('duplicate-programs.json',json.dumps(duplicates,indent=2));z.writestr('member-sha256.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and all(len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in members.items())
assert archive.stat().st_size<8*1024*1024
verification=dict(bytes=archive.stat().st_size,members=len(members)+2,sha256=digest(archive),memberHashesVerified=True,deduplicatedPrograms=len(duplicates))
(dest/'archive-verification.json').write_text(json.dumps(verification,indent=2));(dest/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(verification))
