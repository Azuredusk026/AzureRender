from pathlib import Path
import json,shutil,re,sys,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent;old=root/'build/runs/20261111-012545-uniform-material-descriptor-local-qualification-ea9bed'
text=(root/'shaders/mesh.frag').read_text();assert text.count('    prepareShadowReceiver();')==1
text=text.replace('    prepareShadowReceiver();','    bool deferShadowReceiver=!azureOrdinaryOpaque && AZURE_ALPHA_MODE==1 && material.nodeOpacity==1.0;\n    if(!deferShadowReceiver)prepareShadowReceiver();')
before='''    if (AZURE_ALPHA_MODE == 1 && coverageAlpha < material.alphaCutoff) {
#else
    if (AZURE_ALPHA_MODE == 1 && baseColor.a < material.alphaCutoff) {
#endif
        discard;
    }'''
after='''    bool alphaRejected=AZURE_ALPHA_MODE==1 && coverageAlpha < material.alphaCutoff;
#else
    bool alphaRejected=AZURE_ALPHA_MODE==1 && baseColor.a < material.alphaCutoff;
#endif
    if(deferShadowReceiver){
        uint covered=(!alphaRejected && !gl_HelperInvocation)?1u:0u;
        uint quadCovered=subgroupQuadBroadcast(covered,0u)|subgroupQuadBroadcast(covered,1u)|subgroupQuadBroadcast(covered,2u)|subgroupQuadBroadcast(covered,3u);
        if(quadCovered==0u)discard;
        prepareShadowReceiver();
    }
    if(alphaRejected)discard;'''
assert text.count(before)==1;text=text.replace(before,after)
text=text.replace('#version 450','#version 450\n#extension GL_KHR_shader_subgroup_quad : require\n#extension GL_EXT_shader_quad_control : require\n#extension GL_EXT_maximal_reconvergence : require\nlayout(quad_derivatives) in;\nlayout(full_quads) in;',1)
annotation='#if defined(AZURE_SURFACE_RADIANCE_REUSE) && !defined(AZURE_OPAQUE_SNAPSHOT)\n    [[maximally_reconverges]]';assert text.count(annotation)==1;text=text.replace(annotation,'#if 1\n    [[maximally_reconverges]]')
(out/'candidate.frag').write_text(text)
compare=(old/'compare.py').read_text().replace(old.name,out.name).replace("sourceBase='efd7efd'","sourceBase='f3071a4'")
start=compare.index(" original=(source/'mesh.frag').read_text();");end=compare.index(' parameters={}\n',start)
compare=compare[:start]+" original=(out/'candidate.frag').read_text()\n"+compare[end:]
compare=compare.replace("scope='Current 720p replay; material textureBase is draw-uniform push constant; omit nine explicit nonuniform decorations; all derivatives, receiver arithmetic and camera values unchanged; both roles replacement programs; native acceptance separate'","scope='Feature-enabled 720p replay; defer receiver preparation only for nonordinary alpha-cutoff draws with nodeOpacity exactly one; skip only quads without surviving nonhelper coverage; all four original derivative expressions retained for every surviving quad; native acceptance separate'")
compare=compare.replace("  command=[manifest['compiler'],*specification['arguments'],","  arguments=[('--target-env=vulkan1.1' if v.startswith('--target-env=') else v) for v in specification['arguments']]\n  if not any(v.startswith('--target-env=') for v in arguments):arguments+=['--target-env=vulkan1.1']\n  command=[manifest['compiler'],*arguments,")
marker=' snapshotMatched=matched-mainMatched';assert compare.count(marker)==1
compare=compare.replace(marker," classMatched={e for g in full['groups'] if not any(v.get('id')==0 and v.get('valueU32')==1 for v in g.get('specialization',[])) and any(v.get('id')==1 and v.get('valueU32')!=0xffffffff for v in g.get('specialization',[])) for e in g['events'] if e in matched}\n"+marker)
compare=compare.replace('dict(materials=sorted(matched),','dict(classSpecialized=sorted(classMatched),materials=sorted(matched),')
compare=compare.replace("dict(mode=r['mode'],mainEventMs=","dict(mode=r['mode'],classEventMs=sum(ms for e,ms in r['milliseconds'].items() if e in classMatched),mainEventMs=")
(out/'compare.py').write_text(compare)
(out/'run_compare.py').write_text((old/'run_compare.py').read_text().replace("sourceBase='efd7efd'","sourceBase='f3071a4'"))
shutil.copyfile(old/'replay-profile.json',out/'replay-profile.json')
preflight=(old/'preflight.py').read_text();start=preflight.index('text,n=re.subn');end=preflight.index('source=folder/',start)
preflight=preflight[:start]+"text=(out/'candidate.frag').read_text()\n"+preflight[end:]
preflight=preflight.replace("command=[manifest['compiler'],*p['arguments'],","arguments=[('--target-env=vulkan1.1' if v.startswith('--target-env=') else v) for v in p['arguments']]\n    if not any(v.startswith('--target-env=') for v in arguments):arguments+=['--target-env=vulkan1.1']\n    command=[manifest['compiler'],*arguments,")
(out/'preflight.py').write_text(preflight)
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs,digest
(out/'source-lock.json').write_text(json.dumps(inputs(root),indent=2))
shutil.copyfile(root/'build/runs/20261111-013805-reference-camera-view-main-integration-38f34e/protected-files.json',out/'protected-files.json')
(out/'task-card.json').write_text(json.dumps(dict(sourceBase='f3071a4',scope='Private quad-uniform alpha coverage receiver preparation',basis='129 fixed-class draws account for 25.4489 percent of processor event time; 245602 fragment invocations versus 99118 passed samples; counts are descriptive, not all removable',hypothesis='Whole failed quads can omit four receiver derivative blocks; deferred preparation also narrows live values before alpha coverage',requirements=['quad_derivatives','full_quads','maximally_reconverges','feature-enabled private capture'],gates=dict(attachments='six byte-exact',nativeAdmission='hotspot at least quarter frame and reduction at least 20%, or 3ms GPU'),budget=dict(diagnosisMinutes=10,implementationMinutes=20,totalMinutes=30),productionChanges=0),indent=2))
print('Prepared uniform alpha-cutoff receiver deferral; all four original derivative blocks retained')
