from pathlib import Path
import sys,json,time
out=Path(__file__).resolve().parent;sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
started=time.monotonic()
while True:
 context=s.lease(s.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-native-depth-cyclic-order',out)
 try:context.__enter__();break
 except ValueError as e:
  if 'busy' not in str(e) or time.monotonic()-started>=180:raise
  time.sleep(1)
try:
 result=s.maintenance.guarded_run(out.parents[1],out.name,[sys.executable,str(out/'cyclic.py')],600);(out/'cyclic-execution.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert result['status']=='exited' and result['exitCode']==0
finally:context.__exit__(None,None,None)
