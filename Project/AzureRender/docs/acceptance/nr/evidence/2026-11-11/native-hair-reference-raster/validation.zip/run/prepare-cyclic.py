from pathlib import Path
import sys,json,hashlib,numpy as np
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
p=Path('D:/Projects/FYP-coordination/quality-claim.json');claim=json.loads(p.read_text(encoding='utf-8'));owner=claim['threadId']
claim['localInputLease'].append(s.acquire_inputs(root/'build',out,['20261111-004745-actual-geometry-index-source-e0f0ac'],owner));claim['inputLease'].append(s.acquire_inputs(s.DEFAULT_BUILD,out,['20261027-022702-object-visibility-depth-reconstruction-c7312f'],owner));p.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
prior=out.parent/'20261111-005626-actual-geometry-uv-source-f50f51';base=json.loads((prior/'candidate-config.json').read_text());index=np.fromfile(base['indices'],dtype='<u4').reshape(-1,3);assert index.shape==(14348,3) and index.max()<11564
for offset in [0,1,2]:
 folder=out/f'cycle-{offset}';folder.mkdir(exist_ok=True);config=dict(base)
 if offset:
  rotated=np.roll(index,-offset,axis=1);assert np.array_equal(np.roll(rotated,offset,axis=1),index);path=folder/'indices.bin';rotated.tofile(path);config['indices']=str(path)
 (folder/'candidate-config.json').write_text(json.dumps(config,indent=2)+'\n')
cal=json.loads((prior/'intel-visibility.json').read_text());shader=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release/shaders';inputs=[Path(base[k]) for k in ['positions','indices','profile','uv','queries']]+list(map(Path,base['mips']))+[Path(cal[k]) for k in ['normals','atlas','profile','expected']]+[out.parent/'20261111-004745-actual-geometry-index-source-e0f0ac/native-coverage.exe',out.parent/'20261110-003435-visibility-numeric-contract-4f95e7/calibration.exe']+[shader/n for n in ['reference_depth.vert.spv','reference_depth.frag.spv','reference_depth_masked.vert.spv','reference_depth_masked.frag.spv']]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();(out/'cyclic-inputs.json').write_text(json.dumps({str(f):{'bytes':f.stat().st_size,'sha256':sha(f)} for f in inputs},indent=2)+'\n');print('Frozen '+str(len(inputs))+' inputs; cyclic rotations preserve all 14348 oriented triangles')
