from pathlib import Path
import sys,json,os,stat,runpy
out=Path(__file__).resolve().parent;sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
p=Path('D:/Projects/FYP-coordination/quality-claim.json');claim=json.loads(p.read_text(encoding='utf-8'));name='20261027-002548-native-hair-layer-region-closure-61c105';token=s.acquire_inputs(s.DEFAULT_BUILD,out,[name],claim['threadId']);claim['inputLease'].append(token);claim['pendingCommand']='Reproduce the actual frozen hair project with the current Player before changing its reference camera';p.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
source=s.DEFAULT_BUILD/'runs'/name/'captured';project=source/'hair-receiver.azureproject';data=json.loads(project.read_text(encoding='utf-8'));count=0;size=0;reparse=[];truncated=False
for directory,dirs,files in os.walk(source,followlinks=False):
 root=Path(directory)
 for name in dirs[:]:
  item=root/name
  if item.lstat().st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT:reparse.append(str(item.relative_to(source)));dirs.remove(name)
 for name in files:count+=1;size+=(root/name).lstat().st_size
 if count>10000 or size>2*1024**3:truncated=True;break
mount,tail=data['startupScene'].split(':/');mountdir=next(v['path'] for v in data['mounts'] if v['name']==mount);levelPath=source/mountdir/tail;level=json.loads(levelPath.read_text(encoding='utf-8'));cameras=[]
for n in level['nodes']:
 c=n.get('components',{});a=c.get('azure.camera')
 if a:cameras.append(dict(node=n['id'],parent=n.get('parentId'),camera=a.get('data'),transform=c.get('azure.transform',{}).get('data')))
baseline=runpy.run_path(str(out.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
result=dict(project=str(project),projectDocument=data,level=str(levelPath),logicalBytes=size,files=count,boundedScanStopped=truncated,reparseDirectories=reparse[:12],cameras=cameras,resources=len(level.get('resources',[])),frozenColor=dict(maskPixels=int(baseline['mask'].sum()),overOne=int(baseline['bad'].sum()),maxByteError=int(baseline['difference'][baseline['mask']].max()),meanAbsoluteByteError=float(baseline['difference'][baseline['mask']].mean())));(out/'hair-project-inspection.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
