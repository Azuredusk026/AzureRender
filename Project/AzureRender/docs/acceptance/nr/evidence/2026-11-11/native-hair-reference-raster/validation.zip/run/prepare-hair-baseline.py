from pathlib import Path
import json,struct,hashlib,shutil,subprocess,sys
from urllib.parse import unquote
out=Path(__file__).resolve().parent;root=out.parents[2];info=json.loads((out/'hair-project-inspection.json').read_text());project=Path(info['project']);level=Path(info['level']);data=json.loads(level.read_text(encoding='utf-8'));source=project.parent/'character/hair-receiver.glb';assert data['resources']==[{'id':'hero','asset':'character:/hair-receiver.glb'}];assert not any(data.get(k,{}).get('asset') for k in ['viewFog','irradianceVolume']) and not data.get('reflectionProbe',{}).get('texture')
material=project.parent/'assets/captured-rim-policy.azurematerial';meta=material.with_suffix(material.suffix+'.azmeta');metadata=json.loads(meta.read_text(encoding='utf-8'));doc=json.loads(material.read_text(encoding='utf-8'));assert {v for node in data['nodes'] for v in node.get('materialSlots',{}).values()}=={metadata['id']} and not doc['textures'] and not metadata['dependencies']
with source.open('rb') as f:
 magic,version,size,length,kind=struct.unpack('<4s4I',f.read(20));assert magic==b'glTF' and version==2 and kind==0x4e4f534a and size==source.stat().st_size;gltf=json.loads(f.read(length))
dependencies=[]
for key in ['buffers','images']:
 for entry in gltf.get(key,[]):
  uri=entry.get('uri','')
  if uri and not uri.startswith('data:'):
   relative=Path(unquote(uri));p=(source.parent/relative).resolve();assert not relative.is_absolute() and p.is_relative_to(project.parent.resolve()) and p.is_file(),uri;dependencies.append(p)
fixture=out/'hair-project';inputs=list(dict.fromkeys([source,project,level,material,meta,*dependencies]));inputs += [v.with_suffix(v.suffix+'.azmeta') for v in [source,level,*dependencies] if v.with_suffix(v.suffix+'.azmeta').is_file()];files=[(a,fixture/a.relative_to(project.parent)) for a in inputs];records=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pre=subprocess.run([sys.executable,str(root/'tools/artifact_budget.py'),'--build',str(root/'build'),'--run',str(out),'--planned-bytes',str(sum(v.stat().st_size for v in inputs)+64*1024**2)],capture_output=True,text=True);(out/'hair-copy-preflight.json').write_text(pre.stdout);assert pre.returncode==0,pre.stdout+pre.stderr
for a,b in files:
 b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b);h=sha(a);assert sha(b)==h;records.append(dict(source=str(a),destination=str(b),bytes=b.stat().st_size,sha256=h))
(out/'hair-copy-inputs.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(dict(resources=1,bytes=sum(r['bytes'] for r in records),embeddedImages=len(gltf.get('images',[])),materials=[dict(index=i,name=v.get('name'),extraKeys=list(v.get('extras',{}))) for i,v in enumerate(gltf.get('materials',[]))]),indent=2))
