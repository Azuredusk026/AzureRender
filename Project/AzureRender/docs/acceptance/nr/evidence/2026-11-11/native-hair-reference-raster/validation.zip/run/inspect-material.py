from pathlib import Path
import json,struct
out=Path(__file__).resolve().parent;path=out/'hair-project/character/hair-receiver.glb'
with path.open('rb') as f:
 _,_,_,length,_=struct.unpack('<4s4I',f.read(20));gltf=json.loads(f.read(length))
material=next(v for v in gltf['materials'] if v['name']=='M_actor_laevat_hair_01');profile=material['extras']['azureRenderMaterial'];lighting=profile.get('hair',{}).get('projectedRamp',{}).get('lighting',{});summary=dict(keys=list(profile),schemaVersion=profile.get('schemaVersion'),materialClass=profile.get('class'),features=profile.get('features'),hairKeys=list(profile.get('hair',{})),lightingKeys=list(lighting),characterVisibility=lighting.get('characterVisibility'),gain=lighting.get('mainBrightnessSaturation'));(out/'hair-material-source.json').write_text(json.dumps(profile,indent=2)+'\n');print(json.dumps(summary,indent=2))
