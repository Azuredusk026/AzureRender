from pathlib import Path
import sys,json,time
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
p=Path('D:/Projects/FYP-coordination/quality-claim.json');claim=json.loads(p.read_text(encoding='utf-8'));owner=claim['threadId']
names=['20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2','20261111-053153-reference-camera-render-binding-c3826b','20261111-005626-actual-geometry-uv-source-f50f51','20261110-112309-hair-relative-projection-control-b9da17','20261111-001326-reference-position-frame-482201','20261110-165124-reference-depth-source-4d1d7d','20261110-173835-reference-depth-coverage-4b4afc','20261110-003435-visibility-numeric-contract-4f95e7','20261110-003031-reciprocal-compact-profile-4e7929','20261110-235205-actual-world-depth-source-bcce93','20261110-110844-hair-postvs-clip-source-03c2f0']
t=s.acquire_inputs(root/'build',out,names,owner)
for n in names[:3]:s.maintenance.seal(root/'build',out.parent/n)
for v in claim.get('localInputLease',[]):s.release_inputs(root/'build',v,owner)
for v in claim.get('inputLease',[]):s.release_inputs(s.DEFAULT_BUILD,v,owner)
claim.update(state='native-hair-reference-raster-qualification',lastCommit='1a7da41',taskPath=str(out),localInputLease=[t],inputLease=[],ownedFiles=[],pendingCommand='Verify a single cyclic triangle order factor against the 17017-point native depth/visibility gate; retain frozen original geometry and color baselines')
claim.pop('queueWaitOutcome',None);p.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'task-card.json').write_text(json.dumps(dict(baseCommit='1a7da41',created=time.time(),locationSeconds=600,candidateSeconds=1200,explorationSeconds=1800,gpuSeconds=600,plannedBytes=536870912,gateSource='Native quality 17017-point depth/visibility and original full hair one-byte color gates',hypothesis='Cyclic vertex order can change hardware interpolation rounding without changing the triangle, winding, UVs or coverage; actual Intel residuals originate from the same triangle',baseline=dict(nvidiaVisibilityFailures=0,intelVisibilityFailures=96,maxVisibilityByteError=25,colorFailures=73,maxColorByteError=6)),indent=2)+'\n')
print('Production binding sealed; actual native depth and hair inputs leased')
