from pathlib import Path
import sys,subprocess,json,hashlib
out=Path(__file__).resolve().parent;candidate=out/'hair-project/character/hair-candidate.glb';record=json.loads((out/'hair-uv-asset.json').read_text());assert hashlib.sha256(candidate.read_bytes()).hexdigest()==record['assetSha256']
for mode in ['hair-receiver','hair-uv']:
 r=subprocess.run([sys.executable,str(out/'hair-capture.py'),sys.argv[1],mode],timeout=420);assert r.returncode==0
