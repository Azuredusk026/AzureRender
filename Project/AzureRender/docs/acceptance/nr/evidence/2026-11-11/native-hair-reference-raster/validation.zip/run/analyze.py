from pathlib import Path
import runpy,json,hashlib,numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;root=out.parents[2];base=runpy.run_path(str(out.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'));mask=base['mask'];expected=base['expected'];original=base['bad'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for device,variants in [('nvidia',['hair-receiver','hair-reference','hair-chroma','hair-r11','hair-uv']),('intel',['hair-receiver','hair-uv'])]:
 previous=original
 for variant in variants:
  label=device+'-'+variant;result=json.loads((out/(label+'-results.json')).read_text());assert result['validationClean'] and result['allocatorZero'] and len(result['frames'])==4
  images=[]
  for frame in range(4):
   file=out/(label+f'-frames/frame_{frame:06d}.png');assert sha(file)==result['frames'][frame]['sha256'];images.append(np.asarray(Image.open(file).convert('RGB'))[130:440,1140:1430].copy())
  assert all(np.array_equal(images[0][mask],v[mask]) for v in images)
  error=abs(images[0].astype('i4')-expected);bad=mask&(error.max(axis=2)>1);stats=dict(device=device,variant=variant,failures=int(bad.sum()),maximumByteError=int(error[mask].max()),meanAbsoluteByteError=float(error[mask].mean()),closedFromPrevious=int((previous&~bad).sum()),newFromPrevious=int((bad&~previous).sum()),closedOriginal=int((original&~bad).sum()),newOriginal=int((bad&~original).sum()),failuresAt=[dict(pixel=[int(x)+1140,int(y)+130],error=error[y,x].tolist()) for y,x in zip(*np.where(bad))],fourFrameSource=result);assert stats['failures']==result['frames'][0]['overOne']
  Image.fromarray(images[0]).save(out/(label+'-crop.png'));rows.append(stats);previous=bad
cycles=json.loads((out/'cyclic-results.json').read_text());assert len(cycles)==6 and all(r['changedDepthPixels']==0 and r['changedVisibilityPixels']==0 and r['r32D32Exact'] and r['validationClean'] and r['failures']==(96 if r['device']=='intel' else 0) for r in cycles)
baseline=rows[0];assert baseline['failures']==73 and baseline['maximumByteError']==6 and all(r['vsFrozenDifferentPixels']==0 for r in baseline['fourFrameSource']['frames']);assert [v['failures'] for v in rows[:5]]==[73,71,54,45,43]
binary=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release/AzurePlayer.exe';known=json.loads((root/'docs/acceptance/nr/evidence/2026-11-11/reference-camera-render-binding/results.json').read_text())['builds'];identity=sha(binary);assert identity==next(v['playerSha256'] for v in known if v['configuration']=='release')
result=dict(status='diagnostic-no-production-adoption',overall='failed-user-review',baseCommit='1a7da41',playerSha256=identity,maskPixels=17017,allowedByteError=1,depthCycles=cycles,depthComparedPixels=6*2560*1440,color=rows,assetClosure=json.loads((out/'hair-copy-inputs.json').read_text()),nativeColorUnqualified=True,remaining=['Actual dynamic reference visibility producer','Intel 96 reference depth visibility failures','Skin, eye, GI, reflection and dynamic appearance gates']);(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps([{k:v for k,v in row.items() if k not in ['failuresAt','fourFrameSource']} for row in rows],indent=2))
