from pathlib import Path
import sys,json,struct,hashlib,subprocess,copy
out=Path(__file__).resolve().parent;fixture=out/'hair-project';source=fixture/'character/hair-receiver.glb';candidate=fixture/'character/hair-candidate.glb';device=sys.argv[1];rows=[]
for stage,variant in enumerate(['hair-chroma','hair-r11','hair-uv'],1):
 with source.open('rb') as input:
  magic,version,total,oldSize,kind=struct.unpack('<4s4I',input.read(20));assert magic==b'glTF' and version==2 and kind==0x4e4f534a and total==source.stat().st_size;gltf=json.loads(input.read(oldSize));profiles=[v['extras']['azureRenderMaterial'] for v in gltf['materials'] if v['name']=='M_actor_laevat_hair_01'];assert len(profiles)==1;profile=profiles[0];assert profile==json.loads((out/'hair-material-source.json').read_text());previous=copy.deepcopy(profile)
  profile['hair']['projectedRamp']['lighting']['mainBrightnessSaturation']=True
  if stage>=2:profile['features'].append('r11g11b10-output')
  if stage>=3:profile['features'].append('mirrored-coarse-uv')
  payload=json.dumps(gltf,separators=(',',':'),ensure_ascii=False).encode();payload+=b' '*((-len(payload))%4);sha=hashlib.sha256()
  with candidate.open('wb') as output:
   output.write(struct.pack('<4s4I',magic,version,total-oldSize+len(payload),len(payload),kind));output.write(payload)
   while chunk:=input.read(4*1024**2):output.write(chunk);sha.update(chunk)
 originalTail=sha.hexdigest();withCandidate=hashlib.sha256()
 with candidate.open('rb') as f:
  f.seek(20+len(payload))
  while chunk:=f.read(4*1024**2):withCandidate.update(chunk)
 assert originalTail==withCandidate.hexdigest()
 level=json.loads((fixture/'assets/hair-reference.azurelevel').read_text());level['resources'][0]['asset']='character:/hair-candidate.glb';project=json.loads((fixture/'hair-reference.azureproject').read_text());project['startupScene']='assets:/'+variant+'.azurelevel'
 for p,v in [(fixture/(variant+'.azureproject'),project),(fixture/'assets'/(variant+'.azurelevel'),level),(out/(variant+'-material.json'),profile)]:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
 result=dict(variant=variant,changedFactor=['mainBrightnessSaturation','r11g11b10-output','mirrored-coarse-uv'][stage-1],unchangedBinaryTailSha256=originalTail,assetSha256=hashlib.sha256(candidate.read_bytes()).hexdigest(),assetBytes=candidate.stat().st_size);(out/(variant+'-asset.json')).write_text(json.dumps(result,indent=2)+'\n');r=subprocess.run([sys.executable,str(out/'hair-capture.py'),device,variant],timeout=420);assert r.returncode==0;raster=json.loads((out/(device+'-'+variant+'-results.json')).read_text());rows.append(dict(**result,frames=raster['frames']));(out/(device+'-material-variants.json')).write_text(json.dumps(rows,indent=2)+'\n');print(variant,[(f['overOne'],f['maxByteError']) for f in raster['frames']],flush=True)
