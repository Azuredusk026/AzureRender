from pathlib import Path
import subprocess,json,os,re,hashlib,numpy as np
out=Path(__file__).resolve().parent;runs=out.parent;prior=runs/'20261111-005626-actual-geometry-uv-source-f50f51';public=runs/'20261111-004745-actual-geometry-index-source-e0f0ac';build=runs/'20261110-030251-hair-main-chroma-public-9e799c/release';calibration=runs/'20261110-003435-visibility-numeric-contract-4f95e7';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for n,v in json.loads((out/'cyclic-inputs.json').read_text()).items():assert sha(Path(n))==v['sha256'],n
rows=[]
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(build)+';'+env['PATH'])
 frozen=np.fromfile(prior/(device+'-actual-r32.bin'),dtype='<u4');baseline=np.fromfile(prior/(device+'-actual-rg8.bin'),dtype='u1').reshape(-1,2)[:,1]
 for cycle in [0,1,2]:
  folder=out/f'cycle-{cycle}';prefix=folder/(device+'-actual');command=[str(public/'native-coverage.exe'),str(build/'shaders'),str(folder/'candidate-config.json'),str(prefix)]
  (folder/(device+'-depth-command.json')).write_text(json.dumps(command,indent=2)+'\n')
  with (folder/(device+'-depth.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
  text=(folder/(device+'-depth.log')).read_text(errors='replace');assert r.returncode==0 and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I),text[-3000:]
  config=json.loads((prior/(device+'-visibility.json')).read_text());config['depth']=str(prefix)+'-r32.bin';path=folder/(device+'-visibility.json');path.write_text(json.dumps(config,indent=2)+'\n');command=[str(calibration/'calibration.exe'),str(path),str(calibration)];(folder/(device+'-visibility-command.json')).write_text(json.dumps(command,indent=2)+'\n')
  with (folder/(device+'-visibility.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
  result=json.loads((folder/(device+'-actual-result.json')).read_text());text=(folder/(device+'-visibility.log')).read_text(errors='replace');assert result['validationErrors']==0 and result['zeroAllocator'] and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I)
  depth=np.fromfile(config['depth'],dtype='<u4');assert depth.shape==frozen.shape==(2560*1440,);a=np.fromfile(folder/(device+'-actual-rg8.bin'),dtype='u1').reshape(-1,2)[:,1];expected=np.fromfile(config['expected'],dtype='<u4');assert len(a)==len(expected)==17017
  q=np.fromfile(config['queries'],dtype='<f4').reshape(-1,4);x=q[:,0].astype(int);y=q[:,1].astype(int);selected=depth.reshape(1440,2560)[y,x];d32=np.fromfile(folder/(device+'-actual-selected-d32.bin'),dtype='<u4');assert np.array_equal(selected,d32);selected.tofile(folder/(device+'-actual-selected-r32.bin'))
  if cycle==0:assert np.array_equal(depth,frozen) and np.array_equal(a,baseline),'Frozen control must reproduce exactly'
  error=abs(a.astype('i4')-expected.astype('i4'));old=abs(baseline.astype('i4')-expected.astype('i4'));row=dict(device=device,cycle=cycle,failures=int((error>1).sum()),maximumByteError=int(error.max()),changedVisibilityPixels=int((a!=baseline).sum()),changedDepthPixels=int((depth!=frozen).sum()),newFailures=int(((error>1)&(old<=1)).sum()),closedFailures=int(((error<=1)&(old>1)).sum()),visibilityExitCode=r.returncode,validationClean=True,r32D32Exact=True);rows.append(row);(out/'cyclic-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
