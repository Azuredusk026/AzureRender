from pathlib import Path
import runpy,json,numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;data=runpy.run_path(str(out.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'));mask=data['mask'];expected=data['expected'];interior=np.lib.stride_tricks.sliding_window_view(np.pad(mask,1),(3,3)).all(axis=(-2,-1));rows=[]
depth=[np.fromfile(out.parent/'20261111-005626-actual-geometry-uv-source-f50f51'/(d+'-actual-r32.bin'),dtype='<f4').reshape(1440,2560) for d in ['nvidia','intel']]
for variant in ['hair-receiver','hair-uv']:
 intel=np.asarray(Image.open(out/('intel-'+variant+'-crop.png')).convert('RGB')).astype('i4');nvidia=np.asarray(Image.open(out/('nvidia-'+variant+'-crop.png')).convert('RGB')).astype('i4');error=abs(intel-expected).max(axis=2);strong=mask&(error>8);coords=list(zip(*np.where(strong)));coords.sort(key=lambda yx:(-error[yx],yx));points=[]
 for y,x in coords[:64]:
  px,py=int(x)+1140,int(y)+130;z=[float(a[1439-py,px]) for a in depth];points.append(dict(pixel=[px,py],native=expected[y,x].tolist(),nvidia=nvidia[y,x].tolist(),intel=intel[y,x].tolist(),error=int(error[y,x]),interior=bool(interior[y,x]),qualifiedDepth=z))
 rows.append(dict(variant=variant,strongPixels=int(strong.sum()),strongInterior=int((strong&interior).sum()),peak=points[:12],allStrongPoints=points))
(out/'intel-localization.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([dict(variant=r['variant'],strongPixels=r['strongPixels'],strongInterior=r['strongInterior'],peak=r['peak'][:5]) for r in rows],indent=2))
