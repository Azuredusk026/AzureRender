#include "scene/TransformMath.hpp"
#include "render/ReferenceCameraCalibration.hpp"
#include <iomanip>
#include <iostream>
int main(int argc,char** argv)try{
 using namespace azurerender;using namespace internal;
 if(argc!=10)throw std::invalid_argument("Expected translation, rotation, and scale");Vector3 position,rotation,scale;
 for(unsigned i=0;i<3;++i){position[i]=std::stof(argv[1+i]);rotation[i]=std::stof(argv[4+i]);scale[i]=std::stof(argv[7+i]);}
 const auto matrix=scene::composeTrs(position,rotation,scale);
 const auto pose=referenceCameraPose({matrix[12],matrix[13],matrix[14]},addVectors(position,normalize({-matrix[8],-matrix[9],-matrix[10]})),normalize({matrix[4],matrix[5],matrix[6]}));
 std::cout<<std::setprecision(9)<<'[';unsigned n=0;for(const auto& vector:{pose.position,pose.right,pose.up,pose.back}){if(n++)std::cout<<',';std::cout<<'['<<vector[0]<<','<<vector[1]<<','<<vector[2]<<']';}std::cout<<"]\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
