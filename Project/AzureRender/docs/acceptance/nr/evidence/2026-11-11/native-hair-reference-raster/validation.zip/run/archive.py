from pathlib import Path
import json,zipfile,hashlib,re
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=json.loads((out/'results.json').read_text());assert result['status']=='diagnostic-no-production-adoption'
docs=['docs/acceptance/nr/native-hair-reference-raster.md','docs/plans/2026-11-09-native-quality.md'];files={'source/'+n:root/n for n in docs};files.update({'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.log','.json','.cpp','.png'}})
for folder in out.glob('cycle-*'):
 for p in folder.iterdir():
  if p.is_file() and (p.suffix in {'.json','.log'} or p.name=='indices.bin' or p.name.endswith(('selected-r32.bin','selected-d32.bin','rg8.bin'))):files[folder.name+'/'+p.name]=p
for p in (out/'hair-project').rglob('*'):
 if p.is_file() and p.suffix in {'.azureproject','.azurelevel','.azurematerial','.azmeta','.json'} and not any(s in {'.azure','cache','generated'} for s in p.relative_to(out/'hair-project').parts):files['project/'+str(p.relative_to(out/'hair-project')).replace('\\','/')]=p
for p in (out.parent/'20261110-112309-hair-relative-projection-control-b9da17/inputs').iterdir():
 if p.is_file():files['input/'+p.name]=p
for path in ['20261110-165124-reference-depth-source-4d1d7d/native-profile.bin','20261111-001326-reference-position-frame-482201/native-frame.bin']:files['input/'+Path(path).name]=out.parent/path
dest=root/'docs/acceptance/nr/evidence/2026-11-11/native-hair-reference-raster';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']=dict(bytes=archive.stat().st_size,sha256=sha(archive),members=len(members)+1);result['failureRowsArchiveMember']='run/results.json';result['color']=[{k:v for k,v in row.items() if k!='failuresAt'} for row in result['color']];(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n')
p=root/docs[0];text=p.read_text(encoding='utf-8')
for s in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',s))<=45,s
for link in re.findall(r'\]\(([^)]+)\)',text):assert (p.parent/link).exists(),link
print(json.dumps(result['archive']))
