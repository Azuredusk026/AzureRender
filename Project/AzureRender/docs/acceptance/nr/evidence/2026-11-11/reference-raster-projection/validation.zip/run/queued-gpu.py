from pathlib import Path
import sys,json,time
out=Path(__file__).resolve().parent;sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
started=time.monotonic()
while True:
 context=s.lease(s.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-reference-raster-gpu',out)
 try:context.__enter__();break
 except ValueError as error:
  if not any(v in str(error) for v in ['busy','still running']):raise
  if time.monotonic()-started>=180:raise TimeoutError('Bounded GPU queue wait ended; no execution')
  time.sleep(1)
try:
 result=s.maintenance.guarded_run(out.parents[1],out.name,[sys.executable,str(out/'gpu.py')],600);(out/'gpu-execution.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));sys.exit(result.get('exitCode',2))
finally:context.__exit__(None,None,None)
