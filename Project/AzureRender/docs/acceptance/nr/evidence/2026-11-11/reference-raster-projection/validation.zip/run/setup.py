from pathlib import Path
import json,hashlib,struct,ctypes,sys
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
files=['CMakeLists.txt','src/render/ReferenceRasterProjection.hpp','shaders/reference_raster_projection.glsl','shaders/reference_raster_projection_test.comp','tests/ReferenceRasterProjectionGpuTests.cpp']
(out/'frozen-source.json').write_text(json.dumps({n:sha(root/n) for n in files},indent=2)+'\n')
for n in ['20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2']:s.maintenance.resume(root/'build',n)
(out/'before-player-sha256.json').write_text(json.dumps({c:sha(out.parent/b/c/'AzurePlayer.exe') for c,b in [('release','20261110-030251-hair-main-chroma-public-9e799c'),('debug','20261110-031856-hair-main-chroma-debug-668bf2')]},indent=2)+'\n')
frame=out.parent/'20261111-001326-reference-position-frame-482201/native-frame.bin';profile=out.parent/'20261110-165124-reference-depth-source-4d1d7d/native-profile.bin';vertices=out.parent/'20261110-110844-hair-postvs-clip-source-03c2f0/vulkan-vertex.bin'
axes=struct.unpack('<4i',frame.read_bytes()[:16]);offset=struct.unpack('<4f',frame.read_bytes()[16:]);p=struct.unpack('<20f',profile.read_bytes());v=vertices.read_bytes();assert len(v)==11564*256
f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0];fma=ctypes.CDLL('ucrtbase').fmaf;fma.argtypes=[ctypes.c_float]*3;fma.restype=ctypes.c_float
records=bytearray()
for at in range(0,len(v),256):
 values=struct.unpack_from('<64f',v,at);world=values[16:19];relative=[f32((world[abs(a)-1] if a>0 else -world[abs(a)-1])+offset[i]) for i,a in enumerate(axes[:3])]
 clip=[]
 for row in range(4):
  q=f32(relative[1]*p[4+row]);q=fma(p[row],relative[0],q);q=fma(p[8+row],relative[2],q);clip.append(f32(q+p[12+row]))
 for axis in range(2):clip[axis]=fma(-f32(clip[3]*p[16+axis]),2 if axis==0 else -2,clip[axis])
 records+=struct.pack('<16f',*world,1,*values[:4],*values[:4],*clip)
(out/'native-records.bin').write_bytes(records)
(out/'input-manifest.json').write_text(json.dumps({str(f):sha(f) for f in [frame,profile,vertices,out/'native-records.bin']},indent=2)+'\n')
source=(out.parent/'20261111-010755-reference-camera-view-0d60e5/build.py').read_text();source=source.replace("'AzureReferenceCameraViewTests'","'AzureReferenceRasterProjectionGpuTests'");(out/'build.py').write_text(source)
source=(out.parent/'20261111-010755-reference-camera-view-0d60e5/queued-build.py').read_text().replace('quality-reference-position-frame-','quality-reference-raster-');(out/'queued-build.py').write_text(source)
print('Source frozen; actual 11564 source records prepared with explicit ucrt fmaf oracle')
