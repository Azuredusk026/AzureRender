from pathlib import Path
import json,zipfile,hashlib,re
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=json.loads((out/'results.json').read_text())
plan=root/'docs/plans/2026-11-11-reference-raster-projection.md';plan.write_text(plan.read_text(encoding='utf-8').replace('- [ ]','- [x]'),encoding='utf-8')
for name,prefix in [('README.md','docs/'),('docs/project-status.md',''),('docs/plans/azure-engine-plan.md','../'),('docs/plans/2026-11-09-native-quality.md','../')]:
 p=root/name;text=p.read_text(encoding='utf-8')
 if '[参考光栅位置]' not in text:text+='\n[参考光栅位置]('+prefix+'acceptance/nr/reference-raster-projection.md)通过两配置、双设备数值核对。\n组合保留设备最终深度及屏幕偏移，场景宿主绑定继续接入。\n'
 p.write_text(text,encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');anchor='## 2026-11-11 参考相机视图'
if '## 2026-11-11 参考光栅位置' not in text:text=text.replace(anchor,'## 2026-11-11 参考光栅位置\n\n- 提供参考横纵位置与设备最终深度、屏幕偏移的公共组合接口。\n- 关闭及退化路径保留设备位置，配置由准备后的视图生成。\n- 两配置、双设备共 709824 个组合分量逐位一致。\n- 既有 858 份程序及两份当前 Player 保持相同，原四帧复用精确证据。\n- 场景宿主绑定及整体原生外观继续按原门槛推进。\n\n'+anchor)
p.write_text(text,encoding='utf-8')
sources=list(result['sourceSha256'])+['docs/runtime/reference-raster-projection.md','docs/plans/2026-11-11-reference-raster-projection.md','docs/acceptance/nr/reference-raster-projection.md']
files={'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log','.bin'}};files.update({'source/'+n:root/n for n in sources})
for key in json.loads((out/'input-manifest.json').read_text()):
 p=Path(key)
 if p!=out/'native-records.bin':files['inputs/'+p.name]=p
dest=root/'docs/acceptance/nr/evidence/2026-11-11/reference-raster-projection';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']=dict(bytes=archive.stat().st_size,sha256=sha(archive),members=len(members)+1)
(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n');(dest/'program-catalog.json').write_bytes((out/'program-catalog.json').read_bytes())
for n in [v for v in sources if v.endswith('.md')]:
 p=root/n;text=p.read_text(encoding='utf-8')
 for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(n,sentence)
 for link in re.findall(r'\]\(([^)]+)\)',text):
  if not re.match(r'(https?:|#)',link):assert (p.parent/link.split('#')[0]).exists(),(n,link)
print(json.dumps(result['archive']))
