from pathlib import Path
import json,hashlib,re
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((out/'frozen-source.json').read_text());assert all(sha(root/n)==v for n,v in sources.items())
rows=json.loads((out/'gpu-results.json').read_text());assert len(rows)==4
for r in rows:assert r['exitCode']==0 and r['validationClean'] and '44364 records / 177456 exact GPU raster components' in r['stdout'],r
old=json.loads((root/'docs/acceptance/nr/evidence/2026-11-11/reference-position-frame/program-catalog.json').read_text())['sha256'];assert len(old)==858
players=json.loads((out/'before-player-sha256.json').read_text());identities=[];catalogs=[]
assert players==dict(release='f6a391018258ff2ea7fa32e3394cb5089e996ed206d14eb4142e4c030a954b43',debug='78cb7bb5c895d4edd5339acec1cfd44678b4079371001be86b9046556a1766b2')
for c,parent in [('release','20261110-030251-hair-main-chroma-public-9e799c'),('debug','20261110-031856-hair-main-chroma-debug-668bf2')]:
 b=out.parent/parent/c;catalog={p.name:sha(p) for p in (b/'shaders').glob('*.spv')};assert len(catalog)==859
 assert all(catalog[n]==v for n,v in old.items());assert sha(b/'AzurePlayer.exe')==players[c]
 assert (out/(c+'-cpu.log')).read_text().startswith('CPU depth, offset, disable, zero-W, overflow and three invalid-input contracts passed')
 identities.append(dict(configuration=c,playerSha256=players[c],playerUnchanged=True,testSha256=sha(b/'AzureReferenceRasterProjectionGpuTests.exe'),oldProgramsExact=858,programCount=859));catalogs.append(catalog)
assert catalogs[0]==catalogs[1]
default=json.loads((root/'docs/acceptance/nr/evidence/2026-11-11/reference-position-frame/results.json').read_text())['defaultFour'];assert default['allExact']
result=dict(status='qualified-public-reference-raster-composition',overall='failed-user-review',baseCommit='7d9dd54',sourceSha256=sources,configurations=identities,gpu=rows,recordsPerEndpoint=44364,componentsPerEndpoint=177456,totalExactGpuComponents=709824,actualVerticesPerEndpoint=11564,defaultFour=default,originalFourReuseReason='Both current Player executable bytes and all 858 production/reference shaders are unchanged; new shader is a standalone numeric fixture',remaining=['Scene host binding','Production hair 73 color failures','Intel depth/visibility 96 failures','Skin, eyes, GI, reflection and dynamic appearance gates'])
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');(out/'program-catalog.json').write_text(json.dumps(dict(count=859,sha256=catalogs[0]),indent=2)+'\n');print(json.dumps(dict(status=result['status'],totalExactGpuComponents=709824,oldProgramsExact=858,playersUnchanged=True),indent=2))
