from pathlib import Path
import json,subprocess,sys,os,re,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for name,digest in json.loads((out/'frozen-source.json').read_text()).items():assert sha(root/name)==digest,name
for configuration,parent in [('release','20261110-030251-hair-main-chroma-public-9e799c'),('debug','20261110-031856-hair-main-chroma-debug-668bf2')]:
 build=out.parent/parent/configuration
 assert (build/'AzureReferenceRasterProjectionGpuTests.exe').stat().st_mtime>=(root/'tests/ReferenceRasterProjectionGpuTests.cpp').stat().st_mtime,'Target requires rebuild after fixture extension: '+configuration
 command=[str(build/'AzureReferenceRasterProjectionGpuTests.exe'),'--cpu-only'];r=subprocess.run(command,capture_output=True,text=True,timeout=30);(out/(configuration+'-cpu.log')).write_text(r.stdout+r.stderr);assert r.returncode==0
 for device in ['nvidia','intel']:
  env=os.environ.copy()
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
  env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(build)+';'+env['PATH'])
  command=[str(build/'AzureReferenceRasterProjectionGpuTests.exe'),str(build/'shaders/reference_raster_projection_test.comp.spv'),str(out.parent/'20261110-165124-reference-depth-source-4d1d7d/native-profile.bin'),str(out.parent/'20261111-001326-reference-position-frame-482201/native-frame.bin'),str(out/'native-records.bin')]
  label=configuration+'-'+device;print('START',label,flush=True)
  with (out/(label+'.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  t=(out/(label+'.log')).read_text(errors='replace');row=dict(configuration=configuration,device=device,command=command,exitCode=r.returncode,validationClean=not bool(re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)',t,re.I)),stdout=t.strip());rows.append(row);(out/'gpu-results.json').write_text(json.dumps(rows,indent=2)+'\n');assert r.returncode==0 and row['validationClean'],t[-5000:];print('PASS',label,t.strip(),flush=True)
print('Four GPU endpoints completed')
