from pathlib import Path
import json,sys,subprocess,time
out=Path(__file__).resolve().parent;root=out.parents[2]
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a';claimPath=Path('D:/Projects/FYP-coordination/quality-claim.json');claim=json.loads(claimPath.read_text(encoding='utf-8'))
inputs=['20261111-010755-reference-camera-view-0d60e5','20261111-001326-reference-position-frame-482201','20261110-110844-hair-postvs-clip-source-03c2f0','20261110-165124-reference-depth-source-4d1d7d','20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2']
token=s.acquire_inputs(root/'build',out,inputs,owner)
old=out.parent/'20261111-014118-reference-scene-view-binding-8d47bd'
(old/'design-result.json').write_text(json.dumps(dict(status='design-budget-exhausted',sourceChanged=False,baseCommit='7d9dd54',observedAt=time.time(),locationBudgetSeconds=600,explorationBudgetSeconds=1800,findings=['Main scene uses forward depth; source view uses reversed depth','Reference XYW must retain final device NDC depth and screen-space deformation','GPU culling push constants do not carry reference projection error bounds','Runtime camera source resolution and editor pose updates require a separate typed contract'],retryTriggers=['Qualified public raster composition','Conservative mixed-frustum GPU contract']),indent=2)+'\n')
s.maintenance.seal(root/'build',old)
s.maintenance.seal(root/'build',Path(claim['taskPath']))
for n in inputs[-2:]:s.maintenance.seal(root/'build',out.parent/n)
for t in claim.get('localInputLease',[]):s.release_inputs(root/'build',t,owner)
for t in claim.get('inputLease',[]):s.release_inputs(s.DEFAULT_BUILD,t,owner)
claim.update(state='reference-raster-projection',taskPath=str(out),lastCommit='7d9dd54',localInputLease=[token],inputLease=[],ownedFiles=['src/render/ReferenceRasterProjection.hpp','shaders/reference_raster_projection.glsl','shaders/reference_raster_projection_test.comp','tests/ReferenceRasterProjectionGpuTests.cpp','CMakeLists.txt'],pendingCommand='Preserve device depth and final screen offsets while applying reference raster XYW')
claimPath.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'task-card.json').write_text(json.dumps(dict(baseCommit='7d9dd54',started=time.time(),candidateSeconds=1200,explorationSeconds=1800,buildSeconds=1200,gpuSeconds=600,plannedBytes=100663296,gateSource='AGENT.md rendering/public interface gates; NR original four frame exactness; frozen actual world/index/UV provenance',deliverable='Public reference raster composition on CPU and Vulkan with final device depth and NDC XY displacement',defaultPlayerExpectedUnchanged=True),indent=2)+'\n')
print('Previous design isolated, camera evidence sealed, input leases transferred')
