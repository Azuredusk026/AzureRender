from pathlib import Path
import json,os,subprocess,sys,shutil,time,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,verify,digest
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
before=inputs(root);(out/'source-lock.json').write_text(json.dumps(before,indent=2));checks=[]
targets=['AzureComputedMaterialViewTests','AzureMaterialViewDeterminismGpuTests','AzureDepthPrefillRecordingTests','AzureMotionRecordingTests','AzureMaterialPipelinePolicyTests','AzureMaterialUvPolicyTests','AzureMaterialUvGradientsGpuTests','AzureShaderCompilerContractTests','AzureHotReloadTests','AzureProjectedReflectionSceneTests','AzureReferenceCameraSelectionTests','AzureReferenceCameraMacroTests']
selector=r'^(AzureRender\.(ComputedMaterialView|DepthPrefillRecording|MotionRecording|MaterialPipelinePolicy|MaterialUvPolicy|ShaderCompilerContract|ShaderCatalogCompilation|HotReload|ReferenceCameraMacro)|AzureRuntime\.ReferenceCameraSelection|AzureEngine\.(ModuleBoundaries|ModuleBoundaryFixtures))$'
qualified=root/'build/runs/20261111-021128-quad-depth-visibility-local-qualification-1ea541/combined'
measured=json.loads((qualified/'compare-state.json').read_text())['programs']
for config in ['Release','Debug']:
    build=root/('build/ninja-msvc-'+config.lower());start=time.monotonic();os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
    command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
    for target in targets:command+=['--test-target',target]
    with (out/(config.lower()+'-build.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
    manifest=json.loads((build/'shader-reload.json').read_text());assert len(manifest['programs'])==988
    hashes={p['output']:digest(build/'shaders'/p['output']) for p in manifest['programs']}
    reference=json.loads((out/(config.lower()+'-reference-programs.json')).read_text());assert len(reference)==860 and all(hashes.get(n)==h for n,h in reference.items())
    aliases=[n for n in hashes if n.endswith('_viewquad.frag.spv')];assert len(aliases)==128
    for p in measured:assert hashes[p['file'].replace('.frag.spv','_viewquad.frag.spv')]==p['candidateSha256'],p['file']
    (out/(config.lower()+'-program-sha256.json')).write_text(json.dumps(hashes,indent=2));shutil.copyfile(build/'build-provenance.json',out/(config.lower()+'-build-provenance.json'))
    command=['ctest','--test-dir',str(build),'-C',config,'--output-on-failure','--no-tests=error','-R',selector,'--output-junit',str(out/(config.lower()+'-tests.xml'))]
    with (out/(config.lower()+'-tests.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
    cases=ET.parse(out/(config.lower()+'-tests.xml')).findall('.//testcase');assert len(cases)==12 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
    verify(root,json.loads((build/'build-provenance.json').read_text()));assert inputs(root)==before
    assert all(digest(root/p)==h for p,h in json.loads((out/'protected-files.json').read_text()).items())
    checks.append(dict(config=config,tests=len(cases),skips=0,activePrograms=988,referenceProgramsExact=860,measuredProgramsExact=10,aliases=128,seconds=time.monotonic()-start))
    (out/'build-results.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks[-1]),flush=True)
