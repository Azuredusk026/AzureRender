from pathlib import Path
import json,sys,zipfile,hashlib,shutil
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from shared_resources import acquire_inputs
assert inputs(root)==json.loads((out/'source-lock.json').read_text())
protected=json.loads((out/'protected-files.json').read_text());assert len(protected)==13 and all(digest(root/p)==h for p,h in protected.items())
lock=json.loads((out/'frozen-project-inputs.json').read_text());assert len(lock)==1729 and all(digest(Path(p))==h for p,h in lock.items())
for config in ['release','debug']:verify(root,json.loads((out/(config+'-build-provenance.json')).read_text()))
build=json.loads((out/'build-results.json').read_text());assert len(build)==2 and sum(x['tests'] for x in build)==24
assert all(x['referenceProgramsExact']==860 and x['measuredProgramsExact']==10 and x['aliases']==128 and not x['skips'] for x in build)
refresh=json.loads((out/'timeout-refresh.json').read_text());assert refresh['testCasesUnchanged'] and all(x['allRuntimeAndTestProductsExact'] for x in refresh['configs'])
gpu=json.loads((out/'gpu-results.json').read_text());assert len(gpu)==12
assert all(x['result']['validationErrors']==0 and x['result']['zeroAllocator'] for x in gpu if x['mode']!='uv-gradient')
missing=json.loads((out/'missing-program-results.json').read_text());assert missing['status']=='passed' and missing['referenceSelected'] and missing['allocatorZero']
capture=json.loads((out/'capture-results.json').read_text());assert capture['exitCode']==0 and len(capture['frames'])==4
assert all(capture[k] for k in ['validationClean','allocatorZero','sourceUnchanged','programsUnchanged','projectInputsUnchanged'])
manifest=json.loads((out/'capture-manifest.json').read_text());assert manifest['computedMaterialViewPipelines']>0 and manifest['computedMaterialViewSelectionsTotal']>0 and manifest['computedMaterialViewFrameEligible']
cost=json.loads((out/'cost-results.json').read_text());assert cost['productionEfficiencyPassed'] and all(cost['efficiencyCriteria'].values()) and cost['shortEnvironmentQualified']
reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames'
duplicates=[]
for frame in capture['frames']:
    path=out/'frames'/frame['name'];original=reference/frame['name']
    assert frame['changedPixels']==frame['maximumByteError']==0 and digest(path)==digest(original)==frame['sha256']==frame['referenceSha256']
    duplicates.append(dict(path=str(path),original=str(original),bytes=path.stat().st_size,sha256=digest(path)))
files=['CMakeLists.txt','shaders/mesh.frag','shaders/selected_receiver.glsl','src/render/ComputedMaterialView.hpp','src/scenes/CharacterComputedMaterialView.inc','src/scenes/CharacterMaterialUv.inc','src/scenes/CharacterMaterialSampling.inc','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','src/app/AzureRenderApp.cpp','tests/ComputedMaterialViewTests.cpp','tests/MaterialViewDeterminismGpuTests.cpp','tests/support/VulkanComputeFixture.hpp']
source={p:digest(root/p) for p in files}
result=dict(status='qualified-standard-depth-material-view-candidate',sourceBase='58294c7',productionSourceSha256=source,localQualification='d41f927',nativeQualification='e329f55',build=build,timeoutRefresh=refresh,gpuProcesses=gpu,missingProgram=missing,originalFour=capture,productionSelection={k:v for k,v in manifest.items() if k.startswith('computedMaterialView')},shortEfficiency=cost,shortGpuBudgetPassed=cost['rows'][1]['summary']['gpu']['p95']<=16.6,shortCpuBudgetPassed=cost['rows'][1]['summary']['cpu']['p95']<=8,formalPerformancePassed=False,fixed80WattsAccepted=False,productionAdopted=False,depthDisabledBoundaryPending=True,projectInputsExact=1729,protectedFilesExact=13,overall='failed-user-review')
(out/'results.json').write_text(json.dumps(result,indent=2));(out/'duplicate-frame-inventory.json').write_text(json.dumps(duplicates,indent=2))
dest=root/'docs/acceptance/nr/evidence/2026-11-11/material-viewquad-standard-depth';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={}
def add(z,path,name):
    assert name not in members;members[name]=dict(bytes=path.stat().st_size,sha256=digest(path));z.write(path,name)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.rglob('*')):
        if not p.is_file() or any(s in ['tmp','shader-preflight'] for s in p.relative_to(out).parts):continue
        if p.suffix in ['.json','.py','.log','.xml','.csv','.frag','.hpp','.cpp','.inc','.glsl']:add(z,p,'run/'+p.relative_to(out).as_posix())
    for name in files:add(z,root/name,'source/'+name)
    measured=json.loads((root/'build/runs/20261111-021128-quad-depth-visibility-local-qualification-1ea541/combined/compare-state.json').read_text())['programs']
    for p in measured:
        name=p['file'].replace('.frag.spv','_viewquad.frag.spv');path=root/'build/ninja-msvc-release/shaders'/name
        assert digest(path)==p['candidateSha256'];add(z,path,'programs/'+name)
    z.writestr('member-sha256.json',json.dumps(members,indent=2))
assert archive.stat().st_size<8*1024**2
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in members.items())
verification=dict(bytes=archive.stat().st_size,members=len(members)+1,sha256=digest(archive),memberHashesVerified=True)
(dest/'archive-verification.json').write_text(json.dumps(verification,indent=2));(dest/'results.json').write_text(json.dumps(result,indent=2))
for item in duplicates:
    path=Path(item['path']);assert path.parent.resolve()==(out/'frames').resolve()
    assert digest(path)==digest(Path(item['original']))==item['sha256'];path.unlink()
(out/'identical-frames-reclaimed.json').write_text(json.dumps(dict(files=len(duplicates),bytes=sum(x['bytes'] for x in duplicates),archive=verification),indent=2))
guard=root/'build/runs/20261111-015153-performance-continuation-inputs-fd65fd';receipt=guard/'viewquad-standard-depth-lease.json'
if not receipt.exists():receipt.write_text(json.dumps(dict(token=acquire_inputs(root/'build',guard,[out.name],'01a1c097-ec33-7790-8c18-08a2b0ddb0c3'),input=out.name),indent=2))
print(json.dumps(verification))
