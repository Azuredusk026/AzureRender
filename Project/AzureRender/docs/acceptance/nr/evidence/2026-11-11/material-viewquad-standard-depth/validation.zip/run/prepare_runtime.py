from pathlib import Path
import json,sys
root=Path.cwd();out=Path(__file__).resolve().parent;native=root/'build/runs/20261111-022601-quad-depth-combination-native-qualification-05d8c0'
text=(out/'capture.py').read_text()
text=text.replace("from artifact_maintenance import managed_environment","from artifact_maintenance import managed_environment")
text=text.replace("assert p.returncode==0 and len(frames)==4", "manifest=json.loads((out/'frames/capture_manifest.json').read_text());(out/'capture-manifest.json').write_text(json.dumps(manifest,indent=2))\nassert manifest['computedMaterialViewPipelines']>0 and manifest['computedMaterialViewSelectionsTotal']>0 and manifest['computedMaterialViewFrameEligible']\nassert manifest['computedMaterialViewFallback']=='ready'\nassert p.returncode==0 and len(frames)==4")
(out/'capture.py').write_text(text)
text=(native/'cost.py').read_text()
text=text.replace("from build_provenance import inputs,digest","from build_provenance import inputs,digest,verify\nfrom run_playable_performance import freeze_products")
text=text.replace("['featureRequestObserved','validationClean','allocatorZero','sourceUnchanged','productsUnchanged','privateProgramsUnchanged','projectInputsUnchanged']","['validationClean','allocatorZero','sourceUnchanged','programsUnchanged','projectInputsUnchanged']")
text=text.replace('planned=128*1024**2','planned=32*1024**2')
first=text.index("before=inputs(root);exe=");last=text.index("assert all(digest(Path(p))==h for p,h in products.items())",first)
text=text[:first]+"verify(root,json.loads((out/'release-build-provenance.json').read_text()))\nbefore=inputs(root);exe=build/'AzurePlayer.exe';products=freeze_products(root,exe,build/'AzureRender.exe')\n"+text[last:]
text=text.replace("runtime=out/('candidate' if label=='candidate' else 'reference')","runtime=build\n    if label=='candidate':os.environ.pop('AZURE_DISABLE_COMPUTED_MATERIAL_VIEW',None)\n    else:os.environ['AZURE_DISABLE_COMPUTED_MATERIAL_VIEW']='1'")
text=text.replace(" and 'Quad-demand device probe: quad-control and maximal-reconvergence requested' in log",'')
text=text.replace("('defaultIsolation','shadowHistory','surfaceRadiance')","('defaultIsolation','shadowHistory','surfaceRadiance','computedMaterialView')")
marker="    log=(folder/'process.log').read_text(errors='replace');"
assert text.count(marker)==1
text=text.replace(marker,"    if label=='candidate':assert data['computedMaterialViewPipelines']>0 and data['computedMaterialViewSelectionsTotal']>0 and data['computedMaterialViewFrameEligible'] and data['computedMaterialViewFallback']=='ready'\n    else:assert data['computedMaterialViewPipelines']==0 and data['computedMaterialViewSelectionsTotal']==0 and data['computedMaterialViewFallback']=='disabled'\n"+marker)
text=text.replace("metadata={k:v for k,v in data.items()", "modeEnvironment=dict(AZURE_DISABLE_COMPUTED_MATERIAL_VIEW=os.environ.get('AZURE_DISABLE_COMPUTED_MATERIAL_VIEW')),metadata={k:v for k,v in data.items()")
text=text.replace('privateEfficiencyPassed=','productionEfficiencyPassed=')
text+="\nos.environ.pop('AZURE_DISABLE_COMPUTED_MATERIAL_VIEW',None)\nverify(root,json.loads((out/'release-build-provenance.json').read_text()))\n"
(out/'cost.py').write_text(text)
print('Prepared production capture with actual selection assertions and same-host environment-controlled ABA')
