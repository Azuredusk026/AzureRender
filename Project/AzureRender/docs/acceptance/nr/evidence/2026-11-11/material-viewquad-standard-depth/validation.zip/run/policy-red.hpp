#pragma once
#include <cstdint>
#include <optional>
#include <string>
namespace azurerender {
struct ComputedMaterialViewInputs {
    float sceneLighting=0,isolationMode=0,effectMode=0,effectEnabled=0,reflectionSource=0;
};
struct ComputedMaterialViewCapabilities {
    std::uint32_t vendorId=0;
    bool quadControl=false,bindless=false,singleSample=false,referenceUv=false,experimentalReuse=false,depthAvailable=false;
};
constexpr bool computedMaterialViewEligible(const ComputedMaterialViewCapabilities&,const ComputedMaterialViewInputs&) noexcept {return false;}
inline std::optional<std::string> computedMaterialViewProgram(std::string){return std::nullopt;}
}
