from pathlib import Path
import os,sys,subprocess,shutil
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'))
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside',*sys.argv[1:]]).returncode)
mode='red' if '--red' in sys.argv else 'green'
if mode=='red':shutil.copyfile(out/'candidate-source/src/render/ComputedMaterialView.hpp',out/'policy-red.hpp')
command=['cl','/nologo','/EHsc','/std:c++17','/W4','/I'+str(out/'candidate-source/src'),'/Fo'+str(out/'policy.obj'),'/Fe'+str(out/'policy.exe'),str(out/'ComputedMaterialViewTests.cpp')]
with (out/(mode+'-compile.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
result=subprocess.run([str(out/'policy.exe')],capture_output=True,timeout=10)
(out/(mode+'-policy.log')).write_bytes(result.stdout+result.stderr)
if mode=='red':assert result.returncode!=0 and b'Qualified ordinary view must select' in result.stderr
else:assert result.returncode==0,result.stderr
print(mode,result.returncode,(result.stdout+result.stderr).decode().strip())
