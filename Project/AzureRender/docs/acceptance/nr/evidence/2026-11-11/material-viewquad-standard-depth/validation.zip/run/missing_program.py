from pathlib import Path
import os,json,sys,subprocess,time
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest,verify
os.environ.update(managed_environment(out/'tmp'));os.environ.update(DOTNET_ROOT='D:/Tools/dotnet9',VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer')
os.environ.pop('AZURE_DISABLE_COMPUTED_MATERIAL_VIEW',None)
build=root/'build/ninja-msvc-release';verify(root,json.loads((out/'release-build-provenance.json').read_text()));before=inputs(root)
producer=root/'build/runs/20261111-022601-quad-depth-combination-native-qualification-05d8c0'
runtime=producer/'reference';hashes=json.loads((producer/'reference-programs.json').read_text());assert len(hashes)==859
baseline=json.loads((out/'release-reference-programs.json').read_text())
assert all(baseline.get(n)==h and digest(runtime/'shaders'/n)==h for n,h in hashes.items())
assert not list((runtime/'shaders').glob('*_viewquad.frag.spv'))
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
folder=out/'missing-optional-program';folder.mkdir(exist_ok=True)
command=[str(build/'AzurePlayer.exe'),'--project',str(project),'--resource-root',str(runtime),'--width','640','--height','360','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','24','--smoke-frames','8','--gpu-timing','--gpu-timing-output',str(folder/'timing.json')]
(folder/'command.json').write_text(json.dumps(command,indent=2));start=time.monotonic()
with (folder/'process.log').open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
data=json.loads((folder/'timing.json').read_text());text=(folder/'process.log').read_text(errors='replace')
assert data['computedMaterialViewPipelines']==0 and data['computedMaterialViewSelectionsTotal']==0 and not data['computedMaterialViewFrameEligible']
assert data['computedMaterialViewFallback'] not in ['ready','disabled','build-disabled','unsupported-capability-or-policy']
assert 'Computed material view reference fallback:' in text and '_viewquad.frag.spv' in text
assert 'Allocator after unload: buffers=0 images=0' in text
assert not any(v in text for v in ['VUID-','SYNC-HAZARD','Validation Error:','Validation Warning:'])
assert inputs(root)==before and all(digest(runtime/'shaders'/n)==h for n,h in hashes.items())
verify(root,json.loads((out/'release-build-provenance.json').read_text()))
result=dict(status='passed',seconds=time.monotonic()-start,baselineProgramsExact=859,optionalProgramsAbsent=True,referenceSelected=True,validationClean=True,allocatorZero=True,metadata={k:v for k,v in data.items() if k.startswith('computedMaterialView')})
(out/'missing-program-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
