from pathlib import Path
import difflib, json, re, hashlib, sys
root=Path.cwd();out=Path(__file__).resolve().parent
native=root/'build/runs/20261111-022601-quad-depth-combination-native-qualification-05d8c0/source'
base=(root/'shaders/mesh.frag').read_text().splitlines(keepends=True)
variants=[(native/(name+'.frag')).read_text().splitlines(keepends=True) for name in ['main','snapshot']]
assert hashlib.sha256((native/'main.frag').read_bytes()).hexdigest()=='41fa15f0a8732239a77dd67ca2d70408d8ee8f887daaaf5555cc4778b5720183'
assert hashlib.sha256((native/'snapshot.frag').read_bytes()).hexdigest()=='c464953de1fd33be16d5d5a87f18d6613ee2b1901f13c89816a48e43faab478f'
ops=[difflib.SequenceMatcher(None,base,v,autojunk=False).get_opcodes() for v in variants]
intervals=[(a,b) for rows in ops for tag,a,b,c,d in rows if tag!='equal']
# A conditional branch must contain complete existing preprocessor groups.
groups=[];stack=[]
for i,line in enumerate(base):
    directive=re.match(r'\s*#\s*(if|ifdef|ifndef|elif|else|endif)\b',line)
    if not directive:continue
    kind=directive.group(1)
    if kind in ['if','ifdef','ifndef']:stack.append([i,[i]])
    elif kind in ['else','elif']:stack[-1][1].append(i)
    else:
        start,markers=stack.pop();groups.append((start,i+1,markers+[i]))
assert not stack
def expand(pair):
    start,end=pair
    while True:
        before=(start,end)
        for first,last,markers in groups:
            if any(start<=p<end for p in markers):start=min(start,first);end=max(end,last)
        if before==(start,end):return start,end
intervals=sorted(expand(x) for x in intervals);merged=[]
for first,last in intervals:
    if merged and first<=merged[-1][1]:merged[-1]=(merged[-1][0],max(last,merged[-1][1]))
    else:merged.append((first,last))
def segment(index,first,last):
    left={};right={}
    for tag,a,b,c,d in ops[index]:
        if tag=='equal':
            for n in range(a,b+1):left.setdefault(n,c+n-a);right[n]=c+n-a
        else:left.setdefault(a,c);right[b]=d
    return ''.join(variants[index][left[first]:right[last]])
generated=[];cursor=0;records=[]
for first,last in merged:
    generated+=base[cursor:first];original=''.join(base[first:last]);main=segment(0,first,last);snapshot=segment(1,first,last)
    if main==snapshot:
        text='#if defined(AZURE_COMPUTED_MATERIAL_VIEW)\n'+main+'#else\n'+original+'#endif\n'
    elif snapshot==original:
        text='#if defined(AZURE_COMPUTED_MATERIAL_VIEW) && !defined(AZURE_OPAQUE_SNAPSHOT)\n'+main+'#else\n'+original+'#endif\n'
    else:
        text='#if defined(AZURE_COMPUTED_MATERIAL_VIEW)\n#if !defined(AZURE_OPAQUE_SNAPSHOT)\n'+main+'#else\n'+snapshot+'#endif\n#else\n'+original+'#endif\n'
    generated.append(text);records.append(dict(firstLine=first+1,lastLine=last,mainEqualsSnapshot=main==snapshot,snapshotEqualsReference=snapshot==original));cursor=last
generated+=base[cursor:]
(out/'mesh-reference.frag').write_text(''.join(base))
destination=out/'woven_mesh.frag' if '--dry-run' in sys.argv else root/'shaders/mesh.frag'
destination.write_text(''.join(generated))
(destination.parent/'selected_receiver.glsl').write_bytes((native/'selected_receiver.glsl').read_bytes())
(out/'shader-weave.json').write_text(json.dumps(records,indent=2))
print('Wove',len(merged),'balanced regions from exact qualified main/snapshot templates')
