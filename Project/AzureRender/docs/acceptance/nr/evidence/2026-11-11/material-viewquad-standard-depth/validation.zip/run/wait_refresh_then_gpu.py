from pathlib import Path
import subprocess,sys,time,shutil
root=Path.cwd();out=Path(__file__).resolve().parent
if not (out/'gpu-before-timeout-fix.log').exists():shutil.copyfile(out/'process.log',out/'gpu-before-timeout-fix.log')
if not (out/'gpu-before-timeout-fix.py').exists():(out/'gpu-before-timeout-fix.py').write_text((out/'gpu.py').read_text().replace('timeout=480','timeout=210'))
common=[sys.executable,'-X','utf8','-B','tools/shared_resources.py','run','--owner','01a1c097-ec33-7790-8c18-08a2b0ddb0c3','--run',out.name]
for task,script,timeout in [('material-viewquad-timeout-refresh','refresh_timeout.py',400),('material-viewquad-production-gpu','gpu.py',2000)]:
    if script=='refresh_timeout.py' and (out/'timeout-refresh.json').exists():continue
    start=time.monotonic()
    while True:
        result=subprocess.run([*common,'--task',task,'--timeout',str(timeout),'--command',sys.executable,'-X','utf8','-B',str(out/script)],capture_output=True)
        (out/(task+'-queue.log')).write_bytes(result.stdout+result.stderr)
        if result.returncode==0:print(task+' passed',flush=True);break
        if b'Shared resource busy or inaccessible' not in result.stderr or time.monotonic()-start>180:
            print((result.stdout+result.stderr).decode(errors='replace'),flush=True);raise SystemExit(result.returncode)
        time.sleep(5)
