from pathlib import Path
import os,json,sys,subprocess,time
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify,digest
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'))
assert len(json.loads((out/'build-results.json').read_text()))==2
before=inputs(root);assert before==json.loads((out/'source-lock.json').read_text());rows=[]
for config in ['release','debug']:
    build=root/('build/ninja-msvc-'+config);verify(root,json.loads((out/(config+'-build-provenance.json')).read_text()))
    for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
        os.environ['VK_LOADER_DRIVERS_SELECT']=driver
        for mode in ['computed','reference','uv-gradient']:
            folder=out/(config+'-'+device+'-'+mode);folder.mkdir(exist_ok=True);start=time.monotonic()
            if mode=='uv-gradient':
                command=[str(build/'AzureMaterialUvGradientsGpuTests.exe'),str(build/'shaders/material_uv_gradients_test.vert.spv'),str(build/'shaders/material_uv_gradients_test.frag.spv')]
            else:
                command=[str(build/'AzureMaterialViewDeterminismGpuTests.exe'),str(build/'shaders'),str(folder)]
                if mode=='computed':command+=['--computed-viewquad']
            (folder/'command.json').write_text(json.dumps(command,indent=2))
            with (folder/'process.log').open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=480)
            text=(folder/'process.log').read_text(errors='replace')
            assert ('Intel' if device=='intel' else 'NVIDIA') in text
            assert not any(v in text for v in ['VUID-','SYNC-HAZARD','Validation Error:','Validation Warning:'])
            if mode!='uv-gradient':
                result=json.loads((folder/'results.json').read_text());assert result['validationErrors']==0 and result['zeroAllocator']
                if mode=='computed':assert result['eligibleChecks']==(28 if device=='nvidia' else 0) and result['fallbackChecks']==(242 if device=='nvidia' else 270),result
                assert result['pixelsCompared']==(299520 if mode=='computed' else 199680),result
            else:result=dict(output=text)
            row=dict(config=config,device=device,mode=mode,seconds=time.monotonic()-start,result=result);rows.append(row)
            (out/'gpu-results.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
    verify(root,json.loads((out/(config+'-build-provenance.json')).read_text()))
assert len(rows)==12 and inputs(root)==before
assert all(digest(root/p)==h for p,h in json.loads((out/'protected-files.json').read_text()).items())
