from pathlib import Path
out=Path(__file__).resolve().parent
text=(out/'seal.py').read_text()
text=text.replace("status='qualified-production-computed-material-view'","status='qualified-standard-depth-material-view-candidate'")
text=text.replace('productionAdopted=True','productionAdopted=False,depthDisabledBoundaryPending=True')
text=text.replace("11/material-viewquad-production';dest","11/material-viewquad-standard-depth';dest")
text=text.replace("guard/'viewquad-production-lease.json'","guard/'viewquad-standard-depth-lease.json'")
assert "11/material-viewquad-standard-depth';dest" in text
(out/'seal-standard-depth.py').write_text(text)
print('Prepared standard-depth candidate seal; production adoption remains pending depth-disabled boundary')
