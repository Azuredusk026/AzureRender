from pathlib import Path
import json,subprocess,sys,os
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'))
subprocess.run([sys.executable,'-X','utf8','-B',str(out/'weave_shader.py'),'--dry-run'],check=True)
qualified=root/'build/runs/20261111-021128-quad-depth-visibility-local-qualification-1ea541/combined'
measured=json.loads((qualified/'compare-state.json').read_text())['programs'];assert len(measured)==10
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text())
folder=out/'shader-preflight';folder.mkdir(exist_ok=True);rows=[]
with (out/'shader-preflight.log').open('wb') as log:
    for target in measured:
        program=next(p for p in manifest['programs'] if p['output']==target['file'])
        for mode in ['reference','candidate']:
            args=list(program['arguments']);defines=list(program['defines'])
            if mode=='candidate':args+=['--target-env=vulkan1.1'];defines+=['AZURE_COMPUTED_MATERIAL_VIEW=1','AZURE_FRAGMENT_QUAD_OPERATIONS=1']
            path=folder/(mode+'-'+program['output'])
            command=[manifest['compiler'],*args,*['-D'+v for v in defines],'-I'+str(root/'shaders'),str(out/'woven_mesh.frag'),'-o',str(path)]
            subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
            subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.3',str(path)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=15)
            expected=target['candidateSha256'] if mode=='candidate' else digest(root/'build/ninja-msvc-release/shaders'/program['output'])
            row=dict(mode=mode,program=program['output'],sha256=digest(path),expectedSha256=expected,exact=digest(path)==expected,command=command);rows.append(row)
            (out/'shader-preflight-results.json').write_text(json.dumps(rows,indent=2))
            assert row['exact'],row
print('20 compiled programs validated: ten prior references and ten measured candidates byte-identical')
