from pathlib import Path
import json,sys,os,subprocess,shutil,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
before=json.loads((out/'source-lock.json').read_text());after=inputs(root)
assert {n for n in before.keys()|after.keys() if before.get(n)!=after.get(n)}=={'CMakeLists.txt'}
shutil.copyfile(out/'source-lock.json',out/'source-lock-before-gpu-timeout-fix.json')
shutil.copyfile(out/'gpu.py',out/'gpu-after-timeout-fix.py')
failed=(out/'release-nvidia-computed').resolve();destination=(out/'release-nvidia-computed-before-timeout-fix').resolve()
assert failed.parent==out.resolve() and destination.parent==out.resolve() and not destination.exists()
failed.rename(destination)
reports=[]
for config in ['release','debug']:
    build=root/('build/ninja-msvc-'+config);old=json.loads((out/(config+'-build-provenance.json')).read_text())
    assert all(digest(Path(p))==h for p,h in old['products'].items())
    shutil.copyfile(out/(config+'-build-provenance.json'),out/(config+'-provenance-before-timeout-fix.json'))
    targets=old['buildScope']['testProducts'].keys()
    command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config.title()]
    for target in targets:command+=['--test-target',target]
    start=time.monotonic()
    with (out/(config+'-timeout-refresh.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
    proof=json.loads((build/'build-provenance.json').read_text());verify(root,proof)
    changed={p:[old['products'].get(p),proof['products'].get(p)] for p in old['products'].keys()|proof['products'].keys() if old['products'].get(p)!=proof['products'].get(p)}
    (out/(config+'-timeout-product-diff.json')).write_text(json.dumps(changed,indent=2))
    assert not changed,'Timeout metadata must preserve every actual runtime and test product byte'
    shutil.copyfile(build/'build-provenance.json',out/(config+'-build-provenance.json'))
    reports.append(dict(config=config,seconds=time.monotonic()-start,allRuntimeAndTestProductsExact=True,priorTwelveChecksReused=True))
assert inputs(root)==after
(out/'source-lock.json').write_text(json.dumps(after,indent=2))
(out/'timeout-refresh.json').write_text(json.dumps(dict(reason='27 views with resize require 54 pipeline preparations; continuous compiler progress at initial 210-second process bound',testCasesUnchanged=True,originalCTestTimeoutSeconds=180,originalProcessTimeoutSeconds=210,currentTimeoutSeconds=480,configs=reports),indent=2))
print(json.dumps(reports))
