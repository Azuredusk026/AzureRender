from pathlib import Path
import ctypes,json,time,sys
out=Path(__file__).resolve().parent;pid=int(sys.argv[1]);receipt=out/'queue-window.json'
kernel=ctypes.WinDLL('kernel32',use_last_error=True);ntdll=ctypes.WinDLL('ntdll')
kernel.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32];kernel.OpenProcess.restype=ctypes.c_void_p
kernel.CloseHandle.argtypes=[ctypes.c_void_p]
ntdll.NtSuspendProcess.argtypes=ntdll.NtResumeProcess.argtypes=[ctypes.c_void_p]
handle=kernel.OpenProcess(0x0800,False,pid)
if not handle:raise ctypes.WinError(ctypes.get_last_error())
state=dict(ownedRuntimeDriverPid=pid,state='suspending',reason='Let the current managed child finish, then give the quality stream its requested queue window')
def save():receipt.write_text(json.dumps(state,indent=2))
save();suspended=False
try:
    assert ntdll.NtSuspendProcess(handle)==0;suspended=True;state['state']='driver-suspended';save();start=time.monotonic()
    queue=Path('D:/Projects/FYP-coordination/resources/current.json')
    while True:
        current=json.loads(queue.read_text()) if queue.exists() else {}
        if current.get('state')!='held' or current.get('owner')!='01a1c097-ec33-7790-8c18-08a2b0ddb0c3':break
        if time.monotonic()-start>300:raise TimeoutError('Current managed child did not release its lease')
        time.sleep(2)
    state.update(state='quality-window-open',windowSeconds=120);save();print('Quality queue window open for at least 120 seconds',flush=True);start=time.monotonic()
    while time.monotonic()-start<120:time.sleep(2)
finally:
    if suspended:assert ntdll.NtResumeProcess(handle)==0
    kernel.CloseHandle(handle);state['state']='driver-resumed';save();print('Owned runtime driver resumed',flush=True)
