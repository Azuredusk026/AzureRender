from pathlib import Path
import json,sys,shutil,subprocess
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261111-034457-scene-reference-camera-main-integration-80b1fd';sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,inputs,digest
for config in ['release','debug']:
    proof=json.loads((prior/(config+'-build-provenance.json')).read_text());verify(root,proof)
    shutil.copyfile(prior/(config+'-program-sha256.json'),out/(config+'-reference-programs.json'))
    shutil.copyfile(prior/(config+'-build-provenance.json'),out/(config+'-reference-provenance.json'))
for name in ['protected-files.json','frozen-project-inputs.json','baseline-dlls.json','capture.py']:
    shutil.copyfile(prior/name,out/name)
shutil.copyfile(prior/'host-identities.json',out/'reference-host-identities.json')
(out/'reference-source.json').write_text(json.dumps(inputs(root),indent=2))
assert (out/'red-policy.log').read_text().startswith('Qualified ordinary view must select')
assert '128 canonical programs' in (out/'green-policy.log').read_text()
rows=json.loads((out/'shader-preflight-results.json').read_text());assert len(rows)==20 and all(r['exact'] for r in rows)
for source,destination in [('candidate-source/src/render/ComputedMaterialView.hpp','src/render/ComputedMaterialView.hpp'),('candidate-source/CharacterComputedMaterialView.inc','src/scenes/CharacterComputedMaterialView.inc'),('ComputedMaterialViewTests.cpp','tests/ComputedMaterialViewTests.cpp')]:
    shutil.copyfile(out/source,root/destination)
subprocess.run([sys.executable,'-X','utf8','-B',str(out/'weave_shader.py')],check=True)
print('Frozen current two-configuration source/products; promoted qualified policy and balanced shader')
