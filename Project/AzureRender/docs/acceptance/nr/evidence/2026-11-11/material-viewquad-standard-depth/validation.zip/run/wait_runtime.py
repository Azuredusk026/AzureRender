from pathlib import Path
import json,sys,subprocess,time
root=Path.cwd();out=Path(__file__).resolve().parent;start=time.monotonic()
while True:
    try:ready=len(json.loads((out/'gpu-results.json').read_text()))==12
    except (FileNotFoundError,json.JSONDecodeError):ready=False
    if ready:break
    if time.monotonic()-start>2000:raise TimeoutError('GPU qualification not completed within the declared device-check budget')
    time.sleep(5)
print('All GPU rows present; yielding a sixty-second queue window to the quality stream',flush=True)
time.sleep(60)
common=[sys.executable,'-X','utf8','-B','tools/shared_resources.py','run','--owner','01a1c097-ec33-7790-8c18-08a2b0ddb0c3','--run',out.name]
for task,script,timeout,resultFile in [('material-viewquad-missing-program','missing_program.py',200,'missing-program-results.json'),('material-viewquad-original-four','capture.py',600,'capture-results.json'),('material-viewquad-short-aba','cost.py',1000,'cost-results.json')]:
    if (out/resultFile).exists():print(task+' already has a result; inspect before repeating',flush=True);continue
    start=time.monotonic()
    while True:
        result=subprocess.run([*common,'--task',task,'--timeout',str(timeout),'--command',sys.executable,'-X','utf8','-B',str(out/script)],capture_output=True)
        (out/(task+'-queue.log')).write_bytes(result.stdout+result.stderr)
        if result.returncode==0:print(task+' exited successfully',flush=True);break
        if b'Shared resource busy or inaccessible' not in result.stderr or time.monotonic()-start>180:
            print((result.stdout+result.stderr).decode(errors='replace'),flush=True);raise SystemExit(result.returncode)
        time.sleep(5)
print('Runtime stages ended; inspect actual efficiency and gate results before sealing',flush=True)
