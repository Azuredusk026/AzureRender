param([Parameter(Mandatory=$true)][string]$Plan)
$ErrorActionPreference='Stop'
$qualityPlan=Get-Content -LiteralPath $Plan -Raw | ConvertFrom-Json
$qualityRoot=(Resolve-Path -LiteralPath $qualityPlan.root).Path.TrimEnd('\')+'\'
$qualityStarted=Get-Date
for($qualityAt=0;$qualityAt -lt $qualityPlan.items.Count;$qualityAt+=10){
 if(((Get-Date)-$qualityStarted).TotalSeconds -gt 120){throw 'Maintenance budget exceeded'}
 $qualityQueue=Get-Content -LiteralPath D:/Projects/FYP-coordination/resources/current.json -Raw | ConvertFrom-Json
 if($qualityQueue.state -ne 'held' -or $qualityQueue.owner -ne '01a1c099-8121-7be3-b0b8-7af2f9a06b2a' -or $qualityQueue.task -ne 'quality-cull-debug-budget'){throw 'Expected exclusive resource lease'}
 for($qualityIndex=$qualityAt;$qualityIndex -lt [Math]::Min($qualityAt+10,$qualityPlan.items.Count);$qualityIndex++){
  $qualityItem=$qualityPlan.items[$qualityIndex];$qualityPath=(Resolve-Path -LiteralPath $qualityItem.path).Path
  if(-not $qualityPath.StartsWith($qualityRoot,[StringComparison]::OrdinalIgnoreCase)){throw 'Path leaves owned Debug build'}
  if($qualityItem.kind -eq 'directory'){
   if((Split-Path $qualityPath -Parent) -ne ($qualityRoot+'CMakeFiles') -or -not $qualityPath.EndsWith('Tests.dir',[StringComparison]::OrdinalIgnoreCase)){throw 'Unexpected intermediate directory'}
   if((Get-ChildItem -LiteralPath $qualityPath -Recurse -Force | Where-Object {($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0}).Count){throw 'Intermediate directory contains a link'}
   Remove-Item -LiteralPath $qualityPath -Recurse
  }else{
   if((Split-Path $qualityPath -Parent) -ne $qualityRoot.TrimEnd('\') -or -not $qualityPath.EndsWith('Tests.exe',[StringComparison]::OrdinalIgnoreCase)){throw 'Unexpected symbol file'}
   Remove-Item -LiteralPath $qualityPath
  }
 }
}
Write-Output ('Reclaimed '+$qualityPlan.items.Count+' explicit rebuildable artifact entries')
