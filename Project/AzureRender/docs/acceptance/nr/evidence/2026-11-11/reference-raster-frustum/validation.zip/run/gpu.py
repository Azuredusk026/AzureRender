from pathlib import Path
import sys,json,hashlib,subprocess,os,re
out=Path(__file__).resolve().parent;root=out.parents[2];c=sys.argv[1].lower();build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if c=='release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for n,v in json.loads((out/'frozen-source.json').read_text()).items():assert sha(root/n)==v,n
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*' if device=='nvidia' else '*igvk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(build)+';'+env['PATH'])
 command=[str(build/'AzureReferenceRasterFrustumGpuTests.exe'),str(build/'shaders/cull_indirect.comp.spv'),str(out.parent/'20261110-165124-reference-depth-source-4d1d7d/native-profile.bin'),str(out.parent/'20261111-001326-reference-position-frame-482201/native-frame.bin'),str(out.parent/'20261111-001326-reference-position-frame-482201/native-world-positions.bin')];label=c+'-'+device
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(command,env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 t=(out/(label+'.log')).read_text(errors='replace');row=dict(configuration=c,device=device,command=command,exitCode=r.returncode,validationClean=not bool(re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)',t,re.I)),stdout=t.strip());rows.append(row);(out/(c+'-gpu-results.json')).write_text(json.dumps(rows,indent=2)+'\n');assert r.returncode==0 and row['validationClean'],t[-5000:];assert '32045 exact mixed-frustum draw records' in t,t;print(label,t.strip(),flush=True)
