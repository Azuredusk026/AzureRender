from pathlib import Path
import hashlib,json
out=Path(__file__).resolve().parent;root=out.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((root/'docs/acceptance/nr/evidence/2026-11-11/conservative-frustum-transport/results.json').read_text())
build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
old=next(v for v in prior['identities'] if v['configuration']=='release')
catalog=json.loads((root/'docs/acceptance/nr/evidence/2026-11-11/conservative-frustum-transport/program-catalog.json').read_text())['sha256']
result=dict(playerSha256=sha(build/'AzurePlayer.exe'),priorPlayerSha256=old['playerSha256'],exactPrograms=sum(sha(build/'shaders'/n)==h for n,h in catalog.items()),programs=len(catalog))
result['playerExact']=result['playerSha256']==result['priorPlayerSha256']
(out/'release-identity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
