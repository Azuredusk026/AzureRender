from pathlib import Path
out=Path(__file__).resolve().parent
prior=out.parent/'20261111-034117-reference-conservative-frustum-f4c8f9'
(out/'prepare-four.py').write_bytes((prior/'prepare-four.py').read_bytes())
source=(prior/'analyze.py').read_text()
source=source.replace('reference-raster-projection/program-catalog.json','conservative-frustum-transport/program-catalog.json')
source=source.replace('len(data)==6','len(data)==2')
source=source.replace("assert set(changed)=={'cull_indirect.comp.spv','visibility_prototype.comp.spv'}",'assert changed==[]')
source=source.replace('oldProgramsExact=857','oldProgramsExact=859')
start=source.index("cpu=json.loads");end=source.index("four=json.loads",start)
source=source[:start]+source[end:]
source=source.replace("debug-initial-budget-execution.json", "debug-budget-stopped-execution.json")
source=source.replace("assert reclaim['protectedProductsExact']==895", "assert reclaim['protectedProductsExact']>=880")
source=source.replace("qualified-conservative-frustum-transport", "qualified-reference-raster-frustum").replace("baseCommit='6483e03'", "baseCommit='e931a86'")
source=source.replace('cpu=cpu,','').replace('drawRecordsPerEndpoint=49160,exactDrawRecords=196640','drawRecordsPerEndpoint=32045,exactDrawRecords=128180')
source=source.replace("'Reference XYW/device depth mixed plane preparation',",'')
source=source.replace('gpuProcesses=12,cpuProcesses=4,exactDrawRecords=196640','gpuProcesses=4,exactDrawRecords=128180')
(out/'analyze.py').write_text(source)
failure=out/'debug-final-build-execution.json'
assert 'budget-stopped' in failure.read_text()
(out/'debug-budget-stopped-execution.json').write_bytes(failure.read_bytes())
print('Prepared identity/image checks; retained interrupted Debug build result')
