from pathlib import Path
import json,zipfile,hashlib,re
out=Path(__file__).resolve().parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=json.loads((out/'results.json').read_text());plan=root/'docs/plans/2026-11-11-reference-raster-frustum.md';plan.write_text(plan.read_text(encoding='utf-8').replace('- [ ]','- [x]'),encoding='utf-8')
for name,prefix in [('README.md','docs/'),('docs/project-status.md',''),('docs/plans/azure-engine-plan.md','../'),('docs/plans/2026-11-09-native-quality.md','../')]:
 p=root/name;text=p.read_text(encoding='utf-8')
 if '[参考光栅混合视锥]' not in text:text+='\n[参考光栅混合视锥]('+prefix+'acceptance/nr/reference-raster-frustum.md)完成两配置、两设备检查。\n有界参数、退化回退及原四帧通过，光栅与拾取继续接入。\n'
 p.write_text(text,encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');anchor='## 2026-11-11 保守剔除参数'
if '## 2026-11-11 参考光栅混合视锥' not in text:text=text.replace(anchor,'## 2026-11-11 参考光栅混合视锥\n\n- 准备参考横纵平面及设备深度平面的有界保守参数。\n- 参考与设备零齐次尺度区间共用现有 128 字节布局。\n- 两配置、两设备共 128180 条绘制记录精确核对。\n- 859 份程序及原四帧保持摘要一致。\n\n'+anchor)
p.write_text(text,encoding='utf-8')
sources=list(result['sourceSha256'])+['docs/runtime/reference-raster-frustum.md','docs/plans/2026-11-11-reference-raster-frustum.md','docs/acceptance/nr/reference-raster-frustum.md'];files={'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.ps1','.json','.log','.cpp','.hpp','.spv'}};files.update({'source/'+n:root/n for n in sources})
files.update({'input/native-profile.bin':out.parent/'20261110-165124-reference-depth-source-4d1d7d/native-profile.bin','input/native-frame.bin':out.parent/'20261111-001326-reference-position-frame-482201/native-frame.bin','input/native-world-positions.bin':out.parent/'20261111-001326-reference-position-frame-482201/native-world-positions.bin'})
dest=root/'docs/acceptance/nr/evidence/2026-11-11/reference-raster-frustum';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result['archive']=dict(bytes=archive.stat().st_size,sha256=sha(archive),members=len(members)+1);(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n');(dest/'program-catalog.json').write_bytes((out/'program-catalog.json').read_bytes())
for n in [v for v in sources if v.endswith('.md')]:
 p=root/n;text=p.read_text(encoding='utf-8')
 for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(n,sentence)
 for link in re.findall(r'\]\(([^)]+)\)',text):
  if not re.match(r'(https?:|#)',link):assert (p.parent/link.split('#')[0]).exists(),(n,link)
print(json.dumps(result['archive']))
