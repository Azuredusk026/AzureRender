from pathlib import Path
out=Path(__file__).resolve().parent
for name in ['debug-build.log','debug-internal-preflight.log']:
 p=out/name;target=out/('budget-stopped-'+name)
 if not target.exists():target.write_bytes(p.read_bytes())
print('Preserved initial build/preflight logs')
