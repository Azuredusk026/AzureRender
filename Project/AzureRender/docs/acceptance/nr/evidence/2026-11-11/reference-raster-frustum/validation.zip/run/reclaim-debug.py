from pathlib import Path
import sys,json,hashlib,subprocess,time
out=Path(__file__).resolve().parent;root=out.parents[2];build=out.parent/'20261110-031856-hair-main-chroma-debug-668bf2/debug';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
names=['AzureVisibilityGpuTests','AzureRenderFrameTaskSchedulerTests','AzureProjectReferenceViewsTests','AzureProjectTests','AzureConservativeCullingGpuTests','AzureReferenceRasterProjectionGpuTests','AzureReferenceDepthGpuTests','AzureReferencePositionFrameGpuTests','AzureMaterialUvPolicyTests','AzureMaterialPipelinePolicyTests']
with s.lease(s.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-cull-debug-budget',out):
 items=[]
 for p in [build/'CMakeFiles'/(n+'.dir') for n in names]+[build/(n+'.exe') for n in names]:
  assert p.exists() and p.resolve().is_relative_to(build.resolve()) and not p.is_symlink()
  files=[f for f in p.rglob('*') if f.is_file()] if p.is_dir() else [p]
  assert all(not f.is_symlink() and f.resolve().is_relative_to(build.resolve()) for f in files)
  assert not subprocess.run(['git','ls-files','--',str(p)],cwd=root,capture_output=True,text=True,check=True).stdout
  items.append(dict(path=str(p.resolve()),kind='directory' if p.is_dir() else 'file',bytes=sum(f.stat().st_size for f in files),files={str(f):sha(f) for f in files}))
 protected=[p for p in build.glob('*.exe') if p.stem not in names]+list(build.glob('*.lib'))+list((build/'shaders').glob('*.spv'));before={str(p):sha(p) for p in protected};plan=dict(root=str(build.resolve()),items=items,protectedSha256=before);(out/'debug-reclaim-plan.json').write_text(json.dumps(plan,indent=2)+'\n');started=time.monotonic()
 r=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','RemoteSigned','-File',str(out/'reclaim-debug.ps1'),'-Plan',str(out/'debug-reclaim-plan.json')],capture_output=True,text=True,timeout=120);(out/'debug-reclaim.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
 assert all(not Path(item['path']).exists() for item in items);assert all(sha(Path(p))==v for p,v in before.items())
 result=dict(status='reclaimed-owned-rebuildable-debug-intermediates',items=len(items),batches=(len(items)+9)//10,logicalBytes=sum(item['bytes'] for item in items),protectedProductsExact=len(before),seconds=time.monotonic()-started);(out/'debug-reclaim-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
