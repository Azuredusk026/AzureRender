from pathlib import Path
import sys,json,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files=['CMakeLists.txt','src/render/ReferenceCameraView.hpp','src/render/ReferenceRasterFrustum.hpp','tests/ReferenceRasterFrustumGpuTests.cpp'];(out/'frozen-source.json').write_text(json.dumps({n:sha(root/n) for n in files},indent=2)+'\n')
for n in ['20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2']:s.maintenance.resume(root/'build',n)
old=out.parent/'20261111-034117-reference-conservative-frustum-f4c8f9';source=(old/'build.py').read_text();at=source.index('targets=');end=source.index('\nif configuration',at);source=source[:at]+"targets=['AzureReferenceRasterFrustumGpuTests','AzurePlayer']"+source[end:];(out/'build.py').write_text(source);(out/'queued-build.py').write_text((old/'queued-build.py').read_text().replace('quality-conservative-frustum-','quality-reference-raster-frustum-'));print('Four mixed-frustum sources frozen; no shader changes')
