from pathlib import Path
out=Path(__file__).resolve().parent;prior=out.parent/'20261111-034117-reference-conservative-frustum-f4c8f9'
source=(prior/'archive.py').read_text(encoding='utf-8')
source=source.replace('2026-11-11-conservative-frustum-transport.md','2026-11-11-reference-raster-frustum.md')
source=source.replace('conservative-frustum-transport','reference-raster-frustum').replace('runtime/conservative-frustum.md','runtime/reference-raster-frustum.md')
start=source.index('for name,prefix');end=source.index('sources=list',start)
source=source[:start]+'''for name,prefix in [('README.md','docs/'),('docs/project-status.md',''),('docs/plans/azure-engine-plan.md','../'),('docs/plans/2026-11-09-native-quality.md','../')]:
 p=root/name;text=p.read_text(encoding='utf-8')
 if '[参考光栅混合视锥]' not in text:text+='\\n[参考光栅混合视锥]('+prefix+'acceptance/nr/reference-raster-frustum.md)完成两配置、两设备检查。\\n有界参数、退化回退及原四帧通过，光栅与拾取继续接入。\\n'
 p.write_text(text,encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');anchor='## 2026-11-11 保守剔除参数'
if '## 2026-11-11 参考光栅混合视锥' not in text:text=text.replace(anchor,'## 2026-11-11 参考光栅混合视锥\\n\\n- 准备参考横纵平面及设备深度平面的有界保守参数。\\n- 参考与设备零齐次尺度区间共用现有 128 字节布局。\\n- 两配置、两设备共 128180 条绘制记录精确核对。\\n- 859 份程序及原四帧保持摘要一致。\\n\\n'+anchor)
p.write_text(text,encoding='utf-8')
'''+source[end:]
source=source.replace("dest=root/", "files.update({'input/native-profile.bin':out.parent/'20261110-165124-reference-depth-source-4d1d7d/native-profile.bin','input/native-frame.bin':out.parent/'20261111-001326-reference-position-frame-482201/native-frame.bin','input/native-world-positions.bin':out.parent/'20261111-001326-reference-position-frame-482201/native-world-positions.bin'})\ndest=root/")
(out/'archive.py').write_text(source,encoding='utf-8')
print('Archive driver prepared; requires completed results and acceptance document')
