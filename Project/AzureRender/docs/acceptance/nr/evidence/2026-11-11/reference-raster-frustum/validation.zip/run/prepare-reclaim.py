from pathlib import Path
import json
out=Path(__file__).resolve().parent
prior=out.parent/'20261111-034117-reference-conservative-frustum-f4c8f9'
source=(prior/'reclaim-debug.py').read_text()
start=source.index('names=');end=source.index('\nwith s.lease',start)
source=source[:start]+"names=['AzureVisibilityGpuTests','AzureRenderFrameTaskSchedulerTests','AzureProjectReferenceViewsTests','AzureProjectTests','AzureConservativeCullingGpuTests','AzureReferenceRasterProjectionGpuTests','AzureReferenceDepthGpuTests','AzureReferencePositionFrameGpuTests','AzureMaterialUvPolicyTests','AzureMaterialPipelinePolicyTests']"+source[end:]
source=source.replace("+sorted(build.glob('*Tests.pdb'))", "+[build/(n+'.exe') for n in names]")
source=source.replace("protected=list(build.glob('*.exe'))", "protected=[p for p in build.glob('*.exe') if p.stem not in names]")
(out/'reclaim-debug.py').write_text(source)
ps=(prior/'reclaim-debug.ps1').read_text().replace("$qualityPath.EndsWith('Tests.pdb'", "$qualityPath.EndsWith('Tests.exe'")
(out/'reclaim-debug.ps1').write_text(ps)
