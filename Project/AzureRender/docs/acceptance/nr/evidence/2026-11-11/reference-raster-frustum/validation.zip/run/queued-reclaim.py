from pathlib import Path
import runpy,time
out=Path(__file__).resolve().parent
started=time.monotonic()
while True:
 try:
  runpy.run_path(str(out/'reclaim-debug.py'),run_name='__main__')
  break
 except ValueError as e:
  if 'busy' not in str(e) or time.monotonic()-started>=180:raise
  time.sleep(1)
