from pathlib import Path
import json, os, subprocess, sys, shutil, time, xml.etree.ElementTree as ET
root=Path.cwd().resolve(); out=Path(__file__).resolve().parent; prior=out.parent
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,verify,digest
os.environ.update(managed_environment(prior/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1',VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
if '--inside' not in sys.argv: raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
before=inputs(root); (out/'source-lock.json').write_text(json.dumps(before,indent=2))
targets=['AzureComputedMaterialDepthPolicyRecordingTests','AzureComputedMaterialViewTests','AzureMaterialViewDeterminismGpuTests','AzureDepthPrefillRecordingTests','AzureMotionRecordingTests','AzureMaterialPipelinePolicyTests','AzureMaterialUvPolicyTests','AzureMaterialUvGradientsGpuTests','AzureShaderCompilerContractTests','AzureHotReloadTests','AzureProjectedReflectionSceneTests','AzureReferenceCameraSelectionTests','AzureReferenceCameraMacroTests']
selector=r'^(AzureRender\.(ComputedMaterialView|DepthPrefillRecording|MotionRecording|MaterialPipelinePolicy|MaterialUvPolicy|ShaderCompilerContract|ShaderCatalogCompilation|HotReload|ReferenceCameraMacro)|AzureRuntime\.ReferenceCameraSelection|AzureEngine\.(ModuleBoundaries|ModuleBoundaryFixtures))$'
checks=[]
for config in ['Release','Debug']:
    label=config.lower(); build=root/('build/ninja-msvc-'+label); start=time.monotonic()
    with (out/(label+'-configure.log')).open('wb') as log: subprocess.run(['cmake','-S',str(root),'-B',str(build),'-U','AZURE_ENABLE_COMPUTED_MATERIAL_VIEW'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
    assert 'AZURE_ENABLE_COMPUTED_MATERIAL_VIEW:BOOL=OFF' in (build/'CMakeCache.txt').read_text()
    previous=json.loads((prior/(label+'-program-sha256.json')).read_text())
    aliases={k:v for k,v in previous.items() if k.endswith('_viewquad.frag.spv')}; assert len(aliases)==128
    shader_dir=(build/'shaders').resolve()
    stale=list(shader_dir.glob('*_viewquad.frag.spv'))
    assert all(path.resolve().parent==shader_dir and aliases[path.name]==digest(path) for path in stale)
    for path in stale: path.unlink()
    command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
    for target in targets: command+=['--test-target',target]
    with (out/(label+'-build.log')).open('wb') as log: subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
    manifest=json.loads((build/'shader-reload.json').read_text()); assert len(manifest['programs'])==860
    hashes={p['output']:digest(shader_dir/p['output']) for p in manifest['programs']}
    assert hashes=={k:v for k,v in previous.items() if k not in aliases}
    assert not list(shader_dir.glob('*_viewquad.frag.spv'))
    (out/(label+'-program-sha256.json')).write_text(json.dumps(hashes,indent=2))
    shutil.copyfile(build/'build-provenance.json',out/(label+'-build-provenance.json'))
    command=['ctest','--test-dir',str(build),'-C',config,'--output-on-failure','--no-tests=error','-R',selector,'--output-junit',str(out/(label+'-tests.xml'))]
    with (out/(label+'-tests.log')).open('wb') as log: subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
    cases=ET.parse(out/(label+'-tests.xml')).findall('.//testcase'); assert len(cases)==12 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
    verify(root,json.loads((build/'build-provenance.json').read_text())); assert inputs(root)==before
    assert all(digest(root/p)==h for p,h in json.loads((prior/'protected-files.json').read_text()).items())
    checks.append(dict(config=config,tests=len(cases),skips=0,activePrograms=860,referenceProgramsExact=860,aliases=0,staleCandidateArtifactsRemoved=len(stale),option='OFF',seconds=time.monotonic()-start))
    (out/'build-results.json').write_text(json.dumps(checks,indent=2)); print(json.dumps(checks[-1]),flush=True)
