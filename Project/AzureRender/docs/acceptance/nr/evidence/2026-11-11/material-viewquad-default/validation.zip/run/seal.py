from pathlib import Path
import json,sys,zipfile,hashlib
root=Path.cwd(); out=Path(__file__).resolve().parent; parent=out.parent
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def encode(x): return (json.dumps(x,indent=2)+'\n').encode()
source=read(out/'source-lock.json'); assert inputs(root)==source
checks=read(out/'build-results.json'); assert len(checks)==2 and all(x['tests']==12 and x['skips']==0 and x['option']=='OFF' and x['referenceProgramsExact']==860 for x in checks)
for config in ['release','debug']: verify(root,read(out/(config+'-build-provenance.json')))
candidate_dir=root/'docs/acceptance/nr/evidence/2026-11-11/material-viewquad-production'
candidate=read(candidate_dir/'results.json'); assert not candidate['productionAdopted'] and candidate['defaultBuildOption']=='OFF'
candidate_archive=read(candidate_dir/'archive-verification.json')
assert digest(candidate_dir/'validation.zip')==candidate_archive['sha256']
capture=read(out/'capture-results.json'); assert all(capture[k] for k in ['validationClean','allocatorZero','sourceUnchanged','programsUnchanged','projectInputsUnchanged'])
assert capture['exitCode']==0 and len(capture['frames'])==4
lock=read(out/'frozen-project-inputs.json'); assert len(lock)==1729 and all(digest(Path(p))==h for p,h in lock.items())
protected=read(parent/'protected-files.json'); assert len(protected)==13 and all(digest(root/p)==h for p,h in protected.items())
manifest=read(out/'capture-manifest.json'); selection={k:v for k,v in manifest.items() if k.startswith('computedMaterialView')}
assert selection['computedMaterialViewFallback']=='build-disabled' and selection['computedMaterialViewPipelines']==selection['computedMaterialViewSelectionsTotal']==0
memory=read(out/'memory-results.json'); assert memory['peakWorkingSetBytes']<=2*1024**3
original=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames'
duplicates=[]
for folder in [out,parent/'memory-reference']:
    for f in capture['frames']:
        p=folder/'frames'/f['name']; ref=original/f['name']
        assert f['changedPixels']==f['maximumByteError']==0 and digest(p)==digest(ref)==f['sha256']
        duplicates.append(dict(path=str(p),original=str(ref),sha256=f['sha256'],bytes=p.stat().st_size))
result=dict(status='default-reference-verified',sourceBase='58294c7',defaultBuildOption='OFF',
  defaultSourceSha256={p:digest(root/p) for p in candidate['candidateSourceSha256']},build=checks,
  originalFour=capture,selection=selection,memory=memory,projectInputsExact=1729,protectedFilesExact=13,
  candidateArchive=candidate_archive,productionAdopted=False,formalPerformancePassed=False)
(out/'results.json').write_bytes(encode(result))
(out/'duplicate-frame-inventory.json').write_bytes(encode(duplicates))
dest=candidate_dir.parent/'material-viewquad-default'; dest.mkdir(parents=True,exist_ok=True)
archive=dest/'validation.zip'; members={}
def add(z,p,name):
    b=p.read_bytes(); assert name not in members
    members[name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()); z.writestr(name,b)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.iterdir()):
        if p.suffix in ['.json','.py','.log','.xml','.csv']: add(z,p,'run/'+p.name)
    add(z,parent/'protected-files.json','run/protected-files.json')
    add(z,root/'CMakeLists.txt','source/CMakeLists.txt')
    z.writestr('member-sha256.json',encode(members))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(members)|{'member-sha256.json'}
    assert all(len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in members.items())
assert archive.stat().st_size<8*1024**2
verification=dict(bytes=archive.stat().st_size,members=len(members)+1,sha256=digest(archive),memberHashesVerified=True)
(dest/'archive-verification.json').write_bytes(encode(verification)); (dest/'results.json').write_bytes(encode(result))
for row in duplicates:
    p=Path(row['path']); assert p.resolve().parent in [(out/'frames').resolve(),(parent/'memory-reference/frames').resolve()]
    assert digest(p)==digest(Path(row['original']))==row['sha256']; p.unlink()
(out/'identical-frames-reclaimed.json').write_bytes(encode(dict(files=len(duplicates),bytes=sum(v['bytes'] for v in duplicates),archive=verification)))
print(json.dumps(dict(verification=verification,seconds=capture['seconds'],peakWorkingSetBytes=memory['peakWorkingSetBytes'])))
