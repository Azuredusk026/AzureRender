from pathlib import Path
import hashlib,json,re,shutil,zipfile
root=Path.cwd(); out=Path(__file__).resolve().parent
dest=root/'docs/acceptance/nr/evidence/2026-11-11/material-viewquad-production'
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def encode(obj): return (json.dumps(obj,indent=2)+'\n').encode()
def sha(b): return hashlib.sha256(b).hexdigest()
def compare(folder):
    capture=read(folder/'capture-results.json'); memory=read(folder/'memory-results.json')
    manifest=read(folder/'capture-manifest.json'); observations=read(folder/'memory-observations.json')
    log=(folder/'capture.log').read_text(errors='replace')
    peak=next(x for x in observations if x['peak']==memory['peakWorkingSetBytes'])
    assert all(capture[k] for k in ['validationClean','allocatorZero','sourceUnchanged','programsUnchanged','projectInputsUnchanged'])
    assert len(capture['frames'])==4 and all(x['changedPixels']==x['maximumByteError']==0 and x['sha256']==x['referenceSha256'] for x in capture['frames'])
    return dict(peakWorkingSetBytes=memory['peakWorkingSetBytes'], firstPeak=peak,
        pipelinePreparationMilliseconds=float(re.search(r'Scene load pipelines: ([\d.]+) ms',log)[1]),
        pipelineRequests=int(re.search(r'Pipeline cache saved: .*requests=(\d+)',log)[1]),
        capture=capture, allocator=memory['allocator'],
        selection={k:v for k,v in manifest.items() if k.startswith('computedMaterialView')})
ref=out/'memory-reference'; a=compare(out); b=compare(ref)
ac=read(out/'capture-command.json'); bc=read(ref/'capture-command.json')
assert ac['products']==bc['products']
def scrub(c):
    c=c['command'].copy()
    for opt in ['--capture-dir','--runtime-report','--gpu-timing-output']: c[c.index(opt)+1]='<output>'
    return c
assert scrub(ac)==scrub(bc) and a['allocator']==b['allocator'] and a['capture']['frames']==b['capture']['frames']
assert a['selection']['computedMaterialViewPipelines']==464 and b['selection']['computedMaterialViewPipelines']==0
assert a['pipelineRequests']-b['pipelineRequests']==464
limit=2*1024**3
decision=dict(status='opt-in-candidate',sameExecutableAndPrograms=True,sameCommandExceptOutputPaths=True,
    referenceEnvironment='AZURE_DISABLE_COMPUTED_MATERIAL_VIEW=1', candidate=a, reference=b,
    workingSetIncreaseBytes=a['peakWorkingSetBytes']-b['peakWorkingSetBytes'], workingSetBudgetBytes=limit,
    candidateWithinWorkingSetBudget=a['peakWorkingSetBytes']<=limit,
    referenceWithinWorkingSetBudget=b['peakWorkingSetBytes']<=limit,
    allocatorCountersIdentical=True, formalP5Workload=False, defaultBuildOption='OFF',
    reason='Candidate exceeds the host working-set budget in the matched four-frame load and the GPU P95 target in the latest short test.')
assert not decision['candidateWithinWorkingSetBudget'] and decision['referenceWithinWorkingSetBudget']
archive=dest/'validation.zip'; original=out/'pre-decision-validation.zip'; old=read(dest/'archive-verification.json')
assert sha(archive.read_bytes())==old['sha256']
shutil.copyfile(archive,original)
result=read(dest/'results.json'); assert result['productionAdopted'] and not result['shortGpuBudgetPassed']
result['status']='opt-in-candidate-with-depth-policy'
result['productionAdopted']=False
result['candidateSourceSha256']=result.pop('productionSourceSha256')
result['candidateSelection']=result.pop('productionSelection')
result['memoryComparison']=decision
result['defaultBuildOption']='OFF'
correction=dict(previousArchive=old,previousAdoptionField=True,currentAdoptionField=False,
    measuredCandidateBytes=a['peakWorkingSetBytes'],measuredReferenceBytes=b['peakWorkingSetBytes'],
    previousArchiveRetainedInRun=original.name,matchedControl='run/memory-reference/capture-results.json',
    rationale=decision['reason'])
data={'run/results.json':encode(result),'run/adoption-correction.json':encode(correction),
      'run/memory-comparison.json':encode(decision),'run/correct_candidate_archive.py':Path(__file__).read_bytes()}
for name in ['capture.py','capture-command.json','capture-manifest.json','capture-results.json','capture.log','gpu-timing.csv','gpu-timing.json','memory-observations.json','memory-results.json','runtime.json']:
    data['run/memory-reference/'+name]=(ref/name).read_bytes()
updated=out/'corrected-candidate-validation.zip'
with zipfile.ZipFile(original) as prev, zipfile.ZipFile(updated,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    members=json.loads(prev.read('member-sha256.json')); assert len(members)+1==old['members']
    for name, item in members.items():
        payload=prev.read(name)
        assert len(payload)==item['bytes'] and sha(payload)==item['sha256']
        if name not in data: z.writestr(name,payload)
    for name,payload in data.items():
        members[name]=dict(bytes=len(payload),sha256=sha(payload));z.writestr(name,payload)
    z.writestr('member-sha256.json',encode(members))
with zipfile.ZipFile(updated) as z:
    assert z.testzip() is None and set(z.namelist())==set(members)|{'member-sha256.json'}
    assert all(len(z.read(n))==v['bytes'] and sha(z.read(n))==v['sha256'] for n,v in members.items())
    assert json.loads(z.read('run/results.json'))==result
assert updated.stat().st_size<8*1024**2
shutil.copyfile(updated,archive); assert sha(archive.read_bytes())==sha(updated.read_bytes())
verification=dict(bytes=archive.stat().st_size,members=len(members)+1,sha256=sha(archive.read_bytes()),memberHashesVerified=True)
for name,payload in [('results.json',encode(result)),('adoption-correction.json',encode(correction)),('memory-comparison.json',encode(decision))]:
    (out/name).write_bytes(payload)
    if name!='memory-comparison.json': (dest/name).write_bytes(payload)
(dest/'archive-verification.json').write_bytes(encode(verification))
print(json.dumps(dict(verification=verification,workingSetIncreaseBytes=decision['workingSetIncreaseBytes'],candidatePipelineMs=a['pipelinePreparationMilliseconds'],referencePipelineMs=b['pipelinePreparationMilliseconds'])))
