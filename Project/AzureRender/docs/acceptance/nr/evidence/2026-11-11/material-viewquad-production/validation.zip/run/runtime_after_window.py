from pathlib import Path
import subprocess,time,sys
out=Path(__file__).resolve().parent;start=time.monotonic()
print('Yielding two-minute queue window before runtime acceptance',flush=True)
while time.monotonic()-start<120:time.sleep(5)
raise SystemExit(subprocess.run([sys.executable,'-X','utf8','-B',str(out/'runtime.py')]).returncode)
