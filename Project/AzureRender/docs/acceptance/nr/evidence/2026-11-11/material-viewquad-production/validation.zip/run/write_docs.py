from pathlib import Path
import json
root=Path.cwd();out=Path(__file__).resolve().parent;dest=root/'docs/acceptance/nr/evidence/2026-11-11/material-viewquad-production'
r=json.loads((dest/'results.json').read_text());a=json.loads((dest/'archive-verification.json').read_text());cost=r['shortEfficiency'];candidate=cost['rows'][1]['summary']
assert cost['productionEfficiencyPassed'] and r['productionAdopted']
gpuPixels=sum(x['result'].get('pixelsCompared',0) for x in r['standardDepthGpuProcesses'])
document=f'''# 材质视图组合生产验收

日期：2026-11-11。
源码基础为 `58294c7`，同阶段源码摘要随证据保存。
局部及原生资格来源为 `d41f927` 与 `e329f55`。
整体状态仍为 `failed-user-review`。

## 生产契约

[材质视图组合](../../runtime/computed-material-view.md)按设备及当帧相机选择。
优化管线复用布局、专用常量及附件规则。
参考 UV、失配视图及能力不足设备使用参考族。
缺失可选优化程序时记录原因并保留参考路径。

同帧深度的视图及范围共同参与资格判断。
透明裁剪只结束完全不可见的四像素组。
幸存组保持全部四份原始阴影导数及着色。
管线映射由渲染器持有，记录计数使用原子操作。

## 构建与设备

两配置实际宿主及所属测试目标构建通过。
两配置合计二十四项检查通过，无跳过。
每配置全部 860 份既有程序保持摘要。
新增优化族为 128 份，总数为 988 份。

每配置十份优化程序与实际测量程序逐字节相同。
标准深度资格包含两配置、两设备的十二次设备检查。
当前全部 988 份程序与该资格分别保持摘要。
材质独立视图累计核对 {gpuPixels} 个精确像素。
四次公共 UV 梯度回归同时通过。

NVIDIA 每配置核对二十八次资格命中及 242 次回退。
Intel 每配置的 270 次状态检查全部使用参考路径。
范围包含普通材质、显式照明、参考 UV 及尺寸变化。
诊断切换、验证层及释放后资源归零均通过。

实际宿主另行验证可选程序缺失的回退。
859 份冻结参考程序保持摘要，优化程序全部缺失。
宿主记录明确原因并完成八帧及资源清理。
必需参考 UV 的失败契约保持原值。

## 深度资格

生产渲染器的关闭深度控制先在原实现上复现失败。
原检查记录二十六条准备管线及四次优化选择。
当前视图关闭深度测试时，优化资格与管线准备均关闭。
独立管线仅使用通过资格的深度比较范围。

两配置、两设备的四个记录端点通过。
设备提供真实能力，空后端记录生产渲染器的选择。
NVIDIA 标准深度仍准备二十六条管线并记录四次选择。
关闭深度时，两设备的管线数及优化选择均归零。

实际 AzureRender 宿主另行执行关闭深度的命令行对照。
自动回退与强制参考的 PNG 摘要及 RGBA 完全一致。
该入口的验证及资源归零检查通过。
首次 Player 独立资产入口拒绝发生于渲染前，记录保留。

## 原始四帧

当前生产宿主重新采集严格原始四帧。
采集实际耗时约为 {r['originalFour']['seconds']:.3f} 秒。
四张 PNG 摘要与 RGB 分别精确一致。
实际优化管线选择计数为正，验证及卸载检查通过。

1729 项挂载输入及十三份用户保护文件保持摘要。
重复截图在归档与原图摘要核对后回收。
联合场景工作集观察与正式内存验收分别记录。

## 成对短时测量

三进程共用同一生产可执行文件。
两侧参考通过环境控制选择原始管线。
每进程固定更新 120 帧，取后六十帧统计。
实际分辨率为 1920 × 1080。

两侧参考 GPU 均值约为 {cost['referenceMeanMs']:.6f} 毫秒。
候选 GPU 均值约为 {candidate['gpu']['mean']:.6f} 毫秒。
降幅约为 {cost['reductionFraction']*100:.3f}%，参考漂移约为 {cost['referenceDriftFraction']*100:.3f}%。
受影响范围降幅约为 {cost['affectedRangeReductionFraction']*100:.3f}%。

四项短时效率条件及供电、热状态检查通过。
候选 GPU P95 约为 {candidate['gpu']['p95']:.6f} 毫秒。
CPU 工作 P95 约为 {candidate['cpu']['p95']:.6f} 毫秒。
正式帧预算、固定 80W 与长跑继续按现有标准验收。

## 验证记录

首轮编译发现帧数常量的声明顺序问题。
帧状态数组在常量声明后定义，重编通过。
完整设备用例的首轮进程触及 210 秒上限。
日志保留持续管线准备与超时位置。

该用例覆盖二十七个视图及五十四次管线准备。
执行时间上限为 480 秒，用例及数值门槛保持原值。
标准深度资格保留当批的产品身份及时间修正。
当前生产源码重新执行全部二十四项检查。

两个编译检查曾因默认预约超过受管池余量而拒绝启动。
混合编译验证预约 64 MiB，完整目录验证预约 768 MiB。
目录验证实际产物规模已单独记录。
受管池上限及逐份字节比较门槛保持原值。

## 验证归档

[实施计划](../../plans/2026-11-11-material-viewquad-production.md)、
[结果清单](evidence/2026-11-11/material-viewquad-production/results.json)
和[验证归档](evidence/2026-11-11/material-viewquad-production/validation.zip)
保存源码、实际优化程序、失败记录及完整测量。
[标准深度资格](material-viewquad-standard-depth.md)保存完整独立像素矩阵。

归档共 {a['members']} 项，大小为 {a['bytes']} 字节。
成员摘要与压缩校验全部通过。
固定功率的设备控制限制单独保留。
完整颜色与其他设备差异继续按所属单元推进。
'''
(root/'docs/acceptance/nr/material-viewquad-production.md').write_text(document,encoding='utf-8')
for file,heading,relative in [('README.md','# AzureRender 工程','docs/acceptance/nr/material-viewquad-production.md'),('docs/plans/azure-engine-plan.md','## 当前执行顺序','../acceptance/nr/material-viewquad-production.md')]:
    p=root/file;text=p.read_text(encoding='utf-8');entry=f'[材质视图组合生产验收]({relative})通过双配置、双设备及严格原始四帧。\nGPU 短时均值减少约 {cost["reductionFraction"]*100:.2f}%，正式帧预算及固定功率继续验收。\n'
    assert entry not in text;p.write_text(text.replace(heading+'\n\n',heading+'\n\n'+entry+'\n',1),encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');entry=f'''## 2026-11-11 材质视图组合生产接入

- 接入设备及当帧视图资格、128 份有界程序与可观察回退，全部既有 860 份程序保持摘要。
- 双配置二十四项检查与十二次设备检查通过，严格原始四帧精确一致，缺失程序及卸载清理通过。
- 同一宿主成对短检的 GPU 均值减少约 {cost['reductionFraction']*100:.2f}%，正式预算与固定功率保持所属待项。

''';p.write_text(text.replace('# Changelog\n\n','# Changelog\n\n'+entry,1),encoding='utf-8')
p=root/'docs/plans/2026-11-06-performance-bottlenecks.md';text=p.read_text(encoding='utf-8');start=text.index('## 当前状态');end=text.index('## 机制验收记录',start)
current=f'''## 当前状态

[材质视图组合生产验收](../acceptance/nr/material-viewquad-production.md)通过两配置二十四项检查。
标准深度十二次设备检查及当前深度策略四端点通过。
实际命令行回退和当前宿主严格原始四帧均通过。
既有 860 份程序保持摘要，优化族为 128 份。
运行时输入及实际程序身份以所属验收清单为准。

局部完整材质降幅约为 21.21%。
同一生产宿主短检的 GPU 均值减少约 {cost['reductionFraction']*100:.2f}%。
GPU P95 约为 {candidate['gpu']['p95']:.5f} 毫秒。
CPU 工作 P95 约为 {candidate['cpu']['p95']:.5f} 毫秒。

[完整捕获](../acceptance/nr/quad-device-capture-qualification.md)覆盖 3453 个事件及 76 条管线。
材质绘制仍为 GPU 主导成本。
正式 CPU、GPU 及长跑保持所属采样条件。
其他隔离候选的结果保留在各自验收记录中。

[场景参考相机主线集成](../acceptance/nr/scene-reference-camera-main-integration.md)通过两配置三十四项检查。
场景选择、持久锚点、宏兼容及原始四帧通过。
实际绘制及拾取消费继续按所属单元接入。

[驻留色彩图像](../acceptance/nr/resident-srgb-channel-scope.md)完成 180 份图像的全部层级核对。
四十份满足单通道关系，乐观差额约为 113.70 MB。
[块存储调查](../acceptance/nr/dds-block-storage-scope.md)记录来源容量及设备格式能力。
实际缓存、采样资格和分配高水位分别验收。

[管理员功率结果](../acceptance/nr/gpu-power-limit-qualification.md)确认设置入口不受设备支持。
正式固定功率条件继续保留，独立软件工作持续推进。
Intel 原生差异及完整颜色按专项接入。

''';p.write_text(text[:start]+current+text[end:],encoding='utf-8')
print('Wrote current production behavior and measured acceptance results')
