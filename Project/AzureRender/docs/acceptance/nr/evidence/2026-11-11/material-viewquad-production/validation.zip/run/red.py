from pathlib import Path
import json,sys,os,subprocess,time,shutil
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
shutil.copyfile(root/'src/scenes/CharacterComputedMaterialView.inc',out/'before-depth-guard.inc')
build=root/'build/ninja-msvc-release';command=['cmake','--build',str(build),'--config','Release','--target','AzureComputedMaterialDepthPolicyRecordingTests','-j','3']
with (out/'red-build.log').open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
with (out/'red-recording.log').open('wb') as log:result=subprocess.run([str(build/'AzureComputedMaterialDepthPolicyRecordingTests.exe'),str(build/'shaders'),str(out/'red')],stdout=log,stderr=subprocess.STDOUT,timeout=60)
text=(out/'red-recording.log').read_text(errors='replace');assert result.returncode!=0 and 'Depth-disabled or unqualified view must retain reference pipelines' in text,text[-2500:]
report=json.loads((out/'red/results.json').read_text());assert len(report['cases'])==2 and all(x['zeroAllocator'] for x in report['cases'])
assert report['cases'][0]['frameEligible'] and report['cases'][1]['frameEligible'] and report['cases'][1]['preparedPipelines']>0
print(json.dumps(dict(status='expected-red',actual=report)),flush=True)
