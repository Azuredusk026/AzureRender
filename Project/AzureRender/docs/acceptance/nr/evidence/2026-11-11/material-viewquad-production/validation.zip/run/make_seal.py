from pathlib import Path
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261111-034916-material-viewquad-production-24693d'
text=(prior/'seal.py').read_text()
text=text.replace("root=Path.cwd();out=Path(__file__).resolve().parent;sys.path", "root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261111-034916-material-viewquad-production-24693d';sys.path")
text=text.replace("x['referenceProgramsExact']==860","x['referenceProgramsExact']==988")
text=text.replace("(out/'timeout-refresh.json')","(prior/'timeout-refresh.json')")
text=text.replace("(out/'gpu-results.json')","(prior/'gpu-results.json')")
text=text.replace("(out/'missing-program-results.json')","(prior/'missing-program-results.json')")
marker="capture=json.loads((out/'capture-results.json').read_text())"
extra='''recordings=[]
for config in ['release','debug']:
    assert json.loads((out/(config+'-program-sha256.json')).read_text())==json.loads((prior/(config+'-program-sha256.json')).read_text())
    for device in ['nvidia','intel']:
        data=json.loads((out/(config+'-'+device+'-depth-recording/results.json')).read_text())
        assert data['status']=='passed' and data['validationErrors']==0 and all(c['zeroAllocator'] for c in data['cases'])
        assert not data['cases'][1]['frameEligible'] and data['cases'][1]['preparedPipelines']==data['cases'][1]['selections']==0
        recordings.append(dict(config=config,device=device,result=data))
cli=json.loads((out/'depth-cli-results.json').read_text());assert cli['status']=='passed' and cli['pngShaExact'] and cli['validationClean'] and cli['allocatorZero']
standard=root/'docs/acceptance/nr/evidence/2026-11-11/material-viewquad-standard-depth'
standardArchive=json.loads((standard/'archive-verification.json').read_text());assert digest(standard/'validation.zip')==standardArchive['sha256']
'''
assert text.count(marker)==1;text=text.replace(marker,extra+marker)
text=text.replace("'tests/support/VulkanComputeFixture.hpp']","'tests/support/VulkanComputeFixture.hpp','tests/ComputedMaterialDepthPolicyRecordingTests.cpp','tools/test_shader_compiler_contract.py','tools/test_shader_catalog.py']")
text=text.replace("timeoutRefresh=refresh,gpuProcesses=gpu", "standardDepthTimeoutHistory=refresh,standardDepthArchive=standardArchive,standardDepthGpuProcesses=gpu,standardDepthProgramsExact=988,depthPolicyRecording=recordings,actualDepthCli=cli,testReservationCorrection=json.loads((out/'test-reservation-correction.json').read_text())")
text=text.replace("status='qualified-production-computed-material-view'","status='qualified-production-computed-material-view-with-depth-policy'")
text=text.replace("if p.suffix in ['.json','.py','.log','.xml','.csv','.frag','.hpp','.cpp','.inc','.glsl']:","if p.suffix in ['.json','.py','.log','.xml','.csv','.frag','.hpp','.cpp','.inc','.glsl'] or (p.suffix=='.png' and p.relative_to(out).parts[0].startswith('depth-cli-')):")
(out/'seal.py').write_text(text)
print('Prepared final source/product, depth-policy, current four-frame and ABA seal')
