from pathlib import Path
import json,shutil,sys
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261111-034916-material-viewquad-production-24693d';sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest
for name in ['protected-files.json','frozen-project-inputs.json','baseline-dlls.json','capture.py','cost.py','missing_program.py']:
    shutil.copyfile(prior/name,out/name)
for config in ['release','debug']:shutil.copyfile(prior/(config+'-program-sha256.json'),out/(config+'-reference-programs.json'))
(out/'source-lock.json').write_text(json.dumps(inputs(root),indent=2))
text=(prior/'build.py').read_text()
text=text.replace("targets=['AzureComputedMaterialViewTests'","targets=['AzureComputedMaterialDepthPolicyRecordingTests','AzureComputedMaterialViewTests'")
text=text.replace("assert len(reference)==860", "assert len(reference)==988")
text=text.replace('referenceProgramsExact=860','referenceProgramsExact=988')
# All twelve previous checks stay in this batch. The new device-backed
# recording contract runs explicitly on both vendors after each build.
marker="    checks.append(dict(config=config"
extra='''    for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
        os.environ['VK_LOADER_DRIVERS_SELECT']=driver
        folder=out/(config.lower()+'-'+device+'-depth-recording');folder.mkdir(exist_ok=True)
        with (folder/'process.log').open('wb') as log:subprocess.run([str(build/'AzureComputedMaterialDepthPolicyRecordingTests.exe'),str(build/'shaders'),str(folder)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
        state=json.loads((folder/'results.json').read_text());assert state['status']=='passed' and len(state['cases'])==2 and state['validationErrors']==0
        assert state['cases'][1]['preparedPipelines']==0 and not state['cases'][1]['frameEligible']
'''
assert text.count(marker)==1;text=text.replace(marker,extra+marker)
(out/'build.py').write_text(text)
print('Prepared full two-configuration runtime provenance, 24 existing checks and four new depth-policy recording endpoints')
