from pathlib import Path
import os,json,sys,subprocess,time
import numpy as np
from PIL import Image
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest,verify
os.environ.update(managed_environment(out/'tmp'));os.environ.update(DOTNET_ROOT='D:/Tools/dotnet9',VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer')
build=root/'build/ninja-msvc-release';verify(root,json.loads((out/'release-build-provenance.json').read_text()));before=inputs(root)
asset=root/'build/runs/20261111-034916-material-viewquad-production-24693d/release-nvidia-computed/scene.gltf';assetHash=digest(asset);rows=[]
for mode in ['reference','automatic']:
    if mode=='reference':os.environ['AZURE_DISABLE_COMPUTED_MATERIAL_VIEW']='1'
    else:os.environ.pop('AZURE_DISABLE_COMPUTED_MATERIAL_VIEW',None)
    folder=out/('depth-cli-'+mode);folder.mkdir(exist_ok=True);start=time.monotonic()
    command=[str(build/'AzureRender.exe'),'--asset',str(asset),'--qa-disable-depth-test','--width','128','--height','96','--anti-aliasing','off','--no-inner-outline','--no-stylized','--fixed-frame-step','--capture-fps','24','--capture-frames','1','--capture-dir',str(folder/'frames'),'--gpu-timing','--gpu-timing-output',str(folder/'timing.json')]
    (folder/'command.json').write_text(json.dumps(command,indent=2))
    with (folder/'process.log').open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    data=json.loads((folder/'timing.json').read_text());text=(folder/'process.log').read_text(errors='replace')
    assert data['computedMaterialViewPipelines']==0 and data['computedMaterialViewSelectionsTotal']==0 and not data['computedMaterialViewFrameEligible']
    assert data['computedMaterialViewFallback']==('disabled' if mode=='reference' else 'depth-test-disabled')
    assert 'Allocator after unload: buffers=0 images=0' in text and not any(x in text for x in ['VUID-','SYNC-HAZARD','Validation Error:','Validation Warning:'])
    image=folder/'frames/frame_000000.png';assert image.exists()
    rows.append(dict(mode=mode,seconds=time.monotonic()-start,sha256=digest(image),metadata={k:v for k,v in data.items() if k.startswith('computedMaterialView')}))
first=np.asarray(Image.open(out/'depth-cli-reference/frames/frame_000000.png').convert('RGBA'));second=np.asarray(Image.open(out/'depth-cli-automatic/frames/frame_000000.png').convert('RGBA'));assert np.array_equal(first,second) and rows[0]['sha256']==rows[1]['sha256']
assert inputs(root)==before and digest(asset)==assetHash;verify(root,json.loads((out/'release-build-provenance.json').read_text()))
os.environ.pop('AZURE_DISABLE_COMPUTED_MATERIAL_VIEW',None)
result=dict(status='passed',asset=str(asset),assetSha256=assetHash,rows=rows,exactRgbaPixels=int(first.shape[0]*first.shape[1]),pngShaExact=True,validationClean=True,allocatorZero=True)
(out/'depth-cli-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
