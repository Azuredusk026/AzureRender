from pathlib import Path
import json,shutil
out=Path(__file__).resolve().parent;src=(out/'depth-cli-reference').resolve();dst=(out/'depth-cli-reference-player-preflight').resolve()
assert src.parent==dst.parent==out.resolve() and not dst.exists();src.rename(dst)
shutil.copyfile(out/'process.log',out/'player-asset-preflight-failure.log')
(out/'cli-host-correction.json').write_text(json.dumps(dict(reason='Standalone --asset workflow uses AzureRender; AzurePlayer requires --project or --scene',firstAttemptStartedRenderer=False,originalCommandPreserved=True,actualHost='AzureRender.exe',sharedProductionRenderer=True,acceptanceUnchanged=True),indent=2))
