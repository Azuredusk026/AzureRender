from pathlib import Path
import shutil,json
out=Path(__file__).resolve().parent
for name in ['release-tests.log','release-tests.xml','release-build-provenance.json','source-lock.json','process.log']:
    shutil.copyfile(out/name,out/(Path(name).stem+'-before-test-reservation-fix'+Path(name).suffix))
(out/'test-reservation-correction.json').write_text(json.dumps(dict(failedChecks=['ShaderCompilerContract','ShaderCatalogCompilation'],reason='Default 2 GiB reservation exceeds current 16 GiB managed pool by 61781903 bytes before either test starts',managedPoolLimitBytes=17179869184,previousReservedBytes=15094167439,observedPriorCatalogRunBytes=[461612291,320792255],compilerContractPlannedBytes=64*1024**2,catalogPlannedBytes=768*1024**2,acceptanceAndPoolLimitsUnchanged=True),indent=2))
print('Preserved both reservation failures and original proofs')
