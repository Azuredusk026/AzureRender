from pathlib import Path
import subprocess,sys,time
root=Path.cwd();out=Path(__file__).resolve().parent;start=time.monotonic()
command=[sys.executable,'-X','utf8','-B','tools/shared_resources.py','run','--owner','01a1c097-ec33-7790-8c18-08a2b0ddb0c3','--run',out.name,'--task','material-depth-policy-green','--timeout','1300','--command',sys.executable,'-X','utf8','-B',str(out/'build.py')]
while True:
    result=subprocess.run(command,capture_output=True);(out/'green-queue.log').write_bytes(result.stdout+result.stderr)
    if result.returncode==0:print('Both configurations and all depth endpoints passed',flush=True);break
    if b'Shared resource busy or inaccessible' not in result.stderr or time.monotonic()-start>180:
        print((result.stdout+result.stderr).decode(errors='replace'),flush=True);raise SystemExit(result.returncode)
    time.sleep(5)
raise SystemExit(subprocess.run([sys.executable,'-X','utf8','-B',str(out/'runtime.py')]).returncode)
