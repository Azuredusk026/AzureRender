from pathlib import Path
import subprocess,sys,json,time
root=Path.cwd();out=Path(__file__).resolve().parent
common=[sys.executable,'-X','utf8','-B','tools/shared_resources.py','run','--owner','01a1c097-ec33-7790-8c18-08a2b0ddb0c3','--run',out.name]
for task,script,timeout,resultName in [('material-depth-policy-cli','actual_depth_cli.py',300,'depth-cli-results.json'),('material-depth-policy-original-four','capture.py',650,'capture-results.json'),('material-depth-policy-short-aba','cost.py',1000,'cost-results.json')]:
    if (out/resultName).exists():print(task+' has a result; inspect before repeating',flush=True);continue
    start=time.monotonic()
    while True:
        result=subprocess.run([*common,'--task',task,'--timeout',str(timeout),'--command',sys.executable,'-X','utf8','-B',str(out/script)],capture_output=True)
        (out/(task+'-queue.log')).write_bytes(result.stdout+result.stderr)
        if result.returncode==0:print(task+' exited successfully',flush=True);break
        if b'Shared resource busy or inaccessible' not in result.stderr or time.monotonic()-start>180:
            print((result.stdout+result.stderr).decode(errors='replace'),flush=True);raise SystemExit(result.returncode)
        time.sleep(5)
