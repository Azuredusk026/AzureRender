from pathlib import Path
root=Path.cwd();out=Path(__file__).resolve().parent;prior=root/'build/runs/20261111-034916-material-viewquad-production-24693d'
text=(prior/'write_docs.py').read_text().replace("r['gpuProcesses']","r['standardDepthGpuProcesses']")
text=text.replace('两配置、两设备共执行十二次设备检查。','标准深度资格包含两配置、两设备的十二次设备检查。\n当前全部 988 份程序与该资格分别保持摘要。')
text=text.replace('两份构建来源证明及运行依赖核对通过。','两份构建来源证明及运行依赖核对通过。')
text=text.replace('## 原始四帧','''## 深度资格

生产渲染器的关闭深度控制先在原实现上复现失败。
原检查记录二十六条准备管线及四次优化选择。
当前视图关闭深度测试时，优化资格与管线准备均关闭。
独立管线仅使用通过资格的深度比较范围。

两配置、两设备的四个记录端点通过。
设备提供真实能力，空后端记录生产渲染器的选择。
NVIDIA 标准深度仍准备二十六条管线并记录四次选择。
关闭深度时，两设备的管线数及优化选择均归零。

实际 AzureRender 宿主另行执行关闭深度的命令行对照。
自动回退与强制参考的 PNG 摘要及 RGBA 完全一致。
该入口的验证及资源归零检查通过。
首次 Player 独立资产入口拒绝发生于渲染前，记录保留。

## 原始四帧''')
text=text.replace('两配置刷新构建证明后，全部实际产品保持字节。\n已通过的二十四项检查依据产品身份复用。','标准深度资格保留当批的产品身份及时间修正。\n当前生产源码重新执行全部二十四项检查。')
text=text.replace('## 验证归档','''两个编译检查曾因默认预约超过受管池余量而拒绝启动。
混合编译验证预约 64 MiB，完整目录验证预约 768 MiB。
目录验证实际产物规模已单独记录。
受管池上限及逐份字节比较门槛保持原值。

## 验证归档''')
text=text.replace('保存源码、实际优化程序、失败记录及完整测量。','保存源码、实际优化程序、失败记录及完整测量。\n[标准深度资格](material-viewquad-standard-depth.md)保存完整独立像素矩阵。')
text=text.replace('十二次设备检查、实际可选回退及严格原始四帧均通过。','标准深度十二次设备检查及当前深度策略四端点通过。\n实际命令行回退和当前宿主严格原始四帧均通过。')
text=text.replace('## 2026-11-11 材质视图组合生产接入','## 2026-11-11 材质视图组合生产接入')
(out/'write_docs.py').write_text(text)
print('Prepared measured production documentation with separate standard-depth GPU and current depth-policy evidence')
