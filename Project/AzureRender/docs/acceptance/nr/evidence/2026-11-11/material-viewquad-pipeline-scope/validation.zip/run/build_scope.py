from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import digest,inputs,verify
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1')
phase=sys.argv[1]
assert phase in {'red','green','default'}
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),phase,'--inside']).returncode)
build=root/'build/ninja-msvc-release';shaders=build/'shaders'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(n,v):(out/n).write_text(json.dumps(v,indent=2))
def invoke(name,cmd,timeout=600,expected=0,env=None):
 with (out/(name+'.log')).open('wb') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,env=env)
 assert p.returncode==expected,(name,p.returncode)
 return (out/(name+'.log')).read_text(errors='replace')
prior=out.parent/'20261111-063356-reference-camera-binding-main-integration-c12528'
baseline=read(prior/'release-program-sha256.json'); assert len(baseline)==886
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
before=inputs(root);write(phase+'-source-lock.json',before)
configure=['cmake','-S',str(root),'-B',str(build)]
configure+=['-U','AZURE_ENABLE_COMPUTED_MATERIAL_VIEW'] if phase=='default' else ['-DAZURE_ENABLE_COMPUTED_MATERIAL_VIEW=ON']
invoke(phase+'-configure',configure,180)
assert ('AZURE_ENABLE_COMPUTED_MATERIAL_VIEW:BOOL='+('OFF' if phase=='default' else 'ON')) in (build/'CMakeCache.txt').read_text()
if phase=='default':
    measured=read(out/'green-program-sha256.json') if (out/'green-program-sha256.json').exists() else read(out/'red-program-sha256.json')
    generated=list(shaders.glob('*_viewquad.frag.spv'))
    assert all(p.resolve().parent==shaders.resolve() and digest(p)==measured[p.name] for p in generated)
    for p in generated:p.unlink()
if phase=='red':
    invoke('red-build',['cmake','--build',str(build),'--config','Release','--target','AzureComputedMaterialDepthPolicyRecordingTests'],800)
else:
    targets=['AzureComputedMaterialDepthPolicyRecordingTests','AzureComputedMaterialViewTests','AzureMaterialViewDeterminismGpuTests']
    cmd=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config','Release']
    for target in targets:cmd+=['--test-target',target]
    invoke(phase+'-build',cmd,800)
    write(('release' if phase=='green' else phase)+'-build-provenance.json',read(build/'build-provenance.json'))
    verify(root,read(build/'build-provenance.json'))
cat=read(build/'shader-reload.json')['programs'];hashes={p['output']:digest(shaders/p['output']) for p in cat}
assert all(hashes.get(k)==v for k,v in baseline.items())
aliases={n:v for n,v in hashes.items() if n.endswith('_viewquad.frag.spv')}
assert len(aliases)==(0 if phase=='default' else 128) and len(hashes)==886+len(aliases)
if phase!='default':
    measured=read(out.parent/'20261111-021128-quad-depth-visibility-local-qualification-1ea541/combined/compare-state.json')['programs']
    for p in measured:assert aliases[p['file'].replace('.frag.spv','_viewquad.frag.spv')]==p['candidateSha256']
write(phase+'-program-sha256.json',hashes)
if phase=='green':assert read(out/'red-program-sha256.json')==hashes
for dev,driver in ([('nvidia','*nv-vk64*')] if phase=='red' else [('nvidia','*nv-vk64*'),('intel','*igvk64*')]):
    env=os.environ|{'VK_LOADER_DRIVERS_SELECT':driver,'PATH':str(build)+';'+os.environ['PATH']}
    env.pop('AZURE_DISABLE_COMPUTED_MATERIAL_VIEW',None)
    p=out/(phase+'-'+dev)
    log=invoke(phase+'-'+dev+'-recording',[str(build/'AzureComputedMaterialDepthPolicyRecordingTests.exe'),str(shaders),str(p)],180,int(phase=='red'),env)
    cases=read(p/'results.json')
    if phase=='red':assert 'Specialized material preparation exceeds the active policy combinations' in log
    else:assert cases['status']=='passed' and cases['validationErrors']==0 and all(c['zeroAllocator'] for c in cases['cases'])
assert all(digest(root/p)==h for p,h in read(out/'protected-files.json').items()) and inputs(root)==before
write(phase+'-results.json',dict(status='expected-red' if phase=='red' else 'passed',programs=len(hashes),aliases=len(aliases),existingExact=886))
if phase=='green':
    for name,timeout in [('capture.py',650),('cost.py',1000)]:
        subprocess.run([sys.executable,'-X','utf8','-B',str(out/name)],check=True,timeout=timeout)
