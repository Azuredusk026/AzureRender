from pathlib import Path
import subprocess,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;mode=sys.argv[1]
assert mode in {'red','green'}
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='engine-dev'
def apply(name,edits):
 p=root/name; old=p.read_bytes(); backup=out/(mode+'-before-'+p.name)
 assert not backup.exists(),backup
 backup.write_bytes(old)
 newline='\r\n' if b'\r\n' in old else '\n'
 for before,after in edits:
  a=before.replace('\n',newline).encode();b=after.replace('\n',newline).encode()
  assert old.count(a)==1,(name,before)
  old=old.replace(a,b)
 p.write_bytes(old)
if mode=='red':
 apply('tests/ComputedMaterialDepthPolicyRecordingTests.cpp',[
 ('    for(bool depth:{true,false}){','    for(unsigned mode=0;mode<3;++mode){\n        const bool depth=mode!=1,referenceCameraPrograms=mode==2;'),
 ('context.depthTestEnabled=depth;context.computeShaders','context.depthTestEnabled=depth;context.referenceCameraPrograms=referenceCameraPrograms;context.computeShaders'),
 ('{{"depthTest",depth},{"preparedPipelines"','{{"depthTest",depth},{"referenceCameraPrograms",referenceCameraPrograms},{"preparedPipelines"'),
 ('if(depth&&qualified){require(data.at("computedMaterialViewPipelines").get<unsigned>()>0&&data.at("computedMaterialViewFrameEligible").get<bool>(),"Qualified depth-enabled view must prepare and select its existing optimized policy");}',
  'if(depth&&qualified&&!referenceCameraPrograms){\n            require(data.at("computedMaterialViewPipelines").get<unsigned>()>0&&data.at("computedMaterialViewSelectionsTotal").get<unsigned>()>0&&data.at("computedMaterialViewFrameEligible").get<bool>(),"Qualified depth-enabled view must prepare and select its existing optimized policy");\n            require(data.at("computedMaterialViewPipelines").get<unsigned>()<=8,"Specialized material preparation exceeds the active policy combinations");\n        }'),
 ('"Depth-disabled or unqualified view must retain reference pipelines"','"Depth-disabled, reference-camera or unqualified view must retain reference pipelines"'),
 ])
else:
 apply('src/scenes/CharacterSceneRenderer.hpp',[
  ('    ComputedMaterialViewCapabilities computedMaterialViewCapabilities_;',
   '    ComputedMaterialViewCapabilities computedMaterialViewCapabilities_;\n    std::uint8_t computedMaterialOrdinaryPolicies_=0;\n    std::array<std::uint8_t,unsigned(AssetMaterialClass::Showcase)+1> computedMaterialClassPolicies_{};')
 ])
 apply('src/scenes/CharacterMaterialSampling.inc',[
  ('    materialDepthPoliciesNeeded_={};','    materialDepthPoliciesNeeded_={};\n#if defined(AZURE_COMPUTED_MATERIAL_VIEW_PROGRAMS)\n    computedMaterialOrdinaryPolicies_=0;computedMaterialClassPolicies_.fill(0);\n#endif'),
  ('        independentCoverageNeeded_|=material.coverageTexture.present;','''        independentCoverageNeeded_|=material.coverageTexture.present;
#if defined(AZURE_COMPUTED_MATERIAL_VIEW_PROGRAMS)
        if(material.alphaMode!=AssetAlphaMode::Blend){
            const auto policy=(extendedMaterialLighting(material)?1U:0U)|(material.coverageTexture.present?2U:0U);
            const auto bit=static_cast<std::uint8_t>(1U<<(policy+4U*unsigned(material.doubleSided)));
            const auto index=unsigned(material.materialClass);
            if(ordinaryOpaqueMaterial(material))computedMaterialOrdinaryPolicies_|=bit;
            else if(index<computedMaterialClassPolicies_.size())computedMaterialClassPolicies_[index]|=bit;
        }
#endif'''),
 ])
 apply('src/scenes/CharacterComputedMaterialView.inc',[
  ('    if(!desc.depthTest||','    if(desc.alphaBlend||!desc.depthTest||'),
  ('    if(!path)return;\n    VkShaderModule module=', '''    if(!path)return;
    unsigned fixedClass=UINT32_MAX;
    bool ordinary=false;
    for(const auto& value:desc.fragmentSpecialization){
        if(value.id==0)ordinary=value.value==VK_TRUE;
        if(value.id==1)fixedClass=value.value;
    }
    const auto policies=ordinary?computedMaterialOrdinaryPolicies_:
        fixedClass<computedMaterialClassPolicies_.size()?computedMaterialClassPolicies_[fixedClass]:0U;
    if(!policies)return;
    std::string_view name=source->second;
    name.remove_suffix(std::string_view(".frag.spv").size());
    const bool coverage=name.ends_with("_coverage");
    if(coverage)name.remove_suffix(std::string_view("_coverage").size());
    const unsigned policy=(name.ends_with("_lighting")?1U:0U)|(coverage?2U:0U);
    const unsigned single=1U<<policy,doubleSided=1U<<(policy+4U);
    const unsigned allowedFacing=desc.cullMode==VK_CULL_MODE_NONE?single|doubleSided:single;
    if((policies&allowedFacing)==0U)return;
    VkShaderModule module='''),
 ])
