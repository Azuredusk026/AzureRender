from pathlib import Path
import json,os,re,subprocess,sys,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import digest,inputs,verify
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
def invoke(label,command,timeout=500,env=None):
 with (out/(label+'.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,check=True,env=env)
 return (out/(label+'.log')).read_text(errors='replace')
before=inputs(root);assert before==read(out/'green-source-lock.json')
expected=read(out/'green-program-sha256.json');assert len(expected)==1014
for k in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','AZURE_DISABLE_COMPUTED_MATERIAL_VIEW']:os.environ.pop(k,None)
os.environ.update(VK_LAYER_VALIDATE_SYNC='1')
rows=[]
for config in ['Release','Debug']:
 c=config.lower();build=root/('build/ninja-msvc-'+c);shaders=build/'shaders'
 if config=='Debug':
  invoke(c+'-opt-in-configure',['cmake','-S',str(root),'-B',str(build),'-DAZURE_ENABLE_COMPUTED_MATERIAL_VIEW=ON'],180)
  cmd=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
  for target in ['AzureComputedMaterialDepthPolicyRecordingTests','AzureComputedMaterialViewTests','AzureMaterialViewDeterminismGpuTests']:cmd+=['--test-target',target]
  invoke(c+'-opt-in-build',cmd,850)
  proof=read(build/'build-provenance.json');write(c+'-opt-in-build-provenance.json',proof)
 else:proof=read(out/'release-build-provenance.json')
 assert 'AZURE_ENABLE_COMPUTED_MATERIAL_VIEW:BOOL=ON' in (build/'CMakeCache.txt').read_text()
 verify(root,proof)
 cat=read(build/'shader-reload.json')['programs']; hashes={p['output']:digest(shaders/p['output']) for p in cat};assert hashes==expected
 write(c+'-opt-in-program-sha256.json',hashes)
 invoke(c+'-opt-in-policy',[str(build/'AzureComputedMaterialViewTests.exe')],60)
 for dev,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  env=os.environ|{'VK_LOADER_DRIVERS_SELECT':driver,'PATH':str(build)+';'+os.environ['PATH']}
  if config=='Debug':
   folder=out/(c+'-'+dev+'-recording')
   invoke(c+'-'+dev+'-recording',[str(build/'AzureComputedMaterialDepthPolicyRecordingTests.exe'),str(shaders),str(folder)],80,env)
   x=read(folder/'results.json');assert x['status']=='passed' and x['validationErrors']==0
  folder=out/(c+'-'+dev+'-opt-in-view');start=time.monotonic()
  log=invoke(c+'-'+dev+'-opt-in-view',[str(build/'AzureMaterialViewDeterminismGpuTests.exe'),str(shaders),str(folder),'--computed-viewquad'],500,env)
  x=read(folder/'results.json')
  assert x['status']=='passed' and x['validationErrors']==0 and x['zeroAllocator'] and x['pixelsCompared']==299520
  assert (x['eligibleChecks'],x['fallbackChecks'])==((28,242) if dev=='nvidia' else (0,270))
  assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)',log,re.I)
  rows.append(dict(config=config,device=dev,result=x,seconds=time.monotonic()-start))
  write('opt-in-gpu-results.json',rows);print(json.dumps(rows[-1]),flush=True)
 verify(root,proof);assert inputs(root)==before
assert len(rows)==4 and sum(r['result']['pixelsCompared'] for r in rows)==1198080
assert all(digest(root/p)==h for p,h in read(out/'protected-files.json').items())
