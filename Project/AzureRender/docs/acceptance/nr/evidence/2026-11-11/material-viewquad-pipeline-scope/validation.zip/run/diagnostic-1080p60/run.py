from pathlib import Path
import csv,json,os,subprocess,sys,time
import numpy as np
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;parent=out.parent
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import digest,inputs,verify
from gpu_environment import wait_and_record,RunEnvironmentMonitor
from run_playable_performance import memory_snapshot,freeze_products
os.environ.update(managed_environment(parent/'tmp'));os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',DOTNET_ROOT='D:/Tools/dotnet9')
build=root/'build/ninja-msvc-release';os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LOADER_DEBUG','VK_LAYER_ENABLES','AZURE_CPU_WORK_REPORT','AZURERENDER_RESOURCE_ROOT','AZURE_DISABLE_COMPUTED_MATERIAL_VIEW']:os.environ.pop(key,None)
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
short=read(parent/'cost-results.json');assert short['productionEfficiencyPassed'] and short['rows'][1]['summary']['gpu']['p95']<=16.6 and short['rows'][1]['summary']['cpu']['p95']<=8
assert read(parent/'memory-results.json')['peakWorkingSetBytes']<=2*1024**3
before=inputs(root);assert before==read(parent/'green-source-lock.json')
verify(root,read(parent/'release-build-provenance.json'))
exe=build/'AzurePlayer.exe';products=freeze_products(root,exe,build/'AzureRender.exe')
lock=read(parent/'frozen-project-inputs.json');assert len(lock)==1729 and all(digest(Path(p))==h for p,h in lock.items())
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
timing=out/'timing.json'
cmd=[str(exe),'--project',str(project),'--resource-root',str(build),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','60','--smoke-frames','2100','--gpu-timing','--gpu-timing-output',str(timing)]
write('command.json',dict(command=cmd,products=products))
envpath=out/'environment.json';env=wait_and_record(envpath,timeout=60)
observations=[];start=time.monotonic()
with RunEnvironmentMonitor(env,path=envpath,interval=2),(out/'process.log').open('wb') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
 try:
  while p.poll() is None:
   try:observations.append(dict(seconds=time.monotonic()-start,**memory_snapshot(p.pid)))
   except OSError:
    if p.poll() is not None:break
    raise
   if time.monotonic()-start>600:raise TimeoutError(cmd)
   time.sleep(.05)
 finally:
  if p.poll() is None:p.kill();p.wait()
  write('memory-observations.json',observations)
assert p.returncode==0
data=read(timing);assert data['sceneWidth']==1920 and data['sceneHeight']==1080
assert data['computedMaterialViewPipelines']==108 and data['computedMaterialViewFrameEligible'] and data['computedMaterialViewSelectionsTotal']>0
log=(out/'process.log').read_text(errors='replace');assert 'Allocator after unload: buffers=0 images=0' in log
samples=list(csv.DictReader((out/'timing.csv').open()));selected=[r for r in samples if 301<=int(r['frame'])<=2100]
assert len(selected)==1800 and len(data['cpuFrame']['workSamplesMs'])==2100
def stats(xs):return dict(samples=len(xs),mean=float(np.mean(xs)),p95=float(np.percentile(xs,95)),maximum=float(np.max(xs)))
statsByRange={n:stats([float(r[k]) for r in selected]) for n,k in [('gpu','frameMs'),('main','sceneMs'),('shadow','shadowMs'),('post','postProcessMs')]}
statsByRange['cpu']=stats(data['cpuFrame']['workSamplesMs'][300:])
assert observations and env['runObservations'] and not env['monitorErrors']
power=sorted({r['powerLimitWatts'] for r in env['runObservations'] if r['powerLimitWatts'] is not None})
thermal=any(any(v is True for v in r['thermalSlowdown'].values()) for r in env['runObservations'])
ac=sorted({r['hostPower']['acLineStatus'] for r in env['runObservations']})
result=dict(status='software-diagnostic',seconds=time.monotonic()-start,dimensions=[1920,1080],fixedSimulationFps=60,warmupFrames=300,
   measuredFrames=1800,timing=statsByRange,gpuBudgetPassed=statsByRange['gpu']['p95']<=16.6,cpuBudgetPassed=statsByRange['cpu']['p95']<=8,
   peakWorkingSetBytes=max(v['peak'] for v in observations),allocator=data.get('allocator'),powerLimits=power,
   acLineStates=ac,thermalSlowdownObserved=thermal,allocatorZero=True,fixed80WattsAccepted=False,formalPerformancePassed=False)
assert inputs(root)==before and all(digest(Path(p))==h for p,h in products.items()) and all(digest(Path(p))==h for p,h in lock.items())
write('results.json',result);print(json.dumps(result),flush=True)
