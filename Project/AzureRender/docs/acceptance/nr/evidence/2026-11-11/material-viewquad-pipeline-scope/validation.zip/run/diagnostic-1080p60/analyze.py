from pathlib import Path
import csv,json
import numpy as np
out=Path(__file__).resolve().parent
env=json.loads((out/'environment.json').read_text());run=env['runObservations']
thermal=[{k:x[k] for k in ['seconds','temperature','graphicsClockMHz','powerLimitWatts','thermalSlowdown']} for x in run if any(v is True for v in x['thermalSlowdown'].values())]
rows=[x for x in csv.DictReader((out/'timing.csv').open()) if 301<=int(x['frame'])<=2100]
assert len(rows)==1800 and thermal
ranges=[]
for i in range(6):
 group=rows[i*300:(i+1)*300]
 values={k:np.array([float(x[k]) for x in group]) for k in ['frameMs','sceneMs','shadowMs','postProcessMs']}
 ranges.append(dict(first=int(group[0]['frame']),last=int(group[-1]['frame']),
    timing={k:dict(mean=float(v.mean()),p95=float(np.percentile(v,95))) for k,v in values.items()}))
result=dict(status='long-window-attribution',fixedWindowUnchanged=True,sampledThermalMarkers=thermal,ranges=ranges,
  interpretation='Thermal slowdown was observed during the run. Frame ranges describe the change in recorded cost; no controlled causal comparison or formal power qualification.')
(out/'thermal-attribution.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(firstThermal=thermal[0],lastThermal=thermal[-1],first=ranges[0],last=ranges[-1])))
