from pathlib import Path
import json,os,subprocess,sys,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import digest,inputs,verify
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1',VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
def invoke(label,cmd,timeout=800,env=None):
 with (out/(label+'.log')).open('wb') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,check=True,env=env)
before=inputs(root);assert before==read(out/'green-source-lock.json')
subprocess.run([sys.executable,'-X','utf8','-B',str(out/'build_scope.py'),'default','--inside'],check=True,timeout=1100)
rows=[]
for config in ['Release','Debug']:
 c=config.lower();build=root/('build/ninja-msvc-'+c);shaders=(build/'shaders').resolve()
 if config=='Debug':
  invoke(c+'-default-configure',['cmake','-S',str(root),'-B',str(build),'-U','AZURE_ENABLE_COMPUTED_MATERIAL_VIEW'],180)
  known=read(out/'green-program-sha256.json')
  generated=list(shaders.glob('*_viewquad.frag.spv'))
  assert all(p.resolve().parent==shaders and digest(p)==known[p.name] for p in generated)
  for p in generated:p.unlink()
 assert 'AZURE_ENABLE_COMPUTED_MATERIAL_VIEW:BOOL=OFF' in (build/'CMakeCache.txt').read_text()
 targets=['AzureComputedMaterialDepthPolicyRecordingTests','AzureComputedMaterialViewTests','AzureMaterialViewDeterminismGpuTests','AzureMaterialPipelinePolicyTests','AzureReferenceCameraBindingTests','AzureShaderCompilerContractTests']
 cmd=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
 for target in targets:cmd+=['--test-target',target]
 invoke(c+'-default-scoped-build',cmd,850)
 proof=read(build/'build-provenance.json');verify(root,proof);write(c+'-default-scoped-build-provenance.json',proof)
 baseline=read(out.parent/'20261111-063356-reference-camera-binding-main-integration-c12528'/(c+'-program-sha256.json'))
 cat=read(build/'shader-reload.json')['programs'];assert len(cat)==len(baseline)==886
 assert {p['output']:digest(shaders/p['output']) for p in cat}==baseline
 assert not list(shaders.glob('*_viewquad.frag.spv'))
 selector=r'^(AzureRender\.(ComputedMaterialView|ComputedMaterialDepthPolicyRecording|MaterialPipelinePolicy|ReferenceCameraBinding|ShaderCompilerContract|ShaderCatalogCompilation)|AzureEngine\.(ModuleBoundaries|ModuleBoundaryFixtures))$'
 junit=out/(c+'-default-tests.xml')
 invoke(c+'-default-tests',['ctest','--test-dir',str(build),'-C',config,'--output-on-failure','--no-tests=error','-R',selector,'--output-junit',str(junit)],390)
 cases=ET.parse(junit).findall('.//testcase');assert len(cases)==8 and not any(x.find('failure') is not None or x.find('skipped') is not None for x in cases)
 if config=='Debug':
  for dev,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
   env=os.environ|{'VK_LOADER_DRIVERS_SELECT':driver,'PATH':str(build)+';'+os.environ['PATH']}
   folder=out/(c+'-default-'+dev)
   invoke(c+'-default-'+dev+'-recording',[str(build/'AzureComputedMaterialDepthPolicyRecordingTests.exe'),str(shaders),str(folder)],100,env)
   x=read(folder/'results.json');assert x['status']=='passed' and x['validationErrors']==0 and all(not y['frameEligible'] and y['preparedPipelines']==y['selections']==0 for y in x['cases'])
 verify(root,proof);assert inputs(root)==before
 rows.append(dict(config=config,tests=len(cases),skipped=0,activePrograms=886,aliases=0,sourceUnchanged=True))
 write('default-checks.json',rows);print(json.dumps(rows[-1]),flush=True)
subprocess.run([sys.executable,'-X','utf8','-B',str(out/'default-capture/capture.py')],check=True,timeout=650)
assert all(digest(root/p)==h for p,h in read(out/'protected-files.json').items())
