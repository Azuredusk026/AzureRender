from pathlib import Path
import json
root=Path.cwd(); out=Path(__file__).resolve().parent
dest=root/'docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope'
result=json.loads((dest/'results.json').read_text());proof=json.loads((dest/'archive-verification.json').read_text())
assert len(result['optInGpuChecks'])==4 and sum(x['tests'] for x in result['defaultChecks'])==16
assert result['shortGpuBudgetPassed'] and result['memoryWithinObservedBudget'] and not result['diagnostic1080p60']['gpuBudgetPassed'] and not result['productionAdopted']
def edit(name,needle,replacement):
 p=root/name; s=p.read_text(encoding='utf-8-sig');assert s.count(needle)==1,name
 p.write_text(s.replace(needle,replacement),encoding='utf-8')
p=root/'docs/acceptance/nr/material-viewquad-pipeline-scope.md'
s=p.read_text(encoding='utf-8');assert '## 构建与归档' not in s
p.write_text(s+f"""
## 构建与归档

显式候选的两配置各有 1014 份活动程序，摘要完全一致。
两设备和两配置共执行四次实际材质视图回归。
共核对 1198080 个像素，验证层及资源释放检查通过。

两配置的标准构建各有 886 份活动参考程序。
标准构建共通过十六项检查，原始四帧摘要及 RGB 精确一致。
标准宿主实测记录可在归档中核对。

[结果清单](evidence/2026-11-11/material-viewquad-pipeline-scope/results.json)
及[验证归档](evidence/2026-11-11/material-viewquad-pipeline-scope/validation.zip)
保存两个构建配置、设备检查及原始计时数据。
归档共 {proof['members']} 项，大小为 {proof['bytes']} 字节，成员摘要全部通过。
""",encoding='utf-8')
edit('README.md','# AzureRender 工程\n\n','# AzureRender 工程\n\n[材质组合管线范围验收](docs/acceptance/nr/material-viewquad-pipeline-scope.md)通过原始四帧、工作集和短时净收益检查。\n1080p60 诊断继续受 GPU 帧预算和设备供电条件约束。\n\n')
edit('CHANGELOG.md','# Changelog\n\n','# Changelog\n\n## 2026-11-11 材质组合管线范围\n\n- 按普通及固定类别准备已使用的照明和覆盖组合。\n- 原始四帧准备 108 份候选管线，工作集约为 2.047 GB。\n- 短测 GPU P95 为 16.40 毫秒，长窗口诊断结果见[验收记录](docs/acceptance/nr/material-viewquad-pipeline-scope.md)。\n\n')
edit('docs/plans/azure-engine-plan.md','## 当前执行顺序\n\n','## 当前执行顺序\n\n[材质组合管线范围验收](../acceptance/nr/material-viewquad-pipeline-scope.md)通过原始四帧及短时净收益。\n候选四帧加载的峰值工作集约为 2.047 GB。\n1080p60 诊断的 GPU P95 约为 18.04 毫秒，标准构建采用参考族。\n\n')
edit('docs/project-status.md','# 项目现状\n\n','# 项目现状\n\n[材质组合管线范围](acceptance/nr/material-viewquad-pipeline-scope.md)通过工作集及短时成本检查。\n正式固定功率、长窗口 GPU 帧预算及完整交付继续验收。\n\n')
edit('docs/runtime/computed-material-view.md','各管线共享布局、专用常量及附件规则。','各管线共享布局、专用常量及附件规则。\n\n优化准备限定普通和固定类别的专用材质。\n已加载材质提供照明、覆盖及朝向组合。\n动态类别采用参考管线。')
edit('docs/acceptance/nr/material-viewquad-production.md','[运行契约](../../runtime/computed-material-view.md)说明候选的构建及选择条件。','[运行契约](../../runtime/computed-material-view.md)说明候选的构建及选择条件。\n专用材质准备及长窗口结果见[管线范围验收](material-viewquad-pipeline-scope.md)。')
edit('docs/plans/2026-11-11-material-viewquad-pipeline-scope.md','未达门槛的结果保存在隔离候选记录。','未达门槛的结果保存在隔离候选记录。\n[管线范围验收](../acceptance/nr/material-viewquad-pipeline-scope.md)记录实际宿主及当前诊断。')
