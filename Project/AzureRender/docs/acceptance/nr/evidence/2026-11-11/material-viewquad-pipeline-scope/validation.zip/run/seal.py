from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs,verify
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def encode(v):return (json.dumps(v,indent=2)+'\n').encode()
base=subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()
assert base=='81a27d5'
assert inputs(root)==read(out/'green-source-lock.json')
protected=read(out/'protected-files.json');assert len(protected)==13 and all(digest(root/p)==h for p,h in protected.items())
frozen=read(out/'frozen-project-inputs.json');assert len(frozen)==1729 and all(digest(Path(p))==h for p,h in frozen.items())
red=read(out/'red-nvidia/results.json')['cases'][0]; assert red['preparedPipelines']==26 and red['selections']==4
recordings={key:read(out/(key+'/results.json')) for key in ['green-nvidia','green-intel','default-nvidia','default-intel']}
positive=recordings['green-nvidia']['cases'][0];assert positive['preparedPipelines']==8 and positive['selections']==4
assert all(x['status']=='passed' and x['validationErrors']==0 and len(x['cases'])==3 and all(c['zeroAllocator'] for c in x['cases']) for x in recordings.values())
assert all(c['preparedPipelines']==c['selections']==0 for key,x in recordings.items() for c in (x['cases'][1:] if key=='green-nvidia' else x['cases']))
candidate=read(out/'green-results.json');default=read(out/'default-results.json')
assert candidate['programs']==1014 and candidate['aliases']==128 and default['programs']==886 and default['aliases']==0
assert read(out/'red-program-sha256.json')==read(out/'green-program-sha256.json')
capture=read(out/'capture-results.json');assert len(capture['frames'])==4 and capture['exitCode']==0
assert all(capture[k] for k in ['validationClean','allocatorZero','sourceUnchanged','programsUnchanged','projectInputsUnchanged'])
manifest=read(out/'capture-manifest.json');selection={k:v for k,v in manifest.items() if k.startswith('computedMaterialView')}
assert 0<selection['computedMaterialViewPipelines']<464 and selection['computedMaterialViewSelectionsTotal']>0
memory=read(out/'memory-results.json')
assert memory['peakWorkingSetBytes']<=2*1024**3
long=read(out/'diagnostic-1080p60/results.json');assert long['measuredFrames']==1800 and long['warmupFrames']==300 and not long['formalPerformancePassed']
thermal=read(out/'diagnostic-1080p60/thermal-attribution.json');assert thermal['fixedWindowUnchanged'] and len(thermal['ranges'])==6
gpuChecks=read(out/'opt-in-gpu-results.json');assert len(gpuChecks)==4 and sum(x['result']['pixelsCompared'] for x in gpuChecks)==1198080
assert all(x['result']['zeroAllocator'] and x['result']['validationErrors']==0 for x in gpuChecks)
defaultChecks=read(out/'default-checks.json');assert len(defaultChecks)==2 and sum(x['tests'] for x in defaultChecks)==16 and all(x['aliases']==0 for x in defaultChecks)
defaultCapture=read(out/'default-capture/capture-results.json');assert defaultCapture['frames']==capture['frames'] and defaultCapture['validationClean'] and defaultCapture['allocatorZero']
assert read(out/'default-capture/capture-manifest.json')['computedMaterialViewFallback']=='build-disabled'
cost=read(out/'cost-results.json');assert cost['sourceAndProgramsUnchanged'] and cost['projectInputsUnchanged']
gpu=cost['rows'][1]['summary']['gpu']['p95'];cpu=cost['rows'][1]['summary']['cpu']['p95']
original=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames'
dup=[]
for folder in [out,out/'default-capture']:
 for frame in capture['frames']:
  p=folder/'frames'/frame['name'];ref=original/frame['name'];h=digest(p)
  assert h==digest(ref)==frame['sha256']==frame['referenceSha256'] and frame['changedPixels']==frame['maximumByteError']==0
  dup.append(dict(path=str(p),reference=str(ref),sha256=h,bytes=p.stat().st_size))
result=dict(status='specialized-opt-in-candidate',sourceBase=base,defaultBuildOption='OFF',productionAdopted=False,
  replayAttribution=read(out/'scope-cost-attribution.json'),recordingRed=red,recordings=recordings,
  candidateBuild=candidate,defaultBuild=default,selection=selection,originalFour=capture,memory=memory,
  diagnostic1080p60=long,thermalAttribution=thermal,optInGpuChecks=gpuChecks,defaultChecks=defaultChecks,defaultOriginalFour=defaultCapture,
  memoryWithinObservedBudget=memory['peakWorkingSetBytes']<=2*1024**3,
  shortGpuBudgetPassed=gpu<=16.6,shortCpuBudgetPassed=cpu<=8,shortEfficiency=cost,
  defaultRuntimeProof=read(out/'default-build-provenance.json')['schemaVersion'] if 'schemaVersion' in read(out/'default-build-provenance.json') else True,
  fixed80WattsAccepted=False,formalPerformancePassed=False,projectInputsExact=1729,protectedFilesExact=13,overall='failed-user-review')
for config in ['release','debug']:verify(root,read(out/(config+'-default-scoped-build-provenance.json')))
(out/'results.json').write_bytes(encode(result));(out/'duplicate-frame-inventory.json').write_bytes(encode(dup))
dest=root/'docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope';dest.mkdir(parents=True,exist_ok=True)
zpath=dest/'validation.zip'; members={}
def add(z,p,n):
 b=p.read_bytes();assert n not in members
 members[n]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());z.writestr(n,b)
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(out.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(out)
  if rel.parts[0] in ['tmp','frames']:continue
  if p.suffix in ['.json','.py','.log','.xml','.csv','.hpp','.cpp','.inc']:
   add(z,p,'run/'+rel.as_posix())
 for f in ['CMakeLists.txt','src/scenes/CharacterComputedMaterialView.inc','src/scenes/CharacterMaterialSampling.inc','src/scenes/CharacterSceneRenderer.hpp','tests/ComputedMaterialDepthPolicyRecordingTests.cpp']:
  add(z,root/f,'source/'+f)
 z.writestr('member-sha256.json',encode(members))
assert zpath.stat().st_size<8*1024**2
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and set(z.namelist())==set(members)|{'member-sha256.json'}
 assert all(len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256'] for n,v in members.items())
archive=dict(bytes=zpath.stat().st_size,members=len(members)+1,sha256=digest(zpath),memberHashesVerified=True)
(dest/'archive-verification.json').write_bytes(encode(archive));(dest/'results.json').write_bytes(encode(result))
for row in dup:
 p=Path(row['path']);assert p.resolve().parent in [(out/'frames').resolve(),(out/'default-capture/frames').resolve()] and digest(p)==digest(Path(row['reference']))==row['sha256'];p.unlink()
(out/'identical-frames-reclaimed.json').write_bytes(encode(dict(files=len(dup),bytes=sum(x['bytes'] for x in dup),archive=archive)))
print(json.dumps(dict(archive=archive,pipelines=selection['computedMaterialViewPipelines'],selections=selection['computedMaterialViewSelectionsTotal'],peakWorkingSetBytes=memory['peakWorkingSetBytes'],gpuP95=gpu,cpuP95=cpu,efficiencyPassed=cost['productionEfficiencyPassed'])))
