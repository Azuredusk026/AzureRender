from pathlib import Path
import collections,hashlib,json,zipfile
out=Path(__file__).resolve().parent
root=Path.cwd()
archive=root/'docs/acceptance/nr/evidence/2026-11-11/material-fragment-work-scope/validation.zip'
with zipfile.ZipFile(archive) as z:
 v=json.loads(z.read('results.json'))
 p=json.loads(z.read('capture/pipeline-scope.json'))
 assert z.testzip() is None
maps={x['pipeline']:x['events'] for x in p['groups']}
replay_path=out.parent/'20261111-021128-quad-depth-visibility-local-qualification-1ea541/combined/compare-state.json'
replay=json.loads(replay_path.read_text())
assert v['captureSha256']==replay['captureSha256']
g=collections.defaultdict(list)
for x in v['groups']:
 key='ordinary' if x['ordinary'] else 'dynamic' if x['fixedClass']==2**32-1 else 'fixed'
 g[key].extend(maps[x['pipeline']])
assert sorted(e for events in g.values() for e in events)==sorted(replay['eventScopes']['materials'])
rows={}
for k,events in g.items():
 d=collections.defaultdict(list)
 for row in replay['timings']:
  d[row['mode']].append(sum(row['milliseconds'][str(x)] for x in events))
 a=sum(d['baseline'])/2;b=sum(d['candidate'])/2
 rows[k]=dict(events=len(events),referenceMilliseconds=a,candidateMilliseconds=b,savedMilliseconds=a-b)
specialized=sum(rows[k]['savedMilliseconds'] for k in ['ordinary','fixed'])
savings=sum(v['savedMilliseconds'] for v in rows.values())
result=dict(status='scope-cost-attribution',captureSha256=replay['captureSha256'],archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),replayResultsSha256=hashlib.sha256(replay_path.read_bytes()).hexdigest(),rows=rows,specializedSavingsFraction=specialized/savings,scope='Individual draws in a frozen replay; all pipelines used the original combined configuration, no native subset timing claimed')
(out/'scope-cost-attribution.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
