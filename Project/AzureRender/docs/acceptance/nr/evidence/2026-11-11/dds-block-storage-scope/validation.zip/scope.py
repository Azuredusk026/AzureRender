from pathlib import Path
import json,struct,hashlib,collections,time
root=Path.cwd();out=root/'build/runs/20261111-010805-dds-block-storage-scope-534c65';lock=json.loads((root/'build/runs/20261111-005441-reference-position-frame-main-integration-59835c/frozen-project-inputs.json').read_text());rows=[];start=time.monotonic()
# DXGI format numeric values match the Windows SDK dxgiformat contract.
blocks={70:('bc1-typeless',8),71:('bc1-unorm',8),72:('bc1-srgb',8),73:('bc2-typeless',16),74:('bc2-unorm',16),75:('bc2-srgb',16),76:('bc3-typeless',16),77:('bc3-unorm',16),78:('bc3-srgb',16),79:('bc4-typeless',8),80:('bc4-unorm',8),81:('bc4-snorm',8),82:('bc5-typeless',16),83:('bc5-unorm',16),84:('bc5-snorm',16),94:('bc6-typeless',16),95:('bc6-ufloat',16),96:('bc6-sfloat',16),97:('bc7-typeless',16),98:('bc7-unorm',16),99:('bc7-srgb',16)}
legacy={b'DXT1':('bc1',8),b'DXT3':('bc2',16),b'DXT5':('bc3',16),b'ATI1':('bc4',8),b'BC4U':('bc4',8),b'ATI2':('bc5',16),b'BC5U':('bc5',16)}
for name,expected in lock.items():
 p=Path(name)
 if p.suffix.lower()!='.dds':continue
 b=p.read_bytes();actual=hashlib.sha256(b).hexdigest();assert actual==expected and b[:4]==b'DDS ' and struct.unpack_from('<I',b,4)[0]==124
 width=struct.unpack_from('<I',b,16)[0];height=struct.unpack_from('<I',b,12)[0];mips=max(1,struct.unpack_from('<I',b,28)[0]);four=b[84:88];fmt=struct.unpack_from('<I',b,128)[0] if four==b'DX10' else None;kind=blocks.get(fmt) if four==b'DX10' else legacy.get(four);rgba=0;w=width;h=height;packed=0
 for i in range(mips):
  rgba+=w*h*4
  if kind:packed+=max(1,(w+3)//4)*max(1,(h+3)//4)*kind[1]
  w=max(w//2,1);h=max(h//2,1)
 rows.append(dict(path=name,sha256=actual,width=width,height=height,mipLevels=mips,fourCC=four.decode('ascii',errors='replace'),dxgiFormat=fmt,blockFormat=kind[0] if kind else None,encodedBytes=len(b),rgbaMipBytes=rgba,blockMipBytes=packed))
assert len(rows)==85
formats=collections.Counter((r['blockFormat'] or 'not-block') for r in rows);result=dict(status='source-dds-header-scope',sourceBase='7a7b98c',sourceFiles=len(rows),sourceHashesVerified=True,formats=dict(formats),encodedBytes=sum(r['encodedBytes'] for r in rows),rgbaMipBytes=sum(r['rgbaMipBytes'] for r in rows),blockSourceRgbaBytes=sum(r['rgbaMipBytes'] for r in rows if r['blockFormat']),blockSourceBytes=sum(r['blockMipBytes'] for r in rows if r['blockFormat']),seconds=time.monotonic()-start,rows=rows,scope='Frozen standalone DDS source inventory; actual resident cache identities, authored mip policy and exact device filtering remain separate')
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2));print('DXGI formats',collections.Counter(r['dxgiFormat'] for r in rows));print('FourCC',collections.Counter(r['fourCC'] for r in rows))
