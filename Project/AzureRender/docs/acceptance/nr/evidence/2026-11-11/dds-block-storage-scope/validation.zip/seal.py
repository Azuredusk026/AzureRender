from pathlib import Path
import json,sys,zipfile,hashlib,shutil
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest
frame=root/'build/runs/20261111-005441-reference-position-frame-main-integration-59835c'
shutil.copyfile(frame/'frozen-project-inputs.json',out/'frozen-project-inputs.json')
shutil.copyfile(frame/'protected-files.json',out/'protected-files.json')
assert all(digest(root/p)==h for p,h in json.loads((out/'protected-files.json').read_text()).items())
sourceNames=['src/assets/image/TextureContainerAdapter.cpp','src/assets/image/ImageCodec.hpp','src/assets/image/ImageCodec.cpp','src/app/AzureRenderApp.cpp','src/rhi/Rhi.hpp']
source={p:digest(root/p) for p in sourceNames}
(out/'runtime-scope.json').write_text(json.dumps(dict(source=source,decodedRepresentation='Authored RGBA8 mip arrays and sourceCompression string; original block payload not retained',normalProcessing='BC5 normal reconstruction must be evaluated against processed cache pixels',uploadContract='IRhi one-shot buffer-to-image copy uses bytesPerTexel, not block dimensions',deviceCreation='AzureRenderApp does not request textureCompressionBC in its enabled VkPhysicalDeviceFeatures',formatQuery='Physical format properties only; no logical device creation or enabled-feature proof',candidateStatus='Source survey; no production candidate, cache saving or native admission asserted'),indent=2))
result=json.loads((out/'results.json').read_text());result.update(headerPotentialReductionBytes=result['blockSourceRgbaBytes']-result['blockSourceBytes'],runtimeSourceHashes=source,physicalFormats=json.loads((out/'physical-format-properties.json').read_text()),protectedFilesExact=13,productionCandidate=False,actualGpuSavingMeasured=False,overall='failed-user-review')
(out/'results.json').write_text(json.dumps(result,indent=2))
dest=root/'docs/acceptance/nr/evidence/2026-11-11/dds-block-storage-scope';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.iterdir()):
        if p.is_file() and p.suffix in ['.json','.py']:
            members[p.name]=digest(p);z.write(p,p.name)
    z.writestr('member-sha256.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in members.items())
assert archive.stat().st_size<8*1024*1024
verification=dict(bytes=archive.stat().st_size,members=len(members)+1,sha256=digest(archive),memberHashesVerified=True)
(dest/'archive-verification.json').write_text(json.dumps(verification,indent=2));(dest/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(verification))
