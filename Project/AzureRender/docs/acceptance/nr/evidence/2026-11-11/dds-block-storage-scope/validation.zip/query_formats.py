from pathlib import Path
import ctypes as c,json,os
out=Path('build/runs/20261111-010805-dds-block-storage-scope-534c65')
class App(c.Structure):_fields_=[('sType',c.c_uint32),('pNext',c.c_void_p),('pApplicationName',c.c_char_p),('applicationVersion',c.c_uint32),('pEngineName',c.c_char_p),('engineVersion',c.c_uint32),('apiVersion',c.c_uint32)]
class Create(c.Structure):_fields_=[('sType',c.c_uint32),('pNext',c.c_void_p),('flags',c.c_uint32),('pApplicationInfo',c.POINTER(App)),('enabledLayerCount',c.c_uint32),('ppEnabledLayerNames',c.c_void_p),('enabledExtensionCount',c.c_uint32),('ppEnabledExtensionNames',c.c_void_p)]
class Format(c.Structure):_fields_=[('linearTilingFeatures',c.c_uint32),('optimalTilingFeatures',c.c_uint32),('bufferFeatures',c.c_uint32)]
v=c.WinDLL('vulkan-1.dll');app=App(0,None,b'AzureStorageScope',1,b'AzureRender',1,(1<<22)|(1<<12));info=Create(1,None,0,c.pointer(app),0,None,0,None);instance=c.c_void_p()
v.vkCreateInstance.argtypes=[c.POINTER(Create),c.c_void_p,c.POINTER(c.c_void_p)];assert v.vkCreateInstance(c.byref(info),None,c.byref(instance))==0
v.vkEnumeratePhysicalDevices.argtypes=[c.c_void_p,c.POINTER(c.c_uint32),c.POINTER(c.c_void_p)];count=c.c_uint32();assert v.vkEnumeratePhysicalDevices(instance,c.byref(count),None)==0;devices=(c.c_void_p*count.value)();assert v.vkEnumeratePhysicalDevices(instance,c.byref(count),devices)==0
v.vkGetPhysicalDeviceProperties.argtypes=[c.c_void_p,c.c_void_p];v.vkGetPhysicalDeviceFormatProperties.argtypes=[c.c_void_p,c.c_uint32,c.POINTER(Format)];rows=[]
for dev in devices:
 raw=c.create_string_buffer(4096);v.vkGetPhysicalDeviceProperties(dev,raw);name=raw.raw[20:276].split(b'\0')[0].decode();formats=[]
 for value,label in [(141,'BC5_UNORM'),(145,'BC7_UNORM'),(146,'BC7_SRGB')]:
  f=Format();v.vkGetPhysicalDeviceFormatProperties(dev,value,c.byref(f));formats.append(dict(format=value,name=label,optimalTilingFeatures=f.optimalTilingFeatures,sampled=bool(f.optimalTilingFeatures&1),linearFilter=bool(f.optimalTilingFeatures&0x1000)))
 import struct
 rows.append(dict(device=name,vendorId=struct.unpack_from('<I',raw.raw,8)[0],deviceId=struct.unpack_from('<I',raw.raw,12)[0],driverVersion=struct.unpack_from('<I',raw.raw,4)[0],formats=formats))
v.vkDestroyInstance.argtypes=[c.c_void_p,c.c_void_p];v.vkDestroyInstance(instance,None)
(out/'physical-format-properties.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
