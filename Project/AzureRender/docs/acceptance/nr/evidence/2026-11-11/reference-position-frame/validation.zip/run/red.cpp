#include "render/ReferencePositionFrame.hpp"
#include "render/ReferenceDepth.hpp"
using namespace azurerender;int main(){ReferencePositionFrame f;ReferenceDepthConfig c;c.schemaVersion=2;c.positionFrame=f;ReferenceDepthShaders s;s.positionFrame=ReferenceDepthPositionFrameShaders::load("missing");return int(referencePositionFrameCode(f));}
