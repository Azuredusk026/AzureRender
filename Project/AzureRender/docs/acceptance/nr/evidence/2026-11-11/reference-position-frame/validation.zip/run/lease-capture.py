from pathlib import Path
import sys,json,hashlib
out=Path(__file__).parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a';token=s.acquire_inputs(root/'build',out,['20261110-110844-hair-postvs-clip-source-03c2f0'],owner);path=Path('D:/Projects/FYP-coordination/quality-claim.json');claim=json.loads(path.read_text(encoding='utf-8'));claim['localInputLease'].append(token);claim['ownedFiles']+=['tests/ReferenceDepthCoverageGpuTests.cpp','tests/ReferenceDepthGpuTests.cpp','docs/runtime/reference-position-frame.md','docs/runtime/reference-depth.md'];path.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
capture=out.parent/'20261110-110844-hair-postvs-clip-source-03c2f0/vulkan-vertex.bin';old=json.loads((out.parent/'20261110-235205-actual-world-depth-source-bcce93/task-card.json').read_text());expected=old['inputsSha256'][str(capture)];assert hashlib.sha256(capture.read_bytes()).hexdigest()==expected
(out/'capture-lease.json').write_text(json.dumps({'token':token,'sha256':expected,'matchesPreviousFrozenInput':True},indent=2)+'\n')
