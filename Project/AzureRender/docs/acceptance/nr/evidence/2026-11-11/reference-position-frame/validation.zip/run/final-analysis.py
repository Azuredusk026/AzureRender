from pathlib import Path
import json,hashlib,numpy as np,re
out=Path(__file__).parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,digest in json.loads((out/'frozen-source.json').read_text()).items():
 if sha(root/n)==digest:continue
 assert n=='src/render/ReferenceDepth.hpp'
 tested=out/'tested-source/ReferenceDepth.hpp';assert sha(tested)==digest
 semantic=lambda p:re.sub(r'\s+','',re.sub(r'//[^\n]*','',p.read_text()))
 assert semantic(tested)==semantic(root/n)
identities=[json.loads((out/(c+'-identity.json')).read_text()) for c in ['release','debug']];assert identities[0]['programSha256']==identities[1]['programSha256']
rows=[]
for c in ['release','debug']:
 r=json.loads((out/(c+'-gpu-results.json')).read_text());assert len(r)==6 and all(v['exitCode']==0 and v['validationClean'] for v in r)
 for v in r:
  text=(out/(c+'-'+v['device']+'-'+v['target']+'.log')).read_text()
  expected='832700 exact frame components' if 'PositionFrame' in v['target'] else '20992 exact masked R32/D32 values; 50 rejects' if 'Coverage' in v['target'] else '147840 exact R32/D32 values'
  assert expected in text and 'cleanup passed' in text,expected
 rows+=r
native=json.loads((out/'native-results.json').read_text());assert len(native['devices'])==2
for row in native['devices']:
 d=row['device'];a=np.fromfile(out/(d+'-actual-r32.bin'),dtype='<u4');b=np.fromfile(out.parent/'20261110-235205-actual-world-depth-source-bcce93'/(d+'-actual-r32.bin'),dtype='<u4');assert np.array_equal(a,b),d
 assert row['changedVisibilityPixels']==row['newFailures']==row['closedFailures']==0 and row['failures']==(0 if d=='nvidia' else 96)
 row['cpuMappedDepthPlaneExactValues']=int(a.size)
four=json.loads((out/'default-four-results.json').read_text());assert four['allExact'] and four['validationClean'] and four['allocatorZero']
assert not re.search('SYNC-HAZARD|VUID-|Validation (?:Error|Warning)',(out/'default-four.log').read_text(errors='replace'))
result={'status':'qualified-public-position-frame-native-intel-failures-retained','overall':'failed-user-review','baseCommit':'a6f7725','configurations':['Debug','Release'],'programs':858,'oldProgramsExact':855,'newPrograms':identities[0]['added'],'programConfigurationsBitExact':True,'framePointsPerEndpoint':208175,'exactFrameComponents':3330800,'exactR32D32Values':675328,'cpuFrameRejectionsPerBatch':13,'depthRejectionsPerBatch':15,'coverageRejectionsPerBatch':50,'nativeDepthPlanesMatchingCpuMapping':7372800,'nativeResults':native,'defaultFour':four,'identities':identities,'gpuResults':rows,'compiledSourceSha256':json.loads((out/'frozen-source.json').read_text())}
result['publishedSourceSha256']={n:sha(root/n) for n in result['compiledSourceSha256']}
(out/'final-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['nativeResults','defaultFour','identities','gpuResults','compiledSourceSha256','publishedSourceSha256']},indent=2))
