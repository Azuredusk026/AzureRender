from pathlib import Path
import json,subprocess,sys,os,re,hashlib
out=Path(__file__).parent;root=out.parents[2];configuration=sys.argv[1];build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug');rows=[]
for name,digest in json.loads((out/'frozen-source.json').read_text()).items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(build)+';'+env['PATH'])
 for target in ['AzureReferencePositionFrameGpuTests','AzureReferenceDepthGpuTests','AzureReferenceDepthCoverageGpuTests']:
  args=[str(build/'shaders/reference_position_frame_test.comp.spv'),str(out/'native-frame.bin'),str(out/'native-records.bin')] if 'PositionFrame' in target else [str(build/'shaders')]
  command=[str(build/(target+'.exe')),*args];label=configuration.lower()+'-'+device+'-'+target;print('START',label,flush=True)
  with (out/(label+'.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  text=(out/(label+'.log')).read_text(errors='replace');row={'configuration':configuration,'device':device,'target':target,'command':command,'exitCode':r.returncode,'validationClean':not bool(re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)',text,re.I))};rows.append(row);(out/(configuration.lower()+'-gpu-results.json')).write_text(json.dumps(rows,indent=2)+'\n');assert r.returncode==0 and row['validationClean'],text[-5000:];print('PASS',label,text.strip(),flush=True)
