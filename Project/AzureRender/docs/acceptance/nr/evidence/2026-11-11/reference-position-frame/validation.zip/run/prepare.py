from pathlib import Path
import sys,json,subprocess
out=Path(__file__).parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a';p=Path('D:/Projects/FYP-coordination/quality-claim.json');old=json.loads(p.read_text(encoding='utf-8'))
token=s.acquire_inputs(root/'build',out,['20261110-235205-actual-world-depth-source-bcce93','20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2','20261110-211719-alpha-ellipse-lod-5c69d6','20261110-003435-visibility-numeric-contract-4f95e7','20261110-173835-reference-depth-coverage-4b4afc','20261110-165124-reference-depth-source-4d1d7d','20261110-003031-reciprocal-compact-profile-4e7929'],owner)
mainToken=s.acquire_inputs(s.DEFAULT_BUILD,out,['20261027-022702-object-visibility-depth-reconstruction-c7312f'],owner)
s.maintenance.seal(root/'build',Path(old['taskPath']))
for t in old['localInputLease']:s.release_inputs(root/'build',t,owner)
for t in old['inputLease']:s.release_inputs(s.DEFAULT_BUILD,t,owner)
old.update(state='reference-position-frame-contract',lastCommit='a6f7725',taskPath=str(out),localInputLease=[token],inputLease=[mainToken],ownedFiles=['src/render/ReferencePositionFrame.hpp','shaders/reference_position_frame.glsl','shaders/reference_position_frame_test.comp','src/render/ReferenceDepth.hpp','src/render/ReferenceDepth.cpp','shaders/reference_depth.vert','CMakeLists.txt','tests/ReferencePositionFrameGpuTests.cpp','docs/plans/2026-11-11-reference-position-frame.md'],pendingCommand='CPU missing interface red check, then versioned frame and depth binding')
p.write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'red.cpp').write_text('#include "render/ReferencePositionFrame.hpp"\n#include "render/ReferenceDepth.hpp"\nusing namespace azurerender;int main(){ReferencePositionFrame f;ReferenceDepthConfig c;c.schemaVersion=2;c.positionFrame=f;ReferenceDepthShaders s;s.positionFrame=ReferenceDepthPositionFrameShaders::load("missing");return int(referencePositionFrameCode(f));}\n')
command='D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat cl /nologo /std:c++20 /EHsc /Zs /I"'+str(root/'src')+'" /I"D:/Tools/VulkanSDK/1.4.350.0/Include" "'+str(out/'red.cpp')+'"'
r=subprocess.run(command,shell=True,capture_output=True,text=True);(out/'red.log').write_text(r.stdout+r.stderr);assert r.returncode!=0 and 'ReferencePositionFrame.hpp' in r.stdout+r.stderr
(out/'task-card.json').write_text(json.dumps({'baseCommit':'a6f7725','scope':'Versioned signed-axis frame and public world-coordinate depth input','explorationSeconds':1800,'candidateSeconds':1200,'buildSeconds':1200,'gpuSeconds':600,'plannedBytes':100663296,'gate':'Bit-exact CPU/GPU frame, prior855 SPV identity, real world-depth source no new visibility failures, original gates retained'},indent=2)+'\n')
print('Missing public frame interface observed; input leases transferred and previous unit sealed')
