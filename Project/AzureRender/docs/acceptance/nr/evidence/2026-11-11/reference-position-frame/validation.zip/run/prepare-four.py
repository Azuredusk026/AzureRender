from pathlib import Path
import sys,json
out=Path(__file__).parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a';token=s.acquire_inputs(s.DEFAULT_BUILD,out,['20261103-234012-character-reference-stages-5abe6c'],owner);p=Path('D:/Projects/FYP-coordination/quality-claim.json');claim=json.loads(p.read_text(encoding='utf-8'));claim['inputLease'].append(token);p.write_text(json.dumps(claim,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'default-four.py').write_bytes((out.parent/'20261110-214332-material-uv-loop-qualification-cf1d1e/default-four.py').read_bytes())
print('Current Player differs from prior byte identity: fresh original four capture prepared and project input leased')
