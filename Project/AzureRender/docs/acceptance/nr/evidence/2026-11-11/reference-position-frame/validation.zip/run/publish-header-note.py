from pathlib import Path
import hashlib,json,re
out=Path(__file__).parent;root=out.parents[2];p=root/'src/render/ReferenceDepth.hpp';original=p.read_bytes();expected=json.loads((out/'frozen-source.json').read_text())['src/render/ReferenceDepth.hpp'];assert hashlib.sha256(original).hexdigest()==expected
folder=out/'tested-source';folder.mkdir(exist_ok=True);(folder/'ReferenceDepth.hpp').write_bytes(original)
text=p.read_text();text=text.replace('// Borrowed VERTEX_BUFFER vec4 positions (xyz camera-relative, w ignored),','// Borrowed VERTEX_BUFFER vec4 positions. Version1 consumes relative xyz;\n    // version2 transforms world xyz through positionFrame. The w value is ignored,')
def semantic(value):return re.sub(r'\s+','',re.sub(r'//[^\n]*','',value))
assert semantic(original.decode())==semantic(text)
p.write_text(text);(out/'published-header-note.json').write_text(json.dumps({'path':'src/render/ReferenceDepth.hpp','compiledSha256':expected,'publishedSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'semanticTokensIdentical':True,'change':'Clarify default relative positions and version2 world positions in API comment; implementation and tested binaries unchanged'},indent=2)+'\n')
