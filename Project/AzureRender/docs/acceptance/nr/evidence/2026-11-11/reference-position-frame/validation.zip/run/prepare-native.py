from pathlib import Path
import json
out=Path(__file__).parent;root=out.parents[2];public=out.parent/'20261110-211719-alpha-ellipse-lod-5c69d6';old=out.parent/'20261110-235205-actual-world-depth-source-bcce93'
for name in ['native-synthetic.cpp','private-compute-fixture.hpp']:(out/name).write_bytes((public/name).read_bytes())
source=(public/'native-coverage.cpp').read_text();needle='ReferenceDepthGpu producer(backend,{2560,1440},1,{},ReferenceDepthShaders::loadEllipseMasked(argv[1],queryMaterialUvGradientSupport(host.physical)))';assert needle in source
source=source.replace(needle,'auto shaders=ReferenceDepthShaders::loadEllipseMasked(argv[1],queryMaterialUvGradientSupport(host.physical));shaders.positionFrame=ReferenceDepthPositionFrameShaders::load(argv[1]);ReferenceDepthConfig config;config.schemaVersion=2;config.positionFrame=ReferencePositionFrame{};config.positionFrame->parameters.axes={-1,2,3,0};config.positionFrame->parameters.offset={0,-.8800051212310791F,-3.299988031387329F,0};\n        ReferenceDepthGpu producer(backend,{2560,1440},1,config,shaders)');(out/'native-coverage.cpp').write_text(source)
commands=[c.replace(str(public),str(out)).replace(public.as_posix(),out.as_posix()) for c in json.loads((public/'public-native-build-commands.json').read_text())];(out/'native-build-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
config=json.loads((old/'candidate-config.json').read_text());config['positions']=str(out/'native-world-positions.bin');(out/'candidate-config.json').write_text(json.dumps(config,indent=2)+'\n')
source=(old/'batch.py').read_text().replace("public=runs/'20261110-211719-alpha-ellipse-lod-5c69d6'","public=out").replace("calibration=runs/'20261110-003435-visibility-numeric-contract-4f95e7';rows=[]","calibration=runs/'20261110-003435-visibility-numeric-contract-4f95e7';rows=[]")
source=source.replace("str(out/'queries.bin')","str(out.parent/'20261110-235205-actual-world-depth-source-bcce93/queries.bin')").replace("str(out/'expected.bin')","str(out.parent/'20261110-235205-actual-world-depth-source-bcce93/expected.bin')")
source=source.replace("public/(device+'-public-rg8.bin')","out.parent/'20261110-235205-actual-world-depth-source-bcce93'/(device+'-actual-rg8.bin')")
source=source.replace("(out/'results.json')","(out/'native-results.json')");(out/'native-batch.py').write_text(source)
print('Public framed-depth caller source and one-factor comparison with previous CPU-mapped stream prepared')
