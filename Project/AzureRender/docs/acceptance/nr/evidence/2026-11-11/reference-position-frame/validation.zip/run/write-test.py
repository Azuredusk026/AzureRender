from pathlib import Path
out=Path(__file__).parent;root=out.parents[2];source=(root/'tests/ReferenceClipProjectionGpuTests.cpp').read_text()
source=source.replace('render/ReferenceClipProjection.hpp','render/ReferencePositionFrame.hpp').replace('#include "render/ReferenceFmaShader.hpp"','#include "render/ReferenceDepth.hpp"\n#include <algorithm>\n#include <set>')
start=source.index('struct Batch ');end=source.index('\n}\nint main',start)
source=source[:start]+'''struct Batch {ReferencePositionFrame profile;std::vector<Record> records;};
std::vector<Batch> analytic(){
    std::vector<Batch> batches;std::array<int,3> axes{1,2,3};
    do{for(unsigned signs=0;signs<8;++signs){
        Batch batch;for(unsigned i=0;i<3;++i)batch.profile.parameters.axes[i]=(signs&(1U<<i))?-axes[i]:axes[i];
        batch.profile.parameters.offset={-.8800051212310791F,1.F,0x1p-126F,0};
        for(int i=0;i<4096;++i){Record r{};
            for(unsigned axis=0;axis<3;++axis){
                if(i%8==0){std::uint32_t word=std::uint32_t(i/8+axis)|(axis==1?0x80000000U:0U);std::memcpy(&r.position[axis],&word,4);}
                else r.position[axis]=std::ldexp(float((i+int(axis)*19)%65-32),(i%25)-12);
            }
            r.position[3]=1;r.expected[3]=1;
            for(unsigned axis=0;axis<3;++axis){const int choice=batch.profile.parameters.axes[axis];const double value=r.position[std::abs(choice)-1];r.expected[axis]=float((choice<0?-value:value)+double(batch.profile.parameters.offset[axis]));}
            batch.records.push_back(r);
        }
        batches.push_back(std::move(batch));
    }}while(std::next_permutation(axes.begin(),axes.end()));
    Batch edge;edge.profile.parameters.offset={-0.F,0.F,-0x1p-126F,0};
    edge.records={{{-0.F,-0.F,0x1.000002p-126F,1},{-0.F,0.F,0x1p-149F,1}},{{0x1p-149F,-0x1p-149F,0x1p-126F,1},{0x1p-149F,-0x1p-149F,0,1}},{{1.F,0x1p-24F,0,1},{1.F,0x1p-24F,-0x1p-126F,1}}};batches.push_back(std::move(edge));return batches;
}'''+source[end:]
start=source.index('    ReferenceClipProjectionProfile p;');end=source.index('    if(argc==4)',start)
source=source[:start]+'''    ReferencePositionFrame p;unsigned refused=0;std::set<unsigned> codes;
    const auto reject=[&](ReferencePositionFrame value){try{validateReferencePositionFrame(value);}catch(const std::invalid_argument&){++refused;}};
    p.schemaVersion=0;reject(p);p.schemaVersion=2;reject(p);p={};p.reserved[0]=1;reject(p);p={};p.parameters.axes[3]=1;reject(p);
    p={};p.parameters.offset[3]=1;reject(p);p={};p.parameters.axes[0]=0;reject(p);p.parameters.axes[0]=4;reject(p);p.parameters.axes[0]=std::numeric_limits<int>::min();reject(p);
    p={};p.parameters.axes[1]=-1;reject(p);p={};p.parameters.offset[0]=std::numeric_limits<float>::infinity();reject(p);p.parameters.offset[0]=std::numeric_limits<float>::quiet_NaN();reject(p);
    p={};try{(void)referenceRelativePosition(p,{std::numeric_limits<float>::infinity(),0,0});}catch(const std::invalid_argument&){++refused;}
    p.parameters.offset[0]=std::numeric_limits<float>::max();try{(void)referenceRelativePosition(p,{std::numeric_limits<float>::max(),0,0});}catch(const std::invalid_argument&){++refused;}
    if(refused!=13)throw std::runtime_error("Position frame rejection contract failed");
    auto batches=analytic();for(std::size_t i=0;i<48;++i)codes.insert(referencePositionFrameCode(batches[i].profile));
    if(codes.size()!=48||referencePositionFrameCode(ReferencePositionFrame{})!=136)throw std::runtime_error("Frame axis codes must be unique and canonical");
'''+source[end:]
source=source.replace('ReferenceClipProjectionProfile','ReferencePositionFrame').replace('profile.size()!=80','profile.size()!=32').replace('profile.data(),80','profile.data(),32').replace('validateReferenceClipProjection','validateReferencePositionFrame').replace('projectReferenceClip','referenceRelativePosition')
source=source.replace('std::memcmp(value.data(),record.expected.data(),16)','std::memcmp(value.data(),record.expected.data(),12)')
start=source.index('    const auto inputShader=');end=source.index('    test::VulkanComputeFixture host',start)
source=source[:start]+'    const auto inputShader=readBinaryFile(argv[1]);\n'+source[end:]
source=source.replace('range{VK_SHADER_STAGE_COMPUTE_BIT,80}','range{VK_SHADER_STAGE_COMPUTE_BIT,32}').replace('createShaderModule(prepared.code)','createShaderModule(inputShader)')
source=source.replace('commands.pushConstants(layout,VK_SHADER_STAGE_COMPUTE_BIT,0,&batch.profile.parameters,80);','struct Push{std::array<unsigned,4> code{};std::array<float,4> offset{};} push;push.code[0]=referencePositionFrameCode(batch.profile);push.offset=batch.profile.parameters.offset;commands.pushConstants(layout,VK_SHADER_STAGE_COMPUTE_BIT,0,&push,32);')
source=source.replace('if(host.errors.load())','if(host.errors.load()||host.allocator.statistics().liveBuffers||host.allocator.statistics().liveImages)')
source=source.replace('nine projection and five shader rejection cases','thirteen frame rejection cases,48 signed axis permutations').replace('exact clip components','exact frame components').replace('80-byte profile','32-byte frame').replace('projection shader','position frame shader')
(root/'tests/ReferencePositionFrameGpuTests.cpp').write_text(source)
print('CPU and GPU frame contract tests prepared before implementation')
