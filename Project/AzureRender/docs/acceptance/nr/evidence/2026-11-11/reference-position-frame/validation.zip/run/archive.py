from pathlib import Path
import json,hashlib,zipfile,re,subprocess
out=Path(__file__).parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
note=json.loads((out/'published-header-note.json').read_text());note['publishedSha256']=sha(root/note['path']);(out/'published-header-note.json').write_text(json.dumps(note,indent=2)+'\n')
subprocess.run([__import__('sys').executable,str(out/'final-analysis.py')],check=True,capture_output=True)
plan=root/'docs/plans/2026-11-11-reference-position-frame.md';plan.write_text(plan.read_text(encoding='utf-8').replace('- [ ]','- [x]'),encoding='utf-8')
for name,prefix in [('README.md','docs/'),('docs/project-status.md',''),('docs/plans/azure-engine-plan.md','../'),('docs/plans/2026-11-09-native-quality.md','../')]:
 p=root/name;text=p.read_text(encoding='utf-8');text=text.replace('当前程序集为 855 份，实际相机与几何深度组合继续验收。','当前程序集为 858 份，实际相机与几何深度组合继续验收。')
 if '[参考坐标帧与世界坐标深度]' not in text:text+='\n[参考坐标帧与世界坐标深度]('+prefix+'acceptance/nr/reference-position-frame.md)通过双配置、双设备核对。\n公开世界坐标路径的完整深度平面与 CPU 预转换控制逐位一致，原始四帧摘要精确一致。\n实际索引、朝向及 UV 组合继续独立验收。\n'
 p.write_text(text,encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');anchor='## 2026-11-11 实际网格位置来源'
if '## 2026-11-11 参考坐标帧' not in text:text=text.replace(anchor,'## 2026-11-11 参考坐标帧\n\n- 提供版本一有符号轴置换及参考单精度偏移。\n- 版本二公开深度配置直接消费世界坐标，推送参数为 128 字节。\n- 两配置新增三份程序，既有 855 份程序摘要全部一致。\n- 十二个 GPU 进程核对 3330800 个坐标分量及 675328 个附件值。\n- 完整深度平面的 7372800 个值与 CPU 来源控制逐位一致。\n- 重新采集原始四帧并通过精确摘要、验证及资源清理门禁。\n- Intel 九十六处可见量超差与生产头发完整颜色继续验收。\n\n'+anchor)
p.write_text(text,encoding='utf-8')
result=json.loads((out/'final-results.json').read_text());dest=root/'docs/acceptance/nr/evidence/2026-11-11/reference-position-frame';dest.mkdir(parents=True,exist_ok=True)
catalog={'programs':858,'configurationsIdentical':True,'prior855ProgramsExact':True,'sha256':result['identities'][0]['programSha256']};(dest/'program-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
source=list(result['publishedSourceSha256'])+['docs/runtime/reference-position-frame.md','docs/runtime/reference-depth.md','docs/plans/2026-11-11-reference-position-frame.md','docs/acceptance/nr/reference-position-frame.md']
files={'run/'+p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and p.suffix in {'.py','.json','.log','.bin','.cpp','.hpp'} and 'default-four-frames' not in p.parts and 'tmp' not in p.parts}
files.update({'source/'+n:root/n for n in source});files['program-catalog.json']=dest/'program-catalog.json';build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release';files['build/shader-reload.json']=build/'shader-reload.json'
for n in result['newPrograms']:files['build/'+n]=build/'shaders'/n
old=out.parent/'20261110-235205-actual-world-depth-source-bcce93'
for d in ['nvidia','intel']:files['baseline/'+d+'-r32.bin']=old/(d+'-actual-r32.bin');files['baseline/'+d+'-rg8.bin']=old/(d+'-actual-rg8.bin')
members={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()};archive=dest/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result.update(publishedHeaderNote=note,programCatalogSha256=sha(dest/'program-catalog.json'),archive={'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members)+1});(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n')
for name in [n for n in source if n.endswith('.md')]:
 p=root/name;text=p.read_text(encoding='utf-8')
 for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(name,sentence)
 for link in re.findall(r'\]\(([^)]+)\)',text):
  if not re.match(r'(https?:|#)',link):assert (p.parent/link.split('#')[0]).exists(),(name,link)
print(json.dumps(result['archive']))
