from pathlib import Path
import json,hashlib,subprocess,sys
out=Path(__file__).parent;root=out.parents[2];configuration=sys.argv[1];build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=json.loads((root/'docs/acceptance/nr/evidence/2026-11-10/material-primary-uv-policy/program-catalog.json').read_text())['sha256'];catalog=json.loads((build/'shader-reload.json').read_text());programs={p['output']:sha(build/'shaders'/p['output']) for p in catalog['programs']};assert len(programs)==858
changed=[n for n in baseline if baseline[n]!=programs.get(n)];assert not changed,changed
for n,digest in json.loads((out/'frozen-source.json').read_text()).items():assert sha(root/n)==digest,n
command=[str(build/'AzureReferencePositionFrameGpuTests.exe'),'--cpu-only'];r=subprocess.run(command,capture_output=True,text=True,timeout=60);(out/(configuration.lower()+'-cpu-frame.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
v={'configuration':configuration,'programs':858,'oldProgramsExact':855,'added':sorted(set(programs)-set(baseline)),'cpuFrameExitCode':r.returncode,'cpuFrameCommand':command,'playerSha256':sha(build/'AzurePlayer.exe'),'programSha256':programs};(out/(configuration.lower()+'-identity.json')).write_text(json.dumps(v,indent=2)+'\n');print(configuration,'855 prior programs exact,3 added, CPU frame contract passed')
