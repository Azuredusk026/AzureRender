from pathlib import Path
import json,re,subprocess,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent;folder=out/'preflight';folder.mkdir(exist_ok=True)
text,n=re.subn(r'nonuniformEXT\((material\.textureBase \+ [0-8]u)\)',lambda m:'('+m.group(1)+')',(root/'shaders/mesh.frag').read_text());assert n==9
source=folder/'uniform-material.frag';source.write_text(text)
manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());profile=json.loads((out/'replay-profile.json').read_text())
eligible={p['output']:p for p in manifest['programs'] if p['source']=='mesh.frag' and not any(v in p['defines'] for v in ['AZURE_VIEW_FOG=1','AZURE_HAIR_PIXEL_INTEGRAL=1','AZURE_GEOMETRY_SAMPLES=1'])}
names=sorted({next(n for n in s['programFiles'] if n in eligible) for s in profile['shaders'].values() if any(n in eligible for n in s['programFiles'])});assert len(names)==10
rows=[]
for name in names:
    p=eligible[name];destination=folder/name
    command=[manifest['compiler'],*p['arguments'],*['-D'+v for v in p['defines']],'-I'+str(root/'shaders'),str(source),'-o',str(destination)]
    r=subprocess.run(command,capture_output=True,text=True,timeout=30);assert r.returncode==0,r.stdout+r.stderr
    r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe',str(destination)],capture_output=True,text=True,timeout=15);assert r.returncode==0,r.stdout+r.stderr
    counts={}
    for role,path in [('reference',root/'build/ninja-msvc-release/shaders'/name),('candidate',destination)]:
        r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-dis.exe',str(path)],capture_output=True,text=True,timeout=15);assert r.returncode==0
        counts[role]=dict(nonUniformDecorations=sum('OpDecorate' in line and 'NonUniform' in line for line in r.stdout.splitlines()),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    rows.append(dict(program=name,command=command,compilerExitCode=0,validationExitCode=0,counts=counts))
(out/'preflight-results.json').write_text(json.dumps(rows,indent=2));print(json.dumps([dict(program=r['program'],counts=r['counts']) for r in rows],indent=2))
