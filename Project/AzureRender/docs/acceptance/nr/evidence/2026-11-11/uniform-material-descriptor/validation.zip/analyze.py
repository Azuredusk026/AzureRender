from pathlib import Path
import json,sys
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
state=json.loads((out/'compare-state.json').read_text());assert state['status']=='compared'
assert len(state['programs'])==10 and len(state['comparisons'])==6
assert len(state['eventScopes']['materials'])==1006
assert state['allTargetsEqual'] and all(p['equal'] for p in state['comparisons'])
assert inputs(root)==json.loads((out/'source-lock.json').read_text())
assert all(digest(root/p)==h for p,h in json.loads((out/'protected-files.json').read_text()).items())
assert [v['mode'] for v in state['summary']]==['baseline','candidate','candidate','baseline']
scopes={}
for key in ['allEventMs','matchedEventMs','mainEventMs','ordinaryMainEventMs','snapshotEventMs']:
    a=[v[key] for v in state['summary'] if v['mode']=='baseline'];b=[v[key] for v in state['summary'] if v['mode']=='candidate']
    baseline=sum(a)/2;candidate=sum(b)/2;frame=sum(v['allEventMs'] for v in state['summary'] if v['mode']=='baseline')/2
    scopes[key]=dict(referenceMs=baseline,candidateMs=candidate,savedMs=baseline-candidate,reduction=(baseline-candidate)/baseline,share=baseline/frame,referenceDrift=abs(a[1]-a[0])/baseline)
qualified=any(v['share']>=.25 and v['reduction']>=.2 for k,v in scopes.items() if k!='allEventMs') or scopes['allEventMs']['savedMs']>=3
result=dict(status='local-qualified' if qualified else 'isolated-below-native-admission',candidate='draw-uniform-material-descriptors',sourceBase='efd7efd',allSixAttachmentsExact=True,materials=1006,totalEvents=len(state['timings'][0]['milliseconds']),scope=scopes,qualified=qualified,protectedFilesExact=13,sourceUnchanged=True,formalPerformanceAccepted=False)
(out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
