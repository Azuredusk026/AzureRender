from pathlib import Path
import json,re,shutil,sys
root=Path.cwd();out=Path(__file__).resolve().parent
old=root/'build/runs/20261110-235204-quad-cascade-demand-local-qualification-0b5052'
text=(old/'compare.py').read_text().replace(old.name,out.name)
start=text.index(' (private/\'selected_receiver.glsl\')')
end=text.index(' parameters={}\n',start)
text=text[:start]+''' original,n=re.subn(r'nonuniformEXT\((material\.textureBase \+ [0-8]u)\)',lambda m:'('+m.group(1)+')',original)
 assert n==9,n
'''+text[end:]
# Keep the production Vulkan/SPIR-V target: no additional shader feature needed.
start=text.index('  arguments=[');end=text.index('  built=subprocess.run',start)
text=text[:start]+"  command=[manifest['compiler'],*specification['arguments'],*['-D'+d for d in specification['defines']],'-I'+str(source),str(shader_source),'-o',str(out/filename)]\n"+text[end:]
text=text.replace("sourceBase='73300ab'","sourceBase='efd7efd'").replace("scope='Current 720p feature-enabled private replay; conservative quad-uniform current/next cascade demand; four original derivative expressions retained; curvature unconditional; view fields dynamic; both roles use replacement programs; native acceptance separate'","scope='Current 720p replay; material textureBase is draw-uniform push constant; omit nine explicit nonuniform decorations; all derivatives, receiver arithmetic and camera values unchanged; both roles replacement programs; native acceptance separate'")
(out/'compare.py').write_text(text)
runner=(old/'run_compare.py').read_text().replace("sourceBase='73300ab'","sourceBase='efd7efd'")
(out/'run_compare.py').write_text(runner)
shutil.copyfile(old/'replay-profile.json',out/'replay-profile.json')
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
source=inputs(root);(out/'source-lock.json').write_text(json.dumps(source,indent=2))
protected=json.loads((root/'build/runs/20261111-005441-reference-position-frame-main-integration-59835c/protected-files.json').read_text());assert all(digest(root/p)==h for p,h in protected.items())
(out/'protected-files.json').write_text(json.dumps(protected,indent=2))
(out/'task-card.json').write_text(json.dumps(dict(sourceBase='efd7efd',scope='Draw-uniform material descriptor indexing',hypothesis='Nine push-constant texture array indices can use dynamically uniform descriptor access; compare actual full material scope without changing sampled coordinates or shading arithmetic',deliverable='Local compiler, attachment and complete-event ABBA results',baseline='Current 859-program root shaders and frozen 73300ab capture',budget=dict(diagnosisMinutes=10,implementationMinutes=20,totalMinutes=30),gates=dict(attachments='all six byte-exact',nativeAdmission='hotspot >=25% processor frame and >=20% reduction, or >=3ms GPU / >=2ms CPU'),productionChanges=0),indent=2))
coord=Path('D:/Projects/FYP-coordination/assignments.json');v=json.loads(coord.read_text());v['integrationHead']='efd7efd';v['pendingQualityCommits']=[]
for name in ['ddc91d1','2148a98','585440f','7a7b98c','b699b6b','cb15bc1','efd7efd']:
    if name not in v['integrationCommits']:v['integrationCommits'].append(name)
for stream in v['streams']:
    if stream['id']=='performance':stream.update(state='reference-frame-main-qualified; uniform-material-descriptor-local-qualification',run=str(out))
    if stream['id']=='quality':stream['integratedSourceHead']='0f607b1'
coord.write_text(json.dumps(v,ensure_ascii=False,indent=2))
print('Prepared nine uniform push-constant descriptor indices')
