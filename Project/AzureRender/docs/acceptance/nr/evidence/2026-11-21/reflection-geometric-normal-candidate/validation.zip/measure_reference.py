import numpy as np
import cv2

def luma(rgb):
    return cv2.cvtColor(np.asarray(rgb, dtype=np.float32) / 255, cv2.COLOR_RGB2GRAY)

def contrast_structure(x, y, ax, ay, blur):
    return (2*(blur(x*y)-ax*ay)+.03**2) / (blur(x*x)-ax*ax+blur(y*y)-ay*ay+.03**2)

def measure(candidate, reference):
    rgb_diff = candidate.astype(np.int16) - reference.astype(np.int16)
    x, y = luma(candidate), luma(reference)
    blur = lambda image: cv2.GaussianBlur(image, (11, 11), 1.5)
    a, b = blur(x), blur(y)
    ssim = (2*a*b+.01**2)/(a*a+b*b+.01**2)*contrast_structure(x, y, a, b, blur)
    med_source, med_candidate = map(float, (np.median(y), np.median(x)))
    matched = np.minimum(x*(med_source/med_candidate), 1) if med_candidate > 0 else x
    matched_blur = blur(matched)
    matched_ssim = (2*matched_blur*b+.01**2)/(matched_blur**2+b*b+.01**2)*contrast_structure(
        matched, y, matched_blur, b, blur)
    return dict(pixels=int(x.size), ssim=float(ssim.mean()), medianReference=med_source,
                medianCandidate=med_candidate, medianLumaRelativeError=(abs(med_candidate-med_source)/med_source
                if med_source > 0 else None), meanAbsByte=float(np.abs(rgb_diff).mean()),
                diagnosticMedianMatchedLumaSsim=float(matched_ssim.mean()),
                medianSignedRgbBytes=np.median(rgb_diff, axis=(0, 1)).tolist(),
                exactPixels=int(np.all(rgb_diff == 0, axis=2).sum()), peak=int(np.abs(rgb_diff).max()))
