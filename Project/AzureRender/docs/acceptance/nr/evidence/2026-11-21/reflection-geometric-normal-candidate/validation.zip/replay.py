from hashlib import sha256
import json
import os
from pathlib import Path
import traceback
import zlib
import renderdoc as rd

ROOT = Path(os.environ['AZR_CANDIDATE_ROOT'])
REQ = json.loads((ROOT/'request.json').read_bytes())


def walk(rows):
    for row in rows:
        yield row
        yield from walk(row.children)


def execute():
    cap = rd.OpenCaptureFile()
    ctl = None
    result = {}
    try:
        assert cap.OpenFile(REQ['capture']['path'], '', None) == rd.ResultCode.Succeeded
        options = rd.ReplayOptions()
        options.forceGPUVendor = rd.GPUVendor.nVidia
        options.forceGPUDeviceID = 0x28e0
        status, ctl = cap.OpenCapture(options, None)
        assert status == rd.ResultCode.Succeeded and not ctl.GetAPIProperties().degraded
        textures = {str(t.resourceId):t for t in ctl.GetTextures()}
        end = list(walk(ctl.GetRootActions()))[-1].eventId
        ctl.SetFrameEvent(17241, True)
        pipe = ctl.GetPipelineState()
        stage = rd.ShaderStage.Fragment
        reflection = pipe.GetShaderReflection(stage)
        original = pipe.GetShader(stage)
        assert sha256(bytes(reflection.rawBytes)).hexdigest() == REQ['programs']['control']

        def sample():
            ctl.SetFrameEvent(21054, True)
            surface = bytes(ctl.GetTextureData(textures['ResourceId::9847'].resourceId, rd.Subresource()))
            ctl.SetFrameEvent(end, True)
            display = textures['ResourceId::154']
            raw = bytes(ctl.GetTextureData(display.resourceId, rd.Subresource()))
            order = (2,1,0) if display.format.Name().startswith('B8G8') else (0,1,2)
            rgb = bytearray(2560*1440*3)
            for i, channel in enumerate(order):
                rgb[i::3] = raw[channel::4]
            return surface, bytes(rgb)

        control, baseline = sample()
        assert sha256(baseline).hexdigest() == REQ['originalDisplayRgbSha256']
        binary = (ROOT/'candidate.spv').read_bytes()
        assert sha256(binary).hexdigest() == REQ['programs']['candidate']
        target, error = ctl.BuildTargetShader(reflection.entryPoint, rd.ShaderEncoding.SPIRV, binary, rd.ShaderCompileFlags(), stage)
        assert target != rd.ResourceId.Null(), error
        try:
            ctl.ReplaceResource(original, target)
            changed, candidate = sample()
            for component in (0,1,2,3,12,13,14,15):
                assert changed[component::16] == control[component::16]
            assert changed != control
            for name, raw in [('candidateDisplay', candidate), ('controlDisplay', baseline)]:
                encoded = zlib.compress(raw, 6)
                (ROOT/(name+'.zlib')).write_bytes(encoded)
                result[name] = dict(sha256=sha256(raw).hexdigest(), encodedSha256=sha256(encoded).hexdigest())
            result['surface'] = dict(controlSha256=sha256(control).hexdigest(), candidateSha256=sha256(changed).hexdigest(),
                changedBytes=sum(a!=b for a,b in zip(control,changed)), depthAndRoughnessExact=True)
            (ROOT/'candidate-checkpoint.json').write_text(json.dumps(result, indent=2)+'\n')
        finally:
            ctl.RemoveReplacement(original)
            ctl.FreeTargetResource(target)
        assert sample() == (control, baseline)
        result.update(restored=True, status='verified')
        (ROOT/'replay.json').write_text(json.dumps(result, indent=2)+'\n')
    finally:
        if ctl is not None:
            ctl.Shutdown()
        cap.Shutdown()


try:
    execute()
except Exception:
    (ROOT/'failure.txt').write_text(traceback.format_exc())
    os._exit(1)
os._exit(0)
