from hashlib import sha256
import json
from pathlib import Path
import sys
import zlib

import numpy as np
from PIL import Image
from measure_reference import measure

ROOT = Path(__file__).resolve().parent
REQ = json.loads((ROOT/'request.json').read_bytes())


def gather():
    replay = json.loads((ROOT/'replay.json').read_bytes())
    assert replay['restored'] and replay['surface']['depthAndRoughnessExact']
    displays = []
    for name in ('controlDisplay', 'candidateDisplay'):
        encoded = (ROOT/(name+'.zlib')).read_bytes()
        assert sha256(encoded).hexdigest() == replay[name]['encodedSha256']
        raw = zlib.decompress(encoded)
        assert sha256(raw).hexdigest() == replay[name]['sha256']
        displays.append(np.frombuffer(raw, 'u1').reshape(1440, 2560, 3))
    control, candidate = displays
    assert sha256(control.tobytes()).hexdigest() == REQ['originalDisplayRgbSha256']
    reference_path = Path(REQ['reference'])
    assert sha256(reference_path.read_bytes()).hexdigest() == REQ['referenceSha256']
    with Image.open(reference_path) as image:
        reference = np.asarray(image.convert('RGB'))
    y, x = np.where(np.any(control != candidate, axis=-1))
    arrays = dict(x=x.astype('u2'), y=y.astype('u2'), control=control[y,x],
                  referenceDelta=reference[y,x]-control[y,x], candidateDelta=candidate[y,x]-control[y,x])
    for name in ('centerFloor', 'cyanRing'):
        left, top, right, bottom = REQ['rectangles'][name]
        for label, image in (('reference', reference), ('control', control), ('candidate', candidate)):
            arrays[name+'_'+label] = image[top:bottom, left:right]
    np.savez_compressed(ROOT/'hall.npz', **arrays)


def evaluate():
    results = {}
    with np.load(ROOT/'hall.npz', allow_pickle=False) as arrays:
        x, y = arrays['x'], arrays['y']
        assert len(set(zip(x, y))) == len(x)
        candidate = arrays['control'] + arrays['candidateDelta']
        reference = arrays['control'] + arrays['referenceDelta']
        assert np.all(np.any(arrays['control'] != candidate, axis=-1))
        within = np.abs(reference.astype('i2')-arrays['control']).max(axis=-1) <= 1
        over = np.abs(reference.astype('i2')-candidate).max(axis=-1) > 1
        for name, (left, top, right, bottom) in REQ['rectangles'].items():
            region = (x >= left) & (x < right) & (y >= top) & (y < bottom)
            row = dict(changedPixels=int(region.sum()), newOverOne=int((region & within & over).sum()))
            if name in ('centerFloor', 'cyanRing'):
                for label in ('control', 'candidate'):
                    metrics = measure(arrays[name+'_'+label], arrays[name+'_reference'])
                    row[label] = {key:metrics[key] for key in ('ssim', 'medianLumaRelativeError')}
            results[name] = row
    gates = REQ['gates']
    passed = all(results[name]['candidate']['ssim'] >= gates['ssim']
                 and results[name]['candidate']['medianLumaRelativeError'] <= gates['lumaRelative']
                 for name in ('centerFloor', 'cyanRing'))
    passed = passed and all(row['newOverOne'] <= gates['newOverOne'] for row in results.values())
    return dict(regions=results, hallOneFramePassed=passed)


if __name__ == '__main__':
    record = '--record' in sys.argv
    if record:
        gather()
    results = evaluate()
    if record:
        (ROOT/'results.json').write_text(json.dumps(results, indent=2)+'\n')
    else:
        assert results == json.loads((ROOT/'results.json').read_bytes())
    print(json.dumps(results, indent=2))
    print('PASS: frozen region and neighbor image gates recomputed')
