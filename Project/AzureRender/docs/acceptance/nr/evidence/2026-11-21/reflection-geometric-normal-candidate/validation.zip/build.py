from hashlib import sha256
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
request = json.loads((ROOT/'programs.json').read_bytes())
source = (ROOT/'frozen-source/mesh.frag').read_bytes()
assert source.count(b'vec3 snapshotNormal=shadedNormal;') == 1
compiler = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe')
validator = compiler.with_name('spirv-val.exe')
for label in ('control', 'candidate'):
    code = source if label == 'control' else source.replace(
        b'vec3 snapshotNormal=shadedNormal;', b'vec3 snapshotNormal=geometricNormal;')
    path = ROOT/(label+'.frag')
    assert path.read_bytes() == code
    subprocess.run([str(compiler), *['-D'+flag for flag in request['defines']],
        '-I', str(ROOT/'frozen-source'), str(path), '-o', str(ROOT/(label+'.spv'))],
        check=True, timeout=60)
    binary = ROOT/(label+'.spv')
    assert sha256(binary.read_bytes()).hexdigest() == request['programs'][label]
    subprocess.run([str(validator), '--target-env', 'vulkan1.1', str(binary)], check=True, timeout=30)
print('PASS: frozen control, single-factor source patch and validated SPIR-V reproduced')
