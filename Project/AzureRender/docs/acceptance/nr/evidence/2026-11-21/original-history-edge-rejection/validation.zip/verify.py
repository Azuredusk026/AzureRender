import hashlib,json,zlib,sys
from pathlib import Path
import numpy as np
from test_screen_space_reflections_gpu import RIGHT,oracle,polygon_mask
R=Path(__file__).resolve().parent
D=json.loads((R/'input.json').read_bytes())
def read(name,dtype,c):
 m=D['attachments'][name];b=zlib.decompress((R/m['file']).read_bytes());assert hashlib.sha256(b).hexdigest()==m['sha256']
 w,h=m.get('extent',[m.get('width'),m.get('height')]);return np.frombuffer(b,dtype).reshape(h,w,c)
def world(uv,z,m):
 p=np.array([*(2*np.asarray(uv)-1),z,1.])@m;return p[:3]/p[3]
def main():
 hit=read('hitUv','<u2',2)/65535;prior=read('historyUv','<u2',2)/65535;conf=read('confidence','u1',1)[...,0]
 mask=polygon_mask(oracle(RIGHT)['reflectionPolygon'],.65)[1::2,1::2];hits=mask&hit.any(axis=2);bad=hits&(conf==0)
 assert hits.sum()==87 and np.count_nonzero(conf[mask])==86 and bad.sum()==1
 y,x=np.argwhere(bad)[0];assert [int(x),int(y)]==[97,78]
 uv=prior[y,x];motion=read('motionInput','<f4',4);px,py=np.floor(hit[y,x]*[320,240]).astype(int);v=motion[py,px]
 assert v[3]==1 and np.isfinite(v).all()
 hx,hy=np.floor(uv*[160,120]).astype(int);z=read('previousDepth','<f4',1)[hy,hx,0];expected=1-float(v[2])
 mat=np.frombuffer(bytes.fromhex(D['constants']['hex']),'<f4').reshape(30,4).astype(float)[18:22]
 p=world(uv,expected,mat);actual=world(uv,z,mat);error=float(np.linalg.norm(actual-p))
 span=max(np.linalg.norm(world(uv+[1/160,0],expected,mat)-p),np.linalg.norm(world(uv+[0,1/120],expected,mat)-p))
 assert error>span
 # Quantized probe UVs must identify a unique point-sampled depth cell.
 eps=.5/65535;assert np.array_equal(np.floor((uv-eps)*[160,120]),np.floor((uv+eps)*[160,120]))
 rgb=read('previousColor','<f2',4);cx,cy=np.floor(uv*[320,240]).astype(int);source=[2*hx+1,2*hy+1]
 accepted=mask&(conf>0);coords=np.floor(prior[accepted]*[320,240]).astype(int);acceptedColors=rgb[coords[:,1],coords[:,0],:3].astype(float)
 assert np.all(acceptedColors[:,0]>.7)
 color=rgb[cy,cx,:3].astype(float);assert color[0]<.02
 depthSourceColor=rgb[source[1],source[0],:3].astype(float)
 result=dict(rayPixel=[int(x),int(y)],geometryHits=87,acceptedRays=86,rejectedHits=1,acceptedHistoryRedRange=[float(acceptedColors[:,0].min()),float(acceptedColors[:,0].max())],hitUv=hit[y,x].tolist(),historyUv=uv.tolist(),motion=v.tolist(),colorSourcePixel=[int(cx),int(cy)],depthSourcePixel=[int(t) for t in source],historyDepthPixel=[int(hx),int(hy)],expectedPreviousDepth=expected,actualPreviousDepth=float(z),historyWorldErrorM=error,oneTracePixelSpanM=float(span),historyColor=color.tolist(),depthSourceColor=depthSourceColor.tolist(),depthRejectVerified=True,pointCellUnambiguous=True)
 if '--record' in sys.argv:(R/'results.json').write_text(json.dumps(result,indent=2)+'\n')
 else:assert result==json.loads((R/'results.json').read_bytes())
 print(json.dumps(result,indent=2));print('PASS: unique rejected hit exceeds existing history-depth tolerance')
if __name__=='__main__':main()
