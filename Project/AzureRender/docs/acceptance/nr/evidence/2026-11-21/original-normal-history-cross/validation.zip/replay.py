import renderdoc as rd
import json, os, traceback, hashlib, zlib, struct
from pathlib import Path
R=Path(os.environ['AZR_CANDIDATE_ROOT'])
S=R.parent/'20261120-001407-nr-reflection-switch-transition-6707ab'
req=json.loads((S/'capture-receipt.json').read_bytes())['artifacts'][0]
prior=json.loads((S/'replay.json').read_bytes())
programs=json.loads((R/'programs.json').read_bytes())['programs']
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(n,v):(R/n).write_text(json.dumps(v,indent=2)+'\n')
cap=rd.OpenCaptureFile();ctl=None
try:
 assert sha(Path(req['path']).read_bytes())==req['sha256']
 assert cap.OpenFile(req['path'],'',None)==rd.ResultCode.Succeeded
 opts=rd.ReplayOptions();opts.forceGPUVendor=rd.GPUVendor.nVidia;opts.forceGPUDeviceID=0x28e0
 status,ctl=cap.OpenCapture(opts,None);assert status==rd.ResultCode.Succeeded
 textures={str(t.resourceId):t for t in ctl.GetTextures()}
 bindings=[]
 for event in (209,214,219):
  ctl.SetFrameEvent(event,True);pipe=ctl.GetPipelineState();ref=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
  assert sha(bytes(ref.rawBytes))==programs['control']
  push=bytes(ctl.GetVulkanPipelineState().pushconsts);base=struct.unpack_from('<I',push,136)[0]
  for use in pipe.GetReadOnlyResources(rd.ShaderStage.Fragment):
   decl=ref.readOnlyResources[use.access.index]
   if decl.name=='textureArray' and use.access.arrayElement==base+1:
    t=textures[str(use.descriptor.resource)];raw=bytes(ctl.GetTextureData(t.resourceId,rd.Subresource()))
    bindings.append(dict(event=event,base=base,push=push.hex(),resource=str(t.resourceId),format=t.format.Name(),width=t.width,height=t.height,raw=raw.hex(),sha256=sha(raw)))
 assert len(bindings)==3
 ctl.SetFrameEvent(209,True);pipe=ctl.GetPipelineState();ref=pipe.GetShaderReflection(rd.ShaderStage.Fragment);original=pipe.GetShader(rd.ShaderStage.Fragment)
 ctl.SetFrameEvent(270,True);rp=ctl.GetPipelineState();rr=rp.GetShaderReflection(rd.ShaderStage.Compute);ro=rp.GetShader(rd.ShaderStage.Compute)
 probeTargets={}
 def sample(label):
  out={}
  for key,event,rid in [('surface',269,'ResourceId::610'),('normalRoughness',270,prior['attachments']['normalRoughness']['resource']),('outputColor',270,prior['attachments']['outputColor']['resource']),('outputConfidence',270,prior['attachments']['outputConfidence']['resource']),('outputFootprint',270,prior['attachments']['outputFootprint']['resource']),('filtered',331,prior['attachments']['filtered']['resource']),('display',411,'ResourceId::156')]:
   ctl.SetFrameEvent(event,True);t=textures[rid];data=bytes(ctl.GetTextureData(t.resourceId,rd.Subresource()));f=label+'-'+key+'.zlib';(R/f).write_bytes(zlib.compress(data))
   out[key]=dict(file=f,sha256=sha(data),width=t.width,height=t.height,format=t.format.Name(),bytes=len(data),resource=rid,event=event)
  for key,target in probeTargets.items():
   try:
    ctl.ReplaceResource(ro,target);ctl.SetFrameEvent(270,True);t=textures[prior['attachments']['outputFootprint']['resource']];data=bytes(ctl.GetTextureData(t.resourceId,rd.Subresource()));f=label+'-'+key+'.zlib';(R/f).write_bytes(zlib.compress(data));out[key]=dict(file=f,sha256=sha(data),width=t.width,height=t.height,format=t.format.Name(),bytes=len(data),resource=str(t.resourceId),event=270)
    for unchanged in ('outputColor','outputConfidence'):
     assert sha(bytes(ctl.GetTextureData(textures[out[unchanged]['resource']].resourceId,rd.Subresource())))==out[unchanged]['sha256']
   finally:ctl.RemoveReplacement(ro)
  return out
 baseline=sample('baseline')
 results={}
 history=R.parent/'20261120-002443-nr-tracked-reflection-candidate-4b0cb9'
 hreq=json.loads((history/'request.json').read_bytes())
 historyPrograms={}
 for name in ('candidate','wrongDepth'):
  binary=(history/(name+'.spv')).read_bytes();assert sha(binary)==hreq['programs'][name]
  target,error=ctl.BuildTargetShader(rr.entryPoint,rd.ShaderEncoding.SPIRV,binary,rd.ShaderCompileFlags(),rd.ShaderStage.Compute);assert target!=rd.ResourceId.Null(),error
  historyPrograms[name]=target
 for normal in ('control','geometric','tilted'):
  nt=None
  if normal!='control':
   binary=(R/(normal+'.spv')).read_bytes();assert sha(binary)==programs[normal]
   nt,error=ctl.BuildTargetShader(ref.entryPoint,rd.ShaderEncoding.SPIRV,binary,rd.ShaderCompileFlags(),rd.ShaderStage.Fragment);assert nt!=rd.ResourceId.Null(),error
   ctl.ReplaceResource(original,nt)
  try:
   for hist,ht in historyPrograms.items():
    try:
     ctl.ReplaceResource(ro,ht);results[normal+'-'+hist]=sample(normal+'-'+hist)
    finally:ctl.RemoveReplacement(ro)
  finally:
   if nt:ctl.RemoveReplacement(original);ctl.FreeTargetResource(nt)
 restored=sample('restored')
 assert all(restored[k]['sha256']==baseline[k]['sha256'] for k in baseline)
 for t in historyPrograms.values():ctl.FreeTargetResource(t)
 write('cross-readback.json',dict(capture=req,programs=programs,historyPrograms=hreq['programs'],results=results,baseline=baseline,restored=True))
except Exception:
 (R/'failure.txt').write_text(traceback.format_exc());os._exit(1)
finally:
 if ctl:ctl.Shutdown()
 cap.Shutdown()
os._exit(0)
