from pathlib import Path
import hashlib,json,zlib,sys
import numpy as np
from test_screen_space_reflections_gpu import RIGHT,oracle,polygon_mask
R=Path(__file__).resolve().parent
D=json.loads((R/'cross-readback.json').read_bytes())
N=json.loads((R/'normal-readback.json').read_bytes())
def load(label,key,dtype,c):
 m=D['results'][label][key];b=zlib.decompress((R/m['file']).read_bytes())
 assert hashlib.sha256(b).hexdigest()==m['sha256'] and len(b)==m['bytes']
 return np.frombuffer(b,dtype).reshape(m['height'],m['width'],c)
def main():
 assert D['restored'] and D['capture']==N['capture'] and D['programs']==N['programs']
 mask=polygon_mask(oracle(RIGHT)['reflectionPolygon'],.65);half=mask[1::2,1::2];rows={}
 for normal,expected in [('control',97),('geometric',97),('tilted',86)]:
  label=normal+'-candidate';bad=normal+'-wrongDepth'
  for key,m in D['results'][bad].items():assert m['sha256']==N['results'][normal][key]['sha256'],(normal,key)
  for key in ('surface','normalRoughness','outputColor','outputFootprint'):
   assert D['results'][label][key]['sha256']==D['results'][bad][key]['sha256'],(label,key)
  conf=load(label,'outputConfidence','u1',1)[...,0];f=load(label,'filtered','<f4',4)[...,3]
  a=load(label,'display','u1',4)[...,[2,1,0]].astype(float)/255;b=load(bad,'display','u1',4)[...,[2,1,0]].astype(float)/255
  linear=lambda x:np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)
  signal=float(np.mean((linear(a)-linear(b))[mask,0]))
  assert np.count_nonzero(conf[half])==np.count_nonzero(f[half])==expected
  assert signal>.003
  rows[normal]=dict(rightPixels=int(half.sum()),acceptedRays=int(np.count_nonzero(conf[half])),filteredPixels=int(np.count_nonzero(f[half])),linearRedSignal=signal,wrongDepthMatchesOriginal=True,rayColorAndGeometryExact=True)
 for label,items in D['results'].items():
  for key,m in items.items():load(label,key,'u1',m['bytes']//(m['width']*m['height']))
 if '--record' in sys.argv:(R/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 else:assert rows==json.loads((R/'results.json').read_bytes())
 print(json.dumps(rows,indent=2));print('PASS: six paths, normal-independent motion recovery and wrong-depth rejection')
if __name__=='__main__':main()
