import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
lease = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lease['state'] == 'held' and Path(lease['output']).resolve() == root
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
with (root/'producer.log').open('wb') as output:
    subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe', '--python', str(root/'producer_worker.py')],
        cwd=root, env=dict(os.environ, AZR_PRODUCER_ROOT=str(root)), startupinfo=startup,
        stdout=output, stderr=subprocess.STDOUT, check=True, timeout=110)
