"""Verify normal provenance and compare one-factor sampling and precision controls."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import zlib

import numpy as np

ROOT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:sha256(b).hexdigest()


def load(record,dtype,channels=None):
    enc=(ROOT/record['file']).read_bytes()
    raw=zlib.decompress(enc)
    assert sha(enc)==record['encodedSha256'] and sha(raw)==record['sha256']
    w,h=record['dimensions']
    return np.frombuffer(raw,dtype).reshape((h,w,channels) if channels else (h,w))


def oct_to_vector(encoded, axis):
    uv=encoded.astype('f8')*2-1
    pole=1-np.sum(abs(uv),axis=-1,keepdims=True)
    folded=(1-abs(uv[...,::-1]))*np.where(uv>=0,1.,-1.)
    uv=np.where(pole<0,folded,uv)
    v=np.concatenate((uv,pole),axis=-1)
    if axis=='y':v=v[...,[0,2,1]]
    return v/np.linalg.norm(v,axis=-1,keepdims=True)


def to_oct(vec, axis):
    n=vec/np.abs(vec).sum(axis=-1,keepdims=True)
    if axis=='y':n=n[...,[0,2,1]]
    xy=n[...,:2]
    fold=(1-abs(xy[...,::-1]))*np.where(xy>=0,1.,-1.)
    return (np.where(n[...,2,None]<0,fold,xy)+1)*.5


def samples(a, x, y):
    return a[y::2,x::2]


def unpack10(buf):
    return np.stack(((buf&1023),((buf>>10)&1023)),axis=-1)


def angles(a,b):
    return np.degrees(np.arctan2(np.linalg.norm(np.cross(a,b),axis=-1),
                                 np.sum(a*b,axis=-1)))


def pp(x):
    return [float(v) for v in np.percentile(x,[50,90,99])]


def pairmask():
    old=ROOT.parent/'20261120-010938-nr-reflection-step-sensitivity-29dbba'
    q=read(old/'inputs.json')
    with np.load(old/'inputs.npz',allow_pickle=False) as a:
        for label in ('native','player'):
            for k in ('confidence','currentDepth'):
                assert sha(a[label+'_'+k].tobytes())==q['source'][label]['control'][k]['sha256']
        c0,c1=np.float32(9.999899864196777),np.float32(9.999999747378752e-05)
        d0,d1=a['constants'][24,2:]
        diff=abs(1/(a['native_currentDepth']*c0+c1)-1/(a['player_currentDepth']*d0+d1))
        keep=(diff<=.02)&(a['native_confidence']>0)&(a['player_confidence']>0)
        assert keep.shape==(225,295)
    return keep


def evaluate():
    req=read(ROOT/'request.json')
    d=read(ROOT/'direct.json')
    for label,r in d.items():
        prev=req['jobs'][label]
        for k in ('frame','captureSha256','prepareEvent','rayEvent'):
            assert r[k]==prev[k]
        assert r['prepared']['fullSha256']==prev['rayNormal']['fullSha256']
    n=d['native'];p=d['player']
    assert n['early']['primary']['fullSha256']==n['early']['secondary']['fullSha256']
    src_native=unpack10(load(n['early']['primary'],'<u4'))/1023
    prep_native_units=unpack10(load(n['prepared'],'<u4'))
    prep_native=prep_native_units/1023
    src_player=load(p['early']['primary'],'<f4',4)
    prep_player=load(p['prepared'],'<f4',4)[...,:2]
    eligible=np.load(ROOT/'pairmask.npy',allow_pickle=False)
    assert eligible.shape==prep_native.shape[:2]
    mirror=np.array([-1,1,1])
    wc=oct_to_vector(prep_native,'y')*mirror
    pc=oct_to_vector(prep_player,'y')
    stats={}
    for name,(x,y,r,b) in {'centerFloor':[505,495,775,585],'cyanRing':[520,530,635,590]}.items():
        cut=np.zeros(eligible.shape,bool)
        cut[y-478:b-478,x-498:r-498]=True
        mask=eligible&cut
        details=dict(points=int(mask.sum()),observedNormalDegrees=pp(angles(wc,pc)[mask]),nativeReencode={},playerNormalControls={})
        assert len(pc[mask])>5000
        for iy in (0,1):
            for ix in (0,1):
                key='x{}y{}'.format(ix,iy)
                ntap=samples(src_native,ix,iy)
                ndec=oct_to_vector(ntap,'y')
                nout=np.rint(to_oct(ndec,'y')*1023)
                native_delta=nout-prep_native_units
                details['nativeReencode'][key]=dict(exactTwo=int(np.count_nonzero(np.all(native_delta==0,axis=-1)&mask)),
                    withinOneUnit=int(np.count_nonzero(np.all(abs(native_delta)<=1,axis=-1)&mask)))
                ptap=samples(src_player,ix,iy)[...,1:3]
                pdec=oct_to_vector(ptap,'z')
                pprepared=to_oct(pdec,'y')
                if (ix,iy)==(1,1):
                    np.testing.assert_allclose(pprepared[mask],prep_player[mask],atol=2e-7,rtol=0)
                encoded_in_native=to_oct(pdec*mirror,'y')
                round_trip=oct_to_vector(np.rint(encoded_in_native*1023)/1023,'y')
                round_trip_native=np.rint(to_oct(round_trip,'y')*1023)/1023
                source_angle=angles(oct_to_vector(samples(src_native,0,1),'y')*mirror,pdec)
                details['playerNormalControls'][key]=dict(floatDegrees=pp(angles(pdec,wc)[mask]),
                     nativeEncodingRoundTripDegrees=pp(angles(oct_to_vector(round_trip_native,'y')*mirror,wc)[mask]),
                     fullSourceAngleDegrees=pp(source_angle[mask]))
        stats[name]=details
    return stats


if __name__=='__main__':
    record=len(sys.argv)==2 and sys.argv[1]=='--record'
    if record:np.save(ROOT/'pairmask.npy',pairmask())
    info=evaluate()
    if record:(ROOT/'results.json').write_text(json.dumps(info,indent=2)+'\n')
    else:assert info==read(ROOT/'results.json')
    print(json.dumps(info,indent=2))
    print('PASS: source taps, normal conversion and precision controls')

