"""Test whether frozen normal discrepancies lie within their storage cells."""
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'input'))
import normal_score as source


def evaluate():
    records = source.read(source.ROOT / 'direct.json')
    native = source.unpack10(source.load(records['native']['prepared'], '<u4'))
    player = source.load(records['player']['early']['primary'], '<f4', 4)
    eligible = np.load(source.ROOT / 'pairmask.npy', allow_pickle=False)
    native_vectors = source.oct_to_vector(native / 1023, 'y') * [-1, 1, 1]
    result = {}
    for name, bounds in {'centerFloor': [505, 495, 775, 585],
                         'cyanRing': [520, 530, 635, 590]}.items():
        x, y, right, bottom = bounds
        region = np.zeros(eligible.shape, dtype=bool)
        region[y-478:bottom-478, x-498:right-498] = True
        mask = eligible & region
        codes = native[mask].astype(float)
        controls = {}
        distances = []
        for iy in (0, 1):
            for ix in (0, 1):
                vectors = source.oct_to_vector(source.samples(player, ix, iy)[..., 1:3], 'z')[mask]
                encoded = source.to_oct(vectors * [-1, 1, 1], 'y') * 1023
                residual = encoded - codes
                distance = np.max(abs(residual), axis=-1)
                distances.append(distance)
                controls[f'x{ix}y{iy}'] = {
                    'nearestCellContains': int(np.count_nonzero(distance <= .5 + 1e-5)),
                    'oneUnitContains': int(np.count_nonzero(distance <= 1 + 1e-5)),
                    'distanceUnits': source.pp(distance),
                    'signedUnitsMedian': np.median(residual, axis=0).tolist(),
                }
        best = np.min(distances, axis=0)
        result[name] = {'count': int(mask.sum()), 'controls': controls,
                        'anyTapNearestCellContains': int(np.count_nonzero(best <= .5 + 1e-5)),
                        'anyTapOneUnitContains': int(np.count_nonzero(best <= 1 + 1e-5)),
                        'bestTapDistanceUnits': source.pp(best)}
        values, counts = np.unique(native[mask], axis=0, return_counts=True)
        top = np.argsort(counts)[-5:][::-1]
        result[name]['dominantNativeCodes'] = [
            {'code': values[i].tolist(), 'count': int(counts[i])} for i in top]
    return result


def verify_producer():
    import struct
    import zlib
    records = json.loads((ROOT/'producer.json').read_bytes())
    binding = json.loads((ROOT/'bound-normal.json').read_bytes())
    assert len(records['rows']) == 2
    direct = source.read(source.ROOT/'direct.json')['player']
    array = source.load(direct['early']['primary'], '<f4', 4)
    for row in records['rows']:
        x, y = row['pixel']
        assert row['event'] == binding['event'] == 17241
        assert row['before'] != row['after']
        assert array[y-956, x-996].tobytes().hex() == row['after']
    assert records['captureSha256'] == binding['captureSha256'] == direct['captureSha256']
    assert struct.unpack_from('<I', bytes.fromhex(binding['pushConstants']), 136)[0] == binding['textureBase']
    normal = binding['normal']
    assert normal['slot'] == binding['textureBase'] + 1
    encoded = (ROOT/normal['file']).read_bytes()
    raw = zlib.decompress(encoded)
    assert sha256(encoded).hexdigest() == normal['encodedSha256']
    assert sha256(raw).hexdigest() == normal['sha256']
    pixels = np.frombuffer(raw, 'u1').reshape(-1, 4)
    count = int(np.count_nonzero(np.all(pixels == [128, 128, 255, 255], axis=1)))
    assert count == 956901 and len(pixels) == 1048576
    print('PASS: two receiver draws, push-constant normal slot and bound texture bytes')


if __name__ == '__main__':
    values = evaluate()
    path = ROOT / 'results.json'
    if '--record' in sys.argv:
        path.write_text(json.dumps(values, indent=2) + '\n', encoding='utf-8')
    else:
        assert values == json.loads(path.read_bytes())
    verify_producer()
    print(json.dumps(values, indent=2))
    print('PASS: four source taps against nearest and conservative one-unit storage cells')
