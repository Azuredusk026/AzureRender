import json
import os
from pathlib import Path
import struct
from hashlib import sha256
import traceback
import zlib
import renderdoc as rd

ROOT = Path(os.environ['AZR_PRODUCER_ROOT'])
cap = rd.OpenCaptureFile()
ctl = None
try:
    request = json.loads((ROOT/'input/request.json').read_bytes())['jobs']['player']
    assert cap.OpenFile(request['capture'], '', None) == rd.ResultCode.Succeeded
    options = rd.ReplayOptions()
    options.forceGPUVendor = rd.GPUVendor.nVidia
    options.forceGPUDeviceID = 0x28e0
    status, ctl = cap.OpenCapture(options, None)
    assert status == rd.ResultCode.Succeeded and not ctl.GetAPIProperties().degraded
    ctl.SetFrameEvent(17241, True)
    push = bytes(ctl.GetVulkanPipelineState().pushconsts)
    base = struct.unpack_from('<I', push, 136)[0]
    pipe = ctl.GetPipelineState()
    reflection = pipe.GetShaderReflection(rd.ShaderStage.Fragment)
    assert sha256(bytes(reflection.rawBytes)).hexdigest() == 'e99e2258c6a04aaa479024336460ede13b8a45f3b8a592c85e8fbe8905495cd6'
    textures = {t.resourceId: t for t in ctl.GetTextures()}
    matches = []
    for item in pipe.GetReadOnlyResources(rd.ShaderStage.Fragment):
        desc = reflection.readOnlyResources[item.access.index]
        if desc.name != 'textureArray' or item.access.arrayElement != base+1:
            continue
        texture = textures[item.descriptor.resource]
        data = bytes(ctl.GetTextureData(texture.resourceId, rd.Subresource()))
        encoded = zlib.compress(data, 6)
        (ROOT/'bound-normal.zlib').write_bytes(encoded)
        matches.append(dict(resource=str(texture.resourceId), width=texture.width, height=texture.height,
            format=texture.format.Name(), slot=base+1, file='bound-normal.zlib', sha256=sha256(data).hexdigest(),
            encodedSha256=sha256(encoded).hexdigest(), bytes=len(data)))
    assert len(matches) == 1
    result = dict(event=17241, captureSha256=request['captureSha256'], textureBase=base,
                  pushConstants=push.hex(), normal=matches[0])
    (ROOT/'bound-normal.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
except Exception:
    (ROOT/'binding-failure.txt').write_text(traceback.format_exc())
    os._exit(1)
finally:
    if ctl is not None:
        ctl.Shutdown()
    cap.Shutdown()
os._exit(0)
