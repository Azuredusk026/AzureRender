import json
import os
from pathlib import Path
import struct
from hashlib import sha256
import traceback
import renderdoc as rd

ROOT = Path(os.environ['AZR_PRODUCER_ROOT'])


def actions(rows):
    for row in rows:
        yield row
        yield from actions(row.children)


def run():
    request = json.loads((ROOT/'input/request.json').read_bytes())['jobs']['player']
    witness = json.loads((ROOT/'input/direct.json').read_bytes())['player']['early']['primary']
    cap = rd.OpenCaptureFile()
    ctl = None
    result = dict(frame=request['frame'], captureSha256=request['captureSha256'], rows=[])
    try:
        assert cap.OpenFile(request['capture'], '', None) == rd.ResultCode.Succeeded
        options = rd.ReplayOptions()
        options.forceGPUVendor = rd.GPUVendor.nVidia
        options.forceGPUDeviceID = 0x28e0
        status, ctl = cap.OpenCapture(options, None)
        assert status == rd.ResultCode.Succeeded and not ctl.GetAPIProperties().degraded
        textures = {str(t.resourceId): t for t in ctl.GetTextures()}
        events = {a.eventId: a for a in actions(ctl.GetRootActions())}
        texture = textures[witness['resource']]
        observer = request['prepareEvent']-1
        ctl.SetFrameEvent(observer, True)
        raw = bytes(ctl.GetTextureData(texture.resourceId, rd.Subresource()))
        assert sha256(raw).hexdigest() == witness['fullSha256']
        for x, y in ((1201, 1021), (1101, 1121)):
            offset = (y*texture.width+x)*16
            expected = raw[offset:offset+16]
            ctl.SetFrameEvent(observer, True)
            history = ctl.PixelHistory(texture.resourceId, x, y, rd.Subresource(), rd.CompType.Typeless)
            for aid in sorted({h.eventId for h in history if h.eventId < observer and h.Passed()}, reverse=True):
                action = events.get(aid)
                if action is None or not (action.flags & rd.ActionFlags.Drawcall):
                    continue
                ctl.SetFrameEvent(aid, True)
                after = bytes(ctl.GetTextureData(texture.resourceId, rd.Subresource()))[offset:offset+16]
                if after != expected:
                    continue
                ctl.SetFrameEvent(aid-1, True)
                before = bytes(ctl.GetTextureData(texture.resourceId, rd.Subresource()))[offset:offset+16]
                if before == after:
                    continue
                ctl.SetFrameEvent(aid, True)
                pipe = ctl.GetPipelineState()
                reflection = pipe.GetShaderReflection(rd.ShaderStage.Fragment)
                bindings = []
                for binding in pipe.GetReadOnlyResources(rd.ShaderStage.Fragment):
                    rid = str(binding.descriptor.resource)
                    if rid not in textures:
                        continue
                    desc = reflection.readOnlyResources[binding.access.index]
                    tex = textures[rid]
                    row = dict(resource=rid, name=desc.name, width=tex.width, height=tex.height,
                        arrayElement=binding.access.arrayElement, format=tex.format.Name())
                    if 'normal' in desc.name.lower() or max(tex.width, tex.height) <= 2:
                        data = bytes(ctl.GetTextureData(tex.resourceId, rd.Subresource()))
                        row.update(sha256=sha256(data).hexdigest(), firstBytes=data[:64].hex())
                    bindings.append(row)
                result['rows'].append(dict(pixel=[x,y], event=aid, indexResource=str(pipe.GetIBuffer().resourceId),
                    instance=action.instanceOffset, before=before.hex(), after=after.hex(),
                    surface=struct.unpack('<4f', after), textureBindings=bindings,
                    pixelProgram=sha256(bytes(reflection.rawBytes)).hexdigest()))
                break
            assert len(result['rows']) > 0
        (ROOT/'producer.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    finally:
        if ctl is not None:
            ctl.Shutdown()
        cap.Shutdown()


try:
    run()
except Exception:
    (ROOT/'producer-failure.txt').write_text(traceback.format_exc())
    os._exit(1)
os._exit(0)
