import hashlib,json,zlib,sys
from pathlib import Path
import numpy as np
from test_screen_space_reflections_gpu import LEFT,RIGHT,oracle,polygon_mask,CAMERA
R=Path(__file__).resolve().parent
D=json.loads((R/'normal-readback.json').read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(label,key,dtype,channels):
 m=D['results'][label][key];b=zlib.decompress((R/m['file']).read_bytes())
 assert sha(b)==m['sha256'] and len(b)==m['bytes']
 return np.frombuffer(b,dtype).reshape(m['height'],m['width'],channels)
def decode(a):
 p=a[...,:2]*2-1;n=np.stack([p[...,0],1-np.abs(p).sum(axis=-1),p[...,1]],axis=-1)
 old=n.copy();negative=n[...,1]<0
 for i,j in ((0,2),(2,0)):n[...,i]=np.where(negative,(1-np.abs(old[...,j]))*np.where(old[...,i]>=0,1,-1),old[...,i])
 return n/np.linalg.norm(n,axis=-1,keepdims=True)
def angle(a,b):return np.degrees(np.arctan2(np.linalg.norm(np.cross(a,b),axis=-1),np.sum(a*b,axis=-1)))
def limits(a):return [float(np.min(a)),float(np.max(a))]
def main():
 assert D['restored'] and len(D['bindings'])==3
 for b in D['bindings']:
  raw=bytes.fromhex(b['raw']);assert sha(raw)==b['sha256']
  assert b['format']=='R8G8B8A8_UNORM' and raw==bytes([128,128,255,255])*4
 prior=json.loads((R/'prior-replay.json').read_bytes());req=json.loads((R/'prior-request.json').read_bytes())
 for name,h in req['frozenInputs'].items():assert sha((R/'fixture'/name).read_bytes())==h
 for k in ('normalRoughness','outputColor','outputConfidence','outputFootprint','filtered'):
  assert D['results']['control'][k]['sha256']==prior['attachments'][k]['sha256']
 display=load('control','display','u1',4)[...,[2,1,0]]
 assert sha(display.tobytes())==req['originalFrameRgbSha256']
 masks={n:polygon_mask(oracle(x)['reflectionPolygon'],.65)[1::2,1::2] for n,x in [('left',LEFT),('right',RIGHT)]}
 base=load('control','surface','<f4',4);result={}
 p=np.frombuffer(bytes.fromhex(prior['constants']['hex']),'<f4').reshape(30,4).astype(float)
 meta=prior['attachments']['currentDepth'];z=np.frombuffer(zlib.decompress((R/meta['file']).read_bytes()),'<f4').reshape(120,160)
 yy,xx=np.mgrid[:120,:160];uv=np.stack([(xx+.5)/160,(yy+.5)/120],axis=-1)
 clip=np.concatenate([uv*2-1,z[...,None],np.ones((120,160,1))],axis=-1);w=clip@p[14:18];world=w[...,:3]/w[...,3,None]
 incident=world-CAMERA;incident/=np.linalg.norm(incident,axis=-1,keepdims=True)
 normal0=decode(load('control','normalRoughness','<f4',4))
 ray0=incident-2*np.sum(incident*normal0,axis=-1,keepdims=True)*normal0
 for label in ('geometric','tilted'):
  surface=load(label,'surface','<f4',4);np.testing.assert_array_equal(surface[...,[0,3]],base[...,[0,3]])
  normal=decode(load(label,'normalRoughness','<f4',4))
  if label=='geometric':np.testing.assert_array_equal(normal[masks['right']],np.tile([0,1,0],(97,1)))
  ray=incident-2*np.sum(incident*normal,axis=-1,keepdims=True)*normal
  rows={}
  for name,mask in masks.items():
   conf=load(label,'outputConfidence','u1',1)[...,0];f=load(label,'filtered','<f4',4)
   hit=load(label,'hitUv','<u2',2);history=load(label,'historyUv','<u2',2)
   rows[name]=dict(pixels=int(mask.sum()),geometryHits=int(np.count_nonzero(hit[mask].any(axis=1))),historyAddresses=int(np.count_nonzero(history[mask].any(axis=1))),normalAngleDegrees=limits(angle(normal0[mask],normal[mask])),reflectionAngleDegrees=limits(angle(ray0[mask],ray[mask])),acceptedRays=int(np.count_nonzero(conf[mask])),filteredPixels=int(np.count_nonzero(f[mask,3])))
  changed={k:int(np.count_nonzero(load(label,k,'u1',D['results'][label][k]['bytes']//(D['results'][label][k]['width']*D['results'][label][k]['height']))!=load('control',k,'u1',D['results']['control'][k]['bytes']//(D['results']['control'][k]['width']*D['results']['control'][k]['height'])))) for k in D['results']['control']}
  assert all(v['acceptedRays']==v['filteredPixels']==0 for v in rows.values())
  result[label]=dict(regions=rows,changedBytes=changed,depthAndRoughnessExact=True)
 assert all(x>0 for x in result['geometric']['regions']['right']['normalAngleDegrees'])
 assert result['tilted']['regions']['right']['normalAngleDegrees'][0]>5
 result['fallbackTangentAngleDegrees']=float(np.degrees(np.arctan(np.sqrt(2)/255)))
 if '--record' in sys.argv:(R/'results.json').write_text(json.dumps(result,indent=2)+'\n')
 else:assert result==json.loads((R/'results.json').read_bytes())
 print(json.dumps(result,indent=2));print('PASS: frozen inputs, actual bindings, direction response and history rejection')
if __name__=='__main__':main()
