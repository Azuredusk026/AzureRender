from pathlib import Path
import hashlib,json,subprocess
R=Path(__file__).resolve().parent
q=json.loads((R/'programs.json').read_bytes());src=(R/'frozen-source/mesh.frag').read_bytes()
assert src.count(b'vec3 snapshotNormal=shadedNormal;')==1
compiler=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe')
for name,value in [('control',b'shadedNormal'),('geometric',b'geometricNormal'),('tilted',b'normalize(geometricNormal+vec3(0.1,0,0))')]:
 f=R/(name+'.frag');f.write_bytes(src.replace(b'vec3 snapshotNormal=shadedNormal;',b'vec3 snapshotNormal='+value+b';'))
 subprocess.run([str(compiler),*['-D'+v for v in q['defines']],'-I',str(R/'frozen-source'),str(f),'-o',str(R/(name+'.spv'))],check=True)
 assert hashlib.sha256((R/(name+'.spv')).read_bytes()).hexdigest()==q['programs'][name]
 subprocess.run([str(compiler.with_name('spirv-val.exe')),'--target-env','vulkan1.1',str(R/(name+'.spv'))],check=True)
print('PASS: three programs reproduced and SPIR-V validated')
