from hashlib import sha256
from pathlib import Path
import json
import sys
import zipfile

import numpy as np


run=Path(__file__).resolve().parent
adapter,=sys.argv[1:]
assert adapter in ('nvidia','intel')
root=run.parent
previous=root/'20261112-153052-reference-hair-mip-footprint-510ded'
baseline=root/'20261112-135432-reference-outline-projection-d784cf'
numeric=root/'20261110-003435-visibility-numeric-contract-4f95e7'
x,y=np.fromfile(numeric/'receiver-queries.bin','<f4').reshape(-1,4)[:,:2].astype('i4').T
assert len(x)==49384


def plane(folder):
    name='reference-normals-a2b10g10r10.bin'
    row=json.loads((folder/'reference-planes.json').read_text())[name]
    with zipfile.ZipFile(folder/'reference-planes.zip') as archive:
        raw=archive.read(row['archiveEntry'])
    assert sha256(raw).hexdigest()==row['sha256']
    return np.frombuffer(raw,'<u4').reshape(1440,2560)


base_attachment,candidate_attachment=(plane(folder/f'release-{adapter}-frames') for folder in (baseline,previous))
probe_attachment=plane(run/(adapter+'-frames'))
full_changed=base_attachment!=candidate_attachment
assert np.all((probe_attachment[full_changed]>>30)<2)
full_lod=probe_attachment[full_changed].view('<f4').astype('f8')-1
full_near=np.abs(full_lod-np.rint(full_lod-.5)-.5)<=1/256
base,candidate,probe=(plane[y,x] for plane in (base_attachment,candidate_attachment,probe_attachment))
raw=Path(json.loads((numeric/'hair-calibration.json').read_text())['normals']).read_bytes()
assert sha256(raw).hexdigest()=='63731d707e7ba30d9417049c8148b9bd2167208e435e8d9f0cc100a1fd03e095'
frozen=np.frombuffer(raw,'<u4').reshape(1440,2560)[y,x]
changed=base!=candidate
points=np.flatnonzero(changed)
assert len(points)==(8 if adapter=='nvidia' else 1061)
assert np.all((probe[changed]>>30)<2)
lod=probe[changed].view('<f4').astype('f8')-1
delta=np.abs(lod-np.rint(lod-.5)-.5)
near=delta<=1/256
if adapter=='nvidia':
    assert near.all() and np.array_equal(base[changed],frozen[changed])
    assert int(full_changed.sum())==8 and full_near.all()
control=[]
for i,j in enumerate(points):
    control.append(dict(pixel=[int(x[j]),int(y[j])],lod=float(lod[i]),boundaryDistance=float(delta[i]),
        basePackedNormal=int(base[j]),candidatePackedNormal=int(candidate[j]),frozenPackedNormal=int(frozen[j]),
        basePackedNormalExact=bool(base[j]==frozen[j]),withinOneFixedLodUnit=bool(near[i])))
selected=np.fromfile(run/f'{adapter}-selected.bin','<u4').reshape(17017,9)
hair_lod=selected[:,2].view('<f4').astype('f8')-1
hair_near=np.abs(hair_lod-np.rint(hair_lod-.5)-.5)<=1/256
hair_base,hair_candidate,hair_expected=selected[:,4],selected[:,5],selected[:,3]


def over_one(words):
    error=np.maximum(*[np.abs(((words>>shift)&1023).astype('i4')-((hair_expected>>shift)&1023).astype('i4'))
        for shift in (0,10)])
    return int((error>1).sum())


result=dict(device=adapter,receiverSamples=len(x),changedNormals=len(points),nearHalfWithinOneFixedLodUnit=int(near.sum()),
    completeAttachmentChangedNormals=int(full_changed.sum()),completeAttachmentNearHalf=int(full_near.sum()),
    nearWithFrozenBaselineExact=int((near&(base[changed]==frozen[changed])).sum()),
    fixedLodUnit=1/256,frozenHairSamples=len(selected),
    frozenHairNearHalf=int(hair_near.sum()),frozenHairNormalsOverOne=over_one(hair_candidate),
    frozenHairPredictedBoundaryFallbackNormalsOverOne=over_one(np.where(hair_near,hair_base,hair_candidate)),
    changed=control)
(run/(adapter+'-receiver-boundary.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key!='changed'}))

