from hashlib import file_digest, sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

import numpy as np


run=Path(__file__).resolve().parent
adapter,*arguments=sys.argv[1:]
assert adapter in ('nvidia','intel')
assert arguments in ([],['--analyze-existing'])
previous=run.parent/'20261112-153052-reference-hair-mip-footprint-510ded'
build=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
native=run.parent/'20261112-053111-intel-reference-visibility-sources-5238e2/native-normal-explicit-mips'
fixture=previous/'hair-project'
frames=run/(adapter+'-frames')
player=previous/'candidate-AzurePlayer.exe'
root=run/'overlay'
overlay=json.loads((run/'overlay.json').read_text())
candidate=json.loads((previous/f'release-{adapter}-results.json').read_text())


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


assert digest(player)==candidate['playerSha256']==overlay['isolatedPlayerSha256']
assert digest(build/'AzurePlayer.exe')==overlay['productionPlayerSha256']
for name,value in overlay['instrumentedShaders'].items():
    assert digest(root/'shaders'/name)==value
for item in json.loads((previous/'fixture-inputs.json').read_text())['files']:
    path=fixture/item['relative']
    assert path.stat().st_size==item['bytes'] and digest(path)==item['sha256']
meta=json.loads((fixture/'character/captured-hair-normal.dds.azmeta').read_text())['settings']['texture']
assert meta['mipBias']==-1 and meta['mipFilter']=='nearest' and meta['anisotropy']==1
command=[str(player),'--project',str(fixture/'hair-coverage.azureproject'),'--width','2560','--height','1440',
    '--capture-frames','3','--capture-dir',str(frames),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene',
    '--qa-isolation','beauty','--disable-compute-skinning','--disable-bindless','--resource-root',str(root)]
command_path=run/(adapter+'-command.json')
if arguments:
    assert json.loads(command_path.read_text())==command
else:
    command_path.write_text(json.dumps(command,indent=2)+'\n')
    env=os.environ.copy()
    env.update(PATH=str(build)+os.pathsep+env['PATH'])
    with (run/(adapter+'.log')).open('wb') as log:
        process=subprocess.run(command,cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    assert process.returncode==0
log=(run/(adapter+'.log')).read_text(errors='replace')
assert 'Captured frames: 3' in log and 'Allocator after unload: buffers=0 images=0' in log,log[-5000:]
assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I),log[-5000:]
manifest=json.loads((frames/'capture_manifest.json').read_text())['referenceSceneDepth']
gpu=json.loads((frames/'gpu_capabilities.json').read_text())
assert gpu['vendor_id']==(0x10de if adapter=='nvidia' else 0x8086)
assert (manifest['rowOrigin'],manifest['width'],manifest['height'],manifest['submission'])==('bottom-left',2560,1440,3)
files={key:frames/manifest[key] for key in ('raster','hardware','packedNormals','objectIds','objectVisibility')}
assert files['raster'].read_bytes()==files['hardware'].read_bytes()
assert digest(files['raster'])==candidate['referenceDepthSha256']
assert digest(files['objectIds'])==candidate['objectIdsSha256']
words=np.fromfile(files['packedNormals'],'<u4').reshape(1440,2560)
raw=np.fromfile(previous/f'release-{adapter}-hair-selected.bin','<u4').reshape(17017,8)
x,y=raw[:,:2].astype('i4').T
sampled=words[y,x]
mode=np.isfinite(sampled.view('<f4'))&((sampled>>30)<2)
assert mode.all(),dict(count=int((~mode).sum()),examples=np.flatnonzero(~mode)[:16].tolist())
base_lod=sampled.view('<f4').astype('f8')
assert np.isfinite(base_lod).all() and np.all(np.abs(base_lod)<126)
lod=base_lod+meta['mipBias']
native_levels=np.stack([np.fromfile(native/f'{adapter}-mip-{level:02d}.bin','<u4') for level in range(12)])
candidate_normals=raw[:,4]
errors=np.maximum(*[np.abs(((native_levels>>shift)&1023).astype('i4')-((candidate_normals>>shift)&1023).astype('i4'))
    for shift in (0,10)])
match=errors<=1
rows=np.arange(len(x))
choices={}
predictions={}
for label,values in (('unrounded-nearest-up',np.floor(lod+.5)),
    ('round-even-8-nearest-down',np.ceil(np.rint(lod*256)/256+.5)-1),
    ('round-even-8-nearest-up',np.floor(np.rint(lod*256)/256+.5)),
    ('truncate-8-nearest-down',np.ceil(np.floor(lod*256)/256+.5)-1),
    ('truncate-8-nearest-up',np.floor(np.floor(lod*256)/256+.5))):
    levels=np.clip(values,0,11).astype('i4')
    choices[label]=levels
    predictions[label]=int(match[levels,rows].sum())
selected=[]
for item in candidate['introduced']:
    px,py=item['pixel']
    word=words[py,px]
    assert int(word)>>30<2
    value=float(word.view('<f4'))+meta['mipBias']
    assert np.isfinite(value) and abs(value)<126
    matched=np.flatnonzero((x==px)&(y==py))
    entry=dict(pixel=[px,py],lodAfterBias=value,deltaFromHalfLevel=value-round(value-.5)-.5,
        estimatedNearestUp=int(np.clip(np.floor(value+.5),0,11)),
        nearest8Preferred=int(np.clip(np.ceil(np.rint(value*256)/256+.5)-1,0,11)),
        candidateVisibility=item['current'],frozenVisibility=item['expected'])
    if len(matched):
        assert len(matched)==1
        entry['actualCandidateMips']=np.flatnonzero(match[:,matched[0]]).tolist()
    selected.append(entry)
np.column_stack((x,y,sampled,raw[:,2],raw[:,3],raw[:,4],raw[:,5],raw[:,6],raw[:,7])).astype('<u4').tofile(
    run/(adapter+'-selected.bin'))
record=dict(device=adapter,playerSha256=digest(player),shaderSha256=overlay['instrumentedShaders']['reference_scene_visibility.frag.spv'],
    frozenSamples=len(x),lodBaseRange=[float(base_lod.min()),float(base_lod.max())],samplerBias=meta['mipBias'],
    lodSha256=sha256(sampled.tobytes()).hexdigest(),depthSha256=digest(files['raster']),
    priorPayloadPredicateRejected=int((((sampled>>20)&1023)==0).sum()),analyzedExisting=bool(arguments),
    objectIdsSha256=digest(files['objectIds']),validationClean=True,allocatorZero=True,
    modeMatchedNativeMip=int(match.any(axis=0).sum()),matchingCandidateMipsByRounding=predictions,
    introducedReceiverLod=selected)
(run/(adapter+'-live-lod.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))

