from hashlib import file_digest, sha256
from pathlib import Path
from shutil import copyfile, copytree
import json
import os
import subprocess


run=Path(__file__).resolve().parent
engine=run.parents[2]
previous=run.parent/'20261112-153052-reference-hair-mip-footprint-510ded'
build=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
source_root=run/'source'
stage=source_root/'Project/AzureRender/shaders'
overlay=run/'overlay/shaders'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


isolated=json.loads((previous/'isolated-candidate.json').read_text())
assert digest(previous/'candidate-AzurePlayer.exe')==isolated['candidatePlayerSha256']
assert digest(build/'AzurePlayer.exe')==isolated['restoredPlayerSha256']
patch=previous/'candidate.patch'
assert digest(patch)==isolated['candidatePatchSha256']
expected=json.loads((previous/'release-baseline-shaders.json').read_text())
catalog={path.name:digest(path) for path in (build/'shaders').glob('*.spv')}
assert catalog==expected and len(catalog)==895
copytree(engine/'shaders',stage)
env=os.environ.copy()
for key in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE'):
    env.pop(key,None)
env['GIT_CEILING_DIRECTORIES']=str(run)
args=['git','apply','--include=Project/AzureRender/shaders/reference_scene_depth.frag',
    '--include=Project/AzureRender/shaders/texture_footprint.glsl']
subprocess.run([*args,'--check',str(patch)],cwd=source_root,env=env,check=True)
subprocess.run([*args,str(patch)],cwd=source_root,env=env,check=True)
frag=stage/'reference_scene_depth.frag'
candidate=frag.read_text()
assert 'float lod=azureAxisDiagonalMipLod' in candidate and 'float azureAxisDiagonalMipLod' in (stage/'texture_footprint.glsl').read_text()


def compile_shader(suffix,target):
    defines=['AZURE_REFERENCE_MATERIAL_UV','AZURE_FRAGMENT_QUAD_OPERATIONS','AZURE_INDEPENDENT_COVERAGE',
        'AZURE_REFERENCE_SCENE_VISIBILITY']
    if suffix:
        defines.append('AZURE_BINDLESS')
    argv=[str(sdk/'glslc.exe'),'--target-env=vulkan1.1',*('-D'+key+'=1' for key in defines),str(frag),'-o',str(target)]
    subprocess.run(argv,check=True)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(target)],check=True)
    return argv


orig=json.loads((previous/'typecheck.json').read_text())['shaderPrograms']
commands={}
for suffix in ('','_bindless'):
    name='reference_scene_visibility'+suffix+'.frag.spv'
    target=run/('candidate-'+name)
    commands['candidate-'+name]=compile_shader(suffix,target)
    assert digest(target)==orig[name]
raw_candidate=frag.read_bytes()
(run/'candidate-reference-scene-depth.frag').write_bytes(raw_candidate)
probe=candidate.replace('vec3 surfaceNormal(){','float referenceNormalLodProbe;\n\nvec3 surfaceNormal(){',1)
probe=probe.replace('            encoded=textureLod(NORMAL_TEXTURE,textureCoordinate,lod).rg;',
    '            referenceNormalLodProbe=lod;\n            encoded=textureLod(NORMAL_TEXTURE,textureCoordinate,lod).rg;',1)
original_assignment='    packedNormal=encodeVisibilityNormal(referenceNormal(normal));'
assert original_assignment in probe
probe=probe.replace(original_assignment,
    '    if(material.normalControl.x==5.0){\n'
    '        uint bits=floatBitsToUint(referenceNormalLodProbe);\n'
    '        packedNormal=vec4(float(bits&1023u)/1023.0,float((bits>>10u)&1023u)/1023.0,\n'
    '            float((bits>>20u)&1023u)/1023.0,float(bits>>30u)/3.0);\n'
    '    }else{\n'+original_assignment+'\n    }',1)
frag.write_text(probe,encoding='utf-8')
(run/'instrumented-reference-scene-depth.frag').write_bytes(frag.read_bytes())
overlay.mkdir(parents=True)
for name in catalog:
    if name not in orig:
        copyfile(build/'shaders'/name,overlay/name)
for suffix in ('','_bindless'):
    name='reference_scene_visibility'+suffix+'.frag.spv'
    commands['probe-'+name]=compile_shader(suffix,overlay/name)
    assert digest(overlay/name)!=orig[name]
    copyfile(overlay/name,run/('probe-'+name))
after={path.name:digest(path) for path in overlay.glob('*.spv')}
assert after.keys()==catalog.keys() and {name for name in after if after[name]!=catalog[name]}==set(orig)
assert {path.name:digest(path) for path in (build/'shaders').glob('*.spv')}==catalog
result=dict(shaderCount=len(after),isolatedPlayerSha256=isolated['candidatePlayerSha256'],
    productionPlayerSha256=isolated['restoredPlayerSha256'],candidateShaders=orig,
    instrumentedShaders={name:after[name] for name in orig},overlay=after,commands=commands)
(run/'overlay.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ('overlay','commands')}))

