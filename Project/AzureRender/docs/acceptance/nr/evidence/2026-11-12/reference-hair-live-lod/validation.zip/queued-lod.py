from pathlib import Path
import json
import os
import subprocess
import sys


run=Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared

predecessor,*adapters=sys.argv[1:]
assert adapters in ([],['nvidia'],['intel'])
state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
assert state['token']==predecessor and state['state']=='released',state
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key,None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
lease=None
try:
    with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-reference-hair-live-lod',run) as lease:
        (run/'lease-held.json').write_text(json.dumps(lease,indent=2)+'\n')
        for adapter in adapters or ('nvidia','intel'):
            os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*' if adapter=='nvidia' else '*igvk64*'
            command=[sys.executable,'-B',str(run/'capture-lod.py'),adapter]
            receipt=shared.maintenance.guarded_run(run.parents[1],run.name,command,260)
            (run/(adapter+'-execution.json')).write_text(json.dumps(receipt,indent=2)+'\n')
            print(json.dumps(receipt),flush=True)
            assert receipt['status']=='exited' and receipt['exitCode']==0,receipt
            subprocess.run([sys.executable,'-B',str(run/'compact-capture.py'),adapter+'-frames'],check=True)
finally:
    if lease is not None:
        (run/'lease-released.json').write_text(json.dumps(lease,indent=2)+'\n')

