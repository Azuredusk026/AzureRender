from hashlib import file_digest
from pathlib import Path
import json
import zipfile


run=Path(__file__).resolve().parent
engine=run.parents[2]
evidence=engine/'docs/acceptance/nr/evidence/2026-11-12/reference-hair-live-lod'
overlay=(run/'overlay/shaders').resolve(strict=True)
assert overlay.parent.parent==run and overlay.parent.name=='overlay' and overlay.name=='shaders'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


record=json.loads((evidence/'results.json').read_text())
archive_path=evidence/'validation.zip'
assert record['status']=='qualified-reference-hair-live-lod'
assert digest(archive_path)==record['archive']['sha256']
manifest=json.loads((run/'overlay.json').read_text())
catalog=manifest['overlay']
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert json.loads(archive.read('overlay.json'))==manifest
    for name,sha in manifest['instrumentedShaders'].items():
        assert digest(run/('probe-'+name))==sha
        assert archive.read('probe-'+name)==(run/('probe-'+name)).read_bytes()

files=list(overlay.iterdir())
assert {path.name for path in files}==catalog.keys() and len(files)==895
for path in files:
    assert path.resolve(strict=True).parent==overlay and path.suffix=='.spv'
    assert path.is_file() and not path.is_symlink() and path.stat().st_nlink==1
    assert digest(path)==catalog[path.name]
size=sum(path.stat().st_size for path in files)
for path in files:
    path.unlink()
overlay.rmdir()
overlay.parent.rmdir()
(run/'compacted-overlay.json').write_text(json.dumps(dict(files=len(files),bytes=size,
    evidenceSha256=record['archive']['sha256']),indent=2)+'\n')
print(f'Removed {len(files)} verified shader copies from this diagnostic, {size} bytes')

