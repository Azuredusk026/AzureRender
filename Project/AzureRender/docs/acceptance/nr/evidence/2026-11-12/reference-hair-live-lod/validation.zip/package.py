from hashlib import file_digest, sha256
from pathlib import Path
import json
import zipfile

import numpy as np


run=Path(__file__).resolve().parent
engine=run.parents[2]
previous=run.parent/'20261112-153052-reference-hair-mip-footprint-510ded'
build=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
evidence=engine/'docs/acceptance/nr/evidence/2026-11-12/reference-hair-live-lod'


def read(name):
    return json.loads((run/name).read_text())


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


overlay=read('overlay.json')
assert overlay['shaderCount']==len(overlay['overlay'])==895
assert digest(build/'AzurePlayer.exe')==overlay['productionPlayerSha256']
assert digest(previous/'candidate-AzurePlayer.exe')==overlay['isolatedPlayerSha256']
production=json.loads((previous/'release-baseline-shaders.json').read_text())
assert {path.name:digest(path) for path in (build/'shaders').glob('*.spv')}==production
assert {name for name,value in overlay['overlay'].items() if value!=production[name]}==set(overlay['instrumentedShaders'])
assert all(digest(run/'overlay/shaders'/name)==sha for name,sha in overlay['overlay'].items())

lease=read('lease-released.json')
assert lease['state']=='released' and lease['token']==read('lease-held.json')['token']
first_lease=read('first-lease-released.json')
assert first_lease['state']=='released' and first_lease['token']==read('first-lease-held.json')['token']
devices={}
receipts={}
boundaries={}
for adapter in ('nvidia','intel'):
    result=read(adapter+'-live-lod.json')
    receipt=read(adapter+'-execution.json')
    assert receipt['status']=='exited' and receipt['exitCode']==(1 if adapter=='nvidia' else 0)
    assert result['analyzedExisting']==(adapter=='nvidia')
    previous_result=json.loads((previous/f'release-{adapter}-results.json').read_text())
    assert result['frozenSamples']==17017 and result['playerSha256']==previous_result['playerSha256']
    assert result['depthSha256']==previous_result['referenceDepthSha256']
    assert result['objectIdsSha256']==previous_result['objectIdsSha256']
    assert result['validationClean'] and result['allocatorZero']
    selected=np.fromfile(run/f'{adapter}-selected.bin','<u4').reshape(17017,9)
    assert sha256(selected[:,2].tobytes()).hexdigest()==result['lodSha256']
    assert np.array_equal(selected[:,[0,1,3,4,5,6,7,8]],
        np.fromfile(previous/f'release-{adapter}-hair-selected.bin','<u4').reshape(17017,8))
    for name,sha in overlay['instrumentedShaders'].items():
        assert digest(run/('probe-'+name))==sha
    receipts[adapter]=receipt
    devices[adapter]=result
    boundaries[adapter]=read(adapter+'-receiver-boundary.json')
assert devices['nvidia']['priorPayloadPredicateRejected']==3067
assert boundaries['nvidia']['changedNormals']==boundaries['nvidia']['nearWithFrozenBaselineExact']==8

evidence.mkdir(parents=True,exist_ok=False)
archive_path=evidence/'validation.zip'
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(run.iterdir()):
        if path.is_file() and path.suffix in ('.py','.json','.log','.spv','.frag','.bin'):
            archive.write(path,path.name)
    for adapter in devices:
        folder=run/(adapter+'-frames')
        for name in ('capture_manifest.json','reference-planes.json','gpu_capabilities.json'):
            archive.write(folder/name,(folder/name).relative_to(run).as_posix())
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    members=len(archive.namelist())
raw=archive_path.read_bytes()
assert len(raw)<8*1024**2
result=dict(status='qualified-reference-hair-live-lod',overallStatus='failed-user-review',devices=devices,
    boundaries={device:{key:value for key,value in item.items() if key!='changed'} for device,item in boundaries.items()},
    executions=receipts,lease=lease,firstLease=first_lease,scope=read('task-card.json'),
    overlay={key:value for key,value in overlay.items() if key!='overlay'},
    archive=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw),members=members))
(evidence/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['archive']))

