from hashlib import sha256
from pathlib import Path
import json
import zipfile
import zlib

import numpy as np


run = Path(__file__).resolve().parent
capture = run.parent/'20261112-053111-intel-reference-visibility-sources-5238e2/native-normal-explicit-mips'
native = run.parent/'20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry'
normals = run.parent/'20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
numeric = run.parent/'20261110-003435-visibility-numeric-contract-4f95e7'


def read(folder,name):
    return json.loads((folder/name).read_text())


def crop(folder, item):
    raw=(folder/item['path']).read_bytes()
    assert len(raw)==item['bytes'] and sha256(raw).hexdigest()==item['sha256']
    return np.frombuffer(zlib.decompress(raw),'<u4').reshape(310,290)


replay = read(native,'native-caster-geometry.json')
producer = read(normals,'native-atlas-producers.json')
explicit = read(capture,'explicit-normal-mips.json')
assert replay['status']==producer['status']==explicit['status']=='qualified'
owner=np.zeros((310,290),'u2')
last=np.zeros_like(owner,'<u4')
for event,stage in producer['receiverNormal']['stages'].items():
    value=crop(normals,stage['crop'])
    owner[value!=last]=int(event)
    last=value
depths={event:crop(native,replay['receiverDepth'][str(event)]['crop']) for event in (422,440,699)}
x,y=np.fromfile(numeric/'receiver-queries.bin','<f4').reshape(-1,4)[:,:2].astype('i4').T
sy,sx=y-1000,x-1140
native_shell=(depths[422]!=depths[440])&(depths[440]==depths[699])&(owner==422)
selected=native_shell[sy,sx]
x,y,sy,sx=(arr[selected] for arr in (x,y,sy,sx))
assert len(x)==2046
frozen=depths[699][sy,sx].astype('i8')

intel=explicit['devices']['intel']['receiverSources']['depth']
blob=(capture/intel['file']).read_bytes()
raw=zlib.decompress(blob)
assert sha256(blob).hexdigest()==intel['compressedSha256']
assert len(raw)==intel['bytes'] and sha256(raw).hexdigest()==intel['sha256']
same_adapter=np.frombuffer(raw,'<u4').reshape(1440,2560)[y,x].astype('i8')

folder=run/'release-intel-frames'
item=read(folder,'reference-planes.json')['reference-depth-r32.bin']
with zipfile.ZipFile(folder/'reference-planes.zip') as archive:
    raw=archive.read(item['archiveEntry'])
assert len(raw)==item['size'] and sha256(raw).hexdigest()==item['sha256']
vulkan=np.frombuffer(raw,'<u4').reshape(1440,2560)[y,x].astype('i8')


def metrics(value,target):
    delta=value-target
    return dict(exact=int((delta==0).sum()),withinOneUlp=int((abs(delta)<=1).sum()),
        minimumUlp=int(delta.min()),maximumUlp=int(delta.max()))


comparisons = dict(vulkanIntelToFrozen=metrics(vulkan,frozen),vulkanIntelToNativeIntel=metrics(vulkan,same_adapter),
    nativeIntelToFrozen=metrics(same_adapter,frozen))
assert [result['withinOneUlp'] for result in comparisons.values()]==[1720,2035,1735]
assert [result['exact'] for result in comparisons.values()]==[753,2017,770]
record=dict(samples=len(x),nativeIntelSha256=intel['sha256'],vulkanIntelSha256=item['sha256'],
    comparisons=comparisons,overallStatus='failed-user-review')
(run/'native-adapter-depth.json').write_text(json.dumps(record,indent=2)+'\n')
np.column_stack((x,y,frozen,same_adapter,vulkan)).astype('<u4').tofile(run/'native-adapter-depth-selected.bin')
print(json.dumps(record))

