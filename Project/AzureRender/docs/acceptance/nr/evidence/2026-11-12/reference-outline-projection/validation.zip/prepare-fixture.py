from hashlib import file_digest
from pathlib import Path
from shutil import copyfile
import json
import struct


run = Path(__file__).resolve().parent
baseline = run.parent / '20261112-114419-reference-geometric-normal-3e57b5'
source = baseline / 'hair-project'
fixture = run / 'hair-project'
reference_views = 'config/reference-views.json'
native = run.parent / '20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry'
parameters = native / '440-0-b0.bin'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


files = json.loads((baseline/'fixture-inputs.json').read_text())['files']
assert len(files) == 45
for row in files:
    relative = Path(row['relative'])
    original = source / relative
    assert original.resolve(strict=True).is_relative_to(source)
    assert original.stat().st_size == row['bytes'] and digest(original) == row['sha256']
    if relative.as_posix() == reference_views:
        continue
    target = fixture / relative
    target.parent.mkdir(parents=True,exist_ok=True)
    copyfile(original,target)
    assert digest(target) == row['sha256']

raw = parameters.read_bytes()
assert len(raw) == 1536
slope = -struct.unpack_from('<f',raw,10*16+8)[0]
intercept = struct.unpack_from('<f',raw,11*16+8)[0]
assert (slope,intercept) == (-9.894371032714844e-06,.10000098496675491)
assert struct.unpack_from('<f',(native/'440-0-b3.bin').read_bytes(),13*16+4)[0] == 0
document = json.loads((source/reference_views).read_text())
assert set(document['views']) == {'native-hair'}
outline = dict(schemaVersion=1,clipWSlope=slope,clipZIntercept=intercept)
view = document['views']['native-hair']
assert view['produceSceneDepth'] and 'outlineDepthProjection' not in view
view['outlineDepthProjection'] = outline
(fixture/reference_views).write_text(json.dumps(document,indent=2)+'\n')
files_after = [dict(relative=path.relative_to(fixture).as_posix(),bytes=path.stat().st_size,sha256=digest(path))
    for path in sorted(fixture.rglob('*')) if path.is_file()]
changed = {after['relative'] for before,after in zip(files,files_after) if before['sha256'] != after['sha256']}
assert [before['relative'] for before in files] == [after['relative'] for after in files_after]
assert changed == {reference_views}
result = dict(files=files_after,nativeEvent=440,sourceConstantsSha256=digest(parameters),outline=outline,
    materialDepthOffset=0,changed=sorted(changed))
(run/'fixture-inputs.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key!='files'}))

