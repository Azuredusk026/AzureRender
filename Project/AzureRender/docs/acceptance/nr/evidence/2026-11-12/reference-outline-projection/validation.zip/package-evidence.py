from hashlib import sha256
from pathlib import Path
import json
import zipfile

import numpy as np


run = Path(__file__).resolve().parent
engine = run.parents[2]
evidence = engine/'docs/acceptance/nr/evidence/2026-11-12/reference-outline-projection'
native = run.parent/'20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry'
native_normals = run.parent/'20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
previous = run.parent/'20261112-114419-reference-geometric-normal-3e57b5'
numeric = run.parent/'20261110-003435-visibility-numeric-contract-4f95e7'


def load(path):
    return json.loads(path.read_text())


def read(name):
    return load(run/name)


def receipt(path):
    result = load(path)
    assert result['status']=='exited' and result['exitCode']==0, path
    return result


def attachments(folder):
    manifest = load(folder/'reference-planes.json')
    with zipfile.ZipFile(folder/'reference-planes.zip') as archive:
        planes = {}
        for name, item in manifest.items():
            data = archive.read(item['archiveEntry'])
            assert len(data)==item['size'] and sha256(data).hexdigest()==item['sha256']
            planes[name] = data
        return planes


assert read('red-receipt.json')['exitCode']==3
assert read('green-receipt.json')['exitCode']==0
abi = read('abi-candidate.json')
assert abi==read('abi-base.json')
shader_preflight=read('preflight-shaders.json')
assert len(shader_preflight)==4
for path,digest in shader_preflight.items():
    assert sha256((run/path).read_bytes()).hexdigest()==digest
release=read('release-verification.json')
debug=read('debug-verification.json')
assert (release['tests'],debug['tests'])==(8,7)
assert release['changedShaders']==debug['changedShaders']
assert {name:item['after'] for name,item in release['changedShaders'].items()}==shader_preflight
assert release['shaderCount']==debug['shaderCount']==895
results = {}
controls = {}
devices = ('nvidia','intel')
configurations = ('release','debug')
cases = tuple(f'{config}-{adapter}' for config in configurations for adapter in devices)
for label in cases:
    configuration,adapter=label.split('-')
    results[label]=read(label+'-results.json')
    controls[label]=read('outline-control-'+label+'/summary.json')
    assert results[label]['hairDepthExact'] and results[label]['hairColorExact'] and results[label]['hairVisibilityExact']
    assert results[label]['nativeHairShell']['withinOneUlp']>results[label]['nativeHairShell']['baselineWithinOneUlp']
    assert results[label]['receiver']['overOne']<=results[label]['receiver']['baselineOverOne']
    assert read(label+'-gpu-verification.json')['tests']==5
for adapter in devices:
    release_result,debug_result=(results[name+'-'+adapter] for name in configurations)
    ignored=('configuration','playerSha256')
    assert {key:value for key,value in release_result.items() if key not in ignored}=={
        key:value for key,value in debug_result.items() if key not in ignored}
    release_folder=run/('release-'+adapter+'-frames')
    debug_folder=run/('debug-'+adapter+'-frames')
    assert attachments(release_folder)==attachments(debug_folder)
    for frame in range(3):
        name=f'frame_{frame:06d}.png'
        assert (release_folder/name).read_bytes()==(debug_folder/name).read_bytes()

stages = {path.stem.removesuffix('-execution'):receipt(path)
    for path in sorted(run.glob('*-execution.json'))}
expected = {'release-build','release-cpu-tests','debug-prepare','debug-build','debug-cpu-tests','original-four'}
for case in cases:
    expected |= {case+'-gpu-tests',case+'-capture',case+'-outline-projection-control'}
assert expected<=stages.keys()
leases={}
for path in sorted(run.glob('*-lease-released.json')):
    stage=path.name.removesuffix('-lease-released.json')
    item=load(path)
    assert item['state']=='released' and item['token']==read(stage+'-lease-held.json')['token']
    leases[stage]=item
assert len(leases)>=2
default=read('default-four-results.json')
assert default['allExact'] and default['depthCaptureAbsent'] and default['allocatorZero'] and default['validationClean']
assert len(default['frames'])==4 and default['playerSha256']==release['playerSha256']
native_adapter=read('native-adapter-depth.json')
assert native_adapter['vulkanIntelSha256']==results['release-intel']['referenceDepthSha256']

evidence.mkdir(parents=True,exist_ok=False)
archive_path=evidence/'validation.zip'
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(run.iterdir()):
        if path.is_file() and path.suffix in ('.py','.cpp','.json','.xml','.log','.spv'):
            archive.write(path,path.name)
    for label in cases:
        control=run/('outline-control-'+label)
        for path in sorted(control.rglob('*')):
            if path.is_file() and path.suffix in ('.json','.log','.bin'):
                archive.write(path,path.relative_to(run).as_posix())
        folder=run/(label+'-frames')
        for name in ('reference-planes.json','capture_manifest.json','gpu_capabilities.json'):
            archive.write(folder/name,(folder/name).relative_to(run).as_posix())
    native_report=load(native/'native-caster-geometry.json')
    depth_crops=tuple(native_report['receiverDepth'][str(event)]['crop']['path'] for event in (422,440,699))
    for name in ('440-0-b0.bin','440-0-b3.bin','440-0.asm','native-caster-geometry.json',*depth_crops):
        archive.write(native/name,'native/'+name)
    normal_report=load(native_normals/'native-atlas-producers.json')
    archive.write(native_normals/'native-atlas-producers.json','native-normals/native-atlas-producers.json')
    for stage in normal_report['receiverNormal']['stages'].values():
        name=stage['crop']['path']
        archive.write(native_normals/name,'native-normals/'+name)
    for name in ('receiver-queries.bin','receiver-expected.bin'):
        archive.write(numeric/name,'frozen/'+name)
    archive.write(run/'native-adapter-depth-selected.bin','selected/native-adapter-depth.bin')
    x,y=np.fromfile(numeric/'receiver-queries.bin','<f4').reshape(-1,4)[:,:2].astype('i4').T
    for adapter in devices:
        label='release-'+adapter
        for frame,source in (('base',previous),('current',run)):
            planes=attachments(source/(label+'-frames'))
            depth=np.frombuffer(planes['reference-depth-r32.bin'],'<u4').reshape(1440,2560)[y,x]
            visibility=np.frombuffer(planes['reference-object-visibility-rg8.bin'],'u1').reshape(1440,2560,2)[y,x,1]
            archive.writestr(f'selected/{adapter}-{frame}-depth.bin',depth.tobytes())
            archive.writestr(f'selected/{adapter}-{frame}-visibility.bin',visibility.tobytes())
    archive.write(run/'hair-project/config/reference-views.json','fixture/reference-views.json')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    members=len(archive.namelist())
raw=archive_path.read_bytes()
assert len(raw)<8*1024**2
result=dict(status='qualified-reference-outline-projection',overallStatus='failed-user-review',scope=read('task-card.json'),
    fixture=read('fixture-inputs.json'),abi=abi,release=release,debug=debug,devices=results,controls=controls,
    nativeAdapterDepth=native_adapter,executions=stages,leases=leases,defaultFour=default,
    archive=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw),members=members))
(evidence/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['archive']))

