#include "render/RenderSettings.hpp"
#include <cstddef>
#include <iostream>

int main(){
    using namespace azurerender;
    std::cout<<"{\"viewSize\":"<<sizeof(ReferenceCameraView)<<",\"viewAlignment\":"<<alignof(ReferenceCameraView)
        <<",\"frame\":"<<offsetof(ReferenceCameraView,frame)<<",\"projection\":"<<offsetof(ReferenceCameraView,projection)
        <<",\"extent\":"<<offsetof(ReferenceCameraView,extent)<<",\"depthConvention\":"<<offsetof(ReferenceCameraView,depthConvention)
        <<",\"sceneDepth\":"<<offsetof(ReferenceCameraView,produceSceneDepth)
        <<",\"sceneVisibility\":"<<offsetof(ReferenceCameraView,produceSceneVisibilityInputs)
        <<",\"objectVisibility\":"<<offsetof(ReferenceCameraView,objectVisibility)
        <<",\"cameraViewSize\":"<<sizeof(CameraViewDescriptor)<<",\"calibrationSize\":"<<sizeof(ReferenceCameraCalibration)
        <<",\"renderSettingsSize\":"<<sizeof(RenderSettings)<<",\"cameraView\":"<<offsetof(RenderSettings,cameraView)<<"}\n";
}
