from hashlib import file_digest, sha256
from pathlib import Path
import json
import re
import runpy
import subprocess
import sys
import zipfile
import zlib

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
config, device = sys.argv[1:]
assert config in ('Release', 'Debug') and device in ('nvidia', 'intel')
label = config.lower() + '-' + device
frames = out / (label + '-frames')
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if config == 'Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
prior = out.parent / '20261112-114419-reference-geometric-normal-3e57b5'
fixture = out / 'hair-project'
player = build / 'AzurePlayer.exe'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


previous = json.loads((prior / (label + '-results.json')).read_text())
candidate_player = json.loads((out / (config.lower() + '-verification.json')).read_text())['playerSha256']
assert previous['playerSha256'] != candidate_player and digest(player) == candidate_player
for entry in json.loads((out / 'fixture-inputs.json').read_text())['files']:
    path = fixture / entry['relative']
    assert path.stat().st_size == entry['bytes'] and digest(path) == entry['sha256']
command = [str(player), '--project', str(fixture / 'hair-coverage.azureproject'), '--width', '2560', '--height', '1440',
    '--capture-frames', '3', '--capture-dir', str(frames), '--fixed-frame-step', '--qa-camera', 'scene', '--qa-light', 'scene',
    '--qa-isolation', 'beauty', '--disable-compute-skinning', '--disable-bindless', '--resource-root', str(build)]
(out / (label + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
log_path = out / (label + '.log')
with log_path.open('wb') as log:
    execution = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=240)
log = log_path.read_text(errors='replace')
assert execution.returncode == 0 and 'Allocator after unload: buffers=0 images=0' in log, log[-7000:]
assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]', log, re.I), log[-7000:]
assert 'M_actor_laevat_cloth_01, slot=1, bytes=22369620' in log
capture = json.loads((frames / 'capture_manifest.json').read_text())['referenceSceneDepth']
assert (capture['rowOrigin'], capture['normalFrame'], capture['submission'], capture['width'], capture['height']) == (
    'bottom-left', 'reference', 3, 2560, 1440)
keys = ('raster', 'hardware', 'packedNormals', 'objectIds', 'objectVisibility')
planes = {key: (frames / capture[key]).read_bytes() for key in keys}
assert planes['raster'] == planes['hardware']
assert sha256(planes['raster']).hexdigest() != previous['referenceDepthSha256']
assert sha256(planes['objectIds']).hexdigest() == previous['objectIdsSha256']
baseline_manifest = json.loads((prior / (label + '-frames/reference-planes.json')).read_text())
with zipfile.ZipFile(prior / (label + '-frames/reference-planes.zip')) as archive:
    before = {key: archive.read(baseline_manifest[capture[key]]['archiveEntry']) for key in keys}
assert sha256(before['packedNormals']).hexdigest() == previous['normalsSha256']
assert sha256(before['objectVisibility']).hexdigest() == previous['visibilitySha256']

assert before['packedNormals'] == planes['packedNormals'] and before['objectIds'] == planes['objectIds']
assert sha256(before['raster']).hexdigest() == previous['referenceDepthSha256']
before_depth = np.frombuffer(before['raster'],'<u4').reshape(1440,2560)
after_depth = np.frombuffer(planes['raster'],'<u4').reshape(1440,2560)
before_rg8 = np.frombuffer(before['objectVisibility'],'u1').reshape(1440,2560,2)
after_rg8 = np.frombuffer(planes['objectVisibility'],'u1').reshape(1440,2560,2)
assert np.array_equal(before_rg8[...,0],after_rg8[...,0])

atlas = out.parent / '20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
replay = out.parent / '20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry'
native = json.loads((replay/'native-caster-geometry.json').read_text())
normal_report = json.loads((atlas/'native-atlas-producers.json').read_text())
assert native['status'] == normal_report['status'] == 'qualified'


def load_crop(folder, entry):
    payload = (folder / entry['path']).read_bytes()
    assert len(payload)==entry['bytes'] and sha256(payload).hexdigest()==entry['sha256']
    return np.frombuffer(zlib.decompress(payload),'<u4').reshape(310,290)


owner = np.zeros((310,290),'u2')
last = np.zeros_like(owner,'<u4')
for event, stage in normal_report['receiverNormal']['stages'].items():
    current = load_crop(atlas,stage['crop'])
    owner[current!=last] = int(event)
    last = current
native_depth = {event:load_crop(replay,native['receiverDepth'][str(event)]['crop']) for event in (422,440,699)}
native_shell = (native_depth[422]!=native_depth[440]) & (native_depth[440]==native_depth[699])
numeric = out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
x,y = np.fromfile(numeric/'receiver-queries.bin','<f4').reshape(-1,4)[:,:2].astype('i4').T
expected = np.fromfile(numeric/'receiver-expected.bin','<u4').astype('i4')
assert len(x)==len(expected)==49384
crop_y,crop_x = y-1000,x-1140
shell = native_shell[crop_y,crop_x] & (owner[crop_y,crop_x]==422)
assert int(shell.sum())==2046
target_depth = native_depth[699][crop_y,crop_x].astype('i8')
before_error = np.abs(before_depth[y,x].astype('i8')-target_depth)
after_error = np.abs(after_depth[y,x].astype('i8')-target_depth)
depth_changed = before_depth[y,x]!=after_depth[y,x]
before_visibility = before_rg8[y,x,1].astype('i4')
after_visibility = after_rg8[y,x,1].astype('i4')
before_bad = np.abs(before_visibility-expected)>1
after_bad = np.abs(after_visibility-expected)>1
new_bad = ~before_bad & after_bad
closed = before_bad & ~after_bad


def stats(mask):
    return dict(samples=int(mask.sum()),baselineOverOne=int((mask&before_bad).sum()),
        overOne=int((mask&after_bad).sum()),closed=int((mask&closed).sum()),
        introduced=int((mask&new_bad).sum()),depthChanged=int((mask&depth_changed).sum()))


shell_metrics = stats(shell)
shell_metrics.update(exact=int((shell&(after_error==0)).sum()),
    withinOneUlp=int((shell&(after_error<=1)).sum()),baselineWithinOneUlp=int((shell&(before_error<=1)).sum()),
    closer=int((shell&(after_error<before_error)).sum()),further=int((shell&(after_error>before_error)).sum()),
    medianUlp=float(np.median(after_error[shell])),baselineMedianUlp=float(np.median(before_error[shell])))
receiver = stats(np.ones(len(x),dtype=bool))
assert receiver['baselineOverOne']==previous['receiver']['overOne']
hair_source = out.parent/'20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
hx,hy = np.fromfile(hair_source/'queries.bin','<f4').reshape(-1,4)[:,:2].astype('i4').T
assert len(hx)==17017
hair_depth_exact = bool(np.array_equal(before_depth[hy,hx],after_depth[hy,hx]))
hair_visibility_exact = bool(np.array_equal(before_rg8[hy,hx],after_rg8[hy,hx]))
hair_expected = np.fromfile(hair_source/'expected.bin','<u4').astype('i4')
hair_errors = np.abs(after_rg8[hy,hx,1].astype('i4')-hair_expected)
color = runpy.run_path(str(out.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
bounds = color['x0'],color['y0'],color['x1'],color['y1']
current_color = np.asarray(Image.open(frames/'frame_000000.png').convert('RGB').crop(bounds))
before_color = np.asarray(Image.open(prior/(label+'-frames/frame_000000.png')).convert('RGB').crop(bounds))
mask = color['mask']
hair_color_exact = bool(np.array_equal(current_color[mask],before_color[mask]))
hair_color_errors = np.abs(current_color.astype('i4')-color['expected'])[mask].max(axis=1)
introduced = [dict(pixel=[int(x[i]),int(y[i])],nativeShell=bool(shell[i]),owner=int(owner[crop_y[i],crop_x[i]]),
    expected=int(expected[i]),baseline=int(before_visibility[i]),current=int(after_visibility[i]),
    baselineDepthUlp=int(before_error[i]),depthUlp=int(after_error[i])) for i in np.flatnonzero(new_bad)]
results = dict(configuration=config,device=device,playerSha256=candidate_player,receiver=receiver,
    nativeHairShell=shell_metrics,otherReceivers=stats(~shell),introduced=introduced,
    attachmentDepthChanged=int((before_depth!=after_depth).sum()),hairDepthExact=hair_depth_exact,
    hairVisibilityExact=hair_visibility_exact,hairColorExact=hair_color_exact,
    hairVisibilityOverOne=int((hair_errors>1).sum()),hairColorOverOne=int((hair_color_errors>1).sum()),
    validationClean=True,allocatorZero=True,referenceDepthSha256=sha256(planes['raster']).hexdigest(),
    visibilitySha256=sha256(planes['objectVisibility']).hexdigest(),normalsSha256=sha256(planes['packedNormals']).hexdigest(),
    objectIdsSha256=sha256(planes['objectIds']).hexdigest(),colorSha256=[digest(frames/f'frame_{i:06d}.png') for i in range(3)])
(out/(label+'-results.json')).write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
assert shell_metrics['withinOneUlp']>shell_metrics['baselineWithinOneUlp']
assert shell_metrics['overOne']<=shell_metrics['baselineOverOne'] and receiver['overOne']<=receiver['baselineOverOne']
assert hair_depth_exact and hair_visibility_exact and hair_color_exact
assert results['hairVisibilityOverOne']==previous['hairVisibilityOverOne']
assert results['hairColorOverOne']==previous['hairColorOverOne']

