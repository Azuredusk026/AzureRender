from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys


out = Path(__file__).resolve().parent
build = out.parents[1]
main = Path('D:/Projects/FYP/Project/AzureRender/build')
owner = '01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
source = 'c6589718e25daca22c00871622312016da789734'
sys.path.insert(0, str(main.parent / 'tools'))
import shared_resources as shared


claim_path = Path('D:/Projects/FYP-coordination/quality-claim.json')
claim = json.loads(claim_path.read_text(encoding='utf-8'))
assert claim['threadId'] == owner and claim['state'] == 'reference-receiver-source-isolation'
commit = subprocess.check_output(['git', 'log', '-1', '--format=%H%n%P'], cwd=build.parent, text=True).splitlines()
assert commit == [source, claim['lastCommit']]
evidence = build.parent / 'docs/acceptance/nr/evidence/2026-11-12/reference-receiver-source-isolation'
manifest = json.loads((evidence / 'results.json').read_text())
assert manifest['status'] == 'qualified'
assert sha256((evidence / 'validation.zip').read_bytes()).hexdigest() == manifest['archive']['sha256']
old_stage = Path(claim['taskPath'])
assert old_stage.name == '20261112-133809-reference-receiver-source-isolation-6cdff0'
old_local, old_main = claim['localInputLease'], claim['inputLease']


def inherited(root, tokens):
    with shared.maintenance.database(root, True) as db:
        records = shared.maintenance.rows(db)
    assert all(records[token]['owner'] == owner for token in tokens)
    return list(dict.fromkeys(name for token in tokens for name in records[token]['inputs']))


local_inputs = inherited(build, old_local) + [old_stage.name]
main_inputs = inherited(main, old_main)
local = shared.acquire_inputs(build, out, local_inputs, owner)
try:
    native = shared.acquire_inputs(main, out, main_inputs, owner)
except Exception:
    shared.release_inputs(build, local, owner)
    raise
claim.update(state='reference-outline-projection', taskPath=str(out), inputLease=[native], localInputLease=[local],
    nativeCaptureLease=native, lastCommit=source, pendingCommand='Verify opt-in reference outline depth projection',
    ownedFiles=['src/render/ReferenceCameraView.hpp','src/render/ReferenceCameraViewJson.cpp','src/render/ReferenceRasterProjection.hpp','shaders/outline_view_scaled.glsl','tests/ReferenceCameraViewTests.cpp','docs/acceptance/nr/reference-outline-projection.md',
        'docs/acceptance/nr/evidence/2026-11-12/reference-outline-projection'], additionalTaskPaths=[])
claim['observed'].update(isolatedNativeDepthNormalsReceiverNvidia=10,isolatedNativeDepthNormalsReceiverIntel=6)
(out / 'task-card.json').write_text(json.dumps(dict(local=local, main=native, sourceBase=source, plannedBytes=536870912,
    localInputs=local_inputs, mainInputs=main_inputs, change='Opt-in native E440 perspective depth coefficients',
    gate='Reference attachments and original four exact; one-byte receivers and hair unchanged'), indent=2) + '\n')
temporary = claim_path.with_name(claim_path.name + '.nr-quality-new')
with temporary.open('x', encoding='utf-8') as stream:
    json.dump(claim, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
os.replace(temporary, claim_path)
for token in old_main:
    shared.release_inputs(main, token, owner)
for token in old_local:
    shared.release_inputs(build, token, owner)
print(json.dumps(dict(local=local, main=native, output=str(out))))

