#include "render/ReferenceCameraViewJson.hpp"
#include "render/ReferenceRasterProjection.hpp"
#include <nlohmann/json.hpp>
#include <iostream>

int main(){
    using namespace azurerender;
    try {
        ReferenceCameraView baseline;
        baseline.produceSceneDepth=true;
        nlohmann::json document=baseline;
        document["outlineDepthProjection"]={{"schemaVersion",1},{"clipWSlope",-.125F},{"clipZIntercept",.25F}};
        const PreparedReferenceCameraView authored(document.get<ReferenceCameraView>());
        const auto upload=referenceRasterProjectionParameters(authored);
        if(nlohmann::json(authored.descriptor())!=document||upload.control[2]!=5||
            upload.projection.jitter!=std::array<float,4>{0,0,-.125F,.25F})return 2;
        std::cout<<"Outline coefficients round trip and reach the reference raster upload\n";
        return 0;
    } catch(const std::exception& e) {
        std::cerr<<e.what()<<'\n';
        return 3;
    }
}
