from hashlib import sha256
from pathlib import Path
import json
import zlib

import numpy as np


out = Path(__file__).resolve().parent
native = out.parent / '20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
replay = out.parent / '20261112-041837-reference-object-shadow-raster-capture-60f161'
receipt = json.loads((native / 'native-atlas-producers.json').read_text())
assert receipt['status'] == 'qualified'
shape = (1024, 1024)
owners = np.zeros(shape, 'u2')
reference = np.zeros(shape, '<u2')
for event, source in receipt['stages'].items():
    file = source['tile']
    data = (native / file['path']).read_bytes()
    assert sha256(data).hexdigest() == file['sha256']
    current = np.frombuffer(zlib.decompress(data), '<u2').reshape(shape)
    owners[current != reference] = int(event)
    reference = current
proof = json.loads((replay / 'shadow-raster-gpu-proof.json').read_text())
data = (replay / 'atlas.bin').read_bytes()
assert sha256(data).hexdigest() == proof['atlas']['sha256']
actual = 65535 - np.frombuffer(data, '<u2').reshape(2048, 4096)[1024:2048, 2048:3072]
delta = np.abs(actual.astype('i4') - reference)
shared = (actual != 0) & (reference != 0)
regions = {}
for event in np.unique(owners):
    own = owners == event
    common = shared & own
    regions[int(event)] = dict(shared=int(common.sum()), withinOne=int((common & (delta <= 1)).sum()),
        overTwo=int((common & (delta > 2)).sum()), maximum=int(delta[common].max(initial=0)),
        nativeOnly=int((own & (actual == 0) & (reference != 0)).sum()))
assert sum(value['overTwo'] for value in regions.values()) == proof['atlasComparison'][1]['overTwo']
(out / 'nvidia-atlas-residual-by-caster.json').write_text(json.dumps(regions, indent=2) + '\n')
print(json.dumps(regions))
