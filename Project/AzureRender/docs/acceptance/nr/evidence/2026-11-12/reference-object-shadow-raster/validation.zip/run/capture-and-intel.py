from pathlib import Path
import json
import os
import subprocess
import sys
import time


out = Path(__file__).resolve().parent
diagnostic = out.parent / '20261112-041837-reference-object-shadow-raster-capture-60f161'
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def run(folder, label, script, *args):
    command = [sys.executable, str(folder / script), *args]
    execution = shared.maintenance.guarded_run(folder.parents[1], folder.name, command, 650)
    (folder / (label + '-execution.json')).write_text(json.dumps(execution, indent=2) + '\n')
    print(json.dumps(execution), flush=True)
    return execution['status'] == 'exited' and execution['exitCode'] == 0


token = sys.argv[1]
deadline = time.monotonic() + 1200
while time.monotonic() < deadline:
    try:
        state = json.loads((shared.DEFAULT_QUEUE / 'current.json').read_text())
    except (OSError, ValueError):
        time.sleep(1)
        continue
    if state.get('token') != token or state.get('state') == 'released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed GPU window has not opened')

for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES', 'VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key, None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LAYER_VALIDATE_SYNC='1')
with shared.lease(shared.DEFAULT_QUEUE, '01a1c099-8121-7be3-b0b8-7af2f9a06b2a',
        'quality-reference-object-shadow-raster-source-and-intel', out):
    os.environ['VK_LOADER_DRIVERS_SELECT'] = '*nv-vk64*'
    source_ok = run(diagnostic, 'capture-source', 'capture.py')
    os.environ['VK_LOADER_DRIVERS_SELECT'] = '*igvk64*'
    tests_ok = run(out, 'release-intel-gpu-tests', 'verify-build.py', 'Release', 'intel')
    intel_ok = run(out, 'release-intel-capture', 'capture-hair-visibility.py', 'Release', 'intel')
    if intel_ok:
        subprocess.run([sys.executable, str(out / 'compact-capture.py'), 'release-intel-frames'], check=True)
    assert source_ok and tests_ok and intel_ok, dict(source=source_ok, tests=tests_ok, capture=intel_ok)
