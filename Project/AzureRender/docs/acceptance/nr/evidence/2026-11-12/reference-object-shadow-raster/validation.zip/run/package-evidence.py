from hashlib import sha256
from pathlib import Path
import json
import zipfile


out = Path(__file__).resolve().parent
root = out.parents[2]
diagnostic = out.parent / '20261112-041837-reference-object-shadow-raster-capture-60f161'
prior = out.parent / '20261112-032619-native-object-record-calibration-19d2f9'
target = root / 'docs/acceptance/nr/evidence/2026-11-12/reference-object-shadow-raster'


def read(folder, name):
    return json.loads((folder / name).read_text(encoding='utf-8-sig'))


def digest(data):
    return sha256(data).hexdigest()


labels = tuple(f'{configuration}-{device}' for configuration in ('release', 'debug') for device in ('nvidia', 'intel'))
captures = {name: read(out, name + '-results.json') for name in labels}
for name, case in captures.items():
    previous = read(prior, name + '-results.json')
    assert case['validationClean'] and case['allocatorZero'], name
    for field in ('referenceDepthSha256', 'referenceNormalsSha256', 'objectIdsSha256'):
        assert case[field] == previous[field], (name, field)
    for region, pixels in (('hair', 17017), ('receiver', 49384)):
        data = case[region]
        assert data['pixels'] == pixels and data['baselineOverOne'] == previous[region]['overOne'], (name, region)
        assert data['baselineOverOne'] - data['closed'] + data['introduced'] == data['overOne'], (name, region)
    if name.endswith('-nvidia'):
        assert case['hair']['overOne'] == 0 and case['hair']['maximum'] <= 1, name
configurations = read(out, 'cross-configuration.json')
assert all(all(configurations[device].values()) for device in ('nvidia', 'intel')) and configurations['sceneControlsExact']
original = read(out, 'default-four-results.json')
assert original['allExact'] and original['depthCaptureAbsent'] and original['validationClean'] and original['allocatorZero']
builds = {key: read(out, key + '-verification.json') for key in ('release', 'debug', *(name + '-gpu' for name in labels))}
assert all(not value['ctestExit'] and value['shaderCount'] == 891 for value in builds.values())
assert len({json.dumps(value['changedShaders'], sort_keys=True) for value in builds.values()}) == 1
assert set(builds['release']['changedShaders']) == {'screen_object_visibility.frag.spv', 'shadow.vert.spv', 'shadow_compute.vert.spv'}
for configuration in ('release', 'debug'):
    execution = read(out, configuration + '-build-execution.json')
    assert execution['status'] == 'exited' and execution['exitCode'] == 0
isolation = read(out, 'atlas-caster-isolation.json')
assert isolation['actual']['overOne'] == 182 and isolation['hair']['maximum'] == 0 and isolation['hair']['closed'] == 182
proof = read(diagnostic, 'shadow-raster-gpu-proof.json')
assert all(proof[name] for name in ('inverseExact', 'projectionExact', 'lightExact', 'casterClipExact', 'casterOriginExact'))
assert proof['vertices'] == 11564 and proof['visibility']['sha256'] == captures['release-nvidia']['visibilitySha256']
assert proof['atlas']['sha256'] == proof['atlasComparison'][1]['sha256']
assert proof['debugMessages'] == []
replay = read(diagnostic, 'capture-replay-execution.json')
assert replay['status'] == 'exited' and replay['exitCode'] == 0
residuals = {device: {kind: read(out, f'release-{device}-{kind}-residual.json') for kind in ('color', 'receiver')}
    for device in ('nvidia', 'intel')}
for device, residual in residuals.items():
    residual['color'].pop('points')
    residual['color']['details'] = f'run/release-{device}-color-residual.json'
archive = out / 'validation-pending.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as writer:
    def add(path, prefix='run'):
        base = out if prefix == 'run' else diagnostic
        writer.write(path, prefix + '/' + path.relative_to(base).as_posix())

    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.json', '.xml', '.log') and not path.name.startswith('first-complete-'):
            add(path)
    for group in isolation:
        for name in ('calibration.json', 'command.json', f'nvidia-{group}-result.json', f'nvidia-{group}-rg8.bin'):
            add(out / group / name)
    for label in labels:
        folder = out / (label + '-frames')
        for name in ('capture_manifest.json', 'gpu_capabilities.json', 'reference-planes.json'):
            add(folder / name)
        if label.startswith('release-'):
            add(folder / 'reference-planes.zip')
    for configuration in ('release', 'debug'):
        folder = out / ('scene-control-' + configuration)
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix in ('.json', '.log', '.gltf', '.azurelevel', '.azureproject'):
                add(path)
        add(folder / 'config/reference-views.json')
        for mode in ('objects', 'calibrated', 'moved', 'light', 'light-calibrated', 'inputs', 'neutral'):
            add(folder / mode / 'capture_manifest.json')
            if mode != 'inputs':
                add(folder / mode / 'reference-object-visibility-rg8.bin')
    add(out / 'default-four-frames/capture_manifest.json')
    for name in ('shadow-raster-gpu-proof.json', 'native-record-gpu-proof.json', 'recorded-parameters.json',
            'parameters.bin', 'caster-parameters.bin', 'caster-vertices.zlib', 'caster-indices.zlib', 'report.json',
            'request.json', 'capture.py', 'renderdoc-worker.py', 'command.json', 'capture-source-execution.json',
            'capture-replay-execution.json', 'renderdoc.log'):
        add(diagnostic / name, 'capture-source')
    for path in sorted(diagnostic.glob('*first*')):
        if path.is_file() and path.suffix in ('.json', '.log'):
            add(path, 'capture-source')
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    contents = {name: digest(reader.read(name)) for name in reader.namelist()}
assert archive.stat().st_size <= 8 * 1024 * 1024
result = dict(status='qualified-reference-object-shadow-raster', overall='failed-user-review', baseCommit='34d8e9a',
    sceneRendererApiVersion=15, acceptedMaximumByteError=1, builds=builds, captures=captures, crossConfiguration=configurations,
    originalFour=original, casterIsolation=isolation, gpuProof=proof, residuals=residuals,
    atlasResidualByCaster=read(out, 'nvidia-atlas-residual-by-caster.json'), layouts=read(out, 'spirv-raster-layout.json'),
    debugBudget=read(out, 'debug-link-budget-preparation.json'),
    archive=dict(bytes=archive.stat().st_size, sha256=digest(archive.read_bytes()), files=len(contents), contents=contents))
target.mkdir(parents=True, exist_ok=True)
assert not (target / 'validation.zip').exists() and not (target / 'results.json').exists()
archive.rename(target / 'validation.zip')
(target / 'results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in result['archive'].items() if key != 'contents'}))
