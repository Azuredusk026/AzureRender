from pathlib import Path
import json
import os
import sys

out=Path(__file__).resolve().parent
root=out.parents[1]
main=Path('D:/Projects/FYP/Project/AzureRender/build')
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0,str(main.parent/'tools'))
import shared_resources as shared
path=Path('D:/Projects/FYP-coordination/quality-claim.json')
claim=json.loads(path.read_text(encoding='utf-8'))
assert claim['threadId']==owner and claim['lastCommit']=='bc12f326f258e6dc92fc3fcafef205c52f1be08d'
assert claim['state']=='native-object-record-calibration-four-frame-regression'
old_main=claim['inputLease']
old_local=claim['localInputLease']

def prior_inputs(build,tokens):
    with shared.maintenance.database(build,True) as db:
        records=shared.maintenance.rows(db)
    assert all(records[token]['owner']==owner for token in tokens)
    return [name for token in tokens for name in records[token]['inputs']]

local_inputs=list(dict.fromkeys(prior_inputs(root,old_local)+['20261112-032619-native-object-record-calibration-19d2f9',
    '20261112-033450-native-object-record-source-capture-071c26']))
main_inputs=list(dict.fromkeys(prior_inputs(main,old_main)))
local=shared.acquire_inputs(root,out,local_inputs,owner)
try:
    native=shared.acquire_inputs(main,out,main_inputs,owner)
except Exception:
    shared.release_inputs(root,local,owner)
    raise
base='34d8e9afb69c3c09a111a7ec662ec2aa13099b5d'
claim.update(state='reference-object-shadow-raster-caster-isolation',taskPath=str(out),inputLease=[native],
    localInputLease=[local],nativeCaptureLease=native,lastCommit=base,
    pendingCommand='Run Vulkan filter controls with D16 caster groups, then qualify native ordered atlas vertex projection',
    ownedFiles=['shaders/shadow.vert','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp',
        'src/render/ObjectShadow.hpp','src/render/SceneReferenceObjectVisibility.hpp'],additionalTaskPaths=[])
(out/'task-card.json').write_text(json.dumps(dict(local=local,main=native,sourceBase=base,plannedBytes=536870912,
    localInputs=local_inputs,mainInputs=main_inputs),indent=2)+'\n')
temporary=path.with_name(path.name+'.nr-quality-new')
with temporary.open('x',encoding='utf-8') as stream:
    json.dump(claim,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
os.replace(temporary,path)
for token in old_main:shared.release_inputs(main,token,owner)
for token in old_local:shared.release_inputs(root,token,owner)
print(json.dumps(dict(local=local,main=native,output=str(out))))
