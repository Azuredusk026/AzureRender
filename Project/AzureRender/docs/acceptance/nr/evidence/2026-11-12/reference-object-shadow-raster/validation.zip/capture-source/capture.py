from hashlib import sha256
from pathlib import Path
import json
import numpy as np
import zlib
import os
import shutil
import struct
import subprocess
import sys


out=Path(__file__).resolve().parent
root=out.parents[2]
stage=out.parent/'20261112-040725-reference-object-shadow-raster-2c9e58'
sys.path.insert(0,str(root/'tools/native_render'))
from renderdoc_capture import fingerprint


normal=json.loads((stage/'release-nvidia-results.json').read_text())
argv=json.loads((stage/'release-nvidia-command.json').read_text())
argv.remove('--disable-compute-skinning')
argv.remove('--disable-bindless')
source=Path(argv[0])
source_identity=fingerprint(source)
assert source_identity['sha256']==json.loads((stage/'release-verification.json').read_text())['playerSha256']
argv[argv.index('--capture-dir')+1]=str(out/'host-frames')
argv[argv.index('--capture-frames')+1]='4'
argv+=['--runtime-report',str(out/'host-runtime.json')]
shader=source.parent/'shaders/screen_object_visibility.frag.spv'
expected={key:normal[field] for key,field in [('depth','referenceDepthSha256'),('normals','referenceNormalsSha256'),
    ('objectIds','objectIdsSha256'),('visibility','visibilitySha256')]}
job=dict(operation='capture',source=source_identity,working_directory=str(source.parent),arguments=argv[1:],output=str(out),
    frame=3,timeout=300,nativeRenderTools=str(root/'tools/native_render'),shaderSha256=sha256(shader.read_bytes()).hexdigest(),
    expectedSha256=expected,layerPath='D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64;D:/Tools/VulkanSDK/1.4.350.0/Bin')
if '--replay-only' in sys.argv:
    original=out/'capture-first-report.json'
    if not original.exists():
        shutil.copyfile(out/'report.json',original)
        shutil.copyfile(out/'process.log',out/'capture-first-process.log')
    job['captureReceipt']=json.loads(original.read_text())['captureReceipt']
    assert fingerprint(job['captureReceipt']['capture']['path'])==job['captureReceipt']['capture']
request=out/'request.json'
request.write_text(json.dumps(job,indent=2)+'\n')
environment=os.environ.copy()
for key in ('VK_LAYER_PATH','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES','VK_DRIVER_FILES','VK_ICD_FILENAMES'):
    environment.pop(key,None)
environment.update(AZURE_OBJECT_VISIBILITY_CAPTURE=str(request),VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'renderdoc-worker.py')]
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (out/'renderdoc.log').open('wb') as log:
    process=subprocess.run(command,env=environment,cwd=out,startupinfo=startup,stdout=log,stderr=subprocess.STDOUT,timeout=520)
report=json.loads((out/'report.json').read_text())
assert process.returncode==0 and report['status']=='qualified',report
assert fingerprint(source)==source_identity
host=out/'host-frames'
assert all(sha256((host/f'frame_{i:06d}.png').read_bytes()).hexdigest()==normal['colors'][i] for i in range(3))
capture=json.loads((host/'capture_manifest.json').read_text())['referenceSceneDepth']
assert sha256((host/capture['objectVisibility']).read_bytes()).hexdigest()==normal['visibilitySha256']
data=(out/'parameters.bin').read_bytes()
view=struct.unpack_from('<20f4I',data)
assert view[20:]==(1,1,1,0)
projection=struct.unpack_from('<28f',data,96)
parameters=dict(clipToWorld=list(view[:16]),reconstruction=list(view[16:20]),control=list(view[20:]),
    record=dict(projection=list(projection[:16]),lightDirection=list(projection[16:19]),lightBias=projection[19],
        normalBias=projection[20],filterRadiusUv=list(projection[21:23]),minimumReceiverDepth=projection[23],
        atlasRect=list(projection[24:28])))
(out/'recorded-parameters.json').write_text(json.dumps(parameters,indent=2)+'\n')
record_stage=out.parent/'20261112-032619-native-object-record-calibration-19d2f9'
source=json.loads((record_stage/'native-object-record-source.json').read_text())
record=source['record']
assert data[:64]==struct.pack('<16f',*source['camera']['clipToWorld'])
assert data[96:160]==struct.pack('<16f',*record['referenceToUnit'])
assert data[160:172]==struct.pack('<3f',*record['lightDirection'])

assert parameters['record']['atlasRect']==[.5,.5,.25,.5]
proof=dict(capture=report['captureReceipt']['capture'],event=report['event'],atlas=report['sources']['atlas'],
    visibility=report['sources']['visibility'],control=parameters['control'],inverseExact=True,projectionExact=True,lightExact=True,
    projectionSha256=sha256(data[96:160]).hexdigest(),lightSha256=sha256(data[160:172]).hexdigest(),
    inverseSha256=sha256(data[:64]).hexdigest(),debugMessages=report['debugMessages'])
(out/'native-record-gpu-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
native_source=out.parent/'20261112-024632-native-atlas-and-receiver-producers-d5e705'
native_projection=json.loads((native_source/'native-atlas-projection-source.json').read_text())
raster=(out/'caster-parameters.bin').read_bytes()
assert sha256(raster).hexdigest()==report['caster']['parametersSha256']
assert raster[:64]==struct.pack('<16f',*native_projection['rasterClipColumns'])
assert raster[112:124]==struct.pack('<3f',*native_projection['absoluteCameraOrigin'])
gpu=report['caster']
record=json.loads((native_source/'native-atlas-producers/native-atlas-producers.json').read_text())['stages']['237']['postVertex']
source_folder=native_source/'native-atlas-producers'
native_positions=np.ndarray((record['count'],4),'<f4',
    buffer=zlib.decompress((source_folder/record['vertices']['path']).read_bytes()),strides=(record['stride'],4))
native_indices=np.frombuffer(zlib.decompress((source_folder/record['indices']['path']).read_bytes()),
    {2:'<u2',4:'<u4'}[record['indexStride']]).reshape(-1,3).astype('i8')+record['baseVertex']
live_positions=np.ndarray((gpu['vertexCount'],4),'<f4',buffer=zlib.decompress((out/'caster-vertices.zlib').read_bytes()),
    strides=(gpu['vertexStride'],4))
live_indices=np.frombuffer(zlib.decompress((out/'caster-indices.zlib').read_bytes()),
    {2:'<u2',4:'<u4'}[gpu['indexStride']]).reshape(-1,3).astype('i8')+gpu['baseVertex']
mapping=np.unique(np.column_stack((native_indices[:,[2,1,0]].reshape(-1),live_indices.reshape(-1))),axis=0)
assert len(mapping)==11564 and all(len(np.unique(mapping[:,i]))==len(mapping) for i in (0,1))
expected=native_positions[mapping[:,0]].copy()
expected[:,1]*=-1
expected[:,2]=expected[:,3]-expected[:,2]
delta=np.abs(expected.astype('f8')-live_positions[mapping[:,1]])
native_atlas=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/native-t2.bin')
source_bytes=native_atlas.read_bytes()
assert sha256(source_bytes).hexdigest()=='86daee0e01e9c33207679b094bdf5cf31a26d2f93754f11abf6c44df1faecf57'
baseline_atlas=out.parent/'20261112-033450-native-object-record-source-capture-071c26/atlas.bin'
baseline_bytes=baseline_atlas.read_bytes()
assert sha256(baseline_bytes).hexdigest()=='ee700ac4164ffd1923cc9ca1eaeddf27366213a4b8dc5cf0e17fa154328f781e'
native=np.frombuffer(source_bytes,'<u2')
atlas=[]
for name,payload in [('baseline',baseline_bytes),('calibrated',(out/'atlas.bin').read_bytes())]:
    values=65535-np.frombuffer(payload,'<u2')
    common=(native!=0)&(values!=0)
    error=np.abs(native[common].astype('i4')-values[common])
    atlas.append(dict(name=name,sha256=sha256(payload).hexdigest(),shared=int(common.sum()),withinOne=int((error<=1).sum()),
        overTwo=int((error>2).sum()),maximum=int(error.max()),actualOnly=int(((native==0)&(values!=0)).sum()),
        nativeOnly=int(((native!=0)&(values==0)).sum())))
proof.update(caster=gpu,casterClipExact=True,casterOriginExact=True,vertexExact=int(np.all(delta==0,axis=1).sum()),
    vertices=len(mapping),maximumVertexComponentError=delta.max(axis=0).tolist(),atlasComparison=atlas)
(out/'shadow-raster-gpu-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ('event','sources','parameters','debugMessages')}))
