from hashlib import sha256
from pathlib import Path
import json
import sys
import zipfile
import zlib

import numpy as np


out = Path(__file__).resolve().parent
device = sys.argv[1]
assert device in ('nvidia', 'intel')
label = 'release-' + device
numeric = out.parent / '20261110-003435-visibility-numeric-contract-4f95e7'
normal = out.parent / '20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
native = out.parent / '20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'


def packed(source, expected_sha, dtype, shape):
    raw = source.read_bytes()
    assert sha256(raw).hexdigest() == expected_sha
    return np.frombuffer(raw, dtype).reshape(shape)


shape = (1440, 2560)
config = json.loads((numeric / 'hair-calibration.json').read_text())
depth = packed(Path(config['depth']), '02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb', '<u4', shape)
normals = packed(Path(config['normals']), '63731d707e7ba30d9417049c8148b9bd2167208e435e8d9f0cc100a1fd03e095', '<u4', shape)
receipt = json.loads((native / 'native-atlas-producers.json').read_text())
assert receipt['status'] == 'qualified'
owners = np.zeros((310, 290), 'u2')
previous = np.zeros_like(owners, dtype='<u4')
for event, source in receipt['receiverNormal']['stages'].items():
    file = source['crop']
    raw = (native / file['path']).read_bytes()
    assert sha256(raw).hexdigest() == file['sha256']
    current = np.frombuffer(zlib.decompress(raw), '<u4').reshape(owners.shape)
    owners[current != previous] = int(event)
    previous = current
assert np.array_equal(previous, normals[1000:1310, 1140:1430])
x, y = np.fromfile(numeric / 'receiver-queries.bin', '<f4').reshape(-1, 4)[:, :2].astype('i4').T
hx, hy = np.fromfile(normal / 'queries.bin', '<f4').reshape(-1, 4)[:, :2].astype('i4').T
hair = np.isin(y * 2560 + x, hy * 2560 + hx)
reference = np.fromfile(numeric / 'receiver-expected.bin', '<u4').astype('i4')
assert len(reference) == len(x) == 49384 and hair.sum() == 17017
frame = out / (label + '-frames')
case = json.loads((out / (label + '-results.json')).read_text())
manifest = json.loads((frame / 'capture_manifest.json').read_text())['referenceSceneDepth']
with zipfile.ZipFile(frame / 'reference-planes.zip') as archive:
    actual = {}
    for field, digest, dtype, dimensions in (
            ('raster', 'referenceDepthSha256', '<u4', shape),
            ('packedNormals', 'referenceNormalsSha256', '<u4', shape),
            ('objectVisibility', 'visibilitySha256', 'u1', (*shape, 2))):
        raw = archive.read(manifest[field])
        assert sha256(raw).hexdigest() == case[digest]
        actual[field] = np.frombuffer(raw, dtype).reshape(dimensions)
delta = np.abs(actual['objectVisibility'][y, x, 1].astype('i4') - reference)
depth_error = np.abs(actual['raster'][y, x].astype('i8') - depth[y, x])
normal_exact = actual['packedNormals'][y, x] == normals[y, x]
assert (delta > 1).sum() == case['receiver']['overOne']
owner = owners[y - 1000, x - 1140]


def region(mask):
    bad = mask & (delta > 1)
    same_depth = depth_error == 0
    return dict(pixels=int(mask.sum()), visibilityOverOne=int(bad.sum()), visibilityOver64=int((mask & (delta > 64)).sum()),
        depthExact=int((mask & same_depth).sum()), normalExact=int((mask & normal_exact).sum()),
        overOneBothExact=int((bad & same_depth & normal_exact).sum()), overOneOnlyDepthExact=int((bad & same_depth & ~normal_exact).sum()),
        overOneOnlyNormalExact=int((bad & ~same_depth & normal_exact).sum()), overOneNeitherExact=int((bad & ~same_depth & ~normal_exact).sum()))


report = dict(device=device, hair=region(hair), nonhair=region(~hair), nonhairByNativeNormalWriter={
    int(event): region(~hair & (owner == event)) for event in np.unique(owner) if np.any(~hair & (owner == event))})
(out / (label + '-receiver-residual.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ('device', 'hair', 'nonhair')}))
