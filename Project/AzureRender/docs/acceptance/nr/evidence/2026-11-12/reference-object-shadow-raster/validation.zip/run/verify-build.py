from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys


out=Path(__file__).resolve().parent
configuration=sys.argv[1]
assert configuration in ('Release','Debug')
prefix=configuration.lower()
build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
prior=out.parent/'20261111-232828-scene-reference-normal-60ddfa'/f'{prefix}-verification.json'
catalog={path.name:sha256(path.read_bytes()).hexdigest() for path in (build/'shaders').glob('*.spv')}
baseline=json.loads(prior.read_text())['sha256']
assert catalog.keys()==baseline.keys() and len(catalog)==891
changed={name:{'sourceSha256':baseline[name],'sha256':value} for name,value in catalog.items() if value!=baseline[name]}
new_shaders={'shadow.vert.spv','shadow_compute.vert.spv'}
assert changed.keys()==new_shaders|{'screen_object_visibility.frag.spv'},changed
prior_record=out.parent/'20261112-032619-native-object-record-calibration-19d2f9'
previous=json.loads((prior_record/f'{prefix}-verification.json').read_text())['changedShaders']
assert changed['screen_object_visibility.frag.spv']==previous['screen_object_visibility.frag.spv']
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
if len(sys.argv)>2:
    assert sys.argv[2] in ('nvidia','intel')
    prefix+='-'+sys.argv[2]+'-gpu'
    regex='^AzureRender[.](ScreenObjectVisibility(Gpu|ReferenceGpu)|ReferenceDepth(Coverage)?Gpu)$'
else:
    regex='^(AzureRender[.](ReferenceCameraView|ReferenceCameraBinding|ExtensionRegistry|ScreenObjectVisibility)|AzureEngine[.]ProjectReferenceViews)$'
command=[ctest,'--test-dir',str(build),'-R',regex,'--no-tests=error','--output-on-failure','--output-junit',str(out/(prefix+'-ctest.xml'))]
with (out/(prefix+'-ctest.log')).open('wb') as log:
    process=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
report=dict(configuration=configuration,shaderCount=len(catalog),changedShaders=changed,ctestCommand=command,
    ctestExit=process.returncode,playerSha256=sha256((build/'AzurePlayer.exe').read_bytes()).hexdigest())
(out/(prefix+'-verification.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
assert process.returncode==0,(out/(prefix+'-ctest.log')).read_text(errors='replace')
