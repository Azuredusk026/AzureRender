from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys
import zlib

import numpy as np

out=Path(sys.argv[1]).resolve(strict=True)
assert out.parent.name=='runs' and out.parent.parent.name=='build'
source=out.parent/'20261112-024632-native-atlas-and-receiver-producers-d5e705'
capture=out.parent/'20261112-013522-scene-visibility-atlas-source-33c6c3'
numeric=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
normal=out.parent/'20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
config=json.loads((numeric/'hair-calibration.json').read_text())
config.update(queries=str(normal/'queries.bin'),expected=str(normal/'expected.bin'))
expected=np.fromfile(config['expected'],'<u4').astype('i4')
assert len(expected)==17017
reference_atlas=Path(config['atlas']).read_bytes()
assert sha256(reference_atlas).hexdigest()=='86daee0e01e9c33207679b094bdf5cf31a26d2f93754f11abf6c44df1faecf57'
forward=(capture/'atlas.bin').read_bytes()
assert sha256(forward).hexdigest()=='ee700ac4164ffd1923cc9ca1eaeddf27366213a4b8dc5cf0e17fa154328f781e'
actual=(65535-np.frombuffer(forward,'<u2')).reshape(2048,4096)
reference=np.frombuffer(reference_atlas,'<u2').reshape(2048,4096)
tile=(slice(1024,2048),slice(2048,3072))
event_map={143:264,152:276,163:238,171:268,182:256,191:242,200:260,208:246,223:251,237:272}

def owner(label,forward):
    folder=source/f'{label}-atlas-producers'
    receipt=json.loads((folder/f'{label}-atlas-producers.json').read_text())
    assert receipt['status']=='qualified'
    last=np.zeros((1024,1024),'u2')
    previous=np.zeros((1024,1024),'u2')
    for event,stage in receipt['stages'].items():
        info=stage['tile']
        data=(folder/info['path']).read_bytes()
        assert sha256(data).hexdigest()==info['sha256']
        current=np.frombuffer(zlib.decompress(data),'<u2').reshape(1024,1024)
        if forward:current=65535-current
        last[current!=previous]=int(event)
        previous=current
    return last,previous

native_owner,native_tile=owner('native',False)
vulkan_owner,vulkan_tile=owner('vulkan',True)
assert np.array_equal(native_tile,reference[tile]) and np.array_equal(vulkan_tile,actual[tile])
groups=dict(actual=(),hair=(237,),cloth_one=(191,),cloth_two=(208,),other=tuple(key for key in event_map if key not in (191,208,237)),
    both_cloth=(191,208),reference=tuple(event_map))
reports={}
failed={}
scratch=out/'hybrid-atlas.bin'
for label,events in groups.items():
    mask=np.isin(native_owner,events)|np.isin(vulkan_owner,[event_map[key] for key in events])
    if label=='reference':mask=np.ones(mask.shape,'bool')
    atlas=actual.copy()
    atlas[tile][mask]=reference[tile][mask]
    payload=atlas.astype('<u2').tobytes()
    scratch.write_bytes(payload)
    folder=out/label
    folder.mkdir()
    path=folder/'calibration.json'
    path.write_text(json.dumps(dict(config,atlas=str(scratch),scope=label),indent=2)+'\n')
    command=[str(numeric/'calibration.exe'),str(path),str(numeric)]
    (folder/'command.json').write_text(json.dumps(command,indent=2)+'\n')
    with (folder/'process.log').open('wb') as log:
        process=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=100)
    result=json.loads((folder/f'nvidia-{label}-result.json').read_text())
    selected=np.fromfile(folder/f'nvidia-{label}-rg8.bin','u1').reshape(-1,2)
    assert result['zeroAllocator'] and not result['validationErrors'] and np.all(selected[:,0]==255)
    difference=np.abs(selected[:,1].astype('i4')-expected)
    failed[label]=difference>1
    assert process.returncode==int(failed[label].any())
    reports[label]=dict(replacedTexels=int((mask&(vulkan_tile!=native_tile)).sum()),atlasSha256=sha256(payload).hexdigest(),
        overOne=int(failed[label].sum()),maximum=int(difference.max()),closed=int((failed['actual']&~failed[label]).sum()),
        introduced=int((~failed['actual']&failed[label]).sum()))
assert reports['actual']['overOne']==182 and reports['reference']['overOne']==0
(out/'atlas-caster-isolation.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports))
