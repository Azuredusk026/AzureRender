param([ValidateSet('Release','Debug')][string]$Configuration)
$ErrorActionPreference='Stop'
$isolated=(Get-Item -LiteralPath $PSScriptRoot).Parent.Parent.Parent.FullName
Set-Location -LiteralPath $isolated
$key=$Configuration.ToLowerInvariant()
$env:TMP=Join-Path $PSScriptRoot 'tmp'
$env:TEMP=$env:TMP
$runtime=if($key -eq 'debug'){'/MDd'}else{'/MD'}
$source=Join-Path $PSScriptRoot 'material-layout.cpp'
$base=Join-Path $PSScriptRoot "material-layout-$key"
& tools/msvc_env.bat cl /nologo /utf-8 /std:c++20 /EHsc $runtime /Isrc /ID:/Tools/VulkanSDK/1.4.350.0/Include /ID:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/include "/Fo$base.obj" "/Fe$base.exe" $source *> "$base-compile.log"
if($LASTEXITCODE -ne 0){Get-Content -LiteralPath "$base-compile.log";throw "Material layout compilation failed"}
& "$base.exe" | Tee-Object -FilePath "$base-result.log"
if($LASTEXITCODE -ne 0){throw "Material layout probe failed"}

