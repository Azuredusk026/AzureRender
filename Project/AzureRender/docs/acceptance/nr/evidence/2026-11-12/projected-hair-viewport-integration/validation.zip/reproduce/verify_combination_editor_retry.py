from pathlib import Path
import json
import subprocess
import sys

run = Path(__file__).resolve().parent
proof = json.loads((run/'tested-tree.json').read_bytes())['resolvedTree']
for mode in ('build','cpu','gpu','reference','selection','four'):
    assert json.loads((run/f'combined-debug-{mode}-results.json').read_bytes())['tree'] == proof
subprocess.run([sys.executable,'-X','utf8','-B',str(run/'check_combination_debug.py'),'editor'],check=True,timeout=570)
result=json.loads((run/'combined-debug-editor-results.json').read_bytes())
assert result['tree']==proof and result['result']['tests']['AzureEngine.EditorPlayable']<240
print('Debug EditorPlayable passed with original command and timeout',flush=True)
