import json
from pathlib import Path
import subprocess
import sys

run=Path(__file__).resolve().parent
for mode in ('gpu','reference','selection','four','editor'):
    subprocess.run([sys.executable,'-X','utf8','-B',str(run/'check_combination_debug.py'),mode],
        check=True,timeout=970)
    result=json.loads((run/f'combined-debug-{mode}-results.json').read_bytes())
    assert result['tree']==json.loads((run/'tested-tree.json').read_bytes())['resolvedTree']
    print(mode,'passed',flush=True)
