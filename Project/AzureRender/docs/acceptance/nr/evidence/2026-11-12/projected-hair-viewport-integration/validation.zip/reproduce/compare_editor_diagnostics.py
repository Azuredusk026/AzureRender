from datetime import datetime
from pathlib import Path
from statistics import median
import json
import os
import sys
import xml.etree.ElementTree as ET


source = Path(os.environ['LOCALAPPDATA'])/'AzureRender/editor/logs/azurerender.log.jsonl'
rows = []
with source.open(encoding='utf-8') as stream:
    for line in stream:
        try:
            rows.append(json.loads(line, strict=False))
        except ValueError:
            continue
for name in sys.argv[1:]:
    file = Path(name)
    case = ET.parse(file).getroot()
    start = datetime.fromisoformat(case.attrib['timestamp']).timestamp()*1000
    duration = float(case.find('testcase').attrib['time'])
    events = [line for line in rows if start <= line['timestamp_ms'] < start+1000*duration+1000]
    scenes = [line['timestamp_ms'] for line in events if line['message']=='Opened scene: editor-exploration']
    intervals = [second-first for first,second in zip(scenes,scenes[1:]) if second-first>100]
    print(json.dumps({'xml':str(file),'started':case.attrib['timestamp'],'durationSeconds':duration,
        'events':len(events),'sceneOpens':len(scenes),'sceneIntervalMedianMs':median(intervals) if intervals else None,
        'sceneIntervalMaxMs':max(intervals) if intervals else None,
        'startup':[line['message'] for line in events if line['subsystem']=='startup'],
        'last':events[-1]['message'] if events else None}, ensure_ascii=False))

