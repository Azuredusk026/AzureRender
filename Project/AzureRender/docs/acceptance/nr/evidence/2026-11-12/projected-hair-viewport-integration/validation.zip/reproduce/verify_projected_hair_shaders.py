from hashlib import file_digest, sha256
import json
from pathlib import Path
from struct import pack, unpack


job = Path(__file__).resolve().parent
main = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261112-011326-handoff-final-regression-e2e260')
prior = Path(json.loads((main / 'quality-hair-boundary-combination-run.json').read_bytes())['path'])
proof = json.loads((main / 'quality-projected-hair-combined-candidate.json').read_bytes())
reference = json.loads((main / 'quality-projected-hair-production-preflight.json').read_bytes())
expected = reference['changedShaders']
assert len(expected) == 32 and all(name.startswith('mesh') for name in expected)


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def quality_binding_fingerprint(code):
    assert len(code) % 4 == 0
    fmt = f'<{len(code) // 4}I'
    words = list(unpack(fmt, code))
    assert words[0] == 0x07230203
    names = {}
    decorations = {}
    cursor = 5
    while cursor < len(words):
        count, opcode = words[cursor] >> 16, words[cursor] & 65535
        assert count > 0 and cursor + count <= len(words)
        if opcode == 5:
            name = pack(f'<{count - 2}I', *words[cursor + 2:cursor + count]).split(b'\0', 1)[0]
            names[words[cursor + 1]] = name.decode()
        if opcode == 71 and count == 4 and words[cursor + 2] == 33:
            target = words[cursor + 1]
            assert target not in decorations
            decorations[target] = cursor + 3
        cursor += count
    named_bindings = {names[target]: index for target, index in decorations.items() if target in names}
    rewritten = {}
    for name, quality, integrated in (('referenceObjectVisibility', 45, 50), ('referenceObjectIds', 46, 51)):
        slot = named_bindings[name]
        assert words[slot] == integrated
        words[slot] = quality
        rewritten[name] = {'integrated': integrated, 'quality': quality}
    return sha256(pack(fmt, *words)).hexdigest(), rewritten


results = {}
for configuration, receipt, build_name in (
        ('release', 'combined-build-results.json', 'catalog-standard'),
        ('debug', 'combined-debug-build-results.json', 'catalog-standard-debug')):
    build = job.parents[1] / build_name
    baseline = json.loads((prior / receipt).read_bytes())['result']
    candidate = json.loads((job / receipt).read_bytes())
    assert candidate['tree'] == proof['resolvedTree']
    data = candidate['result']
    before, after = baseline['programs'], data['programs']
    assert len(before) == len(after) == data['shaderCount'] == 896 and set(before) == set(after)
    changed = {name: {'before': before[name], 'after': fingerprint} for name, fingerprint in after.items()
               if fingerprint != before[name]}
    assert set(changed) == set(expected)
    exact = {}
    binding_comparison = {}
    for name, actual in changed.items():
        path = build / 'shaders' / name
        assert digest(path) == actual['after']
        if name.startswith('mesh_object'):
            normalized, rewrites = quality_binding_fingerprint(path.read_bytes())
            assert actual != expected[name] and normalized == expected[name]['after'], name
            binding_comparison[name] = {'normalizedSha256': normalized, 'bindings': rewrites}
        else:
            assert actual == expected[name], name
            exact[name] = actual['after']
    assert len(exact) == len(binding_comparison) == 16
    assert set(baseline['binaries']) <= set(data['binaries'])
    binaries = {name: {'before': baseline['binaries'][name], 'after': fingerprint}
                for name, fingerprint in data['binaries'].items()
                if name in baseline['binaries'] and fingerprint != baseline['binaries'][name]}
    assert {'AzureRender', 'AzurePlayer'} <= binaries.keys()
    for name, fingerprint in data['binaries'].items():
        assert digest(build / (name + '.exe')) == fingerprint
    results[configuration] = {
        'shaderCount': len(after), 'changedPrograms': changed, 'qualityExact': exact,
        'qualityWithIntegratedBindings': binding_comparison, 'changedBinaries': binaries,
        'addedBinaries': sorted(set(data['binaries']) - set(baseline['binaries'])),
    }
for key in ('changedPrograms', 'qualityExact', 'qualityWithIntegratedBindings'):
    assert results['release'][key] == results['debug'][key]
(job / 'combined-projected-hair-shader-delta.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: {'shaders': value['shaderCount'], 'qualityExact': len(value['qualityExact']),
    'qualityWithIntegratedBindings': len(value['qualityWithIntegratedBindings']),
    'changedBinaries': len(value['changedBinaries'])} for key, value in results.items()}, indent=2))

