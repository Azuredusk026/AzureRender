#include "assets/GltfLoader.hpp"
#include <cstddef>
#include <iostream>

#ifdef _DEBUG
static_assert(sizeof(AssetMaterial) == 4504);
static_assert(offsetof(AssetMaterial, projectedHairRamp) == 3344);
static_assert(sizeof(decltype(AssetMaterial::projectedHairRamp)) == 384);
static_assert(offsetof(AssetMaterial, preparedPixels) == 4296);
static_assert(offsetof(AssetMaterial, hairPointMipReferenceNormal) == 4294);
static_assert(offsetof(AssetMaterial, geometricReferenceNormal) == 4293);
#else
static_assert(sizeof(AssetMaterial) == 3928);
static_assert(offsetof(AssetMaterial, projectedHairRamp) == 2824);
static_assert(sizeof(decltype(AssetMaterial::projectedHairRamp)) == 360);
static_assert(offsetof(AssetMaterial, preparedPixels) == 3720);
static_assert(offsetof(AssetMaterial, hairPointMipReferenceNormal) == 3718);
static_assert(offsetof(AssetMaterial, geometricReferenceNormal) == 3717);
#endif

int main() {
    std::cout << sizeof(AssetMaterial) << ' ' << offsetof(AssetMaterial, preparedPixels) << ' '
              << offsetof(AssetMaterial, hairPointMipReferenceNormal) << ' '
              << offsetof(AssetMaterial, projectedHairRamp) << ' '
              << sizeof(decltype(AssetMaterial::projectedHairRamp)) << ' '
              << offsetof(decltype(AssetMaterial::projectedHairRamp), axisDiagonalPrimaryTextureFootprint) << '\n';
}