from pathlib import Path
import subprocess
import sys
run=Path(__file__).resolve().parent
for script in ('check_combination.py','check_combination_debug.py'):
    subprocess.run([sys.executable,'-X','utf8','-B',str(run/script),'build'],
        check=True,timeout=1350)
