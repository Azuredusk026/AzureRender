from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import traceback
import zlib

import renderdoc as rd

request=json.loads(Path(os.environ['AZURE_ATLAS_PRODUCER_REQUEST']).read_text(encoding='utf-8-sig'))
output=Path(request['output'])
capture=rd.OpenCaptureFile()
controller=None
receipt={'status':'failed'}
draws=(143,152,163,171,182,191,200,208,223,237)

def emit(path,data):
    (output/path).write_bytes(data)
    return dict(path=path,bytes=len(data),sha256=sha256(data).hexdigest())

def fields(obj,names):
    return {name:str(getattr(obj,name)) for name in names}

def event_stage(pipeline,event,stage):
    reflection=pipeline.GetShaderReflection(stage)
    if not reflection:return None
    prefix=f'{event}-{stage}'
    program=bytes(reflection.rawBytes)
    disassembly=controller.DisassembleShader(pipeline.GetGraphicsPipelineObject(),reflection,'')
    constants={}
    for index,block in enumerate(reflection.constantBlocks):
        binding=pipeline.GetConstantBlock(stage,index,0).descriptor
        if binding.resource==rd.ResourceId.Null():continue
        data=bytes(controller.GetBufferData(binding.resource,binding.byteOffset,binding.byteSize))
        constants[block.fixedBindNumber]=dict(resource=str(binding.resource),offset=binding.byteOffset,
            **emit(f'{prefix}-b{block.fixedBindNumber}.bin',data))
    sources={reflection.readOnlyResources[binding.access.index].fixedBindNumber:str(binding.descriptor.resource)
        for binding in pipeline.GetReadOnlyResources(stage)}
    return dict(program=emit(prefix+'.dxbc',program),assembly=emit(prefix+'.asm',disassembly.encode('utf-8')),
        sources=sources,constants=constants)

def tile(data):
    pitch=4096*2
    return b''.join(data[y*pitch+2048*2:y*pitch+3072*2] for y in range(1024,2048))

try:
    assert capture.OpenFile(request['capture'],'',None)==rd.ResultCode.Succeeded
    gpus=[gpu for gpu in capture.GetAvailableGPUs() if gpu.vendor==rd.GPUVendor.nVidia and rd.GraphicsAPI.D3D11 in gpu.apis]
    assert len(gpus)==1
    options=rd.ReplayOptions()
    options.forceGPUVendor=gpus[0].vendor
    options.forceGPUDeviceID=gpus[0].deviceID
    status,controller=capture.OpenCapture(options,None)
    assert status==rd.ResultCode.Succeeded and controller
    properties=controller.GetAPIProperties()
    assert properties.vendor==options.forceGPUVendor and properties.pipelineType==rd.GraphicsAPI.D3D11 and not properties.degraded
    controller.SetFrameEvent(699,True)
    pipeline=controller.GetPipelineState()
    reflection=pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
    sources={reflection.readOnlyResources[binding.access.index].fixedBindNumber:binding.descriptor.resource
        for binding in pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel)}
    resource=sources[2]
    assert str(resource)=='ResourceId::158089'
    uses=[(event.eventId,str(event.usage)) for event in controller.GetUsage(resource) if event.eventId<=699]
    assert tuple(event for event,usage in uses if usage=='ResourceUsage.DepthStencilTarget')==draws
    final=bytes(controller.GetTextureData(resource,rd.Subresource()))
    assert len(final)==4096*2048*2 and sha256(final).hexdigest()==request['atlasSha256']
    receipt.update(resource=str(resource),device=gpus[0].name,uses=uses,atlasSha256=sha256(final).hexdigest(),stages={})
    for event in (125,*draws):
        controller.SetFrameEvent(event,True)
        raw=bytes(controller.GetTextureData(resource,rd.Subresource()))
        assert len(raw)==len(final)
        crop=tile(raw)
        entry=dict(tile=emit(f'{event}-tile.zlib',zlib.compress(crop,6)),tileSha256=sha256(crop).hexdigest())
        receipt['stages'][str(event)]=entry
        if event==125:
            assert not any(crop)
            continue
        pipeline=controller.GetPipelineState()
        assert pipeline.GetDepthTarget().resource==resource
        state=controller.GetD3D11PipelineState()
        viewport=pipeline.GetViewport(0)
        entry.update(viewport=fields(viewport,('x','y','width','height','minDepth','maxDepth')),
            rasterizer=fields(state.rasterizer.state,('depthBias','slopeScaledDepthBias','depthBiasClamp','cullMode','scissorEnable')),
            depth=fields(state.outputMerger.depthStencilState,('depthEnable','depthWrites','depthFunction')))
        if event in (143,223,237):
            entry['vertex']=event_stage(pipeline,event,rd.ShaderStage.Vertex)
            entry['pixel']=event_stage(pipeline,event,rd.ShaderStage.Pixel)
        if event==237:
            mesh=controller.GetPostVSData(0,0,rd.MeshDataStage.VSOut)
            assert mesh.numIndices==43044 and mesh.indexByteStride in (2,4) and mesh.vertexByteStride>=16
            index_data=bytes(controller.GetBufferData(mesh.indexResourceId,mesh.indexByteOffset,mesh.numIndices*mesh.indexByteStride))
            indices=struct.unpack('<'+('I' if mesh.indexByteStride==4 else 'H')*mesh.numIndices,index_data)
            vertex_count=max(indices)+mesh.baseVertex+1
            assert vertex_count>0 and min(indices)+mesh.baseVertex>=0
            vertices=bytes(controller.GetBufferData(mesh.vertexResourceId,mesh.vertexByteOffset,vertex_count*mesh.vertexByteStride))
            assert len(vertices)==vertex_count*mesh.vertexByteStride
            entry['postVertex']=dict(count=vertex_count,stride=mesh.vertexByteStride,indexStride=mesh.indexByteStride,
                baseVertex=mesh.baseVertex,vertices=emit('237-post-vertices.zlib',zlib.compress(vertices,6)),
                indices=emit('237-post-indices.zlib',zlib.compress(index_data,6)))
    assert crop==tile(final)
    normal=sources[6]
    assert str(normal)=='ResourceId::141952'
    normal_uses=[(event.eventId,str(event.usage)) for event in controller.GetUsage(normal) if event.eventId<=699]
    normal_events=tuple(event for event,usage in normal_uses if usage=='ResourceUsage.ColorTarget')
    assert normal_events==(296,310,328,345,363,377,391,404,422,440,460,478)
    receipt['receiverNormal']=dict(resource=str(normal),uses=normal_uses,boundsNative=[1140,1000,1430,1310],stages={})
    for event in (275,*normal_events,699):
        controller.SetFrameEvent(event,True)
        raw=bytes(controller.GetTextureData(normal,rd.Subresource()))
        assert len(raw)==2560*1440*4
        crop=b''.join(raw[(y*2560+1140)*4:(y*2560+1430)*4] for y in range(1000,1310))
        receipt['receiverNormal']['stages'][str(event)]=dict(rawSha256=sha256(raw).hexdigest(),
            crop=emit(f'{event}-receiver-normal.zlib',zlib.compress(crop,6)))
    assert sha256(raw).hexdigest()==request['normalSha256']
    receipt['status']='qualified'
except Exception:
    receipt['error']=traceback.format_exc()
finally:
    if controller:controller.Shutdown()
    capture.Shutdown()
    (output/'native-atlas-producers.json').write_text(json.dumps(receipt,indent=2)+'\n')
os._exit(0)
