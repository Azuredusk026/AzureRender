Shader hash a34382f5-4097a378-f3401a15-4d7d8bd4

ps_5_0
      dcl_globalFlags refactoringAllowed
      dcl_constantbuffer cb0[27], immediateIndexed
      dcl_constantbuffer cb1[7], immediateIndexed
      dcl_sampler s0, mode_default
      dcl_resource_texture2d (float,float,float,float) t0
      dcl_input_ps_siv linear noperspective v0.xy, position
      dcl_input_ps linear v1.xy
      dcl_temps 1
   0: sample_b(texture2d)(float,float,float,float) r0.x, v1.xyxx, t0.wxyz, s0, cb0[26].x
   1: mul r0.x, r0.x, cb1[6].w
   2: sqrt r0.x, r0.x
   3: dp2 r0.y, v0.xyxx, l(0.067111, 0.005837, 0.000000, 0.000000)
   4: frc r0.y, r0.y
   5: mul r0.y, r0.y, l(52.982918)
   6: frc r0.y, r0.y
   7: ge r0.z, r0.x, l(0)
   8: movc r0.y, r0.z, r0.y, -r0.y
   9: add r0.x, -r0.y, r0.x
  10: lt r0.x, r0.x, l(0)
  11: discard_nz r0.x
  12: ret
