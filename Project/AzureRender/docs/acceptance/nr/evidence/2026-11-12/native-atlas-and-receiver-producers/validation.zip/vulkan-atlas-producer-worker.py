from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import traceback
import zlib

import renderdoc as rd

request=json.loads(Path(os.environ['AZURE_VULKAN_ATLAS_PRODUCER_REQUEST']).read_text(encoding='utf-8'))
output=Path(request['output'])
capture=rd.OpenCaptureFile()
controller=None
receipt={'status':'failed'}

def emit(name,data):
    (output/name).write_bytes(data)
    return dict(path=name,bytes=len(data),sha256=sha256(data).hexdigest())

def tile(data):
    pitch=4096*2
    return b''.join(data[y*pitch+2048*2:y*pitch+3072*2] for y in range(1024,2048))

def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)

def shader(pipeline,stage):
    reflection=pipeline.GetShaderReflection(stage)
    if not reflection:return None
    return dict(id=str(pipeline.GetShader(stage)),sha256=sha256(bytes(reflection.rawBytes)).hexdigest())

try:
    assert capture.OpenFile(request['capture'],'',None)==rd.ResultCode.Succeeded
    gpu,=[g for g in capture.GetAvailableGPUs() if g.vendor==rd.GPUVendor.nVidia and rd.GraphicsAPI.Vulkan in g.apis]
    options=rd.ReplayOptions()
    options.forceGPUVendor=gpu.vendor
    options.forceGPUDeviceID=gpu.deviceID
    status,controller=capture.OpenCapture(options,None)
    assert status==rd.ResultCode.Succeeded and controller
    properties=controller.GetAPIProperties()
    assert properties.vendor==gpu.vendor and properties.pipelineType==rd.GraphicsAPI.Vulkan and not properties.degraded
    final_event=406
    controller.SetFrameEvent(final_event,True)
    pipeline=controller.GetPipelineState()
    reflection=pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
    atlas=next(binding.descriptor.resource for binding in pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel)
        if reflection.readOnlyResources[binding.access.index].fixedBindNumber==4)
    assert str(atlas)==request['resource']
    final=bytes(controller.GetTextureData(atlas,rd.Subresource()))
    assert len(final)==4096*2048*2 and sha256(final).hexdigest()==request['atlasSha256']
    uses=[(event.eventId,str(event.usage)) for event in controller.GetUsage(atlas) if event.eventId<=final_event]
    actions={action.eventId:action for action in walk(controller.GetRootActions())}
    producers=[actions[event] for event,usage in uses if usage=='ResourceUsage.DepthStencilTarget'
        and event in actions and actions[event].flags&rd.ActionFlags.Drawcall]
    assert producers and any(draw.numIndices==43044 for draw in producers)
    receipt.update(resource=str(atlas),device=gpu.name,uses=uses,atlasSha256=sha256(final).hexdigest(),stages={})
    for draw in producers:
        event=draw.eventId
        controller.SetFrameEvent(event,True)
        pipeline=controller.GetPipelineState()
        assert pipeline.GetDepthTarget().resource==atlas
        raw=bytes(controller.GetTextureData(atlas,rd.Subresource()))
        assert len(raw)==len(final)
        crop=tile(raw)
        viewport=pipeline.GetViewport(0)
        entry=dict(indexCount=draw.numIndices,vertex=shader(pipeline,rd.ShaderStage.Vertex),
            pixel=shader(pipeline,rd.ShaderStage.Pixel),tile=emit(f'{event}-tile.zlib',zlib.compress(crop,6)),
            tileSha256=sha256(crop).hexdigest(),viewport=[viewport.x,viewport.y,viewport.width,viewport.height,
                viewport.minDepth,viewport.maxDepth])
        receipt['stages'][str(event)]=entry
        if draw.numIndices in (43044,102927,61923):
            mesh=controller.GetPostVSData(0,0,rd.MeshDataStage.VSOut)
            assert mesh.numIndices==draw.numIndices and mesh.indexByteStride in (2,4) and mesh.vertexByteStride>=16
            index_data=bytes(controller.GetBufferData(mesh.indexResourceId,mesh.indexByteOffset,mesh.numIndices*mesh.indexByteStride))
            indices=struct.unpack('<'+('I' if mesh.indexByteStride==4 else 'H')*mesh.numIndices,index_data)
            vertex_count=max(indices)+mesh.baseVertex+1
            assert vertex_count>0 and min(indices)+mesh.baseVertex>=0
            vertices=bytes(controller.GetBufferData(mesh.vertexResourceId,mesh.vertexByteOffset,vertex_count*mesh.vertexByteStride))
            assert len(vertices)==vertex_count*mesh.vertexByteStride
            entry['postVertex']=dict(count=vertex_count,stride=mesh.vertexByteStride,indexStride=mesh.indexByteStride,
                baseVertex=mesh.baseVertex,vertices=emit(f'{event}-post-vertices.zlib',zlib.compress(vertices,6)),
                indices=emit(f'{event}-post-indices.zlib',zlib.compress(index_data,6)))
    assert crop==tile(final)
    receipt['status']='qualified'
except Exception:
    receipt['error']=traceback.format_exc()
finally:
    if controller:controller.Shutdown()
    capture.Shutdown()
    (output/'vulkan-atlas-producers.json').write_text(json.dumps(receipt,indent=2)+'\n')
os._exit(0)
