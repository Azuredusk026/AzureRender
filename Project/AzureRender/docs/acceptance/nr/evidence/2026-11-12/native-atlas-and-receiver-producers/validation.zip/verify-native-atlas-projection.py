from hashlib import sha256
from pathlib import Path
import json

import numpy as np

out=Path(__file__).resolve().parent
source=out/'native-atlas-producers'
prior=out.parent/'20261112-020715-scene-visibility-reference-calibration-f77af1'
numeric=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
native=json.loads((source/'native-atlas-producers.json').read_text())
assert native['status']=='qualified'
view=json.loads((prior/'hair-project/config/reference-views.json').read_text())['views']['native-hair']
config=json.loads((numeric/'hair-calibration.json').read_text())
calibration=view['objectVisibility']['calibration']
assert calibration['clipToWorld']==config['clipToWorld']
unit=np.asarray(config['record']['projection'],'<f4').reshape(4,4).T
clip=unit.copy()
clip[0]*=np.float32(2)
clip[1]*=np.float32(-2)
clip[0,3]-=np.float32(1)
clip[1,3]+=np.float32(1)
clip_bytes=clip.T.astype('<f4').tobytes()
assert len(clip_bytes)==64
reference_origins=[]
for event in ('143','223','237'):
    matrices=(source/(event+'-0-b2.bin')).read_bytes()[:64]
    assert matrices==clip_bytes,(event,matrices.hex(),clip_bytes.hex())
    constants=(source/(event+'-0-b0.bin')).read_bytes()
    reference_origins.append(np.frombuffer(constants[44*16:45*16],'<f4').tolist())
assert all(value==reference_origins[0] for value in reference_origins)
axes=view['frame']['axes']
offset=np.asarray(calibration['positionOffset'],'<f4')
relative=np.asarray(view['frame']['offset'],'<f4')
anchor=offset-relative
assert anchor.tolist()==reference_origins[0][:3]
assert all(event['viewport']=={'x':'2048.0','y':'1024.0','width':'1024.0','height':'1024.0','minDepth':'0.0','maxDepth':'1.0'}
    and event['depth']['depthFunction']=='CompareFunction.GreaterEqual' and event['depth']['depthWrites']=='True'
    and event['rasterizer']['depthBias']=='-8' for key,event in native['stages'].items() if key!='125')
result=dict(pixelConsumerEvent=699,vertexSourceEvents=[143,223,237],depthConvention='reversed',atlasPage=6,
    referenceAxes=axes,referenceOffset=offset.tolist(),absoluteCameraOrigin=anchor.tolist(),
    rasterClipColumns=clip.T.reshape(-1).tolist(),rasterClipSha256=sha256(clip_bytes).hexdigest(),
    consumerUnitColumns=unit.T.reshape(-1).tolist(),consumerUnitSha256=sha256(unit.T.astype('<f4').tobytes()).hexdigest(),
    viewportConversion='x = 2u - 1; y = 1 - 2v; z = reversed depth',matrixBitMatch=True,
    casterHairPixelProgramEmpty=not native['stages']['237']['pixel']['sources'])
(out/'native-atlas-projection-source.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
