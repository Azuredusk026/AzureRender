from hashlib import sha256
from pathlib import Path
import json
import zipfile

out=Path(__file__).resolve().parent
engine=out.parents[2]
target=engine/'docs/acceptance/nr/evidence/2026-11-12/native-atlas-and-receiver-producers'
native=out/'native-atlas-producers'
vulkan=out/'vulkan-atlas-producers'

def read(folder,file):
    return json.loads((folder/file).read_text(encoding='utf-8'))

def digest(data):
    return sha256(data).hexdigest()

native_receipt=read(native,'native-atlas-producers.json')
vulkan_receipt=read(vulkan,'vulkan-atlas-producers.json')
assert native_receipt['status']==vulkan_receipt['status']=='qualified'
assert len(native_receipt['stages'])==11 and len(vulkan_receipt['stages'])==10
assert len(native_receipt['receiverNormal']['stages'])==14
projection=read(out,'native-atlas-projection-source.json')
arithmetic=read(out,'native-shadow-vertex-arithmetic.json')
assert projection['matrixBitMatch'] and arithmetic['vertices']==arithmetic['exactVertices']==11564
cross=read(out,'atlas-cross-producer-attribution.json')
attribution=read(out,'producer-attribution.json')
assert cross['depthError']['2']['pixels']==2380 and cross['depthError']['2']['sameMaterial']==2345
assert attribution['receiverLastNormalChange']['nvidia']['377']['overOne']==1400
target.mkdir(parents=True,exist_ok=False)
archive=target/'validation.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as writer:
    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py','.json','.log'):
            writer.write(path,path.name)
    for folder in (native,vulkan):
        for path in sorted(folder.iterdir()):
            if not path.is_file() or path.suffix not in ('.py','.json','.log','.zlib','.bin','.asm','.dxbc'):
                continue
            if folder==vulkan and '-post-' in path.name and not path.name.startswith('272-'):
                continue
            writer.write(path,path.relative_to(out).as_posix())
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    contents={name:digest(reader.read(name)) for name in reader.namelist()}
assert archive.stat().st_size<=8*1024*1024
result=dict(status='qualified-native-atlas-and-receiver-producer-isolation',overall='failed-user-review',
    sourceCommit='4e4c00c65d07056cd5b235d83d807a4395388c12',native=native_receipt,vulkan=vulkan_receipt,
    atlasProducerComparison=cross,receiverSourceAttribution=attribution,projection=projection,vertexArithmetic=arithmetic,
    execution={label:read(out,label+'-atlas-producers-execution.json') for label in ('native','vulkan')},
    archive=dict(bytes=archive.stat().st_size,sha256=digest(archive.read_bytes()),files=len(contents),contents=contents))
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:value for key,value in result['archive'].items() if key!='contents'}))
