from hashlib import file_digest
from pathlib import Path
import json
import os
import subprocess

out=Path(__file__).resolve().parent
original=out.parent/'20261112-013522-scene-visibility-atlas-source-33c6c3'
receipt=json.loads((original/'report.json').read_text())
assert receipt['status']=='qualified' and receipt['event']==406
record=receipt['captureReceipt']['capture']
capture=Path(record['path']).resolve(strict=True)
assert capture.parent==original
with capture.open('rb') as stream:assert file_digest(stream,'sha256').hexdigest()==record['sha256']
assert capture.stat().st_size==record['bytes']
folder=out/'vulkan-atlas-producers'
folder.mkdir()
request=folder/'request.json'
request.write_text(json.dumps(dict(capture=str(capture),output=str(folder),captureSha256=record['sha256'],
    resource=receipt['sources']['atlas']['resource'],atlasSha256=receipt['sources']['atlas']['sha256']),indent=2)+'\n')
env=os.environ.copy()
for key in ('VK_LAYER_PATH','VK_INSTANCE_LAYERS','ENABLE_VULKAN_RENDERDOC_CAPTURE','VK_LOADER_DRIVERS_SELECT','VK_DRIVER_FILES','VK_ICD_FILENAMES'):
    env.pop(key,None)
env['AZURE_VULKAN_ATLAS_PRODUCER_REQUEST']=str(request)
startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'vulkan-atlas-producer-worker.py')]
(folder/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (folder/'process.log').open('wb') as log:
    result=subprocess.run(command,env=env,startupinfo=startup,cwd=folder,stdout=log,stderr=subprocess.STDOUT,timeout=210)
replay=json.loads((folder/'vulkan-atlas-producers.json').read_text())
assert result.returncode==0 and replay['status']=='qualified',replay
with capture.open('rb') as stream:assert file_digest(stream,'sha256').hexdigest()==record['sha256']
print(json.dumps({key:replay[key] for key in ('status','device','resource','atlasSha256','uses')}))
