from hashlib import sha256
from pathlib import Path
import json
import zipfile
import zlib

import numpy as np

out=Path(__file__).resolve().parent
native=out/'native-atlas-producers'
stage=out.parent/'20261112-020715-scene-visibility-reference-calibration-f77af1'
atlas=out.parent/'20261112-013522-scene-visibility-atlas-source-33c6c3'
numeric=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
hair=out.parent/'20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
receipt=json.loads((native/'native-atlas-producers.json').read_text())
assert receipt['status']=='qualified'

def array(source,dtype,shape):
    data=(native/source['path']).read_bytes()
    assert len(data)==source['bytes'] and sha256(data).hexdigest()==source['sha256']
    return np.frombuffer(zlib.decompress(data),dtype).reshape(shape)

def changes(stages,details,dtype,shape):
    owner=np.zeros(shape,'u2')
    previous=np.zeros(shape,dtype)
    changed={}
    for event,source in stages.items():
        current=array(source[details],dtype,shape)
        delta=current!=previous
        owner[delta]=int(event)
        changed[int(event)]=int(delta.sum())
        previous=current
    return previous,owner,changed

frozen,casters,changed=changes(receipt['stages'],'tile','<u2',(1024,1024))
payload=(atlas/'atlas.bin').read_bytes()
assert sha256(payload).hexdigest()=='ee700ac4164ffd1923cc9ca1eaeddf27366213a4b8dc5cf0e17fa154328f781e'
actual=65535-np.frombuffer(payload,'<u2').reshape(2048,4096)[1024:2048,2048:3072]
common=(frozen!=0)&(actual!=0)
difference=np.abs(actual.astype('i4')-frozen.astype('i4'))
assert int(common.sum())==182211 and int((common&(difference>2)).sum())==2380
atlas_stats={}
for event in np.unique(casters):
    positions=casters==event
    shared=positions&common
    atlas_stats[int(event)]=dict(rawChanges=changed.get(int(event),0),finalTexels=int(positions.sum()),
        frozenCovered=int((positions&(frozen!=0)).sum()),shared=int(shared.sum()),actualOnly=int((positions&(actual!=0)&(frozen==0)).sum()),
        frozenOnly=int((positions&(actual==0)&(frozen!=0)).sum()),overTwo=int((shared&(difference>2)).sum()),
        over32=int((shared&(difference>32)).sum()),over512=int((shared&(difference>512)).sum()),
        maximum=int(difference[shared].max(initial=0)))
reference,owners,writes=changes(receipt['receiverNormal']['stages'],'crop','<u4',(310,290))
assert writes[699]==0 and 699 not in owners
queries=np.fromfile(numeric/'receiver-queries.bin','<f4').reshape(-1,4)
x,y=queries[:,:2].astype('i4').T
query_owners=owners[y-1000,x-1140]
hair_queries=np.fromfile(hair/'queries.bin','<f4').reshape(-1,4)
hx,hy=hair_queries[:,:2].astype('i4').T
in_hair=np.isin(y*2560+x,hy*2560+hx)
target=np.fromfile(numeric/'receiver-expected.bin','<u4').astype('i4')
assert len(x)==len(y)==len(target)==49384 and int(in_hair.sum())==17017
receiver_stats={}
for device in ('nvidia','intel'):
    frames=stage/f'release-{device}-frames'
    config=json.loads((frames/'capture_manifest.json').read_text())['referenceSceneDepth']
    with zipfile.ZipFile(frames/'reference-planes.zip') as archive:
        visibility=np.frombuffer(archive.read(config['objectVisibility']),'u1').reshape(1440,2560,2)[y,x,1].astype('i4')
        packed=np.frombuffer(archive.read(config['packedNormals']),'<u4').reshape(1440,2560)[y,x]
    delta=np.abs(visibility-target)
    exact_normal=packed==reference[y-1000,x-1140]
    receiver_stats[device]={}
    for event in np.unique(query_owners):
        positions=query_owners==event
        receiver_stats[device][int(event)]=dict(rawChanges=writes.get(int(event),0),receivers=int(positions.sum()),
            receiversHair=int((positions&in_hair).sum()),normalExact=int((positions&exact_normal).sum()),
            overOne=int((positions&(delta>1)).sum()),overOneNonhair=int((positions&(delta>1)&~in_hair).sum()),
            over64=int((positions&(delta>64)).sum()),maximum=int(delta[positions].max(initial=0)))
result=dict(atlasResource=receipt['resource'],normalResource=receipt['receiverNormal']['resource'],
    atlasLastDepthWrite=atlas_stats,receiverLastNormalChange=receiver_stats)
(out/'producer-attribution.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
