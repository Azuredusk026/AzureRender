from hashlib import file_digest
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys

out=Path(sys.argv[1]).resolve(strict=True)
assert out.parent.name=='runs' and out.parent.parent.name=='build'
folder=out/'native-atlas-producers'
folder.mkdir()
native=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc')
expected_sha='fa2ca267f7168f5603e83ad5f817a3074d8dbee23a216e6ab8ef2c340ec06a90'
def digest(path):
    with path.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()

assert digest(native)==expected_sha
worker=folder/'worker.py'
shutil.copyfile(Path(__file__).with_name('native-atlas-producer-worker.py'),worker)
request=folder/'request.json'
request.write_text(json.dumps(dict(capture=str(native),output=str(folder),captureSha256=expected_sha,
    atlasSha256='86daee0e01e9c33207679b094bdf5cf31a26d2f93754f11abf6c44df1faecf57',
    normalSha256='63731d707e7ba30d9417049c8148b9bd2167208e435e8d9f0cc100a1fd03e095'),indent=2)+'\n')
env=os.environ.copy()
for key in ('VK_LAYER_PATH','VK_INSTANCE_LAYERS','ENABLE_VULKAN_RENDERDOC_CAPTURE','VK_LOADER_DRIVERS_SELECT','VK_DRIVER_FILES','VK_ICD_FILENAMES'):
    env.pop(key,None)
env['AZURE_ATLAS_PRODUCER_REQUEST']=str(request)
startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(worker)]
(folder/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (folder/'process.log').open('wb') as log:
    result=subprocess.run(command,env=env,startupinfo=startup,cwd=folder,stdout=log,stderr=subprocess.STDOUT,timeout=380)
receipt=json.loads((folder/'native-atlas-producers.json').read_text())
assert result.returncode==0 and receipt['status']=='qualified',receipt
assert digest(native)==expected_sha
print(json.dumps({key:receipt[key] for key in ('status','device','resource','atlasSha256','uses')}))
