from hashlib import sha256
from pathlib import Path
import json
import zlib

import numpy as np

out=Path(__file__).resolve().parent
native=out/'native-atlas-producers'
receipt=json.loads((native/'native-atlas-producers.json').read_text())
projection=json.loads((out/'native-atlas-projection-source.json').read_text())
mesh=receipt['stages']['237']['postVertex']
payload=(native/mesh['vertices']['path']).read_bytes()
assert sha256(payload).hexdigest()==mesh['vertices']['sha256']
assert mesh['stride']==19*4
vertices=np.frombuffer(zlib.decompress(payload),'<f4').reshape(mesh['count'],19)
expected=vertices[:,:4]
relative=vertices[:,6:9]
anchor=np.asarray(projection['absoluteCameraOrigin'],'<f4')
columns=np.asarray(projection['rasterClipColumns'],'<f4').reshape(4,4)

def fma(a,b,c):
    return (a.astype('f8')*b.astype('f8')+c.astype('f8')).astype('f4')

def project(world):
    first=fma(world[:,0:1],columns[0],world[:,1:2]*columns[1])
    return fma(world[:,2:3],columns[2],first)+columns[3]

absolute=relative+anchor
replayed=project(absolute)
bits_equal=replayed.view('<u4')==expected.view('<u4')
error=np.abs(replayed.astype('f8')-expected)
ideal=(absolute.astype('f8')@columns[:3].astype('f8'))+columns[3].astype('f8')
result=dict(vertices=len(expected),exactVertices=int(bits_equal.all(axis=1).sum()),exactComponents=int(bits_equal.sum()),
    maximumClipError=error.max(axis=0).tolist(),groupedVsDoubleMaxClipError=np.abs(replayed.astype('f8')-ideal).max(axis=0).tolist(),
    viewport='native event 237',sourceFloatOffsets=dict(position=0,relativePosition=6))
(out/'native-shadow-vertex-arithmetic.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
assert bits_equal.all(),result
