from hashlib import sha256
from itertools import permutations
from pathlib import Path
import json
import zlib

import numpy as np

out=Path(__file__).resolve().parent
source=out/'native-atlas-producers'
live=out/'vulkan-atlas-producers'
native=json.loads((source/'native-atlas-producers.json').read_text())
vulkan=json.loads((live/'vulkan-atlas-producers.json').read_text())
assert native['status']==vulkan['status']=='qualified'
pairs={143:264,152:276,163:238,171:268,182:256,191:242,200:260,208:246,223:251,237:272}

def decode(folder,info):
    data=(folder/info['path']).read_bytes()
    assert len(data)==info['bytes'] and sha256(data).hexdigest()==info['sha256']
    return zlib.decompress(data)

def changes(folder,stages,forward,labels):
    owner=np.zeros((1024,1024),'u2')
    prev=np.zeros((1024,1024),'<u2')
    counts={}
    for event,source in stages.items():
        event=int(event)
        current=np.frombuffer(decode(folder,source['tile']),'<u2').reshape(1024,1024)
        if forward:current=65535-current
        changed=current!=prev
        owner[changed]=labels.get(event,event)
        counts[event]=int(changed.sum())
        prev=current
    return prev,owner,counts

frozen,native_last,native_counts=changes(source,native['stages'],False,{})
actual,actual_last,actual_counts=changes(live,vulkan['stages'],True,{engine:origin for origin,engine in pairs.items()})
error=np.abs(frozen.astype('i4')-actual.astype('i4'))
common=(frozen!=0)&(actual!=0)
assert int(common.sum())==182211
by_kind={}
for gate in (2,32,512):
    misses=common&(error>gate)
    both=native_last==actual_last
    combinations,counts=np.unique(np.column_stack((native_last[misses],actual_last[misses])),axis=0,return_counts=True)
    by_kind[gate]=dict(pixels=int(misses.sum()),sameMaterial=int((misses&both).sum()),differentMaterial=int((misses&~both).sum()),
        eventPairs=[dict(nativeEvent=int(key[0]),productionEvent=pairs[int(key[1])],sameMaterial=bool(key[0]==key[1]),count=int(count))
            for key,count in sorted(zip(combinations,counts),key=lambda item:int(item[1]),reverse=True)])

def mesh(folder,entry):
    mesh=entry['postVertex']
    stride=mesh['stride']
    vertices=np.ndarray((mesh['count'],4),'<f4',buffer=decode(folder,mesh['vertices']),strides=(stride,4))
    dtype={2:'<u2',4:'<u4'}[mesh['indexStride']]
    indices=np.frombuffer(decode(folder,mesh['indices']),dtype).astype('i8')+mesh['baseVertex']
    return vertices,indices.reshape(-1,3)

n_pos,n_indices=mesh(source,native['stages']['237'])
v_pos,v_indices=mesh(live,vulkan['stages']['272'])
assert len(n_indices)==len(v_indices)==43044//3
matches=[]
for permutation in permutations(range(3)):
    vertex_pairs=np.unique(np.column_stack((n_indices[:,permutation].reshape(-1),v_indices.reshape(-1))),axis=0)
    if len(vertex_pairs)!=len(np.unique(n_indices)) or len(vertex_pairs)!=len(np.unique(v_indices)):
        continue
    if any(len(np.unique(vertex_pairs[:,index]))!=len(vertex_pairs) for index in (0,1)):
        continue
    reference=n_pos[vertex_pairs[:,0]].astype('f8')
    production=v_pos[vertex_pairs[:,1]].astype('f8')
    assert np.isfinite(reference).all() and np.isfinite(production).all()
    reference[:,:3]/=reference[:,3,None]
    production[:,:3]/=production[:,3,None]
    reference[:,1]*=-1
    reference[:,2]=1-reference[:,2]
    delta=np.abs(reference[:,:3]-production[:,:3])*np.asarray((512,512,65535))
    matches.append((float(delta.mean()),permutation,reference,production,delta))
assert matches
_,permutation,reference,production,delta=min(matches,key=lambda item:item[0])
reference_pixel=np.rint(reference[:,:2]*(512*256))
production_pixel=np.rint(production[:,:2]*(512*256))
hair_mesh=dict(vertices=len(delta),triangleCornerOrder=permutation,comparedAxes=['atlasX','atlasY','D16'],
    median=np.median(delta,axis=0).tolist(),p95=np.percentile(delta,95,axis=0).tolist(),maximum=delta.max(axis=0).tolist(),
    xySubpixelExact=int(np.all(reference_pixel==production_pixel,axis=1).sum()),
    d16WithinOne=int((delta[:,2]<=1).sum()))
result=dict(casterEventMap=pairs,nativeDepthUpdates=native_counts,actualDepthUpdates=actual_counts,
    coveredByBoth=int(common.sum()),actualOnly=int(((actual!=0)&(frozen==0)).sum()),
    nativeOnly=int(((frozen!=0)&(actual==0)).sum()),depthError=by_kind,hairVertex=hair_mesh)
(out/'atlas-cross-producer-attribution.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({**result,'depthError':{key:{**value,'eventPairs':value['eventPairs'][:10]} for key,value in by_kind.items()}}))
