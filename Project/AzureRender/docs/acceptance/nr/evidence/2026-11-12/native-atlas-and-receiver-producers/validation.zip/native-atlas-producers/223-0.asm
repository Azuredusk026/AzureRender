Shader hash 17f2d152-7b8ac39e-9a4c4881-287db236

vs_5_0
      dcl_globalFlags refactoringAllowed
      dcl_constantbuffer cb0[82], immediateIndexed
      dcl_constantbuffer cb1[4091], dynamicIndexed
      dcl_constantbuffer cb2[4], immediateIndexed
      dcl_constantbuffer cb3[11], immediateIndexed
      dcl_resource_structured t0, 16
      dcl_input v0.xyz
      dcl_input v1.xy
      dcl_input v2.xyz
      dcl_input v3.xyz
      dcl_input v4.xyzw
      dcl_input v5.xyzw
      dcl_input_sgv v6.x, instanceid
      dcl_output_siv o0.xyzw, position
      dcl_output o1.xy
      dcl_output o2.xyz
      dcl_output o3.xyz
      dcl_output o4.xyz
      dcl_output o5.xyz
      dcl_output o6.x
      dcl_temps 12
   0: and r0.xy, v2.xxxx, l(2.000000, 0.000000, 0.000000, 0.000000)
   1: ult r0.x, l(0), r0.x
   2: ubfe r0.z, l(10), l(10), v2.x
   3: utof r0.yz, r0.yyzy
   4: ge r0.w, r0.y, l(512.000000)
   5: add r1.x, r0.y, l(-1024.000000)
   6: movc r1.x, r0.w, r1.x, r0.y
   7: ge r0.y, r0.z, l(512.000000)
   8: add r0.w, r0.z, l(-1024.000000)
   9: movc r1.y, r0.y, r0.w, r0.z
  10: mul r0.yz, r1.xxyx, l(0.000000, 0.001957, 0.001957, 0.000000)
  11: add r2.xyz, -abs(r0.yzyy), l(1.000000, 1.000000, 1.000000, 0.000000)
  12: add r3.z, -abs(r0.z), r2.x
  13: lt r0.w, r3.z, l(0)
  14: ge r1.xy, r1.xyxx, l(0, 0, 0, 0)
  15: and r1.xy, r1.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
  16: mad r1.xy, r1.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
  17: mul r1.xy, r1.xyxx, r2.yzyy
  18: movc r3.xy, r0.wwww, r1.xyxx, r0.yzyy
  19: dp3 r0.y, r3.xyzx, r3.xyzx
  20: rsq r0.y, r0.y
  21: mul r0.yzw, r0.yyyy, r3.xxyz
  22: movc r0.xyz, r0.xxxx, r0.yzwy, v2.xyzx
  23: ishl r0.w, v6.x, l(4)
  24: and r1.xy, l(32, -49, 0, 0), cb1[r0.w + 4].wwww
  25: ieq r1.xz, r1.xxyx, l(0, 0, 0, 0)
  26: or r1.x, r1.z, r1.x
  27: if_z r1.x
  28:   iadd r1.xz, l(3, 0, 3, 0), cb1[r0.w + 5].xxyx
  29:   imad r2.xyzw, v5.xyzw, l(3, 3, 3, 3), r1.xxxx
  30:   imad r3.xyzw, v5.xyzw, l(3, 3, 3, 3), r1.zzzz
  31:   iadd r1.xz, r2.xxxx, l(1, 0, 2, 0)
  32:   iadd r4.xy, r3.xxxx, l(1, 2, 0, 0)
  33:   uge r1.yw, r1.yyyy, l(0, 2, 0, 4)
  34:   if_nz r1.y
  35:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r5.xyzw, r4.y, l(0), t0.xyzw
  36:     iadd r4.zw, r3.yyyy, l(0, 0, 2, 1)
  37:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r6.xyzw, r4.z, l(0), t0.xyzw
  38:     mul r6.xyzw, r6.xyzw, v4.yyyy
  39:     mad r5.xyzw, r5.xyzw, v4.xxxx, r6.xyzw
  40:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r6.xyzw, r4.x, l(0), t0.xyzw
  41:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r4.w, l(0), t0.xyzw
  42:     mul r7.xyzw, r7.xyzw, v4.yyyy
  43:     mad r6.xyzw, r6.xyzw, v4.xxxx, r7.xyzw
  44:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r3.x, l(0), t0.xyzw
  45:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r8.xyzw, r3.y, l(0), t0.xyzw
  46:     mul r8.xyzw, r8.xyzw, v4.yyyy
  47:     mad r7.xyzw, r7.xyzw, v4.xxxx, r8.xyzw
  48:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r8.xyzw, r1.z, l(0), t0.xyzw
  49:     iadd r4.zw, r2.yyyy, l(0, 0, 2, 1)
  50:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r9.xyzw, r4.z, l(0), t0.xyzw
  51:     mul r9.xyzw, r9.xyzw, v4.yyyy
  52:     mad r8.xyzw, r8.xyzw, v4.xxxx, r9.xyzw
  53:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r9.xyzw, r1.x, l(0), t0.xyzw
  54:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r4.w, l(0), t0.xyzw
  55:     mul r10.xyzw, r10.xyzw, v4.yyyy
  56:     mad r9.xyzw, r9.xyzw, v4.xxxx, r10.xyzw
  57:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r2.x, l(0), t0.xyzw
  58:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r11.xyzw, r2.y, l(0), t0.xyzw
  59:     mul r11.xyzw, r11.xyzw, v4.yyyy
  60:     mad r10.xyzw, r10.xyzw, v4.xxxx, r11.xyzw
  61:   else
  62:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r5.xyzw, r4.y, l(0), t0.xyzw
  63:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r6.xyzw, r4.x, l(0), t0.xyzw
  64:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r3.x, l(0), t0.xyzw
  65:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r8.xyzw, r1.z, l(0), t0.xyzw
  66:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r9.xyzw, r1.x, l(0), t0.xyzw
  67:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r2.x, l(0), t0.xyzw
  68:   endif
  69:   if_nz r1.w
  70:     iadd r1.xyzw, r3.zwzw, l(2, 2, 1, 1)
  71:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.xyzw, r1.x, l(0), t0.xyzw
  72:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r11.xyzw, r1.y, l(0), t0.xyzw
  73:     mul r11.xyzw, r11.xyzw, v4.wwww
  74:     mad r4.xyzw, r4.xyzw, v4.zzzz, r11.xyzw
  75:     add r5.xyzw, r4.xyzw, r5.xyzw
  76:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.xyzw, r1.z, l(0), t0.xyzw
  77:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r1.xyzw, r1.w, l(0), t0.xyzw
  78:     mul r1.xyzw, r1.xyzw, v4.wwww
  79:     mad r1.xyzw, r4.xyzw, v4.zzzz, r1.xyzw
  80:     add r6.xyzw, r1.xyzw, r6.xyzw
  81:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r1.xyzw, r3.z, l(0), t0.xyzw
  82:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r3.xyzw, r3.w, l(0), t0.xyzw
  83:     mul r3.xyzw, r3.xyzw, v4.wwww
  84:     mad r1.xyzw, r1.xyzw, v4.zzzz, r3.xyzw
  85:     add r7.xyzw, r1.xyzw, r7.xyzw
  86:     iadd r1.xyzw, r2.zwzw, l(2, 2, 1, 1)
  87:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r3.xyzw, r1.x, l(0), t0.xyzw
  88:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.xyzw, r1.y, l(0), t0.xyzw
  89:     mul r4.xyzw, r4.xyzw, v4.wwww
  90:     mad r3.xyzw, r3.xyzw, v4.zzzz, r4.xyzw
  91:     add r8.xyzw, r3.xyzw, r8.xyzw
  92:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r3.xyzw, r1.z, l(0), t0.xyzw
  93:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r1.xyzw, r1.w, l(0), t0.xyzw
  94:     mul r1.xyzw, r1.xyzw, v4.wwww
  95:     mad r1.xyzw, r3.xyzw, v4.zzzz, r1.xyzw
  96:     add r9.xyzw, r1.xyzw, r9.xyzw
  97:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r1.xyzw, r2.z, l(0), t0.xyzw
  98:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r2.xyzw, r2.w, l(0), t0.xyzw
  99:     mul r2.xyzw, r2.xyzw, v4.wwww
 100:     mad r1.xyzw, r1.xyzw, v4.zzzz, r2.xyzw
 101:     add r10.xyzw, r1.xyzw, r10.xyzw
 102:   endif
 103:   dp3 r1.x, r10.xyzx, r0.xyzx
 104:   dp3 r1.y, r9.xyzx, r0.xyzx
 105:   dp3 r0.z, r8.xyzx, r0.xyzx
 106:   mov r2.xyz, v0.xyzx
 107:   mov r2.w, l(1.000000)
 108:   dp4 r1.z, r10.xyzw, r2.xyzw
 109:   dp4 r1.w, r9.xyzw, r2.xyzw
 110:   dp4 r3.x, r8.xyzw, r2.xyzw
 111:   dp4 r4.x, r7.xyzw, r2.xyzw
 112:   dp4 r4.y, r6.xyzw, r2.xyzw
 113:   dp4 r4.z, r5.xyzw, r2.xyzw
 114:   mov r0.xy, r1.xyxx
 115: else
 116:   mov r4.xyz, v3.xyzx
 117:   mov r1.zw, v0.xxxy
 118:   mov r3.x, v0.z
 119: endif
 120: mul r2.xyz, r1.wwww, cb1[r0.w + 1].xyzx
 121: mad r2.xyz, cb1[r0.w + 0].xyzx, r1.zzzz, r2.xyzx
 122: mad r2.xyz, cb1[r0.w + 2].xyzx, r3.xxxx, r2.xyzx
 123: add r3.yzw, -cb0[44].xxyz, cb1[r0.w + 3].xxyz
 124: add r2.xyz, r2.xyzx, r3.yzwy
 125: mul r3.yzw, r0.yyyy, cb1[r0.w + 1].xxyz
 126: mad r3.yzw, cb1[r0.w + 0].xxyz, r0.xxxx, r3.yyzw
 127: mad r0.xyz, cb1[r0.w + 2].xyzx, r0.zzzz, r3.yzwy
 128: lt r1.x, cb1[r0.w + 10].x, l(1.000000)
 129: mad o1.xy, v1.xyxx, cb3[10].xyxx, cb3[10].zwzz
 130: dp3 r1.y, r0.xyzx, r0.xyzx
 131: max r1.y, r1.y, l(0.000000)
 132: rsq r1.y, r1.y
 133: mul o3.xyz, r0.xyzx, r1.yyyy
 134: mul r0.xyz, r2.yyyy, cb0[33].xywx
 135: mad r0.xyz, cb0[32].xywx, r2.xxxx, r0.xyzx
 136: mad r0.xyz, cb0[34].xywx, r2.zzzz, r0.xyzx
 137: add o4.xyz, r0.xyzx, cb0[35].xywx
 138: movc r0.xy, r1.xxxx, r1.zwzz, r4.xyxx
 139: movc r0.z, r1.x, r3.x, r4.z
 140: mul r1.xyz, r0.yyyy, cb1[r0.w + 7].xyzx
 141: mad r1.xyz, cb1[r0.w + 6].xyzx, r0.xxxx, r1.xyzx
 142: mad r0.xyz, cb1[r0.w + 8].xyzx, r0.zzzz, r1.xyzx
 143: add r1.xyz, -cb0[81].xyzx, cb1[r0.w + 9].xyzx
 144: add r0.xyz, r0.xyzx, r1.xyzx
 145: mul r1.xyz, r0.yyyy, cb0[58].xywx
 146: mad r0.xyw, cb0[57].xyxw, r0.xxxx, r1.xyxz
 147: mad r0.xyz, cb0[59].xywx, r0.zzzz, r0.xywx
 148: add o5.xyz, r0.xyzx, cb0[60].xywx
 149: add r0.xyz, r2.xyzx, cb0[44].xyzx
 150: mul r1.xyzw, r0.yyyy, cb2[1].xyzw
 151: mad r1.xyzw, cb2[0].xyzw, r0.xxxx, r1.xyzw
 152: mad r0.xyzw, cb2[2].xyzw, r0.zzzz, r1.xyzw
 153: add o0.xyzw, r0.xyzw, cb2[3].xyzw
 154: mov o2.xyz, r2.xyzx
 155: mov o6.x, v6.x
 156: ret
