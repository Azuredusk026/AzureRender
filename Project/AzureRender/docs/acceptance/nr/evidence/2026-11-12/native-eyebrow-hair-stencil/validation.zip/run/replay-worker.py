from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import traceback
import zlib

import renderdoc as rd


request = json.loads(Path(os.environ['AZURE_NATIVE_STENCIL_REQUEST']).read_text())
out = Path(request['output'])
receipt = dict(status='failed', devices={})
pixel_count = 2560 * 1440
fields = ('reference', 'compareMask', 'writeMask', 'function', 'passOperation', 'failOperation', 'depthFailOperation')
tests = ('backfaceCulled', 'sampleMasked', 'depthClipped', 'scissorClipped', 'shaderDiscarded', 'depthTestFailed', 'stencilTestFailed')


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


def face(state):
    return {key: int(getattr(state, key)) if key in fields[:3] else str(getattr(state, key)) for key in fields}


def dsv_state(controller, event, actions):
    controller.SetFrameEvent(event, True)
    state = controller.GetD3D11PipelineState()
    raster = state.rasterizer.state
    om = state.outputMerger
    dsv = om.depthStencilState
    return dict(event=event, indices=actions[event].numIndices, depthReadOnly=om.depthReadOnly,
        stencilReadOnly=om.stencilReadOnly, depthEnable=dsv.depthEnable, depthWrites=dsv.depthWrites,
        depthFunction=str(dsv.depthFunction), stencilEnable=dsv.stencilEnable,
        front=face(dsv.frontFace), back=face(dsv.backFace), cullMode=str(raster.cullMode), frontCCW=raster.frontCCW)


def crop(raw):
    return b''.join(raw[(row * 2560 + 1140) * 8:(row * 2560 + 1430) * 8] for row in range(1000, 1310))


def attachment(controller, target, name, event):
    controller.SetFrameEvent(event, True)
    raw = bytes(controller.GetTextureData(target, rd.Subresource()))
    assert len(raw) == pixel_count * 8
    local = crop(raw)
    compressed = zlib.compress(local, 6)
    path = f'{name}-{event}-d32s8.zlib'
    (out / path).write_bytes(compressed)
    values = [struct.unpack_from('<II', raw, (int(y) * 2560 + int(x)) * 8)
        for x, y in request['overlap']]
    return dict(path=path, sha256=sha256(compressed).hexdigest(), fullSha256=sha256(raw).hexdigest(),
        rawCropSha256=sha256(local).hexdigest(), overlapSecondWords=sorted(Counter(stencil for _, stencil in values).items()))


def pixel_history(controller, target, item):
    x, y = item['point']
    controller.SetFrameEvent(422, True)
    rows = []
    for change in controller.PixelHistory(target, x, y, rd.Subresource(), rd.CompType.Typeless):
        if change.eventId not in (296, 422):
            continue
        rows.append(dict(event=change.eventId, fragment=change.fragIndex, primitive=change.primitiveID,
            passed=change.Passed(), tests={key: getattr(change, key) for key in tests},
            stencil=[change.preMod.stencil, change.shaderOut.stencil, change.postMod.stencil],
            depth=[change.preMod.depth, change.shaderOut.depth, change.postMod.depth]))
    return dict(point=item['point'], kind=item['kind'], changes=rows)


def replay(capture, name, vendor):
    gpu, = [item for item in capture.GetAvailableGPUs() if item.vendor == vendor and rd.GraphicsAPI.D3D11 in item.apis]
    options = rd.ReplayOptions()
    options.forceGPUVendor = vendor
    options.forceGPUDeviceID = gpu.deviceID
    status, controller = capture.OpenCapture(options, None)
    assert status == rd.ResultCode.Succeeded and controller
    try:
        api = controller.GetAPIProperties()
        assert api.vendor == vendor and api.pipelineType == rd.GraphicsAPI.D3D11 and not api.degraded
        actions = {action.eventId: action for action in walk(controller.GetRootActions())}
        assert actions[296].numIndices == 1878 and actions[422].numIndices == 43044
        controller.SetFrameEvent(422, True)
        pipe = controller.GetPipelineState()
        target, normal = pipe.GetDepthTarget().resource, pipe.GetOutputTargets()[3].resource
        assert str(target) == 'ResourceId::141967' and str(normal) == 'ResourceId::141952'
        usage = controller.GetUsage(target)
        events = sorted({item.eventId for item in usage if 270 <= item.eventId <= 478
            and item.usage == rd.ResourceUsage.DepthStencilTarget and item.eventId in actions
            and actions[item.eventId].flags & rd.ActionFlags.Drawcall})
        assert {296, 422, 440}.issubset(events) and len(events) <= 32
        states = {event: dsv_state(controller, event, actions) for event in events}
        checkpoints = (276, 296, 421, 422, 440, 699)
        attachments = {event: attachment(controller, target, name, event) for event in checkpoints}
        history = [pixel_history(controller, normal, item) for item in request['history']] if name == 'nvidia' else []
        if history:
            assert any(change['event'] == 422 for item in history for change in item['changes'])
        return dict(device=gpu.name, states=states, attachments=attachments, history=history,
            messages=[str(item.description) for item in controller.GetDebugMessages()])
    finally:
        controller.Shutdown()


capture = rd.OpenCaptureFile()
try:
    assert capture.OpenFile(request['capture'], '', None) == rd.ResultCode.Succeeded
    for name, vendor in (('nvidia', rd.GPUVendor.nVidia), ('intel', rd.GPUVendor.Intel)):
        receipt['devices'][name] = replay(capture, name, vendor)
    receipt['status'] = 'qualified'
except BaseException:
    receipt['error'] = traceback.format_exc()
finally:
    capture.Shutdown()
    (out / 'report.json').write_text(json.dumps(receipt, indent=2) + '\n')
os._exit(0 if receipt['status'] == 'qualified' else 1)