from hashlib import sha256
from pathlib import Path
import json
import zipfile
import zlib

import numpy as np


out = Path(__file__).resolve().parent
target = out.parents[2] / 'docs/acceptance/nr/evidence/2026-11-12/native-eyebrow-hair-stencil'
raw = out / 'stencil-replay'


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


replay = load(raw / 'report.json')
execution = load(out / 'replay-execution.json')
held, released = [load(out / f'lease-{name}.json') for name in ('held', 'released')]
request = load(raw / 'request.json')
assert replay['status'] == 'qualified' and execution['status'] == 'exited' and execution['exitCode'] == 0
assert held['token'] == released['token'] and held['state'] == 'held' and released['state'] == 'released'
assert held['task'] == released['task'] == 'quality-native-eyebrow-hair-stencil'
assert len(request['overlap']) == 135 and len(request['nativeEyebrow']) == 496
assert request['beforeMaxUlp'] == 1 and request['afterUlp'] == [10771, 123265]
nvidia, intel = [replay['devices'][name] for name in ('nvidia', 'intel')]
assert nvidia['states'] == intel['states']
states = nvidia['states']
for event in ('296', '310'):
    for side in ('front', 'back'):
        face = states[event][side]
        assert face['reference'] == 52 and face['writeMask'] == 255
        assert face['function'] == 'CompareFunction.AlwaysTrue' and face['passOperation'] == 'StencilOperation.Replace'
for event in ('422', '440'):
    for side in ('front', 'back'):
        face = states[event][side]
        assert face['reference'] == 36 and face['compareMask'] == 16 and face['writeMask'] == 239
        assert face['function'] == 'CompareFunction.GreaterEqual' and face['passOperation'] == 'StencilOperation.Replace'
        assert face['failOperation'] == face['depthFailOperation'] == 'StencilOperation.Keep'
assert set(states) == {'296','310','328','345','363','377','391','404','422','440','460','478'}
for event in ('328','345','363','377','391','404','460','478'):
    for side in ('front', 'back'):
        face = states[event][side]
        assert face['reference'] & 16 == 0 and face['writeMask'] == 255
        assert face['function'] == 'CompareFunction.AlwaysTrue' and face['passOperation'] == 'StencilOperation.Replace'
assert all(value['depthFunction'] == 'CompareFunction.GreaterEqual' and value['depthWrites'] for value in states.values())
points = np.array(request['overlap'], dtype='i4') - [1140, 1000]
x, y = points.T
all_points = np.array(request['nativeEyebrow'], dtype='i4') - [1140, 1000]
all_x, all_y = all_points.T
attachments = {}
for name, device in replay['devices'].items():
    attachments[name] = {}
    for event, entry in device['attachments'].items():
        data = (raw / entry['path']).read_bytes()
        assert sha256(data).hexdigest() == entry['sha256']
        decoded = zlib.decompress(data)
        assert sha256(decoded).hexdigest() == entry['rawCropSha256']
        assert len(decoded) == 310 * 290 * 8
        words = np.frombuffer(decoded, '<u4').reshape(310, 290, 2)
        depth, stencil = words[:, :, 0], words[:, :, 1]
        assert stencil.max() <= 255
        assert (stencil[y, x] == (0 if event == '276' else 52)).all()
        attachments[name][event] = dict(plane=stencil, depth=depth)
    assert np.array_equal(attachments[name]['421']['depth'][y,x], attachments[name]['422']['depth'][y,x])
    assert np.array_equal(attachments[name]['422']['depth'][y,x], attachments[name]['440']['depth'][y,x])
    assert (attachments[name]['699']['plane'][all_y,all_x] == 52).all()
for event in nvidia['attachments']:
    assert np.array_equal(attachments['nvidia'][event]['plane'], attachments['intel'][event]['plane'])
history = nvidia['history']
controls = [item for item in history if item['kind'] == 'native-hair']
covered = [item for item in history if item['kind'] == 'native-eyebrow-player-hair']
assert len(covered) == 6 and len(controls) == 2
for item in covered:
    assert any(change['event'] == 296 and change['passed'] for change in item['changes'])
    hair = [change for change in item['changes'] if change['event'] == 422]
    assert hair and all(change['tests']['stencilTestFailed'] and not change['passed'] for change in hair)
    assert any(not change['tests']['depthTestFailed'] and not change['tests']['shaderDiscarded']
        and not change['tests']['backfaceCulled'] and change['tests']['stencilTestFailed'] for change in hair)
for item in controls:
    assert any(change['event'] == 422 and change['passed'] and not change['tests']['stencilTestFailed']
        for change in item['changes'])

inputs = [out / name for name in ('task-card.json', 'replay.py', 'replay-worker.py', 'queued-replay.py',
    'replay-execution.json', 'lease-held.json', 'lease-released.json', 'package-evidence.py')]
inputs.extend(sorted(raw.iterdir()))
archive = out / 'validation-pending.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as writer:
    for path in inputs:
        writer.write(path, 'run/' + path.relative_to(out).as_posix())
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    contents = {name: sha256(reader.read(name)).hexdigest() for name in reader.namelist()}
    assert len(contents) == len(inputs)
assert archive.stat().st_size <= 8 * 1024 * 1024
payload = dict(status='qualified-native-eyebrow-hair-stencil', overall='failed-user-review',
    result=dict(eyebrowPoints=len(all_points), overlap=len(points), depthBeforeMaxUlp=request['beforeMaxUlp'],
        playerHairDepthOverNativeUlp=request['afterUlp'], stencilBefore=0, stencilEyebrow=52,
        protectedBit=16, overlapStencilDepthPreserved=135, rejectedPixelHistory=len(covered),
        passedPixelHistoryControls=len(controls), sameStencilCropsAcrossAdapters=6),
    nativeReplay=replay, execution=execution, lease=released,
    archive=dict(bytes=archive.stat().st_size, sha256=sha256(archive.read_bytes()).hexdigest(), contents=contents))
target.mkdir(parents=True, exist_ok=True)
assert not (target / 'validation.zip').exists() and not (target / 'results.json').exists()
archive.rename(target / 'validation.zip')
(target / 'results.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in payload['archive'].items() if key != 'contents'}))