from pathlib import Path
import json
import sys
import time


out = Path(__file__).resolve().parent
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


predecessor, = sys.argv[1:]
deadline = time.monotonic() + 1200
while time.monotonic() < deadline:
    try:
        state = json.loads((shared.DEFAULT_QUEUE / 'current.json').read_text())
    except (OSError, ValueError):
        time.sleep(1)
        continue
    if state.get('token') != predecessor or state.get('state') == 'released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed native eyebrow and hair stencil window has not opened')

with shared.lease(shared.DEFAULT_QUEUE, '01a1c099-8121-7be3-b0b8-7af2f9a06b2a', 'quality-native-eyebrow-hair-stencil', out) as lease:
    (out / 'lease-held.json').write_text(json.dumps(lease, indent=2) + '\n')
    command = [sys.executable, '-B', str(out / 'replay.py')]
    report = shared.maintenance.guarded_run(out.parents[1], out.name, command, 120)
    (out / 'replay-execution.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)
    assert report['status'] == 'exited' and report['exitCode'] == 0, report

(out / 'lease-released.json').write_text(json.dumps(lease, indent=2) + '\n')
assert lease['state'] == 'released'
