from hashlib import file_digest, sha256
from pathlib import Path
import json
import os
import subprocess
import zlib

import numpy as np


out = Path(__file__).resolve().parent
source = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc')
frozen_capture_sha = 'fa2ca267f7168f5603e83ad5f817a3074d8dbee23a216e6ab8ef2c340ec06a90'
with source.open('rb') as stream:
    assert file_digest(stream, 'sha256').hexdigest() == frozen_capture_sha
eyebrow = out.parent / '20261112-103417-eyebrow-receiver-producer-1f8f43/source-replay'
producers = out.parent / '20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry'
eyebrow_manifest = json.loads((eyebrow / 'report.json').read_text())['captures']
native_manifest = json.loads((producers / 'native-caster-geometry.json').read_text())['receiverDepth']


def plane(root, entry):
    raw = (root / entry['path']).read_bytes()
    assert sha256(raw).hexdigest() == entry['sha256']
    data = zlib.decompress(raw)
    if 'rawSha256' in entry:
        assert sha256(data).hexdigest() == entry['rawSha256']
    return np.frombuffer(data, '<u4').reshape(310, 290)


def eyebrow_plane(source_name, phase, field):
    return plane(eyebrow, eyebrow_manifest[source_name][phase][field]['crop'])


native_before = eyebrow_plane('native', 'before', 'normal')
native_brow = eyebrow_plane('native', 'after', 'normal')
native_final = eyebrow_plane('native', 'final', 'normal')
points = (native_before != native_brow) & (native_brow == native_final)
assert int(points.sum()) == 496
writers = eyebrow_manifest['player']['writers']
p0, p1 = [plane(eyebrow, writers[str(e)]['planes']['depth']['crop']) for e in (270, 274)]
n0, n1 = [plane(producers, native_manifest[str(e)]['crop']) for e in (421, 422)]
overlap = points & (p0 != p1)
assert int(overlap.sum()) == 135
assert np.array_equal(n0[overlap], n1[overlap])
before_delta = np.abs(p0[overlap].astype('i8') - n0[overlap].astype('i8'))
after_delta = p1[overlap].astype('i8') - n0[overlap].astype('i8')
assert int(before_delta.max()) == 1 and int(after_delta.min()) == 10771
xy = np.argwhere(overlap)[:, ::-1] + [1140, 1000]
selected = np.argsort(after_delta)[[0, 27, 54, 81, 108, 134]]
history = [{'point': xy[i].tolist(), 'kind': 'native-eyebrow-player-hair'} for i in selected]
native_hair = np.argwhere(~points & (n0 != n1))
assert len(native_hair) >= 100
for index in np.linspace(0, len(native_hair) - 1, 4, dtype='i4')[1:-1]:
    y, x = native_hair[index]
    history.append({'point': [int(x) + 1140, int(y) + 1000], 'kind': 'native-hair'})
folder = out / 'stencil-replay'
folder.mkdir()
request = folder / 'request.json'
request.write_text(json.dumps(dict(capture=str(source), captureSha256=frozen_capture_sha, output=str(folder),
    history=history, overlap=xy.tolist(), nativeEyebrow=(np.argwhere(points)[:, ::-1] + [1140, 1000]).tolist(),
    beforeMaxUlp=int(before_delta.max()), afterUlp=[int(after_delta.min()), int(after_delta.max())]), indent=2) + '\n')
env = os.environ.copy()
for key in ('VK_LAYER_PATH', 'VK_INSTANCE_LAYERS', 'ENABLE_VULKAN_RENDERDOC_CAPTURE',
        'VK_LOADER_DRIVERS_SELECT', 'VK_DRIVER_FILES', 'VK_ICD_FILENAMES'):
    env.pop(key, None)
env['AZURE_NATIVE_STENCIL_REQUEST'] = str(request)
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
command = ['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe', '--python', str(out / 'replay-worker.py')]
(folder / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (folder / 'process.log').open('wb') as log:
    proc = subprocess.run(command, env=env, startupinfo=startup, cwd=folder,
        stdout=log, stderr=subprocess.STDOUT, timeout=100)
report = json.loads((folder / 'report.json').read_text())
assert proc.returncode == 0 and report['status'] == 'qualified', report
with source.open('rb') as stream:
    assert file_digest(stream, 'sha256').hexdigest() == frozen_capture_sha
print(json.dumps({name: dict(device=item['device'], history=len(item['history']), readbacks=len(item['attachments']))
    for name, item in report['devices'].items()}))