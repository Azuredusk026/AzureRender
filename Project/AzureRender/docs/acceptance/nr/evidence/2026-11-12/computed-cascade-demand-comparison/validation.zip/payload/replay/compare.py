from hashlib import sha256
import json
from pathlib import Path
import sys
import traceback
import renderdoc as rd

out=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261112-011326-handoff-final-regression-e2e260/computed-cascade-demand-preflight/replay')
settings=json.loads((out/'settings.json').read_bytes())
prepared=json.loads((out/'qualification.json').read_bytes())
previous=json.loads((out/'previous-comparison.json').read_bytes())
profile=json.loads((out/'replay-profile.json').read_bytes())
report={'status':'starting','captureSha256':prepared['originalCaptureSha256'],'roles':['qualified','candidate','candidate','qualified'],
        'consecutiveWarmReplays':16,'comparisons':[],'timings':[]}
def save():
    (out/'ab-comparison.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def digest(data):
    return sha256(data).hexdigest()

controller=None
capture=None
try:
    save()
    capture=rd.OpenCaptureFile()
    assert capture.OpenFile(settings['capture'],'',None)==rd.ResultCode.Succeeded
    status,controller=capture.OpenCapture(rd.ReplayOptions(),None)
    assert status==rd.ResultCode.Succeeded
    assert prepared['originalCaptureSha256']==previous['captureSha256']==settings['captureSha256']
    originals=[]
    replacements={role:[] for role in ('qualified','candidate')}
    for row in prepared['programs']:
        controller.SetFrameEvent(row['event'],True)
        pipeline=controller.GetPipelineState()
        shader=pipeline.GetShader(rd.ShaderStage.Pixel)
        assert str(shader)==row['shader']
        reflection=pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
        assert digest(bytes(reflection.rawBytes))==profile['shaders'][row['shader']]['sha256']
        fragment=controller.GetVulkanPipelineState().fragmentShader
        assert {'ids':list(fragment.specializationIds),'dataHex':bytes(fragment.specializationData).hex()}==row['originalSpecialization']
        originals.append(shader)
        for role in replacements:
            program=(out/row[role]['path']).read_bytes()
            assert digest(program)==row[role]['sha256']
            resource,errors=controller.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,program,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
            assert resource!=rd.ResourceId.Null(),errors
            replacements[role].append(resource)
    assert len(originals)==10 and len(set(map(str,originals)))==10
    report['programs']=prepared['programs']
    events={row['event'] for row in profile['measurements']}
    assert len(events)==3453
    anchor=max(row['event'] for row in profile['measurements'] if row['kind']=='draw')
    controls={(row['event'],row['target']):row for row in previous['comparisons']}
    assert len(controls)==6
    scopes={k:set(v) for k,v in previous['eventScopes'].items()}
    assert len(scopes['materials'])==1006 and scopes['materials']<=events

    def apply(role):
        for original in originals:
            controller.RemoveReplacement(original)
        for original,new in zip(originals,replacements[role]):
            controller.ReplaceResource(original,new)

    def warm():
        for unused in range(report['consecutiveWarmReplays']):
            controller.SetFrameEvent(anchor,True)

    def read_target(event,index):
        controller.SetFrameEvent(event,True)
        target=controller.GetPipelineState().GetOutputTargets()[index]
        assert target.resource!=rd.ResourceId.Null()
        return bytes(controller.GetTextureData(target.resource,rd.Subresource()))

    def measure(role):
        warm()
        timing={int(row.eventId):float(row.value.d)*1000 for row in controller.FetchCounters([rd.GPUCounter.EventGPUDuration])}
        assert set(timing)==events
        report['timings'].append({'role':role,'milliseconds':timing,'totalMs':sum(timing.values()),
            'scopeMs':{scope:sum(timing[event] for event in group) for scope,group in scopes.items()}})
        save()

    apply('qualified')
    warm()
    baseline={}
    for (event,index),old in sorted(controls.items()):
        data=read_target(event,index)
        assert len(data)==old['bytes'] and digest(data)==old['candidateSha256'],(event,index)
        baseline[(event,index)]=data
    apply('candidate')
    warm()
    for (event,index),original in baseline.items():
        actual=read_target(event,index)
        report['comparisons'].append(dict(event=event,target=index,bytes=len(actual),qualifiedSha256=digest(original),
            candidateSha256=digest(actual),equal=actual==original,changedBytes=sum(x!=y for x,y in zip(actual,original))+abs(len(actual)-len(original))))
    report['allTargetsExact']=all(row['equal'] for row in report['comparisons'])
    report['status']='attachments-checked'
    save()
    if report['allTargetsExact']:
        apply('qualified')
        warm()
        measure('qualified')
        apply('candidate')
        measure('candidate')
        measure('candidate')
        apply('qualified')
        measure('qualified')
    report['status']='measured' if report['allTargetsExact'] else 'pixel-gate-failed'
    save()
except Exception:
    report.update(status='replay-failed',error=traceback.format_exc())
    save()
finally:
    if controller:
        controller.Shutdown()
    if capture:
        capture.Shutdown()
sys.exit(0 if report['status'] in ('measured','pixel-gate-failed') else 1)

