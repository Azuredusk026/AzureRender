from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import difflib
import json
import re
import subprocess
import sys
import time

root=Path.cwd().resolve()
output=Path(__file__).resolve().parent/'computed-cascade-demand-preflight'
output.mkdir(exist_ok=True)
shader_root=root/'shaders'
base_source=shader_root/'mesh.frag'
archive=root/'docs/acceptance/nr/evidence/2026-11-11/quad-cascade-demand-local-qualification/validation.zip'
catalog=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_bytes())
compiler=Path(catalog['compiler'])
validator=compiler.with_name('spirv-val.exe')
disassembler=compiler.with_name('spirv-dis.exe')
manifest={program['output']:program for program in catalog['programs']}
assert compiler.is_file() and validator.is_file() and disassembler.is_file()

with ZipFile(archive) as previous:
    names=[n.rsplit('combined-1090519040-',1)[1]+'.spv' for n in previous.namelist() if n.startswith('candidate-source/') and n.endswith('.frag')]
assert len(names)==len(set(names))==10 and all(name in manifest for name in names)
baseline=base_source.read_text(encoding='utf-8')
before,separator,suffix=baseline.partition('void prepareShadowReceiver() {')
assert separator and 'float sampleShadowMap' in suffix
receiver,separator2,after=suffix.partition('float sampleShadowMap')
original=receiver
declaration='    selectedShadowReceiver=azureEmptyShadowReceiver();\n'
assert receiver.count(declaration)==1
receiver=receiver.replace(declaration,declaration+'''    uint receiverMask=1u<<uint(shadowReceiverCascade);
    if(shadowReceiverCascade<3)receiverMask|=receiverMask<<1u;
    uint quadReceiverMask=subgroupQuadBroadcast(receiverMask,0u)|subgroupQuadBroadcast(receiverMask,1u)
        |subgroupQuadBroadcast(receiverMask,2u)|subgroupQuadBroadcast(receiverMask,3u);
''')
for index in range(4):
    block=f'    {{const int i={index};'
    assert receiver.count(block)==1
    receiver=receiver.replace(block,f'''#if defined(AZURE_COMPUTED_MATERIAL_VIEW)
    if((quadReceiverMask & {1<<index}u)!=0u)
#endif
'''+block)
candidate=before+separator+receiver+separator2+after
candidate_source=output/'mesh.frag'
candidate_source.write_text(candidate,encoding='utf-8',newline='\n')
(output/'source.patch').write_text(''.join(difflib.unified_diff(baseline.splitlines(keepends=True),candidate.splitlines(keepends=True),
                  fromfile='a/shaders/mesh.frag',tofile='b/shaders/mesh.frag')),encoding='utf-8',newline='\n')

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def program(name,role,source,defines,arguments):
    path=output/f'{role}-{name}'
    cmd=[str(compiler),*['-D'+d for d in defines],*arguments,'-I'+str(shader_root),str(source),'-o',str(path)]
    compiled=subprocess.run(cmd,cwd=root,capture_output=True,check=True,timeout=45)
    validated=subprocess.run([str(validator),'--target-env','vulkan1.3','--relax-block-layout',str(path)],cwd=root,capture_output=True,check=True,timeout=45)
    assembly=subprocess.check_output([str(disassembler),str(path)],cwd=root,text=True,encoding='utf-8',timeout=30)
    return {'path':path.name,'sha256':digest(path),'bytes':path.stat().st_size,
            'derivativeOps':len(re.findall(r'\bOpDPd[xy](?:Fine|Coarse)?\b',assembly)),
            'quadBroadcasts':len(re.findall(r'\bOpGroupNonUniformQuadBroadcast\b',assembly)),'command':cmd,'validated':True}

start=time.monotonic()
rows=[]
for name in names:
    entry=manifest[name]
    defines=entry['defines']
    arguments=entry['arguments']
    standard=program(name,'standard-candidate',candidate_source,defines,arguments)
    production=Path(catalog['binaryRoot'])/name
    assert standard['sha256']==digest(production),name
    defines=['AZURE_COMPUTED_MATERIAL_VIEW=1','AZURE_FRAGMENT_QUAD_OPERATIONS=1',*defines]
    args=['--target-env=vulkan1.1']
    reference=program(name,'computed-reference',base_source,defines,args)
    experimental=program(name,'computed-candidate',candidate_source,defines,args)
    assert reference['sha256']!=experimental['sha256']
    assert experimental['derivativeOps']==reference['derivativeOps']
    assert experimental['quadBroadcasts']==reference['quadBroadcasts']+4
    rows.append(dict(name=name,standardUnchanged=True,standard=standard,reference=reference,candidate=experimental))
    print(name,'standard byte exact, computed derivative op count',experimental['derivativeOps'],flush=True)
source_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
record={'scope':'offline-computed-cascade-guard-preflight','sourceRevision':source_revision,'sourceSha256':digest(base_source),
        'inputArchiveSha256':digest(archive),'programs':rows,'matchedStandardPrograms':len(rows),'noProductionChanges':True,
        'requiresActualImageAndLocalTimingQualification':True,'seconds':time.monotonic()-start}
(output/'results.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'matched':len(rows),'seconds':record['seconds'],'receipt':str(output/'results.json')}))
