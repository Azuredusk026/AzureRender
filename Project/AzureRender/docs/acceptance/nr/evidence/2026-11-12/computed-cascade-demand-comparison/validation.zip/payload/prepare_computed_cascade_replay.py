from pathlib import Path, PurePosixPath
from zipfile import ZipFile
from io import BytesIO
from hashlib import sha256
import json
import subprocess
import time

root=Path.cwd().resolve()
out=Path(__file__).resolve().parent/'computed-cascade-demand-preflight'
replay=out/'replay'
replay.mkdir(exist_ok=True)
archive=root/'docs/acceptance/nr/evidence/2026-11-11/quad-depth-visibility/validation.zip'
source_commit='88d84fb'
prefix=PurePosixPath('Project/AzureRender/shaders')
shader_root=replay/'shaders'
archive_bytes=subprocess.check_output(['git','archive','--format=zip',source_commit,'--',prefix.as_posix()],cwd=root.parents[1])
with ZipFile(BytesIO(archive_bytes)) as files:
    for entry in files.infolist():
        if entry.is_dir():
            continue
        rel=PurePosixPath(entry.filename).relative_to(prefix)
        assert not rel.is_absolute() and '..' not in rel.parts
        destination=shader_root.joinpath(*rel.parts)
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(files.read(entry))

def digest(data):
    return sha256(data).hexdigest()

def emit_candidate(text):
    head,token,tail=text.partition('void prepareShadowReceiver() {')
    body,end,rest=tail.partition('float sampleShadowMap')
    assert token and end
    point='    selectedShadowReceiver=azureEmptyShadowReceiver();\n'
    assert body.count(point)==1
    body=body.replace(point,point+'''    uint receiverMask=1u<<uint(shadowReceiverCascade);
    if(shadowReceiverCascade<3)receiverMask|=receiverMask<<1u;
    uint quadReceiverMask=subgroupQuadBroadcast(receiverMask,0u)|subgroupQuadBroadcast(receiverMask,1u)
        |subgroupQuadBroadcast(receiverMask,2u)|subgroupQuadBroadcast(receiverMask,3u);
''')
    for index in range(4):
        block=f'    {{const int i={index};'
        assert body.count(block)==1
        body=body.replace(block,f'    if((quadReceiverMask & {1<<index}u)!=0u){{const int i={index};')
    return head+token+body+end+rest

start=time.monotonic()
rows=[]
with ZipFile(archive) as previous:
    (shader_root/'selected_receiver.glsl').write_bytes(previous.read('combined/candidate-source/selected_receiver.glsl'))
    provenance=json.loads(previous.read('combined/compare-state.json'))
    assert provenance['allTargetsEqual'] and len(provenance['programs'])==10
    (replay/'previous-comparison.json').write_bytes(previous.read('combined/compare-state.json'))
    (replay/'replay-profile.json').write_bytes(previous.read('combined/replay-profile.json'))
    for item in provenance['programs']:
        filename=item['file']
        original=previous.read('combined/'+filename)
        assert digest(original)==item['candidateSha256']
        previous_build=json.loads(previous.read(f'combined/{filename}.build.json'))
        previous_command=previous_build['command']
        assert previous_build['returncode']==0 and '-o' in previous_command
        compiler=Path(previous_command[0])
        validator=compiler.with_name('spirv-val.exe')
        args=[v for v in previous_command[1:] if v.startswith('-D') or v.startswith('--target-env=')]
        assert '--target-env=vulkan1.1' in args
        source_name=f"combined-{item['shadowRadiusBits']}-{filename[:-4]}"
        source=previous.read('combined/candidate-source/'+source_name).decode().replace('\r\n','\n')
        original_source=replay/f'qualified-{source_name}'
        original_source.write_text(source,encoding='utf-8',newline='\n')
        private_source=replay/f'candidate-{source_name}'
        private_source.write_text(emit_candidate(source),encoding='utf-8',newline='\n')
        built={}
        for role,path in [('qualified',original_source),('candidate',private_source)]:
            product=replay/f'{role}-{filename}'
            command=[str(compiler),*args,'-I'+str(shader_root),str(path),'-o',str(product)]
            result=subprocess.run(command,cwd=root,capture_output=True,check=True,timeout=45)
            subprocess.run([str(validator),'--target-env','vulkan1.3','--relax-block-layout',str(product)],cwd=root,capture_output=True,check=True,timeout=45)
            product_sha=digest(product.read_bytes())
            if role=='qualified':
                assert product_sha==item['candidateSha256'],(filename,product_sha,item['candidateSha256'])
            else:
                assert product_sha!=item['candidateSha256']
            built[role]={'path':product.name,'sha256':product_sha,'command':command}
        rows.append(dict(file=filename,event=item['event'],shader=item['shader'],originalSpecialization=item['originalSpecialization'],**built))
        print(filename,'qualified baseline exact and candidate validated',flush=True)

receipt={'status':'ready-for-local-replay','originalCaptureSha256':provenance['captureSha256'],
         'sourceBase':source_commit,'archiveSha256':digest(archive.read_bytes()),
         'programs':rows,'seconds':time.monotonic()-start}
(replay/'qualification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')


