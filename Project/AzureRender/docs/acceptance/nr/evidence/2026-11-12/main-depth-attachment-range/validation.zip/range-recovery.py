from copy import deepcopy
from hashlib import file_digest
import json
import os
from pathlib import Path
import subprocess
import sys
import time

run=Path(__file__).resolve().parent
engine=run.parents[2]
out=run/'depth-split-range-recovery'
out.mkdir(exist_ok=False)
sys.path.insert(0,str(engine/'tools'))
from create_visibility_fixture import create
from build_provenance import inputs,verify
from artifact_maintenance import managed_environment

project=create(out/'fixture',outline=False)
scene=project.parent/'assets/scene.azurelevel'
document=json.loads(scene.read_bytes())
template=document['nodes'][0]
document['nodes']=[]
for index in range(384):
    node=deepcopy(template)
    node['id']=f'surface-{index:03d}'
    node['components']['azure.transform']['data']['translation']=[(index%16-8)*.0125,(index//16-12)*.0125,0]
    document['nodes'].append(node)
document['renderSettings']['sceneLighting']=True
scene.write_text(json.dumps(document,indent=2)+'\n')
environment=dict(os.environ,**managed_environment(out/'tmp'))
for name in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LAYER_ENABLES'):
    environment.pop(name,None)
environment['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'

def invoke(name,args,timeout,env=environment):
    start=time.monotonic()
    with (out/(name+'.log')).open('wb') as log, subprocess.Popen(args,cwd=engine,env=env,stdout=log,
            stderr=subprocess.STDOUT) as p:
        try:
            code=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill.exe','/PID',str(p.pid),'/T','/F'],stdout=log,stderr=subprocess.STDOUT)
            p.wait(timeout=30)
            raise
    if code:
        raise RuntimeError((name,code,(out/(name+'.log')).read_text(errors='replace')[-6000:]))
    return time.monotonic()-start

def capture(config,label,disable=False):
    build=engine/f'build/ninja-msvc-{config.lower()}'
    frames=out/label
    argv=[str(build/'AzurePlayer.exe'),'--project',str(project),'--width','480','--height','270',
        '--qa-camera','full-body-front','--qa-light','scene','--qa-isolation','beauty','--capture-frames','1',
        '--fixed-frame-step','--capture-dir',str(frames),'--resource-root',str(build)]
    if disable:
        argv.append('--disable-gpu-culling')
    duration=invoke(label,argv,130,dict(environment,PATH=str(build)+os.pathsep+environment['PATH']))
    data=json.loads((frames/'capture_manifest.json').read_bytes())
    logs=(out/(label+'.log')).read_text(errors='replace')
    assert 'Allocator after unload: buffers=0 images=0' in logs and 'VUID-' not in logs
    with (frames/'frame_000000.png').open('rb') as stream:
        image=file_digest(stream,'sha256').hexdigest()
    return {'seconds':duration,'imageSha256':image,'conservativePrepared':data.get('conservativeOcclusionPrepared'),
        'splitRecorded':data.get('mainDepthSplitRecorded'),'commands':data.get('conservativeOcclusionCommands'),
        'fallback':data.get('conservativeOcclusionFallback'),'command':argv}

baseline=capture('Release','baseline-release')
(out/'baseline-fixture.json').write_text(json.dumps(baseline,indent=2)+'\n')
print('baseline fixture',baseline['splitRecorded'],baseline['commands'],baseline['fallback'],flush=True)
results={}
for config in ('Debug','Release'):
    label=config.lower()
    elapsed=invoke(label+'-build',[sys.executable,'-X','utf8','-B',str(run/'full.py'),
        'build',config,'--inside'],1730)
    active=capture(config,label+'-split')
    fallback=capture(config,label+'-fallback',True)
    results[label]=dict(buildSeconds=elapsed,split=active,fallback=fallback)
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(config,'split',active['splitRecorded'],active['commands'],active['fallback'],flush=True)
    proof=json.loads((run/f'{label}-products.json').read_bytes())
    assert proof['source']==inputs(engine)
    verify(engine,proof)
    assert active['splitRecorded'] and active['commands']>=256 and not fallback['splitRecorded']
    assert active['imageSha256']==fallback['imageSha256']==baseline['imageSha256']
