from pathlib import Path
import hashlib
import json
import subprocess
import sys


out = Path(__file__).resolve().parent
configuration = sys.argv[1]
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration == 'Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
prior = out.parent / '20261111-213928-scene-reference-depth-728062/release-verification.json'
old = json.loads(prior.read_text())['sha256']
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
catalog = {p.name: sha(p) for p in (build / 'shaders').glob('*.spv')}
added = sorted(catalog.keys() - old.keys())
changed = sorted(name for name in old if name in catalog and old[name] != catalog[name])
assert not old.keys() - catalog.keys()
assert added == ['character_snapshot_depth_visibility_compute_reference_camera.vert.spv', 'character_snapshot_depth_visibility_reference_camera.vert.spv', 'reference_scene_visibility.frag.spv', 'reference_scene_visibility_bindless.frag.spv'], added
assert not changed, changed
assert len(catalog) <= 1024
validator = 'D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe'
prefix = configuration.lower()
with (out / (prefix + '-spirv.log')).open('wb') as log:
    for name in added + changed:
        subprocess.run([validator, '--target-env', 'vulkan1.2', str(build / 'shaders' / name)],
            stdout=log, stderr=subprocess.STDOUT, check=True)
ctest = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
regex = '^(AzureRender[.](ReferenceCameraView|ReferenceCameraBinding|ExtensionRegistry)|AzureEngine[.]ProjectReferenceViews)$'
if '--gpu' in sys.argv:
    regex = '^AzureRender[.]ReferenceDepth(Coverage)?Gpu$'
    prefix += '-gpu'
command = [ctest, '--test-dir', str(build), '-R', regex, '--no-tests=error', '--output-on-failure',
    '--output-junit', str(out / (prefix + '-ctest.xml'))]
with (out / (prefix + '-ctest.log')).open('wb') as log:
    test = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=280)
report = dict(configuration=configuration, count=len(catalog), unchanged=len(old) - len(changed),
    changed=changed, added=added, validated=len(changed) + len(added), sha256=catalog,
    ctestCommand=command, ctestExit=test.returncode, playerSha256=sha(build / 'AzurePlayer.exe'))
(out / (prefix + '-verification.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'sha256'}))
assert test.returncode == 0, (out / (prefix + '-ctest.log')).read_text(errors='replace')
