from pathlib import Path
import json
import zipfile

import numpy as np


out = Path(__file__).resolve().parent
native_source = json.loads((out/'normal-source-inspection.json').read_text())
native = np.fromfile(native_source['nativeNormalPath'],'<u4').reshape(1440,2560)
reports={}
for case in ('baseline','ellipse','implicit','reference-frame'):
    folder=out/('nvidia-normal-visibility-control-'+case)
    if not (folder/'summary.json').is_file():
        continue
    summary=json.loads((folder/'summary.json').read_text())
    queries=np.fromfile(folder/'queries.bin','<f4').reshape(-1,4)
    x,y=queries[:,:2].astype('i4').T
    frozen=np.fromfile(folder/'expected.bin','<u4').astype('i4')
    actual=np.fromfile(folder/'nvidia-live-normal-source-rg8.bin','u1').reshape(-1,2)[:,1].astype('i4')
    name='scene-native-basis-normals.bin'
    if (folder/name).is_file():
        plane=np.fromfile(folder/name,'<u4')
    else:
        entry=json.loads((folder/'reference-planes.json').read_text())[name]['archiveEntry']
        with zipfile.ZipFile(folder/'reference-planes.zip') as archive:
            plane=np.frombuffer(archive.read(entry),'<u4')
    packed=plane.reshape(1440,2560)[y,x]
    reference=native[y,x]
    code=lambda plane,shift: ((plane>>shift)&1023).astype('i4')
    normal_delta=np.stack([code(packed,shift)-code(reference,shift) for shift in (0,10)],axis=1)
    visibility_delta=actual-frozen
    failures=np.flatnonzero(np.abs(visibility_delta)>1)
    assert len(failures)==17017-summary['withinOnePixels']
    reports[case]=dict(exact=summary['exactPixels'],overOne=len(failures),maxError=summary['maximumByteError'],
        signedCodeDifference=[{int(value):int(count) for value,count in zip(*np.unique(delta,return_counts=True))} for delta in normal_delta.T],
        errors=[dict(pixel=[int(x[i]),int(1439-y[i])],visibilityDelta=int(visibility_delta[i]),normalDelta=normal_delta[i].tolist(),
            nativeNormal=[int(code(reference,0)[i]),int(code(reference,10)[i])],
            sceneNormal=[int(code(packed,0)[i]),int(code(packed,10)[i])]) for i in failures])
if {'baseline','ellipse'}<=reports.keys():
    first={tuple(row['pixel']) for row in reports['baseline']['errors']}
    second={tuple(row['pixel']) for row in reports['ellipse']['errors']}
    reports['closed']=sorted(first-second)
    reports['introduced']=sorted(second-first)
(out/'normal-visibility-intersection.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports))
