from pathlib import Path
from hashlib import file_digest
import json
import shutil
import subprocess
import sys


out = Path(__file__).resolve().parent
engine = out.parents[2]
build = (out.parent / '20261110-031856-hair-main-chroma-debug-668bf2/debug').resolve(strict=True)
assert build.parent.parent == out.parent and build.is_dir() and not build.is_symlink()
execution = json.loads((out / 'debug-final-build-execution.json').read_text())
assert execution['status'] == 'budget-stopped'
queue = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_text())
assert queue['state']=='released' or queue['owner']!='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'

ninja = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
targets = ['AzurePlayer','AzureReferenceCameraViewTests','AzureProjectReferenceViewsTests',
    'AzureRenderExtensionRegistryTests','AzureReferenceCameraBindingTests']
command = [ninja, '-C', str(build), '-n', *targets]
plan = subprocess.check_output(command, text=True)
(out / 'debug-recovery-dry-run.log').write_text(plan)
for target in ('AzureRuntime.lib','AzurePlayerHost.lib','AzurePlayer.exe'):
    assert ' '+target in plan, target
declarations = (build / 'build.ninja').read_text(encoding='utf-8')
assert 'TARGET_PDB = AzurePlayer.pdb' in declarations
assert 'TARGET_PDB = AzureMaterialCoverageTests.pdb' in declarations

sys.path.insert(0, str(engine / 'tools'))
from artifact_maintenance import measure

shutil.copyfile(out / 'debug-final-build-execution.json', out / 'debug-budget-stopped-execution.json')
shutil.copyfile(out / 'debug-build.log', out / 'debug-budget-stopped-build.log')
before = measure(build.parent)
files = {'AzureRuntime.lib':205266672, 'AzurePlayerHost.lib':74728762,
    'AzurePlayer.pdb':125841408, 'AzureMaterialCoverageTests.pdb':22048768}
receipts = []
for name, expected_bytes in files.items():
    path = build / name
    assert path.resolve(strict=True).parent == build and path.is_file() and not path.is_symlink()
    stat = path.stat()
    assert stat.st_nlink==1 and stat.st_size==expected_bytes, (name,stat.st_size,expected_bytes)
    ignored = subprocess.run(['git','-C',str(engine),'check-ignore','-q',str(path)])
    assert ignored.returncode==0, path
    with path.open('rb') as source:
        digest = file_digest(source, 'sha256').hexdigest()
    receipts.append(dict(name=name, path=str(path), bytes=stat.st_size, sha256=digest,
        regeneratedByThisBuild=name!='AzureMaterialCoverageTests.pdb'))
for receipt in receipts:
    (build / receipt['name']).unlink()
after = measure(build.parent)
assert before - after == sum(item['bytes'] for item in receipts)
(out / 'debug-link-budget-recovery.json').write_text(json.dumps(dict(before=before,after=after,files=receipts,
    retainedPlayer=str(build / 'AzurePlayer.exe'),dryRun=command),indent=2) + '\n')
print(json.dumps(dict(before=before,after=after,removed=[item['name'] for item in receipts])))
