from pathlib import Path
import base64
import hashlib
import json
import runpy
import struct

import numpy as np


prep = Path(__file__).resolve().parent
run = prep.parent if prep.name == 'next-input-prep' else prep.parent / '20261111-213928-scene-reference-depth-728062'
main = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f')
baseline = runpy.run_path(str(run.parent / '20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
ys, xs = np.nonzero(baseline['mask'])
assert len(xs) == 17017
x, y = xs + 1140, 1439 - (ys + 130)
normal_path = main / 'native-t6.bin'
normal = normal_path.read_bytes()
normal_sha = hashlib.sha256(normal).hexdigest()
assert normal_sha == '63731d707e7ba30d9417049c8148b9bd2167208e435e8d9f0cc100a1fd03e095'
target = np.frombuffer(normal, dtype='<u4').reshape(1440, 2560)[y, x]
packed = [(target >> shift) & mask for shift, mask in ((0,1023),(10,1023),(20,1023),(30,3))]
channel_stats = [dict(minimum=int(channel.min()), maximum=int(channel.max()), unique=int(len(np.unique(channel))))
    for channel in packed]
alpha_values, alpha_counts = np.unique(packed[3], return_counts=True)
alpha_histogram = {str(value): int(count) for value, count in zip(alpha_values, alpha_counts)}

asset = run / 'hair-project/character/hair-coverage.glb'
with asset.open('rb') as file:
    magic, version, total, json_size, json_kind = struct.unpack('<4sIIII', file.read(20))
    assert magic == b'glTF' and version == 2 and total == asset.stat().st_size and json_kind == 0x4e4f534a
    document = json.loads(file.read(json_size))
    bin_size, bin_kind = struct.unpack('<II', file.read(8))
    assert bin_kind == 0x004e4942
    bin_offset = file.tell()
    rows = []
    for index, material in enumerate(document['materials']):
        alpha = material.get('alphaMode', 'OPAQUE')
        if alpha == 'BLEND':
            continue
        profile = material.get('extras', {}).get('azureRenderMaterial', {})
        row = dict(index=index, name=material.get('name'), alphaMode=alpha, profileClass=profile.get('class'),
            snapshotNormal=profile.get('hair', {}).get('projectedRamp', {}).get('snapshotNormal'))
        if 'normalTexture' in material:
            normal_slot = material['normalTexture']
            texture = document['textures'][normal_slot['index']]
            image = document['images'][texture['source']]
            row.update(texture=normal_slot, sampler=document['samplers'][texture['sampler']] if 'sampler' in texture else None)
            if 'bufferView' in image:
                buffer = document['bufferViews'][image['bufferView']]
                assert buffer.get('buffer', 0) == 0 and buffer['byteOffset'] + buffer['byteLength'] <= bin_size
                file.seek(bin_offset + buffer['byteOffset'])
                data = file.read(buffer['byteLength'])
                row['image'] = dict(embedded=True, format=image.get('mimeType'), bytes=len(data),
                    sha256=hashlib.sha256(data).hexdigest())
            elif image['uri'].startswith('data:'):
                header, payload = image['uri'].split(',', 1)
                assert header.endswith(';base64')
                data = base64.b64decode(payload, validate=True)
                row['image'] = dict(embedded=True, format=header[5:-7], bytes=len(data),
                    sha256=hashlib.sha256(data).hexdigest())
            else:
                path = (asset.parent / image['uri']).resolve(strict=True)
                path.relative_to(asset.parent.resolve())
                row['image'] = dict(embedded=False, path=str(path), bytes=path.stat().st_size,
                    sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        rows.append(row)
hair = next(row for row in rows if row['index'] == 9)
assert hair['alphaMode'] == 'MASK' and hair['name'] == 'M_actor_laevat_hair_01'
qualified = main.parent / '20261103-234012-character-reference-stages-5abe6c/public-screen-normal-static/materials'
material_path = qualified / '596a1696-19c2-57af-b0dc-378a6effa15b.azurematerial'
material = json.loads(material_path.read_text(encoding='utf-8-sig'))
material_data = material['surface']['materials'][0]
normal_slot = material_data['normalTexture']['index']
assert material['textures'][str(normal_slot)]['asset'] == '8f873e5f-9141-59f1-a941-e044877267cb'
assert material_data['extras']['azureRenderMaterial']['hair']['projectedRamp']['snapshotNormal'] == 'material-normal-rg'
normal_image = qualified / 'captured-hair-normal.dds'
metadata_path = normal_image.with_suffix('.dds.azmeta')
metadata = json.loads(metadata_path.read_text(encoding='utf-8-sig'))
assert metadata['id'] == material['textures'][str(normal_slot)]['asset']
dds = normal_image.read_bytes()
assert dds[:4] == b'DDS '
height, width = struct.unpack_from('<II', dds, 12)
mip_count = struct.unpack_from('<I', dds, 28)[0]
surface_texture = material['surface']['textures'][normal_slot]
sampler_index = surface_texture.get('sampler')
authored = dict(material=str(material_path), materialSha256=hashlib.sha256(material_path.read_bytes()).hexdigest(),
    normalAsset=metadata['id'], path=str(normal_image), sha256=hashlib.sha256(dds).hexdigest(), bytes=len(dds),
    extent=[width, height], mipLevels=mip_count, fourCC=dds[84:88].decode('ascii', errors='replace'),
    dxgiFormat=struct.unpack_from('<I',dds,128)[0] if dds[84:88]==b'DX10' else None,
    sidecarSampler=metadata['settings'].get('texture'), surfaceSampler=None if sampler_index is None
        else material['surface']['samplers'][sampler_index])
report = dict(nativeNormalPath=str(normal_path), nativeNormalSha256=normal_sha, nativeExtent=[2560,1440],
    hairMaskPoints=len(target), nativeChannelStats=channel_stats, nativeAlphaHistogram=alpha_histogram,
    nativeHairWordsSha256=hashlib.sha256(target.tobytes()).hexdigest(), actualMaterialInputs=rows, authoredHairNormal=authored)
(prep / 'normal-source-inspection.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(hairMaterial=hair, nativeAlphaHistogram=alpha_histogram, nativeChannelStats=channel_stats, authoredHairNormal=authored)))
