from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys


out = Path(__file__).resolve().parent
sys.path.insert(0,str(out.parents[2]/'tools'))
from native_render.light_lab import generate


build = out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
player = build/'AzurePlayer.exe'
fingerprint = hashlib.sha256(player.read_bytes()).hexdigest()
assert fingerprint=='c1e644f2be57bedcf415ecfc79b81974b673043ff7c1e830ff01e57af0cdf2ad'
fixture = out/'configuration-red'
generate(fixture,'dark')
config = fixture/'config'
config.mkdir()
profile = dict(schemaVersion=1,frame=dict(schemaVersion=1,axes=[1,2,3],offset=[0,0,0]),
    projection=dict(schemaVersion=1,columns=[[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]],jitter=[0,0]),
    extent=[128,128],depthConvention='reversed',flipNdcY=False,produceSceneDepth=True,produceSceneVisibilityInputs=True)
(config/'reference-views.json').write_text(json.dumps(dict(schemaVersion=1,views={'red':profile}),indent=2))
env = os.environ.copy()
for key in ('VK_INSTANCE_LAYERS','VK_LOADER_DRIVERS_SELECT','VK_DRIVER_FILES','VK_ICD_FILENAMES'):
    env.pop(key,None)
env['VK_DRIVER_FILES']=str(fixture/'unavailable-driver.json')
command=[str(player),'--project',str(fixture/'lab.azureproject'),'--smoke-frames','1','--resource-root',str(build)]
result=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=25)
(out/'runtime-red.log').write_text(result.stdout)
assert result.returncode!=0 and 'Unexpected reference camera fields' in result.stdout,result.stdout
assert 'Starting logical device' not in result.stdout and 'Starting window' not in result.stdout,result.stdout
(out/'runtime-red-result.json').write_text(json.dumps(dict(baseCommit='7044017',command=command,exitCode=result.returncode,
    expectedMissingField='produceSceneVisibilityInputs',programSha256=fingerprint,initializedGraphics=False),indent=2)+'\n')
print(result.stdout)
