from pathlib import Path
import json
import os
import shutil
import sys
import time


out=Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def run(task, receipt, script, *args):
    result=shared.maintenance.guarded_run(out.parents[1],task,[sys.executable,str(out/script),*args],900)
    (out/(receipt+'-execution.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    assert result['status']=='exited' and result['exitCode']==0,result


token=sys.argv[1]
queue=shared.DEFAULT_QUEUE/'current.json'
deadline=time.monotonic()+1800
while time.monotonic()<deadline:
    try:
        state=json.loads(queue.read_text())
    except (OSError,ValueError):
        time.sleep(1)
        continue
    if state.get('token')!=token or state.get('state')=='released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed build batch has not released the queue')
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key,None)
os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',
    VK_LAYER_VALIDATE_SYNC='1')
parent='20261110-030251-hair-main-chroma-public-9e799c'
with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-scene-reference-normal-ellipse',out):
    for name in ('release-build.log','release-final-build-execution.json','release-verification.json'):
        previous=out/('baseline-'+name)
        if not previous.exists():shutil.copyfile(out/name,previous)
    try:
        run(out.name,'baseline-normal-visibility','normal-visibility-control.py',str(out/'release-nvidia-fixed-frames'),'nvidia','baseline')
    except AssertionError as error:
        print('Baseline visibility collection requires follow-up:',error,flush=True)
    shared.maintenance.resume(out.parents[1],parent)
    run(parent,'release-final-build','build.py','Release')
    run(out.name,'release-nvidia-fixed-ellipse','capture-normal.py','Release','nvidia','fixed','ellipse')
    run(out.name,'ellipse-normal-visibility','normal-visibility-control.py',str(out/'release-nvidia-fixed-ellipse-frames'),'nvidia','ellipse')
