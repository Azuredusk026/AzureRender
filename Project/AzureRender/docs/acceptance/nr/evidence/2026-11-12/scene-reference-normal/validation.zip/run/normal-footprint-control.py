from pathlib import Path
import io
import json
import struct
import zipfile

import numpy as np
from PIL import Image


out=Path(__file__).resolve().parent
root=out.parents[2]
vertex=Path(json.loads((out/'normal-vertex-comparison.json').read_text())['nativePath'])
values=np.fromfile(vertex,'<f4').reshape(-1,23).astype('f8')
indices=np.fromfile(vertex.with_name('422-index.bin'),'<u2').reshape(-1,3)
with zipfile.ZipFile(root/'docs/acceptance/nr/evidence/2026-11-10/raster-primitive-depth-model/validation.zip') as source:
    queries=np.frombuffer(source.read('inputs/queries.bin'),'<f4').reshape(-1,4)
    primitives=np.frombuffer(source.read('run/nvidia-primitive-selected.bin'),'<f4').astype('i4')
assert len(queries)==len(primitives)==17017 and primitives.min()>=0 and primitives.max()<len(indices)
pixel=queries[:,:2].astype('i4')
triangles=values[indices[primitives]]
clip=triangles[:,:,:4]
screen=(clip[:,:,:2]/clip[:,:,3:4]*[1280,-720])+[1280,720]
inverse_w=1/clip[:,:,3]
source=out/'normal-source-inspection.json'
record=json.loads(source.read_text())
frozen=np.fromfile(record['nativeNormalPath'],'<u4').reshape(1440,2560)[pixel[:,1],pixel[:,0]]
expected=np.stack((frozen&1023,(frozen>>10)&1023),axis=1).astype('i4')
dds=Path(record['authoredHairNormal']['path']).read_bytes()
assert dds[84:88]==b'DX10' and struct.unpack_from('<I',dds,128)[0]==98
size=2048
offset=148
mips=[]
for level in range(12):
    extent=max(size>>level,1)
    length=((extent+3)//4)**2*16
    header=bytearray(dds[:148])
    struct.pack_into('<III',header,12,extent,extent,length)
    struct.pack_into('<I',header,28,1)
    with Image.open(io.BytesIO(header+dds[offset:offset+length])) as image:
        mips.append(np.asarray(image.convert('RGBA'),dtype='f8')[:,:,:2]/255)
    offset+=length
assert offset==len(dds)


def interpolation(points,vertices):
    first,second=vertices[:,1]-vertices[:,0],vertices[:,2]-vertices[:,0]
    p=points-vertices[:,0]
    determinant=first[:,0]*second[:,1]-first[:,1]*second[:,0]
    valid=np.abs(determinant)>1.e-15
    u=np.divide(p[:,0]*second[:,1]-p[:,1]*second[:,0],determinant,where=valid,out=np.zeros(len(points)))
    v=np.divide(first[:,0]*p[:,1]-first[:,1]*p[:,0],determinant,where=valid,out=np.zeros(len(points)))
    weights=np.stack((1-u-v,u,v),axis=1)*inverse_w
    weights/=weights.sum(axis=1,keepdims=True)
    return np.sum(weights[:,:,None]*triangles,axis=1),valid


def sample(uv,levels):
    result=np.zeros((len(uv),2))
    for level in np.unique(levels):
        hit=levels==level
        image=mips[level]
        extent=image.shape[0]
        texel=uv[hit]*extent-.5
        lo=np.floor(texel).astype('i4')
        factor=texel-lo
        x0,y0=(lo%extent).T
        x1,y1=((lo+1)%extent).T
        a=image[y0,x0]*(1-factor[:,0:1])+image[y0,x1]*factor[:,0:1]
        b=image[y1,x0]*(1-factor[:,0:1])+image[y1,x1]*factor[:,0:1]
        result[hit]=a*(1-factor[:,1:2])+b*factor[:,1:2]
    return result


def encode(fields,texture):
    normal=fields[:,9:12]
    tangent=fields[:,12:15]
    bitangent=np.cross(normal,tangent)*fields[:,15:16]
    xy=texture*2-1
    z=np.sqrt(np.maximum(0,1-np.sum(xy*xy,axis=1,keepdims=True)))
    n=tangent*xy[:,0:1]+bitangent*xy[:,1:2]+normal*z
    oct=n[:,[0,2]]/np.abs(n).sum(axis=1,keepdims=True)
    folded=(1-np.abs(oct[:,::-1]))*np.where(oct>=0,1,-1)
    oct=np.where(n[:,1:2]<0,folded,oct)
    return np.rint((oct*.5+.5)*1023).astype('i4')


def decode(codes):
    oct=codes*2/1023-1
    y=1-np.abs(oct).sum(axis=1)
    folded=(1-np.abs(oct[:,::-1]))*np.where(oct>=0,1,-1)
    x,z=np.where(y[:,None]<0,folded,oct).T
    normal=np.stack((x,y,z),axis=1)
    return normal/np.linalg.norm(normal,axis=1,keepdims=True)


expected_direction=decode(expected)
rows=[]
capture=out/'release-nvidia-fixed-frames/reference-normals-a2b10g10r10.bin'
targets=[]
planes=capture.parent/'reference-planes.zip'
if capture.is_file() or planes.is_file():
    if capture.is_file():
        raw=capture.read_bytes()
    else:
        manifest=json.loads((capture.parent/'reference-planes.json').read_text())
        with zipfile.ZipFile(planes) as archive:
            raw=archive.read(manifest[capture.name]['archiveEntry'])
    live=np.frombuffer(raw,'<u4').reshape(1440,2560)[pixel[:,1],pixel[:,0]]
    live_code=np.stack((1023-(live&1023),(live>>10)&1023),axis=1).astype('i4')
    targets=np.flatnonzero(np.abs(live_code-expected).max(axis=1)>1)
probes=[]
for snap in (False,True):
    vertices=np.rint(screen*256)/256 if snap else screen
    fields,valid=interpolation(pixel+.5,vertices)
    quad=(pixel&~1)+.5
    uv=[interpolation(quad+shift,vertices)[0][:,4:6] for shift in ([0,0],[1,0],[0,1],[1,1])]
    for row in (0,1):
        dx=(uv[2*row+1]-uv[2*row])*size
        dy=(uv[2]-uv[0])*size
        dx2=np.sum(dx*dx,axis=1)
        dy2=np.sum(dy*dy,axis=1)
        cross=np.sum(dx*dy,axis=1)
        for model,footprint in [('max-axis',np.maximum(dx2,dy2)),
            ('ellipse-major',(dx2+dy2+np.sqrt((dx2-dy2)**2+4*cross**2))*.5)]:
            lod=.5*np.log2(np.maximum(footprint,1.e-20))-1
            levels=np.clip(np.floor(lod+.5),0,11).astype('i4')
            codes=encode(fields,sample(fields[:,4:6],levels))
            error=np.abs(codes-expected).max(axis=1)
            angles=np.degrees(np.arccos(np.clip(np.sum(decode(codes)*expected_direction,axis=1),-1,1)))
            rows.append(dict(snapped=snap,horizontalQuadRow=row,footprint=model,valid=int(valid.sum()),
                exact=int((valid&(error==0)).sum()),withinOne=int((valid&(error<=1)).sum()),
                maximum=int(error[valid].max()),mean=float(error[valid].mean()),
                angleP95=float(np.percentile(angles[valid],95)),angleMaximum=float(angles[valid].max()),
                anglesOverOne=int((valid&(angles>1)).sum())))
            for index in targets:
                probes.append(dict(pixel=[int(pixel[index,0]),1439-int(pixel[index,1])],snapped=snap,
                    horizontalQuadRow=row,footprint=model,level=int(levels[index]),lodAfterBias=float(lod[index]),
                    selectedCode=codes[index].tolist(),nativeCode=expected[index].tolist(),runtimeCode=live_code[index].tolist()))
alternatives=[]
if len(targets):
    fields,_=interpolation(pixel+.5,np.rint(screen*256)/256)
    fields=fields[targets]
    for level in range(12):
        codes=encode(fields,sample(fields[:,4:6],np.full(len(fields),level,dtype='i4')))
        for index,code in zip(targets,codes):
            alternatives.append(dict(pixel=[int(pixel[index,0]),1439-int(pixel[index,1])],level=level,
                code=code.tolist(),distanceToNative=int(np.abs(code-expected[index]).max()),
                distanceToRuntime=int(np.abs(code-live_code[index]).max())))
report=dict(scope='CPU diagnostic; native tangent basis, authored BC7 texture and observed primitive identity',
    maskPoints=len(pixel),cases=rows,probes=probes,pointMipAlternatives=alternatives)
(out/'normal-footprint-control.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
