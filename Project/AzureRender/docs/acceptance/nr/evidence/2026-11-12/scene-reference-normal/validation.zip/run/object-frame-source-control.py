from pathlib import Path
from hashlib import sha256
import json

import numpy as np


out = Path(__file__).resolve().parent
reference = json.loads((out.parent / '20261110-003435-visibility-numeric-contract-4f95e7/hair-calibration.json').read_text())
scene = json.loads((out / 'hair-project/assets/hair-coverage.azurelevel').read_text())
view = json.loads((out / 'hair-project/config/reference-views.json').read_text())['views']['native-hair']
camera = next(node for node in scene['nodes'] if node['id'] == 'camera')['components']['azure.transform']['data']
shadow = next(node for node in scene['nodes'] if node['id'] == 'hero')['components']['azure.object-shadow']['data']
outgoing = np.asarray(next(light for light in scene['lights'] if light['id'] == 'main')['shape']['direction'], dtype='f8')
outgoing /= np.linalg.norm(outgoing)
right = np.cross([0, 1, 0], outgoing)
right /= np.linalg.norm(right)
vertical = np.cross(outgoing, right)
forward = np.eye(4)
forward[:3, :3] = np.stack([right, vertical, outgoing]) / (2 * np.asarray(shadow['halfExtents'])[:, None])
forward[:3, 3] = .5 - forward[:3, :3] @ shadow['center']

inverse = np.asarray(reference['clipToWorld'], dtype='f8').reshape(4, 4).T
native_camera = inverse[:3, 2] / inverse[3, 2]
axes = np.zeros((3, 3))
for index, axis in enumerate(view['frame']['axes']):
    axes[index, abs(axis)-1] = 1 if axis > 0 else -1
raw_offset = native_camera - axes @ camera['translation']
integer_offset = np.rint(raw_offset)
assert np.max(np.abs(raw_offset - integer_offset)) < 3e-5
native_to_scene = np.eye(4)
native_to_scene[:3, :3] = axes.T
native_to_scene[:3, 3] = -axes.T @ integer_offset
source_projection = forward @ native_to_scene
source_projection[2] *= -1
source_projection[2, 3] += 1
frozen_projection = np.asarray(reference['record']['projection']).reshape(4, 4).T
diff = source_projection - frozen_projection
assert np.max(np.abs(diff[:3, :3])) < 1e-6
assert np.max(np.abs(diff[:3, 3])) < 5e-5

camera_projection = np.asarray(view['projection']['columns'], dtype='f8').T
jitter = view['projection']['jitter']
camera_projection[0] -= 2 * jitter[0] * camera_projection[3]
camera_projection[1] += 2 * jitter[1] * camera_projection[3]
relative_to_absolute = np.eye(4)
relative_to_absolute[:3, 3] = integer_offset - view['frame']['offset']
derived_inverse = relative_to_absolute @ np.linalg.inv(camera_projection)
absolute_inverse_error = np.abs(derived_inverse - inverse)

atlas = Path(reference['atlas'])
scene_atlas = atlas.with_name('exact-object-atlas.bin')
frozen_data, scene_data = atlas.read_bytes(), scene_atlas.read_bytes()
frozen = np.frombuffer(frozen_data, '<u2').astype('i4')
actual = 65535 - np.frombuffer(scene_data, '<u2').astype('i4')
common = (frozen > 0) & (actual > 0)
assert int(common.sum()) == 182211
report = dict(scope='CPU coordinate comparison and prior actual D16 attachment readback',
    sourceCamera=native_camera.tolist(),derivedOrigin=raw_offset.tolist(),nearestIntegralOrigin=integer_offset.tolist(),
    signedAxes=view['frame']['axes'],sourceLightDirection=(axes @ outgoing).tolist(),
    frozenLightDirection=reference['record']['lightDirection'],
    sourceProjection=source_projection.T.reshape(-1).tolist(),frozenProjection=reference['record']['projection'],
    projectionMaxLinearDifference=float(np.abs(diff[:3, :3]).max()),
    projectionMaxTranslationDifference=float(np.abs(diff[:3, 3]).max()),
    derivedClipToWorld=derived_inverse.T.reshape(-1).tolist(),
    frozenClipToWorld=reference['clipToWorld'],
    absoluteInverseMaxDifference=float(absolute_inverse_error.max()),
    actualAtlasSha256=sha256(scene_data).hexdigest(),frozenAtlasSha256=sha256(frozen_data).hexdigest(),
    commonAtlasTexels=int(common.sum()),atlasOverTwoUnits=int((np.abs(actual[common]-frozen[common])>2).sum()))
(out / 'object-frame-source-control.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
