from pathlib import Path
import hashlib
import json
import os
import traceback

import renderdoc as rd


request = json.loads(Path(os.environ['AZURE_NATIVE_NORMAL_REQUEST']).read_text(encoding='utf-8-sig'))
output = Path(request['output'])
capture = rd.OpenCaptureFile()
controller = None
report = {'status': 'failed'}


def readonly(pipeline, reflection):
    return {reflection.readOnlyResources[item.access.index].fixedBindNumber: item.descriptor.resource
        for item in pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel)}


def digest(data):
    return hashlib.sha256(data).hexdigest()


try:
    assert capture.OpenFile(request['capture'], '', None) == rd.ResultCode.Succeeded
    vendor = rd.GPUVendor.nVidia if request.get('device','nvidia')=='nvidia' else rd.GPUVendor.Intel
    devices = [gpu for gpu in capture.GetAvailableGPUs() if gpu.vendor == vendor and rd.GraphicsAPI.D3D11 in gpu.apis]
    assert len(devices) == 1
    options = rd.ReplayOptions()
    options.forceGPUVendor = devices[0].vendor
    options.forceGPUDeviceID = devices[0].deviceID
    status, controller = capture.OpenCapture(options, None)
    assert status == rd.ResultCode.Succeeded and controller
    properties = controller.GetAPIProperties()
    assert properties.vendor == options.forceGPUVendor and properties.pipelineType == rd.GraphicsAPI.D3D11 and not properties.degraded
    controller.SetFrameEvent(699, True)
    pipeline = controller.GetPipelineState()
    reflection = pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
    normal = readonly(pipeline, reflection)[6]
    assert str(normal) == 'ResourceId::141952'
    descriptions = {str(item.resourceId): item for item in controller.GetTextures()}
    texture = descriptions[str(normal)]
    assert (texture.width, texture.height, texture.format.Name()) == (2560, 1440, 'R10G10B10A2_UNORM')
    uses = [{'event': item.eventId, 'usage': str(item.usage)} for item in controller.GetUsage(normal) if item.eventId <= 699]
    pixels = bytes(controller.GetTextureData(normal, rd.Subresource()))
    assert len(pixels) == 2560 * 1440 * 4
    if request['normalSha256']:
        assert digest(pixels) == request['normalSha256']
    report.update(resource=str(normal), format=texture.format.Name(), width=texture.width, height=texture.height,
        uses=uses, event699Sha256=digest(pixels), vendor=str(properties.vendor), replayDevice=devices[0].name)
    for event in (421, 422, 440, 478, 522, 699):
        controller.SetFrameEvent(event, True)
        pipeline = controller.GetPipelineState()
        reflection = pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
        data = bytes(controller.GetTextureData(normal, rd.Subresource()))
        report.setdefault('events', {})[str(event)] = dict(normalSha256=digest(data), outputTargets=[
            str(descriptor.resource) for descriptor in pipeline.GetOutputTargets()])
        if reflection:
            inputs = readonly(pipeline, reflection)
            report['events'][str(event)]['readOnly'] = {str(slot): str(resource) for slot, resource in inputs.items()}
            (output / (str(event) + '-pixel.asm')).write_text(controller.DisassembleShader(
                pipeline.GetGraphicsPipelineObject(), reflection, ''), encoding='utf-8')
            if event == 422:
                source = Path(request['normalTexture']).read_bytes()
                assert digest(source) == request['normalTextureSha256'] and source[84:88] == b'DX10'
                candidates = []
                for slot, resource in inputs.items():
                    description = descriptions.get(str(resource))
                    if not description or (description.width,description.height,description.mips)!=(2048,2048,12):
                        continue
                    levels = [bytes(controller.GetTextureData(resource,rd.Subresource(mip,0,0))) for mip in range(12)]
                    payload = b''.join(levels)
                    candidates.append(dict(slot=slot,resource=str(resource),format=description.format.Name(),
                        sha256=digest(payload),bytes=len(payload),exactAuthoredPayload=payload==source[148:],
                        mipSha256=[digest(level) for level in levels]))
                report['authoredNormalTextureCandidates'] = candidates
        if event in (422, 699):
            y0, y1, x0, x1 = 1000, 1310, 1140, 1430
            crop = b''.join(data[(y * 2560 + x0) * 4:(y * 2560 + x1) * 4] for y in range(y0, y1))
            (output / (str(event) + '-normal-crop.bin')).write_bytes(crop)
    report['status'] = 'collected'
except Exception:
    report['error'] = traceback.format_exc()
finally:
    if controller:
        controller.Shutdown()
    capture.Shutdown()
    (output / 'normal-source.json').write_text(json.dumps(report, indent=2) + '\n')
os._exit(0 if report['status'] == 'collected' else 1)
