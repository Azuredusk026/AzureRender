from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys


out = Path(__file__).resolve().parent
capture = Path(sys.argv[1]).resolve(strict=True)
device = sys.argv[2] if len(sys.argv)>2 else 'nvidia'
assert device in ('nvidia','intel')
expected = 'fa2ca267f7168f5603e83ad5f817a3074d8dbee23a216e6ab8ef2c340ec06a90'


def capture_digest():
    with capture.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


assert capture_digest() == expected
folder = out / ('normal-source-replay' if device=='nvidia' else 'normal-source-replay-intel')
folder.mkdir()
request = folder / 'request.json'
texture = json.loads((out / 'normal-source-inspection.json').read_text())['authoredHairNormal']
request.write_text(json.dumps(dict(capture=str(capture), output=str(folder), device=device,
    normalSha256='63731d707e7ba30d9417049c8148b9bd2167208e435e8d9f0cc100a1fd03e095' if device=='nvidia' else None,
    normalTexture=texture['path'],normalTextureSha256=texture['sha256']), indent=2))
env = os.environ.copy()
for key in ('VK_LAYER_PATH', 'VK_INSTANCE_LAYERS', 'ENABLE_VULKAN_RENDERDOC_CAPTURE',
        'VK_LOADER_DRIVERS_SELECT', 'VK_DRIVER_FILES', 'VK_ICD_FILENAMES'):
    env.pop(key, None)
env['AZURE_NATIVE_NORMAL_REQUEST'] = str(request)
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
command = ['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe', '--python', str(out / 'normal-source-worker.py')]
(folder / 'command.json').write_text(json.dumps(command, indent=2))
with (folder / 'replay.log').open('wb') as log:
    result = subprocess.run(command, cwd=folder, env=env, startupinfo=startup, stdout=log,
        stderr=subprocess.STDOUT, timeout=270)
report = json.loads((folder / 'normal-source.json').read_text())
assert capture_digest() == expected and result.returncode == 0 and report['status'] == 'collected', report
print(json.dumps(report))
