from pathlib import Path
from hashlib import sha256
import json
import zipfile

import numpy as np


out = Path(__file__).resolve().parent
profile = out.parent / '20261110-003435-visibility-numeric-contract-4f95e7'
reference = json.loads((profile / 'receiver-calibration.json').read_text())
query = Path(reference['queries']).read_bytes()
points = np.frombuffer(query,'<f4').reshape(-1,4)
assert len(points)==49384
x,y=points[:,:2].astype('i4').T
hair = np.fromfile(out/'nvidia-normal-visibility-control-reference-frame/queries.bin','<f4').reshape(-1,4)
hair_in_receiver = np.isin(y*2560+x, hair[:,1].astype('i4')*2560+hair[:,0].astype('i4'))
assert len(hair)==17017

frames=out/'release-nvidia-fixed-reference-frame-frames'
planes=json.loads((frames/'reference-planes.json').read_text())
with zipfile.ZipFile(frames/'reference-planes.zip') as archive:
    samples={}
    for key,name,dtype in [('depth','reference-depth-r32.bin','<u4'),('normal','reference-normals-a2b10g10r10.bin','<u4'),
        ('objectIds','reference-object-ids-r8.bin','u1')]:
        data=archive.read(planes[name]['archiveEntry'])
        assert sha256(data).hexdigest()==planes[name]['sha256']
        samples[key]=np.frombuffer(data,dtype).reshape(1440,2560)[y,x]

depth = np.fromfile(reference['depth'],'<u4').reshape(1440,2560)[y,x]
normal = np.fromfile(reference['normals'],'<u4').reshape(1440,2560)[y,x]
report = {}
for name,mask in [('full',np.ones(len(x),bool)),('hair',hair_in_receiver),('other',~hair_in_receiver)]:
    a,b=samples['normal'][mask],normal[mask]
    diff = np.maximum(*[np.abs(((a>>shift)&1023).astype('i4')-((b>>shift)&1023).astype('i4')) for shift in (0,10)])
    report[name]=dict(pixels=int(mask.sum()), liveObject=int((samples['objectIds'][mask]>0).sum()),
        liveDepthExact=int((samples['depth'][mask]==depth[mask]).sum()), liveNormalsExact=int((a==b).sum()),
        liveNormalsWithinOne=int((diff<=1).sum()), maximumNormalCodeDifference=int(diff.max()))
result = dict(scope='Readback overlap for frozen full receiver positions; no visibility run',
    querySha256=sha256(query).hexdigest(), referencePlaneHashes={name:meta['sha256'] for name,meta in planes.items()}, groups=report)
(out/'receiver-input-overlap.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(report))
