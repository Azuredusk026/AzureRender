from pathlib import Path
import hashlib
import itertools
import json
import mmap
import struct

import numpy as np


prep = Path(__file__).resolve().parent
run = prep.parent if prep.name == 'next-input-prep' else prep.parent / '20261111-213928-scene-reference-depth-728062'
native = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/source-normal-vertex')
state = json.loads((native / 'summary.json').read_text())
assert state['vertex']['event'] == 422 and state['vertex']['vertexByteStride'] == 92
packed = (native / '422-vertex.bin').read_bytes()
post = np.frombuffer(packed, dtype='<f4').reshape(-1, 23)
asset = run / 'hair-project/character/hair-coverage.glb'
previous = run.parent / '20261111-072757-material-ellipse-coverage-policy-3e26b6/scene-depth-source-inspection.json'
transform = np.array(json.loads(previous.read_text())['mesh'][0]['imported'][0]['worldMatrix'])[:3,:3]


def unit(vectors):
    return vectors / np.maximum(np.linalg.norm(vectors, axis=1, keepdims=True), 1.e-20)


with asset.open('rb') as file, mmap.mmap(file.fileno(), 0, access=mmap.ACCESS_READ) as data:
    length, kind = struct.unpack_from('<II', data, 12)
    assert kind == 0x4e4f534a
    gltf = json.loads(data[20:20+length])
    start = 28+length
    primitive = next(p for mesh in gltf['meshes'] for p in mesh['primitives'] if p.get('material') == 9)

    def read(name, components):
        index = primitive['attributes'][name]
        accessor = gltf['accessors'][index]
        view = gltf['bufferViews'][accessor['bufferView']]
        offset = start + view.get('byteOffset', 0) + accessor.get('byteOffset', 0)
        assert accessor['componentType'] == 5126
        return np.ndarray((accessor['count'], components), dtype='<f4', buffer=data, offset=offset,
            strides=(view.get('byteStride', 4*components),4)).copy()

    uv = read('TEXCOORD_0', 2)
    normal = read('NORMAL', 3)
    tangent = read('TANGENT', 4)
    accessor = gltf['accessors'][primitive['indices']]
    view = gltf['bufferViews'][accessor['bufferView']]
    offset = start + view.get('byteOffset', 0) + accessor.get('byteOffset', 0)
    index_type = {5123:'<u2',5125:'<u4'}[accessor['componentType']]
    indices = np.frombuffer(data, index_type, count=accessor['count'], offset=offset).copy().astype('u4')

assert len(uv) == len(post) == 11564
native_indices = np.fromfile(native/'422-index.bin', '<u2').astype('u4')
assert len(indices) == len(native_indices) == 43044
alignments = []
for corners in itertools.permutations(range(3)):
    order = native_indices.reshape(-1, 3)[:,corners].reshape(-1)
    pairs = np.unique(np.column_stack((indices, order)), axis=0)
    if len(pairs) != len(uv) or not np.array_equal(pairs[:,0], np.arange(len(uv))) or len(np.unique(pairs[:,1])) != len(uv):
        continue
    aligned = post[pairs[:,1]]
    difference = np.abs(uv-aligned[:,4:6])
    alignments.append((float(difference.mean()), corners, pairs[:,1], int((difference==0).sum()), float(difference.max())))
assert alignments, 'The native and project triangle lists could not establish a unique vertex remapping'
mean_uv_error, corners, mapping, uv_exact_components, maximum_uv_error = min(alignments, key=lambda row: row[0])
post = post[mapping]
reference = {'normal':unit(normal @ np.linalg.inv(transform)), 'tangent':unit(tangent[:,:3] @ transform.T)}
fields = {str(start): unit(post[:,start:start+3].astype('f8')) for start in (6,9,12,16,19)}
best = {}
for name, values in reference.items():
    ranked = []
    for field, sampled in fields.items():
        for permutation in itertools.permutations(range(3)):
            for signs in itertools.product((-1,1), repeat=3):
                converted = values[:,permutation]*signs
                dot = np.sum(converted*sampled, axis=1)
                ranked.append((float(np.mean(dot)), field, permutation, signs))
    _, field, permutation, signs = max(ranked)
    converted = values[:,permutation]*signs
    dot = np.sum(converted*fields[field], axis=1)
    angles = np.degrees(np.arccos(np.clip(dot, -1., 1.)))
    best[name] = dict(floatOffset=int(field), axisPermutation=permutation, signs=signs,
        degreesP50=float(np.median(angles)), degreesP95=float(np.percentile(angles,95)),
        degreesMax=float(angles.max()), degreesUnderPointOne=int(np.count_nonzero(angles<=.1)))
report = dict(nativePath=str(native/'422-vertex.bin'), nativeSha256=hashlib.sha256(packed).hexdigest(),
    vertexCount=len(post), sourceTriangleCornerOrder=corners, exactUvComponents=uv_exact_components,
    meanUvError=mean_uv_error, maximumUvError=maximum_uv_error, signature=state['vertex']['signature'], comparison=best,
    sampler=state['samplers'], lodBias=state['globalLodBias'][0])
sign_pairs, counts = np.unique(np.column_stack((tangent[:,3], post[:,15])), axis=0, return_counts=True)
report['tangentHandedness'] = [dict(asset=float(pair[0]), native=float(pair[1]), count=int(count))
    for pair, count in zip(sign_pairs, counts)]
report['assetNodeDeterminant'] = float(np.linalg.det(transform))
(prep / 'normal-vertex-comparison.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
