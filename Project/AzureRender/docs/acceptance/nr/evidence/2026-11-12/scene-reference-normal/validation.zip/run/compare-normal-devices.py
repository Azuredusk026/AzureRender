from pathlib import Path
from hashlib import sha256
import json
import zipfile

import numpy as np


out = Path(__file__).resolve().parent
queries = np.fromfile(out / 'nvidia-normal-visibility-control-reference-frame/queries.bin', '<f4').reshape(-1,4)
x,y = queries[:, :2].astype('i4').T
assert len(x) == 17017 and min(x) >= 1140 and min(y) >= 1000 and max(x) < 1430 and max(y) < 1310


def crop(path):
    return np.fromfile(path, '<u4').reshape(310,290)[y - 1000,x - 1140]


def live(folder):
    name = 'reference-normals-a2b10g10r10.bin'
    raw = folder / name
    if raw.is_file():
        data = raw.read_bytes()
    else:
        planes = json.loads((folder / 'reference-planes.json').read_text())
        with zipfile.ZipFile(folder / 'reference-planes.zip') as archive:
            data = archive.read(planes[name]['archiveEntry'])
        assert sha256(data).hexdigest() == planes[name]['sha256']
    return np.frombuffer(data,'<u4').reshape(1440,2560)[y,x]


def compare(first, second):
    diff = np.stack([((first >> shift)&1023).astype('i4') - ((second >> shift)&1023).astype('i4') for shift in (0,10)], axis=1)
    error = np.abs(diff).max(axis=1)
    return dict(exact=int((first==second).sum()), withinOne=int((error<=1).sum()), maximumCodeDifference=int(error.max()),
        alphaExact=int(((first>>30)==(second>>30)).sum()),
        signedCodeDifference=[{int(value):int(count) for value,count in zip(*np.unique(row,return_counts=True))} for row in diff.T])


sources = {name:out/('normal-source-replay' if name=='nvidia' else 'normal-source-replay-intel') for name in ('nvidia','intel')}
frozen = crop(sources['nvidia'] / '699-normal-crop.bin')
report = {}
for device,label in [('nvidia','release-nvidia-fixed-reference-frame'), ('intel','release-intel-fixed-qualified')]:
    producer = crop(sources[device] / '422-normal-crop.bin')
    native = crop(sources[device] / '699-normal-crop.bin')
    current = live(out / (label+'-frames'))
    report[device] = dict(nativeProducerConsumer=compare(producer,native), nativeVsFrozen=compare(native,frozen),
        sceneVsNativeDevice=compare(current,native), sceneVsFrozen=compare(current,frozen))
    channel_error = np.maximum(*[np.abs(((current>>shift)&1023).astype('i4')-((native>>shift)&1023).astype('i4')) for shift in (0,10)])
    report[device]['sameDeviceOutliers'] = [dict(pixel=[int(x[i]),1439-int(y[i])],current=int(current[i]),native=int(native[i]),
        frozen=int(frozen[i]),codeDifference=int(channel_error[i])) for i in np.flatnonzero(channel_error>1)]
(out / 'normal-device-comparison.json').write_text(json.dumps(report,indent=2) + '\n')
print(json.dumps({device:{name:{key:value for key,value in data.items() if key!='signedCodeDifference'} if isinstance(data,dict) else data
    for name,data in details.items()} for device,details in report.items()}))
