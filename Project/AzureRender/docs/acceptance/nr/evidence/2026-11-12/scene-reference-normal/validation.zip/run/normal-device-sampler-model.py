from contextlib import redirect_stdout
from pathlib import Path
import io
import json
import runpy

import numpy as np


out = Path(__file__).resolve().parent
with redirect_stdout(io.StringIO()):
    model = runpy.run_path(str(out / 'normal-footprint-control.py'))
pixel = model['pixel']
reference_codes = model['expected']
crop = np.fromfile(out/'normal-source-replay-intel/699-normal-crop.bin','<u4').reshape(310,290)
intel = crop[pixel[:,1]-1000,pixel[:,0]-1140]
intel_codes = np.stack((intel&1023,(intel>>10)&1023),axis=1).astype('i4')
cross_device = np.abs(intel_codes-reference_codes).max(axis=1)>1

vertices = np.rint(model['screen']*256)/256
fields, valid = model['interpolation'](pixel+.5, vertices)
assert valid.all()
decode = model['decode']
angles = {}
levels = len(model['mips'])
expected = {'nvidia':decode(reference_codes), 'intel':decode(intel_codes)}
for name, normals in expected.items():
    angle = []
    for level in range(levels):
        sample = model['sample'](fields[:,4:6],np.full(len(pixel),level,dtype='i4'))
        predicted = decode(model['encode'](fields,sample))
        angle.append(np.degrees(np.arccos(np.clip(np.sum(normals*predicted,axis=1),-1,1))))
    angles[name] = np.stack(angle,axis=1)

ordered = {name:np.argsort(angle,axis=1) for name,angle in angles.items()}
best = {name:ids[:,0] for name,ids in ordered.items()}
row = np.arange(len(pixel))
minimum = {name:angle[row,best[name]] for name,angle in angles.items()}
gap = {name:angle[row,ordered[name][:,1]]-minimum[name] for name,angle in angles.items()}
confident = {name:(minimum[name]<=.35)&(gap[name]>=.7) for name in expected}
both = confident['nvidia']&confident['intel']
difference = best['intel']-best['nvidia']
quad=(pixel&~1)+.5
uv=[model['interpolation'](quad+offset,vertices)[0][:,4:6] for offset in ([0,0],[1,0],[0,1],[1,1])]
horizontal=[(uv[1]-uv[0])*2048,(uv[3]-uv[2])*2048]
vertical=[(uv[2]-uv[0])*2048,(uv[3]-uv[1])*2048]
footprints=[]
for row,dx in enumerate(horizontal):
    for col,dy in enumerate(vertical):
        dx2=np.sum(dx*dx,axis=1)
        dy2=np.sum(dy*dy,axis=1)
        dot=np.sum(dx*dy,axis=1)
        for name,footprint in [('max-axis',np.maximum(dx2,dy2)),('max-component',np.maximum(np.max(dx*dx,axis=1),np.max(dy*dy,axis=1))),
            ('ellipse-major',(dx2+dy2+np.sqrt((dx2-dy2)**2+4*dot**2))*.5)]:
            level=np.clip(np.floor(.5*np.log2(np.maximum(footprint,1.e-20))-.5),0,levels-1).astype('i4')
            counts={device:int((confident[device]&(level==best[device])).sum()) for device in expected}
            mismatch_subset={device:int((both&cross_device&(level==best[device])).sum()) for device in expected}
            footprints.append(dict(horizontalQuadRow=row,verticalQuadColumn=col,footprint=name,agreement=counts,
                agreementAmongDeviceDifferences=mismatch_subset))
report = dict(scope='Analytic source-footprint diagnostic; nearest normal direction among authored mips',
    maskedPositions=len(pixel), nativeCodeDifferencesOverOne=int(cross_device.sum()),
    inferredUniquePerDevice={name:int(mask.sum()) for name,mask in confident.items()},
    jointlyInferred=int(both.sum()), jointlyInferredAmongNativeDifferences=int((both&cross_device).sum()),
    differentMipAmongNativeDifferences=int((both&cross_device&(difference!=0)).sum()),
    mipDifferenceCounts={int(value):int(count) for value,count in zip(*np.unique(difference[both&cross_device],return_counts=True))},
    nearestAngleP95={name:float(np.percentile(value,95)) for name,value in minimum.items()},
    nativeAngularDifferenceP95=float(np.percentile(np.degrees(np.arccos(np.clip(np.sum(expected['nvidia']*expected['intel'],axis=1),-1,1))),95)),
    footprintModels=footprints)
(out/'normal-device-sampler-model.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
