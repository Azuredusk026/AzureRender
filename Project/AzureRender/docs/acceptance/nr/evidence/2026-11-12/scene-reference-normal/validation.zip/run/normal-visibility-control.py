from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import zipfile

import numpy as np


out = Path(__file__).resolve().parent
root = out.parents[2]
capture = Path(sys.argv[1]).resolve(strict=True)
device = sys.argv[2]
assert device in ('nvidia','intel') and out in capture.parents
old = out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
reference = json.loads((old/'hair-calibration.json').read_text())
tag = '-'+sys.argv[3] if len(sys.argv)==4 else ''
folder = out/(device+'-normal-visibility-control'+tag)
folder.mkdir()


def digest(data):
    return hashlib.sha256(data).hexdigest()


archive_root = root/'docs/acceptance/nr/evidence'
with zipfile.ZipFile(archive_root/'2026-11-11/actual-world-depth-source/validation.zip') as frozen:
    for key in ('queries','expected'):
        data = frozen.read('run/'+key+'.bin')
        path = folder/(key+'.bin')
        path.write_bytes(data)
        reference[key] = str(path)
with zipfile.ZipFile(archive_root/'2026-11-10/visibility-reference-arithmetic/validation.zip') as frozen:
    data = frozen.read('profile/correction.bin')
    assert digest(data)==digest(Path(reference['profile']).read_bytes())
    path = folder/'correction.bin'
    path.write_bytes(data)
    reference['profile'] = str(path)
assert Path(reference['queries']).stat().st_size==17017*16 and Path(reference['expected']).stat().st_size==17017*4


manifest = json.loads((capture/'capture_manifest.json').read_text())['referenceSceneDepth']
assert manifest['rowOrigin']=='bottom-left' and manifest['width']==2560 and manifest['height']==1440
words = np.fromfile(capture/manifest['packedNormals'],'<u4')
assert words.size==2560*1440
# The initial controls recorded engine axes. The reference capture uses native axes directly.
world = words if manifest.get('normalFrame')=='reference' else (words&0xfffffc00) | (1023-(words&1023))
converted = folder/'scene-native-basis-normals.bin'
converted.write_bytes(world.astype('<u4').tobytes())
controlled = dict(reference,normals=str(converted),scope='live-normal-source')
path = folder/'calibration.json'
path.write_text(json.dumps(controlled,indent=2)+'\n')
inputs = {key:digest(Path(reference[key]).read_bytes()) for key in ('depth','normals','atlas','queries','expected','profile')}
assert inputs['depth']=='02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb'
assert inputs['normals']=='63731d707e7ba30d9417049c8148b9bd2167208e435e8d9f0cc100a1fd03e095'
assert inputs['atlas']=='86daee0e01e9c33207679b094bdf5cf31a26d2f93754f11abf6c44df1faecf57'
env = os.environ.copy()
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    env.pop(key,None)
env.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*' if device=='nvidia' else '*igvk64*',
    VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
command = [str(old/'calibration.exe'),str(path),str(old)]
(folder/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (folder/'process.log').open('wb') as log:
    process = subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
report = json.loads((folder/(device+'-live-normal-source-result.json')).read_text())
assert report['pixels']==17017 and report['zeroAllocator'] and not report['validationErrors']
assert process.returncode==(0 if report['withinOnePixels']==report['pixels'] else 1)
assert len((folder/(device+'-live-normal-source-rg8.bin')).read_bytes())==17017*2
report.update(deviceExitCode=process.returncode,inputs=inputs,candidateNormalSha256=digest(words.tobytes()),
    candidateNativeBasisSha256=digest(converted.read_bytes()),source='Production normals with frozen depth, atlas, IDs and inverse projection',
    oneByteGatePassed=report['withinOnePixels']==report['pixels'])
(folder/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
