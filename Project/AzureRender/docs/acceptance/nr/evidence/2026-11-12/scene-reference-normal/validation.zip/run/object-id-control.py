from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

import numpy as np


out = Path(__file__).resolve().parent
sys.path.insert(0, str(out.parents[2]/'tools'))
from native_render.light_lab import generate


def write(path, data):
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


def component(name, data):
    return dict(type=name,version=1,data=data)


configuration = sys.argv[1] if len(sys.argv)>1 else 'Release'
assert configuration in ('Release', 'Debug')
folder = out/('object-id-control-'+configuration.lower())
generate(folder,'dark')
mesh_path=folder/'plane.gltf'
mesh=json.loads(mesh_path.read_text())
mesh['materials'][0]['doubleSided']=True
write(mesh_path,mesh)
level = folder/'level.azurelevel'
scene = json.loads(level.read_text())
camera = next(node for node in scene['nodes'] if node['id']=='camera')
anchor = camera['components']['azure.transform']['data']['translation']
reference = dict(enabled=True,view='visibility',anchorPosition=anchor,anchorRight=[1,0,0],anchorUp=[0,1,0],anchorBack=[0,0,1])
camera['components']['azure.reference-camera'] = component('azure.reference-camera',reference)
scene['nodes'] = [camera]
for name,x,z,page in (('left',-.35,0,6),('right',.35,.5,1)):
    scene['nodes'].append(dict(id=name,resourceId='plane',components={
        'azure.transform':component('azure.transform',dict(translation=[x,0,z],scale=[.125,.125,1])),
        'azure.object-shadow':component('azure.object-shadow',dict(enabled=True,atlasPage=page,halfExtents=[1,1,1]))}))
config = folder/'config'
config.mkdir()
depth_view = dict(schemaVersion=1,extent=[128,128],depthConvention='reversed',flipNdcY=False,produceSceneDepth=True,
    frame=dict(schemaVersion=1,axes=[1,2,3],offset=[0,0,0]),
    projection=dict(schemaVersion=1,columns=[[1,0,0,0],[0,-1,0,0],[0,0,.25,0],[0,0,.5,1]],jitter=[0,0]))
visibility_view = dict(depth_view,produceSceneVisibilityInputs=True)
permuted_view = dict(visibility_view,frame=dict(schemaVersion=1,axes=[3,2,-1],offset=[0,0,0]),
    projection=dict(schemaVersion=1,columns=[[0,0,.25,0],[0,-1,0,0],[-1,0,0,0],[0,0,.5,1]],jitter=[0,0]))
write(config/'reference-views.json',dict(schemaVersion=1,views={
    'depth':depth_view,'visibility':visibility_view,'permuted':permuted_view}))
build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
depth_planes={}
visibility_planes={}
reports={}
for mode in ('visibility','depth','permuted'):
    reference['view']=mode
    write(level,scene)
    frames=folder/mode
    command=[str(build/'AzurePlayer.exe'),'--project',str(folder/'lab.azureproject'),'--width','128','--height','128',
        '--capture-dir',str(frames),'--capture-frames','3','--fixed-frame-step','--qa-camera','scene','--qa-light','scene',
        '--qa-isolation','albedo','--disable-bindless','--disable-compute-skinning','--disable-parallel-recording','--resource-root',str(build)]
    write(folder/(mode+'-command.json'),command)
    log_path=folder/(mode+'.log')
    with log_path.open('wb') as log:
        process=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    diagnostics=log_path.read_text(errors='replace')
    assert process.returncode==0 and 'Allocator after unload: buffers=0 images=0' in diagnostics,diagnostics[-5000:]
    assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',diagnostics,re.I),diagnostics[-5000:]
    manifest=json.loads((frames/'capture_manifest.json').read_text())
    capture=manifest['referenceSceneDepth']
    assert capture['rowOrigin']=='bottom-left' and capture['submission']==3
    data=(frames/capture['raster']).read_bytes()
    assert data==(frames/capture['hardware']).read_bytes()
    depth_planes[mode]=data
    depth=np.frombuffer(data,dtype='<f4').reshape(128,128)
    x=[0,24,64,104]
    assert depth[64,x].tolist()==[0,.5,.625,.625]
    reports[mode]=dict(depthSha256=hashlib.sha256(data).hexdigest(),depthSamples=depth[64,x].tolist())
    if mode=='depth':
        assert 'packedNormals' not in capture and 'objectIds' not in capture and 'normalFrame' not in capture
        assert not list(frames.glob('reference-*normal*')) and not list(frames.glob('reference-object*'))
        continue
    ids=np.frombuffer((frames/capture['objectIds']).read_bytes(),dtype='u1').reshape(128,128)
    normal=np.frombuffer((frames/capture['packedNormals']).read_bytes(),dtype='<u4').reshape(128,128)
    assert capture['normalFrame']=='reference'
    assert sorted(np.unique(ids))==[0,1,2]
    assert ids[64,0]==0 and ids[64,24]!=ids[64,104] and ids[64,64]==ids[64,104]
    assert np.array_equal(ids!=0,depth!=0)
    assert (normal[64,0]>>30)==0 and np.all((normal[64,x[1:]]>>30)==3)
    visibility_planes[mode]=(ids,normal)
    reports[mode].update(objectIds=ids[64,x].tolist(),packedNormal=normal[64,x].tolist())

assert depth_planes['depth']==depth_planes['visibility']==depth_planes['permuted']
ids,normal=visibility_planes['visibility']
permuted_ids,permuted_normal=visibility_planes['permuted']
assert np.array_equal(ids,permuted_ids)
covered=ids>0
red=lambda p:(p[covered]&1023).astype('i4')
green=lambda p:((p[covered]>>10)&1023).astype('i4')
assert np.max(np.abs(red(permuted_normal)-green(normal)))<=1
assert np.max(np.abs(green(permuted_normal)+red(normal)-1023))<=1
write(folder/'summary.json',dict(cases=reports,wholeDepthExact=True,visibilityInputsOnlyWhenSelected=True,
    referenceAxisPermutation=True,validationClean=True,allocatorZero=True))
print(json.dumps(reports))
