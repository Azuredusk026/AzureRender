from hashlib import sha256
from pathlib import Path
import json
import sys
import zipfile


root = Path(__file__).resolve().parent
for name in sys.argv[1:]:
    folder = (root / name).resolve(strict=True)
    assert folder.parent == root and not folder.is_symlink()
    source_names = ('reference-depth-r32.bin', 'reference-depth-d32.bin',
        'reference-normals-a2b10g10r10.bin', 'reference-object-ids-r8.bin',
        'scene-native-basis-normals.bin')
    files = {file: (folder / file).resolve(strict=True) for file in source_names if (folder / file).is_file()}
    assert files and all(path.parent == folder for path in files.values())
    archive = folder / 'reference-planes.zip'
    manifest = folder / 'reference-planes.json'
    assert not archive.exists() and not manifest.exists()
    entries = {}
    primary = {}
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as result:
        for name, path in files.items():
            raw = path.read_bytes()
            digest = sha256(raw).hexdigest()
            entry = primary.setdefault(digest, name)
            if entry == name:
                result.writestr(name, raw)
            entries[name] = {'sha256': digest, 'size': len(raw), 'archiveEntry': entry}
    with zipfile.ZipFile(archive) as result:
        assert result.testzip() is None
        for name, info in entries.items():
            assert result.read(info['archiveEntry']) == files[name].read_bytes()
    manifest.write_text(json.dumps(entries, indent=2) + '\n')
    for path in files.values():
        path.unlink()
    print(f'{folder.name}: {sum(info["size"] for info in entries.values())} -> {archive.stat().st_size}', flush=True)
