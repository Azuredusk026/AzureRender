from pathlib import Path
import json,sys,time

out=Path(__file__).resolve().parent
root=out.parents[2]
main=Path('D:/Projects/FYP/Project/AzureRender')
sys.path.insert(0,str(main/'tools'))
import shared_resources as shared

red=json.loads((out/'runtime-red-result.json').read_text())
assert red['baseCommit']=='7044017' and red['expectedMissingField']=='produceSceneVisibilityInputs'
assert red['exitCode']!=0 and not red['initializedGraphics']
started=time.monotonic()
while True:
    lease=shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-scene-reference-normal-source',out)
    try:
        lease.__enter__()
        break
    except ValueError as error:
        if not any(part in str(error) for part in ('busy','still running')):
            raise
        if time.monotonic()-started>=180:
            raise TimeoutError('Scene normal source queue wait ended before execution')
        time.sleep(1)
try:
    capture=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc')
    execution=shared.maintenance.guarded_run(out.parents[1],out.name,[sys.executable,str(out/'normal-source.py'),str(capture)],330)
    (out/'normal-source-execution.json').write_text(json.dumps(execution,indent=2)+'\n')
    assert execution['status']=='exited' and execution['exitCode']==0,execution
    print('Native normal source replay collected')
finally:
    lease.__exit__(None,None,None)
