from pathlib import Path
import json
import os
import subprocess
import sys
import time


out = Path(__file__).resolve().parent
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def run(name, script, *args):
    result = shared.maintenance.guarded_run(out.parents[1], out.name, [sys.executable, str(out / script), *args], 600)
    (out / (name + '-execution.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    assert result['status'] == 'exited' and result['exitCode'] == 0, result


def device(name):
    os.environ['VK_LOADER_DRIVERS_SELECT'] = '*nv-vk64*' if name == 'nvidia' else '*igvk64*'


def compact(*folders):
    subprocess.run([sys.executable, str(out / 'compact-capture.py'), *folders], check=True)


configuration = sys.argv[1]
assert configuration in ('Release', 'Debug')
prefix = configuration.lower()
for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES', 'VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key, None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LAYER_VALIDATE_SYNC='1')
token = sys.argv[2] if len(sys.argv)>2 else None
if token:
    deadline = time.monotonic() + 900
    while time.monotonic() < deadline:
        try:
            state = json.loads((shared.DEFAULT_QUEUE / 'current.json').read_text())
        except (OSError, ValueError):
            time.sleep(1)
            continue
        if state.get('token') != token or state.get('state') == 'released':
            break
        time.sleep(1)
    else:
        raise TimeoutError('The agreed GPU verification window has not opened')
with shared.lease(shared.DEFAULT_QUEUE, '01a1c099-8121-7be3-b0b8-7af2f9a06b2a', 'quality-scene-reference-normal-'+prefix+'-gpu', out):
    device('nvidia')
    run('object-id-control-'+prefix, 'object-id-control.py', configuration)
    if configuration == 'Release':
        run('release-reference-depth-tests', 'verify-build.py', configuration, '--gpu')
        run('release-nvidia-indexed-compute', 'capture-normal.py', configuration, 'nvidia', 'indexed', 'compute', '--compute')
        compact('release-nvidia-indexed-compute-frames')
    else:
        run('debug-nvidia-fixed-qualified', 'capture-normal.py', configuration, 'nvidia', 'fixed', 'qualified')
        compact('debug-nvidia-fixed-qualified-frames')
    device('intel')
    name = prefix+'-intel-fixed-qualified'
    run(name, 'capture-normal.py', configuration, 'intel', 'fixed', 'qualified')
    if configuration == 'Release':
        run('release-intel-normal-visibility', 'normal-visibility-control.py', str(out / (name+'-frames')), 'intel', 'qualified')
        compact('intel-normal-visibility-control-qualified')
        native_capture = 'D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc'
        run('native-intel-normal-source', 'normal-source.py', native_capture, 'intel')
    compact(name+'-frames')
