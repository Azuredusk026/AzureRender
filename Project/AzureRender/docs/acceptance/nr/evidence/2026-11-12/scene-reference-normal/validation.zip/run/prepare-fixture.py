from pathlib import Path
import hashlib
import json
import shutil
import struct


out = Path(__file__).resolve().parent
previous = out.parent / '20261111-213928-scene-reference-depth-728062'
source_root = previous / 'hair-project'
target_root = out / 'hair-project'
assert not target_root.exists()


def digest(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def record(source, target, expected=None):
    sha = digest(target)
    if expected:
        assert sha == expected
    rows.append(dict(source=str(source), destination=str(target), sha256=sha, bytes=target.stat().st_size))


rows = []
source_records = json.loads((previous / 'hair-copy-inputs.json').read_text())
for item in source_records:
    source = Path(item['destination'])
    relative = source.relative_to(source_root)
    assert digest(source) == item['sha256']
    target = target_root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    record(source, target, item['sha256'])

source_info = json.loads((out / 'normal-source-inspection.json').read_text())['authoredHairNormal']
source = Path(source_info['path'])
assert digest(source) == source_info['sha256'] and source_info['extent'] == [2048,2048] and source_info['mipLevels'] == 12
normal = target_root / 'character/captured-hair-normal.dds'
shutil.copyfile(source, normal)
record(source, normal, source_info['sha256'])
metadata = normal.with_suffix('.dds.azmeta')
write(metadata, dict(schemaVersion=1, id=source_info['normalAsset'], dependencies=[],
    settings=dict(texture=dict(schemaVersion=2, filter='linear', magFilter='linear', mipFilter='nearest',
        anisotropy=1, mipBias=-1, wrapU='repeat', wrapV='repeat', colorSpace='linear', usage='normal', mipPolicy='generate'))))
record(source.with_suffix('.dds.azmeta'), metadata)

asset = target_root / 'character/hair-coverage.glb'
with asset.open('rb') as file:
    magic, version, length, json_length, kind = struct.unpack('<4sIIII', file.read(20))
    assert magic == b'glTF' and version == 2 and kind == 0x4e4f534a and length == asset.stat().st_size
    model = json.loads(file.read(json_length))
    payload = file.read()
material = model['materials'][9]
assert material['name'] == 'M_actor_laevat_hair_01' and material['alphaMode'] == 'MASK' and 'normalTexture' not in material
profile = material['extras']['azureRenderMaterial']
assert profile['coverageTexture']['lodPolicy'] == 'ellipse-major'
image = len(model['images'])
model['images'].append(dict(uri=normal.name))
slot = len(model['textures'])
model['textures'].append(dict(source=image))
material['normalTexture'] = dict(index=slot)
profile['hair']['projectedRamp']['snapshotNormal'] = 'material-normal-rg'
json_data = json.dumps(model, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
json_data += b' ' * (-len(json_data) % 4)
with asset.open('wb') as file:
    file.write(struct.pack('<4sIIII', magic, version, 20 + len(json_data) + len(payload), len(json_data), kind))
    file.write(json_data)
    file.write(payload)

profile_path = target_root / 'config/reference-views.json'
profiles = json.loads(profile_path.read_text())
view = profiles['views']['native-hair']
assert view['produceSceneDepth'] and 'produceSceneVisibilityInputs' not in view
view['produceSceneVisibilityInputs'] = True
write(profile_path, profiles)
for changed in (asset, profile_path):
    row = next(item for item in rows if Path(item['destination']) == changed)
    row.update(inputSha256=row['sha256'], sha256=digest(changed), bytes=changed.stat().st_size)
write(out / 'hair-copy-inputs.json', rows)
print(json.dumps(dict(files=len(rows), bytes=sum(row['bytes'] for row in rows), normalTextureSha256=digest(normal),
    geometryPayloadSha256=hashlib.sha256(payload).hexdigest(), authoredTextureSlot=slot)))
