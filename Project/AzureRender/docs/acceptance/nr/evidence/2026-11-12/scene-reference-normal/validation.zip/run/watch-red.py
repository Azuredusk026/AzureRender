from pathlib import Path
import json
import runpy
import sys
import time

queue=Path('D:/Projects/FYP-coordination/resources/current.json')
token=sys.argv[1]
task=token[5:] if token.startswith('task:') else None
deadline=time.monotonic()+1800
while time.monotonic()<deadline:
    try:
        state=json.loads(queue.read_text())
    except (OSError, ValueError):
        time.sleep(1)
        continue
    if task:
        ready=state.get('task')==task and state.get('state')=='released'
    else:
        ready=state.get('token')!=token or state.get('state')=='released'
    if ready:
        script=Path(__file__).with_name('red.py')
        sys.argv=[str(script),*sys.argv[2:]]
        runpy.run_path(str(script),run_name='__main__')
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed queue group has not retired')
