from hashlib import sha256
from pathlib import Path
import json
import zipfile


run = Path(__file__).resolve().parent
root = run.parents[2]
target = root / 'docs/acceptance/nr/evidence/2026-11-12/scene-reference-normal'
assert not target.exists()


def read(name):
    return json.loads((run / name).read_text())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


labels = ('release-nvidia-fixed-reference-frame', 'release-nvidia-indexed-compute', 'release-intel-fixed-qualified',
    'debug-nvidia-fixed-qualified', 'debug-intel-fixed-qualified')
captures = {name: read(name + '-results.json') for name in labels}
for report in captures.values():
    assert report['hardwareDepthExact'] and report['wholeDepthExact'] and report['selectedObjectIdsExact'] == 17017
    assert report['validationClean'] and report['allocatorZero']
    assert report['capture']['normalFrame'] == 'reference'

controls = {name: read(f'nvidia-normal-visibility-control-{name}/summary.json') for name in (
    'baseline', 'ellipse', 'implicit', 'reference-frame')}
assert controls['reference-frame']['withinOnePixels'] == 17017 and controls['reference-frame']['oneByteGatePassed']
assert controls['reference-frame']['exactPixels'] == 17014
assert all(not controls[name]['oneByteGatePassed'] for name in ('baseline','ellipse','implicit'))
controls['intel-reference-frame'] = read('intel-normal-visibility-control-qualified/summary.json')

original = read('default-four-results.json')
assert original['allExact'] and original['depthCaptureAbsent'] and original['validationClean'] and original['allocatorZero']
comparison = read('configuration-comparison.json')
assert comparison['shaderCatalogsExact']
synthetic = {config:read(f'object-id-control-{config}/summary.json') for config in ('release','debug')}
assert synthetic['debug'] == synthetic['release']
source_replays = {device:read(f'normal-source-replay{suffix}/normal-source.json') for device,suffix in (('nvidia',''),('intel','-intel'))}
assert all(report['status']=='collected' for report in source_replays.values())
for device, report in source_replays.items():
    assert any(source['exactAuthoredPayload'] for source in report['authoredNormalTextureCandidates']), device

target.mkdir(parents=True)
archive = target / 'validation.zip'
paths = set()
paths.update(p.relative_to(run) for p in run.iterdir() if p.is_file() and p.suffix in ('.py','.json','.xml','.log'))
paths.update((Path(name) / item) for name in (label + '-frames' for label in labels)
    for item in ('capture_manifest.json','reference-planes.json','gpu_capabilities.json'))
paths.update(Path(label + '-frames/reference-planes.zip') for label in ('release-nvidia-fixed-reference-frame','release-intel-fixed-qualified'))
for folder in ('configuration-red', 'normal-source-replay', 'normal-source-replay-intel',
    *(f'nvidia-normal-visibility-control-{name}' for name in ('baseline','ellipse','implicit','reference-frame')),
    'intel-normal-visibility-control-qualified','object-id-control-release','object-id-control-debug','default-four-frames'):
    paths.update(p.relative_to(run) for p in (run / folder).iterdir() if p.is_file()
        and p.suffix in ('.json','.log','.asm','.gltf','.azurelevel','.azureproject','.bin') and p.name!='correction.bin')
paths.add(Path('hair-project/config/reference-views.json'))
assert all((run / p).is_file() for p in paths), sorted(p.as_posix() for p in paths if not (run/p).is_file())
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as result:
    for path in sorted(paths):
        result.write(run / path, 'run/' + path.as_posix())
with zipfile.ZipFile(archive) as result:
    assert result.testzip() is None
    contents = {name: sha256(result.read(name)).hexdigest() for name in result.namelist()}
assert archive.stat().st_size<=8*1024*1024
data = dict(status='qualified-scene-reference-visibility-input-producers', overall='failed-user-review',
    baseCommit='7044017', sceneRendererApiVersion=12, source=read('native-normal-stage-proof.json'),
    controls=controls, captures=captures, crossConfiguration=comparison, objectIdentityControl=synthetic,
    originalFour=original, compiledPrograms=891, unchangedPrograms=887, validatedPrograms=4,
    archive=dict(bytes=archive.stat().st_size, sha256=digest(archive), files=len(contents), contents=contents))
(target/'results.json').write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(data['archive'] | {'contents':None}, indent=2))
