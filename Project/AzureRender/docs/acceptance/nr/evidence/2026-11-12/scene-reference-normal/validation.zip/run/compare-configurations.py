from pathlib import Path
import json


out = Path(__file__).resolve().parent
groups = {
    'nvidia-fixed': ('release-nvidia-fixed-reference-frame', 'debug-nvidia-fixed-qualified'),
    'intel-fixed': ('release-intel-fixed-qualified', 'debug-intel-fixed-qualified'),
}
report = {}
for name, (release, debug) in groups.items():
    left, right = [json.loads((out / (label + '-results.json')).read_text()) for label in (release, debug)]
    keys = ('rasterSha256', 'normalsSha256', 'objectIdsSha256', 'color')
    exact = {key: left[key] == right[key] for key in keys}
    assert all(exact.values()), (name, exact)
    assert left['wholeDepthExact'] and right['wholeDepthExact']
    assert left['selectedObjectIdsExact'] == right['selectedObjectIdsExact'] == 17017
    assert all(result['capture']['normalFrame'] == 'reference' for result in (left, right))
    report[name] = dict(inputs=[release, debug], exact=exact)
left, right = [json.loads((out / (label + '-verification.json')).read_text()) for label in ('release', 'debug')]
assert left['sha256'] == right['sha256']
report['shaderCatalogsExact'] = True
(out / 'configuration-comparison.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
