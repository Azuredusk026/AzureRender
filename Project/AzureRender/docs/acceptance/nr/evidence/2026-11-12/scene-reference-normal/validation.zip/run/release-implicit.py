from pathlib import Path
import json
import os
import shutil
import sys
import time


out = Path(__file__).resolve().parent
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def run(task, name, script, *args):
    result = shared.maintenance.guarded_run(out.parents[1], task, [sys.executable, str(out / script), *args], 900)
    (out / (name + '-execution.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    assert result['status'] == 'exited' and result['exitCode'] == 0, result


token = sys.argv[1]
candidate = sys.argv[2] if len(sys.argv)>2 else 'implicit'
assert candidate in ('implicit','reference-frame')
queue = shared.DEFAULT_QUEUE / 'current.json'
deadline = time.monotonic() + 900
while time.monotonic() < deadline:
    try:
        state = json.loads(queue.read_text())
    except (OSError, ValueError):
        time.sleep(1)
        continue
    if state.get('token') != token or state.get('state') == 'released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed original-frame batch has not released the queue')
for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES', 'VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key, None)
os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*', VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',
    VK_LAYER_VALIDATE_SYNC='1')
parent = '20261110-030251-hair-main-chroma-public-9e799c'
with shared.lease(shared.DEFAULT_QUEUE, '01a1c099-8121-7be3-b0b8-7af2f9a06b2a', 'quality-scene-reference-normal-'+candidate, out):
    previous = 'ellipse' if candidate=='implicit' else 'implicit'
    shutil.copyfile(out / 'release-build.log', out / (previous+'-release-build.log'))
    shutil.copyfile(out / 'release-final-build-execution.json', out / (previous+'-release-build-execution.json'))
    if candidate=='reference-frame':
        shutil.copyfile(out / 'release-verification.json', out / 'implicit-release-verification.json')
    shared.maintenance.resume(out.parents[1], parent)
    run(parent, 'release-final-build', 'build.py', 'Release')
    name='release-nvidia-fixed-'+candidate
    run(out.name, name, 'capture-normal.py', 'Release', 'nvidia', 'fixed', candidate)
    run(out.name, candidate+'-normal-visibility', 'normal-visibility-control.py', str(out / (name+'-frames')), 'nvidia', candidate)
