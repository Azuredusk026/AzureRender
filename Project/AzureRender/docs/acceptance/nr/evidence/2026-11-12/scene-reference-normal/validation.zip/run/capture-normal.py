from pathlib import Path
import hashlib
import json
import os
import re
import runpy
import subprocess
import sys

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
configuration, device, binding = sys.argv[1:4]
assert configuration in ('Release', 'Debug') and device in ('nvidia', 'intel') and binding in ('fixed', 'indexed')
label = '-'.join((configuration.lower(), device, binding))
if len(sys.argv)>=5:
    label += '-'+sys.argv[4]
compute = '--compute' in sys.argv[5:]
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration == 'Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
frames = out / (label + '-frames')
previous = out.parent / '20261111-213928-scene-reference-depth-728062'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_plane(path, dtype):
    data = path.read_bytes()
    assert len(data) == 2560*1440*np.dtype(dtype).itemsize, path
    return data, np.frombuffer(data, dtype=dtype).reshape(1440,2560)


def decode_normal(words):
    x = (words&1023).astype('f8')*2/1023-1
    z = ((words>>10)&1023).astype('f8')*2/1023-1
    y = 1-np.abs(x)-np.abs(z)
    nx = np.where(y<0,(1-np.abs(z))*np.where(x<0,-1,1),x)
    nz = np.where(y<0,(1-np.abs(x))*np.where(z<0,-1,1),z)
    normal = np.stack((nx,y,nz),axis=1)
    return normal/np.linalg.norm(normal,axis=1,keepdims=True)


for item in json.loads((out / 'hair-copy-inputs.json').read_text()):
    assert digest(Path(item['destination']).read_bytes()) == item['sha256'], item
command = [str(build/'AzurePlayer.exe'), '--project', str(out/'hair-project/hair-coverage.azureproject'),
    '--width','2560','--height','1440','--capture-frames','3','--capture-dir',str(frames),'--fixed-frame-step',
    '--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty',
    '--disable-parallel-recording','--resource-root',str(build)]
if not compute:
    command.append('--disable-compute-skinning')
if binding == 'fixed':
    command.append('--disable-bindless')
(out / (label + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
environment = os.environ.copy()
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    environment.pop(key,None)
environment.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*' if device=='nvidia' else '*igvk64*',
    VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
log_path = out / (label + '.log')
with log_path.open('wb') as log:
    process = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=420)
log = log_path.read_text(errors='replace')
assert process.returncode == 0 and not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I),log[-6000:]
assert 'Allocator after unload: buffers=0 images=0' in log and 'Character texture access: '+binding+',' in log
assert ('vertex-shader fallback path' in log)==(not compute)
manifest = json.loads((frames/'capture_manifest.json').read_text())
capture = manifest['referenceSceneDepth']
assert (capture['width'],capture['height'],capture['submission'],capture['rowOrigin'])==(2560,1440,3,'bottom-left')
raster_bytes, raster = read_plane(frames/capture['raster'], '<u4')
hardware_bytes, hardware = read_plane(frames/capture['hardware'], '<u4')
normal_bytes, normals = read_plane(frames/capture['packedNormals'], '<u4')
id_bytes, ids = read_plane(frames/capture['objectIds'], 'u1')
assert raster_bytes==hardware_bytes
assert np.count_nonzero((raster==0)&(ids!=0))==0

baseline = runpy.run_path(str(out.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
ys,xs = np.nonzero(baseline['mask'])
x,y,ui_y = xs+1140,1439-(ys+130),ys+130
assert len(x)==17017 and np.all(ids[y,x]==1)
fixture = json.loads((out/'normal-source-inspection.json').read_text())
native_data,native = read_plane(Path(fixture['nativeNormalPath']),'<u4')
assert digest(native_data)==fixture['nativeNormalSha256']
expected = native[y,x]
if capture.get('normalFrame')!='reference':
    # The initial engine-basis control used a signed X-axis reflection.
    expected = (expected&0xfffffc00) | (1023-(expected&1023))
actual = normals[y,x]
assert np.all((actual>>30)==3) and np.all(((actual>>20)&1023)==0)
channel_errors = [np.abs(((actual>>shift)&1023).astype('i4')-((expected>>shift)&1023).astype('i4')) for shift in (0,10)]
maximum = np.maximum(*channel_errors)
angle = np.degrees(np.arccos(np.clip(np.sum(decode_normal(actual)*decode_normal(expected),axis=1),-1,1)))
prior_label = 'release-nvidia-indexed-qualified' if device=='nvidia' else 'release-intel-fixed-qualified'
prior_bytes,prior = read_plane(previous/(prior_label+'-frames/reference-depth-r32.bin'),'<u4')
color = []
for index in range(3):
    path=frames/f'frame_{index:06d}.png'
    display=np.asarray(Image.open(path).convert('RGB'))
    error=np.abs(display[ui_y,x].astype('i4')-baseline['expected'][baseline['mask']])
    color.append(dict(frame=index,sha256=digest(path.read_bytes()),overOne=int((error.max(axis=1)>1).sum()),maxByteError=int(error.max())))
changed = np.flatnonzero(maximum>0)
worst = sorted(changed,key=lambda i:maximum[i],reverse=True)[:20]
report = dict(configuration=configuration,device=device,binding=binding,computeSkinning=compute,capture=capture,
    rasterSha256=digest(raster_bytes),priorRasterSha256=digest(prior_bytes),normalsSha256=digest(normal_bytes),
    objectIdsSha256=digest(id_bytes),wholeDepthExact=raster_bytes==prior_bytes,
    selectedDepthExact=int((raster[y,x]==prior[y,x]).sum()), hardwareDepthExact=True,
    selectedObjectIdsExact=int((ids[y,x]==1).sum()), packedNormalExact=int((actual==expected).sum()),
    normalWithinOne=int((maximum<=1).sum()), maximumNormalCodeError=int(maximum.max()),
    normalExactPerChannel=[int((error==0).sum()) for error in channel_errors], color=color, validationClean=True, allocatorZero=True,
    normalAngleDegrees=dict(median=float(np.median(angle)),p95=float(np.percentile(angle,95)),maximum=float(angle.max())),
    strongest=[dict(pixel=[int(x[i]),int(ui_y[i])],actual=int(actual[i]),expected=int(expected[i]),error=int(maximum[i])) for i in worst])
(out / (label+'-results.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
assert report['selectedDepthExact']==17017
