from hashlib import sha256
from pathlib import Path
import base64
import json
import math
import re
import subprocess
import sys

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
engine = out.parents[2]
build = out.parent / '20261110-030251-hair-main-chroma-public-9e799c/release'
sys.path.insert(0, str(engine / 'tools'))
from native_render.light_lab import generate
from test_outline_projection_gpu import sphere


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def check(label, enabled, visibility, fixed):
    fixture = out / 'reference-outline-control' / label
    generate(fixture, 'directional-near')
    model, payload, _ = sphere()
    model['buffers'] = [dict(byteLength=len(payload), uri='data:application/octet-stream;base64,' + base64.b64encode(payload).decode())]
    Image.new('RGBA', (4, 4), (255, 255, 0, 255)).save(fixture / 'mask.png')
    model['images'] = [dict(uri='mask.png')]
    model['textures'] = [dict(source=0, sampler=0)]
    model['samplers'] = [dict(wrapS=33071, wrapT=33071, magFilter=9729, minFilter=9729)]
    model['materials'] = [dict(name='reference-outline', extras=dict(azureRenderMaterial=dict(schemaVersion=2,
        **{'class': 'generic'}, features=['silhouette-outline'], outlineSurface=dict(schemaVersion=1, mode='view-scaled', width=4, minimumPixels=1,
            depthOffset=.1, depthPrepass=enabled, normalSource='geometry', maskTexture=0, color=[1, 0, 0]))))]
    write(fixture / 'plane.gltf', model)
    level_path = fixture / 'level.azurelevel'
    level = json.loads(level_path.read_text())
    camera, = [node['components'] for node in level['nodes'] if node['id'] == 'camera']
    camera['azure.camera']['data'] = dict(enabled=True, priority=1, fieldOfView=55, nearPlane=.1, farPlane=20)
    camera['azure.reference-camera'] = dict(type='azure.reference-camera', version=1, data=dict(enabled=True,
        view='outline', anchorPosition=[0, 0, 5], anchorRight=[1, 0, 0], anchorUp=[0, 1, 0], anchorBack=[0, 0, 1]))
    level['renderSettings']['antiAliasing'] = 0
    write(level_path, level)
    scale = 1 / math.tan(math.radians(55) / 2)
    view = dict(schemaVersion=1, frame=dict(schemaVersion=1, axes=[1, 2, 3], offset=[0, 0, 0]),
        projection=dict(schemaVersion=1, columns=[[scale, 0, 0, 0], [0, -scale, 0, 0], [0, 0, 0, -1],
            [0, 0, .1, 5]], jitter=[0, 0]), extent=[128, 128], depthConvention='reversed', flipNdcY=False,
        produceSceneDepth=True)
    if visibility:
        view['produceSceneVisibilityInputs'] = True
    (fixture / 'config').mkdir()
    write(fixture / 'config/reference-views.json', dict(schemaVersion=1, views=dict(outline=view)))
    frames = fixture / 'frames'
    player = build / 'AzurePlayer.exe'
    command = [str(player), '--project', str(fixture / 'lab.azureproject'), '--width', '128', '--height', '128',
        '--capture-dir', str(frames), '--capture-frames', '3', '--fixed-frame-step', '--qa-camera', 'scene',
        '--qa-light', 'scene', '--resource-root', str(build)]
    if fixed:
        command.extend(['--disable-bindless', '--disable-compute-skinning'])
    write(fixture / 'command.json', command)
    log = fixture / 'player.log'
    with log.open('wb') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=150)
    diagnostic = log.read_text(errors='replace')
    assert result.returncode == 0 and 'Allocator after unload: buffers=0 images=0' in diagnostic, diagnostic[-4500:]
    assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]', diagnostic, re.I), diagnostic[-4500:]
    assert ('Character texture access: fixed,' if fixed else 'Character texture access: indexed,') in diagnostic, diagnostic[-4500:]
    manifest = json.loads((frames / 'capture_manifest.json').read_text())['referenceSceneDepth']
    assert (manifest['rowOrigin'], manifest['width'], manifest['height'], manifest['submission']) == ('bottom-left', 128, 128, 3)
    assert ('packedNormals' in manifest) == ('objectIds' in manifest) == visibility
    plane = {name: (frames / manifest[name]).read_bytes() for name in
        ('raster', 'hardware', 'packedNormals', 'objectIds') if name in manifest}
    assert plane['raster'] == plane['hardware']
    return plane


off = check('off', False, True, True)
on = check('on-fixed', True, True, True)
indexed = check('on-indexed', True, True, False)
depth_only = check('depth-only', True, False, True)
assert on['packedNormals'] == off['packedNormals'] and on['objectIds'] == off['objectIds']
assert on == indexed and on['raster'] == depth_only['raster']
baseline = np.frombuffer(off['raster'], '<f4')
visible = np.frombuffer(on['raster'], '<f4')
assert np.all(visible >= baseline)
growth = (baseline == 0) & (visible > 0)
assert int(growth.sum()) > 0
result = dict(newlyCovered=int(growth.sum()), changedDepth=int((baseline != visible).sum()),
    writesDepthOnly=True, fixedIndexedExact=True, depthOnlyExact=True, normalsExact=True, objectIdsExact=True,
    offDepthSha256=sha256(off['raster']).hexdigest(), onDepthSha256=sha256(on['raster']).hexdigest())
write(out / 'reference-outline-control' / 'summary.json', result)
print(json.dumps(result))
