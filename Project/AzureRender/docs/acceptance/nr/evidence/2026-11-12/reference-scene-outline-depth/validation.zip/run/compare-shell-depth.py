from hashlib import sha256
from pathlib import Path
import json
import sys
import zipfile
import zlib

import numpy as np


out = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in ('red', 'green')
profile = out.parent / '20261112-061922-project-reference-visibility-profile-47902e'
replay = out.parent / '20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry'
atlas = out.parent / '20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
numeric = out.parent / '20261110-003435-visibility-numeric-contract-4f95e7'
hair = out.parent / '20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
native = json.loads((replay / 'native-caster-geometry.json').read_text())
normals = json.loads((atlas / 'native-atlas-producers.json').read_text())
assert native['status'] == normals['status'] == 'qualified'


def load_crop(folder, entry):
    payload = (folder / entry['path']).read_bytes()
    assert sha256(payload).hexdigest() == entry['sha256'] and len(payload) == entry['bytes']
    return np.frombuffer(zlib.decompress(payload), '<u4').reshape(310, 290)


receiver = np.fromfile(numeric / 'receiver-queries.bin', '<f4').reshape(-1, 4)
x, y = receiver[:, :2].astype('i4').T
rows, columns = y - 1000, x - 1140
assert len(x) == 49384 and np.all((rows >= 0) & (rows < 310) & (columns >= 0) & (columns < 290))
last = np.zeros((310, 290), dtype='<u4')
owner = np.zeros_like(last, dtype='u2')
for event, stage in normals['receiverNormal']['stages'].items():
    current = load_crop(atlas, stage['crop'])
    owner[current != last] = int(event)
    last = current
source = {event: load_crop(replay, native['receiverDepth'][str(event)]['crop'])[rows, columns]
    for event in (422, 440, 699)}
projection = np.fromfile(replay / '440-0-b0.bin', '<f4').reshape(-1, 4)
scene_slope = float(projection[34, 2]) / float(projection[34, 3])
scene_intercept = float(projection[35, 2])
shell_slope = -float(projection[10, 2])
shell_intercept = float(projection[11, 2])
target = source[699]
native_shell = (source[422] != source[440]) & (source[440] == target)
normal_owner = owner[rows, columns]
shell = (normal_owner == 422) & native_shell
hair_query = np.fromfile(hair / 'queries.bin', '<f4').reshape(-1, 4)
hx, hy = hair_query[:, :2].astype('i4').T
in_hair = np.isin(y * 2560 + x, hy * 2560 + hx)
assert shell.sum() == 2046 and in_hair.sum() == 17017 and not (shell & in_hair).any()
expected = np.fromfile(numeric / 'receiver-expected.bin', '<u4').astype('i4')


def attachments(folder):
    names = json.loads((folder / 'capture_manifest.json').read_text())['referenceSceneDepth']
    assert (names['rowOrigin'], names['width'], names['height']) == ('bottom-left', 2560, 1440)
    mapping = json.loads((folder / 'reference-planes.json').read_text())
    with zipfile.ZipFile(folder / 'reference-planes.zip') as archive:
        planes = {label: archive.read(mapping[names[label]]['archiveEntry'])
            for label in ('raster', 'hardware', 'packedNormals', 'objectIds', 'objectVisibility')}
    assert planes['raster'] == planes['hardware']
    assert all(sha256(data).hexdigest() == mapping[names[label]]['sha256'] for label, data in planes.items())
    return planes


labels = ('release-nvidia', 'release-intel') if mode == 'red' else tuple(
    f'{config}-{device}' for config in ('release', 'debug') for device in ('nvidia', 'intel'))
if len(sys.argv) > 2:
    assert mode == 'green' and set(sys.argv[2:]) <= set(labels)
    labels = tuple(sys.argv[2:])
report = {}
for label in labels:
    before = attachments(profile / (label + '-frames'))
    after = before if mode == 'red' else attachments(out / (label + '-frames'))
    assert all(before[field] == after[field] for field in ('packedNormals', 'objectIds'))
    previous_depth = np.frombuffer(before['raster'], '<u4').reshape(1440, 2560)[y, x]
    actual_depth = np.frombuffer(after['raster'], '<u4').reshape(1440, 2560)[y, x]
    actual_rg8 = np.frombuffer(after['objectVisibility'], 'u1').reshape(1440, 2560, 2)[y, x, 1].astype('i4')
    old_rg8 = np.frombuffer(before['objectVisibility'], 'u1').reshape(1440, 2560, 2)[y, x, 1].astype('i4')
    signed_ulp = actual_depth.astype('i8') - target.astype('i8')
    depth_ulp = np.abs(signed_ulp)
    previous_ulp = np.abs(previous_depth.astype('i8') - target.astype('i8'))
    failed = np.abs(actual_rg8 - expected) > 1
    old_failed = np.abs(old_rg8 - expected) > 1
    actual_shell = previous_depth != actual_depth
    shifted = shell & actual_shell
    introduced = ~old_failed & failed
    by_normal_owner = {}
    for event in np.unique(normal_owner):
        positions = normal_owner == event
        by_normal_owner[int(event)] = dict(pixels=int(positions.sum()), previousOverOne=int((positions & old_failed).sum()),
            overOne=int((positions & failed).sum()))
    linear_control = {}
    if shifted.any():
        current = actual_depth.view('<f4')[shifted].astype('f8')
        adjusted = ((current - scene_slope) * (shell_intercept / scene_intercept) + shell_slope).astype('<f4')
        delta = adjusted.view('<u4').astype('i8') - target[shifted].astype('i8')
        linear_control = dict(samples=int(shifted.sum()), exact=int((delta == 0).sum()), withinOneUlp=int((abs(delta) <= 1).sum()),
            signedUlp=np.quantile(delta, [0, .05, .25, .5, .75, .95, 1]).tolist(),
            base=[scene_slope, scene_intercept], outline=[shell_slope, shell_intercept])
    report[label] = dict(referenceDepthSha256=sha256(after['raster']).hexdigest(), receiverByNativeNormalOwner=by_normal_owner,
        shellPixels=int(shell.sum()), shellDepthExact=int((shell & (depth_ulp == 0)).sum()),
        shellDepthWithinOneUlp=int((shell & (depth_ulp <= 1)).sum()),
        shellDepthChanged=int((shell & (previous_depth != actual_depth)).sum()),
        shellDepthCloser=int((shell & (depth_ulp < previous_ulp)).sum()),
        shellDepthFurther=int((shell & (depth_ulp > previous_ulp)).sum()),
        shellDepthMedianUlp=float(np.median(depth_ulp[shell])), previousShellDepthMedianUlp=float(np.median(previous_ulp[shell])),
        shellSignedUlp=np.quantile(signed_ulp[shell], [0, .05, .25, .5, .75, .95, 1]).tolist(),
        shellWithin64Ulp=int((shell & (depth_ulp <= 64)).sum()),
        nativeProjectionControl=linear_control,
        shellVisibilityOverOne=int((shell & failed).sum()), previousShellVisibilityOverOne=int((shell & old_failed).sum()),
        shellVisibilityClosed=int((shell & old_failed & ~failed).sum()), shellVisibilityIntroduced=int((shell & ~old_failed & failed).sum()),
        receiverVisibilityOverOne=int(failed.sum()), previousReceiverVisibilityOverOne=int(old_failed.sum()),
        receiverVisibilityClosed=int((old_failed & ~failed).sum()), receiverVisibilityIntroduced=int(introduced.sum()),
        receiverShellWrites=dict(native=int(native_shell.sum()), actual=int(actual_shell.sum()), shared=int((native_shell & actual_shell).sum()),
            actualOnly=int((~native_shell & actual_shell).sum()), nativeOnly=int((native_shell & ~actual_shell).sum()),
            introducedShared=int((introduced & native_shell & actual_shell).sum()),
            introducedActualOnly=int((introduced & ~native_shell & actual_shell).sum())),
        hairDepthChanged=int((in_hair & (previous_depth != actual_depth)).sum()),
        hairVisibilityOverOne=int((in_hair & failed).sum()), previousHairVisibilityOverOne=int((in_hair & old_failed).sum()),
        normalsExact=True, objectIdsExact=True)
    if mode == 'red':
        assert report[label]['shellDepthExact'] < report[label]['shellPixels'] and report[label]['shellVisibilityOverOne'] > 0
suffix = '-' + '-'.join(labels) if len(sys.argv) > 2 else ''
(out / (mode + '-shell-depth-comparison' + suffix + '.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
