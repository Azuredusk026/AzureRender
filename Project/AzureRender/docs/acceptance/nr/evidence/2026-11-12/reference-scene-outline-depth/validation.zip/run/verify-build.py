from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys


out=Path(__file__).resolve().parent
configuration=sys.argv[1]
assert configuration in ('Release','Debug')
prefix=configuration.lower()
build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
prior=out.parent/'20261111-232828-scene-reference-normal-60ddfa'/f'{prefix}-verification.json'
catalog={path.name:sha256(path.read_bytes()).hexdigest() for path in (build/'shaders').glob('*.spv')}
baseline=json.loads(prior.read_text())['sha256']
atlas=out.parent/'20261112-040725-reference-object-shadow-raster-2c9e58'
previous=json.loads((atlas/f'{prefix}-verification.json').read_text())['changedShaders']
baseline.update({name:entry['sha256'] for name,entry in previous.items()})
material_stage=out.parent/'20261112-044926-material-reference-object-visibility-344def'
previous=json.loads((material_stage/f'{prefix}-verification.json').read_text())['changedShaders']
baseline.update({name:entry['sha256'] for name,entry in previous.items()})
outline_programs={'reference_scene_outline_depth'+skin+bind+'.vert.spv'
    for skin in ('','_compute') for bind in ('','_bindless')}
assert catalog.keys()==baseline.keys()|outline_programs and len(baseline)==891 and len(catalog)==895
changed={name:{'sourceSha256':value,'sha256':catalog[name]} for name,value in baseline.items() if value!=catalog[name]}
assert not changed,changed
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
if len(sys.argv)>2:
    assert sys.argv[2] in ('nvidia','intel')
    prefix+='-'+sys.argv[2]+'-gpu'
    regex='^AzureRender[.](ScreenObjectVisibility(Gpu|ReferenceGpu)|ReferenceDepth(Coverage)?Gpu|SurfaceResponseGpu)$'
else:
    editor='|AzureEditor[.]ProjectFlow' if configuration=='Release' else ''
    regex='^(AzureRender[.](ReferenceCameraView|ReferenceCameraBinding|ExtensionRegistry|ScreenObjectVisibility)|AzureEngine[.]ProjectReferenceViews'+editor+')$'
command=[ctest,'--test-dir',str(build),'-R',regex,'--no-tests=error','--output-on-failure','--output-junit',str(out/(prefix+'-ctest.xml'))]
with (out/(prefix+'-ctest.log')).open('wb') as log:
    process=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
report=dict(configuration=configuration,shaderCount=len(catalog),changedShaders=changed,
    newShaders={name:catalog[name] for name in sorted(outline_programs)},ctestCommand=command,
    ctestExit=process.returncode,playerSha256=sha256((build/'AzurePlayer.exe').read_bytes()).hexdigest())
(out/(prefix+'-verification.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({**report,'changedShaders':len(changed)}))
assert process.returncode==0,(out/(prefix+'-ctest.log')).read_text(errors='replace')
