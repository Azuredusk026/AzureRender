from hashlib import file_digest, sha256
from pathlib import Path
import json
import sys
import xml.etree.ElementTree as xml
import zipfile


out = Path(__file__).resolve().parent
engine = out.parents[2]
target = engine / 'docs/acceptance/nr/evidence/2026-11-12/reference-scene-outline-depth'
labels = tuple(f'{config}-{device}' for config in ('release', 'debug') for device in ('nvidia', 'intel'))


def read(name):
    return json.loads((out / name).read_text(encoding='utf-8-sig'))


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def receipt(name):
    result = read(name + '-execution.json')
    assert result['status'] == 'exited' and result['exitCode'] == 0, result
    return result


builds = {}
for name in ('release', 'debug', *(label + '-gpu' for label in labels)):
    result = read(name + '-verification.json')
    assert result['shaderCount'] == 895 and result['ctestExit'] == 0
    assert not result['changedShaders']
    suite = xml.parse(out / (name + '-ctest.xml')).getroot()
    expected = 6 if name == 'release' else 5
    assert len(suite.findall('.//testcase')) == expected
    assert not any(suite.findall(path) for path in ('.//failure', './/error', './/skipped'))
    builds[name] = dict(**result, tests=expected)
build_execution = {name: receipt(name) for name in ('release-build', 'debug-link-recovery', 'release-cpu-tests', 'debug-cpu-tests',
    *(f'{label}-{test}' for label in labels for test in ('gpu-tests', 'capture')))}
red = read('red-shell-depth-comparison.json')
for label, count in (('release-nvidia', 878), ('release-intel', 881)):
    assert red[label]['shellPixels'] == 2046 and red[label]['shellDepthWithinOneUlp'] == 0
    assert red[label]['shellVisibilityOverOne'] == count and red[label]['receiverShellWrites']['actual'] == 0
green = {label: read(f'green-shell-depth-comparison-{label}.json')[label] for label in labels}
captures = {label: read(label + '-results.json') for label in labels}
fields = ('visibilitySha256', 'referenceDepthSha256', 'referenceNormalsSha256', 'objectIdsSha256', 'colors',
    'colorHair', 'colorHairBaseline', 'hair', 'receiver')
cross = {}
for device in ('nvidia', 'intel'):
    release, debug = (f'{config}-{device}' for config in ('release', 'debug'))
    assert green[release] == green[debug]
    cross[device] = {field: captures[release][field] == captures[debug][field] for field in fields}
    assert all(cross[device].values())
for label, capture in captures.items():
    assert capture['validationClean'] and capture['allocatorZero']
    assert capture['hair']['pixels'] == capture['colorHair']['pixels'] == 17017 and capture['receiver']['pixels'] == 49384
    assert green[label]['shellPixels'] == 2046 and green[label]['shellDepthCloser'] == 2042
    assert green[label]['hairDepthChanged'] == 0 and green[label]['normalsExact'] and green[label]['objectIdsExact']
    expected = (46, 1712, 0, 0) if label.endswith('nvidia') else (66, 1976, 208, 575)
    assert (green[label]['shellVisibilityOverOne'], capture['receiver']['overOne'], capture['hair']['overOne'],
        capture['colorHair']['overOne']) == expected
    assert builds[label + '-gpu']['playerSha256'] == builds[label.split('-')[0]]['playerSha256']
    planes = read(label + '-frames/reference-planes.json')
    for name, key in (('depth-r32', 'referenceDepthSha256'), ('depth-d32', 'referenceDepthSha256'),
        ('normals-a2b10g10r10', 'referenceNormalsSha256'), ('object-ids-r8', 'objectIdsSha256'),
        ('object-visibility-rg8', 'visibilitySha256')):
        assert planes[f'reference-{name}.bin']['sha256'] == capture[key]

if sys.argv[1:] == ['--preflight-only']:
    print(json.dumps(dict(buildTests={name: value['tests'] for name, value in builds.items()}, crossConfiguration=cross)))
    sys.exit(0)
control = read('reference-outline-control/summary.json')
assert control['newlyCovered'] > 0 and all(control[key] for key in
    ('writesDepthOnly', 'fixedIndexedExact', 'depthOnlyExact', 'normalsExact', 'objectIdsExact'))
original = read('default-four-results.json')
assert original['allExact'] and original['depthCaptureAbsent'] and original['validationClean'] and original['allocatorZero']
assert original['projectSha256'] == '13638585d18092a315bd7586a88b349fe256c468eb9090ccb6189232b8209d78'
for name in ('outline-control', 'original-four'):
    receipt(name)


archive = out / 'reference-outline-validation-pending.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as writer:
    def add(path):
        writer.write(path, 'run/' + path.relative_to(out).as_posix())

    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.json', '.xml', '.log'):
            add(path)
    for label in labels:
        for name in ('capture_manifest.json', 'gpu_capabilities.json', 'reference-planes.json'):
            add(out / (label + '-frames') / name)
    controls = out / 'reference-outline-control'
    add(controls / 'summary.json')
    for case in ('off', 'on-fixed', 'on-indexed', 'depth-only'):
        fixture = controls / case
        for name in ('command.json', 'player.log', 'plane.gltf', 'mask.png', 'level.azurelevel', 'lab.azureproject', 'config/reference-views.json',
            'frames/capture_manifest.json'):
            add(fixture / name)
        manifest = read(f'reference-outline-control/{case}/frames/capture_manifest.json')['referenceSceneDepth']
        for name in ('raster', 'hardware', 'packedNormals', 'objectIds'):
            if name in manifest:
                add(fixture / 'frames' / manifest[name])
    add(out / 'default-four-frames/capture_manifest.json')
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    files = {name: sha256(reader.read(name)).hexdigest() for name in reader.namelist()}
assert archive.stat().st_size <= 8 * 1024 * 1024

result = dict(status='qualified-reference-scene-outline-depth', overall='failed-user-review',
    baseCommit='b21e221bc534fa7d4ebeb4caa2f6be9a4a1fbb5f', acceptedMaximumByteError=1,
    fixture=read('profile-fixture-inputs.json'), builds=builds, buildExecution=build_execution, captures=captures,
    red=red, green=green, crossConfiguration=cross, referenceControl=control, originalFour=original,
    archive=dict(bytes=archive.stat().st_size, sha256=digest(archive), files=len(files), contents=files))
target.mkdir(parents=True, exist_ok=True)
assert not (target / 'validation.zip').exists() and not (target / 'results.json').exists()
archive.rename(target / 'validation.zip')
(target / 'results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in result['archive'].items() if key != 'contents'}))
