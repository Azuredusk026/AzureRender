from hashlib import file_digest
from pathlib import Path
import json
import subprocess
import sys


out = Path(__file__).resolve().parent
engine = out.parents[2]
build = (out.parent / '20261110-031856-hair-main-chroma-debug-668bf2/debug').resolve(strict=True)
assert build.parent.parent == out.parent and not build.is_symlink()
queue = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_text())
assert queue['state'] == 'held' and queue['owner'] == '01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0, str(engine / 'tools'))
from artifact_maintenance import measure


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


ninja = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
targets = ['AzurePlayer', 'AzureReferenceCameraViewTests', 'AzureProjectReferenceViewsTests', 'AzureRenderExtensionRegistryTests',
    'AzureReferenceCameraBindingTests', 'AzureScreenObjectVisibilityTests', 'AzureScreenObjectVisibilityGpuTests',
    'AzureReferenceDepthGpuTests', 'AzureReferenceDepthCoverageGpuTests', 'AzureSurfaceResponseGpuTests']
command = [ninja, '-C', str(build), '-n', *targets]
cmake = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
batch = 'D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'
configure = [batch, cmake, '-S', str(engine), '-B', str(build)]
with (out / 'debug-configure.log').open('wb') as log:
    subprocess.run(subprocess.list2cmdline(configure), shell=True, cwd=engine, stdout=log, stderr=subprocess.STDOUT, timeout=90, check=True)
plan = subprocess.check_output(command, text=True)
previous = out.parent / '20261112-061922-project-reference-visibility-profile-47902e/debug-verification.json'
assert digest(build / 'AzurePlayer.exe') == json.loads(previous.read_text())['playerSha256']
assert 'Linking CXX executable AzurePlayer.exe' in plan
symbols = build / 'AzurePlayer.pdb'
assert not any('AzurePlayer.pdb' in line for line in (build / 'build.ninja').read_text(encoding='utf-8').splitlines()
    if line.startswith('build AzurePlayer.exe'))
archive = out / 'build-symbols'
archive.mkdir(exist_ok=True)
assert archive.resolve() == out / 'build-symbols'
destination = archive / 'previous-AzurePlayer.pdb'
assert not destination.exists()
before = measure(build.parent)
files = []
for path in (symbols, build / 'AzureRenderCore.lib'):
    assert path.is_file() and not path.is_symlink() and path.resolve(strict=True).parent == build and path.stat().st_nlink == 1
    assert subprocess.run(['git', '-C', str(engine), 'check-ignore', '-q', str(path)]).returncode == 0
    if path != symbols:
        assert 'Linking CXX static library ' + path.name in plan
    files.append(dict(name=path.name, bytes=path.stat().st_size, sha256=digest(path)))

symbols.rename(destination)
assert digest(destination) == files[0]['sha256']
files[0]['archived'] = str(destination)
for item in files[1:]:
    (build / item['name']).unlink()
after = measure(build.parent)
assert before - after == sum(item['bytes'] for item in files)
assert subprocess.check_output(command, text=True) == plan
(out / 'debug-link-budget-preparation.json').write_text(json.dumps(dict(before=before, after=after, files=files,
    command=command, configure=configure), indent=2) + '\n')
print(f'Debug generated outputs {before} -> {after} bytes')
