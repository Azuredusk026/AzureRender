from hashlib import file_digest
from pathlib import Path
import gzip
import json
import shutil
import subprocess
import sys


out = Path(__file__).resolve().parent
engine = out.parents[2]
build = (out.parent / '20261110-031856-hair-main-chroma-debug-668bf2/debug').resolve(strict=True)
archive = (out / 'build-symbols').resolve(strict=True)
assert build.parent.parent == out.parent and archive.parent == out
sys.path.insert(0, str(engine / 'tools'))
from artifact_maintenance import measure


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def store(source, label):
    assert source.resolve(strict=True).parent in (build, archive)
    assert not source.is_symlink() and source.stat().st_nlink == 1
    assert subprocess.run(['git', '-C', str(engine), 'check-ignore', '-q', str(source)]).returncode == 0
    target = archive / (label + '.gz')
    assert not target.exists()
    size = source.stat().st_size
    fingerprint = digest(source)
    try:
        with source.open('rb') as stream, gzip.open(target, 'xb', compresslevel=3) as compressed:
            shutil.copyfileobj(stream, compressed, 1024 * 1024)
        with gzip.open(target, 'rb') as compressed:
            assert file_digest(compressed, 'sha256').hexdigest() == fingerprint
        measure(out)
    except Exception:
        if target.exists():
            target.unlink()
        raise
    source.unlink()
    return dict(name=source.name, bytes=size, sha256=fingerprint, archive=str(target), archiveBytes=target.stat().st_size)


receipt = out / 'debug-link-recovery.json'
if sys.argv[1:] == ['--compress-previous']:
    previous = archive / 'previous-AzurePlayer.pdb'
    expected = json.loads((out / 'debug-link-budget-preparation.json').read_text())['files'][0]
    assert digest(previous) == expected['sha256']
    report = store(previous, 'previous-AzurePlayer.pdb')
    (out / 'previous-player-symbols.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))
    sys.exit(0)

queue = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_text())
assert queue['state'] == 'held' and queue['owner'] == '01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
ninja = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
cmake = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
environment = 'D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'
tests = ['AzureReferenceCameraViewTests', 'AzureProjectReferenceViewsTests', 'AzureRenderExtensionRegistryTests',
    'AzureReferenceCameraBindingTests', 'AzureScreenObjectVisibilityTests', 'AzureScreenObjectVisibilityGpuTests',
    'AzureReferenceDepthGpuTests', 'AzureReferenceDepthCoverageGpuTests', 'AzureSurfaceResponseGpuTests']
targets = tests + ['AzurePlayer']
dry_run = [ninja, '-C', str(build), '-n', *targets]
commands = []
archived = []
before = measure(build.parent)

with (out / 'debug-link-recovery.log').open('wb') as log:
    for target in targets:
        command = [environment, cmake, '--build', str(build), '--target', target, '--parallel', '1']
        commands.append(command)
        subprocess.run(subprocess.list2cmdline(command), cwd=engine, shell=True, stdout=log,
            stderr=subprocess.STDOUT, timeout=90, check=True)
        symbols = build / (target + '.pdb')
        if symbols.is_file():
            rule = 'build ' + target + '.exe'
            assert not any(symbols.name in line for line in (build / 'build.ninja').read_text(encoding='utf-8').splitlines()
                if line.startswith(rule))
            archived.append(store(symbols, target + '.pdb'))
        with (build / (target + '.exe')).open('rb') as executable:
            assert executable.read(2) == b'MZ'
        measure(build.parent)

plan = subprocess.check_output(dry_run, text=True)
assert '[1/1]' in plan and 'generate_script_bindings.py --check' in plan and 'Linking' not in plan, plan
report = dict(before=before, after=measure(build.parent), commands=commands, symbols=archived, dryRun=plan)
receipt.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
