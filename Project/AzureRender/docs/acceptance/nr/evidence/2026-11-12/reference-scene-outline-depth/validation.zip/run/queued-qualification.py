from pathlib import Path
import json
import os
import subprocess
import sys
import time


out = Path(__file__).resolve().parent
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def run(task, name, script, *args):
    command = [sys.executable, '-B', str(out / script), *args]
    execution = shared.maintenance.guarded_run(out.parents[1], task, command, 650)
    (out / (name + '-execution.json')).write_text(json.dumps(execution, indent=2) + '\n')
    print(json.dumps(execution), flush=True)
    assert execution['status'] == 'exited' and execution['exitCode'] == 0, execution


def capture(config, device):
    os.environ['VK_LOADER_DRIVERS_SELECT'] = '*igvk64*' if device == 'intel' else '*nv-vk64*'
    label = config.lower() + '-' + device
    run(out.name, label + '-gpu-tests', 'verify-build.py', config, device)
    run(out.name, label + '-capture', 'capture-hair-visibility.py', config, device)
    subprocess.run([sys.executable, '-B', str(out / 'compact-capture.py'), label + '-frames'], check=True)


def debug_build():
    parent = '20261110-031856-hair-main-chroma-debug-668bf2'
    shared.maintenance.resume(out.parents[1], parent)
    run(parent, 'debug-prepare', 'prepare-debug-budget.py')
    run(parent, 'debug-build', 'build.py', 'Debug')
    run(out.name, 'debug-cpu-tests', 'verify-build.py', 'Debug')


token, batch = sys.argv[1:]
assert batch in ('release-nvidia', 'release-intel', 'debug-nvidia', 'debug-intel', 'debug-build',
    'intel-and-debug-build', 'debug-actual', 'debug-recover-actual', 'original-four', 'outline-control',
    'original-and-control')
deadline = time.monotonic() + 1200
while time.monotonic() < deadline:
    try:
        state = json.loads((shared.DEFAULT_QUEUE / 'current.json').read_text())
    except (OSError, ValueError):
        time.sleep(1)
        continue
    if state.get('token') != token or state.get('state') == 'released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed outline depth window has not opened')

for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES', 'VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key, None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LAYER_VALIDATE_SYNC='1')
with shared.lease(shared.DEFAULT_QUEUE, '01a1c099-8121-7be3-b0b8-7af2f9a06b2a',
        'quality-reference-scene-outline-depth-' + batch, out):
    if batch == 'release-nvidia':
        parent = '20261110-030251-hair-main-chroma-public-9e799c'
        shared.maintenance.resume(out.parents[1], parent)
        run(parent, 'release-build', 'build.py', 'Release')
        run(out.name, 'release-cpu-tests', 'verify-build.py', 'Release')
        capture('Release', 'nvidia')
    elif batch == 'debug-build':
        debug_build()
    elif batch == 'intel-and-debug-build':
        capture('Release', 'intel')
        debug_build()
    elif batch in ('debug-actual', 'debug-recover-actual'):
        if batch == 'debug-recover-actual':
            parent = '20261110-031856-hair-main-chroma-debug-668bf2'
            shared.maintenance.resume(out.parents[1], parent)
            run(parent, 'debug-link-recovery', 'recover-debug-link.py')
            run(out.name, 'debug-cpu-tests', 'verify-build.py', 'Debug')
        for device in ('nvidia', 'intel'):
            capture('Debug', device)
    elif batch in ('original-four', 'outline-control', 'original-and-control'):
        os.environ['VK_LOADER_DRIVERS_SELECT'] = '*nv-vk64*'
        if batch != 'outline-control':
            run(out.name, 'original-four', 'default-four.py')
        if batch != 'original-four':
            run(out.name, 'outline-control', 'outline-reference-control.py')
    else:
        config, device = batch.split('-')
        capture(config.title(), device)
