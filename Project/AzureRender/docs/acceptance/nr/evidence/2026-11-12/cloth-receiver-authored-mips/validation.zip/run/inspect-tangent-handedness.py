from hashlib import file_digest
from pathlib import Path
import json
import struct

import numpy as np


out = Path(__file__).resolve().parent
asset = out / 'hair-project/character/hair-coverage.glb'
fixture = json.loads((out / 'fixture-inputs.json').read_text())
expected = next(item['sha256'] for item in fixture['files'] if item['relative'] == 'character/hair-coverage.glb')
with asset.open('rb') as stream:
    asset_sha = file_digest(stream, 'sha256').hexdigest()
    assert asset_sha == expected
    stream.seek(0)
    size = struct.unpack('<4s4I', stream.read(20))[3]
    doc = json.loads(stream.read(size))
    stream.read(8)
    buffer_start = stream.tell()
    mesh, = [item for item in doc['meshes'] if item['name'] == 'S_actor_laevat_cloth_01_lod0']
    primitive, = mesh['primitives']

    def load(index):
        accessor = doc['accessors'][index]
        view = doc['bufferViews'][accessor['bufferView']]
        count = accessor['count']
        components = {'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'SCALAR': 1}[accessor['type']]
        dtype = {5126: '<f4', 5123: '<u2', 5125: '<u4'}[accessor['componentType']]
        stride = components * np.dtype(dtype).itemsize
        assert view['buffer'] == 0 and view.get('byteStride', stride) == stride and 'sparse' not in accessor
        stream.seek(buffer_start + view.get('byteOffset', 0) + accessor.get('byteOffset', 0))
        return np.frombuffer(stream.read(count * stride), dtype).reshape(count, components)

    position, normal, uv, tangent = [load(primitive['attributes'][key]) for key in ('POSITION', 'NORMAL', 'TEXCOORD_0', 'TANGENT')]
    indices = load(primitive['indices']).reshape(-1, 3)

edge1 = position[indices[:, 1]] - position[indices[:, 0]]
edge2 = position[indices[:, 2]] - position[indices[:, 0]]
uv1 = uv[indices[:, 1]] - uv[indices[:, 0]]
uv2 = uv[indices[:, 2]] - uv[indices[:, 0]]
determinant = uv1[:, 0] * uv2[:, 1] - uv1[:, 1] * uv2[:, 0]
valid = (np.abs(determinant) > 1e-8) & (np.linalg.norm(np.cross(edge1, edge2), axis=1) > 1e-8)
derived_bitangent = ((edge2 * uv1[:, :1] - edge1 * uv2[:, :1]) * np.sign(determinant[:, None]))[valid]
corners = indices[valid]
bitangent = np.cross(normal[corners], tangent[corners, :3])
expected_sign = np.sign(np.einsum('ijk,ik->ij', bitangent, derived_bitangent))
actual_sign = tangent[corners, 3]
values, counts = np.unique(tangent[:, 3], return_counts=True)
result = dict(assetSha256=asset_sha, triangles=len(indices), validTriangles=int(valid.sum()),
    comparedCorners=actual_sign.size, matchingCorners=int((actual_sign == expected_sign).sum()),
    vertexSigns={int(value): int(count) for value, count in zip(values, counts)})
assert result['comparedCorners'] == 100152 and result['matchingCorners'] == 100049
(out / 'authored-tangent-handedness.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
