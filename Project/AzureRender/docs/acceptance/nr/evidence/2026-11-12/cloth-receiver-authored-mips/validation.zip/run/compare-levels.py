from hashlib import sha256
from io import BytesIO
from pathlib import Path
import base64
import json
import struct

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
project = out / 'hair-project'
fixture = json.loads((out / 'fixture-inputs.json').read_text())
with (project / 'character/hair-coverage.glb').open('rb') as stream:
    size = struct.unpack('<4s4I', stream.read(20))[3]
    gltf = json.loads(stream.read(size))
original = gltf['textures'][fixture['oldNormalTexture']]['source']
embedded = base64.b64decode(gltf['images'][original]['uri'].split(',', 1)[1], validate=True)
assert sha256(embedded).hexdigest() == 'c65df30156c698f809c824ef7e28fcfabc1c7a0b03ed616a13a34b5ef2ac3a90'
with Image.open(BytesIO(embedded)) as image:
    generated = np.asarray(image.convert('RGBA'))
dds = (project / 'character/cloth-receiver-normal-authored.dds').read_bytes()
assert sha256(dds).hexdigest() == fixture['authoredDdsSha256']


def next_normal_level(previous):
    height, width = previous.shape[:2]
    data = previous.astype('f4') / np.float32(255)
    data[..., :3] = (data[..., :3] * 2 - 1) * data[..., 3:]
    a, b, c, d = data[::2, ::2], data[::2, 1::2], data[1::2, ::2], data[1::2, 1::2]
    mean = (a + b + c + d) * np.float32(.25)
    assert mean.shape[:2] == (height // 2, width // 2)
    length = np.sqrt(mean[..., 0] ** 2 + mean[..., 1] ** 2 + mean[..., 2] ** 2)
    denominator = np.where(length > 1e-6, length, 1)
    mean[..., :3] = mean[..., :3] / denominator[..., None] * .5 + .5
    mean[length <= 1e-6, :3] = [.5, .5, 1]
    mean[..., 3] = length
    return np.floor(np.clip(mean, 0, 1) * 255 + .5).astype('u1')


levels = []
offset = 148
for info in fixture['levels']:
    width, height = info['extent']
    payload = dds[offset:offset + info['bytes']]
    offset += info['bytes']
    assert sha256(payload).hexdigest() == info['transformedSha256']
    header = bytearray(dds[:148])
    struct.pack_into('<3I', header, 12, height, width, len(payload))
    struct.pack_into('<I', header, 28, 1)
    with Image.open(BytesIO(header + payload)) as image:
        authored = np.asarray(image, dtype='i2')[..., :2]
    assert authored.shape[:2] == generated.shape[:2] == (height, width)
    delta = np.abs(authored - generated[..., :2])
    error = delta.max(axis=2)
    signed = authored.astype('f4') / np.float32(255) * 2 - 1
    outside = (signed[..., 0] ** 2 + signed[..., 1] ** 2) > 1
    levels.append(dict(level=info['level'], extent=info['extent'], texels=height * width,
        exact=int((error == 0).sum()), withinOne=int((error <= 1).sum()), maximum=int(error.max()),
        median=float(np.median(error)), p95=float(np.quantile(error, .95)), authoredRgOutsideUnit=int(outside.sum())))
    if width > 1:
        generated = next_normal_level(generated)
assert offset == len(dds) and levels[0]['exact'] == 4189362
(out / 'cpu-level-comparison.json').write_text(json.dumps(dict(method='CPU model of generated normal mip averages; GPU capture owns acceptance',
    levels=levels), indent=2) + '\n')
print(json.dumps(levels[:5]))
