from hashlib import file_digest, sha256
from io import BytesIO
from pathlib import Path
from shutil import copyfile
import json
import struct

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
outline = out.parent / '20261112-073905-reference-scene-outline-depth-d97cff'
native = out.parent / '20261112-083618-native-cloth-receiver-normal-input-a94a9c/native-source'
source = outline / 'hair-project'
project = out / 'hair-project'
asset = Path('character/hair-coverage.glb')
normal_asset = Path('character/cloth-receiver-normal-authored.dds')


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def flip_bc5_rows(raw, width, height):
    rows = (height + 3) // 4
    columns = (width + 3) // 4
    words = np.frombuffer(raw, '<u8').reshape(rows, columns, 2)[::-1]
    active_rows = min(4, height)
    fields = np.uint64(((1 << (active_rows * 12)) - 1) << 16)
    result = words & ~fields
    for y in range(active_rows):
        source_shift = np.uint64(16 + 12 * y)
        target_shift = np.uint64(16 + 12 * (active_rows - 1 - y))
        result |= ((words >> source_shift) & np.uint64(0xfff)) << target_shift
    return result.astype('<u8', copy=False).tobytes()


def decode_level(header, raw, width, height):
    wrapper = bytearray(header)
    struct.pack_into('<3I', wrapper, 12, height, width, len(raw))
    struct.pack_into('<I', wrapper, 28, 1)
    with Image.open(BytesIO(wrapper + raw)) as image:
        assert image.size == (width, height) and image.pixel_format == 'BC5'
        return np.asarray(image)


report = json.loads((native / 'report.json').read_text())
assert report['status'] == 'qualified'
raw = (native / report['dds']['file']).read_bytes()
assert sha256(raw).hexdigest() == report['dds']['sha256'] == '924a06afe633006325ec42ae990c203a500495a75c61353d1409d2fd7e2c07cf'
header = raw[:report['dds']['headerBytes']]
levels = report['devices']['nvidia']['levels']
assert len(levels) == 12 and levels == report['devices']['intel']['levels']
offset = len(header)
authored, level_manifest = [header], []
for level in levels:
    end = offset + level['bytes']
    data = raw[offset:end]
    offset = end
    assert sha256(data).hexdigest() == level['sha256']
    width, height = level['extent']
    flipped = flip_bc5_rows(data, width, height)
    assert flip_bc5_rows(flipped, width, height) == data
    assert np.array_equal(decode_level(header, flipped, width, height), decode_level(header, data, width, height)[::-1])
    authored.append(flipped)
    level_manifest.append(dict(**level, transformedSha256=sha256(flipped).hexdigest()))
assert offset == len(raw)

baseline = json.loads((outline / 'profile-fixture-inputs.json').read_text())
assert len(baseline) == 43
for entry in baseline:
    relative = Path(entry['relative'])
    original = (source / relative).resolve(strict=True)
    assert original.is_relative_to(source) and digest(original) == entry['sha256']
    destination = project / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    if relative != asset:
        copyfile(original, destination)
        assert digest(destination) == entry['sha256']

with (source / asset).open('rb') as stream:
    magic, version, total, length, json_type = struct.unpack('<4s4I', stream.read(20))
    assert (magic, version, total, json_type) == (b'glTF', 2, (source / asset).stat().st_size, 0x4e4f534a)
    old_json = stream.read(length)
    doc = json.loads(old_json)
    bin_header = stream.read(8)
    binary = stream.read()
    assert struct.unpack('<2I', bin_header) == (len(binary), 0x004e4942)

cloth, = [entry for entry in doc['materials'] if entry['name'] == 'M_actor_laevat_cloth_01']
previous = cloth['normalTexture']['index']
old_texture = doc['textures'][previous]
assert old_texture.get('sampler') is None and 'extensions' not in old_texture
assert doc['images'][old_texture['source']]['name'] == 'T_actor_laevat_cloth_01_N-normal'
image = dict(name='Cloth receiver authored BC5 levels', uri=normal_asset.name)
texture = dict(**old_texture)
texture['source'] = len(doc['images'])
replacement = len(doc['textures'])
doc['images'].append(image)
doc['textures'].append(texture)
cloth['normalTexture']['index'] = replacement
encoded = json.dumps(doc, separators=(',', ':'), ensure_ascii=False).encode()
encoded += b' ' * ((-len(encoded)) % 4)
file_size = 20 + len(encoded) + len(bin_header) + len(binary)
with (project / asset).open('xb') as destination:
    destination.write(struct.pack('<4s4I', b'glTF', 2, file_size, len(encoded), json_type))
    destination.write(encoded)
    destination.write(bin_header)
    destination.write(binary)
new_doc = json.loads(encoded)
assert new_doc['images'].pop() == image and new_doc['textures'].pop() == texture
new_cloth, = [entry for entry in new_doc['materials'] if entry['name'] == cloth['name']]
assert new_cloth['normalTexture']['index'] == replacement
new_cloth['normalTexture']['index'] = previous
assert new_doc == json.loads(old_json)
with (project / normal_asset).open('xb') as destination:
    destination.writelines(authored)

files = [dict(relative=path.relative_to(project).as_posix(), bytes=path.stat().st_size, sha256=digest(path))
    for path in sorted(project.rglob('*')) if path.is_file()]
old_hashes = {entry['relative']: entry['sha256'] for entry in baseline}
new_hashes = {entry['relative']: entry['sha256'] for entry in files}
assert set(new_hashes) - set(old_hashes) == {normal_asset.as_posix()}
assert [name for name in old_hashes if new_hashes[name] != old_hashes[name]] == [asset.as_posix()]
fixture = dict(files=files, binarySha256=sha256(binary).hexdigest(), oldNormalTexture=previous, newNormalTexture=replacement,
    originalDdsSha256=report['dds']['sha256'], authoredDdsSha256=new_hashes[normal_asset.as_posix()], levels=level_manifest,
    samplerPreserved=True, onlyNormalTextureChanged=True)
(out / 'fixture-inputs.json').write_text(json.dumps(fixture, indent=2) + '\n')
print(json.dumps(dict(files=len(files), bytes=sum(item['bytes'] for item in files), ddsSha256=fixture['authoredDdsSha256'])))
