from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import sys
import traceback

import renderdoc as rd


job = json.loads(Path(os.environ['AZURE_NORMAL_BIAS_REQUEST']).read_text())
out = Path(job['output'])
sys.path.insert(0, job['dxbcTools'])
from dxbc_util import checksum, chunks, fbits, imm, instructions, opcode, rebuild, words


def with_bias(raw, bias):
    assert checksum(raw) == raw[4:20]
    parts = chunks(raw)
    index, = [i for i, (kind, _) in enumerate(parts) if kind in (b'SHEX', b'SHDR')]
    kind, program = parts[index]
    body = words(program)
    samples = [(at, length) for _, at, op, length in instructions(body) if op == opcode('SAMPLE_B')]
    assert len(samples) == 3
    at, length = samples[2]
    original = body[at:at + length]
    assert original[-2:] == [0, 26] and (original[-3] >> 12) & 255 == 8
    replacement = original[:-3] + imm(fbits(bias))
    replacement[0] = (replacement[0] & 0x80ffffff) | (len(replacement) << 24)
    body[at:at + length] = replacement
    body[1] = len(body)
    parts[index] = kind, struct.pack('<' + 'I' * len(body), *body)
    return rebuild(raw, parts)


report = dict(status='failed', bias=job['bias'], devices={})
capture = rd.OpenCaptureFile()
controller = None
original = None
replacement = None
try:
    assert capture.OpenFile(job['capture'], '', None) == rd.ResultCode.Succeeded
    points = list(struct.iter_unpack('<4f', Path(job['queries']).read_bytes()))
    assert len(points) == 17017
    offsets = [(int(y) * 2560 + int(x)) * 4 for x, y, _, _ in points]
    for name, vendor in (('nvidia', rd.GPUVendor.nVidia), ('intel', rd.GPUVendor.Intel)):
        gpu, = [item for item in capture.GetAvailableGPUs() if item.vendor == vendor and rd.GraphicsAPI.D3D11 in item.apis]
        options = rd.ReplayOptions()
        options.forceGPUVendor = vendor
        options.forceGPUDeviceID = gpu.deviceID
        status, controller = capture.OpenCapture(options, None)
        assert status == rd.ResultCode.Succeeded and controller
        properties = controller.GetAPIProperties()
        assert properties.vendor == vendor and properties.pipelineType == rd.GraphicsAPI.D3D11 and not properties.degraded
        controller.SetFrameEvent(422, True)
        pipe = controller.GetPipelineState()
        reflection = pipe.GetShaderReflection(rd.ShaderStage.Pixel)
        original = pipe.GetShader(rd.ShaderStage.Pixel)
        raw = bytes(reflection.rawBytes)
        target = pipe.GetOutputTargets()[3].resource
        assert str(target) == 'ResourceId::141952'
        text = controller.DisassembleShader(pipe.GetGraphicsPipelineObject(), reflection, '')
        (out / (name + '-422-pixel.asm')).write_text(text, encoding='utf-8')

        def readback():
            controller.SetFrameEvent(422, True)
            data = bytes(controller.GetTextureData(target, rd.Subresource()))
            assert len(data) == 2560 * 1440 * 4
            return data

        baseline = readback()
        native = job['baseline'][name]
        assert sha256(baseline).hexdigest() == native['baselineSha256']
        assert sha256(raw).hexdigest() == native['shaderSha256']
        hashes = []
        with (out / (name + '-biased-normals.bin')).open('wb') as selected:
            for bias in job['bias']:
                bytecode = with_bias(raw, bias)
                replacement, errors = controller.BuildTargetShader('main', rd.ShaderEncoding.DXBC, bytecode,
                    rd.ShaderCompileFlags(), rd.ShaderStage.Pixel)
                assert replacement != rd.ResourceId.Null(), errors
                controller.ReplaceResource(original, replacement)
                actual = readback()
                if bias == -1.0:
                    assert actual == baseline, 'Immediate -1.0 must match the bound constant'
                selected.write(b''.join(actual[offset:offset + 4] for offset in offsets))
                hashes.append(dict(bias=bias, shader=sha256(bytecode).hexdigest(), attachment=sha256(actual).hexdigest()))
                controller.RemoveReplacement(original)
                controller.FreeTargetResource(replacement)
                replacement = None
        assert readback() == baseline
        messages = [str(message.description) for message in controller.GetDebugMessages()]
        report['devices'][name] = dict(device=gpu.name, copyControlExact=True, restorationExact=True, hashes=hashes, messages=messages)
        controller.Shutdown()
        controller = None
        original = None
    report['status'] = 'qualified'
except BaseException:
    report['error'] = traceback.format_exc()
finally:
    if controller:
        if original:
            controller.RemoveReplacement(original)
        if replacement:
            controller.FreeTargetResource(replacement)
        controller.Shutdown()
    capture.Shutdown()
    (out / 'bias-replay.json').write_text(json.dumps(report, indent=2) + '\n')
os._exit(0 if report['status'] == 'qualified' else 1)
