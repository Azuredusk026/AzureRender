from hashlib import sha256
from pathlib import Path
import json
import zipfile


out = Path(__file__).resolve().parent
target = out.parents[2] / 'docs/acceptance/nr/evidence/2026-11-12/native-hair-normal-mip-bias'
raw = out / 'native-normal-bias'


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


replay = load(raw / 'bias-replay.json')
execution = load(out / 'replay-execution.json')
comparison = load(out / 'native-normal-bias-comparison.json')
assert replay['status'] == 'qualified' and execution['status'] == 'exited' and execution['exitCode'] == 0
assert replay['bias'] == [i / 32 for i in range(-56, -7)]
for name, device in replay['devices'].items():
    assert device['copyControlExact'] and device['restorationExact'] and len(device['hashes']) == 49
    samples = raw / (name + '-biased-normals.bin')
    assert samples.stat().st_size == 49 * 17017 * 4
    assert sha256(samples.read_bytes()).hexdigest() == comparison['devices'][name]['selectedSha256']
    assert comparison['devices'][name]['monotonicViolations'] == 0
intel_best = min(comparison['biasAgainstFrozen'], key=lambda row: row['intelOverOne'])
baseline, = [row for row in comparison['biasAgainstFrozen'] if row['bias'] == -1]
assert baseline == {'bias': -1.0, 'nvidiaOverOne': 0, 'intelOverOne': 886}
assert intel_best == {'bias': -.9375, 'nvidiaOverOne': 548, 'intelOverOne': 477}
inputs = [out / name for name in ('task-card.json', 'native-normal-bias.py', 'native-normal-bias-worker.py',
    'verify-patch.py', 'queued-replay.py', 'replay-execution.json', 'package-evidence.py', 'native-normal-bias-comparison.json')]
inputs.extend(sorted(raw.iterdir()))
archive = out / 'validation-pending.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as writer:
    for path in inputs:
        writer.write(path, 'run/' + path.relative_to(out).as_posix())
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    contents = {name: sha256(reader.read(name)).hexdigest() for name in reader.namelist()}
    assert len(contents) == len(inputs)
assert archive.stat().st_size <= 8 * 1024 * 1024
payload = dict(status='qualified-native-hair-normal-mip-bias', overall='failed-user-review',
    baseline=baseline, intelBest=intel_best, comparison=comparison, nativeReplay=replay, execution=execution,
    archive=dict(bytes=archive.stat().st_size, sha256=sha256(archive.read_bytes()).hexdigest(), contents=contents))
target.mkdir(parents=True, exist_ok=True)
assert not (target / 'validation.zip').exists() and not (target / 'results.json').exists()
archive.rename(target / 'validation.zip')
(target / 'results.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in payload['archive'].items() if key != 'contents'}))