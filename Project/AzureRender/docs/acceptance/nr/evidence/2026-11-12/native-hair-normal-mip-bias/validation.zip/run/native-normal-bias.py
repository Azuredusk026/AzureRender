from hashlib import file_digest, sha256
from pathlib import Path
import json
import os
import subprocess

import numpy as np


out = Path(__file__).resolve().parent
prior = out.parent / '20261112-053111-intel-reference-visibility-sources-5238e2/native-normal-explicit-mips'
native = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc')
capture_sha = 'fa2ca267f7168f5603e83ad5f817a3074d8dbee23a216e6ab8ef2c340ec06a90'
queries = out.parent / '20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame/queries.bin'
assert sha256(queries.read_bytes()).hexdigest() == '2ffff6e92f0fac8fe5b79d4fd6eb6e7c4c4fe1b9ae5eb38b2eb0cc8cbee3a7e8'
with native.open('rb') as stream:
    assert file_digest(stream, 'sha256').hexdigest() == capture_sha
baseline = json.loads((prior / 'explicit-normal-mips.json').read_text())['devices']
folder = out / 'native-normal-bias'
folder.mkdir()
bias = np.arange(-56, -7) / 32
assert -1.0 in bias
job = dict(capture=str(native), queries=str(queries), output=str(folder), dxbcTools=str(prior), bias=bias.tolist(), baseline=baseline)
request = folder / 'request.json'
request.write_text(json.dumps(job, indent=2) + '\n')
env = os.environ.copy()
for key in ('VK_LAYER_PATH', 'VK_INSTANCE_LAYERS', 'ENABLE_VULKAN_RENDERDOC_CAPTURE',
        'VK_LOADER_DRIVERS_SELECT', 'VK_DRIVER_FILES', 'VK_ICD_FILENAMES'):
    env.pop(key, None)
env['AZURE_NORMAL_BIAS_REQUEST'] = str(request)
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
command = ['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe', '--python', str(out / 'native-normal-bias-worker.py')]
(folder / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (folder / 'process.log').open('wb') as log:
    result = subprocess.run(command, env=env, startupinfo=startup, cwd=folder,
        stdout=log, stderr=subprocess.STDOUT, timeout=350)
replay = json.loads((folder / 'bias-replay.json').read_text())
assert result.returncode == 0 and replay['status'] == 'qualified', replay
with native.open('rb') as stream:
    assert file_digest(stream, 'sha256').hexdigest() == capture_sha


def range_stats(values):
    return dict(count=len(values), quantile=np.quantile(values, [0, .05, .25, .5, .75, .95, 1]).tolist()) if len(values) else dict(count=0)


def difference(first, second):
    return np.maximum(*[np.abs(((first >> shift) & 1023).astype('i4') - ((second >> shift) & 1023).astype('i4'))
        for shift in (0, 10)])


levels = {}
matches = {}
native_packed = {}
crossings = {}
summary = dict(devices={})
base_index, = np.flatnonzero(bias == -1.0)
for name in ('nvidia', 'intel'):
    packed = np.fromfile(folder / (name + '-biased-normals.bin'), '<u4').reshape(len(bias), 17017)
    native_packed[name] = np.fromfile(prior / (name + '-implicit.bin'), '<u4')
    assert np.array_equal(packed[base_index], native_packed[name])
    mip = np.stack([np.fromfile(prior / f'{name}-mip-{level:02d}.bin', '<u4') for level in range(12)])
    is_match = packed[:, None, :] == mip[None, :, :]
    assert is_match.any(axis=1).all()
    unique = is_match.sum(axis=1) == 1
    found = np.where(unique, is_match.argmax(axis=1), -1)
    levels[name] = found
    matches[name] = is_match[base_index]
    monotonic_violations = np.sum((np.maximum.accumulate(found, axis=0) > found) & unique)
    transitions = (found[1:] == found[:-1] + 1) & unique[1:] & unique[:-1]
    assert monotonic_violations == 0
    locations = np.argwhere(transitions)
    inferred_lod = found[1:][transitions] - .5 - (bias[1:][locations[:, 0]] + bias[:-1][locations[:, 0]]) * .5
    per_pixel_lod = np.full(17017, np.nan)
    per_pixel_lod[locations[:, 1]] = inferred_lod
    crossings[name] = per_pixel_lod
    summary['devices'][name] = dict(samples=len(bias) * 17017, unique=int(unique.sum()), transitions=len(locations),
        pointsWithTransitions=int(np.isfinite(per_pixel_lod).sum()), monotonicViolations=int(monotonic_violations),
        selectedSha256=sha256(packed.tobytes()).hexdigest(), inferredLod=range_stats(inferred_lod))
    per_pixel_lod.astype('<f4').tofile(folder / (name + '-inferred-lod.bin'))


bad = difference(native_packed['nvidia'], native_packed['intel']) > 1
both = np.isfinite(crossings['nvidia']) & np.isfinite(crossings['intel'])
delta = crossings['nvidia'] - crossings['intel']
summary['frozenNormalDifference'] = int(bad.sum())
summary['nvidiaMinusIntel'] = range_stats(delta[both])
summary['nvidiaMinusIntelAtDifferences'] = range_stats(delta[both & bad])
summary['biasAgainstFrozen'] = [dict(bias=float(value),
    nvidiaOverOne=int((difference(native_packed['nvidia'], nvidia) > 1).sum()),
    intelOverOne=int((difference(native_packed['nvidia'], intel) > 1).sum()))
    for value, nvidia, intel in zip(bias,
        np.fromfile(folder / 'nvidia-biased-normals.bin', '<u4').reshape(len(bias), 17017),
        np.fromfile(folder / 'intel-biased-normals.bin', '<u4').reshape(len(bias), 17017))]
(out / 'native-normal-bias-comparison.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
