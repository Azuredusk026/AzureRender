from pathlib import Path
import struct
import sys
run = Path(__file__).resolve().parent
tool = run.parent / '20261112-053111-intel-reference-visibility-sources-5238e2/native-normal-explicit-mips'
shader = run.parent / '20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry/422-4.dxbc'
sys.path.insert(0, str(tool))
from dxbc_util import checksum, chunks, fbits, imm, instructions, opcode, rebuild, words
worker = (run / 'native-normal-bias-worker.py').read_text()
function = worker.split('def with_bias(', 1)[1].split('\n\nreport =', 1)[0]
exec('def with_bias(' + function)
raw = shader.read_bytes()
variants = [with_bias(raw, bias / 32) for bias in range(-56, -7)]
assert len(set(variants)) == 49
assert all(checksum(variant) == variant[4:20] for variant in variants)
print(f'{len(variants)} distinct DXBC replacements, checked per-container checksums')