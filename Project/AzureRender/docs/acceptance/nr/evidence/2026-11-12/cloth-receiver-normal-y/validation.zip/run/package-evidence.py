from hashlib import sha256
from pathlib import Path
import json
import sys
import zipfile


out = Path(__file__).resolve().parent
engine = out.parents[2]
target = engine / 'docs/acceptance/nr/evidence/2026-11-12/cloth-receiver-normal-y'
outline_evidence = engine / 'docs/acceptance/nr/evidence/2026-11-12/reference-scene-outline-depth/results.json'


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


preflight = sys.argv[1:] == ['--release-only']
configs = ('release',) if preflight else ('release', 'debug')
labels = [f'{config}-{device}' for config in configs for device in ('nvidia', 'intel')]
outline = load(outline_evidence)
fixture = load(out / 'fixture-inputs.json')
assert len(fixture['files']) == 45 and len(fixture['levels']) == 12 and fixture['allOtherInputsExact']
assert fixture['samplerMetadataSha256'] == '3729331732c863451c67cd47c568c7dfdbd8ebf99065214e7340744cffc8134a'
assert fixture['convertedDdsSha256'] == '34bbb19e3e85d2477a2c657e6956514b62866424982584b5c92df8d90bbbcf26'
assert fixture['compressedRoundTrip'] and fixture['redBlocksExact']
assert max(level['greenMaximumByteError'] for level in fixture['levels']) == 1
residuals = load(out / 'receiver-residual-attribution.json')
assert residuals['nvidia']['377']['failed'] == 296 and residuals['intel']['377']['failed'] == 346
rows = {label: load(out / (label + '-results.json')) for label in labels}
execution = {label: load(out / (label + '-execution.json')) for label in labels}
for label, row in rows.items():
    config, device = label.split('-')
    assert execution[label]['status'] == 'exited' and execution[label]['exitCode'] == 0
    assert row['playerSha256'] == outline['builds'][config]['playerSha256']
    assert all(row[field] for field in ('depthExact', 'idsExact', 'hairVisibilityExact', 'hairColorExact',
        'validationClean', 'allocatorZero'))
    expected = (296, 658, 0, 0) if device == 'nvidia' else (346, 973, 208, 575)
    assert (row['receiverByOwner']['377']['overOne'], row['receiver']['overOne'], row['hairVisibilityOverOne'],
        row['hairColorOverOne']) == expected
    assert all(value['changed'] == 0 for key, value in row['receiverByOwner'].items() if key != '377')
    assert row['clothNormal']['current']['median'] == 1
    manifest = load(out / (label + '-frames/reference-planes.json'))
    assert manifest['reference-object-visibility-rg8.bin']['sha256'] == row['visibilitySha256']
    assert manifest['reference-normals-a2b10g10r10.bin']['sha256'] == row['normalsSha256']
    assert manifest['reference-depth-r32.bin']['sha256'] == outline['captures'][label]['referenceDepthSha256']
    assert manifest['reference-depth-d32.bin']['sha256'] == outline['captures'][label]['referenceDepthSha256']
    assert manifest['reference-object-ids-r8.bin']['sha256'] == outline['captures'][label]['objectIdsSha256']
if preflight:
    print(json.dumps({label: row['receiverByOwner']['377'] for label, row in rows.items()}))
    sys.exit(0)
for device in ('nvidia', 'intel'):
    release, debug = [rows[config + '-' + device] for config in configs]
    assert all(release[key] == debug[key] for key in release if key not in ('configuration', 'playerSha256'))
assert outline['originalFour']['allExact'] and outline['originalFour']['playerSha256'] == rows['release-nvidia']['playerSha256']

archive = out / 'validation-pending.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as writer:
    def add(path):
        writer.write(path, 'run/' + path.relative_to(out).as_posix())

    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.json', '.log'):
            add(path)
    add(out / 'hair-project/character/cloth-receiver-normal-authored.dds.azmeta')
    for label in labels:
        for name in ('capture_manifest.json', 'gpu_capabilities.json', 'reference-planes.json'):
            add(out / (label + '-frames') / name)
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    files = {name: sha256(reader.read(name)).hexdigest() for name in reader.namelist()}
assert archive.stat().st_size <= 8 * 1024 * 1024
result = dict(status='qualified-cloth-receiver-normal-y-input', overall='failed-user-review',
    baseCommit='bbaa99f2f651386a815004c49876d1b87faca2d1', scope='reference fixture only', acceptedMaximumByteError=1,
    fixture=fixture, residualAttribution=residuals, captures=rows, execution=execution,
    crossConfigurationExact=True, originalFour=outline['originalFour'],
    archive=dict(bytes=archive.stat().st_size, sha256=sha256(archive.read_bytes()).hexdigest(), contents=files))
target.mkdir(parents=True, exist_ok=True)
assert not (target / 'validation.zip').exists() and not (target / 'results.json').exists()
archive.rename(target / 'validation.zip')
(target / 'results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in result['archive'].items() if key != 'contents'}))
