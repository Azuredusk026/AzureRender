from hashlib import file_digest, sha256
from io import BytesIO
from pathlib import Path
from shutil import copyfile
import json
import struct
import sys

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
engine = out.parents[2]
prior = out.parent / '20261112-090101-cloth-receiver-native-sampler-e301d1'
source = prior / 'hair-project'
project = out / 'hair-project'
relative_texture = Path('character/cloth-receiver-normal-authored.dds')
sys.path.insert(0, str(engine / 'tools'))
from normal_map_orientation import convert_normal_y


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def negate_green(payload):
    blocks = np.frombuffer(payload, '<u8').reshape(-1, 2).copy()
    channel = blocks[:, 1].copy()
    first = channel & 255
    second = (channel >> 8) & 255
    words = (255 - second) | ((255 - first) << 8)
    codes_eight = np.asarray([1, 0, 7, 6, 5, 4, 3, 2], dtype='u8')
    codes_six = np.asarray([1, 0, 5, 4, 3, 2, 7, 6], dtype='u8')
    for pixel in range(16):
        shift = np.uint64(16 + 3 * pixel)
        code = (channel >> shift) & 7
        replacement = np.where(first > second, codes_eight[code], codes_six[code])
        words |= replacement << shift
    blocks[:, 1] = words
    return blocks.tobytes()


def decode_level(header, payload, width, height):
    wrapper = bytearray(header)
    struct.pack_into('<3I', wrapper, 12, height, width, len(payload))
    struct.pack_into('<I', wrapper, 28, 1)
    with Image.open(BytesIO(wrapper + payload)) as image:
        assert image.size == (width, height) and image.pixel_format == 'BC5'
        return image.copy()


fixture = json.loads((prior / 'fixture-inputs.json').read_text())
assert len(fixture['files']) == 45 and fixture['sameTextureAndGeometry']
assert fixture['candidateMetadataSha256'] == '3729331732c863451c67cd47c568c7dfdbd8ebf99065214e7340744cffc8134a'
original = (source / relative_texture).read_bytes()
assert sha256(original).hexdigest() == fixture['authoredDdsSha256'] == '1fb335fe9de63f7338e93e2d44e8b1c23bcf0a7ee08581ca0ed723efb8455ba9'
header = original[:148]
assert header[:4] == b'DDS ' and header[84:88] == b'DX10'
height, width, _, _, count = struct.unpack_from('<5I', header, 12)
assert (width, height, count, struct.unpack_from('<I', header, 128)[0]) == (2048, 2048, 12, 83)
offset = len(header)
parts = [header]
levels = []
for level in range(count):
    w, h = max(1, width >> level), max(1, height >> level)
    length = ((w + 3) // 4) * ((h + 3) // 4) * 16
    payload = original[offset:offset + length]
    offset += length
    converted = negate_green(payload)
    assert len(converted) == length and negate_green(converted) == payload
    assert np.array_equal(np.frombuffer(converted, '<u8')[::2], np.frombuffer(payload, '<u8')[::2])
    old_image = decode_level(header, payload, w, h)
    new_image = np.asarray(decode_level(header, converted, w, h), dtype='i2')
    expected = np.asarray(convert_normal_y(old_image, 'positive', 'negative'), dtype='i2')
    delta = np.abs(new_image - expected)
    assert not delta[..., (0, 2)].any() and int(delta[..., 1].max()) <= 1
    parts.append(converted)
    levels.append(dict(level=level, extent=[w, h], bytes=length, sourceSha256=sha256(payload).hexdigest(),
        convertedSha256=sha256(converted).hexdigest(), greenExact=int((delta[..., 1] == 0).sum()),
        greenMaximumByteError=int(delta[..., 1].max())))
assert offset == len(original) and len(levels) == 12

for item in fixture['files']:
    relative = Path(item['relative'])
    initial = (source / relative).resolve(strict=True)
    assert initial.is_relative_to(source) and digest(initial) == item['sha256']
    destination = project / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    if relative == relative_texture:
        with destination.open('xb') as stream:
            stream.writelines(parts)
    else:
        copyfile(initial, destination)
        assert digest(destination) == item['sha256']
files = [dict(relative=path.relative_to(project).as_posix(), bytes=path.stat().st_size, sha256=digest(path))
    for path in sorted(project.rglob('*')) if path.is_file()]
old_hashes = {entry['relative']: entry['sha256'] for entry in fixture['files']}
new_hashes = {entry['relative']: entry['sha256'] for entry in files}
assert old_hashes.keys() == new_hashes.keys()
assert [name for name in old_hashes if new_hashes[name] != old_hashes[name]] == [relative_texture.as_posix()]
result = dict(files=files, originalDdsSha256=fixture['authoredDdsSha256'], convertedDdsSha256=new_hashes[relative_texture.as_posix()],
    samplerMetadataSha256=fixture['candidateMetadataSha256'], levels=levels, compressedRoundTrip=True, redBlocksExact=True,
    decodedReference='tools/normal_map_orientation.py', allOtherInputsExact=True)
(out / 'fixture-inputs.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(files=len(files), bytes=sum(item['bytes'] for item in files), ddsSha256=result['convertedDdsSha256'],
    exactGreenTexels=sum(entry['greenExact'] for entry in levels), maximumGreenByteError=max(entry['greenMaximumByteError'] for entry in levels))))
