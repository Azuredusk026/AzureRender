from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys


out = Path(__file__).resolve().parent
build = out.parents[1]
main = Path('D:/Projects/FYP/Project/AzureRender/build')
owner = '01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
source = 'bbaa99f2f651386a815004c49876d1b87faca2d1'
sys.path.insert(0, str(main.parent / 'tools'))
import shared_resources as shared


claim_path = Path('D:/Projects/FYP-coordination/quality-claim.json')
claim = json.loads(claim_path.read_text(encoding='utf-8'))
assert claim['threadId'] == owner and claim['state'] == 'cloth-receiver-native-sampler'
commit = subprocess.check_output(['git', 'log', '-1', '--format=%H%n%P'], cwd=build.parent, text=True).splitlines()
assert commit == [source, claim['lastCommit']]
evidence = build.parent / 'docs/acceptance/nr/evidence/2026-11-12/cloth-receiver-native-sampler'
manifest = json.loads((evidence / 'results.json').read_text())
assert manifest['status'] == 'qualified-cloth-receiver-native-sampler-input'
assert sha256((evidence / 'validation.zip').read_bytes()).hexdigest() == manifest['archive']['sha256']
old_stage = Path(claim['taskPath'])
assert old_stage.name == '20261112-090101-cloth-receiver-native-sampler-e301d1'
old_local, old_main = claim['localInputLease'], claim['inputLease']


def inherited(root, tokens):
    with shared.maintenance.database(root, True) as db:
        records = shared.maintenance.rows(db)
    assert all(records[token]['owner'] == owner for token in tokens)
    return list(dict.fromkeys(name for token in tokens for name in records[token]['inputs']))


local_inputs = inherited(build, old_local) + [old_stage.name]
main_inputs = inherited(main, old_main)
local = shared.acquire_inputs(build, out, local_inputs, owner)
try:
    native = shared.acquire_inputs(main, out, main_inputs, owner)
except Exception:
    shared.release_inputs(build, local, owner)
    raise
claim.update(state='cloth-receiver-normal-y', taskPath=str(out), inputLease=[native], localInputLease=[local],
    nativeCaptureLease=native, lastCommit=source, pendingCommand='Match the tangent-space green channel to the fixture UV direction',
    ownedFiles=['docs/acceptance/nr/cloth-receiver-normal-y.md',
        'docs/acceptance/nr/evidence/2026-11-12/cloth-receiver-normal-y'], additionalTaskPaths=[])
claim['observed'].update(clothNativeSamplerNvidia=1310,clothNativeSamplerIntel=1317,clothNativeSamplerReceiverNvidia=1672,
    clothNativeSamplerReceiverIntel=1944,clothNativeSamplerMetadata=manifest['fixture']['candidateMetadataSha256'])
(out / 'task-card.json').write_text(json.dumps(dict(local=local, main=native, sourceBase=source, plannedBytes=536870912,
    localInputs=local_inputs, mainInputs=main_inputs, change='One cloth normal green channel, with fixed sampler and geometry',
    gate='16629 event 377 receiver pixels, 49384 total, maximum per-channel byte error 1'), indent=2) + '\n')
temporary = claim_path.with_name(claim_path.name + '.nr-quality-new')
with temporary.open('x', encoding='utf-8') as stream:
    json.dump(claim, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
os.replace(temporary, claim_path)
for token in old_main:
    shared.release_inputs(main, token, owner)
for token in old_local:
    shared.release_inputs(build, token, owner)
print(json.dumps(dict(local=local, main=native, output=str(out))))
