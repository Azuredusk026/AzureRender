from hashlib import sha256
from pathlib import Path
import json

import numpy as np


run=Path(__file__).resolve().parent
probe=run.parent/'20261112-143340-native-texture-sampling-footprint-750e56'
control=probe/'frozen-shape-control.py'
program=control.read_text().split('cases = []',1)[0]
scope={'__file__':str(control)}
exec(compile(program,str(control),'exec'),scope)
xy,screen,quad=(scope[key] for key in ('xy','screen','quad'))
mips,implicit,bias,size=(scope[key] for key in ('mips','implicit','bias','size'))
raster=np.rint(screen*256)/256
corners=[scope['interpolate'](quad+step,raster) for step in ((0,0),(1,0),(0,1),(1,1))]
dx=(corners[1]-corners[0])*size
dy=(corners[2]-corners[0])*size
axis=scope['projected_max']
rho=np.maximum.reduce((axis(dx),axis(dy),(11/16)*axis(dx+dy),(11/16)*axis(dx-dy)))
lod=np.log2(np.maximum(rho,1.e-20))+bias
model_level=np.clip(np.floor(lod+.5),0,11).astype('i4')
fraction=lod-np.rint(lod-.5)-.5
difference=scope['codes']


def levels(words,reference):
    error=difference(words[None,:],reference)
    return error,error<=1


report=dict(source='actual reference normals and independent native explicit mip readbacks',
    modeledClip='nearest-8',derivativeRow=0,derivativeColumn=0,devices={})
for adapter in ('nvidia','intel'):
    path=run/f'release-{adapter}-hair-selected.bin'
    raw=np.fromfile(path,'<u4').reshape(17017,8)
    assert np.array_equal(raw[:,:2],xy) and np.array_equal(raw[:,2],implicit['nvidia'])
    target,baseline,current,expected,old_visibility,new_visibility=raw[:,2:].T
    prior_bad=difference(baseline,target)>1
    current_bad=difference(current,target)>1
    visibility_bad=np.abs(new_visibility.astype('i4')-expected)>1
    error,closest=levels(current,mips[adapter])
    _,old_closest=levels(baseline,mips[adapter])
    _,native_closest=levels(target,mips['nvidia'])
    selected=[]
    for i in np.flatnonzero(current_bad):
        chosen=np.flatnonzero(closest[:,i]).tolist()
        expected_mips=np.flatnonzero(native_closest[:,i]).tolist()
        row=dict(pixel=[int(value) for value in xy[i]],baselineBad=bool(prior_bad[i]),
            visibilityOverOne=bool(visibility_bad[i]),modelMip=int(model_level[i]),estimatedLod=float(lod[i]),
            deltaFromHalfLevel=float(fraction[i]),texelDx=dx[i].tolist(),texelDy=dy[i].tolist(),
            originalDeviceMips=np.flatnonzero(old_closest[:,i]).tolist(),candidateDeviceMips=chosen,
            frozenNvidiaMips=expected_mips,candidateCodeError=int(difference(current[i],target[i])),
            closestMipCodeError=int(error[:,i].min()),modeledMipWithinFrozenCodes=int(model_level[i]) in expected_mips)
        selected.append(row)
    report['devices'][adapter]=dict(samples=len(xy),baselineNormalOverOne=int(prior_bad.sum()),
        candidateNormalOverOne=int(current_bad.sum()),candidateHasDeviceMip=int(closest.any(axis=0).sum()),
        candidateMatchesModelMip=int(closest[model_level,np.arange(len(xy))].sum()),samplesOverOne=selected,
        noMatchingDeviceMip=[dict(pixel=[int(value) for value in xy[i]],minimumCodeError=int(error[:,i].min()),
            frozenCodeError=int(difference(current[i],target[i]))) for i in np.flatnonzero(~closest.any(axis=0))],
        inputSha256=sha256(path.read_bytes()).hexdigest())
(run/'mip-boundary-attribution.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))

