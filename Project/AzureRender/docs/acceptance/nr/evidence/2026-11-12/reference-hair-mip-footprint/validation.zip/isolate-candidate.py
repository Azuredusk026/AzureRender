from hashlib import file_digest, sha256
from pathlib import Path
from shutil import copyfile
import json
import subprocess


run=Path(__file__).resolve().parent
engine=run.parents[2]
build=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
geometry=run.parent/'20261112-114419-reference-geometric-normal-3e57b5'
paths=('schemas/azure_render_material.schema.json','shaders/reference_scene_depth.frag','shaders/texture_footprint.glsl',
    'src/assets/GltfLoader.cpp','src/assets/GltfLoader.hpp','src/assets/MaterialData.cpp',
    'src/assets/MaterialSurfaceProfile.hpp','src/scenes/CharacterSceneRenderer.cpp')


def git(*args):
    return subprocess.check_output(['git',*args],cwd=engine)


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


gate=json.loads((run/'release-candidate-gate.json').read_text())
assert gate['status']=='failed-reference-hair-mip-footprint'
assert set(git('diff','--name-only').decode().splitlines())=={'Project/AzureRender/'+path for path in paths}
assert not git('diff','--cached','--name-only')
patch=git('diff','--binary','--',*paths)
assert patch
(run/'candidate.patch').write_bytes(patch)
versions=json.loads((run/'release-verification.json').read_text())
baseline=json.loads((run/'release-baseline-shaders.json').read_text())
assert len(baseline)==895 and len(versions['changedShaders'])==2
host=(build/'AzurePlayer.exe').resolve(strict=True)
assert host.parent==build.resolve(strict=True) and digest(host)==versions['playerSha256']
copyfile(host,run/'candidate-AzurePlayer.exe')
assert digest(run/'candidate-AzurePlayer.exe')==versions['playerSha256']
old_host=run/'baseline-AzurePlayer.exe'
old_host_sha=json.loads((run/'baseline-receipt.json').read_text())['release-nvidia']['playerSha256']
assert digest(old_host)==old_host_sha
for name,ids in versions['changedShaders'].items():
    generated=(build/'shaders'/name).resolve(strict=True)
    original=geometry/name
    assert generated.parent==(build/'shaders').resolve(strict=True) and digest(generated)==ids['after']
    assert baseline[name]==ids['before']==digest(original)
    copyfile(original,generated)
    assert digest(generated)==ids['before']
copyfile(old_host,host)
assert digest(host)==old_host_sha
assert {path.name:digest(path) for path in (build/'shaders').glob('*.spv')}==baseline
git('restore','--worktree','--',*paths)
assert not git('status','--short')
result=dict(sourceBase=git('rev-parse','HEAD').decode().strip(),candidatePatchSha256=sha256(patch).hexdigest(),
    candidatePlayerSha256=versions['playerSha256'],restoredPlayerSha256=old_host_sha,
    restoredShaderCount=len(baseline),restoredFiles=list(paths),overallStatus='failed-user-review')
(run/'isolated-candidate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

