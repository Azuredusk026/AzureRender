#include "assets/GltfLoader.hpp"
#include <iostream>
#include <stdexcept>

int main() {
    using Settings = azurerender::TextureImportSettings;
    AssetMaterial hair;
    validateHairPointMipReferenceNormal(hair);
    hair.hairPointMipReferenceNormal = true;
    hair.materialProfileVersion = 2;
    hair.materialClass = AssetMaterialClass::Hair;
    hair.projectedHairRamp.present = true;
    hair.projectedHairRamp.materialSnapshotNormal = true;
    hair.alphaMode = AssetAlphaMode::Mask;
    auto& normal = hair.textureSettings[1];
    normal.filter = "linear";
    normal.mipFilter = Settings::MipFilter::Nearest;
    normal.anisotropy = 1;
    normal.mipBias = -1;
    normal.mipPolicy = "generate";
    validateHairPointMipReferenceNormal(hair);

    const auto rejects = [&hair](auto edit) {
        auto invalid = hair;
        edit(invalid);
        try { validateHairPointMipReferenceNormal(invalid); }
        catch (const std::invalid_argument&) { return true; }
        return false;
    };
    if (!rejects([](auto& m) { m.materialProfileVersion = 1; })
        || !rejects([](auto& m) { m.materialClass = AssetMaterialClass::Fabric; })
        || !rejects([](auto& m) { m.projectedHairRamp.materialSnapshotNormal = false; })
        || !rejects([](auto& m) { m.alphaMode = AssetAlphaMode::Blend; })
        || !rejects([](auto& m) { m.textureSettings[1].filter = "nearest"; })
        || !rejects([](auto& m) { m.textureSettings[1].magFilter = Settings::MagFilter::Nearest; })
        || !rejects([](auto& m) { m.textureSettings[1].mipFilter = Settings::MipFilter::Linear; })
        || !rejects([](auto& m) { m.textureSettings[1].anisotropy = 8; })
        || !rejects([](auto& m) { m.textureSettings[1].mipPolicy = "none"; })) return 1;
    std::cout << "Accepted the native hair sampler and rejected nine incompatible receivers or samplers\n";
}
