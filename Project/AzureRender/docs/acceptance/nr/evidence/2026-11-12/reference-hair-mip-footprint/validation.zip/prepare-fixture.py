from hashlib import file_digest, sha256
from pathlib import Path
from shutil import copyfile
import json
import struct


run=Path(__file__).resolve().parent
baseline=run.parent/'20261112-135432-reference-outline-projection-d784cf'
fixture=run/'hair-project'
source=baseline/'hair-project'
manifest=json.loads((baseline/'fixture-inputs.json').read_text())['files']
assert len(manifest)==45


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


changed=[]
for item in manifest:
    relative=Path(item['relative'])
    original=source/relative
    assert original.resolve(strict=True).is_relative_to(source.resolve())
    assert original.stat().st_size==item['bytes'] and digest(original)==item['sha256']
    path=fixture/relative
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.suffix!='.glb':
        copyfile(original,path)
        assert digest(path)==item['sha256']
        continue
    raw=original.read_bytes()
    magic,version,length,json_size,kind=struct.unpack_from('<4sIII4s',raw)
    assert (magic,version,length,kind)==(b'glTF',2,len(raw),b'JSON')
    document=json.loads(raw[20:20+json_size])
    material,=[m for m in document['materials'] if m['name']=='M_actor_laevat_hair_01']
    profile=material['extras']['azureRenderMaterial']
    assert profile['schemaVersion']==2 and profile['class']=='hair'
    assert profile['hair']['projectedRamp']['snapshotNormal']=='material-normal-rg'
    assert 'referenceNormal' not in profile and material['normalTexture']['index']==68
    profile['referenceNormal']={'schemaVersion':1,'encoding':'hair-point-mip'}
    encoded=json.dumps(document,separators=(',',':')).encode()
    encoded+=b' '*(-len(encoded)%4)
    binary=raw[20+json_size:]
    new=struct.pack('<4sIII4s',magic,version,20+len(encoded)+len(binary),len(encoded),kind)+encoded+binary
    path.write_bytes(new)
    assert path.read_bytes()[20+len(encoded):]==binary
    changed.append(dict(relative=item['relative'],originalSha256=item['sha256'],candidateSha256=digest(path),
        unchangedPayloadSha256=sha256(binary).hexdigest()))
assert len(changed)==1
files=[dict(relative=p.relative_to(fixture).as_posix(),bytes=p.stat().st_size,sha256=digest(p))
    for p in sorted(fixture.rglob('*')) if p.is_file()]
assert len(files)==45
(report_path:=run/'fixture-inputs.json').write_text(json.dumps(dict(files=files,changed=changed),indent=2)+'\n')
assert report_path.is_file()
reports={}
for config in ('release','debug'):
    for adapter in ('nvidia','intel'):
        label=f'{config}-{adapter}'
        row=json.loads((baseline/(label+'-results.json')).read_text())
        assert row['hairVisibilityOverOne']==(0 if adapter=='nvidia' else 208)
        assert row['hairColorOverOne']==(0 if adapter=='nvidia' else 575)
        reports[label]={key:row[key] for key in ('playerSha256','hairVisibilityOverOne','hairColorOverOne',
            'receiver','referenceDepthSha256','normalsSha256','objectIdsSha256','visibilitySha256','colorSha256')}
(run/'baseline-receipt.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(dict(files=len(files),changed=changed)))

