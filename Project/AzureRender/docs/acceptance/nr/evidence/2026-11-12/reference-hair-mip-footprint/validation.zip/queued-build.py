from pathlib import Path
import json
import os
import subprocess
import sys
import time


out = Path(__file__).resolve().parent
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def run(folder, label, script, *arguments, timeout=450):
    command = [sys.executable, '-B', str(out / script), *arguments]
    result = shared.maintenance.guarded_run(out.parents[1], folder, command, timeout)
    (out / (label + '-execution.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    assert result['status'] == 'exited' and result['exitCode'] == 0, result


predecessor, batch = sys.argv[1:]
assert batch in ('release-build', 'release-capture', 'release-final', 'debug-build', 'debug-capture', 'debug-final', 'original-four')
deadline = time.monotonic() + 1200
while time.monotonic() < deadline:
    try:
        state = json.loads((shared.DEFAULT_QUEUE / 'current.json').read_text())
    except (OSError, ValueError):
        time.sleep(1)
        continue
    if state.get('token') != predecessor or state.get('state') == 'released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed reference hair mip footprint window has not opened')

for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES', 'VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key, None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LAYER_VALIDATE_SYNC='1')
lease = None
try:
    with shared.lease(shared.DEFAULT_QUEUE, '01a1c099-8121-7be3-b0b8-7af2f9a06b2a', 'quality-reference-hair-mip-footprint-' + batch, out) as lease:
        (out / (batch + '-lease-held.json')).write_text(json.dumps(lease, indent=2) + '\n')
        if batch.endswith(('-build', '-final')):
            configuration = batch.split('-')[0].title()
            parent = ('20261110-030251-hair-main-chroma-public-9e799c' if configuration == 'Release'
                else '20261110-031856-hair-main-chroma-debug-668bf2')
            shared.maintenance.resume(out.parents[1], parent)
            if configuration == 'Debug':
                run(parent, 'debug-prepare', 'prepare-debug-budget.py', timeout=120)
            run(parent, configuration.lower() + '-build', 'build.py', configuration, timeout=940)
            run(out.name, configuration.lower() + '-cpu-tests', 'verify-build.py', configuration)
        if batch.endswith(('-capture', '-final')):
            configuration = batch.split('-')[0].title()
            for device in ('nvidia', 'intel'):
                os.environ['VK_LOADER_DRIVERS_SELECT'] = '*igvk64*' if device == 'intel' else '*nv-vk64*'
                label = configuration.lower() + '-' + device
                for suffix, script, arguments in (
                    ('-gpu-tests', 'verify-build.py', (configuration, device)),
                ):
                    execution_file = out / (label + suffix + '-execution.json')
                    if execution_file.is_file():
                        previous = json.loads(execution_file.read_text())
                        assert previous['status'] == 'exited' and previous['exitCode'] == 0
                    else:
                        run(out.name, label + suffix, script, *arguments)
                captured = out / (label + '-capture-execution.json')
                if captured.is_file():
                    previous = json.loads(captured.read_text())
                    assert previous['status'] == 'exited' and previous['exitCode'] == 0
                    assert (out / (label + '-results.json')).is_file()
                    assert (out / (label + '-frames') / 'reference-planes.json').is_file()
                else:
                    run(out.name, label + '-capture', 'capture.py', configuration, device)
                    subprocess.run([sys.executable, '-B', str(out / 'compact-capture.py'), label + '-frames'], check=True)
            run(out.name, configuration.lower() + '-candidate-gate', 'candidate-gate.py', configuration.lower(), timeout=30)
        if batch in ('original-four', 'debug-final'):
            os.environ['VK_LOADER_DRIVERS_SELECT'] = '*nv-vk64*'
            run(out.name, 'original-four', 'default-four.py', timeout=650)
finally:
    if lease is not None:
        (out / (batch + '-lease-released.json')).write_text(json.dumps(lease, indent=2) + '\n')


