from hashlib import sha256
from pathlib import Path
import json
import zipfile


run=Path(__file__).resolve().parent
engine=run.parents[2]
evidence=engine/'docs/acceptance/nr/evidence/2026-11-12/reference-hair-mip-footprint'


def read(name):
    return json.loads((run/name).read_text())


gate=read('release-candidate-gate.json')
assert gate['status']=='failed-reference-hair-mip-footprint' and gate['overallStatus']=='failed-user-review'
receipts={}
for name in ('release-build','release-cpu-tests','release-nvidia-gpu-tests','release-intel-gpu-tests',
             'release-nvidia-capture','release-intel-capture','release-candidate-gate'):
    receipt=read(name+'-execution.json')
    assert receipt['status']=='exited'
    assert receipt['exitCode']==(2 if name=='release-candidate-gate' else 0)
    receipts[name]=receipt
lease=read('release-final-lease-released.json')
assert lease['state']=='released' and lease['token']==read('release-final-lease-held.json')['token']
isolation=read('isolated-candidate.json')
assert isolation['restoredShaderCount']==895
assert isolation['candidatePatchSha256']==sha256((run/'candidate.patch').read_bytes()).hexdigest()
abi={}
for config in ('release','debug'):
    before=read(f'material-layout-{config}-before.json')
    after=read(f'material-layout-{config}-after.json')
    assert before['size']==after['size']
    assert all(after['fields'][name]==offset for name,offset in before['fields'].items())
    abi[config]=dict(size=after['size'],fieldOffset=after['fields']['hairPointMipReferenceNormal'])
attribution=read('mip-boundary-attribution.json')
assert len(attribution['devices']['nvidia']['samplesOverOne'])==6
assert len(attribution['devices']['intel']['samplesOverOne'])==13
assert sum(row['visibilityOverOne'] for row in attribution['devices']['nvidia']['samplesOverOne'])==2
assert attribution['devices']['nvidia']['candidateHasDeviceMip']==17017
assert attribution['devices']['intel']['candidateHasDeviceMip']==17016
assert len(attribution['devices']['intel']['noMatchingDeviceMip'])==1

evidence.mkdir(parents=True,exist_ok=False)
archive_path=evidence/'validation.zip'
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(run.iterdir()):
        if path.is_file() and path.suffix in ('.py','.cpp','.json','.log','.spv','.patch','.bin','.xml'):
            archive.write(path,path.name)
    for device in ('nvidia','intel'):
        folder=run/f'release-{device}-frames'
        for name in ('capture_manifest.json','reference-planes.json','gpu_capabilities.json'):
            archive.write(folder/name,(folder/name).relative_to(run).as_posix())
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    members=len(archive.namelist())
raw=archive_path.read_bytes()
assert len(raw)<8*1024**2
summary=dict(status=gate['status'],overallStatus=gate['overallStatus'],gate=gate,scope=read('task-card.json'),
    release=read('release-verification.json'),fixture=read('fixture-inputs.json')['changed'],layout=abi,
    isolation=isolation,attribution=attribution,executions=receipts,lease=lease,
    archive=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw),members=members))
(evidence/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))

