from hashlib import sha256
from pathlib import Path
import json
import re
import subprocess


out = Path(__file__).resolve().parent
engine = out.parents[2]
build = out.parent / '20261110-030251-hair-main-chroma-public-9e799c/release'
ninja = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
batch = 'D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'
sdk = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
source = engine / 'shaders/reference_scene_depth.frag'
programs = {}
for suffix in ('', '_bindless'):
    target = out / ('reference_scene_visibility' + suffix + '.frag.spv')
    definitions = ['AZURE_REFERENCE_MATERIAL_UV', 'AZURE_FRAGMENT_QUAD_OPERATIONS', 'AZURE_INDEPENDENT_COVERAGE',
        'AZURE_REFERENCE_SCENE_VISIBILITY']
    if suffix:
        definitions.append('AZURE_BINDLESS')
    command = [str(sdk / 'glslc.exe'), '--target-env=vulkan1.1', *('-D' + key + '=1' for key in definitions),
        str(source), '-o', str(target)]
    subprocess.run(command, check=True)
    subprocess.run([str(sdk / 'spirv-val.exe'), '--target-env', 'vulkan1.3', '--relax-block-layout', str(target)], check=True)
    programs[target.name] = sha256(target.read_bytes()).hexdigest()
for path in ('src/scenes/CharacterSceneRenderer.cpp', 'src/assets/GltfLoader.cpp'):
    target = 'CMakeFiles/AzureRenderCore.dir/' + path + '.obj'
    commands = subprocess.check_output([ninja, '-C', str(build), '-t', 'commands', target], encoding='utf-8').splitlines()
    command = commands[-1]
    assert 'cl.exe ' in command and ' -c ' in command
    command = re.sub(r' /F[od]\S+| /showIncludes| /FS', '', command).replace(' -c ', ' /Zs ')
    process = subprocess.run(f'"{batch}" {command}', shell=True, cwd=out, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out / (Path(path).stem + '-typecheck.log')).write_bytes(process.stdout)
    assert process.returncode == 0, process.stdout.decode(errors='replace')
(out / 'typecheck.json').write_text(json.dumps(dict(shaderPrograms=programs, sourceChecks=2), indent=2) + '\n')
print(json.dumps(programs))
