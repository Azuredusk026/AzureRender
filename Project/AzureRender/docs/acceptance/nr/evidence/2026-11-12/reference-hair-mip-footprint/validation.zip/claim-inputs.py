from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys


out = Path(__file__).resolve().parent
build = out.parents[1]
main = Path('D:/Projects/FYP/Project/AzureRender/build')
owner = '01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
source = 'fa8c6a9fbc883bf8880bf983e81343b6a2435ab2'
sys.path.insert(0, str(main.parent / 'tools'))
import shared_resources as shared


claim_path = Path('D:/Projects/FYP-coordination/quality-claim.json')
claim = json.loads(claim_path.read_text(encoding='utf-8'))
assert claim['threadId'] == owner and claim['state'] == 'native-texture-sampling-footprint'
commit = subprocess.check_output(['git', 'log', '-1', '--format=%H%n%P'], cwd=build.parent, text=True).splitlines()
assert commit == [source, claim['lastCommit']]
evidence = build.parent / 'docs/acceptance/nr/evidence/2026-11-12/native-texture-sampling-footprint'
manifest = json.loads((evidence / 'results.json').read_text())
assert manifest['status'] == 'qualified'
assert sha256((evidence / 'validation.zip').read_bytes()).hexdigest() == manifest['archive']['sha256']
old_stage = Path(claim['taskPath'])
assert old_stage.name == '20261112-143340-native-texture-sampling-footprint-750e56'
old_local, old_main = claim['localInputLease'], claim['inputLease']


def inherited(root, tokens):
    with shared.maintenance.database(root, True) as db:
        records = shared.maintenance.rows(db)
    assert all(records[token]['owner'] == owner for token in tokens)
    return list(dict.fromkeys(name for token in tokens for name in records[token]['inputs']))


local_inputs = inherited(build, old_local) + [old_stage.name]
main_inputs = inherited(main, old_main)
local = shared.acquire_inputs(build, out, local_inputs, owner)
try:
    native = shared.acquire_inputs(main, out, main_inputs, owner)
except Exception:
    shared.release_inputs(build, local, owner)
    raise
claim.update(state='reference-hair-mip-footprint', taskPath=str(out), inputLease=[native], localInputLease=[local],
    nativeCaptureLease=native, lastCommit=source, pendingCommand='Evaluate native-like explicit mip footprint for reference hair normal producer',
    ownedFiles=['src/assets/GltfLoader.hpp','src/assets/GltfLoader.cpp','src/assets/MaterialData.cpp','src/scenes/CharacterSceneRenderer.cpp','schemas/azure_render_material.schema.json','shaders/reference_scene_depth.frag','shaders/texture_footprint.glsl','docs/acceptance/nr/reference-hair-mip-footprint.md',
        'docs/acceptance/nr/evidence/2026-11-12/reference-hair-mip-footprint'], additionalTaskPaths=[])
claim['observed'].update(nativeFootprintFrozenExact=17012,nativeFootprintFrozenNormalNvidia=5,nativeFootprintFrozenNormalIntel=11)
(out / 'task-card.json').write_text(json.dumps(dict(local=local, main=native, sourceBase=source, plannedBytes=268435456,
    localInputs=local_inputs, mainInputs=main_inputs, change='Opt-in explicit point-mip footprint for reference snapshot hair normal',
    gate='Frozen 49384 receivers and 17017 hair at original one-byte gate; preserve original four frames and reference depth/IDs'), indent=2) + '\n')
temporary = claim_path.with_name(claim_path.name + '.nr-quality-new')
with temporary.open('x', encoding='utf-8') as stream:
    json.dump(claim, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
os.replace(temporary, claim_path)
for token in old_main:
    shared.release_inputs(main, token, owner)
for token in old_local:
    shared.release_inputs(build, token, owner)
print(json.dumps(dict(local=local, main=native, output=str(out))))



