param([ValidateSet('Release','Debug')][string]$Config,[ValidateSet('all','build','suite')][string]$Mode='all')
$ErrorActionPreference='Stop'
$run=(Resolve-Path $PSScriptRoot).Path
$engine=(Get-Item -LiteralPath $run).Parent.Parent.Parent.FullName
Set-Location -LiteralPath $engine
$python='build/reinstall-environment/venv/Scripts/python.exe'
$owner='01a1c097-ec33-7790-8c18-08a2b0ddb0c3'
function Invoke-Regression([string]$task,[string[]]$step,[int]$seconds){
 $deadline=[DateTime]::UtcNow.AddMinutes(40)
 $log=Join-Path $run "$task-queue.log"
 do{
  while(Test-Path -LiteralPath "$run/queue-window.json"){Start-Sleep -Seconds 5}
  & $python -X utf8 -B tools/shared_resources.py run --owner $owner --task $task --run (Split-Path $run -Leaf) --timeout $seconds --command $python -X utf8 -B "$run/full.py" @step *> $log
  $code=$LASTEXITCODE
  $contents=Get-Content -LiteralPath $log -Raw
  if($code -eq 0){Write-Output "$task completed";Start-Sleep -Seconds 4;return}
  if($contents -notmatch 'Shared resource busy or inaccessible'){Get-Content -LiteralPath $log -Tail 20;throw "$task failed with exit $code"}
  Start-Sleep -Seconds 6
 }while([DateTime]::UtcNow -lt $deadline)
 throw 'Shared queue did not open'
}
$c=$Config.ToLowerInvariant()
if($Mode -in @('all','build')){Invoke-Regression "full-$c-build" @('build',$Config) 1850}
if($Mode -in @('all','suite')){
 $inventory=Get-Content -LiteralPath "$run/$c-inventory.json" -Raw | ConvertFrom-Json
 $count=$inventory.tests.Count
 $completed=@{}
 Get-ChildItem -LiteralPath $run -File -Filter "$c-ctest-*-*.json" | ForEach-Object {
  $report=Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json
  if($null -ne $report.firstTest){for($i=$report.firstTest;$i -le $report.lastTest;$i++){$completed[$i]=$true}}
 }
 $long=@{}
 for($i=1;$i -le $count;$i++){
  $time=$inventory.tests[$i-1].properties | Where-Object name -eq 'TIMEOUT' | Select-Object -First 1
  if($null -ne $time -and [double]$time.value -gt 150){$long[$i]=$true}
 }
 for($first=1;$first -le $count;){
  if($completed.ContainsKey($first)){$first++;continue}
  $last=$first
  if(-not $long.ContainsKey($first)){
   while($last -lt $count -and ($last-$first) -lt 34 -and -not $long.ContainsKey($last+1) -and -not $completed.ContainsKey($last+1)){$last++}
  }
  $suffix='{0:000}-{1:000}' -f $first,$last
  Invoke-Regression "full-$c-$suffix" @('suite',$Config,"$first","$last") 4400
  $first=$last+1
 }
}
