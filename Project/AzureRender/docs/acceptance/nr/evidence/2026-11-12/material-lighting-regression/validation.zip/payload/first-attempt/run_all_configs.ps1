$ErrorActionPreference='Stop'
$run=(Resolve-Path $PSScriptRoot).Path
$engine=(Get-Item -LiteralPath $run).Parent.Parent.Parent.FullName
Set-Location -LiteralPath $engine
$python='build/reinstall-environment/venv/Scripts/python.exe'
foreach($config in @('Debug','Release')){
    & "$run/run.ps1" -Config $config -Mode build
}
foreach($config in @('Debug','Release')){
    & "$run/run.ps1" -Config $config -Mode suite
}
& $python -X utf8 -B "$run/summarize.py" --full | Set-Content -LiteralPath "$run/full-suite-summary.json" -Encoding utf8NoBOM
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
$results=Get-Content -LiteralPath "$run/full-suite-summary.json" -Raw | ConvertFrom-Json
if($results.debug.state -ne 'passed' -or $results.release.state -ne 'passed'){
    Get-Content -LiteralPath "$run/full-suite-summary.json"
    exit 1
}
Get-Content -LiteralPath "$run/full-suite-summary.json"
