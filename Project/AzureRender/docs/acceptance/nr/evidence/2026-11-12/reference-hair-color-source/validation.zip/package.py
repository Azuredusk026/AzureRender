
from hashlib import sha256
from pathlib import Path
import json
import zipfile


run=Path(__file__).resolve().parent
engine=run.parents[2]
prior=run.parent/'20261112-164303-reference-hair-mip-boundary-342000'
evidence=engine/'docs/acceptance/nr/evidence/2026-11-12/reference-hair-color-source'


def load(path):
    return json.loads(path.read_text())


status=load(run/'color-source-gate.json')
assert status['overallStatus']=='failed-user-review'
cases={device:load(run/(device+'-results.json')) for device in ('nvidia','intel')}
executions={device:load(run/(device+'-execution.json')) for device in cases}
assert all(item['status']=='exited' and item['exitCode']==0 for item in executions.values())
assert all(case['validationClean'] and case['allocatorZero'] and case['shaderCount']==895 for case in cases.values())
lease_held,lease_released=(load(run/('lease-'+state+'.json')) for state in ('held','released'))
assert lease_held['token']==lease_released['token'] and lease_released['state']=='released'
shader_dir=prior/'next-color-shaders'
compiled=load(shader_dir/'compiled.json')
source_dir=prior.parent/'20261112-153052-reference-hair-mip-footprint-510ded/hair-project/character'
source_hashes={str(name):sha256((source_dir/name).read_bytes()).hexdigest()
    for name in ('native-textures/t18.dds','captured-hair-normal.dds','native-textures/t18.dds.azmeta')}
assert source_hashes['native-textures/t18.dds']==source_hashes['captured-hair-normal.dds']=='876179d4707dfd219f8100a656ff602807535f601888165caf77282f58deda54'
for name,row in compiled['programs'].items():
    assert sha256((shader_dir/name).read_bytes()).hexdigest()==row['probeSha256']
    assert all(case['overlay'][name]==row['probeSha256'] for case in cases.values())
assert status['overlayFilesCompacted']==895 and not (run/'overlay').exists()
assert len(compiled['programs'])==8 and len({case['playerSha256'] for case in cases.values()})==1
for device,case in cases.items():
    expected=0 if device=='nvidia' else 568
    assert all(frame['baselineOverOne']==expected for frame in case['colors'])
    assert len(case['attachments'])==5 and len(case['colors'])==3

evidence.mkdir(parents=True,exist_ok=False)
archive_path=evidence/'validation.zip'
with zipfile.ZipFile(archive_path,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(run.iterdir()):
        if path.is_file() and path.suffix in ('.py','.json','.log','.bin'):
            archive.write(path,path.name)
    for path in sorted(shader_dir.iterdir()):
        if path.suffix in ('.frag','.json','.spv'):
            archive.write(path,'isolated-shaders/'+path.name)
    for name in ('next-color-compile.py','next-color-input-audit.py','next-color-input-audit.json'):
        archive.write(prior/name,'source-control/'+name)
    for device in cases:
        for name in ('capture_manifest.json','reference-planes.json','gpu_capabilities.json'):
            path=run/(device+'-frames')/name
            archive.write(path,path.relative_to(run).as_posix())
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    archive_count=len(archive.namelist())
payload=archive_path.read_bytes()
assert len(payload)<8*1024**2
summary=dict(status=status['status'],gate=status,lease=lease_released,execution=executions,
    scope=load(run/'task-card.json'),sourceFiles=source_hashes,programs=compiled['programs'],
    devices={device:{key:value for key,value in result.items() if key!='overlay'} for device,result in cases.items()},
    archive=dict(sha256=sha256(payload).hexdigest(),bytes=len(payload),members=archive_count))
(evidence/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
