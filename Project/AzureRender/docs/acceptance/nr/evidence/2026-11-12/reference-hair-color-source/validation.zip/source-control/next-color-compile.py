
from hashlib import file_digest
from pathlib import Path
import json
import subprocess
import sys


out=Path(__file__).resolve().parent
engine=out.parents[2]
build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
manifest=json.loads((build/'shader-reload.json').read_text())
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
scratch=out/'next-color-shaders'
scratch.mkdir(exist_ok=True)


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def replace_once(source, old, new):
    assert source.count(old)==1, old
    return source.replace(old,new)


original=engine/'shaders/mesh.frag'
candidate=replace_once(original.read_text(), '#include "material_primary_uv.glsl"',
    '#include "material_primary_uv.glsl"\n#include "texture_footprint.glsl"')
anchor='float azureMaterialRadianceScale() {'
candidate=replace_once(candidate,anchor,'''
vec4 sampleProjectedHairData(vec2 uv) {
    vec4 implicitSample=azureSamplePrimaryUv(AZ_TEX_HAIR_DATA,uv);
    uint flags=uint(materialSurfaceProfiles.profiles[material.materialPadding>>1U].rows[6].w+.5);
    if(AZURE_MATERIAL_CLASS!=3U||(flags&4U)==0u)return implicitSample;
    vec2 size=vec2(textureSize(AZ_TEX_HAIR_DATA,0));
    float lod=azureAxisDiagonalMipLod(azurePrimaryUvDx*size,azurePrimaryUvDy*size);
    vec4 explicitSample=textureLod(AZ_TEX_HAIR_DATA,uv,lod);
    bool atBoundary=abs(fract(lod-1.0)-.5)<=1.0/256.0;
    return mix(explicitSample,implicitSample,bvec4(atBoundary));
}
'''+anchor)
candidate=replace_once(candidate,':azureSamplePrimaryUv(AZ_TEX_HAIR_DATA,uv);',':sampleProjectedHairData(uv);')
candidate=replace_once(candidate,':azureSamplePrimaryUv(AZ_TEX_HAIR_DATA,textureCoordinate);',':sampleProjectedHairData(textureCoordinate);')
probe=scratch/'mesh.frag'
probe.write_text(candidate,encoding='utf-8')
programs=[]
for desc in manifest['programs']:
    defines=desc['defines']
    if (desc['source']=='mesh.frag' and desc['output'].startswith('mesh') and desc['output'].endswith('_coverage_uvquad.frag.spv')
        and 'AZURE_BINDLESS=1' not in defines and 'AZURE_GEOMETRY_SAMPLES=1' not in defines):
        programs.append(desc)
assert len(programs)==8, [x['output'] for x in programs]
commands={}
for desc in programs:
    name=desc['output']
    base=[str(sdk/'glslc.exe'),*desc['arguments'],*('-D'+flag for flag in desc['defines'])]
    baseline=scratch/'baseline.spv'
    subprocess.run([*base,str(original),'-o',str(baseline)],check=True)
    expected=digest(build/'shaders'/name)
    assert digest(baseline)==expected,name
    baseline.unlink()
    shader=scratch/name
    args=[*base,'-I'+str(original.parent),str(probe),'-o',str(shader)]
    subprocess.run(args,check=True)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(shader)],check=True)
    assert digest(shader)!=expected
    commands[name]=dict(baselineSha256=expected,probeSha256=digest(shader),command=args)
result=dict(scope='t18 beauty shading only',samplerLodBias=-1,sourceSha256=digest(probe),productionSourceSha256=digest(original),programs=commands)
(scratch/'compiled.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value['probeSha256'] for key,value in commands.items()}))
