
from pathlib import Path
from collections import Counter
import json
import runpy
import numpy as np
from PIL import Image
p = Path(__file__).resolve().parent
base = runpy.run_path(str(p.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
mask = base['mask']
bounds = tuple(base[name] for name in ('x0','y0','x1','y1'))
assert mask.sum()==17017
out={}
for device in ('nvidia','intel'):
    d = np.fromfile(p/f'release-{device}-hair-selected.bin', '<u4').astype('i4').reshape(-1,8)
    x,y,normal,old_normal,new_normal,rg,old_rg,new_rg=d.T
    row,col = 1439-y-bounds[1],x-bounds[0]
    assert mask[row,col].all() and len(set(zip(row,col)))==17017
    values = np.array(Image.open(p/f'release-{device}-frames/frame_000000.png').convert('RGB').crop(bounds)).astype('i4')
    delta = (values-base['expected'])[row,col]
    error = np.abs(delta).max(axis=1)
    rg_bad=np.abs(rg-new_rg)>1
    normal_bad=np.maximum(*[np.abs(((normal>>s)&1023)-((new_normal>>s)&1023)) for s in (0,10)])>1
    inner = mask.copy()
    inner[1:-1,1:-1] = np.logical_and.reduce([mask[1+dy:mask.shape[0]-1+dy,1+dx:mask.shape[1]-1+dx] for dy in (-1,0,1) for dx in (-1,0,1)])
    inner[0,:]=inner[-1,:]=inner[:,0]=inner[:,-1]=False
    bad=error>1
    out[device] = dict(histogram={str(k): v for k,v in sorted(Counter(error.tolist()).items())}, colorOverOne=int(bad.sum()),
        colorAndVisibility=int((bad&rg_bad).sum()),colorAndNormal=int((bad&normal_bad).sum()),
        colorAndBoth=int((bad&rg_bad&normal_bad).sum()),colorAndNeither=int((bad&~rg_bad&~normal_bad).sum()),
        colorAndExactVisibility=int((bad&(rg==new_rg)).sum()),colorAndExactPackedNormal=int((bad&(normal==new_normal)).sum()),
        colorInsideErodedMask=int((bad&inner[row,col]).sum()), extremes=[
        dict(display=[int(x[i]),int(1439-y[i])],referenceRow=int(y[i]),delta=delta[i].tolist(),
            expected=base['expected'][row[i],col[i]].tolist(),actual=values[row[i],col[i]].tolist(),
            visible=[int(rg[i]),int(new_rg[i])],packedNormal=[int(normal[i]),int(new_normal[i])])
        for i in np.flatnonzero(error>15)])
(p/'next-color-input-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
