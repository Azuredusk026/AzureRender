
from hashlib import file_digest
from pathlib import Path
import json
import os
import subprocess
import sys
import time


out=Path(__file__).resolve().parent
build=out.parents[1]
previous=out.parent/'20261112-164303-reference-hair-mip-boundary-342000'
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def write(name,value):
    (out/name).write_text(json.dumps(value,indent=2)+'\n')


predecessor,receipt_path=sys.argv[1:]
deadline=time.monotonic()+1800
while time.monotonic()<deadline:
    try:
        state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
        receipt=json.loads(Path(receipt_path).read_text())
    except (OSError,ValueError):
        time.sleep(1)
        continue
    assert state['token']==predecessor and receipt['token']==predecessor
    if state['state']==receipt['state']=='released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed color input window has not opened')
write('predecessor-receipt.json',receipt)
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key,None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
lease=None
try:
    with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-reference-hair-color-source-gpu',out) as lease:
        write('lease-held.json',lease)
        for device in ('nvidia','intel'):
            os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*' if device=='intel' else '*nv-vk64*'
            argv=[sys.executable,'-B',str(out/'color-capture.py'),device]
            result=shared.maintenance.guarded_run(build,out.name,argv,330)
            write(device+'-execution.json',result)
            print(json.dumps(result),flush=True)
            assert result['status']=='exited' and result['exitCode']==0,result
            subprocess.run([sys.executable,'-B',str(out/'compact-capture.py'),device+'-frames'],check=True)
        devices={name:json.loads((out/(name+'-results.json')).read_text()) for name in ('nvidia','intel')}
        catalog=devices['nvidia']['overlay']
        assert catalog==devices['intel']['overlay']
        shaders=(out/'overlay/shaders').resolve(strict=True)
        assert shaders.parent.parent==out.resolve(strict=True)
        listed=list(shaders.iterdir())
        assert {path.name:digest(path) for path in listed}==catalog
        for path in listed:
            assert path.is_file() and path.resolve(strict=True).parent==shaders and path.suffix=='.spv'
            path.unlink()
        shaders.rmdir()
        shaders.parent.rmdir()
        nvidia,intel=(devices[name] for name in ('nvidia','intel'))
        attachments_exact=all(record['exact'] for result in devices.values() for record in result['attachments'].values())
        unchanged_nvidia=all(row['overOne']==0 for row in nvidia['colors'])
        improved_intel=all(row['overOne']<row['baselineOverOne'] for row in intel['colors'])
        changed=any(row['frozenHairChanged'] for result in devices.values() for row in result['colors'])
        summary=dict(status='qualified-source-isolation' if changed and attachments_exact else 'failed-source-isolation',
            source='projected hair data texture in beauty',referenceAttachmentsExact=attachments_exact,activated=changed,
            nvidiaFrozenHairPass=unchanged_nvidia,intelFrozenHairImproved=improved_intel,
            candidateQualified=changed and attachments_exact and unchanged_nvidia and improved_intel,overallStatus='failed-user-review',
            colors={name:rows['colors'] for name,rows in devices.items()},overlayFilesCompacted=len(listed))
        write('color-source-gate.json',summary)
        print(json.dumps(summary),flush=True)
finally:
    if lease is not None:
        write('lease-released.json',lease)
