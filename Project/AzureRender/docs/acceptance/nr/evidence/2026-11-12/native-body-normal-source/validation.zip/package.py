
from hashlib import sha256
from pathlib import Path
import json
import zipfile


run=Path(__file__).resolve().parent
engine=run.parents[2]
out=engine/'docs/acceptance/nr/evidence/2026-11-12/native-body-normal-source'
read=lambda path:json.loads(path.read_text())
source=read(run/'native-source/report.json')
comparison=read(run/'native-body-source-comparison.json')
receipt=read(run/'replay-execution.json')
held=read(run/'lease-held.json')
released=read(run/'lease-released.json')
assert source['status']=='qualified'
assert receipt['status']=='exited' and receipt['exitCode']==0
assert held['token']==released['token'] and released['state']=='released'
assert all(source['devices']['nvidia'][key]==source['devices']['intel'][key] for key in ('levels','sampler','program'))
assert len(comparison['levels'])==11 and all(row['blocksExact'] for row in comparison['levels'])
assert sum(row['texels']['rows-0-green-0']['exact'] for row in comparison['levels'])==1398101
region=read(run/'receiver-decomposition.json')
body={device:rows['328'] for device,rows in region.items()}
assert body['nvidia']['receiverBad']==46 and body['intel']['receiverBad']==77
native=run/'native-source'/source['dds']['file']
assert sha256(native.read_bytes()).hexdigest()==source['dds']['sha256']
known={
    'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU',
    'NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image',
}
assert set(source['devices']['nvidia']['messages'])<=known and not source['devices']['intel']['messages']
out.mkdir(parents=True,exist_ok=False)
archive_path=out/'validation.zip'
with zipfile.ZipFile(archive_path,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(run.iterdir()):
        if path.is_file() and path.suffix in ('.py','.json','.log'):
            archive.write(path,path.name)
    for path in sorted((run/'native-source').iterdir()):
        if path.is_file():
            archive.write(path,path.relative_to(run).as_posix())
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    count=len(archive.namelist())
payload=archive_path.read_bytes()
assert len(payload)<8*1024**2
report=dict(status='qualified-native-body-normal-source',overallStatus='failed-user-review',bodyRegion=body,
    source=source,comparison=comparison,scope=read(run/'task-card.json'),execution=receipt,lease=released,
    archive=dict(sha256=sha256(payload).hexdigest(),bytes=len(payload),members=count))
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['archive']))
