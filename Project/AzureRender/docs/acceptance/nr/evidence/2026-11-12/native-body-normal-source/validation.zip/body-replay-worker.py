from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import traceback

import renderdoc as rd


request = json.loads(Path(os.environ['AZURE_BODY_RECEIVER_REQUEST']).read_text(encoding='utf-8'))
out = Path(request['output'])
capture = rd.OpenCaptureFile()
controller = None
receipt = dict(status='failed', devices={})


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


def dds_header(width, height, mip_count, base_size):
    code = struct.unpack('<I', b'DX10')[0]
    fields = [124, 0xA1007, height, width, base_size, 0, mip_count] + [0] * 11
    pixel_format = [32, 4, code, 0, 0, 0, 0, 0]
    caps = [0x401008, 0, 0, 0, 0]
    dxgi_format_bc5, dimension_texture_2d = 83, 3
    return b'DDS ' + struct.pack('<36I', *(fields + pixel_format + caps + [dxgi_format_bc5, dimension_texture_2d, 0, 1, 0]))


def constant(pipeline, reflection, stage, slot, row):
    index, = [i for i, block in enumerate(reflection.constantBlocks) if block.bufferBacked and block.fixedBindNumber == slot]
    binding = pipeline.GetConstantBlock(stage, index, 0).descriptor
    assert binding.byteSize >= (row + 1) * 16
    raw = bytes(controller.GetBufferData(binding.resource, binding.byteOffset + row * 16, 16))
    return struct.unpack('<4f', raw)


try:
    assert capture.OpenFile(request['capture'], '', None) == rd.ResultCode.Succeeded
    for name, vendor in (('nvidia', rd.GPUVendor.nVidia), ('intel', rd.GPUVendor.Intel)):
        gpu, = [g for g in capture.GetAvailableGPUs() if g.vendor == vendor and rd.GraphicsAPI.D3D11 in g.apis]
        options = rd.ReplayOptions()
        options.forceGPUVendor = gpu.vendor
        options.forceGPUDeviceID = gpu.deviceID
        status, controller = capture.OpenCapture(options, None)
        assert status == rd.ResultCode.Succeeded and controller
        properties = controller.GetAPIProperties()
        assert properties.vendor == vendor and properties.pipelineType == rd.GraphicsAPI.D3D11 and not properties.degraded
        event = request['event']
        action, = [entry for entry in walk(controller.GetRootActions()) if entry.eventId == event]
        assert action.numIndices == 17037 and action.numInstances == 1
        controller.SetFrameEvent(event, True)
        pipeline = controller.GetPipelineState()
        ps, vs = rd.ShaderStage.Pixel, rd.ShaderStage.Vertex
        pixel = pipeline.GetShaderReflection(ps)
        vertex = pipeline.GetShaderReflection(vs)
        binding, = [entry.descriptor for entry in pipeline.GetReadOnlyResources(ps)
            if pixel.readOnlyResources[entry.access.index].fixedBindNumber == 1]
        texture, = [item for item in controller.GetTextures() if item.resourceId == binding.resource]
        assert str(binding.resource) == request['resource'] and (binding.firstMip, binding.firstSlice) == (0, 0)
        assert (texture.width, texture.height, texture.mips, texture.format.Name()) == (1024, 1024, 11, 'BC5_UNORM')
        levels, payload = [], []
        for level in range(texture.mips):
            width, height = max(1, texture.width >> level), max(1, texture.height >> level)
            raw = bytes(controller.GetTextureData(binding.resource, rd.Subresource(level, 0, 0)))
            assert len(raw) == ((width + 3) // 4) * ((height + 3) // 4) * 16
            levels.append(dict(level=level, extent=[width, height], bytes=len(raw), sha256=sha256(raw).hexdigest()))
            payload.append(raw)
        assert len(levels) == 11
        sampler, = [entry.sampler for entry in pipeline.GetSamplers(ps)]
        sample = dict(bias=sampler.mipBias, lod=[sampler.minLOD, sampler.maxLOD], anisotropy=sampler.maxAnisotropy,
            address=[str(sampler.addressU), str(sampler.addressV)], filters=[str(sampler.filter.minify),
                str(sampler.filter.magnify), str(sampler.filter.mip)])
        assert sample['filters'] == ['FilterMode.Linear', 'FilterMode.Linear', 'FilterMode.Point']
        program = dict(pixelSha256=sha256(bytes(pixel.rawBytes)).hexdigest(), vertexSha256=sha256(bytes(vertex.rawBytes)).hexdigest(),
            sampleBias=constant(pipeline, pixel, ps, 1, 26)[0], normalScale=constant(pipeline, pixel, ps, 3, 0)[3],
            backface=constant(pipeline, pixel, ps, 3, 1)[1], uvTransform=constant(pipeline, vertex, vs, 3, 10))
        assert program['sampleBias'] == -1 and program['normalScale'] == 1 and program['backface'] == 0
        assert program['pixelSha256']=='907e0a39de60c6fc742ef86c230eb59ef2034b9a92909ce529df469a1986e1bc'
        assert program['vertexSha256']=='588e2efbfc43c84cdd37d2c1295c69089d534802b1facdfaa3906c2d4fd36c77'
        assert program['uvTransform']==(1,1,0,0)
        receipt['devices'][name] = dict(device=gpu.name, levels=levels, sampler=sample, program=program,
            messages=[str(message.description) for message in controller.GetDebugMessages()])
        if name == 'nvidia':
            header = dds_header(texture.width, texture.height, texture.mips, len(payload[0]))
            data = header + b''.join(payload)
            path = out / 'body-receiver-normal.dds'
            path.write_bytes(data)
            receipt['dds'] = dict(file=path.name, bytes=len(data), headerBytes=len(header), sha256=sha256(data).hexdigest())
        else:
            assert all(receipt['devices']['nvidia'][key] == receipt['devices']['intel'][key] for key in ('levels', 'sampler', 'program'))
        controller.Shutdown()
        controller = None
    receipt['status'] = 'qualified'
except BaseException:
    receipt['error'] = traceback.format_exc()
finally:
    if controller:
        controller.Shutdown()
    capture.Shutdown()
    (out / 'report.json').write_text(json.dumps(receipt, indent=2) + '\n')
os._exit(0 if receipt['status'] == 'qualified' else 1)
