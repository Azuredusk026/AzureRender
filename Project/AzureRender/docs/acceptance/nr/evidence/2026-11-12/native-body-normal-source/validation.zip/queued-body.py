
from pathlib import Path
import json
import sys
import time


out=Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def write(name,value):
    (out/name).write_text(json.dumps(value,indent=2)+'\n')


predecessor,receipt_path=sys.argv[1:]
deadline=time.monotonic()+1800
while time.monotonic()<deadline:
    try:
        state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
        receipt=json.loads(Path(receipt_path).read_text())
    except (OSError,ValueError):
        time.sleep(1)
        continue
    assert state['token']==receipt['token']==predecessor
    if state['state']==receipt['state']=='released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed body normal source window has not opened')
write('predecessor-receipt.json',receipt)
lease=None
try:
    with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-native-body-normal-source-gpu',out) as lease:
        write('lease-held.json',lease)
        argv=[sys.executable,'-B',str(out/'body-replay.py')]
        result=shared.maintenance.guarded_run(out.parents[1],out.name,argv,180)
        write('replay-execution.json',result)
        print(json.dumps(result),flush=True)
        assert result['status']=='exited' and result['exitCode']==0,result
finally:
    if lease is not None:
        write('lease-released.json',lease)
