
from pathlib import Path
import json
import os
import subprocess
import sys


out=Path(__file__).resolve().parent
build=out.parents[1]
main=Path('D:/Projects/FYP/Project/AzureRender/build')
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0,str(main.parent/'tools'))
import shared_resources as shared


claim_path=Path('D:/Projects/FYP-coordination/quality-claim.json')
claim=json.loads(claim_path.read_text(encoding='utf-8'))
assert claim['threadId']==owner and claim['state']=='reference-hair-color-triple'
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=build.parent,text=True).strip()
assert source=='b167227b73c025efa410c8cc4a7386aedb3ef283'==claim['lastCommit']
local_inputs=['20261112-153052-reference-hair-mip-footprint-510ded',
    '20261112-072016-native-receiver-producer-replay-523058','20261112-164303-reference-hair-mip-boundary-342000',
    '20261112-174157-reference-hair-color-pair-8d76da','20261112-024632-native-atlas-and-receiver-producers-d5e705',
    '20261110-003435-visibility-numeric-contract-4f95e7']
main_inputs=['20261022-201845-endfield-capture-954719','20261027-022702-object-visibility-depth-reconstruction-c7312f']
local=shared.acquire_inputs(build,out,local_inputs,owner)
try:
    native=shared.acquire_inputs(main,out,main_inputs,owner)
except Exception:
    shared.release_inputs(build,local,owner)
    raise
card=dict(local=local,main=native,sourceBase=source,plannedBytes=16777216,localInputs=local_inputs,mainInputs=main_inputs,
    scope='Native E328 t1 BC5 normal source, 11 mip levels',gate='Both native adapters and current fixture, source fingerprints and contents')
(out/'task-card.json').write_text(json.dumps(card,indent=2)+'\n')
paths=claim.get('additionalTaskPaths',[])
assert str(out) not in paths
claim['additionalTaskPaths']=paths+[str(out)]
temporary=claim_path.with_name(claim_path.name+'.nr-quality-new')
with temporary.open('x',encoding='utf-8') as stream:
    json.dump(claim,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
os.replace(temporary,claim_path)
print(json.dumps(card))
