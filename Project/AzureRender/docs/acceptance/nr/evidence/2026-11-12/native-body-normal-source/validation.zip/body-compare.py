
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from struct import pack, unpack_from
import json

import numpy as np
from PIL import Image


out=Path(__file__).resolve().parent
native=out/'native-source'
fixture=out.parent/'20261112-153052-reference-hair-mip-footprint-510ded/hair-project'
authored=fixture/'character/native-captured-body/t15.dds'
receipt=json.loads((native/'report.json').read_text())
assert receipt['status']=='qualified'
native_path=native/receipt['dds']['file']
captured_bytes=native_path.read_bytes()
authored_bytes=authored.read_bytes()
assert sha256(captured_bytes).hexdigest()==receipt['dds']['sha256']
assert sha256(authored_bytes).hexdigest()=='3d16ddcced1a4f482f969250b835c5ea569ce620d8ef16cc465fc19cbb266a9e'
assert authored_bytes[:4]==captured_bytes[:4]==b'DDS ' and authored_bytes[84:88]==b'ATI2'
assert unpack_from('<7I',authored_bytes,4)[2:4]==(1024,1024)
assert unpack_from('<I',authored_bytes,28)[0]==11
assert captured_bytes[84:88]==b'DX10'
assert len(captured_bytes)-148==len(authored_bytes)-128


def image(size, blocks):
    header=bytearray(captured_bytes[:148])
    header[12:24]=pack('<3I',size,size,len(blocks))
    header[28:32]=pack('<I',1)
    with Image.open(BytesIO(header+blocks)) as decoded:
        assert decoded.size==(size,size) and decoded.pixel_format=='BC5'
        return np.asarray(decoded,dtype='i2')[...,:2]


levels=[]
before,after=128,148
for level in receipt['devices']['nvidia']['levels']:
    size=level['extent'][0]
    length=level['bytes']
    current=authored_bytes[before:before+length]
    reference=captured_bytes[after:after+length]
    assert sha256(reference).hexdigest()==level['sha256']
    expected=image(size,reference)
    direct=image(size,current)
    comparison={}
    for flipped in (False,True):
        for inverted in (False,True):
            candidate=(direct[::-1] if flipped else direct).copy()
            if inverted:
                candidate[...,1]=255-candidate[...,1]
            error=np.abs(candidate-expected)
            peak=error.max(axis=-1)
            comparison[f'rows-{int(flipped)}-green-{int(inverted)}']=dict(exact=int((peak==0).sum()),
                withinOne=int((peak<=1).sum()),maximum=int(peak.max()),
                meanChannels=error.mean(axis=(0,1)).tolist())
    levels.append(dict(level=level['level'],size=size,nativeSha256=level['sha256'],fixtureSha256=sha256(current).hexdigest(),
        blocksExact=current==reference,texels=comparison))
    before+=length
    after+=length
assert before==len(authored_bytes) and after==len(captured_bytes)
outcome=dict(event=328,resource='ResourceId::85394',texture='character/native-captured-body/t15.dds',
    currentSha256=sha256(authored_bytes).hexdigest(),nativeSha256=sha256(captured_bytes).hexdigest(),levels=levels)
(out/'native-body-source-comparison.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps([(item['level'],item['blocksExact'],{key:value['exact'] for key,value in item['texels'].items()})
    for item in levels]))
