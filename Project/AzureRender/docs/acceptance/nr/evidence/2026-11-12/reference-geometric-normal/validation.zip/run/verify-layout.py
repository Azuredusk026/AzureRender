from pathlib import Path
import json
import re
import subprocess
import sys


out = Path(__file__).resolve().parent

ninja = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
batch = 'D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'
phase, config = sys.argv[1:]
assert config in ('release','debug')
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if config=='release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
assert phase in ('before','after')
target = 'CMakeFiles/AzureRenderCore.dir/src/assets/GltfLoader.cpp.obj'
command = subprocess.check_output([ninja,'-C',str(build),'-t','commands',target],encoding='utf-8').splitlines()[-1]
assert 'cl.exe ' in command and ' -c ' in command
command = re.sub(r' /F[od]\S+| /showIncludes| /FS','',command).replace(' -c ',' /Zs /d1reportSingleClassLayoutAssetMaterial ')
p = subprocess.run(f'"{batch}" {command}',shell=True,cwd=out,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
log = p.stdout.decode(errors='replace')
(out/f'material-layout-{config}-{phase}.log').write_text(log,encoding='utf-8')
assert p.returncode==0,log
layout = re.search(r'(?m)^class AssetMaterial\s+size\((\d+)\):\s*\n(.*?)(?=\n\s*\+---)',log,re.S)
if not layout:
    layout = re.search(r'(?m)^struct AssetMaterial\s+size\((\d+)\):\s*\n(.*?)(?=\n\s*\+---)',log,re.S)
assert layout,log[:3000]
lines = log[layout.start():].splitlines()
rows = {}
for line in lines[2:]:
    match = re.match(r'^\s*(\d+)\s+\|\s+([^|]*\S)\s*$',line)
    if not line.strip():
        break
    if match:
        rows[match[2].split()[-1]]=int(match[1])
record = dict(size=int(layout[1]),fields=rows)
assert 'sampledReferenceNormal' in rows and 'referenceDepthStencil' in rows and 'baseColorPixels' in rows,record
if phase=='after':
    before=json.loads((out/f'material-layout-{config}-before.json').read_text())
    assert record['size']==before['size']
    assert all(rows[key]==value for key,value in before['fields'].items())
    assert rows['geometricReferenceNormal']==rows['doubleSided']+1
    assert rows['geometricReferenceNormal']<record['size']
(out/f'material-layout-{config}-{phase}.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(size=record['size'],sampled=rows['sampledReferenceNormal'],stencil=rows['referenceDepthStencil'],
    doubleSided=rows['doubleSided'],geometric=rows.get('geometricReferenceNormal'))))