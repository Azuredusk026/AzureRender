from pathlib import Path


out = Path(__file__).resolve().parent
prior = out.parent / '20261112-093321-reference-normal-sampled-rg-ceb2c6/normal-reference-control.py'
text = prior.read_text()
text = text.replace("mode, configuration = sys.argv[1:]",
    "mode, configuration, *device_argument = sys.argv[1:]\ndevice = device_argument[0] if device_argument else 'nvidia'\nassert device in ('nvidia','intel')")
text = text.replace("parent = out / (mode + '-normal-control-' + configuration.lower())",
    "parent = out / (mode + '-geometric-normal-control-' + configuration.lower() + '-' + device)")
text = text.replace("def fixture(folder, requested):", "def fixture(folder, requested, texture):")
text = text.replace("profiles['referenceNormal'] = dict(schemaVersion=2 if requested == 'invalid' else 1, encoding='sampled-rg')",
    "profiles['referenceNormal'] = dict(schemaVersion=1, encoding=requested)")
text = text.replace("    write(folder / 'plane.gltf', model)", "    if not texture:\n        del model['materials'][0]['normalTexture']\n    write(folder / 'plane.gltf', model)")
text = text.replace("def run(label, requested, fixed):","def run(label, requested, fixed, texture=True):")
text = text.replace("fixture(folder, requested)","fixture(folder, requested, texture)")
a = text.index("    if mode == 'red' and requested")
b = text.index("    assert result.returncode == 0",a)
text = text[:a] + """    if (mode == 'red' and requested == 'geometry') or requested == 'invalid':
        assert result.returncode != 0 and 'referenceNormal' in log, log[-7000:]
        if mode == 'red':
            assert 'sampled-rg' in log, log[-7000:]
        return {'exitCode': result.returncode, 'diagnostic': 'referenceNormal'}
""" + text[b:]
a = text.index("rgb = run('default-fixed'")
text = text[:a] + """default = run('default-fixed', None, True)
assert default['code'] == [673,243], default
selected = run('geometric-fixed', 'geometry', True)
result = dict(configuration=configuration,device=device,mode=mode,default=default,selected=selected)
if mode == 'red':
    assert selected['exitCode'] == 1
else:
    assert selected['code'] == [585,804], selected
    result['indexed'] = run('geometric-indexed','geometry',False)
    result['untextured'] = run('geometric-untextured','geometry',True,False)
    assert result['indexed'] == selected == result['untextured']
    result['sampledRg'] = run('sampled-rg','sampled-rg',True)
    assert result['sampledRg']['code'] == [675,777]
    result['invalid'] = run('invalid-encoding','invalid',True)
with (build/'AzurePlayer.exe').open('rb') as stream:
    result['playerSha256'] = file_digest(stream,'sha256').hexdigest()
write(parent/'summary.json',result)
print(json.dumps(result))
"""
text = text.replace('    normals = (0, 0, 1) * 4',
    "    geometric_normal = tuple(value / math.sqrt(21) for value in (1, 2, 4))\n    normals = (geometric_normal if requested == 'geometry' else (0, 0, 1)) * 4")
a = text.index("def oct_encode(")
b = text.index("default = run(",a)
text = text[:a] + text[b:]
compile(text, 'geometric-normal-control.py', 'exec')
(out / 'geometric-normal-control.py').write_text(text, encoding='utf-8')