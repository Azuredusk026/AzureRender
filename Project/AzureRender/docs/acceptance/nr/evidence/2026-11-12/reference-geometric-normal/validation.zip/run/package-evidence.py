from hashlib import sha256
from pathlib import Path
import json
import sys
import zipfile


out = Path(__file__).resolve().parent
engine = out.parents[2]
target = engine/'docs/acceptance/nr/evidence/2026-11-12/reference-geometric-normal'


def load(name):
    return json.loads((out/name).read_text(encoding='utf-8-sig'))


def receipt(label):
    execution=load(label+'-execution.json')
    assert execution['status']=='exited' and execution['exitCode']==0,execution
    return execution


only_release=sys.argv[1:]==['--release-only']
configs=('release',) if only_release else ('release','debug')
labels=[f'{config}-{device}' for config in configs for device in ('nvidia','intel')]
fixture=load('fixture-inputs.json')
assert len(fixture['files'])==45 and fixture['onlyGeometricReferenceNormalChanged']
assert set(fixture['policies'])=={'M_actor_laevat_brow_01','M_actor_laevat_face_01'}
assert all(value==dict(schemaVersion=1,encoding='geometry') for value in fixture['policies'].values())
schema=load('schema-verification.json')
assert schema['schemaSha256']==sha256((engine/'schemas/azure_render_material.schema.json').read_bytes()).hexdigest()
assert len(schema['cases'])==10 and schema['cases']['geometricVersionTwo'] and not schema['cases']['geometricVersionOne']
layout={}
for config in ('release','debug'):
    before,after=[load(f'material-layout-{config}-{phase}.json') for phase in ('before','after')]
    assert before['size']==after['size']
    assert all(after['fields'][key]==value for key,value in before['fields'].items())
    assert set(after['fields'])-set(before['fields'])=={'geometricReferenceNormal'}
    layout[config]=dict(size=after['size'],oldFieldCount=len(before['fields']),newOffset=after['fields']['geometricReferenceNormal'])
assert layout['release']['size']==3720 and layout['debug']['size']==4296
red=load('red-geometric-normal-control-release-nvidia/summary.json')
assert red['default']['code']==[673,243] and red['selected']['exitCode']==1
receipt('red-geometric-normal-control-release')
axis=load('release-nvidia-geometric-normal-axis-tie-execution.json')
assert axis['status']=='exited' and axis['exitCode']==1
assert "[511, 1023]" in (out/'release-nvidia-geometric-normal-axis-tie.log').read_text()
shaders=load('typecheck.json')['shaderPrograms']
controls={label:load(f'green-geometric-normal-control-{label}/summary.json') for label in labels}
builds={name:load(name+'-verification.json') for name in (*configs,*(label+'-gpu' for label in labels))}
build_executions={name:receipt(name) for name in
    tuple(name for config in configs for name in (config+'-build',config+'-cpu-tests'))
    + tuple(name for label in labels for name in (label+'-geometric-normal-control',label+'-gpu-tests',label+'-capture'))}
for name,build in builds.items():
    assert build['shaderCount']==895 and build['ctestExit']==0
    assert {key:change['after'] for key,change in build['changedShaders'].items()}==shaders
    assert build['tests']==(8 if name=='release' else 7 if name=='debug' else 5)
for label,control in controls.items():
    config,_=label.split('-')
    assert control['selected']==control['indexed']==control['untextured']
    assert control['selected']['code']==[585,804]
    assert control['sampledRg']['code']==[675,777]
    assert control['invalid']['exitCode']==1
    assert control['playerSha256']==builds[config]['playerSha256']
captures={label:load(label+'-results.json') for label in labels}
introduced=load('geometric-normal-introduced-attribution.json')
assert (introduced['nvidia']['count'],introduced['intel']['count'])==(10,21)
assert all(row['normalWithinOne']==row['count'] and row['maximum']==17 for row in introduced.values())
for label,capture in captures.items():
    config,device=label.split('-')
    assert capture['playerSha256']==builds[config]['playerSha256']==builds[label+'-gpu']['playerSha256']
    assert all(capture[key] for key in ('depthExact','idsExact','hairVisibilityExact','hairColorExact','validationClean','allocatorZero'))
    assert capture['receiver']['closed']>0 and capture['receiver']['overOne']<capture['receiver']['baselineOverOne']
    assert all(capture['normalSource'][event]['after']['withinOne']>capture['normalSource'][event]['before']['withinOne']
        for event in ('296','345'))
    expected_hair=(0,0) if device=='nvidia' else (208,575)
    assert (capture['hairVisibilityOverOne'],capture['hairColorOverOne'])==expected_hair
    manifest=load(label+'-frames/reference-planes.json')
    assert manifest['reference-object-visibility-rg8.bin']['sha256']==capture['visibilitySha256']
    assert manifest['reference-normals-a2b10g10r10.bin']['sha256']==capture['normalsSha256']
    assert manifest['reference-depth-r32.bin']['sha256']==manifest['reference-depth-d32.bin']['sha256']==capture['referenceDepthSha256']
    assert manifest['reference-object-ids-r8.bin']['sha256']==capture['objectIdsSha256']
if only_release:
    print(json.dumps({label:dict(receiver=capture['receiver'],normals=capture['normalSource']) for label,capture in captures.items()}))
    sys.exit(0)
for device in ('nvidia','intel'):
    release,debug=[captures[config+'-'+device] for config in configs]
    assert all(release[key]==debug[key] for key in release if key not in ('configuration','playerSha256'))
if sys.argv[1:] == ['--before-original']:
    print(json.dumps({label: row['receiver'] for label, row in captures.items()}))
    sys.exit(0)
original=load('default-four-results.json')
assert all(original[key] for key in ('allExact','depthCaptureAbsent','validationClean','allocatorZero'))
assert original['playerSha256']==builds['release']['playerSha256']
assert original['projectSha256']=='13638585d18092a315bd7586a88b349fe256c468eb9090ccb6189232b8209d78'
receipt('original-four')

archive=out/'validation-pending.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as writer:
    def add(path):
        writer.write(path,'run/'+path.relative_to(out).as_posix())

    for path in sorted(out.iterdir()):
        if path.is_file() and (path.suffix in ('.py','.ps1','.json','.xml','.log') or path.name=='implementation-plan.md'):
            add(path)
    for label in labels:
        for name in ('capture_manifest.json','gpu_capabilities.json','reference-planes.json'):
            add(out/(label+'-frames')/name)
    for folder in ('red-geometric-normal-control-release-nvidia',*(f'green-geometric-normal-control-{label}' for label in labels)):
        for path in sorted((out/folder).rglob('*')):
            if path.is_file() and (path.name in ('summary.json','lab.azureproject','level.azurelevel','reference-views.json',
                'plane.gltf','normal.png','player.log','command.json','capture_manifest.json','reference-normals-a2b10g10r10.bin')):
                add(path)
    add(out/'default-four-frames/capture_manifest.json')
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    files={name:sha256(reader.read(name)).hexdigest() for name in reader.namelist()}
assert archive.stat().st_size<=8*1024*1024
result=dict(status='qualified-reference-geometric-normal',overall='failed-user-review',sceneRendererApi=17,
    baseCommit='3b907dca3433d86db4825f02b7612c3657dff04c',acceptedMaximumByteError=1,
    fixture=fixture,schema=schema,layout=layout,red=red,controls=controls,builds=builds,buildExecution=build_executions,
    captures=captures,introducedReceiverSamples=introduced,crossConfigurationExact=True,originalFour=original,
    archive=dict(bytes=archive.stat().st_size,sha256=sha256(archive.read_bytes()).hexdigest(),contents=files))
target.mkdir(parents=True,exist_ok=True)
assert not (target/'validation.zip').exists() and not (target/'results.json').exists()
archive.rename(target/'validation.zip')
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:value for key,value in result['archive'].items() if key!='contents'}))