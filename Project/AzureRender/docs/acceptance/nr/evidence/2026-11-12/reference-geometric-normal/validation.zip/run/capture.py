from hashlib import file_digest, sha256
from pathlib import Path
import json
import re
import runpy
import subprocess
import sys
import zipfile
import zlib

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
config, device = sys.argv[1:]
assert config in ('Release', 'Debug') and device in ('nvidia', 'intel')
label = config.lower() + '-' + device
frames = out / (label + '-frames')
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if config == 'Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
prior = out.parent / '20261112-110307-reference-depth-stencil-coverage-198047'
fixture = out / 'hair-project'
player = build / 'AzurePlayer.exe'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


previous = json.loads((prior / (label + '-results.json')).read_text())
candidate_player = json.loads((out / (config.lower() + '-verification.json')).read_text())['playerSha256']
assert previous['playerSha256'] != candidate_player and digest(player) == candidate_player
for entry in json.loads((out / 'fixture-inputs.json').read_text())['files']:
    path = fixture / entry['relative']
    assert path.stat().st_size == entry['bytes'] and digest(path) == entry['sha256']
command = [str(player), '--project', str(fixture / 'hair-coverage.azureproject'), '--width', '2560', '--height', '1440',
    '--capture-frames', '3', '--capture-dir', str(frames), '--fixed-frame-step', '--qa-camera', 'scene', '--qa-light', 'scene',
    '--qa-isolation', 'beauty', '--disable-compute-skinning', '--disable-bindless', '--resource-root', str(build)]
(out / (label + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
log_path = out / (label + '.log')
with log_path.open('wb') as log:
    execution = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=240)
log = log_path.read_text(errors='replace')
assert execution.returncode == 0 and 'Allocator after unload: buffers=0 images=0' in log, log[-7000:]
assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]', log, re.I), log[-7000:]
assert 'M_actor_laevat_cloth_01, slot=1, bytes=22369620' in log
capture = json.loads((frames / 'capture_manifest.json').read_text())['referenceSceneDepth']
assert (capture['rowOrigin'], capture['normalFrame'], capture['submission'], capture['width'], capture['height']) == (
    'bottom-left', 'reference', 3, 2560, 1440)
keys = ('raster', 'hardware', 'packedNormals', 'objectIds', 'objectVisibility')
planes = {key: (frames / capture[key]).read_bytes() for key in keys}
assert planes['raster'] == planes['hardware']
assert sha256(planes['raster']).hexdigest() == previous['referenceDepthSha256']
assert sha256(planes['objectIds']).hexdigest() == previous['objectIdsSha256']
baseline_manifest = json.loads((prior / (label + '-frames/reference-planes.json')).read_text())
with zipfile.ZipFile(prior / (label + '-frames/reference-planes.zip')) as archive:
    before = {key: archive.read(baseline_manifest[capture[key]]['archiveEntry']) for key in keys}
assert sha256(before['packedNormals']).hexdigest() == previous['normalsSha256']
assert sha256(before['objectVisibility']).hexdigest() == previous['visibilitySha256']

atlas = out.parent / '20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
native = json.loads((atlas / 'native-atlas-producers.json').read_text())
assert native['status'] == 'qualified'
owners = np.zeros((310, 290), dtype='u2')
last = np.zeros((310, 290), dtype='<u4')
for event, stage in native['receiverNormal']['stages'].items():
    entry = stage['crop']
    payload = (atlas / entry['path']).read_bytes()
    assert sha256(payload).hexdigest() == entry['sha256']
    normals = np.frombuffer(zlib.decompress(payload), '<u4').reshape(310, 290)
    owners[normals != last] = int(event)
    last = normals

numeric = out.parent / '20261110-003435-visibility-numeric-contract-4f95e7'
coordinates = np.fromfile(numeric / 'receiver-queries.bin', '<f4').reshape(-1, 4)
x, y = coordinates[:, :2].astype('i4').T
expected = np.fromfile(numeric / 'receiver-expected.bin', '<u4').astype('i4')
assert len(expected) == len(x) == 49384
selected_owners = owners[y - 1000, x - 1140]
assert (selected_owners == 296).sum() == 496 and (selected_owners == 345).sum() == 3825
current_rg8 = np.frombuffer(planes['objectVisibility'], 'u1').reshape(1440, 2560, 2)
previous_rg8 = np.frombuffer(before['objectVisibility'], 'u1').reshape(1440, 2560, 2)
assert np.array_equal(current_rg8[...,0],previous_rg8[...,0])
current = current_rg8[y, x, 1].astype('i4')
baseline = previous_rg8[y, x, 1].astype('i4')
current_normals = np.frombuffer(planes['packedNormals'], '<u4').reshape(1440, 2560)
previous_normals = np.frombuffer(before['packedNormals'], '<u4').reshape(1440, 2560)
normal_changed = current_normals != previous_normals
assert normal_changed.any()


def stats(selection):
    actual = np.abs(current[selection] - expected[selection])
    old = np.abs(baseline[selection] - expected[selection])
    current_errors, old_errors = actual > 1, old > 1
    return dict(pixels=len(actual), overOne=int(current_errors.sum()), baselineOverOne=int(old_errors.sum()),
        closed=int((old_errors & ~current_errors).sum()), introduced=int((current_errors & ~old_errors).sum()),
        maximum=int(actual.max()), changed=int((current[selection] != baseline[selection]).sum()))


hair_source = out.parent / '20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
hair_q = np.fromfile(hair_source / 'queries.bin', '<f4').reshape(-1, 4)
hx, hy = hair_q[:, :2].astype('i4').T
hair_expected = np.fromfile(hair_source / 'expected.bin', '<u4').astype('i4')
assert len(hair_expected) == 17017
hair_errors = np.abs(current_rg8[hy, hx, 1].astype('i4') - hair_expected)
hair_visibility_exact = bool(np.array_equal(current_rg8[hy, hx], previous_rg8[hy, hx]))
color = runpy.run_path(str(out.parent / '20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
bounds = color['x0'], color['y0'], color['x1'], color['y1']
current_color = np.asarray(Image.open(frames / 'frame_000000.png').convert('RGB').crop(bounds))
previous_color = np.asarray(Image.open(prior / (label + '-frames/frame_000000.png')).convert('RGB').crop(bounds))
mask = color['mask']
hair_color_exact = bool(np.array_equal(current_color[mask], previous_color[mask]))
hair_color_errors = np.abs(current_color.astype('i4') - color['expected'])[mask].max(axis=1)
receiver = stats(np.ones(len(x), dtype=bool))
assert receiver['baselineOverOne'] == previous['receiver']['overOne']
groups = {int(event): stats(selected_owners == event) for event in np.unique(selected_owners)}
assert groups[296]['baselineOverOne'] == 30
assert groups[345]['baselineOverOne'] == (130 if device == 'nvidia' else 135)
assert receiver['baselineOverOne'] == (410 if device == 'nvidia' else 742)
targets = last[y-1000,x-1140]
normal_source = {}
for event in (296,345):
    selected = selected_owners==event
    target = targets[selected]
    words = {name:plane[y[selected],x[selected]] for name,plane in
        (('before',previous_normals),('after',current_normals))}
    result = {}
    for name, values in words.items():
        difference = np.stack([np.abs(((values>>shift)&1023).astype('i4')-((target>>shift)&1023).astype('i4'))
            for shift in (0,10)]).max(axis=0)
        result[name] = dict(exact=int((difference==0).sum()),withinOne=int((difference<=1).sum()),
            median=float(np.median(difference)),p95=float(np.quantile(difference,.95)),maximum=int(difference.max()))
    normal_source[event] = result
results = dict(configuration=config,device=device,playerSha256=candidate_player,receiver=receiver,receiverByOwner=groups,
    normalSource=normal_source,normalChangedPixels=int(normal_changed.sum()),depthExact=True,idsExact=True,
    referenceDepthSha256=sha256(planes['raster']).hexdigest(),objectIdsSha256=sha256(planes['objectIds']).hexdigest(),
    hairVisibilityExact=hair_visibility_exact,hairColorExact=hair_color_exact,
    hairVisibilityOverOne=int((hair_errors>1).sum()),hairColorOverOne=int((hair_color_errors>1).sum()),
    validationClean=True,allocatorZero=True,visibilitySha256=sha256(planes['objectVisibility']).hexdigest(),
    normalsSha256=sha256(planes['packedNormals']).hexdigest(),colorSha256=[digest(frames/f'frame_{i:06d}.png') for i in range(3)])
(out/(label+'-results.json')).write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
