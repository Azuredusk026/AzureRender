from pathlib import Path


out=Path(__file__).resolve().parent
prior=out.parent/'20261112-110307-reference-depth-stencil-coverage-198047'
text=(prior/'capture.py').read_text()
text=text.replace("stencil = out.parent / '20261112-105542-native-eyebrow-hair-stencil-8ad501/stencil-replay'\n","")
text=text.replace("prior = out.parent / '20261112-093321-reference-normal-sampled-rg-ceb2c6'", "prior = out.parent / '20261112-110307-reference-depth-stencil-coverage-198047'")
text=text.replace("assert planes['raster'] == planes['hardware']",
    "assert planes['raster'] == planes['hardware']\nassert sha256(planes['raster']).hexdigest() == previous['referenceDepthSha256']\nassert sha256(planes['objectIds']).hexdigest() == previous['objectIdsSha256']")
text=text.replace("assert (selected_owners == 377).sum() == 16629",
    "assert (selected_owners == 296).sum() == 496 and (selected_owners == 345).sum() == 3825")
a=text.index('stencil_result =')
b=text.index('current = current_rg8',a)
text=text[:a]+"assert np.array_equal(current_rg8[...,0],previous_rg8[...,0])\n"+text[b:]
a=text.index("assert groups[296]['baselineOverOne']")
text=text[:a]+"""assert groups[296]['baselineOverOne'] == 30
assert groups[345]['baselineOverOne'] == (130 if device == 'nvidia' else 135)
assert receiver['baselineOverOne'] == (410 if device == 'nvidia' else 742)
targets = last[y-1000,x-1140]
normal_source = {}
for event in (296,345):
    selected = selected_owners==event
    target = targets[selected]
    words = {name:plane[y[selected],x[selected]] for name,plane in
        (('before',previous_normals),('after',current_normals))}
    result = {}
    for name, values in words.items():
        difference = np.stack([np.abs(((values>>shift)&1023).astype('i4')-((target>>shift)&1023).astype('i4'))
            for shift in (0,10)]).max(axis=0)
        result[name] = dict(exact=int((difference==0).sum()),withinOne=int((difference<=1).sum()),
            median=float(np.median(difference)),p95=float(np.quantile(difference,.95)),maximum=int(difference.max()))
    normal_source[event] = result
results = dict(configuration=config,device=device,playerSha256=candidate_player,receiver=receiver,receiverByOwner=groups,
    normalSource=normal_source,normalChangedPixels=int(normal_changed.sum()),depthExact=True,idsExact=True,
    referenceDepthSha256=sha256(planes['raster']).hexdigest(),objectIdsSha256=sha256(planes['objectIds']).hexdigest(),
    hairVisibilityExact=hair_visibility_exact,hairColorExact=hair_color_exact,
    hairVisibilityOverOne=int((hair_errors>1).sum()),hairColorOverOne=int((hair_color_errors>1).sum()),
    validationClean=True,allocatorZero=True,visibilitySha256=sha256(planes['objectVisibility']).hexdigest(),
    normalsSha256=sha256(planes['packedNormals']).hexdigest(),colorSha256=[digest(frames/f'frame_{i:06d}.png') for i in range(3)])
(out/(label+'-results.json')).write_text(json.dumps(results,indent=2)+'\\n')
print(json.dumps(results))
"""
compile(text,'capture.py','exec')
(out/'capture.py').write_text(text,encoding='utf-8')