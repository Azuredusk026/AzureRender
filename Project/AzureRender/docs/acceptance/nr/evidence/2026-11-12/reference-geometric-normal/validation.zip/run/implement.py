from pathlib import Path


root=Path(__file__).resolve().parents[3]
assert root==Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender')
updated={}


def replace(path,old,new):
    source=root/path
    raw=source.read_bytes()
    sep='\r\n' if b'\r\n' in raw else '\n'
    data=raw.decode().replace('\r\n','\n')
    assert data.count(old)==1,path
    updated[source]=data.replace(old,new).replace('\n',sep).encode()


replace('src/assets/GltfLoader.hpp','''    bool doubleSided = false;
};''','''    bool doubleSided = false;
    bool geometricReferenceNormal = false;
};''')
replace('src/assets/GltfLoader.cpp','''                if(profile.at("schemaVersion")!=2||!value.is_object()||value.size()!=2
                    ||!value.contains("schemaVersion")||!value.at("schemaVersion").is_number_integer()||value.at("schemaVersion")!=1
                    ||!value.contains("encoding")||value.at("encoding")!="sampled-rg")
                    throw std::invalid_argument(context+": referenceNormal requires schemaVersion one, sampled-rg and profile version two");
                if(material.normalTexture.index<0)
                    throw std::invalid_argument(context+": referenceNormal requires a standard normal texture");
                result.sampledReferenceNormal=true;
''','''                if (profile.at("schemaVersion") != 2 || !value.is_object() || value.size() != 2
                    || !value.contains("schemaVersion") || !value.at("schemaVersion").is_number_integer()
                    || value.at("schemaVersion") != 1 || !value.contains("encoding")
                    || (value.at("encoding") != "sampled-rg" && value.at("encoding") != "geometry"))
                    throw std::invalid_argument(context + ": referenceNormal requires schemaVersion one, sampled-rg or geometry, and profile version two");
                result.sampledReferenceNormal = value.at("encoding") == "sampled-rg";
                result.geometricReferenceNormal = value.at("encoding") == "geometry";
                if (result.sampledReferenceNormal && material.normalTexture.index < 0)
                    throw std::invalid_argument(context + ": sampled-rg referenceNormal requires a standard normal texture");
''')
replace('src/assets/MaterialData.cpp',
    '        lost(source.sampledReferenceNormal&&!replacement.sampledReferenceNormal,"referenceNormal");',
    '''        lost((source.sampledReferenceNormal && !replacement.sampledReferenceNormal)
            || (source.geometricReferenceNormal && !replacement.geometricReferenceNormal), "referenceNormal");''')
replace('src/scenes/CharacterSceneRenderer.cpp','''                const float hairNormalMode=hair.present?(hair.materialSnapshotNormal?2.F:1.F):0.F;
                const float normalMode=m.sampledReferenceNormal?3.F:hairNormalMode;
''','''                float normalMode=hair.present?(hair.materialSnapshotNormal?2.F:1.F):0.F;
                if (m.sampledReferenceNormal) normalMode = 3.F;
                if (m.geometricReferenceNormal) normalMode = 4.F;
''')
replace('shaders/reference_scene_depth.frag','''    float mode=material.normalControl.x;
    if(mode==3.0){''','''    float mode=material.normalControl.x;
    if (mode == 4.0)
        return characterProjectedSafeNormalize(worldNormal, vec3(0, 0, 1)) * facing;
    if(mode==3.0){''')
replace('schemas/azure_render_material.schema.json','''        "encoding": {
          "type": "string",
          "const": "sampled-rg"
        }''','''        "encoding": {
          "type": "string",
          "enum": ["sampled-rg", "geometry"]
        }''')
for path,data in updated.items():
    path.write_bytes(data)
print('\n'.join(path.relative_to(root).as_posix() for path in updated))