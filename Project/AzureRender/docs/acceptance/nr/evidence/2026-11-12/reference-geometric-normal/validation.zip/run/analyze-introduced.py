from hashlib import sha256
from pathlib import Path
import json
import zipfile
import zlib

import numpy as np


out=Path(__file__).resolve().parent
base=out.parent/'20261112-110307-reference-depth-stencil-coverage-198047'
native=out.parent/'20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry'
atlas=out.parent/'20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
numeric=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'


def crop(root,entry):
    data=(root/entry['path']).read_bytes()
    assert sha256(data).hexdigest()==entry['sha256']
    raw=zlib.decompress(data)
    if 'rawSha256' in entry:
        assert sha256(raw).hexdigest()==entry['rawSha256']
    return np.frombuffer(raw,'<u4').reshape(310,290)


stages=json.loads((atlas/'native-atlas-producers.json').read_text())['receiverNormal']['stages']
native_normal=np.zeros((310,290),'<u4')
owner=np.zeros((310,290),dtype='i4')
for event,stage in stages.items():
    value=crop(atlas,stage['crop'])
    owner[value!=native_normal]=int(event)
    native_normal=value
depth_entry=json.loads((native/'native-caster-geometry.json').read_text())['receiverDepth']['699']['crop']
native_depth=crop(native,depth_entry)
x,y=np.fromfile(numeric/'receiver-queries.bin','<f4').reshape(-1,4)[:,:2].astype('i4').T
expected=np.fromfile(numeric/'receiver-expected.bin','<u4').astype('i4')
assert len(x)==len(expected)==49384
coordinates=y-1000,x-1140
native_normal=native_normal[coordinates]
native_depth=native_depth[coordinates]
owner=owner[coordinates]


def capture(root,label):
    folder=root/(label+'-frames')
    manifest=json.loads((folder/'reference-planes.json').read_text())
    names=('reference-depth-r32.bin','reference-normals-a2b10g10r10.bin','reference-object-visibility-rg8.bin')
    with zipfile.ZipFile(folder/'reference-planes.zip') as archive:
        entries=[archive.read(manifest[name]['archiveEntry']) for name in names]
    assert all(sha256(raw).hexdigest()==manifest[name]['sha256'] for name,raw in zip(names,entries))
    return (np.frombuffer(entries[0],'<u4').reshape(1440,2560)[y,x],
        np.frombuffer(entries[1],'<u4').reshape(1440,2560)[y,x],
        np.frombuffer(entries[2],'u1').reshape(1440,2560,2)[y,x,1].astype('i4'))


def normal_error(packed):
    return np.stack([np.abs(((packed>>shift)&1023).astype('i4')-((native_normal>>shift)&1023).astype('i4'))
        for shift in (0,10)]).max(axis=0)


report={}
for device in ('nvidia','intel'):
    label='release-'+device
    prior_depth,prior_normal,prior_result=capture(base,label)
    depth,normal,result=capture(out,label)
    assert np.array_equal(prior_depth,depth)
    changed=result!=prior_result
    assert set(owner[changed])=={296,345}
    mask=(np.abs(prior_result-expected)<=1)&(np.abs(result-expected)>1)
    assert int(mask.sum())==(10 if device=='nvidia' else 21)
    before_normal,after_normal=normal_error(prior_normal),normal_error(normal)
    depth_ulp=np.abs(depth.astype('i8')-native_depth)
    report[device]=dict(count=int(mask.sum()),normalExact=int((mask&(after_normal==0)).sum()),
        normalWithinOne=int((mask&(after_normal<=1)).sum()),normalCloser=int((mask&(after_normal<before_normal)).sum()),
        depthExact=int((mask&(depth_ulp==0)).sum()),depthWithinOne=int((mask&(depth_ulp<=1)).sum()),
        bothExact=int((mask&(depth_ulp==0)&(after_normal==0)).sum()),
        bothWithinOne=int((mask&(depth_ulp<=1)&(after_normal<=1)).sum()),
        maximum=int(np.max(np.abs(result-expected)[mask])),
        samples=[dict(pixel=[int(x[i]),int(y[i])],event=int(owner[i]),frozen=int(expected[i]),
            before=int(prior_result[i]),after=int(result[i]),depthUlp=int(depth_ulp[i]),
            normalBefore=int(before_normal[i]),normalAfter=int(after_normal[i]))
            for i in np.flatnonzero(mask)])
(out/'geometric-normal-introduced-attribution.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({device:{k:v for k,v in row.items() if k!='samples'} for device,row in report.items()}))