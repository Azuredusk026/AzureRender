from hashlib import sha256
from pathlib import Path
import json
import zlib

import numpy as np


out = Path(__file__).resolve().parent
native = out.parent / '20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
numerics = out.parent / '20261112-053111-intel-reference-visibility-sources-5238e2/live-numerics'
receiver = out.parent / '20261110-003435-visibility-numeric-contract-4f95e7'
hair = out.parent / '20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
capture = json.loads((native / 'native-atlas-producers.json').read_text())
assert capture['status'] == 'qualified' and capture['receiverNormal']['resource'] == 'ResourceId::141952'
shape = (310, 290)
previous = np.zeros(shape, dtype='<u4')
owner = np.zeros(shape, dtype='u2')
for event, source in capture['receiverNormal']['stages'].items():
    entry = source['crop']
    data = (native / entry['path']).read_bytes()
    assert len(data) == entry['bytes'] and sha256(data).hexdigest() == entry['sha256']
    current = np.frombuffer(zlib.decompress(data), '<u4').reshape(shape)
    owner[previous != current] = int(event)
    previous = current
assert not (owner == 699).any()
query = np.fromfile(receiver / 'receiver-queries.bin', '<f4').reshape(-1, 4)
x, y = query[:, :2].astype('i4').T
events = owner[y - 1000, x - 1140]
hair_query = np.fromfile(hair / 'queries.bin', '<f4').reshape(-1, 4)
hx, hy = hair_query[:, :2].astype('i4').T
in_hair = np.isin(y * 2560 + x, hy * 2560 + hx)
expected = np.fromfile(receiver / 'receiver-expected.bin', '<u4').astype('i4')
assert len(expected) == 49384 and in_hair.sum() == 17017
reference = json.loads((numerics / 'results.json').read_text())
live_normals = np.fromfile(numerics / 'normals.bin', '<u4').reshape(1440, 2560)[y, x]
native_normals = previous[y - 1000, x - 1140]
live_depth = np.fromfile(numerics / 'depth.bin', '<f4').reshape(1440, 2560)[y, x]
native_r32 = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/native-t0.bin')
depth_data = native_r32.read_bytes()
assert sha256(depth_data).hexdigest() == '02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb'
native_depth = np.frombuffer(depth_data, '<f4').reshape(1440, 2560)[y, x]
normal_error = np.max([np.abs(((live_normals >> shift) & 1023).astype('i4') - ((native_normals >> shift) & 1023).astype('i4'))
    for shift in (0, 10)], axis=0)
depth_ulp = np.abs(live_depth.view('<u4').astype('i8') - native_depth.view('<u4').astype('i8'))
cases = ('intel-device', 'intel-profile', 'intel-native-atlas', 'intel-native-depth', 'intel-native-normal', 'intel-native-all')
failure = {}
values = {}
for case in cases:
    error = np.abs(np.fromfile(numerics / case / 'receiver-selected.bin', 'u1').astype('i4') - expected)
    failure[case] = error > 1
    assert int(failure[case].sum()) == reference[case]['receiver']['overOne']
    values[case] = error
initial = failure['intel-profile']
report = {}


def distribution(values):
    return dict(exact=int((values == 0).sum()), withinOne=int((values <= 1).sum()),
        quantiles=np.quantile(values, [0, .25, .5, .75, .9, .99, 1]).tolist())


for event in np.unique(events):
    region = events == event
    items = {}
    for case in cases:
        failed = failure[case]
        items[case] = dict(overOne=int((failed & region).sum()), closed=int((initial & ~failed & region).sum()),
            added=int((~initial & failed & region).sum()), maximum=int(values[case][region].max()))
    residual = region & initial
    report[int(event)] = dict(samples=int(region.sum()), hair=int((region & in_hair).sum()),
        profileOutsideHair=int((region & initial & ~in_hair).sum()), profileOver64=int((region & (values['intel-profile'] > 64)).sum()),
        inputs=dict(depthAll=distribution(depth_ulp[region]), depthResidual=distribution(depth_ulp[residual]),
            normalAll=distribution(normal_error[region]), normalResidual=distribution(normal_error[residual])),
        cases=items)
(out / 'profile-receiver-attribution.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({event: dict(count=row['samples'], hair=row['hair'], profile=row['cases']['intel-profile']['overOne'],
    depth=row['cases']['intel-native-depth']['overOne'], normals=row['cases']['intel-native-normal']['overOne'],
    atlas=row['cases']['intel-native-atlas']['overOne'], over64=row['profileOver64']) for event, row in report.items()}))
