from pathlib import Path
import json
import os
import subprocess
import sys


out = Path(__file__).resolve().parent
engine = out.parents[2]
main = Path('D:/Projects/FYP/Project/AzureRender')
phase = sys.argv[1]
editor = len(sys.argv) > 2 and sys.argv[2] == 'editor'
assert phase in ('red', 'green')
sources = ['tests/EditorProjectFlowTests.cpp' if editor else 'tests/ProjectReferenceViewsTests.cpp']
if phase == 'green':
    sources.append('src/editor/EditorSession.cpp' if editor else 'src/runtime/ProjectReferenceViews.cpp')
args = [str(main / 'tools/msvc_env.bat'), 'cl', '/nologo', '/Zs', '/std:c++17', '/EHsc', '/utf-8',
    '/I' + str(engine / 'src'), '/ID:/Tools/VulkanSDK/1.4.350.0/Include',
    '/I' + str(main / 'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'),
    *[str(engine / source) for source in sources]]
env = os.environ.copy()
for name in ('TMP', 'TEMP', 'TMPDIR'):
    env[name] = str(out / 'tmp')
process = subprocess.run(subprocess.list2cmdline(args), shell=True, cwd=out, env=env,
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
prefix = phase + ('-editor' if editor else '')
(out / (prefix + '-typecheck.log')).write_bytes(process.stdout)
message = process.stdout.decode(errors='replace')
print(message)
if phase == 'red':
    assert process.returncode and 'C2039' in message and ('referenceViews' if editor else 'objectVisibilityProfile') in message, message
else:
    assert process.returncode == 0, message
(out / (prefix + '-typecheck.json')).write_text(json.dumps(dict(returnCode=process.returncode, command=args), indent=2) + '\n')
