from pathlib import Path
import json
import os
import subprocess
import sys


out = Path(__file__).resolve().parent
build = out.parents[1]
main = Path('D:/Projects/FYP/Project/AzureRender/build')
owner = '01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0, str(main.parent / 'tools'))
import shared_resources as shared

claim_path = Path('D:/Projects/FYP-coordination/quality-claim.json')
claim = json.loads(claim_path.read_text(encoding='utf-8'))
assert claim['threadId'] == owner and claim['state'] == 'intel-reference-visibility-sources'
assert claim['lastCommit'] == 'fa82f57758691e0ebd4ca43496cffd9490ab3f13'
source = subprocess.check_output(['git', 'log', '-1', '--format=%H%n%P%n%s'], cwd=build.parent, encoding='utf-8').splitlines()
assert source[0] == '3dc8cce41e9b632386ffdf2be47d4234fa8ccbd0' and source[1] == claim['lastCommit']
old_local, old_main = claim['localInputLease'], claim['inputLease']


def inherited(root, tokens):
    with shared.maintenance.database(root, True) as db:
        records = shared.maintenance.rows(db)
    assert all(records[token]['owner'] == owner for token in tokens)
    return list(dict.fromkeys(name for token in tokens for name in records[token]['inputs']))


local_inputs = inherited(build, old_local)
local_inputs.append('20261112-053111-intel-reference-visibility-sources-5238e2')
main_inputs = inherited(main, old_main)
local = shared.acquire_inputs(build, out, local_inputs, owner)
try:
    native = shared.acquire_inputs(main, out, main_inputs, owner)
except Exception:
    shared.release_inputs(build, local, owner)
    raise
claim.update(state='project-reference-visibility-profile-red', taskPath=str(out), inputLease=[native], localInputLease=[local],
    nativeCaptureLease=native, lastCommit=source[0], pendingCommand='Add typed project configuration for the qualified ProfileV1 arithmetic and verify the actual Player on both devices',
    ownedFiles=['src/runtime/ProjectReferenceViews.*','src/app/AzureRenderApp.*','src/render/RenderContext.hpp',
        'src/render/ScreenObjectVisibility*','src/scenes/CharacterSceneRenderer.*','src/extensions/ISceneRenderer.hpp',
        'tests/ProjectReferenceViewsTests.cpp','tests/ExtensionRegistryTests.cpp'], additionalTaskPaths=[])
claim['observed'].update(intelAtlasHigherOne=6075, profileSameInputsDeviceHairOverOne=63, profileSameInputsDeviceReceiverOverOne=202,
    profileSameInputsReferenceOverOne=0, intelProfileActualInputsHairOverOne=208, intelProfileActualInputsReceiverOverOne=2981,
    nativeDifferentMipsIntelOneLower=843, nativeExplicitNormalAtNvidiaLevelOverOne=6)
(out / 'task-card.json').write_text(json.dumps(dict(local=local, main=native, sourceBase=source[0],
    plannedBytes=536870912, localInputs=local_inputs, mainInputs=main_inputs), indent=2) + '\n')
temporary = claim_path.with_name(claim_path.name + '.nr-quality-new')
with temporary.open('x', encoding='utf-8') as stream:
    json.dump(claim, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
os.replace(temporary, claim_path)
for token in old_main:
    shared.release_inputs(main, token, owner)
for token in old_local:
    shared.release_inputs(build, token, owner)
print(json.dumps(dict(local=local, main=native, output=str(out))))
