from pathlib import Path
import json


out=Path(__file__).resolve().parent
fields=('visibilitySha256','referenceDepthSha256','referenceNormalsSha256','objectIdsSha256','colors','colorHair','colorHairBaseline','hair','receiver')
results={}
for device in ('nvidia','intel'):
    release,debug=[json.loads((out/(configuration+'-'+device+'-results.json')).read_text()) for configuration in ('release','debug')]
    exact={field:release[field]==debug[field] for field in fields}
    assert all(exact.values()),(device,exact)
    assert all(case['validationClean'] and case['allocatorZero'] for case in (release,debug))
    results[device]=exact
(out/'cross-configuration.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
