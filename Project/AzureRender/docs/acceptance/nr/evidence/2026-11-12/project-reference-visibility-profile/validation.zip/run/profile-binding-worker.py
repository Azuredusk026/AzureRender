from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import sys
import traceback

import renderdoc as rd


job = json.loads(Path(os.environ['AZURE_PROJECT_PROFILE_CAPTURE']).read_text())
output = Path(job['output'])
sys.path.insert(0, job['nativeRenderTools'])
from renderdoc_capture import fingerprint
from renderdoc_worker import capture_target


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


report = {'status': 'failed', 'captureReceipt': {'artifacts': []}}
capture = None
controller = None
try:
    if 'captureReceipt' in job:
        report['captureReceipt'] = job['captureReceipt']
    else:
        layer = {'VK_LAYER_PATH': job['layerPath'], 'VK_INSTANCE_LAYERS': 'VK_LAYER_RENDERDOC_Capture',
            'ENABLE_VULKAN_RENDERDOC_CAPTURE': '1'}
        os.environ.update(layer)
        try:
            capture_target(rd, job, report['captureReceipt'])
        finally:
            for key in layer:
                os.environ.pop(key, None)
    receipt = report['captureReceipt']
    assert receipt['status'] == 'captured' and 'Vulkan' in receipt['api'] and receipt['capture_frame'] == job['frame']
    assert fingerprint(receipt['capture']['path']) == receipt['capture']
    capture = rd.OpenCaptureFile()
    assert capture.OpenFile(receipt['capture']['path'], '', None) == rd.ResultCode.Succeeded
    gpu, = [item for item in capture.GetAvailableGPUs() if item.vendor == rd.GPUVendor.nVidia and rd.GraphicsAPI.Vulkan in item.apis]
    options = rd.ReplayOptions()
    options.forceGPUVendor = gpu.vendor
    options.forceGPUDeviceID = gpu.deviceID
    status, controller = capture.OpenCapture(options, None)
    assert status == rd.ResultCode.Succeeded and controller
    properties = controller.GetAPIProperties()
    assert properties.pipelineType == rd.GraphicsAPI.Vulkan and properties.vendor == gpu.vendor and not properties.degraded
    matches = []
    for action in walk(controller.GetRootActions()):
        if not action.flags & rd.ActionFlags.Drawcall or action.numIndices != 3:
            continue
        controller.SetFrameEvent(action.eventId, True)
        pipe = controller.GetPipelineState()
        shader = pipe.GetShaderReflection(rd.ShaderStage.Pixel)
        if shader and sha256(bytes(shader.rawBytes)).hexdigest() == job['shaderSha256']:
            matches.append(action.eventId)
    event, = matches
    controller.SetFrameEvent(event, True)
    pipe = controller.GetPipelineState()
    shader = pipe.GetShaderReflection(rd.ShaderStage.Pixel)
    report.update(device=gpu.name, event=event, shaderSha256=job['shaderSha256'])
    slots = {}
    for resources, descriptors in ((shader.readOnlyResources, pipe.GetReadOnlyResources(rd.ShaderStage.Pixel)),
            (shader.readWriteResources, pipe.GetReadWriteResources(rd.ShaderStage.Pixel))):
        for binding in descriptors:
            entry = resources[binding.access.index]
            if entry.fixedBindSetOrSpace == 0:
                slots[entry.fixedBindNumber] = binding.descriptor
    resource = slots[5]
    assert resource.resource != rd.ResourceId.Null() and resource.byteSize == 2097152
    payload = bytes(controller.GetBufferData(resource.resource, resource.byteOffset, resource.byteSize))
    assert len(payload) == 2097152 and sha256(payload).hexdigest() == job['profileSha256']
    uniform_index, = [index for index, block in enumerate(shader.constantBlocks) if block.bufferBacked
        and block.fixedBindSetOrSpace == 0 and block.fixedBindNumber == 0]
    uniform = pipe.GetConstantBlock(rd.ShaderStage.Pixel, uniform_index, 0).descriptor
    parameters = bytes(controller.GetBufferData(uniform.resource, uniform.byteOffset, 992))
    assert len(parameters) == 992
    controls = struct.unpack_from('<4I', parameters, 80)
    assert controls[1] == 3, controls
    report['profile'] = dict(set=0, binding=5, resource=str(resource.resource), offset=resource.byteOffset,
        bytes=len(payload), sha256=sha256(payload).hexdigest())
    report['uniform'] = dict(bytes=len(parameters), sha256=sha256(parameters).hexdigest(), control=controls)
    report['debugMessages'] = [str(message.description) for message in controller.GetDebugMessages()]
    assert not report['debugMessages'], report['debugMessages']
    report['status'] = 'qualified'
except BaseException:
    report['error'] = traceback.format_exc()
finally:
    if controller:
        controller.Shutdown()
    if capture:
        capture.Shutdown()
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
os._exit(0 if report['status'] == 'qualified' else 1)
