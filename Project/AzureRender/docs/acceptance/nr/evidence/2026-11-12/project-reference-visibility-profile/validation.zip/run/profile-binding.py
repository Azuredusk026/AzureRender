from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys


out = Path(__file__).resolve().parent
engine = out.parents[2]
sys.path.insert(0, str(engine / 'tools/native_render'))
from renderdoc_capture import fingerprint


prior = out.parent / '20261112-044926-material-reference-object-visibility-344def/green-release-fixed'
folder = out / 'profile-binding'
fixture = folder / 'fixture'
profile = fixture / 'config/object-visibility-profile-v1.bin'
replay_only = '--replay-only' in sys.argv
if not replay_only:
    fixture.mkdir(parents=True)
    for name in ('plane.gltf', 'lab.azureproject', 'objects.azurelevel'):
        shutil.copyfile(prior / name, fixture / ('level.azurelevel' if name == 'objects.azurelevel' else name))
    (fixture / 'config').mkdir()
    config = json.loads((prior / 'config/reference-views.json').read_text())
    config['objectVisibilityArithmetic'] = 'profile-v1'
    (fixture / 'config/reference-views.json').write_text(json.dumps(config, indent=2) + '\n')
    shutil.copyfile(out / 'hair-project/config/object-visibility-profile-v1.bin', profile)
profile_hash = sha256(profile.read_bytes()).hexdigest()
assert profile_hash == 'bbda0d685ab5a66767c2c3881a67dff147e1f5a2c766db1f6dd5b63fecedcf2c'
argv = json.loads((prior / 'objects-command.json').read_text())
player = Path(argv[0])
identity = fingerprint(player)
assert identity['sha256'] == json.loads((out / 'release-verification.json').read_text())['playerSha256']
argv[argv.index('--project') + 1] = str(fixture / 'lab.azureproject')
argv[argv.index('--capture-dir') + 1] = str(folder / 'frames')
argv[argv.index('--capture-frames') + 1] = '4'
shader = player.parent / 'shaders/screen_object_visibility.frag.spv'
job = dict(operation='capture', source=identity, working_directory=str(player.parent), arguments=argv[1:],
    output=str(folder), frame=3, timeout=220, nativeRenderTools=str(engine / 'tools/native_render'),
    shaderSha256=sha256(shader.read_bytes()).hexdigest(), profileSha256=profile_hash,
    layerPath='D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64;D:/Tools/VulkanSDK/1.4.350.0/Bin')
if replay_only:
    report_path = folder / 'first-report.json'
    if not report_path.exists():
        shutil.copyfile(folder / 'report.json', report_path)
        shutil.copyfile(folder / 'renderdoc.log', folder / 'first-renderdoc.log')
    job['captureReceipt'] = json.loads(report_path.read_text())['captureReceipt']
    assert fingerprint(job['captureReceipt']['capture']['path']) == job['captureReceipt']['capture']
request = folder / 'request.json'
request.write_text(json.dumps(job, indent=2) + '\n')
environment = os.environ.copy()
for key in ('VK_LAYER_PATH', 'VK_INSTANCE_LAYERS', 'VK_LAYER_ENABLES', 'VK_DRIVER_FILES', 'VK_ICD_FILENAMES'):
    environment.pop(key, None)
environment.update(AZURE_PROJECT_PROFILE_CAPTURE=str(request), VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
command = ['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe', '--python', str(out / 'profile-binding-worker.py')]
(folder / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (folder / 'renderdoc.log').open('wb') as log:
    result = subprocess.run(command, env=environment, cwd=folder, startupinfo=startup,
        stdout=log, stderr=subprocess.STDOUT, timeout=320)
report = json.loads((folder / 'report.json').read_text())
assert result.returncode == 0 and report['status'] == 'qualified', report
assert fingerprint(player) == identity
print(json.dumps(report))
