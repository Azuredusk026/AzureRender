from hashlib import file_digest
from pathlib import Path
import json
import re
import shutil
import subprocess
import sys
import tempfile


out = Path(__file__).resolve().parent
root = out.parents[2]
release = out.parent / '20261110-030251-hair-main-chroma-public-9e799c/release'
cmake = Path('D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe')
sys.path.insert(0, str(root / 'tools'))
import build_game


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def run(command, log_name):
    with (out / log_name).open('wb') as log:
        result = subprocess.run(command, cwd=out, stdout=log, stderr=subprocess.STDOUT, timeout=160)
    assert result.returncode == 0, (out / log_name).read_text(errors='replace')[-4000:]


def prepare_runtime_install(directory):
    generated = release / 'cmake_install.cmake'
    statements = re.findall(r'(?m)^(  file\(INSTALL DESTINATION "\$\{CMAKE_INSTALL_PREFIX\}/([^"]+)"[^\n]*(?:\n    [^\n]*)*)',
        generated.read_text(encoding='utf-8'))
    selected = []
    for statement, destination in statements:
        if destination in ('share/AzureRender/shaders', 'share/AzureRender/assets_public', 'share/AzureRender/licenses'):
            selected.append(statement)
        elif destination == 'bin' and ('.dll"' in statement or '/AzurePlayer.exe"' in statement or '/AzureGameLauncher.exe"' in statement):
            selected.append(statement)
        elif 'RENAME "runtime-build.json"' in statement or '/tools/build_game.py"' in statement:
            selected.append(statement)
    install_script = out / 'package-runtime-install.cmake'
    assert len(selected) >= len(build_game.REQUIRED_LICENSES) + 8
    install_script.write_text('\n'.join(selected) + '\n', encoding='utf-8')
    run([str(cmake), '-DCMAKE_INSTALL_PREFIX=' + directory.as_posix(), '-P', str(install_script)], 'package-install.log')
    return dict(source=digest(generated), runtimeRecipe=digest(install_script), statements=len(selected))


stage_temp = (out / 'tmp').resolve(strict=True)
assert stage_temp.parent == out and not stage_temp.is_symlink()
with tempfile.TemporaryDirectory(dir=stage_temp, prefix='profile-package-') as folder:
    temporary = Path(folder).resolve(strict=True)
    assert temporary.parent == stage_temp
    install, project, published = (temporary / part for part in ('install', 'project', 'published'))
    fixture = out / 'cli-project'
    (project / 'assets').mkdir(parents=True)
    for name in ('plane.gltf', 'level.azurelevel'):
        shutil.copyfile(fixture / name, project / 'assets' / name)
    shutil.copytree(fixture / 'config', project / 'config')
    descriptor = json.loads((fixture / 'lab.azureproject').read_text())
    descriptor['mounts'][0]['path'] = 'assets'
    entry = project / 'lab.azureproject'
    entry.write_text(json.dumps(descriptor, indent=2) + '\n')
    install_receipt = prepare_runtime_install(install)
    player = install / 'bin/AzurePlayer.exe'
    expected = json.loads((out / 'release-verification.json').read_text())['playerSha256']
    assert digest(player) == expected
    builder = install / 'share/AzureRender/tools/build_game.py'
    assert digest(builder) == digest(root / 'tools/build_game.py')
    run([sys.executable, str(builder), '--project', str(entry), '--install', str(install),
        '--output', str(published), '--validation-timeout', '45'], 'package-build.log')
    moved = temporary / 'Moved game'
    published.rename(moved)
    project.rename(temporary / 'Source unavailable')
    install.rename(temporary / 'Install unavailable')
    manifest = build_game.verify_package(moved)
    records = {item['path']: item for item in manifest['files']}
    selected = {name: records['game/config/' + name] for name in ('reference-views.json', 'object-visibility-profile-v1.bin')}
    assert selected['reference-views.json']['sha256'] == digest(fixture / 'config/reference-views.json')
    assert selected['object-visibility-profile-v1.bin']['sha256'] == digest(fixture / 'config/object-visibility-profile-v1.bin')
    assert digest(moved / 'bin/AzurePlayer.exe') == expected
    run([str(moved / 'bin/AzurePlayer.exe'), '--project', str(moved / 'game/project.azureproject'),
        '--check-project'], 'package-moved-player.log')
    assert 'Project validation passed' in (out / 'package-moved-player.log').read_text(errors='replace')
    report = dict(playerSha256=expected, builderSha256=digest(root / 'tools/build_game.py'), installation=install_receipt,
        packageFiles=len(records), configuration=selected, sourceUnavailable=True, installUnavailable=True, movedCheck=True)
(out / 'package-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
