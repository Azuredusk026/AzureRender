  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE EXECUTABLE FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-030251-hair-main-chroma-public-9e799c/release/AzurePlayer.exe")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE FILE FILES
    "D:/Tools/VS2022BuildTools/VC/Redist/MSVC/14.44.35112/x64/Microsoft.VC143.CRT/concrt140.dll"
    "D:/Tools/VS2022BuildTools/VC/Redist/MSVC/14.44.35112/x64/Microsoft.VC143.CRT/msvcp140.dll"
    "D:/Tools/VS2022BuildTools/VC/Redist/MSVC/14.44.35112/x64/Microsoft.VC143.CRT/msvcp140_1.dll"
    "D:/Tools/VS2022BuildTools/VC/Redist/MSVC/14.44.35112/x64/Microsoft.VC143.CRT/msvcp140_2.dll"
    "D:/Tools/VS2022BuildTools/VC/Redist/MSVC/14.44.35112/x64/Microsoft.VC143.CRT/msvcp140_atomic_wait.dll"
    "D:/Tools/VS2022BuildTools/VC/Redist/MSVC/14.44.35112/x64/Microsoft.VC143.CRT/msvcp140_codecvt_ids.dll"
    "D:/Tools/VS2022BuildTools/VC/Redist/MSVC/14.44.35112/x64/Microsoft.VC143.CRT/vccorlib140.dll"
    "D:/Tools/VS2022BuildTools/VC/Redist/MSVC/14.44.35112/x64/Microsoft.VC143.CRT/vcruntime140.dll"
    "D:/Tools/VS2022BuildTools/VC/Redist/MSVC/14.44.35112/x64/Microsoft.VC143.CRT/vcruntime140_1.dll"
    "D:/Tools/VS2022BuildTools/VC/Redist/MSVC/14.44.35112/x64/Microsoft.VC143.CRT/vcruntime140_threads.dll"
    )
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/shaders" TYPE DIRECTORY FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-030251-hair-main-chroma-public-9e799c/release/shaders/" FILES_MATCHING REGEX "/[^/]*\\.spv$")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/assets_public" TYPE DIRECTORY FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/assets_public/" REGEX "/\\.azure$" EXCLUDE REGEX "/[^/]*\\.tmp$" EXCLUDE)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "imgui-LICENSE.txt" FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/third_party/imgui/LICENSE.txt")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "opus-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/opus/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "opusfile-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/opusfile/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "directxtex-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/directxtex/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "directxmath-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/directxmath/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "ktx-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/ktx/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "zstd-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/zstd/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "egl-registry-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/egl-registry/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "opengl-registry-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/opengl-registry/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "libvorbis-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/libvorbis/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "libogg-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/libogg/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "libflac-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/libflac/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "mp3lame-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/mp3lame/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "tiff-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/tiff/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "libwebp-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/libwebp/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "libjpeg-turbo-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/libjpeg-turbo/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "liblzma-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/liblzma/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "assimp-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/assimp/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "jhasse-poly2tri-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/jhasse-poly2tri/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "kubazip-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/kubazip/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "minizip-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/minizip/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "pugixml-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/pugixml/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "rapidjson-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/rapidjson/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "utfcpp-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/utfcpp/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "glfw3-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/glfw3/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "tinygltf-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/tinygltf/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "stb-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/stb/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "openexr-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/openexr/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "imath-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/imath/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "libdeflate-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/libdeflate/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "openjph-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/openjph/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "nlohmann-json-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/nlohmann-json/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "joltphysics-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/joltphysics/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "lua-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/lua/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "sol2-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/sol2/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "rmlui-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/rmlui/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "miniaudio-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/miniaudio/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "freetype-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/freetype/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "libpng-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/libpng/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "zlib-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/zlib/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "bzip2-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/bzip2/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "brotli-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/brotli/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "manifold-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/manifold/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "clipper2-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/clipper2/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "tbb-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/tbb/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "hwloc-LICENSE.txt" FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/share/hwloc/copyright")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE FILE FILES "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/glfw3.dll")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE FILE FILES
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/DirectXTex.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/FLAC++.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/FLAC.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/Iex-3_4.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/IlmThread-3_4.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/Imath-3_2.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/OpenEXR-3_4.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/OpenEXRCore-3_4.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/OpenEXRUtil-3_4.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/assimp-vc143-mt.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/brotlicommon.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/brotlidec.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/brotlienc.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/bz2.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/deflate.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/freetype.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/glfw3.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/hwloc-15.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/jpeg62.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/ktx.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/kubazip.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/liblzma.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/libmp3lame.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/libpng16.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/libsharpyuv.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/libwebp.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/libwebpdecoder.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/libwebpdemux.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/libwebpmux.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/lua.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/manifold.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/manifoldc.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/minizip.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/ogg.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/openjph.0.31.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/opus.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/pkgconf-8.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/poly2tri.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/pugixml.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/rmlui.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/rmlui_debugger.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/tbb12.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/tbbmalloc.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/tbbmalloc_proxy.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/tiff.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/turbojpeg.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/vorbis.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/vorbisenc.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/vorbisfile.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/z.dll"
    "D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin/zstd.dll"
    )
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender" TYPE FILE RENAME "runtime-build.json" FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-030251-hair-main-chroma-public-9e799c/release/runtime-build-Release.json")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/tools" TYPE FILE FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/tools/build_game.py")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/assets_public/fonts/NotoSansCJK-LICENSE.txt")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "LatoLatin-LICENSE.txt" FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/assets_public/fonts/RmlUi-Sample-Fonts-LICENSE.txt")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "gkNextEngine-LICENSE.txt" FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/third_party/gknextengine/LICENSE.txt")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "NanoSVG-LICENSE.txt" FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/third_party/nanosvg/LICENSE.txt")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "NanoSVG-source.json" FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/third_party/nanosvg/SOURCE.json")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "ImGuizmo-LICENSE.txt" FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/third_party/ImGuizmo/LICENSE.txt")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "ImGuizmo-source.json" FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/third_party/ImGuizmo/source.json")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "ImViewGuizmo-LICENSE.txt" FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/third_party/ImViewGuizmo/LICENSE.txt")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE RENAME "ImViewGuizmo-source.json" FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/third_party/ImViewGuizmo/source.json")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/docs/licenses/texture-containers-source.json")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE DIRECTORY FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/docs/licenses/ktx")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/docs/licenses/image-codecs-source.json")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/docs/licenses/audio-codecs-source.json")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE FILE FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/docs/licenses/compressed-audio-source.json")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/licenses" TYPE DIRECTORY FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/docs/licenses/compressed-audio")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/bin" TYPE EXECUTABLE FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-030251-hair-main-chroma-public-9e799c/release/AzureGameLauncher.exe")
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/AzureRender/assets_public" TYPE DIRECTORY FILES "D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/assets_public/brand")
