from hashlib import file_digest, sha256
from pathlib import Path
import json
import xml.etree.ElementTree as xml
import zipfile


out = Path(__file__).resolve().parent
engine = out.parents[2]
prior = out.parent / '20261112-044926-material-reference-object-visibility-344def'
target = engine / 'docs/acceptance/nr/evidence/2026-11-12/project-reference-visibility-profile'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


labels = tuple(f'{config}-{device}' for config in ('release', 'debug') for device in ('nvidia', 'intel'))
builds = {}
for name in ('release', 'debug', *(key + '-gpu' for key in labels)):
    build = read(out / (name + '-verification.json'))
    assert build['shaderCount'] == 891 and build['ctestExit'] == 0 and not build['changedShaders']
    suite = xml.parse(out / (name + '-ctest.xml')).getroot()
    expected = 6 if name == 'release' else 5 if name == 'debug' else 4
    assert len(suite.findall('.//testcase')) == expected
    assert not any(suite.findall(path) for path in ('.//failure', './/error', './/skipped'))
    builds[name] = {**build, 'tests': expected}
red = read(out / 'red-player-profile-check.json')
green = read(out / 'green-player-profile-check.json')
assert red['playerSha256'] != green['playerSha256'] == builds['release']['playerSha256']
assert all(case['code'] == 0 for case in red['cases'].values())
assert {name: case['code'] for name, case in green['cases'].items()} == dict(valid=0, reserved=1, truncated=1, missing=1)
package = read(out / 'package-verification.json')
assert package['movedCheck'] and package['sourceUnavailable'] and package['installUnavailable']
assert package['playerSha256'] == builds['release']['playerSha256']
assert 'Ran 20 tests' in (out / 'package-rules.log').read_text(encoding='utf-8-sig')
binding = read(out / 'profile-binding/report.json')
assert binding['status'] == 'qualified' and binding['profile']['bytes'] == 2097152 and binding['uniform']['control'][1] == 3
assert binding['profile']['sha256'] == package['configuration']['object-visibility-profile-v1.bin']['sha256']
captures = {label: read(out / (label + '-results.json')) for label in labels}
for label, capture in captures.items():
    baseline = read(prior / (label + '-results.json'))
    assert capture['validationClean'] and capture['allocatorZero']
    assert capture['hair']['pixels'] == capture['colorHair']['pixels'] == 17017 and capture['receiver']['pixels'] == 49384
    assert all(capture[key] == baseline[key] for key in ('referenceDepthSha256', 'referenceNormalsSha256', 'objectIdsSha256'))
    if label.endswith('nvidia'):
        assert capture['visibilitySha256'] == baseline['visibilitySha256'] and capture['colors'] == baseline['colors']
        assert (capture['hair']['overOne'], capture['receiver']['overOne'], capture['colorHair']['overOne']) == (0, 2736, 0)
    else:
        assert capture['visibilitySha256'] == 'd54b15c7a622e089c89883abca66ca377632e425a7f7ceeff6074f97b79ae5d3'
        assert (capture['hair']['overOne'], capture['receiver']['overOne'], capture['colorHair']['overOne']) == (208, 2981, 575)
cross = read(out / 'cross-configuration.json')
assert all(all(cross[device].values()) for device in ('nvidia', 'intel'))
original = read(out / 'default-four-results.json')
assert original['allExact'] and original['depthCaptureAbsent'] and original['validationClean'] and original['allocatorZero']
assert original['projectSha256'] == '13638585d18092a315bd7586a88b349fe256c468eb9090ccb6189232b8209d78'
attribution = read(out / 'profile-receiver-attribution.json')
assert attribution['377']['cases']['intel-profile']['overOne'] == 1399
assert attribution['377']['cases']['intel-native-normal']['overOne'] == 158
assert attribution['422']['cases']['intel-profile']['overOne'] == 1089
assert attribution['422']['cases']['intel-native-depth']['overOne'] == 152


archive = out / 'profile-validation-pending.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as writer:
    def add(path):
        writer.write(path, 'run/' + path.relative_to(out).as_posix())

    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.json', '.xml', '.log') and not path.name.startswith(('native-normal-bias', 'native-caster-geometry')):
            add(path)
    add(out / 'package-runtime-install.cmake')
    for label in labels:
        for name in ('capture_manifest.json', 'gpu_capabilities.json', 'reference-planes.json'):
            add(out / (label + '-frames') / name)
    for name in ('report.json', 'request.json', 'command.json', 'renderdoc.log'):
        add(out / 'profile-binding' / name)
    for name in ('lab.azureproject', 'plane.gltf', 'level.azurelevel', 'config/reference-views.json'):
        add(out / 'profile-binding/fixture' / name)
    for name in ('capture_manifest.json', 'frame_000002.png'):
        add(out / 'profile-binding/frames' / name)
    for path in sorted((out / 'hair-color-crops').iterdir()):
        add(path)
    add(out / 'default-four-frames/capture_manifest.json')
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    files = {name: sha256(reader.read(name)).hexdigest() for name in reader.namelist()}
assert archive.stat().st_size <= 8 * 1024 * 1024

result = dict(status='qualified-project-reference-visibility-profile', overall='failed-user-review',
    baseCommit='3dc8cce41e9b632386ffdf2be47d4234fa8ccbd0', sceneRendererApiVersion=16, acceptedMaximumByteError=1,
    fixture=read(out / 'profile-fixture-inputs.json'), builds=builds, captures=captures, profileBinding=binding,
    receiverSourceAttribution=attribution,
    colorCrops=read(out / 'hair-color-crops/manifest.json'),
    crossConfiguration=cross, projectValidation=dict(before=red, verified=green), portablePackage=package, originalFour=original,
    archive=dict(bytes=archive.stat().st_size, sha256=digest(archive), files=len(files), contents=files))
target.mkdir(parents=True, exist_ok=True)
assert not (target / 'validation.zip').exists() and not (target / 'results.json').exists()
archive.rename(target / 'validation.zip')
(target / 'results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in result['archive'].items() if key != 'contents'}))
