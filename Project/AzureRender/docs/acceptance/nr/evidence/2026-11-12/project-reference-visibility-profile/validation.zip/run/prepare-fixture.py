from hashlib import file_digest
from pathlib import Path
from shutil import copyfile
import json


out = Path(__file__).resolve().parent
fixture = out.parent / '20261112-032619-native-object-record-calibration-19d2f9'
source = fixture / 'hair-project'
project = out / 'hair-project'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


files = json.loads((fixture / 'hair-fixture-inputs.json').read_text())
assert len(files) == 42
for entry in files:
    relative = Path(entry['relative'])
    original = source / relative
    assert original.resolve(strict=True).is_relative_to(source)
    assert original == Path(entry['destination'])
    assert digest(original) == entry['sha256']
    destination = project / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    copyfile(original, destination)
    assert digest(destination) == entry['sha256']

config = project / 'config/reference-views.json'
profile = project / 'config/object-visibility-profile-v1.bin'
data = json.loads(config.read_text(encoding='utf-8'))
assert set(data) == {'schemaVersion', 'views'} and data['schemaVersion'] == 1
data['objectVisibilityArithmetic'] = 'profile-v1'
config.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
profile_source = out.parent / '20261110-003031-reciprocal-compact-profile-4e7929/correction.bin'
assert profile_source.stat().st_size == 2 * 1024 * 1024
copyfile(profile_source, profile)
profile_hash = 'bbda0d685ab5a66767c2c3881a67dff147e1f5a2c766db1f6dd5b63fecedcf2c'
assert digest(profile) == profile_hash == digest(profile_source)
catalog = [
    dict(relative=path.relative_to(project).as_posix(), bytes=path.stat().st_size, sha256=digest(path))
    for path in sorted(project.rglob('*')) if path.is_file()
]
(out / 'profile-fixture-inputs.json').write_text(json.dumps(catalog, indent=2) + '\n')
print(len(catalog), sum(item['bytes'] for item in catalog), profile_hash)
