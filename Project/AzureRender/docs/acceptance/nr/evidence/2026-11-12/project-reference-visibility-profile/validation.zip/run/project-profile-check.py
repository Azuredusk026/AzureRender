from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess
import sys


out = Path(__file__).resolve().parent
phase = sys.argv[1]
assert phase in ('red', 'green')
fixture = out / 'cli-project'
fixture.mkdir(exist_ok=True)
prior = out.parent / '20261112-044926-material-reference-object-visibility-344def/green-release-fixed'
for name in ('plane.gltf', 'lab.azureproject', 'objects.azurelevel'):
    shutil.copyfile(prior / name, fixture / ('level.azurelevel' if name == 'objects.azurelevel' else name))
(fixture / 'config').mkdir(exist_ok=True)
config = json.loads((prior / 'config/reference-views.json').read_text())
config['objectVisibilityArithmetic'] = 'profile-v1'
(fixture / 'config/reference-views.json').write_text(json.dumps(config, indent=2) + '\n')
profile = fixture / 'config/object-visibility-profile-v1.bin'
valid = (out / 'hair-project/config/object-visibility-profile-v1.bin').read_bytes()
assert sha256(valid).hexdigest() == 'bbda0d685ab5a66767c2c3881a67dff147e1f5a2c766db1f6dd5b63fecedcf2c'
player = out.parent / '20261110-030251-hair-main-chroma-public-9e799c/release/AzurePlayer.exe'
command = [str(player), '--project', str(fixture / 'lab.azureproject'), '--check-project']
report = dict(command=command, playerSha256=sha256(player.read_bytes()).hexdigest(), cases={})
cases = [('valid', valid), ('reserved', bytes([3]) + valid[1:]), ('truncated', valid[:-1]), ('missing', None)]
for name, data in cases:
    if data is None:
        profile.unlink()
    else:
        profile.write_bytes(data)
    process = subprocess.run(command, cwd=fixture, capture_output=True, timeout=45)
    log = process.stdout.decode(errors='replace') + process.stderr.decode(errors='replace')
    report['cases'][name] = dict(code=process.returncode, log=log)
    if phase == 'red' or name == 'valid':
        assert process.returncode == 0 and 'Project validation passed' in log, log
    else:
        reason = 'reserved code' if name == 'reserved' else 'requires exactly 2097152 bytes'
        assert process.returncode != 0 and reason in log, log
profile.write_bytes(valid)
(out / (phase + '-player-profile-check.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
