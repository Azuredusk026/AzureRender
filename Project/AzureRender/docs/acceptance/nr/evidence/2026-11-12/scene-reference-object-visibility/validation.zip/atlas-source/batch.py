from pathlib import Path
import subprocess
import sys


out=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(out/'capture.py'),*sys.argv[1:]],check=True)
subprocess.run([sys.executable,str(out/'isolate-inputs.py')],check=True)
