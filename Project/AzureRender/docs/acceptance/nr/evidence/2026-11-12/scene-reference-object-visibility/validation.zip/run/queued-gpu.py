from pathlib import Path
import json
import os
import sys
import time


out=Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


token,label,device,script,*args=sys.argv[1:]
assert device in ('nvidia','intel')
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key,None)
os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*' if device=='nvidia' else '*igvk64*',
    VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
deadline=time.monotonic()+1200
while time.monotonic()<deadline:
    try:
        state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
    except (OSError,ValueError):
        time.sleep(1)
        continue
    if state.get('token')!=token or state.get('state')=='released':break
    time.sleep(1)
else:
    raise TimeoutError('The agreed GPU window has not opened')
with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a',
    'quality-scene-reference-object-visibility-'+label,out):
    execution=shared.maintenance.guarded_run(out.parents[1],out.name,[sys.executable,str(out/script),*args],650)
    (out/(label+'-execution.json')).write_text(json.dumps(execution,indent=2)+'\n')
    print(json.dumps(execution),flush=True)
    assert execution['status']=='exited' and execution['exitCode']==0,execution
