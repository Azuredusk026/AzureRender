from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess

import numpy as np


out=Path(__file__).resolve().parent
stage=out.parent/'20261112-010418-scene-reference-object-visibility-709f68'
previous=out.parent/'20261111-232828-scene-reference-normal-60ddfa'
old=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
recorded=json.loads((out/'recorded-parameters.json').read_text())
report=json.loads((out/'report.json').read_text())
assert report['status']=='qualified'
assert recorded['control']==[1,1,1,0] and recorded['reconstruction'][2:]==[0,0]
for name in ('depth','normals','objectIds','atlas','visibility'):
    assert sha256((out/(name+'.bin')).read_bytes()).hexdigest()==report['sources'][name]['sha256']

reverse_atlas=out/'actual-atlas-reversed.bin'
forward=np.fromfile(out/'atlas.bin','<u2')
assert len(forward)==4096*2048
(np.uint16(65535)-forward).astype('<u2').tofile(reverse_atlas)
source_control=json.loads((previous/'object-frame-source-control.json').read_text())
view=json.loads((stage/'hair-project/config/reference-views.json').read_text())['views']['native-hair']
relative_to_native=np.eye(4)
relative_to_native[:3,3]=np.asarray(source_control['nearestIntegralOrigin'])-np.asarray(view['frame']['offset'])
native_to_relative=np.eye(4)
native_to_relative[:3,3]=-relative_to_native[:3,3]
inverse_relative=np.asarray(recorded['clipToWorld'],dtype='f8').reshape(4,4).T
absolute_inverse=(relative_to_native@inverse_relative).T.astype('f4').reshape(-1).tolist()


def reverse_record(record,native_coordinates):
    matrix=np.asarray(record['projection'],dtype='f8').reshape(4,4).T
    if native_coordinates:matrix=matrix@native_to_relative
    matrix[2]*=-1
    matrix[2,3]+=1
    return dict(record,projection=matrix.T.astype('f4').reshape(-1).tolist())


source_record=reverse_record(recorded['record'],True)
relative_record=reverse_record(recorded['record'],False)
cases={
    'frozen':{},
    'atlas':dict(atlas=str(reverse_atlas)),
    'inverse':dict(clipToWorld=absolute_inverse),
    'record':dict(record=source_record),
    'live':dict(depth=str(out/'depth.bin'),normals=str(out/'normals.bin'),atlas=str(reverse_atlas),
        clipToWorld=recorded['clipToWorld'],record=relative_record),
}

env=os.environ.copy()
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    env.pop(key,None)
env.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
summaries={}
for scope in ('hair','receiver'):
    source=json.loads((old/(scope+'-calibration.json')).read_text())
    if scope=='hair':
        folder=previous/'nvidia-normal-visibility-control-reference-frame'
        source.update(queries=str(folder/'queries.bin'),expected=str(folder/'expected.bin'))
    queries=np.fromfile(source['queries'],'<f4').reshape(-1,4)
    x,y=queries[:,:2].astype('i4').T
    assert np.all(np.fromfile(out/'objectIds.bin','u1').reshape(1440,2560)[y,x]==1)
    for name,overrides in cases.items():
        label=scope+'-'+name
        directory=out/label
        directory.mkdir()
        path=directory/'calibration.json'
        config=dict(source,**overrides,scope=label)
        path.write_text(json.dumps(config,indent=2)+'\n')
        command=[str(old/'calibration.exe'),str(path),str(old)]
        (directory/'command.json').write_text(json.dumps(command,indent=2)+'\n')
        with (directory/'process.log').open('wb') as log:
            process=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=95)
        result=json.loads((directory/('nvidia-'+label+'-result.json')).read_text())
        assert result['zeroAllocator'] and not result['validationErrors']
        assert result['pixels']==len(queries)
        assert process.returncode==(0 if result['withinOnePixels']==result['pixels'] else 1)
        if name=='frozen':assert process.returncode==0
        summaries[label]=dict(result,overOne=result['pixels']-result['withinOnePixels'],deviceExit=process.returncode)
(out/'visibility-source-isolation.json').write_text(json.dumps(summaries,indent=2)+'\n')
print(json.dumps({name:{key:result[key] for key in ('pixels','exactPixels','overOne','maximumByteError')} for name,result in summaries.items()}))
