from pathlib import Path
import json
import subprocess
import sys


out = Path(__file__).resolve().parent
root = out.parents[2]
main = Path('D:/Projects/FYP/Project/AzureRender')
configuration = sys.argv[1]
assert configuration in ('Debug','Release')
gpu_test_only='--gpu-test-only' in sys.argv
prefix = configuration.lower()+('-gpu-test' if gpu_test_only else '')
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
cmake = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
targets = ['AzurePlayer','AzureReferenceCameraViewTests','AzureProjectReferenceViewsTests','AzureRenderExtensionRegistryTests',
    'AzureReferenceCameraBindingTests','AzureScreenObjectVisibilityTests','AzureScreenObjectVisibilityGpuTests',
    'AzureReferenceDepthGpuTests','AzureReferenceDepthCoverageGpuTests']
if configuration=='Release':
    targets += ['AzureRender','AzureGameLauncher']
if gpu_test_only:
    targets=['AzureScreenObjectVisibilityGpuTests']
preflight = [sys.executable,str(root/'tools/artifact_budget.py'),'--build',str(root/'build'),'--run',str(build.parent),
    '--planned-bytes',str(16777216 if gpu_test_only else 33554432 if configuration=='Debug' else 134217728)]
result = subprocess.run(preflight,capture_output=True,text=True)
(out/(prefix+'-internal-preflight.log')).write_text(result.stdout+result.stderr)
result.check_returncode()
commands=[] if gpu_test_only else [[cmake,'-S',str(root),'-B',str(build)]]
commands.append([cmake,'--build',str(build),'--target',*targets,'--parallel','4'])
(out/(prefix+'-build-commands.json')).write_text(json.dumps(commands,indent=2)+'\n')
with (out/(prefix+'-build.log')).open('wb') as log:
    for command in commands:
        subprocess.run(subprocess.list2cmdline([str(main/'tools/msvc_env.bat'),*command]),cwd=root,shell=True,
            stdout=log,stderr=subprocess.STDOUT,check=True)
