from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import struct
import subprocess
import sys


out=Path(__file__).resolve().parent
root=out.parents[2]
stage=out.parent/'20261112-010418-scene-reference-object-visibility-709f68'
sys.path.insert(0,str(root/'tools/native_render'))
from renderdoc_capture import fingerprint


normal=json.loads((stage/'release-nvidia-results.json').read_text())
argv=json.loads((stage/'release-nvidia-command.json').read_text())
source=Path(argv[0])
source_identity=fingerprint(source)
assert source_identity['sha256']==json.loads((stage/'release-verification.json').read_text())['playerSha256']
argv[argv.index('--capture-dir')+1]=str(out/'host-frames')
argv[argv.index('--capture-frames')+1]='4'
argv+=['--runtime-report',str(out/'host-runtime.json')]
shader=source.parent/'shaders/screen_object_visibility.frag.spv'
expected={key:normal[field] for key,field in [('depth','referenceDepthSha256'),('normals','referenceNormalsSha256'),
    ('objectIds','objectIdsSha256'),('visibility','visibilitySha256')]}
job=dict(operation='capture',source=source_identity,working_directory=str(source.parent),arguments=argv[1:],output=str(out),
    frame=3,timeout=300,nativeRenderTools=str(root/'tools/native_render'),shaderSha256=sha256(shader.read_bytes()).hexdigest(),
    expectedSha256=expected,layerPath='D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64;D:/Tools/VulkanSDK/1.4.350.0/Bin')
if '--replay-only' in sys.argv:
    original=out/'capture-first-report.json'
    if not original.exists():
        shutil.copyfile(out/'report.json',original)
        shutil.copyfile(out/'process.log',out/'capture-first-process.log')
    job['captureReceipt']=json.loads(original.read_text())['captureReceipt']
    assert fingerprint(job['captureReceipt']['capture']['path'])==job['captureReceipt']['capture']
request=out/'request.json'
request.write_text(json.dumps(job,indent=2)+'\n')
environment=os.environ.copy()
for key in ('VK_LAYER_PATH','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES','VK_DRIVER_FILES','VK_ICD_FILENAMES'):
    environment.pop(key,None)
environment.update(AZURE_OBJECT_VISIBILITY_CAPTURE=str(request),VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'renderdoc-worker.py')]
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (out/'renderdoc.log').open('wb') as log:
    process=subprocess.run(command,env=environment,cwd=out,startupinfo=startup,stdout=log,stderr=subprocess.STDOUT,timeout=520)
report=json.loads((out/'report.json').read_text())
assert process.returncode==0 and report['status']=='qualified',report
assert fingerprint(source)==source_identity
host=out/'host-frames'
assert all(sha256((host/f'frame_{i:06d}.png').read_bytes()).hexdigest()==normal['colors'][i] for i in range(3))
capture=json.loads((host/'capture_manifest.json').read_text())['referenceSceneDepth']
assert sha256((host/capture['objectVisibility']).read_bytes()).hexdigest()==normal['visibilitySha256']
data=(out/'parameters.bin').read_bytes()
view=struct.unpack_from('<20f4I',data)
assert view[20:]==(1,1,1,0)
projection=struct.unpack_from('<28f',data,96)
parameters=dict(clipToWorld=list(view[:16]),reconstruction=list(view[16:20]),control=list(view[20:]),
    record=dict(projection=list(projection[:16]),lightDirection=list(projection[16:19]),lightBias=projection[19],
        normalBias=projection[20],filterRadiusUv=list(projection[21:23]),minimumReceiverDepth=projection[23],
        atlasRect=list(projection[24:28])))
(out/'recorded-parameters.json').write_text(json.dumps(parameters,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ('event','sources','parameters','debugMessages')}))
