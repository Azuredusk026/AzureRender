from hashlib import sha256
from pathlib import Path
import json
import zipfile


out=Path(__file__).resolve().parent
root=out.parents[2]
atlas_run=out.parent/'20261112-013522-scene-visibility-atlas-source-33c6c3'
target=root/'docs/acceptance/nr/evidence/2026-11-12/scene-reference-object-visibility'


def read(folder,name):
    return json.loads((folder/name).read_text(encoding='utf-8'))


def digest(data):
    return sha256(data).hexdigest()


labels=tuple(f'{configuration}-{device}' for configuration in ('release','debug') for device in ('nvidia','intel'))
captures={name:read(out,name+'-results.json') for name in labels}
for name,case in captures.items():
    assert case['validationClean'] and case['allocatorZero'] and case['hair']['pixels']==17017 and case['receiver']['pixels']==49384,name
    assert case['hair']['overOne']>0 and case['receiver']['overOne']>0,name
configurations=read(out,'cross-configuration.json')
assert all(all(configurations[device].values()) for device in ('nvidia','intel')) and configurations['sceneControlsExact']
original=read(out,'default-four-results.json')
assert original['allExact'] and original['depthCaptureAbsent'] and original['validationClean'] and original['allocatorZero']
builds={key:read(out,key+'-verification.json') for key in ('release','debug',*(name+'-gpu' for name in labels))}
assert all(not value['ctestExit'] and value['shaderCount']==891 and value['allShadersExact'] for value in builds.values())
atlas_report=read(atlas_run,'report.json')
source_isolation=read(atlas_run,'visibility-source-isolation.json')
atlas_comparison=read(atlas_run,'atlas-source-comparison.json')
assert atlas_report['status']=='qualified' and source_isolation['hair-frozen']['overOne']==source_isolation['receiver-frozen']['overOne']==0
assert atlas_comparison['liveControlVsProduction']['hair']['exact']==17017

target.mkdir(parents=True,exist_ok=False)
archive=target/'validation.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as writer:
    def add(path,prefix='run'):
        base=out if prefix=='run' else atlas_run
        writer.write(path,prefix+'/'+path.relative_to(base).as_posix())
    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py','.json','.xml','.log'):
            add(path)
    for label in labels:
        folder=out/(label+'-frames')
        for name in ('capture_manifest.json','gpu_capabilities.json','reference-planes.json'):
            add(folder/name)
        if label.startswith('release-'):
            add(folder/'reference-planes.zip')
    for config in ('release','debug'):
        folder=out/('scene-control-'+config)
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix in ('.json','.log','.gltf','.azurelevel','.azureproject'):
                add(path)
        add(folder/'config/reference-views.json')
        for mode in ('objects','permuted','inputs','neutral'):
            add(folder/mode/'capture_manifest.json')
            if mode!='inputs':add(folder/mode/'reference-object-visibility-rg8.bin')
    add(out/'default-four-frames/capture_manifest.json')
    add(out/'hair-project/config/reference-views.json')
    for path in sorted((out/'runtime-red').iterdir()):
        if path.is_file() and path.suffix in ('.json','.log','.gltf','.azurelevel','.azureproject'):
            add(path)
    for name in ('task-card.json','capture.py','renderdoc-worker.py','isolate-inputs.py','batch.py','request.json','report.json',
        'capture-first-report.json','atlas-source-execution.json','atlas-source-replay-execution.json',
        'recorded-parameters.json','visibility-source-isolation.json','atlas.bin','parameters.bin','atlas-source-comparison.json','compare-atlas-source.py'):
        add(atlas_run/name,'atlas-source')
    for scope in ('hair','receiver'):
        for control in ('frozen','atlas','inverse','record','live'):
            folder=atlas_run/(scope+'-'+control)
            for path in sorted(folder.iterdir()):
                if path.is_file() and path.suffix in ('.json','.bin','.log'):
                    add(path,'atlas-source')
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    contents={name:digest(reader.read(name)) for name in reader.namelist()}
assert archive.stat().st_size<=8*1024*1024
result=dict(status='qualified-scene-reference-object-visibility-path',overall='failed-user-review',baseCommit='22663a8',
    sceneRendererApiVersion=13,acceptedMaximumByteError=1,builds=builds,captures=captures,crossConfiguration=configurations,
    originalFour=original,atlasSource=atlas_report,sourceIsolation=source_isolation,atlasComparison=atlas_comparison,
    archive=dict(bytes=archive.stat().st_size,sha256=digest(archive.read_bytes()),files=len(contents),contents=contents))
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result['archive'].items() if k!='contents'}))
