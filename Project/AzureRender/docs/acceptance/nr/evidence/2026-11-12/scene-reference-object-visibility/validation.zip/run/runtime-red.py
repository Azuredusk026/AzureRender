from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess


out = Path(__file__).resolve().parent
prior = out.parent/'20261111-232828-scene-reference-normal-60ddfa/object-id-control-release'
project = out/'runtime-red'
(project/'config').mkdir(parents=True)
for name in ('plane.gltf','level.azurelevel','lab.azureproject','config/reference-views.json'):
    shutil.copyfile(prior/name,project/name)
views = project/'config/reference-views.json'
config = json.loads(views.read_text())
config['views']['permuted']['objectVisibility'] = {'pixelOffset':[.5,.5]}
views.write_text(json.dumps(config,indent=2)+'\n')
player = out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release/AzurePlayer.exe'
assert sha256(player.read_bytes()).hexdigest()=='ef98d71974283d60efb1ee40c4ba5f1984dd37ec9233abad6588b1b43277d662'
command = [str(player),'--project',str(project/'lab.azureproject'),'--width','128','--height','128',
    '--capture-frames','1','--capture-dir',str(project/'frames'),'--resource-root',str(player.parent)]
environment = os.environ.copy()
for key in ('VK_INSTANCE_LAYERS','VK_ICD_FILENAMES','VK_LOADER_DRIVERS_SELECT'):
    environment.pop(key,None)
environment['VK_DRIVER_FILES']=str(project/'disabled-driver.json')
process=subprocess.run(command,env=environment,capture_output=True,timeout=45)
data=process.stdout+process.stderr
(project/'process.log').write_bytes(data)
assert process.returncode!=0 and b'Unexpected reference camera fields' in data
assert b'Vulkan instance' not in data and not (project/'frames').exists()
(out/'runtime-red-result.json').write_text(json.dumps(dict(command=command,exitCode=process.returncode,
    noGpuDriver=True,missingPublicField='objectVisibility',error='Unexpected reference camera fields'),indent=2)+'\n')
print(data.decode(errors='replace'))
