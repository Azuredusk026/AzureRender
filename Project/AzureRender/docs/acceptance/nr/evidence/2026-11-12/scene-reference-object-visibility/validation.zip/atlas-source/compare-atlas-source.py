from hashlib import sha256
from pathlib import Path
import json

import numpy as np


out=Path(__file__).resolve().parent
report=json.loads((out/'report.json').read_text())
stage=out.parent/'20261112-010418-scene-reference-object-visibility-709f68'
previous=out.parent/'20261111-232828-scene-reference-normal-60ddfa'
sources=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
actual=(out/'atlas.bin').read_bytes()
frozen_config=json.loads((sources/'receiver-calibration.json').read_text())
frozen=Path(frozen_config['atlas']).read_bytes()
assert sha256(actual).hexdigest()==report['sources']['atlas']['sha256']
assert sha256(frozen).hexdigest()=='86daee0e01e9c33207679b094bdf5cf31a26d2f93754f11abf6c44df1faecf57'
first=65535-np.frombuffer(actual,'<u2').astype('i4')
second=np.frombuffer(frozen,'<u2').astype('i4')
both=(first>0)&(second>0)
diff=np.abs(first[both]-second[both])
atlas=dict(frozenSha256=sha256(frozen).hexdigest(),actualForwardSha256=sha256(actual).hexdigest(),
    sharedCovered=int(both.sum()),actualOnly=int(((first>0)&(second==0)).sum()),frozenOnly=int(((second>0)&(first==0)).sum()),
    sharedWithinOne=int((diff<=1).sum()),sharedOverTwo=int((diff>2).sum()),maxUnits=int(diff.max()))
image=np.fromfile(out/'visibility.bin','u1').reshape(1440,2560,2)
measurements={}
for name,queries in [('hair',previous/'nvidia-normal-visibility-control-reference-frame/queries.bin'),
    ('receiver',sources/'receiver-queries.bin')]:
    x,y=np.fromfile(queries,'<f4').reshape(-1,4)[:,:2].astype('i4').T
    actual=image[y,x]
    replay=np.fromfile(out/(name+'-live')/('nvidia-'+name+'-live-rg8.bin'),'u1').reshape(-1,2)
    diff=np.abs(actual.astype('i4')-replay.astype('i4')).max(axis=1)
    measurements[name]=dict(pixels=len(x),exact=int((diff==0).sum()),overOne=int((diff>1).sum()),maximum=int(diff.max()))
result=dict(atlas=atlas,liveControlVsProduction=measurements)
(out/'atlas-source-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
