from hashlib import sha256
from pathlib import Path
import json
import re
import subprocess
import sys

import numpy as np


out=Path(__file__).resolve().parent
configuration,device=sys.argv[1:]
assert configuration in ('Release','Debug') and device in ('nvidia','intel')
label=configuration.lower()+'-'+device
frames=out/(label+'-frames')
build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
prior=out.parent/'20261111-232828-scene-reference-normal-60ddfa'
baseline=prior/('release-nvidia-fixed-reference-frame-results.json' if device=='nvidia' else 'release-intel-fixed-qualified-results.json')
baseline=json.loads(baseline.read_text())
for item in json.loads((out/'hair-fixture-inputs.json').read_text()):
    assert sha256(Path(item['destination']).read_bytes()).hexdigest()==item['sha256']

command=[str(build/'AzurePlayer.exe'),'--project',str(out/'hair-project/hair-coverage.azureproject'),
    '--width','2560','--height','1440','--capture-frames','3','--capture-dir',str(frames),'--fixed-frame-step',
    '--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--disable-compute-skinning',
    '--disable-bindless','--resource-root',str(build)]
(out/(label+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
log_path=out/(label+'.log')
with log_path.open('wb') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=420)
log=log_path.read_text(errors='replace')
assert result.returncode==0 and 'Allocator after unload: buffers=0 images=0' in log,log[-7000:]
assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I),log[-7000:]
capture=json.loads((frames/'capture_manifest.json').read_text())['referenceSceneDepth']
assert (capture['rowOrigin'],capture['normalFrame'],capture['submission'],capture['width'],capture['height'])==('bottom-left','reference',3,2560,1440)
for field,key in [('raster','rasterSha256'),('hardware','rasterSha256'),('packedNormals','normalsSha256'),('objectIds','objectIdsSha256')]:
    assert sha256((frames/capture[field]).read_bytes()).hexdigest()==baseline[key],field
colors=[sha256((frames/f'frame_{i:06d}.png').read_bytes()).hexdigest() for i in range(3)]
assert colors==[row['sha256'] for row in baseline['color']]
raw=(frames/capture['objectVisibility']).read_bytes()
assert len(raw)==2560*1440*2
image=np.frombuffer(raw,'u1').reshape(1440,2560,2)
ids=np.fromfile(frames/capture['objectIds'],'u1').reshape(1440,2560)
assert np.all(image[:,:,0]==255) and np.all(image[:,:,1][ids==0]==255)
assert np.any(image[:,:,1][ids>0]<255)

def compare(queries,expected):
    p=np.fromfile(queries,'<f4').reshape(-1,4)
    x,y=p[:,:2].astype('i4').T
    reference=np.fromfile(expected,'<u4').astype('i4')
    assert len(reference)==len(x) and np.all(ids[y,x]>0)
    actual=image[y,x,1].astype('i4')
    difference=actual-reference
    positions=np.flatnonzero(np.abs(difference)>1)
    return dict(pixels=len(reference),exact=int((difference==0).sum()),overOne=len(positions),
        maximum=int(np.abs(difference).max()),median=float(np.median(np.abs(difference))),
        samples=[[int(x[i]),1439-int(y[i]),int(actual[i]),int(reference[i])] for i in positions[:25]])

hair=prior/'nvidia-normal-visibility-control-reference-frame'
receiver=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
hair_result=compare(hair/'queries.bin',hair/'expected.bin')
receiver_result=compare(receiver/'receiver-queries.bin',receiver/'receiver-expected.bin')
assert hair_result['pixels']==17017 and receiver_result['pixels']==49384
report=dict(configuration=configuration,device=device,program='actual Player live attachments',visibilitySha256=sha256(raw).hexdigest(),
    referenceDepthSha256=baseline['rasterSha256'],referenceNormalsSha256=baseline['normalsSha256'],objectIdsSha256=baseline['objectIdsSha256'],
    colors=colors,hair=hair_result,receiver=receiver_result,validationClean=True,allocatorZero=True)
(out/(label+'-results.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
