from hashlib import sha256
from pathlib import Path
import json
import sys
import zipfile

import numpy as np


out=Path(__file__).resolve().parent
device=sys.argv[1]
assert device in ('nvidia','intel')
frames=out/('release-'+device+'-frames')
previous=out.parent/'20261111-232828-scene-reference-normal-60ddfa'
hair=previous/'nvidia-normal-visibility-control-reference-frame'
receiver=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
reference=json.loads((receiver/'receiver-calibration.json').read_text())


def read(name,dtype,channels=1):
    info=json.loads((frames/'reference-planes.json').read_text())[name]
    with zipfile.ZipFile(frames/'reference-planes.zip') as archive:
        data=archive.read(info['archiveEntry'])
    assert sha256(data).hexdigest()==info['sha256']
    array=np.frombuffer(data,dtype)
    return array.reshape(1440,2560,channels) if channels!=1 else array.reshape(1440,2560)


live_depth=read('reference-depth-r32.bin','<u4')
live_normal=read('reference-normals-a2b10g10r10.bin','<u4')
live_rg=read('reference-object-visibility-rg8.bin','u1',2)
native_depth=np.fromfile(reference['depth'],'<u4').reshape(1440,2560)
native_normal=np.fromfile(reference['normals'],'<u4').reshape(1440,2560)
summary={}
for scope,query_path,expected_path in [('hair',hair/'queries.bin',hair/'expected.bin'),
    ('receiver',receiver/'receiver-queries.bin',receiver/'receiver-expected.bin')]:
    points=np.fromfile(query_path,'<f4').reshape(-1,4)
    x,y=points[:,:2].astype('i4').T
    expected=np.fromfile(expected_path,'<u4').astype('i4')
    actual=live_rg[y,x,1].astype('i4')
    failure=np.abs(actual-expected)>1
    depth=live_depth[y,x]==native_depth[y,x]
    normal=live_normal[y,x]==native_normal[y,x]
    summary[scope]=dict(pixels=len(x),visibilityOverOne=int(failure.sum()),
        failedWithExactDepth=int((failure&depth).sum()),failedWithExactNormals=int((failure&normal).sum()),
        failedWithExactDepthAndNormals=int((failure&depth&normal).sum()),
        failedWithBothInputsDifferent=int((failure&~depth&~normal).sum()),
        fullyVisibleVsOccluded=int((failure&(actual==255)&(expected==0)).sum()),
        fullyOccludedVsVisible=int((failure&(actual==0)&(expected==255)).sum()))
report=dict(scope='Readback intersection only; shared failures identify where other input differences must be tested',device=device,groups=summary)
(out/(device+'-visibility-input-intersection.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
