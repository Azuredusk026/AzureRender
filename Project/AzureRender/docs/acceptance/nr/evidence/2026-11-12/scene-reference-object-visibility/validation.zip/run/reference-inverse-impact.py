from pathlib import Path
import json

import numpy as np


out=Path(__file__).resolve().parent
prior=out.parent/'20261111-232828-scene-reference-normal-60ddfa'
control=json.loads((prior/'object-frame-source-control.json').read_text())
old=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
source=json.loads((old/'hair-calibration.json').read_text())
view=json.loads((out/'hair-project/config/reference-views.json').read_text())['views']['native-hair']
points=np.fromfile(prior/'nvidia-normal-visibility-control-reference-frame/queries.bin','<f4').reshape(-1,4)
x,y=points[:,:2].astype('i4').T
depth=np.fromfile(source['depth'],'<f4').reshape(1440,2560)[y,x]
assert len(depth)==17017
profile=np.fromfile(source['profile'],'<u4')
assert len(profile)==524288


def fma(a,b,c):
    return (np.asarray(a,dtype='f8')*np.asarray(b,dtype='f8')+np.asarray(c,dtype='f8')).astype('f4')


def reconstruct(matrix):
    ndc=fma(fma(points[:,:2],np.float32(1)/np.asarray([2560,1440],dtype='f4'),0),2,-1)
    h=fma(ndc[:,0:1],matrix[0],-ndc[:,1:2]*matrix[1])
    h=fma(depth[:,None],matrix[2],h)+matrix[3]
    bits=h[:,3].copy().view('u4')
    exponent=((bits>>23)&255).astype('i4')
    assert ((exponent>0)&(exponent<=252)).all()
    index=bits&0x7fffff
    code=((profile[index>>4]>>((index&15)*2))&3).astype('i4')
    normalized=(index|0x3f800000).view('f4')
    reciprocal=((np.float32(1)/normalized).view('i4')+code-1).view('f4')
    reciprocal=np.ldexp(reciprocal,127-exponent)
    reciprocal=np.where(bits>>31,-reciprocal,reciprocal)
    return h[:,:3]*reciprocal[:,None]


def project(world,matrix):
    return fma(world[:,2:3],matrix[2,:3],fma(world[:,0:1],matrix[0,:3],world[:,1:2]*matrix[1,:3]))+matrix[3,:3]


def metrics(current,reference):
    difference=np.abs(current.astype('f8')-reference.astype('f8')).max(axis=1)
    return dict(exact=int((difference==0).sum()),p50=float(np.percentile(difference,50)),
        p95=float(np.percentile(difference,95)),maximum=float(difference.max()))


authored_inverse=np.asarray(source['clipToWorld'],dtype='f4').reshape(4,4)
derived_inverse=np.asarray(control['derivedClipToWorld'],dtype='f4').reshape(4,4)
projection=np.asarray(view['projection']['columns'],dtype='f8').T
projection[0]-=2*view['projection']['jitter'][0]*projection[3]
projection[1]+=2*view['projection']['jitter'][1]*projection[3]
relative_inverse=np.linalg.inv(projection).T.astype('f4')
from_relative=np.asarray(control['nearestIntegralOrigin'],dtype='f4')-np.asarray(view['frame']['offset'],dtype='f4')
authored=reconstruct(authored_inverse)
derived=reconstruct(derived_inverse)
relative=reconstruct(relative_inverse)+from_relative
authored_projection=np.asarray(source['record']['projection'],dtype='f4').reshape(4,4)
derived_projection=np.asarray(control['sourceProjection'],dtype='f4').reshape(4,4)
frozen_q=project(authored,authored_projection)
report=dict(scope='CPU binary32 source control; frozen depth and recorded reciprocal profile; no GPU claim',pixels=len(depth),
    worldPosition=dict(derivedAbsolute=metrics(derived,authored),derivedRelativeThenTranslated=metrics(relative,authored)),
    unbiassedUnitObjectPosition=dict(derivedInverse=metrics(project(derived,authored_projection),frozen_q),
        derivedObjectProjection=metrics(project(authored,derived_projection),frozen_q),
        bothDerived=metrics(project(derived,derived_projection),frozen_q)))
(out/'reference-inverse-impact.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
