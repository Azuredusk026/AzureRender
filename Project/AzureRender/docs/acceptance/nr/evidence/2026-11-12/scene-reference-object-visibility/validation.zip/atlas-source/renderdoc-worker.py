from hashlib import sha256
from pathlib import Path
import ctypes
from ctypes import wintypes
import json
import os
import sys
import traceback

import renderdoc as rd


job=json.loads(Path(os.environ['AZURE_OBJECT_VISIBILITY_CAPTURE']).read_text(encoding='utf-8'))
output=Path(job['output'])
sys.path.insert(0,job['nativeRenderTools'])
from renderdoc_capture import fingerprint
from renderdoc_worker import capture_target


def wait_for_target(pid):
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
    kernel.OpenProcess.restype=wintypes.HANDLE
    kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD]
    kernel.WaitForSingleObject.restype=wintypes.DWORD
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    handle=kernel.OpenProcess(0x00100000,False,pid)
    if not handle:
        assert ctypes.get_last_error()==87,'Cannot wait for the selected capture process'
        return
    try:
        assert kernel.WaitForSingleObject(handle,90000)==0,'Captured Player did not finish'
    finally:
        kernel.CloseHandle(handle)


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


report={'status':'failed','captureReceipt':{'artifacts':[]}}
capture=None
controller=None
try:
    if 'captureReceipt' in job:
        report['captureReceipt']=job['captureReceipt']
    else:
        capture_environment={'VK_LAYER_PATH':job['layerPath'],'VK_INSTANCE_LAYERS':'VK_LAYER_RENDERDOC_Capture',
            'ENABLE_VULKAN_RENDERDOC_CAPTURE':'1'}
        prior_environment={name:os.environ.get(name) for name in capture_environment}
        os.environ.update(capture_environment)
        try:
            capture_target(rd,job,report['captureReceipt'])
        finally:
            for name,value in prior_environment.items():
                if value is None:os.environ.pop(name,None)
                else:os.environ[name]=value
        wait_for_target(report['captureReceipt']['pid'])
    receipt=report['captureReceipt']
    assert receipt['status']=='captured' and 'Vulkan' in receipt['api'] and receipt['capture_frame']==job['frame']
    assert fingerprint(receipt['capture']['path'])==receipt['capture']
    capture=rd.OpenCaptureFile()
    assert capture.OpenFile(receipt['capture']['path'],'',None)==rd.ResultCode.Succeeded
    gpu,=[item for item in capture.GetAvailableGPUs() if item.vendor==rd.GPUVendor.nVidia and rd.GraphicsAPI.Vulkan in item.apis]
    options=rd.ReplayOptions()
    options.forceGPUVendor=gpu.vendor
    options.forceGPUDeviceID=gpu.deviceID
    status,controller=capture.OpenCapture(options,None)
    assert status==rd.ResultCode.Succeeded and controller
    properties=controller.GetAPIProperties()
    assert properties.pipelineType==rd.GraphicsAPI.Vulkan and properties.vendor==gpu.vendor and not properties.degraded
    report['device']=gpu.name
    textures={str(item.resourceId):item for item in controller.GetTextures()}
    matches=[]
    for action in walk(controller.GetRootActions()):
        if not action.flags&rd.ActionFlags.Drawcall or action.numIndices!=3 or action.numInstances!=1:
            continue
        controller.SetFrameEvent(action.eventId,True)
        pipe=controller.GetPipelineState()
        shader=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
        if not shader or sha256(bytes(shader.rawBytes)).hexdigest()!=job['shaderSha256']:
            continue
        matches.append(action.eventId)
    assert len(matches)==1,matches
    event,=matches
    controller.SetFrameEvent(event,True)
    pipe=controller.GetPipelineState()
    shader=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
    inputs={shader.readOnlyResources[item.access.index].fixedBindNumber:item.descriptor.resource
        for item in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel)}
    targets=[descriptor.resource for descriptor in pipe.GetOutputTargets() if descriptor.resource!=rd.ResourceId.Null()]
    report['targetResources']=[str(resource) for resource in targets]
    assert len(targets)==1,report['targetResources']
    sources={'depth':inputs[1],'normals':inputs[2],'objectIds':inputs[3],'atlas':inputs[4],'visibility':targets[0]}
    report['event']=event
    report['sources']={}
    for name,resource in sources.items():
        texture=textures[str(resource)]
        data=bytes(controller.GetTextureData(resource,rd.Subresource()))
        path=output/(name+'.bin')
        path.write_bytes(data)
        actual=sha256(data).hexdigest()
        if name=='atlas':
            assert (texture.width,texture.height,len(data))==(4096,2048,4096*2048*2)
            assert 'D16' in texture.format.Name(),texture.format.Name()
        else:
            assert (texture.width,texture.height)==(2560,1440) and actual==job['expectedSha256'][name],(name,actual)
        report['sources'][name]=dict(resource=str(resource),format=texture.format.Name(),width=texture.width,
            height=texture.height,bytes=len(data),sha256=actual)
    bound=pipe.GetConstantBlock(rd.ShaderStage.Pixel,0,0).descriptor
    parameters=bytes(controller.GetBufferData(bound.resource,bound.byteOffset,992))
    assert len(parameters)==992
    (output/'parameters.bin').write_bytes(parameters)
    report['parameters']=dict(resource=str(bound.resource),offset=bound.byteOffset,sha256=sha256(parameters).hexdigest())
    report['debugMessages']=[str(message.description) for message in controller.GetDebugMessages()]
    report['status']='qualified'
except BaseException:
    report['error']=traceback.format_exc()
finally:
    if controller:controller.Shutdown()
    if capture:capture.Shutdown()
    (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)
