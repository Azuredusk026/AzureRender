
from hashlib import file_digest, sha256
from pathlib import Path
import json
import re
import runpy
import subprocess
import sys
import zipfile

import numpy as np
from PIL import Image


out=Path(__file__).resolve().parent
config,device,*options=sys.argv[1:]
assert config in ('Release','Debug') and device in ('nvidia','intel')
assert options in ([],['indexed'])
indexed=bool(options)
base_label=config.lower()+'-'+device
label=base_label+('-indexed' if indexed else '')
frames=out/(label+'-frames')
root=out.parent
boundary=root/'20261112-164303-reference-hair-mip-boundary-342000'
triple=root/'20261112-175619-reference-hair-color-triple-d2d080/triple'
fixture=out/'hair-project'
build=root/('20261110-030251-hair-main-chroma-public-9e799c/release' if config=='Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
player=build/'AzurePlayer.exe'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


verify=json.loads((out/(config.lower()+'-verification.json')).read_text())
assert digest(player)==verify['playerSha256']
inputs=json.loads((out/'fixture-inputs.json').read_text())['files']
assert len(inputs)==45
for item in inputs:
    path=fixture/item['relative']
    assert path.stat().st_size==item['bytes'] and digest(path)==item['sha256']
argv=[str(player),'--project',str(fixture/'hair-coverage.azureproject'),'--width','2560','--height','1440',
    '--capture-frames','3','--capture-dir',str(frames),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene',
    '--qa-isolation','beauty','--disable-compute-skinning',*(() if indexed else ('--disable-bindless',)),
    '--resource-root',str(build)]
(out/(label+'-command.json')).write_text(json.dumps(argv,indent=2)+'\n')
log_file=out/(label+'.log')
with log_file.open('wb') as log:
    execution=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=270)
log=log_file.read_text(errors='replace')
assert execution.returncode==0 and 'Allocator after unload: buffers=0 images=0' in log,log[-8000:]
assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I),log[-8000:]
assert ('Character texture access: indexed' if indexed else 'Character texture access: fixed') in log
for slot in (0,6,7):
    assert f'M_actor_laevat_hair_01, slot={slot}, bytes=22369620' in log
for item in inputs:
    assert digest(fixture/item['relative'])==item['sha256']
assert digest(player)==verify['playerSha256']
pci=(0x10de,0x28e0) if device=='nvidia' else (0x8086,0xa788)
device_report=json.loads((frames/'gpu_capabilities.json').read_text())
assert (device_report['vendor_id'],device_report['device_id'])==pci
assert device_report['resource_access']['enabled']['descriptor_indexing']==indexed
capture=json.loads((frames/'capture_manifest.json').read_text())['referenceSceneDepth']
assert (capture['rowOrigin'],capture['normalFrame'],capture['submission'],capture['width'],capture['height'])==(
    'bottom-left','reference',3,2560,1440)
base_frames=boundary/(base_label+'-frames')
frozen=json.loads((base_frames/'reference-planes.json').read_text())
planes=('raster','hardware','packedNormals','objectIds','objectVisibility')
attachments={}
with zipfile.ZipFile(base_frames/'reference-planes.zip') as archive:
    for name in planes:
        path=frames/capture[name]
        before=frozen[capture[name]]
        native=archive.read(before['archiveEntry'])
        actual=path.read_bytes()
        assert sha256(native).hexdigest()==before['sha256']
        attachments[name]=dict(exact=actual==native,sha256=sha256(actual).hexdigest(),baselineSha256=before['sha256'])
control=json.loads((triple/(device+'-results.json')).read_text())
assert all(item['exact'] for item in control['attachments'].values())
color=runpy.run_path(str(root/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
bounds=tuple(color[name] for name in ('x0','y0','x1','y1'))
assert int(color['mask'].sum())==17017
report=[]
for index in range(3):
    name=f'frame_{index:06d}.png'
    path=frames/name
    expected=triple/(device+'-frames')/name
    same=path.read_bytes()==expected.read_bytes()
    actual=np.asarray(Image.open(path).convert('RGB').crop(bounds))
    delta=np.abs(actual.astype('i4')-color['expected'])[color['mask']].max(axis=1)
    if index==0:
        points=np.argwhere(color['mask'])
        np.column_stack((points[:,1]+bounds[0],points[:,0]+bounds[1],actual[color['mask']],color['expected'][color['mask']])).astype('<u2').tofile(out/(label+'-selected-rgb.bin'))
    report.append(dict(exactDiagnosticPng=same,sha256=digest(path),expectedSha256=control['colors'][index]['after'],
        overOne=int((delta>1).sum()),maximum=int(delta.max())))
previous=json.loads((boundary/(base_label+'-results.json')).read_text())
result=dict(configuration=config,device=device,pci=list(pci),descriptorIndexing=indexed,attachments=attachments,colors=report,validationClean=True,
    allocatorZero=True,playerSha256=digest(player),receiver=previous['receiver'],hairVisibility=previous['hairVisibility'],
    referenceNormal=previous['normal'])
(out/(label+'-results.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
assert all(row['exact'] for row in attachments.values()),attachments
assert all(row['exactDiagnosticPng'] and row['sha256']==row['expectedSha256']
    and row['overOne']==(0 if device=='nvidia' else 32) for row in report),report
