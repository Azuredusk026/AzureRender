
from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys


out=Path(__file__).resolve().parent
build=out.parents[1]
main=Path('D:/Projects/FYP/Project/AzureRender/build')
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
source='2f52c6052918584fbccc13624a92fa5a2e188501'
triple='8db3894c11e2a9dd18616b1aba3a03490080d107'
sys.path.insert(0,str(main.parent/'tools'))
import shared_resources as shared


claim_path=Path('D:/Projects/FYP-coordination/quality-claim.json')
claim=json.loads(claim_path.read_text(encoding='utf-8'))
assert claim['threadId']==owner and claim['state']=='reference-hair-color-triple'
commits=subprocess.check_output(['git','log','-3','--format=%H'],cwd=build.parent,text=True).splitlines()
assert commits==[source,triple,claim['lastCommit']]
base=build.parent/'docs/acceptance/nr/evidence/2026-11-12'
for name,status in (('reference-hair-color-triple','qualified-color-triple-control'),
                    ('native-body-normal-source','qualified-native-body-normal-source')):
    folder=base/name
    result=json.loads((folder/'results.json').read_text())
    assert result['status']==status and sha256((folder/'validation.zip').read_bytes()).hexdigest()==result['archive']['sha256']
previous=Path(claim['taskPath'])
assert previous.name=='20261112-175619-reference-hair-color-triple-d2d080'
body=build/'runs/20261112-180345-native-body-normal-source-43299d'
assert [Path(path) for path in claim['additionalTaskPaths']]==[body]
body_card=json.loads((body/'task-card.json').read_text())
old_local=claim['localInputLease']+[body_card['local']]
old_main=claim['inputLease']+[body_card['main']]


def inherited(root,tokens):
    with shared.maintenance.database(root,True) as db:
        records=shared.maintenance.rows(db)
    assert all(records[token]['owner']==owner for token in tokens)
    return list(dict.fromkeys(name for token in tokens for name in records[token]['inputs']))


local_inputs=list(dict.fromkeys(inherited(build,old_local)+[previous.name,body.name]))
main_inputs=inherited(main,old_main)
local=shared.acquire_inputs(build,out,local_inputs,owner)
try:
    native=shared.acquire_inputs(main,out,main_inputs,owner)
except Exception:
    shared.release_inputs(build,local,owner)
    raise
claim.update(state='projected-hair-point-mip',taskPath=str(out),inputLease=[native],localInputLease=[local],
    nativeCaptureLease=native,lastCommit=source,additionalTaskPaths=[],
    pendingCommand='Validate the opt-in production path against the three-texture diagnostic and the frozen four frames',
    ownedFiles=['src/assets/GltfLoader.cpp','src/assets/GltfLoader.hpp','src/assets/MaterialData.cpp',
                'src/assets/MaterialSurfaceProfile.hpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp',
                'shaders/mesh.frag','schemas/azure_render_material.schema.json','tests/CharacterRepairTests.cpp',
                'docs/acceptance/nr/projected-hair-point-mip.md'])
claim['observed'].update(projectedHairThreeTextureRgbOverOne=32,bodyNormalCompressedLevelsExact=11)
(out/'task-card.json').write_text(json.dumps(dict(local=local,main=native,sourceBase=source,plannedBytes=268435456,
    localInputs=local_inputs,mainInputs=main_inputs,change='Opt-in projected hair primary texture footprint',
    gate='Exact reproduction of the qualified three-texture readbacks, original default four PNGs, and dual configuration regression'),indent=2)+'\n')
temporary=claim_path.with_name(claim_path.name+'.nr-quality-new')
with temporary.open('x',encoding='utf-8') as stream:
    json.dump(claim,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
os.replace(temporary,claim_path)
for token in old_main:
    shared.release_inputs(main,token,owner)
for token in old_local:
    shared.release_inputs(build,token,owner)
print(json.dumps(dict(local=local,main=native,output=str(out))))
