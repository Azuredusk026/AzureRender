
from pathlib import Path
import json
import sys


out=Path(__file__).resolve().parent
sys.path.insert(0,str(out.parents[2]/'tools'))
import artifact_maintenance as maintenance


result=maintenance.guarded_run(out.parents[1],out.name,[sys.executable,'-B',str(out/'verify-build.py'),'Release'],360)
(out/'release-cpu-tests-execution.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
assert result['status']=='exited' and result['exitCode']==0,result
