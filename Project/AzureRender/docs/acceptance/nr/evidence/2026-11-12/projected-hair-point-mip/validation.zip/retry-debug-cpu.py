
from pathlib import Path
import json
import sys


out=Path(__file__).resolve().parent
sys.path.insert(0,str(out.parents[2]/'tools'))
import artifact_maintenance as maintenance


for label,script,args in (('debug-build','recover-debug.py',()),('debug-cpu-tests','verify-build.py',('Debug',))):
    result=maintenance.guarded_run(out.parents[1],out.name,[sys.executable,'-B',str(out/script),*args],390)
    (out/(label+'-execution.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    assert result['status']=='exited' and result['exitCode']==0,result
