from hashlib import file_digest
from pathlib import Path
import json
import subprocess
import sys
import xml.etree.ElementTree as xml


out = Path(__file__).resolve().parent
prior = out.parent / '20261112-164303-reference-hair-mip-boundary-342000'
configuration = sys.argv[1]
assert configuration in ('Release', 'Debug')
config = configuration.lower()
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration == 'Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
baseline_path = out / (config + '-baseline-shaders.json')


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


catalog = {path.name: digest(path) for path in sorted((build / 'shaders').glob('*.spv'))}
player = digest(build / 'AzurePlayer.exe')
previous_player = json.loads((prior / (config + '-verification.json')).read_text())['playerSha256']
assert len(catalog) == 895
if sys.argv[2:] == ['--baseline']:
    assert player == previous_player
    with baseline_path.open('x', encoding='utf-8') as stream:
        json.dump(catalog, stream, indent=2)
    print(json.dumps(dict(configuration=configuration, shaderCount=len(catalog), playerSha256=player)))
    sys.exit(0)

baseline = json.loads(baseline_path.read_text())
changed = {name: dict(before=baseline[name], after=catalog[name]) for name in catalog if catalog[name] != baseline[name]}
assert baseline.keys() == catalog.keys() and player != previous_player
expected={name:dict(before=row['before'],after=row['after'])
    for name,row in json.loads((out/'shader-check.json').read_text()).items() if row['changes']}
assert len(expected)==32 and changed==expected,changed
device = sys.argv[2] if len(sys.argv) > 2 else None
if device:
    assert device in ('nvidia', 'intel')
    prefix = config + '-' + device + '-gpu'
    tests = '^AzureRender[.](ScreenObjectVisibility(Gpu|ReferenceGpu)|ReferenceDepth(Coverage)?Gpu|SurfaceResponseGpu|MaterialUvGradientsGpu)$'
    count = 6
else:
    prefix = config
    editor = '|AzureEditor[.]ProjectFlow' if configuration == 'Release' else ''
    tests = '^(AzureRender[.](ReferenceCameraView|ReferenceCameraBinding|ExtensionRegistry|ScreenObjectVisibility|MaterialCoverage|CharacterRepair|MaterialUvPolicy)|AzureEngine[.]ProjectReferenceViews|AzureAssets[.](MaterialDocument|MaterialUvImport)' + editor + ')$'
    count = 11 if configuration == 'Release' else 10
ctest = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
receipt = out / (prefix + '-ctest.xml')
command = [ctest, '--test-dir', str(build), '-R', tests, '--no-tests=error', '--output-on-failure', '--output-junit', str(receipt)]
log_path = out / (prefix + '-ctest.log')
with log_path.open('wb') as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=310)
assert result.returncode == 0, log_path.read_text(errors='replace')
suite = xml.parse(receipt).getroot()
assert len(suite.findall('.//testcase')) == count
assert not any(suite.findall(path) for path in ('.//failure', './/error', './/skipped'))
record = dict(configuration=configuration, shaderCount=len(catalog), changedShaders=changed, ctestCommand=command,
    ctestExit=result.returncode, tests=count, playerSha256=player)
(out / (prefix + '-verification.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))


