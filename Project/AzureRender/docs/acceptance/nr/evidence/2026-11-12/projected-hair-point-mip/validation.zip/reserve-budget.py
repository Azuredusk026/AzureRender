
from pathlib import Path
import json
import sys


out=Path(__file__).resolve().parent
build=out.parents[1]
sys.path.insert(0,str(build.parent/'tools'))
import artifact_maintenance as maintenance


cap=469762048
used=maintenance.measure(out)
assert used<cap
reservation=maintenance.reserve_write(build,out,used,cap-used)
assert reservation['allowed'],reservation
card=json.loads((out/'task-card.json').read_text())
assert card['plannedBytes']==268435456
card['plannedBytes']=cap
(out/'task-card.json').write_text(json.dumps(card,indent=2)+'\n')
(out/'budget-expansion.json').write_text(json.dumps(dict(used=used,plannedBytes=cap,reservation=reservation),indent=2)+'\n')
print(json.dumps(reservation))
