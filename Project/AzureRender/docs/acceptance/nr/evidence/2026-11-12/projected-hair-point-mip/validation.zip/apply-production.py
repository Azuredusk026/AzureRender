
from pathlib import Path


root=Path(__file__).resolve().parents[3]


def replace(path,old,new):
    path=root/path
    raw=path.read_bytes()
    text=raw.decode('utf-8')
    old=old.replace('\r\n','\n')
    new=new.replace('\r\n','\n')
    if b'\r\n' in raw:
        old=old.replace('\n','\r\n')
        new=new.replace('\n','\r\n')
    assert text.count(old)==1,(path,text.count(old),old)
    path.write_bytes(text.replace(old,new).encode('utf-8'))


header='src/assets/GltfLoader.hpp'
replace(header,'        bool materialSnapshotNormal=false;',
    '        bool materialSnapshotNormal=false;\n        bool axisDiagonalPrimaryTextureFootprint=false;')
replace(header,'inline void validateHairPointMipReferenceNormal(const AssetMaterial& material) {',
'''inline bool usesLinearPointMipSampling(const azurerender::TextureImportSettings& settings) {
    using Settings = azurerender::TextureImportSettings;
    return settings.filter == "linear" && (settings.magFilter == Settings::MagFilter::Linear
        || settings.magFilter == Settings::MagFilter::MatchFilter)
        && settings.mipFilter == Settings::MipFilter::Nearest && settings.anisotropy == 1.F
        && settings.mipPolicy != "none";
}

inline void validateProjectedHairPrimaryTextureFootprint(const AssetMaterial& material) {
    const auto& hair = material.projectedHairRamp;
    if (!hair.axisDiagonalPrimaryTextureFootprint) return;
    if (!hair.present || material.materialClass != AssetMaterialClass::Hair || material.materialProfileVersion != 2
        || (material.materialFeatures & MaterialFeatureMirroredCoarseUv) == 0
        || material.alphaMode == AssetAlphaMode::Blend)
        throw std::invalid_argument("projectedRamp.primaryTextureFootprint requires version two hair with mirrored-coarse-uv");
    for (const unsigned slot : {0U, 6U, 7U}) {
        if (!usesLinearPointMipSampling(material.textureSettings[slot]))
            throw std::invalid_argument("projectedRamp.primaryTextureFootprint requires linear filtering, nearest mip and anisotropy one");
    }
}

inline void validateHairPointMipReferenceNormal(const AssetMaterial& material) {''')
replace(header,'''    const auto& normal = material.textureSettings[1];
    using Settings = azurerender::TextureImportSettings;
''','')
replace(header,'''    if (normal.filter != "linear" || (normal.magFilter != Settings::MagFilter::Linear
        && normal.magFilter != Settings::MagFilter::MatchFilter) || normal.mipFilter != Settings::MipFilter::Nearest
        || normal.anisotropy != 1.F || normal.mipPolicy == "none")
''','''    if (!usesLinearPointMipSampling(material.textureSettings[1]))
''')

loader='src/assets/GltfLoader.cpp'
replace(loader,'''        "directionX","secondaryColor","objectBasis","surfaceResponse","diffuseScale","frame","virtualLight","line","tangentSign","lighting","snapshotNormal"};''',
'''        "directionX","secondaryColor","objectBasis","surfaceResponse","diffuseScale","frame","virtualLight","line","tangentSign",
        "lighting","snapshotNormal","primaryTextureFootprint"};''')
replace(loader,'''    auto& target=result.projectedHairRamp;
    if(source.Has("snapshotNormal")) {''',
'''    auto& target=result.projectedHairRamp;
    if (source.Has("primaryTextureFootprint")) {
        const auto& footprint = source.Get("primaryTextureFootprint");
        if (!footprint.IsString() || footprint.Get<std::string>() != "axis-diagonal")
            throw std::invalid_argument("Invalid projectedRamp.primaryTextureFootprint");
        target.axisDiagonalPrimaryTextureFootprint = true;
    }
    if(source.Has("snapshotNormal")) {''')
replace(loader,'''    azurerender::validateMaterialUvPolicy(result);
    azurerender::validateMaterialRimResponse(result);''',
'''    azurerender::validateMaterialUvPolicy(result);
    validateProjectedHairPrimaryTextureFootprint(result);
    azurerender::validateMaterialRimResponse(result);''')

replace('src/assets/MaterialData.cpp',
'''        lost(source.projectedHairRamp.present&&!replacement.projectedHairRamp.present,"hair.projectedRamp");''',
'''        lost(source.projectedHairRamp.present&&!replacement.projectedHairRamp.present,"hair.projectedRamp");
        lost(source.projectedHairRamp.axisDiagonalPrimaryTextureFootprint
            && !replacement.projectedHairRamp.axisDiagonalPrimaryTextureFootprint,"hair.projectedRamp.primaryTextureFootprint");''')

pack='src/assets/MaterialSurfaceProfile.hpp'
replace(pack,'''    validateHairPointMipReferenceNormal(material);
''','''    validateHairPointMipReferenceNormal(material);
    validateProjectedHairPrimaryTextureFootprint(material);
''')
replace(pack,'''    result.rows[19][3]=material.radianceScale;
    result.rows[21][0]''','''    if (material.projectedHairRamp.axisDiagonalPrimaryTextureFootprint) {
        result.rows[6][3] += 16.F;
        result.rows[12] = {material.textureSettings[0].mipBias, material.textureSettings[6].mipBias,
            material.textureSettings[7].mipBias, 0.F};
    }
    result.rows[19][3]=material.radianceScale;
    result.rows[21][0]''')

renderer='src/scenes/CharacterSceneRenderer.cpp'
replace('src/scenes/CharacterSceneRenderer.hpp','    void createUniformBuffers(bool referenceObjectRaster);',
    '    void createUniformBuffers(bool referenceObjectRaster,float maximumSamplerLodBias);')
replace(renderer,'        createUniformBuffers(referenceObjectRaster);createJointBuffers();',
    '        createUniformBuffers(referenceObjectRaster,limits.maxSamplerLodBias);createJointBuffers();')
replace(renderer,'void CharacterSceneRenderer::createUniformBuffers(bool referenceObjectRaster) {',
    'void CharacterSceneRenderer::createUniformBuffers(bool referenceObjectRaster,float maximumSamplerLodBias) {')
replace(renderer,'            profiles.push_back(packMaterialSurfaceProfile(material));',
'''            auto profile = packMaterialSurfaceProfile(material);
            if (material.projectedHairRamp.axisDiagonalPrimaryTextureFootprint) {
                for (float& bias : profile.rows[12])
                    bias = std::clamp(bias, -maximumSamplerLodBias, maximumSamplerLodBias);
            }
            profiles.push_back(profile);''')

replace('schemas/azure_render_material.schema.json','''          "properties": {
            "snapshotNormal": {''',
'''          "properties": {
            "primaryTextureFootprint": {
              "type": "string",
              "const": "axis-diagonal",
              "description": "使用轴向与对角足迹选择头发基色 RGB、参数和双法线的纹理层级。"
            },
            "snapshotNormal": {''')

shader='shaders/mesh.frag'
replace(shader,'''#include "material_primary_uv.glsl"
#include "material_output_precision.glsl"''',
'''#include "material_primary_uv.glsl"
#if defined(AZURE_REFERENCE_MATERIAL_UV) && !defined(AZURE_OPAQUE_SNAPSHOT) && !defined(AZURE_GEOMETRY_SAMPLES)
#define AZURE_HAIR_PRIMARY_MIP 1
#include "texture_footprint.glsl"
#endif
#include "material_output_precision.glsl"''')
replace(shader,'''float azureMaterialRadianceScale() {
''',
'''#if defined(AZURE_HAIR_PRIMARY_MIP)
vec4 selectProjectedHairPrimaryMip(sampler2D image,vec2 uv,vec4 implicitSample,int biasLane) {
    if(AZURE_MATERIAL_CLASS!=3U)return implicitSample;
    uint profile=material.materialPadding>>1U;
    uint flags=uint(materialSurfaceProfiles.profiles[profile].rows[6].w+.5);
    if((flags&16U)==0u)return implicitSample;
    vec2 size=vec2(textureSize(image,0));
    float lod=azureAxisDiagonalMipLod(azurePrimaryUvDx*size,azurePrimaryUvDy*size);
    float bias=materialSurfaceProfiles.profiles[profile].rows[12][biasLane];
    bool atBoundary=abs(fract(lod+bias)-.5)<=1.0/256.0;
    vec4 explicitSample=textureLod(image,uv,lod);
    return mix(explicitSample,implicitSample,bvec4(atBoundary));
}
vec4 sampleProjectedHairPrimaryMip(sampler2D image,vec2 uv,int biasLane) {
    return selectProjectedHairPrimaryMip(image,uv,azureSamplePrimaryUv(image,uv),biasLane);
}
#else
#define sampleProjectedHairPrimaryMip(image,uv,biasLane) azureSamplePrimaryUv(image,uv)
#endif
float azureMaterialRadianceScale() {
''')
replace(shader,':azureSamplePrimaryUv(AZ_TEX_FACE_SDF,uv);',':sampleProjectedHairPrimaryMip(AZ_TEX_FACE_SDF,uv,2);')
replace(shader,':azureSamplePrimaryUv(AZ_TEX_HAIR_DATA,uv);',':sampleProjectedHairPrimaryMip(AZ_TEX_HAIR_DATA,uv,1);')
replace(shader,':azureSamplePrimaryUv(AZ_TEX_FACE_SDF,textureCoordinate).b;',
    ':sampleProjectedHairPrimaryMip(AZ_TEX_FACE_SDF,textureCoordinate,2).b;')
replace(shader,'''    vec4 baseColor = azureSamplePrimaryUv(AZ_TEX_BASE_COLOR,textureCoordinate);
''','''    vec4 baseColor = azureSamplePrimaryUv(AZ_TEX_BASE_COLOR,textureCoordinate);
#if defined(AZURE_HAIR_PRIMARY_MIP)
    baseColor.rgb=selectProjectedHairPrimaryMip(AZ_TEX_BASE_COLOR,textureCoordinate,baseColor,0).rgb;
#endif
''')
replace(shader,':azureSamplePrimaryUv(AZ_TEX_HAIR_DATA,textureCoordinate);',
    ':sampleProjectedHairPrimaryMip(AZ_TEX_HAIR_DATA,textureCoordinate,1);')
