
from hashlib import file_digest
from pathlib import Path
import json


run=Path(__file__).resolve().parent
compiled=(run/'shader-check').resolve(strict=True)
assert compiled.parent==run
release=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release/shaders'
expected=json.loads((run/'shader-check.json').read_text())
files=list(compiled.iterdir())
assert len(expected)==len(files)==36 and {path.name for path in files}==expected.keys()


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


size=0
for path in files:
    assert path.is_file() and not path.is_symlink() and path.resolve(strict=True).parent==compiled
    expected_sha=expected[path.name]['after']
    assert digest(path)==expected_sha==digest(release/path.name)
    size+=path.stat().st_size
for path in files:
    path.unlink()
compiled.rmdir()
(run/'compacted-shader-check.json').write_text(json.dumps(dict(files=len(files),bytes=size,activeExact=True),indent=2)+'\n')
print(size)
