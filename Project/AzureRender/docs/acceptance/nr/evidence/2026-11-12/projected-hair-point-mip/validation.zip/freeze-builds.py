
from hashlib import file_digest
from pathlib import Path
import json


out=Path(__file__).resolve().parent
boundary=out.parent/'20261112-164303-reference-hair-mip-boundary-342000'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


for config,slug in (('release','20261110-030251-hair-main-chroma-public-9e799c'),
                    ('debug','20261110-031856-hair-main-chroma-debug-668bf2')):
    build=out.parent/slug/config
    prior=json.loads((boundary/(config+'-verification.json')).read_text())
    assert digest(build/'AzurePlayer.exe')==prior['playerSha256']
    baseline=json.loads((boundary/(config+'-baseline-shaders.json')).read_text())
    for name,row in prior['changedShaders'].items():
        assert baseline[name]==row['before']
        baseline[name]=row['after']
    actual={p.name:digest(p) for p in (build/'shaders').glob('*.spv')}
    assert actual==baseline and len(actual)==895
    (out/(config+'-baseline-shaders.json')).write_text(json.dumps(actual,indent=2)+'\n')
    (out/(config+'-baseline-player.json')).write_text(json.dumps(dict(path=str(build/'AzurePlayer.exe'),sha256=prior['playerSha256']),indent=2)+'\n')
    print(config,prior['playerSha256'],len(actual))
