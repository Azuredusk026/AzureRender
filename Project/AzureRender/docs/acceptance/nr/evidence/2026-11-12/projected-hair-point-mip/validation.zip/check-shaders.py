
from hashlib import file_digest
from pathlib import Path
import json
import subprocess


out=Path(__file__).resolve().parent
engine=out.parents[2]
build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
manifest=json.loads((build/'shader-reload.json').read_text())
source=engine/'shaders/mesh.frag'
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
compiled=out/'shader-check'
compiled.mkdir(exist_ok=False)


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


selected=('mesh.frag.spv','mesh_object_coverage.frag.spv','character_snapshot_object_coverage_uvquad.frag.spv',
    'mesh_object_samples_coverage_uvquad.frag.spv')
record={}
for program in manifest['programs']:
    name=program['output']
    defines=set(program['defines'])
    changes=(program['source']=='mesh.frag' and 'AZURE_REFERENCE_MATERIAL_UV=1' in defines
        and not {'AZURE_OPAQUE_SNAPSHOT=1','AZURE_GEOMETRY_SAMPLES=1'}.intersection(defines))
    if not changes and name not in selected:
        continue
    target=compiled/name
    args=[str(sdk/'glslc.exe'),*program['arguments'],*('-D'+flag for flag in program['defines']),str(source),'-o',str(target)]
    subprocess.run(args,check=True)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(target)],check=True)
    before,after=digest(build/'shaders'/name),digest(target)
    assert (before!=after)==changes,(name,before,after)
    record[name]=dict(before=before,after=after,changes=changes,command=args)
assert len(record)==36 and sum(item['changes'] for item in record.values())==32
assert sum('bindless' in name and item['changes'] for name,item in record.items())==16
(out/'shader-check.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(variants=len(record),changed=32,fixed=16,indexed=16,existingExact=len(selected))))
