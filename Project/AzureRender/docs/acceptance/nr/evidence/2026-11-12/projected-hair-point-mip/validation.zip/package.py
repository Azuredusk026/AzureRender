
from hashlib import sha256
from pathlib import Path
import json
import zipfile


run=Path(__file__).resolve().parent
engine=run.parents[2]
evidence=engine/'docs/acceptance/nr/evidence/2026-11-12/projected-hair-point-mip'
configs=('release','debug')
devices=('nvidia','intel')
fixed=tuple(f'{config}-{device}' for config in configs for device in devices)
indexed='release-nvidia-indexed'
labels=(*fixed,indexed)


def read(name):
    return json.loads((run/name).read_text())


def receipt(path):
    result=read(path.name)
    assert result['status']=='exited' and result['exitCode']==0,result
    return result


first=read('first-failed-release-build-execution.json')
assert first['status']=='exited' and first['exitCode']==1
second=read('second-failed-release-cpu-tests-execution.json')
assert second['status']=='exited' and second['exitCode']==1
first_debug=read('first-debug-debug-build-execution.json')
assert first_debug['status']=='budget-stopped' and first_debug['reason']=='managed-pool-limit'
debug_recovery=read('debug-symbols.json')
assert debug_recovery['status']=='recovered' and 'Linking' not in debug_recovery['dryRun']
assert 'fixed lookup sampler violated at slot 5' in (run/'second-failed-release-ctest.log').read_text(errors='replace')
assert 'C3493' in (run/'first-failed-release-build.log').read_text(errors='replace')
assert 'Unknown projectedRamp field: primaryTextureFootprint' in (run/'red-ctest.log').read_text(errors='replace')
assert all((run/(config+'-renderer-typecheck.log')).is_file() for config in configs)
checks={config:read(config+'-verification.json') for config in configs}
assert [checks[config]['tests'] for config in configs]==[11,10]
assert checks['release']['changedShaders']==checks['debug']['changedShaders']
shader_checks=read('shader-check.json')
shader_changes={name:dict(before=row['before'],after=row['after']) for name,row in shader_checks.items() if row['changes']}
assert len(shader_changes)==32 and checks['release']['changedShaders']==shader_changes
assert all(checks[config]['shaderCount']==895 for config in configs)
cases={label:read(label+'-results.json') for label in labels}
for label in labels:
    row=cases[label]
    assert row['validationClean'] and row['allocatorZero'] and len(row['attachments'])==5
    assert all(item['exact'] for item in row['attachments'].values())
    assert all(frame['exactDiagnosticPng'] for frame in row['colors'])
    assert row['descriptorIndexing']==(label==indexed)
    if label!=indexed:
        assert read(label+'-gpu-verification.json')['tests']==6
for device in devices:
    release,debug=(cases[f'{config}-{device}'] for config in configs)
    assert release['attachments']==debug['attachments'] and release['colors']==debug['colors']
    a,b=(run/f'{config}-{device}-frames' for config in configs)
    with zipfile.ZipFile(a/'reference-planes.zip') as left,zipfile.ZipFile(b/'reference-planes.zip') as right:
        assert left.namelist()==right.namelist() and all(left.read(name)==right.read(name) for name in left.namelist())
    for i in range(3):
        name=f'frame_{i:06d}.png'
        assert (a/name).read_bytes()==(b/name).read_bytes()
assert cases[indexed]['attachments']==cases['release-nvidia']['attachments']
assert cases[indexed]['colors']==cases['release-nvidia']['colors']
expected=read('default-four-results.json')
assert expected['allExact'] and expected['validationClean'] and expected['allocatorZero'] and expected['depthCaptureAbsent']
assert len(expected['frames'])==4 and expected['playerSha256']==checks['release']['playerSha256']
executions={p.name.removesuffix('-execution.json'):receipt(p)
    for p in sorted(run.glob('*-execution.json')) if not p.name.startswith(('first-failed-','second-failed-','first-debug-'))}
assert {'release-build','debug-build','debug-prepare','release-cpu-tests','debug-cpu-tests','original-four'}<=executions.keys()
assert all({label+'-capture',label+'-gpu-tests'}<=executions.keys() for label in fixed)
assert indexed+'-capture' in executions
leases={}
for path in run.glob('*-lease-released.json'):
    if path.name.startswith(('first-failed-','second-failed-','first-debug-')):
        continue
    stage=path.name.removesuffix('-lease-released.json')
    value=read(path.name)
    assert value['state']=='released' and value['token']==read(stage+'-lease-held.json')['token']
    leases[stage]=value
assert 'release-capture-all' in leases and len(leases)>=3
layouts={}
for config in configs:
    before=read(f'material-layout-{config}-before.json')
    after=read(f'material-layout-{config}-after.json')
    assert before==after
    layouts[config]=after
fixture=read('fixture-inputs.json')
assert len(fixture['files'])==45 and len(fixture['changed'])==1

evidence.mkdir(parents=True,exist_ok=False)
archive_path=evidence/'validation.zip'
with zipfile.ZipFile(archive_path,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(run.iterdir()):
        if path.is_file() and not path.name.startswith('next-') and path.suffix in ('.py','.json','.log','.xml','.bin'):
            archive.write(path,path.name)
    for label in labels:
        for name in ('capture_manifest.json','reference-planes.json','gpu_capabilities.json'):
            path=run/(label+'-frames')/name
            archive.write(path,path.relative_to(run).as_posix())
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    count=len(archive.namelist())
raw=archive_path.read_bytes()
assert len(raw)<8*1024**2
report=dict(status='qualified-projected-hair-point-mip',overallStatus='failed-user-review',cases=cases,
    verification=checks,layout=layouts,defaultFour=expected,fixture=fixture['changed'],leases=leases,execution=executions,
    firstBuild=first,firstCpuFixture=second,firstDebugBuild=first_debug,debugRecovery=debug_recovery,scope=read('task-card.json'),archive=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw),members=count))
(evidence/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['archive']))
