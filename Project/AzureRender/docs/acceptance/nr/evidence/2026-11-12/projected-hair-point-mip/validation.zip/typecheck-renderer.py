
from pathlib import Path
import re
import subprocess
import sys


out=Path(__file__).resolve().parent
ninja='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
batch='D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'
config,=sys.argv[1:]
assert config in ('release','debug')
build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if config=='release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
target='CMakeFiles/AzureRenderCore.dir/src/scenes/CharacterSceneRenderer.cpp.obj'
command=subprocess.check_output([ninja,'-C',str(build),'-t','commands',target],encoding='utf-8').splitlines()[-1]
assert 'cl.exe ' in command and ' -c ' in command
command=re.sub(r' /F[od]\S+| /showIncludes| /FS','',command).replace(' -c ',' /Zs ')
p=subprocess.run(f'"{batch}" {command}',shell=True,cwd=out,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
log=p.stdout.decode(errors='replace')
(out/(config+'-renderer-typecheck.log')).write_text(log,encoding='utf-8')
assert p.returncode==0,log
print(config,'renderer syntax verified')
