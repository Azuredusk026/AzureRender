
from hashlib import file_digest
from pathlib import Path
import gzip
import json
import subprocess
import sys

from archive_debug_symbols import archive_targets


out=Path(__file__).resolve().parent
build=(out.parent/'20261110-031856-hair-main-chroma-debug-668bf2/debug').resolve(strict=True)
assert build.parent.parent==out.parent.resolve(strict=True)
baseline=json.loads((out/'debug-baseline-player.json').read_text())['sha256']
with (build/'AzurePlayer.exe').open('rb') as stream:
    player=file_digest(stream,'sha256').hexdigest()
assert player!=baseline
symbols=out/'build-symbols'
raw=build/'AzurePlayer.pdb'
partial=symbols/'AzurePlayer.pdb.gz'
interrupted=symbols/'AzurePlayer.pdb.gz.interrupted'
assert partial.resolve(strict=True).parent==symbols.resolve(strict=True) and not interrupted.exists()
assert raw.resolve(strict=True).parent==build and partial.stat().st_size<raw.stat().st_size
partial_size=partial.stat().st_size
try:
    with gzip.open(partial,'rb') as compressed:
        file_digest(compressed,'sha256')
except EOFError:
    pass
else:
    raise AssertionError('Interrupted archive unexpectedly has a complete gzip trailer')
partial.replace(interrupted)
archived=archive_targets(build,['AzurePlayer'])
assert len(archived)==1 and archived[0]['file']=='AzurePlayer.pdb'
assert not raw.exists()
ninja='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
targets=['AzurePlayer','AzureReferenceCameraViewTests','AzureProjectReferenceViewsTests','AzureRenderExtensionRegistryTests',
    'AzureReferenceCameraBindingTests','AzureScreenObjectVisibilityTests','AzureScreenObjectVisibilityGpuTests',
    'AzureReferenceDepthGpuTests','AzureReferenceDepthCoverageGpuTests','AzureSurfaceResponseGpuTests','AzureMaterialCoverageTests',
    'AzureMaterialDocumentTests','AzureCharacterRepairTests','AzureMaterialUvPolicyTests','AzureMaterialUvImportTests',
    'AzureMaterialUvGradientsGpuTests']
plan=subprocess.check_output([ninja,'-C',str(build),'-n',*targets],text=True)
assert '[1/1]' in plan and 'generate_script_bindings.py --check' in plan and 'Linking' not in plan,plan
cmake='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
batch='D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'
argv=[batch,cmake,'--build',str(build),'--target',*targets,'--parallel','1']
with (out/'debug-recovered-build.log').open('wb') as log:
    subprocess.run(subprocess.list2cmdline(argv),shell=True,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
after=subprocess.check_output([ninja,'-C',str(build),'-n',*targets],text=True)
assert after==plan
all_symbols=[]
for path in sorted(symbols.glob('*.pdb.gz')):
    with gzip.open(path,'rb') as stream:
        digest=file_digest(stream,'sha256').hexdigest()
        length=stream.tell()
    assert not (build/path.name.removesuffix('.gz')).exists()
    all_symbols.append(dict(file=path.name.removesuffix('.gz'),bytes=length,sha256=digest,archive=str(path)))
assert any(item==archived[0] for item in all_symbols)
record=dict(status='recovered',playerSha256=player,rawSymbols=archived[0],interruptedBytes=partial_size,
    symbols=all_symbols,dryRun=after,command=argv)
(out/'debug-symbols.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(playerSha256=player,symbols=len(all_symbols),interruptedBytes=partial_size)))
