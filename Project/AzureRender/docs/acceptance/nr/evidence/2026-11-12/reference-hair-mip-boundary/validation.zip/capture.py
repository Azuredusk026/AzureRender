from hashlib import file_digest, sha256
from pathlib import Path
import json
import re
import runpy
import subprocess
import sys
import zipfile
import zlib

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
config, device = sys.argv[1:]
assert config in ('Release', 'Debug') and device in ('nvidia', 'intel')
label = config.lower() + '-' + device
frames = out / (label + '-frames')
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if config == 'Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
prior = out.parent / '20261112-135432-reference-outline-projection-d784cf'
fixture = out.parent / '20261112-153052-reference-hair-mip-footprint-510ded/hair-project'
player = build / 'AzurePlayer.exe'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


previous = json.loads((prior / (label + '-results.json')).read_text())
candidate_player = json.loads((out / (config.lower() + '-verification.json')).read_text())['playerSha256']
assert previous['playerSha256'] != candidate_player and digest(player) == candidate_player
for entry in json.loads((out / 'fixture-inputs.json').read_text())['files']:
    path = fixture / entry['relative']
    assert path.stat().st_size == entry['bytes'] and digest(path) == entry['sha256']
command = [str(player), '--project', str(fixture / 'hair-coverage.azureproject'), '--width', '2560', '--height', '1440',
    '--capture-frames', '3', '--capture-dir', str(frames), '--fixed-frame-step', '--qa-camera', 'scene', '--qa-light', 'scene',
    '--qa-isolation', 'beauty', '--disable-compute-skinning', '--disable-bindless', '--resource-root', str(build)]
(out / (label + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
log_path = out / (label + '.log')
with log_path.open('wb') as log:
    execution = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=240)
log = log_path.read_text(errors='replace')
assert execution.returncode == 0 and 'Allocator after unload: buffers=0 images=0' in log, log[-7000:]
assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]', log, re.I), log[-7000:]
assert 'M_actor_laevat_cloth_01, slot=1, bytes=22369620' in log
capture = json.loads((frames / 'capture_manifest.json').read_text())['referenceSceneDepth']
assert (capture['rowOrigin'], capture['normalFrame'], capture['submission'], capture['width'], capture['height']) == (
    'bottom-left', 'reference', 3, 2560, 1440)
keys = ('raster', 'hardware', 'packedNormals', 'objectIds', 'objectVisibility')
planes = {key: (frames / capture[key]).read_bytes() for key in keys}
assert planes['raster'] == planes['hardware']
assert sha256(planes['raster']).hexdigest() == previous['referenceDepthSha256']
assert sha256(planes['objectIds']).hexdigest() == previous['objectIdsSha256']
baseline_manifest = json.loads((prior / (label + '-frames/reference-planes.json')).read_text())
with zipfile.ZipFile(prior / (label + '-frames/reference-planes.zip')) as archive:
    before = {key: archive.read(baseline_manifest[capture[key]]['archiveEntry']) for key in keys}
assert sha256(before['packedNormals']).hexdigest() == previous['normalsSha256']
assert sha256(before['objectVisibility']).hexdigest() == previous['visibilitySha256']

assert sha256(before['raster']).hexdigest()==previous['referenceDepthSha256']
assert before['raster']==planes['raster'] and before['objectIds']==planes['objectIds']
before_normal=np.frombuffer(before['packedNormals'],'<u4').reshape(1440,2560)
after_normal=np.frombuffer(planes['packedNormals'],'<u4').reshape(1440,2560)
before_rg8=np.frombuffer(before['objectVisibility'],'u1').reshape(1440,2560,2)
after_rg8=np.frombuffer(planes['objectVisibility'],'u1').reshape(1440,2560,2)
assert np.array_equal(before_rg8[...,0],after_rg8[...,0])

numeric=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
native_path=Path(json.loads((numeric/'hair-calibration.json').read_text())['normals'])
assert digest(native_path)=='63731d707e7ba30d9417049c8148b9bd2167208e435e8d9f0cc100a1fd03e095'
native_normal=np.fromfile(native_path,'<u4').reshape(1440,2560)
atlas=out.parent/'20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
native_stages=json.loads((atlas/'native-atlas-producers.json').read_text())
assert native_stages['status']=='qualified'
owners=np.zeros((310,290),dtype='u2')
last=np.zeros_like(owners,'<u4')
for event,stage in native_stages['receiverNormal']['stages'].items():
    item=stage['crop']
    payload=(atlas/item['path']).read_bytes()
    assert sha256(payload).hexdigest()==item['sha256']
    next_normal=np.frombuffer(zlib.decompress(payload),'<u4').reshape(310,290)
    owners[next_normal!=last]=int(event)
    last=next_normal
x,y=np.fromfile(numeric/'receiver-queries.bin','<f4').reshape(-1,4)[:,:2].astype('i4').T
expected=np.fromfile(numeric/'receiver-expected.bin','<u4').astype('i4')
assert len(expected)==49384
receiver_before=before_rg8[y,x,1].astype('i4')
receiver_after=after_rg8[y,x,1].astype('i4')
before_bad=np.abs(receiver_before-expected)>1
after_bad=np.abs(receiver_after-expected)>1
new_bad=~before_bad&after_bad
closed=before_bad&~after_bad
selected_owners=owners[y-1000,x-1140]


def stats(mask):
    return dict(samples=int(mask.sum()),baselineOverOne=int((mask&before_bad).sum()),overOne=int((mask&after_bad).sum()),
        introduced=int((mask&new_bad).sum()),closed=int((mask&closed).sum()),
        normalsChanged=int((mask&(before_normal[y,x]!=after_normal[y,x])).sum()))


receiver=stats(np.ones(len(x),dtype=bool))
assert receiver['baselineOverOne']==previous['receiver']['overOne']
receiver_groups={int(event):stats(selected_owners==event) for event in np.unique(selected_owners)}
introduced=[dict(pixel=[int(x[i]),int(y[i])],owner=int(selected_owners[i]),expected=int(expected[i]),
    baseline=int(receiver_before[i]),current=int(receiver_after[i])) for i in np.flatnonzero(new_bad)]
hair_source=out.parent/'20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
hx,hy=np.fromfile(hair_source/'queries.bin','<f4').reshape(-1,4)[:,:2].astype('i4').T
hair_expected=np.fromfile(hair_source/'expected.bin','<u4').astype('i4')
assert len(hair_expected)==17017
hair_before_rg8=before_rg8[hy,hx,1].astype('i4')
hair_after_rg8=after_rg8[hy,hx,1].astype('i4')
hair_before_visibility_bad=np.abs(hair_before_rg8-hair_expected)>1
hair_after_visibility_bad=np.abs(hair_after_rg8-hair_expected)>1
assert int(hair_before_visibility_bad.sum())==previous['hairVisibilityOverOne']
frozen_normal=native_normal[hy,hx]


def normal_error(values):
    return np.maximum(*[np.abs(((values>>shift)&1023).astype('i4')-((frozen_normal>>shift)&1023).astype('i4'))
        for shift in (0,10)])


before_error=normal_error(before_normal[hy,hx])
after_error=normal_error(after_normal[hy,hx])
normal=dict(baselineExact=int((before_error==0).sum()),exact=int((after_error==0).sum()),
    baselineOverOne=int((before_error>1).sum()),overOne=int((after_error>1).sum()),
    maximum=int(after_error.max()),changed=int((before_normal[hy,hx]!=after_normal[hy,hx]).sum()))
hair_visibility=dict(overOne=int(hair_after_visibility_bad.sum()),baselineOverOne=int(hair_before_visibility_bad.sum()),
    closed=int((hair_before_visibility_bad&~hair_after_visibility_bad).sum()),
    introduced=int((~hair_before_visibility_bad&hair_after_visibility_bad).sum()))

color=runpy.run_path(str(out.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
bounds=color['x0'],color['y0'],color['x1'],color['y1']
current_color=np.asarray(Image.open(frames/'frame_000000.png').convert('RGB').crop(bounds))
before_color=np.asarray(Image.open(prior/(label+'-frames/frame_000000.png')).convert('RGB').crop(bounds))
mask=color['mask']
current_rgb_error=np.abs(current_color.astype('i4')-color['expected'])[mask].max(axis=1)>1
before_rgb_error=np.abs(before_color.astype('i4')-color['expected'])[mask].max(axis=1)>1
assert int(before_rgb_error.sum())==previous['hairColorOverOne']
hair_color=dict(overOne=int(current_rgb_error.sum()),baselineOverOne=int(before_rgb_error.sum()),
    closed=int((before_rgb_error&~current_rgb_error).sum()),introduced=int((~before_rgb_error&current_rgb_error).sum()))
raw_selected=np.column_stack((hx,hy,frozen_normal,before_normal[hy,hx],after_normal[hy,hx],
    hair_expected,hair_before_rg8,hair_after_rg8)).astype('<u4')
raw_selected.tofile(out/(label+'-hair-selected.bin'))
results=dict(configuration=config,device=device,playerSha256=candidate_player,receiver=receiver,receiverByOwner=receiver_groups,
    introduced=introduced,normal=normal,hairVisibility=hair_visibility,hairColor=hair_color,
    validationClean=True,allocatorZero=True,referenceDepthSha256=sha256(planes['raster']).hexdigest(),
    objectIdsSha256=sha256(planes['objectIds']).hexdigest(),normalsSha256=sha256(planes['packedNormals']).hexdigest(),
    visibilitySha256=sha256(planes['objectVisibility']).hexdigest(),colorSha256=[digest(frames/f'frame_{i:06d}.png') for i in range(3)])
(out/(label+'-results.json')).write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({key:value for key,value in results.items() if key!='introduced'}))


