from pathlib import Path
import json
import sys


run=Path(__file__).resolve().parent
configuration,=sys.argv[1:]
assert configuration in ('release','debug')
rows={name:json.loads((run/f'{configuration}-{name}-results.json').read_text()) for name in ('nvidia','intel')}
nvidia,intel=(rows[name] for name in ('nvidia','intel'))
baseline=json.loads((run/'baseline-receipt.json').read_text())[configuration+'-nvidia']
attachments=('referenceDepthSha256','objectIdsSha256','normalsSha256','visibilitySha256','colorSha256')
checks={
    'nvidiaFrozenAttachmentsAndColor':all(nvidia[key]==baseline[key] for key in attachments),
    'nvidiaFrozenHairVisibility':nvidia['hairVisibility']['overOne']==0,
    'nvidiaFrozenHairColor':nvidia['hairColor']['overOne']==0,
    'nvidiaReceiverCount':nvidia['receiver']['overOne']<=nvidia['receiver']['baselineOverOne'],
    'intelReceiverCount':intel['receiver']['overOne']<=intel['receiver']['baselineOverOne'],
    'intelReferenceNormalImproved':intel['normal']['overOne']<intel['normal']['baselineOverOne'],
    'intelFrozenHairVisibilityImproved':intel['hairVisibility']['overOne']<intel['hairVisibility']['baselineOverOne'],
    'intelFrozenHairColor':intel['hairColor']['overOne']<=intel['hairColor']['baselineOverOne'],
}
result=dict(status='qualified' if all(checks.values()) else 'failed-reference-hair-mip-boundary',checks=checks,
    overallStatus='failed-user-review',receiver={name:row['receiver'] for name,row in rows.items()},
    hair={name:{key:row[key] for key in ('normal','hairVisibility','hairColor')} for name,row in rows.items()})
(run/(configuration+'-candidate-gate.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
if not all(checks.values()):
    sys.exit(2)


