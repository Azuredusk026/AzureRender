from hashlib import sha256
from pathlib import Path
import json
import zipfile


run=Path(__file__).resolve().parent
engine=run.parents[2]
baseline=run.parent/'20261112-135432-reference-outline-projection-d784cf'
previous=run.parent/'20261112-153052-reference-hair-mip-footprint-510ded'
evidence=engine/'docs/acceptance/nr/evidence/2026-11-12/reference-hair-mip-boundary'
configs=('release','debug')
adapters=('nvidia','intel')
cases=tuple(f'{config}-{adapter}' for config in configs for adapter in adapters)


def read(name):
    return json.loads((run/name).read_text())


def check_receipt(name):
    result=read(name+'-execution.json')
    assert result['status']=='exited' and result['exitCode']==0
    return result


gates={config:read(config+'-candidate-gate.json') for config in configs}
assert all(gate['status']=='qualified' and all(gate['checks'].values()) for gate in gates.values())
verify={config:read(config+'-verification.json') for config in configs}
assert [verify[config]['tests'] for config in configs]==[8,7]
assert verify['release']['changedShaders']==verify['debug']['changedShaders']
assert {name:item['after'] for name,item in verify['release']['changedShaders'].items()}==read('typecheck.json')['shaderPrograms']
assert verify['release']['shaderCount']==verify['debug']['shaderCount']==895
results={case:read(case+'-results.json') for case in cases}
for case in cases:
    assert read(case+'-gpu-verification.json')['tests']==5
    assert results[case]['validationClean'] and results[case]['allocatorZero']
for adapter in adapters:
    release,debug=(results[f'{config}-{adapter}'] for config in configs)
    ignored=('configuration','playerSha256')
    assert {key:value for key,value in release.items() if key not in ignored}=={
        key:value for key,value in debug.items() if key not in ignored}
    fixed=run/f'release-{adapter}-frames'
    checked=run/f'debug-{adapter}-frames'
    assert (fixed/'reference-planes.json').read_bytes()==(checked/'reference-planes.json').read_bytes()
    with zipfile.ZipFile(fixed/'reference-planes.zip') as left,zipfile.ZipFile(checked/'reference-planes.zip') as right:
        assert left.namelist()==right.namelist() and all(left.read(name)==right.read(name) for name in left.namelist())
    for index in range(3):
        name=f'frame_{index:06d}.png'
        assert (fixed/name).read_bytes()==(checked/name).read_bytes()
        if adapter=='nvidia':
            assert (fixed/name).read_bytes()==(baseline/f'release-{adapter}-frames'/name).read_bytes()

default=read('default-four-results.json')
assert default['allExact'] and default['validationClean'] and default['allocatorZero']
assert default['depthCaptureAbsent'] and len(default['frames'])==4
assert default['playerSha256']==verify['release']['playerSha256']
receipts={path.name.removesuffix('-execution.json'):check_receipt(path.name.removesuffix('-execution.json'))
    for path in sorted(run.glob('*-execution.json'))}
assert {'release-build','release-cpu-tests','release-candidate-gate','debug-prepare','debug-build','debug-cpu-tests',
        'debug-candidate-gate','original-four'}<=receipts.keys()
assert all({case+'-capture',case+'-gpu-tests'}<=receipts.keys() for case in cases)
leases={}
for path in sorted(run.glob('*-lease-released.json')):
    stage=path.name.removesuffix('-lease-released.json')
    item=read(path.name)
    assert item['state']=='released' and item['token']==read(stage+'-lease-held.json')['token']
    leases[stage]=item
assert len(leases)>=2
abi={}
for config in configs:
    before=read(f'material-layout-{config}-before.json')
    after=read(f'material-layout-{config}-after.json')
    assert before['size']==after['size']
    assert all(after['fields'][name]==offset for name,offset in before['fields'].items())
    abi[config]=dict(size=after['size'],fieldOffset=after['fields']['hairPointMipReferenceNormal'])

evidence.mkdir(parents=True,exist_ok=False)
archive_path=evidence/'validation.zip'
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(run.iterdir()):
        if path.is_file() and not path.name.startswith('next-') and path.suffix in ('.py','.cpp','.json','.xml','.log','.spv','.spvasm','.bin'):
            archive.write(path,path.name)
    for case in cases:
        folder=run/(case+'-frames')
        for name in ('capture_manifest.json','gpu_capabilities.json','reference-planes.json'):
            archive.write(folder/name,(folder/name).relative_to(run).as_posix())
    archive.write(previous/'candidate.patch','previous-source/candidate.patch')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    members=len(archive.namelist())
raw=archive_path.read_bytes()
assert len(raw)<8*1024**2
summary=dict(status='qualified-reference-hair-mip-boundary',overallStatus='failed-user-review',
    devices=results,gates=gates,verify=verify,scope=read('task-card.json'),layout=abi,defaultFour=default,
    fixture=read('fixture-inputs.json')['changed'],execution=receipts,leases=leases,
    archive=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw),members=members))
(evidence/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))

