#include "EditorRenderResourceState.hpp"
#include <iostream>

int main() {
    azurerender::SceneDocument scene;
    scene.resources.push_back({"mesh-a", "mesh", "models/a.glb"});
    azurerender::SceneNode placed;
    placed.id = "actor";
    placed.resourceId = "mesh-a";
    scene.nodes.push_back(placed);
    azurerender::EditorRenderResourceState state;
    state.load(scene, [] {});
    scene.resources.push_back({"mesh-b", "mesh", "models/b.glb"});
    if (state.needsReload(scene)) {
        std::cerr << "Importing an unplaced model must leave the renderer idle\n";
        return 1;
    }
    return 0;
}
