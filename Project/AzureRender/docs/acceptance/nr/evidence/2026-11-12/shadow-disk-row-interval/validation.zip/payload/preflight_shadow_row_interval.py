from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json
import math
import numpy as np

root=Path.cwd().resolve()
output=Path(__file__).resolve().parent/'shadow-row-interval-preflight'
output.mkdir(exist_ok=True)
archive=root/'docs/acceptance/nr/evidence/2026-11-08/shadow-disk-kernel/validation.zip'
with ZipFile(archive) as reference:
    parameters=json.loads(reference.read('parameters.json'))
    distribution=np.frombuffer(reference.read('shape-ids.bin'),dtype='u1')
assert len(parameters)==48 and distribution.size==921600 and distribution.max()<48

def row_limits(radius,fraction_x,fraction_y,bound,y):
    near_y=np.minimum(np.abs(y-fraction_y),np.abs(y-fraction_y+np.float32(1)))
    outer=radius+np.float32(.5)
    horizontal_squared=(outer*outer+np.float32(.001))-near_y*near_y
    reach=np.sqrt(np.maximum(horizontal_squared,np.float32(0)))
    first=np.maximum(-bound,np.ceil(fraction_x-reach).astype(np.int32)-1)
    last=np.minimum(bound,np.floor(fraction_x+reach).astype(np.int32))
    first+=(first+bound)&1
    return first,last,horizontal_squared>0

def count(radius,fx,fy):
    radius=np.asarray(radius,dtype=np.float32)
    fx=np.asarray(fx,dtype=np.float32)
    fy=np.asarray(fy,dtype=np.float32)
    bound=np.ceil(radius+np.float32(.5)).astype(np.int32)
    old=np.zeros(len(radius),dtype=np.int32)
    new=np.zeros(len(radius),dtype=np.int32)
    positive=np.zeros(len(radius),dtype=np.int32)
    lost=0
    lanes=np.arange(18,dtype=np.int32)
    x=(-bound[:,None]+2*lanes[None,:])
    in_x=x<=bound[:,None]
    ox=x.astype(np.float32)-fx[:,None]
    dx=np.minimum(np.abs(ox),np.abs(ox+np.float32(1)))
    for i in range(18):
        y=-bound+2*i
        y_f=y.astype(np.float32)
        valid=(y<=bound)[:,None]&in_x
        y0=y_f-fy
        dy=np.minimum(np.abs(y0),np.abs(y0+np.float32(1)))
        nearest=np.sqrt(dx*dx+(dy*dy)[:,None])
        any_positive=(radius+np.float32(.5))[:,None]>nearest
        first,last,row_valid=row_limits(radius,fx,fy,bound,y_f)
        kept=valid&row_valid[:,None]&(x>=first[:,None])&(x<=last[:,None])
        lost+=np.count_nonzero(valid&any_positive&~kept)
        old+=np.count_nonzero(valid,axis=1)
        new+=np.count_nonzero(kept,axis=1)
        positive+=np.count_nonzero(valid&any_positive,axis=1)
    return old,new,positive,lost

frequencies=np.bincount(distribution,minlength=48).astype(np.int64)[1:]
table=np.array([entry['parameters'][:3] for entry in parameters[1:]],dtype=np.float32)
old,new,nonzero,lost=count(*table.T)
assert lost==0 and np.array_equal(old,[entry['calls'] for entry in parameters[1:]])
calls=int(old@frequencies)
remaining=int(new@frequencies)
assert calls==11917189
rng=np.random.default_rng(21689)
total=0
tested_groups=0
missed=0
for trial in range(16):
    size=8192
    fx=rng.random(size,dtype=np.float32)
    fy=rng.random(size,dtype=np.float32)
    if trial<8:
        radius=rng.uniform(.00001,16,size).astype(np.float32)
    else:
        sample_x=rng.integers(-15,17,size).astype(np.float32)
        sample_y=rng.integers(-15,17,size).astype(np.float32)
        distance=np.sqrt((sample_x-fx)**2+(sample_y-fy)**2)-np.float32(.5)
        radius=np.clip(np.nextafter(distance,np.float32(-np.inf if trial%2 else np.inf)),np.float32(.00001),np.float32(16))
    counts,unused1,unused2,lost=count(radius,fx,fy)
    total+=size
    tested_groups+=int(counts.sum())
    missed+=int(lost)
assert missed==0 and total==131072
record=dict(status='geometry-preflight',sourceArchiveSha256=sha256(archive.read_bytes()).hexdigest(),
    capturedWorkShapes=len(parameters),fixturePixels=int(distribution.size),activeFixturePixels=int(frequencies.sum()),
    originalCalls=calls,retainedCalls=remaining,removedCalls=calls-remaining,removedFraction=(calls-remaining)/calls,
    testedFloat32Shapes=total,testedFloat32Groups=tested_groups,omittedPositiveGroups=missed,margin=.001,
    mapping='Same x parity and ascending accumulation order; only zero-weight groups may be skipped.')
(output/'geometry-results.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,indent=2))

