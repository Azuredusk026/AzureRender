from pathlib import Path
import json
import os
import subprocess
import sys
import time

root=Path.cwd().resolve()
out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import digest,inputs
from gpu_environment import wait_and_record,RunEnvironmentMonitor

stage=out.parents[1]
capture=root/'build/runs/20261111-001050-quad-feature-device-capture-4798d1/current_frame320.rdc'
ready=json.loads((out/'qualification.json').read_bytes())
assert digest(capture)==ready['originalCaptureSha256']
original_source=inputs(root)
protected=json.loads((stage/'protected-files.json').read_bytes())
assert len(protected)==13 and all(digest(root/name)==sha for name,sha in protected.items())
settings={'capture':str(capture),'captureSha256':ready['originalCaptureSha256']}
(out/'settings.json').write_text(json.dumps(settings,indent=2)+'\n',encoding='utf-8')
os.environ.update(managed_environment(out/'tmp'))
wait_and_record(out/'startup-environment.json',timeout=60)
startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
executable=Path('D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe')
assert executable.is_file()
command=[str(executable),'--python',str(out/'compare.py')]
start=time.monotonic()
with RunEnvironmentMonitor({},path=out/'run-environment.json',interval=2):
    with (out/'driver.log').open('wb') as log:
        result=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=360)
comparison=json.loads((out/'ab-comparison.json').read_bytes())
assert result.returncode==0 and comparison['status'] in ('measured','pixel-gate-failed'),comparison.get('error',comparison['status'])
assert inputs(root)==original_source and all(digest(root/name)==sha for name,sha in protected.items())
summary={'status':comparison['status'],'allTargetsExact':comparison['allTargetsExact'],'seconds':time.monotonic()-start,
         'captureSha256':settings['captureSha256'],'timings':[]}
if comparison['status']=='measured':
    timings=comparison['timings']
    assert [row['role'] for row in timings]==comparison['roles']
    summary['timings']=[{key:value for key,value in row.items() if key!='milliseconds'} for row in timings]
    baseline=[row['scopeMs']['materials'] for row in timings if row['role']=='qualified']
    candidate=[row['scopeMs']['materials'] for row in timings if row['role']=='candidate']
    average=lambda values:sum(values)/len(values)
    total=average([row['totalMs'] for row in timings if row['role']=='qualified'])
    summary.update(materialShare=average(baseline)/total,materialSavings=1-average(candidate)/average(baseline),
        baselineDrift=abs(baseline[1]-baseline[0])/average(baseline))
    summary['meetsLocalWorkloadAndReduction']=summary['materialShare']>=.25 and summary['materialSavings']>=.20 and summary['baselineDrift']<=.05
(out/'ab-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2),flush=True)

