from pathlib import Path
from hashlib import sha256
import difflib
import json
import shutil
import subprocess
import time

root=Path.cwd().resolve()
stage=Path(__file__).resolve().parent
source=stage/'computed-cascade-demand-preflight/replay'
out=stage/'shadow-row-interval-preflight'
replay=out/'replay'
replay.mkdir(exist_ok=True)
geometry=json.loads((out/'geometry-results.json').read_bytes())
assert geometry['omittedPositiveGroups']==0 and geometry['removedFraction']>.20
prepared=json.loads((source/'qualification.json').read_bytes())
assert len(prepared['programs'])==10
for name in ('previous-comparison.json','replay-profile.json','run_compare.py'):
    shutil.copyfile(source/name,replay/name)
comparison=(source/'compare.py').read_text(encoding='utf-8')
old_path=f"out=Path('{source.as_posix()}')"
assert comparison.count(old_path)==1
(replay/'compare.py').write_text(comparison.replace(old_path,f"out=Path('{replay.as_posix()}')"),encoding='utf-8',newline='\n')

def emit(text):
    old_loop='    for(int y=-bound;y<=bound;y+=2)for(int x=-bound;x<=bound;x+=2){\n'
    old_end='    }\n    return visible/max(totalWeight,1e-6);'
    new_loop='''    float outerRadius=radius+.5;
    float outerSquared=outerRadius*outerRadius+.001;
    for(int y=-bound;y<=bound;y+=2){
        float rowOffset=float(y)-fraction.y;
        float nearestY=min(abs(rowOffset),abs(rowOffset+1.0));
        float horizontalSquared=outerSquared-nearestY*nearestY;
        if(horizontalSquared<=0.0)continue;
        float horizontalReach=sqrt(horizontalSquared);
        int first=max(-bound,int(ceil(fraction.x-horizontalReach))-1);
        int last=min(bound,int(floor(fraction.x+horizontalReach)));
        first+=(first+bound)&1;
        for(int x=first;x<=last;x+=2){
'''
    assert text.count(old_loop)==text.count(old_end)==1
    before,unused,tail=text.partition(old_loop)
    body,unused,after=tail.partition(old_end)
    assert body.lstrip().startswith('vec4 weights=shadowDiskQuadWeights')
    inner=''.join('    '+line for line in body.splitlines(keepends=True))
    return before+new_loop+inner+'        }\n'+old_end+after

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

start=time.monotonic()
programs=[]
for row in prepared['programs']:
    name=row['file']
    previous_binary=source/row['qualified']['path']
    assert digest(previous_binary)==row['qualified']['sha256']
    shutil.copyfile(previous_binary,replay/previous_binary.name)
    previous_args=row['qualified']['command']
    previous_source=Path(previous_args[-3])
    assert previous_source.parent==source and previous_args[-2]=='-o'
    text=previous_source.read_text(encoding='utf-8')
    candidate_source=replay/f'candidate-{previous_source.name.removeprefix("qualified-")}'
    candidate_source.write_text(emit(text),encoding='utf-8',newline='\n')
    program=replay/f'candidate-{name}'
    command=[*previous_args[:-3],str(candidate_source),'-o',str(program)]
    compiled=subprocess.run(command,cwd=root,capture_output=True,timeout=45)
    assert compiled.returncode==0,compiled.stderr.decode(errors='replace')
    validator=Path(command[0]).with_name('spirv-val.exe')
    validated=subprocess.run([str(validator),'--target-env','vulkan1.3','--relax-block-layout',str(program)],cwd=root,capture_output=True,timeout=45)
    assert validated.returncode==0,validated.stderr.decode(errors='replace')
    assert digest(program)!=row['qualified']['sha256']
    programs.append({**row,'candidate':{'path':program.name,'sha256':digest(program),'command':command}})
    print(name,'row interval candidate validated',flush=True)
current=root/'shaders/mesh.frag'
text=current.read_text(encoding='utf-8')
current_candidate=emit(text)
(out/'source.patch').write_text(''.join(difflib.unified_diff(text.splitlines(keepends=True),current_candidate.splitlines(keepends=True),
                  fromfile='a/shaders/mesh.frag',tofile='b/shaders/mesh.frag')),encoding='utf-8',newline='\n')
record={**prepared,'status':'ready-for-local-replay','programs':programs,'seconds':time.monotonic()-start,
        'workloadGeometrySha256':digest(out/'geometry-results.json'),'currentMeshSourceSha256':digest(current)}
(replay/'qualification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')

