from hashlib import sha256
from pathlib import Path
import json
import zlib

import numpy as np


out = Path(__file__).resolve().parent
proof = json.loads((out / 'cross-device-live-atlas.json').read_text())
native = out.parent / '20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
reference = json.loads((native / 'native-atlas-producers.json').read_text())
assert reference['status'] == 'qualified'
tile = (slice(1024, 2048), slice(2048, 3072))
images = {}
for name, path in (('intel', out / 'atlas.bin'),
        ('nvidia', out.parent / '20261112-041837-reference-object-shadow-raster-capture-60f161/atlas.bin')):
    raw = path.read_bytes()
    assert sha256(raw).hexdigest() == proof[name]['sha256']
    images[name] = np.frombuffer(raw, '<u2').reshape(2048, 4096)[tile]
owners = np.zeros((1024, 1024), 'u2')
previous = np.zeros_like(owners, dtype='<u2')
for event, item in reference['stages'].items():
    file = item['tile']
    payload = (native / file['path']).read_bytes()
    assert sha256(payload).hexdigest() == file['sha256']
    current = np.frombuffer(zlib.decompress(payload), '<u2').reshape(owners.shape)
    owners[current != previous] = int(event)
    previous = current
delta = images['intel'].astype('i4') - images['nvidia']
shared = (images['intel'] != 65535) & (images['nvidia'] != 65535)
assert int(shared.sum()) == proof['common'] and np.all(np.abs(delta[shared]) <= 1)


def region(mask):
    return dict(common=int(mask.sum()), exact=int((mask & (delta == 0)).sum()),
        intelLower=int((mask & (delta == -1)).sum()), intelHigher=int((mask & (delta == 1)).sum()))


nvidia_root = out.parent / '20261112-041837-reference-object-shadow-raster-capture-60f161'
nvidia_caster = json.loads((nvidia_root / 'shadow-raster-gpu-proof.json').read_text())['caster']
mesh = {}
for name, folder, caster in (('intel', out, proof['caster']), ('nvidia', nvidia_root, nvidia_caster)):
    raw_positions = zlib.decompress((folder / 'caster-vertices.zlib').read_bytes())
    raw_indices = zlib.decompress((folder / 'caster-indices.zlib').read_bytes())
    assert sha256(raw_positions).hexdigest() == caster['verticesSha256']
    assert sha256(raw_indices).hexdigest() == caster['indicesSha256']
    coordinates = np.ndarray((caster['vertexCount'], 4), '<f4', buffer=raw_positions, strides=(caster['vertexStride'], 4))
    indices = np.frombuffer(raw_indices, {2: '<u2', 4: '<u4'}[caster['indexStride']]).astype('i8') + caster['baseVertex']
    mesh[name] = coordinates, indices
mapping = np.unique(np.column_stack((mesh['intel'][1], mesh['nvidia'][1])), axis=0)
assert len(mapping) == 11564 and all(len(np.unique(mapping[:, index])) == len(mapping) for index in (0, 1))
positions = [mesh[name][0][mapping[:, index]] for index, name in enumerate(('intel', 'nvidia'))]
position_delta = positions[0].astype('f8') - positions[1]
position_error = np.abs(position_delta)
report = dict(tile=region(shared), casterPosition=dict(vertices=len(mapping), exact=int(np.all(position_error == 0, axis=1).sum()),
    componentExact=(position_error == 0).sum(axis=0).tolist(), signedMedian=np.median(position_delta, axis=0).tolist(),
    maximumError=position_error.max(axis=0).tolist(), intelPath='vertex', nvidiaPath='compute'),
    lastNativeWriter={int(event): region(shared & (owners == event))
    for event in np.unique(owners) if np.any(shared & (owners == event))})
(out / 'atlas-device-delta.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'lastNativeWriter'}))
