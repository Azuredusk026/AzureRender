#define main screenObjectVisibilitySyntheticMain
#include "ScreenObjectVisibilityGpuTests.cpp"
#undef main

#include <fstream>
#include <nlohmann/json.hpp>

namespace {
VkImageView uploadAtlas(Inputs& inputs,unsigned width,unsigned height,const std::vector<char>& bytes){
    auto& host=inputs.host;
    auto& backend=*host.backend;
    auto staging=host.allocator.createBuffer(bytes.size(),VK_BUFFER_USAGE_TRANSFER_SRC_BIT,true);
    try{
        std::memcpy(staging.mapped,bytes.data(),bytes.size());
        host.allocator.flush(staging,0,bytes.size());
        inputs.images.push_back(host.allocator.createImage2D(width,height,VK_FORMAT_D16_UNORM,
            VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT|VK_IMAGE_USAGE_SAMPLED_BIT|VK_IMAGE_USAGE_TRANSFER_DST_BIT));
        const auto image=inputs.images.back().image;
        host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer native){
            commands.imageBarrier({image,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,
                VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,VK_ACCESS_TRANSFER_WRITE_BIT,VK_IMAGE_ASPECT_DEPTH_BIT});
            VkBufferImageCopy copy{};
            copy.imageSubresource={VK_IMAGE_ASPECT_DEPTH_BIT,0,0,1};
            copy.imageExtent={width,height,1};
            vkCmdCopyBufferToImage(native,staging.buffer,image,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,&copy);
            commands.imageBarrier({image,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL,1,
                VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,
                VK_ACCESS_SHADER_READ_BIT,VK_IMAGE_ASPECT_DEPTH_BIT});
        });
        inputs.views.push_back(backend.createImageView(image,VK_FORMAT_D16_UNORM,VK_IMAGE_ASPECT_DEPTH_BIT,1));
    }catch(...){host.allocator.destroyBuffer(staging);throw;}
    host.allocator.destroyBuffer(staging);
    return inputs.views.back();
}
}

int main(int argc,char** argv)try{
    require(argc==3,"Expected typed live visibility case and shader directory");
    const auto config=nlohmann::json::parse(std::ifstream(argv[1]));
    const unsigned width=config.at("extent")[0],height=config.at("extent")[1];
    const unsigned atlasWidth=config.at("atlasExtent")[0],atlasHeight=config.at("atlasExtent")[1];
    const VkDeviceSize pixelCount=VkDeviceSize(width)*height;
    const auto payload=[&](const char* key,std::size_t size){
        auto bytes=readBinaryFile(config.at(key).get<std::string>());
        require(bytes.size()==size,"Invalid live attachment size");
        return bytes;
    };
    const auto depth=payload("depth",pixelCount*4),normal=payload("normals",pixelCount*4),ids=payload("objectIds",pixelCount);
    const auto atlas=payload("atlas",VkDeviceSize(atlasWidth)*atlasHeight*2);
    test::VulkanComputeFixture host(true);
    auto& backend=*host.backend;
    {
        Inputs uploaded(host);
        ScreenObjectVisibilityInputs inputs;
        inputs.extent={width,height};
        inputs.depth=uploaded.upload(width,height,VK_FORMAT_R32_SFLOAT,depth.data(),depth.size());
        inputs.normals=uploaded.upload(width,height,VK_FORMAT_A2B10G10R10_UNORM_PACK32,normal.data(),normal.size());
        inputs.objectIds=uploaded.upload(width,height,VK_FORMAT_R8_UINT,ids.data(),ids.size());
        inputs.atlas=uploadAtlas(uploaded,atlasWidth,atlasHeight,atlas);
        inputs.atlasFormat=VK_FORMAT_D16_UNORM;
        inputs.atlasLayout=VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;
        inputs.objectDepth=config.at("atlasForward")?ScreenObjectDepth::Forward:ScreenObjectDepth::Reversed;
        ScreenObjectVisibilityView view;
        view.clipToWorld=config.at("clipToWorld").get<std::array<float,16>>();
        view.pixelOffset=config.at("pixelOffset").get<std::array<float,2>>();
        view.flipNdcY=config.at("flipNdcY");
        const auto& source=config.at("record");
        ScreenObjectVisibilityRecord record;
        record.worldToUnitShadow=source.at("projection").get<std::array<float,16>>();
        record.lightDirection=source.at("lightDirection").get<std::array<float,3>>();
        record.lightBias=source.at("lightBias");
        record.normalBias=source.at("normalBias");
        record.atlasRect=source.at("atlasRect").get<std::array<float,4>>();
        record.filterRadiusUv=source.at("filterRadiusUv").get<std::array<float,2>>();
        record.minimumReceiverDepth=source.at("minimumReceiverDepth");
        record.projectionDepth=source.at("projectionForward")?ScreenObjectDepth::Forward:ScreenObjectDepth::Reversed;
        ScreenObjectVisibilityNumerics numerics;
        if(config.contains("profile")){
            const auto profile=payload("profile",2097152);
            numerics.mode=ScreenObjectVisibilityArithmetic::ProfileV1;
            numerics.reciprocalCorrections.resize(profile.size()/4);
            std::memcpy(numerics.reciprocalCorrections.data(),profile.data(),profile.size());
        }
        ScreenObjectVisibilityGpu owner(backend,inputs.extent,1,ScreenObjectVisibilityShaders::load(argv[2]),numerics);
        auto readback=host.allocator.createBuffer(pixelCount*2,VK_BUFFER_USAGE_TRANSFER_DST_BIT,true);
        try{
            host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer){
                owner.record(commands,0,inputs,view,{record});
                const auto output=owner.output(0);
                commands.imageBarrier({output.image,output.layout,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,1,
                    VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_SHADER_READ_BIT,VK_ACCESS_TRANSFER_READ_BIT});
                commands.copyImageToBuffer(output.image,readback.buffer,inputs.extent);
                commands.bufferBarrier({readback.buffer,0,readback.size,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_HOST_BIT,
                    VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
            });
            host.allocator.invalidate(readback,0,readback.size);
            std::ofstream output(config.at("output").get<std::string>(),std::ios::binary);
            output.write(static_cast<const char*>(readback.mapped),static_cast<std::streamsize>(readback.size));
            require(static_cast<bool>(output),"Cannot write live visibility readback");
        }catch(...){host.allocator.destroyBuffer(readback);throw;}
        host.allocator.destroyBuffer(readback);
    }
    const auto stats=host.allocator.statistics();
    const bool zero=!stats.liveImages&&!stats.liveBuffers;
    std::cout<<nlohmann::json{{"device",host.properties.deviceName},{"vendor",host.properties.vendorID},
        {"zeroAllocator",zero},{"validationErrors",host.errors.load()}}.dump()<<'\n';
    return zero&&!host.errors.load()?0:1;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
