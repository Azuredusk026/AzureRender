from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys

import numpy as np


out = Path(__file__).resolve().parent
root = out.parents[2]
stage = out.parent / '20261112-044926-material-reference-object-visibility-344def'
nvidia = out.parent / '20261112-041837-reference-object-shadow-raster-capture-60f161'
sys.path.insert(0, str(root / 'tools/native_render'))
from renderdoc_capture import fingerprint


actual = json.loads((stage / 'release-intel-results.json').read_text())
argv = json.loads((stage / 'release-intel-command.json').read_text())
assert '--disable-compute-skinning' in argv and '--disable-bindless' in argv
source = Path(argv[0])
identity = fingerprint(source)
assert identity['sha256'] == json.loads((stage / 'release-verification.json').read_text())['playerSha256']
argv[argv.index('--capture-dir') + 1] = str(out / 'host-frames')
argv[argv.index('--capture-frames') + 1] = '4'
argv += ['--runtime-report', str(out / 'host-runtime.json')]
shader = source.parent / 'shaders/screen_object_visibility.frag.spv'
expected = {key: actual[field] for key, field in (('depth', 'referenceDepthSha256'), ('normals', 'referenceNormalsSha256'),
    ('objectIds', 'objectIdsSha256'), ('visibility', 'visibilitySha256'))}
job = dict(operation='capture', source=identity, working_directory=str(source.parent), arguments=argv[1:], output=str(out),
    frame=3, timeout=300, nativeRenderTools=str(root / 'tools/native_render'), shaderSha256=sha256(shader.read_bytes()).hexdigest(),
    expectedSha256=expected, layerPath='D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64;D:/Tools/VulkanSDK/1.4.350.0/Bin')
if '--replay-only' in sys.argv:
    original = out / 'capture-first-report.json'
    if not original.exists():
        shutil.copyfile(out / 'report.json', original)
        shutil.copyfile(out / 'renderdoc.log', out / 'capture-first-renderdoc.log')
    job['captureReceipt'] = json.loads(original.read_text())['captureReceipt']
    assert fingerprint(job['captureReceipt']['capture']['path']) == job['captureReceipt']['capture']
request = out / 'request.json'
request.write_text(json.dumps(job, indent=2) + '\n')
environment = os.environ.copy()
for key in ('VK_LAYER_PATH', 'VK_INSTANCE_LAYERS', 'VK_LAYER_ENABLES', 'VK_DRIVER_FILES', 'VK_ICD_FILENAMES'):
    environment.pop(key, None)
environment.update(AZURE_OBJECT_VISIBILITY_CAPTURE=str(request), VK_LOADER_DRIVERS_SELECT='*igvk64*')
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
command = ['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe', '--python', str(out / 'intel-atlas-worker.py')]
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (out / 'renderdoc.log').open('wb') as log:
    process = subprocess.run(command, env=environment, cwd=out, startupinfo=startup, stdout=log, stderr=subprocess.STDOUT, timeout=520)
report = json.loads((out / 'report.json').read_text())
assert process.returncode == 0 and report['status'] == 'qualified', report
assert fingerprint(source) == identity
host = out / 'host-frames'
assert all(sha256((host / f'frame_{i:06d}.png').read_bytes()).hexdigest() == actual['colors'][i] for i in range(3))
comparison = json.loads((nvidia / 'shadow-raster-gpu-proof.json').read_text())
assert (out / 'parameters.bin').read_bytes() == (nvidia / 'parameters.bin').read_bytes()
assert (out / 'caster-parameters.bin').read_bytes() == (nvidia / 'caster-parameters.bin').read_bytes()
sources = {'nvidia': (nvidia / 'atlas.bin', comparison['atlas']['sha256']), 'intel': (out / 'atlas.bin', report['sources']['atlas']['sha256'])}
images = {}
for name, (path, expected_hash) in sources.items():
    raw = path.read_bytes()
    assert sha256(raw).hexdigest() == expected_hash
    images[name] = np.frombuffer(raw, '<u2')
delta = np.abs(images['intel'].astype('i4') - images['nvidia'])
valid = (images['intel'] != 65535) & (images['nvidia'] != 65535)
result = dict(intel=report['sources']['atlas'], nvidia=comparison['atlas'], caster=report['caster'],
    uniformExact=True, casterUniformExact=True, common=int(valid.sum()), exact=int((valid & (delta == 0)).sum()),
    withinOne=int((valid & (delta <= 1)).sum()), overTwo=int((valid & (delta > 2)).sum()), maximum=int(delta.max()),
    intelOnly=int(((images['intel'] != 65535) & (images['nvidia'] == 65535)).sum()),
    nvidiaOnly=int(((images['intel'] == 65535) & (images['nvidia'] != 65535)).sum()), debugMessages=report['debugMessages'])
(out / 'cross-device-live-atlas.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
