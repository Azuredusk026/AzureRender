from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import runpy
import zipfile

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
engine = out.parents[2]
material = out.parent / '20261112-044926-material-reference-object-visibility-344def'
normal = out.parent / '20261111-232828-scene-reference-normal-60ddfa'
archive_path = engine / 'docs/acceptance/nr/evidence/2026-11-11/native-d3d11-depth-devices/validation.zip'
base = runpy.run_path(str(out.parent / '20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
dy, dx = np.where(base['mask'])
x, y = dx + 1140, 1309 - dy
assert len(x) == 17017
with zipfile.ZipFile(archive_path) as archive:
    raw_depth = archive.read('run/intel-replay/selected-depth.npy')
    manifest = json.loads(archive.read('manifest.json'))
    assert sha256(raw_depth).hexdigest() == manifest['run/intel-replay/selected-depth.npy']['sha256']
    native_depth = np.load(BytesIO(raw_depth), allow_pickle=False)
normal_folder = normal / 'normal-source-replay-intel'
native_normal_receipt = json.loads((normal_folder / 'normal-source.json').read_text())
assert native_normal_receipt['status'] == 'collected' and 'Intel' in native_normal_receipt['replayDevice']
raw_normal = (normal_folder / '699-normal-crop.bin').read_bytes()
native_normal = np.frombuffer(raw_normal, '<u4').reshape(310, 290)[y - 1000, x - 1140]
frame = material / 'release-intel-frames'
attachments = json.loads((frame / 'capture_manifest.json').read_text())['referenceSceneDepth']
case = json.loads((material / 'release-intel-results.json').read_text())
with zipfile.ZipFile(frame / 'reference-planes.zip') as archive:
    def selected(attachment, fingerprint, dtype, shape):
        data = archive.read(attachments[attachment])
        assert sha256(data).hexdigest() == case[fingerprint]
        return np.frombuffer(data, dtype).reshape(shape)[y, x]

    depth = selected('raster', 'referenceDepthSha256', '<u4', (1440, 2560))
    normals = selected('packedNormals', 'referenceNormalsSha256', '<u4', (1440, 2560))
    visibility = selected('objectVisibility', 'visibilitySha256', 'u1', (1440, 2560, 2))[:, 1]
control = normal / 'nvidia-normal-visibility-control-reference-frame'
qx, qy = np.fromfile(control / 'queries.bin', '<f4').reshape(-1, 4)[:, :2].astype('i4').T
expected = np.full((1440, 2560), -1, 'i2')
expected[qy, qx] = np.fromfile(control / 'expected.bin', '<u4')
assert np.all(expected[y, x] >= 0)
bad = np.abs(visibility.astype('i4') - expected[y, x]) > 1
assert bad.sum() == case['hair']['overOne'] == 236
depth_error = np.abs(depth.astype('i8') - native_depth)
normal_error = np.maximum(*[np.abs(((normals >> bit) & 1023).astype('i4') - ((native_normal >> bit) & 1023).astype('i4')) for bit in (0, 10)])
assert (depth_error == 0).sum() == 17014 and (normal_error <= 1).sum() == 17016
frozen_inputs = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f')
with (frozen_inputs / 'native-t6.bin').open('rb') as stream:
    raw = stream.read()
assert sha256(raw).hexdigest() == '63731d707e7ba30d9417049c8148b9bd2167208e435e8d9f0cc100a1fd03e095'
frozen_normal = np.frombuffer(raw, '<u4').reshape(1440, 2560)[y, x]
raw = (frozen_inputs / 'native-t0.bin').read_bytes()
assert sha256(raw).hexdigest() == '02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb'
frozen_depth = np.frombuffer(raw, '<u4').reshape(1440, 2560)[y, x]
color_frame = frame / 'frame_000000.png'
assert sha256(color_frame.read_bytes()).hexdigest() == case['colors'][0]
color = np.asarray(Image.open(color_frame).convert('RGB').crop((1140, 130, 1430, 440))).astype('i4')[base['mask']]
color_bad = np.abs(color - base['expected'][base['mask']]).max(axis=1) > 1
assert color_bad.sum() == case['colorHair']['overOne'] == 580
frozen_normal_error = np.maximum(*[np.abs(((normals >> bit) & 1023).astype('i4') - ((frozen_normal >> bit) & 1023).astype('i4')) for bit in (0, 10)])
frozen_depth_error = np.abs(depth.astype('i8') - frozen_depth)
report = dict(pixels=len(x), visibilityOutsideFrozen=int(bad.sum()), sameDeviceDepthExact=int((depth_error == 0).sum()),
    sameDeviceNormalExact=int((normals == native_normal).sum()), sameDeviceNormalWithinOne=int((normal_error <= 1).sum()),
    residualBothInputsExact=int((bad & (depth_error == 0) & (normals == native_normal)).sum()),
    residualDepthExactNormalWithinOne=int((bad & (depth_error == 0) & (normal_error <= 1)).sum()),
    residualDepthOverOne=int((bad & (depth_error > 1)).sum()), residualNormalOverOne=int((bad & (normal_error > 1)).sum()),
    nativeIntelDepthSelectedSha256=sha256(raw_depth).hexdigest(), nativeIntelNormalCropSha256=sha256(raw_normal).hexdigest(),
    frozenColorIntersections=dict(pixels=int(color_bad.sum()), withVisibilityOverOne=int((color_bad & bad).sum()),
        withNormalOverOne=int((color_bad & (frozen_normal_error > 1)).sum()), withDepthOverOneUlp=int((color_bad & (frozen_depth_error > 1)).sum()),
        withExactDepthAndNormal=int((color_bad & (depth == frozen_depth) & (normals == frozen_normal)).sum())))
(out / 'intel-live-vs-native-inputs.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
