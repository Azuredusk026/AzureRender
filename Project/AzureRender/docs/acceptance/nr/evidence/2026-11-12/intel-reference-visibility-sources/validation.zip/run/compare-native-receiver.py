from hashlib import sha256
from pathlib import Path
import json
import zipfile
import zlib

import numpy as np


out = Path(__file__).resolve().parent
native = out / 'native-normal-explicit-mips'
receipt = json.loads((native / 'explicit-normal-mips.json').read_text())
assert receipt['status'] == 'qualified'
material = out.parent / '20261112-044926-material-reference-object-visibility-344def'
numeric = out.parent / '20261110-003435-visibility-numeric-contract-4f95e7'
normal = out.parent / '20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
expected = {}
for region, q, r, count in (('hair', normal / 'queries.bin', normal / 'expected.bin', 17017),
        ('receiver', numeric / 'receiver-queries.bin', numeric / 'receiver-expected.bin', 49384)):
    x, y = np.fromfile(q, '<f4').reshape(-1, 4)[:, :2].astype('i4').T
    target = np.fromfile(r, '<u4').astype('i4')
    assert len(x) == len(y) == len(target) == count
    expected[region] = x, y, target


def read(device, label, dtype, shape):
    record = receipt['devices'][device]['receiverSources'][label]
    packed = (native / record['file']).read_bytes()
    assert sha256(packed).hexdigest() == record['compressedSha256']
    raw = zlib.decompress(packed)
    assert len(raw) == record['bytes'] and sha256(raw).hexdigest() == record['sha256']
    return np.frombuffer(raw, dtype).reshape(shape)


def stats(values, target):
    difference = np.abs(values.astype('i4') - target.astype('i4'))
    return dict(pixels=len(target), exact=int((difference == 0).sum()), overOne=int((difference > 1).sum()),
        maximum=int(difference.max()))


qualified = {}
for device in ('nvidia', 'intel'):
    frame = material / ('release-' + device + '-frames')
    case = json.loads((material / ('release-' + device + '-results.json')).read_text())
    manifest = json.loads((frame / 'capture_manifest.json').read_text())['referenceSceneDepth']
    with zipfile.ZipFile(frame / 'reference-planes.zip') as archive:
        data = archive.read(manifest['objectVisibility'])
    assert sha256(data).hexdigest() == case['visibilitySha256']
    live = np.frombuffer(data, 'u1').reshape(1440, 2560, 2)
    if 'visibility' not in receipt['devices'][device]['receiverSources']:
        qualified[device] = dict(outputTargets=receipt['devices'][device]['receiverSources']['visibilityTargets'])
        continue
    raw = read(device, 'visibility', 'u1', (1440, 2560, 2))
    regions = {}
    for region, (x, y, target) in expected.items():
        captured, production = raw[y, x, 1], live[y, x, 1]
        frozen_native = stats(captured, target)
        if device == 'nvidia':
            assert frozen_native['exact'] == len(target), (region, frozen_native)
        regions[region] = dict(nativeVsFrozen=frozen_native, liveVsSameDevice=stats(production, captured),
            liveVsFrozen=stats(production, target), bothOutsideFrozen=int(((np.abs(production.astype('i4')-target) > 1)
                & (np.abs(captured.astype('i4')-target) > 1)).sum()))
    qualified[device] = regions


nvidia_atlas = read('nvidia', 'atlas', '<u2', (2048, 4096))
intel_atlas = read('intel', 'atlas', '<u2', (2048, 4096))
shared = (nvidia_atlas != 0) & (intel_atlas != 0)
delta = intel_atlas.astype('i4') - nvidia_atlas
qualified['nativeAtlas'] = dict(shared=int(shared.sum()), exact=int((shared & (delta == 0)).sum()),
    withinOne=int((shared & (np.abs(delta) <= 1)).sum()), lower=int((shared & (delta < 0)).sum()),
    higher=int((shared & (delta > 0)).sum()), overTwo=int((shared & (np.abs(delta) > 2)).sum()),
    maximum=int(np.abs(delta[shared]).max()), intelOnly=int(((intel_atlas != 0) & (nvidia_atlas == 0)).sum()),
    nvidiaOnly=int(((intel_atlas == 0) & (nvidia_atlas != 0)).sum()))
(out / 'native-receiver-comparison.json').write_text(json.dumps(qualified, indent=2) + '\n')
print(json.dumps(qualified))
