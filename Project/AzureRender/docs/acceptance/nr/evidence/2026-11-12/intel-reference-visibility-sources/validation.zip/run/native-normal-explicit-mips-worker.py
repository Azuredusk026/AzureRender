from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import sys
import traceback
import zlib

import renderdoc as rd


job = json.loads(Path(os.environ['AZURE_NATIVE_NORMAL_MIP_REQUEST']).read_text(encoding='utf-8-sig'))
output = Path(job['output'])
sys.path.insert(0, str(output))
from dxbc_util import checksum, chunks, fbits, imm, instructions, opcode, rebuild, words


def with_level(raw, level):
    assert checksum(raw) == raw[4:20]
    parts = chunks(raw)
    index = next(i for i,(kind,_) in enumerate(parts) if kind in (b'SHEX',b'SHDR'))
    body = words(parts[index][1])
    samples = [(at,n) for _,at,op,n in instructions(body) if op == opcode('SAMPLE_B')]
    assert len(samples) == 3
    at,n = samples[2]
    original = body[at:at+n]
    assert original[-2:] == [0,26] and (original[-3] >> 12) & 255 == 8, original
    replacement = original[:-3] + imm(fbits(level))
    replacement[0] = (replacement[0] & 0x80fff800) | opcode('SAMPLE_L') | (len(replacement) << 24)
    body[at:at+n] = replacement
    body[1] = len(body)
    parts[index] = (parts[index][0], struct.pack('<'+'I'*len(body),*body))
    return rebuild(raw,parts)


def receiver_sources(controller, name):
    controller.SetFrameEvent(699, True)
    pipeline = controller.GetPipelineState()
    reflection = pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
    textures = {str(texture.resourceId): texture for texture in controller.GetTextures()}
    bindings = {reflection.readOnlyResources[binding.access.index].fixedBindNumber: binding.descriptor.resource
        for binding in pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel)}
    result = {}

    def read(label, resource, width, height, texel_bytes):
        texture = textures[str(resource)]
        assert (texture.width, texture.height) == (width, height)
        raw = bytes(controller.GetTextureData(resource, rd.Subresource()))
        assert len(raw) == width * height * texel_bytes
        packed = zlib.compress(raw, 6)
        path = output / f'{name}-{label}.zlib'
        path.write_bytes(packed)
        result[label] = dict(resource=str(resource), format=texture.format.Name(), bytes=len(raw),
            sha256=sha256(raw).hexdigest(), compressedSha256=sha256(packed).hexdigest(), file=path.name)

    for label, binding, width, height, size in (('depth',0,2560,1440,4),('atlas',2,4096,2048,2),('normals',6,2560,1440,4)):
        read(label, bindings[binding], width, height, size)
    targets = [binding.resource for binding in pipeline.GetOutputTargets() if binding.resource != rd.ResourceId.Null()]
    visibility = [resource for resource in targets if 'R8G8' in textures[str(resource)].format.Name()
        and (textures[str(resource)].width, textures[str(resource)].height) == (2560, 1440)]
    if len(visibility) == 1:
        read('visibility', visibility[0], 2560, 1440, 2)
    else:
        result['visibilityTargets'] = [dict(resource=str(resource), format=textures[str(resource)].format.Name()) for resource in targets]
    if name == 'nvidia':
        expected = {'depth':'02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb',
            'atlas':'86daee0e01e9c33207679b094bdf5cf31a26d2f93754f11abf6c44df1faecf57',
            'normals':'63731d707e7ba30d9417049c8148b9bd2167208e435e8d9f0cc100a1fd03e095'}
        assert {key: result[key]['sha256'] for key in expected} == expected
    return result


def hair_material_sources(controller, name):
    controller.SetFrameEvent(950, True)
    pipeline = controller.GetPipelineState()
    reflection = pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
    textures = {str(texture.resourceId): texture for texture in controller.GetTextures()}
    text = controller.DisassembleShader(pipeline.GetGraphicsPipelineObject(), reflection, '').encode('utf-8')
    (output / (name + '-950-pixel.asm')).write_bytes(text)
    bindings = {}
    for binding in pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel):
        slot = reflection.readOnlyResources[binding.access.index].fixedBindNumber
        resource = binding.descriptor.resource
        description = textures.get(str(resource))
        if description and slot in (0, 17, 18):
            bindings[slot] = dict(resource=str(resource), format=description.format.Name(), mips=description.mips,
                extent=[description.width, description.height], firstMip=binding.descriptor.firstMip)
    samplers = [dict(index=binding.access.index, mip=str(binding.sampler.filter.mip),
        minify=str(binding.sampler.filter.minify), maxAnisotropy=binding.sampler.maxAnisotropy,
        bias=binding.sampler.mipBias, lod=[binding.sampler.minLOD, binding.sampler.maxLOD])
        for binding in pipeline.GetSamplers(rd.ShaderStage.Pixel)]
    return dict(shaderSha256=sha256(bytes(reflection.rawBytes)).hexdigest(), assemblySha256=sha256(text).hexdigest(),
        textures=bindings, samplers=samplers)


report = {'status':'failed','devices':{}}
capture = rd.OpenCaptureFile()
controller = None
replacement = None
original = None
try:
    assert capture.OpenFile(job['capture'],'',None) == rd.ResultCode.Succeeded
    points = [(x,y) for x,y,_,_ in struct.iter_unpack('<4f', Path(job['queries']).read_bytes())]
    assert len(points) == 17017
    locations = [(int(y)*2560 + int(x))*4 for x,y in points]
    for name,vendor in [('nvidia',rd.GPUVendor.nVidia),('intel',rd.GPUVendor.Intel)]:
        gpu, = [entry for entry in capture.GetAvailableGPUs() if entry.vendor==vendor and rd.GraphicsAPI.D3D11 in entry.apis]
        options = rd.ReplayOptions()
        options.forceGPUVendor=vendor
        options.forceGPUDeviceID=gpu.deviceID
        status,controller=capture.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and controller
        properties=controller.GetAPIProperties()
        assert properties.vendor==vendor and properties.pipelineType==rd.GraphicsAPI.D3D11 and not properties.degraded
        controller.SetFrameEvent(422,True)
        pipe=controller.GetPipelineState()
        reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
        original=pipe.GetShader(rd.ShaderStage.Pixel)
        raw=bytes(reflection.rawBytes)
        target=pipe.GetOutputTargets()[3].resource
        assert str(target)=='ResourceId::141952'
        sampler,=[binding.sampler for binding in pipe.GetSamplers(rd.ShaderStage.Pixel)]
        texture_id,=[binding.descriptor.resource for binding in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel)
            if reflection.readOnlyResources[binding.access.index].fixedBindNumber==1]
        texture=next(item for item in controller.GetTextures() if item.resourceId==texture_id)
        block,=[index for index,item in enumerate(reflection.constantBlocks) if item.bufferBacked and item.fixedBindNumber==0]
        constants=pipe.GetConstantBlock(rd.ShaderStage.Pixel,block,0).descriptor
        sample_bias=struct.unpack('<f',bytes(controller.GetBufferData(constants.resource,constants.byteOffset+26*16,4)))[0]
        def readback():
            controller.SetFrameEvent(422,True)
            data=bytes(controller.GetTextureData(target,rd.Subresource()))
            assert len(data)==2560*1440*4
            return data
        def select(data):
            return b''.join(data[offset:offset+4] for offset in locations)
        baseline=readback()
        baseline_selected=select(baseline)
        (output/(name+'-implicit.bin')).write_bytes(baseline_selected)
        device=dict(gpu=gpu.name,shaderSha256=sha256(raw).hexdigest(),baselineSha256=sha256(baseline).hexdigest(),levels={})
        device['sample']=dict(resource=str(texture_id),format=texture.format.Name(),extent=[texture.width,texture.height],
            mips=texture.mips,sampleBias=sample_bias,samplerBias=sampler.mipBias,lod=[sampler.minLOD,sampler.maxLOD],
            filter=[str(sampler.filter.minify),str(sampler.filter.magnify),str(sampler.filter.mip)],anisotropy=sampler.maxAnisotropy)
        report['devices'][name]=device
        for level in (None,*range(12)):
            bytecode=raw if level is None else with_level(raw,level)
            replacement,errors=controller.BuildTargetShader('main',rd.ShaderEncoding.DXBC,bytecode,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
            assert replacement!=rd.ResourceId.Null(),errors
            controller.ReplaceResource(original,replacement)
            actual=readback()
            if level is None:
                assert actual==baseline
                device['copyControlExact']=True
            else:
                selected=select(actual)
                assert all((a>>6)==(b>>6) for a,b in zip(selected[3::4],baseline_selected[3::4]))
                (output/(name+f'-mip-{level:02d}.bin')).write_bytes(selected)
                device['levels'][level]=dict(attachmentSha256=sha256(actual).hexdigest(),selectedSha256=sha256(selected).hexdigest(),
                    shaderSha256=sha256(bytecode).hexdigest())
            controller.RemoveReplacement(original)
            controller.FreeTargetResource(replacement)
            replacement=None
        assert readback()==baseline
        device['baselineRestored']=True
        device['receiverSources']=receiver_sources(controller,name)
        try:
            device['materialSources']=hair_material_sources(controller,name)
        except Exception as error:
            device['materialSourceError']=str(error)
        device['messages']=[str(message.description) for message in controller.GetDebugMessages()]
        controller.Shutdown()
        controller=None
        original=None
    report['status']='qualified'
except BaseException:
    report['error']=traceback.format_exc()
finally:
    if controller:
        if original: controller.RemoveReplacement(original)
        if replacement: controller.FreeTargetResource(replacement)
        controller.Shutdown()
    capture.Shutdown()
    (output/'explicit-normal-mips.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)
