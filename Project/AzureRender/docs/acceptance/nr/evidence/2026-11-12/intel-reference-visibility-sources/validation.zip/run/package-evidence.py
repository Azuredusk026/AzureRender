from hashlib import sha256
from pathlib import Path
import json
import zipfile
import zlib


out = Path(__file__).resolve().parent
engine = out.parents[2]
target = engine / 'docs/acceptance/nr/evidence/2026-11-12/intel-reference-visibility-sources'
material = out.parent / '20261112-044926-material-reference-object-visibility-344def'
native = out / 'native-normal-explicit-mips'
numerics = out / 'live-numerics'


def read(folder, file):
    return json.loads((folder / file).read_text(encoding='utf-8-sig'))


def digest(data):
    return sha256(data).hexdigest()


atlas = read(out, 'cross-device-live-atlas.json')
delta = read(out, 'atlas-device-delta.json')
assert atlas['uniformExact'] and atlas['casterUniformExact'] and not atlas['debugMessages']
assert atlas['withinOne'] == atlas['common'] == 182219 and atlas['exact'] == 176144
assert delta['tile']['intelHigher'] == 6075 and delta['tile']['intelLower'] == 0
live = read(numerics, 'results.json')
assert live['intel-device']['sameProductionBytes']
assert live['crossDevice-device-hair']['overOne'] == 63 and live['crossDevice-device-receiver']['overOne'] == 202
assert live['crossDevice-profile-hair']['overOne'] == live['crossDevice-profile-receiver']['overOne'] == 0
assert live['intel-native-all']['hair']['overOne'] == live['intel-native-all']['receiver']['overOne'] == 0
previous = read(material, 'default-four-results.json')
build = out.parent / '20261110-030251-hair-main-chroma-public-9e799c/release'
assert previous['allExact'] and digest((build / 'AzurePlayer.exe').read_bytes()) == previous['playerSha256']
native_report = read(native, 'explicit-normal-mips.json')
assert native_report['status'] == 'qualified'
for device in ('nvidia', 'intel'):
    evidence = native_report['devices'][device]
    assert evidence['copyControlExact'] and evidence['baselineRestored'] and len(evidence['levels']) == 12
mip_comparison = read(out, 'native-explicit-mip-comparison.json')
native_comparison = read(out, 'native-receiver-comparison.json')
footprints = read(out, 'native-mip-footprint-comparison.json')
assert footprints['intelAtKnownNvidiaLevel']['availableOverOne'] == 6
assert mip_comparison['crossDevice']['mipDelta']['-1'] == 843
assert native_comparison['intel']['hair']['nativeVsFrozen']['overOne'] == 217


archive = out / 'validation-pending.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as writer:
    def add(path):
        writer.write(path, 'run/' + path.relative_to(out).as_posix())

    for file in sorted(out.iterdir()):
        if file.is_file() and file.suffix in ('.py', '.cpp', '.json', '.xml', '.log'):
            add(file)
    for name in ('caster-vertices.zlib', 'caster-indices.zlib', 'caster-parameters.bin', 'parameters.bin'):
        add(out / name)
    data = (out / 'atlas.bin').read_bytes()
    assert digest(data) == atlas['intel']['sha256']
    writer.writestr('run/atlas.bin.zlib', zlib.compress(data, 9))
    for file in sorted(numerics.rglob('*')):
        if file.is_file() and (file.suffix in ('.json', '.log') or file.name.endswith('-selected.bin')):
            add(file)
    for file in sorted(native.iterdir()):
        if file.is_file() and file.suffix in ('.py', '.hpp', '.txt', '.json', '.log', '.bin'):
            add(file)
    for device, record in native_report['devices'].items():
        for field, source in record['receiverSources'].items():
            if field not in ('depth', 'atlas', 'normals', 'visibility'):
                continue
            payload = (native / source['file']).read_bytes()
            data = zlib.decompress(payload)
            assert digest(payload) == source['compressedSha256'] and digest(data) == source['sha256']
            if field == 'atlas':
                add(native / source['file'])
            else:
                size = 2 if field == 'visibility' else 4
                crop = b''.join(data[(row * 2560 + 1140) * size:(row * 2560 + 1430) * size] for row in range(1000, 1310))
                writer.writestr(f'run/native-normal-explicit-mips/{device}-{field}-crop.zlib', zlib.compress(crop, 9))
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    files = {name: digest(reader.read(name)) for name in reader.namelist()}
assert archive.stat().st_size <= 8 * 1024 * 1024
result = dict(status='qualified-intel-reference-visibility-sources', overall='failed-user-review', baseCommit='fa82f57',
    acceptedMaximumByteError=1, liveAtlas=atlas, atlasDelta=delta, liveNumerics=live,
    sameDeviceInputs=read(out, 'intel-live-vs-native-inputs.json'), nativeMips=mip_comparison,
    mipFootprints={**footprints, 'tests': footprints['tests'][:6]}, nativeReceivers=native_comparison, materialOriginalFour=previous,
    archive=dict(bytes=archive.stat().st_size, sha256=digest(archive.read_bytes()), files=len(files), contents=files))
target.mkdir(parents=True, exist_ok=True)
assert not (target / 'validation.zip').exists() and not (target / 'results.json').exists()
archive.rename(target / 'validation.zip')
(target / 'results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in result['archive'].items() if key != 'contents'}))
