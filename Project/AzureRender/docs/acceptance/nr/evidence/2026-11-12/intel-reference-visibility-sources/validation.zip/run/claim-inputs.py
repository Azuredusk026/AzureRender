from pathlib import Path
import json
import os
import subprocess
import sys


out = Path(__file__).resolve().parent
build = out.parents[1]
main = Path('D:/Projects/FYP/Project/AzureRender/build')
owner = '01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0, str(main.parent / 'tools'))
import shared_resources as shared

claim_path = Path('D:/Projects/FYP-coordination/quality-claim.json')
claim = json.loads(claim_path.read_text(encoding='utf-8'))
assert claim['threadId'] == owner and claim['state'] == 'material-reference-object-visibility-qualification'
assert claim['lastCommit'] == '4bf4e7d43149e632028c8e44555a35403a88115e'
source = subprocess.check_output(['git', 'log', '-1', '--format=%H%n%P%n%s'], cwd=build.parent, encoding='utf-8').splitlines()
assert source[1] == claim['lastCommit'] and source[2] == 'feat(nr-quality): 接入材质参考对象可见量', source
old_local, old_main = claim['localInputLease'], claim['inputLease']


def inherited(root, tokens):
    with shared.maintenance.database(root, True) as db:
        records = shared.maintenance.rows(db)
    assert all(records[token]['owner'] == owner for token in tokens)
    return list(dict.fromkeys(name for token in tokens for name in records[token]['inputs']))


local_inputs = inherited(build, old_local)
for name in ('20261112-044926-material-reference-object-visibility-344def', '20261112-024632-native-atlas-and-receiver-producers-d5e705',
        '20261110-003435-visibility-numeric-contract-4f95e7', '20261110-003031-reciprocal-compact-profile-4e7929',
        '20261112-041837-reference-object-shadow-raster-capture-60f161', '20261111-232828-scene-reference-normal-60ddfa'):
    if name not in local_inputs:
        local_inputs.append(name)
main_inputs = inherited(main, old_main)
local = shared.acquire_inputs(build, out, local_inputs, owner)
try:
    native = shared.acquire_inputs(main, out, main_inputs, owner)
except Exception:
    shared.release_inputs(build, local, owner)
    raise
claim.update(state='intel-reference-visibility-sources', taskPath=str(out), inputLease=[native], localInputLease=[local],
    nativeCaptureLease=native, lastCommit=source[0],
    pendingCommand='Capture the live Intel D16 atlas and qualify device arithmetic, frozen input substitutions and native normal mip selection',
    ownedFiles=['docs/acceptance/nr/'], additionalTaskPaths=[])
claim['observed'].update(materialNvidiaColorOverOne=0, materialIntelColorOverOne=580, materialIntelNativeColorOverlap=571,
    materialIntelSameDeviceColorOverOne=7, materialMatchingIdentityRows=181, materialDifferentIdentityPositions=1144,
    materialCrossConfigurationExact=True)
(out / 'task-card.json').write_text(json.dumps(dict(local=local, main=native, sourceBase=source[0],
    plannedBytes=536870912, localInputs=local_inputs, mainInputs=main_inputs), indent=2) + '\n')
temporary = claim_path.with_name(claim_path.name + '.nr-quality-new')
with temporary.open('x', encoding='utf-8') as stream:
    json.dump(claim, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
os.replace(temporary, claim_path)
for token in old_main:
    shared.release_inputs(main, token, owner)
for token in old_local:
    shared.release_inputs(build, token, owner)
print(json.dumps(dict(local=local, main=native, output=str(out))))
