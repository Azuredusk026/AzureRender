from hashlib import file_digest
from pathlib import Path
import json
import os
import subprocess


out = Path(__file__).resolve().parent
capture = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc')
capture_sha = 'fa2ca267f7168f5603e83ad5f817a3074d8dbee23a216e6ab8ef2c340ec06a90'
raster_sha = '02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb'


def verify_capture():
    with capture.open('rb') as stream:
        assert file_digest(stream, 'sha256').hexdigest() == capture_sha


verify_capture()
folder = out / 'native-caster-geometry'
folder.mkdir()
request = folder / 'request.json'
request.write_text(json.dumps(dict(capture=str(capture), output=str(folder),
    captureSha256=capture_sha, rasterDepthSha256=raster_sha), indent=2) + '\n')
env = os.environ.copy()
for key in ('VK_LAYER_PATH', 'VK_INSTANCE_LAYERS', 'ENABLE_VULKAN_RENDERDOC_CAPTURE',
        'VK_LOADER_DRIVERS_SELECT', 'VK_DRIVER_FILES', 'VK_ICD_FILENAMES'):
    env.pop(key, None)
env['AZURE_CASTER_GEOMETRY_REQUEST'] = str(request)
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
command = ['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe', '--python',
    str(out / 'native-caster-geometry-worker.py')]
with (folder / 'process.log').open('wb') as log:
    result = subprocess.run(command, env=env, startupinfo=startup, cwd=folder, stdout=log,
        stderr=subprocess.STDOUT, timeout=240)
receipt = json.loads((folder / 'native-caster-geometry.json').read_text())
assert result.returncode == 0 and receipt['status'] == 'qualified', receipt
verify_capture()
print(json.dumps(dict(device=receipt['device'], atlasEvents=list(receipt['atlasDraws']),
    depthEvents=list(receipt['receiverDepth']), programEvents=list(receipt['receiverDraws']))))
