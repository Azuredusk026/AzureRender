from pathlib import Path
import json
import re
import subprocess
import sys


out = Path(__file__).resolve().parent
engine = out.parents[2]
build = out.parent / '20261110-030251-hair-main-chroma-public-9e799c/release'
ninja = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
batch = 'D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'
target = 'AzureScreenObjectVisibilityGpuTests'
commands = subprocess.check_output([ninja, '-C', str(build), '-t', 'commands', target], encoding='utf-8').splitlines()
old_object = f'CMakeFiles\\{target}.dir\\tests\\ScreenObjectVisibilityGpuTests.cpp.obj'
original = str(engine / 'tests/ScreenObjectVisibilityGpuTests.cpp')
obj = str(out / 'live-visibility-numerics.obj')
source = str(out / 'live-visibility-numerics.cpp')
compile_line, = [line for line in commands if 'cl.exe ' in line and old_object in line]
compile_line = compile_line.replace(old_object, obj).replace(original, source)
assert source in compile_line and original not in compile_line
compile_line = re.sub(r' /Fd\S+| /showIncludes| /FS', '', compile_line)
compile_line += ' /I' + str(engine / 'tests')
link_line, = [line for line in commands if 'link.exe ' in line and f'/out:{target}.exe' in line]
link_line = re.search(r'\S+\\link\.exe .+?(?= &&|"$)', link_line).group(0)
link_line = link_line.replace(old_object, obj)
for option, extension in (('out', 'exe'), ('implib', 'lib'), ('pdb', 'pdb')):
    link_line = link_line.replace(f'/{option}:{target}.{extension}', f'/{option}:' + str(out / ('live-visibility-numerics.' + extension)))
assert obj in link_line and str(out / 'live-visibility-numerics.exe') in link_line
commands = [f'"{batch}" {line}' for line in (compile_line, link_line)]
(out / 'numerics-build-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
if '--plan' in sys.argv:
    print(json.dumps(dict(compiler=compile_line.split()[0], link=link_line.split()[0], output=obj)))
    raise SystemExit(0)
with (out / 'numerics-build.log').open('wb') as log:
    for command in commands:
        subprocess.run(command, shell=True, cwd=build, stdout=log, stderr=subprocess.STDOUT, check=True)
