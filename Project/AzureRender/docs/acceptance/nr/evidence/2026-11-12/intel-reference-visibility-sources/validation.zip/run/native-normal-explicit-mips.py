from hashlib import file_digest, sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import zipfile

import numpy as np


out=Path(__file__).resolve().parent
root=out.parents[2]
prior=out.parent/'20261111-232828-scene-reference-normal-60ddfa'
native=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc')
reference_sha='fa2ca267f7168f5603e83ad5f817a3074d8dbee23a216e6ab8ef2c340ec06a90'
with native.open('rb') as stream:assert file_digest(stream,'sha256').hexdigest()==reference_sha
queries=prior/'nvidia-normal-visibility-control-reference-frame/queries.bin'
assert sha256(queries.read_bytes()).hexdigest()=='2ffff6e92f0fac8fe5b79d4fd6eb6e7c4c4fe1b9ae5eb38b2eb0cc8cbee3a7e8'
folder=out/'native-normal-explicit-mips'
folder.mkdir()
worker=folder/'worker.py'
shutil.copyfile(out/'native-normal-explicit-mips-worker.py',worker)
with zipfile.ZipFile(root/'docs/acceptance/nr/evidence/2026-11-10/hair-final-float-values/validation.zip') as archive:
    for name in ('dxbc_util.py','D3D12TokenizedProgramFormat.hpp','LICENSE-RenderDoc.txt'):
        (folder/name).write_bytes(archive.read(name))
request=folder/'request.json'
request.write_text(json.dumps(dict(capture=str(native),queries=str(queries),output=str(folder)),indent=2)+'\n')
env=os.environ.copy()
for key in ('VK_LAYER_PATH','VK_INSTANCE_LAYERS','ENABLE_VULKAN_RENDERDOC_CAPTURE','VK_LOADER_DRIVERS_SELECT','VK_DRIVER_FILES','VK_ICD_FILENAMES'):
    env.pop(key,None)
env['AZURE_NATIVE_NORMAL_MIP_REQUEST']=str(request)
startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(worker)]
(folder/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (folder/'process.log').open('wb') as log:
    process=subprocess.run(command,env=env,startupinfo=startup,cwd=folder,stdout=log,stderr=subprocess.STDOUT,timeout=360)
replay=json.loads((folder/'explicit-normal-mips.json').read_text())
assert process.returncode==0 and replay['status']=='qualified',replay
with native.open('rb') as stream:assert file_digest(stream,'sha256').hexdigest()==reference_sha


def compare(first,second):
    return np.maximum(*[np.abs(((first>>shift)&1023).astype('i4')-((second>>shift)&1023).astype('i4')) for shift in (0,10)])


implicit={name:np.fromfile(folder/(name+'-implicit.bin'),'<u4') for name in ('nvidia','intel')}
native_difference=compare(implicit['nvidia'],implicit['intel'])>1
summary={}
inferred={}
for name,original in implicit.items():
    levels=np.stack([np.fromfile(folder/(name+f'-mip-{level:02d}.bin'),'<u4') for level in range(12)])
    errors=compare(levels,original)
    exact=levels==original
    summary[name]=dict(samples=len(original),exactSomeLevel=int(exact.any(axis=0).sum()),
        withinOneSomeLevel=int((errors<=1).any(axis=0).sum()),exactUniqueLevel=int((exact.sum(axis=0)==1).sum()))
    inferred[name]=np.where(exact.sum(axis=0)==1,exact.argmax(axis=0),-1)
both=(inferred['nvidia']>=0)&(inferred['intel']>=0)
differences=inferred['intel']-inferred['nvidia']
summary['crossDevice']=dict(nativeOverOne=int(native_difference.sum()),uniqueBoth=int(both.sum()),
    uniqueAmongDifferences=int((both&native_difference).sum()),mipDelta={int(value):int(count) for value,count in
        zip(*np.unique(differences[both&native_difference],return_counts=True))})
(out/'native-explicit-mip-comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
