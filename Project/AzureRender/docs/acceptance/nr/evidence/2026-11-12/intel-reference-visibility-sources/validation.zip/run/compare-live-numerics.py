from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import subprocess
import zipfile

import numpy as np


out = Path(__file__).resolve().parent
material = out.parent / '20261112-044926-material-reference-object-visibility-344def'
numeric = out.parent / '20261110-003435-visibility-numeric-contract-4f95e7'
normal = out.parent / '20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
build = out.parent / '20261110-030251-hair-main-chroma-public-9e799c/release'
intel = json.loads((material / 'release-intel-results.json').read_text())
atlas = json.loads((out / 'cross-device-live-atlas.json').read_text())
frozen = json.loads((numeric / 'hair-calibration.json').read_text())
folder = out / 'live-numerics'
folder.mkdir()


def checked(path, digest):
    data = path.read_bytes()
    assert sha256(data).hexdigest() == digest
    return data


for field, digest in (('depth', '02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb'),
        ('normals', '63731d707e7ba30d9417049c8148b9bd2167208e435e8d9f0cc100a1fd03e095'),
        ('atlas', '86daee0e01e9c33207679b094bdf5cf31a26d2f93754f11abf6c44df1faecf57'),
        ('profile', 'bbda0d685ab5a66767c2c3881a67dff147e1f5a2c766db1f6dd5b63fecedcf2c')):
    checked(Path(frozen[field]), digest)
checked(out / 'atlas.bin', atlas['intel']['sha256'])
nvidia_atlas = out.parent / '20261112-041837-reference-object-shadow-raster-capture-60f161/atlas.bin'
checked(nvidia_atlas, atlas['nvidia']['sha256'])
frames = material / 'release-intel-frames'
manifest = json.loads((frames / 'capture_manifest.json').read_text())['referenceSceneDepth']
with zipfile.ZipFile(frames / 'reference-planes.zip') as archive:
    actual = {}
    for field, attachment, fingerprint in (('depth', 'raster', 'referenceDepthSha256'),
            ('normals', 'packedNormals', 'referenceNormalsSha256'), ('objectIds', 'objectIds', 'objectIdsSha256')):
        raw = archive.read(manifest[attachment])
        assert sha256(raw).hexdigest() == intel[fingerprint]
        path = folder / (field + '.bin')
        path.write_bytes(raw)
        actual[field] = str(path)
    original = archive.read(manifest['objectVisibility'])
assert sha256(original).hexdigest() == intel['visibilitySha256']
original = np.frombuffer(original, 'u1').reshape(1440, 2560, 2)
parameters = (out / 'parameters.bin').read_bytes()
view = struct.unpack_from('<20f4I', parameters)
assert view[20:] == (1, 1, 1, 0)
record = struct.unpack_from('<28f', parameters, 96)
base = dict(**actual, atlas=str(out / 'atlas.bin'), extent=[2560, 1440], atlasExtent=[4096, 2048], atlasForward=True,
    clipToWorld=view[:16], pixelOffset=view[18:20], flipNdcY=True, record=dict(projection=record[:16], lightDirection=record[16:19],
        lightBias=record[19], normalBias=record[20], filterRadiusUv=record[21:23], minimumReceiverDepth=record[23],
        atlasRect=record[24:28], projectionForward=False))
profile = dict(base, profile=frozen['profile'])
cases = (('intel-device', 'intel', base), ('nvidia-device-same-input', 'nvidia', base), ('intel-profile', 'intel', profile),
    ('nvidia-profile-same-input', 'nvidia', profile), ('intel-nvidia-live-atlas', 'intel', dict(profile, atlas=str(nvidia_atlas))),
    ('intel-native-atlas', 'intel', dict(profile, atlas=frozen['atlas'], atlasForward=False)),
    ('intel-native-depth', 'intel', dict(profile, depth=frozen['depth'])), ('intel-native-normal', 'intel', dict(profile, normals=frozen['normals'])),
    ('intel-native-all', 'intel', dict(profile, depth=frozen['depth'], normals=frozen['normals'], atlas=frozen['atlas'], atlasForward=False)))
regions = {}
for name, points, reference, count in (('hair', normal / 'queries.bin', normal / 'expected.bin', 17017),
        ('receiver', numeric / 'receiver-queries.bin', numeric / 'receiver-expected.bin', 49384)):
    x, y = np.fromfile(points, '<f4').reshape(-1, 4)[:, :2].astype('i4').T
    target = np.fromfile(reference, '<u4').astype('i4')
    assert len(x) == len(y) == len(target) == count
    regions[name] = (x, y, target, np.abs(original[y, x, 1].astype('i4') - target) > 1)


reports = {}
selections = {}
for name, adapter, config in cases:
    case = folder / name
    case.mkdir()
    request = case / 'request.json'
    output = case / 'visibility.bin'
    request.write_text(json.dumps(dict(config, output=str(output)), indent=2) + '\n')
    command = [str(out / 'live-visibility-numerics.exe'), str(request), str(build / 'shaders')]
    env = os.environ.copy()
    for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES', 'VK_LOADER_DRIVERS_SELECT'):
        env.pop(key, None)
    env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if adapter == 'intel' else '*nv-vk64*',
        VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LAYER_VALIDATE_SYNC='1', PATH=str(build) + os.pathsep + env['PATH'])
    process = subprocess.run(command, cwd=build, env=env, capture_output=True, timeout=95)
    (case / 'process.log').write_bytes(process.stdout + process.stderr)
    assert process.returncode == 0, (name, process.stdout, process.stderr)
    receipt = json.loads(process.stdout.splitlines()[-1])
    assert receipt['vendor'] == (0x8086 if adapter == 'intel' else 0x10de) and receipt['zeroAllocator'] and not receipt['validationErrors']
    raw = output.read_bytes()
    assert len(raw) == 2560 * 1440 * 2
    output_sha = sha256(raw).hexdigest()
    image = np.frombuffer(raw, 'u1').reshape(1440, 2560, 2)
    assert np.all(image[:, :, 0] == 255)
    receipt.update(sha256=output_sha, sameProductionBytes=output_sha == intel['visibilitySha256'])
    for region, (x, y, target, prior_bad) in regions.items():
        values = image[y, x, 1].astype('i4')
        difference = np.abs(values - target)
        bad = difference > 1
        receipt[region] = dict(pixels=len(target), exact=int((difference == 0).sum()), overOne=int(bad.sum()),
            maximum=int(difference.max()), closed=int((prior_bad & ~bad).sum()), introduced=int((~prior_bad & bad).sum()))
        payload = values.astype('u1').tobytes()
        (case / (region + '-selected.bin')).write_bytes(payload)
        selections[name, region] = values
    output.unlink()
    reports[name] = receipt
    (folder / 'results.json').write_text(json.dumps(reports, indent=2) + '\n')
    if name == 'intel-device':
        assert receipt['sameProductionBytes'], receipt

for mode in ('device', 'profile'):
    for region in regions:
        first, second = (selections[name, region] for name in ('intel-' + mode, 'nvidia-' + mode + '-same-input'))
        delta = np.abs(first - second)
        reports['crossDevice-' + mode + '-' + region] = dict(exact=int((delta == 0).sum()), overOne=int((delta > 1).sum()), maximum=int(delta.max()))
(folder / 'results.json').write_text(json.dumps(reports, indent=2) + '\n')
print(json.dumps(reports))
