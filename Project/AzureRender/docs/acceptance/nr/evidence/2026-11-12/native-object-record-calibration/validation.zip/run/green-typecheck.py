from pathlib import Path
import json
import os
import subprocess

out=Path(__file__).resolve().parent
engine=out.parents[2]
main=Path('D:/Projects/FYP/Project/AzureRender')
environment=os.environ.copy()
temporary=out/'tmp'
temporary.mkdir(exist_ok=True)
for key in ('TMP','TEMP','TMPDIR'):
    environment[key]=str(temporary)
include=main/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Include')
sources=['tests/ReferenceCameraViewTests.cpp','src/render/ReferenceCameraViewJson.cpp']
args=[str(main/'tools/msvc_env.bat'),'cl','/nologo','/Zs','/std:c++20','/EHsc','/utf-8',
    '/I'+str(engine/'src'),'/I'+str(include),'/I'+str(sdk),*[str(engine/path) for path in sources]]
command=subprocess.list2cmdline(args)
run=subprocess.run(command,shell=True,cwd=out,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(out/'green-typecheck.log').write_bytes(run.stdout)
diagnostic=run.stdout.decode(errors='replace')
print(diagnostic)
assert run.returncode==0,diagnostic
(out/'green-typecheck.json').write_text(json.dumps(dict(exit=run.returncode,sources=sources,command=args),indent=2)+'\n')
