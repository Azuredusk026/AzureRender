from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess

out=Path(__file__).resolve().parent
build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
player=build/'AzurePlayer.exe'
assert sha256(player.read_bytes()).hexdigest()=='011e4c2f7a271c732ff7fb950b39a4af6e5fdec8f062bb082fc079d426bfdf5f'
temporary=out/'tmp'
temporary.mkdir(exist_ok=True)
environment=os.environ.copy()
for key in ('VK_ICD_FILENAMES','VK_LOADER_DRIVERS_SELECT','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES'):
    environment.pop(key,None)
environment.update(VK_DRIVER_FILES=str(out/'disabled-driver.json'),TMP=str(temporary),TEMP=str(temporary),TMPDIR=str(temporary))
command=[str(player),'--project',str(out/'hair-project/hair-coverage.azureproject'),'--width','2560','--height','1440',
    '--qa-camera','scene','--qa-light','scene','--resource-root',str(build)]
with (out/'runtime-red.log').open('wb') as log:
    result=subprocess.run(command,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=50)
output=(out/'runtime-red.log').read_text(errors='replace')
assert result.returncode!=0 and 'Unexpected reference camera fields' in output,output
(out/'runtime-red-result.json').write_text(json.dumps(dict(exitCode=result.returncode,expectedSchemaRejection=True,
    command=command,playerSha256=sha256(player.read_bytes()).hexdigest()),indent=2)+'\n')
print(output)
