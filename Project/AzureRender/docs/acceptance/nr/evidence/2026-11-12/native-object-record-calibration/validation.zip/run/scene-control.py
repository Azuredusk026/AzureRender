from hashlib import sha256
from pathlib import Path
import base64
import copy
import json
import re
import struct
import subprocess
import sys

import numpy as np


out=Path(__file__).resolve().parent
root=out.parents[2]
sys.path.insert(0,str(root/'tools'))
from native_render.light_lab import generate


configuration=sys.argv[1]
assert configuration in ('Release','Debug')
folder=out/('scene-control-'+configuration.lower())
build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
generate(folder,'dark')


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def component(name,data):
    return dict(type=name,version=1,data=data)


def quad(x0,x1,y0,y1,z):
    return (x0,y0,z,x1,y0,z,x1,y1,z,x0,y1,z)


positions=quad(-.82,.82,-.75,.75,0)+quad(-.45,-.05,-.35,.35,.5)
normals=[0,0,1]*8
texcoords=[0,0,1,0,1,1,0,1]*2
indices=[0,1,2,0,2,3,4,5,6,4,6,7]
payload=struct.pack('<24f24f16f12H',*positions,*normals,*texcoords,*indices)
mesh_path=folder/'plane.gltf'
mesh=json.loads(mesh_path.read_text())
mesh['buffers']=[dict(byteLength=len(payload),uri='data:application/octet-stream;base64,'+base64.b64encode(payload).decode())]
mesh['bufferViews']=[dict(buffer=0,byteOffset=offset,byteLength=size) for offset,size in ((0,96),(96,96),(192,64),(256,24))]
for field in mesh['accessors'][:3]:field['count']=8
mesh['accessors'][0].update(min=[-.82,-.75,0],max=[.82,.75,.5])
mesh['accessors'][3]['count']=12
mesh['materials'][0]['doubleSided']=True
write(mesh_path,mesh)

level=folder/'level.azurelevel'
scene=json.loads(level.read_text())
geometry,camera,light=scene['nodes']
anchor=camera['components']['azure.transform']['data']['translation']
selection=dict(enabled=True,view='objects',anchorPosition=anchor,anchorRight=[1,0,0],anchorUp=[0,1,0],anchorBack=[0,0,1])
camera['components']['azure.reference-camera']=component('azure.reference-camera',selection)
geometry['components']={'azure.object-shadow':component('azure.object-shadow',dict(enabled=True,atlasPage=6,
    halfExtents=[1.5,1.5,2],filterRadiusX=0,filterRadiusY=0,normalBias=.005,lightBias=.0025))}
scene['lights']=[dict(id='main',nodeId=light['id'],color=[1,1,1],intensity=1,enabled=True,radius=1,
    shape=dict(type='directional',direction=[.70710678,0,-.70710678],falloff='legacy'))]
config=folder/'config'
config.mkdir()
inputs=dict(schemaVersion=1,extent=[128,128],depthConvention='reversed',flipNdcY=False,produceSceneDepth=True,
    produceSceneVisibilityInputs=True,frame=dict(schemaVersion=1,axes=[1,2,3],offset=[0,0,0]),
    projection=dict(schemaVersion=1,columns=[[1,0,0,0],[0,-1,0,0],[0,0,.25,0],[0,0,.5,1]],jitter=[0,0]))
objects=dict(inputs,objectVisibility=dict(pixelOffset=[.5,.5]))
permuted=dict(objects,frame=dict(schemaVersion=1,axes=[3,2,-1],offset=[0,0,0]),
    projection=dict(schemaVersion=1,columns=[[0,0,.25,0],[0,-1,0,0],[-1,0,0,0],[0,0,.5,1]],jitter=[0,0]))
calibrated=dict(permuted,objectVisibility=dict(pixelOffset=[.5,.5],calibration=dict(schemaVersion=1,
    positionOffset=[6,5,-4],clipToWorld=[0,0,-1,0,0,-1,0,0,4,0,0,0,4,5,-4,1])))
direction=np.array([.70710678,0,-.70710678],dtype='f4')
def dot(a,b):
    return (a[0]*b[0]+a[1]*b[1])+a[2]*b[2]
direction*=np.float32(1)/np.sqrt(dot(direction,direction))
right=np.cross(np.array([0,1,0],dtype='f4'),direction)
right/=np.sqrt(dot(right,right))
vertical=np.cross(direction,right)
world_to_unit=np.eye(4,dtype='f4')
world_to_unit[:3,:3]=np.stack([right,vertical,direction])*np.array([.5/1.5,.5/1.5,.5/2],dtype='f4')[:,None]
world_to_unit[:3,3]=.5
relative_to_world=np.eye(4)
relative_to_world[:3,:3]=np.array([[0,0,-1],[0,1,0],[1,0,0]])
relative_to_world[:3,3]=-relative_to_world[:3,:3]@np.array([6,5,-4])
forward_to_reversed=np.eye(4)
forward_to_reversed[2,2]=-1
forward_to_reversed[2,3]=1
reference_to_unit=(forward_to_reversed@world_to_unit@relative_to_world).astype('f4')
source_light=relative_to_world[:3,:3].T@direction.astype('f8')
calibrated['objectVisibility']['calibration']['objectRecords']=[dict(atlasPage=6,
    anchorWorldToUnit=world_to_unit.T.reshape(-1).tolist(),referenceToUnit=reference_to_unit.T.reshape(-1).tolist(),
    lightDirection=source_light.tolist())]
write(config/'reference-views.json',dict(schemaVersion=1,views=dict(inputs=inputs,objects=objects,permuted=permuted,calibrated=calibrated)))

reports={}
planes={}
sample_x=[0,48,80,106]
for mode in ('objects','calibrated','moved','light','light-calibrated','inputs','neutral'):
    fixture=copy.deepcopy(scene)
    fixture['nodes'][1]['components']['azure.reference-camera']['data']['view']=('objects' if mode in ('neutral','light')
        else 'calibrated' if mode in ('moved','light-calibrated') else mode)
    if mode=='moved':
        fixture['nodes'][0]['components']['azure.transform']=component('azure.transform',dict(translation=[1,0,0]))
        fixture['nodes'][1]['components']['azure.transform']['data']['translation']=[1,0,5]
    if mode in ('light','light-calibrated'):
        fixture['lights'][0]['shape']['direction']=[-.70710678,0,-.70710678]
    if mode=='neutral':fixture['nodes'][0]['components'].pop('azure.object-shadow')
    write(level,fixture)
    write(folder/(mode+'.azurelevel'),fixture)
    frames=folder/mode
    command=[str(build/'AzurePlayer.exe'),'--project',str(folder/'lab.azureproject'),'--width','128','--height','128',
        '--capture-dir',str(frames),'--capture-frames','3','--fixed-frame-step','--qa-camera','scene','--qa-light','scene',
        '--qa-isolation','albedo','--disable-bindless','--resource-root',str(build)]
    if configuration=='Debug':command.append('--disable-parallel-recording')
    write(folder/(mode+'-command.json'),command)
    log_path=folder/(mode+'.log')
    with log_path.open('wb') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=160)
    log=log_path.read_text(errors='replace')
    assert result.returncode==0 and 'Allocator after unload: buffers=0 images=0' in log,log[-7000:]
    assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I),log[-7000:]
    capture=json.loads((frames/'capture_manifest.json').read_text())['referenceSceneDepth']
    assert capture['rowOrigin']=='bottom-left' and capture['normalFrame']=='reference' and capture['submission']==3
    raster=(frames/capture['raster']).read_bytes()
    assert raster==(frames/capture['hardware']).read_bytes()
    depth=np.frombuffer(raster,'<f4').reshape(128,128)
    assert depth[64,sample_x].tolist()==[0,.625,.5,.5],depth[64,sample_x]
    ids=(frames/capture['objectIds']).read_bytes()
    normal=(frames/capture['packedNormals']).read_bytes()
    assert set(ids)==({0} if mode=='neutral' else {0,1})
    planes[mode]=(raster,ids,normal)
    reports[mode]=dict(depthSha256=sha256(raster).hexdigest(),objectIdsSha256=sha256(ids).hexdigest(),
        packedNormalSha256=sha256(normal).hexdigest(),depth=depth[64,sample_x].tolist())
    if mode=='inputs':
        assert 'objectVisibility' not in capture and not list(frames.glob('*visibility-rg8*'))
        continue
    data=(frames/capture['objectVisibility']).read_bytes()
    assert len(data)==128*128*2
    rg=np.frombuffer(data,'u1').reshape(128,128,2)
    assert np.all(rg[:,:,0]==255)
    assert np.all(rg[:,:,1][np.frombuffer(ids,'u1').reshape(128,128)==0]==255)
    green=rg[64,sample_x,1].tolist()
    if mode=='neutral':assert np.all(rg==255)
    elif mode not in ('light','light-calibrated'):
        assert green[0]==255 and green[2]==0 and green[3]==255,green
    reports[mode].update(visibilitySha256=sha256(data).hexdigest(),visibility=green,nonFull=int((rg[:,:,1]<255).sum()))

assert planes['objects']==planes['inputs']
assert planes['objects'][:2]==planes['calibrated'][:2]==planes['moved'][:2]
assert reports['objects']['visibilitySha256']==reports['calibrated']['visibilitySha256']==reports['moved']['visibilitySha256']
assert reports['light']['visibilitySha256']==reports['light-calibrated']['visibilitySha256']
assert reports['light']['visibilitySha256']!=reports['objects']['visibilitySha256']
write(folder/'summary.json',dict(cases=reports,outputOnlyWhenSelected=True,signedFrameExact=True,lightRotationExact=True,
    rigidCameraMoveExact=True,validationClean=True,allocatorZero=True))
print(json.dumps(reports))
