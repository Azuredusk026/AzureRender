from hashlib import sha256
from pathlib import Path
import json
import shutil
import sys

source_file=Path(__file__).with_name('native-object-record-source.json')
out=Path(sys.argv[1]).resolve(strict=True)
assert out.parent.name=='runs' and out.parent.parent.name=='build'
base=out.parent/'20261112-020715-scene-visibility-reference-calibration-f77af1'
original=(base/'hair-project').resolve(strict=True)
fixture=out/'hair-project'
assert not fixture.exists()
native=json.loads(source_file.read_text())
expected=json.loads((base/'hair-fixture-inputs.json').read_text())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

files=[]
for item in expected:
    source=Path(item['destination']).resolve(strict=True)
    relative=source.relative_to(original)
    destination=fixture/relative
    assert source.is_file() and not source.is_symlink() and digest(source)==item['sha256']
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,destination)
    files.append(dict(relative=relative.as_posix(),source=str(source),destination=str(destination),sha256=item['sha256']))
configuration=fixture/'config/reference-views.json'
contents=json.loads(configuration.read_text())
calibration=contents['views']['native-hair']['objectVisibility']['calibration']
assert calibration==native['camera'] and 'objectRecords' not in calibration
calibration['objectRecords']=[native['record']]
configuration.write_text(json.dumps(contents,indent=2)+'\n')
for item in files:
    if Path(item['destination'])==configuration:item['sha256']=digest(configuration)
    assert digest(Path(item['destination']))==item['sha256']
assert len(files)==42 and sum(Path(item['destination']).stat().st_size for item in files)<220_000_000
(out/'hair-fixture-inputs.json').write_text(json.dumps(files,indent=2)+'\n')
(out/'native-object-record-source.json').write_text(source_file.read_text())
print(f'Prepared {len(files)} project files and the reference object record')
