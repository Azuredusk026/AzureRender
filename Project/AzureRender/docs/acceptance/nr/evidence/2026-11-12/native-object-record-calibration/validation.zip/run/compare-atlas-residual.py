from hashlib import sha256
from pathlib import Path
import json
import zipfile

import numpy as np

out=Path(__file__).resolve().parent
isolation=out.parent/'20261112-013522-scene-visibility-atlas-source-33c6c3'
normal=out.parent/'20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
numeric=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
frames=out/'release-nvidia-frames'
measured=json.loads((out/'release-nvidia-results.json').read_text())
with zipfile.ZipFile(frames/'reference-planes.zip') as archive:
    payload=archive.read('reference-object-visibility-rg8.bin')
assert sha256(payload).hexdigest()==measured['visibilitySha256']
image=np.frombuffer(payload,'u1').reshape(1440,2560,2)
result={}
for scope,queries,expected in [('hair',normal/'queries.bin',normal/'expected.bin'),
        ('receiver',numeric/'receiver-queries.bin',numeric/'receiver-expected.bin')]:
    x,y=np.fromfile(queries,'<f4').reshape(-1,4)[:,:2].astype('i4').T
    reference=np.fromfile(expected,'<u4').astype('i4')
    actual=image[y,x,1].astype('i4')
    control=np.fromfile(isolation/f'{scope}-atlas'/f'nvidia-{scope}-atlas-rg8.bin','u1').reshape(-1,2)[:,1].astype('i4')
    actual_failure=np.abs(actual-reference)>1
    atlas_failure=np.abs(control-reference)>1
    delta=np.abs(actual-control)
    result[scope]=dict(pixels=len(reference),productionOverOne=int(actual_failure.sum()),atlasOnlyOverOne=int(atlas_failure.sum()),
        productionAndAtlasOverOne=int((actual_failure&atlas_failure).sum()),productionOutsideAtlasOverOne=int((actual_failure&~atlas_failure).sum()),
        exactComparedToAtlasOnly=int((delta==0).sum()),withinOneComparedToAtlasOnly=int((delta<=1).sum()),maximumAgainstAtlasOnly=int(delta.max()))
assert result['hair']['productionOverOne']==measured['hair']['overOne'] and result['receiver']['productionOverOne']==measured['receiver']['overOne']
(out/'nvidia-atlas-residual.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
