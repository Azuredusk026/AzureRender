from pathlib import Path
import json
import os
import sys

out=Path(__file__).resolve().parent
root=out.parents[1]
main=Path('D:/Projects/FYP/Project/AzureRender/build')
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0,str(main.parent/'tools'))
import shared_resources as shared

claim_path=Path('D:/Projects/FYP-coordination/quality-claim.json')
claim=json.loads(claim_path.read_text(encoding='utf-8'))
assert claim['threadId']==owner and claim['lastCommit']=='b9fb7347ad3fe3866eb482a5fdcb9684ccd75636'
assert claim['state']=='visibility-projection-depth-four-frame-regression'
old_main=claim['inputLease']
old_local=claim['localInputLease']

def prior_inputs(build,tokens):
    with shared.maintenance.database(build,True) as db:
        records=shared.maintenance.rows(db)
    assert all(records[token]['owner']==owner for token in tokens)
    return list(dict.fromkeys(name for token in tokens for name in records[token]['inputs']))

local_inputs=prior_inputs(root,old_local)+['20261112-025941-visibility-projection-depth-c1c792']
main_inputs=prior_inputs(main,old_main)
local=shared.acquire_inputs(root,out,local_inputs,owner)
try:
    native=shared.acquire_inputs(main,out,main_inputs,owner)
except Exception:
    shared.release_inputs(root,local,owner)
    raise
new_commit='bc12f326f258e6dc92fc3fcafef205c52f1be08d'
claim.update(state='native-object-record-calibration-red',taskPath=str(out),inputLease=[native],
    localInputLease=[local],nativeCaptureLease=native,lastCommit=new_commit,
    pendingCommand='Verify native record schema, exact authored anchor and live object/light movement',
    ownedFiles=['src/render/ReferenceCameraView.hpp','src/render/ReferenceCameraViewJson.cpp',
        'src/render/ReferenceCameraCalibration.hpp','src/render/RenderContext.hpp','src/render/SceneReferenceObjectVisibility.hpp',
        'src/scenes/CharacterReferenceSceneDepth.inc','tests/ReferenceCameraViewTests.cpp','tests/ExtensionRegistryTests.cpp'],
    additionalTaskPaths=[])
(out/'task-card.json').write_text(json.dumps(dict(local=local,main=native,sourceBase=new_commit,plannedBytes=536870912,
    localInputs=local_inputs,mainInputs=main_inputs),indent=2)+'\n')
temporary=claim_path.with_name(claim_path.name+'.nr-quality-new')
with temporary.open('x',encoding='utf-8') as stream:
    json.dump(claim,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
os.replace(temporary,claim_path)
for token in old_main:shared.release_inputs(main,token,owner)
for token in old_local:shared.release_inputs(root,token,owner)
print(json.dumps(dict(local=local,main=native,output=str(out))))
