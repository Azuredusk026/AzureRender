from pathlib import Path
import json
import zipfile

import numpy as np

out=Path(__file__).resolve().parent
native=out.parent/'20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
queries=np.fromfile(native/'queries.bin','<f4').reshape(-1,4)
x,y=queries[:,:2].astype('i4').T
expected=np.fromfile(native/'expected.bin','<u4').astype('i4')
assert len(x)==17017
inputs={}
outputs={}
for device in ('nvidia','intel'):
    folder=out/f'release-{device}-frames'
    manifest=json.loads((folder/'capture_manifest.json').read_text())['referenceSceneDepth']
    with zipfile.ZipFile(folder/'reference-planes.zip') as archive:
        def packed(field):
            return np.frombuffer(archive.read(manifest[field]),'<u4').reshape(1440,2560)[y,x]
        inputs[device]=(packed('raster'),packed('packedNormals'))
        outputs[device]=np.frombuffer(archive.read(manifest['objectVisibility']),'u1').reshape(1440,2560,2)[y,x,1].astype('i4')
common=(inputs['nvidia'][0]==inputs['intel'][0])&(inputs['nvidia'][1]==inputs['intel'][1])
nvidia=np.abs(outputs['nvidia']-expected)>1
intel=np.abs(outputs['intel']-expected)>1
cross=np.abs(outputs['nvidia']-outputs['intel'])
result=dict(sameDepthAndNormal=int(common.sum()),sameInputsBothOutOfGate=int((common&nvidia&intel).sum()),
    sameInputsOnlyIntelOutOfGate=int((common&~nvidia&intel).sum()),
    sameInputsOnlyNvidiaOutOfGate=int((common&nvidia&~intel).sum()),
    sameInputsOutputsOverOne=int((common&(cross>1)).sum()),sameInputsMaximumCrossDevice=int(cross[common].max()))
(out/'hair-cross-device-source.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
