from pathlib import Path
import json
import sys
import zipfile

import numpy as np

out=Path(__file__).resolve().parent
atlas=out.parent/'20261112-013522-scene-visibility-atlas-source-33c6c3'
old=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
normal=out.parent/'20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
device=sys.argv[1]
assert device in ('nvidia','intel')
config=json.loads((old/'hair-calibration.json').read_text())
source_depth=np.fromfile(config['depth'],'<u4').reshape(1440,2560)
source_normals=np.fromfile(config['normals'],'<u4').reshape(1440,2560)
case=out/f'release-{device}-frames'
manifest=json.loads((case/'capture_manifest.json').read_text())['referenceSceneDepth']
with zipfile.ZipFile(case/'reference-planes.zip') as archive:
    actual=np.frombuffer(archive.read('reference-object-visibility-rg8.bin'),'u1').reshape(1440,2560,2)
    depth=np.frombuffer(archive.read('reference-depth-r32.bin'),'<u4').reshape(1440,2560)
    normals=np.frombuffer(archive.read(manifest['packedNormals']),'<u4').reshape(1440,2560)
coordinates={}
statistics={}
for scope,queries,expected in [('hair',normal/'queries.bin',normal/'expected.bin'),
        ('receiver',old/'receiver-queries.bin',old/'receiver-expected.bin')]:
    x,y=np.fromfile(queries,'<f4').reshape(-1,4)[:,:2].astype('i4').T
    coordinates[scope]=(x,y)
    target=np.fromfile(expected,'<u4').astype('i4')
    delta=np.abs(actual[y,x,1].astype('i4')-target)
    bad=delta>1
    same_depth=depth[y,x]==source_depth[y,x]
    same_normal=normals[y,x]==source_normals[y,x]
    entry=dict(pixels=len(target),overOne=int(bad.sum()),over64=int((delta>64).sum()),
        inputDepthExact=int(same_depth.sum()),inputNormalExact=int(same_normal.sum()),
        overOneWithExactInputs=int((bad&same_depth&same_normal).sum()),
        over64WithExactInputs=int(((delta>64)&same_depth&same_normal).sum()))
    if device=='nvidia':
        masks={}
        for label in ('atlas','record','inverse'):
            probe=np.fromfile(atlas/(scope+'-'+label)/f'nvidia-{scope}-{label}-rg8.bin','u1').reshape(-1,2)
            masks[label]=np.abs(probe[:,1].astype('i4')-target)>1
        entry['previousIsolationOverlap']={label:int((bad&mask).sum()) for label,mask in masks.items()}
        entry['bothAtlasAndRecord']=int((bad&masks['atlas']&masks['record']).sum())
        entry['atlasOrRecord']=int((bad&(masks['atlas']|masks['record'])).sum())
    if scope=='receiver':
        hair_x,hair_y=coordinates['hair']
        in_hair=np.isin(y*2560+x,hair_y*2560+hair_x)
        entry['nonhair']=dict(pixels=int((~in_hair).sum()),overOne=int((bad&~in_hair).sum()),
            over64=int(((delta>64)&~in_hair).sum()),overOneWithExactInputs=int((bad&~in_hair&same_depth&same_normal).sum()),
            overOneWithDepthOnlyExact=int((bad&~in_hair&same_depth&~same_normal).sum()),
            overOneWithNormalOnlyExact=int((bad&~in_hair&~same_depth&same_normal).sum()),
            overOneWithNeitherInputExact=int((bad&~in_hair&~same_depth&~same_normal).sum()))
    statistics[scope]=entry
(out/f'{device}-remaining-source-intersection.json').write_text(json.dumps(statistics,indent=2)+'\n')
print(json.dumps(statistics))
