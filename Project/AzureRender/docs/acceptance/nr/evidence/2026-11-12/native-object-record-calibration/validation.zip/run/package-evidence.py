from hashlib import sha256
from pathlib import Path
import json
import zipfile

out=Path(__file__).resolve().parent
root=out.parents[2]
diagnostic=out.parent/'20261112-033450-native-object-record-source-capture-071c26'
target=root/'docs/acceptance/nr/evidence/2026-11-12/native-object-record-calibration'

def read(folder,name):
    return json.loads((folder/name).read_text(encoding='utf-8'))

def digest(data):
    return sha256(data).hexdigest()

labels=tuple(f'{configuration}-{device}' for configuration in ('release','debug') for device in ('nvidia','intel'))
captures={name:read(out,name+'-results.json') for name in labels}
for name,case in captures.items():
    assert case['validationClean'] and case['allocatorZero'],name
    for region,pixels in (('hair',17017),('receiver',49384)):
        data=case[region]
        assert data['pixels']==pixels and data['baselineOverOne']-data['closed']+data['introduced']==data['overOne'],(name,region)
configurations=read(out,'cross-configuration.json')
assert all(all(configurations[device].values()) for device in ('nvidia','intel')) and configurations['sceneControlsExact']
original=read(out,'default-four-results.json')
assert original['allExact'] and original['depthCaptureAbsent'] and original['validationClean'] and original['allocatorZero']
builds={key:read(out,key+'-verification.json') for key in ('release','debug',*(name+'-gpu' for name in labels))}
assert all(not value['ctestExit'] and value['shaderCount']==891 for value in builds.values())
assert len({json.dumps(value['changedShaders'],sort_keys=True) for value in builds.values()})==1
source=read(out,'native-object-record-source.json')
residual=read(out,'nvidia-atlas-residual.json')
assert residual['hair']['productionAndAtlasOverOne']==residual['hair']['productionOverOne']
assert residual['hair']['withinOneComparedToAtlasOnly']==17017
cross_device=read(out,'hair-cross-device-source.json')
assert cross_device['sameDepthAndNormal']==7182 and cross_device['sameInputsOutputsOverOne']==28
symbols=read(out,'debug-symbol-budget-recovery.json')
assert symbols['playerSha256']==builds['debug']['playerSha256']
oracle=read(out,'object-record-affine-oracle.json')
assert oracle['cases']==1024 and oracle['maximumAbsoluteError']<1.e-10
proof=read(diagnostic,'native-record-gpu-proof.json')
assert proof['inverseExact'] and proof['projectionExact'] and proof['lightExact']
assert proof['projectionSha256']==source['sources']['nativeReferenceToUnitSha256']
assert proof['visibility']['sha256']==captures['release-nvidia']['visibilitySha256']
target.mkdir(parents=True,exist_ok=False)
archive=target/'validation.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as writer:
    def add(path,prefix='run'):
        base=out if prefix=='run' else diagnostic
        writer.write(path,prefix+'/'+path.relative_to(base).as_posix())
    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py','.json','.xml','.log'):
            add(path)
    for label in labels:
        folder=out/(label+'-frames')
        for name in ('capture_manifest.json','gpu_capabilities.json','reference-planes.json'):
            add(folder/name)
        if label.startswith('release-'):add(folder/'reference-planes.zip')
    for config in ('release','debug'):
        folder=out/('scene-control-'+config)
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix in ('.json','.log','.gltf','.azurelevel','.azureproject'):
                add(path)
        add(folder/'config/reference-views.json')
        for mode in ('objects','calibrated','moved','light','light-calibrated','inputs','neutral'):
            add(folder/mode/'capture_manifest.json')
            if mode!='inputs':add(folder/mode/'reference-object-visibility-rg8.bin')
    add(out/'default-four-frames/capture_manifest.json')
    add(out/'hair-project/config/reference-views.json')
    for name in ('native-record-gpu-proof.json','recorded-parameters.json','parameters.bin','report.json','request.json',
            'capture.py','renderdoc-worker.py','command.json','capture-source-execution.json','renderdoc.log'):
        add(diagnostic/name,'capture-source')
    for path in sorted(diagnostic.glob('*first*')):
        if path.is_file() and path.suffix in ('.json','.log'):
            add(path,'capture-source')
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    contents={name:digest(reader.read(name)) for name in reader.namelist()}
assert archive.stat().st_size<=8*1024*1024
result=dict(status='qualified-native-object-record-calibration',overall='failed-user-review',baseCommit='bc12f32',
    sceneRendererApiVersion=15,acceptedMaximumByteError=1,builds=builds,captures=captures,crossConfiguration=configurations,
    originalFour=original,source=source,affineOracle=oracle,gpuProof=proof,atlasResidual=residual,crossDeviceSource=cross_device,debugSymbolRecovery=symbols,
    archive=dict(bytes=archive.stat().st_size,sha256=digest(archive.read_bytes()),files=len(contents),contents=contents))
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result['archive'].items() if k!='contents'}))
