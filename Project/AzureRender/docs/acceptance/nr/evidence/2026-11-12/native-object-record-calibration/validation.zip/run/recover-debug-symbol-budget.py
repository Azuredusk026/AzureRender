from hashlib import file_digest
from pathlib import Path
import json
import subprocess
import sys

out=Path(__file__).resolve().parent
engine=out.parents[2]
build=(out.parent/'20261110-031856-hair-main-chroma-debug-668bf2/debug').resolve(strict=True)
assert build.parent.parent==out.parent and not build.is_symlink()
queue=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_text())
assert queue['state']=='released' or queue['owner']!='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
targets=['AzurePlayer','AzureReferenceCameraViewTests','AzureProjectReferenceViewsTests','AzureRenderExtensionRegistryTests',
    'AzureReferenceCameraBindingTests','AzureScreenObjectVisibilityTests','AzureScreenObjectVisibilityGpuTests',
    'AzureReferenceDepthGpuTests','AzureReferenceDepthCoverageGpuTests']
ninja='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
command=[ninja,'-C',str(build),'-n',*targets]

def digest(path):
    with path.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()

plan=subprocess.check_output(command,text=True)
assert '[1/1]' in plan and 'generate_script_bindings.py --check' in plan and 'Linking' not in plan
source=build/'AzurePlayer.pdb'
player=build/'AzurePlayer.exe'
assert source.is_file() and not source.is_symlink() and source.resolve(strict=True).parent==build
assert source.stat().st_nlink==1
assert subprocess.run(['git','-C',str(engine),'check-ignore','-q',str(source)]).returncode==0
assert all('AzurePlayer.pdb' not in line for line in (build/'build.ninja').read_text(encoding='utf-8').splitlines()
    if line.startswith('build AzurePlayer.exe'))
folder=out/'build-symbols'
folder.mkdir(exist_ok=True)
assert folder.is_dir() and not folder.is_symlink() and folder.resolve().parent==out
destination=folder/source.name
assert destination.resolve().parent.parent==out and not destination.exists()
sys.path.insert(0,str(engine/'tools'))
from artifact_maintenance import measure

try:
    measure(build.parent)
except ValueError as failure:
    assert str(failure)=='Task byte/file-count budget exceeded',failure
else:
    raise AssertionError('The build does not require quota recovery')
bytes_count=source.stat().st_size
fingerprint=digest(source)
player_fingerprint=digest(player)
source.rename(destination)
try:
    after=measure(build.parent)
    assert digest(destination)==fingerprint and digest(player)==player_fingerprint
    new_plan=subprocess.check_output(command,text=True)
    assert new_plan==plan,new_plan
except Exception:
    destination.rename(source)
    raise
(out/'debug-symbol-budget-recovery.json').write_text(json.dumps(dict(beforeInferred=after+bytes_count,after=after,initialMeasureExceededQuota=True,
    source=str(source),archivedSymbols=str(destination),bytes=bytes_count,symbolSha256=fingerprint,
    playerSha256=player_fingerprint,dryRun=plan),indent=2)+'\n')
print(f'Debug active bytes {after+bytes_count} -> {after}; Player symbols preserved in the stage run')
