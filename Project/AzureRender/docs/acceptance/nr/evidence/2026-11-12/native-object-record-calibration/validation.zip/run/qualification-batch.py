from pathlib import Path
import json
import os
import subprocess
import sys
import time


out=Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


configuration,device,token,*options=sys.argv[1:]
assert configuration in ('Release','Debug') and (device in ('nvidia','intel') or configuration=='Debug' and device=='both')
build_debug=options==['--build-debug']
verify_debug_build=options==['--verify-debug-build']
assert not options or build_debug and (configuration,device)==('Release','intel') or verify_debug_build and (configuration,device)==('Debug','both')
label=configuration.lower()+'-'+device
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key,None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')


def run(task,name,script,*args):
    execution=shared.maintenance.guarded_run(out.parents[1],task,[sys.executable,str(out/script),*args],620)
    (out/(name+'-execution.json')).write_text(json.dumps(execution,indent=2)+'\n')
    print(json.dumps(execution),flush=True)
    assert execution['status']=='exited' and execution['exitCode']==0,execution


deadline=time.monotonic()+1200
while time.monotonic()<deadline:
    try:
        state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
    except (OSError,ValueError):
        time.sleep(1)
        continue
    if state.get('token')!=token or state.get('state')=='released':break
    time.sleep(1)
else:
    raise TimeoutError('The agreed GPU verification window has not opened')
with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a',
    'quality-native-object-record-calibration-'+label,out):
    if verify_debug_build:
        parent='20261110-031856-hair-main-chroma-debug-668bf2'
        shared.maintenance.resume(out.parents[1],parent)
        run(parent,'debug-build','build.py','Debug')
        run(out.name,'debug-cpu-tests','verify-build.py','Debug')
    for adapter in ('nvidia','intel') if device=='both' else (device,):
        case=configuration.lower()+'-'+adapter
        os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*' if adapter=='nvidia' else '*igvk64*'
        run(out.name,case+'-gpu-tests','verify-build.py',configuration,adapter)
        if adapter=='nvidia':
            run(out.name,case+'-scene-control','scene-control.py',configuration)
        run(out.name,case+'-capture','capture-hair-visibility.py',configuration,adapter)
        subprocess.run([sys.executable,str(out/'compact-capture.py'),case+'-frames'],check=True)
    if build_debug:
        parent='20261110-031856-hair-main-chroma-debug-668bf2'
        shared.maintenance.resume(out.parents[1],parent)
        run(parent,'debug-build','build.py','Debug')
