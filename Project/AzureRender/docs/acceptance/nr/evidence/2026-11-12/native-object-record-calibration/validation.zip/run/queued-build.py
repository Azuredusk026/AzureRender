from pathlib import Path
import json
import sys
import time


out = Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


configuration,token = sys.argv[1:]
assert configuration in ('Release','Debug')
parent = '20261110-030251-hair-main-chroma-public-9e799c' if configuration=='Release' else '20261110-031856-hair-main-chroma-debug-668bf2'
deadline = time.monotonic()+1200
while time.monotonic()<deadline:
    try:
        state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
    except (OSError,ValueError):
        time.sleep(1)
        continue
    if state.get('token')!=token or state.get('state')=='released':break
    time.sleep(1)
else:
    raise TimeoutError('The agreed build window has not opened')
with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a',
    'quality-native-object-record-calibration-'+configuration.lower(),out):
    shared.maintenance.resume(out.parents[1],parent)
    execution=shared.maintenance.guarded_run(out.parents[1],parent,[sys.executable,str(out/'build.py'),configuration],900)
    (out/(configuration.lower()+'-build-execution.json')).write_text(json.dumps(execution,indent=2)+'\n')
    print(json.dumps(execution),flush=True)
    assert execution['status']=='exited' and execution['exitCode']==0,execution
