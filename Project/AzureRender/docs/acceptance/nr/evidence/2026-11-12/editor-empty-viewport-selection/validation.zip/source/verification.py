import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


run = Path(__file__).resolve().parent
root = run.parents[2]
sys.path.insert(0, str(root / 'tools'))
from create_playable_project import create
from test_editor_workspace import launch


def read(path):
    return json.loads(path.read_bytes())


def suite(configuration, index, name):
    label = configuration.lower()
    inventory = read(run / f'{label}-inventory.json')['tests']
    assert inventory[index - 1]['name'] == name
    subprocess.run([sys.executable, '-X', 'utf8', '-B', str(run / 'full.py'), 'suite', configuration,
                    str(index), str(index), '--inside'], check=True)
    result = read(run / f'{label}-ctest-{index:03d}-{index:03d}.json')
    assert result['status'] == 'passed' and result['exitCode'] == 0 and result['tests'] == 1, result
    assert not result['failed'] and not result['skipped']
    return result


for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LAYER_ENABLES'):
    os.environ.pop(key, None)
os.environ['VK_LOADER_DRIVERS_SELECT'] = '*nv-vk64*'
os.environ['DOTNET_ROOT'] = 'D:/Tools/dotnet9'
output = run / 'editor-empty-viewport-green'
output.mkdir(exist_ok=False)
report = {}
for configuration, service, reference, editor in (('Debug', 396, 441, 338), ('Release', 398, 443, 340)):
    label = configuration.lower()
    build = root / 'build' / f'ninja-msvc-{label}'
    scenarios = build / 'u6-selection'
    initial = set(scenarios.glob('run-*'))
    selection = suite(configuration, 194, 'AzureEditor.SelectionGpu')
    new, = set(scenarios.glob('run-*')) - initial
    assert len(read(new / 'summary.json')) == 2
    result = {'tests': {'AzureEditor.SelectionGpu': selection}, 'workflows': {}}
    for workflow in ('exploration', 'inspector'):
        base = new / workflow
        copy = output / label / workflow
        copy.mkdir(parents=True)
        case = {}
        for name, expected in (('ctrl-blank', ['range-a', 'range-c']), ('blank', [])):
            relative = base / name
            current = read(relative / 'runtime.json')['editorWorkspace']
            assert current['selection'] == expected and not current['dirty'], current['selection']
            case[name] = {'selection': current['selection'], 'nodes': current['nodeCount'], 'image': current['image']}
            target = copy / name
            target.mkdir()
            for file in ('runtime.json', 'stdout.log', 'stderr.log', 'ui-input.json'):
                shutil.copyfile(relative / file, target / file)
        result['workflows'][workflow] = case
    result['tests']['AzureEditor.SelectionService'] = suite(configuration, service, 'AzureEditor.SelectionService')
    result['tests']['AzureEditor.ReferencePicker'] = suite(configuration, reference, 'AzureEditor.ReferencePicker')
    positive = output / label / 'positive'
    create(positive / 'game')
    actions = [dict(frame=25,action='click',target='node.hero:body'), dict(frame=28,action='click',target='focus'),
               dict(frame=32,action='click',target='node.ground'), dict(frame=36,action='click',target='pick.hero:body')]
    data = launch(build / 'AzureRender.exe', positive, 'picking', (1920, 1080), 1, actions,
                  capture=False, close_policy='discard')
    assert data['history'][-1]['selected'] == 'hero:body' and not data['dirty'], data['history'][-1]
    result['positivePick'] = {'selected': data['history'][-1]['selected'], 'dirty': data['dirty']}
    result['tests']['AzureEngine.EditorPlayable'] = suite(configuration, editor, 'AzureEngine.EditorPlayable')
    report[label] = result
    (output / 'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(configuration, 'blank, Ctrl blank, positive viewport pick and registered checks passed', flush=True)