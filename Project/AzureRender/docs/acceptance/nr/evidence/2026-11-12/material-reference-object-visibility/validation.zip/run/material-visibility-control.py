from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import json
import re
import shutil
import subprocess
import sys

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
stage = out.parent / '20261112-040725-reference-object-shadow-raster-2c9e58'
name, configuration, resource = sys.argv[1:]
assert name in ('red', 'green') and configuration in ('Release', 'Debug') and resource in ('fixed', 'indexed')
source = stage / ('scene-control-' + configuration.lower())
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration == 'Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
folder = out / f'{name}-{configuration.lower()}-{resource}'
folder.mkdir()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


for file in ('plane.gltf', 'lab.azureproject'):
    shutil.copyfile(source / file, folder / file)
scene = json.loads((source / 'objects.azurelevel').read_text())
reference = json.loads((source / 'config/reference-views.json').read_text())
reference['views']['shifted'] = deepcopy(reference['views']['objects'])
reference['views']['shifted']['objectVisibility']['pixelOffset'] = [-.5, -.5]
(folder / 'config').mkdir()
write(folder / 'config/reference-views.json', reference)


def capture(view):
    camera = scene['nodes'][1]['components']['azure.reference-camera']['data']
    camera['view'] = view
    write(folder / 'level.azurelevel', scene)
    write(folder / (view + '.azurelevel'), scene)
    frames = folder / view
    command = [str(build / 'AzurePlayer.exe'), '--project', str(folder / 'lab.azureproject'), '--width', '128', '--height', '128',
        '--capture-dir', str(frames), '--capture-frames', '3', '--fixed-frame-step', '--qa-camera', 'scene', '--qa-light', 'scene',
        '--qa-isolation', 'object-shadow-visibility', '--resource-root', str(build)]
    if resource == 'fixed':
        command.append('--disable-bindless')
    write(folder / (view + '-command.json'), command)
    log = folder / (view + '.log')
    with log.open('wb') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=160)
    diagnostic = log.read_text(errors='replace')
    assert result.returncode == 0 and 'Allocator after unload: buffers=0 images=0' in diagnostic, diagnostic[-6000:]
    assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]', diagnostic, re.I), diagnostic[-6000:]
    assert f'Character texture access: {resource},' in diagnostic, diagnostic[-6000:]
    manifest = json.loads((frames / 'capture_manifest.json').read_text())['referenceSceneDepth']
    assert (manifest['rowOrigin'], manifest['submission']) == ('bottom-left', 3)
    image = np.asarray(Image.open(frames / 'frame_000002.png').convert('RGB')).astype('i4')
    ids = np.fromfile(frames / manifest['objectIds'], 'u1').reshape(128, 128)[::-1]
    green = np.fromfile(frames / manifest['objectVisibility'], 'u1').reshape(128, 128, 2)[::-1, :, 1]
    value = green.astype('f8') / 255
    srgb = np.where(value <= .0031308, 12.92 * value, 1.055 * value ** (1 / 2.4) - .055)
    display = np.rint(srgb * 255).astype('i4')
    return image, ids, green, display


first, second = capture('objects'), capture('shifted')
assert np.array_equal(first[1], second[1])
affected = (first[1] == 1) & (np.abs(first[3] - second[3]) > 2)
assert int(affected.sum()) > 20, 'Shifted reconstruction must move the measured shadow edge'
report = dict(referenceChanged=int(affected.sum()),
    materialChanged=int((affected & (np.abs(first[0] - second[0]).max(axis=2) > 2)).sum()),
    displayErrors=[int((affected & (np.abs(image - display[:, :, None]).max(axis=2) > 1)).sum())
        for image, _, _, display in (first, second)],
    referenceSha256=[sha256(row[2].tobytes()).hexdigest() for row in (first, second)],
    frameSha256=[sha256(row[0].tobytes()).hexdigest() for row in (first, second)])
report['passed'] = report['materialChanged'] == report['referenceChanged'] and report['displayErrors'] == [0, 0]
write(folder / 'results.json', report)
print(json.dumps(report))
if not report['passed']:
    raise SystemExit(2)
