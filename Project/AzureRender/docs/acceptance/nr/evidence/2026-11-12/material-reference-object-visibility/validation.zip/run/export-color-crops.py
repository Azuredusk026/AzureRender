from hashlib import sha256
from pathlib import Path
import json
import runpy

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
prior = out.parent / '20261112-040725-reference-object-shadow-raster-2c9e58'
frozen = runpy.run_path(str(out.parent / '20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
bounds = tuple(frozen[key] for key in ('x0', 'y0', 'x1', 'y1'))
mask = frozen['mask']
reference = frozen['expected']
assert int(mask.sum()) == 17017
folder = out / 'hair-color-crops'
folder.mkdir()


def save(name, data):
    path = folder / (name + '.png')
    Image.fromarray(data.astype('u1')).save(path, compress_level=9)
    return dict(path=path.name, sha256=sha256(path.read_bytes()).hexdigest())


receipt = dict(bounds=bounds, reference=save('frozen-rgb', reference), mask=save('frozen-mask', mask * 255), outputs={})
for adapter in ('nvidia', 'intel'):
    label = 'release-' + adapter
    case = json.loads((out / (label + '-results.json')).read_text())
    receipt['outputs'][adapter] = {}
    for name, source, stats in (('material', out, 'colorHair'), ('atlas', prior, 'colorHairBaseline')):
        frames = source / (label + '-frames')
        hashes = [sha256((frames / f'frame_{index:06d}.png').read_bytes()).hexdigest() for index in range(3)]
        if source == out:
            assert hashes == case['colors']
        else:
            old = json.loads((prior / (label + '-results.json')).read_text())
            assert hashes == old['colors']
        image = np.asarray(Image.open(frames / 'frame_000000.png').convert('RGB').crop(bounds)).astype('i4')
        maximum = np.abs(image - reference)[mask].max(axis=1)
        assert (len(maximum), int((maximum > 1).sum()), int(maximum.max())) == tuple(case[stats][key] for key in ('pixels', 'overOne', 'maximum'))
        receipt['outputs'][adapter][name] = dict(**save(adapter + '-' + name, image), frameSha256=hashes)
(folder / 'manifest.json').write_text(json.dumps(receipt, indent=2) + '\n')
