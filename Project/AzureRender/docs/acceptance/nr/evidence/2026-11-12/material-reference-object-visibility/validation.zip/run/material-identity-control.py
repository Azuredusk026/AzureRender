from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import json
import re
import shutil
import subprocess
import sys

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
configuration = sys.argv[1]
assert configuration in ('Release', 'Debug')
stage = out.parent / '20261112-040725-reference-object-shadow-raster-2c9e58'
source = stage / ('scene-control-' + configuration.lower())
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration == 'Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
folder = out / ('material-identity-' + configuration.lower())
folder.mkdir()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


for file in ('plane.gltf', 'lab.azureproject'):
    shutil.copyfile(source / file, folder / file)
scene = json.loads((source / 'objects.azurelevel').read_text())
near = deepcopy(scene['nodes'][0])
near['id'] = 'near-plane'
near['components']['azure.transform'] = dict(type='azure.transform', version=1, data=dict(translation=[0, 0, .25]))
near['components']['azure.object-shadow']['data'].update(atlasPage=5, lightBias=4.)
scene['nodes'].append(near)
reference = json.loads((source / 'config/reference-views.json').read_text())
for view in ('objects', 'inputs'):
    reference['views'][view]['projection']['columns'][2][2] = -.25
(folder / 'config').mkdir()
write(folder / 'config/reference-views.json', reference)


def capture(label, view, neutral=False):
    fixture = deepcopy(scene)
    fixture['nodes'][1]['components']['azure.reference-camera']['data']['view'] = view
    if neutral:
        for node in fixture['nodes']:
            node['components'].pop('azure.object-shadow', None)
    write(folder / 'level.azurelevel', fixture)
    write(folder / (label + '.azurelevel'), fixture)
    frames = folder / label
    command = [str(build / 'AzurePlayer.exe'), '--project', str(folder / 'lab.azureproject'), '--width', '128', '--height', '128',
        '--capture-dir', str(frames), '--capture-frames', '3', '--fixed-frame-step', '--qa-camera', 'scene', '--qa-light', 'scene',
        '--qa-isolation', 'object-shadow-visibility', '--disable-bindless', '--resource-root', str(build)]
    write(folder / (label + '-command.json'), command)
    log = folder / (label + '.log')
    with log.open('wb') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=160)
    diagnostic = log.read_text(errors='replace')
    assert result.returncode == 0 and 'Allocator after unload: buffers=0 images=0' in diagnostic, diagnostic[-6000:]
    assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]', diagnostic, re.I), diagnostic[-6000:]
    manifest = json.loads((frames / 'capture_manifest.json').read_text())['referenceSceneDepth']
    assert (manifest['rowOrigin'], manifest['submission']) == ('bottom-left', 3)
    png = np.asarray(Image.open(frames / 'frame_000002.png').convert('RGB'))
    ids = np.fromfile(frames / manifest['objectIds'], 'u1').reshape(128, 128)[::-1]
    if view == 'inputs':
        assert 'objectVisibility' not in manifest
        return png, ids, None
    green = np.fromfile(frames / manifest['objectVisibility'], 'u1').reshape(128, 128, 2)[::-1, :, 1]
    return png, ids, green


direct, scene_id, _ = capture('direct', 'inputs')
selected, visible_id, green = capture('selected', 'objects')
neutral, empty_id, empty = capture('neutral', 'objects', True)
assert np.array_equal(scene_id, visible_id)
different = (visible_id != 0) & (green < 240) & np.all(direct == 255, axis=2)
assert int(different.sum()) > 20, 'Expected an occluded far receiver and an unoccluded visible near receiver'
source_ids = np.unique(visible_id[different]).tolist()
assert len(source_ids) == 1, source_ids
assert np.array_equal(selected[different], direct[different]), 'Visible material sampled another object identity'
assert np.all(empty_id == 0) and np.all(empty == 255)
report = dict(differentObjectPositions=int(different.sum()), retainedDirect=int(np.all(selected[different] == direct[different], axis=1).sum()),
    referenceIdentity=source_ids[0], neutral=int((empty == 255).sum()), selectedDigest=sha256(selected.tobytes()).hexdigest(),
    directDigest=sha256(direct.tobytes()).hexdigest(), neutralDigest=sha256(neutral.tobytes()).hexdigest(), passed=True)
write(folder / 'results.json', report)
print(json.dumps(report))
