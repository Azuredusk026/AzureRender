from pathlib import Path
import re
import subprocess


out = Path(__file__).resolve().parent
build = out.parent / '20261110-030251-hair-main-chroma-public-9e799c/release'
ninja = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
target = 'CMakeFiles/AzureRenderCore.dir/src/scenes/CharacterSceneRenderer.cpp.obj'
commands = subprocess.check_output([ninja, '-C', str(build), '-t', 'commands', target], encoding='utf-8').splitlines()
command = commands[-1]
assert 'cl.exe ' in command and ' -c ' in command
command = re.sub(r' /F[od]\S+| /showIncludes| /FS', '', command).replace(' -c ', ' /Zs ')
batch = 'D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'
process = subprocess.run(f'"{batch}" {command}', shell=True, cwd=out, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(out / 'renderer-typecheck.log').write_bytes(process.stdout)
print(process.stdout.decode(errors='replace'))
assert process.returncode == 0, process.returncode
