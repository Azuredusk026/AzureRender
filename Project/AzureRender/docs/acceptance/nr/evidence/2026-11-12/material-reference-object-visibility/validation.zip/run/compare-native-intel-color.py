from hashlib import sha256
from pathlib import Path
import json
import runpy
import zipfile

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
native = out.parents[2] / 'docs/acceptance/nr/evidence/2026-11-11/native-d3d11-depth-devices/validation.zip'
with zipfile.ZipFile(native) as archive:
    receipt = json.loads(archive.read('run/intel-replay/replay-result.json'))
    data = archive.read('run/intel-replay/hair-color-crop.bin')
assert sha256(data).hexdigest() == receipt['hairColor']['cropSha256']
base = runpy.run_path(str(out.parent / '20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
mask = base['mask']
bounds = tuple(base[key] for key in ('x0', 'y0', 'x1', 'y1'))
packed = np.frombuffer(data, '<u4').reshape(mask.shape)[mask]
channels = []
for shift, bits in ((0, 6), (11, 6), (22, 5)):
    value = (packed >> shift) & ((1 << (bits + 5)) - 1)
    exponent = (value >> bits).astype('i4')
    mantissa = (value & ((1 << bits) - 1)).astype('f8')
    assert np.all(exponent != 31)
    channels.append(np.where(exponent == 0, np.ldexp(mantissa, -14 - bits), np.ldexp(1 + mantissa / (1 << bits), exponent - 15)) * .25)
linear = np.stack(channels, axis=-1)
encoded = np.where(linear <= .0031308, 12.92 * linear, 1.055 * np.power(linear, 1 / 2.4) - .055)
same_device = np.rint(np.clip(encoded, 0, 1) * 255).astype('i4')
image = out / 'release-intel-frames/frame_000000.png'
production = json.loads((out / 'release-intel-results.json').read_text())
assert sha256(image.read_bytes()).hexdigest() == production['colors'][0]
candidate = np.asarray(Image.open(image).convert('RGB').crop(bounds)).astype('i4')[mask]
frozen = base['expected'][mask]
native_error = np.abs(same_device - frozen).max(axis=1)
vulkan_error = np.abs(candidate - frozen).max(axis=1)
same_error = np.abs(candidate - same_device).max(axis=1)
assert (native_error > 1).sum() == 580 and native_error.max() == 166
assert (vulkan_error > 1).sum() == production['colorHair']['overOne']
y, x = np.where(mask)
report = dict(pixels=int(mask.sum()), nativeOverOne=int((native_error > 1).sum()), actualOverOne=int((vulkan_error > 1).sum()),
    overlap=int(((native_error > 1) & (vulkan_error > 1)).sum()), sameDeviceExact=int((same_error == 0).sum()),
    sameDeviceOverOne=int((same_error > 1).sum()), sameDeviceMaximum=int(same_error.max()),
    sameDeviceResidual=[dict(pixel=[int(x[i]+bounds[0]), int(y[i]+bounds[1])], actual=candidate[i].tolist(),
        native=same_device[i].tolist(), frozen=frozen[i].tolist(), maximum=int(same_error[i])) for i in np.flatnonzero(same_error > 1)],
    nativeCropSha256=receipt['hairColor']['cropSha256'], nativeArchiveSha256=sha256(native.read_bytes()).hexdigest())
(out / 'intel-native-color-comparison.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'sameDeviceResidual'}))
