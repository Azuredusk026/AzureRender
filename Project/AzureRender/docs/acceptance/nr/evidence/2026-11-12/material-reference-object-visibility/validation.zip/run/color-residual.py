from hashlib import sha256
from pathlib import Path
import json
import runpy
import sys
import zipfile

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
engine = out.parents[2]
device = sys.argv[1]
assert device in ('nvidia', 'intel')
label = 'release-' + device
prior = out.parent / '20261112-040725-reference-object-shadow-raster-2c9e58'
normal = out.parent / '20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
color = runpy.run_path(str(out.parent / '20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
reference = color['expected']
mask = color['mask']
x0, y0, x1, y1 = (color[key] for key in ('x0', 'y0', 'x1', 'y1'))


def read_color(folder, receipt):
    png = folder / (label + '-frames/frame_000000.png')
    assert sha256(png.read_bytes()).hexdigest() == receipt['colors'][0]
    return np.asarray(Image.open(png).convert('RGB').crop((x0, y0, x1, y1))).astype('i4')


actual_case = json.loads((out / (label + '-results.json')).read_text())
old_case = json.loads((prior / (label + '-results.json')).read_text())
actual = read_color(out, actual_case)
previous = read_color(prior, old_case)
actual_failure = mask & (np.abs(actual - reference).max(axis=2) > 1)
previous_failure = mask & (np.abs(previous - reference).max(axis=2) > 1)
assert actual_failure.sum() == actual_case['colorHair']['overOne']
assert previous_failure.sum() == actual_case['colorHairBaseline']['overOne']
historical = json.loads((engine / 'docs/acceptance/nr/evidence/2026-11-09/hair-color-visibility-attribution/results.json').read_text())


def point_mask(points):
    values = np.zeros_like(mask)
    for point in points:
        x, y = point['pixel']
        values[y - y0, x - x0] = True
    return values


historical_failure = point_mask(historical['baseline']['points'])
historical_control = point_mask(historical['nativeVisibilityControl']['points'])
assert (historical_failure == color['bad']).all() and int(historical_control.sum()) == 31
points = np.fromfile(normal / 'queries.bin', '<f4').reshape(-1, 4)
x, native_y = points[:, :2].astype('i4').T
y = 1439 - native_y
assert mask[y - y0, x - x0].all() and len(x) == int(mask.sum())
visibility_reference = np.fromfile(normal / 'expected.bin', '<u4').astype('i4')
with zipfile.ZipFile(out / (label + '-frames/reference-planes.zip')) as archive:
    data = archive.read('reference-object-visibility-rg8.bin')
assert sha256(data).hexdigest() == actual_case['visibilitySha256']
visibility = np.frombuffer(data, 'u1').reshape(1440, 2560, 2)[native_y, x, 1]
visibility_failure = np.abs(visibility.astype('i4') - visibility_reference) > 1
assert visibility_failure.sum() == actual_case['hair']['overOne']
colors = actual_failure[y - y0, x - x0]
report = dict(device=device, overOne=int(actual_failure.sum()), previousOverOne=int(previous_failure.sum()),
    closed=int((previous_failure & ~actual_failure).sum()), introduced=int((actual_failure & ~previous_failure).sum()),
    overlapsHistorical=int((actual_failure & historical_failure).sum()),
    overlapsHistoricalVisibilitySensitive=int((actual_failure & historical_failure & ~historical_control).sum()),
    overlapsHistoricalVisibilityControl=int((actual_failure & historical_control).sum()),
    overlapsLiveVisibilityFailure=int((colors & visibility_failure).sum()),
    points=[dict(pixel=[int(x[i]), int(y[i])], rendered=actual[y[i]-y0, x[i]-x0].tolist(),
        native=reference[y[i]-y0, x[i]-x0].tolist(), visibility=int(visibility[i]), nativeVisibility=int(visibility_reference[i]))
        for i in np.flatnonzero(colors)])
(out / (label + '-color-residual.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'points'}))
