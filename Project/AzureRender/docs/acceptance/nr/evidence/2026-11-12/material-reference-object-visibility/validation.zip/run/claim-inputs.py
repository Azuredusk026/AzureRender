from pathlib import Path
import json
import os
import subprocess
import sys


out = Path(__file__).resolve().parent
build = out.parents[1]
main = Path('D:/Projects/FYP/Project/AzureRender/build')
owner = '01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0, str(main.parent / 'tools'))
import shared_resources as shared

claim_path = Path('D:/Projects/FYP-coordination/quality-claim.json')
claim = json.loads(claim_path.read_text(encoding='utf-8'))
assert claim['threadId'] == owner and claim['state'] == 'reference-object-shadow-raster-build'
assert claim['lastCommit'] == '34d8e9afb69c3c09a111a7ec662ec2aa13099b5d'
source = subprocess.check_output(['git', 'log', '-1', '--format=%H%n%P%n%s'], cwd=build.parent, encoding='utf-8').splitlines()
assert source[1] == claim['lastCommit'] and source[2] == 'feat(nr-quality): 接入参考对象图集光栅', source
old_local, old_main = claim['localInputLease'], claim['inputLease']


def inherited(root, tokens):
    with shared.maintenance.database(root, True) as db:
        records = shared.maintenance.rows(db)
    assert all(records[token]['owner'] == owner for token in tokens)
    return list(dict.fromkeys(name for token in tokens for name in records[token]['inputs']))


local_inputs = inherited(build, old_local)
for name in ('20261112-040725-reference-object-shadow-raster-2c9e58', '20261112-041837-reference-object-shadow-raster-capture-60f161'):
    if name not in local_inputs:
        local_inputs.append(name)
main_inputs = inherited(main, old_main)
local = shared.acquire_inputs(build, out, local_inputs, owner)
try:
    native = shared.acquire_inputs(main, out, main_inputs, owner)
except Exception:
    shared.release_inputs(build, local, owner)
    raise
claim.update(state='material-reference-object-visibility-red', taskPath=str(out), inputLease=[native],
    localInputLease=[local], nativeCaptureLease=native, lastCommit=source[0],
    pendingCommand='Verify the real material ignores reference pixel reconstruction before connecting its sampled visibility',
    ownedFiles=['shaders/mesh.frag', 'src/scenes/CharacterSceneRenderer.cpp', 'src/scenes/CharacterSceneRenderer.hpp',
        'src/scenes/CharacterReferenceSceneDepth.inc'], additionalTaskPaths=[])
claim['observed'].update(referenceRasterHairNvidia=0, referenceRasterHairIntel=236,
    referenceRasterReceiverNvidia=2736, referenceRasterReceiverIntel=3031,
    referenceRasterHairColorNvidia=39, referenceRasterHairColorIntel=592, referenceRasterNvidiaVerticesExact=11559)
(out / 'task-card.json').write_text(json.dumps(dict(local=local, main=native, sourceBase=source[0],
    plannedBytes=536870912, localInputs=local_inputs, mainInputs=main_inputs), indent=2) + '\n')
temporary = claim_path.with_name(claim_path.name + '.nr-quality-new')
with temporary.open('x', encoding='utf-8') as stream:
    json.dump(claim, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
os.replace(temporary, claim_path)
for token in old_main:
    shared.release_inputs(main, token, owner)
for token in old_local:
    shared.release_inputs(build, token, owner)
print(json.dumps(dict(local=local, main=native, output=str(out))))
