from hashlib import sha256
from pathlib import Path
import json
import zipfile


out = Path(__file__).resolve().parent
root = out.parents[2]
prior = out.parent / '20261112-040725-reference-object-shadow-raster-2c9e58'
target = root / 'docs/acceptance/nr/evidence/2026-11-12/material-reference-object-visibility'


def read(folder, file):
    return json.loads((folder / file).read_text(encoding='utf-8-sig'))


def digest(raw):
    return sha256(raw).hexdigest()


labels = tuple(f'{configuration}-{device}' for configuration in ('release', 'debug') for device in ('nvidia', 'intel'))
captures = {key: read(out, key + '-results.json') for key in labels}
planes = ('visibilitySha256', 'referenceDepthSha256', 'referenceNormalsSha256', 'objectIdsSha256')
for label, capture in captures.items():
    old = read(prior, label + '-results.json')
    assert capture['validationClean'] and capture['allocatorZero'] and all(capture[plane] == old[plane] for plane in planes)
    assert capture['colorHair']['pixels'] == 17017
    if label.endswith('nvidia'):
        assert capture['colorHair']['overOne'] == 0 and capture['colorHair']['maximum'] <= 1
builds = {name: read(out, name + '-verification.json') for name in ('release', 'debug', *(key + '-gpu' for key in labels))}
assert all(build['shaderCount'] == 891 and build['materialObjectPrograms'] == len(build['changedShaders']) == 320
    and build['ctestExit'] == 0 for build in builds.values())
assert all(build['changedShaders'] == builds['release']['changedShaders'] for build in builds.values())
cross = read(out, 'cross-configuration.json')
assert all(all(cross[device].values()) for device in ('nvidia', 'intel')) and cross['materialControlsExact']
red = read(out / 'red-release-fixed', 'results.json')
assert red['referenceChanged'] == 181 and red['materialChanged'] == 0 and red['displayErrors'] == [0, 181]
groups = ('red-release-fixed', 'green-release-fixed', 'green-release-indexed', 'green-debug-fixed', 'green-debug-indexed')
controls = {key: read(out / key, 'results.json') for key in groups}
for key, receipt in controls.items():
    if key != groups[0]:
        assert receipt['passed'] and receipt['materialChanged'] == 181 and receipt['displayErrors'] == [0, 0]
identity = read(out / 'material-identity-release', 'results.json')
assert identity['passed'] and identity['differentObjectPositions'] == identity['retainedDirect'] and identity['neutral'] == 128 * 128
original = read(out, 'default-four-results.json')
assert original['allExact'] and original['depthCaptureAbsent'] and original['validationClean'] and original['allocatorZero']
assert original['projectSha256'] == '13638585d18092a315bd7586a88b349fe256c468eb9090ccb6189232b8209d78'
residuals = {adapter: read(out, f'release-{adapter}-color-residual.json') for adapter in ('nvidia', 'intel')}
for adapter, value in residuals.items():
    value.pop('points')
    value['details'] = f'run/release-{adapter}-color-residual.json'
cropped = read(out / 'hair-color-crops', 'manifest.json')
assert cropped['bounds'] == [1140, 130, 1430, 440]
intel_color = read(out, 'intel-native-color-comparison.json')
assert intel_color['actualOverOne'] == captures['release-intel']['colorHair']['overOne']
assert intel_color['nativeOverOne'] == 580 and intel_color['overlap'] == 571 and intel_color['sameDeviceOverOne'] == 7


archive = out / 'validation-pending.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as writer:
    def add(path):
        writer.write(path, 'run/' + path.relative_to(out).as_posix())

    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.json', '.xml', '.log'):
            add(path)
    for key in labels:
        for name in ('capture_manifest.json', 'gpu_capabilities.json', 'reference-planes.json'):
            add(out / (key + '-frames') / name)
    for key in (*groups, 'material-identity-release'):
        folder = out / key
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix in ('.json', '.log', '.gltf', '.azurelevel', '.azureproject'):
                add(path)
        add(folder / 'config/reference-views.json')
        modes = ('direct', 'selected', 'neutral') if key == 'material-identity-release' else ('objects', 'shifted')
        for mode in modes:
            frames = folder / mode
            manifest = read(frames, 'capture_manifest.json')['referenceSceneDepth']
            for name in ('capture_manifest.json', 'frame_000002.png', manifest['objectIds']):
                add(frames / name)
            if 'objectVisibility' in manifest:
                add(frames / manifest['objectVisibility'])
    for path in sorted((out / 'hair-color-crops').iterdir()):
        add(path)
    add(out / 'default-four-frames/capture_manifest.json')
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    files = {name: digest(reader.read(name)) for name in reader.namelist()}
assert archive.stat().st_size <= 8 * 1024 * 1024
result = dict(status='qualified-material-reference-object-visibility', overall='failed-user-review', baseCommit='4bf4e7d',
    sceneRendererApiVersion=15, acceptedMaximumByteError=1,
    builds={name: {field: value for field, value in build.items() if field != 'changedShaders'} for name, build in builds.items()},
    changedShaderPrograms=builds['release']['changedShaders'], captures=captures, controls=controls,
    identity=identity, originalFour=original, crossConfiguration=cross, colorResiduals=residuals, crops=cropped, intelNativeColor=intel_color,
    spirvLayout=read(out, 'spirv-material-layout.json'),
    debugBudget=read(out, 'debug-link-budget-preparation.json'),
    archive=dict(bytes=archive.stat().st_size, sha256=digest(archive.read_bytes()), files=len(files), contents=files))
target.mkdir(parents=True, exist_ok=True)
assert not (target / 'validation.zip').exists() and not (target / 'results.json').exists()
archive.rename(target / 'validation.zip')
(target / 'results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in result['archive'].items() if key != 'contents'}))
