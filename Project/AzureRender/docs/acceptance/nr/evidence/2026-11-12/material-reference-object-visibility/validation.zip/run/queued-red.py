from pathlib import Path
import json
import os
import sys
import time


out = Path(__file__).resolve().parent
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


token = sys.argv[1]
deadline = time.monotonic() + 1200
while time.monotonic() < deadline:
    try:
        state = json.loads((shared.DEFAULT_QUEUE / 'current.json').read_text())
    except (OSError, ValueError):
        time.sleep(1)
        continue
    if state.get('token') != token or state.get('state') == 'released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed GPU window has not opened')

for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES', 'VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key, None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LAYER_VALIDATE_SYNC='1',
    VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
with shared.lease(shared.DEFAULT_QUEUE, '01a1c099-8121-7be3-b0b8-7af2f9a06b2a',
        'quality-material-reference-object-visibility-red', out):
    command = [sys.executable, str(out / 'material-visibility-control.py'), 'red', 'Release', 'fixed']
    execution = shared.maintenance.guarded_run(out.parents[1], out.name, command, 100)
    (out / 'red-execution.json').write_text(json.dumps(execution, indent=2) + '\n')
    print(json.dumps(execution), flush=True)
    assert execution['status'] == 'exited' and execution['exitCode'] == 2, execution
    receipt = json.loads((out / 'red-release-fixed/results.json').read_text())
    assert receipt['referenceChanged'] > 20 and receipt['materialChanged'] == 0 and not receipt['passed'], receipt
    print(json.dumps(receipt), flush=True)
