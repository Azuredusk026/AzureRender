from pathlib import Path
import json
import os
import subprocess
import sys
import time


out = Path(__file__).resolve().parent
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def run(task, name, script, *args):
    command = [sys.executable, str(out / script), *args]
    execution = shared.maintenance.guarded_run(out.parents[1], task, command, 650)
    (out / (name + '-execution.json')).write_text(json.dumps(execution, indent=2) + '\n')
    print(json.dumps(execution), flush=True)
    assert execution['status'] == 'exited' and execution['exitCode'] == 0, execution


def device(adapter):
    os.environ['VK_LOADER_DRIVERS_SELECT'] = '*nv-vk64*' if adapter == 'nvidia' else '*igvk64*'


def character(configuration, adapter):
    device(adapter)
    label = configuration.lower() + '-' + adapter
    run(out.name, label + '-gpu-tests', 'verify-build.py', configuration, adapter)
    run(out.name, label + '-capture', 'capture-hair-visibility.py', configuration, adapter)
    subprocess.run([sys.executable, str(out / 'compact-capture.py'), label + '-frames'], check=True)


token, batch = sys.argv[1:]
assert batch in ('release-nvidia', 'release-intel', 'debug-build', 'debug-nvidia', 'debug-intel', 'original-four', 'material-identity')
deadline = time.monotonic() + 1200
while time.monotonic() < deadline:
    try:
        state = json.loads((shared.DEFAULT_QUEUE / 'current.json').read_text())
    except (OSError, ValueError):
        time.sleep(1)
        continue
    if state.get('token') != token or state.get('state') == 'released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed GPU window has not opened')

for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES', 'VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key, None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LAYER_VALIDATE_SYNC='1')
with shared.lease(shared.DEFAULT_QUEUE, '01a1c099-8121-7be3-b0b8-7af2f9a06b2a',
        'quality-material-reference-object-visibility-' + batch, out):
    if batch == 'debug-build':
        parent = '20261110-031856-hair-main-chroma-debug-668bf2'
        shared.maintenance.resume(out.parents[1], parent)
        run(parent, 'debug-build', 'build.py', 'Debug')
    elif batch == 'original-four':
        device('nvidia')
        run(out.name, batch, 'default-four.py')
    elif batch == 'material-identity':
        device('nvidia')
        run(out.name, batch, 'material-identity-control.py', 'Release')
    else:
        configuration, adapter = batch.split('-', 1)
        character(configuration.title(), adapter)
        if batch == 'release-nvidia':
            run(out.name, 'green-release-indexed', 'material-visibility-control.py', 'green', 'Release', 'indexed')
        if batch == 'debug-nvidia':
            for mode in ('fixed', 'indexed'):
                run(out.name, 'green-debug-' + mode, 'material-visibility-control.py', 'green', 'Debug', mode)
            run(out.name, 'material-identity', 'material-identity-control.py', 'Release')
