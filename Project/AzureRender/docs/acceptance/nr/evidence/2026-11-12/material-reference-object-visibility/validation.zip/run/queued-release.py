from pathlib import Path
import json
import os
import sys
import time


out = Path(__file__).resolve().parent
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def run(task, name, script, *args):
    command = [sys.executable, str(out / script), *args]
    execution = shared.maintenance.guarded_run(out.parents[1], task, command, 650)
    (out / (name + '-execution.json')).write_text(json.dumps(execution, indent=2) + '\n')
    print(json.dumps(execution), flush=True)
    assert execution['status'] == 'exited' and execution['exitCode'] == 0, execution


token = sys.argv[1]
deadline = time.monotonic() + 1200
while time.monotonic() < deadline:
    try:
        state = json.loads((shared.DEFAULT_QUEUE / 'current.json').read_text())
    except (OSError, ValueError):
        time.sleep(1)
        continue
    if state.get('token') != token or state.get('state') == 'released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed Release window has not opened')

for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES', 'VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key, None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LAYER_VALIDATE_SYNC='1',
    VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
with shared.lease(shared.DEFAULT_QUEUE, '01a1c099-8121-7be3-b0b8-7af2f9a06b2a',
        'quality-material-reference-object-visibility-release', out):
    parent = '20261110-030251-hair-main-chroma-public-9e799c'
    shared.maintenance.resume(out.parents[1], parent)
    run(parent, 'release-build', 'build.py', 'Release')
    run(out.name, 'green-release-fixed', 'material-visibility-control.py', 'green', 'Release', 'fixed')
