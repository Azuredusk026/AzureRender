from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys


out=Path(__file__).resolve().parent
configuration=sys.argv[1]
assert configuration in ('Release','Debug')
prefix=configuration.lower()
build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
prior=out.parent/'20261111-232828-scene-reference-normal-60ddfa'/f'{prefix}-verification.json'
catalog={path.name:sha256(path.read_bytes()).hexdigest() for path in (build/'shaders').glob('*.spv')}
baseline=json.loads(prior.read_text())['sha256']
atlas=out.parent/'20261112-040725-reference-object-shadow-raster-2c9e58'
previous=json.loads((atlas/f'{prefix}-verification.json').read_text())['changedShaders']
baseline.update({name:entry['sha256'] for name,entry in previous.items()})
assert catalog.keys()==baseline.keys() and len(catalog)==891
changed={name:{'sourceSha256':baseline[name],'sha256':value} for name,value in catalog.items() if value!=baseline[name]}
ninja='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
commands=subprocess.check_output([ninja,'-C',str(build),'-t','commands','AzurePlayer'],text=True).splitlines()
material={Path(line.split('/shaders/mesh.frag -o ',1)[1].split(' ',1)[0]).name for line in commands
    if '/shaders/mesh.frag -o ' in line and '-DAZURE_OBJECT_SHADOW=1' in line}
assert {'mesh_object.frag.spv','mesh_object_bindless.frag.spv','character_snapshot_object.frag.spv',
    'character_snapshot_object_bindless.frag.spv'}<=changed.keys()<=material,(len(material),len(changed),changed.keys()-material)
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
if len(sys.argv)>2:
    assert sys.argv[2] in ('nvidia','intel')
    prefix+='-'+sys.argv[2]+'-gpu'
    regex='^AzureRender[.](ScreenObjectVisibility(Gpu|ReferenceGpu)|ReferenceDepth(Coverage)?Gpu)$'
else:
    regex='^(AzureRender[.](ReferenceCameraView|ReferenceCameraBinding|ExtensionRegistry|ScreenObjectVisibility)|AzureEngine[.]ProjectReferenceViews)$'
command=[ctest,'--test-dir',str(build),'-R',regex,'--no-tests=error','--output-on-failure','--output-junit',str(out/(prefix+'-ctest.xml'))]
with (out/(prefix+'-ctest.log')).open('wb') as log:
    process=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
report=dict(configuration=configuration,shaderCount=len(catalog),materialObjectPrograms=len(material),changedShaders=changed,ctestCommand=command,
    ctestExit=process.returncode,playerSha256=sha256((build/'AzurePlayer.exe').read_bytes()).hexdigest())
(out/(prefix+'-verification.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({**report,'changedShaders':len(changed)}))
assert process.returncode==0,(out/(prefix+'-ctest.log')).read_text(errors='replace')
