from pathlib import Path


source = Path(__file__).resolve().parents[3] / 'src/scenes/CharacterSceneRenderer.cpp'
data = source.read_bytes()
newline = b'\r\n' if b'\r\n' in data else b'\n'
data = data.replace(b'\r\n', b'\n')
start = data.index(b'    if(referenceDepthActive()){\n        const auto slot=context.currentFrame;\n')
end = data.index(b'    std::optional<RenderGraph::ResourceId> outlineMaskResource;', start)
registration = data[start:end]
target = b'                const auto output=graph.addCommandPass("character-reference-object-visibility",\n'
assert registration.count(target) == 1
registration = registration.replace(target, b'                referenceMaterialIds=identityResource;\n' + target)
target = b'                if(objectAtlasResource){\n'
assert registration.count(target) == 1
registration = registration.replace(target, b'                referenceVisibilityPass=output;\n' + target)
data = data[:start] + data[end:]
destination = data.index(b'    rhi::ImageBarrierDesc overlayInitial{};overlayInitial.image=overlaySceneDepth_[context.currentFrame].image.image;')
dependencies = b'''    std::optional<RenderGraph::ResourceId> referenceMaterialIds;
    std::optional<RenderGraph::PassId> referenceVisibilityPass;
'''
use = b'''    const auto useReferenceVisibility=[&](RenderGraph::PassId pass){
        if(!referenceVisibilityPass||!objectShadowPrepared_)return;
        // The visibility owner transitions its RG8 output within the command pass.
        graph.dependsOn(pass,*referenceVisibilityPass);
        graph.use(pass,*referenceMaterialIds,RenderGraphUsage::Sampled,false);
    };
'''
data = data[:destination] + dependencies + registration + use + data[destination:]
prepass = b'''        recordOverlayDepth(*frozenContext,*frozenInstances,commands);
    });
'''
main = b'    graph.setRecordingChunks(main, std::move(mainChunks));\n'
for marker, consumer in ((prepass, b'prepass'), (main, b'main')):
    assert data.count(marker) == 1
    data = data.replace(marker, marker + b'    useReferenceVisibility(' + consumer + b');\n')
source.write_bytes(data.replace(b'\n', newline))
