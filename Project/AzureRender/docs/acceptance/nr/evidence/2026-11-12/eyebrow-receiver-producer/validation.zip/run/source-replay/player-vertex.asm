SPIR-V 1.0 module, <id> bound of 1397

Generator: Shaderc over Glslang from Google - Contact David Neto, dneto@google.com
Generator Version: 11

Capability(Shader);



MemoryModel(Logical, GLSL450);

EntryPoint(Vertex, main, "main", {
    gl_InstanceIndex, 
    gl_VertexIndex, 
    instanceObjectShadow, 
    opacityCoordinate, 
    position, 
    browMask, 
    gl_PerVertex_var, 
    worldNormal, 
    worldTangent, 
    tangent, 
    textureCoordinate, 
    texcoord, 
    worldPosition, 
    normal, 
    jointIndices, 
    jointWeights, 
    morph0, 
    morph1
  });


Source(GLSL, 450);
SourceExtension("GL_EXT_spirv_intrinsics");
SourceExtension("GL_GOOGLE_cpp_style_line_directive");
SourceExtension("GL_GOOGLE_include_directive");




struct ResType {
  uint _child0;
  uint _child1;
}
bool azureReferenceSceneDepth = SpecConstantFalse() : [[SpecId(7)]];
struct CameraData : [[Block]] {
  float4 cameraPosition : [[Offset(0)]];
  float4 cameraForward : [[Offset(16)]];
  float4 clusterGrid : [[Offset(32)]];
  float4 clusterDepth : [[Offset(48)]];
  float4 clusterLighting : [[Offset(64)]];
  float4 cascadeSplits : [[Offset(80)]];
  float4 renderingParameters : [[Offset(96)]];
  float4 showcaseParameters : [[Offset(112)]];
  float4 qaParameters : [[Offset(128)]];
  float4 faceLightDirection : [[Offset(144)]];
  float4 faceSdfParameters : [[Offset(160)]];
  float4 faceSdfShadowColor : [[Offset(176)]];
  float4 mainLightDirection : [[Offset(192)]];
  float4 cascadeDepthRanges : [[Offset(208)]];
  float4[4] referenceColumns : [[Offset(688)]] : [[ArrayStride(16)]];
  float4 referenceJitter : [[Offset(752)]];
  uint4 referenceControl : [[Offset(768)]];
  float4 referenceOffset : [[Offset(784)]];
}
Uniform CameraData* camera : [[DescriptorSet(0), Binding(0)]];
struct InstanceSkinnedVertices : [[BufferBlock]] {
  uint[] words : [[Offset(0), NonWritable]] : [[ArrayStride(4)]];
}
Uniform InstanceSkinnedVertices* computed : [[DescriptorSet(0), Binding(17), NonWritable]];
struct InstanceTransforms {
  float4x4 model : [[ColMajor, MatrixStride(16), Offset(0)]];
  float4x4 modelViewProjection : [[ColMajor, MatrixStride(16), Offset(64)]];
  float4x4[4] cascadeLightModelViewProjection : [[ColMajor, MatrixStride(16), Offset(128)]] : [[ArrayStride(64)]];
  uint4 meta : [[Offset(384)]];
  float4 faceLight : [[Offset(400)]];
  float2 morph : [[Offset(416)]];
  uint objectShadowIndex : [[Offset(424)]];
  uint instanceFlags : [[Offset(428)]];
  float4x4 faceFrame : [[ColMajor, MatrixStride(16), Offset(432)]];
}
struct InstanceData : [[BufferBlock]] {
  InstanceTransforms[] instances : [[Offset(0), NonWritable]] : [[ArrayStride(496)]];
}
Uniform InstanceData* instanceData : [[DescriptorSet(0), Binding(13), NonWritable]];
Input int* gl_InstanceIndex : [[BuiltIn(InstanceIndex)]];
Input int* gl_VertexIndex : [[BuiltIn(VertexIndex)]];
Output uint* instanceObjectShadow : [[Location(15), Flat]];
Output float3* opacityCoordinate : [[Location(14)]];
Input float3* position : [[Location(0)]];
Private float* eyebrowRegion;
Input float* browMask : [[Location(8)]];
Private float4* instanceFaceDirection;
Private float4x4* instanceFaceFrame;
struct MorphWeights : [[Block]] {
  float4 styleParameters : [[Offset(80)]];
  float4 featureParameters : [[Offset(96)]];
  uint materialFeatures : [[Offset(116)]];
  float2 weights : [[Offset(128)]];
  float4x4 gizmoTransform : [[ColMajor, MatrixStride(16), Offset(144)]];
}
PushConstant MorphWeights* morphWeights;
struct gl_PerVertex : [[Block]] {
  float4 gl_Position : [[BuiltIn(Position)]];
  float gl_PointSize : [[BuiltIn(PointSize)]];
  float[1] gl_ClipDistance : [[BuiltIn(ClipDistance)]];
  float[1] gl_CullDistance : [[BuiltIn(CullDistance)]];
}
Output gl_PerVertex* gl_PerVertex_var;
Output float3* worldNormal : [[Location(0)]];
Output float4* worldTangent : [[Location(1)]];
Input float4* tangent : [[Location(2)]];
Output float2* textureCoordinate : [[Location(2)]];
Input float2* texcoord : [[Location(3)]];
Output float3* worldPosition : [[Location(3)]];
Private float4[4]* shadowPositions;
struct MorphTargetWords : [[BufferBlock]] {
  uint[] words : [[Offset(0), NonWritable]] : [[ArrayStride(4)]];
}
Uniform MorphTargetWords* morphTargets : [[DescriptorSet(0), Binding(21), NonWritable]];
struct MorphInstanceWeights : [[BufferBlock]] {
  float[] values : [[Offset(0), NonWritable]] : [[ArrayStride(4)]];
}
Uniform MorphInstanceWeights* morphInstances : [[DescriptorSet(0), Binding(22), NonWritable]];
struct JointData : [[BufferBlock]] {
  float4x4[] matrices : [[ColMajor, MatrixStride(16), Offset(0), NonWritable]] : [[ArrayStride(64)]];
}
Uniform JointData* jointData : [[DescriptorSet(0), Binding(10), NonWritable]];
Input float3* normal : [[Location(1)]];
Input uint4* jointIndices : [[Location(4)]];
Input float4* jointWeights : [[Location(5)]];
Input float3* morph0 : [[Location(6)]];
Input float3* morph1 : [[Location(7)]];

void main() {
  float4x4* model;
  int* axis;
  bool* browOverlay;
  float4* skinnedPosition;
  uint* param;
  float3* skinnedNormal;
  uint* param@2;
  float3* skinnedTangent;
  uint* param@3;
  float4* gizmoPosition;
  float3* initialWorldPosition;
  float3* worldViewDirection;
  float3* localViewDirection;
  float3* gizmoNormal;
  float3* gizmoTangent;
  float4* referenceDeviceBase;
  float3x3* modelLinear;
  float3* param@4;
  float4* param@5;
  float4* param@6;
  int* cascadeIndex;
  int _1053 = *gl_InstanceIndex;
  uint* _1055 = &instanceData.instances[_1053].objectShadowIndex;
  uint _1056 = *_1055;
  *instanceObjectShadow = _1056;
  float3 _1061 = *position;
  *opacityCoordinate = _1061;
  float _1066 = *browMask;
  *eyebrowRegion = _1066;
  int _1069 = *gl_InstanceIndex;
  float4* _1071 = &instanceData.instances[_1069].faceLight;
  float4 _1072 = *_1071;
  *instanceFaceDirection = _1072;
  int _1075 = *gl_InstanceIndex;
  float4x4* _1078 = &instanceData.instances[_1075].faceFrame;
  float4x4 _1079 = *_1078;
  *instanceFaceFrame = _1079;
  uint* _1084 = &morphWeights.materialFeatures;
  uint _1085 = *_1084;
  uint _1087 = _1085 & 65536;
  bool _1088 = _1087 != 0;
  
  if(_1088) {
    uint* _1091 = &morphWeights.materialFeatures;
    uint _1092 = *_1091;
    uint _1094 = _1092 & 1048576;
    bool _1095 = _1094 == 0;
  }

  bool _1096 = Phi(_1088, _1095);
  
  if(_1096) {
    int _1099 = *gl_InstanceIndex;
    float4x4* _1100 = &instanceData.instances[_1099].model;
    float4x4 _1101 = *_1100;
    float4x4* _1103 = &morphWeights.gizmoTransform;
    float4x4 _1104 = *_1103;
    float4x4 _1105 = _1101 * _1104;
    *instanceFaceFrame = _1105;
  } else {
    uint* _1107 = &morphWeights.materialFeatures;
    uint _1108 = *_1107;
    uint _1110 = _1108 & 1050624;
    bool _1111 = _1110 != 0;
    bool _1112 = !_1111;
    
    if(_1112) {
      int _1115 = *gl_InstanceIndex;
      uint* _1117 = &instanceData.instances[_1115].instanceFlags;
      uint _1118 = *_1117;
      uint _1119 = _1118 & 1;
      bool _1120 = _1119 != 0;
    }

    bool _1121 = Phi(_1111, _1120);
    
    if(_1121) {
      int _1126 = *gl_InstanceIndex;
      float4x4* _1127 = &instanceData.instances[_1126].model;
      float4x4 _1128 = *_1127;
      *model = _1128;
      float4x4 _1129 = *model;
      float4x4* _1130 = &morphWeights.gizmoTransform;
      float4x4 _1131 = *_1130;
      float4x4 _1132 = _1129 * _1131;
      float4x4 _1133 = *model;
      float4x4 _1134 = GLSL.std.450::MatrixInverse(_1133);
      float4x4 _1135 = _1132 * _1134;
      float4x4 _1136 = *instanceFaceFrame;
      float4x4 _1137 = _1135 * _1136;
      *instanceFaceFrame = _1137;
      *axis = 0;

      while(true) {
        int _1144 = *axis;
        bool _1145 = _1144 < 3;
        if(!_1145) break;
        int _1146 = *axis;
        int _1147 = *axis;
        float4* _1148 = &instanceFaceFrame[_1147];
        float4 _1149 = *_1148;
        float3 _1150 = _1149.xyz;
        float3 _1151 = GLSL.std.450::Normalize(_1150);
        float* _1152 = &instanceFaceFrame[_1146].x;
        float _1153 = _1151.x;
        *_1152 = _1153;
        float* _1154 = &instanceFaceFrame[_1146].y;
        float _1155 = _1151.y;
        *_1154 = _1155;
        float* _1156 = &instanceFaceFrame[_1146].z;
        float _1157 = _1151.z;
        *_1156 = _1157;
        int _1158 = *axis;
        int _1159 = _1158 + 1;
        *axis = _1159;
      }

    }

  }

  uint* _1161 = &morphWeights.materialFeatures;
  uint _1162 = *_1161;
  uint _1164 = _1162 & 64;
  bool _1165 = _1164 != 0;
  *browOverlay = _1165;
  *param = 0;
  float3 _1168 = posedVector(param);
  float _1169 = _1168.x;
  float _1170 = _1168.y;
  float _1171 = _1168.z;
  float4 _1172 = CompositeConstruct({_1169, _1170, _1171, 1.0000});
  *skinnedPosition = _1172;
  *param@2 = 3;
  float3 _1175 = posedVector(param@2);
  float3 _1176 = GLSL.std.450::Normalize(_1175);
  *skinnedNormal = _1176;
  *param@3 = 6;
  float3 _1180 = posedVector(param@3);
  float3 _1181 = GLSL.std.450::Normalize(_1180);
  *skinnedTangent = _1181;
  float4x4* _1183 = &morphWeights.gizmoTransform;
  float4x4 _1184 = *_1183;
  float4 _1185 = *skinnedPosition;
  float4 _1186 = _1184 * _1185;
  *gizmoPosition = _1186;
  bool _1187 = *browOverlay;
  
  if(_1187) {
    float _1190 = *browMask;
    bool _1192 = _1190 > 0.5000;
  }

  bool _1193 = Phi(_1187, _1192);
  
  if(_1193) {
    int _1197 = *gl_InstanceIndex;
    float4x4* _1198 = &instanceData.instances[_1197].model;
    float4x4 _1199 = *_1198;
    float4 _1200 = *gizmoPosition;
    float4 _1201 = _1199 * _1200;
    float3 _1202 = _1201.xyz;
    *initialWorldPosition = _1202;
    float4* _1204 = &camera.cameraPosition;
    float4 _1205 = *_1204;
    float3 _1206 = _1205.xyz;
    float3 _1207 = *initialWorldPosition;
    float3 _1208 = _1206 - _1207;
    float3 _1209 = GLSL.std.450::Normalize(_1208);
    *worldViewDirection = _1209;
    int _1211 = *gl_InstanceIndex;
    float4x4* _1212 = &instanceData.instances[_1211].model;
    float4x4 _1213 = *_1212;
    float4 _1215 = _1213[0];
    float3 _1216 = _1215.xyz;
    float4 _1217 = _1213[1];
    float3 _1218 = _1217.xyz;
    float4 _1219 = _1213[2];
    float3 _1220 = _1219.xyz;
    float3x3 _1221 = CompositeConstruct({_1216, _1218, _1220});
    float3x3 _1222 = Transpose(_1221);
    float3 _1223 = *worldViewDirection;
    float3 _1224 = _1222 * _1223;
    float3 _1225 = GLSL.std.450::Normalize(_1224);
    *localViewDirection = _1225;
    float3 _1226 = *localViewDirection;
    float* _1228 = &morphWeights.featureParameters.x;
    float _1229 = *_1228;
    float3 _1230 = _1226 * _1229;
    float4 _1231 = *gizmoPosition;
    float3 _1232 = _1231.xyz;
    float3 _1233 = _1232 + _1230;
    float* _1234 = &gizmoPosition.x;
    float _1235 = _1233.x;
    *_1234 = _1235;
    float* _1236 = &gizmoPosition.y;
    float _1237 = _1233.y;
    *_1236 = _1237;
    float* _1238 = &gizmoPosition.z;
    float _1239 = _1233.z;
    *_1238 = _1239;
  }

  float4x4* _1241 = &morphWeights.gizmoTransform;
  float4x4 _1242 = *_1241;
  float4 _1243 = _1242[0];
  float3 _1244 = _1243.xyz;
  float4 _1245 = _1242[1];
  float3 _1246 = _1245.xyz;
  float4 _1247 = _1242[2];
  float3 _1248 = _1247.xyz;
  float3x3 _1249 = CompositeConstruct({_1244, _1246, _1248});
  float3x3 _1250 = GLSL.std.450::MatrixInverse(_1249);
  float3x3 _1251 = Transpose(_1250);
  float3 _1252 = *skinnedNormal;
  float3 _1253 = _1251 * _1252;
  float3 _1254 = GLSL.std.450::Normalize(_1253);
  *gizmoNormal = _1254;
  float4x4* _1256 = &morphWeights.gizmoTransform;
  float4x4 _1257 = *_1256;
  float4 _1258 = _1257[0];
  float3 _1259 = _1258.xyz;
  float4 _1260 = _1257[1];
  float3 _1261 = _1260.xyz;
  float4 _1262 = _1257[2];
  float3 _1263 = _1262.xyz;
  float3x3 _1264 = CompositeConstruct({_1259, _1261, _1263});
  float3 _1265 = *skinnedTangent;
  float3 _1266 = _1264 * _1265;
  float3 _1267 = GLSL.std.450::Normalize(_1266);
  *gizmoTangent = _1267;
  int _1272 = *gl_InstanceIndex;
  float4x4* _1273 = &instanceData.instances[_1272].modelViewProjection;
  float4x4 _1274 = *_1273;
  float4 _1275 = *gizmoPosition;
  float4 _1276 = _1274 * _1275;
  float4* _1278 = &gl_PerVertex_var.gl_Position;
  *_1278 = _1276;
  float4* _1280 = &gl_PerVertex_var.gl_Position;
  float4 _1281 = *_1280;
  *referenceDeviceBase = _1281;
  int _1284 = *gl_InstanceIndex;
  float4x4* _1285 = &instanceData.instances[_1284].model;
  float4x4 _1286 = *_1285;
  float4 _1287 = _1286[0];
  float3 _1288 = _1287.xyz;
  float4 _1289 = _1286[1];
  float3 _1290 = _1289.xyz;
  float4 _1291 = _1286[2];
  float3 _1292 = _1291.xyz;
  float3x3 _1293 = CompositeConstruct({_1288, _1290, _1292});
  *modelLinear = _1293;
  float3x3 _1295 = *modelLinear;
  float3x3 _1296 = GLSL.std.450::MatrixInverse(_1295);
  float3x3 _1297 = Transpose(_1296);
  float3 _1298 = *gizmoNormal;
  float3 _1299 = _1297 * _1298;
  float3 _1300 = GLSL.std.450::Normalize(_1299);
  *worldNormal = _1300;
  int _1302 = *gl_InstanceIndex;
  float4x4* _1303 = &instanceData.instances[_1302].model;
  float4x4 _1304 = *_1303;
  float4 _1305 = _1304[0];
  float3 _1306 = _1305.xyz;
  float4 _1307 = _1304[1];
  float3 _1308 = _1307.xyz;
  float4 _1309 = _1304[2];
  float3 _1310 = _1309.xyz;
  float3x3 _1311 = CompositeConstruct({_1306, _1308, _1310});
  float3 _1312 = *gizmoTangent;
  float3 _1313 = _1311 * _1312;
  float3 _1314 = GLSL.std.450::Normalize(_1313);
  float* _1317 = &tangent.w;
  float _1318 = *_1317;
  float3x3 _1319 = *modelLinear;
  float _1320 = GLSL.std.450::Determinant(_1319);
  float4x4* _1321 = &morphWeights.gizmoTransform;
  float4x4 _1322 = *_1321;
  float4 _1323 = _1322[0];
  float3 _1324 = _1323.xyz;
  float4 _1325 = _1322[1];
  float3 _1326 = _1325.xyz;
  float4 _1327 = _1322[2];
  float3 _1328 = _1327.xyz;
  float3x3 _1329 = CompositeConstruct({_1324, _1326, _1328});
  float _1330 = GLSL.std.450::Determinant(_1329);
  float _1331 = _1320 * _1330;
  float _1332 = GLSL.std.450::FSign(_1331);
  float _1333 = _1318 * _1332;
  float _1334 = _1314.x;
  float _1335 = _1314.y;
  float _1336 = _1314.z;
  float4 _1337 = CompositeConstruct({_1334, _1335, _1336, _1333});
  *worldTangent = _1337;
  float2 _1342 = *texcoord;
  *textureCoordinate = _1342;
  int _1344 = *gl_InstanceIndex;
  float4x4* _1345 = &instanceData.instances[_1344].model;
  float4x4 _1346 = *_1345;
  float4 _1347 = *gizmoPosition;
  float4 _1348 = _1346 * _1347;
  float3 _1349 = _1348.xyz;
  *worldPosition = _1349;
  float3 _1351 = *worldPosition;
  *param@4 = _1351;
  float4 _1353 = *referenceDeviceBase;
  *param@5 = _1353;
  float4* _1355 = &gl_PerVertex_var.gl_Position;
  float4 _1356 = *_1355;
  *param@6 = _1356;
  float4 _1357 = azureCameraRasterPosition(param@4, param@5, param@6);
  float4* _1358 = &gl_PerVertex_var.gl_Position;
  *_1358 = _1357;
  *cascadeIndex = 0;

  while(true) {
    int _1365 = *cascadeIndex;
    bool _1366 = _1365 < 4;
    if(!_1366) break;
    int _1369 = *cascadeIndex;
    int _1370 = *gl_InstanceIndex;
    int _1371 = *cascadeIndex;
    float4x4* _1372 = &instanceData.instances[_1370].cascadeLightModelViewProjection[_1371];
    float4x4 _1373 = *_1372;
    float4 _1374 = *gizmoPosition;
    float4 _1375 = _1373 * _1374;
    float4* _1376 = &shadowPositions[_1369];
    *_1376 = _1375;
    int _1377 = *cascadeIndex;
    int _1378 = _1377 + 1;
    *cascadeIndex = _1378;
  }

  return;
}

int float32Width64(uint2* a) {
  int* _108;
  int* _120;
  uint* _104 = &a.y;
  uint _105 = *_104;
  bool _107 = _105 != 0;
  
  if(_107) {
    uint* _111 = &a.y;
    uint _112 = *_111;
    int _113 = GLSL.std.450::FindUMsb(_112);
    int _115 = _113 + 33;
    *_108 = _115;
  } else {
    uint* _117 = &a.x;
    uint _118 = *_117;
    bool _119 = _118 != 0;
    
    if(_119) {
      uint* _123 = &a.x;
      uint _124 = *_123;
      int _125 = GLSL.std.450::FindUMsb(_124);
      int _127 = _125 + 1;
      *_120 = _127;
    } else {
      *_120 = 0;
    }

    int _130 = *_120;
    *_108 = _130;
  }

  int _131 = *_108;
  return _131;
}

bool float32Below64(uint2* a@2, int* n) {
  int _134 = *n;
  bool _135 = _134 <= 0;
  
  if(_135) {
    return false;
  }

  int _140 = *n;
  bool _142 = _140 < 32;
  
  if(_142) {
    uint* _145 = &a@2.x;
    uint _146 = *_145;
    int _147 = *n;
    uint _148 = 1 << _147;
    uint _149 = _148 - 1;
    uint _150 = _146 & _149;
    bool _151 = _150 != 0;
    return _151;
  }

  int _153 = *n;
  bool _154 = _153 == 32;
  
  if(_154) {
    uint* _157 = &a@2.x;
    uint _158 = *_157;
    bool _159 = _158 != 0;
    return _159;
  }

  int _161 = *n;
  bool _163 = _161 < 64;
  
  if(_163) {
    uint* _166 = &a@2.x;
    uint _167 = *_166;
    bool _168 = _167 != 0;
    bool _169 = !_168;
    
    if(_169) {
      uint* _172 = &a@2.y;
      uint _173 = *_172;
      int _174 = *n;
      int _175 = _174 - 32;
      uint _176 = 1 << _175;
      uint _177 = _176 - 1;
      uint _178 = _173 & _177;
      bool _179 = _178 != 0;
    }

    bool _180 = Phi(_168, _179);
    return _180;
  }

  uint2 _182 = *a@2;
  bool _185 = _182 != {0, 0};
  bool _186 = Any(_185);
  return _186;
}

uint2 float32Left64(uint2* a@3, int* n@2) {
  int _189 = *n@2;
  bool _190 = _189 <= 0;
  
  if(_190) {
    uint2 _193 = *a@3;
    return _193;
  }

  int _195 = *n@2;
  bool _196 = _195 < 32;
  
  if(_196) {
    uint* _199 = &a@3.x;
    uint _200 = *_199;
    int _201 = *n@2;
    uint _202 = _200 << _201;
    uint* _203 = &a@3.y;
    uint _204 = *_203;
    int _205 = *n@2;
    uint _206 = _204 << _205;
    uint* _207 = &a@3.x;
    uint _208 = *_207;
    int _209 = *n@2;
    int _210 = 32 - _209;
    uint _211 = _208 >> unsigned(_210);
    uint _212 = _206 | _211;
    uint2 _213 = CompositeConstruct({_202, _212});
    return _213;
  }

  int _215 = *n@2;
  bool _216 = _215 < 64;
  
  if(_216) {
    uint* _219 = &a@3.x;
    uint _220 = *_219;
    int _221 = *n@2;
    int _222 = _221 - 32;
    uint _223 = _220 << _222;
    uint2 _224 = CompositeConstruct({0, _223});
    return _224;
  }

  return {0, 0};
}

uint2 float32Right64(uint2* a@4, int* n@3) {
  int _228 = *n@3;
  bool _229 = _228 <= 0;
  
  if(_229) {
    uint2 _232 = *a@4;
    return _232;
  }

  int _234 = *n@3;
  bool _235 = _234 < 32;
  
  if(_235) {
    uint* _238 = &a@4.x;
    uint _239 = *_238;
    int _240 = *n@3;
    uint _241 = _239 >> unsigned(_240);
    uint* _242 = &a@4.y;
    uint _243 = *_242;
    int _244 = *n@3;
    int _245 = 32 - _244;
    uint _246 = _243 << _245;
    uint _247 = _241 | _246;
    uint* _248 = &a@4.y;
    uint _249 = *_248;
    int _250 = *n@3;
    uint _251 = _249 >> unsigned(_250);
    uint2 _252 = CompositeConstruct({_247, _251});
    return _252;
  }

  int _254 = *n@3;
  bool _255 = _254 < 64;
  
  if(_255) {
    uint* _258 = &a@4.y;
    uint _259 = *_258;
    int _260 = *n@3;
    int _261 = _260 - 32;
    uint _262 = _259 >> unsigned(_261);
    uint2 _263 = CompositeConstruct({_262, 0});
    return _263;
  }

  return {0, 0};
}

uint2 float32Align64(uint2* a@5, int* shift) {
  uint2* param@7;
  int* param@8;
  uint2* q;
  uint2* param@9;
  int* param@10;
  uint2* param@11;
  int* param@12;
  int _267 = *shift;
  bool _268 = _267 >= 0;
  
  if(_268) {
    uint2 _272 = *a@5;
    *param@7 = _272;
    int _274 = *shift;
    *param@8 = _274;
    uint2 _275 = float32Left64(param@7, param@8);
    return _275;
  }

  int _278 = *shift;
  int _279 = -_278;
  uint2 _281 = *a@5;
  *param@9 = _281;
  *param@10 = _279;
  uint2 _283 = float32Right64(param@9, param@10);
  *q = _283;
  int _284 = *shift;
  int _285 = -_284;
  uint2 _287 = *a@5;
  *param@11 = _287;
  *param@12 = _285;
  bool _289 = float32Below64(param@11, param@12);
  uint _290 = Select(_289, 1, 0);
  uint* _291 = &q.x;
  uint _292 = *_291;
  uint _293 = _292 | _290;
  uint* _294 = &q.x;
  *_294 = _293;
  uint2 _295 = *q;
  return _295;
}

uint float32Round64(uint2* a@6, int* shift@2) {
  uint2* param@13;
  int* param@14;
  uint* q@2;
  uint2* param@15;
  int* param@16;
  bool* halfwayBit;
  uint2* param@17;
  int* param@18;
  uint2* param@19;
  int* param@20;
  int _298 = *shift@2;
  bool _299 = _298 <= 0;
  
  if(_299) {
    int _302 = *shift@2;
    int _303 = -_302;
    uint2 _305 = *a@6;
    *param@13 = _305;
    *param@14 = _303;
    uint2 _307 = float32Left64(param@13, param@14);
    uint _308 = _307.x;
    return _308;
  }

  uint2 _312 = *a@6;
  *param@15 = _312;
  int _314 = *shift@2;
  *param@16 = _314;
  uint2 _315 = float32Right64(param@15, param@16);
  uint _316 = _315.x;
  *q@2 = _316;
  int _318 = *shift@2;
  bool _319 = _318 <= 64;
  
  if(_319) {
    int _322 = *shift@2;
    int _323 = _322 - 1;
    uint2 _325 = *a@6;
    *param@17 = _325;
    *param@18 = _323;
    uint2 _327 = float32Right64(param@17, param@18);
    uint _328 = _327.x;
    uint _329 = _328 & 1;
    bool _330 = _329 != 0;
  }

  bool _331 = Phi(_319, _330);
  *halfwayBit = _331;
  uint _332 = *q@2;
  bool _333 = *halfwayBit;
  
  if(_333) {
    int _336 = *shift@2;
    int _337 = _336 - 1;
    uint2 _339 = *a@6;
    *param@19 = _339;
    *param@20 = _337;
    bool _341 = float32Below64(param@19, param@20);
    bool _342 = !_341;
    
    if(_342) {
      uint _345 = *q@2;
      uint _346 = _345 & 1;
      bool _347 = _346 != 0;
    }

    bool _348 = Phi(_341, _347);
  }

  bool _349 = Phi(_333, _348);
  uint _350 = Select(_349, 1, 0);
  uint _351 = _332 + _350;
  return _351;
}

float float32ReferenceFma(float* a@7, float* b, float* c) {
  uint* ab;
  uint* bb;
  uint* cb;
  uint* ae;
  uint* be;
  uint* ce;
  uint* am;
  uint* bm;
  uint* cm;
  float* _424;
  int* ep;
  int* _438;
  int* _450;
  int* ec;
  int* _462;
  uint* hi;
  uint* lo;
  uint2* p;
  uint2* v;
  int* top;
  uint2* param@21;
  uint2* param@22;
  int* alignedExponent;
  uint2* param@23;
  int* param@24;
  uint2* _515;
  uint2* param@25;
  int* param@26;
  uint* ps;
  uint* cs;
  uint* sign;
  uint* low;
  uint2* value;
  bool* larger;
  uint2* big;
  uint2* small;
  int* width;
  uint2* param@27;
  int* power;
  uint* significand;
  uint2* param@28;
  int* param@29;
  uint2* param@30;
  int* param@31;
  float _355 = *a@7;
  uint _356 = Bitcast(_355);
  *ab = _356;
  float _358 = *b;
  uint _359 = Bitcast(_358);
  *bb = _359;
  float _361 = *c;
  uint _362 = Bitcast(_361);
  *cb = _362;
  uint _364 = *ab;
  uint _366 = _364 >> unsigned(23);
  uint _368 = _366 & 255;
  *ae = _368;
  uint _370 = *bb;
  uint _371 = _370 >> unsigned(23);
  uint _372 = _371 & 255;
  *be = _372;
  uint _374 = *cb;
  uint _375 = _374 >> unsigned(23);
  uint _376 = _375 & 255;
  *ce = _376;
  uint _377 = *ae;
  bool _378 = _377 == 255;
  uint _379 = *be;
  bool _380 = _379 == 255;
  bool _381 = _378 || _380;
  uint _382 = *ce;
  bool _383 = _382 == 255;
  bool _384 = _381 || _383;
  
  if(_384) {
    float _387 = *a@7;
    float _388 = *b;
    float _389 = *c;
    float _390 = GLSL.std.450::Fma(_387, _388, _389);
    return _390;
  }

  uint _393 = *ab;
  uint _395 = _393 & 8388607;
  uint _396 = *ae;
  bool _397 = _396 != 0;
  uint _399 = Select(_397, 8388608, 0);
  uint _400 = _395 | _399;
  *am = _400;
  uint _402 = *bb;
  uint _403 = _402 & 8388607;
  uint _404 = *be;
  bool _405 = _404 != 0;
  uint _406 = Select(_405, 8388608, 0);
  uint _407 = _403 | _406;
  *bm = _407;
  uint _409 = *cb;
  uint _410 = _409 & 8388607;
  uint _411 = *ce;
  bool _412 = _411 != 0;
  uint _413 = Select(_412, 8388608, 0);
  uint _414 = _410 | _413;
  *cm = _414;
  uint _415 = *am;
  bool _416 = _415 == 0;
  uint _417 = *bm;
  bool _418 = _417 == 0;
  bool _419 = _416 || _418;
  
  if(_419) {
    uint _422 = *cm;
    bool _423 = _422 != 0;
    
    if(_423) {
      float _427 = *c;
      *_424 = _427;
    } else {
      float _429 = *a@7;
      float _430 = *b;
      float _431 = *c;
      float _432 = GLSL.std.450::Fma(_429, _430, _431);
      *_424 = _432;
    }

    float _433 = *_424;
    return _433;
  }

  uint _436 = *ae;
  bool _437 = _436 != 0;
  
  if(_437) {
    uint _441 = *ae;
    int _442 = Bitcast(_441);
    int _444 = _442 - 150;
    *_438 = _444;
  } else {
    *_438 = -149;
  }

  int _447 = *_438;
  uint _448 = *be;
  bool _449 = _448 != 0;
  
  if(_449) {
    uint _453 = *be;
    int _454 = Bitcast(_453);
    int _455 = _454 - 150;
    *_450 = _455;
  } else {
    *_450 = -149;
  }

  int _457 = *_450;
  int _458 = _447 + _457;
  *ep = _458;
  uint _460 = *ce;
  bool _461 = _460 != 0;
  
  if(_461) {
    uint _465 = *ce;
    int _466 = Bitcast(_465);
    int _467 = _466 - 150;
    *_462 = _467;
  } else {
    *_462 = -149;
  }

  int _469 = *_462;
  *ec = _469;
  uint _470 = *am;
  uint _471 = *bm;
  ResType _475 = UMulExtended(_470, _471);
  uint _476 = _475._child0;
  *lo = _476;
  uint _477 = _475._child1;
  *hi = _477;
  uint _479 = *lo;
  uint _480 = *hi;
  uint2 _481 = CompositeConstruct({_479, _480});
  *p = _481;
  uint _483 = *cm;
  uint2 _484 = CompositeConstruct({_483, 0});
  *v = _484;
  int _486 = *ep;
  uint2 _488 = *p;
  *param@21 = _488;
  int _489 = float32Width64(param@21);
  int _490 = _486 + _489;
  *top = _490;
  uint _491 = *cm;
  bool _492 = _491 != 0;
  
  if(_492) {
    int _495 = *top;
    int _496 = *ec;
    uint2 _498 = *v;
    *param@22 = _498;
    int _499 = float32Width64(param@22);
    int _500 = _496 + _499;
    int _501 = GLSL.std.450::SMax(_495, _500);
    *top = _501;
  }

  int _503 = *top;
  int _505 = _503 - 63;
  *alignedExponent = _505;
  int _506 = *ep;
  int _507 = *alignedExponent;
  int _508 = _506 - _507;
  uint2 _510 = *p;
  *param@23 = _510;
  *param@24 = _508;
  uint2 _512 = float32Align64(param@23, param@24);
  *p = _512;
  uint _513 = *cm;
  bool _514 = _513 != 0;
  
  if(_514) {
    int _518 = *ec;
    int _519 = *alignedExponent;
    int _520 = _518 - _519;
    uint2 _522 = *v;
    *param@25 = _522;
    *param@26 = _520;
    uint2 _524 = float32Align64(param@25, param@26);
    *_515 = _524;
  } else {
    *_515 = {0, 0};
  }

  uint2 _526 = *_515;
  *v = _526;
  uint _528 = *ab;
  uint _529 = *bb;
  uint _530 = _528 ^ _529;
  uint _532 = _530 & 2147483648;
  *ps = _532;
  uint _534 = *cb;
  uint _535 = _534 & 2147483648;
  *cs = _535;
  uint _537 = *ps;
  *sign = _537;
  uint _538 = *ps;
  uint _539 = *cs;
  bool _540 = _538 == _539;
  
  if(_540) {
    uint* _544 = &p.x;
    uint _545 = *_544;
    uint* _546 = &v.x;
    uint _547 = *_546;
    uint _548 = _545 + _547;
    *low = _548;
    uint _550 = *low;
    uint* _551 = &p.y;
    uint _552 = *_551;
    uint* _553 = &v.y;
    uint _554 = *_553;
    uint _555 = _552 + _554;
    uint _556 = *low;
    uint* _557 = &p.x;
    uint _558 = *_557;
    bool _559 = _556 < _558;
    uint _560 = Select(_559, 1, 0);
    uint _561 = _555 + _560;
    uint2 _562 = CompositeConstruct({_550, _561});
    *value = _562;
  } else {
    uint* _565 = &p.y;
    uint _566 = *_565;
    uint* _567 = &v.y;
    uint _568 = *_567;
    bool _569 = _566 > _568;
    bool _570 = !_569;
    
    if(_570) {
      uint* _573 = &p.y;
      uint _574 = *_573;
      uint* _575 = &v.y;
      uint _576 = *_575;
      bool _577 = _574 == _576;
      
      if(_577) {
        uint* _580 = &p.x;
        uint _581 = *_580;
        uint* _582 = &v.x;
        uint _583 = *_582;
        bool _584 = _581 >= _583;
      }

      bool _585 = Phi(_577, _584);
    }

    bool _586 = Phi(_569, _585);
    *larger = _586;
    bool _588 = *larger;
    uint2 _589 = *p;
    uint2 _590 = *v;
    bool _591 = CompositeConstruct({_588, _588});
    uint2 _592 = Select(_591, _589, _590);
    *big = _592;
    bool _594 = *larger;
    uint2 _595 = *v;
    uint2 _596 = *p;
    bool _597 = CompositeConstruct({_594, _594});
    uint2 _598 = Select(_597, _595, _596);
    *small = _598;
    bool _599 = *larger;
    uint _600 = *ps;
    uint _601 = *cs;
    uint _602 = Select(_599, _600, _601);
    *sign = _602;
    uint* _603 = &big.x;
    uint _604 = *_603;
    uint* _605 = &small.x;
    uint _606 = *_605;
    uint _607 = _604 - _606;
    uint* _608 = &big.y;
    uint _609 = *_608;
    uint* _610 = &small.y;
    uint _611 = *_610;
    uint _612 = _609 - _611;
    uint* _613 = &big.x;
    uint _614 = *_613;
    uint* _615 = &small.x;
    uint _616 = *_615;
    bool _617 = _614 < _616;
    uint _618 = Select(_617, 1, 0);
    uint _619 = _612 - _618;
    uint2 _620 = CompositeConstruct({_607, _619});
    *value = _620;
  }

  uint2 _623 = *value;
  *param@27 = _623;
  int _624 = float32Width64(param@27);
  *width = _624;
  int _625 = *width;
  bool _626 = _625 == 0;
  
  if(_626) {
    return 0.0000;
  }

  int _632 = *alignedExponent;
  int _633 = *width;
  int _634 = _632 + _633;
  int _635 = _634 - 1;
  *power = _635;
  int _636 = *power;
  bool _638 = _636 < -126;
  
  if(_638) {
    int _642 = *alignedExponent;
    int _643 = -149 - _642;
    uint2 _645 = *value;
    *param@28 = _645;
    *param@29 = _643;
    uint _647 = float32Round64(param@28, param@29);
    *significand = _647;
    uint _648 = *sign;
    uint _649 = *significand;
    uint _650 = _648 | _649;
    float _651 = Bitcast(_650);
    return _651;
  }

  int _653 = *width;
  int _655 = _653 - 24;
  uint2 _657 = *value;
  *param@30 = _657;
  *param@31 = _655;
  uint _659 = float32Round64(param@30, param@31);
  *significand = _659;
  uint _660 = *significand;
  bool _662 = _660 == 16777216;
  
  if(_662) {
    uint _665 = *significand;
    uint _666 = _665 >> unsigned(1);
    *significand = _666;
    int _667 = *power;
    int _668 = _667 + 1;
    *power = _668;
  }

  int _669 = *power;
  bool _671 = _669 > 127;
  
  if(_671) {
    uint _674 = *sign;
    uint _676 = _674 | 2139095040;
    float _677 = Bitcast(_676);
    return _677;
  }

  uint _679 = *sign;
  int _680 = *power;
  int _681 = _680 + 127;
  uint _682 = Bitcast(_681);
  uint _683 = _682 << 23;
  uint _684 = _679 | _683;
  uint _685 = *significand;
  uint _686 = _685 & 8388607;
  uint _687 = _684 | _686;
  float _688 = Bitcast(_687);
  return _688;
}

float3 azureReferenceRelativePosition(float3* world, uint* packedAxes, float3* offset) {
  uint* axis@2;
  uint* code;
  uint* bits;
  uint* other;
  float3* result;
  float* param@32;
  float* param@33;
  float* param@34;
  *axis@2 = 0;

  while(true) {
    uint _697 = *axis@2;
    bool _699 = _697 < 3;
    if(!_699) break;
    uint _701 = *packedAxes;
    uint _702 = *axis@2;
    uint _703 = _702 * 3;
    uint _704 = _701 >> _703;
    uint _706 = _704 & 7;
    *code = _706;
    uint _708 = *code;
    uint _709 = _708 & 3;
    float* _710 = &world[_709];
    float _711 = *_710;
    uint _712 = Bitcast(_711);
    uint _713 = *code;
    uint _714 = _713 & 4;
    uint _716 = _714 << 29;
    uint _717 = _712 ^ _716;
    *bits = _717;
    uint _719 = *axis@2;
    float* _720 = &offset[_719];
    float _721 = *_720;
    uint _722 = Bitcast(_721);
    *other = _722;
    uint _723 = *bits;
    uint _724 = *other;
    uint _725 = _723 | _724;
    uint _727 = _725 & 2147483647;
    bool _728 = _727 == 0;
    
    if(_728) {
      uint _732 = *axis@2;
      uint _733 = *bits;
      uint _734 = *other;
      uint _735 = _733 & _734;
      uint _736 = _735 & 2147483648;
      float _737 = Bitcast(_736);
      float* _738 = &result[_732];
      *_738 = _737;
    } else {
      uint _740 = *axis@2;
      uint _742 = *bits;
      float _743 = Bitcast(_742);
      uint _744 = *axis@2;
      *param@32 = 1.0000;
      *param@33 = _743;
      float* _748 = &offset[_744];
      float _749 = *_748;
      *param@34 = _749;
      float _750 = float32ReferenceFma(param@32, param@33, param@34);
      float* _751 = &result[_740];
      *_751 = _750;
    }

    uint _752 = *axis@2;
    uint _753 = _752 + 1;
    *axis@2 = _753;
  }

  float3 _754 = *result;
  return _754;
}

float4 azureReferenceClipProjection(float3* position@2, float4[4]* columns, float2* jitter) {
  float4* value@2;
  float4* first;
  float4* second;
  float2* offset@2;
  float2* shifted;
  float* _758 = &position@2.y;
  float _759 = *_758;
  float4* _760 = &columns[1];
  float4 _761 = *_760;
  float4 _762 = _761 * _759;
  *value@2 = _762;
  float4* _764 = &columns[0];
  float4 _765 = *_764;
  float* _766 = &position@2.x;
  float _767 = *_766;
  float4 _768 = CompositeConstruct({_767, _767, _767, _767});
  float4 _769 = *value@2;
  float4 _770 = GLSL.std.450::Fma(_765, _768, _769);
  *first = _770;
  float4 _771 = *first;
  *value@2 = _771;
  float4* _774 = &columns[2];
  float4 _775 = *_774;
  float* _777 = &position@2.z;
  float _778 = *_777;
  float4 _779 = CompositeConstruct({_778, _778, _778, _778});
  float4 _780 = *value@2;
  float4 _781 = GLSL.std.450::Fma(_775, _779, _780);
  *second = _781;
  float4 _782 = *second;
  *value@2 = _782;
  float4 _783 = *value@2;
  float4* _785 = &columns[3];
  float4 _786 = *_785;
  float4 _787 = _783 + _786;
  *value@2 = _787;
  float* _789 = &value@2.w;
  float _790 = *_789;
  float2 _791 = *jitter;
  float2 _792 = _791 * _790;
  *offset@2 = _792;
  float2 _794 = *offset@2;
  float2 _795 = -_794;
  float4 _799 = *value@2;
  float2 _800 = _799.xy;
  float2 _801 = GLSL.std.450::Fma(_795, {2.0000, -2.0000}, _800);
  *shifted = _801;
  float2 _802 = *shifted;
  float* _803 = &value@2.x;
  float _804 = _802.x;
  *_803 = _804;
  float* _805 = &value@2.y;
  float _806 = _802.y;
  *_805 = _806;
  float4 _807 = *value@2;
  return _807;
}

float4 azureComposeReferenceRasterPosition(float4* referenceClip, float4* deviceBase, float4* deviceFinal, bool* enabled) {
  float4* result@2;
  float* depth;
  float2* finalNdc;
  float2* baseNdc;
  float2* delta;
  float2* offset@3;
  bool _810 = *enabled;
  bool _811 = !_810;
  bool _812 = !_811;
  
  if(_812) {
    float* _815 = &referenceClip.w;
    float _816 = *_815;
    bool _817 = _816 == 0.0000;
  }

  bool _818 = Phi(_811, _817);
  bool _819 = !_818;
  
  if(_819) {
    float* _822 = &deviceBase.w;
    float _823 = *_822;
    bool _824 = _823 == 0.0000;
  }

  bool _825 = Phi(_818, _824);
  bool _826 = !_825;
  
  if(_826) {
    float* _829 = &deviceFinal.w;
    float _830 = *_829;
    bool _831 = _830 == 0.0000;
  }

  bool _832 = Phi(_825, _831);
  
  if(_832) {
    float4 _835 = *deviceFinal;
    return _835;
  }

  float4 _838 = *referenceClip;
  *result@2 = _838;
  float* _840 = &deviceFinal.z;
  float _841 = *_840;
  float* _842 = &deviceFinal.w;
  float _843 = *_842;
  float _844 = _841 / _843;
  *depth = _844;
  float _845 = *depth;
  float* _846 = &result@2.w;
  float _847 = *_846;
  float _848 = _845 * _847;
  float* _849 = &result@2.z;
  *_849 = _848;
  float4 _850 = *deviceBase;
  float3 _851 = _850.xyw;
  float4 _852 = *deviceFinal;
  float3 _853 = _852.xyw;
  bool _855 = _851 != _853;
  bool _856 = Any(_855);
  
  if(_856) {
    float4 _860 = *deviceFinal;
    float2 _861 = _860.xy;
    float* _862 = &deviceFinal.w;
    float _863 = *_862;
    float2 _864 = CompositeConstruct({_863, _863});
    float2 _865 = _861 / _864;
    *finalNdc = _865;
    float4 _867 = *deviceBase;
    float2 _868 = _867.xy;
    float* _869 = &deviceBase.w;
    float _870 = *_869;
    float2 _871 = CompositeConstruct({_870, _870});
    float2 _872 = _868 / _871;
    *baseNdc = _872;
    float2 _874 = *finalNdc;
    float2 _875 = *baseNdc;
    float2 _876 = _874 - _875;
    *delta = _876;
    float2 _878 = *delta;
    float* _879 = &result@2.w;
    float _880 = *_879;
    float2 _881 = _878 * _880;
    *offset@3 = _881;
    float4 _882 = *result@2;
    float2 _883 = _882.xy;
    float2 _884 = *offset@3;
    float2 _885 = _883 + _884;
    float* _886 = &result@2.x;
    float _887 = _885.x;
    *_886 = _887;
    float* _888 = &result@2.y;
    float _889 = _885.y;
    *_888 = _889;
  }

  float4 _890 = *result@2;
  bool _892 = IsNan(_890);
  bool _893 = Any(_892);
  bool _894 = !_893;
  
  if(_894) {
    float4 _897 = *result@2;
    bool _898 = IsInf(_897);
    bool _899 = Any(_898);
  }

  bool _900 = Phi(_893, _899);
  
  if(_900) {
    float4 _903 = *deviceFinal;
    return _903;
  }

  float4 _905 = *result@2;
  return _905;
}

float4 azureReferenceRasterPosition(float3* world@2, float4* deviceBase@2, float4* deviceFinal@2, float4[4]* columns@2, float2* jitter@2, uint* packedAxes@2, float3* frameOffset, bool* enabled@2, bool* flipY) {
  float4* referenceClip@2;
  float3* param@35;
  uint* param@36;
  float3* param@37;
  float3* param@38;
  float4[4]* param@39;
  float2* param@40;
  float4* param@41;
  float4* param@42;
  float4* param@43;
  bool* param@44;
  bool _908 = *enabled@2;
  bool _909 = !_908;
  
  if(_909) {
    float4 _912 = *deviceFinal@2;
    return _912;
  }

  float3 _916 = *world@2;
  *param@35 = _916;
  uint _918 = *packedAxes@2;
  *param@36 = _918;
  float3 _920 = *frameOffset;
  *param@37 = _920;
  float3 _921 = azureReferenceRelativePosition(param@35, param@36, param@37);
  *param@38 = _921;
  float4[4] _924 = *columns@2;
  *param@39 = _924;
  float2 _926 = *jitter@2;
  *param@40 = _926;
  float4 _927 = azureReferenceClipProjection(param@38, param@39, param@40);
  *referenceClip@2 = _927;
  bool _928 = *flipY;
  
  if(_928) {
    float* _931 = &referenceClip@2.y;
    float _932 = *_931;
    float _933 = -_932;
    float* _934 = &referenceClip@2.y;
    *_934 = _933;
  }

  
  if(azureReferenceSceneDepth) {
    float* _938 = &referenceClip@2.y;
    float _939 = *_938;
    float _940 = -_939;
    float* _941 = &referenceClip@2.y;
    *_941 = _940;
    float4 _942 = *referenceClip@2;
    return _942;
  }

  float4 _946 = *referenceClip@2;
  *param@41 = _946;
  float4 _948 = *deviceBase@2;
  *param@42 = _948;
  float4 _950 = *deviceFinal@2;
  *param@43 = _950;
  *param@44 = true;
  float4 _952 = azureComposeReferenceRasterPosition(param@41, param@42, param@43, param@44);
  return _952;
}

float4 azureCameraRasterPosition(float3* world@3, float4* deviceBase@3, float4* deviceFinal@3) {
  float3* param@45;
  float4* param@46;
  float4* param@47;
  float4[4]* param@48;
  float2* param@49;
  uint* param@50;
  float3* param@51;
  bool* param@52;
  bool* param@53;
  uint* _965 = &camera.referenceControl.z;
  uint _966 = *_965;
  uint _967 = _966 & 1;
  bool _968 = _967 != 0;
  uint* _969 = &camera.referenceControl.z;
  uint _970 = *_969;
  uint _971 = _970 & 2;
  bool _972 = _971 != 0;
  float3 _974 = *world@3;
  *param@45 = _974;
  float4 _976 = *deviceBase@3;
  *param@46 = _976;
  float4 _978 = *deviceFinal@3;
  *param@47 = _978;
  float4[4]* _981 = &camera.referenceColumns;
  float4[4] _982 = *_981;
  float4 _983 = _982[0];
  float4* _984 = &param@48[0];
  *_984 = _983;
  float4 _985 = _982[1];
  float4* _986 = &param@48[1];
  *_986 = _985;
  float4 _987 = _982[2];
  float4* _988 = &param@48[2];
  *_988 = _987;
  float4 _989 = _982[3];
  float4* _990 = &param@48[3];
  *_990 = _989;
  float4* _993 = &camera.referenceJitter;
  float4 _994 = *_993;
  float2 _995 = _994.xy;
  *param@49 = _995;
  uint* _997 = &camera.referenceControl.y;
  uint _998 = *_997;
  *param@50 = _998;
  float4* _1000 = &camera.referenceOffset;
  float4 _1001 = *_1000;
  float3 _1002 = _1001.xyz;
  *param@51 = _1002;
  *param@52 = _968;
  *param@53 = _972;
  float4 _1005 = azureReferenceRasterPosition(param@45, param@46, param@47, param@48, param@49, param@50, param@51, param@52, param@53);
  return _1005;
}

float posedFloat(uint* offset@4) {
  int _1021 = *gl_InstanceIndex;
  uint* _1022 = &instanceData.instances[_1021].meta.y;
  uint _1023 = *_1022;
  int _1025 = *gl_VertexIndex;
  uint _1026 = Bitcast(_1025);
  uint _1027 = _1023 + _1026;
  uint _1029 = _1027 * 10;
  uint _1030 = *offset@4;
  uint _1031 = _1029 + _1030;
  uint* _1032 = &computed.words[_1031];
  uint _1033 = *_1032;
  float _1034 = Bitcast(_1033);
  return _1034;
}

float3 posedVector(uint* offset@5) {
  uint* param@54;
  uint* param@55;
  uint* param@56;
  uint _1038 = *offset@5;
  *param@54 = _1038;
  float _1039 = posedFloat(param@54);
  uint _1040 = *offset@5;
  uint _1041 = _1040 + 1;
  *param@55 = _1041;
  float _1043 = posedFloat(param@55);
  uint _1044 = *offset@5;
  uint _1045 = _1044 + 2;
  *param@56 = _1045;
  float _1047 = posedFloat(param@56);
  float3 _1048 = CompositeConstruct({_1039, _1043, _1047});
  return _1048;
}


