from hashlib import sha256
from pathlib import Path
import json
import zipfile


out = Path(__file__).resolve().parent
target = out.parents[2] / 'docs/acceptance/nr/evidence/2026-11-12/eyebrow-receiver-producer'
source = out / 'source-replay'


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


replay = load(source / 'report.json')
execution = load(out / 'replay-execution.json')
comparison = load(out / 'eyebrow-producer-comparison.json')
assert replay['status'] == 'qualified' and execution['status'] == 'exited' and execution['exitCode'] == 0
assert comparison['coverage']['hostDrawWrites'] == {'all': 496, 'failed': 140}
assert comparison['coverage']['hostNormalOwner'] == {'267': {'all': 361, 'failed': 24}, '274': {'all': 135, 'failed': 116}}
assert comparison['coverage']['intelAtHostHairPoints'] == 116
assert comparison['geometry']['pairedVertices'] == 578 and comparison['geometry']['indexedCorners'] == 1878
assert comparison['geometry']['projection']['invertedY']['pixelMaximum'] < .0001
inputs = [out / name for name in ('task-card.json', 'replay.py', 'replay-worker.py', 'queued-replay.py',
    'replay-execution.json', 'analyze.py', 'package-evidence.py', 'eyebrow-producer-comparison.json')]
inputs.extend(sorted(source.iterdir()))
archive = out / 'validation-pending.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as writer:
    for path in inputs:
        writer.write(path, 'run/' + path.relative_to(out).as_posix())
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    contents = {name: sha256(reader.read(name)).hexdigest() for name in reader.namelist()}
    assert len(contents) == len(inputs)
assert archive.stat().st_size <= 8 * 1024 * 1024
payload = dict(status='qualified-eyebrow-receiver-producer', overall='failed-user-review', comparison=comparison,
    nativeAndPlayerReplay=replay, execution=execution, archive=dict(bytes=archive.stat().st_size,
        sha256=sha256(archive.read_bytes()).hexdigest(), contents=contents))
target.mkdir(parents=True, exist_ok=True)
assert not (target / 'validation.zip').exists() and not (target / 'results.json').exists()
archive.rename(target / 'validation.zip')
(target / 'results.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in payload['archive'].items() if key != 'contents'}))