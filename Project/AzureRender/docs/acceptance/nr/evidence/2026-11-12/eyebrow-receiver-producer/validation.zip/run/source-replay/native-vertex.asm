Shader hash 476ecc2b-c2b98ae8-e6f243ff-4f0bca68

vs_5_0
      dcl_globalFlags refactoringAllowed
      dcl_constantbuffer cb0[82], immediateIndexed
      dcl_constantbuffer cb1[20], immediateIndexed
      dcl_constantbuffer cb2[4091], dynamicIndexed
      dcl_constantbuffer cb3[11], immediateIndexed
      dcl_resource_structured t0, 16
      dcl_input v0.xyz
      dcl_input v1.xy
      dcl_input v2.xyz
      dcl_input v3.xyz
      dcl_input v4.xyzw
      dcl_input v5.xyzw
      dcl_input_sgv v6.x, instanceid
      dcl_output_siv o0.xyzw, position
      dcl_output o1.xy
      dcl_output o2.xyz
      dcl_output o3.xyz
      dcl_output o4.xyz
      dcl_output o5.xyz
      dcl_output o6.x
      dcl_temps 12
   0: and r0.xy, v2.xxxx, l(2.000000, 0.000000, 0.000000, 0.000000)
   1: ult r0.x, l(0), r0.x
   2: ubfe r0.z, l(10), l(10), v2.x
   3: utof r0.yz, r0.yyzy
   4: ge r0.w, r0.y, l(512.000000)
   5: add r1.x, r0.y, l(-1024.000000)
   6: movc r1.x, r0.w, r1.x, r0.y
   7: ge r0.y, r0.z, l(512.000000)
   8: add r0.w, r0.z, l(-1024.000000)
   9: movc r1.y, r0.y, r0.w, r0.z
  10: mul r0.yz, r1.xxyx, l(0.000000, 0.001957, 0.001957, 0.000000)
  11: add r2.xyz, -abs(r0.yzyy), l(1.000000, 1.000000, 1.000000, 0.000000)
  12: add r3.z, -abs(r0.z), r2.x
  13: lt r0.w, r3.z, l(0)
  14: ge r1.xy, r1.xyxx, l(0, 0, 0, 0)
  15: movc r1.xy, r1.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
  16: mul r1.xy, r1.xyxx, r2.yzyy
  17: movc r3.xy, r0.wwww, r1.xyxx, r0.yzyy
  18: dp3 r0.y, r3.xyzx, r3.xyzx
  19: rsq r0.y, r0.y
  20: mul r0.yzw, r0.yyyy, r3.xxyz
  21: movc r0.xyz, r0.xxxx, r0.yzwy, v2.xyzx
  22: ishl r0.w, v6.x, l(4)
  23: and r1.xy, l(32, -49, 0, 0), cb2[r0.w + 4].wwww
  24: ieq r1.xz, r1.xxyx, l(0, 0, 0, 0)
  25: or r1.x, r1.z, r1.x
  26: if_z r1.x
  27:   iadd r1.xz, l(3, 0, 3, 0), cb2[r0.w + 5].xxyx
  28:   imad r2.xyzw, v5.xyzw, l(3, 3, 3, 3), r1.xxxx
  29:   imad r3.xyzw, v5.xyzw, l(3, 3, 3, 3), r1.zzzz
  30:   iadd r1.xz, r2.xxxx, l(1, 0, 2, 0)
  31:   iadd r4.xy, r3.xxxx, l(1, 2, 0, 0)
  32:   uge r1.yw, r1.yyyy, l(0, 2, 0, 4)
  33:   if_nz r1.y
  34:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r5.xyzw, r4.y, l(0), t0.xyzw
  35:     iadd r4.zw, r3.yyyy, l(0, 0, 2, 1)
  36:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r6.xyzw, r4.z, l(0), t0.xyzw
  37:     mul r6.xyzw, r6.xyzw, v4.yyyy
  38:     mad r5.xyzw, r5.xyzw, v4.xxxx, r6.xyzw
  39:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r6.xyzw, r4.x, l(0), t0.xyzw
  40:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r4.w, l(0), t0.xyzw
  41:     mul r7.xyzw, r7.xyzw, v4.yyyy
  42:     mad r6.xyzw, r6.xyzw, v4.xxxx, r7.xyzw
  43:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r3.x, l(0), t0.xyzw
  44:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r8.xyzw, r3.y, l(0), t0.xyzw
  45:     mul r8.xyzw, r8.xyzw, v4.yyyy
  46:     mad r7.xyzw, r7.xyzw, v4.xxxx, r8.xyzw
  47:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r8.xyzw, r1.z, l(0), t0.xyzw
  48:     iadd r4.zw, r2.yyyy, l(0, 0, 2, 1)
  49:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r9.xyzw, r4.z, l(0), t0.xyzw
  50:     mul r9.xyzw, r9.xyzw, v4.yyyy
  51:     mad r8.xyzw, r8.xyzw, v4.xxxx, r9.xyzw
  52:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r9.xyzw, r1.x, l(0), t0.xyzw
  53:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r4.w, l(0), t0.xyzw
  54:     mul r10.xyzw, r10.xyzw, v4.yyyy
  55:     mad r9.xyzw, r9.xyzw, v4.xxxx, r10.xyzw
  56:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r2.x, l(0), t0.xyzw
  57:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r11.xyzw, r2.y, l(0), t0.xyzw
  58:     mul r11.xyzw, r11.xyzw, v4.yyyy
  59:     mad r10.xyzw, r10.xyzw, v4.xxxx, r11.xyzw
  60:   else
  61:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r5.xyzw, r4.y, l(0), t0.xyzw
  62:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r6.xyzw, r4.x, l(0), t0.xyzw
  63:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r3.x, l(0), t0.xyzw
  64:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r8.xyzw, r1.z, l(0), t0.xyzw
  65:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r9.xyzw, r1.x, l(0), t0.xyzw
  66:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r2.x, l(0), t0.xyzw
  67:   endif
  68:   if_nz r1.w
  69:     iadd r1.xyzw, r3.zwzw, l(2, 2, 1, 1)
  70:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.xyzw, r1.x, l(0), t0.xyzw
  71:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r11.xyzw, r1.y, l(0), t0.xyzw
  72:     mul r11.xyzw, r11.xyzw, v4.wwww
  73:     mad r4.xyzw, r4.xyzw, v4.zzzz, r11.xyzw
  74:     add r5.xyzw, r4.xyzw, r5.xyzw
  75:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.xyzw, r1.z, l(0), t0.xyzw
  76:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r1.xyzw, r1.w, l(0), t0.xyzw
  77:     mul r1.xyzw, r1.xyzw, v4.wwww
  78:     mad r1.xyzw, r4.xyzw, v4.zzzz, r1.xyzw
  79:     add r6.xyzw, r1.xyzw, r6.xyzw
  80:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r1.xyzw, r3.z, l(0), t0.xyzw
  81:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r3.xyzw, r3.w, l(0), t0.xyzw
  82:     mul r3.xyzw, r3.xyzw, v4.wwww
  83:     mad r1.xyzw, r1.xyzw, v4.zzzz, r3.xyzw
  84:     add r7.xyzw, r1.xyzw, r7.xyzw
  85:     iadd r1.xyzw, r2.zwzw, l(2, 2, 1, 1)
  86:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r3.xyzw, r1.x, l(0), t0.xyzw
  87:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.xyzw, r1.y, l(0), t0.xyzw
  88:     mul r4.xyzw, r4.xyzw, v4.wwww
  89:     mad r3.xyzw, r3.xyzw, v4.zzzz, r4.xyzw
  90:     add r8.xyzw, r3.xyzw, r8.xyzw
  91:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r3.xyzw, r1.z, l(0), t0.xyzw
  92:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r1.xyzw, r1.w, l(0), t0.xyzw
  93:     mul r1.xyzw, r1.xyzw, v4.wwww
  94:     mad r1.xyzw, r3.xyzw, v4.zzzz, r1.xyzw
  95:     add r9.xyzw, r1.xyzw, r9.xyzw
  96:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r1.xyzw, r2.z, l(0), t0.xyzw
  97:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r2.xyzw, r2.w, l(0), t0.xyzw
  98:     mul r2.xyzw, r2.xyzw, v4.wwww
  99:     mad r1.xyzw, r1.xyzw, v4.zzzz, r2.xyzw
 100:     add r10.xyzw, r1.xyzw, r10.xyzw
 101:   endif
 102:   dp3 r1.x, r10.xyzx, r0.xyzx
 103:   dp3 r1.y, r9.xyzx, r0.xyzx
 104:   dp3 r0.z, r8.xyzx, r0.xyzx
 105:   mov r2.xyz, v0.xyzx
 106:   mov r2.w, l(1.000000)
 107:   dp4 r1.z, r10.xyzw, r2.xyzw
 108:   dp4 r1.w, r9.xyzw, r2.xyzw
 109:   dp4 r3.x, r8.xyzw, r2.xyzw
 110:   dp4 r4.x, r7.xyzw, r2.xyzw
 111:   dp4 r4.y, r6.xyzw, r2.xyzw
 112:   dp4 r4.z, r5.xyzw, r2.xyzw
 113:   mov r0.xy, r1.xyxx
 114: else
 115:   mov r4.xyz, v3.xyzx
 116:   mov r1.zw, v0.xxxy
 117:   mov r3.x, v0.z
 118: endif
 119: mul r2.xyz, r1.wwww, cb2[r0.w + 1].xyzx
 120: mad r2.xyz, cb2[r0.w + 0].xyzx, r1.zzzz, r2.xyzx
 121: mad r2.xyz, cb2[r0.w + 2].xyzx, r3.xxxx, r2.xyzx
 122: add r3.yzw, -cb0[44].xxyz, cb2[r0.w + 3].xxyz
 123: add r2.xyz, r2.xyzx, r3.yzwy
 124: mul r5.xyzw, r2.yyyy, cb0[33].xyzw
 125: mad r5.xyzw, cb0[32].xyzw, r2.xxxx, r5.xyzw
 126: mad r5.xyzw, cb0[34].xyzw, r2.zzzz, r5.xyzw
 127: add r5.xyzw, r5.xyzw, cb0[35].xyzw
 128: mul r1.xy, r5.wwww, cb1[19].zwzz
 129: mad o0.xy, -r1.xyxx, l(2.000000, -2.000000, 0.000000, 0.000000), r5.xyxx
 130: mul r3.yzw, r0.yyyy, cb2[r0.w + 1].xxyz
 131: mad r3.yzw, cb2[r0.w + 0].xxyz, r0.xxxx, r3.yyzw
 132: mad r0.xyz, cb2[r0.w + 2].xyzx, r0.zzzz, r3.yzwy
 133: lt r1.x, cb2[r0.w + 10].x, l(1.000000)
 134: mad o1.xy, v1.xyxx, cb3[10].xyxx, cb3[10].zwzz
 135: dp3 r1.y, r0.xyzx, r0.xyzx
 136: max r1.y, r1.y, l(0.000000)
 137: rsq r1.y, r1.y
 138: mul o3.xyz, r0.xyzx, r1.yyyy
 139: movc r0.xy, r1.xxxx, r1.zwzz, r4.xyxx
 140: movc r0.z, r1.x, r3.x, r4.z
 141: mul r1.xyz, r0.yyyy, cb2[r0.w + 7].xyzx
 142: mad r1.xyz, cb2[r0.w + 6].xyzx, r0.xxxx, r1.xyzx
 143: mad r0.xyz, cb2[r0.w + 8].xyzx, r0.zzzz, r1.xyzx
 144: add r1.xyz, -cb0[81].xyzx, cb2[r0.w + 9].xyzx
 145: add r0.xyz, r0.xyzx, r1.xyzx
 146: mul r1.xyz, r0.yyyy, cb0[58].xywx
 147: mad r0.xyw, cb0[57].xyxw, r0.xxxx, r1.xyxz
 148: mad r0.xyz, cb0[59].xywx, r0.zzzz, r0.xywx
 149: add o5.xyz, r0.xyzx, cb0[60].xywx
 150: mov o0.zw, r5.zzzw
 151: mov o2.xyz, r2.xyzx
 152: mov o4.xyz, r5.xywx
 153: mov o6.x, v6.x
 154: ret
