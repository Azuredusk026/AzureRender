from hashlib import file_digest
from pathlib import Path
import json
import os
import subprocess


out = Path(__file__).resolve().parent
native = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc')
engine = out.parent / '20261112-041837-reference-object-shadow-raster-capture-60f161/capture_frame3.rdc'
captures = {'native': (native, 'fa2ca267f7168f5603e83ad5f817a3074d8dbee23a216e6ab8ef2c340ec06a90'),
    'player': (engine, 'fe3de15f134314eacb146e9cdf143bd6d98903d8250ddda8931faa1cc0e5f856')}


def fingerprints():
    for path, expected in captures.values():
        with path.open('rb') as stream:
            assert file_digest(stream, 'sha256').hexdigest() == expected


fingerprints()
folder = out / 'source-replay'
folder.mkdir()
request = folder / 'request.json'
job = dict(output=str(folder), captures={key: dict(path=str(path), sha256=digest) for key, (path, digest) in captures.items()},
    nativeEvent=296, nativeDepth='ResourceId::141967', nativeNormal='ResourceId::141952', playerDepth='ResourceId::1137',
    playerNormal='ResourceId::1143', playerIds='ResourceId::1145', playerConsumer=340,
    playerFinalDepth='76b408186899e8a0cab586054933d9974ee59eed59d264f185cb36ced5878e0e',
    playerFinalNormals='cbe0d3780970ca90e61aecb34b4e890ddfa3d9d89aec0aafaabf29c6f4ed12e5')
request.write_text(json.dumps(job, indent=2) + '\n')
env = os.environ.copy()
for key in ('VK_LAYER_PATH', 'VK_INSTANCE_LAYERS', 'ENABLE_VULKAN_RENDERDOC_CAPTURE',
    'VK_LOADER_DRIVERS_SELECT', 'VK_DRIVER_FILES', 'VK_ICD_FILENAMES'):
    env.pop(key, None)
env['AZURE_EYEBROW_RECEIVER_REQUEST'] = str(request)
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
command = ['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe', '--python', str(out / 'replay-worker.py')]
(folder / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (folder / 'process.log').open('wb') as log:
    result = subprocess.run(command, env=env, startupinfo=startup, cwd=folder, stdout=log, stderr=subprocess.STDOUT, timeout=180)
report = json.loads((folder / 'report.json').read_text())
assert result.returncode == 0 and report['status'] == 'qualified', report
fingerprints()
print(json.dumps({key: dict(event=value['event'], vertexStride=value['postVs']['stride']) for key, value in report['captures'].items()}))
