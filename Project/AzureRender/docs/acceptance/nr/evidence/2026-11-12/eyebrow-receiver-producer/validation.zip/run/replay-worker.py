from array import array
from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import sys
import traceback
import zlib

import renderdoc as rd


request = json.loads(Path(os.environ['AZURE_EYEBROW_RECEIVER_REQUEST']).read_text(encoding='utf-8'))
out = Path(request['output'])
receipt = dict(status='failed', captures={})


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


def emit(name, raw, compress=False):
    content = zlib.compress(raw, 6) if compress else raw
    (out / name).write_bytes(content)
    return dict(path=name, bytes=len(content), sha256=sha256(content).hexdigest(), rawBytes=len(raw), rawSha256=sha256(raw).hexdigest())


def crop(data):
    assert len(data) == 2560 * 1440 * 4
    return b''.join(data[(row * 2560 + 1140) * 4:(row * 2560 + 1430) * 4] for row in range(1000, 1310))


def post_vs(controller, pipeline, label):
    mesh = controller.GetPostVSData(0, 0, rd.MeshDataStage.VSOut)
    assert mesh.numIndices == 1878 and mesh.indexByteStride in (2, 4) and mesh.vertexByteStride >= 24
    indices = bytes(controller.GetBufferData(mesh.indexResourceId, mesh.indexByteOffset, mesh.numIndices * mesh.indexByteStride))
    values = struct.unpack('<' + ('I' if mesh.indexByteStride == 4 else 'H') * mesh.numIndices, indices)
    count = max(values) + mesh.baseVertex + 1
    assert 0 <= min(values) + mesh.baseVertex and 0 < count <= 2000
    vertices = bytes(controller.GetBufferData(mesh.vertexResourceId, mesh.vertexByteOffset, count * mesh.vertexByteStride))
    assert len(vertices) == count * mesh.vertexByteStride
    reflection = pipeline.GetShaderReflection(rd.ShaderStage.Vertex)
    signature = [dict(name=item.semanticName, index=item.semanticIndex, count=item.compCount, system=str(item.systemValue),
        register=item.regIndex) for item in reflection.outputSignature]
    return dict(vertices=count, stride=mesh.vertexByteStride, indexStride=mesh.indexByteStride, baseVertex=mesh.baseVertex,
        signature=signature, vertexData=emit(label + '-vertices.zlib', vertices, True),
        indexData=emit(label + '-indices.zlib', indices, True))


def read_planes(controller, label, event, depth, normal, native):
    controller.SetFrameEvent(event, True)
    result = {}
    for name, resource in (('depth', depth), ('normal', normal)):
        raw = bytes(controller.GetTextureData(resource, rd.Subresource()))
        if name == 'depth' and native:
            assert len(raw) == 2560 * 1440 * 8 and sys.byteorder == 'little'
            words = array('I')
            assert words.itemsize == 4
            words.frombytes(raw)
            raw = words[::2].tobytes()
        assert len(raw) == 2560 * 1440 * 4
        result[name] = dict(fullSha256=sha256(raw).hexdigest(), crop=emit(f'{label}-{event}-{name}.zlib', crop(raw), True))
    return result


def replay(label, api, native):
    capture = rd.OpenCaptureFile()
    controller = None
    try:
        assert capture.OpenFile(request['captures'][label]['path'], '', None) == rd.ResultCode.Succeeded
        gpu, = [item for item in capture.GetAvailableGPUs() if item.vendor == rd.GPUVendor.nVidia and api in item.apis]
        options = rd.ReplayOptions()
        options.forceGPUVendor = gpu.vendor
        options.forceGPUDeviceID = gpu.deviceID
        status, controller = capture.OpenCapture(options, None)
        assert status == rd.ResultCode.Succeeded and controller
        properties = controller.GetAPIProperties()
        assert properties.vendor == gpu.vendor and properties.pipelineType == api and not properties.degraded
        textures = {str(item.resourceId): item for item in controller.GetTextures()}
        actions = {action.eventId: action for action in walk(controller.GetRootActions())}
        if native:
            event = request['nativeEvent']
            depth, normal = [textures[request[key]].resourceId for key in ('nativeDepth', 'nativeNormal')]
            assert (actions[event].numIndices, actions[event].numInstances) == (1878, 1)
        else:
            depth, normal, identity = [textures[request[key]].resourceId for key in ('playerDepth', 'playerNormal', 'playerIds')]
            candidates = []
            for event_id, action in actions.items():
                if event_id >= request['playerConsumer'] or not action.flags & rd.ActionFlags.Drawcall:
                    continue
                if (action.numIndices, action.numInstances) != (1878, 1):
                    continue
                controller.SetFrameEvent(event_id, True)
                pipe = controller.GetPipelineState()
                targets = [binding.resource for binding in pipe.GetOutputTargets()]
                if all(resource in targets for resource in (depth, normal, identity)):
                    candidates.append(event_id)
            assert len(candidates) == 1, candidates
            event = candidates[0]
        controller.SetFrameEvent(event, True)
        pipe = controller.GetPipelineState()
        if native:
            assert pipe.GetDepthTarget().resource == depth and pipe.GetOutputTargets()[3].resource == normal
        programs = {}
        for name, stage in (('vertex', rd.ShaderStage.Vertex), ('pixel', rd.ShaderStage.Pixel)):
            reflection = pipe.GetShaderReflection(stage)
            code = bytes(reflection.rawBytes)
            text = controller.DisassembleShader(pipe.GetGraphicsPipelineObject(), reflection, '').encode()
            programs[name] = dict(shaderSha256=sha256(code).hexdigest(), assembly=emit(f'{label}-{name}.asm', text))
        before_event = max(value for value in actions if value < event)
        post = post_vs(controller, pipe, label)
        before = read_planes(controller, label, before_event, depth, normal, native)
        after = read_planes(controller, label, event, depth, normal, native)
        final_event = 699 if native else request['playerConsumer']
        final = read_planes(controller, label, final_event, depth, normal, native)
        writers = {}
        if native:
            assert final['depth']['fullSha256'] == '02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb'
            assert final['normal']['fullSha256'] == '63731d707e7ba30d9417049c8148b9bd2167208e435e8d9f0cc100a1fd03e095'
        else:
            assert final['depth']['fullSha256'] == request['playerFinalDepth']
            assert final['normal']['fullSha256'] == request['playerFinalNormals']
            writer_events = sorted({usage.eventId for usage in controller.GetUsage(depth)
                if usage.eventId < final_event and usage.usage == rd.ResourceUsage.ColorTarget
                and usage.eventId in actions and actions[usage.eventId].flags & rd.ActionFlags.Drawcall})
            assert event in writer_events and len(writer_events) <= 32
            for writer in writer_events:
                writers[writer] = dict(indices=actions[writer].numIndices,
                    planes=after if writer == event else read_planes(controller, label, writer, depth, normal, False))
        return dict(api=str(api), device=gpu.name, event=event, beforeEvent=before_event, finalEvent=final_event,
            indexCount=1878, depthResource=str(depth), normalResource=str(normal), programs=programs, postVs=post,
            before=before, after=after, final=final, writers=writers,
            messages=[str(item.description) for item in controller.GetDebugMessages()])
    finally:
        if controller:
            controller.Shutdown()
        capture.Shutdown()


try:
    receipt['captures']['native'] = replay('native', rd.GraphicsAPI.D3D11, True)
    receipt['captures']['player'] = replay('player', rd.GraphicsAPI.Vulkan, False)
    receipt['status'] = 'qualified'
except BaseException:
    receipt['error'] = traceback.format_exc()
finally:
    (out / 'report.json').write_text(json.dumps(receipt, indent=2) + '\n')
os._exit(0 if receipt['status'] == 'qualified' else 1)
