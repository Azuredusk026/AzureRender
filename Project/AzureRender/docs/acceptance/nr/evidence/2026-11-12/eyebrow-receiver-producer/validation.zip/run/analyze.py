from hashlib import sha256
from itertools import permutations
from pathlib import Path
import json
import zipfile
import zlib

import numpy as np


out = Path(__file__).resolve().parent
source = out / 'source-replay'
atlas = out.parent / '20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
numeric = out.parent / '20261110-003435-visibility-numeric-contract-4f95e7'
latest = out.parent / '20261112-093321-reference-normal-sampled-rg-ceb2c6'
report = json.loads((source / 'report.json').read_text())
assert report['status'] == 'qualified'
receipt = json.loads((out / 'replay-execution.json').read_text())
assert receipt['status'] == 'exited' and receipt['exitCode'] == 0
native, player = [report['captures'][key] for key in ('native', 'player')]
assert native['event'] == 296 and native['indexCount'] == player['indexCount'] == 1878


def inflated(folder, entry):
    data = (folder / entry['path']).read_bytes()
    assert len(data) == entry['bytes'] and sha256(data).hexdigest() == entry['sha256']
    raw = zlib.decompress(data)
    if 'rawSha256' in entry:
        assert len(raw) == entry['rawBytes'] and sha256(raw).hexdigest() == entry['rawSha256']
    return raw


def crop(folder, entry):
    return np.frombuffer(inflated(folder, entry), '<u4').reshape(310, 290)


def planes(record):
    return tuple(crop(source, record[key]['crop']) for key in ('depth', 'normal'))


history = json.loads((atlas / 'native-atlas-producers.json').read_text())['receiverNormal']['stages']
native_owner = np.zeros((310, 290), dtype='u2')
last = np.zeros((310, 290), dtype='<u4')
for event, row in history.items():
    current = crop(atlas, row['crop'])
    native_owner[current != last] = int(event)
    last = current
coordinates = np.fromfile(numeric / 'receiver-queries.bin', '<f4').reshape(-1, 4)
x, y = coordinates[:, :2].astype('i4').T
expected = np.fromfile(numeric / 'receiver-expected.bin', '<u4').astype('i4')
assert len(expected) == len(x) == 49384
eyebrow = native_owner[y - 1000, x - 1140] == 296
assert int(eyebrow.sum()) == 496
x, y, expected = x[eyebrow], y[eyebrow], expected[eyebrow]
origin = y - 1000, x - 1140
native_before = planes(native['before'])
native_after = planes(native['after'])
native_final = planes(native['final'])
assert np.array_equal(last, native_final[1])
native_wrote = (native_before[0] != native_after[0]) | (native_before[1] != native_after[1])
assert native_wrote[origin].all() and np.array_equal(native_after[1][origin], native_final[1][origin])
host_before = planes(player['before'])
host_after = planes(player['after'])
host_final = planes(player['final'])
host_wrote = ((host_before[0] != host_after[0]) | (host_before[1] != host_after[1]))[origin]
host_kept_depth = host_wrote & (host_after[0][origin] == host_final[0][origin])
host_kept_normal = host_wrote & (host_after[1][origin] == host_final[1][origin])

last_depth = np.zeros_like(host_final[0])
last_normal = np.zeros_like(host_final[1])
host_depth_owner = np.zeros_like(native_owner)
host_normal_owner = np.zeros_like(native_owner)
for event, row in player['writers'].items():
    written_depth, written_normal = planes(row['planes'])
    host_depth_owner[written_depth != last_depth] = int(event)
    host_normal_owner[written_normal != last_normal] = int(event)
    last_depth, last_normal = written_depth, written_normal
assert np.array_equal(host_final[0], last_depth) and np.array_equal(host_final[1], last_normal)


def latest_read(folder):
    catalog = json.loads((folder / 'reference-planes.json').read_text())
    with zipfile.ZipFile(folder / 'reference-planes.zip') as archive:
        def field(name, dtype, channels):
            entry = catalog[name]
            raw = archive.read(entry['archiveEntry'])
            assert sha256(raw).hexdigest() == entry['sha256']
            return np.frombuffer(raw, dtype).reshape(1440, 2560, channels)[y, x]
        return (field('reference-depth-r32.bin', '<u4', 1)[:, 0],
            field('reference-normals-a2b10g10r10.bin', '<u4', 1)[:, 0],
            field('reference-object-visibility-rg8.bin', 'u1', 2)[:, 1])


depth, normal, visibility = latest_read(latest / 'release-nvidia-frames')
delta = np.abs(visibility.astype('i4') - expected)
failed = delta > 1
assert int(failed.sum()) == 140 and int(delta.max()) == 251
intel_depth, intel_normal, intel_visibility = latest_read(latest / 'release-intel-frames')
intel_delta = np.abs(intel_visibility.astype('i4') - expected)
intel_failed = intel_delta > 1
assert int(intel_failed.sum()) == 139 and int(intel_delta.max()) == 251
native_depth_ulp = np.abs(depth.astype('i8') - native_final[0][origin].astype('i8'))
retained = host_normal_owner[origin] == player['event']
assert int((retained & failed).sum()) == 24
assert np.array_equal(normal, host_final[1][origin])
changed_depth = depth != host_final[0][origin]
changed_normal = normal != host_final[1][origin]


def counts(mask):
    return dict(all=int(mask.sum()), failed=int((mask & failed).sum()))


coverage = dict(nativePoints=len(x), latestFailures=int(failed.sum()), hostDrawWrites=counts(host_wrote),
    hostDrawMissing=counts(~host_wrote), hostDrawDepthRetained=counts(host_kept_depth), hostDrawNormalRetained=counts(host_kept_normal),
    hostDepthChangesSinceCapture=counts(changed_depth), hostNormalChangesSinceCapture=counts(changed_normal),
    intelFailures=int(intel_failed.sum()), intelAtHostHairPoints=int((intel_failed & ~retained).sum()),
    depthOver64UlpAtHostHairPoints=int(((native_depth_ulp > 64) & ~retained & failed).sum()),
    hostDepthOwner={int(event): counts(host_depth_owner[origin] == event) for event in np.unique(host_depth_owner[origin])},
    hostNormalOwner={int(event): counts(host_normal_owner[origin] == event) for event in np.unique(host_normal_owner[origin])})


def vertex_array(stage):
    mesh = stage['postVs']
    return np.frombuffer(inflated(source, mesh['vertexData']), '<f4').reshape(mesh['vertices'], mesh['stride'] // 4)


def uv_words(uv):
    words = uv.astype('<f2').view('<u2').astype('u4')
    return words[:, 0] | (words[:, 1] << 16)


native_vertices = vertex_array(native)
player_vertices = vertex_array(player)
native_uv = native_vertices[:, 4:6]
assert native['postVs']['signature'][1]['name'] == 'TEXCOORD' and native['postVs']['signature'][1]['count'] == 2
native_uv_flipped = native_uv.copy()
native_uv_flipped[:, 1] = 1 - native_uv[:, 1]
choices = []
for name, native_coordinates in (('direct', native_uv), ('1-v', native_uv_flipped)):
    native_keys = uv_words(native_coordinates)
    for offset in range(4, player_vertices.shape[1] - 1):
        candidate = player_vertices[:, offset:offset + 2]
        if not np.isfinite(candidate).all() or np.abs(candidate).max() > 16:
            continue
        host_keys = uv_words(candidate)
        choices.append((int(np.isin(host_keys, native_keys).sum()), name, offset, native_keys, host_keys))
best = max(choices, key=lambda case: case[0])
matched, orientation, offset, native_keys, host_keys = best
def indices(stage):
    mesh = stage['postVs']
    return np.frombuffer(inflated(source, mesh['indexData']), '<u' + str(mesh['indexStride'])).astype('i4') + mesh['baseVertex']


native_indices, host_indices = indices(native), indices(player)
assert len(native_indices) == len(host_indices) == 1878
assert matched == len(native_vertices) == len(player_vertices) == 578
from itertools import permutations
native_triangles = native_indices.reshape(-1, 3)
host_triangles = host_indices.reshape(-1, 3)
for order in permutations(range(3)):
    candidate = host_triangles[:, order].ravel()
    if np.array_equal(native_keys[native_indices], host_keys[candidate]):
        host_indices = candidate
        break
else:
    raise AssertionError((native_indices[:18].tolist(), host_indices[:18].tolist(),
        int((native_keys == host_keys).sum()), int((native_keys[native_indices] == host_keys[host_indices]).sum())))
pairs = np.unique(np.column_stack((native_indices, host_indices)), axis=0)
assert pairs.shape == (578, 2)
assert len(np.unique(pairs[:, 0])) == len(np.unique(pairs[:, 1])) == 578
native_clip = native_vertices[pairs[:, 0], :4]
host_clip = player_vertices[pairs[:, 1], :4]
assert np.isfinite(native_clip).all() and np.isfinite(host_clip).all()
assert np.all(native_clip[:, 3] != 0) and np.all(host_clip[:, 3] != 0)
native_ndc = native_clip[:, :3].astype('f8') / native_clip[:, 3, None]
host_ndc = host_clip[:, :3].astype('f8') / host_clip[:, 3, None]
projected = {}
for key, y_sign in (('direct', 1), ('invertedY', -1)):
    ndc = native_ndc * [1, y_sign, 1]
    screen = np.abs((ndc[:, :2] - host_ndc[:, :2]) * [1280, 720]).max(axis=1)
    depth_error = np.abs(ndc[:, 2] - host_ndc[:, 2])
    projected[key] = dict(pixelMedian=float(np.median(screen)), pixelP95=float(np.quantile(screen, .95)),
        pixelMaximum=float(screen.max()), depthMedian=float(np.median(depth_error)), depthMaximum=float(depth_error.max()))
geometry = dict(nativeVertices=len(native_vertices), hostVertices=len(player_vertices), matchedUv=matched,
    indexedCorners=len(native_indices), pairedVertices=len(pairs), hostTriangleCornerOrder=order, hostUvFloatOffset=offset, nativeUvOrientation=orientation, projection=projected)
result = dict(nativeEvent=native['event'], hostEvent=player['event'], coverage=coverage, geometry=geometry)
(out / 'eyebrow-producer-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
