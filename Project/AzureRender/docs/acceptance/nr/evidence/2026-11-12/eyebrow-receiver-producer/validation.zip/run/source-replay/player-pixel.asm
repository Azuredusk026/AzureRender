SPIR-V 1.3 module, <id> bound of 707

Generator: Shaderc over Glslang from Google - Contact David Neto, dneto@google.com
Generator Version: 11

Capability(Shader);
Capability(ImageQuery);
Capability(DerivativeControl);
Capability(GroupNonUniform);
Capability(GroupNonUniformQuad);
Capability(ShaderNonUniform);
Capability(RuntimeDescriptorArray);
Capability(SampledImageArrayNonUniformIndexing);

Extension("SPV_EXT_descriptor_indexing");


MemoryModel(Logical, GLSL450);

EntryPoint(Fragment, main, "main", {
    textureCoordinate, 
    gl_FrontFacing, 
    worldNormal, 
    worldTangent, 
    opacityCoordinate, 
    referenceDepth, 
    gl_FragCoord, 
    packedNormal, 
    objectId, 
    instanceObjectShadow, 
    worldPosition
  });

ExecutionMode(main, OriginUpperLeft);

Source(GLSL, 450);
SourceExtension("GL_EXT_nonuniform_qualifier");
SourceExtension("GL_GOOGLE_cpp_style_line_directive");
SourceExtension("GL_GOOGLE_include_directive");
SourceExtension("GL_KHR_shader_subgroup_basic");
SourceExtension("GL_KHR_shader_subgroup_quad");




Private float2* azurePrimaryUvDx;
Private float2* azurePrimaryUvDy;
struct Material : [[Block]] {
  float alphaCutoff : [[Offset(0)]];
  int alphaMode : [[Offset(4)]];
  float4 normalControl : [[Offset(64)]];
  uint features : [[Offset(116)]];
  uint textureBase : [[Offset(136)]];
  float nodeOpacity : [[Offset(140)]];
}
PushConstant Material* material;
Input float2* textureCoordinate : [[Location(2)]];
Input bool* gl_FrontFacing : [[BuiltIn(FrontFacing)]];
UniformConstant SampledImage<float, 2D>[]* textures : [[DescriptorSet(0), Binding(1)]];
Input float3* worldNormal : [[Location(0)]];
Input float4* worldTangent : [[Location(1)]];
Input float3* opacityCoordinate : [[Location(14)]];
Output float* referenceDepth : [[Location(0)]];
Input float4* gl_FragCoord : [[BuiltIn(FragCoord)]];
Output float4* packedNormal : [[Location(1)]];
Output uint* objectId : [[Location(2)]];
Input uint* instanceObjectShadow : [[Location(15), Flat]];
Input float3* worldPosition : [[Location(3)]];

void main() {
  float2* param;
  float3* normal;
  float3* param@2;
  float* param@3;
  float* alpha;
  float* _666;
  float3* param@4;
  float3* param@5;
  float2 _638 = *textureCoordinate;
  *param = _638;
  azurePreparePrimaryUv(param);
  float3 _641 = surfaceNormal();
  *normal = _641;
  float3 _645 = *opacityCoordinate;
  *param@2 = _645;
  float* _647 = &material.nodeOpacity;
  float _648 = *_647;
  *param@3 = _648;
  bool _649 = azureNodeOpacityCovered(param@2, param@3);
  bool _650 = !_649;
  
  if(_650) {
    Kill();
  }

  int* _655 = &material.alphaMode;
  int _656 = *_655;
  bool _657 = _656 == 1;
  
  if(_657) {
    uint* _661 = &material.features;
    uint _662 = *_661;
    uint _664 = _662 & 33554432;
    bool _665 = _664 != 0;
    
    if(_665) {
      uint* _669 = &material.textureBase;
      uint _670 = *_669;
      uint _671 = _670 + 2;
      uint _672 = CopyObject(_671) : [[NonUniform]];
      SampledImage<float, 2D>* _673 = &textures[_672];
      float _674 = coverageAlpha(_673);
      *_666 = _674;
    } else {
      uint* _676 = &material.textureBase;
      uint _677 = *_676;
      uint _678 = CopyObject(_677) : [[NonUniform]];
      SampledImage<float, 2D>* _679 = &textures[_678];
      float _680 = coverageAlpha(_679);
      *_666 = _680;
    }

    float _681 = *_666;
    *alpha = _681;
    float _682 = *alpha;
    float* _683 = &material.alphaCutoff;
    float _684 = *_683;
    bool _685 = _682 < _684;
    
    if(_685) {
      Kill();
    }

  }

  float* _692 = &gl_FragCoord.z;
  float _693 = *_692;
  *referenceDepth = _693;
  float3 _697 = *normal;
  *param@4 = _697;
  float3 _698 = referenceNormal(param@4);
  *param@5 = _698;
  float4 _700 = encodeVisibilityNormal(param@5);
  *packedNormal = _700;
  uint _705 = *instanceObjectShadow;
  *objectId = _705;
  return;
}

float2x2 azureMirroredCoarseUvGradients(float2* uv) {
  float2* dx;
  float2* dy;
  float2 _82 = *uv;
  float2 _83 = DPdxFine(_82);
  *dx = _83;
  float2 _85 = *uv;
  float2 _86 = DPdyFine(_85);
  *dy = _86;
  float2 _87 = *dx;
  float2 _90 = GroupNonUniformQuadBroadcast(Subgroup, _87, 2);
  float2 _91 = *dy;
  float2 _93 = GroupNonUniformQuadBroadcast(Subgroup, _91, 0);
  float _96 = _90.x;
  float _97 = _90.y;
  float _98 = _93.x;
  float _99 = _93.y;
  float2 _100 = CompositeConstruct({_96, _97});
  float2 _101 = CompositeConstruct({_98, _99});
  float2x2 _102 = CompositeConstruct({_100, _101});
  return _102;
}

void azurePreparePrimaryUv(float2* uv@2) {
  float2x2* gradients;
  float2* param@6;
  float2 _108 = *uv@2;
  *param@6 = _108;
  float2x2 _109 = azureMirroredCoarseUvGradients(param@6);
  *gradients = _109;
  float2* _114 = &gradients[0];
  float2 _115 = *_114;
  *azurePrimaryUvDx = _115;
  float2* _118 = &gradients[1];
  float2 _119 = *_118;
  *azurePrimaryUvDy = _119;
  return;
}

float4 azureSamplePrimaryUv(SampledImage<float, 2D>* image, float2* uv@3) {
  SampledImage<float, 2D> _120 = *image;
  float2 _121 = *uv@3;
  float2 _122 = *azurePrimaryUvDx;
  float2 _123 = *azurePrimaryUvDy;
  float4 _124 = ImageSampleExplicitLod(_120, _121, Grad(_122, _123));
  return _124;
}

float azureEllipseMajorAxisLod(float2* dx@2, float2* dy@2) {
  float* scale;
  float2* x;
  float2* y;
  float* a;
  float* b;
  float* c;
  float* eigenvalue;
  float* _128 = &dx@2.x;
  float _129 = *_128;
  float _130 = GLSL.std.450::FAbs(_129);
  float* _132 = &dx@2.y;
  float _133 = *_132;
  float _134 = GLSL.std.450::FAbs(_133);
  float _135 = GLSL.std.450::FMax(_130, _134);
  float* _136 = &dy@2.x;
  float _137 = *_136;
  float _138 = GLSL.std.450::FAbs(_137);
  float* _139 = &dy@2.y;
  float _140 = *_139;
  float _141 = GLSL.std.450::FAbs(_140);
  float _142 = GLSL.std.450::FMax(_138, _141);
  float _143 = GLSL.std.450::FMax(_135, _142);
  *scale = _143;
  float2 _145 = *dx@2;
  float _146 = *scale;
  float _148 = GLSL.std.450::FMax(_146, 0.0000);
  float2 _149 = CompositeConstruct({_148, _148});
  float2 _150 = _145 / _149;
  *x = _150;
  float2 _152 = *dy@2;
  float _153 = *scale;
  float _154 = GLSL.std.450::FMax(_153, 0.0000);
  float2 _155 = CompositeConstruct({_154, _154});
  float2 _156 = _152 / _155;
  *y = _156;
  float2 _158 = *x;
  float2 _159 = *x;
  float _160 = Dot(_158, _159);
  *a = _160;
  float2 _162 = *x;
  float2 _163 = *y;
  float _164 = Dot(_162, _163);
  *b = _164;
  float2 _166 = *y;
  float2 _167 = *y;
  float _168 = Dot(_166, _167);
  *c = _168;
  float _171 = *a;
  float _172 = *c;
  float _173 = _171 + _172;
  float _174 = *a;
  float _175 = *c;
  float _176 = _174 - _175;
  float _177 = *a;
  float _178 = *c;
  float _179 = _177 - _178;
  float _180 = _176 * _179;
  float _182 = *b;
  float _183 = 4.0000 * _182;
  float _184 = *b;
  float _185 = _183 * _184;
  float _186 = _180 + _185;
  float _187 = GLSL.std.450::Sqrt(_186);
  float _188 = _173 + _187;
  float _189 = 0.5000 * _188;
  *eigenvalue = _189;
  float _191 = *scale;
  float _192 = GLSL.std.450::FMax(_191, 0.0000);
  float _193 = GLSL.std.450::Log2(_192);
  float _194 = *eigenvalue;
  float _195 = GLSL.std.450::FMax(_194, 0.0000);
  float _196 = GLSL.std.450::Log2(_195);
  float _197 = 0.5000 * _196;
  float _198 = _193 + _197;
  float _199 = GLSL.std.450::FMax(-126.0000, _198);
  return _199;
}

float azureSampleCoverageAlpha(SampledImage<float, 2D>* image@2, float2* uv@4, uint* features) {
  float2* size;
  float2* param@7;
  float2* param@8;
  float2* param@9;
  uint _202 = *features;
  uint _204 = _202 & 268435456;
  bool _205 = _204 != 0;
  
  if(_205) {
    SampledImage<float, 2D> _209 = *image@2;
    Image<float, 2D> _210 = Image(_209);
    int2 _212 = ImageQuerySizeLod(_210, 0);
    float2 _213 = ConvertSToF(_212);
    *size = _213;
    SampledImage<float, 2D> _214 = *image@2;
    float2 _215 = *uv@4;
    float2 _216 = *azurePrimaryUvDx;
    float2 _217 = *size;
    float2 _218 = _216 * _217;
    float2 _219 = *azurePrimaryUvDy;
    float2 _220 = *size;
    float2 _221 = _219 * _220;
    *param@7 = _218;
    *param@8 = _221;
    float _224 = azureEllipseMajorAxisLod(param@7, param@8);
    float4 _225 = ImageSampleExplicitLod(_214, _215, Lod(_224));
    float _226 = _225.w;
    return _226;
  }

  float2 _229 = *uv@4;
  *param@9 = _229;
  float4 _230 = azureSamplePrimaryUv(image@2, param@9);
  float _231 = _230.w;
  return _231;
}

bool azureNodeOpacityCovered(float3* coordinate, float* opacity) {
  uint3* cell;
  uint* hash;
  float _234 = *opacity;
  bool _235 = _234 >= 1.0000;
  
  if(_235) {
    return true;
  }

  float _240 = *opacity;
  bool _241 = _240 <= 0.0000;
  
  if(_241) {
    return false;
  }

  float3 _249 = *coordinate;
  float3 _251 = _249 * 256.0000;
  float3 _252 = GLSL.std.450::Floor(_251);
  int3 _254 = ConvertFToS(_252);
  uint3 _255 = Bitcast(_254);
  *cell = _255;
  uint* _257 = &cell.x;
  uint _258 = *_257;
  uint _260 = _258 * 1597334677;
  uint* _261 = &cell.y;
  uint _262 = *_261;
  uint _264 = _262 * 3812015801;
  uint _265 = _260 ^ _264;
  uint* _266 = &cell.z;
  uint _267 = *_266;
  uint _269 = _267 * 2798796415;
  uint _270 = _265 ^ _269;
  *hash = _270;
  uint _271 = *hash;
  uint _273 = _271 >> 16;
  uint _274 = *hash;
  uint _275 = _274 ^ _273;
  *hash = _275;
  uint _277 = *hash;
  uint _278 = _277 * 2246822519;
  *hash = _278;
  uint _279 = *hash;
  uint _281 = _279 >> 13;
  uint _282 = *hash;
  uint _283 = _282 ^ _281;
  *hash = _283;
  uint _284 = *hash;
  uint _286 = _284 >> 8;
  float _287 = ConvertUToF(_286);
  float _289 = _287 * 0.0000;
  float _290 = *opacity;
  bool _291 = _289 < _290;
  return _291;
}

float3 characterProjectedSafeNormalize(float3* value, float3* fallback) {
  float* length2;
  float3* _301;
  float3 _295 = *value;
  float3 _296 = *value;
  float _297 = Dot(_295, _296);
  *length2 = _297;
  float _298 = *length2;
  bool _300 = _298 > 0.0000;
  
  if(_300) {
    float3 _304 = *value;
    float _305 = *length2;
    float _306 = GLSL.std.450::InverseSqrt(_305);
    float3 _307 = _304 * _306;
    *_301 = _307;
  } else {
    float3 _309 = *fallback;
    *_301 = _309;
  }

  float3 _310 = *_301;
  return _310;
}

float3 characterProjectedHairNormal(float2* encoded, float* scale@2, float3* normal@2, float4* tangent) {
  float2* xy;
  float* z;
  float3* bitangent;
  float3* param@10;
  float3* param@11;
  float3* param@12;
  float3* param@13;
  float* _314 = &encoded.x;
  float _315 = *_314;
  float _317 = _315 * 2.0000;
  float _318 = _317 - 1.0000;
  float* _319 = &encoded.y;
  float _320 = *_319;
  float _321 = _320 * 2.0000;
  float _322 = 1.0000 - _321;
  float2 _323 = CompositeConstruct({_318, _322});
  *xy = _323;
  float2 _325 = *xy;
  float2 _326 = *xy;
  float _327 = Dot(_325, _326);
  float _328 = GLSL.std.450::FMin(_327, 1.0000);
  float _329 = 1.0000 - _328;
  float _330 = GLSL.std.450::FMax(_329, 0.0000);
  float _331 = GLSL.std.450::Sqrt(_330);
  *z = _331;
  float3 _333 = *normal@2;
  float4 _334 = *tangent;
  float3 _335 = _334.xyz;
  float3 _336 = GLSL.std.450::Cross(_333, _335);
  float* _337 = &tangent.w;
  float _338 = *_337;
  float3 _339 = _336 * _338;
  *bitangent = _339;
  float4 _340 = *tangent;
  float3 _341 = _340.xyz;
  float* _342 = &xy.x;
  float _343 = *_342;
  float3 _344 = _341 * _343;
  float _345 = *scale@2;
  float3 _346 = _344 * _345;
  float3 _347 = *bitangent;
  float* _348 = &xy.y;
  float _349 = *_348;
  float3 _350 = _347 * _349;
  float _351 = *scale@2;
  float3 _352 = _350 * _351;
  float3 _353 = _346 + _352;
  float3 _354 = *normal@2;
  float _355 = *z;
  float3 _356 = _354 * _355;
  float3 _357 = _353 + _356;
  float3 _360 = *normal@2;
  *param@10 = _360;
  *param@11 = {0.0000, 0.0000, 1.0000};
  float3 _362 = characterProjectedSafeNormalize(param@10, param@11);
  *param@12 = _357;
  *param@13 = _362;
  float3 _365 = characterProjectedSafeNormalize(param@12, param@13);
  return _365;
}

float4 sampleSurfaceTexture(SampledImage<float, 2D>* image@3) {
  float4* _378;
  float2* param@14;
  uint* _373 = &material.features;
  uint _374 = *_373;
  uint _376 = _374 & 134217728;
  bool _377 = _376 != 0;
  
  if(_377) {
    float2 _384 = *textureCoordinate;
    *param@14 = _384;
    float4 _385 = azureSamplePrimaryUv(image@3, param@14);
    *_378 = _385;
  } else {
    SampledImage<float, 2D> _387 = *image@3;
    float2 _388 = *textureCoordinate;
    float4 _389 = ImageSampleImplicitLod(_387, _388);
    *_378 = _389;
  }

  float4 _390 = *_378;
  return _390;
}

float3 surfaceNormal() {
  float* facing;
  float* mode;
  float2* encoded@2;
  float2* _411;
  float2* param@15;
  float* param@16;
  float3* param@17;
  float4* param@18;
  float3* normal@3;
  float3* param@19;
  float3* param@20;
  float3* tangent@2;
  float3* param@21;
  float3* param@22;
  float3* bitangent@2;
  float3* sampled;
  float3* param@23;
  float3* param@24;
  bool _396 = *gl_FrontFacing;
  float _398 = Select(_396, 1.0000, -1.0000);
  *facing = _398;
  float* _402 = &material.normalControl.x;
  float _403 = *_402;
  *mode = _403;
  float _404 = *mode;
  bool _405 = _404 > 0.0000;
  
  if(_405) {
    float _409 = *mode;
    bool _410 = _409 == 2.0000;
    
    if(_410) {
      uint* _418 = &material.textureBase;
      uint _419 = *_418;
      uint _420 = _419 + 1;
      uint _421 = CopyObject(_420) : [[NonUniform]];
      SampledImage<float, 2D>* _422 = &textures[_421] : [[NonUniform]];
      SampledImage<float, 2D> _423 = *_422 : [[NonUniform]];
      float2 _424 = *textureCoordinate;
      float4 _425 = ImageSampleImplicitLod(_423, _424);
      float2 _426 = _425.xy;
      *_411 = _426;
    } else {
      uint* _428 = &material.textureBase;
      uint _429 = *_428;
      uint _431 = _429 + 7;
      uint _432 = CopyObject(_431) : [[NonUniform]];
      SampledImage<float, 2D>* _433 = &textures[_432];
      float4 _434 = sampleSurfaceTexture(_433);
      float2 _435 = _434.xy;
      *_411 = _435;
    }

    float2 _436 = *_411;
    *encoded@2 = _436;
    float _437 = *mode;
    bool _438 = _437 == 2.0000;
    
    if(_438) {
      float* _441 = &encoded@2.y;
      float _442 = *_441;
      float _443 = 1.0000 - _442;
      float* _444 = &encoded@2.y;
      *_444 = _443;
    }

    float4 _449 = *worldTangent;
    float3 _450 = _449.xyz;
    float* _452 = &worldTangent.w;
    float _453 = *_452;
    float* _454 = &material.normalControl.z;
    float _455 = *_454;
    float _456 = _453 * _455;
    float _457 = _450.x;
    float _458 = _450.y;
    float _459 = _450.z;
    float4 _460 = CompositeConstruct({_457, _458, _459, _456});
    float2 _462 = *encoded@2;
    *param@15 = _462;
    float* _464 = &material.normalControl.y;
    float _465 = *_464;
    *param@16 = _465;
    float3 _467 = *worldNormal;
    *param@17 = _467;
    *param@18 = _460;
    float3 _469 = characterProjectedHairNormal(param@15, param@16, param@17, param@18);
    float _470 = *facing;
    float3 _471 = _469 * _470;
    return _471;
  }

  float3 _475 = *worldNormal;
  *param@19 = _475;
  *param@20 = {0.0000, 0.0000, 1.0000};
  float3 _477 = characterProjectedSafeNormalize(param@19, param@20);
  float _478 = *facing;
  float3 _479 = _477 * _478;
  *normal@3 = _479;
  float4 _481 = *worldTangent;
  float3 _482 = _481.xyz;
  float3 _483 = *normal@3;
  float3 _484 = *normal@3;
  float4 _485 = *worldTangent;
  float3 _486 = _485.xyz;
  float _487 = Dot(_484, _486);
  float3 _488 = _483 * _487;
  float3 _489 = _482 - _488;
  *param@21 = _489;
  *param@22 = {1.0000, 0.0000, 0.0000};
  float3 _493 = characterProjectedSafeNormalize(param@21, param@22);
  *tangent@2 = _493;
  float3 _495 = *normal@3;
  float3 _496 = *tangent@2;
  float3 _497 = GLSL.std.450::Cross(_495, _496);
  float* _498 = &worldTangent.w;
  float _499 = *_498;
  float3 _500 = _497 * _499;
  *bitangent@2 = _500;
  uint* _502 = &material.textureBase;
  uint _503 = *_502;
  uint _504 = _503 + 1;
  uint _505 = CopyObject(_504) : [[NonUniform]];
  SampledImage<float, 2D>* _506 = &textures[_505];
  float4 _507 = sampleSurfaceTexture(_506);
  float3 _508 = _507.xyz;
  float3 _509 = _508 * 2.0000;
  float3 _510 = CompositeConstruct({1.0000, 1.0000, 1.0000});
  float3 _511 = _509 - _510;
  *sampled = _511;
  float3 _512 = *tangent@2;
  float3 _513 = *bitangent@2;
  float3 _514 = *normal@3;
  float _516 = _512.x;
  float _517 = _512.y;
  float _518 = _512.z;
  float _519 = _513.x;
  float _520 = _513.y;
  float _521 = _513.z;
  float _522 = _514.x;
  float _523 = _514.y;
  float _524 = _514.z;
  float3 _525 = CompositeConstruct({_516, _517, _518});
  float3 _526 = CompositeConstruct({_519, _520, _521});
  float3 _527 = CompositeConstruct({_522, _523, _524});
  float3x3 _528 = CompositeConstruct({_525, _526, _527});
  float3 _529 = *sampled;
  float3 _530 = _528 * _529;
  *param@23 = _530;
  float3 _533 = *normal@3;
  *param@24 = _533;
  float3 _534 = characterProjectedSafeNormalize(param@23, param@24);
  return _534;
}

float3 referenceNormal(float3* world) {
  uint* axes;
  uint* axis;
  uint* code;
  float3* result;
  float* _538 = &material.normalControl.w;
  float _539 = *_538;
  uint _540 = ConvertFToU(_539);
  *axes = _540;
  *axis = 0;

  while(true) {
    uint _547 = *axis;
    bool _548 = _547 < 3;
    if(!_548) break;
    uint _550 = *axes;
    uint _551 = *axis;
    uint _552 = _551 * 3;
    uint _553 = _550 >> _552;
    uint _554 = _553 & 7;
    *code = _554;
    uint _556 = *axis;
    uint _557 = *code;
    uint _558 = _557 & 3;
    float* _559 = &world[_558];
    float _560 = *_559;
    uint _561 = Bitcast(_560);
    uint _562 = *code;
    uint _564 = _562 & 4;
    uint _566 = _564 << 29;
    uint _567 = _561 ^ _566;
    float _568 = Bitcast(_567);
    float* _569 = &result[_556];
    *_569 = _568;
    uint _570 = *axis;
    uint _571 = _570 + 1;
    *axis = _571;
  }

  float3 _572 = *result;
  return _572;
}

float4 encodeVisibilityNormal(float3* normal@4) {
  float2* oct;
  float3 _576 = *normal@4;
  float2 _577 = _576.xz;
  float* _578 = &normal@4.x;
  float _579 = *_578;
  float _580 = GLSL.std.450::FAbs(_579);
  float* _581 = &normal@4.y;
  float _582 = *_581;
  float _583 = GLSL.std.450::FAbs(_582);
  float _584 = _580 + _583;
  float* _585 = &normal@4.z;
  float _586 = *_585;
  float _587 = GLSL.std.450::FAbs(_586);
  float _588 = _584 + _587;
  float2 _589 = CompositeConstruct({_588, _588});
  float2 _590 = _577 / _589;
  *oct = _590;
  float* _591 = &normal@4.y;
  float _592 = *_591;
  bool _593 = _592 < 0.0000;
  
  if(_593) {
    float2 _596 = *oct;
    float2 _597 = _596.yx;
    float2 _598 = GLSL.std.450::FAbs(_597);
    float2 _599 = CompositeConstruct({1.0000, 1.0000});
    float2 _600 = _599 - _598;
    float2 _603 = *oct;
    bool _606 = _603 >= {0.0000, 0.0000};
    float2 _607 = Select(_606, {1.0000, 1.0000}, {-1.0000, -1.0000});
    float2 _608 = _600 * _607;
    *oct = _608;
  }

  float2 _609 = *oct;
  float2 _610 = _609 * 0.5000;
  float2 _611 = CompositeConstruct({0.5000, 0.5000});
  float2 _612 = _610 + _611;
  float _613 = _612.x;
  float _614 = _612.y;
  float4 _615 = CompositeConstruct({_613, _614, 0.0000, 1.0000});
  return _615;
}

float coverageAlpha(SampledImage<float, 2D>* image@4) {
  float2* param@25;
  uint* param@26;
  uint* _618 = &material.features;
  uint _619 = *_618;
  uint _620 = _619 & 134217728;
  bool _621 = _620 == 0;
  
  if(_621) {
    SampledImage<float, 2D> _624 = *image@4;
    float2 _625 = *textureCoordinate;
    float4 _626 = ImageSampleImplicitLod(_624, _625);
    float _627 = _626.w;
    return _627;
  }

  float2 _630 = *textureCoordinate;
  *param@25 = _630;
  uint* _632 = &material.features;
  uint _633 = *_632;
  *param@26 = _633;
  float _634 = azureSampleCoverageAlpha(image@4, param@25, param@26);
  return _634;
}


