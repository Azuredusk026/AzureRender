from hashlib import file_digest, sha256
from pathlib import Path
import base64
import json
import math
import re
import struct
import subprocess
import sys

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
engine = out.parents[2]
sys.path.insert(0, str(engine / 'tools'))
from native_render.light_lab import generate


mode, configuration, *device_argument = sys.argv[1:]
device = device_argument[0] if device_argument else 'nvidia'
assert device in ('nvidia','intel')
assert mode in ('red', 'green') and configuration in ('Release', 'Debug')
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration == 'Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
parent = out / (mode + '-stencil-control-' + configuration.lower() + '-' + device)
queries = dict(protectedWithRear=16, clearedByFront=22, open=30, clippedProtection=37, maskedProtection=46)
expected = dict(protectedWithRear=.1/5, clearedByFront=.1/4.6, open=.1/4.6,
    clippedProtection=.1/4.6, maskedProtection=.1/5)


def write(path, payload):
    path.write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')


def fixture(folder, policy, visibility):
    generate(folder, 'directional-near')
    data = bytearray()
    views, accessors, primitives, materials = [], [], [], []
    material_indices = {}

    def attribute(values, kind, count, lo=None, hi=None):
        data.extend(bytes((-len(data)) % 4))
        short = kind == 'SCALAR'
        payload = struct.pack('<' + ('H' if short else 'f') * len(values), *values)
        views.append(dict(buffer=0, byteOffset=len(data), byteLength=len(payload)))
        data.extend(payload)
        accessor = dict(bufferView=len(views)-1, componentType=5123 if short else 5126, count=count, type=kind)
        if lo is not None:
            accessor.update(min=lo, max=hi)
        accessors.append(accessor)
        return len(accessors)-1

    def plane(name, bounds, z, normal, role=None, masked=False):
        low, high = bounds
        coords = (low,-1.35,z, high,-1.35,z, high,1.35,z, low,1.35,z)
        position = attribute(coords,'VEC3',4,[low,-1.35,z],[high,1.35,z])
        normal = attribute(normal * 4,'VEC3',4)
        uv = attribute((0,0,1,0,1,1,0,1),'VEC2',4)
        indices = attribute((0,1,2,0,2,3),'SCALAR',6)
        material = dict(name=name, doubleSided=True)
        if role and policy:
            role = 'unknown' if policy == 'invalid' and role == 'respect' else role
            material['extras'] = dict(azureRenderMaterial={'schemaVersion':2, 'class':'generic',
                'referenceDepthStencil':dict(schemaVersion=1, role=role)})
        if masked:
            material.update(alphaMode='MASK',alphaCutoff=.5,pbrMetallicRoughness=dict(baseColorTexture=dict(index=0)))
        material_index = material_indices.setdefault(name, len(materials))
        if material_index == len(materials):
            materials.append(material)
        else:
            assert materials[material_index] == material
        primitives.append(dict(attributes=dict(POSITION=position,NORMAL=normal,TEXCOORD_0=uv),
            indices=indices,material=material_index))

    plane('respect-first',(-1.65,1.65),.4,(0,1,0),'respect')
    plane('protect-opaque',(-1.55,-.45),0,(0,0,1),'protect')
    plane('clear-ordinary',(-1.02,-.68),.2,(1,0,0))
    plane('clear-ordinary',(-1.55,-1.16),-.2,(1,0,0))
    plane('protect-masked',(.15,1.55),0,(0,0,1),'protect',True)
    gltf = dict(asset=dict(version='2.0'), scene=0, scenes=[dict(nodes=[0])], nodes=[dict(mesh=0)],
        buffers=[dict(byteLength=len(data),uri='data:application/octet-stream;base64,'+base64.b64encode(data).decode())],
        bufferViews=views,accessors=accessors,meshes=[dict(primitives=primitives)],materials=materials,
        samplers=[dict(wrapS=33071,wrapT=33071,magFilter=9728,minFilter=9728)],
        textures=[dict(source=0,sampler=0)],images=[dict(uri='coverage.png')])
    write(folder / 'plane.gltf', gltf)
    alpha = Image.new('RGBA',(2,2),(255,255,255,0))
    for row in range(2):
        alpha.putpixel((1,row),(255,255,255,255))
    alpha.save(folder / 'coverage.png')
    level_path = folder / 'level.azurelevel'
    level = json.loads(level_path.read_text())
    camera, = [node['components'] for node in level['nodes'] if node['id'] == 'camera']
    camera['azure.camera']['data'] = dict(enabled=True,priority=1,fieldOfView=55,nearPlane=.1,farPlane=20)
    camera['azure.reference-camera'] = dict(type='azure.reference-camera',version=1,data=dict(enabled=True,
        view='stencil',anchorPosition=[0,0,5],anchorRight=[1,0,0],anchorUp=[0,1,0],anchorBack=[0,0,1]))
    level['renderSettings']['antiAliasing'] = 0
    write(level_path,level)
    scale = 1 / math.tan(math.radians(55)/2)
    view = dict(schemaVersion=1,frame=dict(schemaVersion=1,axes=[1,2,3],offset=[0,0,0]),
        projection=dict(schemaVersion=1,columns=[[scale,0,0,0],[0,-scale,0,0],[0,0,.1,5]],jitter=[0,0]),
        extent=[64,64],depthConvention='reversed',flipNdcY=False,produceSceneDepth=True)
    view['projection']['columns'].insert(2,[0,0,0,-1])
    if visibility:
        view['produceSceneVisibilityInputs']=True
    (folder / 'config').mkdir()
    write(folder / 'config/reference-views.json',dict(schemaVersion=1,views=dict(stencil=view)))


def run(label, policy, visibility=True, fixed=True):
    folder = parent / label
    fixture(folder, policy, visibility)
    frames = folder / 'frames'
    player = build / 'AzurePlayer.exe'
    command = [str(player),'--project',str(folder/'lab.azureproject'),'--width','64','--height','64',
        '--capture-dir',str(frames),'--capture-frames','3','--fixed-frame-step','--qa-camera','scene',
        '--qa-light','scene','--resource-root',str(build)]
    if fixed:
        command.extend(['--disable-bindless','--disable-compute-skinning'])
    write(folder/'command.json',command)
    log_path=folder/'player.log'
    with log_path.open('wb') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=100)
    log=log_path.read_text(errors='replace')
    assert 'Allocator after unload: buffers=0 images=0' in log, log[-7000:]
    if policy=='invalid' or (mode=='red' and policy):
        message = 'unknown field referenceDepthStencil' if mode=='red' else 'referenceDepthStencil'
        assert result.returncode!=0 and message in log, log[-7000:]
        return dict(exitCode=result.returncode, diagnostic=message)
    assert result.returncode==0 and not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I),log[-7000:]
    assert ('Character texture access: fixed,' if fixed else 'Character texture access: indexed,') in log,log[-7000:]
    manifest=json.loads((frames/'capture_manifest.json').read_text())['referenceSceneDepth']
    assert (manifest['width'],manifest['height'],manifest['submission'],manifest['rowOrigin'])==(64,64,3,'bottom-left')
    assert ('packedNormals' in manifest)==visibility
    planes={name:(frames/manifest[name]).read_bytes() for name in ('raster','hardware','packedNormals','objectIds') if name in manifest}
    assert planes['raster']==planes['hardware']
    depth=np.frombuffer(planes['raster'],'<f4').reshape(64,64)
    values={name:float(depth[32,x]) for name,x in queries.items()}
    if visibility:
        packed=np.frombuffer(planes['packedNormals'],'<u4').reshape(64,64)
        normals={name:int(packed[32,x]) for name,x in queries.items()}
    else:
        normals=None
    return dict(depth=values,normals=normals,sha256={name:sha256(value).hexdigest() for name,value in planes.items()})


def near(actual, target):
    return all(abs(actual[key]-value)<1e-7 for key,value in target.items())


baseline=run('default-fixed',None)
assert near(baseline['depth'],dict.fromkeys(queries,.1/4.6)),baseline
selected=run('stencil-fixed','active')
result=dict(configuration=configuration,mode=mode,default=baseline,selected=selected,expected=expected)
if mode=='red':
    assert selected['exitCode']!=0 and not near(baseline['depth'],expected)
else:
    assert near(selected['depth'],expected),selected
    protected=selected['normals']['protectedWithRear']
    assert protected and protected==selected['normals']['maskedProtection'] and protected!=baseline['normals']['open']
    assert all(selected['normals'][name]==baseline['normals'][name] for name in ('clearedByFront','open','clippedProtection'))
    result['indexed']=run('stencil-indexed','active',True,False)
    assert result['indexed']==selected
    result['depthOnly']=run('stencil-depth-only','active',False)
    assert result['depthOnly']['sha256']['raster']==selected['sha256']['raster']
    result['invalid']=run('invalid-role','invalid')
with (build/'AzurePlayer.exe').open('rb') as stream:
    result['playerSha256']=file_digest(stream,'sha256').hexdigest()
write(parent/'summary.json',result)
print(json.dumps(result))