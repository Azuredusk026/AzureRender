from hashlib import sha256
from pathlib import Path
import json
import sys
import zipfile
import zlib

import numpy as np


out = Path(__file__).resolve().parent
source = out.parent/'20261112-105542-native-eyebrow-hair-stencil-8ad501/stencil-replay'
replay = json.loads((source/'report.json').read_text())
request = json.loads((source/'request.json').read_text())
x,y = np.array(request['overlap'],dtype='i4').T
assert len(x)==135


def native(device):
    entry = replay['devices'][device]['attachments']['699']
    data = (source/entry['path']).read_bytes()
    assert sha256(data).hexdigest()==entry['sha256']
    decoded=zlib.decompress(data)
    assert sha256(decoded).hexdigest()==entry['rawCropSha256']
    values=np.frombuffer(decoded,'<u4').reshape(310,290,2)[y-1000,x-1140]
    assert (values[:,1]==52).all()
    return values[:,0].astype('i8')


def histogram(values):
    return {int(delta):int(count) for delta,count in zip(*np.unique(values,return_counts=True))}


native_planes={device:native(device) for device in ('nvidia','intel')}
report=dict(nativeNvidiaMinusIntel=histogram(native_planes['nvidia']-native_planes['intel']),cases={})
for config in sys.argv[1:]:
    assert config in ('release','debug')
    for device in ('nvidia','intel'):
        label=config+'-'+device
        folder=out/(label+'-frames')
        manifest=json.loads((folder/'reference-planes.json').read_text())
        record=manifest['reference-depth-r32.bin']
        with zipfile.ZipFile(folder/'reference-planes.zip') as archive:
            data=archive.read(record['archiveEntry'])
        assert sha256(data).hexdigest()==record['sha256']
        actual=np.frombuffer(data,'<u4').reshape(1440,2560)[y,x].astype('i8')
        report['cases'][label]=dict(points=len(actual),toFrozenNvidia=histogram(actual-native_planes['nvidia']),
            toNativeOnSameAdapter=histogram(actual-native_planes[device]))
for label,row in report['cases'].items():
    expected={-1:9,0:126} if label.endswith('-nvidia') else {-2:2,-1:7,0:126}
    assert row['toNativeOnSameAdapter']==expected,(label,row)
(out/('overlap-depth-'+'-'.join(sys.argv[1:])+'.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))