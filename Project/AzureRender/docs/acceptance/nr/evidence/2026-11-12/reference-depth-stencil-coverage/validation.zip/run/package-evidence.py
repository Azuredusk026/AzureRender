from hashlib import sha256
from pathlib import Path
import json
import sys
import zipfile


out = Path(__file__).resolve().parent
engine = out.parents[2]
target = engine / 'docs/acceptance/nr/evidence/2026-11-12/reference-depth-stencil-coverage'


def load(name):
    return json.loads((out / name).read_text(encoding='utf-8-sig'))


def receipt(label):
    execution = load(label + '-execution.json')
    assert execution['status'] == 'exited' and execution['exitCode'] == 0, execution
    return execution


preflight = sys.argv[1:] == ['--release-only']
configs = ('release',) if preflight else ('release', 'debug')
labels = [f'{config}-{device}' for config in configs for device in ('nvidia','intel')]
fixture = load('fixture-inputs.json')
assert len(fixture['files']) == 45 and fixture['onlyReferenceStencilPolicyChanged']
assert fixture['policies'] == {
    'M_actor_laevat_brow_01': {'schemaVersion':1, 'role':'protect'},
    'M_actor_laevat_iris_01': {'schemaVersion':1, 'role':'protect'},
    'M_actor_laevat_hair_01': {'schemaVersion':1, 'role':'respect'},
}
schema = load('schema-verification.json')
assert schema['schemaSha256'] == sha256((engine / 'schemas/azure_render_material.schema.json').read_bytes()).hexdigest()
assert schema['cases'] == dict(ordinaryVersionOne=True,ordinaryVersionTwo=True,protectVersionTwo=True,respectVersionTwo=True,
    protectVersionOne=False,unknownVersion=False,unknownRole=False,unknownField=False,missingRole=False)
red = load('red-stencil-control-release-nvidia/summary.json')
assert red['selected']['exitCode'] == 1 and red['selected']['diagnostic'] == 'unknown field referenceDepthStencil'
receipt('red-stencil-control-release')
first_failure = load('release-nvidia-capture-first-execution.json')
assert first_failure['status'] == 'exited' and first_failure['exitCode'] == 1
assert 'NameError' in (out/'release-nvidia-capture-first.log').read_text()
limit = load('release-intel-stencil-control-five-materials-execution.json')
assert limit['status'] == 'exited' and limit['exitCode'] == 1
old_intel = out/'green-stencil-control-release-intel-five-materials/stencil-indexed'
assert 'fixed, requested slots=65, stage sampler limit=64' in (old_intel/'player.log').read_text()
controls = {label: load(f'green-stencil-control-{label}/summary.json') for label in labels}
builds = {name: load(name + '-verification.json') for name in (*configs, *(label + '-gpu' for label in labels))}
build_executions = {name: receipt(name) for name in
    tuple(name for config in configs for name in (config + '-build',config + '-cpu-tests'))
    + tuple(name for label in labels for name in (label + '-stencil-control',label + '-gpu-tests',label + '-capture'))}
for name, build in builds.items():
    assert build['shaderCount'] == 895 and not build['changedShaders'] and build['ctestExit'] == 0
    assert build['tests'] == (8 if name == 'release' else 7 if name == 'debug' else 5)
for label, control in controls.items():
    config, _ = label.split('-')
    assert control['selected'] == control['indexed'] and control['invalid']['exitCode'] == 1
    assert control['selected']['sha256']['raster'] == control['depthOnly']['sha256']['raster']
    assert all(abs(control['selected']['depth'][key] - value) < 1e-7 for key,value in control['expected'].items())
    assert control['playerSha256'] == builds[config]['playerSha256']
assert controls['release-nvidia']['default'] == red['default']
captures = {label: load(label + '-results.json') for label in labels}
overlap = load('overlap-depth-' + '-'.join(configs) + '.json')
assert set(overlap['cases']) == set(labels)
for label, capture in captures.items():
    config, device = label.split('-')
    assert capture['playerSha256'] == builds[config]['playerSha256'] == builds[label + '-gpu']['playerSha256']
    assert all(capture[key] for key in ('hairVisibilityExact','hairColorExact','validationClean','allocatorZero'))
    assert capture['nativeOverlap']['points'] == capture['protectedCrop']['changedNormals'] == 135
    assert capture['nativeOverlap']['medianDepthErrorAfter'] == 0
    assert capture['receiver']['closed'] >= 100 and capture['receiver']['introduced'] == 0
    assert capture['receiverByOwner']['296']['closed'] >= 100
    assert capture['protectedCrop']['changedDepthOutside'] == capture['protectedCrop']['changedNormalsOutside'] == 0
    assert capture['firstVisibilityChannelExact']
    expected_hair = (0,0) if device == 'nvidia' else (208,575)
    assert (capture['hairVisibilityOverOne'],capture['hairColorOverOne']) == expected_hair
    manifest = load(label + '-frames/reference-planes.json')
    assert manifest['reference-object-visibility-rg8.bin']['sha256'] == capture['visibilitySha256']
    assert manifest['reference-normals-a2b10g10r10.bin']['sha256'] == capture['normalsSha256']
    assert manifest['reference-depth-r32.bin']['sha256'] == manifest['reference-depth-d32.bin']['sha256'] == capture['referenceDepthSha256']
    assert manifest['reference-object-ids-r8.bin']['sha256'] == capture['objectIdsSha256']
if preflight:
    print(json.dumps({label: dict(receiver=capture['receiver'],eyebrow=capture['receiverByOwner']['296'],
        overlap=capture['nativeOverlap']) for label,capture in captures.items()}))
    sys.exit(0)
for device in ('nvidia','intel'):
    release,debug = [captures[config+'-'+device] for config in configs]
    assert all(release[key] == debug[key] for key in release if key not in ('configuration','playerSha256'))
if sys.argv[1:] == ['--before-original']:
    print(json.dumps({label: row['receiver'] for label, row in captures.items()}))
    sys.exit(0)
original = load('default-four-results.json')
assert all(original[key] for key in ('allExact','depthCaptureAbsent','validationClean','allocatorZero'))
assert original['playerSha256'] == builds['release']['playerSha256']
assert original['projectSha256'] == '13638585d18092a315bd7586a88b349fe256c468eb9090ccb6189232b8209d78'
receipt('original-four')

archive = out / 'validation-pending.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as writer:
    def add(path):
        writer.write(path,'run/'+path.relative_to(out).as_posix())

    for path in sorted(out.iterdir()):
        if path.is_file() and (path.suffix in ('.py','.ps1','.json','.xml','.log','.patch') or path.name == 'implementation-plan.md'):
            add(path)
    for label in labels:
        for name in ('capture_manifest.json','gpu_capabilities.json','reference-planes.json'):
            add(out/(label+'-frames')/name)
    for folder in ('red-stencil-control-release-nvidia',*(f'green-stencil-control-{label}' for label in labels)):
        for path in sorted((out/folder).rglob('*')):
            if path.is_file() and (path.name in ('summary.json','lab.azureproject','level.azurelevel','reference-views.json',
                'plane.gltf','coverage.png','player.log','command.json','capture_manifest.json') or path.name.startswith('reference-depth-')):
                add(path)
    add(old_intel/'player.log')
    add(old_intel/'plane.gltf')
    add(out/'default-four-frames/capture_manifest.json')
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    files = {name: sha256(reader.read(name)).hexdigest() for name in reader.namelist()}
assert archive.stat().st_size <= 8*1024*1024
result = dict(status='qualified-reference-depth-stencil-coverage',overall='failed-user-review',sceneRendererApi=17,
    baseCommit='3896adf96dd8d338f46a0f04449090e64f437e7d',acceptedMaximumByteError=1,
    fixture=fixture,schema=schema,red=red,controls=controls,builds=builds,buildExecution=build_executions,
    captures=captures,overlapDepth=overlap,crossConfigurationExact=True,originalFour=original,
    archive=dict(bytes=archive.stat().st_size,sha256=sha256(archive.read_bytes()).hexdigest(),contents=files))
target.mkdir(parents=True,exist_ok=True)
assert not (target/'validation.zip').exists() and not (target/'results.json').exists()
archive.rename(target/'validation.zip')
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:value for key,value in result['archive'].items() if key!='contents'}))