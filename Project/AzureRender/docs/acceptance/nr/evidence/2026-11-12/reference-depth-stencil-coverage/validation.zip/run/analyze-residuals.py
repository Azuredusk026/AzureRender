from hashlib import sha256
from pathlib import Path
import json
import zipfile
import zlib

import numpy as np


out = Path(__file__).resolve().parent
atlas = out.parent / '20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
replay = out.parent / '20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry'
numeric = out.parent / '20261110-003435-visibility-numeric-contract-4f95e7'


def crop(folder, entry):
    data = (folder / entry['path']).read_bytes()
    assert sha256(data).hexdigest() == entry['sha256'] and len(data) == entry['bytes']
    raw = zlib.decompress(data)
    assert len(raw) == 310 * 290 * 4
    if 'rawSha256' in entry:
        assert sha256(raw).hexdigest() == entry['rawSha256']
    return np.frombuffer(raw, '<u4').reshape(310, 290)


history = json.loads((atlas / 'native-atlas-producers.json').read_text())['receiverNormal']['stages']
native_replay = json.loads((replay / 'native-caster-geometry.json').read_text())
owners = np.zeros((310, 290), dtype='u2')
last = np.zeros((310, 290), dtype='<u4')
for event, row in history.items():
    current = crop(atlas, row['crop'])
    owners[last != current] = int(event)
    last = current
depth = crop(replay, native_replay['receiverDepth']['699']['crop'])
coordinates = np.fromfile(numeric / 'receiver-queries.bin', '<f4').reshape(-1, 4)
x, y = coordinates[:, :2].astype('i4').T
assert np.all((1140 <= x) & (x < 1430) & (1000 <= y) & (y < 1310))
expected = np.fromfile(numeric / 'receiver-expected.bin', '<u4').astype('i4')
assert len(expected) == len(x) == 49384
origin = y - 1000, x - 1140
target_depth, target_normal, target_owner = depth[origin], last[origin], owners[origin]


def read_planes(folder):
    manifest = json.loads((folder / 'reference-planes.json').read_text())
    with zipfile.ZipFile(folder / 'reference-planes.zip') as archive:
        def plane(name, dtype, width):
            entry = manifest[name]
            data = archive.read(entry['archiveEntry'])
            assert sha256(data).hexdigest() == entry['sha256'] and len(data) == entry['size']
            return np.frombuffer(data, dtype).reshape(1440, 2560, width)
        return (plane('reference-depth-r32.bin', '<u4', 1), plane('reference-normals-a2b10g10r10.bin', '<u4', 1),
            plane('reference-object-visibility-rg8.bin', 'u1', 2))


result = {}
for device in ('nvidia', 'intel'):
    label = 'release-' + device
    actual_depth, actual_normal, actual_visibility = read_planes(out / (label + '-frames'))
    depth_ulp = np.abs(actual_depth[y, x, 0].astype('i8') - target_depth.astype('i8'))
    packed = actual_normal[y, x, 0]
    norm_error = np.stack([np.abs(((packed >> shift) & 1023).astype('i4') - ((target_normal >> shift) & 1023).astype('i4'))
        for shift in (0, 10)]).max(axis=0)
    delta = np.abs(actual_visibility[y, x, 1].astype('i4') - expected)
    actual = json.loads((out / (label + '-results.json')).read_text())
    assert int((delta > 1).sum()) == actual['receiver']['overOne']
    by_event = {}
    for event in np.unique(target_owner):
        selected = target_owner == event
        failed = selected & (delta > 1)
        assert int(failed.sum()) == actual['receiverByOwner'][str(event)]['overOne']
        depth_out, normal_out = depth_ulp > 1, norm_error > 1
        by_event[int(event)] = dict(samples=int(selected.sum()), failed=int(failed.sum()),
            inputDepthWithinOneUlp=int((selected & ~depth_out).sum()), inputNormalWithinOne=int((selected & ~normal_out).sum()),
            bothInputsWithinOne=int((failed & ~depth_out & ~normal_out).sum()),
            depthOverOneOnly=int((failed & depth_out & ~normal_out).sum()),
            normalOverOneOnly=int((failed & ~depth_out & normal_out).sum()),
            bothInputsOverOne=int((failed & depth_out & normal_out).sum()),
            normalOver16=int((failed & (norm_error > 16)).sum()), depthOver64Ulp=int((failed & (depth_ulp > 64)).sum()))
    assert sum(row['failed'] for row in by_event.values()) == actual['receiver']['overOne']
    result[device] = by_event
(out / 'receiver-residual-attribution.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
