from pathlib import Path
import json
import os
import sys
import time


out = Path(__file__).resolve().parent
sys.path.insert(0, 'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


predecessor, mode, configuration = sys.argv[1:]
assert mode in ('red', 'green') and configuration in ('Release', 'Debug')
deadline = time.monotonic() + 1200
while time.monotonic() < deadline:
    try:
        state = json.loads((shared.DEFAULT_QUEUE / 'current.json').read_text())
    except (OSError, ValueError):
        time.sleep(1)
        continue
    if state.get('token') != predecessor or state.get('state') == 'released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed reference stencil control window has not opened')

for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES', 'VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key, None)
os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*', VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',
    VK_LAYER_VALIDATE_SYNC='1')
label = mode + '-stencil-control-' + configuration.lower()
with shared.lease(shared.DEFAULT_QUEUE, '01a1c099-8121-7be3-b0b8-7af2f9a06b2a', 'quality-' + label, out) as lease:
    (out / (label + '-lease-held.json')).write_text(json.dumps(lease, indent=2) + '\n')
    command = [sys.executable, '-B', str(out / 'stencil-reference-control.py'), mode, configuration]
    result = shared.maintenance.guarded_run(out.parents[1], out.name, command, 450)
    (out / (label + '-execution.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    assert result['status'] == 'exited' and result['exitCode'] == 0, result

(out / (label + '-lease-released.json')).write_text(json.dumps(lease, indent=2) + '\n')
