from pathlib import Path
import json
import re
import subprocess


out = Path(__file__).resolve().parent
build = out.parent / '20261110-030251-hair-main-chroma-public-9e799c/release'
ninja = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
batch = 'D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'
units = ('src/scenes/CharacterSceneRenderer.cpp','src/assets/GltfLoader.cpp','src/assets/MaterialData.cpp','src/rhi/VulkanRhi.cpp')
result = {}
for path in units:
    target = 'CMakeFiles/AzureRenderCore.dir/' + path + '.obj'
    commands = subprocess.check_output([ninja,'-C',str(build),'-t','commands',target],encoding='utf-8').splitlines()
    command = commands[-1]
    assert 'cl.exe ' in command and ' -c ' in command
    command = re.sub(r' /F[od]\S+| /showIncludes| /FS','',command).replace(' -c ',' /Zs ')
    process = subprocess.run(f'"{batch}" {command}',shell=True,cwd=out,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    log = out / (Path(path).stem + '-typecheck.log')
    log.write_bytes(process.stdout)
    assert process.returncode == 0, process.stdout.decode(errors='replace')
    result[path] = dict(exitCode=process.returncode, log=log.name)
(out/'typecheck.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))