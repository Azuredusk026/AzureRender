$ErrorActionPreference = 'Stop'
$run = Split-Path -Parent $PSCommandPath
$engine = (Get-Item -LiteralPath $run).Parent.Parent.Parent.FullName
$schema = Join-Path $engine 'schemas/azure_render_material.schema.json'
$document = Get-Content -LiteralPath $schema -Raw | ConvertFrom-Json -AsHashtable
$gate = @($document.allOf | Where-Object {
    @($_.if.anyOf | Where-Object { $_.required -contains 'referenceDepthStencil' }).Count -gt 0
})
if ($gate.Count -ne 1) { throw 'Expected exactly one material profile gate for referenceDepthStencil' }
$target = [ordered]@{
    type = $document.type
    additionalProperties = $document.additionalProperties
    required = $document.required
    properties = [ordered]@{
        schemaVersion = $document.properties.schemaVersion
        class = $document.properties.class
        referenceDepthStencil = $document.properties.referenceDepthStencil
    }
    allOf = $gate
}
$bundle = $target | ConvertTo-Json -Depth 100 -Compress
$cases = [ordered]@{
    ordinaryVersionOne = @('{"schemaVersion":1,"class":"generic"}', $true)
    ordinaryVersionTwo = @('{"schemaVersion":2,"class":"fabric"}', $true)
    protectVersionTwo = @('{"schemaVersion":2,"class":"fabric","referenceDepthStencil":{"schemaVersion":1,"role":"protect"}}', $true)
    respectVersionTwo = @('{"schemaVersion":2,"class":"hair","referenceDepthStencil":{"schemaVersion":1,"role":"respect"}}', $true)
    protectVersionOne = @('{"schemaVersion":1,"class":"fabric","referenceDepthStencil":{"schemaVersion":1,"role":"protect"}}', $false)
    unknownVersion = @('{"schemaVersion":2,"class":"fabric","referenceDepthStencil":{"schemaVersion":2,"role":"protect"}}', $false)
    unknownRole = @('{"schemaVersion":2,"class":"fabric","referenceDepthStencil":{"schemaVersion":1,"role":"rgb"}}', $false)
    unknownField = @('{"schemaVersion":2,"class":"fabric","referenceDepthStencil":{"schemaVersion":1,"role":"protect","extra":0}}', $false)
    missingRole = @('{"schemaVersion":2,"class":"fabric","referenceDepthStencil":{"schemaVersion":1}}', $false)
}
$result = [ordered]@{}
foreach ($case in $cases.GetEnumerator()) {
    $issues = @()
    $actual = Test-Json -Json $case.Value[0] -Schema $bundle -ErrorAction SilentlyContinue -ErrorVariable issues
    if ($actual -isnot [bool] -or $actual -ne $case.Value[1]) {
        throw "Material schema case failed: $($case.Key), actual=$actual, expected=$($case.Value[1]), issues=$issues"
    }
    $result[$case.Key] = [bool]$actual
}
$report = [ordered]@{ schemaSha256 = (Get-FileHash -LiteralPath $schema -Algorithm SHA256).Hash.ToLower();
    scope = 'Profile version gate and referenceDepthStencil property'; cases = $result }
$report | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $run 'schema-verification.json') -Encoding utf8
$report | ConvertTo-Json -Depth 4
