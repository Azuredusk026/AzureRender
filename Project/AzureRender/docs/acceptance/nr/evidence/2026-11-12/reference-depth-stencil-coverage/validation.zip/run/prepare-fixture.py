from hashlib import file_digest, sha256
from pathlib import Path
from shutil import copyfile
import json
import struct


out = Path(__file__).resolve().parent
prior = out.parent / '20261112-093321-reference-normal-sampled-rg-ceb2c6'
source = prior / 'hair-project'
project = out / 'hair-project'
asset = Path('character/hair-coverage.glb')


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


fixture = json.loads((prior / 'fixture-inputs.json').read_text())
assert len(fixture['files']) == 45 and fixture['onlyReferenceNormalPolicyChanged']
for item in fixture['files']:
    relative = Path(item['relative'])
    original = (source / relative).resolve(strict=True)
    assert original.is_relative_to(source) and digest(original) == item['sha256']
    destination = project / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    if relative != asset:
        copyfile(original, destination)
        assert digest(destination) == item['sha256']

with (source / asset).open('rb') as stream:
    magic, version, total, size, json_type = struct.unpack('<4s4I', stream.read(20))
    assert (magic, version, total, json_type) == (b'glTF', 2, (source / asset).stat().st_size, 0x4e4f534a)
    old_json = stream.read(size)
    document = json.loads(old_json)
    bin_header = stream.read(8)
    binary = stream.read()
    assert struct.unpack('<2I', bin_header) == (len(binary), 0x004e4942)

policies = {
    'M_actor_laevat_brow_01': {'schemaVersion': 1, 'role': 'protect'},
    'M_actor_laevat_iris_01': {'schemaVersion': 1, 'role': 'protect'},
    'M_actor_laevat_hair_01': {'schemaVersion': 1, 'role': 'respect'},
}
materials = {entry['name']: entry['extras']['azureRenderMaterial'] for entry in document['materials'] if entry['name'] in policies}
assert materials.keys() == policies.keys()
for name, policy in policies.items():
    profile = materials[name]
    assert profile['schemaVersion'] == 2 and 'referenceDepthStencil' not in profile
    profile['referenceDepthStencil'] = policy
encoded = json.dumps(document, separators=(',', ':'), ensure_ascii=False).encode()
encoded += b' ' * ((-len(encoded)) % 4)
file_size = 20 + len(encoded) + len(bin_header) + len(binary)
with (project / asset).open('xb') as destination:
    destination.write(struct.pack('<4s4I', b'glTF', 2, file_size, len(encoded), json_type))
    destination.write(encoded)
    destination.write(bin_header)
    destination.write(binary)
verified = json.loads(encoded)
for entry in verified['materials']:
    if entry['name'] in policies:
        assert entry['extras']['azureRenderMaterial'].pop('referenceDepthStencil') == policies[entry['name']]
assert verified == json.loads(old_json)
files = [dict(relative=path.relative_to(project).as_posix(), bytes=path.stat().st_size, sha256=digest(path))
    for path in sorted(project.rglob('*')) if path.is_file()]
old_hashes = {entry['relative']: entry['sha256'] for entry in fixture['files']}
new_hashes = {entry['relative']: entry['sha256'] for entry in files}
assert old_hashes.keys() == new_hashes.keys()
assert [name for name in old_hashes if new_hashes[name] != old_hashes[name]] == [asset.as_posix()]
result = dict(files=files, binarySha256=sha256(binary).hexdigest(), onlyReferenceStencilPolicyChanged=True, policies=policies,
    sameDdsSha256=fixture['sameDdsSha256'], sameSamplerSha256=fixture['sameSamplerSha256'])
(out / 'fixture-inputs.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(files=len(files), bytes=sum(item['bytes'] for item in files), assetSha256=new_hashes[asset.as_posix()])))
