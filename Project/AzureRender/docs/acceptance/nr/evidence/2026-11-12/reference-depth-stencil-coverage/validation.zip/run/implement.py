from pathlib import Path


root = Path(__file__).resolve().parents[2].parent
assert root == Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender')
modified = {}


def change(relative, old, new):
    path = root / relative
    if path not in modified:
        raw = path.read_bytes()
        newline = '\r\n' if b'\r\n' in raw else '\n'
        modified[path] = (raw.decode('utf-8').replace('\r\n', '\n'), newline)
    text, newline = modified[path]
    assert text.count(old) == 1, (relative, old, text.count(old))
    modified[path] = (text.replace(old, new), newline)


rhi = 'src/rhi/Rhi.hpp'
change(rhi, '''    ShaderSpecialization vertexSpecialization;
    ShaderSpecialization fragmentSpecialization;
};''', '''    ShaderSpecialization vertexSpecialization;
    ShaderSpecialization fragmentSpecialization;
    // A fixed state shared by front and back faces.
    std::optional<VkStencilOpState> stencil;
};''')
change(rhi, '''    bool load = false;
    VkSampleCountFlagBits samples = VK_SAMPLE_COUNT_1_BIT;
};''', '''    bool load = false;
    VkSampleCountFlagBits samples = VK_SAMPLE_COUNT_1_BIT;
    bool clearStencil = false;
};''')
change(rhi, '''        if(attachment.load&&attachment.initialLayout==VK_IMAGE_LAYOUT_UNDEFINED)
            throw std::invalid_argument("Loading an attachment requires defined prior contents");
''', '''        if(attachment.load&&attachment.initialLayout==VK_IMAGE_LAYOUT_UNDEFINED)
            throw std::invalid_argument("Loading an attachment requires defined prior contents");
        if (attachment.clearStencil && (!attachment.isDepth || !attachment.clear
            || (attachment.format != VK_FORMAT_D16_UNORM_S8_UINT
                && attachment.format != VK_FORMAT_D24_UNORM_S8_UINT
                && attachment.format != VK_FORMAT_D32_SFLOAT_S8_UINT)))
            throw std::invalid_argument("Clearing stencil requires a cleared depth-stencil attachment");
''')
backend = 'src/rhi/VulkanRhi.cpp'
change(backend, '''    depthStencil.depthCompareOp = desc.depthCompare;
''', '''    depthStencil.depthCompareOp = desc.depthCompare;
    if (desc.stencil) {
        depthStencil.stencilTestEnable = VK_TRUE;
        depthStencil.front = depthStencil.back = *desc.stencil;
    }
''')
change(backend, '''        attachment.stencilLoadOp = source.isDepth&&source.load?VK_ATTACHMENT_LOAD_OP_LOAD:VK_ATTACHMENT_LOAD_OP_DONT_CARE;
''', '''        attachment.stencilLoadOp = source.clearStencil ? VK_ATTACHMENT_LOAD_OP_CLEAR
            : source.isDepth && source.load ? VK_ATTACHMENT_LOAD_OP_LOAD : VK_ATTACHMENT_LOAD_OP_DONT_CARE;
''')

change('src/assets/GltfLoader.hpp', '''    bool sampledReferenceNormal=false;
''', '''    bool sampledReferenceNormal=false;
    enum class ReferenceDepthStencil { Ordinary, Protect, Respect };
    ReferenceDepthStencil referenceDepthStencil = ReferenceDepthStencil::Ordinary;
''')
gltf = 'src/assets/GltfLoader.cpp'
change(gltf, '''"coverageTexture","blendDepth","referenceNormal"};''', '''"coverageTexture","blendDepth","referenceNormal","referenceDepthStencil"};''')
change(gltf, '''            if(profile.contains("referenceNormal")) {''', '''            if (profile.contains("referenceDepthStencil")) {
                const auto& value = profile.at("referenceDepthStencil");
                if (profile.at("schemaVersion") != 2 || !value.is_object() || value.size() != 2
                    || !value.contains("schemaVersion") || !value.at("schemaVersion").is_number_integer()
                    || value.at("schemaVersion") != 1 || !value.contains("role")
                    || (value.at("role") != "protect" && value.at("role") != "respect"))
                    throw std::invalid_argument(context + ": referenceDepthStencil requires schemaVersion one, protect or respect, and profile version two");
                using Stencil = AssetMaterial::ReferenceDepthStencil;
                result.referenceDepthStencil = value.at("role") == "protect" ? Stencil::Protect : Stencil::Respect;
            }
            if(profile.contains("referenceNormal")) {''')
change(gltf, '''    validateMaterialCoverage(result);
    azurerender::validateMaterialBlendDepth(result);''', '''    validateMaterialCoverage(result);
    if (result.referenceDepthStencil != AssetMaterial::ReferenceDepthStencil::Ordinary
        && (result.alphaMode == AssetAlphaMode::Blend || result.materialClass == AssetMaterialClass::Overlay))
        throw std::invalid_argument(result.name + ": referenceDepthStencil requires a reference depth surface");
    azurerender::validateMaterialBlendDepth(result);''')
change('src/assets/MaterialData.cpp', '''        lost(source.sampledReferenceNormal&&!replacement.sampledReferenceNormal,"referenceNormal");''', '''        lost(source.sampledReferenceNormal&&!replacement.sampledReferenceNormal,"referenceNormal");
        lost(source.referenceDepthStencil != AssetMaterial::ReferenceDepthStencil::Ordinary
            && source.referenceDepthStencil != replacement.referenceDepthStencil, "referenceDepthStencil");''')
schema = 'schemas/azure_render_material.schema.json'
change(schema, '''    "referenceNormal": {
''', '''    "referenceDepthStencil": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "schemaVersion",
        "role"
      ],
      "properties": {
        "schemaVersion": {
          "type": "integer",
          "const": 1
        },
        "role": {
          "enum": ["protect", "respect"]
        }
      }
    },
    "referenceNormal": {
''')
change(schema, '''              "referenceNormal"
            ]
          }
''', '''              "referenceNormal"
            ]
          },
          {
            "required": [
              "referenceDepthStencil"
            ]
          }
''')

target = 'src/render/SceneReferenceDepthTargets.hpp'
change(target, '''    SceneReferenceDepthTargets(rhi::IRhi& backend,VkExtent2D extent,unsigned frames,bool visibilityInputs)
        :backend_(backend),extent_(extent),visibilityInputs_(visibilityInputs) {
''', '''    SceneReferenceDepthTargets(rhi::IRhi& backend, VkExtent2D extent, unsigned frames, bool visibilityInputs, bool stencilEnabled)
        :backend_(backend),extent_(extent),visibilityInputs_(visibilityInputs),stencilEnabled_(stencilEnabled) {
''')
change(target, '''        if(!(backend.imageSampleCounts(VK_FORMAT_R32_SFLOAT,colorUsage)&VK_SAMPLE_COUNT_1_BIT)
            ||!(backend.imageSampleCounts(VK_FORMAT_D32_SFLOAT,depthUsage)&VK_SAMPLE_COUNT_1_BIT))
            throw std::invalid_argument("Scene reference depth requires readable R32 and D32 attachments");
        if(visibilityInputs_){
            constexpr std::uint64_t bytesPerPixel=13;
            if(std::uint64_t(extent.width)*extent.height*frames*bytesPerPixel>256ULL*1024*1024)
                throw std::invalid_argument("Scene reference visibility inputs exceed attachment budget");
''', '''        const auto hardwareFormat = stencilEnabled_ ? VK_FORMAT_D32_SFLOAT_S8_UINT : VK_FORMAT_D32_SFLOAT;
        if (!(backend.imageSampleCounts(VK_FORMAT_R32_SFLOAT, colorUsage) & VK_SAMPLE_COUNT_1_BIT)
            || !(backend.imageSampleCounts(hardwareFormat, depthUsage) & VK_SAMPLE_COUNT_1_BIT))
            throw std::invalid_argument(stencilEnabled_
                ? "Scene reference stencil requires readable R32 and D32S8 attachments"
                : "Scene reference depth requires readable R32 and D32 attachments");
        const std::uint64_t bytesPerPixel = 8 + (stencilEnabled_ ? 4 : 0) + (visibilityInputs_ ? 5 : 0);
        if (std::uint64_t(extent.width) * extent.height * frames * bytesPerPixel > 256ULL * 1024 * 1024)
            throw std::invalid_argument("Scene reference attachments exceed the memory budget");
        if(visibilityInputs_){
''')
change(target, '''                {VK_FORMAT_D32_SFLOAT,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL,true,true,true}};
            desc.depthAttachment=1;
''', '''                {hardwareFormat,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL,true,true,true}};
            desc.depthAttachment=1;
            desc.attachments[1].clearStencil = stencilEnabled_;
''')
change(target, '''                slot.hardware=backend.allocator().createImage2D(extent.width,extent.height,VK_FORMAT_D32_SFLOAT,depthUsage);
                slot.rasterView=backend.createImageView(slot.raster.image,VK_FORMAT_R32_SFLOAT,VK_IMAGE_ASPECT_COLOR_BIT,1);
                slot.hardwareView=backend.createImageView(slot.hardware.image,VK_FORMAT_D32_SFLOAT,VK_IMAGE_ASPECT_DEPTH_BIT,1);''', '''                slot.hardware=backend.allocator().createImage2D(extent.width,extent.height,hardwareFormat,depthUsage);
                slot.rasterView=backend.createImageView(slot.raster.image,VK_FORMAT_R32_SFLOAT,VK_IMAGE_ASPECT_COLOR_BIT,1);
                slot.hardwareView=backend.createImageView(slot.hardware.image,hardwareFormat,hardwareAspects(),1);''')
change(target, '''    bool visibilityInputs() const noexcept{return visibilityInputs_;}
''', '''    bool visibilityInputs() const noexcept{return visibilityInputs_;}
    bool stencilEnabled() const noexcept { return stencilEnabled_; }
    VkImageAspectFlags hardwareAspects() const noexcept {
        return stencilEnabled_ ? VK_IMAGE_ASPECT_DEPTH_BIT | VK_IMAGE_ASPECT_STENCIL_BIT : VK_IMAGE_ASPECT_DEPTH_BIT;
    }
''')
change(target, '''                barrier.aspectMask=depth?VK_IMAGE_ASPECT_DEPTH_BIT:VK_IMAGE_ASPECT_COLOR_BIT;
''', '''                barrier.aspectMask=depth?hardwareAspects():VK_IMAGE_ASPECT_COLOR_BIT;
''')
change(target, '''    bool visibilityInputs_=false;
    VkRenderPass pass_{};
''', '''    bool visibilityInputs_=false;
    bool stencilEnabled_=false;
    VkRenderPass pass_{};
''')

renderer = 'src/scenes/CharacterSceneRenderer.cpp'
change(renderer, '''        hardware.aspectMask=VK_IMAGE_ASPECT_DEPTH_BIT;
        const auto rasterResource=graph.importImage("character-reference-r32",raster);''', '''        hardware.aspectMask=referenceSceneDepth_->hardwareAspects();
        const auto rasterResource=graph.importImage("character-reference-r32",raster);''')
change(renderer, '''    if(referenceDepthRequested(context))
        referenceSceneDepth_=std::make_unique<SceneReferenceDepthTargets>(*rhi_,context.renderExtent,
            static_cast<unsigned>(kMaxFramesInFlight),referenceVisibilityRequested(context));
''', '''    if (referenceDepthRequested(context)) {
        const auto usesStencil = [](const LoadedAsset& asset) {
            return std::any_of(asset.primitives.begin(), asset.primitives.end(), [&](const AssetPrimitive& primitive) {
                return primitive.indexCount && asset.materials[primitive.materialIndex].referenceDepthStencil
                    != AssetMaterial::ReferenceDepthStencil::Ordinary;
            });
        };
        const bool stencilEnabled = usesStencil(asset_) || std::any_of(additionalResources_.begin(), additionalResources_.end(),
            [&](const auto& resource) { return usesStencil(resource->asset); });
        referenceSceneDepth_=std::make_unique<SceneReferenceDepthTargets>(*rhi_,context.renderExtent,
            static_cast<unsigned>(kMaxFramesInFlight),referenceVisibilityRequested(context),stencilEnabled);
    }
''')
change(renderer, '''    for(auto* pipelines:{&referenceSceneDepthPipelines_,&referenceSceneVisibilityPipelines_})
        for(auto& pipeline:*pipelines){
            if(pipeline)rhi_->destroyPipeline(pipeline);
            pipeline=VK_NULL_HANDLE;
        }
    for(auto& pipeline:referenceSceneOutlineDepthPipelines_){
        if(pipeline)rhi_->destroyPipeline(pipeline);
        pipeline=VK_NULL_HANDLE;
    }
''', '''    const auto releasePipelines = [&](auto& groups) {
        for (auto& group : groups) {
            for (auto& pipeline : group) {
                if (pipeline) rhi_->destroyPipeline(pipeline);
                pipeline = VK_NULL_HANDLE;
            }
        }
    };
    releasePipelines(referenceSceneDepthPipelines_);
    releasePipelines(referenceSceneVisibilityPipelines_);
    releasePipelines(referenceSceneOutlineDepthPipelines_);
''')
change(renderer, '''    const auto& spans=referenceDepth?referenceSpans:snapshot.visibleSpans;
    for(std::size_t spanIndex=0;spanIndex<spans.size();++spanIndex){
''', '''    const auto& spans=referenceDepth?referenceSpans:snapshot.visibleSpans;
    const bool stencilEnabled = referenceDepth && referenceSceneDepth_->stencilEnabled();
    const auto recordSpan = [&](std::size_t spanIndex, bool respectStencil) {
''')
change(renderer, '''            const auto& m=mesh.materials[primitive.materialIndex];if(m.alphaMode==AssetAlphaMode::Blend||m.materialClass==AssetMaterialClass::Overlay)continue;
            if(referenceDepth&&m.alphaMode==AssetAlphaMode::Mask''', '''            const auto& m=mesh.materials[primitive.materialIndex];if(m.alphaMode==AssetAlphaMode::Blend||m.materialClass==AssetMaterialClass::Overlay)continue;
            if (stencilEnabled && (m.referenceDepthStencil == AssetMaterial::ReferenceDepthStencil::Respect) != respectStencil)
                continue;
            if(referenceDepth&&m.alphaMode==AssetAlphaMode::Mask''')
change(renderer, '''                const auto& pipelines=visibilityInputs?referenceSceneVisibilityPipelines_:referenceSceneDepthPipelines_;
                commands.bindPipeline(pipelines[m.doubleSided?2:mirrored?1:0]);
''', '''                const auto& pipelines=visibilityInputs?referenceSceneVisibilityPipelines_:referenceSceneDepthPipelines_;
                const auto stencilRole = stencilEnabled ? static_cast<std::size_t>(m.referenceDepthStencil) : 0;
                commands.bindPipeline(pipelines[stencilRole][m.doubleSided?2:mirrored?1:0]);
''')
change(renderer, '''        if(colorRequired)recordOutlineShells(context,snapshot,commands,spans,OutlineShellPass::SnapshotDepth,counters,spanIndex);
    }
    if(referenceDepth)recordOutlineShells(context,snapshot,commands,spans,OutlineShellPass::ReferenceDepth);
''', '''        if(colorRequired)recordOutlineShells(context,snapshot,commands,spans,OutlineShellPass::SnapshotDepth,counters,spanIndex);
    };
    for (std::size_t spanIndex = 0; spanIndex < spans.size(); ++spanIndex)
        recordSpan(spanIndex, false);
    // Resolve the nearest ordinary or protected surface before any respecting draw.
    if (stencilEnabled)
        for (std::size_t spanIndex = 0; spanIndex < spans.size(); ++spanIndex)
            recordSpan(spanIndex, true);
    if(referenceDepth)recordOutlineShells(context,snapshot,commands,spans,OutlineShellPass::ReferenceDepth);
''')

change('src/scenes/CharacterSceneRenderer.hpp', '''    std::array<VkPipeline,3> referenceSceneDepthPipelines_{};
    std::array<VkPipeline,2> referenceSceneOutlineDepthPipelines_{};
    std::array<VkPipeline,3> referenceSceneVisibilityPipelines_{};
''', '''    std::array<std::array<VkPipeline, 3>, 3> referenceSceneDepthPipelines_{};
    std::array<std::array<VkPipeline, 2>, 2> referenceSceneOutlineDepthPipelines_{};
    std::array<std::array<VkPipeline, 3>, 3> referenceSceneVisibilityPipelines_{};
''')

ref = 'src/scenes/CharacterReferenceSceneDepth.inc'
change(ref, '''namespace {
bool referenceDepthRequested''', '''namespace {
using ReferenceDepthStencil = AssetMaterial::ReferenceDepthStencil;

VkStencilOpState referenceDepthStencilState(ReferenceDepthStencil role) {
    constexpr std::uint32_t protection = 1;
    const bool respect = role == ReferenceDepthStencil::Respect;
    VkStencilOpState state{};
    state.failOp = VK_STENCIL_OP_KEEP;
    state.depthFailOp = VK_STENCIL_OP_KEEP;
    state.passOp = respect ? VK_STENCIL_OP_KEEP : VK_STENCIL_OP_REPLACE;
    state.compareOp = respect ? VK_COMPARE_OP_EQUAL : VK_COMPARE_OP_ALWAYS;
    state.compareMask = protection;
    state.writeMask = respect ? 0 : protection;
    state.reference = role == ReferenceDepthStencil::Protect ? protection : 0;
    return state;
}

bool referenceDepthRequested''')
change(ref, '''        for(unsigned facing=0;facing<pipelines.size();++facing){
            // The reference attachment stores rows in the opposite order to the scene view.
            desc.frontFace=facing==1?VK_FRONT_FACE_COUNTER_CLOCKWISE:VK_FRONT_FACE_CLOCKWISE;
            desc.cullMode=context.faceCullingEnabled&&facing!=2?VK_CULL_MODE_BACK_BIT:VK_CULL_MODE_NONE;
            pipelines[facing]=rhi_->createGraphicsPipeline(desc);
        }
''', '''        const bool stencilEnabled = referenceSceneDepth_->stencilEnabled();
        const auto roles = stencilEnabled ? pipelines.size() : 1;
        for (std::size_t role = 0; role < roles; ++role) {
            if (stencilEnabled)
                desc.stencil = referenceDepthStencilState(static_cast<ReferenceDepthStencil>(role));
            auto& orientations = pipelines[role];
            for (unsigned facing = 0; facing < orientations.size(); ++facing) {
                // The reference attachment stores rows in the opposite order to the scene view.
                desc.frontFace=facing==1?VK_FRONT_FACE_COUNTER_CLOCKWISE:VK_FRONT_FACE_CLOCKWISE;
                desc.cullMode=context.faceCullingEnabled&&facing!=2?VK_CULL_MODE_BACK_BIT:VK_CULL_MODE_NONE;
                orientations[facing]=rhi_->createGraphicsPipeline(desc);
            }
        }
''')
change(ref, '''        for(unsigned facing=0;facing<referenceSceneOutlineDepthPipelines_.size();++facing){
            desc.frontFace=facing?VK_FRONT_FACE_COUNTER_CLOCKWISE:VK_FRONT_FACE_CLOCKWISE;
            referenceSceneOutlineDepthPipelines_[facing]=rhi_->createGraphicsPipeline(desc);
        }
''', '''        const auto roles = referenceSceneDepth_->stencilEnabled() ? referenceSceneOutlineDepthPipelines_.size() : 1;
        for (std::size_t role = 0; role < roles; ++role) {
            if (role == 1) desc.stencil = referenceDepthStencilState(ReferenceDepthStencil::Respect);
            auto& orientations = referenceSceneOutlineDepthPipelines_[role];
            for (unsigned facing = 0; facing < orientations.size(); ++facing) {
                desc.frontFace=facing?VK_FRONT_FACE_COUNTER_CLOCKWISE:VK_FRONT_FACE_CLOCKWISE;
                orientations[facing]=rhi_->createGraphicsPipeline(desc);
            }
        }
''')
change('src/scenes/CharacterOutlinePass.inc', '''            if(referenceDepth)commands.bindPipeline(referenceSceneOutlineDepthPipelines_[mirrored?1:0]);
            else commands.bindPipeline''', '''            if (referenceDepth) {
                const bool respectStencil = referenceSceneDepth_->stencilEnabled()
                    && material.referenceDepthStencil == AssetMaterial::ReferenceDepthStencil::Respect;
                commands.bindPipeline(referenceSceneOutlineDepthPipelines_[respectStencil ? 1 : 0][mirrored ? 1 : 0]);
            } else commands.bindPipeline''')

for path, (text, newline) in modified.items():
    path.write_bytes(text.replace('\n', newline).encode('utf-8'))
print('\n'.join(path.relative_to(root).as_posix() for path in modified))