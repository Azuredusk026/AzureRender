from hashlib import file_digest
from pathlib import Path
import base64
import json
import math
import re
import struct
import subprocess
import sys

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
engine = out.parents[2]
sys.path.insert(0, str(engine / 'tools'))
from native_render.light_lab import generate


mode, configuration = sys.argv[1:]
assert mode in ('red', 'green') and configuration in ('Release', 'Debug')
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration == 'Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
parent = out / (mode + '-normal-control-' + configuration.lower())
pixel = (192, 160, 20, 255)


def write(path, payload):
    path.write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')


def fixture(folder, requested):
    generate(folder, 'directional-near')
    positions = (-1.5, -1.5, 0, 1.5, -1.5, 0, 1.5, 1.5, 0, -1.5, 1.5, 0)
    normals = (0, 0, 1) * 4
    tangents = (1, 0, 0, 1) * 4
    uv = (0, 0, 1, 0, 1, 1, 0, 1)
    data = struct.pack('<12f12f16f8f6H', *positions, *normals, *tangents, *uv, 0, 1, 2, 0, 2, 3)
    profiles = dict(schemaVersion=2, **{'class': 'generic'})
    if requested:
        profiles['referenceNormal'] = dict(schemaVersion=2 if requested == 'invalid' else 1, encoding='sampled-rg')
    model = dict(asset=dict(version='2.0'), scene=0, scenes=[dict(nodes=[0])], nodes=[dict(mesh=0)],
        buffers=[dict(byteLength=len(data), uri='data:application/octet-stream;base64,' + base64.b64encode(data).decode())],
        bufferViews=[dict(buffer=0, byteOffset=o, byteLength=n) for o, n in ((0, 48), (48, 48), (96, 64), (160, 32), (192, 12))],
        accessors=[dict(bufferView=i, componentType=5126 if i < 4 else 5123, count=4 if i < 4 else 6, type=kind,
            **(dict(min=[-1.5, -1.5, 0], max=[1.5, 1.5, 0]) if i == 0 else {}))
            for i, kind in enumerate(('VEC3', 'VEC3', 'VEC4', 'VEC2', 'SCALAR'))],
        meshes=[dict(primitives=[dict(attributes=dict(POSITION=0, NORMAL=1, TANGENT=2, TEXCOORD_0=3), indices=4, material=0)])],
        materials=[dict(name='reference-normal-control', normalTexture=dict(index=0), doubleSided=True,
            extras=dict(azureRenderMaterial=profiles))],
        samplers=[dict(wrapS=33071, wrapT=33071, magFilter=9728, minFilter=9728)],
        textures=[dict(source=0, sampler=0)], images=[dict(uri='normal.png')])
    write(folder / 'plane.gltf', model)
    Image.new('RGBA', (2, 2), pixel).save(folder / 'normal.png')
    level_path = folder / 'level.azurelevel'
    level = json.loads(level_path.read_text())
    camera, = [node['components'] for node in level['nodes'] if node['id'] == 'camera']
    camera['azure.camera']['data'] = dict(enabled=True, priority=1, fieldOfView=55, nearPlane=.1, farPlane=20)
    camera['azure.reference-camera'] = dict(type='azure.reference-camera', version=1, data=dict(enabled=True,
        view='normal', anchorPosition=[0, 0, 5], anchorRight=[1, 0, 0], anchorUp=[0, 1, 0], anchorBack=[0, 0, 1]))
    write(level_path, level)
    scale = 1 / math.tan(math.radians(55) / 2)
    view = dict(schemaVersion=1, frame=dict(schemaVersion=1, axes=[1, 2, 3], offset=[0, 0, 0]),
        projection=dict(schemaVersion=1, columns=[[scale, 0, 0, 0], [0, -scale, 0, 0], [0, 0, 0, -1],
            [0, 0, .1, 5]], jitter=[0, 0]), extent=[64, 64], depthConvention='reversed', flipNdcY=False,
        produceSceneDepth=True, produceSceneVisibilityInputs=True)
    (folder / 'config').mkdir()
    write(folder / 'config/reference-views.json', dict(schemaVersion=1, views=dict(normal=view)))


def run(label, requested, fixed):
    folder = parent / label
    fixture(folder, requested)
    frames = folder / 'frames'
    player = build / 'AzurePlayer.exe'
    command = [str(player), '--project', str(folder / 'lab.azureproject'), '--width', '64', '--height', '64',
        '--capture-dir', str(frames), '--capture-frames', '3', '--fixed-frame-step', '--qa-camera', 'scene',
        '--qa-light', 'scene', '--resource-root', str(build)]
    if fixed:
        command.extend(['--disable-bindless', '--disable-compute-skinning'])
    write(folder / 'command.json', command)
    log_path = folder / 'player.log'
    with log_path.open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=120)
    log = log_path.read_text(errors='replace')
    assert 'Allocator after unload: buffers=0 images=0' in log, log[-7000:]
    if mode == 'red' and requested == 'sampled-rg':
        assert result.returncode != 0 and 'unknown field referenceNormal' in log, log[-7000:]
        return {'exitCode': result.returncode, 'diagnostic': 'unknown field referenceNormal'}
    if requested == 'invalid':
        assert result.returncode != 0 and 'referenceNormal' in log, log[-7000:]
        return {'exitCode': result.returncode}
    assert result.returncode == 0 and not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]', log, re.I), log[-7000:]
    assert ('Character texture access: fixed,' if fixed else 'Character texture access: indexed,') in log, log[-7000:]
    report = json.loads((frames / 'capture_manifest.json').read_text())['referenceSceneDepth']
    assert (report['width'], report['height'], report['submission'], report['rowOrigin']) == (64, 64, 3, 'bottom-left')
    normal = np.fromfile(frames / report['packedNormals'], '<u4').reshape(64, 64)[28:36, 28:36]
    depth = np.fromfile(frames / report['raster'], '<f4').reshape(64, 64)[28:36, 28:36]
    assert np.all(depth > 0) and np.unique(normal).size == 1
    word = int(normal[0, 0])
    return {'code': [word & 1023, (word >> 10) & 1023], 'word': word}


def oct_encode(vector):
    x, y, z = vector
    total = abs(x) + abs(y) + abs(z)
    a, b = x / total, z / total
    if y < 0:
        a, b = (1 - abs(b)) * (1 if a >= 0 else -1), (1 - abs(a)) * (1 if b >= 0 else -1)
    return [round((a * .5 + .5) * 1023), round((b * .5 + .5) * 1023)]


def distance(a, b):
    return max(abs(x - y) for x, y in zip(a, b))


rgb = run('default-fixed', None, True)
selected = run('sampled-fixed', 'sampled-rg', True)
x, y, b = (channel / 255 * 2 - 1 for channel in pixel[:3])
z = math.sqrt(max(0, 1 - x * x - y * y))
rgb_candidates = {1: oct_encode((x, y, b)), -1: oct_encode((x, -y, -b))}
facing, = [sign for sign, candidate in rgb_candidates.items() if distance(rgb['code'], candidate) <= 1]
expected = oct_encode((facing * x, facing * y, facing * z))
result = dict(configuration=configuration, mode=mode, default=rgb, selected=selected, facing=facing,
    expectedRgb=rgb_candidates[facing], expectedSampledRg=expected)
if mode == 'red':
    assert selected['exitCode'] != 0 and distance(rgb['code'], expected) > 1, result
else:
    result['error'] = distance(selected['code'], expected)
    assert result['error'] <= 1, result
    result['indexed'] = run('sampled-indexed', 'sampled-rg', False)
    assert result['indexed'] == selected, result
    result['invalid'] = run('invalid-profile', 'invalid', True)
with (build / 'AzurePlayer.exe').open('rb') as stream:
    result['playerSha256'] = file_digest(stream, 'sha256').hexdigest()
write(parent / 'summary.json', result)
print(json.dumps(result))
