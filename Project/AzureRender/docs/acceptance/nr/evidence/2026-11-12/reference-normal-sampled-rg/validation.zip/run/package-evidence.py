from hashlib import sha256
from pathlib import Path
import json
import sys
import zipfile


out = Path(__file__).resolve().parent
engine = out.parents[2]
target = engine / 'docs/acceptance/nr/evidence/2026-11-12/reference-normal-sampled-rg'
outline_path = engine / 'docs/acceptance/nr/evidence/2026-11-12/reference-scene-outline-depth/results.json'


def read(name):
    return json.loads((out / name).read_text(encoding='utf-8-sig'))


def receipt(label):
    execution = read(label + '-execution.json')
    assert execution['status'] == 'exited' and execution['exitCode'] == 0, execution
    return execution


preflight = sys.argv[1:] == ['--release-only']
configs = ('release',) if preflight else ('release', 'debug')
labels = [f'{config}-{device}' for config in configs for device in ('nvidia', 'intel')]
outline = json.loads(outline_path.read_text())
fixture = read('fixture-inputs.json')
assert len(fixture['files']) == 45 and fixture['onlyReferenceNormalPolicyChanged']
assert fixture['policy'] == dict(schemaVersion=1, encoding='sampled-rg')
assert fixture['sameDdsSha256'] == '34bbb19e3e85d2477a2c657e6956514b62866424982584b5c92df8d90bbbcf26'
schema = read('schema-verification.json')
assert schema['schemaSha256'] == sha256((engine / 'schemas/azure_render_material.schema.json').read_bytes()).hexdigest()
assert schema['cases'] == dict(ordinaryVersionOne=True, ordinaryVersionTwo=True, sampledVersionTwo=True, sampledVersionOne=False,
    unknownVersion=False, unknownEncoding=False, unknownField=False, missingEncoding=False)
red = read('red-normal-control-summary.json')
assert red['defaultCode'] == [673, 243] and red['playerRejectedSampledRg'] and red['allocatorZero']
assert red['execution']['status'] == 'exited' and red['execution']['exitCode'] == 1
controls = {config: read(f'green-normal-control-{config}/summary.json') for config in configs}
builds = {name: read(name + '-verification.json') for name in (*configs, *(label + '-gpu' for label in labels))}
build_executions = {name: receipt(name) for name in
    tuple(name for config in configs for name in (config + '-build', config + '-cpu-tests', 'green-normal-control-' + config))
    + tuple(name for label in labels for name in (label + '-gpu-tests', label + '-capture'))}
for name, build in builds.items():
    assert build['shaderCount'] == 895 and build['ctestExit'] == 0
    assert set(build['changedShaders']) == {'reference_scene_visibility.frag.spv', 'reference_scene_visibility_bindless.frag.spv'}
    assert build['tests'] == (8 if name == 'release' else 7 if name == 'debug' else 5)
for config, control in controls.items():
    assert control['error'] == 0 and control['selected'] == control['indexed'] and control['selected']['code'] == [675, 777]
    assert control['default']['code'] == [673, 243] and control['invalid']['exitCode'] != 0
    assert control['playerSha256'] == builds[config]['playerSha256']
rows = {label: read(label + '-results.json') for label in labels}
residuals = read('receiver-residual-attribution.json')
assert (residuals['nvidia']['377']['failed'], residuals['intel']['377']['failed']) == (158, 224)
for label, row in rows.items():
    config, device = label.split('-')
    assert row['playerSha256'] == builds[config]['playerSha256'] == builds[label + '-gpu']['playerSha256']
    assert all(row[field] for field in ('depthExact', 'idsExact', 'hairVisibilityExact', 'hairColorExact',
        'validationClean', 'allocatorZero'))
    expected = (158, 520, 0, 0, 13919) if device == 'nvidia' else (224, 851, 208, 575, 12766)
    assert (row['receiverByOwner']['377']['overOne'], row['receiver']['overOne'], row['hairVisibilityOverOne'],
        row['hairColorOverOne'], row['clothNormal']['current']['withinOne']) == expected
    assert all(value['changed'] == 0 for key, value in row['receiverByOwner'].items() if key != '377')
    manifest = read(label + '-frames/reference-planes.json')
    assert manifest['reference-object-visibility-rg8.bin']['sha256'] == row['visibilitySha256']
    assert manifest['reference-normals-a2b10g10r10.bin']['sha256'] == row['normalsSha256']
    assert manifest['reference-depth-r32.bin']['sha256'] == outline['captures'][label]['referenceDepthSha256']
    assert manifest['reference-depth-d32.bin']['sha256'] == outline['captures'][label]['referenceDepthSha256']
    assert manifest['reference-object-ids-r8.bin']['sha256'] == outline['captures'][label]['objectIdsSha256']
if preflight:
    print(json.dumps({label: row['receiverByOwner']['377'] for label, row in rows.items()}))
    sys.exit(0)
assert builds['release']['changedShaders'] == builds['debug']['changedShaders']
for device in ('nvidia', 'intel'):
    release, debug = [rows[config + '-' + device] for config in configs]
    assert all(release[key] == debug[key] for key in release if key not in ('configuration', 'playerSha256'))
original = read('default-four-results.json')
assert original['allExact'] and original['depthCaptureAbsent'] and original['validationClean'] and original['allocatorZero']
assert original['playerSha256'] == builds['release']['playerSha256']
assert original['projectSha256'] == outline['originalFour']['projectSha256']
receipt('original-four')

archive = out / 'validation-pending.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as writer:
    def add(path):
        writer.write(path, 'run/' + path.relative_to(out).as_posix())

    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.ps1', '.json', '.xml', '.log'):
            add(path)
    for label in labels:
        for name in ('capture_manifest.json', 'gpu_capabilities.json', 'reference-planes.json'):
            add(out / (label + '-frames') / name)
    for mode in ('red-normal-control-release', *(f'green-normal-control-{config}' for config in configs)):
        for path in sorted((out / mode).rglob('*')):
            if path.is_file() and path.name in ('summary.json', 'lab.azureproject', 'level.azurelevel', 'reference-views.json',
                'plane.gltf', 'normal.png', 'player.log', 'command.json', 'capture_manifest.json', 'reference-normals-a2b10g10r10.bin'):
                add(path)
    add(out / 'default-four-frames/capture_manifest.json')
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    files = {name: sha256(reader.read(name)).hexdigest() for name in reader.namelist()}
assert archive.stat().st_size <= 8 * 1024 * 1024
result = dict(status='qualified-reference-normal-sampled-rg', overall='failed-user-review',
    baseCommit='98e6c2c36a8af452cabe54639bd7f1f7c937dbac', acceptedMaximumByteError=1,
    fixture=fixture, schema=schema, red=red, controls=controls, builds=builds, buildExecution=build_executions,
    captures=rows, residualAttribution=residuals, crossConfigurationExact=True, originalFour=original,
    archive=dict(bytes=archive.stat().st_size, sha256=sha256(archive.read_bytes()).hexdigest(), contents=files))
target.mkdir(parents=True, exist_ok=True)
assert not (target / 'validation.zip').exists() and not (target / 'results.json').exists()
archive.rename(target / 'validation.zip')
(target / 'results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in result['archive'].items() if key != 'contents'}))
