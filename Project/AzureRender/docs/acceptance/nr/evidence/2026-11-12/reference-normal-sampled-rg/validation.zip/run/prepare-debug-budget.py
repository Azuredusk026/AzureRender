from hashlib import file_digest
from pathlib import Path
import json
import subprocess
import sys


out = Path(__file__).resolve().parent
engine = out.parents[2]
build = (out.parent / '20261110-031856-hair-main-chroma-debug-668bf2/debug').resolve(strict=True)
assert build.parent.parent == out.parent and not build.is_symlink()
queue = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_text())
assert queue['state'] == 'held' and queue['owner'] == '01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0, str(engine / 'tools'))
from artifact_maintenance import measure


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


baseline = out.parent / '20261112-073905-reference-scene-outline-depth-d97cff/debug-verification.json'
assert digest(build / 'AzurePlayer.exe') == json.loads(baseline.read_text())['playerSha256']
ninja = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
targets = ['AzurePlayer', 'AzureReferenceCameraViewTests', 'AzureProjectReferenceViewsTests', 'AzureRenderExtensionRegistryTests',
    'AzureReferenceCameraBindingTests', 'AzureScreenObjectVisibilityTests', 'AzureScreenObjectVisibilityGpuTests',
    'AzureReferenceDepthGpuTests', 'AzureReferenceDepthCoverageGpuTests', 'AzureSurfaceResponseGpuTests', 'AzureMaterialCoverageTests',
    'AzureMaterialDocumentTests']
command = [ninja, '-C', str(build), '-n', *targets]
plan = subprocess.check_output(command, text=True)
assert 'Linking CXX executable AzurePlayer.exe' in plan
before = measure(build.parent)
names = ('AzureRenderCore.lib', 'AzureRuntime.lib', 'AzurePlayerHost.lib')
files = []
for name in names:
    path = build / name
    assert 'Linking CXX static library ' + name in plan
    assert path.is_file() and not path.is_symlink() and path.resolve(strict=True).parent == build and path.stat().st_nlink == 1
    assert subprocess.run(['git', '-C', str(engine), 'check-ignore', '-q', str(path)]).returncode == 0
    files.append(dict(name=name, bytes=path.stat().st_size, sha256=digest(path)))
for name in names:
    (build / name).unlink()
after = measure(build.parent)
assert before - after == sum(item['bytes'] for item in files)
assert subprocess.check_output(command, text=True) == plan
(out / 'debug-budget-preparation.json').write_text(json.dumps(dict(before=before, after=after, files=files, dryRun=plan), indent=2) + '\n')
print(f'Debug generated outputs {before} -> {after} bytes')
