from hashlib import file_digest, sha256
from pathlib import Path
from shutil import copyfile
import json
import struct


out = Path(__file__).resolve().parent
prior = out.parent / '20261112-091515-cloth-receiver-normal-y-29da47'
source = prior / 'hair-project'
project = out / 'hair-project'
asset = Path('character/hair-coverage.glb')


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


fixture = json.loads((prior / 'fixture-inputs.json').read_text())
assert len(fixture['files']) == 45 and fixture['allOtherInputsExact']
for item in fixture['files']:
    relative = Path(item['relative'])
    original = (source / relative).resolve(strict=True)
    assert original.is_relative_to(source) and digest(original) == item['sha256']
    destination = project / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    if relative != asset:
        copyfile(original, destination)
        assert digest(destination) == item['sha256']

with (source / asset).open('rb') as stream:
    magic, version, total, size, json_type = struct.unpack('<4s4I', stream.read(20))
    assert (magic, version, total, json_type) == (b'glTF', 2, (source / asset).stat().st_size, 0x4e4f534a)
    old_json = stream.read(size)
    document = json.loads(old_json)
    bin_header = stream.read(8)
    binary = stream.read()
    assert struct.unpack('<2I', bin_header) == (len(binary), 0x004e4942)

cloth, = [entry for entry in document['materials'] if entry['name'] == 'M_actor_laevat_cloth_01']
profile = cloth['extras']['azureRenderMaterial']
assert profile['schemaVersion'] == 2 and profile['class'] == 'fabric' and 'referenceNormal' not in profile
assert document['images'][document['textures'][cloth['normalTexture']['index']]['source']]['uri'] == 'cloth-receiver-normal-authored.dds'
policy = dict(schemaVersion=1, encoding='sampled-rg')
profile['referenceNormal'] = policy
encoded = json.dumps(document, separators=(',', ':'), ensure_ascii=False).encode()
encoded += b' ' * ((-len(encoded)) % 4)
file_size = 20 + len(encoded) + len(bin_header) + len(binary)
with (project / asset).open('xb') as destination:
    destination.write(struct.pack('<4s4I', b'glTF', 2, file_size, len(encoded), json_type))
    destination.write(encoded)
    destination.write(bin_header)
    destination.write(binary)
verified = json.loads(encoded)
verified_cloth, = [entry for entry in verified['materials'] if entry['name'] == cloth['name']]
assert verified_cloth['extras']['azureRenderMaterial'].pop('referenceNormal') == policy
assert verified == json.loads(old_json)
files = [dict(relative=path.relative_to(project).as_posix(), bytes=path.stat().st_size, sha256=digest(path))
    for path in sorted(project.rglob('*')) if path.is_file()]
old_hashes = {entry['relative']: entry['sha256'] for entry in fixture['files']}
new_hashes = {entry['relative']: entry['sha256'] for entry in files}
assert old_hashes.keys() == new_hashes.keys()
assert [name for name in old_hashes if new_hashes[name] != old_hashes[name]] == [asset.as_posix()]
result = dict(files=files, binarySha256=sha256(binary).hexdigest(), onlyReferenceNormalPolicyChanged=True, policy=policy,
    sameDdsSha256=fixture['convertedDdsSha256'], sameSamplerSha256=fixture['samplerMetadataSha256'])
(out / 'fixture-inputs.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(files=len(files), bytes=sum(item['bytes'] for item in files), assetSha256=new_hashes[asset.as_posix()])))
