
from hashlib import sha256
from pathlib import Path
import json
import zipfile


run=Path(__file__).resolve().parent
engine=run.parents[2]
prior=run.parent/'20261112-173549-reference-hair-color-source-196fbc'
native=run.parent/'20261112-053111-intel-reference-visibility-sources-5238e2/native-normal-explicit-mips'
evidence=engine/'docs/acceptance/nr/evidence/2026-11-12/reference-hair-color-pair'
modes=('t17','pair')
devices=('nvidia','intel')


def load(path):
    return json.loads(path.read_text())


gate=load(run/'color-pair-gate.json')
assert gate['overallStatus']=='failed-user-review'
assert gate['overlaysCompacted']=={mode:895 for mode in modes}
assert not any((run/mode/'overlay').exists() for mode in modes)
held,released=(load(run/('lease-'+state+'.json')) for state in ('held','released'))
assert held['token']==released['token'] and released['state']=='released'
records={}
for mode in modes:
    folder=run/mode
    compiled=load(folder/'shader-probe/compiled.json')
    assert compiled['mode']==mode and len(compiled['programs'])==8
    records[mode]=dict(programs=compiled['programs'],results={},execution={})
    for device in devices:
        receipt=load(folder/(device+'-execution.json'))
        assert receipt['status']=='exited' and receipt['exitCode']==0
        source=load(folder/(device+'-results.json'))
        assert source['shaderCount']==895 and source['validationClean'] and source['allocatorZero']
        assert all(source['overlay'][name]==item['probeSha256'] for name,item in compiled['programs'].items())
        records[mode]['execution'][device]=receipt
        records[mode]['results'][device]={name:value for name,value in source.items() if name!='overlay'}
texture_folder=run.parent/'20261112-153052-reference-hair-mip-footprint-510ded/hair-project/character/native-textures'
inputs={}
for slot in ('t17','t18'):
    paths=texture_folder/(slot+'.dds'),texture_folder/(slot+'.dds.azmeta')
    inputs[slot]={path.name:sha256(path.read_bytes()).hexdigest() for path in paths}
    settings=load(paths[1])['settings']['texture']
    assert settings==dict(schemaVersion=1,filter='linear',mipFilter='nearest',anisotropy=1,mipBias=-1)
source_file=native/'nvidia-950-pixel.asm'
asm=source_file.read_text()
assert 'v1.xyxx, t17.xyzw, s2, cb1[26].x' in asm and 'v1.xyxx, t18.xyzw, s2, cb1[26].x' in asm
prior_receipt=load(engine/'docs/acceptance/nr/evidence/2026-11-12/reference-hair-color-source/results.json')
assert prior_receipt['gate']['colors']['intel'][0]['overOne']==449
assert prior_receipt['gate']['colors']['intel'][0]['introduced']==47

evidence.mkdir(parents=True,exist_ok=False)
archive_path=evidence/'validation.zip'
with zipfile.ZipFile(archive_path,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(run.iterdir()):
        if path.is_file() and not path.name.startswith('next-') and path.suffix in ('.py','.json','.log'):
            archive.write(path,path.name)
    for mode in modes:
        for path in sorted((run/mode).rglob('*')):
            if path.is_file() and path.suffix in ('.py','.json','.log','.bin','.spv','.frag'):
                archive.write(path,path.relative_to(run).as_posix())
    for device in devices:
        archive.write(prior/(device+'-frozen-hair-rgb.bin'),'t18-only/'+device+'-frozen-hair-rgb.bin')
    archive.write(source_file,'native-source/'+source_file.name)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    count=len(archive.namelist())
raw=archive_path.read_bytes()
assert len(raw)<8*1024**2
summary=dict(status=gate['status'],gate=gate,inputs=inputs,nativeShaderSha256=sha256(source_file.read_bytes()).hexdigest(),
    modes=records,sourceT18Archive=prior_receipt['archive']['sha256'],lease=released,scope=load(run/'task-card.json'),
    archive=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw),members=count))
(evidence/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
