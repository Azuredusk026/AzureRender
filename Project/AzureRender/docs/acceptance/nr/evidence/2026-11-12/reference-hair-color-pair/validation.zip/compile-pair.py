
from hashlib import file_digest
from pathlib import Path
import json
import subprocess


run=Path(__file__).resolve().parent
engine=run.parents[2]
build=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
catalog=json.loads((build/'shader-reload.json').read_text())
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def replace_once(source,old,new):
    assert source.count(old)==1,old
    return source.replace(old,new)


original=engine/'shaders/mesh.frag'
source=replace_once(original.read_text(),'#include "material_primary_uv.glsl"',
    '#include "material_primary_uv.glsl"\n#include "texture_footprint.glsl"')
anchor='float azureMaterialRadianceScale() {'
source=replace_once(source,anchor,'''
vec4 sampleProjectedHairPointMip(sampler2D image,vec2 uv) {
    vec4 implicitSample=azureSamplePrimaryUv(image,uv);
    uint flags=uint(materialSurfaceProfiles.profiles[material.materialPadding>>1U].rows[6].w+.5);
    if(AZURE_MATERIAL_CLASS!=3U||(flags&4U)==0u)return implicitSample;
    vec2 size=vec2(textureSize(image,0));
    float lod=azureAxisDiagonalMipLod(azurePrimaryUvDx*size,azurePrimaryUvDy*size);
    vec4 explicitSample=textureLod(image,uv,lod);
    bool atBoundary=abs(fract(lod-1.0)-.5)<=1.0/256.0;
    return mix(explicitSample,implicitSample,bvec4(atBoundary));
}
'''+anchor)
t17=replace_once(source,':azureSamplePrimaryUv(AZ_TEX_FACE_SDF,uv);',':sampleProjectedHairPointMip(AZ_TEX_FACE_SDF,uv);')
t17=replace_once(t17,':azureSamplePrimaryUv(AZ_TEX_FACE_SDF,textureCoordinate).b;',
    ':sampleProjectedHairPointMip(AZ_TEX_FACE_SDF,textureCoordinate).b;')
pair=replace_once(t17,':azureSamplePrimaryUv(AZ_TEX_HAIR_DATA,uv);',
    ':sampleProjectedHairPointMip(AZ_TEX_HAIR_DATA,uv);')
pair=replace_once(pair,':azureSamplePrimaryUv(AZ_TEX_HAIR_DATA,textureCoordinate);',
    ':sampleProjectedHairPointMip(AZ_TEX_HAIR_DATA,textureCoordinate);')
programs=[desc for desc in catalog['programs'] if desc['source']=='mesh.frag' and desc['output'].startswith('mesh')
    and desc['output'].endswith('_coverage_uvquad.frag.spv') and 'AZURE_BINDLESS=1' not in desc['defines']
    and 'AZURE_GEOMETRY_SAMPLES=1' not in desc['defines']]
assert len(programs)==8
base_shaders={}
for desc in programs:
    name=desc['output']
    argv=[str(sdk/'glslc.exe'),*desc['arguments'],*('-D'+flag for flag in desc['defines'])]
    check=run/'baseline.spv'
    subprocess.run([*argv,str(original),'-o',str(check)],check=True)
    expected=digest(build/'shaders'/name)
    assert digest(check)==expected,name
    check.unlink()
    base_shaders[name]=(expected,argv)
for mode,glsl in (('t17',t17),('pair',pair)):
    folder=run/mode/'shader-probe'
    folder.mkdir(parents=True,exist_ok=False)
    probe=folder/'mesh.frag'
    probe.write_text(glsl,encoding='utf-8')
    outputs={}
    for name,(expected,base) in base_shaders.items():
        target=folder/name
        argv=[*base,'-I'+str(original.parent),str(probe),'-o',str(target)]
        subprocess.run(argv,check=True)
        subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(target)],check=True)
        assert digest(target)!=expected
        outputs[name]=dict(baselineSha256=expected,probeSha256=digest(target),command=argv)
    record=dict(mode=mode,bias=-1,sourceSha256=digest(probe),productionSourceSha256=digest(original),programs=outputs)
    (folder/'compiled.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(dict(mode=mode,compiled=len(outputs),sourceSha256=record['sourceSha256'])))
