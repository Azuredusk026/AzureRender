
from hashlib import file_digest
from pathlib import Path
import json
import os
import subprocess
import sys
import time

import numpy as np


run=Path(__file__).resolve().parent
build=run.parents[1]
t18=run.parent/'20261112-173549-reference-hair-color-source-196fbc'
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')


def compact_overlay(folder,catalog):
    shader_dir=(folder/'overlay/shaders').resolve(strict=True)
    assert shader_dir.parent.parent==folder.resolve(strict=True)
    listed=list(shader_dir.iterdir())
    assert {path.name:digest(path) for path in listed}==catalog
    for path in listed:
        assert path.is_file() and path.resolve(strict=True).parent==shader_dir and path.suffix=='.spv'
        path.unlink()
    shader_dir.rmdir()
    shader_dir.parent.rmdir()
    return len(listed)


def capture(mode):
    folder=run/mode
    for device in ('nvidia','intel'):
        os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*' if device=='intel' else '*nv-vk64*'
        argv=[sys.executable,'-B',str(run/'color-capture.py'),mode,device]
        result=shared.maintenance.guarded_run(build,run.name,argv,330)
        write(folder/(device+'-execution.json'),result)
        print(json.dumps(result),flush=True)
        assert result['status']=='exited' and result['exitCode']==0,result
        subprocess.run([sys.executable,'-B',str(folder/'compact-capture.py'),device+'-frames'],check=True)
    cases={device:json.loads((folder/(device+'-results.json')).read_text()) for device in ('nvidia','intel')}
    assert cases['nvidia']['overlay']==cases['intel']['overlay']
    files=compact_overlay(folder,cases['nvidia']['overlay'])
    assert files==895
    return cases,files


def colors(folder):
    raw=np.fromfile(folder/'intel-frozen-hair-rgb.bin','<u2').astype('i4').reshape(17017,11)
    pixels,baseline,actual,frozen=np.split(raw,(2,5,8),axis=1)
    return pixels,baseline,actual,frozen


predecessor,receipt_path=sys.argv[1:]
deadline=time.monotonic()+1800
while time.monotonic()<deadline:
    try:
        state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
        receipt=json.loads(Path(receipt_path).read_text())
    except (OSError,ValueError):
        time.sleep(1)
        continue
    assert state['token']==predecessor and receipt['token']==predecessor
    if state['state']==receipt['state']=='released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed color pairing window has not opened')
write(run/'predecessor-receipt.json',receipt)
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key,None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
lease=None
try:
    with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-reference-hair-color-pair-gpu',run) as lease:
        write(run/'lease-held.json',lease)
        modes={mode:capture(mode) for mode in ('t17','pair')}
        pixels,baseline,actual_t18,frozen=colors(t18)
        bad={name:(np.abs(raw-frozen).max(axis=1)>1) for name,raw in (('baseline',baseline),('t18',actual_t18))}
        assert (int(bad['baseline'].sum()),int(bad['t18'].sum()))==(568,449)
        for mode in modes:
            selected,old,actual,expected=colors(run/mode)
            assert np.array_equal(selected,pixels) and np.array_equal(old,baseline) and np.array_equal(expected,frozen)
            bad[mode]=np.abs(actual-frozen).max(axis=1)>1
            assert int(bad[mode].sum())==modes[mode][0]['intel']['colors'][0]['overOne']
        t18_new=~bad['baseline']&bad['t18']
        assert int(t18_new.sum())==47
        pair_new=~bad['baseline']&bad['pair']
        attachments_exact=all(attachment['exact'] for cases,_ in modes.values()
            for device in cases.values() for attachment in device['attachments'].values())
        activated=all(any(row['frozenHairChanged'] for row in cases['intel']['colors']) for cases,_ in modes.values())
        nvidia_pass=all(row['overOne']==0 for cases,_ in modes.values() for row in cases['nvidia']['colors'])
        summary=dict(status='qualified-color-pair-control' if attachments_exact and activated else 'failed-color-pair-control',
            overallStatus='failed-user-review',referenceAttachmentsExact=attachments_exact,activated=activated,nvidiaFrozenHairPass=nvidia_pass,
            colors={mode:{name:result['colors'] for name,result in cases.items()} for mode,(cases,_) in modes.items()},
            t18IntroducedClosedByT17=int((t18_new&~bad['t17']).sum()),t18IntroducedClosedByPair=int((t18_new&~bad['pair']).sum()),
            t18IntroducedStillInPair=int((t18_new&bad['pair']).sum()),
            pairIntroducedOutsideT18=int((pair_new&~t18_new).sum()),
            pairClosedOverBothSingleControls=int((bad['t17']&bad['t18']&~bad['pair']).sum()),
            overlaysCompacted={mode:files for mode,(_,files) in modes.items()})
        write(run/'color-pair-gate.json',summary)
        print(json.dumps(summary),flush=True)
finally:
    if lease is not None:
        write(run/'lease-released.json',lease)
