from pathlib import Path
import json
import os
import subprocess
import sys

out=Path(__file__).resolve().parent
root=Path.cwd().resolve()
if '--inside' not in sys.argv:
    raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import describe,digest,inputs,verify

def read(path):
    return json.loads(path.read_bytes())
def write(path,payload):
    temp=path.with_suffix(path.suffix+'.next')
    temp.write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
    temp.replace(path)

original=out/'replay-attempts/null-rhi-camera-first'
source=inputs(root)
test_source={p.relative_to(root).as_posix():digest(p) for p in (root/'tests').rglob('*') if p.is_file()}
protected=read(out/'protected-files.json')
assert len(protected)==13 and all(digest(root/name)==sha for name,sha in protected.items())
change='tests/NullRhiPassTests.cpp'
assert subprocess.check_output(['git','rev-parse','--short=7','HEAD'],text=True).strip()=='953648e'
env=os.environ|managed_environment(out/'tmp')
env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',
           CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',
           PYTHONDONTWRITEBYTECODE='1',VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LAYER_ENABLES','AZURE_DISABLE_COMPUTED_MATERIAL_VIEW'):
    env.pop(key,None)
proofs={}
results={}
for config in ('Debug','Release'):
    label=config.lower()
    build=root/f'build/ninja-msvc-{label}'
    tests_before=read(original/f'{label}-tests-source.json')
    assert set(test_source)==set(tests_before)
    test_delta={name:[tests_before[name],value] for name,value in test_source.items() if value!=tests_before[name]}
    assert set(test_delta)=={change}
    product_before=read(original/f'{label}-products.json')
    assert product_before['source']==source and product_before['commit'].startswith('bfe700e')
    command=['cmake','--build',str(build),'--config',config,'--target','AzureRenderNullRhiPassTests']
    with (out/f'null-rhi-camera-{label}-build.log').open('wb') as log:
        subprocess.run(command,env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
    assert 'AZURE_ENABLE_COMPUTED_MATERIAL_VIEW:BOOL=OFF' in (build/'CMakeCache.txt').read_text()
    inventory=json.loads(subprocess.check_output(['ctest','--test-dir',str(build),'-C',config,'--show-only=json-v1'],env=env))
    assert inventory['tests']==read(original/f'{label}-inventory.json')['tests']
    relevant=[x['name'] for x in inventory['tests'] if Path(x['command'][0]).name=='AzureRenderNullRhiPassTests.exe']
    assert relevant==['AzureRender.NullRhiPass']
    product=describe(root,[Path(name) for name in product_before['products']])
    assert product['source']==source
    verify(root,product)
    changes={name:[product_before['products'][name],value] for name,value in product['products'].items()
        if value!=product_before['products'][name]}
    assert [Path(name).name for name in changes]==['AzureRenderNullRhiPassTests.exe']
    proofs[label]=product
    results[label]=dict(testSource=test_delta,changedProducts=changes,
        identicalProducts=len(product['products'])-len(changes),registeredTests=len(inventory['tests']))
assert inputs(root)==source and all(digest(root/name)==sha for name,sha in protected.items())
for label,proof in proofs.items():
    write(out/f'{label}-products.json',proof)
    write(out/f'{label}-tests-source.json',test_source)
    results[label]['productReceiptSha256']=digest(out/f'{label}-products.json')
write(out/'null-rhi-camera-rebuild.json',results)
for config,first,last in [('Debug',420,420),('Release',417,423)]:
    subprocess.run([sys.executable,'-X','utf8','-B',str(out/'full.py'),'suite',config,str(first),str(last),'--inside'],
                   env=env,cwd=root,check=True,timeout=180)
    report=read(out/f'{config.lower()}-ctest-{first:03d}-{last:03d}.json')
    assert report['status']=='passed' and not report['failed'] and not report['skipped'],report
    print(config,'passed',report['tests'],flush=True)

