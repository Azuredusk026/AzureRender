from hashlib import file_digest
from pathlib import Path
from shutil import copyfile
import json
import uuid


out = Path(__file__).resolve().parent
prior = out.parent / '20261112-084230-cloth-receiver-authored-mips-a73d87'
project = out / 'hair-project'
source = prior / 'hair-project'
sidecar = Path('character/cloth-receiver-normal-authored.dds.azmeta')
native = out.parent / '20261112-083618-native-cloth-receiver-normal-input-a94a9c/native-source'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


fixture = json.loads((prior / 'fixture-inputs.json').read_text())
assert fixture['authoredDdsSha256'] == '1fb335fe9de63f7338e93e2d44e8b1c23bcf0a7ee08581ca0ed723efb8455ba9'
assert len(fixture['files']) == 44
for item in fixture['files']:
    relative = Path(item['relative'])
    original = (source / relative).resolve(strict=True)
    assert original.is_relative_to(source) and digest(original) == item['sha256']
    destination = project / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    copyfile(original, destination)
    assert digest(destination) == item['sha256']

baseline = json.loads((source / sidecar).read_text(encoding='utf-8'))
assert baseline['schemaVersion'] == 1 and baseline['dependencies'] == [] and baseline['settings'] == {}
uuid.UUID(baseline['id'])
program = json.loads((native / 'report.json').read_text())['devices']['nvidia']
sampler = program['sampler']
assert sampler['filters'] == ['FilterMode.Linear', 'FilterMode.Linear', 'FilterMode.Point']
assert sampler['address'] == ['AddressMode.Wrap', 'AddressMode.Wrap'] and sampler['bias'] == 0 and sampler['anisotropy'] == 0
assert program['program']['sampleBias'] == -1
settings = dict(schemaVersion=2, usage='normal', colorSpace='linear', filter='linear', magFilter='linear',
    wrapU='repeat', wrapV='repeat', mipPolicy='generate', mipFilter='nearest', anisotropy=1, mipBias=-1)
candidate = dict(baseline, settings={'texture': settings})
with (project / sidecar).open('x', encoding='utf-8') as stream:
    json.dump(candidate, stream, indent=2)
    stream.write('\n')
files = [dict(relative=path.relative_to(project).as_posix(), bytes=path.stat().st_size, sha256=digest(path))
    for path in sorted(project.rglob('*')) if path.is_file()]
old_hashes = {entry['relative']: entry['sha256'] for entry in fixture['files']}
new_hashes = {entry['relative']: entry['sha256'] for entry in files}
assert set(new_hashes) - set(old_hashes) == {sidecar.as_posix()}
assert all(new_hashes[name] == value for name, value in old_hashes.items())
result = dict(files=files, authoredDdsSha256=fixture['authoredDdsSha256'], baselineMetadataSha256=digest(source / sidecar),
    candidateMetadataSha256=new_hashes[sidecar.as_posix()], sampler=settings, sameTextureAndGeometry=True)
(out / 'fixture-inputs.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(files=len(files), bytes=sum(item['bytes'] for item in files),
    metadataSha256=result['candidateMetadataSha256'])))
