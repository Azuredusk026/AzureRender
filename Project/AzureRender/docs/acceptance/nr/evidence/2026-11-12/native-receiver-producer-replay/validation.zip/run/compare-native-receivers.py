from hashlib import sha256
from pathlib import Path
import json
import struct
import zlib

import numpy as np


out = Path(__file__).resolve().parent
capture = out / 'native-caster-geometry'
receipt = json.loads((capture / 'native-caster-geometry.json').read_text())
assert receipt['status'] == 'qualified' and receipt['depthResource'] == 'ResourceId::141967'
counter_messages = {
    'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU',
    'NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image',
}
assert set(receipt['debugMessages']) <= counter_messages, receipt['debugMessages']
assets = json.loads((out / 'player-reference-asset-inputs.json').read_text())
numeric = out.parent / '20261110-003435-visibility-numeric-contract-4f95e7'
profile = out.parent / '20261112-061922-project-reference-visibility-profile-47902e'
source = out.parent / '20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
numerics = out.parent / '20261112-053111-intel-reference-visibility-sources-5238e2/live-numerics'
reference = json.loads((source / 'native-atlas-producers.json').read_text())
assert reference['status'] == 'qualified' and reference['receiverNormal']['resource'] == 'ResourceId::141952'


def read_crop(folder, entry):
    data = (folder / entry['path']).read_bytes()
    assert sha256(data).hexdigest() == entry['sha256'] and len(data) == entry['bytes']
    return np.frombuffer(zlib.decompress(data), '<u4').reshape(310, 290)


receiver = np.fromfile(numeric / 'receiver-queries.bin', '<f4').reshape(-1, 4)
x, y = receiver[:, :2].astype('i4').T
assert len(receiver) == 49384 and np.all((x >= 1140) & (x < 1430) & (y >= 1000) & (y < 1310))
owners = np.zeros((310, 290), 'u2')
previous = np.zeros_like(owners, dtype='<u4')
for event, stage in reference['receiverNormal']['stages'].items():
    current = read_crop(source, stage['crop'])
    owners[previous != current] = int(event)
    previous = current
query_owner = owners[y - 1000, x - 1140]
expected = np.fromfile(numeric / 'receiver-expected.bin', '<u4').astype('i4')


def residual(mode):
    codes = np.fromfile(numerics / mode / 'receiver-selected.bin', 'u1').astype('i4')
    return np.abs(codes - expected) > 1


actual_failure = residual('intel-profile')
depth_closed = actual_failure & ~residual('intel-native-depth')
normal_closed = actual_failure & ~residual('intel-native-normal')
numerical_receipt = json.loads((numerics / 'results.json').read_text())
previous_summary = json.loads((profile / 'profile-receiver-attribution.json').read_text())
assert actual_failure.sum() == numerical_receipt['intel-profile']['receiver']['overOne'] == 2981
assert depth_closed.sum() == sum(item['cases']['intel-native-depth']['closed'] for item in previous_summary.values()) == 1227
assert normal_closed.sum() == sum(item['cases']['intel-native-normal']['closed'] for item in previous_summary.values()) == 1530
timeline = {int(event): read_crop(capture, stage['crop']) for event, stage in receipt['receiverDepth'].items()}
native_r32 = timeline.pop(699)
assert receipt['receiverDepth']['699']['fullSha256'] == '02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb'
native_r32 = native_r32[y - 1000, x - 1140]
actual_r32 = np.fromfile(numerics / 'depth.bin', '<u4').reshape(1440, 2560)[y, x]
events = sorted(timeline)
predecessor = None
depth_history = {}
last_after_422 = np.zeros(len(x), 'u2')
for event in events:
    row = timeline[event][y - 1000, x - 1140]
    change = row != predecessor if predecessor is not None else row != 0
    if event > 422:
        last_after_422[change] = event
    exact = row == native_r32
    depth_history[event] = {
        str(owner): dict(changed=int((change & (query_owner == owner)).sum()),
            equalsR32=int((exact & (query_owner == owner)).sum()),
            equalsR32InDepthClosed=int((exact & (query_owner == owner) & depth_closed).sum()))
        for owner in (377, 422)
    }
    predecessor = row

geometry = {}
for event in (296, 328, 345, 377, 404, 422, 440, 460, 478):
    data = receipt['receiverDraws'][str(event)]['input']
    indices = data['indices']
    if not indices:
        continue
    closest = sorted(assets['meshes'], key=lambda item: abs(item['indices'] - indices))[:3]
    candidates = [dict(material=item['material'], indices=item['indices'], offset=item['indices'] - indices) for item in closest]
    matches = []
    for slot, texture in data['textures'].items():
        if 'baseSha256' not in texture:
            continue
        for item in assets['meshes']:
            for source_name, image in (item['normal'] or {}).get('images', {}).items():
                if texture['baseSha256'] == image.get('baseSha256'):
                    matches.append(dict(binding=int(slot), material=item['material'], source=source_name, sha256=texture['baseSha256']))
    geometry[event] = dict(indices=indices, candidates=candidates, exactNativeTextureSources=matches, bindings=data['textures'])
assert geometry[422]['indices'] == 43044 and geometry[422]['candidates'][0]['offset'] == 0
assert geometry[377]['indices'] == 102882 and geometry[377]['candidates'][0]['material'] == 'M_actor_laevat_cloth_01'
assert geometry[440]['indices'] == 43044 and geometry[440]['candidates'][0]['offset'] == 0
native_normal = geometry[377]['bindings']['1']
assert native_normal['resource'] == 'ResourceId::87521' and native_normal['format'] == 'BC5_UNORM'
assert geometry[440]['bindings']['0']['resource'] == geometry[422]['bindings']['2']['resource'] == 'ResourceId::23880'
assert any(item['event'] == 541 and item['usage'] == 'ResourceUsage.PS_Resource' for item in receipt['depthUsage'])
assert any(item['event'] == 541 and item['usage'] == 'ResourceUsage.ColorTarget' for item in receipt['rasterDepthUsage'])
assert all(receipt['receiverDepth'][str(event)]['fullSha256'] == receipt['receiverDepth']['699']['fullSha256']
    for event in (478, 541, 688))


def constant(name, row, component):
    return struct.unpack_from('<f', (capture / (name + '.bin')).read_bytes(), row * 16 + component * 4)[0]


constants = dict(clothNormalScale=constant('377-4-b2', 0, 3), clothSampleBias=constant('377-4-b0', 26, 0),
    hairCutoff=constant('422-4-b2', 12, 0), shellCutoff=constant('440-4-b1', 12, 0),
    hairSampleBias=constant('422-4-b0', 26, 0), shellSampleBias=constant('440-4-b0', 26, 0),
    shellWidth=constant('440-0-b3', 13, 0))
assert constants == dict(clothNormalScale=1.0, clothSampleBias=-1.0, hairCutoff=.5, shellCutoff=.5,
    hairSampleBias=-1.0, shellSampleBias=-1.0, shellWidth=.5)

groups = {}
for event in (377, 422):
    selected = query_owner == event
    fixed_depth = selected & depth_closed
    fixed_normal = selected & normal_closed
    before_event = max(item for item in events if item < event)
    before = timeline[before_event][y - 1000, x - 1140]
    initial = timeline[event][y - 1000, x - 1140]
    final = timeline[events[-1]][y - 1000, x - 1140]
    after = last_after_422[fixed_depth]
    later = {int(value): int(count) for value, count in zip(*np.unique(after, return_counts=True))}
    groups[event] = dict(samples=int(selected.sum()), profileOverOne=int((selected & actual_failure).sum()),
        depthClosed=int(fixed_depth.sum()), normalClosed=int(fixed_normal.sum()),
        depthClosedInitiallyNativeR32=int((fixed_depth & (initial == native_r32)).sum()),
        depthClosedFinallyNativeR32=int((fixed_depth & (final == native_r32)).sum()),
        depthClosedChangedByProducer=int((fixed_depth & (initial != before)).sum()),
        depthClosedActualMatchesBeforeProducerNativeD32=int((fixed_depth & (actual_r32 == before)).sum()),
        depthClosedActualMatchesInitialNativeD32=int((fixed_depth & (actual_r32 == initial)).sum()),
        depthClosedActualMatchesFinalNativeD32=int((fixed_depth & (actual_r32 == final)).sum()),
        depthClosedLastNativeWriteAfter422=later)

assert groups[377]['profileOverOne'] == previous_summary['377']['cases']['intel-profile']['overOne']
assert groups[422]['profileOverOne'] == previous_summary['422']['cases']['intel-profile']['overOne']
assert groups[422]['depthClosedLastNativeWriteAfter422'] == {0: 84, 440: 860}
assert depth_history[440]['422']['changed'] == 2046 and depth_history[440]['422']['equalsR32'] == 19063
summary = dict(device=receipt['device'], depth=receipt['depthResource'], r32=receipt['rasterDepthResource'],
    depthUsage=receipt['depthUsage'], r32Usage=receipt['rasterDepthUsage'], profiles=groups, geometry=geometry, depthHistory=depth_history,
    constants=constants, counterMessages=receipt['debugMessages'])
(out / 'native-receiver-producer-comparison.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(dict(groups=groups, event377=geometry[377], event422=geometry[422], r32Usage=receipt['rasterDepthUsage'])))
