from hashlib import file_digest, sha256
from pathlib import Path
import base64
import json
import struct
from urllib.parse import unquote


out = Path(__file__).resolve().parent
profile = out.parent / '20261112-061922-project-reference-visibility-profile-47902e'
project = profile / 'hair-project'
paths = {entry['relative']: entry for entry in json.loads((profile / 'profile-fixture-inputs.json').read_text())}
relative = 'character/hair-coverage.glb'
asset = project / relative
scene = project / 'assets/hair-coverage.azurelevel'
with scene.open('rb') as stream:
    assert file_digest(stream, 'sha256').hexdigest() == paths['assets/hair-coverage.azurelevel']['sha256']
level = json.loads(scene.read_text())
assert level['resources'] == [{'id': 'hero', 'asset': 'character:/hair-coverage.glb'}]
hero, = [node for node in level['nodes'] if node['id'] == 'hero']
overrides = {}
for path in sorted((project / 'assets').glob('*.azurematerial')):
    meta = path.with_suffix(path.suffix + '.azmeta')
    key = json.loads(meta.read_text())['id']
    override_relative = path.relative_to(project).as_posix()
    data = path.read_bytes()
    digest = sha256(data).hexdigest()
    assert digest == paths[override_relative]['sha256']
    overrides[key] = dict(path=override_relative, sha256=digest, material=json.loads(data))


def describe_image(data):
    identity = dict(bytes=len(data), sha256=sha256(data).hexdigest(), magic=data[:12].hex())
    if data[:4] == b'DDS ':
        height, width = struct.unpack_from('<2I', data, 12)
        fourcc = data[84:88]
        if fourcc == b'DX10':
            fmt, = struct.unpack_from('<I', data, 128)
            start = 148
            block = {71: 8, 72: 8, 74: 16, 75: 16, 77: 16, 78: 16, 80: 8, 81: 8,
                83: 16, 84: 16, 95: 16, 96: 16, 98: 16, 99: 16}.get(fmt)
            identity['dxgi'] = fmt
        else:
            start = 128
            block = {b'DXT1': 8, b'DXT3': 16, b'DXT5': 16, b'ATI1': 8, b'ATI2': 16,
                b'BC4U': 8, b'BC4S': 8, b'BC5U': 16, b'BC5S': 16}.get(fourcc)
            identity['fourCC'] = fourcc.decode('ascii', errors='replace')
        if block:
            count = ((width + 3) // 4) * ((height + 3) // 4) * block
            assert len(data) >= start + count
            identity.update(extent=[width, height], baseBytes=count, baseSha256=sha256(data[start:start + count]).hexdigest())
    return identity


with asset.open('rb') as stream:
    assert file_digest(stream, 'sha256').hexdigest() == paths[relative]['sha256']
    stream.seek(0)
    tag, version, total, length, chunk = struct.unpack('<5I', stream.read(20))
    assert (tag, version, total, chunk) == (0x46546c67, 2, asset.stat().st_size, 0x4e4f534a)
    gltf = json.loads(stream.read(length))
    bin_length, chunk = struct.unpack('<2I', stream.read(8))
    assert chunk == 0x004e4942 and stream.tell() + bin_length == total
    offset = stream.tell()

    def normal_image(index):
        texture = gltf['textures'][index]
        mappings = {'source': texture.get('source')}
        for name in ('MSFT_texture_dds', 'KHR_texture_basisu', 'EXT_texture_webp'):
            if name in texture.get('extensions', {}):
                mappings[name] = texture['extensions'][name]['source']
        images = {}
        for name, image_index in mappings.items():
            if image_index is None:
                continue
            image = gltf['images'][image_index]
            if 'bufferView' in image:
                view = gltf['bufferViews'][image['bufferView']]
                assert view['buffer'] == 0
                stream.seek(offset + view.get('byteOffset', 0))
                data = stream.read(view['byteLength'])
                assert len(data) == view['byteLength']
                identity = describe_image(data)
            else:
                uri = image['uri']
                if uri.startswith('data:'):
                    declaration, encoded = uri.split(',', 1)
                    assert declaration.endswith(';base64')
                    identity = dict(dataUriType=declaration[5:-7], **describe_image(base64.b64decode(encoded, validate=True)))
                else:
                    source_path = (asset.parent / unquote(uri)).resolve(strict=True)
                    key = source_path.relative_to(project).as_posix()
                    identity = dict(uri=uri, **describe_image(source_path.read_bytes()))
                    assert identity['sha256'] == paths[key]['sha256']
            images[name] = dict(index=image_index, name=image.get('name'), mime=image.get('mimeType'), **identity)
        return dict(texture=index, sampler=texture.get('sampler'), images=images)

    materials = gltf['materials']
    accessors = gltf['accessors']
    output = []
    for mesh in gltf['meshes']:
        for primitive in mesh['primitives']:
            material = materials[primitive['material']]
            source = material.get('normalTexture')
            slot = material['name']
            override = hero.get('materialSlots', {}).get('name:' + slot)
            output.append(dict(mesh=mesh['name'], material=slot, indices=accessors[primitive['indices']]['count'],
                vertices=accessors[primitive['attributes']['POSITION']]['count'],
                alphaMode=material.get('alphaMode', 'OPAQUE'), alphaCutoff=material.get('alphaCutoff', .5),
                doubleSided=material.get('doubleSided', False), normal=normal_image(source['index']) if source else None,
                normalScale=source.get('scale', 1.0) if source else None, sceneMaterial=overrides[override] if override else None))
    assert len(output) == 13 and sum(item['indices'] == 43044 for item in output) == 1
report = dict(assetSha256=paths[relative]['sha256'], sceneSha256=paths['assets/hair-coverage.azurelevel']['sha256'], meshes=output)
(out / 'player-reference-asset-inputs.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps([{key: item[key] for key in ('material', 'indices', 'vertices')} for item in output]))
