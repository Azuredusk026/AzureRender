from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys


out = Path(__file__).resolve().parent
build = out.parents[1]
main = Path('D:/Projects/FYP/Project/AzureRender/build')
owner = '01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
source = '9327ca4a66d151ccf54ae75525373e506608febc'
sys.path.insert(0, str(main.parent / 'tools'))
import shared_resources as shared


claim_path = Path('D:/Projects/FYP-coordination/quality-claim.json')
claim = json.loads(claim_path.read_text(encoding='utf-8'))
assert claim['threadId'] == owner and claim['state'] == 'project-reference-visibility-profile-cpu'
assert claim['lastCommit'] == '3dc8cce41e9b632386ffdf2be47d4234fa8ccbd0'
commit = subprocess.check_output(['git', 'log', '-1', '--format=%H%n%P'], cwd=build.parent, text=True).splitlines()
assert commit == [source, claim['lastCommit']]
evidence = build.parent / 'docs/acceptance/nr/evidence/2026-11-12/project-reference-visibility-profile'
manifest = json.loads((evidence / 'results.json').read_text())
assert manifest['status'] == 'qualified-project-reference-visibility-profile'
assert sha256((evidence / 'validation.zip').read_bytes()).hexdigest() == manifest['archive']['sha256']
old_stage = Path(claim['taskPath'])
assert old_stage.name == '20261112-061922-project-reference-visibility-profile-47902e'
old_local, old_main = claim['localInputLease'], claim['inputLease']


def inherited(root, tokens):
    with shared.maintenance.database(root, True) as db:
        records = shared.maintenance.rows(db)
    assert all(records[token]['owner'] == owner for token in tokens)
    return list(dict.fromkeys(name for token in tokens for name in records[token]['inputs']))


local_inputs = inherited(build, old_local)
local_inputs.append(old_stage.name)
main_inputs = inherited(main, old_main)
local = shared.acquire_inputs(build, out, local_inputs, owner)
try:
    native = shared.acquire_inputs(main, out, main_inputs, owner)
except Exception:
    shared.release_inputs(build, local, owner)
    raise
claim.update(state='native-receiver-producer-replay', taskPath=str(out), inputLease=[native], localInputLease=[local],
    nativeCaptureLease=native, lastCommit=source,
    pendingCommand='Replay native e377 packed normal inputs and the e422 through e699 receiver depth timeline',
    ownedFiles=['docs/acceptance/nr/native-receiver-producer-replay.md'], additionalTaskPaths=[])
claim['observed'].update(profileActualReceiverNvidia=2736,profileActualReceiverIntel=2981,profileActualHairNvidia=0,
    profileActualHairIntel=208,profileActualColorNvidia=0,profileActualColorIntel=575,profileGpuTests=16,
    profileGpuBindingExact=True,profileOriginalFourExact=True,profilePackageMoved=True,
    receiver377ProfileOverOne=1399,receiver377FrozenNormalOverOne=158,
    receiver422ProfileOverOne=1089,receiver422FrozenDepthOverOne=152)
(out / 'task-card.json').write_text(json.dumps(dict(local=local, main=native, sourceBase=source,
    plannedBytes=67108864, localInputs=local_inputs, mainInputs=main_inputs,
    baselinePlayer=manifest['builds']['release']['playerSha256'], gate='49384 pixels, maximum per-channel byte error 1'), indent=2) + '\n')
temporary = claim_path.with_name(claim_path.name + '.nr-quality-new')
with temporary.open('x', encoding='utf-8') as stream:
    json.dump(claim, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
os.replace(temporary, claim_path)
for token in old_main:
    shared.release_inputs(main, token, owner)
for token in old_local:
    shared.release_inputs(build, token, owner)
print(json.dumps(dict(local=local, main=native, output=str(out))))
