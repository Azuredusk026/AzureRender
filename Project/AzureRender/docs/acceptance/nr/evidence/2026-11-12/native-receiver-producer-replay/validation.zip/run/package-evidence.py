from hashlib import sha256
from pathlib import Path
import json
import zipfile


out = Path(__file__).resolve().parent
capture = out / 'native-caster-geometry'
target = out.parents[2] / 'docs/acceptance/nr/evidence/2026-11-12/native-receiver-producer-replay'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


comparison = read(out / 'native-receiver-producer-comparison.json')
execution = read(out / 'native-caster-geometry-execution.json')
native = read(capture / 'native-caster-geometry.json')
assert execution['status'] == 'exited' and execution['exitCode'] == 0 and native['status'] == 'qualified'
assert comparison['profiles']['377']['normalClosed'] == 1253
assert comparison['profiles']['422']['depthClosedLastNativeWriteAfter422'] == {'0': 84, '440': 860}
prior = read(out.parent / '20261112-061922-project-reference-visibility-profile-47902e/default-four-results.json')
assert prior['allExact'] and prior['depthCaptureAbsent'] and prior['validationClean'] and prior['allocatorZero']
assert prior['playerSha256'] == read(out / 'task-card.json')['baselinePlayer']
archive = out / 'native-receiver-validation-pending.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as writer:
    def add(path):
        writer.write(path, 'run/' + path.relative_to(out).as_posix())

    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.json', '.log'):
            add(path)
    for path in sorted(capture.iterdir()):
        if path.is_file() and (path.name.endswith('-depth.zlib') or path.name.startswith(('377-', '422-', '440-'))
                or path.name in ('native-caster-geometry.json', 'process.log', 'request.json')):
            add(path)
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    fingerprints = {name: sha256(reader.read(name)).hexdigest() for name in reader.namelist()}
assert archive.stat().st_size <= 8 * 1024 * 1024
result = dict(status='qualified-native-receiver-producer-replay', overall='failed-user-review',
    baseCommit='9327ca4a66d151ccf54ae75525373e506608febc', productionChanged=False, referencePixels=49384, acceptedMaximumByteError=1,
    execution=execution, source=read(capture / 'request.json'), native=native, comparison=comparison,
    playerAssets=read(out / 'player-reference-asset-inputs.json'), originalFour=prior,
    archive=dict(bytes=archive.stat().st_size, sha256=sha256(archive.read_bytes()).hexdigest(), files=len(fingerprints), contents=fingerprints))
target.mkdir(parents=True, exist_ok=True)
assert not (target / 'validation.zip').exists() and not (target / 'results.json').exists()
archive.rename(target / 'validation.zip')
(target / 'results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in result['archive'].items() if key != 'contents'}))
