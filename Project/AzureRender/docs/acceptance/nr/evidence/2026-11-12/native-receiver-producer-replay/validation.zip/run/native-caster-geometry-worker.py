from array import array
from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import sys
import traceback
import zlib

import renderdoc as rd

request=json.loads(Path(os.environ['AZURE_CASTER_GEOMETRY_REQUEST']).read_text(encoding='utf-8'))
out=Path(request['output'])
capture=rd.OpenCaptureFile()
controller=None
receipt={'status':'failed'}

def emit(name,raw,compress=False):
    data=zlib.compress(raw,6) if compress else raw
    (out/name).write_bytes(data)
    return dict(path=name,bytes=len(data),sha256=sha256(data).hexdigest(),rawBytes=len(raw),rawSha256=sha256(raw).hexdigest())

def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)

def crop(data):
    assert len(data)==2560*1440*4
    return b''.join(data[(y*2560+1140)*4:(y*2560+1430)*4] for y in range(1000,1310))

def stage(pipeline,event,shader_stage):
    reflection=pipeline.GetShaderReflection(shader_stage)
    if not reflection:return None
    prefix=f'{event}-{shader_stage}'
    text=controller.DisassembleShader(pipeline.GetGraphicsPipelineObject(),reflection,'').encode('utf-8')
    inputs={reflection.readOnlyResources[binding.access.index].fixedBindNumber:str(binding.descriptor.resource)
        for binding in pipeline.GetReadOnlyResources(shader_stage)}
    constants={}
    for index,block in enumerate(reflection.constantBlocks):
        binding=pipeline.GetConstantBlock(shader_stage,index,0).descriptor
        if binding.resource==rd.ResourceId.Null():continue
        data=bytes(controller.GetBufferData(binding.resource,binding.byteOffset,binding.byteSize))
        constants[block.fixedBindNumber]=dict(resource=str(binding.resource),offset=binding.byteOffset,
            **emit(f'{prefix}-b{block.fixedBindNumber}.bin',data))
    return dict(program=emit(prefix+'.dxbc',bytes(reflection.rawBytes)),assembly=emit(prefix+'.asm',text),
        inputs=inputs,constants=constants)


def receiver_input(pipeline, event, action):
    reflection = pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
    descriptions = {str(item.resourceId): item for item in controller.GetTextures()}
    resources = {}
    for binding in pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel):
        slot = reflection.readOnlyResources[binding.access.index].fixedBindNumber
        desc = binding.descriptor
        texture = descriptions.get(str(desc.resource))
        if not texture:
            continue
        entry = dict(resource=str(desc.resource), format=texture.format.Name(), extent=[texture.width, texture.height],
            mips=texture.mips, firstMip=desc.firstMip, firstSlice=desc.firstSlice)
        if event in (377, 422) and slot <= 2:
            pixels = bytes(controller.GetTextureData(desc.resource, rd.Subresource(desc.firstMip, desc.firstSlice, 0)))
            entry.update(baseBytes=len(pixels), baseSha256=sha256(pixels).hexdigest())
        resources[slot] = entry
    samplers = [dict(binding=item.access.index, lod=[item.sampler.minLOD,item.sampler.maxLOD],
        bias=item.sampler.mipBias, filter=[str(item.sampler.filter.minify),str(item.sampler.filter.magnify),str(item.sampler.filter.mip)])
        for item in pipeline.GetSamplers(rd.ShaderStage.Pixel)]
    return dict(indices=action.numIndices if action else None, instances=action.numInstances if action else None,
        textures=resources, samplers=samplers)


try:
    assert capture.OpenFile(request['capture'],'',None)==rd.ResultCode.Succeeded
    gpu,=[g for g in capture.GetAvailableGPUs() if g.vendor==rd.GPUVendor.nVidia and rd.GraphicsAPI.D3D11 in g.apis]
    options=rd.ReplayOptions()
    options.forceGPUVendor=gpu.vendor
    options.forceGPUDeviceID=gpu.deviceID
    status,controller=capture.OpenCapture(options,None)
    assert status==rd.ResultCode.Succeeded and controller
    properties=controller.GetAPIProperties()
    assert properties.vendor==gpu.vendor and properties.pipelineType==rd.GraphicsAPI.D3D11 and not properties.degraded
    actions={action.eventId:action for action in walk(controller.GetRootActions())}
    receipt.update(device=gpu.name,atlasDraws={},receiverDraws={},receiverDepth={})
    for event,indices in ((191,102882),(208,61935)):
        controller.SetFrameEvent(event,True)
        assert actions[event].numIndices==indices
        pipeline=controller.GetPipelineState()
        assert str(pipeline.GetDepthTarget().resource)=='ResourceId::158089'
        mesh=controller.GetPostVSData(0,0,rd.MeshDataStage.VSOut)
        assert mesh.numIndices==indices and mesh.indexByteStride in (2,4) and mesh.vertexByteStride>=16
        raw_indices=bytes(controller.GetBufferData(mesh.indexResourceId,mesh.indexByteOffset,mesh.numIndices*mesh.indexByteStride))
        values=struct.unpack('<'+('I' if mesh.indexByteStride==4 else 'H')*mesh.numIndices,raw_indices)
        vertex_count=max(values)+mesh.baseVertex+1
        assert min(values)+mesh.baseVertex>=0 and vertex_count>0
        vertices=bytes(controller.GetBufferData(mesh.vertexResourceId,mesh.vertexByteOffset,vertex_count*mesh.vertexByteStride))
        assert len(vertices)==vertex_count*mesh.vertexByteStride
        signature=pipeline.GetShaderReflection(rd.ShaderStage.Vertex).outputSignature
        receipt['atlasDraws'][str(event)]=dict(numIndices=indices,vertices=vertex_count,vertexStride=mesh.vertexByteStride,
            indexStride=mesh.indexByteStride,baseVertex=mesh.baseVertex,signature=[dict(name=item.semanticName,
                index=item.semanticIndex,count=item.compCount,system=str(item.systemValue)) for item in signature],
            vertexData=emit(f'{event}-vertices.zlib',vertices,True),indexData=emit(f'{event}-indices.zlib',raw_indices,True))
    controller.SetFrameEvent(422,True)
    depth=controller.GetPipelineState().GetDepthTarget().resource
    assert str(depth)=='ResourceId::141967'
    texture=next(t for t in controller.GetTextures() if t.resourceId==depth)
    assert (texture.width,texture.height,texture.format.Name())==(2560,1440,'D32S8_TYPELESS')
    usage=controller.GetUsage(depth)
    depth_events={item.eventId for item in usage if 275<=item.eventId<699 and item.usage==rd.ResourceUsage.DepthStencilTarget}
    checkpoints={275,296,310,328,345,363,377,391,404,421,422,440,460,478,541}
    receipt['depthResource']=str(depth)
    receipt['depthUsage']=[dict(event=item.eventId,usage=str(item.usage)) for item in usage if 275<=item.eventId<=699]
    for event in sorted(depth_events|checkpoints):
        controller.SetFrameEvent(event,True)
        raw=bytes(controller.GetTextureData(depth,rd.Subresource()))
        assert len(raw)==2560*1440*8
        words=array('I')
        assert sys.byteorder=='little' and words.itemsize==4
        words.frombytes(raw)
        depth_raw=words[::2].tobytes()
        receipt['receiverDepth'][str(event)]=dict(fullSha256=sha256(depth_raw).hexdigest(),
            crop=emit(f'{event}-depth.zlib',crop(depth_raw),True))
        if event in (296,328,345,377,404,422,440,460,478):
            pipeline=controller.GetPipelineState()
            receipt['receiverDraws'][str(event)]=dict(vertex=stage(pipeline,event,rd.ShaderStage.Vertex),
                pixel=stage(pipeline,event,rd.ShaderStage.Pixel), input=receiver_input(pipeline,event,actions.get(event)))
    controller.SetFrameEvent(699,True)
    pipeline=controller.GetPipelineState()
    shader=pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
    source=next(binding.descriptor.resource for binding in pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel)
        if shader.readOnlyResources[binding.access.index].fixedBindNumber==0)
    data=bytes(controller.GetTextureData(source,rd.Subresource()))
    assert sha256(data).hexdigest()==request['rasterDepthSha256']
    receipt['rasterDepthResource']=str(source)
    receipt['rasterDepthUsage']=[dict(event=item.eventId,usage=str(item.usage)) for item in controller.GetUsage(source)
        if 275<=item.eventId<=699]
    receipt['receiverDepth']['699']=dict(fullSha256=sha256(data).hexdigest(),crop=emit('699-depth.zlib',crop(data),True))
    receipt['debugMessages']=[str(message.description) for message in controller.GetDebugMessages()]
    receipt['status']='qualified'
except Exception:
    receipt['error']=traceback.format_exc()
finally:
    if controller:controller.Shutdown()
    capture.Shutdown()
    (out/'native-caster-geometry.json').write_text(json.dumps(receipt,indent=2)+'\n')
os._exit(0 if receipt['status']=='qualified' else 1)
