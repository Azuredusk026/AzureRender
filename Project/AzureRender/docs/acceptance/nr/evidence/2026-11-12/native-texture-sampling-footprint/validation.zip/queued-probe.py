from hashlib import file_digest
from pathlib import Path
import json
import subprocess
import sys


out=Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared

predecessor,=sys.argv[1:]
state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
assert state['state']=='released' and state['token']==predecessor,state
program=out/'footprint.exe'
shader=out/'footprint.hlsl'
inputs=out/'gradients.bin'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


command=[str(program),str(shader),str(inputs),str(out)]
fingerprints={path.name:digest(path) for path in (program,shader,inputs,out/'footprint.vert.dxbc',out/'footprint.frag.dxbc')}
(out/'program.json').write_text(json.dumps(dict(command=command,sha256=fingerprints),indent=2)+'\n')
lease=None
try:
    with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a',
            'quality-native-texture-sampling-footprint',out) as lease:
        (out/'lease-held.json').write_text(json.dumps(lease,indent=2)+'\n')
        execution=shared.maintenance.guarded_run(out.parents[1],out.name,command,45)
        (out/'probe-execution.json').write_text(json.dumps(execution,indent=2)+'\n')
        print(json.dumps(execution),flush=True)
        assert execution['status']=='exited' and execution['exitCode']==0
finally:
    if lease is not None:
        (out/'lease-released.json').write_text(json.dumps(lease,indent=2)+'\n')
assert all(digest(out/name)==sha for name,sha in fingerprints.items())
runtime={f'runtime.{stage}.dxbc':digest(out/f'runtime.{stage}.dxbc') for stage in ('vert','frag')}
assembly=(out/'runtime.frag.asm').read_text()
assert all(operation in assembly for operation in ('sample_b','sample_d','sample_l','deriv_rtx_coarse','deriv_rty_coarse'))
(out/'runtime-shaders.json').write_text(json.dumps(dict(sha256=runtime,
    preflightExact=all(runtime[f'runtime.{stage}.dxbc']==fingerprints[f'footprint.{stage}.dxbc']
        for stage in ('vert','frag'))),indent=2)+'\n')
subprocess.run([sys.executable,'-B',str(out/'analyze.py')],cwd=out,check=True)

