from hashlib import file_digest, sha256
from pathlib import Path
import json
import re
import zipfile


run=Path(__file__).resolve().parent
engine=run.parents[2]
baseline=engine/'docs/acceptance/nr/evidence/2026-11-12/reference-outline-projection/results.json'
prior=run.parent/'20261112-135432-reference-outline-projection-d784cf'
evidence=engine/'docs/acceptance/nr/evidence/2026-11-12/native-texture-sampling-footprint'


def read(name):
    return json.loads((run/name).read_text())


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


outline=json.loads(baseline.read_text())
assert outline['status']=='qualified-reference-outline-projection'
report=read('sampling-footprint.json')
assert report['status']=='qualified' and report['positionsPerAdapter']==411200
assert read('analyzer-self-check.json')['status']=='passed'
assert all(item['covered']==report['positionsPerAdapter'] for item in report['devices'].values())
frozen=read('frozen-shape-control.json')
assert frozen['samples']==17017 and frozen['candidateConstants']==[.34375,.6875]
exact=next(test for test in frozen['tests'] if test['vertices']=='nearest-8' and test['row']==test['col']==0
    and test['footprint']=='cardinal-diagonal')
assert (exact['agreement']['nvidia'],exact['nvidiaOverOneVsFrozen'],exact['intelOverOneVsFrozen'])==(17012,5,11)
execution=read('probe-execution.json')
assert execution['status']=='exited' and execution['exitCode']==0
first=run/'first-attempt'
first_execution=json.loads((first/'probe-execution.json').read_text())
assert first_execution['status']=='exited' and first_execution['exitCode']==1
assert 'Ambiguous physical adapter' in (first/'process.log').read_text()
lease=read('lease-released.json')
assert lease['state']=='released' and lease['token']==read('lease-held.json')['token']
for name,item in report['devices'].items():
    assert digest(run/f'{name}-values.bin')==item['valuesSha256']
    assert digest(run/f'{name}-derivatives.bin')==item['derivativesSha256']
assert digest(first/'nvidia-values.bin')==report['devices']['nvidia']['valuesSha256']
assert digest(first/'nvidia-derivatives.bin')==report['devices']['nvidia']['derivativesSha256']

diagnostics=(run/'process.log').read_text(errors='replace')
adapters={}
for name,vendor in (('nvidia',4318),('intel',32902),('intel-alt',32902)):
    pattern=rf'{name} vendor={vendor} device=(\d+) debug=([01]) luid=(-?\d+:\d+) adapter=([^\r\n]+)'
    match=re.search(pattern,diagnostics)
    assert match,diagnostics
    adapters[name]=dict(deviceId=int(match[1]),debugLayer=match[2]=='1',luid=match[3],adapter=match[4])
assert 'HRESULT=' not in diagnostics
assert adapters['nvidia']['deviceId']==10464 and adapters['intel']['deviceId']==adapters['intel-alt']['deviceId']==42888
for path,labels in (('vk-nv-vk64-luid.log',('nvidia',)),('vk-igvk64-luid.log',('intel','intel-alt'))):
    expected={adapters[label]['luid'] for label in labels}
    assert set(re.findall(r'valid=1 luid=(-?\d+:\d+)',(run/path).read_text()))==expected

unchanged={}
for config,slug in (('release','20261110-030251-hair-main-chroma-public-9e799c'),
                    ('debug','20261110-031856-hair-main-chroma-debug-668bf2')):
    runtime=run.parent/slug/config
    candidate=outline[config]
    assert digest(runtime/'AzurePlayer.exe')==candidate['playerSha256']
    original=json.loads((prior/(config+'-baseline-shaders.json')).read_text())
    for key,change in candidate['changedShaders'].items():
        original[key]=change['after']
    assert len(original)==895 and {item.name:digest(item) for item in (runtime/'shaders').glob('*.spv')}==original
    unchanged[config]=dict(playerSha256=candidate['playerSha256'],shaderCount=len(original))

evidence.mkdir(parents=True,exist_ok=False)
archive_path=evidence/'validation.zip'
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(run.iterdir()):
        if path.is_file() and path.suffix in ('.py','.cpp','.hlsl','.json','.exe','.log','.bin','.dxbc','.asm'):
            archive.write(path,path.name)
    for path in sorted(first.iterdir()):
        if path.suffix in ('.json','.log','.exe','.dxbc','.asm'):
            archive.write(path,path.relative_to(run).as_posix())
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    members=len(archive.namelist())
raw=archive_path.read_bytes()
assert len(raw)<8*1024**2
report.update(execution=execution,originalExecution=first_execution,nvidiaRepeatExact=True,
    lease=lease,adapters=adapters,unchangedRuntime=unchanged,
    runtimeShaders=read('runtime-shaders.json'),scope=read('task-card.json'),
    frozenControl=dict(samples=frozen['samples'],primitiveArchiveSha256=frozen['primitiveArchiveSha256'],case=exact),
    archive=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw),members=members))
(evidence/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['archive']))

