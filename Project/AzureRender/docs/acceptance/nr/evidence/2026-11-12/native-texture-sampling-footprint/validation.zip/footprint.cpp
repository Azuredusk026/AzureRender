#define NOMINMAX
#include <d3d11.h>
#include <d3d11sdklayers.h>
#include <d3dcompiler.h>
#include <dxgi1_2.h>
#include <wrl/client.h>

#include <array>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using Microsoft::WRL::ComPtr;
using Float4 = std::array<float, 4>;
using Path = std::filesystem::path;

namespace {
constexpr unsigned tileSize = 4;
constexpr unsigned textureExtent = 2048;
constexpr unsigned mipCount = 12;
constexpr DXGI_FORMAT resultFormat = DXGI_FORMAT_R32G32B32A32_FLOAT;

struct Inputs {
    std::uint32_t columns, rows;
    std::vector<Float4> gradients;
};

struct Targets {
    std::array<ComPtr<ID3D11Texture2D>, 2> image;
    std::array<ComPtr<ID3D11RenderTargetView>, 2> view;
    ComPtr<ID3D11Texture2D> readback;
};

struct Adapter {
    ComPtr<IDXGIAdapter1> device;
    DXGI_ADAPTER_DESC1 description{};
};

void check(HRESULT result, const char* operation) {
    if (SUCCEEDED(result)) return;
    std::cerr << operation << " HRESULT=0x" << std::hex << static_cast<unsigned>(result) << std::dec << '\n';
    throw std::runtime_error(operation);
}

std::vector<Adapter> enumerateAdapters() {
    ComPtr<IDXGIFactory1> factory;
    check(CreateDXGIFactory1(IID_PPV_ARGS(&factory)), "Create DXGI factory");
    std::vector<Adapter> adapters;
    for (unsigned index = 0; ; ++index) {
        Adapter adapter;
        const auto result = factory->EnumAdapters1(index, &adapter.device);
        if (result == DXGI_ERROR_NOT_FOUND) break;
        check(result, "Enumerate DXGI adapter");
        check(adapter.device->GetDesc1(&adapter.description), "Read DXGI adapter");
        adapters.push_back(std::move(adapter));
    }
    return adapters;
}

Inputs readInputs(const Path& path) {
    std::ifstream stream(path, std::ios::binary);
    Inputs input{};
    stream.read(reinterpret_cast<char*>(&input.columns), sizeof(input.columns));
    stream.read(reinterpret_cast<char*>(&input.rows), sizeof(input.rows));
    if (!stream || !input.columns || input.columns > 1024 || !input.rows || input.rows > 256)
        throw std::runtime_error("Invalid gradient grid size");
    input.gradients.resize(input.columns * input.rows);
    stream.read(reinterpret_cast<char*>(input.gradients.data()), input.gradients.size() * sizeof(Float4));
    if (!stream || stream.peek() != EOF) throw std::runtime_error("Invalid gradient grid length");
    return input;
}

ComPtr<ID3DBlob> compile(const Path& path, const char* entry, const char* profile) {
    ComPtr<ID3DBlob> program, diagnostics;
    const auto result = D3DCompileFromFile(path.c_str(), nullptr, nullptr, entry, profile,
        D3DCOMPILE_ENABLE_STRICTNESS | D3DCOMPILE_WARNINGS_ARE_ERRORS | D3DCOMPILE_OPTIMIZATION_LEVEL3,
        0, &program, &diagnostics);
    if (diagnostics) std::cerr << static_cast<const char*>(diagnostics->GetBufferPointer()) << '\n';
    check(result, entry);
    return program;
}

void saveProgram(ID3DBlob* program, const Path& path) {
    check(D3DWriteBlobToFile(program, path.c_str(), TRUE), "Save executed shader bytecode");
    ComPtr<ID3DBlob> assembly;
    check(D3DDisassemble(program->GetBufferPointer(), program->GetBufferSize(), 0, nullptr, &assembly),
        "Disassemble executed shader bytecode");
    auto text = path;
    text.replace_extension(L"asm");
    check(D3DWriteBlobToFile(assembly.Get(), text.c_str(), TRUE), "Save executed shader assembly");
}

ComPtr<ID3D11ShaderResourceView> gradientView(ID3D11Device* device, const Inputs& input) {
    D3D11_BUFFER_DESC description{};
    description.ByteWidth = static_cast<UINT>(input.gradients.size() * sizeof(Float4));
    description.Usage = D3D11_USAGE_IMMUTABLE;
    description.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    description.MiscFlags = D3D11_RESOURCE_MISC_BUFFER_STRUCTURED;
    description.StructureByteStride = sizeof(Float4);
    D3D11_SUBRESOURCE_DATA data{input.gradients.data(), 0, 0};
    ComPtr<ID3D11Buffer> buffer;
    check(device->CreateBuffer(&description, &data, &buffer), "Create gradient buffer");
    D3D11_SHADER_RESOURCE_VIEW_DESC viewDescription{};
    viewDescription.Format = DXGI_FORMAT_UNKNOWN;
    viewDescription.ViewDimension = D3D11_SRV_DIMENSION_BUFFER;
    viewDescription.Buffer.NumElements = static_cast<UINT>(input.gradients.size());
    ComPtr<ID3D11ShaderResourceView> view;
    check(device->CreateShaderResourceView(buffer.Get(), &viewDescription, &view), "Create gradient view");
    return view;
}

ComPtr<ID3D11ShaderResourceView> mipView(ID3D11Device* device) {
    D3D11_TEXTURE2D_DESC description{};
    description.Width = description.Height = textureExtent;
    description.MipLevels = mipCount;
    description.ArraySize = 1;
    description.Format = DXGI_FORMAT_R8_UNORM;
    description.SampleDesc.Count = 1;
    description.Usage = D3D11_USAGE_IMMUTABLE;
    description.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    std::array<std::vector<std::uint8_t>, mipCount> pixels;
    std::array<D3D11_SUBRESOURCE_DATA, mipCount> initial{};
    for (unsigned level = 0; level < mipCount; ++level) {
        const auto extent = textureExtent >> level;
        pixels[level].assign(extent * extent, static_cast<std::uint8_t>(16 * (level + 1)));
        initial[level] = {pixels[level].data(), extent, 0};
    }
    ComPtr<ID3D11Texture2D> texture;
    check(device->CreateTexture2D(&description, initial.data(), &texture), "Create mip-coded texture");
    ComPtr<ID3D11ShaderResourceView> view;
    check(device->CreateShaderResourceView(texture.Get(), nullptr, &view), "Create mip-coded texture view");
    return view;
}

Targets makeTargets(ID3D11Device* device, unsigned width, unsigned height) {
    D3D11_TEXTURE2D_DESC description{};
    description.Width = width;
    description.Height = height;
    description.MipLevels = description.ArraySize = description.SampleDesc.Count = 1;
    description.Format = resultFormat;
    description.Usage = D3D11_USAGE_DEFAULT;
    description.BindFlags = D3D11_BIND_RENDER_TARGET;
    Targets result;
    for (unsigned i = 0; i < result.image.size(); ++i) {
        check(device->CreateTexture2D(&description, nullptr, &result.image[i]), "Create output texture");
        check(device->CreateRenderTargetView(result.image[i].Get(), nullptr, &result.view[i]), "Create render target");
    }
    description.Usage = D3D11_USAGE_STAGING;
    description.BindFlags = 0;
    description.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    check(device->CreateTexture2D(&description, nullptr, &result.readback), "Create staging texture");
    return result;
}

void save(ID3D11DeviceContext* context, const Targets& targets, unsigned index,
          unsigned width, unsigned height, const Path& path) {
    context->CopyResource(targets.readback.Get(), targets.image[index].Get());
    D3D11_MAPPED_SUBRESOURCE mapped{};
    check(context->Map(targets.readback.Get(), 0, D3D11_MAP_READ, 0, &mapped), "Map output texture");
    std::ofstream stream(path, std::ios::binary);
    const auto* first = static_cast<const char*>(mapped.pData);
    const auto rowBytes = static_cast<std::streamsize>(width * sizeof(Float4));
    for (unsigned y = 0; y < height; ++y) stream.write(first + y * mapped.RowPitch, rowBytes);
    context->Unmap(targets.readback.Get(), 0);
    if (!stream) throw std::runtime_error("Cannot save mapped output");
}

void diagnostics(ID3D11Device* device, bool debug) {
    check(device->GetDeviceRemovedReason(), "D3D11 device status");
    if (!debug) return;
    ComPtr<ID3D11InfoQueue> queue;
    check(device->QueryInterface(IID_PPV_ARGS(&queue)), "Get D3D11 validation queue");
    const auto count = queue->GetNumStoredMessagesAllowedByRetrievalFilter();
    for (UINT64 index = 0; index < count; ++index) {
        SIZE_T bytes = 0;
        check(queue->GetMessage(index, nullptr, &bytes), "Get D3D11 validation message size");
        std::vector<char> storage(bytes);
        auto* message = reinterpret_cast<D3D11_MESSAGE*>(storage.data());
        check(queue->GetMessage(index, message, &bytes), "Read D3D11 validation message");
        if (message->Severity <= D3D11_MESSAGE_SEVERITY_WARNING) {
            std::cerr << message->pDescription << '\n';
            throw std::runtime_error("D3D11 validation warning");
        }
    }
}

void render(IDXGIAdapter1* adapter, const Inputs& inputs, ID3DBlob* vertex, ID3DBlob* pixel, const Path& prefix) {
    DXGI_ADAPTER_DESC1 adapterDescription{};
    check(adapter->GetDesc1(&adapterDescription), "Read adapter descriptor");
    ComPtr<ID3D11Device> device;
    ComPtr<ID3D11DeviceContext> context;
    constexpr D3D_FEATURE_LEVEL supported[] = {D3D_FEATURE_LEVEL_11_0};
    bool debug = true;
    auto result = D3D11CreateDevice(adapter, D3D_DRIVER_TYPE_UNKNOWN, nullptr, D3D11_CREATE_DEVICE_DEBUG,
        supported, 1, D3D11_SDK_VERSION, &device, nullptr, &context);
    if (result == DXGI_ERROR_SDK_COMPONENT_MISSING) {
        debug = false;
        result = D3D11CreateDevice(adapter, D3D_DRIVER_TYPE_UNKNOWN, nullptr, 0,
            supported, 1, D3D11_SDK_VERSION, &device, nullptr, &context);
    }
    check(result, "Create D3D11 device");
    std::wcout << prefix.filename().wstring() << L" vendor=" << adapterDescription.VendorId
        << L" device=" << adapterDescription.DeviceId << L" debug=" << debug
        << L" luid=" << adapterDescription.AdapterLuid.HighPart << L":" << adapterDescription.AdapterLuid.LowPart
        << L" adapter=" << adapterDescription.Description << L'\n';

    const auto width = tileSize * inputs.columns;
    const auto height = tileSize * inputs.rows;
    const auto gradients = gradientView(device.Get(), inputs);
    const auto mips = mipView(device.Get());
    const auto targets = makeTargets(device.Get(), width, height);
    ComPtr<ID3D11VertexShader> vs;
    ComPtr<ID3D11PixelShader> ps;
    check(device->CreateVertexShader(vertex->GetBufferPointer(), vertex->GetBufferSize(), nullptr, &vs), "Create vertex shader");
    check(device->CreatePixelShader(pixel->GetBufferPointer(), pixel->GetBufferSize(), nullptr, &ps), "Create pixel shader");

    const struct {
        std::uint32_t columns, rows;
        float width, height;
    } rasterSize{inputs.columns, inputs.rows, static_cast<float>(width), static_cast<float>(height)};
    D3D11_BUFFER_DESC constantsDescription{};
    constantsDescription.ByteWidth = sizeof(rasterSize);
    constantsDescription.Usage = D3D11_USAGE_IMMUTABLE;
    constantsDescription.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    D3D11_SUBRESOURCE_DATA constantsData{&rasterSize, 0, 0};
    ComPtr<ID3D11Buffer> constants;
    check(device->CreateBuffer(&constantsDescription, &constantsData, &constants), "Create raster extent buffer");

    D3D11_SAMPLER_DESC samplerDescription{};
    samplerDescription.Filter = D3D11_FILTER_MIN_MAG_LINEAR_MIP_POINT;
    samplerDescription.AddressU = samplerDescription.AddressV = samplerDescription.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
    samplerDescription.MaxAnisotropy = 1;
    samplerDescription.ComparisonFunc = D3D11_COMPARISON_NEVER;
    samplerDescription.MaxLOD = 1000;
    ComPtr<ID3D11SamplerState> sampler;
    check(device->CreateSamplerState(&samplerDescription, &sampler), "Create native point-mip sampler");

    D3D11_RASTERIZER_DESC rasterDescription{};
    rasterDescription.FillMode = D3D11_FILL_SOLID;
    rasterDescription.CullMode = D3D11_CULL_NONE;
    rasterDescription.DepthClipEnable = TRUE;
    ComPtr<ID3D11RasterizerState> raster;
    check(device->CreateRasterizerState(&rasterDescription, &raster), "Create raster state");
    const D3D11_VIEWPORT viewport{0, 0, static_cast<float>(width), static_cast<float>(height), 0, 1};
    context->RSSetState(raster.Get());
    context->RSSetViewports(1, &viewport);
    context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    context->VSSetShader(vs.Get(), nullptr, 0);
    context->PSSetShader(ps.Get(), nullptr, 0);
    ID3D11Buffer* constant = constants.Get();
    context->VSSetConstantBuffers(0, 1, &constant);
    ID3D11ShaderResourceView* gradient = gradients.Get();
    ID3D11ShaderResourceView* texture = mips.Get();
    ID3D11SamplerState* pointMip = sampler.Get();
    context->VSSetShaderResources(0, 1, &gradient);
    context->PSSetShaderResources(1, 1, &texture);
    context->PSSetSamplers(0, 1, &pointMip);
    ID3D11RenderTargetView* outputs[] = {targets.view[0].Get(), targets.view[1].Get()};
    const float clear[] = {0, 0, 0, 0};
    for (auto* view : outputs) context->ClearRenderTargetView(view, clear);
    context->OMSetRenderTargets(2, outputs, nullptr);
    context->DrawInstanced(6, static_cast<UINT>(inputs.gradients.size()), 0, 0);
    context->OMSetRenderTargets(0, nullptr, nullptr);
    save(context.Get(), targets, 0, width, height, Path(prefix.wstring() + L"-values.bin"));
    save(context.Get(), targets, 1, width, height, Path(prefix.wstring() + L"-derivatives.bin"));
    context->ClearState();
    context->Flush();
    diagnostics(device.Get(), debug);
}
}

int wmain(int argc, wchar_t** argv) try {
    const auto adapters = enumerateAdapters();
    if (argc == 2 && std::wstring(argv[1]) == L"--list-adapters") {
        for (const auto& adapter : adapters) {
            const auto& id = adapter.description;
            std::wcout << L"vendor=" << id.VendorId << L" device=" << id.DeviceId << L" flags=" << id.Flags
                << L" luid=" << id.AdapterLuid.HighPart << L":" << id.AdapterLuid.LowPart << L" adapter=" << id.Description << L'\n';
        }
        return 0;
    }
    if (argc != 4) throw std::runtime_error("Expected shader, gradient grid and output directory");
    const auto vertex = compile(argv[1], "vertexMain", "vs_5_0");
    const auto pixel = compile(argv[1], "pixelMain", "ps_5_0");
    const auto inputs = readInputs(argv[2]);
    const Path output = argv[3];
    saveProgram(vertex.Get(), output / L"runtime.vert.dxbc");
    saveProgram(pixel.Get(), output / L"runtime.frag.dxbc");
    const struct AdapterTarget {unsigned vendor, device, count; const wchar_t* label;} targets[] = {
        {0x10de, 0x28e0, 1, L"nvidia"}, {0x8086, 0xa788, 2, L"intel"}
    };
    for (const auto& target : targets) {
        std::vector<const Adapter*> found;
        for (const auto& adapter : adapters) {
            const auto& id = adapter.description;
            if (id.VendorId == target.vendor && id.DeviceId == target.device && id.Flags == DXGI_ADAPTER_FLAG_NONE)
                found.push_back(&adapter);
        }
        if (found.size() != target.count) throw std::runtime_error("Unexpected number of DXGI identities for selected PCI device");
        for (std::size_t index = 0; index < found.size(); ++index) {
            const std::wstring label = std::wstring(target.label) + (index == 0 ? L"" : L"-alt");
            render(found[index]->device.Get(), inputs, vertex.Get(), pixel.Get(), output / label);
        }
    }
    return 0;
} catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
}

