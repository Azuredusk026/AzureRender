#include <vulkan/vulkan.h>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <vector>

int main() {
    VkApplicationInfo app{};
    app.sType=VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app.apiVersion=VK_API_VERSION_1_1;
    VkInstanceCreateInfo description{};
    description.sType=VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    description.pApplicationInfo=&app;
    VkInstance instance{};
    if(vkCreateInstance(&description,nullptr,&instance)!=VK_SUCCESS)return 1;
    std::uint32_t count=0;
    if(vkEnumeratePhysicalDevices(instance,&count,nullptr)!=VK_SUCCESS||count==0){
        vkDestroyInstance(instance,nullptr);
        return 2;
    }
    std::vector<VkPhysicalDevice> devices(count);
    if(vkEnumeratePhysicalDevices(instance,&count,devices.data())!=VK_SUCCESS){
        vkDestroyInstance(instance,nullptr);
        return 3;
    }
    for(auto device:devices){
        VkPhysicalDeviceIDProperties identity{};
        identity.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ID_PROPERTIES;
        VkPhysicalDeviceProperties2 info{};
        info.sType=VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2;
        info.pNext=&identity;
        vkGetPhysicalDeviceProperties2(device,&info);
        std::uint32_t low=0;
        std::int32_t high=0;
        std::memcpy(&low,identity.deviceLUID,4);
        std::memcpy(&high,identity.deviceLUID+4,4);
        std::cout<<"vendor="<<info.properties.vendorID<<" device="<<info.properties.deviceID
            <<" valid="<<identity.deviceLUIDValid<<" luid="<<high<<':'<<low<<" name="<<info.properties.deviceName<<'\n';
    }
    vkDestroyInstance(instance,nullptr);
}

