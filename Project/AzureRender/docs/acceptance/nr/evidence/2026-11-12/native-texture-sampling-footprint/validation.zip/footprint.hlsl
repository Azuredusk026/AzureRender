StructuredBuffer<float4> inputGradients : register(t0);
Texture2D<float4> mipCodes : register(t1);
SamplerState pointMip : register(s0);

cbuffer RasterExtent : register(b0) {
    uint2 tiles;
    float2 extent;
};

struct Vertex {
    float4 position : SV_Position;
    nointerpolation float4 gradients : TEXCOORD0;
    nointerpolation float2 origin : TEXCOORD1;
};

Vertex vertexMain(uint vertex : SV_VertexID, uint instance : SV_InstanceID) {
    static const float2 corners[6] = {
        float2(0, 0), float2(1, 0), float2(0, 1),
        float2(0, 1), float2(1, 0), float2(1, 1)
    };
    Vertex result;
    result.origin = 4 * float2(instance % tiles.x, instance / tiles.x);
    float2 pixel = result.origin + 4 * corners[vertex];
    result.position = float4(pixel / extent * float2(2, -2) + float2(-1, 1), .5, 1);
    result.gradients = inputGradients[instance];
    return result;
}

struct Samples {
    float4 values : SV_Target0;
    float4 derivatives : SV_Target1;
};

Samples pixelMain(Vertex input) {
    const float2 position = input.position.xy - input.origin - .5;
    const float2 dx = input.gradients.xy / 2048;
    const float2 dy = input.gradients.zw / 2048;
    precise float2 uv = dx * position.x + dy * position.y;
    const float2 measuredX = ddx_coarse(uv);
    const float2 measuredY = ddy_coarse(uv);

    Samples result;
    result.values = float4(
        mipCodes.SampleBias(pointMip, uv, -1).r,
        mipCodes.SampleGrad(pointMip, uv, measuredX * .5, measuredY * .5).r,
        mipCodes.SampleLevel(pointMip, uv, 0).r,
        mipCodes.SampleLevel(pointMip, uv, 11).r);
    result.derivatives = float4(measuredX, measuredY) * 2048;
    return result;
}

