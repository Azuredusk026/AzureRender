from hashlib import sha256
from pathlib import Path
import json
import io
import subprocess
import zipfile

import numpy as np


out = Path(__file__).resolve().parent
engine = out.parents[2]
normal = out.parent / '20261111-232828-scene-reference-normal-60ddfa'
material = out.parent / '20261112-044926-material-reference-object-visibility-344def'
experiment = out.parent / '20261112-053111-intel-reference-visibility-sources-5238e2/native-normal-explicit-mips'
evidence = json.loads((experiment / 'explicit-normal-mips.json').read_text())
assert evidence['status'] == 'qualified'
vertex_info = json.loads((normal / 'normal-vertex-comparison.json').read_text())
vertex_file = Path(vertex_info['nativePath'])
raw = vertex_file.read_bytes()
assert sha256(raw).hexdigest() == vertex_info['nativeSha256']
vertices = np.frombuffer(raw, '<f4').reshape(-1, 23).astype('f8')
indices = np.fromfile(vertex_file.with_name('422-index.bin'), '<u2').reshape(-1, 3)
primitive_evidence='Project/AzureRender/docs/acceptance/nr/evidence/2026-11-10/raster-primitive-depth-model'
source_commit='3a2f491ff5a4975944e2b4cc36c94ec48034d03c'
primitive_archive=subprocess.check_output(['git','show',f'{source_commit}:{primitive_evidence}/validation.zip'],cwd=engine)
primitive_manifest=json.loads(subprocess.check_output(['git','show',f'{source_commit}:{primitive_evidence}/results.json'],cwd=engine))
assert sha256(primitive_archive).hexdigest()==primitive_manifest['archive']['sha256']
with zipfile.ZipFile(io.BytesIO(primitive_archive)) as archive:
    model_xy = np.frombuffer(archive.read('inputs/queries.bin'), '<f4').reshape(-1, 4)[:, :2].astype('i4')
    primitive = np.frombuffer(archive.read('run/nvidia-primitive-selected.bin'), '<f4').astype('i4')
query = normal / 'nvidia-normal-visibility-control-reference-frame/queries.bin'
xy = np.fromfile(query, '<f4').reshape(-1, 4)[:, :2].astype('i4')
assert len(xy) == len(model_xy) == len(primitive) == 17017 and primitive.min() >= 0 and primitive.max() < len(indices)
linear_id = lambda points: points[:, 1] * 2560 + points[:, 0]
order = np.argsort(linear_id(model_xy))
places = np.searchsorted(linear_id(model_xy)[order], linear_id(xy))
assert np.array_equal(model_xy[order[places]], xy)
triangles = vertices[indices[primitive[order[places]]]]
clip = triangles[:, :, :4]
screen = clip[:, :, :2] / clip[:, :, 3:4] * [1280, -720] + [1280, 720]
inv_w = 1 / clip[:, :, 3]
tex = triangles[:, :, 4:6]
quad = (xy & ~1) + .5
rows = np.arange(len(xy))


def interpolate(points, raster):
    first, second = raster[:, 1] - raster[:, 0], raster[:, 2] - raster[:, 0]
    relative = points - raster[:, 0]
    determinant = first[:, 0] * second[:, 1] - first[:, 1] * second[:, 0]
    assert np.all(np.abs(determinant) > 1.e-15)
    u = (relative[:, 0] * second[:, 1] - relative[:, 1] * second[:, 0]) / determinant
    v = (first[:, 0] * relative[:, 1] - first[:, 1] * relative[:, 0]) / determinant
    weights = np.stack((1 - u - v, u, v), axis=1) * inv_w
    weights /= weights.sum(axis=1, keepdims=True)
    return np.sum(weights[:, :, None] * tex, axis=1)


def projected_max(vector):
    absolute = np.abs(vector)
    return absolute.max(axis=1) + (11/32) * absolute.min(axis=1)


def codes(a, b):
    return np.maximum(*[np.abs(((a >> bit) & 1023).astype('i4') - ((b >> bit) & 1023).astype('i4')) for bit in (0, 10)])


implicit = {name: np.fromfile(experiment / (name + '-implicit.bin'), '<u4') for name in ('nvidia', 'intel')}
mips = {name: np.stack([np.fromfile(experiment / f'{name}-mip-{level:02d}.bin', '<u4') for level in range(12)])
    for name in implicit}
matches = {name: mips[name] == value for name, value in implicit.items()}
assert all(np.all(valid.any(axis=0)) for valid in matches.values())
unique = {name: valid.sum(axis=0) == 1 for name, valid in matches.items()}
both = unique['nvidia'] & unique['intel']
bad = codes(implicit['nvidia'], implicit['intel']) > 1
assert bad.sum() == 886 and (bad & both).sum() == 848
color_points = json.loads((material / 'release-intel-color-residual.json').read_text())['points']
color_keys = np.array([(1439 - item['pixel'][1]) * 2560 + item['pixel'][0] for item in color_points])
color_bad = np.isin(linear_id(xy), color_keys)
assert color_bad.sum() == 580
nearest_intel_error = codes(mips['intel'], implicit['nvidia'][None, :])
observed_nvidia_mask = matches['nvidia']
feasible = np.where(observed_nvidia_mask, nearest_intel_error, 1024).min(axis=0)
reference_choice = observed_nvidia_mask.argmax(axis=0)
fixed_nvidia_choice_error = codes(mips['intel'][reference_choice, rows], implicit['nvidia'])
sample = evidence['devices']['nvidia']['sample']
assert sample['mips'] == 12 and sample['filter'][2] == 'FilterMode.Point'
size = np.array(sample['extent'])
bias = sample['sampleBias'] + sample['samplerBias']
cases = []
for position_name, raster in (('float', screen), ('nearest-8', np.rint(screen * 256) / 256), ('floor-8', np.floor(screen * 256) / 256)):
    uv = [interpolate(quad + step, raster) for step in ((0, 0), (1, 0), (0, 1), (1, 1))]
    horizontal = [(uv[1] - uv[0]) * size, (uv[3] - uv[2]) * size]
    vertical = [(uv[2] - uv[0]) * size, (uv[3] - uv[1]) * size]
    horizontal.append(np.where((xy[:, 1] % 2)[:, None] == 0, horizontal[0], horizontal[1]))
    vertical.append(np.where((xy[:, 0] % 2)[:, None] == 0, vertical[0], vertical[1]))
    for row, dx in enumerate(horizontal):
        for col, dy in enumerate(vertical):
            dx2, dy2 = np.sum(dx * dx, axis=1), np.sum(dy * dy, axis=1)
            cross = np.sum(dx * dy, axis=1)
            cardinal = np.maximum(projected_max(dx), projected_max(dy))
            diagonal = (11/16) * np.maximum(projected_max(dx + dy), projected_max(dx - dy))
            metrics = {
                'cardinal-diagonal': np.square(np.maximum(cardinal, diagonal)),
                'max-axis': np.maximum(dx2, dy2),
                'ellipse-major': (dx2 + dy2 + np.sqrt((dx2 - dy2) ** 2 + 4 * cross ** 2)) * .5,
                'max-component': np.maximum(np.max(dx * dx, axis=1), np.max(dy * dy, axis=1)),
                'axis-bounds': np.sum(np.maximum(dx * dx, dy * dy), axis=1),
            }
            for method, metric in metrics.items():
                lod = .5 * np.log2(np.maximum(metric, 1.e-20)) + bias
                levels = np.clip(np.floor(lod + .5), 0, 11).astype('i4')
                actual_level = {name: table[levels, rows] for name, table in matches.items()}
                intel_error = codes(mips['intel'][levels, rows], implicit['nvidia'])
                nvidia_error = codes(mips['nvidia'][levels, rows], implicit['nvidia'])
                cases.append(dict(vertices=position_name, row=row, col=col, footprint=method,
                    agreement={name: int(level.sum()) for name, level in actual_level.items()},
                    agreementAmongUniqueDifferences={name: int((level & bad & both).sum()) for name, level in actual_level.items()},
                    intelOverOneVsFrozen=int((intel_error > 1).sum()), nvidiaOverOneVsFrozen=int((nvidia_error > 1).sum()),
                    intelOverOneInColorMask=int(((intel_error > 1) & color_bad).sum())))
best = sorted(cases, key=lambda entry: (entry['nvidiaOverOneVsFrozen'], entry['intelOverOneVsFrozen']))
report = dict(samples=len(xy), sourceCommit=source_commit, primitiveArchiveSha256=sha256(primitive_archive).hexdigest(),
    candidateConstants=[11/32,11/16], colorOverlapWithNativeNormalDifference=int((color_bad & bad).sum()),
    colorWithBothUniqueMipAndNativeNormalDifference=int((color_bad & bad & both).sum()),
    intelAtKnownNvidiaLevel=dict(availableOverOne=int((feasible > 1).sum()), fixedChoiceOverOne=int((fixed_nvidia_choice_error > 1).sum())),
    tests=best)
(out / 'frozen-shape-control.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({**report, 'tests': best[:6]}))

