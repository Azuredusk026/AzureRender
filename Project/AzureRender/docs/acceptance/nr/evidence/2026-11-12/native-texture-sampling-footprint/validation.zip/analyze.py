from hashlib import sha256
from pathlib import Path
import json
import struct

import numpy as np


out = Path(__file__).resolve().parent
inputs = json.loads((out/'inputs.json').read_text())
raw = (out/'gradients.bin').read_bytes()
assert len(raw)==inputs['bytes'] and sha256(raw).hexdigest()==inputs['sha256']
columns,rows=struct.unpack_from('<II',raw)
tile=inputs['tile']
assert (columns,rows,tile)==(257,100,4)
authored=np.frombuffer(raw,dtype='<f4',offset=8).reshape(rows,columns,4)
adapter_ids={'nvidia':0x10de,'intel':0x8086,'intel-alt':0x8086}


def read(adapter,name):
    raw=(out/f'{adapter}-{name}.bin').read_bytes()
    assert len(raw)==rows*columns*tile*tile*16
    data=np.frombuffer(raw,'<f4').reshape(rows,tile,columns,tile,4).transpose(0,2,1,3,4)
    assert np.isfinite(data).all()
    return data,sha256(raw).hexdigest()


def crossings(level):
    assert np.all(level[:,0]<4) and np.all(level[:,-1]>=4)
    assert np.all(np.diff(level,axis=1)>=0)
    change=np.diff((level>=4).astype('i4'),axis=1)
    assert np.all(change.sum(axis=1)==1)
    return np.argmax(change,axis=1)+1


def model_levels(measured):
    dx,dy=measured[:,:,:2],measured[:,:,2:]
    x_squared=np.square(dx).sum(axis=-1)
    y_squared=np.square(dy).sum(axis=-1)
    dot=(dx*dy).sum(axis=-1)
    max_axis=np.maximum(x_squared,y_squared)
    ellipse=(x_squared+y_squared+np.sqrt((x_squared-y_squared)**2+4*dot*dot))*.5
    component=np.maximum(np.max(np.square(dx),axis=-1),np.max(np.square(dy),axis=-1))
    axis_bounds=np.maximum(np.square(dx),np.square(dy)).sum(axis=-1)
    def approximate_norm(vector):
        absolute=np.abs(vector)
        return absolute.max(axis=-1)+(11/32)*absolute.min(axis=-1)

    cardinal=np.maximum(approximate_norm(dx),approximate_norm(dy))
    diagonal=(11/16)*np.maximum(approximate_norm(dx+dy),approximate_norm(dx-dy))
    candidate=np.maximum(cardinal,diagonal)
    return dict(maxAxis=max_axis,ellipse=ellipse,maxComponent=component,axisBounds=axis_bounds,
        cardinalDiagonal=np.square(candidate))


def classify(measured,levels,observed):
    derivative=np.linalg.norm(measured[:,:,:2],axis=-1)
    lengths=np.log2(derivative)
    indices=np.arange(rows)
    estimate=(lengths[indices,observed-1]+lengths[indices,observed])*.5
    magnitudes=model_levels(measured)
    reports={}
    for name,scale in magnitudes.items():
        predictions=np.floor(.5*np.log2(scale)-.5).astype('i4')
        predict_interval=4.5-np.log2(np.sqrt(scale[:,0])/derivative[:,0])
        gap=np.maximum.reduce((lengths[indices,observed-1]-predict_interval,
            predict_interval-lengths[indices,observed],np.zeros(rows)))
        reports[name]=dict(differentCells=int((predictions!=levels).sum()),
            exactBoundaryIntervals=int((gap==0).sum()),
            medianBoundaryErrorLod=float(np.median(abs(estimate-predict_interval))),
            p95BoundaryErrorLod=float(np.quantile(abs(estimate-predict_interval),.95)),
            maximumBoundaryErrorLod=float(abs(estimate-predict_interval).max()))
    return reports


report={'status':'qualified','overallStatus':'failed-user-review',
    'inputSha256':inputs['sha256'],'shapes':rows,'scaleSteps':columns,'positionsPerAdapter':rows*columns*tile*tile,
    'devices':{}}
levels_by_device={}
for name,vendor in adapter_ids.items():
    values, values_sha=read(name,'values')
    derivatives, derivatives_sha=read(name,'derivatives')
    sample_codes=values.astype('f8')*255/16
    codes=np.rint(sample_codes).astype('i4')
    assert np.max(np.abs(sample_codes-codes))<2e-5
    assert np.all(codes[...,2]==1) and np.all(codes[...,3]==12), 'Explicit levels or draw coverage failed'
    levels=codes[...,:2]-1
    assert np.all((levels>=2)&(levels<=5))
    center=levels[:,:,0,0]
    measured=derivatives[:,:,0,0].astype('f8')
    derivative_error=float(np.abs(measured-authored).max())
    assert derivative_error<=2e-5
    levels_by_device[name]=center
    variation=np.any(levels!=center[:,:,None,None],axis=(2,3,4))
    thresholds=crossings(center[...,0])
    grad_thresholds=crossings(center[...,1])
    comparable=classify(measured,center[...,0],thresholds)
    report['devices'][name]=dict(vendor=vendor,valuesSha256=values_sha,derivativesSha256=derivatives_sha,
        exactCornerGradients=int(np.all(measured==authored,axis=-1).sum()),maximumCornerGradientError=derivative_error,
        covered=int(np.count_nonzero(codes[...,2]==1)),
        variedWithinCell=int(variation.sum()),biasGradDifferentCells=int((center[...,0]!=center[...,1]).sum()),
        biasGradDifferentBoundaries=int((thresholds!=grad_thresholds).sum()),models=comparable,
        boundaries=[dict(shape=inputs['shapes'][i],bias=int(thresholds[i]),grad=int(grad_thresholds[i])) for i in range(rows)])
    center.astype('u1').tofile(out/f'{name}-selected-mips.bin')
    measured.astype('<f4').tofile(out/f'{name}-selected-derivatives.bin')
nvidia=levels_by_device['nvidia']
intel=levels_by_device['intel']
report['nvidiaIntelDifferentCells']={mode:int((nvidia[...,i]!=intel[...,i]).sum()) for i,mode in enumerate(('sampleBias','sampleGrad'))}
report['intelLuidReadbacksExact']=all(report['devices']['intel'][key]==report['devices']['intel-alt'][key]
    for key in ('valuesSha256','derivativesSha256'))
report['intelLuidDifferentCells']={mode:int((intel[...,i]!=levels_by_device['intel-alt'][...,i]).sum())
    for i,mode in enumerate(('sampleBias','sampleGrad'))}
(out/'sampling-footprint.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(devices={name:{key:value for key,value in item.items() if key!='boundaries'}
    for name,item in report['devices'].items()},crossDevice=report['nvidiaIntelDifferentCells'])))

