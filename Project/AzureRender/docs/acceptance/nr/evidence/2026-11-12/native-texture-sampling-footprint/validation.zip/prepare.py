from hashlib import sha256
from itertools import product
from pathlib import Path
import json
import math
import struct

import numpy as np


out = Path(__file__).resolve().parent
angles = (0,17,43,59)
ratios = (.125,.35,.65,1)
correlations = (-.92,-.55,0,.35,.70,.96)
shape_parameters = [(angle,0,0) for angle in angles]+list(product(angles,ratios,correlations))
assert len(shape_parameters)==100
columns=257
scale_range = [3.85,5.12]
lengths = np.exp2(np.linspace(*scale_range,columns))
shapes = []
for angle,ratio,rho in shape_parameters:
    theta=math.radians(angle)
    axis=np.array([math.cos(theta),math.sin(theta)])
    perpendicular=np.array([-axis[1],axis[0]])
    second=ratio*(rho*axis+math.sqrt(1-rho*rho)*perpendicular)
    vector=np.concatenate([axis,second])
    shapes.append(dict(rotation=angle,ratio=ratio,correlation=rho,gradientShape=vector.tolist()))
normalized = np.array([item['gradientShape'] for item in shapes])
gradient = (normalized[:,None,:] * lengths[None,:,None]).astype('<f4')
assert gradient.shape==(100,257,4)
assert np.isfinite(gradient).all() and np.all(np.diff(np.linalg.norm(gradient[:,:,:2],axis=-1))>0)
raw = struct.pack('<II',columns,len(shapes))+gradient.tobytes()
(out/'gradients.bin').write_bytes(raw)
manifest = dict(rows=len(shapes),columns=columns,tile=4,textureExtent=2048,mips=12,shaderBias=-1,
    bytes=len(raw),sha256=sha256(raw).hexdigest(),log2Range=scale_range,shapes=shapes)
(out/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({key:value for key,value in manifest.items() if key!='shapes'}))

