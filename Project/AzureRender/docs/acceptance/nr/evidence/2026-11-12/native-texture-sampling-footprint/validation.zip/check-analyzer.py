from pathlib import Path
from shutil import copyfile
from tempfile import TemporaryDirectory
import json
import subprocess
import sys

import numpy as np


run = Path(__file__).resolve().parent
input_bytes=(run/'gradients.bin').read_bytes()
inputs=json.loads((run/'inputs.json').read_text())
rows,columns,tile=(inputs[key] for key in ('rows','columns','tile'))
gradient=np.frombuffer(input_bytes,'<f4',offset=8).reshape(rows,columns,4).astype('f8')
dx,dy=gradient[:,:,:2],gradient[:,:,2:]
dx_squared=np.square(dx).sum(axis=-1)
dy_squared=np.square(dy).sum(axis=-1)
dot=(dx*dy).sum(axis=-1)
max_axis=np.maximum(dx_squared,dy_squared)
ellipse=(dx_squared+dy_squared+np.sqrt((dx_squared-dy_squared)**2+4*dot*dot))*.5


def tiles(plane):
    return np.repeat(np.repeat(plane,tile,axis=0),tile,axis=1).astype('<f4')


with TemporaryDirectory(prefix='cpu-analyzer-',dir=run) as temporary:
    folder=Path(temporary).resolve()
    assert folder.parent==run and folder.name.startswith('cpu-analyzer-')
    for name in ('inputs.json','gradients.bin','analyze.py'):
        copyfile(run/name,folder/name)
    for name,metric in (('nvidia',ellipse),('intel',max_axis),('intel-alt',max_axis)):
        level=np.floor(.5*np.log2(metric)-.5)+1
        values=np.stack((level,level,np.ones_like(level),np.full_like(level,12)),axis=-1)*16/255
        tiles(values).tofile(folder/f'{name}-values.bin')
        tiles(gradient).tofile(folder/f'{name}-derivatives.bin')
    subprocess.run([sys.executable,'-B',str(folder/'analyze.py')],check=True,capture_output=True)
    results=json.loads((folder/'sampling-footprint.json').read_text())
    assert results['devices']['nvidia']['models']['ellipse']['differentCells']==0
    assert results['devices']['intel']['models']['maxAxis']['differentCells']==0
    assert results['nvidiaIntelDifferentCells']['sampleBias']>0
    assert results['intelLuidReadbacksExact']
    assert all(item['biasGradDifferentCells']==0 for item in results['devices'].values())
record=dict(status='passed',syntheticCpuOnly=True,cells=rows*columns,crossingDifferent=results['nvidiaIntelDifferentCells']['sampleBias'])
(run/'analyzer-self-check.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))

