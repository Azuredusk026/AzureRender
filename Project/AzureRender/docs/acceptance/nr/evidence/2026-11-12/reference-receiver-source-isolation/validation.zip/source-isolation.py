from hashlib import file_digest, sha256
from itertools import product
from pathlib import Path
import json
import os
import struct
import subprocess
import zipfile

import numpy as np


out = Path(__file__).resolve().parent
geometry = out.parent / '20261112-114419-reference-geometric-normal-3e57b5'
numerics = out.parent / '20261112-053111-intel-reference-visibility-sources-5238e2'
numeric = out.parent / '20261110-003435-visibility-numeric-contract-4f95e7'
hair = out.parent / '20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
nvidia_raster = out.parent / '20261112-041837-reference-object-shadow-raster-capture-60f161'
build = out.parent / '20261110-030251-hair-main-chroma-public-9e799c/release'
program = numerics / 'live-visibility-numerics.exe'
source = json.loads((numeric / 'hair-calibration.json').read_text())
original_atlas = json.loads((numerics / 'cross-device-live-atlas.json').read_text())
introduced = json.loads((geometry / 'geometric-normal-introduced-attribution.json').read_text())
assert out.name != geometry.name and out.parent == geometry.parent


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


frozen = {}
for key, expected in (
    ('depth','02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb'),
    ('normals','63731d707e7ba30d9417049c8148b9bd2167208e435e8d9f0cc100a1fd03e095'),
    ('atlas','86daee0e01e9c33207679b094bdf5cf31a26d2f93754f11abf6c44df1faecf57'),
    ('profile','bbda0d685ab5a66767c2c3881a67dff147e1f5a2c766db1f6dd5b63fecedcf2c'),
):
    path = Path(source[key])
    assert digest(path) == expected
    frozen[key] = str(path)
atlas_paths = {'nvidia':nvidia_raster/'atlas.bin','intel':numerics/'atlas.bin'}
assert all(digest(path) == original_atlas[name]['sha256'] for name,path in atlas_paths.items())

parameters = (numerics/'parameters.bin').read_bytes()
view = struct.unpack_from('<20f4I',parameters)
assert view[20:] == (1,1,1,0)
record = struct.unpack_from('<28f',parameters,96)
base = dict(extent=[2560,1440],atlasExtent=[4096,2048],atlasForward=True,profile=frozen['profile'],
    clipToWorld=view[:16],pixelOffset=view[18:20],flipNdcY=True,
    record=dict(projection=record[:16],lightDirection=record[16:19],lightBias=record[19],normalBias=record[20],
        filterRadiusUv=record[21:23],minimumReceiverDepth=record[23],atlasRect=record[24:28],projectionForward=False))


def region(query_path, target_path, count):
    x,y=np.fromfile(query_path,'<f4').reshape(-1,4)[:,:2].astype('i4').T
    target=np.fromfile(target_path,'<u4').astype('i4')
    assert len(x)==len(y)==len(target)==count
    return x,y,target


regions = {
    'receiver':region(numeric/'receiver-queries.bin',numeric/'receiver-expected.bin',49384),
    'hair':region(hair/'queries.bin',hair/'expected.bin',17017),
}
receiver_x,receiver_y,receiver_expected = regions['receiver']
receiver_id = receiver_y * 2560 + receiver_x
status = dict(status='running',rawSourceProgramSha256=digest(program),parametersSha256=sha256(parameters).hexdigest(),
    atlasSha256={name:digest(path) for name,path in atlas_paths.items()},devices={})


def read_actual(adapter, raw_dir):
    label='release-'+adapter
    frames=geometry/(label+'-frames')
    results=json.loads((geometry/(label+'-results.json')).read_text())
    manifest=json.loads((frames/'reference-planes.json').read_text())
    fields={
        'depth':'reference-depth-r32.bin',
        'normals':'reference-normals-a2b10g10r10.bin',
        'objectIds':'reference-object-ids-r8.bin',
        'visibility':'reference-object-visibility-rg8.bin',
    }
    stored={}
    with zipfile.ZipFile(frames/'reference-planes.zip') as archive:
        for key,name in fields.items():
            row=manifest[name]
            data=archive.read(row['archiveEntry'])
            assert len(data)==row['size'] and sha256(data).hexdigest()==row['sha256']
            if key=='visibility':
                assert row['sha256']==results['visibilitySha256']
                values=np.frombuffer(data,'u1').reshape(1440,2560,2)
                assert (values[:,:,0]==255).all()
            else:
                path=raw_dir/(key+'.bin')
                with path.open('xb') as stream:
                    stream.write(data)
                stored[key]=str(path)
    return stored,values[:,:,1],results['visibilitySha256']


def run(adapter, folder, label, config, actual, actual_sha, introduced_mask):
    case=folder/label
    case.mkdir()
    output=case/'visibility.bin'
    request=case/'request.json'
    request.write_text(json.dumps(dict(config,output=str(output)),indent=2)+'\n')
    argv=[str(program),str(request),str(build/'shaders')]
    env=os.environ.copy()
    for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
        env.pop(key,None)
    env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if adapter=='intel' else '*nv-vk64*',
        VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',
        PATH=str(build)+os.pathsep+env['PATH'])
    process=subprocess.run(argv,cwd=build,env=env,capture_output=True,timeout=95)
    (case/'process.log').write_bytes(process.stdout+process.stderr)
    assert process.returncode==0,(label,process.stdout,process.stderr)
    result=json.loads(process.stdout.splitlines()[-1])
    assert result['vendor']==(0x8086 if adapter=='intel' else 0x10de)
    assert result['zeroAllocator'] and not result['validationErrors']
    raw=output.read_bytes()
    assert len(raw)==2560*1440*2
    output_sha=sha256(raw).hexdigest()
    image=np.frombuffer(raw,'u1').reshape(1440,2560,2)
    assert (image[:,:,0]==255).all()
    result.update(outputSha256=output_sha,actualFullAttachmentExact=output_sha==actual_sha)
    for name,(x,y,target) in regions.items():
        reference=actual[y,x].astype('i4')
        values=image[y,x,1].astype('i4')
        difference=np.abs(values-target)
        bad=difference>1
        original_bad=np.abs(reference-target)>1
        result[name]=dict(samples=len(target),overOne=int(bad.sum()),maximum=int(difference.max()),
            closed=int((original_bad&~bad).sum()),introduced=int((~original_bad&bad).sum()))
        if name=='receiver':
            result[name]['geometricIntroducedStillOverOne']=int((bad&introduced_mask).sum())
        (case/(name+'-selected.bin')).write_bytes(values.astype('u1').tobytes())
    output.unlink()
    return result


report_path=out/'source-isolation.json'
for adapter in ('nvidia','intel'):
    folder=out/adapter
    folder.mkdir()
    raw_dir=folder/'inputs'
    raw_dir.mkdir()
    assert raw_dir.resolve(strict=True).parent == folder.resolve(strict=True)
    sources,actual,actual_sha=read_actual(adapter,raw_dir)
    introduced_pixels=np.array([row['pixel'] for row in introduced[adapter]['samples']])
    introduced_mask=np.isin(receiver_id,introduced_pixels[:,1]*2560+introduced_pixels[:,0])
    assert int(introduced_mask.sum())==introduced[adapter]['count']
    runs={}
    data=dict(actualSha256=actual_sha,cases=runs)
    status['devices'][adapter]=data
    try:
        for atlas_name in (adapter,'intel' if adapter=='nvidia' else 'nvidia'):
            name='cached-'+atlas_name+'-atlas'
            runs[name]=run(adapter,folder,name,dict(base,**sources,atlas=str(atlas_paths[atlas_name])),
                actual,actual_sha,introduced_mask)
        exact=[name for name in atlas_paths if runs['cached-'+name+'-atlas']['actualFullAttachmentExact']]
        data['reproducingAtlasSources']=exact
        if exact:
            atlas_name=adapter if adapter in exact else exact[0]
            data['selectedAtlas']=atlas_name
            for depth,normals,atlas in product((False,True),repeat=3):
                enabled=[name for name,active in (('depth',depth),('normals',normals),('atlas',atlas)) if active]
                if not enabled:
                    continue
                label='native-'+'-'.join(enabled)
                actual_inputs=dict(base,**sources,atlas=str(atlas_paths[atlas_name]))
                for field in enabled:
                    actual_inputs[field]=frozen[field]
                actual_inputs['atlasForward']=not atlas
                runs[label]=run(adapter,folder,label,actual_inputs,actual,actual_sha,introduced_mask)
            assert not runs['native-depth-normals-atlas']['receiver']['overOne']
            assert not runs['native-depth-normals-atlas']['hair']['overOne']
    finally:
        for path in raw_dir.iterdir():
            assert path.resolve(strict=True).parent == raw_dir.resolve(strict=True) and path.name in ('depth.bin','normals.bin','objectIds.bin')
            path.unlink()
        report_path.write_text(json.dumps(status,indent=2)+'\n')
status['status']='qualified' if all(item['reproducingAtlasSources'] for item in status['devices'].values()) else 'missing-live-atlas'
report_path.write_text(json.dumps(status,indent=2)+'\n')
print(json.dumps({device:{name:row['receiver'] for name,row in item['cases'].items()}
    for device,item in status['devices'].items()}))