from hashlib import sha256
from pathlib import Path
import json
import zipfile

import numpy as np


run = Path(__file__).resolve().parent
evidence = run.parents[2] / 'docs/acceptance/nr/evidence/2026-11-12/reference-receiver-source-isolation'
numeric = run.parent / '20261110-003435-visibility-numeric-contract-4f95e7'
hair = run.parent / '20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'


def read(name):
    return json.loads((run / name).read_text())


report = read('source-isolation.json')
assert report['status'] == 'qualified'
assert read('first-replay-execution.json')['exitCode'] == 1
assert "key 'extent' not found" in (run/'first-nvidia/cached-nvidia-atlas/process.log').read_text()
receipt = read('replay-execution.json')
assert receipt['status'] == 'exited' and receipt['exitCode'] == 0
lease = read('lease-released.json')
assert lease['state'] == 'released' and lease['token'] == read('lease-held.json')['token']
target = {
    'receiver': np.fromfile(numeric/'receiver-expected.bin','<u4').astype('i4'),
    'hair': np.fromfile(hair/'expected.bin','<u4').astype('i4'),
}
assert [len(values) for values in target.values()] == [49384,17017]
assert set(report['devices']) == {'nvidia','intel'}
for adapter, device in report['devices'].items():
    assert device['reproducingAtlasSources'] == [adapter]
    assert len(device['cases']) == 9
    baseline = device['cases']['cached-'+adapter+'-atlas']
    assert baseline['actualFullAttachmentExact']
    assert baseline['outputSha256'] == device['actualSha256']
    for region, expected in target.items():
        original = np.fromfile(run/adapter/('cached-'+adapter+'-atlas')/(region+'-selected.bin'),'u1')
        original_bad = np.abs(original.astype('i4')-expected)>1
        for case, item in device['cases'].items():
            assert item['validationErrors'] == 0 and item['zeroAllocator']
            values = np.fromfile(run/adapter/case/(region+'-selected.bin'),'u1')
            error = np.abs(values.astype('i4')-expected)
            current_bad = error>1
            result = item[region]
            assert (len(values),int(current_bad.sum()),int(error.max()),
                    int((original_bad & ~current_bad).sum()),int((~original_bad & current_bad).sum())) == (
                result['samples'],result['overOne'],result['maximum'],result['closed'],result['introduced'])
        assert not device['cases']['native-depth-normals-atlas'][region]['overOne']

evidence.mkdir(parents=True,exist_ok=False)
archive_path = evidence/'validation.zip'
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(run.rglob('*')):
        if path.is_file() and path.relative_to(run).parts[0] != 'tmp':
            archive.write(path,path.relative_to(run).as_posix())
    for path in (numeric/'receiver-queries.bin',numeric/'receiver-expected.bin',hair/'queries.bin',hair/'expected.bin'):
        archive.write(path,'frozen/'+path.name)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    members = len(archive.namelist())
raw = archive_path.read_bytes()
assert len(raw) < 8*1024**2
report.update(
    overallStatus='failed-user-review',
    scope=read('task-card.json'),
    execution=receipt,
    originalLaunch=read('first-replay-execution.json'),
    resourceRelease=lease,
    archive={'sha256':sha256(raw).hexdigest(),'bytes':len(raw),'members':members},
)
(evidence/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['archive']))

