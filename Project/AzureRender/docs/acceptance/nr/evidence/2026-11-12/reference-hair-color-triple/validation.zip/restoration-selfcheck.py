
from pathlib import Path
import json

import shader_files as shaders


out=Path(__file__).resolve().parent
root=out/'restore-control'
live=root/'active'
probe=root/'mode/shader-probe'
live.mkdir(parents=True)
probe.mkdir(parents=True)
before={}
programs={}
for index in range(8):
    name=f'fixture{index}_coverage_uvquad.frag.spv'
    active=live/name
    staged=probe/name
    active.write_bytes(f'baseline {index}'.encode())
    staged.write_bytes(f'probe {index}'.encode())
    before[name]=shaders.digest(active)
    programs[name]=dict(baselineSha256=before[name],probeSha256=shaders.digest(staged))
shaders.write(probe/'compiled.json',dict(programs=programs))
original=shaders.locations
shaders.locations=lambda run:(live,before)
try:
    try:
        with shaders.shader_files(root,root/'mode') as installed:
            assert shaders.catalog(live)==installed and installed!=before
            raise RuntimeError('Deliberate diagnostic child failure')
    except RuntimeError as error:
        assert str(error)=='Deliberate diagnostic child failure'
    else:
        raise AssertionError('Fixture failure did not propagate')
    assert shaders.catalog(live)==before
    receipt=shaders.read(root/'mode/shader-restoration.json')
    assert receipt==dict(status='restored',files=8,restored=before)
    shaders.write(out/'restoration-selfcheck.json',dict(status='passed',filesRestored=len(before),synthetic=True))
finally:
    shaders.locations=original
print(json.dumps(shaders.read(out/'restoration-selfcheck.json')))
