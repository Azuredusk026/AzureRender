
from hashlib import file_digest, sha256
from pathlib import Path
import json
import re
import runpy
import subprocess
import sys
import zipfile

import numpy as np
from PIL import Image


run=Path(__file__).resolve().parent
mode,device=sys.argv[1:]
assert mode in ('t16','triple') and device in ('nvidia','intel')
out=run/mode
boundary=run.parent/'20261112-164303-reference-hair-mip-boundary-342000'
shader_probe=out/'shader-probe'
build=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
fixture=run.parent/'20261112-153052-reference-hair-mip-footprint-510ded/hair-project'
shaders=build/'shaders'



def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


compiled=json.loads((shader_probe/'compiled.json').read_text())
programs=compiled['programs']
player=build/'AzurePlayer.exe'
reference=json.loads((boundary/'release-verification.json').read_text())
assert digest(player)==reference['playerSha256']
journal=json.loads((out/'shader-journal.json').read_text())
expected=journal['active']
assert len(expected)==895 and journal['shaderDirectory']==str(shaders.resolve(strict=True))
assert set(programs)==set(journal['modified'])
assert all(expected[name]==record['probeSha256'] for name,record in programs.items())
assert {path.name:digest(path) for path in shaders.glob('*.spv')}==expected
for entry in json.loads((boundary/'fixture-inputs.json').read_text())['files']:
    path=fixture/entry['relative']
    assert path.stat().st_size==entry['bytes'] and digest(path)==entry['sha256']
frames=out/(device+'-frames')
argv=[str(player),'--project',str(fixture/'hair-coverage.azureproject'),'--width','2560','--height','1440',
    '--capture-frames','3','--capture-dir',str(frames),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene',
    '--qa-isolation','beauty','--disable-compute-skinning','--disable-bindless','--resource-root',str(build)]
(out/(device+'-command.json')).write_text(json.dumps(argv,indent=2)+'\n')
log_path=out/(device+'.log')
with log_path.open('wb') as log:
    execution=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=240)
log=log_path.read_text(errors='replace')
assert execution.returncode==0 and 'Allocator after unload: buffers=0 images=0' in log, log[-7000:]
assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I), log[-7000:]
assert {p.name:digest(p) for p in shaders.glob('*.spv')}==expected
assert digest(player)==reference['playerSha256']
capabilities=json.loads((frames/'gpu_capabilities.json').read_text())
expected_device=(0x10de,0x28e0) if device=='nvidia' else (0x8086,0xa788)
assert (capabilities['vendor_id'],capabilities['device_id'])==expected_device
capture=json.loads((frames/'capture_manifest.json').read_text())['referenceSceneDepth']
assert (capture['rowOrigin'],capture['normalFrame'],capture['submission'],capture['width'],capture['height'])==(
    'bottom-left','reference',3,2560,1440)
keys=('raster','hardware','packedNormals','objectIds','objectVisibility')
base_frames=boundary/(f'release-{device}-frames')
base_capture=json.loads((base_frames/'capture_manifest.json').read_text())['referenceSceneDepth']
stored=json.loads((base_frames/'reference-planes.json').read_text())
attachments={}
with zipfile.ZipFile(base_frames/'reference-planes.zip') as archive:
    for key in keys:
        current=(frames/capture[key]).read_bytes()
        before=archive.read(stored[base_capture[key]]['archiveEntry'])
        attachments[key]=dict(exact=current==before,before=sha256(before).hexdigest(),after=sha256(current).hexdigest())
base=runpy.run_path(str(run.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
mask=base['mask']
bounds=tuple(base[name] for name in ('x0','y0','x1','y1'))
assert mask.sum()==17017
colors=[]
for index in range(3):
    current=frames/f'frame_{index:06d}.png'
    previous=base_frames/current.name
    old=np.array(Image.open(previous).convert('RGB'),dtype='u1')
    new=np.array(Image.open(current).convert('RGB'),dtype='u1')
    x0,y0,x1,y1=bounds
    old_crop=old[y0:y1,x0:x1]
    new_crop=new[y0:y1,x0:x1]
    delta=np.any(old_crop!=new_crop,axis=2)
    old_bad=np.abs(old_crop.astype('i4')-base['expected'])[mask].max(axis=1)>1
    new_bad=np.abs(new_crop.astype('i4')-base['expected'])[mask].max(axis=1)>1
    colors.append(dict(baselineOverOne=int(old_bad.sum()),overOne=int(new_bad.sum()),
        introduced=int((~old_bad&new_bad).sum()),closed=int((old_bad&~new_bad).sum()),
        fullFrameChanged=int(np.any(old!=new,axis=2).sum()),cropChanged=int(delta.sum()),
        frozenHairChanged=int((delta&mask).sum()),before=digest(previous),after=digest(current)))
    if index==0:
        coords=np.argwhere(mask)
        selected=np.column_stack((coords[:,1]+x0,coords[:,0]+y0,old_crop[mask],new_crop[mask],base['expected'][mask])).astype('<u2')
        selected.tofile(out/(device+'-frozen-hair-rgb.bin'))
result=dict(device=device,pciDevice=list(expected_device),playerSha256=digest(player),attachments=attachments,colors=colors,shaderCount=len(expected),activeShaders=expected,
    validationClean=True,allocatorZero=True)
(out/(device+'-results.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key!='overlay'}))
