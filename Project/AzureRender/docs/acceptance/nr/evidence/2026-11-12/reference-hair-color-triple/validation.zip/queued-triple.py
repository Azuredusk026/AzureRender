
from pathlib import Path
import json
import os
import subprocess
import sys
import time

import numpy as np
from shader_files import shader_files


run=Path(__file__).resolve().parent
build=run.parents[1]
prior_pair=run.parent/'20261112-174157-reference-hair-color-pair-8d76da/pair'
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')


def capture(mode):
    folder=run/mode
    with shader_files(run,folder) as active:
        for device in ('nvidia','intel'):
            os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*' if device=='intel' else '*nv-vk64*'
            argv=[sys.executable,'-B',str(run/'color-capture.py'),mode,device]
            result=shared.maintenance.guarded_run(build,run.name,argv,330)
            write(folder/(device+'-execution.json'),result)
            print(json.dumps(result),flush=True)
            assert result['status']=='exited' and result['exitCode']==0,result
            subprocess.run([sys.executable,'-B',str(folder/'compact-capture.py'),device+'-frames'],check=True)
        cases={device:json.loads((folder/(device+'-results.json')).read_text()) for device in ('nvidia','intel')}
        assert all(case['activeShaders']==active for case in cases.values())
    restoration=json.loads((folder/'shader-restoration.json').read_text())
    assert restoration['status']=='restored' and restoration['files']==895
    return cases,restoration['files']


def colors(folder):
    raw=np.fromfile(folder/'intel-frozen-hair-rgb.bin','<u2').astype('i4').reshape(17017,11)
    pixels,baseline,actual,frozen=np.split(raw,(2,5,8),axis=1)
    return pixels,baseline,actual,frozen


predecessor,receipt_path=sys.argv[1:]
deadline=time.monotonic()+1800
while time.monotonic()<deadline:
    try:
        state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
        receipt=json.loads(Path(receipt_path).read_text())
    except (OSError,ValueError):
        time.sleep(1)
        continue
    assert state['token']==predecessor and receipt['token']==predecessor
    if state['state']==receipt['state']=='released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed color pairing window has not opened')
write(run/'predecessor-receipt.json',receipt)
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key,None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
lease=None
try:
    with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-reference-hair-color-triple-gpu',run) as lease:
        write(run/'lease-held.json',lease)
        modes={mode:capture(mode) for mode in ('t16','triple')}
        pixels,baseline,actual_pair,frozen=colors(prior_pair)
        bad={name:(np.abs(raw-frozen).max(axis=1)>1) for name,raw in (('baseline',baseline),('priorPair',actual_pair))}
        assert (int(bad['baseline'].sum()),int(bad['priorPair'].sum()))==(568,393)
        for mode in modes:
            selected,old,actual,expected=colors(run/mode)
            assert np.array_equal(selected,pixels) and np.array_equal(old,baseline) and np.array_equal(expected,frozen)
            bad[mode]=np.abs(actual-frozen).max(axis=1)>1
            assert int(bad[mode].sum())==modes[mode][0]['intel']['colors'][0]['overOne']
        prior_new=~bad['baseline']&bad['priorPair']
        assert int(prior_new.sum())==40
        triple_new=~bad['baseline']&bad['triple']
        attachments_exact=all(attachment['exact'] for cases,_ in modes.values()
            for device in cases.values() for attachment in device['attachments'].values())
        activated=all(any(row['frozenHairChanged'] for row in cases['intel']['colors']) for cases,_ in modes.values())
        nvidia_pass=all(row['overOne']==0 for cases,_ in modes.values() for row in cases['nvidia']['colors'])
        summary=dict(status='qualified-color-triple-control' if attachments_exact and activated else 'failed-color-triple-control',
            overallStatus='failed-user-review',referenceAttachmentsExact=attachments_exact,activated=activated,nvidiaFrozenHairPass=nvidia_pass,
            colors={mode:{name:result['colors'] for name,result in cases.items()} for mode,(cases,_) in modes.items()},
            pairIntroducedClosedByTriple=int((prior_new&~bad['triple']).sum()),
            pairIntroducedStillInTriple=int((prior_new&bad['triple']).sum()),
            tripleIntroducedOutsidePair=int((triple_new&~prior_new).sum()),
            tripleClosedOverBothSingleControls=int((bad['t16']&bad['priorPair']&~bad['triple']).sum()),
            shaderFilesRestored={mode:files for mode,(_,files) in modes.items()})
        write(run/'color-triple-gate.json',summary)
        print(json.dumps(summary),flush=True)
finally:
    if lease is not None:
        write(run/'lease-released.json',lease)
