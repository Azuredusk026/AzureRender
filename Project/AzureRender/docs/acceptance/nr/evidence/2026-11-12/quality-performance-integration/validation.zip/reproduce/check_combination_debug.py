from hashlib import file_digest
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET


run = Path(__file__).resolve().parent
engine = run.parents[2]
mode = sys.argv[1]
assert mode in ('build', 'cpu', 'gpu', 'reference', 'four', 'editor')
root = Path('D:/Projects/FYP/Project/AzureRender')
coordination = root / 'build/runs/20261112-011326-handoff-final-regression-e2e260'
proof = json.loads((coordination/'quality-merged-tree-resolved.json').read_bytes())
build = engine/'build/catalog-standard-debug'
def git(*command):
    return subprocess.check_output(['git','-C',str(engine),*command]).decode().strip()

assert git('write-tree') == proof['resolvedTree']
subprocess.run(['git','-C',str(engine),'diff','--exit-code'],check=True)
environment = dict(os.environ)
for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_INSTANCE_LAYERS',
    'VK_LAYER_VALIDATE_SYNC', 'VK_LAYER_ENABLES', 'AZURE_DISABLE_COMPUTED_MATERIAL_VIEW'):
    environment.pop(key, None)
environment.update(CMAKE_BUILD_PARALLEL_LEVEL='3', DOTNET_ROOT='D:/Tools/dotnet9',
    PATH=str(build)+os.pathsep+environment['PATH'], VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
assert 'AZURE_ENABLE_COMPUTED_MATERIAL_VIEW:BOOL=OFF' in (build/'CMakeCache.txt').read_text()
assert 'AZURE_ENABLE_SHADOW_HISTORY:BOOL=OFF' in (build/'CMakeCache.txt').read_text()

def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()

def invoke(name, command, timeout, env=environment):
    log = run/(name+'.log')
    started = time.monotonic()
    with log.open('wb') as output, subprocess.Popen(command, cwd=engine, env=env,
            stdout=output, stderr=subprocess.STDOUT) as process:
        try:
            code=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill.exe','/PID',str(process.pid),'/T','/F'],
                stdout=output,stderr=subprocess.STDOUT,check=False)
            process.wait(timeout=30)
            raise
    if code:
        raise subprocess.CalledProcessError(code,command)
    return {'seconds':time.monotonic()-started,'command':command}

def assert_reserve():
    total,_,free=shutil.disk_usage(engine)
    assert free>max(50*2**30,total//10),(free,total)

def run_suite(name, pattern, expected, env=environment):
    junit=run/(name+'.xml')
    stats=invoke(name,['ctest','--test-dir',str(build),'-C','Debug','--no-tests=error',
        '--output-on-failure','-R',pattern,'--output-junit',str(junit)],560,env)
    cases=ET.parse(junit).findall('.//testcase')
    assert len(cases)==expected and all(c.find('failure') is None and c.find('skipped') is None for c in cases)
    stats['tests']={c.get('name'):float(c.get('time')) for c in cases}
    return stats

if mode=='build':
    assert_reserve()
    targets=('AzureRender','AzurePlayer','AzureEngineContracts','AzureRenderExtensionRegistryTests','AzureReferenceCameraViewTests','AzureReferenceCameraBindingTests',
        'AzureMaterialCoverageTests','AzureProjectReferenceViewsTests','AzureMaterialDocumentTests',
        'AzureEditorProjectFlowTests','AzureScreenObjectVisibilityTests','AzureScreenObjectVisibilityGpuTests',
        'AzureReferenceDepthGpuTests','AzureReferenceDepthCoverageGpuTests','AzureSurfaceResponseGpuTests',
        'AzureShadowHistoryPolicyTests','AzureShadowHistoryRuntimePolicyTests','AzureShadowHistoryRecordingTests','AzureShadowHistoryCacheGpuTests',
        'AzureRenderEditorSessionTests','AzureEditorTaskServiceTests')
    stats=invoke('combined-debug-standard-build',['cmake','--build',str(build),'--config','Debug','--target',*targets],2700)
    shaders=sorted((build/'shaders').glob('*.spv'))
    names={p.name for p in shaders}
    registry=json.loads((build/'shader-reload.json').read_bytes())
    assert names=={program['output'] for program in registry['programs']} and len(names)==896
    stats.update(shaderCount=len(names),programs={p.name:digest(p) for p in shaders},
        binaries={name:digest(build/(name+'.exe')) for name in targets if (build/(name+'.exe')).is_file()})
    assert_reserve()
elif mode=='cpu':
    stats=run_suite('combined-debug-standard-cpu',
        r'^(AzureRender[.](ReferenceCameraView|ReferenceCameraBinding|ExtensionRegistry|ScreenObjectVisibility|MaterialCoverage|ShadowHistory(Policy|RuntimePolicy|Recording)|EditorSession)|AzureEngine[.]ProjectReferenceViews|AzureAssets[.]MaterialDocument|AzureEditor[.](ProjectFlow|TaskService))$',13)
elif mode=='editor':
    stats=run_suite('combined-debug-standard-editor',r'^AzureEngine[.]EditorPlayable$',1)
    assert stats['tests']['AzureEngine.EditorPlayable'] < 240
elif mode=='gpu':
    stats={}
    for adapter, driver in (('nvidia','*nv-vk64*'),('intel','*igvk64*')):
        stats[adapter]=run_suite('combined-debug-standard-gpu-'+adapter,
            r'^AzureRender[.](ScreenObjectVisibility(Gpu|ReferenceGpu)|ReferenceDepth(Coverage)?Gpu|SurfaceResponseGpu|ShadowHistoryCacheGpu)$',6,
            dict(environment,VK_LOADER_DRIVERS_SELECT=driver))
elif mode=='reference':
    reference_source=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261112-135432-reference-outline-projection-d784cf')
    fixture=reference_source/'hair-project'
    registry=json.loads((reference_source/'fixture-inputs.json').read_bytes())
    for item in registry['files']:
        path=fixture/item['relative']
        assert path.stat().st_size==item['bytes'] and digest(path)==item['sha256']
    stats={}
    for adapter,driver in (('nvidia','*nv-vk64*'),('intel','*igvk64*')):
        before=json.loads((reference_source/f'debug-{adapter}-results.json').read_bytes())
        frames=run/('combined-debug-reference-'+adapter)
        result=invoke('combined-debug-reference-'+adapter,[str(build/'AzurePlayer.exe'),'--project',str(fixture/'hair-coverage.azureproject'),
            '--width','2560','--height','1440','--capture-frames','3','--capture-dir',str(frames),'--fixed-frame-step',
            '--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--disable-compute-skinning',
            '--disable-bindless','--resource-root',str(build)],300,dict(environment,VK_LOADER_DRIVERS_SELECT=driver))
        log=(run/('combined-debug-reference-'+adapter+'.log')).read_text(errors='replace')
        assert 'Allocator after unload: buffers=0 images=0' in log
        assert all(value not in log for value in ('VUID-','SYNC-HAZARD','Validation Error','Validation Warning'))
        capture=json.loads((frames/'capture_manifest.json').read_bytes())['referenceSceneDepth']
        assert (capture['rowOrigin'],capture['normalFrame'],capture['submission'],capture['width'],capture['height'])==(
            'bottom-left','reference',3,2560,1440)
        fields={'raster':'referenceDepthSha256','hardware':'referenceDepthSha256','objectIds':'objectIdsSha256',
            'packedNormals':'normalsSha256','objectVisibility':'visibilitySha256'}
        result['attachments']={key:digest(frames/capture[key]) for key in fields}
        result['exact']={key:sha==before[fields[key]] for key,sha in result['attachments'].items()}
        result['frames']=[digest(frames/f'frame_{index:06d}.png') for index in range(3)]
        result['colorExact']=result['frames']==before['colorSha256']
        result['sourceReceiverOverOne']=before['receiver']['overOne']
        stats[adapter]=result
        (run/'combined-debug-reference-partial-results.json').write_text(json.dumps(stats,indent=2)+'\n')
        assert all(result['exact'].values()) and result['colorExact'], result
    for item in registry['files']:
        assert digest(fixture/item['relative'])==item['sha256']
else:
    fixture=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
    before=digest(fixture)
    frames=run/'combined-debug-default-four'
    stats=invoke('combined-debug-default-four',[str(build/'AzurePlayer.exe'),'--project',str(fixture),'--width','2560','--height','1440',
        '--qa-camera','scene','--qa-light','scene','--capture-frames','4','--capture-fps','24','--fixed-frame-step',
        '--capture-dir',str(frames),'--runtime-report',str(run/'combined-debug-default-four-runtime.json'),
        '--resource-root',str(build)],900)
    expected=['4faf27a0d379b247e9a0a98d77dd8a8c2622ad689dc914428ca8df7944b79387',
        '55678cd9b32fb282416bb975ead40e01c7a66042b93d8a4ff6f75da29dc3a2ab',
        'ecee0ff56e78afd0447c1704224b1aabcb16f73bac624d0ce69e27a1e4f33d79',
        '1eb14b1cce256811991cb04971dd86d7bb2eda455d127e0e4667c258921a6574']
    actual=[digest(frames/f'frame_{index:06d}.png') for index in range(4)]
    log=(run/'combined-debug-default-four.log').read_text(errors='replace')
    assert actual==expected and 'Allocator after unload: buffers=0 images=0' in log
    assert all(token not in log for token in ('VUID-','SYNC-HAZARD','Validation Error','Validation Warning'))
    assert digest(fixture)==before and 'referenceSceneDepth' not in json.loads((frames/'capture_manifest.json').read_bytes())
    stats.update(sha256=actual,projectSha256=before,allocatorZero=True,validationClean=True)
assert git('write-tree')==proof['resolvedTree']
subprocess.run(['git','-C',str(engine),'diff','--exit-code'],check=True)
(run/f'combined-debug-{mode}-results.json').write_text(json.dumps(dict(tree=proof['resolvedTree'],result=stats),indent=2)+'\n')
print(mode, 'verified', proof['resolvedTree'], flush=True)
