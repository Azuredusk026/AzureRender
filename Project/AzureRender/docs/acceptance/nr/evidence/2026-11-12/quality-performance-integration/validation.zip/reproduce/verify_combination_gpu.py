import json
from pathlib import Path
import subprocess
import sys

run=Path(__file__).resolve().parent
for mode in ('gpu','reference','four','editor'):
    subprocess.run([sys.executable,'-X','utf8','-B',str(run/'check_combination.py'),mode],
        check=True,timeout=970)
    result=json.loads((run/f'combined-{mode}-results.json').read_bytes())
    assert result['tree']=='f7ef2bf1053dd1067b5246361ded1c8f72da4188'
    print(mode,'passed',flush=True)
