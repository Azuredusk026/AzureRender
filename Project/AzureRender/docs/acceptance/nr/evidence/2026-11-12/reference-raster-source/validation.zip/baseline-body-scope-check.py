from hashlib import sha256
from pathlib import Path
import json
import zipfile
import zlib

import numpy as np


run=Path(__file__).resolve().parent
base=run.parent/'20261112-182312-projected-hair-point-mip-82adc1'
source=run.parent/'20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
owners=np.zeros((310,290),dtype='u2')
previous=np.zeros_like(owners,dtype='<u4')
native=json.loads((source/'native-atlas-producers.json').read_text())
for event,entry in native['receiverNormal']['stages'].items():
    item=entry['crop']
    raw=(source/item['path']).read_bytes()
    assert sha256(raw).hexdigest()==item['sha256']
    values=np.frombuffer(zlib.decompress(raw),'<u4').reshape(310,290)
    owners[values!=previous]=int(event)
    previous=values
numeric=run.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
x,y=np.fromfile(numeric/'receiver-queries.bin','<f4').reshape(49384,4)[:,:2].astype('i4').T
select=owners[y-1000,x-1140]==328
assert int(select.sum())==9116
target=previous[y-1000,x-1140]
for device,count in (('nvidia',141),('intel',276)):
    folder=base/('release-'+device+'-frames')
    field='reference-normals-a2b10g10r10.bin'
    row=json.loads((folder/'reference-planes.json').read_text())[field]
    with zipfile.ZipFile(folder/'reference-planes.zip') as archive:
        raw=archive.read(row['archiveEntry'])
    assert sha256(raw).hexdigest()==row['sha256']
    packed=np.frombuffer(raw,'<u4').reshape(1440,2560)[y,x]
    difference=np.maximum(*[
        np.abs(((packed>>bit)&1023).astype('i4')-((target>>bit)&1023).astype('i4'))
        for bit in (0,10)
    ])
    assert int((select&(difference>1)).sum())==count
    print(device,count)

