from collections import Counter
from pathlib import Path
import json
import re
import subprocess

run=Path(__file__).resolve().parent
tool=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-dis.exe')
names=sorted(path.name for path in (run/'grid/shader-probe').glob('*.spv'))


def parse(path):
    text=subprocess.check_output([str(tool),str(path)],text=True)
    precise=set(re.findall(r'OpDecorate\s+(%\S+)\s+NoContraction',text))
    functions={}
    current=None
    for line in text.splitlines():
        line=line.strip()
        definition=re.match(r'(%\S+)\s*=\s*(Op\S+)(.*)',line)
        if definition and definition[2]=='OpFunction':
            current=definition[1].split('(',1)[0]
            functions[current]=[]
        elif line=='OpFunctionEnd':
            current=None
        elif current and definition:
            functions[current].append((definition[2],definition[1] in precise))
    return dict(functions=functions)


result={}
for name in names:
    old=parse(run/'baseline-shaders'/name)['functions']
    new=parse(run/'grid/shader-probe'/name)['functions']
    assert old.keys()==new.keys()
    changed=[]
    for function in old:
        if old[function]!=new[function]:
            before=Counter(op for op,precise in old[function] if precise)
            after=Counter(op for op,precise in new[function] if precise)
            added=after-before
            lost=before-after
            prefix=len(old[function])
            if function=='%main':
                prefix=0
                for left,right in zip(old[function],new[function]):
                    if left[0]!=right[0]:
                        break
                    prefix+=1
            changed.append(dict(function=function,instructionsBefore=len(old[function]),instructionsAfter=len(new[function]),
                decoratedBefore=sum(before.values()),decoratedAfter=sum(after.values()),added=dict(added),
                lost=dict(lost),commonOperationPrefix=prefix,
                decorationDifferencesInPrefix=sum(a!=b for a,b in zip(old[function][:prefix],new[function][:prefix]))))
    result[name]=changed
(run/'grid/spirv-decoration-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

