
from hashlib import file_digest
from pathlib import Path
import json
import subprocess


run=Path(__file__).resolve().parent
engine=run.parents[2]
build=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
manifest=json.loads((build/'shader-reload.json').read_text())
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
out=run/'next-body-probe'
out.mkdir(exist_ok=False)
original=engine/'shaders/reference_scene_depth.frag'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def replace(source,old,new):
    assert source.count(old)==1,old
    return source.replace(old,new)


source=original.read_text()
source=replace(source,'    layout(offset=80) float referenceNormalMipBias;',
    '    layout(offset=80) float referenceNormalMipBias;\n    layout(offset=112) uint materialClass;')
source=replace(source,'    float mode=material.normalControl.x;',
    '    float mode=material.normalControl.x;\n    if(mode==0.0&&material.materialClass==1u)mode=3.0;')
probe=out/'reference_scene_depth.frag'
probe.write_text(source,encoding='utf-8')
programs={}
for row in manifest['programs']:
    name=row['output']
    if name not in ('reference_scene_visibility.frag.spv','reference_scene_visibility_bindless.frag.spv'):
        continue
    base=[str(sdk/'glslc.exe'),*row['arguments'],*('-D'+flag for flag in row['defines'])]
    test=out/'original.spv'
    subprocess.run([*base,str(original),'-o',str(test)],check=True)
    before=digest(build/'shaders'/name)
    assert digest(test)==before
    test.unlink()
    result=out/name
    argv=[*base,'-I'+str(original.parent),str(probe),'-o',str(result)]
    subprocess.run(argv,check=True)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(result)],check=True)
    assert digest(result)!=before
    programs[name]=dict(baselineSha256=before,probeSha256=digest(result),command=argv)
assert len(programs)==2
(out/'compiled.json').write_text(json.dumps(dict(sourceSha256=digest(probe),programs=programs,
    scope='Unassigned reference normal on the skin material class'),indent=2)+'\n')
print(json.dumps({name:row['probeSha256'] for name,row in programs.items()}))
