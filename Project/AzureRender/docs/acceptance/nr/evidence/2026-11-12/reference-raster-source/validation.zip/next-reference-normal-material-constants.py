from pathlib import Path
from hashlib import sha256
import json
import struct

run=Path(__file__).resolve().parent
source=run.parent/'20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry'
fixture=run.parent/'20261112-182312-projected-hair-point-mip-82adc1/hair-project'
doc=json.loads((source/'native-caster-geometry.json').read_text())['receiverDraws']
result={}
for event in ('328','377'):
    item=doc[event]['pixel']
    stages={}
    camera_slot, material_slot = ('1','3') if event == '328' else ('0','2')
    for slot in (camera_slot, material_slot):
        row=item['constants'][slot]
        data=(source/row['path']).read_bytes()
        assert sha256(data).hexdigest()==row['sha256']
        floats=struct.unpack('<'+'f'*(len(data)//4),data)
        stages[slot]=[floats[i:i+4] for i in range(0,len(floats),4)]
    result[event]=dict(shaderBias=stages[camera_slot][26][0],
        normalScale=stages[material_slot][0][3],backfaceMode=stages[material_slot][1][1],
        backfaceMultiplier=2*stages[material_slot][1][1]-1)
asset=fixture/'character/hair-coverage.glb'
raw=asset.read_bytes()
length,=struct.unpack_from('<I',raw,12)
doc=json.loads(raw[20:20+length])
for name in ('M_actor_laevat_body_01','M_actor_laevat_cloth_01'):
    m,=(m for m in doc['materials'] if m['name']==name)
    normal=m['normalTexture']
    tex=doc['textures'][normal['index']]
    image=doc['images'][tex['source']]
    profile=m['extras']['azureRenderMaterial']
    result[name]=dict(normalScale=normal.get('scale',1),sampler=doc['samplers'][tex['sampler']] if 'sampler' in tex else None,
        uri=image['uri'][:100],normalMode=profile.get('referenceNormal'),
        materialClass=profile['class'],doubleSided=m.get('doubleSided',False))
print(json.dumps(result,indent=2))
(run/'next-reference-normal-material-constants.json').write_text(json.dumps(result,indent=2)+'\n')



