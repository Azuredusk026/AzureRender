from pathlib import Path

run=Path(__file__).resolve().parent
old=run.parent/'20261112-182312-projected-hair-point-mip-82adc1/next-precision-edge.py'
source=old.read_text().split('\npoints=np.array',1)[0]
scope={'__file__':str(old)}
exec(compile(source,str(old),'exec'),scope)

import json
import numpy as np


xy,screen,quad=(scope[name] for name in ('xy','screen','quad'))
interpolate,projected_max=(scope[name] for name in ('interpolate','projected_max'))
triple=run.parent/'20261112-175619-reference-hair-color-triple-d2d080/next-triple-residual-lod.json'
positions={tuple(row['display']):row for row in json.loads(triple.read_text())['pixels']}
point_order=[(int(x),1439-int(y)) for x,y in xy]
bad=np.array([point in positions for point in point_order])
assert len(xy)==17017 and int(bad.sum())==32


def biased_lod(raster,row,column):
    uv=[interpolate(quad+step,raster) for step in ((0,0),(1,0),(0,1),(1,1))]
    xs=[(uv[1]-uv[0])*4096,(uv[3]-uv[2])*4096]
    ys=[(uv[2]-uv[0])*4096,(uv[3]-uv[1])*4096]
    dx,dy=xs[row],ys[column]
    return np.log2(np.maximum(np.maximum(projected_max(dx),projected_max(dy)),
        (11/16)*np.maximum(projected_max(dx+dy),projected_max(dx-dy))))-1


result=dict(samples=len(xy),frozenBad=int(bad.sum()),models={})
for row in (0,1):
    for column in (0,1):
        nearest=biased_lod(np.rint(screen*256)/256,row,column)
        floor=biased_lod(np.floor(screen*256)/256,row,column)
        nearest_level=np.clip(np.floor(nearest+.5),0,11).astype('i4')
        floor_level=np.clip(np.floor(floor+.5),0,11).astype('i4')
        changed=nearest_level!=floor_level
        rows=[]
        for i in np.flatnonzero(bad&changed):
            display=point_order[i]
            rows.append(dict(display=display,nearest=float(nearest[i]),floor=float(floor[i]),
                nearestLevel=int(nearest_level[i]),floorLevel=int(floor_level[i]),
                rgbError=positions[display]['rgbError'],visibilityError=positions[display]['visibilityError']))
        result['models'][f'{row}-{column}']=dict(mipChoiceChanged=int(changed.sum()),
            frozenBadWithChoiceChanged=len(rows),frozenBadWithChoiceChangedAndExactVisibility=sum(row['visibilityError']==0 for row in rows),
            points=rows)
(run/'next-hair-raster-lod-hypothesis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({name:{key:value for key,value in row.items() if key!='points'} for name,row in result['models'].items()}))

