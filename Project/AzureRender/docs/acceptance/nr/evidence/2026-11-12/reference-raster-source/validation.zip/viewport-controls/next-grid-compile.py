
from hashlib import file_digest
from pathlib import Path
import json
import subprocess


run=Path(__file__).resolve().parent
engine=run.parents[2]
build=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
manifest=json.loads((build/'shader-reload.json').read_text())
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
shader=engine/'shaders/mesh.vert'
out=run/'next-grid-probe'
out.mkdir(exist_ok=False)


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


source=shader.read_text()
anchor='    gl_Position=azureCameraRasterPosition(worldPosition,referenceDeviceBase,gl_Position);'
assert source.count(anchor)==1
replacement=anchor+'''
    const uint projectedHairReferenceUv=0x08010002u;
    if((morphWeights.materialFeatures&projectedHairReferenceUv)==projectedHairReferenceUv&&gl_Position.w>0.0) {
        vec2 halfViewport=camera.clusterDepth.zw*.5;
        precise vec2 window=(gl_Position.xy/gl_Position.w)*halfViewport+halfViewport;
        precise vec2 snapped=roundEven(window*256.0)/256.0+vec2(1.0/2048.0);
        precise vec2 ndc=(snapped-halfViewport)/halfViewport;
        gl_Position.xy=ndc*gl_Position.w;
    }
'''
probe=out/'mesh.vert'
probe.write_text(source.replace(anchor,replacement),encoding='utf-8')
blocked={'AZURE_SNAPSHOT_DEPTH=1','AZURE_REFERENCE_SCENE_VISIBILITY=1','AZURE_OUTLINE_MASK=1',
    'AZURE_COMPUTE_SKINNING=1','AZURE_SURFACE_RADIANCE_REUSE=1','AZURE_BINDLESS=1'}
programs={}
for row in manifest['programs']:
    defines=set(row['defines'])
    if row['source']!='mesh.vert' or 'AZURE_REFERENCE_CAMERA=1' not in defines or blocked.intersection(defines):
        continue
    name=row['output']
    base=[str(sdk/'glslc.exe'),*row['arguments'],*('-D'+flag for flag in row['defines'])]
    test=out/'original.spv'
    subprocess.run([*base,str(shader),'-o',str(test)],check=True)
    original=digest(build/'shaders'/name)
    assert digest(test)==original,name
    test.unlink()
    target=out/name
    command=[*base,'-I'+str(shader.parent),str(probe),'-o',str(target)]
    subprocess.run(command,check=True)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(target)],check=True)
    assert digest(target)!=original
    programs[name]=dict(baselineSha256=original,probeSha256=digest(target),command=command)
assert len(programs)>=2
(out/'compiled.json').write_text(json.dumps(dict(sourceSha256=digest(probe),stage='beauty vertex only',programs=programs),indent=2)+'\n')
print(json.dumps(list(programs)))
