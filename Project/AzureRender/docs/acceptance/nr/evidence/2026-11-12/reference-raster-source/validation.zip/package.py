from hashlib import sha256
from pathlib import Path
import json
import zipfile

import numpy as np


run=Path(__file__).resolve().parent
engine=run.parents[2]
evidence=engine/'docs/acceptance/nr/evidence/2026-11-12/reference-raster-source'
devices=('nvidia','intel')
modes=('grid','body')


def load(path):
    return json.loads(path.read_text())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


lease=load(run/'lease-released.json')
assert lease['state']=='released' and lease['token']==load(run/'lease-held.json')['token']
predecessor=load(run/'predecessor-receipt.json')
assert predecessor['state']=='released' and predecessor['token']!=lease['token']
report=load(run/'raster-source-gate.json')
assert report['overallStatus']=='failed-user-review'
assert report['gridUnchangedReferencePlanes']==all(row['exact'] for case in report['cases']['grid'].values() for row in case['planes'].values())
paths=[run/name for name in ('task-card.json','queued-diagnostics.py','diagnostics-capture.py',
    'shader_files.py','lease-held.json','lease-released.json','predecessor-receipt.json','raster-source-gate.json',
    'next-reference-normal-material-constants.py','next-reference-normal-material-constants.json',
    'next-hair-raster-lod-hypothesis.py','next-hair-raster-lod-hypothesis.json',
    'compare-grid-whole-frame.py','grid/whole-frame-change.json','compare-grid-spirv-decorations.py',
    'grid/spirv-decoration-comparison.json','baseline-body-scope-check.py','gpu-controller.log')]
for mode in modes:
    folder=run/mode
    compiled=load(folder/'shader-probe/compiled.json')
    programs=compiled['programs']
    assert len(programs)==(4 if mode=='grid' else 2)
    journal=load(folder/'shader-journal.json')
    restore=load(folder/'shader-restoration.json')
    assert restore['status']=='restored' and restore['files']==895
    assert len(journal['active'])==895
    source=folder/'shader-probe'/('mesh.vert' if mode=='grid' else 'reference_scene_depth.frag')
    assert digest(source)==compiled['sourceSha256']
    for name,entry in programs.items():
        assert digest(folder/'shader-probe'/name)==entry['probeSha256']==journal['active'][name]
    paths.extend([source,folder/'shader-probe/compiled.json',folder/'shader-journal.json',
        folder/'shader-restoration.json',folder/'compact-capture.py'])
    paths.extend(folder/'shader-probe'/name for name in sorted(programs))
    for device in devices:
        case=report['cases'][mode][device]
        execution=load(folder/(device+'-execution.json'))
        assert execution['status']=='exited' and execution['exitCode']==0
        assert case==load(folder/(device+'-results.json'))
        assert case['validationClean'] and case['allocatorZero']
        assert len(case['planes'])==5 and len(case['colors'])==3
        assert case['unchangedReferenceGeometry']==all(case['planes'][name]['exact'] for name in ('raster','hardware','objectIds'))
        packed=np.fromfile(folder/(device+'-rgb.bin'),'<u2').reshape(17017,11)
        errors=np.abs(packed[:,5:8].astype('i4')-packed[:,8:11]).max(axis=1)
        assert case['colors'][0]['overOne']==int((errors>1).sum())
        assert case['colors'][0]['maximum']==int(errors.max())
        if mode=='body':
            body=case['receiver']['328']
            assert body['samples']==9116
            table=np.fromfile(folder/(device+'-receiver.bin'),'<u4').reshape(49384,9)
            target,before,after,owners=table[:,[2,3,4,7]].astype('i4').T
            select=owners==328
            assert body['baselineOverOne']==int(((np.abs(before-target)>1)&select).sum())
            assert body['overOne']==int(((np.abs(after-target)>1)&select).sum())
            old_normal,new_normal,target_normal=table[:,[5,6,8]].T
            for name,values in (('baselineNormalOverOne',old_normal),('normalOverOne',new_normal)):
                error=np.maximum(*[np.abs(((values>>bit)&1023).astype('i4')-
                    ((target_normal>>bit)&1023).astype('i4')) for bit in (0,10)])
                assert body[name]==int(((error>1)&select).sum())
            paths.append(folder/(device+'-receiver.bin'))
        for name in ('command.json','execution.json','results.json','rgb.bin'):
            paths.append(folder/(device+'-'+name))
        paths.append(folder/(device+'.log'))
        frames=folder/(device+'-frames')
        paths.extend(frames/name for name in ('capture_manifest.json','gpu_capabilities.json','reference-planes.json'))
production=run.parent/'20261112-182312-projected-hair-point-mip-82adc1'
controls=(production/'next-reference-raster-grid.py',production/'next-reference-raster-grid.json',
    production/'next-precision-edge.py',production/'next-precision-edge.json',
    production/'next-grid-compile.py',production/'next-body-compile.py')
evidence.mkdir(parents=True,exist_ok=False)
archive_path=evidence/'validation.zip'
with zipfile.ZipFile(archive_path,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(set(paths+[Path(__file__)])):
        archive.write(path,path.relative_to(run).as_posix())
    for path in controls:
        archive.write(path,'viewport-controls/'+path.name)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    count=len(archive.namelist())
raw=archive_path.read_bytes()
assert len(raw)<8*1024**2
report.update(status='qualified-independent-raster-sources',lease=lease,predecessor=predecessor,
    gridWholeFrameChange=load(run/'grid/whole-frame-change.json'),
    gridSpirvDecorationComparison=load(run/'grid/spirv-decoration-comparison.json'),
    sourceCommit=load(run/'task-card.json')['sourceBase'],
    archive=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw),members=count))
(evidence/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['archive']))



