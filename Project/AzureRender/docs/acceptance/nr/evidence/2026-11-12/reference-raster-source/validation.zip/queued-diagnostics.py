
from pathlib import Path
import json
import os
import subprocess
import sys
import time
import traceback

from shader_files import catalog, locations, shader_files


run=Path(__file__).resolve().parent
build=run.parents[1]
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')


def capture(mode):
    folder=run/mode
    with shader_files(run,folder):
        for device in ('nvidia','intel'):
            os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*' if device=='intel' else '*nv-vk64*'
            argv=[sys.executable,'-B',str(run/'diagnostics-capture.py'),mode,device]
            result=shared.maintenance.guarded_run(build,run.name,argv,330)
            write(folder/(device+'-execution.json'),result)
            print(json.dumps(result),flush=True)
            assert result['status']=='exited' and result['exitCode']==0,result
            subprocess.run([sys.executable,'-B',str(folder/'compact-capture.py'),device+'-frames'],check=True)
    restoration=json.loads((folder/'shader-restoration.json').read_text())
    assert restoration['status']=='restored' and restoration['files']==895
    return {device:json.loads((folder/(device+'-results.json')).read_text()) for device in ('nvidia','intel')}


predecessor,receipt_path=sys.argv[1:]
deadline=time.monotonic()+1800
while time.monotonic()<deadline:
    try:
        state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
        receipt=json.loads(Path(receipt_path).read_text())
    except (OSError,ValueError):
        time.sleep(1)
        continue
    assert state['token']==receipt['token']==predecessor
    if state['state']==receipt['state']=='released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed reference raster source window has not opened')
write(run/'predecessor-receipt.json',receipt)
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key,None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
lease=None
try:
    with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-reference-raster-source-gpu',run) as lease:
        write(run/'lease-held.json',lease)
        results={}
        for mode in ('grid','body'):
            try:
                results[mode]=capture(mode)
            except Exception:
                write(run/(mode+'-failure.json'),dict(traceback=traceback.format_exc()))
                shaders,baseline=locations(run)
                assert catalog(shaders)==baseline
        if len(results)!=2:
            raise RuntimeError(f'Valid captures completed for {list(results)}. See the saved failures.')
        grid=results['grid']
        body=results['body']
        gate=dict(overallStatus='failed-user-review',cases=results,
            gridUnchangedReferencePlanes=all(row['exact'] for result in grid.values() for row in result['planes'].values()),
            gridNvidiaPass=all(row['overOne']==0 for row in grid['nvidia']['colors']),
            gridIntelImproved=all(row['overOne']<32 for row in grid['intel']['colors']),
            bodyUnchangedReferenceGeometry=all(result['unchangedReferenceGeometry'] for result in body.values()),
            bodyVisibilityRExact=all(result['visibilityRExact'] for result in body.values()),
            bodyScopedNormals=all(not row['normalsChanged'] for result in body.values()
                for name,row in result['receiver'].items() if name!='328'),
            bodyRegion={name:result['receiver']['328'] for name,result in body.items()})
        write(run/'raster-source-gate.json',gate)
        print(json.dumps(gate),flush=True)
finally:
    if lease is not None:
        write(run/'lease-released.json',lease)
