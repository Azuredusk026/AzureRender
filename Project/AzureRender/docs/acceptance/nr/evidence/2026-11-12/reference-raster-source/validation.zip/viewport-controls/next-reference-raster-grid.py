
from hashlib import sha256
from pathlib import Path
import json
import numpy as np


out=Path(__file__).resolve().parent
source=out.parent/'20261111-232828-scene-reference-normal-60ddfa'
record=json.loads((source/'normal-vertex-comparison.json').read_text())
path=Path(record['nativePath'])
raw=path.read_bytes()
assert sha256(raw).hexdigest()==record['nativeSha256']
vertices=np.frombuffer(raw,'<f4').reshape(-1,23)
assert len(vertices)==11564 and np.isfinite(vertices[:,:4]).all()
assert (vertices[:,3]>0).all()
half=np.array([1280,720],dtype='f4')
basis=np.array([1,-1],dtype='f4')
clip=vertices[:,:2]*basis
w=vertices[:,3:4]
native_window=(clip.astype('f8')/w.astype('f8'))*half+half
snapped=np.rint(native_window*256).astype('i8')
grid=snapped.astype('f4')*(1/256)
variants={}
for offset in (0,1/2048,1/1024,1/512):
    desired=(grid+offset).astype('f4')
    ndc=(desired-half)/half
    adjusted=(ndc*w).astype('f4')
    viewport_wide=(adjusted.astype('f8')/w.astype('f8'))*half+half
    viewport_single=(adjusted/w)*half+half
    methods={}
    for name,window in (('wide',viewport_wide),('float32',viewport_single)):
        nearest=np.rint(window*256).astype('i8')
        floor=np.floor(window*256).astype('i8')
        methods[name]=dict(nearestExact=int(np.all(nearest==snapped,axis=1).sum()),
            floorExact=int(np.all(floor==snapped,axis=1).sum()),maxWindowError=float(np.abs(window-desired).max()))
    variants[str(offset)]=methods
report=dict(vertices=len(vertices),grid=256,sourceSha256=record['nativeSha256'],variants=variants)
(out/'next-reference-raster-grid.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
