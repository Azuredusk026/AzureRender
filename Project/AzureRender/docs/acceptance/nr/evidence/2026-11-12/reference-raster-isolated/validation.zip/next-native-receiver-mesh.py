from hashlib import file_digest
from pathlib import Path
import json
import os
import subprocess
import sys


out=Path(sys.argv[1]).resolve(strict=True)
preflight='--preflight' in sys.argv
worker=Path(__file__).resolve().with_name('next-native-receiver-mesh-worker.py')
source=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc')
renderdoc=Path('D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe')
expected='fa2ca267f7168f5603e83ad5f817a3074d8dbee23a216e6ab8ef2c340ec06a90'


def digest(path):
    with path.open('rb') as file:
        return file_digest(file,'sha256').hexdigest()


assert digest(source)==expected and worker.is_file() and renderdoc.is_file()
if preflight:
    print(json.dumps(dict(captureSha256=expected,workerSha256=digest(worker),renderdocSha256=digest(renderdoc))))
    raise SystemExit(0)
folder=out/'native-receiver-mesh'
folder.mkdir()
request=folder/'request.json'
request.write_text(json.dumps(dict(output=str(folder),capture=str(source),captureSha256=expected,
    events=((328,17037),(345,8718),(377,102882))),indent=2)+'\n')
command=[str(renderdoc),'--python',str(worker)]
(folder/'command.json').write_text(json.dumps(command,indent=2)+'\n')
env=os.environ.copy()
for name in ('VK_INSTANCE_LAYERS','VK_LAYER_PATH','ENABLE_VULKAN_RENDERDOC_CAPTURE',
    'VK_LOADER_DRIVERS_SELECT','VK_DRIVER_FILES','VK_ICD_FILENAMES'):
    env.pop(name,None)
env['AZURE_RECEIVER_MESH_REQUEST']=str(request)
startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
with (folder/'process.log').open('wb') as log:
    process=subprocess.run(command,cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT,
        startupinfo=startup,timeout=240)
report=json.loads((folder/'native-receiver-mesh.json').read_text())
assert process.returncode==0 and report['status']=='qualified',report
assert digest(source)==expected
print(json.dumps(report))


