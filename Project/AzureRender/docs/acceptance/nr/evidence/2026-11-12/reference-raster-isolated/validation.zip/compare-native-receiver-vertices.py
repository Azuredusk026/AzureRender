from hashlib import sha256
from pathlib import Path
import json
import zlib

import numpy as np


run=Path(__file__).resolve().parent
root=run/'native-receiver-mesh'
manifest=json.loads((root/'native-receiver-mesh.json').read_text())['devices']
topology=json.loads((run/'cloth-topology-coverage.json').read_text())
previous=run.parent/'20261112-213454-reference-raster-source-a825da/body'
atlas=run.parent/'20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry/native-caster-geometry.json'
atlas_index=json.loads(atlas.read_text())['atlasDraws']['191']['indexData']['rawSha256']


def payload(entry):
    blob=(root/entry['path']).read_bytes()
    assert sha256(blob).hexdigest()==entry['sha256']
    raw=zlib.decompress(blob)
    assert len(raw)==entry['rawBytes'] and sha256(raw).hexdigest()==entry['rawSha256']
    return raw


result={}
for event in ('328','345','377'):
    n,i=(manifest[device]['events'][event] for device in ('nvidia','intel'))
    assert (n['signature'],n['vertices'],n['vertexStride'])==(i['signature'],i['vertices'],i['vertexStride'])
    index=payload(n['indexData'])
    assert index==payload(i['indexData'])
    if event=='377':
        assert sha256(index).hexdigest()==atlas_index
    left,right=(np.frombuffer(payload(row['vertexData']),'<f4').reshape(row['vertices'],-1) for row in (n,i))
    layout=sorted(n['signature'],key=lambda row:row['system']!='ShaderBuiltin.Position')
    assert sum(row['count'] for row in layout)==left.shape[1]
    fields={}
    offset=0
    for slot in layout:
        label=slot['name']+str(slot['index'])
        count=slot['count']
        a,b=(values[:,offset:offset+count] for values in (left,right))
        assert np.isfinite(a).all() and np.isfinite(b).all()
        equal=(a.view('<u4')==b.view('<u4'))
        fields[label]=dict(exactComponents=equal.sum(axis=0).tolist(),exactRows=int(equal.all(axis=1).sum()),
            maximumAbsolute=np.abs(a.astype('f8')-b).max(axis=0).tolist())
        offset+=count
    result[event]=dict(indicesSha256=n['indexData']['rawSha256'],vertices=n['vertices'],fields=fields)

for device,row in topology.items():
    probe=np.fromfile(previous/(device+'-receiver.bin'),'<u4').reshape(49384,9)
    region=probe[probe[:,7]==377]
    assert len(region)==16629
    candidate=set(map(tuple,row['candidatePositions']))
    x,y,target,old,*_=region.T.astype('i8')
    hits=np.array([(int(px),int(py)) in candidate for px,py in zip(x,y)])
    assert int(hits.sum())==53
    bad=np.abs(old-target)>1
    assert int(bad.sum())==(158 if device=='nvidia' else 223)
    row.update(receiverOverOne=int(bad.sum()),nativeUnmatchedCoverageOverOne=int((hits&bad).sum()),
        overOneOutsideNativeUnmatchedCoverage=int((~hits&bad).sum()))
(run/'receiver-mesh-comparison.json').write_text(json.dumps(dict(events=result,cloth=topology),indent=2)+'\n')
print(json.dumps(dict(events={event:{'vertices':row['vertices'],'clip':row['fields'][next(iter(row['fields']))]}
        for event,row in result.items()},
    cloth={device:{k:v for k,v in row.items() if k!='candidatePositions'} for device,row in topology.items()})))

