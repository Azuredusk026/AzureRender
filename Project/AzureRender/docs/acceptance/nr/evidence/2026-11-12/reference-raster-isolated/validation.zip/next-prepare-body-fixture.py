from hashlib import file_digest, sha256
from pathlib import Path
from shutil import copyfile
import json
import struct
import sys


run=Path(sys.argv[1]).resolve(strict=True)
preflight='--preflight' in sys.argv
baseline=run.parent/'20261112-182312-projected-hair-point-mip-82adc1'
fixture=run/'hair-project'
source=baseline/'hair-project'
manifest=json.loads((baseline/'fixture-inputs.json').read_text())['files']
assert len(manifest)==45


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def patch(raw):
    magic,version,length,json_size,kind=struct.unpack_from('<4sIII4s',raw)
    assert (magic,version,length,kind)==(b'glTF',2,len(raw),b'JSON')
    document=json.loads(raw[20:20+json_size])
    material,=[m for m in document['materials'] if m['name']=='M_actor_laevat_body_01']
    profile=material['extras']['azureRenderMaterial']
    assert profile['schemaVersion']==2 and profile['class']=='skin'
    assert 'referenceNormal' not in profile and material.get('doubleSided')
    normal=document['textures'][material['normalTexture']['index']]
    assert document['images'][normal['source']]['uri']=='native-captured-body/t15.dds'
    profile['referenceNormal']={'schemaVersion':1,'encoding':'sampled-rg'}
    encoded=json.dumps(document,separators=(',',':')).encode()
    encoded+=b' '*(-len(encoded)%4)
    assert profile.pop('referenceNormal')['encoding']=='sampled-rg'
    assert document==json.loads(raw[20:20+json_size])
    binary=raw[20+json_size:]
    new=struct.pack('<4sIII4s',magic,version,20+len(encoded)+len(binary),len(encoded),kind)+encoded+binary
    assert new[20+len(encoded):]==binary
    return new,sha256(binary).hexdigest()


changed=[]
for item in manifest:
    relative=Path(item['relative'])
    original=source/relative
    assert original.resolve(strict=True).is_relative_to(source.resolve())
    assert original.stat().st_size==item['bytes'] and digest(original)==item['sha256']
    path=fixture/relative
    if not preflight:
        path.parent.mkdir(parents=True,exist_ok=True)
    if relative.as_posix()!='character/hair-coverage.glb':
        if not preflight:
            copyfile(original,path)
            assert digest(path)==item['sha256']
        continue
    raw=original.read_bytes()
    new,payload=patch(raw)
    if not preflight:
        with path.open('xb') as stream:
            stream.write(new)
        assert digest(path)==sha256(new).hexdigest()
    changed.append(dict(relative=item['relative'],originalSha256=item['sha256'],
        candidateSha256=sha256(new).hexdigest(),unchangedPayloadSha256=payload))
assert len(changed)==1
if not preflight:
    files=[dict(relative=p.relative_to(fixture).as_posix(),bytes=p.stat().st_size,sha256=digest(p))
        for p in sorted(fixture.rglob('*')) if p.is_file()]
    assert len(files)==45
    (run/'fixture-inputs.json').write_text(json.dumps(dict(files=files,changed=changed),indent=2)+'\n')
print(json.dumps(dict(files=len(manifest),changed=changed)))

