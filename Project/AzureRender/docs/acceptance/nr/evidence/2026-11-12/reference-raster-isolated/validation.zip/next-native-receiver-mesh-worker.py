from array import array
from hashlib import sha256
from pathlib import Path
import json
import os
import traceback
import zlib

import renderdoc as rd


request = json.loads(Path(os.environ['AZURE_RECEIVER_MESH_REQUEST']).read_text(encoding='utf-8'))
out = Path(request['output'])
capture = rd.OpenCaptureFile()
report = dict(status='failed', devices={})


def emit(path, raw):
    encoded = zlib.compress(raw, 6)
    path.write_bytes(encoded)
    return dict(path=str(path.relative_to(out)), bytes=len(encoded), sha256=sha256(encoded).hexdigest(),
        rawBytes=len(raw), rawSha256=sha256(raw).hexdigest())


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


def signature(rows):
    return [dict(name=row.semanticName,index=row.semanticIndex,count=row.compCount,
        system=str(row.systemValue)) for row in rows]


def collect(gpu, folder):
    options = rd.ReplayOptions()
    options.forceGPUVendor = gpu.vendor
    options.forceGPUDeviceID = gpu.deviceID
    result, controller = capture.OpenCapture(options, None)
    assert result == rd.ResultCode.Succeeded and controller
    try:
        properties = controller.GetAPIProperties()
        assert properties.vendor == gpu.vendor and properties.pipelineType == rd.GraphicsAPI.D3D11 and not properties.degraded
        actions = {action.eventId:action for action in walk(controller.GetRootActions())}
        summary = dict(device=gpu.name, deviceID=gpu.deviceID, events={})
        for event,count in request['events']:
            action = actions[event]
            assert action.numIndices == count and action.numInstances == 1
            controller.SetFrameEvent(event,True)
            pipeline = controller.GetPipelineState()
            assert str(pipeline.GetDepthTarget().resource) == 'ResourceId::141967'
            reflection = pipeline.GetShaderReflection(rd.ShaderStage.Vertex)
            pixel = pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
            mesh = controller.GetPostVSData(0,0,rd.MeshDataStage.VSOut)
            assert mesh.numIndices == count and mesh.indexByteStride in (2,4) and mesh.vertexByteStride % 4 == 0
            indices = bytes(controller.GetBufferData(mesh.indexResourceId,mesh.indexByteOffset,count*mesh.indexByteStride))
            words = array('H' if mesh.indexByteStride == 2 else 'I')
            words.frombytes(indices)
            assert len(words) == count and min(words)+mesh.baseVertex >= 0
            vertex_count = max(words)+mesh.baseVertex+1
            vertices = bytes(controller.GetBufferData(mesh.vertexResourceId,mesh.vertexByteOffset,vertex_count*mesh.vertexByteStride))
            assert len(vertices) == vertex_count*mesh.vertexByteStride
            viewport = pipeline.GetViewport(0)
            summary['events'][event] = dict(numIndices=count, indexStride=mesh.indexByteStride,
                baseVertex=mesh.baseVertex, vertexStride=mesh.vertexByteStride, vertices=vertex_count,
                vertexProgramSha256=sha256(bytes(reflection.rawBytes)).hexdigest(),
                pixelProgramSha256=sha256(bytes(pixel.rawBytes)).hexdigest(),
                signature=signature(reflection.outputSignature), pixelInput=signature(pixel.inputSignature),
                viewport=[viewport.x,viewport.y,viewport.width,viewport.height,viewport.minDepth,viewport.maxDepth],
                vertexData=emit(folder/f'{event}-vertices.zlib',vertices), indexData=emit(folder/f'{event}-indices.zlib',indices))
        summary['messages'] = [str(message.description) for message in controller.GetDebugMessages()]
        return summary
    finally:
        controller.Shutdown()


try:
    assert capture.OpenFile(request['capture'],'',None) == rd.ResultCode.Succeeded
    available = capture.GetAvailableGPUs()
    for name,vendor,device in (('nvidia',rd.GPUVendor.nVidia,0x28e0),('intel',rd.GPUVendor.Intel,0xa788)):
        candidates = [gpu for gpu in available if gpu.vendor == vendor and gpu.deviceID == device and rd.GraphicsAPI.D3D11 in gpu.apis]
        assert candidates,[(gpu.name,gpu.deviceID) for gpu in available]
        folder = out/name
        folder.mkdir()
        report['devices'][name] = collect(candidates[0],folder)
    report['status'] = 'qualified'
except Exception:
    report['error'] = traceback.format_exc()
finally:
    capture.Shutdown()
    (out/'native-receiver-mesh.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)


