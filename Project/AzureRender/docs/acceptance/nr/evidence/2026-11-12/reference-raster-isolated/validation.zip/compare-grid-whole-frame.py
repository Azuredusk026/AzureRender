from hashlib import sha256
from pathlib import Path
import json
import runpy

import numpy as np
from PIL import Image


run=Path(__file__).resolve().parent
base=run.parent/'20261112-182312-projected-hair-point-mip-82adc1'
color=runpy.run_path(str(run.parent/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
x0,y0,x1,y1=(color[name] for name in ('x0','y0','x1','y1'))
mask=np.zeros((1440,2560),dtype=bool)
mask[y0:y1,x0:x1]=color['mask']
assert int(mask.sum())==17017
result={}
for device in ('nvidia','intel'):
    report=json.loads((run/'grid'/f'{device}-results.json').read_text())
    paths=(base/f'release-{device}-frames/frame_000000.png',run/'grid'/f'{device}-frames/frame_000000.png')
    for path,field in zip(paths,('baselineSha256','sha256')):
        assert sha256(path.read_bytes()).hexdigest()==report['colors'][0][field]
    before,after=(np.asarray(Image.open(path).convert('RGB'),dtype='i2') for path in paths)
    error=np.abs(before-after).max(axis=2)
    result[device]={}
    for name,area in (('whole',np.ones_like(mask)),('frozen',mask),('outsideFrozen',~mask)):
        region=(error>0)&area
        points=np.argwhere(region)
        count=int(region.sum())
        result[device][name]=dict(changed=count,overOne=int(((error>1)&area).sum()),
            maximum=int(error[area].max()),boxXYXY=([int(points[:,1].min()),int(points[:,0].min()),
                int(points[:,1].max()),int(points[:,0].max())] if count else None),
            hist=np.bincount(error[region]).tolist())
    assert result[device]['outsideFrozen']['changed']==report['colors'][0]['outsideMaskRgbChanged']
(run/'grid/whole-frame-change.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({device:{name:{k:v for k,v in data.items() if k!='hist'} for name,data in row.items()} for device,row in result.items()}))

