from pathlib import Path
import json
import os
import subprocess
import sys
import time
import traceback

from shader_files import catalog, locations, shader_files


run=Path(__file__).resolve().parent
build=run.parents[1]
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')


def managed(script, label, output, timeout, *args):
    argv=[sys.executable,'-B',str(run/script),*map(str,args)]
    result=shared.maintenance.guarded_run(build,run.name,argv,timeout)
    write(output/(label+'-execution.json'),result)
    print(json.dumps(result),flush=True)
    assert result['status']=='exited' and result['exitCode']==0,result


def capture_grid():
    folder=run/'grid'
    with shader_files(run,folder):
        for device in ('nvidia','intel'):
            os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*' if device=='intel' else '*nv-vk64*'
            managed('diagnostics-capture.py',device,folder,330,'grid',device)
            subprocess.run([sys.executable,'-B',str(folder/'compact-capture.py'),device+'-frames'],check=True)
    restoration=json.loads((folder/'shader-restoration.json').read_text())
    assert restoration['status']=='restored' and restoration['files']==895
    subprocess.run([sys.executable,'-B',str(run/'compare-grid-whole-frame.py')],check=True)


def receiver_native():
    managed('next-native-receiver-mesh.py','native-receiver-mesh',run,310,run)


def receiver_sources():
    managed('next-production-receiver-source-isolation.py','receiver-source-isolation',run,180,run)


predecessor,receipt_path=sys.argv[1:]
deadline=time.monotonic()+1800
while time.monotonic()<deadline:
    try:
        state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
        receipt=json.loads(Path(receipt_path).read_text())
    except (OSError,ValueError):
        time.sleep(1)
        continue
    assert state['token']==receipt['token']==predecessor
    if state['state']==receipt['state']=='released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed raster and receiver source window has not opened')
write(run/'predecessor-receipt.json',receipt)
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key,None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
lease=None
try:
    with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-reference-raster-isolated-gpu',run) as lease:
        write(run/'lease-held.json',lease)
        results={}
        for label,command in (('grid',capture_grid),('native-receiver-mesh',receiver_native),('receiver-source-isolation',receiver_sources)):
            try:
                command()
                results[label]='qualified-execution'
            except Exception:
                write(run/(label+'-failure.json'),dict(traceback=traceback.format_exc()))
                results[label]='failed-execution'
                shaders,baseline=locations(run)
                assert catalog(shaders)==baseline
            write(run/'execution-states.json',results)
        assert all(status=='qualified-execution' for status in results.values()),results
finally:
    if lease is not None:
        write(run/'lease-released.json',lease)

