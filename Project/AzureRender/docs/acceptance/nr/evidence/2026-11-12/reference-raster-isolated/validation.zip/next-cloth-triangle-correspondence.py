from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import struct
import zlib

import numpy as np


out = Path(__file__).resolve().parent
runs = out.parent
scene = runs / '20261112-182312-projected-hair-point-mip-82adc1/hair-project/character/hair-coverage.glb'
evidence = runs / '20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry'
native = json.loads((evidence / 'native-caster-geometry.json').read_text())['atlasDraws']['191']
assert native['signature'][0] == dict(name='TEXCOORD', index=0, count=2, system='ShaderBuiltin.Undefined')


def decode_native(field):
    item = native[field]
    compressed = (evidence / item['path']).read_bytes()
    assert sha256(compressed).hexdigest() == item['sha256']
    raw = zlib.decompress(compressed)
    assert len(raw) == item['rawBytes'] and sha256(raw).hexdigest() == item['rawSha256']
    return raw


raw = scene.read_bytes()
assert sha256(raw).hexdigest() == '9aba6b5a8e67919ad6bb22ae7524639c39b4466e3f52058bd4c3dfc8e80d7285'
magic, version, size, json_size, kind = struct.unpack_from('<4sIII4s', raw)
assert (magic, version, size, kind) == (b'glTF', 2, len(raw), b'JSON')
document = json.loads(raw[20:20+json_size])
buffer_size, buffer_kind = struct.unpack_from('<I4s', raw, 20+json_size)
assert buffer_kind == b'BIN\0'
buffer_offset = 28 + json_size
mesh, = (mesh for mesh in document['meshes'] if mesh['name'] == 'S_actor_laevat_cloth_01_lod0')
primitive, = mesh['primitives']
assert primitive.get('mode', 4) == 4


def accessor(index, components, kind, datatype):
    row = document['accessors'][index]
    assert (row['type'], row['componentType']) == (kind, datatype) and 'sparse' not in row
    view = document['bufferViews'][row['bufferView']]
    assert view['buffer'] == 0
    dtype = np.dtype({5123:'<u2', 5125:'<u4', 5126:'<f4'}[datatype])
    stride = view.get('byteStride', dtype.itemsize * components)
    offset = view.get('byteOffset', 0) + row.get('byteOffset', 0)
    assert offset + (row['count']-1)*stride + dtype.itemsize*components <= buffer_size
    return np.ndarray((row['count'],components), dtype, raw, buffer_offset+offset, (stride,dtype.itemsize))


source_uv = accessor(primitive['attributes']['TEXCOORD_0'], 2, 'VEC2', 5126)
source_indices = accessor(primitive['indices'], 1, 'SCALAR',
    document['accessors'][primitive['indices']]['componentType']).reshape(-1,3)
native_uv = np.frombuffer(decode_native('vertexData'),'<f4').reshape(native['vertices'],-1)[:,4:6].copy()
native_uv[:,1] = 1 - native_uv[:,1]
assert native['baseVertex'] == 0 and native['indexStride'] == 2
native_indices = np.frombuffer(decode_native('indexData'),'<u2').reshape(-1,3)
assert (source_indices.size, native_indices.size) == (102927,102882)


def match(source, target):
    overlap = source & target
    return dict(nativeTotal=target.total(), fixtureTotal=source.total(), overlap=overlap.total(),
        nativeOnly=(target-overlap).total(), fixtureOnly=(source-overlap).total())


def key_uv(values, precision):
    if precision == 'float16':
        words = values.astype('<f2').view('<u2').astype('u4')
        return words[:,0] | (words[:,1] << 16)
    values = np.rint(values.astype('f8')*precision).astype('<i4')
    words = values.view('<u4').astype('u8')
    return words[:,0] | (words[:,1] << 32)


def compare(precision):
    source = key_uv(source_uv, precision)
    target = key_uv(native_uv, precision)
    source_triangles = [tuple(row) for row in np.sort(source[source_indices], axis=1).tolist()]
    target_triangles = [tuple(row) for row in np.sort(target[native_indices], axis=1).tolist()]
    source_counts, target_counts = Counter(source_triangles), Counter(target_triangles)
    shared_unique = {row for row,count in source_counts.items() if count == target_counts[row] == 1}
    source_primitives = {row:index for index,row in enumerate(source_triangles) if row in shared_unique}
    target_primitives = {row:index for index,row in enumerate(target_triangles) if row in shared_unique}
    same_order = reversed_order = degenerate = 0
    for row in shared_unique:
        native_order = target[native_indices[target_primitives[row]]].tolist()
        fixture_order = source[source_indices[source_primitives[row]]].tolist()
        if len(set(native_order)) < 3:
            degenerate += 1
            continue
        rotation = fixture_order.index(native_order[0])
        fixture_order = fixture_order[rotation:] + fixture_order[:rotation]
        if native_order == fixture_order:
            same_order += 1
        else:
            assert native_order == [fixture_order[0],fixture_order[2],fixture_order[1]]
            reversed_order += 1
    return dict(vertices=match(Counter(source.tolist()),Counter(target.tolist())),
        triangles=match(source_counts,target_counts), unique=len(shared_unique), sameOrder=same_order,
        reversedOrder=reversed_order, uvDegenerate=degenerate)


result = dict(nativeAtlasEvent=191, expectedCameraEvent=377, fixtureSha256=sha256(raw).hexdigest(),
    nativeIndexSha256=native['indexData']['rawSha256'], nativeVertexSha256=native['vertexData']['rawSha256'],
    flippedV=True, comparisons={str(precision):compare(precision) for precision in ('float16',4096,16384,65536)})
(out/'next-cloth-triangle-correspondence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

