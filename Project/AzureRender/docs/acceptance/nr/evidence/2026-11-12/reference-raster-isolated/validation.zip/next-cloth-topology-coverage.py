from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import sys
import zlib

import numpy as np


source=Path(__file__).resolve().parent/'next-cloth-triangle-correspondence.py'
scope={'__file__':str(source)}
exec(compile(source.read_text().split('\nresult = dict(nativeAtlasEvent',1)[0],str(source),'exec'),scope)
root=Path(sys.argv[1]).resolve(strict=True)
runs=root.parent
project=runs/'20261112-182312-projected-hair-point-mip-82adc1'
raster=root/'native-receiver-mesh'
manifest=json.loads((raster/'native-receiver-mesh.json').read_text())
assert manifest['status']=='qualified'
source_uv,source_indices,key_uv=(scope[key] for key in ('source_uv','source_indices','key_uv'))
numeric=runs/'20261110-003435-visibility-numeric-contract-4f95e7'
samples=np.fromfile(numeric/'receiver-queries.bin','<f4').reshape(-1,4)[:,:2].astype('i4')
expected=np.fromfile(numeric/'receiver-expected.bin','<u4').astype('i4')
owners=np.zeros((310,290),dtype='u2')
normals=np.zeros_like(owners,dtype='<u4')
owner_source=runs/'20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
owner_manifest=json.loads((owner_source/'native-atlas-producers.json').read_text())['receiverNormal']['stages']
for event,row in owner_manifest.items():
    entry=row['crop']
    blob=(owner_source/entry['path']).read_bytes()
    assert sha256(blob).hexdigest()==entry['sha256']
    next_normals=np.frombuffer(zlib.decompress(blob),'<u4').reshape(310,290)
    owners[next_normals!=normals]=int(event)
    normals=next_normals
sx,sy=samples.T
cloth=owners[sy-1000,sx-1140]==377
assert len(samples)==49384 and int(cloth.sum())==16629


def load_data(row,field):
    item=row[field]
    encoded=(raster/item['path']).read_bytes()
    assert sha256(encoded).hexdigest()==item['sha256']
    raw=zlib.decompress(encoded)
    assert len(raw)==item['rawBytes'] and sha256(raw).hexdigest()==item['rawSha256']
    return raw


def rasterize_hits(triangles,pixels):
    matches=np.zeros(len(pixels),dtype='u2')
    points=pixels+.5
    for tri in triangles:
        a,b,c=tri
        ab=b-a
        ac=c-a
        determinant=ab[0]*ac[1]-ab[1]*ac[0]
        if abs(determinant)<1.e-12:
            continue
        minimum=tri.min(axis=0)
        maximum=tri.max(axis=0)
        candidates=np.flatnonzero(np.all((points>=minimum)&(points<=maximum),axis=1))
        relative=points[candidates]-a
        u=(relative[:,0]*ac[1]-relative[:,1]*ac[0])/determinant
        v=(ab[0]*relative[:,1]-ab[1]*relative[:,0])/determinant
        selected=candidates[(u>=0)&(v>=0)&(u+v<=1)]
        matches[selected]+=1
    return matches


result={}
for device,row in manifest['devices'].items():
    event=row['events']['377']
    assert event['numIndices']==102882 and event['vertexStride']==92
    assert event['signature'][0]['system']=='ShaderBuiltin.Position'
    assert event['signature'][1]['name']=='TEXCOORD' and event['signature'][1]['count']==2
    verts=np.frombuffer(load_data(event,'vertexData'),'<f4').reshape(event['vertices'],-1)
    dtype='<u2' if event['indexStride']==2 else '<u4'
    indices=np.frombuffer(load_data(event,'indexData'),dtype).astype('i4').reshape(-1,3)+event['baseVertex']
    assert indices.min()>=0 and indices.max()<len(verts)
    uv=verts[:,4:6].copy()
    uv[:,1]=1-uv[:,1]
    atlas=key_uv(uv,65536)
    exported=key_uv(source_uv,65536)
    actual_keys=[tuple(row) for row in np.sort(atlas[indices],axis=1).tolist()]
    fixture_keys=[tuple(row) for row in np.sort(exported[source_indices],axis=1).tolist()]
    unmatched=Counter(actual_keys)-Counter(fixture_keys)
    wholly_unmatched=set(unmatched)-set(fixture_keys)
    indices_of_interest=np.array([i for i,key in enumerate(actual_keys) if key in wholly_unmatched])
    assert len(indices_of_interest)<=unmatched.total()
    clip=verts[indices[indices_of_interest],:4].astype('f8')
    assert np.all(clip[...,3]>0)
    x,y,width,height,*_=event['viewport']
    assert (x,y,width,height)==(0,0,2560,1440)
    projected=clip[:,:,:2]/clip[:,:,3:4]*[width/2,-height/2]+[x+width/2,y+height/2]
    exact=rasterize_hits(projected,samples[cloth])
    snapped=rasterize_hits(np.rint(projected*256)/256,samples[cloth])
    coords=samples[cloth][(exact>0)|(snapped>0)]
    result[device]=dict(nativeUnmatched=unmatched.total(),whollyUnmatched=len(indices_of_interest),
        ambiguousUnmatched=unmatched.total()-len(indices_of_interest),exactCoverage=int((exact>0).sum()),
        snappedCoverage=int((snapped>0).sum()),candidatePositions=coords.tolist())
(root/'cloth-topology-coverage.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({device:{name:value for name,value in row.items() if name!='candidatePositions'} for device,row in result.items()}))

