
from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys


out=Path(__file__).resolve().parent
build=out.parents[1]
main=Path('D:/Projects/FYP/Project/AzureRender/build')
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0,str(main.parent/'tools'))
import shared_resources as shared


claim_path=Path('D:/Projects/FYP-coordination/quality-claim.json')
claim=json.loads(claim_path.read_text(encoding='utf-8'))
assert claim['threadId']==owner and claim['state']=='reference-raster-source'
source,parent=subprocess.check_output(['git','log','-1','--format=%H%n%P'],cwd=build.parent,text=True).splitlines()
assert parent==claim['lastCommit']=='48847a4caa9031d7ccc70e90c093c9fab81984a3'
assert source=='eb05be0008bbbc7fc737b925eec079d10b2d6f6b'
folder=build.parent/'docs/acceptance/nr/evidence/2026-11-12/reference-raster-source'
results=json.loads((folder/'results.json').read_text())
assert results['status']=='qualified-independent-raster-sources' and results['lease']['state']=='released'
assert sha256((folder/'validation.zip').read_bytes()).hexdigest()==results['archive']['sha256']
previous=Path(claim['taskPath'])
assert previous.name=='20261112-213454-reference-raster-source-a825da'
old_local,old_main=claim['localInputLease'],claim['inputLease']


def inherited(root,tokens):
    with shared.maintenance.database(root,True) as db:
        records=shared.maintenance.rows(db)
    assert all(records[token]['owner']==owner for token in tokens)
    return list(dict.fromkeys(name for token in tokens for name in records[token]['inputs']))


local_inputs=inherited(build,old_local)+[previous.name]
main_inputs=inherited(main,old_main)
local=shared.acquire_inputs(build,out,local_inputs,owner)
try:
    native=shared.acquire_inputs(main,out,main_inputs,owner)
except Exception:
    shared.release_inputs(build,local,owner)
    raise
claim.update(state='reference-raster-isolated',taskPath=str(out),inputLease=[native],localInputLease=[local],
    nativeCaptureLease=native,lastCommit=source,additionalTaskPaths=[],
    pendingCommand='Verify isolated raster quantization and identify native receiver geometry and source ownership',
    ownedFiles=['docs/acceptance/nr/reference-raster-isolated.md','docs/acceptance/nr/evidence/2026-11-12/reference-raster-isolated'])
claim['observed'].update(gridIntelRgb=31,gridIntelOutsideFrozenOverOne=6121,bodySampledRgNvidia=45,bodySampledRgIntel=77)
(out/'task-card.json').write_text(json.dumps(dict(local=local,main=native,sourceBase=source,plannedBytes=134217728,
    localInputs=local_inputs,mainInputs=main_inputs,change='Function-local precision for the hair viewport grid; native receiver post-vertex and independent attachment substitution',
    gate='Stable two-device reference attachments, whole-frame RGB comparisons, and full receiver attachment identity for replay qualification'),indent=2)+'\n')
temporary=claim_path.with_name(claim_path.name+'.nr-quality-new')
with temporary.open('x',encoding='utf-8') as stream:
    json.dump(claim,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
os.replace(temporary,claim_path)
for token in old_main:
    shared.release_inputs(main,token,owner)
for token in old_local:
    shared.release_inputs(build,token,owner)
print(json.dumps(dict(local=local,main=native,output=str(out))))
