from hashlib import sha256
from pathlib import Path
import json
import zipfile
import zlib

import numpy as np


run=Path(__file__).resolve().parent
engine=run.parents[2]
evidence=engine/'docs/acceptance/nr/evidence/2026-11-12/reference-raster-isolated'
devices=('nvidia','intel')
grid=run/'grid'
native=run/'native-receiver-mesh'


def load(path):
    return json.loads(path.read_text())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


lease=load(run/'lease-released.json')
held=load(run/'lease-held.json')
predecessor=load(run/'predecessor-receipt.json')
assert lease['state']=='released' and held['state']=='held' and lease['token']==held['token']
assert predecessor['state']=='released' and lease['token']!=predecessor['token']
states=load(run/'execution-states.json')
assert set(states)=={'grid','native-receiver-mesh','receiver-source-isolation'}
assert set(states.values())=={'qualified-execution'}
executions={str(p.relative_to(run)):load(p) for p in (*run.glob('*-execution.json'),*grid.glob('*-execution.json'))}
assert len(executions)==4 and all(row['status']=='exited' and row['exitCode']==0 for row in executions.values())
restoration=load(grid/'shader-restoration.json')
assert restoration['status']=='restored' and restoration['files']==895
programs=load(grid/'shader-probe/compiled.json')
assert len(programs['programs'])==4 and digest(grid/'shader-probe/mesh.vert')==programs['sourceSha256']
for name,program in programs['programs'].items():
    assert program['inlineMainDecorations'] in (36,44) and program['isolatedMainDecorations']==0
    assert len(program['isolatedHelperOperations'])==8
    assert digest(grid/'shader-probe'/name)==program['probeSha256']
    assert digest(run/'baseline-shaders'/name)==program['baselineSha256']==restoration['restored'][name]
whole=load(grid/'whole-frame-change.json')
grid_cases={}
for name,expected in (('nvidia',0),('intel',31)):
    case=load(grid/(name+'-results.json'))
    grid_cases[name]=case
    assert case['allocatorZero'] and case['validationClean']
    assert len(case['planes'])==5 and all(row['exact'] for row in case['planes'].values())
    assert len(case['colors'])==3 and all(row['overOne']==expected and row['introduced']==0 for row in case['colors'])
    assert whole[name]['outsideFrozen']['overOne']==0 and whole[name]['outsideFrozen']['maximum']==1
    assert case['selectedRgb']['1240,248']['candidate']==[146,68,67]
    raw=np.fromfile(grid/(name+'-rgb.bin'),'<u2').reshape(17017,11).astype('i4')
    assert int((np.abs(raw[:,5:8]-raw[:,8:11]).max(axis=1)>1).sum())==expected
    for index,frame in enumerate(case['colors']):
        assert digest(grid/f'{name}-frames/frame_{index:06d}.png')==frame['sha256']
sources=load(run/'source-isolation.json')
assert sources['status']=='qualified'
for name,full,body in (('nvidia',237,46),('intel',494,77)):
    device=sources['devices'][name]
    cases=device['cases']
    assert len(cases)==12 and device['selectedAtlas']==name
    actual=cases['cached-'+name+'-atlas']
    assert actual['actualFullAttachmentExact'] and actual['receiver']['overOne']==full
    assert actual['receiver']['byNativeNormalOwner']['328']['overOne']==body
    assert cases['body-live']['actualFullAttachmentExact']
    assert cases['body-live']['focusedBody']['1235,1072']['value']==23
    assert cases['body-native-atlas']['focusedBody']['1235,1072']['value']==27
    assert cases['native-depth-normals-atlas']['receiver']['overOne']==0
    assert cases['native-depth-normals-atlas']['hair']['overOne']==0
    assert all(case['zeroAllocator'] and not case['validationErrors'] for case in cases.values())
    for label,case in cases.items():
        for region,count in (('receiver',49384),('hair',17017)):
            assert (run/name/label/(region+'-selected.bin')).stat().st_size==count
native_cases=load(native/'native-receiver-mesh.json')
mesh=load(run/'receiver-mesh-comparison.json')
assert native_cases['status']=='qualified'
for name,cloth_residual in (('nvidia',158),('intel',223)):
    records=native_cases['devices'][name]['events']
    assert len(records)==3
    for event in ('328','345','377'):
        assert mesh['events'][event]['fields']['SV_Position0']['exactRows']==records[event]['vertices']
        for role in ('vertexData','indexData'):
            entry=records[event][role]
            encoded=(native/entry['path']).read_bytes()
            assert sha256(encoded).hexdigest()==entry['sha256']
            raw=zlib.decompress(encoded)
            assert len(raw)==entry['rawBytes'] and sha256(raw).hexdigest()==entry['rawSha256']
    assert mesh['cloth'][name]['snappedCoverage']==53 and mesh['cloth'][name]['nativeUnmatchedCoverageOverOne']==0
    assert mesh['cloth'][name]['overOneOutsideNativeUnmatchedCoverage']==cloth_residual
evidence.mkdir(parents=True,exist_ok=False)
archive=evidence/'validation.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(run.iterdir()):
        if path.is_file() and path.suffix in ('.py','.json','.log') and not path.name.startswith('prepare-'):
            z.write(path,path.name)
    for path in sorted(native.rglob('*')):
        if path.is_file():
            z.write(path,path.relative_to(run).as_posix())
    for path in sorted(grid.rglob('*')):
        if path.is_file() and path.suffix in ('.py','.json','.log','.spv','.vert','.bin'):
            z.write(path,path.relative_to(run).as_posix())
    for name in devices:
        for path in sorted((run/name).rglob('*')):
            if path.is_file() and path.suffix in ('.json','.log','.bin'):
                z.write(path,path.relative_to(run).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    members=len(z.namelist())
assert archive.stat().st_size<8*1024**2
result=dict(status='qualified-isolated-raster-and-receiver-sources',overallStatus='failed-user-review',
    scope=load(run/'task-card.json'),lease=lease,predecessor=predecessor,executions=executions,
    grid=grid_cases,gridWholeFrame=whole,shaderPrograms=programs,nativeMeshes=native_cases,meshComparison=mesh,
    receiverSourceIsolation=sources,bodyVisibilityChanges=load(run/'body-visibility-changes.json'),
    archive=dict(sha256=digest(archive),bytes=archive.stat().st_size,members=members))
(evidence/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['archive']))

