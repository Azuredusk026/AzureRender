
from contextlib import contextmanager
from hashlib import file_digest
from pathlib import Path
from shutil import copyfile
import json
import os
import tempfile


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')


def locations(run):
    runs=run.resolve(strict=True).parent
    build=(runs/'20261110-030251-hair-main-chroma-public-9e799c/release').resolve(strict=True)
    shaders=(build/'shaders').resolve(strict=True)
    assert build.parent.parent==runs and shaders.parent==build and shaders.name=='shaders'
    boundary=runs/'20261112-182312-projected-hair-point-mip-82adc1'
    player=read(boundary/'release-verification.json')
    assert digest(build/'AzurePlayer.exe')==player['playerSha256']
    baseline=read(boundary/'release-baseline-shaders.json')
    assert len(baseline)==895
    for name,row in player['changedShaders'].items():
        assert baseline[name]==row['before']
        baseline[name]=row['after']
    return shaders,baseline


def catalog(shaders):
    return {path.name:digest(path) for path in shaders.glob('*.spv')}


def replace_verified(source,destination,expected):
    assert source.is_file() and digest(source)==expected
    temp=None
    try:
        with tempfile.NamedTemporaryFile(dir=destination.parent,prefix=destination.name+'.nr-quality-',delete=False) as stream:
            temp=Path(stream.name)
            stream.write(source.read_bytes())
        assert digest(temp)==expected
        os.replace(temp,destination)
    finally:
        if temp is not None and temp.is_file():
            assert temp.resolve(strict=True).parent==destination.parent.resolve(strict=True)
            temp.unlink()
    assert digest(destination)==expected


def restore(run,folder):
    shaders,baseline=locations(run)
    journal=read(folder/'shader-journal.json')
    assert journal['shaderDirectory']==str(shaders)
    assert journal['before']==baseline
    backup=run/'baseline-shaders'
    for name in journal['modified']:
        target=shaders/name
        assert not target.is_symlink() and target.resolve(strict=True).parent==shaders
        old=baseline[name]
        actual=digest(target)
        assert actual in (old,journal['active'][name]),name
        if actual!=old:
            replace_verified(backup/name,target,old)
    actual=catalog(shaders)
    assert actual==baseline
    write(folder/'shader-restoration.json',dict(status='restored',files=len(actual),
        restored={name:actual[name] for name in journal['modified']}))


@contextmanager
def shader_files(run,folder):
    shaders,baseline=locations(run)
    assert catalog(shaders)==baseline
    probes=folder/'shader-probe'
    compilation=read(probes/'compiled.json')['programs']
    assert len(compilation)=={'grid':4,'body':2}[folder.name]
    backup=run/'baseline-shaders'
    backup.mkdir(exist_ok=True)
    active=baseline.copy()
    for name,row in compilation.items():
        assert Path(name).name==name and (name.endswith('_reference_camera.vert.spv') or name in ('reference_scene_visibility.frag.spv','reference_scene_visibility_bindless.frag.spv'))
        assert baseline[name]==row['baselineSha256']
        assert digest(probes/name)==row['probeSha256']
        if not (backup/name).exists():
            copyfile(shaders/name,backup/name)
        assert digest(backup/name)==baseline[name]
        active[name]=row['probeSha256']
    write(folder/'shader-journal.json',dict(shaderDirectory=str(shaders),modified=sorted(compilation),
        before=baseline,active=active))
    try:
        for name in compilation:
            replace_verified(probes/name,shaders/name,active[name])
        assert catalog(shaders)==active
        yield active
    finally:
        restore(run,folder)
