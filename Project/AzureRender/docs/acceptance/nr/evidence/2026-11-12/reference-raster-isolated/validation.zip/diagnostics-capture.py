
from hashlib import file_digest, sha256
from pathlib import Path
import json
import re
import runpy
import subprocess
import sys
import zipfile
import zlib

import numpy as np
from PIL import Image


run=Path(__file__).resolve().parent
base=run.parent/'20261112-182312-projected-hair-point-mip-82adc1'
mode,device=sys.argv[1:]
assert mode in ('grid','body') and device in ('nvidia','intel')
out=run/mode
frames=out/(device+'-frames')
fixture=base/'hair-project'
build=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
player=build/'AzurePlayer.exe'
root=run.parent


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


assert digest(player)==json.loads((base/'release-verification.json').read_text())['playerSha256']
programs=json.loads((out/'shader-journal.json').read_text())
assert len(programs['active'])==895
assert {p.name:digest(p) for p in (build/'shaders').glob('*.spv')}==programs['active']
inputs=json.loads((base/'fixture-inputs.json').read_text())['files']
assert len(inputs)==45
for item in inputs:
    path=fixture/item['relative']
    assert path.stat().st_size==item['bytes'] and digest(path)==item['sha256']
command=[str(player),'--project',str(fixture/'hair-coverage.azureproject'),'--width','2560','--height','1440',
    '--capture-frames','3','--capture-dir',str(frames),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene',
    '--qa-isolation','beauty','--disable-compute-skinning','--disable-bindless','--resource-root',str(build)]
(out/(device+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
logfile=out/(device+'.log')
with logfile.open('wb') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=270)
log=logfile.read_text(errors='replace')
assert result.returncode==0 and 'Allocator after unload: buffers=0 images=0' in log
assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I)
assert 'Character texture access: fixed' in log
expected_pci=(0x10de,0x28e0) if device=='nvidia' else (0x8086,0xa788)
caps=json.loads((frames/'gpu_capabilities.json').read_text())
assert (caps['vendor_id'],caps['device_id'])==expected_pci
capture=json.loads((frames/'capture_manifest.json').read_text())['referenceSceneDepth']
assert (capture['rowOrigin'],capture['normalFrame'],capture['submission'],capture['width'],capture['height'])==(
    'bottom-left','reference',3,2560,1440)
label='release-'+device
base_frames=base/(label+'-frames')
metadata=json.loads((base_frames/'reference-planes.json').read_text())
fields=('raster','hardware','packedNormals','objectIds','objectVisibility')
before,after={},{}
with zipfile.ZipFile(base_frames/'reference-planes.zip') as archive:
    for field in fields:
        path=capture[field]
        item=metadata[path]
        before[field]=archive.read(item['archiveEntry'])
        assert sha256(before[field]).hexdigest()==item['sha256']
        after[field]=(frames/path).read_bytes()
planes={field:dict(exact=before[field]==after[field],baseline=sha256(before[field]).hexdigest(),
    candidate=sha256(after[field]).hexdigest()) for field in fields}
unchangedReferenceGeometry=all(planes[field]['exact'] for field in ('raster','hardware','objectIds'))

color=runpy.run_path(str(root/'20261110-112309-hair-relative-projection-control-b9da17/baseline.py'))
bounds=tuple(color[name] for name in ('x0','y0','x1','y1'))
mask=color['mask']
assert mask.sum()==17017
frames_summary=[]
for i in range(3):
    name=f'frame_{i:06d}.png'
    old=base_frames/name
    new=frames/name
    before_image=np.asarray(Image.open(old).convert('RGB'))
    after_image=np.asarray(Image.open(new).convert('RGB'))
    assert before_image.shape==after_image.shape==(1440,2560,3)
    x0,y0,x1,y1=bounds
    before_crop=before_image[y0:y1,x0:x1]
    after_crop=after_image[y0:y1,x0:x1]
    changed=np.any(before_image!=after_image,axis=-1)
    changed_total=int(changed.sum())
    changed_inside=int(changed[y0:y1,x0:x1][mask].sum())
    previous=np.abs(before_crop.astype('i4')-color['expected'])[mask].max(axis=1)
    current=np.abs(after_crop.astype('i4')-color['expected'])[mask].max(axis=1)
    assert int((previous>1).sum())==(0 if device=='nvidia' else 32)
    introduced=(previous<=1)&(current>1)
    closed=(previous>1)&(current<=1)
    frames_summary.append(dict(overOne=int((current>1).sum()),introduced=int(introduced.sum()),
        closed=int(closed.sum()),maximum=int(current.max()),exactOldPng=old.read_bytes()==new.read_bytes(),
        wholeRgbChanged=changed_total,insideMaskRgbChanged=changed_inside,
        outsideMaskRgbChanged=changed_total-changed_inside,sha256=digest(new),baselineSha256=digest(old)))
    if i==0:
        coords=np.argwhere(mask)
        point=np.column_stack((coords[:,1]+bounds[0],coords[:,0]+bounds[1],before_crop[mask],after_crop[mask],color['expected'][mask]))
        point.astype('<u2').tofile(out/(device+'-rgb.bin'))
        selected_rgb={}
        for display_x,display_y in ((1240,248),(1248,281)):
            target=(point[:,0]==display_x)&(point[:,1]==display_y)
            assert int(target.sum())==1
            row=point[target][0]
            selected_rgb[f'{display_x},{display_y}']=dict(display=row[:2].tolist(),
                baseline=row[2:5].tolist(),candidate=row[5:8].tolist(),native=row[8:11].tolist())
        location=point[(point[:,0]==1240)&(point[:,1]==248)][0].tolist()

receiver={}
visibilityRExact=None
if mode=='body':
    atlas=root/'20261112-024632-native-atlas-and-receiver-producers-d5e705/native-atlas-producers'
    native=json.loads((atlas/'native-atlas-producers.json').read_text())
    owners=np.zeros((310,290),dtype='u2')
    previous=np.zeros_like(owners,dtype='<u4')
    for event,entry in native['receiverNormal']['stages'].items():
        sample=entry['crop']
        data=(atlas/sample['path']).read_bytes()
        assert sha256(data).hexdigest()==sample['sha256']
        values=np.frombuffer(zlib.decompress(data),'<u4').reshape(310,290)
        owners[values!=previous]=int(event)
        previous=values
    numeric=root/'20261110-003435-visibility-numeric-contract-4f95e7'
    x,y=np.fromfile(numeric/'receiver-queries.bin','<f4').reshape(49384,4)[:,:2].astype('i4').T
    target=np.fromfile(numeric/'receiver-expected.bin','<u4').astype('i4')
    groups=owners[y-1000,x-1140]
    target_normal=previous[y-1000,x-1140]
    old_normal=np.frombuffer(before['packedNormals'],'<u4').reshape(1440,2560)[y,x]
    new_normal=np.frombuffer(after['packedNormals'],'<u4').reshape(1440,2560)[y,x]
    original=np.frombuffer(before['objectVisibility'],'u1').reshape(1440,2560,2)
    candidate=np.frombuffer(after['objectVisibility'],'u1').reshape(1440,2560,2)
    visibilityRExact=bool(np.array_equal(original[:,:,0],candidate[:,:,0]))
    old=original[y,x,1].astype('i4')
    new=candidate[y,x,1].astype('i4')
    bad=np.abs(old-target)>1
    remaining=np.abs(new-target)>1

    def normal_error(values):
        return np.maximum(*[
            np.abs(((values>>bit)&1023).astype('i4')-((target_normal>>bit)&1023).astype('i4'))
            for bit in (0,10)
        ])

    old_normal_error=normal_error(old_normal)
    new_normal_error=normal_error(new_normal)
    for event in np.unique(groups):
        select=groups==event
        receiver[int(event)]=dict(samples=int(select.sum()),baselineOverOne=int((select&bad).sum()),
            overOne=int((select&remaining).sum()),closed=int((select&bad&~remaining).sum()),
            introduced=int((select&~bad&remaining).sum()),normalsChanged=int((select&(old_normal!=new_normal)).sum()),
            baselineNormalOverOne=int((select&(old_normal_error>1)).sum()),
            normalOverOne=int((select&(new_normal_error>1)).sum()),
            baselineNormalMaximum=int(old_normal_error[select].max()),normalMaximum=int(new_normal_error[select].max()))
    assert receiver[328]['baselineOverOne']==(46 if device=='nvidia' else 77)
    assert receiver[328]['baselineNormalOverOne']==(141 if device=='nvidia' else 276)

    np.column_stack((x,y,target,old,new,old_normal,new_normal,groups,target_normal)).astype('<u4').tofile(out/(device+'-receiver.bin'))
assert {p.name:digest(p) for p in (build/'shaders').glob('*.spv')}==programs['active']
report=dict(mode=mode,device=device,validationClean=True,allocatorZero=True,planes=planes,colors=frames_summary,
    display1240_248=location,selectedRgb=selected_rgb,receiver=receiver,unchangedReferenceGeometry=unchangedReferenceGeometry,
    visibilityRExact=visibilityRExact)
(out/(device+'-results.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
