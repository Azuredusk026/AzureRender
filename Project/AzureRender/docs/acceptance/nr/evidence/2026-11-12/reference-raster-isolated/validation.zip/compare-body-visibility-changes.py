from pathlib import Path
from hashlib import sha256
import json
import zipfile

import numpy as np


run=Path(__file__).resolve().parent
last=run.parent/'20261112-213454-reference-raster-source-a825da'
production=run.parent/'20261112-182312-projected-hair-point-mip-82adc1'
frozen=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f')
report=json.loads((last/'raster-source-gate.json').read_text())
depth_name='reference-depth-r32.bin'
native_source=None
for p in frozen.rglob('*.bin'):
    if p.stat().st_size!=2560*1440*4:
        continue
    raw=p.read_bytes()
    if sha256(raw).hexdigest()=='02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb':
        native_source=raw
        break
assert native_source is not None
native_depth=np.frombuffer(native_source,'<u4').reshape(1440,2560)


def normal_codes(a):
    return np.column_stack(((a&1023),((a>>10)&1023))).astype('i4')


def error(old,new):
    return np.abs(old-new).max(axis=1)


summary={}
for device in ('nvidia','intel'):
    binary=last/'body'/f'{device}-receiver.bin'
    raw=np.fromfile(binary,'<u4').reshape(49384,9)
    group=raw[raw[:,7]==328]
    assert len(group)==9116
    x,y,target,original,probe,original_normal,probe_normal,_,target_normal=group.T
    original,probe,target=(v.astype('i4') for v in (original,probe,target))
    d=production/f'release-{device}-frames'
    meta=json.loads((d/'reference-planes.json').read_text())[depth_name]
    with zipfile.ZipFile(d/'reference-planes.zip') as archive:
        blob=archive.read(meta['archiveEntry'])
    assert sha256(blob).hexdigest()==meta['sha256']
    live_depth=np.frombuffer(blob,'<u4').reshape(1440,2560)[y,x]
    depth_delta=live_depth.astype('i8')-native_depth[y,x].astype('i8')
    old_bad=np.abs(original-target)>1
    new_bad=np.abs(probe-target)>1
    old_n=normal_codes(original_normal)
    new_n=normal_codes(probe_normal)
    ref_n=normal_codes(target_normal)
    old_n_delta=error(old_n,ref_n)
    new_n_delta=error(new_n,ref_n)
    frozen_owner=report['bodyRegion'][device]
    masks=dict(closed=old_bad&~new_bad,introduced=~old_bad&new_bad,unchangedBad=old_bad&new_bad,
        stableGood=~old_bad&~new_bad)
    assert all(int(masks[name].sum())==frozen_owner[name] for name in ('closed','introduced'))
    source_row={}
    for label,mask in masks.items():
        rows=[]
        if label in ('closed','introduced'):
            for i in np.flatnonzero(mask):
                rows.append(dict(pixel=[int(x[i]),int(y[i])],visibility=[int(original[i]),int(probe[i]),int(target[i])],
                    depthUlp=int(depth_delta[i]),normal=[old_n[i].tolist(),new_n[i].tolist(),ref_n[i].tolist()]))
        source_row[label]=dict(samples=int(mask.sum()),exactDepth=int((mask&(depth_delta==0)).sum()),
            normalDeltaChanged=int((mask&(old_n_delta!=new_n_delta)).sum()),
            normalExactBefore=int((mask&(old_n_delta==0)).sum()),normalExactAfter=int((mask&(new_n_delta==0)).sum()),
            maximumVisibilityError=int(np.abs(probe[mask]-target[mask]).max()),rows=rows)
    summary[device]=source_row
(run/'body-visibility-changes.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))

