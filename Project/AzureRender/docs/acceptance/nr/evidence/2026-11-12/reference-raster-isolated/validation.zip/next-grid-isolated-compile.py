from hashlib import sha256
from pathlib import Path
import json
import re
import subprocess

run=Path(__file__).resolve().parent
base=run/'grid/shader-probe'
out=run/'next-grid-isolated-verified/shader-probe'
out.mkdir(parents=True)
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
source=base/'mesh.vert'
code=source.read_text()
old="""        vec2 halfViewport=camera.clusterDepth.zw*.5;
        precise vec2 window=(gl_Position.xy/gl_Position.w)*halfViewport+halfViewport;
        precise vec2 snapped=roundEven(window*256.0)/256.0+vec2(1.0/2048.0);
        precise vec2 ndc=(snapped-halfViewport)/halfViewport;
        gl_Position.xy=ndc*gl_Position.w;"""
new="""        gl_Position.xy=azureQuantizedHairRasterXY(gl_Position,camera.clusterDepth.zw*.5);"""
assert code.count(old)==1
code=code.replace(old,new)
helper="""#if defined(AZURE_REFERENCE_CAMERA)
vec2 azureQuantizedHairRasterXY(vec4 clip,vec2 halfViewport){
    precise vec2 window=(clip.xy/clip.w)*halfViewport+halfViewport;
    precise vec2 snapped=roundEven(window*256.0)/256.0+vec2(1.0/2048.0);
    precise vec2 ndc=(snapped-halfViewport)/halfViewport;
    return ndc*clip.w;
}
#endif

void main()"""
assert code.count('void main()')==1
code=code.replace('void main()',helper)
probe=out/'mesh.vert'
probe.write_text(code,encoding='utf-8')


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def parse(path):
    text=subprocess.check_output([str(sdk/'spirv-dis.exe'),str(path)],text=True)
    precise=set(re.findall(r'OpDecorate\s+(%\S+)\s+NoContraction',text))
    functions={}
    current=None
    for line in text.splitlines():
        line=line.strip()
        definition=re.match(r'(%\S+)\s*=\s*(Op\S+)(.*)',line)
        if definition and definition[2]=='OpFunction':
            current=definition[1].split('(',1)[0]
            functions[current]=[]
        elif line=='OpFunctionEnd':
            current=None
        elif current and definition and definition[1] in precise:
            functions[current].append(definition[2])
    return functions


manifest=json.loads((base/'compiled.json').read_text())
programs={}
for name,row in manifest['programs'].items():
    original=run/'baseline-shaders'/name
    assert digest(original)==row['baselineSha256']
    previous=base/name
    assert digest(previous)==row['probeSha256']
    result=out/name
    argv=[*row['command'][:-3],str(probe),'-o',str(result)]
    subprocess.run(argv,check=True)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(result)],check=True)
    baseline,inline,current=(parse(path) for path in (original,previous,result))
    added=set(current)-set(baseline)
    assert added=={'%azureQuantizedHairRasterXY_vf4_vf2_'}
    assert len(current['%azureQuantizedHairRasterXY_vf4_vf2_'])==8
    assert not baseline['%main'] and len(inline['%main']) in (36,44)
    assert all(current[function]==baseline[function] for function in baseline)
    programs[name]=dict(baselineSha256=digest(original),inlineSha256=digest(previous),
        probeSha256=digest(result),inlineMainDecorations=len(inline['%main']),
        isolatedMainDecorations=len(current['%main']),isolatedHelperOperations=current['%azureQuantizedHairRasterXY_vf4_vf2_'],
        command=argv)
assert len(programs)==4
(out/'compiled.json').write_text(json.dumps(dict(sourceSha256=digest(probe),programs=programs),indent=2)+'\n')
print(json.dumps({name:dict(inline=row['inlineMainDecorations'],isolated=row['isolatedMainDecorations'],
    helper=len(row['isolatedHelperOperations'])) for name,row in programs.items()}))


