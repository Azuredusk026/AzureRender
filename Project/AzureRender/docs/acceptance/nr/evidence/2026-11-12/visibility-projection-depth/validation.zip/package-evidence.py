from hashlib import sha256
from pathlib import Path
import json
import re
import xml.etree.ElementTree as xml
import zipfile

out=Path(__file__).resolve().parent
root=out.parents[2]
target=root/'docs/acceptance/nr/evidence/2026-11-12/visibility-projection-depth'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def digest(data):
    return sha256(data).hexdigest()

labels=tuple(f'{configuration}-{device}' for configuration in ('release','debug') for device in ('nvidia','intel'))
builds={key:read(out/(key+'-verification.json')) for key in ('release','debug',*(name+'-gpu' for name in labels))}
assert all(not case['ctestExit'] and case['shaderCount']==891 for case in builds.values())
assert len({json.dumps(case['changedShaders'],sort_keys=True) for case in builds.values()})==1
changes=builds['release']['changedShaders']
assert list(changes)==['screen_object_visibility.frag.spv']
captures={name:read(out/(name+'-results.json')) for name in labels}
assert all(case['priorExact'] and case['validationClean'] and case['allocatorZero'] for case in captures.values())
for device in ('nvidia','intel'):
    for key in ('attachments','colors','hair','receiver'):
        assert captures['release-'+device][key]==captures['debug-'+device][key],(device,key)
profiles={device:read(out/(device+'-frozen-profile-results.json')) for device in ('nvidia','intel')}
for device,result in profiles.items():
    assert result['hair']['withinOnePixels']==17017 and result['receiver']['withinOnePixels']==49384,device
original=read(out/'default-four-results.json')
assert original['allExact'] and original['depthCaptureAbsent'] and original['validationClean'] and original['allocatorZero']
assert read(out/'red-result.json')['expectedMissingField']
passed={}
for key in builds:
    root_xml=xml.parse(out/(key+'-ctest.xml')).getroot()
    cases=list(root_xml.iter('testcase'))
    assert len(cases)==(4 if key.endswith('-gpu') else 5),key
    assert not any(case.find('failure') is not None or case.find('skipped') is not None for case in cases)
    if key.endswith('-gpu'):
        mixed=[case for case in cases if 'ScreenObjectVisibility' in case.attrib['name']]
        assert len(mixed)==2
        for case in mixed:
            assert re.search(r'2299 pixels, mixed projection/atlas depth',case.findtext('system-out','')),case.attrib
    passed[key]=len(cases)
target.mkdir(parents=True,exist_ok=False)
archive=target/'validation.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as writer:
    def add(path):
        writer.write(path,path.relative_to(out).as_posix())
    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py','.json','.xml','.log','.spv'):
            add(path)
    for label in labels:
        folder=out/(label+'-frames')
        for name in ('capture_manifest.json','gpu_capabilities.json','reference-planes.json'):
            add(folder/name)
        if label.startswith('release-'):add(folder/'reference-planes.zip')
    for device in ('nvidia','intel'):
        for region in ('hair','receiver'):
            folder=out/f'{device}-frozen-{region}'
            for path in sorted(folder.iterdir()):
                if path.is_file() and path.suffix in ('.json','.log','.bin'):add(path)
    add(out/'default-four-frames/capture_manifest.json')
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    contents={name:digest(reader.read(name)) for name in reader.namelist()}
assert archive.stat().st_size<=8*1024*1024
result=dict(status='qualified-independent-object-projection-depth',overall='failed-user-review',baseCommit='b9fb734',
    sceneRendererApiVersion=14,acceptedMaximumByteError=1,changedShaders=changes,builds=builds,
    tests=passed,actualCaptures=captures,originalFour=original,frozenProfile=profiles,
    archive=dict(bytes=archive.stat().st_size,sha256=digest(archive.read_bytes()),files=len(contents),contents=contents))
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:value for key,value in result['archive'].items() if key!='contents'}))
