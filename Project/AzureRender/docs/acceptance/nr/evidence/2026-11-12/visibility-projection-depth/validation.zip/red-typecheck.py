from pathlib import Path
import json
import os
import subprocess

out=Path(__file__).resolve().parent
engine=out.parents[2]
main=Path('D:/Projects/FYP/Project/AzureRender')
environment=os.environ.copy()
temporary=out/'tmp'
temporary.mkdir(exist_ok=True)
for key in ('TMP','TEMP','TMPDIR'):
    environment[key]=str(temporary)
include=main/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Include')
source=engine/'tests/ScreenObjectVisibilityTests.cpp'
args=[str(main/'tools/msvc_env.bat'),'cl','/nologo','/Zs','/std:c++20','/EHsc','/utf-8',
    '/I'+str(engine/'src'),'/I'+str(include),'/I'+str(sdk),str(source)]
command=subprocess.list2cmdline(args)
run=subprocess.run(command,shell=True,cwd=out,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(out/'red-typecheck.log').write_bytes(run.stdout)
diagnostic=run.stdout.decode(errors='replace')
assert run.returncode and 'projectionDepth' in diagnostic and 'C2039' in diagnostic,diagnostic
(out/'red-result.json').write_text(json.dumps(dict(exit=run.returncode,expectedMissingField=True,command=args),indent=2)+'\n')
print(diagnostic)
