from pathlib import Path
import json
import subprocess
import sys

out=Path(__file__).resolve().parent
device=sys.argv[1]
assert device in ('nvidia','intel')
numeric=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
normal=out.parent/'20261111-232828-scene-reference-normal-60ddfa/nvidia-normal-visibility-control-reference-frame'
shaders=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release/shaders'
reports={}
for region,pixels in [('hair',17017),('receiver',49384)]:
    config=json.loads((numeric/(region+'-calibration.json')).read_text())
    if region=='hair':config.update(queries=str(normal/'queries.bin'),expected=str(normal/'expected.bin'))
    folder=out/f'{device}-frozen-{region}'
    folder.mkdir()
    path=folder/'configuration.json'
    path.write_text(json.dumps(config,indent=2)+'\n')
    command=[str(numeric/'calibration.exe'),str(path),str(shaders)]
    (folder/'command.json').write_text(json.dumps(command,indent=2)+'\n')
    with (folder/'process.log').open('wb') as log:
        process=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    report=json.loads((folder/f'{device}-{region}-result.json').read_text())
    assert process.returncode==0 and report['pixels']==report['withinOnePixels']==pixels and report['maximumByteError']<=1
    assert report['zeroAllocator'] and not report['validationErrors']
    reports[region]=report
(out/f'{device}-frozen-profile-results.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps({key:value['withinOnePixels'] for key,value in reports.items()}))
