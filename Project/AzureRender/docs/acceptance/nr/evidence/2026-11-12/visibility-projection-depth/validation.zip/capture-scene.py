from hashlib import sha256
from pathlib import Path
import json
import re
import subprocess
import sys

out=Path(__file__).resolve().parent
configuration,device=sys.argv[1:]
assert configuration in ('Release','Debug') and device in ('nvidia','intel')
label=configuration.lower()+'-'+device
frames=out/(label+'-frames')
build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
prior=out.parent/'20261112-020715-scene-visibility-reference-calibration-f77af1'
baseline=json.loads((prior/(label+'-results.json')).read_text())
for item in json.loads((prior/'hair-fixture-inputs.json').read_text()):
    assert sha256(Path(item['destination']).read_bytes()).hexdigest()==item['sha256']
player=build/'AzurePlayer.exe'
assert sha256(player.read_bytes()).hexdigest()==json.loads((out/(configuration.lower()+'-verification.json')).read_text())['playerSha256']
command=[str(player),'--project',str(prior/'hair-project/hair-coverage.azureproject'),
    '--width','2560','--height','1440','--capture-frames','3','--capture-dir',str(frames),'--fixed-frame-step',
    '--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--disable-compute-skinning',
    '--disable-bindless','--resource-root',str(build)]
(out/(label+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
log_path=out/(label+'.log')
with log_path.open('wb') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=420)
log=log_path.read_text(errors='replace')
assert result.returncode==0 and 'Allocator after unload: buffers=0 images=0' in log,log[-7000:]
assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I),log[-7000:]
capture=json.loads((frames/'capture_manifest.json').read_text())['referenceSceneDepth']
assert (capture['rowOrigin'],capture['normalFrame'],capture['submission'],capture['width'],capture['height'])==('bottom-left','reference',3,2560,1440)
attachments=(('raster','referenceDepthSha256'),('hardware','referenceDepthSha256'),('packedNormals','referenceNormalsSha256'),
    ('objectIds','objectIdsSha256'),('objectVisibility','visibilitySha256'))
digests={}
for field,key in attachments:
    value=sha256((frames/capture[field]).read_bytes()).hexdigest()
    assert value==baseline[key],(field,value,baseline[key])
    digests[field]=value
colors=[sha256((frames/f'frame_{i:06d}.png').read_bytes()).hexdigest() for i in range(3)]
assert colors==baseline['colors']
report=dict(configuration=configuration,device=device,attachments=digests,colors=colors,priorExact=True,
    hair=baseline['hair'],receiver=baseline['receiver'],validationClean=True,allocatorZero=True)
(out/(label+'-results.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ('configuration','device','attachments','priorExact')}))
