from hashlib import file_digest
from pathlib import Path
import json
import subprocess
import sys

out=Path(__file__).resolve().parent
engine=out.parents[2]
build=(out.parent/'20261110-031856-hair-main-chroma-debug-668bf2/debug').resolve(strict=True)
assert build.parent.parent==out.parent and not build.is_symlink()
queue=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_text())
assert queue['state']=='released' or queue['owner']!='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0,str(engine/'tools'))
from artifact_maintenance import measure

ninja='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
targets=['AzurePlayer','AzureReferenceCameraViewTests','AzureProjectReferenceViewsTests','AzureRenderExtensionRegistryTests',
    'AzureReferenceCameraBindingTests','AzureScreenObjectVisibilityTests','AzureScreenObjectVisibilityGpuTests',
    'AzureReferenceDepthGpuTests','AzureReferenceDepthCoverageGpuTests']
command=[ninja,'-C',str(build),'-n',*targets]
plan=subprocess.check_output(command,text=True)
assert 'Linking CXX static library AzureRenderCore.lib' in plan and 'Linking CXX executable AzurePlayer.exe' in plan
assert 'Linking CXX executable AzureRenderExtensionRegistryTests.exe' not in plan
assert 'Linking CXX executable AzureMetaGen.exe' not in plan
prior=out.parent/'20261112-020715-scene-visibility-reference-calibration-f77af1'

def digest(path):
    with path.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()

assert digest(build/'AzurePlayer.exe')==json.loads((prior/'debug-verification.json').read_text())['playerSha256']
folder=out/'build-symbols'
folder.mkdir()
assert folder.resolve().parent==out and not folder.is_symlink()
before=measure(build.parent)
files=[]
for name in ('AzureRenderCore.lib','AzureRenderExtensionRegistryTests.pdb','AzureMetaGen.pdb'):
    path=build/name
    assert path.is_file() and not path.is_symlink() and path.resolve(strict=True).parent==build
    assert path.stat().st_nlink==1 and subprocess.run(['git','-C',str(engine),'check-ignore','-q',str(path)]).returncode==0
    files.append(dict(name=name,bytes=path.stat().st_size,sha256=digest(path)))
for item in files:
    path=build/item['name']
    if path.suffix=='.pdb':
        destination=folder/path.name
        assert not destination.exists()
        path.rename(destination)
        assert digest(destination)==item['sha256']
        item['archived']=str(destination)
    else:path.unlink()
after=measure(build.parent)
assert before-after==sum(item['bytes'] for item in files)
assert subprocess.check_output(command,text=True)==plan
(out/'debug-link-budget-preparation.json').write_text(json.dumps(dict(before=before,after=after,files=files,command=command),indent=2)+'\n')
print(f'Debug generated outputs {before} -> {after} bytes')
