from hashlib import sha256
from pathlib import Path
import json
import zipfile


out = Path(__file__).resolve().parent
target = out.parents[2] / 'docs/acceptance/nr/evidence/2026-11-12/native-cloth-receiver-normal-input'
native = out / 'native-source'


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


replay = load(native / 'report.json')
execution = load(out / 'replay-execution.json')
comparison = load(out / 'source-comparison.json')
assert replay['status'] == 'qualified' and execution['status'] == 'exited' and execution['exitCode'] == 0
assert replay['dds']['sha256'] == comparison['dds']['sha256'] == '924a06afe633006325ec42ae990c203a500495a75c61353d1409d2fd7e2c07cf'
assert comparison['orientation']['rows-1-green-0']['exact'] == 4189362
assert comparison['orientation']['rows-1-green-0']['withinOne'] == 4192794
assert comparison['vertexUv']['halfPrecisionFlippedV'] == 31988
assert comparison['receiver']['nvidia']['overOne'] == 1350 and comparison['receiver']['intel']['overOne'] == 1349
assert replay['devices']['nvidia']['levels'] == replay['devices']['intel']['levels']
assert len(replay['devices']['nvidia']['levels']) == 12
assert set(replay['devices']) == {'nvidia', 'intel'}
archive = out / 'validation-pending.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as writer:
    for name in ('task-card.json', 'replay.py', 'replay-worker.py', 'queued-replay.py', 'replay-execution.json',
        'compare-input.py', 'package-evidence.py', 'source-comparison.json', 'native-source/request.json',
        'native-source/command.json', 'native-source/report.json', 'native-source/process.log'):
        writer.write(out / name, 'run/' + name)
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    contents = {name: sha256(reader.read(name)).hexdigest() for name in reader.namelist()}
assert archive.stat().st_size <= 8 * 1024 * 1024
payload = dict(status='qualified-native-cloth-receiver-normal-input', overall='failed-user-review', comparison=comparison,
    nativeReplay=replay, execution=execution, archive=dict(bytes=archive.stat().st_size,
        sha256=sha256(archive.read_bytes()).hexdigest(), contents=contents))
target.mkdir(parents=True, exist_ok=True)
assert not (target / 'validation.zip').exists() and not (target / 'results.json').exists()
archive.rename(target / 'validation.zip')
(target / 'results.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in payload['archive'].items() if key != 'contents'}))
