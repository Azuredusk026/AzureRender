from hashlib import file_digest
from pathlib import Path
import json
import os
import subprocess


out = Path(__file__).resolve().parent
capture = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc')
capture_sha = 'fa2ca267f7168f5603e83ad5f817a3074d8dbee23a216e6ab8ef2c340ec06a90'


def verify_capture():
    with capture.open('rb') as stream:
        assert file_digest(stream, 'sha256').hexdigest() == capture_sha


verify_capture()
folder = out / 'native-source'
folder.mkdir()
request = folder / 'request.json'
request.write_text(json.dumps(dict(capture=str(capture), output=str(folder), captureSha256=capture_sha,
    event=377, resource='ResourceId::87521', baseSha256='5a839ca9b920d1ade77fe97a49aac129097838e72710bbbf07228b35eafc8ed9'),
    indent=2) + '\n')
env = os.environ.copy()
for key in ('VK_LAYER_PATH', 'VK_INSTANCE_LAYERS', 'ENABLE_VULKAN_RENDERDOC_CAPTURE',
    'VK_LOADER_DRIVERS_SELECT', 'VK_DRIVER_FILES', 'VK_ICD_FILENAMES'):
    env.pop(key, None)
env['AZURE_CLOTH_RECEIVER_REQUEST'] = str(request)
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
command = ['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe', '--python', str(out / 'replay-worker.py')]
(folder / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (folder / 'process.log').open('wb') as log:
    result = subprocess.run(command, env=env, startupinfo=startup, cwd=folder, stdout=log,
        stderr=subprocess.STDOUT, timeout=140)
receipt = json.loads((folder / 'report.json').read_text())
assert result.returncode == 0 and receipt['status'] == 'qualified', receipt
verify_capture()
print(json.dumps(dict(devices=list(receipt['devices']), mipLevels=len(receipt['devices']['nvidia']['levels']), dds=receipt['dds'])))
