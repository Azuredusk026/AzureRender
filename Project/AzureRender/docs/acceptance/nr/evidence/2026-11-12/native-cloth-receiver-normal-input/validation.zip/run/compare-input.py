from hashlib import file_digest, sha256
from io import BytesIO
from pathlib import Path
import base64
import json
import struct
import zlib

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
native = out / 'native-source'
scene = out.parent / '20261112-073905-reference-scene-outline-depth-d97cff/hair-project/character/hair-coverage.glb'
report = json.loads((native / 'report.json').read_text())
assert report['status'] == 'qualified'
gpu = json.loads((out / 'replay-execution.json').read_text())
assert gpu['status'] == 'exited' and gpu['exitCode'] == 0
dds = native / report['dds']['file']
raw = dds.read_bytes()
assert sha256(raw).hexdigest() == report['dds']['sha256']
assert raw[:4] == b'DDS ' and raw[84:88] == b'DX10'
levels = report['devices']['nvidia']['levels']
assert len(levels) == 12 and levels == report['devices']['intel']['levels']
offset = report['dds']['headerBytes']
for level in levels:
    next_offset = offset + level['bytes']
    assert sha256(raw[offset:next_offset]).hexdigest() == level['sha256']
    offset = next_offset
assert offset == len(raw) == report['dds']['bytes']
counter_messages = {
    'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU',
    'NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image',
}
assert set(report['devices']['nvidia']['messages']) <= counter_messages
assert not report['devices']['intel']['messages'], report['devices']['intel']['messages']

with scene.open('rb') as stream:
    scene_sha = file_digest(stream, 'sha256').hexdigest()
    assert scene_sha == '849282e0b6a7a7681aba32b336b546a588044b1f19ca889100015a7379ed5169'
    stream.seek(0)
    magic, version, file_bytes, json_bytes, json_type = struct.unpack('<4s4I', stream.read(20))
    assert (magic, version, file_bytes, json_type) == (b'glTF', 2, scene.stat().st_size, 0x4e4f534a)
    document = json.loads(stream.read(json_bytes))
    buffer_bytes, buffer_type = struct.unpack('<2I', stream.read(8))
    assert buffer_type == 0x004e4942
    buffer_offset = stream.tell()
    mesh, = [item for item in document['meshes'] if item['name'] == 'S_actor_laevat_cloth_01_lod0']
    primitive, = mesh['primitives']
    material = document['materials'][primitive['material']]
    assert material['name'] == 'M_actor_laevat_cloth_01'
    index_count = document['accessors'][primitive['indices']]['count']
    assert index_count == 102927
    texcoord = document['accessors'][primitive['attributes']['TEXCOORD_0']]
    assert (texcoord['type'], texcoord['componentType']) == ('VEC2', 5126)
    view = document['bufferViews'][texcoord['bufferView']]
    assert view['buffer'] == 0 and view.get('byteStride', 8) == 8 and 'sparse' not in texcoord
    relative = view.get('byteOffset', 0) + texcoord.get('byteOffset', 0)
    assert relative + texcoord['count'] * 8 <= buffer_bytes
    stream.seek(buffer_offset + relative)
    uv = np.frombuffer(stream.read(texcoord['count'] * 8), '<f4').reshape(-1, 2)
    assert np.isfinite(uv).all()
normal = material['normalTexture']
binding = document['textures'][normal['index']]
image = document['images'][binding['source']]
prefix, data = image['uri'].split(',', 1)
assert prefix == 'data:image/png;base64'
png = base64.b64decode(data, validate=True)
assert sha256(png).hexdigest() == 'c65df30156c698f809c824ef7e28fcfabc1c7a0b03ed616a13a34b5ef2ac3a90'

vertex_evidence = out.parent / '20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry'
vertex_record = json.loads((vertex_evidence / 'native-caster-geometry.json').read_text())['atlasDraws']['191']
assert vertex_record['numIndices'] == 102882 and vertex_record['signature'][0]['name'] == 'TEXCOORD'
assert vertex_record['signature'][0]['index'] == 0 and vertex_record['signature'][0]['count'] == 2
positions = vertex_record['vertexData']
vertex_raw = zlib.decompress((vertex_evidence / positions['path']).read_bytes())
assert sha256(vertex_raw).hexdigest() == positions['rawSha256']
assert len(vertex_raw) == vertex_record['vertices'] * vertex_record['vertexStride']
native_uv = np.frombuffer(vertex_raw, '<f4').reshape(vertex_record['vertices'], -1)[:, 4:6]
flipped_uv = native_uv.copy()
flipped_uv[:, 1] = 1 - flipped_uv[:, 1]


def uv_keys(values):
    words = np.asarray(values, dtype='<f2').view('<u2').astype('u4')
    return words[:, 0] | (words[:, 1] << 16)


uv_match = dict(atlasEvent=191, nativeVertices=vertex_record['vertices'], fixtureVertices=len(uv),
    halfPrecisionDirect=int(np.isin(uv_keys(uv), uv_keys(native_uv)).sum()),
    halfPrecisionFlippedV=int(np.isin(uv_keys(uv), uv_keys(flipped_uv)).sum()))
assert uv_match == dict(atlasEvent=191, nativeVertices=32021, fixtureVertices=32031,
    halfPrecisionDirect=101, halfPrecisionFlippedV=31988)

with Image.open(BytesIO(png)) as source, Image.open(dds) as reference:
    assert source.size == reference.size == (2048, 2048) and reference.pixel_format == 'BC5'
    current = np.asarray(source.convert('RGB'), dtype='i2')[..., :2]
    captured = np.asarray(reference, dtype='i2')[..., :2]

orientation = {}
for flip_rows in (False, True):
    for invert_green in (False, True):
        source = (current[::-1] if flip_rows else current).copy()
        if invert_green:
            source[..., 1] = 255 - source[..., 1]
        delta = np.abs(source - captured)
        error = delta.max(axis=-1)
        orientation[f'rows-{int(flip_rows)}-green-{int(invert_green)}'] = dict(exact=int((error == 0).sum()),
            withinOne=int((error <= 1).sum()), meanPerChannel=delta.mean(axis=(0, 1)).tolist(),
            medianMaximum=float(np.median(error)), p95Maximum=float(np.quantile(error, .95)), maximum=int(error.max()))

stage = out.parents[2] / 'docs/acceptance/nr/evidence/2026-11-12/reference-scene-outline-depth/results.json'
outline = json.loads(stage.read_text())
receiver = {device: outline['green']['release-' + device]['receiverByNativeNormalOwner']['377'] for device in ('nvidia', 'intel')}
assert receiver['nvidia']['pixels'] == receiver['intel']['pixels'] == 16629
card = json.loads((out / 'task-card.json').read_text())
result = dict(sourceBase=card['sourceBase'], outlinePlayer=outline['builds']['release']['playerSha256'],
    nativeResource='ResourceId::87521', nativeEvent=377, receiver=receiver,
    normalAsset=dict(path=str(scene), sha256=scene_sha, imageName=image['name'], pngBytes=len(png), pngSha256=sha256(png).hexdigest(),
        indices=index_count, sampler=binding.get('sampler'), normalScale=normal.get('scale', 1), uvMin=uv.min(axis=0).tolist(),
        uvMax=uv.max(axis=0).tolist()), texelCount=2048 * 2048, orientation=orientation, vertexUv=uv_match, dds=report['dds'])
(out / 'source-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(orientation=orientation, receiver=receiver)))
