from hashlib import sha256
from pathlib import Path
import json
import zipfile

out=Path(__file__).resolve().parent
root=out.parents[2]
target=root/'docs/acceptance/nr/evidence/2026-11-12/scene-visibility-reference-calibration'

def read(folder,name):
    return json.loads((folder/name).read_text(encoding='utf-8'))

def digest(data):
    return sha256(data).hexdigest()

labels=tuple(f'{configuration}-{device}' for configuration in ('release','debug') for device in ('nvidia','intel'))
captures={name:read(out,name+'-results.json') for name in labels}
for name,case in captures.items():
    assert case['validationClean'] and case['allocatorZero'],name
    for region,pixels in (('hair',17017),('receiver',49384)):
        data=case[region]
        assert data['pixels']==pixels and data['baselineOverOne']-data['closed']+data['introduced']==data['overOne'],(name,region)
configurations=read(out,'cross-configuration.json')
assert all(all(configurations[device].values()) for device in ('nvidia','intel')) and configurations['sceneControlsExact']
original=read(out,'default-four-results.json')
assert original['allExact'] and original['depthCaptureAbsent'] and original['validationClean'] and original['allocatorZero']
builds={key:read(out,key+'-verification.json') for key in ('release','debug',*(name+'-gpu' for name in labels))}
assert all(not value['ctestExit'] and value['shaderCount']==891 and value['allShadersExact'] for value in builds.values())
source=read(out,'calibration-source.json')
oracle=read(out,'relocation-oracle.json')
assert oracle['cases']==1024 and oracle['maximumPositionError']<1.e-5
intersections={device:read(out,device+'-remaining-source-intersection.json') for device in ('nvidia','intel')}
for device,result in intersections.items():
    for scope in ('hair','receiver'):
        assert result[scope]['overOne']==captures['release-'+device][scope]['overOne']
atlas_depth=read(out,'atlas-depth-neighborhood.json')
assert atlas_depth['highDelta']['3']['withinBothSmooth']==0
record=read(out,'object-record-source-comparison.json')
assert record['atlasRectEqual'] and record['filterRadiusUvEqual'] and record['biasEqual']
symbols=read(out,'debug-symbol-budget-recovery.json')
assert symbols['playerSha256']==builds['debug']['playerSha256']

target.mkdir(parents=True,exist_ok=False)
archive=target/'validation.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as writer:
    def add(path):
        writer.write(path,'run/'+path.relative_to(out).as_posix())
    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py','.json','.xml','.log'):
            add(path)
    for label in labels:
        folder=out/(label+'-frames')
        for name in ('capture_manifest.json','gpu_capabilities.json','reference-planes.json'):
            add(folder/name)
        if label.startswith('release-'):
            add(folder/'reference-planes.zip')
    for config in ('release','debug'):
        folder=out/('scene-control-'+config)
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix in ('.json','.log','.gltf','.azurelevel','.azureproject'):
                add(path)
        add(folder/'config/reference-views.json')
        for mode in ('objects','calibrated','moved','inputs','neutral'):
            add(folder/mode/'capture_manifest.json')
            if mode!='inputs':add(folder/mode/'reference-object-visibility-rg8.bin')
    add(out/'default-four-frames/capture_manifest.json')
    add(out/'hair-project/config/reference-views.json')
    for path in sorted((out/'runtime-red').iterdir()):
        if path.is_file() and path.suffix in ('.json','.log','.gltf','.azurelevel','.azureproject'):
            add(path)
with zipfile.ZipFile(archive) as reader:
    assert reader.testzip() is None
    contents={name:digest(reader.read(name)) for name in reader.namelist()}
assert archive.stat().st_size<=8*1024*1024
result=dict(status='qualified-reference-inverse-calibration-path',overall='failed-user-review',baseCommit='87ac510',
    sceneRendererApiVersion=14,acceptedMaximumByteError=1,builds=builds,captures=captures,crossConfiguration=configurations,
    originalFour=original,source=source,relocationOracle=oracle,remainingSourceIntersections=intersections,
    atlasDepthNeighborhood=atlas_depth,objectRecordSource=record,debugSymbolRecovery=symbols,
    archive=dict(bytes=archive.stat().st_size,sha256=digest(archive.read_bytes()),files=len(contents),contents=contents))
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result['archive'].items() if k!='contents'}))
