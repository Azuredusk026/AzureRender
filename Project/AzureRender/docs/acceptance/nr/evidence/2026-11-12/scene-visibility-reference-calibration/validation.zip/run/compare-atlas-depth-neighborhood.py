from hashlib import sha256
from pathlib import Path
import json
import numpy as np

out=Path(__file__).resolve().parent
atlas=out.parent/'20261112-013522-scene-visibility-atlas-source-33c6c3'
source=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/native-t2.bin')
actual=atlas/'atlas.bin'

def read(path,fingerprint):
    data=path.read_bytes()
    assert sha256(data).hexdigest()==fingerprint
    return np.frombuffer(data,'<u2').reshape(2048,4096)

ref=read(source,'86daee0e01e9c33207679b094bdf5cf31a26d2f93754f11abf6c44df1faecf57')
live=65535-read(actual,'ee700ac4164ffd1923cc9ca1eaeddf27366213a4b8dc5cf0e17fa154328f781e')
region=(slice(1024,2048),slice(2048,3072))
common=(ref!=0)&(live!=0)
delta=np.abs(live.astype('i4')-ref.astype('i4'))
extreme=common&(delta>2)
assert int(extreme.sum())==2380 and int(extreme[region].sum())==2380
ref,live,common,delta,extreme=[plane[region] for plane in (ref,live,common,delta,extreme)]

def neighborhood_range(plane):
    p=np.pad(plane,1,mode='edge')
    views=[p[y:y+1024,x:x+1024] for y in range(3) for x in range(3)]
    return np.maximum.reduce(views)-np.minimum.reduce(views)

reference_edge=neighborhood_range(ref)
actual_edge=neighborhood_range(live)
levels=(3,8,32,128,512,2048,8192)
classifications={}
for threshold in levels:
    bad=common&(delta>=threshold)
    ys,xs=np.where(bad)
    classifications[threshold]=dict(pixels=len(ys),nearNativeDiscontinuity=int((bad&(reference_edge>=threshold)).sum()),
        nearActualDiscontinuity=int((bad&(actual_edge>=threshold)).sum()),
        withinBothSmooth=int((bad&(reference_edge<threshold)&(actual_edge<threshold)).sum()),
        boundsTile=[int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())])
result=dict(tile=6,commonCoverage=int(common.sum()),highDelta=classifications,
    mostFrequentDeltas={int(value):int(count) for value,count in enumerate(np.bincount(delta[common])[:33]) if count})
(out/'atlas-depth-neighborhood.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
