from hashlib import file_digest
from pathlib import Path
import json
import subprocess
import sys


out=Path(__file__).resolve().parent
engine=out.parents[2]
build=(out.parent/'20261110-031856-hair-main-chroma-debug-668bf2/debug').resolve(strict=True)
assert build.parent.parent==out.parent and build.is_dir() and not build.is_symlink()
queue=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_text())
assert queue['state']=='released' or queue['owner']!='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'

ninja='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
command=[ninja,'-C',str(build),'-n','AzurePlayer','AzureScreenObjectVisibilityGpuTests','AzureScreenObjectVisibilityTests']
plan=subprocess.check_output(command,text=True)
(out/'debug-budget-dry-run.log').write_text(plan)
stale=('AzureRenderCore.lib','AzureRuntime.lib','AzurePlayerHost.lib','AzurePlayer.pdb')
assert all(' '+name in plan for name in (*stale[:3],'AzurePlayer.exe'))
assert 'TARGET_PDB = AzurePlayer.pdb' in (build/'build.ninja').read_text(encoding='utf-8')
player=build/'AzurePlayer.exe'
with player.open('rb') as stream:assert file_digest(stream,'sha256').hexdigest()=='ecfb11e3d99b72a5bc2a9760ee4d285d92bfc61fd420b05431463a53b8ec067d'

sys.path.insert(0,str(engine/'tools'))
from artifact_maintenance import measure

before=measure(build.parent)
files=[]
for name in stale:
    path=build/name
    assert path.is_file() and not path.is_symlink() and path.resolve(strict=True).parent==build
    stat=path.stat()
    assert stat.st_nlink==1
    assert subprocess.run(['git','-C',str(engine),'check-ignore','-q',str(path)]).returncode==0
    with path.open('rb') as stream:digest=file_digest(stream,'sha256').hexdigest()
    files.append(dict(name=name,bytes=stat.st_size,sha256=digest))
for item in files:(build/item['name']).unlink()
after=measure(build.parent)
assert before-after==sum(item['bytes'] for item in files)
(out/'debug-link-budget-recovery.json').write_text(json.dumps(dict(before=before,after=after,files=files,
    dryRun=command,retainedPlayer=str(player)),indent=2)+'\n')
print(f'Debug stale link outputs: {before} -> {after} bytes')
