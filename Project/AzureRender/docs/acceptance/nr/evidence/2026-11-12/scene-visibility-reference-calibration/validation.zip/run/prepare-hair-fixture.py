from hashlib import sha256
from pathlib import Path
import json
import shutil
import struct


out = Path(__file__).resolve().parent
prior = out.parent/'20261112-010418-scene-reference-object-visibility-709f68'
normal = out.parent/'20261111-232828-scene-reference-normal-60ddfa'
native = out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
source = prior/'hair-project'
project = out/'hair-project'
assert not project.exists()
authored=json.loads((native/'hair-calibration.json').read_text())['clipToWorld']
origin=json.loads((normal/'object-frame-source-control.json').read_text())['nearestIntegralOrigin']
assert len(authored)==16 and origin==[-300,300,-300]
calibration=dict(schemaVersion=1,positionOffset=origin,clipToWorld=authored)
files=[]
for item in json.loads((prior/'hair-fixture-inputs.json').read_text()):
    old=Path(item['destination']).resolve(strict=True)
    relative=old.relative_to(source)
    assert sha256(old.read_bytes()).hexdigest()==item['sha256']
    destination=project/relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(old,destination)
    if relative.as_posix()=='config/reference-views.json':
        config=json.loads(destination.read_text())
        config['views']['native-hair']['objectVisibility']['calibration']=calibration
        destination.write_text(json.dumps(config,indent=2)+'\n')
    files.append(dict(source=str(old),destination=str(destination),relative=relative.as_posix(),
        bytes=destination.stat().st_size,sha256=sha256(destination.read_bytes()).hexdigest()))
assert len(files)==42 and len({item['relative'] for item in files})==42
assert (project/'config/reference-views.json').is_file()
(out/'hair-fixture-inputs.json').write_text(json.dumps(files,indent=2)+'\n')
(out/'calibration-source.json').write_text(json.dumps(dict(origin=origin,clipToWorld=authored,
    matrixSha256=sha256(struct.pack('<16f',*authored)).hexdigest(),nativeSource=str(native/'hair-calibration.json'),
    originProof=str(normal/'object-frame-source-control.json')),indent=2)+'\n')
print(f'{len(files)} inputs, {sum(item["bytes"] for item in files)} bytes')
