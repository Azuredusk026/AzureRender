from pathlib import Path
import json

import numpy as np


out=Path(__file__).resolve().parent
rng=np.random.default_rng(24719)
maximum=0.0
for _ in range(1024):
    source_world_axes=rng.permutation(3)
    signs=rng.choice([-1,1],3)
    source_axes=np.zeros((3,3))
    source_axes[np.arange(3),source_world_axes]=signs
    origin=rng.uniform(-25,25,3).astype('f4').astype('f8')
    anchor=rng.uniform(-4,4,3).astype('f4').astype('f8')
    current=rng.uniform(-4,4,3).astype('f4').astype('f8')
    a,_=np.linalg.qr(rng.normal(size=(3,3)))
    b,_=np.linalg.qr(rng.normal(size=(3,3)))
    if np.linalg.det(a)<0:a[:,0]*=-1
    if np.linalg.det(b)<0:b[:,0]*=-1
    rotation=a@b.T
    base=(np.eye(4)+rng.uniform(-.25,.25,(4,4))).astype('f4')
    scale=np.float32(rng.uniform(.25,3))

    # Exercise the runtime composition using the independently chosen authored transform.
    world_origin=np.zeros(3)
    world_origin[source_world_axes]=signs*origin
    mapped=base.astype('f8').copy()
    for row in range(3):
        translation=current[row]+world_origin[row]-np.dot(rotation[:,row],anchor+world_origin)
        mapped[row]=translation*base[3]+np.sum((rotation[source_world_axes,row]*signs)[:,None]*base[:3],axis=0)
    mapped=mapped.astype('f4')
    mapped[:,:2]/=scale

    clip=rng.uniform(-.5,.5,4).astype('f4')
    clip[3]=1
    scaled=clip.copy()
    scaled[:2]*=scale
    from_authored=base.astype('f8')@clip.astype('f8')
    source_world=source_axes.T@(from_authored[:3]/from_authored[3]-origin)
    expected=b@a.T@(source_world-anchor)+current+source_axes.T@origin
    observed=mapped.astype('f8')@scaled.astype('f8')
    error=np.max(np.abs(observed[:3]/observed[3]-expected))
    maximum=max(maximum,float(error))

assert maximum<1.e-5,maximum
result=dict(scope='CPU relocation oracle for signed axes, rigid poses and screen scales',cases=1024,maximumPositionError=maximum)
(out/'relocation-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
