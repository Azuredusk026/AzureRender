from pathlib import Path
import json
import struct

out=Path(__file__).resolve().parent
fixture=out/'hair-project'
glb=fixture/'character/hair-coverage.glb'
with glb.open('rb') as stream:
    assert stream.read(4)==b'glTF'
    assert struct.unpack('<I',stream.read(4))[0]==2
    stream.read(4)
    length,kind=struct.unpack('<II',stream.read(8))
    assert kind==0x4e4f534a
    asset=json.loads(stream.read(length))
primitives=[]
for mesh in asset['meshes']:
    for primitive in mesh['primitives']:
        index_count=asset['accessors'][primitive['indices']]['count']
        material=asset['materials'][primitive['material']]
        primitives.append(dict(mesh=mesh.get('name'),indexCount=index_count,material=material.get('name'),
            alphaMode=material.get('alphaMode','OPAQUE'),materialKeys=sorted(material.get('extras',{}))))
main=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719')
inventory=json.loads((main/'Endfield-games-child_frame10401-inventory.json').read_text())
native=[dict(event=a['eid'],indices=a['numIndices']) for a in inventory['actions'] if a['eid']<=699 and
    a['depthOut']=='ResourceId::158089' and a['kind']=='Draw']
result=dict(native=native,fixture=primitives)
(out/'atlas-caster-inventory.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(native=native,fixture=[(a['mesh'],a['indexCount'],a['material'],a['alphaMode']) for a in primitives])))
