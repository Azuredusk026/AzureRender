from pathlib import Path
import json
import numpy as np

out=Path(__file__).resolve().parent
atlas=out.parent/'20261112-013522-scene-visibility-atlas-source-33c6c3'
old=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
previous=out.parent/'20261112-010418-scene-reference-object-visibility-709f68'
baseline=json.loads((atlas/'recorded-parameters.json').read_text())['record']
native=json.loads((old/'hair-calibration.json').read_text())['record']
frame=json.loads((previous/'hair-project/config/reference-views.json').read_text())['views']['native-hair']['frame']
calibration=json.loads((out/'calibration-source.json').read_text())
shift=np.asarray(calibration['origin'])-np.asarray(frame['offset'])
relative_to_native=np.eye(4)
relative_to_native[:3,3]=-shift
forward_to_reversed=np.eye(4)
forward_to_reversed[2,2]=-1
forward_to_reversed[2,3]=1

def projection(record):
    return np.asarray(record['projection'],dtype='f8').reshape(4,4).T

actual=(forward_to_reversed@projection(baseline)@relative_to_native).astype('f4').astype('f8')
expected=projection(native)
world_to_reference=np.eye(4)
world_to_reference[:3,:3]=0
for row,axis in enumerate(frame['axes']):
    world_to_reference[row,abs(axis)-1]=np.sign(axis)
world_to_reference[:3,3]=calibration['origin']
actual_world=actual@world_to_reference
native_world=expected@world_to_reference

def center(matrix):
    return np.linalg.solve(matrix[:3,:3],np.full(3,.5)-matrix[:3,3]).tolist()

result=dict(source='actual Player object constants and native event 699, common reversed depth and source coordinates',
    actualInNativeCoordinates=actual.T.reshape(-1).tolist(),native=expected.T.reshape(-1).tolist(),
    absoluteDelta=(actual-expected).T.reshape(-1).tolist(),
    maxLinearError=float(np.max(np.abs(actual[:3,:3]-expected[:3,:3]))),
    maxOriginTermError=float(np.max(np.abs(actual[:3,3]-expected[:3,3]))),
    lightDirectionDelta=(np.asarray(baseline['lightDirection'])-np.asarray(native['lightDirection'])).tolist(),
    filterRadiusUvEqual=baseline['filterRadiusUv']==native['filterRadiusUv'],
    atlasRectEqual=baseline['atlasRect']==native['atlasRect'],
    biasEqual=all(baseline[name]==native[name] for name in ('normalBias','lightBias')),
    impliedWorldCenters=dict(actual=center(actual_world),native=center(native_world)))
(out/'object-record-source-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:result[key] for key in ('maxLinearError','maxOriginTermError','lightDirectionDelta','impliedWorldCenters')}))
