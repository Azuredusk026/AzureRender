from pathlib import Path
import time,json,subprocess,os,re,hashlib
r=Path(__file__).resolve().parent;run=r.parent;deadline=time.time()+900
while time.time()<deadline:
 try:j=json.loads((run/'filter-parameters/summary.json').read_text())
 except (OSError,ValueError):j={}
 if j.get('status')=='verified':break
 if j.get('status')=='failed':raise RuntimeError(j)
 time.sleep(1)
else:raise TimeoutError('Prior GPU queue did not finish')
root=Path.cwd();env=os.environ.copy();env['DOTNET_ROOT']='D:/Tools/dotnet9';startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0;report={'status':'running','cases':[]}
try:
 for case in ['base','no-object-shadow']:
  out=r/case;out.mkdir();cmd=[str(root/'build/ninja-msvc-release/AzurePlayer.exe'),'--project',str(r/(case+'.azureproject')),'--width','1280','--height','1440','--capture-frames','1','--capture-fps','60','--capture-dir',str(out/'frames'),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--runtime-report',str(out/'runtime.json')];t=time.perf_counter();print('START',case,flush=True)
  with (out/'player.log').open('wb') as log:p=subprocess.run(cmd,stdout=log,stderr=log,startupinfo=startup,env=env,timeout=300)
  text=(out/'player.log').read_text(errors='replace');assert p.returncode==0 and 'Allocator after unload: buffers=0 images=0' in text;assert not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD|\[error\]',text,re.I)
  report['cases'].append({'case':case,'command':cmd,'exitCode':p.returncode,'elapsedSeconds':time.perf_counter()-t,'imageSha256':hashlib.sha256((out/'frames/frame_000000.png').read_bytes()).hexdigest()});(r/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print('DONE',case,flush=True)
 report['status']='captured-diagnostic'
finally:(r/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
