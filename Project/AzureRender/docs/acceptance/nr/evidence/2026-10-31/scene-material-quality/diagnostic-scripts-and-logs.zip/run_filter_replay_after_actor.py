from pathlib import Path
import subprocess,time,json
r=Path(__file__).resolve().parent;deadline=time.time()+900
while time.time()<deadline:
 try:j=json.loads((r/'actor-closeup/summary.json').read_text())
 except (OSError,ValueError):j={}
 if j.get('status')=='captured-diagnostic':break
 time.sleep(1)
else:raise TimeoutError('Full-scene diagnostics did not finish')
print('Full-scene diagnostic queue complete; replaying filter constants',flush=True)
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
with (r/'filter-parameters/host.log').open('wb') as log:
 p=subprocess.Popen(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(r/'export_filter_parameters.py')],stdout=log,stderr=log,startupinfo=startup);code=p.wait(timeout=600)
print('Replay exit',code,flush=True);print((r/'filter-parameters/summary.json').read_text(),flush=True);raise SystemExit(code)
