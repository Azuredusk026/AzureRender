import os,sys,json,hashlib,struct,time,traceback
from pathlib import Path
import renderdoc as rd
request=json.loads(Path('D:\\Projects\\FYP\\Project\\AzureRender\\build\\runs\\20261031-122504-projected-footprint-quality-5daf40\\capture-inputs-v2\\request.json').read_text(encoding='utf-8'));output=Path(request['output']);sys.path.insert(0,str(Path(request['engine'])/'tools'))
from native_render.renderdoc_replay import _descriptor
capture=controller=None;report=dict(status='failed',toolVersion=rd.GetVersionString(),files=[],candidates=[],startedUnix=time.time());total=0;code=1
sha=lambda data:hashlib.sha256(data).hexdigest()
def publish(name,data):
 global total
 total+=len(data);assert total<=request['maximumBytes'],'Export byte budget exceeded'
 with (output/name).open('xb') as stream:stream.write(data)
 row=dict(file=name,bytes=len(data),sha256=sha(data));report['files'].append(row);return row

def flatten(actions):
 for action in actions:
  yield action
  for child in flatten(action.children):yield child
try:
 capture=rd.OpenCaptureFile();assert capture.OpenFile(request['capture'],'',None)==rd.ResultCode.Succeeded
 status,controller=capture.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded,str(status)
 report['api']=str(controller.GetAPIProperties().pipelineType)
 textures={str(x.resourceId):x for x in controller.GetTextures()};buffers={str(x.resourceId):x for x in controller.GetBuffers()};actions=list(flatten(controller.GetRootActions()));report['actionCount']=len(actions)
 candidates=[x for x in actions if x.flags&rd.ActionFlags.Dispatch and list(x.dispatchDimension)==request['expectedDispatch']];assert candidates,'No full-scene projected tile dispatch found'
 found=[]
 for action in candidates:
  controller.SetFrameEvent(action.eventId,True);reflection=controller.GetPipelineState().GetShaderReflection(rd.ShaderStage.Compute);digest=sha(bytes(reflection.rawBytes))
  report['candidates'].append(dict(event=action.eventId,dispatch=list(action.dispatchDimension),shaderSha256=digest))
  if digest==request['expectedShaderSha256']:found.append(action.eventId)
 assert len(found)==1,found;event=found[0];report['event']=event;controller.SetFrameEvent(0,True);controller.SetFrameEvent(event,True);pipeline=controller.GetPipelineState();reflection=pipeline.GetShaderReflection(rd.ShaderStage.Compute)
 publish('shader.spv',bytes(reflection.rawBytes));blocks=[]
 for index,block in enumerate(reflection.constantBlocks):
  descriptor=pipeline.GetConstantBlock(rd.ShaderStage.Compute,index,0).descriptor;data=bytes(controller.GetBufferData(descriptor.resource,descriptor.byteOffset,block.byteSize));entry=dict(index=index,name=block.name,bytes=block.byteSize,offset=descriptor.byteOffset,resource=str(descriptor.resource));entry.update(publish('constant-'+str(index)+'.bin',data));blocks.append(entry)
 assert [x['bytes'] for x in blocks]==[480];report['constants']=blocks;report['frameRows']=[list(struct.unpack_from('<4f',(output/'constant-0.bin').read_bytes(),i*16)) for i in range(30)]
 def describe(used,declarations):
  row=_descriptor(used);declaration=declarations[used.access.index];row['name']=declaration.name;row['fixedBindNumber']=getattr(declaration,'fixedBindNumber',None);return row
 inputs=[describe(x,reflection.readOnlyResources) for x in pipeline.GetReadOnlyResources(rd.ShaderStage.Compute)];outputs=[describe(x,reflection.readWriteResources) for x in pipeline.GetReadWriteResources(rd.ShaderStage.Compute)];report['rawReadOnly']=inputs;report['rawReadWrite']=outputs;resources=inputs+outputs;inputNames={'worklist','previousColor','previousDepth','currentDepth','motionInput','surfaceMask','normalRoughness'};outputNames={'outputColor','outputFootprint','outputConfidence'};inputs=[x for x in resources if x['name'] in inputNames];outputs=[x for x in resources if x['name'] in outputNames];assert {x['name'] for x in inputs}==inputNames and {x['name'] for x in outputs}==outputNames,[(x['name'],x['fixedBindNumber']) for x in resources]
 formats={'R32G32B32A32_FLOAT':16,'R16G16B16A16_FLOAT':8,'R32_FLOAT':4,'R8_UNORM':1,'R16G16_UNORM':4,'R11G11B10_FLOAT':4};report['inputs']=inputs;report['outputs']=outputs
 def dump(row,label,roi=None):
  if row['resource'] not in textures:
   info=buffers[row['resource']];size=row['byte_size'] or request['expectedDispatch'][0]*4;data=bytes(controller.GetBufferData(info.resourceId,row['byte_offset'],size));row['data']=publish(label+'.bin',data);return
  texture=textures[row['resource']];fmt=texture.format.Name();assert fmt in formats,fmt;mip=row['first_mip'];width=max(1,texture.width>>mip);height=max(1,texture.height>>mip);data=bytes(controller.GetTextureData(texture.resourceId,rd.Subresource(mip,0,0)));assert len(data)==width*height*formats[fmt]
  row.update(width=width,height=height,texelBytes=formats[fmt])
  if roi:
   x0,y0,x1,y1=roi;stride=width*formats[fmt];data=b''.join(data[y*stride+x0*formats[fmt]:y*stride+x1*formats[fmt]] for y in range(y0,y1));row['regionXYXY']=roi
  row['data']=publish(label+'.bin',data)
 for row in inputs:
  label='input-'+row['name']
  if row['name']=='previousColor':row['export']='metadata only for this footprint diagnosis';continue
  if row['name']=='motionInput':dump(row,label+'-roi',[1060,1100,1460,1360])
  else:dump(row,label)
 for row in outputs:dump(row,'output-'+row['name'])
 confidence=next(x for x in outputs if x['name']=='outputConfidence');controller.SetFrameEvent(0,True);controller.SetFrameEvent(event-1,True);dump(dict(confidence),'confidence-before-dispatch')
 report['debugMessages']=[dict(event=getattr(x,'eventId',getattr(x,'eventID',0)),source=str(x.source),severity=str(x.severity),category=str(x.category),description=x.description) for x in controller.GetDebugMessages()]
 report['status']='exported';report['totalBytes']=total;code=0
except Exception:report['error']=traceback.format_exc()
finally:
 if controller:controller.Shutdown()
 if capture:capture.Shutdown()
 report['finishedUnix']=time.time();(output/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
os._exit(code)
