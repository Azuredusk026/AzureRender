import os,sys,json,time,traceback
from pathlib import Path
import renderdoc as rd
request=json.loads(Path('D:\\Projects\\FYP\\Project\\AzureRender\\build\\runs\\20261031-122504-projected-footprint-quality-5daf40\\capture-indexed\\request.json').read_text(encoding='utf-8'))
sys.path.insert(0,'D:\\Projects\\FYP\\Project\\AzureRender\\tools\\native_render')
from renderdoc_worker import capture_target
receipt=dict(format='RenderDocEvidence/1',operation='capture',source=request['source'],status='failed',artifacts=[],tool_version=rd.GetVersionString(),started_unix=time.time(),request=request,host='qrenderdoc embedded Python; host owns global replay lifetime')
class TargetEnvironment:
 def __getattr__(self,name):return getattr(rd,name)
 def ExecuteAndInject(self,*args):
  args=list(args);environment=list(args[3])
  for name,value in request['environment'].items():
   item=rd.EnvironmentModification();item.name=name;item.value=value;item.mod=rd.EnvMod.Set;environment.append(item)
  args[3]=environment
  return rd.ExecuteAndInject(*args)
code=1
try:
 capture_target(TargetEnvironment(),request,receipt);code=0
except Exception:
 receipt['error']=traceback.format_exc()
finally:
 receipt['finished_unix']=time.time();Path(request['output'],'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
os._exit(code)
