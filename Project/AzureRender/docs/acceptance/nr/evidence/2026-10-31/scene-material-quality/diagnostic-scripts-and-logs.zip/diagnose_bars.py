from pathlib import Path
import sys,json,struct,base64,subprocess,os,re,time,hashlib
import numpy as np
from PIL import Image
root=Path.cwd();run=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));import test_screen_space_reflections_gpu as lab
player=root/'build/ninja-msvc-release/AzurePlayer.exe';out=run/'bars';out.mkdir(exist_ok=False);records=[];prepared=[]
cases=[dict(name='off',enabled=False,roughness=.08),dict(name='linear-smooth',algorithm='linear',roughness=.08),dict(name='projected-smooth',algorithm='projected',roughness=.08),dict(name='linear-mid',algorithm='linear',roughness=.15),dict(name='projected-mid',algorithm='projected',roughness=.15),dict(name='linear-rough',algorithm='linear',roughness=.3),dict(name='projected-rough',algorithm='projected',roughness=.3)]
for case in cases:
 folder=out/case['name'];folder.mkdir();project,expected=lab.prepare(folder/'project',case);target=project.parent/'assets/target.gltf';doc=json.loads(target.read_text());binary=base64.b64decode(doc['buffers'][0]['uri'].split(',',1)[1]);offset=len(binary);assert offset%4==0
 binary+=struct.pack('<8f',0,1,1,1,1,0,0,0);view=len(doc['bufferViews']);accessor=len(doc['accessors']);doc['bufferViews'].append(dict(buffer=0,byteOffset=offset,byteLength=32));doc['accessors'].append(dict(bufferView=view,componentType=5126,count=4,type='VEC2'));doc['meshes'][0]['primitives'][0]['attributes']['TEXCOORD_0']=accessor
 texture=np.zeros((16,64,3),dtype=np.uint8)
 for x in range(64):texture[:,x]=255 if (x//8)%2==0 else 0
 Image.fromarray(texture).save(target.parent/'bars.png');doc['images']=[dict(uri='bars.png')];doc['samplers']=[dict(magFilter=9728,minFilter=9728,wrapS=33071,wrapT=33071)];doc['textures']=[dict(source=0,sampler=0)];doc['materials'][0]['emissiveTexture']=dict(index=0,texCoord=0);doc['buffers'][0]=dict(byteLength=len(binary),uri='data:application/octet-stream;base64,'+base64.b64encode(binary).decode());target.write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8');prepared.append((case,folder,project,expected))
report=dict(status='prepared',intent='Independent vertical-bar source checks: a smooth receiver must preserve contrast, and increasing roughness should widen filtering. Explicit UVs, nearest source sampler, flat normals, no grade/bloom/AA and no production changes.',cases=records,playerSha256=lab.sha(player));result=out/'summary.json';result.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
for _ in range(650):
 p=run/'full-roughness/summary.json'
 if p.exists():
  try:prior=json.loads(p.read_text(encoding='utf-8'))
  except (ValueError,OSError):prior={}
  if prior.get('status')=='captured-diagnostic':break
  if prior.get('status')=='failed':raise RuntimeError('Full roughness diagnostic failed: '+prior.get('error',''))
 time.sleep(1)
else:raise TimeoutError('Prior GPU diagnostic did not finish')
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0;env=os.environ.copy();env['DOTNET_ROOT']='D:/Tools/dotnet9';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH'];images={}
def contrast(values):
 low,high=np.quantile(values,[.1,.9]);return float((high-low)/max(high+low,1e-9))
try:
 report['status']='running'
 for case,folder,project,expected in prepared:
  command=[str(player),'--project',str(project),'--width',str(lab.WIDTH),'--height',str(lab.HEIGHT),'--capture-frames','1','--capture-fps','60','--capture-dir',str(folder/'frames'),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--runtime-report',str(folder/'runtime.json')]
  row=dict(case=case,command=command,status='running',timeoutSeconds=240);records.append(row);result.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');start=time.perf_counter();print('Started',case['name'],flush=True)
  (folder/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
  with (folder/'player.log').open('wb') as log:process=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=240)
  row.update(exitCode=process.returncode,elapsedSeconds=time.perf_counter()-start);assert process.returncode==0
  text=(folder/'player.log').read_text(encoding='utf-8',errors='replace');assert 'Allocator after unload: buffers=0 images=0' in text and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD|\[error\]',text,re.I)
  image=np.asarray(Image.open(folder/'frames/frame_000000.png').convert('RGB'));images[case['name']]=image;linear=lab.linear(image);source=linear[lab.polygon_mask(expected['sourcePolygon'],.7),0];row['sourceContrast']=contrast(source);assert row['sourceContrast']>.8,'Explicit source texture was not visibly resolved'
  if case['name']!='off':
   signal=lab.red_signal(image,images['off']);values=signal[lab.polygon_mask(expected['reflectionPolygon'],.65)];row.update(reflectionContrast=contrast(values),meanReflectionSignal=float(values.mean()),maximumReflectionSignal=float(values.max()));assert row['maximumReflectionSignal']>.1,'Reflected source is absent'
  row['capture']=json.loads((folder/'frames/capture_manifest.json').read_text(encoding='utf-8'));row['status']='captured';print(case['name'],'source contrast',row['sourceContrast'],'reflection',row.get('reflectionContrast'),flush=True)
 smooth=next(x for x in records if x['case']['name']=='projected-smooth');rough=next(x for x in records if x['case']['name']=='projected-rough')
 assert smooth['reflectionContrast']>.65,'Smooth projected reflection lost its independently defined source detail'
 assert rough['reflectionContrast']<smooth['reflectionContrast']*.85,'Projected footprint did not respond to increased roughness'
 assert lab.sha(player)==report['playerSha256'];report['status']='characterization-passed';print('Detailed source and smooth/rough projected filtering controls passed',flush=True)
except Exception as error:report.update(status='failed',error=str(error));raise
finally:result.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
