import os,json,time,hashlib,traceback,struct
from pathlib import Path
import renderdoc as rd
request=json.loads(Path('D:\\Projects\\FYP\\Project\\AzureRender\\build\\runs\\20261031-122504-projected-footprint-quality-5daf40\\filter-parameters\\request.json').read_text());out=Path(request['output']);report={'status':'failed','events':[]};cap=ctrl=None;code=1
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(request['capture'],'',None)==rd.ResultCode.Succeeded
 status,ctrl=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 def flatten(actions):
  for a in actions:
   yield a
   for child in flatten(a.children):yield child
 for a in flatten(ctrl.GetRootActions()):
  if not a.flags&rd.ActionFlags.Dispatch or list(a.dispatchDimension)!=[160,90,1]:continue
  ctrl.SetFrameEvent(a.eventId,True);p=ctrl.GetPipelineState();reflection=p.GetShaderReflection(rd.ShaderStage.Compute)
  if hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()!=request['shaderSha256']:continue
  desc=p.GetConstantBlock(rd.ShaderStage.Compute,0,0).descriptor;data=bytes(ctrl.GetBufferData(desc.resource,desc.byteOffset,64));row={'event':a.eventId,'rows':[list(struct.unpack_from('<4f',data,i*16)) for i in range(4)]};report['events'].append(row)
 assert len(report['events'])==1,report
 assert report['events'][0]['rows'][0][2]==6 and report['events'][0]['rows'][3][1]==1
 report['status']='verified';code=0
except Exception:report['error']=traceback.format_exc()
finally:
 if ctrl:ctrl.Shutdown()
 if cap:cap.Shutdown()
 (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(code)
