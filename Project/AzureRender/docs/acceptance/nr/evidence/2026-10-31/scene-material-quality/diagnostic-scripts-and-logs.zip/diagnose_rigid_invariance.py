from pathlib import Path
import json,shutil,subprocess,os,re,time,sys
import numpy as np
from PIL import Image
root=Path.cwd();run=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));import test_screen_space_reflections_gpu as lab
base=run/'bars';baseline=json.loads((base/'summary.json').read_text());assert baseline['status']=='characterization-passed';previous={x['case']['name']:x for x in baseline['cases']}
out=run/'rigid-invariance';out.mkdir(exist_ok=False);player=root/'build/ninja-msvc-release/AzurePlayer.exe';records=[];images={}
variants=[('off-translate','off',[16,0,-32],False),('linear-mid-translate','linear-mid',[16,0,-32],False),('projected-mid-translate','projected-mid',[16,0,-32],False),('linear-mid-yaw','linear-mid',[0,0,0],True),('projected-mid-yaw','projected-mid',[0,0,0],True)]
report=dict(status='running',hypothesis='Footprint should be invariant under a common rigid scene/camera transform. Test nonzero world translation and 180-degree Y rotation independently of the source roughness. Keep original image-space geometric oracles and UV pattern.',cases=records,playerSha256=lab.sha(player));result=out/'summary.json';startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0;env=os.environ.copy();env['DOTNET_ROOT']='D:/Tools/dotnet9';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
def contrast(v):
 lo,hi=np.quantile(v,[.1,.9]);return float((hi-lo)/max(hi+lo,1e-9))
try:
 for name,source,translation,yaw in variants:
  folder=out/name;folder.mkdir();projectRoot=folder/'project';shutil.copytree(base/source/'project',projectRoot,ignore=shutil.ignore_patterns('.azure'));projects=list(projectRoot.glob('*.azureproject'));assert len(projects)==1;project=projects[0]
  levelPath=projectRoot/'assets/scene.azurelevel';level=json.loads(levelPath.read_text())
  for node in level['nodes']:
   components=node.setdefault('components',{});component=components.setdefault('azure.transform',lab.component('azure.transform',dict(translation=[0,0,0],rotation=[0,0,0],scale=[1,1,1])));data=component['data'];position=np.array(data.get('translation',[0,0,0]),float);rotation=list(data.get('rotation',[0,0,0]))
   if yaw:position*=np.array([-1,1,-1]);rotation=[-rotation[0],rotation[1]+180,rotation[2]]
   data['translation']=(position+translation).tolist();data['rotation']=rotation
  levelPath.write_text(json.dumps(level,indent=2)+'\n',encoding='utf-8');expected=json.loads((projectRoot/'expected.json').read_text())
  command=[str(player),'--project',str(project),'--width',str(lab.WIDTH),'--height',str(lab.HEIGHT),'--capture-frames','1','--capture-fps','60','--capture-dir',str(folder/'frames'),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--runtime-report',str(folder/'runtime.json')]
  row=dict(name=name,base=source,translation=translation,worldYaw180=yaw,command=command,status='running');records.append(row);result.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');(folder/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8');start=time.perf_counter();print('Started',name,flush=True)
  with (folder/'player.log').open('wb') as log:process=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=240)
  row.update(exitCode=process.returncode,elapsedSeconds=time.perf_counter()-start);assert process.returncode==0
  text=(folder/'player.log').read_text(encoding='utf-8',errors='replace');assert 'Allocator after unload: buffers=0 images=0' in text and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD|\[error\]',text,re.I)
  image=np.asarray(Image.open(folder/'frames/frame_000000.png').convert('RGB'));images[name]=image;manifest=json.loads((folder/'frames/capture_manifest.json').read_text());row['capture']=manifest
  for key in ['qaCameraPosition','qaCameraTarget']:
   expectedCamera=np.array(previous[source]['capture'][key]);expectedCamera*=np.array([-1,1,-1]) if yaw else 1;expectedCamera+=translation;assert np.allclose(manifest[key],expectedCamera,rtol=0,atol=1e-4),(name,key,manifest[key],expectedCamera.tolist())
  sourceSignal=lab.linear(image)[lab.polygon_mask(expected['sourcePolygon'],.7),0];row['sourceContrast']=contrast(sourceSignal);assert row['sourceContrast']>.8,'Rigid transform changed the visible source oracle'
  if source!='off':
   off=images['off-translate'] if not yaw else np.asarray(Image.open(base/'off/frames/frame_000000.png').convert('RGB'));values=lab.red_signal(image,off)[lab.polygon_mask(expected['reflectionPolygon'],.65)];row['reflectionContrast']=contrast(values);row['referenceContrast']=previous[source]['reflectionContrast'];row['meanSignal']=float(values.mean());row['maximumSignal']=float(values.max())
  row['status']='captured';print(name,'contrast',row.get('reflectionContrast'),'reference',row.get('referenceContrast'),flush=True)
 for row in records:
  if row['base'].startswith('linear'):assert abs(row['reflectionContrast']-row['referenceContrast'])<.05,'Rigid fixture reference control changed'
 for row in records:
  if row['base'].startswith('projected'):assert abs(row['reflectionContrast']-row['referenceContrast'])<.05,'Projected filtering depends on the absolute world pose'
 assert lab.sha(player)==report['playerSha256'];report['status']='characterization-passed';print('Rigid world/camera invariance passed',flush=True)
except Exception as error:report.update(status='failed',error=str(error));raise
finally:result.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
