import os,sys,json,traceback
from pathlib import Path
code=0
try:
 import renderdoc as rd
 env=rd.EnvironmentModification()
 result=dict(version=rd.GetVersionString(),python=sys.version,environmentFields=[x for x in dir(env) if not x.startswith('_')],environmentEnums=[x for x in dir(rd) if x.startswith('Env')],globalsPresent=[x for x in globals() if x in ('pyrenderdoc','qrenderdoc')],executeDoc=rd.ExecuteAndInject.__doc__,captureOptions=[x for x in dir(rd.CaptureOptions()) if not x.startswith('_')])
 Path('D:\\Projects\\FYP\\Project\\AzureRender\\build\\runs\\20261031-122504-projected-footprint-quality-5daf40\\renderdoc-embedded-probe.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
except Exception:
 code=1;Path('D:\\Projects\\FYP\\Project\\AzureRender\\build\\runs\\20261031-122504-projected-footprint-quality-5daf40\\renderdoc-embedded-probe.json').write_text(json.dumps(dict(error=traceback.format_exc())),encoding='utf-8')
os._exit(code)
