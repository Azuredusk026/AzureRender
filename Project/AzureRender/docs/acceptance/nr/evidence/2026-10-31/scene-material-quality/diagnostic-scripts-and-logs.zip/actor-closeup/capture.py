from pathlib import Path
import subprocess,os,time,json,re,hashlib
r=Path(__file__).resolve().parent;root=Path.cwd();env=os.environ.copy();env['DOTNET_ROOT']='D:/Tools/dotnet9';startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
report={'status':'running','cases':[]};start=time.perf_counter()
try:
 for view in ['beauty','albedo','shaded-normal','object-shadow-visibility']:
  out=r/view;out.mkdir();command=[str(root/'build/ninja-msvc-release/AzurePlayer.exe'),'--project',str(r/'closeup.azureproject'),'--width','1280','--height','1440','--capture-frames','1','--capture-fps','60','--capture-dir',str(out/'frames'),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation',view,'--runtime-report',str(out/'runtime.json')]
  print('START',view,flush=True);t=time.perf_counter()
  with (out/'player.log').open('wb') as log:
   p=subprocess.Popen(command,env=env,stdout=log,stderr=log,startupinfo=startup)
   try:code=p.wait(timeout=600)
   except subprocess.TimeoutExpired:p.kill();p.wait();raise
  text=(out/'player.log').read_text(encoding='utf-8',errors='replace');assert code==0 and 'Allocator after unload: buffers=0 images=0' in text;assert not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD|\[error\]',text,re.I)
  image=out/'frames/frame_000000.png';report['cases'].append({'view':view,'command':command,'exitCode':code,'elapsedSeconds':time.perf_counter()-t,'imageSha256':hashlib.sha256(image.read_bytes()).hexdigest()});(r/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print('DONE',view,flush=True)
 report['status']='captured-diagnostic'
finally:
 report['elapsedSeconds']=time.perf_counter()-start;(r/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
