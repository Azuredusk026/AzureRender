from pathlib import Path
import json,subprocess,os,time,re,hashlib
import numpy as np
from PIL import Image
root=Path.cwd();run=Path(__file__).resolve().parent;out=run/'full-roughness';out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
project=root/'build/runs/20261031-105539-full-scene-character-composition-b37668/project/history-environment.azureproject';player=root/'build/ninja-msvc-release/AzurePlayer.exe'
command=[str(player),'--project',str(project),'--width','2560','--height','1440','--capture-frames','1','--capture-fps','60','--capture-dir',str(out/'frames'),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','roughness','--runtime-report',str(out/'runtime.json')]
report=dict(status='running',scope='Existing actual roughness isolation in the complete projected scene. Display PNG samples are diagnostic; they are not raw floating-point G-buffer readback.',command=command,timeoutSeconds=600,playerSha256=sha(player),projectSha256=sha(project));(out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8');(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0;env=os.environ.copy();env['DOTNET_ROOT']='D:/Tools/dotnet9';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH'];env.update(TEMP=str(out),TMP=str(out));start=time.perf_counter()
try:
 with (out/'player.log').open('wb') as log:
  process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup);report['pid']=process.pid
  try:code=process.wait(timeout=600)
  except subprocess.TimeoutExpired:process.kill();process.wait();raise
 report['exitCode']=code;assert code==0
 text=(out/'player.log').read_text(encoding='utf-8',errors='replace');assert 'Allocator after unload: buffers=0 images=0' in text and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD|\[error\]',text,re.I)
 manifest=json.loads((out/'frames/capture_manifest.json').read_text(encoding='utf-8-sig'));report['capture']=manifest
 assert manifest['screenReflectionAlgorithmRequested']=='projected' and not manifest['screenReflectionHistoryValid']
 image=out/'frames/frame_000000.png';a=np.asarray(Image.open(image).convert('RGB'));roi=a[1100:1360,1060:1460].astype(float)/255
 linear=np.where(roi<=.04045,roi/12.92,((roi+.055)/1.055)**2.4)
 report['centralFloorDisplay']=dict(roiXYXY=[1060,1100,1460,1360],meanRgb=roi.mean(axis=(0,1)).tolist(),maximumChannelSpread=float(np.ptp(roi,axis=2).max()),srgbInverseApproximateQuantiles=np.quantile(linear.mean(axis=2),[0,.1,.5,.9,1]).tolist(),interpretation='Conditional sRGB-inverse display approximation only; validate diagnostic display contract or raw inputs before treating this as material roughness.')
 assert sha(player)==report['playerSha256'] and sha(project)==report['projectSha256'];report['imageSha256']=sha(image);report['status']='captured-diagnostic';print('Full roughness isolation captured',report['centralFloorDisplay'],flush=True)
except Exception as error:report.update(status='failed',error=str(error));raise
finally:report['elapsedSeconds']=time.perf_counter()-start;(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
