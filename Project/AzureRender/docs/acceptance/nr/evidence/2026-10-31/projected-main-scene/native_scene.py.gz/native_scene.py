from pathlib import Path
import hashlib,json,subprocess,os,re,sys,time,shutil
import numpy as np
from PIL import Image
root=Path.cwd();run=Path(__file__).resolve().parent;out=run/'native-release-local';out.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'tools'));import gpu_environment
base=root/'build/runs/20261027-002548-native-hair-layer-region-closure-61c105/main-candidate-v7'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
projectPath=base/'project.azureproject';levelPath=base/'assets/scene.azurelevel';source={str(p.relative_to(root)):sha(p) for p in (projectPath,levelPath)}
project=json.loads(projectPath.read_text(encoding='utf-8'));level=json.loads(levelPath.read_text(encoding='utf-8'))
clone=dict(files=0,copiedTextBytes=0,linkedBinaryBytes=0)
for mount in project['mounts']:
 original=(base/mount['path']).resolve(strict=True);local=out/('mount-'+mount['name']);local.mkdir();mount['path']=local.name
 for sourceFile in original.rglob('*'):
  relative=sourceFile.relative_to(original)
  if '.azure' in relative.parts or not sourceFile.is_file():continue
  destination=local/relative;destination.parent.mkdir(parents=True,exist_ok=True)
  if sourceFile.suffix.lower() in ('.json','.azmeta','.azurelevel','.azureproject','.azscene','.gltf'):
   shutil.copy2(sourceFile,destination);clone['copiedTextBytes']+=sourceFile.stat().st_size
  else:os.link(sourceFile,destination);clone['linkedBinaryBytes']+=sourceFile.stat().st_size
  clone['files']+=1
assets=out/'verification';assets.mkdir();project['mounts'].append(dict(name='verification',path=assets.name));project['startupScene']='verification:/scene.azurelevel'
settings=level['renderSettings'];settings['screenSpaceReflection'].update(schemaVersion=2,algorithm='projected')
(assets/'scene.azurelevel').write_text(json.dumps(level,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');target=out/'project.azureproject';target.write_text(json.dumps(project,indent=2)+'\n',encoding='utf-8')
build=root/'build/ninja-msvc-release';player=build/'AzurePlayer.exe';shaders={p.name:sha(p) for p in (build/'shaders').glob('*.spv')}
command=[str(player),'--project',str(target),'--width','1920','--height','1080','--capture-dir',str(out/'frames'),'--capture-frames','2','--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--runtime-report',str(out/'runtime.json'),'--gpu-timing','--gpu-timing-output',str(out/'gpu-timing.json')]
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
report=dict(status='running',scope='Actual full native project current-frame opt-in; startup and two frames, not steady-state performance or source image equivalence',source=source,clone=clone,playerSha256=sha(player),shaderSet=shaders,command=command,environmentBefore=gpu_environment.snapshot())
start=time.perf_counter()
try:
 with (out/'player.log').open('wb') as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=600)
 report['exitCode']=result.returncode;assert result.returncode==0
 text=(out/'player.log').read_text(encoding='utf-8',errors='replace');assert 'Validation layer: disabled' in text and 'Allocator after unload: buffers=0 images=0' in text
 assert not re.search(r'VUID-|Validation (?:Error|Warning)|\[error\]|SYNC-HAZARD',text,re.I)
 runtime=json.loads((out/'runtime.json').read_text(encoding='utf-8-sig'));assert not runtime['scriptErrors'] and not runtime['presentationErrors']
 manifest=json.loads((out/'frames/capture_manifest.json').read_text(encoding='utf-8-sig'));assert manifest['screenReflectionComputeActive'] and manifest['screenReflectionAlgorithm']=='projected' and manifest['screenReflectionProducer']=='projected-current-frame'
 assert manifest['screenReflectionWidth']==960 and manifest['screenReflectionHeight']==540 and manifest['antiAliasing']==1 and not manifest['screenReflectionHistoryValid']
 images=sorted((out/'frames').glob('frame_*.png'));assert len(images)==2
 for p in images:
  a=np.asarray(Image.open(p).convert('RGB'));assert a.shape==(1080,1920,3) and float(a.mean())>1
 report['images']={p.name:sha(p) for p in images};report['capture']=manifest;report['status']='passed'
 assert all(sha(root/p)==h for p,h in source.items());assert sha(player)==report['playerSha256'] and shaders=={p.name:sha(p) for p in (build/'shaders').glob('*.spv')}
 print('Full native projected current-frame capture passed',flush=True)
except Exception as error:report.update(status='failed',error=str(error));raise
finally:
 report['elapsedSeconds']=time.perf_counter()-start;report['environmentAfter']=gpu_environment.snapshot();(out/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
