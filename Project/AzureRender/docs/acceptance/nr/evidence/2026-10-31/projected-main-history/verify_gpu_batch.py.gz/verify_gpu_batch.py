from pathlib import Path
import json,subprocess,time,sys,os,re
import xml.etree.ElementTree as ET
root=Path.cwd();run=Path(__file__).resolve().parent;data=json.loads((run/'affected-tests.json').read_text());ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
os.environ['DOTNET_ROOT']='D:/Tools/dotnet9';os.environ['PATH']=os.environ['DOTNET_ROOT']+';'+os.environ['PATH']
report=dict(status='waiting-for-full-captures',commands=[]);resultFile=run/'gpu-batch-summary.json'
def save():resultFile.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def execute(name,command):
 print('Started',name,flush=True);item=dict(name=name,command=command,status='running');report['commands'].append(item);save()
 with (run/(name+'.log')).open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 item.update(exitCode=result.returncode,status='passed' if result.returncode==0 else 'failed');save();assert result.returncode==0,name
 print('Passed',name,flush=True)
try:
 save()
 for _ in range(2600):
  p=run/'full-capture-summary.json'
  if p.exists():
   try:current=json.loads(p.read_text(encoding='utf-8'))
   except (ValueError,OSError):current={}
   if current.get('status')=='passed':break
   if current.get('status')=='failed':raise RuntimeError('Full-scene capture failed: '+current.get('error',''))
  time.sleep(1)
 else:raise TimeoutError('Full-scene batch did not terminate within the declared serial budget')
 report['status']='running';save()
 gpuNames=[x for x in data['tests'] if x.endswith('Gpu')];assert len(gpuNames)==14
 gpuPattern='^('+'|'.join(re.escape(x) for x in gpuNames)+')$'
 for config in ('release','debug'):
  execute('ctest-gpu-'+config,[ctest,'--test-dir','build/ninja-msvc-'+config,'-R',gpuPattern,'--output-on-failure','--no-tests=error','-j','1','--output-junit',str(run/('ctest-gpu-'+config+'.xml'))])
  cases=list(ET.parse(run/('ctest-gpu-'+config+'.xml')).getroot().iter('testcase'));assert len(cases)==14 and all(not any(x.tag in ('failure','error','skipped') for x in t) for t in cases)
 execute('player-history-debug',[sys.executable,'-X','utf8','tools/test_projected_scene_reflections.py','--executable',str(root/'build/ninja-msvc-debug/AzurePlayer.exe'),'--output',str(run/'player-history-debug'),'--expected-validation','enabled'])
 for config in ('release','debug'):
  execute('linear-extended-'+config,[sys.executable,'-X','utf8','tools/test_screen_space_reflections_gpu.py','--executable',str(root/('build/ninja-msvc-'+config+'/AzurePlayer.exe')),'--output',str(run/('linear-'+config)),'--suite','extended','--expected-validation','enabled' if config=='debug' else 'disabled'])
 report['status']='passed';print('All affected GPU and actual Player batches passed',flush=True)
except Exception as error:report.update(status='failed',error=str(error));raise
finally:save()
