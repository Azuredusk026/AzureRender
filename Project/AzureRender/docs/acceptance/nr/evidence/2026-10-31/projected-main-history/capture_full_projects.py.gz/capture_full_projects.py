from pathlib import Path
import json,hashlib,subprocess,os,re,time,traceback
import numpy as np
from PIL import Image
root=Path.cwd();run=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=root/'build/runs/20261031-105539-full-scene-character-composition-b37668/project';player=root/'build/ninja-msvc-release/AzurePlayer.exe';shaders=root/'build/ninja-msvc-release/shaders'
frozen={p.name:sha(p) for p in shaders.glob('*.spv')};playerSha=sha(player);projects=read(run/'full-projects.json')
refs=dict(environment=root/'build/runs/20261031-102704-preinstall-visual-audit-b55e42/current-full/frames',actor=root/'build/runs/20261031-105539-full-scene-character-composition-b37668/visible/frames')
cases=[dict(name='linear-environment',kind='environment',project=root/'build/runs/20261029-045743-snapshot-shading-budget-8ee0b1/full-candidate/enclosure-sampler.azureproject',algorithm='linear'),dict(name='linear-actor',kind='actor',project=base/'full-character-visible.azureproject',algorithm='linear')]+[dict(name='projected-'+x['kind'],kind=x['kind'],project=root/x['project'],algorithm='projected') for x in projects]
prior={x['name']:x for x in read(run/'full-capture-summary-initial-script-error.json')['cases']}
report=dict(status='running',scope='Four Release functional captures: default linear three-frame prefixes against actual complete-scene references, then projected submitted history in both complete environments. Fixed 2560x1440, 60 Hz simulation; not a sustained performance or full SSIM gate.',playerSha256=playerSha,shaderSet=frozen,cases=[])
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
env=os.environ.copy();env['DOTNET_ROOT']='D:/Tools/dotnet9';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH'];env['PYTHONUTF8']='1'
try:
 for case in cases:
  out=run/('full-'+case['name']);reuse=prior.get(case['name']);out.mkdir(exist_ok=bool(reuse));reference=read(refs[case['kind']]/'capture_manifest.json')
  command=[str(player),'--project',str(case['project']),'--width','2560','--height','1440','--capture-frames','3','--capture-fps','60','--capture-dir',str(out/'frames'),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--runtime-report',str(out/'runtime.json')]
  row=dict(name=case['name'],status='running',command=command,timeoutSeconds=600,projectSha256=sha(case['project']));report['cases'].append(row);print('Started',case['name'],flush=True)
  (out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8');(run/'full-capture-summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
  start=time.perf_counter();local=env.copy();local.update(TEMP=str(out),TMP=str(out))
  if reuse:
   assert reuse['exitCode']==0 and reuse['command']==command and reuse['projectSha256']==row['projectSha256']
   row.update(exitCode=0,elapsedSeconds=reuse['elapsedSeconds'],pid=reuse['pid'],reusedCompletedCapture=True)
  else:
   with (out/'player.log').open('wb') as log:
    process=subprocess.Popen(command,cwd=root,env=local,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup);row['pid']=process.pid
    try:row['exitCode']=process.wait(timeout=600)
    except subprocess.TimeoutExpired:process.kill();process.wait();raise
   row['elapsedSeconds']=time.perf_counter()-start
  assert row['exitCode']==0
  text=(out/'player.log').read_text(encoding='utf-8',errors='replace');assert 'Allocator after unload: buffers=0 images=0' in text and 'Validation layer: disabled' in text
  assert not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD|\[error\]',text,re.I)
  runtime=read(out/'runtime.json');assert not runtime['scriptErrors'] and not runtime['presentationErrors']
  manifest=read(out/'frames/capture_manifest.json');row['capture']=manifest
  for key in ('qaCameraPosition','qaCameraTarget','gradeSettings','viewFogEnabled','viewFogAnalyticEnabled','viewFogMatch','viewFogFrameLayoutVersion','antiAliasing'):assert manifest[key]==reference[key],(case['name'],key)
  assert manifest['screenReflectionAlgorithm']==case['algorithm'] and manifest['screenReflectionHistoryValid'] and manifest['screenReflectionTemporalActive']
  assert manifest['screenReflectionHistoryInputSubmission']==2
  if case['algorithm']=='projected':assert manifest['screenReflectionProducer']=='projected-history' and manifest['screenReflectionReprojectionBytes']==0
  if case['kind']=='actor':
   actor=next(x for x in runtime['animations'] if x['node']=='hero');assert .03<=actor['time']<=.034;row['actorAnimation']=actor
  images=sorted((out/'frames').glob('frame_*.png'));assert len(images)==3;row['images']=[]
  for image in images:
   expected=refs[case['kind']]/image.name;a=np.asarray(Image.open(image).convert('RGB')).astype(np.int16);b=np.asarray(Image.open(expected).convert('RGB')).astype(np.int16);delta=np.abs(a-b)
   item=dict(frame=image.name,sha256=sha(image),pngBytesExact=image.read_bytes()==expected.read_bytes(),differentPixels=int(np.any(delta,axis=2).sum()),maximumChannelError=int(delta.max()),meanAbsoluteByteError=float(delta.mean()));row['images'].append(item)
   if case['algorithm']=='linear':assert item['pngBytesExact'],(case['name'],item)
  assert sha(player)==playerSha and frozen=={p.name:sha(p) for p in shaders.glob('*.spv')} and sha(case['project'])==row['projectSha256']
  row['status']='passed';print('Passed',case['name'],round(row['elapsedSeconds'],3),'seconds',flush=True)
  (run/'full-capture-summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
 report['status']='passed'
except Exception as error:report.update(status='failed',error=str(error));traceback.print_exc();raise
finally:(run/'full-capture-summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
