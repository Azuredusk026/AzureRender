from pathlib import Path
import sys,json,os,traceback
import numpy as np
root=Path.cwd();run=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));import test_screen_space_reflections_gpu as lab
os.environ['DOTNET_ROOT']='D:/Tools/dotnet9';os.environ['PATH']=os.environ['DOTNET_ROOT']+';'+os.environ['PATH']
label=sys.argv[1];out=run/label;out.mkdir(exist_ok=False);player=root/'build/ninja-msvc-release/AzurePlayer.exe'
report=dict(status='running',scope='Actual projected history must preserve the existing moving-source reflection oracle without relaxing its budgets',captures=[],metrics=[],playerSha256=lab.sha(player))
try:
 off,record=lab.capture(player,out/'off','indexed',dict(name='off',enabled=False),False,'disabled');report['captures'].append(record)
 frames,record=lab.capture(player,out/'motion','indexed',dict(name='motion',algorithm='projected',motion=True,frames=3),False,'disabled');report['captures'].append(record)
 manifest=json.loads((out/'motion/frames/capture_manifest.json').read_text(encoding='utf-8'))
 report['diagnostics']={k:v for k,v in manifest.items() if k.startswith('screenReflection')}
 assert manifest['screenReflectionHistoryValid'] and manifest['screenReflectionTemporalActive'] and manifest['screenReflectionHistoryInputSubmission']==2,report['diagnostics']
 for i,x in [(0,lab.LEFT),(2,lab.RIGHT)]:report['metrics'].append(lab.measure_reflection(frames[i],off[0],lab.oracle(x),'projected-history-motion-'+str(i)))
 observed=np.array(report['metrics'][1]['weightedCentroid'])-np.array(report['metrics'][0]['weightedCentroid']);wanted=np.array(lab.oracle(lab.RIGHT)['reflectionCenter'])-np.array(lab.oracle(lab.LEFT)['reflectionCenter'])
 assert observed[0]>20 and np.linalg.norm(observed-wanted)<12,(observed.tolist(),wanted.tolist())
 report['status']='passed';print('Projected submitted history preserves moving-source reflection',flush=True)
except Exception as error:report.update(status='failed',error=str(error));traceback.print_exc();raise
finally:(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
