from pathlib import Path
import json,time,subprocess,hashlib,os,re
from PIL import Image
import numpy as np
root=Path.cwd();run=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for _ in range(1000):
 p=run/'gpu-batch-summary.json'
 if p.exists():
  try:batch=read(p)
  except (ValueError,OSError):batch={}
  if batch.get('status')=='passed':break
  if batch.get('status')=='failed':raise RuntimeError('GPU batch failed: '+batch.get('error',''))
 time.sleep(1)
else:raise TimeoutError('GPU batch did not finish')
player=run/'control/AzurePlayer.exe';project=root/read(run/'full-projects.json')[0]['project'];out=run/'frozen-current-full';out.mkdir(exist_ok=False)
command=[str(player),'--project',str(project),'--width','2560','--height','1440','--capture-frames','1','--capture-fps','60','--capture-dir',str(out/'frames'),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--runtime-report',str(out/'runtime.json')]
report=dict(status='running',intent='Determine whether broad floor filtering is already present in the frozen pre-history scene integration, using the identical complete scene and initial frame. This is a diagnostic, not a changed visual acceptance threshold.',command=command,timeoutSeconds=600,playerSha256=sha(player),projectSha256=sha(project));(out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0;env=os.environ.copy();env['DOTNET_ROOT']='D:/Tools/dotnet9';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH'];env.update(TEMP=str(out),TMP=str(out));start=time.perf_counter()
try:
 print('Started frozen pre-history full-scene diagnostic',flush=True)
 with (out/'player.log').open('wb') as log:
  process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup);report['pid']=process.pid;(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
  try:code=process.wait(timeout=600)
  except subprocess.TimeoutExpired:process.kill();process.wait();raise
 report['exitCode']=code;assert code==0
 text=(out/'player.log').read_text(encoding='utf-8',errors='replace');assert 'Allocator after unload: buffers=0 images=0' in text and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD|\[error\]',text,re.I)
 manifest=read(out/'frames/capture_manifest.json');assert manifest['screenReflectionProducer']=='projected-current-frame' and not manifest['screenReflectionTemporalPrepared'] and not manifest['screenReflectionHistoryValid'];report['capture']=manifest
 frozen=out/'frames/frame_000000.png';current=run/'full-projected-environment/frames/frame_000000.png';a=np.asarray(Image.open(frozen).convert('RGB')).astype(np.int16);b=np.asarray(Image.open(current).convert('RGB')).astype(np.int16);delta=np.abs(a-b)
 report['comparison']=dict(pngBytesExact=frozen.read_bytes()==current.read_bytes(),differentPixels=int(np.any(delta,axis=2).sum()),maximumChannelError=int(delta.max()),frozenSha256=sha(frozen),currentSha256=sha(current));assert sha(player)==report['playerSha256'] and sha(project)==report['projectSha256']
 report['status']='captured-comparison-recorded';print('Frozen full-scene comparison:',report['comparison'],flush=True)
except Exception as error:report.update(status='failed',error=str(error));raise
finally:report['elapsedSeconds']=time.perf_counter()-start;(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
