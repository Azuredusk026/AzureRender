from pathlib import Path
from urllib.parse import unquote
import json,re,subprocess,hashlib,gzip,zipfile
root=Path.cwd();run=Path(__file__).resolve().parent;out=root/'docs/acceptance/nr/evidence/2026-10-31/projected-main-history';path=out/'summary.json';d=json.loads(path.read_text(encoding='utf-8'))
files=['README.md','CHANGELOG.md','docs/runtime/screen-space-reflections.md','docs/plans/azure-engine-plan.md','docs/plans/2026-10-30-development-recovery.md','docs/plans/2026-10-28-reflection-filter-integration.md','docs/plans/2026-10-31-projected-history-motion.md','docs/plans/2026-10-31-full-scene-character-composition.md','docs/plans/2026-10-31-projected-main-history.md','docs/acceptance/nr/projected-main-history.md','docs/acceptance/nr/projected-main-scene.md']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run([str(root/'build/reinstall-environment/venv/Scripts/python.exe'),'-X','utf8','tools/check_doc_style.py',*files],check=True)
errors=[];count=0
for name in files:
 p=root/name;text=re.sub(r'```.*?```','',p.read_text(encoding='utf-8'),flags=re.S)
 for para in re.split(r'\n\s*\n',text):
  if para.lstrip().startswith(('#','-','|','>','![')) or re.match(r'\d+[.)]',para.lstrip()):continue
  assert len(re.findall('[。！？]',para))<=4,(name,para)
 for url in re.findall(r'!?\[[^]\n]*\]\(([^)\n]+)\)',text):
  url=url.strip().strip('<>')
  if url.startswith(('http:','https:','mailto:','#','data:')):continue
  local=unquote(url.split('#',1)[0]);count+=1
  if local and not (p.parent/local).exists():errors.append(dict(file=name,target=local))
assert not errors,errors
(run/'doc-links-final.json').write_text(json.dumps(dict(status='passed',files=len(files),links=count,errors=errors),indent=2)+'\n',encoding='utf-8')
previous=(root/'build/runs/20261031-105539-full-scene-character-composition-b37668/mkdocs.log').read_text(encoding='utf-8-sig');current=(run/'mkdocs-final.log').read_text(encoding='utf-8-sig');assert 'Documentation built in' in current
warnings=lambda text:{x for x in text.splitlines() if 'WARNING' in x or 'contains a link' in x}
assert not warnings(current)-warnings(previous),warnings(current)-warnings(previous)
for row in d['sourceFiles']:assert sha(root/row['file'])==row['sha256'] and subprocess.check_output(['git','hash-object',row['file']],text=True).strip()==row['gitBlob']
for row in d['reusedPublic']['sourceFiles']:assert sha(root/row['file'])==row['sha256']
for name,value in d['preservedUserFiles'].items():assert sha(root/name)==value
p8='docs/acceptance/p8/evidence/2026-10-31/environment-review.json';assert json.loads((root/p8).read_text(encoding='utf-8'))==json.loads(subprocess.check_output(['git','show','HEAD:Project/AzureRender/'+p8],text=True,encoding='utf-8'))
assert d['status']=='scene-history-functionally-verified-filter-quality-pending' and d['frozenCurrentFrame']['comparison']['pngBytesExact']
for row in d['logs']:
 p=root/row['file'];assert sha(p)==row['sha256'] and hashlib.sha256(gzip.decompress(p.read_bytes())).hexdigest()==row['rawSha256']
for row in d['images']:assert sha(root/row['file'])==row['sha256']
zipPath=root/d['smallSceneImages']['file'];assert sha(zipPath)==d['smallSceneImages']['sha256']
with zipfile.ZipFile(zipPath) as bundle:
 for row in d['smallSceneImages']['members']:assert hashlib.sha256(bundle.read(row['file'])).hexdigest()==row['sha256']
d['documentation']=dict(files=[dict(file=n,sha256=sha(root/n)) for n in files],linksChecked=count,paragraphAudit='passed',siteBuild='passed',newWarnings=0,newInvalidAnchors=0,strictSiteAcceptance='pending')
for name in ['verify_history_docs.py','mkdocs-final.log','doc-links-final.json']:
 p=run/name;target=out/(name+'.gz');raw=p.read_bytes();target.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(target.read_bytes())==raw
 d['logs'].append(dict(file=target.relative_to(root).as_posix(),sha256=sha(target),rawSha256=sha(p),bytes=target.stat().st_size))
path.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');subprocess.run(['git','diff','--check','--',*[x['file'] for x in d['sourceFiles']],*files],check=True)
print('PASS:',len(files),'documents;',count,'local links; source, public program, archive and protected user inputs verified; no new site warnings or invalid anchors; NR5 filter quality and P8 gates retained')
