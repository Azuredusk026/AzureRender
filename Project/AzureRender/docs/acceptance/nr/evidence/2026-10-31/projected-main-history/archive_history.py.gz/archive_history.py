from pathlib import Path
import json,hashlib,gzip,zipfile,subprocess,shutil,copy
import xml.etree.ElementTree as ET
root=Path.cwd();run=Path(__file__).resolve().parent;out=root/'docs/acceptance/nr/evidence/2026-10-31/projected-main-history';out.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
full=read(run/'full-capture-summary.json');batch=read(run/'gpu-batch-summary.json');images=read(run/'image-comparisons.json');frozen=read(run/'frozen-current-full/summary.json');expected=read(run/'affected-tests.json')
assert full['status']==batch['status']==images['status']=='passed' and len(images['comparisons'])==226
assert frozen['status']=='captured-comparison-recorded' and frozen['comparison']['pngBytesExact']
assert len(full['cases'])==4 and all(x['status']=='passed' for x in full['cases'])
assert len(batch['commands'])==5 and all(x['status']=='passed' for x in batch['commands'])
configs={}
def cases(path,count):
 values=list(ET.parse(path).getroot().iter('testcase'));assert len(values)==count
 assert all(not any(x.tag in ('failure','error','skipped') for x in v) for v in values)
 return [x.attrib['name'] for x in values]
for config in ('release','debug'):
 cpu=cases(run/('ctest-cpu-'+config+'.xml'),21);gpu=cases(run/('ctest-gpu-'+config+'.xml'),14);latest=cases(run/('ctest-lifecycle-'+config+'.xml'),1)
 assert set(cpu+gpu)==set(expected['tests']) and latest==['AzureRender.ProjectedReflectionScene']
 projected=read(run/('player-history-'+config+'/summary.json'));linear=read(run/('linear-'+config+'/summary.json'))
 assert projected['status']==linear['status']=='passed' and len(projected['captures'])==22 and len(linear['captures'])==44
 configs[config]=dict(affectedTests=cpu+gpu,freshLifecycle=latest,projectedCaptures=22,linearCaptures=44,playerSha256=sha(root/('build/ninja-msvc-'+config+'/AzurePlayer.exe')),editorSha256=sha(root/('build/ninja-msvc-'+config+'/AzureRender.exe')),projectedProgramSha256=sha(root/('build/ninja-msvc-'+config+'/shaders/projected_reflection_trace.comp.spv')))
 assert projected['executableSha256']==configs[config]['playerSha256']
assert configs['release']['playerSha256']==full['playerSha256']
assert configs['release']['projectedProgramSha256']==configs['debug']['projectedProgramSha256']=='f5ec047bbab474b8bc0ab75bee6ffb2a77c7ffb3f36737356c964019442f1aa8'
state=read(run/'handoff-state.json')
for row in state['sources']:assert sha(root/row['file'])==row['sha256']
protected=read(root/'build/runs/20261031-053326-startup-context-d7dce6/preserved-user-files.json')
for name,value in protected.items():assert sha(root/name)==value
public=read(run/'reused-public-verification.json')
for row in public['sourceFiles']:assert sha(root/row['file'])==row['sha256']
assert not subprocess.check_output(['git','diff','--name-only','--','src/render','src/rhi','shaders','CMakeLists.txt'],text=True).strip()
logs=[]
def archive(path,label):
 raw=path.read_bytes();target=out/(label+'.gz');target.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(target.read_bytes())==raw
 logs.append(dict(file=target.relative_to(root).as_posix(),sha256=sha(target),rawSha256=sha(path),bytes=target.stat().st_size))
for p in sorted(run.iterdir()):
 if p.is_file() and p.suffix in ('.json','.log','.xml','.py','.ps1','.txt'):archive(p,p.name)
for folder in ['full-linear-environment','full-linear-actor','full-projected-environment','full-projected-actor','frozen-current-full']:
 for name in ['player.log','runtime.json','command.json']:
  archive(run/folder/name,folder+'-'+name)
for folder in ['player-history-release','player-history-debug','linear-release','linear-debug']:
 archive(run/folder/'summary.json',folder+'-summary.json')
for row in read(run/'full-projects.json'):
 assert sha(root/row['project'])==row['projectSha256'] and sha(root/row['level'])==row['levelSha256'] and sha(root/row['sourceLevel'])==row['sourceSha256']
 original=read(root/row['sourceLevel']);candidate=read(root/row['level']);candidate['renderSettings']['screenSpaceReflection']=original['renderSettings']['screenSpaceReflection'];assert candidate==original
 for key in ['project','level']:archive(root/row[key],Path(row[key]).name)
zipPath=out/'scene-pngs.zip';members=[]
with zipfile.ZipFile(zipPath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
 for folder in ['player-history-release','player-history-debug','linear-release','linear-debug']:
  for p in sorted((run/folder).glob('*/frames/frame_*.png')):
   name=p.relative_to(run).as_posix();bundle.write(p,name);members.append(dict(file=name,sha256=sha(p)))
assert len(members)==172
with zipfile.ZipFile(zipPath) as bundle:
 for row in members:assert hashlib.sha256(bundle.read(row['file'])).hexdigest()==row['sha256']
shutil.copyfile(run/'frozen-current-full/frames/frame_000000.png',out/'current-frame-frozen.png')
quality=read(run/'quality-observation.json');quality['frozenCurrentFrameComparison']=frozen['comparison'];quality['frozenControlConclusion']='The complete-scene initial output matches the pre-history frozen implementation byte-for-byte. Broad floor filtering remains a separate NR5 footprint/material-quality task; history integration did not change this initial image.'
result=dict(schemaVersion=1,status='scene-history-functionally-verified-filter-quality-pending',sourceBaseCommit=state['baseCommit'],ownedRun=run.relative_to(root).as_posix(),sourceFiles=state['sources'],configurations=configs,fullScenes=full,imageComparisons=images,frozenCurrentFrame=frozen,quality=quality,reusedPublic=public,preservedUserFiles=protected,logs=logs,smallSceneImages=dict(file=zipPath.relative_to(root).as_posix(),sha256=sha(zipPath),members=members),images=[dict(file=p.relative_to(root).as_posix(),sha256=sha(p)) for p in sorted(out.glob('*.png'))],redEvidence=read(run/'qualified-red-source.json'),diagnosticNotes=['The initial NullRhi fixture omitted explicit valid attachment formats; qualified red uses RGBA16F and D32.','An initial frozen-source restore kept old mtimes and reused an incompatible object; invalid ABI failure is retained and excluded from qualified red. Fresh source mtimes forced the correct rebuild.','Full-scene capture validation initially referenced absent viewFogMode. Actual captured images were revalidated with declared fog fields without rerendering or changing visual thresholds.'],limitations=['Projected floor filter width, source roughness and formal image parity remain NR5 tasks.','Full captures are three-frame functional prefixes; default linear six images are byte-exact to retained current-machine references. Earlier twelve-frame environment pixel-compatibility pending gates remain unchanged.','Release complete captures disable validation; Debug independent actual Player cases verify the affected resource-graph history paths.','Sustained 1080p60, full animation cycles, long-run, dual-device, physical input and formal SSIM remain separate acceptance scopes.'])
(out/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Archived 35 checks/configuration, 132 actual Player paths, four complete captures, 226 PNG comparisons, frozen initial-frame equivalence and pending filter quality')
