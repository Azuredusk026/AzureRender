from hashlib import sha256
from pathlib import Path
import json, runpy

run=Path(__file__).resolve().parent
base=runpy.run_path(str(run/'iris-production-frozen-recovery.py'))
read,dump,invoke=(base[key] for key in ('read','dump','invoke'))
lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==run
build=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
player=build/'AzurePlayer.exe'
out=run/'cloth-color-adjustment-frozen'
out.mkdir()
before=run/'iris-production-frozen-recovery/frozen-four/frames'
command=read(run/'default-four-command.json')
command[0]=str(player)
for flag,target in (('--capture-dir',out/'frames'),('--runtime-report',out/'runtime.json')):
    command[command.index(flag)+1]=str(target)
after=invoke('nvidia',command,out)
previous=sorted(before.glob('frame_*.png'))
current=sorted(after.glob('frame_*.png'))
assert len(previous)==len(current)==4
h=lambda p:sha256(p.read_bytes()).hexdigest()
original=[row['expectedSha256'] for row in read(run/'default-four-results.json')['frames']]
rows=[dict(name=p.name,activeDriverBaseline=h(p),candidate=h(q),originalDriverBaseline=o,
           activeDriverExact=h(p)==h(q),originalDriverExact=o==h(q)) for p,q,o in zip(previous,current,original)]
dump(out/'results.json',dict(player=h(player),frames=rows))
assert all(row['activeDriverExact'] for row in rows),rows
