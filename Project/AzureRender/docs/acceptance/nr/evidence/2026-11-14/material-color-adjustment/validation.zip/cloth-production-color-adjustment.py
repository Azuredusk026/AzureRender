from hashlib import sha256
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5
import json, runpy, struct, sys
import numpy as np

run=Path(__file__).resolve().parent
repo=run.parents[2]
sys.path.insert(0,str(repo/'tools'))
from native_render.light_lab import generate

root=run/'iris-overlay-geometry-project'
output=run/'cloth-production-color-adjustment'
base=runpy.run_path(str(run/'iris-production-frozen-recovery.py'))
read,dump,invoke=(base[key] for key in ('read','dump','invoke'))
score=runpy.run_path(str(run/'static-quality.py'))
player=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release/AzurePlayer.exe'
lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==run
output.mkdir()

def display(value):
    value=np.clip(value,0,1)
    return np.rint(np.where(value<=.0031308,12.92*value,1.055*value**(1/2.4)-.055)*255).astype(np.int16)

def lab(device,variant):
    folder=output/f'{device}-{variant}'
    generate(folder,'dark')
    model=read(folder/'plane.gltf')
    material=model['materials'][0]
    material['doubleSided']=True
    profile=dict(schemaVersion=2,**{'class':'generic'},displayTransform='linear',radianceScale=.5)
    edge=variant in ('edge','fixed-edge','rim-off')
    if variant!='legacy':
        profile['colorAdjustment']=dict(schemaVersion=1,tint=[.1,.2,.3,.5])
        if variant!='tint':
            profile['colorAdjustment']['rim']=dict(color=[.2,.08,.04],intensity=1.5,width=.5)
    material['extras']=dict(azureRenderMaterial=profile)
    if edge:
        import base64
        item=model['buffers'][0]
        data=bytearray(base64.b64decode(item['uri'].split(',',1)[1]))
        for vertex in range(4):
            struct.pack_into('<3f',data,48+12*vertex,.979795897,0,.2)
        item['uri']='data:application/octet-stream;base64,'+base64.b64encode(data).decode()
    (folder/'plane.gltf').write_text(json.dumps(model))
    command=[str(player),'--project',str(folder/'lab.azureproject'),'--width','64','--height','64',
        '--capture-dir',str(folder/'frames'),'--capture-frames','1','--fixed-frame-step','--qa-camera','scene','--qa-light','scene']
    if variant=='fixed-edge':command.extend(['--disable-bindless','--disable-compute-skinning','--disable-parallel-recording'])
    if variant=='rim-off':command.extend(['--qa-effect','rim','--qa-effect-state','disabled'])
    frame=invoke(device,command,folder)/'frame_000000.png'
    rgb=score['image'](frame).astype(np.int16)[32,32]
    return rgb,sha256(frame.read_bytes()).hexdigest()

def authored_project():
    project=read(root/'eye-shadow-production.azureproject')
    level=read(root/'scene/static-eye-shadow-production.azurelevel')
    hero=next(n for n in level['nodes'] if n['id']=='hero')
    slot='name:M_actor_laevat_cloth_03'
    old=hero['materialSlots'][slot]
    document=read(root/'materials'/f'{old}.azurematerial')
    material=document['surface']['materials'][0]
    profile=material['extras']['azureRenderMaterial']
    assert profile['class']=='fabric' and material['alphaMode']=='BLEND'
    trace=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-212213-native-binding-restoration-d39ea8/frame10401/e1383-ps-constants.json')
    slot6=next(b['variables'] for b in read(trace)['data']['cbufs'] if b['slot']==6)
    enabled,brightness,saturation,contrast=slot6[3]['value']
    width,intensity,_,_=slot6[4]['value']
    assert enabled==1
    profile['colorAdjustment']=dict(schemaVersion=1,brightness=brightness,contrast=contrast,saturation=saturation,
        tint=slot6[8]['value'],rim=dict(color=slot6[9]['value'][:3],intensity=intensity,width=width))
    name='cloth-rim-color-adjustment'
    uid=str(uuid5(NAMESPACE_URL,'azurerender/fixed-10401/'+name))
    asset=root/'materials'/f'{name}.azurematerial'
    dump(asset,document)
    dump(asset.with_suffix('.azurematerial.azmeta'),dict(schemaVersion=1,id=uid,dependencies=[],settings={}))
    hero['materialSlots'][slot]=uid
    dump(root/'scene'/f'{name}.azurelevel',level)
    project['startupScene']=f'stage:/{name}.azurelevel'
    target=root/f'{name}.azureproject';dump(target,project)
    return target,profile['colorAdjustment']

def actual(device,variant,project):
    folder=output/f'{device}-{variant}'
    folder.mkdir()
    command=read(run/f'static-{device}-command.json')
    command[0]=str(player)
    command[command.index('--project')+1]=str(project)
    command[command.index('--capture-dir')+1]=str(folder/'frames')
    frame=invoke(device,command,folder)/'frame_000000.png'
    return score['image'](frame).astype(np.int16),sha256(frame.read_bytes()).hexdigest()

def locations(path):
    return {(p['x'],p['y']) for p in read(run/path)['history']['cloth']}

def save():
    (output/'results.json').write_text(json.dumps(result,indent=2)+'\n')

project,profile=authored_project()
native=locations('native-face-skin-stages/results.json')
assert len(native)==30,len(native)
x,y=np.array(sorted(native)).T
ref=score['image'](score['reference_path']).astype(np.int16)
result=dict(profile=profile,playerSha256=sha256(player.read_bytes()).hexdigest(),devices={})
for device in ('nvidia','intel'):
    row=result['devices'][device]={'lab':{}}
    for variant in ('legacy','tint','front','edge','fixed-edge','rim-off'):
        pixel,digest=lab(device,variant)
        scalar=np.clip((1-.2-.5)/(1-.5),0,1) if variant in ('edge','fixed-edge') else 0
        weight=scalar**2*(3-2*scalar)
        expected=display(np.array([.1,.2,.3])*.25+np.array([.2,.08,.04])*(1.5*.5*weight))
        if variant=='legacy':expected=np.zeros(3,dtype=np.int16)
        row['lab'][variant]=dict(actual=pixel.tolist(),expected=expected.tolist(),digest=digest,
            maximum=int(np.max(np.abs(pixel-expected))))
    save()
    baseline,h0=actual(device,'static-baseline',root/'eye-shadow-production.azureproject')
    candidate,h1=actual(device,'static-rim',project)
    diff=np.max(np.abs(candidate-baseline),axis=2)
    old=np.max(np.abs(baseline-ref),axis=2)
    new=np.max(np.abs(candidate-ref),axis=2)
    row['character']=dict(baselineSha256=h0,candidateSha256=h1,changed=int((diff>0).sum()),
        targetedImproved=int((new[y,x]<old[y,x]).sum()),targetedWorsened=int((new[y,x]>old[y,x]).sum()),
        targetOverEight=[int((e[y,x]>8).sum()) for e in (old,new)],targetPeak=[int(e[y,x].max()) for e in (old,new)],
        frameOverOne=[int((e>1).sum()) for e in (old,new)],frameNewOverOne=int(((old<=1)&(new>1)).sum()),
        targetedPixels=[dict(x=int(i),y=int(j),before=int(old[j,i]),after=int(new[j,i])) for i,j in zip(x,y)])
    save()
    assert all(v['maximum']<=2 for v in row['lab'].values()),row['lab']
print(json.dumps(result))
