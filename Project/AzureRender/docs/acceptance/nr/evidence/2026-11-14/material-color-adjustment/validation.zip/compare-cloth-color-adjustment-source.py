from pathlib import Path
import json,math
import numpy as np

run=Path(__file__).resolve().parent
trace=run/'native-face-cloth-full-trace'
points=np.fromfile(run/'skin-residual-points.bin','<u4').reshape(-1,2)
normals=np.fromfile(run/'engine-cloth-components/967-mipnormal-direct.bin','<f2').reshape(-1,4)
assert len(points)==len(normals)
rows=[]
for f in sorted(trace.glob('1383-*.json')):
    x,y=map(int,f.stem.split('-')[1:])
    state=json.loads(f.read_bytes())
    k=int(np.where((points==[x,y]).all(1))[0][0])
    native=np.array(state['1505']['r12'][1:])
    view=np.array(state['1505']['r2'][:3])
    player=(normals[k,:3].astype(float)*2-1)*[-1,1,1]
    before=np.array(state['2147']['r16'][:3])*.25
    after=np.array(state['2169']['r16'][:3])*.25
    gain=after-before
    assert np.max(np.abs(gain-np.array(state['2168']['r3'][:3])*(2.49*.25)))<1e-6
    assert abs(float(np.dot(native,view))-state['1505']['r13'][3])<1e-6
    rows.append(dict(x=x,y=y,nativeNormal=native.tolist(),nativeView=view.tolist(),
        playerNormalInNativeBasis=player.tolist(),normalAngularError=math.degrees(math.acos(np.clip(np.dot(native,player)/np.linalg.norm(native)/np.linalg.norm(player),-1,1))),
        nativeNormalDotView=float(np.dot(native,view)),playerNormalDotNativeView=float(np.dot(player,view)),
        beforeColorAdjustment=before.tolist(),colorAdjustmentContribution=gain.tolist(),afterColorAdjustment=after.tolist()))
(run/'cloth-color-adjustment-source.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
