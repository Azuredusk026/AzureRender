from hashlib import sha256
from io import BytesIO
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5
import json
import runpy
import struct

import numpy as np
from PIL import Image

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
fixture = grid/'iris-overlay-geometry-project'
textures = grid/'native-cloth-authored-textures'
helpers = runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read, dump, invoke = (helpers[k] for k in ('read','dump','invoke'))
lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==out
source = read(textures/'results.json')['textures']['20']
assert source['format']=='BC7_UNORM' and len(source['levels'])==12


def header(w,h,mips,format,unit):
    flags = 0x2100F if mips>1 else 0x81007
    pitch = w*unit if mips>1 else max(1,(w+3)//4)*max(1,(h+3)//4)*unit
    return b'DDS '+struct.pack('<31I',124,flags,h,w,pitch,0,mips,*([0]*11),
        32,4,0x30315844,0,0,0,0,0,0x401008 if mips>1 else 0x1000,0,0,0,0)+struct.pack('<5I',format,3,0,1,0)


def decode_texture():
    frames=[]
    for entry in source['levels']:
        mip = entry['mip']
        width,height = max(1,source['width']>>mip),max(1,source['height']>>mip)
        payload = (textures/entry['path']).read_bytes()
        assert sha256(payload).hexdigest()==entry['sha256']
        with Image.open(BytesIO(header(width,height,1,98,16)+payload)) as image:
            native = np.asarray(image.convert('RGBA'))[::-1]
            packed = native[:,:,[2,3,0,1]].copy()
            packed[:,:,1] = 255-packed[:,:,1]
            frames.append(packed)
    return frames


base_name = 'cloth-rim-color-adjustment-retest'
base_project = fixture/f'{base_name}.azureproject'
source_material = read(fixture/'materials'/f'{base_name}.azurematerial')
original = source_material['textures']['1']['asset']
with Image.open(fixture/'materials'/f'{original}.png') as image:
    host = np.asarray(image.convert('RGBA'))
levels = decode_texture()
base = levels[0]
assert host.shape==base.shape
match = np.all(host==base,axis=2)
assert int(match.sum())>4_150_000
name = 'cloth-native-packed-parameters'
uid = lambda k:str(uuid5(NAMESPACE_URL,'azurerender/cloth-1383/'+k))
texture = fixture/'materials'/f'{name}.dds'
payload = header(source['width'],source['height'],len(levels),28,4)+b''.join(frame.tobytes() for frame in levels)
texture.write_bytes(payload)
dump(texture.with_suffix('.dds.azmeta'),dict(schemaVersion=1,id=uid(name+'.dds'),dependencies=[],settings=dict(texture=dict(
    schemaVersion=1,usage='linear',colorSpace='linear',mipPolicy='generate',mipFilter='nearest',anisotropy=1,mipBias=-1))))
source_material['textures']['1']['asset']=uid(name+'.dds')
asset = fixture/'materials'/f'{name}.azurematerial'
dump(asset,source_material)
dump(asset.with_suffix('.azurematerial.azmeta'),dict(schemaVersion=1,id=uid(name),dependencies=[],settings={}))
level = read(fixture/'scene'/f'{base_name}.azurelevel')
hero = next(n for n in level['nodes'] if n['id']=='hero')
hero['materialSlots']['name:M_actor_laevat_cloth_03']=uid(name)
dump(fixture/'scene'/f'{name}.azurelevel',level)
project = read(base_project)
project['startupScene']=f'stage:/{name}.azurelevel'
candidate = fixture/f'{name}.azureproject'
dump(candidate,project)
scoring = runpy.run_path(str(grid/'static-quality.py'))
image = lambda p: scoring['image'](p).astype(np.int16)
reference = image(scoring['reference_path'])
points = read(grid/'native-face-skin-stages/results.json')['history']['cloth']
x,y = np.array([(p['x'],p['y']) for p in points]).T
assert len(x)==30
report = dict(texture=sha256(payload).hexdigest(),matchingBase=int(match.sum()),baseTexels=int(match.size),
              levels=[sha256(frame.tobytes()).hexdigest() for frame in levels],devices={})
for device in ('nvidia','intel'):
    folder = out/device
    folder.mkdir()
    command = read(grid/f'static-{device}-command.json')
    for flag,value in (('--project',candidate),('--capture-dir',folder/'frames')):
        command[command.index(flag)+1]=str(value)
    frame = invoke(device,command,folder)/'frame_000000.png'
    previous = image(grid/f'cloth-production-color-adjustment-retest/{device}-static-rim/frames/frame_000000.png')
    current = image(frame)
    old,new = [np.abs(a-reference).max(2) for a in (previous,current)]
    report['devices'][device]=dict(frame=sha256(frame.read_bytes()).hexdigest(),
        overEight=[int((e[y,x]>8).sum()) for e in (old,new)],peak=[int(e[y,x].max()) for e in (old,new)],
        errors=new[y,x].tolist(),newOverOne=int(((old<=1)&(new>1)).sum()),changedPixels=int(np.any(previous!=current,axis=2).sum()))
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
