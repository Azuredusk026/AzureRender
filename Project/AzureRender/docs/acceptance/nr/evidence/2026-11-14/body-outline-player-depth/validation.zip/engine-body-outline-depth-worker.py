from hashlib import sha256
from pathlib import Path
import json,os,subprocess,traceback,struct
import renderdoc as rd

out=Path(os.environ['AZURE_ENGINE_IRIS_MIP_REPLAY'])
request=json.loads((out/'request.json').read_bytes())
cap=rd.OpenCaptureFile();ctl=None;report=dict(status='failed',events={})
try:
    assert cap.OpenFile(request['capture'],'',None)==rd.ResultCode.Succeeded
    options=rd.ReplayOptions();options.forceGPUVendor=rd.GPUVendor.nVidia;options.forceGPUDeviceID=0x28e0
    status,ctl=cap.OpenCapture(options,None)
    assert status==rd.ResultCode.Succeeded and ctl
    props=ctl.GetAPIProperties()
    assert props.pipelineType==rd.GraphicsAPI.Vulkan and props.vendor==rd.GPUVendor.nVidia and not props.degraded
    def walk(actions):
        for a in actions:
            yield a
            yield from walk(a.children)
    points=[(int(x),int(y)) for x,y,*_ in struct.iter_unpack('<6I',Path(request['points']).read_bytes())]
    assert len(points)==1184
    desc={str(t.resourceId):t for t in ctl.GetTextures()}
    for action in walk(ctl.GetRootActions()):
        if not action.flags&rd.ActionFlags.Drawcall or action.numIndices!=17037:
            continue
        ctl.SetFrameEvent(action.eventId,True)
        pipe=ctl.GetPipelineState()
        v=pipe.GetShaderReflection(rd.ShaderStage.Vertex)
        p=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
        if not v or not p:continue
        target=pipe.GetDepthTarget().resource
        tex=desc.get(str(target))
        if tex is None or (tex.width,tex.height)!=(2560,1440):continue
        vk=ctl.GetVulkanPipelineState()
        row=dict(event=action.eventId,vertex=sha256(bytes(v.rawBytes)).hexdigest(),
            pixel=sha256(bytes(p.rawBytes)).hexdigest(),vertexEntry=v.entryPoint,pixelEntry=p.entryPoint,
            texture=str(target),depthFormat=tex.format.Name())
        rs=vk.rasterizer
        ds=vk.depthStencil
        row['raster']={n:str(getattr(rs,n)) for n in ('cullMode','frontCCW','frontFace','depthBias') if hasattr(rs,n)}
        row['depth']={n:str(getattr(ds,n)) for n in ('depthTestEnable','depthWriteEnable','depthFunction','stencilTestEnable','depthCompareOp') if hasattr(ds,n)}
        for phase,event in [('before',action.eventId-1),('after',action.eventId)]:
            ctl.SetFrameEvent(event,True)
            raw=bytes(ctl.GetTextureData(target,rd.Subresource()))
            stride=len(raw)//(tex.width*tex.height)
            assert stride in (4,8) and len(raw)==tex.width*tex.height*stride
            subset=b''.join(raw[(y*tex.width+x)*stride:(y*tex.width+x+1)*stride] for x,y in points)
            path=out/f'{action.eventId}-{phase}.bin';path.write_bytes(subset)
            row[phase]=dict(file=path.name,stride=stride,sha256=sha256(raw).hexdigest())
        report['events'][action.eventId]=row
    assert report['events']
    report['status']='qualified'
except Exception:report['error']=traceback.format_exc()
finally:
    if ctl:ctl.Shutdown()
    cap.Shutdown()
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)
