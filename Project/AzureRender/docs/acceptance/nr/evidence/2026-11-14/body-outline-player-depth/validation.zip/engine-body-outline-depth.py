from hashlib import sha256
from pathlib import Path
import json,os,re,runpy,subprocess

run=Path(__file__).resolve().parent
lock=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state']=='held' and Path(lock['output'])==run
b=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
out=run/'engine-body-outline-depth'
out.mkdir()
source=run/'iris-overlay-player-rdc/overlay_frame1.rdc'
request=dict(capture=str(source),points=str(run/'native-body-outline-depth/changed-native-pixels.bin'),source=str(run.parents[2]/'shaders/mesh.frag'),
             rules=str(b/'shader-reload.json'),catalog=str(run/'release-base-catalog.json'))
(out/'request.json').write_text(json.dumps(request,indent=2)+'\n')
env=os.environ.copy()
env.update(AZURE_ENGINE_IRIS_MIP_REPLAY=str(out),VK_DRIVER_FILES=str(run/'nv-vk64-active-absolute.json'))
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
with (out/'replay.log').open('wb') as log:
    p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(run/'engine-body-outline-depth-worker.py')],
        cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=420)
report=json.loads((out/'results.json').read_bytes())
assert p.returncode==0 and report['status']=='qualified',report
