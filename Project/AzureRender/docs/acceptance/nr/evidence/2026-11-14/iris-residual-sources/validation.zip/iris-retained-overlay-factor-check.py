"""Interrogate quantized eye-shadow factors on retained captures from both devices."""
from pathlib import Path
import json
import runpy
import numpy as np

run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
helpers=runpy.run_path(str(run/'iris-overlay-main-frame-isolation.py'),run_name='eye_controls')
read,digest,frames,lin,srgb,unpack=(helpers[k] for k in ('read','digest','frame','linear','display','unpack'))
coords,x,y=(helpers[k] for k in ('coords','x','y'))
a,b=[np.fromfile(grid/f'native-iris-stages/event-{e}.bin','<u4') for e in (1230,1245)]
assert len(a)==len(b)==255
under,over=unpack(a),unpack(b)
mask=a!=b
assert mask.sum()==94
ref=frames(helpers['score']['reference_path'])[y,x]
assert np.array_equal(ref,srgb(over))
exact_factor=np.divide(over,under,out=np.ones_like(under),where=under>0)
report={}
for dev,folder in [('nvidia','iris-production-absolute-icd'),('intel','iris-production-captures')]:
    prior=grid/folder
    s=read(prior/f'{dev}-results.json')
    older_y=prior/f'{dev}-enabled/frames/frame_000000.png'
    older_n=prior/f'{dev}-disabled/frames/frame_000000.png'
    assert digest(older_y)==s['candidateSha256']
    u,v=(frames(f)[y,x] for f in (older_n,older_y))
    assert np.array_equal(mask,(u!=v).any(1))
    p=run/f'eye-native-public-{dev}-projected'
    current_path=p/'frames/frame_000000.png'
    q=read(p/'results.json')
    assert digest(current_path)==q['frameSha256']
    out=frames(current_path)[y,x]
    assert int((np.abs(out-ref).max(1)>1).sum())==q['irisOverOne']
    # Bounds propagate one half LSB through display conversion and RGB scaling.
    lo=lin(v-.5)/np.maximum(lin(u+.5),1.e-9)
    hi=lin(v+.5)/np.maximum(lin(u-.5),1.e-9)
    drift=np.maximum(np.maximum(lo-exact_factor,exact_factor-hi),0)
    iout=lin(out)
    correction=np.divide(iout,lin(v),out=np.ones_like(iout),where=lin(v)>0)
    counterfactual=srgb(lin(u)*correction*exact_factor)
    err0,err1=[np.abs(w-ref).max(1) for w in (out,counterfactual)]
    detail=[]
    for i in np.flatnonzero(mask&(err0>1)):
        detail.append(dict(point=coords[i].tolist(),currentError=int(err0[i]),conditionalCorrectionError=int(err1[i]),
            nativeRatio=exact_factor[i].tolist(),retainedFactorLow=lo[i].tolist(),retainedFactorHigh=hi[i].tolist(),
            estimatedFactorDriftLowerBound=drift[i].tolist(),expected=ref[i].tolist(),actual=out[i].tolist()))
    report[dev]=dict(currentCoveredOverOne=int((err0[mask]>1).sum()),modelCoveredOverOne=int((err1[mask]>1).sum()),
        retainedFactorOutsideNativeBound=int((drift[mask].max(1)>.01).sum()),
        actualCurrentPeak=int(err0[mask].max()),modelCurrentPeak=int(err1[mask].max()),
        residuals=sorted(detail,key=lambda v:-v['currentError']))
result=dict(status='retained-overlay-factor-model',scope='Bound older PNG captures. Projected frame only supplies output. Actual projected factor is pending.',
    bothSourceAttachmentsExactAtIris=True,devices=report)
(run/'iris-retained-overlay-factor-check.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
for dev,values in report.items():print(dev,{k:v for k,v in values.items() if k!='residuals'},values['residuals'][:2])
