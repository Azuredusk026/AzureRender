"""Compare retained raster iris with native mip and render-lane measurements."""
from hashlib import sha256
from pathlib import Path
import json
import runpy
import numpy as np

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
run=out.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
read=lambda p:json.loads(p.read_bytes())
stat=runpy.run_path(str(run/'iris-overlay-main-frame-isolation.py'),run_name='memory')
points=stat['coords']
pick=tuple(tuple(x) for x in ([1262,257],[1302,265],[1260,262],[1261,261]))
source=read(grid/'native-iris-bottom-history/results.json')
assert source['status']=='qualified'
history={(p['x'],p['y']):p for p in source['shaderSamples'] if not p['depthFailed'] and not p['stencilFailed']}
assert all(xy in history for xy in pick)
mem=out/'iris-engine-main-direction'
job=read(mem/'request.json')
old=read(mem/'results.json')
assert old['status']=='qualified' and job['points']==points.tolist()
lane=old['lanes']['scene-head-frame']
assert sha256((mem/'mesh-scene-head-frame.spv').read_bytes()).hexdigest()==lane['shader']
replayed=np.array(lane['rows'])
assert replayed.shape==(255,4)
where={tuple(p):i for i,p in enumerate(points)}
read_u=lambda p:np.fromfile(p,'<u4')
overlay=np.stack([stat['unpack'](read_u(grid/f'native-iris-stages/event-{e}.bin')) for e in (1230,1245)])
ratio=np.divide(overlay[1],overlay[0],out=np.ones_like(overlay[0]),where=overlay[0]>0)
residual=read(out/'iris-head-plane-residual.json')
driver_lod=read(grid/'iris-explicit-mips/iris-explicit-mips.json')['devices']
receipt={}
for dev in ('nvidia','intel'):
    mip=grid/'iris-explicit-mips'
    pre=mip/f'{dev}-implicit.bin'
    baseline=read_u(pre)
    assert sha256(pre.read_bytes()).hexdigest()==driver_lod[dev]['implicitSha256']
    ref_mips={}
    for level in (3,4,5,6):
        p=mip/f'{dev}-mip-{level:02d}.bin'
        assert sha256(p.read_bytes()).hexdigest()==driver_lod[dev]['mips'][str(level)]['sha256']
        ref_mips[level]=read_u(p)
    a={tuple(r['point']):r for r in residual[dev]['irisRemainder']}
    ref=stat['frame'](stat['score']['reference_path'])
    player=stat['frame'](run/f'eye-native-public-{dev}-projected/frames/frame_000000.png')
    detail=[]
    for xy in pick:
        i=where[xy]
        p=history[xy]
        x,y=xy
        row=a.get(xy)
        possibilities=[l for l,m in ref_mips.items() if m[i]==baseline[i]]
        if row:assert possibilities==row['sameDeviceNativeLevels']
        implicit_display=stat['display'](stat['unpack'](baseline[i:i+1])[0]*ratio[i])
        if dev=='nvidia':assert abs(implicit_display-ref[y,x]).max()<=1
        detail.append(dict(point=list(xy),primitive=p['primitive'],sourceMips=possibilities,
            sourceDisplayBefore=stat['display'](overlay[0,i]).tolist(),sourceDisplayAfter=ref[y,x].tolist(),
            deviceNativeImplicitWithReferenceMultiplication=implicit_display.tolist(),
            playerActual=player[y,x].tolist(),nvidiaReplayProjectedBefore=stat['display'](replayed[i,:3]).tolist(),
            nvidiaReplayWithNativeMultiplication=stat['display'](replayed[i,:3]*ratio[i]).tolist(),
            sourceMipNeighborDisplays={str(l):stat['display'](stat['unpack'](m[i:i+1])[0]*ratio[i]).tolist()
                for l,m in ref_mips.items()}))
    receipt[dev]=detail
res=dict(status='retained-raster-control',replayScope='NVIDIA Vulkan replay only',
         replayShaderSha256=lane['shader'],points=receipt)
(out/'iris-projected-source-memory.json').write_text(json.dumps(res,indent=2)+'\n',encoding='utf8')
print(json.dumps(res))
