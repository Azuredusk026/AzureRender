from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json

out=Path(__file__).resolve().parent
run=out.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
target=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/iris-residual-sources'
read=lambda p:json.loads(p.read_bytes())
raster=read(out/'iris-projected-source-memory.json')
factor=read(run/'iris-retained-overlay-factor-check.json')
assert raster['status']=='retained-raster-control' and factor['bothSourceAttachmentsExactAtIris']
focus=raster['points']['nvidia'][0]
assert focus['point']==[1262,257]
assert focus['nvidiaReplayWithNativeMultiplication']==focus['playerActual']==[67,20,48]
assert focus['sourceDisplayAfter']==[82,26,56] and focus['sourceDisplayBefore']==[101,57,85]
unc=tuple(zip(raster['points']['nvidia'][1:],raster['points']['intel'][1:]))
for i,(nvidia,intel) in enumerate(unc):
    assert nvidia['point']==intel['point'] and nvidia['sourceMips']==[5] and intel['sourceMips']==[4]
    assert max(abs(a-b) for a,b in zip(intel['deviceNativeImplicitWithReferenceMultiplication'],intel['playerActual']))<=1
files=[Path(__file__).resolve(),out/'iris-projected-source-memory.py',out/'iris-projected-source-memory.json',
       run/'iris-retained-overlay-factor-check.py',run/'iris-retained-overlay-factor-check.json']
target.mkdir(parents=True,exist_ok=True)
manifest={p.name:sha256(p.read_bytes()).hexdigest() for p in files}
with ZipFile(target/'validation.zip','w',ZIP_DEFLATED) as archive:
    for p in files:archive.write(p,p.name)
with ZipFile(target/'validation.zip') as archive:
    assert archive.testzip() is None and set(archive.namelist())==set(manifest)
    assert {n:sha256(archive.read(n)).hexdigest() for n in manifest}==manifest
report=dict(status='verified-retained-evidence',actualSceneStatus='failed-user-review',
    eyeShadowControl={k:focus[k] for k in ('point','primitive','sourceMips','sourceDisplayBefore',
        'sourceDisplayAfter','playerActual','nvidiaReplayProjectedBefore','nvidiaReplayWithNativeMultiplication')},
    samplingControl=[dict(point=nv['point'],nvidiaLevel=nv['sourceMips'],intelLevel=ig['sourceMips'],
        intelNativeReplay=ig['deviceNativeImplicitWithReferenceMultiplication'],intelPlayer=ig['playerActual'])
        for nv,ig in unc],
    projectedCurrentDisableOverlay='pending',
    archive=dict(sha256=sha256((target/'validation.zip').read_bytes()).hexdigest(),members=manifest))
(target/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(report['archive']['sha256'])
