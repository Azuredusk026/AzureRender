#include "rhi/GpuAllocator.hpp"

#include <vk_mem_alloc.h>

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <string_view>
#include <stdexcept>
#include <string>

namespace azurerender::rhi {
namespace {
constexpr VkBufferUsageFlags deviceReadUsage=VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT
    |VK_BUFFER_USAGE_STORAGE_BUFFER_BIT|VK_BUFFER_USAGE_VERTEX_BUFFER_BIT
    |VK_BUFFER_USAGE_INDEX_BUFFER_BIT|VK_BUFFER_USAGE_INDIRECT_BUFFER_BIT
    |VK_BUFFER_USAGE_UNIFORM_TEXEL_BUFFER_BIT|VK_BUFFER_USAGE_STORAGE_TEXEL_BUFFER_BIT;

void accountBufferProperties(GpuAllocatorStatistics& statistics,const GpuBuffer& buffer,VkDeviceSize bytes,bool add) {
    const bool local=(buffer.memoryProperties&VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)!=0;
    const auto update=[&](VkDeviceSize& value){if(add)value+=bytes;else value-=bytes;};
    update(local?statistics.liveDeviceLocalBufferBytes:statistics.liveNonDeviceLocalBufferBytes);
    if(buffer.mapped&&(buffer.usage&deviceReadUsage)){
        update(statistics.liveMappedDeviceBufferBytes);
        if(!local)update(statistics.liveMappedNonLocalDeviceBufferBytes);
    }
}

void check(const VkResult result, const char* what) {
    if (result != VK_SUCCESS) {
        throw std::runtime_error(
            std::string(what) + " failed with VkResult "
            + std::to_string(static_cast<int>(result)));
    }
}

}  // namespace

GpuAllocator::~GpuAllocator() {
    shutdown();
}

void GpuAllocator::initialize(
    const VkInstance instance,
    const VkPhysicalDevice physicalDevice,
    const VkDevice device,
    const std::uint32_t apiVersion) {
    if (allocator_ != nullptr) {
        throw std::runtime_error("GpuAllocator is already initialized");
    }

    // Vulkan entry points are resolved dynamically. The project links the
    // loader rather than a static Vulkan library, so letting VMA fetch pointers
    // through vkGetInstanceProcAddr keeps it independent of how the loader was
    // linked.
    VmaVulkanFunctions functions{};
    functions.vkGetInstanceProcAddr = vkGetInstanceProcAddr;
    functions.vkGetDeviceProcAddr = vkGetDeviceProcAddr;

    VmaAllocatorCreateInfo createInfo{};
    createInfo.instance = instance;
    createInfo.physicalDevice = physicalDevice;
    createInfo.device = device;
    createInfo.vulkanApiVersion = apiVersion;
    createInfo.pVulkanFunctions = &functions;

    check(
        vmaCreateAllocator(&createInfo, &allocator_),
        "vmaCreateAllocator");
    statistics_ = GpuAllocatorStatistics{};
}

void GpuAllocator::shutdown() {
    if (allocator_ == nullptr) {
        return;
    }
    vmaDestroyAllocator(allocator_);
    allocator_ = nullptr;
}

void GpuAllocator::updateMemoryHighWater(){
    const VkPhysicalDeviceMemoryProperties* properties=nullptr;vmaGetMemoryProperties(allocator_,&properties);
    VmaBudget budgets[VK_MAX_MEMORY_HEAPS]{};vmaGetHeapBudgets(allocator_,budgets);
    VkDeviceSize bytes=0;
    for(unsigned heap=0;heap<properties->memoryHeapCount;++heap)
        if(properties->memoryHeaps[heap].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT)bytes+=budgets[heap].statistics.blockBytes;
    statistics_.deviceLocalPeakBytes=std::max(statistics_.deviceLocalPeakBytes,bytes);
}

GpuBuffer GpuAllocator::createBuffer(
    const VkDeviceSize size,
    const VkBufferUsageFlags usage,
    const bool hostVisible) {
    if (allocator_ == nullptr) {
        throw std::runtime_error("GpuAllocator is not initialized");
    }
    if (size == 0) {
        throw std::invalid_argument("GpuAllocator buffer size must be non-zero");
    }

    VkBufferCreateInfo bufferInfo{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bufferInfo.size = size;
    bufferInfo.usage = usage;
    bufferInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;

    VmaAllocationCreateInfo allocationInfo{};
    if (hostVisible) {
        allocationInfo.usage = (usage & deviceReadUsage) != 0
            ? VMA_MEMORY_USAGE_AUTO_PREFER_DEVICE : VMA_MEMORY_USAGE_AUTO_PREFER_HOST;
        allocationInfo.flags =
            VMA_ALLOCATION_CREATE_HOST_ACCESS_SEQUENTIAL_WRITE_BIT
            | VMA_ALLOCATION_CREATE_MAPPED_BIT;
        // Mapped allocations always come from coherent memory so callers
        // never reason about non-coherent ranges; flush() exists for future
        // paths that deliberately drop the requirement.
        allocationInfo.requiredFlags = VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT
            | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
    } else {
        allocationInfo.usage = VMA_MEMORY_USAGE_AUTO_PREFER_DEVICE;
        allocationInfo.requiredFlags = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT;
    }

    GpuBuffer result;
    VmaAllocationInfo info{};
    check(
        vmaCreateBuffer(
            allocator_,
            &bufferInfo,
            &allocationInfo,
            &result.buffer,
            &result.allocation,
            &info),
        "vmaCreateBuffer");
    result.mapped = hostVisible ? info.pMappedData : nullptr;
    result.size = size;
    result.usage=usage;
    result.memoryTypeIndex=info.memoryType;
    const VkPhysicalDeviceMemoryProperties* properties=nullptr;vmaGetMemoryProperties(allocator_,&properties);
    result.memoryProperties=properties->memoryTypes[info.memoryType].propertyFlags;

    ++statistics_.bufferAllocations;
    ++statistics_.liveBuffers;
    statistics_.bufferBytes += info.size;
    statistics_.liveBufferBytes+=info.size;updateMemoryHighWater();
    ++statistics_.bufferMemoryPropertySamples;
    accountBufferProperties(statistics_,result,info.size,true);
    return result;
}

void GpuAllocator::destroyBuffer(GpuBuffer& buffer) noexcept {
    if (allocator_ == nullptr || buffer.buffer == VK_NULL_HANDLE) {
        return;
    }
    VmaAllocationInfo info{};vmaGetAllocationInfo(allocator_,buffer.allocation,&info);
    accountBufferProperties(statistics_,buffer,info.size,false);
    statistics_.liveBufferBytes-=info.size;
    vmaDestroyBuffer(allocator_, buffer.buffer, buffer.allocation);
    if (statistics_.liveBuffers > 0) {
        --statistics_.liveBuffers;
    }
    buffer = GpuBuffer{};
}

GpuImage GpuAllocator::createImage(
    const VkImageCreateInfo& createInfo,
    const bool hostVisible) {
    if (allocator_ == nullptr) {
        throw std::runtime_error("GpuAllocator is not initialized");
    }

    VmaAllocationCreateInfo allocationInfo{};
    if (hostVisible) {
        allocationInfo.usage = VMA_MEMORY_USAGE_AUTO_PREFER_HOST;
        allocationInfo.flags =
            VMA_ALLOCATION_CREATE_HOST_ACCESS_SEQUENTIAL_WRITE_BIT
            | VMA_ALLOCATION_CREATE_MAPPED_BIT;
        allocationInfo.requiredFlags = VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT
            | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
    } else {
        allocationInfo.usage = VMA_MEMORY_USAGE_AUTO_PREFER_DEVICE;
        allocationInfo.requiredFlags = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT;
    }

    GpuImage result;
    VmaAllocationInfo info{};
    VkResult status = VK_ERROR_FEATURE_NOT_PRESENT;
    constexpr VkImageUsageFlags immutableTextureUsage = VK_IMAGE_USAGE_SAMPLED_BIT
        | VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    static const bool diagnosticEnabled = [] {
        const char* setting = std::getenv("AZURE_DIAGNOSTIC_NONLOCAL_TEXTURES");
        return setting && std::string_view(setting) == "1";
    }();
    if (diagnosticEnabled && !hostVisible && createInfo.imageType == VK_IMAGE_TYPE_2D
        && createInfo.extent.depth == 1 && createInfo.arrayLayers == 1 && createInfo.mipLevels >= 2
        && createInfo.samples == VK_SAMPLE_COUNT_1_BIT && createInfo.tiling == VK_IMAGE_TILING_OPTIMAL
        && createInfo.flags == 0 && createInfo.usage == immutableTextureUsage
        && (createInfo.format == VK_FORMAT_R8G8B8A8_UNORM || createInfo.format == VK_FORMAT_R8G8B8A8_SRGB)
        && VkDeviceSize(createInfo.extent.width) * createInfo.extent.height >= VkDeviceSize(1024) * 1024) {
        const VkPhysicalDeviceProperties* device = nullptr;
        vmaGetPhysicalDeviceProperties(allocator_, &device);
        if (device->vendorID == 0x10de) {
            const VkPhysicalDeviceMemoryProperties* properties = nullptr;
            vmaGetMemoryProperties(allocator_, &properties);
            VmaAllocationCreateInfo hostPlacement{};
            hostPlacement.usage = VMA_MEMORY_USAGE_AUTO_PREFER_HOST;
            for (uint32_t i = 0; i < properties->memoryTypeCount; ++i) {
                const auto heap = properties->memoryTypes[i].heapIndex;
                if ((properties->memoryHeaps[heap].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT) == 0) {
                    hostPlacement.memoryTypeBits |= uint32_t{1} << i;
                }
            }
            if (hostPlacement.memoryTypeBits != 0) {
                status = vmaCreateImage(allocator_, &createInfo, &hostPlacement,
                                        &result.image, &result.allocation, &info);
                if (status == VK_SUCCESS) {
                    std::fprintf(stderr, "Nonlocal material image %ux%u format=%d bytes=%llu\n",
                        createInfo.extent.width, createInfo.extent.height, int(createInfo.format),
                        static_cast<unsigned long long>(info.size));
                }
            }
        }
    }
    if (status == VK_ERROR_FEATURE_NOT_PRESENT || status == VK_ERROR_OUT_OF_DEVICE_MEMORY) {
        status = vmaCreateImage(allocator_, &createInfo, &allocationInfo,
                                &result.image, &result.allocation, &info);
    }
    check(status, "vmaCreateImage");
    result.width = createInfo.extent.width;
    result.height = createInfo.extent.height;
    result.mipLevels = createInfo.mipLevels;
    result.arrayLayers = createInfo.arrayLayers;
    result.depth = createInfo.extent.depth;

    ++statistics_.imageAllocations;
    ++statistics_.liveImages;
    statistics_.imageBytes += info.size;
    statistics_.liveImageBytes+=info.size;updateMemoryHighWater();
    return result;
}

void GpuAllocator::destroyImage(GpuImage& image) noexcept {
    if (allocator_ == nullptr || image.image == VK_NULL_HANDLE) {
        return;
    }
    VmaAllocationInfo info{};vmaGetAllocationInfo(allocator_,image.allocation,&info);
    statistics_.liveImageBytes-=info.size;
    vmaDestroyImage(allocator_, image.image, image.allocation);
    if (statistics_.liveImages > 0) {
        --statistics_.liveImages;
    }
    image = GpuImage{};
}

GpuImage GpuAllocator::createImage2D(
    const std::uint32_t width,
    const std::uint32_t height,
    const VkFormat format,
    const VkImageUsageFlags usage,
    const std::uint32_t mipLevels,
    const bool hostVisible) {
    VkImageCreateInfo imageInfo{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    imageInfo.imageType = VK_IMAGE_TYPE_2D;
    imageInfo.extent = {width, height, 1};
    imageInfo.mipLevels = std::max(mipLevels, 1U);
    imageInfo.arrayLayers = 1;
    imageInfo.format = format;
    imageInfo.tiling = VK_IMAGE_TILING_OPTIMAL;
    imageInfo.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    imageInfo.usage = usage;
    imageInfo.samples = VK_SAMPLE_COUNT_1_BIT;
    imageInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    return createImage(imageInfo, hostVisible);
}

void GpuAllocator::flush(
    const GpuBuffer& buffer,
    const VkDeviceSize offset,
    const VkDeviceSize size) {
    if (allocator_ == nullptr || buffer.allocation == nullptr) {
        return;
    }
    check(
        vmaFlushAllocation(allocator_, buffer.allocation, offset, size),
        "vmaFlushAllocation");
}

void GpuAllocator::invalidate(const GpuBuffer& buffer,VkDeviceSize offset,VkDeviceSize size){
    if(!allocator_ || !buffer.allocation)throw std::invalid_argument("Readback requires an allocated buffer");
    check(vmaInvalidateAllocation(allocator_,buffer.allocation,offset,size),"vmaInvalidateAllocation");
}
}  // namespace azurerender::rhi
