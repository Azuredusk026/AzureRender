from collections import defaultdict
import json
import os
from pathlib import Path
from statistics import median
import subprocess

root = Path.cwd().resolve()
out = Path(__file__).resolve().parent
for name, mask in (("nvidia","*nv-vk64*"),("intel","*igvk64*")):
    env = dict(os.environ, VK_LOADER_DRIVERS_SELECT=mask, VK_LAYER_PATH="D:/Tools/VulkanSDK/1.4.350.0/Bin")
    env["PATH"] = os.pathsep.join((str(root / "build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin"), env["PATH"]))
    for key in ("VK_DRIVER_FILES", "VK_ICD_FILENAMES", "VK_INSTANCE_LAYERS", "VK_LAYER_ENABLES"):
        env.pop(key, None)
    proc = subprocess.run([str(out/"probe.exe"),str(out/"probe.spv")], env=env, capture_output=True,
                          text=True, timeout=120)
    (out / (name + ".log")).write_text(proc.stdout + proc.stderr, encoding="utf-8")
    assert proc.returncode == 0 and "validation=0,liveAllocations=0" in proc.stdout, proc.stderr
    placements, samples = [], defaultdict(list)
    for line in proc.stdout.splitlines():
        fields = line.split(",")
        if fields[0] == "mixed":
            placements.append(dict(field.split("=", 1) for field in fields[1:]))
        if fields[0] == "sample":
            _, image_format, mode, _, position, side, time = fields
            samples[(image_format, mode, position, side)].append(float(time))
    assert len(placements) == (2 if name == "nvidia" else 0)
    assert len(samples) == (90 if name == "nvidia" else 0)
    assert all(len(times) == 6 for times in samples.values())
    result = {"supported":bool(placements), "localHostSplitExact":bool(placements), "validation":0,
              "placements":placements, "timingPositionMedianMs":{"/".join(k):median(times) for k,times in samples.items()}}
    (out / (name + ".json")).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(name,result["placements"],len(samples),flush=True)
