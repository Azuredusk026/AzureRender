import json
import os
from pathlib import Path
from statistics import median
import subprocess

root=Path.cwd()
out=Path(__file__).resolve().parent
for name,mask in (("nvidia","*nv-vk64*"),("intel","*igvk64*")):
    env=dict(os.environ,VK_LOADER_DRIVERS_SELECT=mask,VK_LAYER_PATH="D:/Tools/VulkanSDK/1.4.350.0/Bin")
    env["PATH"]=os.pathsep.join(map(str,(root/"build/ninja-msvc-release",root/"build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin",env["PATH"])))
    for flag in ("VK_DRIVER_FILES","VK_ICD_FILENAMES","VK_INSTANCE_LAYERS","VK_LAYER_ENABLES"):
        env.pop(flag,None)
    result=subprocess.run([str(out/"probe.exe"),str(out/"probe.spv")],env=env,capture_output=True,text=True,timeout=150)
    (out/f"{name}.log").write_text(result.stdout+result.stderr,encoding="utf-8")
    assert result.returncode==0 and "validation=0,liveAllocations=0" in result.stdout,(name,result.returncode)
    lines=result.stdout.splitlines()
    metadata=[row for row in lines if row.startswith("format=")]
    assert len(metadata)==2
    timings={}
    for row in lines:
        if row.startswith("sample,"):
            _,format,mode,idx,local,remote=row.split(",")
            timings.setdefault(f"{format}/{mode}",[]).append([float(local),float(remote)])
    assert len(timings)==(6 if name=="nvidia" else 0) or (name=="intel" and len(timings)==6)
    summary={}
    for key,values in timings.items():
        assert len(values)==16
        local,remote=map(median,zip(*values))
        assert local>0 and remote>0
        summary[key]={"localMedianMs":local,"nonLocalMedianMs":remote,"ratio":remote/local,"exact":True}
    (out/f"{name}.json").write_text(json.dumps({"target":lines[0],"imageTypes":metadata,"samples":summary},indent=2)+"\n",encoding="utf-8")
    print(name,summary,flush=True)
