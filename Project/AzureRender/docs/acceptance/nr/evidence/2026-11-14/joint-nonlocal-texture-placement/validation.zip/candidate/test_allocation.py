# Test the real production Vulkan image allocation path and its fallback.
import os
from pathlib import Path
import subprocess
import sys

folder=Path(__file__).resolve().parent
root=Path.cwd()
product=folder/sys.argv[1]
environment=dict(os.environ,AZURE_DIAGNOSTIC_NONLOCAL_TEXTURES="1",VK_LOADER_DRIVERS_SELECT="*nv-vk64*",
                 VK_LAYER_PATH="D:/Tools/VulkanSDK/1.4.350.0/Bin")
environment["PATH"]=os.pathsep.join(map(str,(root/"build/ninja-msvc-release",
    root/"build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin",environment["PATH"])))
value=subprocess.run([str(product)],env=environment,capture_output=True,text=True,timeout=90)
print(value.stdout+value.stderr,end="")
assert value.returncode==0,value.returncode
assert "nonlocal=true" in value.stdout,"Large immutable texture remains in the device-local heap"
assert "smallLocal=true" in value.stdout and "attachmentLocal=true" in value.stdout
