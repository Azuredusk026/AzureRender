from pathlib import Path
import json
import subprocess
import sys
import time

run = Path(__file__).resolve().parent
candidate = Path(sys.argv[1])
deadline = time.monotonic() + 180
while not (candidate / "short-results.json").is_file():
    if time.monotonic() >= deadline:
        raise TimeoutError("The paired control did not return")
    time.sleep(2)
first, placed, last = json.loads((candidate / "short-results.json").read_bytes())
assert placed["role"] == "short-nonlocal"
assert placed["deviceLocalPeakBytes"] <= 1610612736 < first["deviceLocalPeakBytes"] == last["deviceLocalPeakBytes"]
assert placed["gpuFrameMs"]["p95"] <= 16.6 and placed["cpuMs"]["p95"] <= 8
assert placed["gpuFrameMs"]["mean"] <= 1.03 * ((first["gpuFrameMs"]["mean"]+last["gpuFrameMs"]["mean"])/2)
assert placed["workingSetPeakBytes"] <= 2147483648
frames = json.loads((candidate / "original-four/results.json").read_bytes())
assert all(frame["sameDriverExact"] for frame in frames["frames"])
section = candidate / "measure_overlay.py"
code = section.read_text(encoding="utf-8")
code = code.replace('run = Path(__file__).resolve().parent', f'run = Path(__file__).resolve().parent\nplacement = Path({str(candidate)!r})')
code = code.replace('run / "candidate-receipt.json"', 'placement / "candidate-receipt.json"')
code = code.replace('str(run / "AzurePlayer.exe")', 'str(placement / "AzurePlayer.exe")')
measure = run / "measure_overlay.py"
measure.write_text(code,encoding="utf-8")
subprocess.run([sys.executable,str(measure)],check=True,timeout=925)
