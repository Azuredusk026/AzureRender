from pathlib import Path
import subprocess
import sys

run = Path(__file__).resolve().parent
with (run / "green.log").open("wb") as log:
    subprocess.run([sys.executable, str(run / "test_allocation.py"), "green.exe"], stdout=log,
                   stderr=subprocess.STDOUT, check=True, timeout=100)
subprocess.run([sys.executable, str(run / "capture_overlay.py")], check=True, timeout=570)
