from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd().resolve()
run = Path(__file__).resolve().parent
source = Path("D:/Projects/FYP-worktrees/nr-integration-verified/Project/AzureRender")
build = source / "build/catalog-computed"
path = build / "build.ninja"
sys.path.insert(0, str(source / "tools"))
from build_provenance import digest, verify

prior = source / "build/runs/20261113-022822-nr-material-viewquad-main-integration-e65379/candidate-products.json"
base = json.loads(prior.read_bytes())
verify(source, base)
assert base["commit"].startswith("01cc6b2")
lines = path.read_text(encoding="utf-8").splitlines()
allocator_row = next(i for i, line in enumerate(lines) if line.startswith("build CMakeFiles") and "GpuAllocator.cpp.obj:" in line)
player_row = next(i for i, line in enumerate(lines) if line.startswith("build AzurePlayer.exe:"))
build_vars = dict(line.strip().split(" = ", 1) for line in lines[allocator_row+1:allocator_row+7])
player_vars = dict(line.strip().split(" = ", 1) for line in lines[player_row+1:player_row+12])
env = dict(os.environ, VULKAN_SDK="D:/Tools/VulkanSDK/1.4.350.0", VCPKG_ROOT="D:/Tools/vcpkg")
msvc = root / "tools/msvc_env.bat"
allocator_object = run / "GpuAllocator.obj"
cpp = run / "GpuAllocator.candidate.cpp"
inputs = {}
def tracked_command(name, program, words):
    response = run / (name + ".rsp")
    response.write_text(words + "\n", encoding="utf-8")
    inputs[str(response)] = digest(response)
    with (run / (name + ".log")).open("wb") as log:
        subprocess.run([str(msvc), program, "@" + str(response)], cwd=build, env=env,
                       stdout=log, stderr=subprocess.STDOUT, check=True)

tracked_command("compile", "cl.exe",
                f'/nologo /c {build_vars["DEFINES"]} {build_vars["FLAGS"]} {build_vars["INCLUDES"]} /Fo"{allocator_object}" "{cpp}"')
candidate = run / "AzurePlayer.exe"
map_path = run / "link.map"
main_obj = lines[player_row].split(" | ", 1)[0].split()[-1]
tracked_command("link", "link.exe",
                f'/nologo "{main_obj}" "{allocator_object}" /out:"{candidate}" /MAP:"{map_path}" '
                f'/MANIFEST:EMBED /MANIFESTINPUT:"{player_vars["MANIFESTS"]}" {player_vars["LINK_FLAGS"]} {player_vars["LINK_LIBRARIES"]}')
symbols = [line for line in map_path.read_text(errors="replace").splitlines()
           if len(line.split()) > 1 and line.split()[1].startswith("?createImage@GpuAllocator@")]
assert len(symbols) == 1 and "GpuAllocator.obj" in symbols[0], symbols
libs = [build / name for name in player_vars["LINK_LIBRARIES"].split() if (build / name).is_file()]
inputs.update({str(value): digest(value) for value in [cpp, path, allocator_object, candidate, build / main_obj, *libs]})
verify(source, base)
proof = {"schemaVersion":1, "commit":base["commit"], "baseReceiptPath":str(prior), "baseReceiptSha256":digest(prior),
         "inputsAndProducts":inputs, "candidateObjectSymbol":symbols[0].strip()}
(run / "candidate-receipt.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
