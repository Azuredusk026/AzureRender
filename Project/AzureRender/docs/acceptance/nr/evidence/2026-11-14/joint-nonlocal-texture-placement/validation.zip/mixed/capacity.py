from collections import Counter
import csv
import json
from pathlib import Path
import sys
from zipfile import ZipFile

root = Path.cwd()
run = Path(__file__).resolve().parent
tables = Path(sys.argv[1])
with (tables / "nvidia.csv").open(encoding="utf-8") as stream:
    shapes = {
        (int(row["format"]), int(row["width"]), int(row["height"]), int(row["mips"])): row
        for row in csv.DictReader(stream)
    }
pack = root / "docs/acceptance/nr/evidence/2026-11-11/resident-srgb-channel-scope/validation.zip"
with ZipFile(pack) as archive:
    inventory = json.loads(archive.read("texture-inventory.json"))
formats = {"R8G8B8A8_UNORM":37, "R8G8B8A8_SRGB":43}
selected = Counter()
for image in inventory:
    shape = (formats.get(image.get("format")), image.get("width"), image.get("height"), image.get("mips"))
    if shape not in shapes or not image["name"].startswith("2D Image ") or image["width"]*image["height"] < 1024*1024:
        continue
    selected[shape] += 1
assert selected
projections = []
for cutoff in (1,2,3):
    remote = local = 0
    for shape, count in selected.items():
        r = shapes[shape]
        _, width, height, levels = shape
        assert int(r["typeBits"]) & 3 == 3 and int(r["tailFirst"]) >= cutoff
        pw, ph = int(r["pageWidth"]), int(r["pageHeight"])
        high = sum((((width>>mip)+pw-1)//pw)*(((height>>mip)+ph-1)//ph)*int(r["alignment"])
                   for mip in range(min(cutoff,levels)))
        assert high < int(r["virtualBytes"])
        remote += high*count
        local += (int(r["virtualBytes"])-high)*count
    projections.append({"hostHighLevels":cutoff,"hostBytes":remote,"localLowBytes":local})
assert projections[0]["hostBytes"] < projections[1]["hostBytes"] < projections[2]["hostBytes"]
result = {"source":"Frozen frame image inventory and NVIDIA sparse image requirements",
          "images":sum(selected.values()),"shapes":{"/".join(map(str,key)):count for key,count in selected.items()},
          "placement":projections,"scope":"Static sparse allocation estimate. Measured allocator peaks and graphics workloads are independent."}
(run / "capacity.json").write_text(json.dumps(result,indent=2) + "\n", encoding="utf-8")
print(result)
