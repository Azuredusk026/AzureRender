from pathlib import Path
import sys

run = Path(__file__).resolve().parent
source = Path(sys.argv[1])
code = source.read_text(encoding="utf-8")
code = code.replace("#include <algorithm>", "#include <algorithm>\n#include <cstdio>\n#include <cstdlib>\n#include <string_view>")
first = code.index("    GpuImage result;", code.index("GpuImage GpuAllocator::createImage("))
last = code.index("    result.width", first)
code = code[:first] + '''    GpuImage result;
    VmaAllocationInfo info{};
    VkResult status = VK_ERROR_FEATURE_NOT_PRESENT;
    constexpr VkImageUsageFlags immutableTextureUsage = VK_IMAGE_USAGE_SAMPLED_BIT
        | VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    static const bool diagnosticEnabled = [] {
        const char* setting = std::getenv("AZURE_DIAGNOSTIC_NONLOCAL_TEXTURES");
        return setting && std::string_view(setting) == "1";
    }();
    if (diagnosticEnabled && !hostVisible && createInfo.imageType == VK_IMAGE_TYPE_2D
        && createInfo.extent.depth == 1 && createInfo.arrayLayers == 1 && createInfo.mipLevels >= 2
        && createInfo.samples == VK_SAMPLE_COUNT_1_BIT && createInfo.tiling == VK_IMAGE_TILING_OPTIMAL
        && createInfo.flags == 0 && createInfo.usage == immutableTextureUsage
        && (createInfo.format == VK_FORMAT_R8G8B8A8_UNORM || createInfo.format == VK_FORMAT_R8G8B8A8_SRGB)
        && VkDeviceSize(createInfo.extent.width) * createInfo.extent.height >= VkDeviceSize(1024) * 1024) {
        const VkPhysicalDeviceProperties* device = nullptr;
        vmaGetPhysicalDeviceProperties(allocator_, &device);
        if (device->vendorID == 0x10de) {
            const VkPhysicalDeviceMemoryProperties* properties = nullptr;
            vmaGetMemoryProperties(allocator_, &properties);
            VmaAllocationCreateInfo hostPlacement{};
            hostPlacement.usage = VMA_MEMORY_USAGE_AUTO_PREFER_HOST;
            for (uint32_t i = 0; i < properties->memoryTypeCount; ++i) {
                const auto heap = properties->memoryTypes[i].heapIndex;
                if ((properties->memoryHeaps[heap].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT) == 0) {
                    hostPlacement.memoryTypeBits |= uint32_t{1} << i;
                }
            }
            if (hostPlacement.memoryTypeBits != 0) {
                status = vmaCreateImage(allocator_, &createInfo, &hostPlacement,
                                        &result.image, &result.allocation, &info);
                if (status == VK_SUCCESS) {
                    std::fprintf(stderr, "Nonlocal material image %ux%u format=%d bytes=%llu\\n",
                        createInfo.extent.width, createInfo.extent.height, int(createInfo.format),
                        static_cast<unsigned long long>(info.size));
                }
            }
        }
    }
    if (status == VK_ERROR_FEATURE_NOT_PRESENT || status == VK_ERROR_OUT_OF_DEVICE_MEMORY) {
        status = vmaCreateImage(allocator_, &createInfo, &allocationInfo,
                                &result.image, &result.allocation, &info);
    }
    check(status, "vmaCreateImage");
''' + code[last:]
(run / "GpuAllocator.candidate.cpp").write_text(code, encoding="utf-8")
