from hashlib import sha256
import json
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile

root = Path.cwd()
run = Path(__file__).resolve().parent
control = Path(sys.argv[1])
mixed = Path(sys.argv[2])
formal = Path(sys.argv[3])
def read(path):
    return json.loads(path.read_bytes())
def sha(path):
    return sha256(path.read_bytes()).hexdigest()

pixels = read(run / "original-four/results.json")
assert pixels["nonlocalAllocations"] == 224 and pixels["nonlocalBytes"] == 1588625408
assert [row["changedPixels"] for row in pixels["frames"]] == [228, 330, 397, 421]
assert all(frame["sameDriverExact"] for frame in pixels["frames"])
assert "nonlocal=false,smallLocal=true,attachmentLocal=true" in (run/"red.log").read_text()
assert "nonlocal=true,smallLocal=true,attachmentLocal=true" in (run/"green.log").read_text()
short_pairs = read(run / "short-results.json")
assert [r["role"] for r in short_pairs] == ["short-local-before","short-nonlocal","short-local-after"]
first, nonlocal_images, last = short_pairs
assert all(r["sampled"] == 60 and r["drivers"] == ["595.79"] and r["allocatorZero"] for r in short_pairs)
assert nonlocal_images["allocationBytes"] == pixels["nonlocalBytes"]
assert all(r["allocationCount"] == 0 for r in (first,last))
assert first["deviceLocalPeakBytes"] == last["deviceLocalPeakBytes"]
assert nonlocal_images["deviceLocalPeakBytes"] < first["deviceLocalPeakBytes"]
allocated = first["deviceLocalPeakBytes"] - nonlocal_images["deviceLocalPeakBytes"]
peak = read(run/"original-four/timing.json")["allocator"]["deviceLocalPeakBytes"]
mixed_actual={}
for label in ("nvidia","intel"):
    path=mixed/(label+".json")
    if path.is_file():
        mixed_actual[label]=read(path)
mixed_capacity=read(mixed/"capacity.json")
formal_timing=read(formal/"results.json")
assert formal_timing["frames"]==1800 and formal_timing["warmup"]==300 and formal_timing["allocatorZero"]
assert formal_timing["nonlocalBytes"]==pixels["nonlocalBytes"]
assert "nonlocal=false,smallLocal=true,attachmentLocal=true" in (run/"intel.log").read_text()
assert "nonlocal=false,smallLocal=true,attachmentLocal=true" in (run/"nvidia-off.log").read_text()
reduction = ((first["gpuFrameMs"]["mean"]+last["gpuFrameMs"]["mean"])/2
             - nonlocal_images["gpuFrameMs"]["mean"])
limit = 1610612736
result = {"source":pixels["source"], "driver":"595.79", "pixelComparison":pixels, "fourFrameDeviceLocalPeakBytes":peak,
          "shortSamples":short_pairs,"shortDeviceLocalReductionBytes":allocated,
          "shortDeviceLocalHeadroomBytes":limit-nonlocal_images["deviceLocalPeakBytes"],
          "shortGPUFrameMeanReductionMs":reduction,"mixedSparseCapacity":mixed_capacity,"mixedSparseProbe":mixed_actual,
          "frozenZeroPixelPassed":False,"formalTiming":formal_timing,"formalLongRunScope":False,
          "thermalAlignment":read(formal/"thermal-alignment.json"),
          "allocatorFallbacks":{"intel":True,"nvidiaOptionDisabled":True},
          "sampleOrderControl":read(run/"control-order.json")}
receipt = read(run/"candidate-receipt.json")
paths = {}
def files(prefix,folder,names):
    for name in names:
        path=folder/name
        assert path.is_file(),path
        paths[f"{prefix}/{name}"]=path
files("candidate",run,("GpuAllocator.candidate.cpp","allocation_test.cpp","test_allocation.py","red.log","green.log","prepare_overlay.py",
                  "build_overlay.py","compile.rsp","link.rsp","candidate-receipt.json","capture_overlay.py","compare_short.py",
                  "order_and_pixels.py","control-order.json","cross-driver-pixels.json","short-results.json","budget.json","archive.py",
                  "test_fallback.py","run_fallbacks.py","intel.log","nvidia-off.log","run_pixels.py"))
files("control",control,("probe.cpp","probe.comp","nvidia.log","intel.log","run.py","nvidia.json","intel.json"))
files("candidate/original-four",run/"original-four",("timing.json","timing.csv","environment.json","results.json","command.json","player.log"))
for pair in short_pairs:
    name=pair["role"]
    files(name,run/name,("timing.json","timing.csv","environment.json","results.json","command.json","player.log"))
files("mixed",mixed,("capacity.py","capacity.json","prepare_probe.py","probe.cpp","probe.comp","bind.inc","support/VulkanComputeFixture.hpp","run.py"))
for label in mixed_actual:
    files("mixed",mixed,(f"{label}.json",f"{label}.log"))
files("timing",formal,("timing.json","timing.csv","process-memory.json","environment.json","results.json","command.json",
                     "measure_overlay.py","run.py","player.log","thermal_alignment.py","thermal-alignment.json"))
dest=root/"docs/acceptance/nr/evidence/2026-11-14/joint-nonlocal-texture-placement"
dest.mkdir(parents=True,exist_ok=True)
bundle=dest/"validation.zip"
with ZipFile(bundle,"w",ZIP_DEFLATED) as archive:
    for name,path in paths.items():
        archive.write(path,name)
with ZipFile(bundle) as archive:
    assert archive.testzip() is None and set(archive.namelist())==set(paths)
    assert all(archive.read(name)==path.read_bytes() for name,path in paths.items())
assert bundle.stat().st_size < 8*1024*1024
result["archiveSha256"]=sha(bundle)
result["archiveMembers"]=len(paths)
result["candidateExecutableSha256"]=sha(run/"AzurePlayer.exe")
assert result["candidateExecutableSha256"] in receipt["inputsAndProducts"].values()
(dest/"results.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(result["archiveMembers"],result["archiveSha256"])
