#include "support/VulkanComputeFixture.hpp"

using namespace azurerender;

bool deviceLocal(uint32_t size, VkFormat format, VkImageUsageFlags usage, uint32_t levels) {
    test::VulkanComputeFixture host(false, false, false, false, false, false, true);
    auto image = host.allocator.createImage2D(size, size, format, usage, levels);
    const bool local = host.allocator.statistics().deviceLocalPeakBytes > 0;
    host.allocator.destroyImage(image);
    if (host.allocator.statistics().liveImages) throw std::runtime_error("live images");
    host.close();
    if (host.errors.load()) throw std::runtime_error("Vulkan validation reported an error");
    return local;
}

int main() try {
    constexpr VkImageUsageFlags texture =
        VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
    const bool largeLocal = deviceLocal(1024, VK_FORMAT_R8G8B8A8_SRGB, texture, 11);
    const bool smallLocal = deviceLocal(256, VK_FORMAT_R8G8B8A8_SRGB, texture, 9);
    const bool attachmentLocal = deviceLocal(
        1024, VK_FORMAT_R8G8B8A8_UNORM, texture | VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT, 11);
    std::cout << std::boolalpha << "nonlocal=" << !largeLocal << ",smallLocal=" << smallLocal
              << ",attachmentLocal=" << attachmentLocal << '\n';
    return 0;
} catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
}
