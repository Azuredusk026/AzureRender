from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
from statistics import median
import sys

import numpy as np
from PIL import Image

caller = Path(__file__).resolve().parent
root = Path.cwd().resolve()
control = Path(sys.argv[1])
history = root / "build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames"
current = root / "build/runs/20261114-020728-nr-joint-59579-main-visual-1bcbe5/baseline-original-four/frames"
ordered = defaultdict(lambda: defaultdict(list))
for row in (control / "nvidia.log").read_text().splitlines():
    fields = row.split(",")
    if fields[0] != "sample":
        continue
    _, image_format, mode, index, local, host = fields
    index = int(index)
    if index == 0:
        continue
    placements = (("localFirst", float(local)), ("hostSecond", float(host))) if index % 2 == 0 else (
        ("hostFirst", float(host)), ("localSecond", float(local)))
    for key, value in placements:
        ordered[f"{image_format}/{mode}"][key].append(value)
timings = {mode: {place: {"count":len(samples),"medianMs":median(samples)} for place, samples in groups.items()}
           for mode, groups in ordered.items()}
assert len(timings) == 6 and all(abs(stats["localFirst"]["count"] - stats["hostFirst"]["count"]) == 1 for stats in timings.values())
(caller / "control-order.json").write_text(json.dumps(timings, indent=2) + "\n", encoding="utf-8")

localized = []
for path in sorted(history.glob("frame_*.png")):
    with Image.open(path) as image:
        old = np.asarray(image.convert("RGB"), dtype=np.int16)
    with Image.open(current / path.name) as image:
        new = np.asarray(image.convert("RGB"), dtype=np.int16)
    delta = new - old
    mask = np.any(delta != 0, axis=2)
    y, x = np.where(mask)
    maxima = np.max(np.abs(delta[y, x]), axis=1)
    persistent = {tuple(point) for point in np.argwhere(mask)}
    if localized:
        previous = localized[-1].pop("_points")
        localized[-1]["sharedWithNext"] = len(previous & persistent)
    localized.append({"frame":path.name, "size":[int(old.shape[1]),int(old.shape[0])],
        "frozenSha256":sha256(path.read_bytes()).hexdigest(),
        "currentSha256":sha256((current / path.name).read_bytes()).hexdigest(),
        "changedPixels":len(x), "signedChannelDelta":{int(value):int(count) for value,count in Counter(delta[y,x][delta[y,x]!=0]).items()},
        "maximumDeltaHistogram":{int(value):int(count) for value,count in Counter(maxima).items()},
        "changedRegions64":len(set(zip(x//64,y//64))), "_points":persistent,
        "aboveOne":[{"xy":[int(x[i]),int(y[i])],"rgbFrozen":old[y[i],x[i]].tolist(),"rgbCurrent":new[y[i],x[i]].tolist()}
                    for i in np.where(maxima>1)[0]]})
localized[-1].pop("_points")
assert [row["changedPixels"] for row in localized] == [228,330,397,421]
(caller / "cross-driver-pixels.json").write_text(json.dumps(localized, indent=2) + "\n", encoding="utf-8")
print([ {key: row[key] for key in ("changedPixels","changedRegions64","maximumDeltaHistogram")} for row in localized])
