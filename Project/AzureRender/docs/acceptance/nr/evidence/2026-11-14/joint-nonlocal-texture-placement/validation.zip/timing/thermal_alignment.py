from pathlib import Path
import csv
import json
from statistics import median, mean
import sys

import numpy as np

run = Path(sys.argv[1])
environment = json.loads((run / "environment.json").read_bytes())
timing = json.loads((run / "timing.json").read_bytes())
with (run / "timing.csv").open() as stream:
    rows = list(csv.DictReader(stream))
assert [int(row["frame"]) for row in rows] == list(range(1, 2101))
gpu = environment["runObservations"]
log = (run / "player.log").read_text(encoding="utf-8", errors="replace").splitlines()
def time_for(message):
    row = next(row for row in log if message in row)
    return int(row.split("]")[0][1:])/1000
logical_device = time_for("Starting logical device")
startup = time_for("Starting graphics pipelines") - logical_device
start = time_for("Outline mask allocated: frame=0") - logical_device
first_heat = next(row for row in gpu if row["thermalSlowdown"]["software"])
before = [row for row in gpu if start <= row["seconds"] < first_heat["seconds"] and row["gpuUtilization"] > 80]
after = [row for row in gpu if row["seconds"] >= first_heat["seconds"] and row["gpuUtilization"] > 80]
gpu_frames = timing["gpuPassTimings"]
def summarize(group):
    return {k:{"minimum":min(row[k] for row in group),"median":median(row[k] for row in group),"maximum":max(row[k] for row in group)}
            for k in ("temperature","graphicsClockMHz","gpuUtilization","powerDrawWatts")}
res = {"graphicsPipelineStartupOffsetSeconds":startup,"firstRenderApproxSeconds":start,"firstSoftwareThermalSeconds":first_heat["seconds"],
       "startToFirstThermalApproxSeconds":first_heat["seconds"]-start,"preThermalActive":summarize(before),"thermalLateActive":summarize(after),
       "earlySlices":{}, "gpuPassTimingsSummary":gpu_frames}
for begin,end in ((60,120),(120,180),(180,240),(240,300),(300,360),(300,600),(1800,2100)):
    res["earlySlices"][f"{begin+1}-{end}"]={key:{"mean":float(mean(float(row[key]) for row in rows[begin:end])),
        "p95":float(np.percentile([float(row[key]) for row in rows[begin:end]],95))}
        for key in ("frameMs","sceneMs","shadowMs","postProcessMs")}
(run / "thermal-alignment.json").write_text(json.dumps(res,indent=2)+"\n",encoding="utf-8")
print(json.dumps({k:v for k,v in res.items() if k != "gpuPassTimingsSummary"},indent=2))
