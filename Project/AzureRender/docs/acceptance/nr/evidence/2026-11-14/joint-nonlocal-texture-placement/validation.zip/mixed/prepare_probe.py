from pathlib import Path
import sys

run = Path(__file__).resolve().parent
previous, source = map(Path, sys.argv[1:])
fixture = (source / "tests/support/VulkanComputeFixture.hpp").read_text(encoding="utf-8")
fixture = fixture.replace("(families[index].queueFlags&VK_QUEUE_COMPUTE_BIT)!=0",
    "(families[index].queueFlags&(VK_QUEUE_COMPUTE_BIT|VK_QUEUE_SPARSE_BINDING_BIT))"
    "==(VK_QUEUE_COMPUTE_BIT|VK_QUEUE_SPARSE_BINDING_BIT)")
fixture = fixture.replace("VkPhysicalDeviceFeatures used{};", """VkPhysicalDeviceFeatures used{};
            if (!features.sparseBinding || !features.sparseResidencyImage2D)
                throw VulkanFeatureUnavailable("Sparse residency is unavailable");
            used.sparseBinding = used.sparseResidencyImage2D = VK_TRUE;""")
inc = run / "support"
inc.mkdir(exist_ok=True)
(inc / "VulkanComputeFixture.hpp").write_text(fixture, encoding="utf-8")
cpp = (previous / "probe.cpp").read_text(encoding="utf-8")
cpp = cpp.replace("VkDeviceMemory memory{};", "VkDeviceMemory memory{};\n    VkDeviceMemory localMemory{};")
cpp = cpp.replace("if (memory) vkFreeMemory(device, memory, nullptr);",
                  "if (memory) vkFreeMemory(device, memory, nullptr);\n        if (localMemory) vkFreeMemory(device, localMemory, nullptr);")
cpp = cpp.replace("unsigned width, unsigned levels, bool local,", "unsigned width, unsigned levels, Placement placement,")
cpp = cpp.replace("void upload(", (run / "bind.inc").read_text(encoding="utf-8") + "\nvoid upload(")
cpp = cpp.replace("    info.imageType =", """    if (placement == Placement::Split) {
        info.flags = VK_IMAGE_CREATE_SPARSE_BINDING_BIT | VK_IMAGE_CREATE_SPARSE_RESIDENCY_BIT;
    }
    info.imageType =""", 1)
cpp = cpp.replace("type = memoryType(memory, requirements.memoryTypeBits, local);",
                  "type = memoryType(memory, requirements.memoryTypeBits, placement == Placement::Local);")
start = cpp.index("    VkMemoryAllocateInfo allocation", cpp.index("void upload("))
end = cpp.index("    host.submit", start)
cpp = cpp[:start]+'''    if (placement == Placement::Split) {
        bytes = bindSplit(host, target, requirements, memory, type, levels, width);
    } else {
        VkMemoryAllocateInfo allocation{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        allocation.allocationSize = requirements.size;
        allocation.memoryTypeIndex = type;
        test::vkRequire(vkAllocateMemory(host.device, &allocation, nullptr, &target.memory), "vkAllocateMemory");
        test::vkRequire(vkBindImageMemory(host.device, target.image, target.memory, 0), "vkBindImageMemory");
        bytes = allocation.allocationSize;
    }
''' + cpp[end:]
cpp = cpp.replace("sizes.maxSets = 2;", "sizes.maxSets = 3;")
cpp = cpp.replace("SAMPLER,2},{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,2", "SAMPLER,3},{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,3")
cpp = cpp.replace("descriptor,2);", "descriptor,3);")
cpp = cpp.replace("local{host.device}, nonlocal{host.device};", "local{host.device}, nonlocal{host.device}, split{host.device};")
cpp = cpp.replace("levels,true,staging", "levels,Placement::Local,staging").replace("levels,false,staging", "levels,Placement::Host,staging")
begin = cpp.index("        backend.writeDescriptorImage({sets[0]")
cpp = cpp[:begin]+'''        VkDeviceSize splitBytes=0;
        uint32_t splitType=0;
        upload(host,split,format,dims,levels,Placement::Split,staging,regions,splitBytes,splitType);
        if (!split.view || splitType != remote || splitBytes == 0)
            throw std::runtime_error("Mixed texture did not use both backing heaps");
''' + cpp[begin:]
begin = cpp.index("        std::vector<uint32_t> reference")
cpp = cpp[:begin]+'''        backend.writeDescriptorImage({sets[2],0,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,split.view,sampler});
''' + cpp[begin:]
begin = cpp.index("        for (unsigned mode=0;mode<3;")
end = cpp.index("\n    }\n    release.reset", begin)
cpp = cpp[:begin] + '''        for (unsigned mode=0;mode<5;++mode) {
            run(sets[0],mode,7);
            host.allocator.invalidate(resultBuffer,0,resultBuffer.size);
            std::memcpy(reference.data(),resultBuffer.mapped,resultBuffer.size);
            for (unsigned side=1; side<3; ++side) {
                run(sets[side],mode,7);
                host.allocator.invalidate(resultBuffer,0,resultBuffer.size);
                if (std::memcmp(reference.data(),resultBuffer.mapped,resultBuffer.size)!=0)
                    throw std::runtime_error("Mixed backing changed shader output bits");
            }
            for (unsigned round=0;round<18;++round) {
                for(unsigned position=0;position<3;++position) {
                    const unsigned side=(position+round)%3;
                    const auto time=run(sets[side],mode,100+round);
                    std::cout<<"sample,"<<format<<','<<mode<<','<<round<<','<<position<<','<<side<<','<<time<<'\\n';
                }
            }
        }
''' + cpp[end:]
(run / "probe.cpp").write_text(cpp, encoding="utf-8")
comp = (previous / "probe.comp").read_text(encoding="utf-8")
comp = comp.replace("} else {\n            vec2 uv", """} else if (parameters.mode >= 3) {
            vec2 uv = (vec2(seed & 65535u, seed >> 16) + vec2(.375,.625)) * (1.0/65536.0);
            color += textureLod(sourceImage,uv,parameters.mode == 3 ? 1.625 : 3.25);
        } else {
            vec2 uv""")
(run / "probe.comp").write_text(comp, encoding="utf-8")
