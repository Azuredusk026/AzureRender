#include "support/VulkanComputeFixture.hpp"
#include "resources/BinaryFile.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <vector>

using namespace azurerender;
namespace {
constexpr unsigned samples = 65536;

struct ImageStorage {
    VkDevice device;
    VkImage image{};
    VkDeviceMemory memory{};
    VkImageView view{};
    ~ImageStorage() {
        if (view) vkDestroyImageView(device, view, nullptr);
        if (image) vkDestroyImage(device, image, nullptr);
        if (memory) vkFreeMemory(device, memory, nullptr);
    }
};

uint32_t memoryType(const VkPhysicalDeviceMemoryProperties& memory, uint32_t mask, bool local) {
    for (uint32_t index = 0; index < memory.memoryTypeCount; ++index) {
        if ((mask & (1U << index)) == 0) continue;
        const auto heap = memory.memoryTypes[index].heapIndex;
        const bool deviceLocal = (memory.memoryHeaps[heap].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT) != 0;
        if (deviceLocal == local) return index;
    }
    return UINT32_MAX;
}

void upload(test::VulkanComputeFixture& host, ImageStorage& target, VkFormat format,
            unsigned width, unsigned levels, bool local, const rhi::GpuBuffer& staging,
            const std::vector<VkBufferImageCopy>& regions, VkDeviceSize& bytes, uint32_t& type) {
    constexpr auto usage = VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    VkImageCreateInfo info{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    info.imageType = VK_IMAGE_TYPE_2D;
    info.format = format;
    info.extent = {width, width, 1};
    info.mipLevels = levels;
    info.arrayLayers = 1;
    info.samples = VK_SAMPLE_COUNT_1_BIT;
    info.tiling = VK_IMAGE_TILING_OPTIMAL;
    info.usage = usage;
    info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    test::vkRequire(vkCreateImage(host.device, &info, nullptr, &target.image), "vkCreateImage");
    VkMemoryRequirements requirements{};
    vkGetImageMemoryRequirements(host.device, target.image, &requirements);
    VkPhysicalDeviceMemoryProperties memory{};
    vkGetPhysicalDeviceMemoryProperties(host.physical, &memory);
    type = memoryType(memory, requirements.memoryTypeBits, local);
    if (type == UINT32_MAX) return;
    VkMemoryAllocateInfo allocation{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    allocation.allocationSize = requirements.size;
    allocation.memoryTypeIndex = type;
    test::vkRequire(vkAllocateMemory(host.device, &allocation, nullptr, &target.memory), "vkAllocateMemory");
    test::vkRequire(vkBindImageMemory(host.device, target.image, target.memory, 0), "vkBindImageMemory");
    bytes = allocation.allocationSize;
    host.submit([&](rhi::ICommandRecorder&, VkCommandBuffer command) {
        VkImageMemoryBarrier barrier{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        barrier.srcQueueFamilyIndex = barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        barrier.image = target.image;
        barrier.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, levels, 0, 1};
        barrier.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        barrier.newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
        barrier.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
        vkCmdPipelineBarrier(command, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT,
                             0, 0, nullptr, 0, nullptr, 1, &barrier);
        vkCmdCopyBufferToImage(command, staging.buffer, target.image, barrier.newLayout,
                               static_cast<uint32_t>(regions.size()), regions.data());
        barrier.oldLayout = barrier.newLayout;
        barrier.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
        barrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
        barrier.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
        vkCmdPipelineBarrier(command, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                             0, 0, nullptr, 0, nullptr, 1, &barrier);
    });
    target.view = host.backend->createImageView(target.image, format, VK_IMAGE_ASPECT_COLOR_BIT, levels);
}
}

int main(int argc, char** argv) try {
    if (argc != 2) throw std::invalid_argument("Supply probe shader");
    test::VulkanComputeFixture host(false, false, false, false, false, false, true);
    auto& backend = *host.backend;
    VkDescriptorSetLayout descriptor{};
    VkDescriptorPool pool{};
    VkPipelineLayout layout{};
    VkShaderModule shader{};
    VkPipeline pipeline{};
    VkSampler sampler{};
    VkQueryPool queries{};
    rhi::GpuBuffer resultBuffer{};
    auto cleanup = std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*) {
        if (queries) vkDestroyQueryPool(host.device, queries, nullptr);
        if (pipeline) backend.destroyPipeline(pipeline);
        if (shader) backend.destroyShaderModule(shader);
        if (layout) backend.destroyPipelineLayout(layout);
        if (pool) backend.destroyDescriptorPool(pool);
        if (descriptor) backend.destroyDescriptorSetLayout(descriptor);
        if (sampler) backend.destroySampler(sampler);
        host.allocator.destroyBuffer(resultBuffer);
    });
    descriptor = backend.createDescriptorSetLayout({
        {0,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_COMPUTE_BIT},
        {1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT}});
    rhi::DescriptorPoolDesc sizes;
    sizes.maxSets = 2;
    sizes.sizes = {{VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,2},{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,2}};
    pool = backend.createDescriptorPool(sizes);
    auto sets = backend.allocateDescriptorSets(pool,descriptor,2);
    rhi::PushConstantRangeDesc push{VK_SHADER_STAGE_COMPUTE_BIT,16};
    layout = backend.createPipelineLayout(descriptor,&push);
    shader = backend.createShaderModule(readBinaryFile(argv[1]));
    pipeline = backend.createComputePipeline({shader,layout});

    rhi::SamplerDesc settings;
    settings.filter = VK_FILTER_LINEAR;
    settings.mipmapLinear = true;
    settings.maxLod = 12;
    sampler = backend.createSampler(settings);
    resultBuffer = host.allocator.createBuffer(samples*16,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
    for (auto set : sets)
        backend.writeDescriptorBuffer({set,1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,resultBuffer.buffer,resultBuffer.size});

    VkQueryPoolCreateInfo query{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};
    query.queryType = VK_QUERY_TYPE_TIMESTAMP;
    query.queryCount = 2;
    test::vkRequire(vkCreateQueryPool(host.device,&query,nullptr,&queries),"vkCreateQueryPool");
    constexpr unsigned dims = 4096;
    constexpr unsigned levels = 13;
    std::vector<VkBufferImageCopy> regions;
    VkDeviceSize count = 0;
    for (unsigned level = 0; level < levels; ++level) {
        const unsigned edge = dims >> level;
        VkBufferImageCopy region{};
        region.bufferOffset = count;
        region.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT,level,0,1};
        region.imageExtent = {edge,edge,1};
        regions.push_back(region);
        count += VkDeviceSize(edge)*edge*4;
    }
    auto staging = host.allocator.createBuffer(count,VK_BUFFER_USAGE_TRANSFER_SRC_BIT,true);
    auto release = std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*) {host.allocator.destroyBuffer(staging);});
    uint32_t random = 1;
    auto* source = static_cast<uint32_t*>(staging.mapped);
    for (VkDeviceSize i = 0; i < count/4; ++i) {
        random = 1664525U*random+1013904223U;
        source[i] = random ^ (random>>17U);
    }
    host.allocator.flush(staging,0,count);

    const auto run = [&](VkDescriptorSet set, unsigned mode, unsigned seed) {
        std::array<uint32_t,4> parameters{dims,mode,seed,levels};
        host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer command) {
            vkCmdResetQueryPool(command,queries,0,2);
            commands.bindComputePipeline(pipeline);
            commands.bindComputeDescriptorSet(layout,set);
            commands.pushConstants(layout,VK_SHADER_STAGE_COMPUTE_BIT,0,parameters.data(),sizeof(parameters));
            vkCmdWriteTimestamp(command,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,queries,0);
            commands.dispatch(samples/64,1,1);
            vkCmdWriteTimestamp(command,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,queries,1);
            commands.bufferBarrier({resultBuffer.buffer,0,resultBuffer.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                   VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
        });
        std::array<uint64_t,2> ticks{};
        test::vkRequire(vkGetQueryPoolResults(host.device,queries,0,2,sizeof(ticks),ticks.data(),sizeof(uint64_t),
                                            VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT),"vkGetQueryPoolResults");
        const uint64_t mask=host.timestampBits>=64 ? ~uint64_t{0} : (uint64_t{1}<<host.timestampBits)-1;
        return (double((ticks[1]-ticks[0])&mask)*host.properties.limits.timestampPeriod)/1.e6;
    };
    std::cout<<"device="<<host.properties.deviceName<<",timestampBits="<<host.timestampBits<<'\n';
    for (auto format : {VK_FORMAT_R8G8B8A8_UNORM,VK_FORMAT_R8G8B8A8_SRGB}) {
        ImageStorage local{host.device}, nonlocal{host.device};
        VkDeviceSize localBytes=0, nonlocalBytes=0;
        uint32_t flat, remote;
        upload(host,local,format,dims,levels,true,staging,regions,localBytes,flat);
        upload(host,nonlocal,format,dims,levels,false,staging,regions,nonlocalBytes,remote);
        std::cout<<"format="<<format<<",localType="<<flat<<",nonLocalType="<<remote
            <<",localBytes="<<localBytes<<",nonLocalBytes="<<nonlocalBytes<<'\n';
        if (flat==UINT32_MAX) throw std::runtime_error("Local image type unavailable");
        if (remote==UINT32_MAX) continue;
        backend.writeDescriptorImage({sets[0],0,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,local.view,sampler});
        backend.writeDescriptorImage({sets[1],0,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,nonlocal.view,sampler});
        std::vector<uint32_t> reference(samples*4);
        for (unsigned mode=0;mode<3;++mode) {
            run(sets[0],mode,7);
            host.allocator.invalidate(resultBuffer,0,resultBuffer.size);
            std::memcpy(reference.data(),resultBuffer.mapped,resultBuffer.size);
            run(sets[1],mode,7);
            host.allocator.invalidate(resultBuffer,0,resultBuffer.size);
            if (std::memcmp(reference.data(),resultBuffer.mapped,resultBuffer.size)!=0)
                throw std::runtime_error("Backing heap changed shader output bits");
            for (unsigned warmup=0;warmup<4;++warmup) {
                run(sets[0],mode,warmup);run(sets[1],mode,warmup);
            }
            for (unsigned round=0;round<16;++round) {
                std::array<double,2> times{};
                for(unsigned position=0;position<2;++position) {
                    const unsigned side=(position+round)%2;
                    times[side]=run(sets[side],mode,100+round);
                }
                std::cout<<"sample,"<<format<<','<<mode<<','<<round<<','<<times[0]<<','<<times[1]<<'\n';
            }
        }
    }
    release.reset();cleanup.reset();
    if (host.allocator.statistics().liveBuffers || host.allocator.statistics().liveImages)
        throw std::runtime_error("GpuAllocator resources remain live");
    host.close();
    if (host.errors.load()) throw std::runtime_error("Vulkan validation warning or error");
    std::cout<<"validation=0,liveAllocations=0\n";
    return 0;
} catch (const std::exception& error) {
    std::cerr<<error.what()<<'\n';
    return 1;
}
