enum class Placement { Local, Host, Split };

VkDeviceSize bindSplit(test::VulkanComputeFixture& host, ImageStorage& target,
                       const VkMemoryRequirements& memoryRequirement,
                       const VkPhysicalDeviceMemoryProperties& memory, uint32_t remoteType,
                       unsigned levels, unsigned width) {
    uint32_t count = 0;
    vkGetImageSparseMemoryRequirements(host.device, target.image, &count, nullptr);
    std::vector<VkSparseImageMemoryRequirements> sparse(count);
    vkGetImageSparseMemoryRequirements(host.device, target.image, &count, sparse.data());
    if (sparse.size() != 1 || sparse[0].formatProperties.aspectMask != VK_IMAGE_ASPECT_COLOR_BIT)
        throw std::runtime_error("Expected one sparse color requirement");
    const auto& supported = sparse[0];
    const auto chunk = supported.formatProperties.imageGranularity;
    constexpr unsigned hostLevels = 2;
    if (supported.imageMipTailFirstLod < hostLevels || supported.imageMipTailSize == 0)
        throw std::runtime_error("Expected independently bindable highest levels");
    const auto localType = memoryType(memory, memoryRequirement.memoryTypeBits, true);
    if (localType == UINT32_MAX) throw std::runtime_error("No local heap");
    const auto pageBytes = memoryRequirement.alignment;
    VkDeviceSize hostBytes = 0;
    VkDeviceSize localBytes = supported.imageMipTailSize;
    std::vector<VkSparseImageMemoryBind> pages;
    for (unsigned mip=0; mip<std::min(levels,supported.imageMipTailFirstLod); ++mip) {
        const auto edge = std::max(1U,width >> mip);
        for (unsigned y=0; y<edge; y+=chunk.height) {
            for (unsigned x=0; x<edge; x+=chunk.width) {
                auto& bytes = mip < hostLevels ? hostBytes : localBytes;
                VkSparseImageMemoryBind bind{};
                bind.subresource = {VK_IMAGE_ASPECT_COLOR_BIT,mip,0};
                bind.offset = {static_cast<int32_t>(x),static_cast<int32_t>(y),0};
                bind.extent = {std::min(chunk.width,edge-x),std::min(chunk.height,edge-y),1};
                bind.memoryOffset = bytes;
                pages.push_back(bind);
                bytes += pageBytes;
            }
        }
    }
    VkMemoryAllocateInfo allocation{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    allocation.allocationSize = hostBytes;
    allocation.memoryTypeIndex = remoteType;
    test::vkRequire(vkAllocateMemory(host.device,&allocation,nullptr,&target.memory),"allocate host pages");
    allocation.allocationSize = localBytes;
    allocation.memoryTypeIndex = localType;
    test::vkRequire(vkAllocateMemory(host.device,&allocation,nullptr,&target.localMemory),"allocate local pages");
    for (auto& page : pages)
        page.memory = page.subresource.mipLevel < hostLevels ? target.memory : target.localMemory;

    VkSparseMemoryBind tail{};
    tail.resourceOffset = supported.imageMipTailOffset;
    tail.size = supported.imageMipTailSize;
    tail.memory = target.localMemory;
    VkSparseImageMemoryBindInfo bindPages{target.image,static_cast<uint32_t>(pages.size()),pages.data()};
    VkSparseImageOpaqueMemoryBindInfo bindTail{target.image,1,&tail};
    VkBindSparseInfo sparseInfo{VK_STRUCTURE_TYPE_BIND_SPARSE_INFO};
    sparseInfo.imageBindCount=1;
    sparseInfo.pImageBinds=&bindPages;
    sparseInfo.imageOpaqueBindCount=1;
    sparseInfo.pImageOpaqueBinds=&bindTail;
    test::vkRequire(vkQueueBindSparse(host.queue,1,&sparseInfo,VK_NULL_HANDLE),"vkQueueBindSparse");
    test::vkRequire(vkQueueWaitIdle(host.queue),"vkQueueWaitIdle(sparse)");
    std::cout<<"mixed,mipTailFirst="<<supported.imageMipTailFirstLod<<",pages="<<pages.size()
             <<",hostBytes="<<hostBytes<<",localBytes="<<localBytes<<'\n';
    return hostBytes + localBytes;
}
