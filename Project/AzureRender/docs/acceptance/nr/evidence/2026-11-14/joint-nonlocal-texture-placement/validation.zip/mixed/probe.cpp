#include "support/VulkanComputeFixture.hpp"
#include "resources/BinaryFile.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <vector>

using namespace azurerender;
namespace {
constexpr unsigned samples = 65536;

struct ImageStorage {
    VkDevice device;
    VkImage image{};
    VkDeviceMemory memory{};
    VkDeviceMemory localMemory{};
    VkImageView view{};
    ~ImageStorage() {
        if (view) vkDestroyImageView(device, view, nullptr);
        if (image) vkDestroyImage(device, image, nullptr);
        if (memory) vkFreeMemory(device, memory, nullptr);
        if (localMemory) vkFreeMemory(device, localMemory, nullptr);
    }
};

uint32_t memoryType(const VkPhysicalDeviceMemoryProperties& memory, uint32_t mask, bool local) {
    for (uint32_t index = 0; index < memory.memoryTypeCount; ++index) {
        if ((mask & (1U << index)) == 0) continue;
        const auto heap = memory.memoryTypes[index].heapIndex;
        const bool deviceLocal = (memory.memoryHeaps[heap].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT) != 0;
        if (deviceLocal == local) return index;
    }
    return UINT32_MAX;
}

enum class Placement { Local, Host, Split };

VkDeviceSize bindSplit(test::VulkanComputeFixture& host, ImageStorage& target,
                       const VkMemoryRequirements& memoryRequirement,
                       const VkPhysicalDeviceMemoryProperties& memory, uint32_t remoteType,
                       unsigned levels, unsigned width) {
    uint32_t count = 0;
    vkGetImageSparseMemoryRequirements(host.device, target.image, &count, nullptr);
    std::vector<VkSparseImageMemoryRequirements> sparse(count);
    vkGetImageSparseMemoryRequirements(host.device, target.image, &count, sparse.data());
    if (sparse.size() != 1 || sparse[0].formatProperties.aspectMask != VK_IMAGE_ASPECT_COLOR_BIT)
        throw std::runtime_error("Expected one sparse color requirement");
    const auto& supported = sparse[0];
    const auto chunk = supported.formatProperties.imageGranularity;
    constexpr unsigned hostLevels = 2;
    if (supported.imageMipTailFirstLod < hostLevels || supported.imageMipTailSize == 0)
        throw std::runtime_error("Expected independently bindable highest levels");
    const auto localType = memoryType(memory, memoryRequirement.memoryTypeBits, true);
    if (localType == UINT32_MAX) throw std::runtime_error("No local heap");
    const auto pageBytes = memoryRequirement.alignment;
    VkDeviceSize hostBytes = 0;
    VkDeviceSize localBytes = supported.imageMipTailSize;
    std::vector<VkSparseImageMemoryBind> pages;
    for (unsigned mip=0; mip<std::min(levels,supported.imageMipTailFirstLod); ++mip) {
        const auto edge = std::max(1U,width >> mip);
        for (unsigned y=0; y<edge; y+=chunk.height) {
            for (unsigned x=0; x<edge; x+=chunk.width) {
                auto& bytes = mip < hostLevels ? hostBytes : localBytes;
                VkSparseImageMemoryBind bind{};
                bind.subresource = {VK_IMAGE_ASPECT_COLOR_BIT,mip,0};
                bind.offset = {static_cast<int32_t>(x),static_cast<int32_t>(y),0};
                bind.extent = {std::min(chunk.width,edge-x),std::min(chunk.height,edge-y),1};
                bind.memoryOffset = bytes;
                pages.push_back(bind);
                bytes += pageBytes;
            }
        }
    }
    VkMemoryAllocateInfo allocation{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    allocation.allocationSize = hostBytes;
    allocation.memoryTypeIndex = remoteType;
    test::vkRequire(vkAllocateMemory(host.device,&allocation,nullptr,&target.memory),"allocate host pages");
    allocation.allocationSize = localBytes;
    allocation.memoryTypeIndex = localType;
    test::vkRequire(vkAllocateMemory(host.device,&allocation,nullptr,&target.localMemory),"allocate local pages");
    for (auto& page : pages)
        page.memory = page.subresource.mipLevel < hostLevels ? target.memory : target.localMemory;

    VkSparseMemoryBind tail{};
    tail.resourceOffset = supported.imageMipTailOffset;
    tail.size = supported.imageMipTailSize;
    tail.memory = target.localMemory;
    VkSparseImageMemoryBindInfo bindPages{target.image,static_cast<uint32_t>(pages.size()),pages.data()};
    VkSparseImageOpaqueMemoryBindInfo bindTail{target.image,1,&tail};
    VkBindSparseInfo sparseInfo{VK_STRUCTURE_TYPE_BIND_SPARSE_INFO};
    sparseInfo.imageBindCount=1;
    sparseInfo.pImageBinds=&bindPages;
    sparseInfo.imageOpaqueBindCount=1;
    sparseInfo.pImageOpaqueBinds=&bindTail;
    test::vkRequire(vkQueueBindSparse(host.queue,1,&sparseInfo,VK_NULL_HANDLE),"vkQueueBindSparse");
    test::vkRequire(vkQueueWaitIdle(host.queue),"vkQueueWaitIdle(sparse)");
    std::cout<<"mixed,mipTailFirst="<<supported.imageMipTailFirstLod<<",pages="<<pages.size()
             <<",hostBytes="<<hostBytes<<",localBytes="<<localBytes<<'\n';
    return hostBytes + localBytes;
}

void upload(test::VulkanComputeFixture& host, ImageStorage& target, VkFormat format,
            unsigned width, unsigned levels, Placement placement, const rhi::GpuBuffer& staging,
            const std::vector<VkBufferImageCopy>& regions, VkDeviceSize& bytes, uint32_t& type) {
    constexpr auto usage = VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    VkImageCreateInfo info{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    if (placement == Placement::Split) {
        info.flags = VK_IMAGE_CREATE_SPARSE_BINDING_BIT | VK_IMAGE_CREATE_SPARSE_RESIDENCY_BIT;
    }
    info.imageType = VK_IMAGE_TYPE_2D;
    info.format = format;
    info.extent = {width, width, 1};
    info.mipLevels = levels;
    info.arrayLayers = 1;
    info.samples = VK_SAMPLE_COUNT_1_BIT;
    info.tiling = VK_IMAGE_TILING_OPTIMAL;
    info.usage = usage;
    info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    test::vkRequire(vkCreateImage(host.device, &info, nullptr, &target.image), "vkCreateImage");
    VkMemoryRequirements requirements{};
    vkGetImageMemoryRequirements(host.device, target.image, &requirements);
    VkPhysicalDeviceMemoryProperties memory{};
    vkGetPhysicalDeviceMemoryProperties(host.physical, &memory);
    type = memoryType(memory, requirements.memoryTypeBits, placement == Placement::Local);
    if (type == UINT32_MAX) return;
    if (placement == Placement::Split) {
        bytes = bindSplit(host, target, requirements, memory, type, levels, width);
    } else {
        VkMemoryAllocateInfo allocation{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        allocation.allocationSize = requirements.size;
        allocation.memoryTypeIndex = type;
        test::vkRequire(vkAllocateMemory(host.device, &allocation, nullptr, &target.memory), "vkAllocateMemory");
        test::vkRequire(vkBindImageMemory(host.device, target.image, target.memory, 0), "vkBindImageMemory");
        bytes = allocation.allocationSize;
    }
    host.submit([&](rhi::ICommandRecorder&, VkCommandBuffer command) {
        VkImageMemoryBarrier barrier{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        barrier.srcQueueFamilyIndex = barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
        barrier.image = target.image;
        barrier.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, levels, 0, 1};
        barrier.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        barrier.newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
        barrier.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
        vkCmdPipelineBarrier(command, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT,
                             0, 0, nullptr, 0, nullptr, 1, &barrier);
        vkCmdCopyBufferToImage(command, staging.buffer, target.image, barrier.newLayout,
                               static_cast<uint32_t>(regions.size()), regions.data());
        barrier.oldLayout = barrier.newLayout;
        barrier.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
        barrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
        barrier.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
        vkCmdPipelineBarrier(command, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                             0, 0, nullptr, 0, nullptr, 1, &barrier);
    });
    target.view = host.backend->createImageView(target.image, format, VK_IMAGE_ASPECT_COLOR_BIT, levels);
}
}

int main(int argc, char** argv) try {
    if (argc != 2) throw std::invalid_argument("Supply probe shader");
    test::VulkanComputeFixture host(false, false, false, false, false, false, true);
    auto& backend = *host.backend;
    VkDescriptorSetLayout descriptor{};
    VkDescriptorPool pool{};
    VkPipelineLayout layout{};
    VkShaderModule shader{};
    VkPipeline pipeline{};
    VkSampler sampler{};
    VkQueryPool queries{};
    rhi::GpuBuffer resultBuffer{};
    auto cleanup = std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*) {
        if (queries) vkDestroyQueryPool(host.device, queries, nullptr);
        if (pipeline) backend.destroyPipeline(pipeline);
        if (shader) backend.destroyShaderModule(shader);
        if (layout) backend.destroyPipelineLayout(layout);
        if (pool) backend.destroyDescriptorPool(pool);
        if (descriptor) backend.destroyDescriptorSetLayout(descriptor);
        if (sampler) backend.destroySampler(sampler);
        host.allocator.destroyBuffer(resultBuffer);
    });
    descriptor = backend.createDescriptorSetLayout({
        {0,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_COMPUTE_BIT},
        {1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT}});
    rhi::DescriptorPoolDesc sizes;
    sizes.maxSets = 3;
    sizes.sizes = {{VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,3},{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,3}};
    pool = backend.createDescriptorPool(sizes);
    auto sets = backend.allocateDescriptorSets(pool,descriptor,3);
    rhi::PushConstantRangeDesc push{VK_SHADER_STAGE_COMPUTE_BIT,16};
    layout = backend.createPipelineLayout(descriptor,&push);
    shader = backend.createShaderModule(readBinaryFile(argv[1]));
    pipeline = backend.createComputePipeline({shader,layout});

    rhi::SamplerDesc settings;
    settings.filter = VK_FILTER_LINEAR;
    settings.mipmapLinear = true;
    settings.maxLod = 12;
    sampler = backend.createSampler(settings);
    resultBuffer = host.allocator.createBuffer(samples*16,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
    for (auto set : sets)
        backend.writeDescriptorBuffer({set,1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,resultBuffer.buffer,resultBuffer.size});

    VkQueryPoolCreateInfo query{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};
    query.queryType = VK_QUERY_TYPE_TIMESTAMP;
    query.queryCount = 2;
    test::vkRequire(vkCreateQueryPool(host.device,&query,nullptr,&queries),"vkCreateQueryPool");
    constexpr unsigned dims = 4096;
    constexpr unsigned levels = 13;
    std::vector<VkBufferImageCopy> regions;
    VkDeviceSize count = 0;
    for (unsigned level = 0; level < levels; ++level) {
        const unsigned edge = dims >> level;
        VkBufferImageCopy region{};
        region.bufferOffset = count;
        region.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT,level,0,1};
        region.imageExtent = {edge,edge,1};
        regions.push_back(region);
        count += VkDeviceSize(edge)*edge*4;
    }
    auto staging = host.allocator.createBuffer(count,VK_BUFFER_USAGE_TRANSFER_SRC_BIT,true);
    auto release = std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*) {host.allocator.destroyBuffer(staging);});
    uint32_t random = 1;
    auto* source = static_cast<uint32_t*>(staging.mapped);
    for (VkDeviceSize i = 0; i < count/4; ++i) {
        random = 1664525U*random+1013904223U;
        source[i] = random ^ (random>>17U);
    }
    host.allocator.flush(staging,0,count);

    const auto run = [&](VkDescriptorSet set, unsigned mode, unsigned seed) {
        std::array<uint32_t,4> parameters{dims,mode,seed,levels};
        host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer command) {
            vkCmdResetQueryPool(command,queries,0,2);
            commands.bindComputePipeline(pipeline);
            commands.bindComputeDescriptorSet(layout,set);
            commands.pushConstants(layout,VK_SHADER_STAGE_COMPUTE_BIT,0,parameters.data(),sizeof(parameters));
            vkCmdWriteTimestamp(command,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,queries,0);
            commands.dispatch(samples/64,1,1);
            vkCmdWriteTimestamp(command,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,queries,1);
            commands.bufferBarrier({resultBuffer.buffer,0,resultBuffer.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                   VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
        });
        std::array<uint64_t,2> ticks{};
        test::vkRequire(vkGetQueryPoolResults(host.device,queries,0,2,sizeof(ticks),ticks.data(),sizeof(uint64_t),
                                            VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT),"vkGetQueryPoolResults");
        const uint64_t mask=host.timestampBits>=64 ? ~uint64_t{0} : (uint64_t{1}<<host.timestampBits)-1;
        return (double((ticks[1]-ticks[0])&mask)*host.properties.limits.timestampPeriod)/1.e6;
    };
    std::cout<<"device="<<host.properties.deviceName<<",timestampBits="<<host.timestampBits<<'\n';
    for (auto format : {VK_FORMAT_R8G8B8A8_UNORM,VK_FORMAT_R8G8B8A8_SRGB}) {
        ImageStorage local{host.device}, nonlocal{host.device}, split{host.device};
        VkDeviceSize localBytes=0, nonlocalBytes=0;
        uint32_t flat, remote;
        upload(host,local,format,dims,levels,Placement::Local,staging,regions,localBytes,flat);
        upload(host,nonlocal,format,dims,levels,Placement::Host,staging,regions,nonlocalBytes,remote);
        std::cout<<"format="<<format<<",localType="<<flat<<",nonLocalType="<<remote
            <<",localBytes="<<localBytes<<",nonLocalBytes="<<nonlocalBytes<<'\n';
        if (flat==UINT32_MAX) throw std::runtime_error("Local image type unavailable");
        if (remote==UINT32_MAX) continue;
        VkDeviceSize splitBytes=0;
        uint32_t splitType=0;
        upload(host,split,format,dims,levels,Placement::Split,staging,regions,splitBytes,splitType);
        if (!split.view || splitType != remote || splitBytes == 0)
            throw std::runtime_error("Mixed texture did not use both backing heaps");
        backend.writeDescriptorImage({sets[0],0,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,local.view,sampler});
        backend.writeDescriptorImage({sets[1],0,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,nonlocal.view,sampler});
        backend.writeDescriptorImage({sets[2],0,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,split.view,sampler});
        std::vector<uint32_t> reference(samples*4);
        for (unsigned mode=0;mode<5;++mode) {
            run(sets[0],mode,7);
            host.allocator.invalidate(resultBuffer,0,resultBuffer.size);
            std::memcpy(reference.data(),resultBuffer.mapped,resultBuffer.size);
            for (unsigned side=1; side<3; ++side) {
                run(sets[side],mode,7);
                host.allocator.invalidate(resultBuffer,0,resultBuffer.size);
                if (std::memcmp(reference.data(),resultBuffer.mapped,resultBuffer.size)!=0)
                    throw std::runtime_error("Mixed backing changed shader output bits");
            }
            for (unsigned round=0;round<18;++round) {
                for(unsigned position=0;position<3;++position) {
                    const unsigned side=(position+round)%3;
                    const auto time=run(sets[side],mode,100+round);
                    std::cout<<"sample,"<<format<<','<<mode<<','<<round<<','<<position<<','<<side<<','<<time<<'\n';
                }
            }
        }

    }
    release.reset();cleanup.reset();
    if (host.allocator.statistics().liveBuffers || host.allocator.statistics().liveImages)
        throw std::runtime_error("GpuAllocator resources remain live");
    host.close();
    if (host.errors.load()) throw std::runtime_error("Vulkan validation warning or error");
    std::cout<<"validation=0,liveAllocations=0\n";
    return 0;
} catch (const std::exception& error) {
    std::cerr<<error.what()<<'\n';
    return 1;
}
