from pathlib import Path
import subprocess
import sys

run = Path(__file__).resolve().parent
for mode, args in (("intel",["--driver","intel"]), ("nvidia-off",["--enable","0"])):
    with (run / (mode + ".log")).open("wb") as log:
        subprocess.run([sys.executable, str(run / "test_fallback.py"), "green.exe", *args],
                       stdout=log, stderr=subprocess.STDOUT, check=True, timeout=100)
