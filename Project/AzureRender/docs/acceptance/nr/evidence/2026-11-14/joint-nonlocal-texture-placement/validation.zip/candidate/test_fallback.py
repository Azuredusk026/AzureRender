import argparse
import os
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description="Check material placement only on eligible adapters")
parser.add_argument("product")
parser.add_argument("--driver", choices=("nvidia", "intel"), default="nvidia")
parser.add_argument("--enable", choices=("0", "1"), default="1")
options = parser.parse_args()
root = Path.cwd()
out = Path(__file__).resolve().parent
mask = {"nvidia":"*nv-vk64*", "intel":"*igvk64*"}[options.driver]
environment = dict(os.environ, AZURE_DIAGNOSTIC_NONLOCAL_TEXTURES=options.enable,
                   VK_LOADER_DRIVERS_SELECT=mask, VK_LAYER_PATH="D:/Tools/VulkanSDK/1.4.350.0/Bin")
environment["PATH"] = os.pathsep.join(map(str,(root/"build/ninja-msvc-release",
    root/"build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin", environment["PATH"])))
for key in ("VK_DRIVER_FILES", "VK_ICD_FILENAMES", "VK_INSTANCE_LAYERS", "VK_LAYER_ENABLES"):
    environment.pop(key, None)
result = subprocess.run([str(out / options.product)], env=environment, capture_output=True, text=True, timeout=70)
print(result.stdout + result.stderr,end="")
assert result.returncode == 0, result.returncode
expected = "true" if options.enable == "1" and options.driver == "nvidia" else "false"
assert f"nonlocal={expected},smallLocal=true,attachmentLocal=true" in result.stdout
assert ("Nonlocal material image" in result.stderr) == (expected == "true")
