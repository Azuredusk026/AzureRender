from hashlib import file_digest
from pathlib import Path
import json
import os
import subprocess

output = Path(__file__).resolve().parent
grid = output.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
lock = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state'] == 'held' and Path(lock['output']) == output
request = json.loads((grid / 'native-face-masks/request.json').read_bytes())
with Path(request['native']).open('rb') as stream:
    assert file_digest(stream, 'sha256').hexdigest() == request['captureSha256']
request['points'] = [(1257,275),(1295,283),(1277,288),(1258,293),(1273,297),(1296,301),(1280,310)]
(output/'request.json').write_text(json.dumps(request, indent=2)+'\n')
environment = os.environ.copy()
environment['AZURE_NR_FACE_CHROMA'] = str(output)
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
with (output/'replay.log').open('wb') as log:
    replay = subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(output/'worker.py')],
                            cwd=output,env=environment,stdout=log,stderr=subprocess.STDOUT,
                            startupinfo=startup,timeout=460)
report = json.loads((output/'native-results.json').read_bytes())
assert replay.returncode == 0 and report['status'] == 'qualified', report
