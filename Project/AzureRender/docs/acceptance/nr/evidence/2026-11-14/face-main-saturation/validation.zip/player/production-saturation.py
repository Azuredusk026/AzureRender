from hashlib import file_digest
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5
import json
import runpy

import cv2
import numpy as np
from PIL import Image

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
fixture = grid/'iris-overlay-geometry-project'
previous = out.parent/'20261114-015010-face-highlight-material-control-dc565e/production'
helpers = runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read, dump, invoke = (helpers[k] for k in ('read','dump','invoke'))
release = helpers['build']
lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==out
baseline_project = fixture/'face-highlight-source-test-production.azureproject'
project = read(baseline_project)
scene = read(fixture/'scene/face-highlight-source-test-production.azurelevel')
slot = 'name:M_actor_laevat_face_01'
hero = next(n for n in scene['nodes'] if n['id']=='hero')
base_name = 'face-highlight-source-test-production'
spec = read(fixture/'materials'/f'{base_name}.azurematerial')
profile = spec['surface']['materials'][0]['extras']['azureRenderMaterial']
assert profile['faceSdf']['highlight']['texture']==5
profile['nprDiffuse']['mainBrightnessSaturation']=True
name = 'face-native-main-saturation-production'
identity = str(uuid5(NAMESPACE_URL,'azurerender/804/'+name))
path = fixture/'materials'/f'{name}.azurematerial'
dump(path,spec)
dump(path.with_suffix('.azurematerial.azmeta'),dict(schemaVersion=1,id=identity,dependencies=[],settings={}))
hero['materialSlots'][slot]=identity
dump(fixture/'scene'/f'{name}.azurelevel',scene)
project['startupScene']=f'stage:/{name}.azurelevel'
candidate_project = fixture/f'{name}.azureproject'
dump(candidate_project,project)


def digest(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


scorer = runpy.run_path(str(grid/'static-quality.py'))
image = lambda path:scorer['image'](path).astype(np.int16)
reference = image(scorer['reference_path'])
mask = cv2.erode(np.asarray(Image.open(grid/'native-face-masks/face.png').convert('L')),np.ones((13,13),np.uint8))>0
assert mask.sum()==1176
results = dict(playerSha256=digest(release/'AzurePlayer.exe'),devices={})
for device in ('nvidia','intel'):
    row = results['devices'][device]={}
    for label,path in (('disabled',baseline_project),('enabled',candidate_project)):
        target = out/f'production-{device}-{label}'
        target.mkdir()
        command = read(previous/f'{device}-highlight/command.json')
        command[command.index('--project')+1]=str(path)
        command[command.index('--capture-dir')+1]=str(target/'frames')
        frame = invoke(device,command,target)/'frame_000000.png'
        pixels = image(frame)
        error = np.abs(pixels-reference).max(2)
        row[label] = dict(frame=digest(frame),overOne=int((error[mask]>1).sum()),
                          peak=int(error[mask].max()),overEight=int((error[mask]>8).sum()))
        expected = previous/f'{device}-highlight/frames/frame_000000.png' if label=='disabled' else out/f'{device}-saturation/frames/frame_000000.png'
        difference = np.abs(pixels-image(expected)).max(2)
        row[label].update(expected=digest(expected),exact=not difference.any(),
                          pixelsDifferent=int((difference>0).sum()),maximumDifference=int(difference.max()))
        (out/'production-saturation-results.json').write_text(json.dumps(results,indent=2)+'\n')
        assert row[label]['exact'], (device,label,row[label])
