from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import json
import subprocess

out = Path(__file__).resolve().parent
release = out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
debug = out.parent/'20261110-031856-hair-main-chroma-debug-668bf2/debug'
roots = {'Release':release,'Debug':debug}
catalog = {mode:{p.name:sha256(p.read_bytes()).hexdigest() for p in (root/'shaders').glob('*.spv')}
           for mode,root in roots.items()}
assert len(catalog['Release'])==895 and catalog['Release']==catalog['Debug']
rules = json.loads((release/'shader-reload.json').read_bytes())['programs']
affected = sorted(row['output'] for row in rules if 'AZURE_EXTENDED_MATERIAL_LIGHTING=1' in row['defines'])
assert len(affected)==384 and set(affected)<=set(catalog['Release'])
validator = 'D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe'


def validate(name):
    result = subprocess.run([validator,'--target-env','vulkan1.3','--relax-block-layout',str(release/'shaders'/name)],
                            capture_output=True,text=True)
    return dict(program=name,exitCode=result.returncode,diagnostic=result.stdout+result.stderr)


with ThreadPoolExecutor(max_workers=5) as workers:
    results = list(workers.map(validate,affected))
assert all(row['exitCode']==0 for row in results)
receipt = dict(programs=len(catalog['Release']),affected=len(results),validated=results,
               player={mode:sha256((root/'AzurePlayer.exe').read_bytes()).hexdigest() for mode,root in roots.items()})
(out/'saturation-build-fingerprints.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(f"{receipt['programs']} identical shaders, {receipt['affected']} validated")
