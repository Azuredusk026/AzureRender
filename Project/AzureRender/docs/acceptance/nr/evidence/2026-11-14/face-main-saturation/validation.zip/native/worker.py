from hashlib import sha256
from pathlib import Path
import json
import os
import traceback

import renderdoc as rd

output = Path(os.environ['AZURE_NR_FACE_CHROMA'])
request = json.loads((output/'request.json').read_bytes())
capture = rd.OpenCaptureFile()
controller = None
report = dict(status='failed', samples=[])
try:
    assert capture.OpenFile(request['native'],'',None)==rd.ResultCode.Succeeded
    options = rd.ReplayOptions()
    options.forceGPUVendor = rd.GPUVendor.nVidia
    options.forceGPUDeviceID = 0x28e0
    status, controller = capture.OpenCapture(options,None)
    assert status==rd.ResultCode.Succeeded and controller
    assert controller.GetAPIProperties().vendor==rd.GPUVendor.nVidia
    controller.SetFrameEvent(804,True)
    pipeline = controller.GetPipelineState()
    target = pipeline.GetOutputTargets()[0].resource
    for x,y in request['points']:
        inputs = rd.DebugPixelInputs()
        history = controller.PixelHistory(target,x,1439-y,rd.Subresource(),rd.CompType.Typeless)
        result, = (row for row in history if row.eventId==804 and row.Passed())
        inputs.primitive = result.primitiveID
        trace = controller.DebugPixel(x,1439-y,inputs)
        assert trace and trace.debugger,(x,y,inputs.primitive)
        registers, states = {}, {}
        steps = 0
        try:
            while True:
                batch = controller.ContinueDebug(trace.debugger)
                if not batch:
                    break
                for entry in batch:
                    for change in entry.changes:
                        row = change.after
                        if row.name:
                            registers[row.name] = list(row.value.f32v)[:4]
                    step = int(entry.nextInstruction)
                    states[step] = {key:value for key,value in registers.items() if key.startswith(('v','r','o'))}
                    steps += 1
                assert steps<20000
        finally:
            controller.FreeTrace(trace)
        name = f'804-{x}-{y}.json'
        payload = (json.dumps(states,separators=(',',':'))+'\n').encode()
        (output/name).write_bytes(payload)
        report['samples'].append(dict(x=x,y=y,primitive=inputs.primitive,steps=steps,path=name,
                                      hardware=list(result.shaderOut.col.floatValue)[:4],
                                      sha256=sha256(payload).hexdigest()))
    report['status']='qualified'
except Exception:
    report['error']=traceback.format_exc()
finally:
    if controller:
        controller.Shutdown()
    capture.Shutdown()
    (output/'native-results.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)
