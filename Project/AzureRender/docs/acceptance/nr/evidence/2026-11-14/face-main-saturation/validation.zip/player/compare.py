from hashlib import sha256
from pathlib import Path
import json
import runpy
import subprocess

import numpy as np

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
production = out.parent/'20261114-015010-face-highlight-material-control-dc565e/production'
native = out.parent/'20261114-033728-face-chroma-points-f9062b'
helpers = runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read, dump, invoke = (helpers[k] for k in ('read','dump','invoke'))
build = helpers['build']
lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==out
source = grid.parents[2]/'shaders/mesh.frag'
sdk = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
resource = out/'resources'
shaders = resource/'shaders'
shaders.mkdir(parents=True)
selected = ('mesh_object_early_lighting.frag.spv','mesh_object_lighting.frag.spv')
rules = [rule for rule in read(build/'shader-reload.json')['programs'] if rule['output'] in selected]
assert len(rules)==len(selected)
for path in (build/'shaders').glob('*.spv'):
    if path.name not in selected:
        (shaders/path.name).hardlink_to(path)
(resource/'runtime-build-Release.json').hardlink_to(build/'runtime-build-Release.json')


def compile_probe(mode, expression):
    code = source.read_text()
    marker = ('        sceneMainDiffuse=response.color*illumination.direct;' if mode in ('response','illumination')
              else '    vec3 qaColor = beautyColor;')
    assert code.count(marker)==1
    path = out/f'{mode}.frag'
    path.write_text(code.replace(marker, marker+'\n    if(AZURE_MATERIAL_CLASS==2U) {outputColor=vec4('
                    +expression+',1.0);outputDisplayMask=vec4(0,0,0,1);return;}'))
    hashes = {}
    for rule in rules:
        dst = shaders/rule['output']
        subprocess.run([str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+d for d in rule['defines']),
                        '-I'+str(source.parent),str(path),'-o',str(dst)],check=True)
        subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(dst)],check=True)
        hashes[dst.name] = sha256(dst.read_bytes()).hexdigest()
    return hashes


def decode(rgb):
    v = rgb.astype(float)/255
    return np.where(v<=.04045,v/12.92,((v+.055)/1.055)**2.4)


def channels(trace, step, register, indices=(0,1,2)):
    values = trace[str(step)][register]
    return [values[i] for i in indices]


scorer = runpy.run_path(str(grid/'static-quality.py'))
samples = read(native/'native-results.json')['samples']
x = [s['x'] for s in samples]
y = [s['y'] for s in samples]
summary = []
for s in samples:
    native_steps = read(native/s['path'])
    main = channels(native_steps,681,'r17')
    response = channels(native_steps,707,'r19')
    pre_local = channels(native_steps,887,'r7')
    with_specular = channels(native_steps,773,'r7')
    item = dict(x=s['x'],y=s['y'],primitive=s['primitive'],nativeHardware=s['hardware'],
                nativeIllumination=main,nativeResponse=response,nativeSpecularAndDiffuse=with_specular,
                nativeBeforeLocal=pre_local,
                nativeMainDiffuse=(np.array(main)*response).tolist(),
                nativeSecondaryLighting=(np.array(s['hardware'][:3])-pre_local).tolist(),
                sourceDisplay=scorer['image'](scorer['reference_path'])[s['y'],s['x']].tolist())
    summary.append(item)

report = dict(samples=summary, modes={})
for mode, expression, scale in (
        ('illumination','(illumination.ambient+illumination.direct)*.25',4),
        ('response','response.color',1),
        ('diffuse','directDiffuse+ambientDiffuse',4),
        ('other','directSpecular+ambientSpecular+rimLighting+emissive',4),
        ('albedo','baseColor.rgb',1)):
    folder = out/f'nvidia-{mode}'
    folder.mkdir()
    hashes = compile_probe(mode,expression)
    command = read(production/'nvidia-highlight/command.json')
    for option, value in (('--capture-dir',folder/'frames'),('--resource-root',resource)):
        command[command.index(option)+1] = str(value)
    frame = invoke('nvidia',command,folder)/'frame_000000.png'
    img = scorer['image'](frame)
    report['modes'][mode] = dict(shaders=hashes,frame=sha256(frame.read_bytes()).hexdigest(),
                                 values=(decode(img[y,x])*scale).tolist())
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
