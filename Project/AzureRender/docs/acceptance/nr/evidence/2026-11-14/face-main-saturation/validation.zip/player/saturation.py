from hashlib import sha256
from pathlib import Path
import json
import runpy
import subprocess

import cv2
import numpy as np
from PIL import Image

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
production = out.parent/'20261114-015010-face-highlight-material-control-dc565e/production'
helpers = runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read, dump, invoke = (helpers[k] for k in ('read','dump','invoke'))
build = helpers['build']
lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==out
source = grid.parents[2]/'shaders/mesh.frag'
sdk = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
resource = out/'resources'
shaders = resource/'shaders'
selected = ('mesh_object_early_lighting.frag.spv','mesh_object_lighting.frag.spv')
rules = [rule for rule in read(build/'shader-reload.json')['programs'] if rule['output'] in selected]
assert len(rules)==len(selected)
code = source.read_text()
marker = '        if(dualFaceSdf) {\n            vec3 highlightProfile='
assert code.count(marker)==1
code = code.replace(marker,'        vec3 saturationHighlight=vec3(0);\n'+marker)
marker = '                directSpecular+=highlight;'
assert code.count(marker)==1
code = code.replace(marker,'                saturationHighlight=highlight;\n'+marker)
marker = '        }\n#endif\n        sceneMainDiffuse=response.color*illumination.direct;'
assert code.count(marker)==1
addition = '''
        }
        if(dualFaceSdf&&materialSurfaceProfiles.profiles[material.materialPadding>>1U].rows[12].z>.5) {
            vec3 sourceColor=response.color*(illumination.ambient+illumination.direct)+saturationHighlight;
            beautyColor+=characterDiffuseSaturation(sourceColor,characterMainBrightnessSaturation(sourceColor))-sourceColor;
        }
#endif
        sceneMainDiffuse=response.color*illumination.direct;'''
probe = out/'face-main-saturation.frag'
probe.write_text(code.replace(marker,addition))
hashes = {}
for rule in rules:
    dst = shaders/rule['output']
    subprocess.run([str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+d for d in rule['defines']),
                    '-I'+str(source.parent),str(probe),'-o',str(dst)],check=True)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(dst)],check=True)
    hashes[dst.name]=sha256(dst.read_bytes()).hexdigest()
scorer = runpy.run_path(str(grid/'static-quality.py'))
image = lambda path: scorer['image'](path).astype(np.int16)
ref = image(scorer['reference_path'])
mask = cv2.erode(np.asarray(Image.open(grid/'native-face-masks/face.png').convert('L')),np.ones((13,13),np.uint8))>0
assert int(mask.sum())==1176
report = dict(shaders=hashes,devices={})
for device in ('nvidia','intel'):
    folder = out/f'{device}-saturation'
    folder.mkdir()
    original = production/f'{device}-highlight'
    command = read(original/'command.json')
    for option,value in (('--capture-dir',folder/'frames'),('--resource-root',resource)):
        command[command.index(option)+1] = str(value)
    frame = invoke(device,command,folder)/'frame_000000.png'
    old = image(original/'frames/frame_000000.png')-ref
    new = image(frame)-ref
    old_max = np.abs(old).max(2)
    new_max = np.abs(new).max(2)
    report['devices'][device] = dict(
        frame=sha256(frame.read_bytes()).hexdigest(),
        faceOverOne=[int((a[mask]>1).sum()) for a in (old_max,new_max)],
        faceOverEight=[int((a[mask]>8).sum()) for a in (old_max,new_max)],
        facePeak=[int(a[mask].max()) for a in (old_max,new_max)],
        faceMedian=[np.median(a[mask],axis=0).tolist() for a in (old,new)],
        faceMeanAbsolute=[np.abs(a[mask]).mean(0).tolist() for a in (old,new)],
        newOutsideFaceOverOne=int(((old_max<=1)&(new_max>1)&~mask).sum()),
        frameOverOne=[int((a>1).sum()) for a in (old_max,new_max)])
    (out/'saturation-results.json').write_text(json.dumps(report,indent=2)+'\n')
