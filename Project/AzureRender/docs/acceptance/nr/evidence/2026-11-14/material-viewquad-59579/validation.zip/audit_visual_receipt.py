import json
from pathlib import Path
import sys

root = Path.cwd()
sys.path.insert(0, str(root / "tools"))
from build_provenance import digest
run = Path(__file__).resolve().parent
record = root / "docs/acceptance/nr/evidence/2026-11-13/frozen-public-visual/driver-59579-results.json"
proof = json.loads(record.read_bytes())["main"]
result = {}
for config, expected in proof.items():
    build = root / "build" / f"ninja-msvc-{config}"
    manifest = json.loads((build / "build-provenance.json").read_bytes())
    actual = {str(build / name):digest(build / name) for name in ("AzurePlayer.exe", "AzureRender.exe")}
    result[config] = {"registeredVisualBuildRecorded":True, "playerMatchesVisualReceipt": actual[str(build / "AzurePlayer.exe")] == expected["playerSha256"],
                      "rendererMatchesVisualReceipt":actual[str(build / "AzureRender.exe")] == expected["rendererSha256"],
                      "staleGenericBuildReceiptCommit":manifest["commit"]}
    assert result[config]["playerMatchesVisualReceipt"] and result[config]["rendererMatchesVisualReceipt"]
    assert manifest["products"].get(str(build / "AzurePlayer.exe").replace("/", "\\")) != actual[str(build / "AzurePlayer.exe")]
(run / "visual-product-receipt-audit.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result))
