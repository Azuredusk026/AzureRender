from hashlib import sha256
import json
from pathlib import Path
import re
import sys
from zipfile import ZipFile

root = Path.cwd()
sys.path.insert(0, str(root / "tools"))
from build_provenance import verify
run = Path(__file__).resolve().parent
candidate = Path("D:/Projects/FYP-worktrees/nr-integration-verified/Project/AzureRender")
receipt = candidate / "build/runs/20261113-022822-nr-material-viewquad-main-integration-e65379/candidate-products.json"
proof = json.loads(receipt.read_bytes())
verify(candidate, proof)
source = root / "docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope"
with ZipFile(source / "validation.zip") as archive:
    locked = json.loads(archive.read("run/frozen-project-inputs.json"))
expected = json.loads((source / "results.json").read_bytes())["originalFour"]["frames"]
frozen = root / "build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames"

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

assert len(locked) == 1729
assert all(digest(Path(name)) == value for name, value in locked.items())
loc = read(run / "pixel-localization.json")
caps = read(frozen / "gpu_capabilities.json")
frozen_driver = f"{caps['driver_version'] >> 22}.{(caps['driver_version'] >> 14) & 255}"
assert frozen_driver == "592.82"
report = {"frozenDriver":frozen_driver, "frozenGpu":caps["device_name"], "rows":{}}
for name, label in (("baseline-original-four","referenceMaterialToFrozen"), ("original-four","computedMaterialToFrozen")):
    group = run / name
    log = (group / "player.log").read_text(errors="replace")
    data = read(group / "timing.json")
    command = read(group / "command.json")
    environment = read(group / "environment.json")
    assert "Allocator after unload: buffers=0 images=0" in log and "Captured frames: 4 at 24 fps" in log
    assert command["source"] == proof["commit"] and command["productReceiptSha256"] == digest(receipt)
    observations = environment.get("runObservations", [])
    assert all(row["driver"] == "595.79" for row in environment["startup"] + observations)
    device = read(group / "frames/gpu_capabilities.json")
    assert device["device_id"] == caps["device_id"] and device["driver_version"] == 2496905216
    computed = name == "original-four"
    assert (data["computedMaterialViewSelectionsTotal"] > 0) == computed
    images = list((group / "frames").glob("frame_*.png"))
    assert len(images) == len(expected) == len(loc[label]) == 4
    frames = []
    for reference, differences in zip(expected, loc[label]):
        image = reference["name"]
        assert image == differences["frame"] and digest(frozen / image) == reference["referenceSha256"]
        actual = digest(group / "frames" / image)
        frames.append({"name":image, "sha256":actual,"expected":reference["referenceSha256"],
                       "exact":actual==reference["referenceSha256"], "changedPixels":differences["count"],
                       "maximumByteError":max(map(int,differences["absoluteDifferenceHistogram"]),default=0)})
    cache = re.search(r"Pipeline cache loaded: bytes=(\d+), state=([^,]+)", log)
    result = {"driver":"595.79","source":proof["commit"],"scope":"pixel-diagnostic","allocatorZero":True,
              "computedMaterialView":computed,"pipelineCacheBytes":int(cache.group(1)),
              "pipelineCacheState":cache.group(2),"recordedRunSeconds":environment.get("runSeconds"),
              "backgroundUtilizationAtStart":environment["startup"][0]["gpuUtilization"],
              "watts":sorted({ob["powerLimitWatts"] for ob in environment["startup"] + observations}), "periodicTelemetryArchived":bool(observations),
              "computeSelections":data["computedMaterialViewSelectionsTotal"],"frames":frames}
    if not computed:
        result["sameDriverCandidateComparison"] = [{"name":row["frame"],"changedPixels":row["count"],
            "maximumByteError":max(map(int,row["absoluteDifferenceHistogram"]),default=0)} for row in loc["computedToReferenceMaterial"]]
    (group / "results.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    report["rows"][name] = result
assert all(row["count"] == 0 for row in loc["computedToReferenceMaterial"])
assert all(a["sha256"] == b["sha256"] for a,b in zip(report["rows"]["baseline-original-four"]["frames"],report["rows"]["original-four"]["frames"]))
(run / "pair-recovery.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(f"{frozen_driver} original, 595.79 independently verified both paths, four PNG pairs match")
