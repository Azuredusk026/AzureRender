from collections import Counter, defaultdict
import json
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile

root = Path.cwd()
path = root / "docs/acceptance/nr/evidence/2026-11-11/resident-srgb-channel-scope/validation.zip"
with ZipFile(path) as archive:
    inventory = json.loads(archive.read("texture-inventory.json"))
    srgb = json.loads(archive.read("results.json"))["rows"]
capacity = json.loads((root / "docs/acceptance/nr/evidence/2026-11-14/joint-59579-qualification/results.json").read_bytes())
bytes_by_format = {"R8G8B8A8_SRGB": 4, "R8G8B8A8_UNORM": 4, "R8G8_UNORM": 2, "R8_UNORM": 1}
images = [item for item in inventory if item["format"] in bytes_by_format
          and item["name"].startswith("2D Image ") and item["mips"] > 1 and item["arraysize"] == 1
          and item["msSamples"] == 1]
assert len({item["resource"] for item in images}) == len(images)
base_by_dimensions = Counter()
for item in images:
    dimension = max(item["width"], item["height"])
    base_by_dimensions[dimension] += item["width"] * item["height"] * bytes_by_format[item["format"]]
levels = defaultdict(list)
for item in srgb:
    for level in item["levels"]:
        levels[(level["width"], level["height"], level["sha256"])].append(level["bytes"])
assert len(srgb) == 180
assert all(len(set(sizes)) == 1 for sizes in levels.values())
base_bytes = sum(base_by_dimensions.values())
excess = capacity["capacityEnvelope"]["peakOverLimitBytes"]
report = {
    "sourceArchiveSha256": sha256(path.read_bytes()).hexdigest(),
    "scope": "historical-capture-single-layer-mipmapped-RGBA8-sRGB-RGBA8-UNORM-RG8-UNORM-R8-UNORM",
    "eligibleInventoryImages": len(images),
    "topMipTexelBytes": base_bytes,
    "topMipTexelBytesByMaximumDimension": dict(sorted(base_by_dimensions.items())),
    "fractionOfTopMipBytesNeededIfAlone": excess / base_bytes,
    "sRgbExactDuplicateMipPayloadBytes": sum(sizes[0] * (len(sizes) - 1) for sizes in levels.values()),
    "sRgbImagesScannedForDuplicates": len(srgb),
    "duplicateScope": "Same width, height and complete captured RGBA sRGB bytes; ignores memory granularity, layout and ownership.",
    "demonstratesUnusedMips": False,
    "testedProductionChanges": False,
}
assert report["sRgbExactDuplicateMipPayloadBytes"] >= 0
output = Path(__file__).resolve().parent / "capacity-scan.json"
output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
