from PIL import Image
from pathlib import Path
from collections import Counter
import json
import numpy as np

run = Path(__file__).resolve().parent
root = Path.cwd()
reference = root / "build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames"
result = {}
for pair, locations in [
    ("referenceMaterialToFrozen", (run / "baseline-original-four/frames", reference)),
    ("computedMaterialToFrozen", (run / "original-four/frames", reference)),
    ("computedToReferenceMaterial", (run / "original-four/frames", run / "baseline-original-four/frames")),
]:
    entries = []
    for index in range(4):
        name = f"frame_{index:06}.png"
        operands = [path / name for path in locations]
        if not all(path.is_file() for path in operands):
            continue
        images = []
        for path in operands:
            with Image.open(path) as image:
                images.append(np.asarray(image.convert("RGB"), dtype=np.int16))
        difference = np.abs(images[0] - images[1])
        magnitude = difference.max(axis=2)
        y, x = np.where(magnitude)
        rows = [(int(a),int(b),[int(v) for v in difference[b,a]]) for a,b in zip(x,y)]
        entries.append({"frame":name,"count":len(rows),
          "box":[int(x.min()),int(y.min()),int(x.max()),int(y.max())] if len(rows) else None,
          "absoluteDifferenceHistogram":dict(sorted(Counter(map(int,magnitude[y,x])).items())),
          "strongestDifference":[list(row) for row in sorted(rows,key=lambda row:max(row[2]),reverse=True)[:12]]})
    if entries:
        result[pair] = entries
(run / "pixel-localization.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
for pair, entries in result.items():
    print(pair, [(e["count"],e["box"],e["absoluteDifferenceHistogram"]) for e in entries])
