from pathlib import Path
import csv
import json
import sys
import numpy as np

folder = Path(__file__).resolve().parent
data = json.loads((folder / "results.json").read_bytes())
trace = json.loads((folder / "timing.json").read_bytes())
environment = json.loads((folder / "environment.json").read_bytes())
with (folder / "timing.csv").open() as stream:
    rows = list(csv.DictReader(stream))
assert len(rows) == data["frames"] + data["warmup"] == 2100
assert [row["frame"] for row in rows] == [str(i) for i in range(1,2101)]
first_slowdown = next(row for row in environment["runObservations"] if row["thermalSlowdown"]["software"])
report = {
    "firstSoftwareThermalSlowdownSecondsFromPlayerStart": first_slowdown["seconds"],
    "startGpuTemperatureC": environment["startup"][0]["temperature"],
    "startupGpuUtilization": [row["gpuUtilization"] for row in environment["startup"]],
    "materialResidentTexelBytes": trace["materialTextureCache"]["residentBytes"],
    "liveImageBytes": trace["allocator"]["liveImageBytes"],
    "liveBufferBytes": trace["allocator"]["liveBufferBytes"],
    "gpuFrameP95MsByWindow": [row["frameMs"]["p95"] for row in data["windows"]],
    "cpuWorkP95MsByWindow": [row["cpuWorkMs"]["p95"] for row in data["windows"]],
    "gpuP95GapMs": data["timings"]["frameMs"]["p95"] - 16.6,
    "activePipelines": trace["computedMaterialViewPipelines"],
    "computedSelections": trace["computedMaterialViewSelectionsTotal"],
    "renderedFrames": trace["submission"]["frames"],
}
assert report["materialResidentTexelBytes"] == 1852081920
assert report["activePipelines"] > 0 and report["computedSelections"] > 0
assert all(p95 > 16.6 for p95 in report["gpuFrameP95MsByWindow"])
(folder / "analysis.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps(report))
