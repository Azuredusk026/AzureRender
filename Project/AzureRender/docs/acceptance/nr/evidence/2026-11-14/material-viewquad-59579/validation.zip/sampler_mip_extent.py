import json
import math
from pathlib import Path
from collections import Counter
from zipfile import ZipFile
from hashlib import sha256

root = Path.cwd()
run = Path(__file__).resolve().parent
path = root / "docs/acceptance/nr/evidence/2026-11-10/material-storage-scope/validation.zip"
with ZipFile(path) as source:
    data = json.loads(source.read("results.json"))["materialImageStorage"]
rows = data["rows"]
assert len(rows) == data["uniqueTextures"]
histogram = Counter()
suffix_bytes = 0
identity = set()
for row in rows:
    histogram[str((row["mipLevels"] - 1) - math.ceil(row["maximumLod"]))] += 1
    # Bounds storage that trails the declared maximum. Actual tap footprints still need proof.
    width, height = row["width"], row["height"]
    relevant = min(row["mipLevels"], math.ceil(row["maximumLod"]) + 1)
    count = 0
    for level in range(row["mipLevels"]):
        if level >= relevant:
            count += max(1, width >> level) * max(1, height >> level) * 4
    suffix_bytes += count
    identity.add((row["group"],row["format"],row["width"],row["height"],row["mipLevels"]))
report = {
    "sourceArchiveSha256":sha256(path.read_bytes()).hexdigest(),
    "scope": "frozen historical sampler declarations before linear-channel packing",
    "rows":len(rows),
    "imageIdentityGroups":len(identity),
    "levelsBeyondCeilingOfMaximumLod":dict(sorted(histogram.items())),
    "potentialCoarsestMipPayloadBytes":suffix_bytes,
    "requiresLiveSamplerFootprintVerification":True,
}
(run / "sampler-mip-extent.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report))
