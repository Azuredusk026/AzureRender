import json
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
run = Path(__file__).resolve().parent
prior = root / "build/runs/20261113-005205-nr-main-registered-regression-c82feb"
ctest = Path("D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe")
result = {}
for config in ("Debug", "Release"):
    argv = [str(ctest), "--test-dir",str(root / "build" / f"ninja-msvc-{config.lower()}"),
            "-C",config,"--show-only=json-v1"]
    current = json.loads(subprocess.check_output(argv, cwd=root))
    previously = json.loads((prior / f"{config.lower()}-inventory.json").read_bytes())
    current_by_name = {test["name"]:test for test in current["tests"]}
    prior_by_name = {test["name"]:test for test in previously["tests"]}
    assert len(current_by_name) == len(current["tests"])
    assert len(prior_by_name) == len(previously["tests"])
    current_names = set(current_by_name)
    prior_names = set(prior_by_name)
    changed_commands = sorted(name for name in current_names & prior_names
        if current_by_name[name].get("command") != prior_by_name[name].get("command"))
    result[config] = {"currentCount":len(current_names),"previousCount":len(prior_names),
        "added":sorted(current_names-prior_names), "missing":sorted(prior_names-current_names),
        "changedCommands":changed_commands}
(run / "registered-inventory-audit.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result))
