from pathlib import Path
from hashlib import sha256
import json
import os
import sys
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
run = Path(__file__).resolve().parent
capture = run / "original-four"
qualification = root / "docs/acceptance/nr/evidence/2026-11-14/joint-59579-qualification/results.json"
target = root / "docs/acceptance/nr/evidence/2026-11-14/material-viewquad-59579"

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

report = {"capacity":read(run / "capacity-scan.json"),
          "samplerMipExtent":read(run / "sampler-mip-extent.json"),
          "registeredInventory":read(run / "registered-inventory-audit.json"),
          "visualProductReceipt":read(run / "visual-product-receipt-audit.json"),
          "capture":read(capture / "results.json"),
          "originalReferenceDriver":read(run / "pair-recovery.json")["frozenDriver"],
          "pixelPairDispatcher":read(run / "pixel-pair-dispatch.json"),
          "pixelLocalization":read(run / "pixel-localization.json"),
          "fanReady":read(run / "fan-ready.json"),
          "baselineQualificationSha256":digest(qualification)}
assert report["fanReady"]["mode"] == "automatic" and report["capture"]["allocatorZero"]
assert len(report["capture"]["frames"]) == 4
files = {name: run / name for name in ("verify_candidate.py", "measure_candidate.py", "capacity_scan.py",
         "capacity-scan.json", "fan-ready.json", "process.log",
         "archive_evidence.py", "start_pixel_diagnostic.py", "pixel_pair.py", "sparse-capabilities.txt", "sampler_mip_extent.py", "sampler-mip-extent.json", "audit_registered_inventory.py", "registered-inventory-audit.json", "audit_visual_receipt.py", "visual-product-receipt-audit.json", "recover_pixel_pair.py", "pair-recovery.json", "localize_pixels.py", "pixel-localization.json", "pixel-pair-dispatch.json")}
for case, members in (("first-startup-rejected", ("command.json", "environment.json", "dispatch.log")),
                      ("first-pixel-timeout", ("command.json", "environment.json", "dispatch.log", "player.log"))):
    for name in members:
        files[f"{case}/{name}"] = run / case / name
for name in ("results.json", "command.json", "environment.json", "player.log", "runtime.json", "timing.json",
             "frames/capture_manifest.json", "frames/gpu_capabilities.json"):
    files["original-four/" + name] = capture / name
for frame in report["capture"]["frames"]:
    image = capture / "frames" / frame["name"]
    assert digest(image) == frame["sha256"]
rejection = read(run / "first-startup-rejected" / "environment.json")
observed = [row["gpuUtilization"] for row in rejection["observations"]]
report["firstStartupRejection"] = {"error":rejection["error"], "observations":len(observed),
                                   "lastThree":observed[-3:], "limit":rejection["policy"]["maxIdleUtilization"]}
report["firstPixelTimeoutSeconds"] = 360
timing = Path(sys.argv[2]) if len(sys.argv) > 2 else run
if (timing / "results.json").is_file():
    report["longWindow"] = read(timing / "results.json")
    report["longWindow"]["analysis"] = read(timing / "analysis.json")
    assert report["longWindow"]["frames"] == 1800
    assert all(row["changedPixels"] == 0 for row in read(run / "baseline-original-four/results.json")["sameDriverCandidateComparison"])
    for name in ("command.json", "environment.json", "results.json", "timing.csv", "timing.json",
                 "process-memory.json", "player.log", "analysis.json", "analyze_timing.py", "measure_candidate.py"):
        files["long-window/" + name] = timing / name
else:
    report["longWindow"] = None
    if len(sys.argv) > 2 and (timing / "environment.json").is_file():
        status = read(timing / "environment.json")
        report["timingRejection"] = status.get("error")
        for name in ("environment.json", "command.json", "process.log"):
            if (timing / name).is_file():
                files["timing-rejected/" + name] = timing / name

if (run / "baseline-original-four" / "results.json").is_file():
    baseline = run / "baseline-original-four"
    report["baselineCapture"] = read(baseline / "results.json")
    for name in ("command.json", "environment.json", "results.json", "player.log", "runtime.json", "timing.json",
                 "frames/capture_manifest.json", "frames/gpu_capabilities.json"):
        files["baseline-original-four/" + name] = baseline / name
    files["baseline-original-four.py"] = run / "baseline_original_four.py"
    for frame in report["baselineCapture"]["frames"]:
        image = baseline / "frames" / frame["name"]
        assert digest(image) == frame["sha256"]
    if (run / "baseline-process.log").is_file():
        files["baseline-process.log"] = run / "baseline-process.log"
if len(sys.argv) > 1:
    main = Path(sys.argv[1]) / "baseline-original-four"
    report["mainCapture"] = read(main / "results.json")
    assert report["mainCapture"]["allocatorZero"]
    for name in ("command.json", "environment.json", "results.json", "timing.json", "player.log",
                 "frames/capture_manifest.json", "frames/gpu_capabilities.json"):
        files["main/" + name] = main / name
    files["main/run.py"] = main.parent / "main_original_four.py"
    files["main/compare.py"] = main.parent / "compare_main.py"
    files["main/comparison.json"] = main.parent / "main-comparison.json"
target.mkdir(parents=True, exist_ok=True)
bundle = target / "validation.zip"
with ZipFile(bundle, "w", ZIP_DEFLATED) as archive:
    for name, path in files.items():
        archive.write(path, name)
with ZipFile(bundle) as archive:
    assert archive.testzip() is None
    assert all(archive.read(name) == path.read_bytes() for name, path in files.items())
report["archiveSha256"] = digest(bundle)
(target / "results.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(report["archiveSha256"], len(files))

