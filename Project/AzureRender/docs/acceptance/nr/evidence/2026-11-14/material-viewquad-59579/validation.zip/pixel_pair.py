from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
for name in ("baseline_original_four.py", "verify_candidate.py"):
    print("Running", name, flush=True)
    subprocess.run([sys.executable, str(root / name)], check=True)

import json
import numpy as np
from PIL import Image

baseline = root / "baseline-original-four"
computed = root / "original-four"
path = baseline / "results.json"
report = json.loads(path.read_bytes())
result = []
for row in report["frames"]:
    name = row["name"]
    with Image.open(baseline / "frames" / name) as image:
        reference = np.asarray(image.convert("RGB"), dtype=np.int16)
    with Image.open(computed / "frames" / name) as image:
        candidate = np.asarray(image.convert("RGB"), dtype=np.int16)
    error = np.abs(reference - candidate)
    result.append({"name":name, "changedPixels":int(np.count_nonzero(np.any(error, axis=2))), "maximumByteError":int(np.max(error))})
report["sameDriverCandidateComparison"] = result
path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result), flush=True)
