from pathlib import Path
import json
import os
import subprocess
import sys
import time
from zipfile import ZipFile

import numpy as np
from PIL import Image

root = Path.cwd().resolve()
run = Path(__file__).resolve().parent
candidate = Path("D:/Projects/FYP-worktrees/nr-integration-verified/Project/AzureRender")
build = candidate / "build/catalog-computed"
prior = candidate / "build/runs/20261113-022822-nr-material-viewquad-main-integration-e65379"
sys.path.insert(0, str(candidate / "tools"))
from build_provenance import digest, verify
from gpu_environment import RunEnvironmentMonitor, environment_errors, snapshot

def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


deadline = time.monotonic() + 480
while not (run / "fan-ready.json").exists():
    if time.monotonic() >= deadline:
        raise SystemExit("Fan control was not ready")
    time.sleep(1)

proof = read(prior / "candidate-products.json")
verify(candidate, proof)
assert proof["commit"].startswith("01cc6b2")
previous = read(prior / "cost-results.json")
assert previous["originalFourExact"] and all(previous["criteria"].values())
evidence = root / "docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope"
with ZipFile(evidence / "validation.zip") as archive:
    locked = json.loads(archive.read("run/frozen-project-inputs.json"))
    command = json.loads(archive.read("run/capture-command.json"))["command"]
expected = read(evidence / "results.json")["originalFour"]["frames"]
assert len(locked) == 1729 and len(expected) == 4

def verify_inputs():
    assert all(digest(Path(name)) == value for name, value in locked.items())

verify_inputs()
capture = run / "original-four"
capture.mkdir()
command[0] = str(build / "AzurePlayer.exe")
command += ["--resource-root", str(build)]
for flag, dest in (("--capture-dir", capture / "frames"), ("--runtime-report", capture / "runtime.json"),
                   ("--gpu-timing-output", capture / "timing.json")):
    command[command.index(flag) + 1] = str(dest)
env = dict(os.environ, VK_LOADER_DRIVERS_SELECT="*nv-vk64*", DOTNET_ROOT="D:/Tools/dotnet9")
env["PATH"] = os.pathsep.join(map(str, (build, root / "build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin", env["PATH"])))
for key in ("VK_DRIVER_FILES", "VK_ICD_FILENAMES", "VK_INSTANCE_LAYERS", "VK_LAYER_VALIDATE_SYNC", "VK_LOADER_DEBUG",
            "VK_LAYER_ENABLES", "AZURE_CPU_WORK_REPORT", "AZURERENDER_RESOURCE_ROOT", "AZURE_DISABLE_COMPUTED_MATERIAL_VIEW"):
    env.pop(key, None)
save(capture / "command.json", {"command":command, "source":proof["commit"], "productReceiptSha256":digest(prior / "candidate-products.json")})
path = capture / "environment.json"
started = snapshot()
assert started["driver"] == "595.79" and started["hostPower"]["acLineStatus"] == 1
environment = {"startup": [started], "coverage": "PixelDiagnostic", "idleGate": "recorded separately for formal timing"}
save(path, environment)
with RunEnvironmentMonitor(environment, path=path, interval=2), (capture / "player.log").open("wb") as log:
    subprocess.run(command, cwd=candidate, env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=550)
log = (capture / "player.log").read_text(errors="replace")
assert "Allocator after unload: buffers=0 images=0" in log
data = read(capture / "timing.json")
assert data["computedMaterialViewPipelines"] > 0 and data["computedMaterialViewSelectionsTotal"] > 0
observed = environment["startup"] + environment["runObservations"] + [environment["final"]]
assert all(row["driver"] == "595.79" for row in observed)
reference = root / "build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames"
rows = []
for frame in expected:
    name = frame["name"]
    output = capture / "frames" / name
    frozen = reference / name
    actual = digest(output)
    assert digest(frozen) == frame["referenceSha256"]
    with Image.open(output) as image:
        rendered = np.asarray(image.convert("RGB"), dtype=np.int16)
    with Image.open(frozen) as image:
        original = np.asarray(image.convert("RGB"), dtype=np.int16)
    error = np.abs(rendered - original)
    rows.append(dict(name=name, sha256=actual, expected=frame["referenceSha256"], exact=actual == frame["referenceSha256"],
                     changedPixels=int(np.count_nonzero(np.any(error, axis=2))), maximumByteError=int(np.max(error))))
verify(candidate, proof)
verify_inputs()
save(capture / "results.json", {"driver":"595.79", "source":proof["commit"], "frames":rows, "scope":"pixel-diagnostic", "backgroundUtilizationAtStart":started["gpuUtilization"],
                               "watts":sorted({row["powerLimitWatts"] for row in observed}), "allocatorZero":True})
