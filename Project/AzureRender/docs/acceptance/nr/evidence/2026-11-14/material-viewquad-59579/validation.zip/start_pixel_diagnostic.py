from pathlib import Path
import shutil

run = Path(__file__).resolve().parent
rejected = run / "first-startup-rejected"
assert not rejected.exists()
(run / "original-four").replace(rejected)
shutil.copy2(run / "process.log", rejected / "dispatch.log")
for name in ("verify_candidate.py", "baseline_original_four.py"):
    script = run / name
    text = script.read_text(encoding="utf-8")
    text = text.replace("environment_errors, wait_and_record", "environment_errors, snapshot")
    text = text.replace("environment = wait_and_record(path, timeout=120)", '''started = snapshot()
assert started["driver"] == "595.79" and started["hostPower"]["acLineStatus"] == 1
environment = {"startup": [started], "coverage": "PixelDiagnostic", "idleGate": "recorded separately for formal timing"}
save(path, environment)''')
    text = text.replace('"environmentErrors":environment_errors(environment)', '"scope":"pixel-diagnostic", "backgroundUtilizationAtStart":started["gpuUtilization"]')
    text = text.replace('if not all(row["exact"] for row in rows):\n    raise SystemExit("Frozen four-frame acceptance failed; see original-four/results.json")\nsubprocess.run([sys.executable, str(run / "measure_candidate.py")], cwd=root, check=True)\n', '')
    script.write_text(text, encoding="utf-8")
path = run / "archive_evidence.py"
text = path.read_text(encoding="utf-8").replace('         "archive_evidence.py")}', '         "archive_evidence.py", "start_pixel_diagnostic.py")}')
text = text.replace('for name in ("results.json", "command.json", "environment.json", "player.log", "runtime.json", "timing.json",',
'''for name in ("command.json", "environment.json", "dispatch.log"):
    files["first-startup-rejected/" + name] = run / "first-startup-rejected" / name
for name in ("results.json", "command.json", "environment.json", "player.log", "runtime.json", "timing.json",''',1)
text = text.replace('    if not frame["exact"]:\n        files["original-four/frames/" + frame["name"]] = image\n','')
text = text.replace('    assert any(not frame["exact"] for frame in report["capture"]["frames"])','')
text = text.replace('        if not frame["exact"]:\n            files["baseline-original-four/frames/" + frame["name"]] = image\n','')
text = text.replace('if (run / "results.json").is_file():','''rejection = read(run / "first-startup-rejected" / "environment.json")
observed = [row["gpuUtilization"] for row in rejection["observations"]]
report["firstStartupRejection"] = {"error":rejection["error"], "observations":len(observed),
                                   "lastThree":observed[-3:], "limit":rejection["policy"]["maxIdleUtilization"]}
if (run / "results.json").is_file():''')
path.write_text(text, encoding="utf-8")
