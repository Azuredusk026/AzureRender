from pathlib import Path
import csv
import json
import os
import subprocess
import sys
import time
from zipfile import ZipFile

import numpy as np

root = Path.cwd().resolve()
run = Path(__file__).resolve().parent
candidate = Path("D:/Projects/FYP-worktrees/nr-integration-verified/Project/AzureRender")
build = candidate / "build/catalog-computed"
prior = candidate / "build/runs/20261113-022822-nr-material-viewquad-main-integration-e65379"
sys.path.insert(0, str(candidate / "tools"))
from build_provenance import digest, verify
from gpu_environment import RunEnvironmentMonitor, environment_errors, wait_and_record
from run_playable_performance import memory_snapshot


def read(path):
    return json.loads(path.read_bytes())


def save(name, value):
    (run / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


proof = read(prior / "candidate-products.json")
archive = root / "docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope/validation.zip"
with ZipFile(archive) as package:
    locked = json.loads(package.read("run/frozen-project-inputs.json"))
    command = json.loads(package.read("run/diagnostic-1080p60/command.json"))["command"]
baseline_command = read(Path("D:/Projects/FYP/Project/AzureRender/build/runs/20261114-011046-nr-joint-59579-max-fan-control-c9091a") / "command.json")["command"]
for index, value in enumerate(baseline_command):
    if index == 0 or baseline_command[index-1] in ("--resource-root", "--gpu-timing-output"):
        continue
    assert command[index] == value
assert len(locked) == 1729
verify(candidate, proof)
assert all(digest(Path(path)) == value for path, value in locked.items())
timing = run / "timing.json"
command[0] = str(build / "AzurePlayer.exe")
command[command.index("--resource-root") + 1] = str(build)
command[command.index("--gpu-timing-output") + 1] = str(timing)
env = dict(os.environ, VK_LOADER_DRIVERS_SELECT="*nv-vk64*", DOTNET_ROOT="D:/Tools/dotnet9")
env["PATH"] = os.pathsep.join(map(str, (build, root / "build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin", env["PATH"])))
for key in ("VK_DRIVER_FILES", "VK_ICD_FILENAMES", "VK_INSTANCE_LAYERS", "VK_LAYER_VALIDATE_SYNC", "VK_LOADER_DEBUG",
            "VK_LAYER_ENABLES", "AZURE_CPU_WORK_REPORT", "AZURERENDER_RESOURCE_ROOT", "AZURE_DISABLE_COMPUTED_MATERIAL_VIEW"):
    env.pop(key, None)
save("command.json", {"command":command, "source":proof["commit"], "frozenInputCount":len(locked), "productReceiptSha256":digest(prior / "candidate-products.json")})
path = run / "environment.json"
environment = wait_and_record(path, timeout=120)
observations = []
start = time.monotonic()
with RunEnvironmentMonitor(environment, path=path, interval=2), (run / "player.log").open("wb") as log:
    player = subprocess.Popen(command, cwd=candidate, env=env, stdout=log, stderr=subprocess.STDOUT)
    try:
        while player.poll() is None:
            try:
                observations.append(memory_snapshot(player.pid))
            except OSError:
                if player.poll() is not None:
                    break
                raise
            if time.monotonic()-start > 650:
                raise TimeoutError("Joint scene candidate timed out")
            time.sleep(.2)
    finally:
        if player.poll() is None:
            player.kill()
            player.wait()
        save("process-memory.json", observations)
assert player.returncode == 0
assert "Allocator after unload: buffers=0 images=0" in (run / "player.log").read_text(errors="replace")
data = read(timing)
assert (data["sceneWidth"], data["sceneHeight"]) == (1920, 1080)
assert data["computedMaterialViewPipelines"] > 0 and data["computedMaterialViewSelectionsTotal"] > 0
assert data["computedMaterialViewFrameEligible"] and data["computedMaterialViewFallback"] == "ready"
with timing.with_suffix(".csv").open(encoding="utf-8") as stream:
    rows = [row for row in csv.DictReader(stream) if 300 < int(row["frame"]) <= 2100]
assert [int(row["frame"]) for row in rows] == list(range(301, 2101))
cpu = data["cpuFrame"]["workSamplesMs"]
assert len(cpu) == 2100
observed = environment["startup"] + environment["runObservations"] + [environment["final"]]
assert all(row["driver"] == "595.79" for row in observed)

def stats(values):
    return {"mean":float(np.mean(values)), "p95":float(np.percentile(values, 95)), "peak":float(np.max(values))}


def window(begin, end):
    result = {key:stats([float(row[key]) for row in rows[begin:end]])
              for key in ("frameMs", "sceneMs", "shadowMs", "postProcessMs")}
    result["cpuWorkMs"] = stats(cpu[300+begin:300+end])
    return result


total = window(0, 1800)
thermal = environment_errors(environment)
local = data["allocator"]["deviceLocalPeakBytes"]
working = max(row["peak"] for row in observations)
watts = sorted({row["powerLimitWatts"] for row in observed})
gates = {"fixed80W":watts==[80.0], "thermalAndAC":not thermal, "gpuP95":total["frameMs"]["p95"]<=16.6,
         "cpuP95":total["cpuWorkMs"]["p95"]<=8, "deviceLocal":local<=1610612736, "workingSet":working<=2147483648}
verify(candidate, proof)
assert all(digest(Path(path)) == value for path, value in locked.items())
save("results.json", {"scope":"isolated-computed-material-view-1080p60", "source":proof["commit"], "driver":"595.79", "warmup":300,
                       "frames":1800, "gpuPowerLimitWatts":watts, "environmentFailures":thermal,
                       "peakTemperatureC":max(row["temperature"] for row in observed), "observationCount":len(observed),
                       "softwareThermalSlowdownObservations":sum(row["thermalSlowdown"]["software"] for row in observed),
                       "timings":total, "deviceLocalPeakBytes":local, "workingSetPeakBytes":working, "allocatorZero":True,
                       "gates":gates, "windows":[window(i,i+300) for i in range(0,1800,300)]})
