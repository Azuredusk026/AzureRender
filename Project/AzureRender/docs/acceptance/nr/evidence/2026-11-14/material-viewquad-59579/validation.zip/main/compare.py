from hashlib import sha256
from pathlib import Path
import json
import sys
from PIL import Image
import numpy as np

main = Path(__file__).resolve().parent
control = Path(sys.argv[1])
target = main / "baseline-original-four"
reference = control / "baseline-original-four/frames"
report = json.loads((target / "results.json").read_bytes())
assert report["allocatorZero"] and report["driver"] == "595.79"
combined = []
for row in report["frames"]:
    name = row["name"]
    a = target / "frames" / name
    b = reference / name
    with Image.open(a) as im:
        application = np.asarray(im.convert("RGB"), dtype=np.int16)
    with Image.open(b) as im:
        reference_path = np.asarray(im.convert("RGB"), dtype=np.int16)
    diff = np.abs(application - reference_path)
    combined.append({"name":name,"changedPixels":int(np.count_nonzero(np.any(diff,axis=2))),
                     "maximumByteError":int(diff.max()),
                     "pngExact":sha256(a.read_bytes()).digest()==sha256(b.read_bytes()).digest()})
(main / "main-comparison.json").write_text(json.dumps(combined, indent=2) + "\n", encoding="utf-8")
report["sameDriverReferenceMaterialComparison"] = combined
(target / "results.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(combined))
