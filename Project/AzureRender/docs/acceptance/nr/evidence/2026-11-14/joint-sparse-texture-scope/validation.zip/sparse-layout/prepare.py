import json
from pathlib import Path
from zipfile import ZipFile

root = Path.cwd()
out = Path(__file__).resolve().parent
source = root / "docs/acceptance/nr/evidence/2026-11-11/resident-srgb-channel-scope/validation.zip"
with ZipFile(source) as package:
    inventory = json.loads(package.read("texture-inventory.json"))
formats = {"R8G8B8A8_SRGB":43,"R8G8B8A8_UNORM":37,"R8G8_UNORM":16,"R8_UNORM":9}
images = [row for row in inventory if row["format"] in formats and row["name"].startswith("2D Image ")
          and row["mips"]>1 and row["arraysize"]==1 and row["msSamples"]==1]
assert len(images)==364
specs = sorted({(formats[row["format"]],row["width"],row["height"],row["mips"]) for row in images})
(out/"images.txt").write_text("".join(" ".join(map(str,desc))+"\n" for desc in specs),encoding="ascii")
print(len(specs),"image descriptions")
