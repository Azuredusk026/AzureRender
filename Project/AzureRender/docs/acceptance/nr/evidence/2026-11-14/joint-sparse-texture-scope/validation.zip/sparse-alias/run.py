import json
import os
from pathlib import Path
import subprocess
import sys

root=Path.cwd()
out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/"tools"))
from artifact_maintenance import managed_environment
info=subprocess.STARTUPINFO()
info.dwFlags|=subprocess.STARTF_USESHOWWINDOW
info.wShowWindow=0
with (out/"replay.log").open("wb") as log:
    child=subprocess.run(["D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe","--python",str(out/"scan.py")],
        cwd=out,env=dict(os.environ,**managed_environment(out/"tmp")),
        stdout=log,stderr=subprocess.STDOUT,startupinfo=info,timeout=420)
report=json.loads((out/"results.json").read_bytes())
assert child.returncode==0 and report["status"]=="complete",report.get("error")
print(report,flush=True)
