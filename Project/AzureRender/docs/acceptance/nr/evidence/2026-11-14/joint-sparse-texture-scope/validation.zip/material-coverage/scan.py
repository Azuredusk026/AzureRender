from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys
import time
import traceback
from zipfile import ZipFile

import renderdoc as rd

root = Path(r"D:/Projects/FYP/Project/AzureRender")
out = Path(r"D:/Projects/FYP/Project/AzureRender/build/runs/20261114-025819-nr-joint-texture-reachability-fbe01a")
run = root / "build/runs/20261111-001050-quad-feature-device-capture-4798d1"
prior = root / "docs/acceptance/nr/evidence/2026-11-14/joint-texture-usage/validation.zip"
state = json.loads((run / "state.json").read_bytes())
with ZipFile(prior) as archive:
    known = json.loads(archive.read("usage-feedback.json"))
events = {entry["event"]: entry for entry in json.loads((run / "mapped-events.json").read_bytes())}
assert len(events) == 3453
images = {entry["resource"]: entry for entry in known["entries"]}
assert len(images) == 364
reports = {}
report = {"sourceCaptureSha256":state["captureSha256"],"frame":state["captureFrame"],
          "eventCount":len(events),"status":"starting"}
cap = controller = None
start = time.monotonic()

def save():
    path = out/"progress.json.pending"
    path.write_text(json.dumps(dict(report,seconds=time.monotonic()-start),indent=2)+"\n",encoding="utf-8")
    path.replace(out/"progress.json")

try:
    digest = sha256()
    with Path(state["capture"]).open("rb") as capture:
        for data in iter(lambda: capture.read(1024*1024),b""):
            digest.update(data)
    assert digest.hexdigest() == state["captureSha256"] == known["sourceCaptureSha256"]
    cap = rd.OpenCaptureFile()
    assert cap.OpenFile(state["capture"],"",None) == rd.ResultCode.Succeeded
    status, controller = cap.OpenCapture(rd.ReplayOptions(),None)
    assert status == rd.ResultCode.Succeeded
    counts = Counter()
    kinds = Counter()
    capture_events = set()
    def walk(tree):
        for action in tree:
            if (action.flags & (rd.ActionFlags.Drawcall | rd.ActionFlags.Dispatch)) and not action.children:
                capture_events.add(action.eventId)
            walk(action.children)
    walk(controller.GetRootActions())
    report["mappedEventsOutsideLeafDrawDispatch"] = sorted(set(events)-capture_events)
    report["leafDrawDispatchOutsideMappedEvents"] = sorted(capture_events-set(events))
    selected = sorted(capture_events | set(events))
    report["selectedEventCount"] = len(selected)
    for index, event in enumerate(selected,1):
        controller.SetFrameEvent(event,False)
        pipeline = controller.GetPipelineState()
        found = set()
        for binding in pipeline.GetAllUsedDescriptors(True):
            name = str(binding.descriptor.resource)
            if name in images:
                found.add(name)
                kinds[str(binding.access.stage).split(".")[-1]] += 1
        if found:
            counts.update(found)
            reports[event] = sorted(found)
        if index % 50 == 0:
            report.update(completedEvents=index, observedImages=len(counts))
            save()
    for src in known["exampleDynamicAccesses"]:
        seen = set(reports.get(src["event"], []))
        expected = {value["resource"] for value in src["boundMaterialTextureWitnesses"]}
        assert expected <= seen, (src["event"], sorted(expected-seen))
    unread = set(images)-set(counts)
    report.update(status="complete",completedEvents=len(selected),observedImages=len(counts),stages=dict(kinds),
        noMatchingDescriptors=len(unread),
        noMatchingDescriptorBytes=sum(images[name]["textureBytes"] for name in unread),
        noMatchingDescriptorTopMipBytes=sum(images[name]["topMipTexelBytes"] for name in unread),
        entries=[dict(image,descriptorFeedbackEvents=counts[name]) for name,image in images.items()])
    (out/"events.json").write_text(json.dumps(reports,indent=2)+"\n",encoding="utf-8")
except Exception:
    report.update(status="failed",error=traceback.format_exc())
finally:
    save()
    if controller:
        controller.Shutdown()
    if cap:
        cap.Shutdown()
    report["seconds"]=time.monotonic()-start
    (out/"results.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
sys.exit(0 if report["status"]=="complete" else 2)
