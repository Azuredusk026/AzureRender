from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

root=Path.cwd()
out=Path(__file__).resolve().parent
source=root/"docs/acceptance/nr/evidence/2026-11-11/resident-srgb-channel-scope/validation.zip"
with ZipFile(source) as archive:
    inventory=json.loads(archive.read("texture-inventory.json"))
formats={"R8G8B8A8_SRGB":43,"R8G8B8A8_UNORM":37,"R8G8_UNORM":16,"R8_UNORM":9}
size={43:4,37:4,16:2,9:1}
images=[row for row in inventory if row["format"] in formats and row["name"].startswith("2D Image ")
        and row["mips"]>1 and row["arraysize"]==1 and row["msSamples"]==1]
assert len(images)==364
keys=[(formats[row["format"]],row["width"],row["height"],row["mips"]) for row in images]
shapes=Counter(keys)
report={}
for device,vendor in (("nvidia","10de"),("intel","8086")):
    with (out/f"{device}.csv").open() as file:
        rows=list(csv.DictReader(file))
    assert len(rows)==len(shapes) and all(row["status"]=="ok" and row["vendor"]==vendor and row["aspect"]=="1" for row in rows)
    row_by_shape={tuple(int(row[key]) for key in ("format","width","height","mips")):row for row in rows}
    assert set(row_by_shape)==set(shapes)
    amounts=Counter()
    formats_pages={}
    for shape,count in shapes.items():
        fmt,width,height,mips=shape
        row=row_by_shape[shape]
        tail_start,tail_bytes,alignment,page_w,page_h,virtual = (int(row[name]) for name in ("tailFirst","tailBytes","alignment","pageWidth","pageHeight","virtualBytes"))
        assert mips>tail_start>=0 and tail_bytes%alignment==0
        assert page_w*page_h*size[fmt]==alignment
        page = {"width":page_w,"height":page_h,"bytes":alignment}
        assert fmt not in formats_pages or formats_pages[fmt]==page
        formats_pages[fmt]=page
        def tiled_bytes(index):
            w,h=max(1,width>>index),max(1,height>>index)
            return ((w+page_w-1)//page_w)*((h+page_h-1)//page_h)*alignment
        full=tail_bytes+sum(tiled_bytes(index) for index in range(tail_start))
        amounts.update(tailBytes=count*tail_bytes, estimatedAllBoundBytes=count*full,
                       virtualBytes=count*virtual, firstMipPageBytes=count*(tiled_bytes(0) if tail_start else 0),
                       tailPlusFirstMipPageBytes=count*(tail_bytes+(tiled_bytes(0) if tail_start else 0)),
                       allInMipTail=count*int(tail_start==0))
    report[device]={**amounts,"pageDimensions":formats_pages,"shapes":len(rows)}
result={"scope":"hypothetical sparse image layout of historical captured 2D formats and extents",
        "inventoryArchiveSha256":hashlib.sha256(source.read_bytes()).hexdigest(),
        "shapes":len(shapes),"images":len(images),"devices":report,
        "allocatedOrReadSparsePages":False,"preservedSamplingProven":False}
(out/"results.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(report))
