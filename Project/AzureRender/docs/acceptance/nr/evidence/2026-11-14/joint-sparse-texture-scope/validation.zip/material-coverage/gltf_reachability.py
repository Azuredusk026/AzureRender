from collections import Counter
import json
from pathlib import Path
from struct import unpack
from zipfile import ZipFile

root = Path.cwd()
out = Path(__file__).resolve().parent
proof = root / "docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope/validation.zip"
with ZipFile(proof) as archive:
    frozen = json.loads(archive.read("run/frozen-project-inputs.json"))
project = next(Path(name) for name in frozen if name.endswith("qualified-lit-surfaces-joint-v4\\joint-materials.azureproject"))
doc = json.loads(project.read_bytes())
mounts = {m["name"]:project.parent/m["path"] for m in doc["mounts"]}
def workspace_path(value):
    namespace, name = value.split(":/",1)
    return mounts[namespace]/name
scene = json.loads(workspace_path(doc["startupScene"]).read_bytes())
class Counts(Counter):
    pass
assets = {}
for meta_path in set(p for p in map(Path,frozen) if p.suffix==".azmeta"):
    data = json.loads(meta_path.read_bytes())
    uid = data.get("uuid",data.get("id"))
    if uid:
        assets[uid] = meta_path.with_suffix("")
def material_indices(path):
    with path.open("rb") as f:
        if path.suffix.lower()==".glb":
            tag, version, length = unpack("<4sII",f.read(12))
            assert (tag,version)==(b"glTF",2)
            size, chunk = unpack("<I4s",f.read(8))
            assert chunk==b"JSON"
            return json.loads(f.read(size))
        return json.load(f)
stats = Counts()
rows = []
cache = {}
for resource in scene["resources"]:
    name = resource["asset"]
    path = workspace_path(name) if ":/" in name else assets.get(name)
    if not path or not path.is_file() or path.suffix.lower() not in (".glb",".gltf"):
        stats["unresolvedResources"] += 1
        continue
    if path not in cache:
        asset = material_indices(path)
        total = len(asset.get("materials",[]))
        materials = set()
        nodes = asset.get("nodes",[])
        scene_index = asset.get("scene",0)
        scenes = asset.get("scenes",[])
        roots = list(scenes[scene_index]["nodes"]) if scenes else [i for i,n in enumerate(nodes) if "mesh" in n]
        visited=set()
        while roots:
            index=roots.pop()
            if index in visited:
                continue
            visited.add(index)
            node=nodes[index]
            roots.extend(node.get("children",[]))
            if "mesh" in node:
                materials.update(p.get("material",-1) for p in asset["meshes"][node["mesh"]]["primitives"])
        stats["materialSlots"] += total
        unused = sorted(set(range(total))-materials)
        for index in unused:
            material = asset["materials"][index]
            images = set()
            for p in list(material.values())+list(material.get("pbrMetallicRoughness",{}).values()):
                if type(p) is dict and "index" in p and type(p["index"]) is int:
                    images.add(p["index"])
            stats["unusedMaterialSlotsWithDeclaredTexture"] += bool(images)
        stats["unusedMaterialSlots"]+=len(unused)
        stats["assets"]+=1
        cache[path]=[total,unused]
        if unused:
            rows.append({"asset":str(path.relative_to(project.parent)), "slots":total,"unreferenced":unused})
    stats["sceneResourcePaths"]+=1
(out/"gltf-reachability.json").write_text(json.dumps({"scope":"Static glTF primitive material indices; excludes binding values and dynamic visibility", "totals":dict(stats),"withUnreferenced":rows},indent=2)+"\n",encoding="utf-8")
print(dict(stats))
