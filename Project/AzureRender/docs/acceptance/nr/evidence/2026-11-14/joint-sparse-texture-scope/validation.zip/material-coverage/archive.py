import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZIP_DEFLATED, ZipFile

root=Path.cwd()
out=Path(__file__).resolve().parent
layout,tiles=map(Path,sys.argv[1:])
def read(file):
    return json.loads(file.read_bytes())
def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()
reach=read(out/"results.json")
slots=read(out/"gltf-reachability.json")
pages=read(layout/"results.json")
alias=read(tiles/"results.json")
capacity=read(root/"docs/acceptance/nr/evidence/2026-11-14/joint-59579-qualification/results.json")
assert reach["completedEvents"]==len(set(range(3453))) and reach["mappedEventsOutsideLeafDrawDispatch"]==reach["leafDrawDispatchOutsideMappedEvents"]==[]
assert reach["observedImages"]+reach["noMatchingDescriptors"]==len(reach["entries"])==364
assert slots["totals"]=={"materialSlots":395,"unusedMaterialSlots":0,"assets":374,"sceneResourcePaths":374}
assert pages["images"]==alias["completedImages"]==364 and pages["shapes"]==22
assert alias["sourceCaptureSha256"]==reach["sourceCaptureSha256"]
assert [sum(alias[key].values()) for key in ("examinedPages","duplicatePages")]==[27951,3432]
assert alias["potentialDuplicatePageBytes"]==3432*65536
gap=capacity["capacityEnvelope"]["peakOverLimitBytes"]
rough=reach["noMatchingDescriptorBytes"]+alias["potentialDuplicatePageBytes"]
assert rough<gap
result={"sourceCaptureSha256":reach["sourceCaptureSha256"],"source":"73300ab","frame":reach["frame"],
        "staticPrimitiveSlots":slots["totals"],"descriptorEvents":reach["completedEvents"],"descriptorImageCount":reach["observedImages"],
        "staticMissesWithDescriptorFeedback":sum(row["usageEvents"]==0 and row["descriptorFeedbackEvents"]>0 for row in reach["entries"]),
        "noMatchingDescriptorImages":reach["noMatchingDescriptors"],"noMatchingDescriptorImageBytes":reach["noMatchingDescriptorBytes"],
        "sparseLayout":pages,"duplicatePageScan":alias,
        "deviceLocalAllocationGapBytes":gap,"illustrativeCombinedBytes":rough,"remainingIllustrativeGapBytes":gap-rough,
        "scope":"One captured frame and historical byte inventory. Combined figure assumes independent full savings and compares logical image bytes against an allocation gap. Actual future texture reads and sparse aliasing remain unverified."}
dest=root/"docs/acceptance/nr/evidence/2026-11-14/joint-sparse-texture-scope"
dest.mkdir(parents=True,exist_ok=True)
files={}
for prefix,folder,names in (
    ("material-coverage",out,("gltf_reachability.py","gltf-reachability.json","scan.py","run.py","results.json","events.json","replay.log","process.log","archive.py")),
    ("sparse-layout",layout,("query.cpp","prepare.py","analyze.py","images.txt","nvidia.csv","intel.csv","results.json")),
    ("sparse-alias",tiles,("scan.py","run.py","results.json","replay.log","process.log")),
):
    for name in names:
        files[f"{prefix}/{name}"]=folder/name
package=dest/"validation.zip"
with ZipFile(package,"w",ZIP_DEFLATED) as archive:
    for name,file in files.items():
        archive.write(file,name)
with ZipFile(package) as archive:
    assert archive.testzip() is None and all(archive.read(name)==file.read_bytes() for name,file in files.items())
result["archiveSha256"]=sha(package)
(dest/"results.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(result["remainingIllustrativeGapBytes"],len(files),result["archiveSha256"])
