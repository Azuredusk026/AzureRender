#include <vulkan/vulkan.h>

#include <array>
#include <cstdint>
#include <cstdio>
#include <stdexcept>
#include <vector>

namespace {
void check(VkResult result, const char* operation) {
    if (result != VK_SUCCESS) throw std::runtime_error(operation);
}

struct Instance {
    VkInstance value = VK_NULL_HANDLE;
    ~Instance() { if (value) vkDestroyInstance(value, nullptr); }
};
struct Device {
    VkDevice value = VK_NULL_HANDLE;
    ~Device() { if (value) vkDestroyDevice(value, nullptr); }
};
struct Image {
    VkDevice device;
    VkImage value = VK_NULL_HANDLE;
    ~Image() { if (value) vkDestroyImage(device, value, nullptr); }
};

void query(VkPhysicalDevice physical, VkDevice device, const VkPhysicalDeviceProperties& adapter,
           VkFormat format, uint32_t width, uint32_t height, uint32_t levels) {
    constexpr VkImageUsageFlags usage = VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT
                                       | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
    constexpr VkImageCreateFlags flags = VK_IMAGE_CREATE_SPARSE_BINDING_BIT | VK_IMAGE_CREATE_SPARSE_RESIDENCY_BIT;
    VkImageFormatProperties support{};
    const auto supported = vkGetPhysicalDeviceImageFormatProperties(physical, format, VK_IMAGE_TYPE_2D,
        VK_IMAGE_TILING_OPTIMAL, usage, flags, &support);
    if (supported != VK_SUCCESS || width > support.maxExtent.width || height > support.maxExtent.height ||
        levels > support.maxMipLevels) {
        std::printf("%x,%x,%u,%u,%u,%u,unsupported,0,0,0,0,0,0,0,0,0,0\n",
                    adapter.vendorID, adapter.deviceID, format, width, height, levels);
        return;
    }

    VkImageCreateInfo info{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    info.flags = flags;
    info.imageType = VK_IMAGE_TYPE_2D;
    info.format = format;
    info.extent = {width, height, 1};
    info.mipLevels = levels;
    info.arrayLayers = 1;
    info.samples = VK_SAMPLE_COUNT_1_BIT;
    info.tiling = VK_IMAGE_TILING_OPTIMAL;
    info.usage = usage;
    info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    Image image{device};
    check(vkCreateImage(device, &info, nullptr, &image.value), "vkCreateImage");
    uint32_t number = 0;
    vkGetImageSparseMemoryRequirements(device, image.value, &number, nullptr);
    if (number == 0) throw std::runtime_error("Missing sparse requirements");
    std::vector<VkSparseImageMemoryRequirements> ranges(number);
    vkGetImageSparseMemoryRequirements(device, image.value, &number, ranges.data());
    VkMemoryRequirements requirements{};
    vkGetImageMemoryRequirements(device, image.value, &requirements);
    for (const auto& range : ranges) {
        const auto& properties = range.formatProperties;
        std::printf("%x,%x,%u,%u,%u,%u,ok,%u,%u,%u,%u,%u,%llu,%llu,%llu,%llu,%u\n",
                    adapter.vendorID, adapter.deviceID, format, width, height, levels,
                    properties.aspectMask, properties.imageGranularity.width, properties.imageGranularity.height,
                    properties.flags, range.imageMipTailFirstLod,
                    (unsigned long long)range.imageMipTailSize, (unsigned long long)range.imageMipTailOffset,
                    (unsigned long long)requirements.alignment, (unsigned long long)requirements.size,
                    requirements.memoryTypeBits);
    }
}
}

int main() {
    try {
        VkApplicationInfo application{VK_STRUCTURE_TYPE_APPLICATION_INFO};
        application.apiVersion = VK_API_VERSION_1_1;
        VkInstanceCreateInfo settings{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
        settings.pApplicationInfo = &application;
        Instance instance;
        check(vkCreateInstance(&settings, nullptr, &instance.value), "vkCreateInstance");
        uint32_t count = 0;
        check(vkEnumeratePhysicalDevices(instance.value, &count, nullptr), "vkEnumeratePhysicalDevices");
        std::vector<VkPhysicalDevice> candidates(count);
        check(vkEnumeratePhysicalDevices(instance.value, &count, candidates.data()), "vkEnumeratePhysicalDevices");
        if (count == 0) throw std::runtime_error("No requested adapter");
        std::puts("vendor,device,format,width,height,mips,status,aspect,pageWidth,pageHeight,flags,tailFirst,tailBytes,tailOffset,alignment,virtualBytes,typeBits");
        for (auto physical : candidates) {
            VkPhysicalDeviceFeatures support{};
            VkPhysicalDeviceProperties properties{};
            vkGetPhysicalDeviceFeatures(physical, &support);
            vkGetPhysicalDeviceProperties(physical, &properties);
            if (!support.sparseBinding || !support.sparseResidencyImage2D) continue;
            uint32_t n = 0;
            vkGetPhysicalDeviceQueueFamilyProperties(physical, &n, nullptr);
            std::vector<VkQueueFamilyProperties> queues(n);
            vkGetPhysicalDeviceQueueFamilyProperties(physical, &n, queues.data());
            uint32_t queue = 0;
            while (queue < n && (queues[queue].queueFlags & VK_QUEUE_SPARSE_BINDING_BIT) == 0) ++queue;
            if (queue == n) throw std::runtime_error("Sparse binding feature has no queue");
            VkPhysicalDeviceFeatures features{};
            features.sparseBinding = VK_TRUE;
            features.sparseResidencyImage2D = VK_TRUE;
            const float priority = 1.0F;
            VkDeviceQueueCreateInfo queueInfo{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
            queueInfo.queueFamilyIndex = queue;
            queueInfo.queueCount = 1;
            queueInfo.pQueuePriorities = &priority;
            VkDeviceCreateInfo creation{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
            creation.queueCreateInfoCount = 1;
            creation.pQueueCreateInfos = &queueInfo;
            creation.pEnabledFeatures = &features;
            Device device;
            check(vkCreateDevice(physical, &creation, nullptr, &device.value), "vkCreateDevice");
            uint32_t format, width, height, levels;
            const long begin = std::ftell(stdin);
            while (std::scanf("%u %u %u %u", &format, &width, &height, &levels)==4)
                query(physical, device.value, properties, static_cast<VkFormat>(format), width, height, levels);
            std::fseek(stdin, begin, SEEK_SET);
        }
        return 0;
    } catch (const std::exception& error) {
        std::fprintf(stderr, "%s\n", error.what());
        return 1;
    }
}
