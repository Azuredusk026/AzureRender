from collections import Counter
import csv
from hashlib import sha256
import json
from pathlib import Path
import sys
import time
import traceback
from zipfile import ZipFile

import renderdoc as rd

root = Path(r"D:/Projects/FYP/Project/AzureRender")
out = Path(r"D:/Projects/FYP/Project/AzureRender/build/runs/20261114-030941-nr-joint-sparse-alias-scope-51bc3b")
layouts = Path(r"D:/Projects/FYP/Project/AzureRender/build/runs/20261114-030612-nr-joint-sparse-page-layout-18de6b")
producer = root / "build/runs/20261111-001050-quad-feature-device-capture-4798d1"
source = root / "docs/acceptance/nr/evidence/2026-11-11/resident-srgb-channel-scope/validation.zip"
state = json.loads((producer/"state.json").read_bytes())
with ZipFile(source) as archive:
    inventory = {row["resource"]:row for row in json.loads(archive.read("texture-inventory.json"))}
formats = {"R8G8B8A8_SRGB":(43,4),"R8G8B8A8_UNORM":(37,4),"R8G8_UNORM":(16,2),"R8_UNORM":(9,1)}
tables = []
for adapter in ("nvidia","intel"):
    with (layouts/f"{adapter}.csv").open() as stream:
        table = {}
        for row in csv.DictReader(stream):
            assert row["status"]=="ok"
            shape=tuple(int(row[key]) for key in ("format","width","height","mips"))
            table[shape]=tuple(int(row[key]) for key in ("pageWidth","pageHeight","tailFirst","alignment"))
        assert len(table)==22
        tables.append(table)
cap = controller = None
start = time.monotonic()
report = {"status":"starting","sourceCaptureSha256":state["captureSha256"],"tileScope":"complete 64 KiB color pages, same exact format, outside both mip tails"}
def save():
    p = out / "progress.json.pending"
    p.write_text(json.dumps(dict(report,seconds=time.monotonic()-start),indent=2)+"\n",encoding="utf-8")
    p.replace(out/"progress.json")
try:
    digest=sha256()
    with Path(state["capture"]).open("rb") as stream:
        for block in iter(lambda:stream.read(1024*1024),b""):
            digest.update(block)
    assert digest.hexdigest()==state["captureSha256"]
    cap=rd.OpenCaptureFile()
    assert cap.OpenFile(state["capture"],"",None)==rd.ResultCode.Succeeded
    status,controller=cap.OpenCapture(rd.ReplayOptions(),None)
    assert status==rd.ResultCode.Succeeded
    controller.SetFrameEvent(0,True)
    hashes={}
    all_pages=Counter()
    shared_pages=Counter()
    zero_pages=Counter()
    read_bytes=0
    images=0
    zero=sha256(bytes(65536)).digest()
    for image in controller.GetTextures():
        identity=str(image.resourceId)
        row=inventory[identity]
        fmt=image.format.Name()
        if fmt not in formats or not row["name"].startswith("2D Image ") or image.mips<=1 or image.arraysize!=1 or image.msSamp!=1:
            continue
        images+=1
        number,bpp=formats[fmt]
        shape=(number,image.width,image.height,image.mips)
        pw,ph,nvidia,allocation=tables[0][shape]
        iw,ih,intel,other=tables[1][shape]
        assert (pw,ph,allocation)==(iw,ih,other) and pw*ph*bpp==allocation==65536
        for mip in range(min(nvidia,intel)):
            width=max(1,image.width>>mip)
            height=max(1,image.height>>mip)
            columns,rows=width//pw,height//ph
            if columns==0 or rows==0:
                continue
            data=controller.GetTextureData(image.resourceId,rd.Subresource(mip,0,0))
            assert len(data)==width*height*bpp,(identity,mip,len(data),width,height,bpp)
            read_bytes+=len(data)
            view=memoryview(data)
            stride=width*bpp
            page_stride=pw*bpp
            for y in range(rows):
                for x in range(columns):
                    first=y*ph*stride+x*page_stride
                    h=sha256()
                    for line in range(ph):
                        begin=first+line*stride
                        h.update(view[begin:begin+page_stride])
                    signature=h.digest()
                    key=(number,signature)
                    all_pages[fmt]+=1
                    if key in hashes:
                        shared_pages[fmt]+=1
                    else:
                        hashes[key]=(identity,mip,x,y)
                    if signature==zero:
                        zero_pages[fmt]+=1
        if images%25==0:
            report.update(completedImages=images,examinedPages=sum(all_pages.values()),rawBytesRead=read_bytes)
            save()
    assert images==364 and sum(all_pages.values())-sum(shared_pages.values())==len(hashes)
    report.update(status="complete",completedImages=images,rawBytesRead=read_bytes,
                  examinedPages=dict(all_pages),duplicatePages=dict(shared_pages),allZeroPages=dict(zero_pages),
                  examinedPageBytes=65536*sum(all_pages.values()),
                  potentialDuplicatePageBytes=65536*sum(shared_pages.values()))
except Exception:
    report.update(status="failed",error=traceback.format_exc())
finally:
    save()
    if controller:
        controller.Shutdown()
    if cap:
        cap.Shutdown()
    report["seconds"]=time.monotonic()-start
    (out/"results.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
sys.exit(0 if report["status"]=="complete" else 2)
