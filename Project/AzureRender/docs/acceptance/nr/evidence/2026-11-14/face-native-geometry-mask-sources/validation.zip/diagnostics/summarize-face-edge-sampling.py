from hashlib import sha256
from pathlib import Path
import json
import numpy as np

out=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
capture=out/'face-edge-vulkan-sampling'
r=read(capture/'results.json')
assert r['status']=='qualified'
entry,=[x for x in r['events'] if x['event']==876]
assert entry['selection']['baseline']==entry['selection']['copy']==entry['selection']['restored']
values={}
for key,source in entry['selection'].items():
    p=capture/f'876-{key}-direct.bin'
    b=p.read_bytes()
    assert sha256(b).hexdigest()==source['selectedSha256']['direct']
    values[key]=np.frombuffer(b,'<f2').astype(float).reshape(-1,4)[:,:3]
native=read(out/'face-edge-native-sampling.json')
assert native['status']=='qualified'
native_owners=read(out/'face-native-lanes-summary.json')['faceBaseOwners']['native']['points']
assert [row['point'] for row in native['rows']]==native_owners
assert len(native_owners)==12
rows=[]
for i,row in enumerate(native['rows']):
    registers=row['registers']
    n,rgb=registers['33']['r5'],registers['52']['r5']
    material=registers['69']['r10'][:3]
    mask=registers['70']['r11']
    assert n==rgb
    disk={k:v[i].tolist() for k,v in values.items()}
    node={'screen':row['point']['point'],'primitive':row['point']['primitive'],
            'native':{'linearBaseRgb':n[1:4],'lookupRgb':material,'rgbaStyle':mask,'shaderRgb':row['point']['rgb']},
            'player':disk}
    delta=np.abs(np.asarray(n[1:4])-values['mipalbedo'][i])
    node['nativeVsPlayerBaseMax']=float(delta.max())
    node['nativeVsPlayerStyleMax']=float(np.max(np.abs(np.asarray(mask[:3])-values['mipmask'][i])))
    rows.append(node)
print('coordinate mip base native/player max mask max lookup native/player')
for p in rows:
    n,h=p['native'],p['player']
    f=lambda v: np.round(v,5).tolist()
    print(p['screen'],f(np.array(h['mipalbedo-lod'])*8),f(n['linearBaseRgb']),f(h['mipalbedo']),round(p['nativeVsPlayerBaseMax'],5),
      round(p['nativeVsPlayerStyleMax'],5),f(n['lookupRgb']),f(h['mipshadow-lut']))
(out/'face-edge-sampling-summary.json').write_text(json.dumps(dict(status='source-attribution',rows=rows),indent=2)+'\n')

