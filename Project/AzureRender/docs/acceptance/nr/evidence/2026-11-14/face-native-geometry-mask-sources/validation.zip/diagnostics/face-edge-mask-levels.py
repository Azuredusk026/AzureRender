from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import struct
import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
g=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
stage=g/'native-face-skin-stages'
read=lambda p:json.loads(p.read_bytes())
receipt=read(stage/'results.json')
geometry=receipt['geometry']['804']
assert geometry['vertexStride']==116 and geometry['indexStride']==2 and geometry['baseVertex']==0
raw=(stage/'vertex-804.bin').read_bytes(); inds=(stage/'index-804.bin').read_bytes()
assert sha256(raw).hexdigest()==geometry['vertexSha256'] and sha256(inds).hexdigest()==geometry['indexSha256']
v=np.frombuffer(raw,'<f4').reshape(-1,29)
idx=np.frombuffer(inds,'<u2').reshape(-1,3)
mips=[]
for row in receipt['faceTextures']['20']['levels']:
    data=(stage/row['path']).read_bytes()
    assert sha256(data).hexdigest()==row['sha256'] and len(data)==row['size']
    size=256>>len(mips)
    h=b'DDS '+struct.pack('<31I',124,0x81007,size,size,len(data),0,1,*([0]*11),32,4,0x30315844,0,0,0,0,0,0x1000,0,0,0,0)
    with Image.open(BytesIO(h+struct.pack('<5I',98,3,0,1,0)+data)) as im:
        mips.append(np.asarray(im.convert('RGBA'))/255.)
assert len(mips)==9

def bilinear(tex,uv):
    pixels=uv*tex.shape[0]-.5
    base=np.floor(pixels).astype('i8')
    f=np.rint((pixels-base)*256)/256
    s=np.zeros(4)
    for x,y in ((0,0),(1,0),(0,1),(1,1)):
        sx,sy=np.clip(base+[x,y],0,tex.shape[0]-1)
        s+=tex[sy,sx]*(f[0] if x else 1-f[0])*(f[1] if y else 1-f[1])
    return s

report=[]
for row in read(out/'face-edge-sampling-summary.json')['rows']:
    point=np.asarray(row['screen'])+.5
    tri=v[idx[row['primitive']]].astype(float)
    pos=tri[:,:4]
    screen=np.rint((pos[:,:2]/pos[:,3,None]+1)*[1280,720]*256)/256
    a,b,c=screen
    basis=np.linalg.inv(np.stack((b-a,c-a),axis=1))
    def sample_uv(p):
        bary=basis@(p-a)
        weights=np.r_[1-bary.sum(),bary]/pos[:,3]
        return (weights@tri[:,4:6])/weights.sum(),float(min(bary.min(),1-bary.sum()))
    uv,inside=sample_uv(point)
    assert inside>=-.01
    host=np.asarray(row['player']['mipuv'][:2])
    host[1]=1-host[1]
    assert np.abs(host-uv).max()<.001
    native=np.asarray(row['native']['rgbaStyle'])
    hostMask=np.asarray(row['player']['mipmask'])
    m=[bilinear(tex,uv) for tex in mips]
    full=np.asarray([np.max(np.abs(native-x)) for x in m])
    withoutA=np.asarray([np.max(np.abs(native[:3]-x[:3])) for x in m])
    expectedHost=float(np.max(np.abs(m[0][:3]-hostMask)))
    lod=float(np.log2(256*max(np.linalg.norm(sample_uv(point+offset)[0]-uv) for offset in ([1,0],[0,1]))))
    report.append(dict(point=row['screen'],nativeUv=uv.tolist(),hostUv=host.tolist(),estimatedLod=lod,
            nativeRgba=native.tolist(),hostMask=hostMask.tolist(),exactAtMipZeroVsHost=expectedHost,
            rgbaMaxError=full.tolist(),rgbMaxError=withoutA.tolist(),bestNativeLevel=int(full.argmin())))
result=dict(status='source-attribution',rows=report)
(out/'face-edge-mask-levels.json').write_text(json.dumps(result,indent=2)+'\n')
for r in report:print(r['point'],round(r['estimatedLod'],3),round(r['exactAtMipZeroVsHost'],4),r['bestNativeLevel'],[round(f,4) for f in r['rgbaMaxError'][:6]])

