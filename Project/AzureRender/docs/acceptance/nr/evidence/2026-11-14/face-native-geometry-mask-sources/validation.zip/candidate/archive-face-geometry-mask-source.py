from hashlib import file_digest
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

out=Path(__file__).resolve().parent
q=out.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
g=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
source=g/'native-face-skin-stages'
read=lambda p:json.loads(p.read_bytes())

def sha(path):
    with path.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()

sampling=read(q/'face-edge-mask-levels.json')
trace=read(q/'face-edge-sampling-summary.json')
assert len(sampling['rows'])==len(trace['rows'])==12
rows=[]
for data,stat in zip(sampling['rows'],trace['rows']):
    level=data['bestNativeLevel']
    assert data['point']==stat['screen']
    assert round(data['estimatedLod']-1)==level
    rows.append(dict(point=data['point'],primitive=stat['primitive'],nativeMip=level,
         estimatedLod=data['estimatedLod'],nativeRgbaError=data['rgbaMaxError'][level],
         playerMipZeroRgbError=data['exactAtMipZeroVsHost'],nativeMaskGreen=data['nativeRgba'][1],
         playerMaskGreen=data['hostMask'][1]))
peak=max(r['nativeRgbaError'] for r in rows)
host=max(r['playerMipZeroRgbError'] for r in rows)
assert peak<.001 and host<.002
assert {r['nativeMip'] for r in rows}=={1,2,3}
replay=read(q/'face-edge-vulkan-sampling/results.json')
assert replay['status']=='qualified'
entry,=replay['events']
assert entry['event']==876
assert entry['selection']['baseline']==entry['selection']['copy']==entry['selection']['restored']
members={}
for file in ('face-edge-mask-levels.py','face-edge-mask-levels.json','face-edge-native-sampling.json',
             'face-edge-sampling.py','face-edge-sampling-summary.json','face-edge-sampling-request.json',
             'summarize-face-edge-sampling.py','face-edge-vulkan-sampling/results.json',
             'face-edge-vulkan-sampling/request.json','face-residual-replay.json'):
    members[f'diagnostics/{file}']=q/file
for file in (q/'face-edge-vulkan-sampling').glob('*-direct.bin'):
    members[f'diagnostics/face-edge-vulkan-sampling/{file.name}']=file
capture=read(source/'results.json')
texture=capture['faceTextures']['20']
assert texture['width']==texture['height']==256 and len(texture['levels'])==9
for mip in texture['levels']:
    path=source/mip['path']
    assert sha(path)==mip['sha256']
    members[f'native/{path.name}']=path
for filename in ('pixel-804.txt','vertex-804.bin','index-804.bin','results.json'):
    members[f'native/{filename}']=source/filename
assert 'sample_b' in (source/'pixel-804.txt').read_text()
for filename in ('face-geometry-mask-actual.py',Path(__file__).name,'assets/prepared.json'):
    members[f'candidate/{filename}']=out/filename
assert all(p.is_file() for p in members.values())
folder=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/face-native-geometry-mask-sources'
folder.mkdir(parents=True,exist_ok=False)
archive=folder/'validation.zip'
with ZipFile(archive,'x',ZIP_DEFLATED) as zipfile:
    for key,path in members.items():zipfile.write(path,key)
with ZipFile(archive) as zipfile:
    assert len(zipfile.namelist())==len(members) and zipfile.testzip() is None
result=dict(overallStatus='failed-user-review',observation='source-attribution',
    originalEvent=804,playerEvent=876,nativeMaskSlot=20,nativeMipBias=-1,
    peakNativeRgbaError=peak,peakPlayerMipZeroError=host,rows=rows,
    archive=dict(sha256=sha(archive),members=len(members)))
(folder/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(result['archive'],peak,host)
