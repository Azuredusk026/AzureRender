from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import subprocess
import traceback

out=Path(os.environ['AZURE_NR_FACE_EDGE_OUTPUT']) if 'AZURE_NR_FACE_EDGE_OUTPUT' in os.environ else Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')

def native_worker():
    import renderdoc as rd
    data=read(out/'face-edge-sampling-request.json')
    cap=rd.OpenCaptureFile()
    ctl=None
    r=dict(status='failed',rows=[])
    try:
        assert cap.OpenFile(data['native'],'',None)==rd.ResultCode.Succeeded
        options=rd.ReplayOptions();options.forceGPUVendor=rd.GPUVendor.nVidia;options.forceGPUDeviceID=0x28e0
        state,ctl=cap.OpenCapture(options,None)
        assert state==rd.ResultCode.Succeeded and ctl
        props=ctl.GetAPIProperties()
        assert props.vendor==rd.GPUVendor.nVidia and props.pipelineType==rd.GraphicsAPI.D3D11 and not props.degraded
        ctl.SetFrameEvent(804,True)
        fragment=ctl.GetPipelineState().GetShaderReflection(rd.ShaderStage.Fragment)
        assert sha256(bytes(fragment.rawBytes)).hexdigest()==data['nativeShader']
        targets={32,33,47,48,50,51,52,58,68,69,70,75,76,370,371,435,438,748,749,1500,1580,1650}
        for point in data['nativePoints']:
            x,y=point['point']
            args=rd.DebugPixelInputs();args.primitive=point['primitive']
            trace=ctl.DebugPixel(x,1439-y,args)
            assert trace and trace.debugger,(x,y)
            regs={}; selected={}; count=0
            try:
                while True:
                    batch=ctl.ContinueDebug(trace.debugger)
                    if not batch:break
                    for instruction in batch:
                        for change in instruction.changes:
                            a=change.after
                            if a.name:regs[a.name]=list(a.value.f32v)[:4]
                        k=int(instruction.nextInstruction)
                        if k in targets:
                            selected[k]={name:v for name,v in regs.items() if name in ('v0','v1','v2','v3','r5','r10','r11','r12','r13','r17','o0')}
                        count+=1
                    assert count<20000
            finally:ctl.FreeTrace(trace)
            assert all(k in selected for k in (33,52,69,70,76)),(x,y,sorted(selected))
            r['rows'].append(dict(point=point,registers=selected,steps=count))
        r['status']='qualified'
    except Exception:r['error']=traceback.format_exc()
    finally:
        if ctl:ctl.Shutdown()
        cap.Shutdown()
        write(out/'face-edge-native-sampling.json',r)
    os._exit(0 if r['status']=='qualified' else 1)

def launch():
    from hashlib import file_digest
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==out
    last=read(out/'face-native-lanes-summary.json')
    req=read(grid/'native-face-masks/request.json')
    with Path(req['native']).open('rb') as f:assert file_digest(f,'sha256').hexdigest()==req['captureSha256']
    req['nativeShader']=read(grid/'native-face-skin-stages/results.json')['geometry']['804']['pixelShaderSha256']
    req['nativePoints']=last['faceBaseOwners']['native']['points']
    write(out/'face-edge-sampling-request.json',req)
    folder=out/'face-edge-vulkan-sampling'
    folder.mkdir(exist_ok=True)
    assert not (folder/'results.json').exists()
    probe=read(grid/'face-material-sampling-replay/request.json')
    with Path(probe['capture']).open('rb') as f:
        assert file_digest(f,'sha256').hexdigest()=='6960267c0d71e4d05b6bfe0e2730c332ed71955f1fde6d69eb7d8aadf13eff24'
    order=folder/'points.bin'
    order.write_bytes(b''.join(struct.pack('<II',*r['point']) for r in req['nativePoints']))
    probe['points']=str(order)
    write(folder/'request.json',probe)
    exe='D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe'
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    env=os.environ.copy()
    with (out/'face-edge-native-sampling.log').open('wb') as log:
        c=subprocess.run([exe,'--python',str(Path(__file__))],cwd=out,startupinfo=startup,stdout=log,stderr=subprocess.STDOUT,
            env=dict(env,AZURE_NR_FACE_EDGE_OUTPUT=str(out)),timeout=170)
    r=read(out/'face-edge-native-sampling.json')
    assert c.returncode==0 and r['status']=='qualified',r.get('error')
    with (folder/'replay.log').open('wb') as log:
        c=subprocess.run([exe,'--python',str(grid/'face-material-sampling-worker.py')],cwd=folder,startupinfo=startup,stdout=log,stderr=subprocess.STDOUT,
            env=dict(env,AZURE_ENGINE_IRIS_MIP_REPLAY=str(folder),VK_DRIVER_FILES=str(grid/'nv-vk64-active-absolute.json')),timeout=230)
    r=read(folder/'results.json')
    assert c.returncode==0 and r['status']=='qualified',r.get('error')

if 'AZURE_NR_FACE_EDGE_OUTPUT' in os.environ:native_worker()
elif __name__=='__main__':launch()

