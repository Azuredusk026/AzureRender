from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import traceback

out = Path(os.environ['AZURE_NR_CLOTH_TRACE_OUTPUT']) if 'AZURE_NR_CLOTH_TRACE_OUTPUT' in os.environ else Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read = lambda path: json.loads(path.read_bytes())
write = lambda path, data: path.write_text(json.dumps(data, indent=2)+'\n', encoding='utf8')

def worker():
    import renderdoc as rd
    cap = rd.OpenCaptureFile()
    ctl = None
    result = dict(status='failed', points=[])
    job = read(out/'cloth-normal-trace-request.json')
    try:
        assert cap.OpenFile(job['native'],'',None)==rd.ResultCode.Succeeded
        opt = rd.ReplayOptions()
        opt.forceGPUVendor = rd.GPUVendor.nVidia
        opt.forceGPUDeviceID = 0x28e0
        status, ctl = cap.OpenCapture(opt, None)
        assert status == rd.ResultCode.Succeeded and ctl
        p = ctl.GetAPIProperties()
        assert p.vendor==rd.GPUVendor.nVidia and not p.degraded and p.pipelineType==rd.GraphicsAPI.D3D11
        ctl.SetFrameEvent(1383, True)
        pipe = ctl.GetPipelineState()
        stage = rd.ShaderStage.Fragment
        reflection = pipe.GetShaderReflection(stage)
        assert sha256(bytes(reflection.rawBytes)).hexdigest()==job['shaderSha256']
        i, = (i for i,b in enumerate(reflection.constantBlocks) if b.fixedBindNumber==6)
        d = pipe.GetConstantBlock(stage,i,0).descriptor
        cb = bytes(ctl.GetBufferData(d.resource,d.byteOffset,d.byteSize))
        (out/'cloth-normal-trace-cb6.bin').write_bytes(cb)
        result['cb6Sha256'] = sha256(cb).hexdigest()
        steps = {28,29,30,31,35,36,37,44,47,53,54,55,57,58,900,901,902,903,904,905,
                 906,907,908,913,914,927,936,940,944,947,953,957,968,969,970,971,1504,1505,2158,2169}
        for sample in job['points']:
            x,y = sample['x'],sample['y']
            args=rd.DebugPixelInputs(); args.primitive=sample['primitive']
            trace=ctl.DebugPixel(x,1439-y,args)
            assert trace and trace.debugger,(x,y)
            regs={}
            states={}
            count=0
            try:
                while True:
                    batch=ctl.ContinueDebug(trace.debugger)
                    if not batch: break
                    for event in batch:
                        for change in event.changes:
                            v=change.after
                            if v.name: regs[v.name]=list(v.value.f32v)[:4]
                        i=int(event.nextInstruction)
                        if i in steps:
                            states[i]={key:value for key,value in regs.items() if key.startswith(('v','o')) or key in
                                       ('r2','r3','r4','r6','r8','r9','r10','r12','r13','r14','r16','r17')}
                        count+=1
                    assert count<20000
            finally:
                ctl.FreeTrace(trace)
            for i in (29,54,971,1505,2169):
                assert i in states,(x,y,i,sorted(states))
            result['points'].append(dict(sample=sample,states=states,steps=count))
        result['status']='qualified'
    except Exception:
        result['error']=traceback.format_exc()
    finally:
        if ctl: ctl.Shutdown()
        cap.Shutdown()
        write(out/'cloth-normal-trace.json',result)
    os._exit(0 if result['status']=='qualified' else 1)

def launch():
    from hashlib import file_digest
    lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==out
    job=read(grid/'native-face-masks/request.json')
    with Path(job['native']).open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==job['captureSha256']
    job['points']=[r for r in read(grid/'native-face-cloth-full-trace/results.json')['samples'] if r['event']==1383]
    job['shaderSha256']=read(grid/'native-face-skin-stages/results.json')['geometry']['1383']['pixelShaderSha256']
    assert len(job['points'])==3
    write(out/'cloth-normal-trace-request.json',job)
    startup=subprocess.STARTUPINFO()
    startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=0
    with (out/'cloth-normal-trace.log').open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__))],
            cwd=out,env=dict(os.environ,AZURE_NR_CLOTH_TRACE_OUTPUT=str(out)),stdout=log,
            stderr=subprocess.STDOUT,startupinfo=startup,timeout=150)
    receipt=read(out/'cloth-normal-trace.json')
    assert child.returncode==0 and receipt['status']=='qualified',receipt.get('error')

if 'AZURE_NR_CLOTH_TRACE_OUTPUT' in os.environ: worker()
elif __name__=='__main__': launch()

