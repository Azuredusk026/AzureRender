from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
geometry=read(out/'cloth-normal-geometry.json')
trace=read(out/'cloth-normal-trace.json')
assert trace['status']=='qualified' and len(geometry['points'])==3
assert digest(out/'cloth-normal-trace-cb6.bin')==trace['cb6Sha256']
summary=[dict(point=r['point'],primitive=r['primitive'],isotropicLod=r['isotropicLod'],**r['trace']) for r in geometry['points']]
assert [r['selectedMip'] for r in summary]==[0,1,0]
assert [r['isFrontFace'] for r in summary]==[False,False,True]
assert all(not r['detailApplied'] and r['baseToRimAngle']<.032 and r['selectedBaseNormalAngularError']<.46 for r in summary)
source=grid/'native-cloth-authored-textures'
assets=read(source/'results.json')['textures']['21']
assert len(assets['levels'])==12
members={name:out/name for name in (Path(__file__).name,'cloth-normal-trace.py','cloth-normal-trace.json',
    'cloth-normal-trace-request.json','cloth-normal-trace-cb6.bin','cloth-normal-geometry.py','cloth-normal-geometry.json')}
members['source/texture-manifest.json']=source/'results.json'
for event in ('vertex-1383.bin','index-1383.bin'):
    members[f'source/{event}']=grid/'native-face-skin-stages'/event
for row in assets['levels']:
    path=source/row['path']
    assert digest(path)==row['sha256']
    members[f'source/{path.name}']=path
dest=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/transparent-cloth-normal-source'
dest.mkdir(parents=True,exist_ok=False)
archive=dest/'validation.zip'
with ZipFile(archive,'x',ZIP_DEFLATED) as z:
    for key,path in members.items():z.write(path,key)
with ZipFile(archive) as z:assert z.testzip() is None and len(z.namelist())==len(members)
result=dict(overallStatus='failed-user-review',evidenceType='native-shader-trace',event=1383,
    normalResource={'binding':21,'format':'BC5_UNORM','mipCount':12},points=summary,
    archive=dict(sha256=digest(archive),members=len(members)))
(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(result['archive'])
