from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import struct

import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
normal_stage=grid/'native-cloth-authored-textures'
rt=read(normal_stage/'results.json')['textures']['21']
stage=grid/'native-face-skin-stages'
geometry=read(stage/'results.json')['geometry']['1383']
traces=read(grid/'native-face-cloth-full-trace/results.json')['samples']
vraw=(stage/'vertex-1383.bin').read_bytes()
iraw=(stage/'index-1383.bin').read_bytes()
assert sha256(vraw).hexdigest()==geometry['vertexSha256']
assert sha256(iraw).hexdigest()==geometry['indexSha256']
assert geometry['vertexStride']==116 and geometry['indexStride']==2 and geometry['baseVertex']==0
assert rt['format']=='BC5_UNORM' and rt['width']==rt['height']==2048
mesh=np.frombuffer(vraw,'<f4').reshape(-1,29)
indices=np.frombuffer(iraw,'<u2').reshape(-1,3)
assert len(indices)*3==geometry['indices']
textures=[]
for m in rt['levels']:
    data=(normal_stage/m['path']).read_bytes()
    size=max(1,rt['width']>>m['mip'])
    assert len(data)==m['bytes'] and sha256(data).hexdigest()==m['sha256']
    header=b'DDS '+struct.pack('<31I',124,0x81007,size,size,len(data),0,1,*([0]*11),32,4,0x30315844,0,0,0,0,0,0x1000,0,0,0,0)
    with Image.open(BytesIO(header+struct.pack('<5I',83,3,0,1,0)+data)) as img:
        textures.append(np.asarray(img.convert('RGB'))[...,:2]/255.0)
assert len(textures)==12

def sample(texture, uv):
    size=texture.shape[0]
    sample=uv*size-.5
    linear=sample-np.floor(sample)
    fraction=np.rint(linear*256)/256
    start=np.floor(sample).astype('i8')
    result=np.zeros(2)
    for dx,dy in ((0,0),(0,1),(1,0),(1,1)):
        tx,ty=(start+[dx,dy]) % size
        result+=texture[ty,tx]*(fraction[0] if dx else 1-fraction[0])*(fraction[1] if dy else 1-fraction[1])
    return result

def normalized(v):
    return v/np.linalg.norm(v)

rows=[]
source=out/'cloth-normal-trace.json'
trace={}
if source.is_file():
    r=read(source)
    if r['status']=='qualified':
        trace={(row['sample']['x'],row['sample']['y']):row['states'] for row in r['points']}
        cbytes=(out/'cloth-normal-trace-cb6.bin').read_bytes()
        assert sha256(cbytes).hexdigest()==r['cb6Sha256']
        constants=np.frombuffer(cbytes,'<f4').reshape(-1,4)
for s in traces:
    if s['event']!=1383:continue
    x,y=s['x'],s['y']
    tri=mesh[indices[s['primitive']]].astype(float)
    clip=tri[:,:4]
    screen=(clip[:,:2]/clip[:,3,None]+1)*[1280,720]
    fixed=np.rint(screen*256)/256
    a,b,c=fixed
    inv=np.linalg.inv(np.stack((b-a,c-a),axis=1))
    def varying(point):
        b12=inv@(np.asarray(point)-a)
        bary=np.array([1-b12.sum(),*b12])
        weights=bary/clip[:,3]
        w=weights.sum()
        return (weights@tri/w),bary
    frag,bary=varying([x+.5,y+.5])
    assert np.min(bary)>=-.002,(x,y,bary)
    dx=(varying([x+1.5,y+.5])[0]-frag)[4:6]
    dy=(varying([x+.5,y+1.5])[0]-frag)[4:6]
    uv,N,T=frag[4:6],frag[9:12],frag[12:16]
    B=np.cross(N,T[:3])*T[3]
    sraw=grid/'native-face-cloth-full-trace'/s['file']
    sr=sraw.read_bytes()
    assert sha256(sr).hexdigest()==s['sha256']
    native=np.asarray(json.loads(sr)['1505']['r12'][1:])
    row=dict(point=[x,y],primitive=s['primitive'],barycentric=bary.tolist(),uv=uv.tolist(),
             normal=N.tolist(),tangent=T.tolist(),bitangent=B.tolist(),rimNormal=native.tolist(),
             derivatives=[dx.tolist(),dy.tolist()],isotropicLod=float(np.log2(max(np.linalg.norm(dx),np.linalg.norm(dy))*2048)))
    select=[]
    for mip,tex in enumerate(textures):
        texel=sample(tex,uv)
        xy=texel*2-1
        z=np.sqrt(max(0,1-np.dot(xy,xy)))
        est=normalized(T[:3]*xy[0]+B*xy[1]+N*z)
        select.append(dict(mip=mip,rg=texel.tolist(),normal=est.tolist(),
                           degreesFromRim=float(np.degrees(np.arccos(np.clip(np.dot(est,native),-1,1))))))
    row['levelCandidates']=select
    if (x,y) in trace:
        states=trace[x,y]
        actualBase=np.asarray(states['54']['r10'][:3])
        actualRim=np.asarray(states['971']['r12'][1:])
        assert np.max(np.abs(actualRim-native))<2e-6
        double_area=float((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))
        assert abs(double_area)>.01
        # Projected positions are in a bottom-left viewport; this draw treats
        # counter-clockwise winding in that coordinate system as front-facing.
        sign=1 if double_area>0 else -1
        for opt in select:
            texel=np.asarray(opt['rg'])
            native_sample=np.asarray(states['29']['r8'][:2])
            xy=texel*2-1
            z=np.sqrt(max(0,1-np.dot(xy,xy)))
            est=sign*normalized(constants[0,3]*(T[:3]*xy[0]+B*xy[1])+N*z)
            opt.update(sampleMaxError=float(np.max(np.abs(texel-native_sample))),
                       baseNormal=est.tolist(),baseNormalAngularError=float(np.degrees(np.arccos(np.clip(np.dot(est,actualBase),-1,1)))))
        selected=min(select,key=lambda lane:lane['sampleMaxError'])
        assert selected['mip']==int(round(row['isotropicLod']-1) if row['isotropicLod']>1 else 0)
        assert selected['baseNormalAngularError']<.5 and selected['sampleMaxError']<.003
        row['trace']=dict(shaderSample=native_sample.tolist(),baseNormal=actualBase.tolist(),normalIntensity=float(constants[0,3]),isFrontFace=sign==1,signedDoubleArea=double_area,
            selectedMip=selected['mip'],selectedSampleMaxError=selected['sampleMaxError'],selectedBaseNormalAngularError=selected['baseNormalAngularError'],
            detailApplied='957' in states,baseToRimAngle=float(np.degrees(np.arccos(np.clip(np.dot(actualBase,actualRim),-1,1)))))
    rows.append(row)
assert len(rows)==3
(out/'cloth-normal-geometry.json').write_text(json.dumps(dict(status='source-attribution',points=rows),indent=2)+'\n')
for row in rows:
    options=sorted(row['levelCandidates'],key=lambda q:q.get('sampleMaxError',q['degreesFromRim']))[:3]
    print(row['point'], row['isotropicLod'], [(q['mip'],q.get('sampleMaxError'),q['degreesFromRim']) for q in options],row.get('trace'))

