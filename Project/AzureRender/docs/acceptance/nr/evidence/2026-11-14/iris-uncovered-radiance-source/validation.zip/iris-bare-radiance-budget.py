from hashlib import sha256
from pathlib import Path
import json
import runpy

import numpy as np

out=Path(__file__).resolve().parent
g=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
pack=runpy.run_path(str(out/'iris-mipmap-attribution.py'))
native,display,vulkan=(pack[k] for k in ('native','display','vulkan'))
points=pack['points']
bare=pack['bare']
target=pack['original']
baseline=vulkan('engine-iris-lod-bias','baseline')[:,:3]
historical=read(g/'native-iris-bottom-history/results.json')
assert historical['status']=='qualified'
latest={}
for row in historical['shaderSamples']:
    latest[row['x'],row['y']]=row
assert all(tuple(p) in latest for p in points)
fromTrace=np.array([latest[tuple(p)]['shaderOut'][:3] for p in points])*.25
fromPack=np.array([latest[tuple(p)]['post'][:3] for p in points])*.25
assert np.array_equal(fromPack,target)
before=np.abs(display(baseline)-display(target)).max(1)
remaining=bare&(before>1)
assert remaining.sum()==37
eligible=np.array([not any(latest[tuple(p)][key] for key in ('depthFailed','stencilFailed')) for p in points])
assert eligible[remaining].all()
data=[]
for i in np.flatnonzero(remaining):
    point=points[i].tolist()
    mips=np.flatnonzero(pack['match'][:,i]).tolist()
    row=dict(point=point,primitive=latest[tuple(point)]['primitive'],nativeMip=mips,
       nativeUnpacked=fromTrace[i].tolist(),nativeStored=target[i].tolist(),playerStored=baseline[i].tolist(),
       nativePackingRgb=(fromTrace[i]-target[i]).tolist(),shaderRgbDelta=(baseline[i]-fromTrace[i]).tolist(),
       signedByteDelta=(display(baseline)[i]-display(target)[i]).tolist(),byteError=int(before[i]))
    data.append(row)
data.sort(key=lambda p:-p['byteError'])
raw=np.abs(display(fromTrace)-display(target)).max(1)
noQuant=np.abs(display(fromTrace)-display(baseline)).max(1)
assert int(raw[remaining].max())<=2
intensity=np.asarray([row['shaderRgbDelta'] for row in data])
result=dict(status='source-attribution',samples=int(remaining.sum()),nativePackingDisplayPeak=int(raw[remaining].max()),
    aboveOneWithoutNativePacking=int((noQuant[bare&eligible]>1).sum()),withoutPackingEligible=int((bare&eligible).sum()),
    linearRgbDeltaMedian=np.median(intensity,axis=0).tolist(),
    worstThreeLod=[row['nativeMip'] for row in data[:3]],worst=data[:12],rows=data,
    nativeHistorySha256=sha256((g/'native-iris-bottom-history/results.json').read_bytes()).hexdigest())
(out/'iris-bare-radiance-budget.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(aboveOneWithoutNativePacking=result['aboveOneWithoutNativePacking'],packingPeak=result['nativePackingDisplayPeak'],witnesses=data[:3])))
