from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
result=read(out/'iris-bare-radiance-budget.json')
assert (result['samples'],result['nativePackingDisplayPeak'],result['aboveOneWithoutNativePacking'])==(37,2,38)
assert result['withoutPackingEligible']==159 and result['worstThreeLod']==[[4],[4],[4]]
assert result['worst'][0]['byteError']==20
members={p:out/p for p in (Path(__file__).name,'iris-bare-radiance-budget.py','iris-mipmap-attribution.py','iris-mipmap-attribution.json')}
archive_paths=('native-iris-stages/points.bin','native-iris-stages/event-846.bin','native-iris-stages/event-1230.bin',
    'native-iris-stages/event-1245.bin','native-iris-bottom-history/results.json')
for p in archive_paths:members[f'grid/{p}']=grid/p
assert digest(members['grid/native-iris-bottom-history/results.json'])==result['nativeHistorySha256']
for folder,labels in [('engine-iris-lod-bias',('baseline','miplod','mip5','mip6')),('engine-iris-explicit-mips',('mip4','mip5')),
                      ('engine-iris-lod-boundary',('mip-0.01','mip0.01','mip0.02'))]:
    members[f'grid/{folder}/results.json']=grid/folder/'results.json'
    for label in labels:
        filename=f'897-{label}-direct.bin'
        members[f'grid/{folder}/{filename}']=grid/folder/filename
members['grid/iris-explicit-mips/iris-explicit-mips.json']=grid/'iris-explicit-mips/iris-explicit-mips.json'
for i in range(10):
    filename=f'nvidia-mip-{i:02d}.bin'
    members[f'grid/iris-explicit-mips/{filename}']=grid/'iris-explicit-mips'/filename
assert all(p.is_file() for p in members.values())
dest=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/iris-uncovered-radiance-source'
dest.mkdir(parents=True,exist_ok=False)
archive=dest/'validation.zip'
with ZipFile(archive,'x',ZIP_DEFLATED) as z:
    for key,p in members.items():z.write(p,key)
with ZipFile(archive) as z:assert len(z.namelist())==len(members) and z.testzip() is None
result.update(overallStatus='failed-user-review',archive=dict(sha256=digest(archive),members=len(members)))
(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(result['archive'])
