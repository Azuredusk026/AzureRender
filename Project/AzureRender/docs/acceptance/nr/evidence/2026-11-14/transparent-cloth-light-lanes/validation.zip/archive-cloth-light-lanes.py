from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
trace=read(grid/'native-face-cloth-full-trace/results.json')
content=read(out/'cloth-native-light-lanes.json')
rows=content['rows']
assert content['status']=='qualified-native-lanes' and len(rows)==3
assert max(abs(x) for r in rows for a in r['native']['nativeLightRim'] for x in a)==0
assert max(abs(x) for r in rows for x in r['native']['postExposureAndFog'])<5e-9
assert max(abs(x) for r in rows for x in r['native']['traceHardwareDelta'])<.002
assert [round(r['native']['materialRim'][0],4) for r in rows]==[.1216,.1216,.0571]
members={p:out/p for p in (Path(__file__).name,'analyze-cloth-native-lanes.py','cloth-native-light-lanes.json')}
for p in ('cloth-color-adjustment-source.json','skin-residual-points.bin','native-face-cloth-full-trace/results.json',
          'engine-cloth-components/results.json'):
    members[f'grid/{p}']=grid/p
for row in trace['samples']:
    if row['event']!=1383:continue
    path=f"native-face-cloth-full-trace/{row['file']}"
    assert digest(grid/path)==row['sha256']
    members[f'grid/{path}']=grid/path
for label in ('mipbase','mipnormal','mipspecular','mipdiffuse','mipenvironment','miprim','mipemission','baseline'):
    p=f'engine-cloth-components/967-{label}-direct.bin'
    members[f'grid/{p}']=grid/p
dest=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/transparent-cloth-light-lanes'
dest.mkdir(parents=True,exist_ok=False)
with ZipFile(dest/'validation.zip','x',ZIP_DEFLATED) as z:
    for name,path in members.items():z.write(path,name)
with ZipFile(dest/'validation.zip') as z:assert len(z.namelist())==len(members) and z.testzip() is None
content.update(overallStatus='failed-user-review',archive=dict(members=len(members),sha256=digest(dest/'validation.zip')))
(dest/'results.json').write_text(json.dumps(content,indent=2)+'\n',encoding='utf8')
print(content['archive'])
