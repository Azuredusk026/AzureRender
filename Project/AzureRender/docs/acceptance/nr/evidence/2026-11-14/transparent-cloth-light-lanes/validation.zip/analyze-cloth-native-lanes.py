from hashlib import sha256
from pathlib import Path
import json
import numpy as np

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
source=grid/'native-face-cloth-full-trace'
read=lambda p:json.loads(p.read_bytes())
trace=read(source/'results.json')
assert trace['status']=='qualified'
inputs=read(grid/'cloth-color-adjustment-source.json')
points=np.fromfile(grid/'skin-residual-points.bin','<u4').reshape(-1,2)
lanes={}
for label in ('base','normal','specular','diffuse','environment','rim','emission','baseline'):
    prefix='mip' if label!='baseline' else ''
    p=grid/f'engine-cloth-components/967-{prefix}{label}-direct.bin'
    lanes[label]=np.fromfile(p,'<f2').reshape(-1,4).astype(float)
    assert len(lanes[label])==len(points)

def split(s):
    state=read(source/s['file'])
    assert sha256((source/s['file']).read_bytes()).hexdigest()==s['sha256']
    S=lambda no,r:np.asarray(state[str(no)][r])
    r=next(v for v in inputs if [v['x'],v['y']]==[s['x'],s['y']])
    p=float(S(1470,'r11')[3])
    unlitDiffuse=S(1471,'r23')[:3]*p
    spec=S(1483,'r10')[:3]
    assert np.max(np.abs(unlitDiffuse+spec-S(1484,'r10')[:3]))<1e-6
    postSat=S(1549,'r10')[:3]
    directional1=S(1564,'r6')[1:]
    secondaryTint=S(1568,'r20')[[0,2,3]]
    directional2=directional1*secondaryTint-directional1
    directional3=S(1601,'r18')[:3]
    directional=directional1+directional2+directional3
    assert np.max(np.abs(postSat+directional-S(1603,'r6')[1:]))<1e-6
    reflection=S(1629,'r16')[:3]*S(1629,'r15')[:3]
    assert np.max(np.abs(postSat+directional+reflection-S(1630,'r6')[1:]))<1e-6
    local=S(2147,'r16')[:3]-S(1640,'r16')[:3]
    decoded=np.asarray(r['colorAdjustmentContribution'])
    output=postSat+directional+reflection+local
    assert np.max(np.abs(output-S(2147,'r16')[:3]))<1e-6
    row=int(np.where((points==[s['x'],s['y']]).all(1))[0][0])
    host={k:v[row,:3].tolist() for k,v in lanes.items()}
    preFog=.25*(output+4*decoded)
    tracedHdr=.25*S(2350,'o0')[:3]
    assert S(2350,'o0')[3]==s['hardware'][3]
    hardwareHdr=np.asarray(s['hardware'][:3])*.25
    return dict(point=[s['x'],s['y']],native=dict(diffuse=(.25*unlitDiffuse).tolist(),
        mainSpecular=(.25*spec).tolist(),saturationDelta=(.25*(postSat-unlitDiffuse-spec)).tolist(),
        nativeLightRim=[(.25*v).tolist() for v in (directional1,directional2,directional3)],
        indirectSpecular=(.25*reflection).tolist(),local=(.25*local).tolist(),
        materialRim=decoded.tolist(),postExposureAndFog=(tracedHdr-preFog).tolist(),
        tracedOutput=tracedHdr.tolist(),hardwareOutput=hardwareHdr.tolist(),traceHardwareDelta=(tracedHdr-hardwareHdr).tolist()),
        playerRawLanes=host)

rows=[split(row) for row in trace['samples'] if row['event']==1383]
assert len(rows)==3
(out/'cloth-native-light-lanes.json').write_text(json.dumps(dict(status='qualified-native-lanes',rows=rows),indent=2)+'\n',
                                                  encoding='utf8')
print(json.dumps(rows))
