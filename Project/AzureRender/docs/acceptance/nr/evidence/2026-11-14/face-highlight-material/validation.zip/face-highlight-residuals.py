from pathlib import Path
import json,runpy
import numpy as np
from PIL import Image
import cv2

out=Path(__file__).resolve().parent
run=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
score=runpy.run_path(str(run/'static-quality.py'))
ref=score['image'](score['reference_path']).astype(np.int16)
mask=np.asarray(Image.open(run/'native-face-masks/face.png').convert('L'))
mask=cv2.erode(mask,np.ones((13,13),np.uint8))>0
def stats(delta):
    return dict(minimum=delta.min(0).tolist(),maximum=delta.max(0).tolist(),mean=delta.mean(0).tolist(),
        median=np.median(delta,0).tolist(),perChannelOverOne=(np.abs(delta)>1).sum(0).tolist(),
        histogram=[{str(int(v)):int(n) for v,n in zip(*np.unique(channel,return_counts=True))} for channel in delta.T])
result={}
for device in ('nvidia','intel'):
    result[device]={}
    for mode in ('reference','highlight'):
        image=score['image'](out/f'production/{device}-{mode}/frames/frame_000000.png').astype(np.int16)
        result[device][mode]=stats((image-ref)[mask])
(out/'production-face-residuals.json').write_text(json.dumps(result,indent=2)+'\n')
print({dev:row['highlight']['median'] for dev,row in result.items()})
