from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from hashlib import sha256
import json,subprocess

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
roots={c:out.parent/p for c,p in [('Release','20261110-030251-hair-main-chroma-public-9e799c/release'),
    ('Debug','20261110-031856-hair-main-chroma-debug-668bf2/debug')]}
previous=json.loads((grid/'cloth-color-adjustment-build-fingerprint.json').read_bytes())['catalog']
catalog={c:{p.name:sha256(p.read_bytes()).hexdigest() for p in (root/'shaders').glob('*.spv')} for c,root in roots.items()}
assert len(catalog['Release'])==895 and catalog['Release']==catalog['Debug']
rules=json.loads((roots['Release']/'shader-reload.json').read_bytes())['programs']
affected=sorted(name for name,value in catalog['Release'].items() if previous[name]!=value)
light={row['output'] for row in rules if 'AZURE_EXTENDED_MATERIAL_LIGHTING=1' in row['defines']}
assert affected and set(affected)<=light
validator='D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe'
def check(name):
    p=subprocess.run([validator,'--target-env','vulkan1.3','--relax-block-layout',str(roots['Release']/'shaders'/name)],capture_output=True,text=True)
    return dict(program=name,exitCode=p.returncode,diagnostic=p.stderr+p.stdout)
with ThreadPoolExecutor(max_workers=5) as pool: results=list(pool.map(check,affected))
assert all(v['exitCode']==0 for v in results),[r for r in results if r['exitCode']][:3]
record=dict(programs=len(catalog['Release']),affected=len(affected),validation=results,
    player={key:sha256((p/'AzurePlayer.exe').read_bytes()).hexdigest() for key,p in roots.items()})
(out/'production-build-fingerprints.json').write_text(json.dumps(record,indent=2)+'\n')
print('Programs',record['programs'],'validated',len(results))
