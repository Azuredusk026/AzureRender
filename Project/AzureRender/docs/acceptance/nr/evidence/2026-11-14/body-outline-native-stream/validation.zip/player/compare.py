from hashlib import file_digest, sha256
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5
import json
import runpy
import struct

import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent
grid = out.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
root = grid / 'iris-overlay-geometry-project'
inputs = grid / 'native-body-outline-input-retest'
stages = grid / 'native-face-skin-stages'
helpers = runpy.run_path(str(grid / 'iris-production-frozen-recovery.py'))
read, dump, invoke = (helpers[k] for k in ('read', 'dump', 'invoke'))
receipt = read(inputs / 'results.json')
assert receipt['status'] == 'qualified'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def uid(name):
    return str(uuid5(NAMESPACE_URL, 'azurerender/body-outline-native-stream/' + name))


def make_mesh():
    source = root / 'character/captured-opaque-overlays.glb'
    native = read(stages / 'results.json')['geometry']
    name = 'body-outline-native-geometry.glb'
    with source.open('rb') as file:
        magic, version, _, json_length, json_type = struct.unpack('<5I', file.read(20))
        assert (magic, version, json_type) == (0x46546C67, 2, 0x4E4F534A)
        document = json.loads(file.read(json_length))
        size, kind = struct.unpack('<2I', file.read(8))
        assert kind == 0x004E4942
        buffer = file.read(size)
        assert len(buffer) == size
    assert len(document['buffers']) == 1 and size % 4 == 0
    meshes = [p for mesh in document['meshes'] for p in mesh['primitives']
              if document['materials'][p['material']]['name'] == 'M_actor_laevat_body_01']
    prim, = meshes

    def attr(name, width):
        access = document['accessors'][prim['attributes'][name]]
        view = document['bufferViews'][access['bufferView']]
        return np.ndarray((access['count'], width), dtype='<f4', buffer=buffer,
                          offset=view.get('byteOffset', 0) + access.get('byteOffset', 0),
                          strides=(view.get('byteStride', 4 * width), 4)).astype(float)

    normal = attr('NORMAL', 3)
    tangent = attr('TANGENT', 4)
    length = len(normal)
    assert length == 3289 and 'TEXCOORD_1' not in prim['attributes']
    stream = next(row for row in receipt['bindings'] if row['index'] == 1)
    path = inputs / stream['path']
    assert digest(path) == stream['sha256'] and stream['stride'] == 12
    coordinates = np.fromfile(path, 'i1').reshape(-1, stream['stride'])[:length, 8:10].astype('<f4') / 127
    assert (np.abs(coordinates) <= 1).all()
    assert np.array_equal(attr('TEXCOORD_0', 2), np.fromfile(stages / 'vertex-1018.bin', '<f4')
                          .reshape(-1, native['1018']['vertexStride'] // 4)[:, 4:6])
    transformed = np.fromfile(stages / 'vertex-1018.bin', '<f4').reshape(-1, native['1018']['vertexStride'] // 4)
    bitangent = np.cross(normal, tangent[:, :3]) * tangent[:, 3, None]
    direction = (tangent[:, :3] * coordinates[:, 0, None] + bitangent * coordinates[:, 1, None]
                 + normal * np.sqrt(1 - (coordinates.astype(float) ** 2).sum(1))[:, None])
    smooth_error = np.linalg.norm(direction - transformed[:, 9:12] * [-1, 1, 1], axis=1)
    assert smooth_error.max() < 1e-7, smooth_error.max()
    document['bufferViews'].append(dict(buffer=0, byteOffset=size, byteLength=coordinates.nbytes))
    prim['attributes']['TEXCOORD_1'] = len(document['accessors'])
    document['accessors'].append(dict(bufferView=len(document['bufferViews']) - 1, componentType=5126,
                                      count=length, type='VEC2'))
    document['buffers'][0]['byteLength'] = size + coordinates.nbytes
    updated = json.dumps(document, ensure_ascii=True, separators=(',', ':')).encode('ascii')
    updated += b' ' * (-len(updated) % 4)
    target = out / name
    with target.open('wb') as file:
        file.write(struct.pack('<5I', magic, version, 28 + len(updated) + size + coordinates.nbytes,
                               len(updated), json_type))
        file.write(updated)
        file.write(struct.pack('<2I', size + coordinates.nbytes, kind))
        file.write(buffer)
        file.write(coordinates.tobytes())
    return target, dict(vertices=length, sourceSha256=digest(source), targetSha256=digest(target),
                        coordinateSha256=sha256(coordinates.tobytes()).hexdigest(),
                        directionMaximumError=float(smooth_error.max()))


def make_project(model, mask, mode, color, depth_prepass):
    suffix = f'body-outline-native-{mode}'
    level = read(root / 'scene/static-eye-shadow-production.azurelevel')
    resource = next(item for item in level['resources'] if item['id'] == 'hero')
    resource['asset'] = 'character:/' + model.name
    hero = next(n for n in level['nodes'] if n['id'] == 'hero')
    slot = 'name:M_actor_laevat_body_01'
    spec = read(root / 'materials' / f"{hero['materialSlots'][slot]}.azurematerial")
    profile = spec['surface']['materials'][0]['extras']['azureRenderMaterial']
    binding = np.fromfile(inputs / 'outline-1018-cb3.bin', '<f4').reshape(-1, 4)
    viewport = np.fromfile(inputs / 'outline-1018-cb1.bin', '<f4').reshape(-1, 4)
    assert binding[15, 0] == 1
    width, depth, brightness, saturation = map(float, binding[14])
    if color == 'marker':
        colors = [.04, 4, .04]
    else:
        colors = [brightness] * 3
    outline = dict(schemaVersion=1, mode='view-scaled', width=width, minimumPixels=.5,
                   depthOffset=.1 * depth, color=colors, coverage='depth-tested', depthPrepass=depth_prepass,
                   normalSource='geometry' if mode=='geometry' else 'tangent-uv1')
    assert np.allclose(viewport[1, :2] * viewport[1, 2:], 1)
    if color != 'marker':
        outline['baseColorSaturation'] = saturation
    profile['outlineSurface'] = outline
    texture_index = len(spec['surface']['textures'])
    image_index = len(spec['textures'])
    spec['textures'][str(image_index)] = {'asset': mask, 'usage': 'linear'}
    spec['surface']['textures'].append({'source': image_index})
    outline['maskTexture'] = texture_index
    path = root / 'materials' / f'{suffix}.azurematerial'
    dump(path, spec)
    dump(path.with_suffix('.azurematerial.azmeta'), dict(schemaVersion=1, id=uid(suffix), dependencies=[], settings={}))
    hero['materialSlots'][slot] = uid(suffix)
    dump(root / 'scene' / f'{suffix}.azurelevel', level)
    project = read(root / 'eye-shadow-production.azureproject')
    project['startupScene'] = f'stage:/{suffix}.azurelevel'
    path = root / f'{suffix}.azureproject'
    dump(path, project)
    return path, outline


def run():
    lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state'] == 'held' and Path(lock['output']) == out
    target, mesh = make_mesh()
    link = root / 'character' / target.name
    link.hardlink_to(target)
    meta = link.with_suffix('.glb.azmeta')
    try:
        dump(meta, dict(schemaVersion=1, id=uid(target.name), dependencies=[], settings={}))
        shape = (1440, 2560, 2)
        depth = grid / 'native-body-outline-depth'
        before = np.fromfile(depth / 'depth-1017.bin', '<u4').reshape(shape)[::-1]
        after = np.fromfile(depth / 'depth-1018.bin', '<u4').reshape(shape)[::-1]
        coverage = before[:, :, 0] != after[:, :, 0]
        assert int(coverage.sum()) == 1184
        owner = read(grid / 'face-skin-overlay-ownership.json')['skin']['1018']['locations']
        x, y = np.array(owner).T
        assert len(x) == 61 and coverage[y,x].all()
        score = runpy.run_path(str(grid / 'static-quality.py'))
        image = lambda p: score['image'](p).astype(np.int16)
        reference = image(score['reference_path'])
        report = dict(mesh=mesh, nativeCoverage=int(coverage.sum()), devices={})
        mask = root / 'materials/body-outline-native-mask.png'
        Image.new('RGBA', (1, 1), (255, 255, 0, 255)).save(mask)
        mask_id = uid(mask.name)
        dump(mask.with_suffix('.png.azmeta'), dict(schemaVersion=1, id=mask_id, dependencies=[], settings=dict(texture=dict(
            schemaVersion=1, usage='linear', colorSpace='linear', wrapU='clamp', wrapV='clamp',
            filter='linear', mipPolicy='none', anisotropy=1, mipBias=0))))
        projects = {mode: make_project(link, mask_id, mode, color, use_depth) for mode,color,use_depth in
                    [('geometry','marker',False), ('smooth','marker',False), ('authored','authored',True)]}
        for device in ('nvidia', 'intel'):
            row = report['devices'][device] = {}
            baseline = image(grid / f'cloth-production-color-adjustment-retest/{device}-static-baseline/frames/frame_000000.png')
            old = np.abs(baseline-reference).max(2)
            for mode, (project, profile) in projects.items():
                path = out / f'{device}-{mode}'
                path.mkdir()
                command = read(grid / f'static-{device}-command.json')
                for flag,value in (('--project',project),('--capture-dir',path/'frames')):
                    command[command.index(flag)+1] = str(value)
                frame = invoke(device,command,path)/'frame_000000.png'
                actual = image(frame)
                marker = (actual[:,:,1]>245)&(actual[:,:,0]<60)&(actual[:,:,2]<60)
                err = np.abs(actual-reference).max(2)
                row[mode] = dict(profile=profile, frameSha256=digest(frame), green=int(marker.sum()),
                                 nativeOverlap=int((marker & coverage).sum()), focusOverlap=int(marker[y,x].sum()),
                                 focusOverOne=int((err[y,x]>1).sum()), focusPeak=int(err[y,x].max()),
                                 focusImproved=int((err[y,x]<old[y,x]).sum()),
                                 newFrameOverOne=int(((old<=1)&(err>1)).sum()),
                                 frameOverOne=int((err>1).sum()), baselineFrameOverOne=int((old>1).sum()))
                (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
    finally:
        if link.exists() and link.samefile(target):
            link.unlink()
        if meta.is_file() and read(meta)['id'] == uid(target.name):
            meta.unlink()


if __name__ == '__main__':
    run()
