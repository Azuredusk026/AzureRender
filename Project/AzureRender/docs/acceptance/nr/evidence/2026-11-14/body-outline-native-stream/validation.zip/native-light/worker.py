from hashlib import sha256
from pathlib import Path
import json
import os
import traceback

import renderdoc as rd

output = Path(os.environ['AZURE_NR_OUTLINE_SHADING'])
request = json.loads((output/'request.json').read_bytes())
capture = rd.OpenCaptureFile()
controller = None
report = dict(status='failed', samples=[], resources={}, constants={})
try:
    assert capture.OpenFile(request['native'], '', None) == rd.ResultCode.Succeeded
    options = rd.ReplayOptions()
    options.forceGPUVendor = rd.GPUVendor.nVidia
    options.forceGPUDeviceID = 0x28e0
    status, controller = capture.OpenCapture(options, None)
    assert status == rd.ResultCode.Succeeded and controller
    assert controller.GetAPIProperties().vendor == rd.GPUVendor.nVidia
    controller.SetFrameEvent(1018, True)
    pipeline = controller.GetPipelineState()
    fragment = rd.ShaderStage.Fragment
    reflection = pipeline.GetShaderReflection(fragment)
    for slot in pipeline.GetReadOnlyResources(fragment):
        binding = reflection.readOnlyResources[slot.access.index].fixedBindNumber
        report['resources'][binding] = dict(resource=str(slot.descriptor.resource), format=slot.descriptor.format.Name())
    for index, block in enumerate(reflection.constantBlocks):
        desc = pipeline.GetConstantBlock(fragment,index,0).descriptor
        if desc.resource == rd.ResourceId.Null():
            continue
        if block.fixedBindNumber in (0, 1, 6):
            raw = bytes(controller.GetBufferData(desc.resource, desc.byteOffset, desc.byteSize))
            path = output/f'ps-cb{block.fixedBindNumber}.bin'
            path.write_bytes(raw)
            report['constants'][block.fixedBindNumber] = dict(bytes=len(raw), path=path.name, sha256=sha256(raw).hexdigest())
    for item in request['points']:
        x, y = item['x'], item['y']
        inputs = rd.DebugPixelInputs()
        inputs.primitive = item['primitive']
        trace = controller.DebugPixel(x, 1439-y, inputs)
        assert trace and trace.debugger, (x,y)
        registers, states = {}, {}
        steps = 0
        try:
            while True:
                batch = controller.ContinueDebug(trace.debugger)
                if not batch:
                    break
                for entry in batch:
                    for change in entry.changes:
                        row = change.after
                        if row.name:
                            registers[row.name] = list(row.value.f32v)[:4]
                    step = int(entry.nextInstruction)
                    states[step] = {key: value for key, value in registers.items() if key.startswith(('v','r','o'))}
                    steps += 1
                assert steps < 20000
        finally:
            controller.FreeTrace(trace)
        name = f'1018-{x}-{y}.json'
        payload = (json.dumps(states, separators=(',', ':')) + '\n').encode()
        (output/name).write_bytes(payload)
        report['samples'].append(dict(x=x,y=y,primitive=item['primitive'],hardware=item['shaderOut'],
                                      steps=steps, path=name, sha256=sha256(payload).hexdigest()))
    report['status'] = 'qualified'
except Exception:
    report['error'] = traceback.format_exc()
finally:
    if controller:
        controller.Shutdown()
    capture.Shutdown()
    (output/'native-results.json').write_text(json.dumps(report, indent=2) + '\n')
os._exit(0 if report['status']=='qualified' else 1)
