from hashlib import file_digest
from pathlib import Path
import json
import os
import subprocess

output = Path(__file__).resolve().parent
grid = output.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
lock = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state'] == 'held' and Path(lock['output']) == output
request = json.loads((grid / 'native-face-masks/request.json').read_bytes())
with Path(request['native']).open('rb') as stream:
    assert file_digest(stream, 'sha256').hexdigest() == request['captureSha256']
points = json.loads((grid/'native-face-skin-stages/results.json').read_bytes())['history']['skin-outline']
positions = [(1270,1037), (1270,1047), (1270,1053), (1270,1054)]
request['points'] = [next(row for row in points if (row['x'], row['y']) == point) for point in positions]
(output/'request.json').write_text(json.dumps(request, indent=2)+'\n')
environment = os.environ.copy()
environment['AZURE_NR_OUTLINE_SHADING'] = str(output)
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
with (output/'replay.log').open('wb') as log:
    replay = subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe', '--python', str(output/'worker.py')],
                            cwd=output, env=environment, stdout=log, stderr=subprocess.STDOUT,
                            startupinfo=startup, timeout=460)
report = json.loads((output/'native-results.json').read_bytes())
assert replay.returncode == 0 and report['status'] == 'qualified', report
