"""Read kernel wait chains for the exact descendant launched by the diagnostic."""
import ctypes as c
from ctypes import wintypes as w
from pathlib import Path


class ThreadEntry(c.Structure):
    _fields_=[('size',w.DWORD),('usage',w.DWORD),('id',w.DWORD),('pid',w.DWORD),
              ('priority',w.LONG),('delta',w.LONG),('flags',w.DWORD)]


class LockObject(c.Structure):
    _fields_=[('name',w.WCHAR*128),('timeout',c.c_int64),('alertable',w.BOOL)]


class ThreadObject(c.Structure):
    _fields_=[('pid',w.DWORD),('id',w.DWORD),('wait',w.DWORD),('switches',w.DWORD)]


class Body(c.Union):
    _fields_=[('lock',LockObject),('thread',ThreadObject)]


class Node(c.Structure):
    _fields_=[('kind',w.DWORD),('status',w.DWORD),('body',Body)]


kernel=c.WinDLL('kernel32',use_last_error=True)
advapi=c.WinDLL('advapi32',use_last_error=True)
kernel.CreateToolhelp32Snapshot.argtypes=(w.DWORD,w.DWORD)
kernel.CreateToolhelp32Snapshot.restype=w.HANDLE
kernel.Thread32First.argtypes=(w.HANDLE,c.POINTER(ThreadEntry))
kernel.Thread32Next.argtypes=(w.HANDLE,c.POINTER(ThreadEntry))
kernel.GetProcessTimes.argtypes=(w.HANDLE,)+(c.POINTER(w.FILETIME),)*4
kernel.GetThreadTimes.argtypes=(w.HANDLE,)+(c.POINTER(w.FILETIME),)*4
kernel.OpenThread.argtypes=(w.DWORD,w.BOOL,w.DWORD)
kernel.OpenThread.restype=w.HANDLE
kernel.CloseHandle.argtypes=(w.HANDLE,)
advapi.OpenThreadWaitChainSession.argtypes=(w.DWORD,c.c_void_p)
advapi.OpenThreadWaitChainSession.restype=w.HANDLE
advapi.CloseThreadWaitChainSession.argtypes=(w.HANDLE,)
advapi.GetThreadWaitChain.argtypes=(w.HANDLE,c.c_size_t,w.DWORD,w.DWORD,c.POINTER(w.DWORD),c.POINTER(Node),c.POINTER(w.BOOL))


def times(method,handle):
    samples=[w.FILETIME() for _ in range(4)]
    if not method(handle,*(c.byref(value) for value in samples)):
        return None
    return [value.dwHighDateTime<<32|value.dwLowDateTime for value in samples]


def chains(process):
    token=kernel.CreateToolhelp32Snapshot(4,0)
    if token==c.c_void_p(-1).value:
        raise c.WinError(c.get_last_error())
    details=[]
    try:
        entry=ThreadEntry(size=c.sizeof(ThreadEntry))
        ok=kernel.Thread32First(token,c.byref(entry))
        while ok:
            if entry.pid==process.pid:
                handle=kernel.OpenThread(0x800,False,entry.id)
                if handle:
                    try:
                        row=times(kernel.GetThreadTimes,handle)
                        if row:details.append((entry.id,row))
                    finally:kernel.CloseHandle(handle)
            ok=kernel.Thread32Next(token,c.byref(entry))
    finally:kernel.CloseHandle(token)
    rows=[]
    session=advapi.OpenThreadWaitChainSession(0,None)
    if not session:
        raise c.WinError(c.get_last_error())
    try:
        details.sort(key=lambda item:item[1][0])
        focus=details[:2]+[item for item in sorted(details[2:],key=lambda item:sum(item[1][2:]),reverse=True)[:4]]
        for tid,row in focus:
            cycle=w.BOOL(); count=w.DWORD(16); nodes=(Node*16)()
            valid=advapi.GetThreadWaitChain(session,0,0,tid,c.byref(count),nodes,c.byref(cycle))
            summary={'tid':tid,'ageOrder':next(i for i,item in enumerate(details) if item[0]==tid),
                     'kernelCpuMs':row[2]/10000,'userCpuMs':row[3]/10000}
            if valid:
                summary['cycle']=bool(cycle.value)
                summary['nodes']=[{'kind':n.kind,'status':n.status,**({'pid':n.body.thread.pid,'tid':n.body.thread.id} if n.kind==8 else {})} for n in nodes[:count.value]]
            else:summary['win32Error']=c.get_last_error()
            rows.append(summary)
    finally:advapi.CloseThreadWaitChainSession(session)
    pt=times(kernel.GetProcessTimes,int(process._handle))
    return {'pid':process.pid,'threads':len(details),'processCpuMs':sum(pt[2:])/10000 if pt else None,'waitChains':rows}
