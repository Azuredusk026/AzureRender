"""Pair scene timing from two completed material-radiance runs by exact frame."""
from pathlib import Path
from statistics import median
import hashlib,json,re,sys

from replay_pipeline_environment import normalized,baseline,previous

phases=('CPU preparation','shared textures','buffers','skinning','descriptors','pipelines')
def identity(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def make_report():
    rows=[]
    for original in sorted(baseline.parent.glob('*/player.log')):
        a=original.parent;b=previous.parent/a.name
        frame=Path('frames/frame_000000.png')
        if not (b/frame).is_file():continue
        assert identity(a/frame)==identity(b/frame),a.name
        assert normalized(a,json.loads((a/'command.json').read_bytes()))==normalized(b,json.loads((b/'command.json').read_bytes())),a.name
        timings={}
        for name in phases:
            pair=[]
            for d in (a,b):
                s=(d/'player.log').read_text(encoding='utf-8',errors='replace')
                assert 'Validation layer: enabled' in s and 'Allocator after unload: buffers=0 images=0' in s,a.name
                [value]=re.findall(r'Scene load '+re.escape(name)+r': (\d+\.\d+) ms',s)
                pair.append(float(value))
            assert pair[0]>0 and pair[1]>0
            timings[name]={'candidateMs':pair[0],'registeredMs':pair[1]}
        rows.append({'name':a.name,'frameSha256':identity(a/frame),'phases':timings,
                     'sourceLogsSha256':[identity(d/'player.log') for d in (a,b)]})
    assert len(rows)==34,len(rows)
    result={}
    for name in phases:
        pairs=[r['phases'][name] for r in rows]
        result[name]={'candidateMedianMs':median(p['candidateMs'] for p in pairs),
                      'registeredMedianMs':median(p['registeredMs'] for p in pairs),
                      'medianPairRatio':median(p['registeredMs']/p['candidateMs'] for p in pairs)}
    return {'validation':'enabled','pairedCases':len(rows),'phaseMedians':result,'cases':rows}

if __name__=='__main__':
    report=make_report()
    assert 3.9<report['phaseMedians']['pipelines']['medianPairRatio']<4.1
    assert all(.9<r['medianPairRatio']<1.11 for k,r in report['phaseMedians'].items() if k!='pipelines')
    to=Path(sys.argv[1])
    with to.open('x',encoding='utf-8') as f:f.write(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report['phaseMedians'],indent=2))
