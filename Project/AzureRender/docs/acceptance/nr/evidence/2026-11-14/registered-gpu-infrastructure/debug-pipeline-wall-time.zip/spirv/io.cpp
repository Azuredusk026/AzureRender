
#include <filesystem>
#include <fstream>
#include <string>
#include <chrono>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <algorithm>
#include <cstdint>
#include <cstdlib>
std::string read(const std::filesystem::path& path){
    std::ifstream input(path,std::ios::binary);
    if(!input)throw std::runtime_error("Shader input unavailable: "+path.u8string());
    return {std::istreambuf_iterator<char>(input),std::istreambuf_iterator<char>()};
}
std::string readBlocks(const std::filesystem::path& path){
    std::ifstream input(path,std::ios::binary|std::ios::ate);
    const auto length=input.tellg();
    if(length<0)throw std::runtime_error("Cannot size shader input");
    std::string value(static_cast<std::size_t>(length),'\0');
    input.seekg(0);
    if(!input.read(value.data(),static_cast<std::streamsize>(length))||
       input.peek()!=std::char_traits<char>::eof())throw std::runtime_error("Shader input changed");
    return value;
}
int main(int argc,char** argv){
    if(argc!=2)return 1;
    std::vector<std::filesystem::path> files;
    for(const auto& entry:std::filesystem::directory_iterator(argv[1])) if(entry.is_regular_file()&&entry.path().extension()==".spv")files.push_back(entry.path());
    std::sort(files.begin(),files.end());
    if(files.size()!=897)return 2;
    std::size_t count=0,bytes=0;
    double baseline=0,blocks=0;
    for(const auto& entry:files){
        const auto runRead=[&](auto function,double& milliseconds) {
            const auto start=std::chrono::steady_clock::now();
            auto value=function(entry);
            milliseconds+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
            return value;
        };
        auto a=count%2?runRead(read,baseline):runRead(readBlocks,blocks);
        auto b=count%2?runRead(readBlocks,blocks):runRead(read,baseline);
        if(a!=b)return 3;
        ++count;bytes+=a.size();
    }
    std::cout<<"rows="<<count<<" bytes="<<bytes<<" baseline_ms="<<baseline<<" block_ms="<<blocks<<" exact=yes\n";
}
