"""Attribute the current Debug host timeout to observed stages without inferring cause."""
from pathlib import Path
import hashlib
import json
import re
import sqlite3

root=Path(__file__).resolve().parent
run=root.parent/'20261114-173220-nr-shader-host-compiler-concurrency-d140b8'
cases=(
    ('original-bootstrap',648,'debug-baseline-bootstrap-diagnostics/workflow/exploration','wait-idle'),
    ('candidate-host',642,'debug-candidate-host-2/workflow/exploration','first-developer-query'),
    ('candidate-previews',652,'debug-candidate-devtools/workflow/exploration','preview-create'),
)


def evidence(path):
    return dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def read(path):
    return json.loads(path.read_bytes())


def line_time(line):
    assert (match:=re.match(r'^\[(\d+)\]',line)),line
    return int(match[1])


data={}
with sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True) as db:
    for name,job,location,timeout in cases:
        folder=run/location
        log=folder/'stderr.log'
        lines=log.read_text(encoding='utf-8').splitlines()
        dev=line_time(next(line for line in lines if 'Completed developer views' in line))
        segments=[]
        seg=None
        for line in lines:
            if 'Scene load CPU preparation:' in line:
                seg={'startEpochMs':line_time(line),'afterDeveloperInitialization':line_time(line)>dev}
                segments.append(seg)
            if seg is None:continue
            for label in ('descriptors','pipelines'):
                if (match:=re.search(fr'Scene load {label}: (\d+\.\d+) ms',line)):
                    seg[label]={'elapsed':float(match[1]),'endEpochMs':line_time(line)}
        assert segments and segments[0]['pipelines']
        if name in ('original-bootstrap','candidate-previews'):
            assert len(segments)>=2 and segments[-1]['afterDeveloperInitialization'] and 'descriptors' in segments[-1] and 'pipelines' not in segments[-1]
        files=[log]
        if job==648:
            diag=run/'debug-baseline-bootstrap-diagnostics'
            receipt=diag/'receipt.json'
            records=diag/'operations-observed.jsonl'
            operations=[json.loads(row) for row in records.read_text(encoding='utf-8').splitlines()]
            assert read(receipt)['fixtureExitCode']==1 and operations[-1]['request']['equals']=='Idle' and 'error' in operations[-1]
            common={x['request'].get('name'):x for x in operations if x['request'].get('op')=='query'}
            assert common['engine.frameCount']['value']==7 and common['engine.status']['passed']
            programs=sorted((folder/'candidates/2/binary').glob('*.spv'))
            assert len(programs)==897
            specs=read(folder/'reload.json')
            source=Path(specs['binaryRoot'])
            matches=sum(
                hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256((source/p.name).read_bytes()).digest()
                for p in programs)
            assert matches==897
            files += [receipt,records,diag/'host-observed.jsonl']
        else:
            fixture=(folder.parent.parent/'case.log')
            assert 'TimeoutError: timed out' in fixture.read_text(encoding='utf-8')
            files += [fixture,folder/'operations.json'] if (folder/'operations.json').is_file() else [fixture]
        state=db.execute('select id,state,exit_code,task from jobs where id=?',(job,)).fetchone()
        assert state[:3]==(job,'succeeded' if job==648 else 'failed',0 if job==648 else 1)
        data[name]={'dispatch':state,'timeoutStage':timeout,'segments':segments,
                    'lastLogEpochMs':line_time(lines[-1]),'evidence':[evidence(p) for p in files]}
data['original-bootstrap']['sameCandidateBinaries']=matches
(root/'debug-host-pipeline-boundaries.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print({k: {'timeout':d['timeoutStage'],'stageRows':d['segments']} for k,d in data.items()})
