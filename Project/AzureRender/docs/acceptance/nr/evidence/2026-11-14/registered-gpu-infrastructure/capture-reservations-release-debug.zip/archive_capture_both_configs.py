"""Archive the unchanged registered commands and verified candidate results."""
from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import hashlib
import json
import subprocess
import sys


root=Path.cwd().resolve()
run=Path(__file__).resolve().parent
stage=run/'capture-reservation-candidate'
out=root/'docs/acceptance/nr/evidence/2026-11-14/registered-gpu-infrastructure'
subprocess.run([sys.executable,'-B','-X','utf8',str(run/'validate_capture_reservation_finish.py')],cwd=root,check=True)
receipt=run/'capture-reservation-both-configurations-attribution.json'
attestation=json.loads(receipt.read_bytes())
assert attestation['casesPerConfiguration']==17 and attestation['candidateOnly']
assert attestation['registrationUnchanged']
files={p.relative_to(run).as_posix():p for p in [
    receipt, Path(__file__), run/'test_capture_regression_reservations.py',run/'run_capture_reservation_candidate.py',
    run/'validate_capture_reservation_finish.py',run/'remaining-transitive-reservation-scan.json',
    stage/'observed-reservations.json',stage/'patch.diff',stage/'candidate-validation-complete.json']}
for group in attestation['groups']:
    path=run/group['receipt']
    files[group['receipt']]=path
    assert len(group['cases'])==len(group['observedManagedRuns'])
    for name in group['cases']:
        log=path.parent/(name+'.log')
        files[log.relative_to(run).as_posix()]=log
assert len(files)==47
package=out/'capture-reservations-release-debug.zip'
assert not package.exists()
manifest={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in sorted(files.items())}
with ZipFile(package,'x',compression=ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in sorted(files.items()):
        info=ZipInfo(name,(2026,11,14,0,0,0));info.compress_type=ZIP_DEFLATED
        archive.writestr(info,path.read_bytes())
    info=ZipInfo('member-sha256.json',(2026,11,14,0,0,0));info.compress_type=ZIP_DEFLATED
    archive.writestr(info,json.dumps(manifest,indent=2)+'\n')
with ZipFile(package) as archive:
    assert archive.testzip() is None and len(archive.infolist())==len(files)+1
    assert json.loads(archive.read('member-sha256.json'))==manifest
    assert all(hashlib.sha256(archive.read(n)).hexdigest()==sha for n,sha in manifest.items())
out_summary=out/'capture-reservations-release-debug.json'
record={'archive':{'sizeBytes':package.stat().st_size,'members':len(files)+1,'sha256':hashlib.sha256(package.read_bytes()).hexdigest()},
        'passed':{'Release':17,'Debug':17},'registrationUnchanged':True,'candidateOnly':True,
        'driver':'NVIDIA 595.79','jobs':{g['config']+'-'+g['group']:g['job'] for g in attestation['groups']}}
with out_summary.open('x',encoding='utf-8') as f:
    json.dump(record,f,indent=2);f.write('\n')
print(package,record,flush=True)
