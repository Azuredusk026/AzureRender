"""Replay the registered material case with normalized paths, observing inherited setup."""
from pathlib import Path
import ctypes,hashlib,json,os,re,shutil,subprocess,sys,time
from ctypes import wintypes

root=Path.cwd().resolve(); run=Path(__file__).resolve().parent
build=root/'build/ninja-msvc-debug'
baseline=run.parent/'20261114-202509-material-radiance-gpu-a13ec2/capture/npr-control'
previous=run.parent/'20261114-221941-material-radiance-gpu-b6f21b/capture/npr-control'
validation_cache='shader_validation_cache.bin'
warm_source=run.parent/'20261114-132114-nr-current-registered-regression-16567f'/'tmp'/validation_cache
driver_cache=root/'build/cache/vulkan/vk1-10de-28e0-94d3c000-e5fd15ff5cca63387021a49388fd1dc4-33d51d00297b927c.azpc'

def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def normalized(input_dir,row):
    result=list(row)
    result[0]=Path(result[0]).name
    return [value.replace(str(input_dir),'$CASE') for value in result]

def metadata(source):
    rows=[json.loads(x) for x in (source/'captures/azureplayer.log.jsonl').read_bytes().splitlines()]
    messages=[row['message'] for row in rows]
    assert 'Validation layer: enabled' in messages
    assert 'Allocator after unload: buffers=0 images=0' in messages
    assert not any(x['level']=='error' or x['subsystem']=='validation' and x['level']=='warning' for x in rows)
    starts=[re.fullmatch(r'Scene load pipelines: (\d+\.\d+) ms',m) for m in messages]
    [ms]=[float(x[1]) for x in starts if x]
    cache=[m for m in messages if m.startswith('Pipeline cache ')]
    return {'ms':ms,'cache':cache,'captureSha256':digest(source/'frames/frame_000000.png')}

class PowerState(ctypes.Structure):
    _fields_=[('version',wintypes.ULONG),('controlMask',wintypes.ULONG),('stateMask',wintypes.ULONG)]

def process_snapshot(process):
    if os.name!='nt':return {}
    win=ctypes.WinDLL('kernel32',use_last_error=True)
    win.OpenProcess.argtypes=(wintypes.DWORD,wintypes.BOOL,wintypes.DWORD)
    win.OpenProcess.restype=wintypes.HANDLE
    win.CloseHandle.argtypes=(wintypes.HANDLE,)
    win.GetPriorityClass.argtypes=(wintypes.HANDLE,)
    win.GetProcessInformation.argtypes=(wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD)
    win.GetProcessAffinityMask.argtypes=(wintypes.HANDLE,ctypes.c_void_p,ctypes.c_void_p)
    win.GetProcessTimes.argtypes=(wintypes.HANDLE,*([ctypes.c_void_p]*4))
    handle=win.OpenProcess(0x1000,False,process.pid)
    if not handle:return {'sampleError':ctypes.get_last_error()}
    row={}
    try:
        row['priorityClass']=win.GetPriorityClass(handle)
        power=PowerState(1,0,0)
        if win.GetProcessInformation(handle,4,ctypes.byref(power),ctypes.sizeof(power)):
            row['powerThrottling']={'controlMask':power.controlMask,'stateMask':power.stateMask}
        else:row['powerThrottlingError']=ctypes.get_last_error()
        affinity,machine=ctypes.c_size_t(),ctypes.c_size_t()
        if win.GetProcessAffinityMask(handle,ctypes.byref(affinity),ctypes.byref(machine)):
            row['affinity']=hex(affinity.value);row['systemAffinity']=hex(machine.value)
        creation,exited,kernel,user=[wintypes.FILETIME() for _ in range(4)]
        if win.GetProcessTimes(handle,ctypes.byref(creation),ctypes.byref(exited),ctypes.byref(kernel),ctypes.byref(user)):
            row['cpuMs']={key:((value.dwHighDateTime<<32)|value.dwLowDateTime)/10000
                          for key,value in (('kernel',kernel),('user',user))}
        return row
    finally:win.CloseHandle(handle)

def main():
    out=run/'debug-pipeline-environment-replay';out.mkdir()
    source_command=json.loads((baseline/'command.json').read_bytes())
    original_command=json.loads((previous/'command.json').read_bytes())
    assert normalized(baseline,source_command)==normalized(previous,original_command)
    base,prior=metadata(baseline),metadata(previous)
    original=Path(source_command[0]);assert original==(build/'AzurePlayer.exe')
    original_sha=digest(original);assert original_sha=='a8e0ce254171a1248571cb07f4fb5fc6f9909e8327a192587d3c28b0cf05d9f2'
    assert base['captureSha256']==prior['captureSha256']
    inputs={p.relative_to(baseline):digest(p) for p in baseline.iterdir() if p.is_file() and p.suffix in ('.gltf','.png','.azureproject','.azurelevel','.json') and p.name not in ('command.json','runtime.json')}
    assert inputs and all(digest(previous/n)==sha for n,sha in inputs.items())
    probe_env=os.environ|{'PATH':os.pathsep.join((str(build),'D:/Tools/dotnet9',os.environ['PATH'])),'VK_LOADER_DRIVERS_SELECT':'*nv-vk64*'}
    for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES','VK_LAYER_VALIDATE_SYNC','AZURE_DISABLE_COMPUTED_MATERIAL_VIEW'):
        probe_env.pop(key,None)
    warm_seed=warm_source.read_bytes()
    assert len(warm_seed)==816 and hashlib.sha256(warm_seed).hexdigest()=='3bfc0cac32c01373d75717b7c186e65ccc163d00a4558fcc122cb9b58543b90c'
    observations={}
    for i,mode in enumerate(('warm','cold','cold','warm'),1):
        lane=out/(f'{i}-{mode}');lane.mkdir();(lane/'tmp').mkdir()
        for name,sha in inputs.items():
            target=lane/name;shutil.copyfile(baseline/name,target);assert digest(target)==sha
        env=probe_env|{name:str(lane/'tmp') for name in ('TMP','TEMP','TMPDIR','SQLITE_TMPDIR')}
        cache=lane/'tmp'/validation_cache
        if mode=='warm':cache.write_bytes(warm_seed)
        assert cache.is_file()==(mode=='warm')
        starting_cache=digest(cache) if cache.is_file() else None
        before_driver=digest(driver_cache) if driver_cache.is_file() else None
        cmd=[value.replace(str(baseline),str(lane)) for value in source_command]
        start=time.monotonic()
        process_info=[]
        with (lane/'player.log').open('xb') as f:
            with subprocess.Popen(cmd,cwd=lane,env=env,stdout=f,stderr=subprocess.STDOUT) as player:
                try:
                    while True:
                        process_info.append({'sinceStartSeconds':time.monotonic()-start}|process_snapshot(player))
                        remaining=80-(time.monotonic()-start)
                        if remaining<=0:raise subprocess.TimeoutExpired(cmd,80)
                        try:
                            rc=player.wait(timeout=min(2,remaining))
                            if rc:raise subprocess.CalledProcessError(rc,cmd)
                            break
                        except subprocess.TimeoutExpired:
                            continue
                except BaseException:
                    player.kill()
                    raise
        assert cache.is_file() and cache.stat().st_size>=40
        observations[lane.name]=metadata(lane)|{'wholeSeconds':time.monotonic()-start,
            'syncFlag':env.get('VK_LAYER_VALIDATE_SYNC'),'playerProcess':process_info,
            'startingValidationCacheSha256':starting_cache,'endingValidationCacheSha256':digest(cache),
            'endingValidationCacheBytes':cache.stat().st_size,'startingDriverCacheSha256':before_driver,
            'endingDriverCacheSha256':digest(driver_cache) if driver_cache.is_file() else None}
        assert observations[lane.name]['captureSha256']==base['captureSha256']
    assert digest(original)==original_sha and warm_source.read_bytes()==warm_seed
    report={'command':normalized(baseline,source_command),'binarySha256':original_sha,
            'warmValidationCacheSource':str(warm_source),'earlier':base,'main':prior,'observed':observations}
    (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report),flush=True)

if __name__=='__main__':main()
