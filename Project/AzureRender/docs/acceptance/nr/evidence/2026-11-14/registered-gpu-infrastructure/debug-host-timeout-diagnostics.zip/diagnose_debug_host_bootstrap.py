"""Separate editor progress from the first developer query at the existing deadlines."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time


run=Path(__file__).resolve().parent
root=Path.cwd().resolve()
variant=sys.argv[1]
assert variant in ('baseline','candidate')
build=root/'build/ninja-msvc-debug'
target=(build if variant=='baseline' else run/'debug')/'AzureRender.exe'
out=run/('debug-'+variant+'-bootstrap-diagnostics')

def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()

if len(sys.argv)==2:
    out.mkdir()
    original=build/'AzureRender.exe'
    config=build/'shader-reload.json'
    before={str(p):sha(p) for p in (target,original,config,root/'tools/test_shader_reload_host.py')}
    env=os.environ|{'PATH':os.pathsep.join((str(build),'D:/Tools/dotnet9',os.environ['PATH'])),
                    'AZURERENDER_RESOURCE_ROOT':str(build),'VK_LOADER_DRIVERS_SELECT':'*nv-vk64*'}
    for name in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_INSTANCE_LAYERS'):
        env.pop(name,None)
    try:
        with (out/'fixture.log').open('xb') as log:
            code=subprocess.run([sys.executable,'-B','-X','utf8',str(Path(__file__)),variant,'--child'],
                                env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=420).returncode
    except subprocess.TimeoutExpired:
        code=124
    assert all(sha(Path(p))==v for p,v in before.items())
    (out/'receipt.json').write_text(json.dumps({'variant':variant,'fixtureExitCode':code,'inputs':before},indent=2)+'\n',encoding='utf-8')
    if code:
        assert (out/'operations-observed.jsonl').is_file(), 'Probe did not reach the validation endpoint'
    print(variant,'fixture exit code',code,flush=True)
    raise SystemExit(0)

sys.path.insert(0,str(root/'tools'))
import test_shader_reload_host as fixture
from observe_host_wait import chains

actual=fixture.exchange
epoch=time.monotonic()
launch=subprocess.Popen
host=None

def launch_fixture(command,*args,**kwargs):
    global host
    proc=launch(command,*args,**kwargs)
    if isinstance(command,(list,tuple)) and Path(command[0]).resolve()==target and '--shader-reload' in command:
        assert host is None
        host=proc
    return proc

def sample_host(done):
    for delay in (2,4,4):
        if done.wait(delay) or host is None or host.poll() is not None:return
        try:row=chains(host)
        except OSError as error:row={'waitChainError':repr(error)}
        row['seconds']=time.monotonic()-epoch
        with (out/'host-observed.jsonl').open('a',encoding='utf-8') as stream:
            stream.write(json.dumps(row)+'\n')

def sample(endpoint,token,request):
    begin=time.monotonic()
    row={'request':request,'startSeconds':begin-epoch}
    try:
        reply=actual(endpoint,token,request)
        value=reply.get('value')
        row.update(passed=reply.get('passed'),code=reply.get('code'),hostElapsedMs=reply.get('elapsedMs'),
                   value=value if isinstance(value,(int,bool)) else None,
                   valueLength=len(value) if isinstance(value,str) else None)
        return reply
    except (OSError,ValueError) as error:
        row['error']=repr(error)
        raise
    finally:
        row['seconds']=time.monotonic()-begin
        with (out/'operations-observed.jsonl').open('a',encoding='utf-8') as stream:
            stream.write(json.dumps(row)+'\n')

def monitored(endpoint,token,request):
    if request.get('name')!='developer.status' or len(observed):
        return sample(endpoint,token,request)
    observed.append(True)
    done=threading.Event()
    monitor=threading.Thread(target=sample_host,args=(done,),daemon=True)
    monitor.start()
    with ThreadPoolExecutor(max_workers=3) as pool:
        checks=[pool.submit(sample,endpoint,token,{'op':'query','name':name})
                for name in ('engine.frameCount','engine.status')]
        try:
            return sample(endpoint,token,request)
        finally:
            for check in checks:
                try:check.result()
                except (OSError,ValueError):pass
            done.set()
            monitor.join(timeout=1)

observed=[]
fixture.exchange=monitored
subprocess.Popen=launch_fixture
result=fixture.run(target,build/'shader-reload.json',out/'workflow','exploration')
(out/'exploration-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
