"""Compare completed displayed frames after the registered test produces a terminal result."""
from pathlib import Path
import hashlib,json,re
import numpy as np
from PIL import Image

here=Path(__file__).resolve().parent
runs=here.parent
a=runs/'20261114-231121-material-display-gpu-aebdcb/captures'
b=runs/'20261114-205033-material-display-gpu-43a12b/captures'
registry=runs/'20261114-214915-nr-main-capture-reservation-d7c5ef/debug-gpu-94.log'

def identity(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def summary():
    foreground=json.loads((a/'summary.json').read_bytes())
    reference=json.loads((b/'summary.json').read_bytes())
    assert reference['status']=='passed' and len(reference['captures'])==53 and len(reference['comparisons'])==16
    assert foreground['programSha256']==reference['programSha256']
    line=[l for l in registry.read_text(encoding='utf-8').splitlines() if re.search(r'^\d+/9 Test #296: AzureEngine\.MaterialDisplayGpu',l)]
    if not line:return None
    assert len(line)==1
    rows=[]
    for meta in foreground['captures']:
        name=meta['name'];src=a/name;ref=b/name
        original=json.loads((src/'command.json').read_bytes())
        candidate=json.loads((ref/'command.json').read_bytes())
        assert [item.replace(str(src),'$CASE') for item in original]==[item.replace(str(ref),'$CASE') for item in candidate]
        signatures=[]
        for idx in range(meta['frames']):
            f=f'frame_{idx:06}.png'
            expected=ref/'frames'/f; actual=src/'frames'/f
            with Image.open(expected) as before,Image.open(actual) as after:
                assert np.array_equal(np.asarray(before.convert('RGB')),np.asarray(after.convert('RGB'))),(name,idx)
            signatures.append([identity(expected),identity(actual)])
        rows.append({'case':name,'frameCount':meta['frames'],'frames':signatures,
                     'logs':[identity(src/'player.log'),identity(ref/'player.log')]})
    assert len(rows)==len(foreground['captures'])
    return {'ctest':line[0],'playerSha256':foreground['programSha256'],'caseCount':len(rows),
            'frameCount':sum(row['frameCount'] for row in rows),'rgbExact':True,'registeredCases':rows,
            'originalAssertions':{'scenes':len(reference['captures']),'comparisonGroups':len(reference['comparisons']),
                                  'frames':sum(row['frames'] for row in reference['captures'])}}

if __name__=='__main__':
    report=summary()
    if report is None:raise SystemExit(3)
    with (here/'material-display-main-timeout-comparison.json').open('x',encoding='utf-8') as f:
        f.write(json.dumps(report,indent=2)+'\n')
    print({k:v for k,v in report.items() if k!='registeredCases'},flush=True)
