"""Run the original registered arguments with only staged reservation declarations."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


root = Path.cwd().resolve()
run = Path(__file__).resolve().parent
stage = run / 'capture-reservation-candidate'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def exercise(config, lane):
    build = root / 'build' / ('ninja-msvc-' + config)
    source = json.loads((stage/'observed-reservations.json').read_bytes())
    lookup = {str((root / v['path']).resolve()): n for n,v in source.items()}
    registry = run / (config + '-inventory.json')
    original = json.loads(registry.read_bytes())['tests']
    failed = {'AzureEngine.LocomotionBlendGpu','AzureEngine.MaterialRadianceGpu','AzureEngine.MaterialLightingGpu',
              'AzureEngine.MaterialLightingGpu.Fabric','AzureEngine.MaterialLightingGpu.ObjectShadow',
              'AzureEngine.NprRampCompositionGpu','AzureEngine.NprRampCompositionGpu.Fabric','AzureEngine.MaterialDisplayGpu'}
    destination = stage / (config + '-' + lane)
    destination.mkdir()
    report = {'configuration':config,'selection':lane,'registrySha256':sha(registry),'cases':[]}
    env = os.environ | {'PATH': os.pathsep.join((str(build),'D:/Tools/dotnet9',os.environ['PATH'])),
                         'PYTHONDONTWRITEBYTECODE':'1','VK_LOADER_DRIVERS_SELECT':'*nv-vk64*'}
    for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES','AZURE_DISABLE_COMPUTED_MATERIAL_VIEW'):
        env.pop(key, None)
    for case in original:
        args = case['command']
        pathname = str(Path(args[1]).resolve()) if len(args)>1 and args[1].endswith('.py') else None
        if pathname not in lookup or ((case['name'] in failed) != (lane == 'failed')):
            continue
        label = lookup[pathname]
        props = {p['name']:p['value'] for p in case['properties']}
        config_env = env.copy()
        for item in props.get('ENVIRONMENT', []):
            key, _, value = item.partition('=')
            config_env[key] = value
        assert not any(k in props for k in ('ENVIRONMENT_MODIFICATION','FIXTURES_REQUIRED','RESOURCE_GROUPS'))
        original_script = Path(pathname)
        candidate = stage / source[label]['path']
        script = 'from pathlib import Path; import sys; original, staged = sys.argv[1:3]; sys.argv = [original, *sys.argv[3:]]; sys.path[0] = str(Path(original).parent); exec(compile(Path(staged).read_bytes(), original, "exec"), {"__name__":"__main__", "__file__":original})'
        command = [sys.executable, '-B', '-X', 'utf8', '-c', script, pathname, str(candidate), *args[2:]]
        begin = time.monotonic()
        case_name = case['name']
        products = {str(p): sha(p) for arg in args[2:] if (p:=Path(arg)).suffix in ('.exe','.spv') and p.is_file()}
        with (destination/(case_name+'.log')).open('xb') as output:
            try:
                status = subprocess.run(command, cwd=props.get('WORKING_DIRECTORY',build), env=config_env,
                                        stdout=output, stderr=subprocess.STDOUT, timeout=props['TIMEOUT']).returncode
            except subprocess.TimeoutExpired:
                status = 124
        assert all(sha(Path(path)) == digest for path,digest in products.items())
        report['cases'].append({'test':case_name,'registeredCommand':args,'timeout':props['TIMEOUT'],
                                'scriptSha256':sha(original_script),'candidateSha256':sha(candidate),
                                'productHashes':products,'seconds':time.monotonic()-begin,'exitCode':status})
        (destination/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        print(case_name,status,flush=True)
    assert report['cases'] and (lane != 'failed' or {c['test'] for c in report['cases']} == failed)
    return int(any(row['exitCode'] for row in report['cases']))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('config', choices=('release','debug'))
    parser.add_argument('lane', choices=('failed','adjacent'))
    options = parser.parse_args()
    raise SystemExit(exercise(options.config, options.lane))
