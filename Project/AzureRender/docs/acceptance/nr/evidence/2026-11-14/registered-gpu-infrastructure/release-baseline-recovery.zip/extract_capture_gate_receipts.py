"""Verify the two capacity refusals and the separate Release rehearsal receipts."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re
from xml.etree import ElementTree as ET

run=Path(__file__).resolve().parent
stage=run/'capture-reservation-candidate'
shards={16:['AzureEngine.LocomotionBlendGpu'],18:['AzureEngine.MaterialRadianceGpu','AzureEngine.MaterialLightingGpu'],
        19:['AzureEngine.MaterialLightingGpu.Fabric','AzureEngine.MaterialLightingGpu.ObjectShadow','AzureEngine.NprRampCompositionGpu','AzureEngine.NprRampCompositionGpu.Fabric'],
        20:['AzureEngine.MaterialDisplayGpu']}

def load(path):
    return json.loads(path.read_bytes())
def digest(p):
    return sha256(p.read_bytes()).hexdigest()
def find_receipt(path,test):
    cases=[c for c in ET.parse(path).findall('.//testcase') if c.get('name')==test]
    [case]=cases
    assert case.find('failure') is not None and case.find('skipped') is None
    duration=float(case.get('time'))
    assert duration<4, (test,duration)
    log=case.findtext('system-out') or ''
    marker=re.search(r'(?m)^artifact_cleanup\.py: error: Artifact budget refused: (\{.*\})$',log)
    assert marker and '--new-run' in log and 'returned non-zero exit status 2' in log, (path,test)
    budget=json.loads(marker[1])
    assert budget['plannedBytes']==2**31 and budget['quotaBytes']==2**31
    return {'timeSeconds':duration,'junit':path.name,'junitSha256':digest(path),'budget':budget}

candidate=load(stage/'release-failed/results.json')
assert candidate['registrySha256']==digest(run/'release-inventory.json')
assert all(row['exitCode']==0 for row in candidate['cases'])
by_case={row['test']:row for row in candidate['cases']}
assert len(by_case)==len(candidate['cases'])==8
reservations=load(stage/'observed-reservations.json')
case_rows={}
for shard,tests in shards.items():
    tag=f'release-gpu-{shard}'
    for test in tests:
        initial=find_receipt(run/(tag+'.xml'),test)
        initial_budget=initial['budget']
        expected_reasons=['volume-reserve'] + (['managed-pool-limit'] if shard==20 else [])
        assert initial_budget['reasons']==expected_reasons and initial_budget['allowed'] is False
        row=by_case[test]
        assert Path(row['registeredCommand'][1]).resolve()==(Path.cwd()/next(v['path'] for v in reservations.values() if digest(stage/v['path'])==row['candidateSha256'])).resolve()
        assert test in {case['name'] for case in load(run/'release-inventory.json')['tests']}
        result={'original':initial,'candidate':row,'candidateLogSha256':digest(stage/'release-failed'/(test+'.log'))}
        if shard!=20:
            suffix='02' if shard==16 else '01'
            restored=find_receipt(run/(tag+'-focused-retry-'+suffix+'.xml'),test)
            budget=restored['budget']
            assert budget['allowed'] is False and budget['reasons']==['managed-pool-limit']
            assert budget['freeBytes']-budget['plannedBytes']>=budget['reserveBytes']
            assert budget['managedPool']['projectedBytes']>budget['managedPool']['limitBytes']==16*2**30
            result['volumeRecoveryRetest']=restored
        else:
            assert initial_budget['managedPool']['allowed'] is False
        case_rows[test]=result
assert set(case_rows)==set(by_case)
release_job=load(run/'capture-reservation-release-queue.log')
assert release_job['id']==622 and release_job['state']=='succeeded' and release_job['exit_code']==0
report={'candidateOnly':True,'config':'Release','strictGatesUnchanged':True,'measurements':reservations,'cases':case_rows,
        'releaseGpuDispatch':{name:release_job[name] for name in ('id','run_seconds','state','exit_code')},
        'initialVolumeDenied':8,'retainedPoolDeniedAfterVolumeRecovery':7}
(run/'capture-reservation-release-attribution.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('Verified 8 initial volume failures, 7 residual pool failures and 8 passing GPU rehearsals.')
