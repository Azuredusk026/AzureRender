"""Summarize observed ViewFog pipeline state without counting incomplete cases."""
from collections import Counter
import json
from pathlib import Path

run = Path(__file__).resolve().parent
prior = json.loads((run/'view-fog-prior-pipeline-observations.json').read_bytes())
live = {}
job = None
for line in (run/'view-fog-process-observations.jsonl').read_bytes().splitlines():
    event = json.loads(line)
    if 'job' in event:
        job = event['job']
    else:
        live[event['case']] = event

def summarize(rows):
    result = {}
    for mode in ('indexed','fixed'):
        cases = [row for row in rows if row.get('unloaded') and row['case'].startswith(mode+'-')]
        if not cases:
            continue
        assert all('load' in row and 'save' in row and 'pipelinesMs' in row and len(row['imageSha256'])==64 for row in cases)
        result[mode] = {'completed':len(cases),'saveStates':Counter(row['save'][1] for row in cases),
                        'profiles':sorted({row['load'][2] for row in cases}),'loadedBytes':sorted({int(row['load'][0]) for row in cases}),
                        'pipelineSeconds':round(sum(float(row['pipelinesMs'][0]) for row in cases)/1000,3),
                        'pipelineHits':sum(int(row['save'][3]) for row in cases),
                        'pipelineRequests':sum(int(row['save'][2]) for row in cases)}
    return result

report = {'original':summarize(prior),'repeat':summarize(live.values()),'repeatJob':job}
comparable = [(row,live[row['case']]) for row in prior if row.get('unloaded') and live.get(row['case'],{}).get('unloaded')]
assert all(a['imageSha256']==b['imageSha256'] for a,b in comparable)
report['matchingObservedImageCount']=len(comparable)
(run/'view-fog-cache-attribution.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
