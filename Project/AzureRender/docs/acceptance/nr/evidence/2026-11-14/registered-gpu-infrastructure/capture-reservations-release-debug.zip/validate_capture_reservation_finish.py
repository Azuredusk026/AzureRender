"""Cross-check the four unchanged registered argument sets and their managed receipts."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sqlite3


engine=Path.cwd().resolve()
run=Path(__file__).resolve().parent
stage=run/'capture-reservation-candidate'
owner='01a1d0a8-a74c-7cc0-85e8-540a6653098a'
ports={'release':{'failed':622,'adjacent':632},'debug':{'failed':643,'adjacent':None}}
minimum= datetime.fromisoformat('2026-11-14T19:15:00+08:00').timestamp()


def sha(p):
    with p.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def load(path):
    return json.loads(path.read_bytes())


assert load(stage/'candidate-validation-complete.json')=={'release':17,'debug':17}
reservations=load(stage/'observed-reservations.json')
scans=load(run/'remaining-transitive-reservation-scan.json')
assert all(not scans[key]['uncovered'] for key in ports)
reports=[]
with sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True) as db:
    ids=db.execute('select id from jobs where owner=? and task=? and state=?',(owner,'nr-capture-reservation-candidate-debug-adjacent','succeeded')).fetchall()
    [(ports['debug']['adjacent'],)]=ids
    table={id_:db.execute('select id,owner,task,state,exit_code,started,ended from jobs where id=?',(id_,)).fetchone()
           for lanes in ports.values() for id_ in lanes.values()}

all_managed={}
with sqlite3.connect('file:build/maintenance/artifact-index.sqlite3?mode=ro',uri=True) as db:
    for name,row in db.execute('select name,data from runs'):
        record=json.loads(row)
        if record.get('created',0)>=minimum and len(name)>24:
            all_managed[name]=record

for config,lanes in ports.items():
    path=run/(config+'-inventory.json')
    registry={x['name']:x for x in load(path)['tests']}
    names=set()
    for lane,id_ in lanes.items():
        receipt=stage/f'{config}-{lane}'/'results.json'
        report=load(receipt)
        assert report['registrySha256']==sha(path)
        assert (report['configuration'],report['selection'])==(config,lane)
        assert len(report['cases'])==(8 if lane=='failed' else 9)
        identifier,thread,task,state,code,begin,end=table[id_]
        assert identifier==id_ and thread==owner and state=='succeeded' and code==0 and begin<end
        dispatch_scope={}
        for row in report['cases']:
            case=row['test']; original=registry[case]
            assert case not in names
            names.add(case)
            assert row['registeredCommand']==original['command']
            props={entry['name']:entry['value'] for entry in original['properties']}
            assert row['timeout']==props['TIMEOUT'] and row['exitCode']==0 and 0<row['seconds']<=row['timeout']
            source=Path(row['registeredCommand'][1]).relative_to(engine).as_posix()
            [label]=[k for k,v in reservations.items() if v['path']==source]
            assert sha(stage/source)==row['candidateSha256'] and sha(engine/source)==row['scriptSha256']
            assert all(sha(Path(k))==value for k,value in row['productHashes'].items())
            dispatch_scope[case]={'task':label,'registeredSeconds':row['timeout'],'actualSeconds':row['seconds'],
                                  'logSha256':sha(receipt.parent/(case+'.log'))}
        actual={name:{'status':record['status'],'bytes':record['reservedBytes'],'manifestSha256':record.get('manifestSha256')}
                for name,record in all_managed.items() if begin<=record['created']<=end and any(name[16:-7]==row['task'] for row in dispatch_scope.values())}
        for name,rec in actual.items():
            label=name[16:-7]
            assert rec['status']=='closed' and rec['manifestSha256'] and rec['bytes']<=reservations[label]['plannedBytes'],(name,rec)
        assert len(actual)==len(dispatch_scope), (config,lane,len(actual),len(dispatch_scope))
        for label in {row['task'] for row in dispatch_scope.values()}:
            required=sum(row['task']==label for row in dispatch_scope.values())
            observed=sum(name[16:-7]==label for name in actual)
            assert required==observed,(config,lane,label,required,observed)
        reports.append({'config':config,'group':lane,'job':id_,'cases':dispatch_scope,'observedManagedRuns':actual,
                        'receipt':receipt.relative_to(run).as_posix(),'receiptSha256':sha(receipt)})
    assert len(names)==17

data={'registrySha256':{c:sha(run/(c+'-inventory.json')) for c in ports},'candidatePatchSha256':sha(stage/'patch.diff'),
      'casesPerConfiguration':17,'registrationUnchanged':True,'candidateOnly':True,'reservations':reservations,
      'importScanSha256':sha(run/'remaining-transitive-reservation-scan.json'),'groups':reports}
(run/'capture-reservation-both-configurations-attribution.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print([(group['config'],group['group'],group['job'],len(group['cases'])) for group in reports],flush=True)
