"""Check capture tasks use an explicit, measured reservation for known workloads."""
import argparse
import ast
import json
from pathlib import Path
import re
import sqlite3
import sys
import unittest


engine = Path.cwd()
scripts = {
    'locomotion-blend-lab': 'tools/native_render/locomotion_blend_lab.py',
    'material-radiance-gpu': 'tools/test_material_radiance_gpu.py',
    'material-lighting-gpu': 'tools/test_material_lighting_gpu.py',
    'material-display-gpu': 'tools/test_material_display_gpu.py',
    'npr-ramp-composition': 'tools/test_npr_ramp_composition_gpu.py',
    'material-coverage': 'tools/test_material_coverage_gpu.py',
    'material-coverage-mips': 'tools/test_material_coverage_mips_gpu.py',
    'native-ray-reference': 'tools/test_native_ray_reference_gpu.py',
    'projected-camera-gpu': 'tools/test_projected_camera_gpu.py',
    'projected-scene-gpu': 'tools/test_projected_scene_reflections.py',
}


def history():
    with sqlite3.connect('file:build/maintenance/artifact-index.sqlite3?mode=ro', uri=True) as db:
        rows = db.execute('select name, data from runs').fetchall()
    results = {label: [] for label in scripts}
    for name, raw in rows:
        item = json.loads(raw)
        if item['status'] != 'closed':
            continue
        for label in scripts:
            if re.fullmatch(r'[0-9]{8}-[0-9]{6}-' + label + '-[a-z0-9]{6}', name):
                results[label].append(item['reservedBytes'])
    return results


def preflight(total, free, planned):
    sys.path.insert(0, str(Path.cwd() / 'tools'))
    from artifact_budget import evaluate
    from artifact_maintenance import POLICY
    assert evaluate(total=total, free=free, used=0, planned=planned)['allowed']
    actual_pool_bytes = 15195086655
    return actual_pool_bytes + planned <= POLICY['poolBytes']


class RegisteredCaptureReservations(unittest.TestCase):
    def test_registered_startup_accepts_owned_writes_with_observed_budget(self):
        rows = history()
        for label, file in scripts.items():
            with self.subTest(label=label):
                parsed = ast.parse((engine / file).read_text(encoding='utf-8-sig'))
                candidates = []
                for node in ast.walk(parsed):
                    if isinstance(node, (ast.List, ast.Tuple)):
                        values = [v.value if isinstance(v, ast.Constant) else None for v in node.elts]
                        if '--new-run' in values and values[values.index('--new-run')+1] == label:
                            candidates.append(values)
                [declared] = candidates
                self.assertGreaterEqual(len(rows[label]), 2)
                peak = max(rows[label])
                self.assertIn('--planned-bytes', declared, f'{label}: measured peak is {peak} bytes')
                limit = int(declared[declared.index('--planned-bytes')+1])
                self.assertGreaterEqual(limit, 2 * peak)
                self.assertTrue(preflight(1024208138240, 107454509056, limit))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('history','test'))
    parser.add_argument('--engine', type=Path, default=engine)
    opts = parser.parse_args()
    engine = opts.engine.resolve()
    if opts.mode == 'history':
        print(json.dumps({n: {'count': len(v), 'peak': max(v, default=0)} for n, v in history().items()}, indent=2))
    else:
        unittest.main(argv=[sys.argv[0]])
