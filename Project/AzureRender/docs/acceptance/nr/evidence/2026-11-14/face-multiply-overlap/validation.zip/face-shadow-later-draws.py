"""Measure later writes at the candidate hair-shadow depth footprints."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import struct

from PIL import Image


root = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_bytes())
request = read(root / 'face-shadow-structured-capture/request.json')
native_root = Path(request['source']).parent.parent / '20261103-234012-character-reference-stages-5abe6c'
draws = native_root / 'post-opaque-ownership'
inventory = read(draws / 'manifest.json')
assert inventory['status'] == 'exported'
overlap = read(root / 'face-multiply-overlap-audit.json')
overlapping_points = [tuple(item['point']) for item in overlap['unobstructedDepthPrepassOwners']]
assert len(overlapping_points) == 12


def differences(draw):
    event = draw['event']
    assert set(draw['files']) == {f'{event}-{event - 1}.bin.gz', f'{event}-{event}.bin.gz'}
    before, after = [gzip.decompress((draws / f'{event}-{step}.bin.gz').read_bytes())
                     for step in (event - 1, event)]
    assert len(before) == len(after) == 2560 * 1440 * 4
    changes = []
    for i, (a, b) in enumerate(zip(struct.iter_unpack('<I', before), struct.iter_unpack('<I', after))):
        if a != b:
            changes.append((i % 2560, 1439 - i // 2560))
    return set(changes), dict(event=event, target=draw['target'], changedPixels=len(changes),
                              beforeSha256=sha256(before).hexdigest(), afterSha256=sha256(after).hexdigest())


mask_path = root.parent / '20261112-231945-projected-hair-reference-grid-4b775d/native-face-masks/face.png'
with Image.open(mask_path) as png:
    mono = png.convert('L')
    region = {(i % mono.width, i // mono.width) for i, p in enumerate(mono.tobytes()) if p}
assert len(region) == 3663 and set(overlapping_points) <= region
events = {row['event']: row for row in inventory['events']}
face_shadow_points, owner = differences(events[1358])
assert len(face_shadow_points & region) == 264 and set(overlapping_points) <= face_shadow_points
later = []
for event in sorted(events):
    if event <= 1358:
        continue
    locations, summary = differences(events[event])
    summary.update(
        sharedWithNativeHairShadow=len(locations & face_shadow_points),
        sharedWithFaceHairShadow=len(locations & face_shadow_points & region),
        sharedWithKnownOverlaps=sorted(locations.intersection(overlapping_points)),
    )
    later.append(summary)
assert later and later[-1]['event'] == 1383
assert later[0]['beforeSha256'] == owner['afterSha256']
report = dict(status='measured-native-color-writes', scope='post-opaque-character-draw-inventory',
              nativeCaptureSha256=request['captureSha256'], owner=owner, later=later)
(root / 'face-shadow-later-draws.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf8')
print(json.dumps(later))
