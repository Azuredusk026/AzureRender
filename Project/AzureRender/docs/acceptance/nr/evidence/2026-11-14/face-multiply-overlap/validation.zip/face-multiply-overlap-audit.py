"""Check whether the outlined face receives repeated fragment multiplication."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import runpy
import sys

import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
sys.path.insert(0,str(run.parents[2]/'tools'))
from endfield_native.postvs import read_postvs

load=lambda p:json.loads(p.read_bytes())
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
tool=runpy.run_path(str(run/'iris-overlay-main-frame-isolation.py'),run_name='source_transfer')
gpu_records=load(run/'face-pair-native-ownership.json')
main=Path('D:/Projects/FYP/Project/AzureRender/build/runs')
frames=tool['score']['stages']/'post-opaque-ownership'
geo=main/'20261023-033116-postvs-linear-verification-591bef/postvs-1358'
source=load(run/'late-overlay-replay.json')['native']['1358']['geometry']
vertices=read_postvs(geo/'manifest.json')
assert [entry['sha256'] for entry in vertices['manifest']['buffers']]==[source['vertexHash'],source['indexHash']]
indices=vertices['indices'].astype(int).reshape(-1,3)
assert source['indexHash']==load(run/'late-overlay-replay.json')['native']['1339']['geometry']['indexHash']
assert source['vertexHash']==load(run/'late-overlay-replay.json')['native']['1339']['geometry']['vertexHash']
clip=vertices['attributes']['SV_Position'].astype(float)
precise=(clip[:,:2]/clip[:,3,None]+1)*[1280,720]
first,last=[np.frombuffer(gzip.decompress((frames/f'1358-{evt}.bin.gz').read_bytes()),'<u4').reshape(1440,2560)[::-1]
            for evt in (1357,1358)]
with Image.open(grid/'native-face-masks/face.png') as image:face=np.asarray(image.convert('L'))>0
mask=(first!=last)&face
assert mask.sum()==264
x,y=np.nonzero(mask)[::-1]
ref_before,ref_after=(tool['unpack'](frame[mask]) for frame in (first,last))
native_multipliers=np.divide(ref_after,ref_before,out=np.ones_like(ref_after),where=ref_before>0)
locations=np.column_stack([x,y]).astype(int)

def triangles(pixels):
    matches=[[] for _ in pixels]
    raster=np.rint(precise*256)/256
    for ordinal,idx in enumerate(indices):
        a,b,c=raster[idx]
        dx,dy=b-a,c-a
        area=dx[0]*dy[1]-dx[1]*dy[0]
        if abs(area)<1.e-14:continue
        p=pixels-a
        u=(p[:,0]*dy[1]-p[:,1]*dy[0])/area
        v=(p[:,1]*dx[0]-p[:,0]*dx[1])/area
        w=1-u-v
        for i in np.flatnonzero((u>=0)&(v>=0)&(w>=0)):
            pattern=np.array([w[i],u[i],v[i]])/clip[idx,3]
            uv=pattern@vertices['attributes']['TEXCOORD0'][idx]/pattern.sum()
            matches[i].append(dict(primitive=ordinal,winding=int(np.sign(area)),uv=uv.tolist(),
                depth=float(np.dot([w[i],u[i],v[i]],clip[idx,2]/clip[idx,3]))))
    return matches

coverage=triangles(locations+.5)
assert all(coverage)
assert all(load(run/f'face-{device}-1230/results.json')['frameSha256']==sha256((run/f'face-{device}-1230/frames/frame_000000.png').read_bytes()).hexdigest() for device in ('nvidia','intel'))
result={}
for device in ('nvidia','intel'):
    base=tool['frame'](run/f'face-{device}-1230/frames/frame_000000.png')[mask]
    current=tool['frame'](run/f'face-{device}-pair/frames/frame_000000.png')[mask]
    base_linear=tool['linear'](base)
    exponent_errors=np.column_stack([np.abs(tool['display'](base_linear*native_multipliers**count)-current).max(1)
                                    for count in (0,1,2,3)])
    residual=exponent_errors[:,1]>1
    assert residual.sum()==gpu_records['devices'][device]['owner']['1358']['pairAgainstNativeMultiplication']['overOne']
    n_cover=np.array([len(c) for c in coverage])
    changes=[]
    for i in np.flatnonzero(residual):
        changes.append(dict(point=locations[i].tolist(),singleApplicationError=int(exponent_errors[i,1]),
            exponentErrors=exponent_errors[i].tolist(),triangles=coverage[i],referenceMultiplier=native_multipliers[i].tolist()))
    assert int((residual&(exponent_errors[:,2]<=2)&(n_cover>1)).sum())==12
    assert all(c['winding']==1 for cover in coverage if len(cover)>1 for c in cover)
    result[device]=dict(residuals=int(residual.sum()),withinTwoApplyingTwice=int((residual&(exponent_errors[:,2]<=2)).sum()),
        knownDoubleAppliesWithMultipleTriangles=int((residual&(exponent_errors[:,2]<=2)&(n_cover>1)).sum()),
        withinTwoApplyingZero=int((residual&(exponent_errors[:,0]<=2)).sum()),
        details=sorted(changes,key=lambda x:-x['singleApplicationError']))
report=dict(status='face-shadow-multiplication-audit',sourceCovered=int(mask.sum()),
            rasterMultiple=int(sum(len(c)>1 for c in coverage)),devices=result)
(run/'face-multiply-overlap-audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
for dev,row in result.items():print(dev,{k:v for k,v in row.items() if k!='details'},row['details'][:4])



