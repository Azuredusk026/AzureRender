Shader hash 92d652c8-eb5aa9a1-69e0b441-12933985

ps_5_0
      dcl_globalFlags refactoringAllowed
      dcl_constantbuffer cb0[45], immediateIndexed
      dcl_constantbuffer cb1[123], immediateIndexed
      dcl_constantbuffer cb2[2054], dynamicIndexed
      dcl_constantbuffer cb3[4], immediateIndexed
      dcl_constantbuffer cb4[4], immediateIndexed
      dcl_sampler s0, mode_default
      dcl_sampler s1, mode_default
      dcl_sampler s2, mode_default
      dcl_resource_structured t0, 4
      dcl_resource_texture2d (float,float,float,float) t1
      dcl_resource_texture3d (float,float,float,float) t2
      dcl_resource_texture2d (float,float,float,float) t3
      dcl_resource_texture2d (float,float,float,float) t4
      dcl_input_ps_siv linear noperspective v0.xyw, position
      dcl_input_ps linear v1.xy
      dcl_input_ps linear v2.xyz
      dcl_output o0.xyzw
      dcl_temps 15
   0: lt r0.x, l(0.500000), cb4[0].w
   1: if_nz r0.x
   2:   mul r0.xy, v0.xyxx, cb1[0].zwzz
   3:   sample_l(texture2d)(float,float,float,float) r0.x, r0.xyxx, t1.xyzw, s0, l(0)
   4:   mad r0.x, cb1[2].z, r0.x, cb1[2].w
   5:   div r0.x, l(1.000000, 1.000000, 1.000000, 1.000000), r0.x
   6:   add r0.x, r0.x, -v0.w
   7:   add r0.x, -abs(r0.x), cb4[1].x
   8:   lt r0.x, r0.x, l(0)
   9:   discard_nz r0.x
  10: endif
  11: ftou r0.xy, v0.xyxx
  12: sample_b(texture2d)(float,float,float,float) r1.xyzw, v1.xyxx, t3.xyzw, s2, cb1[26].x
  13: mov r2.x, l(1.000000)
  14: mov r2.w, r1.x
  15: add r2.xyzw, -r1.xyzw, r2.xxxw
  16: mad r1.xyzw, cb4[0].xxxx, r2.xyzw, r1.xyzw
  17: mul r2.xyzw, r1.xyzw, cb4[2].xyzw
  18: utof r3.xy, r0.xyxx
  19: mul r3.zw, r3.xxxy, l(0.000000, 0.000000, 0.031250, 0.031250)
  20: round_ni r3.zw, r3.zzzw
  21: mad r0.w, r3.w, cb3[2].y, r3.z
  22: mul r0.w, r0.w, l(8.000000)
  23: ftoi r0.w, r0.w
  24: mad r1.w, -cb1[3].y, cb3[3].w, v0.w
  25: round_ni r1.w, r1.w
  26: add r3.z, l(-1.000000), cb3[2].w
  27: max r3.w, r1.w, l(0)
  28: min r3.z, r3.z, r3.w
  29: mul r3.w, r3.z, l(8.000000)
  30: ftoi r3.w, r3.w
  31: ge r1.w, r3.z, r1.w
  32: iadd r0.w, r0.w, cb3[0].z
  33: iadd r3.z, r3.w, cb3[0].w
  34: mov r4.w, l(1.000000)
  35: mov r3.w, l(0)
  36: mov r5.x, l(0)
  37: loop
  38:   ilt r5.y, l(7), r5.x
  39:   breakc_nz r5.y
  40:   iadd r5.y, r0.w, r5.x
  41:   ld_structured_indexable(structured_buffer, stride=4)(mixed,mixed,mixed,mixed) r5.y, r5.y, l(0), t0.xxxx
  42:   iadd r5.z, r3.z, r5.x
  43:   ld_structured_indexable(structured_buffer, stride=4)(mixed,mixed,mixed,mixed) r5.z, r5.z, l(0), t0.xxxx
  44:   and r5.y, r5.z, r5.y
  45:   and r5.y, r1.w, r5.y
  46:   ishl r5.z, r5.x, l(5)
  47:   mov r5.w, r3.w
  48:   mov r6.x, r5.y
  49:   loop
  50:     breakc_z r6.x
  51:     firstbit_lo r6.y, r6.x
  52:     ishl r6.z, l(1), r6.y
  53:     xor r6.z, r6.z, r6.x
  54:     iadd r6.y, r5.z, r6.y
  55:     bfi r7.xyz, l(29, 29, 29, 0), l(3, 3, 3, 0), r6.yyyy, l(1, 5, 6, 0)
  56:     ftou r6.w, cb2[r7.y + 6].w
  57:     and r6.w, r6.w, l(1)
  58:     ieq r6.w, r6.w, l(1)
  59:     if_nz r6.w
  60:       add r4.xyz, v2.xyzx, -cb2[r7.x + 6].xyzx
  61:       and r8.xyz, l(0x0000ffff, 0x0000ffff, 0x0000ffff, 0), cb2[r7.y + 6].xzyx
  62:       and r9.xyz, l(0x0000ffff, 0x0000ffff, 0x0000ffff, 0), cb2[r7.z + 6].yxzy
  63:       ushr r10.xyz, cb2[r7.y + 6].xzyx, l(16, 16, 16, 0)
  64:       ushr r11.xyz, cb2[r7.z + 6].yxzy, l(16, 16, 16, 0)
  65:       f16tof32 r8.xyz, r8.xyzx
  66:       f16tof32 r9.xyz, r9.xyzx
  67:       f16tof32 r10.xyz, r10.xyzx
  68:       f16tof32 r11.xyw, r11.yxyz
  69:       mov r12.xz, r8.xxzx
  70:       mov r12.yw, r10.xxxz
  71:       dp4 r6.w, r4.xyzw, r12.xyzw
  72:       mov r10.x, r8.y
  73:       mov r10.z, r9.y
  74:       mov r10.w, r11.x
  75:       dp4 r7.y, r4.xyzw, r10.xyzw
  76:       mov r11.xz, r9.xxzx
  77:       dp4 r4.x, r4.xyzw, r11.xyzw
  78:       bfi r4.y, l(29), l(3), r6.y, l(7)
  79:       max r4.z, abs(r6.w), abs(r7.y)
  80:       max r4.x, abs(r4.x), r4.z
  81:       mad r4.z, cb2[r4.y + 6].x, l(0.500000), l(0.500000)
  82:       add r4.x, -r4.z, r4.x
  83:       mad r4.y, -cb2[r4.y + 6].x, l(0.500000), l(0.500000)
  84:       div_sat r4.x, r4.x, r4.y
  85:       add r4.x, -r4.x, l(1.000000)
  86:       mul r4.x, r4.x, r4.x
  87:     else
  88:       mov r4.x, l(1.000000)
  89:     endif
  90:     lt r4.y, r4.x, l(0.001000)
  91:     if_nz r4.y
  92:       mov r6.x, r6.z
  93:       continue
  94:     endif
  95:     ishl r4.y, r6.y, l(3)
  96:     ftou r4.z, cb2[r4.y + 6].w
  97:     uge r6.w, r4.z, l(4)
  98:     if_nz r6.w
  99:       mov r7.y, r5.w
 100:     endif
 101:     if_z r6.w
 102:       lt r4.y, cb2[r4.y + 6].w, l(1.500000)
 103:       if_nz r4.y
 104:         bfi r4.y, l(29), l(3), r6.y, l(3)
 105:         ieq r6.w, l(16), cb2[r4.y + 6].w
 106:         add r7.w, cb1[122].z, cb2[r4.y + 6].z
 107:         lt r7.w, r7.w, l(0.500000)
 108:         or r6.w, r6.w, r7.w
 109:         if_z r6.w
 110:           bfi r6.yw, l(0, 29, 0, 29), l(0, 3, 0, 3), r6.yyyy, l(0, 2, 0, 4)
 111:           and r4.z, r4.z, l(1)
 112:           ine r7.w, r4.z, l(0)
 113:           lt r8.x, l(0), cb2[r6.y + 6].z
 114:           and r7.w, r7.w, r8.x
 115:           ieq r4.y, l(4), cb2[r4.y + 6].w
 116:           movc r4.z, r4.z, l(0), l(1.000000)
 117:           mad r8.x, cb2[r6.y + 6].y, l(0.500000), l(0.500000)
 118:           add r8.z, r8.x, -abs(cb2[r6.y + 6].x)
 119:           add r8.x, -r8.z, cb2[r6.y + 6].y
 120:           add r8.w, -abs(r8.z), l(1.000000)
 121:           add r8.w, -abs(r8.x), r8.w
 122:           max r8.w, r8.w, l(0.000488)
 123:           ge r9.x, cb2[r6.y + 6].x, l(0)
 124:           movc r8.y, r9.x, r8.w, -r8.w
 125:           dp3 r8.w, r8.xyzx, r8.xyzx
 126:           rsq r8.w, r8.w
 127:           mul r8.xyz, r8.wwww, r8.xyzx
 128:           add r8.w, cb2[r6.w + 6].y, cb2[r6.w + 6].y
 129:           max r8.w, r8.w, l(0.100000)
 130:           and r9.x, r4.y, l(1.000000)
 131:           add r8.w, r8.w, -cb2[r7.z + 6].w
 132:           mad r7.z, r9.x, r8.w, cb2[r7.z + 6].w
 133:           add r9.xyz, -v2.xyzx, cb2[r7.x + 6].xyzx
 134:           dp3 r8.w, r9.yzxy, -r8.xyzx
 135:           lt r9.w, l(0.500000), cb2[r6.w + 6].z
 136:           and r9.w, r4.y, r9.w
 137:           and r9.w, r9.w, l(1.000000)
 138:           mul r9.w, r4.z, r9.w
 139:           mad r10.xyz, -r8.zxyz, r8.wwww, -r9.xyzx
 140:           mad r9.xyz, r9.wwww, r10.xyzx, r9.xyzx
 141:           dp3 r8.w, r9.xyzx, r9.xyzx
 142:           rsq r9.w, r8.w
 143:           mul r10.xyz, r9.wwww, r9.xyzx
 144:           if_nz r7.w
 145:             mul r11.xyz, r8.zxyz, cb2[r6.y + 6].zzzz
 146:             mad r12.xyz, -r11.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), r9.xyzx
 147:             mad r11.xyz, r11.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), r9.xyzx
 148:             dp3 r9.w, r12.xyzx, r12.xyzx
 149:             sqrt r9.w, r9.w
 150:             dp3 r10.w, r11.xyzx, r11.xyzx
 151:             sqrt r10.w, r10.w
 152:             mul r13.xyz, r8.xyzx, r10.xyzx
 153:             mad r13.xyz, r8.zxyz, r10.yzxy, -r13.xyzx
 154:             mul r14.xyz, r8.xyzx, r13.xyzx
 155:             mad r13.xyz, r13.zxyz, r8.yzxy, -r14.xyzx
 156:             dp3 r11.w, r13.xyzx, r13.xyzx
 157:             rsq r11.w, r11.w
 158:             mul r10.xyz, r11.wwww, r13.xyzx
 159:             dp3 r11.w, r12.xyzx, r11.xyzx
 160:             mad r11.w, r9.w, r10.w, r11.w
 161:             mad r11.w, r11.w, l(0.500000), l(1.000000)
 162:             div r11.w, l(1.000000, 1.000000, 1.000000, 1.000000), r11.w
 163:             dp3 r12.x, r10.xyzx, r12.xyzx
 164:             div r9.w, r12.x, r9.w
 165:             dp3 r11.x, r10.xyzx, r11.xyzx
 166:             div r10.w, r11.x, r10.w
 167:             add r9.w, r9.w, r10.w
 168:             mul_sat r9.w, r9.w, l(0.500000)
 169:             mul r9.w, r9.w, r11.w
 170:           else
 171:             mov r9.w, l(1.000000)
 172:           endif
 173:           lt r10.w, r7.z, l(0)
 174:           if_nz r10.w
 175:             mul r10.w, cb2[r7.x + 6].w, cb2[r7.x + 6].w
 176:             mul r10.w, r8.w, r10.w
 177:             mad r10.w, -r10.w, r10.w, l(1.000000)
 178:             max r10.w, r10.w, l(0)
 179:             add r8.w, r8.w, l(1.000000)
 180:             div r8.w, l(1.000000, 1.000000, 1.000000, 1.000000), r8.w
 181:             and r7.w, r7.w, l(1.000000)
 182:             add r11.x, -r8.w, r9.w
 183:             mad r7.w, r7.w, r11.x, r8.w
 184:             mul r8.w, r10.w, r10.w
 185:             mul r7.w, r7.w, r8.w
 186:           else
 187:             mul r9.xyz, r9.xyzx, cb2[r7.x + 6].wwww
 188:             dp3 r7.x, r9.xyzx, r9.xyzx
 189:             min r7.x, r7.x, l(1.000000)
 190:             add r7.x, -r7.x, l(1.000000)
 191:             log r7.x, r7.x
 192:             mul r7.x, r7.x, r7.z
 193:             exp r7.x, r7.x
 194:             mul r7.w, r7.x, r9.w
 195:           endif
 196:           dp3 r7.x, r10.yzxy, -r8.xyzx
 197:           add r7.x, r7.x, -cb2[r6.y + 6].z
 198:           mul_sat r6.y, r7.x, cb2[r6.y + 6].w
 199:           mad r6.y, r6.y, r6.y, l(-1.000000)
 200:           mad r4.z, r4.z, r6.y, l(1.000000)
 201:           mul r4.z, r4.z, r7.w
 202:           mul r4.x, r4.x, r4.z
 203:           lt r4.z, l(0.000100), r4.x
 204:           if_nz r4.z
 205:             if_nz r4.y
 206:               mad_sat r5.w, r4.x, cb2[r6.w + 6].x, r5.w
 207:             endif
 208:           endif
 209:         endif
 210:       endif
 211:     else
 212:       mov r5.w, r7.y
 213:     endif
 214:     mov r6.x, r6.z
 215:   endloop
 216:   mov r3.w, r5.w
 217:   iadd r5.x, r5.x, l(1)
 218: endloop
 219: ftoi r4.xy, v0.xyxx
 220: mov r4.zw, l(0, 0, 0, 0)
 221: ld_indexable(texture2d)(float,float,float,float) r0.w, r4.xyzw, t4.xyzw
 222: eq r0.w, r0.w, l(1.000000)
 223: add r1.w, -r3.w, l(1.000000)
 224: mul r1.w, r1.w, r2.w
 225: movc r4.w, r0.w, l(0), r1.w
 226: lt r0.w, cb1[122].w, l(0.500000)
 227: if_nz r0.w
 228:   eq r0.w, l(0), cb1[4].w
 229:   add r5.xyz, -v2.xyzx, cb0[44].xyzx
 230:   mov r6.x, cb0[0].z
 231:   mov r6.y, cb0[1].z
 232:   mov r6.z, cb0[2].z
 233:   movc r5.xyz, r0.wwww, r5.xyzx, r6.xyzx
 234:   dp3 r0.w, -r5.xyzx, -r5.xyzx
 235:   max r1.w, r0.w, l(0.000000)
 236:   rsq r1.w, r1.w
 237:   mul r2.w, r0.w, r1.w
 238:   mul r5.xyz, r1.wwww, -r5.xyzx
 239:   mad r3.z, v2.y, cb1[74].w, cb1[75].w
 240:   mad r3.w, r2.w, cb1[72].w, -cb1[71].w
 241:   max r3.zw, r3.zzzw, l(0.000000, 0.000000, 0.010000, 0.000000)
 242:   mul r5.w, r3.z, l(-1.442695)
 243:   exp r5.w, r5.w
 244:   add r5.w, -r5.w, l(1.000000)
 245:   div r3.z, r5.w, r3.z
 246:   mad r5.w, v2.y, cb1[74].w, cb1[76].w
 247:   mul r5.w, r5.w, l(1.442695)
 248:   exp r5.w, r5.w
 249:   mul r3.z, r3.z, r5.w
 250:   mul r3.z, r3.z, -r3.w
 251:   mul r7.xyz, r3.zzzz, cb1[73].xyzx
 252:   mul r7.xyz, r7.xyzx, l(1.442695, 1.442695, 1.442695, 0.000000)
 253:   exp r7.xyz, r7.xyzx
 254:   dp3 r3.z, r5.xyzx, cb1[72].xyzx
 255:   mad r3.w, cb1[73].w, cb1[73].w, l(1.000000)
 256:   dp2 r5.w, r3.zzzz, cb1[73].wwww
 257:   add r3.w, r3.w, -r5.w
 258:   lt r5.w, l(0), cb1[83].z
 259:   if_nz r5.w
 260:     and r0.z, l(7), cb1[26].w
 261:     imad r0.xyz, r0.xyzx, l(0x0019660d, 0x0019660d, 0x0019660d, 0), l(0.014584, 0.014584, 0.014584, 0.000000)
 262:     imad r0.x, r0.y, r0.z, r0.x
 263:     imad r0.y, r0.z, r0.x, r0.y
 264:     imad r0.z, r0.x, r0.y, r0.z
 265:     imad r8.x, r0.y, r0.z, r0.x
 266:     dp3 r0.x, r5.xyzx, -r6.xyzx
 267:     add r5.w, v2.y, -cb0[44].y
 268:     lt r6.x, l(0.000000), r0.x
 269:     div r0.x, l(1.000000, 1.000000, 1.000000, 1.000000), r0.x
 270:     and r0.x, r0.x, r6.x
 271:     mul r0.x, r0.x, cb1[83].w
 272:     div r6.x, l(1.000000, 1.000000, 1.000000, 1.000000), r2.w
 273:     mul r6.y, r0.x, r6.x
 274:     mad r6.z, r6.y, r5.w, cb0[44].y
 275:     mad r5.w, -r6.y, r5.w, r5.w
 276:     mad r0.x, -r0.x, r6.x, l(1.000000)
 277:     mul r6.x, r2.w, r0.x
 278:     mul r6.y, r5.w, cb1[77].z
 279:     mul r5.w, r5.w, cb1[80].x
 280:     max r5.w, r5.w, l(-127.000000)
 281:     add r6.w, r6.z, -cb1[77].x
 282:     mul r6.w, r6.w, cb1[77].z
 283:     max r6.yw, r6.yyyw, l(0.000000, -127.000000, 0.000000, -127.000000)
 284:     exp r6.w, -r6.w
 285:     mul r6.w, r6.w, cb1[77].y
 286:     lt r7.w, l(0.000000), abs(r6.y)
 287:     exp r8.z, -r6.y
 288:     add r8.z, -r8.z, l(1.000000)
 289:     div r8.z, r8.z, r6.y
 290:     mad r6.y, -r6.y, l(0.240227), l(0.693147)
 291:     movc r6.y, r7.w, r8.z, r6.y
 292:     add r6.z, r6.z, -cb1[80].z
 293:     mul r6.z, r6.z, cb1[80].x
 294:     max r6.z, r6.z, l(-127.000000)
 295:     exp r6.z, -r6.z
 296:     mul r6.z, r6.z, cb1[80].y
 297:     lt r7.w, l(0.000000), abs(r5.w)
 298:     exp r8.z, -r5.w
 299:     add r8.z, -r8.z, l(1.000000)
 300:     div r8.z, r8.z, r5.w
 301:     mad r5.w, -r5.w, l(0.240227), l(0.693147)
 302:     movc r5.w, r7.w, r8.z, r5.w
 303:     mul r5.w, r5.w, r6.z
 304:     mad r5.w, r6.w, r6.y, r5.w
 305:     mad_sat r6.yz, r2.wwww, cb1[78].wwyw, cb1[78].zzxz
 306:     mul r6.x, r6.x, r5.w
 307:     exp r6.x, -r6.x
 308:     min r6.x, r6.x, l(1.000000)
 309:     max r6.x, r6.x, cb1[79].w
 310:     add r6.x, r6.z, r6.x
 311:     add r6.x, r6.y, r6.x
 312:     min r6.x, r6.x, l(1.000000)
 313:     imad r8.y, r0.z, r8.x, r0.y
 314:     ushr r0.yz, r8.xxyx, l(0, 16, 16, 0)
 315:     utof r0.yz, r0.yyzy
 316:     mad r0.yz, r0.yyzy, l(0.000000, 0.000031, 0.000031, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
 317:     mad r0.yz, r0.yyzy, cb1[87].wwww, r3.xxyx
 318:     mul r8.xy, r0.yzyy, cb1[85].xyxx
 319:     mad r0.y, v0.w, cb1[84].x, cb1[84].y
 320:     log r0.y, r0.y
 321:     mul r0.y, r0.y, cb1[84].z
 322:     div r8.z, r0.y, cb1[83].z
 323:     sample_l(texture3d)(float,float,float,float) r8.xyzw, r8.xyzx, t2.xyzw, s1, l(0)
 324:     add r0.y, v0.w, -cb1[86].z
 325:     mul_sat r0.y, r0.y, l(1000000.000000)
 326:     add r8.xyzw, r8.xyzw, l(-0.000000, -0.000000, -0.000000, -1.000000)
 327:     mad r8.xyzw, r0.yyyy, r8.xyzw, l(0.000000, 0.000000, 0.000000, 1.000000)
 328:     add r0.y, -r6.x, l(1.000000)
 329:     dp3_sat r0.z, -r5.xyzx, cb1[81].xyzx
 330:     log r0.z, r0.z
 331:     mul r0.z, r0.z, cb1[82].w
 332:     exp r0.z, r0.z
 333:     mul r9.xyz, r0.zzzz, cb1[82].xyzx
 334:     mad r0.x, r0.x, r2.w, -cb1[81].w
 335:     max r0.x, r0.x, l(0)
 336:     mul r0.x, r0.x, r5.w
 337:     exp r0.x, -r0.x
 338:     min r0.x, r0.x, l(1.000000)
 339:     add r0.x, -r0.x, l(1.000000)
 340:     mul r9.xyz, r0.xxxx, r9.xyzx
 341:     add r0.x, -r6.y, l(1.000000)
 342:     mul r6.yzw, r0.xxxx, r9.xxyz
 343:     mad r0.xyz, cb1[79].xyzx, r0.yyyy, r6.yzwy
 344:     mad r0.xyz, r0.xyzx, r8.wwww, r8.xyzx
 345:     mul r3.x, r6.x, r8.w
 346:   else
 347:     add r3.y, v2.y, -cb0[44].y
 348:     mul r5.w, r3.y, cb1[77].z
 349:     max r5.w, r5.w, l(-127.000000)
 350:     mul r3.y, r3.y, cb1[80].x
 351:     max r3.y, r3.y, l(-127.000000)
 352:     add r6.x, cb0[44].y, -cb1[77].x
 353:     mul r6.x, r6.x, cb1[77].z
 354:     max r6.x, r6.x, l(-127.000000)
 355:     exp r6.x, -r6.x
 356:     mul r6.x, r6.x, cb1[77].y
 357:     lt r6.y, l(0.000000), abs(r5.w)
 358:     exp r6.z, -r5.w
 359:     add r6.z, -r6.z, l(1.000000)
 360:     div r6.z, r6.z, r5.w
 361:     mad r5.w, -r5.w, l(0.240227), l(0.693147)
 362:     movc r5.w, r6.y, r6.z, r5.w
 363:     add r6.y, cb0[44].y, -cb1[80].z
 364:     mul r6.y, r6.y, cb1[80].x
 365:     max r6.y, r6.y, l(-127.000000)
 366:     exp r6.y, -r6.y
 367:     mul r6.y, r6.y, cb1[80].y
 368:     lt r6.z, l(0.000000), abs(r3.y)
 369:     exp r6.w, -r3.y
 370:     add r6.w, -r6.w, l(1.000000)
 371:     div r6.w, r6.w, r3.y
 372:     mad r3.y, -r3.y, l(0.240227), l(0.693147)
 373:     movc r3.y, r6.z, r6.w, r3.y
 374:     mul r3.y, r3.y, r6.y
 375:     mad r3.y, r6.x, r5.w, r3.y
 376:     mad_sat r6.xy, r2.wwww, cb1[78].wyww, cb1[78].zxzz
 377:     mul r2.w, r2.w, r3.y
 378:     exp r2.w, -r2.w
 379:     min r2.w, r2.w, l(1.000000)
 380:     max r2.w, r2.w, cb1[79].w
 381:     add r2.w, r6.y, r2.w
 382:     add r2.w, r6.x, r2.w
 383:     min r3.x, r2.w, l(1.000000)
 384:     add r2.w, -r3.x, l(1.000000)
 385:     dp3_sat r5.x, -r5.xyzx, cb1[81].xyzx
 386:     log r5.x, r5.x
 387:     mul r5.x, r5.x, cb1[82].w
 388:     exp r5.x, r5.x
 389:     mul r5.xyz, r5.xxxx, cb1[82].xyzx
 390:     mad r0.w, r0.w, r1.w, -cb1[81].w
 391:     max r0.w, r0.w, l(0)
 392:     mul r0.w, r0.w, r3.y
 393:     exp r0.w, -r0.w
 394:     min r0.w, r0.w, l(1.000000)
 395:     add r0.w, -r0.w, l(1.000000)
 396:     mul r5.xyz, r0.wwww, r5.xyzx
 397:     add r0.w, -r6.x, l(1.000000)
 398:     mul r5.xyz, r0.wwww, r5.xyzx
 399:     mad r0.xyz, cb1[79].xyzx, r2.wwww, r5.xyzx
 400:   endif
 401:   mul r5.xyz, r3.xxxx, r7.xyzx
 402:   dp3 r0.w, r5.xyzx, l(0.333333, 0.333333, 0.333333, 0.000000)
 403:   mad r1.w, r3.z, r3.z, l(1.000000)
 404:   mul r1.w, r1.w, l(0.059683)
 405:   mad r5.xyz, cb1[74].xyzx, r1.wwww, cb1[76].xyzx
 406:   mad r1.w, -cb1[73].w, cb1[73].w, l(1.000000)
 407:   mul r2.w, r3.w, l(12.566371)
 408:   sqrt r3.y, r3.w
 409:   mul r2.w, r2.w, r3.y
 410:   max r2.w, r2.w, l(0.001000)
 411:   div r1.w, r1.w, r2.w
 412:   mad_sat r3.yzw, cb1[75].xxyz, r1.wwww, r5.xxyz
 413:   mul r3.yzw, r3.yyzw, l(0.000000, 255.000000, 255.000000, 255.000000)
 414:   add r5.xyz, -r7.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 415:   mul r3.yzw, r3.yyzw, r5.xxyz
 416:   mad r0.xyz, r3.yzwy, r3.xxxx, r0.xyzx
 417:   dp3_sat r0.x, r0.xyzx, l(0.333333, 0.333333, 0.333333, 0.000000)
 418:   add r0.x, -r0.x, l(1.000000)
 419:   mul r0.x, r0.x, r0.w
 420:   mul r4.w, r0.x, r4.w
 421: endif
 422: mul r0.x, cb4[0].z, cb4[3].w
 423: mad r0.yzw, -r1.xxyz, cb4[2].xxyz, cb4[3].xxyz
 424: mad r0.xyz, r0.xxxx, r0.yzwy, r2.xyzx
 425: mul r0.w, r4.w, cb4[2].w
 426: add r1.x, l(1.000000), -cb4[0].z
 427: add r1.y, l(1.000000), -cb4[3].w
 428: mad r1.x, r1.y, cb4[0].z, r1.x
 429: mul r0.w, r0.w, r1.x
 430: add r0.xyz, r0.xyzx, l(-1.000000, -1.000000, -1.000000, 0.000000)
 431: mad r4.xyz, r0.wwww, r0.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 432: mov o0.xyzw, r4.xyzw
 433: ret
