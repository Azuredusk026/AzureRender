"""Check the original hair-shadow depth pass at overlapping face pixels."""
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import traceback

key='AZURE_NR_FACE_SHADOW_DEPTH'
root=Path(os.environ[key]).parent if key in os.environ else Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
load=lambda p:json.loads(p.read_bytes())
write=lambda p,j:p.write_text(json.dumps(j,indent=2)+'\n',encoding='utf8')

def fragment_depth(value):
    depth=getattr(value,'depth',None)
    return depth if depth is not None and math.isfinite(depth) else None

def worker(folder):
    import renderdoc as rd
    request=load(folder/'request.json')
    result=dict(status='failed',events={},points=[])
    capture=rd.OpenCaptureFile()
    controller=None
    try:
        assert capture.OpenFile(request['native'],'',None)==rd.ResultCode.Succeeded
        options=rd.ReplayOptions()
        options.forceGPUVendor=rd.GPUVendor.nVidia
        options.forceGPUDeviceID=0x28e0
        status,controller=capture.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and controller
        gpu=controller.GetAPIProperties()
        assert gpu.vendor==options.forceGPUVendor and gpu.pipelineType==rd.GraphicsAPI.D3D11 and not gpu.degraded
        target_depth=None
        color=None
        for event in (1339,1358):
            controller.SetFrameEvent(event,True)
            pipe=controller.GetPipelineState()
            shader=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
            assert sha256(bytes(shader.rawBytes)).hexdigest()==request['events'][str(event)]['shader']
            depth=pipe.GetDepthTarget().resource
            current_color=pipe.GetOutputTargets()[0].resource
            assert str(depth)=='ResourceId::141967' and str(current_color)=='ResourceId::141925'
            target_depth=depth
            color=current_color
            state=controller.GetD3D11PipelineState().outputMerger.depthStencilState
            constants={}
            for index,block in enumerate(shader.constantBlocks):
                if block.fixedBindNumber not in ((0,1) if event==1339 else (1,4)):continue
                binding=pipe.GetConstantBlock(rd.ShaderStage.Fragment,index,0).descriptor
                raw=bytes(controller.GetBufferData(binding.resource,binding.byteOffset,binding.byteSize))
                assert len(raw)%16==0
                offsets={1339:{0:(0,2),1:(0,1)},1358:{1:(0,2,26),4:(0,1,2)}}[event][block.fixedBindNumber]
                rows=list(struct.iter_unpack('<4f',raw))
                constants[str(block.fixedBindNumber)]={str(i):rows[i] for i in offsets}
                assert all(math.isfinite(v) for i in offsets for v in rows[i])
            resource=[r.descriptor.resource for r in pipe.GetReadOnlyResources(rd.ShaderStage.Fragment)
                if shader.readOnlyResources[r.access.index].fixedBindNumber==(0 if event==1339 else 1)]
            assert len(resource)==1 and str(resource[0])=='ResourceId::141928'
            image=bytes(controller.GetTextureData(resource[0],rd.Subresource()))
            assert len(image)==2560*1440*4
            observed_depth=[struct.unpack_from('<f',image,4*((1439-y)*2560+x))[0] for x,y in request['points']]
            result['events'][event]=dict(depthWrite=bool(state.depthWrites), comparison=str(state.depthFunction),
                constants=constants, screenDepth=observed_depth,
                stencilReference=int(state.frontFace.reference),stencilMask=int(state.frontFace.compareMask))
        entries={}
        for event in (1338,1339,1357,1358):
            controller.SetFrameEvent(event,True)
            depth=bytes(controller.GetTextureData(target_depth,rd.Subresource()))
            assert len(depth)==2560*1440*8,(event,len(depth))
            entries[event]=dict(sha256=sha256(depth).hexdigest(),values=[])
            for x,y in request['points']:
                idx=8*((1439-y)*2560+x)
                z,stencil=struct.unpack_from('<fI',depth,idx)
                entries[event]['values'].append([z,stencil])
        result['depth']=entries
        result['sharedScreenDepthSamples']=result['events'][1339]['screenDepth']==result['events'][1358]['screenDepth']
        for i,(x,y) in enumerate(request['points']):
            fragments=[]
            for event,target in ((1339,target_depth),(1358,color)):
                controller.SetFrameEvent(event,True)
                hist=controller.PixelHistory(target,x,1439-y,rd.Subresource(),rd.CompType.Typeless)
                for fragment in hist:
                    if fragment.eventId!=event:continue
                    fragments.append(dict(event=int(fragment.eventId),primitive=int(fragment.primitiveID),
                        committed=fragment.Passed(),depthFailed=bool(fragment.depthTestFailed),
                        stencilFailed=bool(fragment.stencilTestFailed),cull=bool(fragment.backfaceCulled),
                        discarded=bool(fragment.shaderDiscarded),rgb=[v if math.isfinite(v) else None for v in list(fragment.shaderOut.col.floatValue)[:3]],
                        shaderDepth=fragment_depth(fragment.shaderOut),
                        postDepth=fragment_depth(fragment.postMod),
                        postRgb=[v if math.isfinite(v) else None for v in list(fragment.postMod.col.floatValue)[:3]]))
            result['points'].append(dict(point=[x,y],fragments=fragments))
        result['status']='qualified'
    except Exception:result['error']=traceback.format_exc()
    finally:
        if controller:controller.Shutdown()
        capture.Shutdown()
        write(folder/'results.json',result)
    os._exit(0 if result['status']=='qualified' else 1)

def launch():
    from hashlib import file_digest
    lock=load(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==root
    job=load(grid/'native-face-masks/request.json')
    with Path(job['native']).open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==job['captureSha256']
    source=load(root/'late-overlay-replay.json')
    assert source['status']=='qualified'
    job['events']={str(e):source['native'][str(e)] for e in (1339,1358)}
    probe=load(root/'face-multiply-overlap-audit.json')
    overlapping=[row['point'] for row in probe['devices']['nvidia']['details'] if len(row['triangles'])==2]
    assert len(overlapping)==12
    job['points']=overlapping+[[1321,271],[1275,271]]
    folder=root/'face-shadow-native-depth'
    folder.mkdir(exist_ok=True)
    write(folder/'request.json',job)
    startup=subprocess.STARTUPINFO()
    startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=0
    with (folder/'replay.log').open('wb') as log:
        proc=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__))],
            cwd=folder,env=dict(os.environ,**{key:str(folder)}),stdout=log,stderr=subprocess.STDOUT,
            startupinfo=startup,timeout=165)
    results=load(folder/'results.json')
    assert proc.returncode==0 and results['status']=='qualified',results.get('error')
    metadata=load(root/'face-shadow-structured-capture/results.json')['bindings']
    for event,entry in results['events'].items():
        cpu=metadata[event]
        assert entry['depthWrite']==(cpu['descriptor']['DepthWriteMask']=='D3D11_DEPTH_WRITE_MASK_ALL')
        assert entry['stencilReference']==cpu['reference'] and entry['stencilMask']==cpu['descriptor']['StencilReadMask']
    probe=load(root/'face-multiply-overlap-audit.json')
    predicted={tuple(row['point']):row for row in probe['unobstructedDepthPrepassOwners']}
    measured=[]
    for i,row in enumerate(results['points']):
        xy=tuple(row['point'])
        passed=[f['primitive'] for f in row['fragments'] if f['event']==1358 and f['committed']]
        prepass=[f['primitive'] for f in row['fragments'] if f['event']==1339 and f['committed']]
        comparison=predicted.get(xy)
        depths={event:record['values'][i][0] for event,record in results['depth'].items()}
        winner=None if comparison is None else comparison['winner']
        measured.append(dict(point=row['point'],predicted=winner,prepassCommitted=prepass,colorCommitted=passed,depth=depths,
                             depthAdvanced=depths['1339']>depths['1338'],depthRetained=depths['1358']==depths['1357']))
    write(folder/'comparison.json',dict(status='measured',points=measured))
    print(json.dumps(measured))

if key in os.environ:worker(Path(os.environ[key]))
elif __name__=='__main__':launch()







