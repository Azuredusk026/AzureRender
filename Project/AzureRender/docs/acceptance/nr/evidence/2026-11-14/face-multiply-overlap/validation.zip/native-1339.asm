Shader hash 63007967-d491d1e5-368bea41-6d7be41b

ps_5_0
      dcl_globalFlags refactoringAllowed
      dcl_constantbuffer cb0[3], immediateIndexed
      dcl_constantbuffer cb1[2], immediateIndexed
      dcl_sampler s0, mode_default
      dcl_resource_texture2d (float,float,float,float) t0
      dcl_input_ps_siv linear noperspective v0.xyw, position
      dcl_output o0.xyzw
      dcl_temps 1
   0: lt r0.x, l(0.500000), cb1[0].w
   1: if_nz r0.x
   2:   mul r0.xy, v0.xyxx, cb0[0].zwzz
   3:   sample_l(texture2d)(float,float,float,float) r0.x, r0.xyxx, t0.xyzw, s0, l(0)
   4:   mad r0.x, cb0[2].z, r0.x, cb0[2].w
   5:   div r0.x, l(1.000000, 1.000000, 1.000000, 1.000000), r0.x
   6:   add r0.x, r0.x, -v0.w
   7:   add r0.x, -abs(r0.x), cb1[1].x
   8:   lt r0.x, r0.x, l(0)
   9:   discard_nz r0.x
  10: endif
  11: mov o0.xyzw, l(1.000000, 1.000000, 1.000000, 1.000000)
  12: ret
