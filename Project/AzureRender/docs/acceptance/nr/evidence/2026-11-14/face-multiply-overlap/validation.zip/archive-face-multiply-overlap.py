from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

run=Path(__file__).resolve().parent
out=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/face-multiply-overlap'
read=lambda path:json.loads(path.read_bytes())
sha=lambda path:sha256(path.read_bytes()).hexdigest()
actual=read(run/'face-pair-native-ownership.json')
hypothesis=read(run/'face-multiply-overlap-audit.json')
assert actual['status']=='face-pair-native-ownership' and hypothesis['rasterMultiple']==12
assert hypothesis['sourceCovered']==264
for index,device in enumerate(('nvidia','intel')):
    record=actual['devices'][device]
    assert record['full']['overOne']==(366,376)[index]
    assert record['full']['overEight']==(64,66)[index]
    row=hypothesis['devices'][device]
    assert row['knownDoubleAppliesWithMultipleTriangles']==12
    assert row['residuals']==(20,29)[index]
    assert max(item['singleApplicationError'] for item in row['details'] if len(item['triangles'])==2)==24
files=[Path(__file__).name,'face-multiply-overlap-audit.py','face-multiply-overlap-audit.json',
       'score-final-face-ownership.py','face-pair-native-ownership.json','native-1339.asm','native-1358.asm']
keys={name:sha(run/name) for name in files}
out.mkdir(parents=True,exist_ok=True)
zip_path=out/'validation.zip'
with ZipFile(zip_path,'w',ZIP_DEFLATED) as archive:
    for name in files:archive.write(run/name,name)
with ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    assert {name:sha256(archive.read(name)).hexdigest() for name in files}==keys
report=dict(status='verified-pixel-comparison',overallVisualAcceptance='failed-user-review',
    nativeDepthReadback='pending',referenceSha256=actual['referenceSha256'],coveredFaceHairShadow=264,
    devices={dev:dict(**{k:v for k,v in detail.items() if k!='details'},fullFace=actual['devices'][dev]['full'],
                      frameSha256=actual['devices'][dev]['playerFrameSha256']) for dev,detail in hypothesis['devices'].items()},
    archive=dict(sha256=sha(zip_path),members=keys))
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(report['archive']['sha256'])
