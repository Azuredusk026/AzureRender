from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

run=Path(__file__).resolve().parent
out=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/face-multiply-overlap'
read=lambda path:json.loads(path.read_bytes())
sha=lambda path:sha256(path.read_bytes()).hexdigest()
actual=read(run/'face-pair-native-ownership.json')
hypothesis=read(run/'face-multiply-overlap-audit.json')
structured=read(run/'face-shadow-structured-capture/results.json')
depth_path=run/'face-shadow-native-depth'
depth_result=read(depth_path/'results.json')
depth_comparison=read(depth_path/'comparison.json')
later=read(run/'face-shadow-later-draws.json')
assert structured['status']=='qualified' and not structured['replayStarted']
assert structured['bindings']['1339']['descriptor']['DepthWriteMask']=='D3D11_DEPTH_WRITE_MASK_ALL'
assert structured['bindings']['1358']['descriptor']['DepthWriteMask']=='D3D11_DEPTH_WRITE_MASK_ZERO'
assert actual['status']=='face-pair-native-ownership' and hypothesis['rasterMultiple']==12
assert hypothesis['sourceCovered']==264
assert len(hypothesis['unobstructedDepthPrepassOwners'])==12
assert all(point['depthGap']>1.e-6 for point in hypothesis['unobstructedDepthPrepassOwners'])
assert structured['bindings']['1339']['rasterizer']==structured['bindings']['1358']['rasterizer']
assert depth_result['status']=='qualified' and depth_result['sharedScreenDepthSamples']
assert depth_result['events']['1339']['constants']['1']['0'][3]==0
assert depth_result['events']['1358']['constants']['4']['0'][3]==0
assert depth_result['events']['1358']['constants']['1']['26'][0]==-1
assert len(depth_comparison['points'])==14
for row in depth_comparison['points']:
    assert row['depthAdvanced'] and row['depthRetained']
    assert row['depth']['1339']==row['depth']['1357']
    assert len(row['colorCommitted'])==1 and row['colorCommitted'][0] in row['prepassCommitted']
    if row['predicted'] is not None:assert row['colorCommitted']==[row['predicted']]
assert later['later'][0]['changedPixels']==27832 and later['later'][0]['sharedWithNativeHairShadow']==0
for index,device in enumerate(('nvidia','intel')):
    record=actual['devices'][device]
    assert record['full']['overOne']==(366,376)[index]
    assert record['full']['overEight']==(64,66)[index]
    row=hypothesis['devices'][device]
    assert row['knownDoubleAppliesWithMultipleTriangles']==12
    assert row['residuals']==(20,29)[index]
    assert max(item['singleApplicationError'] for item in row['details'] if len(item['triangles'])==2)==24
files=[Path(__file__).name,'face-multiply-overlap-audit.py','face-multiply-overlap-audit.json',
       'score-final-face-ownership.py','face-pair-native-ownership.json','native-1339.asm','native-1358.asm',
       'face-shadow-structured-capture.py','face-shadow-structured-capture/results.json',
       'face-shadow-structured-capture/request.json','quality-legacy-material-cpu-retest.xml',
       'face-shadow-native-depth-control.py','face-shadow-native-depth/request.json',
       'face-shadow-native-depth/results.json','face-shadow-native-depth/comparison.json',
       'face-shadow-later-draws.py','face-shadow-later-draws.json']
keys={name:sha(run/name) for name in files}
out.mkdir(parents=True,exist_ok=True)
zip_path=out/'validation.zip'
with ZipFile(zip_path,'w',ZIP_DEFLATED) as archive:
    for name in files:archive.write(run/name,name)
with ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    assert {name:sha256(archive.read(name)).hexdigest() for name in files}==keys
report=dict(status='verified-pixel-comparison',overallVisualAcceptance='failed-user-review',
    nativeDepthReadback=dict(status='qualified',positions=14,overlaps=12,
        nearestPassed=12,screenDepthSuppressionEnabled=False,depthUnchangedInColorPass=14),
    nativeDepthPipeline=structured['bindings'],nativeCaptureSha256=structured['captureSha256'],
    nativeLaterDraw=later['later'][0],
    referenceSha256=actual['referenceSha256'],coveredFaceHairShadow=264,
    depthPrepassGeometryPrediction=hypothesis['unobstructedDepthPrepassOwners'],
    devices={dev:dict(**{k:v for k,v in detail.items() if k!='details'},fullFace=actual['devices'][dev]['full'],
                      frameSha256=actual['devices'][dev]['playerFrameSha256']) for dev,detail in hypothesis['devices'].items()},
    archive=dict(sha256=sha(zip_path),members=keys))
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(report['archive']['sha256'])



