"""Audit the retained face-only results at original native ownership boundaries."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import runpy

import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
scorer=runpy.run_path(str(grid/'static-quality.py'))
eye=runpy.run_path(str(run/'iris-overlay-main-frame-isolation.py'),run_name='native_transfer')
frames=scorer['stages']/'post-opaque-ownership'
manifest=read(frames/'manifest.json')
image=lambda path:scorer['image'](path).astype(np.int16)
source=image(scorer['reference_path'])
with Image.open(grid/'native-face-masks/face.png') as item:face=np.asarray(item.convert('L'))>0
assert int(face.sum())==3663

def original_event(event):
    row,=[r for r in manifest['events'] if r['event']==event]
    names=(f'{event}-{event-1}.bin.gz',f'{event}-{event}.bin.gz')
    assert set(row['files'])==set(names)
    raw=[]
    for name in names:
        payload=gzip.decompress((frames/name).read_bytes())
        assert len(payload)==4*2560*1440
        raw.append(np.frombuffer(payload,'<u4').reshape(1440,2560)[::-1])
    return raw

scopes={}
for event in (1230,1358):
    first,last=original_event(event)
    coverage=(first!=last)&face
    scopes[event]=coverage
assert [int(mask.sum()) for mask in scopes.values()]==[41,264]
assert not (scopes[1230]&scopes[1358]).any()
scopes['opaque-face']=face&~(scopes[1230]|scopes[1358])

def statistics(a,b,coverage):
    d=np.max(abs(a[coverage]-b[coverage]),axis=1)
    return dict(pixels=len(d),overOne=int((d>1).sum()),overEight=int((d>8).sum()),peak=int(d.max()))

radial=run.parent/'20261114-051632-face-local-radial-light-retest-ea8fb6'
result={}
for device in ('nvidia','intel'):
    good=run/f'face-{device}-pair'
    baseline=image(radial/f'production-{device}-enabled/frames/frame_000000.png')
    current_file=good/'frames/frame_000000.png'
    receipt=read(good/'results.json')
    assert sha(current_file)==receipt['frameSha256']
    first_only_path=run/f'face-{device}-1230/frames/frame_000000.png'
    assert sha(first_only_path)==read(first_only_path.parents[1]/'results.json')['frameSha256']
    first_only=image(first_only_path)
    current=image(current_file)
    full=statistics(current,source,face)
    assert full['overOne']==receipt['faceOverOne'][1]
    assert full['overEight']==receipt['faceOverEight'][1]
    groups={}
    for name,scope in scopes.items():
        stats=dict(baseline=statistics(baseline,source,scope),pair=statistics(current,source,scope),
                   actualChanged=int(((current!=baseline).any(2)&scope).sum()))
        if isinstance(name,int):
            pre,post=original_event(name)
            original_a=eye['unpack'](pre[scope])
            original_b=eye['unpack'](post[scope])
            native_factor=np.divide(original_b,original_a,out=np.ones_like(original_a),where=original_a>0)
            prior=baseline if name==1230 else first_only
            aa,bb=(eye['linear'](frame[scope]) for frame in (prior,current))
            estimated=eye['display'](aa*native_factor)
            actual_factor=np.divide(bb,aa,out=np.ones_like(bb),where=aa>0)
            estimates=np.abs(estimated-current[scope]).max(1)
            stats['pairAgainstNativeMultiplication']=dict(overOne=int((estimates>1).sum()),peak=int(estimates.max()))
            y,x=np.where(scope)
            stats['factorResiduals']=[dict(point=[int(x[i]),int(y[i])],error=int(estimates[i]),
                expected=estimated[i].tolist(),actual=current[y[i],x[i]].tolist(),
                nativeFactor=native_factor[i].tolist()) for i in np.flatnonzero(estimates>1)]
            stats['inferredFactorMedianAbsoluteError']=np.median(np.abs(actual_factor-native_factor),axis=0).tolist()
            stats['sourcePostToFinalPeak']=int(np.abs(eye['display'](original_b)-source[scope]).max())
        groups[str(name)]=stats
    assert sum(v['pair']['overOne'] for v in groups.values())==full['overOne']
    assert sum(v['pair']['overEight'] for v in groups.values())==full['overEight']
    result[device]=dict(full=full,owner=groups,playerFrameSha256=sha(current_file))
output=dict(status='face-pair-native-ownership',referenceSha256=sha(scorer['reference_path']),devices=result)
(run/'face-pair-native-ownership.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf8')
for dev,record in result.items():
    for event in ('1230','1358'):
        print(dev,event,sorted(record['owner'][event]['factorResiduals'],key=lambda row:-row['error'])[:6])


