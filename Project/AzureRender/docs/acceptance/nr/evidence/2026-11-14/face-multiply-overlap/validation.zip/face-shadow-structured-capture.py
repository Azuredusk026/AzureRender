"""Read capture command metadata without starting a graphics replay."""
from pathlib import Path
import json
import os
from hashlib import sha256
import traceback

import renderdoc as rd

out=Path(os.environ['AZURE_FACE_STRUCTURED_OUTPUT'])
request=json.loads((out/'request.json').read_bytes())
report=dict(status='failed')
capture=rd.OpenCaptureFile()
try:
    digest=sha256()
    with Path(request['source']).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    assert digest.hexdigest()==request['captureSha256']
    report['captureSha256']=digest.hexdigest()
    assert capture.OpenFile(request['source'],'rdc',None)==rd.ResultCode.Succeeded
    assert hasattr(capture,'GetStructuredData')
    structured=capture.GetStructuredData()
    assert structured and structured.chunks
    report['structuredChunks']=len(structured.chunks)
    def describe(node):
        if node.NumChildren():
            return {str(node.GetChild(i).name):describe(node.GetChild(i)) for i in range(node.NumChildren())}
        kind=str(node.type.name)
        if kind.endswith(' *'):return str(node.AsResourceId())
        if kind=='bool':return bool(node.AsBool())
        if kind.startswith(('uint','int')):return int(node.AsInt())
        if kind=='float':return float(node.AsFloat())
        return str(node.AsString())
    states={}
    rasterizers={}
    for ix,chunk in enumerate(structured.chunks):
        if 'CreateDepthStencilState' in str(chunk.name):
            values=describe(chunk)
            states[values['pState']]=dict(chunk=ix,descriptor=values['Descriptor'])
        if 'CreateRasterizerState' in str(chunk.name):
            values=describe(chunk)
            key=next((name for name in ('pState','pRasterizerState') if name in values),None)
            if key in values:rasterizers[values[key]]=values
    bindings={}
    for event,(first,last) in request['events'].items():
        position=max(i for i in range(first,last) if str(structured.chunks[i].name).endswith('OMSetDepthStencilState'))
        raster=max(i for i in range(last) if str(structured.chunks[i].name).endswith('RSSetState'))
        values=describe(structured.chunks[position])
        identity=values['pDepthStencilState']
        bindings[event]=dict(id=identity,reference=values['StencilRef'],**states[identity])
        bindings[event]['definitionChunk']=bindings[event].pop('chunk')
        bindings[event]['bindingChunk']=position
        rasterizer=describe(structured.chunks[raster])['pRasterizerState']
        bindings[event]['rasterizer']=dict(id=rasterizer,bindingChunk=raster,definition=rasterizers.get(rasterizer))
    pre,overlay=(bindings[event] for event in ('1339','1358'))
    assert pre['rasterizer']['id']==overlay['rasterizer']['id']
    rasterizer=pre['rasterizer']['definition']['Descriptor']
    assert rasterizer['DepthBias']==0 and rasterizer['SlopeScaledDepthBias']==0 and rasterizer['DepthBiasClamp']==0
    assert pre['descriptor']['DepthWriteMask']=='D3D11_DEPTH_WRITE_MASK_ALL'
    assert overlay['descriptor']['DepthWriteMask']=='D3D11_DEPTH_WRITE_MASK_ZERO'
    for binding in (pre,overlay):
        state=binding['descriptor']
        assert binding['reference']==4 and state['StencilReadMask']==20
        assert state['DepthEnable'] and state['StencilEnable'] and state['DepthFunc']=='D3D11_COMPARISON_GREATER_EQUAL'
    report['bindings']=bindings
    report.update(status='qualified',replayStarted=False)
except Exception:
    report['error']=traceback.format_exc()
finally:
    capture.Shutdown()
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
os._exit(0 if report['status']=='qualified' else 1)







