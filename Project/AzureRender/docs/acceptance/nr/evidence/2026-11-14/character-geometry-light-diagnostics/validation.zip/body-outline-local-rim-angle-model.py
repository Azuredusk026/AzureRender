"""Predict the Player material-rim delta using the staged scene inputs."""
from pathlib import Path
import json
import runpy
import numpy as np

run=Path(__file__).resolve().parent
g=runpy.run_path(str(run/'body-outline-uv-albedo.py'))
normals=runpy.run_path(str(run/'body-outline-screen-normal-states.py'))
read=g['read']
level=read(run/'body-native-lit-outline-blend-depth.azurelevel')
node_map={n['id']:n for n in level['nodes']}
pos_of=lambda node:np.asarray(node['components']['azure.transform']['data']['translation'])
eye=pos_of(node_map['camera'])
capture=read(run/'body-blend-nvidia/frames/capture_manifest.json')
up=np.asarray(capture['cameraUp'])
axis=np.array([0.,up[2],-up[1]])
source=read(run/'body-outline-source-footprint.json')
def unit(v):
    return v/max(np.linalg.norm(v),1e-12)

def sat(v):
    return np.clip(v,0,1)

def light_sample(p,light):
    shape=light['shape']
    direction=np.asarray(shape['direction'])
    incoming=pos_of(node_map[light['nodeId']])-p
    options=shape['characterResponse']
    assert not shape['influenceBox']['enabled']
    if options.get('projectedDistance'):
        incoming=direction*(incoming@direction)
    d2=incoming@incoming
    toward=unit(incoming)
    s=d2/light['radius']**2
    if shape['falloff']=='smooth-inverse-square':
        attenuation=max(1-s*s,0)**2/(1+d2)
    else:
        assert shape['falloff']=='range-power'
        attenuation=max(1-s,0)**shape['falloffExponent']
    if shape['type']=='spot':
        outer,inner=np.cos([shape['outerCone'],shape['innerCone']])
        attenuation*=sat(((-toward)@direction-outer)/max(inner-outer,1.e-6))**2
    return attenuation,toward

def display(v):
    x=np.clip(v,0,1)
    return np.rint(np.where(x<=.0031308,12.92*x,1.055*x**(1/2.4)-.055)*255).astype('i2')

def linear(v):
    x=np.asarray(v)/255.
    return np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)

scorer=runpy.run_path(str(g['grid']/'static-quality.py'))
image=lambda p:scorer['image'](p).astype('i2')
reference=image(scorer['reference_path'])
actual=image(run/'body-blend-nvidia/frames/frame_000000.png')
lights=[l for l in level['lights'] if l['shape'].get('characterResponse',{}).get('composition')=='material-rim']
blends=[l for l in level['lights'] if l['shape'].get('characterResponse',{}).get('composition')=='color-blend']
assert len(lights)==3 and len(blends)==1
blend=blends[0]
blend_source=read(run/'body-outline-retained-light-trace.json')
blend_controls={tuple(row['point']):next(l for l in row['lights'] if l['type']=='blend') for row in blend_source['points']}
fixed_controls=[]
positions=g['vertices'][:,6:9]
rows=[]
for x,y,_,_,i,_,packed,_ in source['points']:
    tri=g['tri'][i:i+1]
    bary,_=g['bary'](np.array([x+.5,y+.5]),tri,g['screen'])
    w=bary[0]*g['pixel_w'][tri[0]]
    p=(w@positions[tri[0]])/w.sum()*[-1,1,1]+eye
    normal=normals['decode'](np.uint32(packed))*[-1,1,1]
    v=unit(eye-p)
    base=g['output'](x,y,i)
    base=np.asarray(base['sampled']['flip-0'][base['mip']])
    contributions={}
    ideal=np.zeros(3)
    for l in lights:
        opt=l['shape']['characterResponse']
        att,toward=light_sample(p,l)
        planar=unit(toward-axis*(toward@axis))
        edge=1-abs(normal@v)
        t=sat((edge-(.8-.6*opt['width']))/(.1+.2*opt['width']))
        t=t*t*(3-2*t)
        color=.5+opt['surfaceTint']*(base*.96-.5)
        add=.25*att*np.asarray(l['color'])*l['intensity']*color*t*sat(normal@planar)
        contributions[l['id']]=add
        ideal+=add
    att,_=light_sample(p,blends[0])
    gain=1-att*blend['shape']['characterResponse']['strength']
    if (x,y) in blend_controls:
        c=blend_controls[x,y]
        assert np.max(abs(np.asarray(c['color'])-blend['color']))<1.e-7
        fixed_controls.append(dict(point=[x,y],modeledWeight=1-gain,nativeWeight=c['weight'],absoluteWeightError=abs(1-gain-c['weight'])))
    ideal*=gain
    final=display(linear(actual[y,x])+ideal)
    error=int(np.abs(actual[y,x]-reference[y,x]).max())
    err_with=int(np.abs(final-reference[y,x]).max())
    rows.append(dict(point=[x,y],baselineError=error,bestHypotheticalRimError=err_with,
        maxPossibleRimAdd=ideal.tolist(),perLightUpperBound={k:v.tolist() for k,v in contributions.items()},
        native=reference[y,x].tolist(),actual=actual[y,x].tolist(),hypothetical=final.tolist()))
grid=np.asarray([[r['baselineError'],r['bestHypotheticalRimError']] for r in rows])
report=dict(status='approximate-existing-player-rim-response',points=len(rows),
    modelScope='native raster addresses and normals, candidate material and scene lights, spot cones converted from radians, unit radial visibility',
    colorBlendControls=fixed_controls,
    overEight=(grid>8).sum(0).tolist(),improved=int((grid[:,1]<grid[:,0]).sum()),worsened=int((grid[:,1]>grid[:,0]).sum()),
    maximum=grid.max(0).tolist(),worst=sorted(rows,key=lambda row:-row['baselineError'])[:12])
(run/'body-outline-local-rim-angle-model.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
assert len(fixed_controls)==4 and max(row["absoluteWeightError"] for row in fixed_controls)<1.e-5
print(json.dumps(report))




