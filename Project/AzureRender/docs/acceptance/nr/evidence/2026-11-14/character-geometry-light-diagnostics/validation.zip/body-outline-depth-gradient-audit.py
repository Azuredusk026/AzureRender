"""Check where the raster depth samples depart from the snapped barycentric plane."""
from pathlib import Path
import json
import runpy
import numpy as np

run=Path(__file__).resolve().parent
g=runpy.run_path(str(run/'body-outline-uv-albedo.py'))
read=g['read']
f=read(run/'body-outline-source-footprint.json')
fail=read(run/'body-outline-unqualified-depth-probe.json')
cases={tuple(row[:2]):row[4] for row in f['points']}
precise=set(cases)
cases.update({tuple(row['point']):row['inside'][0]['triangle'] for row in fail['records']})
assert len(cases)==1184
records=[]
for (x,y),i in cases.items():
    index=g['tri'][i]
    triangle=g['pos'][index]
    raw=g['screen'][index]
    z=g['pixel_z'][index]
    point=np.array([x+.5,y+.5])
    shifted=triangle-triangle[0]
    dz=z-z[0]
    grad=np.linalg.solve(shifted[1:],dz[1:])
    perfect=np.linalg.solve((raw-raw[0])[1:],dz[1:])
    position=point-triangle[0]
    actual=float(g['depth'][y,x])
    fit=float(z[0]+position@grad)
    unsnapped=float(z[0]+(point-raw[0])@perfect)
    maximum_vertex_delta=float(np.abs(raw-triangle).max())
    depth_rounding_bound=2*maximum_vertex_delta*np.linalg.norm(grad,ord=1)+1.5e-8
    signed=actual-fit
    records.append(dict(point=[x,y],primitive=int(i),slope=grad.tolist(),
        snappedDepthError=signed,unsnappedDepthError=actual-unsnapped,
        expectedBoundFromPositionPrecision=float(depth_rounding_bound),withinBound=bool(abs(signed)<=depth_rounding_bound),
        previousStatus='precise' if (x,y) in precise else 'pending'))
rows=[r for r in records if r['previousStatus']=='pending']
assert len(rows)==66
assert all(r['withinBound'] for r in rows)
qualified=read(g['grid']/'native-body-outline-depth/cpu-grid-raster.json')['256:-1']
assert qualified['passed']==qualified['matches']==1184 and qualified['missing']==qualified['extra']==0
summ=dict(pixels=len(rows),withinPositionPrecisionBound=sum(r['withinBound'] for r in rows),
    snappedMax=max(abs(r['snappedDepthError']) for r in rows),
    rangeOfShallowestPixelDepthSlope=[float(v) for v in np.quantile(
        [max(abs(q) for q in r['slope']) for r in rows],[0,.5,1])])
output=dict(status='depth-precision-diagnostic',nativeCoverage=1184,coverageControl=qualified,unresolved=summ,records=rows)
(run/'body-outline-depth-gradient-audit.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf8')
print(json.dumps(summ))
