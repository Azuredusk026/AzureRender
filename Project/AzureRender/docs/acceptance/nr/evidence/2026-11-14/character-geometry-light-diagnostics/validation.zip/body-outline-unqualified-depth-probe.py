"""Locate the expected depth triangle without excluding uncovered candidates."""
from pathlib import Path
import json
import runpy
import numpy as np

run=Path(__file__).resolve().parent
g=runpy.run_path(str(run/'body-outline-uv-albedo.py'))
base=g['read'](run/'body-outline-source-footprint.json')
assert len(base['missing'])==66
tri=g['tri']
records=[]
for x,y,_ in base['missing']:
    q=np.array([x+.5,y+.5])
    bary,area=g['bary'](q,tri,g['pos'])
    goal=g['depth'][y,x]
    initial=g['orig_depth'][y,x]
    depth=(bary*g['pixel_z'][tri]).sum(1)
    triangle_min=bary.min(1)
    close=np.flatnonzero((area<0)&(triangle_min>=-.01)&(np.abs(depth-goal)<=1.5e-8))
    inside=np.flatnonzero((area<0)&(triangle_min>=0)&(depth>initial))
    info=lambda idx:[dict(triangle=int(i),boundaryWeight=float(triangle_min[i]),depthError=float(depth[i]-goal))
                     for i in idx]
    records.append(dict(point=[x,y],nearBoundary=info(close),inside=info(inside),depth=float(goal)))
matched=[r for r in records if r['nearBoundary']]
result=dict(status='reference-depth-boundary-diagnostic',points=len(base['missing']),
    approximateCoverageDepthMatches=len(matched),singleTriangleDepthMatches=sum(len(r['nearBoundary'])==1 for r in matched),
    records=records)
(run/'body-outline-unqualified-depth-probe.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='records'}))
