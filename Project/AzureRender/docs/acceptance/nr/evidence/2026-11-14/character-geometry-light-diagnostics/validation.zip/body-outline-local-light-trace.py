"""Reconcile each native outline light with its traced source registers."""
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np

run = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_bytes())
retained = run.parent/'20261114-032642-body-outline-native-shading-a58fc7'

def measure(point, states, complete):
    lamps = []
    start = finish = None
    pending = None
    light_id = None
    blend = {}
    def rgb(register, channels=slice(0,3)):
        return np.asarray(state[register],dtype=float)[channels]
    for step,state in states:
        if step == 445:
            start = rgb('r14')
        elif step == 464:
            light_id = int(np.asarray([rgb('r12',3)],dtype='<f4').view('<u4')[0])
            blend = {}
        elif step == 616:
            blend['irradiance'] = float(rgb('r11',0))
        elif step == 618:
            blend['weight'] = float(rgb('r11',2))
            blend['colorDifference'] = rgb('r18',slice(1,4))
        elif step == 771:
            pending = dict(type='ordinary',lightId=light_id,start=rgb('r15'),shadowWeight=float(rgb('r12',3)))
        elif step == 791:
            assert pending is not None
            pending.update(type='edge-rim',edge=rgb('r5',3))
        elif step == 810:
            assert pending is not None
            pending.update(surfaceTint=rgb('r21').tolist(),directionalFacing=float(rgb('r16',2)),
                           falloffAndBand=float(rgb('r11',0)))
        elif step == 814:
            assert pending is not None
            pending.update(type='specular-only')
        elif step == 828:
            assert pending is not None
            pending['referenceContribution'] = rgb('r11')*rgb('r16')
        elif step == 829 and pending is not None:
            delta = rgb('r15') - pending.pop('start')
            reconstructed = pending.pop('referenceContribution')
            maximum_error = float(abs(delta-reconstructed).max())
            assert np.isfinite(delta).all() and maximum_error<3.e-6, (point, delta, reconstructed)
            lamps.append(dict(**pending,delta=(.25*delta).tolist(),termError=maximum_error))
            pending = None
        elif step == 833:
            previous = rgb('r15')
        elif step == 834:
            value = rgb('r15') - previous
            if np.max(abs(value)) > 1.e-8:
                weight = blend['weight']
                source = previous + blend['colorDifference']
                maximum_error = float(abs(value-weight*blend['colorDifference']).max())
                assert maximum_error<3.e-6, (point, value, blend)
                lamps.append(dict(type='blend',lightId=light_id,delta=(.25*value).tolist(),weight=weight,
                                  attenuation=blend['irradiance'],color=source.tolist(),termError=maximum_error))
        elif step == 844:
            finish = rgb('r14')
    assert start is not None and finish is not None and np.isfinite(np.r_[start,finish]).all()
    total = .25*(finish-start)
    if complete:
        observed = sum((np.asarray(row['delta']) for row in lamps),np.zeros(3))
        assert np.max(abs(total-observed))<3.e-6, (point,total,observed,lamps)
    return dict(point=point,nativeMain=(.25*start).tolist(),nativeTotal=total.tolist(),lights=lamps)

def chronological(path):
    state={}
    for step,changes in read(path):
        state.update(changes)
        yield step,state

def measure_retained(point, state):
    def lanes(step, register, select=slice(0,3)):
        return np.asarray(state[str(step)][register],dtype=float)[select]
    main=lanes(445,'r14')
    finish=lanes(844,'r14')
    saved=lanes(833,'r15')
    blended=lanes(834,'r15')
    compared=lanes(618,'r18',slice(1,4))
    weight=float(lanes(618,'r11',2))
    attenuation=float(lanes(616,'r11',0))
    difference=blended-saved
    assert np.max(abs(difference-weight*compared))<3.e-6
    rim=lanes(829,'r15')-lanes(771,'r15')
    observed=[dict(type='edge-rim',directionalFacing=float(lanes(810,'r16',2)),delta=(.25*rim).tolist()),
        dict(type='blend',weight=weight,attenuation=attenuation,color=(compared+saved).tolist(),delta=(.25*difference).tolist())]
    return dict(point=point,nativeMain=(.25*main).tolist(),nativeTotal=(.25*(finish-main)).tolist(),lights=observed)

only_retained = sys.argv[1:] == ['retained']
assert only_retained or not sys.argv[1:]
report=read((retained/'native-results.json') if only_retained else (run/'trace-body-outline-source.json'))
assert report['status']=='qualified'
points=[]
for item in report['samples' if only_retained else 'points']:
    path=(retained if only_retained else run)/item['path' if only_retained else 'file']
    assert sha256(path.read_bytes()).hexdigest()==item['sha256']
    point=[item['x'],item['y']] if only_retained else item['point']
    points.append(measure_retained(point,read(path)) if only_retained else measure(point,chronological(path),True))
if only_retained:
    for row in points:
        blend,=[light for light in row['lights'] if light['type']=='blend']
        assert np.max(abs(np.asarray(row['nativeTotal'])-blend['delta']))<3.e-6
        assert np.allclose(blend['color'],[.086648144,.086648144,.104130924],atol=1.e-7,rtol=0)
        assert abs(blend['weight']-.7*blend['attenuation'])<1.e-7
        rim,=[light for light in row['lights'] if light['type']=='edge-rim']
        assert rim['directionalFacing']==0 and rim['delta']==[0,0,0]
result=dict(status='native-outline-per-light',scope='retained-last-visits' if only_retained else 'chronological',points=points)
name='body-outline-retained-light-trace.json' if only_retained else 'body-outline-local-light-trace.json'
(run/name).write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))

