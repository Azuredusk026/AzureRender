from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
from xml.etree import ElementTree

run = Path(__file__).resolve().parent
out = run.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/character-geometry-light-diagnostics'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: sha256(p.read_bytes()).hexdigest()

geometry = read(run/'body-outline-depth-gradient-audit.json')
paint = read(run/'hair-native-mask-audit.json')['summary']
retained = read(run/'body-outline-retained-light-trace.json')
rim = read(run/'body-outline-local-rim-angle-model.json')
assert geometry['unresolved']['pixels']==geometry['unresolved']['withinPositionPrecisionBound']==66
assert geometry['coverageControl']['matches']==1184
assert paint['colorWritePixels']==17017 and paint['capturedPrimitiveMatches']==4
assert paint['residuals']==31 and paint['residualsChangingGeometricCoverage']==0
assert all(row['lights'][0]['directionalFacing']==0 for row in retained['points'])
blend_error = max(row['absoluteWeightError'] for row in rim['colorBlendControls'])
assert blend_error < 1.e-5
assert rim['maximum']==[88,75] and rim['overEight']==[610,182]
reports={name:ElementTree.parse(run/name).getroot() for name in ('quality-evidence-cpu-retest.xml','quality-native-tools-cpu-retest.xml')}
assert [int(report.attrib['tests']) for report in reports.values()]==[2,3]
assert all(report.attrib['failures']==report.attrib['skipped']=='0' for report in reports.values())
first=rim['worst'][0]
assert first['point']==[1325,1120] and first['bestHypotheticalRimError']==5
files = [Path(__file__).name, 'body-outline-unqualified-depth-probe.py', 'body-outline-unqualified-depth-probe.json',
    'body-outline-depth-gradient-audit.py','body-outline-depth-gradient-audit.json',
    'hair-native-mask-audit.py','hair-native-mask-audit.json',
    'body-outline-local-light-trace.py','body-outline-retained-light-trace.json',
    'body-outline-local-rim-model.py','body-outline-local-rim-model.json',
    'body-outline-local-rim-angle-model.py','body-outline-local-rim-angle-model.json',
    'quality-evidence-cpu-retest.xml','quality-native-tools-cpu-retest.xml']
out.mkdir(parents=True,exist_ok=True)
archive = out/'validation.zip'
fingerprints = {name:sha(run/name) for name in files}
with ZipFile(archive,'w',ZIP_DEFLATED) as zip_file:
    for name in files:zip_file.write(run/name,name)
with ZipFile(archive) as zip_file:
    assert zip_file.testzip() is None
    assert {name:sha256(zip_file.read(name)).hexdigest() for name in files}==fingerprints
report=dict(status='verified-diagnostics', actualSceneStatus='failed-user-review',
    bodyDepth=dict(sourceCoverage=geometry['nativeCoverage'],gradientControls=geometry['unresolved']),
    hair=paint, cpuTests={name:[case.attrib['name'] for case in report.findall('.//testcase')] for name,report in reports.items()},
    bodyLight=dict(scope=rim['modelScope'], modeledOverEight=rim['overEight'], modeledMaximum=rim['maximum'],
        referencePeakControl=first, fourSourceColorBlendMaximumWeightError=blend_error),
    archive=dict(sha256=sha(archive),members=fingerprints))
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(report['archive']['sha256'])

