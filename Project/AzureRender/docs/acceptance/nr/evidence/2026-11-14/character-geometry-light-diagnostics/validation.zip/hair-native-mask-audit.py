"""Audit the frozen hair mask against event 950's actual color writes."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
from PIL import Image

run = Path(__file__).resolve().parent
main = Path('D:/Projects/FYP/Project/AzureRender/build/runs')
grid = run.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
source = main / '20261023-105023-character-composite-contribution-diagnosis-acb8e5'
postvs = main / '20261023-033116-postvs-linear-verification-591bef' / 'postvs-950'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: sha256(p.read_bytes()).hexdigest()
inputs = {
    'before-hair.bin': '72a2b02bfe274fde9eb44d696a768b9d019276852e7e068be565d5322ce8f336',
    'after-hair.bin': '7590b5bbe131bdd9960f3357dd4240f5b48208ebee9a5f713197431f9bafcf6e',
    'native-hair-visible-mask.png': '298c2f71d5055769010c66b53d65137836a57efba0a3709f8bd37966f2d793c7',
}
for name, fingerprint in inputs.items():
    assert sha(source / name) == fingerprint, name
before = np.fromfile(source / 'before-hair.bin', '<u4').reshape(1440, 2560)
after = np.fromfile(source / 'after-hair.bin', '<u4').reshape(1440, 2560)
changed = (before != after)[::-1]
with Image.open(source / 'native-hair-visible-mask.png') as image:
    frozen = np.asarray(image.convert('L')) != 0
assert frozen.shape == changed.shape
assert int(frozen.sum()) == 17017
assert np.array_equal(changed, frozen), (int((changed & ~frozen).sum()), int((frozen & ~changed).sum()))

manifest = read(postvs / 'manifest.json')
assert manifest['complete'] and manifest['eid'] == 950 and manifest['stage'] == 'VSOut'
for entry in manifest['buffers']:
    assert sha(postvs / entry['file']) == entry['sha256']
mesh = manifest['instances'][0]['mesh']
vertices = np.fromfile(postvs / 'buffer_0.bin', '<f4').reshape(-1, mesh['vertexByteStride']//4)
indices = np.fromfile(postvs / 'buffer_1.bin', '<u2').astype(np.int64).reshape(-1, 3)
assert vertices.shape[0] == 11564 and indices.size == mesh['numIndices'] == 43044
clip = vertices[indices, :4].astype(float)
assert np.isfinite(clip).all() and (clip[:,:,3] > 0).all()
ndc = clip[:,:,:3] / clip[:,:,3,None]
positions = (ndc[:,:,:2] + 1) * [1280, 720]

def hit_triangles(point, precision):
    screen = np.rint(positions * precision) / precision if precision else positions
    e0 = screen[:,1] - screen[:,0]
    e1 = screen[:,2] - screen[:,0]
    rel = point - screen[:,0]
    orient = e0[:,0]*e1[:,1] - e0[:,1]*e1[:,0]
    u = rel[:,0]*e1[:,1] - rel[:,1]*e1[:,0]
    v = e0[:,0]*rel[:,1] - e0[:,1]*rel[:,0]
    sign = np.sign(orient)
    ids = np.flatnonzero((sign != 0) & (u*sign >= 0) & (v*sign >= 0) & ((orient-u-v)*sign >= 0))
    wu, wv = u[ids]/orient[ids], v[ids]/orient[ids]
    wd = 1-wu-wv
    depth = wd*ndc[ids,0,2]+wu*ndc[ids,1,2]+wv*ndc[ids,2,2]
    uv = vertices[indices[ids],4:6]
    weights = np.column_stack([wd,wu,wv]) / clip[ids,:,3]
    interpolated = np.sum(weights[:,:,None]*uv, axis=1)/weights.sum(axis=1)[:,None]
    return [dict(primitive=int(i), depth=float(z), winding=int(sign[i]), uv=t.tolist())
            for i,z,t in zip(ids,depth,interpolated)]

report = read(grid / 'hair-static-results.json')
intel = report['cases']['release-intel']['residuals']
controls = read(source / 'native-contributions.json')
assert len(intel) == 31 and len(controls) == 4
rows = []
for item in [*controls, *intel]:
    x,y = item.get('display', item.get('pixel'))
    assert frozen[y,x]
    rows.append(dict(display=[x,y],hardwarePrimitive=item.get('primitive'),
                     rgbError=item.get('rgbError'),continuous=hit_triangles([x+.5,y+.5],0),
                     snapped=hit_triangles([x+.5,y+.5],256)))
assert all(r['snapped'] for r in rows)
assert all(any(t['primitive'] == r['hardwarePrimitive'] for t in r['snapped']) for r in rows[:4])
for row in rows[4:]:
    row['geometricCoverageChanged'] = {t['primitive'] for t in row['snapped']} != {t['primitive'] for t in row['continuous']}
summary = dict(status='qualified-original-mask', colorWritePixels=int(changed.sum()), sourceHashes=inputs,
               capturedPrimitiveMatches=len(rows)-len(intel), residuals=len(intel),
               residualsChangingGeometricCoverage=sum(r['geometricCoverageChanged'] for r in rows[4:]),
               residualsWithSingleSnappedTriangle=sum(len(r['snapped']) == 1 for r in rows[4:]))
(run / 'hair-native-mask-audit.json').write_text(json.dumps(dict(summary=summary, rows=rows), indent=2)+'\n', encoding='utf8')
print(json.dumps(summary))
