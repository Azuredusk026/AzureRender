from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

out=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
members={}
report=dict(overallStatus='failed-user-review',candidateStatus='source-control',devices={})
for device,new in [('nvidia',11),('intel',8)]:
    variant=f'capture-{device}'
    folder=out/variant
    data=report['devices'][device]=read(folder/'results.json')
    assert digest(folder/'frames/frame_000000.png')==data['frameSha256']
    assert data['samples']['traced']['errors'][0][:2]==[41,35]
    assert data['samples']['traced']['errors'][1][:2]==[9,5]
    assert data['samples']['outsideOverEight']['overEight']==[51,47]
    assert data['regions']['face']['newOverOne']==new
    assert all(data['regions'][name]['changed']==0 for name in ('iris','faceCore','outsideFace'))
    assert data['input']['experimentalBinding']==2 and data['input']['fixedMaskBinding']==4
    assert data['input']['sampler']['mipBias']==-1
    assert 'Allocator after unload: buffers=0 images=0' in (folder/'player.log').read_text(errors='replace')
    for name in ('command.json','player.log','results.json','runtime.json','frames/gpu_capabilities.json'):
        members[f'{variant}/{name}']=folder/name
    failed=out/f'{variant}-unsuccessful-1/player.log'
    assert 'fixed lookup sampler violated at slot 4' in failed.read_text(errors='replace')
    members[f'{failed.parent.name}/{failed.name}']=failed
for name in ('face-geometry-mask-actual.py','assets/mesh-face-geometry-mask.frag',Path(__file__).name,
             'assets/face-native-geometry-mask-sampling.azurematerial','assets/face-native-geometry-mask-sampling.dds.azmeta'):
    members[name]=out/name
dest=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/face-native-geometry-mask-frame'
dest.mkdir(parents=True,exist_ok=False)
archive=dest/'validation.zip'
with ZipFile(archive,'x',ZIP_DEFLATED) as z:
    for key,path in members.items():z.write(path,key)
with ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(members)
report['archive']=dict(sha256=digest(archive),members=len(members))
(dest/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(report['archive'])
