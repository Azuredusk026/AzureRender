"""Reconstruct the source albedo input at body-outline witnesses."""
from hashlib import sha256
from pathlib import Path
import json
import struct

import numpy as np

run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
trace=run.parent/'20261114-032642-body-outline-native-shading-a58fc7'
fixture=grid/'iris-overlay-geometry-project'
geometry=grid/'native-face-skin-stages'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
source=read(geometry/'results.json')['geometry']['1018']
verts,indices=(geometry/f'{k}-1018.bin' for k in ('vertex','index'))
assert sha(verts)==source['vertexSha256'] and sha(indices)==source['indexSha256']
vertices=np.fromfile(verts,'<f4').reshape(-1,23).astype(float)
tri=np.fromfile(indices,'<u2').reshape(-1,3)+source['baseVertex']
clip=vertices[:,:4]
screen=(clip[:,:2]/clip[:,3,None]+1.)*[1280,720]
pos=np.rint(screen*256.)/256.
orig_depth=np.fromfile(grid/'native-body-outline-depth/depth-1017.bin','<u4').reshape(1440,2560,2)[::-1,:,0].view('<f4')
depth=np.fromfile(grid/'native-body-outline-depth/depth-1018.bin','<u4').reshape(1440,2560,2)[::-1,:,0].view('<f4')
pixel_w=1/clip[:,3]
pixel_z=clip[:,2]*pixel_w
vertices_uv=vertices[:,4:6]
dds=fixture/'materials/body-native-lit-outline-production-albedo.dds'
data=dds.read_bytes()
assert data[:4]==b'DDS ' and data[84:88]==b'DX10'
height,width=struct.unpack_from('<2I',data,12)
levels=struct.unpack_from('<I',data,28)[0]
assert (height,width,levels)==(1024,1024,11)
assert struct.unpack_from('<5I',data,128)[:2] in ((28,3),(29,3))
textures=[]
start=148
for i in range(levels):
    h,w=max(1,height>>i),max(1,width>>i)
    values=np.frombuffer(data,'u1',count=h*w*4,offset=start).reshape(h,w,4)[:,:,:3].astype(float)/255.
    start+=h*w*4
    linear=np.where(values<=.04045,values/12.92,((values+.055)/1.055)**2.4)
    textures.append(linear)
assert start==len(data)

def bary(p,triangles,positions):
    a,b,c=positions[triangles].transpose(1,0,2)
    u0,v0=(b-a).T
    u1,v1=(c-a).T
    dx,dy=(p-a).T
    area=u0*v1-u1*v0
    keep=area!=0
    safe=np.where(keep,area,1)
    s=(dx*v1-dy*u1)/safe
    t=(u0*dy-v0*dx)/safe
    return np.column_stack([1-s-t,s,t]),area

def source_triangle(x,y):
    barycentric,area=bary(np.array([x+.5,y+.5]),tri,pos)
    z=np.sum(barycentric*pixel_z[tri],axis=1)
    passing=(barycentric>=-1e-12).all(1)&(area<0)&(z>orig_depth[y,x])
    idx=np.flatnonzero(passing)
    assert len(idx)>0,(x,y,float(depth[y,x]),float(orig_depth[y,x]))
    i=int(idx[np.argmax(z[idx])])
    assert abs(z[i]-depth[y,x])<1.5e-8,(x,y,z[i],depth[y,x],i)
    return i

def uv_at(x,y,primitive):
    barycentric,_=bary(np.array([x+.5,y+.5]),tri[primitive:primitive+1],screen)
    weights=barycentric[0]*pixel_w[tri[primitive]]
    return (weights@vertices_uv[tri[primitive]]) / weights.sum()

def texel(uv,tex,flip):
    h,w=tex.shape[:2]
    x,y=np.asarray(uv if not flip else (uv[0],1-uv[1]))*[w,h]-.5
    i,j=int(np.floor(x)),int(np.floor(y))
    s,t=x-i,y-j
    return (1-t)*((1-s)*tex[j%h,i%w]+s*tex[j%h,(i+1)%w])+t*((1-s)*tex[(j+1)%h,i%w]+s*tex[(j+1)%h,(i+1)%w])

def output(x,y,primitive):
    uv=uv_at(x,y,primitive)
    # Form the horizontal and vertical finite differences in this fragment's quad.
    dx=uv_at(x|1,y,primitive)-uv_at(x&~1,y,primitive)
    dy=uv_at(x,y|1,primitive)-uv_at(x,y&~1,primitive)
    lod=np.log2(max(np.linalg.norm(dx*[width,height]),np.linalg.norm(dy*[width,height])))-1.
    mip=int(np.clip(np.rint(lod),0,levels-1))
    return dict(point=[x,y],triangle=primitive,uv=uv.tolist(),lod=float(lod),mip=mip,
                sampled={f'flip-{flip}':[texel(uv,t,flip).tolist() for t in textures] for flip in (0,1)})

witnesses=read(trace/'native-results.json')['samples']
known=[]
for w in witnesses:
    record=trace/w['path']
    assert sha(record)==w['sha256']
    before=read(record)
    x,y=w['x'],w['y']
    reconstructed=source_triangle(x,y)
    assert w['primitive']==reconstructed,(w,reconstructed)
    out=output(x,y,reconstructed)
    expected=np.asarray(before['23']['r2'][1:4])
    guesses=np.asarray(list(out['sampled'].values()))
    error=np.abs(guesses-expected).max(2)
    chosen=np.unravel_index(np.argmin(error),error.shape)
    out.update(nativeAlbedo=expected.tolist(),minimumError=float(error[chosen]),matchingFlipMip=list(map(int,chosen)))
    known.append(out)
result=read(run/'body-outline-remainder.json')
points=sorted({tuple(row['point']) for dev in result.values() for row in dev['blend']['coverage']['witnesses']})
targets=[output(x,y,source_triangle(x,y)) for x,y in points]
q=dict(status='diagnostic-sampling',source=sha(dds),colorAndMipControls=known,worstResidualPositions=targets)
(run/'body-outline-uv-albedo.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
for row in known:
    print('known',row['point'],row['triangle'],row['mip'],row['matchingFlipMip'],row['minimumError'])
for row in targets[:15]:
    print('target',row['point'],row['triangle'],row['mip'],row['uv'],[v[row['mip']] for v in row['sampled'].values()])

