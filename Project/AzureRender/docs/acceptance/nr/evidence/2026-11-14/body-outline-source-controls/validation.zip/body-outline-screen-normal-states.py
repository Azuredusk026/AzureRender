"""Compare source screen samples at the projected outline's unexpanded position."""
from hashlib import sha256
from pathlib import Path
import json
import runpy

import numpy as np

run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
score=runpy.run_path(str(grid/'static-quality.py'))
source=score['stages']
read=lambda p:json.loads(p.read_bytes())
trace=run.parent/'20261114-032642-body-outline-native-shading-a58fc7'
raw=source/'source-shell-screen-normal.bin'
receipt=read(source/'source-shell-screen-normal.json')
assert receipt==dict(id='ResourceId::141946',width=2560,height=1440,
                     format='R10G10B10A2_UNORM',length=14745600)
normal=np.fromfile(raw,'<u4').reshape(1440,2560)
def decode(words):
    x=((words>>0)&1023)/1023.*2-1
    z=((words>>10)&1023)/1023.*2-1
    y=1-np.abs(x)-np.abs(z)
    nx=np.where(y<0,(1-np.abs(z))*np.where(x<0,-1.,1.),x)
    nz=np.where(y<0,(1-np.abs(x))*np.where(z<0,-1.,1.),z)
    rows=np.stack((nx,y,nz),axis=-1)
    return rows/np.linalg.norm(rows,axis=-1)[...,None]

def lanes(rows,point):
    x,y=point
    xy=np.asarray(rows[64]['r8'][:2],'<f4').view('<u4')
    assert int(xy[0])<2560 and int(xy[1])<1440,xy
    traced=np.asarray(rows[75]['r9'][:3])
    xx,yy=map(int,xy)
    projected=decode(normal[yy,xx])
    output=decode(normal[1439-y,x])
    return dict(point=point,nativeSampleDisplay=[xx,1439-yy],
        authoredNormal=traced.tolist(),nativePositionNormal=projected.tolist(),nativeOutputPixelNormal=output.tolist(),
        offset=[xx-x,1439-yy-y],
        nativePositionMaximumError=float(np.abs(projected-traced).max()),
        outputPixelMaximumError=float(np.abs(output-traced).max()),
        positionsAngle=float(np.degrees(np.arccos(np.clip(projected@output,-1,1)))))
rows=[]
for file in sorted(trace.glob('1018-*.json')):
    w=read(file);p=list(map(int,file.stem.split('-')[1:]))
    rows.append(lanes({int(k):v for k,v in w.items()},p))
assert len(rows)==4
assert all(r['offset']==[1,0] and r['nativePositionMaximumError']<1e-6 for r in rows),rows
if (run/'trace-body-outline-source.json').is_file():
    recent=read(run/'trace-body-outline-source.json')
    assert recent['status']=='qualified'
    for row in recent['points']:
        states={}
        current={}
        for index,delta in read(run/row['file']):
            current.update(delta)
            states[index]=current.copy()
        rows.append(lanes(states,row['point']))
result=dict(status='source-coordinate-control',textureSha256=sha256(raw.read_bytes()).hexdigest(),points=rows)
(run/'body-outline-screen-normal-states.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))