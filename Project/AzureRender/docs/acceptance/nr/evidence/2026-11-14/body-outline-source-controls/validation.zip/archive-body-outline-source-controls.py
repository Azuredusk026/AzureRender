from hashlib import file_digest, sha256
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json

run=Path(__file__).resolve().parent
target=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/body-outline-source-controls'
trace=run.parent/'20261114-032642-body-outline-native-shading-a58fc7'
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
def digest(p):
    with p.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()
albedo=read(run/'body-outline-authored-albedo-controls.json')
footprint=read(run/'body-outline-source-footprint.json')
normals=read(run/'body-outline-screen-normal-states.json')
refprov=read(grid/'native-face-skin-stages/results.json')['geometry']['1018']
assert footprint['nativeCoverage']==1184 and footprint['reconstructed']==1118
assert len(footprint['points'])==1118 and len(footprint['missing'])==66
assert footprint['angleOver90']==608 and footprint['differingNormal']==1118
assert len(albedo['matches'])==4 and len(normals['points'])>=4
raw=max(r['rawBaselineError'] for r in albedo['matches'])
tint=max(r['authoredTintError'] for r in albedo['matches'])
normal=max(r['nativePositionMaximumError'] for r in normals['points'][:4])
assert raw<.0011 and tint<.0025 and normal<1.e-6
assert all(r['offset']==[1,0] and r['positionsAngle']>137 for r in normals['points'][:4])
assert digest(grid/'native-face-skin-stages/vertex-1018.bin')==refprov['vertexSha256']
assert digest(grid/'native-face-skin-stages/index-1018.bin')==refprov['indexSha256']
members={p.name:p for p in (Path(__file__).resolve(),*(run/n for n in (
    'body-outline-uv-albedo.py','body-outline-screen-normal-states.py','body-outline-source-footprint.py',
    'body-outline-authored-albedo-controls.py','body-outline-authored-albedo-controls.json',
    'body-outline-screen-normal-states.json','body-outline-source-footprint.json')))}
for p in read(trace/'native-results.json')['samples']:
    name=p['path']
    assert digest(trace/name)==p['sha256']
    members['source/'+name]=trace/name
for name in ('ps-cb0.bin','ps-cb1.bin','ps-cb6.bin','native-results.json','request.json'):
    members['source/'+name]=trace/name
entries={name:digest(p) for name,p in members.items()}
target.mkdir(parents=True,exist_ok=False)
with ZipFile(target/'validation.zip','x',ZIP_DEFLATED) as archive:
    for name,p in members.items():archive.write(p,name)
with ZipFile(target/'validation.zip') as archive:
    assert archive.testzip() is None and set(archive.namelist())==set(members)
    assert {n:sha256(archive.read(n)).hexdigest() for n in members}==entries
report=dict(status='source-controls-qualified',actualSceneStatus='failed-user-review',
    sourceDraw=1018,sourceGeometry={k:refprov[k] for k in ('vertexSha256','indexSha256','pixelShaderSha256')},
    maximumLinearAlbedoError=raw,maximumLinearTintError=tint,maximumTracedNormalError=normal,
    normalControls=normals['points'][:4],
    sourceFootprint={k:footprint[k] for k in ('nativeCoverage','reconstructed','offsetCounts','differingNormal','angleOver90','quantilesDegrees')},
    notQualifiedCount=66,archive=dict(sha256=digest(target/'validation.zip'),members=entries))
(target/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(raw=raw,tint=tint,normal=normal,reconstructed=1118,unqualified=66,archive=report['archive']['sha256'])))
