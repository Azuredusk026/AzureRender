"""Compare the authored outline tint with the original material on native triangles."""
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import runpy
import struct

import numpy as np
from PIL import Image

root=Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
fixture=grid/'iris-overlay-geometry-project'
data=runpy.run_path(str(root/'body-outline-uv-albedo.py'),run_name='outline_uv')
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
texel=data['texel']
level=read(fixture/'scene/face-native-radial-local-production.azurelevel')
hero,=[node for node in level['nodes'] if node['id']=='hero']
profile=fixture/'materials'/(hero['materialSlots']['name:M_actor_laevat_body_01']+'.azurematerial')
texture_id=read(profile)['textures']['0']['asset']
original=fixture/'materials'/f'{texture_id}.dds'
raw=original.read_bytes()
header=bytearray(raw[:148])
assert struct.unpack_from('<2I',header,12)==(1024,1024)
assert struct.unpack_from('<5I',header,128)[:2]==(99,3)
count=struct.unpack_from('<I',header,28)[0]
luma=np.array([.212673,.715152,.072175])
src=[]
offset=148
for i in range(count):
    extent=max(1,1024>>i)
    nblocks=((extent+3)//4)**2
    struct.pack_into('<3I',header,12,extent,extent,nblocks*16)
    struct.pack_into('<I',header,28,1)
    with Image.open(BytesIO(header+raw[offset:offset+nblocks*16])) as image:
        rgba=np.asarray(image.convert('RGBA'),dtype=float)/255
    offset+=nblocks*16
    rgb=rgba[:,:,:3]
    src.append(np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4))
assert offset==len(raw)
witnesses=[]
for row in data['known']:
    x,y=row['point']
    mip=row['mip']
    uv=np.asarray(row['uv'])
    raw=texel(uv,src[mip],False)
    observed=np.asarray(row['nativeAlbedo'])
    tinted=observed*.5
    y_tint=tinted@luma
    tinted=y_tint+(tinted-y_tint)*1.5
    previous=np.asarray(row['sampled']['flip-0'][mip])
    witnesses.append(dict(point=row['point'],mip=mip,primitive=row['triangle'],uv=row['uv'],
        rawBaselineError=float(np.abs(raw-observed).max()),authoredTintError=float(np.abs(previous-tinted).max()),
        sourceRaw=observed.tolist(),fixtureRaw=raw.tolist(),sourceTint=tinted.tolist(),fixtureTint=previous.tolist()))
assert len(witnesses)==4 and max(x['rawBaselineError'] for x in witnesses)<.0011
assert max(x['authoredTintError'] for x in witnesses)<.0025
result=dict(status='qualified-on-four-controls',fixtureMaterial=digest(profile),fixtureRawAlbedo=digest(original),
    fixtureBakedAlbedo=data['q']['source'],matches=witnesses,limits='Original outline binding and remaining high-error pixels require separate replay.')
(root/'body-outline-authored-albedo-controls.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print([(r['point'],r['rawBaselineError'],r['authoredTintError']) for r in witnesses])

