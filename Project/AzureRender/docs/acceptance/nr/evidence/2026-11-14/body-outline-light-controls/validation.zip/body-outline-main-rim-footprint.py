"""Evaluate the native global rim over reconstructed shell triangles."""
from pathlib import Path
import json
import runpy
import numpy as np

run=Path(__file__).resolve().parent
g=runpy.run_path(str(run/'body-outline-uv-albedo.py'))
n=runpy.run_path(str(run/'body-outline-screen-normal-states.py'))
read=g['read']
cb0=np.fromfile(g['trace']/'ps-cb0.bin','<f4').reshape(-1,4).astype(float)
cb1=np.fromfile(g['trace']/'ps-cb1.bin','<f4').reshape(-1,4).astype(float)
def unit(p):
    return p/np.linalg.norm(p,axis=-1,keepdims=True)

def sat(p):
    return np.clip(p,0,1)

rim_camera=cb0[:3,0]*cb1[119,0]+cb0[:3,1]*cb1[119,1]
rim_camera=rim_camera[[1,2,0]]
rim_world=np.asarray([cb1[119,1],0,cb1[119,0]])
rim_src=rim_world+(rim_camera-rim_world)*cb1[125,3]
direction=unit(cb0[6,[1,2,0]]*rim_src[[1,2,0]]-rim_src*cb0[6,[2,0,1]])
bound0=.8-.6*cb1[119,3]
bound1=.9-.4*cb1[119,3]
strength=cb1[118,:3]*cb1[118,3]
for file in sorted(g['trace'].glob('1018-*.json')):
    reg=read(file)
    assert np.max(abs(direction-np.asarray(reg['401']['r11'][:3])))<2e-6
    assert np.isfinite(reg['75']['r9'][:3]).all()
footprint=read(run/'body-outline-source-footprint.json')
tri=g['tri']
position=g['vertices'][:,6:9]
weights_clip=g['pixel_w']
score=runpy.run_path(str(g['grid']/'static-quality.py'))
image=lambda p:score['image'](p).astype('i2')
native=image(score['reference_path'])
actual=image(run/'body-blend-nvidia/frames/frame_000000.png')
err=np.abs(native-actual).max(2)
group=[]
for x,y,_,_,primitive,_,packed,_ in footprint['points']:
    bary,_=g['bary'](np.array([x+.5,y+.5]),tri[primitive:primitive+1],g['screen'])
    ind=tri[primitive]
    w=bary[0]*weights_clip[ind]
    p=(w@position[ind])/w.sum()
    view=unit(cb1[4,3]*(cb0[:3,2]+p)-p)
    normal=n['decode'](np.uint32(packed))
    edge=1-abs(normal@view)
    band=sat((edge-bound0)/(bound1-bound0))
    band=band*band*(3-2*band)
    facing=sat(normal@direction)
    # Radial origin and AO can only reduce the nonnegative rim weight.
    upper=band*facing*float(strength.max())*.96
    group.append(dict(point=[x,y],band=float(band),facing=float(facing),rimWeightUpperBound=float(upper),
        colorError=int(err[y,x])))
assert len(group)==1118 and np.isfinite(direction).all()
summary=dict(status='native-rim-global-footprint',rimDirection=direction.tolist(),rimThresholds=[bound0,bound1],
    strength=strength.tolist(),sourceRimBandPresent=sum(x['rimWeightUpperBound']>0 for x in group),
    sourceRimBandAboveOnePercent=sum(x['rimWeightUpperBound']>.01 for x in group),
    afterEightWithGlobalRimBand=sum(x['colorError']>8 and x['rimWeightUpperBound']>0 for x in group),
    afterEightWithoutGlobalRimBand=sum(x['colorError']>8 and x['rimWeightUpperBound']==0 for x in group))
(run/'body-outline-main-rim-footprint.json').write_text(json.dumps(dict(**summary,points=group),indent=2)+'\n',encoding='utf8')
print(json.dumps(summary))
