"""Reconcile native outline light terms against the four hardware witnesses."""
from hashlib import sha256
from pathlib import Path
import json
import runpy
import numpy as np

run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
traces=run.parent/'20261114-032642-body-outline-native-shading-a58fc7'
read=lambda p:json.loads(p.read_bytes())
report=read(traces/'native-results.json')
assert report['status']=='qualified'
scorer=runpy.run_path(str(grid/'static-quality.py'))
read_img=lambda p:scorer['image'](p).astype('i2')
native=read_img(scorer['reference_path'])
observed={k:read_img(run/f'body-blend-{k}/frames/frame_000000.png') for k in ('nvidia','intel')}
cb1=np.fromfile(traces/'ps-cb1.bin','<f4').reshape(-1,4)
cb6=np.fromfile(traces/'ps-cb6.bin','<f4').reshape(-1,4)
assert cb6[3,0]==0
def srgb(linear):
    rgb=np.where(linear<=.0031308,12.92*linear,1.055*np.maximum(0,linear)**(1/2.4)-.055)
    return np.rint(np.clip(rgb,0,1)*255).astype(int)
rows=[]
for item in report['samples']:
    f=traces/item['path']
    assert sha256(f.read_bytes()).hexdigest()==item['sha256']
    registers=read(f)
    def rgb(step,reg,components=slice(0,3)):
        return np.asarray(registers[str(step)][reg],dtype=float)[components]
    luma=np.asarray([.212673,.715152,.072175])
    tint=rgb(35,'r2',slice(1,4))
    ramp=rgb(324,'r15',slice(0,4))
    object_visibility,ao=rgb(309,'r13',slice(0,2))
    response=rgb(380,'r13',[0,2,3])
    ambient_before_mix=rgb(371,'r14',[0,2,3])
    combined_illumination=rgb(380,'r6')
    main=rgb(418,'r6')
    rim=rgb(437,'r6')-main
    local=rgb(844,'r14')-main-rim
    final=rgb(1048,'o0')
    before_saturation=response*combined_illumination
    lum=before_saturation@luma
    sat=1+np.clip(lum-.5,0,.5)**2
    main_model=lum+(before_saturation-lum)*sat
    assert np.max(abs(main_model-main))<2e-6
    assert np.max(abs(final-(main+rim+local)))<2e-6
    assert np.max(abs(final-np.asarray(item['hardware'][:3])))<1e-6
    at=(item['y'],item['x'])
    reference=native[at]
    reproduced=srgb(final*.25)
    assert np.max(abs(reproduced-reference))<=1,(at,reproduced,reference)
    rows.append(dict(point=[item['x'],item['y']],primitive=item['primitive'],tint=tint.tolist(),ramp=ramp.tolist(),
        objectVisibility=object_visibility,ambientOcclusion=ao,materialDiffuseResponse=response.tolist(),
        shadowLightBeforeMix=ambient_before_mix.tolist(),combinedIllumination=combined_illumination.tolist(),
        brightnessSaturation=float(sat),nativeMainLinear=(.25*main).tolist(),nativeRimLinear=(.25*rim).tolist(),
        nativeLocalLinear=(.25*local).tolist(),nativeOutputLinear=(.25*final).tolist(),
        displayExpected=reference.tolist(),displayReconstructed=reproduced.tolist(),
        displayActual={k:v[at].tolist() for k,v in observed.items()}))
result=dict(status='tested-native-light-lanes',scope='retained-four-witnesses',
    globalDirectionAndWeights=cb1[116:120].tolist(),points=rows)
(run/'body-outline-existing-light-lanes.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
