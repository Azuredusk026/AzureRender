"""Quantify the retained Player's sensitivity to the projection boundary."""
from hashlib import sha256
from pathlib import Path
import json
import numpy as np

run=Path(__file__).resolve().parent
source=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c')
read=lambda p:json.loads(p.read_bytes())
m=read(run/'body-outline-player-projection-model.json')
f=read(run/'body-outline-source-footprint.json')
points={tuple(r[:2]):r[2:] for r in f['points']}
fork=m['indexMismatches']
assert len(points)==1118 and m['exactIndex']+len(fork)==1118
base=source/'engine-qualified-lit-surfaces-replay'
t,=read(base/'summary.json')['textures']
payload=(base/t['path']).read_bytes()
assert sha256(payload).hexdigest()==t['sha256']
texture=np.frombuffer(payload,'<f4').reshape(1440,2560,4)

def decode(s):
    x,y=s[1:3].astype(float)*2-1
    z=1-abs(x)-abs(y)
    if z<0:x,y=(1-abs(y))*np.sign(x),(1-abs(x))*np.sign(y)
    n=np.asarray([x,y,z])
    return n/np.linalg.norm(n)

def nr(w):
    x=((w&1023)/1023.)*2-1
    z=(((w>>10)&1023)/1023.)*2-1
    y=1-abs(x)-abs(z)
    if y<0:x,z=(1-abs(z))*np.sign(x),(1-abs(x))*np.sign(z)
    n=np.asarray([-x,y,z])
    return n/np.linalg.norm(n)

def degrees(a,b):return float(np.degrees(np.arccos(np.clip(a@b,-1,1))))
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
# Use the registered native final image, without invoking a new renderer.
import runpy
scorer=runpy.run_path(str(grid/'static-quality.py'))
native=scorer['image'](scorer['reference_path']).astype('i2')
device={name:scorer['image'](run/f'body-blend-{name}/frames/frame_000000.png').astype('i2')
        for name in ('nvidia','intel')}
before={name:np.abs(im-native).max(2) for name,im in device.items()}
result=[]
for row in fork:
    x,y=row['point']
    a,b=row['source']
    c,d=row['player']
    _,_,_,_,w,_=points[x,y]
    reference=nr(w)
    expected=texture[b,a]
    projected=texture[d,c]
    assert 0<expected[0]<100000
    residual=[int(before[k][y,x]) for k in before]
    result.append(dict(point=[x,y],delta=[c-a,d-b],expectedDepth=float(expected[0]),projectedDepth=float(projected[0]),
        projectedAngle=degrees(reference,decode(projected)) if 0<projected[0]<100000 else None,
        expectedAngle=degrees(reference,decode(expected)),actualError=residual))
angles=np.asarray([r['projectedAngle'] if r['projectedAngle'] is not None else -1 for r in result])
over=np.array([r['actualError'] for r in result])>8
fork_points={tuple(q['point']) for q in result}
outside=[[int(before[name][y,x]) for name in before] for (x,y) in points.keys()-fork_points]
for_group=lambda a:[int(k) for k in (np.array(a)>8).sum(0)]
report=dict(status='projection-boundary-sensitivity',historicalSnapshotSha256=t['sha256'],boundaryPixels=len(fork),
    exactCoordinatePixels=m['exactIndex'],nearBoundaryOverEight=for_group([r['actualError'] for r in result]),
    matchedCoordinateOverEight=for_group(outside),invalidNearBoundary=int((angles<0).sum()),
    nearBoundaryNormalOver45=int((angles>45).sum()),nearBoundaryNormalOver90=int((angles>90).sum()),
    nearBoundaryInvalidOrOver45AndColorOverEight=over[(angles<0)|(angles>45)].sum(0).tolist())
(run/'body-outline-evaluate-address-fork.json').write_text(json.dumps(dict(**report,pixels=result),indent=2)+'\n',encoding='utf8')
print(json.dumps(report))
