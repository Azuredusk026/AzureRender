"""Compare native outline visibility to the separate reference-pass Player exports."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import runpy
import numpy as np

run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
source=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261027-002548-native-hair-layer-region-closure-61c105')
read=lambda p:json.loads(p.read_bytes())
trace=run.parent/'20261114-032642-body-outline-native-shading-a58fc7'
raw=(source/'native-screen-visibility.bin').read_bytes()
sha=sha256(raw).hexdigest()
receipt=read(source/'visibility-inputs.json')
assert sha in json.dumps(receipt) and '141931' in json.dumps(receipt),receipt
plane=np.frombuffer(raw,'u1').reshape(1440,2560,2)[::-1]
for f in sorted(trace.glob('1018-*.json')):
    x,y=map(int,f.stem.split('-')[1:])
    ix,iy=np.asarray(read(f)['64']['r8'][:2],'<f4').view('<u4')
    controls=np.asarray(read(f)['309']['r13'][:2])
    assert np.max(abs(plane[1439-iy,ix]/255.-controls))<=1e-6
footprint=read(run/'body-outline-source-footprint.json')
assert footprint['reconstructed']==1118
x,y,a,b=np.asarray([row[:4] for row in footprint['points']]).T
score=runpy.run_path(str(grid/'static-quality.py'))
image=lambda p:score['image'](p).astype('i2')
reference=image(score['reference_path'])
record={}
for dev in ('nvidia','intel'):
    folder=grid/f'release-{dev}-frames'
    name='reference-object-visibility-rg8.bin'
    metadata=read(folder/'reference-planes.json')[name]
    with ZipFile(folder/'reference-planes.zip') as z:
        artifact=z.read(metadata['archiveEntry'])
    assert len(artifact)==metadata['size'] and sha256(artifact).hexdigest()==metadata['sha256']
    host=np.frombuffer(artifact,'u1').reshape(1440,2560,2)[::-1]
    native=plane[b,a].astype('i2')
    err=abs(host[b,a].astype('i2')-native)
    actual=image(run/f'body-blend-{dev}/frames/frame_000000.png')
    color=np.abs(reference[y,x]-actual[y,x]).max(1)
    bgroup=color>8
    record[dev]=dict(visibilitySha256=metadata['sha256'],
        referenceDarkPixels=(native<255).sum(0).tolist(),
        referenceWithinOneVisibility=(err<=1).sum(0).tolist(),
        colorOverEight=int(bgroup.sum()),
        colorOverEightAndVisibilityOverOne=(err[bgroup]>1).sum(0).tolist(),
        colorOverEightAndVisibilityWithinOne=(err[bgroup]<=1).sum(0).tolist(),
        worstVisibilityPixels=[dict(point=[int(x[i]),int(y[i])],sourceAddress=[int(a[i]),int(b[i])],
             actual=host[b[i],a[i]].tolist(),native=native[i].tolist(),colorError=int(color[i]))
             for i in np.argsort(err.max(1))[-8:][::-1]])
result=dict(status='diagnostic-control',nativeVisibilitySha256=sha,nativePoints=len(x),
    playerAttachmentScope='separate reference scene, same view',byDevice=record)
(run/'body-outline-visibility-inputs.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
