"""Check coordinate parity against retained Player normal attachments."""
from hashlib import sha256
from pathlib import Path
import json

import numpy as np

run=Path(__file__).resolve().parent
native=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c')
read=lambda p:json.loads(p.read_bytes())
footprint=read(run/'body-outline-source-footprint.json')
assert footprint['reconstructed']==1118
pt=footprint['points']

def decode(px):
    a,b=(px[:,1:3]*2-1).T
    c=1-abs(a)-abs(b)
    x=np.where(c<0,(1-abs(b))*np.where(a<0,-1,1),a)
    y=np.where(c<0,(1-abs(a))*np.where(b<0,-1,1),b)
    v=np.stack((x,y,c),axis=1)
    return v/np.linalg.norm(v,axis=1)[:,None]

def ref_decode(w):
    a=((w>>0)&1023)/1023.*2-1
    b=((w>>10)&1023)/1023.*2-1
    c=1-abs(a)-abs(b)
    x=np.where(c<0,(1-abs(b))*np.where(a<0,-1,1),a)
    z=np.where(c<0,(1-abs(a))*np.where(b<0,-1,1),b)
    v=np.stack((-x,c,z),axis=1)
    return v/np.linalg.norm(v,axis=1)[:,None]
xy=np.array([x[:4] for x in pt])
original=ref_decode(np.asarray([x[-2] for x in pt],dtype='<u4'))

def angle(a,b):
    return np.degrees(np.arccos(np.clip(np.einsum('ij,ij->i',a,b),-1,1)))

saves={}
for replay in ('engine-qualified-lit-surfaces-replay','engine-screen-normal-fixed-replay'):
    base=native/replay
    collection=read(base/'summary.json')
    data,=collection['textures']
    assert collection['status']=='exported' and data['format']=='R32G32B32A32_FLOAT'
    payload=(base/data['path']).read_bytes()
    assert len(payload)==data['bytes'] and sha256(payload).hexdigest()==data['sha256']
    tex=np.frombuffer(payload,'<f4').reshape(data['height'],data['width'],4).astype(float)
    record={}
    for flip in (False,True):
        image=tex[::-1] if flip else tex
        samples={}
        for name,x,y in [('source',xy[:,2],xy[:,3]),('output',xy[:,0],xy[:,1])]:
            surface=image[y,x]
            active=np.isfinite(surface).all(axis=1)&(surface[:,0]>0)&(surface[:,0]<100000)
            visible=decode(surface[active])
            residual=angle(visible,original[active])
            samples[name]=dict(valid=int(active.sum()), depthP10P50P90=np.quantile(surface[active,0],[.1,.5,.9]).tolist(),
                angleP10P50P90=np.quantile(residual,[.1,.5,.9]).tolist(),withinFive=int((residual<=5).sum()),
                overNinety=int((residual>90).sum()),controls=[
                    dict(point=xy[i,:2].tolist(),normal=decode(surface[i:i+1])[0].tolist(),
                         native=original[i].tolist(),depth=float(surface[i,0]))
                    for i in range(len(xy)) if xy[i,0]==1270 and xy[i,1] in {1037,1047,1053,1054}])
        record['flipped' if flip else 'direct']=samples
    saves[replay]=dict(textureSha256=data['sha256'],orientation=record)
result=dict(status='historical-player-surface-control',normalInPlayerWorld='negate-native-x',
    nativeFootprint=footprint['reconstructed'],captures=saves)
(run/'body-outline-retained-player-surface.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
for name,row in saves.items():
    print(name)
    for o,rr in row['orientation'].items():
        print(o,[(k,v['valid'],v['angleP10P50P90'],v['withinFive'],v['overNinety']) for k,v in rr.items()])
