from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

run=Path(__file__).resolve().parent
target=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/body-outline-light-controls'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
sources={
    'previousSurface':'body-outline-retained-player-surface',
    'projection':'body-outline-player-projection-model',
    'boundary':'body-outline-evaluate-address-fork',
    'nativeLighting':'body-outline-existing-light-lanes',
    'globalRim':'body-outline-main-rim-footprint',
    'visibility':'body-outline-visibility-inputs',
    'playerLocalRimModel':'body-outline-local-rim-model',
}
findings={key:read(run/(stem+'.json')) for key,stem in sources.items()}
assert len(findings['nativeLighting']['points'])==4
assert all(max(abs(a-b) for a,b in zip(r['displayExpected'],r['displayReconstructed']))<=1
           for r in findings['nativeLighting']['points'])
assert all(x==0 for x in findings['globalRim']['strength'])
assert findings['projection']['exactIndex']==726
assert findings['boundary']['boundaryPixels']==392 and findings['boundary']['nearBoundaryNormalOver45']==3
for device,n in [('nvidia',1099),('intel',1102)]:
    assert findings['visibility']['byDevice'][device]['referenceWithinOneVisibility']==[1118,n]
for p in findings['previousSurface']['captures'].values():
    assert p['orientation']['direct']['source']['withinFive']==1116
assert findings['playerLocalRimModel']['overEight']==[610,587] and findings['playerLocalRimModel']['maximum']==[88,88]
entries=[Path(__file__).name]
for stem in sources.values():
    entries.extend((stem+'.py',stem+'.json'))
target.mkdir(parents=True,exist_ok=True)
fingerprint={key:digest(run/key) for key in entries}
with ZipFile(target/'validation.zip','w',ZIP_DEFLATED) as archive:
    for key in entries:archive.write(run/key,key)
with ZipFile(target/'validation.zip') as archive:
    assert archive.testzip() is None
    assert {key:sha256(archive.read(key)).hexdigest() for key in entries}==fingerprint
surface=findings['previousSurface']['captures']
summaries=dict(previousSurface={k:dict(sha256=v['textureSha256'],
    nativeAddressWithinFive=v['orientation']['direct']['source']['withinFive']) for k,v in surface.items()},
    projection={k:findings['projection'][k] for k in ('sourceVertexCount','reconstructed','exactIndex','maxAbsoluteCoordinateDelta')},
    boundary={k:findings['boundary'][k] for k in ('boundaryPixels','nearBoundaryNormalOver45','matchedCoordinateOverEight')},
    visibility={k:{n:r[n] for n in ('visibilitySha256','referenceWithinOneVisibility','colorOverEightAndVisibilityOverOne')}
        for k,r in findings['visibility']['byDevice'].items()},
    globalRim=findings['globalRim']['strength'],
    modeledLocalRim={k:findings['playerLocalRimModel'][k] for k in ('overEight','maximum','modelScope')})
record=dict(status='verified-controls',actualSceneStatus='failed-user-review',currentGpuScope='pending',
    witnessMaximumDisplayError=1,findings=summaries,archive=dict(sha256=digest(target/'validation.zip'),members=fingerprint))
(target/'results.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(record['archive']['sha256'])
