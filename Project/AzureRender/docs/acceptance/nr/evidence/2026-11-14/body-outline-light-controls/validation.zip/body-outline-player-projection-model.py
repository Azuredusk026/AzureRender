"""Compare Player and source projection addresses using the candidate content."""
from pathlib import Path
import json
import math
import runpy
import numpy as np

run=Path(__file__).resolve().parent
g=runpy.run_path(str(run/'body-outline-uv-albedo.py'))
read=g['read']
native=g['vertices'][:,6:9]
j=read(run/'body-native-lit-outline-production-ordered.gltf')
prim=j['meshes'][j['nodes'][-1]['mesh']]['primitives'][0]
a=j['accessors'][prim['attributes']['POSITION']]
v=j['bufferViews'][a['bufferView']]
buf=g['fixture']/'character'/j['buffers'][v['buffer']]['uri']
pos=np.fromfile(buf,'<f4',count=a['count']*3,offset=a.get('byteOffset',0)+v.get('byteOffset',0)).reshape(-1,3)
scene=read(run/'body-native-lit-outline-blend-depth.azurelevel')
camera=next(x for x in scene['nodes'] if x['id']=='camera')
t=camera['components']['azure.transform']['data']
camera_position=np.asarray(t['translation'])
assert np.array_equal(pos,native*[-1,1,1]+camera_position)
manifest=read(run/'body-blend-nvidia/frames/capture_manifest.json')
u=np.asarray(manifest['cameraUp'])
f=np.asarray([0.,u[2],-u[1]])
r=np.cross(f,u)
assert np.allclose(r,[1,0,0])
h=math.tan(manifest['cameraLens']['verticalFovRadians']*.5)
ratio=2560/1440
ox,oy=manifest['cameraLens']['offsetNdc']
foot=read(run/'body-outline-source-footprint.json')
tri=g['tri']
rows=[]
for x,y,nx,ny,i,pixel,_,_ in foot['points']:
    b,_=g['bary'](np.asarray([x+.5,y+.5]),tri[i:i+1],g['screen'])
    indices=tri[i]
    w=b[0]*g['pixel_w'][indices]
    world=(w@pos[indices])/w.sum()
    local=world-camera_position
    depth=local@f
    sx=(local@r)/(h*ratio*depth)+ox
    sy=-(local@u)/(h*depth)+oy
    px=(np.asarray([sx,sy])*.5+.5)*[2560,1440]
    npix=np.asarray([pixel[0],1440-pixel[1]])
    index=np.floor(px).astype(int)
    rows.append(dict(point=[x,y],source=[nx,ny],player=index.tolist(),
        interpolationAtNativeRaster=px.tolist(),coordinateDelta=(px-npix).tolist(),
        exactIndex=bool(np.array_equal(index,[nx,ny]))))
diff=np.asarray([a['coordinateDelta'] for a in rows])
result=dict(status='player-projection-model',sourceVertexCount=len(pos),
    conditionedOnNativeRaster=True,nativeTraceCoverage=foot['nativeCoverage'],reconstructed=len(rows),
    exactIndex=sum(a['exactIndex'] for a in rows),maxAbsoluteCoordinateDelta=np.abs(diff).max(0).tolist(),
    indexMismatches=[r for r in rows if not r['exactIndex']])
(run/'body-outline-player-projection-model.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
