from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import subprocess
import traceback

key='AZURE_NR_IRIS_INPUT_LANES'
out=Path(os.environ[key]) if key in os.environ else Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')

def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)

def replay():
    import renderdoc as rd
    job=read(out/'request.json')
    source=Path(job['source'])
    code=source.read_text('utf8')
    assert sha256(source.read_bytes()).hexdigest()==job['sourceSha256']
    assert sha256((source.parent/'character_surface.glsl').read_bytes()).hexdigest()==job['eyeIncludeSha256']
    rule,=[r for r in read(Path(job['rules']))['programs'] if r['output']==job['shader']]
    marker='    vec3 qaColor = beautyColor;'
    assert code.count(marker)==1
    lanes={
        'coords':'vec4(eyeCoordinates.baseUv,eyeCoordinates.matcapUv)',
        'base':'baseColor',
        'mip4':'textureLod(AZ_TEX_BASE_COLOR,eyeCoordinates.baseUv,4.0)',
        'matcap':'eyeMatcap',
        'ramp':'classRampRgba',
        'view':'vec4(rampCoordinate,eyeViewRampAlpha,eyeCoordinates.whiteMask,0)',
        'direct':'vec4(directDiffuse,1)',
        'ambient':'vec4(ambientDiffuse,1)',
        'reflection':'vec4(directSpecular,1)',
    }
    anchor='if(eyeNpr){signedMainRamp=true;rampCoordinate=characterMainRampCoordinate(shadedNormal,lightDirection,0);}'
    key=job['nativeWorldKey']
    expr='vec3('+','.join(f'{float(k):.10g}' for k in key)+')'
    bound='vec3 qSide=normalize(instanceFaceFrame[0].xyz); vec3 qFront=normalize(instanceFaceFrame[2].xyz); vec3 qProjected=normalize(qSide*dot(qKey,qSide)+qFront*dot(qKey,qFront));'
    directional={
        'native-vulkan-fixed':anchor.replace('shadedNormal,lightDirection,0','shadedNormal,vec3(-0.20775538683,-0.063696578145,0.976104795933),0'),
        'key-world':anchor.replace('shadedNormal,lightDirection,0','shadedNormal,'+expr+',0'),
        'key-head-frame':'if(eyeNpr){vec3 qKey='+expr+';'+bound+'signedMainRamp=true;rampCoordinate=characterMainRampCoordinate(shadedNormal,qProjected,0);}',
        'scene-head-frame':'if(eyeNpr){vec3 qKey=lightDirection;'+bound+'signedMainRamp=true;rampCoordinate=characterMainRampCoordinate(shadedNormal,qProjected,0);}',
    }
    sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
    def build(label,expr):
        p=out/('mesh-'+label+'.frag')
        f=p.with_suffix('.spv')
        if label in directional:
            assert code.count(anchor)==1
            content=code.replace(anchor,directional[label])
        else:
            content=code if expr is None else code.replace(marker,marker+'\n    if(eyeRadial) { outputColor='+expr+'; return; }')
        p.write_text(content,encoding='utf8')
        args=[str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+v for v in rule['defines']),'-I'+str(source.parent),str(p),'-o',str(f)]
        subprocess.run(args,check=True)
        subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(f)],check=True)
        return f.read_bytes()

    cap=rd.OpenCaptureFile()
    ctl=None
    replacement=None
    record=dict(status='failed',event=job['event'],lanes={})
    try:
        assert cap.OpenFile(job['capture'],'',None)==rd.ResultCode.Succeeded
        opt=rd.ReplayOptions()
        opt.forceGPUVendor=rd.GPUVendor.nVidia
        opt.forceGPUDeviceID=0x28e0
        result,ctl=cap.OpenCapture(opt,None)
        assert result==rd.ResultCode.Succeeded and ctl
        props=ctl.GetAPIProperties()
        assert props.pipelineType==rd.GraphicsAPI.Vulkan and props.vendor==rd.GPUVendor.nVidia and not props.degraded
        action,=[a for a in walk(ctl.GetRootActions()) if a.eventId==job['event']]
        assert action.numIndices==948
        stage=rd.ShaderStage.Fragment
        ctl.SetFrameEvent(action.eventId,True)
        pipe=ctl.GetPipelineState()
        reflect=pipe.GetShaderReflection(stage)
        original=pipe.GetShader(stage)
        raw=bytes(reflect.rawBytes)
        assert sha256(raw).hexdigest()==job['shaderSha256']
        target=pipe.GetOutputTargets()[0].resource
        desc,=[d for d in ctl.GetTextures() if d.resourceId==target]
        assert (desc.width,desc.height,desc.format.Name())==(2560,1440,'R16G16B16A16_FLOAT')

        def snap(label):
            ctl.SetFrameEvent(action.eventId,True)
            data=bytes(ctl.GetTextureData(target,rd.Subresource()))
            assert len(data)==2560*1440*8
            selected=[list(struct.unpack_from('<4e',data,8*(y*2560+x))) for x,y in job['points']]
            record['lanes'][label]=dict(sha256=sha256(data).hexdigest(),rows=selected)
            return selected

        native=snap('baseline')
        selected=[('copy',None),('recompile',None)]
        selected.extend((label,None) for label in directional) if job['mode']=='direction' else selected.extend(lanes.items())
        for label,expr in selected:
            test=raw if label=='copy' else build(label,expr)
            replacement,error=ctl.BuildTargetShader(reflect.entryPoint,rd.ShaderEncoding.SPIRV,test,
                                                    rd.ShaderCompileFlags(),stage)
            assert replacement!=rd.ResourceId.Null(),error
            ctl.ReplaceResource(original,replacement)
            sample=snap(label)
            record['lanes'][label]['shader']=sha256(test).hexdigest()
            if label in ('copy','recompile'):
                assert sample==native,(label,sample,native)
            ctl.RemoveReplacement(original)
            ctl.FreeTargetResource(replacement)
            replacement=None
        assert snap('restored')==native
        assert record['lanes']['baseline']['sha256']==record['lanes']['copy']['sha256']==record['lanes']['restored']['sha256']
        record['status']='qualified'
    except Exception:record['error']=traceback.format_exc()
    finally:
        if ctl:
            if replacement and replacement!=rd.ResourceId.Null():
                ctl.RemoveReplacement(original)
                ctl.FreeTargetResource(replacement)
            ctl.Shutdown()
        cap.Shutdown()
        write(out/'results.json',record)
    os._exit(0 if record['status']=='qualified' else 1)

def launch():
    from hashlib import file_digest
    import sys
    grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==out
    trace=read(out/'trace-iris-base-inputs.json')
    assert trace['status']=='qualified' and len(trace['points'])==5
    native=read(out/'iris-native-input-lanes.json')
    mode=sys.argv[1] if len(sys.argv)>1 else 'lanes'
    assert mode in ('lanes','direction')
    job=read(grid/'engine-iris-explicit-mips/request.json')
    with Path(job['capture']).open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()=='6960267c0d71e4d05b6bfe0e2730c332ed71955f1fde6d69eb7d8aadf13eff24'
    source=Path(job['source'])
    shader='mesh_object_early.frag.spv'
    points=[r['point'] for r in trace['points']]
    if mode=='direction':
        import numpy as np
        points=np.fromfile(grid/'native-iris-stages/points.bin','<u4').reshape(-1,2).tolist()
        assert len(points)==255
    job.update(event=897,shader=shader,shaderSha256=read(Path(job['catalog']))[shader], mode=mode,
        nativeWorldKey=[-native['mainKeyWorld'][0],*native['mainKeyWorld'][1:]],
        points=points,sourceSha256=sha256(source.read_bytes()).hexdigest(),
        eyeIncludeSha256=sha256((source.parent/'character_surface.glsl').read_bytes()).hexdigest())
    dest=out/('iris-engine-input-lanes' if mode=='lanes' else 'iris-engine-main-direction')
    dest.mkdir(exist_ok=True)
    write(dest/'request.json',job)
    startup=subprocess.STARTUPINFO()
    startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=0
    env=dict(os.environ,**{key:str(dest),'VK_DRIVER_FILES':str(grid/'nv-vk64-active-absolute.json')})
    with (dest/'replay.log').open('wb') as log:
        p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__))],
            cwd=dest,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=370)
    data=read(dest/'results.json')
    assert p.returncode==0 and data['status']=='qualified',data.get('error')

if key in os.environ:replay()
elif __name__=='__main__':launch()
