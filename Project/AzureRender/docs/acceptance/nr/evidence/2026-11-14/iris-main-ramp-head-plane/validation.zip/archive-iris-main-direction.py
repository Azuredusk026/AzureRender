from hashlib import file_digest
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

out = Path(__file__).resolve().parent
samples = out.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e'
dest = out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/iris-main-ramp-head-plane'
read = lambda p:json.loads(p.read_bytes())
def digest(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()

results = read(out/'iris-main-direction-scores.json')
assert results['status']=='qualified-source-comparison'
traces = out/'iris-engine-main-direction'
assert results['traceSha256']==digest(traces/'results.json')
actual = {}
members = {p:out/p for p in (Path(__file__).name,'compare-iris-main-direction.py',
    'iris-head-plane-actual.py','probe-iris-input-lanes.py','iris-main-direction-scores.json')}
for path in sorted(traces.iterdir()):
    if path.suffix in ('.json','.frag','.log'):members[path.relative_to(out).as_posix()]=path
for device,expected in [('nvidia',([52,22],[37,7])),('intel',([56,30],[39,13]))]:
    run = samples/f'iris-actual-{device}-scene-head-frame'
    r = read(run/'results.json')
    assert (r['groups']['iris']['overOne'],r['groups']['bare']['overOne'])==expected
    assert r['groups']['covered']['changed']==r['groups']['outside']['changed']==0
    assert r['frameSha256']==digest(run/'frames/frame_000000.png')
    assert r['fragmentSource']==digest(traces/'mesh-scene-head-frame.frag')
    for name,sha in r['shaders'].items():assert digest(run/'resources/shaders'/name)==sha
    for name in ('results.json','command.json','runtime.json','player.log','frames/capture_manifest.json','frames/gpu_capabilities.json'):
        members[device+'/'+name]=run/name
    actual[device]=r
dest.mkdir(parents=True,exist_ok=False)
with ZipFile(dest/'validation.zip','x',ZIP_DEFLATED) as archive:
    for name,path in members.items():archive.write(path,name)
with ZipFile(dest/'validation.zip') as archive:assert set(archive.namelist())==set(members) and archive.testzip() is None
report=dict(overallStatus='failed-user-review',sourceReplay=results,player=actual,
            archive=dict(members=len(members),sha256=digest(dest/'validation.zip')))
(dest/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(report['archive'])
