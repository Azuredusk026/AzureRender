from hashlib import file_digest
from pathlib import Path
import json
import os
import runpy
import subprocess
import sys

import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
face=out.parent/'20261114-051632-face-local-radial-light-retest-ea8fb6'
body=out.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
storage=out.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e'
helper=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read,build,invoke=(helper[k] for k in ('read','build','invoke'))
scorer=runpy.run_path(str(grid/'static-quality.py'))
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def digest(p):
    with p.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()

def main(device,mode):
    assert device in ('nvidia','intel') and mode in ('native-vulkan-fixed','key-head-frame','scene-head-frame')
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==storage
    direction=out/'iris-engine-main-direction'
    receipt=read(direction/'results.json')
    analysis=read(out/'iris-main-direction-scores.json')
    quality=analysis['cases'][mode]['groups']['bare']
    assert receipt['status']=='qualified' and analysis['traceSha256']==digest(direction/'results.json')
    assert quality['aboveOne']<analysis['cases']['baseline']['groups']['bare']['aboveOne'],quality
    source=direction/f'mesh-{mode}.frag'
    sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
    programs=('mesh_object_early_lighting.frag.spv','mesh_object_lighting.frag.spv','mesh_object_early.frag.spv','mesh_object.frag.spv')
    fp=read(body/'face-build-fingerprints.json')
    assert digest(build/'AzurePlayer.exe')==fp['releasePlayer']
    dest=storage/f'iris-actual-{device}-{mode}'
    if dest.exists():
        assert not (dest/'results.json').exists(),dest
        dest.rename(storage/f'{dest.name}-unsuccessful-{len(list(storage.glob(dest.name+"-unsuccessful-*")))+1}')
    dest.mkdir()
    resources=dest/'resources'
    binDir=resources/'shaders'
    binDir.mkdir(parents=True)
    rules={r['output']:r for r in read(build/'shader-reload.json')['programs']}
    updated={}
    inc=out.parents[2]/'shaders'
    for prog in programs:
        rule=rules[prog]
        path=binDir/prog
        cmd=[str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+v for v in rule['defines']),'-I'+str(inc),str(source),'-o',str(path)]
        subprocess.run(cmd,check=True)
        subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(path)],check=True)
        updated[prog]=digest(path)
    stamp=resources/'runtime-build-Release.json'
    stamp.hardlink_to(build/stamp.name)
    cmd=read(face/f'production-{device}-enabled/command.json')
    for flag,value in [('--capture-dir',dest/'frames'),('--resource-root',resources)]:
        assert flag in cmd
        cmd[cmd.index(flag)+1]=str(value)
    cmd+=['--runtime-report',str(dest/'runtime.json')]
    links=[]
    try:
        for name,sha in fp['shaderCatalog'].items():
            if name in updated:continue
            src=build/'shaders'/name
            assert digest(src)==sha
            dst=binDir/name
            dst.hardlink_to(src)
            links.append((dst,src))
        assert len(list(binDir.glob('*.spv')))==895
        frame=invoke(device,cmd,dest)/'frame_000000.png'
    finally:
        for dst,src in links:
            if dst.is_file() and os.path.samefile(dst,src):dst.unlink()
    ref,old,current=[scorer['image'](p).astype('i2') for p in (scorer['reference_path'],
        face/f'production-{device}-enabled/frames/frame_000000.png',frame)]
    with Image.open(grid/'native-face-masks/iris.png') as m:iris=np.asarray(m.convert('L'))>0
    assert iris.sum()==255
    row,col=np.where(iris)
    changed=np.abs(old-current).max(2)
    d0,d1=(np.abs(im-ref).max(2) for im in (old,current))
    points=np.fromfile(grid/'native-iris-stages/points.bin','<u4').reshape(255,2)
    data=runpy.run_path(str(out/'iris-mipmap-attribution.py'),run_name='iris_coordinates')
    assert np.array_equal(data['points'],points) and iris[points[:,1],points[:,0]].all()
    bare=np.zeros(iris.shape,dtype=bool)
    bare[points[:,1],points[:,0]]=data['bare']
    groups={}
    for name,sel in (('iris',iris),('bare',bare),('covered',iris&~bare),('outside',~iris)):
        a,b=d0[sel],d1[sel]
        groups[name]=dict(pixels=int(sel.sum()),overOne=[int((d>1).sum()) for d in (a,b)],
            overEight=[int((d>8).sum()) for d in (a,b)],peak=[int(d.max()) for d in (a,b)],
            newOverOne=int(((a<=1)&(b>1)).sum()),changed=int((changed[sel]>0).sum()))
    write(dest/'results.json',dict(device=device,mode=mode,groups=groups,frameSha256=digest(frame),
          player=fp['releasePlayer'],fragmentSource=digest(source),shaders=updated))
    print(json.dumps(groups))

if __name__=='__main__':main(*sys.argv[1:])
