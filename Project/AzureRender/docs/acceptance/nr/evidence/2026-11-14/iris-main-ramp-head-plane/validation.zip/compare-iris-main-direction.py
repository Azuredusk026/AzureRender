from hashlib import sha256
from pathlib import Path
import json
import runpy
import numpy as np

out=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
raw=runpy.run_path(str(out/'iris-mipmap-attribution.py'))
bare,points,original,display,prior=(raw[k] for k in ('bare','points','original','display','old'))
path=out/'iris-engine-main-direction'
request=read(path/'request.json')
replay=read(path/'results.json')
assert replay['status']=='qualified' and np.array_equal(points,request['points'])
base=np.asarray(replay['lanes']['baseline']['rows'])[:,:3]
assert np.array_equal(base,prior)
absError=lambda v:np.abs(display(v)-display(original)).max(1)
baseline=absError(base)
cases={}
for case in ('baseline','native-vulkan-fixed','key-world','key-head-frame','scene-head-frame'):
    v=np.asarray(replay['lanes'][case]['rows'])[:,:3]
    err=absError(v)
    changes=(v!=base).any(1)
    cases[case]=dict(sourceShader=replay['lanes'][case].get('shader',request['shaderSha256']),groups={})
    for group,mask in [('all',np.ones(len(points),dtype=bool)),('bare',bare),('covered',~bare)]:
        cases[case]['groups'][group]=dict(pixels=int(mask.sum()),changed=int((changes&mask).sum()),
            aboveOne=int(((err>1)&mask).sum()),aboveEight=int(((err>8)&mask).sum()),
            newAboveOne=int(((baseline<=1)&(err>1)&mask).sum()),peak=int(err[mask].max()),
            changedDisplay=int((np.any(display(v)!=display(base),axis=1)&mask).sum()))
    witnesses=read(out/'iris-native-input-lanes.json')['rows']
    cases[case]['focus']={str(p['point']):int(err[np.where((points==p['point']).all(1))[0][0]]) for p in witnesses}
report=dict(status='qualified-source-comparison',cases=cases,
            traceSha256=sha256((path/'results.json').read_bytes()).hexdigest())
(out/'iris-main-direction-scores.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(cases))
