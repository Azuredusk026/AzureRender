from pathlib import Path
import json
import os
import subprocess
import sys
import time

run=Path(__file__).resolve().parent
deadline=time.monotonic()+420
while not (run/"historical-build-result.json").is_file():
    if time.monotonic()>=deadline:
        raise TimeoutError("Reconstructed producer build receipt did not appear")
    time.sleep(2)
subprocess.run([sys.executable,str(run/"capture_historical.py")],check=True,timeout=750,
               cwd=Path.cwd(),env=os.environ.copy())
