from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

run=Path(__file__).resolve().parent
root=Path.cwd().resolve()
product=run/"historical-release"
out=run/"historical-59579"
build_data=json.loads((run/"historical-build-result.json").read_bytes())
preflight=json.loads((run/"preflight.json").read_bytes())
assert build_data["source"].startswith("cd8d95d")
sys.path.insert(0,str(root/"tools"))
from gpu_environment import RunEnvironmentMonitor,snapshot
from PIL import Image
import numpy as np
with (root/"docs/acceptance/nr/evidence/2026-11-05/outline-snapshot-order/release-joint--command.json").open(encoding="utf-8") as inp:
    args=json.load(inp)
exe=product/"AzurePlayer.exe"
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
assert sha(exe)==build_data["builtPlayerSha256"]
args[0]=str(exe)
args[args.index("--capture-dir")+1]=str(out/"frames")
args[args.index("--runtime-report")+1]=str(out/"runtime.json")
args+=["--resource-root",str(product)]
device=snapshot()
assert device["driver"]=="595.79"
out.mkdir(exist_ok=True)
env=dict(os.environ,VK_LOADER_DRIVERS_SELECT="*nv-vk64*")
env["PATH"]=os.pathsep.join((str(product),str(root/"build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin"),env["PATH"]))
for name in ("VK_DRIVER_FILES","VK_ICD_FILENAMES","VK_INSTANCE_LAYERS","VK_LAYER_ENABLES","VK_LAYER_VALIDATE_SYNC",
             "AZURERENDER_RESOURCE_ROOT","AZURE_DIAGNOSTIC_NONLOCAL_TEXTURES","AZURE_DISABLE_COMPUTED_MATERIAL_VIEW"):
    env.pop(name,None)
(out/"command.json").write_text(json.dumps(args,indent=2)+"\n",encoding="utf-8")
evidence={"startup":[device]}
with RunEnvironmentMonitor(evidence,path=out/"environment.json",interval=2),(out/"player.log").open("wb") as log:
    subprocess.run(args,cwd=run/"historical-source/Project/AzureRender",env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=720)
assert "Allocator after unload: buffers=0 images=0" in (out/"player.log").read_text(errors="replace")
frozen=root/"build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames"
current=root/"build/runs/20261114-020728-nr-joint-59579-main-visual-1bcbe5/baseline-original-four/frames"
result=[]
for frame in preflight["frozenFrames"]:
    name=frame["name"]
    actual=out/"frames"/name
    assert sha(frozen/name)==frame["referenceSha256"]
    def pixels(path):
        with Image.open(path) as image:
            return np.asarray(image.convert("RGB"),dtype=np.int16)
    value=pixels(actual)
    frozen_delta=np.abs(value-pixels(frozen/name))
    current_delta=np.abs(value-pixels(current/name))
    result.append({"name":name,"actualSha256":sha(actual),"frozenDeltaPixels":int(np.count_nonzero(np.any(frozen_delta,axis=2))),
                   "frozenDeltaMaximum":int(frozen_delta.max()),"main59579DeltaPixels":int(np.count_nonzero(np.any(current_delta,axis=2))),
                   "main59579DeltaMaximum":int(current_delta.max())})
assert sha(exe)==build_data["builtPlayerSha256"]
(out/"results.json").write_text(json.dumps({"build":build_data,"driver":device["driver"],"frames":result},indent=2)+"\n",encoding="utf-8")
print([{k:v for k,v in frame.items() if k!="actualSha256"} for frame in result],flush=True)
