from pathlib import Path
import argparse
import json
import os
import re
import subprocess
import sys
from zipfile import ZipFile

import numpy as np
from PIL import Image

parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=("preflight","capture"))
parser.add_argument("placement")
parser.add_argument("candidate")
parser.add_argument("--expected-driver", default="592.82")
options = parser.parse_args()
root = Path.cwd().resolve()
task = Path(__file__).resolve().parent
placement = Path(options.placement)
candidate = Path(options.candidate)
build = placement/"build/catalog-computed"
sys.path.insert(0,str(placement/"tools"))
from build_provenance import digest, verify
from gpu_environment import snapshot

receipt = json.loads((candidate/"candidate-receipt.json").read_bytes())
baseline_proof = Path(receipt["baseReceiptPath"])
assert digest(baseline_proof)==receipt["baseReceiptSha256"]
baseline=json.loads(baseline_proof.read_bytes())
review = root/"docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope"
with ZipFile(review/"validation.zip") as archive:
    command = json.loads(archive.read("run/capture-command.json"))["command"]
    project_assets = json.loads(archive.read("run/frozen-project-inputs.json"))
frozen_data=json.loads((review/"results.json").read_bytes())["originalFour"]["frames"]
frozen=root/"build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames"
main = root/"build/ninja-msvc-release/AzurePlayer.exe"
published = root/"docs/acceptance/nr/evidence/2026-11-13/frozen-public-visual/driver-59579-results.json"
approved_main=json.loads(published.read_bytes())["main"]["release"]["playerSha256"]

def verify_inputs():
    verify(placement,baseline)
    assert len(project_assets)==1729 and all(digest(Path(path))==sha for path,sha in project_assets.items())
    assert all(digest(Path(path))==sha for path,sha in receipt["inputsAndProducts"].items())
    assert all(digest(frozen/row["name"])==row["referenceSha256"] for row in frozen_data)
    assert digest(main)==approved_main

verify_inputs()
device = snapshot()
plan = {"candidateCommit":receipt["commit"],"frozenDriver":"592.82","requestedDriver":options.expected_driver,
        "currentDriver":device["driver"],"renderAdapter":device["gpu"],"resourceRoot":str(build),
        "frozenInputCount":len(project_assets),"frozenFrames":frozen_data,
        "candidateReceiptSha256":digest(candidate/"candidate-receipt.json"),
        "sourceProductSha256":{"candidate":digest(candidate/"AzurePlayer.exe"),
                               "referenceComputedPlayer":digest(build/"AzurePlayer.exe"),
                               "standardMainPlayer":digest(main)},
        "sameDriverModes":["main-standard","reference-material","computed-material","nonlocal-images"],
        "captureCommandSeed":command}
(task/"preflight.json").write_text(json.dumps(plan,indent=2)+"\n",encoding="utf-8")
print("NVIDIA", device["driver"], options.mode, len(project_assets), "inputs accepted")
if options.mode=="preflight":
    raise SystemExit(0)
assert device["driver"] == options.expected_driver, "The selected runtime does not match the requested driver"
assert len(frozen_data)==4
all_results=[]
for route in plan["sameDriverModes"]:
    name = route+"-"+device["driver"].replace(".","-")
    out=task/name
    out.mkdir()
    player = main if route == "main-standard" else candidate/"AzurePlayer.exe" if route=="nonlocal-images" else build/"AzurePlayer.exe"
    if route=="main-standard":
        resources=main.parent
    else:
        resources=build
    args=command.copy()
    args[0]=str(player)
    args+=["--resource-root",str(resources)]
    for key, dest in (("--capture-dir",out/"frames"),("--runtime-report",out/"runtime.json"),
                      ("--gpu-timing-output",out/"timing.json")):
        args[args.index(key)+1]=str(dest)
    env=dict(os.environ,VK_LOADER_DRIVERS_SELECT="*nv-vk64*",DOTNET_ROOT="D:/Tools/dotnet9")
    env["PATH"]=os.pathsep.join((str(resources),str(root/"build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin"),env["PATH"]))
    for key in ("VK_DRIVER_FILES","VK_ICD_FILENAMES","VK_INSTANCE_LAYERS","VK_LAYER_ENABLES","VK_LAYER_VALIDATE_SYNC",
                "AZURERENDER_RESOURCE_ROOT","AZURE_DIAGNOSTIC_NONLOCAL_TEXTURES","AZURE_DISABLE_COMPUTED_MATERIAL_VIEW"):
        env.pop(key,None)
    if route=="reference-material":
        env["AZURE_DISABLE_COMPUTED_MATERIAL_VIEW"]="1"
    if route=="nonlocal-images":
        env["AZURE_DIAGNOSTIC_NONLOCAL_TEXTURES"]="1"
    (out/"command.json").write_text(json.dumps(args,indent=2)+"\n",encoding="utf-8")
    with (out/"player.log").open("wb") as log:
        subprocess.run(args,env=env,cwd=root if route=="main-standard" else placement,
                       stdout=log,stderr=subprocess.STDOUT,check=True,timeout=620)
    log=(out/"player.log").read_text(errors="replace")
    assert "Allocator after unload: buffers=0 images=0" in log
    stats=json.loads((out/"timing.json").read_bytes())
    assert (stats["computedMaterialViewSelectionsTotal"]>0) == (route in ("computed-material","nonlocal-images"))
    assert ("Nonlocal material image" in log)==(route=="nonlocal-images")
    if route=="nonlocal-images":
        assert len(re.findall(r"^Nonlocal material image",log,re.M))==224
    rows=[]
    for original in frozen_data:
        produced=out/"frames"/original["name"]
        with Image.open(produced) as image:
            actual=np.asarray(image.convert("RGB"),dtype=np.int16)
        with Image.open(frozen/original["name"]) as image:
            expected=np.asarray(image.convert("RGB"),dtype=np.int16)
        change=np.abs(actual-expected)
        rows.append({"name":original["name"],"actualSha256":digest(produced),"frozenSha256":original["referenceSha256"],
                     "changedPixels":int(np.count_nonzero(np.any(change,axis=2))),"maximumRGBDelta":int(change.max())})
    assert snapshot()["driver"]==device["driver"]
    entry={"route":route,"driver":device["driver"],"frames":rows}
    (out/"results.json").write_text(json.dumps(entry,indent=2)+"\n",encoding="utf-8")
    all_results.append(entry)
    print(route,[row["changedPixels"] for row in rows],flush=True)
verify_inputs()
exact=all(row["changedPixels"]==0 and row["actualSha256"]==row["frozenSha256"]
          for result in all_results for row in result["frames"])
(task/("results-"+device["driver"].replace(".","-")+".json")).write_text(
    json.dumps({"driver":device["driver"],"frozenDriver":"592.82","strictPass":exact,"routes":all_results},indent=2)+"\n",encoding="utf-8")
if not exact and device["driver"]=="592.82":
    raise SystemExit("Strict frozen verification failed")
