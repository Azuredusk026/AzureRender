import hashlib
import json
from pathlib import Path
import subprocess

root=Path.cwd()
out=Path(__file__).resolve().parent
data=json.loads((root/"docs/acceptance/nr/evidence/2026-11-05/outline-snapshot-order/results.json").read_bytes())
match={}
for file in data["testedSources"]:
    relative="Project/AzureRender/"+file["path"]
    blob=subprocess.check_output(["git","show","cd8d95d:"+relative],cwd=root)
    sha=hashlib.sha256(blob.replace(b"\r\n",b"\n")).hexdigest()
    match[file["path"]]={"rebuiltSourceSha256":sha,"frozenCanonicalSha256":file["canonicalSha256"],
                        "matches":sha==file["canonicalSha256"]}
(out/"historical-source-match.json").write_text(json.dumps(match,indent=2)+"\n",encoding="utf-8")
print({key:value["matches"] for key,value in match.items()})
assert all(row["matches"] for row in match.values())
