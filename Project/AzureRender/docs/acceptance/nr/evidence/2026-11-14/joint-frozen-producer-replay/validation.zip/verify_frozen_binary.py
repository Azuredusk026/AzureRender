from pathlib import Path
from hashlib import sha256
import json
import sys

folder=Path(__file__).resolve().parent
root=Path.cwd()
expected=(json.loads((root/"docs/acceptance/nr/evidence/2026-11-05/outline-snapshot-order/release-joint--program.json").read_bytes())
          ["playerSha256"])
scopes=(root/"build",Path("D:/Projects/FYP-worktrees/nr-integration-verified/Project/AzureRender/build"))
files=set()
import subprocess
for base in scopes:
    cmd=["rg","--files","--hidden","--no-ignore",str(base),"-g","*AzurePlayer*.exe","-g","!*dependency*"]
    report=subprocess.run(cmd,check=True,capture_output=True,text=True,encoding="utf-8")
    files.update(Path(line) for line in report.stdout.splitlines())
rows=[]
for path in sorted(files):
    if not path.is_file():
        continue
    with path.open("rb") as stream:
        fingerprint=__import__("hashlib").file_digest(stream,"sha256").hexdigest()
    rows.append({"file":str(path),"size":path.stat().st_size,"sha256":fingerprint})
matches=[row for row in rows if row["sha256"]==expected]
(folder/"frozen-binary-scan.json").write_text(json.dumps({"frozenSha256":expected,"tested":len(rows),"matches":matches},indent=2)+"\n",encoding="utf-8")
print(expected,len(rows),matches,flush=True)
