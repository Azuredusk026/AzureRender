from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile

root=Path.cwd().resolve()
run=Path(__file__).resolve().parent
gitroot=root.parent.parent
source=run/"historical-source"
tree=source/"Project/AzureRender"
bits=run/"historical-release"
historical="cd8d95dd004a59f58ef134b8a9ba34ed2a3abfe2"
assert not source.exists()
source.mkdir()
children=["src","shaders","assets_public","cmake","tools","schemas","managed","third_party","CMakeLists.txt",
          "CMakePresets.json","vcpkg.json","vcpkg-configuration.json","docs/plans"]
tree_files=subprocess.check_output(["git","-C",str(gitroot),"ls-tree","--name-only",historical+":Project/AzureRender"],text=True)
selected=["Project/AzureRender/"+name for name in children if name.split("/")[0] in tree_files.splitlines()]
members=subprocess.run(["git","-C",str(gitroot),"archive",historical,*selected],stdout=subprocess.PIPE,check=True,timeout=95)
with __import__("io").BytesIO(members.stdout) as raw,tarfile.open(fileobj=raw) as archive:
    for item in archive.getmembers():
        destination=(source/item.name).resolve()
        assert destination.is_relative_to(source.resolve()) and not (item.issym() or item.islnk())
    archive.extractall(source)
env=dict(os.environ,VCPKG_ROOT="D:/Tools/vcpkg",VULKAN_SDK="D:/Tools/VulkanSDK/1.4.350.0",
         DOTNET_ROOT="D:/Tools/dotnet9",CMAKE_BUILD_PARALLEL_LEVEL="3")
cmake=Path("D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe")
ninja=cmake.parents[2]/"Ninja/ninja.exe"
installed=root/"build/ninja-msvc-debug/vcpkg_installed"
configure=[str(cmake),"-S",str(tree),"-B",str(bits),"-G","Ninja","-DCMAKE_BUILD_TYPE=Release",
           "-DCMAKE_MAKE_PROGRAM="+str(ninja),
           "-DCMAKE_TOOLCHAIN_FILE=D:/Tools/vcpkg/scripts/buildsystems/vcpkg.cmake",
           "-DVCPKG_TARGET_TRIPLET=x64-windows","-DVCPKG_MANIFEST_INSTALL=OFF",
           "-DVCPKG_INSTALLED_DIR="+str(installed),"-DPython3_EXECUTABLE="+sys.executable,
           "-DBUILD_TESTING=OFF","-DAZURE_ENABLE_MANAGED_SCRIPT_PROTOTYPE=OFF"]
build=[str(cmake),"--build",str(bits),"--target","AzurePlayer"]
(run/"historical-build-command.json").write_text(json.dumps({"source":historical,"commands":[configure,build]},indent=2)+"\n")
batch=root/"tools/msvc_env.bat"
for step,argv,timeout in (("configure",configure,200),("build",build,1250)):
    with (run/("historical-"+step+".log")).open("wb") as log:
        subprocess.run([str(batch),*argv],env=env,cwd=tree,timeout=timeout,stdout=log,stderr=subprocess.STDOUT,check=True)
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
reference=json.loads((root/"docs/acceptance/nr/evidence/2026-11-05/outline-snapshot-order/release-joint--program.json").read_bytes())
shaders={path.name:sha(path) for path in sorted((bits/"shaders").glob("*.spv"))}
exact=[name for name,value in reference["shaders"].items() if shaders.get(name)==value]
missing=sorted(set(reference["shaders"])-shaders.keys())
changed=sorted(set(reference["shaders"])-set(exact)-set(missing))
result={"scope":"reconstructed historical source","source":historical,"builtPlayerSha256":sha(bits/"AzurePlayer.exe"),
        "frozenPlayerSha256":reference["playerSha256"],"builtShaders":len(shaders),"frozenShaders":len(reference["shaders"]),
        "matchingShaders":len(exact),"missingShaders":missing,"changedShaders":changed}
(run/"historical-build-result.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result),flush=True)
