from pathlib import Path
import json, math, struct
import numpy as np

run=Path(__file__).resolve().parent
source=run/'native-face-skin-stages'
report=json.loads((source/'results.json').read_bytes())
info=report['geometry']['1018']
verts=np.fromfile(source/'vertex-1018.bin','<f4').reshape(-1,info['vertexStride']//4).astype(float)
body=np.fromfile(source/'vertex-783.bin','<f4').reshape(-1,info['vertexStride']//4).astype(float)
ix=(np.fromfile(source/'index-1018.bin','<u'+str(info['indexStride'])).astype(int)+info['baseVertex']).reshape(-1,3)
depth=run/'native-body-outline-depth'
old=np.fromfile(depth/'depth-1017.bin','<u4').reshape(1440,2560,2)[::-1]
new=np.fromfile(depth/'depth-1018.bin','<u4').reshape(1440,2560,2)[::-1]
changed=old[:,:,0]!=new[:,:,0]
pos=verts[:,:4]
screen=(pos[:,:2]/pos[:,3,None]+1)*[1280,720]
results={}
for precision in (0,256):
    candidate=screen if precision==0 else np.rint(screen*precision)/precision
    edges=candidate[ix[:,1:]]-candidate[ix[:,:1]]
    cross=edges[:,0,0]*edges[:,1,1]-edges[:,0,1]*edges[:,1,0]
    area=np.abs(cross)
    z=pos[:,2]/pos[:,3]
    mask=np.zeros((1440,2560),bool)
    math_depth=np.zeros((1440,2560),np.float32)
    raw_before=old[:,:,0].view('<f4')
    for order in (-1,1):
        mask[:]=False
        math_depth[:]=0
        for tri,i in zip(ix[np.sign(cross)==order],np.flatnonzero(np.sign(cross)==order)):
            p=candidate[tri]
            lo=np.maximum(0,np.floor(p.min(0)-.5).astype(int))
            hi=np.minimum([2560,1440],np.ceil(p.max(0)+.5).astype(int))
            if (lo>=hi).any():continue
            xx,yy=np.meshgrid(np.arange(lo[0],hi[0])+.5,np.arange(lo[1],hi[1])+.5)
            x,y=xx-p[0,0],yy-p[0,1]
            u=(x*edges[i,1,1]-y*edges[i,1,0])/cross[i]
            v=(y*edges[i,0,0]-x*edges[i,0,1])/cross[i]
            w=1-u-v
            valid=(u>=0)&(v>=0)&(w>=0)
            tested=w*z[tri[0]]+u*z[tri[1]]+v*z[tri[2]]
            ys,xs=slice(lo[1],hi[1]),slice(lo[0],hi[0])
            depth_slice=math_depth[ys,xs]
            np.maximum(depth_slice,np.where(valid,tested,0),out=depth_slice)
            mask[ys,xs]|=valid
        result=mask&(math_depth>raw_before)
        y,x=np.where(changed&~result)
        results[f"{precision}:{order}"]=dict(covered=int(mask.sum()),passed=int(result.sum()),matches=int((changed&result).sum()),
            missing=int((changed&~result).sum()),extra=int((result&~changed).sum()),
            misses=np.column_stack([x,y]).tolist())
(depth/'cpu-grid-raster.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
