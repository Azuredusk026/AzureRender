from hashlib import file_digest
from pathlib import Path
import json,os,subprocess

run=Path(__file__).resolve().parent
lock=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state']=='held' and Path(lock['output'])==run
out=run/'native-body-outline-depth';out.mkdir()
job=json.loads((run/'native-face-masks/request.json').read_bytes())
with Path(job['native']).open('rb') as stream:
    assert file_digest(stream,'sha256').hexdigest()==job['captureSha256']
job['points']={kind:str(run/f'{kind}-residual-points.bin') for kind in ('face','skin')}
(out/'request.json').write_text(json.dumps(job,indent=2)+'\n')
env=os.environ.copy(); env['AZURE_NR_FACE_SKIN_STAGES']=str(out)
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
with (out/'replay.log').open('wb') as log:
    process=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(run/'native-body-outline-depth-worker.py')],
                           cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=380)
report=json.loads((out/'results.json').read_bytes())
assert process.returncode==0 and report['status']=='qualified',report

