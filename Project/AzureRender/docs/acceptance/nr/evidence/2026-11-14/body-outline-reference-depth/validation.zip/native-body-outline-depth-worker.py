from pathlib import Path
from hashlib import sha256
import json,math,os,struct,traceback
import renderdoc as rd

out=Path(os.environ['AZURE_NR_FACE_SKIN_STAGES'])
job=json.loads((out/'request.json').read_bytes())
capture=rd.OpenCaptureFile(); ctl=None; report=dict(status='failed')
try:
    assert capture.OpenFile(job['native'],'',None)==rd.ResultCode.Succeeded
    opt=rd.ReplayOptions();opt.forceGPUVendor=rd.GPUVendor.nVidia;opt.forceGPUDeviceID=0x28e0
    status,ctl=capture.OpenCapture(opt,None)
    assert status==rd.ResultCode.Succeeded and ctl
    for event in (1017,1018):
        ctl.SetFrameEvent(event,True)
        depth=ctl.GetPipelineState().GetDepthTarget().resource
        data=bytes(ctl.GetTextureData(depth,rd.Subresource()))
        assert len(data)==2560*1440*8
        path=out/f'depth-{event}.bin'
        path.write_bytes(data)
        report[str(event)]=dict(bytes=len(data),sha256=sha256(data).hexdigest())
    report['status']='qualified'
except Exception:report['error']=traceback.format_exc()
finally:
    if ctl:ctl.Shutdown()
    capture.Shutdown()
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)
