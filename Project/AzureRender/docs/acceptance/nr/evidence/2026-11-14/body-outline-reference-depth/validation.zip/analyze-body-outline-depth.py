from pathlib import Path
from hashlib import sha256
import json,runpy
import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
depth=run/'native-body-outline-depth'
state=json.loads((run/'native-body-outline-state/results.json').read_bytes())
report=json.loads((depth/'results.json').read_bytes())
assert state['status']==report['status']=='qualified'
def data(event):
    p=depth/f'depth-{event}.bin'
    raw=p.read_bytes()
    assert sha256(raw).hexdigest()==state['events'][str(event)]['depthSha256']==report[str(event)]['sha256']
    return np.frombuffer(raw,dtype='<u4').reshape(1440,2560,2)[::-1]
old,new=map(data,(1017,1018))
changed=old[:,:,0]!=new[:,:,0]
stencil=((old[:,:,1]^new[:,:,1])&255)!=0
before=old[:,:,0].view('<f4')
after=new[:,:,0].view('<f4')
assert np.all(after[changed]>before[changed])
y,x=np.nonzero(changed)
raw=run/'native-body-outline-depth/changed-native-pixels.bin'
np.column_stack([x,y,old[y,x,0],new[y,x,0],old[y,x,1],new[y,x,1]]).astype('<u4').tofile(raw)
source=json.loads((run/'face-skin-overlay-ownership.json').read_bytes())
tx,ty=np.array(source['skin']['1018']['locations']).T
a=np.asarray(Image.open(run/'body-outline-depth-control/back/frames/frame_000000.png').convert('RGB'))
fixture=(a[:,:,1]>249)&(a[:,:,0]<32)&(a[:,:,2]<32)
result=dict(depthChanges=int(changed.sum()),stencilChanges=int(stencil.sum()),stencilAfterHistogram={
    str(int(v)):int(n) for v,n in zip(*np.unique(new[:,:,1][changed]&255,return_counts=True))},
    targetDepthChanges=int(changed[ty,tx].sum()),fixtureChanges=int(fixture.sum()),
    fixtureDepthIntersection=int((fixture&changed).sum()),nativeDepthChangesAbsentFromFixture=int((changed&~fixture).sum()),
    missingBounds=[int(x.min()),int(y.min()),int(x.max()+1),int(y.max()+1)],
    minimumWrittenDepthDelta=float((after[changed]-before[changed]).min()),
    maximumWrittenDepthDelta=float((after[changed]-before[changed]).max()),
    pixelRecordSha256=sha256(raw.read_bytes()).hexdigest())
(depth/'coverage.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
