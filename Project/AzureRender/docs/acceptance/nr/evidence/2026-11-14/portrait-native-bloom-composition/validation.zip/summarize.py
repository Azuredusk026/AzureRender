from hashlib import sha256
from pathlib import Path
import json
import numpy as np

out = Path(__file__).resolve().parent
result = json.loads((out/'results.json').read_bytes())
assert result['status']=='qualified'
targets = {frame:row['candidates'][0] for frame,row in result['captures'].items()}
assert targets['10401']['shaderSha256']==targets['6834']['shaderSha256']
assert targets['10401']['bloomSha256']=='8dc3ff815809fd1ab9a2e9fc41be94cd014d95b16ebd3defea505cf04dc92e47'


def unsigned_float(field, mantissa_bits):
    exponent = (field>>mantissa_bits).astype(np.int16)
    mantissa = (field&((1<<mantissa_bits)-1)).astype(float)/(1<<mantissa_bits)
    assert (exponent<31).all()
    return np.where(exponent==0,np.ldexp(mantissa,-14),np.ldexp(1+mantissa,exponent-15))


for frame, row in targets.items():
    raw = (out/f'{frame}-bloom.bin').read_bytes()
    assert len(raw)==1280*720*4 and sha256(raw).hexdigest()==row['bloomSha256']
    data = np.frombuffer(raw,'<u4')
    channels = np.column_stack([unsigned_float(data&2047,6),unsigned_float((data>>11)&2047,6),
                                unsigned_float(data>>22,5)])
    constants = np.fromfile(out/f"{row['name']}-cb1.bin",'<f4').reshape(-1,4)
    row['bloomSummary'] = dict(peak=channels.max(0).tolist(),mean=channels.mean(0).tolist(),
        percentile99=np.quantile(channels,.99,axis=0).tolist(),nonzero=(channels>0).sum(0).tolist(),
        compositionScale=constants[11,:3].tolist())

summary = dict(status='native-bloom-source-qualified',overallStatus='failed-user-review',
    nativeFrames=targets,sameFullScreenShader=True,fixturePoseMatched=False)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
