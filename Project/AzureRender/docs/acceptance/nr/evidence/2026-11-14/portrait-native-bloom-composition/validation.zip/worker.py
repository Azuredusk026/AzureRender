from hashlib import sha256
from pathlib import Path
import json
import os
import traceback

import renderdoc as rd

out = Path(os.environ['AZURE_NR_NATIVE_BLOOM_COMPOSITION'])
inputs = json.loads((out/'request.json').read_bytes())
report = dict(status='failed',captures={})


def walk(actions):
    for action in actions:
        if action.children:
            yield from walk(action.children)
        else:
            yield action


def inspect(frame, source):
    capture = rd.OpenCaptureFile()
    controller = None
    try:
        assert capture.OpenFile(source['path'],'',None)==rd.ResultCode.Succeeded
        options = rd.ReplayOptions()
        options.forceGPUVendor = rd.GPUVendor.nVidia
        options.forceGPUDeviceID = 0x28e0
        status, controller = capture.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and controller
        assert controller.GetAPIProperties().pipelineType==rd.GraphicsAPI.D3D11
        textures = {str(t.resourceId):t for t in controller.GetTextures()}
        row = report['captures'][frame] = dict(source=source,candidates=[],fullscreen=[])
        action_list = list(walk(controller.GetRootActions()))
        for action in action_list:
            if action.eventId<900 or not action.flags&rd.ActionFlags.Drawcall or action.numIndices>8:
                continue
            controller.SetFrameEvent(action.eventId,False)
            pipe = controller.GetPipelineState()
            reflection = pipe.GetShaderReflection(rd.ShaderStage.Fragment)
            if not reflection:
                continue
            textures_by_slot = {}
            for slot in pipe.GetReadOnlyResources(rd.ShaderStage.Fragment):
                key = str(slot.descriptor.resource)
                tex = textures.get(key)
                if tex is None:
                    continue
                i = reflection.readOnlyResources[slot.access.index].fixedBindNumber
                textures_by_slot[i] = dict(id=key,width=tex.width,height=tex.height,depth=tex.depth,
                                           format=slot.descriptor.format.Name(),storage=tex.format.Name())
            targets = [str(t.resource) for t in pipe.GetOutputTargets()]
            row['fullscreen'].append(dict(event=action.eventId,textures=textures_by_slot,targets=targets))
            if action.eventId!={'10401':1777,'6834':1598}[frame]:
                continue
            active = pipe.GetGraphicsPipelineObject()
            shader = bytes(reflection.rawBytes)
            name = f'{frame}-{action.eventId}-compose'
            (out/f'{name}.asm').write_text(controller.DisassembleShader(active,reflection,''),encoding='utf8')
            candidate = dict(event=action.eventId,shaderSha256=sha256(shader).hexdigest(),
                             name=name,textures=textures_by_slot,targets=targets)
            row['candidates'].append(candidate)
            assert textures_by_slot[1]['format']=='R11G11B10_FLOAT'
            desc = controller.GetPipelineState()
            for index, block in enumerate(reflection.constantBlocks):
                binding = desc.GetConstantBlock(rd.ShaderStage.Fragment,index,0).descriptor
                if binding.resource==rd.ResourceId.Null():
                    continue
                payload = bytes(controller.GetBufferData(binding.resource,binding.byteOffset,binding.byteSize))
                (out/f'{name}-cb{block.fixedBindNumber}.bin').write_bytes(payload)
            controller.SetFrameEvent(action.eventId,True)
            source_slot, = (x for x in controller.GetPipelineState().GetReadOnlyResources(rd.ShaderStage.Fragment)
                            if reflection.readOnlyResources[x.access.index].fixedBindNumber==1)
            raw = bytes(controller.GetTextureData(source_slot.descriptor.resource,rd.Subresource()))
            assert len(raw)==1280*720*4
            (out/f'{frame}-bloom.bin').write_bytes(raw)
            candidate['bloomSha256']=sha256(raw).hexdigest()
        assert len(row['candidates'])==1, frame
    finally:
        if controller:
            controller.Shutdown()
        capture.Shutdown()


try:
    for key, source in inputs.items():
        inspect(key,source)
    report['status']='qualified'
except Exception:
    report['error']=traceback.format_exc()
finally:
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)
