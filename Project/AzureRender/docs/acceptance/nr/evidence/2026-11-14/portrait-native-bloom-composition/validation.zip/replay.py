from hashlib import file_digest
from pathlib import Path
import json
import os
import subprocess

out = Path(__file__).resolve().parent
lock = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state']=='held' and Path(lock['output'])==out
source = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719')
index = json.loads((source/'capture-files-verified.json').read_bytes())
inputs = {}
for frame in (10401,6834):
    path = source/f'Endfield-games-child_frame{frame}.rdc'
    receipt, = (r for r in index if r['path'].endswith(path.name))
    with path.open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==receipt['sha256'].lower()
    inputs[frame] = dict(path=str(path),sha256=receipt['sha256'].lower())
(out/'request.json').write_text(json.dumps(inputs,indent=2)+'\n')
environment = os.environ.copy()
environment['AZURE_NR_NATIVE_BLOOM_COMPOSITION'] = str(out)
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
with (out/'replay.log').open('wb') as log:
    result = subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'worker.py')],
                            cwd=out,env=environment,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=520)
report = json.loads((out/'results.json').read_bytes())
assert result.returncode==0 and report['status']=='qualified',report
