Shader hash 9067bc85-2b431d0e-0fb2dba2-fe9167d4

ps_5_0
      dcl_globalFlags refactoringAllowed
      dcl_constantbuffer cb0[28], immediateIndexed
      dcl_constantbuffer cb1[29], immediateIndexed
      dcl_sampler s0, mode_default
      dcl_resource_texture2d (float,float,float,float) t0
      dcl_resource_texture2d (float,float,float,float) t1
      dcl_resource_texture2d (float,float,float,float) t2
      dcl_input_ps linear v1.xy
      dcl_output o0.xyzw
      dcl_temps 9
   0: dp2 r0.x, cb1[26].xyxx, v1.xyxx
   1: add r0.x, r0.x, cb1[26].z
   2: lt r0.y, cb1[26].w, abs(r0.x)
   3: if_nz r0.y
   4:   lt r0.x, r0.x, l(0)
   5:   movc r0.xyzw, r0.xxxx, cb1[27].xyzw, cb1[28].xyzw
   6:   mad r0.xy, v1.xyxx, r0.xyxx, r0.zwzz
   7:   lt r0.zw, r0.xxxy, l(0, 0, 0, 0)
   8:   or r0.z, r0.w, r0.z
   9:   lt r1.xy, l(1.000000, 1.000000, 0.000000, 0.000000), r0.xyxx
  10:   or r0.w, r1.y, r1.x
  11:   or r0.z, r0.w, r0.z
  12:   if_z r0.z
  13:     sample_l(texture2d)(float,float,float,float) r1.xyzw, r0.xyxx, t0.xyzw, s0, l(0)
  14:     mov r2.xw, l(0, 0, 0, 0)
  15:     mov r2.yz, cb0[0].wwzw
  16:     add r3.xyzw, r0.xyxy, r2.xyzw
  17:     sample_l(texture2d)(float,float,float,float) r4.xyz, r3.xyxx, t0.xyzw, s0, l(0)
  18:     add r2.xyzw, r0.xyxy, -r2.zwxy
  19:     sample_l(texture2d)(float,float,float,float) r5.xyz, r2.xyxx, t0.xyzw, s0, l(0)
  20:     sample_l(texture2d)(float,float,float,float) r3.xyz, r3.zwzz, t0.xyzw, s0, l(0)
  21:     sample_l(texture2d)(float,float,float,float) r2.xyz, r2.zwzz, t0.xyzw, s0, l(0)
  22:     mad r0.z, r4.x, l(0.500000), r4.y
  23:     mad r0.z, r4.z, l(0.500000), r0.z
  24:     mad r0.w, r5.x, l(0.500000), r5.y
  25:     mad r0.w, r5.z, l(0.500000), r0.w
  26:     mad r2.w, r1.x, l(0.500000), r1.y
  27:     mad r2.w, r1.z, l(0.500000), r2.w
  28:     mad r3.w, r3.x, l(0.500000), r3.y
  29:     mad r3.w, r3.z, l(0.500000), r3.w
  30:     mad r4.w, r2.x, l(0.500000), r2.y
  31:     mad r4.w, r2.z, l(0.500000), r4.w
  32:     min r6.xyz, r3.xyzx, r5.xyzx
  33:     min r6.xyz, r4.xyzx, r6.xyzx
  34:     min r6.xyz, r2.xyzx, r6.xyzx
  35:     max r7.xyz, r3.xyzx, r5.xyzx
  36:     max r7.xyz, r4.xyzx, r7.xyzx
  37:     max r7.xyz, r2.xyzx, r7.xyzx
  38:     div r8.xyz, l(0.250000, 0.250000, 0.250000, 0.000000), r7.xyzx
  39:     mul r8.xyz, r6.xyzx, r8.xyzx
  40:     add r7.xyz, -r7.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
  41:     mad r6.xyz, r6.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-4.000000, -4.000000, -4.000000, 0.000000)
  42:     div r6.xyz, l(1.000000, 1.000000, 1.000000, 1.000000), r6.xyzx
  43:     mul r6.xyz, r6.xyzx, r7.xyzx
  44:     max r6.xyz, r6.xyzx, -r8.xyzx
  45:     max r5.w, r6.z, r6.y
  46:     max r5.w, r5.w, r6.x
  47:     min r5.w, r5.w, l(0)
  48:     max r5.w, r5.w, l(-0.187500)
  49:     mul r5.w, r5.w, cb1[24].x
  50:     add r6.x, r0.w, r0.z
  51:     add r6.x, r3.w, r6.x
  52:     add r6.x, r4.w, r6.x
  53:     mad r6.x, r6.x, l(0.250000), -r2.w
  54:     max r6.y, r0.w, r2.w
  55:     max r6.y, r0.z, r6.y
  56:     max r6.z, r3.w, r4.w
  57:     max r6.y, r6.z, r6.y
  58:     min r0.w, r0.w, r2.w
  59:     min r0.z, r0.w, r0.z
  60:     min r0.w, r3.w, r4.w
  61:     min r0.z, r0.w, r0.z
  62:     add r0.z, -r0.z, r6.y
  63:     div r0.z, l(1.000000, 1.000000, 1.000000, 1.000000), r0.z
  64:     mul_sat r0.z, r0.z, abs(r6.x)
  65:     mad r0.z, r0.z, l(-0.500000), l(1.000000)
  66:     mul r0.z, r0.z, r5.w
  67:     mad r0.w, r0.z, l(4.000000), l(1.000000)
  68:     div r0.w, l(1.000000, 1.000000, 1.000000, 1.000000), r0.w
  69:     add r4.xyz, r4.zxyz, r5.zxyz
  70:     add r2.xyz, r2.zxyz, r4.xyzx
  71:     add r2.xyz, r3.zxyz, r2.xyzx
  72:     mad r1.xyz, r0.zzzz, r2.xyzx, r1.zxyz
  73:     mul r1.xyz, r0.wwww, r1.xyzx
  74:     mul r2.xyz, r1.xyzx, cb0[27].xxxx
  75:     sample_l(texture2d)(float,float,float,float) r0.xyz, r0.xyxx, t1.xyzw, s0, l(0)
  76:     add r0.w, l(1.000000), -cb1[9].z
  77:     mul r3.xyz, r0.wwww, r0.zxyz
  78:     lt r3.xyz, l(0.300000, 0.300000, 0.300000, 0.000000), r3.xyzx
  79:     log r4.xyz, r0.zxyz
  80:     mul r4.xyz, r4.xyzx, l(0.330000, 0.330000, 0.330000, 0.000000)
  81:     exp r4.xyz, r4.xyzx
  82:     mad r4.xyz, r4.xyzx, l(1.493800, 1.493800, 1.493800, 0.000000), l(-0.700000, -0.700000, -0.700000, 0.000000)
  83:     max r0.w, r2.z, r2.y
  84:     max r0.w, r2.x, r0.w
  85:     add r5.xy, r0.wwww, -cb1[10].yxyy
  86:     max r2.w, r5.x, l(0)
  87:     min r2.w, r2.w, cb1[10].z
  88:     add r5.xz, v1.xxyx, -cb1[1].xxyx
  89:     add r3.w, l(1.000000), -cb1[2].x
  90:     mad r3.w, cb1[1].w, r3.w, cb1[2].x
  91:     mul r5.xz, r3.wwww, abs(r5.xxzx)
  92:     mul_sat r3.w, l(1.050000), cb1[2].x
  93:     mad r3.w, r3.w, l(1.500000), l(-1.000000)
  94:     mad r3.w, cb1[1].w, r3.w, l(1.000000)
  95:     mul r3.w, r3.w, r5.x
  96:     mad r4.w, cb1[2].x, l(2.000000), l(-1.000000)
  97:     mad r4.w, cb1[1].w, r4.w, l(1.000000)
  98:     add_sat r5.x, l(-2.800000), cb1[2].x
  99:     mul r5.x, r5.x, l(5.000000)
 100:     mad_sat r6.y, r5.z, r4.w, r5.x
 101:     add r4.w, l(-1.000000), cb0[27].z
 102:     mad r4.w, cb1[2].w, r4.w, l(1.000000)
 103:     mad r5.x, cb0[27].z, l(0.562500), -r4.w
 104:     mad r4.w, cb1[1].w, r5.x, r4.w
 105:     mul_sat r6.x, r3.w, r4.w
 106:     log r5.xz, r6.xxyx
 107:     mul r5.xz, r5.xxzx, cb1[2].zzzz
 108:     exp r5.xz, r5.xxzx
 109:     mul r2.w, r2.w, r2.w
 110:     mul r2.w, r2.w, cb1[10].w
 111:     max r2.w, r5.y, r2.w
 112:     max r0.w, r0.w, l(0.000100)
 113:     div r0.w, r2.w, r0.w
 114:     mul r6.xyz, r0.wwww, r2.xyzx
 115:     mad r6.xyz, -r6.xyzx, cb1[9].zzzz, r2.xyzx
 116:     movc r0.xyz, r3.xyzx, r4.xyzx, r0.zxyz
 117:     mad r0.xyz, r0.xyzx, cb1[11].zxyz, r6.xyzx
 118:     mad r0.xyz, -r1.xyzx, cb0[27].xxxx, r0.xyzx
 119:     mad r0.xyz, cb1[9].xxxx, r0.xyzx, r2.xyzx
 120:     dp2 r0.w, r5.xzxx, r5.xzxx
 121:     add r0.w, -r0.w, l(1.000000)
 122:     max r0.w, r0.w, l(0)
 123:     log r0.w, r0.w
 124:     mul r0.w, r0.w, cb1[2].y
 125:     exp r0.w, r0.w
 126:     add r1.xyz, l(1.000000, 1.000000, 1.000000, 0.000000), -cb1[4].zxyz
 127:     mad r1.xyz, r0.wwww, r1.xyzx, cb1[4].zxyz
 128:     mul r0.xyz, r0.xyzx, r1.xyzx
 129:     mul r0.xyz, r0.xyzx, cb1[7].wwww
 130:     mad r0.xyz, r0.xyzx, l(5.555556, 5.555556, 5.555556, 0.000000), l(0.047996, 0.047996, 0.047996, 0.000000)
 131:     max r0.xyz, r0.xyzx, l(0, 0, 0, 0)
 132:     log r0.xyz, r0.xyzx
 133:     mad_sat r0.xyz, r0.xyzx, l(0.073500, 0.073500, 0.073500, 0.000000), l(0.386036, 0.386036, 0.386036, 0.000000)
 134:     mul r0.yzw, r0.xxyz, cb1[7].zzzz
 135:     round_ni r0.y, r0.y
 136:     mul r1.xy, l(0.500000, 0.500000, 0.000000, 0.000000), cb1[7].xyxx
 137:     mad r1.yz, r0.zzwz, cb1[7].xxyx, r1.xxyx
 138:     mad r1.x, r0.y, cb1[7].y, r1.y
 139:     sample_l(texture2d)(float,float,float,float) r2.xyz, r1.xzxx, t2.xyzw, s0, l(0)
 140:     mov r3.x, cb1[7].y
 141:     mov r3.y, l(0)
 142:     add r0.zw, r1.xxxz, r3.xxxy
 143:     sample_l(texture2d)(float,float,float,float) r1.xyz, r0.zwzz, t2.xyzw, s0, l(0)
 144:     mad r0.x, r0.x, cb1[7].z, -r0.y
 145:     add r0.yzw, -r2.xxyz, r1.xxyz
 146:     mad r0.xyz, r0.xxxx, r0.yzwy, r2.xyzx
 147:     mul r1.xyz, r0.xyzx, l(12.920000, 12.920000, 12.920000, 0.000000)
 148:     log r2.xyz, abs(r0.xyzx)
 149:     mul r2.xyz, r2.xyzx, l(0.416667, 0.416667, 0.416667, 0.000000)
 150:     exp r2.xyz, r2.xyzx
 151:     mad r2.xyz, r2.xyzx, l(1.055000, 1.055000, 1.055000, 0.000000), l(-0.055000, -0.055000, -0.055000, 0.000000)
 152:     ge r0.xyz, l(0.003131, 0.003131, 0.003131, 0.000000), r0.xyzx
 153:     movc r0.xyz, r0.xyzx, r1.xyzx, r2.xyzx
 154:     mul r1.xy, v1.xyxx, cb0[0].xyxx
 155:     dp2 r0.w, l(171.000000, 231.000000, 0.000000, 0.000000), r1.xyxx
 156:     mul r1.xyz, r0.wwww, l(0.009709, 0.014085, 0.010309, 0.000000)
 157:     frc r1.xyz, r1.xyzx
 158:     add r1.xyz, r1.xyzx, l(-0.500000, -0.500000, -0.500000, 0.000000)
 159:     mad o0.xyz, r1.xyzx, l(0.001373, 0.001373, 0.001373, 0.000000), r0.xyzx
 160:     min o0.w, r1.w, l(1.000000)
 161:   else
 162:     mov o0.xyzw, l(0.000000, 0.000000, 0.000000, 1.000000)
 163:   endif
 164: else
 165:   mov o0.xyzw, l(0.000000, 0.000000, 0.000000, 1.000000)
 166: endif
 167: ret
