from pathlib import Path
from hashlib import file_digest
import json,os,subprocess

run=Path(__file__).resolve().parent
lock=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state']=='held' and Path(lock['output'])==run
out=run/'engine-cloth-color'
out.mkdir()
old=run/'iris-overlay-player-rdc/overlay_frame1.rdc'
with old.open('rb') as stream:
    assert file_digest(stream,'sha256').hexdigest()=='6960267c0d71e4d05b6bfe0e2730c332ed71955f1fde6d69eb7d8aadf13eff24'
build=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
request=dict(capture=str(old),points=str(run/'skin-residual-points.bin'),source=str(run.parents[2]/'shaders/mesh.frag'),
             rules=str(build/'shader-reload.json'),catalog=str(run/'release-base-catalog.json'))
(out/'request.json').write_text(json.dumps(request,indent=2)+'\n')
env=os.environ.copy()
env['AZURE_ENGINE_IRIS_MIP_REPLAY']=str(out)
env['VK_DRIVER_FILES']=str(run/'nv-vk64-active-absolute.json')
startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
with (out/'replay.log').open('wb') as log:
    proc=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(run/'engine-cloth-color-worker.py')],
                        cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=440)
receipt=json.loads((out/'results.json').read_bytes())
assert proc.returncode==0 and receipt['status']=='qualified',receipt


