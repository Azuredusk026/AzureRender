from hashlib import sha256
from pathlib import Path
import json, os, struct, subprocess, traceback
import renderdoc as rd

out=Path(os.environ['AZURE_ENGINE_IRIS_MIP_REPLAY'])
request=json.loads((out/'request.json').read_bytes())
points=list(struct.iter_unpack('<II',Path(request['points']).read_bytes()))
shaders={key:value for key,value in json.loads(Path(request['catalog']).read_bytes()).items()}
record=dict(status='failed',events=[])
cap=rd.OpenCaptureFile()
controller=None
replacements=[]

def walk(actions):
    for a in actions:
        yield a
        yield from walk(a.children)

try:
    assert cap.OpenFile(request['capture'],'',None)==rd.ResultCode.Succeeded
    options=rd.ReplayOptions()
    options.forceGPUVendor=rd.GPUVendor.nVidia
    options.forceGPUDeviceID=0x28e0
    result,controller=cap.OpenCapture(options,None)
    assert result==rd.ResultCode.Succeeded and controller
    props=controller.GetAPIProperties()
    assert props.pipelineType==rd.GraphicsAPI.Vulkan and props.vendor==rd.GPUVendor.nVidia and not props.degraded
    desc={str(d.resourceId):d for d in controller.GetTextures()}
    for action in walk(controller.GetRootActions()):
        if not action.flags&rd.ActionFlags.Drawcall or action.numIndices!=10698:
            continue
        controller.SetFrameEvent(action.eventId,True)
        pipe=controller.GetPipelineState()
        ref=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
        if not ref:
            continue
        push=bytes(controller.GetVulkanPipelineState().pushconsts)
        raw=bytes(ref.rawBytes)
        digest=sha256(raw).hexdigest()
        targets=[slot.resource for slot in pipe.GetOutputTargets() if str(slot.resource) in desc]
        row=dict(event=action.eventId,shaderSha256=digest,names=[name for name,h in shaders.items() if h==digest],
            classAndFlags=push[112:128].hex(),targets=[dict(id=str(t),format=desc[str(t)].format.Name(),width=desc[str(t)].width,height=desc[str(t)].height) for t in targets])
        record['events'].append(row)
        name=next((n for n in row['names'] if n.startswith('mesh') and 'snapshot' not in n),None)
        if name is None or not targets:
            continue
        color=targets[0]; d=desc[str(color)]
        if (d.width,d.height)!=(2560,1440):
            continue
        rules=json.loads(Path(request['rules']).read_bytes())['programs']
        rule,=[p for p in rules if p['output']==name]
        original=pipe.GetShader(rd.ShaderStage.Fragment)
        row['shaderResource']=str(original)
        row['selection']={}
        def extract(label,event_id=action.eventId):
            controller.SetFrameEvent(event_id,True)
            payload=bytes(controller.GetTextureData(color,rd.Subresource()))
            assert len(payload)%(d.width*d.height)==0
            stride=len(payload)//(d.width*d.height)
            assert stride in (4,8,16)
            selected_digests={}
            for convention,coords in (('direct',points),('flipped',[(x,d.height-1-y) for x,y in points])):
                selected=b''.join(payload[(y*d.width+x)*stride:(y*d.width+x+1)*stride] for x,y in coords)
                (out/f"{action.eventId}-{label}-{convention}.bin").write_bytes(selected)
                selected_digests[convention]=sha256(selected).hexdigest()
            row['selection'][label]=dict(stride=stride,fullSha256=sha256(payload).hexdigest(),selectedSha256=selected_digests)
            return payload
        before_event=action.eventId-1
        baseline=extract('baseline')
        previous=extract('before',before_event)
        assert len(baseline)==len(previous)
        row['history']=[]
        controller.SetFrameEvent(action.eventId,True)
        for x,y in points:
            hits=controller.PixelHistory(color,x,y,rd.Subresource(),rd.CompType.Typeless)
            for v in hits:
                if v.eventId!=action.eventId or v.depthTestFailed or v.stencilTestFailed or v.backfaceCulled or v.shaderDiscarded:
                    continue
                row['history'].append(dict(x=x,y=y,primitive=int(v.primitiveID),shaderOut=list(v.shaderOut.col.floatValue),
                    before=list(v.preMod.col.floatValue),after=list(v.postMod.col.floatValue)))
        assert row['history']
    assert any(row.get('selection',{}).get('before') for row in record['events'])
    record['status']='qualified'
except Exception:
    record['error']=traceback.format_exc()
finally:
    if controller:
        for original,replacement in replacements:
            controller.RemoveReplacement(original)
            controller.FreeTargetResource(replacement)
        controller.Shutdown()
    cap.Shutdown()
    (out/'results.json').write_text(json.dumps(record,indent=2)+'\n')
os._exit(0 if record['status']=='qualified' else 1)




