from pathlib import Path
import gzip
import json
import runpy
import sys

import numpy as np
from PIL import Image

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
sys.path.insert(0,str(out.parents[2]/'tools'))
from endfield_native.postvs import read_postvs

score = runpy.run_path(str(grid/'static-quality.py'))
stage = score['stages']/'post-opaque-ownership'
main = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261023-033116-postvs-linear-verification-591bef')
face = np.asarray(Image.open(grid/'native-face-masks/face.png'))>0
iris = np.asarray(Image.open(grid/'native-face-masks/iris.png'))>0
assert face.sum()==3663 and iris.sum()==255

def load(event):
    return read_postvs(main/f'postvs-{event}/manifest.json')

def source_colour(word):
    cols=[]
    for shift,bits in ((0,6),(11,6),(22,5)):
        raw=(word>>shift)&((1<<(bits+5))-1)
        exp=(raw>>bits).astype(np.int32)
        mantissa=raw&((1<<bits)-1)
        cols.append(np.where(exp==0,np.ldexp(mantissa.astype(float),-14-bits),
                             np.ldexp(1+mantissa/(1<<bits),exp-15)))
    return np.column_stack(cols)

def raster(clip,triangles):
    screen = (clip[:,:2]/clip[:,3,None]+1)*[1280,720]
    bounds = np.maximum(0,np.floor(screen.min(0)).astype(int)-1),np.minimum([2560,1440],np.ceil(screen.max(0)).astype(int)+1)
    x,y=np.meshgrid(np.arange(bounds[0][0],bounds[1][0]),np.arange(bounds[0][1],bounds[1][1]))
    pixel=np.column_stack((x.ravel(),y.ravel()))+.5
    coverage=np.zeros((2,len(pixel)),dtype=np.uint8)
    for tri in triangles:
        a,b,c=np.rint(screen[tri]*256)/256
        basis=np.stack((b-a,c-a),axis=1)
        determinant=np.linalg.det(basis)
        if determinant==0:
            continue
        bary=(pixel-a)@np.linalg.inv(basis).T
        inside=(bary>=0).all(axis=1)&(bary.sum(axis=1)<=1)
        coverage[int(determinant<0)]+=inside
    result=np.zeros((2,1440,2560),dtype=np.uint8)
    result[:,y.ravel(),x.ravel()]=coverage
    return result

results={}
for event in (1230,1245,1358):
    draw=load(event)
    mesh=draw['attributes']
    clip=mesh['SV_Position'].astype(float)
    tris=draw['indices'].reshape(-1,3)
    coverage=raster(clip,tris)
    before,after=[np.frombuffer(gzip.decompress((stage/f'{event}-{step}.bin.gz').read_bytes()),'<u4')
                 .reshape(1440,2560)[::-1] for step in (event-1,event)]
    changed=before!=after
    before_rgb,after_rgb=(source_colour(buffer[changed]) for buffer in (before,after))
    ratio=np.divide(after_rgb,before_rgb,out=np.ones_like(after_rgb),where=before_rgb>0)
    row=results[str(event)]=dict(vertices=len(clip),triangles=len(tris),changed=int(changed.sum()),
        filmBoundsNdc=[(clip[:,:2]/clip[:,3,None]).min(0).tolist(),(clip[:,:2]/clip[:,3,None]).max(0).tolist()],
        windingCoverage=(coverage>0).sum((1,2)).tolist(),
        changedInsideWinding=[int((changed&(layer>0)).sum()) for layer in coverage],
        changedOutsideGeometry=int((changed&~(coverage>0).any(0)).sum()),
        changedFace=int((changed&face).sum()),changedIris=int((changed&iris).sum()),
        ratioMinMedianMax=[ratio.min(0).tolist(),np.median(ratio,axis=0).tolist(),ratio.max(0).tolist()],
        brighterPixels=int((after_rgb>before_rgb).any(1).sum()))
    assert changed.any() and row['changedOutsideGeometry']<=2
    assert row['brighterPixels']==0
assert results['1245']['changedIris']==94 and results['1230']['changedIris']==0
(out/'overlay-footprint.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
