from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import traceback

import renderdoc as rd

out = Path(os.environ['AZURE_NR_LATE_OVERLAY'])
job = json.loads((out/'late-overlay-request.json').read_bytes())
result = dict(status='failed',native={},player={})
events = (1230,1245,1339,1358)
points = ((1315,258),(1277,277),(1271,296),(1291,265),(1250,273))


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


def history(controller,target,x,y):
    records = controller.PixelHistory(target,x,y,rd.Subresource(),rd.CompType.Typeless)
    return [dict(event=r.eventId,primitive=r.primitiveID,passed=r.Passed(),
        depthFailed=r.depthTestFailed,stencilFailed=r.stencilTestFailed,cull=r.backfaceCulled,
        shaderDiscarded=r.shaderDiscarded,before=list(r.preMod.col.floatValue)[:4],
        after=list(r.postMod.col.floatValue)[:4],shader=list(r.shaderOut.col.floatValue)[:4])
        for r in records]


def inspect_capture(path,native):
    capture = rd.OpenCaptureFile()
    controller = None
    try:
        assert capture.OpenFile(path,'',None)==rd.ResultCode.Succeeded
        options = rd.ReplayOptions()
        options.forceGPUVendor = rd.GPUVendor.nVidia
        options.forceGPUDeviceID = 0x28e0
        status,controller = capture.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and controller
        assert controller.GetAPIProperties().vendor==rd.GPUVendor.nVidia
        native_textures = {tex.resourceId:tex for tex in controller.GetTextures()} if native else {}
        acts = list(walk(controller.GetRootActions()))
        report = result['native' if native else 'player']
        stage = rd.ShaderStage.Fragment
        for action in acts:
            eid = action.eventId
            if native and eid not in events:
                continue
            if not native and (action.numIndices not in (96,444,8718) or not action.flags&rd.ActionFlags.Indexed):
                continue
            controller.SetFrameEvent(eid,True)
            pipe = controller.GetPipelineState()
            target = pipe.GetOutputTargets()
            fragment = pipe.GetShaderReflection(stage)
            if not target or not fragment:
                continue
            name = f'{"native" if native else "player"}-{eid}'
            code = bytes(fragment.rawBytes)
            row = report[str(eid)] = dict(indices=action.numIndices,shader=sha256(code).hexdigest(),
                depth=str(pipe.GetDepthTarget().resource),color=str(target[0].resource))
            if not native:
                state = controller.GetVulkanPipelineState()
                payload = bytes(state.pushconsts)
                if len(payload)>=128:
                    row.update(material=int.from_bytes(payload[124:128],'little')>>1,
                               features=hex(int.from_bytes(payload[120:124],'little')))
                continue
            state = controller.GetD3D11PipelineState()
            depth = state.outputMerger.depthStencilState
            stencil = depth.frontFace
            row.update(cull=str(state.rasterizer.state.cullMode),frontCCW=state.rasterizer.state.frontCCW,
                compare=str(depth.depthFunction),
                stencil=dict(enabled=bool(depth.stencilEnable),compare=str(stencil.function),
                reference=stencil.reference,readMask=stencil.compareMask))
            row['textures'] = {}
            for r in pipe.GetReadOnlyResources(stage):
                index = fragment.readOnlyResources[r.access.index].fixedBindNumber
                bound = r.descriptor
                tex = row['textures'][index] = dict(resource=str(bound.resource),format=bound.format.Name(),
                    firstMip=bound.firstMip,mipCount=bound.numMips)
                if index in (3,4):
                    meta = native_textures[bound.resource]
                    tex.update(width=meta.width,height=meta.height,mips=[])
                    for mip in range(bound.firstMip,bound.firstMip+bound.numMips):
                        raw = bytes(controller.GetTextureData(bound.resource,rd.Subresource(mip,0,0)))
                        path = out/f'{name}-t{index}-mip{mip}.bin'
                        path.write_bytes(raw)
                        tex['mips'].append(dict(level=mip,sha256=sha256(raw).hexdigest(),bytes=len(raw)))
            blend = state.outputMerger.blendState.blends[0]
            row['blend'] = dict(enabled=blend.enabled,color=dict(src=str(blend.colorBlend.source),
                dst=str(blend.colorBlend.destination),op=str(blend.colorBlend.operation)))
            assembly = controller.DisassembleShader(pipe.GetGraphicsPipelineObject(),fragment,'')
            (out/f'{name}.asm').write_text(assembly,encoding='utf8')
            for index,block in enumerate(fragment.constantBlocks):
                if block.fixedBindNumber<3:
                    continue
                binding = pipe.GetConstantBlock(stage,index,0).descriptor
                if binding.resource==rd.ResourceId.Null():
                    continue
                raw = bytes(controller.GetBufferData(binding.resource,binding.byteOffset,binding.byteSize))
                (out/f'{name}-cb{block.fixedBindNumber}.bin').write_bytes(raw)
            geometry = controller.GetPostVSData(0,0,rd.MeshDataStage.VSOut)
            vertices = bytes(controller.GetBufferData(geometry.vertexResourceId,geometry.vertexByteOffset,0))
            indices = bytes(controller.GetBufferData(geometry.indexResourceId,geometry.indexByteOffset,
                geometry.numIndices*geometry.indexByteStride))
            for key,data in [('vertices',vertices),('indices',indices)]:
                (out/f'{name}-{key}.bin').write_bytes(data)
            vs = pipe.GetShaderReflection(rd.ShaderStage.Vertex)
            row['geometry'] = dict(vertexStride=geometry.vertexByteStride,indexStride=geometry.indexByteStride,
                indices=geometry.numIndices,vertexHash=sha256(vertices).hexdigest(),indexHash=sha256(indices).hexdigest(),
                output=[dict(name=r.semanticIdxName,count=r.compCount) for r in vs.outputSignature])
            row['points'] = [[x,y,[p for p in history(controller,target[0].resource,x,1439-y) if p['event']==eid]]
                             for x,y in points]
    finally:
        if controller:
            controller.Shutdown()
        capture.Shutdown()


try:
    inspect_capture(job['native'],True)
    assert set(result['native'])=={str(e) for e in events}
    inspect_capture(job['engine'],False)
    assert result['player']
    result['status']='qualified'
except Exception:
    result['error']=traceback.format_exc()
finally:
    (out/'late-overlay-replay.json').write_text(json.dumps(result,indent=2)+'\n')
os._exit(0 if result['status']=='qualified' else 1)
