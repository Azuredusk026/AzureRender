from hashlib import sha256
from io import BytesIO
from pathlib import Path
import gzip
import json
import runpy
import struct
import sys

import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
sys.path.insert(0,str(out.parents[2]/'tools'))
from endfield_native.postvs import read_postvs
source=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261023-033116-postvs-linear-verification-591bef')
passes=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/post-opaque-ownership')
rd=json.loads((out/'late-overlay-replay.json').read_bytes())
assert rd['status']=='qualified'

def unpack(words):
    channels=[]
    for shift,bits in ((0,6),(11,6),(22,5)):
        raw=(words>>shift)&((1<<(bits+5))-1)
        exp=(raw>>bits).astype(int)
        frac=(raw&((1<<bits)-1))/(1<<bits)
        channels.append(np.where(exp==0,np.ldexp(frac,-14),np.ldexp(1+frac,exp-15)))
    return np.column_stack(channels)

def sample(tex,uv):
    size=tex.shape[0]
    p=uv*size-.5
    lo=np.floor(p).astype(int)
    f=p-lo
    # D3D bilinear bounds use eight fractional bits for these textures.
    f=np.rint(f*256)/256
    vals=np.zeros(len(uv))
    for dx in (0,1):
        for dy in (0,1):
            i,j=((lo+[dx,dy])%size).T
            vals+=tex[j,i]*(f[:,0] if dx else 1-f[:,0])*(f[:,1] if dy else 1-f[:,1])
    return vals

def decode_tex(event,mip):
    entry=rd['native'][str(event)]['textures']['3']['mips'][mip]
    raw=(out/f'native-{event}-t3-mip{mip}.bin').read_bytes()
    assert sha256(raw).hexdigest()==entry['sha256']
    size=32>>mip
    header=bytearray(148)
    header[:4]=b'DDS '
    struct.pack_into('<7I',header,4,124,0x81007,size,size,len(raw),0,1)
    struct.pack_into('<II4s',header,76,32,4,b'DX10')
    struct.pack_into('<I',header,108,0x1000)
    struct.pack_into('<5I',header,128,98,3,0,1,0)
    with Image.open(BytesIO(header+raw)) as image:
        return np.asarray(image.convert('RGBA'))[...,0]/255

def interpolate(event,x,y):
    data=read_postvs(source/f'postvs-{event}/manifest.json')
    attr=data['attributes']
    clip=attr['SV_Position'].astype(float)
    triangles=data['indices'].reshape(-1,3)
    screen=(clip[:,:2]/clip[:,3,None]+1)*[1280,720]
    uv=attr['TEXCOORD0'].astype(float)
    hits=np.zeros(len(x),int)
    closest=np.full(len(x),np.inf)
    point=np.column_stack((x,y))+.5
    coords=np.zeros((len(x),2))
    for idx in triangles:
        a,b,c=np.rint(screen[idx]*256)/256
        basis=np.stack((b-a,c-a),axis=1)
        if abs(np.linalg.det(basis))<1e-14:
            continue
        bc=(point-a)@np.linalg.inv(basis).T
        bary=np.column_stack((1-bc.sum(1),bc))
        inside=(bary>=0).all(1)
        hits+=inside
        indices=np.flatnonzero(inside)
        weights=bary[indices]/clip[idx,3]
        z=1/weights.sum(1)
        choose=z<closest[indices]
        closest[indices[choose]]=z[choose]
        coords[indices[choose]]=(weights@uv[idx]*z[:,None])[choose]
    assert (hits>0).all()
    return coords,hits

data={}
for event in (1230,1245,1358):
    before,after=[np.frombuffer(gzip.decompress((passes/f'{event}-{x}.bin.gz').read_bytes()),'<u4')
                  .reshape(1440,2560)[::-1] for x in (event-1,event)]
    y,x=np.where(before!=after)
    original,shaded=unpack(before[y,x]),unpack(after[y,x])
    measured=np.divide(shaded,original,out=np.ones_like(shaded),where=original>0)
    constants=np.fromfile(out/f'native-{event}-cb4.bin','<f4').reshape(-1,4)
    candidates=[]
    a=(1-measured)/(1-constants[2,:3])
    uv,hits=interpolate(event,x,y)
    for mip in range(6):
        tex=decode_tex(event,mip)
        sampled=sample(tex,uv)
        safe=sampled>1e-3
        coefficient=(a[safe]*sampled[safe,None]).sum(0)/np.square(sampled[safe]).sum()
        residual=a-sampled[:,None]*coefficient
        candidates.append(dict(mip=mip,alphaScale=coefficient.tolist(),
          rootMeanSquare=float(np.sqrt(np.square(residual).mean())),ratioRange=[sampled.min(),sampled.max()]))
    ordering=sorted(candidates,key=lambda entry:entry['rootMeanSquare'])
    data[event]=dict(pixels=len(x),overlappingTriangles=int((hits>1).sum()),tint=constants[2,:3].tolist(),fits=ordering)
    print(event,ordering[:2])
(out/'late-overlay-fit.json').write_text(json.dumps(data,indent=2)+'\n')
