from hashlib import file_digest, sha256
from pathlib import Path
import json
import os
import subprocess

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
lock = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state']=='held' and Path(lock['output'])==out
request = json.loads((grid/'native-face-masks/request.json').read_bytes())
request['engine'] = str(grid/'iris-overlay-player-rdc/overlay_frame1.rdc')
request['referenceResult'] = str(out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/face-late-overlay-ownership/results.json')
with Path(request['native']).open('rb') as stream:
    assert file_digest(stream,'sha256').hexdigest()==request['captureSha256']
(out/'late-overlay-request.json').write_text(json.dumps(request,indent=2)+'\n')
env = os.environ.copy()
env['AZURE_NR_LATE_OVERLAY'] = str(out)
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
with (out/'late-overlay-replay.log').open('wb') as log:
    child = subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',
                           str(out/'late-overlay-worker.py')],cwd=out,env=env,stdout=log,
                           stderr=subprocess.STDOUT,startupinfo=startup,timeout=160)
report = json.loads((out/'late-overlay-replay.json').read_bytes())
assert child.returncode==0 and report['status']=='qualified',report
