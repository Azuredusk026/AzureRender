from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
stage=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/post-opaque-ownership')
report=json.loads((out/'late-overlay-replay.json').read_bytes())
text=report['native']['1358']['textures']['4']
source=out/'native-1358-t4-mip0.bin'
binary=source.read_bytes()
assert sha256(binary).hexdigest()==text['mips'][0]['sha256']
assert text['format']=='R10G10B10A2_UNORM'
alpha=np.frombuffer(binary,'<u4').reshape(1440,2560)[::-1]>>30
def mask(name):
    return np.asarray(Image.open(grid/f'native-face-masks/{name}.png'))>0
def affected(event):
    before,after=[np.frombuffer(gzip.decompress((stage/f'{event}-{row}.bin.gz').read_bytes()),'<u4')
                    .reshape(1440,2560)[::-1] for row in (event-1,event)]
    return before!=after
categories={name:np.bincount(alpha[selected],minlength=4).tolist() for name,selected in
            [('face',mask('face')),('iris',mask('iris'))]+[(str(e),affected(e)) for e in (1230,1245,1358)]}
assert categories=={'face':[0,3663,0,0],'iris':[0,0,255,0],
    '1230':[0,41,0,0],'1245':[0,0,95,0],'1358':[0,266,0,0]}
qualified=dict(source=text,categories=categories,
    stencil={e:r['stencil'] for e,r in report['native'].items()})
(out/'overlay-receiver-source.json').write_text(json.dumps(qualified,indent=2)+'\n')
if sys.argv[1:]==['--release-plane']:
    assert source.resolve(strict=True).parent==out
    source.unlink()
