from pathlib import Path
import csv
import hashlib
import json
import os
import subprocess
import sys
import time
import zipfile

import numpy as np

root = Path.cwd().resolve()
out = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "tools"))
from gpu_environment import RunEnvironmentMonitor, environment_errors, wait_and_record
from run_playable_performance import memory_snapshot

build = root / "build/ninja-msvc-release"
archive = root / "docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope/validation.zip"
release = json.loads((root / "docs/acceptance/nr/evidence/2026-11-13/frozen-public-visual/driver-59579-results.json").read_bytes())["main"]["release"]


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def input_digests(paths):
    return {str(path): digest(path) for path in paths}


with zipfile.ZipFile(archive) as evidence:
    locked = json.loads(evidence.read("run/frozen-project-inputs.json"))
    command = json.loads(evidence.read("run/diagnostic-1080p60/command.json"))["command"]
assert len(locked) == 1729 and input_digests(map(Path, locked)) == locked
assert digest(build / "AzurePlayer.exe") == release["playerSha256"]
products = input_digests([build / "AzurePlayer.exe", *sorted(build.glob("*.dll")), *sorted((build / "shaders").glob("*.spv"))])
timing = out / "timing.json"
command[0] = str(build / "AzurePlayer.exe")
command[command.index("--resource-root") + 1] = str(build)
command[command.index("--gpu-timing-output") + 1] = str(timing)
for option, required in (("--width", "1920"), ("--height", "1080"), ("--capture-fps", "60"), ("--smoke-frames", "2100")):
    assert command[command.index(option) + 1] == required
env = dict(os.environ, VK_LOADER_DRIVERS_SELECT="*nv-vk64*", DOTNET_ROOT="D:/Tools/dotnet9")
env["PATH"] = str(build) + os.pathsep + env["PATH"]
for key in ("VK_DRIVER_FILES", "VK_ICD_FILENAMES", "VK_INSTANCE_LAYERS", "VK_LAYER_VALIDATE_SYNC",
            "VK_LOADER_DEBUG", "VK_LAYER_ENABLES", "AZURE_CPU_WORK_REPORT", "AZURERENDER_RESOURCE_ROOT",
            "AZURE_DISABLE_COMPUTED_MATERIAL_VIEW"):
    env.pop(key, None)
source = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
save("command.json", {"command": command, "source": source, "frozenInputCount": len(locked),
                      "frozenInputArchiveSha256": digest(archive), "products": products})
path = out / "environment.json"
environment = wait_and_record(path, timeout=120)
observations = []
start = time.monotonic()
with RunEnvironmentMonitor(environment, path=path, interval=2), (out / "player.log").open("wb") as log:
    player = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    try:
        while player.poll() is None:
            try:
                observations.append(memory_snapshot(player.pid))
            except OSError:
                if player.poll() is not None:
                    break
                raise
            if time.monotonic() - start > 650:
                raise TimeoutError("Joint scene capture timed out")
            time.sleep(0.2)
    finally:
        if player.poll() is None:
            player.kill()
            player.wait()
        save("process-memory.json", observations)
assert player.returncode == 0
assert "Allocator after unload: buffers=0 images=0" in (out / "player.log").read_text(errors="replace")
data = json.loads(timing.read_bytes())
assert (data["sceneWidth"], data["sceneHeight"]) == (1920, 1080)
assert data["computedMaterialViewPipelines"] == data["computedMaterialViewSelectionsTotal"] == 0
with timing.with_suffix(".csv").open(encoding="utf-8") as stream:
    rows = [row for row in csv.DictReader(stream) if 300 < int(row["frame"]) <= 2100]
assert [int(row["frame"]) for row in rows] == list(range(301, 2101))
cpu = data["cpuFrame"]["workSamplesMs"]
assert len(cpu) == 2100
observed = environment["startup"] + environment["runObservations"] + [environment["final"]]
assert all(row["driver"] == "595.79" for row in observed)
watts = sorted({row["powerLimitWatts"] for row in observed if row["powerLimitWatts"] is not None})
thermal = environment_errors(environment)
fixed = watts == [80.0] and all(row["powerLimitWatts"] == 80.0 for row in observed)


def stats(values):
    return {"mean": float(np.mean(values)), "p95": float(np.percentile(values, 95)), "peak": float(np.max(values))}


def window(begin, end):
    result = {key: stats([float(row[key]) for row in rows[begin:end]])
              for key in ("frameMs", "sceneMs", "shadowMs", "postProcessMs")}
    result["cpuWorkMs"] = stats(cpu[300 + begin:300 + end])
    return result


total = window(0, 1800)
local = data["allocator"]["deviceLocalPeakBytes"]
working = max(row["peak"] for row in observations)
gates = {"fixed80W": fixed, "thermalAndAC": not thermal, "gpuP95": total["frameMs"]["p95"] <= 16.6,
         "cpuP95": total["cpuWorkMs"]["p95"] <= 8, "deviceLocal": local <= 1610612736, "workingSet": working <= 2147483648}
assert input_digests(map(Path, locked)) == locked and input_digests(map(Path, products)) == products
assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == source
report = {"scope": "standard-main-joint-1080p60", "source": source, "driver": "595.79", "warmup": 300,
          "frames": 1800, "gpuPowerLimitWatts": watts, "environmentFailures": thermal,
          "observationCount": len(observed), "timings": total, "deviceLocalPeakBytes": local,
          "workingSetPeakBytes": working, "allocatorZero": True, "gates": gates,
          "windows": [window(begin, begin + 300) for begin in range(0, 1800, 300)]}
save("results.json", report)
print(json.dumps({key: value for key, value in report.items() if key != "windows"}), flush=True)
