$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $PSCommandPath
$deadline = (Get-Date).AddMinutes(8)
do {
    if (Test-Path -LiteralPath "$dir/fan-ready.json") {
        & 'D:/Projects/FYP/Project/AzureRender/build/reinstall-environment/venv/Scripts/python.exe' "$dir/qualify.py"
        exit $LASTEXITCODE
    }
    Start-Sleep -Seconds 1
} while ((Get-Date) -lt $deadline)
throw 'Fan control was not ready'
