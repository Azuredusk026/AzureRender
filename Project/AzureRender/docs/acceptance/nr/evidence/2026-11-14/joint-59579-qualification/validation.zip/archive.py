from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile, ZIP_DEFLATED

import numpy as np


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def attach_round(report, files, name, folder):
    report[name] = read_json(folder / "results.json")
    environment = read_json(folder / "environment.json")
    timing = read_json(folder / "timing.json")
    observations = environment["startup"] + environment["runObservations"] + [environment["final"]]
    cpu = timing["cpuFrame"]["workSamplesMs"]
    assert len(cpu) == 2100 == report[name]["warmup"] + report[name]["frames"]
    assert len(observations) == report[name]["observationCount"]
    evidence = report[name]
    evidence["startTemperatureC"] = observations[0]["temperature"]
    evidence["peakTemperatureC"] = max(row["temperature"] for row in observations)
    evidence["softwareThermalSlowdownObservations"] = sum(row["thermalSlowdown"]["software"] for row in observations)
    evidence["hardwareThermalSlowdownObservations"] = sum(row["thermalSlowdown"]["hardware"] for row in observations)
    evidence["cpuWarmupP95Ms"] = float(np.percentile(cpu[:300], 95))
    evidence["physicsP95Ms"] = float(np.percentile(timing["cpuFrame"]["physicsSamplesMs"], 95))
    evidence["drawCallsPerFrame"] = timing["submission"]["drawCallsPerFrame"]
    evidence["materialResidentTexelBytes"] = timing["materialTextureCache"]["residentBytes"]
    evidence["liveImageAllocationBytes"] = timing["allocator"]["liveImageBytes"]
    evidence["liveBufferAllocationBytes"] = timing["allocator"]["liveBufferBytes"]
    for member in ("command.json", "environment.json", "results.json", "timing.csv", "timing.json",
                   "process-memory.json", "player.log"):
        files[f"{name}/{member}"] = folder / member


root = Path.cwd()
run = Path(__file__).resolve().parent
retry, fan = [Path(argument) for argument in sys.argv[1:]]
startup = read_json(run / "environment.json")
prior = root / "build/runs/20261113-011746-nr-main-joint-scene-diagnostic-c840ed/timing.json"
timing = read_json(prior)
samples = startup["observations"]
assert len(samples) >= 3 and startup["errorType"] == "TimeoutError"
assert all(row["driver"] == "595.79" for row in samples)
assert min(row["gpuUtilization"] for row in samples) > startup["policy"]["maxIdleUtilization"]
assert not (run / "timing.json").exists()
files = {"startup-rejected.json": run / "environment.json", "command.json": run / "command.json",
         "qualification.log": run / "process.log", "runner.py": run / "qualify.py",
         "archive.py": Path(__file__)}
limit = 1610612736
texture_bytes = timing["materialTextureCache"]["residentBytes"]
report = {"driver": "595.79", "firstAttempt": {
    "observations": len(samples), "elapsedSeconds": samples[-1]["seconds"] - samples[0]["seconds"],
    "gpuUtilization": [min(row["gpuUtilization"] for row in samples), max(row["gpuUtilization"] for row in samples)],
    "idleLimitPercent": startup["policy"]["maxIdleUtilization"],
    "observedPowerLimitsWatts": sorted({row["powerLimitWatts"] for row in samples}),
    "formalFrames": 0, "failure": startup["error"]},
    "priorCapacity": {"deviceLocalPeakBytes": timing["allocator"]["deviceLocalPeakBytes"],
                      "deviceLocalLimitBytes": limit, "materialResidentTexelBytes": texture_bytes,
                      "materialTexelsOverLimitBytes": texture_bytes - limit,
                      "liveImageAllocationBytes": timing["allocator"]["liveImageBytes"],
                      "sourceTimingSha256": digest(prior)}}
attach_round(report, files, "retry", retry)
attach_round(report, files, "maximumFan", fan)
assert report["retry"]["materialResidentTexelBytes"] == report["maximumFan"]["materialResidentTexelBytes"]
assert digest(retry / "qualify.py") == digest(fan / "qualify.py") == digest(run / "qualify.py")
for name in ("fan-ready.json", "fan-at-speed.json", "fan-restored.json", "first-timeout.log", "second-launch.log",
             "wait_ready.py", "wait-ready.ps1", "process.log"):
    files[f"maximumFan/{name}"] = fan / name
report["maximumFan"]["configuration"] = read_json(fan / "fan-ready.json")
report["maximumFan"]["observedAtSpeed"] = read_json(fan / "fan-at-speed.json")
report["maximumFan"]["restoration"] = read_json(fan / "fan-restored.json")
components = {"sRgbChannelUpperBoundBytes": 113700984, "ddsBlockUpperBoundBytes": 141848232}
report["capacityEnvelope"] = dict(
    components, peakOverLimitBytes=report["retry"]["deviceLocalPeakBytes"] - limit,
    remainingAfterCombinedOptimisticSavingsBytes=report["retry"]["deviceLocalPeakBytes"] - limit - sum(components.values()))
out = root / "docs/acceptance/nr/evidence/2026-11-14/joint-59579-qualification"
out.mkdir(parents=True, exist_ok=True)
archive = out / "validation.zip"
with ZipFile(archive, "w", ZIP_DEFLATED) as package:
    for name, path in files.items():
        package.write(path, name)
with ZipFile(archive) as package:
    assert package.testzip() is None
    assert all(package.read(name) == path.read_bytes() for name, path in files.items())
report["archiveSha256"] = digest(archive)
(out / "results.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

