from pathlib import Path
import runpy
import time

folder = Path(__file__).resolve().parent
deadline = time.monotonic() + 480
while not (folder / "fan-ready.json").is_file():
    if time.monotonic() >= deadline:
        raise SystemExit("Fan control was not ready")
    time.sleep(1)
runpy.run_path(str(folder / "qualify.py"), run_name="__main__")
