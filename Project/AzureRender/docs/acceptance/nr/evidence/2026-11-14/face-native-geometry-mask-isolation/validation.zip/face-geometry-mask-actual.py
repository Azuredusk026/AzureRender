from hashlib import file_digest
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5
import json
import os
import runpy
import struct
import subprocess
import sys

import numpy as np
from PIL import Image, ImageFilter

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
diagnostics=out.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
baseline=out.parent/'20261114-051632-face-local-radial-light-retest-ea8fb6'
originalEvidence=out.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
fixture=grid/'iris-overlay-geometry-project'
helper=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read,invoke,build=(helper[k] for k in ('read','invoke','build'))
score=runpy.run_path(str(grid/'static-quality.py'))
fingerprints=read(originalEvidence/'face-build-fingerprints.json')

def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()

def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')

def prepare(mode='all',pair=False):
    assert mode in ('all','sdf','diffuse','radial','rim','view','tint-base','tint-view','tint-all','tint-base-sdf','tint-base-radial')
    assert digest(build/'AzurePlayer.exe')==fingerprints['releasePlayer']
    observations=read(diagnostics/'face-edge-mask-levels.json')['rows']
    assert len(observations)==12 and all(round(r['estimatedLod']-1)==r['bestNativeLevel'] for r in observations)
    tag=('' if mode=='all' else '-'+mode)+('-pair' if pair else '')
    name='face-native-geometry-mask-sampling'+tag
    staged=out/('assets'+tag)
    staged.mkdir(exist_ok=True)
    material_id,texture_id=(str(uuid5(NAMESPACE_URL,'azurerender/'+name+s)) for s in ('','/t20'))
    src='face-native-radial-local-production'
    material=read(fixture/'materials'/f'{src}.azurematerial')
    surface=material['surface']
    slot=surface['textures'][surface['materials'][0]['extras']['azureRenderMaterial']['faceSdf']['maskTexture']]['source']
    old=material['textures'][str(slot)]
    assert old['asset']=='f904c6bc-9ff0-5a74-b848-3641dbd12e77' and old['usage']=='linear'
    dds=staged/f'{name}.dds'
    auth=fixture/'materials/native-face-t20-fixed-lookup.dds'
    if not dds.exists():dds.hardlink_to(auth)
    assert os.path.samefile(dds,auth)
    with dds.open('rb') as stream:
        assert struct.unpack_from('<7I',stream.read(32),4)[2:]==(256,256,1024,0,9)
    with Image.open(dds) as native, Image.open(fixture/'materials'/f'{old["asset"]}.png') as existing:
        assert native.convert('RGBA').tobytes()==existing.convert('RGBA').tobytes()
    # Slot 4 keeps its fixed sampler. The isolated test carries the authored
    # geometry mask in the unused metallic-roughness binding of this face.
    pbr=surface['materials'][0]['pbrMetallicRoughness']
    assert 'metallicRoughnessTexture' not in pbr and pbr['metallicFactor']==0 and pbr['roughnessFactor']==1
    texture_index,image_index=len(surface['textures']),len(material['textures'])
    assert str(image_index) not in material['textures']
    surface['textures'].append({'source':image_index})
    material['textures'][str(image_index)]={'asset':texture_id,'usage':'linear'}
    pbr['metallicRoughnessTexture']={'index':texture_index}
    meta=read(auth.with_suffix('.dds.azmeta'))
    meta['id']=texture_id
    sampler=meta['settings']['texture']
    sampler.update(mipPolicy='generate',mipFilter='nearest',mipBias=-1,anisotropy=1)
    baseDir=originalEvidence/'face-candidate' if pair else fixture/'scene'
    baseName='face-late-overlay-pair' if pair else src
    level=read(baseDir/f'{baseName}.azurelevel')
    hero=next(n for n in level['nodes'] if n['id']=='hero')
    hero['materialSlots']['name:M_actor_laevat_face_01']=material_id
    project=read((baseDir if pair else fixture)/f'{baseName}.azureproject')
    project['startupScene']=f'stage:/{name}.azurelevel'
    links={f'materials/{dds.name}':dds}
    if pair:
        for p in sorted(baseDir.glob('late-face-overlay-*')):
            if p.name.endswith('.bin.azmeta'):
                existing=fixture/'character'/p.name
                if existing.is_file():
                    for sidecar in (existing,p):
                        metadata=read(sidecar)
                        assert metadata['schemaVersion']==1 and not metadata.get('dependencies') and not metadata.get('settings')
                    continue
            relative='materials' if '.azurematerial' in p.name or '.dds' in p.name else 'character'
            links[f'{relative}/{p.name}']=p
        assert len(links) in (15,16,17)
    for relative,value in {
          f'materials/{name}.dds.azmeta':meta,
          f'materials/{name}.azurematerial':material,
          f'materials/{name}.azurematerial.azmeta':dict(schemaVersion=1,id=material_id,dependencies=[],settings={}),
          f'scene/{name}.azurelevel':level,
          f'{name}.azureproject':project,
    }.items():
        p=staged/Path(relative).name
        write(p,value)
        links[relative]=p
    source=out.parents[2]/'shaders/mesh.frag'
    candidate=subprocess.check_output(['git','show','830a287:Project/AzureRender/shaders/mesh.frag'],
        cwd=out.parents[2],text=True,encoding='utf8')
    def sample(fallback):return f'(faceExperimentMaskPresent()?azureSamplePrimaryUv(AZ_TEX_METALLIC_ROUGHNESS,textureCoordinate):{fallback})'
    fixed='textureLod(AZ_TEX_STYLE_MASK,textureCoordinate,0)'
    f32='textureLod(AZ_TEX_STYLE_MASK,textureCoordinate,0.0)'
    oldImplicit='azureSamplePrimaryUv(AZ_TEX_STYLE_MASK,textureCoordinate)'
    substitutions=[
        ('sdf',f32+'.g',sample(f32)+'.g',2),
        ('radial',fixed+'.g);',sample(fixed)+'.g);',1),
        ('rim',f32+'.a);',sample(f32)+'.a);',1),
        ('diffuse',fixed+'.gb:vec2(0)',sample(fixed)+'.gb:vec2(0)',1),
        ('view',oldImplicit+'.rg;',sample(oldImplicit)+'.rg;',1),
        ('diffuse',oldImplicit+'.r)',sample(oldImplicit)+'.r)',1),
        ('control','vec4 packedMaterial = azureSamplePrimaryUv(AZ_TEX_METALLIC_ROUGHNESS,textureCoordinate);',
         'vec4 packedMaterial = faceExperimentMaskPresent()?vec4(1,1,0,1):azureSamplePrimaryUv(AZ_TEX_METALLIC_ROUGHNESS,textureCoordinate);',1),
    ]
    maskMode={'tint-base':'control','tint-view':'view','tint-all':'all',
        'tint-base-sdf':'sdf','tint-base-radial':'radial'}.get(mode,mode)
    for group,s,t,count in substitutions:
        if maskMode!='all' and group not in (maskMode,'control'):continue
        assert candidate.count(s)==count,s
        candidate=candidate.replace(s,t)
    if mode.startswith('tint-'):
        evidence=read(out/'face-view-mask-math.json')
        assert len(evidence['rows'])==12 and evidence['blueScaleRange']==[1.0,0.699999988079071]
        assert all(r['geometryWeight']==1.0 for r in evidence['rows'])
        line='float maskInfluence=mix(maskPolicy.y,1.0,mask.g)*mask.r;'
        if mode.startswith('tint-base'):
            viewMask=oldImplicit
        else:
            viewMask=sample(oldImplicit)
        assert candidate.count(line)==1 and candidate.count(viewMask+'.rg;')>=1
        candidate=candidate.replace('vec2 mask='+viewMask+'.rg;','vec3 mask='+viewMask+'.rgb;')
        candidate=candidate.replace(line,
            'vec2 localCamera=(transpose(mat3(instanceFaceFrame))*(-camera.cameraForward.xyz)).xz;\n'
            '        float localFacing=clamp(.5+localCamera.y/max(length(localCamera),1e-8),0,1);\n'
            '        float maskInfluence=mix(localFacing,1.0,mask.g)*mask.r*mix(1.0,.7,mask.b);')
    anchor='vec3 materialNprLitAlbedo('
    assert candidate.count(anchor)==1
    candidate=candidate.replace(anchor,'bool faceExperimentMaskPresent(){return AZURE_MATERIAL_CLASS==2U && textureQueryLevels(AZ_TEX_METALLIC_ROUGHNESS)==9;}\n'+anchor)
    frag=staged/'mesh-face-geometry-mask.frag'
    frag.write_text(candidate,encoding='utf8')
    resources=out/('resources'+tag)
    shaders=resources/'shaders'
    shaders.mkdir(parents=True,exist_ok=True)
    sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
    modified=['mesh_object_lighting.frag.spv','mesh_object_early_lighting.frag.spv']
    rules={r['output']:r for r in read(build/'shader-reload.json')['programs']}
    stamp=resources/'runtime-build-Release.json'
    if not stamp.exists():stamp.hardlink_to(build/stamp.name)
    assert os.path.samefile(stamp,build/stamp.name)
    hashes={}
    for name2 in modified:
        rule=rules[name2]
        p=shaders/name2
        assert not p.exists() or not os.path.samefile(p,build/'shaders'/name2)
        command=[str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+v for v in rule['defines']),'-I'+str(source.parent),str(frag),'-o',str(p)]
        subprocess.run(command,check=True)
        subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(p)],check=True)
        hashes[name2]=digest(p)
        assert hashes[name2]!=fingerprints['shaderCatalog'][name2]
    receipt=dict(player=fingerprints['releasePlayer'],programs=hashes,sampler=sampler,texture=digest(dds),experimentalBinding=2,fixedMaskBinding=4,mode=mode,overlayPair=pair)
    write(staged/'prepared.json',receipt)
    return links,resources,fixture/f'{name}.azureproject',receipt

def measure(device,frame,receipt):
    control=(originalEvidence/f'face-{device}-pair' if receipt['overlayPair'] else baseline/f'production-{device}-enabled')/'frames/frame_000000.png'
    ref,old,new=[score['image'](p).astype(np.int16) for p in (score['reference_path'],control,frame)]
    masks={}
    for name in ('face','iris'):
        with Image.open(grid/f'native-face-masks/{name}.png') as im:
            gray=im.convert('L')
            masks[name]=np.asarray(gray)>0
            if name=='face':masks['faceCore']=np.asarray(gray.filter(ImageFilter.MinFilter(13)))>0
    assert masks['faceCore'].sum()==1176
    masks['outsideFace']=~masks['face']
    masks['frame']=np.ones(masks['face'].shape,dtype=bool)
    err=[np.abs(im-ref).max(2) for im in (old,new)]
    delta=np.abs(old-new).max(2)
    dimensions={}
    for name,m in masks.items():
        a,b=[e[m] for e in err]
        dimensions[name]=dict(count=int(m.sum()),overOne=[int((e>1).sum()) for e in (a,b)],
          overEight=[int((e>8).sum()) for e in (a,b)],peak=[int(e.max()) for e in (a,b)],
          newOverOne=int(((a<=1)&(b>1)).sum()),changed=int((delta[m]>0).sum()))
    for label,im in [('baseline',old),('candidate',new)]:
        for name,value in score['compare'](ref.astype('u1'),im.astype('u1'),{k:masks[k] for k in ('face','faceCore','iris')}).items():
            dimensions[name][label]=value
    paired={}
    outside=read(diagnostics/'face-native-factor-control.json')['devices'][device]['outsideLocations']
    for key,points in (
          ('traced',[r['point'] for r in read(diagnostics/'face-edge-mask-levels.json')['rows']]),
          ('outsideOverEight',[r['point'] for r in outside]),
    ):
        x,y=np.asarray(points).T
        a,b=[e[y,x] for e in err]
        paired[key]=dict(points=points,improved=int((b<a).sum()),worsened=int((b>a).sum()),
                        overOne=[int((e>1).sum()) for e in (a,b)],overEight=[int((e>8).sum()) for e in (a,b)],
                        peak=[int(e.max()) for e in (a,b)],errors=[a.tolist(),b.tolist()])
    result=dict(device=device,input=receipt,frameSha256=digest(frame),baselineSha256=digest(control),regions=dimensions,samples=paired)
    write(frame.parents[1]/'results.json',result)
    print(json.dumps(dict(regions=dimensions,samples=paired['traced'])))

if __name__=='__main__':
    device,*extra=sys.argv[1:]
    assert len(extra)<=2 and (len(extra)<2 or extra[1]=='pair')
    pair=len(extra)==2
    mode=extra[0] if extra else 'all'
    if device!='--prepare':
        assert device in ('nvidia','intel')
        lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
        assert lock['state']=='held' and Path(lock['output'])==out
    items,resources,project,receipt=prepare(mode,pair)
    if device=='--prepare':sys.exit(0)
    folder=out/(f'capture-{device}'+('' if mode=='all' else '-'+mode)+('-pair' if pair else ''))
    if folder.exists():
        assert not (folder/'results.json').exists()
        count=len(list(out.glob(f'{folder.name}-unsuccessful-*')))
        folder.rename(out/f'{folder.name}-unsuccessful-{count+1}')
    folder.mkdir()
    installed=[]
    linked=[]
    command=read(baseline/f'production-{device}-enabled/command.json')
    assert Path(command[0])==build/'AzurePlayer.exe'
    for flag,value in [('--project',project),('--capture-dir',folder/'frames'),('--resource-root',resources),('--runtime-report',folder/'runtime.json')]:
        if flag in command:command[command.index(flag)+1]=str(value)
        else:command.extend((flag,str(value)))
    try:
        for native,sha in fingerprints['shaderCatalog'].items():
            if native in receipt['programs']:continue
            original=build/'shaders'/native
            target=resources/'shaders'/native
            assert digest(original)==sha
            if not target.exists():target.hardlink_to(original)
            assert os.path.samefile(target,original)
            linked.append((target,original))
        assert len(list((resources/'shaders').glob('*.spv')))==895
        for key,staged in items.items():
            target=fixture/key
            if not target.exists():target.hardlink_to(staged)
            assert os.path.samefile(target,staged)
            installed.append((target,staged))
        frame=invoke(device,command,folder)/'frame_000000.png'
    finally:
        for target,staged in reversed(installed):
            if target.is_file() and os.path.samefile(target,staged):target.unlink()
            meta=target.with_name(target.name+'.azmeta')
            if meta.is_file() and target.suffix in ('.azurelevel','.azureproject') and not (staged.parent/meta.name).exists():
                meta.replace(staged.parent/meta.name)
        for target,original in linked:
            if target.is_file() and os.path.samefile(target,original):target.unlink()
    assert all(digest(resources/'shaders'/name)==sha for name,sha in receipt['programs'].items())
    measure(device,frame,receipt)
