"""Archive single-consumer tests of the original face mask."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json
import sys


root = Path(__file__).resolve().parent
outputs = root.parents[2] / 'docs/acceptance/nr/evidence/2026-11-14/face-native-geometry-mask-isolation'
load = lambda path: json.loads(path.read_bytes())
sha = lambda path: sha256(path.read_bytes()).hexdigest()
queue = json.loads(sys.stdin.buffer.read())
names = {'sdf': 608, 'view': 611, 'radial': 823, 'rim': 824}
device_runs = {}
members = {Path(__file__).name: Path(__file__), 'face-geometry-mask-actual.py': root / 'face-geometry-mask-actual.py'}
for mode, dispatch in names.items():
    receipt, = [row for row in queue['recent'] if row['id'] == dispatch]
    assert receipt['state'] == 'succeeded' and receipt['exit_code'] == 0 and Path(receipt['output']) == root
    folder = root / f'capture-nvidia-{mode}'
    result = load(folder / 'results.json')
    assert result['input']['mode'] == mode and result['input']['sampler']['mipBias'] == -1
    frame = folder / 'frames/frame_000000.png'
    assert sha(frame) == result['frameSha256']
    for scope in ('faceCore', 'iris', 'outsideFace'):
        assert result['regions'][scope]['changed'] == 0
    for name in ('command.json', 'player.log', 'results.json', 'runtime.json', 'frames/gpu_capabilities.json'):
        members[f'{folder.name}/{name}'] = folder / name
    assert 'Allocator after unload: buffers=0 images=0' in (folder / 'player.log').read_text(encoding='utf8')
    variant = root / ('assets-' + mode)
    members[f'{variant.name}/mesh-face-geometry-mask.frag'] = variant / 'mesh-face-geometry-mask.frag'
    result['queue'] = {key: receipt[key] for key in ('id', 'task', 'state', 'wait_seconds', 'run_seconds')}
    device_runs[mode] = result

sdf, view, radial, rim = (device_runs[mode] for mode in names)
assert sdf['baselineSha256'] == view['baselineSha256']
assert sdf['input']['texture'] == view['input']['texture']
assert sdf['samples']['traced']['errors'][1][:2] == [4, 2]
assert sdf['regions']['face']['overOne'] == [573, 572] and sdf['regions']['face']['newOverOne'] == 0
assert view['regions']['face']['overOne'] == [573, 577] and view['regions']['face']['newOverOne'] == 6
assert radial['regions']['face']['changed']==3 and radial['regions']['face']['newOverOne']==0
assert rim['regions']['face']['overOne']==[573,575] and rim['regions']['face']['newOverOne']==5
outputs.mkdir(parents=True, exist_ok=True)
archive = outputs / 'validation.zip'
with ZipFile(archive, 'w', ZIP_DEFLATED) as z:
    for key, path in members.items():
        z.write(path, key)
with ZipFile(archive) as z:
    assert z.testzip() is None
    checksums = {key: sha256(z.read(key)).hexdigest() for key in members}
assert checksums == {key: sha(path) for key, path in members.items()}
data = dict(overallStatus='failed-user-review', devices=dict(nvidia=device_runs),
            archive=dict(sha256=sha(archive), members=checksums))
(outputs / 'results.json').write_text(json.dumps(data, indent=2) + '\n', encoding='utf8')
print(data['archive']['sha256'])
