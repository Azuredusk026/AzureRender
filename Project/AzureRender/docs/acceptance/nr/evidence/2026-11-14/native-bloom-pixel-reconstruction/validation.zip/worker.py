from hashlib import sha256
from pathlib import Path
import json
import os
import traceback

import renderdoc as rd

out = Path(os.environ['AZURE_NR_BLOOM_CHAIN'])
report = dict(status='failed',passes=[])
request = json.loads((out/'request.json').read_bytes())
frame = '6834'
source = request[frame]


def binding_summary(used):
    value = used.sampler
    return dict(minify=str(value.filter.minify),magnify=str(value.filter.magnify),
                mip=str(value.filter.mip),address=[str(value.addressU),str(value.addressV)])


def replay():
    capture = rd.OpenCaptureFile()
    controller = None
    try:
        assert capture.OpenFile(source['path'],'',None)==rd.ResultCode.Succeeded
        options = rd.ReplayOptions()
        options.forceGPUVendor = rd.GPUVendor.nVidia
        options.forceGPUDeviceID = 0x28e0
        status,controller = capture.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and controller
        textures = {item.resourceId:item for item in controller.GetTextures()}
        stages = dict(extract=[1410],down=[1419,1428,1437,1446,1455,1464,1473],
                      seed=[1482,1491],up=[1500,1509,1518,1527,1536,1545,1554])
        stage = rd.ShaderStage.Compute
        outputs = {}
        for kind,events in stages.items():
            for index,event in enumerate(events):
                controller.SetFrameEvent(event,True)
                pipe = controller.GetPipelineState()
                reflect = pipe.GetShaderReflection(stage)
                assert reflect and reflect.rawBytes
                inputs = {reflect.readOnlyResources[s.access.index].fixedBindNumber:s.descriptor.resource
                          for s in pipe.GetReadOnlyResources(stage) if s.descriptor.resource in textures}
                dest, = [s.descriptor.resource for s in pipe.GetReadWriteResources(stage)
                         if s.descriptor.resource in textures]
                tex = textures[dest]
                expected_t0 = None
                expected_t1 = None
                if kind=='down':
                    expected_t0 = stages[kind][index-1] if index else stages['extract'][0]
                elif kind=='seed':
                    expected_t0 = stages[kind][index-1] if index else stages['down'][-1]
                elif kind=='up':
                    expected_t0 = stages[kind][index-1] if index else stages['seed'][-1]
                    expected_t1 = stages['down'][-index-2] if index<6 else stages['extract'][0]
                if expected_t0:
                    assert inputs[0]==outputs[expected_t0], (kind,event,inputs,expected_t0)
                if expected_t1:
                    assert inputs[1]==outputs[expected_t1], (kind,event,inputs,expected_t1)
                outputs[event] = dest
                constants = {}
                for constant_index,block in enumerate(reflect.constantBlocks):
                    bound = pipe.GetConstantBlock(stage,constant_index,0).descriptor
                    raw = bytes(controller.GetBufferData(bound.resource,bound.byteOffset,bound.byteSize))
                    filename = f'{event}-cb{block.fixedBindNumber}.bin'
                    (out/filename).write_bytes(raw)
                    constants[str(block.fixedBindNumber)] = filename
                assembly = controller.DisassembleShader(pipe.GetComputePipelineObject(),reflect,'')
                (out/f'{event}.asm').write_text(assembly,encoding='utf8')
                if kind=='extract':
                    raw = bytes(controller.GetTextureData(inputs[0],rd.Subresource(0,0,0)))
                    assert len(raw)==2560*1440*8
                    (out/'scene-rgba16f.bin').write_bytes(raw)
                    report['sceneSha256'] = sha256(raw).hexdigest()
                raw = bytes(controller.GetTextureData(dest,rd.Subresource(0,0,0)))
                assert len(raw)==tex.width*tex.height*4 and tex.format.Name()=='R11G11B10_FLOAT'
                filename = f'{event}-r11.bin'
                (out/filename).write_bytes(raw)
                report['passes'].append(dict(kind=kind,event=event,width=tex.width,height=tex.height,
                    resource=str(dest),inputs={str(k):str(v) for k,v in inputs.items()},
                    output=filename,sha256=sha256(raw).hexdigest(),constants=constants,
                    samplers=[binding_summary(s) for s in pipe.GetSamplers(stage)]))
        assert str(outputs[1554])==source['bloom']
    finally:
        if controller:
            controller.Shutdown()
        capture.Shutdown()


try:
    replay()
    report['status']='qualified'
except Exception:
    report['error']=traceback.format_exc()
finally:
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)
