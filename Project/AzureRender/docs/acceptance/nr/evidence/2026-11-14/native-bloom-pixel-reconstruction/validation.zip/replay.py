from hashlib import file_digest
from pathlib import Path
import json
import os
import subprocess

out = Path(__file__).resolve().parent
source = out.parent/'20261114-034154-portrait-native-bloom-composition-f3b56a'
lock = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state']=='held' and Path(lock['output'])==out
captures = json.loads((source/'results.json').read_bytes())['captures']
request = {}
for frame, data in captures.items():
    path = Path(data['source']['path'])
    with path.open('rb') as f:
        assert file_digest(f,'sha256').hexdigest()==data['source']['sha256']
    candidate, = data['candidates']
    request[frame] = dict(path=str(path),event=candidate['event'],bloom=candidate['textures']['1']['id'])
(out/'request.json').write_text(json.dumps(request,indent=2)+'\n')
environment = os.environ.copy()
environment['AZURE_NR_BLOOM_CHAIN'] = str(out)
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
with (out/'replay.log').open('wb') as log:
    child = subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'worker.py')],
                           env=environment,cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=410)
report = json.loads((out/'results.json').read_bytes())
assert child.returncode==0 and report['status']=='qualified',report
