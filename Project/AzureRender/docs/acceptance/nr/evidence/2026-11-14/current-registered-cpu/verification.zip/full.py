from pathlib import Path
import json, os, subprocess, sys, time, xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import digest,inputs,product_paths,describe,verify
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1',VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LAYER_ENABLES','AZURE_DISABLE_COMPUTED_MATERIAL_VIEW']:os.environ.pop(key,None)
mode,config=sys.argv[1:3];assert mode in ['build','suite'] and config in ['Release','Debug']
if mode=='suite' and (out/'queue-window.json').exists() and '--inside' not in sys.argv:
 print('Shared queue reserved for the next coordinated task; current shard has not started.',flush=True)
 raise SystemExit(75)
if sys.argv[1:5]==['suite','Debug','--select','debug-gpu-27-retest'] and '--inside' not in sys.argv:
 subprocess.run([sys.executable,'-B','-X','utf8',str(out/'compress_registered_debug_symbols.py')],check=True)
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),*sys.argv[1:],'--inside']).returncode)
c=config.lower();build=root/('build/ninja-msvc-'+c)
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
def invoke(name,cmd,timeout,env=None):
 with (out/(name+'.log')).open('wb') as log, subprocess.Popen(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,env=env) as process:
  try:return process.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   subprocess.run(['taskkill.exe','/PID',str(process.pid),'/T','/F'],stdout=log,stderr=subprocess.STDOUT)
   process.wait(timeout=30)
   raise
def assert_protected():
 protected=read(out/'protected-files.json');assert all(digest(root/k)==v for k,v in protected.items())
before=inputs(root);testInputs={p.relative_to(root).as_posix():digest(p) for p in (root/'tests').rglob('*') if p.is_file()}
dotnet_root=Path(os.environ['DOTNET_ROOT'])
assert (dotnet_root/'dotnet.exe').is_file()
os.environ['PATH']=os.pathsep.join((str(build),str(dotnet_root),os.environ['PATH']))
assert_protected()
if mode=='build':
 node=Path((out/'node-path.txt').read_text(encoding='utf-8-sig').strip());assert node.is_file()
 assert invoke(c+'-configure',['cmake','-S',str(root),'-B',str(build),'-U','AZURE_ENABLE_COMPUTED_MATERIAL_VIEW','-DAZURE_NODE_EXECUTABLE='+node.as_posix()],180)==0
 assert 'AZURE_ENABLE_COMPUTED_MATERIAL_VIEW:BOOL=OFF' in (build/'CMakeCache.txt').read_text()
 start=time.monotonic()
 rc=invoke(c+'-all-build',['cmake','--build',str(build),'--config',config],1500)
 if rc:raise SystemExit(rc)
 inventory=json.loads(subprocess.check_output(['ctest','--test-dir',str(build),'-C',config,'--show-only=json-v1']))
 write(c+'-inventory.json',inventory)
 assert len(inventory['tests'])>=500
 assert len({x['name'] for x in inventory['tests']})==len(inventory['tests'])
 assert all(x.get('command') for x in inventory['tests'])
 products=[*product_paths(build,config),*sorted(build.glob('*.exe'))]
 proof=describe(root,list(dict.fromkeys(products)));verify(root,proof);write(c+'-products.json',proof)
 write(c+'-tests-source.json',testInputs)
 write(c+'-build-results.json',dict(status='built',seconds=time.monotonic()-start,tests=len(inventory['tests']),
    missingCommands=[x['name'] for x in inventory['tests'] if not x.get('command')],hostSha256=digest(build/'AzurePlayer.exe')))
else:
 product_receipt=out/(c+'-products.json')
 proof=read(product_receipt);assert before==proof['source'] and testInputs==read(out/(c+'-tests-source.json'))
 stamp_path=out/(c+'-verified-product-stamps.json')
 def product_stamps():
  stamps={}
  for filename in proof['products']:
   item=Path(filename).stat()
   stamps[filename]=[item.st_size,item.st_mtime_ns,item.st_ctime_ns]
  return dict(productReceiptSha256=digest(product_receipt),products=stamps)
 def verify_products(force=False):
  now=product_stamps()
  if force or not stamp_path.is_file() or read(stamp_path)!=now:
   verify(root,proof)
   assert product_stamps()==now
   write(stamp_path.name,now)
 verify_products()
 tests=read(out/(c+'-inventory.json'))['tests']
 current_inventory=json.loads(subprocess.check_output(['ctest','--test-dir',str(build),'-C',config,'--show-only=json-v1']))
 assert current_inventory['tests']==tests,'CTest registry differs from the verified build inventory'
 command=['ctest','--test-dir',str(build),'-C',config,'--parallel','1','--output-on-failure','--no-tests=error']
 suffix=''
 if len(sys.argv)>3 and sys.argv[3]=='--select':
  name=sys.argv[4]
  assert name.startswith(c+'-') and name.isascii() and all(x.isalnum() or x=='-' for x in name)
  selection=out/(name+'.txt')
  selected=selection.read_text(encoding='utf-8').splitlines()
  by_name={test['name']:test for test in tests}
  assert selected and len(selected)==len(set(selected))
  expected_tests=[by_name[item] for item in selected]
  command+=['--tests-from-file',str(selection)]
 else:
  first,last=1,len(tests)
  name=c+'-ctest'
  expected_tests=tests
 junit=out/(name+'.xml');start=time.monotonic()
 isolated_fixture_scripts={
  'test_artifact_asset_cleanup.py','test_artifact_cleanup.py','test_artifact_maintenance.py',
  'test_artifact_pipeline_cache.py','test_code_query.py','test_code_symbols.py',
  'test_evidence_archive.py','test_evolution_coverage.py','test_repository_audit.py','test_game_package.py'}
 def uses_isolated_fixture(test):
  filesystem_targets={
   'AzureEditor.ContentDirectoryScale':'AzureContentDirectoryScaleTests',
   'AzureEditor.ProjectFlow':'AzureEditorProjectFlowTests',
  }
  if test['name'] in filesystem_targets:
   assert Path(test['command'][0]).stem==filesystem_targets[test['name']]
   return True
  return any(Path(arg).name in isolated_fixture_scripts for arg in test.get('command',[]))
 fixture_tests=[x for x in expected_tests if uses_isolated_fixture(x)]
 if fixture_tests:
  scratch=root/'build/maintenance-tests'/out.name/name
  scratch.mkdir(parents=True,exist_ok=True)
  fixture_env=os.environ|{key:str(scratch) for key in ('TMP','TEMP','TMPDIR','SQLITE_TMPDIR')}
  groups=[('ordinary',[x for x in expected_tests if not uses_isolated_fixture(x)],None),('filesystem-fixtures',fixture_tests,fixture_env)]
  rc=0;cases=[]
  for label,selected,environment in groups:
   if not selected:continue
   selection=out/(name+'-'+label+'.txt');selection.write_text(''.join(t['name']+'\n' for t in selected),encoding='utf-8')
   part=out/(name+'-'+label+'.xml')
   base=['ctest','--test-dir',str(build),'-C',config,'--parallel','1','--output-on-failure','--no-tests=error']
   code=invoke(name+'-'+label,[*base,'--tests-from-file',str(selection),'--output-junit',str(part)],4200,environment)
   rc=rc or code
   cases.extend(ET.parse(part).findall('.//testcase'))
  tree=ET.Element('testsuite',name=name,tests=str(len(cases)));tree.extend(cases);ET.ElementTree(tree).write(junit,encoding='utf-8',xml_declaration=True)
 else:
  rc=invoke(name,[*command,'--output-junit',str(junit)],4200)
  cases=ET.parse(junit).findall('.//testcase')
 expected={x['name'] for x in expected_tests}; actual={x.attrib['name'] for x in cases}
 assert expected<=actual and actual<={x['name'] for x in tests}
 failed=[x.attrib['name'] for x in cases if x.find('failure') is not None]
 skipped=[x.attrib['name'] for x in cases if x.find('skipped') is not None]
 review=bool(rc or failed or skipped)
 report=dict(status='review' if review else 'passed',
    exitCode=rc or (8 if review else 0),ctestExitCode=rc,seconds=time.monotonic()-start,tests=len(cases),selectedTests=len(expected),automaticFixtureTests=sorted(actual-expected),failed=failed,skipped=skipped)
 verify_products()
assert_protected();assert inputs(root)==before
assert testInputs=={p.relative_to(root).as_posix():digest(p) for p in (root/'tests').rglob('*') if p.is_file()}
if mode=='suite':
 receipt=out/(name+'.json')
 pending=out/(name+f'.{os.getpid()}.pending')
 report['provenanceChecked']=dict(products=digest(product_receipt),registry=digest(out/(c+'-inventory.json')),source=digest(out/(c+'-tests-source.json')),junit=digest(junit),testNames=digest(out/(name+'.txt')) if len(sys.argv)>3 and sys.argv[3]=='--select' else None)
 pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
 os.replace(pending,receipt)
 raise SystemExit(report['exitCode'])

