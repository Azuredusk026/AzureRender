from pathlib import Path
import os
import hashlib
import json
import shutil
import subprocess
import sys
from xml.etree import ElementTree as ET

scratch = Path(__file__).resolve().parent
stage = scratch/'sandbox'
report = stage/'receipt'
tools = stage/'tools'
build = stage/'build/ninja-msvc-release'
for folder in (report, tools, build, stage/'tests'):
    folder.mkdir(parents=True, exist_ok=True)
runner = scratch.parent/'full.py'
shutil.copyfile(runner, report/'full.py')
(report/'protected-files.json').write_text('{}')
(report/'release-tests-source.json').write_text('{}')
(report/'release-products.json').write_text('{"source": {}, "products": {}}')
(tools/'artifact_maintenance.py').write_text('def managed_environment(path): return {}\n')
(tools/'build_provenance.py').write_text('from hashlib import sha256\n'
    'def digest(path): return sha256(path.read_bytes()).hexdigest()\n'
    'def inputs(root): return {}\n'
    'def product_paths(*args): return []\n'
    'def describe(*args): return {}\n'
    'def verify(*args): return None\n')
(build/'CTestTestfile.cmake').write_text(
    f'add_test(PassingCase "{Path(sys.executable).as_posix()}" -c "raise SystemExit(0)")\n'
    f'add_test(FailingCase "{Path(sys.executable).as_posix()}" -c "raise SystemExit(3)")\n'
    f'add_test(SkippedCase "{Path(sys.executable).as_posix()}" -c "raise SystemExit(77)")\n'
    'set_tests_properties(SkippedCase PROPERTIES SKIP_RETURN_CODE 77)\n')
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
inventory = subprocess.check_output(['ctest','--test-dir',str(build),'-C','Release','--show-only=json-v1'],cwd=stage,env=env)
(report/'release-inventory.json').write_bytes(inventory)

def check(tag, names, failed, skipped=None):
    skipped = skipped or []
    (report/(tag+'.txt')).write_text(''.join(name+'\n' for name in names))
    result=subprocess.run([sys.executable,'-B','-X','utf8',str(report/'full.py'),
        'suite','Release','--select',tag,'--inside'],cwd=stage,env=env,capture_output=True,text=True)
    receipt=json.loads((report/(tag+'.json')).read_bytes())
    path=report/(tag+'.xml')
    cases=ET.parse(path).findall('.//testcase')
    assert [case.get('name') for case in cases if case.find('failure') is not None]==failed
    assert [case.get('name') for case in cases if case.find('skipped') is not None]==skipped
    assert receipt['failed']==failed and receipt['skipped']==skipped
    assert receipt['status']==('review' if failed or skipped else 'passed')
    assert receipt['provenanceChecked']['junit']==hashlib.sha256(path.read_bytes()).hexdigest()
    print(tag, 'CTest status', receipt.get('ctestExitCode', receipt['exitCode']), 'wrapper status', result.returncode,
          'failures',failed, 'skips',skipped,flush=True)
    assert result.returncode==receipt['exitCode'], (result.returncode, receipt['exitCode'], result.stdout, result.stderr)
    assert (result.returncode != 0) == bool(failed or skipped), result.returncode
    assert receipt.get('ctestExitCode',receipt['exitCode']) == (8 if failed else 0)

check('release-passing',['PassingCase'],[])
check('release-failing',['PassingCase','FailingCase'],['FailingCase'])
check('release-skipped',['PassingCase','SkippedCase'],[],['SkippedCase'])
