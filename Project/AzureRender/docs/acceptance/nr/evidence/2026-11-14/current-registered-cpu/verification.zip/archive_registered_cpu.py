from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys
import zipfile
import xml.etree.ElementTree as ET

run = Path(__file__).resolve().parent
root = Path.cwd()
sys.path.insert(0, str(root/'tools'))
from build_provenance import digest, inputs

out = root/'docs/acceptance/nr/evidence/2026-11-14/current-registered-cpu'
out.mkdir(exist_ok=True)
scope = {'release': 607, 'debug': 605}
protected = json.loads((run/'protected-files.json').read_bytes())
assert all(digest(root/name)==value for name,value in protected.items())
reports = {}
members = set()

def read(name):
    members.add(name)
    return json.loads((run/name).read_bytes())

def include(name):
    assert (run/name).is_file()
    members.add(name)
    return (run/name).read_bytes()

source = inputs(root)
test_source = {p.relative_to(root).as_posix():digest(p) for p in (root/'tests').rglob('*') if p.is_file()}
for mode, total in scope.items():
    inventory=read(mode+'-inventory.json')
    assert len(inventory['tests'])==total
    by_name={t['name']:t for t in inventory['tests']}
    assert len(by_name)==total
    expected={n for n,t in by_name.items() if not any(p['name']=='LABELS' and 'gpu' in p['value'] for p in t['properties'])}
    assert len(expected)==333
    product=read(mode+'-products.json')
    assert product['source']==source
    assert read(mode+'-tests-source.json')==test_source
    assert (build:=read(mode+'-build-results.json'))['status']=='built' and build['tests']==total and not build['missingCommands']
    assert all(digest(Path(name))==value for name,value in product['products'].items())
    seen=Counter()
    rows=[]
    for n in range(1,13):
        name=f'{mode}-cpu-{n:02}'
        receipt=read(name+'.json')
        assert receipt['status']=='passed' and receipt['exitCode']==0 and not receipt['failed'] and not receipt['skipped']
        tests=include(name+'.txt').decode('utf-8').splitlines()
        junit=include(name+'.xml')
        entries=ET.fromstring(junit).findall('.//testcase')
        assert sorted(x.attrib['name'] for x in entries)==sorted(tests)
        assert all(x.get('status')=='run' and x.find('failure') is None and x.find('skipped') is None for x in entries)
        assert len(tests)==receipt['tests']==receipt['selectedTests'] and set(tests)<=expected
        if (fingerprints:=receipt.get('provenanceChecked')):
            assert fingerprints=={k:digest(run/f) for k,f in dict(products=mode+'-products.json',registry=mode+'-inventory.json',source=mode+'-tests-source.json',junit=name+'.xml',testNames=name+'.txt').items()}
        else:
            assert name=='release-cpu-01'
        queue=include(name+'-queue.log').decode('utf-8')
        decoder=json.JSONDecoder()
        jobs=[]
        while queue.strip():
            queue=queue.lstrip()
            row,size=decoder.raw_decode(queue)
            jobs.append(row)
            queue=queue[size:]
        assert jobs[-1]['state']=='succeeded' and jobs[-1]['task']==name and jobs[-1]['exit_code']==0
        seen.update(tests)
        rows.append(dict(shard=name,job=jobs[-1]['id'],count=len(tests),junitSha256=sha256(junit).hexdigest(),runSeconds=receipt['seconds'],perShardFingerprints=bool(fingerprints)))
    assert seen==Counter({x:1 for x in expected})
    reports[mode]=dict(registrationCount=total,passedCpu=len(seen),failedCpu=0,skippedCpu=0,registeredGpu=total-len(seen),
        productCount=len(product['products']),hostSha256=build['hostSha256'],sourceCommit=product['commit'],sources=len(product['source']),
        registrySha256=digest(run/(mode+'-inventory.json')),receiptSha256=digest(run/(mode+'-products.json')),shards=rows)

for name in ('controller.py','full.py','focused_retry.py','wrapper-exit-check/verify.py',
             'wrapper-exit-check/red.log','wrapper-exit-check/green.log','wrapper-exit-check/skipped-red.log',
             'wrapper-exit-check/final-green.log','archive_registered_cpu.py'):
    include(name)
# Do not pack test scripts' file-system fixtures or activity logs outside this scope.
bundle=out/'verification.zip'
with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for key in sorted(members):
        z.writestr(key, (run/key).read_bytes())
with zipfile.ZipFile(bundle) as z:
    assert set(z.namelist())==members and z.testzip() is None
    assert all(sha256(z.read(n)).hexdigest()==digest(run/n) for n in z.namelist())
data=dict(date='2026-11-14',scope='CPU registered subset; full GPU regression remains separate',configurations=reports,
    exitCodeControls=dict(passing={'ctest':0,'dispatch':0},failing={'ctest':8,'dispatch':8},skipped={'ctest':0,'dispatch':8}),
    archive=dict(members=len(members),bytes=bundle.stat().st_size,sha256=digest(bundle)))
(out/'results.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print({k:(v['passedCpu'],v['registrationCount']) for k,v in reports.items()}, data['archive'],flush=True)
