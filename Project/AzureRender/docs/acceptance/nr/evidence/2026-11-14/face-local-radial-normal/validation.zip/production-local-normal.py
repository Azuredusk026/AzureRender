from pathlib import Path
from hashlib import sha256
from uuid import NAMESPACE_URL,uuid5
import json
import re
import runpy

import cv2
import numpy as np
from PIL import Image

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
previous = out.parent/'20261114-042314-face-mask-native-tint-bb8d53'
fixture = grid/'iris-overlay-geometry-project'
h = runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read,dump,invoke = (h[key] for key in ('read','dump','invoke'))
release = h['build']
lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==out
name = 'face-native-radial-local-production'
base = 'face-native-mask-tint-production'
baseline_project = fixture/f'{base}.azureproject'
candidate_project = fixture/f'{name}.azureproject'
project = read(baseline_project)
scene = read(fixture/'scene'/f'{base}.azurelevel')
spec = read(fixture/'materials'/f'{base}.azurematerial')
npr = spec['surface']['materials'][0]['extras']['azureRenderMaterial']['nprDiffuse']
assert npr['indirectNormal']=='face-frame-radial-horizontal'
npr['localDiffuseNormal'] = 'indirect'
identity = str(uuid5(NAMESPACE_URL,'azurerender/804/'+name))


def bind(path,data):
    if path.exists():
        assert read(path)==data,path
    else:
        dump(path,data)


asset = fixture/'materials'/f'{name}.azurematerial'
bind(asset,spec)
bind(asset.with_suffix('.azurematerial.azmeta'),dict(schemaVersion=1,id=identity,dependencies=[],settings={}))
next(n for n in scene['nodes'] if n['id']=='hero')['materialSlots']['name:M_actor_laevat_face_01']=identity
bind(fixture/'scene'/f'{name}.azurelevel',scene)
project['startupScene']=f'stage:/{name}.azurelevel'
bind(candidate_project,project)
scorer = runpy.run_path(str(grid/'static-quality.py'))
image = lambda path:scorer['image'](path).astype(np.int16)
digest = lambda path:sha256(path.read_bytes()).hexdigest()
reference = image(scorer['reference_path'])
full = np.asarray(Image.open(grid/'native-face-masks/face.png').convert('L'))>0
mask = cv2.erode(full.astype(np.uint8),np.ones((13,13),np.uint8))>0
assert int(mask.sum())==1176
results = dict(player=digest(release/'AzurePlayer.exe'),corePixels=int(mask.sum()),
               fullFacePixels=int(full.sum()),devices={})
for device in ('nvidia','intel'):
    row = results['devices'][device]={}
    baseline = previous/f'production-{device}-enabled'
    for label,project in [('disabled',baseline_project),('enabled',candidate_project)]:
        target = out/f'production-{device}-{label}'
        target.mkdir(exist_ok=True)
        command = read(baseline/'command.json')
        command[command.index('--project')+1]=str(project)
        command[command.index('--capture-dir')+1]=str(target/'frames')
        frame = target/'frames/frame_000000.png'
        if frame.exists():
            assert read(target/'command.json')==command
            log = (target/'player.log').read_text(errors='replace')
            assert 'Allocator after unload: buffers=0 images=0' in log
            assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I)
            assert read(frame.parent/'gpu_capabilities.json')['vendor_id']==(0x10de if device=='nvidia' else 0x8086)
        else:
            frame = invoke(device,command,target)/frame.name
        expected = (baseline if label=='disabled' else out/device)/'frames/frame_000000.png'
        pixels = image(frame)
        delta = np.abs(pixels-image(expected)).max(2)
        signed = pixels-reference
        error = np.abs(signed).max(2)
        row[label] = dict(frame=digest(frame),expected=digest(expected),exact=not delta.any(),
                          pixelsDifferent=int((delta>0).sum()),maximumDifference=int(delta.max()),
                          coreOverOne=int((error[mask]>1).sum()),fullOverOne=int((error[full]>1).sum()),
                          corePeak=int(error[mask].max()),fullPeak=int(error[full].max()),
                          coreMedian=np.median(signed[mask],axis=0).tolist())
        if label=='disabled':
            baseline_error = error
        else:
            new = (baseline_error<=1)&(error>1)
            row[label]['newFaceEdgeOverOne'] = int((new&full&~mask).sum())
            row[label]['newOutsideFaceOverOne'] = int((new&~full).sum())
        (out/'production-local-normal-results.json').write_text(json.dumps(results,indent=2)+'\n')
        assert row[label]['exact'], (device,label,row[label])
        if label=='enabled':
            assert row[label]['newOutsideFaceOverOne']==0,(device,label,row[label])
