from pathlib import Path
from hashlib import sha256
import json
import os
import runpy
import subprocess

import cv2
import numpy as np
from PIL import Image

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
prior = out.parent/'20261114-042314-face-mask-native-tint-bb8d53'
helpers = runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read, invoke = (helpers[k] for k in ('read','invoke'))
build = helpers['build']
lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==out
source = grid.parents[2]/'shaders/mesh.frag'
sdk = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
resource = out/'resources'
shaders = resource/'shaders'
shaders.mkdir(parents=True,exist_ok=True)
names = ('mesh_object_early_lighting.frag.spv','mesh_object_lighting.frag.spv')
rules = [rule for rule in read(build/'shader-reload.json')['programs'] if rule['output'] in names]
assert len(rules)==2
for path in (build/'shaders').glob('*.spv'):
    if path.name not in names:
        target = shaders/path.name
        if target.exists():
            assert os.path.samefile(target,path)
        else:
            target.hardlink_to(path)
stamp = resource/'runtime-build-Release.json'
if not stamp.exists():
    stamp.hardlink_to(build/stamp.name)

code = source.read_text()
marker = '''        vec3 characterRadiance=characterLight?characterLocalLightRadiance(radiance,
            dot(localLightingNormal,pointDirection),localResponse,characterSceneVisibility):radiance;'''
assert code.count(marker)==1
replacement = '''        vec3 wrapNormal=dualFaceSdf&&AZURE_MATERIAL_CLASS==2U?indirectDiffuseNormal:localLightingNormal;
        vec3 characterRadiance=characterLight?characterLocalLightRadiance(radiance,
            dot(wrapNormal,pointDirection),localResponse,characterSceneVisibility):radiance;'''
path = out/'face-radial-local.frag'
path.write_text(code.replace(marker,replacement))
hashes = {}
for rule in rules:
    target = shaders/rule['output']
    subprocess.run([str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+d for d in rule['defines']),
                   '-I'+str(source.parent),str(path),'-o',str(target)],check=True)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',
                    str(target)],check=True)
    hashes[target.name] = sha256(target.read_bytes()).hexdigest()

scorer = runpy.run_path(str(grid/'static-quality.py'))
image = lambda p:scorer['image'](p).astype(np.int16)
reference = image(scorer['reference_path'])
mask = cv2.erode(np.asarray(Image.open(grid/'native-face-masks/face.png').convert('L')),
                 np.ones((13,13),np.uint8))>0
assert int(mask.sum())==1176
strong = [(1295,283),(1296,301)]
report = dict(overallStatus='failed-user-review',shaders=hashes,devices={})
for device in ('nvidia','intel'):
    folder = out/device
    folder.mkdir(exist_ok=True)
    baseline = prior/f'production-{device}-enabled'
    command = read(baseline/'command.json')
    for flag,value in (('--capture-dir',folder/'frames'),('--resource-root',resource)):
        command[command.index(flag)+1] = str(value)
    frame = invoke(device,command,folder)/'frame_000000.png'
    b = image(baseline/'frames/frame_000000.png')-reference
    a = image(frame)-reference
    pre, post = np.abs(b).max(2),np.abs(a).max(2)
    report['devices'][device] = dict(frame=sha256(frame.read_bytes()).hexdigest(),
        faceOverOne=[int((f[mask]>1).sum()) for f in (pre,post)],
        facePeak=[int(f[mask].max()) for f in (pre,post)],
        faceMedian=[np.median(f[mask],axis=0).tolist() for f in (b,a)],
        strongPoints=[dict(x=x,y=y,before=b[y,x].tolist(),after=a[y,x].tolist()) for x,y in strong],
        newOutsideFaceOverOne=int(((pre<=1)&(post>1)&~mask).sum()))
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
