from pathlib import Path
import json,os,subprocess
out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
lock=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state']=='held' and Path(lock['output'])==out
results=[]
for name in ('nvidia','intel'):
    env=os.environ.copy()
    for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT','VK_INSTANCE_LAYERS'):
        env.pop(key,None)
    if name=='nvidia':env['VK_DRIVER_FILES']=str(grid/'nv-vk64-active-absolute.json')
    else:env['VK_LOADER_DRIVERS_SELECT']='*igvk64*'
    command=[ctest,'--test-dir',str(build),'-R',r'^AzureEngine.(DualFaceSdfGpu|FaceMaskedRimGpu)$',
        '--no-tests=error','--output-on-failure','--output-junit',str(out/f'production-{name}-ctest.xml')]
    with (out/f'production-{name}-ctest.log').open('wb') as stream:
        p=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=850)
    results.append(dict(device=name,exitCode=p.returncode))
    (out/'production-ctest.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['exitCode']==0 for r in results),results
