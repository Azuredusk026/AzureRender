from pathlib import Path
from hashlib import sha256
import json
import math
import os
import struct
import traceback

import renderdoc as rd

out = Path(os.environ['AZURE_NR_FACE_CHROMA'])
request = json.loads((out/'request.json').read_bytes())
capture = rd.OpenCaptureFile()
controller = None
report = dict(status='failed',samples=[])
try:
    assert capture.OpenFile(request['native'],'',None)==rd.ResultCode.Succeeded
    options = rd.ReplayOptions()
    options.forceGPUVendor = rd.GPUVendor.nVidia
    options.forceGPUDeviceID = 0x28e0
    status,controller = capture.OpenCapture(options,None)
    assert status==rd.ResultCode.Succeeded and controller
    event = 804
    controller.SetFrameEvent(event,True)
    pipe = controller.GetPipelineState()
    stage = rd.ShaderStage.Fragment
    reflection = pipe.GetShaderReflection(stage)
    target = pipe.GetOutputTargets()[0].resource
    report['constants'] = {}
    for index,block in enumerate(reflection.constantBlocks):
        if block.fixedBindNumber not in (0,1,3,4,5,6,7):
            continue
        descriptor = pipe.GetConstantBlock(stage,index,0).descriptor
        if descriptor.resource==rd.ResourceId.Null():
            continue
        raw = bytes(controller.GetBufferData(descriptor.resource,descriptor.byteOffset,descriptor.byteSize))
        filename = f'e{event}-cb{block.fixedBindNumber}.bin'
        (out/filename).write_bytes(raw)
        report['constants'][str(block.fixedBindNumber)] = dict(path=filename,size=len(raw),sha256=sha256(raw).hexdigest())
    for x,y in request['points']:
        history = controller.PixelHistory(target,x,1439-y,rd.Subresource(),rd.CompType.Typeless)
        result, = (row for row in history if row.eventId==event and row.Passed())
        inputs = rd.DebugPixelInputs()
        inputs.primitive = result.primitiveID
        trace = controller.DebugPixel(x,1439-y,inputs)
        assert trace and trace.debugger
        registers = {}
        lights = []
        current = None
        pre_local = None
        end_local = None
        try:
            while True:
                entries = controller.ContinueDebug(trace.debugger)
                if not entries:
                    break
                for entry in entries:
                    for change in entry.changes:
                        row = change.after
                        if row.name and row.name[0]=='r':
                            registers[row.name] = (list(row.value.f32v)[:4],list(row.value.u32v)[:4])
                    step = int(entry.nextInstruction)
                    f = lambda n:registers[n][0]
                    u = lambda n:registers[n][1]
                    if step==887:
                        pre_local = f('r7')[:3]
                    if step==947:
                        current = dict(index=u('r12')[3],rowOffset=u('r16')[3],initialAttenuation=f('r15')[3])
                    if step==1271 and current is not None:
                        current['wrapInputs'] = dict(normal=f('r4')[:3],direction=f('r27')[:3],context=f('r8')[2],
                            colorRow=u('r16')[3],responseRow=u('r18')[2],incomingWeight=f('r12')[3])
                    if step==1118 and current is not None:
                        current.update(composedColor=f('r24')[:3],colorBlendWeight=f('r15')[3],
                                       priorColor=f('r21')[:3])
                    if step==1405 and current is not None and 'composedColor' in current:
                        current['contribution'] = [a-b for a,b in zip(current['composedColor'],current['priorColor'])]
                        lights.append(current)
                        current = None
                    if step==1399 and current is not None:
                        current.update(contribution=f('r18')[:3],radiance=f('r22')[:3],diffuse=f('r26')[:3],
                                       incomingWeight=f('r12')[3])
                        lights.append(current)
                        current = None
                    if step==1415:
                        end_local = f('r20')[:3]
        finally:
            controller.FreeTrace(trace)
        assert pre_local is not None and end_local is not None
        report['samples'].append(dict(x=x,y=y,primitive=inputs.primitive,lights=lights,
                                     preLocal=pre_local,afterLocal=end_local))
    report['status']='qualified'
except Exception:
    report['error']=traceback.format_exc()
finally:
    if controller:
        controller.Shutdown()
    capture.Shutdown()
    (out/'native-results.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)
