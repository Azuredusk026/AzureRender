from hashlib import file_digest
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json
import xml.etree.ElementTree as ET

out=Path(__file__).resolve().parent
target=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/face-receiver-msaa'
read=lambda p:json.loads(p.read_bytes())
def digest(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()

cpu=out/'receiver-msaa-release-cpu.xml'
tests=ET.parse(cpu).findall('.//testcase')
assert len(tests)==2 and all(c.find(k) is None for c in tests for k in ('failure','error','skipped'))
groups={}
members={p:out/p for p in (Path(__file__).name,'receiver-msaa-batch.py',cpu.name)}
for name in ('nvidia-release-red-v2','nvidia-release-fixed','intel-release-fixed'):
    run=out/f'receiver-msaa-{name}'
    receipt=read(run/'summary.json')
    positive='fixed' in name
    assert bool(receipt['failures'])!=positive and len(receipt['captures'])==(12 if positive else 8)
    assert all(not r['validationEnabled'] for r in receipt['captures'])
    for kind in ('face','eye'):
        row=receipt['metrics'][kind]
        assert row['wrongClassError']==0
        assert row['edgeError']<.008 if positive else row['edgeError']>.23
        if positive:assert row['disjointError']==0
    for capture in receipt['captures']:
        path=run/capture['name']/'frames'
        assert digest(path/'frame_000000.png')==capture['imageSha256']
        manifest=path/'capture_manifest.json'
        assert digest(manifest)==capture['manifestSha256']
        detail=read(manifest)
        assert detail['rasterizationSamples']==detail['snapshotRasterizationSamples']==4
        assert read(path/'gpu_capabilities.json')['vendor_id']==(0x10de if name.startswith('nvidia') else 0x8086)
        members[path.relative_to(out).as_posix()+'/capture_manifest.json']=manifest
    for path in (run/'summary.json',out/(run.name+'.log')):members[path.relative_to(out).as_posix()]=path
    groups[name]={k:receipt[k] for k in ('metrics','failures','playerSha256')}
assert groups['nvidia-release-fixed']['playerSha256']==groups['intel-release-fixed']['playerSha256']
assert groups['nvidia-release-fixed']['playerSha256']!=groups['nvidia-release-red-v2']['playerSha256']
target.mkdir(parents=True,exist_ok=False)
with ZipFile(target/'validation.zip','x',ZIP_DEFLATED) as archive:
    for name,path in members.items():archive.write(path,name)
with ZipFile(target/'validation.zip') as archive:assert set(archive.namelist())==set(members) and archive.testzip() is None
result=dict(overallStatus='failed-user-review',fixtures=groups,cpu=[c.get('name') for c in tests],
            archive=dict(members=len(members),sha256=digest(target/'validation.zip')))
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(result['archive'])
