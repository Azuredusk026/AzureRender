from pathlib import Path
import json
import runpy
import subprocess
import sys

out = Path(__file__).resolve().parent
work = out.parents[2]
batch = runpy.run_path(str(out / 'face-quality-batch.py'))
device, config, label = sys.argv[1:]
assert device in ('nvidia', 'intel') and config in ('release', 'debug')
lock = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state'] == 'held' and Path(lock['output']) == out
capture = out / f'receiver-msaa-{device}-{config}-{label}'
exe = (out / f'msaa-{config}' if label.startswith('fixed') else batch[config]) / 'AzurePlayer.exe'
args = [sys.executable, str(work / 'tools/test_material_composite_gpu.py'), '--executable',
        str(exe), '--receiver-msaa-only', '--output', str(capture),
        '--expected-validation', 'enabled' if config == 'debug' else 'disabled']
code = batch['log'](capture.name, args, dict(env=batch['env_for'](device), cwd=work), 1000)
raise SystemExit(code)
