from pathlib import Path
from io import BytesIO
from hashlib import sha256
from uuid import NAMESPACE_URL,uuid5
import json,runpy,struct,subprocess
import numpy as np
from PIL import Image

output=Path(__file__).resolve().parent
run=output.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
lock=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state']=='held' and Path(lock['output'])==output
root=run/'iris-overlay-geometry-project'
base=runpy.run_path(str(run/'iris-production-frozen-recovery.py'))
read,dump,invoke=(base[k] for k in ('read','dump','invoke'))
score=runpy.run_path(str(run/'static-quality.py'))
release=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
repo=run.parents[2]
src=repo/'shaders/mesh.frag'
folder=output/'retest'
folder.mkdir()
resource=folder/'resources'
shader_directory=resource/'shaders'
shader_directory.mkdir(parents=True)
rules=read(release/'shader-reload.json')['programs']
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
assets=run/'native-face-highlight-mips'
texture=read(assets/'results.json')
assert texture['status']=='qualified' and texture['format']=='BC7_UNORM'
w,h=texture['width'],texture['height']
mips=[]
for i,row in enumerate(texture['levels']):
    raw=(assets/row['path']).read_bytes()
    assert sha256(raw).hexdigest()==row['sha256']
    mw,mh=max(1,w>>i),max(1,h>>i)
    head=struct.pack('<31I',124,0x81007,mh,mw,len(raw),0,1,*([0]*11),32,4,0x30315844,0,0,0,0,0,0x1000,0,0,0,0)
    with Image.open(BytesIO(b'DDS '+head+struct.pack('<5I',98,3,0,1,0)+raw)) as im:
        mips.append(im.convert('RGBA').transpose(Image.Transpose.FLIP_TOP_BOTTOM).tobytes())
head=struct.pack('<31I',124,0x2100F,h,w,w*4,0,len(mips),*([0]*11),32,4,0x30315844,0,0,0,0,0,0x401008,0,0,0,0)
def uid(name):
    return str(uuid5(NAMESPACE_URL,'azurerender/face-highlight-804/'+name))
name='face-highlight-native-t12-retest'
tex=root/'materials'/f'{name}.dds'
data=b'DDS '+head+struct.pack('<5I',28,3,0,1,0)+b''.join(mips)
tex.write_bytes(data)
dump(tex.with_suffix('.dds.azmeta'),dict(schemaVersion=1,id=uid(name),dependencies=[],settings=dict(texture=dict(
    schemaVersion=1,usage='linear',colorSpace='linear',mipPolicy='generate',mipFilter='nearest',anisotropy=1,mipBias=-1,
    wrapU='repeat',wrapV='repeat'))))

def project(name,with_highlight):
    level=read(root/'scene/face-t18.azurelevel')
    spec=read(root/'materials/face-t18.azurematerial')
    hero=next(x for x in level['nodes'] if x['id']=='hero')
    path=root/'materials'/f'{name}.azurematerial'
    if with_highlight:
        spec['textures']['5']={'asset':uid('face-highlight-native-t12-retest'),'usage':'linear'}
        spec['surface']['textures'].append(dict(source=5))
        spec['surface']['materials'][0]['emissiveTexture']=dict(index=5)
    dump(path,spec)
    dump(path.with_suffix('.azurematerial.azmeta'),dict(schemaVersion=1,id=uid(name),dependencies=[],settings={}))
    hero['materialSlots']['name:M_actor_laevat_face_01']=uid(name)
    dump(root/'scene'/f'{name}.azurelevel',level)
    scene=read(root/'eye-shadow-production.azureproject')
    scene['startupScene']=f'stage:/{name}.azurelevel'
    dest=root/f'{name}.azureproject';dump(dest,scene)
    return dest

def compile_programs():
    marker='        sceneMainDiffuse=response.color*illumination.direct;'
    code=src.read_text()
    assert code.count(marker)==1
    patch="""
        if(dualFaceSdf&&textureSize(AZ_TEX_SPECULAR_EMISSIVE,0).x>2) {
            vec2 shift=vec2(dot(viewDirection,normalize(instanceFaceFrame[0].xyz))*.03,0);
            vec3 faceHighlight=texture(AZ_TEX_SPECULAR_EMISSIVE,textureCoordinate+shift).rgb;
            directSpecular+=faceHighlight*(illumination.ambient+illumination.direct);
            beautyColor+=faceHighlight*(illumination.ambient+illumination.direct);
        }
"""
    candidate=folder/'mesh-face-highlight.frag'
    candidate.write_text(code.replace(marker,patch+marker))
    selected=('mesh_object_early_lighting.frag.spv','mesh_object_lighting.frag.spv')
    for rule in rules:
        name=rule['output']
        if name not in selected:continue
        dst=shader_directory/name
        cmd=[str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+flag for flag in rule['defines']),
            '-I'+str(src.parent),str(candidate),'-o',str(dst)]
        subprocess.run(cmd,check=True)
        subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(dst)],check=True)
    assert all((shader_directory/name).exists() for name in selected)
    for f in (release/'shaders').glob('*.spv'):
        to=shader_directory/f.name
        if not to.exists():to.hardlink_to(f)
    for f in ('runtime-build-Release.json',):
        (resource/f).hardlink_to(release/f)

projects={'reference':project('face-highlight-source-control-retest',False),'highlight':project('face-highlight-source-test-retest',True)}
compile_programs()
ref=score['image'](score['reference_path']).astype(np.int16)
mask=np.asarray(Image.open(run/'native-face-masks/face.png').convert('L'))
import cv2
mask=cv2.erode(mask,np.ones((13,13),np.uint8))>0
assert mask.sum()==1176
points=np.fromfile(run/'face-residual-points.bin','<u4').reshape(-1,2)
x,y=points.T
report={'nativeMipCount':len(mips),'textureSha256':sha256(data).hexdigest(),'devices':{}}
for device in ('nvidia','intel'):
    row={}
    for mode,project_path in projects.items():
        target=folder/f'{device}-{mode}'
        target.mkdir()
        cmd=read(run/f'static-{device}-command.json')
        for key,value in (('--project',project_path),('--capture-dir',target/'frames'),('--resource-root',resource)):
            cmd[cmd.index(key)+1]=str(value)
        frames=invoke(device,cmd,target)
        image=score['image'](frames/'frame_000000.png').astype(np.int16)
        error=np.abs(image-ref).max(2)
        row[mode]=dict(frame=sha256((frames/'frame_000000.png').read_bytes()).hexdigest(),
            overOne=int((error[mask]>1).sum()),overEight=int((error[mask]>8).sum()),peak=int(error[mask].max()),
            selected=error[y,x].tolist(),rgb=image[y,x].tolist())
        report['devices'][device]=row
        (folder/'results.json').write_text(json.dumps(report,indent=2)+'\n')
