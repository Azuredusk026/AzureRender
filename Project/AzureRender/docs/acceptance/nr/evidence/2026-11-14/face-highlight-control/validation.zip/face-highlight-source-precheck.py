from pathlib import Path
from hashlib import sha256
from io import BytesIO
import json,struct
from PIL import Image
import numpy as np

run=Path(__file__).resolve().parent
source=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-212213-native-binding-restoration-d39ea8/frame10401')
receipt=json.loads((source/'e804-t12-bin-receipt.json').read_bytes())['data']
data=(source/'e804-t12.bin').read_bytes()
assert sha256(data).hexdigest()==receipt['sha256'] and receipt['format']=='BC7_UNORM'
w,h=receipt['width'],receipt['height']
head=struct.pack('<31I',124,0x81007,h,w,len(data),0,1,*([0]*11),32,4,0x30315844,0,0,0,0,0,0x1000,0,0,0,0)
a=np.asarray(Image.open(BytesIO(b'DDS '+head+struct.pack('<5I',98,3,0,1,0)+data)).convert('RGBA'),dtype=float)/255
def sample(image,uv):
    h,w,c=image.shape
    p=np.array(uv)*[w,h]-.5
    xy=np.floor(p).astype(int)
    u,v=p-xy
    x,y=xy
    return (1-v)*((1-u)*image[y%h,x%w]+u*image[y%h,(x+1)%w])+v*((1-u)*image[(y+1)%h,x%w]+u*image[(y+1)%h,(x+1)%w])
rows=[]
for row in (296,297):
    t=json.loads((run/'native-face-cloth-full-trace'/f'804-1279-{row}.json').read_bytes())
    uv=t['737']['r7'][:2]
    raw=t['738']['r7'][:3]
    before=np.array(t['769']['r7'][:3])
    illumination=np.array(t['770']['r12'])[list([0,2,3])]
    contrib=(before*illumination)*.25
    print(row,uv,raw,sample(a,uv).tolist(),contrib.tolist())
    rows.append(dict(pixel=[1279,row],uv=uv,nativeSample=raw,baseLevelBilinear=sample(a,uv).tolist(),
        illumination=illumination.tolist(),normalizedContribution=contrib.tolist(),ddsFormat=receipt['format']))
(run/'face-highlight-source-precheck.json').write_text(json.dumps(rows,indent=2)+'\n')
