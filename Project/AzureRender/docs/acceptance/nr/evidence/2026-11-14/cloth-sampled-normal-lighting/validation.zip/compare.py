from hashlib import sha256
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5
import json
import runpy
import subprocess

import numpy as np


output = Path(__file__).resolve().parent
grid = output.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
fixture = grid / 'iris-overlay-geometry-project'
helpers = runpy.run_path(str(grid / 'iris-production-frozen-recovery.py'))
read, dump, invoke = (helpers[k] for k in ('read', 'dump', 'invoke'))
release = helpers['build']
rules = read(release / 'shader-reload.json')['programs']
source = grid.parents[2] / 'shaders/mesh.frag'
sdk = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
ownership = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert ownership['state'] == 'held' and Path(ownership['output']) == output


def build_resources(mode):
    root = output / f'resources-{mode}'
    directory = root / 'shaders'
    directory.mkdir(parents=True)
    marker = '    vec3 shadedNormal = normalize(tangentToWorld * sampledNormal);'
    code = source.read_text()
    assert code.count(marker) == 1
    change = '''
    if(AZURE_MATERIAL_CLASS==4U&&AZURE_ALPHA_MODE==2&&textureSize(AZ_TEX_NORMAL,0).x==2048) {
        vec2 sampledXY=normalSample.rg*2.0-1.0;
        float sampledZ=sqrt(max(1.0-dot(sampledXY,sampledXY),0.0));
        shadedNormal=normalize(tangentToWorld*vec3(sampledXY,sampledZ));
    }
'''
    if mode == 'interpolated-frame':
        replacement = '''
        vec3 nativeTangent=worldTangent.xyz;
        vec3 nativeNormal=worldNormal;
        vec3 nativeBitangent=cross(nativeNormal,nativeTangent)*worldTangent.w;
        vec3 tangentNormal=vec3(sampledXY,sampledZ);
        shadedNormal=normalize(mat3(nativeTangent,nativeBitangent,nativeNormal)*tangentNormal)
            *(gl_FrontFacing?1.0:-1.0);
'''
        change = change.replace('        shadedNormal=normalize(tangentToWorld*vec3(sampledXY,sampledZ));', replacement)
    trial = root / f'mesh-{mode}.frag'
    trial.write_text(code.replace(marker, marker + change))
    target = 'mesh_object_lighting.frag.spv'
    rule, = (r for r in rules if r['output'] == target)
    dst = directory / target
    subprocess.run([str(sdk/'glslc.exe'), *rule['arguments'], *('-D'+flag for flag in rule['defines']),
                    '-I'+str(source.parent), str(trial), '-o', str(dst)], check=True)
    subprocess.run([str(sdk/'spirv-val.exe'), '--target-env', 'vulkan1.3', '--relax-block-layout', str(dst)], check=True)
    for path in (release / 'shaders').glob('*.spv'):
        if path.name != target:
            (directory / path.name).hardlink_to(path)
    (root / 'runtime-build-Release.json').hardlink_to(release / 'runtime-build-Release.json')
    return root


def asset_id(name):
    return str(uuid5(NAMESPACE_URL, 'azurerender/cloth-normal-lighting-1383/' + name))


def combined():
    name = 'cloth-native-normal-rim'
    level = read(fixture / 'scene/cloth-rim-color-adjustment-retest.azurelevel')
    slot = 'name:M_actor_laevat_cloth_03'
    hero = next(n for n in level['nodes'] if n['id'] == 'hero')
    material = read(fixture / 'materials/cloth-rim-color-adjustment-retest.azurematerial')
    authored = read(fixture / 'materials/cloth-native-normal-negative-y.azurematerial')
    material['textures']['2'] = authored['textures']['2']
    path = fixture / 'materials' / f'{name}.azurematerial'
    dump(path, material)
    dump(path.with_suffix('.azurematerial.azmeta'), dict(schemaVersion=1, id=asset_id(name), dependencies=[], settings={}))
    hero['materialSlots'][slot] = asset_id(name)
    dump(fixture / 'scene' / f'{name}.azurelevel', level)
    project = read(fixture / 'eye-shadow-production.azureproject')
    project['startupScene'] = f'stage:/{name}.azurelevel'
    path = fixture / f'{name}.azureproject'
    dump(path, project)
    return path


projects = {
    'material': fixture / 'cloth-rim-color-adjustment-retest.azureproject',
    'both': combined(),
}
resources = {key: build_resources(key) for key in ('reconstruct-rg', 'interpolated-frame')}
scoring = runpy.run_path(str(grid / 'static-quality.py'))
image = lambda path: scoring['image'](path).astype(np.int16)
reference = image(scoring['reference_path'])
points = read(grid / 'native-face-skin-stages/results.json')['history']['cloth']
x, y = np.array([(p['x'], p['y']) for p in points]).T
assert len(x) == 30


def score(actual, baseline, comparison):
    error = np.abs(actual - reference).max(2)
    old = np.abs(baseline - reference).max(2)
    change = np.abs(actual - comparison).max(2)
    return dict(overEight=int((error[y,x] > 8).sum()), peak=int(error[y,x].max()),
                newFrameOverOne=int(((old <= 1) & (error > 1)).sum()),
                changedPixels=int((change > 0).sum()), errors=error[y,x].tolist(), rgb=actual[y,x].tolist())


report = {}
for device in ('nvidia', 'intel'):
    row = report[device] = {}
    baseline = image(grid / f'cloth-production-color-adjustment-retest/{device}-static-baseline/frames/frame_000000.png')
    rim = image(grid / f'cloth-production-color-adjustment-retest/{device}-static-rim/frames/frame_000000.png')
    row['baseline'] = score(baseline, baseline, baseline)
    row['rim'] = score(rim, baseline, rim)
    for mode, project in (('both', 'both'), ('reconstruct-rg', 'material'), ('reconstruct-rg', 'both'),
                          ('interpolated-frame', 'both')):
        name = f'{mode}-{project}'
        path = output / f'{device}-{name}'
        path.mkdir()
        command = read(grid / f'static-{device}-command.json')
        for key, value in (('--project', projects[project]), ('--capture-dir', path/'frames'),
                           ('--resource-root', resources.get(mode, release))):
            command[command.index(key)+1] = str(value)
        frame = invoke(device, command, path) / 'frame_000000.png'
        row[name] = score(image(frame), baseline, rim)
        row[name]['frame'] = sha256(frame.read_bytes()).hexdigest()
        (output / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
