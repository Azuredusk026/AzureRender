from pathlib import Path
import sys

out = Path(__file__).resolve().parent
old = Path(sys.argv[1])
cpp = (old/"range.cpp").read_text(encoding="utf-8")
cpp = cpp.replace("source.size()*sizeof(Pair)*3", "source.size()*sizeof(Pair)*7")
cpp = cpp.replace("source.size()*sizeof(Pair)*2", "source.size()*sizeof(Pair)*6")
cpp = cpp.replace("unsigned size=std::min(w,h)>=4?4:std::min(w,h)>=2?2:1;", "")
cpp = cpp.replace("((w+size-1)/size)*((h+size-1)/size)", "(w>=3&&w<=4&&h>=3&&h<=4)?1:w*h")
cpp = cpp.replace('std::ofstream(argv[4])<<result.dump(2);',
    'if(hierarchyReads*4>=baseReads)throw std::runtime_error("Four-shape table did not remove 75% of range reads");std::ofstream(argv[4])<<result.dump(2);')
cpp = cpp.replace("includes hierarchy build cost", "includes four rectangular tables and their build cost")
(out/"range.cpp").write_text(cpp,encoding="utf-8")
