from pathlib import Path
import hashlib
import json
import sys
from zipfile import ZIP_DEFLATED, ZipFile

root=Path.cwd()
probe=Path(__file__).resolve().parent
profile=Path(sys.argv[1])
profile_result=json.loads((profile/"results.json").read_bytes())
nvidia=json.loads((probe/"nvidia-summary.json").read_bytes())
intel=json.loads((probe/"intel-summary.json").read_bytes())
assert nvidia["allResultsBitExact"] and intel["allResultsBitExact"]
assert nvidia["capturedQueries"]==intel["capturedQueries"]==921445
assert nvidia["boundaryQueries"]==intel["boundaryQueries"]==2304
assert nvidia["source"]["queries.bin"]=="a4481f88757b231cb8ae7b109b6658e9398de862e48c83bee7ed12fd42ee7dd2"
assert nvidia["relativeNetChange"]>0 and intel["relativeNetChange"]<0
ranks=sorted(profile_result["passTimings"],key=lambda x:x["averageMs"],reverse=True)
assert len(ranks)==19 and all(p["samples"]==1200 for p in ranks)
assert [row["name"] for row in ranks[:2]]==["character-main","character-opaque-depth"]
share=sum(row["averageMs"] for row in ranks[:2])/profile_result["totalAverageMs"]
target = root/"docs/acceptance/nr/evidence/2026-11-14/joint-gpu-pass-budget"
target.mkdir(exist_ok=True,parents=True)
bundle=target/"validation.zip"
groups=[
    ("pass", profile, ("command.json","environment.json","timing.json","timing.csv","player.log","results.json","run.py")),
    ("range", probe, ("range.comp","range.cpp","prepare.py","run.py","nvidia.json","intel.json","nvidia-summary.json","intel-summary.json",
                      "nvidia.log","intel.log","archive.py")),
]
with ZipFile(bundle,"w",ZIP_DEFLATED) as archive:
    for prefix,folder,names in groups:
        for name in names:
            archive.write(folder/name,f"{prefix}/{name}")
with ZipFile(bundle) as archive:
    assert archive.testzip() is None
    for prefix,folder,names in groups:
        assert all(archive.read(f"{prefix}/{name}")== (folder/name).read_bytes() for name in names)
    members=len(archive.namelist())
result={"profile":profile_result,"dominantPassShare":share,"rankedPasses":ranks,"rangeFixture":{"nvidia":nvidia,"intel":intel},
        "rangePrototypePromoted":False,"archiveMembers":members,"archiveSha256":hashlib.sha256(bundle.read_bytes()).hexdigest()}
(target/"results.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(share,members,result["archiveSha256"])
