from pathlib import Path
import json
import os
import re
import subprocess
import sys

task = Path(__file__).resolve().parent
root = Path.cwd().resolve()
candidate_run = Path(sys.argv[1])
previous = Path(sys.argv[2])
placement = Path("D:/Projects/FYP-worktrees/nr-integration-verified/Project/AzureRender")
build = placement / "build/catalog-computed"
sys.path.insert(0, str(placement / "tools"))
from build_provenance import digest, verify
from gpu_environment import RunEnvironmentMonitor, wait_and_record
receipt = json.loads((candidate_run/"candidate-receipt.json").read_bytes())
base_proof = Path(receipt["baseReceiptPath"])
assert digest(base_proof) == receipt["baseReceiptSha256"]
base = json.loads(base_proof.read_bytes())
def verify_candidate():
    verify(placement, base)
    assert all(digest(Path(file)) == value for file,value in receipt["inputsAndProducts"].items())
verify_candidate()
known = json.loads((previous/"command.json").read_bytes())
assert known["frozenInputCount"] == 1729
cmd = known["command"].copy()
cmd[cmd.index("--smoke-frames")+1] = "1200"
cmd += ["--gpu-pass-timing"]
report=task/"timing.json"
cmd[cmd.index("--gpu-timing-output")+1] = str(report)
env = dict(os.environ, VK_LOADER_DRIVERS_SELECT="*nv-vk64*", DOTNET_ROOT="D:/Tools/dotnet9",
           AZURE_DIAGNOSTIC_NONLOCAL_TEXTURES="1")
env["PATH"] = os.pathsep.join((str(build),str(root/"build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin"),env["PATH"]))
for key in ("VK_DRIVER_FILES", "VK_ICD_FILENAMES", "VK_INSTANCE_LAYERS", "VK_LAYER_VALIDATE_SYNC", "VK_LOADER_DEBUG",
            "VK_LAYER_ENABLES", "AZURE_CPU_WORK_REPORT", "AZURERENDER_RESOURCE_ROOT", "AZURE_DISABLE_COMPUTED_MATERIAL_VIEW"):
    env.pop(key, None)
(task/"command.json").write_text(json.dumps(dict(known,command=cmd,scope="bounded pass timestamps"),indent=2)+"\n",encoding="utf-8")
environment_path=task/"environment.json"
environment=wait_and_record(environment_path,timeout=120)
with RunEnvironmentMonitor(environment,path=environment_path,interval=2),(task/"player.log").open("wb") as log:
    subprocess.run(cmd,cwd=placement,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=580)
line=(task/"player.log").read_text(errors="replace")
bytes_by_image=[int(value) for value in re.findall(r"Nonlocal material image .* bytes=(\d+)",line)]
assert sum(bytes_by_image)==1588625408 and len(bytes_by_image)==224
assert "Allocator after unload: buffers=0 images=0" in line
data=json.loads(report.read_bytes())
assert data["samples"]==1200 and (data["sceneWidth"],data["sceneHeight"])==(1920,1080)
assert data["computedMaterialViewSelectionsTotal"]>0
assert data["gpuPassTimings"], "No registered graph pass measurements"
samples=environment["startup"]+environment["runObservations"]+[environment["final"]]
assert all(row["driver"]=="595.79" for row in samples)
verify_candidate()
result={"passTimings":data["gpuPassTimings"],"totalAverageMs":data["totalAverageMs"],"totalP95Ms":data["totalP95Ms"],
        "softwareThermalSamples":sum(row["thermalSlowdown"]["software"] for row in samples),
        "scope":"1200-frame pass localization; graph timestamp instrumentation enabled"}
(task/"results.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result),flush=True)
