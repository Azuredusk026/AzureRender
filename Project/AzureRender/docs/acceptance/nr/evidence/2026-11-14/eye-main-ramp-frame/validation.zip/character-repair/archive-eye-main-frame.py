from hashlib import file_digest,sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile
import json
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
repo=root.parents[2]
destination=repo/'docs/acceptance/nr/evidence/2026-11-14/eye-main-ramp-frame'
head_plane=destination.parent/'iris-main-ramp-head-plane/results.json'
read=lambda p:json.loads(p.read_bytes())
def digest(p):
    with p.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()

player=digest(root/'msaa-release/AzurePlayer.exe')
members={}
def add(source,name):
    assert source.is_file() and name not in members,(source,name)
    members[name]=source
def files(source,prefix,names):
    for name in names:add(source/name,f'{prefix}/{name}')

cpu=ET.parse(root/'iris-main-frame-green.xml').getroot()
test,=list(cpu.iter('testcase'))
assert test.attrib['name']=='AzureRender.CharacterRepair' and test.find('failure') is None and test.find('skipped') is None
files(root,'character-repair',('iris-main-frame-red.xml','iris-main-frame-green.xml','eye-native-public-frame.py','archive-eye-main-frame.py'))
add(repo/'tools/test_eye_npr_gpu.py','eye-npr/test_eye_npr_gpu.py')
devices={}
for device,token,expected in (('nvidia','NVIDIA',[52,22]),('intel','Intel',[56,30])):
    device_row={}
    suite=root/f'eye-npr-suite-{device}'
    confidence=read(suite/'summary.json')
    assert confidence['status']=='passed' and confidence['playerSha256']==player
    assert len(confidence['captures'])==17 and confidence['maximumLinearError']<=.008
    assert confidence['frameProjectionSeparation'][0]>.015 and confidence['frameProjectionSeparation'][2]<=.008
    files(suite,f'{device}/npr-suite',('summary.json',))
    device_row['nprSuite']={k:confidence[k] for k in ('maximumLinearError','frameProjectionSeparation','frameCaptureSequences','mipChangedPixels')}
    device_row['nprSuite']['cases']=len(confidence['captures'])
    for use in ('animated','control'):
        name='main-frame-'+use
        trial=suite/name
        caps=read(trial/'frames/gpu_capabilities.json')
        capture=next(item for item in confidence['captures'] if item['name']==name)
        assert token.casefold() in caps['device_name'].casefold()
        assert digest(trial/'frames/frame_000001.png')==capture['imageSha256']
        files(trial,f'{device}/npr-suite/{name}',('plane.gltf','level.azurelevel','lab.azureproject','runtime.json','player.log',
            'base.png','ramp.png','matcap.png','frames/capture_manifest.json','frames/gpu_capabilities.json',
            'frames/frame_000000.png','frames/frame_000001.png','frames/frame_000002.png'))
    for index,variant in enumerate(('baseline','projected')):
        case=root/f'eye-native-public-{device}-{variant}'
        result=read(case/'results.json')
        caps=read(case/'frames/gpu_capabilities.json')
        assert token.casefold() in caps['device_name'].casefold()
        assert result['playerSha256']==player and result['frameSha256']==digest(case/'frames/frame_000000.png')
        assert result['expectedFrameDifference']==result['outsideIrisDifference']==0 and result['irisOverOne']==expected[index]
        device_row[variant]=result
        files(case,f'{device}/native/{variant}',('results.json','command.json','player.log','runtime.json',
            'frames/capture_manifest.json','frames/gpu_capabilities.json'))
        if variant=='projected':
            for source in sorted(case.glob('face-iris-public-main-frame.*')):
                add(source,f'{device}/native/{variant}/{source.name}')
    devices[device]=device_row

assert not destination.exists()
destination.mkdir()
archive=destination/'validation.zip'
with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as out:
    for name,path in sorted(members.items()):out.write(path,name)
with ZipFile(archive) as out:
    assert out.testzip() is None and set(out.namelist())==set(members)
    checks={name:sha256(out.read(name)).hexdigest() for name in sorted(members)}
    assert all(digest(path)==checks[name] for name,path in members.items())
result=dict(schemaVersion=1,overallStatus='failed-user-review',playerSha256=player,
    staticSourceResultsSha256=digest(head_plane),devices=devices,archiveSha256=digest(archive),archiveEntries=checks)
(destination/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(destination,len(members),result['archiveSha256'])
