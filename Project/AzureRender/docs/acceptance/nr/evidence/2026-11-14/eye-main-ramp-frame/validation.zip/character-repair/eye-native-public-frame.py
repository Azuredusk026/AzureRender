from hashlib import file_digest
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5
import json
import os
import runpy
import sys

import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
diagnostic=out.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
old=out.parent/'20261114-051632-face-local-radial-light-retest-ea8fb6'
fixture=grid/'iris-overlay-geometry-project'
helper=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read,dump,invoke=(helper[k] for k in ('read','dump','invoke'))
scorer=runpy.run_path(str(grid/'static-quality.py'))
def digest(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()

device,variant=sys.argv[1:]
assert device in ('nvidia','intel') and variant in ('baseline','projected')
lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==out
qualification=out.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e'/f'iris-actual-{device}-scene-head-frame'
qualified=read(qualification/'results.json')
assert digest(qualification/'frames/frame_000000.png')==qualified['frameSha256']
name='face-iris-public-main-frame'
src='face-native-radial-local-production'
folder=out/f'eye-native-public-{device}-{variant}'
folder.mkdir()
links=[]
if variant=='projected':
    level=read(fixture/'scene'/f'{src}.azurelevel')
    slots=next(n for n in level['nodes'] if n['id']=='hero')['materialSlots']
    eye='name:M_actor_laevat_iris_01'
    assert slots[eye]=='f919b7a6-ca12-5772-b0e2-83cd5b5a046a'
    materials=fixture/'materials'
    source=materials/(slots[eye]+'.azurematerial')
    if not source.is_file():
        sidecar,=[p for p in materials.glob('*.azurematerial.azmeta') if read(p)['id']==slots[eye]]
        source=sidecar.with_suffix('')
    material=read(source)
    face=read(materials/f'{src}.azurematerial')['surface']['materials'][0]['extras']['azureRenderMaterial']['faceSdf']
    assert face['headNode']=='capture_material_frame_10401'
    eye_lighting=material['surface']['materials'][0]['extras']['azureRenderMaterial']['eyeSurface']['lightingInputs']
    assert 'mainRampFrame' not in eye_lighting and eye_lighting['illuminationModel']=='npr-main-ambient'
    eye_lighting['mainRampFrame']=dict(schemaVersion=1,node=face['headNode'],basis=face['headBasis'])
    slots[eye]=str(uuid5(NAMESPACE_URL,'azurerender/'+name+'/iris'))
    document=read(fixture/f'{src}.azureproject');document['startupScene']=f'stage:/{name}.azurelevel'
    for path,data in ((f'materials/{name}.azurematerial',material),
        (f'materials/{name}.azurematerial.azmeta',dict(schemaVersion=1,id=slots[eye],dependencies=[],settings={})),
        (f'scene/{name}.azurelevel',level),(f'{name}.azureproject',document)):
        staged=folder/Path(path).name;dump(staged,data);links.append((fixture/path,staged))
build=out/'msaa-release'
cmd=read(old/f'production-{device}-enabled/command.json');cmd[0]=str(build/'AzurePlayer.exe')
for flag,value in (('--capture-dir',folder/'frames'),('--resource-root',build),
    ('--project',fixture/(f'{name}.azureproject' if variant=='projected' else f'{src}.azureproject'))):
    cmd[cmd.index(flag)+1]=str(value)
cmd+=['--runtime-report',str(folder/'runtime.json')]
try:
    for target,staged in links:target.hardlink_to(staged)
    frame=invoke(device,cmd,folder)/'frame_000000.png'
finally:
    for target,staged in reversed(links):
        if target.is_file() and os.path.samefile(target,staged):target.unlink()
with Image.open(grid/'native-face-masks/iris.png') as m:mask=np.asarray(m.convert('L'))>0
image=lambda p:scorer['image'](p).astype('i2')
control,source,actual,candidate=[image(p) for p in (old/f'production-{device}-enabled/frames/frame_000000.png',
    scorer['reference_path'],frame,qualification/'frames/frame_000000.png')]
expected=control if variant=='baseline' else candidate
error=np.abs(actual-source).max(2)
delta=np.abs(actual-expected).max(2)
report=dict(device=device,variant=variant,frameSha256=digest(frame),playerSha256=digest(Path(cmd[0])),
    irisOverOne=int((error[mask]>1).sum()),irisOverEight=int((error[mask]>8).sum()),irisPeak=int(error[mask].max()),
    expectedFrameDifference=int((delta>0).sum()),expectedFramePeak=int(delta.max()),
    outsideIrisDifference=int((np.any(actual!=control,axis=2)&~mask).sum()))
dump(folder/'results.json',report)
print(json.dumps(report))
assert report['expectedFrameDifference']==0,report
