from hashlib import sha256
from pathlib import Path
import json
from zipfile import ZipFile,ZIP_DEFLATED

root=Path.cwd()
out=Path(__file__).resolve().parent
source=root/"docs/acceptance/nr/evidence/2026-11-14/joint-59579-qualification/results.json"
raw=json.loads((out/"usage.json").read_bytes())
feedback=json.loads((out/"usage-feedback.json").read_bytes())
assert raw["status"]==feedback["status"]=="inventory"
assert raw["entries"]==feedback["entries"] and len(raw["entries"])==364
none={row["resource"]:row for row in raw["entries"] if not row["usageEvents"]}
events=feedback["exampleDynamicAccesses"]
seen={v["resource"] for event in events for v in event["boundMaterialTextureWitnesses"] if not v["staticUsageEvents"]}
missing=sum(row["textureBytes"] for row in none.values())
witness_bytes=sum(none[key]["textureBytes"] for key in seen)
remaining=missing-witness_bytes
assert (len(none),len(events),len(seen))==(271,8,19)
assert missing==1252758528 and witness_bytes==158018560 and remaining==1094739968
allocation_gap=json.loads(source.read_bytes())["capacityEnvelope"]["peakOverLimitBytes"]
assert remaining < allocation_gap
report={
    "sourceCaptureSha256":raw["sourceCaptureSha256"],
    "sourceBase":"73300ab",
    "captureFrame":320,
    "captureResolution":[1280,720],
    "renderDocVersion":"1.46",
    "scope":"single captured frame, eligible 2D mipmapped sampled image inventory",
    "inventory":raw["summary"],
    "descriptorFeedbackEventCount":len(events),
    "missingStaticUsageWitnesses":sorted(seen),
    "missingStaticUsageWitnessBytes":witness_bytes,
    "remainingStaticNoEventTextureBytesAfterWitnesses":remaining,
    "observedJointDeviceLocalAllocationGapBytes":allocation_gap,
    "comparisonShortfallBytes":allocation_gap-remaining,
    "comparisonScope":"Logical capture image bytes. Counterexample to selecting whole images by missing static usage, independently of allocation page granularity.",
    "quantifiesUnusedMipOrPages":False,
    "productionCandidate":False,
}
dest=root/"docs/acceptance/nr/evidence/2026-11-14/joint-texture-usage"
dest.mkdir(parents=True,exist_ok=True)
package=dest/"validation.zip"
members=["scan.py","run.py","scan_feedback.py","run_feedback.py","fix_scan.py","prepare_feedback.py",
         "first-usage.json","first-process.log","usage.json","usage-feedback.json","process.log","replay.log","replay-feedback.log","archive.py"]
with ZipFile(package,"w",ZIP_DEFLATED) as archive:
    for item in members:
        archive.write(out/item,item)
with ZipFile(package) as archive:
    assert archive.testzip() is None and all(archive.read(item)==(out/item).read_bytes() for item in members)
report["archiveSha256"]=sha256(package.read_bytes()).hexdigest()
(dest/"results.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps({key:report[key] for key in ("comparisonShortfallBytes","descriptorFeedbackEventCount","archiveSha256")}))
