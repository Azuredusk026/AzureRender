from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
out = Path(__file__).resolve().parent
sys.path.insert(0,str(root/"tools"))
from artifact_maintenance import managed_environment
exe = Path("D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe")
env = dict(os.environ,**managed_environment(out/"tmp"))
info = subprocess.STARTUPINFO()
info.dwFlags |= subprocess.STARTF_USESHOWWINDOW
info.wShowWindow = 0
with (out/"replay.log").open("wb") as log:
    completed = subprocess.run([str(exe),"--python",str(out/"scan.py")],cwd=out,env=env,
             stdout=log,stderr=subprocess.STDOUT,startupinfo=info,timeout=300)
report = json.loads((out/"usage.json").read_bytes())
assert completed.returncode==0 and report["status"]=="inventory",report.get("error",completed.returncode)
print(json.dumps(report["summary"]),flush=True)
