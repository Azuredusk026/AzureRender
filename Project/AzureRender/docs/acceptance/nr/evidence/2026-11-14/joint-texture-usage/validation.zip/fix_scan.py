from pathlib import Path
import sys

root = Path(sys.argv[1])
path = root / "scan.py"
source = path.read_text(encoding="utf-8-sig")
source = source.replace("start = time.monotonic()",'''start = time.monotonic()

def sha256(stream):
    hash = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b""):
        hash.update(block)
    return hash.hexdigest()
''')
source = source.replace('hashlib.file_digest(stream, "sha256").hexdigest()', 'sha256(stream)')
path.write_text(source, encoding="utf-8")
(root / "first-usage.json").write_bytes((root / "usage.json").read_bytes())
(root / "first-process.log").write_bytes((root / "process.log").read_bytes())
