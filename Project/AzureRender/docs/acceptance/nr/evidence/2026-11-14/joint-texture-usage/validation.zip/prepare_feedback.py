from pathlib import Path
import sys
root=Path(sys.argv[1])
filename=root/"scan.py"
s=filename.read_text(encoding="utf-8")
s=s.replace('    report.update(status="inventory", summary=', '''    all_ids = {entry["resource"]:entry for entry in entries}
    registered_events = [17563, 23277]
    actions = {}
    def walk(items):
        for action in items:
            actions[action.eventId]=action
            walk(action.children)
    walk(controller.GetRootActions())
    chosen = [event for event in registered_events if event in actions]
    first_known = next((event for event in sorted(actions) if actions[event].flags & rd.ActionFlags.Drawcall and actions[event].numIndices > 0), None)
    if first_known and first_known not in chosen:
        chosen.insert(0,first_known)
    dynamic=[]
    for event in chosen:
        controller.SetFrameEvent(event,False)
        resources=controller.GetPipelineState().GetReadOnlyResources(rd.ShaderStage.Pixel,True)
        captured = []
        for use in resources:
            resource=str(use.descriptor.resource)
            if resource in all_ids:
                captured.append({"resource":resource, "staticUsageEvents":all_ids[resource]["usageEvents"],
                                 "arrayElement":use.access.arrayElement})
        dynamic.append({"event":event,"boundMaterialTextureWitnesses":captured})
    report["exampleDynamicAccesses"]=dynamic
    report.update(status="inventory", summary=''')
s=s.replace('out / "usage.json"','out / "usage-feedback.json"')
filename=(root/"scan_feedback.py")
filename.write_text(s,encoding="utf-8")
source=(root/"run.py").read_text(encoding="utf-8-sig")
source=source.replace('"scan.py"','"scan_feedback.py"').replace('"usage.json"','"usage-feedback.json"').replace('"replay.log"','"replay-feedback.log"')
(root/"run_feedback.py").write_text(source,encoding="utf-8")
