from collections import Counter
from pathlib import Path
import hashlib
import json
import sys
import time
import traceback

import renderdoc as rd

root = Path(r"D:/Projects/FYP/Project/AzureRender")
out = Path(r"D:/Projects/FYP/Project/AzureRender/build/runs/20261114-024012-nr-texture-use-inventory-0e4291")
source = root / "build/runs/20261111-001050-quad-feature-device-capture-4798d1/state.json"
reference = root / "build/runs/20261111-013339-resident-srgb-channel-scope-00a65e/texture-inventory.json"
state = json.loads(source.read_bytes())
report = {"status":"starting", "sourceCaptureSha256":state["captureSha256"],
          "scope":"RenderDoc usage records for captured 2D single-layer mipmapped color images"}
cap = controller = None
start = time.monotonic()

def sha256(stream):
    hash = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b""):
        hash.update(block)
    return hash.hexdigest()

try:
    capture = Path(state["capture"])
    with capture.open("rb") as stream:
        assert sha256(stream) == state["captureSha256"]
    with reference.open("rb") as stream:
        report["historicalInventorySha256"] = sha256(stream)
    historical = {row["resource"]:row for row in json.loads(reference.read_bytes())}
    cap = rd.OpenCaptureFile()
    assert cap.OpenFile(str(capture),"",None) == rd.ResultCode.Succeeded
    status, controller = cap.OpenCapture(rd.ReplayOptions(), None)
    assert status == rd.ResultCode.Succeeded
    ranges = {"R8G8B8A8_SRGB":4, "R8G8B8A8_UNORM":4, "R8G8_UNORM":2, "R8_UNORM":1}
    entries = []
    for image in controller.GetTextures():
        name = str(image.resourceId)
        row = historical[name]
        fmt = image.format.Name()
        if fmt not in ranges or not row["name"].startswith("2D Image ") or image.mips <= 1 or image.arraysize != 1 or image.msSamp != 1:
            continue
        assert (image.width,image.height,image.mips,fmt) == (row["width"],row["height"],row["mips"],row["format"])
        usage = controller.GetUsage(image.resourceId)
        kinds = Counter(str(item.usage).split(".")[-1] for item in usage)
        entries.append({"resource":name,"textureBytes":row["bytes"],"topMipTexelBytes":image.width*image.height*ranges[fmt],
                        "usageEvents":len(usage),"usageKinds":dict(kinds)})
    assert len(entries)==364
    all_kinds=Counter()
    for e in entries: all_kinds.update(e["usageKinds"])
    report.update(status="inventory", summary={"resources":len(entries), "kinds":dict(all_kinds),
                    "noRecordedEvents":sum(e["usageEvents"]==0 for e in entries),
                    "noRecordedEventsTextureBytes":sum(e["textureBytes"] for e in entries if e["usageEvents"]==0)},
                  entries=entries)
except Exception:
    report.update(status="failed", error=traceback.format_exc())
finally:
    if controller:
        controller.Shutdown()
    if cap:
        cap.Shutdown()
    report["seconds"]=time.monotonic()-start
    (out / "usage.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
sys.exit(0 if report["status"]=="inventory" else 2)
