from pathlib import Path
import hashlib
import json
import sys
from zipfile import ZIP_DEFLATED,ZipFile

root=Path.cwd()
run=Path(__file__).resolve().parent
fixture=Path(sys.argv[1])
replay=Path(sys.argv[2])
def read(path):
    return json.loads(path.read_bytes())
target=root/"docs/acceptance/nr/evidence/2026-11-14/joint-shadow-single-range-table"
target.mkdir(parents=True,exist_ok=True)
package=target/"validation.zip"
proof=read(run/"build-receipt.json")
assert len(proof["shaderCommands"])==774
assert sum(1 for name in proof["products"] if name.endswith(".spv"))==1024
exact={}
for name in ("nvidia","intel"):
    exact[name]=read(fixture/(name+"-summary.json"))
    assert exact[name]["allResultsBitExact"]
    assert exact[name]["capturedQueries"]+exact[name]["boundaryQueries"]==923749
freeze=read(replay/"preflight.json")
assert freeze["frozenInputCount"]==1729 and freeze["currentDriver"]=="595.79" and freeze["frozenDriver"]=="592.82"
visual=read(run/"four/results.json") if (run/"four/results.json").is_file() else None
short=read(run/"short-results.json") if (run/"short-results.json").is_file() else None
paths={}
def files(prefix,base,names):
    for name in names:
        path=base/name
        if path.is_file():
            paths[f"{prefix}/{name}"]=path
files("fixture",fixture,("run.py","range.cpp","range.comp","prepare.py","nvidia.json","intel.json","nvidia-summary.json","intel-summary.json","process.log"))
files("candidate",run,("prepare.py","compile.rsp","link.rsp","compile.log","mesh.frag","shadow_bounds.comp","include/render/ShadowTileBounds.hpp",
                     "build.py","build-receipt.json","capture.py","compare.py","validate.py","short-results.json","process.log","archive.py",
                     "first-validation-process.log","debug-contracts.xml","release-contracts.xml","assess.py","decision.json"))
files("candidate/four",run/"four",("results.json","command.json","timing.csv","timing.json","environment.json","player.log"))
files("candidate/first-validation",run/"first-validation",("command.json","timing.csv","environment.json","player.log"))
for name in ("short-local-before","short-range","short-local-after"):
    files("candidate/"+name,run/name,("results.json","command.json","timing.csv","timing.json","environment.json","player.log"))
files("native-replay-preflight",replay,("preflight.json","replay_frozen.py","verify_frozen_binary.py","frozen-binary-scan.json"))
with ZipFile(package,"w",ZIP_DEFLATED) as z:
    for name,path in paths.items():
        z.write(path,name)
with ZipFile(package) as z:
    assert z.testzip() is None and set(z.namelist())==set(paths)
    assert all(z.read(name)==path.read_bytes() for name,path in paths.items())
assert package.stat().st_size <= 8*1024*1024
result = {"fixture":exact,"compiledVariants":len(proof["shaderCommands"]),"sourceBase":proof["sourceBase"],
          "nativeFour59579":visual,"short1080p":short,"matched59282Run":False,
          "decision":read(run/"decision.json"),"frozenProducerSearch":read(replay/"frozen-binary-scan.json"),
          "archiveMembers":len(paths),"archiveSha256":hashlib.sha256(package.read_bytes()).hexdigest()}
(target/"results.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(result["archiveMembers"],result["archiveSha256"],flush=True)
