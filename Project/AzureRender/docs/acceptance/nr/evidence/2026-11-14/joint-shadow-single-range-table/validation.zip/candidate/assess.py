from pathlib import Path
from statistics import mean
import json

run=Path(__file__).resolve().parent
a,b,c=json.loads((run/"short-results.json").read_bytes())
assert all(row["allocationCount"]==224 and row["deviceLocalPeakBytes"]==1442503488 and row["sampled"]==60 for row in (a,b,c))
assert all(row["powerLimits"]==[80] and row["softwareThermalObservations"]==0 for row in (a,b,c))
middle=mean(row["gpuFrameMs"]["mean"] for row in (a,c))
reduction=middle-b["gpuFrameMs"]["mean"]
cpuControl=abs(a["cpuMs"]["p95"]-c["cpuMs"]["p95"])
decision={"candidateGpuMeanChangeMs":-reduction,"candidateGpuMeanChangePct":-100*reduction/middle,
          "gpuReferenceDriftPct":100*abs(a["gpuFrameMs"]["mean"]-c["gpuFrameMs"]["mean"])/middle,
          "cpuP95ControlSpanMs":cpuControl,"cpuCandidateP95Ms":b["cpuMs"]["p95"],"advanceToFormal":False}
(run/"decision.json").write_text(json.dumps(decision,indent=2)+"\n",encoding="utf-8")
print(decision)
