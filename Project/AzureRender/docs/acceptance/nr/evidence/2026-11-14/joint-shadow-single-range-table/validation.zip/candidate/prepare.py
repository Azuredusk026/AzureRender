from pathlib import Path
import sys

run = Path(__file__).resolve().parent
base = Path(sys.argv[1])
header = (base/"src/render/ShadowTileBounds.hpp").read_text(encoding="utf-8")
reference = "layout_=backend_.createPipelineLayout(setLayout_,nullptr);"
assert header.count(reference)==1
header = header.replace(reference, """const rhi::PushConstantRangeDesc buildStage{VK_SHADER_STAGE_COMPUTE_BIT, sizeof(std::uint32_t)};
            layout_=backend_.createPipelineLayout(setLayout_,&buildStage);""")
reference = "commands.bindComputePipeline(pipeline_);commands.bindComputeDescriptorSet(layout_,set_);commands.dispatch((tiles_+tilesPerGroup_-1)/tilesPerGroup_,tiles_,1);"
assert header.count(reference)==1
header = header.replace(reference, """commands.bindComputePipeline(pipeline_);
        commands.bindComputeDescriptorSet(layout_,set_);
        const std::uint32_t levelZero=0, rectangleTable=1;
        commands.pushConstants(layout_,VK_SHADER_STAGE_COMPUTE_BIT,0,&levelZero,sizeof(levelZero));
        commands.dispatch((tiles_+tilesPerGroup_-1)/tilesPerGroup_,tiles_,1);
        commands.bufferBarrier({buffer_.buffer,0,depthBoundsBytes(),
            VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
            VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});
        commands.pushConstants(layout_,VK_SHADER_STAGE_COMPUTE_BIT,0,&rectangleTable,sizeof(rectangleTable));
        const unsigned lanes=tilesPerGroup_==8?128:16;
        commands.dispatch((tiles_+lanes-1)/lanes,tiles_,1);""")
header = header.replace("VkDeviceSize(tiles_)*tiles_*2*sizeof(float)", "VkDeviceSize(tiles_)*tiles_*4*sizeof(float)")
path = run/"include/render"
path.mkdir(parents=True,exist_ok=True)
(path/"ShadowTileBounds.hpp").write_text(header,encoding="utf-8")

frag = (base/"shaders/mesh.frag").read_text(encoding="utf-8")
old = """    for(int ty=tileLow.y;ty<=tileHigh.y;++ty)for(int tx=tileLow.x;tx<=tileHigh.x;++tx){
        vec2 range=shadowBounds.values[ty*(extent.x/8)+tx];minimumDepth=min(minimumDepth,range.x);maximumDepth=max(maximumDepth,range.y);
    }"""
new = """    ivec2 size=tileHigh-tileLow+1;
    int tilesPerRow=extent.x/8;
    if(all(greaterThanEqual(size,ivec2(3)))&&all(lessThanEqual(size,ivec2(4)))){
        int offset=tilesPerRow*(extent.y/8)+tileLow.y*tilesPerRow+tileLow.x;
        int row=(size.y-3)*tilesPerRow,column=size.x-3;
        vec2 a=shadowBounds.values[offset],b=shadowBounds.values[offset+column];
        vec2 c=shadowBounds.values[offset+row],d=shadowBounds.values[offset+row+column];
        minimumDepth=min(min(a.x,b.x),min(c.x,d.x));
        maximumDepth=max(max(a.y,b.y),max(c.y,d.y));
    }else{
        for(int ty=tileLow.y;ty<=tileHigh.y;++ty)for(int tx=tileLow.x;tx<=tileHigh.x;++tx){
            vec2 range=shadowBounds.values[ty*tilesPerRow+tx];
            minimumDepth=min(minimumDepth,range.x);
            maximumDepth=max(maximumDepth,range.y);
        }
    }"""
assert frag.count(old)==1 and frag.count("objectShadowLoadRecord(uint(extent.x*extent.y)") == 1
frag = frag.replace(old,new).replace("objectShadowLoadRecord(uint(extent.x*extent.y)","objectShadowLoadRecord(2u*uint(extent.x*extent.y)")
(run/"mesh.frag").write_text(frag,encoding="utf-8")
comp = (base/"shaders/shadow_bounds.comp").read_text(encoding="utf-8")
old = "void main(){"
assert comp.count(old)==1
new = """layout(push_constant) uniform BoundsBuild { uint stage; } build;
vec2 mergeShadowBounds(vec2 a, vec2 b) { return vec2(min(a.x,b.x),max(a.y,b.y)); }
vec2 readRow3(ivec2 base,int width){
    int offset=base.y*width;
    vec2 a=result.values[offset+base.x];
    vec2 b=result.values[offset+min(base.x+1,width-1)];
    vec2 c=result.values[offset+min(base.x+2,width-1)];
    return mergeShadowBounds(mergeShadowBounds(a,b),c);
}
void main(){
    if(build.stage!=0u){
        ivec2 grid=textureSize(sourceDepth,0)/8;
        ivec2 tile=ivec2(gl_WorkGroupID.x*gl_WorkGroupSize.x*gl_WorkGroupSize.y+gl_LocalInvocationIndex,
                         gl_WorkGroupID.y);
        if(tile.x>=grid.x || tile.y>=grid.y)return;
        vec2 a=readRow3(tile,grid.x);
        vec2 b=readRow3(ivec2(tile.x,min(tile.y+1,grid.y-1)),grid.x);
        vec2 c=readRow3(ivec2(tile.x,min(tile.y+2,grid.y-1)),grid.x);
        result.values[grid.x*grid.y+tile.y*grid.x+tile.x]=mergeShadowBounds(mergeShadowBounds(a,b),c);
        return;
    }"""
(run/"shadow_bounds.comp").write_text(comp.replace(old,new),encoding="utf-8")
