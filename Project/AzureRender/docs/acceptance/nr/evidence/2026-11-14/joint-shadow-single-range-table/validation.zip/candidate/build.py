from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import os
import re
import shutil
import subprocess
import sys

root=Path.cwd().resolve()
run=Path(__file__).resolve().parent
source=Path(sys.argv[1])
previous=Path(sys.argv[2])
build=source/"build/catalog-computed"
sys.path.insert(0,str(source/"tools"))
from build_provenance import digest,verify
previous_receipt=json.loads((previous/"candidate-receipt.json").read_bytes())
base_path=Path(previous_receipt["baseReceiptPath"])
assert digest(base_path)==previous_receipt["baseReceiptSha256"]
base=json.loads(base_path.read_bytes())
verify(source,base)
assert all(digest(Path(path))==sha for path,sha in previous_receipt["inputsAndProducts"].items())
ninja=build/"build.ninja"
source_text=ninja.read_text(encoding="utf-8")
commands=[]
for line in source_text.splitlines():
    if not line.startswith("  COMMAND = ") or "glslc.exe " not in line:
        continue
    section=line.split("glslc.exe ",1)[1].split(" && ",1)[0]
    parts=section.split()
    if len(parts)>3 and parts[-2]=="-o" and Path(parts[-3]).name in ("mesh.frag","shadow_bounds.comp"):
        options=parts[:-3]
        if "-MD" in options:
            index=options.index("-MD")
            assert options[index+1]=="-MF"
            options=options[:index]+options[index+3:]
        commands.append((options,Path(parts[-3]),Path(parts[-1]).name))
assert len(commands)>200
assert len({row[2] for row in commands})==len(commands)
shader_out=run/"shaders"
shader_out.mkdir(exist_ok=True)
source_files={name.name:name for _,name,_ in commands}
compiler=Path("D:/Tools/VulkanSDK/1.4.350.0/Bin")
constants=set()
for opts,_,_ in commands:
    constants.update(opt for opt in opts if opt.startswith(("-f","-D","-I")))
changed_names={row[2] for row in commands}
for path in (build/"shaders").glob("*.spv"):
    if path.name not in changed_names and not (shader_out/path.name).exists():
        os.link(path,shader_out/path.name)
def compile_shader(row):
    options, origin, name = row
    out=shader_out/name
    out.unlink(missing_ok=True)
    shader=run/origin.name
    cmd=[str(compiler/"glslc.exe"),*options,"-I"+str(origin.parent),str(shader),"-o",str(out)]
    result=subprocess.run(cmd,cwd=build,capture_output=True,text=True,timeout=90)
    assert result.returncode==0,(name,result.stdout,result.stderr)
    validated=subprocess.run([str(compiler/"spirv-val.exe"),"--target-env","vulkan1.3","--relax-block-layout",str(out)],capture_output=True,text=True,timeout=45)
    assert validated.returncode==0,(name,validated.stderr)
    return {"name":name,"command":cmd,"sha256":digest(out)}
with ThreadPoolExecutor(max_workers=4) as pool:
    shaders=list(pool.map(compile_shader,commands))
lines=source_text.splitlines()
index=next(i for i,line in enumerate(lines) if line.startswith("build CMakeFiles") and "CharacterSceneRenderer.cpp.obj:" in line)
player_index=next(i for i,line in enumerate(lines) if line.startswith("build AzurePlayer.exe:"))
def variables(row,count):
    return dict(item.strip().split(" = ",1) for item in lines[row+1:row+1+count])
compile_flags=variables(index,6)
link_flags=variables(player_index,11)
env=dict(os.environ,VULKAN_SDK="D:/Tools/VulkanSDK/1.4.350.0",VCPKG_ROOT="D:/Tools/vcpkg")
overlay_object=run/"CharacterSceneRenderer.obj"
previous_object=previous/"GpuAllocator.obj"
assert previous_receipt["inputsAndProducts"][str(previous_object)]==digest(previous_object)
def tracked_command(label,program,arguments):
    response=run/(label+".rsp")
    response.write_text(arguments+"\n",encoding="utf-8")
    with (run/(label+".log")).open("wb") as log:
        subprocess.run([str(root/"tools/msvc_env.bat"),program,"@"+str(response)],cwd=build,env=env,
                       stdout=log,stderr=subprocess.STDOUT,check=True)
    return response
compile_rsp=tracked_command("compile","cl.exe",
    f'/nologo /c {compile_flags["DEFINES"]} {compile_flags["FLAGS"]} /I"{run/"include"}" {compile_flags["INCLUDES"]} '
    f'/Fo"{overlay_object}" "{source/"src/scenes/CharacterSceneRenderer.cpp"}"')
player=run/"AzurePlayer.exe"
map_path=run/"link.map"
main_obj=lines[player_index].split(" | ",1)[0].split()[-1]
link_rsp=tracked_command("link","link.exe",
    f'/nologo "{main_obj}" "{overlay_object}" "{previous_object}" /out:"{player}" /MAP:"{map_path}" '
    f'/MANIFEST:EMBED /MANIFESTINPUT:"{link_flags["MANIFESTS"]}" {link_flags["LINK_FLAGS"]} {link_flags["LINK_LIBRARIES"]}')
symbols=[]
for line in map_path.read_text(errors="replace").splitlines():
    parts=line.split()
    if len(parts)>1 and (parts[1].startswith("?createImage@GpuAllocator@") or parts[1].startswith("?recordOverlayDepth@CharacterSceneRenderer@")):
        symbols.append(line.strip())
assert len(symbols)==2 and any(line.endswith("GpuAllocator.obj") for line in symbols)
assert any(line.endswith("CharacterSceneRenderer.obj") for line in symbols)
verify(source,base)
proof={"baseReceiptPath":str(base_path),"baseReceiptSha256":digest(base_path),
       "nonlocalReceiptPath":str(previous/"candidate-receipt.json"),"nonlocalReceiptSha256":digest(previous/"candidate-receipt.json"),
       "sourceBase":base["commit"],"shaderCommands":shaders,"linkSymbols":symbols}
proof["products"]={str(path):digest(path) for path in [ninja,compile_rsp,link_rsp,overlay_object,player,previous_object,
    run/"mesh.frag",run/"shadow_bounds.comp",run/"include/render/ShadowTileBounds.hpp",*shader_out.glob("*.spv")]}
assert len(list(shader_out.glob("*.spv")))==len(list((build/"shaders").glob("*.spv")))
(run/"build-receipt.json").write_text(json.dumps(proof,indent=2)+"\n",encoding="utf-8")
print(len(shaders),"validated variants and",len(proof["products"]),"digests",flush=True)
