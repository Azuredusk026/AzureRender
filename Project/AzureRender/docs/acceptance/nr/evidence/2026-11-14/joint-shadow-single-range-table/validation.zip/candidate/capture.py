from pathlib import Path
import json
import os
import subprocess
import sys
from zipfile import ZipFile

import numpy as np
from PIL import Image

root = Path.cwd().resolve()
run = Path(__file__).resolve().parent
source = Path(sys.argv[1])
base = Path(sys.argv[2])
build = source/"build/catalog-computed"
sys.path.insert(0,str(source/"tools"))
from build_provenance import digest,verify
from gpu_environment import RunEnvironmentMonitor,snapshot

receipt = json.loads((run/"build-receipt.json").read_bytes())
base_path = Path(receipt["baseReceiptPath"])
assert digest(base_path)==receipt["baseReceiptSha256"]
source_proof=json.loads(base_path.read_bytes())
def verify_products():
    verify(source,source_proof)
    assert digest(Path(receipt["nonlocalReceiptPath"]))==receipt["nonlocalReceiptSha256"]
    assert all(digest(Path(path))==sha for path,sha in receipt["products"].items())

verify_products()
scope=root/"docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope/validation.zip"
with ZipFile(scope) as archive:
    project_inputs=json.loads(archive.read("run/frozen-project-inputs.json"))
assert len(project_inputs)==1729 and all(digest(Path(path))==sha for path,sha in project_inputs.items())
cmd=json.loads((base/"original-four/command.json").read_bytes())["command"]
out=run/"four"
if (out/"player.log").exists():
    raise FileExistsError("Move the completed diagnostic into the run's retry evidence first")
out.mkdir(exist_ok=True)
cmd[0]=str(run/"AzurePlayer.exe")
cmd[cmd.index("--resource-root")+1]=str(run)
for option,target in (("--capture-dir",out/"frames"),("--runtime-report",out/"runtime.json"),("--gpu-timing-output",out/"timing.json")):
    cmd[cmd.index(option)+1]=str(target)
env=dict(os.environ,VK_LOADER_DRIVERS_SELECT="*nv-vk64*",VK_LAYER_PATH="D:/Tools/VulkanSDK/1.4.350.0/Bin",
         VK_INSTANCE_LAYERS="VK_LAYER_KHRONOS_validation",VK_LAYER_VALIDATE_SYNC="1",
         DOTNET_ROOT="D:/Tools/dotnet9",AZURE_DIAGNOSTIC_NONLOCAL_TEXTURES="1")
env["PATH"]=os.pathsep.join((str(build),str(root/"build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin"),env["PATH"]))
for key in ("VK_DRIVER_FILES","VK_ICD_FILENAMES","VK_LAYER_ENABLES","VK_LOADER_DEBUG","AZURE_CPU_WORK_REPORT",
            "AZURERENDER_RESOURCE_ROOT","AZURE_DISABLE_COMPUTED_MATERIAL_VIEW"):
    env.pop(key,None)
(out/"command.json").write_text(json.dumps({"command":cmd,"receiptSha256":digest(run/"build-receipt.json"),
    "source":receipt["sourceBase"],"vkSyncValidation":True},indent=2)+"\n",encoding="utf-8")
start=snapshot()
assert start["driver"]=="595.79" and start["hostPower"]["acLineStatus"]==1
evidence={"startup":[start]}
with RunEnvironmentMonitor(evidence,path=out/"environment.json",interval=2),(out/"player.log").open("wb") as log:
    subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
log=(out/"player.log").read_text(errors="replace")
assert "Allocator after unload: buffers=0 images=0" in log
assert not any(marker in log for marker in ("Validation Error:", "Validation Warning:", "SYNC-HAZARD", "VUID-"))
timing=json.loads((out/"timing.json").read_bytes())
assert timing["computedMaterialViewSelectionsTotal"]==2816
assert timing["shadowBoundsTilesPerGroup"]==8
receipts=json.loads((base/"original-four/results.json").read_bytes())
frozen=root/"build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames"
result={"frames":[],"deviceLocalPeakBytes":timing["allocator"]["deviceLocalPeakBytes"],"validationClean":True}
for reference in receipts["frames"]:
    name=reference["name"]
    path=out/"frames"/name
    first=base/"original-four/frames"/name
    assert digest(first)==reference["sha256"] and digest(frozen/name)==reference["expected"]
    with Image.open(path) as image, Image.open(first) as current, Image.open(frozen/name) as historical:
        observed=np.asarray(image.convert("RGB"),dtype=np.int16)
        current_error=np.abs(observed-np.asarray(current.convert("RGB"),dtype=np.int16))
        public_error=np.abs(observed-np.asarray(historical.convert("RGB"),dtype=np.int16))
    result["frames"].append({"name":name,"actualSha256":digest(path),"sameDriverSha256":reference["sha256"],
        "sameDriverChangedPixels":int(np.count_nonzero(np.any(current_error,axis=2))),"sameDriverMaximumError":int(current_error.max()),
        "frozenPixels":int(np.count_nonzero(np.any(public_error,axis=2))),"frozenMaximumError":int(public_error.max())})
verify_products()
(out/"results.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
assert all(row["sameDriverChangedPixels"]==0 and row["actualSha256"]==row["sameDriverSha256"] for row in result["frames"])
