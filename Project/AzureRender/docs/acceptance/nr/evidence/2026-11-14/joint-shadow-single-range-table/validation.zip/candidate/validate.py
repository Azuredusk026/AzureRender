from pathlib import Path
import json
import subprocess
import sys
import time

run=Path(__file__).resolve().parent
source=Path(sys.argv[1])
base=Path(sys.argv[2])
deadline=time.monotonic()+60
while not (run/"build-receipt.json").is_file():
    if time.monotonic()>=deadline:
        raise RuntimeError("The candidate build receipt is missing")
    time.sleep(1)
subprocess.run([sys.executable,str(run/"capture.py"),str(source),str(base)],check=True,timeout=680)
frames=json.loads((run/"four/results.json").read_bytes())
assert all(row["sameDriverChangedPixels"]==0 for row in frames["frames"])
subprocess.run([sys.executable,str(run/"compare.py"),str(base),str(source)],check=True,timeout=1760)
