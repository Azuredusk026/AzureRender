from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
from statistics import median

work = Path.cwd().resolve()
out = Path(__file__).resolve().parent
source = Path(sys.argv[1])
engine = Path(sys.argv[2])
sys.path.insert(0,str(engine/"tools"))
from build_provenance import digest
receipt = json.loads((source/"range-inputs.json").read_bytes())
bounds=source/"bounds.bin"
queries=source/"queries.bin"
assert digest(bounds)==receipt["boundsSha256"]
assert queries.stat().st_size==receipt["queries"]*16
# Derive the packed query identity separately from the raw attachment digest.
inputs={file.name:digest(file) for file in (bounds,queries,out/"range.comp",out/"range.spv",out/"range.exe")}
for device,mask in (("nvidia","*nv-vk64*"),("intel","*igvk64*")):
    env=dict(os.environ,VK_LOADER_DRIVERS_SELECT=mask,VK_LAYER_PATH="D:/Tools/VulkanSDK/1.4.350.0/Bin")
    env["PATH"]=os.pathsep.join((str(work/"build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin"),env["PATH"]))
    for name in ("VK_DRIVER_FILES","VK_ICD_FILENAMES","VK_INSTANCE_LAYERS","VK_LAYER_ENABLES"):
        env.pop(name,None)
    with (out/(device+".log")).open("wb") as log:
        subprocess.run([str(out/"range.exe"),str(out/"range.spv"),str(bounds),str(queries),str(out/(device+".json"))],
                       cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=150)
    value=json.loads((out/(device+".json")).read_bytes())
    before=median(row["queryMs"] for row in value["samples"] if row["phase"]==0)
    middle=median(row["totalMs"] for row in value["samples"] if row["phase"]==1)
    after=median(row["queryMs"] for row in value["samples"] if row["phase"]==2)
    summary={"source":inputs,"capturedQueries":value["capturedQueries"],"boundaryQueries":value["boundaryQueries"],
             "allResultsBitExact":value["allResultsBitExact"],"referenceBeforeMedianMs":before,
             "candidateWithBuildMedianMs":middle,"referenceAfterMedianMs":after,"buildMedianMs":median(
                 row["buildMs"] for row in value["samples"] if row["phase"]==1),
             "baselineDrift":abs(before-after)/((before+after)/2),"reducedReads":1-value["hierarchyRangeReads"]/value["baseRangeReads"],
             "relativeNetChange":middle/((before+after)/2)-1,"requiredBytes":value["extraBoundsBytes"]}
    assert summary["allResultsBitExact"] and value["validationErrors"]==0 and value["liveBuffersAfterRelease"]==0
    (out/(device+"-summary.json")).write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
    print(device, summary, flush=True)
