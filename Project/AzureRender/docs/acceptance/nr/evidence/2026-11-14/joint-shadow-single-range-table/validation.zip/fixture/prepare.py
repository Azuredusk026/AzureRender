from pathlib import Path
import sys

run = Path(__file__).resolve().parent
source = Path(sys.argv[1])
cpp = (source/"range.cpp").read_text(encoding="utf-8")
cpp = cpp.replace("source.size()*sizeof(Pair)*7", "source.size()*sizeof(Pair)*2")
cpp = cpp.replace("source.size()*sizeof(Pair)*6", "source.size()*sizeof(Pair)")
cpp = cpp.replace("(w>=3&&w<=4&&h>=3&&h<=4)?1:w*h", "(w>=3&&w<=4&&h>=3&&h<=4)?(w-2)*(h-2):w*h")
cpp = cpp.replace("hierarchyReads*4>=baseReads", "hierarchyReads*3>=baseReads").replace("75% of range reads","two thirds of range reads")
cpp = cpp.replace("four rectangular tables", "one overlapping 3x3 table")
cpp = cpp.replace("if(hierarchical){Parameters p", "if(hierarchical&&level==0){Parameters p")
(run/"range.cpp").write_text(cpp,encoding="utf-8")
py = (source/"run.py").read_text(encoding="utf-8")
(run/"run.py").write_text(py,encoding="utf-8")
