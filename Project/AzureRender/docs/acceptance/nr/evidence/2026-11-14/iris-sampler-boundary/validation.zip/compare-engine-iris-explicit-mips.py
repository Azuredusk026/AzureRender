from pathlib import Path
from hashlib import sha256
from PIL import Image
import json,numpy as np

run=Path(__file__).resolve().parent
folder=run/'engine-iris-explicit-mips'
receipt=json.loads((folder/'results.json').read_bytes()); assert receipt['status']=='qualified'
event,=[row for row in receipt['events'] if row.get('selection')]
assert event['event']==897 and event['selection']['baseline']==event['selection']['copy']==event['selection']['restored']
x,y=np.fromfile(run/'native-iris-stages/points.bin','<u4').reshape(255,2).T
base_png=np.asarray(Image.open(run/'iris-production-absolute-icd/nvidia-disabled/frames/frame_000000.png').convert('RGB'),dtype=np.int16)[y,x]

def display(linear):
    linear=np.clip(linear,0,1)
    return np.rint(np.where(linear<=.0031308,linear*12.92,1.055*linear**(1/2.4)-.055)*255).astype(np.int16)

def decode_native(path):
    words=np.fromfile(path,'<u4'); channels=[]
    for shift,bits in ((0,6),(11,6),(22,5)):
        v=(words>>shift)&((1<<(bits+5))-1)
        p=(v>>bits).astype(int);m=v&((1<<bits)-1)
        channels.append(np.where(p==0,np.ldexp(m.astype(float),-14-bits),np.ldexp(1+m/(1<<bits),p-15))*.25)
    return display(np.column_stack(channels))

def decode_engine(label):
    p=folder/f'{event["event"]}-{label}-direct.bin';raw=p.read_bytes()
    assert sha256(raw).hexdigest()==event['selection'][label]['selectedSha256']['direct']
    return display(np.frombuffer(raw,'<f2').reshape(255,4)[:,:3].astype(float))

native=decode_native(run/'native-iris-stages/event-846.bin')
prior=decode_native(run/'native-iris-stages/event-1230.bin'); post=decode_native(run/'native-iris-stages/event-1245.bin'); overlay=np.any(prior!=post,axis=1)
assert overlay.sum()==94
implicit=decode_engine('baseline'); mips={i:decode_engine(f'mip{i}') for i in (4,5)}
assert np.abs(implicit-base_png).max()<=1
native_levels={i:decode_native(run/f'iris-explicit-mips/nvidia-mip-{i:02d}.bin') for i in (4,5)}

def score(a,b,mask):
    error=np.max(np.abs(a[mask]-b[mask]),axis=1)
    return dict(points=len(error),overOne=int((error>1).sum()),overEight=int((error>8).sum()),maximum=int(error.max()),mean=float(error.mean()))

report={'implicit':score(implicit,native,~overlay),'variants':{}}
for level,candidate in mips.items():
    subset=np.all(native==native_levels[level],axis=1)&~overlay
    report['variants'][level]=dict(entire=score(candidate,native,~overlay),nativeUsesLevel=score(candidate,native,subset),
        implicitOnSameSubset=score(implicit,native,subset),sameExplicitLevels=score(candidate,native_levels[level],~overlay),
        implicitVsExplicitEngine=score(implicit,candidate,~overlay))
for name,actual in [('implicit',implicit),*((str(i),mips[i]) for i in mips)]:
    diffs=np.max(np.abs(actual-native),axis=1)
    kept=np.where((diffs>1)&~overlay)[0]
    report.setdefault('residuals',{})[name]=[dict(x=int(x[i]),y=int(y[i]),reference=native[i].tolist(),candidate=actual[i].tolist(),maximum=int(diffs[i])) for i in kept]
(folder/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print({name:value for name,value in report.items() if name!='residuals'})
