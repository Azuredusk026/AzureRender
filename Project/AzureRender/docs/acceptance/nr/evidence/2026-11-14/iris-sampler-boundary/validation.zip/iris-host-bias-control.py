from pathlib import Path
from hashlib import sha256
from uuid import NAMESPACE_URL,uuid5
import json,os,runpy
import numpy as np

run=Path(__file__).resolve().parent
m=runpy.run_path(str(run/'iris-production-frozen-recovery.py')); read,dump,invoke,root=(m[key] for key in ('read','dump','invoke','project'))
state=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert state['state']=='held' and Path(state['output'])==run
report=run/'iris-host-bias-control';report.mkdir()
for k in ('VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC'):
    assert k not in os.environ
folder=root/'materials'
original='78aceced-9df2-5a59-a58b-f288adb30cb4'
name='iris-bias-control'
texture_id=str(uuid5(NAMESPACE_URL,name+'-dds'))
material_id=str(uuid5(NAMESPACE_URL,name+'-material'))
texture=folder/f'{name}.dds';os.link(folder/f'{original}.dds',texture)
meta=read(folder/f'{original}.dds.azmeta');assert meta['settings']['texture']['mipBias']==-1
meta['settings']['texture']['mipBias']=-.99;meta['id']=texture_id
dump(texture.with_suffix('.dds.azmeta'),meta)
material=read(folder/'f919b7a6-ca12-5772-b0e2-83cd5b5a046a.azurematerial')
assert material['textures']['0']['asset']==original
material['textures']['0']['asset']=texture_id
out=folder/f'{name}.azurematerial';dump(out,material)
dump(out.with_suffix('.azurematerial.azmeta'),dict(schemaVersion=1,id=material_id,dependencies=[],settings={}))
level=read(root/'scene/static-eye-shadow-production.azurelevel')
hero=next(n for n in level['nodes'] if n['id']=='hero')
hero['materialSlots']['name:M_actor_laevat_iris_01']=material_id
project=read(root/'eye-shadow-production.azureproject');project['startupScene']=f'stage:/{name}.azurelevel'
dump(root/'scene'/f'{name}.azurelevel',level)
entry=root/f'{name}.azureproject';dump(entry,project)
score=runpy.run_path(str(run/'static-quality.py'))
ref=score['image'](score['reference_path']).astype(np.int16)
xy=np.fromfile(run/'native-iris-stages/points.bin','<u4').reshape(255,2);x,y=xy.T
results={}
for dev,base in (('nvidia','iris-production-current-nvidia'),('intel','iris-production-captures')):
    case=report/dev;case.mkdir();cmd=read(run/f'static-{dev}-command.json')
    cmd[cmd.index('--project')+1]=str(entry);cmd[cmd.index('--capture-dir')+1]=str(case/'frames')
    frames=invoke(dev,cmd,case)
    old=score['image'](run/base/f'{dev}-enabled/frames/frame_000000.png').astype(np.int16)
    new=score['image'](frames/'frame_000000.png').astype(np.int16)
    error=np.max(np.abs(new-ref),axis=2)
    before=np.max(np.abs(old-ref),axis=2)
    changed=np.any(new!=old,axis=2)
    diff=changed[y,x];new_errors=(error[y,x]>1)&(before[y,x]<=1)
    ys,xs=np.nonzero(changed)
    results[dev]=dict(changedPixels=len(xs),irisChanged=int(diff.sum()),outsideChanged=int(len(xs)-diff.sum()),
        irisOverOne=int((error[y,x]>1).sum()),priorIrisOverOne=int((before[y,x]>1).sum()),peak=int(error[y,x].max()),
        newIrisFailures=int(new_errors.sum()),iris=[dict(x=int(a),y=int(b),before=old[b,a].tolist(),after=new[b,a].tolist(),native=ref[b,a].tolist()) for a,b in xy[diff]])
    (report/'results.json').write_text(json.dumps(results,indent=2)+'\n')
