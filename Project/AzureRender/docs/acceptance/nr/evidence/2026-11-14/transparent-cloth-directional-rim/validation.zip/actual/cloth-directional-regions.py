from hashlib import sha256
from pathlib import Path
import gzip
import json
import runpy
import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
inputs=out.parent/'20261114-042043-cloth-packed-parameters-7caac8'
ownership=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/post-opaque-ownership')
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
files=[ownership/f'1383-{i}.bin.gz' for i in (1382,1383)]
pre,post=[np.frombuffer(gzip.decompress(p.read_bytes()),'<u4').reshape(1440,2560)[::-1] for p in files]
cover=pre!=post
assert cover.any()
ref_path=runpy.run_path(str(grid/'static-quality.py'))['reference_path']
def image(p):
    with Image.open(p) as im: return np.asarray(im.convert('RGB')).astype(np.int16)
ref=image(ref_path)
result={'status':'source-comparison','overallStatus':'failed-user-review','reference':digest(ref_path),
        'nativeClothChanged':int(cover.sum()),'source':{p.name:digest(p) for p in files},'devices':{}}
for side in ('nvidia','intel'):
    folder=out/f'cloth-directional-{side}'
    old=inputs/side/'frames/frame_000000.png'
    new=folder/'frames/frame_000000.png'
    new_report=read(folder/'results.json')
    assert digest(new)==new_report['frameSha256']
    a,b=map(image,(old,new))
    old_err,new_err=[np.abs(v-ref).max(2) for v in (a,b)]
    change=(a!=b).any(2)
    assert new_report['allChanged']==int(change.sum())
    scopes={
        'wholeFrame':np.ones_like(cover),
        'nativeClothChanged':cover,
        'outsideNativeClothChanged':~cover,
        'changedByCandidate':change,
    }
    row={}
    for name,scope in scopes.items():
        row[name]=dict(n=int(scope.sum()),changed=int((change&scope).sum()),
            overOne=[int(((e>1)&scope).sum()) for e in (old_err,new_err)],
            overEight=[int(((e>8)&scope).sum()) for e in (old_err,new_err)],
            newOverOne=int(((old_err<=1)&(new_err>1)&scope).sum()),
            improved=int(((new_err<old_err)&scope).sum()),worsened=int(((new_err>old_err)&scope).sum()),
            peak=[int(e[scope].max()) for e in (old_err,new_err)])
    assert row['wholeFrame']['newOverOne']==new_report['newFrameOverOne']
    result['devices'][side]=dict(metrics=row,referenceFrame=digest(old),candidateFrame=digest(new),receipt=new_report)
(out/'cloth-directional-region-results.json').write_text(json.dumps(result,indent=2)+'\n')
for dev,row in result['devices'].items(): print(dev,row['metrics'])

