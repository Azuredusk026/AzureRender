from copy import deepcopy
from hashlib import sha256
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5
import json
import os
import runpy
import subprocess
import sys

import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
cloth=out.parent/'20261114-042043-cloth-packed-parameters-7caac8'
fixture=grid/'iris-overlay-geometry-project'
helpers=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read,invoke,build=(helpers[k] for k in ('read','invoke','build'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
device,=sys.argv[1:]
assert device in ('nvidia','intel')
lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==out
receipt=out.parent/'20261114-135148-face-receiver-diagnostics-7509b1/cloth-directional-replay-summary.json'
assert read(receipt)['scores']['mipsigned-rim']['rgbErrorImproved']==26
name='cloth-directional-rim-source-control'
staged=out/'cloth-directional-assets'
staged.mkdir(exist_ok=True)
resources=out/'cloth-directional-resources'
shaders=resources/'shaders'
shaders.mkdir(parents=True,exist_ok=True)
src='cloth-native-packed-parameters'
material=read(fixture/'materials'/f'{src}.azurematerial')
profile=material['surface']['materials'][0]['extras']['azureRenderMaterial']
assert profile['class']=='fabric' and material['surface']['materials'][0]['alphaMode']=='BLEND'
rim=profile['colorAdjustment']['rim']
assert abs(rim['width']-.765)<1e-6
rim['width']=1-rim['width']
uid=str(uuid5(NAMESPACE_URL,name))
level=read(fixture/'scene'/f'{src}.azurelevel')
hero=next(n for n in level['nodes'] if n['id']=='hero')
hero['materialSlots']['name:M_actor_laevat_cloth_03']=uid
project=read(fixture/f'{src}.azureproject')
project['startupScene']=f'stage:/{name}.azurelevel'
items={
    f'materials/{name}.azurematerial':material,
    f'materials/{name}.azurematerial.azmeta':dict(schemaVersion=1,id=uid,dependencies=[],settings={}),
    f'scene/{name}.azurelevel':level,
    f'{name}.azureproject':project}
source=Path(out.parents[2]/'shaders/mesh.frag')
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
base=source.read_text()
anchor='float facing=1.0-abs(dot(shadedNormal,viewDirection));'
assert base.count(anchor)==1
candidate=(base.replace(anchor, 'float viewDot=dot(shadedNormal,viewDirection); float facing=1.0-(AZURE_MATERIAL_CLASS==4U && AZURE_ALPHA_MODE==2 ? clamp(viewDot,0.0,1.0) : abs(viewDot));'))
frag=staged/'mesh-cloth-directional.frag'
frag.write_text(candidate,encoding='utf8')
modified=('mesh_object_lighting.frag.spv','mesh_object_early_lighting.frag.spv')
rules={r['output']:r for r in read(build/'shader-reload.json')['programs']}
stamp=resources/'runtime-build-Release.json'
if not stamp.exists():stamp.hardlink_to(build/stamp.name)
shas={}
for p in sorted((build/'shaders').glob('*.spv')):
    q=shaders/p.name
    if p.name in modified:
        rule=rules[p.name]
        assert not q.exists() or not os.path.samefile(p,q)
        command=[str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+v for v in rule['defines']),
                 '-I'+str(source.parent),str(frag),'-o',str(q)]
        subprocess.run(command,check=True)
        subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(q)],check=True)
        shas[p.name]=digest(q)
    elif not q.exists():q.hardlink_to(p)
    else:assert os.path.samefile(p,q)
assert len(list(shaders.glob('*.spv')))==895
links=[]
folder=out/f'cloth-directional-{device}'
folder.mkdir(exist_ok=True)
cmd=read(cloth/device/'command.json')
cmd[0]=str(build/'AzurePlayer.exe')
for k,path in [('--project',fixture/f'{name}.azureproject'),('--capture-dir',folder/'frames'),
               ('--resource-root',resources),('--runtime-report',folder/'runtime.json')]:
    if k in cmd:cmd[cmd.index(k)+1]=str(path)
    else:cmd.extend((k,str(path)))
try:
    for path,data in items.items():
        target,record=fixture/path,staged/Path(path).name
        write(record,data)
        if target.exists():assert os.path.samefile(target,record)
        else:target.hardlink_to(record)
        links.append((target,record))
    result=invoke(device,cmd,folder)/'frame_000000.png'
finally:
    for target,record in reversed(links):
        if target.is_file() and os.path.samefile(target,record):target.unlink()
        meta=target.with_name(target.name+'.azmeta')
        if meta.is_file() and target.suffix in ('.azurelevel','.azureproject') and not (staged/meta.name).exists():
            meta.replace(staged/meta.name)
assert all(digest(shaders/name)==sha for name,sha in shas.items())
ref=runpy.run_path(str(grid/'static-quality.py'))['reference_path']
def pixels(path):
    with Image.open(path) as image:return np.asarray(image.convert('RGB')).astype(np.int16)
actual,expected,base=map(pixels,(result,ref,cloth/device/'frames/frame_000000.png'))
coords=np.asarray(read(receipt)['points'])
x,y=coords.T
assert len(x)==30 and actual.shape==expected.shape==base.shape
before,after = (np.abs(im-expected).max(2) for im in (base,actual))
delta=np.abs(actual-base).max(2)
report=dict(device=device,programs=shas,player=digest(build/'AzurePlayer.exe'),frameSha256=digest(result),
            materialRim=rim,allChanged=int((delta>0).sum()),focusChanged=int((delta[y,x]>0).sum()),
            focusOverOne=[int((v[y,x]>1).sum()) for v in (before,after)],
            focusOverEight=[int((v[y,x]>8).sum()) for v in (before,after)],
            focusPeak=[int(v[y,x].max()) for v in (before,after)],
            newFrameOverOne=int(((before<=1)&(after>1)).sum()),focusErrors=[v[y,x].tolist() for v in (before,after)])
write(folder/'results.json',report)
print(json.dumps(report))

