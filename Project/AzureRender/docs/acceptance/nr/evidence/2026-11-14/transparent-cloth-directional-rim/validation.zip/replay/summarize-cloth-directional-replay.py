from hashlib import sha256
from pathlib import Path
import json
import numpy as np

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
import sys
preview='--preview' in sys.argv
job=out/('cloth-directional-replay-original' if preview and (out/'cloth-directional-replay-original').exists() else 'cloth-directional-replay')
receipt=read(job/'results.json')
assert receipt['status']=='qualified' or (preview and 'mipcolor-adjustment' in receipt.get('error',''))
r,=[r for r in receipt['events'] if r['event']==967]
assert r['selection']['baseline']==r['selection']['copy']==r['selection']['restored']
order=np.fromfile(grid/'skin-residual-points.bin','<u4').reshape(-1,2)
native=read(grid/'native-face-skin-stages/results.json')['history']['cloth']
loc={tuple(x):i for i,x in enumerate(order)}
indices=[loc[(row['x'],row['y'])] for row in native]
ref=np.asarray([row['after'][:3] for row in native])*.25
shader=np.asarray([row['shaderOut'] for row in native])
base=np.asarray([row['before'][:3] for row in native])*.25
raw={}
for source in ('baseline','miplegacy-rim','mipwidth-only','mipsigned-rim','mipfacing'):
    p=job/f'967-{source}-direct.bin'
    payload=p.read_bytes()
    assert sha256(payload).hexdigest()==r['selection'][source]['selectedSha256']['direct']
    raw[source]=np.frombuffer(payload,'<f2').reshape(-1,4).astype(float)[indices,:3]
assert np.max(np.abs(raw['baseline']-ref))>0.1
scores={}
for k,actual in raw.items():
    if k=='mipfacing': continue
    diff=np.abs(actual-ref)
    scores[k]=dict(meanAbsolute=diff.mean(0).tolist(),maxAbsolute=diff.max(0).tolist(),peakPerPoint=diff.max(1).tolist())
# Replay probe emits opaque readback. Blend the measured fragment for an equivalent test.
player,=[q['history'] for q in read(grid/'engine-cloth-color/results.json')['events'] if q['event']==967]
lookup={(s['x'],s['y']):s for s in player}
# The source probe's old code sets alpha=1, so its direct return is the isolated RGB.
alpha=np.asarray([lookup[(s['x'],s['y'])]['shaderOut'][3] for s in native]).reshape(-1,1)
dst=np.asarray([lookup[(s['x'],s['y'])]['before'][:3] for s in native])
src=np.asarray([lookup[(s['x'],s['y'])]['shaderOut'][:3] for s in native])
for k in ('miplegacy-rim','mipwidth-only','mipsigned-rim'):
    actual=raw[k]*alpha+dst*(1-alpha)
    diff=np.abs(actual-ref)
    scores[k]=dict(meanAbsolute=diff.mean(0).tolist(),maxAbsolute=diff.max(0).tolist(),peakPerPoint=diff.max(1).tolist(),
                    rgbErrorImproved=int((diff.max(1)<(np.abs(raw['baseline']-ref)).max(1)).sum()))
dots=raw['mipfacing'][:,0]*2-1
result=dict(status='source-attribution',points=[[row['x'],row['y']] for row in native],
    pointDots=dots.tolist(),scores=scores,program=r['shaderSha256'])
(out/('cloth-directional-replay-preview.json' if preview else 'cloth-directional-replay-summary.json')).write_text(json.dumps(result,indent=2)+'\n')
for k,s in scores.items():print(k,s['meanAbsolute'],s['maxAbsolute'],s.get('rgbErrorImproved'))

