from hashlib import file_digest, sha256
from pathlib import Path
import json
import os
import subprocess

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
lock = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state']=='held' and Path(lock['output'])==out
job = out/'cloth-directional-replay'
if job.exists():
    old=out/'cloth-directional-replay-original'
    assert not old.exists()
    job.rename(old)
job.mkdir(exist_ok=False)
request=json.loads((grid/'engine-cloth-components/request.json').read_bytes())
with Path(request['capture']).open('rb') as stream:
    assert file_digest(stream,'sha256').hexdigest()=='6960267c0d71e4d05b6bfe0e2730c332ed71955f1fde6d69eb7d8aadf13eff24'
request['sourceSha256']=sha256(Path(request['source']).read_bytes()).hexdigest()
(job/'request.json').write_text(json.dumps(request,indent=2)+'\n')
env=dict(os.environ,AZURE_ENGINE_IRIS_MIP_REPLAY=str(job),VK_DRIVER_FILES=str(grid/'nv-vk64-active-absolute.json'))
startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
with (job/'replay.log').open('wb') as log:
    proc=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'cloth-directional-rim-worker.py')],
            cwd=job,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=430)
result=json.loads((job/'results.json').read_bytes())
assert proc.returncode==0 and result['status']=='qualified',result.get('error')

