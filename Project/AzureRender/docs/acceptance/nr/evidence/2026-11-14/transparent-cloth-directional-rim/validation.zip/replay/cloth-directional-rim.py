from hashlib import sha256
from pathlib import Path
import json
import numpy as np

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
native=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c')
read=lambda p:json.loads(p.read_bytes())
shader = native/'native-e1383.dxbc'
asm=(native/'native-e1383.asm').read_text()
assert '1504: dp3 r13.w, r2.xyzx, r12.yzwy' in asm and '2158:   mov_sat r13.w, r13.w' in asm
assert '2159:   add r3.x, -r13.w, l(1.000000)' in asm and '2166:   mul r2.w, r2.w, r3.x' in asm
geo=read(grid/'native-face-skin-stages/results.json')['geometry']['1383']
assert sha256(shader.read_bytes()).hexdigest()==geo['pixelShaderSha256']
rows=read(grid/'cloth-color-adjustment-source.json')
p=grid/'iris-overlay-geometry-project/materials/cloth-native-packed-parameters.azurematerial'
rim=read(p)['surface']['materials'][0]['extras']['azureRenderMaterial']['colorAdjustment']['rim']
def calc(dot, signed, width):
    weight=np.clip((1-(np.clip(dot,0,1) if signed else abs(dot))-width)/(1-width),0,1)
    return np.asarray(rim['color'])*rim['intensity']*.25*(weight*weight*(3-2*weight))
report=[]
for s in rows:
    expected=np.asarray(s['colorAdjustmentContribution'])
    inputs=(s['nativeNormalDotView'],s['playerNormalDotNativeView'])
    candidates={}
    for side,dot in zip(('native','player'),inputs):
        for signed in (False,True):
            predicted=calc(dot,signed,1-rim['width'] if signed else rim['width'])
            candidates[f"{side}-{'signed' if signed else 'absolute'}"]=dict(rgb=predicted.tolist(),
                    maxAbsolute=float(np.max(np.abs(predicted-expected))))
    assert candidates['native-signed']['maxAbsolute']<1e-6
    report.append(dict(point=[s['x'],s['y']],normalDotView=inputs,candidates=candidates))
assert sum(r['candidates']['player-signed']['maxAbsolute']<1e-6 for r in report)==2
assert max(r['candidates']['player-signed']['maxAbsolute'] for r in report)<.001
assert sum(r['candidates']['player-absolute']['maxAbsolute']>.1 for r in report)==2
result=dict(points=report,shaderSha256=geo['pixelShaderSha256'],materialSha256=sha256(p.read_bytes()).hexdigest(),
            acceptance='requires dual-GPU actual fixture')
(out/'cloth-directional-rim.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(report))

