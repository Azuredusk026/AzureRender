from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

out=Path(__file__).resolve().parent
d=out.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
read=lambda p:json.loads(p.read_bytes())
region=read(out/'cloth-directional-region-results.json')
replay=read(d/'cloth-directional-replay-summary.json')
analytic=read(d/'cloth-directional-rim.json')
assert region['overallStatus']=='failed-user-review' and region['nativeClothChanged']==27832
assert replay['scores']['mipsigned-rim']['rgbErrorImproved']==26
assert max(r['candidates']['native-signed']['maxAbsolute'] for r in analytic['points'])<2e-8
for side in ('nvidia','intel'):
    device=region['devices'][side]
    assert device['receipt']['focusOverEight']==[28,11]
    assert device['receipt']['focusPeak']==[39,19]
    assert device['metrics']['outsideNativeClothChanged']['newOverOne']==0
    assert 1000<device['metrics']['nativeClothChanged']['newOverOne']<1050
report=dict(overallStatus=region['overallStatus'],region=region,replay=replay,analytic=analytic)
folder=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/transparent-cloth-directional-rim'
folder.mkdir(parents=True,exist_ok=False)
members={}
for fname in ['cloth-directional-actual.py','cloth-directional-regions.py',Path(__file__).name,
     'cloth-directional-assets/cloth-directional-rim-source-control.azurematerial']:
    members[f'actual/{fname}']=out/fname
for dev in ('nvidia','intel'):
    root=f'cloth-directional-{dev}'
    for name in ['command.json','results.json','runtime.json','frames/gpu_capabilities.json']:
        members[f'actual/{root}/{name}']=out/root/name
for fname in ['cloth-directional-rim.py','cloth-directional-rim-worker.py','cloth-directional-replay.py',
                'summarize-cloth-directional-replay.py','cloth-directional-replay/results.json',
                'cloth-directional-replay-original/results.json']:
    members[f'replay/{fname}']=d/fname
for label in ('baseline','copy','restored','miplegacy-rim','mipwidth-only','mipsigned-rim','mipfacing'):
    name=f'967-{label}-direct.bin'
    members[f'replay/cloth-directional-replay/{name}']=d/'cloth-directional-replay'/name
archive=folder/'validation.zip'
with ZipFile(archive,'x',ZIP_DEFLATED) as z:
    for key,p in members.items():z.write(p,key)
with ZipFile(archive) as z:
    assert len(z.namelist())==len(members) and z.testzip() is None
report['archive']=dict(sha256=sha256(archive.read_bytes()).hexdigest(),members=len(members))
(folder/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(report['archive'])

