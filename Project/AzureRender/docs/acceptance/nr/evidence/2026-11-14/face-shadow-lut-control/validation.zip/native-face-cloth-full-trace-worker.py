from pathlib import Path
from hashlib import sha256
import json,os,traceback
import renderdoc as rd

out=Path(os.environ['AZURE_NR_NATIVE_LIGHT_TRACE'])
job=json.loads((out/'request.json').read_bytes())
previous=json.loads(Path(job['history']).read_bytes())['history']
cap=rd.OpenCaptureFile(); ctl=None; report=dict(status='failed',samples=[])
try:
    assert cap.OpenFile(job['native'],'',None)==rd.ResultCode.Succeeded
    opt=rd.ReplayOptions();opt.forceGPUVendor=rd.GPUVendor.nVidia;opt.forceGPUDeviceID=0x28e0
    status,ctl=cap.OpenCapture(opt,None);assert status==rd.ResultCode.Succeeded and ctl
    assert ctl.GetAPIProperties().vendor==rd.GPUVendor.nVidia
    for owner,event,points,first,last in (('face',804,[(1279,296),(1279,297)],30,2600),('cloth',1383,[(1234,789),(1231,792),(1166,784)],1450,2352)):
        ctl.SetFrameEvent(event,True)
        for x,y in points:
            h=next(v for v in previous[owner] if (v['x'],v['y'])==(x,y))
            args=rd.DebugPixelInputs();args.primitive=h['primitive']
            trace=ctl.DebugPixel(x,1439-y,args)
            assert trace and trace.debugger,(event,x,y)
            registers={}; states={}; count=0
            try:
                while True:
                    batch=ctl.ContinueDebug(trace.debugger)
                    if not batch:break
                    for entry in batch:
                        for v in entry.changes:
                            after=v.after
                            if after.name:
                                registers[after.name]=list(after.value.f32v)[:4]
                        loc=int(entry.nextInstruction)
                        if first<=loc<=last or loc in (1470,1483,1484,1547,1548):
                            states[loc]={key: value for key,value in registers.items() if key.startswith(("r","o"))}
                        count+=1
                    assert count<20000
            finally:
                ctl.FreeTrace(trace)
            assert states,(event,x,y)
            name=f'{event}-{x}-{y}.json'; payload=(json.dumps(states,separators=(',',':'))+'\n').encode()
            (out/name).write_bytes(payload)
            report['samples'].append(dict(event=event,x=x,y=y,primitive=h['primitive'],hardware=h['shaderOut'],steps=count,states=len(states),file=name,sha256=sha256(payload).hexdigest()))
    report['status']='qualified'
except Exception:report['error']=traceback.format_exc()
finally:
    if ctl:ctl.Shutdown()
    cap.Shutdown()
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)
