from hashlib import sha256
from pathlib import Path
from uuid import NAMESPACE_URL,uuid5
import json,runpy,struct
import numpy as np

run=Path(__file__).resolve().parent
replay=run/'native-face-skin-stages'
root=run/'iris-overlay-geometry-project'
report=json.loads((replay/'results.json').read_bytes()); assert report['status']=='qualified'
base=runpy.run_path(str(run/'iris-production-frozen-recovery.py'))
read,dump,invoke=(base[key] for key in ('read','dump','invoke'))
score=runpy.run_path(str(run/'static-quality.py'))
orig='bb40e191-8bee-50ec-9830-2f6656e3ec3a'

def asset_id(name):
    return str(uuid5(NAMESPACE_URL,'azurerender/captured-face-10401/'+name))


def make_lut():
    from io import BytesIO
    from PIL import Image
    source=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-212213-native-binding-restoration-d39ea8/frame10401')
    receipt=read(source/'e804-t14-bin-receipt.json')['data']
    data=(source/'e804-t14.bin').read_bytes()
    assert receipt['complete'] and sha256(data).hexdigest()==receipt['sha256']
    w,h=receipt['width'],receipt['height']
    assert (w,h,receipt['format'])==(1024,32,'BC7_SRGB')
    header=struct.pack('<31I',124,0x81007,h,w,len(data),0,1,*([0]*11),32,4,0x30315844,0,0,0,0,0,0x1000,0,0,0,0)
    name='face-native-shadow-lut'
    path=root/'materials'/f'{name}.png'
    with Image.open(BytesIO(b'DDS '+header+struct.pack('<5I',99,3,0,1,0)+data)) as image:
        image.convert('RGBA').transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(path)
    dump(path.with_suffix('.png.azmeta'),dict(schemaVersion=1,id=asset_id(name),dependencies=[],settings={}))
    return asset_id(name),sha256(path.read_bytes()).hexdigest()


def prepare(bindings):
    spec=read(root/'materials'/f'{orig}.azurematerial')
    level=read(root/'scene/static-eye-shadow-production.azurelevel')
    project=read(root/'eye-shadow-production.azureproject')
    path_name='face-native-shadow-lut-'+'-'.join(f't{i}' for i in bindings)
    material=spec['surface']['materials'][0]
    profile=material['extras']['azureRenderMaterial']
    assets={}
    for binding in bindings:
        key,digest=dds[binding]
        # Both source textures use the same V orientation as the existing glTF.
        if binding==18:
            i=material['pbrMetallicRoughness']['baseColorTexture']['index']
        else:
            i=profile['shadowColorLut']['texture']
        image_index=spec['surface']['textures'][i]['source']
        spec['textures'][str(image_index)]={'asset':key,'usage':'albedo' if binding==18 else 'linear'}
        assets[binding]=digest
    mat_path=root/'materials'/f'{path_name}.azurematerial'
    dump(mat_path,spec)
    dump(mat_path.with_suffix('.azurematerial.azmeta'),dict(schemaVersion=1,id=asset_id(path_name),dependencies=[],settings={}))
    hero=next(node for node in level['nodes'] if node['id']=='hero')
    hero['materialSlots']['name:M_actor_laevat_face_01']=asset_id(path_name)
    dump(root/'scene'/f'{path_name}.azurelevel',level)
    project['startupScene']=f'stage:/{path_name}.azurelevel'
    path=root/f'{path_name}.azureproject'; dump(path,project)
    return path,assets


if __name__=='__main__':
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==run
    out=run/'face-native-shadow-lut'; out.mkdir()
    known=root/'materials/native-face-t18.dds'
    dds={18:(asset_id('native-face-t18'),sha256(known.read_bytes()).hexdigest()),14:make_lut()}
    import PIL.Image as Image
    old=np.asarray(Image.open(root/'materials/2090db99-d6df-5267-a796-a242d6e051e5.png').convert('RGBA'),dtype=np.int16)
    lut=np.asarray(Image.open(root/'materials/face-native-shadow-lut.png').convert('RGBA'),dtype=np.int16)
    assert old.shape==lut.shape==(32,1024,4)
    assert 0<np.abs(old-lut).mean()<1
    ref=score['image'](score['reference_path']).astype(np.int16)
    mask=np.asarray(Image.open(run/'native-face-masks/face.png').convert('L'))
    import cv2
    mask=cv2.erode(mask,np.ones((13,13),np.uint8))>0
    assert mask.sum()==1176
    x,y=np.fromfile(run/'face-residual-points.bin','<u4').reshape(-1,2).T
    result={}
    for variant in ((14,),(18,14)):
        project,assets=prepare(variant)
        name=project.stem
        result[name]=dict(assets=assets,devices={})
        for device in ('nvidia','intel'):
            folder=out/f'{name}-{device}'; folder.mkdir()
            command=read(run/f'static-{device}-command.json')
            for option,value in (('--project',project),('--capture-dir',folder/'frames')):
                command[command.index(option)+1]=str(value)
            frames=invoke(device,command,folder)
            a=score['image'](frames/'frame_000000.png').astype(np.int16)
            d=np.max(np.abs(a-ref),axis=2)
            result[name]['devices'][device]=dict(overOne=int((d[mask]>1).sum()),overEight=int((d[mask]>8).sum()),peak=int(d[mask].max()),
                  selected=d[y,x].tolist(),regional=score['compare'](ref.astype(np.uint8),a.astype(np.uint8),{'face':mask})['face'])
        (out/'results.json').write_text(json.dumps(result,indent=2)+'\n')




