from pathlib import Path
from hashlib import sha256
import math,json,runpy,struct,sys
import numpy as np

run=Path(__file__).resolve().parent
root=run.parents[2];sys.path.insert(0,str(root/'tools'))
from endfield_native.postvs import read_postvs
source=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261023-033116-postvs-linear-verification-591bef/postvs-804/manifest.json')
raw=read_postvs(source)
clip=raw['attributes']['SV_Position'].astype(np.float64)
uv=raw['attributes']['TEXCOORD0'][:,:2].astype(np.float64)
triangles=raw['indices'].reshape(-1,3)
xy=(clip[:,:2]/clip[:,3,None]+1.)*[1280,720]
score=runpy.run_path(str(run/'static-quality.py'))
x,y=np.fromfile(run/'face-residual-points.bin','<u4').reshape(-1,2).T
q=np.column_stack([x,y]).astype(np.float64)+.5
rows=[]
for point,target in zip(zip(x,y),q):
 txy=xy[triangles]; edge=txy[:,1:]-txy[:,0,None]; delta=target-txy[:,0]
 det=edge[:,0,0]*edge[:,1,1]-edge[:,1,0]*edge[:,0,1]
 valid=np.abs(det)>1e-8
 u=np.divide(delta[:,0]*edge[:,1,1]-edge[:,1,0]*delta[:,1],det,out=np.full_like(det,np.nan),where=valid)
 v=np.divide(edge[:,0,0]*delta[:,1]-delta[:,0]*edge[:,0,1],det,out=np.full_like(det,np.nan),where=valid)
 b=np.column_stack([1-u-v,u,v]); indices=np.where(np.all(b>=-.00001,axis=1))[0]
 assert len(indices)>0,point
 controls=[]
 for i in indices:
  vertices=triangles[i]; weighted=b[i]/clip[vertices,3]; norm=weighted/weighted.sum()
  coord=norm@uv[vertices]; depth=norm@clip[vertices,2]
  control=dict(primitive=int(i),nativeUv=coord.tolist(),z=float(depth),uvTexels=(coord*1024-.5).tolist())
  controls.append(control)
 rows.append(dict(x=int(point[0]),y=int(point[1]),covered=controls))
print(json.dumps(rows[:4],indent=2))
(run/'face-native-uv-at-residuals.json').write_text(json.dumps(dict(sourceSha256=sha256(source.read_bytes()).hexdigest(),rows=rows),indent=2)+'\n')
