from hashlib import sha256
from pathlib import Path
from uuid import NAMESPACE_URL,uuid5
import json,runpy,struct
import numpy as np

run=Path(__file__).resolve().parent
replay=run/'native-face-skin-stages'
root=run/'iris-overlay-geometry-project'
report=json.loads((replay/'results.json').read_bytes()); assert report['status']=='qualified'
base=runpy.run_path(str(run/'iris-production-frozen-recovery.py'))
read,dump,invoke=(base[key] for key in ('read','dump','invoke'))
score=runpy.run_path(str(run/'static-quality.py'))
orig='bb40e191-8bee-50ec-9830-2f6656e3ec3a'

def asset_id(name):
    return str(uuid5(NAMESPACE_URL,'azurerender/captured-face-10401/'+name))


def make_dds(binding):
    item=report['faceTextures'][str(binding)]
    levels=[(replay/row['path']).read_bytes() for row in item['levels']]
    assert all(sha256(data).hexdigest()==row['sha256'] and len(data)==row['size'] for data,row in zip(levels,item['levels']))
    w,h=item['width'],item['height']
    assert len(levels)==max(w,h).bit_length()
    assert [len(data) for data in levels]==[16*max(1,((w>>i)+3)//4)*max(1,((h>>i)+3)//4) for i in range(len(levels))]
    srgb=binding==18
    assert item['format'] in ('BC7_SRGB','BC7_UNORM','BC7_TYPELESS'),item
    # Decode each authored BC7 mip to RGBA8 so the existing glTF V convention
    # can be applied losslessly to every level, including the 2x2 and 1x1 levels.
    from io import BytesIO
    from PIL import Image
    flipped=[]
    for i,data in enumerate(levels):
        mw,mh=max(1,w>>i),max(1,h>>i)
        base=struct.pack('<31I',124,0x81007,mh,mw,len(data),0,1,*([0]*11),32,4,0x30315844,0,0,0,0,0,0x1000,0,0,0,0)
        with Image.open(BytesIO(b'DDS '+base+struct.pack('<5I',99 if srgb else 98,3,0,1,0)+data)) as opened:
            flipped.append(opened.convert('RGBA').transpose(Image.Transpose.FLIP_TOP_BOTTOM).tobytes())
    header=struct.pack('<31I',124,0x2100F,h,w,w*4,0,len(flipped),*([0]*11),32,4,0x30315844,0,0,0,0,0,0x401008,0,0,0,0)
    payload=b'DDS '+header+struct.pack('<5I',29 if srgb else 28,3,0,1,0)+b''.join(flipped)
    name=f'native-face-t{binding}-fixed-lookup'
    file=root/'materials'/f'{name}.dds'; file.write_bytes(payload)
    usage='albedo' if srgb else 'linear'
    dump(file.with_suffix('.dds.azmeta'),dict(schemaVersion=1,id=asset_id(name),dependencies=[],settings=dict(texture=dict(schemaVersion=1,
         usage=usage,colorSpace='srgb' if srgb else 'linear',filter='linear',wrapU='repeat' if srgb else 'clamp',
         wrapV='repeat' if srgb else 'clamp',mipPolicy='generate' if srgb else 'none',anisotropy=1,mipBias=-1 if srgb else 0,mipFilter='nearest'))))
    return asset_id(name),sha256(payload).hexdigest()


def prepare(bindings):
    spec=read(root/'materials'/f'{orig}.azurematerial')
    level=read(root/'scene/static-eye-shadow-production.azurelevel')
    project=read(root/'eye-shadow-production.azureproject')
    path_name='face-fixed-lookup-'+'-'.join(f't{i}' for i in bindings)
    material=spec['surface']['materials'][0]
    profile=material['extras']['azureRenderMaterial']
    assets={}
    for binding in bindings:
        key,digest=dds[binding]
        # Both source textures use the same V orientation as the existing glTF.
        if binding==18:
            i=material['pbrMetallicRoughness']['baseColorTexture']['index']
        else:
            i=profile['faceSdf']['maskTexture']
        image_index=spec['surface']['textures'][i]['source']
        spec['textures'][str(image_index)]={'asset':key,'usage':'albedo' if binding==18 else 'linear'}
        assets[binding]=digest
    mat_path=root/'materials'/f'{path_name}.azurematerial'
    dump(mat_path,spec)
    dump(mat_path.with_suffix('.azurematerial.azmeta'),dict(schemaVersion=1,id=asset_id(path_name),dependencies=[],settings={}))
    hero=next(node for node in level['nodes'] if node['id']=='hero')
    hero['materialSlots']['name:M_actor_laevat_face_01']=asset_id(path_name)
    dump(root/'scene'/f'{path_name}.azurelevel',level)
    project['startupScene']=f'stage:/{path_name}.azurelevel'
    path=root/f'{path_name}.azureproject'; dump(path,project)
    return path,assets


if __name__=='__main__':
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==run
    out=run/'face-authored-mips-mask-retest'; out.mkdir()
    known=root/'materials/native-face-t18.dds'
    dds={18:(asset_id('native-face-t18'),sha256(known.read_bytes()).hexdigest()),20:make_dds(20)}
    # The per-source orientation must be established before rendering.
    import PIL.Image as Image
    for binding,name in ((18,'c87fcdc1-aab9-5231-8a6e-3753d2639d7d.png'),(20,'f904c6bc-9ff0-5a74-b848-3641dbd12e77.png')):
        original=np.asarray(Image.open(root/'materials'/name).convert('RGBA'),dtype=np.int16)
        authored=np.asarray(Image.open(root/'materials'/('native-face-t18.dds' if binding==18 else 'native-face-t20-fixed-lookup.dds')).convert('RGBA'),dtype=np.int16)
        assert original.shape==authored.shape
        by_direction=[float(np.abs(original-candidate).mean()) for candidate in (authored,authored[::-1])]
        assert by_direction[0]<by_direction[1],(binding,by_direction)
        if binding==20: assert by_direction[0]==0,(binding,by_direction)
        else: assert (original==authored).all(2).sum()>800000
    ref=score['image'](score['reference_path']).astype(np.int16)
    mask=np.asarray(Image.open(run/'native-face-masks/face.png').convert('L'))
    import cv2
    mask=cv2.erode(mask,np.ones((13,13),np.uint8))>0
    assert mask.sum()==1176
    x,y=np.fromfile(run/'face-residual-points.bin','<u4').reshape(-1,2).T
    result={}
    for variant in ((20,),(18,20)):
        project,assets=prepare(variant)
        name=project.stem
        result[name]=dict(assets=assets,devices={})
        for device in ('nvidia','intel'):
            folder=out/f'{name}-{device}'; folder.mkdir()
            command=read(run/f'static-{device}-command.json')
            for option,value in (('--project',project),('--capture-dir',folder/'frames')):
                command[command.index(option)+1]=str(value)
            frames=invoke(device,command,folder)
            a=score['image'](frames/'frame_000000.png').astype(np.int16)
            d=np.max(np.abs(a-ref),axis=2)
            result[name]['devices'][device]=dict(overOne=int((d[mask]>1).sum()),overEight=int((d[mask]>8).sum()),peak=int(d[mask].max()),
                  selected=d[y,x].tolist(),regional=score['compare'](ref.astype(np.uint8),a.astype(np.uint8),{'face':mask})['face'])
        (out/'results.json').write_text(json.dumps(result,indent=2)+'\n')




