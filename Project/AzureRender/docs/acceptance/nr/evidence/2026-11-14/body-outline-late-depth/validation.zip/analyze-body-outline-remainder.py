from pathlib import Path
import gzip
import json
import runpy

import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
diagnostics=run.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
radial=run.parent/'20261114-051632-face-local-radial-light-retest-ea8fb6'
read=lambda p:json.loads(p.read_bytes())
ref=runpy.run_path(str(grid/'static-quality.py'))['reference_path']

def rgb(path):
    with Image.open(path) as image:return np.asarray(image.convert('RGB'),dtype=np.int16)

expected=rgb(ref)
points=np.fromfile(diagnostics/'body-visible-ownership-points.bin','<u2').reshape(-1,3)
assert points.shape==(1184,3)
x,y,event=points.T
skin=np.asarray(Image.open(grid/'native-face-masks/skin.png').convert('L'))>0
owner=event==1018
cloth=event==1383
assert owner.sum()==1112 and cloth.sum()==57
native_stage=runpy.run_path(str(grid/'static-quality.py'))['stages']/'post-opaque-ownership'

def attachment(name):
    return np.frombuffer(gzip.decompress((native_stage/f'{name}.bin.gz').read_bytes()),'<u4').reshape(1440,2560)[::-1]

def linear_rgb(words):
    result=[]
    for shift,bits in ((0,6),(11,6),(22,5)):
        lane=(words>>shift)&((1<<(bits+5))-1)
        exponent=(lane>>bits).astype(int)
        mantissa=lane&((1<<bits)-1)
        result.append(np.where(exponent==0,np.ldexp(mantissa.astype(float),-14-bits),np.ldexp(1+mantissa/(1<<bits),exponent-15)))
    return np.stack(result,axis=-1)

def encoded(words):
    v=np.clip(linear_rgb(words)*.25,0,1)
    return np.rint(np.where(v<=.0031308,12.92*v,1.055*v**(1/2.4)-.055)*255).astype(np.int16)

native_pre,native_post=(encoded(attachment(f'1018-{tick}')[y,x]) for tick in (1017,1018))
result={}
for device in ('nvidia','intel'):
    baseline=rgb(radial/f'production-{device}-enabled/frames/frame_000000.png')
    report={}
    early=np.abs(baseline-expected).max(2)
    for mode in ('blend','exact'):
        path=run/f'body-{mode}-{device}/frames/frame_000000.png'
        if not path.is_file():continue
        actual=rgb(path)
        err=actual-expected
        d=np.abs(err).max(2)
        delta=np.any(actual!=baseline,axis=2)
        row={}
        for label,selector in [('coverage',np.ones(1184,dtype=bool)),('outlineVisible',owner),('clothLater',cloth)]:
            xx,yy=x[selector],y[selector]
            es=err[yy,xx]
            sort=np.argsort(-d[yy,xx])[:16]
            nativeBefore,nativeAfter=native_pre[selector],native_post[selector]
            candidateRgb,refRgb=actual[yy,xx],expected[yy,xx]
            ds=[np.abs(target-candidateRgb).max(1) for target in (nativeBefore,nativeAfter,refRgb)]
            df=np.abs(nativeAfter-refRgb).max(1)
            row[label]=dict(pixels=len(es),skinPixels=int(skin[yy,xx].sum()),
                overOne=[int((e[yy,xx]>1).sum()) for e in (early,d)],
                overEight=[int((e[yy,xx]>8).sum()) for e in (early,d)],
                nativeOutlineAfterVsFinal=dict(overOne=int((df>1).sum()),overEight=int((df>8).sum()),peak=int(df.max())),
                actualVsNativeStages=dict(overOne=[int((e>1).sum()) for e in ds],peak=[int(e.max()) for e in ds]),
                channels=dict(median=np.median(es,axis=0).tolist(),min=es.min(0).tolist(),max=es.max(0).tolist()),
                witnesses=[dict(point=[int(xx[i]),int(yy[i])],old=baseline[yy[i],xx[i]].tolist(),
                    actual=candidateRgb[i].tolist(),reference=refRgb[i].tolist(),nativeBefore=nativeBefore[i].tolist(),
                    nativeAfter=nativeAfter[i].tolist()) for i in sort])
        cover=np.zeros(skin.shape,dtype=bool);cover[y,x]=True
        row['outsideChanges']=[dict(point=[int(xx),int(yy)],before=int(early[yy,xx]),after=int(d[yy,xx]))
            for yy,xx in zip(*np.where(delta & ~cover))]
        row['newOverOne']=[dict(point=[int(xx),int(yy)],before=int(early[yy,xx]),after=int(d[yy,xx]),
                                     inside=bool(cover[yy,xx])) for yy,xx in zip(*np.where((early<=1)&(d>1)))]
        report[mode]=row
    result[device]=report
(run/'body-outline-remainder.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
for dev,rows in result.items():
    for mode,row in rows.items():
        print(dev,mode,len(row['outsideChanges']),row['outlineVisible']['channels'],row['clothLater']['channels'],row['outlineVisible']['witnesses'][:3])
