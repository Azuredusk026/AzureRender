from hashlib import file_digest
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

out=Path(__file__).resolve().parent
target=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/body-outline-late-depth'
read=lambda p:json.loads(p.read_bytes())
def digest(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()

totals=read(out/'body-blend-depth-results.json')['devices']
remainder=read(out/'body-outline-remainder.json')
assert set(totals)=={'nvidia','intel'}
members=[Path(__file__).name,'run-order.py','analyze-body-outline-remainder.py','body-outline-remainder.json','body-blend-depth-results.json']
result={}
for dev,eight in [('nvidia',626),('intel',627)]:
    path=out/f'body-blend-{dev}'
    assert digest(path/'frames/frame_000000.png')==totals[dev]['frame']
    scores=totals[dev]
    assert scores['focusImproved']==61 and scores['focusPeak']==5 and scores['coverageOverEight']==eight
    row=remainder[dev]['blend']
    assert row['outlineVisible']['pixels']==1112 and row['clothLater']['pixels']==57
    assert row['outlineVisible']['nativeOutlineAfterVsFinal']['peak']==0
    assert row['outlineVisible']['overEight'][1]==eight-65 and row['clothLater']['overEight'][1]==56
    result[dev]=dict(whole=scores,groups={k:{n:row[k][n] for n in ('pixels','overOne','overEight','nativeOutlineAfterVsFinal')}
            for k in ('coverage','outlineVisible','clothLater')})
    members += [f'body-blend-{dev}/{p}' for p in ('command.json','runtime.json','frames/capture_manifest.json','frames/gpu_capabilities.json')]
target.mkdir(parents=True,exist_ok=False)
with ZipFile(target/'validation.zip','x',ZIP_DEFLATED) as archive:
    for name in members:archive.write(out/name,name)
with ZipFile(target/'validation.zip') as archive:assert set(archive.namelist())==set(members) and archive.testzip() is None
record=dict(overallStatus='failed-user-review',lateDepth=result,
    archive=dict(members=len(members),sha256=digest(target/'validation.zip')))
(target/'results.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(record['archive'])
