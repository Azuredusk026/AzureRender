from copy import deepcopy
from pathlib import Path
from hashlib import sha256
import json
import os
import runpy
import sys

import numpy as np

out = Path(__file__).resolve().parent
base = out.parent/'20261114-044912-body-outline-lit-surface-fba9d7'
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
fixture = grid/'iris-overlay-geometry-project'
reference = out.parent/'20261114-051632-face-local-radial-light-retest-ea8fb6'
h = runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read,dump,invoke = (h[key] for key in ('read','dump','invoke'))
old_name = 'body-native-lit-outline-production'
variant=sys.argv[2] if len(sys.argv)==3 else 'opaque-last'
assert variant in ('opaque-last','blend-late-write')
name = 'body-native-lit-outline-depth-order' if variant=='opaque-last' else 'body-native-lit-outline-blend-depth'
model = fixture/'character'/f'{old_name}.gltf'
asset = base/model.name
lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==out
suffix = sys.argv[1] if len(sys.argv)>=2 else 'nvidia'
assert suffix in ('nvidia','intel')
path = out/('results.json' if variant=='opaque-last' else 'body-blend-depth-results.json')
report = read(path) if path.exists() else dict(devices={})
backup = out/f'{old_name}-ordered.gltf'
if not backup.exists():
    document = read(asset)
    meshes,nodes,materials = (document[key] for key in ('meshes','nodes','materials'))
    body, = [m for m in meshes if any(materials[p['material']]['name']=='M_actor_laevat_body_01_lit_outline' for p in m['primitives'])]
    assert len(body['primitives'])==2
    original_index = meshes.index(body)
    original_node, = [n for n in nodes if n.get('mesh')==original_index]
    duplicate = deepcopy(original_node)
    duplicate['name'] += '-lit-outline'
    duplicate['mesh'] = len(meshes)
    meshes.append(dict(primitives=[body['primitives'].pop()]))
    root = document['scenes'][document['scene']]['nodes']
    original_node_index = nodes.index(original_node)
    group, = [n for n in nodes if original_node_index in n.get('children',[])]
    group['children'].append(len(nodes))
    nodes.append(duplicate)
    assert nodes.index(group) in root
    (out/backup.name).write_text(json.dumps(document,separators=(',',':')),encoding='utf8')
    report['candidateSha256'] = sha256(backup.read_bytes()).hexdigest()
    path.write_text(json.dumps(report,indent=2)+'\n')
project = read(base/f'{old_name}.azureproject')
scene = read(base/f'{old_name}.azurelevel')
tint_scene = read(fixture/'scene/face-native-radial-local-production.azurelevel')
hero = lambda level:next(n for n in level['nodes'] if n['id']=='hero')
hero(scene)['materialSlots']['name:M_actor_laevat_face_01'] = hero(tint_scene)['materialSlots']['name:M_actor_laevat_face_01']
project['startupScene'] = f'stage:/{name}.azurelevel'
targets = [(model,backup)]
if variant=='blend-late-write':
    from uuid import NAMESPACE_URL,uuid5
    slot='name:M_actor_laevat_body_01_lit_outline'
    new_material=read(fixture/'materials'/f'{old_name}.azurematerial')
    material=new_material['surface']['materials'][0]
    assert material['alphaMode']=='OPAQUE'
    material['alphaMode']='BLEND'
    material['extras']['azureRenderMaterial']['blendDepth']=dict(schemaVersion=1,write=True,compare='less-or-equal')
    identity=str(uuid5(NAMESPACE_URL,'azurerender/body-outline-lit/blend-late-write'))
    relative=f'materials/{name}.azurematerial'
    staged=out/f'{name}.azurematerial'
    sidecar=staged.with_suffix('.azurematerial.azmeta')
    if not staged.exists():
        dump(staged,new_material)
        dump(sidecar,dict(schemaVersion=1,id=identity,dependencies=[],settings={}))
    else:
        assert read(staged)==new_material
    targets.extend(((fixture/relative,staged),(fixture/(relative+'.azmeta'),sidecar)))
    hero(scene)['materialSlots'][slot]=identity
for dest,data in ((fixture/'scene'/f'{name}.azurelevel',scene),(fixture/f'{name}.azureproject',project)):
    staged = out/dest.name
    if not staged.exists():
        dump(staged,data)
    else:
        assert read(staged)==data
    targets.append((dest,staged))
try:
    for dest,src in targets:
        dest.hardlink_to(src)
    candidate_project = targets[-1][0]
    device = suffix
    folder = out/(device if variant=='opaque-last' else f'body-blend-{device}')
    folder.mkdir(exist_ok=True)
    if (folder/'command.json').is_file():
        assert not (folder/'frames/frame_000000.png').is_file(),folder
        siblings=[p for p in out.glob(f'{folder.name}-interrupted-*') if p.is_dir()]
        folder.rename(out/f'{folder.name}-interrupted-{len(siblings)+1}')
        folder.mkdir()
    before_record = reference/f'production-{device}-enabled'
    command = read(before_record/'command.json')
    command[command.index('--project')+1] = str(candidate_project)
    command[command.index('--capture-dir')+1] = str(folder/'frames')
    if '--runtime-report' not in command: command.extend(['--runtime-report',str(folder/'runtime.json')])
    frame = invoke(device,command,folder)/'frame_000000.png'
    scorer = runpy.run_path(str(grid/'static-quality.py'))
    image = lambda p:scorer['image'](p).astype(np.int16)
    before = image(before_record/'frames/frame_000000.png')
    actual = image(frame)
    ref = image(scorer['reference_path'])
    d0,d1 = (np.abs(im-ref).max(2) for im in (before,actual))
    change = np.abs(before-actual).max(2)
    shape = (1440,2560,2)
    folder = grid/'native-body-outline-depth'
    coverage = (np.fromfile(folder/'depth-1017.bin','<u4').reshape(shape)
        != np.fromfile(folder/'depth-1018.bin','<u4').reshape(shape))[::-1,:,0]
    x,y = np.asarray(read(grid/'face-skin-overlay-ownership.json')['skin']['1018']['locations']).T
    assert coverage[y,x].all() and int(coverage.sum())==1184
    report['devices'][device] = dict(coverageChanges=int((change[coverage]>0).sum()),
        coverageMoreThanOne=int((change[coverage]>1).sum()),focusImproved=int((d1[y,x]<d0[y,x]).sum()),
        focusPeak=int(d1[y,x].max()),coverageOverEight=int((d1[coverage]>8).sum()),
        outsideChanges=int(((change>0)&~coverage).sum()),frame=sha256(frame.read_bytes()).hexdigest(),
        newGlobalOverOne=int(((d0<=1)&(d1>1)).sum()))
    path.write_text(json.dumps(report,indent=2)+'\n')
finally:
    for dest,src in reversed(targets):
        if dest.exists() and os.path.samefile(dest,src):
            dest.unlink()
        sidecar = dest.with_suffix(dest.suffix+'.azmeta')
        if sidecar.exists() and dest!=model and not (out/sidecar.name).exists():
            sidecar.replace(out/sidecar.name)
