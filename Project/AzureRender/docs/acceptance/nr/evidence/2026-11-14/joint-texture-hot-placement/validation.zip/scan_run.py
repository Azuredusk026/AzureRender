from pathlib import Path
import json
import os
import subprocess
import sys
out=Path(__file__).resolve().parent
sys.path.insert(0, str(Path.cwd() / 'tools'))
from artifact_maintenance import managed_environment
info=subprocess.STARTUPINFO()
info.dwFlags|=subprocess.STARTF_USESHOWWINDOW
info.wShowWindow=0
with (out/"replay.log").open("wb") as log:
    subprocess.run(["D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe","--python",(out/"scan_entry.py").as_posix()],cwd=out, env=dict(os.environ, **managed_environment(out / 'tmp')),
                   stdout=log,stderr=subprocess.STDOUT,startupinfo=info,check=True,timeout=500)
result=json.loads((out/"texture-hotset.json").read_bytes())
print(len(result["selected"]),result["selectedBytes"],flush=True)
