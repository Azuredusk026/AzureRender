from pathlib import Path
import json, re, statistics

run=Path(__file__).resolve().parent
def read(name):
    return json.loads((run/name).read_bytes())
short=read("short-results.json")
pixels=read("original-four/results.json")
before, candidate, after=short
assert [row["role"] for row in short] == ["nonlocal-before","resident-hotset","nonlocal-after"]
assert all(row["sampled"]==450 and row["drivers"]==["595.79"] and row["powerLimits"]==[80.0] and row["allocatorZero"] for row in short)
assert all(row["sameDriverExact"] and row["sameDriverChangedPixels"]==0 for row in pixels["frames"])
assert pixels["retainedAllocations"]==candidate["residentCount"]
assert candidate["allocationCount"] + candidate["residentCount"] == before["allocationCount"] == after["allocationCount"] == 224
assert candidate["allocationBytes"] + candidate["residentBytes"] == before["allocationBytes"] == after["allocationBytes"]
device_cap=1610612736
assert all(row["deviceLocalPeakBytes"] <= device_cap for row in short)
baseline_mean=statistics.mean(row["gpuFrameMs"]["mean"] for row in (before,after))
drift=abs(before["gpuFrameMs"]["mean"]-after["gpuFrameMs"]["mean"])
reduction=baseline_mean-candidate["gpuFrameMs"]["mean"]
report = {"textureCount": candidate["residentCount"], "localAllocationBytes":candidate["residentBytes"],
    "frameMeanReductionMs":reduction, "referenceFrameMeanDriftMs":drift,
    "memoryHeadroomBytes": device_cap-candidate["deviceLocalPeakBytes"], "sameDriverPixelExact":True,
    "qualifiesForFormalRerun": reduction > drift and candidate["gpuFrameMs"]["p95"] < min(before["gpuFrameMs"]["p95"],after["gpuFrameMs"]["p95"])}
(run/"decision.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps(report),flush=True)
