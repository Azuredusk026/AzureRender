from pathlib import Path
import sys
import traceback

runner = Path(r"D:/Projects/FYP/Project/AzureRender/build/runs/20261114-125834-nr-joint-texture-hot-placement-4e085e/scan.py")
report = runner.parent / "replay-status.txt"
report.write_text("started\n", encoding="utf-8")
try:
    globals_override = {"__file__": str(runner), "__name__": "__main__"}
    exec(compile(runner.read_bytes(), str(runner), "exec"), globals_override)
except SystemExit:
    raise
except Exception:
    report.write_text(traceback.format_exc(), encoding="utf-8")
    sys.exit(2)
