from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZipFile
import renderdoc as rd

root = Path("D:/Projects/FYP/Project/AzureRender")
out = Path(r"D:/Projects/FYP/Project/AzureRender/build/runs/20261114-125834-nr-joint-texture-hot-placement-4e085e")
producer = root/"build/runs/20261111-001050-quad-feature-device-capture-4798d1"
reach = root/"build/runs/20261114-025819-nr-joint-texture-reachability-fbe01a"
state=json.loads((producer/"state.json").read_bytes())
with Path(state["capture"]).open("rb") as stream:
    digest = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b''):
        digest.update(block)
    assert digest.hexdigest()==state["captureSha256"]
source = root / "docs/acceptance/nr/evidence/2026-11-11/resident-srgb-channel-scope/validation.zip"
with ZipFile(source) as archive:
    inventory = {row["resource"]:row for row in json.loads(archive.read("texture-inventory.json"))}
events=json.loads((reach/"events.json").read_bytes())
profile={str(row["event"]):row for row in json.loads((producer/"profile-state.json").read_bytes())["pixelEvents"]}
counts=Counter()
samples=Counter()
for event, resources in events.items():
    for resource in resources:
        counts[resource]+=1
        samples[resource]+=profile.get(event,{}).get("ps",0)
cap=rd.OpenCaptureFile()
assert cap.OpenFile(state["capture"],"",None)==rd.ResultCode.Succeeded
status,controller=cap.OpenCapture(rd.ReplayOptions(),None)
assert status==rd.ResultCode.Succeeded
controller.SetFrameEvent(0,True)
results=[]
try:
    for image in controller.GetTextures():
        fmt=image.format.Name()
        resource=str(image.resourceId)
        if (not inventory[resource]["name"].startswith("2D Image ") or fmt not in ("R8G8B8A8_UNORM","R8G8B8A8_SRGB")
                or image.width*image.height<1024*1024 or image.arraysize!=1 or image.msSamp!=1 or image.mips<2):
            continue
        data=controller.GetTextureData(image.resourceId,rd.Subresource(0,0,0))
        assert len(data)==image.width*image.height*4
        signature=14695981039346656037
        for i in range(1024):
            signature=((signature^data[i*(len(data)-1)//1023])*1099511628211)&((1<<64)-1)
        size=sum(max(1,image.width>>i)*max(1,image.height>>i)*4 for i in range(image.mips))
        results.append({"resource":resource,"width":image.width,"height":image.height,"mips":image.mips,"format":43 if fmt.endswith("SRGB") else 37,
                        "size":size,"events":counts[resource],"pixelInvocations":samples[resource],"signature":f"{signature:016x}"})
finally:
    controller.Shutdown()
    cap.Shutdown()
assert len(results)==224,len(results)

groups = {}
for row in results:
    key = tuple(row[field] for field in ("width", "height", "mips", "format", "signature"))
    groups.setdefault(key, []).append(row)
ranked = sorted(groups.values(), key=lambda group: (
    -sum(row["pixelInvocations"] for row in group) / sum(row["size"] for row in group),
    -sum(row["events"] for row in group), group[0]["resource"]))
selected = []
total = 0
for group in ranked:
    size = sum(row["size"] for row in group)
    if any(row["pixelInvocations"] for row in group) and total + size <= 100 * 1024**2:
        selected.extend(group)
        total += size
assert len(selected)>5 and total>90*1024**2
(out/"texture-hotset.json").write_text(json.dumps({"capture":state["captureSha256"],"all":results,"selected":selected,"selectedBytes":total},indent=2)+"\n",encoding="utf-8")
print(len(selected),total,flush=True)

sys.exit(0)
