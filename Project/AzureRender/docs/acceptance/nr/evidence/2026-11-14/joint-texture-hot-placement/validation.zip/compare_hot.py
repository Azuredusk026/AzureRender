from pathlib import Path
import csv
import json
import os
import re
import subprocess
import sys
import time
from zipfile import ZipFile

import numpy as np
from placement_gate import check

root = Path.cwd().resolve()
run = Path(__file__).resolve().parent
source = Path("D:/Projects/FYP-worktrees/nr-integration-verified/Project/AzureRender")
build = source / "build/catalog-computed"
sys.path.insert(0, str(source / "tools"))
from build_provenance import digest, verify
from gpu_environment import RunEnvironmentMonitor, environment_errors, wait_and_record, snapshot
from run_playable_performance import memory_snapshot

def read(path):
    return json.loads(path.read_bytes())

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")

def verify_inputs():
    verify(source, baseline)
    assert all(digest(Path(name)) == sha for name, sha in receipt["inputsAndProducts"].items())
    assert len(locked) == 1729 and all(digest(Path(name)) == sha for name, sha in locked.items())

receipt = read(run / "candidate-receipt.json")
baseline_path = Path(receipt["baseReceiptPath"])
assert digest(baseline_path) == receipt["baseReceiptSha256"]
baseline = read(baseline_path)
scope = root / "docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope/validation.zip"
with ZipFile(scope) as archive:
    locked = json.loads(archive.read("run/frozen-project-inputs.json"))
    command = json.loads(archive.read("run/diagnostic-1080p60/command.json"))["command"]
verify_inputs()
pixels = read(run / "original-four/results.json")
assert all(frame["sameDriverExact"] for frame in pixels["frames"]), "Placement changes pixels on the same driver"
command[command.index("--resource-root") + 1] = str(build)
warmup = 300
samples = 450
frames = warmup + samples
command[command.index("--smoke-frames") + 1] = str(frames)
expected_count = len(read(run / "texture-hotset.json")["selected"])
env = dict(os.environ, VK_LOADER_DRIVERS_SELECT="*nv-vk64*", DOTNET_ROOT="D:/Tools/dotnet9")
env["PATH"] = os.pathsep.join(map(str, (build, root / "build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin", env["PATH"])))
for name in ("VK_DRIVER_FILES", "VK_ICD_FILENAMES", "VK_INSTANCE_LAYERS", "VK_LAYER_VALIDATE_SYNC", "VK_LOADER_DEBUG",
             "VK_LAYER_ENABLES", "AZURE_CPU_WORK_REPORT", "AZURERENDER_RESOURCE_ROOT", "AZURE_DISABLE_COMPUTED_MATERIAL_VIEW",
             "AZURE_DIAGNOSTIC_NONLOCAL_TEXTURES"):
    env.pop(name, None)

def collect(role, hotset_enabled):
    folder = run / role
    folder.mkdir()
    timing = folder / "timing.json"
    command[0] = str(run / "AzurePlayer.exe")
    command[command.index("--gpu-timing-output") + 1] = str(timing)
    child_env = dict(env, AZURE_DIAGNOSTIC_NONLOCAL_TEXTURES="1", AZURE_DIAGNOSTIC_LOCAL_HOTSET="1" if hotset_enabled else "0")
    save(folder / "command.json", {"command":command, "inputs":len(locked), "hotsetEnabled":hotset_enabled})
    environment_path = folder / "environment.json"
    environment = wait_and_record(environment_path, timeout=120) if role == "nonlocal-before" else {"startup":[snapshot()]}
    observations = []
    start = time.monotonic()
    with RunEnvironmentMonitor(environment, path=environment_path, interval=2), (folder / "player.log").open("wb") as log:
        player = subprocess.Popen(command, cwd=source, env=child_env, stdout=log, stderr=subprocess.STDOUT)
        try:
            while player.poll() is None:
                try:
                    observations.append(memory_snapshot(player.pid))
                except OSError:
                    if player.poll() is not None:
                        break
                    raise
                if time.monotonic() - start > 520:
                    raise TimeoutError(role)
                time.sleep(.25)
        finally:
            if player.poll() is None:
                player.kill()
                player.wait()
    assert player.returncode == 0
    local, placements = check(folder / "player.log", expected_count if hotset_enabled else 0)
    data = read(timing)
    assert data["computedMaterialViewSelectionsTotal"] > 0 and data["computedMaterialViewFallback"] == "ready"
    cpu = data["cpuFrame"]["workSamplesMs"]
    assert len(cpu) == frames
    with timing.with_suffix(".csv").open(encoding="utf-8") as stream:
        rows = [row for row in csv.DictReader(stream) if warmup < int(row["frame"]) <= frames]
    assert len(rows) == samples
    telemetry = environment["startup"] + environment["runObservations"] + [environment["final"]]
    def stats(values):
        return {"mean":float(np.mean(values)), "p95":float(np.percentile(values, 95))}
    result = {"role":role, "sampled":samples, "gpuFrameMs":stats([float(row["frameMs"]) for row in rows]),
            "gpuSceneMs":stats([float(row["sceneMs"]) for row in rows]), "cpuMs":stats(cpu[warmup:]),
            "deviceLocalPeakBytes":data["allocator"]["deviceLocalPeakBytes"], "workingSetPeakBytes":max(row["peak"] for row in observations),
            "residentCount":len(local), "residentBytes":sum(local), "allocationCount":len(placements), "allocationBytes":sum(placements), "allocatorZero":True,
            "temperatureRange":[min(row["temperature"] for row in telemetry), max(row["temperature"] for row in telemetry)],
            "powerLimits":sorted({row["powerLimitWatts"] for row in telemetry}), "drivers":sorted({row["driver"] for row in telemetry}),
            "softwareThermalObservations":sum(row["thermalSlowdown"]["software"] for row in telemetry)}
    assert result["drivers"] == ["595.79"] and result["powerLimits"] == [80.0]
    assert result["deviceLocalPeakBytes"] <= 1.5 * 1024**3
    save(folder / "results.json", result)
    print(json.dumps(result), flush=True)
    return result

results = [collect(role, hotset_enabled) for role, hotset_enabled in (
    ("nonlocal-before",False), ("resident-hotset",True), ("nonlocal-after",False))]
verify_inputs()
save(run / "short-results.json", results)
