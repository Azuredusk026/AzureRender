from pathlib import Path

run = Path(__file__).resolve().parent
prior = Path("D:/Projects/FYP/Project/AzureRender/build/runs/20261114-032038-nr-joint-nonlocal-image-candidate-92047b")
source = Path("D:/Projects/FYP-worktrees/nr-integration-verified/Project/AzureRender")
allocator = (prior / "GpuAllocator.candidate.cpp").read_text(encoding="utf-8")
cache = (source / "src/render/SampledTextureCache.cpp").read_text(encoding="utf-8")

def replace_one(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

allocator = replace_one(allocator, "namespace azurerender::rhi {\n",
    "namespace azurerender::rhi {\nthread_local bool keepDiagnosticMaterialImageLocal = false;\n")
allocator = replace_one(allocator, "    if (diagnosticEnabled && !hostVisible",
    "    if (diagnosticEnabled && !keepDiagnosticMaterialImageLocal && !hostVisible")
allocator = replace_one(allocator, '    check(status, "vmaCreateImage");\n',
'''    check(status, "vmaCreateImage");
    if (diagnosticEnabled && keepDiagnosticMaterialImageLocal) {
        std::fprintf(stderr, "Resident diagnostic material image %ux%u format=%d bytes=%llu\\n",
            createInfo.extent.width, createInfo.extent.height, int(createInfo.format),
            static_cast<unsigned long long>(info.size));
    }
''')
cache = replace_one(cache, "#include <cstring>\n", "#include <cstring>\n#include <algorithm>\n#include <cstdlib>\n#include <iterator>\n#include <string_view>\n")
cache = replace_one(cache, "namespace azurerender {\nnamespace {\n",
'''namespace azurerender::rhi {
extern thread_local bool keepDiagnosticMaterialImageLocal;
}
namespace azurerender {
namespace {
struct TextureIdentity {
    unsigned width;
    unsigned height;
    unsigned mips;
    VkFormat format;
    std::uint64_t signature;
};
constexpr TextureIdentity hotTextures[] = {
#include "texture_hotset.inc"
};
struct DiagnosticPlacement {
    const bool previous = rhi::keepDiagnosticMaterialImageLocal;
    explicit DiagnosticPlacement(bool keepLocal) { rhi::keepDiagnosticMaterialImageLocal = keepLocal; }
    ~DiagnosticPlacement() { rhi::keepDiagnosticMaterialImageLocal = previous; }
};
bool keepHotTextureLocal(const std::vector<std::uint8_t>& storage, std::size_t baseBytes,
    unsigned width, unsigned height, unsigned mips, VkFormat format) {
    static const bool enabled = [] {
        const char* setting = std::getenv("AZURE_DIAGNOSTIC_LOCAL_HOTSET");
        return setting && std::string_view(setting) == "1";
    }();
    if (!enabled || mips < 2 || baseBytes < 4 * 1024 * 1024
        || (format != VK_FORMAT_R8G8B8A8_UNORM && format != VK_FORMAT_R8G8B8A8_SRGB)) {
        return false;
    }
    const auto matchingLayout = [=](const TextureIdentity& texture) {
        return texture.width == width && texture.height == height && texture.mips == mips && texture.format == format;
    };
    if (std::none_of(std::begin(hotTextures), std::end(hotTextures), matchingLayout)) {
        return false;
    }
    std::uint64_t signature = 14695981039346656037ULL;
    for (unsigned i = 0; i < 1024; ++i) {
        signature ^= storage[i * (baseBytes - 1) / 1023];
        signature *= 1099511628211ULL;
    }
    return std::any_of(std::begin(hotTextures), std::end(hotTextures), [&](const TextureIdentity& texture) {
        return matchingLayout(texture) && texture.signature == signature;
    });
}
''')
cache = replace_one(cache,
'''    entry->image=allocator_.createImage2D(request.width,request.height,physicalFormat,
        VK_IMAGE_USAGE_TRANSFER_DST_BIT|VK_IMAGE_USAGE_SAMPLED_BIT
            |(levels>1?VK_IMAGE_USAGE_TRANSFER_SRC_BIT:0),levels);
''',
'''    {
        DiagnosticPlacement placement(keepHotTextureLocal(*storage, static_cast<std::size_t>(baseBytes),
            request.width, request.height, levels, physicalFormat));
        entry->image=allocator_.createImage2D(request.width,request.height,physicalFormat,
            VK_IMAGE_USAGE_TRANSFER_DST_BIT|VK_IMAGE_USAGE_SAMPLED_BIT
                |(levels>1?VK_IMAGE_USAGE_TRANSFER_SRC_BIT:0),levels);
    }
''')
(run / "GpuAllocator.candidate.cpp").write_text(allocator, encoding="utf-8")
(run / "SampledTextureCache.candidate.cpp").write_text(cache, encoding="utf-8")

build = (prior / "build_overlay.py").read_text(encoding="utf-8")
build = replace_one(build, 'player_row = next', '''cache_row = next(i for i, line in enumerate(lines) if line.startswith("build CMakeFiles") and "SampledTextureCache.cpp.obj:" in line)
cache_vars = dict(line.strip().split(" = ", 1) for line in lines[cache_row+1:cache_row+7])
player_row = next''')
build = replace_one(build, "candidate = run", '''selection = json.loads((run / "texture-hotset.json").read_bytes())["selected"]
header = run / "texture_hotset.inc"
header.write_text("".join(
    f'    {{{row["width"]}, {row["height"]}, {row["mips"]}, static_cast<VkFormat>({row["format"]}), 0x{row["signature"]}ULL}},\\n'
    for row in selection), encoding="utf-8")
cache = run / "SampledTextureCache.candidate.cpp"
cache_object = run / "SampledTextureCache.obj"
tracked_command("compile-cache", "cl.exe",
                f'/nologo /c {cache_vars["DEFINES"]} {cache_vars["FLAGS"]} {cache_vars["INCLUDES"]} /Fo"{cache_object}" "{cache}"')
candidate = run''')
build = replace_one(build, '"{allocator_object}" /out', '"{allocator_object}" "{cache_object}" /out')
build = replace_one(build, 'libs = [build / name', '''cache_symbols = [line for line in map_path.read_text(errors="replace").splitlines()
                 if len(line.split()) > 1 and line.split()[1].startswith("?acquireImpl@SampledTextureCache@")]
assert len(cache_symbols) == 1 and "SampledTextureCache.obj" in cache_symbols[0], cache_symbols
libs = [build / name''')
build = replace_one(build, '[cpp, path, allocator_object, candidate, build / main_obj, *libs]',
    '[cpp, cache, header, run / "texture-hotset.json", path, allocator_object, cache_object, candidate, build / main_obj, *libs]')
build = replace_one(build, '"candidateObjectSymbol":symbols[0].strip()', '"candidateObjectSymbols":[symbols[0].strip(), cache_symbols[0].strip()]')
(run / "build_hot.py").write_text(build, encoding="utf-8")
