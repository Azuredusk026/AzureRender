from collections import Counter
from pathlib import Path
import json
from zipfile import ZipFile
root = Path.cwd()
capture = root / "build/runs/20261111-001050-quad-feature-device-capture-4798d1"
reach = root / "build/runs/20261114-025819-nr-joint-texture-reachability-fbe01a"
with ZipFile(root / "docs/acceptance/nr/evidence/2026-11-11/resident-srgb-channel-scope/validation.zip") as archive:
    inventory = json.loads(archive.read("texture-inventory.json"))
profile = {str(row["event"]): row["ps"] for row in json.loads((capture / "profile-state.json").read_bytes())["pixelEvents"]}
events = json.loads((reach / "events.json").read_bytes())
print("inventory", len(inventory), inventory[0])
print("event shape", next(iter(events.items())))
print("pixel-counter coverage", len(profile), len(events), len(profile.keys() & events.keys()))

samples = Counter()
for event, resources in events.items():
    for resource in resources:
        samples[resource] += profile[event]
rows = [x for x in inventory if x["format"] in ("R8G8B8A8_UNORM", "R8G8B8A8_SRGB") and x["name"].startswith("2D Image ")
        and x["width"]*x["height"] >= 1024*1024 and x["mips"] > 1 and x["arraysize"] == x["msSamples"] == 1]
for row in rows:
    row["pixelInvocations"] = samples[row["resource"]]
    row["logicalBytes"] = sum(max(1,row["width"]>>m)*max(1,row["height"]>>m)*4 for m in range(row["mips"]))
rows.sort(key=lambda row: -row["pixelInvocations"]/row["logicalBytes"])
selected = []
total = 0
for row in rows:
    if row["pixelInvocations"] and total+row["logicalBytes"] <= 100*1024**2:
        selected.append(row)
        total += row["logicalBytes"]
print("eligible",len(rows),"selected",len(selected),"bytes",total,"total weighted share",
      sum(x["pixelInvocations"] for x in selected)/sum(x["pixelInvocations"] for x in rows))
print("selected shapes",Counter((x["width"],x["height"]) for x in selected))
