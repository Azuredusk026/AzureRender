from pathlib import Path
import re
import sys

def placements(log_path):
    log = log_path.read_text(errors="replace")
    assert "Allocator after unload: buffers=0 images=0" in log
    resident = [int(value) for value in re.findall(r"Resident diagnostic material image .* bytes=(\d+)", log)]
    nonlocal_images = [int(value) for value in re.findall(r"Nonlocal material image .* bytes=(\d+)", log)]
    assert len(resident) + len(nonlocal_images) == 224
    return resident, nonlocal_images

def check(log_path, expected):
    resident, nonlocal_images = placements(log_path)
    assert len(resident) == expected, f"expected {expected} textures in local memory, observed {len(resident)}"
    if expected:
        assert 90*1024**2 <= sum(resident) <= 120*1024**2
    return resident, nonlocal_images

if __name__ == "__main__":
    check(Path(sys.argv[1]), int(sys.argv[2]))
