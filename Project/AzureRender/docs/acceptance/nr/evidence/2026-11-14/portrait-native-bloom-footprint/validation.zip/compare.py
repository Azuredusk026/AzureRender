from pathlib import Path
from hashlib import sha256
import json
import runpy

import numpy as np
from PIL import Image

out = Path(__file__).resolve().parent
runs = out.parent
grid = runs/'20261112-231945-projected-hair-reference-grid-4b775d'
source = runs/'20261114-044051-native-bloom-pixel-reconstruction-940538'
portrait = runs/'20261114-032805-portrait-eye-bloom-source-dcf1c9'
composite = runs/'20261114-034154-portrait-native-bloom-composition-f3b56a'
receipt = json.loads((source/'results.json').read_bytes())
scope = json.loads((grid/'portrait-results.json').read_bytes())
case_paths = json.loads(Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261101-043757-material-display-transform-93d6e0/native-final-comparison.json').read_bytes())
reference = Path(case_paths['comparisons'][1]['reference'])
assert sha256(reference.read_bytes()).hexdigest()==scope['referenceSha256']
extract = runpy.run_path(str(out/'native-math.py'),run_name='bloom_math')
passes = extract['passes']
pack, unpack, sample = [extract[name] for name in ('pack','unpack','sample')]
c = np.fromfile(composite/'6834-1598-compose-cb1.bin','<f4').reshape(-1,4)
threshold,start,width,gain = c[10]
assert c[9,1]==0 and c[9,2]==0

def read_rgb(path):
    return np.asarray(Image.open(path).convert('RGB'))


def decode(rgb):
    srgb = rgb.astype(np.float32)/255
    return np.where(srgb<=.04045,srgb/12.92,((srgb+.055)/1.055)**2.4)


def encode(rgb):
    rgb = np.clip(rgb,0,1)
    srgb = np.where(rgb<=.0031308,rgb*12.92,1.055*rgb**(1/2.4)-.055)
    return np.rint(np.clip(srgb,0,1)*255).astype(np.uint8)


def native_bloom(hdr):
    extract_row = dict(passes[1410],width=(hdr.shape[1]+1)//2,height=(hdr.shape[0]+1)//2)
    quantize = lambda value: unpack(pack(value))
    layers = [quantize(extract['extract'](extract_row,hdr,resize=True))]
    for event in (1419,1428,1437,1446,1455,1464,1473,1482):
        previous = layers[-1]
        row = dict(passes[event],width=(previous.shape[1]+1)//2,height=(previous.shape[0]+1)//2)
        layers.append(quantize(extract['downsample'](row,previous,resize=True)))
    result = layers.pop()
    for event,high in zip((1491,1500,1509,1518,1527,1536,1545,1554),reversed(layers)):
        row = dict(passes[event],width=high.shape[1],height=high.shape[0])
        result = quantize(extract['upsample'](row,result,high,resize=True))
    return result


def assess(a,b,regions):
    result = {}
    for name,r in regions.items():
        x0,y0,x1,y1 = r['bounds']
        delta = np.abs(a[y0:y1,x0:x1].astype(np.int16)-b[y0:y1,x0:x1].astype(np.int16)).max(2)
        y,x = np.unravel_index(int(np.argmax(delta)),delta.shape)
        result[name] = dict(overOne=int((delta>1).sum()),peak=int(delta.max()),
            worstPoint=[int(x+x0),int(y+y0)])
    return result


display_reference = read_rgb(reference)
report = dict(status='analytical same-input footprint',differentNativeCamera=True,devices={})
for device,baseline in scope['cases'].items():
    probe = read_rgb(portrait/f'{device}-hdr/frames/frame_000000.png')
    hdr = decode(probe)*16
    assert hdr.shape==display_reference.shape==(1536,1536,3)
    native = native_bloom(hdr)
    y,x = np.ogrid[:hdr.shape[0],:hdr.shape[1]]
    wide = sample(native,(x+.5)*.5-.5,(y+.5)*.5-.5)
    bloom = wide*c[9,0]
    current = read_rgb(grid/f'portrait-{device}-frames/frame_000000.png')
    prior = read_rgb(portrait/f'{device}-direct-bloom/frames/frame_000000.png')
    prior_linear = decode(prior)*.25
    report['devices'][device] = dict(peakPoint=[667,808],currentLinear=prior_linear[808,667].tolist(),
        nativeHalfLinear=wide[808,667].tolist(),nativeCompositeLinear=bloom[808,667].tolist(),
        probeRGB=probe[808,667].tolist(),currentRGB=current[808,667].tolist(),
        referenceRGB=display_reference[808,667].tolist(),
        estimatedLinearOutput=encode(hdr+bloom)[808,667].tolist(),
        currentRegions=assess(current,display_reference,baseline['regions']),
        estimatedNativeBloomRegions=assess(encode(hdr+bloom),display_reference,baseline['regions']),
        estimatedLocalBloomRegions=assess(encode(hdr+prior_linear),display_reference,baseline['regions']),
        probeOnlyRegions=assess(encode(hdr),display_reference,baseline['regions']))
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
