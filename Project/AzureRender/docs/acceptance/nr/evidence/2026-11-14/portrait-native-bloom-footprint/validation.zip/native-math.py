from pathlib import Path
import json
import sys

import numpy as np

out = Path(__file__).resolve().parent.parent/'20261114-044051-native-bloom-pixel-reconstruction-940538'
receipt = json.loads((out/'results.json').read_bytes())
partial = '--partial' in sys.argv
assert partial or receipt['status']=='qualified', receipt
passes = {row['event']:row for row in receipt['passes']}
resources = {}
baseline = out.parent/'20261114-034154-portrait-native-bloom-composition-f3b56a'
if not partial:
    assert (out/'1554-r11.bin').read_bytes()==(baseline/'6834-bloom.bin').read_bytes()
mantissa_bits = np.array([6,6,5])


def unpack(word):
    field = np.stack([word&2047,(word>>11)&2047,word>>22],axis=-1)
    power = (field>>mantissa_bits).astype(np.int16)
    fraction = (field&((1<<mantissa_bits)-1))/(1<<mantissa_bits)
    return np.where(power==0,np.ldexp(fraction,-14),np.ldexp(1+fraction,power-15)).astype(np.float32)


def pack(color):
    color = np.clip(color,0,None)
    _,exp = np.frexp(color)
    exp = np.where(color==0,-14,np.maximum(exp-1,-14))
    units = np.floor(np.ldexp(color,mantissa_bits-exp)).astype(np.uint32)
    field = ((exp+14).astype(np.uint32)<<mantissa_bits)+units
    return field[...,0]|(field[...,1]<<11)|(field[...,2]<<22)


def sample(image,x,y):
    # Coordinates are measured from the first input texel center.
    x = np.rint(x*256)/256
    y = np.rint(y*256)/256
    lo_x = np.floor(x).astype(np.int32)
    lo_y = np.floor(y).astype(np.int32)
    mix_x = (x-lo_x).astype(np.float32)[...,None]
    mix_y = (y-lo_y).astype(np.float32)[...,None]
    x0 = np.clip(lo_x,0,image.shape[1]-1)
    x1 = np.clip(lo_x+1,0,image.shape[1]-1)
    y0 = np.clip(lo_y,0,image.shape[0]-1)
    y1 = np.clip(lo_y+1,0,image.shape[0]-1)
    a = image[y0,x0]
    b = image[y0,x1]
    c = image[y1,x0]
    d = image[y1,x1]
    a = a+(b-a)*mix_x
    b = c+(d-c)*mix_x
    return a+(b-a)*mix_y


def constants(row,block):
    return np.fromfile(out/row['constants'][str(block)],'<f4').reshape(-1,4)


def extract(row,hdr,resize=False):
    global_cb = constants(row,0)
    _,_,out_dx,out_dy = constants(row,1)[0]
    cutoff,soft_start,soft_width,soft_gain = constants(row,1)[1]
    if resize:
        out_dx,out_dy = np.float32(1/row['width']),np.float32(1/row['height'])
    y,x = np.ogrid[:row['height'],:row['width']]
    exposure = global_cb[27,0]
    _,_,src_dx,src_dy = global_cb[0]
    if resize:
        src_dx,src_dy = np.float32(1/hdr.shape[1]),np.float32(1/hdr.shape[0])
    x = (x.astype(np.float32)+.5)*out_dx
    y = (y.astype(np.float32)+.5)*out_dy
    taps = [(0,0,4),(-2,-2,1),(2,-2,1),(2,2,1),(-2,2,1),(-2,0,2),
            (2,0,2),(0,2,2),(0,-2,2),(-1,1,4),(1,1,4),(-1,-1,4),(-1,1,4)]
    rgb_sum = np.zeros((row['height'],row['width'],3),dtype=np.float32)
    weight_sum = np.zeros((row['height'],row['width']),dtype=np.float32)
    luma = np.array([.212673,.715152,.072175],dtype=np.float32)
    for offset_x,offset_y,tap in taps:
        source = sample(hdr,(x+offset_x*src_dx)*hdr.shape[1]-.5,(y+offset_y*src_dy)*hdr.shape[0]-.5)
        source = np.where(np.isfinite(source),source,0)
        peak = source.max(2)
        knee = np.clip(peak-soft_start,0,soft_width)
        scale = np.maximum(peak-cutoff,knee*knee*soft_gain)/np.maximum(peak,1e-4)
        source *= scale[...,None]*exposure
        weight = tap/(1+np.sum(source*luma,axis=-1))
        rgb_sum = (source.astype(np.float64)*weight[...,None]+rgb_sum).astype(np.float32)
        weight_sum = (tap*(weight.astype(np.float64)/tap)+weight_sum).astype(np.float32)
    return rgb_sum/weight_sum[...,None]


def downsample(row,image,resize=False):
    y,x = np.ogrid[:row['height'],:row['width']]
    inv_x,inv_y = constants(row,0)[0,2:]
    if resize:
        inv_x,inv_y = np.float32(1/row['width']),np.float32(1/row['height'])
    weights = np.array([1,8,28,56,70,56,28,8,1],dtype=np.float32)/256
    result = np.zeros((row['height'],row['width'],3),dtype=np.float32)
    for offset_y,weight_y in zip(range(-4,5),weights):
        source_y = (y+offset_y+.5)*inv_y*image.shape[0]-.5
        horizontal = np.zeros_like(result)
        for offset_x,weight_x in zip(range(-4,5),weights):
            source_x = (x+offset_x+.5)*inv_x*image.shape[1]-.5
            point = sample(image,source_x,source_y).astype(np.float16).astype(np.float32)
            horizontal += point*weight_x
        result += horizontal*weight_y
    return result


def cubic_axis(coordinate):
    integer = np.floor(coordinate)
    t = coordinate-integer
    a = (1-t)**3/6
    b = (3*t**3-6*t*t+4)/6
    c = (-3*t**3+3*t*t+3*t+1)/6
    d = t**3/6
    return integer-1+b/(a+b), integer+1+d/(c+d), a+b, c+d


def upsample(row,low,high,resize=False):
    cb = constants(row,0)
    strength,mode = cb[0,:2]
    source_size = cb[1,:2]
    target_size = cb[2,:2]
    if resize:
        source_size = low.shape[1],low.shape[0]
        target_size = high.shape[1],high.shape[0]
    assert mode==0
    y,x = np.ogrid[:row['height'],:row['width']]
    lo_x,hi_x,w0_x,w1_x = cubic_axis((x+.5)/target_size[0]*source_size[0]+.5)
    lo_y,hi_y,w0_y,w1_y = cubic_axis((y+.5)/target_size[1]*source_size[1]+.5)
    max_x = (1-1/target_size[0])*source_size[0]-.5
    max_y = (1-1/target_size[1])*source_size[1]-.5
    result = np.zeros_like(high)
    for xs,wx in [(lo_x,w0_x),(hi_x,w1_x)]:
        for ys,wy in [(lo_y,w0_y),(hi_y,w1_y)]:
            weight = (wx*wy).astype(np.float32)[...,None]
            result += sample(low,np.minimum(xs-1,max_x),np.minimum(ys-1,max_y))*weight
    return ((result-high).astype(np.float64)*strength+high).astype(np.float32)


def score(actual,calculated):
    values = unpack(actual)
    packed = pack(calculated)
    assert np.array_equal(pack(values),actual)
    f = lambda p:np.stack([p&2047,(p>>11)&2047,p>>22],axis=-1).astype(np.int16)
    units = np.abs(f(actual)-f(packed))
    error = np.abs(values-calculated)
    points = np.abs(unpack(packed)-values)
    return dict(total=int(actual.size),exact=int(np.count_nonzero(actual==packed)),
        overOneUnit=int((units.max(2)>1).sum()),maximumUnits=units.max((0,1)).tolist(),
        maximumAbsolute=error.max((0,1)).tolist(),meanAbsolute=error.mean((0,1)).tolist(),
        quantizedMaximumAbsolute=points.max((0,1)).tolist())


if __name__=='__main__':
    hdr = np.fromfile(out/'scene-rgba16f.bin','<f2').reshape(1440,2560,4)[...,:3].astype(np.float32)
    results = {}
    accumulated = {}
    for event,row in passes.items():
        word = np.fromfile(out/row['output'],'<u4').reshape(row['height'],row['width'])
        if row['kind']=='extract':
            actual = extract(row,hdr)
            forward = actual
        elif row['kind']=='down' or event==1482:
            actual = downsample(row,resources[row['inputs']['0']])
            forward = downsample(row,accumulated[row['inputs']['0']])
        else:
            actual = upsample(row,resources[row['inputs']['0']],resources[row['inputs']['1']])
            forward = upsample(row,accumulated[row['inputs']['0']],accumulated[row['inputs']['1']])
        resources[row['resource']] = unpack(word)
        accumulated[row['resource']] = unpack(pack(forward))
        results[event] = dict(independent=score(word,actual),accumulated=score(word,forward))
        print(event,results[event],flush=True)
        name = 'reconstruction-partial.json' if partial else 'reconstruction-results.json'
        (out/name).write_text(json.dumps(results,indent=2)+'\n')
