from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import traceback

import renderdoc as rd

out = Path(os.environ['AZURE_NR_BLOOM_CHAIN'])
request = json.loads((out/'request.json').read_bytes())
report = dict(status='failed',captures={})


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


def run(frame, source):
    file = rd.OpenCaptureFile()
    ctl = None
    try:
        assert file.OpenFile(source['path'],'',None)==rd.ResultCode.Succeeded
        options = rd.ReplayOptions()
        options.forceGPUVendor = rd.GPUVendor.nVidia
        options.forceGPUDeviceID = 0x28e0
        status, ctl = file.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and ctl
        output, = (p.resourceId for p in ctl.GetTextures() if str(p.resourceId)==source['bloom'])
        textures = {p.resourceId:p for p in ctl.GetTextures()}
        actions = {a.eventId:a for a in walk(ctl.GetRootActions())}
        stages = []
        discovered = set()
        collect = lambda rid: [u.eventId for u in ctl.GetUsage(rid)
                               if u.eventId<source['event'] and u.eventId in actions
                               and any(t in str(u.usage) for t in ('RWResource','ColorTarget','CopyDst','ResolveDst'))]
        queue = [(output,source['event'],0)]
        while queue:
            resource, before, level = queue.pop(0)
            key = (resource,before)
            if key in discovered or level>6:
                continue
            discovered.add(key)
            prior = [event for event in collect(resource) if event<before]
            if not prior:
                continue
            event = max(prior)
            action = actions[event]
            ctl.SetFrameEvent(event,True)
            stage = rd.ShaderStage.Compute if action.flags&rd.ActionFlags.Dispatch else rd.ShaderStage.Fragment
            pipe = ctl.GetPipelineState()
            reflect = pipe.GetShaderReflection(stage)
            if not reflect:
                continue
            inputs = []
            for slot in pipe.GetReadOnlyResources(stage):
                rid = slot.descriptor.resource
                tex = textures.get(rid)
                if not tex or tex.width<8 or tex.height<8:
                    continue
                binding = reflect.readOnlyResources[slot.access.index].fixedBindNumber
                inputs.append(dict(binding=binding,id=str(rid),width=tex.width,height=tex.height,format=slot.descriptor.format.Name()))
                if tex.width<=2560 and tex.height<=1440:
                    queue.append((rid,event,level+1))
            rid = textures[resource]
            stages.append(dict(event=event,id=str(resource),width=rid.width,height=rid.height,
                               format=rid.format.Name(),stage=str(stage),inputs=inputs))
            program = bytes(reflect.rawBytes)
            stages[-1]['sha256'] = sha256(program).hexdigest()
            if stage==rd.ShaderStage.Compute:
                stages[-1]['constants'] = {}
                for index, block in enumerate(reflect.constantBlocks):
                    binding = pipe.GetConstantBlock(stage,index,0).descriptor
                    if binding.resource==rd.ResourceId.Null():
                        continue
                    payload = bytes(ctl.GetBufferData(binding.resource,binding.byteOffset,binding.byteSize))
                    name = f'{frame}-{event}-cb{block.fixedBindNumber}.bin'
                    (out/name).write_bytes(payload)
                    stages[-1]['constants'][block.fixedBindNumber]=dict(bytes=len(payload),sha256=sha256(payload).hexdigest(),
                        rows=[list(row) for row in struct.iter_unpack('<4f',payload[:min(len(payload),64)//16*16])])
            assembly = out/f'{frame}-{event}.asm'
            if not assembly.exists():
                assembly.write_text(ctl.DisassembleShader(pipe.GetComputePipelineObject() if stage==rd.ShaderStage.Compute
                    else pipe.GetGraphicsPipelineObject(),reflect,''),encoding='utf8')
        report['captures'][frame] = dict(output=source['bloom'],stages=stages,usage=[
            dict(event=u.eventId,usage=str(u.usage)) for u in ctl.GetUsage(output)])
        assert stages, report['captures'][frame]
    finally:
        if ctl:
            ctl.Shutdown()
        file.Shutdown()


try:
    for frame, source in request.items():
        run(frame,source)
    report['status']='qualified'
except Exception:
    report['error']=traceback.format_exc()
finally:
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)
