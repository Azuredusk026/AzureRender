from hashlib import sha256
from pathlib import Path
from uuid import NAMESPACE_URL,uuid5
import ast,json,runpy,struct
import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
root=run/'iris-overlay-geometry-project'
base=runpy.run_path(str(run/'iris-production-frozen-recovery.py'))
read,dump,invoke=(base[k] for k in ('read','dump','invoke'))
score=runpy.run_path(str(run/'static-quality.py'))
native=run/'native-cloth-authored-textures'
receipt=read(native/'results.json')
assert receipt['status']=='qualified'
out=run/'cloth-native-normal-control'
out.mkdir()
lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==run
def read_function(path,name):
    node,=[n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name]
    env={'np':np}
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),env)
    return env[name]
flip=read_function(run.parent/'20261112-084230-cloth-receiver-authored-mips-a73d87/prepare-fixture.py','flip_bc5_rows')
negate=read_function(run.parent/'20261112-091515-cloth-receiver-normal-y-29da47/prepare-fixture.py','negate_green')
tex=receipt['textures']['21']
w,h=tex['width'],tex['height']
assert tex['format']=='BC5_UNORM' and len(tex['levels'])==max(w,h).bit_length(),tex
head=struct.pack('<31I',124,0xA1007,h,w,tex['levels'][0]['bytes'],0,len(tex['levels']),*([0]*11),32,4,0x30315844,0,0,0,0,0,0x401008,0,0,0,0)
header=b'DDS '+head+struct.pack('<5I',83,3,0,1,0)
parts=[]
for row in tex['levels']:
    data=(native/row['path']).read_bytes()
    assert len(data)==row['bytes'] and sha256(data).hexdigest()==row['sha256']
    i=row['mip']
    nw,nh=max(1,w>>i),max(1,h>>i)
    converted=flip(data,nw,nh)
    assert flip(converted,nw,nh)==data
    parts.append(converted)
def asset_id(name):return str(uuid5(NAMESPACE_URL,'azurerender/cloth-normal-1383/'+name))
def asset(name,negative):
    path=root/'materials'/f'{name}.dds'
    payload=header+b''.join(negate(p) if negative else p for p in parts)
    path.write_bytes(payload)
    dump(path.with_suffix('.dds.azmeta'),dict(schemaVersion=1,id=asset_id(name),dependencies=[],settings=dict(texture=dict(
        schemaVersion=1,usage='normal',colorSpace='linear',mipPolicy='generate',mipFilter='nearest',anisotropy=1,mipBias=-1))))
    return path,asset_id(name)
def variant(texture,mode):
    slot='name:M_actor_laevat_cloth_03'
    level=read(root/'scene/static-eye-shadow-production.azurelevel')
    hero=next(node for node in level['nodes'] if node['id']=='hero')
    old=hero['materialSlots'][slot]
    project=read(root/'eye-shadow-production.azureproject')
    spec=read(root/'materials'/f'{old}.azurematerial')
    material=spec['surface']['materials'][0]
    image=spec['surface']['textures'][material['normalTexture']['index']]['source']
    assert spec['textures'][str(image)]['asset']=='7ae5948e-66b9-5b10-b5c6-c37a9a35c071'
    spec['textures'][str(image)]['asset']=texture
    name='cloth-native-normal-'+mode
    path=root/'materials'/f'{name}.azurematerial'
    dump(path,spec)
    dump(path.with_suffix('.azurematerial.azmeta'),dict(schemaVersion=1,id=asset_id(name),dependencies=[],settings={}))
    hero['materialSlots'][slot]=asset_id(name)
    dump(root/'scene'/f'{name}.azurelevel',level)
    project['startupScene']=f'stage:/{name}.azurelevel'
    file=root/f'{name}.azureproject';dump(file,project)
    return file
def decode(path):
    return np.asarray(Image.open(path).convert('RGB'),dtype=np.int16)
prev=decode(root/'materials/7ae5948e-66b9-5b10-b5c6-c37a9a35c071.png')
points=read(run/'native-face-skin-stages/results.json')['history']['cloth']
x,y=np.array([(p['x'],p['y']) for p in points]).T
assert len(x)==30
reference=score['image'](score['reference_path']).astype(np.int16)
result=dict(native=tex,assets={},devices={})
for negative in (False,True):
    mode='negative-y' if negative else 'source-y'
    path,uid=asset('cloth-authored-normal-'+mode,negative)
    a=decode(path)
    info=dict(sha256=sha256(path.read_bytes()).hexdigest(),baseShape=list(a.shape),hostShape=list(prev.shape))
    if a.shape==prev.shape:
        d=np.abs(a[:,:,:2]-prev[:,:,:2])
        info.update(exactRg=int(np.all(d==0,axis=2).sum()),meanRg=d.mean(axis=(0,1)).tolist(),maximumRg=d.max(axis=(0,1)).tolist())
    result['assets'][mode]=info
    project=variant(uid,mode)
    for device in ('nvidia','intel'):
        row=result['devices'].setdefault(device,{})
        folder=out/f'{mode}-{device}';folder.mkdir()
        command=read(run/f'static-{device}-command.json')
        for flag,value in (('--project',project),('--capture-dir',folder/'frames')):
            command[command.index(flag)+1]=str(value)
        frame=invoke(device,command,folder)/'frame_000000.png'
        actual=score['image'](frame).astype(np.int16)
        baseline_path=run/'cloth-production-color-adjustment-retest'/f'{device}-static-baseline/frames/frame_000000.png'
        baseline=score['image'](baseline_path).astype(np.int16)
        old=np.max(np.abs(baseline-reference),axis=2)
        err=np.max(np.abs(actual-reference),axis=2)
        row[mode]=dict(overEight=int((err[y,x]>8).sum()),peak=int(err[y,x].max()),
            improved=int((err[y,x]<old[y,x]).sum()),worsened=int((err[y,x]>old[y,x]).sum()),
            newFrameOverOne=int(((old<=1)&(err>1)).sum()),frameOverOne=int((err>1).sum()),
            positions=err[y,x].tolist(),sha256=sha256(frame.read_bytes()).hexdigest())
        (out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
