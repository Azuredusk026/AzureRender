from hashlib import sha256
from pathlib import Path
import json,os,traceback
import renderdoc as rd

out=Path(os.environ['AZURE_NR_FACE_SKIN_STAGES'])
job=json.loads((out/'request.json').read_bytes())
cap=rd.OpenCaptureFile()
ctl=None
report=dict(status='failed',textures={})
try:
    assert cap.OpenFile(job['native'],'',None)==rd.ResultCode.Succeeded
    opt=rd.ReplayOptions();opt.forceGPUVendor=rd.GPUVendor.nVidia;opt.forceGPUDeviceID=0x28e0
    status,ctl=cap.OpenCapture(opt,None)
    assert status==rd.ResultCode.Succeeded and ctl
    assert ctl.GetAPIProperties().vendor==rd.GPUVendor.nVidia
    ctl.SetFrameEvent(1383,True)
    pipe=ctl.GetPipelineState()
    ref=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
    textures={item.resourceId:item for item in ctl.GetTextures()}
    for binding in (19,20,21):
        desc=next(row.descriptor for row in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel)
            if ref.readOnlyResources[row.access.index].fixedBindNumber==binding)
        texture=textures[desc.resource]
        levels=[]
        for i in range(texture.mips):
            data=bytes(ctl.GetTextureData(desc.resource,rd.Subresource(i,0,0)))
            path=f't{binding}-mip{i}.bin'
            (out/path).write_bytes(data)
            levels.append(dict(mip=i,bytes=len(data),path=path,sha256=sha256(data).hexdigest()))
        report['textures'][binding]=dict(format=desc.format.Name(),storage=texture.format.Name(),
            resource=str(desc.resource),width=texture.width,height=texture.height,levels=levels)
    report['status']='qualified'
except Exception: report['error']=traceback.format_exc()
finally:
    if ctl: ctl.Shutdown()
    cap.Shutdown()
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)
