from hashlib import sha256
from pathlib import Path
import json
import runpy
import subprocess

import cv2
import numpy as np
from PIL import Image

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
prior = out.parent/'20261114-034155-face-chroma-source-7aa30b'
helpers = runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read, dump, invoke = (helpers[k] for k in ('read','dump','invoke'))
build = helpers['build']
lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==out
source = grid.parents[2]/'shaders/mesh.frag'
sdk = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
resource = out/'resources'
shaders = resource/'shaders'
shaders.mkdir(parents=True)
selected = ('mesh_object_early_lighting.frag.spv','mesh_object_lighting.frag.spv')
rules = [r for r in read(build/'shader-reload.json')['programs'] if r['output'] in selected]
assert len(rules)==len(selected)
for path in (build/'shaders').glob('*.spv'):
    if path.name not in selected:
        (shaders/path.name).hardlink_to(path)
(resource/'runtime-build-Release.json').hardlink_to(build/'runtime-build-Release.json')

code = source.read_text()
marker = '    return characterDiffuseViewTint(base,normal,view,tint);'
assert code.count(marker)==1
replace = '''
    if(AZURE_MATERIAL_CLASS==2U&&materialFeatureEnabled(2048U)>.5) {
        vec2 mask=azureSamplePrimaryUv(AZ_TEX_STYLE_MASK,textureCoordinate).rg;
        vec3 geometry=normalize(worldNormal)*(gl_FrontFacing?1.0:-1.0);
        float maskInfluence=mix(.9988625,1.0,mask.g)*mask.r;
        float weight=clamp(.85*(1.0-clamp(dot(geometry,view),0.0,1.0))*maskInfluence,0.0,1.0);
        return base*mix(vec3(1),vec3(.381326109,.124771841,.138431624),weight);
    }
    return characterDiffuseViewTint(base,normal,view,tint);
'''
frag = out/'face-mask-view-tint.frag'
frag.write_text(code.replace(marker,replace))
hashes = {}
for rule in rules:
    dst = shaders/rule['output']
    subprocess.run([str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+d for d in rule['defines']),
                    '-I'+str(source.parent),str(frag),'-o',str(dst)],check=True)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(dst)],check=True)
    hashes[dst.name]=sha256(dst.read_bytes()).hexdigest()

scorer = runpy.run_path(str(grid/'static-quality.py'))
image = lambda path:scorer['image'](path).astype(np.int16)
ref = image(scorer['reference_path'])
mask = cv2.erode(np.asarray(Image.open(grid/'native-face-masks/face.png').convert('L')),np.ones((13,13),np.uint8))>0
assert int(mask.sum())==1176
report = dict(shaders=hashes,devices={})
for device in ('nvidia','intel'):
    folder = out/device
    folder.mkdir()
    base = prior/f'production-{device}-enabled'
    command = read(base/'command.json')
    for flag,value in (('--capture-dir',folder/'frames'),('--resource-root',resource)):
        command[command.index(flag)+1] = str(value)
    frame = invoke(device,command,folder)/'frame_000000.png'
    old = image(base/'frames/frame_000000.png')-ref
    new = image(frame)-ref
    a,b = [np.abs(f).max(2) for f in (old,new)]
    report['devices'][device] = dict(frame=sha256(frame.read_bytes()).hexdigest(),
        faceOverOne=[int((f[mask]>1).sum()) for f in (a,b)],
        facePeak=[int(f[mask].max()) for f in (a,b)],
        faceMedian=[np.median(f[mask],axis=0).tolist() for f in (old,new)],
        faceMeanAbsolute=[np.abs(f[mask]).mean(0).tolist() for f in (old,new)],
        newOutsideFaceOverOne=int(((a<=1)&(b>1)&~mask).sum()))
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
