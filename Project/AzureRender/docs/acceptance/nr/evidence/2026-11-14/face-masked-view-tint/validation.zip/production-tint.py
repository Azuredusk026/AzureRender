from hashlib import sha256
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5
import json
import runpy
import re

import cv2
import numpy as np
from PIL import Image

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
prior = out.parent/'20261114-034155-face-chroma-source-7aa30b'
fixture = grid/'iris-overlay-geometry-project'
helpers = runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read, dump, invoke = (helpers[k] for k in ('read','dump','invoke'))
release = helpers['build']
lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==out

base_name = 'face-native-main-saturation-production'
baseline_project = fixture/f'{base_name}.azureproject'
project = read(baseline_project)
scene = read(fixture/'scene'/f'{base_name}.azurelevel')
spec = read(fixture/'materials'/f'{base_name}.azurematerial')
npr = spec['surface']['materials'][0]['extras']['azureRenderMaterial']['nprDiffuse']
assert npr['mainBrightnessSaturation'] and 'viewTint' not in npr
# Native e804 illumination blend at the seven traced face pixels.
geometry_scale = .9989546717452598
npr['viewTint'] = dict(schemaVersion=1,scale=.85,color=[.381326109,.124771841,.138431624],
                     mode='face-mask',geometryScale=geometry_scale)
name = 'face-native-mask-tint-production'
identity = str(uuid5(NAMESPACE_URL,'azurerender/804/'+name))
def keep_fixture(path,data):
    if path.exists():
        assert read(path)==data, path
    else:
        dump(path,data)


path = fixture/'materials'/f'{name}.azurematerial'
keep_fixture(path,spec)
keep_fixture(path.with_suffix('.azurematerial.azmeta'),dict(schemaVersion=1,id=identity,dependencies=[],settings={}))
next(n for n in scene['nodes'] if n['id']=='hero')['materialSlots']['name:M_actor_laevat_face_01']=identity
keep_fixture(fixture/'scene'/f'{name}.azurelevel',scene)
project['startupScene']=f'stage:/{name}.azurelevel'
candidate_project = fixture/f'{name}.azureproject'
keep_fixture(candidate_project,project)

scorer = runpy.run_path(str(grid/'static-quality.py'))
image = lambda path:scorer['image'](path).astype(np.int16)
digest = lambda path:sha256(path.read_bytes()).hexdigest()
reference = image(scorer['reference_path'])
mask = cv2.erode(np.asarray(Image.open(grid/'native-face-masks/face.png').convert('L')),np.ones((13,13),np.uint8))>0
assert int(mask.sum())==1176
results = dict(playerSha256=digest(release/'AzurePlayer.exe'),geometryScale=geometry_scale,devices={})
for device in ('nvidia','intel'):
    row = results['devices'][device]={}
    baseline = prior/f'production-{device}-enabled'
    for label,path in (('disabled',baseline_project),('enabled',candidate_project)):
        target = out/f'production-{device}-{label}'
        target.mkdir(exist_ok=True)
        command = read(baseline/'command.json')
        command[command.index('--project')+1]=str(path)
        command[command.index('--capture-dir')+1]=str(target/'frames')
        frame = target/'frames/frame_000000.png'
        if frame.exists():
            assert read(target/'command.json')==command
            log = (target/'player.log').read_text(errors='replace')
            assert 'Allocator after unload: buffers=0 images=0' in log
            assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I)
            assert read(frame.parent/'gpu_capabilities.json')['vendor_id']==(0x10de if device=='nvidia' else 0x8086)
        else:
            frame = invoke(device,command,target)/frame.name
        pixels = image(frame)
        signed = pixels-reference
        error = np.abs(signed).max(2)
        expected = (baseline if label=='disabled' else out/device)/'frames/frame_000000.png'
        difference = np.abs(pixels-image(expected)).max(2)
        row[label] = dict(frame=digest(frame),overOne=int((error[mask]>1).sum()),
            peak=int(error[mask].max()),median=np.median(signed[mask],axis=0).tolist(),
            overEight=int((error[mask]>8).sum()),expected=digest(expected),exact=not difference.any(),
            pixelsDifferent=int((difference>0).sum()),maximumDifference=int(difference.max()))
        if label=='disabled':
            baseline_error = error
        else:
            row[label]['newOutsideFaceOverOne'] = int(((baseline_error<=1)&(error>1)&~mask).sum())
        (out/'production-tint-results.json').write_text(json.dumps(results,indent=2)+'\n')
        if label=='disabled':
            assert row[label]['exact'], (device,label,row[label])
        else:
            assert row[label]['peak']==4 and row[label]['overOne']<row['disabled']['overOne'], row
            assert row[label]['newOutsideFaceOverOne']==0 and row[label]['maximumDifference']<=1, row
