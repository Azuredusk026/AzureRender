from copy import deepcopy
from hashlib import sha256
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5
import json
import os
import runpy
import struct
import sys

import numpy as np
from PIL import Image
from io import BytesIO

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
fixture = grid/'iris-overlay-geometry-project'
helpers = runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read, dump, invoke = (helpers[k] for k in ('read','dump','invoke'))
inputs = grid/'native-body-outline-input-retest'
scope = read(inputs/'results.json')
source = fixture/'character/captured-opaque-overlays.glb'
name = 'body-native-lit-outline-production'
slot = 'M_actor_laevat_body_01'
new_slot = slot+'_lit_outline'
uid = lambda label:str(uuid5(NAMESPACE_URL,'azurerender/body-outline-lit/'+label))


def author_material(scene):
    hero = next(n for n in scene['nodes'] if n['id']=='hero')
    original = hero['materialSlots']['name:'+slot]
    document = read(fixture/'materials'/f'{original}.azurematerial')
    material = document['surface']['materials'][0]
    material['doubleSided'] = False
    material['name'] = new_slot
    profile = material['extras']['azureRenderMaterial']
    profile['features'] = [f for f in profile['features'] if f not in ('silhouette-outline','geometry-shadow')]
    profile['nprDiffuse']['lightingNormal'] = 'screen-surface'
    profile['nprDiffuse']['shadowSaturation'] = 1.4
    profile['outlineSurface'] = dict(schemaVersion=1,mode='view-scaled',target='surface',
        width=.6,minimumPixels=.5,depthOffset=.008,coverage='depth-tested',
        normalSource='tangent-uv1')
    textures = document['surface']['textures']
    images = document['textures']
    profile['outlineSurface']['maskTexture'] = len(textures)
    textures.append(dict(source=len(images)))
    images[str(len(images))] = dict(asset=uid('width-depth'),usage='linear')
    mask = fixture/'materials'/f'{name}-mask.png'
    Image.new('RGBA',(1,1),(255,255,0,255)).save(mask)
    dump(mask.with_suffix('.png.azmeta'),dict(schemaVersion=1,id=uid('width-depth'),dependencies=[],
        settings=dict(texture=dict(schemaVersion=1,usage='mask',colorSpace='linear',filter='linear',
                                   wrapU='clamp',wrapV='clamp',mipPolicy='none',anisotropy=1))))
    original_image = images['0']['asset']
    path = fixture/'materials'/f'{original_image}.dds'
    author_albedo(path,fixture/'materials'/f'{name}-albedo.dds')
    images['0']['asset'] = uid('line-albedo')
    identity = uid('material')
    material_path = fixture/'materials'/f'{name}.azurematerial'
    dump(material_path,document)
    dump(material_path.with_suffix('.azurematerial.azmeta'),dict(schemaVersion=1,id=identity,
         dependencies=[],settings={}))
    hero['materialSlots']['name:'+new_slot] = identity


def author_albedo(source,target):
    data = source.read_bytes()
    header = bytearray(data[:148])
    height,width = struct.unpack_from('<2I',data,12)
    levels = struct.unpack_from('<I',data,28)[0]
    assert (width,height,levels,struct.unpack_from('<I',data,128)[0])==(1024,1024,11,99)
    metadata = read(source.with_suffix('.dds.azmeta'))
    metadata['id'] = uid('line-albedo')
    struct.pack_into('<I',header,20,width*4)
    struct.pack_into('<I',header,128,29)
    luma = np.asarray([.212673,.715152,.072175])
    offset = 148
    with target.open('xb') as f:
        f.write(header)
        for level in range(levels):
            w,h = max(1,width>>level),max(1,height>>level)
            length = ((w+3)//4)*((h+3)//4)*16
            local_header = bytearray(data[:148])
            struct.pack_into('<3I',local_header,12,h,w,length)
            struct.pack_into('<I',local_header,28,1)
            with Image.open(BytesIO(bytes(local_header)+data[offset:offset+length])) as image:
                rgba = np.array(image)
            offset += length
            srgb = rgba[...,:3]/255
            linear = np.where(srgb<=.04045,srgb/12.92,((srgb+.055)/1.055)**2.4)*.5
            luminance = (linear@luma)[...,None]
            tinted = np.maximum(0,luminance+1.5*(linear-luminance))
            srgb = np.where(tinted<=.0031308,tinted*12.92,1.055*tinted**(1/2.4)-.055)
            rgba[...,:3] = np.rint(np.clip(srgb,0,1)*255).astype(np.uint8)
            f.write(rgba.tobytes())
    assert offset==len(data), (offset,len(data))
    dump(target.with_suffix('.dds.azmeta'),metadata)


def author_mesh():
    path = fixture/'character'/f'{name}.gltf'
    with source.open('rb') as f:
        magic,version,total,json_length,json_type = struct.unpack('<5I',f.read(20))
        assert (magic,version,json_type)==(0x46546C67,2,0x4E4F534A)
        document = json.loads(f.read(json_length))
        size,kind = struct.unpack('<2I',f.read(8))
        assert kind==0x004E4942
        start = f.tell()
        meshes = [mesh for mesh in document['meshes'] if any(
            document['materials'][p['material']]['name']==slot for p in mesh['primitives'])]
        mesh, = meshes
        original, = (p for p in mesh['primitives'] if document['materials'][p['material']]['name']==slot)
        prim = deepcopy(original)
        indices = deepcopy(document['accessors'][prim['indices']])
        view = document['bufferViews'][indices['bufferView']]
        assert indices['componentType']==5125 and indices['count']==17037 and 'byteStride' not in view
        f.seek(start+view.get('byteOffset',0)+indices.get('byteOffset',0))
        winding = np.frombuffer(f.read(indices['count']*4),'<u4').reshape(-1,3)[:,[0,2,1]].copy()
    for view in document['bufferViews']:
        assert view['buffer']==0
        view['byteOffset'] = view.get('byteOffset',0)+start
    document['buffers'][0] = dict(uri=source.name,byteLength=total)
    length = document['accessors'][prim['attributes']['POSITION']]['count']
    stream = next(row for row in scope['bindings'] if row['index']==1)
    stream_path = inputs/stream['path']
    assert sha256(stream_path.read_bytes()).hexdigest()==stream['sha256'] and length==3289
    coords = np.fromfile(stream_path,'i1').reshape(-1,stream['stride'])[:length,8:10].astype('<f4')/127
    binary = path.with_suffix('.bin')
    payload = winding.tobytes()+coords.tobytes()
    binary.write_bytes(payload)
    document['buffers'].append(dict(uri=binary.name,byteLength=len(payload)))
    views = document['bufferViews']
    access = document['accessors']
    for attrib,part,offset in [('indices',winding,0),('TEXCOORD_1',coords,winding.nbytes)]:
        view_index = len(views)
        views.append(dict(buffer=1,byteOffset=offset,byteLength=part.nbytes))
        accessor_index = len(access)
        if attrib=='indices':
            indices.update(bufferView=view_index,byteOffset=0)
            access.append(indices)
            prim['indices'] = accessor_index
        else:
            access.append(dict(bufferView=view_index,componentType=5126,count=length,type='VEC2'))
            prim['attributes'][attrib] = accessor_index
    material = deepcopy(document['materials'][prim['material']])
    material['name'] = new_slot
    material['doubleSided'] = False
    prim['material'] = len(document['materials'])
    document['materials'].append(material)
    mesh['primitives'].append(prim)
    (out/path.name).write_text(json.dumps(document,separators=(',',':')),encoding='utf8')
    dump(path.with_suffix('.gltf.azmeta'),dict(schemaVersion=1,id=uid('asset'),dependencies=[],settings={}))
    return path


def run():
    lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    prepare_only = '--prepare' in sys.argv
    if not prepare_only:
        assert lock['state']=='held' and Path(lock['output'])==out
    base = 'face-native-mask-tint-production'
    project = read(fixture/f'{base}.azureproject')
    scene = read(fixture/'scene'/f'{base}.azurelevel')
    candidate = fixture/f'{name}.azureproject'
    if not (out/candidate.name).exists():
        model = author_mesh()
        next(item for item in scene['resources'] if item['id']=='hero')['asset'] = 'character:/'+model.name
        author_material(scene)
        dump(out/f'{name}.azurelevel',scene)
        project['startupScene'] = f'stage:/{name}.azurelevel'
        dump(out/candidate.name,project)
    if prepare_only:
        return
    staged_model = out/f'{name}.gltf'
    mounted_model = fixture/'character'/staged_model.name
    level = fixture/'scene'/f'{name}.azurelevel'
    mounts = [(mounted_model,staged_model),(level,out/level.name),(candidate,out/candidate.name)]
    try:
        for target,source in mounts:
            target.hardlink_to(source)
        compare(candidate)
    finally:
        for target,source in reversed(mounts):
            if target.exists() and os.path.samefile(source,target):
                target.unlink()
        for target,_ in mounts:
            sidecar = target.with_suffix(target.suffix+'.azmeta')
            if sidecar.exists() and target.suffix!='.gltf':
                staged = out/sidecar.name
                if not staged.exists():
                    sidecar.replace(staged)


def compare(candidate):
    compare = runpy.run_path(str(grid/'static-quality.py'))
    image = lambda p:compare['image'](p).astype(np.int16)
    ref = image(compare['reference_path'])
    priority = np.asarray(read(grid/'face-skin-overlay-ownership.json')['skin']['1018']['locations'],np.int32)
    shape = (1440,2560,2)
    depth = grid/'native-body-outline-depth'
    pre = np.fromfile(depth/'depth-1017.bin','<u4').reshape(shape)[::-1]
    post = np.fromfile(depth/'depth-1018.bin','<u4').reshape(shape)[::-1]
    coverage = pre[:,:,0]!=post[:,:,0]
    assert len(priority)==61 and int(coverage.sum())==1184
    results = dict(devices={})
    for device in ('nvidia','intel'):
        folder = out/device
        folder.mkdir(exist_ok=True)
        tint = out.parent/'20261114-042314-face-mask-native-tint-bb8d53'/f'production-{device}-enabled'
        command = read(tint/'command.json')
        command[command.index('--project')+1] = str(candidate)
        command[command.index('--capture-dir')+1] = str(folder/'frames')
        frame = folder/'frames/frame_000000.png'
        if not frame.exists():
            frame = invoke(device,command,folder)/frame.name
        before = image(tint/'frames/frame_000000.png')
        after = image(frame)
        b = np.abs(before-ref).max(2)
        a = np.abs(after-ref).max(2)
        x,y = priority.T
        assert coverage[y,x].all()
        change = np.abs(before-after).max(2)
        results['devices'][device] = dict(focusImproved=int((a[y,x]<b[y,x]).sum()),
            focusChanged=int((change[y,x]>0).sum()),nativeCoverage=int(coverage.sum()),
            nativeCoverageChanged=int((change[coverage]>0).sum()),
            nativeCoverageChangedOverOne=int((change[coverage]>1).sum()),
            nativeCoverageImproved=int((a[coverage]<b[coverage]).sum()),
            nativeCoverageOverEight=[int((err[coverage]>8).sum()) for err in (b,a)],
            focusOverEight=[int((err[y,x]>8).sum()) for err in (b,a)],
            focusPeak=[int(err[y,x].max()) for err in (b,a)],
            changedPixels=int((before!=after).any(2).sum()),
            newGlobalOverOne=int(((b<=1)&(a>1)).sum()))
        (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')


if __name__=='__main__':
    run()
