from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from hashlib import sha256
import json
import re

out = Path(__file__).resolve().parent
repo = out.parents[2]
target = repo/'docs/acceptance/nr/evidence/2026-11-14/body-outline-lit-surface'
target.mkdir(parents=True,exist_ok=True)
read = lambda path:json.loads(path.read_bytes())
result = read(out/'rescored.json')
result.update(overallStatus='failed-user-review',coverageIntersection=read(out/'coverage-intersection.json'))
for device,data in result['devices'].items():
    assert data['focusImproved']==61 and data['focusPeak']==[44,5]
    assert data['nativeCoverageChanged']==571 and data['changedPixels']==571
    log = (out/device/'player.log').read_text(errors='replace')
    assert 'Allocator after unload: buffers=0 images=0' in log
    assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I)
    data['frameSha256'] = sha256((out/device/'frames/frame_000000.png').read_bytes()).hexdigest()
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n')
with ZipFile(target/'validation.zip','w',compression=ZIP_DEFLATED,compresslevel=8) as archive:
    for path in sorted(out.iterdir()):
        if path.is_file() and path.suffix in ('.py','.azureproject','.azurelevel','.json'):
            archive.write(path,path.name)
    for device in result['devices']:
        for name in ('command.json','player.log','frames/capture_manifest.json','frames/gpu_capabilities.json'):
            archive.write(out/device/name,f'{device}/{name}')
with ZipFile(target/'validation.zip') as archive:
    assert archive.testzip() is None
