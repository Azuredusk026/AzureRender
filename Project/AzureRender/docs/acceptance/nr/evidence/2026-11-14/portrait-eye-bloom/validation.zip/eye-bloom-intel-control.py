from pathlib import Path
import json
import os
import re
import runpy
import subprocess

import numpy as np

run=Path(__file__).resolve().parent
score=runpy.run_path(str(run/"static-quality.py"))
main=Path("D:/Projects/FYP/Project/AzureRender")
source=main/"build/runs/20261101-043757-material-display-transform-93d6e0"
baseline=json.loads((source/"native-final-comparison.json").read_text())["comparisons"][1]
reference_path=Path(baseline["reference"])
assert score["sha"](reference_path)==baseline["referenceSha256"]
reference=score["image"](reference_path)
control=source/"native-final-captures/near-linear-isolated/frames/frame_000000.png"
build=run.parent/"20261110-030251-hair-main-chroma-public-9e799c/release"
status=json.loads(Path("D:/Projects/FYP-coordination/resources/current.json").read_text())
assert status["state"]=="held" and Path(status["output"])==run
known=json.loads((run/'iris-production-catalog.json').read_bytes())
assert score['sha'](build/'AzurePlayer.exe')==known['playerSha256']
assert all(score['sha'](build/'shaders'/name)==value for name,value in known['shaders'].items())
base=json.loads((run/"portrait-intel-command.json").read_text())
folder=run/"eye-bloom-intel-control"
folder.mkdir()
command=base.copy()
command[command.index("--capture-dir")+1]=str(folder/"frames")
command[command.index("--runtime-report")+1]=str(folder/"runtime.json")
command.extend(("--qa-effect","bloom","--qa-effect-state","disabled"))
env=os.environ.copy()
for key in ("VK_DRIVER_FILES","VK_ICD_FILENAMES","VK_LAYER_ENABLES"):
    env.pop(key,None)
env.update(VK_LOADER_DRIVERS_SELECT="*igvk64*",VK_INSTANCE_LAYERS="VK_LAYER_KHRONOS_validation",
           VK_LAYER_VALIDATE_SYNC="1")
(folder/"command.json").write_text(json.dumps(command,indent=2)+"\n")
with (folder/"player.log").open("wb") as log:
    result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
log=(folder/"player.log").read_text(errors="replace")
assert result.returncode==0 and "Allocator after unload: buffers=0 images=0" in log,log[-4000:]
assert not re.search(r"VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]",log,re.I),log[-4000:]
gpu=json.loads((folder/"frames/gpu_capabilities.json").read_text())
assert gpu["vendor_id"]==0x8086
world=run/"portrait-intel-frames/frame_000000.png"
disabled=folder/"frames/frame_000000.png"
x,y,u,v=baseline["regions"][4]["bounds"]
target=reference[y:v,x:u].astype(np.int16)
def metrics(path):
    frame=score["image"](path)
    err=np.abs(frame[y:v,x:u].astype(np.int16)-target).max(axis=2)
    return dict(sha256=score["sha"](path),overOne=int((err>1).sum()),maximum=int(err.max()),
                peakBlue=int(frame[808,667,2]))
report=dict(referenceSha256=baseline["referenceSha256"],world=metrics(world),bloomDisabled=metrics(disabled),
            isolated=metrics(control))
assert report["world"]["overOne"]==415 and report["isolated"]["overOne"]==0
(folder/"results.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report))

