from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import traceback

out = Path(os.environ['AZURE_NR_OVERLAY_OUTPUT']) if 'AZURE_NR_OVERLAY_OUTPUT' in os.environ else Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda path:json.loads(path.read_bytes())
receipt=out/'face-residual-replay.json'
request=grid/'native-face-masks/request.json'


def worker():
    import renderdoc as rd
    job=read(out/'face-residual-replay-request.json')
    result=dict(status='failed',sources={})
    for side,path in job['captures'].items():
        cap=rd.OpenCaptureFile();ctl=None
        try:
            assert cap.OpenFile(path,'',None)==rd.ResultCode.Succeeded
            options=rd.ReplayOptions();options.forceGPUVendor=rd.GPUVendor.nVidia;options.forceGPUDeviceID=0x28e0
            state,ctl=cap.OpenCapture(options,None)
            assert state==rd.ResultCode.Succeeded and ctl is not None
            prop=ctl.GetAPIProperties()
            assert prop.vendor==rd.GPUVendor.nVidia and not prop.degraded
            assert prop.pipelineType==(rd.GraphicsAPI.D3D11 if side=='native' else rd.GraphicsAPI.Vulkan)
            seed=804 if side=='native' else 876
            ctl.SetFrameEvent(seed,True)
            target=ctl.GetPipelineState().GetOutputTargets()[0].resource
            tex,=[t for t in ctl.GetTextures() if t.resourceId==target]
            assert (tex.width,tex.height)==(2560,1440)
            rows=[]
            for x,y in job['points']:
                loc=1439-y if side=='native' else y
                history=ctl.PixelHistory(target,x,loc,rd.Subresource(),rd.CompType.Typeless)
                def rgba(v):return list(v.col.floatValue)[:4]
                rows.append(dict(point=[x,y],history=[dict(event=h.eventId,primitive=h.primitiveID,passed=h.Passed(),
                    depthFailed=h.depthTestFailed,stencilFailed=h.stencilTestFailed,cull=h.backfaceCulled,
                    discarded=h.shaderDiscarded,before=rgba(h.preMod),after=rgba(h.postMod),shader=rgba(h.shaderOut))
                    for h in history if h.eventId>=seed-20]))
            seen = sum(any(h['event'] == seed for h in row['history']) for row in rows)
            assert seen == len(rows) if side == 'native' else seen > 0
            result['sources'][side]=dict(event=seed,format=tex.format.Name(),target=str(target),points=rows,
                                          seedPresent=seen,seedAbsent=len(rows)-seen)
        except Exception:
            result['error']=traceback.format_exc()
            break
        finally:
            if ctl:ctl.Shutdown()
            cap.Shutdown()
    if len(result['sources'])==2:result['status']='qualified'
    receipt.write_text(json.dumps(result,indent=2)+'\n')
    os._exit(0 if result['status']=='qualified' else 1)


def launch():
    from hashlib import file_digest
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==out
    source=read(request)
    captures=dict(native=source['native'],vulkan=str(grid/'iris-overlay-player-rdc/overlay_frame1.rdc'))
    known=dict(native=source['captureSha256'],vulkan='6960267c0d71e4d05b6bfe0e2730c332ed71955f1fde6d69eb7d8aadf13eff24')
    for side,path in captures.items():
        with Path(path).open('rb') as stream:assert file_digest(stream,'sha256').hexdigest()==known[side]
    points=[row['point'] for row in read(out/'face-native-factor-control.json')['devices']['nvidia']['outsideLocations'][:12]]
    job=dict(captures=captures,sha256=known,points=points)
    (out/'face-residual-replay-request.json').write_text(json.dumps(job,indent=2)+'\n')
    env=dict(os.environ,AZURE_NR_OVERLAY_OUTPUT=str(out),AZURE_NR_FACE_RESIDUAL_WORKER='1',VK_DRIVER_FILES=str(grid/'nv-vk64-active-absolute.json'))
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    with (out/'face-residual-replay.log').open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__))],
                             cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=300)
    result=read(receipt)
    assert child.returncode==0 and result['status']=='qualified',result.get('error')


if os.environ.get('AZURE_NR_FACE_RESIDUAL_WORKER')=='1':worker()
elif __name__=='__main__':launch()
