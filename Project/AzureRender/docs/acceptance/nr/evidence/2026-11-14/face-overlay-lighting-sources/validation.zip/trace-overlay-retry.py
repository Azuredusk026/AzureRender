from hashlib import sha256
from pathlib import Path
import gzip
import json
import os
import subprocess
import sys
import traceback

out = Path(os.environ['AZURE_NR_OVERLAY_OUTPUT']) if 'AZURE_NR_OVERLAY_OUTPUT' in os.environ else Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
parent=out.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'


def replay():
    def phase(text):
        with (out/'native-overlay-trace-progress.log').open('a', encoding='utf8') as stream:
            print(text, file=stream)
    phase('worker entered')
    import renderdoc as rd
    phase('module imported')
    job=read(out/'native-overlay-trace-retry-request.json')
    events={'1230':(221,416,420,424,427),'1245':(221,416,420,424,427),'1358':(226,421,425,429,432)}
    sources={}
    cap=rd.OpenCaptureFile()
    ctl=None
    result=dict(status='failed')
    try:
        assert cap.OpenFile(job['native'],'',None)==rd.ResultCode.Succeeded
        opt=rd.ReplayOptions();opt.forceGPUVendor=rd.GPUVendor.nVidia;opt.forceGPUDeviceID=0x28e0
        phase('capture file opened')
        status,ctl=cap.OpenCapture(opt,None)
        phase(f'replay opened: {status}')
        assert status==rd.ResultCode.Succeeded and ctl
        assert ctl.GetAPIProperties().vendor==rd.GPUVendor.nVidia and not ctl.GetAPIProperties().degraded
        for event,points in job['points'].items():
            phase(f'event {event}')
            ctl.SetFrameEvent(int(event),True)
            pipe=ctl.GetPipelineState()
            stage=rd.ShaderStage.Fragment
            pixel=pipe.GetShaderReflection(stage)
            assert sha256(bytes(pixel.rawBytes)).hexdigest()==job['programs'][event]
            constants={}
            for i,block in enumerate(pixel.constantBlocks):
                if block.fixedBindNumber not in (1,4):continue
                bound=pipe.GetConstantBlock(stage,i,0).descriptor
                raw=bytes(ctl.GetBufferData(bound.resource,bound.byteOffset,bound.byteSize))
                file=out/f'event-{event}-cb{block.fixedBindNumber}.bin'
                file.write_bytes(raw)
                constants[block.fixedBindNumber]=dict(path=file.name,sha256=sha256(raw).hexdigest())
            target=pipe.GetOutputTargets()[0].resource
            depth=pipe.GetDepthTarget().resource
            scope=job['filmBounds'][event]
            depthCrops={}
            for offset in (-1,0):
                marker=int(event)+offset
                ctl.SetFrameEvent(marker,True)
                raw=bytes(ctl.GetTextureData(depth,rd.Subresource()))
                stride=len(raw)//(2560*1440)
                assert len(raw)==2560*1440*stride and stride in (4,8)
                x0,y0,x1,y1=scope
                samples=b''.join(raw[(v*2560+x0)*stride:(v*2560+x1)*stride] for v in range(1440-y1,1440-y0))
                path=out/f'overlay-{marker}-depth-crop.bin'
                path.write_bytes(samples)
                depthCrops[marker]=dict(stride=stride,path=path.name,sha256=sha256(samples).hexdigest(),
                                         bounds=scope,rows='native-bottom-up')
            ctl.SetFrameEvent(int(event),True)
            beforeFog,afterFog,_,_,beforeOutput=events[event]
            captureSteps={12,13,14,15,16,17,18,35,219,220,221,222,223,224,225,226,227,
                          beforeFog,afterFog,beforeOutput,*range(afterFog,afterFog+12)}
            rows=[]
            for x,y in points:
                phase(f'point {x},{y}')
                hits=[r for r in ctl.PixelHistory(target,x,1439-y,rd.Subresource(),rd.CompType.Typeless)
                      if r.eventId==int(event) and r.Passed()]
                assert hits,(event,x,y)
                hit=hits[-1]
                args=rd.DebugPixelInputs();args.primitive=hit.primitiveID
                trace=ctl.DebugPixel(x,1439-y,args)
                assert trace and trace.debugger,(event,x,y,hit.primitiveID)
                registers={};states={};count=0
                try:
                    while True:
                        batch=ctl.ContinueDebug(trace.debugger)
                        if not batch:break
                        for entry in batch:
                            for item in entry.changes:
                                if item.after.name:
                                    registers[item.after.name]=list(item.after.value.f32v)[:4]
                            index=int(entry.nextInstruction)
                            if index in captureSteps:
                                states[index]={k:list(v) for k,v in registers.items() if k in ('r0','r1','r2','r3','r4','o0')}
                            count+=1
                    assert 0<count<20000
                finally:
                    ctl.FreeTrace(trace)
                assert 13 in states and (afterFog in states or beforeOutput in states),(event,x,y,sorted(states))
                rows.append(dict(x=x,y=y,primitive=hit.primitiveID,hardware=list(hit.shaderOut.col.floatValue)[:4],
                                 registers=states,steps=count))
            sources[event]=dict(samples=rows,depth=str(depth),depthCrops=depthCrops,constants=constants,checkpoints=list(events[event]))
        result.update(status='qualified',events=sources)
    except Exception:result['error']=traceback.format_exc()
    finally:
        if ctl:ctl.Shutdown()
        cap.Shutdown()
        write(out/'native-overlay-trace-retry.json',result)
    os._exit(0 if result['status']=='qualified' else 1)


def launch():
    from hashlib import file_digest
    import numpy as np
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==out
    request=read(parent/'late-overlay-request.json')
    with Path(request['native']).open('rb') as f:
        assert file_digest(f,'sha256').hexdigest()==request['captureSha256']
    ownership=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/post-opaque-ownership')
    native=read(parent/'late-overlay-replay.json')['native']
    footprints=read(parent/'overlay-footprint.json')
    bounds={}
    points={}
    for event in (1230,1245,1358):
        a,b=[np.frombuffer(gzip.decompress((ownership/f'{event}-{i}.bin.gz').read_bytes()),'<u4').reshape(1440,2560)[::-1]
             for i in (event-1,event)]
        y,x=np.where(a!=b)
        assert len(x)=={1230:41,1245:95,1358:266}[event]
        choice=np.linspace(0,len(x)-1,9,dtype=int)
        points[event]=np.column_stack((x[choice],y[choice])).tolist()
        film=(np.asarray(footprints[str(event)]['filmBoundsNdc'])+1)*[1280,720]
        lo=np.floor(film[0]).astype(int)-2
        hi=np.ceil(film[1]).astype(int)+2
        assert (lo>0).all() and (hi<[2560,1440]).all()
        assert (np.column_stack((x,y))>=lo).all() and (np.column_stack((x,y))<hi).all()
        bounds[event]=[*lo.tolist(),*hi.tolist()]
    request.update(points=points,programs={str(e):native[str(e)]['shader'] for e in points},filmBounds=bounds)
    write(out/'native-overlay-trace-retry-request.json',request)
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    with (out/'native-overlay-trace-retry.log').open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__))],
                             cwd=out,env=dict(os.environ,AZURE_NR_OVERLAY_OUTPUT=str(out),AZURE_NR_OVERLAY_TRACE_HOST='1'),stdout=log,
                             stderr=subprocess.STDOUT,startupinfo=startup,timeout=590)
    result=read(out/'native-overlay-trace-retry.json')
    assert child.returncode==0 and result['status']=='qualified',result.get('error')
    print({e:len(row['samples']) for e,row in result['events'].items()})


if os.environ.get('AZURE_NR_OVERLAY_TRACE_HOST')=='1':
    replay()
elif __name__=='__main__':
    launch()
