from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

out=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
record=read(out/'face-native-lanes-summary.json')
assert sorted(record['overlay'])==['1230','1245','1358']
assert all(row['maxBlendError']<1e-6 for row in record['overlay'].values())
assert all(row['count']==12 for row in record['faceBaseOwners'].values())
archive_dir=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/face-overlay-lighting-sources'
archive_dir.mkdir(parents=True,exist_ok=False)
archive=archive_dir/'validation.zip'
names=['trace-overlay-retry.py','native-overlay-trace-retry-request.json','native-overlay-trace-retry.json',
       'verify-embedded-import.py','native-overlay-embedded-import.json','face-residual-replay.py',
       'face-residual-replay-request.json','face-residual-replay.json','summarize-face-native-lanes.py',Path(__file__).name]
for event in record['overlay']:
    names += [f'event-{event}-cb{index}.bin' for index in (1,4)]
    names += [f'overlay-{index}-depth-crop.bin' for index in (int(event)-1,int(event))]
with ZipFile(archive,'x',ZIP_DEFLATED) as z:
    for n in names:z.write(out/n,n)
with ZipFile(archive) as z:
    assert z.testzip() is None and z.namelist()==names
record['archive']=dict(sha256=sha256(archive.read_bytes()).hexdigest(),members=len(names))
(archive_dir/'results.json').write_text(json.dumps(record,indent=2)+'\n')
print(record['archive'])

