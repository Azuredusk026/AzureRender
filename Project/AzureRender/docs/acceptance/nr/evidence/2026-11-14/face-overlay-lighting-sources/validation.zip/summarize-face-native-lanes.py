from hashlib import sha256
from pathlib import Path
import json
import struct

out=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
diagnostic=read(out/'native-overlay-trace-retry.json')
request=read(out/'native-overlay-trace-retry-request.json')
assert diagnostic['status']=='qualified'
record={}
for event,r in diagnostic['events'].items():
    paths={key:out/file['path'] for key,file in r['constants'].items()}
    for key,p in paths.items():
        assert sha256(p.read_bytes()).hexdigest()==r['constants'][key]['sha256']
    raw=paths['1'].read_bytes()
    bias=struct.unpack_from('<f',raw,26*16)[0]
    fogEnabled=struct.unpack_from('<f',raw,122*16+12)[0]<.5
    c=paths['4'].read_bytes()
    tint=struct.unpack_from('<3f',c,32)
    samples=[]
    for s in r['samples']:
        before,after,_,_,end=map(str,r['checkpoints'])
        n=s['registers']
        coverage=n['18']['r2'][3]
        assert coverage>0
        pre=n[before]['r4'][3]
        post=n[after]['r4'][3]
        hardware=s['hardware']
        trace=n[end]['r4']
        validate=max(abs(h-k) for h,k in zip(hardware,trace))
        reconstructed=[1+(channel-1)*post for channel in tint]
        error=max(abs(h-k) for h,k in zip(hardware,reconstructed))
        assert validate<2e-6 and error<2e-6
        samples.append(dict(point=[s['x'],s['y']],primitive=s['primitive'],textureCoverage=coverage,localFactor=pre/coverage,
            fogAbsoluteChange=abs(pre-post),blendReconstructionError=error,hardwareAgreement=validate))
    assert len(samples)==9
    move=max(s['fogAbsoluteChange'] for s in samples)
    assert move<1e-6
    record[event]=dict(tint=tint,samplingBias=bias,fogBranchEnabled=fogEnabled,maxFogAbsoluteChange=move,
                       localFactorRange=[min(s['localFactor'] for s in samples),max(s['localFactor'] for s in samples)],
                       maxBlendError=max(s['blendReconstructionError'] for s in samples),samples=samples,sourcePrograms=request['programs'][event])
edge=read(out/'face-residual-replay.json')
assert edge['status']=='qualified'
err=read(out/'face-native-factor-control.json')['devices']['nvidia']['outsideLocations'][:12]
owners={}
for side,s in edge['sources'].items():
    values=[]
    for r in s['points']:
        active=[h for h in r['history'] if h['passed'] and h['before']!=h['after']]
        assert [h['event'] for h in active]==[s['event']],(side,r['point'],active)
        values.append(dict(point=r['point'],primitive=active[0]['primitive'],rgb=active[0]['shader'][:3]))
    assert [r['point'] for r in values]==[r['point'] for r in err]
    owners[side]=dict(event=s['event'],count=len(values),format=s['format'],points=values)
report=dict(status='source-attribution',overallStatus='failed-user-review',overlay=record,faceBaseOwners=owners)
(out/'face-native-lanes-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:(v['samplingBias'],v['localFactorRange'],v['maxFogAbsoluteChange'],v['maxBlendError']) for k,v in record.items()})
print({k:v['count'] for k,v in owners.items()})

