import hashlib
import json
import os
from pathlib import Path
import sys

from importlib.util import spec_from_file_location, module_from_spec

out = Path(os.environ['AZURE_NR_OVERLAY_OUTPUT']) if 'AZURE_NR_OVERLAY_OUTPUT' in os.environ else Path(__file__).resolve().parent
files = [out/'trace-overlay-retry.py', out/'face-residual-replay.py']
results = {}
for index, path in enumerate(files):
    spec = spec_from_file_location(f'dry_import_{index}', path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    results[path.name] = {'launch': callable(module.launch),
                          'embeddedWorker': callable(getattr(module, 'replay', getattr(module, 'worker', None)))}
data={'python':sys.version,'hashlibFileDigest':hasattr(hashlib,'file_digest'),'modules':results}
(out/'native-overlay-embedded-import.json').write_text(json.dumps(data,indent=2)+'\n')
os._exit(0 if all(all(row.values()) for row in results.values()) else 1)

