from hashlib import sha256
from pathlib import Path
import json
import numpy as np

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
def read(name):
    p = grid/name
    payload = p.read_bytes()
    inputs[name] = sha256(payload).hexdigest()
    return json.loads(payload)
inputs = {}
native = read('native-face-skin-stages/results.json')['history']['cloth']
player_events = read('engine-cloth-color/results.json')['events']
player, = [row for row in player_events if row['event'] == 967]
lookup = {(r['x'], r['y']): r for r in player['history']}
selection = {tuple(p) for p in read('cloth-vulkan-ownership-summary.json')['967']['changed']}
assert set(lookup) == {(row['x'], row['y']) for row in native} == selection and len(selection) == 30
rows = []
samples = {tuple(k[c] for c in ('x', 'y')): k for k in read('cloth-color-adjustment-source.json')}
for native_row in native:
    point = (native_row['x'], native_row['y'])
    player_row = lookup[point]
    n,p = [np.asarray(row['shaderOut'], dtype=float) for row in (native_row,player_row)]
    nb, pb = [np.asarray(row['before'][:3], dtype=float) for row in (native_row, player_row)]
    no, po = [np.asarray(row['after'][:3], dtype=float) for row in (native_row, player_row)]
    n[:3] *= .25; nb *= .25; no *= .25
    # Isolate each difference in the actual blend equation; rounding is the closure term.
    source = (n[:3] - p[:3]) * p[3]
    alpha = (n[3] - p[3]) * (n[:3] - pb)
    background = (nb - pb) * (1 - n[3])
    before_round = source + alpha + background
    error = no - po
    closure = error - before_round
    row = dict(point=point, actualDelta=error.tolist(), sourceRgb=source.tolist(), sourceAlpha=alpha.tolist(),
               destinationRgb=background.tolist(), attachmentRounding=closure.tolist())
    if point in samples:
        gain = np.asarray(samples[point]['colorAdjustmentContribution'])
        row['nativeMaterialRim'] = (gain * p[3]).tolist()
        row['nativeMinusPlayerBeforeThatRim'] = ((n[:3] - p[:3] - gain) * p[3]).tolist()
    rows.append(row)
keys = ('actualDelta','sourceRgb','sourceAlpha','destinationRgb','attachmentRounding')
stats={}
for key in keys:
    a = np.asarray([row[key] for row in rows])
    stats[key] = dict(mean=np.mean(a, 0).tolist(), meanAbsolute=np.mean(np.abs(a), 0).tolist(),
                      maximumAbsolute=np.max(np.abs(a), 0).tolist())
assert stats['sourceAlpha']['maximumAbsolute'][0] < .0005
assert stats['attachmentRounding']['maximumAbsolute'][0] < .004
assert stats['sourceRgb']['meanAbsolute'][0] > 10*stats['destinationRgb']['meanAbsolute'][0]
record=dict(status='source-attribution',capturePoints=len(rows),sourceFiles=inputs,units='linear RGB, native scaled by 0.25',
            components=stats,points=rows)
(out/'cloth-blend-contributions.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(stats))

