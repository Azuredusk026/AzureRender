from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
record = json.loads((out/'cloth-blend-contributions.json').read_bytes())
assert record['capturePoints'] == len(record['points']) == 30
stats = record['components']
assert stats['sourceRgb']['meanAbsolute'][0] > .05
assert stats['destinationRgb']['meanAbsolute'][0] < .0007
assert stats['sourceAlpha']['maximumAbsolute'][0] < .00017
checkpoints = [row for row in record['points'] if 'nativeMaterialRim' in row]
assert len(checkpoints) == 3
assert max(abs(row['nativeMinusPlayerBeforeThatRim'][0]) for row in checkpoints) < .0041
target = out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/transparent-cloth-blend-attribution'
target.mkdir(parents=True, exist_ok=False)
archive = target/'validation.zip'
with ZipFile(archive, 'x', ZIP_DEFLATED) as z:
    for name,sha in record['sourceFiles'].items():
        path = grid/name
        assert sha256(path.read_bytes()).hexdigest() == sha
        z.write(path,name)
    for name in ('cloth-blend-contributions.py',Path(__file__).name):
        z.write(out/name,name)
with ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == 6
record.update(overallStatus='failed-user-review',archive=dict(members=6,sha256=sha256(archive.read_bytes()).hexdigest()))
(target/'results.json').write_text(json.dumps(record,indent=2)+'\n')
print(record['archive'])

