"""Read the native material bindings without opening a graphics replay."""
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import traceback

KEY = 'AZURE_NR_NATIVE_SAMPLER_COMMANDS'
OUT = (Path(os.environ[KEY]) if KEY in os.environ
    else Path(__file__).resolve().parent / 'native-surface-sampler-commands')
ROOT = OUT.parent
EVENTS = {
    846: {'chunks': (1657, 1677), 'slots': (13, 14)},
    950: {'chunks': (1760, 1781), 'slots': (16, 17, 18)},
    1018: {'chunks': (1827, 1849), 'slots': (14,)},
    1383: {'chunks': (2190, 2214), 'slots': (19, 20, 21)},
}
EXPECTED = {
    846: {13: (62, 1, 139680, 'BC7_UNORM_SRGB', 10), 14: (462, 0, 20975, 'BC7_UNORM_SRGB', 9)},
    950: {16: (32, 2, 139677, 'BC7_UNORM_SRGB', 12), 17: (33, 2, 139671, 'BC7_UNORM', 12),
          18: (44, 2, 139862, 'BC7_UNORM', 12)},
    1018: {14: (18, 1, 85442, 'BC7_UNORM_SRGB', 11)},
    1383: {19: (18, 1, 85388, 'BC7_UNORM_SRGB', 12), 20: (19, 1, 85393, 'BC7_UNORM', 12),
           21: (28, 1, 85362, 'BC5_UNORM', 12)},
}


def write(path, obj):
    path.write_text(json.dumps(obj, indent=2) + '\n', encoding='utf8')


def describe(node):
    kind = str(node.type.name)
    if node.NumChildren():
        children = [node.GetChild(i) for i in range(node.NumChildren())]
        names = [str(child.name) for child in children]
        if len(set(names)) < len(names) or '[]' in kind or str(node.name).startswith('pp'):
            return [describe(child) for child in children]
        return {name: describe(child) for name, child in zip(names, children)}
    if kind.endswith(' *') or kind == 'ResourceId':
        return str(node.AsResourceId())
    if kind == 'bool':
        return bool(node.AsBool())
    if kind.startswith(('int', 'uint')):
        return int(node.AsInt())
    if kind in ('float', 'double'):
        return float(node.AsFloat())
    return str(node.AsString())


def inspect():
    (OUT / 'progress.txt').write_text('worker entered\n', encoding='utf8')
    import renderdoc as rd

    request = json.loads((ROOT / 'face-shadow-structured-capture/request.json').read_bytes())
    report = dict(status='failed')
    capture = rd.OpenCaptureFile()
    try:
        digest = sha256()
        with Path(request['source']).open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(block)
        assert digest.hexdigest() == request['captureSha256']
        assert capture.OpenFile(request['source'], 'rdc', None) == rd.ResultCode.Succeeded
        structured = capture.GetStructuredData()
        assert structured and structured.chunks
        definitions = {}
        bindings = {}
        for index, chunk in enumerate(structured.chunks):
            name = str(chunk.name)
            for command, output in (('CreateSamplerState', 'pState'), ('CreateShaderResourceView', 'pView')):
                if command not in name:
                    continue
                identity = chunk.FindChild(output)
                if identity:
                    definitions[describe(identity)] = [index, name, chunk]
            if name.endswith(('PSSetSamplers', 'PSSetShaderResources')):
                bindings.setdefault(name.rsplit('::', 1)[1], []).append((index, describe(chunk)))

        program_root = Path(request['source']).parent.parent / '20261103-234012-character-reference-stages-5abe6c'
        inventory = json.loads((program_root / 'native-stages.json').read_bytes())
        sampler_fields = ('Filter', 'AddressU', 'AddressV', 'AddressW', 'MipLODBias',
                          'MaxAnisotropy', 'MinLOD', 'MaxLOD')
        stages = {}
        for event, target in EVENTS.items():
            first, end = target['chunks']
            shader = (program_root / f'native-e{event}.dxbc').read_bytes()
            shader_hash = sha256(shader).hexdigest()
            inventory_entry, = [row for row in inventory['draws'] if row['event'] == event]
            assert shader_hash == inventory_entry['shaderSha256']
            assembly = (program_root / f'native-e{event}.asm').read_text()
            samples = {}
            for slot in target['slots']:
                pc, sampler_slot, texture, fmt, mips = EXPECTED[event][slot]
                assert re.search(rf'^\s*{pc}:\s+sample_b.*?, t{slot}\.[xyzw]+, s{sampler_slot}, cb1\[26\]\.x$', assembly, re.M)
                owners = {}
                for name, field, resource_slot in (
                    ('PSSetSamplers', 'ppSamplers', sampler_slot),
                    ('PSSetShaderResources', 'ppShaderResourceViews', slot),
                ):
                    active = [(index, values[field][resource_slot - values['StartSlot']])
                              for index, values in bindings[name]
                              if first <= index < end and 0 <= resource_slot - values['StartSlot'] < len(values[field])]
                    binding, identity = active[-1]
                    assert first <= binding < end
                    definition, _, chunk = definitions[identity]
                    owners[name] = dict(id=identity, bindingChunk=binding, definitionChunk=definition, state=describe(chunk))
                sampler = owners['PSSetSamplers']
                state = sampler.pop('state')['Descriptor']
                assert state['Filter'] == 'D3D11_FILTER_MIN_MAG_LINEAR_MIP_POINT'
                assert (state['MipLODBias'], state['MaxAnisotropy'], state['MinLOD'], state['MaxLOD']) == (0.0, 1, 0.0, 1000.0)
                assert {state[field] for field in sampler_fields[1:4]} == {
                    'D3D11_TEXTURE_ADDRESS_CLAMP' if event == 846 and slot == 14 else 'D3D11_TEXTURE_ADDRESS_WRAP'}
                sampler.update(slot=sampler_slot, descriptor={field: state[field] for field in sampler_fields})
                view = owners['PSSetShaderResources']
                state = view.pop('state')
                assert state['pResource'] == f'ResourceId::{texture}'
                assert state['pDesc']['Format'] == 'DXGI_FORMAT_' + fmt
                assert state['pDesc']['Texture2D'] == {'MostDetailedMip': 0, 'MipLevels': mips}
                view.update(texture=state['pResource'], format=state['pDesc']['Format'], firstMip=0, mipCount=mips)
                samples[slot] = dict(instruction=pc, shaderBias='cb1[26].x', sampler=sampler, view=view)
            stages[event] = dict(shaderSha256=shader_hash, samples=samples)
        report.update(
            status='qualified', replayStarted=False, captureSha256=digest.hexdigest(),
            events=stages, definitionCount=len(definitions),
            bindingCount=sum(map(len, bindings.values())),
        )
    except Exception:
        report['error'] = traceback.format_exc()
    finally:
        capture.Shutdown()
        write(OUT / 'results.json', report)
    os._exit(0 if report['status'] == 'qualified' else 1)


def run():
    OUT.mkdir(exist_ok=True)
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = 0
    with (OUT / 'commands.log').open('wb') as log:
        subprocess.run(
            ['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe', '--python', str(Path(__file__).resolve())],
            cwd=ROOT, env=dict(os.environ, **{KEY: str(OUT)}), stdout=log, stderr=subprocess.STDOUT,
            startupinfo=startup, timeout=60, check=True,
        )
    result = json.loads((OUT / 'results.json').read_bytes())
    assert result['status'] == 'qualified' and result['captureSha256']
    fixture = ROOT.parent / '20261112-231945-projected-hair-reference-grid-4b775d/iris-overlay-geometry-project'
    material = ROOT / 'eye-native-public-nvidia-projected/face-iris-public-main-frame.azurematerial'
    material_bytes = material.read_bytes()
    document = json.loads(material_bytes)
    surface = document['surface']['materials'][0]
    profile = surface['extras']['azureRenderMaterial']['eyeSurface']
    iris_slots = {13: surface['pbrMetallicRoughness']['baseColorTexture']['index'], 14: profile['matcapTexture']}
    player_samplers = {}
    for slot, material_slot in iris_slots.items():
        native = result['events']['846']['samples'][str(slot)]
        texture_id = document['textures'][str(material_slot)]['asset']
        texture = fixture / 'materials' / (texture_id + '.dds')
        metadata = texture.with_suffix('.dds.azmeta').read_bytes()
        settings = json.loads(metadata)['settings']['texture']
        dds = texture.read_bytes()
        assert dds[:4] == b'DDS ' and dds[84:88] == b'DX10'
        assert struct.unpack_from('<I', dds, 128)[0] == 99
        assert struct.unpack_from('<I', dds, 28)[0] == native['view']['mipCount']
        expected_wrap = 'repeat' if native['sampler']['descriptor']['AddressU'].endswith('WRAP') else 'clamp'
        assert (settings['filter'], settings['mipFilter'], settings['anisotropy']) == ('linear', 'nearest', 1)
        assert (settings['wrapU'], settings['wrapV'], settings['mipBias']) == (expected_wrap, expected_wrap, -1.0)
        player_samplers[slot] = dict(ddsSha256=sha256(dds).hexdigest(), metadataSha256=sha256(metadata).hexdigest(),
                                     asset=texture_id, mipCount=native['view']['mipCount'], settings=settings)
    result['playerIris'] = dict(materialSha256=sha256(material_bytes).hexdigest(), samplers=player_samplers)
    gpu_record_path = Path(json.loads((ROOT / 'face-shadow-structured-capture/request.json').read_bytes())['source'])
    gpu_record_path = gpu_record_path.parent.parent / '20261103-234012-character-reference-stages-5abe6c/native-character-sampler-corrected-inputs.json'
    gpu_record_bytes = gpu_record_path.read_bytes()
    replay, = [row for row in json.loads(gpu_record_bytes)['events'] if row['event'] == 950]
    assert replay['globalTextureBiasBlock'] == 1 and replay['globalTextureBiasRow'][0] == -1.0
    for slot in (16, 17, 18):
        sample = result['events']['950']['samples'][str(slot)]
        original = replay['samplers'][sample['sampler']['slot']]
        assert original['object'] == sample['sampler']['id']
        assert original['filter'] == dict(minify='FilterMode.Linear', magnify='FilterMode.Linear',
                                           mip='FilterMode.Point', function='FilterFunction.Normal')
        assert original['address'] == ['AddressMode.Wrap'] * 3
        assert original['lod'] == dict(bias=0.0, minimum=0.0, maximum=1000.0)
    result['retainedNativeHairReplay'] = dict(sha256=sha256(gpu_record_bytes).hexdigest(),
                                            event=950, shaderBias=replay['globalTextureBiasRow'][0])
    write(OUT / 'results.json', result)
    print(result['bindingCount'], 'native bindings,', sum(len(event['samples']) for event in result['events'].values()), 'verified samples')


if os.environ.get(KEY):
    inspect()
else:
    run()
