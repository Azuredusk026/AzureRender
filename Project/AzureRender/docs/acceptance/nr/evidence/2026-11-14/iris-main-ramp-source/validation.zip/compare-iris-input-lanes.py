from hashlib import sha256
from pathlib import Path
import json
import numpy as np

out=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
native=read(out/'iris-native-input-lanes.json')
dest=out/'iris-engine-input-lanes'
job=read(dest/'request.json')
trace=read(dest/'results.json')
assert trace['status']=='qualified' and native['status']=='qualified-native-lanes'
fields=trace['lanes']
assert set(fields)=={'baseline','copy','recompile','restored','coords','base','mip4','matcap','ramp','view',
    'direct','ambient','reflection'}
assert [r['point'] for r in native['rows']]==job['points']
display=lambda v:np.rint(np.where(np.clip(v,0,1)<=.0031308,np.clip(v,0,1)*12.92,1.055*np.clip(v,0,1)**(1/2.4)-.055)*255)
rows=[]
for i,n in enumerate(native['rows']):
    A=lambda key:np.asarray(fields[key]['rows'][i])
    assert np.array_equal(A('baseline')[:3],n['playerBefore'])
    coords=A('coords')
    base=A('base')
    direct,ambient,reflection=(A(key)[:3] for key in ('direct','ambient','reflection'))
    baseline=A('baseline')[:3]
    nativeColor=np.asarray(n['nativeUnpacked'])
    total=direct+ambient+reflection
    ratios=baseline[np.abs(total)>1e-4]/total[np.abs(total)>1e-4]
    scale=.25 if np.median(ratios)<.4 else 1
    residual=baseline-total*scale
    rows.append(dict(point=n['point'],baseUvDelta=(coords[:2]-n['baseUv']).tolist(),
      matcapUvDelta=(coords[2:]-n['matcapUv']).tolist(),base=base.tolist(),
      baseDelta=(base-n['base']).tolist(),mip4Delta=(A('mip4')-n['base']).tolist(),
      matcapDelta=(A('matcap')-n['matcap']).tolist(),mainRampDelta=(A('ramp')-n['ramp']).tolist(),
      rampUvDelta=float(A('view')[0]-n['rampUv'][0]),viewRampDelta=float(A('view')[1]-n['viewRampAlpha']),
      whiteMaskDelta=float(A('view')[2]-n['whiteMask']),direct=(direct*scale).tolist(),
      ambient=(ambient*scale).tolist(),reflection=(reflection*scale).tolist(),
      diffuseDelta=((direct+ambient)*scale-(np.asarray(n['diffuse'])+n['directAndLocal'])).tolist(),
      reflectionDelta=(reflection*scale-n['matcapTerm']).tolist(),remainingHost=residual.tolist(),
      baselineByteDelta=(display(baseline)-display(nativeColor)).astype(int).tolist()))
report=dict(status='qualified-input-comparison',rows=rows,sourceSha256=sha256((out/'iris-native-input-lanes.json').read_bytes()).hexdigest(),
            vulkanSha256=sha256((dest/'results.json').read_bytes()).hexdigest())
(out/'iris-compare-input-lanes.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(rows))
