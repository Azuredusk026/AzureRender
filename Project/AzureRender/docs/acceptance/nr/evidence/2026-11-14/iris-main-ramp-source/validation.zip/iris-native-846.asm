Shader hash b8500c6e-79c49675-b70643cf-dfad8f63

ps_5_0
      dcl_globalFlags refactoringAllowed
      dcl_immediateConstantBuffer {
			{ 1.000000, 0, 0, 0}, 
			{ 0, 1.000000, 0, 0}, 
			{ 0, 0, 1.000000, 0}, 
			{ 0, 0, 0, 1.000000}, 
			{ 2, 1, -1.000000, 1.000000}, 
			{ 2, 1, 1.000000, 1.000000}, 
			{ 0, 2, 1.000000, -1.000000}, 
			{ 0, 2, 1.000000, 1.000000}, 
			{ 0, 1, 1.000000, 1.000000}, 
			{ 0, 1, -1.000000, 1.000000} }
      dcl_constantbuffer cb0[45], immediateIndexed
      dcl_constantbuffer cb1[141], immediateIndexed
      dcl_constantbuffer cb2[4086], dynamicIndexed
      dcl_constantbuffer cb3[2054], dynamicIndexed
      dcl_constantbuffer cb4[4], immediateIndexed
      dcl_constantbuffer cb5[66], immediateIndexed
      dcl_constantbuffer cb6[19], immediateIndexed
      dcl_constantbuffer cb7[160], dynamicIndexed
      dcl_sampler s0, mode_default
      dcl_sampler s1, mode_default
      dcl_sampler s2, mode_comparison
      dcl_resource_structured t0, 4
      dcl_resource_structured t1, 16
      dcl_resource_raw t2
      dcl_resource_texture2d (float,float,float,float) t3
      dcl_resource_texture2d (float,float,float,float) t4
      dcl_resource_texture3d (float,float,float,float) t5
      dcl_resource_texture3d (float,float,float,float) t6
      dcl_resource_texture3d (float,float,float,float) t7
      dcl_resource_texture3d (float,float,float,float) t8
      dcl_resource_texture3d (float,float,float,float) t9
      dcl_resource_texture3d (float,float,float,float) t10
      dcl_resource_texture2d (float,float,float,float) t11
      dcl_resource_texture2d (float,float,float,float) t13
      dcl_resource_texture2d (float,float,float,float) t14
      dcl_resource_texture2d (float,float,float,float) t15
      dcl_resource_texture3d (float,float,float,float) t16
      dcl_input_ps_siv linear noperspective v0.xyw, position
      dcl_input_ps linear v1.xy
      dcl_input_ps linear v2.xyz
      dcl_input_ps linear v3.xyz
      dcl_input_ps linear v4.xyzw
      dcl_input_ps linear v5.xyz
      dcl_input_ps linear v6.xyz
      dcl_input_ps nointerpolation v9.x
      dcl_input_ps_sgv nointerpolation v10.x, isfrontface
      dcl_output o0.xyzw
      dcl_output o1.xyzw
      dcl_temps 30
   0: mov r0.x, cb0[0].z
   1: mov r0.y, cb0[1].z
   2: mov r0.z, cb0[2].z
   3: add r1.xyz, r0.xyzx, v2.xyzx
   4: mad r1.xyz, cb1[4].wwww, r1.xyzx, -v2.xyzx
   5: dp3 r0.w, r1.xyzx, r1.xyzx
   6: max r1.w, r0.w, l(0.000000)
   7: rsq r1.w, r1.w
   8: mul r1.xyz, r1.wwww, r1.xyzx
   9: ishl r2.x, v9.x, l(4)
  10: and r2.y, l(16), cb2[r2.x + 4].w
  11: if_nz r2.y
  12:   iadd r2.yz, l(0, 2, 1, 0), cb2[r2.x + 5].xxxx
  13:   ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r3.xyzw, r2.y, l(0), t1.xzyw
  14:   ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r2.yzw, r2.z, l(0), t1.xxyz
  15:   ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.xyzw, cb2[r2.x + 5].x, l(0), t1.xyzw
  16:   mov r5.x, r3.w
  17:   mov r5.y, r4.w
  18:   mov r6.z, r3.x
  19:   mov r7.z, r3.z
  20:   mov r6.y, r2.y
  21:   mov r7.y, r2.z
  22:   mov r3.z, r2.w
  23:   mov r6.x, r4.x
  24:   mov r7.x, r4.y
  25:   mov r3.x, r4.z
  26: else
  27:   mov r5.xy, cb2[r2.x + 3].zxzz
  28:   mov r6.xyz, cb2[r2.x + 0].xyzx
  29:   mov r7.xyz, cb2[r2.x + 1].xyzx
  30:   mov r3.xyz, cb2[r2.x + 2].xzyx
  31: endif
  32: frc r2.xy, v1.xyxx
  33: add r2.zw, r2.xxxy, l(0.000000, 0.000000, -0.500000, -0.500000)
  34: dp2 r2.z, r2.zwzz, r2.zwzz
  35: ge r2.w, r2.z, l(0.250000)
  36: and r4.x, r2.w, l(1.000000)
  37: dp3 r4.y, v3.xyzx, v3.xyzx
  38: sqrt r4.z, r4.y
  39: div r4.z, l(1.000000, 1.000000, 1.000000, 1.000000), r4.z
  40: mul r8.xyz, v3.zxyz, v4.yzxy
  41: mad r8.xyz, v3.yzxy, v4.zxyz, -r8.xyzx
  42: mul r9.xyz, r4.zzzz, v4.xyzx
  43: lt r4.w, l(0), v4.w
  44: movc r4.w, r4.w, l(1.000000), l(-1.000000)
  45: mul r10.xyz, r4.wwww, r8.xyzx
  46: mul r10.xyz, r4.zzzz, r10.xyzx
  47: mul r11.xyz, r4.zzzz, v3.xyzx
  48: dp3 r9.x, r9.xyzx, r1.xyzx
  49: dp3 r9.y, r10.xyzx, r1.xyzx
  50: dp3 r9.z, r11.xyzx, r1.xyzx
  51: dp3 r4.z, r9.xyzx, r9.xyzx
  52: rsq r4.z, r4.z
  53: mul r4.zw, r4.zzzz, r9.xxxy
  54: mul r4.zw, r4.zzzw, cb6[12].yyyy
  55: mul r4.zw, r4.zzzw, l(0.000000, 0.000000, 1.000000, 0.250000)
  56: add r2.z, r2.z, l(-0.250000)
  57: mul_sat r2.z, r2.z, l(-5.000000)
  58: mad r5.z, r2.z, l(-2.000000), l(3.000000)
  59: mul r2.z, r2.z, r2.z
  60: mul r2.z, r2.z, r5.z
  61: mad r4.zw, -r4.zzzw, r2.zzzz, v1.xxxy
  62: sample_b(texture2d)(float,float,float,float) r9.xyzw, r4.zwzz, t13.xyzw, s1, cb1[26].x
  63: mul r10.xyzw, r9.xyzw, cb6[6].xyzw
  64: add r9.xyz, v2.xyzx, cb0[44].xyzx
  65: add r5.xz, -r5.yyxy, r9.xxzx
  66: mov r5.y, l(0.000061)
  67: dp3 r2.z, r5.xyzx, r5.xyzx
  68: rsq r2.z, r2.z
  69: mul r5.xyz, r2.zzzz, r5.xyzx
  70: mul r8.xyz, r8.xyzx, v4.wwww
  71: mul r11.xyz, r10.xyzx, cb6[4].zzzz
  72: dp3 r2.z, r11.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
  73: mad r11.xyz, r10.xyzx, cb6[4].zzzz, -r2.zzzz
  74: mad r11.xyz, cb6[4].wwww, r11.xyzx, r2.zzzz
  75: rsq r2.z, r4.y
  76: mul r4.yzw, r2.zzzz, v3.xxyz
  77: mad r2.z, cb6[1].y, l(2.000000), l(-1.000000)
  78: movc r2.z, v10.x, l(1.000000), r2.z
  79: mul r4.yzw, r2.zzzz, r4.yyzw
  80: mad r2.xy, r2.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
  81: dp2 r2.z, r2.xyxx, r2.xyxx
  82: min r2.z, r2.z, l(1.000000)
  83: add r2.z, -r2.z, l(1.000000)
  84: sqrt r2.z, r2.z
  85: max r12.z, r2.z, l(0.000000)
  86: mul r12.xy, r2.xyxx, -cb6[17].yyyy
  87: mul r2.xyz, r12.xyzx, l(-0.125000, -0.125000, 1.000000, 0.000000)
  88: mad r13.xyz, -r12.xyzx, l(-0.125000, -0.125000, 1.000000, 0.000000), l(0.000000, 0.000000, 1.000000, 0.000000)
  89: mad r2.xyz, r4.xxxx, r13.xyzx, r2.xyzx
  90: mul r13.xyz, r8.xyzx, r2.yyyy
  91: mad r13.xyz, r2.xxxx, v4.xyzx, r13.xyzx
  92: mad r2.xyz, r2.zzzz, v3.xyzx, r13.xyzx
  93: dp3 r5.w, r2.xyzx, r2.xyzx
  94: rsq r5.w, r5.w
  95: mul r13.xyz, r2.xyzx, r5.wwww
  96: ftou r14.xy, v0.xyxx
  97: add r2.x, l(1.000000), -cb1[29].x
  98: mad r2.x, cb1[122].w, r2.x, cb1[29].x
  99: mul r2.x, r2.x, cb1[27].x
 100: mov r13.w, l(0.000061)
 101: dp3 r2.y, r13.xzwx, r13.xzwx
 102: rsq r2.y, r2.y
 103: mul r15.xyz, r2.yyyy, r13.xwzx
 104: lt r2.y, cb1[111].y, l(0.500000)
 105: if_nz r2.y
 106:   mad r16.xyz, cb0[6].xzyx, -cb1[137].wwww, cb1[135].xzyx
 107:   add r16.xyz, r9.xzyx, -r16.xyzx
 108:   max r2.y, abs(r16.y), abs(r16.x)
 109:   add r2.y, r2.y, l(-464.000000)
 110:   add r2.z, abs(r16.z), l(-208.000000)
 111:   mul_sat r2.yz, r2.yyzy, l(0.000000, 0.031250, 0.031250, 0.000000)
 112:   max r2.y, r2.z, r2.y
 113:   ne r2.z, l(0), cb1[135].w
 114:   lt r5.w, r2.y, l(1.000000)
 115:   and r2.z, r2.z, r5.w
 116:   if_nz r2.z
 117:     mad r16.xyz, cb0[6].xzyx, -cb1[137].yyyy, cb1[135].xzyx
 118:     add r16.xyz, r9.xzyx, -r16.xyzx
 119:     max r2.z, abs(r16.y), abs(r16.x)
 120:     add r2.z, r2.z, l(-29.000000)
 121:     mul_sat r2.z, r2.z, l(0.500000)
 122:     add r5.w, abs(r16.z), l(-13.000000)
 123:     mul_sat r5.w, r5.w, l(0.500000)
 124:     max r2.z, r2.z, r5.w
 125:     lt r5.w, r2.z, l(1.000000)
 126:     if_nz r5.w
 127:       mad r16.xyz, r9.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 128:       mul r17.xyz, r16.xyzx, cb1[136].xyzx
 129:       round_ni r17.xyz, r17.xyzx
 130:       mad r16.xyz, r16.xyzx, cb1[136].xyzx, -r17.xyzx
 131:       sample_l(texture3d)(float,float,float,float) r17.xyw, r16.xyzx, t5.yzwx, s1, l(0)
 132:       add r5.w, -r2.z, l(1.000000)
 133:       mul r7.w, l(0.500000), cb1[136].y
 134:       mad r8.w, -cb1[136].y, l(0.500000), l(1.000000)
 135:       max r7.w, r7.w, r16.y
 136:       min r7.w, r8.w, r7.w
 137:       mul r16.w, r7.w, l(0.333333)
 138:       sample_l(texture3d)(float,float,float,float) r18.xyzw, r16.xwzx, t6.xyzw, s0, l(0)
 139:       mad r7.w, r18.w, r5.w, r2.y
 140:       add r19.xyz, r16.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 141:       sample_l(texture3d)(float,float,float,float) r19.xyz, r19.xyzx, t6.xyzw, s0, l(0)
 142:       mad r19.xyz, r19.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 143:       mul r19.xyz, r17.yyyy, r19.xyzx
 144:       mov r19.w, r17.y
 145:       mul r19.xyzw, r5.wwww, r19.xyzw
 146:       add r16.xyz, r16.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 147:       sample_l(texture3d)(float,float,float,float) r16.xyz, r16.xyzx, t6.xyzw, s0, l(0)
 148:       mad r16.xyz, r16.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 149:       mul r16.xyz, r17.xxxx, r16.xyzx
 150:       mov r16.w, r17.x
 151:       mul r16.xyzw, r5.wwww, r16.xyzw
 152:       mad r18.xyz, r18.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 153:       mul r17.xyz, r17.wwww, r18.xyzx
 154:       mul r17.xyzw, r5.wwww, r17.xyzw
 155:     else
 156:       mov r19.xyzw, l(0, 0, 0, 0)
 157:       mov r16.xyzw, l(0, 0, 0, 0)
 158:       mov r17.xyzw, l(0, 0, 0, 0)
 159:       mov r7.w, r2.y
 160:     endif
 161:     mad r18.xyz, cb0[6].xzyx, -cb1[137].zzzz, cb1[135].xzyx
 162:     add r18.xyz, r9.xzyx, -r18.xyzx
 163:     max r5.w, abs(r18.y), abs(r18.x)
 164:     add r5.w, r5.w, l(-116.000000)
 165:     mul_sat r5.w, r5.w, l(0.125000)
 166:     add r8.w, abs(r18.z), l(-52.000000)
 167:     mul_sat r8.w, r8.w, l(0.125000)
 168:     max r5.w, r5.w, r8.w
 169:     lt r8.w, r5.w, l(1.000000)
 170:     if_nz r8.w
 171:       mad r18.xyz, r9.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 172:       mul r20.xyz, r18.xyzx, cb1[136].xyzx
 173:       round_ni r20.xyz, r20.xyzx
 174:       mad r18.xyz, r18.xyzx, cb1[136].xyzx, -r20.xyzx
 175:       sample_l(texture3d)(float,float,float,float) r20.xyw, r18.xyzx, t7.yzwx, s1, l(0)
 176:       add r8.w, -r5.w, l(1.000000)
 177:       mul r2.z, r2.z, r8.w
 178:       mul r8.w, l(0.500000), cb1[136].y
 179:       mad r11.w, -cb1[136].y, l(0.500000), l(1.000000)
 180:       max r8.w, r8.w, r18.y
 181:       min r8.w, r11.w, r8.w
 182:       mul r18.w, r8.w, l(0.333333)
 183:       sample_l(texture3d)(float,float,float,float) r21.xyzw, r18.xwzx, t8.xyzw, s0, l(0)
 184:       mad r7.w, r21.w, r2.z, r7.w
 185:       add r22.xyz, r18.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 186:       sample_l(texture3d)(float,float,float,float) r22.xyz, r22.xyzx, t8.xyzw, s0, l(0)
 187:       mad r22.xyz, r22.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 188:       mul r22.xyz, r20.yyyy, r22.xyzx
 189:       mov r22.w, r20.y
 190:       mad r19.xyzw, r22.xyzw, r2.zzzz, r19.xyzw
 191:       add r18.xyz, r18.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 192:       sample_l(texture3d)(float,float,float,float) r18.xyz, r18.xyzx, t8.xyzw, s0, l(0)
 193:       mad r18.xyz, r18.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 194:       mul r18.xyz, r20.xxxx, r18.xyzx
 195:       mov r18.w, r20.x
 196:       mad r16.xyzw, r18.xyzw, r2.zzzz, r16.xyzw
 197:       mad r18.xyz, r21.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 198:       mul r20.xyz, r20.wwww, r18.xyzx
 199:       mad r17.xyzw, r20.xyzw, r2.zzzz, r17.xyzw
 200:     endif
 201:     lt r2.z, l(0), r5.w
 202:     if_nz r2.z
 203:       mad r18.xyz, r9.xyzx, l(0.125000, 0.125000, 0.125000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 204:       mul r20.xyz, r18.xyzx, cb1[136].xyzx
 205:       mul r21.xyz, l(0.500000, 0.500000, 0.500000, 0.000000), cb1[136].xyzx
 206:       round_ni r20.xyz, r20.xyzx
 207:       mad r18.xyz, r18.xyzx, cb1[136].xyzx, -r20.xyzx
 208:       mad r20.xyz, -cb1[136].xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), l(1.000000, 1.000000, 1.000000, 0.000000)
 209:       max r18.xyz, r21.xyzx, r18.xyzx
 210:       min r18.xyz, r20.xyzx, r18.xyzx
 211:       sample_l(texture3d)(float,float,float,float) r22.xyw, r18.xyzx, t9.yzwx, s1, l(0)
 212:       add r2.z, -r2.y, l(1.000000)
 213:       mul r2.z, r2.z, r5.w
 214:       max r5.w, r21.y, r18.y
 215:       min r5.w, r20.y, r5.w
 216:       mul r18.w, r5.w, l(0.333333)
 217:       sample_l(texture3d)(float,float,float,float) r20.xyzw, r18.xwzx, t10.xyzw, s0, l(0)
 218:       add r21.xyz, r18.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 219:       sample_l(texture3d)(float,float,float,float) r21.xyz, r21.xyzx, t10.xyzw, s0, l(0)
 220:       mad r21.xyz, r21.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 221:       mul r21.xyz, r22.yyyy, r21.xyzx
 222:       mov r21.w, r22.y
 223:       mad r19.xyzw, r21.xyzw, r2.zzzz, r19.xyzw
 224:       add r18.xyz, r18.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 225:       sample_l(texture3d)(float,float,float,float) r18.xyz, r18.xyzx, t10.xyzw, s0, l(0)
 226:       mad r18.xyz, r18.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 227:       mul r18.xyz, r22.xxxx, r18.xyzx
 228:       mov r18.w, r22.x
 229:       mad r16.xyzw, r18.xyzw, r2.zzzz, r16.xyzw
 230:       mad r18.xyz, r20.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 231:       mul r22.xyz, r22.wwww, r18.xyzx
 232:       mad r17.xyzw, r22.xyzw, r2.zzzz, r17.xyzw
 233:       mad r7.w, r20.w, r2.z, r7.w
 234:     endif
 235:     mad_sat r2.z, r7.w, l(2.000000), l(-1.000000)
 236:     add r18.x, -r2.y, r2.z
 237:     add r2.y, r2.y, r2.z
 238:     mul r18.y, r2.y, l(0.500000)
 239:   else
 240:     mov r19.xyzw, l(0, 0, 0, 0)
 241:     mov r16.xyzw, l(0, 0, 0, 0)
 242:     mov r17.xyzw, l(0, 0, 0, 0)
 243:     mov r18.xy, l(0.000000, 1.000000, 0.000000, 0.000000)
 244:   endif
 245:   mul r20.xyzw, r18.yyyx, cb1[138].xyzw
 246:   mad r20.y, r20.w, l(0.500000), r20.y
 247:   mul r2.yz, r18.yyxy, cb1[138].wwyw
 248:   mad r20.w, r2.z, l(0.375000), r2.y
 249:   add r17.xyzw, r17.xyzw, r20.xyzw
 250:   mul r20.xyzw, r18.yyyx, cb1[139].xyzw
 251:   mad r20.y, r20.w, l(0.500000), r20.y
 252:   mul r2.yz, r18.yyxy, cb1[139].wwyw
 253:   mad r20.w, r2.z, l(0.375000), r2.y
 254:   add r16.xyzw, r16.xyzw, r20.xyzw
 255:   mul r20.xyzw, r18.yyyx, cb1[140].xyzw
 256:   mad r20.y, r20.w, l(0.500000), r20.y
 257:   mul r2.yz, r18.yyxy, cb1[140].wwyw
 258:   mad r20.w, r2.z, l(0.375000), r2.y
 259:   add r18.xyzw, r19.xyzw, r20.xyzw
 260:   mov r15.w, l(1.000000)
 261:   dp4 r19.x, r17.xyzw, r15.xyzw
 262:   dp4 r19.y, r16.xyzw, r15.xyzw
 263:   dp4 r19.z, r18.xyzw, r15.xyzw
 264:   max r19.xyz, r19.xyzx, l(0, 0, 0, 0)
 265:   mul r20.xyz, r2.xxxx, r19.xyzx
 266:   mul r21.xyz, r16.xyzx, l(0.715200, 0.715200, 0.715200, 0.000000)
 267:   mad r21.xyz, r17.xyzx, l(0.212600, 0.212600, 0.212600, 0.000000), r21.xyzx
 268:   mad r21.xyz, r18.xyzx, l(0.072200, 0.072200, 0.072200, 0.000000), r21.xyzx
 269:   dp3 r2.y, r21.xyzx, r21.xyzx
 270:   max r2.y, r2.y, l(0.000000)
 271:   rsq r2.y, r2.y
 272:   mul r21.xyz, r2.yyyy, r21.xyzx
 273:   mov r21.y, abs(r21.y)
 274:   mov r21.w, l(1.000000)
 275:   dp4 r17.x, r17.xyzw, r21.xyzw
 276:   dp4 r17.y, r16.xyzw, r21.xyzw
 277:   dp4 r17.z, r18.xyzw, r21.xyzw
 278:   max r16.xyz, r17.xyzx, l(0, 0, 0, 0)
 279:   ge r2.y, r20.y, r20.z
 280:   and r2.y, r2.y, l(1.000000)
 281:   mov r17.xy, r20.zyzz
 282:   mov r17.zw, l(0.000000, 0.000000, -1.000000, 0.666667)
 283:   mad r18.xy, r19.yzyy, r2.xxxx, -r17.xyxx
 284:   mov r18.zw, l(0.000000, 0.000000, 1.000000, -1.000000)
 285:   mad r17.xyzw, r2.yyyy, r18.xyzw, r17.xyzw
 286:   ge r2.y, r20.x, r17.x
 287:   and r2.y, r2.y, l(1.000000)
 288:   mov r18.xyz, r17.xywx
 289:   mov r18.w, r20.x
 290:   mov r17.xyw, r18.wywx
 291:   add r17.xyzw, -r18.xyzw, r17.xyzw
 292:   mad r17.xyzw, r2.yyyy, r17.xyzw, r18.xyzw
 293:   min r2.y, r17.y, r17.w
 294:   add r2.y, -r2.y, r17.x
 295:   add r2.z, -r17.y, r17.w
 296:   mad r5.w, r2.y, l(6.000000), l(0.000100)
 297:   div r2.z, r2.z, r5.w
 298:   add r2.z, r2.z, r17.z
 299:   frc r2.z, abs(r2.z)
 300:   add r5.w, r17.x, l(0.000100)
 301:   div r2.y, r2.y, r5.w
 302:   add r18.xyzw, r2.zzzz, l(-0.500000, 1.000000, 0.666667, 0.333333)
 303:   add r2.z, abs(r18.x), l(-0.450000)
 304:   mul_sat r2.z, r2.z, l(-10.000001)
 305:   mad r5.w, r2.z, l(-2.000000), l(3.000000)
 306:   mul r2.z, r2.z, r2.z
 307:   mul r2.z, r2.z, r5.w
 308:   mad r2.z, r2.z, l(-0.350000), l(0.700000)
 309:   mov_sat r17.x, r17.x
 310:   mul r2.z, r2.z, r17.x
 311:   min r2.y, r2.z, r2.y
 312:   add r2.z, -r2.y, l(2.000000)
 313:   div r2.z, l(2.000000), r2.z
 314:   frc r17.xyz, r18.yzwy
 315:   mad r17.xyz, r17.xyzx, l(6.000000, 6.000000, 6.000000, 0.000000), l(-3.000000, -3.000000, -3.000000, 0.000000)
 316:   add_sat r17.xyz, abs(r17.xyzx), l(-1.000000, -1.000000, -1.000000, 0.000000)
 317:   add r17.xyz, r17.xyzx, l(-1.000000, -1.000000, -1.000000, 0.000000)
 318:   mad r17.xyz, r2.yyyy, r17.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 319:   mul r17.xyz, r2.zzzz, r17.xyzx
 320:   max r2.y, r16.y, r16.x
 321:   max r2.y, r16.z, r2.y
 322:   mul r2.x, r2.x, r2.y
 323:   mov r2.y, l(1.000000)
 324: else
 325:   mov r21.xyz, l(0, 0, 0, 0)
 326:   mov r20.xyz, l(1.000000, 1.000000, 1.000000, 0.000000)
 327:   mov r17.xyz, cb1[112].xyzx
 328:   mov r2.y, l(0)
 329: endif
 330: mad r2.z, -cb6[0].z, l(0.960000), l(0.960000)
 331: mul r16.xyz, r2.zzzz, r10.xyzx
 332: mul r11.xyz, r2.zzzz, r11.xyzx
 333: max r5.w, v5.z, l(0.000000)
 334: div r18.xy, v5.xyxx, r5.wwww
 335: max r5.w, v6.z, l(0.000000)
 336: div r18.zw, v6.xxxy, r5.wwww
 337: add r18.xy, -r18.zwzz, r18.xyxx
 338: mul r19.xy, r18.xyxx, l(0.500000, -0.500000, 0.000000, 0.000000)
 339: sqrt r19.xy, abs(r19.xyxx)
 340: sqrt r19.xy, r19.xyxx
 341: mov r18.z, -r18.y
 342: lt r18.yw, l(0, 0, 0, 0), r18.xxxz
 343: lt r18.xz, r18.xxzx, l(0, 0, 0, 0)
 344: iadd r18.xy, -r18.ywyy, r18.xzxx
 345: itof r18.xy, r18.xyxx
 346: mul r18.xy, r18.xyxx, r19.xyxx
 347: mad o1.xy, r18.xyxx, l(0.500000, 0.500000, 0.000000, 0.000000), l(0.500000, 0.500000, 0.000000, 0.000000)
 348: add r18.xyz, cb1[121].xyzx, cb3[0].xyzx
 349: mad r18.xyz, cb1[111].wwww, r18.xyzx, -cb3[0].xyzx
 350: mov r18.w, l(0.000061)
 351: dp3 r5.w, r18.xzwx, r18.xzwx
 352: rsq r5.w, r5.w
 353: mul r19.xyz, r5.wwww, r18.xwzx
 354: add r22.xyzw, cb1[115].xyzw, -cb3[3].xyzw
 355: mad r22.xyzw, cb1[122].yyyw, r22.xyzw, cb3[3].xyzw
 356: mul r23.xyz, r22.wwww, r22.xyzx
 357: dp3 r24.x, r18.xyzx, r6.xyzx
 358: dp3 r24.y, r18.xyzx, r7.xyzx
 359: dp3 r24.z, r18.xzyx, r3.xyzx
 360: dp3 r5.w, r24.xyzx, r24.xyzx
 361: max r5.w, r5.w, l(0.000000)
 362: rsq r5.w, r5.w
 363: mul r7.xy, r5.wwww, r24.xzxx
 364: mov r6.w, r3.x
 365: dp2 r18.x, r6.xwxx, r7.xyxx
 366: mov r3.xw, r6.zzzy
 367: dp2 r18.y, r3.wzww, r7.xyxx
 368: dp2 r18.z, r3.xyxx, r7.xyxx
 369: mov r14.z, l(0)
 370: ld_indexable(texture2d)(float,float,float,float) r3.x, r14.xyzz, t4.xyzw
 371: add r3.x, r3.x, l(-1.000000)
 372: mad r3.x, cb5[34].x, r3.x, l(1.000000)
 373: add r3.y, -r3.x, l(1.000000)
 374: mad r3.x, cb1[111].z, r3.y, r3.x
 375: mul r3.yzw, r11.xxyz, cb1[110].zzzz
 376: mul r6.xyz, r3.yzwy, l(0.650000, 0.650000, 0.650000, 0.000000)
 377: movc r2.w, r2.w, l(0), l(1.000000)
 378: mul r7.xyz, r4.xxxx, cb6[16].xyzx
 379: mul r24.xyz, r10.wwww, cb6[15].xyzx
 380: mad r25.xyz, cb6[16].xyzx, r4.xxxx, r2.wwww
 381: mad r4.x, -r9.w, cb6[6].w, l(1.000000)
 382: mad r26.xyz, cb6[15].xyzx, r10.wwww, r4.xxxx
 383: mul r25.xyz, r25.xyzx, r26.xyzx
 384: dp3 r4.x, r18.xyzx, r18.xyzx
 385: max r4.x, r4.x, l(0.000000)
 386: rsq r4.x, r4.x
 387: mul r18.xyz, r4.xxxx, r18.xyzx
 388: dp3 r4.x, r13.xyzx, r18.xyzx
 389: mad r4.x, cb1[121].w, cb1[122].x, r4.x
 390: max r4.x, r4.x, l(-1.000000)
 391: min r4.x, r4.x, l(1.000000)
 392: mad r18.x, r4.x, l(0.500000), l(0.500000)
 393: mov r18.yw, l(0.000000, 0.500000, 0.000000, 0.500000)
 394: sample_l(texture2d)(float,float,float,float) r26.xyzw, r18.xyxx, t11.xyzw, s0, l(0)
 395: max r4.x, r26.y, r26.x
 396: max r4.x, r26.z, r4.x
 397: min r5.w, r26.y, r26.x
 398: min r5.w, r26.z, r5.w
 399: add r4.x, r4.x, -r5.w
 400: dp3 r5.w, r13.xyzx, cb0[6].xyzx
 401: mad r18.z, r5.w, l(0.500000), l(0.500000)
 402: sample_l(texture2d)(float,float,float,float) r5.w, r18.zwzz, t11.xyzw, s0, l(0)
 403: min r6.w, r26.w, l(1.000000)
 404: dp3 r7.w, r15.xyzx, cb1[116].xyzx
 405: add_sat r7.w, r7.w, cb1[117].x
 406: mad r7.w, r7.w, cb1[117].y, cb1[117].z
 407: mul r8.w, r6.w, cb1[111].y
 408: add r15.xyz, -r17.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 409: mad r15.xyz, r8.wwww, r15.xyzx, r17.xyzx
 410: mul r15.xyz, r7.wwww, r15.xyzx
 411: mad r7.w, r2.x, l(0.350000), l(0.650000)
 412: min r7.w, r7.w, l(1.500000)
 413: max r17.xy, r2.xxxx, l(1.250000, 0.000000, 0.000000, 0.000000)
 414: min r17.xy, r17.xyxx, l(1.750000, 1.500000, 0.000000, 0.000000)
 415: add r2.x, -r7.w, r17.x
 416: mad r2.x, cb1[111].x, r2.x, r7.w
 417: mul r17.xzw, r2.xxxx, r15.xxyz
 418: mul r17.xzw, r17.xxzw, cb1[110].wwww
 419: dp3 r2.x, r23.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 420: mad r18.xyz, r22.xyzx, r22.wwww, -r2.xxxx
 421: mad r18.xyz, r6.wwww, r18.xyzx, r2.xxxx
 422: mul r15.xyz, r15.xyzx, r17.yyyy
 423: add r23.xy, l(1.000000, 1.000000, 0.000000, 0.000000), -cb1[122].yxyy
 424: mad r23.xzw, r22.xxyz, cb1[122].yyyy, r23.xxxx
 425: mad r15.xyz, r15.xyzx, r23.xzwx, r18.xyzx
 426: mad r15.xyz, r15.xyzx, cb1[110].yyyy, -r17.xzwx
 427: mad r15.xyz, r3.xxxx, r15.xyzx, r17.xzwx
 428: dp3 r2.x, r6.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 429: mad r6.xyz, r3.yzwy, l(0.650000, 0.650000, 0.650000, 0.000000), -r2.xxxx
 430: mad r6.xyz, r6.xyzx, l(1.200000, 1.200000, 1.200000, 0.000000), r2.xxxx
 431: add_sat r2.x, r26.w, r5.w
 432: mad r17.xyz, r11.xyzx, cb1[110].zzzz, -r6.xyzx
 433: mad r6.xyz, r2.xxxx, r17.xyzx, r6.xyzx
 434: mad r17.xyz, r16.xyzx, r25.xyzx, -r6.xyzx
 435: mad r6.xyz, r6.wwww, r17.xyzx, r6.xyzx
 436: add r2.x, -r4.x, l(1.000000)
 437: mad r17.xyz, r26.xyzx, r4.xxxx, r2.xxxx
 438: mul r17.xyz, r6.xyzx, r17.xyzx
 439: mad r18.xyz, r16.xyzx, r25.xyzx, -r3.yzwy
 440: mad r3.yzw, r5.wwww, r18.xxyz, r3.yyzw
 441: dp3 r2.x, r6.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 442: dp3 r4.x, r17.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 443: max r4.x, r4.x, l(0.001000)
 444: div r4.x, l(1.000000, 1.000000, 1.000000, 1.000000), r4.x
 445: mul r2.x, r2.x, r4.x
 446: max r2.x, r2.x, l(0)
 447: min r2.x, r2.x, l(1.500000)
 448: mad r6.xyz, r17.xyzx, r2.xxxx, -r3.yzwy
 449: mad r3.yzw, r3.xxxx, r6.xxyz, r3.yyzw
 450: add r2.x, -r5.w, r6.w
 451: mad r2.x, r3.x, r2.x, r5.w
 452: mul r6.xyz, r8.xyzx, r12.yyyy
 453: mad r6.xyz, r12.xxxx, v4.xyzx, r6.xyzx
 454: mad r6.xyz, r12.zzzz, v3.xyzx, r6.xyzx
 455: mul r8.xyz, r6.yyyy, cb0[1].xyzx
 456: mad r6.xyw, cb0[0].xyxz, r6.xxxx, r8.xyxz
 457: mad r6.xyz, cb0[2].xyzx, r6.zzzz, r6.xywx
 458: dp3 r4.x, r6.xyzx, r6.xyzx
 459: rsq r4.x, r4.x
 460: mul r6.xy, r4.xxxx, r6.xyxx
 461: mad r6.xy, r6.xyxx, l(0.500000, 0.500000, 0.000000, 0.000000), l(0.500000, 0.500000, 0.000000, 0.000000)
 462: sample_b(texture2d)(float,float,float,float) r6.xyzw, r6.xyxx, t14.xyzw, s0, cb1[26].x
 463: add r4.x, l(1.000000), -cb6[1].z
 464: mad r4.x, r10.w, cb6[1].z, r4.x
 465: mul r8.xyz, r3.yzwy, r15.xyzx
 466: mul r12.xyz, r6.wwww, cb6[18].xyzx
 467: mad r6.xyz, r6.xyzx, cb6[18].wwww, r12.xyzx
 468: mul r6.xyz, r2.wwww, r6.xyzx
 469: mad r2.w, r2.x, l(0.500000), l(0.500000)
 470: add r5.w, l(1.000000), -cb1[110].z
 471: mad r2.x, r2.x, r5.w, cb1[110].z
 472: mul r2.x, r2.x, r2.w
 473: mul r12.xyz, r2.xxxx, r15.xyzx
 474: mul r6.xyz, r6.xyzx, r12.xyzx
 475: mad r6.xyz, r8.xyzx, r4.xxxx, r6.xyzx
 476: dp3 r2.x, r6.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 477: add r2.w, r2.x, l(-0.500000)
 478: max r2.w, r2.w, l(0)
 479: min r2.w, r2.w, l(0.500000)
 480: dp3 r5.w, r19.xyzx, r13.xyzx
 481: dp3 r6.w, r1.xyzx, r13.xyzx
 482: add r7.w, -r3.x, l(1.000000)
 483: mad r2.w, r2.w, r2.w, l(1.000000)
 484: add r6.xyz, -r2.xxxx, r6.xyzx
 485: mad r6.xyz, r2.wwww, r6.xyzx, r2.xxxx
 486: max r2.x, r20.y, r20.x
 487: max r2.x, r20.z, r2.x
 488: mul r2.x, r2.x, l(0.500000)
 489: max r2.x, r2.x, l(1.000000)
 490: div r2.x, l(1.000000, 1.000000, 1.000000, 1.000000), r2.x
 491: mul r8.xyz, r2.xxxx, r20.xyzx
 492: mad r12.xyz, r22.xyzx, r22.wwww, -r8.xyzx
 493: mad r8.xyz, r3.xxxx, r12.xyzx, r8.xyzx
 494: dp3 r2.x, r21.xyzx, r13.xyzx
 495: mul r2.w, r2.y, r2.x
 496: mad r8.w, r5.w, l(0.500000), l(-1.000000)
 497: mad r5.w, -r5.w, r8.w, l(0.500000)
 498: mad r2.x, -r2.x, r2.y, r5.w
 499: mad_sat r2.x, r3.x, r2.x, r2.w
 500: mul r2.xyw, r2.xxxx, r8.xyxz
 501: dp2 r5.w, cb0[6].xzxx, cb0[6].xzxx
 502: rsq r5.w, r5.w
 503: mul r8.xy, r5.wwww, cb0[6].xzxx
 504: dp2 r5.w, r19.xzxx, r8.xyxx
 505: mov_sat r5.w, -r5.w
 506: mad r5.w, r5.w, r3.x, r7.w
 507: mul r5.w, r23.y, r5.w
 508: mul r2.xyw, r2.xyxw, r5.wwww
 509: add r5.w, -abs(r6.w), l(0.400000)
 510: mul_sat r5.w, r5.w, l(5.000000)
 511: mad r8.x, r5.w, l(-2.000000), l(3.000000)
 512: mul r5.w, r5.w, r5.w
 513: mul r5.w, r5.w, r8.x
 514: mul r2.xyw, r2.xyxw, r5.wwww
 515: dp3 r5.w, r16.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 516: add r5.w, r5.w, l(-0.100000)
 517: mul_sat r5.w, r5.w, l(-16.666666)
 518: mad r8.x, r5.w, l(-2.000000), l(3.000000)
 519: mul r5.w, r5.w, r5.w
 520: mul r5.w, r5.w, r8.x
 521: mad r3.x, r5.w, r3.x, r7.w
 522: mul r2.xyw, r2.xyxw, r3.xxxx
 523: max r8.xyz, r16.xyzx, l(0.150000, 0.150000, 0.150000, 0.000000)
 524: mad r2.xyw, r2.xyxw, r8.xyxz, r6.xyxz
 525: mul r6.xyz, r24.xyzx, cb1[123].zzzz
 526: mad r6.xyz, r7.xyzx, cb1[123].yyyy, r6.xyzx
 527: mad r6.xyz, r10.xyzx, cb1[123].xxxx, r6.xyzx
 528: mad r2.xyw, r6.xyxz, r4.xxxx, r2.xyxw
 529: utof r6.xy, r14.xyxx
 530: mul r7.xy, r6.xyxx, l(0.031250, 0.031250, 0.000000, 0.000000)
 531: round_ni r7.xy, r7.xyxx
 532: mad r3.x, r7.y, cb4[2].y, r7.x
 533: mul r3.x, r3.x, l(8.000000)
 534: ftoi r3.x, r3.x
 535: mad r5.w, -cb1[3].y, cb4[3].w, v0.w
 536: round_ni r5.w, r5.w
 537: add r6.z, l(-1.000000), cb4[2].w
 538: max r7.x, r5.w, l(0)
 539: min r6.z, r6.z, r7.x
 540: mul r7.x, r6.z, l(8.000000)
 541: ftoi r7.x, r7.x
 542: ge r5.w, r6.z, r5.w
 543: iadd r3.x, r3.x, cb4[0].z
 544: iadd r6.z, r7.x, cb4[0].w
 545: mad r7.x, r7.w, l(-0.250000), l(0.750000)
 546: mad r7.yzw, r10.xxyz, r2.zzzz, l(0.000000, -0.500000, -0.500000, -0.500000)
 547: mov r8.w, l(1.000000)
 548: mov r10.xyz, r2.xywx
 549: mov r2.z, l(0)
 550: loop
 551:   ilt r9.w, l(7), r2.z
 552:   breakc_nz r9.w
 553:   iadd r9.w, r2.z, r3.x
 554:   ld_structured_indexable(structured_buffer, stride=4)(mixed,mixed,mixed,mixed) r9.w, r9.w, l(0), t0.xxxx
 555:   iadd r11.w, r2.z, r6.z
 556:   ld_structured_indexable(structured_buffer, stride=4)(mixed,mixed,mixed,mixed) r11.w, r11.w, l(0), t0.xxxx
 557:   and r9.w, r9.w, r11.w
 558:   and r9.w, r5.w, r9.w
 559:   ishl r11.w, r2.z, l(5)
 560:   mov r12.xyz, r10.xyzx
 561:   mov r12.w, r9.w
 562:   loop
 563:     breakc_z r12.w
 564:     firstbit_lo r13.w, r12.w
 565:     ishl r14.z, l(1), r13.w
 566:     xor r14.z, r12.w, r14.z
 567:     iadd r13.w, r11.w, r13.w
 568:     bfi r15.xyzw, l(29, 29, 29, 29), l(3, 3, 3, 3), r13.wwww, l(1, 5, 6, 7)
 569:     ftou r16.w, cb3[r15.y + 6].w
 570:     and r17.x, r16.w, l(1)
 571:     ieq r17.x, r17.x, l(1)
 572:     if_nz r17.x
 573:       add r8.xyz, r9.xyzx, -cb3[r15.x + 6].xyzx
 574:       and r17.xyz, l(0x0000ffff, 0x0000ffff, 0x0000ffff, 0), cb3[r15.y + 6].xzyx
 575:       and r18.xyz, l(0x0000ffff, 0x0000ffff, 0x0000ffff, 0), cb3[r15.z + 6].yxzy
 576:       ushr r19.xyz, cb3[r15.y + 6].xzyx, l(16, 16, 16, 0)
 577:       ushr r20.xyz, cb3[r15.z + 6].yxzy, l(16, 16, 16, 0)
 578:       f16tof32 r17.xyz, r17.xyzx
 579:       f16tof32 r18.xyz, r18.xyzx
 580:       f16tof32 r19.xyz, r19.xyzx
 581:       f16tof32 r20.xyw, r20.yxyz
 582:       mov r21.xz, r17.xxzx
 583:       mov r21.yw, r19.xxxz
 584:       dp4 r15.y, r8.xyzw, r21.xyzw
 585:       mov r19.x, r17.y
 586:       mov r19.z, r18.y
 587:       mov r19.w, r20.x
 588:       dp4 r17.x, r8.xyzw, r19.xyzw
 589:       mov r20.xz, r18.xxzx
 590:       dp4 r8.x, r8.xyzw, r20.xyzw
 591:       max r8.y, abs(r15.y), abs(r17.x)
 592:       max r8.x, abs(r8.x), r8.y
 593:       mad r8.y, cb3[r15.w + 6].x, l(0.500000), l(0.500000)
 594:       add r8.x, -r8.y, r8.x
 595:       mad r8.y, -cb3[r15.w + 6].x, l(0.500000), l(0.500000)
 596:       div_sat r8.x, r8.x, r8.y
 597:       add r8.x, -r8.x, l(1.000000)
 598:       mul r8.x, r8.x, r8.x
 599:     else
 600:       mov r8.x, l(1.000000)
 601:     endif
 602:     lt r8.y, r8.x, l(0.001000)
 603:     if_nz r8.y
 604:       mov r12.w, r14.z
 605:       continue
 606:     endif
 607:     ishl r8.y, r13.w, l(3)
 608:     ftou r8.z, cb3[r8.y + 6].w
 609:     uge r15.y, r8.z, l(4)
 610:     if_nz r15.y
 611:       mov r17.xyz, r12.xyzx
 612:     endif
 613:     if_z r15.y
 614:       lt r15.y, cb3[r8.y + 6].w, l(1.500000)
 615:       if_nz r15.y
 616:         bfi r15.y, l(29), l(3), r13.w, l(3)
 617:         ieq r17.w, l(16), cb3[r15.y + 6].w
 618:         add r18.x, cb1[122].z, cb3[r15.y + 6].z
 619:         lt r18.x, r18.x, l(0.500000)
 620:         or r17.w, r17.w, r18.x
 621:         if_z r17.w
 622:           bfi r18.xy, l(29, 29, 0, 0), l(3, 3, 0, 0), r13.wwww, l(2, 4, 0, 0)
 623:           and r8.z, r8.z, l(1)
 624:           ieq r13.w, r8.z, l(0)
 625:           not r17.w, r13.w
 626:           lt r18.z, l(0), cb3[r18.x + 6].z
 627:           and r17.w, r17.w, r18.z
 628:           ieq r18.z, l(4), cb3[r15.y + 6].w
 629:           movc r18.w, r8.z, l(0), l(1.000000)
 630:           mad r19.x, cb3[r18.x + 6].y, l(0.500000), l(0.500000)
 631:           add r19.z, r19.x, -abs(cb3[r18.x + 6].x)
 632:           add r19.x, -r19.z, cb3[r18.x + 6].y
 633:           add r19.w, -abs(r19.z), l(1.000000)
 634:           add r19.w, -abs(r19.x), r19.w
 635:           max r19.w, r19.w, l(0.000488)
 636:           ge r20.x, cb3[r18.x + 6].x, l(0)
 637:           movc r19.y, r20.x, r19.w, -r19.w
 638:           dp3 r19.w, r19.xyzx, r19.xyzx
 639:           rsq r19.w, r19.w
 640:           mul r19.xyz, r19.wwww, r19.xyzx
 641:           add r19.w, cb3[r18.y + 6].y, cb3[r18.y + 6].y
 642:           max r19.w, r19.w, l(0.100000)
 643:           and r20.x, r18.z, l(1.000000)
 644:           add r19.w, r19.w, -cb3[r15.z + 6].w
 645:           mad r15.z, r20.x, r19.w, cb3[r15.z + 6].w
 646:           add r20.xyz, -r9.xyzx, cb3[r15.x + 6].xyzx
 647:           dp3 r19.w, r20.yzxy, -r19.xyzx
 648:           lt r20.w, l(0.500000), cb3[r18.y + 6].z
 649:           and r20.w, r18.z, r20.w
 650:           and r20.w, r20.w, l(1.000000)
 651:           mul r20.w, r18.w, r20.w
 652:           mad r21.xyz, -r19.zxyz, r19.wwww, -r20.xyzx
 653:           mad r20.xyz, r20.wwww, r21.xyzx, r20.xyzx
 654:           dp3 r19.w, r20.xyzx, r20.xyzx
 655:           rsq r20.w, r19.w
 656:           mul r21.xyz, r20.wwww, r20.xyzx
 657:           if_nz r17.w
 658:             mul r22.xyz, r19.zxyz, cb3[r18.x + 6].zzzz
 659:             mad r23.xyz, -r22.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), r20.xyzx
 660:             mad r22.xyz, r22.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), r20.xyzx
 661:             dp3 r20.w, r23.xyzx, r23.xyzx
 662:             sqrt r20.w, r20.w
 663:             dp3 r21.w, r22.xyzx, r22.xyzx
 664:             sqrt r21.w, r21.w
 665:             mul r24.xyz, r19.xyzx, r21.xyzx
 666:             mad r24.xyz, r19.zxyz, r21.yzxy, -r24.xyzx
 667:             mul r25.xyz, r19.xyzx, r24.xyzx
 668:             mad r24.xyz, r24.zxyz, r19.yzxy, -r25.xyzx
 669:             dp3 r22.w, r24.xyzx, r24.xyzx
 670:             rsq r22.w, r22.w
 671:             mul r21.xyz, r22.wwww, r24.xyzx
 672:             dp3 r22.w, r23.xyzx, r22.xyzx
 673:             mad r22.w, r20.w, r21.w, r22.w
 674:             mad r22.w, r22.w, l(0.500000), l(1.000000)
 675:             div r22.w, l(1.000000, 1.000000, 1.000000, 1.000000), r22.w
 676:             dp3 r23.x, r21.xyzx, r23.xyzx
 677:             div r20.w, r23.x, r20.w
 678:             dp3 r22.x, r21.xyzx, r22.xyzx
 679:             div r21.w, r22.x, r21.w
 680:             add r20.w, r20.w, r21.w
 681:             mul_sat r20.w, r20.w, l(0.500000)
 682:             mul r20.w, r20.w, r22.w
 683:           else
 684:             mov r20.w, l(1.000000)
 685:           endif
 686:           lt r21.w, r15.z, l(0)
 687:           if_nz r21.w
 688:             mul r21.w, cb3[r15.x + 6].w, cb3[r15.x + 6].w
 689:             mul r21.w, r19.w, r21.w
 690:             mad r21.w, -r21.w, r21.w, l(1.000000)
 691:             max r21.w, r21.w, l(0)
 692:             add r19.w, r19.w, l(1.000000)
 693:             div r19.w, l(1.000000, 1.000000, 1.000000, 1.000000), r19.w
 694:             and r22.x, r17.w, l(1.000000)
 695:             add r22.y, -r19.w, r20.w
 696:             mad r19.w, r22.x, r22.y, r19.w
 697:             mul r21.w, r21.w, r21.w
 698:             mul r19.w, r19.w, r21.w
 699:           else
 700:             mul r22.xyz, r20.xyzx, cb3[r15.x + 6].wwww
 701:             dp3 r21.w, r22.xyzx, r22.xyzx
 702:             min r21.w, r21.w, l(1.000000)
 703:             add r21.w, -r21.w, l(1.000000)
 704:             log r21.w, r21.w
 705:             mul r15.z, r15.z, r21.w
 706:             exp r15.z, r15.z
 707:             mul r19.w, r15.z, r20.w
 708:           endif
 709:           dp3 r15.z, r21.yzxy, -r19.xyzx
 710:           add r15.z, r15.z, -cb3[r18.x + 6].z
 711:           mul_sat r15.z, r15.z, cb3[r18.x + 6].w
 712:           mad r15.z, r15.z, r15.z, l(-1.000000)
 713:           mad r15.z, r18.w, r15.z, l(1.000000)
 714:           mul r15.z, r15.z, r19.w
 715:           ftoi r15.w, cb3[r15.w + 6].w
 716:           not r17.w, r17.w
 717:           ige r18.w, r15.w, l(0)
 718:           and r17.w, r17.w, r18.w
 719:           if_nz r17.w
 720:             if_z r8.z
 721:               ishl r8.z, r15.w, l(2)
 722:               mul r19.xyz, r9.yyyy, cb7[r8.z + 33].xywx
 723:               mad r19.xyz, cb7[r8.z + 32].xywx, r9.xxxx, r19.xyzx
 724:               mad r19.xyz, cb7[r8.z + 34].xywx, r9.zzzz, r19.xyzx
 725:               add r19.xyz, r19.xyzx, cb7[r8.z + 35].xywx
 726:               div_sat r19.xy, r19.xyxx, r19.zzzz
 727:               mad r19.xy, r19.xyxx, cb7[r15.w + 0].zwzz, cb7[r15.w + 0].xyxx
 728:             else
 729:               ishl r8.z, r15.w, l(2)
 730:               dp3 r22.x, -r20.xyzx, cb7[r8.z + 32].xyzx
 731:               dp3 r22.y, -r20.xyzx, cb7[r8.z + 33].xyzx
 732:               dp3 r22.z, -r20.xyzx, cb7[r8.z + 34].xyzx
 733:               lt r8.z, abs(r22.x), abs(r22.y)
 734:               and r8.z, r8.z, l(1)
 735:               dp2 r17.w, abs(r22.xyxx), icb[r8.z + 0].xyxx
 736:               lt r17.w, r17.w, abs(r22.z)
 737:               movc r8.z, r17.w, l(2), r8.z
 738:               dp3 r17.w, r22.xyzx, icb[r8.z + 0].xyzx
 739:               lt r17.w, r17.w, l(0)
 740:               bfi r8.z, l(31), l(1), r8.z, r17.w
 741:               ushr r17.w, r8.z, l(1)
 742:               dp3 r17.w, r22.xyzx, icb[r17.w + 0].xyzx
 743:               div r18.w, l(0.000244), cb7[r15.w + 0].w
 744:               add r18.w, -r18.w, l(0.500000)
 745:               utof r19.z, r8.z
 746:               ult r19.w, r8.z, l(2)
 747:               and r19.w, r19.w, l(2)
 748:               dp2 r19.w, r22.xzxx, icb[r19.w + 0].xzxx
 749:               mul r19.w, r19.w, icb[r8.z + 4].z
 750:               div r19.w, r19.w, abs(r17.w)
 751:               mad r19.z, r19.w, r18.w, r19.z
 752:               add r19.z, r19.z, l(0.500000)
 753:               mul_sat r20.x, r19.z, l(0.166667)
 754:               iadd r19.z, l(-1), icb[r8.z + 4].y
 755:               dp2 r19.z, r22.yzyy, icb[r19.z + 0].xyxx
 756:               mul r8.z, r19.z, icb[r8.z + 4].w
 757:               div r8.z, r8.z, abs(r17.w)
 758:               mad_sat r20.y, -r8.z, r18.w, l(0.500000)
 759:               mad r19.xy, r20.xyxx, cb7[r15.w + 0].zwzz, cb7[r15.w + 0].xyxx
 760:             endif
 761:             sample_l(texture2d)(float,float,float,float) r8.z, r19.xyxx, t15.yzxw, s0, l(0)
 762:             mul r15.z, r8.z, r15.z
 763:           endif
 764:           mul r8.x, r8.x, r15.z
 765:           lt r8.z, l(0.000100), r8.x
 766:           if_nz r8.z
 767:             if_nz r18.z
 768:               add r8.z, l(1.000000), -cb3[r18.y + 6].w
 769:               dp3 r15.z, r4.yzwy, r21.xyzx
 770:               add_sat r15.z, r15.z, l(0.500000)
 771:               mad r15.w, r15.z, l(-2.000000), l(3.000000)
 772:               mul r15.z, r15.z, r15.z
 773:               mul r15.z, r15.z, r15.w
 774:               mad r8.z, r15.z, cb3[r18.y + 6].w, r8.z
 775:               mul r8.z, r8.z, cb3[r18.y + 6].x
 776:               mul r8.z, r8.z, r8.x
 777:               add r19.xyz, -r12.xyzx, cb3[r8.y + 6].xyzx
 778:               mad r19.xyz, r8.zzzz, r19.xyzx, r12.xyzx
 779:             endif
 780:             if_z r18.z
 781:               dp3 r8.z, r13.xyzx, r21.xyzx
 782:               mov_sat r15.z, r8.z
 783:               if_nz cb3[r15.y + 6].w
 784:                 and r15.w, r16.w, l(2)
 785:                 ine r15.w, r15.w, l(0)
 786:                 or r13.w, r13.w, r15.w
 787:                 if_nz r13.w
 788:                   ftoi r15.w, cb3[r15.y + 6].x
 789:                 else
 790:                   add r20.xyz, r9.xyzx, -cb3[r15.x + 6].xyzx
 791:                   lt r22.xyz, abs(r20.yzzy), abs(r20.xxyx)
 792:                   and r16.w, r22.y, r22.x
 793:                   lt r20.xyz, l(0, 0, 0, 0), r20.xyzx
 794:                   and r17.w, l(1023), cb3[r18.x + 6].w
 795:                   ubfe r18.xw, l(10, 0, 0, 10), l(10, 0, 0, 20), cb3[r18.x + 6].wwww
 796:                   movc r17.w, r20.x, r17.w, r18.x
 797:                   and r18.x, l(1023), cb3[r15.y + 6].x
 798:                   movc r18.x, r20.y, r18.w, r18.x
 799:                   ubfe r20.xy, l(10, 10, 0, 0), l(10, 20, 0, 0), cb3[r15.y + 6].xxxx
 800:                   movc r18.w, r20.z, r20.x, r20.y
 801:                   movc r18.x, r22.z, r18.x, r18.w
 802:                   movc r16.w, r16.w, r17.w, r18.x
 803:                   ieq r17.w, r16.w, l(1023)
 804:                   movc r15.w, r17.w, l(-1), r16.w
 805:                 endif
 806:                 ige r16.w, r15.w, l(0)
 807:                 if_nz r16.w
 808:                   add r20.xyz, r9.xyzx, -cb3[r15.x + 6].xyzx
 809:                   imad r15.x, r15.w, l(96), cb5[65].x
 810:                   iadd r22.xyzw, r15.xxxx, l(64, 16, 32, 48)
 811:                   and r22.xyzw, r22.xyzw, l(-4, -4, -4, -4)
 812:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r18.xw, r22.x, t2.xxxy
 813:                   and r15.w, r15.x, l(-4)
 814:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r23.xyzw, r15.w, t2.xyzw
 815:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r24.xyzw, r22.y, t2.xyzw
 816:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r25.xyzw, r22.z, t2.xyzw
 817:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r26.xyzw, r22.w, t2.xyzw
 818:                   dp3 r15.w, r20.xyzx, r20.xyzx
 819:                   max r15.w, r15.w, l(0.000000)
 820:                   rsq r15.w, r15.w
 821:                   mul r20.xyz, r15.wwww, r20.xyzx
 822:                   mad r20.xyz, -r20.xyzx, r18.xxxx, r9.xyzx
 823:                   mul r15.w, r18.w, l(5.000000)
 824:                   mad r20.xyz, r4.yzwy, r15.wwww, r20.xyzx
 825:                   mul r24.xyzw, r20.yyyy, r24.xyzw
 826:                   mad r23.xyzw, r23.xyzw, r20.xxxx, r24.xyzw
 827:                   mad r20.xyzw, r25.xyzw, r20.zzzz, r23.xyzw
 828:                   add r20.xyzw, r26.xyzw, r20.xyzw
 829:                   div r20.xyz, r20.xyzx, r20.wwww
 830:                   iadd r15.x, r15.x, l(80)
 831:                   and r15.x, r15.x, l(-4)
 832:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r23.xyzw, r15.x, t2.xyzw
 833:                   ge r22.yzw, l(0, 0, 0, 0), r20.xxyz
 834:                   ge r24.xyz, r20.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 835:                   add r15.xw, -r23.xxxy, r23.zzzw
 836:                   mad r15.xw, r20.xxxy, r15.xxxw, r23.xxxy
 837:                   mad r18.xw, r15.xxxw, cb5[64].zzzw, l(0.500000, 0.000000, 0.000000, 0.500000)
 838:                   round_ni r18.xw, r18.xxxw
 839:                   mad r15.xw, r15.xxxw, cb5[64].zzzw, -r18.xxxw
 840:                   add r23.xyzw, r15.xxww, l(0.500000, 1.000000, 0.500000, 1.000000)
 841:                   mul r25.xyzw, r23.xxzz, r23.xxzz
 842:                   add r23.xz, -r15.xxwx, l(1.000000, 0.000000, 1.000000, 0.000000)
 843:                   min r26.xy, r15.xwxx, l(0, 0, 0, 0)
 844:                   max r26.zw, r15.xxxw, l(0, 0, 0, 0)
 845:                   mul r27.xy, r23.xzxx, l(0.160000, 0.160000, 0.000000, 0.000000)
 846:                   mad r26.zw, -r26.zzzw, r26.zzzw, r23.yyyw
 847:                   add r26.zw, r26.zzzw, l(0.000000, 0.000000, 1.000000, 1.000000)
 848:                   mul r28.xy, r26.zwzz, l(0.160000, 0.160000, 0.000000, 0.000000)
 849:                   mul r25.xz, r25.xxzx, l(0.080000, 0.000000, 0.080000, 0.000000)
 850:                   mad r15.xw, r25.yyyw, l(0.500000, 0.000000, 0.000000, 0.500000), -r15.xxxw
 851:                   mul r29.xy, r15.xwxx, l(0.160000, 0.160000, 0.000000, 0.000000)
 852:                   mad r15.xw, -r26.xxxy, r26.xxxy, r23.xxxz
 853:                   add r15.xw, r15.xxxw, l(1.000000, 0.000000, 0.000000, 1.000000)
 854:                   mul r26.xy, r15.xwxx, l(0.160000, 0.160000, 0.000000, 0.000000)
 855:                   mul r15.xw, r23.yyyw, l(0.160000, 0.000000, 0.000000, 0.160000)
 856:                   mov r29.z, r26.x
 857:                   mov r29.w, r15.x
 858:                   mov r27.z, r28.x
 859:                   mov r27.w, r25.x
 860:                   add r23.xyzw, r27.zwxz, r29.zwxz
 861:                   mov r26.z, r29.y
 862:                   mov r26.w, r15.w
 863:                   mov r28.z, r27.y
 864:                   mov r28.w, r25.z
 865:                   add r25.xyz, r26.zywz, r28.zywz
 866:                   div r26.xyz, r27.xzwx, r23.zwyz
 867:                   add r26.xyz, r26.xyzx, l(-2.500000, -0.500000, 1.500000, 0.000000)
 868:                   mul r26.xyz, r26.xyzx, cb5[64].xxxx
 869:                   div r27.xyz, r28.zywz, r25.xyzx
 870:                   add r27.xyz, r27.xyzx, l(-2.500000, -0.500000, 1.500000, 0.000000)
 871:                   mul r27.xyw, r27.xyxz, cb5[64].yyyy
 872:                   mul r28.xyzw, r23.zwyz, r25.xxxy
 873:                   mov r26.w, r27.x
 874:                   mad r29.xyzw, r18.xwxw, cb5[64].xyxy, r26.xwyw
 875:                   sample_c_lz(texture2d)(float,float,float,float) r15.x, r29.xyxx, t3.xxxx, s2, r20.z
 876:                   sample_c_lz(texture2d)(float,float,float,float) r15.w, r29.zwzz, t3.xxxx, s2, r20.z
 877:                   mul r15.w, r15.w, r28.y
 878:                   mad r15.x, r28.x, r15.x, r15.w
 879:                   mad r25.xw, r18.xxxw, cb5[64].xxxy, r26.zzzw
 880:                   sample_c_lz(texture2d)(float,float,float,float) r15.w, r25.xwxx, t3.xxxx, s2, r20.z
 881:                   mad r15.x, r28.z, r15.w, r15.x
 882:                   mov r27.z, r26.x
 883:                   mad r29.xyzw, r18.xwxw, cb5[64].xyxy, r27.zyzw
 884:                   sample_c_lz(texture2d)(float,float,float,float) r15.w, r29.xyxx, t3.xxxx, s2, r20.z
 885:                   mad r15.x, r28.w, r15.w, r15.x
 886:                   mul r28.xyzw, r23.xyzw, r25.yyzz
 887:                   mov r27.xz, r26.yyzy
 888:                   mad r26.xyzw, r18.xwxw, cb5[64].xyxy, r27.xyzy
 889:                   sample_c_lz(texture2d)(float,float,float,float) r15.w, r26.xyxx, t3.xxxx, s2, r20.z
 890:                   mad r15.x, r28.x, r15.w, r15.x
 891:                   sample_c_lz(texture2d)(float,float,float,float) r15.w, r26.zwzz, t3.xxxx, s2, r20.z
 892:                   mad r15.x, r28.y, r15.w, r15.x
 893:                   sample_c_lz(texture2d)(float,float,float,float) r15.w, r29.zwzz, t3.xxxx, s2, r20.z
 894:                   mad r15.x, r28.z, r15.w, r15.x
 895:                   iadd r15.w, r22.x, l(8)
 896:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r23.xz, r15.w, t2.xxyx
 897:                   add r25.xy, -r20.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 898:                   min r20.xy, r20.xyxx, r25.xyxx
 899:                   or r22.xyz, r22.yzwy, r24.xyzx
 900:                   or r15.w, r22.y, r22.x
 901:                   or r15.w, r22.z, r15.w
 902:                   and r16.w, r20.z, l(0x7fffffff)
 903:                   ult r16.w, l(0x7f800000), r16.w
 904:                   or r15.w, r15.w, r16.w
 905:                   mad r22.xyzw, r18.xwxw, cb5[64].xyxy, r27.xwzw
 906:                   sample_c_lz(texture2d)(float,float,float,float) r16.w, r22.xyxx, t3.xxxx, s2, r20.z
 907:                   mad r15.x, r28.w, r16.w, r15.x
 908:                   mul r16.w, r23.y, r25.z
 909:                   sample_c_lz(texture2d)(float,float,float,float) r17.w, r22.zwzz, t3.xxxx, s2, r20.z
 910:                   mad r15.x, r16.w, r17.w, r15.x
 911:                   add r16.w, -r20.w, r23.x
 912:                   mul r16.w, r16.w, l(0.250000)
 913:                   min r17.w, r20.y, r20.x
 914:                   min r16.w, r16.w, r17.w
 915:                   mul_sat r16.w, r16.w, l(20.000000)
 916:                   mad r17.w, r16.w, l(-2.000000), l(3.000000)
 917:                   mul r16.w, r16.w, r16.w
 918:                   mul r16.w, r16.w, r17.w
 919:                   min r16.w, r16.w, r23.z
 920:                   movc r13.w, r13.w, r16.w, r23.z
 921:                   add r15.x, r15.x, l(-1.000000)
 922:                   movc r15.x, r15.w, l(0), r15.x
 923:                   mad r13.w, r13.w, r15.x, l(1.000000)
 924:                 else
 925:                   dp3 r15.x, r5.xyzx, r21.xyzx
 926:                   add_sat r13.w, r15.x, l(1.000000)
 927:                 endif
 928:               else
 929:                 mov r13.w, l(1.000000)
 930:               endif
 931:               if_z cb3[r15.y + 6].w
 932:                 mul r20.xyz, r8.xxxx, cb3[r8.y + 6].xyzx
 933:                 add r15.x, l(1.000000), -cb3[r18.y + 6].y
 934:                 max r15.w, r20.y, r20.x
 935:                 max r15.w, r20.z, r15.w
 936:                 mul r15.w, r7.x, r15.w
 937:                 max r15.w, r15.w, l(1.000000)
 938:                 div r15.w, l(1.000000, 1.000000, 1.000000, 1.000000), r15.w
 939:                 mad r15.x, r15.w, cb3[r18.y + 6].y, r15.x
 940:                 mul r20.xyz, r15.xxxx, cb3[r8.y + 6].xyzx
 941:                 mul r15.x, l(0.250000), cb3[r18.y + 6].x
 942:                 add_sat r15.w, r8.z, l(0.500000)
 943:                 mad r16.w, -cb3[r18.y + 6].x, l(0.250000), l(1.000000)
 944:                 mad r15.x, r15.w, r16.w, r15.x
 945:                 mul r20.xyz, r15.xxxx, r20.xyzx
 946:                 mov r22.xyz, r3.yzwy
 947:                 mov r23.xyz, r3.yzwy
 948:               else
 949:                 ieq r15.x, l(3), cb3[r15.y + 6].w
 950:                 if_nz r15.x
 951:                   mul r24.xyz, r21.zxyz, cb0[6].xyzx
 952:                   mad r21.xyz, cb0[6].zxyz, r21.xyzx, -r24.xyzx
 953:                   mul r24.xyz, r21.xyzx, cb0[6].zxyz
 954:                   mad r21.xyz, cb0[6].yzxy, r21.yzxy, -r24.xyzx
 955:                   dp3 r15.w, r21.xyzx, r21.xyzx
 956:                   rsq r15.w, r15.w
 957:                   mul r21.xyz, r15.wwww, r21.xyzx
 958:                   dp3_sat r15.z, r13.xyzx, -r21.xyzx
 959:                   mad r22.xyz, cb3[r18.y + 6].yyyy, r7.yzwy, l(0.500000, 0.500000, 0.500000, 0.000000)
 960:                   mov r23.xyz, l(0, 0, 0, 0)
 961:                 else
 962:                   ieq r15.y, l(1), cb3[r15.y + 6].w
 963:                   if_nz r15.y
 964:                     add r8.z, r8.z, cb3[r18.y + 6].x
 965:                     max_sat r8.z, r8.z, l(-1.000000)
 966:                     mul r15.z, r13.w, r8.z
 967:                     mul r23.xyz, r11.xyzx, cb3[r18.y + 6].yyyy
 968:                   else
 969:                     mov r23.xyz, l(0, 0, 0, 0)
 970:                   endif
 971:                   and r22.xyz, r16.xyzx, r15.yyyy
 972:                 endif
 973:                 movc r8.x, r15.x, l(0), r8.x
 974:                 mov r20.xyz, cb3[r8.y + 6].xyzx
 975:               endif
 976:               mul r8.xyz, r8.xxxx, r20.xyzx
 977:               add r15.xyw, r22.xyxz, -r23.xyxz
 978:               mad r15.xyz, r15.zzzz, r15.xywx, r23.xyzx
 979:               mul r8.xyz, r8.xyzx, r15.xyzx
 980:               mad r12.xyz, r8.xyzx, r4.xxxx, r12.xyzx
 981:             endif
 982:           else
 983:             mov r18.z, l(0)
 984:           endif
 985:           movc r12.xyz, r18.zzzz, r19.xyzx, r12.xyzx
 986:         endif
 987:       endif
 988:     else
 989:       mov r12.xyz, r17.xyzx
 990:     endif
 991:     mov r12.w, r14.z
 992:   endloop
 993:   mov r10.xyz, r12.xyzx
 994:   iadd r2.z, r2.z, l(1)
 995: endloop
 996: lt r2.x, l(0.500000), cb6[3].x
 997: if_nz r2.x
 998:   dp3 r2.x, r10.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 999:   add r2.yzw, -r2.xxxx, r10.xxyz
1000:   mad r2.xyz, cb6[3].zzzz, r2.yzwy, r2.xxxx
1001:   add r2.xyz, r2.xyzx, l(-0.500000, -0.500000, -0.500000, 0.000000)
1002:   mad r2.xyz, cb6[3].wwww, r2.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000)
1003:   mul r3.xyz, r2.xyzx, cb6[3].yyyy
1004:   mad r2.xyz, -r2.xyzx, cb6[3].yyyy, cb6[8].xyzx
1005:   mad r2.xyz, cb6[8].wwww, r2.xyzx, r3.xyzx
1006:   add r2.w, l(1.000000), -cb6[4].x
1007:   mov_sat r6.w, r6.w
1008:   add r3.x, -r6.w, l(1.000000)
1009:   add r3.y, -r2.w, l(1.000000)
1010:   add r2.w, -r2.w, r3.x
1011:   div r3.x, l(1.000000, 1.000000, 1.000000, 1.000000), r3.y
1012:   mul_sat r2.w, r2.w, r3.x
1013:   mad r3.x, r2.w, l(-2.000000), l(3.000000)
1014:   mul r2.w, r2.w, r2.w
1015:   mul r2.w, r2.w, r3.x
1016:   mul r3.xyz, r2.wwww, cb6[9].xyzx
1017:   mad r10.xyz, r3.xyzx, cb6[4].yyyy, r2.xyzx
1018: endif
1019: mul r2.xyz, r10.xyzx, cb1[27].yyyy
1020: eq r2.w, l(1.000000), cb6[2].x
1021: movc o0.w, r2.w, r10.w, l(1.000000)
1022: lt r2.w, cb1[122].w, l(0.500000)
1023: if_nz r2.w
1024:   mul r2.w, r0.w, r1.w
1025:   mad r3.x, r9.y, cb1[74].w, cb1[75].w
1026:   mad r3.y, r2.w, cb1[72].w, -cb1[71].w
1027:   max r3.xy, r3.xyxx, l(0.010000, 0.000000, 0.000000, 0.000000)
1028:   mul r3.z, r3.x, l(-1.442695)
1029:   exp r3.z, r3.z
1030:   add r3.z, -r3.z, l(1.000000)
1031:   div r3.x, r3.z, r3.x
1032:   mad r3.z, r9.y, cb1[74].w, cb1[76].w
1033:   mul r3.z, r3.z, l(1.442695)
1034:   exp r3.z, r3.z
1035:   mul r3.x, r3.z, r3.x
1036:   mul r3.x, r3.x, -r3.y
1037:   mul r3.xyz, r3.xxxx, cb1[73].xyzx
1038:   mul r3.xyz, r3.xyzx, l(1.442695, 1.442695, 1.442695, 0.000000)
1039:   exp r3.xyz, r3.xyzx
1040:   dp3 r3.w, -r1.xyzx, cb1[72].xyzx
1041:   mad r4.x, cb1[73].w, cb1[73].w, l(1.000000)
1042:   dp2 r4.y, r3.wwww, cb1[73].wwww
1043:   add r4.x, -r4.y, r4.x
1044:   lt r4.y, l(0), cb1[83].z
1045:   if_nz r4.y
1046:     and r14.w, l(7), cb1[26].w
1047:     imad r4.yzw, r14.xxyw, l(0, 0x0019660d, 0x0019660d, 0x0019660d), l(0.000000, 0.014584, 0.014584, 0.014584)
1048:     imad r4.y, r4.z, r4.w, r4.y
1049:     imad r4.z, r4.w, r4.y, r4.z
1050:     imad r4.w, r4.y, r4.z, r4.w
1051:     imad r5.x, r4.z, r4.w, r4.y
1052:     dp3 r0.x, -r1.xyzx, -r0.xyzx
1053:     lt r0.y, l(0.000000), r0.x
1054:     div r0.x, l(1.000000, 1.000000, 1.000000, 1.000000), r0.x
1055:     and r0.x, r0.x, r0.y
1056:     mul r0.x, r0.x, cb1[83].w
1057:     div r0.y, l(1.000000, 1.000000, 1.000000, 1.000000), r2.w
1058:     mul r0.z, r0.y, r0.x
1059:     mad r4.y, r0.z, v2.y, cb0[44].y
1060:     mad r0.z, -r0.z, v2.y, v2.y
1061:     mad r0.x, -r0.x, r0.y, l(1.000000)
1062:     mul r0.y, r2.w, r0.x
1063:     mul r5.z, r0.z, cb1[77].z
1064:     mul r0.z, r0.z, cb1[80].x
1065:     max r0.z, r0.z, l(-127.000000)
1066:     add r5.w, r4.y, -cb1[77].x
1067:     mul r5.w, r5.w, cb1[77].z
1068:     max r5.zw, r5.zzzw, l(0.000000, 0.000000, -127.000000, -127.000000)
1069:     exp r5.w, -r5.w
1070:     mul r5.w, r5.w, cb1[77].y
1071:     lt r6.z, l(0.000000), abs(r5.z)
1072:     exp r6.w, -r5.z
1073:     add r6.w, -r6.w, l(1.000000)
1074:     div r6.w, r6.w, r5.z
1075:     mad r5.z, -r5.z, l(0.240227), l(0.693147)
1076:     movc r5.z, r6.z, r6.w, r5.z
1077:     add r4.y, r4.y, -cb1[80].z
1078:     mul r4.y, r4.y, cb1[80].x
1079:     max r4.y, r4.y, l(-127.000000)
1080:     exp r4.y, -r4.y
1081:     mul r4.y, r4.y, cb1[80].y
1082:     lt r6.z, l(0.000000), abs(r0.z)
1083:     exp r6.w, -r0.z
1084:     add r6.w, -r6.w, l(1.000000)
1085:     div r6.w, r6.w, r0.z
1086:     mad r0.z, -r0.z, l(0.240227), l(0.693147)
1087:     movc r0.z, r6.z, r6.w, r0.z
1088:     mul r0.z, r0.z, r4.y
1089:     mad r0.z, r5.w, r5.z, r0.z
1090:     mad_sat r5.zw, r2.wwww, cb1[78].wwwy, cb1[78].zzzx
1091:     mul r0.y, r0.y, r0.z
1092:     exp r0.y, -r0.y
1093:     min r0.y, r0.y, l(1.000000)
1094:     max r0.y, r0.y, cb1[79].w
1095:     add r0.y, r5.w, r0.y
1096:     add r0.y, r5.z, r0.y
1097:     min r0.y, r0.y, l(1.000000)
1098:     imad r5.y, r4.w, r5.x, r4.z
1099:     ushr r4.yz, r5.xxyx, l(0, 16, 16, 0)
1100:     utof r4.yz, r4.yyzy
1101:     mad r4.yz, r4.yyzy, l(0.000000, 0.000031, 0.000031, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
1102:     mad r4.yz, r4.yyzy, cb1[87].wwww, r6.xxyx
1103:     mul r6.xy, r4.yzyy, cb1[85].xyxx
1104:     mad r4.y, v0.w, cb1[84].x, cb1[84].y
1105:     log r4.y, r4.y
1106:     mul r4.y, r4.y, cb1[84].z
1107:     div r6.z, r4.y, cb1[83].z
1108:     sample_l(texture3d)(float,float,float,float) r6.xyzw, r6.xyzx, t16.xyzw, s0, l(0)
1109:     add r4.y, v0.w, -cb1[86].z
1110:     mul_sat r4.y, r4.y, l(1000000.000000)
1111:     add r6.xyzw, r6.xyzw, l(-0.000000, -0.000000, -0.000000, -1.000000)
1112:     mad r6.xyzw, r4.yyyy, r6.xyzw, l(0.000000, 0.000000, 0.000000, 1.000000)
1113:     add r4.y, -r0.y, l(1.000000)
1114:     dp3_sat r4.z, r1.xyzx, cb1[81].xyzx
1115:     log r4.z, r4.z
1116:     mul r4.z, r4.z, cb1[82].w
1117:     exp r4.z, r4.z
1118:     mul r5.xyw, r4.zzzz, cb1[82].xyxz
1119:     mad r0.x, r0.x, r2.w, -cb1[81].w
1120:     max r0.x, r0.x, l(0)
1121:     mul r0.x, r0.x, r0.z
1122:     exp r0.x, -r0.x
1123:     min r0.x, r0.x, l(1.000000)
1124:     add r0.x, -r0.x, l(1.000000)
1125:     mul r5.xyw, r0.xxxx, r5.xyxw
1126:     add r0.x, -r5.z, l(1.000000)
1127:     mul r5.xyz, r0.xxxx, r5.xywx
1128:     mad r4.yzw, cb1[79].xxyz, r4.yyyy, r5.xxyz
1129:     mad r4.yzw, r4.yyzw, r6.wwww, r6.xxyz
1130:     mul r0.x, r0.y, r6.w
1131:   else
1132:     mul r0.y, v2.y, cb1[77].z
1133:     mul r0.z, v2.y, cb1[80].x
1134:     max r0.yz, r0.yyzy, l(0.000000, -127.000000, -127.000000, 0.000000)
1135:     add r5.x, cb0[44].y, -cb1[77].x
1136:     mul r5.x, r5.x, cb1[77].z
1137:     max r5.x, r5.x, l(-127.000000)
1138:     exp r5.x, -r5.x
1139:     mul r5.x, r5.x, cb1[77].y
1140:     lt r5.y, l(0.000000), abs(r0.y)
1141:     exp r5.z, -r0.y
1142:     add r5.z, -r5.z, l(1.000000)
1143:     div r5.z, r5.z, r0.y
1144:     mad r0.y, -r0.y, l(0.240227), l(0.693147)
1145:     movc r0.y, r5.y, r5.z, r0.y
1146:     add r5.y, cb0[44].y, -cb1[80].z
1147:     mul r5.y, r5.y, cb1[80].x
1148:     max r5.y, r5.y, l(-127.000000)
1149:     exp r5.y, -r5.y
1150:     mul r5.y, r5.y, cb1[80].y
1151:     lt r5.z, l(0.000000), abs(r0.z)
1152:     exp r5.w, -r0.z
1153:     add r5.w, -r5.w, l(1.000000)
1154:     div r5.w, r5.w, r0.z
1155:     mad r0.z, -r0.z, l(0.240227), l(0.693147)
1156:     movc r0.z, r5.z, r5.w, r0.z
1157:     mul r0.z, r0.z, r5.y
1158:     mad r0.y, r5.x, r0.y, r0.z
1159:     mad_sat r5.xy, r2.wwww, cb1[78].wyww, cb1[78].zxzz
1160:     mul r0.z, r2.w, r0.y
1161:     exp r0.z, -r0.z
1162:     min r0.z, r0.z, l(1.000000)
1163:     max r0.z, r0.z, cb1[79].w
1164:     add r0.z, r5.y, r0.z
1165:     add r0.z, r5.x, r0.z
1166:     min r0.x, r0.z, l(1.000000)
1167:     dp3_sat r1.x, r1.xyzx, cb1[81].xyzx
1168:     log r1.x, r1.x
1169:     mul r1.x, r1.x, cb1[82].w
1170:     exp r1.x, r1.x
1171:     mul r1.xyz, r1.xxxx, cb1[82].xyzx
1172:     mad r0.w, r0.w, r1.w, -cb1[81].w
1173:     max r0.w, r0.w, l(0)
1174:     mul r0.y, r0.w, r0.y
1175:     exp r0.y, -r0.y
1176:     min r0.y, r0.y, l(1.000000)
1177:     add r0.yz, -r0.yyxy, l(0.000000, 1.000000, 1.000000, 0.000000)
1178:     mul r1.xyz, r0.yyyy, r1.xyzx
1179:     add r0.y, -r5.x, l(1.000000)
1180:     mul r1.xyz, r0.yyyy, r1.xyzx
1181:     mad r4.yzw, cb1[79].xxyz, r0.zzzz, r1.xxyz
1182:   endif
1183:   mul r0.yzw, r0.xxxx, r3.xxyz
1184:   mad r1.x, r3.w, r3.w, l(1.000000)
1185:   mul r1.x, r1.x, l(0.059683)
1186:   mad r1.xyz, cb1[74].xyzx, r1.xxxx, cb1[76].xyzx
1187:   mad r1.w, -cb1[73].w, cb1[73].w, l(1.000000)
1188:   mul r2.w, r4.x, l(12.566371)
1189:   sqrt r3.w, r4.x
1190:   mul r2.w, r2.w, r3.w
1191:   max r2.w, r2.w, l(0.001000)
1192:   div r1.w, r1.w, r2.w
1193:   mad_sat r1.xyz, cb1[75].xyzx, r1.wwww, r1.xyzx
1194:   mul r1.xyz, r1.xyzx, l(255.000000, 255.000000, 255.000000, 0.000000)
1195:   add r3.xyz, -r3.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
1196:   mul r1.xyz, r1.xyzx, r3.xyzx
1197:   mad r1.xyz, r1.xyzx, r0.xxxx, r4.yzwy
1198:   mad o0.xyz, r2.xyzx, r0.yzwy, r1.xyzx
1199: else
1200:   mov o0.xyz, r2.xyzx
1201: endif
1202: mov o1.zw, l(0.000000, 0.000000, 1.000000, 0.400000)
1203: ret
