from hashlib import sha256
from pathlib import Path
import json
import numpy as np

out=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
trace=read(out/'trace-iris-base-inputs.json')
assert trace['status']=='qualified'
job=read(out/'trace-iris-base-request.json')
profiles={}
for name,const in trace['constants'].items():
    data=(out/name).read_bytes()
    assert sha256(data).hexdigest()==const['sha256']
    profiles[int(Path(name).stem.split('-cb')[-1])]=np.frombuffer(data,'<f4').astype(float).reshape(-1,4)
exposure=profiles[1][27,1]
assert profiles[1][26,0]==-1
result=[]
keyWorld=profiles[1][121,:3]*profiles[1][111,3]-profiles[3][0,:3]*(1-profiles[1][111,3])
keyBias=profiles[1][121,3]*profiles[1][122,0]
for candidate,sample in zip(job['points'],trace['points']):
    path=out/sample['file']
    assert sha256(path.read_bytes()).hexdigest()==sample['sha256']
    steps=dict(read(path))
    def V(step,reg):
        return np.asarray(next(steps[k][reg] for k in sorted(steps,reverse=True) if k<=step and reg in steps[k]))
    def A(step,reg):
        return np.asarray(sample['samples'][str(step)][reg])
    assert np.max(np.abs(A(63,'r9')*profiles[6][6]-V(64,'r10')))<1e-6
    U,B,F=(V(32,v)[:3] for v in ('r6','r7','r3'))
    F=F[[0,2,1]]
    mainDir=keyWorld@U*U+(keyWorld@F)*F
    mainDir/=np.linalg.norm(mainDir)
    assert np.max(np.abs(mainDir-V(388,'r18')[:3]))<3e-7
    coord=.5+.5*np.clip(V(388,'r13')[:3]@mainDir+keyBias,-1,1)
    assert abs(coord-A(394,'r18')[0])<3e-7
    illumination=V(465,'r15')[:3]
    eyeDiffuse=V(465,'r3')[1:]*illumination*V(465,'r4')[0]
    eyeMatcap=V(475,'r6')[:3]
    solid=V(525,'r2')[[0,1,3]]
    saturation=V(484,'r2')[3]
    luma=np.array([.212673,.715152,.072175])
    main=eyeDiffuse+eyeMatcap
    main=(1-saturation)*(main@luma)+saturation*main
    assert np.max(np.abs(main-V(486,'r6')[:3]))<8e-7
    screenRim=solid-main
    rimReplay=V(523,'r2')[[0,1,3]]*V(524,'r8')[:3]
    assert np.max(np.abs(screenRim-rimReplay))<8e-7
    final=V(1020,'r2')[:3]
    assert np.max(np.abs(final-V(1019,'r10')[:3]*exposure))<5e-7
    delta=np.asarray(candidate['shaderRgbDelta'])
    rim=screenRim*.25*exposure
    result.append(dict(point=sample['point'],baseUv=A(62,'r4')[2:].tolist(),base=A(63,'r9').tolist(),
        normal=V(388,'r13')[:3].tolist(),rampDirection=mainDir.tolist(),frame=[U.tolist(),B.tolist(),F.tolist()],
        matcapUv=A(462,'r6')[:2].tolist(),matcap=A(463,'r6').tolist(),
        rampUv=A(394,'r18')[:2].tolist(),ramp=A(395,'r26').tolist(),viewRampUv=A(402,'r18')[2:].tolist(),
        viewRampAlpha=A(403,'r5')[3],whiteMask=V(483,'r7')[3],
        diffuse=(eyeDiffuse*.25*exposure).tolist(),matcapTerm=(eyeMatcap*.25*exposure).tolist(),
        saturation=saturation,main=(main*.25*exposure).tolist(),rim=rim.tolist(),
        directAndLocal=(final*.25-main*.25*exposure-rim).tolist(),nativeUnpacked=(final*.25).tolist(),
        playerBefore=candidate['playerStored'],errorBefore=delta.tolist(),
        errorAddingNativeRim=(delta+rim).tolist()))
record=dict(status='qualified-native-lanes',sourceExposure=exposure,materialBaseGain=profiles[6][6].tolist(),
            mainKeyWorld=keyWorld.tolist(),mainKeyBias=keyBias,rows=result)
(out/'iris-native-input-lanes.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(json.dumps(record))
