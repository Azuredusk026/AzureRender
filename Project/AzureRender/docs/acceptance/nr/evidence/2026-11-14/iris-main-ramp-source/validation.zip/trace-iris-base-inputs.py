from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import traceback

key='AZURE_NR_IRIS_BASE_TRACE'
out=Path(os.environ[key]) if key in os.environ else Path(__file__).resolve().parent
g=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')

def trace():
    import renderdoc as rd
    job=read(out/'trace-iris-base-request.json')
    report=dict(status='failed',constants={},points=[])
    cap=rd.OpenCaptureFile();ctl=None
    try:
        assert cap.OpenFile(job['capture'],'',None)==rd.ResultCode.Succeeded
        opt=rd.ReplayOptions();opt.forceGPUVendor=rd.GPUVendor.nVidia;opt.forceGPUDeviceID=0x28e0
        state,ctl=cap.OpenCapture(opt,None)
        assert state==rd.ResultCode.Succeeded and ctl
        props=ctl.GetAPIProperties()
        assert props.vendor==rd.GPUVendor.nVidia and props.pipelineType==rd.GraphicsAPI.D3D11 and not props.degraded
        ctl.SetFrameEvent(846,True)
        pipe=ctl.GetPipelineState();stage=rd.ShaderStage.Fragment
        shader=pipe.GetShaderReflection(stage)
        assert sha256(bytes(shader.rawBytes)).hexdigest()==job['pixelShaderSha256']
        asm=ctl.DisassembleShader(pipe.GetGraphicsPipelineObject(),shader,'')
        (out/'iris-native-846.asm').write_text(asm,encoding='utf8')
        samples=[(int(k),op) for k,op in re.findall(r'^\s*(\d+):\s*(\S+[^\n]*)',asm,re.M) if op.startswith('sample')]
        primary=[(k,op) for k,op in samples if re.search(r'\bt13\.',op)]
        assert len(primary)==1 and 'sample_b' in primary[0][1]
        report['samples']=samples
        need={k for i,_ in samples for k in (i,i+1)}
        for i,block in enumerate(shader.constantBlocks):
            d=pipe.GetConstantBlock(stage,i,0).descriptor
            payload=bytes(ctl.GetBufferData(d.resource,d.byteOffset,d.byteSize))
            name=f'iris-native-846-cb{block.fixedBindNumber}.bin'
            (out/name).write_bytes(payload)
            report['constants'][name]=dict(sha256=sha256(payload).hexdigest(),bytes=len(payload))
        for candidate in job['points']:
            x,y=candidate['point']; prim=candidate['primitive']
            params=rd.DebugPixelInputs();params.primitive=prim
            hit=ctl.DebugPixel(x,1439-y,params)
            assert hit and hit.debugger
            live={}; selected={}; updates=[]; count=0
            try:
                while True:
                    batch=ctl.ContinueDebug(hit.debugger)
                    if not batch:break
                    for step in batch:
                        k=int(step.nextInstruction); changed={}
                        for item in step.changes:
                            reg=item.after
                            if reg.name:
                                changed[reg.name]=list(reg.value.f32v)[:4]
                        live.update(changed)
                        if changed:updates.append([k,changed])
                        if k in need:selected[k]=dict(live)
                        count+=1
                    assert count<20000
            finally:ctl.FreeTrace(hit)
            assert primary[0][0]+1 in selected,(candidate,count)
            tracefile=out/f'iris-native-846-trace-{x}-{y}.json'
            tracefile.write_text(json.dumps(updates,separators=(',',':'))+'\n')
            report['points'].append(dict(point=candidate['point'],primitive=prim,
                  samples=selected,steps=count,file=tracefile.name,sha256=sha256(tracefile.read_bytes()).hexdigest()))
        report['status']='qualified'
    except Exception:report['error']=traceback.format_exc()
    finally:
        if ctl:ctl.Shutdown()
        cap.Shutdown()
        write(out/'trace-iris-base-inputs.json',report)
    os._exit(0 if report['status']=='qualified' else 1)

def launch():
    from hashlib import file_digest
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==out
    job=read(g/'iris-explicit-mips/request.json')
    with Path(job['capture']).open('rb') as stream:assert file_digest(stream,'sha256').hexdigest()==job['captureSha256']
    stat=read(out/'iris-bare-radiance-budget.json')
    job['points']=[*stat['worst'][:4],next(r for r in stat['rows'] if r['point']==[1261,261])]
    write(out/'trace-iris-base-request.json',job)
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    with (out/'trace-iris-base-inputs.log').open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__))],
              cwd=out,env=dict(os.environ,**{key:str(out)}),stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=220)
    report=read(out/'trace-iris-base-inputs.json')
    assert child.returncode==0 and report['status']=='qualified',report.get('error')

if key in os.environ:trace()
elif __name__=='__main__':launch()
