from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json
out=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
source=read(out/'iris-native-input-lanes.json')
comparison=read(out/'iris-compare-input-lanes.json')
native=read(out/'trace-iris-base-inputs.json')
assert source['status']=='qualified-native-lanes' and comparison['status']=='qualified-input-comparison'
assert comparison['sourceSha256']==digest(out/'iris-native-input-lanes.json')
assert comparison['vulkanSha256']==digest(out/'iris-engine-input-lanes/results.json')
rows=comparison['rows']
assert len(rows)==5
assert max(abs(x) for r in rows[:4] for x in r['baseDelta'])<3e-8
assert all(r['matcapDelta']==[0,0,0,0] for r in rows[:4])
assert all(.21< -r['rampUvDelta']<.28 for r in rows[:4])
assert all(abs(v)<2e-8 for row in source['rows'] for v in row['rim'])
assert max(abs(v) for row in rows[:4] for v in row['diffuseDelta'])>.05
members=[Path(__file__).name,'trace-iris-base-inputs.py','trace-iris-base-request.json','trace-iris-base-inputs.json',
         'iris-native-846.asm','probe-iris-input-lanes.py','analyze-iris-native-lanes.py','compare-iris-input-lanes.py',
         'iris-engine-input-lanes/results.json','iris-engine-input-lanes/request.json']
for name,value in native['constants'].items():
    assert digest(out/name)==value['sha256'];members.append(name)
for row in native['points']:
    assert digest(out/row['file'])==row['sha256'];members.append(row['file'])
for path in sorted((out/'iris-engine-input-lanes').glob('*.frag')):members.append(path.relative_to(out).as_posix())
dest=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/iris-main-ramp-source'
dest.mkdir(parents=True,exist_ok=False)
with ZipFile(dest/'validation.zip','x',ZIP_DEFLATED) as z:
    for p in members:z.write(out/p,p)
with ZipFile(dest/'validation.zip') as z:assert len(z.namelist())==len(set(members)) and z.testzip() is None
report=dict(overallStatus='failed-user-review',source=source,comparison=comparison,
    archive=dict(members=len(members),sha256=digest(dest/'validation.zip')))
(dest/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(report['archive'])
