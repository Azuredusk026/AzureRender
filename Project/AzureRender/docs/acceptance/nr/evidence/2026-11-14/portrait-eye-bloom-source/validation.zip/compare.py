from hashlib import sha256
from pathlib import Path
import json
import os
import runpy
import subprocess

import numpy as np

out = Path(__file__).resolve().parent
grid = out.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
helpers = runpy.run_path(str(grid / 'iris-production-frozen-recovery.py'))
read, dump, invoke = (helpers[key] for key in ('read','dump','invoke'))
build = helpers['build']
lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state'] == 'held' and Path(lock['output']) == out
repo = grid.parents[2]
source = repo / 'shaders/inner_outline.frag'
rule, = (r for r in read(build/'shader-reload.json')['programs'] if r['output']=='inner_outline.frag.spv')
sdk = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
resource = out / 'resources'
shaders = resource / 'shaders'
if not shaders.is_dir():
    shaders.mkdir(parents=True)
    for path in (build/'shaders').glob('*.spv'):
        if path.name != rule['output']:
            (shaders/path.name).hardlink_to(path)
    (resource/'runtime-build-Release.json').hardlink_to(build/'runtime-build-Release.json')


def replace_shader(mode, expression):
    code = source.read_text()
    old = ('        hdrColor += bloom;' if mode=='direct-bloom'
           else '        vec3 hdrColor = texture(sceneColorTexture, screenUv).rgb;')
    assert code.count(old)==1
    path = out / f'{mode}.frag'
    path.write_text(code.replace(old, old + '\n        return vec4(' + expression + ',1.0);'))
    target = shaders / rule['output']
    subprocess.run([str(sdk/'glslc.exe'), *rule['arguments'], *('-D'+d for d in rule['defines']),
                    '-I'+str(source.parent), str(path), '-o', str(target)], check=True)
    subprocess.run([str(sdk/'spirv-val.exe'), '--target-env', 'vulkan1.3', '--relax-block-layout', str(target)], check=True)
    return sha256(target.read_bytes()).hexdigest()


scorer = runpy.run_path(str(grid/'static-quality.py'))
image = scorer['image']
destination = out/'results.json'
report = read(destination) if destination.is_file() else {}
peak = np.array([667,808])
point = lambda xy: (int(xy[0]),int(xy[1]))
offsets = np.array([[-4,0],[4,0],[0,-4],[0,4],[-2.8,-2.8],[2.8,-2.8],[-2.8,2.8],[2.8,2.8]])


def linearize(value):
    v = value.astype(float)/255
    return np.where(v <= .04045, v/12.92, ((v+.055)/1.055)**2.4)


def footprint(field):
    coords = peak+offsets
    x,y = np.rint(coords).astype(int).T
    return coords,field[y,x]


probes = {
    'hdr': 'clamp(hdrColor/16.0,0.0,1.0)',
    'scene-mask': 'vec3(texture(displayMaskTexture,screenUv).r)',
}
if os.environ.get('AZURE_NR_BLOOM_RETEST'):
    probes = {'direct-bloom': 'clamp(bloom*4.0,0.0,1.0)'}
for mode, expression in probes.items():
    shader = replace_shader(mode, expression)
    for device in ('nvidia','intel'):
        folder = out/f'{device}-{mode}'
        folder.mkdir()
        command = read(grid/f'portrait-{device}-command.json')
        for flag,value in (('--capture-dir',folder/'frames'),('--runtime-report',folder/'runtime.json'),
                           ('--resource-root',resource)):
            command[command.index(flag)+1]=str(value)
        frame = invoke(device,command,folder)/'frame_000000.png'
        rgb = image(frame)
        field = linearize(rgb) * {'hdr':16,'direct-bloom':.25}.get(mode,1)
        coordinates, samples = footprint(field)
        row = report.setdefault(device, {})
        row[mode] = dict(frameSha256=sha256(frame.read_bytes()).hexdigest(), shaderSha256=shader,
                         peak=field[808,667].tolist(), coordinates=coordinates.tolist(), samples=samples.tolist(),
                         patch=field[802:815,661:674].tolist())
        if mode=='hdr':
            contribution = np.maximum(samples - 1.05,0) * (.16/8)
            row[mode].update(contributions=contribution.tolist(), sum=contribution.sum(0).tolist())
        (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
