"""Record artifact identity and pixel scope of the four existing joint captures."""
from pathlib import Path
import hashlib
import json

import numpy as np
from PIL import Image


engine=Path.cwd().resolve()
root=engine/'build/runs'
out=Path(__file__).resolve().parent
kit=root/'20261114-040710-nr-native-frozen-59282-replay-kit-b9ac16'
frozen=root/'20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames'
current=kit/'historical-59579/frames'
info=json.loads((kit/'preflight.json').read_bytes())
assert info['frozenDriver']=='592.82' and info['frozenInputCount']==1729


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


cases=[]
for source in info['frozenFrames']:
    name=source['name']
    ref,prod=frozen/name,current/name
    assert sha(ref)==source['referenceSha256']
    with Image.open(ref) as image:
        a=np.asarray(image.convert('RGB'),dtype=np.int16)
    with Image.open(prod) as image:
        b=np.asarray(image.convert('RGB'),dtype=np.int16)
    assert a.shape==b.shape==(1440,2560,3)
    changed=np.abs(b-a).max(axis=2)
    points=np.transpose(np.where(changed>1))
    rows=[{'x':int(x),'y':int(y),'frozenRGB':[int(v) for v in a[y,x]],'replayRGB':[int(v) for v in b[y,x]]} for y,x in points]
    cases.append({'name':name,'frozenSha256':sha(ref),'replaySha256':sha(prod),'changedPixels':int(np.count_nonzero(changed)),
                  'exactlyOneLevel':int(np.count_nonzero(changed==1)),'moreThanOneLevel':len(rows),'maxRGBDelta':int(changed.max()),
                  'diagnosticPoints':rows})
assert [c['changedPixels'] for c in cases]==[228,330,397,421]
assert [c['moreThanOneLevel'] for c in cases]==[0,3,4,4]
report={'frozenDriver':'592.82','replayDriver':'595.79','historicalCommit':'cd8d95d','referenceGateChangedPixels':0,
        'strictPass':False,'width':2560,'height':1440,'cases':cases}
(out/'joint-frozen-driver-pixel-scope.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print([c['moreThanOneLevel'] for c in cases],flush=True)
