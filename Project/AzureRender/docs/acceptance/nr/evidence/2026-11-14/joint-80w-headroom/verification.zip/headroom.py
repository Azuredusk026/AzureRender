"""Quantify the minimum joint-scene cost reduction using the actual 80 W samples."""
from pathlib import Path
import csv
import hashlib
import json
import math


root=Path(__file__).resolve().parent
source=root.parent/'20261114-034546-nr-joint-nonlocal-80w-timing-c8b31a'
result=json.loads((source/'results.json').read_bytes())
assert not result['gates']['gpuP95'] and not result['gates']['thermalAndAC']
warmup=result['warmup']
frames=result['frames']
assert (warmup,frames,result['gpuPowerLimitWatts'],result['driver'])==(300,1800,[80.0],'595.79')
with (source/'timing.csv').open(newline='',encoding='utf-8') as f:
    rows=list(csv.DictReader(f))
assert len(rows)==warmup+frames
for i,row in enumerate(rows,1):
    assert int(row['frame'])==i
    assert abs(sum(float(row[k]) for k in ('sceneMs','shadowMs','postProcessMs'))-float(row['frameMs']))<0.001


def p95(values):
    values=sorted(values)
    return values[math.ceil(len(values)*0.95)-1]


def needed(rows,target,phase=None):
    costs=[float(row['frameMs'])-target for row in rows]
    if phase is not None:
        costs=[cost/float(row[phase]) if float(row[phase])>0 else (float('inf') if cost>0 else -1.0)
               for cost,row in zip(costs,rows)]
    return max(0,p95(costs))


data={}
for label,scope in [('measured',rows[warmup:]),('last300',rows[-300:])]:
    p95_ms=p95(float(row['frameMs']) for row in scope)
    reduction_required=needed(scope,16.6)
    reduce_shadow=needed(scope,16.6,'shadowMs')
    reduce_scene=needed(scope,16.6,'sceneMs')
    data[label]=dict(frames=len(scope),gpuP95Ms=p95_ms,steadyPerFrameMsRequired=reduction_required,
        shadowFractionRequired=reduce_shadow,sceneFractionRequired=reduce_scene,
        noShadowClockUnchangedP95Ms=p95(float(row['frameMs'])-float(row['shadowMs']) for row in scope),
        noPostProcessClockUnchangedP95Ms=p95(float(row['frameMs'])-float(row['postProcessMs']) for row in scope),
        powerMatched=True,thermalGateStillFails=True)
assert abs(data['measured']['gpuP95Ms']-18.61)<0.02
out={'timeSeriesSha256':hashlib.sha256((source/'timing.csv').read_bytes()).hexdigest(),
     'sourceResultsSha256':hashlib.sha256((source/'results.json').read_bytes()).hexdigest(),
     'scope':'Arithmetic on measured GPU spans, not a proposed pass removal or runtime prediction',
     'windows':data}
(root/'joint-80w-phase-headroom.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data,indent=2))
