from hashlib import sha256
from pathlib import Path
from xml.etree import ElementTree as ET
import argparse
import json
import re
import os
import subprocess
import sys

run=Path(__file__).resolve().parent
queue=Path('D:/Projects/FYP-coordination/tools/dispatch.py')
owner='01a1d0a8-a74c-7cc0-85e8-540a6653098a'
pattern=re.compile(r'(debug|release)-(gpu|cpu)-[0-9]{2}')
def read(path): return json.loads(path.read_bytes())
def digest(path): return sha256(path.read_bytes()).hexdigest()
def artifact(base,ending): return run/(base+ending)
def records(path):
    items=ET.parse(path).findall('.//testcase')
    assert len({x.get('name') for x in items})==len(items)
    return {x.get('name'):x for x in items}
def status(item):
    if item.find('failure') is not None:return 'failed'
    if item.find('skipped') is not None:return 'skipped'
    return 'passed'
def raw_paths(config,tag):
    return [artifact(config,'-products.json'),artifact(config,'-inventory.json'),artifact(config,'-tests-source.json'),
            *(artifact(tag,ext) for ext in ('.json','.xml','.txt'))]
def seal(paths):
    return {p.relative_to(run).as_posix():digest(p) for p in paths}
def verify(path):
    data=read(path)
    for name, expected in data['identity'].items():
        live=run/name
        if digest(live)==expected:
            continue
        original=run/'before-volume-resume-shader-receipt'/name
        assert data['original']=='release-cpu-04' and name.startswith('release-cpu-04.')
        assert digest(original)==expected
    assert seal(run/p for p in data['retestIdentity'])==data['retestIdentity']
    scope=records(run/(data['retest']+'.xml'))
    assert all(status(scope[name])=='passed' for name in data['recovered'])
    return data
def write(path,data):
    temp=path.with_suffix(path.suffix+f'.{os.getpid()}.pending')
    temp.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    os.replace(temp,path)

def retry(shard,retry_reason,attempt,timeout_for_queue,cases=()):
    assert (m:=pattern.fullmatch(shard))
    config,lane=m.groups()
    assert attempt>=1 and timeout_for_queue>0
    prior=artifact(shard,'.json')
    report=read(prior)
    assert report['status']=='review'
    names={*report['failed'],*report['skipped']}
    assert names
    original=records(artifact(shard,'.xml'))
    assert names=={n for n,item in original.items() if status(item)!='passed'}
    if cases:
        assert len(cases)==len(set(cases)) and set(cases)<=names, (cases,names)
        names=set(cases)
    inputs=seal(raw_paths(config,shard))
    by_name={t['name']:t for t in read(artifact(config,'-inventory.json'))['tests']}
    assert names<=by_name.keys()
    retry_name=f'{shard}-focused-retry-{attempt:02}'
    query=artifact(retry_name,'.txt')
    assert not query.exists(),query
    query.write_text(''.join(name+'\n' for name in sorted(names)),encoding='utf-8')
    duration=sum(float(next((p['value'] for p in by_name[name]['properties'] if p['name']=='TIMEOUT'),180)) for name in names)
    suffixes=(retry_name+'.xml',retry_name+'.json',retry_name+'.txt')
    args=[sys.executable,'-B','-X','utf8',str(queue),'run','--owner',owner,'--task',retry_name,'--run',run.name,
          '--kind','gpu' if lane=='gpu' else 'build','--priority','P0',
          '--wait-timeout',str(timeout_for_queue),'--timeout',str(max(900,int(duration)+420)),
          '--command',sys.executable,'-B','-X','utf8',str(run/'full.py'),'suite',config.capitalize(),'--select',retry_name]
    with artifact(retry_name,'-queue.log').open('xb') as out:
        command=subprocess.run(args,cwd=Path.cwd(),env=dict(os.environ,CODEX_THREAD_ID=owner),stdout=out,stderr=subprocess.STDOUT)
    assert seal(raw_paths(config,shard))==inputs
    if not artifact(retry_name,'.json').is_file():
        raise SystemExit(command.returncode or 1)
    retest=read(artifact(retry_name,'.json'))
    assert retest['exitCode']==command.returncode
    outcome=records(artifact(retry_name,'.xml'))
    assert retest['selectedTests']==len(names) and names<=outcome.keys()
    assert set(retest['failed'])=={name for name,case in outcome.items() if status(case)=='failed'}
    assert set(retest['skipped'])=={name for name,case in outcome.items() if status(case)=='skipped'}
    # A failing auto-included fixture must be examined before accepting any of its dependents.
    assert all(status(outcome[x])=='passed' for x in outcome.keys()-names)
    fixed=sorted(name for name in names if status(outcome[name])=='passed')
    record=dict(original=shard,retest=retry_name,reason=retry_reason,identity=inputs,retestIdentity=seal(run/p for p in suffixes),
        targeted=sorted(names),recovered=fixed,unresolved=sorted(names-set(fixed)))
    receipt=run/(retry_name+'-receipt.json')
    write(receipt,record)
    assert verify(receipt)==record
    print(json.dumps(record,indent=2),flush=True)
    return 0 if not record['unresolved'] else 8

def apply_retests(bases):
    for config,data in bases.items():
        fixed={}
        failures=set(data['failed'])|set(data['skipped'])
        for path in run.glob(config+'-*-*-focused-retry-*-receipt.json'):
            k=verify(path)
            for n in k['recovered']:
                if n in failures:fixed[n]=path.name
        data['passed']+=len(fixed)
        data['failed']=sorted(set(data['failed'])-fixed.keys())
        data['skipped']=sorted(set(data['skipped'])-fixed.keys())
        data['verifiedReruns']=fixed
        assert data['passed']<=data['expected']
    return bases

def summarize():
    raw=subprocess.check_output([sys.executable,'-B','-X','utf8',str(run/'controller.py'),'summary'],cwd=Path.cwd())
    bases=apply_retests(json.loads(raw))
    print(json.dumps(bases,indent=2))
    return 0 if all(r['passed']==r['expected'] for r in bases.values()) else 8

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    subs=ap.add_subparsers(dest='mode',required=True)
    subs.add_parser('summary')
    run_args=subs.add_parser('retry')
    run_args.add_argument('shard')
    run_args.add_argument('--reason',required=True)
    run_args.add_argument('--attempt',type=int,required=True)
    run_args.add_argument('--wait-timeout',type=int,default=14400)
    run_args.add_argument('--case',action='append',default=[])
    a=ap.parse_args()
    raise SystemExit(summarize() if a.mode=='summary' else retry(a.shard,a.reason,a.attempt,a.wait_timeout,a.case))
