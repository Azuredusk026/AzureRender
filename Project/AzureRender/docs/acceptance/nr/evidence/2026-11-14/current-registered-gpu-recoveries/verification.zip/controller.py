from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET
import focused_retry as focus

root = Path.cwd()
out = Path(__file__).resolve().parent
coord = Path('D:/Projects/FYP-coordination/tools/dispatch.py')
py = sys.executable
configs = ('Release', 'Debug')

def read(name):
    return json.loads((out / name).read_text(encoding='utf-8-sig'))

def dispatch(task, kind, timeout, args):
    command = [py, '-B', '-X', 'utf8', str(coord), 'run', '--owner', os.environ['CODEX_THREAD_ID'],
               '--task', task, '--run', out.name, '--kind', kind, '--priority',
               os.environ.get('AZURE_REGISTERED_QUEUE_PRIORITY', 'P0'),
               '--wait-timeout', '14400', '--timeout', str(timeout), '--command',
               py, '-B', '-X', 'utf8', *args]
    with (out / (task + '-queue.log')).open('ab') as log:
        return subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode

def properties(test):
    return {entry['name']: entry['value'] for entry in test['properties']}

def seeded(config):
    if not (out / 'registered-seed.json').is_file():
        return set()
    scope = read('registered-seed.json')[config.lower()]
    def digest(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()
    for path, expected in scope['provenance'].items():
        assert digest(out / path) == expected, path
    names = set()
    for path, expected in scope['junit'].items():
        assert digest(out / path) == expected, path
        for case in ET.parse(out / path).findall('.//testcase'):
            assert case.find('failure') is None and case.find('skipped') is None
            names.add(case.attrib['name'])
    return names

def selection(config):
    name = config.lower()
    expected = {'release': 607, 'debug': 605}
    registry = read(name + '-inventory.json')['tests']
    assert len(registry) == expected[name], (config, len(registry))
    assert len({test['name'] for test in registry}) == len(registry)
    already_passed = seeded(config)
    assert already_passed <= {test['name'] for test in registry}
    cpu, gpu = [], []
    for index, test in enumerate(registry, 1):
        if test['name'] in already_passed:
            continue
        labels = properties(test).get('LABELS', [])
        (gpu if 'gpu' in labels else cpu).append((index, test))
    priority = (
        'AzureEngine.GamePackage', 'AzureEngine.PlayablePackage',
        'AzureRender.ScreenObjectVisibilityReferenceGpu', 'AzureEngine.EditorPlayable',
        'AzureEngine.EditorHost',
    )
    order = {test: index for index, test in enumerate(priority)}
    gpu.sort(key=lambda case: order.get(case[1]['name'], len(order)))
    return cpu, gpu

def groups(items, gpu):
    selected, seconds = [], 0
    for index, test in items:
        limit = float(properties(test).get('TIMEOUT', 180 if gpu else 60))
        if selected and (seconds + limit > (2400 if gpu else 1800)):
            yield selected, seconds
            selected, seconds = [], 0
        selected.append((index, test['name']))
        seconds += limit
    if selected:
        yield selected, seconds

def has_verified_resolution(task, report):
    remaining = set(report['failed']) | set(report['skipped'])
    recovery = set()
    if not remaining:
        return False
    for receipt in out.glob(task + '-focused-retry-*-receipt.json'):
        data = focus.verify(receipt)
        assert data['original'] == task
        recovery.update(data['recovered'])
    return remaining <= recovery

def run_groups(config, index):
    workload = 'gpu' if index else 'cpu'
    for number, (tests, seconds) in enumerate(groups(selection(config)[index], index), 1):
        task = f'{config.lower()}-{workload}-{number:02}'
        report_path = out / (task + '.json')
        if report_path.is_file():
            existing = read(report_path.name)
            if existing['status'] == 'passed' or has_verified_resolution(task, existing):
                continue
        review_receipts = (out / 'strict-visual-regression/executed-visual-results.json',
                           out / 'before-devtools-host-retest/executed-devtools-results.json')
        if report_path.is_file():
            prior = next((json.loads(receipt.read_bytes()).get(task)
                          for receipt in review_receipts if receipt.is_file()
                          and task in json.loads(receipt.read_bytes())), None)
            if prior:
                report = read(report_path.name)
                assert report['status'] == 'review' and report['failed'] == [prior['test']]
                assert not report['skipped']
                assert hashlib.sha256(report_path.read_bytes()).hexdigest() == prior['resultsSha256']
                assert hashlib.sha256(report_path.with_suffix('.xml').read_bytes()).hexdigest() == prior['junitSha256']
                continue
            # A review receipt is immutable. The focused retry lane runs the
            # failed subset without replacing the registered JUnit and receipt.
            if read(report_path.name)['status'] == 'review':
                continue
        choices = out / (task + '.txt')
        choices.write_text(''.join(name + '\n' for _, name in tests), encoding='utf-8')
        rc = dispatch(task, 'gpu' if index else 'build', max(900, int(seconds) + 420),
                      [str(out / 'full.py'), 'suite', config, '--select', task])
        if not report_path.is_file():
            return rc or 1
        if rc:
            report = read(report_path.name)
            if report.get('status') != 'review' or report.get('exitCode') != rc or not (report['failed'] or report['skipped']):
                return rc
        report = summary()
        progress = out / 'registered-progress.pending'
        progress.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
        progress.replace(out / 'registered-progress.json')
    return 0

def summary():
    result = {}
    for config in configs:
        c = config.lower()
        expected = {t['name'] for t in read(c + '-inventory.json')['tests']}
        outcomes = {name: {'passed'} for name in seeded(config)}
        for report in out.glob(f'{c}-*-??.json'):
            info = json.loads(report.read_text(encoding='utf-8'))
            if 'selectedTests' not in info:
                continue
            for case in ET.parse(report.with_suffix('.xml')).findall('.//testcase'):
                name = case.attrib['name']
                assert name in expected, name
                state = ('failed' if case.find('failure') is not None else
                         'skipped' if case.find('skipped') is not None else 'passed')
                outcomes.setdefault(name, set()).add(state)
        result[c] = dict(expected=len(expected), passed=sum(x == {'passed'} for x in outcomes.values()),
                         failed=sorted(k for k, v in outcomes.items() if 'failed' in v),
                         skipped=sorted(k for k, v in outcomes.items() if 'skipped' in v),
                         missing=sorted(expected - outcomes.keys()))
    return result

def merged_summary():
    return focus.apply_retests(summary())

if sys.argv[1:] == ['summary']:
    print(json.dumps(summary(), indent=2))
    raise SystemExit(0)

if not (out / 'release-build-results.json').is_file():
    raise SystemExit('Release build receipt is required')
if not (out / 'debug-build-results.json').is_file():
    code = dispatch('nr-main-integration-debug-build', 'build', 2000,
                    [str(out / 'full.py'), 'build', 'Debug'])
    if code:
        raise SystemExit(code)

# A test failure is kept in its immutable shard receipt. Keep testing
# independent groups; an infrastructure failure stops only its lane.
for index in range(2):
    for config in configs:
        code = run_groups(config, index)
        if code:
            report = merged_summary()
            (out / 'registered-summary.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
            raise SystemExit(code)
report = merged_summary()
(out / 'registered-summary.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
raise SystemExit(0 if all(row['passed'] == row['expected'] for row in report.values()) else 8)
