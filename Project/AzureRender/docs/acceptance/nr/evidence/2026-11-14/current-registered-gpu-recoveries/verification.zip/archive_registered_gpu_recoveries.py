import hashlib
import json
from pathlib import Path
import subprocess
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

from focused_retry import verify


source = Path(__file__).resolve().parent
engine = Path.cwd().resolve()
target = engine / 'docs/acceptance/nr/evidence/2026-11-14/current-registered-gpu-recoveries'
target.mkdir(parents=True, exist_ok=True)
members = {}


def include(p, name=None):
    key = name or p.relative_to(source).as_posix()
    assert key not in members
    members[key] = p.read_bytes()
    return members[key]


cases = {}
for number, scope in ((14, {'AzureRender.SamplingHostGpu', 'AzureEditor.DevtoolsHost'}),
                      (16, {'AzureEngine.ManagedWorkflows.coreclr'})):
    initial = f'release-gpu-{number}'
    rerun = initial + '-focused-retry-01'
    receipt = verify(source / (rerun + '-receipt.json'))
    assert set(receipt['recovered']) == scope == set(receipt['targeted'])
    assert receipt['unresolved'] == []
    include(source / (rerun + '-receipt.json'))
    j = {}
    for name in (initial, rerun):
        for suffix in ('.json', '.txt', '.log', '-queue.log'):
            include(source / (name + suffix))
        xml = include(source / (name + '.xml'))
        j[name] = {x.get('name'): x for x in ET.fromstring(xml).findall('.//testcase')}
    for name in sorted(scope):
        prior, final = j[initial][name], j[rerun][name]
        assert prior.find('failure') is not None
        assert final.find('failure') is None and final.find('skipped') is None
        cases[name] = {'originalResult': 'failed', 'originalSeconds': float(prior.get('time')),
                       'retestResult': 'passed', 'retestSeconds': float(final.get('time')),
                       'originalShard': initial, 'retestShard': rerun}

editor = source / 'release-editor-retest-observation/azure devtools host kun15bi9'
for project in ('exploration', 'inspector'):
    records = include(editor / project / 'compiler-progress.jsonl')
    generation_two = [x for x in map(json.loads, records.splitlines()) if x['generation']=='2']
    assert max(x['recentWrites'] for x in generation_two) == 897
    include(editor / project / 'stderr.log')
for backend in ('coreclr', 'nativeaot'):
    p = engine / 'build/ninja-msvc-release/managed-workflows' / backend / 'summary.json'
    status = json.loads(include(p, 'managed/' + backend + '.json'))
    assert status['status']=='passed' and status['package']['moved'] and status['package']['tamperRejected']
for name in ('focused_retry.py', 'controller.py', 'test_resume_receipts.py', 'observe_editor_retest.py', Path(__file__).name):
    include(source / name)

archive = target / 'verification.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for name, data in sorted(members.items()):
        z.writestr(name,data)
with ZipFile(archive) as z:
    assert z.testzip() is None and all(z.read(k)==v for k,v in members.items())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
products = {n: sha(source / (n+'.json')) for n in ('release-products','release-inventory','release-tests-source')}
protected = json.loads((source/'protected-files.json').read_bytes())
assert all(sha(engine / k)==v for k,v in protected.items())
subprocess.run(['git','diff','--check'],check=True,cwd=engine)
result = {'date':'2026-11-14','scope':'Three recovered Release registered cases',
          'configuration':'Release','cases':cases,'provenanceFiles':products,
          'archive':{'members':len(members),'bytes':archive.stat().st_size,'sha256':sha(archive)}}
(target / 'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
