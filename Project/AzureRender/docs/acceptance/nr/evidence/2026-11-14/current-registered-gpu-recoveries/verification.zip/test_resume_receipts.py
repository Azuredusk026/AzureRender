import ast
import pathlib
import types


root = pathlib.Path(__file__).resolve().parent
source = root / 'controller.py'
tree = ast.parse(source.read_text(encoding='utf-8'))
defs = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
ns = {'out': root, 'focus': types.SimpleNamespace(), 'json': __import__('json')}

# The real, sealed retest must appear in the final merged report after a
# controller restart. An unresolved case must stay in the result.
expected = ['AzureEditor.DevtoolsHost', 'AzureRender.SamplingHostGpu']
raw = {'release': {'expected': 607, 'passed': 442, 'failed': expected + ['unresolved'], 'skipped': []},
       'debug': {'expected': 605, 'passed': 336, 'failed': [], 'skipped': []}}
ns['summary'] = lambda: raw
ns['focus'] = __import__('focused_retry')
if 'merged_summary' in defs:
    node = ast.Module(body=[defs['merged_summary']], type_ignores=[])
    exec(compile(node, str(source), 'exec'), ns)
else:
    ns['merged_summary'] = ns['summary']
merged = ns['merged_summary']()
assert merged['release']['passed'] == 444, merged
assert merged['release']['failed'] == ['unresolved'], merged
assert set(merged['release']['verifiedReruns']) == set(expected), merged
assert merged['debug']['passed'] == 336, merged
assert 'has_verified_resolution' in defs, 'Resume must not overwrite a completed focused recovery'
node = ast.Module(body=[defs['has_verified_resolution']], type_ignores=[])
exec(compile(node, str(source), 'exec'), ns)
assert ns['has_verified_resolution']('release-gpu-14', {'failed': expected, 'skipped': []})
assert not ns['has_verified_resolution']('release-gpu-14', {'failed': expected + ['unresolved'], 'skipped': []})
assert not ns['has_verified_resolution']('release-gpu-14', {'failed': [], 'skipped': []})
print('verified retest receipts merge while unresolved failure remains')
