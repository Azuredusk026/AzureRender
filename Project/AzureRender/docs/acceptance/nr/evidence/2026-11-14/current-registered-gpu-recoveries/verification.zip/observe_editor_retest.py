import argparse
import json
import os
from pathlib import Path
import shutil
import time


def sample(root, output, start, previous):
    temp_root = root / 'tmp'
    for temp in (*temp_root.glob('azure devtools host *'), *temp_root.glob('azure shader host *')):
        for workflow in ('exploration', 'inspector'):
            folder = temp / workflow
            destination = output / temp.name / workflow
            if not folder.is_dir() or folder.stat().st_mtime < start:
                continue
            destination.mkdir(parents=True, exist_ok=True)
            for name in ('stdout.log', 'stderr.log', 'control-results.json', 'operations.json'):
                source = folder / name
                if source.is_file() and source.stat().st_size <= 4 * 1024 * 1024:
                    path = destination / name
                    pending = path.with_suffix(f'.{os.getpid()}.pending')
                    try:
                        shutil.copyfile(source, pending)
                        os.replace(pending, path)
                    except (FileNotFoundError, PermissionError):
                        pass
            options_path = folder / 'reload.json'
            try:
                options = json.loads(options_path.read_bytes())
            except (FileNotFoundError, PermissionError, ValueError):
                continue
            if int(options.get('maximumPrograms', 0)) > 1024:
                continue
            scratch = Path(options.get('scratchRoot', folder / 'shader candidates'))
            if scratch.parent != folder:
                continue
            for generation in scratch.glob('[0-9]*'):
                program_files = list((generation / 'binary').rglob('*.spv'))
                new = sum(1 for p in program_files if p.stat().st_mtime > start) if program_files else 0
                row = {'generation': generation.name, 'programFiles': len(program_files), 'recentWrites': new,
                       'catalogPrograms': len(options['programs']), 'compilerTimeoutMs': options.get('timeoutMs')}
                key = (workflow, str(generation))
                if previous.get(key) != row:
                    previous[key] = row
                    with (destination / 'compiler-progress.jsonl').open('a', encoding='utf-8') as f:
                        print(json.dumps(dict(at=time.time(), **row)), file=f)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--seconds', type=int, default=1800)
    p.add_argument('--self-test', action='store_true')
    args = p.parse_args()
    root = Path(__file__).resolve().parent
    out = root / 'release-editor-retest-observation'
    out.mkdir(exist_ok=True)
    if args.self_test:
        control = out / 'observer-control'
        folder = control / 'tmp' / 'azure devtools host control' / 'exploration'
        folder.mkdir(parents=True, exist_ok=True)
        (folder / 'endpoint.json').write_text('excluded', encoding='utf-8')
        (folder / 'stderr.log').write_text('compiler diagnostic control', encoding='utf-8')
        (folder / 'reload.json').write_text('{"maximumPrograms": 1, "programs": [1]}', encoding='utf-8')
        bindir = folder / 'shader candidates' / '2' / 'binary'
        bindir.mkdir(parents=True, exist_ok=True)
        (bindir / 'control.spv').write_bytes(b'staging control')
        result = control / 'output'
        recent = {}
        for _ in range(2):
            sample(control, result, time.time() - 30, recent)
        files = sorted(x.name for x in result.rglob('*') if x.is_file())
        assert files == ['compiler-progress.jsonl', 'stderr.log'], files
        stats = list(result.rglob('compiler-progress.jsonl'))[0]
        assert len(stats.read_text().splitlines()) == 1
        assert json.loads(stats.read_text())['recentWrites'] == 1
        print('observer copied log, recorded one distinct compiler state, excluded endpoint and binaries')
        return
    start = time.time() - 180
    deadline = time.monotonic() + args.seconds
    states = {}
    while time.monotonic() < deadline:
        try:
            sample(root, out, start, states)
        except (FileNotFoundError, PermissionError):
            pass
        if all((root / f'release-gpu-{n}-focused-retry-01-receipt.json').is_file() for n in (14, 15)):
            break
        time.sleep(2)


if __name__ == '__main__':
    main()
