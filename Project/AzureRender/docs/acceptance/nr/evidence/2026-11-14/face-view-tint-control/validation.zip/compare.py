from hashlib import sha256
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5
import json
import runpy

import cv2
import numpy as np
from PIL import Image

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
prior = out.parent/'20261114-034155-face-chroma-source-7aa30b'
fixture = grid/'iris-overlay-geometry-project'
helpers = runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read, dump, invoke = (helpers[k] for k in ('read','dump','invoke'))
lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==out
data = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-212213-native-binding-restoration-d39ea8/frame10401')
constants = np.fromfile(data/'e804-PS-cb6.bin','<f4').reshape(-1,4)
settings = dict(schemaVersion=1,scale=.85*float(constants[12,1]),color=constants[13,:3].tolist())
base_name = 'face-native-main-saturation-production'
project = read(fixture/f'{base_name}.azureproject')
scene = read(fixture/'scene'/f'{base_name}.azurelevel')
spec = read(fixture/'materials'/f'{base_name}.azurematerial')
profile = spec['surface']['materials'][0]['extras']['azureRenderMaterial']
assert profile['nprDiffuse']['mainBrightnessSaturation'] is True and 'viewTint' not in profile['nprDiffuse']
profile['nprDiffuse']['viewTint'] = settings
name = 'face-main-saturation-view-tint'
asset = str(uuid5(NAMESPACE_URL,'azurerender/804/'+name))
path = fixture/'materials'/f'{name}.azurematerial'
dump(path,spec)
dump(path.with_suffix('.azurematerial.azmeta'),dict(schemaVersion=1,id=asset,dependencies=[],settings={}))
hero = next(n for n in scene['nodes'] if n['id']=='hero')
hero['materialSlots']['name:M_actor_laevat_face_01']=asset
dump(fixture/'scene'/f'{name}.azurelevel',scene)
project['startupScene']=f'stage:/{name}.azurelevel'
candidate = fixture/f'{name}.azureproject'
dump(candidate,project)

scorer = runpy.run_path(str(grid/'static-quality.py'))
image = lambda p: scorer['image'](p).astype(np.int16)
reference = image(scorer['reference_path'])
mask = cv2.erode(np.asarray(Image.open(grid/'native-face-masks/face.png').convert('L')),np.ones((13,13),np.uint8))>0
assert mask.sum()==1176
report = dict(profile=settings,devices={})
for device in ('nvidia','intel'):
    folder = out/device
    folder.mkdir()
    baseline = prior/f'production-{device}-enabled'
    command = read(baseline/'command.json')
    for flag,value in (('--project',candidate),('--capture-dir',folder/'frames')):
        command[command.index(flag)+1] = str(value)
    frame = invoke(device,command,folder)/'frame_000000.png'
    previous = image(baseline/'frames/frame_000000.png')-reference
    current = image(frame)-reference
    old,new = [np.abs(field).max(2) for field in (previous,current)]
    report['devices'][device] = dict(frame=sha256(frame.read_bytes()).hexdigest(),
        overOne=[int((error[mask]>1).sum()) for error in (old,new)],
        peak=[int(error[mask].max()) for error in (old,new)],
        median=[np.median(field[mask],axis=0).tolist() for field in (previous,current)],
        meanAbsolute=[np.abs(field[mask]).mean(0).tolist() for field in (previous,current)],
        newOutsideOverOne=int(((old<=1)&(new>1)&~mask).sum()))
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
