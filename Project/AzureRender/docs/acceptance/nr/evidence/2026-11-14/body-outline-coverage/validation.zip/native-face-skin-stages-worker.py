from hashlib import sha256
from pathlib import Path
import json,os,struct,traceback
import renderdoc as rd

out=Path(os.environ['AZURE_NR_FACE_SKIN_STAGES'])
job=json.loads((out/'request.json').read_bytes())
locations={kind:list(struct.iter_unpack('<II',Path(path).read_bytes())) for kind,path in job['points'].items()}
assert set(locations)=={'face','skin'} and all(locations.values())
cap=rd.OpenCaptureFile()
ctl=None
result=dict(status='failed',rows={},geometry={})
try:
    assert cap.OpenFile(job['native'],'',None)==rd.ResultCode.Succeeded
    opt=rd.ReplayOptions(); opt.forceGPUVendor=rd.GPUVendor.nVidia; opt.forceGPUDeviceID=0x28e0
    status,ctl=cap.OpenCapture(opt,None)
    assert status==rd.ResultCode.Succeeded and ctl
    props=ctl.GetAPIProperties()
    assert props.vendor==rd.GPUVendor.nVidia and not props.degraded
    for event in (782,783,803,804,825,846,950,1017,1018,1138,1160,1230,1245,1267,1291,1314,1339,1358,1382,1383):
        ctl.SetFrameEvent(event,True)
        if event in (782,1230):
            target=ctl.GetPipelineState().GetOutputTargets()[0].resource
            assert str(target)==('ResourceId::141976' if event==782 else 'ResourceId::141925')
        data=bytes(ctl.GetTextureData(target,rd.Subresource()))
        assert len(data)==2560*1440*4
        current={}
        for kind,points in locations.items():
            selected=b''.join(data[i:i+4] for i in (((1439-y)*2560+x)*4 for x,y in points))
            (out/f'{kind}-{event}.bin').write_bytes(selected)
            current[kind]=dict(samples=len(points),sha256=sha256(selected).hexdigest())
        result['rows'][event]=current
        if event in (783,804,1018,1383):
            pipe=ctl.GetPipelineState()
            reflection=pipe.GetShaderReflection(rd.ShaderStage.Vertex)
            pixel=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
            if event in (804,1018):
                (out/f'pixel-{event}.dxbc').write_bytes(bytes(pixel.rawBytes))
                if event==804:
                    disassembly=ctl.DisassembleShader(pipe.GetGraphicsPipelineObject(),pixel,'')
                    (out/'pixel-804.txt').write_text(disassembly,encoding='utf8')
                bound={pixel.readOnlyResources[slot.access.index].fixedBindNumber:slot.descriptor.resource for slot in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel)}
                if event==804:
                    textures={item.resourceId:item for item in ctl.GetTextures()}
                    result['faceTextures']={}
                    for binding in (18,20):
                        resource=bound[binding]
                        description=textures[resource]
                        descriptor=next(slot.descriptor for slot in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel) if pixel.readOnlyResources[slot.access.index].fixedBindNumber==binding)
                        levels=[]
                        for mip in range(description.mips):
                            data=bytes(ctl.GetTextureData(resource,rd.Subresource(mip,0,0)))
                            path=out/f'face-t{binding}-mip{mip}.bin'
                            path.write_bytes(data)
                            levels.append(dict(path=path.name,size=len(data),sha256=sha256(data).hexdigest()))
                        result['faceTextures'][binding]=dict(resource=str(resource),width=description.width,height=description.height,format=descriptor.format.Name(),resourceFormat=description.format.Name(),levels=levels)
            q=ctl.GetPostVSData(0,0,rd.MeshDataStage.VSOut)
            vs=bytes(ctl.GetBufferData(q.vertexResourceId,q.vertexByteOffset,0))
            ix=bytes(ctl.GetBufferData(q.indexResourceId,q.indexByteOffset,q.numIndices*q.indexByteStride))
            (out/f'vertex-{event}.bin').write_bytes(vs)
            (out/f'index-{event}.bin').write_bytes(ix)
            signature=[dict(name=value.semanticIdxName,components=int(value.compCount),type=int(value.varType)) for value in reflection.outputSignature]
            result['geometry'][event]=dict(vertexStride=int(q.vertexByteStride),indexStride=int(q.indexByteStride),indices=int(q.numIndices),
                baseVertex=int(q.baseVertex),signature=signature,vertexSha256=sha256(vs).hexdigest(),indexSha256=sha256(ix).hexdigest(),
                pixelShaderSha256=sha256(bytes(pixel.rawBytes)).hexdigest())
    result['history']={}
    for kind,event,points in (('face',804,locations['face']),('skin-outline',1018,locations['skin']),('cloth',1383,locations['skin'])):
        ctl.SetFrameEvent(event,True)
        target=ctl.GetPipelineState().GetOutputTargets()[0].resource
        hits=[]
        for x,y in points:
            history=ctl.PixelHistory(target,x,1439-y,rd.Subresource(),rd.CompType.Typeless)
            for row in history:
                if row.eventId!=event or row.depthTestFailed or row.stencilTestFailed or row.backfaceCulled or row.shaderDiscarded:
                    continue
                hits.append(dict(x=x,y=y,primitive=int(row.primitiveID),shaderOut=list(row.shaderOut.col.floatValue),
                   before=list(row.preMod.col.floatValue),after=list(row.postMod.col.floatValue)))
        result['history'][kind]=hits
    result['status']='qualified'
except Exception:
    result['error']=traceback.format_exc()
finally:
    if ctl:
        ctl.Shutdown()
    cap.Shutdown()
    (out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
os._exit(0 if result['status']=='qualified' else 1)






