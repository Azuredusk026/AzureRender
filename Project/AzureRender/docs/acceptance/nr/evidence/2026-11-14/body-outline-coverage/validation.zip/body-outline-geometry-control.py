from pathlib import Path
from hashlib import sha256
from uuid import NAMESPACE_URL,uuid5
import copy, json,math,runpy,struct
import numpy as np

run=Path(__file__).resolve().parent
replay=run/'native-face-skin-stages'
root=run/'iris-overlay-geometry-project'
mod=runpy.run_path(str(run/'iris-production-frozen-recovery.py'))
read,dump,invoke=(mod[key] for key in ('read','dump','invoke'))
score=runpy.run_path(str(run/'static-quality.py'))


def geometry(out):
    report=read(replay/'results.json')
    assert report['status']=='qualified'
    info=report['geometry']['1018']
    assert info['indices']==17037
    for key in ('vertex','index'):
        data=(replay/f'{key}-1018.bin').read_bytes()
        assert sha256(data).hexdigest()==info[f'{key}Sha256']
    assert info['vertexStride']%4==0
    source=np.fromfile(replay/'vertex-1018.bin','<f4').reshape(-1,info['vertexStride']//4)
    ix=np.fromfile(replay/'index-1018.bin','<u'+str(info['indexStride'])).astype(np.int64)+info['baseVertex']
    assert len(ix)==17037 and ix.min()>=0 and ix.max()<len(source)
    source=source[:ix.max()+1]
    assert sum(row['components'] for row in info['signature'] if row['name']!='SV_Position')==source.shape[1]-4
    clip=source[:,:4].astype(float)
    assert np.isfinite(clip).all() and (clip[:,3]>.1).all()
    camera=read(run/'static-nvidia-frames/capture_manifest.json')
    eye=np.asarray(camera['qaCameraPosition']); f=np.asarray(camera['qaCameraTarget'])-eye; f/=np.linalg.norm(f)
    r=np.cross(f,camera['cameraUp']);r/=np.linalg.norm(r);u=np.cross(r,f)
    yscale=math.tan(camera['cameraLens']['verticalFovRadians']*.5); xscale=yscale*2560/1440
    ox,oy=camera['cameraLens']['offsetNdc']; x,y,z,d=clip.T
    positions=eye+np.outer(d,f)+np.outer((x-ox*d)*xscale,r)+np.outer((-y+oy*d)*yscale,u)
    delta=positions.astype('<f4')-eye; depth=delta@f
    restored=np.column_stack(((delta@r)/xscale+ox*depth,-(delta@u)/yscale+oy*depth))
    max_error=float((np.abs(restored/depth[:,None]-clip[:,:2]/d[:,None])*[1280,720]).max())
    assert max_error<.001,max_error
    report['fixtureProjection']=dict(maxPixelError=max_error,vertices=len(positions),indices=len(ix))
    dump(out/'source.json',report['fixtureProjection'])
    return positions.astype('<f4'),ix.reshape(-1,3)[:,[0,2,1]].astype('<u4').reshape(-1)


def prepare(arrays,mode):
    identity=str(uuid5(NAMESPACE_URL,'azurerender/native-body-outline-10401/'+mode))
    path='native-body-outline-'+mode
    pos,ix=arrays
    binary=b''.join((pos.tobytes(),ix.tobytes()))
    material={'name':path,'doubleSided':False,'pbrMetallicRoughness':{'baseColorFactor':[.01,1,.01,1],
              'metallicFactor':0,'roughnessFactor':1},'extras':{'azureRenderMaterial':{
              'schemaVersion':2,'class':'generic','features':['unlit-surface'],'surface':{'schemaVersion':1,'lighting':'unlit'},'displayTransform':'linear'}}}
    gltf=dict(asset={'version':'2.0'},scenes=[{'nodes':[0]}],scene=0,nodes=[{'mesh':0}],
              meshes=[{'primitives':[{'attributes':{'POSITION':0},'indices':1,'material':0}]}],materials=[material],
              buffers=[{'uri':path+'.bin','byteLength':len(binary)}],bufferViews=[{'buffer':0,'byteLength':pos.nbytes},
              {'buffer':0,'byteOffset':pos.nbytes,'byteLength':ix.nbytes}],accessors=[{'bufferView':0,'componentType':5126,
              'count':len(pos),'type':'VEC3','min':pos.min(0).tolist(),'max':pos.max(0).tolist()},
              {'bufferView':1,'componentType':5125,'count':len(ix),'type':'SCALAR'}])
    if mode=='back':
        binary=pos.tobytes()+ix.reshape(-1,3)[:,[0,2,1]].copy().tobytes()
    (root/'character'/f'{path}.bin').write_bytes(binary)
    dump(root/'character'/f'{path}.gltf',gltf)
    dump(root/'character'/f'{path}.gltf.azmeta',dict(schemaVersion=1,id=identity,dependencies=[],settings={}))
    level=read(root/'scene/static-eye-shadow-production.azurelevel')
    level['resources'].append({'id':path,'asset':f'character:/{path}.gltf'})
    level['nodes'].append({'id':path,'resourceId':path,'components':{'azure.transform':{'type':'azure.transform','version':1,'data':{'translation':[0,0,0]}}}})
    dump(root/'scene'/f'{path}.azurelevel',level)
    project=read(root/'eye-shadow-production.azureproject');project['startupScene']=f'stage:/{path}.azurelevel'
    target=root/f'{path}.azureproject';dump(target,project)
    return target


if __name__=='__main__':
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==run
    out=run/'body-outline-geometry-control';out.mkdir()
    arrays=geometry(out)
    owner=read(run/'face-skin-overlay-ownership.json')['skin']['1018']['locations']
    x,y=np.asarray(owner).T;assert len(x)==61
    report={}
    for mode in ('front','back'):
        target=prepare(arrays,mode)
        folder=out/mode;folder.mkdir()
        command=read(run/'static-nvidia-command.json');command[command.index('--project')+1]=str(target)
        command[command.index('--capture-dir')+1]=str(folder/'frames')
        frames=invoke('nvidia',command,folder)
        img=score['image'](frames/'frame_000000.png')
        green=(img[:,:,1]>249)&(img[:,:,0]<32)&(img[:,:,2]<32)
        report[mode]=dict(totalGreen=int(green.sum()),nativeResidualCovered=int(green[y,x].sum()),
                          missing=np.column_stack([x[~green[y,x]],y[~green[y,x]]]).tolist())
        (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
