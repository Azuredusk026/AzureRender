from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import traceback

variable='AZURE_NR_NATIVE_FACE_VIEW_MASK'
out=Path(os.environ[variable]) if variable in os.environ else Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
q=out.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')

def trace():
    import renderdoc as rd
    job=read(out/'trace-face-view-mask-request.json')
    cap=rd.OpenCaptureFile()
    ctl=None
    reply=dict(status='failed',constants={},points=[])
    try:
        assert cap.OpenFile(job['native'],'',None)==rd.ResultCode.Succeeded
        opt=rd.ReplayOptions();opt.forceGPUVendor=rd.GPUVendor.nVidia;opt.forceGPUDeviceID=0x28e0
        state,ctl=cap.OpenCapture(opt,None)
        assert state==rd.ResultCode.Succeeded and ctl
        props=ctl.GetAPIProperties()
        assert props.vendor==rd.GPUVendor.nVidia and props.pipelineType==rd.GraphicsAPI.D3D11 and not props.degraded
        ctl.SetFrameEvent(804,True)
        pipe=ctl.GetPipelineState()
        stage=rd.ShaderStage.Fragment
        reflection=pipe.GetShaderReflection(stage)
        assert sha256(bytes(reflection.rawBytes)).hexdigest()==job['nativeShader']
        for i,block in enumerate(reflection.constantBlocks):
            binding=block.fixedBindNumber
            if binding not in (0,1,2,6):continue
            desc=pipe.GetConstantBlock(stage,i,0).descriptor
            data=bytes(ctl.GetBufferData(desc.resource,desc.byteOffset,desc.byteSize))
            assert len(data)==desc.byteSize
            (out/f'face-view-mask-cb{binding}.bin').write_bytes(data)
            reply['constants'][binding]=dict(bytes=len(data),sha256=sha256(data).hexdigest())
        assert set(reply['constants'])=={0,1,2,6}
        steps={9,32,33,70,72,76,77,78,79,80,81,82,83,84,85,86,87,110,113,114,117,
               339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,
               635,637,638,639,640,641,651,654,658,661,665,681,686,689,692,695,699,704,706}
        for sample in job['nativePoints']:
            x,y=sample['point']
            args=rd.DebugPixelInputs();args.primitive=sample['primitive']
            hit=ctl.DebugPixel(x,1439-y,args)
            assert hit and hit.debugger
            registers={};states={};count=0
            try:
                while True:
                    batch=ctl.ContinueDebug(hit.debugger)
                    if not batch:break
                    for ins in batch:
                        for change in ins.changes:
                            var=change.after
                            if var.name:registers[var.name]=list(var.value.f32v)[:4]
                        step=int(ins.nextInstruction)
                        if step in steps:states[step]={name:var for name,var in registers.items()
                            if name in ('r2','r3','r4','r5','r6','r7','r8','r9','r10','r11','r12','r13','r14','r15','r17','r18','r20','r25','r27')}
                        count+=1
                    assert count<20000
            finally:ctl.FreeTrace(hit)
            assert set(range(339,355))<=set(states)
            reply['points'].append(dict(sample=sample,registers=states,steps=count))
        reply['status']='qualified'
    except Exception:reply['error']=traceback.format_exc()
    finally:
        if ctl:ctl.Shutdown()
        cap.Shutdown()
        write(out/'trace-face-view-mask.json',reply)
    os._exit(0 if reply['status']=='qualified' else 1)

def launch():
    from hashlib import file_digest
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==out
    job=read(q/'face-edge-sampling-request.json')
    with Path(job['native']).open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==job['captureSha256']
    assert len(job['nativePoints'])==12
    write(out/'trace-face-view-mask-request.json',job)
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    with (out/'trace-face-view-mask.log').open('wb') as log:
        proc=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__))],
            cwd=out,env=dict(os.environ,**{variable:str(out)}),stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=220)
    result=read(out/'trace-face-view-mask.json')
    assert proc.returncode==0 and result['status']=='qualified',result.get('error')

if variable in os.environ:trace()
elif __name__=='__main__':launch()
