from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

out=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
native=read(out/'face-view-mask-math.json')
trace=read(out/'trace-face-view-mask.json')
assert trace['status']=='qualified' and len(native['rows'])==len(trace['points'])==12
assert native['blueScaleRange']==[1.0,.699999988079071]
assert max(v['tintFactorReconstructionPeak'] for v in native['rows'])<1.1e-7
frames={}
members=[Path(__file__).name,'face-geometry-mask-actual.py','analyze-face-view-mask.py','trace-face-view-mask.py',
         'trace-face-view-mask.json','trace-face-view-mask-request.json','face-view-mask-math.json']
for b,m in trace['constants'].items():
    p=f'face-view-mask-cb{b}.bin'
    assert digest(out/p)==m['sha256']
    members.append(p)
for mode in ('tint-base','tint-view','tint-all'):
    folder=f'capture-nvidia-{mode}'
    p=out/folder
    r=read(p/'results.json')
    assert digest(p/'frames/frame_000000.png')==r['frameSha256']
    assert r['regions']['outsideFace']['changed']==r['regions']['iris']['changed']==0
    assert read(p/'frames/gpu_capabilities.json')['vendor_id']==0x10de
    frames[mode]=r
    members.extend(f'{folder}/{x}' for x in ('results.json','command.json','runtime.json','frames/gpu_capabilities.json'))
    members.extend(f'assets-{mode}/{x}' for x in ('prepared.json','mesh-face-geometry-mask.frag'))
assert frames['tint-base']['regions']['face']['overOne']==[573,422]
assert frames['tint-base']['samples']['traced']['improved']==11
assert frames['tint-all']['samples']['traced']['errors'][1][:2]==[9,5]
assert frames['tint-all']['regions']['face']['overOne']==[573,582]
dest=out.parents[2]/'docs/acceptance/nr/evidence/2026-11-14/face-view-mask-blue-source'
dest.mkdir(parents=True,exist_ok=False)
with ZipFile(dest/'validation.zip','x',ZIP_DEFLATED) as z:
    for p in members:z.write(out/p,p)
with ZipFile(dest/'validation.zip') as z:assert len(z.namelist())==len(set(members)) and z.testzip() is None
report=dict(overallStatus='failed-user-review',native=native,frames=frames,
    archive=dict(members=len(members),sha256=digest(dest/'validation.zip')))
(dest/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(report['archive'])
