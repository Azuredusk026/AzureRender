from hashlib import sha256
from pathlib import Path
import json

import numpy as np

out=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
trace=read(out/'trace-face-view-mask.json')
assert trace['status']=='qualified' and len(trace['points'])==12
buffers={}
for binding,record in trace['constants'].items():
    raw=(out/f'face-view-mask-cb{binding}.bin').read_bytes()
    assert len(raw)==record['bytes'] and sha256(raw).hexdigest()==record['sha256']
    buffers[int(binding)]=np.frombuffer(raw,'<f4').astype(float).reshape(-1,4)
assert buffers[1][26,0]==-1
low,high=buffers[6][12,1],buffers[6][12,0]
tint=buffers[6][13,:3]
rows=[]
clamp=lambda x:float(np.clip(x,0,1))
for row in trace['points']:
    r=row['registers']
    R=lambda step,name:np.asarray(r[str(step)][name],dtype=float)
    mask=R(70,'r11')
    head_xz=R(80,'r15')[[0,2]]
    geometry=clamp(head_xz[1]/np.linalg.norm(head_xz)+.5)
    view=R(9,'r2')[:3]
    normal=R(76,'r13')[:3]
    facing=clamp(normal@view)
    mask_influence=(geometry+(1-geometry)*mask[1])*mask[0]
    blue=low+(high-low)*mask[2]
    weight=clamp(.85*(1-facing)*mask_influence*blue)
    current=clamp(.85*(1-facing)*(.9989546717452598+(1-.9989546717452598)*mask[1])*mask[0])
    factors=1-weight+weight*tint
    actual_geometry=R(341,'r12')[0]
    actual_weight=R(351,'r8')[3]
    actual_factors=R(353,'r18')[:3]
    assert np.max(np.abs(R(354,'r20')[:3]-R(339,'r5')[1:]*actual_factors))<4e-6
    assert abs(geometry-actual_geometry)<4e-6
    assert abs(weight-actual_weight)<4e-6
    assert np.abs(factors-actual_factors).max()<4e-6
    rows.append(dict(point=row['sample']['point'],geometryWeight=geometry,blueScale=blue,nativeTintWeight=actual_weight,
         approximateWeightAtNativeMip=current,normalFacing=facing,mask=mask.tolist(),nativeFactor=actual_factors.tolist(),
         tintFactorReconstructionPeak=float(np.abs(factors-actual_factors).max())))
result=dict(status='source-attribution',nativeTint=tint.tolist(),blueScaleRange=[low,high],rows=rows)
(out/'face-view-mask-math.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
