from hashlib import sha256
from pathlib import Path
import json
import runpy

import numpy as np

out = Path(__file__).resolve().parent
grid = out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
player = out.parent/'20261114-031526-body-outline-native-stream-b1826a'
read = lambda path: json.loads(path.read_bytes())
source = grid/'native-body-outline-input-retest'
settings = read(grid/'static-nvidia-frames/capture_manifest.json')
points = np.fromfile(grid/'native-body-outline-depth/changed-native-pixels.bin','<u4').reshape(-1,6)
x, y = points[:,:2].T
assert len(points)==1184
old_depth, new_depth = (points[:,i].view('<f4').astype(float) for i in (2,3))
record = read(grid/'engine-body-outline-depth/results.json')['events']['940']
assert record['depth']['depthFunction']=='CompareFunction.Less'
path = grid/'engine-body-outline-depth'/record['before']['file']
host_depth = np.fromfile(path,'<f4').astype(float)
assert len(host_depth)==len(old_depth)

projection = np.fromfile(source/'outline-1018-cb0.bin','<f4').reshape(-1,4).astype(float)
outline = np.fromfile(source/'outline-1018-cb3.bin','<f4').reshape(-1,4).astype(float)
viewport = np.fromfile(source/'outline-1018-cb1.bin','<f4').reshape(-1,4).astype(float)[1,:2]
shell = np.fromfile(grid/'native-face-skin-stages/vertex-1018.bin','<f4').reshape(-1,23).astype(float)
body = np.fromfile(grid/'native-face-skin-stages/vertex-783.bin','<f4').reshape(-1,33).astype(float)
w = shell[:,3]
assert np.array_equal(w,body[:,3])
inverse_projection = 1/abs(projection[9,1])
square = inverse_projection**2
half_fov = inverse_projection*((.08729290217161179*square-.30189499258995056)*square+1)
projected_normal = shell[:,9:12]@projection[32:35,:2]
direction = projected_normal/np.linalg.norm(projected_normal,axis=1)[:,None] * [viewport[1]/viewport[0],1]
native_xy = direction*(.3926990330219269/half_fov)*outline[14,0] * np.clip(w*half_fov*4.583662509918213,0,1)[:,None]*.005
lower = np.minimum(w,1.5707961320877075/half_fov)[:,None]/viewport
native_xy = np.sign(native_xy)*np.maximum(np.abs(native_xy),lower)
pixel_error = np.abs(native_xy-(shell[:,:2]-body[:,:2]))/w[:,None]*viewport*.5
distance_offset = .1*outline[14,1]
native_z = projection[11,2]/(w+distance_offset)-projection[10,2]
depth_error = np.abs(native_z-shell[:,2]/w)
assert pixel_error.max()<.0001 and depth_error.max()<1e-8

near, far = (settings['cameraLens'][k] for k in ('nearPlane','farPlane'))
to_host_depth = lambda depth: far/(far-near)*(1-near*(depth+projection[10,2])/projection[11,2])
converted_old = to_host_depth(old_depth)
converted_shell = to_host_depth(new_depth)
native_test = converted_old>converted_shell
host_test = host_depth>converted_shell
assert native_test.all() and int(host_test.sum())==1170

scorer = runpy.run_path(str(grid/'static-quality.py'))
image = lambda path: scorer['image'](path).astype(np.int16)
reference = image(scorer['reference_path'])
receipt = dict(status='depth-source-qualified',overallStatus='failed-user-review',nativePositions=len(points),
               originalOutlineDepthSha256=sha256(path.read_bytes()).hexdigest(),
               authoredProjectionMaximumPixelError=float(pixel_error.max()),
               authoredDepthMaximumError=float(depth_error.max()),
               nativeTestPassed=int(native_test.sum()),playerDepthTestWithNativeShell=int(host_test.sum()),
               closePlayerDepthBefore=int((np.abs(host_depth-converted_old)<1e-6).sum()),
               hostOcclusionPositions=np.column_stack((x[~host_test],y[~host_test])).tolist(),devices={})
for device in ('nvidia','intel'):
    before = image(grid/f'cloth-production-color-adjustment-retest/{device}-static-baseline/frames/frame_000000.png')
    candidate = image(player/f'{device}-authored/frames/frame_000000.png')
    marker = image(player/f'{device}-smooth/frames/frame_000000.png')
    mask = (marker[:,:,1]>245)&(marker[:,:,0]<60)&(marker[:,:,2]<60)
    marker_delta = np.abs(marker-before).max(2)>1
    marker_at_native = marker_delta[y,x]
    changed = np.any(candidate!=before,axis=2)
    old = np.abs(before-reference).max(2)
    new = np.abs(candidate-reference).max(2)
    receipt['devices'][device] = dict(markerMatches=int(mask[y,x].sum()),
        markerMatchesPlayerDepthHypothesis=int((mask[y,x]&host_test).sum()),
        visibleMarkerChangesAtNativePositions=int(marker_at_native.sum()),
        visibleMarkerChangesPassingPlayerDepth=int((marker_at_native&host_test).sum()),
        visibleMarkerChangesOutsideNative=int(marker_delta.sum()-marker_at_native.sum()),
        visibleMarkerChangesAtFailedDepth=np.column_stack((x[marker_at_native&~host_test],y[marker_at_native&~host_test])).tolist(),
        changedAtNativePositions=int(changed[y,x].sum()),changedOutsideNative=int(changed.sum()-changed[y,x].sum()),
        improvedAtNativePositions=int((new[y,x]<old[y,x]).sum()),
        nativePositionsOverEight=[int((field[y,x]>8).sum()) for field in (old,new)])
    assert marker_at_native.sum()==1171 and (marker_at_native&host_test).sum()==1170
(out/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
