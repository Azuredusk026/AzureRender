from pathlib import Path
import json, math
import numpy as np

run=Path(__file__).resolve().parent
folder=run/'face-material-sampling-replay'
report=json.loads((folder/'results.json').read_bytes())
assert report['status']=='qualified'
event,=[row for row in report['events'] if row['event']==876]
names=('uv','albedo','albedo-lod','mask','sdf','ramp','ramp-coord','shadow-lut','diffuse','rim')
assert event['selection']['baseline']==event['selection']['copy']==event['selection']['restored']
vectors={n:np.fromfile(folder/f'876-mip{n}-direct.bin','<f2').reshape(-1,4).astype(float) for n in names}
points=np.fromfile(run/'face-residual-points.bin','<u4').reshape(-1,2)
native=json.loads((run/'native-face-skin-stages/results.json').read_bytes())['history']['face']
geometry=json.loads((run/'face-native-uv-at-residuals.json').read_bytes())['rows']
assert all(len(v)==len(points)==10 for v in vectors.values())
rows=[]
for i,(x,y) in enumerate(points):
    src=next(p for p in native if (p['x'],p['y'])==(x,y))
    g=next(r for r in geometry if (r['x'],r['y'])==(x,y))
    primitive=next(p for p in g['covered'] if p['primitive']==src['primitive'])
    uv=np.array(primitive['nativeUv'])
    predicted_uv=[uv[0],1-uv[1]]
    row=dict(x=int(x),y=int(y),primitive=src['primitive'],nativeUv=uv.tolist(),
        player={name:vectors[name][i,:3].tolist() for name in names})
    row['player']['albedo-lod']=[value*8 for value in row['player']['albedo-lod']]
    row['uvResidual']=np.abs(vectors['uv'][i,:2]-predicted_uv).tolist()
    trace=run/'native-face-cloth-full-trace'/f'804-{x}-{y}.json'
    if trace.exists():
        t=json.loads(trace.read_bytes())
        r=t['33']['r5']
        row['nativeSamples']=dict(albedo=[*r[1:],r[0]],mask=t['70']['r11'],shadowLut=t['69']['r10'][:3])
    rows.append(row)
print(json.dumps([r for r in rows if 'nativeSamples' in r],indent=2))
(folder/'comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
