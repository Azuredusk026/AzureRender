from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json,re,argparse

parser=argparse.ArgumentParser(description='Restore historical public visual diagnostic shaders into a new staging directory.')
parser.add_argument('--staging',type=Path,required=True)
a=parser.parse_args()
archive=Path(__file__).resolve().with_suffix('.zip')
archive=archive.with_name(archive.name.replace('-restore.zip','.zip'))
expect='7697a93c182185b9c0d38bd3ae54972bbddde785ebed0f87610da431b03d77af'
assert sha256(archive.read_bytes()).hexdigest()==expect
from pathlib import PurePosixPath
expected_staging=(archive.parent.parent/'maintenance'/'public-shader-recovery').resolve()
staging=a.staging.absolute()
assert '..' not in staging.parts and staging.resolve()==staging and expected_staging in staging.parents and not staging.exists()
for parent in (staging,*staging.parents):
 if parent.exists():
  assert not parent.is_symlink() and not (getattr(parent.lstat(),'st_file_attributes',0)&1024)
allowed=tuple(PurePosixPath(v) for v in ('main-background-control/control/shaders','main-background-control/screen-space/shaders','frozen-pipeline-controls/backdrop/shaders','frozen-pipeline-controls/both/shaders','frozen-pipeline-controls/transfer/shaders'))
with ZipFile(archive) as z:
 raw=z.read('inventory.json');assert sha256(raw).hexdigest()=='06f37e39a05d6d803292ad33632cb67cbccd3f8320dcbeb7642935d709845b24'
 index=json.loads(raw); result={}
 assert len(index['sha256'])==897 and len(z.namelist())==898
 for sha,row in index['sha256'].items():
  assert re.fullmatch('[a-f0-9]{64}',sha)
  blob=z.read('shader/'+sha+'.spv'); assert len(blob)==row['bytes'] and sha256(blob).hexdigest()==sha
  for rel in row['files']:
   p=PurePosixPath(rel)
   assert not p.is_absolute() and str(p)==rel and '..' not in p.parts and p.suffix=='.spv' and ':' not in rel and '\\' not in rel
   assert any(k in p.parents for k in allowed)
   dst=staging.joinpath(*p.parts);assert staging in dst.resolve().parents and dst not in result
   dst.parent.mkdir(parents=True,exist_ok=True)
   with dst.open('xb') as out:out.write(blob)
   result[dst]=sha
assert len(result)==4483 and all(sha256(p.read_bytes()).hexdigest()==s for p,s in result.items())
print('Restored and verified',len(result),'files at',staging)
