from pathlib import Path
from hashlib import sha256
import json

import numpy as np

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
points=np.fromfile(grid/'native-iris-stages/points.bin','<u4').reshape(255,2)
read=lambda p:json.loads(p.read_bytes())


def native(path):
    words=np.fromfile(path,'<u4')
    assert len(words)==255
    channels=[]
    for shift,bits in ((0,6),(11,6),(22,5)):
        v=(words>>shift)&((1<<(bits+5))-1)
        power=(v>>bits).astype(int);m=v&((1<<bits)-1)
        channels.append(np.where(power==0,np.ldexp(m.astype(float),-14-bits),np.ldexp(1+m/(1<<bits),power-15))*.25)
    return np.column_stack(channels)


def display(linear):
    linear=np.clip(linear,0,1)
    return np.rint(np.where(linear<=.0031308,12.92*linear,1.055*linear**(1/2.4)-.055)*255).astype(np.int16)


def vulkan(directory,label):
    folder=grid/directory
    receipt=read(folder/'results.json')
    assert receipt['status']=='qualified'
    event,=[x for x in receipt['events'] if x.get('selection')]
    assert event['event']==897 and event['selection']['baseline']==event['selection']['copy']==event['selection']['restored']
    raw=(folder/f'897-{label}-direct.bin').read_bytes()
    assert sha256(raw).hexdigest()==event['selection'][label]['selectedSha256']['direct']
    return np.frombuffer(raw,'<f2').reshape(255,4).astype(float)


original=native(grid/'native-iris-stages/event-846.bin')
before,after=[native(grid/f'native-iris-stages/event-{e}.bin') for e in (1230,1245)]
bare=~(before!=after).any(1)
assert bare.sum()==161
old=vulkan('engine-iris-lod-bias','baseline')[:,:3]
lod=vulkan('engine-iris-lod-bias','miplod')[:,:2]
native_receipt=read(grid/'iris-explicit-mips/iris-explicit-mips.json')['devices']['nvidia']
native_mip_paths=[grid/f'iris-explicit-mips/nvidia-mip-{i:02d}.bin' for i in range(10)]
for i,p in enumerate(native_mip_paths):
    assert sha256(p.read_bytes()).hexdigest()==native_receipt['mips'][str(i)]['sha256']
native_levels=np.stack([native(path) for path in native_mip_paths])
match=(native_levels==original).all(2)
assert match.any(0).all()
known=match.sum(0)==1
engine_levels={i:vulkan('engine-iris-lod-bias',f'mip{i}')[:,:3] if i in (5,6) else
                 vulkan('engine-iris-explicit-mips',f'mip{i}')[:,:3] for i in (4,5,6)}
assert np.array_equal(engine_levels[5],vulkan('engine-iris-explicit-mips','mip5')[:,:3])


def stats(candidate,mask=bare):
    error=np.abs(display(candidate)-display(original)).max(1)[mask]
    return dict(pixels=int(mask.sum()),overOne=int((error>1).sum()),overEight=int((error>8).sum()),
                maximum=int(error.max()),mean=float(error.mean()))


def compare_alignment(offset):
    chosen=np.argmax(match,axis=0)+offset
    can=known&np.isin(chosen,list(engine_levels))
    result=old.copy()
    for level,v in engine_levels.items():
        select=can&(chosen==level)
        result[select]=v[select]
    return result,can


report=dict(status='diagnostic',baseline=stats(old),offsets={},nearLevelBoundary=[])
report['inputs']={name:sha256((grid/name).read_bytes()).hexdigest() for name in (
    'native-iris-stages/points.bin','native-iris-stages/event-846.bin','native-iris-stages/event-1230.bin',
    'native-iris-stages/event-1245.bin','iris-explicit-mips/iris-explicit-mips.json',
    'engine-iris-lod-bias/results.json','engine-iris-lod-boundary/results.json','engine-iris-explicit-mips/results.json')}
for offset in (-1,0,1,2):
    result,can=compare_alignment(offset)
    report['offsets'][offset]=dict(result=stats(result),aligned=stats(result,can&bare),
                                  sameBaselineScope=stats(old,can&bare))
for bias in (-.01,.01,.02):
    candidate=vulkan('engine-iris-lod-boundary',f'mip{bias}')[:,:3]
    for i in np.where((candidate!=old).any(1))[0]:
        expected=display(original)[i]
        report['nearLevelBoundary'].append(dict(bias=bias,point=points[i].tolist(),coveredByOverlay=bool(not bare[i]),
            reportedLod=lod[i].tolist(),nativeLevels=np.where(match[:,i])[0].tolist(),
            baseline=display(old)[i].tolist(),candidate=display(candidate)[i].tolist(),reference=expected.tolist(),
            maxByteError=[int(np.abs(display(a)[i]-expected).max()) for a in (old,candidate)]))
assert report['baseline']['overOne']==37 and report['offsets'][1]['result']['overOne']==36
assert any(row['point']==[1261,261] and row['maxByteError']==[12,1] for row in report['nearLevelBoundary'])
assert any(row['point']==[1261,260] and row['maxByteError']==[1,12] for row in report['nearLevelBoundary'])
(out/'iris-mipmap-attribution.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
