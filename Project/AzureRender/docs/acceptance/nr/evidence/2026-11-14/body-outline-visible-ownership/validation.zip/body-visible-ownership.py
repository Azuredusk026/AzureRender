from hashlib import sha256
from pathlib import Path
import gzip
import json
import runpy

import numpy as np

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
task=out.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
radial=out.parent/'20261114-051632-face-local-radial-light-retest-ea8fb6'
capture=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/post-opaque-ownership')
read=lambda path:json.loads(path.read_bytes())
source=runpy.run_path(str(grid/'static-quality.py'))
base=source['image'](source['reference_path']).astype(np.int16)
depth=grid/'native-body-outline-depth'
coverage=[np.fromfile(depth/f'depth-{i}.bin','<u4').reshape(1440,2560,2)[::-1,:,0] for i in (1017,1018)]
mask=coverage[0]!=coverage[1]
y,x=np.where(mask)
assert len(x)==1184
reference=base[y,x]
events={}
last=np.full(1184,1018,dtype=np.int16)
values={}
for row in read(capture/'manifest.json')['events']:
    event=row['event']
    if event<1018:continue
    events[event]=[]
    binary=[]
    for path in row['files']:
        data=gzip.decompress((capture/path).read_bytes())
        assert len(data)==2560*1440*4
        binary.append(np.frombuffer(data,'<u4').reshape(1440,2560)[::-1][y,x])
        events[event].append(dict(path=path,sha256=sha256(data).hexdigest()))
    values[event]=binary
    hits=binary[0]!=binary[1]
    assert len(hits)==1184
    last[hits]=event
    events[event]=dict(changed=int(hits.sum()),sources=events[event])
before_after=values[1018]
assert int((before_after[0]!=before_after[1]).sum())>1100
point_payload=np.column_stack((x,y,last)).astype('<u2').tobytes()
(out/'body-visible-ownership-points.bin').write_bytes(point_payload)


def frame(path):return source['image'](path).astype(np.int16)[y,x]


report=dict(status='source-attribution',outlineCoverage=1184,events=events,byLastDraw={},devices={},
            pointOwnership=dict(encoding='uint16 little-endian: x, y, last event',
                                sha256=sha256(point_payload).hexdigest()))
for e in sorted(np.unique(last)):
    selection=last==e
    report['byLastDraw'][int(e)]=int(selection.sum())
for device in ('nvidia','intel'):
    control=frame(radial/f'production-{device}-enabled/frames/frame_000000.png')
    items={'ordered-lit':task/f'{device}/frames/frame_000000.png',
           'lit':out.parent/'20261114-044912-body-outline-lit-surface-fba9d7'/f'{device}/frames/frame_000000.png',
           'late-depth':task/f'body-blend-{device}/frames/frame_000000.png',
           'exact-shell':task/f'body-exact-{device}/frames/frame_000000.png'}
    per_case={}
    for name,path in items.items():
        if not path.is_file():continue
        candidate=frame(path)
        diff=np.abs(candidate-reference).max(1)
        change=np.abs(candidate-control).max(1)>0
        per_case[name]={int(e):dict(changed=int(change[last==e].sum()),overOne=int((diff[last==e]>1).sum()),
                                  overEight=int((diff[last==e]>8).sum()),peak=int(diff[last==e].max())) for e in np.unique(last)}
        per_case[name]['frameSha256']=sha256(path.read_bytes()).hexdigest()
    report['devices'][device]=per_case
(out/'body-visible-ownership.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(owners=report['byLastDraw'],devices=report['devices'])))
