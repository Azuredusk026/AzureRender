from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import collections
import json
import struct

out = Path(__file__).resolve().parent
report_path = out / 'body-visible-ownership.json'
points = out / 'body-visible-ownership-points.bin'
report = json.loads(report_path.read_bytes())
rows = tuple(struct.iter_unpack('<HHH', points.read_bytes()))
assert len(rows) == len({(x, y) for x, y, e in rows}) == report['outlineCoverage'] == 1184
assert sha256(points.read_bytes()).hexdigest() == report['pointOwnership']['sha256']
assert all(x < 2560 and y < 1440 for x, y, e in rows)
counts = collections.Counter(e for x, y, e in rows)
assert dict(counts) == {int(k): v for k, v in report['byLastDraw'].items()}
assert counts[1018] == 1112 and sum(n for k, n in counts.items() if k != 1018) == 72
for device in ('nvidia', 'intel'):
    tests = report['devices'][device]['lit']
    assert (tests['1018']['changed'], tests['1018']['overEight'], tests['1018']['peak']) == (513, 721, 148)
    assert tests['1383']['changed'] == 56
report['overallStatus'] = 'failed-user-review'
folder = out.parents[2] / 'docs/acceptance/nr/evidence/2026-11-14/body-outline-visible-ownership'
folder.mkdir(parents=True, exist_ok=False)
members = ['body-visible-ownership.py', points.name, Path(__file__).name]
zipped = folder / 'validation.zip'
with ZipFile(zipped, 'x', ZIP_DEFLATED) as archive:
    for name in members:
        archive.write(out / name, name)
with ZipFile(zipped) as archive:
    assert archive.namelist() == members and archive.testzip() is None
report['archive'] = dict(sha256=sha256(zipped.read_bytes()).hexdigest(), members=len(members))
(folder / 'results.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf8')
print(json.dumps(dict(ownership=counts, archive=report['archive'])))

