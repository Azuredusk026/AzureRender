from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
from hashlib import sha256
import gzip
import json
import sys

import numpy as np
from PIL import Image

root = Path(__file__).resolve().parent
build = root.parents[1]
grid = root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
local = root.parent/'20261114-051632-face-local-radial-light-retest-ea8fb6'
stage = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c')
post = stage/'post-opaque-ownership'
read = lambda path:json.loads(path.read_bytes())
digest = lambda path:sha256(path.read_bytes()).hexdigest()
image = lambda path:np.asarray(Image.open(path).convert('RGB')).astype(np.int16)
mask_path = grid/'native-face-masks/face.png'
mask = np.asarray(Image.open(mask_path).convert('L'))>0
pixels = int(mask.sum())
assert pixels==3663 and digest(mask_path)==read(grid/'native-face-masks/result.json')['masks']['face']['sha256']
reference_path = stage/'snapshot-shell-cloth-reference.png'
ref = image(reference_path)
y,x = np.where(mask)
latest = np.zeros(pixels,np.uint16)
changed = {}
for row in read(post/'manifest.json')['events']:
    event = row['event']
    inputs = [np.frombuffer(gzip.decompress((post/name).read_bytes()),'<u4').reshape(1440,2560)[::-1][y,x]
              for name in row['files']]
    touched = inputs[0]!=inputs[1]
    latest[touched] = event
    if touched.any():
        changed[str(event)] = dict(indices=row['indices'],pixels=int(touched.sum()),
                                  attachment=row['target'],sha256=[digest(post/name) for name in row['files']])
result = dict(overallStatus='failed-user-review',faceMask= digest(mask_path),facePixels=pixels,
              reference=digest(reference_path),nativeWrites=changed,devices={})
for device in ('nvidia','intel'):
    frame = local/f'production-{device}-enabled/frames/frame_000000.png'
    delta = np.abs(image(frame)-ref).max(2)[y,x]
    row = result['devices'][device] = dict(frame=digest(frame),byLatestEvent={})
    for event in sorted(set(latest)):
        selected = latest==event
        d = delta[selected]
        row['byLatestEvent'][str(event)] = dict(pixels=int(selected.sum()),overOne=int((d>1).sum()),
                                            overEight=int((d>8).sum()),peak=int(d.max()))
    position = int(np.argmax(delta))
    row.update(peak=int(delta[position]),peakEvent=int(latest[position]),
               peakPosition=[int(x[position]),int(y[position])])
    assert row['peakPosition']==[1315,258] and row['peakEvent']==1230
    assert row['byLatestEvent']['1230']['overEight']==41 and row['byLatestEvent']['1358']['overEight']==264
out = root
if '--publish' in sys.argv:
    out = build.parent/'docs/acceptance/nr/evidence/2026-11-14/face-late-overlay-ownership'
    out.mkdir(parents=True,exist_ok=True)
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
if '--publish' in sys.argv:
    with ZipFile(out/'validation.zip','w',compression=ZIP_DEFLATED) as archive:
        archive.write(Path(__file__),'compare.py')
        archive.write(post/'manifest.json','stage-manifest.json')
        archive.write(out/'results.json','results.json')
    with ZipFile(out/'validation.zip') as archive:
        assert archive.testzip() is None
