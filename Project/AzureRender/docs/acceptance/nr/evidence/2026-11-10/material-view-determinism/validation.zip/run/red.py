from pathlib import Path
import subprocess,os,sys,json,time
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside',*sys.argv[1:]]).returncode)
with (out/'red-build.log').open('wb') as log:subprocess.run(['cmake','--build','build/ninja-msvc-release','--target','AzureMaterialViewDeterminismGpuTests','-j','3'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
os.environ['PATH']=str(root/'build/ninja-msvc-release')+';'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin')+';'+os.environ['PATH'];os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*'
with (out/'red-intel.log').open('wb') as log:p=subprocess.run([str(root/'build/ninja-msvc-release/AzureMaterialViewDeterminismGpuTests.exe'),str(root/'build/ninja-msvc-release/shaders'),str(out/'red-intel')],stdout=log,stderr=subprocess.STDOUT,timeout=180)
(out/'red-execution.json').write_text(json.dumps(dict(returncode=p.returncode),indent=2));assert p.returncode!=0,'The original independent-view failure must be reproduced before trying a fix';failure=json.loads((out/'red-intel/failure.json').read_text());assert 'Intel' in failure['device'];print(json.dumps(failure))
