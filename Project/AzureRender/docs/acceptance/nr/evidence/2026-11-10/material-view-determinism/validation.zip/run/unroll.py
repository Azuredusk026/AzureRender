from pathlib import Path
import subprocess,os,sys,json,hashlib,concurrent.futures,time
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));build=root/'build/ninja-msvc-release';manifest=json.loads((build/'shader-reload.json').read_text());private=out/'unrolled-shaders';private.mkdir();sourceDir=out/'unrolled-source';sourceDir.mkdir()
programs=manifest['programs'];assert len({p['output'] for p in programs})==len(programs)
before={p['output']:hashlib.sha256((build/'shaders'/p['output']).read_bytes()).hexdigest() for p in programs}
for p in programs:os.link(build/'shaders'/p['output'],private/p['output'])
source=(root/'shaders/mesh.frag').read_text();entry=source.index('void prepareShadowReceiver() {');start=source.index('    for(int i=0;i<4;++i){',entry);end=source.index('\n    }\n}',start)+len('\n    }');loop=source[start:end];body=loop[len('    for(int i=0;i<4;++i){'):-len('\n    }')]
expanded='\n'.join('    {const int i='+str(i)+';'+body+'\n    }' for i in range(4));candidate=source[:start]+expanded+source[end:];assert candidate.count('void prepareShadowReceiver()')==1
(sourceDir/'mesh.frag').write_text(candidate);(out/'receiver-unroll.patch').write_text(''.join(__import__('difflib').unified_diff(source.splitlines(True),candidate.splitlines(True),fromfile='shaders/mesh.frag',tofile='private/mesh.frag')))
selected=[p for p in programs if p['source']=='mesh.frag'];commands=[];startTime=time.monotonic()
def compileOne(p):
 destination=private/p['output'];destination.unlink();command=[manifest['compiler'],*p['arguments'],*['-D'+d for d in p['defines']],'-I'+str(root/'shaders'),str(sourceDir/'mesh.frag'),'-o',str(destination)]
 value=subprocess.run(command,capture_output=True,text=True,timeout=30);record=dict(output=p['output'],command=command,returncode=value.returncode,stdout=value.stdout,stderr=value.stderr)
 if value.returncode==0:
  validation=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe',str(destination)],capture_output=True,text=True,timeout=15);record['validation']=dict(returncode=validation.returncode,stdout=validation.stdout,stderr=validation.stderr)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for r in pool.map(compileOne,selected):commands.append(r)
(out/'unroll-build.json').write_text(json.dumps(dict(programs=len(selected),seconds=time.monotonic()-startTime,commands=commands),indent=2));assert all(r['returncode']==0 and r['validation']['returncode']==0 for r in commands)
assert all(hashlib.sha256((build/'shaders'/name).read_bytes()).hexdigest()==sha for name,sha in before.items());(out/'original-programs.json').write_text(json.dumps(before,indent=2))
os.environ['PATH']=str(build)+';'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin')+';'+os.environ['PATH'];executions=[]
for device,driver in [('intel','*igvk64*'),('nvidia','*nv-vk64*')]:
 os.environ['VK_LOADER_DRIVERS_SELECT']=driver
 with (out/('unroll-'+device+'.log')).open('wb') as log:p=subprocess.run([str(build/'AzureMaterialViewDeterminismGpuTests.exe'),str(private),str(out/('unroll-'+device))],stdout=log,stderr=subprocess.STDOUT,timeout=180)
 executions.append(dict(device=device,returncode=p.returncode));(out/'unroll-execution.json').write_text(json.dumps(executions,indent=2))
 if p.returncode:raise SystemExit(p.returncode)
print(json.dumps(dict(status='passed',programs=len(selected),executions=executions)))
