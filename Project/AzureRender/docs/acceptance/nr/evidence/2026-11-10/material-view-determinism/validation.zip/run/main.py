from pathlib import Path
import subprocess,os,sys,json,hashlib,xml.etree.ElementTree as ET
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from artifact_maintenance import managed_environment;from build_provenance import verify,inputs
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside',*sys.argv[1:]]).returncode)
assert len(json.loads((out/'matrix-execution.json').read_text()))==3 and all(x['returncode']==0 for x in json.loads((out/'matrix-execution.json').read_text()))
assert (root/'shaders/mesh.frag').read_bytes()==(out/'original-mesh.frag').read_bytes()
with (out/'final-red-build.log').open('wb') as log:subprocess.run(['cmake','--build','build/ninja-msvc-release','--target','AzureMaterialViewDeterminismGpuTests','-j','3'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
os.environ['PATH']=str(root/'build/ninja-msvc-release')+';'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin')+';'+os.environ['PATH'];os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*'
with (out/'final-red-intel.log').open('wb') as log:p=subprocess.run([str(root/'build/ninja-msvc-release/AzureMaterialViewDeterminismGpuTests.exe'),str(out/'frozen-original-shaders'),str(out/'final-red-intel'),'--legacy-only'],stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert p.returncode!=0 and (out/'final-red-intel/failure.json').exists(),'Final regression must reject the original program identity failure'
(out/'final-regression.cpp').write_bytes((root/'tests/MaterialViewDeterminismGpuTests.cpp').read_bytes())
(root/'shaders/mesh.frag').write_bytes((out/'unrolled-source/mesh.frag').read_bytes());source=inputs(root)
targets=['AzureMaterialViewDeterminismGpuTests','AzureTemporalViewGpuTests','AzureMaterialDisplayViewGpuTests','AzureShadowFilteringGpuTests','AzureObjectShadowFilteringGpuTests','AzureShadowTileBoundsGpuTests','AzureShaderCompilerContractTests','AzureHotReloadTests']
selector=r'^(AzureRender\.(ShaderCompilerContract|ShaderCatalogCompilation|HotReload|ShadowFilteringGpu|ObjectShadowFilteringGpu|ShadowTileBoundsGpu)|AzureEngine\.(ModuleBoundaries|ModuleBoundaryFixtures))$'
summary=[];gpu=[]
for config in ['Release','Debug']:
 build=root/('build/ninja-msvc-'+config.lower());command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
 for target in targets:command+=['--test-target',target]
 with (out/(config.lower()+'-main-build.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 receipt=json.loads((build/'build-provenance.json').read_text());verify(root,receipt);(out/(config.lower()+'-provenance.json')).write_text(json.dumps(receipt,indent=2))
 manifest=json.loads((build/'shader-reload.json').read_text());assert len(manifest['programs'])==687
 for p in manifest['programs']:
  assert hashlib.sha256((build/'shaders'/p['output']).read_bytes()).digest()==hashlib.sha256((out/'unrolled-shaders'/p['output']).read_bytes()).digest(),(config,p['output'])
 os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['PATH']=str(build)+';'+str(root/'build/ninja-msvc-debug/vcpkg_installed/x64-windows'/('debug/bin' if config=='Debug' else 'bin'))+';'+os.environ['PATH']
 command=['ctest','--test-dir',str(build),'-C',config,'--output-on-failure','--no-tests=error','-R',selector,'--output-junit',str(out/(config.lower()+'-main-tests.xml'))]
 with (out/(config.lower()+'-main-tests.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=360)
 cases=ET.parse(out/(config.lower()+'-main-tests.xml')).findall('.//testcase');assert len(cases)==8 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
 summary.append(dict(configuration=config,ctests=len(cases),shaderIdentities=687));print(json.dumps(summary[-1]),flush=True)
 for device,driver in [('intel','*igvk64*'),('nvidia','*nv-vk64*')]:
  os.environ['VK_LOADER_DRIVERS_SELECT']=driver
  for target,label in [('AzureMaterialViewDeterminismGpuTests','determinism'),('AzureMaterialViewDeterminismGpuTests','legacy'),('AzureTemporalViewGpuTests','temporal'),('AzureMaterialDisplayViewGpuTests','display')]:
   destination=out/(config.lower()+'-'+device+'-'+label);command=[str(build/(target+'.exe')),str(build/'shaders'),str(destination)]
   if label=='legacy':command.append('--legacy-only')
   with (out/(destination.name+'.log')).open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=180)
   text=(out/(destination.name+'.log')).read_text(errors='replace');row=dict(configuration=config,device=device,target=target,returncode=p.returncode,validationClean=not any(t in text for t in ['Validation Error:','Validation Warning:','SYNC-HAZARD','VUID-']))
   gpu.append(row);(out/'main-gpu-execution.json').write_text(json.dumps(gpu,indent=2));assert p.returncode==0 and row['validationClean'],row
   if label=='legacy':assert json.loads((destination/'results.json').read_text())['pixelsCompared']==33280
   if label=='determinism':assert json.loads((destination/'results.json').read_text())['pixelsCompared']==199680
   print(json.dumps(row),flush=True)
 verify(root,receipt)
assert inputs(root)==source
(out/'main-results.json').write_text(json.dumps(dict(builds=summary,gpu=gpu,sourceUnchanged=True),indent=2))
print('Main two-configuration regression passed',flush=True)
