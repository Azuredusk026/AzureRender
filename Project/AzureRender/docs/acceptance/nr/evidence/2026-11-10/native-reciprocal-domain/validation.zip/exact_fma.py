from pathlib import Path
import json
import numpy as np
out=Path(__file__).resolve().parent
def decode(bits):
    exponent=(bits>>23)&255;mantissa=bits&0x7fffff
    assert exponent!=255
    return ((-1 if bits>>31 else 1)*(mantissa if exponent==0 else (1<<23)|mantissa),
            -149 if exponent==0 else exponent-150)
def rounded(value,shift):
    if shift<=0:return value<<(-shift)
    q,r=divmod(value,1<<shift);half=1<<(shift-1)
    return q+(r>half or (r==half and q&1))
def fma(a,b,c):
    a,ea=decode(int(a));b,eb=decode(int(b));c,ec=decode(int(c))
    exponent=min(ea+eb,ec)
    value=(a*b<<(ea+eb-exponent))+(c<<(ec-exponent))
    if value==0:return 0
    sign=0x80000000 if value<0 else 0;value=abs(value)
    power=exponent+value.bit_length()-1
    if power < -126:return sign|rounded(value,-149-exponent)
    significand=rounded(value,value.bit_length()-24)
    if significand==1<<24:significand>>=1;power+=1
    assert power<=127
    return sign|((power+127)<<23)|(significand&0x7fffff)
prior=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261109-181501-native-producer-gpu-intermediates-de1e3d')
queries=np.fromfile(prior/'receiver-queries.bin',dtype='<u4').reshape(-1,3,4)
native=np.fromfile(prior/'native-homogeneous.bin',dtype='<u4').reshape(-1,4)[:,0]
intel=np.fromfile(out.parent/'20261109-220249-intel-receiver-combination-00550a/intel-precise-homogeneous.bin',dtype='<u4').reshape(-1,4)[:,0]
actual=np.empty(49384,dtype='<u4')
for i,(x,y,depth,_) in enumerate(queries[:,0]):
    cx=fma(fma(x,969723085,0),0x40000000,0xbf800000)
    cy=fma(fma(y,976620385,0),0x40000000,0xbf800000)
    h=fma(cy^0x80000000,2887152347,0)
    h=fma(cx,3205463799,h)
    h=fma(depth,3309010823,h)
    actual[i]=fma(h,0x3f800000,3169993671)
actual.tofile(out/'cpu-homogeneous-x.u32')
filtered=np.fromfile(out/'intel-lookup-filter.bin',dtype='<f4').reshape(-1,4)
expected=np.fromfile(prior/'expected.u8',dtype='u1')
failure=np.where(abs(np.rint(filtered[:,2]*255).astype('i4')-expected)>1)[0]
pixels=np.fromfile(prior/'pixels.bin',dtype='<u4').reshape(-1,2)
result=dict(exactNative=int((actual==native).sum()),exactIntel=int((actual==intel).sum()),samples=len(actual),
    failures=[dict(index=int(i),pixel=[int(pixels[i,0]),1439-int(pixels[i,1])],cpuBits=int(actual[i]),nativeBits=int(native[i]),intelBits=int(intel[i])) for i in failure])
(out/'exact-fma-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
