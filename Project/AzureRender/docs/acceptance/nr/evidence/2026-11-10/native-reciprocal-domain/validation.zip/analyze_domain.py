from pathlib import Path
import json,hashlib
import numpy as np
out=Path(__file__).resolve().parent
state=json.loads((out/'domain-state.json').read_text())
assert state['status']=='qualified' and state['baselineRestored'] and len(state['runs'])==12
assert all(row['qualified'] for row in state['runs'])
bits=np.zeros(1<<23,dtype='<u4')
for row in state['runs']:
    values=np.fromfile(out/f'phase-{row["phase"]}-byte-{row["byte"]}.u8',dtype='u1').astype('<u4')
    assert len(values)==row['count']
    bits[row['offset']:row['offset']+row['count']] |= values<<(8*row['byte'])
native_bits=bits
native_values=native_bits.view('<f4')
valid=np.isfinite(native_values)&(native_values>=.49)&(native_values<=1.01)
bits=np.fromfile(out/'compute-rcp-domain.f32',dtype='<u4')
assert len(bits)==1<<23
values=bits.view('<f4')
assert values[0]==1 and np.isfinite(values).all() and np.all((values>=.49)&(values<=1.01))
coverage=dict(actualNativeDomainElements=int(valid.sum()),requestedDomainElements=1<<23,
    nativeComputeExactElements=int((native_bits[valid]==bits[valid]).sum()))
input_bits=np.arange(1<<23,dtype='<u4')|np.uint32(0x3f800000)
correct=(1.0/input_bits.view('<f4').astype('f8')).astype('<f4').view('<u4')
delta=bits.astype('i8')-correct.astype('i8')
unique,counts=np.unique(delta,return_counts=True)
assert np.max(abs(delta))<=2
hist={str(int(value)):int(count) for value,count in zip(unique,counts)}
if delta.min()>=-1 and delta.max()<=2:
    code=(delta+1).astype('u1').reshape(-1,4)
    packed=code[:,0]|(code[:,1]<<2)|(code[:,2]<<4)|(code[:,3]<<6)
    packed.tofile(out/'native-rcp-correction.2bit')
prior=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261109-181501-native-producer-gpu-intermediates-de1e3d')
def decode(name,count):
    result=np.zeros((49384,count),dtype='<u4')
    for component in range(count):
        for byte in range(4):result[:,component]|=np.fromfile(prior/f'{name}-{component}-{byte}.u8',dtype='u1').astype('<u4')<<(byte*8)
    return result.view('<f4')
h=np.column_stack([decode('homogeneous',3),decode('homogeneous-w',1)])
world=decode('world',3)
wbits=h[:,3].copy().view('<u4');exponent=((wbits>>23)&255).astype('i4')
assert np.all(h[:,3]>0) and np.all((exponent>0)&(exponent<255))
reciprocal=np.ldexp(values[wbits&0x7fffff],127-exponent).astype('<f4')
reconstructed=(h[:,:3]*reciprocal[:,None]).astype('<f4')
exact=np.all(reconstructed.view('<u4')==world.view('<u4'),axis=1)
report=dict(status='compute-domain-checked',domainElements=len(bits),nativeCoverage=coverage,allGreenPixelsPerVersion=state['width']*state['height'],
    versions=len(state['runs']),relativeToCorrectRoundedUlpHistogram=hist,
    nativeWorldReconstruction=dict(samples=len(exact),exactPixels=int(exact.sum()),maxAbsolutePerComponent=abs(reconstructed-world).max(axis=0).tolist()),
    tableSha256=hashlib.sha256((out/'compute-rcp-domain.f32').read_bytes()).hexdigest(),qualification=state,
    scope='Complete Vulkan compute reciprocal domain plus observed native draw coverage. Exponent scaling checked against qualified native world positions. No runtime implementation or full quality claim.')
(out/'domain-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='qualification'},indent=2))
