from pathlib import Path
import json,hashlib
out=Path(__file__).resolve().parent
main=Path('D:/Projects/FYP/Project/AzureRender')
prior=main/'build/runs/20261109-181501-native-producer-gpu-intermediates-de1e3d'
source=(prior/'collector.cpp').read_text()
source=source.replace('unsigned width=16,height=8;', 'unsigned groupSize=1;unsigned width=16,height=8;')
source=source.replace('width=fixture.at("width");height=fixture.at("height");',
    'groupSize=fixture.value("workgroupSize",1U);width=fixture.at("width");height=fixture.at("height");')
source=source.replace('if(raw.size()%(3*sizeof(Vec4)))','if(raw.size()%sizeof(Vec4))')
source=source.replace('expected.resize(queries.size()/3,Vec4{});','expected.resize(fixture.value("samples",queries.size()/3),Vec4{});')
source=source.replace('if(queries.size()!=expected.size()*3||expected.empty())',
    'if((queries.size()<expected.size()*3&&!fixture.value("repeatQueries",false))||expected.empty())')
source=source.replace('commands.dispatch(count,1,1);','commands.dispatch((count+groupSize-1)/groupSize,1,1);')
source=source.replace('test::VulkanComputeFixture host;auto& backend=*host.backend;',
    'test::VulkanComputeFixture host;std::cout<<"Device: "<<host.properties.deviceName<<"\\n";auto& backend=*host.backend;')
(out/'collector.cpp').write_text(source)
for name in ['compile-command.txt','link-command.txt']:
    (out/name).write_text((prior/name).read_text().replace(str(prior),str(out)))
first=out.parent/'20261109-220249-intel-receiver-combination-00550a'
(out/'object_shadow.glsl').write_text((first/'object_shadow.glsl').read_text())
(out/'native_receiver_precise.glsl').write_text((prior/'native_receiver_precise.glsl').read_text())
shader=(prior/'precise-filter.comp').read_text().replace('local_size_x=1','local_size_x=256')
shader=shader.replace('    uint i=gl_GlobalInvocationID.x;', '    uint i=gl_GlobalInvocationID.x;if(i>=2097163u)return;')
at=shader.rindex('    }else{')
shader=shader[:at]+'''    }else{
        uint base=(i-11u)*4u;
        uvec4 bits=uvec4(base,base+1u,base+2u,base+3u)|uvec4(0x3f800000u);
        outputData.results[i]=vec4(1.0)/uintBitsToFloat(bits);
    }
}
'''
(out/'domain.comp').write_text(shader)
(out/'synthetic-depth.d16').write_bytes(b'\xff\xff'*128)
(out/'synthetic-queries.bin').write_bytes(b'\0'*48)
(out/'domain-fixture.json').write_text(json.dumps(dict(width=16,height=8,
    forwardDepthPath=str(out/'synthetic-depth.d16'),queryPath=str(out/'synthetic-queries.bin'),
    samples=2097152,workgroupSize=256,repeatQueries=True),indent=2))
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [main/'build/ninja-msvc-release/AzureRenderCore.lib',main/'build/ninja-msvc-release/AzureFoundation.lib',main/'src/rhi/Rhi.hpp',main/'src/rhi/GpuAllocator.hpp']}
(out/'collector-inputs.json').write_text(json.dumps(hashes,indent=2))
print('Prepared complete normalized reciprocal compute domain and bounded dispatch')
