from pathlib import Path
import json
out=Path(__file__).resolve().parent
prior=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261109-181501-native-producer-gpu-intermediates-de1e3d')
query=(prior/'receiver-queries.bin').read_bytes();assert len(query)==49384*48
table=(out/'compute-rcp-domain.f32').read_bytes();assert len(table)==(1<<23)*4
(out/'lookup-queries.bin').write_bytes(query+table)
fixture=json.loads((prior/'coordinates-fixture.json').read_text())
fixture.update(queryPath=str(out/'lookup-queries.bin'),samples=49384,workgroupSize=1)
(out/'lookup-fixture.json').write_text(json.dumps(fixture,indent=2))
source=(prior/'native_receiver_precise.glsl').read_text()
needle='homogeneousPosition=world;world.xyz/=world.w;worldPosition=world.xyz;'
assert needle in source
replacement='''homogeneousPosition=world;
uint reciprocalBits=floatBitsToUint(world.w);
uint reciprocalIndex=reciprocalBits&0x7fffffu;
precise float reciprocalNormalized=queries.values[148152u+(reciprocalIndex>>2u)][int(reciprocalIndex&3u)];
precise float reciprocal=ldexp(reciprocalNormalized,127-int((reciprocalBits>>23u)&255u));
world.xyz*=reciprocal;worldPosition=world.xyz;'''
(out/'native_receiver_lookup.glsl').write_text(source.replace(needle,replacement))
shader=(prior/'precise-filter.comp').read_text().replace('native_receiver_precise.glsl','native_receiver_lookup.glsl')
(out/'lookup-filter.comp').write_text(shader)
needle='outputData.results[i]=vec4(filtered,objectShadowUnorm8(filtered.x),clear.x);'
assert needle in shader
(out/'lookup-world.comp').write_text(shader.replace(needle,'outputData.results[i]=vec4(measuredWorld,1.0);'))
print('Prepared normalized reciprocal reference lookup in the diagnostic query buffer')
