from pathlib import Path
import sys,json,traceback,hashlib,time
import renderdoc as rd
out=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261109-234658-native-reciprocal-domain-2562a0')
main=Path('D:/Projects/FYP/Project/AzureRender');sys.path.insert(0,str(out))
from domain_probe import instrument
cap=c=None;shader=replacement=None
report=dict(status='starting',domainElements=1<<23,runs=[])
def save():(out/'domain-state.json').write_text(json.dumps(report,indent=2)+'\n')
try:
    cap=rd.OpenCaptureFile()
    path=main/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc'
    assert cap.OpenFile(str(path),'',None)==rd.ResultCode.Succeeded
    status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
    c.SetFrameEvent(699,True);pipe=c.GetPipelineState();shader=pipe.GetShader(rd.ShaderStage.Pixel)
    raw=bytes(pipe.GetShaderReflection(rd.ShaderStage.Pixel).rawBytes)
    (out/'original-producer.dxbc').write_bytes(raw)
    target=pipe.GetOutputTargets()[0].resource
    texture=next(t for t in c.GetTextures() if t.resourceId==target)
    assert texture.format.Name()=='R8G8_UNORM' and texture.width==2560 and texture.height==1440
    frame=texture.width*texture.height
    baseline=bytes(c.GetTextureData(target,rd.Subresource()));assert len(baseline)==frame*2
    green=baseline[1::2]
    report.update(sourceShaderSha256=hashlib.sha256(raw).hexdigest(),width=texture.width,height=texture.height,
                  qualifiedGreenSha256=hashlib.sha256(green).hexdigest())
    save()
    for phase,offset in enumerate(range(0,1<<23,frame)):
        count=min(frame,(1<<23)-offset)
        for byte in range(4):
            name=f'phase-{phase}-byte-{byte}'
            code=instrument(raw,texture.width,offset,byte);(out/(name+'.dxbc')).write_bytes(code)
            replacement,errors=c.BuildTargetShader('main',rd.ShaderEncoding.DXBC,code,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
            assert replacement!=rd.ResourceId.Null(),errors
            c.ReplaceResource(shader,replacement);c.SetFrameEvent(699,True)
            actual=bytes(c.GetTextureData(target,rd.Subresource()));assert len(actual)==len(baseline)
            qualified=actual[1::2]==green
            row=dict(phase=phase,byte=byte,offset=offset,count=count,qualified=qualified,
                     shaderSha256=hashlib.sha256(code).hexdigest())
            report['runs'].append(row);save();assert qualified,row
            payload=actual[0::2][:count]
            (out/(name+'.u8')).write_bytes(payload)
            row['outputSha256']=hashlib.sha256(payload).hexdigest()
            c.RemoveReplacement(shader);c.FreeTargetResource(replacement);replacement=None;save()
    c.SetFrameEvent(699,True);assert bytes(c.GetTextureData(target,rd.Subresource()))==baseline
    report.update(status='qualified',baselineRestored=True,debugMessages=[str(m.description) for m in c.GetDebugMessages()])
except BaseException:report.update(status='failed',error=traceback.format_exc())
finally:
    if c:
        if shader:c.RemoveReplacement(shader)
        if replacement:c.FreeTargetResource(replacement)
        c.Shutdown()
    if cap:cap.Shutdown()
    save()
sys.exit(0 if report['status']=='qualified' else 1)
