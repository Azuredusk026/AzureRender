from pathlib import Path
import subprocess,os,sys,json
out=Path(__file__).resolve().parent
main=Path('D:/Projects/FYP/Project/AzureRender')
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
mode=sys.argv[1]
if mode=='build':
    with (out/'collector-build.log').open('wb') as log:
        for name in ['compile-command.txt','link-command.txt']:
            subprocess.run((out/name).read_text(),cwd=main/'build/ninja-msvc-release',shell=True,check=True,stdout=log,stderr=subprocess.STDOUT)
        for command in [[str(sdk/'glslc.exe'),'-I'+str(out),str(out/'domain.comp'),'-o',str(out/'domain.spv')],
                        [str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3',str(out/'domain.spv')]]:
            subprocess.run(command,check=True,stdout=log,stderr=subprocess.STDOUT)
else:
    os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer')
    for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(key,None)
    os.environ['PATH']=str(main/'build/ninja-msvc-release')+';'+os.environ['PATH']
    with (out/'compute-domain.log').open('wb') as log:
        subprocess.run([str(out/'collector.exe'),str(out/'domain.spv'),str(out/'domain-fixture.json'),str(out/'compute-rcp-domain.f32')],check=True,stdout=log,stderr=subprocess.STDOUT)
print(mode+' completed')
