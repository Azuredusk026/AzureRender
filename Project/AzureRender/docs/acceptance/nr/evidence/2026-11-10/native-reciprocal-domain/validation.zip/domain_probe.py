from pathlib import Path
import struct
from dxbc_util import chunks,words,instructions,opcode,inst,dest,source,imm,fbits,rebuild,checksum
def instrument(raw,width,offset,byte):
    assert checksum(raw)==raw[4:20]
    parts=chunks(raw);index=next(i for i,(kind,_) in enumerate(parts) if kind in [b'SHEX',b'SHDR'])
    w=words(parts[index][1]);items=list(instructions(w))
    declaration=next(item for item in items if item[2]==opcode('DCL_TEMPS'))
    coordinate=w[declaration[1]+1];integer=coordinate+1;value=coordinate+2
    w[declaration[1]+1]=coordinate+3
    returns=[item for item in items if item[2]==opcode('RET')];assert len(returns)==1
    position=[2|(1<<2)|(0x44<<4)|(1<<12)|(1<<20),0]
    extra=inst('FTOU',dest(coordinate,3),position)
    extra+=inst('IMAD',dest(integer),source(coordinate,1),imm(width),source(coordinate,0))
    extra+=inst('IADD',dest(integer),source(integer),imm(offset))
    extra+=inst('OR',dest(value),source(integer),imm(0x3f800000))
    extra+=inst('RCP',dest(value),source(value))
    extra+=inst('USHR',dest(integer),source(value),imm(byte*8))
    extra+=inst('AND',dest(integer),source(integer),imm(255))
    extra+=inst('UTOF',dest(integer),source(integer))
    extra+=inst('MUL',dest(integer),source(integer),imm(fbits(1/255)))
    extra+=inst('MOV',dest(0,1,True),source(integer))
    end=returns[0][1];w[end:end]=extra;w[1]=len(w)
    parts[index]=(parts[index][0],struct.pack('<'+'I'*len(w),*w))
    return rebuild(raw,parts)
