from pathlib import Path
import json,hashlib,zipfile,re,subprocess
out=Path(__file__).parent;root=out.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((out/'frozen-source.json').read_text())
for name,digest in frozen.items():
 if not name.endswith('.md'):assert sha(root/name)==digest,name
release=json.loads((out/'release-program-sha256.json').read_text());debug=json.loads((out/'debug-program-sha256.json').read_text())
assert release==debug and len(release)==855
for name,digest in release.items():
 for build in ['20261110-030251-hair-main-chroma-public-9e799c/release','20261110-031856-hair-main-chroma-debug-668bf2/debug']:
  assert sha(root/'build/runs'/build/'shaders'/name)==digest,name
result=json.loads((out/'matrix-analysis.json').read_text());assert result['qualifiedGroups']==36
for group in result['groups']:
 if group['group']=='footprint':assert (group['changedPixels'],group['maximumByteChange'])==((2028,34) if group['device']=='nvidia' else (162,15))
docs=['README.md','docs/project-status.md','docs/plans/azure-engine-plan.md']
for name in docs:
 p=root/name;text=p.read_text(encoding='utf-8');prefix='docs/' if name=='README.md' else '' if name=='docs/project-status.md' else '../'
 if '[材质主 UV 绑定]' not in text:
  text+='\n[材质主 UV 绑定]('+prefix+'acceptance/nr/material-primary-uv-policy.md)通过两配置、双设备的三十六组检查。\n'
  text+='公开材质、阴影、覆盖、足迹正控制及失败清理通过，原始四帧摘要精确一致。\n'
  text+='当前程序集为 855 份，实际相机与几何深度组合继续验收。\n';p.write_text(text,encoding='utf-8')
p=root/'CHANGELOG.md';text=p.read_text(encoding='utf-8');title,remaining=text.split('\n',1)
if '## 2026-11-10 材质主 UV 绑定' not in text:p.write_text(title+'\n\n## 2026-11-10 材质主 UV 绑定\n\n- 版本二受光材质通过公开特性选择镜像四像素足迹。\n- 主表面、深度、阴影及轮廓共用导入器选定的坐标流。\n- 接收循环采用 `62fc79c` 的受检来源，参考程序族增加 168 份。\n- 双配置的 855 份程序一致，八项 CPU 检查及三十六组 GPU 检查通过。\n- 原始四帧摘要一致，十六项缺失程序清理检查通过。\n- 空扩展、填充材质与梯度主导范围的失败及修正分别归档。\n- Intel 九十六处深度超差及生产头发颜色验收继续推进。\n'+remaining,encoding='utf-8')
source=list(frozen)+['docs/runtime/material-primary-uv-policy.md','docs/plans/2026-11-10-material-uv-loop-qualification.md','docs/acceptance/nr/material-primary-uv-policy.md']
files={}
for p in out.rglob('*'):
 if p.is_file() and p.suffix in {'.json','.log','.py','.cpp','.patch','.png','.gltf','.azurelevel','.azureproject','.azmeta'} and p.stat().st_size<1024*1024:
  if 'default-four-frames' in p.parts or 'tmp' in p.parts:continue
  files['run/'+p.relative_to(out).as_posix()]=p
files.update({'source/'+name:root/name for name in source})
files['build/shader-reload.json']=root/'build/runs/20261110-030251-hair-main-chroma-public-9e799c/release/shader-reload.json'
dest=root/'docs/acceptance/nr/evidence/2026-11-10/material-primary-uv-policy';dest.mkdir(parents=True,exist_ok=True)
catalog={'programs':855,'referenceFamily':168,'configurationsIdentical':True,'sha256':release}
(dest/'program-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
files['program-catalog.json']=dest/'program-catalog.json'
members={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()};archive=dest/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,v in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
result.update(testedSourceSha256=frozen,publishedSourceSha256={n:sha(root/n) for n in source},programCatalogSha256=sha(dest/'program-catalog.json'),archive={'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members)+1})
(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n')
for name in source+docs+['CHANGELOG.md']:
 if not name.endswith('.md'):continue
 p=root/name;text=p.read_text(encoding='utf-8')
 if name not in docs+['CHANGELOG.md']:
  for link in re.findall(r'\]\(([^)]+)\)',text):
   if not re.match(r'(https?:|#)',link):assert (p.parent/link.split('#')[0]).exists(),(name,link)
  for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(name,sentence)
print(json.dumps(result['archive']))
