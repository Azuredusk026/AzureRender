from pathlib import Path
import json,subprocess
out=Path(__file__).parent;root=out.parents[2];old=out.parent/'20261110-141407-material-mirrored-uv-policy-1a9615'
for name in json.loads((old/'candidate-source-index.json').read_text()):
 p=root/name
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((old/'candidate-source'/name).read_bytes())
