from pathlib import Path
import sys,json,os,time,hashlib
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
out=Path(__file__).parent;root=out.parents[2];owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
assert json.loads((out/'receiver-fix.json').read_text())['qualified']
groups=['shadow','generic-red-aa0','hair-red-aa0','hair-red-aa4','object-shadow','hair-shell-red-aa0','solid','footprint','missing']
folders={'Release':'20261110-030251-hair-main-chroma-public-9e799c/release','Debug':'20261110-031856-hair-main-chroma-debug-668bf2/debug'}
order=[('Release','intel','shadow')]+[(c,d,g) for c in ['Release','Debug'] for d in ['nvidia','intel'] for g in groups if (c,d,g)!=('Release','intel','shadow')]
rows=json.loads((out/'matrix-results.json').read_text()) if (out/'matrix-results.json').exists() else []
done={(r['configuration'],r['device'],r['group']) for r in rows if r['result'].get('exitCode')==0 and not r.get('supersededInput',False)}
for configuration,device,group in order:
 if (configuration,device,group) in done:continue
 while (out/'pause-matrix').exists():time.sleep(1)
 for name,digest in json.loads((out/'frozen-source.json').read_text()).items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 build=root/'build/runs'/folders[configuration];label=configuration.lower()+'-'+device+'-'+group;output=out/('matrix-'+label)
 tool='test_material_uv_footprint_gpu.py' if group=='footprint' else 'test_material_uv_policy_failure_gpu.py' if group=='missing' else 'test_material_uv_policy_gpu.py'
 command=[sys.executable,str(root/'tools'/tool),'--executable',str(build/'AzurePlayer.exe'),'--output',str(output),'--expected-validation','enabled' if configuration=='Debug' else 'disabled']
 if group not in ['footprint','missing']:
  command+=['--section','solid' if group=='solid' else 'coverage']
  if group!='solid':command+=['--case',group]
 env={'VK_LOADER_DRIVERS_SELECT':'*igvk64*' if device=='intel' else '*nv-vk64*','VK_INSTANCE_LAYERS':'VK_LAYER_KHRONOS_validation','VK_LAYER_VALIDATE_SYNC':'1'};old={k:os.environ.get(k) for k in env};os.environ.update(env)
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
 started=time.monotonic()
 while True:
  context=s.lease(s.DEFAULT_QUEUE,owner,'quality-uv-'+label,out)
  try:context.__enter__();break
  except ValueError as error:
   if not any(x in str(error) for x in ['busy','still running']):raise
   if time.monotonic()-started>=180:raise TimeoutError('Queue wait ended; group not executed: '+label)
   time.sleep(1)
 try:
  print('START',label,flush=True);result=s.maintenance.guarded_run(root/'build',out.name,command,360);(out/(label+'-execution.json')).write_text(json.dumps(result,indent=2));(out/(label+'-process.log')).write_bytes((out/'process.log').read_bytes())
 finally:
  context.__exit__(None,None,None)
  for key,value in old.items():
   if value is None:os.environ.pop(key,None)
   else:os.environ[key]=value
 row={'configuration':configuration,'device':device,'group':group,'result':result};rows.append(row);(out/'matrix-results.json').write_text(json.dumps(rows,indent=2)+'\n');assert result.get('exitCode')==0,result;print('PASS',label,flush=True)
 time.sleep(2)
