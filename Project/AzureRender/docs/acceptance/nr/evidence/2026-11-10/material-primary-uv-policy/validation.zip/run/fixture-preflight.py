from pathlib import Path
import sys,json,hashlib,math,base64,struct
out=Path(__file__).parent;root=out.parents[2];sys.path.insert(0,str(root/'tools'))
from test_material_uv_footprint_gpu import prepare
rows=[]
for enabled in [False,True]:
 folder=out/'fixture-preflight'/str(enabled);project=prepare(folder,enabled);model=json.loads((folder/'surface.gltf').read_text());index=model['meshes'][0]['primitives'][0]['material'];profile=model['materials'][index]['extras']['azureRenderMaterial'];assert profile=={'schemaVersion':2,'class':'generic','features':['mirrored-coarse-uv'] if enabled else []};assert index==1 and 'mirrored-coarse-uv' not in model['materials'][0].get('extras',{}).get('azureRenderMaterial',{}).get('features',[]);assert project.is_file()
 positions=struct.unpack('<12f',base64.b64decode(model['buffers'][0]['uri'].split(',')[1])[:48]);assert positions==(-2,-1,2,2,-1,-4,2,4,-4,-2,4,2) and model['accessors'][0]['max']==[2,4,2]
 f=1/math.tan(math.radians(55)/2);depth=4/(1-1.5*.5/f);worldY=.9*depth/f;ratio=1.5*worldY/4;assert 2<worldY<4 and ratio>1
 rows.append({'enabled':enabled,'projectExists':True,'activeMaterial':index,'paddingPolicyAbsent':True,'profile':profile,'planeTopY':4,'ndcWitness':[.5,-.9],'witnessDxOverDy':ratio})
(out/'fixture-preflight.json').write_text(json.dumps(rows,indent=2)+'\n')
p=out/'frozen-source.json';value=json.loads(p.read_text());old=value['tools/test_material_uv_footprint_gpu.py'];new=hashlib.sha256((root/'tools/test_material_uv_footprint_gpu.py').read_bytes()).hexdigest();value['tools/test_material_uv_footprint_gpu.py']=new;p.write_text(json.dumps(value,indent=2)+'\n')
(out/'fixture-dominant-gradient-correction.json').write_text(json.dumps({'cause':'Original visible plane has abs(dVdx)/abs(dVdy)<=0.75; Intel maximum-column scale can hide the modified X derivative','evidence':'Actual four Intel images identical with the policy on the rendered material; independent device LOD source and analytic plane Jacobian agree','correction':'Extend plane topY2 to4, preserving shader and sampler; visible analytic witness now has X-dominant gradient','beforeSha256':old,'afterSha256':new,'affectedGroups':['footprint'],'priorNvidiaPositiveControlPreservedAsV1':True,'publicBinariesUnchanged':True,'acceptanceThresholdsUnchanged':True},indent=2)+'\n');print('Active material, actual geometry and X-dominant visible witness verified')
