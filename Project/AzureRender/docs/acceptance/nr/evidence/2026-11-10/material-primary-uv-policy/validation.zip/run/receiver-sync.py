from pathlib import Path
import subprocess,json,hashlib
out=Path(__file__).parent;root=out.parents[2];commit='62fc79cb097c1b77fed92e78ae7902b0bf68903d'
def extract(text):
 start=text.index('void prepareShadowReceiver()');end=text.index('\nfloat sampleShadowMap',start);return text[start:end]
qualified=subprocess.check_output(['git','show',commit+':Project/AzureRender/shaders/mesh.frag'],cwd=root).decode('utf-8');working=(root/'shaders/mesh.frag').read_text(encoding='utf-8');staged=subprocess.check_output(['git','show',':Project/AzureRender/shaders/mesh.frag'],cwd=root).decode('utf-8');assert extract(qualified)==extract(working)==extract(staged)
diff=subprocess.check_output(['git','diff','--cached','--','Project/AzureRender/shaders/mesh.frag'],cwd=root.parents[1]).decode();assert 'azurePreparePrimaryUv' not in diff and '+    {const int i=3;' in diff
sha=hashlib.sha256(extract(staged).encode()).hexdigest();value=json.loads((out/'receiver-fix.json').read_text());value['qualification']['integrationCommit']=commit;value['receiverFunctionSha256']=sha;(out/'receiver-fix.json').write_text(json.dumps(value,indent=2)+'\n')
dest=root/'docs/acceptance/nr/evidence/2026-11-10/receiver-source-sync';dest.mkdir(parents=True,exist_ok=True)
result={'sourceCommit':commit,'sourceFunctionSha256':sha,'stagedAndWorkingFunctionMatch':True,'sourceOwnerAttestation':{'threadId':'01a1c097-ec33-7790-8c18-08a2b0ddb0c3','automaticChecksPerConfiguration':8,'actualGpuViewFlows':16,'matrixPixelsPerEndpoint':199680,'legacyPixelsPerEndpoint':33280,'nvidiaFrozenProgramPixels':199680,'nativeFourPngShaAndRgbExact':True,'validationErrors':0,'resourcesAfterUnload':0,'stableInputs':1729},'localBuilds':{c:json.loads((out/(c+'-final-build-execution.json')).read_text()) for c in ['release','debug']},'uvCombinationStatus':'pending-independent-GPU-qualification','overall':'failed-user-review'}
assert all(v['exitCode']==0 for v in result['localBuilds'].values());(dest/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(sha)
