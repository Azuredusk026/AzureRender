from pathlib import Path
import json,subprocess,sys
out=Path(__file__).parent;root=out.parents[2];old=out.parent/'20261110-183305-intel-depth-alpha-footprint-e32993';command=json.loads((old/'attribute-build-commands.json').read_text())[0];command=command.replace(str(old/'native-coverage.cpp'),str(root/'tests/MaterialUvPolicyTests.cpp')).replace(str(old),str(out)).replace(' -c ',' ');command+=' /Fe'+str(out/'cpu-contract.exe')
with (out/('cpu-contract-'+sys.argv[1]+'-build.log')).open('wb') as log:r=subprocess.run('D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat '+command,shell=True,stdout=log,stderr=subprocess.STDOUT,timeout=60)
assert r.returncode==0
r=subprocess.run([str(out/'cpu-contract.exe')],capture_output=True,text=True);(out/('cpu-contract-'+sys.argv[1]+'.log')).write_text(r.stdout+r.stderr);print(r.returncode,r.stdout+r.stderr)
if sys.argv[1]=='red':assert r.returncode!=0 and '8/12' in r.stdout+r.stderr
else:assert r.returncode==0
