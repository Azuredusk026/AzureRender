from pathlib import Path
import sys,time,json,os
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as shared
out=Path(__file__).resolve().parent;configuration='Release'
assert json.loads((out/'receiver-fix.json').read_text())['sourcePrepared'], 'Receiver correction source required before compilation'
name='20261110-030251-hair-main-chroma-public-9e799c' if configuration=='Release' else '20261110-031856-hair-main-chroma-debug-668bf2'
started=time.monotonic()
while True:
 context=shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-material-mirrored-uv-'+configuration.lower(),out)
 try:context.__enter__();break
 except ValueError as error:
  if not any(s in str(error) for s in ['busy','still running']):raise
  if time.monotonic()-started>=180:raise TimeoutError('Queue wait ended; no build executed')
  time.sleep(1)
try:
 os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
 result=shared.maintenance.guarded_run(out.parents[1],out.name,[sys.executable,str(out/'default-four.py')],300)
 (out/('default-four-execution.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
finally:context.__exit__(None,None,None)
sys.exit(result.get('exitCode',2))
