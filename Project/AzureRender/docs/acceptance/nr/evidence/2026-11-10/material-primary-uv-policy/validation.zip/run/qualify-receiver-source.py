from pathlib import Path
import json,hashlib,subprocess
out=Path(__file__).parent;root=out.parents[2];main=Path('D:/Projects/FYP/Project/AzureRender');sha=lambda data:hashlib.sha256(data).hexdigest()
def function(path):
 text=path.read_text(encoding='utf-8');start=text.index('void prepareShadowReceiver()');end=text.index('\nfloat sampleShadowMap',start);return text[start:end]
a=function(main/'shaders/mesh.frag');b=function(root/'shaders/mesh.frag');assert a==b and all('{const int i='+str(i)+';' in a for i in range(4))
value=json.loads((out/'receiver-fix.json').read_text());value.update(qualified=True,rootParentCommit=subprocess.check_output(['git','-C','D:/Projects/FYP','rev-parse','HEAD'],text=True).strip(),receiverFunctionSha256=sha(a.encode()),sourceFunctionIdentical=True,qualification={'threadId':'01a1c097-ec33-7790-8c18-08a2b0ddb0c3','messageId':'msg_02f4b6bea2a342c7016af32629542887d2b12eb6d50aa80721','cursor':'31732e01-f0cf-4656-aea9-2dce91c4241c:31','checks':'Main dual-configuration and device material identity, native frozen four PNG SHA256/RGB exact, zero validation and resources','integrationCommit':'pending source-owner commit'})
(out/'receiver-fix.json').write_text(json.dumps(value,indent=2)+'\n');print('Receiver function exactly matches qualified source; integration commit pending')
