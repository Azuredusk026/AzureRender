from pathlib import Path
import json,sys,numpy as np,hashlib
from PIL import Image
out=Path(__file__).parent;rows=json.loads((out/'matrix-results.json').read_text());latest={(r['configuration'],r['device'],r['group']):r for r in rows};summaries=[];images=0;coveragePixels=0;numericComponents=0
for (configuration,device,group),row in latest.items():
 if row['result'].get('exitCode')!=0 or row.get('supersededInput',False):continue
 folder=out/('matrix-'+configuration.lower()+'-'+device+'-'+group);entry={'configuration':configuration,'device':device,'group':group,'executionSeconds':row['result']['seconds']}
 if group in ['footprint','solid','missing']:
  path=folder/('results.json' if group=='footprint' else 'solid/results.json' if group=='solid' else 'summary.json');value=json.loads(path.read_text());assert value['status']=='passed',path
  if group=='footprint':
   assert len(value['cases'])==4 and value['changedPixels']>0 and value['maximumByteChange']>0
   for policy in ['reference','device']:
    a=np.asarray(Image.open(folder/('indexed-'+policy)/'frames/frame_000000.png').convert('RGB'));b=np.asarray(Image.open(folder/('fixed-'+policy)/'frames/frame_000000.png').convert('RGB'));assert np.array_equal(a,b),(configuration,device,policy)
   entry.update(changedPixels=value['changedPixels'],maximumByteChange=value['maximumByteChange'],defaultDescriptorIdentity=True,referenceDescriptorIdentity=True);images+=4
  elif group=='solid':
   assert len(value['captures'])==4
   for capture in value['captures']:
    assert capture['exitCode']==0 and capture['allocatorZero'] and capture['maximumLinearError']<=value['maximumLinearErrorBudget'];numericComponents+=len(capture['pixels'])*3
   entry.update(captures=4,maximumLinearError=max(c['maximumLinearError'] for c in value['captures']),linearBudget=value['maximumLinearErrorBudget']);images+=4
  else:
   assert len(value['cases'])==4
   for case in value['cases']:
    assert case['status']=='passed' and case['exitCode']!=0 and case['frames']==0 and case['allocatorAfterUnload']=={'buffers':0,'images':0}
    assert not list((folder/case['name']/'resources/shaders').iterdir()),case['name']
   entry.update(rejectionCases=4,temporaryShaderLinksReleased=True)
 else:
  value=json.loads((folder/'coverage/summary.json').read_text());assert value['status']=='passed' and len(value['cases'])==4 and len(value['groups'])==1
  planes=[]
  for case in value['cases']:
   assert case['status']=='captured' and case['frames']==1
   image=Image.open(folder/'coverage'/case['name']/'frames/frame_000000.png').convert('RGB');planes.append(np.asarray(image));images+=1
  assert all(np.array_equal(planes[0],a) for a in planes[1:]),(configuration,device,group)
  pixels=planes[0].shape[0]*planes[0].shape[1];coveragePixels+=pixels*4;entry.update(captures=4,allFourRgbExact=True,comparedPixelValues=pixels*4)
 summaries.append(entry)
result={'status':'matrix-in-progress','overall':'failed-user-review','sourceCommit':'2e4262b','receiverSourceCommit':'62fc79cb097c1b77fed92e78ae7902b0bf68903d','qualifiedGroups':len(summaries),'requiredGroups':36,'capturedImages':images,'coveragePixelValues':coveragePixels,'numericComponents':numericComponents,'groups':summaries,'failedAttempts':[r for r in rows if r['result'].get('exitCode')!=0]}
if '--final' in sys.argv:
 assert len(summaries)==36
 for configuration in ['release','debug']:
  identity=json.loads((out/(configuration+'-identity.json')).read_text());assert len(identity['cpuChecks'])==4 and all(r['exitCode']==0 for r in identity['cpuChecks']) and identity['programs']==855 and identity['referenceFamily']==168
 result['defaultFour']=json.loads((out/'default-four-results.json').read_text());assert result['defaultFour']['allExact'];result['status']='qualified-public-material-uv-policy';result['cpuChecks']=8;result['programs']=855;result['referenceFamily']=168
(out/'matrix-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['groups','failedAttempts']},indent=2))
