from pathlib import Path
import subprocess,json,sys,re,hashlib
out=Path(__file__).parent;root=out.parents[2];configuration=sys.argv[1];build=out.parent/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug');rows=[]
fixture=root/'assets_public/third_person/material_fixture.gltf';assert fixture.is_file()
for target,args in [('AzureMaterialUvPolicyTests',[]),('AzureMaterialPipelinePolicyTests',[]),('AzureMaterialUvImportTests',[]),('AzureCharacterRepairTests',[str(fixture)])]:
 command=[str(build/(target+'.exe')),*args]
 with (out/(configuration.lower()+'-'+target+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 rows.append({'target':target,'exitCode':r.returncode,'command':command});(out/(configuration.lower()+'-cpu-results.json')).write_text(json.dumps(rows,indent=2)+'\n');assert r.returncode==0,target
catalog=json.loads((build/'shader-reload.json').read_text());programs=catalog['programs'];assert len(programs)==855
references=[p for p in programs if 'AZURE_REFERENCE_MATERIAL_UV=1' in p['defines']];assert len(references)==168
assert all('AZURE_FRAGMENT_QUAD_OPERATIONS=1' in p['defines'] and '--target-env=vulkan1.1' in p['arguments'] for p in references)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();hashes={p['output']:sha(build/'shaders'/p['output']) for p in programs};(out/(configuration.lower()+'-program-sha256.json')).write_text(json.dumps(hashes,indent=2)+'\n')
baseline=json.loads((out.parent/'20261110-211719-alpha-ellipse-lod-5c69d6'/(configuration.lower()+'-all-program-sha256.json')).read_text());sources={p['output']:p['source'] for p in programs};changed=[n for n in baseline if baseline[n]!=hashes.get(n)];assert all(sources[n]=='mesh.frag' for n in changed),changed
result={'configuration':configuration,'cpuChecks':rows,'programs':len(programs),'referenceFamily':len(references),'changedOriginalPrograms':changed,'originalNonMeshProgramsExact':True,'playerSha256':sha(build/'AzurePlayer.exe')};(out/(configuration.lower()+'-identity.json')).write_text(json.dumps(result,indent=2)+'\n');print(configuration,'four CPU checks,855 programs,168 reference variants, non-mesh baseline identity passed')
