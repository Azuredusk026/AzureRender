from pathlib import Path
import sys,json,hashlib
out=Path(__file__).parent;root=out.parents[2];sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
(out/'receiver-fix.json').write_text(json.dumps({'qualified':False,'sourcePrepared':True,'source':'Integrator staged four constant-index shadow receiver blocks','patchSha256':hashlib.sha256((out/'receiver-unroll.patch').read_bytes()).hexdigest(),'qualification':'Integrator formal default-four gate pending; compilation only, no UV GPU batch authorized by this checkpoint'},indent=2)+'\n')
script=(out/'queued-build.py').read_text().replace("['qualified'], 'Receiver correction qualification required before formal build'","['sourcePrepared'], 'Receiver correction source required before compilation'");(out/'queued-build.py').write_text(script)
for n in ['20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2']:s.maintenance.resume(root/'build',n)
