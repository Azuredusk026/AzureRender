from pathlib import Path
import json,subprocess
out=Path(__file__).parent;old=out.parent/'20261110-141407-material-mirrored-uv-policy-1a9615'
(out/'build.py').write_text((old/'build.py').read_text().replace("'AzureCharacterRepairTests','AzurePlayer'","'AzureCharacterRepairTests','AzureMaterialUvImportTests','AzurePlayer'"))
(out/'queued-build.py').write_text((old/'queued-build.py').read_text().replace("configuration=sys.argv[1]","configuration=sys.argv[1]\nassert json.loads((out/'receiver-fix.json').read_text())['qualified'], 'Receiver correction qualification required before formal build'"))
patch=subprocess.check_output(['git','-C','D:/Projects/FYP','diff','--','Project/AzureRender/shaders/mesh.frag']);assert b'{const int i=3;' in patch;(out/'receiver-unroll.patch').write_bytes(patch)
(out/'source-candidate.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=out.parents[2]))
task=json.loads((out/'task-card.json').read_text());task['gpuSeconds']=4800;task['reasonForGpuBudget']='Both configurations, both devices, seven source groups, footprint positive control and missing-program cleanup; four-image queue slices';(out/'task-card.json').write_text(json.dumps(task,indent=2)+'\n')
