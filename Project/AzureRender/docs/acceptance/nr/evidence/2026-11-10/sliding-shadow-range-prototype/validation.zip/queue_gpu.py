from pathlib import Path
import sys,time,json
r=Path.cwd();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
import shared_resources as shared
import artifact_maintenance as maintenance
start=time.monotonic();deadline=start+150
while True:
 locked=False
 try:
  with shared.lease(shared.DEFAULT_QUEUE,'01a1c097-ec33-7790-8c18-08a2b0ddb0c3','sliding-shadow-range-private-gpu',o):
   locked=True
   (o/'queue-result.json').write_text(json.dumps(dict(waitSeconds=time.monotonic()-start,acquired=True),indent=2))
   result=maintenance.guarded_run(r/'build',o.name,[sys.executable,'-X','utf8','-B',str(o/'qualify_gpu.py')],420)
  print(json.dumps(result),flush=True);raise SystemExit(result.get('exitCode',2))
 except (ValueError,OSError) as error:
  if locked or 'Shared resource busy or inaccessible' not in str(error):raise
  if time.monotonic()>=deadline:
   (o/'queue-result.json').write_text(json.dumps(dict(waitSeconds=time.monotonic()-start,acquired=False,reason=str(error)),indent=2));raise SystemExit(2)
  time.sleep(2)
