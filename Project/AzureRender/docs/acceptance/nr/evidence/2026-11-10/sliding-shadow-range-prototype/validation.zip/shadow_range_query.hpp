#pragma once
#include <array>
#include <cstdint>
#include <limits>
#include <optional>
#include <stdexcept>
namespace azurerender {
struct ShadowRangeQueryPlan {
 std::array<std::uint32_t,4> indices{};
 std::uint32_t count=0,level=0;
};
inline std::uint32_t shadowRangeTableElementCount(std::uint32_t columns,std::uint32_t rows){
 const auto baseElements=std::uint64_t(columns)*rows;
 if(!columns||!rows||baseElements>std::numeric_limits<std::uint32_t>::max()/3u)
  throw std::invalid_argument("Shadow range table dimensions exceed the three-plane index domain");
 return static_cast<std::uint32_t>(baseElements*3u);
}
inline std::optional<ShadowRangeQueryPlan> makeShadowRangeQueryPlan(std::uint32_t columns,std::uint32_t rows,
 std::array<std::uint32_t,2> low,std::array<std::uint32_t,2> high){
 const auto total=shadowRangeTableElementCount(columns,rows);
 if(low[0]>high[0]||low[1]>high[1]||high[0]>=columns||high[1]>=rows)
  throw std::invalid_argument("Shadow range rectangle is outside the base table");
 const auto width=high[0]-low[0]+1,height=high[1]-low[1]+1,shortSide=width<height?width:height;
 ShadowRangeQueryPlan result;std::uint32_t side=1;
 while(side<4&&side*2<=shortSide){side*=2;++result.level;}
 if(width>side*2||height>side*2)return std::nullopt;
 const std::uint32_t right=high[0]+1-side,bottom=high[1]+1-side,offset=result.level*(total/3);
 const std::array<std::uint32_t,2> xs{low[0],right},ys{low[1],bottom};
 for(unsigned y=0;y<(bottom==low[1]?1u:2u);++y)for(unsigned x=0;x<(right==low[0]?1u:2u);++x)
  result.indices[result.count++]=offset+ys[y]*columns+xs[x];
 return result;
}
}
