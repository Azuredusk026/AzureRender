#include "shadow_range_query.hpp"
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <vector>
using namespace azurerender;
struct Bounds {float minimum,maximum;};
static_assert(sizeof(Bounds)==8);
Bounds unite(Bounds a,Bounds b){return {std::min(a.minimum,b.minimum),std::max(a.maximum,b.maximum)};}
Bounds direct(const std::vector<Bounds>& data,unsigned width,unsigned x0,unsigned y0,unsigned x1,unsigned y1){
 Bounds result{1,0};for(unsigned y=y0;y<=y1;++y)for(unsigned x=x0;x<=x1;++x)result=unite(result,data[y*width+x]);return result;
}
int main()try{
 std::mt19937 random(0x63f29a1);std::uint64_t queries=0,fast=0,reads=0,directReads=0;unsigned rejects=0;
 for(auto extent:{std::array<unsigned,2>{1,1},{2,3},{3,2},{7,9},{17,13},{64,61}}){
  unsigned w=extent[0],h=extent[1],n=w*h;std::vector<Bounds> base(n),table(n*3);
  if(shadowRangeTableElementCount(w,h)!=n*3)throw std::runtime_error("Table size mismatch");
  for(auto& v:base){v.minimum=float(random()&0xfffff)/1048576;v.maximum=std::min(1.F,v.minimum+float(random()&0xfffff)/1048576);}
  for(unsigned level=0;level<3;++level){unsigned side=1u<<level;for(unsigned y=0;y<h;++y)for(unsigned x=0;x<w;++x)
   table[level*n+y*w+x]=direct(base,w,x,y,std::min(w-1,x+side-1),std::min(h-1,y+side-1));}
  auto check=[&](unsigned x0,unsigned y0,unsigned x1,unsigned y1){
   auto plan=makeShadowRangeQueryPlan(w,h,{x0,y0},{x1,y1});auto expected=direct(base,w,x0,y0,x1,y1);Bounds actual{1,0};
   unsigned count=(x1-x0+1)*(y1-y0+1);directReads+=count;
   if(plan){
    if(plan->count!=1&&plan->count!=2&&plan->count!=4)throw std::runtime_error("Invalid block count");
    for(unsigned i=0;i<plan->count;++i){if(plan->indices[i]>=table.size())throw std::runtime_error("Out-of-range table read");
     for(unsigned j=0;j<i;++j)if(plan->indices[i]==plan->indices[j])throw std::runtime_error("Duplicate table read");
     actual=unite(actual,table[plan->indices[i]]);}
    ++fast;reads+=plan->count;
   }else{actual=direct(base,w,x0,y0,x1,y1);reads+=count;}
   if(std::memcmp(&actual,&expected,sizeof(Bounds))!=0)throw std::runtime_error("Brute-force union differs");++queries;
  };
  if(w<=7&&h<=9)for(unsigned y0=0;y0<h;++y0)for(unsigned y1=y0;y1<h;++y1)for(unsigned x0=0;x0<w;++x0)for(unsigned x1=x0;x1<w;++x1)check(x0,y0,x1,y1);
  for(unsigned i=0;i<8192;++i){unsigned x0=random()%w,y0=random()%h;unsigned dx=random()%std::min(6u,w-x0),dy=random()%std::min(6u,h-y0);check(x0,y0,x0+dx,y0+dy);}
  try{(void)makeShadowRangeQueryPlan(w,h,{w,0},{w,0});}catch(const std::invalid_argument&){++rejects;}
 }
 for(auto dimensions:{std::array<unsigned,2>{0,1},{1,0},{std::numeric_limits<unsigned>::max(),2}})
  try{(void)shadowRangeTableElementCount(dimensions[0],dimensions[1]);}catch(const std::invalid_argument&){++rejects;}
 try{(void)makeShadowRangeQueryPlan(8,8,{2,0},{1,0});}catch(const std::invalid_argument&){++rejects;}
 bool wideOverflowRejected=false;try{(void)shadowRangeTableElementCount(0xaaaaaaabu,0x80000000u);}catch(const std::invalid_argument&){wideOverflowRejected=true;}
 if(!wideOverflowRejected)throw std::runtime_error("Wide multiplication overflow was accepted");
 auto square=makeShadowRangeQueryPlan(16,16,{4,5},{7,8});if(!square||square->count!=1||square->level!=2)throw std::runtime_error("Exact four-block footprint should use one entry");
 if(makeShadowRangeQueryPlan(16,16,{2,0},{2,8}))throw std::runtime_error("Long narrow rectangle must retain direct fallback");
 if(rejects!=10||fast==0||fast==queries||reads>=directReads)throw std::runtime_error("Coverage or read count invariant failed");
 std::cout<<"queries="<<queries<<" exact; fast="<<fast<<" reads="<<reads<<" directReads="<<directReads<<" rejects="<<rejects<<'\n';return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
