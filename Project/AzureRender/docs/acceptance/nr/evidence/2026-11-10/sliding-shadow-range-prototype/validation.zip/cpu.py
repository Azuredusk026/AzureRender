from pathlib import Path
import subprocess,sys,os,json,time
r=Path.cwd();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'));start=time.monotonic()
command=[str(r/'tools/msvc_env.bat'),'cl.exe','/nologo','/std:c++17','/EHsc','/O2','/MD','/Fo'+str(o/'query_tests.obj'),'/Fe'+str(o/'query_tests.exe'),str(o/'query_tests.cpp'),'/link','/PDB:'+str(o/'query_tests.pdb')]
with (o/'cpu-build.log').open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
result=subprocess.run([str(o/'query_tests.exe')],capture_output=True,text=True,timeout=30)
(o/'cpu-tests.log').write_text(result.stdout+result.stderr);assert result.returncode==0,result.stdout+result.stderr
(o/'cpu-results.json').write_text(json.dumps(dict(status='passed',seconds=time.monotonic()-start,command=command,output=result.stdout),indent=2));print(result.stdout,flush=True)
