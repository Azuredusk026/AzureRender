#include "private_fixture.hpp"
#include "shadow_range_query.hpp"
#include "resources/BinaryFile.hpp"
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <random>
#include <string>
#include <vector>
using namespace azurerender;
struct Bounds {float minimum,maximum;};
struct Result {Bounds bounds;std::uint32_t count,level;};
struct Push {std::uint32_t width,height,phase,count;};
static_assert(sizeof(Bounds)==8&&sizeof(Result)==16&&sizeof(Push)==16);
Bounds unite(Bounds a,Bounds b){return {std::min(a.minimum,b.minimum),std::max(a.maximum,b.maximum)};}
Bounds direct(const std::vector<Bounds>& base,unsigned w,std::array<unsigned,4> q){
 Bounds v{1,0};for(unsigned y=q[1];y<=q[3];++y)for(unsigned x=q[0];x<=q[2];++x)v=unite(v,base[y*w+x]);return v;
}
void run(const char* shaderPath,unsigned w,unsigned h,unsigned count,bool timing){
 test::VulkanComputeFixture host(false,false,false,false,false,false,true,false,!timing);auto& backend=*host.backend;
 std::mt19937 random(0x816f4+w*31+h);unsigned n=w*h;std::vector<Bounds> base(n),table(shadowRangeTableElementCount(w,h));
 for(auto& b:base){b.minimum=float(random()&0xfffff)/1048576;b.maximum=std::min(1.F,b.minimum+float(random()&0x3ffff)/1048576);}
 base.front()={0,0};base.back()={1,1};
 std::vector<std::array<unsigned,4>> queries(count);
 for(unsigned i=0;i<count;++i){unsigned x=random()%w,y=random()%h;unsigned dx=(i&1)?3:2,dy=(i&2)?3:2;if(i%8==0){dx=0;dy=8;}
  queries[i]={x,y,std::min(w-1,x+dx),std::min(h-1,y+dy)};}
 std::vector<Bounds> expectedTable(table.size());
 for(unsigned level=0;level<3;++level)for(unsigned y=0;y<h;++y)for(unsigned x=0;x<w;++x)
  expectedTable[level*n+y*w+x]=direct(base,w,{x,y,std::min(w-1,x+(1u<<level)-1),std::min(h-1,y+(1u<<level)-1)});
 std::copy(base.begin(),base.end(),table.begin());
 rhi::GpuBuffer ranges{},rectangles{},results{};VkDescriptorSetLayout setLayout{};VkDescriptorPool pool{};VkPipelineLayout layout{};VkPipeline pipeline{};VkShaderModule shader{};VkQueryPool timestamps{};
 auto cleanup=std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*){
  if(timestamps)vkDestroyQueryPool(host.device,timestamps,nullptr);if(pipeline)backend.destroyPipeline(pipeline);if(shader)backend.destroyShaderModule(shader);
  if(layout)backend.destroyPipelineLayout(layout);if(pool)backend.destroyDescriptorPool(pool);if(setLayout)backend.destroyDescriptorSetLayout(setLayout);
  host.allocator.destroyBuffer(results);host.allocator.destroyBuffer(rectangles);host.allocator.destroyBuffer(ranges);
 });
 ranges=host.allocator.createBuffer(table.size()*sizeof(Bounds),VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
 rectangles=host.allocator.createBuffer(queries.size()*sizeof(queries[0]),VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
 results=host.allocator.createBuffer(queries.size()*sizeof(Result)*2,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
 std::memcpy(ranges.mapped,table.data(),ranges.size);std::memcpy(rectangles.mapped,queries.data(),rectangles.size);
 host.allocator.flush(ranges,0,ranges.size);host.allocator.flush(rectangles,0,rectangles.size);
 setLayout=backend.createDescriptorSetLayout({{0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},{1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},{2,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT}});
 rhi::DescriptorPoolDesc description;description.sizes={{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,3}};description.maxSets=1;pool=backend.createDescriptorPool(description);
 auto set=backend.allocateDescriptorSets(pool,setLayout,1).front();
 backend.writeDescriptorBuffer({set,0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,ranges.buffer,ranges.size});backend.writeDescriptorBuffer({set,1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,rectangles.buffer,rectangles.size});backend.writeDescriptorBuffer({set,2,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,results.buffer,results.size});
 const rhi::PushConstantRangeDesc push{VK_SHADER_STAGE_COMPUTE_BIT,sizeof(Push)};layout=backend.createPipelineLayout(setLayout,&push);shader=backend.createShaderModule(readBinaryFile(shaderPath));pipeline=backend.createComputePipeline({shader,layout});
 auto dispatch=[&](rhi::ICommandRecorder& commands,unsigned phase){Push p{w,h,phase,count};commands.pushConstants(layout,VK_SHADER_STAGE_COMPUTE_BIT,0,&p,sizeof(p));commands.dispatch(((phase<2?n:count)+63)/64,1,1);};
 auto resultBarrier=[&](rhi::ICommandRecorder& commands){commands.bufferBarrier({results.buffer,0,results.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});};
 if(timing){VkQueryPoolCreateInfo q{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};q.queryType=VK_QUERY_TYPE_TIMESTAMP;q.queryCount=10;test::vkRequire(vkCreateQueryPool(host.device,&q,nullptr,&timestamps),"vkCreateQueryPool");}
 host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer raw){
  commands.bufferBarrier({ranges.buffer,0,ranges.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});
  commands.bufferBarrier({rectangles.buffer,0,rectangles.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT});
  commands.bindComputePipeline(pipeline);commands.bindComputeDescriptorSet(layout,set);
  if(timing){vkCmdResetQueryPool(raw,timestamps,0,10);vkCmdWriteTimestamp(raw,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,timestamps,8);}
  for(unsigned phase=0;phase<2;++phase){dispatch(commands,phase);commands.bufferBarrier({ranges.buffer,0,ranges.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});}
  if(timing){vkCmdWriteTimestamp(raw,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,timestamps,9);commands.bufferBarrier({ranges.buffer,0,ranges.size,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT});}
  dispatch(commands,2);dispatch(commands,3);
  commands.bufferBarrier({ranges.buffer,0,ranges.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
  commands.bufferBarrier({results.buffer,0,results.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
 });
 host.allocator.invalidate(ranges,0,ranges.size);host.allocator.invalidate(results,0,results.size);
 if(std::memcmp(ranges.mapped,expectedTable.data(),ranges.size)!=0)throw std::runtime_error("GPU range table differs from direct per-block oracle");
 const auto output=static_cast<const Result*>(results.mapped);std::uint64_t fast=0,reads=0,directReads=0;
 for(unsigned i=0;i<count;++i){auto q=queries[i];auto expected=direct(base,w,q);auto plan=makeShadowRangeQueryPlan(w,h,{q[0],q[1]},{q[2],q[3]});
  for(unsigned mode=0;mode<2;++mode){const auto& actual=output[i+mode*count];if(std::memcmp(&actual.bounds,&expected,sizeof(expected))!=0)throw std::runtime_error("GPU rectangle union differs from independent oracle");
   unsigned expectedCount=mode==0&&plan?plan->count:0,expectedLevel=mode==0&&plan?plan->level:0xffffffffu;
   if(actual.count!=expectedCount||actual.level!=expectedLevel)throw std::runtime_error("GPU plan metadata differs from CPU contract");}
  auto directCount=std::uint64_t(q[2]-q[0]+1)*(q[3]-q[1]+1);directReads+=directCount;reads+=plan?plan->count:directCount;fast+=bool(plan);
 }
 std::cout<<host.properties.deviceName<<" grid="<<w<<'x'<<h<<" queries="<<count<<" tablePairs="<<table.size()<<" fast="<<fast<<" reads="<<reads<<" directReads="<<directReads<<" validation="<<(!timing?"enabled":"disabled")<<'\n';
 if(timing){
  host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer raw){
   commands.bindComputePipeline(pipeline);commands.bindComputeDescriptorSet(layout,set);
   commands.bufferBarrier({results.buffer,0,results.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_READ_BIT,VK_ACCESS_SHADER_WRITE_BIT});
   for(unsigned i=0;i<2048;++i){dispatch(commands,i%2?2:3);resultBarrier(commands);}
   vkCmdResetQueryPool(raw,timestamps,0,8);const unsigned modes[]={3,2,2,3};
   for(unsigned block=0;block<4;++block){commands.bufferBarrier({results.buffer,0,results.size,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});vkCmdWriteTimestamp(raw,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,timestamps,block*2);
    for(unsigned i=0;i<64;++i){dispatch(commands,modes[block]);resultBarrier(commands);}
    vkCmdWriteTimestamp(raw,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,timestamps,block*2+1);}
  });
  std::array<std::uint64_t,10> ticks{};test::vkRequire(vkGetQueryPoolResults(host.device,timestamps,0,10,sizeof(ticks),ticks.data(),8,VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT),"vkGetQueryPoolResults");
  const auto mask=host.timestampBits==64?~std::uint64_t(0):(std::uint64_t(1)<<host.timestampBits)-1;
  std::cout<<"buildMilliseconds="<<double((ticks[9]-ticks[8])&mask)*host.properties.limits.timestampPeriod/1000000.0<<" additionalTableBytes="<<(ranges.size/3*2)<<'\n';
  for(unsigned i=0;i<4;++i)std::cout<<"timestampBlock="<<i<<" mode="<<(i==0||i==3?"direct":"table")<<" milliseconds="<<double((ticks[i*2+1]-ticks[i*2])&mask)*host.properties.limits.timestampPeriod/1000000.0<<" repeats=64\n";
 }
 cleanup.reset();if(host.errors.load())throw std::runtime_error("Vulkan validation error or warning");
}
int main(int argc,char** argv)try{
 if(argc<2||argc>3)throw std::invalid_argument("Expected shader and optional --timing");bool timing=argc==3&&std::string(argv[2])=="--timing";
 if(timing)run(argv[1],512,512,262144,true);
 else for(auto extent:{std::array<unsigned,2>{1,1},{7,9},{64,61},{512,512}})run(argv[1],extent[0],extent[1],extent[0]==512?262144:8192,false);
 return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
