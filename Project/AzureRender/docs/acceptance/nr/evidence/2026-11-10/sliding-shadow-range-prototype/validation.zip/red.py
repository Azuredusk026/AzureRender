from pathlib import Path
import subprocess,sys,os,json
r=Path.cwd();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'))
command=[str(r/'tools/msvc_env.bat'),'cl.exe','/nologo','/std:c++17','/EHsc','/Zs',str(o/'query_tests.cpp')]
result=subprocess.run(command,capture_output=True,text=True,errors='replace',timeout=30)
(o/'red.log').write_text(result.stdout+result.stderr)
assert result.returncode!=0 and 'shadow_range_query.hpp' in result.stdout+result.stderr
(o/'red.json').write_text(json.dumps(dict(status='expected-missing-interface-failure',exitCode=result.returncode,command=command),indent=2))
print('Expected missing query interface failure observed')
