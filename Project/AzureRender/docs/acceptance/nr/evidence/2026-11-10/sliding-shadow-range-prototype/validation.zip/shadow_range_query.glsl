#ifndef AZURE_SHADOW_RANGE_QUERY_GLSL
#define AZURE_SHADOW_RANGE_QUERY_GLSL
// Caller validates the three-plane dimensions and inclusive base-table rectangle.
bool azureShadowRangeQueryPlan(uvec2 extent,uvec2 low,uvec2 high,out uvec4 indices,out uint count,out uint level){
 indices=uvec4(0);count=0u;level=0u;uvec2 dimensions=high-low+1u;
 level=uint(min(findMSB(min(dimensions.x,dimensions.y)),2));uint side=1u<<level;
 if(any(greaterThan(dimensions,uvec2(side*2u))))return false;
 uvec2 last=high+1u-side;uint offset=level*extent.x*extent.y;
 uint columns=last.x==low.x?1u:2u,rows=last.y==low.y?1u:2u;
 for(uint y=0u;y<rows;++y)for(uint x=0u;x<columns;++x)
  indices[count++]=offset+(y==0u?low.y:last.y)*extent.x+(x==0u?low.x:last.x);
 return true;
}
#endif
