from pathlib import Path
import os,sys,json,subprocess,time
r=Path.cwd();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest
os.environ.update(managed_environment(o/'tmp'))
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
before=inputs(r);records=json.loads((o/'reference-build-options.json').read_text());rows=[]
compiler='D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe';shader=o/'query_test.comp.spv'
with (o/'shader-build.log').open('wb') as log:subprocess.run([compiler,'-I'+str(o),str(o/'query_test.comp'),'-o',str(shader)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe',str(shader)],check=True,timeout=15)
for row in records:
 config=row['config'];folder=o/config;folder.mkdir(exist_ok=True);build=Path(row['build']);object=folder/'gpu_tests.obj';executable=folder/'gpu_tests.exe'
 compile=['cl.exe',*row['compileOptions'],'/I'+str(r/'tests'),'/I'+str(o),'/c',str(o/'gpu_tests.cpp'),'/Fo'+str(object),'/Fd'+str(folder/'compile.pdb')]
 link=['link.exe',*row['linkOptions'],'/OUT:'+str(executable),'/PDB:'+str(folder/'gpu_tests.pdb'),str(object),*row['libraries']]
 start=time.monotonic()
 with (o/(config+'-gpu-build.log')).open('wb') as log:
  subprocess.run(compile,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
  subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
 rows.append(dict(config=config,seconds=time.monotonic()-start,compile=compile,link=link,executableSha256=digest(executable)))
assert inputs(r)==before
(o/'gpu-build-results.json').write_text(json.dumps(dict(rows=rows,shaderSha256=digest(shader),productionSourceUnchanged=True),indent=2));print('Private GPU fixture and both ABIs built',flush=True)
