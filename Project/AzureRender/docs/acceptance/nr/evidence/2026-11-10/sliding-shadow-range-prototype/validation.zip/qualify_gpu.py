from pathlib import Path
import os,sys,json,subprocess,time
r=Path.cwd();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest
os.environ.update(managed_environment(o/'tmp'))
for k in ['VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LOADER_DEBUG','VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(k,None)
before=inputs(r);private={str(p):digest(p) for p in [o/'gpu_tests.cpp',o/'private_fixture.hpp',o/'query_test.comp',o/'shadow_range_query.glsl',o/'shadow_range_query.hpp']}
subprocess.run([sys.executable,'-X','utf8','-B',str(o/'build_gpu.py')],check=True,timeout=180)
rows=[];initialPath=os.environ['PATH']
for config in ['release','debug']:
 os.environ['PATH']=str(r/('build/ninja-msvc-'+config))+';'+initialPath
 for device,selector in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  os.environ['VK_LOADER_DRIVERS_SELECT']=selector;log=o/(config+'-'+device+'-numeric.log');start=time.monotonic()
  with log.open('wb') as stream:subprocess.run([str(o/config/'gpu_tests.exe'),str(o/'query_test.comp.spv')],stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=120)
  s=log.read_text(errors='replace');assert s.count('validation=enabled')==4 and 'grid=512x512 queries=262144' in s and not any(x in s for x in ['VUID-','SYNC-HAZARD','Validation Error:','Validation Warning:'])
  assert ('Intel' if device=='intel' else 'NVIDIA') in s
  rows.append(dict(config=config,device=device,seconds=time.monotonic()-start,grids=4,queryModes=2,validationClean=True));print(s.strip(),flush=True)
assert inputs(r)==before and all(digest(Path(p))==v for p,v in private.items())
(o/'gpu-numeric-results.json').write_text(json.dumps(dict(status='passed',rows=rows,privateSourceFingerprints=private,productionSourceUnchanged=True),indent=2))
