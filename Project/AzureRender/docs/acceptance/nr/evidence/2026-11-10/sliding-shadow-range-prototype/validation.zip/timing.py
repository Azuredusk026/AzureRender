from pathlib import Path
import os,sys,json,subprocess,time,re
r=Path.cwd();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest
from gpu_environment import wait_and_record,RunEnvironmentMonitor
os.environ.update(managed_environment(o/'tmp'));os.environ['PATH']=str(r/'build/ninja-msvc-release')+';'+os.environ['PATH']
for k in ['VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LOADER_DEBUG','VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(k,None)
qualified=json.loads((o/'gpu-numeric-results.json').read_text());assert len(qualified['rows'])==4
assert all(digest(Path(p))==v for p,v in qualified['privateSourceFingerprints'].items())
before=inputs(r);wait_and_record(o/'timing-startup-environment.json',timeout=60);rows=[]
for device,selector in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 os.environ['VK_LOADER_DRIVERS_SELECT']=selector;log=o/(device+'-timing.log');environment={};start=time.monotonic()
 with RunEnvironmentMonitor(environment,path=o/(device+'-timing-environment.json'),interval=2):
  with log.open('wb') as stream:subprocess.run([str(o/'release/gpu_tests.exe'),str(o/'query_test.comp.spv'),'--timing'],stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=120)
 s=log.read_text(errors='replace');assert 'validation=disabled' in s and not any(x in s for x in ['VUID-','SYNC-HAZARD','Validation Error:','Validation Warning:'])
 blocks=[dict(block=int(a),mode=b,milliseconds=float(c),repeats=int(d)) for a,b,c,d in re.findall(r'timestampBlock=(\d+) mode=(\w+) milliseconds=([0-9.e+-]+) repeats=(\d+)',s)]
 assert len(blocks)==4 and all(b['repeats']==64 for b in blocks)
 direct=[v['milliseconds'] for v in blocks if v['mode']=='direct'];table=[v['milliseconds'] for v in blocks if v['mode']=='table'];reference=sum(direct)/2;candidate=sum(table)/2
 build=float(re.search(r'buildMilliseconds=([0-9.e+-]+)',s)[1]);extra=int(re.search(r'additionalTableBytes=(\d+)',s)[1])
 rows.append(dict(device=device,seconds=time.monotonic()-start,blocks=blocks,queriesPerDispatch=262144,buildMilliseconds=build,additionalTableBytes=extra,referenceMillisecondsPerDispatch=reference/64,tableMillisecondsPerDispatch=candidate/64,queryReduction=1-candidate/reference,referenceDrift=abs(direct[0]-direct[-1])/reference,validationEnabled=False))
 print(s.strip(),flush=True)
assert inputs(r)==before and all(digest(Path(p))==v for p,v in qualified['privateSourceFingerprints'].items())
(o/'timing-results.json').write_text(json.dumps(dict(status='isolated-query-timing-recorded',rows=rows,productionSourceUnchanged=True,nativeOptimizationAdmitted=False),indent=2))
