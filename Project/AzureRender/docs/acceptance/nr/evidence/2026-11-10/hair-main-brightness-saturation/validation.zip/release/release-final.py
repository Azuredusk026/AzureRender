from pathlib import Path
import subprocess,json,sys
out=Path(__file__).resolve().parent;root=out.parents[2];main=Path('D:/Projects/FYP/Project/AzureRender');cmake='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe';build=out/'release'
command='"'+str(main/'tools/msvc_env.bat')+'" "'+cmake+'" --build '+str(build)+' --target AzureCharacterRepairTests --parallel 4'
with (out/'release-final-contract-build.log').open('wb') as log:r=subprocess.run(command,shell=True,cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
with (out/'release-final-contract.log').open('wb') as log:r=subprocess.run([str(build/'AzureCharacterRepairTests.exe'),str(root/'assets_public/third_person/material_fixture.gltf')],cwd=build,stdout=log,stderr=subprocess.STDOUT)
(out/'release-final-contract.json').write_text(json.dumps(dict(exitCode=r.returncode,command=command),indent=2));assert r.returncode==0
for script,args in [('material-gpu.py',['nvidia']),('default-four.py',[])]:subprocess.run([sys.executable,str(out/script),*args],check=True)
print('Final Release contract, public material images and original four frames passed')
