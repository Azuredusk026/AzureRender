from pathlib import Path
import subprocess,json,os,re,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];build=out/'release';rows=[]
for label,args,selection in [('material-contract',[str(build/'AzureCharacterRepairTests.exe'),str(root/'assets_public/third_person/material_fixture.gltf')],None),('nvidia-surface',[str(build/'AzureSurfaceResponseGpuTests.exe'),str(build/'shaders/surface_response_test.comp.spv'),str(root/'assets_public/showcase_looks.json')],'*nv-vk64*'),('intel-surface',[str(build/'AzureSurfaceResponseGpuTests.exe'),str(build/'shaders/surface_response_test.comp.spv'),str(root/'assets_public/showcase_looks.json')],'*igvk64*')]:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 if selection:env['VK_LOADER_DRIVERS_SELECT']=selection
 env.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(args,cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(out/(label+'.log')).read_text(errors='replace');row=dict(name=label,exitCode=r.returncode,command=args,validationErrors=bool(re.search(r'VUID-|Validation Error|Validation Warning',text)));rows.append(row);(out/'initial-checks.json').write_text(json.dumps(rows,indent=2))
 assert r.returncode==0 and not row['validationErrors'],text[-4000:]
 if selection:assert len(re.findall(r'Surface probe \d+:',text))==317;row['effectiveProbes']=317
(out/'initial-checks.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2))
