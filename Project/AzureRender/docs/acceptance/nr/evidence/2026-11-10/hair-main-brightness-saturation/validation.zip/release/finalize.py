from pathlib import Path
import json,hashlib,zipfile,subprocess
out=Path(__file__).resolve().parent;root=out.parents[2];debug=out.parent/'20261110-031856-hair-main-chroma-debug-668bf2';configurations={}
for name,folder,build in [('Release',out,out/'release'),('Debug',debug,debug/'debug')]:
 checks=json.loads((folder/'initial-checks.json').read_text());assert all(x['exitCode']==0 and not x['validationErrors'] for x in checks);assert all(x.get('effectiveProbes')==317 for x in checks if 'surface' in x['name'])
 images={}
 for device in ['nvidia','intel']:
  report=json.loads((folder/(device+'-material-chroma-controlled/summary.json')).read_text());assert report['status']=='passed' and len(report['captures'])==7;assert all(c['maximumLinearError']<=.008 for c in report['captures']);images[device]=report
 configurations[name]=dict(checks=checks,materialImages=images,playerSha256=hashlib.sha256((build/'AzurePlayer.exe').read_bytes()).hexdigest())
four=json.loads((out/'default-four-results.json').read_text());assert four['allExact'];assert json.loads((out/'release-final-contract.json').read_text())['exitCode']==0
r=dict(status='public-main-brightness-saturation-qualified',overallVisualAcceptance='failed-user-review',productionHairColorPassed=False,privateSelectedMainRemainingFailures=14,layoutVersion=22,configurations=configurations,defaultFourFrames=four,converterTests=27,scope='Public opt-in selected-main chroma operation; original full native color, current depth producer and remaining sampling/storage differences retain separate gates.')
sourceNames=subprocess.check_output(['git','diff','--name-only'],cwd=root.parents[1],text=True).splitlines();members={}
for n in sourceNames:
 p=root.parents[1]/n
 if p.is_file():members['source/'+n]=p.read_bytes()
for label,folder in [('release',out),('debug',debug)]:
 for p in folder.iterdir():
  if p.is_file() and p.suffix in ['.py','.json','.log','.txt']:members[label+'/'+p.name]=p.read_bytes()
 for pattern in ['*-material-chroma-controlled','*-material-chroma-qualified','*-local-control','intel-direct-shadow-probe']:
  for base in folder.glob(pattern):
   for p in base.rglob('*'):
    if p.is_file() and p.suffix in ['.png','.json','.gltf','.azurelevel','.azureproject','.log']:members[label+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
members['source/Project/AzureRender/docs/acceptance/nr/hair-main-brightness-saturation.md']=(root/'docs/acceptance/nr/hair-main-brightness-saturation.md').read_bytes()
patch=subprocess.check_output(['git','diff','--binary'],cwd=root.parents[1]);members['source.patch']=patch
r['sourceFiles']=[dict(path=n,sha256=hashlib.sha256(v).hexdigest(),bytes=len(v)) for n,v in members.items() if n.startswith('source/')]
dest=root/'docs/acceptance/nr/evidence/2026-11-10/hair-main-brightness-saturation';dest.mkdir(parents=True,exist_ok=True);members['results-before-archive.json']=(json.dumps(r,indent=2)+'\n').encode()
with zipfile.ZipFile(dest/'validation.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in members.items():z.writestr(n,b)
b=(dest/'validation.zip').read_bytes();assert len(b)<8*1024*1024;r.update(archiveBytes=len(b),archiveSha256=hashlib.sha256(b).hexdigest(),archiveFiles=[dict(path=n,bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for n,v in members.items()]);(dest/'results.json').write_text(json.dumps(r,indent=2)+'\n');z=zipfile.ZipFile(dest/'validation.zip');assert z.testzip() is None
for item in r['archiveFiles']:b=z.read(item['path']);assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
print('Qualified archive',r['archiveBytes'],r['archiveSha256'],len(r['archiveFiles']))
