from pathlib import Path
import subprocess,sys,os,json
out=Path(__file__).resolve().parent;root=out.parents[2];device=sys.argv[1];selection=sys.argv[2] if len(sys.argv)>2 else None;folder=out/(device+('-local-control' if selection else '-material-chroma-controlled'));env=os.environ.copy()
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
cmd=[sys.executable,str(root/'tools/test_projected_hair_lighting_gpu.py'),'--executable',str(out/'debug/AzurePlayer.exe'),'--output',str(folder),'--main-brightness-saturation']
if selection:cmd+=['--case',selection]
(out/(device+('-control-command.json' if selection else '-controlled-material-command.json'))).write_text(json.dumps(cmd,indent=2))
with (out/(device+'-controlled-material-chroma.log')).open('wb') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
if r.returncode:print((out/(device+'-controlled-material-chroma.log')).read_text(errors='replace')[-4000:])
raise SystemExit(r.returncode)
