from pathlib import Path
import subprocess,json,sys
out=Path(__file__).resolve().parent;root=out.parents[2];main=Path('D:/Projects/FYP/Project/AzureRender');cmake='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe';ninja='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe';build=out/'debug';commands=[['"'+cmake+'"','-S',str(root),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_MAKE_PROGRAM='+ninja,'-DCMAKE_TOOLCHAIN_FILE=D:/Tools/vcpkg/scripts/buildsystems/vcpkg.cmake','-DVCPKG_INSTALLED_DIR='+str(main/'build/ninja-msvc-debug/vcpkg_installed'),'-DVCPKG_MANIFEST_INSTALL=OFF','-DBUILD_TESTING=ON','"-DCMAKE_EXE_LINKER_FLAGS_DEBUG=/DEBUG /INCREMENTAL:NO"'],['"'+cmake+'"','--build',str(build),'--target','AzureCharacterRepairTests','AzureSurfaceResponseGpuTests','AzurePlayer','--parallel','4']]
(out/'debug-build-commands.json').write_text(json.dumps(commands,indent=2))
with (out/'debug-build.log').open('wb') as log:
 for args in commands:
  command='"'+str(main/'tools/msvc_env.bat')+'" '+' '.join(args);r=subprocess.run(command,cwd=root,shell=True,stdout=log,stderr=subprocess.STDOUT)
  if r.returncode:raise SystemExit(r.returncode)
print('Independent Debug targets compiled')
