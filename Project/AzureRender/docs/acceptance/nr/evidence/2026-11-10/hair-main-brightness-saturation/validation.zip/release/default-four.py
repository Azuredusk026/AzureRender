from pathlib import Path
import subprocess,json,hashlib,re,numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;build=out/'release';frames=out/'default-four-frames';project=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject');cmd=[str(build/'AzurePlayer.exe'),'--project',str(project),'--width','2560','--height','1440','--qa-camera','scene','--qa-light','scene','--capture-frames','4','--capture-fps','24','--fixed-frame-step','--capture-dir',str(frames),'--runtime-report',str(out/'default-runtime.json'),'--resource-root',str(build)]
(out/'default-four-command.json').write_text(json.dumps(cmd,indent=2))
with (out/'default-four.log').open('wb') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
text=(out/'default-four.log').read_text(errors='replace');assert r.returncode==0 and not re.search(r'VUID-|Validation (?:Error|Warning)|\[error\]',text),text[-3000:];assert 'Allocator after unload: buffers=0 images=0' in text
expected=['4faf27a0d379b247e9a0a98d77dd8a8c2622ad689dc914428ca8df7944b79387','55678cd9b32fb282416bb975ead40e01c7a66042b93d8a4ff6f75da29dc3a2ab','ecee0ff56e78afd0447c1704224b1aabcb16f73bac624d0ce69e27a1e4f33d79','1eb14b1cce256811991cb04971dd86d7bb2eda455d127e0e4667c258921a6574'];rows=[]
for i,wanted in enumerate(expected):
 p=frames/f'frame_{i:06d}.png';digest=hashlib.sha256(p.read_bytes()).hexdigest();rows.append(dict(frame=p.name,sha256=digest,expectedSha256=wanted,pngExact=digest==wanted))
report=dict(exitCode=r.returncode,frames=rows,validationClean=True,allocatorZero=True,allExact=all(x['pngExact'] for x in rows));(out/'default-four-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['allExact']
