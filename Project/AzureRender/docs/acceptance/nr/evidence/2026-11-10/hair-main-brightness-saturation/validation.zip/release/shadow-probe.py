from pathlib import Path
import subprocess,os,json,numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;env=os.environ.copy()
for k in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:env.pop(k,None)
env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1');folder=out/'intel-direct-shadow-probe';cmd=[str(out/'release/AzurePlayer.exe'),'--project',str(out/'intel-material-chroma-qualified/direct/test.azureproject'),'--width','128','--height','128','--capture-dir',str(folder),'--capture-frames','1','--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','shadow-visibility'];(out/'intel-shadow-command.json').write_text(json.dumps(cmd,indent=2))
with (out/'intel-shadow.log').open('wb') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0;(out/'intel-shadow-execution.json').write_text(json.dumps(dict(exitCode=r.returncode)));p=np.array(Image.open(folder/'frame_000000.png').convert('RGB'));print('Actual shadow samples',[(x,y,p[y,x].tolist()) for x,y in [(45,64),(45,65),(46,64),(47,62),(43,64)]])
