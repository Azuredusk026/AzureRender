from pathlib import Path
import json,hashlib,zipfile,re
out=Path(__file__).parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();dest=root/'docs/acceptance/nr/evidence/2026-11-10/depth-interpolant-source';dest.mkdir(parents=True,exist_ok=True)
files={'run/'+p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and p.suffix in {'.py','.json','.log','.vert','.frag','.spv','.bin','.zlib'} and p.stat().st_size<2*1024*1024};doc=root/'docs/acceptance/nr/depth-interpolant-source.md';files['source/depth-interpolant-source.md']=doc
members={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()};archive=dest/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<8*1024*1024
r=json.loads((out/'results.json').read_text());r.update(archive={'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members)+1});(dest/'results.json').write_text(json.dumps(r,indent=2)+'\n')
for link in re.findall(r'\]\(([^)]+)\)',doc.read_text(encoding='utf-8')):assert (doc.parent/link).exists(),link
print(json.dumps(r['archive']))
