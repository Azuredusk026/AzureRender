#version 450
#extension GL_GOOGLE_include_directive : require
#include "material_uv_gradients.glsl"
#include "texture_footprint.glsl"
layout(location=0) in vec2 textureCoordinate;
layout(location=1) noperspective in float linearDepth;
layout(location=2) in float projectedZ;
layout(binding=0) uniform sampler2D alphaMask;
layout(push_constant) uniform Projection {vec4 columns[4];vec4 jitter;uvec4 control;vec4 coverage;} projection;
layout(location=0) out float diagnosticValue;
void main(){
    mat2 g=azureMirroredCoarseUvGradients(textureCoordinate);
    vec2 size=vec2(textureSize(alphaMask,0));
    float lod=azureEllipseMajorAxisLod(g[0]*size,g[1]*size)+projection.coverage.y;
    if(textureLod(alphaMask,textureCoordinate,lod).r<projection.coverage.x)discard;
    diagnosticValue=vec4(gl_FragCoord.z,linearDepth,projectedZ*gl_FragCoord.w,gl_FragCoord.w)[projection.control.y];
}
