from pathlib import Path
import os,subprocess,json,re,hashlib,numpy as np,zlib
out=Path(__file__).parent;prior=out.parent/'20261110-211719-alpha-ellipse-lod-5c69d6';exe=prior/'native-coverage.exe';build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release';calibration=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7';config=json.loads((out/'config.json').read_text());q=np.fromfile(config['queries'],dtype='<f4').reshape(-1,4).astype(int);rows=[]
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(build)+';'+env['PATH'])
 for channel in range(4):
  config['channel']=channel;path=out/f'{device}-{channel}-config.json';path.write_text(json.dumps(config,indent=2)+'\n');prefix=out/f'{device}-{channel}'
  with (out/f'{device}-{channel}.log').open('wb') as log:r=subprocess.run([str(exe),str(out/'shaders'),str(path),str(prefix)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=45)
  text=(out/f'{device}-{channel}.log').read_text(errors='replace');assert r.returncode==0 and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I),text[-2500:]
  raw=Path(str(prefix)+'-r32.bin');plane=raw.read_bytes();selected=np.frombuffer(plane,dtype='<f4').reshape(1440,2560)[q[:,1],q[:,0]].copy();selected.tofile(out/f'{device}-{channel}-selected.bin');assert np.isfinite(selected).all()
  d32=np.fromfile(str(prefix)+'-selected-d32.bin',dtype='<u4');control=np.fromfile(prior/f'{device}-public-selected-d32.bin',dtype='<u4');assert np.array_equal(d32,control),(device,channel,'D32 identity failed')
  if channel==0:assert np.array_equal(selected.view('u4'),control),(device,'R32 identity failed')
  row={'device':device,'channel':channel,'d32ControlExact':True,'planeSha256':hashlib.sha256(plane).hexdigest()}
  if channel<3:
   cfg=json.loads((calibration/'hair-calibration.json').read_text());cfg.update(depth=str(raw),scope=f'route{channel}');cfgpath=out/f'{device}-{channel}-visibility.json';cfgpath.write_text(json.dumps(cfg,indent=2)+'\n')
   with (out/f'{device}-{channel}-visibility.log').open('wb') as log:r=subprocess.run([str(calibration/'calibration.exe'),str(cfgpath),str(calibration)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=45)
   result=json.loads((out/f'{device}-route{channel}-result.json').read_text());assert result['zeroAllocator'] and result['validationErrors']==0;row['visibility']=result
  compressed=raw.with_suffix('.zlib');packed=zlib.compress(plane,9);compressed.write_bytes(packed);assert zlib.decompress(packed)==plane;raw.unlink();rows.append(row);(out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(device,channel,'identity controlled',row.get('visibility',{}).get('withinOnePixels'),flush=True)
