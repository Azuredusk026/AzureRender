from pathlib import Path
import json,numpy as np
out=Path(__file__).parent;config=json.loads((out/'config.json').read_text());q=np.fromfile(config['queries'],dtype='<f4').reshape(-1,4).astype(int);native=np.fromfile('D:/Projects/FYP/Project/AzureRender/build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/native-t0.bin',dtype='<f4').reshape(1440,2560)[q[:,1],q[:,0]];rows=[]
for row in json.loads((out/'runs.json').read_text()):
 device=row['device'];channel=row['channel'];a=np.fromfile(out/f'{device}-{channel}-selected.bin',dtype='<f4');b=np.fromfile(out/f'{device}-0-selected.bin',dtype='<f4')
 result={k:v for k,v in row.items() if k!='visibility'};result.update(route=['hardwareDepth','noperspectiveZOverW','smoothZTimesReciprocalW','fragmentReciprocalW'][channel],pixels=len(a),hardwareDepthExact=int((a.view('u4')==b.view('u4')).sum()))
 if channel<3:
  ulp=abs(a.view('u4').astype('i8')-native.view('u4').astype('i8'));result.update(nativeDepthExact=int((ulp==0).sum()),nativeDepthWithinOneUlp=int((ulp<=1).sum()),visibilityFailures=17017-row['visibility']['withinOnePixels'],maximumByteError=row['visibility']['maximumByteError'])
 rows.append(result)
r={'status':'qualified-source-control-attribute-candidates-isolated','overall':'failed-user-review','sourceCommit':'3990a03','observations':rows,'execution':json.loads((out/'candidate-execution.json').read_text()),'publicSourceUnchanged':True,'remainingIntelFailures':96,'next':'Scene binding and independent native quality units; interpolation retry requires new fixed-function precision evidence'};(out/'results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(rows,indent=2))
