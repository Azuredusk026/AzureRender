from pathlib import Path
import subprocess,json,os,sys
root=Path.cwd();out=root/'build/runs/20261110-204800-gpu-power-limit-qualification-4930ec';sys.path.insert(0,str(root/'tools'));from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));rows=[]
for name,command in [('before',['nvidia-smi','-q','-d','POWER']),('request-80w',['nvidia-smi','-i','0','-pl','80']),('after',['nvidia-smi','-q','-d','POWER'])]:
 p=subprocess.run(command,capture_output=True,text=True,timeout=15);(out/(name+'.log')).write_text(p.stdout+p.stderr);rows.append(dict(name=name,command=command,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
(out/'qualification.json').write_text(json.dumps(rows,indent=2));print(json.dumps([dict(name=x['name'],returncode=x['returncode'],output=x['stdout'] if x['name']=='request-80w' else '') for x in rows],indent=2))
