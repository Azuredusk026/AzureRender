from pathlib import Path
import json,os,subprocess,sys,shutil,time,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,verify,digest
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
before=inputs(root);checks=[]
targets=['AzureReferenceClipProjectionGpuTests','AzureReferenceDepthGpuTests','AzureReferenceDepthCoverageGpuTests','AzureHotReloadTests','AzureShaderCompilerContractTests']
selector=r'^(AzureRender\.(ReferenceClipProjectionGpu|ReferenceDepthGpu|ReferenceDepthCoverageGpu|ShaderCompilerContract|ShaderCatalogCompilation|HotReload)|AzureEngine\.(ModuleBoundaries|ModuleBoundaryFixtures))$'
for config in ['Release','Debug']:
 build=root/('build/ninja-msvc-'+config.lower());command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
 for target in targets:command+=['--test-target',target]
 start=time.monotonic()
 with (out/(config.lower()+'-build.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 baseline=json.loads((out/'baseline-products.json').read_text())[config.lower()]['shaders'];manifest=json.loads((build/'shader-reload.json').read_text());assert len(manifest['programs'])==688
 assert all(digest(build/'shaders'/name)==sha for name,sha in baseline.items())
 assert digest(build/'shaders/reference_depth_ellipse.frag.spv')=="b14e7955b56975f2a4d2c247580b745c6b7a1d238c22cb4213f76288bff7c3a0"
 shutil.copyfile(build/'build-provenance.json',out/(config.lower()+'-build-provenance.json'))
 command=['ctest','--test-dir',str(build),'-C',config,'--output-on-failure','--no-tests=error','-R',selector,'--output-junit',str(out/(config.lower()+'-tests.xml'))]
 with (out/(config.lower()+'-tests.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=360)
 cases=ET.parse(out/(config.lower()+'-tests.xml')).findall('.//testcase');assert len(cases)==8 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
 checks.append(dict(config=config,tests=len(cases),skips=0,seconds=time.monotonic()-start));print(json.dumps(checks[-1]),flush=True)
 verify(root,json.loads((build/'build-provenance.json').read_text()))
 for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  os.environ['VK_LOADER_DRIVERS_SELECT']=driver
  with (out/(config.lower()+'-'+device+'-projection.log')).open('wb') as log:subprocess.run([str(build/'AzureReferenceClipProjectionGpuTests.exe'),str(build/'shaders/reference_clip_projection_test.comp.spv'),str(out/'native-profile.bin'),str(out/'native-records.bin')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
  text=(out/(config.lower()+'-'+device+'-projection.log')).read_text(errors='replace');assert ('Intel' if device=='intel' else 'NVIDIA') in text and '19756 points / 79024 exact clip components' in text and not any(x in text for x in ['VUID-','SYNC-HAZARD','Validation Error:','Validation Warning:'])
 for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  os.environ['VK_LOADER_DRIVERS_SELECT']=driver
  for target,expected in [('AzureReferenceDepthGpuTests','73920 exact R32/D32 values'),('AzureReferenceDepthCoverageGpuTests','10496 exact masked R32/D32 values')]:
   with (out/(config.lower()+'-'+device+'-'+target+'.log')).open('wb') as log:subprocess.run([str(build/(target+'.exe')),str(build/'shaders')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
   text=(out/(config.lower()+'-'+device+'-'+target+'.log')).read_text(errors='replace');assert expected in text and not any(x in text for x in ['VUID-','SYNC-HAZARD','Validation Error:','Validation Warning:']),text
 os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
assert inputs(root)==before

(out/'build-results.json').write_text(json.dumps(dict(checks=checks,sourceUnchanged=True,projectionPointsPerBatch=19756,fullNativeGpuComponents=316096,depthAndCoverageGpuValues=337664,oldProgramIdentitiesPerConfiguration=687,activeProgramCount=688),indent=2))
print('Both actual host builds and 16 focused checks passed')
