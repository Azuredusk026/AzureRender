from pathlib import Path
import json
out=Path(__file__).parent;old=out.parent/'20261110-183305-intel-depth-alpha-footprint-e32993'
for name in ['native-synthetic.cpp','private-compute-fixture.hpp']:(out/name).write_bytes((old/name).read_bytes())
source=(old/'native-coverage.cpp').read_text().replace('ReferenceDepthShaders::loadMasked(argv[1])','ReferenceDepthShaders::loadEllipseMasked(argv[1],queryMaterialUvGradientSupport(host.physical))').replace('ReferenceDepthGpu producer(backend,','geometry.surface.schemaVersion=2;geometry.surface.alpha->lodPolicy=ReferenceDepthAlphaLodPolicy::EllipseMajorAxisMirroredCoarseY;\n        ReferenceDepthGpu producer(backend,')
(out/'native-coverage.cpp').write_text(source)
commands=[c.replace(str(old),str(out)).replace(old.as_posix(),out.as_posix()) for c in json.loads((old/'attribute-build-commands.json').read_text())];(out/'public-native-build-commands.json').write_text(json.dumps(commands,indent=2)+'\n');(out/'native-link').mkdir(exist_ok=True)
source=(out/'candidate.py').read_text().replace("str(out.parent/'20261110-183305-intel-depth-alpha-footprint-e32993/native-coverage.exe')","str(out/'native-coverage.exe')").replace("str(out/'candidate-shaders')","str(build/'shaders')").replace("device+'-candidate'","device+'-public'").replace("device+'-candidate-depth.log'","device+'-public-depth.log'").replace("scope='ellipse'","scope='public'").replace("device+'-ellipse-result.json'","device+'-public-result.json'").replace("out/'candidate-results.json'","out/'public-native-results.json'")
(out/'run-public-native.py').write_text(source)
four=out.parent/'20261110-154308-reference-clip-projection-public-07ee1e/default-four.py';(out/'default-four.py').write_bytes(four.read_bytes())
source=(out/'queued-build.py').read_text().replace("str(out/'batch.py')","str(out/'public-batch.py')").replace('2100','480');(out/'queued-public.py').write_text(source)
