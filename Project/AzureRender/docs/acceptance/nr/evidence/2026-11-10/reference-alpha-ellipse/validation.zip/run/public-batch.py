from pathlib import Path
import subprocess,json,sys,zlib,hashlib,os
out=Path(__file__).parent;build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
compaction=[]
for device in ['nvidia','intel']:
 p=out/f'{device}-candidate-r32.bin';data=p.read_bytes();packed=zlib.compress(data,9);compressed=p.with_suffix('.zlib');compressed.write_bytes(packed);assert zlib.decompress(packed)==data;compaction.append({'path':str(p),'sha256':hashlib.sha256(data).hexdigest(),'compressedBytes':len(packed)});p.unlink()
(out/'private-plane-compaction.json').write_text(json.dumps(compaction,indent=2)+'\n')
with (out/'public-native-build.log').open('wb') as log:
 for command in json.loads((out/'public-native-build-commands.json').read_text()):
  r=subprocess.run('D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat '+command,cwd=build,shell=True,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  assert r.returncode==0,'Native fixture build failed; see public-native-build.log'
r=subprocess.run([sys.executable,str(out/'run-public-native.py')]);assert r.returncode==0
env=os.environ.copy();env.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1');r=subprocess.run([sys.executable,str(out/'default-four.py')],env=env,timeout=180);assert r.returncode==0
