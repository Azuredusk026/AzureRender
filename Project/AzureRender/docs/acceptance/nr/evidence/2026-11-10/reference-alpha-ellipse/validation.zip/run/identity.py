from pathlib import Path
import subprocess,json,hashlib
out=Path(__file__).parent;runs=out.parent;rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for config,folder in [('release','20261110-030251-hair-main-chroma-public-9e799c/release'),('debug','20261110-031856-hair-main-chroma-debug-668bf2/debug')]:
 build=runs/folder;catalog=json.loads((build/'shader-reload.json').read_text());assert len(catalog['programs'])==687
 programs={p['output']:sha(build/'shaders'/p['output']) for p in catalog['programs']};(out/(config+'-all-program-sha256.json')).write_text(json.dumps(programs,indent=2)+'\n')
 for name in ['reference_depth.vert.spv','reference_depth.frag.spv','reference_depth_masked.vert.spv','reference_depth_masked.frag.spv']:(out/(config+'-'+name)).write_bytes((build/'shaders'/name).read_bytes())
 command=['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe','--test-dir',str(build),'--show-only=json-v1','-R','^AzureRender.ReferenceDepthGpu$'];r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0
 value=json.loads(r.stdout);assert len(value['tests'])==1;properties={p['name']:p['value'] for p in value['tests'][0]['properties']};assert properties['RUN_SERIAL'] and properties['TIMEOUT']==120 and properties['LABELS']==['gpu'];(out/(config+'-ctest-registration.json')).write_text(json.dumps(value,indent=2)+'\n')
 rows.append({'configuration':config,'playerSha256':sha(build/'AzurePlayer.exe'),'totalPrograms':len(programs),'testSha256':sha(build/'AzureReferenceDepthGpuTests.exe'),'serialGpuRegistration':True})
(out/'program-identity.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows)
