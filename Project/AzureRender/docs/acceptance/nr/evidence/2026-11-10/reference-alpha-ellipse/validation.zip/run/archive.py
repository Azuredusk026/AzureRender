from pathlib import Path
import json,hashlib,zipfile,re
out=Path(__file__).parent;root=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=out/'results.json';private=json.loads(p.read_text());private['status']='qualified-alpha-candidate-depth-differences-retained';p.write_text(json.dumps(private,indent=2)+'\n')
files={'run/'+p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and p.suffix in {'.py','.json','.log','.frag','.spv','.bin','.hpp','.cpp','.zlib'} and p.stat().st_size<2*1024*1024}
sources=['CMakeLists.txt','src/render/ReferenceDepth.hpp','src/render/ReferenceDepth.cpp','shaders/reference_depth.frag','shaders/texture_footprint.glsl','tests/ReferenceDepthCoverageGpuTests.cpp','docs/runtime/reference-depth.md','docs/plans/2026-11-10-reference-alpha-ellipse.md','docs/acceptance/nr/reference-alpha-ellipse.md']
files.update({'source/'+name:root/name for name in sources})
config=json.loads((out/'candidate-config.json').read_text());inputNames=['positions','indices','profile','uv','queries']
files.update({'inputs/'+name+'.bin':Path(config[name]) for name in inputNames});files.update({'inputs/alpha-mip'+str(i)+'.bin':Path(name) for i,name in enumerate(config['mips'])})
dest=root/'docs/acceptance/nr/evidence/2026-11-10/reference-alpha-ellipse';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(members,ensure_ascii=False,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<=8*1024*1024
r=json.loads((out/'public-results.json').read_text());r.update(archive={'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members)+1});(dest/'results.json').write_text(json.dumps(r,indent=2)+'\n')
for name in [n for n in sources if n.endswith('.md')]:
 p=root/name
 for link in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if not link.startswith('https://'):assert (p.parent/link).exists(),(name,link)
 text=p.read_text(encoding='utf-8')
 for sentence in re.split('[。！？\n]',text):assert len(re.findall('[\u4e00-\u9fff]',sentence))<=45,(name,sentence)
print(json.dumps(r['archive']))
