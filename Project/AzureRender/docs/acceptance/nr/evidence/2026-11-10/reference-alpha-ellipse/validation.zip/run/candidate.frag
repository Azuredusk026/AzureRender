#version 450
#extension GL_GOOGLE_include_directive : require
#include "material_uv_gradients.glsl"
layout(location=0) in vec2 textureCoordinate;
layout(binding=0) uniform sampler2D alphaMask;
layout(push_constant) uniform Projection {vec4 columns[4];vec4 jitter;uvec4 control;vec4 coverage;} projection;
layout(location=0) out float surfaceDepth;
void main(){
    mat2 gradients=azureMirroredCoarseUvGradients(textureCoordinate);
    vec2 size=vec2(textureSize(alphaMask,0));
    precise vec2 dx=gradients[0]*size;
    precise vec2 dy=gradients[1]*size;
    precise float a=dot(dx,dx),b=dot(dx,dy),c=dot(dy,dy);
    precise float rho2=0.5*(a+c+sqrt((a-c)*(a-c)+4.0*b*b));
    float lod=0.5*log2(max(rho2,1.17549435e-38))+projection.coverage.y;
    if(textureLod(alphaMask,textureCoordinate,lod)[projection.control.y]<projection.coverage.x)discard;
    surfaceDepth=gl_FragCoord.z;
}
