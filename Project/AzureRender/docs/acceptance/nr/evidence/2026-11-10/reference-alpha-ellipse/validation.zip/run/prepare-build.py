from pathlib import Path
import sys,json
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
p=Path('D:/Projects/FYP-coordination/quality-claim.json');v=json.loads(p.read_text(encoding='utf-8'));out=Path(__file__).parent;root=out.parents[2]
v['localInputLease'].append(s.acquire_inputs(root/'build',out,['20261110-031856-hair-main-chroma-debug-668bf2'],v['threadId']))
v['inputLease'].append(s.acquire_inputs(s.DEFAULT_BUILD,out,['20261103-234012-character-reference-stages-5abe6c'],v['threadId']))
v.update(state='ellipse-alpha-public-implementation',pendingCommand='dual-configuration-build-and-gpu-contract',ownedFiles=['src/render/ReferenceDepth.hpp','src/render/ReferenceDepth.cpp','shaders/reference_depth.frag','shaders/texture_footprint.glsl','tests/ReferenceDepthCoverageGpuTests.cpp','CMakeLists.txt','docs/plans/2026-11-10-reference-alpha-ellipse.md'])
p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ['20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2']:s.maintenance.resume(root/'build',name)
old=out.parent/'20261110-173835-reference-depth-coverage-4b4afc';(out/'build.py').write_bytes((old/'build.py').read_bytes());(out/'batch.py').write_text((old/'batch.py').read_text().replace('6272 exact masked R32/D32 values','10496 exact masked R32/D32 values').replace("'tests/ReferenceDepthCoverageGpuTests.cpp'","'tests/ReferenceDepthCoverageGpuTests.cpp','shaders/texture_footprint.glsl'"));(out/'queued-build.py').write_bytes((old/'queued.py').read_bytes())
