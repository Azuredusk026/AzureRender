from pathlib import Path
import json,re,subprocess,shutil,struct
out=Path(__file__).resolve().parent;prior=out.parent/'20261109-221435-hair-color-closure-430845'
report=json.loads((out.parent/'20261110-005429-hair-interpolated-basis-afd897/results.json').read_text())
points=report['qualification']['points'];rows={(r['field'],tuple(r['pixel'])):r for r in report['rows']}
source=(prior/'native-visibility.spvasm').read_text();sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
shutil.copyfile(prior/'native-visibility.spv',out/'control.spv');shutil.copyfile(prior/'native-visibility.spvasm',out/'control.spvasm')
for mode,fields in [('identity',['normal','tangent']),('normal',['normal']),('tangent',['tangent']),('both',['normal','tangent'])]:
 text=source;decl=[];init=[]
 def type_id(pattern,declaration,name):
  match=re.search(r'(%\S+) = '+pattern+r'\n',text)
  if match:return match[1]
  identifier='%basis_'+name;decl.append(identifier+' = '+declaration);return identifier
 b3=type_id('OpTypeVector %bool 3','OpTypeVector %bool 3','b3')
 b4=type_id('OpTypeVector %bool 4','OpTypeVector %bool 4','b4')
 u3=type_id('OpTypeVector %uint 3','OpTypeVector %uint 3','u3')
 u4=type_id('OpTypeVector %uint 4','OpTypeVector %uint 4','u4')
 for field in fields:
  n=3 if field=='normal' else 4;vtype=f'%v{n}float';original='%worldNormal_0' if field=='normal' else '%worldTangent'
  ptr=type_id('OpTypePointer Private '+vtype,'OpTypePointer Private '+vtype,field+'Pointer')
  storage='%basis_'+field+'Storage';decl.append(storage+' = OpVariable '+ptr+' Private')
  # Redirect original input reads before adding the initial source read.
  text,count=re.subn(r'(OpLoad '+vtype+r' )'+original+r'(?=\s|$)',r'\1'+storage,text);assert count>0
 init += ['%basis_normal_original = OpLoad %v3float %worldNormal_0','%basis_tangent_original = OpLoad %v4float %worldTangent',
  f'%basis_normal_originalBits = OpBitcast {u3} %basis_normal_original',f'%basis_tangent_originalBits = OpBitcast {u4} %basis_tangent_original']
 init += ['%basis_coord = OpLoad %v4float %gl_FragCoord','%basis_xf = OpCompositeExtract %float %basis_coord 0','%basis_yf = OpCompositeExtract %float %basis_coord 1','%basis_x = OpConvertFToS %int %basis_xf','%basis_y = OpConvertFToS %int %basis_yf']
 previous={f:f'%basis_{f}_original' for f in fields}
 for index,pixel in enumerate(points):
  tag=f'%basis_{index}_'
  decl += [f'{tag}x = OpConstant %int {pixel[0]}',f'{tag}y = OpConstant %int {pixel[1]}']
  init += [f'{tag}hitx = OpIEqual %bool %basis_x {tag}x',f'{tag}hity = OpIEqual %bool %basis_y {tag}y',f'{tag}pixelHit = OpLogicalAnd %bool {tag}hitx {tag}hity']
  # Match both measured input vectors to select the observed visible invocation.
  # Other overdraw fragments and derivative helpers retain their own inputs.
  for field,n,ut,bt in [('normal',3,u3,b3),('tangent',4,u4,b4)]:
   ids=[]
   for component,word in enumerate(rows[field,tuple(pixel)]['vulkanBits']):
    identifier=tag+field+'Expected'+str(component);ids.append(identifier);decl.append(f'{identifier} = OpConstant %uint {word}')
   decl.append(f'{tag}{field}Expected = OpConstantComposite {ut} '+' '.join(ids))
   init += [f'{tag}{field}Equal = OpIEqual {bt} %basis_{field}_originalBits {tag}{field}Expected',f'{tag}{field}Match = OpAll %bool {tag}{field}Equal']
  init += [f'{tag}basisMatch = OpLogicalAnd %bool {tag}normalMatch {tag}tangentMatch',f'{tag}hit = OpLogicalAnd %bool {tag}pixelHit {tag}basisMatch']
  for field in fields:
   n=3 if field=='normal' else 4;bits=rows[field,tuple(pixel)]['vulkanBits' if mode=='identity' else 'nativeBits'].copy()
   if mode!='identity':bits[0]^=0x80000000
   ids=[]
   for component,word in enumerate(bits):
    value=struct.unpack('<f',struct.pack('<I',word))[0];identifier=tag+field+str(component);ids.append(identifier)
    decl.append(f'{identifier} = OpConstant %float {value:.9g}')
   constant=tag+field+'Constant';decl.append(f'{constant} = OpConstantComposite %v{n}float '+' '.join(ids))
   condition=tag+field+'Condition';bt=b3 if n==3 else b4
   init += [f'{condition} = OpCompositeConstruct {bt} '+' '.join([tag+'hit']*n)]
   selected=tag+field+'Selected';init += [f'{selected} = OpSelect %v{n}float {condition} {constant} {previous[field]}'];previous[field]=selected
 for field in fields:init += [f'OpStore %basis_{field}Storage {previous[field]}']
 start=text.index('       %main = OpFunction');text=text[:start]+'\n'.join(decl)+'\n'+text[start:]
 lines=text.splitlines();start=next(i for i,s in enumerate(lines) if re.search(r'%main = OpFunction',s));label=next(i for i in range(start+1,len(lines)) if 'OpLabel' in lines[i])
 insert=label+1
 while insert<len(lines) and (not lines[insert].strip() or ' = OpVariable ' in lines[insert]):insert+=1
 lines[insert:insert]=init;text='\n'.join(lines)+'\n'
 (out/(mode+'.spvasm')).write_text(text)
 for command in [[str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/(mode+'.spvasm')),'-o',str(out/(mode+'.spv'))],[str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/(mode+'.spv'))]]:subprocess.run(command,check=True)
base=(prior/'baseline.py').read_text().split("receiver=main/")[0];(out/'baseline.py').write_text(base)
text=(out/'identity.spvasm').read_text();start=text.index('       %main = OpFunction')
decl='''%activation_pass_r = OpConstant %float 0.125
%activation_pass_g = OpConstant %float 0.375
%activation_fail_r = OpConstant %float 0.25
%activation_fail_g = OpConstant %float 0.5
'''
text=text[:start]+decl+text[start:];start=text.index('%main = OpFunction');end=text.index('OpFunctionEnd',start);body=text[start:end]
assert body.count('OpReturn\n')==1
code=[];previous='%basis_0_hit'
for i in range(1,len(points)):
 current=f'%activation_hit{i}';code.append(f'{current} = OpLogicalOr %bool {previous} %basis_{i}_hit');previous=current
code += [f'%activation_r = OpSelect %float {previous} %activation_pass_r %activation_fail_r',f'%activation_g = OpSelect %float {previous} %activation_pass_g %activation_fail_g',
 '%activation_original = OpLoad %v4float %outputColor','%activation_b = OpCompositeExtract %float %activation_original 2','%activation_a = OpCompositeExtract %float %activation_original 3',
 '%activation_color = OpCompositeConstruct %v4float %activation_r %activation_g %activation_b %activation_a','OpStore %outputColor %activation_color','OpReturn']
text=text[:start]+body.replace('OpReturn\n','\n'.join(code)+'\n')+text[end:]
(out/'activation.spvasm').write_text(text)
for command in [[str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/'activation.spvasm'),'-o',str(out/'activation.spv')],[str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/'activation.spv')]]:subprocess.run(command,check=True)
(out/'source-control.json').write_text(json.dumps(dict(points=points,sourceInput=report['summary'],variants=['control','activation','identity','normal','tangent','both'],scope='Diagnostic actual input substitution at 31 known failures; native visibility source control retained. Activation validates observed invocation selection; identity supplies measured Vulkan bits. No production patch.'),indent=2))
print('Prepared basis substitution, actual invocation activation and identity controls; all six SPIR-V programs validated')
