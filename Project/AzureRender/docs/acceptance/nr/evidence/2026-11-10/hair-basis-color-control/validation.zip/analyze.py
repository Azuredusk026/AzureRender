from pathlib import Path
import json,zlib,runpy,numpy as np
out=Path(__file__).resolve().parent;b=runpy.run_path(str(out/'baseline.py'));expected=b['expected'];mask=b['mask'];bad=b['bad']
state=json.loads((out/'state.json').read_text());assert state['status']=='collected' and len(state['variants'])==6
assert not state['debugMessages'] and all(v['baselineRestored'] for v in state['variants'])
source=json.loads((out/'source-control.json').read_text());target={(p[0]-1140,p[1]-130) for p in source['points']}
rows=[];control=None
for name in ['control','identity','normal','tangent','both']:
 a=np.frombuffer(zlib.decompress((out/(name+'-final.zlib')).read_bytes()),dtype='u1').reshape(310,290,4)[:,:,[2,1,0]].astype('i4')
 delta=abs(a-expected);failed=mask&(delta.max(axis=2)>1)
 if name=='control':control=a;assert int(failed.sum())==31 and int(delta[mask].max())==6
 changed=np.any(a!=control,axis=2);outside=changed.copy()
 for x,y in target:outside[y,x]=False
 rows.append(dict(name=name,maskPixels=int(mask.sum()),pixelsOverOneByte=int(failed.sum()),maximumByteError=int(delta[mask].max()),meanAbsoluteByteError=float(delta[mask].mean()),resolvedOriginalFailures=int((bad&~failed).sum()),newOriginalFailures=int((~bad&failed).sum()),changedHairPixels=int((changed&mask).sum()),changedOutsideTargetPixels=int(outside.sum()),
  failures=[dict(pixel=[int(x+1140),int(y+130)],absoluteError=delta[y,x].tolist()) for y,x in zip(*np.where(failed))]))
report=dict(status='diagnostic-basis-source-control',rows=rows,state=state,scope='Source substitution of measured native input values only at 31 diagnostic locations, with native visibility control. Not a production implementation or a full quality pass.')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps([{k:v for k,v in r.items() if k!='failures'} for r in rows],indent=2))
