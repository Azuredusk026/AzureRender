from pathlib import Path
import renderdoc as rd
import json,hashlib,traceback,sys
out=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-110844-hair-postvs-clip-source-03c2f0')
main=Path('D:/Projects/FYP/Project/AzureRender/build/runs')
cases=[('native',main/'20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc',950),('vulkan',main/'20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc',493)]
report=dict(status='starting',draws=[]);cap=None;c=None
try:
 for label,path,event in cases:
  cap=rd.OpenCaptureFile();assert cap.OpenFile(str(path),'',None)==rd.ResultCode.Succeeded
  status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
  c.SetFrameEvent(event,True);pipe=c.GetPipelineState();reflection=pipe.GetShaderReflection(rd.ShaderStage.Vertex)
  row=dict(label=label,event=event,constantBuffers=[],readOnlyBuffers=[])
  (out/f'{label}-vertex.asm').write_text(c.DisassembleShader(pipe.GetGraphicsPipelineObject(),reflection,''))
  def metadata(value):
   v={}
   for key in ['resource','resourceId','byteOffset','byteSize','offset','size','buffer','vecOffset','vecCount']:
    if hasattr(value,key):
     x=getattr(value,key);v[key]=x if isinstance(x,(int,float,str,bool)) else str(x)
   return v
  def datafile(name,rid):
   assert rid and str(rid)!='ResourceId::0'
   raw=bytes(c.GetBufferData(rid,0,0));assert len(raw)<=16*1024*1024
   (out/name).write_bytes(raw);return dict(name=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
  for index,cb in enumerate(reflection.constantBlocks):
   binding=pipe.GetConstantBlock(rd.ShaderStage.Vertex,index,0)
   descriptor=binding.descriptor if hasattr(binding,'descriptor') else binding
   rid=getattr(descriptor,'resource',getattr(descriptor,'resourceId',None))
   entry=dict(index=index,name=cb.name,binding=metadata(binding),descriptor=metadata(descriptor))
   if rid and str(rid)!='ResourceId::0':entry['file']=datafile(f'{label}-cb-{index}.bin',rid)
   row['constantBuffers'].append(entry)
  for used in pipe.GetReadOnlyResources(rd.ShaderStage.Vertex):
   resource=reflection.readOnlyResources[used.access.index]
   if resource.fixedBindNumber not in [10,13]:continue
   descriptor=used.descriptor
   entry=dict(binding=resource.fixedBindNumber,name=resource.name,descriptor=metadata(descriptor))
   entry['file']=datafile(f'{label}-binding-{resource.fixedBindNumber}.bin',descriptor.resource)
   row['readOnlyBuffers'].append(entry)
  row['debugMessages']=[str(m.description) for m in c.GetDebugMessages()]
  report['draws'].append(row);c.Shutdown();c=None;cap.Shutdown();cap=None
 report['status']='exported'
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'matrix-state.json').write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if report['status']=='exported' else 1)
