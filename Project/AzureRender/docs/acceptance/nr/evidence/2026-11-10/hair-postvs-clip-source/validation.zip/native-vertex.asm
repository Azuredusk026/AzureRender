Shader hash e315ffa2-bef97485-2a03278a-aa0e31fa

vs_5_0
      dcl_globalFlags refactoringAllowed
      dcl_constantbuffer cb0[82], immediateIndexed
      dcl_constantbuffer cb1[20], immediateIndexed
      dcl_constantbuffer cb2[4091], dynamicIndexed
      dcl_constantbuffer cb3[11], immediateIndexed
      dcl_resource_structured t0, 16
      dcl_input v0.xyz
      dcl_input v1.xy
      dcl_input v2.xyz
      dcl_input v3.xyzw
      dcl_input v4.xyz
      dcl_input v5.xyz
      dcl_input v6.xyz
      dcl_input v7.xyzw
      dcl_input v8.xyzw
      dcl_input v9.xyzw
      dcl_input_sgv v10.x, instanceid
      dcl_output_siv o0.xyzw, position
      dcl_output o1.xy
      dcl_output o2.xyz
      dcl_output o3.xyz
      dcl_output o4.xyzw
      dcl_output o5.xyz
      dcl_output o6.xyz
      dcl_output o7.xyz
      dcl_output o8.xyzw
      dcl_output o9.xyz
      dcl_output o10.x
      dcl_temps 16
   0: and r0.x, v2.x, l(2.000000)
   1: ult r0.y, l(0), r0.x
   2: if_nz r0.x
   3:   and r0.x, v2.x, l(1023)
   4:   ubfe r0.zw, l(0, 0, 10, 10), l(0, 0, 10, 20), v2.xxxx
   5:   utof r0.xzw, r0.xxzw
   6:   ge r1.x, r0.x, l(512.000000)
   7:   add r1.y, r0.x, l(-1024.000000)
   8:   movc r1.x, r1.x, r1.y, r0.x
   9:   ge r2.xy, r0.zwzz, l(512.000000, 512.000000, 0.000000, 0.000000)
  10:   add r2.zw, r0.zzzw, l(0.000000, 0.000000, -1024.000000, -1024.000000)
  11:   movc r1.yz, r2.xxyx, r2.zzwz, r0.zzwz
  12:   mul r0.xzw, r1.xxyz, l(0.001957, 0.000000, 0.001957, 0.001957)
  13:   add r2.xyz, -abs(r0.xzxx), l(1.000000, 1.000000, 1.000000, 0.000000)
  14:   add r3.z, -abs(r0.z), r2.x
  15:   lt r1.w, r3.z, l(0)
  16:   ge r1.xy, r1.xyxx, l(0, 0, 0, 0)
  17:   movc r1.xy, r1.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
  18:   mul r1.xy, r1.xyxx, r2.yzyy
  19:   movc r3.xy, r1.wwww, r1.xyxx, r0.xzxx
  20:   dp3 r0.x, r3.xyzx, r3.xyzx
  21:   rsq r0.x, r0.x
  22:   mul r1.xyw, r0.xxxx, r3.xyxz
  23:   mad r2.xyz, r3.yzxy, r0.xxxx, -r1.wxyw
  24:   dp3 r0.x, r2.xyzx, r1.xywx
  25:   add r2.xyz, -r0.xxxx, r2.xyzx
  26:   dp3 r0.x, r2.xyzx, r2.xyzx
  27:   rsq r0.x, r0.x
  28:   mul r2.xyz, r0.xxxx, r2.xyzx
  29:   lt r0.x, r1.z, l(0)
  30:   movc r0.x, r0.x, l(-1.000000), l(1.000000)
  31:   dp2 r0.z, r0.wwww, r0.xxxx
  32:   add r3.x, -r0.z, l(1.000000)
  33:   add r0.z, -abs(r3.x), l(1.000000)
  34:   mul r3.y, r0.z, r0.x
  35:   dp2 r0.x, r3.xyxx, r3.xyxx
  36:   rsq r0.x, r0.x
  37:   mul r0.xz, r0.xxxx, r3.xxyx
  38:   mul r3.xyz, r1.wxyw, r2.yzxy
  39:   mad r3.xyz, r1.ywxy, r2.zxyz, -r3.xyzx
  40:   dp3 r0.w, r3.xyzx, r3.xyzx
  41:   rsq r0.w, r0.w
  42:   mul r3.xyz, r0.wwww, r3.xyzx
  43:   mul r3.xyz, r0.zzzz, r3.xyzx
  44:   mad r2.xyz, r0.xxxx, r2.xyzx, r3.xyzx
  45:   ushr r0.x, v2.x, l(31)
  46:   utof r0.x, r0.x
  47:   mad r2.w, r0.x, l(2.000000), l(-1.000000)
  48: else
  49:   mov r2.xyzw, l(0, 0, 0, 0)
  50:   mov r1.xyw, v2.xyxz
  51: endif
  52: movc r0.xyzw, r0.yyyy, r2.xyzw, v3.xyzw
  53: and r1.z, v6.x, l(2.000000)
  54: ult r2.x, l(0), r1.z
  55: if_nz r1.z
  56:   and r1.z, v6.x, l(1023)
  57:   utof r1.z, r1.z
  58:   ubfe r2.yz, l(0, 10, 10, 0), l(0, 10, 20, 0), v6.xxxx
  59:   utof r2.yz, r2.yyzy
  60:   ge r2.w, r1.z, l(512.000000)
  61:   add r3.x, r1.z, l(-1024.000000)
  62:   movc r3.x, r2.w, r3.x, r1.z
  63:   ge r4.xy, r2.yzyy, l(512.000000, 512.000000, 0.000000, 0.000000)
  64:   add r4.zw, r2.yyyz, l(0.000000, 0.000000, -1024.000000, -1024.000000)
  65:   movc r3.yz, r4.xxyx, r4.zzwz, r2.yyzy
  66:   mul r2.yzw, r3.xxyz, l(0.000000, 0.001957, 0.001957, 0.001957)
  67:   add r4.xyz, -abs(r2.yzyy), l(1.000000, 1.000000, 1.000000, 0.000000)
  68:   add r5.x, -abs(r2.z), r4.x
  69:   lt r1.z, r5.x, l(0)
  70:   ge r3.xy, r3.xyxx, l(0, 0, 0, 0)
  71:   movc r3.xy, r3.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
  72:   mul r3.xy, r3.xyxx, r4.yzyy
  73:   movc r5.yz, r1.zzzz, r3.xxyx, r2.yyzy
  74:   dp3 r1.z, r5.xyzx, r5.xyzx
  75:   rsq r1.z, r1.z
  76:   mul r3.xyw, r1.zzzz, r5.yxyz
  77:   mad r4.xyz, r5.zxyz, r1.zzzz, -r3.yxwy
  78:   dp3 r1.z, r4.xzyx, r3.xywx
  79:   add r4.xyz, -r1.zzzz, r4.xyzx
  80:   dp3 r1.z, r4.xyzx, r4.xyzx
  81:   rsq r1.z, r1.z
  82:   mul r4.xyz, r1.zzzz, r4.xyzx
  83:   lt r1.z, r3.z, l(0)
  84:   movc r1.z, r1.z, l(-1.000000), l(1.000000)
  85:   dp2 r2.y, r2.wwww, r1.zzzz
  86:   add r5.x, -r2.y, l(1.000000)
  87:   add r2.y, -abs(r5.x), l(1.000000)
  88:   mul r5.y, r1.z, r2.y
  89:   dp2 r1.z, r5.xyxx, r5.xyxx
  90:   rsq r1.z, r1.z
  91:   mul r2.yz, r1.zzzz, r5.xxyx
  92:   mul r5.xyz, r3.yxwy, r4.yzxy
  93:   mad r5.xyz, r3.wyxw, r4.zxyz, -r5.xyzx
  94:   dp3 r1.z, r5.xyzx, r5.xyzx
  95:   rsq r1.z, r1.z
  96:   mul r5.xyz, r1.zzzz, r5.xyzx
  97:   mul r5.xyz, r2.zzzz, r5.xyzx
  98:   mad r4.xyw, r2.yyyy, r4.yzyx, r5.yzyx
  99:   ushr r1.z, v6.x, l(31)
 100:   utof r1.z, r1.z
 101:   mad r4.z, r1.z, l(2.000000), l(-1.000000)
 102: else
 103:   mov r3.xyw, v6.xzxy
 104:   mov r4.xyzw, l(0, 0, 0, 0)
 105: endif
 106: movc r1.z, r2.x, r4.w, v7.x
 107: movc r2.xyz, r2.xxxx, r4.xyzx, v7.yzwy
 108: ishl r2.w, v10.x, l(4)
 109: and r4.xyz, l(16, -49, 32, 0), cb2[r2.w + 4].wwww
 110: ieq r4.zw, r4.zzzy, l(0, 0, 0, 0)
 111: or r3.z, r4.w, r4.z
 112: if_z r3.z
 113:   iadd r4.zw, l(0, 0, 3, 3), cb2[r2.w + 5].xxxy
 114:   imad r5.xyzw, v9.xyzw, l(3, 3, 3, 3), r4.zzzz
 115:   imad r6.xyzw, v9.xyzw, l(3, 3, 3, 3), r4.wwww
 116:   iadd r4.zw, r5.xxxx, l(0, 0, 1, 2)
 117:   iadd r7.xy, r6.xxxx, l(1, 2, 0, 0)
 118:   uge r7.zw, r4.yyyy, l(0, 0, 2, 4)
 119:   if_nz r7.z
 120:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r8.xyzw, r7.y, l(0), t0.xyzw
 121:     iadd r9.xy, r6.yyyy, l(2, 1, 0, 0)
 122:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r9.x, l(0), t0.xyzw
 123:     mul r10.xyzw, r10.xyzw, v8.yyyy
 124:     mad r8.xyzw, r8.xyzw, v8.xxxx, r10.xyzw
 125:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r7.x, l(0), t0.xyzw
 126:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r9.xyzw, r9.y, l(0), t0.xyzw
 127:     mul r9.xyzw, r9.xyzw, v8.yyyy
 128:     mad r9.xyzw, r10.xyzw, v8.xxxx, r9.xyzw
 129:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r6.x, l(0), t0.xyzw
 130:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r11.xyzw, r6.y, l(0), t0.xyzw
 131:     mul r11.xyzw, r11.xyzw, v8.yyyy
 132:     mad r10.xyzw, r10.xyzw, v8.xxxx, r11.xyzw
 133:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r11.xyzw, r4.w, l(0), t0.xyzw
 134:     iadd r12.xy, r5.yyyy, l(2, 1, 0, 0)
 135:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r13.xyzw, r12.x, l(0), t0.xyzw
 136:     mul r13.xyzw, r13.xyzw, v8.yyyy
 137:     mad r11.xyzw, r11.xyzw, v8.xxxx, r13.xyzw
 138:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r13.xyzw, r4.z, l(0), t0.xyzw
 139:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r12.xyzw, r12.y, l(0), t0.xyzw
 140:     mul r12.xyzw, r12.xyzw, v8.yyyy
 141:     mad r12.xyzw, r13.xyzw, v8.xxxx, r12.xyzw
 142:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r13.xyzw, r5.x, l(0), t0.xyzw
 143:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r14.xyzw, r5.y, l(0), t0.xyzw
 144:     mul r14.xyzw, r14.xyzw, v8.yyyy
 145:     mad r13.xyzw, r13.xyzw, v8.xxxx, r14.xyzw
 146:   else
 147:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r8.xyzw, r7.y, l(0), t0.xyzw
 148:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r9.xyzw, r7.x, l(0), t0.xyzw
 149:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r10.xyzw, r6.x, l(0), t0.xyzw
 150:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r11.xyzw, r4.w, l(0), t0.xyzw
 151:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r12.xyzw, r4.z, l(0), t0.xyzw
 152:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r13.xyzw, r5.x, l(0), t0.xyzw
 153:   endif
 154:   if_nz r7.w
 155:     iadd r7.xyzw, r6.zwzw, l(2, 2, 1, 1)
 156:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r14.xyzw, r7.x, l(0), t0.xyzw
 157:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r15.xyzw, r7.y, l(0), t0.xyzw
 158:     mul r15.xyzw, r15.xyzw, v8.wwww
 159:     mad r14.xyzw, r14.xyzw, v8.zzzz, r15.xyzw
 160:     add r8.xyzw, r8.xyzw, r14.xyzw
 161:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r14.xyzw, r7.z, l(0), t0.xyzw
 162:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r7.w, l(0), t0.xyzw
 163:     mul r7.xyzw, r7.xyzw, v8.wwww
 164:     mad r7.xyzw, r14.xyzw, v8.zzzz, r7.xyzw
 165:     add r9.xyzw, r7.xyzw, r9.xyzw
 166:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r6.z, l(0), t0.xyzw
 167:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r6.xyzw, r6.w, l(0), t0.xyzw
 168:     mul r6.xyzw, r6.xyzw, v8.wwww
 169:     mad r6.xyzw, r7.xyzw, v8.zzzz, r6.xyzw
 170:     add r10.xyzw, r6.xyzw, r10.xyzw
 171:     iadd r6.xyzw, r5.zwzw, l(2, 2, 1, 1)
 172:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r6.x, l(0), t0.xyzw
 173:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r14.xyzw, r6.y, l(0), t0.xyzw
 174:     mul r14.xyzw, r14.xyzw, v8.wwww
 175:     mad r7.xyzw, r7.xyzw, v8.zzzz, r14.xyzw
 176:     add r11.xyzw, r7.xyzw, r11.xyzw
 177:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r7.xyzw, r6.z, l(0), t0.xyzw
 178:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r6.xyzw, r6.w, l(0), t0.xyzw
 179:     mul r6.xyzw, r6.xyzw, v8.wwww
 180:     mad r6.xyzw, r7.xyzw, v8.zzzz, r6.xyzw
 181:     add r12.xyzw, r6.xyzw, r12.xyzw
 182:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r6.xyzw, r5.z, l(0), t0.xyzw
 183:     ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r5.xyzw, r5.w, l(0), t0.xyzw
 184:     mul r5.xyzw, r5.xyzw, v8.wwww
 185:     mad r5.xyzw, r6.xyzw, v8.zzzz, r5.xyzw
 186:     add r13.xyzw, r5.xyzw, r13.xyzw
 187:   endif
 188:   dp3 r3.z, r13.xyzx, r0.xyzx
 189:   dp3 r4.y, r12.xyzx, r0.xyzx
 190:   dp3 r4.z, r11.xyzx, r0.xyzx
 191:   dp3 r4.w, r13.xyzx, r1.xywx
 192:   dp3 r5.x, r12.xyzx, r1.xywx
 193:   dp3 r5.y, r11.xyzx, r1.xywx
 194:   mov r6.xyz, v0.xyzx
 195:   mov r6.w, l(1.000000)
 196:   dp4 r5.z, r13.xyzw, r6.xyzw
 197:   dp4 r5.w, r12.xyzw, r6.xyzw
 198:   dp4 r7.x, r11.xyzw, r6.xyzw
 199:   dp4 r10.x, r10.xyzw, r6.xyzw
 200:   dp4 r10.y, r9.xyzw, r6.xyzw
 201:   dp4 r10.z, r8.xyzw, r6.xyzw
 202: else
 203:   mov r10.xyz, v4.xyzx
 204:   mov r3.z, r0.x
 205:   mov r4.yz, r0.yyzy
 206:   mov r4.w, r1.x
 207:   mov r5.xy, r1.ywyy
 208:   mov r5.zw, v0.xxxy
 209:   mov r7.x, v0.z
 210: endif
 211: mul r6.xyz, r5.wwww, cb2[r2.w + 1].xyzx
 212: mad r6.xyz, cb2[r2.w + 0].xyzx, r5.zzzz, r6.xyzx
 213: mad r6.xyz, cb2[r2.w + 2].xyzx, r7.xxxx, r6.xyzx
 214: add r7.yzw, -cb0[44].xxyz, cb2[r2.w + 3].xxyz
 215: add r6.xyz, r6.xyzx, r7.yzwy
 216: mul r8.xyzw, r6.yyyy, cb0[33].xyzw
 217: mad r8.xyzw, cb0[32].xyzw, r6.xxxx, r8.xyzw
 218: mad r8.xyzw, cb0[34].xyzw, r6.zzzz, r8.xyzw
 219: add r8.xyzw, r8.xyzw, cb0[35].xyzw
 220: mul r7.yz, r8.wwww, cb1[19].zzwz
 221: mad o0.xy, -r7.yzyy, l(2.000000, -2.000000, 0.000000, 0.000000), r8.xyxx
 222: mul r7.yzw, r5.xxxx, cb2[r2.w + 1].xxyz
 223: mad r7.yzw, cb2[r2.w + 0].xxyz, r4.wwww, r7.yyzw
 224: mad r7.yzw, cb2[r2.w + 2].xxyz, r5.yyyy, r7.yyzw
 225: mul r9.xyz, r4.yyyy, cb2[r2.w + 1].xyzx
 226: mad r9.xyz, cb2[r2.w + 0].xyzx, r3.zzzz, r9.xyzx
 227: mad r4.yzw, cb2[r2.w + 2].xxyz, r4.zzzz, r9.xxyz
 228: lt r3.z, cb2[r2.w + 10].x, l(1.000000)
 229: mad o1.xy, v1.xyxx, cb3[10].xyxx, cb3[10].zwzz
 230: dp3 r5.x, r7.yzwy, r7.yzwy
 231: max r5.x, r5.x, l(0.000000)
 232: rsq r5.x, r5.x
 233: mul o3.xyz, r5.xxxx, r7.yzwy
 234: dp3 r5.x, r4.yzwy, r4.yzwy
 235: max r5.x, r5.x, l(0.000000)
 236: rsq r5.x, r5.x
 237: mul o4.xyz, r4.yzwy, r5.xxxx
 238: movc r4.yz, r3.zzzz, r5.zzwz, r10.xxyx
 239: movc r3.z, r3.z, r7.x, r10.z
 240: mul r5.xyz, r4.zzzz, cb2[r2.w + 7].xyzx
 241: mad r4.yzw, cb2[r2.w + 6].xxyz, r4.yyyy, r5.xxyz
 242: mad r4.yzw, cb2[r2.w + 8].xxyz, r3.zzzz, r4.yyzw
 243: add r5.xyz, -cb0[81].xyzx, cb2[r2.w + 9].xyzx
 244: add r4.yzw, r4.yyzw, r5.xxyz
 245: mul r5.xyz, r4.zzzz, cb0[58].xywx
 246: mad r5.xyz, cb0[57].xywx, r4.yyyy, r5.xyzx
 247: mad r4.yzw, cb0[59].xxyw, r4.wwww, r5.xxyz
 248: add o6.xyz, r4.yzwy, cb0[60].xywx
 249: movc o7.xyz, r4.xxxx, r3.xwyx, r1.xywx
 250: movc o8.x, r4.x, r1.z, r0.x
 251: movc o8.yzw, r4.xxxx, r2.xxyz, r0.yyzw
 252: mov o0.zw, r8.zzzw
 253: mov o4.w, r0.w
 254: mov o2.xyz, r6.xyzx
 255: mov o5.xyz, r8.xywx
 256: mov o9.xyz, v5.xyzx
 257: mov o10.x, v10.x
 258: ret
