from pathlib import Path
import json,hashlib
import numpy as np
out=Path(__file__).resolve().parent
state=json.loads((out/'export-state.json').read_text());matrix=json.loads((out/'matrix-state.json').read_text())
assert state['status']==matrix['status']=='exported'
for d in state['draws']:
 for f in d['files']:
  raw=(out/f['name']).read_bytes();assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256']
expected={'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU','NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image'}
for d in state['draws']+matrix['draws']:
 assert not d['debugMessages'] if d['label']=='vulkan' else set(d['debugMessages'])<=expected
native=np.fromfile(out/'native-vertex.bin',dtype='<f4').reshape(-1,33)
vulkan=np.fromfile(out/'vulkan-vertex.bin',dtype='<f4').reshape(-1,64)
ai=np.fromfile(out/'native-index.bin',dtype='<u2').reshape(-1,3)
bi=np.fromfile(out/'vulkan-index.bin',dtype='<u4').reshape(-1,3)
assert native.shape[0]==vulkan.shape[0]==11564 and ai.size==bi.size==43044
assert np.array_equal(ai[:,::-1],bi)
assert int(ai.max())<11564
cb0=np.fromfile(out/'native-cb-0-range.bin',dtype='<f4').reshape(-1,4)
cb1=np.fromfile(out/'native-cb-1-range.bin',dtype='<f4').reshape(-1,4)
world=native[:,6:9]
q=world[:,1,None]*cb0[33]
q=(world[:,0,None].astype('f8')*cb0[32]+q.astype('f8')).astype('f4')
q=(world[:,2,None].astype('f8')*cb0[34]+q.astype('f8')).astype('f4')
q+=cb0[35]
j=q[:,3,None]*cb1[19,2:4]
q[:,:2]=((-j).astype('f8')*[2,-2]+q[:,:2].astype('f8')).astype('f4')
assert np.array_equal(q.view('u4'),native[:,:4].copy().view('u4'))
rows=json.loads((out/'uv-source-results.json').read_text())['rows']
models=[]
for row in rows:
 if row['pixel'] not in [[1306,156],[1322,263],[1193,295],[1193,296],[1193,297]]:continue
 point={"pixel":row['pixel'],"models":[]}
 for label,buf,uv in [('native',native,native[:,4:6]),('vulkan',vulkan,vulkan[:,12:14])]:
  ndc=buf[:,:2]/buf[:,3,None];screen=np.rint((ndc*np.array([1280,720],dtype='f4')+np.array([1280,720],dtype='f4')).astype('f8')*256)/256
  v=screen[ai];pos=np.array(row['pixel'])+.5;v0=v[:,1]-v[:,0];v1=v[:,2]-v[:,0];v2=pos-v[:,0];den=v0[:,0]*v1[:,1]-v1[:,0]*v0[:,1];valid=abs(den)>1e-10
  u=np.divide(v2[:,0]*v1[:,1]-v1[:,0]*v2[:,1],den,out=np.zeros_like(den),where=valid);vv=np.divide(v0[:,0]*v2[:,1]-v2[:,0]*v0[:,1],den,out=np.zeros_like(den),where=valid)
  good=np.where(valid&(u>=0)&(vv>=0)&(u+vv<=1))[0]
  weights=np.stack([1-u-vv,u,vv],axis=1)[good]/buf[ai[good],3]
  values=np.sum(weights[:,:,None]*uv[ai[good]],axis=1)/weights.sum(axis=1)[:,None]
  errors=np.max(abs(values-row[label]),axis=1);best=int(np.argmin(errors))
  point['models'].append(dict(label=label,nearestTriangle=int(good[best]),coveredTriangleCount=len(good),predictedUv=values[best].tolist(),actualUv=row[label],maximumAbsoluteError=float(errors[best])))
 models.append(point)
uvdelta=abs(native[:,4:6].astype('f8')-vulkan[:,12:14].astype('f8'))
report=dict(status='qualified-postvs-source-diagnosis',vertices=11564,indices=43044,reverseIndexOrderExact=True,sourceUvMaximumPerComponent=uvdelta.max(axis=0).tolist(),clipXywMaximumPerComponent=abs(native[:,[0,1,3]].astype('f8')-vulkan[:,[0,1,3]].astype('f8')).max(axis=0).tolist(),nativeClipModelBitExactVertices=11564,cpuSubpixelModels=models,export=state,matrixExport=matrix,productionChanged=False,overallVisualAcceptance='failed-user-review',scope='Actual VSOut buffers qualify source differences. CPU nearest-triangle interpolation is a numerical model, not GPU primitive ownership or a passing color candidate. Native and Vulkan depth conventions differ; raw Z is not compared as homologous.')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(vertices=11564,reverseIndexOrderExact=True,nativeClipModelBitExactVertices=11564,models=models),indent=2))
