from pathlib import Path
import renderdoc as rd
import json,hashlib,traceback,sys
out=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-110844-hair-postvs-clip-source-03c2f0')
main=Path('D:/Projects/FYP/Project/AzureRender/build/runs')
cases=[('native',main/'20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc',950),('vulkan',main/'20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc',493)]
report=dict(status='starting',draws=[]);cap=None;c=None
try:
 for label,path,event in cases:
  cap=rd.OpenCaptureFile();assert cap.OpenFile(str(path),'',None)==rd.ResultCode.Succeeded
  status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
  c.SetFrameEvent(event,True);pipe=c.GetPipelineState();reflection=pipe.GetShaderReflection(rd.ShaderStage.Vertex)
  mesh=c.GetPostVSData(0,0,rd.MeshDataStage.VSOut)
  fields=['baseVertex','vertexByteOffset','vertexByteStride','indexByteOffset','indexByteStride','numIndices','flipY','unproject']
  row=dict(label=label,event=event,mesh={k:getattr(mesh,k) for k in fields},signature=[],files=[])
  for sig in reflection.outputSignature:
   keys=['compCount','regIndex','regChannelMask','semanticName','semanticIndex','varName','stream']
   v={k:getattr(sig,k) for k in keys};v.update(systemValue=str(sig.systemValue),varType=str(sig.varType));row['signature'].append(v)
  for role,rid in [('vertex',mesh.vertexResourceId),('index',mesh.indexResourceId)]:
   assert rid and str(rid)!='ResourceId::0'
   data=bytes(c.GetBufferData(rid,0,0));assert data and len(data)<=16*1024*1024
   name=f'{label}-{role}.bin';(out/name).write_bytes(data);row['files'].append(dict(role=role,name=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
  raw=bytes(reflection.rawBytes);(out/f'{label}-vertex.shader').write_bytes(raw)
  row['shaderSha256']=hashlib.sha256(raw).hexdigest();row['debugMessages']=[str(m.description) for m in c.GetDebugMessages()]
  report['draws'].append(row);c.Shutdown();c=None;cap.Shutdown();cap=None
 report['status']='exported'
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'export-state.json').write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if report['status']=='exported' else 1)
