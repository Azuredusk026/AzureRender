SPIR-V 1.0 module, <id> bound of 652

Generator: Shaderc over Glslang from Google - Contact David Neto, dneto@google.com
Generator Version: 11

Capability(Shader);



MemoryModel(Logical, GLSL450);

EntryPoint(Vertex, main, "main", {
    instanceObjectShadow, 
    gl_InstanceIndex, 
    opacityCoordinate, 
    position, 
    eyebrowRegion, 
    browMask, 
    instanceFaceDirection, 
    instanceFaceFrame, 
    jointWeights, 
    jointIndices, 
    normal, 
    tangent, 
    gl_VertexIndex, 
    morph0, 
    morph1, 
    gl_PerVertex_var, 
    worldNormal, 
    worldTangent, 
    textureCoordinate, 
    texcoord, 
    worldPosition, 
    shadowPositions
  });


Source(GLSL, 450);
SourceExtension("GL_GOOGLE_cpp_style_line_directive");
SourceExtension("GL_GOOGLE_include_directive");




struct MorphTargetWords : [[BufferBlock]] {
  uint[] words : [[Offset(0), NonWritable]] : [[ArrayStride(4)]];
}
Uniform MorphTargetWords* morphTargets : [[DescriptorSet(0), Binding(21), NonWritable]];
struct MorphInstanceWeights : [[BufferBlock]] {
  float[] values : [[Offset(0), NonWritable]] : [[ArrayStride(4)]];
}
Uniform MorphInstanceWeights* morphInstances : [[DescriptorSet(0), Binding(22), NonWritable]];
Output uint* instanceObjectShadow : [[Location(15), Flat]];
struct InstanceTransforms {
  float4x4 model : [[ColMajor, MatrixStride(16), Offset(0)]];
  float4x4 modelViewProjection : [[ColMajor, MatrixStride(16), Offset(64)]];
  float4x4[4] cascadeLightModelViewProjection : [[ColMajor, MatrixStride(16), Offset(128)]] : [[ArrayStride(64)]];
  uint4 meta : [[Offset(384)]];
  float4 faceLight : [[Offset(400)]];
  float2 morph : [[Offset(416)]];
  uint objectShadowIndex : [[Offset(424)]];
  uint instanceFlags : [[Offset(428)]];
  float4x4 faceFrame : [[ColMajor, MatrixStride(16), Offset(432)]];
}
struct InstanceData : [[BufferBlock]] {
  InstanceTransforms[] instances : [[Offset(0), NonWritable]] : [[ArrayStride(496)]];
}
Uniform InstanceData* instanceData : [[DescriptorSet(0), Binding(13), NonWritable]];
Input int* gl_InstanceIndex : [[BuiltIn(InstanceIndex)]];
Output float3* opacityCoordinate : [[Location(14)]];
Input float3* position : [[Location(0)]];
Output float* eyebrowRegion : [[Location(8)]];
Input float* browMask : [[Location(8)]];
Output float4* instanceFaceDirection : [[Location(9), Flat]];
Output float4x4* instanceFaceFrame : [[Location(10), Flat]];
struct MorphWeights : [[Block]] {
  float4 styleParameters : [[Offset(80)]];
  float4 featureParameters : [[Offset(96)]];
  uint materialFeatures : [[Offset(116)]];
  float2 weights : [[Offset(128)]];
  float4x4 gizmoTransform : [[ColMajor, MatrixStride(16), Offset(144)]];
}
PushConstant MorphWeights* morphWeights;
Input float4* jointWeights : [[Location(5)]];
struct JointData : [[BufferBlock]] {
  float4x4[] matrices : [[ColMajor, MatrixStride(16), Offset(0), NonWritable]] : [[ArrayStride(64)]];
}
Uniform JointData* jointData : [[DescriptorSet(0), Binding(10), NonWritable]];
Input uint4* jointIndices : [[Location(4)]];
Input float3* normal : [[Location(1)]];
Input float4* tangent : [[Location(2)]];
Input int* gl_VertexIndex : [[BuiltIn(VertexIndex)]];
Input float3* morph0 : [[Location(6)]];
Input float3* morph1 : [[Location(7)]];
struct CameraData : [[Block]] {
  float4 cameraPosition : [[Offset(0)]];
  float4 cameraForward : [[Offset(16)]];
  float4 clusterGrid : [[Offset(32)]];
  float4 clusterDepth : [[Offset(48)]];
  float4 clusterLighting : [[Offset(64)]];
  float4 cascadeSplits : [[Offset(80)]];
  float4 renderingParameters : [[Offset(96)]];
  float4 showcaseParameters : [[Offset(112)]];
  float4 qaParameters : [[Offset(128)]];
  float4 faceLightDirection : [[Offset(144)]];
  float4 faceSdfParameters : [[Offset(160)]];
  float4 faceSdfShadowColor : [[Offset(176)]];
  float4 mainLightDirection : [[Offset(192)]];
  float4 cascadeDepthRanges : [[Offset(208)]];
}
Uniform CameraData* camera : [[DescriptorSet(0), Binding(0)]];
struct gl_PerVertex : [[Block]] {
  float4 gl_Position : [[BuiltIn(Position)]];
  float gl_PointSize : [[BuiltIn(PointSize)]];
  float[1] gl_ClipDistance : [[BuiltIn(ClipDistance)]];
  float[1] gl_CullDistance : [[BuiltIn(CullDistance)]];
}
Output gl_PerVertex* gl_PerVertex_var;
Output float3* worldNormal : [[Location(0)]];
Output float4* worldTangent : [[Location(1)]];
Output float2* textureCoordinate : [[Location(2)]];
Input float2* texcoord : [[Location(3)]];
Output float3* worldPosition : [[Location(3)]];
Output float4[4]* shadowPositions : [[Location(4)]];

void main() {
  float4x4* model;
  int* axis;
  bool* browOverlay;
  uint* jointBase;
  float4x4* skinMatrix;
  float3* morphedPosition;
  float3* morphedNormal;
  float3* morphedTangent;
  uint* param;
  uint* param@2;
  uint* param@3;
  float3* param@4;
  float3* param@5;
  float3* param@6;
  float4* skinnedPosition;
  float4x4* param@7;
  float3* param@8;
  float3* skinnedNormal;
  float3* skinnedTangent;
  float4* gizmoPosition;
  float3* initialWorldPosition;
  float3* worldViewDirection;
  float3* localViewDirection;
  float3* gizmoNormal;
  float3* gizmoTangent;
  float3x3* modelLinear;
  int* cascadeIndex;
  int _179 = *gl_InstanceIndex;
  uint* _181 = &instanceData.instances[_179].objectShadowIndex;
  uint _182 = *_181;
  *instanceObjectShadow = _182;
  float3 _187 = *position;
  *opacityCoordinate = _187;
  float _192 = *browMask;
  *eyebrowRegion = _192;
  int _195 = *gl_InstanceIndex;
  float4* _198 = &instanceData.instances[_195].faceLight;
  float4 _199 = *_198;
  *instanceFaceDirection = _199;
  int _202 = *gl_InstanceIndex;
  float4x4* _205 = &instanceData.instances[_202].faceFrame;
  float4x4 _206 = *_205;
  *instanceFaceFrame = _206;
  uint* _212 = &morphWeights.materialFeatures;
  uint _213 = *_212;
  uint _215 = _213 & 65536;
  bool _216 = _215 != 0;
  
  if(_216) {
    uint* _219 = &morphWeights.materialFeatures;
    uint _220 = *_219;
    uint _222 = _220 & 1048576;
    bool _223 = _222 == 0;
  }

  bool _224 = Phi(_216, _223);
  
  if(_224) {
    int _227 = *gl_InstanceIndex;
    float4x4* _228 = &instanceData.instances[_227].model;
    float4x4 _229 = *_228;
    float4x4* _231 = &morphWeights.gizmoTransform;
    float4x4 _232 = *_231;
    float4x4 _233 = _229 * _232;
    *instanceFaceFrame = _233;
  } else {
    uint* _235 = &morphWeights.materialFeatures;
    uint _236 = *_235;
    uint _238 = _236 & 1050624;
    bool _239 = _238 != 0;
    bool _240 = !_239;
    
    if(_240) {
      int _243 = *gl_InstanceIndex;
      uint* _245 = &instanceData.instances[_243].instanceFlags;
      uint _246 = *_245;
      uint _247 = _246 & 1;
      bool _248 = _247 != 0;
    }

    bool _249 = Phi(_239, _248);
    
    if(_249) {
      int _253 = *gl_InstanceIndex;
      float4x4* _254 = &instanceData.instances[_253].model;
      float4x4 _255 = *_254;
      *model = _255;
      float4x4 _256 = *model;
      float4x4* _257 = &morphWeights.gizmoTransform;
      float4x4 _258 = *_257;
      float4x4 _259 = _256 * _258;
      float4x4 _260 = *model;
      float4x4 _261 = GLSL.std.450::MatrixInverse(_260);
      float4x4 _262 = _259 * _261;
      float4x4 _263 = *instanceFaceFrame;
      float4x4 _264 = _262 * _263;
      *instanceFaceFrame = _264;
      *axis = 0;

      while(true) {
        int _272 = *axis;
        bool _274 = _272 < 3;
        if(!_274) break;
        int _275 = *axis;
        int _276 = *axis;
        float4* _277 = &instanceFaceFrame[_276];
        float4 _278 = *_277;
        float3 _279 = _278.xyz;
        float3 _280 = GLSL.std.450::Normalize(_279);
        float* _281 = &instanceFaceFrame[_275].x;
        float _282 = _280.x;
        *_281 = _282;
        float* _283 = &instanceFaceFrame[_275].y;
        float _284 = _280.y;
        *_283 = _284;
        float* _285 = &instanceFaceFrame[_275].z;
        float _286 = _280.z;
        *_285 = _286;
        int _287 = *axis;
        int _288 = _287 + 1;
        *axis = _288;
      }

    }

  }

  uint* _291 = &morphWeights.materialFeatures;
  uint _292 = *_291;
  uint _294 = _292 & 64;
  bool _295 = _294 != 0;
  *browOverlay = _295;
  int _297 = *gl_InstanceIndex;
  uint* _298 = &instanceData.instances[_297].meta.x;
  uint _299 = *_298;
  *jointBase = _299;
  float* _303 = &jointWeights.x;
  float _304 = *_303;
  uint _309 = *jointBase;
  uint* _313 = &jointIndices.x;
  uint _314 = *_313;
  uint _315 = _309 + _314;
  float4x4* _316 = &jointData.matrices[_315];
  float4x4 _317 = *_316;
  float4x4 _318 = _317 * _304;
  float* _319 = &jointWeights.y;
  float _320 = *_319;
  uint _321 = *jointBase;
  uint* _322 = &jointIndices.y;
  uint _323 = *_322;
  uint _324 = _321 + _323;
  float4x4* _325 = &jointData.matrices[_324];
  float4x4 _326 = *_325;
  float4x4 _327 = _326 * _320;
  float4 _328 = _318[0];
  float4 _329 = _327[0];
  float4 _330 = _328 + _329;
  float4 _331 = _318[1];
  float4 _332 = _327[1];
  float4 _333 = _331 + _332;
  float4 _334 = _318[2];
  float4 _335 = _327[2];
  float4 _336 = _334 + _335;
  float4 _337 = _318[3];
  float4 _338 = _327[3];
  float4 _339 = _337 + _338;
  float4x4 _340 = CompositeConstruct({_330, _333, _336, _339});
  float* _341 = &jointWeights.z;
  float _342 = *_341;
  uint _343 = *jointBase;
  uint* _344 = &jointIndices.z;
  uint _345 = *_344;
  uint _346 = _343 + _345;
  float4x4* _347 = &jointData.matrices[_346];
  float4x4 _348 = *_347;
  float4x4 _349 = _348 * _342;
  float4 _350 = _340[0];
  float4 _351 = _349[0];
  float4 _352 = _350 + _351;
  float4 _353 = _340[1];
  float4 _354 = _349[1];
  float4 _355 = _353 + _354;
  float4 _356 = _340[2];
  float4 _357 = _349[2];
  float4 _358 = _356 + _357;
  float4 _359 = _340[3];
  float4 _360 = _349[3];
  float4 _361 = _359 + _360;
  float4x4 _362 = CompositeConstruct({_352, _355, _358, _361});
  float* _363 = &jointWeights.w;
  float _364 = *_363;
  uint _365 = *jointBase;
  uint* _366 = &jointIndices.w;
  uint _367 = *_366;
  uint _368 = _365 + _367;
  float4x4* _369 = &jointData.matrices[_368];
  float4x4 _370 = *_369;
  float4x4 _371 = _370 * _364;
  float4 _372 = _362[0];
  float4 _373 = _371[0];
  float4 _374 = _372 + _373;
  float4 _375 = _362[1];
  float4 _376 = _371[1];
  float4 _377 = _375 + _376;
  float4 _378 = _362[2];
  float4 _379 = _371[2];
  float4 _380 = _378 + _379;
  float4 _381 = _362[3];
  float4 _382 = _371[3];
  float4 _383 = _381 + _382;
  float4x4 _384 = CompositeConstruct({_374, _377, _380, _383});
  *skinMatrix = _384;
  float3 _386 = *position;
  *morphedPosition = _386;
  float3 _389 = *normal;
  *morphedNormal = _389;
  float4 _392 = *tangent;
  float3 _393 = _392.xyz;
  *morphedTangent = _393;
  int _394 = *gl_InstanceIndex;
  int _396 = *gl_VertexIndex;
  uint _397 = Bitcast(_396);
  int _398 = *gl_InstanceIndex;
  uint* _400 = &instanceData.instances[_394].meta.z;
  uint _401 = *_400;
  *param = _401;
  *param@2 = _397;
  uint* _404 = &instanceData.instances[_398].meta.w;
  uint _405 = *_404;
  *param@3 = _405;
  float3 _407 = *morphedPosition;
  *param@4 = _407;
  float3 _409 = *morphedNormal;
  *param@5 = _409;
  float3 _411 = *morphedTangent;
  *param@6 = _411;
  bool _412 = applyAssetMorph(param, param@2, param@3, param@4, param@5, param@6);
  float3 _413 = *param@4;
  *morphedPosition = _413;
  float3 _414 = *param@5;
  *morphedNormal = _414;
  float3 _415 = *param@6;
  *morphedTangent = _415;
  bool _416 = !_412;
  
  if(_416) {
    float3 _420 = *morph0;
    int _421 = *gl_InstanceIndex;
    float* _423 = &instanceData.instances[_421].morph.x;
    float _424 = *_423;
    float3 _425 = _420 * _424;
    float3 _427 = *morph1;
    int _428 = *gl_InstanceIndex;
    float* _429 = &instanceData.instances[_428].morph.y;
    float _430 = *_429;
    float3 _431 = _427 * _430;
    float3 _432 = _425 + _431;
    float3 _433 = *morphedPosition;
    float3 _434 = _433 + _432;
    *morphedPosition = _434;
  }

  float4x4 _438 = *skinMatrix;
  *param@7 = _438;
  float3 _440 = *morphedPosition;
  *param@8 = _440;
  float4 _441 = azureSkinPosition(param@7, param@8);
  *skinnedPosition = _441;
  float4x4 _443 = *skinMatrix;
  float4 _445 = _443[0];
  float3 _446 = _445.xyz;
  float4 _447 = _443[1];
  float3 _448 = _447.xyz;
  float4 _449 = _443[2];
  float3 _450 = _449.xyz;
  float3x3 _451 = CompositeConstruct({_446, _448, _450});
  float3 _452 = *morphedNormal;
  float3 _453 = _451 * _452;
  float3 _454 = GLSL.std.450::Normalize(_453);
  *skinnedNormal = _454;
  float4x4 _456 = *skinMatrix;
  float4 _457 = _456[0];
  float3 _458 = _457.xyz;
  float4 _459 = _456[1];
  float3 _460 = _459.xyz;
  float4 _461 = _456[2];
  float3 _462 = _461.xyz;
  float3x3 _463 = CompositeConstruct({_458, _460, _462});
  float3 _464 = *morphedTangent;
  float3 _465 = _463 * _464;
  float3 _466 = GLSL.std.450::Normalize(_465);
  *skinnedTangent = _466;
  float4x4* _468 = &morphWeights.gizmoTransform;
  float4x4 _469 = *_468;
  float4 _470 = *skinnedPosition;
  float4 _471 = _469 * _470;
  *gizmoPosition = _471;
  bool _472 = *browOverlay;
  
  if(_472) {
    float _475 = *browMask;
    bool _477 = _475 > 0.5000;
  }

  bool _478 = Phi(_472, _477);
  
  if(_478) {
    int _482 = *gl_InstanceIndex;
    float4x4* _483 = &instanceData.instances[_482].model;
    float4x4 _484 = *_483;
    float4 _485 = *gizmoPosition;
    float4 _486 = _484 * _485;
    float3 _487 = _486.xyz;
    *initialWorldPosition = _487;
    float4* _492 = &camera.cameraPosition;
    float4 _493 = *_492;
    float3 _494 = _493.xyz;
    float3 _495 = *initialWorldPosition;
    float3 _496 = _494 - _495;
    float3 _497 = GLSL.std.450::Normalize(_496);
    *worldViewDirection = _497;
    int _499 = *gl_InstanceIndex;
    float4x4* _500 = &instanceData.instances[_499].model;
    float4x4 _501 = *_500;
    float4 _502 = _501[0];
    float3 _503 = _502.xyz;
    float4 _504 = _501[1];
    float3 _505 = _504.xyz;
    float4 _506 = _501[2];
    float3 _507 = _506.xyz;
    float3x3 _508 = CompositeConstruct({_503, _505, _507});
    float3x3 _509 = Transpose(_508);
    float3 _510 = *worldViewDirection;
    float3 _511 = _509 * _510;
    float3 _512 = GLSL.std.450::Normalize(_511);
    *localViewDirection = _512;
    float3 _513 = *localViewDirection;
    float* _515 = &morphWeights.featureParameters.x;
    float _516 = *_515;
    float3 _517 = _513 * _516;
    float4 _518 = *gizmoPosition;
    float3 _519 = _518.xyz;
    float3 _520 = _519 + _517;
    float* _521 = &gizmoPosition.x;
    float _522 = _520.x;
    *_521 = _522;
    float* _523 = &gizmoPosition.y;
    float _524 = _520.y;
    *_523 = _524;
    float* _525 = &gizmoPosition.z;
    float _526 = _520.z;
    *_525 = _526;
  }

  float4x4* _528 = &morphWeights.gizmoTransform;
  float4x4 _529 = *_528;
  float4 _530 = _529[0];
  float3 _531 = _530.xyz;
  float4 _532 = _529[1];
  float3 _533 = _532.xyz;
  float4 _534 = _529[2];
  float3 _535 = _534.xyz;
  float3x3 _536 = CompositeConstruct({_531, _533, _535});
  float3x3 _537 = GLSL.std.450::MatrixInverse(_536);
  float3x3 _538 = Transpose(_537);
  float3 _539 = *skinnedNormal;
  float3 _540 = _538 * _539;
  float3 _541 = GLSL.std.450::Normalize(_540);
  *gizmoNormal = _541;
  float4x4* _543 = &morphWeights.gizmoTransform;
  float4x4 _544 = *_543;
  float4 _545 = _544[0];
  float3 _546 = _545.xyz;
  float4 _547 = _544[1];
  float3 _548 = _547.xyz;
  float4 _549 = _544[2];
  float3 _550 = _549.xyz;
  float3x3 _551 = CompositeConstruct({_546, _548, _550});
  float3 _552 = *skinnedTangent;
  float3 _553 = _551 * _552;
  float3 _554 = GLSL.std.450::Normalize(_553);
  *gizmoTangent = _554;
  int _559 = *gl_InstanceIndex;
  float4x4* _560 = &instanceData.instances[_559].modelViewProjection;
  float4x4 _561 = *_560;
  float4 _562 = *gizmoPosition;
  float4 _563 = _561 * _562;
  float4* _564 = &gl_PerVertex_var.gl_Position;
  *_564 = _563;
  int _567 = *gl_InstanceIndex;
  float4x4* _568 = &instanceData.instances[_567].model;
  float4x4 _569 = *_568;
  float4 _570 = _569[0];
  float3 _571 = _570.xyz;
  float4 _572 = _569[1];
  float3 _573 = _572.xyz;
  float4 _574 = _569[2];
  float3 _575 = _574.xyz;
  float3x3 _576 = CompositeConstruct({_571, _573, _575});
  *modelLinear = _576;
  float3x3 _578 = *modelLinear;
  float3x3 _579 = GLSL.std.450::MatrixInverse(_578);
  float3x3 _580 = Transpose(_579);
  float3 _581 = *gizmoNormal;
  float3 _582 = _580 * _581;
  float3 _583 = GLSL.std.450::Normalize(_582);
  *worldNormal = _583;
  int _585 = *gl_InstanceIndex;
  float4x4* _586 = &instanceData.instances[_585].model;
  float4x4 _587 = *_586;
  float4 _588 = _587[0];
  float3 _589 = _588.xyz;
  float4 _590 = _587[1];
  float3 _591 = _590.xyz;
  float4 _592 = _587[2];
  float3 _593 = _592.xyz;
  float3x3 _594 = CompositeConstruct({_589, _591, _593});
  float3 _595 = *gizmoTangent;
  float3 _596 = _594 * _595;
  float3 _597 = GLSL.std.450::Normalize(_596);
  float* _598 = &tangent.w;
  float _599 = *_598;
  float3x3 _600 = *modelLinear;
  float _601 = GLSL.std.450::Determinant(_600);
  float4x4* _602 = &morphWeights.gizmoTransform;
  float4x4 _603 = *_602;
  float4 _604 = _603[0];
  float3 _605 = _604.xyz;
  float4 _606 = _603[1];
  float3 _607 = _606.xyz;
  float4 _608 = _603[2];
  float3 _609 = _608.xyz;
  float3x3 _610 = CompositeConstruct({_605, _607, _609});
  float _611 = GLSL.std.450::Determinant(_610);
  float _612 = _601 * _611;
  float _613 = GLSL.std.450::FSign(_612);
  float _614 = _599 * _613;
  float _615 = _597.x;
  float _616 = _597.y;
  float _617 = _597.z;
  float4 _618 = CompositeConstruct({_615, _616, _617, _614});
  *worldTangent = _618;
  float2 _623 = *texcoord;
  *textureCoordinate = _623;
  int _625 = *gl_InstanceIndex;
  float4x4* _626 = &instanceData.instances[_625].model;
  float4x4 _627 = *_626;
  float4 _628 = *gizmoPosition;
  float4 _629 = _627 * _628;
  float3 _630 = _629.xyz;
  *worldPosition = _630;
  *cascadeIndex = 0;

  while(true) {
    int _637 = *cascadeIndex;
    bool _638 = _637 < 4;
    if(!_638) break;
    int _642 = *cascadeIndex;
    int _643 = *gl_InstanceIndex;
    int _644 = *cascadeIndex;
    float4x4* _645 = &instanceData.instances[_643].cascadeLightModelViewProjection[_644];
    float4x4 _646 = *_645;
    float4 _647 = *gizmoPosition;
    float4 _648 = _646 * _647;
    float4* _649 = &shadowPositions[_642];
    *_649 = _648;
    int _650 = *cascadeIndex;
    int _651 = _650 + 1;
    *cascadeIndex = _651;
  }

  return;
}

float3 morphVector(uint* offset) {
  uint _39 = *offset;
  uint* _41 = &morphTargets.words[_39];
  uint _42 = *_41;
  float _43 = Bitcast(_42);
  uint _44 = *offset;
  uint _46 = _44 + 1;
  uint* _47 = &morphTargets.words[_46];
  uint _48 = *_47;
  float _49 = Bitcast(_48);
  uint _50 = *offset;
  uint _52 = _50 + 2;
  uint* _53 = &morphTargets.words[_52];
  uint _54 = *_53;
  float _55 = Bitcast(_54);
  float3 _56 = CompositeConstruct({_43, _49, _55});
  return _56;
}

bool applyAssetMorph(uint* tableBase, uint* vertexIndex, uint* weightBase, float3* position@2, float3* normal@2, float3* tangent@2) {
  uint* table;
  uint* delta;
  uint* weights;
  uint* count;
  uint* target;
  float* weight;
  uint* base;
  uint* param@9;
  uint* param@10;
  uint* param@11;
  uint _59 = *tableBase;
  bool _61 = _59 == 0;
  
  if(_61) {
    return false;
  }

  uint _67 = *tableBase;
  uint _68 = *vertexIndex;
  uint _70 = _68 * 3;
  uint _71 = _67 + _70;
  *table = _71;
  uint _73 = *table;
  uint* _74 = &morphTargets.words[_73];
  uint _75 = *_74;
  *delta = _75;
  uint _77 = *weightBase;
  uint _78 = *table;
  uint _79 = _78 + 1;
  uint* _80 = &morphTargets.words[_79];
  uint _81 = *_80;
  uint _82 = _77 + _81;
  *weights = _82;
  uint _84 = *table;
  uint _85 = _84 + 2;
  uint* _86 = &morphTargets.words[_85];
  uint _87 = *_86;
  *count = _87;
  *target = 0;

  while(true) {
    uint _94 = *target;
    uint _95 = *count;
    bool _96 = _94 < _95;
    if(!_96) break;
    uint _103 = *weights;
    uint _104 = *target;
    uint _105 = _103 + _104;
    float* _107 = &morphInstances.values[_105];
    float _108 = *_107;
    *weight = _108;
    float _109 = *weight;
    bool _111 = _109 == 0.0000;
    
    if(_111) {
      goto loop_continue1;
    }

    uint _116 = *delta;
    uint _117 = *target;
    uint _119 = _117 * 9;
    uint _120 = _116 + _119;
    *base = _120;
    float _121 = *weight;
    uint _123 = *base;
    *param@9 = _123;
    float3 _124 = morphVector(param@9);
    float3 _125 = _124 * _121;
    float3 _126 = *position@2;
    float3 _127 = _126 + _125;
    *position@2 = _127;
    float _128 = *weight;
    uint _129 = *base;
    uint _130 = _129 + 3;
    *param@10 = _130;
    float3 _132 = morphVector(param@10);
    float3 _133 = _132 * _128;
    float3 _134 = *normal@2;
    float3 _135 = _134 + _133;
    *normal@2 = _135;
    float _136 = *weight;
    uint _137 = *base;
    uint _139 = _137 + 6;
    *param@11 = _139;
    float3 _141 = morphVector(param@11);
    float3 _142 = _141 * _136;
    float3 _143 = *tangent@2;
    float3 _144 = _143 + _142;
    *tangent@2 = _144;
loop_continue1:
    uint _145 = *target;
    uint _147 = _145 + 1;
    *target = _147;
  }

  return true;
}

float4 azureSkinPosition(float4x4* skin, float3* position@3) {
  float4x4 _151 = *skin;
  float3 _152 = *position@3;
  float _154 = _152.x;
  float _155 = _152.y;
  float _156 = _152.z;
  float4 _157 = CompositeConstruct({_154, _155, _156, 1.0000});
  float4 _158 = _151 * _157;
  float3 _159 = _158.xyz;
  float _160 = _159.x;
  float _161 = _159.y;
  float _162 = _159.z;
  float4 _163 = CompositeConstruct({_160, _161, _162, 1.0000});
  return _163;
}


