from pathlib import Path
import json, struct, hashlib, io, base64, time
import ctypes
import numpy as np
zstd=ctypes.CDLL(str(Path.cwd()/'build/ninja-msvc-release/zstd.dll'))
zstd.ZSTD_compressBound.argtypes=[ctypes.c_size_t];zstd.ZSTD_compressBound.restype=ctypes.c_size_t
zstd.ZSTD_compress.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int];zstd.ZSTD_compress.restype=ctypes.c_size_t
zstd.ZSTD_decompress.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t];zstd.ZSTD_decompress.restype=ctypes.c_size_t
zstd.ZSTD_isError.argtypes=[ctypes.c_size_t];zstd.ZSTD_isError.restype=ctypes.c_uint
zstd.ZSTD_versionString.restype=ctypes.c_char_p

from PIL import Image

root=Path.cwd();out=Path(__file__).resolve().parent
frozen=json.loads((root/'build/runs/20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text())
seen_files=set();seen_images={};rows=[];errors=[];start=time.monotonic()

def image(data,label):
    encoded=hashlib.sha256(data).hexdigest()
    if encoded in seen_images:return
    try:
        with Image.open(io.BytesIO(data)) as im:
            a=np.asarray(im.convert('RGBA'))
        h,w,_=a.shape; channels=[];variable=[]
        for c in range(4):
            x=a[:,:,c];lo=int(x.min());hi=int(x.max())
            if lo==hi and lo in (0,255):channels.append(str(lo));continue
            equal=next((prior for prior in variable if np.array_equal(x,a[:,:,prior])),None)
            if equal is not None:channels.append('c'+str(equal))
            else:variable.append(c);channels.append('c'+str(c))
        row=dict(source=label,encodedSha256=encoded,decodedSha256=hashlib.sha256(a.tobytes()).hexdigest(),width=w,height=h,bytes=int(a.size),independentChannels=len(variable),mapping=channels)
        raw=a.tobytes();bound=zstd.ZSTD_compressBound(len(raw));buffer=ctypes.create_string_buffer(bound)
        compress_start=time.monotonic();count=zstd.ZSTD_compress(buffer,bound,raw,len(raw),1);assert not zstd.ZSTD_isError(count)
        compressed_seconds=time.monotonic()-compress_start
        restored=ctypes.create_string_buffer(len(raw));decode_start=time.monotonic();decoded=zstd.ZSTD_decompress(restored,len(raw),buffer,count)
        assert decoded==len(raw) and restored.raw==raw
        row.update(compressedBytes=count,retainedBytes=min(count,len(raw)),compressSeconds=compressed_seconds,decompressSeconds=time.monotonic()-decode_start,roundTripExact=True)
        seen_images[encoded]=row;rows.append(row)
    except Exception as e:errors.append(dict(source=label,error=str(e)))

for name,digest in frozen.items():
    p=Path(name);ext=p.suffix.lower()
    if ext not in ('.png','.dds','.glb','.gltf') or digest in seen_files:continue
    seen_files.add(digest)
    if ext in ('.png','.dds'):image(p.read_bytes(),str(p));continue
    try:
        if ext=='.glb':
            with p.open('rb') as f:
                magic,version,total=struct.unpack('<III',f.read(12));assert magic==0x46546c67 and version==2
                size,kind=struct.unpack('<II',f.read(8));assert kind==0x4e4f534a
                gltf=json.loads(f.read(size));head=f.read(8)
                if not head:continue
                size,kind=struct.unpack('<II',head);assert kind==0x004e4942
                bin_offset=f.tell()
                for i,entry in enumerate(gltf.get('images',[])):
                    if 'bufferView' not in entry:continue
                    v=gltf['bufferViews'][entry['bufferView']];assert v.get('buffer',0)==0
                    f.seek(bin_offset+v.get('byteOffset',0));image(f.read(v['byteLength']),str(p)+'#image'+str(i))
        else:
            gltf=json.loads(p.read_text('utf-8-sig'))
            for i,entry in enumerate(gltf.get('images',[])):
                uri=entry.get('uri','')
                if uri.startswith('data:'):image(base64.b64decode(uri.split(',',1)[1]),str(p)+'#image'+str(i))
    except Exception as e:errors.append(dict(source=str(p),error=str(e)))
    if len(seen_files)%50==0:print('files',len(seen_files),'images',len(rows),flush=True)

unique={ (r['decodedSha256'],r['width'],r['height']):r for r in rows}
compression=dict(decodedBytes=sum(r['bytes'] for r in unique.values()),compressedBytes=sum(r['compressedBytes'] for r in unique.values()),retainedBytes=sum(r['retainedBytes'] for r in unique.values()),compressSeconds=sum(r['compressSeconds'] for r in unique.values()),decompressSeconds=sum(r['decompressSeconds'] for r in unique.values()),version=zstd.ZSTD_versionString().decode(),level=1,roundTripExact=all(r['roundTripExact'] for r in unique.values()))
summary={str(n):dict(images=sum(r['independentChannels']==n for r in unique.values()),baseBytes=sum(r['bytes'] for r in unique.values() if r['independentChannels']==n)) for n in range(5)}
report=dict(compression=compression,status='decoded-source-compression-scope',seconds=time.monotonic()-start,uniqueSourceFiles=len(seen_files),encodedImages=len(rows),uniqueDecodedImages=len(unique),groups=summary,errors=errors,rows=rows,scope='Pillow-decoded unique frozen source images at base level; Zstandard level 1 and exact roundtrip. Runtime processed material bytes, shared ownership and actual loading peak remain separate')
(out/'results.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='rows'}),flush=True)
