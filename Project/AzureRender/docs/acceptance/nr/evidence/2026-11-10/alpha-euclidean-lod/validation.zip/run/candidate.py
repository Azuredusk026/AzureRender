from pathlib import Path
import json,subprocess,os,re,numpy as np
out=Path(__file__).resolve().parent;build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release';calibration=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7';rows=[]
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(build)+';'+env['PATH'])
 prefix=out/(device+'-candidate');command=[str(out.parent/'20261110-183305-intel-depth-alpha-footprint-e32993/native-coverage.exe'),str(out/'candidate-shaders'),str(out/'candidate-config.json'),str(prefix)]
 with (out/(device+'-candidate-depth.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
 text=(out/(device+'-candidate-depth.log')).read_text(errors='replace');assert r.returncode==0 and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I),text[-3000:]
 config=json.loads((calibration/'hair-calibration.json').read_text());config.update(depth=str(prefix)+'-r32.bin',scope='euclidean');path=out/(device+'-candidate-visibility.json');path.write_text(json.dumps(config,indent=2)+'\n')
 with (out/(device+'-candidate-visibility.log')).open('wb') as log:r=subprocess.run([str(calibration/'calibration.exe'),str(path),str(calibration)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
 text=(out/(device+'-candidate-visibility.log')).read_text(errors='replace');result=json.loads((out/(device+'-euclidean-result.json')).read_text());assert result['validationErrors']==0 and result['zeroAllocator'] and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I)
 rows.append({'device':device,'visibilityExitCode':r.returncode,'result':result});(out/'candidate-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(device,result['exactPixels'],result['withinOnePixels'],result['maximumByteError'],flush=True)
