from pathlib import Path
import sys,json,subprocess
out=Path(__file__).resolve().parent;root=out.parents[2];prior=out.parent/'20261110-173835-reference-depth-coverage-4b4afc';old=out.parent/'20261110-183305-intel-depth-alpha-footprint-e32993'
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
local=s.acquire_inputs(root/'build',out,[prior.name,old.name,'20261110-165124-reference-depth-source-4d1d7d','20261110-003435-visibility-numeric-contract-4f95e7','20261110-003031-reciprocal-compact-profile-4e7929','20261110-030251-hair-main-chroma-public-9e799c'],owner)
external=s.acquire_inputs(s.DEFAULT_BUILD,out,['20261108-045252-screen-object-visibility-ca2907','20261027-022702-object-visibility-depth-reconstruction-c7312f'],owner)
p=Path('D:/Projects/FYP-coordination/quality-claim.json');v=json.loads(p.read_text(encoding='utf-8'));v.update(state='explicit-euclidean-alpha-lod-candidate',taskPath=str(out),inputLease=[external],localInputLease=[local],pendingCommand='explicit-lod-two-devices',ownedFiles=['docs/acceptance/nr/alpha-euclidean-lod.md']);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
folder=out/'candidate-shaders';folder.mkdir(exist_ok=True)
for name in ['reference_depth.vert.spv','reference_depth.frag.spv','reference_depth_masked.vert.spv']:(folder/name).write_bytes((prior/('release-'+name)).read_bytes())
command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslangValidator.exe','-V','--target-env','vulkan1.1','-I'+str(root/'shaders'),'-o',str(folder/'reference_depth_masked.frag.spv'),str(out/'candidate.frag')];r=subprocess.run(command,capture_output=True,text=True);(out/'shader-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.1',str(folder/'reference_depth_masked.frag.spv')],capture_output=True,text=True);assert r.returncode==0,r.stderr
(out/'candidate-config.json').write_bytes((prior/'native-config.json').read_bytes())
candidate=(old/'candidate.py').read_text().replace("str(out/'native-coverage.exe')","str(out.parent/'20261110-183305-intel-depth-alpha-footprint-e32993/native-coverage.exe')").replace("scope='quad'","scope='euclidean'").replace("device+'-quad-result.json'","device+'-euclidean-result.json'")
(out/'candidate.py').write_text(candidate)
(out/'queued.py').write_text((old/'queued-candidate.py').read_text().replace('quality-intel-alpha-footprint','quality-alpha-euclidean-lod'))
(out/'task-card.json').write_text(json.dumps({'baseCommit':'fbf8661','delivery':'Test explicit Euclidean isotropic LOD against one independently observed Alpha predicate difference','source':'https://docs.vulkan.org/spec/latest/chapters/textures.html#textures-scale-factor','hypothesis':'Hardware derivative scale approximation survives textureGrad; explicit Euclidean LOD removes that freedom','singleFactor':'Scale estimation changes from hardware textureGrad to Euclidean textureLod, same reference quad gradients','baseline':{'nvidiaVisibilityFailures':0,'intelVisibilityFailures':97},'criteria':['All original17017 pixels checked','NVIDIA no regressions','Intel original Alpha point closes without new failures','Zero validation errors and allocator count'],'plannedBytes':67108864,'explorationSeconds':1800,'gpuSeconds':240},indent=2)+'\n')
print('Explicit Euclidean LOD candidate prepared')
