from pathlib import Path
import json,os,subprocess,sys,shutil,time,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,verify,digest
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
before=inputs(root);checks=[]
targets=['AzureMaterialUvGradientsGpuTests','AzureHotReloadTests','AzureShaderCompilerContractTests']
selector=r'^(AzureRender\.(MaterialUvGradientsGpu|ShaderCompilerContract|ShaderCatalogCompilation|HotReload)|AzureEngine\.(ModuleBoundaries|ModuleBoundaryFixtures))$'
for config in ['Release','Debug']:
 build=root/('build/ninja-msvc-'+config.lower());command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
 for target in targets:command+=['--test-target',target]
 start=time.monotonic()
 with (out/(config.lower()+'-build.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 shutil.copyfile(build/'build-provenance.json',out/(config.lower()+'-build-provenance.json'))
 command=['ctest','--test-dir',str(build),'-C',config,'--output-on-failure','--no-tests=error','-R',selector,'--output-junit',str(out/(config.lower()+'-tests.xml'))]
 with (out/(config.lower()+'-tests.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=360)
 cases=ET.parse(out/(config.lower()+'-tests.xml')).findall('.//testcase');assert len(cases)==6 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
 checks.append(dict(config=config,tests=len(cases),skips=0,seconds=time.monotonic()-start));print(json.dumps(checks[-1]),flush=True)
 verify(root,json.loads((build/'build-provenance.json').read_text()))
 os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*'
 with (out/(config.lower()+'-intel-gradient.log')).open('wb') as log:subprocess.run([str(build/'AzureMaterialUvGradientsGpuTests.exe'),str(build/'shaders/material_uv_gradients_test.vert.spv'),str(build/'shaders/material_uv_gradients_test.frag.spv')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
 text=(out/(config.lower()+'-intel-gradient.log')).read_text(errors='replace');assert 'Intel' in text and '8716 pixels / 34864 exact components; 81 retained' in text and not any(x in text for x in ['VUID-','SYNC-HAZARD','Validation Error:','Validation Warning:'])
 os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
assert inputs(root)==before

(out/'build-results.json').write_text(json.dumps(dict(checks=checks,sourceUnchanged=True,gradientPixelsPerBatch=8716),indent=2))
print('Both actual host builds and 12 focused checks passed')
