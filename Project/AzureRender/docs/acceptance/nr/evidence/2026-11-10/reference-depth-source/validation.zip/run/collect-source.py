from pathlib import Path
import renderdoc as rd
import json,traceback,sys
out=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-165124-reference-depth-source-4d1d7d')
path=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc')
report={'status':'starting','draws':[]};cap=None;c=None
def fields(value):return {k:str(getattr(value,k)) for k in dir(value) if not k.startswith('_') and not callable(getattr(value,k))}
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(path),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 c.SetFrameEvent(699,True);pipe=c.GetPipelineState();reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
 for a in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel):
  if reflection.readOnlyResources[a.access.index].fixedBindNumber==0:
   report['depthResource']=str(a.descriptor.resource);report['depthUsage']=[{'event':x.eventId,'usage':str(x.usage)} for x in c.GetUsage(a.descriptor.resource)]
 for event in [422,440,950]:
  c.SetFrameEvent(event,True);pipe=c.GetPipelineState();state=c.GetD3D11PipelineState();mesh=c.GetPostVSData(0,0,rd.MeshDataStage.VSOut)
  row={'event':event,'rasterizer':fields(state.rasterizer.state),'stride':mesh.vertexByteStride,'indexCount':mesh.numIndices,'vertexOffset':mesh.vertexByteOffset,'depth':str(pipe.GetDepthTarget().resource),'vertexInputs':[{k:str(getattr(b,k)) for k in ['resourceId','byteOffset','byteStride']} for b in pipe.GetVBuffers()]}
  data=bytes(c.GetBufferData(mesh.vertexResourceId,0,0));assert len(data)<16*1024*1024;(out/f'source-{event}-vertices.bin').write_bytes(data)
  reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
  if reflection:(out/f'source-{event}-fragment.asm').write_text(c.DisassembleShader(pipe.GetGraphicsPipelineObject(),reflection,''),encoding='utf-8')
  report['draws'].append(row)
 report['status']='exported'
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'source-state.json').write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if report['status']=='exported' else 1)
