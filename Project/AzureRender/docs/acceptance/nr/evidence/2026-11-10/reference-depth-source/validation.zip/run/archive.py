from pathlib import Path
import hashlib,json,re,zipfile
engine=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender');out=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda name:json.loads((out/name).read_text(encoding='utf-8'))
frozen=read('frozen-source.json');assert all(sha(engine/name)==digest for name,digest in frozen.items())
gpu=read('gpu-results.json');assert len(gpu)==4 and all(x['exitCode']==0 and x['validationClean'] for x in gpu)
for row in gpu:assert '73920 exact R32/D32 values' in (out/f"{row['configuration']}-{row['device']}-gpu.log").read_text()
assert read('default-four-results.json')['allExact']
docs=['docs/runtime/reference-depth.md','docs/acceptance/nr/reference-depth-source.md','docs/plans/2026-11-10-reference-depth-source.md']
dependencies=['src/render/ReferenceClipProjection.hpp','src/render/ReferenceFmaShader.hpp','shaders/reference_clip_projection.glsl']
prior=json.loads((out.parent/'20261110-154308-reference-clip-projection-public-07ee1e/frozen-source.json').read_text())
assert all(sha(engine/name)==prior[name] for name in dependencies)
dest=engine/'docs/acceptance/nr/evidence/2026-11-10/reference-depth-source';dest.mkdir(parents=True,exist_ok=True)
files={f'source/{name}':engine/name for name in list(frozen)+dependencies+docs}
allowed={'.json','.log','.py','.bin','.spv','.cpp','.comp'}
files.update({f'run/{p.name}':p for p in out.iterdir() if p.is_file() and p.suffix in allowed and not (p.name.startswith('release-') and p.name.endswith('-depth.bin'))})
frames=out/'default-four-frames';files.update({f'run/default-four-frames/{p.name}':p for p in frames.iterdir() if p.is_file() and p.suffix=='.json'})
members={name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in files.items()}
archive=dest/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.writestr('manifest.json',json.dumps(members,ensure_ascii=False,indent=2))
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,info in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==info['sha256']
result={'status':'qualified-public-opaque-depth-producer-native-material-binding-pending','overall':'failed-user-review','exactGpuAttachmentValues':295680,'gpuBatches':gpu,'rejectionsPerBatch':10,'projectionWorkflows':['Orthographic','Perspective'],'coverageChecks':['Forward/reversed nearest overlap','Adjacent binary32 depth','Asymmetric Y mapping','Clear and slot reuse'],'nativeDepthComparison':read('native-depth-results.json'),'nativeSourceScope':{'events':[422,440,950],'422Vs950ClipExactVertices':11564,'440ClipDifferentVertices':11564,'bothDepthShadersDiscardAlpha':True,'nativeCompleteColorGate':'pending; original 17017 pixels and one-byte threshold unchanged'},'defaultFour':read('default-four-results.json'),'programIdentity':read('program-identity.json'),'preparedPrograms':read('prepared-programs.json'),'source':frozen,'archive':{'members':len(members)+1,'bytes':archive.stat().st_size,'sha256':sha(archive)}}
(dest/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in docs:
 p=engine/name
 for link in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if not link.startswith('https:'):assert (p.parent/link).exists(),link
print(json.dumps(result['archive']))
