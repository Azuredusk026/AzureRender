from pathlib import Path
import sys,json,subprocess
root=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender');out=Path(__file__).parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
names=['20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2','20261110-110844-hair-postvs-clip-source-03c2f0','20261110-154308-reference-clip-projection-public-07ee1e']
token=s.acquire_inputs(root/'build',out,names,owner)
mainToken=s.acquire_inputs(s.DEFAULT_BUILD,out,['20261022-201845-endfield-capture-954719','20261023-105023-character-composite-contribution-diagnosis-acb8e5'],owner)
claim=Path('D:/Projects/FYP-coordination/quality-claim.json');v=json.loads(claim.read_text(encoding='utf-8'));v.update(state='reference-depth-source-implementation',lastCommit='d5b8d95',taskPath=str(out),localInputLease=[token],inputLease=[mainToken],pendingCommand='reference-depth-source',ownedFiles=['src/render/ReferenceDepth.hpp','src/render/ReferenceDepth.cpp','shaders/reference_depth.vert','shaders/reference_depth.frag','tests/ReferenceDepthGpuTests.cpp','CMakeLists.txt']);claim.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'task-card.json').write_text(json.dumps({'baseCommit':'d5b8d95','deliverable':'Public geometry R32/D32 depth producer, original relative projection','plannedBytes':134217728,'explorationSeconds':1800,'buildSecondsPerConfiguration':900,'gpuSeconds':240,'captureSeconds':240,'criteria':['Actual geometry producer','Explicit forward/reversed depth, clear/overlap precision','Two workflows, both devices/configurations','Native hair depth source diagnosis, unchanged thresholds','Default host/shader identity and cleanup']},indent=2)+'\n')
cmd=subprocess.list2cmdline(['D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat','cl','/nologo','/std:c++17','/c','/I'+str(root/'src'),str(out/'red.cpp'),'/Fo'+str(out/'red.obj')])
with (out/'red.log').open('wb') as log:r=subprocess.run(cmd,shell=True,stdout=log,stderr=subprocess.STDOUT,cwd=root)
assert r.returncode!=0 and 'ReferenceDepth.hpp' in (out/'red.log').read_text(errors='replace')
print('Missing public producer verified; input leases acquired')
