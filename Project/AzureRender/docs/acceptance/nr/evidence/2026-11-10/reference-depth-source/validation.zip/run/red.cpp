#include "render/ReferenceDepth.hpp"
int main(){azurerender::ReferenceDepthConfig config;return config.schemaVersion!=1;}
