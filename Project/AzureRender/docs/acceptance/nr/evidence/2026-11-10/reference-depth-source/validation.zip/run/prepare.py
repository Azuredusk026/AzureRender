from pathlib import Path
import sys,json,hashlib,numpy as np
from PIL import Image
out=Path(__file__).parent;root=out.parents[2];previous=root/'build/runs/20261110-154308-reference-clip-projection-public-07ee1e';post=root/'build/runs/20261110-110844-hair-postvs-clip-source-03c2f0'
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
claim=Path('D:/Projects/FYP-coordination/quality-claim.json');value=json.loads(claim.read_text(encoding='utf-8'))
if len(value['inputLease'])==1:
 token=s.acquire_inputs(s.DEFAULT_BUILD,out,['20261027-022702-object-visibility-depth-reconstruction-c7312f'],owner)
 value['inputLease'].append(token);claim.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ['20261110-030251-hair-main-chroma-public-9e799c','20261110-031856-hair-main-chroma-debug-668bf2']:s.maintenance.resume(root/'build',name)
(out/'native-profile.bin').write_bytes((previous/'native-profile.bin').read_bytes())
records=np.fromfile(previous/'native-records.bin',dtype='<f4').reshape(-1,8);records[:,:4].copy().tofile(out/'native-positions.bin')
np.fromfile(post/'native-index.bin',dtype='<u2').astype('<u4').tofile(out/'native-indices.bin')
mask=Image.open(s.DEFAULT_BUILD/'runs/20261023-105023-character-composite-contribution-diagnosis-acb8e5/native-hair-visible-mask.png')
m=np.asarray(mask);m=m[:,:,0] if m.ndim==3 else m
assert m.shape==(1440,2560),m.shape
ys,xs=np.nonzero(m);assert len(xs)==17017
coordinates=np.column_stack([xs,ys]).astype('<u4');coordinates.tofile(out/'native-mask-coordinates.bin')
native=s.DEFAULT_BUILD/'runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/native-t0.bin'
assert hashlib.sha256(native.read_bytes()).hexdigest()=='02a45801c10f071def9e85501756cc7a192a8fca0196d993472cf26a3498fcdb'
depth=np.fromfile(native,dtype='<f4').reshape(1440,2560);depth[1439-coordinates[:,1],coordinates[:,0]].tofile(out/'native-selected-depth.bin')
files=['CMakeLists.txt','src/render/ReferenceDepth.hpp','src/render/ReferenceDepth.cpp','shaders/reference_depth.vert','shaders/reference_depth.frag','tests/ReferenceDepthGpuTests.cpp']
(out/'frozen-source.json').write_text(json.dumps({name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files},indent=2)+'\n')
print('11564 relative positions, 43044 uint32 indices, original17017 native depths prepared')
