from pathlib import Path
import sys,json,subprocess,os,re
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
out=Path(__file__).resolve().parent;root=out.parents[2]
for configuration,name in [('Release','20261110-030251-hair-main-chroma-public-9e799c'),('Debug','20261110-031856-hair-main-chroma-debug-668bf2')]:
 result=s.maintenance.guarded_run(root/'build',name,[sys.executable,str(out/'build.py'),configuration],900)
 (out/(configuration.lower()+'-build-execution.json')).write_text(json.dumps(result,indent=2));assert result.get('exitCode')==0,result
rows=[]
for configuration,folder in [('release','20261110-030251-hair-main-chroma-public-9e799c/release'),('debug','20261110-031856-hair-main-chroma-debug-668bf2/debug')]:
 build=root/'build/runs'/folder
 for device in ['nvidia','intel']:
  env=os.environ.copy()
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
  env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
  label=configuration+'-'+device;command=[str(build/'AzureReferenceDepthGpuTests.exe'),str(build/'shaders')]
  if configuration=='release':command += [str(out/'native-profile.bin'),str(out/'native-positions.bin'),str(out/'native-indices.bin'),str(out/label)]
  with (out/(label+'-gpu.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  text=(out/(label+'-gpu.log')).read_text(errors='replace');row=dict(configuration=configuration,device=device,exitCode=r.returncode,command=command,validationClean=not bool(re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I)));rows.append(row);(out/'gpu-results.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,text[-2500:],flush=True)
  assert r.returncode==0 and row['validationClean'],text[-3000:]
  assert '73920 exact R32/D32 values' in text
  assert ('NVIDIA' in text)==(device=='nvidia')
