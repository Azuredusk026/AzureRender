from pathlib import Path
import numpy as np,json,hashlib
out=Path(__file__).parent
coordinates=np.fromfile(out/'native-mask-coordinates.bin',dtype='<u4').reshape(-1,2)
reference=np.fromfile(out/'native-selected-depth.bin',dtype='<f4');assert len(reference)==17017
def compare(values):
 delta=np.abs(values.astype(np.float64)-reference)
 ulp=np.abs(values.view('<u4').astype(np.int64)-reference.view('<u4').astype(np.int64))
 return dict(exact=int((ulp==0).sum()),withinOneUlp=int((ulp<=1).sum()),maxUlp=int(ulp.max()),medianUlp=float(np.median(ulp)),maxAbsolute=float(delta.max()),medianAbsolute=float(np.median(delta)),missing=int((values==0).sum()))
rows=[]
for device in ['nvidia','intel']:
 path=out/f'release-{device}-depth.bin';planes=np.fromfile(path,dtype='<f4').reshape(2,1440,2560)
 values=planes[0,coordinates[:,1],coordinates[:,0]];depth=planes[1,coordinates[:,1],coordinates[:,0]]
 mirrored=planes[0,1439-coordinates[:,1],coordinates[:,0]]
 values.tofile(out/f'{device}-selected-color.bin');depth.tofile(out/f'{device}-selected-d32.bin')
 bad=np.flatnonzero(values.view('<u4')!=reference.view('<u4'))
 row=dict(device=device,maskPixels=17017,colorVsNative=compare(values),d32VsNative=compare(depth),mirroredRowDiagnostic=compare(mirrored),selectedColorD32BitExact=bool(np.array_equal(values.view('<u4'),depth.view('<u4'))),fullOutputSha256=hashlib.sha256(path.read_bytes()).hexdigest(),examples=[dict(pixel=coordinates[k].tolist(),expected=float(reference[k]),color=float(values[k]),depth=float(depth[k])) for k in bad[:12]])
 rows.append(row)
(out/'native-depth-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
