from pathlib import Path
out=Path(__file__).resolve().parent
base=(out/'native_receiver_cliponly.glsl').read_text()
for mode in ['product','subtract']:
 source=base
 if mode=='product':
  source=source.replace('exactFiniteFma(exactFiniteFma(inputValue.x,uintBitsToFloat(969723085u),0.0),2.0,-1.0)','fma(exactFiniteFma(inputValue.x,uintBitsToFloat(969723085u),0.0),2.0,-1.0)')
  source=source.replace('exactFiniteFma(exactFiniteFma(inputValue.y,uintBitsToFloat(976620385u),0.0),2.0,-1.0)','fma(exactFiniteFma(inputValue.y,uintBitsToFloat(976620385u),0.0),2.0,-1.0)')
 else:
  source=source.replace('exactFiniteFma(inputValue.x,uintBitsToFloat(969723085u),0.0)','inputValue.x*uintBitsToFloat(969723085u)')
  source=source.replace('exactFiniteFma(inputValue.y,uintBitsToFloat(976620385u),0.0)','inputValue.y*uintBitsToFloat(976620385u)')
 (out/f'native_receiver_{mode}.glsl').write_text(source)
 for kind in ['filter','world']:
  (out/f'{mode}-{kind}.comp').write_text((out/f'exact-{kind}.comp').read_text().replace('native_receiver_exact.glsl',f'native_receiver_{mode}.glsl'))
 (out/f'run_{mode}.py').write_text((out/'run.py').read_text().replace('exact-filter',f'{mode}-filter').replace('exact-world',f'{mode}-world'))
 (out/f'analyze_{mode}.py').write_text((out/'analyze.py').read_text().replace('exact-filter',f'{mode}-filter').replace('exact-world',f'{mode}-world').replace("['intel','nvidia']","['intel']").replace('receiver-results.json',f'{mode}-results.json'))
