from pathlib import Path
import subprocess,os,sys
out=Path(__file__).resolve().parent
main=Path('D:/Projects/FYP/Project/AzureRender')
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
mode=sys.argv[1]
if mode=='build':
    with (out/'lookup-build.log').open('wb') as log:
        for name in ['exactclip-filter','exactclip-world']:
            for command in [[str(sdk/'glslc.exe'),'-I'+str(out),str(out/(name+'.comp')),'-o',str(out/(name+'.spv'))],
                            [str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3',str(out/(name+'.spv'))]]:
                subprocess.run(command,check=True,stdout=log,stderr=subprocess.STDOUT)
else:
    os.environ.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if mode=='intel' else '*nv-vk64*',
        VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer')
    for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(key,None)
    os.environ['PATH']=str(main/'build/ninja-msvc-release')+';'+os.environ['PATH']
    for name in ['exactclip-filter','exactclip-world']:
        with (out/(mode+'-'+name+'.log')).open('wb') as log:
            subprocess.run([str(out/'collector.exe'),str(out/(name+'.spv')),str(out/'fixture.json'),
                str(out/(mode+'-'+name+'.bin'))],check=True,stdout=log,stderr=subprocess.STDOUT)
print(mode+' completed')
