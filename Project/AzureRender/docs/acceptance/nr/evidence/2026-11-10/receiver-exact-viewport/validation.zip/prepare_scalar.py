from pathlib import Path
out=Path(__file__).resolve().parent
prior=out.parent/'20261109-234658-native-reciprocal-domain-2562a0'
source=(prior/'native_receiver_lookup.glsl').read_text()
first=source[source.index('vec2 clip='):source.index('\nprecise vec4 world')]
clip='''precise float ux=inputValue.x*uintBitsToFloat(969723085u);
precise float uy=inputValue.y*uintBitsToFloat(976620385u);
precise vec2 clip=vec2(fma(ux,2.0,-1.0),fma(uy,2.0,-1.0));'''
(out/'native_receiver_scalar.glsl').write_text(source.replace(first,clip))
for kind in ['filter','world']:
 (out/f'scalar-{kind}.comp').write_text((out/f'exact-{kind}.comp').read_text().replace('native_receiver_exact.glsl','native_receiver_scalar.glsl'))
(out/'run_scalar.py').write_text((out/'run.py').read_text().replace('exact-filter','scalar-filter').replace('exact-world','scalar-world'))
(out/'analyze_scalar.py').write_text((out/'analyze.py').read_text().replace('exact-filter','scalar-filter').replace('exact-world','scalar-world').replace('receiver-results.json','scalar-results.json'))
