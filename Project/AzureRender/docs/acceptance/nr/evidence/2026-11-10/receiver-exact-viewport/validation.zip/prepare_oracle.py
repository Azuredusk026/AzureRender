from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent
prior=out.parent/'20261109-234658-native-reciprocal-domain-2562a0'
namespace={}
source=(prior/'exact_fma.py').read_text().split("prior=Path(")[0].replace('out=Path(__file__).resolve().parent','').replace('assert power<=127','if power>127:return sign|0x7f800000')
exec(source,namespace)
rng=np.random.default_rng(349928)
triples=rng.integers(0,2**32,size=(65536,3),dtype='<u4')
# Keep finite source operands; retain signs, subnormals and overflow results.
triples&=np.uint32(0xff7fffff)
edge=[0,1,0x7fffff,0x800000,0x3f800000,0x3f800001,0x3fffffff,0x7f7fffff,0x80000001,0xbf800000]
for i in range(1000):triples[i]=[edge[i%10],edge[(i//10)%10],edge[(i//100)%10]]
expected=np.array([namespace['fma'](*row) for row in triples],dtype='<u4')
queries=np.zeros((len(triples),3,4),dtype='<u4');queries[:,0,:3]=triples
queries.tofile(out/'oracle-queries.bin');expected.tofile(out/'oracle-expected.u32')
fixture=dict(width=16,height=8,forwardDepthPath=str(prior/'synthetic-depth.d16'),queryPath=str(out/'oracle-queries.bin'),samples=len(triples),workgroupSize=256)
(out/'oracle-fixture.json').write_text(json.dumps(fixture,indent=2))
shader=(out/'exact-filter.comp').read_text().replace('local_size_x=1','local_size_x=256').replace('#include "native_receiver_exact.glsl"','#include "exact_fma.glsl"')
shader=shader[:shader.index('    }else{')]+'''    }else{
        uint j=(i-11u)*3u;vec4 a=queries.values[j];
        outputData.results[i]=vec4(exactFiniteFma(a.x,a.y,a.z),fma(a.x,a.y,a.z),0.0,1.0);
    }
}
'''
shader=shader.replace('uint i=gl_GlobalInvocationID.x;','uint i=gl_GlobalInvocationID.x;if(i>=65547u)return;')
(out/'oracle.comp').write_text(shader)
runner=(out/'run.py').read_text().replace("['exact-filter','exact-world']","['oracle']").replace("out/'fixture.json'","out/'oracle-fixture.json'")
(out/'run_oracle.py').write_text(runner)
# A narrower candidate keeps the original matrix operations.
source=(prior/'native_receiver_lookup.glsl').read_text()
first=source[source.index('vec2 clip='):source.index('\nprecise vec4 world')]
precise=(out/'native_receiver_exactclip.glsl').read_text()
clip=precise[precise.index('vec2 clip='):precise.index('\nprecise vec4 world')]
(out/'native_receiver_cliponly.glsl').write_text('#include "exact_fma.glsl"\n'+source.replace(first,clip))
for kind in ['filter','world']:
 (out/f'cliponly-{kind}.comp').write_text((out/f'exact-{kind}.comp').read_text().replace('native_receiver_exact.glsl','native_receiver_cliponly.glsl'))
(out/'run_cliponly.py').write_text((out/'run.py').read_text().replace('exact-filter','cliponly-filter').replace('exact-world','cliponly-world'))
(out/'analyze_cliponly.py').write_text((out/'analyze.py').read_text().replace('exact-filter','cliponly-filter').replace('exact-world','cliponly-world').replace('receiver-results.json','cliponly-results.json'))
print('Prepared 65536 exact arithmetic oracle cases and viewport-only candidate')
