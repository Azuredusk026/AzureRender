from pathlib import Path
import json,hashlib
import numpy as np
out=Path(__file__).resolve().parent
prior=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261109-181501-native-producer-gpu-intermediates-de1e3d')
expected=np.fromfile(prior/'expected.u8',dtype='u1').astype('i4')
world=np.fromfile(prior/'native-world.bin',dtype='<f4').reshape(-1,3)
assert len(expected)==len(world)==49384
rows=[]
for device in ['intel','nvidia']:
    result=np.fromfile(out/(device+'-scalar-filter.bin'),dtype='<f4').reshape(-1,4)
    actual_world=np.fromfile(out/(device+'-scalar-world.bin'),dtype='<f4').reshape(-1,4)[:,:3].copy()
    assert result.shape==(49384,4) and np.isfinite(result).all()
    d=abs(np.rint(result[:,2]*255).astype('i4')-expected)
    same=np.all(world.view('<u4')==actual_world.view('<u4'),axis=1)
    for name in ['scalar-filter','scalar-world']:
        log=(out/(device+'-'+name+'.log')).read_text(errors='replace')
        assert 'zero validation errors' in log and 'Device: ' in log
    rows.append(dict(device=device,exactPixels=int((d==0).sum()),pixelsOverOneByte=int((d>1).sum()),
        maximumByteError=int(d.max()),nativeWorldExactPixels=int(same.sum()),
        nativeWorldExactAmongFailures=int((same&(d>1)).sum()),
        worldMaximumAbsolutePerComponent=abs(world-actual_world).max(axis=0).tolist(),
        outputSha256=hashlib.sha256((out/(device+'-scalar-filter.bin')).read_bytes()).hexdigest()))
report=dict(status='diagnostic-reference-lookup',rows=rows,
    scope='Full normalized reciprocal reference in a private compute fixture; fixed sampling footprint and original queries preserved. Production remains unchanged.')
(out/'scalar-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
