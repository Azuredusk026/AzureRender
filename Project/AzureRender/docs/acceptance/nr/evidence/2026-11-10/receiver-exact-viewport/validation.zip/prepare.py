from pathlib import Path
import json,shutil
out=Path(__file__).resolve().parent
prior=out.parent/'20261109-234658-native-reciprocal-domain-2562a0'
for name in ['object_shadow.glsl','collector.exe','native_receiver_lookup.glsl']:
    shutil.copyfile(prior/name,out/name)
source=(out/'native_receiver_lookup.glsl').read_text()
needle='homogeneousPosition=world;'
replacement='''precise float hx=exactFiniteFma(-clip.y,uintBitsToFloat(2887152347u),0.0);
hx=exactFiniteFma(clip.x,uintBitsToFloat(3205463799u),hx);
hx=exactFiniteFma(inputValue.z,uintBitsToFloat(3309010823u),hx);
hx=exactFiniteFma(hx,1.0,uintBitsToFloat(3169993671u));
world.x=hx;homogeneousPosition=world;'''
assert needle in source
(out/'native_receiver_exact.glsl').write_text('#include "exact_fma.glsl"\n'+source.replace(needle,replacement))
for kind in ['filter','world']:
    shader=(prior/f'lookup-{kind}.comp').read_text().replace('native_receiver_lookup.glsl','native_receiver_exact.glsl')
    (out/f'exact-{kind}.comp').write_text(shader)
fixture=json.loads((prior/'lookup-fixture.json').read_text())
(out/'fixture.json').write_text(json.dumps(fixture,indent=2))
runner=(prior/'receiver.py').read_text().replace("['lookup-filter','lookup-world']","['exact-filter','exact-world']").replace("out/'lookup-fixture.json'","out/'fixture.json'")
(out/'run.py').write_text(runner)
analyze=(prior/'analyze_receiver.py').read_text().replace('lookup-filter','exact-filter').replace('lookup-world','exact-world')
(out/'analyze.py').write_text(analyze)
print('Prepared exact finite FMA diagnostic')
