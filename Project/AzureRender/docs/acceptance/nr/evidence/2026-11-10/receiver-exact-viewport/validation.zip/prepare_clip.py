from pathlib import Path
out=Path(__file__).resolve().parent
source=(out/'native_receiver_exact.glsl').read_text()
needle='vec2 clip=fma(inputValue.xy*uintBitsToFloat(uvec4(1159725056u,1152647168u,969723085u,976620385u)).zw,vec2(2.0),vec2(-1.0));'
assert needle in source
source=source.replace(needle,'''vec2 clip=vec2(
exactFiniteFma(exactFiniteFma(inputValue.x,uintBitsToFloat(969723085u),0.0),2.0,-1.0),
exactFiniteFma(exactFiniteFma(inputValue.y,uintBitsToFloat(976620385u),0.0),2.0,-1.0));''')
(out/'native_receiver_exactclip.glsl').write_text(source)
for kind in ['filter','world']:
    shader=(out/f'exact-{kind}.comp').read_text().replace('native_receiver_exact.glsl','native_receiver_exactclip.glsl')
    (out/f'exactclip-{kind}.comp').write_text(shader)
(out/'run_clip.py').write_text((out/'run.py').read_text().replace('exact-filter','exactclip-filter').replace('exact-world','exactclip-world'))
(out/'analyze_clip.py').write_text((out/'analyze.py').read_text().replace('exact-filter','exactclip-filter').replace('exact-world','exactclip-world').replace('receiver-results.json','clip-results.json'))
