from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent;d=json.loads((out/'neutral-state.json').read_text());assert d['status']=='qualified' and len(d['captures'])==1
c=d['captures'][0];assert c['sourceControlQualified'] and c['baselineRestored'] and len(c['runs'])==9 and all(x['qualified'] for x in c['runs']);w=np.zeros((31,3),dtype='<u4')
for r in c['runs']:q=r['case'];w[:,q['component']]|=np.array(r['values'],dtype='<u4')<<q['shift']
a=w.view('<f4');assert np.isfinite(a).all();f=json.loads((out.parent/'20261110-013009-hair-final-float-values-c03e78/results.json').read_text());lookup={tuple(x['pixel']):x for x in f['rows']};rows=[]
for i,p in enumerate(d['points']):
 r=lookup[tuple(p)];v=np.array(r['vulkan']);rows.append(dict(pixel=p,nativeNeutralBits=w[i].tolist(),nativeNeutral=a[i].tolist(),vulkan=r['vulkan'],maximumRemaining=float(abs(a[i]-v).max()),originalMaximum=r['maximumAbsolute'],group=bool(r['parameterSampleExact'] and r['maximumAbsolute']>.001)))
g=[x for x in rows if x['group']];assert len(g)==20;report=dict(status='qualified-native-main-chroma-neutralization',points=31,groupPoints=len(g),groupMaximumRemaining=max(x['maximumRemaining'] for x in g),groupMaximumOriginal=max(x['originalMaximum'] for x in g),rows=rows,qualification=d,execution=json.loads((out/'neutral-execution.json').read_text()));(out/'neutral-results.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ['rows','qualification','execution']})
