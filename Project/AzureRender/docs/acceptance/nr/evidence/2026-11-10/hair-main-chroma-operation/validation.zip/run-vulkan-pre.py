from pathlib import Path
import os,subprocess,json
out=Path(__file__).resolve().parent
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES']:os.environ.pop(key,None)
for key in ['APPDATA','LOCALAPPDATA']:
 p=out/'tmp'/key.lower();p.mkdir(parents=True,exist_ok=True);os.environ[key]=str(p)
os.environ['RENDERDOC_DEBUG_LOG_FILE']=str(out/'tmp/renderdoc.log');os.environ['RDOC_DEBUG_LOG_FILE']=str(out/'tmp/renderdoc.log')
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
with (out/'driver-vulkan-pre.log').open('wb') as log:
 r=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'collect-vulkan-pre.py')],startupinfo=startup,creationflags=subprocess.CREATE_NO_WINDOW,stdout=log,stderr=subprocess.STDOUT)
state=json.loads((out/'vulkan-pre-state.json').read_text());raise SystemExit(r.returncode if r.returncode else (0 if state['status']=='qualified' else 1))
