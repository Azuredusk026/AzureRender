from pathlib import Path
import re,json,shutil,sys,struct,subprocess
out=Path(__file__).resolve().parent;prior=out.parent/'20261109-231408-hair-material-sample-region-5f9f16'
for name in ['dxbc_util.py','D3D12TokenizedProgramFormat.hpp','LICENSE-RenderDoc.txt','checksum-source.json','header-source.json','native-original.shader']:(shutil.copyfile(prior/name,out/name) if not (out/name).is_file() else None)
sys.path.insert(0,str(out));from dxbc_util import chunks,words,instructions,opcode,inst,dest,source,imm,fbits,rebuild,checksum
raw=(out/'native-original.shader').read_bytes();assert checksum(raw)==raw[4:20]
def native_probe(field='pre',component=None,shift=0):
 parts=chunks(raw);idx=next(i for i,(kind,_) in enumerate(parts) if kind in [b'SHEX',b'SHDR']);w=words(parts[idx][1]);items=list(instructions(w))
 declared=next(i for i in items if i[2]==opcode('DCL_TEMPS'));capture=w[declared[1]+1];scratch=capture+1;seen=capture+2;flag=capture+3;w[declared[1]+1]=capture+4
 body=items[items.index(declared)+1:];assert len(body)==2137
 site=body[1354 if field=='pre' else 1356];at,n=site[1],site[3]
 operand=at+1
 while w[operand-1]&0x80000000:operand+=1
 assert site[2]==opcode('MAD') and w[operand+1]==(5 if field=='pre' else 4)
 end=next(i[1] for i in items if i[2]==opcode('RET'));extra=[]
 if component is not None:
  for mask,offset in [(1,shift),(2,shift+6)]:
   extra+=inst('USHR',dest(scratch),source(capture,component),imm(offset));extra+=inst('AND',dest(scratch),source(scratch),imm(63))
   if mask==2 and shift==24:
    extra+=inst('IEQ',dest(flag),source(seen),imm(0));extra+=inst('AND',dest(flag),source(flag),imm(8));extra+=inst('OR',dest(scratch),source(scratch),source(flag))
   extra+=inst('UTOF',dest(scratch),source(scratch));extra+=inst('MUL',dest(scratch),source(scratch),imm(fbits(1/64)));extra+=inst('MOV',dest(0,mask,True),source(scratch))
 w[end:end]=extra
 hook=inst('MOV',dest(capture,7),[2|(1<<2)|(0xe4<<4)|(1<<20),4])
 if field=='pre':hook+=inst('MOV',dest(capture,8),source(5,1))
 hook+=inst('MOV',dest(seen),imm(1));w[at+n:at+n]=hook
 first=body[0][1];assert body[0][2]==opcode('MOV');w[first:first]=inst('MOV',dest(seen),imm(0))
 w[1]=len(w);parts[idx]=(parts[idx][0],struct.pack('<'+'I'*len(w),*w));code=rebuild(raw,parts);assert checksum(code)==code[4:20];return code
(out/'native-output-control.dxbc').write_bytes(native_probe(component=None))
cases=[]
for field,n in [('pre',4),('post',3)]:
 for component in range(n):
  for shift in [0,12,24]:
   name=f'{field}-{component}-{shift}';(out/(name+'.dxbc')).write_bytes(native_probe(field,component,shift));cases.append(dict(name=name,field=field,component=component,components=n,shift=shift))
(out/'cases.json').write_text(json.dumps(cases,indent=2))
print('Prepared 21 native main-composite chroma probes')
