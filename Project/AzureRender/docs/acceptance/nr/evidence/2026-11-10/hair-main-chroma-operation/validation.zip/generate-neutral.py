from pathlib import Path
import sys,struct,json,subprocess
out=Path(__file__).resolve().parent;sys.path.insert(0,str(out))
from dxbc_util import chunks,words,instructions,opcode,inst,dest,source,imm,fbits,rebuild,checksum
raw=(out/'native-original.shader').read_bytes();assert checksum(raw)==raw[4:20]
parts=chunks(raw);idx=next(i for i,(kind,_) in enumerate(parts) if kind in [b'SHEX',b'SHDR']);w=words(parts[idx][1]);items=list(instructions(w));decl=next(i for i in items if i[2]==opcode('DCL_TEMPS'));body=items[items.index(decl)+1:];assert len(body)==2137
site=body[1354];assert site[2]==opcode('MAD');assert w[site[1]+2]==5
w[site[1]+site[3]:site[1]+site[3]]=inst('MOV',dest(5,2),imm(fbits(1.0)));w[1]=len(w);parts[idx]=(parts[idx][0],struct.pack('<'+'I'*len(w),*w));raw=rebuild(raw,parts);assert checksum(raw)==raw[4:20];(out/'neutral-base.dxbc').write_bytes(raw)
ops={opcode(n) for n in ['MOV','MUL','MAD','ADD','MAX','MIN','MOVC']}
def native_probe(component=None,shift=0):
 parts=chunks(raw);idx=next(i for i,(kind,_) in enumerate(parts) if kind in [b'SHEX',b'SHDR']);w=words(parts[idx][1]);items=list(instructions(w))
 decl=next(i for i in items if i[2]==opcode('DCL_TEMPS'));capture=w[decl[1]+1];scratch=capture+1;w[decl[1]+1]=capture+2
 writes=[]
 for pc,at,op,n in items:
  if op not in ops:continue
  operand=at+1
  while w[operand-1]&0x80000000:operand+=1
  token=w[operand]
  if ((token>>12)&255)==2 and w[operand+1]==0:writes.append((at,n,operand,token))
 assert len(writes)==3
 for at,n,operand,token in reversed(writes):
  w[operand]=token&~(255<<12);w[operand+1]=capture
  w[at+n:at+n]=inst('MOV',[token,0],[2|(1<<2)|(0xe4<<4)|(1<<20),capture])
 w[1]=len(w)
 if component is not None:
  end=next(i[1] for i in instructions(w) if i[2]==opcode('RET'));extra=[]
  for mask,offset in [(1,shift),(2,shift+6)]:
   extra+=inst('USHR',dest(scratch),source(capture,component),imm(offset));extra+=inst('AND',dest(scratch),source(scratch),imm(63))
   extra+=inst('UTOF',dest(scratch),source(scratch));extra+=inst('MUL',dest(scratch),source(scratch),imm(fbits(1/64)));extra+=inst('MOV',dest(0,mask,True),source(scratch))
  w[end:end]=extra
 w[1]=len(w);parts[idx]=(parts[idx][0],struct.pack('<'+'I'*len(w),*w));code=rebuild(raw,parts);assert checksum(code)==code[4:20];return code
(out/'neutral-output-control.dxbc').write_bytes(native_probe());cases=[]
for component in range(3):
 for shift in [0,12,24]:
  name=f'neutral-final-{component}-{shift}';(out/(name+'.dxbc')).write_bytes(native_probe(component,shift));cases.append(dict(name=name,field='neutralFinal',component=component,components=3,shift=shift))
(out/'cases-neutral.json').write_text(json.dumps(cases,indent=2));print('Prepared single-factor neutralization and nine native final-float probes')
