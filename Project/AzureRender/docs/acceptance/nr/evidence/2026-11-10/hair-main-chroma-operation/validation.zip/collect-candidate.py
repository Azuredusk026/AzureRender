from pathlib import Path
import renderdoc as rd
import json,zlib,hashlib,traceback,sys,struct
out=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-024017-hair-main-chroma-operation-d9ef14')
prior=out.parent/'20261109-221435-hair-color-closure-430845';capture=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc')
result=dict(status='starting',variants=[]);cap=None;c=None;original=None;replacement=None
def save():(out/'candidate-state.json').write_text(json.dumps(result,indent=2)+'\n')
def snapshot(event,stride):
 c.SetFrameEvent(event,True);target=c.GetPipelineState().GetOutputTargets()[0].resource
 data=bytes(c.GetTextureData(target,rd.Subresource()));assert len(data)==2560*1440*stride
 return b''.join(data[(y*2560+1140)*stride:(y*2560+1430)*stride] for y in range(130,440))
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(capture),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 baseline=snapshot(493,8);assert hashlib.sha256(baseline).hexdigest()=='5cb648f7489caac695a104eb40af7e204a964e29780d9681349de6af0d5b8057'
 original=c.GetPipelineState().GetShader(rd.ShaderStage.Pixel)
 for name in ['control','candidate']:
  result['activeVariant']=name;save()
  code=(out/(name+'.spv')).read_bytes()
  replacement,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,code,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert replacement!=rd.ResourceId.Null(),errors
  c.ReplaceResource(original,replacement)
  hdr=snapshot(493,8);final=snapshot(567,4)
  (out/(name+'-hdr.zlib')).write_bytes(zlib.compress(hdr,9));(out/(name+'-final.zlib')).write_bytes(zlib.compress(final,9))
  if name=='activation':
   expected=zlib.decompress((prior/'native-visibility-hdr.zlib').read_bytes())
   points=json.loads((out/'source-control.json').read_text())['points']
   active=[struct.unpack_from('<HH',hdr,((y-130)*290+x-1140)*8)==(0x3000,0x3600) for x,y in points]
   blueExact=all(hdr[i+4:i+6]==expected[i+4:i+6] for i in range(0,len(hdr),8))
   result['activationQualification']=dict(points=len(points),activePoints=sum(active),allPointsActive=all(active),blueExact=blueExact);save()
   assert all(active) and result['activationQualification']['blueExact'],result['activationQualification']
  if name in ['control','identity']:
   qualification=dict(hdrExact=hdr==zlib.decompress((prior/'native-visibility-hdr.zlib').read_bytes()),finalExact=final==zlib.decompress((prior/'native-visibility-final.zlib').read_bytes()))
   result[name+'Qualification']=qualification;save()
   assert all(qualification.values()),(name,qualification)
  c.RemoveReplacement(original);c.FreeTargetResource(replacement);replacement=None
  assert snapshot(493,8)==baseline
  result['variants'].append(dict(name=name,baselineRestored=True,shaderSha256=hashlib.sha256(code).hexdigest(),hdrSha256=hashlib.sha256(hdr).hexdigest(),finalSha256=hashlib.sha256(final).hexdigest()));save()
 result.update(status='collected',debugMessages=[str(m.description) for m in c.GetDebugMessages()])
except BaseException:result.update(status='failed',error=traceback.format_exc())
finally:
 if c:
  if original:
   c.RemoveReplacement(original)
   result['cleanupBaselineRestored']=snapshot(493,8)==baseline
  if replacement:c.FreeTargetResource(replacement)
  c.Shutdown()
 if cap:cap.Shutdown()
 save()
sys.exit(0 if result['status']=='collected' else 1)
