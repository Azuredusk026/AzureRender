from pathlib import Path
import json,zipfile,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];r=json.loads((out/'results.json').read_text());neutral=json.loads((out/'neutral-results.json').read_text());candidate=json.loads((out/'candidate-results.json').read_text());parts=json.loads((out/'vulkan-parts-results.json').read_text());pre=json.loads((out/'vulkan-pre-results.json').read_text())
r['neutralizationSummary']={k:v for k,v in neutral.items() if k not in ['rows','qualification','execution']};r['candidateSummary']=[{k:v for k,v in x.items() if k!='failures'} for x in candidate['rows']];r['vulkanProbeScope']=[pre['scope'],parts['scope']];r['execution']=json.loads((out/'execution.json').read_text());r['remainingScope']='Native single-factor neutralization qualifies the missing main-composite chroma operation. The private Vulkan beauty-minus-ambientSpecular candidate fails the complete region and is rejected. Clustered local lights require an explicit separate main-composite boundary before any production change.'
assert r['execution']['exitCode']==0 and candidate['execution']['exitCode']==0 and neutral['execution']['exitCode']==0
assert all(x['execution']['exitCode']==0 for x in [pre,parts]);(out/'results.json').write_text(json.dumps(r,indent=2)+'\n')
dest=root/'docs/acceptance/nr/evidence/2026-11-10/hair-main-chroma-operation';dest.mkdir(parents=True,exist_ok=True);files=[p for p in out.iterdir() if p.is_file() and p.suffix in ('.py','.json','.dxbc','.spv','.shader','.bin','.zlib','.hpp','.txt','.log')];members={p.name:p.read_bytes() for p in sorted(files)}
for name in ['main-chroma-candidate.spvasm','vulkan-pre-0-0.spvasm','vulkan-diffuse-hair-rim-0-0.spvasm']:members[name]=(out/name).read_bytes()
for name in ['renderdoc_replay.py','renderdoc_capture.py']:members['support/'+name]=(Path('D:/Projects/FYP/Project/AzureRender/tools/native_render')/name).read_bytes()
with zipfile.ZipFile(dest/'validation.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,b in members.items():z.writestr(name,b)
b=(dest/'validation.zip').read_bytes();assert len(b)<8*1024*1024;r['archiveFiles']=[dict(path=n,bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for n,v in members.items()];r['archiveBytes']=len(b);r['archiveSha256']=hashlib.sha256(b).hexdigest();(dest/'results.json').write_text(json.dumps(r,indent=2)+'\n');z=zipfile.ZipFile(dest/'validation.zip');assert z.testzip() is None
for x in r['archiveFiles']:b=z.read(x['path']);assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
print('Archive verified',len(r['archiveFiles']),r['archiveBytes'],r['archiveSha256'])
