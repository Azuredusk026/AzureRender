from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent;d=json.loads((out/'state.json').read_text());assert d['status']=='qualified' and len(d['captures'])==1
c=d['captures'][0];assert c['sourceControlQualified'] and c['baselineRestored'] and len(c['runs'])==21 and all(r['qualified'] for r in c['runs'])
allowed={'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU','NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image'}
assert set(c['debugMessages'])<=allowed
values={}
for field,n in [('pre',4),('post',3)]:
 words=np.zeros((len(d['points']),n),dtype='<u4');flags=[]
 for r in c['runs']:
  q=r['case']
  if q['field']!=field:continue
  a=np.array(r['values'],dtype='<u4')
  if q['shift']==24:flags.extend((a>>8).tolist());a &=255
  words[:,q['component']] |= a<<q['shift']
 assert len(flags)==len(d['points'])*n and all(v==0 for v in flags);assert np.isfinite(words.view('<f4')).all();values[field]=words
f=json.loads((out.parent/'20261110-013009-hair-final-float-values-c03e78/results.json').read_text());lookup={tuple(r['pixel']):r for r in f['rows']};rows=[];coeff=np.array([.21267290413379669,.7151522040367126,.07217500358819962],dtype='f8')
for i,pixel in enumerate(d['points']):
 pre=values['pre'][i].view('<f4').astype('f8');post=values['post'][i].view('<f4').astype('f8');final=lookup[tuple(pixel)];delta=post-pre[:3];difference=np.array(final['native'])-np.array(final['vulkan']);residual=difference-delta;luma=float(np.dot(pre[:3],coeff));prediction=luma+pre[3]*(pre[:3]-luma)
 rows.append(dict(pixel=pixel,preBits=values['pre'][i].tolist(),postBits=values['post'][i].tolist(),pre=pre.tolist(),post=post.tolist(),operationDelta=delta.tolist(),finalDifference=difference.tolist(),unexplainedAfterOperationDelta=residual.tolist(),maximumDelta=float(abs(delta).max()),maximumFinalDifference=float(abs(difference).max()),maximumUnexplained=float(abs(residual).max()),cpuPredictionMaximumError=float(abs(post-prediction).max()),largeChromaStableMaterialGroup=bool(final['parameterSampleExact'] and final['maximumAbsolute']>.001)))
group=[r for r in rows if r['largeChromaStableMaterialGroup']];assert len(group)==20
report=dict(status='qualified-native-main-chroma-operation',points=len(rows),largeChromaStableMaterialGroup=dict(points=len(group),maximumFinalDifference=max(r['maximumFinalDifference'] for r in group),maximumOperationDelta=max(r['maximumDelta'] for r in group),maximumUnexplainedAfterOperationDelta=max(r['maximumUnexplained'] for r in group)),maximumCpuPredictionError=max(r['cpuPredictionMaximumError'] for r in rows),rows=rows,qualification=d,scope='Actual native main-composite color before/after brightness-dependent saturation, plus its exact gain. Final shader differences are separately qualified prior evidence. Delta attribution is numerical evidence; production candidate still requires complete region validation.')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['rows','qualification']},indent=2));print(json.dumps(rows[7],indent=2))
