from pathlib import Path
import re,json,subprocess
out=Path(__file__).resolve().parent
base=out.parent/'20261109-221435-hair-color-closure-430845';original=(base/'native-visibility.spvasm').read_text();sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin');cases=[]
for field,n in [('responseScene',4)]:
 for component in range(n):
  for shift in [0,12,24]:
   name=f'vulkan-pre-{component}-{shift}';text=original;decl=[]
   def existing(pattern,definition,key):
    match=re.search(r'(%\S+) = '+pattern+r'\n',text)
    if match:return match[1]
    tag='%diffuse_probe_'+key;decl.append(tag+' = '+definition);return tag
   p4=existing('OpTypePointer Private %v4float','OpTypePointer Private %v4float','p4');p2=existing('OpTypePointer Private %v2float','OpTypePointer Private %v2float','p2');pb=existing('OpTypePointer Private %bool','OpTypePointer Private %bool','pb')
   u4=existing('OpTypeVector %uint 4','OpTypeVector %uint 4','u4');u2=existing('OpTypeVector %uint 2','OpTypeVector %uint 2','u2');b4=existing('OpTypeVector %bool 4','OpTypeVector %bool 4','b4');b2=existing('OpTypeVector %bool 2','OpTypeVector %bool 2','b2')
   decl += ['%diffuse_probe_z4 = OpConstantNull %v4float','%diffuse_probe_z2 = OpConstantNull %v2float','%diffuse_probe_false = OpConstantFalse %bool','%diffuse_probe_true = OpConstantTrue %bool',
    f'%diffuse_probe_responseScene = OpVariable {p4} Private %diffuse_probe_z4',f'%diffuse_probe_masks = OpVariable {p2} Private %diffuse_probe_z2',f'%diffuse_probe_seen = OpVariable {pb} Private %diffuse_probe_false',f'%diffuse_probe_varied = OpVariable {pb} Private %diffuse_probe_false',
    '%diffuse_probe_scale = OpConstant %float 0.015625','%diffuse_probe_mask = OpConstant %uint 63',f'%diffuse_probe_shift_r = OpConstant %uint {shift}',f'%diffuse_probe_shift_g = OpConstant %uint {shift+6}','%diffuse_probe_two = OpConstant %uint 2']
   offset=text.index('       %main = OpFunction');text=text[:offset]+'\n'.join(decl)+'\n'+text[offset:]
   hook=f'''%response_color = OpLoad %v3float %beautyColor
%response_r = OpCompositeExtract %float %response_color 0
%response_g = OpCompositeExtract %float %response_color 1
%response_b = OpCompositeExtract %float %response_color 2
%response_rgba = OpCompositeConstruct %v4float %response_r %response_g %response_b %float_1
%response_maskVec = OpCompositeConstruct %v2float %float_0 %float_0
%diffuse_old_r = OpLoad %v4float %diffuse_probe_responseScene
%diffuse_old_u = OpLoad %v2float %diffuse_probe_masks
%diffuse_or_bits = OpBitcast {u4} %diffuse_old_r
%diffuse_ou_bits = OpBitcast {u2} %diffuse_old_u
%diffuse_nr_bits = OpBitcast {u4} %response_rgba
%diffuse_nu_bits = OpBitcast {u2} %response_maskVec
%diffuse_r_ne = OpINotEqual {b4} %diffuse_or_bits %diffuse_nr_bits
%diffuse_u_ne = OpINotEqual {b2} %diffuse_ou_bits %diffuse_nu_bits
%diffuse_r_any = OpAny %bool %diffuse_r_ne
%diffuse_u_any = OpAny %bool %diffuse_u_ne
%diffuse_any = OpLogicalOr %bool %diffuse_r_any %diffuse_u_any
%diffuse_seen = OpLoad %bool %diffuse_probe_seen
%diffuse_changed = OpLogicalAnd %bool %diffuse_seen %diffuse_any
%diffuse_prior = OpLoad %bool %diffuse_probe_varied
%diffuse_varied = OpLogicalOr %bool %diffuse_prior %diffuse_changed
OpStore %diffuse_probe_varied %diffuse_varied
OpStore %diffuse_probe_responseScene %response_rgba
OpStore %diffuse_probe_masks %response_maskVec
OpStore %diffuse_probe_seen %diffuse_probe_true
'''
   needle='%13136 = OpLabel';assert text.count(needle)==1;text=text.replace(needle,needle+'\n'+hook)
   start=text.index('%main = OpFunction');end=text.index('OpFunctionEnd',start);body=text[start:end];assert body.count('OpReturn\n')==1
   probe=f'''%diffuse_probe_loaded = OpLoad %v{n}float %diffuse_probe_{field}
%diffuse_probe_value = OpCompositeExtract %float %diffuse_probe_loaded {component}
%diffuse_probe_bits = OpBitcast %uint %diffuse_probe_value
%diffuse_probe_rs = OpShiftRightLogical %uint %diffuse_probe_bits %diffuse_probe_shift_r
%diffuse_probe_gs = OpShiftRightLogical %uint %diffuse_probe_bits %diffuse_probe_shift_g
%diffuse_probe_rb = OpBitwiseAnd %uint %diffuse_probe_rs %diffuse_probe_mask
%diffuse_probe_gbase = OpBitwiseAnd %uint %diffuse_probe_gs %diffuse_probe_mask
'''
   if shift==24:
    probe+='''%diffuse_probe_seen_final = OpLoad %bool %diffuse_probe_seen
%diffuse_probe_unseen = OpLogicalNot %bool %diffuse_probe_seen_final
%diffuse_probe_varied_final = OpLoad %bool %diffuse_probe_varied
%diffuse_probe_vflag = OpSelect %uint %diffuse_probe_varied_final %uint_1 %uint_0
%diffuse_probe_uflag = OpSelect %uint %diffuse_probe_unseen %diffuse_probe_two %uint_0
%diffuse_probe_flags = OpBitwiseOr %uint %diffuse_probe_vflag %diffuse_probe_uflag
%diffuse_probe_fshift = OpShiftLeftLogical %uint %diffuse_probe_flags %diffuse_probe_two
%diffuse_probe_gb = OpBitwiseOr %uint %diffuse_probe_gbase %diffuse_probe_fshift
'''
   else:probe+='%diffuse_probe_gb = OpCopyObject %uint %diffuse_probe_gbase\n'
   probe+='''%diffuse_probe_rf = OpConvertUToF %float %diffuse_probe_rb
%diffuse_probe_gf = OpConvertUToF %float %diffuse_probe_gb
%diffuse_probe_r = OpFMul %float %diffuse_probe_rf %diffuse_probe_scale
%diffuse_probe_g = OpFMul %float %diffuse_probe_gf %diffuse_probe_scale
%diffuse_probe_original = OpLoad %v4float %outputColor
%diffuse_probe_b = OpCompositeExtract %float %diffuse_probe_original 2
%diffuse_probe_a = OpCompositeExtract %float %diffuse_probe_original 3
%diffuse_probe_color = OpCompositeConstruct %v4float %diffuse_probe_r %diffuse_probe_g %diffuse_probe_b %diffuse_probe_a
OpStore %outputColor %diffuse_probe_color
OpReturn
'''
   text=text[:start]+body.replace('OpReturn\n',probe)+text[end:];(out/(name+'.spvasm')).write_text(text)
   for command in [[str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/(name+'.spvasm')),'-o',str(out/(name+'.spv'))],[str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/(name+'.spv'))]]:subprocess.run(command,check=True)
   cases.append(dict(name=name,field=field,component=component,components=n,shift=shift))
(out/'cases-vulkan-pre.json').write_text(json.dumps(cases,indent=2));print('Prepared twelve Vulkan main-composite color probes')
