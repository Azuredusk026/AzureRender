from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent;d=json.loads((out/'vulkan-parts-state.json').read_text());assert d['status']=='qualified' and len(d['captures'])==1;c=d['captures'][0];assert c['sourceControlQualified'] and c['baselineRestored'] and not c['debugMessages'] and len(c['runs'])==12 and all(x['qualified'] for x in c['runs']);w=np.zeros((31,4),dtype='<u4');flags=[]
for r in c['runs']:
 q=r['case'];a=np.array(r['values'],dtype='<u4')
 if q['shift']==24:flags.extend((a>>8).tolist());a &=255
 w[:,q['component']]|=a<<q['shift']
assert len(flags)==124 and all(v==0 for v in flags);a=w.view('<f4');assert np.isfinite(a).all();r=dict(status='qualified-vulkan-parts-reflection-update-color',points=31,rows=[dict(pixel=p,bits=w[i].tolist(),value=a[i].tolist()) for i,p in enumerate(d['points'])],qualification=d,execution=json.loads((out/'vulkan-parts-execution.json').read_text()),scope='Actual sum of diffuse, both hair lobes and rim after stripe modulation. Clustered local-light terms are already present; it is not identical in scope to native pre-saturation main color.');(out/'vulkan-parts-results.json').write_text(json.dumps(r,indent=2)+'\n');print('All 31 Vulkan colors and 124 flags qualified')
