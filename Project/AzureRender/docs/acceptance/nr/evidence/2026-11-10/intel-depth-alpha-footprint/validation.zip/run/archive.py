from pathlib import Path
import hashlib,json,zipfile,re
engine=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender');out=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda n:json.loads((out/n).read_text(encoding='utf-8'))
result=read('results.json');assert all(x['probeD32ControlBitExact'] and x['colorDepthControlBitExact'] and x['alphaPredicateVsFrontDepthDisagreements']==0 for x in result['controls'])
assert len(read('attribute-runs.json'))==8 and all(x['depthControlExact'] and x['alphaControlExact'] for x in read('attribute-runs.json'))
assert all(x['candidateDepthUnchanged'] and x['candidateVisibilityUnchanged'] for x in read('candidate-summary.json'))
doc=engine/'docs/acceptance/nr/intel-depth-alpha-footprint.md';files={'source/docs/acceptance/nr/intel-depth-alpha-footprint.md':doc}
files.update({'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.json','.py','.log','.bin','.cpp','.hpp','.frag'}})
for folder in ['control-shaders','probe-shaders','attribute-shaders','candidate-shaders']:
 files.update({'run/'+folder+'/'+p.name:p for p in (out/folder).iterdir() if p.is_file()})
for name in ['src/render/ReferenceDepth.cpp','src/render/ReferenceDepth.hpp','shaders/material_uv_gradients.glsl','src/render/MaterialUvGradients.hpp']:files['source/'+name]=engine/name
dest=engine/'docs/acceptance/nr/evidence/2026-11-10/intel-depth-alpha-footprint';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.writestr('manifest.json',json.dumps(members,ensure_ascii=False,indent=2))
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,value in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==value['sha256']
result.update(overall='failed-user-review',sourceCommit='f100244',candidateStatus='isolated-no-change-to-original97-failures',candidate=read('candidate-summary.json'),defaultRegression=read('default-regression-reuse.json'),archive={'members':len(members)+1,'bytes':archive.stat().st_size,'sha256':sha(archive)})
(dest/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for link in re.findall(r'\]\(([^)]+)\)',doc.read_text(encoding='utf-8')):assert (doc.parent/link).exists(),link
print(json.dumps(result['archive']))
