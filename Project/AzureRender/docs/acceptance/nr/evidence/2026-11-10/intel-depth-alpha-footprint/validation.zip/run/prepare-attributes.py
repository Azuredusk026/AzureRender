from pathlib import Path
import json,sys,subprocess,hashlib,numpy as np
out=Path(__file__).resolve().parent;prior=out.parent/'20261110-173835-reference-depth-coverage-4b4afc';sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a';token=s.acquire_inputs(out.parents[1],out,['20261110-030251-hair-main-chroma-public-9e799c'],owner);p=Path('D:/Projects/FYP-coordination/quality-claim.json');v=json.loads(p.read_text(encoding='utf-8'));v['localInputLease'].append(token);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ['native-synthetic.cpp','private-compute-fixture.hpp']:(out/name).write_bytes((prior/name).read_bytes())
source=(prior/'native-coverage.cpp').read_text(encoding='utf-8');needle='geometry.surface.alpha->channel=0;';assert needle in source;source=source.replace(needle,'geometry.surface.alpha->channel=c.value("channel",0U);');(out/'native-coverage.cpp').write_text(source,encoding='utf-8')
commands=json.loads((prior/'native-build-commands.json').read_text());commands=[c.replace(prior.as_posix(),out.as_posix()).replace(str(prior),str(out)) for c in commands];assert all(str(prior/'native-coverage.obj') not in c for c in commands);(out/'attribute-build-commands.json').write_text(json.dumps(commands,indent=2)+'\n');(out/'native-link').mkdir(exist_ok=True)
folder=out/'attribute-shaders';folder.mkdir(exist_ok=True)
for name in ['reference_depth.vert.spv','reference_depth.frag.spv','reference_depth_masked.vert.spv']:(folder/name).write_bytes((out/'control-shaders'/name).read_bytes())
r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslangValidator.exe','-V','--target-env','vulkan1.0','-o',str(folder/'reference_depth_masked.frag.spv'),str(out/'attributes.frag')],capture_output=True,text=True);assert r.returncode==0,r.stderr
r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(folder/'reference_depth_masked.frag.spv')],capture_output=True,text=True);assert r.returncode==0,r.stderr
# All baseline image information used below is retained as exact original-mask
# samples and full-file fingerprints before freeing this task's four big planes.
config=json.loads((out/'unmasked-config.json').read_text());q=np.fromfile(config['queries'],dtype='<f4').reshape(-1,4);x=q[:,0].astype(int);y=q[:,1].astype(int);removed=[]
for device in ['nvidia','intel']:
 for scope in ['control','probe']:
  path=(out/f'{device}-{scope}-r32.bin').resolve();assert path.parent==out.resolve();raw=path.read_bytes();values=np.frombuffer(raw,dtype='<f4').reshape(1440,2560)[y,x];values.tofile(out/f'{device}-{scope}-selected-r32.bin');removed.append({'file':path.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'preservedSelected':17017});path.unlink()
(out/'raw-plane-compaction.json').write_text(json.dumps(removed,indent=2)+'\n');print('Attribute source controls prepared within64MiB')
