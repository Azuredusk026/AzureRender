#version 450
layout(location=0) in vec2 textureCoordinate;
layout(binding=0) uniform sampler2D alphaMask;
layout(push_constant) uniform Projection {vec4 columns[4];vec4 jitter;uvec4 control;vec4 coverage;} projection;
layout(location=0) out float alphaSample;
void main(){alphaSample=texture(alphaMask,textureCoordinate,projection.coverage.y)[projection.control.y];}
