from pathlib import Path
import json,subprocess,os,re,numpy as np
out=Path(__file__).resolve().parent;build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release';commands=json.loads((out/'attribute-build-commands.json').read_text());wrapper=subprocess.list2cmdline(['D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'])
with (out/'attribute-build.log').open('wb') as log:
 for command in commands:
  r=subprocess.run(wrapper+' '+command,cwd=build,shell=True,stdout=log,stderr=subprocess.STDOUT);assert r.returncode==0,r.returncode
for suffix in ['obj','pdb','lib']:
 p=(out/('native-coverage.'+suffix)).resolve();assert p.parent==out.resolve()
 if p.exists():p.unlink()
config=json.loads((out/'unmasked-config.json').read_text());q=np.fromfile(config['queries'],dtype='<f4').reshape(-1,4);x=q[:,0].astype(int);y=q[:,1].astype(int);rows=[]
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(build)+';'+env['PATH'])
 referenceDepth=np.fromfile(out/f'{device}-control-selected-d32.bin',dtype='<u4')
 for channel,name in [(0,'alpha'),(1,'u'),(2,'v'),(3,'lod')]:
  c={**config,'channel':channel};path=out/(device+'-attribute-config.json');path.write_text(json.dumps(c,indent=2)+'\n');prefix=out/(device+'-attribute-'+name);command=[str(out/'native-coverage.exe'),str(out/'attribute-shaders'),str(path),str(prefix)]
  with (out/(device+'-attribute-'+name+'.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
  text=(out/(device+'-attribute-'+name+'.log')).read_text(errors='replace');assert r.returncode==0 and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I),text[-2500:]
  actualDepth=np.fromfile(str(prefix)+'-selected-d32.bin',dtype='<u4');assert np.array_equal(referenceDepth,actualDepth),(device,name,'D32 control changed')
  image=Path(str(prefix)+'-r32.bin');values=np.fromfile(image,dtype='<f4').reshape(1440,2560)[y,x];values.tofile(out/f'{device}-attribute-{name}-selected.bin')
  if channel==0:assert np.array_equal(values.view('u4'),np.fromfile(out/f'{device}-selected-alpha.bin',dtype='<u4')),(device,'Alpha control changed; attribute probe not qualified')
  assert image.resolve().parent==out.resolve();image.unlink();rows.append({'device':device,'field':name,'depthControlExact':True,'alphaControlExact':True});(out/'attribute-runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(device,name,'qualified',flush=True)
