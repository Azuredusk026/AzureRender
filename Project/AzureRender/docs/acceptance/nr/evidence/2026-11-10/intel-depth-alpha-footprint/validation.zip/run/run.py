from pathlib import Path
import json,subprocess,os,re,time
out=Path(__file__).resolve().parent;prior=out.parent/'20261110-173835-reference-depth-coverage-4b4afc';rows=[]
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(prior)+';'+str(out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release')+';'+env['PATH'])
 for scope in ['control','probe']:
  label=device+'-'+scope;command=[str(prior/'native-coverage.exe'),str(out/(scope+'-shaders')),str(out/'unmasked-config.json'),str(out/label)];start=time.monotonic()
  with (out/(label+'.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
  text=(out/(label+'.log')).read_text(errors='replace');clean=not bool(re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I));assert r.returncode==0 and clean,text[-2500:]
  rows.append({'device':device,'scope':scope,'exitCode':r.returncode,'seconds':time.monotonic()-start,'validationClean':clean,'command':command});(out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,'source output collected',flush=True)
