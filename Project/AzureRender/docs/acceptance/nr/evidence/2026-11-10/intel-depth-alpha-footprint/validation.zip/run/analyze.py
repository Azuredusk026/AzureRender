from pathlib import Path
import json,numpy as np
out=Path(__file__).parent;prior=out.parent/'20261110-173835-reference-depth-coverage-4b4afc';config=json.loads((out/'unmasked-config.json').read_text());q=np.fromfile(config['queries'],dtype='<f4').reshape(-1,4);x=q[:,0].astype(int);y=q[:,1].astype(int)
alphas={};depths={};controls=[]
for device in ['nvidia','intel']:
 control=np.fromfile(out/f'{device}-control-selected-d32.bin',dtype='<f4');probe=np.fromfile(out/f'{device}-probe-selected-d32.bin',dtype='<f4');assert len(control)==17017 and np.array_equal(control.view('u4'),probe.view('u4')),(device,'unmasked D32 identity failed')
 depthImage=np.fromfile(out/f'{device}-control-r32.bin',dtype='<f4').reshape(1440,2560);assert np.array_equal(depthImage[y,x].view('u4'),control.view('u4'))
 alpha=np.fromfile(out/f'{device}-probe-r32.bin',dtype='<f4').reshape(1440,2560)[y,x];assert np.isfinite(alpha).all() and ((alpha>=0)&(alpha<=1)).all();alpha.tofile(out/f'{device}-selected-alpha.bin');alphas[device]=alpha;depths[device]=control
 actual=np.fromfile(prior/f'native-{device}-r32.bin',dtype='<f4').reshape(1440,2560)[y,x];accepted=actual.view('u4')==control.view('u4');predicate=alpha>=.5
 controls.append({'device':device,'probeD32ControlBitExact':True,'colorDepthControlBitExact':True,'sampledAlphaRange':[float(alpha.min()),float(alpha.max())],'alphaPredicateVsFrontDepthDisagreements':int((accepted!=predicate).sum())})
lookup={(int(px),int(py)):k for k,(px,py) in enumerate(q[:,:2])};failures=json.loads((prior/'native-analysis.json').read_text())[1]['failures'];indices=np.array([lookup[tuple(row['texturePixel'])] for row in failures]);large=np.array([lookup[tuple(row['texturePixel'])] for row in failures if row['depthUlp']>1]);ulp=np.abs(depths['nvidia'].view('u4').astype('i8')-depths['intel'].view('u4').astype('i8'));cross=(alphas['nvidia']>=.5)!=(alphas['intel']>=.5)
rows=[]
for label,selection in [('all17017',np.arange(17017)),('all97Failures',indices),('large21Failures',large)]:
 rows.append({'scope':label,'pixels':len(selection),'alphaPredicateDifferences':int(cross[selection].sum()),'unmaskedDepthExact':int((ulp[selection]==0).sum()),'unmaskedDepthWithinOneUlp':int((ulp[selection]<=1).sum()),'unmaskedDepthBeyondOneUlp':int((ulp[selection]>1).sum()),'alphaMaxDifference':float(np.max(abs(alphas['nvidia'][selection]-alphas['intel'][selection])))})
details=[]
for row in failures:
 k=lookup[tuple(row['texturePixel'])];details.append({**row,'alphaNvidia':float(alphas['nvidia'][k]),'alphaIntel':float(alphas['intel'][k]),'alphaPredicateDifferent':bool(cross[k]),'unmaskedDepthUlpBetweenDevices':int(ulp[k])})
result={'status':'qualified-alpha-probe-unmasked-depth-control-identical','controls':controls,'scopes':rows,'failures':details};(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'controls':controls,'scopes':rows},indent=2))
