#version 450
#extension GL_GOOGLE_include_directive : require
#include "material_uv_gradients.glsl"
layout(location=0) in vec2 textureCoordinate;
layout(binding=0) uniform sampler2D alphaMask;
layout(push_constant) uniform Projection {vec4 columns[4];vec4 jitter;uvec4 control;vec4 coverage;} projection;
layout(location=0) out float surfaceDepth;
void main(){
    mat2 gradients=azureMirroredCoarseUvGradients(textureCoordinate);
    float scale=exp2(projection.coverage.y);
    if(textureGrad(alphaMask,textureCoordinate,gradients[0]*scale,gradients[1]*scale)[projection.control.y]<projection.coverage.x)discard;
    surfaceDepth=gl_FragCoord.z;
}
