#version 450
layout(location=0) in vec2 textureCoordinate;
layout(binding=0) uniform sampler2D alphaMask;
layout(push_constant) uniform Projection {vec4 columns[4];vec4 jitter;uvec4 control;vec4 coverage;} projection;
layout(location=0) out float diagnosticValue;
void main(){
    float alpha=texture(alphaMask,textureCoordinate,projection.coverage.y).r;
    vec4 values=vec4(alpha,textureCoordinate,textureQueryLod(alphaMask,textureCoordinate).y);
    diagnosticValue=values[projection.control.y];
}
