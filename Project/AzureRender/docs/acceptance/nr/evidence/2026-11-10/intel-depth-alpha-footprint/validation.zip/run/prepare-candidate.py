from pathlib import Path
import json,subprocess,sys
out=Path(__file__).resolve().parent;root=out.parents[2];prior=out.parent/'20261110-173835-reference-depth-coverage-4b4afc';sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a';token=s.acquire_inputs(out.parents[1],out,['20261110-003435-visibility-numeric-contract-4f95e7','20261110-003031-reciprocal-compact-profile-4e7929'],owner);p=Path('D:/Projects/FYP-coordination/quality-claim.json');v=json.loads(p.read_text(encoding='utf-8'));v['localInputLease'].append(token);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
folder=out/'candidate-shaders';folder.mkdir(exist_ok=True)
for name in ['reference_depth.vert.spv','reference_depth.frag.spv','reference_depth_masked.vert.spv']:(folder/name).write_bytes((out/'control-shaders'/name).read_bytes())
command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslangValidator.exe','-V','--target-env','vulkan1.1','-I'+str(root/'shaders'),'-o',str(folder/'reference_depth_masked.frag.spv'),str(out/'candidate.frag')];r=subprocess.run(command,capture_output=True,text=True);(out/'candidate-shader-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.1',str(folder/'reference_depth_masked.frag.spv')],capture_output=True,text=True);assert r.returncode==0,r.stderr
config=json.loads((prior/'native-config.json').read_text());(out/'candidate-config.json').write_text(json.dumps(config,indent=2)+'\n');print('One candidate factor: reference quad gradient footprint; all native data unchanged')
