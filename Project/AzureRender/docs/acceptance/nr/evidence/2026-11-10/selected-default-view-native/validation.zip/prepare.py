import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs,verify
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'))
os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
if '--inside' not in sys.argv:
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
def call(label,args):
 with (out/(label+'.log')).open('wb') as log:subprocess.run(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=700)
verify(root,json.loads((build/'build-provenance.json').read_text()))
source=inputs(root);(out/'baseline-source.json').write_text(json.dumps(source,indent=2))
base={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}
(out/'baseline-products.json').write_text(json.dumps(base,indent=2));shutil.copyfile(build/'AzurePlayer.exe',out/'baseline-AzurePlayer.exe')
parent=root/'build/runs/20261110-162938-selected-default-view-combination-001ae4'
selected=next((parent/'candidate-source').glob('combined-*-character_snapshot*early.frag'))
combined=next((parent/'precision-boundary-diagnostic/candidate-source').glob('combined-*-mesh*early.frag'))
(out/'selected.frag').write_bytes(selected.read_bytes());(out/'combined.frag').write_bytes(combined.read_bytes());(out/'selected_receiver.glsl').write_bytes((parent/'selected_receiver.glsl').read_bytes())
tests=['AzureDepthPrefillRecordingTests','AzureMaterialClassEarlyDepthTests']
def rebuild(label,enabled):
 call(label+'-configure',['cmake','--preset','msvc-release','-DAZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION='+enabled])
 cmd=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',build,'--config','Release']
 for name in tests:cmd+=['--test-target',name]
 call(label+'-build',cmd)
try:
 rebuild('candidate','ON');shutil.copyfile(build/'build-provenance.json',out/'candidate-build-provenance.json')
 shutil.copyfile(build/'AzurePlayer.exe',out/'candidate-AzurePlayer.exe')
 for name in tests:shutil.copyfile(build/(name+'.exe'),out/(name+'.exe'))
 manifest=json.loads((build/'shader-reload.json').read_text());(out/'candidate-shader-reload.json').write_text(json.dumps(manifest,indent=2))
 runtime=out/'runtime';(runtime/'shaders').mkdir(parents=True)
 for path in sorted((build/'shaders').glob('*.spv')):os.link(path,runtime/'shaders'/path.name)
 programs=[p for p in manifest['programs'] if p['source']=='mesh.frag'];assert len(programs)==580,len(programs)
 compiled=[]
 with (out/'private-build.log').open('wb') as log:
  for i,p in enumerate(programs):
   path=runtime/'shaders'/p['output'];path.unlink();candidate=out/('combined.frag' if '_isolation0.frag.spv' in p['output'] else 'selected.frag')
   command=[manifest['compiler'],*p['arguments'],*['-D'+x for x in p['defines']],'-I'+str(root/'shaders'),str(candidate),'-o',str(path)]
   subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
   subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.3','--relax-block-layout',str(path)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=15)
   compiled.append(dict(program=p,source=candidate.name,sha256=digest(path),bytes=path.stat().st_size))
   if i%32==0:print('Compiled',i+1,'/',len(programs),flush=True)
 (out/'private-programs.json').write_text(json.dumps(dict(compiled=compiled,defaultViewPrograms=sum(x['source']=='combined.frag' for x in compiled)),indent=2))
 assert inputs(root)==source and all(digest(Path(p))==h for p,h in base.items() if p.endswith('.spv'))
finally:
 rebuild('restore','OFF')
 shutil.copyfile(build/'build-provenance.json',out/'restored-build-provenance.json')
assert inputs(root)==source and all(digest(Path(p))==h for p,h in base.items())
print('Private programs ready; default source and products restored',flush=True)
