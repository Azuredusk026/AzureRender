import json,os,shutil,subprocess,sys,time
from pathlib import Path
import numpy as np
from PIL import Image
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'))
runtime=out/'runtime';exe=out/'candidate-AzurePlayer.exe'
before=inputs(root);programs={str(p):digest(p) for p in (runtime/'shaders').glob('*.spv')}
base=json.loads((out/'baseline-products.json').read_text())
assert all(digest(Path(p))==sha for p,sha in base.items() if p.endswith('.spv'))
lock=json.loads((root/'build/runs/20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text())
assert len(lock)==1729 and all(digest(Path(p))==sha for p,sha in lock.items())
reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint'
checks=[]
for name in ['AzureDepthPrefillRecordingTests','AzureMaterialClassEarlyDepthTests']:
    start=time.monotonic()
    with (out/(name+'.log')).open('wb') as log:p=subprocess.run([str(out/(name+'.exe')),str(runtime/'shaders')],stdout=log,stderr=subprocess.STDOUT,timeout=60)
    checks.append(dict(name=name,exitCode=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,checks[-1]
command=json.loads((reference/'command.json').read_text());command[0]=str(exe)
command[command.index('--capture-dir')+1]=str(out/'frames');command[command.index('--runtime-report')+1]=str(out/'runtime.json')
command+=['--resource-root',str(runtime)]
os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer',DOTNET_ROOT='D:/Tools/dotnet9')
os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','AZURE_CPU_WORK_REPORT']:os.environ.pop(key,None)
(out/'capture-command.json').write_text(json.dumps(dict(command=command,executableSha256=digest(exe),programs=programs),indent=2))
start=time.monotonic()
with (out/'capture.log').open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=550)
rows=[]
for path in sorted((out/'frames').glob('frame_*.png')):
    actual=np.asarray(Image.open(path).convert('RGB'));expected=np.asarray(Image.open(reference/'frames'/path.name).convert('RGB'))
    diff=np.abs(actual.astype('i2')-expected.astype('i2'));ys,xs=np.where(np.any(diff,axis=2))
    rows.append(dict(frame=path.name,sha256=digest(path),changedPixels=len(xs),maximumByteError=int(diff.max()),firstDifferences=[dict(x=int(x),y=int(y),expected=expected[y,x].tolist(),actual=actual[y,x].tolist()) for x,y in zip(xs[:40],ys[:40])]))
manifest=json.loads((out/'frames/capture_manifest.json').read_text()) if (out/'frames/capture_manifest.json').exists() else {}
log=(out/'capture.log').read_text(errors='replace')
report=dict(exitCode=p.returncode,seconds=time.monotonic()-start,checks=checks,frames=rows,metadata={k:v for k,v in manifest.items() if k.startswith(('defaultIsolation','screenReflection','computeReflection','shadowHistory'))},validationClean=not any(x in log for x in ['Validation Error:','Validation Warning:','SYNC-HAZARD','VUID-']),allocatorZero='Allocator after unload: buffers=0 images=0' in log,sourceUnchanged=inputs(root)==before,privateProgramsUnchanged=all(digest(Path(p))==sha for p,sha in programs.items()),projectInputsUnchanged=all(digest(Path(p))==sha for p,sha in lock.items()))
(out/'capture-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
assert p.returncode==0 and len(rows)==4 and all(r['changedPixels']==0 and r['sha256']==digest(reference/'frames'/r['frame']) for r in rows)
assert report['metadata'].get('defaultIsolationSelected') and report['metadata']['defaultIsolationPipelines']>0
assert all(report[k] for k in ['validationClean','allocatorZero','sourceUnchanged','privateProgramsUnchanged','projectInputsUnchanged'])
