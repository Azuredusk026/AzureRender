from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();out=Path(__file__).resolve().parent;dest=root/'docs/acceptance/nr/evidence/2026-11-10/selected-default-view-native'
h=lambda b:hashlib.sha256(b).hexdigest()
capture=json.loads((out/'capture-results.json').read_text());cost=json.loads((out/'cost-results.json').read_text())
assert capture['exitCode']==0 and len(capture['frames'])==4 and all(x['changedPixels']==0 for x in capture['frames'])
assert all(capture[k] for k in ['validationClean','allocatorZero','sourceUnchanged','privateProgramsUnchanged','projectInputsUnchanged'])
assert cost['sourceAndProgramsUnchanged'] and cost['projectInputsUnchanged']
protected=json.loads((root/'build/runs/20261110-131820-output-pixel-loading-integration-683849/protected-files.json').read_text());assert len(protected)==13 and all(h((root/k).read_bytes())==v for k,v in protected.items());(out/'protected-files.json').write_text(json.dumps(protected,indent=2))
criteria=dict(minimumWholeFrameGain=cost['reductionFraction']>=.02,twiceReferenceDrift=cost['reductionFraction']>=2*cost['referenceDriftFraction'],maximumReferenceDrift=cost['referenceDriftFraction']<=.03,minimumAffectedRangeGain=cost['affectedRangeReductionFraction']>=.05)
privateEffective=all(criteria.values());p95=cost['rows'][1]['summary']['gpu']['p95'];cpu95=cost['rows'][1]['summary']['cpu']['p95']
result=dict(status='strict-compatible-effective-private-candidate-production-integration-pending' if privateEffective else 'strict-compatible-efficiency-gate-failed',sourceHead='264dd76',privateProgramCount=580,defaultViewProgramCount=64,capture=capture,cost=cost,efficiencyCriteria=criteria,privateEfficiencyPassed=privateEffective,shortGpuP95Milliseconds=p95,shortCpuWorkP95Milliseconds=cpu95,shortGpuBudgetPassed=p95<=16.6,shortCpuBudgetPassed=cpu95<=8,formalPerformancePassed=False,productionAdopted=False,defaultBuildRestored=True,protectedFilesUnchanged=True)
dest.mkdir(parents=True,exist_ok=True);members=[]
files=[f for f in out.rglob('*') if f.is_file() and not set(f.relative_to(out).parts)&{'tmp','runtime'} and f.suffix.lower() in {'.py','.json','.log','.frag','.glsl'}]
with zipfile.ZipFile(dest/'validation.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(files):
  data=f.read_bytes();name=f.relative_to(out).as_posix();z.writestr(name,data);members.append(dict(path=name,bytes=len(data),sha256=h(data)))
archive=dest/'validation.zip';assert archive.stat().st_size<=8*1024**2
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(members)
 for row in members:
  data=z.read(row['path']);assert len(data)==row['bytes'] and h(data)==row['sha256']
result.update(archiveBytes=archive.stat().st_size,archiveSha256=h(archive.read_bytes()),archiveMembers=members)
(dest/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','efficiencyCriteria','shortGpuP95Milliseconds','shortCpuWorkP95Milliseconds','archiveBytes','archiveSha256']},indent=2))
