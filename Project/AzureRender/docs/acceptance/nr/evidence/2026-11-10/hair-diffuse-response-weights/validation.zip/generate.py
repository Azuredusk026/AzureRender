from pathlib import Path
import re,json,shutil,sys,struct,subprocess
out=Path(__file__).resolve().parent;prior=out.parent/'20261109-231408-hair-material-sample-region-5f9f16'
for name in ['dxbc_util.py','D3D12TokenizedProgramFormat.hpp','LICENSE-RenderDoc.txt','checksum-source.json','header-source.json','native-original.shader']:(shutil.copyfile(prior/name,out/name) if not (out/name).is_file() else None)
sys.path.insert(0,str(out));from dxbc_util import chunks,words,instructions,opcode,inst,dest,source,imm,fbits,rebuild,checksum
raw=(out/'native-original.shader').read_bytes();assert checksum(raw)==raw[4:20]
def native_probe(field='responseScene',component=None,shift=0):
 parts=chunks(raw);idx=next(i for i,(kind,_) in enumerate(parts) if kind in [b'SHEX',b'SHDR']);w=words(parts[idx][1]);items=list(instructions(w))
 declared=next(i for i in items if i[2]==opcode('DCL_TEMPS'));capture=w[declared[1]+1];scratch=capture+1;seen=capture+2;flag=capture+3;w[declared[1]+1]=capture+4
 body=items[items.index(declared)+1:];assert len(body)==2137
 site=body[1167 if field=='responseScene' else 1119];at,n=site[1],site[3]
 operand=at+1
 while w[operand-1]&0x80000000:operand+=1
 assert site[2]==opcode('MAD' if field=='responseScene' else 'MIN') and w[operand+1]==(24 if field=='responseScene' else 17)
 end=next(i[1] for i in items if i[2]==opcode('RET'));extra=[]
 if component is not None:
  for mask,offset in [(1,shift),(2,shift+6)]:
   extra+=inst('USHR',dest(scratch),source(capture,component),imm(offset));extra+=inst('AND',dest(scratch),source(scratch),imm(63))
   if mask==2 and shift==24:
    extra+=inst('IEQ',dest(flag),source(seen),imm(0));extra+=inst('AND',dest(flag),source(flag),imm(8));extra+=inst('OR',dest(scratch),source(scratch),source(flag))
   extra+=inst('UTOF',dest(scratch),source(scratch));extra+=inst('MUL',dest(scratch),source(scratch),imm(fbits(1/64)));extra+=inst('MOV',dest(0,mask,True),source(scratch))
 w[end:end]=extra
 if field=='responseScene':hook=inst('MOV',dest(capture,7),[2|(1<<2)|(0xe4<<4)|(1<<20),24])+inst('MOV',dest(capture,8),source(3,2))
 else:hook=inst('MOV',dest(capture,1),source(17,2))+inst('MOV',dest(capture,2),source(15,3))
 hook+=inst('MOV',dest(seen),imm(1));w[at+n:at+n]=hook
 first=body[0][1];assert body[0][2]==opcode('MOV');w[first:first]=inst('MOV',dest(seen),imm(0))
 w[1]=len(w);parts[idx]=(parts[idx][0],struct.pack('<'+'I'*len(w),*w));code=rebuild(raw,parts);assert checksum(code)==code[4:20];return code
(out/'native-output-control.dxbc').write_bytes(native_probe(component=None))
base=out.parent/'20261109-221435-hair-color-closure-430845';original=(base/'native-visibility.spvasm').read_text();sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin');cases=[]
for field,n in [('responseScene',4),('masks',2)]:
 for component in range(n):
  for shift in [0,12,24]:
   name=f'{field}-{component}-{shift}';(out/(name+'.dxbc')).write_bytes(native_probe(field,component,shift));text=original;decl=[]
   def existing(pattern,definition,key):
    match=re.search(r'(%\S+) = '+pattern+r'\n',text)
    if match:return match[1]
    tag='%diffuse_probe_'+key;decl.append(tag+' = '+definition);return tag
   p4=existing('OpTypePointer Private %v4float','OpTypePointer Private %v4float','p4');p2=existing('OpTypePointer Private %v2float','OpTypePointer Private %v2float','p2');pb=existing('OpTypePointer Private %bool','OpTypePointer Private %bool','pb')
   u4=existing('OpTypeVector %uint 4','OpTypeVector %uint 4','u4');u2=existing('OpTypeVector %uint 2','OpTypeVector %uint 2','u2');b4=existing('OpTypeVector %bool 4','OpTypeVector %bool 4','b4');b2=existing('OpTypeVector %bool 2','OpTypeVector %bool 2','b2')
   decl += ['%diffuse_probe_z4 = OpConstantNull %v4float','%diffuse_probe_z2 = OpConstantNull %v2float','%diffuse_probe_false = OpConstantFalse %bool','%diffuse_probe_true = OpConstantTrue %bool',
    f'%diffuse_probe_responseScene = OpVariable {p4} Private %diffuse_probe_z4',f'%diffuse_probe_masks = OpVariable {p2} Private %diffuse_probe_z2',f'%diffuse_probe_seen = OpVariable {pb} Private %diffuse_probe_false',f'%diffuse_probe_varied = OpVariable {pb} Private %diffuse_probe_false',
    '%diffuse_probe_scale = OpConstant %float 0.015625','%diffuse_probe_mask = OpConstant %uint 63',f'%diffuse_probe_shift_r = OpConstant %uint {shift}',f'%diffuse_probe_shift_g = OpConstant %uint {shift+6}','%diffuse_probe_two = OpConstant %uint 2']
   offset=text.index('       %main = OpFunction');text=text[:offset]+'\n'.join(decl)+'\n'+text[offset:]
   hook=f'''%response_color = OpCompositeExtract %v3float %6620 0
%response_r = OpCompositeExtract %float %response_color 0
%response_g = OpCompositeExtract %float %response_color 1
%response_b = OpCompositeExtract %float %response_color 2
%response_scene = OpLoad %float %visibility_3
%response_rgba = OpCompositeConstruct %v4float %response_r %response_g %response_b %response_scene
%response_lit = OpLoad %float %litMask_5
%response_ao = OpLoad %float %aoMask_4
%response_maskVec = OpCompositeConstruct %v2float %response_lit %response_ao
%diffuse_old_r = OpLoad %v4float %diffuse_probe_responseScene
%diffuse_old_u = OpLoad %v2float %diffuse_probe_masks
%diffuse_or_bits = OpBitcast {u4} %diffuse_old_r
%diffuse_ou_bits = OpBitcast {u2} %diffuse_old_u
%diffuse_nr_bits = OpBitcast {u4} %response_rgba
%diffuse_nu_bits = OpBitcast {u2} %response_maskVec
%diffuse_r_ne = OpINotEqual {b4} %diffuse_or_bits %diffuse_nr_bits
%diffuse_u_ne = OpINotEqual {b2} %diffuse_ou_bits %diffuse_nu_bits
%diffuse_r_any = OpAny %bool %diffuse_r_ne
%diffuse_u_any = OpAny %bool %diffuse_u_ne
%diffuse_any = OpLogicalOr %bool %diffuse_r_any %diffuse_u_any
%diffuse_seen = OpLoad %bool %diffuse_probe_seen
%diffuse_changed = OpLogicalAnd %bool %diffuse_seen %diffuse_any
%diffuse_prior = OpLoad %bool %diffuse_probe_varied
%diffuse_varied = OpLogicalOr %bool %diffuse_prior %diffuse_changed
OpStore %diffuse_probe_varied %diffuse_varied
OpStore %diffuse_probe_responseScene %response_rgba
OpStore %diffuse_probe_masks %response_maskVec
OpStore %diffuse_probe_seen %diffuse_probe_true
'''
   needle='OpStore %response_0 %6620';assert text.count(needle)==1;text=text.replace(needle,needle+'\n'+hook)
   start=text.index('%main = OpFunction');end=text.index('OpFunctionEnd',start);body=text[start:end];assert body.count('OpReturn\n')==1
   probe=f'''%diffuse_probe_loaded = OpLoad %v{n}float %diffuse_probe_{field}
%diffuse_probe_value = OpCompositeExtract %float %diffuse_probe_loaded {component}
%diffuse_probe_bits = OpBitcast %uint %diffuse_probe_value
%diffuse_probe_rs = OpShiftRightLogical %uint %diffuse_probe_bits %diffuse_probe_shift_r
%diffuse_probe_gs = OpShiftRightLogical %uint %diffuse_probe_bits %diffuse_probe_shift_g
%diffuse_probe_rb = OpBitwiseAnd %uint %diffuse_probe_rs %diffuse_probe_mask
%diffuse_probe_gbase = OpBitwiseAnd %uint %diffuse_probe_gs %diffuse_probe_mask
'''
   if shift==24:
    probe+='''%diffuse_probe_seen_final = OpLoad %bool %diffuse_probe_seen
%diffuse_probe_unseen = OpLogicalNot %bool %diffuse_probe_seen_final
%diffuse_probe_varied_final = OpLoad %bool %diffuse_probe_varied
%diffuse_probe_vflag = OpSelect %uint %diffuse_probe_varied_final %uint_1 %uint_0
%diffuse_probe_uflag = OpSelect %uint %diffuse_probe_unseen %diffuse_probe_two %uint_0
%diffuse_probe_flags = OpBitwiseOr %uint %diffuse_probe_vflag %diffuse_probe_uflag
%diffuse_probe_fshift = OpShiftLeftLogical %uint %diffuse_probe_flags %diffuse_probe_two
%diffuse_probe_gb = OpBitwiseOr %uint %diffuse_probe_gbase %diffuse_probe_fshift
'''
   else:probe+='%diffuse_probe_gb = OpCopyObject %uint %diffuse_probe_gbase\n'
   probe+='''%diffuse_probe_rf = OpConvertUToF %float %diffuse_probe_rb
%diffuse_probe_gf = OpConvertUToF %float %diffuse_probe_gb
%diffuse_probe_r = OpFMul %float %diffuse_probe_rf %diffuse_probe_scale
%diffuse_probe_g = OpFMul %float %diffuse_probe_gf %diffuse_probe_scale
%diffuse_probe_original = OpLoad %v4float %outputColor
%diffuse_probe_b = OpCompositeExtract %float %diffuse_probe_original 2
%diffuse_probe_a = OpCompositeExtract %float %diffuse_probe_original 3
%diffuse_probe_color = OpCompositeConstruct %v4float %diffuse_probe_r %diffuse_probe_g %diffuse_probe_b %diffuse_probe_a
OpStore %outputColor %diffuse_probe_color
OpReturn
'''
   text=text[:start]+body.replace('OpReturn\n',probe)+text[end:];(out/(name+'.spvasm')).write_text(text)
   for command in [[str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/(name+'.spvasm')),'-o',str(out/(name+'.spv'))],[str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/(name+'.spv'))]]:subprocess.run(command,check=True)
   cases.append(dict(name=name,field=field,component=component,components=n,shift=shift))
(out/'cases.json').write_text(json.dumps(cases,indent=2))
previous=out.parent/'20261110-015225-hair-diffuse-ramp-input-182363'
(out/'collect.py').write_text((previous/'collect.py').read_text().replace(previous.name,out.name));(out/'run.py').write_text((previous/'run.py').read_text())
print('Prepared 18 paired diffuse response, scene-visibility and mask probes')
