from pathlib import Path
import shutil,re
out=Path(__file__).resolve().parent;prior=out.parent/'20261110-015225-hair-diffuse-ramp-input-182363'
for name in ['dxbc_util.py','D3D12TokenizedProgramFormat.hpp','LICENSE-RenderDoc.txt','checksum-source.json','header-source.json','native-original.shader']:shutil.copyfile(prior/name,out/name)
source=(prior/'prepare.py').read_text()
source=source.replace('shutil.copyfile(prior/name,out/name)','(shutil.copyfile(prior/name,out/name) if not (out/name).is_file() else None)')
start=source.index('def native_probe(');end=source.index("(out/'native-output-control.dxbc')",start)
replacement='''def native_probe(field='responseScene',component=None,shift=0):
 parts=chunks(raw);idx=next(i for i,(kind,_) in enumerate(parts) if kind in [b'SHEX',b'SHDR']);w=words(parts[idx][1]);items=list(instructions(w))
 declared=next(i for i in items if i[2]==opcode('DCL_TEMPS'));capture=w[declared[1]+1];scratch=capture+1;seen=capture+2;flag=capture+3;w[declared[1]+1]=capture+4
 body=items[items.index(declared)+1:];assert len(body)==2137
 site=body[1167 if field=='responseScene' else 1119];at,n=site[1],site[3]
 operand=at+1
 while w[operand-1]&0x80000000:operand+=1
 assert site[2]==opcode('MAD' if field=='responseScene' else 'MIN') and w[operand+1]==(24 if field=='responseScene' else 17)
 end=next(i[1] for i in items if i[2]==opcode('RET'));extra=[]
 if component is not None:
  for mask,offset in [(1,shift),(2,shift+6)]:
   extra+=inst('USHR',dest(scratch),source(capture,component),imm(offset));extra+=inst('AND',dest(scratch),source(scratch),imm(63))
   if mask==2 and shift==24:
    extra+=inst('IEQ',dest(flag),source(seen),imm(0));extra+=inst('AND',dest(flag),source(flag),imm(8));extra+=inst('OR',dest(scratch),source(scratch),source(flag))
   extra+=inst('UTOF',dest(scratch),source(scratch));extra+=inst('MUL',dest(scratch),source(scratch),imm(fbits(1/64)));extra+=inst('MOV',dest(0,mask,True),source(scratch))
 w[end:end]=extra
 if field=='responseScene':hook=inst('MOV',dest(capture,7),[2|(1<<2)|(0xe4<<4)|(1<<20),24])+inst('MOV',dest(capture,8),source(3,2))
 else:hook=inst('MOV',dest(capture,1),source(17,2))+inst('MOV',dest(capture,2),source(15,3))
 hook+=inst('MOV',dest(seen),imm(1));w[at+n:at+n]=hook
 first=body[0][1];assert body[0][2]==opcode('MOV');w[first:first]=inst('MOV',dest(seen),imm(0))
 w[1]=len(w);parts[idx]=(parts[idx][0],struct.pack('<'+'I'*len(w),*w));code=rebuild(raw,parts);assert checksum(code)==code[4:20];return code
'''
source=source[:start]+replacement+source[end:]
source=source.replace("[('ramp',4),('uv',2)]","[('responseScene',4),('masks',2)]")
source=source.replace('%diffuse_probe_ramp','%diffuse_probe_responseScene').replace('%diffuse_probe_uv','%diffuse_probe_masks')
source=source.replace('%6534','%response_rgba').replace('%6533','%response_maskVec')
source=source.replace("hook=f'''%diffuse_old_r",'''hook=f\'''%response_color = OpCompositeExtract %v3float %6620 0
%response_r = OpCompositeExtract %float %response_color 0
%response_g = OpCompositeExtract %float %response_color 1
%response_b = OpCompositeExtract %float %response_color 2
%response_scene = OpLoad %float %visibility_3
%response_rgba = OpCompositeConstruct %v4float %response_r %response_g %response_b %response_scene
%response_lit = OpLoad %float %litMask_5
%response_ao = OpLoad %float %aoMask_4
%response_maskVec = OpCompositeConstruct %v2float %response_lit %response_ao
%diffuse_old_r''')
source=source.replace("needle='OpStore %ramp_10 %response_rgba'","needle='OpStore %response_0 %6620'")
source=source.replace("previous=out.parent/'20261110-013009-hair-final-float-values-c03e78'", "previous=out.parent/'20261110-015225-hair-diffuse-ramp-input-182363'")
source=source.replace('Prepared 18 paired diffuse ramp and actual coordinate probes with seen/variation flags','Prepared 18 paired diffuse response, scene-visibility and mask probes')
(out/'generate.py').write_text(source)
print('Prepared native PC-verified response and mask generation recipe')
