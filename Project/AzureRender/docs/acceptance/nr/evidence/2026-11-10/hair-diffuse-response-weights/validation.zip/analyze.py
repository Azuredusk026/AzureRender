from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent;d=json.loads((out/'state.json').read_text());assert d['status']=='qualified' and len(d['captures'])==2
allowed={'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU','NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image'}
assert set(d['captures'][0]['debugMessages'])<=allowed and not d['captures'][1]['debugMessages']
samples={};flagRows={}
for capture in d['captures']:
 assert capture['sourceControlQualified'] and capture['baselineRestored'] and len(capture['runs'])==18 and all(r['qualified'] for r in capture['runs'])
 label=capture['label'];samples[label]={};flagRows[label]={}
 for field,n in [('responseScene',4),('masks',2)]:
  words=np.zeros((len(d['points']),n),dtype='<u4');flags=[]
  for r in capture['runs']:
   case=r['case']
   if case['field']!=field:continue
   values=np.array(r['values'],dtype='<u4')
   if case['shift']==24:flags.extend((values>>8).tolist());values &=255
   words[:,case['component']] |= values<<case['shift']
  assert len(flags)==len(d['points'])*n and all(v==0 for v in flags),(label,field,flags)
  assert np.isfinite(words.view('<f4')).all();samples[label][field]=words;flagRows[label][field]=flags
rows=[]
for i,pixel in enumerate(d['points']):
 nr=samples['native']['responseScene'][i];vr=samples['vulkan']['responseScene'][i];nm=samples['native']['masks'][i];vm=samples['vulkan']['masks'][i]
 nf=nr.view('<f4');vf=vr.view('<f4');nmf=nm.view('<f4');vmf=vm.view('<f4')
 rows.append(dict(pixel=pixel,nativeResponseSceneBits=nr.tolist(),vulkanResponseSceneBits=vr.tolist(),nativeResponseScene=nf.tolist(),vulkanResponseScene=vf.tolist(),nativeMaskBits=nm.tolist(),vulkanMaskBits=vm.tolist(),nativeMasks=nmf.tolist(),vulkanMasks=vmf.tolist(),responseExact=bool(np.all(nr[:3]==vr[:3])),sceneExact=bool(nr[3]==vr[3]),masksExact=bool(np.all(nm==vm)),maximumResponseAbsolute=float(abs(nf[:3]-vf[:3]).max()),maximumMaskAbsolute=float(abs(nmf-vmf).max())))
report=dict(status='qualified-diffuse-response-weights',points=len(rows),responseExactPoints=sum(r['responseExact'] for r in rows),sceneExactPoints=sum(r['sceneExact'] for r in rows),maskExactPoints=sum(r['masksExact'] for r in rows),maximumResponseAbsolute=max(r['maximumResponseAbsolute'] for r in rows),maximumMaskAbsolute=max(r['maximumMaskAbsolute'] for r in rows),rows=rows,qualification=d,scope='Actual pre-final-scale weighted diffuse color, scene visibility and lit/ao masks. Shader output with full-crop blue qualification and seen/consistency flags.')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['rows','qualification']},indent=2))
print(json.dumps(sorted(rows,key=lambda r:r['maximumResponseAbsolute'],reverse=True)[:5],indent=2))
