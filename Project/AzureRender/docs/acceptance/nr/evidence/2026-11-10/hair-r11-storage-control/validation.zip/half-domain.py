from pathlib import Path
import math,json,numpy as np
out=Path(__file__).resolve().parent;words=np.concatenate([np.arange(0x7c00,dtype='u2'),np.arange(0x8000,0xfc00,dtype='u2')]);values=words.view('<f2').astype('<f4');assert np.isfinite(values).all();rows=[]
for m in [6,5]:
 positive=np.maximum(values,0);normal=(positive.view('<u4') & np.uint32(0xffffffff^((1<<(23-m))-1))).view('<f4');scale=2**(14+m);q=np.where(positive<2**-14,np.floor(positive*scale)/scale,normal).astype('<f4');expected=[]
 for v in values:
  v=float(v)
  if v<=0:expected.append(0.0);continue
  exponent=math.frexp(v)[1]-1
  if exponent < -14:expected.append(math.floor(math.ldexp(v,14+m))*2**(-14-m))
  else:expected.append(math.floor(math.ldexp(v,m-exponent))*2**(exponent-m))
 reference=np.array(expected,dtype='<f4');different=int(np.count_nonzero(q.view('<u4')!=reference.view('<u4')));assert different==0;rows.append(dict(mantissaBits=m,finiteHalfInputs=len(values),different=different))
r=dict(status='cpu-finite-half-storage-model-qualified',scope='Finite half-domain source values only; independent frexp/floor reference, not a GPU result or a full F32 overflow contract.',rows=rows);(out/'half-domain-results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
