from pathlib import Path
import sys,json,subprocess
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as shared
out=Path(__file__).resolve().parent
result=shared.maintenance.guarded_run(out.parents[1],'20261110-031856-hair-main-chroma-debug-668bf2',[sys.executable,str(out/'build.py'),'Debug'],900)
(out/'debug-final-build-execution.json').write_text(json.dumps(result,indent=2));assert result.get('exitCode')==0,result
raise SystemExit(subprocess.run([sys.executable,str(out/'gpu.py')],timeout=240).returncode)
