from pathlib import Path
import runpy
out=Path(__file__).resolve().parent
for name in ['build.py','intel.py']:
 print('Final qualification '+name,flush=True)
 runpy.run_path(str(out/name),run_name='__main__')
