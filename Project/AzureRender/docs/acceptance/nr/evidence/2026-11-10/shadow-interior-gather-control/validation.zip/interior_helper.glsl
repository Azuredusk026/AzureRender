#if defined(AZURE_SEPARATE_SHADOW_SAMPLER)
vec4 shadowTexelQuad(texture2D depthMap,sampler depthSampler,ivec2 base,ivec2 lo,ivec2 hi,bool interior){
 if(interior){vec2 uv=(vec2(base)+1.0)/vec2(textureSize(sampler2D(depthMap,depthSampler),0));return textureGather(sampler2D(depthMap,depthSampler),uv).wzxy;}
 return shadowTexelQuad(depthMap,depthSampler,base,lo,hi);
}
#else
vec4 shadowTexelQuad(sampler2D depthMap,ivec2 base,ivec2 lo,ivec2 hi,bool interior){
 if(interior){vec2 uv=(vec2(base)+1.0)/vec2(textureSize(depthMap,0));return textureGather(depthMap,uv).wzxy;}
 return shadowTexelQuad(depthMap,base,lo,hi);
}
#endif
