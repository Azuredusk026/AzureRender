from pathlib import Path
import json,hashlib,sys,traceback,struct,subprocess,math
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261110-153101-shadow-interior-gather-control-1ab7eb';a=root/'build/runs/20261110-135028-compact-texture-gpu-cost-25d5da'
state=json.loads((a/'state.json').read_text());profile=json.loads((a/'events/profile.json').read_text());report=dict(status='starting',sourceBase='274615b',scope='Current 720p replay; Reuse original full-interior qualification for identical quad texture gathers; local replay only; native acceptance is separate',captureSha256=state['captureSha256']);cap=None;c=None
def save():(out/'compare-state.json').write_text(json.dumps(report,indent=2))
def durations():return {int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
try:
 save();cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 shaders={k:dict(v,programFile=next(n for n in v['programFiles'] if n.startswith(('mesh','character_snapshot')))) for k,v in profile['shaders'].items() if any(n.startswith(('mesh','character_snapshot')) for n in v['programFiles'])};compiled={};rows=[]
 manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());source=root/'shaders';private=out/'candidate-source';private.mkdir()
 original=(source/'mesh.frag').read_text();assert original.count('camera.renderingParameters.w')==1
 helper=(out/'interior_helper.glsl').read_text();(private/'shadow_compare.glsl').write_text((source/'shadow_compare.glsl').read_text()+'\n'+helper)
 begin=original.index('float sampleCascadeShadow(');end=original.index('\nvec2 shadowReceiverGradients',begin);section=original[begin:end]
 needle='shadowTexelQuad(mainShadowDepth,sharedDepthSampler,base+ivec2(x,y),lo,hi)';assert section.count(needle)==2
 section=section.replace(needle,'shadowTexelQuad(mainShadowDepth,sharedDepthSampler,base+ivec2(x,y),lo,hi,interior)');original=original[:begin]+section+original[end:]
 parameters={}
 for key,entry in shaders.items():
  event=next(r['event'] for r in profile['measurements'] if r['shader']==key);c.SetFrameEvent(event,True);pipe=c.GetPipelineState();shader=pipe.GetShader(rd.ShaderStage.Pixel)
  reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel);assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==entry['sha256']
  descriptor=pipe.GetConstantBlock(rd.ShaderStage.Pixel,0,0).descriptor
  raw=bytes(c.GetBufferData(descriptor.resource,descriptor.byteOffset+108,4));bits=struct.unpack('<I',raw)[0];radius=struct.unpack('<f',raw)[0];assert math.isfinite(radius)
  filename=entry['programFile'];assert filename not in parameters or parameters[filename]==bits;parameters[filename]=bits
  shader_source=private/('interior-'+str(bits)+'-'+filename[:-4]);shader_source.write_text(original)
  specification=next(v for v in manifest['programs'] if v['output']==filename);assert specification['source']=='mesh.frag'
  command=[manifest['compiler'],*specification['arguments'],*['-D'+d for d in specification['defines']],'-I'+str(source),str(shader_source),'-o',str(out/filename)]
  built=subprocess.run(command,capture_output=True,text=True,timeout=30);(out/(filename+'.build.json')).write_text(json.dumps(dict(command=command,returncode=built.returncode,stdout=built.stdout,stderr=built.stderr),indent=2));assert built.returncode==0,built.stderr
  validated=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe',str(out/filename)],capture_output=True,text=True,timeout=15);assert validated.returncode==0,validated.stderr
  program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/entry['programFile']).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert program!=rd.ResourceId.Null(),errors
  compiled[key]=(shader,program);rows.append(dict(shader=key,file=entry['programFile'],event=event,shadowRadius=radius,shadowRadiusBits=bits,errors=errors))
 report.update(status='compiled',programs=rows);save()
 draws=sorted((r for r in profile['measurements'] if r['kind']=='draw'),key=lambda x:x['seconds'],reverse=True)
 pixel=json.loads((a/'profile-state.json').read_text());last={}
 for row in pixel['pixelEvents']:
  if not row['hasChildren'] and row['shader'] in shaders:
   colors=tuple(row.get('colorTargets',[]));last[colors]=max(last.get(colors,0),row['event'])
 events=sorted(set(last.values())|{max(r['event'] for r in draws)})
 report['comparedEvents']=events
 controls={}
 for event in events:
  c.SetFrameEvent(event,True)
  for index,target in enumerate(c.GetPipelineState().GetOutputTargets()):
   if target.resource!=rd.ResourceId.Null():controls[(event,index)]=(target.resource,bytes(c.GetTextureData(target.resource,rd.Subresource())))
 for shader,program in compiled.values():c.ReplaceResource(shader,program)
 durations() # Warm candidate pipelines before the retained ABBA batch.
 for shader,program in compiled.values():c.RemoveReplacement(shader)
 durations() # Warm all original pipelines again before the retained baseline.
 report['status']='baseline-read';report['timings']=[dict(mode='baseline',milliseconds=durations())];save()
 for shader,program in compiled.values():c.ReplaceResource(shader,program)
 comparisons=[]
 for (event,index),(resource,data) in controls.items():
  c.SetFrameEvent(event,True);value=bytes(c.GetTextureData(resource,rd.Subresource()));comparisons.append(dict(event=event,target=index,bytes=len(data),equal=value==data,baselineSha256=hashlib.sha256(data).hexdigest(),candidateSha256=hashlib.sha256(value).hexdigest()))
 report.update(status='candidate-read',comparisons=comparisons);save()
 for unused in range(2):report['timings'].append(dict(mode='candidate',milliseconds=durations()));save()
 for shader,program in compiled.values():c.RemoveReplacement(shader)
 report['timings'].append(dict(mode='baseline',milliseconds=durations()))
 matched={r['event'] for r in profile['measurements'] if r['shader'] in shaders}
 report['summary']=[dict(mode=r['mode'],allEventMs=sum(r['milliseconds'].values()),matchedEventMs=sum(ms for e,ms in r['milliseconds'].items() if e in matched)) for r in report['timings']]
 report.update(status='compared',allTargetsEqual=all(r['equal'] for r in comparisons));save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='compared' else 1)
