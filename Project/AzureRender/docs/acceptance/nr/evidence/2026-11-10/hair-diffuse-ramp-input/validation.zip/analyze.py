from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent;d=json.loads((out/'state.json').read_text());assert d['status']=='qualified' and len(d['captures'])==2
allowed={'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU','NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image'}
assert set(d['captures'][0]['debugMessages'])<=allowed and not d['captures'][1]['debugMessages']
samples={};flagRows={}
for capture in d['captures']:
 assert capture['sourceControlQualified'] and capture['baselineRestored'] and len(capture['runs'])==18 and all(r['qualified'] for r in capture['runs'])
 label=capture['label'];samples[label]={};flagRows[label]={}
 for field,n in [('ramp',4),('uv',2)]:
  words=np.zeros((len(d['points']),n),dtype='<u4');flags=[]
  for r in capture['runs']:
   case=r['case']
   if case['field']!=field:continue
   values=np.array(r['values'],dtype='<u4')
   if case['shift']==24:flags.extend((values>>8).tolist());values &=255
   words[:,case['component']] |= values<<case['shift']
  assert len(flags)==len(d['points'])*n and all(v==0 for v in flags),(label,field,flags)
  assert np.isfinite(words.view('<f4')).all();samples[label][field]=words;flagRows[label][field]=flags
nativeTexels=(out/'native-ramp-top-mip.bin').read_bytes();vulkanTexels=(out/'vulkan-ramp-top-mip.bin').read_bytes();assert nativeTexels==vulkanTexels and len(nativeTexels)==1024
texels=np.frombuffer(nativeTexels,dtype='u1').reshape(256,4).astype('f8')/255
def filtered(uv,clamp,quantized):
 s=float(uv[0])*256-.5;i=int(np.floor(s));f=s-i
 if quantized:f=round(f*256)/256
 lo=max(0,min(255,i)) if clamp else i%256;hi=max(0,min(255,i+1)) if clamp else (i+1)%256
 return texels[lo]*(1-f)+texels[hi]*f
rows=[]
for i,pixel in enumerate(d['points']):
 nr=samples['native']['ramp'][i];vr=samples['vulkan']['ramp'][i];nu=samples['native']['uv'][i];vu=samples['vulkan']['uv'][i]
 nf=nr.view('<f4');vf=vr.view('<f4');nuf=nu.view('<f4');vuf=vu.view('<f4')
 rows.append(dict(pixel=pixel,nativeRampBits=nr.tolist(),vulkanRampBits=vr.tolist(),nativeRamp=nf.tolist(),vulkanRamp=vf.tolist(),
  nativeUvBits=nu.tolist(),vulkanUvBits=vu.tolist(),nativeUv=nuf.tolist(),vulkanUv=vuf.tolist(),rampExact=bool(np.all(nr==vr)),uvExact=bool(np.all(nu==vu)),
  maximumRampAbsolute=float(abs(nf-vf).max()),maximumUvAbsolute=float(abs(nuf-vuf).max()),
  nativeClampCpuError=float(abs(nf-filtered(nuf,True,True)).max()),vulkanWrapCpuError=float(abs(vf-filtered(vuf,False,True)).max()),vulkanClampCpuError=float(abs(vf-filtered(vuf,True,True)).max())))
report=dict(status='qualified-diffuse-ramp-input',points=len(rows),rampExactPoints=sum(r['rampExact'] for r in rows),uvExactPoints=sum(r['uvExact'] for r in rows),
 maximumRampAbsolute=max(r['maximumRampAbsolute'] for r in rows),maximumUvAbsolute=max(r['maximumUvAbsolute'] for r in rows),
 maximumNativeClampCpuError=max(r['nativeClampCpuError'] for r in rows),maximumVulkanWrapCpuError=max(r['vulkanWrapCpuError'] for r in rows),maximumVulkanClampCpuError=max(r['vulkanClampCpuError'] for r in rows),
 rows=rows,qualification=d,scope='Actual main diffuse-ramp read and exact sampling coordinates, with full-crop blue qualification and per-invocation seen/consistency flags. CPU address models are diagnostic predictions; shader output remains authoritative.')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['rows','qualification']},indent=2))
print(json.dumps(sorted(rows,key=lambda r:r['maximumRampAbsolute'],reverse=True)[:3],indent=2))
