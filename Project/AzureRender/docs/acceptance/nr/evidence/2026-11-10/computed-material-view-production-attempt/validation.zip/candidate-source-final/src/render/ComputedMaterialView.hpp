#pragma once
#include <cstdint>

namespace azurerender {

// Qualification covers the NVIDIA implementation. Other vendors retain the
// byte-identical reference shader family until their program path is qualified.
constexpr bool computedMaterialProgramSupported(std::uint32_t vendorId) noexcept {
    return vendorId==0x10deU;
}

// Derived from the exact values uploaded to the material camera buffer.
struct ComputedMaterialViewInputs {
    float sceneLighting=0;
    float isolationMode=0;
    float effectMode=0;
    float effectEnabled=0;
    float reflectionSource=0;
};

constexpr bool computedMaterialViewEligible(const ComputedMaterialViewInputs& input) noexcept {
    return input.sceneLighting==1.F && input.isolationMode==0.F
        && input.effectMode==0.F && input.effectEnabled==1.F
        && input.reflectionSource==2.F;
}

}
