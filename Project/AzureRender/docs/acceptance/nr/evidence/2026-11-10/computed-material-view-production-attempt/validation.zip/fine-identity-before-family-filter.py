from pathlib import Path
import os,sys,json,subprocess,re,time
r=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',VK_LOADER_DRIVERS_SELECT='*igvk64*');build=r/'build/ninja-msvc-release';os.environ['PATH']=str(build)+';'+os.environ['PATH']
with (out/'intel-causal-build.log').open('wb') as log:subprocess.run([str(r/'tools/msvc_env.bat'),'cmake','--build','--preset','msvc-release','--target','AzureComputedMaterialViewGpuTests','-j','3'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
original=subprocess.check_output(['git','show','5868d1a:Project/AzureRender/shaders/mesh.frag'],text=True)
a=original.index('void prepareShadowReceiver() {');b=original.index('float sampleShadowMap(',a);region=original[a:b];assert region.count('dFdx(')==4 and region.count('dFdy(')==4
fine=original[:a]+region.replace('dFdx(','dFdxFine(').replace('dFdy(','dFdyFine(')+original[b:]
manifest=json.loads((build/'shader-reload.json').read_text());programs=[x for x in manifest['programs'] if x['source']=='mesh.frag' and not any(n in x['output'] for n in ['bindless','integral','samples','fog','isolation'])]
print('causal programs per role',len(programs),flush=True);rows=[]
for label,source in [('explicit-fine-identity',fine)]:
 folder=out/('intel-causal-'+label);shaders=folder/'shaders';shaders.mkdir(parents=True);src=out/('intel-causal-'+label+'.frag');src.write_text(source)
 for path in (out/'reference-shaders').glob('*.spv'):os.link(path,shaders/path.name)
 with (out/('intel-causal-'+label+'-compile.log')).open('wb') as log:
  for x in programs:
   target=shaders/x['output'];target.unlink();command=[manifest['compiler'],*x['arguments'],*['-D'+d for d in x['defines']],'-I'+str(r/'shaders'),str(src),'-o',str(target)];subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
   subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe',str(target)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=15)
 command=[str(build/'AzureComputedMaterialViewGpuTests.exe'),str(shaders),str(folder/'pixels'),str(shaders),'--dynamic-only','--legacy-only','--reset-submissions']
 with (out/('intel-causal-'+label+'.log')).open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 result=dict(label=label,returnCode=p.returncode,programs=len(programs))
 for name in ['failure.json','summary.json']:
  if (folder/'pixels'/name).is_file():result[name]=json.loads((folder/'pixels'/name).read_text())
 rows.append(result);(out/'intel-fine-identity-results.json').write_text(json.dumps(rows,indent=2));print(label,p.returncode,flush=True)
