#include "render/RenderViewService.hpp"
#include "render/ComputedMaterialView.hpp"
#include "scenes/CharacterSceneRenderer.hpp"
#include "support/VulkanComputeFixture.hpp"
#include <fstream>
#include <filesystem>
#include <map>
#include <sstream>
using namespace azurerender;
void require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
int main(int argc,char** argv)try{
 require(argc==3||argc==4||argc==5||argc==6,"Expected shaders, output, optional frozen reference shaders and dynamic-only control");
 const bool dynamicOnly=argc>=5&&std::string(argv[4])=="--dynamic-only";
 const bool legacyOnly=argc==6&&std::string(argv[5])=="--legacy-only";
 test::VulkanComputeFixture host(true);
 const bool supported=computedMaterialProgramSupported(host.properties.vendorID);
 const std::filesystem::path root=AZURERENDER_TEST_SOURCE_DIR,output=argv[2];std::filesystem::create_directories(output);
 nlohmann::json model;std::ifstream(root/"assets_public/scene_inspector/assets/cube.gltf")>>model;
 model["images"]=nlohmann::json::array();model["textures"]=nlohmann::json::array();
 model["materials"]=nlohmann::json::array({{{"name","computed-view-surface"},{"doubleSided",true},{"pbrMetallicRoughness",{{"baseColorFactor",{.32,.14,.08,1}}}},{"extras",{{"azureRenderMaterial",{{"schemaVersion",2},{"class","generic"},{"features",nlohmann::json::array()}}}}}}});
 for(auto& mesh:model["meshes"])for(auto& primitive:mesh["primitives"])primitive["material"]=0;
 std::ofstream(output/"scene.gltf")<<model.dump();
 model["materials"][0]["extras"]["azureRenderMaterial"]["environmentLighting"]={{"schemaVersion",1},{"diffuse","global-environment"},{"reflection","global-environment"},{"globalIntensity",.5}};
 std::ofstream(output/"lighting.gltf")<<model.dump();
 RenderContext base;base.rhi=host.backend.get();base.allocator=&host.allocator;base.device=host.device;
 base.physicalDevice=host.physical;base.graphicsQueue=host.queue;base.commandPool=host.pool;base.graphicsQueueFamily=host.family;
 base.descriptorLimits=host.properties.limits;base.shadowMapSize=32;base.cullingEnabled=false;base.computeShaders=true;base.rgba16fStorageImage=true;
 base.sceneColorFormat=VK_FORMAT_R16G16B16A16_SFLOAT;base.depthFormat=base.shadowFormat=VK_FORMAT_D32_SFLOAT;base.normalFormat=VK_FORMAT_R8G8B8A8_UNORM;
 base.rampAtlasPath=(root/"assets_public/toon_ramp_atlas.ppm").string();
 std::map<std::string,std::vector<unsigned char>> references;nlohmann::json receipt;receipt["checks"]=nlohmann::json::array();receipt["device"]=host.properties.deviceName;
 std::uint64_t serial=0;std::size_t pixelsCompared=0;unsigned selectedChecks=0;CharacterSceneRenderer* renderer=nullptr;
 for(unsigned candidate=0;candidate<2;++candidate){
 base.shaderDirectory=candidate||argc==3?argv[1]:argv[3];base.computedMaterialViewSpecializationEnabled=candidate!=0&&!dynamicOnly;
 {
 RenderViewService service(base,[&](const std::string&){auto value=std::make_unique<CharacterSceneRenderer>();renderer=value.get();return value;},[&]{vkDeviceWaitIdle(host.device);});
 for(unsigned lighting=0;lighting<2;++lighting)for(unsigned setting=0;setting<3;++setting){
  if(legacyOnly&&(lighting!=0||setting!=1))continue;
  RenderViewDescriptor descriptor;descriptor.rendererId="character";descriptor.extent={48,48};
  descriptor.settings.faceSdfFeature=descriptor.settings.showcasePlatformFeature=false;
  descriptor.settings.innerOutlineEnabled=descriptor.settings.silhouetteOutlineEnabled=false;descriptor.settings.characterPresentation={false,false};descriptor.settings.bloom.enabled=false;
  descriptor.settings.sceneLightingEnabled=setting!=1;descriptor.settings.screenSpaceReflection.enabled=setting!=2;
  descriptor.scene.resources.push_back({"surface",(output/(lighting?"lighting.gltf":"scene.gltf")).string()});scene::SceneNodeDesc node;node.id="surface";node.resourceId="surface";descriptor.scene.nodes.push_back(node);
  const auto view=service.create(descriptor);const unsigned isolations[]={0,0,0,0,1,22,0,0,0,0};
  for(unsigned phase=0;phase<10;++phase){
   if(phase==8)service.resize(view,{64,40});++serial;base.currentFrame=serial%2;SceneFrameData frame;frame.timeSeconds=phase/60.0;
   frame.qaIsolationMode=isolations[phase];frame.qaEffectMode=phase==6?1:0;frame.qaEffectEnabled=phase!=6;
   service.request(view);RenderGraph graph;service.schedule(graph,frame,base,serial);std::string error;require(graph.compile(error),error.c_str());
   host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer){graph.execute(&commands);});require(service.submitted(serial),"View submission must commit");service.complete(serial);if(phase<3)continue;
   const auto pixels=service.readPixels(view);const auto expected=phase>=8?64*40*4:48*48*4;require(pixels.size()==expected,"View readback must follow resize");
   std::ostringstream metadata;metadata<<'{';renderer->appendCaptureManifestFields(metadata);metadata<<"\"end\":true}";auto state=nlohmann::json::parse(metadata.str());
   require(state.contains("computedMaterialViewPipelines")&&state.contains("computedMaterialViewSelected")&&state.contains("computedMaterialViewEligible"),"Computed material view must expose actual preparation, qualification and selection");
   const bool eligible=setting==0&&isolations[phase]==0&&phase!=6;
   require(state["computedMaterialProgramSupported"].get<bool>()==supported,"Device qualification must be observable");
   if(candidate&&supported)require(state["optimizedMaterialProgramModulesCreated"].get<unsigned>()>0,"Qualified rendering must load actual optimized modules");
   require(state["computedMaterialViewEligible"].get<bool>()==eligible,"Uploaded view qualification must match lighting, diagnostics, effects and computed reflection");
   require((state["computedMaterialViewPipelines"].get<unsigned>()>0)==bool(candidate&&!dynamicOnly&&supported),"Context must control preparation of computed material pipelines");
   require(state["computedMaterialViewSelected"].get<bool>()==(candidate&&!dynamicOnly&&supported&&eligible),"Only qualified actual views may select computed material pipelines");
   require(state["computedMaterialViewFallback"]=="","Valid view preparation must succeed");if(candidate&&!dynamicOnly&&supported&&eligible)++selectedChecks;
   const auto key=std::to_string(lighting)+"-"+std::to_string(setting)+"-"+std::to_string(phase);
   if(candidate){if(pixels!=references.at(key)){
    const auto& expectedPixels=references.at(key);nlohmann::json differences=nlohmann::json::array();unsigned maximumError=0;std::size_t changedBytes=0;
    for(std::size_t byte=0;byte<pixels.size();++byte)if(pixels[byte]!=expectedPixels[byte]){++changedBytes;const auto error=unsigned(std::abs(int(pixels[byte])-int(expectedPixels[byte])));maximumError=std::max(maximumError,error);if(differences.size()<32)differences.push_back({{"byte",byte},{"expected",expectedPixels[byte]},{"actual",pixels[byte]}});}
    nlohmann::json failure={{"device",host.properties.deviceName},{"key",key},{"lighting",lighting},{"setting",setting},{"phase",phase},{"dynamicOnly",dynamicOnly},{"changedBytes",changedBytes},{"maximumByteError",maximumError},{"firstDifferences",differences},{"metadata",state}};
    std::ofstream(output/"failure.json")<<failure.dump(2);std::ofstream original(output/"expected.rgba",std::ios::binary);original.write(reinterpret_cast<const char*>(expectedPixels.data()),expectedPixels.size());std::ofstream actual(output/"actual.rgba",std::ios::binary);actual.write(reinterpret_cast<const char*>(pixels.data()),pixels.size());std::cerr<<failure.dump()<<'\n';throw std::runtime_error("Computed material views and dynamic fallback must preserve independent reference pixels");
   }pixelsCompared+=pixels.size()/4;}else references[key]=pixels;
   receipt["checks"].push_back({{"candidate",candidate},{"lighting",lighting},{"setting",setting},{"phase",phase},{"eligible",eligible},{"bytes",pixels.size()},{"metadata",state}});
  }
  service.release(view);service.complete(serial);service.clear();service.complete(serial);
 }
 }
 }
 require(selectedChecks==(!dynamicOnly&&supported?8U:0U),"Two material workflows must each exercise four qualified view selections");
 require(host.errors.load()==0,"View probe must have zero Vulkan synchronization and validation errors");require(!host.allocator.statistics().liveImages&&!host.allocator.statistics().liveBuffers,"View probe must retire all allocations");
 receipt["validationErrors"]=host.errors.load();receipt["zeroAllocator"]=true;receipt["pixelsCompared"]=pixelsCompared;receipt["selectedChecks"]=selectedChecks;receipt["status"]="passed";
 std::ofstream(output/"summary.json")<<receipt.dump(2);std::cout<<host.properties.deviceName<<": "<<pixelsCompared<<" exact RGBA pixels, "<<selectedChecks<<" qualified selections, dynamic fallback and cleanup passed\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
