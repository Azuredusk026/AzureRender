from pathlib import Path
import os,sys,json,subprocess,re,time
r=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',VK_LOADER_DRIVERS_SELECT='*igvk64*');build=r/'build/ninja-msvc-release';os.environ['PATH']=str(build)+';'+os.environ['PATH']
with (out/'intel-causal-build.log').open('wb') as log:subprocess.run([str(r/'tools/msvc_env.bat'),'cmake','--build','--preset','msvc-release','--target','AzureComputedMaterialViewGpuTests','-j','3'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
original=subprocess.check_output(['git','show','5868d1a:Project/AzureRender/shaders/mesh.frag'],text=True)
selected=(r/'build/runs/20261110-164548-selected-default-view-native-3af93e/selected.frag').read_text();(out/'selected_receiver.glsl').write_bytes((r/'shaders/shadow_receiver_state.glsl').read_bytes())
view=(r/'shaders/mesh.frag').read_text();start=view.index('float sampleCascadeShadow(');end=view.index('#if defined(AZURE_SHADOW_HISTORY)',start);a=original.index('float sampleCascadeShadow(');b=original.index('#if defined(AZURE_SHADOW_HISTORY)',a);view=view[:start]+original[a:b]+view[end:]
manifest=json.loads((build/'shader-reload.json').read_text());programs=[x for x in manifest['programs'] if x['source']=='mesh.frag' and not any(n in x['output'] for n in ['bindless','integral','samples','fog','isolation'])]
print('causal programs per role',len(programs),flush=True);rows=[]
for label,source in [('receiver-only',selected),('view-dynamic-original-receiver',view)]:
 folder=out/('intel-causal-'+label);shaders=folder/'shaders';shaders.mkdir(parents=True);src=out/('intel-causal-'+label+'.frag');src.write_text(source)
 for path in (out/'reference-shaders').glob('*.spv'):os.link(path,shaders/path.name)
 with (out/('intel-causal-'+label+'-compile.log')).open('wb') as log:
  for x in programs:
   target=shaders/x['output'];target.unlink();command=[manifest['compiler'],*x['arguments'],*['-D'+d for d in x['defines']],'-I'+str(r/'shaders'),str(src),'-o',str(target)];subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
   subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe',str(target)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=15)
 command=[str(build/'AzureComputedMaterialViewGpuTests.exe'),str(shaders),str(folder/'pixels'),str(out/'reference-shaders'),'--dynamic-only','--legacy-only']
 with (out/('intel-causal-'+label+'.log')).open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 result=dict(label=label,returnCode=p.returncode,programs=len(programs))
 for name in ['failure.json','summary.json']:
  if (folder/'pixels'/name).is_file():result[name]=json.loads((folder/'pixels'/name).read_text())
 rows.append(result);(out/'intel-causal-results.json').write_text(json.dumps(rows,indent=2));print(label,p.returncode,flush=True)
