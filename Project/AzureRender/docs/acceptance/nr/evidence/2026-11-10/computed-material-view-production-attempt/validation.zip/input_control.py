from pathlib import Path
import sys,os,json,subprocess
r=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',VK_LOADER_DRIVERS_SELECT='*igvk64*');build=r/'build/ninja-msvc-release';os.environ['PATH']=str(build)+';'+os.environ['PATH']
with (out/'input-control-build.log').open('wb') as log:subprocess.run([str(r/'tools/msvc_env.bat'),'cmake','--build','--preset','msvc-release','--target','AzureComputedMaterialViewGpuTests','-j','3'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
rows=[]
for label,extra in [('identity-original',[]),('identity-submission-frozen',['--reset-submissions'])]:
 folder=out/('intel-input-'+label);command=[str(build/'AzureComputedMaterialViewGpuTests.exe'),str(out/'reference-shaders'),str(folder),str(out/'reference-shaders'),'--dynamic-only','--legacy-only',*extra]
 with (out/('intel-input-'+label+'.log')).open('wb') as log:a=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 row=dict(label=label,returnCode=a.returncode)
 for name in ['summary.json','failure.json']:
  if (folder/name).exists():row[name]=json.loads((folder/name).read_text())
 rows.append(row);(out/'intel-input-control-results.json').write_text(json.dumps(rows,indent=2));print(label,a.returncode,flush=True)
