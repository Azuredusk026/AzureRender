from pathlib import Path
import os,sys,subprocess,json
r=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9')
command=[str(r/'tools/msvc_env.bat'),'cmake','--build','--preset','msvc-release','--target','AzureComputedMaterialViewGpuTests','-j','3']
with (out/'gpu-interface-red.log').open('wb') as log:a=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=180)
s=(out/'gpu-interface-red.log').read_text(errors='replace');assert a.returncode!=0 and 'computedMaterialViewSpecializationEnabled' in s and 'C2039' in s,s[-4000:]
(out/'gpu-interface-red.json').write_text(json.dumps(dict(expectedMissingContext=True,returnCode=a.returncode,command=command),indent=2));print(s[-1600:])
