#include "render/ComputedMaterialView.hpp"
#include <array>
#include <iostream>
#include <limits>
#include <stdexcept>
using namespace azurerender;
void require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
int main()try{
 const ComputedMaterialViewInputs valid{1.F,0.F,0.F,1.F,2.F};
 require(computedMaterialViewEligible(valid),"Uploaded default scene/computed view must qualify");
 require(!computedMaterialViewEligible({}),"Uninitialized view must use dynamic shading");
 const std::array<float ComputedMaterialViewInputs::*,5> fields{&ComputedMaterialViewInputs::sceneLighting,&ComputedMaterialViewInputs::isolationMode,&ComputedMaterialViewInputs::effectMode,&ComputedMaterialViewInputs::effectEnabled,&ComputedMaterialViewInputs::reflectionSource};
 const std::array<float,15> values{-1.F,-.5F,-.01F,0.F,.01F,.49F,.5F,.99F,1.F,1.01F,1.5F,2.F,3.F,std::numeric_limits<float>::infinity(),std::numeric_limits<float>::quiet_NaN()};
 unsigned fallback=0;
 for(auto field:fields)for(float value:values){
  auto input=valid;input.*field=value;
  if(value==valid.*field)require(computedMaterialViewEligible(input),"Matching actual input must qualify");
  else {require(!computedMaterialViewEligible(input),"Every mismatched or nonfinite uploaded field must use dynamic shading");++fallback;}
 }
 auto zero=valid;zero.isolationMode=-0.F;zero.effectMode=-0.F;
 require(computedMaterialViewEligible(zero),"Signed zero modes retain default semantics");
 std::cout<<"Computed material view: exact default inputs, "<<fallback<<" independent fallback cases, empty input and signed-zero modes passed\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
