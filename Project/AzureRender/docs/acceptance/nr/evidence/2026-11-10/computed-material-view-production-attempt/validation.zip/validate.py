from pathlib import Path
import os,sys,subprocess,json,time,shutil,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,verify
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside',*sys.argv[1:]]).returncode)
source=inputs(root);(out/'production-source.json').write_text(json.dumps(source,indent=2));os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
config=sys.argv[-1] if sys.argv[-1] in ['Release','Debug'] else 'Release';build=root/('build/ninja-msvc-'+config.lower())
targets=['AzureComputedMaterialViewPolicyTests','AzureComputedMaterialViewGpuTests','AzureDepthPrefillRecordingTests','AzureMaterialClassEarlyDepthTests','AzureBeautyCompositionGpuTests','AzureMaterialUvGradientsGpuTests','AzureReferenceClipProjectionGpuTests','AzureHotReloadTests','AzureShaderCompilerContractTests']
command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
for t in targets:command+=['--test-target',t]
with (out/(config.lower()+'-build.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
shutil.copyfile(build/'build-provenance.json',out/(config.lower()+'-build-provenance.json'))
from build_provenance import digest
originals=json.loads((out/'reference-programs.json').read_text());previous=json.loads((out/'pre-fallback-optimized-products.json').read_text())
assert all(digest(build/'shaders'/name)==sha for name,sha in originals.items())
optimized={name:sha for name,sha in previous.items() if not any(token in name for token in ['integral','fog','_samples'])};assert len(optimized)==256
assert all(digest(build/'shaders'/name.replace('.frag.spv','_receiver.frag.spv'))==sha for name,sha in optimized.items())
manifest=json.loads((build/'shader-reload.json').read_text());assert len(manifest['programs'])==939
(out/(config.lower()+'-program-family-identity.json')).write_text(json.dumps(dict(referencePrograms=len(originals),optimizedPrograms=len(optimized),catalogPrograms=939,referenceExact=True,optimizedExact=True),indent=2))

selector=r'^(AzureRender\.(ComputedMaterialViewPolicy|ComputedMaterialViewGpu|DepthPrefillRecording|MaterialClassEarlyDepth|BeautyCompositionGpu|MaterialUvGradientsGpu|ReferenceClipProjectionGpu|ShaderCompilerContract|ShaderCatalogCompilation|HotReload)|AzureEngine\.(ModuleBoundaries|ModuleBoundaryFixtures))$'
command=['ctest','--test-dir',str(build),'-C',config,'--output-on-failure','--no-tests=error','-R',selector,'--output-junit',str(out/(config.lower()+'-tests.xml'))]
with (out/(config.lower()+'-tests.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=480)
cases=ET.parse(out/(config.lower()+'-tests.xml')).findall('.//testcase');assert len(cases)==12 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases),len(cases)
for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 os.environ['VK_LOADER_DRIVERS_SELECT']=driver
 command=[str(build/'AzureComputedMaterialViewGpuTests.exe'),str(build/'shaders'),str(out/(config.lower()+'-'+device+'-frozen-view')),str(out/'reference-shaders')]
 with (out/(config.lower()+'-'+device+'-frozen-view.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
 summary=json.loads((out/(config.lower()+'-'+device+'-frozen-view/summary.json')).read_text());assert summary['status']=='passed' and summary['pixelsCompared']==99840 and summary['selectedChecks']==(8 if device=='nvidia' else 0)
verify(root,json.loads((build/'build-provenance.json').read_text()));assert inputs(root)==source
(out/(config.lower()+'-validation.json')).write_text(json.dumps(dict(status='passed',tests=len(cases),skips=0,sourceUnchanged=True),indent=2));print(config,'12 checks and both frozen-reference devices passed',flush=True)
