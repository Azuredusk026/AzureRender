from pathlib import Path
import json,numpy as np
out=Path(__file__).resolve().parent;d=json.loads((out/'state.json').read_text());assert d['status']=='qualified' and len(d['captures'])==2
allowed={'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU','NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image'}
assert set(d['captures'][0]['debugMessages'])<=allowed and not d['captures'][1]['debugMessages']
samples={};flagRows={}
for capture in d['captures']:
 assert capture['sourceControlQualified'] and capture['baselineRestored'] and len(capture['runs'])==18 and all(r['qualified'] for r in capture['runs'])
 label=capture['label'];samples[label]={};flagRows[label]={}
 for field,n in [('ambient',4),('line',2)]:
  words=np.zeros((len(d['points']),n),dtype='<u4');flags=[]
  for r in capture['runs']:
   case=r['case']
   if case['field']!=field:continue
   values=np.array(r['values'],dtype='<u4')
   if case['shift']==24:flags.extend((values>>8).tolist());values &=255
   words[:,case['component']] |= values<<case['shift']
  assert len(flags)==len(d['points'])*n and all(v==0 for v in flags),(label,field,flags)
  assert np.isfinite(words.view('<f4')).all();samples[label][field]=words;flagRows[label][field]=flags
rows=[]
for i,pixel in enumerate(d['points']):
 nr=samples['native']['ambient'][i];vr=samples['vulkan']['ambient'][i];nm=samples['native']['line'][i];vm=samples['vulkan']['line'][i]
 nf=nr.view('<f4');vf=vr.view('<f4');nmf=nm.view('<f4');vmf=vm.view('<f4')
 rows.append(dict(pixel=pixel,nativeAmbientBits=nr.tolist(),vulkanAmbientBits=vr.tolist(),nativeAmbient=nf.tolist(),vulkanAmbient=vf.tolist(),nativeLineBits=nm.tolist(),vulkanLineBits=vm.tolist(),nativeLines=nmf.tolist(),vulkanLines=vmf.tolist(),ambientExact=bool(np.all(nr[:3]==vr[:3])),sceneExact=bool(nr[3]==vr[3]),lineExact=bool(np.all(nm==vm)),maximumAmbientAbsolute=float(abs(nf[:3]-vf[:3]).max()),maximumLineAbsolute=float(abs(nmf-vmf).max())))
report=dict(status='qualified-stripe-modulation',points=len(rows),ambientExactPoints=sum(r['ambientExact'] for r in rows),sceneExactPoints=sum(r['sceneExact'] for r in rows),lineExactPoints=sum(r['lineExact'] for r in rows),maximumAmbientAbsolute=max(r['maximumAmbientAbsolute'] for r in rows),maximumLineAbsolute=max(r['maximumLineAbsolute'] for r in rows),rows=rows,qualification=d,scope='Actual ambient color before stripe modulation, plus stripe intensity and saturation. Shader output with full-crop blue qualification and seen/consistency flags.')
for key in ['ambientExactPoints','maximumAmbientAbsolute','sceneExactPoints']:report.pop(key)
for row in rows:
 for key in ['ambientExact','maximumAmbientAbsolute','sceneExact']:row.pop(key)
 for old,new in [('nativeAmbient','nativeCompositeDiffuseBeforeStripe'),('nativeAmbientBits','nativeCompositeDiffuseBeforeStripeBits'),('vulkanAmbient','vulkanAmbientDiffuseBeforeStripe'),('vulkanAmbientBits','vulkanAmbientDiffuseBeforeStripeBits')]:row[new]=row.pop(old)
report['scope']='Stripe intensity and saturation correspond. Native r16 is composite diffuse; Vulkan ambientDiffuse is ambient-only. Raw vectors have different scopes and are not a color-error comparison. Fourth components are native scene visibility and a Vulkan constant-one sentinel.'
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['rows','qualification']},indent=2))
