from pathlib import Path
import renderdoc as rd
import sys,json,struct,zlib,hashlib,traceback
out=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-023220-hair-stripe-modulation-94006f');main=Path('D:/Projects/FYP/Project/AzureRender');prior=out.parent/'20261109-221435-hair-color-closure-430845'
sys.path.insert(0,str(out.parents[2]/'tools'))
from native_render.renderdoc_replay import sampler_binding
points=[r['pixel'] for r in json.loads((prior/'native-visibility-results.json').read_text())['points']];cases=json.loads((out/'cases.json').read_text())
captures=[('native',main/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc',950),('vulkan',main/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc',493)]
result=dict(status='starting',points=points,captures=[]);cap=None;c=None;original=None;replacement=None
def save():(out/'state.json').write_text(json.dumps(result,indent=2)+'\n')
def unsigned_float(word,mantissa):
 exponent=word>>mantissa;fraction=word&((1<<mantissa)-1);assert exponent!=31
 return fraction*2.0**(-14-mantissa) if exponent==0 else (1+fraction/float(1<<mantissa))*2.0**(exponent-15)
try:
 for label,path,event in captures:
  cap=rd.OpenCaptureFile();assert cap.OpenFile(str(path),'',None)==rd.ResultCode.Succeeded
  status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
  c.SetFrameEvent(event,True);pipe=c.GetPipelineState();original=pipe.GetShader(rd.ShaderStage.Pixel);target=pipe.GetOutputTargets()[0].resource
  raw=bytes(pipe.GetShaderReflection(rd.ShaderStage.Pixel).rawBytes);(out/(label+'-source.shader')).write_bytes(raw)
  if label=='native':assert raw==(out/'native-original.shader').read_bytes()
  native=label=='native';stride=4 if native else 8
  def snapshot():
   c.SetFrameEvent(event,True);data=bytes(c.GetTextureData(target,rd.Subresource()));assert len(data)==2560*1440*stride
   return b''.join(data[((1439-y if native else y)*2560+1140)*stride:((1439-y if native else y)*2560+1430)*stride] for y in range(130,440))
  def blue(data):
   if native:return tuple(w[0]>>22 for w in struct.iter_unpack('<I',data))
   return b''.join(data[i+4:i+6] for i in range(0,len(data),8))
  baseline=snapshot();row=dict(label=label,event=event,sourceSha256=hashlib.sha256(raw).hexdigest(),runs=[]);result['captures'].append(row);save()
  try:
   row['samplers']=[sampler_binding(used) for used in pipe.GetSamplers(rd.ShaderStage.Pixel)]
   reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
   row['declaredResources']=[dict(name=r.name,binding=r.fixedBindNumber,index=i) for i,r in enumerate(reflection.readOnlyResources)]
   row['resources']=[dict(index=used.access.index,arrayElement=used.access.arrayElement,resource=str(used.descriptor.resource),format=used.descriptor.format.Name()) for used in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel)]
   descriptions={str(t.resourceId):t for t in c.GetTextures()}
   for used in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel):
    index=used.access.index
    if index>=len(reflection.readOnlyResources):continue
    resource=reflection.readOnlyResources[index]
    selected=(resource.fixedBindNumber==13) if native else resource.name=='styleMaskTexture'
    if not selected:continue
    info=descriptions.get(str(used.descriptor.resource))
    if info is None:continue
    row['rampTexture']=dict(resource=str(info.resourceId),width=info.width,height=info.height,mips=info.mips,format=info.format.Name(),shaderName=resource.name)
    if info.width*info.height<=262144:
     texels=bytes(c.GetTextureData(info.resourceId,rd.Subresource()));(out/(label+'-ramp-top-mip.bin')).write_bytes(texels)
     row['rampTexture'].update(bytes=len(texels),sha256=hashlib.sha256(texels).hexdigest())
    break
  except Exception:row['metadataError']=traceback.format_exc()
  save()
  code=(out/'native-output-control.dxbc').read_bytes() if native else (prior/'native-visibility.spv').read_bytes()
  replacement,errors=c.BuildTargetShader('main',rd.ShaderEncoding.DXBC if native else rd.ShaderEncoding.SPIRV,code,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert replacement!=rd.ResourceId.Null(),errors
  c.ReplaceResource(original,replacement);source=snapshot()
  if native:assert source==baseline
  else:assert source==zlib.decompress((prior/'native-visibility-hdr.zlib').read_bytes())
  (out/(label+'-stored-baseline.zlib')).write_bytes(zlib.compress(source,9));row['sourceControlQualified']=True;row['controlSha256']=hashlib.sha256(code).hexdigest();save()
  c.RemoveReplacement(original);c.FreeTargetResource(replacement);replacement=None;assert snapshot()==baseline
  expected_blue=blue(source)
  for case in cases:
   code=(out/(case['name']+('.dxbc' if native else '.spv'))).read_bytes()
   replacement,errors=c.BuildTargetShader('main',rd.ShaderEncoding.DXBC if native else rd.ShaderEncoding.SPIRV,code,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert replacement!=rd.ResourceId.Null(),errors
   c.ReplaceResource(original,replacement);data=snapshot();qualified=blue(data)==expected_blue
   sample=dict(case=case,qualified=qualified,shaderSha256=hashlib.sha256(code).hexdigest(),values=[]);row['runs'].append(sample);save();assert qualified,(label,case['name'])
   for x,y in points:
    offset=((y-130)*290+x-1140)*stride
    if native:
     packed=struct.unpack_from('<I',data,offset)[0];values=[unsigned_float(packed&2047,6),unsigned_float((packed>>11)&2047,6)]
    else:values=list(struct.unpack_from('<4e',data,offset))[:2]
    digits=[int(round(v*64)) for v in values];assert all(0<=d<=63 for d in digits)
    sample['values'].append(digits[0]|digits[1]<<6)
   c.RemoveReplacement(original);c.FreeTargetResource(replacement);replacement=None;assert snapshot()==baseline;save()
  row['baselineRestored']=True;row['debugMessages']=[str(m.description) for m in c.GetDebugMessages()]
  c.Shutdown();c=None;cap.Shutdown();cap=None;original=None;save()
 result['status']='qualified'
except BaseException:result.update(status='failed',error=traceback.format_exc())
finally:
 if c:
  if original:c.RemoveReplacement(original)
  if replacement:c.FreeTargetResource(replacement)
  c.Shutdown()
 if cap:cap.Shutdown()
 save()
sys.exit(0 if result['status']=='qualified' else 1)
