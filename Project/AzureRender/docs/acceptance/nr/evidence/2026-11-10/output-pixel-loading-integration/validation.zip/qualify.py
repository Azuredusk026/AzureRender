from pathlib import Path
import runpy
o=Path(__file__).resolve().parent
for name in ['intel.py','large_materials.py','capture.py']:
 print('Running '+name,flush=True)
 runpy.run_path(str(o/name),run_name='__main__')
