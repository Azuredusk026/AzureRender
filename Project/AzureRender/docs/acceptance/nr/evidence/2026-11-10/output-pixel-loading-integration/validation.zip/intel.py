from pathlib import Path
import os,sys,json,subprocess,time,hashlib
r=Path.cwd();o=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tools'));from artifact_maintenance import managed_environment
from build_provenance import verify,inputs
os.environ.update(managed_environment(o/'tmp'));os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*'
for k in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(k,None)
before=inputs(r);checks=[]
for config in ['Release','Debug']:
 b=r/('build/ninja-msvc-'+config.lower());verify(r,json.loads((b/'build-provenance.json').read_text()))
 for target,args in [('AzureSampledTextureChannelsGpuTests',[str(b/'shaders/sampled_texture_channels_test.comp.spv')]),('AzureMaterialOutputPrecisionGpuTests',[str(b/'shaders/material_output_precision_test.comp.spv')]),('AzureSurfaceResponseGpuTests',[str(b/'shaders/surface_response_test.comp.spv'),str(r/'assets_public/showcase_looks.json')])]:
  log=o/(config.lower()+'-intel-'+target+'.log');start=time.monotonic()
  with log.open('wb') as f:subprocess.run([str(b/(target+'.exe')),*args],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=240)
  s=log.read_text(errors='replace');assert not any(x in s for x in ['VUID-','SYNC-HAZARD','Validation Error:','Validation Warning:'])
  if target=='AzureSampledTextureChannelsGpuTests':assert 'Intel' in s and 'cases=648' in s and 'validation=0' in s
  checks.append(dict(config=config,target=target,seconds=time.monotonic()-start));print(s.strip(),flush=True)
assert inputs(r)==before
(o/'intel-results.json').write_text(json.dumps(dict(checks=checks,sourceUnchanged=True),indent=2))
