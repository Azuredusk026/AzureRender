from pathlib import Path
import json,hashlib,zipfile,subprocess
r=Path.cwd();o=Path(__file__).resolve().parent
h=lambda b:hashlib.sha256(b).hexdigest()
load=lambda name:json.loads((o/name).read_text())
for name in ['build-results.json','intel-results.json','large-material-results.json','capture-results.json','memory-observations.json']:assert (o/name).is_file(),name
protected=load('protected-files.json')
for n,digest in protected.items():assert h((r/n).read_bytes())==digest,n
assert subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()=='314dda1'
assert len(load('intel-results.json')['checks'])==6
assert len(load('large-material-results.json')['checks'])==4
capture=load('capture-results.json');assert all(x['pngIdentical'] and x['changedPixels']==0 for x in capture['frames'])
assert load('build-results.json')['sourceUnchanged'] and capture['sourceUnchanged'] and capture['productsUnchanged']
assert all(x['tests']==17 and x['skips']==0 for x in load('build-results.json')['checks'])
destination=r/'docs/acceptance/nr/evidence/2026-11-10/output-pixel-loading-integration';destination.mkdir(parents=True,exist_ok=False)
entries={}
for p in sorted(o.rglob('*')):
 if not p.is_file() or 'tmp' in p.relative_to(o).parts or 'dry' in p.relative_to(o).parts:continue
 if p.suffix in ['.json','.jsonl','.log','.xml','.py']:
  assert p.stat().st_size<32*1024*1024,p
  entries[p.relative_to(o).as_posix()]=p.read_bytes()
source_names=set()
for commit in ['61d2f72','67d5096','314dda1']:
 for name in subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',commit],text=True).splitlines():
  prefix='Project/AzureRender/'
  if not name.startswith(prefix):continue
  name=name[len(prefix):]
  if name.startswith(('src/','shaders/','tests/','tools/','schemas/')) or name=='CMakeLists.txt':source_names.add(name)
for name in sorted(source_names):entries['sources/'+name]=(r/name).read_bytes()
archive=destination/'validation.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in entries.items():z.writestr(name,data)
assert archive.stat().st_size<8*1024*1024
members=[dict(path=n,bytes=len(b),sha256=h(b)) for n,b in entries.items()]
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(entries)
 for row in members:assert h(z.read(row['path']))==row['sha256']
mem=load('memory-observations.json')
report=dict(status='public-output-and-prepared-pixel-loading-integration-qualified',sourceHead='314dda1',build=load('build-results.json'),intel=load('intel-results.json'),largeMaterials=load('large-material-results.json'),capture=capture,workingSet=dict(peakBytes=mem['peakWorkingSetBytes'],observedBelow2GiB=mem['peakWorkingSetBytes']<2**31,scope='One full frozen native scene loading run with validation'),protectedFilesUnchanged=len(protected),wholeFrameTimingRuns=0,formalMemoryPassed=False,overallVisualAcceptance='failed-user-review',archive=dict(file='validation.zip',bytes=archive.stat().st_size,sha256=h(archive.read_bytes())),members=members)
(destination/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(archive=report['archive'],members=len(members),peakBytes=mem['peakWorkingSetBytes'])),flush=True)
