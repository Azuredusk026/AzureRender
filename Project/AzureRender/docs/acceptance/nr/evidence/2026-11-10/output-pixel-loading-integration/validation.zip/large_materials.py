from pathlib import Path
import os,sys,base64,io,json,time
import numpy as np
from PIL import Image
r=Path.cwd();o=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tools'));from artifact_maintenance import managed_environment
from build_provenance import verify,inputs
import test_material_output_precision_gpu as probe
original_prepare=probe.prepare

def uri(image):
 stream=io.BytesIO();image.save(stream,format='PNG');return 'data:image/png;base64,'+base64.b64encode(stream.getvalue()).decode()
def prepare_large(folder,family,enabled):
 project,pixels,wanted,isolation=original_prepare(folder,family,enabled)
 path=folder/('plane.gltf' if family=='pbr' else 'assets/panels.gltf');model=probe.read(path)
 active={p.get('material',0) for m in model['meshes'] for p in m['primitives']}
 if family=='pbr':
  images=model.setdefault('images',[]);images.append({'uri':uri(Image.new('RGBA',(256,256),(255,255,255,255)))})
  textures=model.setdefault('textures',[]);textures.append({'source':len(images)-1})
  for index in active:model['materials'][index]['emissiveTexture']={'index':len(textures)-1}
 else:
  sources={model['textures'][model['materials'][i]['pbrMetallicRoughness']['baseColorTexture']['index']]['source'] for i in active}
  for index in sources:
   encoded=model['images'][index]['uri'];assert encoded.startswith('data:image/png;base64,')
   image=Image.open(io.BytesIO(base64.b64decode(encoded.split(',',1)[1]))).convert('RGBA');a=np.asarray(image)
   assert np.all(a==a[0,0]),'Only a constant albedo is enlarged; gradients and normals retain their source sizes'
   model['images'][index]['uri']=uri(image.resize((256,256),Image.Resampling.NEAREST))
 probe.save(path,model);return project,pixels,wanted,isolation
probe.prepare=prepare_large
os.environ.update(managed_environment(o/'tmp'));before=inputs(r);reports=[]
for config in ['Release','Debug']:
 b=r/('build/ninja-msvc-'+config.lower());verify(r,json.loads((b/'build-provenance.json').read_text()))
 for device,selector in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  os.environ['VK_LOADER_DRIVERS_SELECT']=selector
  for k in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(k,None)
  if config=='Debug':os.environ['VK_INSTANCE_LAYERS']='VK_LAYER_KHRONOS_validation';os.environ['VK_LAYER_VALIDATE_SYNC']='1'
  else:
   for k in ['VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC']:os.environ.pop(k,None)
  target=o/('large-'+config.lower()+'-'+device);start=time.monotonic()
  probe.run(b/'AzurePlayer.exe',target,config=='Debug','enabled' if config=='Debug' else 'disabled')
  for name in ['pbr-native','pbr-quantized','hair-native','hair-quantized']:
   manifest=probe.read(target/name/'frames/capture_manifest.json');assert manifest['materialTextureCache']['referencedPixelBytes']>=256*256*4,(name,manifest['materialTextureCache'])
  reports.append(dict(config=config,device=device,seconds=time.monotonic()-start,cases=4,preparedTexturePathConfirmed=True));print(json.dumps(reports[-1]),flush=True)
assert inputs(r)==before
(o/'large-material-results.json').write_text(json.dumps(dict(checks=reports,sourceUnchanged=True,originalLinearBudget=probe.BUDGET),indent=2))
