from pathlib import Path
import json,os,subprocess,sys,shutil,time,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,verify,digest
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
before=inputs(root);checks=[]
targets=['AzureSampledTextureCacheTests','AzureRenderNullRhiPassTests','AzureOutlineProjectionTests','AzureMotionRecordingTests','AzureDepthPrefillRecordingTests','AzureMaterialClassEarlyDepthTests','AzureRenderNullRhiTests','AzureMaterialTextureSharingTests','AzureCharacterRepairTests','AzureSurfaceResponseGpuTests','AzureSampledTextureChannelsGpuTests','AzureAssetLevelTests','AzureProjectStartupTests','AzureLevelRefreshRetirementTests','AzureMaterialOutputPrecisionGpuTests']
selector=r'^(AzureRender\.(SampledTextureCache|NullRhiPass|NullRhi|OutlineProjection|MotionRecording|DepthPrefillRecording|MaterialClassEarlyDepth|MaterialTextureSharing|CharacterRepair|SurfaceResponseGpu|SampledTextureChannelsGpu|MaterialOutputPrecisionGpu)|AzureEngine\.(ModuleBoundaries|ModuleBoundaryFixtures|AssetLevel|ProjectStartup|LevelRefreshRetirement))$'
for config in ['Release','Debug']:
 build=root/('build/ninja-msvc-'+config.lower());command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
 for target in targets:command+=['--test-target',target]
 start=time.monotonic()
 with (out/(config.lower()+'-build.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
 shutil.copyfile(build/'build-provenance.json',out/(config.lower()+'-build-provenance.json'))
 command=['ctest','--test-dir',str(build),'-C',config,'--output-on-failure','--no-tests=error','-R',selector,'--output-junit',str(out/(config.lower()+'-tests.xml'))]
 with (out/(config.lower()+'-tests.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
 cases=ET.parse(out/(config.lower()+'-tests.xml')).findall('.//testcase');assert len(cases)==17 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
 checks.append(dict(config=config,tests=len(cases),skips=0,seconds=time.monotonic()-start));print(json.dumps(checks[-1]),flush=True)
 verify(root,json.loads((build/'build-provenance.json').read_text()))
assert inputs(root)==before

(out/'build-results.json').write_text(json.dumps(dict(checks=checks,sourceUnchanged=True,cacheCasesPerConfiguration=17),indent=2))
print('Both actual host builds and 34 effective checks passed')
