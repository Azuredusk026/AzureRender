from pathlib import Path
import json,shutil
out=Path(__file__).resolve().parent
prior=out.parent/'20261109-234658-native-reciprocal-domain-2562a0'
for name in ['object_shadow.glsl','synthetic-depth.d16','collector.exe']:
 shutil.copyfile(prior/name,out/name)
shutil.copyfile(prior/'native-rcp-correction.2bit',out/'correction.bin')
fixture=dict(width=16,height=8,forwardDepthPath=str(out/'synthetic-depth.d16'),queryPath=str(out/'correction.bin'),samples=2097152,workgroupSize=256,repeatQueries=True)
(out/'fixture.json').write_text(json.dumps(fixture,indent=2))
source=(prior/'domain.comp').read_text()
source=source.replace('#include "native_receiver_precise.glsl"','')
source=source.replace('void main(){','#include "compact_rcp.glsl"\nvoid main(){')
source=source[:source.index('    }else{')]+'''    }else{
        uint base=(i-11u)*4u;
        outputData.results[i]=uintBitsToFloat(uvec4(profileNormalizedReciprocal(base),profileNormalizedReciprocal(base+1u),profileNormalizedReciprocal(base+2u),profileNormalizedReciprocal(base+3u)));
    }
}
'''
source=source.replace('uint i=gl_GlobalInvocationID.x;','uint i=gl_GlobalInvocationID.x;if(i>=2097163u)return;')
(out/'compact.comp').write_text(source)
runner=(prior/'receiver.py').read_text().replace("['lookup-filter','lookup-world']","['compact']").replace("out/'lookup-fixture.json'","out/'fixture.json'")
(out/'run.py').write_text(runner)
print('Prepared exact quotient and two-bit residual exhaustive fixture')
