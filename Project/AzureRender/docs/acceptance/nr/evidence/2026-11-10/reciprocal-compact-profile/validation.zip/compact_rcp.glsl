// Private diagnostic: exact binary32 reciprocal on normalized [1,2).
uint roundedNormalizedReciprocal(uint index) {
    if(index==0u)return 0x3f800000u;
    uint denominator=0x800000u|index,remainder=0x800000u,quotient=0u;
    for(int bit=0;bit<24;++bit){
        remainder<<=1u;quotient<<=1u;
        if(remainder>=denominator){remainder-=denominator;quotient|=1u;}
    }
    uint twice=remainder<<1u;
    quotient+=uint(twice>denominator||(twice==denominator&&(quotient&1u)!=0u));
    return 0x3f000000u|(quotient&0x7fffffu);
}
uint profileNormalizedReciprocal(uint index) {
    uint packed=floatBitsToUint(queries.values[index>>6u][int((index>>4u)&3u)]);
    uint code=(packed>>((index&15u)*2u))&3u;
    return uint(int(roundedNormalizedReciprocal(index))+int(code)-1);
}
