from pathlib import Path
import json,zlib,math,numpy as np
out=Path(__file__).resolve().parent;d=json.loads((out/'state.json').read_text());assert d['status']=='qualified' and len(d['captures'])==2
allowed={'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU','NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image'}
assert set(d['captures'][0]['debugMessages'])<=allowed and not d['captures'][1]['debugMessages']
samples={}
for c in d['captures']:
 assert c['sourceControlQualified'] and c['baselineRestored'] and len(c['runs'])==9 and all(r['qualified'] for r in c['runs'])
 words=np.zeros((len(d['points']),3),dtype='<u4')
 for r in c['runs']:
  case=r['case'];values=np.array(r['values'],dtype='<u4')
  if case['shift']==24:assert (values<=255).all()
  words[:,case['component']] |= values<<case['shift']
 assert np.isfinite(words.view('<f4')).all();samples[c['label']]=words
def r11code(value,m):
 value=float(value)
 if value<=0:return 0
 exponent=math.frexp(value)[1]-1
 if exponent>15:return 31<<m
 if exponent < -14:return int(math.floor(math.ldexp(value,14+m)))
 return ((exponent+15)<<m)|int(math.floor((math.ldexp(value,-exponent)-1)*(1<<m)))
nativeStored=np.frombuffer(zlib.decompress((out/'native-stored-baseline.zlib').read_bytes()),dtype='<u4').reshape(310,290)
vkStored=np.frombuffer(zlib.decompress((out/'vulkan-stored-baseline.zlib').read_bytes()),dtype='<u2').reshape(310,290,4)
material=json.loads((out.parent/'20261110-005429-hair-interpolated-basis-afd897/results.json').read_text());stable={tuple(r['pixel']):r['parameterSampleExact'] for r in material['rows'] if r['field']=='normal'}
rows=[]
for i,(x,y) in enumerate(d['points']):
 n=samples['native'][i];v=samples['vulkan'][i];nf=n.view('<f4');vf=v.view('<f4');word=int(nativeStored[y-130,x-1140])
 nativeCodes=[word&2047,(word>>11)&2047,word>>22];predicted=[r11code(f,m) for f,m in zip(nf,[6,6,5])];vkCodes=[r11code(f,m) for f,m in zip(vf,[6,6,5])]
 half=np.asarray(vf,dtype='<f2');rne=half.view('<u2').copy();rtz=rne.copy();over=abs(half.astype('f8'))>abs(vf.astype('f8'));rtz[over]-=1
 stored=vkStored[y-130,x-1140,:3].copy()
 rows.append(dict(pixel=[x,y],nativeBits=n.tolist(),vulkanBits=v.tolist(),native=nf.tolist(),vulkan=vf.tolist(),
  maximumAbsolute=float(abs(nf-vf).max()),parameterSampleExact=stable[x,y],nativeStoredCodes=nativeCodes,nativePredictedTowardZero=predicted,
  nativeStorageQualified=predicted==nativeCodes,vulkanStoredBits=stored.tolist(),vulkanNearestEvenBits=rne.tolist(),vulkanTowardZeroBits=rtz.tolist(),
  vulkanStorageNearestEvenQualified=bool(np.all(rne==stored)),vulkanStorageTowardZeroQualified=bool(np.all(rtz==stored)),
  vulkanTowardZeroCodes=vkCodes,vulkanTowardZeroMatchesNativeStored=vkCodes==nativeCodes))
report=dict(status='actual-final-float-comparison',points=len(rows),nativeStoredQualifiedPoints=sum(r['nativeStorageQualified'] for r in rows),
 vulkanNearestEvenQualifiedPoints=sum(r['vulkanStorageNearestEvenQualified'] for r in rows),vulkanTowardZeroQualifiedPoints=sum(r['vulkanStorageTowardZeroQualified'] for r in rows),
 vulkanOutputTowardZeroMatchesNative=sum(r['vulkanTowardZeroMatchesNativeStored'] for r in rows),maximumAbsolute=max(r['maximumAbsolute'] for r in rows),rows=rows,qualification=d,
 scope='Actual pre-attachment floating outputs; native copy control and full-crop blue qualification. Storage reconstruction independently qualifies each point. Native visibility source control retained on Vulkan; production unchanged.')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['rows','qualification']},indent=2))
assert report['nativeStoredQualifiedPoints']==len(rows),'Native final-float probe did not reconstruct every stored native value'
assert max(report['vulkanNearestEvenQualifiedPoints'],report['vulkanTowardZeroQualifiedPoints'])==len(rows),'No single half conversion reconstructs every Vulkan stored value'
