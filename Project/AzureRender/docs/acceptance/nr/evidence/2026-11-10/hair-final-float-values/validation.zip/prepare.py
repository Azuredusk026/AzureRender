from pathlib import Path
import sys,struct,json,subprocess
out=Path(__file__).resolve().parent;sys.path.insert(0,str(out))
from dxbc_util import chunks,words,instructions,opcode,inst,dest,source,imm,fbits,rebuild,checksum
raw=(out/'native-original.shader').read_bytes();assert checksum(raw)==raw[4:20]
ops={opcode(n) for n in ['MOV','MUL','MAD','ADD','MAX','MIN','MOVC']}
def native_probe(component=None,shift=0):
 parts=chunks(raw);idx=next(i for i,(kind,_) in enumerate(parts) if kind in [b'SHEX',b'SHDR']);w=words(parts[idx][1]);items=list(instructions(w))
 decl=next(i for i in items if i[2]==opcode('DCL_TEMPS'));capture=w[decl[1]+1];scratch=capture+1;w[decl[1]+1]=capture+2
 writes=[]
 for pc,at,op,n in items:
  if op not in ops:continue
  operand=at+1
  while w[operand-1]&0x80000000:operand+=1
  token=w[operand]
  if ((token>>12)&255)==2 and w[operand+1]==0:writes.append((at,n,operand,token))
 assert len(writes)==3
 for at,n,operand,token in reversed(writes):
  w[operand]=token&~(255<<12);w[operand+1]=capture
  w[at+n:at+n]=inst('MOV',[token,0],[2|(1<<2)|(0xe4<<4)|(1<<20),capture])
 w[1]=len(w)
 if component is not None:
  end=next(i[1] for i in instructions(w) if i[2]==opcode('RET'));extra=[]
  for mask,offset in [(1,shift),(2,shift+6)]:
   extra+=inst('USHR',dest(scratch),source(capture,component),imm(offset));extra+=inst('AND',dest(scratch),source(scratch),imm(63))
   extra+=inst('UTOF',dest(scratch),source(scratch));extra+=inst('MUL',dest(scratch),source(scratch),imm(fbits(1/64)));extra+=inst('MOV',dest(0,mask,True),source(scratch))
  w[end:end]=extra
 w[1]=len(w);parts[idx]=(parts[idx][0],struct.pack('<'+'I'*len(w),*w));code=rebuild(raw,parts);assert checksum(code)==code[4:20];return code
(out/'native-output-control.dxbc').write_bytes(native_probe())
base=out.parent/'20261109-221435-hair-color-closure-430845';text=(base/'native-visibility.spvasm').read_text();sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin');cases=[]
for component in range(3):
 for shift in [0,12,24]:
  name=f'color-{component}-{shift}';(out/(name+'.dxbc')).write_bytes(native_probe(component,shift))
  declarations=f'''%final_probe_scale = OpConstant %float 0.015625
%final_probe_mask = OpConstant %uint 63
%final_probe_shift_r = OpConstant %uint {shift}
%final_probe_shift_g = OpConstant %uint {shift+6}
'''
  start=text.index('       %main = OpFunction');t=text[:start]+declarations+text[start:];start=t.index('%main = OpFunction');end=t.index('OpFunctionEnd',start);body=t[start:end];assert body.count('OpReturn\n')==1
  probe=f'''%final_probe_original = OpLoad %v4float %outputColor
%final_probe_value = OpCompositeExtract %float %final_probe_original {component}
%final_probe_bits = OpBitcast %uint %final_probe_value
%final_probe_rs = OpShiftRightLogical %uint %final_probe_bits %final_probe_shift_r
%final_probe_gs = OpShiftRightLogical %uint %final_probe_bits %final_probe_shift_g
%final_probe_rb = OpBitwiseAnd %uint %final_probe_rs %final_probe_mask
%final_probe_gb = OpBitwiseAnd %uint %final_probe_gs %final_probe_mask
%final_probe_rf = OpConvertUToF %float %final_probe_rb
%final_probe_gf = OpConvertUToF %float %final_probe_gb
%final_probe_r = OpFMul %float %final_probe_rf %final_probe_scale
%final_probe_g = OpFMul %float %final_probe_gf %final_probe_scale
%final_probe_b = OpCompositeExtract %float %final_probe_original 2
%final_probe_a = OpCompositeExtract %float %final_probe_original 3
%final_probe_color = OpCompositeConstruct %v4float %final_probe_r %final_probe_g %final_probe_b %final_probe_a
OpStore %outputColor %final_probe_color
OpReturn
'''
  t=t[:start]+body.replace('OpReturn\n',probe)+t[end:];(out/(name+'.spvasm')).write_text(t)
  for cmd in [[str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/(name+'.spvasm')),'-o',str(out/(name+'.spv'))],[str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/(name+'.spv'))]]:subprocess.run(cmd,check=True)
  cases.append(dict(name=name,component=component,shift=shift))
(out/'cases.json').write_text(json.dumps(cases,indent=2));print('Prepared native full-output copy control and nine paired final-float probes')
