import ctypes,json,subprocess,time
from ctypes import wintypes

class Memory(ctypes.Structure):
    _fields_=[('cb',wintypes.DWORD),('faults',wintypes.DWORD)]+[(name,ctypes.c_size_t) for name in ['peakWorkingSet','workingSet','peakPagedPool','pagedPool','peakNonPagedPool','nonPagedPool','pagefile','peakPagefile','privateUsage']]

def run_observed(command,log,out,timeout=550):
    query=ctypes.WinDLL('psapi').GetProcessMemoryInfo
    query.argtypes=[wintypes.HANDLE,ctypes.POINTER(Memory),wintypes.DWORD];query.restype=wintypes.BOOL
    start=time.monotonic();samples=[]
    with subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT) as process:
        while process.poll() is None:
            memory=Memory();memory.cb=ctypes.sizeof(memory)
            if query(wintypes.HANDLE(int(process._handle)),ctypes.byref(memory),memory.cb):
                samples.append(dict(unixSeconds=time.time(),seconds=time.monotonic()-start,workingSetBytes=memory.workingSet,peakWorkingSetBytes=memory.peakWorkingSet,privateBytes=memory.privateUsage))
            if time.monotonic()-start>timeout:
                process.kill();process.wait();raise subprocess.TimeoutExpired(command,timeout)
            time.sleep(.2)
        result=subprocess.CompletedProcess(command,process.returncode)
    (out/'memory-observations.json').write_text(json.dumps(dict(samples=samples,peakWorkingSetBytes=max((s['peakWorkingSetBytes'] for s in samples),default=0)),indent=2))
    return result
