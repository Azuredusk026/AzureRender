from pathlib import Path
import json,subprocess,sys,time,os
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from artifact_maintenance import managed_environment
from gpu_environment import wait_and_record
os.environ.update(managed_environment(out/'tmp'))
os.environ['DOTNET_ROOT']='D:/Tools/dotnet9'
for key in ['VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LOADER_DEBUG','VK_LAYER_ENABLES','VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
from run_playable_performance import freeze_products
verify(root,json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text()))
source=inputs(root);products=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
frozen=json.loads((root/'build/runs/20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text())
def mounted():
 result={};shared={}
 for p in frozen:
  path=Path(p);st=path.stat();key=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
  if key not in shared:shared[key]=digest(path)
  result[p]=shared[key]
 return result
assert mounted()==frozen
(out/'frozen-inputs.json').write_text(json.dumps(dict(source=source,products=products,project=frozen),indent=2))
wait_and_record(out/'startup-environment.json',timeout=60)
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;start=time.monotonic()
env=os.environ.copy();env.pop('VK_DRIVER_FILES',None);env.pop('VK_ICD_FILENAMES',None)
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'capture_current.py')]
with (out/'capture-driver.log').open('wb') as log:
 r=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=580)
state=json.loads((out/'state.json').read_text());assert r.returncode==0 and state['status']=='captured',state
assert inputs(root)==source and all(digest(Path(p))==v for p,v in products.items()) and mounted()==frozen
used=sum(p.stat().st_size for p in out.rglob('*') if p.is_file());assert used<=2**31,used
(out/'capture-result.json').write_text(json.dumps(dict(status='captured',seconds=time.monotonic()-start,sourceBase='274615b',diagnosticExtent=[1280,720],formalAcceptance=False,sourceUnchanged=True,productsUnchanged=True,mountedInputsUnchanged=True,usedBytes=used,capture=state),indent=2))
print(json.dumps(dict(status='captured',seconds=time.monotonic()-start,usedBytes=used)),flush=True)
