from pathlib import Path
import json,numpy as np,runpy,zlib
out=Path(__file__).resolve().parent;d=json.loads((out/'state.json').read_text());assert d['status']=='qualified' and len(d['captures'])==1;c=d['captures'][0];assert c['sourceControlQualified'] and c['fullColorControlQualified'] and c['baselineRestored'] and not c['debugMessages'] and len(c['runs'])==9 and all(x['qualified'] for x in c['runs']);w=np.zeros((31,3),dtype='<u4');flags=[]
for r in c['runs']:
 q=r['case'];a=np.array(r['values'],dtype='<u4')
 if q['shift']==24:flags.extend((a>>8).tolist());a &=255
 w[:,q['component']]|=a<<q['shift']
assert len(flags)==93 and all(v==0 for v in flags);a=w.view('<f4');assert np.isfinite(a).all();prior=json.loads((out.parent/'20261110-024017-hair-main-chroma-operation-d9ef14/results.json').read_text());source={tuple(x['pixel']):x for x in prior['rows']};inputRows=[]
for i,p in enumerate(d['points']):
 n=source[tuple(p)];error=abs(a[i]-np.array(n['pre'][:3]));inputRows.append(dict(pixel=p,vulkanBits=w[i].tolist(),vulkan=a[i].tolist(),native=n['pre'][:3],maximumAbsolute=float(error.max()),group=n['largeChromaStableMaterialGroup']))
group=[x for x in inputRows if x['group']];b=runpy.run_path(str(out/'baseline.py'));expected=b['expected'];mask=b['mask'];bad=b['bad'];colorRows=[];control=None;controlFailed=None
for name in ['control','candidate']:
 a=np.frombuffer(zlib.decompress((out/(name+'-final.zlib')).read_bytes()),dtype='u1').reshape(310,290,4)[:,:,[2,1,0]].astype('i4');delta=abs(a-expected);failed=mask&(delta.max(axis=2)>1)
 if name=='control':control=a;controlFailed=failed;assert int(failed.sum())==31 and int(delta[mask].max())==6
 colorRows.append(dict(name=name,maskPixels=int(mask.sum()),pixelsOverOneByte=int(failed.sum()),maximumByteError=int(delta[mask].max()),meanAbsoluteByteError=float(delta[mask].mean()),resolvedOriginalFailures=int((bad&~failed).sum()),newOriginalFailures=int((~bad&failed).sum()),resolvedControlFailures=int((controlFailed&~failed).sum()),newAgainstControlFailures=int((~controlFailed&failed).sum()),changedHairPixels=int((np.any(a!=control,axis=2)&mask).sum()),failures=[dict(pixel=[int(x+1140),int(y+130)],absoluteError=delta[y,x].tolist()) for y,x in zip(*np.where(failed))]))
r=dict(status='diagnostic-selected-main-composite',inputRows=inputRows,largeChromaGroupMaximumInputError=max(x['maximumAbsolute'] for x in group),maximumInputError=max(x['maximumAbsolute'] for x in inputRows),colorRows=colorRows,qualification=d,execution=json.loads((out/'execution.json').read_text()),scope='Private Vulkan candidate explicitly reconstructs selected-main diffuse and both selected-main hair lobes with ambient diffuse, excludes clustered local lights, and tests the unchanged complete frozen 17017-pixel original hair mask.')
(out/'results.json').write_text(json.dumps(r,indent=2)+'\n');print('Input error',r['largeChromaGroupMaximumInputError'],r['maximumInputError']);print(json.dumps([{k:v for k,v in x.items() if k!='failures'} for x in colorRows],indent=2))
