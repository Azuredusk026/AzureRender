from pathlib import Path
import subprocess,json,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];main=Path('D:/Projects/FYP/Project/AzureRender');prior=out.parent/'20261109-234658-native-reciprocal-domain-2562a0'
cmd=(prior/'compile-command.txt').read_text().replace(str(main/'src').replace('/','\\'),str(root/'src').replace('/','\\')).replace(str(main/'tests').replace('/','\\'),str(root/'tests').replace('/','\\')).replace(str(prior).replace('/','\\'),str(out).replace('/','\\')).replace('collector.cpp','CharacterRepairTests.cpp').replace(str(out/'CharacterRepairTests.cpp').replace('/','\\'),str(root/'tests/CharacterRepairTests.cpp').replace('/','\\')).replace('collector.obj','CharacterRepairTests-red.obj').replace('/showIncludes','')
cmd='"'+str(main/'tools/msvc_env.bat')+'" '+cmd;(out/'red-command.txt').write_text(cmd)
with (out/'red-build.log').open('wb') as log:r=subprocess.run(cmd,cwd=root,shell=True,stdout=log,stderr=subprocess.STDOUT)
text=(out/'red-build.log').read_text(errors='replace');assert r.returncode!=0 and 'MaterialFeatureR11G11B10Output' in text and ('C2039' in text or 'C2065' in text),text[-3000:]
report=dict(status='expected-contract-compile-failure',exitCode=r.returncode,testSha256=hashlib.sha256((root/'tests/CharacterRepairTests.cpp').read_bytes()).hexdigest(),missingApi='AssetMaterialFeature::MaterialFeatureR11G11B10Output');(out/'red-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
