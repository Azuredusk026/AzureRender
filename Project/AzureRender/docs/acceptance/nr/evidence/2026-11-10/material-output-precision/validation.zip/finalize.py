from pathlib import Path
import json,hashlib,re,zipfile
import numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;root=out.parents[2]
report=json.loads((out/'public-checks.json').read_text());four=json.loads((out/'default-four-results.json').read_text());assert four['allExact']
for relative,wanted in json.loads((out/'frozen-source.json').read_text()).items():assert hashlib.sha256((root/relative).read_bytes()).hexdigest()==wanted,relative
reference=root/'build/runs/20261110-030251-hair-main-chroma-public-9e799c/default-four-frames'
for frame in four['frames']:
 actual=out/'default-four-frames'/frame['frame'];prior=reference/frame['frame'];assert hashlib.sha256(prior.read_bytes()).hexdigest()==frame['expectedSha256']
 a=np.array(Image.open(actual).convert('RGB'));b=np.array(Image.open(prior).convert('RGB'));assert np.array_equal(a,b)
 frame.update(rgbDifferentPixels=0,rgbMaximumByteError=0,rgbSha256=hashlib.sha256(a.tobytes()).hexdigest())
report.update(status='public-output-precision-validated',defaultFour=four,sourceCommitBase='6760300',productionOutputFeatureDefault=False,materialSurfaceProfileLayoutVersion=22,materialSurfaceProfileBytes=352)
for cfg in ['release','debug']:
 for dev in ['nvidia','intel']:
  text=(out/f'{cfg}-{dev}-numeric.log').read_text(errors='replace');assert not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I)
  assert '102400 inputs, 819200 GPU component comparisons' in text
report['binaryIdentity']=json.loads((out/'verified-binaries.json').read_text())
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
e=root/'docs/acceptance/nr/evidence/2026-11-10/material-output-precision';e.mkdir(parents=True,exist_ok=True)
allowed={'.py','.json','.log','.txt','.spv'}
files=[(p,p.name) for p in out.iterdir() if p.is_file() and p.suffix in allowed]
for folder in out.glob('*-images'):
 for p in folder.rglob('*'):
  if p.is_file() and p.suffix in {'.png','.json','.jsonl','.gltf','.azureproject','.azurelevel','.log'} and 'tmp' not in p.relative_to(out).parts and '.azcache' not in p.name:
   files.append((p,str(p.relative_to(out)).replace('\\','/')))
for relative in json.loads((out/'frozen-source.json').read_text()):files.append((root/relative,'source/'+relative))
for relative in ['tools/test_material_output_precision_gpu.py','docs/runtime/material-output-precision.md','docs/acceptance/nr/material-output-precision.md']:
 files.append((root/relative,'source/'+relative))
for p in ['capture_manifest.json']:
 f=out/'default-four-frames'/p
 if f.exists():files.append((f,'default-four-frames/'+p))
z=e/'validation.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,9) as a:
 for p,name in files:a.write(p,name)
assert z.stat().st_size<=8388608
report.update(archiveBytes=z.stat().st_size,archiveSha256=hashlib.sha256(z.read_bytes()).hexdigest(),archiveFiles=[])
with zipfile.ZipFile(z) as a:
 assert a.testzip() is None
 for n in a.namelist():
  data=a.read(n);report['archiveFiles'].append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(e/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=report['status'],archiveBytes=report['archiveBytes'],archiveSha256=report['archiveSha256'],members=len(report['archiveFiles']),numericComparisons=report['numericComponentComparisons'],images=report['images'],defaultFourExact=True),indent=2))
