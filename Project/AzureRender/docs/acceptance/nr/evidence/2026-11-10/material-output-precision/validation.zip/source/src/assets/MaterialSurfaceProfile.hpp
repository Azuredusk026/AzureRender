#pragma once
#include "assets/GltfLoader.hpp"
#include "assets/MaterialBlendDepth.hpp"
#include "assets/MaterialOutputPrecision.hpp"
#include "assets/MaterialRimResponse.hpp"
#include <cstddef>
#include <type_traits>

namespace azurerender {
// Binding 27 is a versioned union, indexed by the stable material order.
struct alignas(16) PackedMaterialSurfaceProfile {
    static constexpr unsigned kLayoutVersion=22;
    using Row=std::array<float,4>;
    std::array<Row,22> rows=[] {
        std::array<Row,22> value{};value[19][3]=1;return value;
    }();
};
static_assert(std::is_standard_layout_v<PackedMaterialSurfaceProfile>);
static_assert(sizeof(PackedMaterialSurfaceProfile)==352);
static_assert(alignof(PackedMaterialSurfaceProfile)==16);
static_assert(offsetof(PackedMaterialSurfaceProfile,rows)==0);
static_assert(sizeof(PackedMaterialSurfaceProfile::Row)==16);
static_assert(offsetof(PackedMaterialSurfaceProfile,rows)+5*sizeof(PackedMaterialSurfaceProfile::Row)==80);

inline PackedMaterialSurfaceProfile packProjectedHairSurfaceProfile(const AssetMaterial::ProjectedHairRamp& hair) {
    PackedMaterialSurfaceProfile result;
    auto& rows=result.rows;
    rows[0]={hair.primaryShift,hair.secondaryShift,hair.intensity,hair.secondaryRange};
    rows[1]={hair.edgeFade,hair.specularNormalScale,hair.directionX,hair.surfaceNormalScale};
    rows[2]={hair.secondaryColor[0],hair.secondaryColor[1],hair.secondaryColor[2],
        hair.surfaceResponse==AssetMaterial::ProjectedHairRamp::SurfaceResponse::StrandDiffuse?1.F:0.F};
    for(unsigned axis=0;axis<3;++axis)for(unsigned component=0;component<3;++component)
        rows[axis+3][component]=hair.objectBasis[axis*3+component];
    rows[3][3]=hair.diffuseScale;
    rows[4][3]=hair.tangentSign;
    if(hair.virtualLight)rows[6]={1,hair.virtualBlend,hair.objectGain,0};
    if(hair.line.present){
        rows[7]={hair.line.frequency,hair.line.strandShift,hair.line.range,hair.line.depth};
        rows[8]={hair.line.alternation,hair.line.saturation,1,hair.line.mainDiffuse?1.F:0.F};rows[9]=hair.line.uvTransform;
    }
    if(hair.lighting.present) {
        const auto& light=hair.lighting;
        const auto source=light.characterVisibility==AssetMaterial::CharacterVisibility::One
            ?0U:static_cast<unsigned>(light.characterVisibility)+1U;
        rows[6][0]=static_cast<float>((hair.virtualLight?1U:0U)|(source<<1U));
        rows[5][3]=light.shadowScale;rows[6][3]=light.transparentHighlights?2.F:1.F;
        if(light.mainBrightnessSaturation)rows[6][3]+=8.F;
        rows[10]={light.ambientColor[0],light.ambientColor[1],light.ambientColor[2],light.shadowBrightness};
        rows[11]={light.mainColor[0],light.mainColor[1],light.mainColor[2],light.shadowSaturation};
    }
    if(hair.materialSnapshotNormal)rows[6][3]+=4.F;
    return result;
}

inline PackedMaterialSurfaceProfile packEyeSurfaceProfile(const AssetMaterial::EyeSurface& eye) {
    PackedMaterialSurfaceProfile result{{{{eye.parallaxScale,eye.matcapNormalScale,eye.alphaPremultiply,eye.matcapShadowFloor},
        {eye.highlightColor[0],eye.highlightColor[1],eye.highlightColor[2],0},
        {eye.scatteringColor[0],eye.scatteringColor[1],eye.scatteringColor[2],0},
        eye.matcapColor,{eye.directWeights[0],eye.directWeights[1],eye.directWeights[2],0},eye.uvScaleOffset}}};
    result.rows[19][3]=1;
    if(eye.nprLighting){
        result.rows[6]={eye.shadowScale,0,0,1};
        result.rows[7]={eye.ambientColor[0],eye.ambientColor[1],eye.ambientColor[2],0};
        result.rows[8]={eye.mainColor[0],eye.mainColor[1],eye.mainColor[2],0};
    }
    return result;
}

inline PackedMaterialSurfaceProfile packMaterialSurfaceProfile(const AssetMaterial& material) {
    validateUnlitSubmission(material.unlitTextureLayers);
    validateMaterialBlendDepth(material);
    validateMaterialOutputPrecision(material);
    validateMaterialRimResponse(material);
    if(material.projectedHairRamp.lighting.mainBrightnessSaturation&&
        (!material.projectedHairRamp.present||!material.projectedHairRamp.lighting.present
            ||material.projectedHairRamp.surfaceResponse!=AssetMaterial::ProjectedHairRamp::SurfaceResponse::StrandDiffuse
            ||material.materialProfileVersion!=2||material.materialClass!=AssetMaterialClass::Hair
            ||!(material.materialFeatures&MaterialFeatureDiffuseRamp)))
        throw std::invalid_argument("Main brightness saturation requires a lit strand-diffuse hair profile in version two");
    if(material.projectedHairRamp.materialSnapshotNormal&&(!material.projectedHairRamp.present
        ||material.materialProfileVersion!=2||material.materialClass!=AssetMaterialClass::Hair))
        throw std::invalid_argument("projectedRamp.snapshotNormal requires a version 2 projected hair profile");
    if(material.projectedHairRamp.lighting.transparentHighlights&&
        (!material.projectedHairRamp.present||!material.projectedHairRamp.lighting.present||material.alphaMode!=AssetAlphaMode::Blend))
        throw std::invalid_argument("Transparent highlights require a lit projected hair profile on a transparent receiver");
    validateMaterialCoverage(material);
    const bool lit=(material.materialFeatures&(MaterialFeatureUnlitSurface|MaterialFeatureMultiplyComposite|MaterialFeatureOverlay))==0
        &&!material.unlitTextureLayers.present&&material.materialClass!=AssetMaterialClass::Overlay;
    const bool microfacetClass=(material.materialClass==AssetMaterialClass::Generic||material.materialClass==AssetMaterialClass::Fabric
        ||material.materialClass==AssetMaterialClass::Metal);
    const bool ordinary=microfacetClass&&!material.nprDiffuse.present&&!material.projectedHairRamp.present&&!material.eyeSurface.present;
    validateMaterialLighting(material.environmentLighting,material.mainLightShadow,material.materialProfileVersion,lit,ordinary,microfacetClass);
    const bool nprColorSurface=material.materialClass==AssetMaterialClass::Generic||material.materialClass==AssetMaterialClass::Skin
        ||material.materialClass==AssetMaterialClass::Fabric||material.materialClass==AssetMaterialClass::Metal;
    validateNprRampComposition(material.nprDiffuse.rampComposition,material.nprDiffuse.present&&lit&&nprColorSurface
        &&!material.projectedHairRamp.present&&!material.eyeSurface.present,material.materialProfileVersion,
        (material.materialFeatures&MaterialFeatureDiffuseRamp)!=0);
    validateNprShadowSaturation(material.nprDiffuse.shadowSaturation,material.nprDiffuse.present&&lit
        &&(nprColorSurface||material.materialClass==AssetMaterialClass::Face),material.materialProfileVersion);
    validateMaterialRadianceScale(material.radianceScale,
        (material.materialFeatures&MaterialFeatureMultiplyComposite)!=0);
    validateMaterialDisplayTransform(material.displayTransform,
        (material.materialFeatures&MaterialFeatureMultiplyComposite)!=0
        ||(material.unlitTextureLayers.present&&material.unlitTextureLayers.composite==UnlitTextureLayers::Composite::Additive));
    PackedMaterialSurfaceProfile result;
    if(material.unlitTextureLayers.present) {
        const auto& p=material.unlitTextureLayers;auto& r=result.rows;
        r[0]=p.layers[0].scaleOffset;r[1]=p.layers[0].rotation;
        r[2]={p.layers[0].speed[0],p.layers[0].speed[1],0,0};
        if(p.layerCount==2) {r[2][2]=p.layers[1].speed[0];r[2][3]=p.layers[1].speed[1];
            r[3]=p.layers[1].scaleOffset;r[4]=p.layers[1].rotation;}
        r[5]={p.clockRate,p.clockOffsetSeconds,p.softDistance,p.softBias};
        r[6]=p.tint;r[7]=p.blendTint;
        r[8]={p.highlightThreshold,p.highlightGain,p.postExposureWeight,p.globalColorWeight};
        r[9]={p.layers[0].sampleMode==UnlitTextureLayer::SampleMode::RedAsAlpha?1.F:0.F,
            p.layers[1].sampleMode==UnlitTextureLayer::SampleMode::RedAsAlpha?1.F:0.F,
            p.layerCount==1?0.F:p.layers[1].role==UnlitTextureLayer::Role::Mask?1.F:2.F,p.softIntersectionEnabled?1.F:0.F};
        if(p.viewDepthFadePresent){r[10]=p.viewDepthFade;r[11][0]=1;}
        r[11][1]=p.useVertexColor?1.F:0.F;
        if(p.viewCoveragePresent){r[11][2]=1;r[12]=p.viewCoverage;}
        if(p.coverageLayer.present) {
            const auto& coverage=p.coverageLayer;const auto& layer=coverage.sample;r[11][3]=1;
            r[13]=layer.scaleOffset;r[14]=layer.rotation;
            r[15]={layer.speed[0],layer.speed[1],layer.sampleMode==UnlitTextureLayer::SampleMode::RedAsAlpha?1.F:0.F,0};
            r[16]={coverage.threshold,coverage.gain,0,0};
        }
        if(p.baseUvDistortion.present) {
            const auto& d=p.baseUvDistortion;const auto& layer=d.sample;r[16][2]=1;
            r[17]=layer.scaleOffset;r[18]=layer.rotation;
            r[19]={layer.speed[0],layer.speed[1],d.channels==UnlitTextureLayers::BaseUvDistortion::Channels::Rg?1.F:0.F,0};
            r[20]={d.scale[0],d.scale[1],d.bias[0],d.bias[1]};
        }
        r[16][3]=p.fogMode==UnlitTextureLayers::FogMode::Scene?1.F:0.F;
        r[15][3]=p.composite==UnlitTextureLayers::Composite::Additive?1.F:0.F;
        if(p.attenuateColorBlend)r[15][3]=2.F;
        r[19][3]=material.radianceScale;
        r[21][0]=static_cast<float>(material.displayTransform);
        return result;
    }
    if(material.nprDiffuse.present) {
        result.rows[0]={material.nprDiffuse.shadowScale,static_cast<float>(material.nprDiffuse.shadowMask),
            static_cast<float>(material.nprDiffuse.baseAo),
            static_cast<float>(material.nprDiffuse.indirectNormal)};
        result.rows[1][0]=static_cast<float>(material.nprDiffuse.rimResponse);
        result.rows[1][3]=static_cast<float>(material.nprDiffuse.rampComposition);
        result.rows[6][0]=material.nprDiffuse.shadowSaturation-1;
        result.rows[3][0]=static_cast<float>(material.nprDiffuse.characterVisibility);
        result.rows[3][1]=material.nprDiffuse.localDiffuseFloorScale;
        result.rows[3][2]=material.nprDiffuse.screenLightingNormal?2.F:material.nprDiffuse.radialLightingNormal?1.F:0.F;
        result.rows[3][3]=material.nprDiffuse.transparentHighlights?1.F:0.F;
        if(material.nprDiffuse.mainRamp.present) {
            result.rows[1][1]=1;
            result.rows[1][2]=material.nprDiffuse.mainRamp.bias;
        }
        if(material.nprDiffuse.viewTint.present) {
            const auto& tint=material.nprDiffuse.viewTint;
            result.rows[2]={tint.color[0],tint.color[1],tint.color[2],tint.scale};
        }
        if(material.nprDiffuse.lighting.present) {
            const auto& light=material.nprDiffuse.lighting;
            result.rows[10]={light.ambientColor[0],light.ambientColor[1],light.ambientColor[2],1};
            result.rows[11]={light.mainColor[0],light.mainColor[1],light.mainColor[2],0};
        }
    } else {
        result=material.eyeSurface.present?packEyeSurfaceProfile(material.eyeSurface)
            :packProjectedHairSurfaceProfile(material.projectedHairRamp);
    }
    if(material.materialClass==AssetMaterialClass::Generic||material.materialClass==AssetMaterialClass::Fabric
        ||material.materialClass==AssetMaterialClass::Metal) {
        result.rows[5][2]=static_cast<float>(material.specularInput.source);
        result.rows[5][3]=material.specularInput.scale;
        if(material.specularRamp.present) {
            const auto& ramp=material.specularRamp;
            result.rows[4]={0,0,ramp.iridescence,ramp.flipV?-1.F:1.F};
        }
    }
    result.rows[19][3]=material.radianceScale;
    result.rows[21][0]=static_cast<float>(material.displayTransform);
    const auto environmentFlags=materialEnvironmentFlags(material.environmentLighting);
    result.rows[21][1]=static_cast<float>(environmentFlags);
    result.rows[21][2]=environmentFlags?material.environmentLighting.globalIntensity.value_or(-1.F):0.F;
    result.rows[21][3]=static_cast<float>(material.mainLightShadow);
    return result;
}
}
