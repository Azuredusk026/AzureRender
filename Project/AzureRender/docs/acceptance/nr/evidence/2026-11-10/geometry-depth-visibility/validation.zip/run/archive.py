from pathlib import Path
import hashlib,json,re,zipfile
engine=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender');out=Path(__file__).parent;calibration=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda name:json.loads((out/name).read_text(encoding='utf-8'))
v=read('runs.json');cross=read('cross-results.json');assert len(v)==4 and len(cross)==2
for row in v:assert row['result']['validationErrors']==0 and row['result']['zeroAllocator'] and row['validationClean']
assert all(row['result']['withinOnePixels']==17017 for row in v if row['scope']=='control')
assert [row['result']['withinOnePixels'] for row in v if row['scope']=='geometry']==[17010,16914]
assert [row['result']['withinOnePixels'] for row in cross]==[17010,16914]
files={f'run/{p.name}':p for p in out.iterdir() if p.is_file() and p.suffix in {'.json','.py','.bin','.log'}}
config=read('nvidia-control.json');inputs={}
for name in ['depth','normals','atlas','queries','expected','profile']:
 p=Path(config[name]);inputs[name]={'bytes':p.stat().st_size,'sha256':sha(p),'sourcePath':str(p)}
 if name in ['queries','expected','profile']:files['reference/'+p.name]=p
for name in ['calibration.exe','calibration.cpp','screen_object_visibility.frag.spv','screen_object_visibility.vert.spv','source-inputs.json']:files['qualified-probe/'+name]=calibration/name
for name in ['src/render/ScreenObjectVisibility.cpp','src/render/ScreenObjectVisibility.hpp','shaders/screen_object_visibility.frag','shaders/float32_reference.glsl','tests/ScreenObjectVisibilityGpuTests.cpp','tests/support/VulkanComputeFixture.hpp']:files['source/'+name]=engine/name
doc=engine/'docs/acceptance/nr/geometry-depth-visibility.md';files['source/docs/acceptance/nr/geometry-depth-visibility.md']=doc
dest=engine/'docs/acceptance/nr/evidence/2026-11-10/geometry-depth-visibility';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
members={name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.writestr('manifest.json',json.dumps(members,ensure_ascii=False,indent=2))
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,value in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==value['sha256']
result={'status':'failed-native-geometry-depth-source-gate','overall':'failed-user-review','gate':{'maskPixels':17017,'maxByteError':1,'thresholdUnchanged':True},'sourceCommit':'e07934d','inputManifest':read('input-manifest.json'),'sharedInputs':inputs,'pairedRuns':v,'crossRuns':cross,'failureCorrelation':read('correlation.json'),'defaultRegression':read('default-regression-reuse.json'),'archive':{'members':len(members)+1,'bytes':archive.stat().st_size,'sha256':sha(archive)},'next':['Material coverage, culling and shell source','Device depth raster precision']}
(dest/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for link in re.findall(r'\]\(([^)]+)\)',doc.read_text(encoding='utf-8')):assert (doc.parent/link).exists(),link
print(json.dumps(result['archive']))
