from pathlib import Path
import subprocess,os,json,time,re
out=Path(__file__).parent.resolve();calibration=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7';main=Path('D:/Projects/FYP/Project/AzureRender');rows=[]
for consumer,producer in [('intel','nvidia'),('nvidia','intel')]:
 config=json.loads((out/(consumer+'-geometry.json')).read_text());config.update(depth=str(out/(producer+'-geometry-depth.bin')),scope='cross-'+producer);path=out/(consumer+'-cross-'+producer+'.json');path.write_text(json.dumps(config,indent=2)+'\n')
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if consumer=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(main/'build/ninja-msvc-release')+';'+env['PATH'])
 label=consumer+'-cross-'+producer;command=[str(calibration/'calibration.exe'),str(path),str(calibration)];start=time.monotonic()
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
 text=(out/(label+'.log')).read_text(errors='replace');result=json.loads((out/(label+'-result.json')).read_text());assert result['validationErrors']==0 and result['zeroAllocator'] and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I)
 rows.append({'consumer':consumer,'producer':producer,'exitCode':r.returncode,'seconds':time.monotonic()-start,'result':result});print(label,result['exactPixels'],result['withinOnePixels'],result['maximumByteError'],flush=True)
(out/'cross-results.json').write_text(json.dumps(rows,indent=2)+'\n')
