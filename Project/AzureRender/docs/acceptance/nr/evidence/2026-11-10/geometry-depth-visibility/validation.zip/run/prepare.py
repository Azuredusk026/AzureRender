from pathlib import Path
import sys,json,hashlib,zlib,numpy as np
out=Path(__file__).resolve().parent;root=out.parents[2];main=Path('D:/Projects/FYP/Project/AzureRender');runs=root/'build/runs';owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0,str(main/'tools'));import shared_resources as s
local=s.acquire_inputs(root/'build',out,['20261110-165124-reference-depth-source-4d1d7d','20261110-003435-visibility-numeric-contract-4f95e7','20261110-003031-reciprocal-compact-profile-4e7929'],owner)
external=s.acquire_inputs(s.DEFAULT_BUILD,out,['20261027-022702-object-visibility-depth-reconstruction-c7312f','20261108-045252-screen-object-visibility-ca2907'],owner)
p=Path('D:/Projects/FYP-coordination/quality-claim.json');v=json.loads(p.read_text(encoding='utf-8'));v.update(state='geometry-depth-visibility-source-check',taskPath=str(out),lastCommit='e07934d',inputLease=[external],localInputLease=[local],pendingCommand='paired-native-depth-visibility',ownedFiles=['docs/acceptance/nr/geometry-depth-visibility.md']);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
calibration=runs/'20261110-003435-visibility-numeric-contract-4f95e7';source=runs/'20261110-165124-reference-depth-source-4d1d7d';frozen=json.loads((calibration/'source-inputs.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
critical=['src/render/ScreenObjectVisibility.cpp','src/render/ScreenObjectVisibility.hpp','shaders/screen_object_visibility.frag','shaders/float32_reference.glsl']
assert all(sha(root/name)==frozen[name] for name in critical)
manifest={'visibilitySource':{name:frozen[name] for name in critical},'calibrationExecutableSha256':sha(calibration/'calibration.exe'),'producerCommit':'e07934d','producerScope':'Initial flipNdcY=true actual R32 output; direct native texture rows, no image edits','files':{}}
for device in ['nvidia','intel']:
 packed=source/f'initial-release-{device}-depth.zlib';raw=zlib.decompress(packed.read_bytes());assert len(raw)==2560*1440*8
 producer=out/(device+'-geometry-depth.bin');producer.write_bytes(raw[:2560*1440*4]);manifest['files'][producer.name]={'bytes':producer.stat().st_size,'sha256':sha(producer),'sourceCompressedSha256':sha(packed),'sourceFullSha256':hashlib.sha256(raw).hexdigest()}
 for scope in ['control','geometry']:
  config=json.loads((calibration/'hair-calibration.json').read_text());config['scope']=scope
  if scope=='geometry':config['depth']=str(producer)
  (out/(device+'-'+scope+'.json')).write_text(json.dumps(config,indent=2)+'\n')
queries=np.fromfile(main/'build/runs/20261108-045252-screen-object-visibility-ca2907/queries.bin',dtype='<f4').reshape(-1,4)
coords=np.fromfile(source/'native-mask-coordinates.bin',dtype='<u4').reshape(-1,2);assert np.array_equal(queries[:,:2].astype('<u4'),np.column_stack([coords[:,0],1439-coords[:,1]]))
manifest['coordinateIdentity']='All17017 query x/y equal source-mask x/(1439-y); producer directly supplies those texture rows'
(out/'input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'task-card.json').write_text(json.dumps({'baseCommit':'e07934d','delivery':'Actual geometry-produced depth effect on public visibility, frozen original17017mask','hypothesis':'Depth differences may preserve visibility within original one-byte gate; actual RG8 decides','changedFactor':'Only borrowed R32 depth image contents','budgetBytes':67108864,'gpuSeconds':240,'explorationSeconds':1800,'criteria':['Same executable, shader, normals, atlas, inverse, reciprocal profile and original expected bytes','Both devices: baseline17017 all<=1byte','Candidate17017 all<=1byte; report all failures without threshold change','Vulkan validation and allocator zero','No production source mutation']},indent=2)+'\n')
print('Direct native-row producer inputs and unchanged public visibility source verified')
