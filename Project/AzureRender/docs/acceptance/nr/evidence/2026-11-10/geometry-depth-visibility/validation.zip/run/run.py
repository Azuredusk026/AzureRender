from pathlib import Path
import subprocess,os,json,re,time
out=Path(__file__).resolve().parent;calibration=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7';main=Path('D:/Projects/FYP/Project/AzureRender');rows=[]
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(main/'build/ninja-msvc-release')+';'+env['PATH'])
 for scope in ['control','geometry']:
  command=[str(calibration/'calibration.exe'),str(out/(device+'-'+scope+'.json')),str(calibration)];label=device+'-'+scope;start=time.monotonic()
  with (out/(label+'.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
  text=(out/(label+'.log')).read_text(errors='replace');result=json.loads((out/(label+'-result.json')).read_text());row={'device':device,'scope':scope,'command':command,'exitCode':r.returncode,'seconds':time.monotonic()-start,'validationClean':not bool(re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I)),'result':result};rows.append(row);(out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,json.dumps(result),flush=True)
  assert result['pixels']==17017 and result['validationErrors']==0 and result['zeroAllocator'] and row['validationClean']
  if scope=='control':assert r.returncode==0 and result['withinOnePixels']==17017
print('Paired source diagnostic complete; original threshold retained')
