#include "render/ReferenceFmaShader.hpp"
#include <fstream>
#include <iterator>
#include <iostream>
int main(int argc,char** argv){if(argc!=3)return 2;std::ifstream in(argv[1],std::ios::binary);std::vector<char> source{std::istreambuf_iterator<char>(in),std::istreambuf_iterator<char>()};auto result=azurerender::prepareReferenceFmaShader(source);auto again=azurerender::prepareReferenceFmaShader(result.code);if(result.fusedResults!=3||again.code!=result.code)return 1;std::ofstream(argv[2],std::ios::binary).write(result.code.data(),result.code.size());std::cout<<result.fusedResults<<" Fma results explicit and idempotent\n";}