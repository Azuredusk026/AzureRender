cmake_minimum_required(VERSION 3.20)

list(PREPEND VCPKG_OVERLAY_PORTS "${CMAKE_CURRENT_SOURCE_DIR}/cmake/vcpkg-overlays")

project(
    AzureRender
    VERSION 0.1.0
    DESCRIPTION "Portfolio-first Vulkan stylized renderer"
    LANGUAGES C CXX
)

include(CTest)
file(MAKE_DIRECTORY "${CMAKE_BINARY_DIR}/.cmake/api/v1/query")
file(WRITE "${CMAKE_BINARY_DIR}/.cmake/api/v1/query/codemodel-v2" "")
include(GNUInstallDirs)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

# MSVC does not enable C++ unwind semantics by default. Without /EHsc every
# try/catch in the codebase and in the test executables is inert, so a thrown
# exception terminates the process instead of being caught. This must apply to
# all targets, not just the renderer, because the tests assert on error paths.
if(MSVC)
    add_compile_options(/EHsc /utf-8)
endif()

# Ninja tracks header dependencies on MSVC by matching the /showIncludes
# prefix recorded at compiler-detection time against the compiler's actual
# output bytes. On a localized toolchain the recorded prefix can diverge from
# reality (wrong code page during the probe), and then every header edit
# silently fails to trigger a rebuild; stale objects crash against new struct
# layouts at runtime. Probe the compiler here and compare byte-exactly so the
# misconfiguration is loud instead of corrupting objects.
if(MSVC AND CMAKE_GENERATOR MATCHES "Ninja")
    set(_azr_probe_dir
        "${CMAKE_BINARY_DIR}/CMakeFiles/AzureRenderShowIncludesProbe")
    file(WRITE "${_azr_probe_dir}/foo.h" "\n")
    file(WRITE "${_azr_probe_dir}/main.c" "#include \"foo.h\"\n")
    execute_process(
        COMMAND "${CMAKE_CXX_COMPILER}" /nologo /showIncludes /c main.c
        WORKING_DIRECTORY "${_azr_probe_dir}"
        OUTPUT_VARIABLE _azr_probe_out
        ERROR_VARIABLE _azr_probe_out
        RESULT_VARIABLE _azr_probe_result
        ENCODING NONE
    )
    string(FIND "${_azr_probe_out}" "foo.h" _azr_probe_has_include)
    string(FIND
        "${_azr_probe_out}"
        "${CMAKE_CXX_CL_SHOWINCLUDES_PREFIX}"
        _azr_prefix_pos)
    if(_azr_probe_result EQUAL 0 AND _azr_probe_has_include GREATER_EQUAL 0
       AND ("${CMAKE_CXX_CL_SHOWINCLUDES_PREFIX}" STREQUAL ""
            OR _azr_prefix_pos LESS 0))
        message(
            WARNING
            "Ninja header-dependency tracking is broken in this build tree: "
            "the recorded /showIncludes prefix does not match the compiler's "
            "output. Run 'python tools/fix_msvc_deps_prefix.py "
            "${CMAKE_BINARY_DIR}' and configure again, or expect stale "
            "objects after header edits.")
    endif()
    unset(_azr_probe_dir)
    unset(_azr_probe_out)
    unset(_azr_probe_result)
    unset(_azr_probe_has_include)
    unset(_azr_prefix_pos)
endif()

find_package(assimp 6.0.4 EXACT CONFIG REQUIRED)
find_package(TIFF REQUIRED)
find_package(pugixml CONFIG REQUIRED)
if(MSVC)
    set_source_files_properties(src/assets/image/SvgCodec.cpp PROPERTIES COMPILE_OPTIONS "/wd4702")
endif()
find_package(WebP CONFIG REQUIRED)
find_package(FLAC CONFIG REQUIRED)
find_package(Vorbis CONFIG REQUIRED)
find_package(mp3lame CONFIG REQUIRED)
find_package(Opus CONFIG REQUIRED)
find_package(OpusFile CONFIG REQUIRED)
find_package(ZLIB REQUIRED)
find_package(zstd CONFIG REQUIRED)
find_package(Jolt CONFIG REQUIRED)
find_package(manifold 3.5.2 EXACT CONFIG REQUIRED)
find_package(sol2 CONFIG REQUIRED)
find_package(Lua 5.4 EXACT REQUIRED)
find_package(Python3 COMPONENTS Interpreter REQUIRED)
add_custom_target(AzureEngineContracts ALL
    COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/write_engine_contracts.py"
        --source "${CMAKE_CURRENT_SOURCE_DIR}"
        --manifest "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/engine-evolution-manifest.json"
        --output "${CMAKE_CURRENT_BINARY_DIR}/contracts"
    COMMENT "Generating verified engine interface snapshots and schemas"
    VERBATIM)
if(BUILD_TESTING)
    add_test(NAME AzureTools.EvolutionCoverage COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_evolution_coverage.py")
    add_test(NAME AzureTools.EngineContracts COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_engine_contracts.py")
    add_test(NAME AzureEngine.ContractsSnapshot COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/write_engine_contracts.py"
        --verify --output "${CMAKE_CURRENT_BINARY_DIR}/contracts")
    add_test(NAME AzureEngine.EvolutionCoverage COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/verify_evolution_coverage.py"
        --manifest "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/engine-evolution-manifest.json"
        --evidence "${CMAKE_CURRENT_BINARY_DIR}/evolution-coverage"
        --build-dir "${CMAKE_CURRENT_BINARY_DIR}" --configuration "$<CONFIG>"
        --historical-policy committed-content)
    set_tests_properties(AzureEngine.EvolutionCoverage PROPERTIES RUN_SERIAL TRUE TIMEOUT 300)
endif()
find_package(RmlUi CONFIG REQUIRED)
find_path(MINIAUDIO_INCLUDE_DIR miniaudio.h REQUIRED)
find_package(Vulkan REQUIRED COMPONENTS glslc)
find_program(AZURE_SPIRV_VAL_EXECUTABLE NAMES spirv-val spirv-val.exe
    HINTS "$ENV{VULKAN_SDK}/Bin" "${Vulkan_INCLUDE_DIR}/../Bin" REQUIRED)
find_package(directxtex CONFIG REQUIRED)
find_package(Ktx CONFIG REQUIRED)
find_package(glfw3 CONFIG REQUIRED)
find_package(nlohmann_json CONFIG REQUIRED)
find_package(OpenEXR CONFIG REQUIRED)
find_package(VulkanMemoryAllocator CONFIG REQUIRED)

# Dear ImGui integration.
#
# Windows MinGW builds cannot link the vcpkg `x64-windows` (MSVC) imgui static
# library because the C++ name mangling schemes are incompatible. The project
# therefore compiles the vendored imgui sources under `third_party/imgui` so the
# library always uses the same ABI as the project compiler. When the vendored
# sources are absent, the vcpkg imgui package is used as a fallback.
if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui/imgui.cpp")
    add_library(azure_imgui STATIC
        third_party/imgui/imgui.cpp
        third_party/imgui/imgui_draw.cpp
        third_party/imgui/imgui_tables.cpp
        third_party/imgui/imgui_widgets.cpp
        third_party/imgui/backends/imgui_impl_glfw.cpp
        third_party/imgui/backends/imgui_impl_vulkan.cpp
    )
    target_include_directories(
        azure_imgui
        PUBLIC
            "${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui"
            "${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui/backends"
    )
    target_compile_features(azure_imgui PUBLIC cxx_std_17)
    target_compile_definitions(azure_imgui PUBLIC GLFW_INCLUDE_VULKAN IMGUI_USE_WCHAR32)
    target_link_libraries(azure_imgui PUBLIC Vulkan::Vulkan glfw)
    add_library(imgui::imgui ALIAS azure_imgui)
else()
    find_package(imgui CONFIG QUIET)
    if(NOT TARGET imgui::imgui)
        find_path(IMGUI_INCLUDE_DIR imgui.h PATH_SUFFIXES imgui)
        find_library(IMGUI_LIBRARY NAMES imgui)
        if(IMGUI_INCLUDE_DIR AND IMGUI_LIBRARY)
            add_library(imgui::imgui UNKNOWN IMPORTED)
            find_library(IMGUI_STB_LIBRARY NAMES stb)
            set_target_properties(
                imgui::imgui
                PROPERTIES
                    IMPORTED_LOCATION "${IMGUI_LIBRARY}"
                    INTERFACE_INCLUDE_DIRECTORIES "${IMGUI_INCLUDE_DIR}"
            )
            if(IMGUI_STB_LIBRARY)
                set_property(
                    TARGET imgui::imgui APPEND PROPERTY
                    INTERFACE_LINK_LIBRARIES "${IMGUI_STB_LIBRARY}")
            endif()
        endif()
    endif()
endif()
find_path(TINYGLTF_INCLUDE_DIR tiny_gltf.h REQUIRED)
find_path(STB_INCLUDE_DIR stb_easy_font.h PATH_SUFFIXES stb REQUIRED)

set(SHADER_SOURCE_DIR "${CMAKE_CURRENT_SOURCE_DIR}/shaders")
set(SHADER_BINARY_DIR "${CMAKE_CURRENT_BINARY_DIR}/shaders")
option(AZURE_ENABLE_BATCHED_SHADOW_BOUNDS "Enable eight-tile shadow workgroups" ON)
set_property(SOURCE src/scenes/CharacterSceneRenderer.cpp APPEND PROPERTY COMPILE_DEFINITIONS "$<$<BOOL:${AZURE_ENABLE_BATCHED_SHADOW_BOUNDS}>:AZURE_BATCHED_SHADOW_BOUNDS=1>")
option(AZURE_ENABLE_SURFACE_RADIANCE_REUSE "Enable experimental same-frame surface-radiance reuse" OFF)
option(AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS "Enable intrusive radiance consumption counters" OFF)
option(AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION "Enable experimental validated radiance consumer selection" OFF)
if(AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION AND NOT AZURE_ENABLE_SURFACE_RADIANCE_REUSE)
    message(FATAL_ERROR "Radiance frame selection requires AZURE_ENABLE_SURFACE_RADIANCE_REUSE")
endif()
if(AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS AND NOT AZURE_ENABLE_SURFACE_RADIANCE_REUSE)
    message(FATAL_ERROR "Radiance diagnostics require AZURE_ENABLE_SURFACE_RADIANCE_REUSE")
endif()
set_property(SOURCE src/scenes/CharacterSceneRenderer.cpp src/app/AzureRenderApp.cpp APPEND PROPERTY
    COMPILE_DEFINITIONS "$<$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_REUSE}>:AZURE_SURFACE_RADIANCE_PROGRAMS=1>"
    "$<$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS}>:AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1>"
    "$<$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION}>:AZURE_SURFACE_RADIANCE_FRAME_SELECTION=1>")
option(AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION "Enable experimental default-isolation material specialization" OFF)

function(compile_shader source_file)
    get_filename_component(shader_name "${source_file}" NAME)
    set(oneValueArgs OUTPUT_NAME)
    set(multiValueArgs DEFINES)
    cmake_parse_arguments(SHADER "" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    if(SHADER_OUTPUT_NAME)
        set(shader_name "${SHADER_OUTPUT_NAME}")
    endif()
    set(shader_output "${SHADER_BINARY_DIR}/${shader_name}.spv")
    set(shader_dependency_directory "${CMAKE_CURRENT_BINARY_DIR}/CMakeFiles/shader-deps")
    set(shader_depfile "${shader_dependency_directory}/${shader_name}.d")
    set(shader_define_args)
    set(shader_lut_dependency)
    get_filename_component(shader_source_base "${source_file}" NAME)
    if(shader_source_base STREQUAL "view_fog_surface.frag" OR "AZURE_VIEW_FOG=1" IN_LIST SHADER_DEFINES)
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/view_fog.glsl" "${SHADER_SOURCE_DIR}/view_fog_material.glsl" "${SHADER_SOURCE_DIR}/fog_transport.glsl" "${SHADER_SOURCE_DIR}/fog_view_projection.glsl" "${SHADER_SOURCE_DIR}/fog_analytic.glsl")
    endif()
    if(shader_source_base STREQUAL "mesh.frag")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/unlit_surface_sample.glsl" "${SHADER_SOURCE_DIR}/unlit_opaque.glsl" "${SHADER_SOURCE_DIR}/unlit_blend.glsl" "${SHADER_SOURCE_DIR}/surface_radiance.glsl" "${SHADER_SOURCE_DIR}/surface_radiance_identity.glsl" "${SHADER_SOURCE_DIR}/surface_radiance_statistics.glsl")
    endif()
    if(shader_source_base STREQUAL "surface_radiance_probe.frag" OR shader_source_base STREQUAL "surface_radiance_validation.frag")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/surface_radiance_identity.glsl" "${SHADER_SOURCE_DIR}/surface_radiance_statistics.glsl" "${SHADER_SOURCE_DIR}/beauty_composition.glsl")
    endif()
    if(shader_source_base STREQUAL "mesh.frag" OR shader_source_base STREQUAL "beauty_composition_test.comp")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/beauty_composition.glsl")
    endif()
    if(shader_source_base STREQUAL "shadow.frag" OR shader_source_base STREQUAL "surface_response_test.comp")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/shadow_coverage.glsl")
    endif()
    if(shader_source_base STREQUAL "outline.vert" OR shader_source_base STREQUAL "surface_response_test.comp")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/outline_projection.glsl")
    endif()
    if(shader_source_base STREQUAL "outline.vert")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/outline_projection_data.glsl" "${SHADER_SOURCE_DIR}/outline_view_scaled.glsl")
    endif()
    if(shader_source_base STREQUAL "motion_projection_test.comp")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/motion_projection.glsl")
    endif()
    if(shader_source_base STREQUAL "motion_vector.vert" OR shader_source_base STREQUAL "motion_outline.vert" OR shader_source_base STREQUAL "motion_vector.frag")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/motion_vector_vertex.glsl" "${SHADER_SOURCE_DIR}/motion_vector_push.glsl" "${SHADER_SOURCE_DIR}/motion_pose_data.glsl" "${SHADER_SOURCE_DIR}/motion_projection.glsl" "${SHADER_SOURCE_DIR}/outline_projection.glsl" "${SHADER_SOURCE_DIR}/morph_data.glsl" "${SHADER_SOURCE_DIR}/instance_data.glsl" "${SHADER_SOURCE_DIR}/node_opacity.glsl")
    endif()
    if(shader_source_base STREQUAL "motion_pose_test.comp")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/motion_pose_data.glsl" "${SHADER_SOURCE_DIR}/motion_projection.glsl" "${SHADER_SOURCE_DIR}/outline_projection.glsl")
    endif()
    if(shader_source_base STREQUAL "outline.frag" OR shader_source_base STREQUAL "outline_depth.frag")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/outline_surface_fragment.glsl" "${SHADER_SOURCE_DIR}/node_opacity.glsl")
    endif()
    if(shader_source_base STREQUAL "mesh.vert" OR shader_source_base STREQUAL "shadow.vert"
        OR shader_source_base STREQUAL "outline.vert" OR shader_source_base STREQUAL "scene_instance_layout_test.comp")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/instance_data.glsl")
    endif()
    if(shader_source_base STREQUAL "inner_outline.frag" OR shader_source_base STREQUAL "view_resolve.frag" OR shader_source_base STREQUAL "color_grading_lut_test.comp" OR shader_source_base STREQUAL "spatial_antialiasing.frag")
        set(shader_lut_dependency "${SHADER_SOURCE_DIR}/color_grading_lut.glsl")
    endif()
    if(shader_source_base STREQUAL "spatial_antialiasing.frag")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/spatial_antialiasing.glsl")
    endif()
    if(shader_source_base STREQUAL "mesh.frag" OR shader_source_base STREQUAL "shadow.frag" OR shader_source_base STREQUAL "character_depth.frag" OR shader_source_base STREQUAL "outline.frag")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/node_opacity.glsl")
    endif()
    if(shader_source_base STREQUAL "mesh.frag")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/screen_space_reflection.glsl")
    endif()
    if(shader_source_base STREQUAL "mesh.frag" OR shader_source_base STREQUAL "motion_vector.frag"
        OR shader_source_base STREQUAL "motion_vector.vert" OR shader_source_base STREQUAL "motion_outline.vert"
        OR shader_source_base STREQUAL "character_depth.frag")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/material_sampling.glsl")
    endif()
    if(shader_source_base MATCHES "^(mesh|shadow|outline|motion_vector|motion_outline)\\.vert$"
        OR shader_source_base STREQUAL "skin.comp" OR shader_source_base STREQUAL "motion_pose_test.comp")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/skin_position.glsl")
    endif()
    list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/character_diffuse.glsl")
    if(shader_source_base STREQUAL "mesh.frag" OR shader_source_base STREQUAL "specular_ramp_test.comp")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/specular_ramp.glsl")
    endif()
    if(shader_source_base STREQUAL "mesh.frag" OR shader_source_base STREQUAL "outline.frag" OR shader_source_base STREQUAL "outline_depth.frag" OR shader_source_base STREQUAL "background.frag" OR shader_source_base STREQUAL "outline_mask.frag" OR shader_source_base STREQUAL "character_depth.frag")
        list(APPEND shader_lut_dependency "${SHADER_SOURCE_DIR}/fragment_sampling.glsl")
    endif()
    foreach(shader_define IN LISTS SHADER_DEFINES)
        list(APPEND shader_define_args "-D${shader_define}")
    endforeach()
    set(shader_arguments_json "")
    if("AZURE_SURFACE_RADIANCE_REUSE=1" IN_LIST SHADER_DEFINES OR "AZURE_SURFACE_RADIANCE_CONSUMER=1" IN_LIST SHADER_DEFINES OR "AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1" IN_LIST SHADER_DEFINES)
        list(APPEND shader_define_args "--target-env=vulkan1.3")
        set(shader_arguments_json "\"--target-env=vulkan1.3\"")
    elseif("AZURE_FRAGMENT_QUAD_OPERATIONS=1" IN_LIST SHADER_DEFINES)
        list(APPEND shader_define_args "--target-env=vulkan1.1")
        set(shader_arguments_json "\"--target-env=vulkan1.1\"")
    endif()

    add_custom_command(
        OUTPUT "${shader_output}"
        COMMAND "${CMAKE_COMMAND}" -E make_directory "${SHADER_BINARY_DIR}" "${shader_dependency_directory}"
        COMMAND Vulkan::glslc ${shader_define_args} -MD -MF "${shader_depfile}" "${source_file}" -o "${shader_output}"
        COMMAND "${AZURE_SPIRV_VAL_EXECUTABLE}" --target-env vulkan1.3 --relax-block-layout "${shader_output}"
        DEPFILE "${shader_depfile}"
        DEPENDS "${AZURE_SPIRV_VAL_EXECUTABLE}" "${source_file}" ${shader_lut_dependency} "${SHADER_SOURCE_DIR}/morph_data.glsl" "${SHADER_SOURCE_DIR}/shadow_compare.glsl" "${SHADER_SOURCE_DIR}/surface_response.glsl" "${SHADER_SOURCE_DIR}/environment_specular.glsl" "${SHADER_SOURCE_DIR}/light_attenuation.glsl" "${SHADER_SOURCE_DIR}/character_surface.glsl" "${SHADER_SOURCE_DIR}/sky.glsl" "${SHADER_SOURCE_DIR}/pathtracing/bsdf.glsl" "${SHADER_SOURCE_DIR}/pathtracing/lighting.glsl"
        COMMENT "Compiling ${shader_name}"
        VERBATIM
    )

    set(COMPILED_SHADERS ${COMPILED_SHADERS} "${shader_output}" PARENT_SCOPE)
    set(shader_defines_json "")
    foreach(shader_define IN LISTS SHADER_DEFINES)
        if(shader_defines_json)
            string(APPEND shader_defines_json ",")
        endif()
        string(APPEND shader_defines_json "\"${shader_define}\"")
    endforeach()
    get_filename_component(shader_source_name "${source_file}" NAME)
    set_property(GLOBAL APPEND PROPERTY AZURE_SHADER_DESCRIPTORS
        "{\"source\":\"${shader_source_name}\",\"output\":\"${shader_name}.spv\",\"defines\":[${shader_defines_json}],\"arguments\":[${shader_arguments_json}]}")
endfunction()

compile_shader("${SHADER_SOURCE_DIR}/editor_ui.frag")
if(AZURE_ENABLE_SURFACE_RADIANCE_REUSE)
if(AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION)
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_validation.frag")
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_selection_commit.comp")
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_selection_commit.comp" DEFINES AZURE_SURFACE_RADIANCE_DRAW_SELECTION=1 OUTPUT_NAME surface_radiance_draw_commit.comp)
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.frag" DEFINES AZURE_SURFACE_RADIANCE_CONSUMER=1 AZURE_SURFACE_RADIANCE_FAST_PROBE=1 OUTPUT_NAME surface_radiance_fast_probe.frag)
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_depth_copy.vert")
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_depth_copy.frag")
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_validation.frag" DEFINES AZURE_SURFACE_RADIANCE_PROBE=1 OUTPUT_NAME surface_radiance_validation_probe.frag)
endif()
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.vert")
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.frag")
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.frag" DEFINES AZURE_SURFACE_RADIANCE_CONSUMER=1 OUTPUT_NAME surface_radiance_consumer.frag)
if(AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS)
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.frag" DEFINES AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1 OUTPUT_NAME surface_radiance_probe_stats.frag)
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.frag" DEFINES AZURE_SURFACE_RADIANCE_CONSUMER=1 AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1 OUTPUT_NAME surface_radiance_consumer_stats.frag)
if(AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION)
compile_shader("${SHADER_SOURCE_DIR}/surface_radiance_probe.frag" DEFINES AZURE_SURFACE_RADIANCE_CONSUMER=1 AZURE_SURFACE_RADIANCE_FAST_PROBE=1 AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1 AZURE_SURFACE_RADIANCE_SPARSE_DIAGNOSTICS=1 AZURE_SURFACE_RADIANCE_CAPTURE_FAILURES=1 OUTPUT_NAME surface_radiance_capture_probe.frag)
endif()
endif()
endif()
compile_shader("${SHADER_SOURCE_DIR}/editor_ui.frag" DEFINES AZURE_EDITOR_SRGB=1 OUTPUT_NAME editor_ui_srgb.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.vert")
compile_shader("${SHADER_SOURCE_DIR}/cull_indirect.comp")
compile_shader("${SHADER_SOURCE_DIR}/cull_indirect.comp"
    DEFINES AZURE_SURFACE_IDENTITIES=1 OUTPUT_NAME visibility_prototype.comp)
compile_shader(
    "${SHADER_SOURCE_DIR}/mesh.vert"
    DEFINES AZURE_COMPUTE_SKINNING=1
    OUTPUT_NAME mesh_compute.vert)
compile_shader("${SHADER_SOURCE_DIR}/mesh.vert" DEFINES AZURE_SNAPSHOT_DEPTH=1 OUTPUT_NAME character_snapshot_depth.vert)
compile_shader("${SHADER_SOURCE_DIR}/mesh.vert" DEFINES AZURE_SNAPSHOT_DEPTH=1 AZURE_COMPUTE_SKINNING=1 OUTPUT_NAME character_snapshot_depth_compute.vert)
compile_shader("${SHADER_SOURCE_DIR}/character_depth.frag")
compile_shader("${SHADER_SOURCE_DIR}/character_depth.frag" DEFINES AZURE_SNAPSHOT_DEPTH=1 OUTPUT_NAME character_snapshot_depth.frag)
compile_shader("${SHADER_SOURCE_DIR}/character_depth.frag" DEFINES AZURE_SNAPSHOT_DEPTH=1 AZURE_BINDLESS=1 OUTPUT_NAME character_snapshot_depth_bindless.frag)
compile_shader("${SHADER_SOURCE_DIR}/character_depth.frag" DEFINES AZURE_SNAPSHOT_DEPTH=1 AZURE_GEOMETRY_SAMPLES=1 OUTPUT_NAME character_snapshot_depth_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/character_depth.frag" DEFINES AZURE_SNAPSHOT_DEPTH=1 AZURE_GEOMETRY_SAMPLES=1 AZURE_BINDLESS=1 OUTPUT_NAME character_snapshot_depth_bindless_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/shadow_filter_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/object_shadow_filter_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/shadow_history_clear.comp")
compile_shader("${SHADER_SOURCE_DIR}/shadow_history_ownership_test.vert")
compile_shader("${SHADER_SOURCE_DIR}/shadow_history_ownership_test.frag")
compile_shader("${SHADER_SOURCE_DIR}/screen_object_visibility.vert")
compile_shader("${SHADER_SOURCE_DIR}/screen_object_visibility.frag")
compile_shader("${SHADER_SOURCE_DIR}/shadow_bounds.comp")
if(AZURE_ENABLE_BATCHED_SHADOW_BOUNDS)
compile_shader("${SHADER_SOURCE_DIR}/shadow_bounds.comp" DEFINES AZURE_SHADOW_BOUNDS_BATCH=1 OUTPUT_NAME shadow_bounds_batch.comp)
endif()
compile_shader("${SHADER_SOURCE_DIR}/stable_key_sort.comp")
compile_shader("${SHADER_SOURCE_DIR}/conservative_occlusion.comp")
compile_shader("${SHADER_SOURCE_DIR}/predicate_draw_selection.comp")
compile_shader("${SHADER_SOURCE_DIR}/depth_prepass_test.vert")
compile_shader("${SHADER_SOURCE_DIR}/depth_prepass_test.frag")
compile_shader("${SHADER_SOURCE_DIR}/transparent_deform.comp")
compile_shader("${SHADER_SOURCE_DIR}/transparent_depth_keys.comp")
compile_shader("${SHADER_SOURCE_DIR}/transparent_index_scatter.comp")
compile_shader("${SHADER_SOURCE_DIR}/surface_response_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/material_output_precision_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/reference_clip_projection_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/material_uv_gradients_test.vert")
compile_shader("${SHADER_SOURCE_DIR}/material_uv_gradients_test.frag" DEFINES AZURE_FRAGMENT_QUAD_OPERATIONS=1)
compile_shader("${SHADER_SOURCE_DIR}/motion_projection_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/motion_pose_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/motion_vector.vert")
compile_shader("${SHADER_SOURCE_DIR}/motion_outline.vert")
compile_shader("${SHADER_SOURCE_DIR}/motion_vector.frag")
compile_shader("${SHADER_SOURCE_DIR}/temporal_copy.frag")
compile_shader("${SHADER_SOURCE_DIR}/temporal_resolve.frag")
compile_shader("${SHADER_SOURCE_DIR}/temporal_resolve.frag" DEFINES AZURE_TEMPORAL_DISPLAY_MASK=1 OUTPUT_NAME temporal_display_resolve.frag)
compile_shader("${SHADER_SOURCE_DIR}/readonly_depth_test.vert")
compile_shader("${SHADER_SOURCE_DIR}/readonly_depth_test.frag")
compile_shader("${SHADER_SOURCE_DIR}/specialization_test.vert")
compile_shader("${SHADER_SOURCE_DIR}/specialization_test.frag")
compile_shader("${SHADER_SOURCE_DIR}/specialization_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/beauty_composition_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/irradiance_clipmap_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/octahedral_environment_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/reflection_probe_field_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/reflection_spatial_filter.comp")
compile_shader("${SHADER_SOURCE_DIR}/reflection_signal_pyramid.comp" DEFINES AZURE_REFLECTION_PACKED=1 OUTPUT_NAME reflection_signal_pyramid_packed.comp)
compile_shader("${SHADER_SOURCE_DIR}/reflection_signal_pyramid.comp" OUTPUT_NAME reflection_signal_pyramid_float.comp)
compile_shader("${SHADER_SOURCE_DIR}/reflection_surface_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/depth_pyramid.comp")
compile_shader("${SHADER_SOURCE_DIR}/reflection_reprojection.comp")
compile_shader("${SHADER_SOURCE_DIR}/projected_reflection_prepare.comp")
compile_shader("${SHADER_SOURCE_DIR}/reflection_trace.comp" DEFINES AZURE_REFLECTION_PACKED=1 OUTPUT_NAME reflection_trace_packed.comp)
compile_shader("${SHADER_SOURCE_DIR}/reflection_trace.comp" OUTPUT_NAME reflection_trace_float.comp)
compile_shader("${SHADER_SOURCE_DIR}/reflection_temporal.comp" DEFINES AZURE_REFLECTION_PACKED=1 OUTPUT_NAME reflection_temporal_packed.comp)
compile_shader("${SHADER_SOURCE_DIR}/reflection_temporal.comp" OUTPUT_NAME reflection_temporal_float.comp)
compile_shader("${SHADER_SOURCE_DIR}/depth_bias_test.frag")
compile_shader("${SHADER_SOURCE_DIR}/scene_instance_layout_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/color_grading_lut_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/character_depth.frag" DEFINES AZURE_BINDLESS=1 OUTPUT_NAME character_depth_bindless.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_OPAQUE_SNAPSHOT=1 OUTPUT_NAME character_snapshot.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_OPAQUE_SNAPSHOT=1 AZURE_BINDLESS=1 OUTPUT_NAME character_snapshot_bindless.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1 OUTPUT_NAME mesh_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1 AZURE_BINDLESS=1 OUTPUT_NAME mesh_bindless_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1 AZURE_OBJECT_SHADOW=1 OUTPUT_NAME mesh_object_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1 AZURE_OBJECT_SHADOW=1 AZURE_BINDLESS=1 OUTPUT_NAME mesh_object_bindless_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/outline.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1  OUTPUT_NAME outline_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/outline.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1 AZURE_VIEW_SCALED_OUTLINE=1 OUTPUT_NAME outline_view_scaled_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/outline.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1 AZURE_VIEW_SCALED_OUTLINE=1 AZURE_BINDLESS=1 OUTPUT_NAME outline_view_scaled_bindless_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/background.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1  OUTPUT_NAME background_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/background.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1 AZURE_BINDLESS=1 OUTPUT_NAME background_bindless_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag")
compile_shader("${SHADER_SOURCE_DIR}/view_fog_surface.frag")
compile_shader("${SHADER_SOURCE_DIR}/view_fog_surface.frag" DEFINES AZURE_FOG_SAMPLES=1 OUTPUT_NAME view_fog_surface_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_VIEW_FOG=1 OUTPUT_NAME mesh_fog.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_VIEW_FOG=1 AZURE_BINDLESS=1 OUTPUT_NAME mesh_fog_bindless.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_VIEW_FOG=1 AZURE_GEOMETRY_SAMPLES=1 OUTPUT_NAME mesh_fog_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_VIEW_FOG=1 AZURE_BINDLESS=1 AZURE_GEOMETRY_SAMPLES=1 OUTPUT_NAME mesh_fog_bindless_samples.frag)
foreach(_projection_base IN ITEMS mesh mesh_object character_snapshot_depth)
    foreach(_projection_indexed IN ITEMS FALSE TRUE)
        foreach(_projection_compute IN ITEMS FALSE TRUE)
            set(_projection_name "${_projection_base}_projected")
            set(_projection_defines AZURE_PROJECTED_SURFACE=1)
            if(_projection_base STREQUAL "mesh_object")
                list(APPEND _projection_defines AZURE_OBJECT_SHADOW=1)
            elseif(_projection_base STREQUAL "character_snapshot_depth")
                list(APPEND _projection_defines AZURE_SNAPSHOT_DEPTH=1)
            endif()
            if(_projection_indexed)
                string(APPEND _projection_name "_bindless")
                list(APPEND _projection_defines AZURE_BINDLESS=1)
            endif()
            if(_projection_compute)
                string(APPEND _projection_name "_compute")
                list(APPEND _projection_defines AZURE_COMPUTE_SKINNING=1)
            endif()
            compile_shader("${SHADER_SOURCE_DIR}/mesh.vert" DEFINES ${_projection_defines} OUTPUT_NAME "${_projection_name}.vert")
        endforeach()
    endforeach()
endforeach()
compile_shader("${SHADER_SOURCE_DIR}/mesh.vert" DEFINES AZURE_OBJECT_SHADOW=1 OUTPUT_NAME mesh_object.vert)
compile_shader("${SHADER_SOURCE_DIR}/mesh.vert" DEFINES AZURE_OBJECT_SHADOW=1 AZURE_COMPUTE_SKINNING=1 OUTPUT_NAME mesh_object_compute.vert)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_OBJECT_SHADOW=1 OUTPUT_NAME mesh_object.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_OBJECT_SHADOW=1 AZURE_BINDLESS=1 OUTPUT_NAME mesh_object_bindless.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_OBJECT_SHADOW=1 AZURE_OPAQUE_SNAPSHOT=1 OUTPUT_NAME character_snapshot_object.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES AZURE_OBJECT_SHADOW=1 AZURE_BINDLESS=1 AZURE_OPAQUE_SNAPSHOT=1 OUTPUT_NAME character_snapshot_object_bindless.frag)
foreach(_hair_object IN ITEMS 0 1)
    foreach(_hair_indexed IN ITEMS 0 1)
        set(_hair_defines AZURE_HAIR_PIXEL_INTEGRAL=1)
        set(_hair_suffix "")
        if(_hair_object)
            list(APPEND _hair_defines AZURE_OBJECT_SHADOW=1)
            string(APPEND _hair_suffix "_object")
        endif()
        if(_hair_indexed)
            list(APPEND _hair_defines AZURE_BINDLESS=1)
            string(APPEND _hair_suffix "_bindless")
        endif()
        compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES ${_hair_defines} OUTPUT_NAME "mesh_integral${_hair_suffix}.frag")
        compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES ${_hair_defines} AZURE_OPAQUE_SNAPSHOT=1 OUTPUT_NAME "character_snapshot_integral${_hair_suffix}.frag")
    endforeach()
endforeach()
compile_shader(
    "${SHADER_SOURCE_DIR}/mesh.frag"
    DEFINES AZURE_BINDLESS=1
    OUTPUT_NAME mesh_bindless.frag)
compile_shader("${SHADER_SOURCE_DIR}/outline.vert")
compile_shader(
    "${SHADER_SOURCE_DIR}/outline.vert"
    DEFINES AZURE_COMPUTE_SKINNING=1
    OUTPUT_NAME outline_compute.vert)
compile_shader("${SHADER_SOURCE_DIR}/outline.frag")
compile_shader("${SHADER_SOURCE_DIR}/outline.vert" DEFINES AZURE_VIEW_SCALED_OUTLINE=1 OUTPUT_NAME outline_view_scaled.vert)
compile_shader("${SHADER_SOURCE_DIR}/outline.vert" DEFINES AZURE_VIEW_SCALED_OUTLINE=1 AZURE_BINDLESS=1 OUTPUT_NAME outline_view_scaled_bindless.vert)
compile_shader("${SHADER_SOURCE_DIR}/outline.vert" DEFINES AZURE_VIEW_SCALED_OUTLINE=1 AZURE_COMPUTE_SKINNING=1 OUTPUT_NAME outline_view_scaled_compute.vert)
compile_shader("${SHADER_SOURCE_DIR}/outline.vert" DEFINES AZURE_VIEW_SCALED_OUTLINE=1 AZURE_COMPUTE_SKINNING=1 AZURE_BINDLESS=1 OUTPUT_NAME outline_view_scaled_compute_bindless.vert)
compile_shader("${SHADER_SOURCE_DIR}/outline.frag" DEFINES AZURE_VIEW_SCALED_OUTLINE=1 OUTPUT_NAME outline_view_scaled.frag)
compile_shader("${SHADER_SOURCE_DIR}/outline.frag" DEFINES AZURE_VIEW_SCALED_OUTLINE=1 AZURE_BINDLESS=1 OUTPUT_NAME outline_view_scaled_bindless.frag)
compile_shader("${SHADER_SOURCE_DIR}/outline_depth.frag")
compile_shader("${SHADER_SOURCE_DIR}/outline_depth.frag" DEFINES AZURE_BINDLESS=1 OUTPUT_NAME outline_depth_bindless.frag)
foreach(_snapshot_object "" "_object")
    foreach(_snapshot_bindless "" "_bindless")
        set(_snapshot_defines AZURE_GEOMETRY_SAMPLES=1 AZURE_OPAQUE_SNAPSHOT=1)
        if(_snapshot_object)
            list(APPEND _snapshot_defines AZURE_OBJECT_SHADOW=1)
        endif()
        if(_snapshot_bindless)
            list(APPEND _snapshot_defines AZURE_BINDLESS=1)
        endif()
        compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES ${_snapshot_defines} OUTPUT_NAME "character_snapshot${_snapshot_object}${_snapshot_bindless}_samples.frag")
    endforeach()
endforeach()
compile_shader("${SHADER_SOURCE_DIR}/outline_depth.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1 OUTPUT_NAME outline_depth_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/outline_depth.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1 AZURE_BINDLESS=1 OUTPUT_NAME outline_depth_bindless_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/outline_mask.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1 OUTPUT_NAME outline_mask_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/outline_mask.frag" DEFINES AZURE_GEOMETRY_SAMPLES=1 AZURE_BINDLESS=1 OUTPUT_NAME outline_mask_bindless_samples.frag)
compile_shader("${SHADER_SOURCE_DIR}/sampled_upload_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/outline_mask.frag")
compile_shader("${SHADER_SOURCE_DIR}/multisample_probe.vert")
compile_shader("${SHADER_SOURCE_DIR}/multisample_probe.frag")
compile_shader("${SHADER_SOURCE_DIR}/scene_multisample_resolve.frag")
compile_shader("${SHADER_SOURCE_DIR}/scene_multisample_resolve.frag" DEFINES AZURE_DISPLAY_MASK=1 OUTPUT_NAME scene_multisample_display_resolve.frag)
compile_shader("${SHADER_SOURCE_DIR}/scene_multisample_probe.frag")
compile_shader("${SHADER_SOURCE_DIR}/outline_mask.frag" DEFINES AZURE_BINDLESS=1 OUTPUT_NAME outline_mask_bindless.frag)
compile_shader("${SHADER_SOURCE_DIR}/mesh.vert" DEFINES AZURE_OUTLINE_MASK=1 OUTPUT_NAME outline_mask.vert)
compile_shader("${SHADER_SOURCE_DIR}/mesh.vert" DEFINES AZURE_OUTLINE_MASK=1 AZURE_COMPUTE_SKINNING=1 OUTPUT_NAME outline_mask_compute.vert)
compile_shader("${SHADER_SOURCE_DIR}/background.vert")
compile_shader("${SHADER_SOURCE_DIR}/background.frag")
compile_shader(
    "${SHADER_SOURCE_DIR}/background.frag"
    DEFINES AZURE_BINDLESS=1
    OUTPUT_NAME background_bindless.frag)
compile_shader("${SHADER_SOURCE_DIR}/shadow.vert")
compile_shader(
    "${SHADER_SOURCE_DIR}/shadow.vert"
    DEFINES AZURE_COMPUTE_SKINNING=1
    OUTPUT_NAME shadow_compute.vert)
compile_shader("${SHADER_SOURCE_DIR}/shadow.frag")
compile_shader(
    "${SHADER_SOURCE_DIR}/shadow.frag"
    DEFINES AZURE_BINDLESS=1
    OUTPUT_NAME shadow_bindless.frag)
compile_shader("${SHADER_SOURCE_DIR}/inner_outline.vert")
compile_shader("${SHADER_SOURCE_DIR}/inner_outline.frag")
compile_shader("${SHADER_SOURCE_DIR}/hud.vert")
compile_shader("${SHADER_SOURCE_DIR}/hud.frag")
compile_shader("${SHADER_SOURCE_DIR}/game-ui.vert")
compile_shader("${SHADER_SOURCE_DIR}/game-ui.frag")
compile_shader("${SHADER_SOURCE_DIR}/blackhole.vert")
compile_shader("${SHADER_SOURCE_DIR}/blackhole.frag")
compile_shader("${SHADER_SOURCE_DIR}/pathtracing.comp")
compile_shader("${SHADER_SOURCE_DIR}/pathtracing.frag")
compile_shader("${SHADER_SOURCE_DIR}/sky.frag")
compile_shader("${SHADER_SOURCE_DIR}/blackhole_taa.frag")
compile_shader(
    "${SHADER_SOURCE_DIR}/blackhole_taa.frag"
    DEFINES AZURE_COMPUTE_BLOOM=1
    OUTPUT_NAME blackhole_taa_compute.frag)
compile_shader("${SHADER_SOURCE_DIR}/blackhole_composite.frag")
compile_shader("${SHADER_SOURCE_DIR}/clear.comp")
compile_shader("${SHADER_SOURCE_DIR}/view_resolve.frag")
compile_shader("${SHADER_SOURCE_DIR}/spatial_antialiasing.frag")
compile_shader("${SHADER_SOURCE_DIR}/bloom_downsample.comp")
compile_shader("${SHADER_SOURCE_DIR}/bloom_composite.comp")
compile_shader("${SHADER_SOURCE_DIR}/ibl_prefilter.comp")
compile_shader("${SHADER_SOURCE_DIR}/skin.comp")
compile_shader("${SHADER_SOURCE_DIR}/specular_ramp_test.comp")
compile_shader("${SHADER_SOURCE_DIR}/irradiance_query_test.comp")
# Optional scene resources derive from the existing material program matrix.
get_property(_clipmap_base_programs GLOBAL PROPERTY AZURE_SHADER_DESCRIPTORS)
foreach(_clipmap_base IN LISTS _clipmap_base_programs)
    string(JSON _clipmap_source GET "${_clipmap_base}" source)
    if(NOT _clipmap_source STREQUAL "mesh.frag")
        continue()
    endif()
    string(JSON _clipmap_output GET "${_clipmap_base}" output)
    string(REGEX REPLACE "\\.frag\\.spv$" "_clipmap.frag" _clipmap_output "${_clipmap_output}")
    set(_clipmap_defines AZURE_IRRADIANCE_CLIPMAP=1)
    string(JSON _clipmap_define_count LENGTH "${_clipmap_base}" defines)
    if(_clipmap_define_count GREATER 0)
        math(EXPR _clipmap_define_last "${_clipmap_define_count}-1")
        foreach(_clipmap_define_index RANGE 0 ${_clipmap_define_last})
            string(JSON _clipmap_define GET "${_clipmap_base}" defines ${_clipmap_define_index})
            list(APPEND _clipmap_defines "${_clipmap_define}")
        endforeach()
    endif()
    if("AZURE_VIEW_FOG=1" IN_LIST _clipmap_defines)
        continue()
    endif()
    compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES ${_clipmap_defines} OUTPUT_NAME "${_clipmap_output}")
endforeach()
get_property(_field_base_programs GLOBAL PROPERTY AZURE_SHADER_DESCRIPTORS)
foreach(_field_base IN LISTS _field_base_programs)
    string(JSON _field_source GET "${_field_base}" source)
    if(NOT _field_source STREQUAL "mesh.frag")
        continue()
    endif()
    string(JSON _field_output GET "${_field_base}" output)
    string(REGEX REPLACE "\\.frag\\.spv$" "_field.frag" _field_output "${_field_output}")
    set(_field_defines AZURE_PROBE_FIELD=1)
    string(JSON _field_define_count LENGTH "${_field_base}" defines)
    if(_field_define_count GREATER 0)
        math(EXPR _field_define_last "${_field_define_count}-1")
        foreach(_field_define_index RANGE 0 ${_field_define_last})
            string(JSON _field_define GET "${_field_base}" defines ${_field_define_index})
            list(APPEND _field_defines "${_field_define}")
        endforeach()
    endif()
    if("AZURE_VIEW_FOG=1" IN_LIST _field_defines)
        continue()
    endif()
    compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES ${_field_defines} OUTPUT_NAME "${_field_output}")
endforeach()
# Fully covered ordinary surfaces use a separate early-depth program family.
get_property(_early_base_programs GLOBAL PROPERTY AZURE_SHADER_DESCRIPTORS)
foreach(_early_base IN LISTS _early_base_programs)
    string(JSON _early_source GET "${_early_base}" source)
    if(NOT _early_source STREQUAL "mesh.frag")
        continue()
    endif()
    set(_early_defines AZURE_ORDINARY_EARLY_DEPTH=1)
    string(JSON _early_count LENGTH "${_early_base}" defines)
    if(_early_count GREATER 0)
        math(EXPR _early_last "${_early_count}-1")
        foreach(_early_index RANGE 0 ${_early_last})
            string(JSON _early_define GET "${_early_base}" defines ${_early_index})
            list(APPEND _early_defines "${_early_define}")
        endforeach()
    endif()
    if("AZURE_GEOMETRY_SAMPLES=1" IN_LIST _early_defines
        OR "AZURE_HAIR_PIXEL_INTEGRAL=1" IN_LIST _early_defines
        OR "AZURE_VIEW_FOG=1" IN_LIST _early_defines)
        continue()
    endif()
    string(JSON _early_output GET "${_early_base}" output)
    string(REGEX REPLACE "\\.frag\\.spv$" "_early.frag" _early_output "${_early_output}")
    compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES ${_early_defines} OUTPUT_NAME "${_early_output}")
endforeach()
# Explicit material lighting policies have an isolated program family.
get_property(_lighting_base_programs GLOBAL PROPERTY AZURE_SHADER_DESCRIPTORS)
foreach(_lighting_base IN LISTS _lighting_base_programs)
    string(JSON _lighting_source GET "${_lighting_base}" source)
    if(NOT _lighting_source STREQUAL "mesh.frag")
        continue()
    endif()
    string(JSON _lighting_output GET "${_lighting_base}" output)
    string(REGEX REPLACE "\\.frag\\.spv$" "_lighting.frag" _lighting_output "${_lighting_output}")
    set(_lighting_defines AZURE_EXTENDED_MATERIAL_LIGHTING=1)
    string(JSON _lighting_define_count LENGTH "${_lighting_base}" defines)
    if(_lighting_define_count GREATER 0)
        math(EXPR _lighting_define_last "${_lighting_define_count}-1")
        foreach(_lighting_define_index RANGE 0 ${_lighting_define_last})
            string(JSON _lighting_define GET "${_lighting_base}" defines ${_lighting_define_index})
            list(APPEND _lighting_defines "${_lighting_define}")
        endforeach()
    endif()
    if("AZURE_VIEW_FOG=1" IN_LIST _lighting_defines)
        continue()
    endif()
    compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES ${_lighting_defines} OUTPUT_NAME "${_lighting_output}")
endforeach()
# Independent coverage is isolated from every existing default program.
get_property(_coverage_base_programs GLOBAL PROPERTY AZURE_SHADER_DESCRIPTORS)
foreach(_coverage_base IN LISTS _coverage_base_programs)
    string(JSON _coverage_source GET "${_coverage_base}" source)
    if(NOT _coverage_source MATCHES "^(mesh|character_depth|shadow|outline|outline_depth|outline_mask)\\.frag$")
        continue()
    endif()
    string(JSON _coverage_output GET "${_coverage_base}" output)
    string(REGEX REPLACE "\\.frag\\.spv$" "_coverage.frag" _coverage_output "${_coverage_output}")
    set(_coverage_defines AZURE_INDEPENDENT_COVERAGE=1)
    string(JSON _coverage_count LENGTH "${_coverage_base}" defines)
    if(_coverage_count GREATER 0)
        math(EXPR _coverage_last "${_coverage_count}-1")
        foreach(_coverage_index RANGE 0 ${_coverage_last})
            string(JSON _coverage_define GET "${_coverage_base}" defines ${_coverage_index})
            list(APPEND _coverage_defines "${_coverage_define}")
        endforeach()
    endif()
    if("AZURE_VIEW_FOG=1" IN_LIST _coverage_defines)
        continue()
    endif()
    compile_shader("${SHADER_SOURCE_DIR}/${_coverage_source}" DEFINES ${_coverage_defines} OUTPUT_NAME "${_coverage_output}")
endforeach()
# Default isolation is prepared only for main, single-sample early-depth programs.
get_property(_isolation_base_programs GLOBAL PROPERTY AZURE_SHADER_DESCRIPTORS)
if(NOT AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION)
    set(_isolation_base_programs)
endif()
foreach(_isolation_base IN LISTS _isolation_base_programs)
    string(JSON _isolation_source GET "${_isolation_base}" source)
    string(JSON _isolation_output GET "${_isolation_base}" output)
    if(NOT _isolation_source STREQUAL "mesh.frag"
        OR NOT _isolation_output MATCHES "^mesh.*_early(_lighting)?(_coverage)?\\.frag\\.spv$")
        continue()
    endif()
    set(_isolation_defines AZURE_STATIC_ISOLATION=1)
    string(JSON _isolation_count LENGTH "${_isolation_base}" defines)
    if(_isolation_count GREATER 0)
        math(EXPR _isolation_last "${_isolation_count}-1")
        foreach(_isolation_index RANGE 0 ${_isolation_last})
            string(JSON _isolation_define GET "${_isolation_base}" defines ${_isolation_index})
            list(APPEND _isolation_defines "${_isolation_define}")
        endforeach()
    endif()
    string(REGEX REPLACE "\\.frag\\.spv$" "_isolation0.frag" _isolation_output "${_isolation_output}")
    compile_shader("${SHADER_SOURCE_DIR}/mesh.frag" DEFINES ${_isolation_defines} OUTPUT_NAME "${_isolation_output}")
endforeach()
if(AZURE_ENABLE_SURFACE_RADIANCE_REUSE)
get_property(_radiance_bases GLOBAL PROPERTY AZURE_SHADER_DESCRIPTORS)
foreach(_radiance_base IN LISTS _radiance_bases)
    string(JSON _radiance_source GET "${_radiance_base}" source)
    string(JSON _radiance_output GET "${_radiance_base}" output)
    string(JSON _radiance_count LENGTH "${_radiance_base}" defines)
    set(_radiance_defines)
    if(_radiance_count GREATER 0)
        math(EXPR _radiance_last "${_radiance_count}-1")
        foreach(_radiance_index RANGE 0 ${_radiance_last})
            string(JSON _radiance_define GET "${_radiance_base}" defines ${_radiance_index})
            list(APPEND _radiance_defines "${_radiance_define}")
        endforeach()
    endif()
    set(_radiance_selected FALSE)
    if(_radiance_source STREQUAL "mesh.vert" AND NOT "AZURE_SNAPSHOT_DEPTH=1" IN_LIST _radiance_defines AND NOT "AZURE_OUTLINE_MASK=1" IN_LIST _radiance_defines)
        set(_radiance_selected TRUE)
    elseif(_radiance_source STREQUAL "mesh.frag" AND "AZURE_ORDINARY_EARLY_DEPTH=1" IN_LIST _radiance_defines AND NOT "AZURE_EXTENDED_MATERIAL_LIGHTING=1" IN_LIST _radiance_defines AND NOT "AZURE_INDEPENDENT_COVERAGE=1" IN_LIST _radiance_defines AND NOT "AZURE_GEOMETRY_SAMPLES=1" IN_LIST _radiance_defines AND NOT "AZURE_VIEW_FOG=1" IN_LIST _radiance_defines)
        set(_radiance_selected TRUE)
    endif()
    if(_radiance_selected AND NOT "AZURE_STATIC_ISOLATION=1" IN_LIST _radiance_defines)
        string(REGEX REPLACE "\\.spv$" "" _radiance_output "${_radiance_output}")
        string(REGEX REPLACE "\\.(vert|frag)$" "_radiance.\\1" _radiance_output "${_radiance_output}")
        compile_shader("${SHADER_SOURCE_DIR}/${_radiance_source}" DEFINES ${_radiance_defines} AZURE_SURFACE_RADIANCE_REUSE=1 OUTPUT_NAME "${_radiance_output}")
        if(AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION AND _radiance_source STREQUAL "mesh.frag" AND NOT "AZURE_OPAQUE_SNAPSHOT=1" IN_LIST _radiance_defines)
            string(REPLACE "_radiance.frag" "_radiance_fast.frag" _radiance_fast_output "${_radiance_output}")
            compile_shader("${SHADER_SOURCE_DIR}/${_radiance_source}" DEFINES ${_radiance_defines} AZURE_SURFACE_RADIANCE_REUSE=1 AZURE_SURFACE_RADIANCE_FAST=1 OUTPUT_NAME "${_radiance_fast_output}")
        endif()
        if(AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS AND _radiance_source STREQUAL "mesh.frag")
            string(REPLACE "_radiance.frag" "_radiance_stats.frag" _radiance_stats_output "${_radiance_output}")
            set(_radiance_stats_sampling)
            if(AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION)
                list(APPEND _radiance_stats_sampling AZURE_SURFACE_RADIANCE_SPARSE_DIAGNOSTICS=1)
                if(NOT "AZURE_OPAQUE_SNAPSHOT=1" IN_LIST _radiance_defines)
                    string(REPLACE "_radiance_fast.frag" "_radiance_fast_stats.frag" _radiance_fast_stats_output "${_radiance_fast_output}")
                    compile_shader("${SHADER_SOURCE_DIR}/${_radiance_source}" DEFINES ${_radiance_defines} AZURE_SURFACE_RADIANCE_REUSE=1 AZURE_SURFACE_RADIANCE_FAST=1 AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1 AZURE_SURFACE_RADIANCE_SPARSE_DIAGNOSTICS=1 AZURE_SURFACE_RADIANCE_CAPTURE_FAILURES=1 OUTPUT_NAME "${_radiance_fast_stats_output}")
                endif()
            endif()
            compile_shader("${SHADER_SOURCE_DIR}/${_radiance_source}" DEFINES ${_radiance_defines} ${_radiance_stats_sampling} AZURE_SURFACE_RADIANCE_REUSE=1 AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1 OUTPUT_NAME "${_radiance_stats_output}")
        endif()
    endif()
endforeach()
endif()
add_custom_target(AzureRenderShaders ALL DEPENDS ${COMPILED_SHADERS})
find_program(AZURE_DXC_EXECUTABLE NAMES dxc HINTS "$ENV{VULKAN_SDK}/Bin" "$ENV{VULKAN_SDK}/bin")
if(AZURE_DXC_EXECUTABLE)
    get_filename_component(AZURE_DXC_DIRECTORY "${AZURE_DXC_EXECUTABLE}" DIRECTORY)
    set(AZURE_DXC_DEPENDENCIES "${AZURE_DXC_EXECUTABLE}")
    foreach(AZURE_DXC_LIBRARY dxcompiler.dll libdxcompiler.so)
        if(EXISTS "${AZURE_DXC_DIRECTORY}/${AZURE_DXC_LIBRARY}")
            list(APPEND AZURE_DXC_DEPENDENCIES "${AZURE_DXC_DIRECTORY}/${AZURE_DXC_LIBRARY}")
        endif()
    endforeach()
    set(AZURE_PROJECTED_REFLECTION_SHADER "${SHADER_BINARY_DIR}/projected_reflection_trace.comp.spv")
    set(AZURE_PROJECTED_REFLECTION_DXC_ARGS -spirv -T cs_6_0 -E main -HV 2018 -fspv-target-env=vulkan1.1
        -fvk-b-shift 0 0 -fvk-t-shift 1 0 -fvk-s-shift 8 0 -fvk-u-shift 9 0 -Od)
    add_custom_command(OUTPUT "${AZURE_PROJECTED_REFLECTION_SHADER}"
        COMMAND "${CMAKE_COMMAND}" -E make_directory "${SHADER_BINARY_DIR}"
        COMMAND "${AZURE_DXC_EXECUTABLE}" ${AZURE_PROJECTED_REFLECTION_DXC_ARGS}
            -Fo "${AZURE_PROJECTED_REFLECTION_SHADER}" "${SHADER_SOURCE_DIR}/projected_reflection_trace.hlsl"
        DEPENDS "${SHADER_SOURCE_DIR}/projected_reflection_trace.hlsl" ${AZURE_DXC_DEPENDENCIES}
        COMMENT "Compiling projected reflection trace" VERBATIM)
    add_custom_target(AzureProjectedReflectionShaders DEPENDS "${AZURE_PROJECTED_REFLECTION_SHADER}")
    add_dependencies(AzureRenderShaders AzureProjectedReflectionShaders)
    set(_projected_dxc_json_args "")
    foreach(_argument IN LISTS AZURE_PROJECTED_REFLECTION_DXC_ARGS)
        list(APPEND _projected_dxc_json_args "\"${_argument}\"")
    endforeach()
    list(JOIN _projected_dxc_json_args "," _projected_dxc_json_arguments)
    set_property(GLOBAL APPEND PROPERTY AZURE_SHADER_DESCRIPTORS
        "{\"source\":\"projected_reflection_trace.hlsl\",\"output\":\"projected_reflection_trace.comp.spv\",\"defines\":[],\"compiler\":\"${AZURE_DXC_EXECUTABLE}\",\"arguments\":[${_projected_dxc_json_arguments}],\"outputOption\":\"-Fo\"}")
endif()
include(cmake/AzureShaderModules.cmake)
get_property(AZURE_SHADER_DESCRIPTORS GLOBAL PROPERTY AZURE_SHADER_DESCRIPTORS)
list(JOIN AZURE_SHADER_DESCRIPTORS ",\n" AZURE_SHADER_DESCRIPTORS_JSON)
list(LENGTH AZURE_SHADER_DESCRIPTORS AZURE_SHADER_PROGRAM_COUNT)
if(AZURE_SHADER_PROGRAM_COUNT GREATER 1024)
    message(FATAL_ERROR "Shader program catalog exceeds the bounded reload capacity")
endif()
file(GENERATE OUTPUT "${CMAKE_CURRENT_BINARY_DIR}/shader-reload.json" CONTENT
    "{\"schemaVersion\":2,\"maximumPrograms\":${AZURE_SHADER_PROGRAM_COUNT},\"sourceRoot\":\"${SHADER_SOURCE_DIR}\",\"binaryRoot\":\"${SHADER_BINARY_DIR}\",\"scratchRoot\":\"${CMAKE_CURRENT_BINARY_DIR}/developer/shaders\",\"compiler\":\"$<TARGET_FILE:Vulkan::glslc>\",\"programs\":[${AZURE_SHADER_DESCRIPTORS_JSON}]}\n")

# Engine targets expose explicit ownership and dependency boundaries.
add_library(AzureBuildOptions INTERFACE)
target_include_directories(AzureBuildOptions INTERFACE "${CMAKE_CURRENT_SOURCE_DIR}/src")
target_compile_definitions(AzureBuildOptions INTERFACE GLFW_INCLUDE_VULKAN
    AZURERENDER_VERSION="${PROJECT_VERSION}-rc1"
    $<$<CONFIG:Debug>:AZURERENDER_ENABLE_VALIDATION=1>)
if(MSVC)
    target_compile_options(AzureBuildOptions INTERFACE /W4 /WX /permissive- /wd4127 /wd4456 /wd4996)
else()
    target_compile_options(AzureBuildOptions INTERFACE -Wall -Wextra -Wpedantic -Werror -Wno-missing-field-initializers)
endif()
add_library(AzureFoundation STATIC
    src/foundation/SettingRegistry.cpp
    src/diagnostics/RuntimeDiagnostics.cpp
    src/resources/ResourceLocator.cpp
)
add_library(AzurePlatform STATIC
    src/platform/NativeArguments.cpp
    src/platform/GlfwFrontend.cpp
    src/platform/ProcessRunner.cpp
    src/platform/PathSelection.cpp
)
add_library(AzureDevtools STATIC src/devtools/ShaderHotReloader.cpp src/devtools/ShaderCompileJob.cpp src/devtools/GeometryProcessCompiler.cpp)
target_link_libraries(AzureDevtools PUBLIC AzureRenderCore AzurePlatform AzureProcedural)
add_library(AzureProcedural STATIC src/assets/generators/ScadGenerator.cpp src/assets/generators/GeometryCompilerAdapter.cpp src/assets/generators/ProceduralGltfWriter.cpp src/assets/generators/RigTextGenerator.cpp)
target_link_libraries(AzureProcedural PUBLIC AzureRenderCore PRIVATE manifold::manifold)
add_executable(AzureGeometryCompiler tools/procedural/main.cpp)
add_executable(AzureMaterialValidator tools/MaterialValidator.cpp)
target_link_libraries(AzureMaterialValidator PRIVATE AzureRenderCore)
target_link_libraries(AzureGeometryCompiler PRIVATE AzureProcedural)
add_library(AzureAI STATIC src/ai/ModelClient.cpp src/ai/ModelProcess.cpp)
target_link_libraries(AzureAI PUBLIC AzureFoundation)
add_library(AzureRenderCore STATIC
    src/render/GpuStableKeySort.cpp
    src/render/GpuConservativeOcclusion.cpp
    src/render/GpuPredicateDrawSelection.cpp
    src/render/DepthPrepassSplit.cpp
    src/render/GpuTransparentIndexSort.cpp
    src/render/ScreenObjectVisibility.cpp
    src/render/ColorGradingLut.cpp
    src/render/ColorGradingLutGpu.cpp
    src/render/ReflectionSpatialFilter.cpp
    src/render/ReflectionSignalPyramid.cpp
    src/render/DepthPyramid.cpp
    src/render/ReflectionRay.cpp
    src/render/ProjectedReflectionRay.cpp
    src/render/ProjectedReflectionCamera.cpp
    src/render/ProjectedReflectionPreparation.cpp
    src/render/ProjectedScreenReflectionGpu.cpp
    src/render/ReflectionTemporal.cpp
    src/render/ReflectionReprojection.cpp
    src/render/ScreenReflectionGpu.cpp
    src/assets/GeneratorRegistry.cpp
    src/assets/PrimitiveGenerator.cpp
    src/assets/primitives/RoundPrimitives.cpp
    src/assets/MaterialData.cpp
    src/assets/MaterialGraph.cpp
    src/assets/Scene2D.cpp
    src/assets/TextureImportSettings.cpp
    src/assets/GltfLoader.cpp
    src/assets/UnlitTextureLayers.cpp
    src/animation/AnimationBlend.cpp
    src/animation/ExpressionPose.cpp
    src/assets/image/ImageCodec.cpp
    src/assets/image/SvgCodec.cpp
    src/assets/image/TextureContainerAdapter.cpp
    src/assets/image/ImageEncoder.cpp
    src/assets/image/ImageFormatAdapter.cpp
    src/assets/audio/AudioCodec.cpp
    src/assets/audio/CompressedAudioAdapter.cpp
    src/assets/audio/AudioEncoder.cpp
    src/assets/audio/AudioFormatAdapter.cpp
    src/assets/audio/MiniaudioImpl.cpp
    src/assets/audio/AudioNotificationQueue.cpp
    src/assets/AssetFormatRegistry.cpp
    src/assets/AssetTransfer.cpp
    src/assets/AssetExportJob.cpp
    src/assets/model/ModelFormatAdapter.cpp
    src/assets/model/UsdaFormatAdapter.cpp
    src/diagnostics/GpuCapabilityReport.cpp
    src/render/ResourceAccessProfile.cpp
    src/render/VisibilityPrototype.cpp
    src/render/RendererCore.cpp
    src/render/GameUiRenderer.cpp
    src/render/Renderer2D.cpp
    src/render/RenderGraph.cpp
    src/render/RenderViewService.cpp
    src/render/RenderViewOutput.cpp
    src/render/SpatialAntiAliasing.cpp
    src/render/TransientResourcePool.cpp
    src/render/RenderSettings.cpp
    src/render/EnvironmentAsset.cpp
    src/render/FogTransport.cpp
    src/render/AerialFog.cpp
    src/render/AnalyticFog.cpp
    src/render/FogVolumeData.cpp
    src/render/FogViewProjection.cpp
    src/render/ViewFogBinding.cpp
    src/render/ViewFogBindingJson.cpp
    src/render/ViewFogGpu.cpp
    src/render/EnvironmentCubeTexture.cpp
    src/render/ComputePass.cpp
    src/rhi/GpuAllocator.cpp
    src/rhi/NullRhi.cpp
    src/render/SampledTextureCache.cpp
    src/render/OutlineProjectionResources.cpp
    src/render/MotionPoseData.cpp
    src/render/SurfaceRadianceCache.cpp
    src/render/ShadowHistoryCache.cpp
    src/render/MotionVectorPass.cpp
    src/render/SceneMultisampling.cpp
    src/render/TemporalReconstruction.cpp
    src/render/MotionVectorTarget.cpp
    src/rhi/PipelineInspection.cpp
    src/rhi/PipelineCacheStore.cpp
    src/rhi/VulkanPipelineCache.cpp
    src/rhi/UploadRingBuffer.cpp
    src/rhi/VulkanRhi.cpp
    src/rhi/VulkanMemoryAllocatorImpl.cpp
    src/scenes/CharacterSceneRenderer.cpp
    src/scenes/pathtracing/PathTracingSceneRenderer.cpp
    src/render/pathtracing/TraceScene.cpp
    src/render/sky/SkyPass.cpp
    src/scenes/BlackholeSceneRenderer.cpp
    src/scenes/BuiltinRendererCatalog.cpp
    src/scenes/SampleSceneRenderer.cpp
)
add_executable(AzureMetaGen tools/metagen/main.cpp)
set(AZURE_GENERATED_DIR "${CMAKE_CURRENT_BINARY_DIR}/generated")
set(AZURE_REFLECTION_OUTPUT "${AZURE_GENERATED_DIR}/reflection/GeneratedRegistry.hpp")
set(AZURE_COMPONENT_OUTPUT "${AZURE_GENERATED_DIR}/runtime/GeneratedComponents.hpp")
add_custom_command(OUTPUT "${AZURE_REFLECTION_OUTPUT}" "${AZURE_COMPONENT_OUTPUT}"
    COMMAND AzureMetaGen "${AZURE_REFLECTION_OUTPUT}" ecs/Components.hpp ecs/GameComponents.hpp ecs/CameraComponents.hpp ecs/ObjectShadow.hpp --components-output "${AZURE_COMPONENT_OUTPUT}"
    WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/src"
    DEPENDS AzureMetaGen src/ecs/Components.hpp src/ecs/GameComponents.hpp src/ecs/CameraComponents.hpp src/ecs/ObjectShadow.hpp
    VERBATIM)
add_library(AzureReflection STATIC src/reflection/Registry.cpp "${AZURE_REFLECTION_OUTPUT}")
target_include_directories(AzureReflection PUBLIC "${AZURE_GENERATED_DIR}")
target_link_libraries(AzureReflection PUBLIC AzureFoundation nlohmann_json::nlohmann_json)
add_library(AzureRuntime STATIC
    src/assets/scene/SceneExchange.cpp
    src/assets/scene/SceneExchange.hpp
    src/runtime/MaterialDocument.cpp
    src/runtime/ScriptRuntimeRegistry.cpp
    src/runtime/EngineSettings.cpp
    src/runtime/ObservationRegistry.cpp
    src/runtime/ModuleAssembly.cpp
    src/runtime/ComponentRegistry.cpp
    src/runtime/SystemRegistry.cpp
    "${AZURE_COMPONENT_OUTPUT}"
    src/app/CommandLine.cpp
    src/runtime/SceneDocument.cpp
    src/runtime/SceneRenderSnapshot.cpp
    src/runtime/RuntimeRenderSnapshotCache.cpp
    src/runtime/Project.cpp
    src/runtime/AssetDatabase.cpp
    src/runtime/AssetSourceCache.cpp
    src/runtime/AssetGeneration.cpp
    src/runtime/Level.cpp
    src/runtime/Prefab.cpp
    src/runtime/LevelSession.cpp
    src/runtime/PhysicsWorld.cpp
    src/runtime/physics/PhysicsShapeFactory.cpp
    src/runtime/camera/GameCameraService.cpp
    src/runtime/GameRuntime.cpp
    src/runtime/PreviousTransformSnapshot.cpp
    src/runtime/GameUi.cpp
    src/runtime/AnimationStateMachine.cpp
    src/runtime/PresentationRuntime.cpp
    src/runtime/AudioRuntime.cpp
)
add_custom_target(AzureScriptBindingCheck
    COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/generate_script_bindings.py" --check
    VERBATIM)
add_library(AzureScriptingHost STATIC src/scripting/BindingDescriptor.cpp src/scripting/ScriptBindingHost.cpp src/scripting/ScriptHostSession.cpp)
target_link_libraries(AzureScriptingHost PUBLIC AzureRuntime)
add_dependencies(AzureScriptingHost AzureScriptBindingCheck)
option(AZURE_ENABLE_MANAGED_SCRIPT_PROTOTYPE "Enable trusted managed scripting prototypes" OFF)
if(AZURE_ENABLE_MANAGED_SCRIPT_PROTOTYPE)
    if(NOT WIN32)
        message(FATAL_ERROR "Managed scripting prototype currently supports Windows x64")
    endif()
    find_program(AZURE_DOTNET_EXECUTABLE dotnet REQUIRED)
    file(GLOB_RECURSE AZURE_MANAGED_INPUTS CONFIGURE_DEPENDS "${CMAKE_CURRENT_SOURCE_DIR}/managed/*.cs" "${CMAKE_CURRENT_SOURCE_DIR}/managed/*.json" "${CMAKE_CURRENT_SOURCE_DIR}/managed/*.csproj")
    set(AZURE_MANAGED_OUTPUT "${CMAKE_BINARY_DIR}/managed")
    add_custom_command(OUTPUT "${AZURE_MANAGED_OUTPUT}/complete.stamp"
        COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/build_managed_scripts.py" --output "${AZURE_MANAGED_OUTPUT}"
        DEPENDS ${AZURE_MANAGED_INPUTS} schemas/script_bindings.json tools/build_managed_scripts.py
        VERBATIM)
    add_custom_target(AzureManagedArtifacts DEPENDS "${AZURE_MANAGED_OUTPUT}/complete.stamp")
    add_library(AzureManagedScripting STATIC src/scripting/dotnet/ManagedModule.cpp src/scripting/dotnet/ManagedScriptRuntime.cpp src/scripting/dotnet/ManagedScriptingModule.cpp)
    target_link_libraries(AzureManagedScripting PUBLIC AzureScriptingHost)
    add_dependencies(AzureManagedScripting AzureManagedArtifacts)
endif()
add_library(AzureLuaScripting STATIC src/scripting/lua/ScriptRuntime.cpp src/scripting/lua/LuaScriptingModule.cpp)
target_link_libraries(AzureLuaScripting PUBLIC AzureScriptingHost PRIVATE sol2::sol2 ${LUA_LIBRARIES})
target_include_directories(AzureLuaScripting PRIVATE ${LUA_INCLUDE_DIR})
add_library(AzureGameplay STATIC
    src/gameplay/CharacterMovementSystem.cpp
    src/gameplay/CameraFollowSystem.cpp
    src/gameplay/LocomotionSystem.cpp
    src/gameplay/SharedSystems.cpp)
target_link_libraries(AzureGameplay PUBLIC AzureRuntime)
add_library(AzureValidation STATIC src/validation/ValidationService.cpp src/validation/ValidationTransport.cpp)
target_link_libraries(AzureValidation PUBLIC AzureRuntime)
if(WIN32)
    target_link_libraries(AzureValidation PRIVATE ws2_32)
endif()
add_library(AzureProjectRuntime STATIC src/app/ProjectRuntimeAssembly.cpp)
target_link_libraries(AzureProjectRuntime PUBLIC AzureGameplay AzureLuaScripting)
if(AZURE_ENABLE_MANAGED_SCRIPT_PROTOTYPE)
    target_link_libraries(AzureProjectRuntime PUBLIC AzureManagedScripting)
    target_compile_definitions(AzureProjectRuntime PRIVATE AZURE_ENABLE_MANAGED_SCRIPT_PROTOTYPE=1)
else()
    target_compile_definitions(AzureProjectRuntime PRIVATE AZURE_ENABLE_MANAGED_SCRIPT_PROTOTYPE=0)
endif()
add_library(AzureUi STATIC src/ui/localization/Localization.cpp src/ui/Widgets.cpp src/ui/Feedback.cpp src/ui/Containers.cpp src/ui/BrandMark.cpp src/ui/AppChrome.cpp)
target_link_libraries(AzureUi PUBLIC imgui::imgui)
target_include_directories(AzureUi PUBLIC "${CMAKE_CURRENT_SOURCE_DIR}/src")

add_library(AzureEditor STATIC
    src/editor/scene/SceneImportService.cpp
    src/editor/documents/EditorDocumentManager.cpp
    src/editor/animation/AnimationPreviewService.cpp
    src/editor/scripts/ScriptAuthoringRegistry.cpp
    src/editor/scripts/ScriptAuthoringOperations.cpp
    src/editor/documents/EditorDocumentSession.cpp
    src/editor/documents/DocumentBatchTransaction.cpp
    src/editor/documents/DiagnosticOperations.cpp
    src/editor/preview/AssetThumbnailService.cpp
    src/editor/preview/DeveloperServices.cpp
    src/editor/ai/ProposalController.cpp
    src/editor/ai/ProposalOperations.cpp
    src/editor/ai/adapters/ProposalAdapters.cpp
    src/editor/panels/UiCatalogPanel.cpp
    src/editor/panels/SettingsPanel.cpp
    src/editor/panels/OutlinerPanel.cpp
    src/editor/panels/InspectorPanel.cpp
    src/editor/panels/ViewportPanel.cpp
    src/editor/panels/AssetBrowserPanel.cpp
    src/editor/panels/CapturePanel.cpp
    src/editor/panels/AnimationPanel.cpp
    src/editor/panels/GameplayDebugPanel.cpp
    src/editor/panels/BuildPanel.cpp
    src/editor/panels/ConsolePanel.cpp
    src/editor/SelectionService.cpp
    src/editor/properties/PropertyWidgets.cpp
    src/editor/console/ConsoleLogModel.cpp
    src/editor/commands/EditRegistry.cpp
    src/editor/commands/EditService.cpp
    src/editor/commands/EditTransaction.cpp
    src/editor/properties/PropertyEditorRegistry.cpp
    src/editor/properties/ReferencePickerService.cpp
    src/editor/commands/EditorOperations.cpp
    src/editor/viewport/SelectionBounds.cpp
    src/editor/viewport/EditorCameraService.cpp
    src/editor/viewport/GizmoController.cpp
    src/editor/documents/DocumentActionGuard.cpp
    src/editor/documents/EditorFeedback.cpp
    src/editor/documents/EditorTaskService.cpp
    src/editor/input/EditorInputRouter.cpp
    src/editor/input/ExternalFileDrop.cpp
    src/editor/EditorCameraController.cpp
    src/editor/EditorContext.cpp
    src/editor/EditorProjectEditing.cpp
    src/editor/EditorHierarchyEditing.cpp
    src/editor/content/ContentOperationService.cpp
    src/editor/content/PrefabAuthoringService.cpp
    src/editor/content/PrefabAuthoringOperations.cpp
    src/editor/panels/PrefabAuthoringPanel.cpp
    src/editor/material/MaterialEditingService.cpp
    src/editor/preview/ThumbnailProviderRegistry.cpp
    src/editor/panels/TextureAssetPanel.cpp
    src/editor/panels/AssetTransferPanel.cpp
    src/editor/panels/MaterialAssetPanel.cpp
    src/editor/panels/PhysicsAuthoringPanel.cpp
    src/editor/panels/DocumentTabs.cpp
    src/editor/panels/ScriptAuthoringPanel.cpp
    src/editor/panels/ProblemsPanel.cpp
    src/editor/panels/ContentAssistancePanel.cpp
    src/editor/viewport/ViewportOverlayRegistry.cpp
    src/editor/viewport/ViewportOverlays.cpp
    src/editor/viewport/PhysicsOverlays.cpp
    src/editor/content/AssetCatalog.cpp
    src/editor/content/ContentDirectoryModel.cpp
    src/editor/content/AssetEditorRegistry.cpp
    src/editor/content/AssetExportService.cpp
    src/editor/content/NodePresetRegistry.cpp
    src/editor/content/SceneNaming.cpp
    src/editor/content/ExternalDropImport.cpp
    src/editor/ui/ObjectCreationMenu.cpp
    src/editor/content/BuiltinGeometryService.cpp
    src/editor/AssetImportJob.cpp
    src/editor/EditorSession.cpp
    src/editor/GameBuildJob.cpp
    src/editor/EditorAutomation.cpp
    src/editor/EditorWorkspace.cpp
    src/editor/EditorWorkspaceUI.cpp
    src/editor/EditorTheme.cpp
    src/editor/shell/EditorChrome.cpp
    src/editor/EditorToolbar.cpp
    src/editor/ImGuiEditorLayer.cpp
)
set(AZURE_HOST_SOURCES
    src/app/AzureRenderDevtools.cpp
    src/app/AzureRenderSettings.cpp
    src/app/AzureRenderValidation.cpp
    src/app/AzureRenderApp.cpp
    src/app/AzureRenderGameplay.cpp
    src/app/AzureRenderCapture.cpp
    src/app/AzureRenderDescriptors.cpp
    src/app/AzureRenderFrame.cpp
    src/app/AzureRenderPipeline.cpp
    src/app/AzureRenderResources.cpp
    src/app/AzureRenderSupport.cpp
)

target_link_libraries(AzureFoundation PUBLIC AzureBuildOptions nlohmann_json::nlohmann_json)
target_compile_definitions(AzureFoundation PRIVATE AZURERENDER_DEVELOPMENT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}")
target_link_libraries(AzurePlatform PUBLIC AzureFoundation Vulkan::Vulkan glfw)
if(WIN32)
    target_link_libraries(AzurePlatform PRIVATE ole32 shell32 uuid)
endif()
target_link_libraries(AzureRenderCore PUBLIC AzureFoundation Vulkan::Vulkan nlohmann_json::nlohmann_json RmlUi::RmlUi
    GPUOpen::VulkanMemoryAllocator OpenEXR::OpenEXR)
target_link_libraries(AzureRenderCore PRIVATE pugixml::pugixml Opus::opus OpusFile::opusfile mp3lame::mp3lame Microsoft::DirectXTex KTX::ktx assimp::assimp TIFF::TIFF WebP::webp ZLIB::ZLIB FLAC::FLAC Vorbis::vorbisenc)
target_include_directories(AzureRenderCore PRIVATE "${TINYGLTF_INCLUDE_DIR}" "${STB_INCLUDE_DIR}")
if(AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION)
    target_compile_definitions(AzureRenderCore PRIVATE AZURE_DEFAULT_ISOLATION_VARIANTS=1)
endif()
target_link_libraries(AzureRuntime PUBLIC AzureRenderCore AzureReflection Jolt::Jolt RmlUi::RmlUi)
target_link_libraries(AzureRuntime PRIVATE zstd::libzstd)
target_include_directories(AzureRuntime SYSTEM PRIVATE ${MINIAUDIO_INCLUDE_DIR})
target_include_directories(AzureRenderCore SYSTEM PRIVATE ${MINIAUDIO_INCLUDE_DIR})
if(WIN32)
    target_link_libraries(AzureRuntime PRIVATE winmm ole32 uuid)
    target_link_libraries(AzureRenderCore PRIVATE winmm ole32 uuid)
endif()
target_link_libraries(AzureEditor PUBLIC AzureUi AzureRuntime AzurePlatform AzureProjectRuntime AzureAI)
if(TARGET imgui::imgui)
    target_sources(AzureEditor PRIVATE third_party/ImGuizmo/ImGuizmo.cpp src/editor/viewport/ViewportGizmo.cpp)
    set_source_files_properties(third_party/ImGuizmo/ImGuizmo.cpp PROPERTIES COMPILE_OPTIONS "$<$<CXX_COMPILER_ID:MSVC>:/wd4245>")
    target_include_directories(AzureEditor PRIVATE third_party/ImGuizmo)
    target_include_directories(AzureEditor PRIVATE third_party/ImViewGuizmo)
    target_link_libraries(AzureEditor PUBLIC imgui::imgui)
    target_compile_definitions(AzureEditor PRIVATE AZURERENDER_HAS_IMGUI=1)
endif()
add_library(AzureRenderHost STATIC ${AZURE_HOST_SOURCES})
target_link_libraries(AzureRenderHost PUBLIC AzureRuntime AzurePlatform AzureEditor AzureValidation AzureDevtools)
target_compile_definitions(AzureRenderHost PUBLIC AZURE_WITH_EDITOR=1)
if(TARGET imgui::imgui)
    target_compile_definitions(AzureRenderHost PRIVATE AZURERENDER_HAS_IMGUI=1)
endif()
add_library(AzurePlayerHost STATIC ${AZURE_HOST_SOURCES})
target_link_libraries(AzurePlayerHost PUBLIC AzureRuntime AzurePlatform AzureProjectRuntime AzureValidation)
target_compile_definitions(AzurePlayerHost PUBLIC AZURE_WITH_EDITOR=0)
foreach(AZURE_HOST_TARGET AzureRenderHost AzurePlayerHost)
    target_include_directories(${AZURE_HOST_TARGET} PRIVATE "${TINYGLTF_INCLUDE_DIR}" "${STB_INCLUDE_DIR}")
endforeach()
add_executable(AzureRender src/main.cpp)
target_link_libraries(AzureRender PRIVATE AzureRenderHost)
add_executable(AzurePlayer src/player/main.cpp)
target_link_libraries(AzurePlayer PRIVATE AzurePlayerHost)
add_dependencies(AzureRender AzureRenderShaders)
add_dependencies(AzureRender AzureGeometryCompiler)
add_dependencies(AzurePlayer AzureRenderShaders)

if(BUILD_TESTING)
    add_executable(AzureScreenSpaceReflectionTests tests/ScreenSpaceReflectionTests.cpp src/runtime/SceneDocument.cpp src/render/RenderSettings.cpp)
    target_link_libraries(AzureScreenSpaceReflectionTests PRIVATE AzureRuntime AzureRenderCore)
    add_test(NAME AzureRender.ScreenSpaceReflection COMMAND AzureScreenSpaceReflectionTests "${CMAKE_CURRENT_BINARY_DIR}/runs/ssr-contract/roundtrip.azscene")
    add_executable(AzureProjectedReflectionSceneTests tests/ProjectedReflectionSceneTests.cpp)
    target_link_libraries(AzureProjectedReflectionSceneTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureProjectedReflectionSceneTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureProjectedReflectionSceneTests AzureRenderShaders)
    add_test(NAME AzureRender.ProjectedReflectionScene COMMAND AzureProjectedReflectionSceneTests "${SHADER_BINARY_DIR}")
    add_executable(AzureEnvironmentSpecularTests tests/EnvironmentSpecularTests.cpp src/render/RenderSettings.cpp src/runtime/SceneDocument.cpp)
    target_link_libraries(AzureEnvironmentSpecularTests PRIVATE AzureRuntime AzureRenderCore)
    add_test(NAME AzureRender.EnvironmentSpecular COMMAND AzureEnvironmentSpecularTests "${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures/environment_specular/dfg_reference.json" "${CMAKE_CURRENT_BINARY_DIR}/runs/environment-specular-cpu")
    add_test(NAME AzureTools.ScriptBindings COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_script_bindings.py")
    add_test(NAME AzureTools.PerformanceBudget COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_performance_budget.py")
    add_test(NAME AzureTools.GpuEnvironment COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_gpu_environment.py")
    add_test(NAME AzureTools.PerformanceProvenance COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_performance_provenance.py")
    add_test(NAME AzureTools.PlatformerLongRunRules COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_platformer_long_run.py")
    add_test(NAME AzureTools.LongRunCleanup COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_long_run_cleanup.py")
    set_tests_properties(AzureTools.LongRunCleanup PROPERTIES TIMEOUT 30)
    add_test(NAME AzureTools.MemoryResidency COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_memory_residency.py")
    add_test(NAME AzureTools.VirtualAllocationTrace COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_virtual_allocation_trace.py")
    add_executable(AzureVisibilityPrototypeTests tests/VisibilityPrototypeTests.cpp)
    target_link_libraries(AzureVisibilityPrototypeTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.VisibilityPrototype COMMAND AzureVisibilityPrototypeTests)
    add_test(NAME AzureTools.VisibilityBenchmark COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_visibility_benchmark.py")
    add_executable(AzureVisibilityGpuTests tests/VisibilityGpuTests.cpp)
    target_link_libraries(AzureVisibilityGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureVisibilityGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.VisibilityGpu COMMAND AzureVisibilityGpuTests
        "${SHADER_BINARY_DIR}/cull_indirect.comp.spv" "${SHADER_BINARY_DIR}/visibility_prototype.comp.spv"
        "${CMAKE_CURRENT_BINARY_DIR}/visibility-gpu.json")
    set_tests_properties(AzureRender.VisibilityGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureResourceAccessProfileTests tests/ResourceAccessProfileTests.cpp)
    add_executable(AzurePipelineInspectionTests tests/PipelineInspectionTests.cpp)
    target_link_libraries(AzurePipelineInspectionTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.PipelineInspection COMMAND AzurePipelineInspectionTests)
    target_link_libraries(AzureResourceAccessProfileTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ResourceAccessProfile COMMAND AzureResourceAccessProfileTests)
    add_executable(AzureSceneNodeGroupingTests tests/SceneNodeGroupingTests.cpp)
    target_include_directories(AzureSceneNodeGroupingTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.SceneNodeGrouping COMMAND AzureSceneNodeGroupingTests)
    add_executable(AzureStaticSkinningRecordingTests tests/StaticSkinningRecordingTests.cpp)
    target_link_libraries(AzureStaticSkinningRecordingTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureStaticSkinningRecordingTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureStaticSkinningRecordingTests AzureRenderShaders)
    add_test(NAME AzureRender.StaticSkinningRecording COMMAND AzureStaticSkinningRecordingTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.StaticSkinningRecording PROPERTIES TIMEOUT 120)

    add_executable(AzureSkinningBatchTests tests/SkinningBatchTests.cpp)
    target_link_libraries(AzureSkinningBatchTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.SkinningBatch COMMAND AzureSkinningBatchTests)
    add_executable(AzureViewBatchingTests tests/ViewBatchingTests.cpp)
    target_link_libraries(AzureViewBatchingTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ViewBatching COMMAND AzureViewBatchingTests)
    add_executable(AzurePrimitiveOpacityTests tests/PrimitiveOpacityTests.cpp)
    target_include_directories(AzurePrimitiveOpacityTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.PrimitiveOpacity COMMAND AzurePrimitiveOpacityTests)
    add_executable(AzureNodeOpacityRecordingTests tests/NodeOpacityRecordingTests.cpp)
    target_link_libraries(AzureNodeOpacityRecordingTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureNodeOpacityRecordingTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureNodeOpacityRecordingTests AzureRenderShaders)
    add_test(NAME AzureRender.NodeOpacityRecording COMMAND AzureNodeOpacityRecordingTests "${SHADER_BINARY_DIR}")
    add_executable(AzureOutlineCoverageRecordingTests tests/OutlineCoverageRecordingTests.cpp)
    target_link_libraries(AzureOutlineCoverageRecordingTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureOutlineCoverageRecordingTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureOutlineCoverageRecordingTests AzureRenderShaders)
    add_test(NAME AzureRender.OutlineCoverageRecording COMMAND AzureOutlineCoverageRecordingTests "${SHADER_BINARY_DIR}")
    add_executable(AzureSkinningGpuTests tests/SkinningGpuTests.cpp)
    target_link_libraries(AzureSkinningGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureSkinningGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.SkinningGpu COMMAND AzureSkinningGpuTests "${SHADER_BINARY_DIR}/skin.comp.spv")
    set_tests_properties(AzureRender.SkinningGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureShadowTileBoundsBatchTests tests/ShadowTileBoundsBatchTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureShadowTileBoundsBatchTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ShadowTileBoundsBatch COMMAND AzureShadowTileBoundsBatchTests)
    if(AZURE_ENABLE_BATCHED_SHADOW_BOUNDS)
        add_executable(AzureShadowTileBoundsBatchGpuTests tests/ShadowTileBoundsBatchGpuTests.cpp)
        target_link_libraries(AzureShadowTileBoundsBatchGpuTests PRIVATE AzureRenderCore)
        add_dependencies(AzureShadowTileBoundsBatchGpuTests AzureRenderShaders)
        add_test(NAME AzureRender.ShadowTileBoundsBatchGpu COMMAND AzureShadowTileBoundsBatchGpuTests "${SHADER_BINARY_DIR}")
        add_test(NAME AzureRender.ShadowTileBoundsBatchTailGpu COMMAND AzureShadowTileBoundsBatchGpuTests "${SHADER_BINARY_DIR}" --tail)
        set_tests_properties(AzureRender.ShadowTileBoundsBatchGpu AzureRender.ShadowTileBoundsBatchTailGpu PROPERTIES LABELS gpu SKIP_RETURN_CODE 77 RUN_SERIAL TRUE TIMEOUT 120)
    endif()

    add_executable(AzureShadowFilteringGpuTests tests/ShadowFilteringGpuTests.cpp)
    add_executable(AzurePipelineCacheStoreTests tests/PipelineCacheStoreTests.cpp)
    target_link_libraries(AzurePipelineCacheStoreTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.PipelineCacheStore COMMAND AzurePipelineCacheStoreTests "${CMAKE_BINARY_DIR}/test-artifacts/pipeline-cache-store")
    add_executable(AzureVulkanPipelineCacheTests tests/VulkanPipelineCacheTests.cpp)
    target_link_libraries(AzureVulkanPipelineCacheTests PRIVATE AzureRenderCore)
    add_dependencies(AzureVulkanPipelineCacheTests AzureRenderShaders)
    add_test(NAME AzureRender.VulkanPipelineCache COMMAND AzureVulkanPipelineCacheTests "${SHADER_BINARY_DIR}/shadow_bounds.comp.spv" "${CMAKE_BINARY_DIR}/test-artifacts/vulkan-pipeline-cache")
    set_tests_properties(AzureRender.VulkanPipelineCache PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureObjectShadowFilteringGpuTests tests/ObjectShadowFilteringGpuTests.cpp)
    target_link_libraries(AzureObjectShadowFilteringGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureObjectShadowFilteringGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ObjectShadowFilteringGpu COMMAND AzureObjectShadowFilteringGpuTests "${SHADER_BINARY_DIR}/object_shadow_filter_test.comp.spv")
    set_tests_properties(AzureRender.ObjectShadowFilteringGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureShadowTileBoundsGpuTests tests/ShadowTileBoundsGpuTests.cpp)
    target_link_libraries(AzureShadowTileBoundsGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureShadowTileBoundsGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ShadowTileBoundsGpu COMMAND AzureShadowTileBoundsGpuTests "${SHADER_BINARY_DIR}/shadow_bounds.comp.spv")
    set_tests_properties(AzureRender.ShadowTileBoundsGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    target_link_libraries(AzureShadowFilteringGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureShadowFilteringGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ShadowFilteringGpu COMMAND AzureShadowFilteringGpuTests "${SHADER_BINARY_DIR}/shadow_filter_test.comp.spv")
    set_tests_properties(AzureRender.ShadowFilteringGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureSceneInstanceGpuLayoutTests tests/SceneInstanceGpuLayoutTests.cpp)
    target_link_libraries(AzureSceneInstanceGpuLayoutTests PRIVATE AzureRenderCore)
    add_dependencies(AzureSceneInstanceGpuLayoutTests AzureRenderShaders)
    add_test(NAME AzureRender.SceneInstanceGpuLayout COMMAND AzureSceneInstanceGpuLayoutTests "${SHADER_BINARY_DIR}/scene_instance_layout_test.comp.spv")
    set_tests_properties(AzureRender.SceneInstanceGpuLayout PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 60)
    add_executable(AzureSurfaceResponseGpuTests tests/SurfaceResponseGpuTests.cpp)
    add_executable(AzureReferenceClipProjectionGpuTests tests/ReferenceClipProjectionGpuTests.cpp)
    target_link_libraries(AzureReferenceClipProjectionGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureReferenceClipProjectionGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ReferenceClipProjectionGpu COMMAND AzureReferenceClipProjectionGpuTests "${SHADER_BINARY_DIR}/reference_clip_projection_test.comp.spv")
    set_tests_properties(AzureRender.ReferenceClipProjectionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureMaterialUvGradientsGpuTests tests/MaterialUvGradientsGpuTests.cpp)
    target_link_libraries(AzureMaterialUvGradientsGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureMaterialUvGradientsGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.MaterialUvGradientsGpu COMMAND AzureMaterialUvGradientsGpuTests "${SHADER_BINARY_DIR}/material_uv_gradients_test.vert.spv" "${SHADER_BINARY_DIR}/material_uv_gradients_test.frag.spv")
    set_tests_properties(AzureRender.MaterialUvGradientsGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureMaterialOutputPrecisionGpuTests tests/MaterialOutputPrecisionGpuTests.cpp)
    target_link_libraries(AzureMaterialOutputPrecisionGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureMaterialOutputPrecisionGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.MaterialOutputPrecisionGpu COMMAND AzureMaterialOutputPrecisionGpuTests "${SHADER_BINARY_DIR}/material_output_precision_test.comp.spv")
    set_tests_properties(AzureRender.MaterialOutputPrecisionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureMotionProjectionGpuTests tests/MotionProjectionGpuTests.cpp)
    add_executable(AzureMotionPoseGpuTests tests/MotionPoseGpuTests.cpp)
    add_executable(AzureSpecularRampGpuTests tests/SpecularRampGpuTests.cpp)
    target_link_libraries(AzureSpecularRampGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureSpecularRampGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.SpecularRampGpu COMMAND AzureSpecularRampGpuTests "${SHADER_BINARY_DIR}/specular_ramp_test.comp.spv")
    set_tests_properties(AzureRender.SpecularRampGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureMotionVectorGpuTests tests/MotionVectorGpuTests.cpp)
    add_executable(AzureSceneMultisamplingGpuTests tests/SceneMultisamplingGpuTests.cpp)
    target_link_libraries(AzureSceneMultisamplingGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureSceneMultisamplingGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.SceneMultisamplingGpu COMMAND AzureSceneMultisamplingGpuTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.SceneMultisamplingGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120 SKIP_RETURN_CODE 77)
    add_executable(AzureSceneMultisamplingTests tests/SceneMultisamplingTests.cpp)
    target_link_libraries(AzureSceneMultisamplingTests PRIVATE AzureRenderCore)
    add_dependencies(AzureSceneMultisamplingTests AzureRenderShaders)
    add_test(NAME AzureRender.SceneMultisampling COMMAND AzureSceneMultisamplingTests "${SHADER_BINARY_DIR}")
    add_executable(AzureMultisampleContractTests tests/MultisampleContractTests.cpp)
    target_link_libraries(AzureMultisampleContractTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.MultisampleContract COMMAND AzureMultisampleContractTests)
    add_executable(AzureMultisampleGpuTests tests/MultisampleGpuTests.cpp)
    target_link_libraries(AzureMultisampleGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureMultisampleGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.MultisampleGpu COMMAND AzureMultisampleGpuTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.MultisampleGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120 SKIP_RETURN_CODE 77)
    add_executable(AzureTemporalViewGpuTests tests/TemporalViewGpuTests.cpp)
    target_link_libraries(AzureTemporalViewGpuTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureTemporalViewGpuTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureTemporalViewGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.TemporalViewGpu COMMAND AzureTemporalViewGpuTests "${SHADER_BINARY_DIR}" "${CMAKE_BINARY_DIR}/test-artifacts/temporal-views")
    set_tests_properties(AzureRender.TemporalViewGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 240)
    add_executable(AzureMaterialDisplayViewGpuTests tests/MaterialDisplayViewGpuTests.cpp)
    target_link_libraries(AzureMaterialDisplayViewGpuTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureMaterialDisplayViewGpuTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureMaterialDisplayViewGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.MaterialDisplayViewGpu COMMAND AzureMaterialDisplayViewGpuTests "${SHADER_BINARY_DIR}" "${CMAKE_BINARY_DIR}/test-artifacts/material-display-views")
    set_tests_properties(AzureRender.MaterialDisplayViewGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    target_link_libraries(AzureMotionVectorGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureMotionVectorGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.MotionVectorGpu COMMAND AzureMotionVectorGpuTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.MotionVectorGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureReadOnlyDepthGpuTests tests/ReadOnlyDepthGpuTests.cpp)
    target_link_libraries(AzureReadOnlyDepthGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureReadOnlyDepthGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ReadOnlyDepthGpu COMMAND AzureReadOnlyDepthGpuTests "${SHADER_BINARY_DIR}/readonly_depth_test.vert.spv" "${SHADER_BINARY_DIR}/readonly_depth_test.frag.spv")
    set_tests_properties(AzureRender.ReadOnlyDepthGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureDepthBiasGpuTests tests/DepthBiasGpuTests.cpp)
    target_link_libraries(AzureDepthBiasGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureDepthBiasGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.DepthBiasGpu COMMAND AzureDepthBiasGpuTests "${SHADER_BINARY_DIR}/readonly_depth_test.vert.spv" "${SHADER_BINARY_DIR}/depth_bias_test.frag.spv")
    set_tests_properties(AzureRender.DepthBiasGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureShaderSpecializationGpuTests tests/ShaderSpecializationGpuTests.cpp)
    add_executable(AzureVolumeImageUploadGpuTests tests/VolumeImageUploadGpuTests.cpp)
    target_link_libraries(AzureVolumeImageUploadGpuTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.VolumeImageUploadGpu COMMAND AzureVolumeImageUploadGpuTests)
    set_tests_properties(AzureRender.VolumeImageUploadGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureMaterialCoverageTests tests/MaterialCoverageTests.cpp)
    target_link_libraries(AzureMaterialCoverageTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.MaterialCoverage COMMAND AzureMaterialCoverageTests)
    add_test(NAME AzureRender.MaterialCoverageGpu
        COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_coverage_gpu.py"
            --executable "$<TARGET_FILE:AzurePlayer>")
    set_tests_properties(AzureRender.MaterialCoverageGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 1200)
    add_test(NAME AzureRender.MaterialCoverageFailureGpu
        COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_coverage_failure_gpu.py"
            --executable "$<TARGET_FILE:AzurePlayer>")
    set_tests_properties(AzureRender.MaterialCoverageFailureGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.MaterialCoverageMipsGpu
        COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_coverage_mips_gpu.py"
            --executable "$<TARGET_FILE:AzurePlayer>")
    set_tests_properties(AzureRender.MaterialCoverageMipsGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_executable(AzureMaterialPipelinePolicyTests tests/MaterialPipelinePolicyTests.cpp)
    target_link_libraries(AzureMaterialPipelinePolicyTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.MaterialPipelinePolicy COMMAND AzureMaterialPipelinePolicyTests)
    add_executable(AzureMaterialFacingDemandTests tests/MaterialFacingDemandTests.cpp)
    target_link_libraries(AzureMaterialFacingDemandTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureMaterialFacingDemandTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureMaterialFacingDemandTests AzureRenderShaders)
    add_test(NAME AzureRender.MaterialFacingDemand COMMAND AzureMaterialFacingDemandTests "${SHADER_BINARY_DIR}")
    add_executable(AzureMaterialClassEarlyDepthTests tests/MaterialClassEarlyDepthTests.cpp)
    target_link_libraries(AzureMaterialClassEarlyDepthTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureMaterialClassEarlyDepthTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureMaterialClassEarlyDepthTests AzureRenderShaders)
    add_test(NAME AzureRender.MaterialClassEarlyDepth COMMAND AzureMaterialClassEarlyDepthTests "${SHADER_BINARY_DIR}")
    foreach(AZURE_FEATURE_AA 0 3 4)
        add_test(NAME AzureRender.MaterialFeatureSpecializationGpu.aa${AZURE_FEATURE_AA}
            COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_feature_specialization_gpu.py"
                --player "$<TARGET_FILE:AzurePlayer>" --aa "${AZURE_FEATURE_AA}")
        set_tests_properties(AzureRender.MaterialFeatureSpecializationGpu.aa${AZURE_FEATURE_AA}
            PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 240)
    endforeach()
    target_link_libraries(AzureShaderSpecializationGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureShaderSpecializationGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ShaderSpecializationGpu COMMAND AzureShaderSpecializationGpuTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.ShaderSpecializationGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureBeautyCompositionGpuTests tests/BeautyCompositionGpuTests.cpp)
    target_link_libraries(AzureBeautyCompositionGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureBeautyCompositionGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.BeautyCompositionGpu COMMAND AzureBeautyCompositionGpuTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.BeautyCompositionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    target_link_libraries(AzureMotionPoseGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureMotionPoseGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.MotionPoseGpu COMMAND AzureMotionPoseGpuTests "${SHADER_BINARY_DIR}/motion_pose_test.comp.spv")
    set_tests_properties(AzureRender.MotionPoseGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    target_link_libraries(AzureMotionProjectionGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureMotionProjectionGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.MotionProjectionGpu COMMAND AzureMotionProjectionGpuTests "${SHADER_BINARY_DIR}/motion_projection_test.comp.spv")
    set_tests_properties(AzureRender.MotionProjectionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    target_link_libraries(AzureSurfaceResponseGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureSurfaceResponseGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.SurfaceResponseGpu COMMAND AzureSurfaceResponseGpuTests "${SHADER_BINARY_DIR}/surface_response_test.comp.spv" "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/showcase_looks.json")
    set_tests_properties(AzureRender.SurfaceResponseGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureOpaqueTransparencyScratchTests tests/OpaqueTransparencyScratchTests.cpp)
    add_executable(AzureSurfaceRadianceFrameSelectionTests tests/SurfaceRadianceFrameSelectionTests.cpp)
    target_link_libraries(AzureSurfaceRadianceFrameSelectionTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.SurfaceRadianceFrameSelection COMMAND AzureSurfaceRadianceFrameSelectionTests)
    add_executable(AzureSurfaceRadianceStatisticsTests tests/SurfaceRadianceStatisticsTests.cpp)
    target_link_libraries(AzureSurfaceRadianceStatisticsTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.SurfaceRadianceStatistics COMMAND AzureSurfaceRadianceStatisticsTests)
    add_executable(AzureSurfaceRadianceCacheTests tests/SurfaceRadianceCacheTests.cpp)
    target_link_libraries(AzureSurfaceRadianceCacheTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.SurfaceRadianceCache COMMAND AzureSurfaceRadianceCacheTests)
    add_executable(AzureShadowHistoryCacheTests tests/ShadowHistoryCacheTests.cpp)
    target_link_libraries(AzureShadowHistoryCacheTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ShadowHistoryCache COMMAND AzureShadowHistoryCacheTests)
    add_executable(AzureShadowHistoryPolicyTests tests/ShadowHistoryPolicyTests.cpp)
    target_link_libraries(AzureShadowHistoryPolicyTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ShadowHistoryPolicy COMMAND AzureShadowHistoryPolicyTests)
    add_executable(AzureShadowHistoryCacheGpuTests tests/ShadowHistoryCacheGpuTests.cpp)
    target_link_libraries(AzureShadowHistoryCacheGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureShadowHistoryCacheGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ShadowHistoryCacheGpu COMMAND AzureShadowHistoryCacheGpuTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.ShadowHistoryCacheGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120 SKIP_RETURN_CODE 77)
    if(AZURE_ENABLE_SURFACE_RADIANCE_REUSE)
    add_executable(AzureSurfaceRadianceCacheGpuTests tests/SurfaceRadianceCacheGpuTests.cpp)
    target_link_libraries(AzureSurfaceRadianceCacheGpuTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureSurfaceRadianceCacheGpuTests PRIVATE AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS=$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS}> AZURE_TEST_SURFACE_RADIANCE_FRAME_SELECTION=$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION}>)
    add_dependencies(AzureSurfaceRadianceCacheGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.SurfaceRadianceCacheGpu COMMAND AzureSurfaceRadianceCacheGpuTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.SurfaceRadianceCacheGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120 SKIP_RETURN_CODE 77)
    add_executable(AzureSurfaceRadianceViewGpuTests tests/SurfaceRadianceViewGpuTests.cpp)
    target_link_libraries(AzureSurfaceRadianceViewGpuTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureSurfaceRadianceViewGpuTests PRIVATE AZURE_TEST_SURFACE_RADIANCE_DIAGNOSTICS=$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS}> AZURE_TEST_SURFACE_RADIANCE_FRAME_SELECTION=$<BOOL:${AZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION}>)
    target_compile_definitions(AzureSurfaceRadianceViewGpuTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureSurfaceRadianceViewGpuTests AzureRenderShaders)
    add_executable(AzureSurfaceRadianceRecordingTests tests/SurfaceRadianceRecordingTests.cpp)
    target_link_libraries(AzureSurfaceRadianceRecordingTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureSurfaceRadianceRecordingTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureSurfaceRadianceRecordingTests AzureRenderShaders)
    add_test(NAME AzureRender.SurfaceRadianceRecording COMMAND AzureSurfaceRadianceRecordingTests "${SHADER_BINARY_DIR}")
    endif()
    target_link_libraries(AzureOpaqueTransparencyScratchTests PRIVATE AzureRenderCore)
    add_dependencies(AzureOpaqueTransparencyScratchTests AzureRenderShaders)
    add_test(NAME AzureRender.OpaqueTransparencyScratch COMMAND AzureOpaqueTransparencyScratchTests "${SHADER_BINARY_DIR}" "${CMAKE_CURRENT_SOURCE_DIR}")
    set_tests_properties(AzureRender.OpaqueTransparencyScratch PROPERTIES TIMEOUT 120)

    add_executable(AzureDepthOnlyShadowRecordingTests tests/DepthOnlyShadowRecordingTests.cpp)
    target_link_libraries(AzureDepthOnlyShadowRecordingTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureDepthOnlyShadowRecordingTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureDepthOnlyShadowRecordingTests AzureRenderShaders)
    add_test(NAME AzureRender.DepthOnlyShadowRecording COMMAND AzureDepthOnlyShadowRecordingTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.DepthOnlyShadowRecording PROPERTIES TIMEOUT 120)

    add_executable(AzureDepthPrefillRecordingTests tests/DepthPrefillRecordingTests.cpp)
    target_link_libraries(AzureDepthPrefillRecordingTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureDepthPrefillRecordingTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    target_compile_definitions(AzureDepthPrefillRecordingTests PRIVATE AZURE_TEST_DEFAULT_ISOLATION=$<BOOL:${AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION}>)
    add_dependencies(AzureDepthPrefillRecordingTests AzureRenderShaders)
    add_test(NAME AzureRender.DepthPrefillRecording COMMAND AzureDepthPrefillRecordingTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.DepthPrefillRecording PROPERTIES TIMEOUT 120)

    if(AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION)
    add_executable(AzureDefaultIsolationViewGpuTests tests/DefaultIsolationViewGpuTests.cpp)
    target_link_libraries(AzureDefaultIsolationViewGpuTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureDefaultIsolationViewGpuTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureDefaultIsolationViewGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.DefaultIsolationViewGpu COMMAND AzureDefaultIsolationViewGpuTests "${SHADER_BINARY_DIR}" "${CMAKE_BINARY_DIR}/test-artifacts/default-isolation-views")
    set_tests_properties(AzureRender.DefaultIsolationViewGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    endif()

    add_executable(AzureDepthOnlyGpuTests tests/DepthOnlyGpuTests.cpp)
    target_link_libraries(AzureDepthOnlyGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureDepthOnlyGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.DepthOnlyGpu COMMAND AzureDepthOnlyGpuTests "${SHADER_BINARY_DIR}/readonly_depth_test.vert.spv" "${SHADER_BINARY_DIR}/depth_bias_test.frag.spv")
    set_tests_properties(AzureRender.DepthOnlyGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)

    add_executable(AzureDepthOnlyPipelineTests tests/DepthOnlyPipelineTests.cpp)
    target_link_libraries(AzureDepthOnlyPipelineTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.DepthOnlyPipeline COMMAND AzureDepthOnlyPipelineTests)
    set_tests_properties(AzureRender.DepthOnlyPipeline PROPERTIES TIMEOUT 30)

    add_executable(AzureBufferBarrierBatchTests tests/BufferBarrierBatchTests.cpp)
    target_link_libraries(AzureBufferBarrierBatchTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.BufferBarrierBatch COMMAND AzureBufferBarrierBatchTests)
    set_tests_properties(AzureRender.BufferBarrierBatch PROPERTIES TIMEOUT 30)

    add_executable(AzureSampledUploadGpuTests tests/SampledUploadGpuTests.cpp)
    target_link_libraries(AzureSampledUploadGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureSampledUploadGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.SampledUploadGpu COMMAND AzureSampledUploadGpuTests "${SHADER_BINARY_DIR}/sampled_upload_test.comp.spv")
    set_tests_properties(AzureRender.SampledUploadGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureColorGradingLutGpuTests tests/ColorGradingLutGpuTests.cpp)
    target_link_libraries(AzureColorGradingLutGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureColorGradingLutGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ColorGradingLutGpu COMMAND AzureColorGradingLutGpuTests "${SHADER_BINARY_DIR}/color_grading_lut_test.comp.spv")
    set_tests_properties(AzureRender.ColorGradingLutGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    if(AZURE_ENABLE_SHADER_MODULE_PROTOTYPE)
        add_executable(AzureShaderModuleTests tests/ShaderModuleTests.cpp)
        target_link_libraries(AzureShaderModuleTests PRIVATE AzureRenderCore)
        add_dependencies(AzureShaderModuleTests AzureShaderModulePrototypes)
        add_test(NAME AzureRender.ShaderModule COMMAND AzureShaderModuleTests
            "${AZURE_MODULE_BINARY}/bloom-direct.spv.json" "${AZURE_MODULE_BINARY}/bloom-cached.spv.json")
        add_executable(AzureShaderCompositionTests tests/ShaderCompositionTests.cpp)
        target_link_libraries(AzureShaderCompositionTests PRIVATE AzureRenderCore)
        add_dependencies(AzureShaderCompositionTests AzureShaderModulePrototypes AzureRenderShaders)
        add_test(NAME AzureRender.ShaderComposition COMMAND AzureShaderCompositionTests
            "${SHADER_BINARY_DIR}/bloom_downsample.comp.spv" "${AZURE_MODULE_BINARY}/bloom-direct.spv"
            "${AZURE_MODULE_BINARY}/bloom-cached.spv" "${CMAKE_CURRENT_BINARY_DIR}/shader-composition.json")
        set_tests_properties(AzureRender.ShaderComposition PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
        add_test(NAME AzureTools.ShaderModule COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_shader_module.py")
        add_test(NAME AzureTools.ShaderTypes COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_shader_types.py")
        add_test(NAME AzureTools.ShaderComposition COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_shader_composition.py")
        set_tests_properties(AzureTools.ShaderModule AzureTools.ShaderComposition PROPERTIES ENVIRONMENT "AZURE_SLANG_COMPILER=${AZURE_SLANG_COMPILER}")
    endif()
    add_executable(AzureProceduralGeometryTests tests/ProceduralGeometryTests.cpp)
    target_link_libraries(AzureProceduralGeometryTests PRIVATE AzureProcedural)
    add_test(NAME AzureAssets.ProceduralGeometry COMMAND AzureProceduralGeometryTests "${CMAKE_CURRENT_BINARY_DIR}/procedural-tests")
    add_executable(AzureRigTextTests tests/RigTextTests.cpp)
    target_link_libraries(AzureRigTextTests PRIVATE AzureProcedural AzureRuntime)
    add_test(NAME AzureAssets.RigText COMMAND AzureRigTextTests "${CMAKE_CURRENT_BINARY_DIR}/rig-text-tests")
    add_executable(AzureProceduralProcessTests tests/ProceduralProcessTests.cpp)
    target_link_libraries(AzureProceduralProcessTests PRIVATE AzureDevtools)
    add_test(NAME AzureAssets.ProceduralProcess COMMAND AzureProceduralProcessTests "$<TARGET_FILE:AzureGeometryCompiler>" "${CMAKE_CURRENT_BINARY_DIR}/procedural-process-tests")
    add_executable(AzureLocalizationTests tests/LocalizationTests.cpp)
    target_link_libraries(AzureLocalizationTests PRIVATE AzureUi)
    add_test(NAME AzureUi.Localization COMMAND AzureLocalizationTests)
    add_executable(AzureCameraSystemTests tests/CameraSystemTests.cpp)
    target_link_libraries(AzureCameraSystemTests PRIVATE AzureRuntime)
    add_test(NAME AzureRuntime.CameraSystem COMMAND AzureCameraSystemTests)
    add_executable(AzurePathTracingTests tests/PathTracingTests.cpp)
    target_link_libraries(AzurePathTracingTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.PathTracing COMMAND AzurePathTracingTests)
    add_executable(AzureEngineSettingsTests tests/EngineSettingsTests.cpp)
    add_executable(AzureColorGradingLutTests tests/ColorGradingLutTests.cpp)
    target_link_libraries(AzureColorGradingLutTests PRIVATE AzureRuntime)
    add_test(NAME AzureRender.ColorGradingLut COMMAND AzureColorGradingLutTests)
    add_executable(AzureCharacterRepairTests tests/CharacterRepairTests.cpp)
    target_link_libraries(AzureCharacterRepairTests PRIVATE AzureRuntime)
    add_executable(AzureUnlitTextureLayersTests tests/UnlitTextureLayersTests.cpp)
    add_executable(AzureFogTransportTests tests/FogTransportTests.cpp)
    target_link_libraries(AzureFogTransportTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.FogTransport COMMAND AzureFogTransportTests)
    add_executable(AzureAerialFogTests tests/AerialFogTests.cpp)
    target_link_libraries(AzureAerialFogTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.AerialFog COMMAND AzureAerialFogTests)
    set(AZURE_AERIAL_TEST_SHADER "${CMAKE_CURRENT_BINARY_DIR}/shader-modules/aerial-fog-test.comp.spv")
    add_custom_command(OUTPUT "${AZURE_AERIAL_TEST_SHADER}"
        COMMAND "${CMAKE_COMMAND}" -E make_directory "${CMAKE_CURRENT_BINARY_DIR}/shader-modules"
        COMMAND Vulkan::glslc -I "${SHADER_SOURCE_DIR}" "${CMAKE_CURRENT_SOURCE_DIR}/tests/shaders/aerial_fog_test.comp" -o "${AZURE_AERIAL_TEST_SHADER}"
        DEPENDS tests/shaders/aerial_fog_test.comp shaders/fog_analytic.glsl shaders/fog_transport.glsl VERBATIM)
    add_custom_target(AzureAerialFogTestShader DEPENDS "${AZURE_AERIAL_TEST_SHADER}")
    add_executable(AzureAerialFogGpuTests tests/AerialFogGpuTests.cpp)
    target_link_libraries(AzureAerialFogGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureAerialFogGpuTests AzureAerialFogTestShader)
    add_test(NAME AzureRender.AerialFogGpu COMMAND AzureAerialFogGpuTests "${AZURE_AERIAL_TEST_SHADER}")
    set_tests_properties(AzureRender.AerialFogGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureFogVolumeDataTests tests/FogVolumeDataTests.cpp)
    target_link_libraries(AzureFogVolumeDataTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.FogVolumeData COMMAND AzureFogVolumeDataTests)
    add_executable(AzureFogViewProjectionTests tests/FogViewProjectionTests.cpp)
    target_link_libraries(AzureFogViewProjectionTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.FogViewProjection COMMAND AzureFogViewProjectionTests)
    add_executable(AzureViewFogBindingTests tests/ViewFogBindingTests.cpp)
    target_link_libraries(AzureViewFogBindingTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ViewFogBinding COMMAND AzureViewFogBindingTests)
    add_executable(AzureViewFogGpuTests tests/ViewFogGpuTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureViewFogGpuTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ViewFogGpu COMMAND AzureViewFogGpuTests)
    add_test(NAME AzureRender.ViewFogShaderContract COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/check_view_fog_shader_contract.py" "${SHADER_BINARY_DIR}")
    add_executable(AzureFogVolumeOwnerTests tests/FogVolumeOwnerTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureFogVolumeOwnerTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.FogVolumeOwner COMMAND AzureFogVolumeOwnerTests)
    set(AZURE_FOG_TEST_SHADER "${CMAKE_CURRENT_BINARY_DIR}/shader-modules/fog-volume-test.comp.spv")
    add_custom_command(OUTPUT "${AZURE_FOG_TEST_SHADER}"
        COMMAND "${CMAKE_COMMAND}" -E make_directory "${CMAKE_CURRENT_BINARY_DIR}/shader-modules"
        COMMAND Vulkan::glslc -I "${SHADER_SOURCE_DIR}" "${CMAKE_CURRENT_SOURCE_DIR}/tests/shaders/fog_volume_test.comp" -o "${AZURE_FOG_TEST_SHADER}"
        DEPENDS tests/shaders/fog_volume_test.comp shaders/fog_transport.glsl shaders/fog_view_projection.glsl VERBATIM)
    add_custom_target(AzureFogVolumeTestShader DEPENDS "${AZURE_FOG_TEST_SHADER}")
    add_executable(AzureFogVolumeGpuTests tests/FogVolumeGpuTests.cpp)
    target_link_libraries(AzureFogVolumeGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureFogVolumeGpuTests AzureFogVolumeTestShader)
    add_test(NAME AzureRender.FogVolumeGpu COMMAND AzureFogVolumeGpuTests "${AZURE_FOG_TEST_SHADER}")
    set_tests_properties(AzureRender.FogVolumeGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    target_link_libraries(AzureUnlitTextureLayersTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.UnlitTextureLayers COMMAND AzureUnlitTextureLayersTests)
    add_executable(AzureUnlitTextureMaterialTests tests/UnlitTextureMaterialTests.cpp)
    target_link_libraries(AzureUnlitTextureMaterialTests PRIVATE AzureRuntime)
    add_test(NAME AzureRender.UnlitTextureMaterial COMMAND AzureUnlitTextureMaterialTests
        "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/third_person/material_fixture.gltf")
    add_executable(AzureTextureFilteringTests tests/TextureFilteringTests.cpp)
    add_executable(AzureTextureMipCoverageTests tests/TextureMipCoverageTests.cpp)
    target_include_directories(AzureTextureMipCoverageTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.TextureMipCoverage COMMAND AzureTextureMipCoverageTests)
    add_test(NAME AzureRender.AlphaMipCoverageGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_alpha_mip_coverage_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.AlphaMipCoverageGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_executable(AzureSampledTextureCacheTests tests/SampledTextureCacheTests.cpp src/render/SampledTextureCache.cpp src/rhi/NullRhi.cpp)
    target_include_directories(AzureSampledTextureCacheTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureSampledTextureCacheTests PRIVATE Vulkan::Vulkan)
    add_test(NAME AzureRender.SampledTextureCache COMMAND AzureSampledTextureCacheTests)
    add_executable(AzureMaterialTextureSharingTests tests/MaterialTextureSharingTests.cpp)
    target_link_libraries(AzureMaterialTextureSharingTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureMaterialTextureSharingTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureMaterialTextureSharingTests AzureRenderShaders)
    add_test(NAME AzureRender.MaterialTextureSharing COMMAND AzureMaterialTextureSharingTests "${SHADER_BINARY_DIR}")
    target_include_directories(AzureTextureFilteringTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.TextureFiltering COMMAND AzureTextureFilteringTests)
    add_test(NAME AzureRender.SamplingGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_render_sampling.py"
        --executable "$<TARGET_FILE:AzureRender>" --asset "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/third_person/material_fixture.gltf"
        --output "${CMAKE_CURRENT_BINARY_DIR}/sampling-fixture")
    set_tests_properties(AzureRender.SamplingGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 240)
    add_test(NAME AzureRender.ComponentExposureGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_component_exposure_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.ComponentExposureGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 240)
    add_test(NAME AzureRender.ProjectedHairIntegralGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_hair_integral_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.ProjectedHairIntegralGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.MaterialMotionResponseGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_temporal_coverage_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.MaterialMotionResponseGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.BlendCoverageGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_temporal_alpha_coverage_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --case blend --validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.BlendCoverageGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.BlendFadeCoverageGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_temporal_alpha_coverage_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --case fading --validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.BlendFadeCoverageGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.BlendFadeCycleGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_temporal_alpha_coverage_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --case fade-cycle --validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.BlendFadeCycleGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.CompositeCoverageCompatibilityGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_temporal_alpha_coverage_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --case composite --validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.CompositeCoverageCompatibilityGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.MultisampleMaterialMotionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_temporal_coverage_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --quality multisample --validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.MultisampleMaterialMotionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.MultisampleCameraMotionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_temporal_coverage_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --quality multisample --motion-driver camera --validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.MultisampleCameraMotionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    foreach(coverage_case mask cloth blend fading fade-cycle composite)
        add_test(NAME AzureRender.MultisampleCoverage-${coverage_case}Gpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_temporal_alpha_coverage_gpu.py"
            --executable "$<TARGET_FILE:AzurePlayer>" --quality multisample --case "${coverage_case}" --validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
        set_tests_properties(AzureRender.MultisampleCoverage-${coverage_case}Gpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    endforeach()
    add_test(NAME AzureRender.MultisampleOutlineProjectionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_outline_projection_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --quality multisample --validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.MultisampleOutlineProjectionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.MultisampleScreenRimGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_screen_rim_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --quality multisample --case edge --case interior --case near-depth --case mid-depth --case far-depth --case fixed --case material-depth
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.MultisampleScreenRimGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.MultisampleScreenRimGpu.Modulation COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_screen_rim_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --quality multisample --case zero-offset --case zero-tint --case spot --case disabled --case effect-disabled --case no-receiver --case parallel --case blend --case rim-isolation --case smooth
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.MultisampleScreenRimGpu.Modulation PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.MultisampleScreenRimGpu.Physical COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_screen_rim_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --quality multisample --case pbr --case pbr-control --case pbr-specular --case pbr-material --case pbr-material-control
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.MultisampleScreenRimGpu.Physical PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.MultisampleScreenRimGpu.Facing COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_screen_rim_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --quality multisample --case material-facing --case material-facing-fixed --case material-facing-near-depth --case material-facing-far-depth --case material-facing-front --case material-facing-disabled --case material-facing-effect-disabled --case material-facing-no-receiver --case material-facing-generic
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.MultisampleScreenRimGpu.Facing PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureRender.MultisampleRefractionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_scene_refraction_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --quality multisample --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.MultisampleRefractionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 300)
    add_test(NAME AzureRender.CoverageDetailMetrics COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_temporal_coverage_metrics.py")
    add_test(NAME AzureRender.SpatialAntiAliasingGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_spatial_antialiasing_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>")
    add_test(NAME AzureRender.SpatialAntiAliasingAuxiliaryGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_spatial_antialiasing_gpu.py"
        --executable "$<TARGET_FILE:AzureRender>" --auxiliary)
    set_tests_properties(AzureRender.SpatialAntiAliasingGpu AzureRender.SpatialAntiAliasingAuxiliaryGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 240)
    add_test(NAME AzureRender.SpatialAntiAliasingTransferGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_spatial_antialiasing_transfer_gpu.py"
        --executable "$<TARGET_FILE:AzureRender>")
    set_tests_properties(AzureRender.SpatialAntiAliasingTransferGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_test(NAME AzureRender.ColorGradingLutProduction COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_color_grading_lut_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.ColorGradingLutProduction PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 240)
    if(WIN32)
        add_test(NAME AzureRender.ColorGradingLutEditor COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_color_grading_lut_editor_gpu.py"
            --executable "$<TARGET_FILE:AzureRender>" --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
        set_tests_properties(AzureRender.ColorGradingLutEditor PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 240)
        add_test(NAME AzureRender.SamplingHostGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_render_sampling_host.py"
            --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/sampling-host")
        set_tests_properties(AzureRender.SamplingHostGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 240)
    endif()
    add_test(NAME AzureRender.CharacterRepair COMMAND AzureCharacterRepairTests
        "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/third_person/material_fixture.gltf")
    add_executable(AzureOutlineProjectionTests tests/OutlineProjectionTests.cpp)
    add_executable(AzureTemporalViewStateTests tests/TemporalViewStateTests.cpp)
    add_executable(AzureMotionPoseDataTests tests/MotionPoseDataTests.cpp)
    add_executable(AzureTransparentTopologyTests tests/TransparentTopologyTests.cpp)
    target_link_libraries(AzureTransparentTopologyTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.TransparentTopology COMMAND AzureTransparentTopologyTests)
    add_executable(AzureTemporalReconstructionTests tests/TemporalReconstructionTests.cpp)
    target_link_libraries(AzureTemporalReconstructionTests PRIVATE AzureRenderCore)
    add_dependencies(AzureTemporalReconstructionTests AzureRenderShaders)
    add_test(NAME AzureRender.TemporalReconstruction COMMAND AzureTemporalReconstructionTests "${SHADER_BINARY_DIR}")
    add_executable(AzureSharedMotionGpuTests tests/SharedMotionGpuTests.cpp)
    target_link_libraries(AzureSharedMotionGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureSharedMotionGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.SharedMotionGpu COMMAND AzureSharedMotionGpuTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.SharedMotionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureMultisampleViewGpuTests tests/MultisampleViewGpuTests.cpp)
    target_link_libraries(AzureMultisampleViewGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureMultisampleViewGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.MultisampleViewsGpu COMMAND AzureMultisampleViewGpuTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.MultisampleViewsGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120 SKIP_RETURN_CODE 77)
    add_executable(AzureMultisampleViewTests tests/MultisampleViewTests.cpp)
    target_link_libraries(AzureMultisampleViewTests PRIVATE AzureRenderCore)
    add_dependencies(AzureMultisampleViewTests AzureRenderShaders)
    add_test(NAME AzureRender.MultisampleViews COMMAND AzureMultisampleViewTests "${SHADER_BINARY_DIR}")
    add_executable(AzureTemporalSettingsTests tests/TemporalSettingsTests.cpp)
    add_executable(AzureMotionVectorTargetTests tests/MotionVectorTargetTests.cpp)
    add_executable(AzureMotionRecordingTests tests/MotionRecordingTests.cpp)
    target_link_libraries(AzureMotionRecordingTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureMotionRecordingTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureMotionRecordingTests AzureRenderShaders)
    add_test(NAME AzureRender.MotionRecording COMMAND AzureMotionRecordingTests "${SHADER_BINARY_DIR}")
    if(MSVC)
        foreach(motion_test AzureMotionRecordingTests AzureMotionVectorGpuTests AzureSharedMotionGpuTests)
            target_link_options(${motion_test} PRIVATE "$<$<CONFIG:Debug>:/INCREMENTAL:NO>")
        endforeach()
    endif()
    target_link_libraries(AzureMotionVectorTargetTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.MotionVectorTarget COMMAND AzureMotionVectorTargetTests)
    target_link_libraries(AzureTemporalSettingsTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.TemporalSettings COMMAND AzureTemporalSettingsTests)
    add_executable(AzureReadOnlyDepthContractTests tests/ReadOnlyDepthContractTests.cpp)
    target_link_libraries(AzureReadOnlyDepthContractTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ReadOnlyDepthContract COMMAND AzureReadOnlyDepthContractTests)
    target_link_libraries(AzureMotionPoseDataTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.MotionPoseData COMMAND AzureMotionPoseDataTests)
    add_executable(AzureRenderViewSubmissionTests tests/RenderViewSubmissionTests.cpp)
    target_link_libraries(AzureRenderViewSubmissionTests PRIVATE AzureRenderCore)
    add_dependencies(AzureRenderViewSubmissionTests AzureRenderShaders)
    add_test(NAME AzureRender.RenderViewSubmission COMMAND AzureRenderViewSubmissionTests "${SHADER_BINARY_DIR}")
    target_link_libraries(AzureTemporalViewStateTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.TemporalViewState COMMAND AzureTemporalViewStateTests)
    target_link_libraries(AzureOutlineProjectionTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.OutlineProjection COMMAND AzureOutlineProjectionTests)
    find_program(AZURE_NODE_EXECUTABLE node)
    if(AZURE_NODE_EXECUTABLE)
        add_test(NAME AzureRender.SurfaceConversion COMMAND "${AZURE_NODE_EXECUTABLE}"
            "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_surface_conversion.js")
    endif()
    target_link_libraries(AzureEngineSettingsTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.SettingsOverlay COMMAND AzureEngineSettingsTests)
    add_executable(AzureSettingRegistryTests tests/SettingRegistryTests.cpp)
    target_link_libraries(AzureSettingRegistryTests PRIVATE AzureFoundation)
    add_test(NAME AzureEngine.SettingRegistry COMMAND AzureSettingRegistryTests)
    add_executable(AzureUiFoundationTests tests/UiFoundationTests.cpp)
    target_link_libraries(AzureUiFoundationTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.UiFoundation COMMAND AzureUiFoundationTests)
    add_executable(AzureConsoleLogModelTests tests/ConsoleLogModelTests.cpp)
    target_link_libraries(AzureConsoleLogModelTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.ConsoleLogModel COMMAND AzureConsoleLogModelTests)
    add_executable(AzurePanelContextTests tests/PanelContextTests.cpp)
    target_link_libraries(AzurePanelContextTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.PanelContext COMMAND AzurePanelContextTests)
    find_package(Python3 COMPONENTS Interpreter REQUIRED)
    add_executable(AzureRenderViewTests tests/RenderViewTests.cpp)
    target_link_libraries(AzureRenderViewTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.RenderView COMMAND AzureRenderViewTests "${SHADER_BINARY_DIR}")
    add_dependencies(AzureRenderViewTests AzureRenderShaders)
    add_executable(AzureThumbnailTests tests/ThumbnailTests.cpp)
    target_link_libraries(AzureThumbnailTests PRIVATE AzureEditor)
    add_dependencies(AzureThumbnailTests AzureRenderShaders)
    add_test(NAME AzureEditor.Thumbnail COMMAND AzureThumbnailTests "${SHADER_BINARY_DIR}")
    add_executable(AzureHotReloadTests tests/HotReloadTests.cpp)
    target_link_libraries(AzureHotReloadTests PRIVATE AzureDevtools)
    add_executable(AzureShaderCompilerContractTests tests/ShaderCompilerContractTests.cpp)
    target_link_libraries(AzureShaderCompilerContractTests PRIVATE AzureDevtools)
    if(WIN32 AND AZURE_DXC_EXECUTABLE)
        add_dependencies(AzureShaderCompilerContractTests AzureProjectedReflectionShaders)
        add_test(NAME AzureRender.ShaderCompilerContract COMMAND "${Python3_EXECUTABLE}"
            "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_shader_compiler_contract.py"
            --executable "$<TARGET_FILE:AzureShaderCompilerContractTests>"
            --config "${CMAKE_CURRENT_BINARY_DIR}/shader-reload.json" --dxc "${AZURE_DXC_EXECUTABLE}")
        set_tests_properties(AzureRender.ShaderCompilerContract PROPERTIES TIMEOUT 120 RUN_SERIAL TRUE)
        add_test(NAME AzureRender.ShaderCatalogCompilation COMMAND "${Python3_EXECUTABLE}"
            "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_shader_catalog.py"
            --executable "$<TARGET_FILE:AzureShaderCompilerContractTests>"
            --config "${CMAKE_CURRENT_BINARY_DIR}/shader-reload.json")
        set_tests_properties(AzureRender.ShaderCatalogCompilation PROPERTIES TIMEOUT 120 RUN_SERIAL TRUE)
    endif()
    if(WIN32)
        add_test(NAME AzureRender.HotReload COMMAND AzureHotReloadTests
            "$<TARGET_FILE:Vulkan::glslc>" "${CMAKE_CURRENT_BINARY_DIR}/hot-reload-tests")
        add_executable(AzureProcessRunnerTests tests/ProcessRunnerTests.cpp)
        target_link_libraries(AzureProcessRunnerTests PRIVATE AzurePlatform)
        add_test(NAME AzurePlatform.ProcessRunner COMMAND AzureProcessRunnerTests)
        add_test(NAME AzureRender.PreviewHost COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_render_preview_host.py" --executable "$<TARGET_FILE:AzureRender>")
        set_tests_properties(AzureRender.PreviewHost PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 420)
        add_test(NAME AzureEditor.SelectionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_selection.py"
            --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/u6-selection")
        set_tests_properties(AzureEditor.SelectionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 420)
        add_test(NAME AzureEditor.GizmoGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_gizmo.py"
            --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/u6-gizmo")
        set_tests_properties(AzureEditor.GizmoGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 420)
        add_test(NAME AzureEditor.DevtoolsHost COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_devtools_host.py"
            --executable "$<TARGET_FILE:AzureRender>" --shader-config "${CMAKE_BINARY_DIR}/shader-reload.json")
        set_tests_properties(AzureEditor.DevtoolsHost PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 420)
        add_test(NAME AzureEditor.ShaderReloadHost COMMAND "${Python3_EXECUTABLE}"
            "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_shader_reload_host.py"
            --executable "$<TARGET_FILE:AzureRender>"
            --config "${CMAKE_BINARY_DIR}/shader-reload.json")
        set_tests_properties(AzureEditor.ShaderReloadHost PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 420)
    endif()
    add_executable(AzureModelProtocolTests tests/ModelProtocolTests.cpp)
    target_link_libraries(AzureModelProtocolTests PRIVATE AzureAI)
    add_test(NAME AzureAI.ModelProtocol COMMAND AzureModelProtocolTests
        "${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures/ai/protocol.json" "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/ai_bridge.py")
    add_test(NAME AzureAI.Bridge COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_ai_bridge.py")
    if(WIN32)
        add_test(NAME AzureEditor.ProposalHost COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_proposal_host.py" --executable "$<TARGET_FILE:AzureRender>")
        set_tests_properties(AzureEditor.ProposalHost PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 420)
    endif()
    add_executable(AzureProposalControllerTests tests/ProposalControllerTests.cpp)
    target_link_libraries(AzureProposalControllerTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.ProposalController COMMAND AzureProposalControllerTests)
    add_executable(AzureProposalAdapterTests tests/ProposalAdapterTests.cpp)
    target_link_libraries(AzureProposalAdapterTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.ProposalAdapter COMMAND AzureProposalAdapterTests
        "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/gameplay" "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/scene_inspector")
    add_executable(AzureEditorObservationTests tests/EditorObservationTests.cpp)
    target_link_libraries(AzureEditorObservationTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.Observation COMMAND AzureEditorObservationTests)
    add_test(NAME AzureTools.Cli COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_azure_cli.py")
    if(WIN32)
        add_test(NAME AzureAssets.ProceduralHost COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_procedural_host.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/procedural-host")
        set_tests_properties(AzureAssets.ProceduralHost PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
        add_test(NAME AzureEditor.SettingsHost COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_settings_host.py" --executable "$<TARGET_FILE:AzureRender>")
        set_tests_properties(AzureEditor.SettingsHost PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 300)
    endif()
    add_test(NAME AzureEditor.ObservationHost COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_observation_host.py" --executable "$<TARGET_FILE:AzureRender>")
    set_tests_properties(AzureEditor.ObservationHost PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 240)
    add_executable(AzureGenerationManifestTests tests/GenerationManifestTests.cpp)
    target_link_libraries(AzureGenerationManifestTests PRIVATE AzureRuntime)
    add_test(NAME AzureAssets.GenerationManifest COMMAND AzureGenerationManifestTests)
    add_executable(AzureValidationProbe tests/ValidationProbe.cpp)
    target_link_libraries(AzureValidationProbe PRIVATE AzureValidation)
    add_test(NAME AzureTools.ValidationProtocol COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_validation_protocol.py" --probe "$<TARGET_FILE:AzureValidationProbe>")
    add_executable(AzureObservationTests tests/ObservationTests.cpp)
    target_link_libraries(AzureObservationTests PRIVATE AzureValidation)
    add_test(NAME AzureEngine.Observation COMMAND AzureObservationTests)
    add_executable(AzureEditServiceTests tests/EditServiceTests.cpp)
    target_link_libraries(AzureEditServiceTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.EditService COMMAND AzureEditServiceTests)
    add_executable(AzureEditTransactionTests tests/EditTransactionTests.cpp)
    target_link_libraries(AzureEditTransactionTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.EditTransaction COMMAND AzureEditTransactionTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/gameplay")
    add_executable(AzureSystemCompositionTests tests/SystemCompositionTests.cpp)
    target_link_libraries(AzureSystemCompositionTests PRIVATE AzureProjectRuntime)
    target_compile_definitions(AzureSystemCompositionTests PRIVATE AZURE_INSPECTOR_PROJECT="${CMAKE_CURRENT_SOURCE_DIR}/assets_public/scene_inspector")
    add_test(NAME AzureEngine.SystemComposition COMMAND AzureSystemCompositionTests)
    find_package(Python3 COMPONENTS Interpreter REQUIRED)
    add_test(NAME AzureEngine.SceneInspectorHost COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_scene_inspector_host.py"
        --editor $<TARGET_FILE:AzureRender> --player $<TARGET_FILE:AzurePlayer>
        --project "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/scene_inspector/project.azureproject")
    set_tests_properties(AzureEngine.SceneInspectorHost PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 180)
    add_executable(AzureModuleAssemblyTests tests/ModuleAssemblyTests.cpp)
    target_link_libraries(AzureModuleAssemblyTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.ModuleAssembly COMMAND AzureModuleAssemblyTests)
    add_executable(AzureComponentRegistryTests tests/ComponentRegistryTests.cpp)
    target_link_libraries(AzureComponentRegistryTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.ComponentRegistry COMMAND AzureComponentRegistryTests)
    set(AZURE_TOOL_METADATA "${AZURE_GENERATED_DIR}/fixtures/GeneratedToolRegistry.hpp")
    add_custom_command(OUTPUT "${AZURE_TOOL_METADATA}"
        COMMAND AzureMetaGen "${AZURE_TOOL_METADATA}" tests/MetadataFixture.hpp
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}"
        DEPENDS AzureMetaGen tests/MetadataFixture.hpp VERBATIM)
    add_executable(AzureMetadataGenerationTests tests/MetadataGenerationTests.cpp "${AZURE_TOOL_METADATA}")
    target_include_directories(AzureMetadataGenerationTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}")
    target_link_libraries(AzureMetadataGenerationTests PRIVATE AzureReflection)
    add_test(NAME AzureEngine.MetadataGeneration COMMAND AzureMetadataGenerationTests)
    add_executable(AzureRegisteredComponentWorkflowTests tests/RegisteredComponentWorkflowTests.cpp)
    target_link_libraries(AzureRegisteredComponentWorkflowTests PRIVATE AzureEditor)
    add_test(NAME AzureEngine.RegisteredComponentWorkflow COMMAND AzureRegisteredComponentWorkflowTests)
    add_executable(AzureObjectShadowTests tests/ObjectShadowTests.cpp)
    target_link_libraries(AzureObjectShadowTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ObjectShadow COMMAND AzureObjectShadowTests)
    add_executable(AzureObjectShadowAtlasTests tests/ObjectShadowAtlasTests.cpp)
    target_link_libraries(AzureObjectShadowAtlasTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ObjectShadowAtlas COMMAND AzureObjectShadowAtlasTests)
    add_executable(AzureObjectShadowRecordingTests tests/ObjectShadowRecordingTests.cpp)
    target_link_libraries(AzureObjectShadowRecordingTests PRIVATE AzureRenderCore)
    target_compile_definitions(AzureObjectShadowRecordingTests PRIVATE AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_dependencies(AzureObjectShadowRecordingTests AzureRenderShaders)
    add_test(NAME AzureRender.ObjectShadowRecording COMMAND AzureObjectShadowRecordingTests "${SHADER_BINARY_DIR}")
    add_executable(AzureObjectShadowDocumentTests tests/ObjectShadowDocumentTests.cpp)
    target_link_libraries(AzureObjectShadowDocumentTests PRIVATE AzureEditor)
    add_test(NAME AzureEngine.ObjectShadowDocument COMMAND AzureObjectShadowDocumentTests)
    add_executable(AzureRegisteredComponentHost src/main.cpp tests/RegisterHostExtension.cpp)
    target_link_libraries(AzureRegisteredComponentHost PRIVATE AzureRenderHost)
    add_dependencies(AzureRegisteredComponentHost AzureRenderShaders)
    add_test(NAME AzureEngine.RegisteredComponentHost COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_registered_component_host.py"
        --executable $<TARGET_FILE:AzureRegisteredComponentHost>
        --project "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/gameplay/project.azureproject")
    set_tests_properties(AzureEngine.RegisteredComponentHost PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_test(NAME AzureEngine.ModuleBoundaryFixtures COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_module_boundaries.py")
    add_test(NAME AzureEngine.ModuleBoundaries COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/check_module_boundaries.py"
        --source "${CMAKE_CURRENT_SOURCE_DIR}" --build-dir "${CMAKE_CURRENT_BINARY_DIR}")
    add_executable(AzureGameUiRendererTests tests/GameUiRendererTests.cpp)
    target_link_libraries(AzureGameUiRendererTests PRIVATE AzureRenderCore RmlUi::RmlUi)
    add_dependencies(AzureGameUiRendererTests AzureRenderShaders)
    add_test(NAME AzureEngine.GameUiRenderer COMMAND AzureGameUiRendererTests "${SHADER_BINARY_DIR}")
    add_executable(AzureGameUiTests tests/GameUiTests.cpp)
    target_link_libraries(AzureGameUiTests PRIVATE AzureRuntime RmlUi::RmlUi)
    add_test(NAME AzureEngine.GameUi COMMAND AzureGameUiTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/gameplay/assets/hud.rml" "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/fonts/LatoLatin-Regular.ttf")
    add_executable(AzureEditorWorkspaceTests tests/EditorWorkspaceTests.cpp)
    target_link_libraries(AzureEditorWorkspaceTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.Workspace COMMAND AzureEditorWorkspaceTests)
    add_executable(AzureEditorWorkflowTests tests/EditorWorkflowTests.cpp)
    target_link_libraries(AzureEditorWorkflowTests PRIVATE AzureEditor)
    add_test(NAME AzureEngine.EditorWorkflow COMMAND AzureEditorWorkflowTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/gameplay")
    add_executable(AzurePresentationRuntimeTests tests/PresentationRuntimeTests.cpp)
    target_link_libraries(AzurePresentationRuntimeTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.PresentationRuntime COMMAND AzurePresentationRuntimeTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/gameplay/project.azureproject")
    add_executable(AzureGameplayPresentationTests tests/GameplayPresentationTests.cpp)
    target_link_libraries(AzureGameplayPresentationTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.GameplayPresentation COMMAND AzureGameplayPresentationTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/gameplay/assets/portal.wav")
    add_executable(AzureScriptRuntimeTests tests/ScriptRuntimeTests.cpp)
    add_executable(AzureResourceFrameTraceTests tests/ResourceFrameTraceTests.cpp)
    target_link_libraries(AzureResourceFrameTraceTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.ResourceFrameTrace COMMAND AzureResourceFrameTraceTests)
    add_executable(AzureScriptBackendContractTests tests/ScriptBackendContractTests.cpp)
    target_link_libraries(AzureScriptBackendContractTests PRIVATE AzureProjectRuntime)
    add_test(NAME AzureEngine.ScriptBackendContract COMMAND AzureScriptBackendContractTests)
    add_executable(AzureScriptInteropTests tests/ScriptInteropTests.cpp)
    target_link_libraries(AzureScriptInteropTests PRIVATE AzureProjectRuntime)
    add_test(NAME AzureEngine.ScriptInterop COMMAND AzureScriptInteropTests)
    if(AZURE_ENABLE_MANAGED_SCRIPT_PROTOTYPE)
        add_executable(AzureManagedModuleTests tests/ManagedModuleTests.cpp)
        target_link_libraries(AzureManagedModuleTests PRIVATE AzureProjectRuntime AzureManagedScripting)
        foreach(AZURE_BACKEND coreclr nativeaot)
            add_test(NAME AzureEngine.ManagedModule.${AZURE_BACKEND} COMMAND AzureManagedModuleTests "${AZURE_BACKEND}" "${AZURE_MANAGED_OUTPUT}/${AZURE_BACKEND}")
        endforeach()
        add_executable(AzureManagedScriptRuntimeTests tests/ManagedScriptRuntimeTests.cpp)
        target_link_libraries(AzureManagedScriptRuntimeTests PRIVATE AzureProjectRuntime)
        foreach(AZURE_BACKEND coreclr nativeaot)
            add_test(NAME AzureEngine.ManagedRuntime.${AZURE_BACKEND} COMMAND AzureManagedScriptRuntimeTests "${AZURE_BACKEND}" "${AZURE_MANAGED_OUTPUT}/${AZURE_BACKEND}")
        endforeach()
        add_test(NAME AzureEngine.ScriptBackendParity.lua COMMAND AzureManagedScriptRuntimeTests lua "${AZURE_MANAGED_OUTPUT}/coreclr")
        foreach(AZURE_BACKEND coreclr nativeaot)
            add_test(NAME AzureEngine.ManagedWorkflows.${AZURE_BACKEND} COMMAND "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_managed_workflows.py" --build-dir "${CMAKE_BINARY_DIR}"
                --backend "${AZURE_BACKEND}" --configuration "$<CONFIG>" --evidence "${CMAKE_BINARY_DIR}/managed-workflows/${AZURE_BACKEND}")
            set_tests_properties(AzureEngine.ManagedWorkflows.${AZURE_BACKEND} PROPERTIES LABELS "gpu;script" RUN_SERIAL TRUE TIMEOUT 600)
        endforeach()
    endif()
    target_link_libraries(AzureScriptRuntimeTests PRIVATE AzureProjectRuntime)
    add_test(NAME AzureEngine.ScriptRuntime COMMAND AzureScriptRuntimeTests)
    add_executable(AzurePhysicsInputTests tests/PhysicsInputTests.cpp)
    add_executable(AzureThirdPersonTests tests/ThirdPersonTests.cpp)
    target_link_libraries(AzureThirdPersonTests PRIVATE AzureProjectRuntime)
    add_test(NAME AzureEngine.ThirdPerson COMMAND AzureThirdPersonTests)
    add_executable(AzureLocomotionTests tests/LocomotionTests.cpp)
    target_link_libraries(AzureLocomotionTests PRIVATE AzureProjectRuntime)
    add_test(NAME AzureEngine.Locomotion COMMAND AzureLocomotionTests)
    add_executable(AzureInteractionTests tests/InteractionTests.cpp)
    target_link_libraries(AzureInteractionTests PRIVATE AzureProjectRuntime)
    add_test(NAME AzureEngine.Interaction COMMAND AzureInteractionTests)
    add_executable(AzureScriptEntityTests tests/ScriptEntityTests.cpp)
    target_link_libraries(AzureScriptEntityTests PRIVATE AzureProjectRuntime)
    add_test(NAME AzureEngine.ScriptEntities COMMAND AzureScriptEntityTests)
    add_executable(AzurePlayableQuestTests tests/PlayableQuestTests.cpp)
    target_link_libraries(AzurePlayableQuestTests PRIVATE AzureProjectRuntime)
    target_compile_definitions(AzurePlayableQuestTests PRIVATE AZURE_QUEST_PROJECT="${CMAKE_CURRENT_SOURCE_DIR}/assets_public/exploration")
    add_test(NAME AzureEngine.PlayableQuest COMMAND AzurePlayableQuestTests)
    add_executable(AzureBrowRegionTests tests/BrowRegionTests.cpp)
    add_executable(AzureLocomotionBlendTests tests/LocomotionBlendTests.cpp)
    target_include_directories(AzureLocomotionBlendTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureLocomotionBlendTests PRIVATE nlohmann_json::nlohmann_json)
    add_test(NAME AzureEngine.LocomotionBlend COMMAND AzureLocomotionBlendTests)

    add_executable(AzureAnimationPoseTests tests/AnimationPoseTests.cpp)
    target_include_directories(AzureAnimationPoseTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureAnimationPoseTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.AnimationPose COMMAND AzureAnimationPoseTests)
    add_executable(AzureNodeOpacityTests tests/NodeOpacityTests.cpp)
    target_include_directories(AzureNodeOpacityTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureNodeOpacityTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.NodeOpacity COMMAND AzureNodeOpacityTests)
    add_executable(AzureMorphTargetTests tests/MorphTargetTests.cpp)
    target_link_libraries(AzureMorphTargetTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.MorphTargets COMMAND AzureMorphTargetTests)
    add_executable(AzureStableDepthOrderTests tests/StableDepthOrderTests.cpp)
    target_include_directories(AzureStableDepthOrderTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.StableDepthOrder COMMAND AzureStableDepthOrderTests)
    add_executable(AzureAnimationCurveTests tests/AnimationCurveTests.cpp)
    target_include_directories(AzureAnimationCurveTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.AnimationCurve COMMAND AzureAnimationCurveTests)
    add_executable(AzureExpressionPoseTests tests/ExpressionPoseTests.cpp)
    target_link_libraries(AzureExpressionPoseTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ExpressionPose COMMAND AzureExpressionPoseTests)
    add_executable(AzureSceneImportTests tests/SceneImportTests.cpp)
    target_link_libraries(AzureSceneImportTests PRIVATE AzureEditor)
    add_test(NAME AzureAssets.SceneImport COMMAND AzureSceneImportTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/resource_validation/mechanical_panel.gltf")
    add_test(NAME AzureEditor.SceneImportWorkflow COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_scene_import_workflow.py" --executable "$<TARGET_FILE:AzureSceneImportTests>")
    target_include_directories(AzureBrowRegionTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureBrowRegionTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.BrowRegions COMMAND AzureBrowRegionTests)
    target_link_libraries(AzurePhysicsInputTests PRIVATE AzureProjectRuntime)
    add_test(NAME AzureEngine.PhysicsInput COMMAND AzurePhysicsInputTests)
    add_executable(AzureAssetLevelTests tests/AssetLevelTests.cpp)
    add_executable(AzureAssetSourceCacheTests tests/AssetSourceCacheTests.cpp)
    target_link_libraries(AzureAssetSourceCacheTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.AssetSourceCache COMMAND AzureAssetSourceCacheTests)
    target_link_libraries(AzureAssetLevelTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.AssetLevel COMMAND AzureAssetLevelTests)
    add_executable(AzureProjectStartupTests tests/ProjectStartupTests.cpp)
    target_link_libraries(AzureProjectStartupTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.ProjectStartup COMMAND AzureProjectStartupTests)
    add_executable(AzureLevelRefreshRetirementTests tests/LevelRefreshRetirementTests.cpp)
    target_link_libraries(AzureLevelRefreshRetirementTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.LevelRefreshRetirement COMMAND AzureLevelRefreshRetirementTests)
    set_tests_properties(AzureEngine.LevelRefreshRetirement PROPERTIES TIMEOUT 30)
    add_executable(AzureAssetDependencyIndexTests tests/AssetDependencyIndexTests.cpp)
    target_link_libraries(AzureAssetDependencyIndexTests PRIVATE AzureRuntime)
    if(WIN32)
        target_link_libraries(AzureAssetDependencyIndexTests PRIVATE Psapi)
    endif()
    add_test(NAME AzureEngine.AssetDependencyIndex COMMAND AzureAssetDependencyIndexTests
        "${CMAKE_CURRENT_SOURCE_DIR}/build/runs/asset-dependency-index-tests")
    add_test(NAME AzureEngine.AssetDependencyIndex.Contracts COMMAND AzureAssetDependencyIndexTests
        --contracts-only "${CMAKE_CURRENT_SOURCE_DIR}/build/runs/asset-dependency-index-tests")
    add_executable(AzureReflectionTests tests/ReflectionTests.cpp)
    target_link_libraries(AzureReflectionTests PRIVATE AzureReflection)
    add_test(NAME AzureEngine.Reflection COMMAND AzureReflectionTests)
    add_executable(AzureSceneVisibilityTests tests/SceneVisibilityTests.cpp)
    target_link_libraries(AzureSceneVisibilityTests PRIVATE AzureRuntime)
    add_test(NAME AzureRender.SceneVisibility COMMAND AzureSceneVisibilityTests
        "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/exploration/assets/cube.gltf")
    find_package(Python3 COMPONENTS Interpreter REQUIRED)
    add_test(NAME AzureEngine.RepositoryAudit COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_repository_audit.py")
    add_test(NAME AzureRender.SceneVisibilityGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_scene_visibility_gpu.py" --executable "$<TARGET_FILE:AzurePlayer>")
    set_tests_properties(AzureRender.SceneVisibilityGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 300)
    add_test(NAME AzureEngine.PublicGait COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_public_gait.py")
    add_test(NAME AzureEngine.LocomotionPlayer COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_locomotion_direction.py" --player "$<TARGET_FILE:AzurePlayer>")
    set_tests_properties(AzureEngine.LocomotionPlayer PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 300)
    add_test(NAME AzureEngine.LocomotionBlendGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/native_render/locomotion_blend_lab.py" --player "$<TARGET_FILE:AzurePlayer>")
    set_tests_properties(AzureEngine.LocomotionBlendGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 360)
    add_test(NAME AzureEngine.AnimationRetarget COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_animation_retarget.py")
    add_test(NAME AzureEngine.SourceSkinRestore COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_skin_restore.py")
    add_test(NAME AzureEngine.GamePackageRules COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_game_package_rules.py")
    add_test(NAME AzureEngine.PlayableDeliveryRules COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_playable_delivery_rules.py")
    include("${CMAKE_CURRENT_SOURCE_DIR}/tools/register_game_package.cmake")
    azure_register_game_package()
    add_test(NAME AzureEngine.BuildConfiguration COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_build_configuration.py")
    if(WIN32)
        add_test(NAME AzureTools.ManagedWorkflowCleanup COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_managed_workflow_cleanup.py")
    endif()
    add_test(NAME AzureTools.ShaderArithmeticOrder COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_shader_arithmetic_order.py")
    set_tests_properties(AzureTools.ShaderArithmeticOrder PROPERTIES TIMEOUT 30)
    add_test(NAME AzureEngine.BuildProvenance COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_build_provenance.py")
    if(WIN32)
        add_test(NAME AzureTools.NativeWindow COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_native_window.py")
    endif()
    add_test(NAME AzureEngine.CharacterIntake COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_intake.py")
    add_test(NAME AzureEngine.CharacterPreparation COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_preparation.py")
    if(WIN32)
        add_test(NAME AzureEditor.WorkspaceGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_workspace.py" --executable $<TARGET_FILE:AzureRender>)
        set_tests_properties(AzureEditor.WorkspaceGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    endif()
    add_test(NAME AzureEngine.MaterialFixtureGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_fixture.py" --executable $<TARGET_FILE:AzureRender> --asset "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/third_person/material_fixture.gltf")
    add_test(NAME AzureEngine.IndependentAnimationGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_independent_animation_gpu.py" --executable $<TARGET_FILE:AzurePlayer>)
    add_test(NAME AzureEngine.NodeOpacityGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_node_opacity_gpu.py" --executable $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.NodeOpacityGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.MaterialShadowCoverageGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_shadow_coverage_gpu.py" --executable $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.MaterialShadowCoverageGpu PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.SilhouetteCoverageGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_silhouette_coverage_gpu.py" --executable $<TARGET_FILE:AzurePlayer> --run)
    set_tests_properties(AzureEngine.SilhouetteCoverageGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.UnlitSurfaceGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_unlit_surface_gpu.py" --executable $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.UnlitSurfaceGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.MaterialRadianceGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_radiance_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.MaterialRadianceGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.MaterialLightingGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_lighting_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.MaterialLightingGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.NprRampCompositionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_npr_ramp_composition_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.NprRampCompositionGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.MaterialDisplayGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_display_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.MaterialDisplayGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.UnlitTextureLayersGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_unlit_texture_layers_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.UnlitTextureLayersGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.MaterialOverlaysGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_overlays_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.MaterialOverlaysGpu PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.BlendDepthGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_blend_depth_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.BlendDepthGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.OpaqueSurfaceOverlaysGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_opaque_surface_overlays_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.OpaqueSurfaceOverlaysGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.OpaqueSurfaceOverlaysMsaaGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_opaque_surface_overlays_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --anti-aliasing 4 --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.OpaqueSurfaceOverlaysMsaaGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.FaceMaskedRimGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_face_masked_rim_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.FaceMaskedRimGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.FaceMaskedRimMsaaGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_face_masked_rim_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --anti-aliasing 4 --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.FaceMaskedRimMsaaGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.ViewFogGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_view_fog_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.ViewFogGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.SceneFogGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_scene_fog_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.SceneFogGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.ViewFogMultisampleGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_view_fog_msaa_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.ViewFogMultisampleGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.VertexColorGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_vertex_color_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.VertexColorGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.UnlitViewCoverageGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_vertex_color_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --case view-coverage --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.UnlitViewCoverageGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.UnlitCoverageLayerGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_vertex_color_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --case coverage-layer --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.UnlitCoverageLayerGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.UnlitUvDistortionGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_vertex_color_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --case uv-distortion --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.UnlitUvDistortionGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.SceneRefractionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_scene_refraction_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.SceneRefractionGpu PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.DualFaceSdfGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_dual_face_sdf_gpu.py" --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.DualFaceSdfGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.SceneCharacterGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_scene_character_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.SceneCharacterGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.CharacterProbeGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_probe_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.CharacterProbeGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.EyeSurfaceGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_eye_surface_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer>
        --fixtures "${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures/eye_radial_surface"
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.EyeSurfaceGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.EyeNprGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_eye_npr_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.EyeNprGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.ProjectedSurfaceGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_surface_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer>)
    add_test(NAME AzureEngine.ProjectedSurfaceMultisampleGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_surface_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --quality multisample)
    add_test(NAME AzureEngine.ProjectedSurfaceSupersampleGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_surface_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --quality supersample)
    set_tests_properties(AzureEngine.ProjectedSurfaceGpu AzureEngine.ProjectedSurfaceMultisampleGpu AzureEngine.ProjectedSurfaceSupersampleGpu PROPERTIES TIMEOUT 600 LABELS gpu RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.OutlineProjectionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_outline_projection_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.OutlineProjectionGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.CubeProbeGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_cube_probe_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.CubeProbeGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.ReflectionLodGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/native_render/reflection_lod_lab.py"
        --player $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.ReflectionLodGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.EnvironmentSpecularGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_environment_specular_gpu.py"
        --group global --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.EnvironmentSpecularGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.EnvironmentSpecularGpu.Local COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_environment_specular_gpu.py"
        --group local --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.EnvironmentSpecularGpu.Local PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.EnvironmentSpecularGpu.Compatibility COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_environment_specular_gpu.py"
        --group compatibility --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.EnvironmentSpecularGpu.Compatibility PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.ScreenSpaceReflectionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_screen_space_reflections_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer>
        --suite extended --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.ScreenSpaceReflectionGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.ProjectedScreenReflectionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_scene_reflections.py"
        --executable $<TARGET_FILE:AzurePlayer>
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.ProjectedScreenReflectionGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureTools.CubemapEnvironment COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_cubemap_environment.py")
    add_test(NAME AzureEngine.ProjectedHairGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_hair_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> $<$<CONFIG:Debug>:--require-validation> COMMAND_EXPAND_LISTS)
    add_test(NAME AzureEngine.ProjectedHairSurfaceGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_hair_surface_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> $<$<CONFIG:Debug>:--require-validation> COMMAND_EXPAND_LISTS)
    set_tests_properties(AzureEngine.ProjectedHairGpu AzureEngine.ProjectedHairSurfaceGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.MaterialCompositeGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_composite_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.MaterialCompositeGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.ThirdPersonPlayer COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_third_person_player.py" --executable $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.IndependentAnimationGpu AzureEngine.ThirdPersonPlayer PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.PlayablePlayer COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_playable_player.py" --executable $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.PlayablePlayer PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.OptionalRuntimeTrace COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_optional_runtime_trace.py" --player $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.OptionalRuntimeTrace PROPERTIES TIMEOUT 180 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.RuntimeSpawnGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_runtime_spawn_gpu.py" --executable $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.RuntimeSpawnGpu PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    set_tests_properties(AzureEngine.MaterialFixtureGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 240)
    add_test(NAME AzureEngine.PresentationGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_game_presentation.py" --executable $<TARGET_FILE:AzurePlayer> --project "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/gameplay/project.azureproject")
    set_tests_properties(AzureEngine.PresentationGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME AzureEngine.EditorHost COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_workflow.py" --executable $<TARGET_FILE:AzureRender> --project "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/gameplay/project.azureproject")
    add_test(NAME AzureEngine.EditorPlayable COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_playable.py" --executable $<TARGET_FILE:AzureRender>)
    set_tests_properties(AzureEngine.EditorPlayable PROPERTIES LABELS "gpu" TIMEOUT 240)
    set_tests_properties(AzureEngine.EditorHost PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_test(NAME AzureEngine.MetaGenerator COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_metagen.py" $<TARGET_FILE:AzureMetaGen>)
    add_test(NAME AzureEngine.LevelPlayer COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_level_player.py" $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.LevelPlayer PROPERTIES LABELS gpu)
    add_test(NAME AzureEngine.PhysicsPlayer COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_physics_player.py" $<TARGET_FILE:AzurePlayer>)
    add_test(NAME AzureEngine.ScriptPlayer COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_script_player.py" $<TARGET_FILE:AzurePlayer> "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/gameplay")
    set_tests_properties(AzureEngine.ScriptPlayer PROPERTIES LABELS gpu)
    set_tests_properties(AzureEngine.PhysicsPlayer PROPERTIES LABELS gpu)
    add_executable(AzureProjectTests tests/ProjectTests.cpp)
    target_link_libraries(AzureProjectTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.Project COMMAND AzureProjectTests)
    add_executable(AzureRuntimeLifecycleTests tests/RuntimeLifecycleTests.cpp)
    target_link_libraries(AzureRuntimeLifecycleTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.RuntimeLifecycle COMMAND AzureRuntimeLifecycleTests)
    add_executable(AzureRuntimeSceneSnapshotCacheTests tests/RuntimeSceneSnapshotCacheTests.cpp)
    add_executable(AzurePreviousTransformSnapshotTests tests/PreviousTransformSnapshotTests.cpp)
    target_link_libraries(AzurePreviousTransformSnapshotTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.PreviousTransformSnapshot COMMAND AzurePreviousTransformSnapshotTests)
    add_executable(AzureSceneTransformCacheTests tests/SceneTransformCacheTests.cpp)
    target_link_libraries(AzureSceneTransformCacheTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.SceneTransformCache COMMAND AzureSceneTransformCacheTests)
    target_link_libraries(AzureRuntimeSceneSnapshotCacheTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.RuntimeSceneSnapshotCache COMMAND AzureRuntimeSceneSnapshotCacheTests)
    add_executable(AzureRuntimeRenderSnapshotCacheTests tests/RuntimeRenderSnapshotCacheTests.cpp)
    target_link_libraries(AzureRuntimeRenderSnapshotCacheTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.RuntimeRenderSnapshotCache COMMAND AzureRuntimeRenderSnapshotCacheTests)
    add_executable(AzureRenderEnvironmentAssetTests tests/EnvironmentAssetTests.cpp src/render/EnvironmentAsset.cpp src/render/EnvironmentCubeTexture.cpp src/rhi/NullRhi.cpp src/assets/image/ImageCodec.cpp
    src/assets/image/TextureContainerAdapter.cpp)
    target_include_directories(AzureRenderEnvironmentAssetTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src" "${STB_INCLUDE_DIR}")
    target_sources(AzureRenderEnvironmentAssetTests PRIVATE src/assets/image/SvgCodec.cpp)
    target_link_libraries(AzureRenderEnvironmentAssetTests PRIVATE pugixml::pugixml Vulkan::Vulkan Microsoft::DirectXTex KTX::ktx OpenEXR::OpenEXR TIFF::TIFF WebP::webp)
    add_test(NAME AzureRender.EnvironmentAsset COMMAND AzureRenderEnvironmentAssetTests)
    add_executable(AzureRenderRenderGraphTests tests/RenderGraphTests.cpp src/render/RenderGraph.cpp src/rhi/NullRhi.cpp)
    target_include_directories(AzureRenderRenderGraphTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureRenderRenderGraphTests PRIVATE Vulkan::Vulkan)
    add_test(NAME AzureRender.RenderGraph COMMAND AzureRenderRenderGraphTests)
    add_executable(AzureRenderTransientResourcePoolTests tests/TransientResourcePoolTests.cpp src/render/TransientResourcePool.cpp src/rhi/NullRhi.cpp)
    target_include_directories(AzureRenderTransientResourcePoolTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureRenderTransientResourcePoolTests PRIVATE Vulkan::Vulkan)
    add_test(NAME AzureRender.TransientResourcePool COMMAND AzureRenderTransientResourcePoolTests)
    add_executable(AzureRenderLightBufferTests tests/LightBufferTests.cpp)
    target_link_libraries(AzureRenderLightBufferTests PRIVATE nlohmann_json::nlohmann_json)
    target_include_directories(AzureRenderLightBufferTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.LightBuffer COMMAND AzureRenderLightBufferTests)
    add_executable(AzureRenderReflectionProbeTests tests/ReflectionProbeTests.cpp)
    target_include_directories(AzureRenderReflectionProbeTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureRenderReflectionProbeTests PRIVATE nlohmann_json::nlohmann_json)
    target_compile_options(AzureRenderReflectionProbeTests PRIVATE
        $<$<CXX_COMPILER_ID:MSVC>:/UNDEBUG>
        $<$<NOT:$<CXX_COMPILER_ID:MSVC>>:-UNDEBUG>)
    add_test(NAME AzureRender.ReflectionProbe COMMAND AzureRenderReflectionProbeTests)
    add_executable(AzureReflectionProbeFieldGpuTests tests/ReflectionProbeFieldGpuTests.cpp)
    target_link_libraries(AzureReflectionProbeFieldGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureReflectionProbeFieldGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ReflectionProbeFieldGpu COMMAND AzureReflectionProbeFieldGpuTests "${SHADER_BINARY_DIR}/reflection_probe_field_test.comp.spv")
    foreach(_mode sphere rotated no-projection adapted priority)
        add_test(NAME AzureRender.ReflectionProbeFieldGpu.${_mode} COMMAND AzureReflectionProbeFieldGpuTests "${SHADER_BINARY_DIR}/reflection_probe_field_test.comp.spv" --${_mode})
        set_tests_properties(AzureRender.ReflectionProbeFieldGpu.${_mode} PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    endforeach()
    set_tests_properties(AzureRender.ReflectionProbeFieldGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_test(NAME AzureEngine.SurfaceFacingGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/native_render/surface_facing_lab.py" --player "$<TARGET_FILE:AzurePlayer>")
    add_test(NAME AzureEngine.SurfaceUvGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/native_render/surface_uv_lab.py" --player "$<TARGET_FILE:AzurePlayer>")
    set_tests_properties(AzureEngine.SurfaceUvGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureEngine.ReflectionProbeHairGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/native_render/probe_field_hair_lab.py" --player "$<TARGET_FILE:AzurePlayer>")
    set_tests_properties(AzureEngine.SurfaceFacingGpu AzureEngine.ReflectionProbeHairGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureEngine.ReflectionProbeFieldGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/native_render/probe_field_lab.py" --player "$<TARGET_FILE:AzurePlayer>")
    set_tests_properties(AzureEngine.ReflectionProbeFieldGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_executable(AzureReflectionProbeFieldTests tests/ReflectionProbeFieldTests.cpp)
    target_include_directories(AzureReflectionProbeFieldTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureReflectionProbeFieldTests PRIVATE nlohmann_json::nlohmann_json)
    add_test(NAME AzureRender.ReflectionProbeField COMMAND AzureReflectionProbeFieldTests)
    add_executable(AzureOctahedralEnvironmentTests tests/OctahedralEnvironmentTests.cpp)
    target_include_directories(AzureOctahedralEnvironmentTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.OctahedralEnvironment COMMAND AzureOctahedralEnvironmentTests)
    add_executable(AzureOctahedralEnvironmentOwnerTests tests/OctahedralEnvironmentOwnerTests.cpp src/rhi/NullRhi.cpp)
    target_include_directories(AzureOctahedralEnvironmentOwnerTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureOctahedralEnvironmentOwnerTests PRIVATE Vulkan::Vulkan)
    add_test(NAME AzureRender.OctahedralEnvironmentOwner COMMAND AzureOctahedralEnvironmentOwnerTests)
    add_executable(AzureOctahedralEnvironmentGpuTests tests/OctahedralEnvironmentGpuTests.cpp)
    target_link_libraries(AzureOctahedralEnvironmentGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureOctahedralEnvironmentGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.OctahedralEnvironmentGpu COMMAND AzureOctahedralEnvironmentGpuTests "${SHADER_BINARY_DIR}/octahedral_environment_test.comp.spv")
    add_test(NAME AzureRender.OctahedralEnvironmentGpu.Mathematical COMMAND AzureOctahedralEnvironmentGpuTests "${SHADER_BINARY_DIR}/octahedral_environment_test.comp.spv" --mathematical)
    set_tests_properties(AzureRender.OctahedralEnvironmentGpu AzureRender.OctahedralEnvironmentGpu.Mathematical PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureRenderIrradianceVolumeTests tests/IrradianceVolumeTests.cpp)
    target_include_directories(AzureRenderIrradianceVolumeTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_compile_options(AzureRenderIrradianceVolumeTests PRIVATE
        $<$<CXX_COMPILER_ID:MSVC>:/UNDEBUG>
        $<$<NOT:$<CXX_COMPILER_ID:MSVC>>:-UNDEBUG>)
    add_test(NAME AzureRender.IrradianceVolume COMMAND AzureRenderIrradianceVolumeTests)
    add_executable(AzureIrradianceClipmapTests tests/IrradianceClipmapTests.cpp)
    target_include_directories(AzureIrradianceClipmapTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.IrradianceClipmap COMMAND AzureIrradianceClipmapTests "${CMAKE_CURRENT_BINARY_DIR}/clipmap-contract/fixture.azic")
    add_executable(AzureIrradianceClipmapOwnerTests tests/IrradianceClipmapOwnerTests.cpp src/rhi/NullRhi.cpp)
    target_include_directories(AzureIrradianceClipmapOwnerTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureIrradianceClipmapOwnerTests PRIVATE Vulkan::Vulkan)
    add_test(NAME AzureRender.IrradianceClipmapOwner COMMAND AzureIrradianceClipmapOwnerTests)
    add_executable(AzureIrradianceClipmapGpuTests tests/IrradianceClipmapGpuTests.cpp)
    target_link_libraries(AzureIrradianceClipmapGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureIrradianceClipmapGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.IrradianceClipmapGpu COMMAND AzureIrradianceClipmapGpuTests "${SHADER_BINARY_DIR}/irradiance_clipmap_test.comp.spv")
    add_test(NAME AzureRender.IrradianceClipmapGpu.Disabled COMMAND AzureIrradianceClipmapGpuTests "${SHADER_BINARY_DIR}/irradiance_clipmap_test.comp.spv" --disabled)
    add_test(NAME AzureRender.IrradianceClipmapGpu.Mirrored COMMAND AzureIrradianceClipmapGpuTests "${SHADER_BINARY_DIR}/irradiance_clipmap_test.comp.spv" --mirrored)
    set_tests_properties(AzureRender.IrradianceClipmapGpu AzureRender.IrradianceClipmapGpu.Disabled AzureRender.IrradianceClipmapGpu.Mirrored PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_test(NAME AzureRender.IrradianceClipmapSceneGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/native_render/irradiance_clipmap_lab.py" --player "$<TARGET_FILE:AzurePlayer>")
    set_tests_properties(AzureRender.IrradianceClipmapSceneGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_executable(AzureIrradianceQueryTests tests/IrradianceQueryTests.cpp)
    target_include_directories(AzureIrradianceQueryTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureIrradianceQueryTests PRIVATE nlohmann_json::nlohmann_json)
    add_test(NAME AzureRender.IrradianceQuery COMMAND AzureIrradianceQueryTests)
    add_executable(AzureIrradianceQueryGpuTests tests/IrradianceQueryGpuTests.cpp)
    target_link_libraries(AzureIrradianceQueryGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureIrradianceQueryGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.IrradianceQueryGpu COMMAND AzureIrradianceQueryGpuTests "${SHADER_BINARY_DIR}/irradiance_query_test.comp.spv")
    set_tests_properties(AzureRender.IrradianceQueryGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureRenderCascadedShadowTests tests/CascadedShadowTests.cpp)
    target_include_directories(AzureRenderCascadedShadowTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.CascadedShadow COMMAND AzureRenderCascadedShadowTests)
    add_executable(AzureRenderClusteredLightGridTests tests/ClusteredLightGridTests.cpp)
    target_include_directories(AzureRenderClusteredLightGridTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.ClusteredLightGrid COMMAND AzureRenderClusteredLightGridTests)
    add_executable(AzureRenderClusteredLightReceiverTests tests/ClusteredLightReceiverTests.cpp)
    target_include_directories(AzureRenderClusteredLightReceiverTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.ClusteredLightReceiver COMMAND AzureRenderClusteredLightReceiverTests)
    add_executable(
        AzureRenderComputePassTests
        tests/ComputePassTests.cpp
        src/render/ComputePass.cpp
        src/render/ComputePass.hpp
        src/rhi/NullRhi.cpp
        src/rhi/NullRhi.hpp)
    target_include_directories(AzureRenderComputePassTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureRenderComputePassTests PRIVATE Vulkan::Vulkan)
    add_test(NAME AzureRender.ComputePass COMMAND AzureRenderComputePassTests)
    add_executable(AzureRenderFrameTaskSchedulerTests tests/FrameTaskSchedulerTests.cpp)
    target_include_directories(AzureRenderFrameTaskSchedulerTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureRenderFrameTaskSchedulerTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.FrameTaskScheduler COMMAND AzureRenderFrameTaskSchedulerTests)
    add_executable(AzureRenderSurfaceLifecycleTests tests/SurfaceLifecycleTests.cpp)
    target_sources(AzureRenderSurfaceLifecycleTests PRIVATE src/editor/documents/EditorTaskService.cpp)
    target_include_directories(AzureRenderSurfaceLifecycleTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureRenderSurfaceLifecycleTests PRIVATE AzureValidation)
    add_test(NAME AzureRender.SurfaceLifecycle COMMAND AzureRenderSurfaceLifecycleTests)
    add_executable(
        AzureRenderCommandLineTests
        tests/CommandLineTests.cpp
        src/app/CommandLine.cpp
        src/app/CommandLine.hpp
        src/app/AzureRenderOptions.hpp
    )
    target_include_directories(
        AzureRenderCommandLineTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureRenderCommandLineTests PRIVATE nlohmann_json::nlohmann_json)
    add_test(
        NAME AzureRender.CommandLine
        COMMAND AzureRenderCommandLineTests)
    add_executable(
        AzureRenderEditorCameraTests
        tests/EditorCameraControllerTests.cpp
        src/editor/EditorCameraController.cpp
        src/editor/EditorCameraController.hpp
    )
    target_include_directories(
        AzureRenderEditorCameraTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(AzureRenderEditorCameraTests PRIVATE nlohmann_json::nlohmann_json)
    add_test(
        NAME AzureRender.EditorCameraController
        COMMAND AzureRenderEditorCameraTests)
    add_executable(AzureEditorInputRouterTests tests/EditorInputRouterTests.cpp src/editor/input/EditorInputRouter.cpp)
    add_executable(AzureSelectionBoundsTests tests/SelectionBoundsTests.cpp)
    target_link_libraries(AzureSelectionBoundsTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.SelectionBounds COMMAND AzureSelectionBoundsTests)
    add_executable(AzureTransformEditingTests tests/TransformEditingTests.cpp)
    target_link_libraries(AzureTransformEditingTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.TransformEditing COMMAND AzureTransformEditingTests)
    add_executable(AzureGizmoControllerTests tests/GizmoControllerTests.cpp)
    add_executable(AzureAssetDeformationTests tests/AssetDeformationTests.cpp)
    target_link_libraries(AzureAssetDeformationTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.AssetDeformation COMMAND AzureAssetDeformationTests)
    target_link_libraries(AzureGizmoControllerTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.GizmoController COMMAND AzureGizmoControllerTests)
    add_executable(AzureSelectionServiceTests tests/SelectionServiceTests.cpp)
    add_executable(AzureEditorNodeAdditionTests tests/EditorNodeAdditionTests.cpp)
    target_link_libraries(AzureEditorNodeAdditionTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.NodeAddition COMMAND AzureEditorNodeAdditionTests)
    target_link_libraries(AzureSelectionServiceTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.SelectionService COMMAND AzureSelectionServiceTests)
    add_executable(AzureEditorContentWorkflowTests tests/EditorContentWorkflowTests.cpp)
    target_link_libraries(AzureEditorContentWorkflowTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.ContentWorkflow COMMAND AzureEditorContentWorkflowTests)
    add_executable(AzureEditorTaskServiceTests tests/EditorTaskServiceTests.cpp)
    target_link_libraries(AzureEditorTaskServiceTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.TaskService COMMAND AzureEditorTaskServiceTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/test_model.gltf")
    add_executable(AzureEditorAssetWorkflowTests tests/EditorAssetWorkflowTests.cpp)
    target_link_libraries(AzureEditorAssetWorkflowTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.AssetWorkflow COMMAND AzureEditorAssetWorkflowTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/test_model.gltf")
    target_include_directories(AzureEditorInputRouterTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(NAME AzureRender.EditorInputRouter COMMAND AzureEditorInputRouterTests)
    add_executable(AzureEditorCameraServiceTests tests/EditorCameraServiceTests.cpp)
    target_link_libraries(AzureEditorCameraServiceTests PRIVATE AzureEditor)
    add_test(NAME AzureRender.EditorCameraService COMMAND AzureEditorCameraServiceTests)
    add_executable(AzureDocumentBackupTests tests/DocumentBackupTests.cpp)
    target_link_libraries(AzureDocumentBackupTests PRIVATE AzureEditor)
    add_test(NAME AzureRender.DocumentBackup COMMAND AzureDocumentBackupTests)
    add_executable(AzureDocumentActionGuardTests tests/DocumentActionGuardTests.cpp)
    target_link_libraries(AzureDocumentActionGuardTests PRIVATE AzureEditor)
    add_test(NAME AzureRender.DocumentActionGuard COMMAND AzureDocumentActionGuardTests)
    if(Python3_Interpreter_FOUND)
        add_test(NAME AzureEditor.ContentGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_content.py" --executable $<TARGET_FILE:AzureRender> --output "${CMAKE_CURRENT_BINARY_DIR}/u7/content")
        set_tests_properties(AzureEditor.ContentGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
        if(WIN32)
            add_test(NAME AzureEditor.NativeInputGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_native_viewport.py" --executable $<TARGET_FILE:AzureRender> --output "${CMAKE_CURRENT_BINARY_DIR}/p4/native")
            set_tests_properties(AzureEditor.NativeInputGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 240)
        endif()
        add_test(NAME AzureEditor.UsabilityGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_usability.py" --executable $<TARGET_FILE:AzureRender> --output "${CMAKE_CURRENT_BINARY_DIR}/u5/usability")
        add_test(NAME AzureEditor.SceneContainerGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_scene_container.py" --executable $<TARGET_FILE:AzureRender> --output "${CMAKE_CURRENT_BINARY_DIR}/ux/scene-container")
        set_tests_properties(AzureEditor.SceneContainerGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
        add_test(NAME AzureEditor.DocumentGuardGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_document_guard.py" --executable $<TARGET_FILE:AzureRender> --output "${CMAKE_CURRENT_BINARY_DIR}/u5/documents")
        add_test(NAME AzureEditor.ContentScanWait COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_content_wait.py")
        set_tests_properties(AzureEditor.UsabilityGpu AzureEditor.DocumentGuardGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 240)
    endif()
    add_executable(AzureRenderEditorSessionTests tests/EditorSessionTests.cpp)
    target_link_libraries(AzureRenderEditorSessionTests PRIVATE AzureEditor)
    add_test(
        NAME AzureRender.EditorSession
        COMMAND AzureRenderEditorSessionTests)
    add_executable(
        AzureRenderEcsTests
        tests/EcsTests.cpp)
    target_include_directories(
        AzureRenderEcsTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(
        NAME AzureRender.Ecs
        COMMAND AzureRenderEcsTests)
    add_executable(
        AzureRenderPickMathTests
        tests/PickMathTests.cpp)
    target_include_directories(
        AzureRenderPickMathTests PRIVATE
            "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(
        AzureRenderPickMathTests PRIVATE Vulkan::Vulkan)
    add_test(
        NAME AzureRender.PickMath
        COMMAND AzureRenderPickMathTests)
    add_executable(
        AzureRenderSceneModelTests
        tests/SceneModelTests.cpp
        src/runtime/SceneDocument.cpp
        src/editor/SceneModel.hpp
        src/render/RenderSettings.cpp
        src/render/RenderSettings.hpp
    )
    target_include_directories(
        AzureRenderSceneModelTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(
        AzureRenderSceneModelTests PRIVATE AzureRuntime nlohmann_json::nlohmann_json)
    # These test executables use assert as their verification contract.
    target_compile_options(AzureRenderSceneModelTests PRIVATE
        $<$<CXX_COMPILER_ID:MSVC>:/UNDEBUG>
        $<$<NOT:$<CXX_COMPILER_ID:MSVC>>:-UNDEBUG>)
    target_compile_definitions(
        AzureRenderSceneModelTests PRIVATE
        AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_test(
        NAME AzureRender.SceneModel
        COMMAND AzureRenderSceneModelTests)
    add_executable(
        AzureRenderRuntimeDiagnosticsTests
        tests/RuntimeDiagnosticsTests.cpp
        src/diagnostics/RuntimeDiagnostics.cpp
        src/diagnostics/RuntimeDiagnostics.hpp
    )
    target_include_directories(
        AzureRenderRuntimeDiagnosticsTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(
        NAME AzureRender.RuntimeDiagnostics
        COMMAND AzureRenderRuntimeDiagnosticsTests)
    add_executable(
        AzureRenderGpuCapabilityReportTests
        tests/GpuCapabilityReportTests.cpp
        src/diagnostics/GpuCapabilityReport.cpp
        src/diagnostics/GpuCapabilityReport.hpp
        src/diagnostics/RuntimeDiagnostics.cpp
        src/diagnostics/RuntimeDiagnostics.hpp
    )
    target_include_directories(
        AzureRenderGpuCapabilityReportTests PRIVATE
            "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(
        AzureRenderGpuCapabilityReportTests PRIVATE
            Vulkan::Vulkan
            nlohmann_json::nlohmann_json)
    add_test(
        NAME AzureRender.GpuCapabilityReport
        COMMAND AzureRenderGpuCapabilityReportTests)
    add_executable(
        AzureRenderResourceLocatorTests
        tests/ResourceLocatorTests.cpp
        src/resources/ResourceLocator.cpp
        src/resources/ResourceLocator.hpp
        src/diagnostics/RuntimeDiagnostics.cpp
        src/diagnostics/RuntimeDiagnostics.hpp
    )
    target_include_directories(
        AzureRenderResourceLocatorTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(
        NAME AzureRender.ResourceLocator
        COMMAND AzureRenderResourceLocatorTests)
    add_executable(
        AzureRenderExtensionRegistryTests
        tests/ExtensionRegistryTests.cpp
        src/render/RenderGraph.cpp
    )
    target_include_directories(
        AzureRenderExtensionRegistryTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(
        AzureRenderExtensionRegistryTests PRIVATE Vulkan::Vulkan nlohmann_json::nlohmann_json)
    add_test(
        NAME AzureRender.ExtensionRegistry
        COMMAND AzureRenderExtensionRegistryTests)
    add_executable(
        AzureRenderUploadRingTests
        tests/UploadRingTests.cpp
    )
    target_include_directories(
        AzureRenderUploadRingTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    add_test(
        NAME AzureRender.UploadRing
        COMMAND AzureRenderUploadRingTests)
    add_executable(
        AzureRenderNullRhiTests
        tests/NullRhiTests.cpp
        src/rhi/NullRhi.cpp
    )
    target_include_directories(
        AzureRenderNullRhiTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(
        AzureRenderNullRhiTests PRIVATE Vulkan::Vulkan)
    target_compile_options(AzureRenderNullRhiTests PRIVATE
        $<$<CXX_COMPILER_ID:MSVC>:/UNDEBUG>
        $<$<NOT:$<CXX_COMPILER_ID:MSVC>>:-UNDEBUG>)
    add_test(
        NAME AzureRender.NullRhi
        COMMAND AzureRenderNullRhiTests)
    add_executable(AzureRenderNullRhiPassTests tests/NullRhiPassTests.cpp)
    target_link_libraries(AzureRenderNullRhiPassTests PRIVATE AzureRenderCore)
    add_dependencies(AzureRenderNullRhiPassTests AzureRenderShaders)
    target_compile_options(AzureRenderNullRhiPassTests PRIVATE
        $<$<CXX_COMPILER_ID:MSVC>:/UNDEBUG>
        $<$<NOT:$<CXX_COMPILER_ID:MSVC>>:-UNDEBUG>)
    target_compile_definitions(
        AzureRenderNullRhiPassTests PRIVATE
        AZURERENDER_TEST_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
    add_test(
        NAME AzureRender.NullRhiPass
        COMMAND AzureRenderNullRhiPassTests "${SHADER_BINARY_DIR}")
    add_executable(
        AzureRenderSceneGraphTests
        tests/SceneGraphTests.cpp
    )
    target_include_directories(
        AzureRenderSceneGraphTests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(
        AzureRenderSceneGraphTests PRIVATE Vulkan::Vulkan)
    add_test(
        NAME AzureRender.SceneGraph
        COMMAND AzureRenderSceneGraphTests)

    # GPU visual regression. This needs a working Vulkan device, so it is
    # registered only when Python and the tooling are present and it reports
    # "skipped" rather than failing on machines without a usable GPU.
    find_package(Python3 COMPONENTS Interpreter QUIET)
    if(Python3_Interpreter_FOUND)
        add_test(
            NAME AzureRender.VisualRegression
            COMMAND
                "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/run_visual_regression.py"
                --executable "$<TARGET_FILE:AzureRender>"
                --tolerance strict
                --output-dir "${CMAKE_CURRENT_BINARY_DIR}/visual-regression"
                --summary
                    "${CMAKE_CURRENT_BINARY_DIR}/visual-regression-summary.json")
        set_tests_properties(
            AzureRender.VisualRegression
            PROPERTIES
                SKIP_RETURN_CODE 2
                TIMEOUT 900
                LABELS "gpu"
                RUN_SERIAL TRUE)
        # The fixed per-material descriptor path must stay pixel-identical;
        # it is the fallback on devices without descriptor indexing.
        add_test(
            NAME AzureRender.VisualRegressionLegacyDescriptors
            COMMAND
                "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/run_visual_regression.py"
                --executable "$<TARGET_FILE:AzureRender>"
                --tolerance strict
                "--renderer-arg=--disable-bindless"
                --output-dir "${CMAKE_CURRENT_BINARY_DIR}/visual-regression-legacy"
                --summary
                    "${CMAKE_CURRENT_BINARY_DIR}/visual-regression-legacy-summary.json")
        set_tests_properties(
            AzureRender.VisualRegressionLegacyDescriptors
            PROPERTIES
                SKIP_RETURN_CODE 2
                TIMEOUT 900
                LABELS "gpu"
                RUN_SERIAL TRUE)
    endif()
    if(WIN32)
        add_test(
            NAME AzureRender.BlackholeComputeGpu
            COMMAND powershell.exe -NoProfile -ExecutionPolicy Bypass
                -File "${CMAKE_CURRENT_SOURCE_DIR}/tools/run_blackhole_compute_smoke.ps1"
                -Executable "$<TARGET_FILE:AzureRender>"
                -OutputDirectory "${CMAKE_CURRENT_BINARY_DIR}/blackhole-compute-smoke")
        set_tests_properties(
            AzureRender.BlackholeComputeGpu
            PROPERTIES
                SKIP_RETURN_CODE 2
                TIMEOUT 180
                LABELS "gpu"
                RUN_SERIAL TRUE)
        add_test(
            NAME AzureRender.CharacterIblComputeGpu
            COMMAND powershell.exe -NoProfile -ExecutionPolicy Bypass
                -File "${CMAKE_CURRENT_SOURCE_DIR}/tools/run_character_ibl_smoke.ps1"
                -Executable "$<TARGET_FILE:AzureRender>"
                -OutputDirectory "${CMAKE_CURRENT_BINARY_DIR}/character-ibl-smoke")
        set_tests_properties(
            AzureRender.CharacterIblComputeGpu
            PROPERTIES
                SKIP_RETURN_CODE 2
                TIMEOUT 180
                LABELS "gpu"
                RUN_SERIAL TRUE)
        add_test(
            NAME AzureRender.CharacterSkinningComputeGpu
            COMMAND powershell.exe -NoProfile -ExecutionPolicy Bypass
                -File "${CMAKE_CURRENT_SOURCE_DIR}/tools/run_character_skinning_smoke.ps1"
                -Executable "$<TARGET_FILE:AzureRender>"
                -OutputDirectory "${CMAKE_CURRENT_BINARY_DIR}/character-skinning-smoke")
        set_tests_properties(
            AzureRender.CharacterSkinningComputeGpu
            PROPERTIES
                SKIP_RETURN_CODE 2
                TIMEOUT 180
                LABELS "gpu"
                RUN_SERIAL TRUE)
    endif()
    if(WIN32 AND Python3_Interpreter_FOUND)
        add_test(NAME AzureRender.R4AcceptanceRules
            COMMAND "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_r4_acceptance.py")
        add_test(NAME AzureEngine.PlayerCli
            COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_player_cli.py"
                --executable "$<TARGET_FILE:AzurePlayer>")
        add_test(NAME AzureRender.BlackholeOptimizationRules
            COMMAND "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_blackhole_optimization.py")
        add_test(NAME AzureRender.R3Comparison
            COMMAND "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/run_r3_comparison.py"
                --executable "$<TARGET_FILE:AzureRender>"
                --output-dir "${CMAKE_CURRENT_BINARY_DIR}/r3-comparison"
                --frames 10 --instances 64)
        set_tests_properties(AzureRender.R3Comparison PROPERTIES
            TIMEOUT 900 LABELS "gpu" RUN_SERIAL TRUE)
        add_test(NAME AzureRender.R3TransparentComparison
            COMMAND "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/run_r3_comparison.py"
                --executable "$<TARGET_FILE:AzureRender>"
                --output-dir "${CMAKE_CURRENT_BINARY_DIR}/r3-transparent-comparison"
                --frames 10 --instances 16 --transparent-fixture)
        set_tests_properties(AzureRender.R3TransparentComparison PROPERTIES
            TIMEOUT 900 LABELS "gpu" RUN_SERIAL TRUE)
        add_test(NAME AzureRender.AuditRegressions
            COMMAND "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/run_audit_regressions.py"
                --executable "$<TARGET_FILE:AzureRender>")
        set_tests_properties(AzureRender.AuditRegressions PROPERTIES
            TIMEOUT 90 LABELS "gpu" RUN_SERIAL TRUE)
        add_test(
            NAME AzureRender.VisualRegressionLegacySkinning
            COMMAND
                "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/run_visual_regression.py"
                --executable "$<TARGET_FILE:AzureRender>"
                --tolerance strict
                "--renderer-arg=--disable-compute-skinning"
                --output-dir "${CMAKE_CURRENT_BINARY_DIR}/visual-regression-legacy-skinning"
                --summary
                    "${CMAKE_CURRENT_BINARY_DIR}/visual-regression-legacy-skinning-summary.json")
        set_tests_properties(
            AzureRender.VisualRegressionLegacySkinning
            PROPERTIES
                SKIP_RETURN_CODE 2
                TIMEOUT 900
                LABELS "gpu"
                RUN_SERIAL TRUE)
        add_test(
            NAME AzureRender.CharacterMorphComputeGpu
            COMMAND
                "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/run_morph_compute_regression.py"
                --executable "$<TARGET_FILE:AzureRender>"
                --output-dir
                    "${CMAKE_CURRENT_BINARY_DIR}/morph-compute-regression")
        set_tests_properties(
            AzureRender.CharacterMorphComputeGpu
            PROPERTIES
                SKIP_RETURN_CODE 2
                TIMEOUT 180
                LABELS "gpu"
                RUN_SERIAL TRUE)
        add_test(
            NAME AzureRender.ClusteredLightingGpu
            COMMAND
                "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/run_clustered_lighting_smoke.py"
                --executable "$<TARGET_FILE:AzureRender>"
                --output-dir
                    "${CMAKE_CURRENT_BINARY_DIR}/clustered-lighting-smoke")
        set_tests_properties(
            AzureRender.ClusteredLightingGpu
            PROPERTIES
                SKIP_RETURN_CODE 2
                TIMEOUT 180
                LABELS "gpu"
                RUN_SERIAL TRUE)
    endif()
    add_test(
        NAME AzureRender.ReleaseGateMissingBuild
        COMMAND "${CMAKE_COMMAND}"
            -DBUILD_DIR=${CMAKE_CURRENT_BINARY_DIR}/missing-release-gate-build
            -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/run_release_gate.cmake)
    set_tests_properties(
        AzureRender.ReleaseGateMissingBuild PROPERTIES WILL_FAIL TRUE)
    add_test(
        NAME AzureRender.InstallManifestRoundTrip
        COMMAND "${CMAKE_COMMAND}"
            -DSOURCE_DIR=${CMAKE_CURRENT_SOURCE_DIR}
            -P ${CMAKE_CURRENT_SOURCE_DIR}/tools/test_install_manifest_roundtrip.cmake)
endif()

target_link_libraries(
    AzureRender
    PRIVATE
        Vulkan::Vulkan
        glfw
        nlohmann_json::nlohmann_json
        GPUOpen::VulkanMemoryAllocator
        OpenEXR::OpenEXR
)

# The VMA implementation unit is third-party code and does not satisfy the
# project warning gate; exempt only that file.
if(MSVC)
    set_source_files_properties(
        src/rhi/VulkanMemoryAllocatorImpl.cpp
        PROPERTIES COMPILE_OPTIONS "/W0")
else()
    set_source_files_properties(
        src/rhi/VulkanMemoryAllocatorImpl.cpp
        PROPERTIES COMPILE_OPTIONS "-w")
endif()


target_include_directories(
    AzureRender
    PRIVATE
        "${CMAKE_CURRENT_SOURCE_DIR}/src"
        "${TINYGLTF_INCLUDE_DIR}"
        "${STB_INCLUDE_DIR}"
)

target_compile_definitions(
    AzureRender
    PRIVATE
        GLFW_INCLUDE_VULKAN
        AZURERENDER_VERSION="${PROJECT_VERSION}-rc1"
        AZURERENDER_DEVELOPMENT_ROOT="${CMAKE_CURRENT_SOURCE_DIR}"
        $<$<CONFIG:Debug>:AZURERENDER_ENABLE_VALIDATION=1>
)

if(MSVC)
    # The strict warning gate is tuned for the GCC/MinGW baseline. MSVC reports
    # additional diagnostic classes that are not defects on this codebase:
    # C4456 (local shadowing of reused Vulkan *Info structs), C4996 (getenv),
    # and C4127 (conditions on compile-time constants such as kEnableValidation,
    # which is false in Release). They are demoted so the MSVC toolchain stays
    # buildable without weakening the GCC gate that CI enforces.
    target_compile_options(
        AzureRender
        PRIVATE
            /W4
            /WX
            /permissive-
            /wd4127
            /wd4456
            /wd4996
    )
else()
    target_compile_options(
        AzureRender
        PRIVATE
            -Wall
            -Wextra
            -Wpedantic
            -Werror
            -Wno-missing-field-initializers
    )
endif()

if(WIN32)
    add_custom_command(
        TARGET AzureRender
        POST_BUILD
        COMMAND "${CMAKE_COMMAND}" -E copy_if_different
                "$<TARGET_FILE:glfw>"
                "$<TARGET_FILE_DIR:AzureRender>"
        COMMENT "Copying GLFW runtime"
    )
endif()

if(MINGW)
    get_filename_component(MINGW_RUNTIME_DIR "${CMAKE_CXX_COMPILER}" DIRECTORY)
    set(AZURERENDER_MINGW_RUNTIME_FILES "")
    foreach(runtime_dll libgcc_s_seh-1.dll libstdc++-6.dll libwinpthread-1.dll)
        if(EXISTS "${MINGW_RUNTIME_DIR}/${runtime_dll}")
            list(APPEND AZURERENDER_MINGW_RUNTIME_FILES
                "${MINGW_RUNTIME_DIR}/${runtime_dll}")
            add_custom_command(
                TARGET AzureRender
                POST_BUILD
                COMMAND "${CMAKE_COMMAND}" -E copy_if_different
                        "${MINGW_RUNTIME_DIR}/${runtime_dll}"
                        "$<TARGET_FILE_DIR:AzureRender>"
                COMMENT "Copying ${runtime_dll}"
            )
        endif()
    endforeach()
endif()

set_property(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}" PROPERTY VS_STARTUP_PROJECT AzureRender)

set_target_properties(AzureRender PROPERTIES INSTALL_RPATH "$ORIGIN")
add_executable(AzureAssetExchange tools/asset-exchange/main.cpp)
target_link_libraries(AzureAssetExchange PRIVATE AzureRenderCore AzurePlatform)
install(TARGETS AzureRender AzurePlayer AzureMetaGen AzureGeometryCompiler AzureAssetExchange AzureMaterialValidator RUNTIME DESTINATION "${CMAKE_INSTALL_BINDIR}")
install(DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}/contracts/"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/contracts")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/engine-evolution-manifest.json"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/tools/write_engine_contracts.py"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/tools")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/engine-delivery.md"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/p3-implementation.md"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
if(MSVC)
    if(MSVC_VERSION GREATER_EQUAL 1930)
        # CMake 3.20's runtime module recognizes VC142; VS2022 ships VC143.
        set(AZURE_MSVC_REDIST_ROOT "$ENV{VCToolsRedistDir}" CACHE PATH "MSVC redistributable root")
        get_filename_component(AZURE_MSVC_BIN "${CMAKE_CXX_COMPILER}" DIRECTORY)
        get_filename_component(AZURE_MSVC_VC "${AZURE_MSVC_BIN}/../../../../../.." ABSOLUTE)
        file(GLOB AZURE_MSVC_CRT_CANDIDATES
            "${AZURE_MSVC_REDIST_ROOT}/x64/Microsoft.VC143.CRT/msvcp140.dll"
            "${AZURE_MSVC_VC}/Redist/MSVC/*/x64/Microsoft.VC143.CRT/msvcp140.dll")
        list(SORT AZURE_MSVC_CRT_CANDIDATES COMPARE NATURAL ORDER DESCENDING)
        if(NOT AZURE_MSVC_CRT_CANDIDATES)
            message(FATAL_ERROR "VC143 runtime missing; set AZURE_MSVC_REDIST_ROOT to its redistributable root")
        endif()
        list(GET AZURE_MSVC_CRT_CANDIDATES 0 AZURE_MSVC_CRT_FILE)
        get_filename_component(AZURE_MSVC_CRT_DIR "${AZURE_MSVC_CRT_FILE}" DIRECTORY)
        file(GLOB AZURE_MSVC_CRT_DLLS "${AZURE_MSVC_CRT_DIR}/*.dll")
        install(FILES ${AZURE_MSVC_CRT_DLLS} DESTINATION "${CMAKE_INSTALL_BINDIR}")
    else()
        set(CMAKE_INSTALL_SYSTEM_RUNTIME_DESTINATION "${CMAKE_INSTALL_BINDIR}")
        include(InstallRequiredSystemLibraries)
    endif()
endif()
if(MINGW)
    if(NOT AZURERENDER_MINGW_RUNTIME_FILES)
        message(FATAL_ERROR "MinGW runtime DLLs were not found")
    endif()
    install(
        FILES ${AZURERENDER_MINGW_RUNTIME_FILES}
        DESTINATION "${CMAKE_INSTALL_BINDIR}")
endif()
install(
    DIRECTORY "${SHADER_BINARY_DIR}/"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/shaders"
    FILES_MATCHING PATTERN "*.spv")
install(
    DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/assets_public"
    PATTERN ".azure" EXCLUDE
    PATTERN "*.tmp" EXCLUDE)
set(AZURE_DOCUMENTATION_FILES
        "${CMAKE_CURRENT_SOURCE_DIR}/README.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/CHANGELOG.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/THIRD_PARTY_NOTICES.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/index.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/getting-started.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/architecture.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/character-rendering.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/blackhole-rendering.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/assets-and-editor.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/development-and-release.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/reference.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/documentation-standard.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/azure-engine-plan.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/render-core-implementation.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/compute-passes.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/character-finish.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/environment-assets.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/clustered-lighting.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/render-graph.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/rhi-synchronization.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/scene-data.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/parallel-submission.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/windows-acceptance.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/engine-foundation.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/system-composition.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/edit-operations.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/observations-generation.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/ui-settings.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/content-proposals.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/development-previews.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/procedural-content.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/shader-modules.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/resource-visibility.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/reference/developer-cli.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/g0-implementation.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/g1-implementation.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/g2-implementation.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/g3-implementation.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/g4-implementation.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/reflection.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/assets-levels.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/physics-input.md"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/scripts-gameplay.md")
install(FILES ${AZURE_DOCUMENTATION_FILES}
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs"
    FILES_MATCHING PATTERN "*.md" PATTERN "*.json")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/p8/evidence/"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/p8/evidence")
foreach(AZURE_DOCUMENTATION_FILE IN LISTS AZURE_DOCUMENTATION_FILES)
    file(RELATIVE_PATH AZURE_DOCUMENTATION_RELATIVE "${CMAKE_CURRENT_SOURCE_DIR}" "${AZURE_DOCUMENTATION_FILE}")
    if(AZURE_DOCUMENTATION_RELATIVE MATCHES "^docs/")
        get_filename_component(AZURE_DOCUMENTATION_DIRECTORY "${AZURE_DOCUMENTATION_RELATIVE}" DIRECTORY)
        install(FILES "${AZURE_DOCUMENTATION_FILE}"
            DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/${AZURE_DOCUMENTATION_DIRECTORY}")
    endif()
endforeach()
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/r1/2026-09-26.md"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/r1")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/tutorials/"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/tutorials")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/media/"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/media" OPTIONAL)
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/r2/2026-09-26.md"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/r2")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/r3/2026-10-03.md"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/r3")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/r4/2026-10-03.md"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/r4")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/blackhole-performance.md"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-03-blackhole-optimization.md"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g0/2026-10-03.md"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/g0")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/blackhole/2026-10-03.md"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/blackhole")
install(
    FILES
        "${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui/LICENSE.txt"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses"
    RENAME "imgui-LICENSE.txt")
foreach(_pkg opus opusfile directxtex directxmath ktx zstd egl-registry opengl-registry libvorbis libogg libflac mp3lame tiff libwebp libjpeg-turbo liblzma libspng assimp jhasse-poly2tri kubazip minizip pugixml rapidjson utfcpp glfw3 tinygltf stb openexr imath libdeflate openjph nlohmann-json joltphysics lua sol2 rmlui miniaudio freetype libpng zlib bzip2 brotli manifold clipper2 tbb hwloc)
    if(EXISTS
        "${VCPKG_INSTALLED_DIR}/${VCPKG_TARGET_TRIPLET}/share/${_pkg}/copyright")
        install(
            FILES
                "${VCPKG_INSTALLED_DIR}/${VCPKG_TARGET_TRIPLET}/share/${_pkg}/copyright"
            DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses"
            RENAME "${_pkg}-LICENSE.txt")
    endif()
endforeach()
if(WIN32)
    install(FILES "$<TARGET_FILE:glfw>" DESTINATION "${CMAKE_INSTALL_BINDIR}")
    file(GLOB AZURE_RUNTIME_DLLS
        "${VCPKG_INSTALLED_DIR}/${VCPKG_TARGET_TRIPLET}/bin/*.dll")
    install(FILES ${AZURE_RUNTIME_DLLS}
        DESTINATION "${CMAKE_INSTALL_BINDIR}")
elseif(UNIX)
    install(
        FILES "$<TARGET_FILE:glfw>"
        DESTINATION "${CMAKE_INSTALL_BINDIR}"
        RENAME "libglfw.so.3")
endif()

set(CPACK_PACKAGE_NAME "AzureRender")
set(CPACK_PACKAGE_VENDOR "AzureRender Project")
set(CPACK_PACKAGE_VERSION "${PROJECT_VERSION}-rc1")
set(CPACK_PACKAGE_DESCRIPTION_SUMMARY "Vulkan stylized renderer and editor RC")
if(WIN32)
    if(CMAKE_GENERATOR_PLATFORM MATCHES "^[Aa][Rr][Mm]64$"
        OR CMAKE_CXX_COMPILER_ARCHITECTURE_ID MATCHES "^[Aa][Rr][Mm]64$")
        set(AZURERENDER_PACKAGE_ARCH "arm64")
    elseif(CMAKE_SIZEOF_VOID_P EQUAL 8)
        set(AZURERENDER_PACKAGE_ARCH "x64")
    elseif(CMAKE_SIZEOF_VOID_P EQUAL 4)
        set(AZURERENDER_PACKAGE_ARCH "x86")
    else()
        message(FATAL_ERROR
            "Cannot determine Windows package architecture from the configured target")
    endif()
else()
    string(TOLOWER "${CMAKE_SYSTEM_PROCESSOR}" AZURERENDER_PACKAGE_ARCH)
    if(AZURERENDER_PACKAGE_ARCH STREQUAL "")
        message(FATAL_ERROR "CMAKE_SYSTEM_PROCESSOR is required for package naming")
    endif()
endif()
set(CPACK_PACKAGE_FILE_NAME
    "AzureRender-${CPACK_PACKAGE_VERSION}-${CMAKE_SYSTEM_NAME}-${AZURERENDER_PACKAGE_ARCH}")
set(AZURE_SCRIPT_BACKENDS "\"lua\"")
if(AZURE_ENABLE_MANAGED_SCRIPT_PROTOTYPE)
    set(AZURE_SCRIPT_BACKENDS "\"lua\", \"coreclr\", \"nativeaot\"")
endif()
file(GENERATE OUTPUT "${CMAKE_CURRENT_BINARY_DIR}/runtime-build-$<CONFIG>.json"
    CONTENT "{\n  \"schemaVersion\": 1,\n  \"engineVersion\": \"${PROJECT_VERSION}\",\n  \"configuration\": \"$<CONFIG>\",\n  \"architecture\": \"${AZURERENDER_PACKAGE_ARCH}\",\n  \"platform\": \"${CMAKE_SYSTEM_NAME}\",\n  \"scriptBackends\": [${AZURE_SCRIPT_BACKENDS}]\n}\n")
install(FILES "${CMAKE_CURRENT_BINARY_DIR}/runtime-build-$<CONFIG>.json"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender" RENAME "runtime-build.json")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/tools/build_game.py"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/tools")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/tools/ai_bridge.py"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/tools")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/tools/ai/"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/tools/ai"
    FILES_MATCHING PATTERN "*.py" PATTERN "__pycache__" EXCLUDE)
set(CPACK_GENERATOR "ZIP;TGZ")
set(CPACK_INCLUDE_TOPLEVEL_DIRECTORY ON)
include(CPack)

foreach(AZURE_PHASE f1 r5 g5 g6 u1 f2 p1 f3 r6 g7 u2 p2 f4 g8 u3 f5 u4 g9 r7 g10 r8 r9 g11 p3 u5 u6 g1 g2 g3 g4 u0 p0)
    file(GLOB AZURE_PHASE_RECORDS "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/${AZURE_PHASE}/*.md")
    if(AZURE_PHASE_RECORDS)
        install(FILES ${AZURE_PHASE_RECORDS} DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/${AZURE_PHASE}")
    endif()
endforeach()

install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/fonts/NotoSansCJK-LICENSE.txt" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/fonts/RmlUi-Sample-Fonts-LICENSE.txt" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses" RENAME "LatoLatin-LICENSE.txt")

install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/editor-game-ui.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/game-publishing.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/build-reproducibility.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/exploration-gameplay.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/playable-performance.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/scene-visibility.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/u0-implementation.md" "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/p0-implementation.md" "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/third-person-playable-plan.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
install(FILES
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-05-quality-round.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-05-repository-plan.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-05-playable-quality-plan.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-05-editor-ui-plan.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-06-engine-evolution.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-06-engine-foundation-steps.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-06-ai-native-editor-steps.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-06-engine-specialized-steps.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-07-editor-usability.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-08-editor-acceptance.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/editor-usability-manifest.json"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/engine-evolution-manifest.json"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
install(FILES
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/research/2026-10-06-gknextengine.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/research/2026-10-07-editor-usability.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/research/gknextengine-source-map.json"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/research")

install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/third_party/gknextengine/LICENSE.txt" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses" RENAME "gkNextEngine-LICENSE.txt")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/third_party/nanosvg/LICENSE.txt" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses" RENAME "NanoSVG-LICENSE.txt")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/third_party/nanosvg/SOURCE.json" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses" RENAME "NanoSVG-source.json")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/assets/extended-formats.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/assets")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/scene-2d.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/content-expansion-manifest.json" "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-12-content-expansion.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/script-services.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/tutorials/managed-scripts.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/tutorials")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/g11-implementation.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/schemas/script_bindings.json" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/schemas")
if(AZURE_ENABLE_MANAGED_SCRIPT_PROTOTYPE)
    install(DIRECTORY "${AZURE_MANAGED_OUTPUT}/coreclr/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/scripting/coreclr" FILES_MATCHING PATTERN "*.dll" PATTERN "*.json")
    install(FILES "${AZURE_MANAGED_OUTPUT}/nativeaot/Azure.Engine.Native.dll" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/scripting/nativeaot")
    install(FILES "${AZURE_MANAGED_OUTPUT}/manifest.json" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/scripting")
    install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/third_party/dotnet/LICENSE.txt" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses" RENAME "dotnet-LICENSE.txt")
    install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/third_party/dotnet/THIRD-PARTY-NOTICES.txt" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses" RENAME "dotnet-THIRD-PARTY-NOTICES.txt")
endif()

install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/research/editor-usability-evidence/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/research/editor-usability-evidence")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/u5/evidence/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/u5/evidence")

install(FILES third_party/ImGuizmo/LICENSE.txt DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses" RENAME "ImGuizmo-LICENSE.txt")
install(FILES third_party/ImGuizmo/source.json DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses" RENAME "ImGuizmo-source.json")
install(FILES third_party/ImViewGuizmo/LICENSE.txt DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses" RENAME "ImViewGuizmo-LICENSE.txt")
install(FILES third_party/ImViewGuizmo/source.json DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses" RENAME "ImViewGuizmo-source.json")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/physics-authoring.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")

install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/u6/evidence/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/u6/evidence" OPTIONAL)

install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/content-workflows.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/tutorials/editor-interaction.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/tutorials")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-08-content-workflows.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/u7/2026-10-08.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/u7")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/u7/evidence/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/u7/evidence" OPTIONAL)
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/p4/2026-10-08.md" "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/p4/physical-input.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/p4")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/p4/evidence/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/p4/evidence" OPTIONAL)
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-09-character-rendering-repair.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/research/2026-10-09-character-rendering-diagnosis.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/research")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-09-character-presentation-refinement.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/research/2026-10-09-character-presentation-refinement.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/research")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/character/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/character")

# Editor productization contracts.
if(BUILD_TESTING)
    add_executable(AzureEditorProjectFlowTests tests/EditorProjectFlowTests.cpp)
    target_link_libraries(AzureEditorProjectFlowTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.ProjectFlow COMMAND AzureEditorProjectFlowTests)
endif()

target_sources(AzureEditor PRIVATE src/editor/projects/ProjectOpenService.cpp)

target_sources(AzureEditor PRIVATE src/editor/panels/ProjectBrowserPanel.cpp src/editor/panels/EnvironmentPanel.cpp)

target_sources(AzureEditor PRIVATE src/editor/projects/ProjectCreateJob.cpp)

if(BUILD_TESTING AND Python3_Interpreter_FOUND)
    add_test(NAME AzureEditor.ProductizationGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_productization.py" --executable $<TARGET_FILE:AzureRender> --output "${CMAKE_CURRENT_BINARY_DIR}/productization")
    set_tests_properties(AzureEditor.ProductizationGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
endif()

install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/project-workspace.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-09-editor-productization.md" "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/hazel-fermion-manifest.json" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/research/2026-10-09-hazel-fermion.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/research")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/u8/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/u8")

if(BUILD_TESTING)
    add_executable(AzurePropertyEditingTests tests/PropertyEditingTests.cpp)
    target_link_libraries(AzurePropertyEditingTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.PropertyEditing COMMAND AzurePropertyEditingTests)
    add_executable(AzureReferencePickerTests tests/ReferencePickerTests.cpp)
    target_link_libraries(AzureReferencePickerTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.ReferencePicker COMMAND AzureReferencePickerTests)
endif()

install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/property-editing.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
if(BUILD_TESTING AND TARGET AzureRender)
    add_test(NAME AzureEditor.PropertiesGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_properties.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/property-ui-${CMAKE_BUILD_TYPE}")
    set_tests_properties(AzureEditor.PropertiesGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 300)
endif()

install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/u9/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/u9")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/content-transactions.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g12/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/g12")

if(BUILD_TESTING)
    add_executable(AzureContentOperationTests tests/ContentOperationTests.cpp)
    add_executable(AzureSceneRenderSnapshotTests tests/SceneRenderSnapshotTests.cpp)
    target_link_libraries(AzureSceneRenderSnapshotTests PRIVATE AzureRuntime)
    add_test(NAME AzureRuntime.SceneRenderSnapshot COMMAND AzureSceneRenderSnapshotTests)
    target_link_libraries(AzureContentOperationTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.ContentOperations COMMAND AzureContentOperationTests)
    add_executable(AzureTextureImportContractTests tests/TextureImportContractTests.cpp)
    target_link_libraries(AzureTextureImportContractTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.TextureImportContract COMMAND AzureTextureImportContractTests)
    add_executable(AzureReflectionSpatialFilterTests tests/ReflectionSpatialFilterTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureReflectionSpatialFilterTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ReflectionSpatialFilter COMMAND AzureReflectionSpatialFilterTests)
    add_executable(AzureReflectionSignalPyramidTests tests/ReflectionSignalPyramidTests.cpp src/rhi/NullRhi.cpp)
    add_executable(AzureDepthPyramidTests tests/DepthPyramidTests.cpp src/rhi/NullRhi.cpp)
    add_executable(AzureReflectionRayTests tests/ReflectionRayTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureReflectionRayTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ReflectionRay COMMAND AzureReflectionRayTests)
    add_executable(AzureProjectedReflectionRayTests tests/ProjectedReflectionRayTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureProjectedReflectionRayTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ProjectedReflectionRay COMMAND AzureProjectedReflectionRayTests)
    add_executable(AzureProjectedReflectionCameraTests tests/ProjectedReflectionCameraTests.cpp)
    target_link_libraries(AzureProjectedReflectionCameraTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ProjectedReflectionCamera COMMAND AzureProjectedReflectionCameraTests)
    add_executable(AzureProjectedReflectionPreparationTests tests/ProjectedReflectionPreparationTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureProjectedReflectionPreparationTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ProjectedReflectionPreparation COMMAND AzureProjectedReflectionPreparationTests)
    add_executable(AzureProjectedScreenReflectionTests tests/ProjectedScreenReflectionTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureProjectedScreenReflectionTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ProjectedScreenReflection COMMAND AzureProjectedScreenReflectionTests)
    add_executable(AzureProjectedReflectionPreparationGpuTests tests/ProjectedReflectionPreparationGpuTests.cpp)
    target_link_libraries(AzureProjectedReflectionPreparationGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureProjectedReflectionPreparationGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ProjectedReflectionPreparationGpu COMMAND AzureProjectedReflectionPreparationGpuTests "${SHADER_BINARY_DIR}/projected_reflection_prepare.comp.spv")
    set_tests_properties(AzureRender.ProjectedReflectionPreparationGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureProjectedReflectionCameraGpuTests tests/ProjectedReflectionCameraGpuTests.cpp)
    target_link_libraries(AzureProjectedReflectionCameraGpuTests PRIVATE AzureRenderCore AzurePlatform)
    add_dependencies(AzureProjectedReflectionCameraGpuTests AzureRenderShaders)
    if(TARGET AzureProjectedReflectionShaders)
        add_dependencies(AzureProjectedReflectionCameraGpuTests AzureProjectedReflectionShaders)
    endif()
    add_executable(AzureReflectionTemporalTests tests/ReflectionTemporalTests.cpp src/rhi/NullRhi.cpp)
    add_executable(AzureReflectionReprojectionTests tests/ReflectionReprojectionTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureReflectionReprojectionTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ReflectionReprojection COMMAND AzureReflectionReprojectionTests)
    add_executable(AzureReflectionReprojectionGpuTests tests/ReflectionReprojectionGpuTests.cpp)
    target_link_libraries(AzureReflectionReprojectionGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureReflectionReprojectionGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ReflectionReprojectionGpu COMMAND AzureReflectionReprojectionGpuTests "${SHADER_BINARY_DIR}/reflection_reprojection.comp.spv")
    set_tests_properties(AzureRender.ReflectionReprojectionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    target_link_libraries(AzureReflectionTemporalTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ReflectionTemporal COMMAND AzureReflectionTemporalTests)
    add_executable(AzureReflectionTemporalGpuTests tests/ReflectionTemporalGpuTests.cpp)
    target_link_libraries(AzureReflectionTemporalGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureReflectionTemporalGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ReflectionTemporalGpu COMMAND AzureReflectionTemporalGpuTests "${SHADER_BINARY_DIR}/reflection_temporal_packed.comp.spv" "${SHADER_BINARY_DIR}/reflection_temporal_float.comp.spv" "${SHADER_BINARY_DIR}/reflection_signal_pyramid_packed.comp.spv" "${SHADER_BINARY_DIR}/reflection_signal_pyramid_float.comp.spv")
    set_tests_properties(AzureRender.ReflectionTemporalGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureScreenReflectionTests tests/ScreenReflectionTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureScreenReflectionTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ScreenReflection COMMAND AzureScreenReflectionTests)
    add_executable(AzureScreenObjectVisibilityTests tests/ScreenObjectVisibilityTests.cpp src/rhi/NullRhi.cpp)
    add_executable(AzureGpuStableKeySortTests tests/GpuStableKeySortTests.cpp src/rhi/NullRhi.cpp)
    add_executable(AzureGpuConservativeOcclusionTests tests/GpuConservativeOcclusionTests.cpp src/rhi/NullRhi.cpp)
    add_executable(AzureGpuPredicateDrawSelectionTests tests/GpuPredicateDrawSelectionTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureGpuPredicateDrawSelectionTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.GpuPredicateDrawSelection COMMAND AzureGpuPredicateDrawSelectionTests)
    add_executable(AzureGpuPredicateDrawSelectionGpuTests tests/GpuPredicateDrawSelectionGpuTests.cpp)
    target_link_libraries(AzureGpuPredicateDrawSelectionGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureGpuPredicateDrawSelectionGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.GpuPredicateDrawSelectionGpu COMMAND AzureGpuPredicateDrawSelectionGpuTests "${SHADER_BINARY_DIR}/predicate_draw_selection.comp.spv")
    set_tests_properties(AzureRender.GpuPredicateDrawSelectionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)

    add_executable(AzureDepthPrepassSplitTests tests/DepthPrepassSplitTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureDepthPrepassSplitTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.DepthPrepassSplit COMMAND AzureDepthPrepassSplitTests)
    add_executable(AzureDepthPrepassSplitGpuTests tests/DepthPrepassSplitGpuTests.cpp)
    target_link_libraries(AzureDepthPrepassSplitGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureDepthPrepassSplitGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.DepthPrepassSplitGpu COMMAND AzureDepthPrepassSplitGpuTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.DepthPrepassSplitGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    target_link_libraries(AzureGpuConservativeOcclusionTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.GpuConservativeOcclusion COMMAND AzureGpuConservativeOcclusionTests)
    add_executable(AzureGpuConservativeOcclusionGpuTests tests/GpuConservativeOcclusionGpuTests.cpp)
    target_link_libraries(AzureGpuConservativeOcclusionGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureGpuConservativeOcclusionGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.GpuConservativeOcclusionGpu COMMAND AzureGpuConservativeOcclusionGpuTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.GpuConservativeOcclusionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureGpuTransparentIndexSortTests tests/GpuTransparentIndexSortTests.cpp src/rhi/NullRhi.cpp)
    target_link_libraries(AzureGpuTransparentIndexSortTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.GpuTransparentIndexSort COMMAND AzureGpuTransparentIndexSortTests)
    add_executable(AzureGpuTransparentIndexSortGpuTests tests/GpuTransparentIndexSortGpuTests.cpp)
    target_link_libraries(AzureGpuTransparentIndexSortGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureGpuTransparentIndexSortGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.GpuTransparentIndexSortGpu COMMAND AzureGpuTransparentIndexSortGpuTests "${SHADER_BINARY_DIR}")
    set_tests_properties(AzureRender.GpuTransparentIndexSortGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    target_link_libraries(AzureGpuStableKeySortTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.GpuStableKeySort COMMAND AzureGpuStableKeySortTests)
    add_executable(AzureGpuStableKeySortGpuTests tests/GpuStableKeySortGpuTests.cpp)
    target_link_libraries(AzureGpuStableKeySortGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureGpuStableKeySortGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.GpuStableKeySortGpu COMMAND AzureGpuStableKeySortGpuTests "${SHADER_BINARY_DIR}/stable_key_sort.comp.spv")
    set_tests_properties(AzureRender.GpuStableKeySortGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    target_link_libraries(AzureScreenObjectVisibilityTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ScreenObjectVisibility COMMAND AzureScreenObjectVisibilityTests)
    add_executable(AzureScreenObjectVisibilityGpuTests tests/ScreenObjectVisibilityGpuTests.cpp)
    target_link_libraries(AzureScreenObjectVisibilityGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureScreenObjectVisibilityGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ScreenObjectVisibilityGpu COMMAND AzureScreenObjectVisibilityGpuTests "${SHADER_BINARY_DIR}")
    add_test(NAME AzureRender.ScreenObjectVisibilityReferenceGpu COMMAND AzureScreenObjectVisibilityGpuTests "${SHADER_BINARY_DIR}" --reference)
    set_tests_properties(AzureRender.ScreenObjectVisibilityReferenceGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureReflectionRayGpuTests tests/ReflectionRayGpuTests.cpp)
    add_executable(AzureNativeRayReferenceGpuTests tests/NativeRayReferenceGpuTests.cpp)
    target_link_libraries(AzureNativeRayReferenceGpuTests PRIVATE AzureRenderCore AzurePlatform)
    if(TARGET AzureProjectedReflectionShaders)
        add_dependencies(AzureNativeRayReferenceGpuTests AzureProjectedReflectionShaders)
    endif()
    if(Python3_Interpreter_FOUND)
        add_test(NAME AzureTools.NativeRayFixture COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_native_ray_fixture.py")
        add_test(NAME AzureRender.NativeRayReferenceGpu COMMAND "${Python3_EXECUTABLE}"
            "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_native_ray_reference_gpu.py"
            --executable "$<TARGET_FILE:AzureNativeRayReferenceGpuTests>"
            --shader "${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures/native_ray_vulkan/reference.spv")
        set_tests_properties(AzureRender.NativeRayReferenceGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
        if(TARGET AzureProjectedReflectionShaders)
            add_test(NAME AzureRender.ProjectedReflectionCameraGpu COMMAND "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_camera_gpu.py"
                --executable "$<TARGET_FILE:AzureProjectedReflectionCameraGpuTests>"
                --shader "${AZURE_PROJECTED_REFLECTION_SHADER}")
            set_tests_properties(AzureRender.ProjectedReflectionCameraGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 180)
            add_test(NAME AzureRender.ProjectedReflectionPreparedMirrorGpu COMMAND "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_camera_gpu.py"
                --executable "$<TARGET_FILE:AzureProjectedReflectionCameraGpuTests>"
                --shader "${AZURE_PROJECTED_REFLECTION_SHADER}"
                --preparation "${SHADER_BINARY_DIR}/projected_reflection_prepare.comp.spv")
            set_tests_properties(AzureRender.ProjectedReflectionPreparedMirrorGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 180)
            add_test(NAME AzureRender.ProjectedScreenReflectionGpu COMMAND "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_camera_gpu.py"
                --executable "$<TARGET_FILE:AzureProjectedReflectionCameraGpuTests>"
                --shader "${AZURE_PROJECTED_REFLECTION_SHADER}"
                --composition "${SHADER_BINARY_DIR}")
            set_tests_properties(AzureRender.ProjectedScreenReflectionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 180)
            add_test(NAME AzureRender.ProjectedReflectionMotionGpu COMMAND "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_camera_gpu.py"
                --executable "$<TARGET_FILE:AzureProjectedReflectionCameraGpuTests>"
                --shader "${AZURE_PROJECTED_REFLECTION_SHADER}"
                --composition "${SHADER_BINARY_DIR}" --motion-contract)
            set_tests_properties(AzureRender.ProjectedReflectionMotionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 180)
            add_test(NAME AzureRender.ProjectedReflectionRayGpu COMMAND "${Python3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_native_ray_reference_gpu.py"
                --executable "$<TARGET_FILE:AzureNativeRayReferenceGpuTests>"
                --shader "${AZURE_PROJECTED_REFLECTION_SHADER}" --projected)
            set_tests_properties(AzureRender.ProjectedReflectionRayGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
        endif()
    endif()
    target_link_libraries(AzureReflectionRayGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureReflectionRayGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ReflectionRayGpu COMMAND AzureReflectionRayGpuTests "${SHADER_BINARY_DIR}/reflection_trace_packed.comp.spv" "${SHADER_BINARY_DIR}/reflection_trace_float.comp.spv" "${SHADER_BINARY_DIR}/reflection_signal_pyramid_packed.comp.spv" "${SHADER_BINARY_DIR}/reflection_signal_pyramid_float.comp.spv" "${SHADER_BINARY_DIR}/reflection_spatial_filter.comp.spv" "${SHADER_BINARY_DIR}/depth_pyramid.comp.spv")
    set_tests_properties(AzureRender.ReflectionRayGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    target_link_libraries(AzureDepthPyramidTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.DepthPyramid COMMAND AzureDepthPyramidTests)
    add_executable(AzureDepthPyramidGpuTests tests/DepthPyramidGpuTests.cpp)
    add_executable(AzureGpuBufferPolicyGpuTests tests/GpuBufferPolicyGpuTests.cpp)
    target_link_libraries(AzureGpuBufferPolicyGpuTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.GpuBufferPolicyGpu COMMAND AzureGpuBufferPolicyGpuTests)
    set_tests_properties(AzureRender.GpuBufferPolicyGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    target_link_libraries(AzureDepthPyramidGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureDepthPyramidGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.DepthPyramidGpu COMMAND AzureDepthPyramidGpuTests "${SHADER_BINARY_DIR}/depth_pyramid.comp.spv")
    set_tests_properties(AzureRender.DepthPyramidGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureReflectionSurfaceGpuTests tests/ReflectionSurfaceGpuTests.cpp)
    target_link_libraries(AzureReflectionSurfaceGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureReflectionSurfaceGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ReflectionSurfaceGpu COMMAND AzureReflectionSurfaceGpuTests "${SHADER_BINARY_DIR}/reflection_surface_test.comp.spv")
    set_tests_properties(AzureRender.ReflectionSurfaceGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    target_link_libraries(AzureReflectionSignalPyramidTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.ReflectionSignalPyramid COMMAND AzureReflectionSignalPyramidTests)
    add_executable(AzureReflectionSignalPyramidGpuTests tests/ReflectionSignalPyramidGpuTests.cpp)
    target_link_libraries(AzureReflectionSignalPyramidGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureReflectionSignalPyramidGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ReflectionSignalPyramidGpu COMMAND AzureReflectionSignalPyramidGpuTests "${SHADER_BINARY_DIR}/reflection_signal_pyramid_packed.comp.spv" "${SHADER_BINARY_DIR}/reflection_signal_pyramid_float.comp.spv")
    set_tests_properties(AzureRender.ReflectionSignalPyramidGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    add_executable(AzureReflectionSpatialFilterGpuTests tests/ReflectionSpatialFilterGpuTests.cpp)
    target_link_libraries(AzureReflectionSpatialFilterGpuTests PRIVATE AzureRenderCore)
    add_dependencies(AzureReflectionSpatialFilterGpuTests AzureRenderShaders)
    add_test(NAME AzureRender.ReflectionSpatialFilterGpu COMMAND AzureReflectionSpatialFilterGpuTests "${SHADER_BINARY_DIR}/reflection_spatial_filter.comp.spv")
    set_tests_properties(AzureRender.ReflectionSpatialFilterGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
endif()

if(BUILD_TESTING)
    add_executable(AzureTextureMaterialImportTests tests/TextureMaterialImportTests.cpp)
    target_link_libraries(AzureTextureMaterialImportTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.TextureMaterialImport COMMAND AzureTextureMaterialImportTests)
    add_executable(AzureMaterialUvImportTests tests/MaterialUvImportTests.cpp)
    target_link_libraries(AzureMaterialUvImportTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.MaterialUvImport COMMAND AzureMaterialUvImportTests)
    add_executable(AzureShadowColorLutTests tests/ShadowColorLutTests.cpp)
    target_link_libraries(AzureShadowColorLutTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.ShadowColorLut COMMAND AzureShadowColorLutTests)
    add_executable(AzureMaterialOriginInstanceTests tests/MaterialOriginInstanceTests.cpp)
    target_link_libraries(AzureMaterialOriginInstanceTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRender.MaterialOriginInstances COMMAND AzureMaterialOriginInstanceTests)
    add_executable(AzureSpecularInputTests tests/SpecularInputTests.cpp)
    target_link_libraries(AzureSpecularInputTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.SpecularInput COMMAND AzureSpecularInputTests)
    add_test(NAME AzureEngine.SpecularInputGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_specular_input_gpu.py" --executable $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.SpecularInputGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.ShadowColorLutGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_shadow_color_lut_gpu.py" --executable $<TARGET_FILE:AzurePlayer>)
    add_test(NAME AzureRender.ScreenSurfaceNormalGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_screen_normal_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.ScreenSurfaceNormalGpu PROPERTIES TIMEOUT 1800 LABELS gpu RUN_SERIAL TRUE)
    add_test(NAME AzureRender.NprViewMaskGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_npr_view_mask_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.NprViewMaskGpu PROPERTIES TIMEOUT 1800 LABELS gpu RUN_SERIAL TRUE)
    add_test(NAME AzureRender.ScreenSurfaceNormalShadowGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_screen_normal_shadow_gpu.py"
        --executable "$<TARGET_FILE:AzurePlayer>" --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.ScreenSurfaceNormalShadowGpu PROPERTIES TIMEOUT 1800 LABELS gpu RUN_SERIAL TRUE)
    add_test(NAME AzureRender.MaterialOriginGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_origin_gpu.py" --executable $<TARGET_FILE:AzurePlayer>)
    add_test(NAME AzureRender.MaterialRadialNormalGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_material_origin_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --radial-normal --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.MaterialOriginGpu AzureRender.MaterialRadialNormalGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureRender.SpecularRampProductionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_specular_ramp_gpu.py" --executable $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureRender.SpecularRampProductionGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.ObjectShadowGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_object_shadow_gpu.py" --executable $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.ObjectShadowGpu PROPERTIES TIMEOUT 900 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureTools.GpuTextureAccess COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_gpu_texture_access.py")
    add_test(NAME AzureTools.NativeNprLighting COMMAND "${Python3_EXECUTABLE}" -m unittest discover -s "${CMAKE_CURRENT_SOURCE_DIR}/tools" -p test_native_npr_lighting.py)
    add_test(NAME AzureTools.NativeSurfaceColors COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_native_surface_colors.py")
    add_test(NAME AzureTools.NativeProjectedHairMath COMMAND "${Python3_EXECUTABLE}" -m unittest discover -s "${CMAKE_CURRENT_SOURCE_DIR}/tools" -p test_native_character_projected_hair_math.py)
    add_test(NAME AzureTools.OutlineDirections COMMAND "${Python3_EXECUTABLE}" -m unittest discover -s "${CMAKE_CURRENT_SOURCE_DIR}/tools" -p test_outline_directions.py)
    add_test(NAME AzureTools.NativeTemporalCapture COMMAND "${Python3_EXECUTABLE}" -m unittest discover -s "${CMAKE_CURRENT_SOURCE_DIR}/tools" -p test_native_render_temporal_capture.py)
    add_test(NAME AzureTools.NativeCapturedLights COMMAND "${Python3_EXECUTABLE}" -m unittest discover -s "${CMAKE_CURRENT_SOURCE_DIR}/tools" -p test_native_captured_lights.py)
    add_test(NAME AzureTools.NativeCameraProjection COMMAND "${Python3_EXECUTABLE}" -m unittest discover -s "${CMAKE_CURRENT_SOURCE_DIR}/tools" -p test_native_camera_projection.py)
    add_test(NAME AzureTools.NativeCapturePixels COMMAND "${Python3_EXECUTABLE}" -m unittest discover -s "${CMAKE_CURRENT_SOURCE_DIR}/tools" -p test_native_capture_pixels.py)
    add_test(NAME AzureRender.CameraProjectionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_camera_projection_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.CameraProjectionGpu PROPERTIES TIMEOUT 180 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureRender.CaptureCameraGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_capture_camera_gpu.py"
        --player $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureRender.CaptureCameraGpu PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureTools.NativePostVs COMMAND "${Python3_EXECUTABLE}" -m unittest discover -s "${CMAKE_CURRENT_SOURCE_DIR}/tools" -p test_native_postvs.py)
    add_test(NAME AzureEngine.NprIlluminationGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_npr_illumination_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureEngine.NprIlluminationGpu PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    foreach(hair_group IN ITEMS surface local specular)
        set(hair_test "AzureRender.ProjectedHairLightingGpu")
        if(NOT hair_group STREQUAL "surface")
            string(APPEND hair_test ".${hair_group}")
        endif()
        add_test(NAME "${hair_test}" COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_hair_lighting_gpu.py"
            --executable $<TARGET_FILE:AzurePlayer> --group "${hair_group}" --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
        set_tests_properties("${hair_test}" PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    endforeach()
    add_test(NAME AzureRender.ProjectedHairMainChromaGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_projected_hair_lighting_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --main-brightness-saturation --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.ProjectedHairMainChromaGpu PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureRender.CharacterLocalLightGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_local_light_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.CharacterLocalLightGpu PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureRender.CharacterColorBlendGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_color_blend_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.CharacterColorBlendGpu PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureRender.CharacterScreenRimGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_screen_rim_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --case edge --case interior --case near-depth --case mid-depth --case far-depth --case fixed --case material-depth
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.CharacterScreenRimGpu PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureRender.CharacterScreenRimGpu.Modulation COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_screen_rim_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --case zero-offset --case zero-tint --case spot --case disabled --case effect-disabled --case no-receiver --case parallel --case blend --case rim-isolation --case smooth
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.CharacterScreenRimGpu.Modulation PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureRender.CharacterScreenRimGpu.Physical COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_screen_rim_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --case pbr --case pbr-control --case pbr-specular --case pbr-material --case pbr-material-control
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.CharacterScreenRimGpu.Physical PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureRender.CharacterScreenRimGpu.Facing COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_screen_rim_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --case material-facing --case material-facing-fixed --case material-facing-near-depth --case material-facing-far-depth --case material-facing-front --case material-facing-disabled --case material-facing-effect-disabled --case material-facing-no-receiver --case material-facing-generic
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.CharacterScreenRimGpu.Facing PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureRender.ClusteredLightProjectionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_character_local_light_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --case upper-light --case lower-light --case offset-camera
        --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureRender.ClusteredLightProjectionGpu PROPERTIES TIMEOUT 120 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureAssets.TextureMipBiasGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_texture_mip_bias_gpu.py"
        --executable $<TARGET_FILE:AzurePlayer> --expected-validation "$<IF:$<CONFIG:Debug>,enabled,disabled>")
    set_tests_properties(AzureAssets.TextureMipBiasGpu PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEditor.TextureMipBiasGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_texture_mip_bias_ui.py"
        --executable $<TARGET_FILE:AzureRender>)
    set_tests_properties(AzureEditor.TextureMipBiasGpu PROPERTIES TIMEOUT 300 LABELS "gpu" RUN_SERIAL TRUE)
    add_test(NAME AzureEngine.NprDiffuseGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_npr_diffuse_gpu.py" --executable $<TARGET_FILE:AzurePlayer>)
    set_tests_properties(AzureEngine.NprDiffuseGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
    set_tests_properties(AzureEngine.ShadowColorLutGpu PROPERTIES TIMEOUT 600 LABELS "gpu" RUN_SERIAL TRUE)
endif()

if(BUILD_TESTING)
    add_executable(AzureContentEditingWorkflowTests tests/ContentEditingWorkflowTests.cpp)
    target_link_libraries(AzureContentEditingWorkflowTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.ContentEditingWorkflow COMMAND AzureContentEditingWorkflowTests)
    add_test(NAME AzureEditor.ContentTransactionsGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_content_transactions.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/content-transactions-ui-${CMAKE_BUILD_TYPE}")
    set_tests_properties(AzureEditor.ContentTransactionsGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 300)
endif()

if(BUILD_TESTING)
    add_executable(AzureContentNavigationTests tests/ContentNavigationTests.cpp)
    target_link_libraries(AzureContentNavigationTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.ContentNavigation COMMAND AzureContentNavigationTests)
    add_executable(AzureAssetOpenTests tests/AssetOpenTests.cpp)
    target_link_libraries(AzureAssetOpenTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.AssetOpen COMMAND AzureAssetOpenTests)
    add_executable(AzurePrimitiveGeneratorTests tests/PrimitiveGeneratorTests.cpp)
    target_link_libraries(AzurePrimitiveGeneratorTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.PrimitiveGenerator COMMAND AzurePrimitiveGeneratorTests)
    add_executable(AzureEditorCreationTests tests/EditorCreationTests.cpp)
    target_link_libraries(AzureEditorCreationTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.Creation COMMAND AzureEditorCreationTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/scene_inspector")
    add_executable(AzureContentDirectoryScaleTests tests/ContentDirectoryScaleTests.cpp)
    target_link_libraries(AzureContentDirectoryScaleTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.ContentDirectoryScale COMMAND AzureContentDirectoryScaleTests)
    set_tests_properties(AzureEditor.ContentDirectoryScale PROPERTIES TIMEOUT 180)
    add_test(NAME AzureEditor.ContentNavigationGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_content_navigation.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/content-navigation-ui-${CMAKE_BUILD_TYPE}")
    set_tests_properties(AzureEditor.ContentNavigationGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 300)
    add_test(NAME AzureEditor.PanelDesignGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_panel_design.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/panel-design-ui-${CMAKE_BUILD_TYPE}")
    set_tests_properties(AzureEditor.PanelDesignGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 300)
    add_test(NAME AzureEditor.PanelDiagnosticsGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_panel_design.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/panel-diagnostics-ui-${CMAKE_BUILD_TYPE}" --cases diagnostics)
    set_tests_properties(AzureEditor.PanelDiagnosticsGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 120)
    add_test(NAME AzureEditor.SelectionDesignGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_selection_design.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/selection-design-ui-${CMAKE_BUILD_TYPE}")
    set_tests_properties(AzureEditor.SelectionDesignGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME AzureEditor.ViewportDesignGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_viewport_design.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/viewport-design-ui-${CMAKE_BUILD_TYPE}")
    set_tests_properties(AzureEditor.ViewportDesignGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 180)
endif()

if(BUILD_TESTING)
    add_executable(AzureExplorationDesignTests tests/ExplorationDesignTests.cpp)
    add_executable(AzurePlatformerPhysicsTests tests/PlatformerPhysicsTests.cpp)
    target_link_libraries(AzurePlatformerPhysicsTests PRIVATE AzureProjectRuntime)
    add_test(NAME AzureGame.PlatformerPhysics COMMAND AzurePlatformerPhysicsTests)
    add_executable(AzurePlatformerFlowTests tests/PlatformerFlowTests.cpp)
    target_link_libraries(AzurePlatformerFlowTests PRIVATE AzureProjectRuntime AzureLuaScripting)
    add_test(NAME AzureGame.PlatformerFlow COMMAND AzurePlatformerFlowTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/platformer/project.azureproject" "${CMAKE_CURRENT_BINARY_DIR}/platformer-flow")
    add_test(NAME AzureGame.PlatformerPhase4 COMMAND AzurePlatformerFlowTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/platformer/project.azureproject" "${CMAKE_CURRENT_BINARY_DIR}/platformer-phase4" 60)
    add_test(NAME AzureGame.PlatformerPhase9 COMMAND AzurePlatformerFlowTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/platformer/project.azureproject" "${CMAKE_CURRENT_BINARY_DIR}/platformer-phase9" 135)
    add_test(NAME AzureGame.PlatformerCompletion COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_platformer_completion.py" --executable "$<TARGET_FILE:AzurePlayer>" --planner "$<TARGET_FILE:AzurePlatformerFlowTests>" --project "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/platformer/project.azureproject" --output "${CMAKE_CURRENT_BINARY_DIR}/platformer-completion")
    set_tests_properties(AzureGame.PlatformerCompletion PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    add_test(NAME AzureEngine.LiveGameState COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_live_game_state.py" --player "$<TARGET_FILE:AzurePlayer>" --project "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/platformer/project.azureproject" --output "${CMAKE_CURRENT_BINARY_DIR}/live-game-state")
    set_tests_properties(AzureEngine.LiveGameState PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME AzureEditor.NodeAdditionGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_node_addition.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/node-addition-ui")
    set_tests_properties(AzureEditor.NodeAdditionGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 300)
    add_test(NAME AzureEditor.GeneralWorkflowGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_general_workflow.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/general-editor-workflow")
    set_tests_properties(AzureEditor.GeneralWorkflowGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 300)
    add_test(NAME AzureGame.GameSequence COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_game_sequence.py" --executable "$<TARGET_FILE:AzurePlayer>" --planner "$<TARGET_FILE:AzurePlatformerFlowTests>" --exploration "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/exploration/project.azureproject" --platformer "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/platformer/project.azureproject" --output "${CMAKE_CURRENT_BINARY_DIR}/game-sequence")
    set_tests_properties(AzureGame.GameSequence PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 600)
    target_link_libraries(AzureExplorationDesignTests PRIVATE AzureRuntime)
    add_test(NAME AzureGame.ExplorationDesign COMMAND AzureExplorationDesignTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/exploration/project.azureproject")
    add_test(NAME AzureGame.ExplorationCompletion COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_exploration_completion.py" --executable "$<TARGET_FILE:AzurePlayer>" --project "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/exploration/project.azureproject" --output "${CMAKE_CURRENT_BINARY_DIR}/exploration-completion-${CMAKE_BUILD_TYPE}")
    set_tests_properties(AzureGame.ExplorationCompletion PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 600)
    add_executable(AzureMaterialSlotEditingTests tests/MaterialSlotEditingTests.cpp)
    target_link_libraries(AzureMaterialSlotEditingTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.MaterialSlotEditing COMMAND AzureMaterialSlotEditingTests)
    add_executable(AzureMaterialDocumentTests tests/MaterialDocumentTests.cpp)
    add_executable(AzureMaterialGraphTests tests/MaterialGraphTests.cpp)
    add_executable(AzureRenderer2DTests tests/Renderer2DTests.cpp)
    target_link_libraries(AzureRenderer2DTests PRIVATE AzureRenderCore RmlUi::RmlUi)
    add_dependencies(AzureRenderer2DTests AzureRenderShaders)
    add_test(NAME AzureRender.Renderer2D COMMAND AzureRenderer2DTests "${SHADER_BINARY_DIR}")
    add_executable(AzureScene2DTests tests/Scene2DTests.cpp)
    add_executable(AzureScene2DDependencyTests tests/Scene2DDependencyTests.cpp)
    target_link_libraries(AzureScene2DDependencyTests PRIVATE AzureRuntime)
    add_test(NAME AzureAssets.Scene2DDependencies COMMAND AzureScene2DDependencyTests)
    add_executable(AzureScene2DWorkflowTests tests/Scene2DWorkflowTests.cpp)
    target_link_libraries(AzureScene2DWorkflowTests PRIVATE AzureRuntime AzureRenderCore)
    add_dependencies(AzureScene2DWorkflowTests AzureRenderShaders)
    add_test(NAME AzureEngine.Scene2DWorkflow COMMAND AzureScene2DWorkflowTests "${SHADER_BINARY_DIR}" "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/samples/2d/scene.azure2d" "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/fonts/LatoLatin-Regular.ttf")
    add_executable(AzureExtendedImageFormatsTests tests/ExtendedImageFormatsTests.cpp)
    add_executable(AzureExtendedAssetWorkflowTests tests/ExtendedAssetWorkflowTests.cpp)
    target_link_libraries(AzureExtendedAssetWorkflowTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.ExtendedAssetWorkflow COMMAND AzureExtendedAssetWorkflowTests)
    add_executable(AzureUsdaFormatTests tests/UsdaFormatTests.cpp)
    add_executable(AzureAudioNotificationQueueTests tests/AudioNotificationQueueTests.cpp)
    add_executable(AzureAudioDeviceShutdownTests tests/AudioDeviceShutdownTests.cpp)
    target_link_libraries(AzureAudioDeviceShutdownTests PRIVATE AzureRuntime)
    add_test(NAME AzureRuntime.AudioDeviceShutdown COMMAND AzureAudioDeviceShutdownTests)
    set_tests_properties(AzureRuntime.AudioDeviceShutdown PROPERTIES TIMEOUT 20 SKIP_RETURN_CODE 77 RUN_SERIAL TRUE)
    target_link_libraries(AzureAudioNotificationQueueTests PRIVATE AzureRenderCore)
    add_test(NAME AzureRuntime.AudioNotificationQueue COMMAND AzureAudioNotificationQueueTests)
    set_tests_properties(AzureRuntime.AudioNotificationQueue PROPERTIES TIMEOUT 10)
    target_link_libraries(AzureUsdaFormatTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.UsdaFormat COMMAND AzureUsdaFormatTests)
    target_link_libraries(AzureExtendedImageFormatsTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.ExtendedImageFormats COMMAND AzureExtendedImageFormatsTests)
    target_link_libraries(AzureScene2DTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.Scene2D COMMAND AzureScene2DTests)
    add_executable(AzureMaterialGraphEditingTests tests/MaterialGraphEditingTests.cpp)
    target_link_libraries(AzureMaterialGraphEditingTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.MaterialGraphEditing COMMAND AzureMaterialGraphEditingTests)
    target_link_libraries(AzureMaterialGraphTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.MaterialGraph COMMAND AzureMaterialGraphTests)
    target_link_libraries(AzureMaterialDocumentTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.MaterialDocument COMMAND AzureMaterialDocumentTests)
    add_executable(AzureEditorProjectionTests tests/EditorProjectionTests.cpp)
    add_executable(AzurePreviewSimulationTests tests/PreviewSimulationTests.cpp)
    add_executable(AzureEditorDocumentManagerTests tests/EditorDocumentManagerTests.cpp)
    add_executable(AzureAnimationAuthoringTests tests/AnimationAuthoringTests.cpp)
    add_executable(AzureAuthoringWorkflowTests tests/AuthoringWorkflowTests.cpp)
    add_executable(AzureManagedAuthoringTests tests/ManagedAuthoringTests.cpp)
    target_link_libraries(AzureManagedAuthoringTests PRIVATE AzureEditor)
    if(AZURE_ENABLE_MANAGED_SCRIPT_PROTOTYPE)
        add_test(NAME AzureEditor.ManagedAuthoring COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_managed_authoring.py" --tester "$<TARGET_FILE:AzureManagedAuthoringTests>" --artifacts "${AZURE_MANAGED_OUTPUT}/coreclr" --output "${CMAKE_CURRENT_BINARY_DIR}/managed-authoring-${CMAKE_BUILD_TYPE}")
        set_tests_properties(AzureEditor.ManagedAuthoring PROPERTIES TIMEOUT 120)
    endif()
    add_executable(AzureDomainAuthoringTests tests/DomainAuthoringTests.cpp)
    add_executable(AzurePrefabAuthoringTests tests/PrefabAuthoringTests.cpp)
    target_link_libraries(AzurePrefabAuthoringTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.PrefabAuthoring COMMAND AzurePrefabAuthoringTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/physics_arm")
    target_link_libraries(AzureDomainAuthoringTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.DomainAuthoring COMMAND AzureDomainAuthoringTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/face_sdf_v1.png")
    target_link_libraries(AzureAuthoringWorkflowTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.AuthoringWorkflow COMMAND AzureAuthoringWorkflowTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/scene_inspector")
    target_link_libraries(AzureAnimationAuthoringTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.AnimationAuthoring COMMAND AzureAnimationAuthoringTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/third_person/game")
    target_link_libraries(AzureEditorDocumentManagerTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.DocumentManager COMMAND AzureEditorDocumentManagerTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/scene_inspector")
    add_test(NAME AzureEditor.AuthoringGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_authoring.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/authoring-${CMAKE_BUILD_TYPE}")
    set_tests_properties(AzureEditor.AuthoringGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 300)
    target_link_libraries(AzurePreviewSimulationTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.PreviewSimulation COMMAND AzurePreviewSimulationTests)
    add_executable(AzurePhysicsAuthoringTests tests/PhysicsAuthoringTests.cpp)
    target_link_libraries(AzurePhysicsAuthoringTests PRIVATE AzureRuntime)
    add_test(NAME AzureEngine.PhysicsAuthoring COMMAND AzurePhysicsAuthoringTests)
    add_test(NAME AzureEditor.SimulationGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_simulation.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/simulation-${CMAKE_BUILD_TYPE}")
    set_tests_properties(AzureEditor.SimulationGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 300)
    target_link_libraries(AzureEditorProjectionTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.EditorProjection COMMAND AzureEditorProjectionTests)
    add_executable(AzureViewportOverlayTests tests/ViewportOverlayTests.cpp)
    target_link_libraries(AzureViewportOverlayTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.ViewportOverlays COMMAND AzureViewportOverlayTests)
    add_test(NAME AzureEditor.ViewportNavigationGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_viewport_navigation.py" --executable "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/viewport-navigation-${CMAKE_BUILD_TYPE}")
    set_tests_properties(AzureEditor.ViewportNavigationGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 300)
    add_test(NAME AzureEditor.SceneGeometryGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_editor_scene_geometry.py" --editor "$<TARGET_FILE:AzureRender>" --output "${CMAKE_CURRENT_BINARY_DIR}/scene-geometry")
    set_tests_properties(AzureEditor.SceneGeometryGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 180)
    add_test(NAME AzureEngine.RendererResidency COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_renderer_residency.py" --player "$<TARGET_FILE:AzurePlayer>" --output "${CMAKE_CURRENT_BINARY_DIR}/renderer-residency")
    set_tests_properties(AzureEngine.RendererResidency PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 300)
endif()

install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/p5/2026-10-10.md" "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/p5/physical-input.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/p5")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/runtime/"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime"
    FILES_MATCHING PATTERN "*.md")
foreach(AZURE_PRODUCT_PHASE u10 u11 u12 g13 u13 g15 g16)
    install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/${AZURE_PRODUCT_PHASE}/"
        DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/${AZURE_PRODUCT_PHASE}")
endforeach()

install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/p5/evidence/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/p5/evidence" OPTIONAL)
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/p5/closure/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/p5/closure")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/u16/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/u16")
install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/p6/" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/acceptance/p6")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-10-p5-closure-and-user-experience.md" "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/authoring-usability-manifest.json" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
install(FILES
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-11-pipeline-inspection.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-11-asset-format-expansion.md"
    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/asset-format-manifest.json"
    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/research/2026-10-10-authoring-usability.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/research")

if(BUILD_TESTING)
    add_executable(AzureAssetFormatRegistryTests tests/AssetFormatRegistryTests.cpp)
    target_link_libraries(AzureAssetFormatRegistryTests PRIVATE AzureRenderCore)
    add_test(NAME AzureAssets.FormatRegistry COMMAND AzureAssetFormatRegistryTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/test_model.gltf")
endif()

if(BUILD_TESTING)
    add_executable(AzureModelFormatAdapterTests tests/ModelFormatAdapterTests.cpp)
    target_link_libraries(AzureModelFormatAdapterTests PRIVATE AzureRuntime assimp::assimp)
    add_test(NAME AzureAssets.ModelFormats COMMAND AzureModelFormatAdapterTests)
endif()

if(BUILD_TESTING)
    add_executable(AzureImageCodecTests tests/ImageCodecTests.cpp)
    target_link_libraries(AzureImageCodecTests PRIVATE AzureRenderCore TIFF::TIFF WebP::webp)
    target_include_directories(AzureImageCodecTests PRIVATE "${STB_INCLUDE_DIR}")
    add_test(NAME AzureAssets.ImageFormats COMMAND AzureImageCodecTests)
    add_executable(AzureTextureContainerTests tests/TextureContainerTests.cpp)
    target_link_libraries(AzureTextureContainerTests PRIVATE AzureEditor KTX::ktx)
    add_dependencies(AzureTextureContainerTests AzureRenderShaders)
    add_test(NAME AzureAssets.TextureContainers COMMAND AzureTextureContainerTests "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/test_model.gltf" "${CMAKE_CURRENT_BINARY_DIR}/shaders")
    add_test(NAME AzureEditor.TextureContainersGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_texture_container_workflows.py" --executable "$<TARGET_FILE:AzureRender>")
    set_tests_properties(AzureEditor.TextureContainersGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 420)
endif()

install(FILES docs/runtime/image-format-import.md DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES docs/runtime/texture-containers.md DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES docs/licenses/texture-containers-source.json DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses")
install(DIRECTORY docs/licenses/ktx DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses")
install(FILES docs/licenses/image-codecs-source.json DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses")
install(FILES docs/licenses/audio-codecs-source.json DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses")
install(FILES docs/runtime/audio-format-import.md DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")
install(FILES docs/runtime/asset-exchange.md DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/runtime")

if(BUILD_TESTING)
    add_executable(AzureAudioCodecTests tests/AudioCodecTests.cpp)
    add_executable(AzureCompressedAudioFormatsTests tests/CompressedAudioFormatsTests.cpp)
    target_link_libraries(AzureCompressedAudioFormatsTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.CompressedAudioGpu COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_compressed_audio_workflows.py" --executable "$<TARGET_FILE:AzureRender>")
    set_tests_properties(AzureEditor.CompressedAudioGpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE TIMEOUT 420)
    add_test(NAME AzureAssets.CompressedAudioFormats COMMAND AzureCompressedAudioFormatsTests "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g23/evidence/2026-10-12/audio-fixtures" "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/test_model.gltf")
    target_link_libraries(AzureAudioCodecTests PRIVATE AzureRuntime FLAC::FLAC Vorbis::vorbisenc mp3lame::mp3lame)
    add_test(NAME AzureAssets.AudioFormats COMMAND AzureAudioCodecTests "${CMAKE_CURRENT_BINARY_DIR}/audio-codec-fixtures")
    set_tests_properties(AzureAssets.AudioFormats PROPERTIES FIXTURES_SETUP AudioCodecFixtures)
    add_executable(AzureEditorAudioWorkflowTests tests/EditorAudioWorkflowTests.cpp)
    target_link_libraries(AzureEditorAudioWorkflowTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.AudioWorkflow COMMAND AzureEditorAudioWorkflowTests "${CMAKE_CURRENT_BINARY_DIR}/audio-codec-fixtures")
    set_tests_properties(AzureEditor.AudioWorkflow PROPERTIES FIXTURES_REQUIRED AudioCodecFixtures)
    add_executable(AzureAssetRoundTripTests tests/AssetRoundTripTests.cpp)
    add_executable(AzureFirstBatchAuthoringTests tests/FirstBatchAuthoringTests.cpp)
    target_link_libraries(AzureFirstBatchAuthoringTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.FirstBatchAuthoring COMMAND AzureFirstBatchAuthoringTests
        "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/test_model.gltf"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g19/evidence/2026-10-12/image-fixtures"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g20/evidence/2026-10-12/audio-fixtures"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g18/evidence/2026-10-12/converted-fixtures/fbx-target/animated.glb")
    add_executable(AzureEditorAssetTransferTests tests/EditorAssetTransferTests.cpp)
    target_link_libraries(AzureEditorAssetTransferTests PRIVATE AzureEditor)
    add_test(NAME AzureEditor.AssetTransfer COMMAND AzureEditorAssetTransferTests
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g19/evidence/2026-10-12/image-fixtures/alpha.png"
        "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/test_model.gltf"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g20/evidence/2026-10-12/audio-fixtures/tone.wav")
    add_test(NAME AzureEditor.AssetTransferGpu COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_asset_transfer_workflows.py" --executable "$<TARGET_FILE:AzureRender>")
    set_tests_properties(AzureEditor.AssetTransferGpu PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 420)
    foreach(_host AzureRender AzurePlayer)
        add_test(NAME "AzureEngine.UnicodeOutputs${_host}" COMMAND "${Python3_EXECUTABLE}"
            "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_unicode_outputs.py" --executable "$<TARGET_FILE:${_host}>"
            --source "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g21/evidence/2026-10-12/roundtrip-outputs/glb-output/test_model.glb")
        set_tests_properties("AzureEngine.UnicodeOutputs${_host}" PROPERTIES LABELS gpu RUN_SERIAL TRUE TIMEOUT 120)
    endforeach()
    add_test(NAME AzureTools.AssetExchange COMMAND "${Python3_EXECUTABLE}"
        "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_asset_exchange.py" "$<TARGET_FILE:AzureAssetExchange>"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g19/evidence/2026-10-12/image-fixtures/alpha.png")
    target_link_libraries(AzureAssetRoundTripTests PRIVATE AzureRenderCore assimp::assimp)
    add_test(NAME AzureAssets.RoundTrip COMMAND AzureAssetRoundTripTests
        "${CMAKE_CURRENT_SOURCE_DIR}/assets_public/test_model.gltf"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g19/evidence/2026-10-12/image-fixtures"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g20/evidence/2026-10-12/audio-fixtures"
        "${CMAKE_CURRENT_SOURCE_DIR}/docs/acceptance/g18/evidence/2026-10-12/converted-fixtures/fbx-target/animated.glb")
endif()

if(WIN32)
    target_link_libraries(AzureRenderCore PRIVATE mfplat mfreadwrite mfuuid ole32 propsys)
endif()

install(FILES docs/licenses/compressed-audio-source.json DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses")
install(DIRECTORY docs/licenses/compressed-audio DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/licenses")

# Installed editor startup uses the existing GLFW/Vulkan backend and project services.
if(WIN32 AND MSVC)
    target_link_options(AzureRender PRIVATE /SUBSYSTEM:WINDOWS /ENTRY:mainCRTStartup)
endif()
target_sources(AzureEditor PRIVATE src/editor/projects/ProjectCenterController.cpp src/editor/projects/ProjectCenterView.cpp)
target_sources(AzureRenderHost PRIVATE src/app/ProjectCenterHost.cpp)

if(WIN32)
    add_executable(AzureGameLauncher WIN32 src/launcher/main.cpp)
    set_property(TARGET AzureGameLauncher PROPERTY MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
    target_link_libraries(AzureGameLauncher PRIVATE nlohmann_json::nlohmann_json shell32)
    install(TARGETS AzureGameLauncher RUNTIME DESTINATION "${CMAKE_INSTALL_BINDIR}")
endif()

if(WIN32)
    file(TO_CMAKE_PATH "${Python3_EXECUTABLE}" AZURE_INSTALL_PYTHON_EXECUTABLE)
    install(CODE "execute_process(COMMAND \"${AZURE_INSTALL_PYTHON_EXECUTABLE}\" \"${CMAKE_CURRENT_SOURCE_DIR}/tools/install_python_runtime.py\" --destination \"\${CMAKE_INSTALL_PREFIX}/share/AzureRender/tools/python\" COMMAND_ERROR_IS_FATAL ANY)")
endif()

target_sources(AzurePlatform PRIVATE src/platform/WindowIcon.cpp)
install(DIRECTORY assets_public/brand DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/assets_public")

if(BUILD_TESTING)
    foreach(_ev_case IN ITEMS
        "ResourceManifest|test_resource_validation_manifest.py"
        "ResourceReader|test_resource_reader_probe.py"
        "ResourceValidationRunner|test_resource_validation_runner.py"
        "ValidationAssetExport|test_validation_asset_export.py"
        "SceneExchange|test_scene_exchange.py"
        "MaterialSemantics|test_material_semantics.py"
        "NativeRenderEvidence|test_native_render*.py"
        "NativeCharacter|test_native_character*.py"
        "NativeMeshUv|test_native_mesh_uv.py"
        "NativeVfxProfile|test_native_vfx_profile.py"
        "NativeColorSpace|test_native_color_space.py"
        "EndfieldNative|test_endfield_native*.py")
        string(REPLACE "|" ";" _ev_parts "${_ev_case}")
        list(GET _ev_parts 0 _ev_name)
        list(GET _ev_parts 1 _ev_file)
        add_test(NAME "AzureTools.${_ev_name}" COMMAND "${Python3_EXECUTABLE}"
            -m unittest discover -s "${CMAKE_CURRENT_SOURCE_DIR}/tools" -p "${_ev_file}")
        set_tests_properties("AzureTools.${_ev_name}" PROPERTIES LABELS tools TIMEOUT 120)
    endforeach()
endif()

if(MSVC)
    get_property(AZURE_LOCAL_TARGETS DIRECTORY PROPERTY BUILDSYSTEM_TARGETS)
    foreach(AZURE_LOCAL_TARGET IN LISTS AZURE_LOCAL_TARGETS)
        get_target_property(AZURE_LOCAL_TYPE ${AZURE_LOCAL_TARGET} TYPE)
        if(AZURE_LOCAL_TYPE STREQUAL "EXECUTABLE")
            target_sources(${AZURE_LOCAL_TARGET} PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/cmake/windows-application.manifest")
        endif()
    endforeach()
endif()
