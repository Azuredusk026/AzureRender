#include "render/ReferenceClipProjection.hpp"
int main(){azurerender::ReferenceClipProjectionProfile p;auto c=azurerender::projectReferenceClip(p,{1,2,3});return c[3]==1?0:1;}
