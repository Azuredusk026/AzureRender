#include "render/ReferenceClipProjection.hpp"
#include <fstream>
#include <cstring>
#include <iostream>
int main(int argc,char** argv){if(argc!=3)return 2;azurerender::ReferenceClipProjectionProfile p;std::ifstream(argv[1],std::ios::binary).read(reinterpret_cast<char*>(&p.parameters),80);std::ifstream input(argv[2],std::ios::binary);std::array<float,8> record;unsigned count=0;while(input.read(reinterpret_cast<char*>(record.data()),32)){auto actual=azurerender::projectReferenceClip(p,{record[0],record[1],record[2]});if(std::memcmp(actual.data(),record.data()+4,16))return 1;++count;}std::cout<<count<<" native CPU clip vectors exact\n";return count==11564?0:1;}