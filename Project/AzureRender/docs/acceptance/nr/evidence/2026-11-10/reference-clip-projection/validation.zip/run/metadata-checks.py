from pathlib import Path
import sys,json,subprocess,hashlib
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
out=Path(__file__).resolve().parent;root=out.parents[2];prior=json.loads((out/'program-identity.json').read_text());rows=[]
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
for configuration,name in [('Release','20261110-030251-hair-main-chroma-public-9e799c'),('Debug','20261110-031856-hair-main-chroma-debug-668bf2')]:
 result=s.maintenance.guarded_run(root/'build',name,[sys.executable,str(out/'build.py'),configuration],900);(out/(configuration.lower()+'-metadata-build-execution.json')).write_text(json.dumps(result,indent=2));assert result.get('exitCode')==0,result
 build=root/'build/runs'/name/configuration.lower();r=subprocess.run([ctest,'--test-dir',str(build),'--show-only=json-v1','-R','^AzureRender.ReferenceClipProjectionGpu$'],capture_output=True,text=True);assert r.returncode==0,r.stderr
 value=json.loads(r.stdout);(out/(configuration.lower()+'-ctest-registration.json')).write_text(json.dumps(value,indent=2));tests=value['tests'];assert len(tests)==1
 properties={p['name']:p['value'] for p in tests[0]['properties']};assert properties['LABELS']==['gpu'] and properties['RUN_SERIAL'] and properties['TIMEOUT']==120,properties
 identity=next(row for row in prior if row['configuration']==configuration.lower());assert hashlib.sha256((build/'AzurePlayer.exe').read_bytes()).hexdigest()==identity['playerSha256'];assert hashlib.sha256((build/'shaders/reference_clip_projection_test.comp.spv').read_bytes()).hexdigest()==identity['sourceShaderSha256']
 rows.append(dict(configuration=configuration,registrationVerified=True,playerAndShaderUnchanged=True))
(out/'metadata-results.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
