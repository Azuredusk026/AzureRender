from pathlib import Path
import os,subprocess,json
out=Path(__file__).resolve().parent;build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
env=os.environ.copy()
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:env.pop(key,None)
env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
command=[str(build/'AzureReferenceClipProjectionGpuTests.exe'),str(out/'fma-nocontract.comp.spv'),str(out/'native-profile.bin'),str(out/'native-records.bin')]
r=subprocess.run(command,cwd=out.parents[2],env=env,capture_output=True,timeout=120);(out/'intel-fma-nocontract-gpu.log').write_bytes(r.stdout+r.stderr);(out/'intel-fma-nocontract-gpu.json').write_text(json.dumps(dict(exitCode=r.returncode,command=command),indent=2));print((r.stdout+r.stderr).decode(errors='replace'));assert r.returncode in [0,1]
