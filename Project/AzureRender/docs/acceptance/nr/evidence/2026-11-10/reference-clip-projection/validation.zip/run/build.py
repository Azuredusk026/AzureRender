from pathlib import Path
import subprocess,json,sys
out=Path(__file__).resolve().parent;root=out.parents[2];main=Path('D:/Projects/FYP/Project/AzureRender')
configuration=sys.argv[1];build=root/'build/runs'/('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration=='Release' else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
cmake='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
commands=[[cmake,'-S',str(root),'-B',str(build)],[cmake,'--build',str(build),'--target','AzureReferenceClipProjectionGpuTests','AzurePlayer','--parallel','4']]
(out/(configuration.lower()+'-final-build-commands.json')).write_text(json.dumps(commands,indent=2))
with (out/(configuration.lower()+'-final-build.log')).open('wb') as log:
 for args in commands:
  command=subprocess.list2cmdline([str(main/'tools/msvc_env.bat')]+args)
  result=subprocess.run(command,cwd=root,shell=True,stdout=log,stderr=subprocess.STDOUT)
  if result.returncode:raise SystemExit(result.returncode)
print(configuration+' production host and output precision targets built')
