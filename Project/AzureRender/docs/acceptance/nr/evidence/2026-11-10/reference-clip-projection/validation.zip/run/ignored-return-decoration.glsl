#ifndef AZURE_REFERENCE_CLIP_PROJECTION_GLSL
#define AZURE_REFERENCE_CLIP_PROJECTION_GLSL
#extension GL_EXT_spirv_intrinsics : require
// NoContraction must decorate each Fma result, including through function calls.
spirv_instruction(set="GLSL.std.450",id=50)
spirv_decorate(42) vec4 azureReferenceFma(vec4 a,vec4 b,vec4 c);
spirv_instruction(set="GLSL.std.450",id=50)
spirv_decorate(42) vec2 azureReferenceFma(vec2 a,vec2 b,vec2 c);
// Columns consume a camera-relative position. Normalized UV jitter follows
// upper-left UV: subtract twice X and add twice Y in homogeneous clip space.
vec4 azureReferenceClipProjection(vec3 position,vec4 columns[4],vec2 jitter){
    precise vec4 value=position.y*columns[1];
    value=azureReferenceFma(columns[0],vec4(position.x),value);
    value=azureReferenceFma(columns[2],vec4(position.z),value);
    value=value+columns[3];
    precise vec2 offset=value.w*jitter;
    value.xy=azureReferenceFma(-offset,vec2(2,-2),value.xy);
    return value;
}
#endif
