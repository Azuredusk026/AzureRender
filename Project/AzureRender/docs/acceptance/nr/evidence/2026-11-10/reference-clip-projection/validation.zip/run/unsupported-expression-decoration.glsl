#ifndef AZURE_REFERENCE_CLIP_PROJECTION_GLSL
#define AZURE_REFERENCE_CLIP_PROJECTION_GLSL
#extension GL_EXT_spirv_intrinsics : require
// Columns consume a camera-relative position. Normalized UV jitter follows
// upper-left UV: subtract twice X and add twice Y in homogeneous clip space.
vec4 azureReferenceClipProjection(vec3 position,vec4 columns[4],vec2 jitter){
    precise vec4 value=position.y*columns[1];
    value=spirv_decorate(42)(fma(columns[0],vec4(position.x),value));
    value=spirv_decorate(42)(fma(columns[2],vec4(position.z),value));
    value=value+columns[3];
    precise vec2 offset=value.w*jitter;
    value.xy=spirv_decorate(42)(fma(-offset,vec2(2,-2),value.xy));
    return value;
}
#endif
