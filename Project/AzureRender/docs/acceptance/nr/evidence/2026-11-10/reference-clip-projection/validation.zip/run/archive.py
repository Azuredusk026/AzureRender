from pathlib import Path
import hashlib,json,re,zipfile
engine=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender')
out=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda name:json.loads((out/name).read_text(encoding='utf-8'))
frozen=read('frozen-source.json')
assert all(sha(engine/name)==digest for name,digest in frozen.items())
gpu=read('gpu-results.json');assert len(gpu)==4 and all(x['exitCode']==0 and x['validationClean'] for x in gpu)
assert read('default-four-results.json')['allExact']
assert all(x['registrationVerified'] and x['playerAndShaderUnchanged'] for x in read('metadata-results.json'))
docs=['docs/runtime/reference-clip-projection.md','docs/acceptance/nr/reference-clip-projection.md']
dest=engine/'docs/acceptance/nr/evidence/2026-11-10/reference-clip-projection';dest.mkdir(parents=True,exist_ok=True)
files={f'source/{name}':engine/name for name in list(frozen)+docs}
allowed={'.json','.log','.py','.bin','.spv','.spvasm','.glsl','.cpp','.comp'}
files.update({f'run/{p.name}':p for p in out.iterdir() if p.is_file() and p.suffix in allowed})
frames=out/'default-four-frames'
files.update({f'run/default-four-frames/{p.name}':p for p in frames.iterdir() if p.is_file() and p.suffix=='.json'})
members={name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in files.items()}
archive=dest/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
    for name,p in sorted(files.items()):z.write(p,name)
    z.writestr('manifest.json',json.dumps(members,ensure_ascii=False,indent=2))
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,info in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==info['sha256']
result={'status':'qualified-public-kernel-scene-binding-pending','overall':'failed-user-review','nativePoints':11564,'analyticPoints':8192,'configurations':['Release','Debug'],'devices':['NVIDIA','Intel'],'exactGpuComponents':316096,'projectionRejections':9,'shaderRejections':5,'defaultFour':read('default-four-results.json'),'programIdentity':read('program-identity.json'),'metadata':read('metadata-results.json'),'source':frozen,'archive':{'members':len(members)+1,'bytes':archive.stat().st_size,'sha256':sha(archive)},'remaining':['Production camera frame binding','Actual depth producer','Material sampling policy and native visual gates']}
(dest/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in docs:
    p=engine/name
    for link in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
        if not link.startswith('https:'):assert (p.parent/link).exists(),link
print(json.dumps(result['archive']))
