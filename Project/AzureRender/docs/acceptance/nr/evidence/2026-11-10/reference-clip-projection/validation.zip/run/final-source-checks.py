from pathlib import Path
import sys,json,subprocess
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
out=Path(__file__).resolve().parent;root=out.parents[2];pruned=[]
for configuration,name in [('Release','20261110-030251-hair-main-chroma-public-9e799c'),('Debug','20261110-031856-hair-main-chroma-debug-668bf2')]:
 result=s.maintenance.guarded_run(root/'build',name,[sys.executable,str(out/'build.py'),configuration],900)
 (out/(configuration.lower()+'-corrected-build-execution.json')).write_text(json.dumps(result,indent=2));assert result.get('exitCode')==0,result
 build=root/'build/runs'/name/configuration.lower();catalog=json.loads((build/'shader-reload.json').read_text());registered={p['output'] for p in catalog['programs']}
 stale=list((build/'shaders').glob('*_uvquad.frag.spv'));assert len(stale)==168
 for path in stale:
  absolute=path.resolve();assert absolute.parent==(build/'shaders').resolve() and path.name not in registered
  pruned.append(str(absolute));absolute.unlink()
(out/'isolated-candidate-shader-prune.json').write_text(json.dumps(dict(scope='Only the 168 private candidate programs per owned build; all current catalog programs retained',files=pruned),indent=2))
raise SystemExit(subprocess.run([sys.executable,str(out/'gpu.py')],timeout=240).returncode)
