from pathlib import Path
import json,os,re,subprocess,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];rows=[]
for configuration,folder in [('release','20261110-030251-hair-main-chroma-public-9e799c/release'),('debug','20261110-031856-hair-main-chroma-debug-668bf2/debug')]:
 build=root/'build/runs'/folder
 for device in ['nvidia','intel']:
  env=os.environ.copy()
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
  env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
  command=[str(build/'AzureReferenceClipProjectionGpuTests.exe'),str(build/'shaders/reference_clip_projection_test.comp.spv'),str(out/'native-profile.bin'),str(out/'native-records.bin')]
  label=configuration+'-'+device
  with (out/(label+'-gpu.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  text=(out/(label+'-gpu.log')).read_text(errors='replace');row=dict(configuration=configuration,device=device,exitCode=r.returncode,command=command,validationClean=not bool(re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I)));rows.append(row);(out/'gpu-results.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,text[-1000:],flush=True)
  assert r.returncode==0 and row['validationClean'],text[-2000:]
  assert '19756 points / 79024 exact clip components' in text
  assert ('NVIDIA' in text)==(device=='nvidia')
