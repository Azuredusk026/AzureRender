import json,os,subprocess,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;config=sys.argv[1];build=root/('build/ninja-msvc-'+config.lower())
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,verify
os.environ.update(managed_environment(out/'tmp'));os.environ['PYTHONDONTWRITEBYTECODE']='1'
verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
cpu=['ScreenObjectVisibility','NullRhi','NullRhiPass','RenderGraph','ShadowHistoryCache','DepthPrefillRecording','MaterialClassEarlyDepth','ObjectShadowRecording','VulkanPipelineCache']
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
rows=[]
common=('cpu',r'^AzureRender\.('+'|'.join(cpu)+r')$|^AzureEngine\.ModuleBoundar(yFixtures|ies)$|^AzureAssets\.TextureContainers$',None)
if config=='Release' and (out/'release-checks.json').exists():
    rows=json.loads((out/'release-checks.json').read_text())
    assert len(rows)==1 and len(rows[0]['tests'])==11 and not rows[0]['failuresOrSkips'] and rows[0]['exitCode']==0
    common=('common-missing',r'^AzureAssets\.TextureContainers$',None)
for label,pattern,driver in [common,('nvidia',r'^AzureRender\.ScreenObjectVisibility(Reference)?Gpu$','*nv-vk64*'),('intel',r'^AzureRender\.ScreenObjectVisibility(Reference)?Gpu$','*igvk64*')]:
    name=config.lower()+'-'+label
    if driver:
        os.environ.update(VK_LOADER_DRIVERS_SELECT=driver,VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
        for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(key,None)
    command=[ctest,'--test-dir',str(build),'-R',pattern,'-V','--output-junit',str(out/(name+'.xml'))]
    start=time.monotonic()
    with (out/(name+'.log')).open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=220)
    tests=list(ET.parse(out/(name+'.xml')).getroot().iter('testcase'))
    failures=[t.attrib['name'] for t in tests if t.find('failure') is not None or t.find('skipped') is not None]
    row=dict(name=name,exitCode=p.returncode,seconds=time.monotonic()-start,tests=[t.attrib['name'] for t in tests],failuresOrSkips=failures);rows.append(row)
    (out/(config.lower()+'-checks.json')).write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
    assert p.returncode==0 and not failures and len(tests)==(12 if label=='cpu' else 1 if label=='common-missing' else 2),row
assert inputs(root)==before
assert sum(len(row['tests']) for row in rows)==16
print(config+' sixteen effective checks passed with zero skips')
