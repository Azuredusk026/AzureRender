import hashlib,json,sys,zipfile
from pathlib import Path
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,inputs
for config in ['release','debug']:verify(root,json.loads((root/('build/ninja-msvc-'+config)/'build-provenance.json').read_text()))
checks={c:json.loads((out/(c+'-checks.json')).read_text()) for c in ['release','debug']}
assert all(sum(len(r['tests']) for r in rows)==16 and all(r['exitCode']==0 and not r['failuresOrSkips'] for r in rows) for rows in checks.values())
capture=json.loads((out/'capture-results.json').read_text());assert len(capture['frames'])==4 and all(r['changedPixels']==0 for r in capture['frames'])
comparison=json.loads((out/'shader-comparison.json').read_text());assert comparison['changedPrograms']==['screen_object_visibility.frag.spv']
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(out/'source-inputs.json').write_text(json.dumps(inputs(root),indent=2))
evidence=root/'docs/acceptance/nr/evidence/2026-11-10/visibility-reference-integration';evidence.mkdir(parents=True,exist_ok=True)
names=['build.py','checks.py','capture.py','finish.py','archive.py','targets.json','source-inputs.json','shader-comparison.json','release-checks.json','debug-checks.json','initial-selector-failure.log','capture-command.json','capture-results.json','capture.log','frames/capture_manifest.json']
for c in ['release','debug']:
    names += [c+'-'+n for n in ['configure.log','build.log','build-provenance.json','cpu.log','cpu.xml','nvidia.log','nvidia.xml','intel.log','intel.xml']]
names+=['release-common-missing.log','release-common-missing.xml']
with zipfile.ZipFile(evidence/'validation.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name in names:z.write(out/name,name)
assert (evidence/'validation.zip').stat().st_size<8*1024*1024
report=dict(status='mainline-integration-passed',sourceCommit='da56ac4',integrationCommit='1ee5757',checks=checks,effectiveChecks=32,skipped=0,capture=capture,shaderComparison=comparison,selectorRepair=dict(initialPassed=11,missingTest='AzureAssets.TextureContainers',missingPassed=1,priorResultsReused=True),overallVisualAcceptance='failed-user-review',formalPerformancePassed=False,archiveBytes=(evidence/'validation.zip').stat().st_size,archiveSha256=digest(evidence/'validation.zip'),archiveFiles=[dict(name=n,bytes=(out/n).stat().st_size,sha256=digest(out/n)) for n in names])
(evidence/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','effectiveChecks','skipped','archiveBytes','archiveSha256']}))
