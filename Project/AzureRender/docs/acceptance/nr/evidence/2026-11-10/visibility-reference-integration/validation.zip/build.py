import json,os,shutil,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'))
os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
if '--inside' not in sys.argv:
    raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside',*sys.argv[1:]]).returncode)
config=sys.argv[-1];assert config in ['Release','Debug'];build=root/('build/ninja-msvc-'+config.lower())
targets=['AzureScreenObjectVisibilityTests','AzureScreenObjectVisibilityGpuTests','AzureRenderNullRhiTests','AzureRenderNullRhiPassTests','AzureRenderRenderGraphTests','AzureShadowHistoryCacheTests','AzureDepthPrefillRecordingTests','AzureMaterialClassEarlyDepthTests','AzureObjectShadowRecordingTests','AzureTextureContainerTests','AzureVulkanPipelineCacheTests']
(out/'targets.json').write_text(json.dumps(targets,indent=2))
with (out/(config.lower()+'-configure.log')).open('wb') as log:subprocess.run(['cmake','--preset','msvc-'+config.lower(),'-DAZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION=OFF','-DAZURE_ENABLE_SHADOW_HISTORY=OFF'],stdout=log,stderr=subprocess.STDOUT,check=True)
command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
for target in targets:command+=['--test-target',target]
with (out/(config.lower()+'-build.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
shutil.copyfile(build/'build-provenance.json',out/(config.lower()+'-build-provenance.json'))
print(config+' runtime hosts and eleven affected targets built',flush=True)
