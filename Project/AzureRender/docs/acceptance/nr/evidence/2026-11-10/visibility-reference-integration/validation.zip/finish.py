import subprocess,sys
from pathlib import Path
out=Path(__file__).resolve().parent
subprocess.run([sys.executable,'-X','utf8','-B',str(out/'checks.py'),'Debug'],check=True,timeout=230)
subprocess.run([sys.executable,'-X','utf8','-B',str(out/'capture.py')],check=True,timeout=580)
