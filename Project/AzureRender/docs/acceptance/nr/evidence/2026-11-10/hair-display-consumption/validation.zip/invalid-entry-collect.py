from pathlib import Path
import renderdoc as rd
import json,traceback,sys
out=Path(__file__).resolve().parent;r=dict(status='starting');cap=rd.OpenCaptureFile();c=None
try:
 assert cap.OpenFile('D:/Projects/FYP/Project/AzureRender/build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc','',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded;c.SetFrameEvent(567,True);pipe=c.GetPipelineState();shader=pipe.GetShader(rd.ShaderStage.Pixel);reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel);(out/'display-original.spv').write_bytes(bytes(reflection.rawBytes));r['target']=dict(resource=str(pipe.GetOutputTargets()[0].resource),format=pipe.GetOutputTargets()[0].format.Name());r['resources']=[dict(index=u.access.index,resource=str(u.descriptor.resource),format=u.descriptor.format.Name()) for u in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel)];r['declaredResources']=[dict(name=x.name,binding=x.fixedBindNumber) for x in reflection.readOnlyResources];r['constants']=[]
 def variable(v):return dict(name=v.name,type=str(v.type),f32=list(v.value.f32v),u32=list(v.value.u32v),members=[variable(x) for x in v.members])
 for i,block in enumerate(reflection.constantBlocks):
  entry=dict(name=block.name,byteSize=block.byteSize,bufferBacked=block.bufferBacked)
  try:
   bound=pipe.GetConstantBuffer(rd.ShaderStage.Pixel,i,0);entry['binding']=dict(resource=str(bound.resourceId),offset=bound.byteOffset,size=bound.byteSize);values=c.GetCBufferVariableContents(pipe.GetGraphicsPipelineObject(),shader,rd.ShaderStage.Pixel,pipe.GetShaderEntryPoint(rd.ShaderStage.Pixel),i,bound.resourceId,bound.byteOffset,bound.byteSize);entry['values']=[variable(v) for v in values]
  except Exception:entry['error']=traceback.format_exc()
  r['constants'].append(entry)
 r['debugMessages']=[str(m.description) for m in c.GetDebugMessages()];r['status']='exported'
except BaseException:r.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 cap.Shutdown();(out/'export.json').write_text(json.dumps(r,indent=2))
sys.exit(0 if r['status']=='exported' else 1)
