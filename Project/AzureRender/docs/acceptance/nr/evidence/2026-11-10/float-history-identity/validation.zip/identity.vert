#version 450
layout(push_constant) uniform Parameters {uint base;uint mode;float depth;uint reserved;} p;
void main(){
    const vec2 corners[3]=vec2[3](vec2(-1,-1),vec2(3,-1),vec2(-1,3));
    gl_Position=vec4(corners[gl_VertexIndex],p.depth,1);
}
