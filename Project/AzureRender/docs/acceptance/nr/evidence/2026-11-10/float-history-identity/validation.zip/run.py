from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest
os.environ.update(managed_environment(out/'tmp'));before=inputs(root);rows=[]
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(key,None)
for label,selector in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 os.environ['VK_LOADER_DRIVERS_SELECT']=selector;start=time.monotonic()
 with (out/(label+'.log')).open('wb') as log:p=subprocess.run([str(out/'PrivateFloatIdentity.exe'),str(out)],stdout=log,stderr=subprocess.STDOUT,timeout=120)
 text=(out/(label+'.log')).read_text(errors='replace');assert p.returncode==0,(label,p.returncode,text[-1200:])
 result=json.loads(next(line for line in text.splitlines() if line.startswith('{"device"')));assert result['scenarios']==57 and result['checkedPixels']==119537664 and result['validationMessages']==0
 assert ('NVIDIA' in result['device']) if label=='nvidia' else ('Intel' in result['device'])
 result.update(label=label,seconds=time.monotonic()-start);rows.append(result);print(json.dumps(result),flush=True)
assert inputs(root)==before and all(digest(Path(p))==h for p,h in json.loads((out/'baseline-programs.json').read_text()).items())
(out/'results.json').write_text(json.dumps(dict(status='float-identity-local-gpu-contract-passed',devices=rows,runtimeSourceUnchanged=True,programsUnchanged=True,nativeSceneCaptures=0,wholeFrameTimingRuns=0),indent=2))
