from pathlib import Path
import json,os,shutil,subprocess,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import digest,inputs,verify
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
programs={str(p):digest(p) for p in (build/'shaders').glob('*.spv')};(out/'baseline-programs.json').write_text(json.dumps(programs,indent=2))
fixture=(root/'tests/support/VulkanComputeFixture.hpp').read_text().replace('debug.messageSeverity=VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT;','debug.messageSeverity=VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT|VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT;')
(out/'FloatIdentityFixture.hpp').write_text(fixture)
target=root/'tests/ShadowHistoryCacheGpuTests.cpp';assert not subprocess.check_output(['git','status','--porcelain','--',str(target)]).strip(),'Temporary test entry has existing changes'
baseline=target.read_bytes();(out/'ShadowHistoryCacheGpuTests.cpp.baseline').write_bytes(baseline)
command=['cmake','--build','--preset','msvc-release','--target','AzureShadowHistoryCacheGpuTests','-j','3']
try:
 target.write_text((out/'FloatIdentity.cpp').read_text().replace('FLOAT_IDENTITY_FIXTURE',(out/'FloatIdentityFixture.hpp').as_posix()))
 with (out/'private-build.log').open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=170)
 shutil.copyfile(build/'AzureShadowHistoryCacheGpuTests.exe',out/'PrivateFloatIdentity.exe')
finally:
 target.write_bytes(baseline)
 with (out/'restore-test-build.log').open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=170)
for name in ['identity.vert','identity.frag']:
 with (out/(name+'-compile.log')).open('wb') as log:
  subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe',str(out/name),'-o',str(out/(name+'.spv'))],stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.3',str(out/(name+'.spv'))],stdout=log,stderr=subprocess.STDOUT,check=True)
assert target.read_bytes()==baseline and inputs(root)==before and all(digest(Path(p))==h for p,h in programs.items())
for config in ['debug','release']:verify(root,json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text()))
(out/'build-results.json').write_text(json.dumps(dict(runtimeSourceUnchanged=True,programsUnchanged=True,originalTestSourceRestored=True,originalTestRebuilt=True,bothConfigurationsVerified=True,privateExecutableSha256=digest(out/'PrivateFloatIdentity.exe')),indent=2))
print('Private GPU fixture built; original test source and executable restored')
