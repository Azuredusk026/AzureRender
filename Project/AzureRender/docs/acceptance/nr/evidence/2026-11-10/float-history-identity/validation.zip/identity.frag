#version 450
layout(early_fragment_tests) in;
layout(push_constant) uniform Parameters {uint base;uint mode;float depth;uint reserved;} p;
layout(location=0) out vec4 color;
layout(location=1) out vec4 normal;
layout(location=2) out vec4 identity;
void main(){
    uvec2 pixel=uvec2(gl_FragCoord.xy);
    if(p.mode==1u&&(pixel.x&1u)!=0u)discard;
    uint offset=pixel.y*1024u+pixel.x;
    float value=p.base<=16777215u&&offset<=16777215u-p.base?float(p.base+offset):-1.0;
    if(p.mode==1u)value=-1.0;
    if(p.mode==2u)value=7.0;
    color=vec4(.5,.5,.5,1);normal=vec4(.5,.5,1,1);identity=vec4(value,0,0,1);
}
