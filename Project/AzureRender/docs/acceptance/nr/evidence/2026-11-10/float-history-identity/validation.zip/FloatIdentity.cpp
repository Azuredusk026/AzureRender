#include "FLOAT_IDENTITY_FIXTURE"
#include "resources/BinaryFile.hpp"
#include <array>
#include <cmath>
#include <cstring>
#include <iostream>
using namespace azurerender;
namespace {
constexpr unsigned extent=1024,count=extent*extent,maxKey=16777215;
struct Push {std::uint32_t base,mode;float depth;std::uint32_t reserved=0;};
void require(bool condition,const char* message){if(!condition)throw std::runtime_error(message);}
}
int main(int argc,char** argv)try{
    require(argc==2,"Expected private shader directory");
    test::VulkanComputeFixture host(true);auto& backend=*host.backend;
    VkFormatProperties capabilities{};vkGetPhysicalDeviceFormatProperties(host.physical,VK_FORMAT_R32_SFLOAT,&capabilities);
    const auto needed=VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT|VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BLEND_BIT|VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT;
    require((capabilities.optimalTilingFeatures&needed)==needed,"R32 float identity requires color blending and sampling");
    std::array<rhi::GpuImage,4> images{};std::array<VkImageView,4> views{};
    VkRenderPass clearPass{},loadPass{};VkFramebuffer clearFrame{},loadFrame{};
    VkDescriptorSetLayout setLayout{};VkPipelineLayout layout{};VkShaderModule vertex{},fragment{};
    std::array<VkPipeline,3> pipelines{},overlays{};rhi::GpuBuffer readback{};
    auto cleanup=std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*){
        for(auto pipeline:pipelines)if(pipeline)backend.destroyPipeline(pipeline);
        for(auto pipeline:overlays)if(pipeline)backend.destroyPipeline(pipeline);
        if(vertex)backend.destroyShaderModule(vertex);if(fragment)backend.destroyShaderModule(fragment);
        if(layout)backend.destroyPipelineLayout(layout);if(setLayout)backend.destroyDescriptorSetLayout(setLayout);
        if(clearFrame)backend.destroyFramebuffer(clearFrame);if(loadFrame)backend.destroyFramebuffer(loadFrame);
        if(clearPass)backend.destroyRenderPass(clearPass);if(loadPass)backend.destroyRenderPass(loadPass);
        for(auto view:views)if(view)backend.destroyImageView(view);
        for(auto& image:images)host.allocator.destroyImage(image);host.allocator.destroyBuffer(readback);
    });
    const std::array<VkFormat,4> formats{VK_FORMAT_R8_UNORM,VK_FORMAT_R8_UNORM,VK_FORMAT_R32_SFLOAT,VK_FORMAT_D32_SFLOAT};
    rhi::RenderPassDesc pass;pass.depthAttachment=3;pass.externalReadDependency=true;
    for(unsigned i=0;i<4;++i){
        const bool depth=i==3;
        images[i]=host.allocator.createImage2D(extent,extent,formats[i],depth?VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT:VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT|(i==2?VK_IMAGE_USAGE_TRANSFER_SRC_BIT:0));
        views[i]=backend.createImageView(images[i].image,formats[i],depth?VK_IMAGE_ASPECT_DEPTH_BIT:VK_IMAGE_ASPECT_COLOR_BIT,1);
        const auto initial=depth?VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL:VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
        const auto final=i==2?VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL:initial;
        pass.attachments.push_back({formats[i],initial,final,true,true,depth});
    }
    clearPass=backend.createRenderPass(pass);
    for(auto& attachment:pass.attachments)attachment.clear=false;
    loadPass=backend.createRenderPass(pass);
    const std::vector<VkImageView> attachments(views.begin(),views.end());
    clearFrame=backend.createFramebuffer({clearPass,attachments,extent,extent});loadFrame=backend.createFramebuffer({loadPass,attachments,extent,extent});
    setLayout=backend.createDescriptorSetLayout({});
    const rhi::PushConstantRangeDesc range{VK_SHADER_STAGE_VERTEX_BIT|VK_SHADER_STAGE_FRAGMENT_BIT,sizeof(Push)};
    layout=backend.createPipelineLayout(setLayout,&range);
    vertex=backend.createShaderModule(readBinaryFile(std::string(argv[1])+"/identity.vert.spv"));
    fragment=backend.createShaderModule(readBinaryFile(std::string(argv[1])+"/identity.frag.spv"));
    for(unsigned mode=0;mode<3;++mode){
        rhi::GraphicsPipelineDesc desc;desc.vertexShader=vertex;desc.fragmentShader=fragment;desc.layout=layout;desc.renderPass=clearPass;
        desc.colorAttachmentCount=3;desc.colorWriteMasks.assign(3,VK_COLOR_COMPONENT_R_BIT);desc.cullMode=VK_CULL_MODE_NONE;
        desc.alphaBlend=true;desc.premultipliedAlpha=mode==1;desc.primaryColorBlend=mode==2?rhi::PrimaryColorBlend::Additive:rhi::PrimaryColorBlend::Alpha;
        pipelines[mode]=backend.createGraphicsPipeline(desc);desc.depthWrite=false;overlays[mode]=backend.createGraphicsPipeline(desc);
    }
    readback=host.allocator.createBuffer(count*4,VK_BUFFER_USAGE_TRANSFER_DST_BIT,true);
    bool initialized=false;std::uint64_t checked=0;unsigned scenarios=0;
    const auto execute=[&](unsigned blend,std::uint32_t base,bool overlay){
        host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer raw){
            for(unsigned i=0;i<4;++i){
                const bool depth=i==3;const auto target=depth?VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL:VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
                const auto prior=!initialized?VK_IMAGE_LAYOUT_UNDEFINED:i==2?VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL:target;
                commands.imageBarrier({images[i].image,prior,target,1,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,
                    VkPipelineStageFlags(depth?VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT|VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT:VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT),
                    VK_ACCESS_MEMORY_READ_BIT|VK_ACCESS_MEMORY_WRITE_BIT,VkAccessFlags(depth?VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_READ_BIT|VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT:VK_ACCESS_COLOR_ATTACHMENT_READ_BIT|VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT),
                    VkImageAspectFlags(depth?VK_IMAGE_ASPECT_DEPTH_BIT:VK_IMAGE_ASPECT_COLOR_BIT)});
            }
            rhi::RenderPassBeginDesc begin;begin.renderPass=overlay?loadPass:clearPass;begin.framebuffer=overlay?loadFrame:clearFrame;
            begin.extent={extent,extent};begin.clearValues.resize(4);begin.clearValues[2].color.float32[0]=-1;begin.clearValues[3].depthStencil={1,0};
            commands.beginRenderPass(begin);commands.setViewport(extent,extent);commands.setScissor({extent,extent});
            auto draw=[&](VkPipeline pipeline,Push push){commands.bindPipeline(pipeline);commands.pushConstants(layout,VK_SHADER_STAGE_VERTEX_BIT|VK_SHADER_STAGE_FRAGMENT_BIT,0,&push,sizeof(push));commands.draw(3);};
            draw(overlay?overlays[blend]:pipelines[blend],{base,overlay?1U:0U,overlay?.4F:.6F});
            if(overlay)draw(pipelines[blend],{base,2,.9F});
            commands.endRenderPass();
            commands.imageBarrier({images[2].image,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,1,
                VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT});
            commands.bufferBarrier({readback.buffer,0,readback.size,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT|VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_MEMORY_READ_BIT|VK_ACCESS_MEMORY_WRITE_BIT|VK_ACCESS_HOST_READ_BIT,VK_ACCESS_TRANSFER_WRITE_BIT});
            VkBufferImageCopy copy{};copy.imageSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};copy.imageExtent={extent,extent,1};
            vkCmdCopyImageToBuffer(raw,images[2].image,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,readback.buffer,1,&copy);
            commands.bufferBarrier({readback.buffer,0,readback.size,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
        });
        initialized=true;host.allocator.invalidate(readback,0,readback.size);
        const auto* values=static_cast<const float*>(readback.mapped);
        for(unsigned i=0;i<count;++i){
            const auto key=std::uint64_t(base)+i;
            const float expected=overlay&&((i%extent)&1U)==0U?-1.F:key<=maxKey?static_cast<float>(key):-1.F;
            if(!std::isfinite(values[i])||values[i]!=expected)throw std::runtime_error("Float identity mismatch: blend="+std::to_string(blend)+" base="+std::to_string(base)+" pixel="+std::to_string(i)+" actual="+std::to_string(values[i])+" expected="+std::to_string(expected));
            ++checked;
        }
    };
    for(unsigned blend=0;blend<3;++blend){
        for(unsigned chunk=0;chunk<16;++chunk){const auto base=chunk*count;execute(blend,base,false);execute(blend,base,true);++scenarios;}
        for(auto base:{16777214U,16777216U,UINT32_MAX}){execute(blend,base,false);execute(blend,base,true);++scenarios;}
    }
    cleanup.reset();
    require(!host.allocator.statistics().liveImages&&!host.allocator.statistics().liveBuffers,"Float identity allocations leaked");
    host.close();require(!host.errors.load(),"Float identity validation message");
    std::cout<<"{\"device\":\""<<host.properties.deviceName<<"\",\"scenarios\":"<<scenarios<<",\"checkedPixels\":"<<checked<<",\"validationMessages\":0,\"liveImages\":0,\"liveBuffers\":0}"<<std::endl;
    return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
