from pathlib import Path
import json,shutil,numpy as np
out=Path(__file__).resolve().parent;main=Path('D:/Projects/FYP/Project/AzureRender')
source=main/'build/runs/20261108-045252-screen-object-visibility-ca2907'
config=json.loads((source/'calibration-inputs.json').read_text())
config['queries']=str(source/'queries.bin');config['expected']=str(source/'expected.bin')
config['profile']=str(out.parent/'20261110-003031-reciprocal-compact-profile-4e7929/correction.bin')
(out/'hair-calibration.json').write_text(json.dumps(config,indent=2))
prior=main/'build/runs/20261109-181501-native-producer-gpu-intermediates-de1e3d'
query=np.fromfile(prior/'receiver-queries.bin',dtype='<f4').reshape(-1,3,4)[:,0,:].copy();query.tofile(out/'receiver-queries.bin')
np.fromfile(prior/'expected.u8',dtype='u1').astype('<u4').tofile(out/'receiver-expected.bin')
config.update(queries=str(out/'receiver-queries.bin'),expected=str(out/'receiver-expected.bin'))
(out/'receiver-calibration.json').write_text(json.dumps(config,indent=2))
code=(source/'calibration.cpp').read_text()
needle='ScreenObjectVisibilityGpu owner(backend,{width,height},1,ScreenObjectVisibilityShaders::load(argv[2]));'
assert needle in code
code=code.replace(needle,'''ScreenObjectVisibilityNumerics numerics;
        const auto profile=readBinaryFile(config["profile"].get<std::string>());
        numerics.mode=ScreenObjectVisibilityArithmetic::ProfileV1;
        numerics.reciprocalCorrections.resize(profile.size()/4);
        std::memcpy(numerics.reciprocalCorrections.data(),profile.data(),profile.size());
        ScreenObjectVisibilityGpu owner(backend,{width,height},1,ScreenObjectVisibilityShaders::load(argv[2]),numerics);''')
# Separate output names for the two frozen scopes.
code=code.replace('"-calibration-rg8.bin"','"-"+config["scope"].get<std::string>()+"-rg8.bin"').replace('"-calibration.json"','"-"+config["scope"].get<std::string>()+"-result.json"')
(out/'calibration.cpp').write_text(code)
for scope in ['hair','receiver']:
 p=out/(scope+'-calibration.json');c=json.loads(p.read_text());c['scope']=scope;p.write_text(json.dumps(c,indent=2))
print('Prepared public production calibration for 17017 hair and 49384 receiver samples')
