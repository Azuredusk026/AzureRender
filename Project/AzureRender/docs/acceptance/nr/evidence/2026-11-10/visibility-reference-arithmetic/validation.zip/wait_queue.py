from pathlib import Path
import sys,time,json
out=Path(__file__).resolve().parent;sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared
start=time.monotonic()
while True:
 context=shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-public-numerics-final',out)
 try:context.__enter__();break
 except ValueError as error:
  if not any(s in str(error) for s in ['busy','still running']):raise
  if time.monotonic()-start>=180:raise TimeoutError('Queue wait exceeded 180 seconds; no candidate executed')
  time.sleep(1)
try:
 result=shared.maintenance.guarded_run(out.parents[1],out.name,[sys.executable,str(out/'final_batch.py')],240)
 (out/'final-execution.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
finally:context.__exit__(None,None,None)
sys.exit(result.get('exitCode',2))
