from pathlib import Path
import os,subprocess,json,sys
out=Path(__file__).resolve().parent;root=out.parents[2];main=Path('D:/Projects/FYP/Project/AzureRender');sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin');mode=sys.argv[1]
if mode=='build':
 with (out/'final-build.log').open('wb') as log:
  for part in ['green','gpu']:
   subprocess.run([str(main/'tools/msvc_env.bat'),sys.executable,str(out/'build_contract.py'),part],check=True,stdout=log,stderr=subprocess.STDOUT)
  subprocess.run([str(out/'contract.exe')],check=True,stdout=log,stderr=subprocess.STDOUT)
  for shader in ['screen_object_visibility.frag','screen_object_visibility.vert']:
   subprocess.run([str(sdk/'glslc.exe'),str(root/'shaders'/shader),'-o',str(out/(shader+'.spv'))],check=True,stdout=log,stderr=subprocess.STDOUT)
  for name in ['oracle','domain']:
   subprocess.run([str(sdk/'glslc.exe'),'-I'+str(root/'shaders'),'-I'+str(out.parent/'20261109-234658-native-reciprocal-domain-2562a0'),str(out/(name+'.comp')),'-o',str(out/(name+'.spv'))],check=True,stdout=log,stderr=subprocess.STDOUT)
  for name in ['screen_object_visibility.frag','screen_object_visibility.vert','oracle','domain']:
   subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3',str(out/(name+'.spv'))],check=True,stdout=log,stderr=subprocess.STDOUT)
else:
 subprocess.run([sys.executable,str(out/'run_gpu.py'),mode],check=True)
 os.environ.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if mode=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer')
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(key,None)
 os.environ['PATH']=str(main/'build/ninja-msvc-release')+';'+os.environ['PATH']
 for name in ['oracle','domain']:
  with (out/(mode+'-'+name+'.log')).open('wb') as log:
   subprocess.run([str(out.parent/'20261109-234658-native-reciprocal-domain-2562a0/collector.exe'),str(out/(name+'.spv')),str(out/(name+'-fixture.json')),str(out/(mode+'-'+name+'.bin'))],check=True,stdout=log,stderr=subprocess.STDOUT)
print(mode+' validation completed')
