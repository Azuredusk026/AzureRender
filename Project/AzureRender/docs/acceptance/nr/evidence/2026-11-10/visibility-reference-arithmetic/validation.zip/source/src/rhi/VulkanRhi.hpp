#pragma once

#include "rhi/GpuAllocator.hpp"
#include "rhi/Rhi.hpp"
#include "rhi/PipelineInspection.hpp"

#include <functional>
#include <unordered_map>
#include <mutex>
#include <atomic>

namespace azurerender::rhi {

// Production backend. Owns nothing beyond what its create calls return;
// callers destroy through the matching destroy methods.
class VulkanRhi final : public IRhi {
public:
    struct CacheUsage {std::uint64_t requests=0,hits=0,feedback=0;};
    CacheUsage pipelineCacheUsage()const noexcept{return {cacheRequests_.load(),cacheHits_.load(),cacheFeedback_.load()};}
    VulkanRhi(
        VkDevice device,
        VkPhysicalDevice physicalDevice,
        VkQueue graphicsQueue,
        VkCommandPool commandPool,
        GpuAllocator& allocator, bool samplerAnisotropyEnabled=false,
        PipelineInspection* pipelineInspection=nullptr,bool sampleShadingEnabled=false,bool exactDepthBiasEnabled=false,
        VkPipelineCache pipelineCache=VK_NULL_HANDLE)
        : device_(device),
          physicalDevice_(physicalDevice),
          graphicsQueue_(graphicsQueue),
          commandPool_(commandPool),
          samplerAnisotropyEnabled_(samplerAnisotropyEnabled),allocator_(&allocator),
          pipelineInspection_(pipelineInspection),sampleShadingEnabled_(sampleShadingEnabled),exactDepthBiasEnabled_(exactDepthBiasEnabled),pipelineCache_(pipelineCache) {
        if(pipelineCache_&&physicalDevice_){VkPhysicalDeviceProperties properties{};vkGetPhysicalDeviceProperties(physicalDevice_,&properties);cacheFeedbackEnabled_=properties.apiVersion>=VK_API_VERSION_1_3;}
    }

    GpuAllocator& allocator() override { return *allocator_; }
    bool supportsSampledImage(VkFormat format,bool linearFilter) const override;
    bool supportsStorageImage(VkFormat format) const override;
    bool supportsFragmentStorageBuffers(VkDeviceSize bytes,std::uint32_t count=1) const override {
        if(!physicalDevice_||!bytes||!count)return false;
        VkPhysicalDeviceProperties properties{};vkGetPhysicalDeviceProperties(physicalDevice_,&properties);
        return bytes<=properties.limits.maxStorageBufferRange&&count<=properties.limits.maxPerStageDescriptorStorageBuffers
            &&count<=properties.limits.maxDescriptorSetStorageBuffers;
    }
    VkSampleCountFlags imageSampleCounts(VkFormat,VkImageUsageFlags) const override;
    bool supportsSampleShading() const noexcept override {return sampleShadingEnabled_;}
    bool supportsExactDepthBias() const noexcept override {return exactDepthBiasEnabled_;}

    void copyBuffer(
        const GpuBuffer& source,
        const GpuBuffer& destination,
        VkDeviceSize size) override;
    void transitionImageLayout(
        const GpuImage& image,
        VkImageLayout oldLayout,
        VkImageLayout newLayout,
        std::uint32_t mipLevels) override;
    void copyBufferToImage(
        const GpuBuffer& source,
        const GpuImage& destination,
        std::uint32_t width,
        std::uint32_t height,
        std::uint32_t mipLevels = 1, std::uint32_t bytesPerTexel = 4) override;
    void clearImage(const GpuImage& image) override;
    void generateMipmaps(
        const GpuImage& image,
        VkFormat format,
        std::uint32_t width,
        std::uint32_t height,
        std::uint32_t mipLevels) override;

    VkImageView createImageView(
        VkImage image,
        VkFormat format,
        VkImageAspectFlags aspect,
        std::uint32_t mipLevels,
        std::uint32_t baseMipLevel = 0,
        VkImageViewType viewType = VK_IMAGE_VIEW_TYPE_2D,
        std::uint32_t arrayLayers = 1) override;
    void destroyImageView(VkImageView view) override;
    VkSampler createSampler(const SamplerDesc& desc) override;
    void destroySampler(VkSampler sampler) override;
    void executeOneShot(
        const std::function<void(ICommandRecorder&)>& record) override;

    VkShaderModule createShaderModule(
        const std::vector<char>& code) override;
    void destroyShaderModule(VkShaderModule shader) override;
    VkPipelineLayout createPipelineLayout(
        VkDescriptorSetLayout setLayout,
        const PushConstantRangeDesc* pushConstants) override;
    void destroyPipelineLayout(VkPipelineLayout layout) override;
    VkPipeline createComputePipeline(const ComputePipelineDesc& desc) override;
    VkPipeline createGraphicsPipeline(
        const GraphicsPipelineDesc& desc) override;
    void destroyPipeline(VkPipeline pipeline) override;

    VkDescriptorSetLayout createDescriptorSetLayout(
        const std::vector<DescriptorBindingDesc>& bindings) override;
    void destroyDescriptorSetLayout(VkDescriptorSetLayout layout) override;
    VkDescriptorPool createDescriptorPool(
        const DescriptorPoolDesc& desc) override;
    void destroyDescriptorPool(VkDescriptorPool pool) override;
    std::vector<VkDescriptorSet> allocateDescriptorSets(
        VkDescriptorPool pool,
        VkDescriptorSetLayout layout,
        std::uint32_t count) override;
    void writeDescriptorImage(const DescriptorImageWrite& write) override;
    void writeDescriptorImageArray(
        const DescriptorImageArrayWrite& write) override;
    void writeDescriptorBuffer(const DescriptorBufferWrite& write) override;

    VkRenderPass createRenderPass(const RenderPassDesc& desc) override;
    void destroyRenderPass(VkRenderPass renderPass) override;
    VkFramebuffer createFramebuffer(const FramebufferDesc& desc) override;
    void destroyFramebuffer(VkFramebuffer framebuffer) override;

private:
    // Records a one-shot command buffer, submits, and waits for idle.
    void runOneShot(
        const char* label,
        const std::function<void(VkCommandBuffer)>& record);

    VkDevice device_ = VK_NULL_HANDLE;
    VkPhysicalDevice physicalDevice_ = VK_NULL_HANDLE;
    VkQueue graphicsQueue_ = VK_NULL_HANDLE;
    VkCommandPool commandPool_ = VK_NULL_HANDLE;
    bool samplerAnisotropyEnabled_ = false;
    GpuAllocator* allocator_ = nullptr;
    PipelineInspection* pipelineInspection_ = nullptr;
    bool sampleShadingEnabled_=false;
    bool exactDepthBiasEnabled_=false;
    std::unordered_map<VkRenderPass,VkSampleCountFlagBits> renderPassSamples_;
    std::mutex renderPassMutex_;
    VkPipelineCache pipelineCache_=VK_NULL_HANDLE;
    bool cacheFeedbackEnabled_=false;
    std::atomic<std::uint64_t> cacheRequests_{0},cacheHits_{0},cacheFeedback_{0};
    void notePipelineCache(const VkPipelineCreationFeedback& feedback)noexcept{
        if(!pipelineCache_)return;
        cacheRequests_.fetch_add(1,std::memory_order_relaxed);
        if(feedback.flags&VK_PIPELINE_CREATION_FEEDBACK_VALID_BIT){cacheFeedback_.fetch_add(1,std::memory_order_relaxed);
            if(feedback.flags&VK_PIPELINE_CREATION_FEEDBACK_APPLICATION_PIPELINE_CACHE_HIT_BIT)cacheHits_.fetch_add(1,std::memory_order_relaxed);}
    }
};

// Records onto a live VkCommandBuffer. Created per frame by the engine.
class VulkanCommandRecorder final : public ICommandRecorder {
public:
    explicit VulkanCommandRecorder(VkCommandBuffer commandBuffer, bool exclusiveRecording = false)
        : commandBuffer_(commandBuffer), exclusiveRecording_(exclusiveRecording) {}
    void invalidatePipelineBindings() noexcept {
        boundGraphicsPipeline_ = VK_NULL_HANDLE;
        boundComputePipeline_ = VK_NULL_HANDLE;
        boundGraphicsSet_ = VK_NULL_HANDLE;
        boundComputeSet_ = VK_NULL_HANDLE;
        boundGraphicsLayout_ = VK_NULL_HANDLE;
        boundComputeLayout_ = VK_NULL_HANDLE;
    }

    void beginRenderPass(const RenderPassBeginDesc& desc) override;
    void endRenderPass() override;
    void setViewport(
        float width, float height, float x = 0.0F, float y = 0.0F) override;
    void setScissor(VkExtent2D extent, VkOffset2D offset = {}) override;
    void bindComputePipeline(VkPipeline pipeline) override;
    void bindComputeDescriptorSet(VkPipelineLayout layout, VkDescriptorSet set) override;
    void bindPipeline(VkPipeline pipeline) override;
    void bindDescriptorSet(
        VkPipelineLayout layout,
        VkDescriptorSet set) override;
    void pushConstants(
        VkPipelineLayout layout,
        VkShaderStageFlags stages,
        std::uint32_t offset,
        const void* data,
        std::uint32_t size) override;
    void bindVertexBuffer(VkBuffer buffer, VkDeviceSize offset) override;
    void bindVertexStream(std::uint32_t binding,VkBuffer buffer,VkDeviceSize offset) override;
    void bindIndexBuffer(VkBuffer buffer, VkDeviceSize offset) override;
    void draw(std::uint32_t vertexCount) override;
    void drawIndexed(
        std::uint32_t indexCount,
        std::uint32_t firstIndex,
        std::uint32_t instanceCount = 1,
        std::uint32_t firstInstance = 0) override;
    void drawIndexedIndirect(VkBuffer buffer, VkDeviceSize offset,
                             std::uint32_t drawCount, std::uint32_t stride) override;
    void dispatch(
        std::uint32_t groupCountX,
        std::uint32_t groupCountY,
        std::uint32_t groupCountZ) override;
    void imageBarrier(const ImageBarrierDesc& barrier) override;
    void bufferBarrier(const BufferBarrierDesc& barrier) override;
    void bufferBarriers(const BufferBarrierDesc* barriers, std::size_t count) override;
    void clearColorImage(
        VkImage image,
        VkImageLayout layout,
        const VkClearColorValue& color) override;
    void copyImageToBuffer(
        VkImage image,
        VkBuffer buffer,
        VkExtent2D extent) override;
    void writeTimestamp(
        VkQueryPool pool,
        std::uint32_t query,
        VkPipelineStageFlagBits stage) override;

private:
    VkCommandBuffer commandBuffer_ = VK_NULL_HANDLE;
    bool exclusiveRecording_ = false;
    VkPipeline boundGraphicsPipeline_ = VK_NULL_HANDLE;
    VkPipeline boundComputePipeline_ = VK_NULL_HANDLE;
    VkDescriptorSet boundGraphicsSet_ = VK_NULL_HANDLE;
    VkDescriptorSet boundComputeSet_ = VK_NULL_HANDLE;
    VkPipelineLayout boundGraphicsLayout_ = VK_NULL_HANDLE;
    VkPipelineLayout boundComputeLayout_ = VK_NULL_HANDLE;
};

}  // namespace azurerender::rhi
