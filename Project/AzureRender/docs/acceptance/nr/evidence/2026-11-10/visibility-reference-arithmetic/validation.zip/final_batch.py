from pathlib import Path
import subprocess,sys
out=Path(__file__).resolve().parent
for mode in ['build','intel','nvidia']:
 subprocess.run([sys.executable,str(out/'validate.py'),mode],check=True)
