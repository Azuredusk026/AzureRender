from pathlib import Path
import subprocess,os,json,sys,time
out=Path(__file__).resolve().parent;main=Path('D:/Projects/FYP/Project/AzureRender');device=sys.argv[1]
os.environ.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer')
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(key,None)
os.environ['PATH']=str(main/'build/ninja-msvc-release')+';'+os.environ['PATH']
profile=out.parent/'20261110-003031-reciprocal-compact-profile-4e7929/correction.bin'
commands=[('default',[str(out/'ScreenObjectVisibilityGpuTests.exe'),str(out)]),('reference',[str(out/'ScreenObjectVisibilityGpuTests.exe'),str(out),str(profile)])]
commands.append(('neutral',[str(out/'ScreenObjectVisibilityGpuTests.exe'),str(out),'--reference']))
commands += [(scope,[str(out/'calibration.exe'),str(out/(scope+'-calibration.json')),str(out)]) for scope in ['hair','receiver']]
rows=[]
for name,command in commands:
 start=time.monotonic()
 with (out/(device+'-'+name+'.log')).open('wb') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=110)
 rows.append(dict(name=name,command=command,exitCode=r.returncode,seconds=time.monotonic()-start))
(out/(device+'-runs.json')).write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
sys.exit(1 if any(r['exitCode'] for r in rows) else 0)
