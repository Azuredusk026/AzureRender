from pathlib import Path
import subprocess,json,sys,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];main=Path('D:/Projects/FYP/Project/AzureRender');build=main/'build/ninja-msvc-release'
prior=out.parent/'20261109-234658-native-reciprocal-domain-2562a0'
compile=(prior/'compile-command.txt').read_text().replace('-I'+str(main/'src'),'-I'+str(root/'src')).replace('-I'+str(main/'tests'),'-I'+str(root/'tests'))
# Windows paths in the saved native command use backslashes.
compile=compile.replace('-I'+str(main/'src').replace('/','\\'),'-I'+str(root/'src').replace('/','\\')).replace('-I'+str(main/'tests').replace('/','\\'),'-I'+str(root/'tests').replace('/','\\'))
old=str(prior).replace('/','\\')
compile=compile.replace(old,str(out).replace('/','\\'))
mode=sys.argv[1];files=['tests/ScreenObjectVisibilityTests.cpp'] if mode=='red' else ['tests/ScreenObjectVisibilityTests.cpp','src/render/ScreenObjectVisibility.cpp','src/rhi/NullRhi.cpp']
if mode=='gpu':files=['tests/ScreenObjectVisibilityGpuTests.cpp','src/rhi/VulkanRhi.cpp',str(out/'calibration.cpp')]
commands=[]
for file in files:
 name=Path(file).stem
 command=compile.replace(str(out/'collector.cpp').replace('/','\\'),str(root/file).replace('/','\\')).replace('collector.obj',name+'.obj')
 commands.append(command)
link=(prior/'link-command.txt').read_text().replace(old,str(out).replace('/','\\')).replace('collector.obj','ScreenObjectVisibilityTests.obj '+str(out/'ScreenObjectVisibility.obj').replace('/','\\')+' '+str(out/'NullRhi.obj').replace('/','\\')).replace('collector.exe','contract.exe')
if mode=='gpu':
 for name in ['ScreenObjectVisibilityGpuTests','calibration']:
  commands.append(link.replace('ScreenObjectVisibilityTests.obj',name+'.obj').replace('NullRhi.obj','VulkanRhi.obj').replace('contract.exe',name+'.exe'))
elif mode!='red':commands.append(link)
(out/(mode+'-commands.json')).write_text(json.dumps(commands,indent=2))
with (out/(mode+'-build.log')).open('wb') as log:
 for cmd in commands:subprocess.run(cmd,cwd=build,shell=True,check=True,stdout=log,stderr=subprocess.STDOUT)
print(mode+' contract build completed')
