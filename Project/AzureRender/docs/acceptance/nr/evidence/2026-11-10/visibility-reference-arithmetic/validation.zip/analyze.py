from pathlib import Path
import hashlib,json,numpy as np
out=Path(__file__).resolve().parent;root=out.parents[2]
prior=out.parent/'20261109-234658-native-reciprocal-domain-2562a0'
oracleExpected=np.fromfile(out.parent/'20261110-002212-receiver-exact-fma-a8571f/oracle-expected.u32',dtype='<u4')
domainExpected=np.fromfile(prior/'compute-rcp-domain.f32',dtype='<u4')
assert len(oracleExpected)==65536 and len(domainExpected)==8388608
rows=[]
for device in ['intel','nvidia']:
 runs=json.loads((out/(device+'-runs.json')).read_text());assert len(runs)==5 and all(r['exitCode']==0 for r in runs)
 for scope,count in [('hair',17017),('receiver',49384)]:
  result=json.loads((out/(device+'-'+scope+'-result.json')).read_text())
  assert result['pixels']==result['withinOnePixels']==count and result['maximumByteError']<=1
  assert result['validationErrors']==0 and result['zeroAllocator']
 for name,expected in [('oracle',oracleExpected),('domain',domainExpected)]:
  raw=np.fromfile(out/(device+'-'+name+'.bin'),dtype='<u4')
  actual=raw.reshape(-1,4)[:,0] if name=='oracle' else raw
  assert len(actual)==len(expected)
  log=(out/(device+'-'+name+'.log')).read_text(errors='replace');assert 'zero validation errors' in log
  differences=int((actual!=expected).sum());assert differences==0,(device,name,differences)
  rows.append(dict(device=device,check=name,samples=len(expected),differences=differences,sha256=hashlib.sha256((out/(device+'-'+name+'.bin')).read_bytes()).hexdigest()))
assert 'PASS: visibility validation' in (out/'final-build.log').read_text()
sources=['CMakeLists.txt','src/render/ScreenObjectVisibility.hpp','src/render/ScreenObjectVisibility.cpp','src/rhi/Rhi.hpp','src/rhi/NullRhi.hpp','src/rhi/NullRhi.cpp','src/rhi/VulkanRhi.hpp','shaders/screen_object_visibility.frag','shaders/float32_reference.glsl','tests/ScreenObjectVisibilityTests.cpp','tests/ScreenObjectVisibilityGpuTests.cpp']
fingerprints={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sources}
(out/'source-inputs.json').write_text(json.dumps(fingerprints,indent=2))
report=dict(status='public-reference-arithmetic-passed',arithmetic=rows,sourceFingerprints=fingerprints,
 gpuRuns={d:json.loads((out/(d+'-runs.json')).read_text()) for d in ['intel','nvidia']},
 calibration={d:{s:json.loads((out/(d+'-'+s+'-result.json')).read_text()) for s in ['hair','receiver']} for d in ['intel','nvidia']},
 execution=json.loads((out/'final-execution.json').read_text()),scope='Release targeted production objects and public shaders; main host integration, Debug and original four-frame regression pending integration owner.')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(arithmetic=rows,calibration=report['calibration'],scope=report['scope']),indent=2))
