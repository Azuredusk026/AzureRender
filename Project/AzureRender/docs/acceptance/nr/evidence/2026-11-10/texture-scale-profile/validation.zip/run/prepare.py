from pathlib import Path
import sys,json,subprocess,numpy as np
out=Path(__file__).parent;root=out.parents[2];prior=out.parent/'20261110-173835-reference-depth-coverage-4b4afc';old=out.parent/'20261110-183305-intel-depth-alpha-footprint-e32993';owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
local=s.acquire_inputs(root/'build',out,[prior.name,old.name,'20261110-030251-hair-main-chroma-public-9e799c'],owner)
p=Path('D:/Projects/FYP-coordination/quality-claim.json');v=json.loads(p.read_text(encoding='utf-8'));v.update(state='independent-texture-scale-profile',taskPath=str(out),localInputLease=[local],inputLease=[],lastCommit='5cb239d',pendingCommand='two-device-affine-gradient-query',ownedFiles=['docs/acceptance/nr/texture-scale-profile.md']);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
folder=out/'shaders';folder.mkdir(exist_ok=True)
for name in ['reference_depth.vert.spv','reference_depth.frag.spv','reference_depth_masked.vert.spv']:(folder/name).write_bytes((prior/('release-'+name)).read_bytes())
command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslangValidator.exe','-V','--target-env','vulkan1.0','-o',str(folder/'reference_depth_masked.frag.spv'),str(out/'profile.frag')];r=subprocess.run(command,capture_output=True,text=True);(out/'shader-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(folder/'reference_depth_masked.frag.spv')],capture_output=True,text=True);assert r.returncode==0,r.stderr
np.array([[-1,-1,.03125,1],[1,-1,.03125,1],[-1,1,.03125,1],[1,1,.03125,1]],dtype='<f4').tofile(out/'positions.bin');np.zeros((4,2),dtype='<f4').tofile(out/'uv.bin');np.array([0,1,2,2,1,3],dtype='<u4').tofile(out/'indices.bin');np.r_[np.eye(4,dtype='<f4').flatten(),np.zeros(4,dtype='<f4')].astype('<f4').tofile(out/'projection.bin')
queries=[];cases=[]
for k in range(256):
 x=(k%16)*16+8;y=(k//16)*16+8;queries.append([x,y,0,0]);cases.append({'case':k,'pixel':[x,y],'ratio':(k%16)/15,'scale':2**(k//16/2),'swap':bool((k//16)%2)})
np.array(queries,dtype='<f4').tofile(out/'queries.bin');(out/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
config=json.loads((prior/'native-config.json').read_text());config.update(positions=str(out/'positions.bin'),uv=str(out/'uv.bin'),indices=str(out/'indices.bin'),profile=str(out/'projection.bin'),queries=str(out/'queries.bin'),cutoff=0,lodBias=0);(out/'config.json').write_text(json.dumps(config,indent=2)+'\n')
(out/'task-card.json').write_text(json.dumps({'baseCommit':'5cb239d','delivery':'Independent affine gradient footprint query on both devices','baseline':'Euclidean explicit LOD fails native Alpha predicate','criteria':['256 independent scale/ratio/orientation combinations','Read actual derivatives alongside hardware LOD','Check complete sample set against general functions','Zero validation and allocator errors'],'budgetBytes':33554432,'explorationSeconds':1800,'gpuSeconds':120},indent=2)+'\n')
(out/'queued.py').write_text((old/'queued-candidate.py').read_text().replace("str(out/'candidate.py')","str(out/'run.py')").replace('quality-intel-alpha-quad-candidate','quality-independent-texture-scale-profile'))
print('Independent 256-case footprint fixture ready')
