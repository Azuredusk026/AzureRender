#version 450
layout(location=0) in vec2 textureCoordinate;
layout(binding=0) uniform sampler2D alphaMask;
layout(push_constant) uniform Projection {vec4 columns[4];vec4 jitter;uvec4 control;vec4 coverage;} projection;
layout(location=0) out float surfaceDepth;
void main(){
    uint row=uint(gl_FragCoord.y)/16u;
    float ratio=float(uint(gl_FragCoord.x)/16u%16u)/15.0;
    float scale=exp2(float(row/4u)*1.25);
    vec2 gx=vec2(1.0,ratio),gy=vec2(0);
    if(row%4u==1u)gy=gx;
    if(row%4u==2u)gy=vec2(-ratio,1.0);
    if(row%4u==3u)gy=vec2(ratio,0.5);
    vec2 uv=scale*(gx*gl_FragCoord.x+gy*gl_FragCoord.y)/vec2(textureSize(alphaMask,0));
    vec2 dx=dFdxFine(uv)*vec2(textureSize(alphaMask,0));
    vec2 dy=dFdyFine(uv)*vec2(textureSize(alphaMask,0));
    float a=dot(dx,dx),b=dot(dx,dy),c=dot(dy,dy);
    float eigen=0.5*(a+c+sqrt((a-c)*(a-c)+4.0*b*b));
    vec4 observed=vec4(textureQueryLod(alphaMask,uv).y,0.5*log2(max(a,c)),log2(max(length(vec2(dx.x,dy.x)),length(vec2(dx.y,dy.y)))),0.5*log2(eigen));
    surfaceDepth=observed[projection.control.y];
}
