from pathlib import Path
import numpy as np,json
out=Path(__file__).parent;old=out.parent/'20261110-183305-intel-depth-alpha-footprint-e32993';config=json.loads((out/'native-config.json').read_text());q=np.fromfile(config['queries'],dtype='<f4').reshape(-1,4);k=np.flatnonzero((q[:,0]==1326)&(q[:,1]==1262))[0];rows=[]
for device in ['nvidia','intel']:
 raw=np.stack([np.fromfile(out/f'{device}-raw-{c}-selected.bin',dtype='<f4') for c in range(4)],axis=1);derived=np.stack([np.fromfile(out/f'{device}-derived-{c}-selected.bin',dtype='<f4') for c in range(4)],axis=1)
 control=np.fromfile(old/f'{device}-control-selected-d32.bin',dtype='<u4')
 for mode in ['raw','derived']:
  for c in range(4):assert np.array_equal(np.fromfile(out/f'{device}-{mode}-{c}-selected-d32.bin',dtype='<u4'),control)
 assert np.array_equal(derived[:,0].view('u4'),np.fromfile(old/f'{device}-attribute-lod-selected.bin',dtype='<u4'))
 assert np.array_equal(derived[:,3].view('u4'),np.fromfile(old/f'{device}-attribute-alpha-selected.bin',dtype='<u4'))
 a=np.stack([np.fromfile(out/f'{device}-two-axis-{c}-selected.bin',dtype='<f4') for c in range(4)],axis=1).astype('f8')
 models={name:{'pixels':len(a),'maximumLodError':float(max(abs(a[:,0]-a[:,c]))),'meanLodError':float(np.mean(abs(a[:,0]-a[:,c])))} for c,name in [(1,'columnEuclidean'),(2,'rowEuclidean'),(3,'ellipseMajorAxis')]}
 rows.append({'device':device,'nativeD32BitExactAcrossAllEightObservations':True,'nativeAlphaAndQueryLodBitExact':True,'nativePixels':len(control),'genericTwoAxisModels':models,'nativeAlphaPoint':{'texturePixel':[1326,1262],'uiPixel':[1326,177],'quadTexelDerivatives':raw[k].tolist(),'hardwareLod':float(derived[k,0]),'columnEuclideanLod':float(derived[k,1]),'rowEuclideanLod':float(derived[k,2]),'alpha':float(derived[k,3])}})
r={'status':'qualified-observation-models-diagnostic','overall':'failed-user-review','sourceCommit':'5cb239d','genericCasesPerDevice':512,'gpuRuns':32,'executionSeconds':[6.375,10.609,6.406],'devices':rows,'publicSourceUnchanged':True,'interpretation':'Observed NVIDIA LOD is closer to ellipse major axis; this is not a bit-exact hardware algorithm identification','next':'Independent explicit ellipse major-axis LOD candidate; retain all97 production failures'};(out/'results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(rows,indent=2))
