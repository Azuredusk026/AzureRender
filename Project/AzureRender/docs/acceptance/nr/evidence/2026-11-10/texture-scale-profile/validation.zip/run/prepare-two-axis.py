from pathlib import Path
import subprocess
out=Path(__file__).parent;folder=out/'two-axis-shaders';folder.mkdir(exist_ok=True)
for p in (out/'shaders').iterdir():
 if p.name!='reference_depth_masked.frag.spv':(folder/p.name).write_bytes(p.read_bytes())
r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslangValidator.exe','-V','--target-env','vulkan1.0','-o',str(folder/'reference_depth_masked.frag.spv'),str(out/'two-axis.frag')],capture_output=True,text=True);(out/'two-axis-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0
source=(out/'run.py').read_text().replace("str(out/'shaders')","str(out/'two-axis-shaders')").replace("f'{device}-{channel}","f'{device}-two-axis-{channel}").replace("out/'runs.json'","out/'two-axis-runs.json'")
(out/'run-two-axis.py').write_text(source);(out/'queued-two-axis.py').write_text((out/'queued.py').read_text().replace("str(out/'run.py')","str(out/'run-two-axis.py')"))
