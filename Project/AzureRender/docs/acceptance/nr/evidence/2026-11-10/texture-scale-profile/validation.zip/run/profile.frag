#version 450
layout(location=0) in vec2 textureCoordinate;
layout(binding=0) uniform sampler2D alphaMask;
layout(push_constant) uniform Projection {vec4 columns[4];vec4 jitter;uvec4 control;vec4 coverage;} projection;
layout(location=0) out float surfaceDepth;
void main(){
    uint row=uint(gl_FragCoord.y)/16u;
    float ratio=float(uint(gl_FragCoord.x)/16u%16u)/15.0;
    float scale=exp2(float(row)*0.5);
    vec2 g=scale*(((row&1u)==0u)?vec2(1.0,ratio):vec2(ratio,1.0));
    vec2 uv=g*gl_FragCoord.x/vec2(textureSize(alphaMask,0));
    vec2 dx=dFdxFine(uv)*vec2(textureSize(alphaMask,0));
    vec2 dy=dFdyFine(uv)*vec2(textureSize(alphaMask,0));
    vec4 observed=vec4(textureQueryLod(alphaMask,uv).y,dx,length(dy));
    surfaceDepth=observed[projection.control.y];
}
