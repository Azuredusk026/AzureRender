#version 450
#extension GL_GOOGLE_include_directive : require
#include "material_uv_gradients.glsl"
layout(location=0) in vec2 textureCoordinate;
layout(binding=0) uniform sampler2D alphaMask;
layout(push_constant) uniform Projection {vec4 columns[4];vec4 jitter;uvec4 control;vec4 coverage;} projection;
layout(location=0) out float surfaceDepth;
void main(){
    mat2 g=azureMirroredCoarseUvGradients(textureCoordinate);
    vec2 size=vec2(textureSize(alphaMask,0));
    vec2 dx=g[0]*size,dy=g[1]*size;
#if RAW_DERIVATIVES
    vec4 observed=vec4(dx,dy);
#else
    vec4 observed=vec4(textureQueryLod(alphaMask,textureCoordinate).y,log2(max(length(dx),length(dy))),log2(max(length(vec2(dx.x,dy.x)),length(vec2(dx.y,dy.y)))),texture(alphaMask,textureCoordinate,-1.0).r);
#endif
    surfaceDepth=observed[projection.control.y];
}
