from pathlib import Path
import json,hashlib,zipfile,re,subprocess,sys
out=Path(__file__).parent;engine=out.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();dest=engine/'docs/acceptance/nr/evidence/2026-11-10/texture-scale-profile';dest.mkdir(parents=True,exist_ok=True)
files={'run/'+p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and p.suffix in {'.py','.json','.log','.frag','.spv','.bin'} and p.stat().st_size<1024*1024}
doc=engine/'docs/acceptance/nr/texture-scale-profile.md';files['source/texture-scale-profile.md']=doc
members={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()};archive=dest/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.writestr('manifest.json',json.dumps(members,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
assert archive.stat().st_size<8*1024*1024
r=json.loads((out/'results.json').read_text());r.update(archive={'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(members)+1},defaultRegression={'sourceCommit':'f100244','fourFrames':'SHA256/RGB exact','reason':'Public source and executable inputs unchanged'})
(dest/'results.json').write_text(json.dumps(r,indent=2)+'\n')
for link in re.findall(r'\]\(([^)]+)\)',doc.read_text(encoding='utf-8')):
 if not link.startswith('https://'):assert (doc.parent/link).exists(),link
print(json.dumps(r['archive']))
