from pathlib import Path
import sys,json,subprocess
out=Path(__file__).parent;root=out.parents[2];prior=out.parent/'20261110-173835-reference-depth-coverage-4b4afc';owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
local=s.acquire_inputs(root/'build',out,['20261110-165124-reference-depth-source-4d1d7d'],owner);external=s.acquire_inputs(s.DEFAULT_BUILD,out,['20261108-045252-screen-object-visibility-ca2907'],owner)
p=Path('D:/Projects/FYP-coordination/quality-claim.json');v=json.loads(p.read_text(encoding='utf-8'));v['localInputLease'].append(local);v['inputLease'].append(external);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for mode in ['derived','raw']:
 folder=out/(mode+'-shaders');folder.mkdir(exist_ok=True)
 for name in ['reference_depth.vert.spv','reference_depth.frag.spv','reference_depth_masked.vert.spv']:(folder/name).write_bytes((prior/('release-'+name)).read_bytes())
 command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslangValidator.exe','-V','--target-env','vulkan1.1','-DRAW_DERIVATIVES='+('1' if mode=='raw' else '0'),'-I'+str(root/'shaders'),'-o',str(folder/'reference_depth_masked.frag.spv'),str(out/'native-footprint.frag')];r=subprocess.run(command,capture_output=True,text=True);(out/(mode+'-build.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
 r=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.1',str(folder/'reference_depth_masked.frag.spv')],capture_output=True,text=True);assert r.returncode==0,r.stderr
config=json.loads((prior/'native-config.json').read_text());config['cutoff']=0;(out/'native-config.json').write_text(json.dumps(config,indent=2)+'\n')
source=(out/'run.py').read_text().replace("q=np.fromfile(out/'queries.bin',dtype='<f4')","q=np.fromfile(Path(json.loads((out/'native-config.json').read_text())['queries']),dtype='<f4')")
source=source.replace("for channel in range(4):","for mode in ['derived','raw']:\n  for channel in range(4):")
lines=source.splitlines();start=next(k for k,l in enumerate(lines) if "  config=json.loads" in l);end=next(k for k,l in enumerate(lines) if " (out/'runs.json')" in l)
for k in range(start,end):lines[k]=' '+lines[k]
source='\n'.join(lines)+'\n';source=source.replace("out/'config.json'","out/'native-config.json'").replace("f'{device}-{channel}","f'{device}-{mode}-{channel}").replace("str(out/'shaders')","str(out/(mode+'-shaders'))").replace("'channel':channel","'mode':mode,'channel':channel").replace("out/'runs.json'","out/'native-runs.json'")
(out/'run-native.py').write_text(source)
(out/'queued-native.py').write_text((out/'queued.py').read_text().replace("str(out/'run.py')","str(out/'run-native.py')"))
print('Native footprint readback prepared')
