from pathlib import Path
import os,subprocess,json,re,hashlib,numpy as np
out=Path(__file__).parent;root=out.parents[2];exe=out.parent/'20261110-183305-intel-depth-alpha-footprint-e32993/native-coverage.exe';q=np.fromfile(out/'queries.bin',dtype='<f4').reshape(-1,4).astype(int);rows=[]
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release')+';'+env['PATH'])
 for channel in range(4):
  config=json.loads((out/'config.json').read_text());config['channel']=channel;path=out/f'{device}-{channel}-config.json';path.write_text(json.dumps(config,indent=2)+'\n');prefix=out/f'{device}-{channel}'
  with (out/f'{device}-{channel}.log').open('wb') as log:r=subprocess.run([str(exe),str(out/'shaders'),str(path),str(prefix)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=30)
  text=(out/f'{device}-{channel}.log').read_text(errors='replace');assert r.returncode==0 and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I),text[-2500:]
  raw=Path(str(prefix)+'-r32.bin');data=np.fromfile(raw,dtype='<f4').reshape(1440,2560);selected=data[q[:,1],q[:,0]].copy();selected.tofile(out/f'{device}-{channel}-selected.bin');assert np.isfinite(selected).all();rows.append({'device':device,'channel':channel,'selected':len(selected),'planeSha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'validationErrors':0,'allocatorZero':True});del data;raw.unlink()
 (out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(device,'256 LOD and derivative tuples read',flush=True)
