from pathlib import Path
import renderdoc as rd
import json,sys,traceback
out=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-173835-reference-depth-coverage-4b4afc');report={'status':'starting','draws':[]};cap=None;c=None
def fields(value):return {k:str(getattr(value,k)) for k in dir(value) if not k.startswith('_') and k not in ['this','thisown'] and not callable(getattr(value,k))}
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc','',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 for event in [422,440]:
  c.SetFrameEvent(event,True);p=c.GetPipelineState();row={'event':event,'depth':fields(p.GetDepthTestState()),'samplers':[]}
  for value in p.GetSamplers(rd.ShaderStage.Pixel):
   s={'members':fields(value)}
   for key in ['sampler','samplerDescriptor']:
    if hasattr(value,key):
     actual=getattr(value,key);s[key]=fields(actual)
     if hasattr(actual,'filter'):s['filter']=fields(actual.filter)
   row['samplers'].append(s)
  report['draws'].append(row)
 report['status']='exported'
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'sampler-state.json').write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if report['status']=='exported' else 1)
