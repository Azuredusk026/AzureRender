#include "render/ReferenceDepth.hpp"
int main(){azurerender::ReferenceDepthSurface surface;surface.alpha.emplace();return surface.schemaVersion!=1;}
