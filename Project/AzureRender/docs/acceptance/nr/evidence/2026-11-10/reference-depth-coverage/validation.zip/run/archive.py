from pathlib import Path
import hashlib,json,zipfile,re
engine=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender');out=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda name:json.loads((out/name).read_text(encoding='utf-8'))
frozen=read('frozen-source.json');assert all(sha(engine/name)==digest for name,digest in frozen.items())
gpu=read('gpu-results.json');assert len(gpu)==8 and all(r['exitCode']==0 and r['validationClean'] for r in gpu)
native=read('native-analysis.json');assert native[0]['depthExact']==native[0]['visibilityExact']==17017 and native[0]['visibilityOverOneByte']==0 and native[1]['visibilityOverOneByte']==97
assert read('default-four-results.json')['allExact']
docs=['docs/runtime/reference-depth.md','docs/acceptance/nr/reference-depth-coverage.md','docs/plans/2026-11-10-reference-depth-coverage.md']
dependencies=['src/render/ReferenceClipProjection.hpp','src/render/ReferenceFmaShader.hpp','shaders/reference_clip_projection.glsl','tests/ReferenceDepthGpuTests.cpp','tests/support/VulkanComputeFixture.hpp']
files={'source/'+name:engine/name for name in list(frozen)+dependencies+docs}
files.update({'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.json','.py','.log','.bin','.cpp','.hpp','.asm','.spv'}})
config=read('native-config.json')
for key in ['positions','indices','profile','queries']:files['inputs/'+Path(config[key]).name]=Path(config[key])
for p in (out/'default-four-frames').iterdir():
 if p.is_file() and p.suffix=='.json':files['run/default-four-frames/'+p.name]=p
dest=engine/'docs/acceptance/nr/evidence/2026-11-10/reference-depth-coverage';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.writestr('manifest.json',json.dumps(members,ensure_ascii=False,indent=2))
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,value in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==value['sha256']
result={'status':'qualified-public-surface-and-nvidia-native-source-intel-source-pending','overall':'failed-user-review','sourceBase':'c260811','exactAttachmentValues':320768,'maskedExactValues':25088,'opaqueExactValues':295680,'rejectionsPerMaskedBatch':17,'gpuBatches':gpu,'nativeSource':native,'nativeConfiguration':config,'defaultFour':read('default-four-results.json'),'programIdentity':read('program-identity.json'),'preparedPrograms':read('prepared-programs.json'),'source':frozen,'archive':{'members':len(members)+1,'bytes':archive.stat().st_size,'sha256':sha(archive)},'remaining':['Intel97 visibility pixels beyond one-byte gate','Actual camera and asset scene binding','Complete native visual and performance gates']}
(dest/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in docs:
 p=engine/name
 for link in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if not link.startswith('https:'):assert (p.parent/link).exists(),link
print(json.dumps(result['archive']))
