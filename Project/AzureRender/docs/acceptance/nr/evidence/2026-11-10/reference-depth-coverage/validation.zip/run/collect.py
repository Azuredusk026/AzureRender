from pathlib import Path
import renderdoc as rd
import json,traceback,sys,hashlib
out=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-173835-reference-depth-coverage-4b4afc');path=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc')
report={'status':'starting','draws':[]};cap=None;c=None
def fields(value):return {k:str(getattr(value,k)) for k in dir(value) if not k.startswith('_') and k not in ['this','thisown'] and not callable(getattr(value,k))}
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(path),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 textures={t.resourceId:t for t in c.GetTextures()}
 for event,alphaSlot in [(422,2),(440,0)]:
  c.SetFrameEvent(event,True);pipe=c.GetPipelineState();state=c.GetD3D11PipelineState();reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
  row={'event':event,'rasterizer':fields(state.rasterizer.state),'outputMerger':fields(state.outputMerger),'buffers':[],'samplers':[],'signatures':[]}
  for index,b in enumerate(reflection.constantBlocks):
   d=pipe.GetConstantBlock(rd.ShaderStage.Pixel,index,0).descriptor;data=bytes(c.GetBufferData(d.resource,d.byteOffset,d.byteSize));assert len(data)<=65536
   name=f'{event}-ps-cb{b.fixedBindNumber}.bin';(out/name).write_bytes(data);row['buffers'].append({'register':b.fixedBindNumber,'file':name,'bytes':len(data)})
  for access in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel):
   if reflection.readOnlyResources[access.access.index].fixedBindNumber!=alphaSlot:continue
   t=textures[access.descriptor.resource];row['alpha']={'resource':str(t.resourceId),'format':t.format.Name(),'width':t.width,'height':t.height,'mips':t.mips,'descriptor':fields(access.descriptor),'files':[]}
   for mip in range(t.mips):
    sub=rd.Subresource();sub.mip=mip;data=bytes(c.GetTextureData(t.resourceId,sub));assert len(data)<=16*1024*1024
    name=f'{event}-alpha-mip{mip}.bin';(out/name).write_bytes(data);row['alpha']['files'].append({'file':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
  for sampler in pipe.GetSamplers(rd.ShaderStage.Pixel):row['samplers'].append({'access':fields(sampler.access),'descriptor':fields(sampler.descriptor)})
  vertexReflection=pipe.GetShaderReflection(rd.ShaderStage.Vertex)
  for sig in vertexReflection.outputSignature:row['signatures'].append(fields(sig))
  (out/f'{event}-vertex.asm').write_text(c.DisassembleShader(pipe.GetGraphicsPipelineObject(),vertexReflection,''),encoding='utf-8')
  for index,b in enumerate(vertexReflection.constantBlocks):
   d=pipe.GetConstantBlock(rd.ShaderStage.Vertex,index,0).descriptor;data=bytes(c.GetBufferData(d.resource,d.byteOffset,d.byteSize));assert len(data)<131072
   (out/f'{event}-vs-cb{b.fixedBindNumber}.bin').write_bytes(data)
  report['draws'].append(row)
 report['status']='exported'
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'source-state.json').write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if report['status']=='exported' else 1)
