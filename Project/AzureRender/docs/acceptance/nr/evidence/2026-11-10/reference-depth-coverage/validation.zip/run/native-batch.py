from pathlib import Path
import sys,subprocess,json,os,re,time
out=Path(__file__).resolve().parent;root=out.parents[2];build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release';main=Path('D:/Projects/FYP/Project/AzureRender');calibration=out.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
r=subprocess.run([sys.executable,str(out/'build-native.py')],timeout=180);assert r.returncode==0
rows=[]
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(build)+';'+env['PATH'])
 prefix=out/('native-'+device);command=[str(out/'native-coverage.exe'),str(build/'shaders'),str(out/'native-config.json'),str(prefix)]
 with (out/(device+'-native-depth.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 text=(out/(device+'-native-depth.log')).read_text(errors='replace');assert r.returncode==0 and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I),text[-4000:]
 config=json.loads((calibration/'hair-calibration.json').read_text());config.update(depth=str(prefix)+'-r32.bin',scope='masked');configPath=out/(device+'-masked-config.json');configPath.write_text(json.dumps(config,indent=2)+'\n');command=[str(calibration/'calibration.exe'),str(configPath),str(calibration)]
 with (out/(device+'-masked-visibility.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 text=(out/(device+'-masked-visibility.log')).read_text(errors='replace');result=json.loads((out/(device+'-masked-result.json')).read_text());assert result['pixels']==17017 and result['validationErrors']==0 and result['zeroAllocator'] and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I)
 rows.append({'device':device,'producer':'Public ReferenceDepthGpu, native front surface Alpha/cull; raw BC7 feature enabled only in private probe','visibilityExitCode':r.returncode,'result':result});(out/'native-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(device,result,flush=True)
