from pathlib import Path
import json,numpy as np,hashlib
out=Path(__file__).resolve().parent;root=out.parents[2];prior=out.parent/'20261110-165124-reference-depth-source-4d1d7d'
header=(root/'tests/support/VulkanComputeFixture.hpp').read_text(encoding='utf-8');needle='used.independentBlend=VK_TRUE;used.samplerAnisotropy=features.samplerAnisotropy;';assert needle in header
header=header.replace(needle,needle+'used.textureCompressionBC=features.textureCompressionBC;if(!used.textureCompressionBC)throw VulkanFeatureUnavailable("Native BC7 texture capability unavailable");')
(out/'private-compute-fixture.hpp').write_text(header,encoding='utf-8');source=(root/'tests/ReferenceDepthCoverageGpuTests.cpp').read_text(encoding='utf-8').replace('"support/VulkanComputeFixture.hpp"','"private-compute-fixture.hpp"');(out/'native-synthetic.cpp').write_text(source,encoding='utf-8')
vertices=np.fromfile(prior/'source-422-vertices.bin',dtype='<f4').reshape(-1,23);assert len(vertices)==11564;vertices[:,4:6].copy().tofile(out/'native-uv.bin')
state=json.loads((out/'source-state.json').read_text());a=next(x for x in state['draws'] if x['event']==422)['alpha'];assert a['format']=='BC7_UNORM'
config={'positions':str(prior/'native-positions.bin'),'indices':str(prior/'native-indices.bin'),'profile':str(prior/'native-profile.bin'),'uv':str(out/'native-uv.bin'),'mips':[str(out/x['file']) for x in a['files']],'width':a['width'],'height':a['height'],'cutoff':.5,'lodBias':-1,'queries':'D:/Projects/FYP/Project/AzureRender/build/runs/20261108-045252-screen-object-visibility-ca2907/queries.bin'}
cb=np.fromfile(out/'422-ps-cb2.bin',dtype='<f4').reshape(-1,4);assert cb[12,0]==config['cutoff'];cb=np.fromfile(out/'422-ps-cb0.bin',dtype='<f4').reshape(-1,4);assert cb[26,0]==config['lodBias']
(out/'native-config.json').write_text(json.dumps(config,indent=2)+'\n');(out/'private-fixture-change.json').write_text(json.dumps({'scope':'Private native texture probe only; production fixture unchanged','enabledDeviceFeature':'textureCompressionBC from physical support, required for raw BC7 source','sourceFixtureSha256':hashlib.sha256((root/'tests/support/VulkanComputeFixture.hpp').read_bytes()).hexdigest(),'privateFixtureSha256':hashlib.sha256((out/'private-compute-fixture.hpp').read_bytes()).hexdigest()},indent=2)+'\n')
print('Native UV, exact BC7 mips and sampler/cutoff source prepared')
