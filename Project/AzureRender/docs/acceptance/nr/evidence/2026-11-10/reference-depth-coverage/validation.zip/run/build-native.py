from pathlib import Path
import json,subprocess,sys
out=Path(__file__).resolve().parent;root=out.parents[2];build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release';commands=json.loads((out/'native-template-commands.json').read_text());compile,link=commands;oldObject=str(Path('CMakeFiles')/'AzureReferenceDepthCoverageGpuTests.dir/tests/ReferenceDepthCoverageGpuTests.cpp.obj');obj=str(out/'native-coverage.obj');assert oldObject in compile and oldObject in link
compile=compile.replace(oldObject,obj);pdbFlag=next(x for x in compile.split() if x.startswith('/Fd'));compile=compile.replace(pdbFlag,'/Fd'+str(out/'native-coverage.pdb'));source=str(root/'tests/ReferenceDepthCoverageGpuTests.cpp');assert source in compile;compile=compile.replace(source,str(out/'native-coverage.cpp'))
link=link.replace(oldObject,obj).replace('--intdir='+str(Path('CMakeFiles')/'AzureReferenceDepthCoverageGpuTests.dir'),'--intdir='+str(out/'native-link'))
for extension in ['exe','lib','pdb']:
    oldName='AzureReferenceDepthCoverageGpuTests.'+extension;newPath=out/('native-coverage.'+extension)
    link=link.replace((build/oldName).as_posix(),newPath.as_posix()).replace(str(build/oldName),str(newPath)).replace(oldName,str(newPath))
assert 'AzureReferenceDepthCoverageGpuTests' not in link and '/release/D:' not in link
(out/'native-link').mkdir(exist_ok=True);commands=[compile,link];(out/'native-build-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
if '--plan-only' in sys.argv:print('Private object, PDB, link intermediates and executable paths prepared');raise SystemExit(0)
with (out/'native-build.log').open('wb') as log:
 for command in commands:
  wrapper=subprocess.list2cmdline(['D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat']);r=subprocess.run(wrapper+' '+command,cwd=build,shell=True,stdout=log,stderr=subprocess.STDOUT)
  if r.returncode:raise SystemExit(r.returncode)
print('Native probe linked to current public depth core')
