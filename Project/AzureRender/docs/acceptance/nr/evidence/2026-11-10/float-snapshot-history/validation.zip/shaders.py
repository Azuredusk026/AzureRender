from pathlib import Path
import json,os,subprocess,sys,hashlib,shutil
root=Path.cwd();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';runtime=out/'runtime'
runtime.mkdir(exist_ok=True);(runtime/'shaders').mkdir(exist_ok=True)
for p in (build/'shaders').glob('*.spv'):
 if not (runtime/'shaders'/p.name).exists():os.link(p,runtime/'shaders'/p.name)
text=(root/'shaders/mesh.frag').read_text()
extensions='''
#if defined(AZURE_SNAPSHOT_REUSE)
#extension GL_KHR_shader_subgroup_vote : require
#extension GL_EXT_shader_quad_control : require
#extension GL_EXT_maximal_reconvergence : require
layout(quad_derivatives) in;
layout(full_quads) in;
#endif
layout(location=2) out vec4 snapshotIdentity;
'''
text=text.replace('#version 450','#version 450\n'+extensions)
clean=(root/'shaders/shadow_history.glsl').read_text();clean=clean[clean.index('bool azureShadowHistoryCascadeClean'):clean.index('float azureSampleShadowHistory')]
declarations='''
#if defined(AZURE_SNAPSHOT_REUSE)
layout(location=15,component=1) flat in uvec2 shadowHistorySource;
layout(std430,binding=49) coherent buffer SnapshotHistoryInputs {
    uvec4 extentAndReuse;vec4 dirty[4];uvec4 statistics;uvec2 ranges[];
} shadowHistoryInputs;
layout(binding=50) uniform sampler2D previousSnapshotIdentity;
layout(binding=51) uniform sampler2D previousSnapshotColor;
layout(binding=52) uniform sampler2D previousSnapshotNormal;
'''+clean+'''
uint snapshotHistoryKey(){
    uint instance=shadowHistorySource.x,first=shadowHistorySource.y,triangle=uint(gl_PrimitiveID);
    if(instance>=shadowHistoryInputs.extentAndReuse.w||first==0xffffffffu)return 0xffffffffu;
    uvec2 range=shadowHistoryInputs.ranges[instance];
    if(range.x==0xffffffffu||first>=range.y||range.y-first<3u||triangle>(range.y-first-3u)/3u)return 0xffffffffu;
    if(range.x%3u!=0u||first%3u!=0u)return 0xffffffffu;
    uint key=(range.x+first+triangle*3u)/3u;return key<=16777215u?key:0xffffffffu;
}
bool snapshotHistoryLoad(uint key){
    ivec2 pixel=ivec2(gl_FragCoord.xy);
    bool inside=all(lessThan(uvec2(pixel),shadowHistoryInputs.extentAndReuse.xy));
    bool valid=inside&&key!=0xffffffffu&&(shadowHistoryInputs.extentAndReuse.z&1u)!=0u;
    float previous=valid?texelFetch(previousSnapshotIdentity,pixel,0).r:-1.0;
    bool matched=valid&&float(key)==previous&&azureShadowHistoryClean();
    bool hit=subgroupQuadAll(matched);
    bool sampled=!gl_HelperInvocation&&(pixel.x&31)==0&&(pixel.y&31)==0;
    if(sampled){atomicAdd(shadowHistoryInputs.statistics.x,1u);if(key!=0xffffffffu)atomicAdd(shadowHistoryInputs.statistics.y,1u);if(hit)atomicAdd(shadowHistoryInputs.statistics.z,1u);}
    if(hit){outputColor=texelFetch(previousSnapshotColor,pixel,0);outputNormal=texelFetch(previousSnapshotNormal,pixel,0);return true;}
    return false;
}
#endif
'''
text=text.replace('vec3 rgbToHsv(vec3 c){',declarations+'\nvec3 rgbToHsv(vec3 c){')
text=text.replace('void main()\n','''void main()
#if defined(AZURE_SNAPSHOT_REUSE)
    [[maximally_reconverges]]
#endif
''')
text=text.replace('    prepareShadowReceiver();','''    prepareShadowReceiver();
    snapshotIdentity=vec4(-1,0,0,1);
#if defined(AZURE_SNAPSHOT_REUSE)
    uint historyKey=azureOrdinaryOpaque?snapshotHistoryKey():0xffffffffu;
    if(snapshotHistoryLoad(historyKey)){snapshotIdentity=vec4(historyKey==0xffffffffu?-1.0:float(historyKey),0,0,1);return;}
#endif
''')
# Only the complete ordinary path publishes a valid key. Diagnostic early exits invalidate it.
end='    outputNormal=encodeReflectionSurface(dot(worldPosition-camera.cameraPosition.xyz,camera.cameraForward.xyz),snapshotNormal,microfacetSurface&&!overlayMaterial?roughness:1.0);'
assert text.count(end)==1
text=text.replace(end,end+'\n#if defined(AZURE_SNAPSHOT_REUSE)\n    snapshotIdentity=vec4(historyKey==0xffffffffu?-1.0:float(historyKey),0,0,1);\n#endif')
(out/'mesh.frag').write_text(text)
for name in ['character_depth.frag','outline_depth.frag']:
 s=(root/'shaders'/name).read_text();s=s.replace('#version 450','#version 450\nlayout(location=2) out vec4 snapshotIdentity;');s=s.replace('void main() {','void main() {\n    snapshotIdentity=vec4(-1,0,0,1);');(out/name).write_text(s)
manifest=json.loads((build/'shader-reload.json').read_text());programs=[]
with (out/'private-program-build.log').open('wb') as log:
 def compile(p,source,defines,output):
  destination=runtime/'shaders'/output
  if destination.exists():destination.unlink()
  command=[manifest['compiler'],*['-D'+d for d in defines],*p['arguments'],*(['--target-env=vulkan1.2'] if 'AZURE_SNAPSHOT_REUSE=1' in defines else []),'-I'+str(root/'shaders'),str(source),'-o',str(destination)]
  subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.3','--relax-block-layout',str(destination)],stdout=log,stderr=subprocess.STDOUT,check=True)
  programs.append(dict(output=output,source=str(source),defines=defines,sha256=hashlib.sha256(destination.read_bytes()).hexdigest()))
 for p in manifest['programs']:
  defines=p['defines'];source=p['source'];output=p['output']
  if source=='mesh.frag' and 'AZURE_OPAQUE_SNAPSHOT=1' in defines:
   compile(p,out/source,defines,output)
   if 'AZURE_ORDINARY_EARLY_DEPTH=1' in defines and not any(x in defines for x in ['AZURE_EXTENDED_MATERIAL_LIGHTING=1','AZURE_INDEPENDENT_COVERAGE=1','AZURE_GEOMETRY_SAMPLES=1','AZURE_VIEW_FOG=1','AZURE_STATIC_ISOLATION=1']):
    compile(p,out/source,defines+['AZURE_SNAPSHOT_REUSE=1'],output.replace('.frag.spv','_snapshot_reuse.frag.spv'))
  elif source=='outline_depth.frag' or source=='character_depth.frag' and 'AZURE_SNAPSHOT_DEPTH=1' in defines:
   compile(p,out/source,defines,output)
   if source=='character_depth.frag':
    at=output.index('_samples') if '_samples' in output else output.index('.frag.spv');alias=output[:at]+'_no_history'+output[at:];shutil.copyfile(build/'shaders'/output,runtime/'shaders'/alias)
  elif source=='mesh.vert' and not any(x in defines for x in ['AZURE_SNAPSHOT_DEPTH=1','AZURE_OUTLINE_MASK=1','AZURE_SURFACE_RADIANCE_REUSE=1','AZURE_SHADOW_HISTORY=1']):
   compile(p,root/'shaders'/source,defines+['AZURE_SHADOW_HISTORY=1'],output.replace('.vert.spv','_snapshot_history.vert.spv'))
(out/'private-programs.json').write_text(json.dumps(programs,indent=2));print('Compiled private programs',len(programs),flush=True)
