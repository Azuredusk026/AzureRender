from pathlib import Path
import json,os,shutil,subprocess,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;mode=sys.argv[1]
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import digest,inputs
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),mode,'--inside']).returncode)
build=root/'build/ninja-msvc-release'
if mode=='candidate' and not (out/'baseline-programs.json').exists():
 (out/'baseline-programs.json').write_text(json.dumps({str(p):digest(p) for p in (build/'shaders').glob('*.spv')},indent=2));shutil.copyfile(build/'AzurePlayer.exe',out/'baseline-AzurePlayer.exe')
 shutil.copyfile(build/'build-provenance.json',out/'baseline-build-provenance.json')
elif mode=='restore':
 for p in out.glob('*.baseline'):
  (root/('src/app' if p.name=='AzureRenderApp.cpp.baseline' else 'src/scenes')/p.name.removesuffix('.baseline')).write_bytes(p.read_bytes())
command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config','Release','--test-target','AzureDepthPrefillRecordingTests','--test-target','AzureMaterialClassEarlyDepthTests','--test-target','AzureRenderNullRhiPassTests','--test-target','AzureRenderRenderGraphTests']
with (out/(mode+'-build.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
shutil.copyfile(build/'build-provenance.json',out/(mode+'-build-provenance.json'))
if mode=='candidate':
 shutil.copyfile(build/'AzurePlayer.exe',out/'candidate-AzurePlayer.exe')
 if not (out/'private-programs.json').exists():subprocess.run([sys.executable,'-X','utf8','-B',str(out/'shaders.py')],check=True)
print(mode+' actual hosts built',flush=True)
