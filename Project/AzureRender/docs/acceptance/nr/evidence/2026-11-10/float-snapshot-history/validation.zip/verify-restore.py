from pathlib import Path
import json,subprocess,sys,hashlib,struct
root=Path.cwd();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify
for config in ['debug','release']:verify(root,json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text()))
for p in out.glob('*.baseline'):
 name=p.name.removesuffix('.baseline');folder='src/app' if name=='AzureRenderApp.cpp' else 'src/scenes';assert (root/folder/name).read_bytes()==p.read_bytes()
assert all(digest(Path(p))==h for p,h in json.loads((out/'baseline-programs.json').read_text()).items())
checks=[]
for name in ['AzureDepthPrefillRecordingTests','AzureMaterialClassEarlyDepthTests','AzureRenderNullRhiPassTests','AzureRenderRenderGraphTests']:
 with (out/('restored-'+name+'.log')).open('wb') as log:p=subprocess.run([str(build/(name+'.exe')),str(build/'shaders')],stdout=log,stderr=subprocess.STDOUT)
 checks.append(dict(name=name,exitCode=p.returncode));assert p.returncode==0,name
def code(path):
 data=path.read_bytes();pe=struct.unpack_from('<I',data,0x3c)[0];sections=struct.unpack_from('<H',data,pe+6)[0];optional=struct.unpack_from('<H',data,pe+20)[0]
 for index in range(sections):
  at=pe+24+optional+40*index
  if data[at:at+8].rstrip(b'\0')==b'.text':
   size,offset=struct.unpack_from('<II',data,at+16);return hashlib.sha256(data[offset:offset+size]).hexdigest()
 raise AssertionError('Missing code section')
before=code(out/'baseline-AzurePlayer.exe');after=code(build/'AzurePlayer.exe')
report=dict(bothConfigurationsVerified=True,sourceFilesRestored=6,programsUnchanged=True,checks=checks,baselineTextSha256=before,restoredTextSha256=after,playerTextIdentical=before==after)
(out/'restore-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report));assert before==after
