from pathlib import Path
import difflib,json,shutil,sys
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;old=root/'build/runs/20261110-021429-snapshot-color-history-9c89e5'
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify,inputs
for config in ['debug','release']:verify(root,json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text()))
(out/'baseline-source.json').write_text(json.dumps(inputs(root),indent=2))
files={p.name.removesuffix('.baseline'):('src/app' if p.name=='AzureRenderApp.cpp.baseline' else 'src/scenes') for p in old.glob('*.baseline')}
assert len(files)==6
for name,folder in files.items():
 p=root/folder/name;before=(old/(name+'.baseline')).read_text().splitlines(keepends=True);after=(old/'active-source'/name).read_text().splitlines(keepends=True)
 baseline=out/(name+'.baseline');assert not baseline.exists();baseline.write_bytes(p.read_bytes());current=p.read_text()
 for group in reversed(list(difflib.SequenceMatcher(a=before,b=after,autojunk=False).get_grouped_opcodes(4))):
  original=''.join(before[group[0][1]:group[-1][2]]);changed=''.join(after[group[0][3]:group[-1][4]])
  assert original and current.count(original)==1,(name,original[:100],current.count(original));current=current.replace(original,changed,1)
 p.write_text(current)
p=root/'src/scenes/CharacterSceneRenderer.cpp';s=p.read_text()
lines=[]
for line in s.splitlines(keepends=True):
 if 'snapshotHistoryCapable_' in line and 'VK_FORMAT_R32_UINT' in line:line=line.replace('VK_FORMAT_R32_UINT','VK_FORMAT_R32_SFLOAT')
 lines.append(line)
s=''.join(lines);assert s.count('id.color.uint32[0]=UINT32_MAX;')==2;s=s.replace('id.color.uint32[0]=UINT32_MAX;','id.color.float32[0]=-1;')
line=next(x for x in s.splitlines() if '"snapshotHistoryPrepared' in x)
s=s.replace(line,line+'\n         << "  \\"snapshotHistoryTriangleCapacity\\": " << snapshotHistoryTriangleCapacity_ << ",\\n"'.replace('\\"','\\"'))
p.write_text(s)
p=root/'src/scenes/CharacterSceneRenderer.hpp';s=p.read_text().replace('    bool snapshotHistoryCapable_=false;','    bool snapshotHistoryCapable_=false;\n    std::uint64_t snapshotHistoryTriangleCapacity_=0;');p.write_text(s)
p=root/'src/scenes/CharacterShadowHistory.inc';s=p.read_text();s=s.replace('shadowHistoryRecorded_=false;shadowHistoryClear_.reset();if(!shadowHistory_&&!snapshotHistoryCapable_)return;','shadowHistoryRecorded_=false;shadowHistoryClear_.reset();snapshotHistoryTriangleCapacity_=0;if(!shadowHistory_&&!snapshotHistoryCapable_)return;')
needle='if(base!=UINT32_MAX)ranges.at(instance.sourceIndex)={base,indices};';assert s.count(needle)==1
s=s.replace(needle,'if(base!=UINT32_MAX){ranges.at(instance.sourceIndex)={base,indices};snapshotHistoryTriangleCapacity_=std::max(snapshotHistoryTriangleCapacity_,(std::uint64_t(base)+indices)/3);}')
p.write_text(s)
for name in ['build.py','shaders.py','capture.py','verify-restore.py']:shutil.copyfile(old/name,out/name)
p=out/'shaders.py';s=p.read_text()
s=s.replace('layout(location=2) out uint snapshotIdentity;','layout(location=2) out vec4 snapshotIdentity;')
s=s.replace('snapshotIdentity=0xffffffffu;','snapshotIdentity=vec4(-1,0,0,1);')
s=s.replace('snapshotIdentity=historyKey;','snapshotIdentity=vec4(historyKey==0xffffffffu?-1.0:float(historyKey),0,0,1);')
s=s.replace('uniform usampler2D previousSnapshotIdentity;','uniform sampler2D previousSnapshotIdentity;')
s=s.replace('    return range.x+first+triangle*3u;','    if(range.x%3u!=0u||first%3u!=0u)return 0xffffffffu;\n    uint key=(range.x+first+triangle*3u)/3u;return key<=16777215u?key:0xffffffffu;')
s=s.replace('    uint previous=valid?texelFetch(previousSnapshotIdentity,pixel,0).r:0xffffffffu;','    float previous=valid?texelFetch(previousSnapshotIdentity,pixel,0).r:-1.0;')
s=s.replace('bool matched=valid&&key==previous&&azureShadowHistoryClean();','bool matched=valid&&float(key)==previous&&azureShadowHistoryClean();')
needle="   if source=='character_depth.frag':shutil.copyfile(build/'shaders'/output,runtime/'shaders'/output.replace('.frag.spv','_no_history.frag.spv'))"
assert s.count(needle)==1
s=s.replace(needle,"   if source=='character_depth.frag':\n    at=output.index('_samples') if '_samples' in output else output.index('.frag.spv');alias=output[:at]+'_no_history'+output[at:];shutil.copyfile(build/'shaders'/output,runtime/'shaders'/alias)")
assert 'out uint snapshotIdentity' not in s and 'snapshotIdentity=historyKey' not in s
p.write_text(s)
p=out/'capture.py';s=p.read_text().replace('frames-corrected','frames')
s=s.replace("rows.append(dict(frame=path.name,sha256=digest(path),", "rows.append(dict(frame=path.name,pngIdentical=digest(path)==digest(reference/'frames'/path.name),sha256=digest(path),")
s=s.replace("all(r['changedPixels']==0 for r in rows)","all(r['changedPixels']==0 and r['pngIdentical'] for r in rows)")
s=s.replace("assert report['metadata'].get('snapshotHistoryPrepared')", "assert report['metadata'].get('snapshotHistoryPrepared') and report['metadata']['snapshotHistoryTriangleCapacity']>0")
p.write_text(s)
source=out/'candidate-source';source.mkdir()
for name,folder in files.items():shutil.copyfile(root/folder/name,source/name)
(out/'source-change.json').write_text(json.dumps({str(root/folder/name):digest(root/folder/name) for name,folder in files.items()},indent=2))
print('Prepared float snapshot candidate; seal lifecycle preserved')
