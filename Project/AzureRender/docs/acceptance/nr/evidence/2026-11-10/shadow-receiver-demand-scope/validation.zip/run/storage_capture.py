from pathlib import Path
import json,struct,traceback,sys
(Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261110-203318-receiver-demand-scope-2ae4d8')/'started.txt').write_text('script entered')
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261110-203318-receiver-demand-scope-2ae4d8');capture=root/'build/runs/20261110-135028-compact-texture-gpu-cost-25d5da';state=json.loads((capture/'state.json').read_text());profile=json.loads((capture/'events/profile.json').read_text());cap=None;c=None;report=dict(status='starting',rows=[])
try:
 (out/'storage-api.json').write_text(json.dumps(report))
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 report['status']='capture-opened';(out/'storage-api.json').write_text(json.dumps(report))
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 report['status']='replay-opened';(out/'storage-api.json').write_text(json.dumps(report))
 for shader,entry in profile['shaders'].items():
  if not any(n.startswith(('mesh','character_snapshot')) for n in entry['programFiles']):continue
  event=next(x['event'] for x in profile['measurements'] if x['shader']==shader);c.SetFrameEvent(event,True);pipe=c.GetPipelineState();reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel);block=reflection.constantBlocks[0];descriptor=pipe.GetConstantBlock(rd.ShaderStage.Pixel,0,0).descriptor
  variables=[]
  for v in block.variables:
   row=dict(name=v.name,offset=v.byteOffset,members=[x.name for x in v.type.members])
   if v.name in ['mainLightDirection','clusterLighting','qaParameters','nprLightingParameters','renderingParameters']:
    row['values']=struct.unpack('<4f',bytes(c.GetBufferData(descriptor.resource,descriptor.byteOffset+v.byteOffset,16)))
   variables.append(row)
  stage=c.GetVulkanPipelineState().fragmentShader
  if 'lighting' in str(entry['programFiles']):
   report.setdefault('storageApi',dict(resources=[dict(name=r.name,bind=r.fixedBindNumber) for r in reflection.readWriteResources],bound=[dict(names=dir(r),text=str(r),accessNames=dir(r.access),descriptorNames=dir(r.descriptor),resource=str(r.descriptor.resource),offset=r.descriptor.byteOffset,size=r.descriptor.byteSize,index=r.access.index) for r in pipe.GetReadWriteResources(rd.ShaderStage.Pixel)],pushBytes=len(c.GetVulkanPipelineState().pushconsts)))

  report['rows'].append(dict(shader=shader,programFiles=entry['programFiles'],event=event,variables=variables,specializationIds=list(stage.specializationIds),specializationData=bytes(stage.specializationData).hex()))
 report['status']='inspected'
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 (out/'storage-api.json').write_text(json.dumps(report,indent=2))
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='inspected' else 1)
