from pathlib import Path
import renderdoc as rd
import json,zlib,hashlib,traceback,sys
out=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-112309-hair-relative-projection-control-b9da17')
prior=out.parent/'20261110-095632-hair-r11-storage-control-93b2d8'
capture=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc')
result=dict(status='starting',variants=[],uvProbes=[]);cap=None;c=None;vs=None;fs=None;resources=[]
def save():(out/'state.json').write_text(json.dumps(result,indent=2)+'\n')
def snapshot(event,stride):
 c.SetFrameEvent(event,True);target=c.GetPipelineState().GetOutputTargets()[0].resource
 raw=bytes(c.GetTextureData(target,rd.Subresource()));assert len(raw)==2560*1440*stride
 return b''.join(raw[(y*2560+1140)*stride:(y*2560+1430)*stride] for y in range(130,440))
def install(original,name,stage):
 code=(out/name).read_bytes();replacement,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,code,rd.ShaderCompileFlags(),stage)
 assert replacement!=rd.ResourceId.Null(),errors
 resources.append(replacement);c.ReplaceResource(original,replacement);return replacement
def free(original,replacement):
 c.RemoveReplacement(original);c.FreeTargetResource(replacement);resources.remove(replacement)
try:
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(capture),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 baseline=snapshot(493,8);originalFinal=snapshot(567,4);c.SetFrameEvent(493,True);pipe=c.GetPipelineState();vs=pipe.GetShader(rd.ShaderStage.Vertex);fs=pipe.GetShader(rd.ShaderStage.Pixel)
 for name in ['control','candidate']:
  result['activeVariant']=name;save();vertex=install(vs,name+'.spv',rd.ShaderStage.Vertex);fragment=install(fs,'fragment.spv',rd.ShaderStage.Pixel)
  hdr=snapshot(493,8);final=snapshot(567,4)
  for suffix,data in [('hdr',hdr),('final',final)]:(out/f'{name}-{suffix}.zlib').write_bytes(zlib.compress(data,9))
  row=dict(name=name,hdrSha256=hashlib.sha256(hdr).hexdigest(),finalSha256=hashlib.sha256(final).hexdigest())
  if name=='control':
   row.update(hdrExact=hdr==zlib.decompress((prior/'candidate-hdr.zlib').read_bytes()),finalExact=final==zlib.decompress((prior/'candidate-final.zlib').read_bytes()));assert row['hdrExact'] and row['finalExact'],row
  free(fs,fragment)
  if name=='candidate':
   uvBaseline=snapshot(493,8)
   for component in [0,1]:
    for shift in [0,12,24]:
     probe=f'uv-{component}-{shift}';fragment=install(fs,probe+'.spv',rd.ShaderStage.Pixel);raw=snapshot(493,8)
     qualification=all(raw[i+4:i+6]==uvBaseline[i+4:i+6] for i in range(0,len(raw),8))
     (out/(probe+'.zlib')).write_bytes(zlib.compress(raw,9));result['uvProbes'].append(dict(name=probe,component=component,shift=shift,blueExact=qualification));save();assert qualification,probe
     free(fs,fragment);assert snapshot(493,8)==uvBaseline
  free(vs,vertex);row['baselineRestored']=snapshot(493,8)==baseline and snapshot(567,4)==originalFinal;result['variants'].append(row);save();assert row['baselineRestored']
 result.update(status='qualified',debugMessages=[str(m.description) for m in c.GetDebugMessages()])
except BaseException:result.update(status='failed',error=traceback.format_exc())
finally:
 if c:
  if fs:c.RemoveReplacement(fs)
  if vs:c.RemoveReplacement(vs)
  result['cleanupBaselineRestored']=snapshot(493,8)==baseline and snapshot(567,4)==originalFinal
  for resource in resources:c.FreeTargetResource(resource)
  c.Shutdown()
 if cap:cap.Shutdown()
 save()
sys.exit(0 if result['status']=='qualified' else 1)
