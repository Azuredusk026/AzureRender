from pathlib import Path
import numpy as np,json,subprocess,hashlib,shutil,zipfile
out=Path(__file__).resolve().parent;prior=out.parent/'20261110-110844-hair-postvs-clip-source-03c2f0'
source=(prior/'vulkan-vertex.spvasm').read_text();(out/'control.spvasm').write_text(source)
cb0=np.fromfile(prior/'native-cb-0-range.bin',dtype='<f4').reshape(-1,4);cb1=np.fromfile(prior/'native-cb-1-range.bin',dtype='<f4').reshape(-1,4)
a=np.fromfile(prior/'native-vertex.bin',dtype='<f4').reshape(-1,33);b=np.fromfile(prior/'vulkan-vertex.bin',dtype='<f4').reshape(-1,64);v=b[:,16:19].copy();v[:,0]*=-1;offset=np.median(a[:,6:9].astype('f8')-v.astype('f8'),axis=0).astype('f4')
decls=[];pool={}
def scalar(x):
 x=np.float32(x);key=int(x.view('u4'))
 if key not in pool:
  name='%proj_constant_'+str(len(pool));pool[key]=name;decls.append(f'{name} = OpConstant %float {float(x)!r}')
 return pool[key]
def vector(name,values):
 ids=[scalar(x) for x in values];decls.append(f'{name} = OpConstantComposite %v4float '+' '.join(ids));return name
rows=[vector('%proj_row'+str(i),cb0[i]) for i in range(32,36)]
yoff,zoff=scalar(offset[1]),scalar(offset[2]);jz,jw=scalar(cb1[19,2]),scalar(cb1[19,3]);two,ntwo=scalar(2),scalar(-2)
hook=f"""%proj_world = OpLoad %v3float %worldPosition
%proj_wx = OpCompositeExtract %float %proj_world 0
%proj_x = OpFNegate %float %proj_wx
%proj_wy = OpCompositeExtract %float %proj_world 1
%proj_y = OpFAdd %float %proj_wy {yoff}
%proj_wz = OpCompositeExtract %float %proj_world 2
%proj_z = OpFAdd %float %proj_wz {zoff}
%proj_x4 = OpCompositeConstruct %v4float %proj_x %proj_x %proj_x %proj_x
%proj_z4 = OpCompositeConstruct %v4float %proj_z %proj_z %proj_z %proj_z
%proj_q0 = OpVectorTimesScalar %v4float {rows[1]} %proj_y
%proj_q1 = OpExtInst %v4float %1 Fma {rows[0]} %proj_x4 %proj_q0
%proj_q2 = OpExtInst %v4float %1 Fma {rows[2]} %proj_z4 %proj_q1
%proj_q3 = OpFAdd %v4float %proj_q2 {rows[3]}
%proj_qx = OpCompositeExtract %float %proj_q3 0
%proj_qy = OpCompositeExtract %float %proj_q3 1
%proj_qw = OpCompositeExtract %float %proj_q3 3
%proj_jx = OpFMul %float %proj_qw {jz}
%proj_jy = OpFMul %float %proj_qw {jw}
%proj_njx = OpFNegate %float %proj_jx
%proj_njy = OpFNegate %float %proj_jy
%proj_outx = OpExtInst %float %1 Fma %proj_njx {two} %proj_qx
%proj_outy = OpExtInst %float %1 Fma %proj_njy {ntwo} %proj_qy
%proj_oldz = OpCompositeExtract %float %563 2
%proj_oldw = OpCompositeExtract %float %563 3
%proj_depth = OpFDiv %float %proj_oldz %proj_oldw
%proj_outz = OpFMul %float %proj_depth %proj_qw
%proj_output = OpCompositeConstruct %v4float %proj_outx %proj_outy %proj_outz %proj_qw
OpStore %564 %proj_output
"""
source=source.replace('       %main = OpFunction','\n'.join(decls)+'\n       %main = OpFunction',1)
pos=source.index('               OpReturn',source.index('       %main = OpFunction'));source=source[:pos]+hook+source[pos:]
annotations=''.join(f'OpDecorate %{n} NoContraction\n' for n in ['proj_y','proj_z','proj_q0','proj_q3','proj_jx','proj_jy','proj_depth','proj_outz'])
source=source.replace('       %void = OpTypeVoid',annotations+'       %void = OpTypeVoid',1)
assert source.count('OpDecorate %proj_y NoContraction')==1
(out/'candidate.spvasm').write_text(source)
for name in ['control','candidate']:
 subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-as.exe','--target-env','vulkan1.0',str(out/(name+'.spvasm')),'-o',str(out/(name+'.spv'))],check=True)
 subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.0',str(out/(name+'.spv'))],check=True)
shutil.copyfile(out.parent/'20261110-095632-hair-r11-storage-control-93b2d8/candidate.spv',out/'fragment.spv')
with zipfile.ZipFile(Path('docs/acceptance/nr/evidence/2026-11-09/hair-uv-sample-region/validation.zip')) as z:
 for c in [0,1]:
  for shift in [0,12,24]:
   name=f'uv-{c}-{shift}.spv';(out/name).write_bytes(z.read(name))
(out/'source.json').write_text(json.dumps(dict(frameOffset=offset.tolist(),calibration='Median common frame translation across all paired VSOut positions; private source diagnosis only',nativeWorldReconstructionExactPerComponent=np.count_nonzero((v+offset).view('u4')==a[:,6:9].copy().view('u4'),axis=0).tolist(),nativeViewProjectionRows=cb0[32:36].tolist(),jitter=cb1[19].tolist(),depth='old clip Z/W divided then multiplied by source clip W; float rounding remains',vertexShaderScope='Only final clip output changes; authored UV, basis, worldPosition and material expressions retained',source=hashlib.sha256((prior/'vulkan-vertex.shader').read_bytes()).hexdigest()),indent=2))
print('Both vertex shaders assembled and validated')
