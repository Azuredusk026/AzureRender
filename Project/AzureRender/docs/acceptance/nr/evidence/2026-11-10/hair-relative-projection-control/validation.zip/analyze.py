from pathlib import Path
import json,zlib,runpy,numpy as np,struct
out=Path(__file__).resolve().parent;b=runpy.run_path(str(out/'baseline.py'));expected=b['expected'];mask=b['mask'];bad=b['bad'];state=json.loads((out/'state.json').read_text());assert state['status']=='qualified' and state['cleanupBaselineRestored'] and not state['debugMessages']
assert all(v['baselineRestored'] for v in state['variants']) and all(p['blueExact'] for p in state['uvProbes'])
control=None;failedControl=None;rows=[]
for name in ['control','candidate']:
 a=np.frombuffer(zlib.decompress((out/(name+'-final.zlib')).read_bytes()),dtype='u1').reshape(310,290,4)[:,:,[2,1,0]].astype('i4');delta=abs(a-expected);failed=mask&(delta.max(axis=2)>1)
 if name=='control':control=a;failedControl=failed;assert int(failed.sum())==6 and int(delta[mask].max())==6
 rows.append(dict(name=name,maskPixels=int(mask.sum()),pixelsOverOneByte=int(failed.sum()),maximumByteError=int(delta[mask].max()),meanAbsoluteByteError=float(delta[mask].mean()),resolvedOriginalFailures=int((bad&~failed).sum()),newOriginalFailures=int((~bad&failed).sum()),resolvedControlFailures=int((failedControl&~failed).sum()),newControlFailures=int((~failedControl&failed).sum()),changedHairPixels=int((np.any(a!=control,axis=2)&mask).sum()),failures=[dict(pixel=[int(x+1140),int(y+130)],absoluteError=delta[y,x].tolist()) for y,x in zip(*np.where(failed))]))
prior=json.loads((out/'uv-source.json').read_text());uv=[]
for r in prior['rows']:
 x,y=r['pixel'];index=((y-130)*290+x-1140)*8;words=[]
 for component in [0,1]:
  word=0
  for shift in [0,12,24]:
   data=zlib.decompress((out/f'uv-{component}-{shift}.zlib').read_bytes());rg=struct.unpack_from('<4e',data,index)[:2];d=[int(round(v*64)) for v in rg];assert all(0<=v<=63 for v in d);word|=(d[0]|(d[1]<<6))<<shift
  assert 0<=word<=0xffffffff;words.append(word)
 value=[struct.unpack('<f',struct.pack('<I',v))[0] for v in words]
 uv.append(dict(pixel=r['pixel'],native=r['native'],baseline=r['vulkan'],candidate=value,nativeBits=r['nativeBits'],candidateBits=words,exact=words==r['nativeBits'],maximumAbsolute=float(np.max(abs(np.array(value)-r['native'])))))
report=dict(status='qualified-private-relative-projection-control',rows=rows,uv=uv,uvExactPoints=sum(r['exact'] for r in uv),uvMaximumAbsolute=max(r['maximumAbsolute'] for r in uv),state=state,source=json.loads((out/'source.json').read_text()),productionChanged=False,overallVisualAcceptance='failed-user-review',scope='Fitted common frame and native camera projection alter final vertex clip output only. Six UV probes retain original blue output. Full frozen17017 hair gate unchanged; this private source control is not a portable camera implementation.')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['uv','state','source']},indent=2));print('UV6',[(r['pixel'],r['maximumAbsolute'],r['exact']) for r in uv if r['pixel'] in [[1306,156],[1319,172],[1322,263],[1193,295],[1193,296],[1193,297]]])
