import hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd(); out=Path(__file__).resolve().parent
source=root/'build/runs/20261109-111635-compact-vertex-source-706378/slice_benchmark.cpp'
text=source.read_text().replace('#include "prior_slice.hpp"','')
text=text[:text.index('ClusterGridDesc desc{')]+r'''
for(unsigned scale:{1U,2U,4U}){
ClusterGridDesc desc{16*scale,9*scale,24*scale,.1F,10000.F,1.0312498882412913F,-1.8333331346511843F,false,-0.0002929684706032276F,7.717559492448345e-05F};
ClusteredLightGrid grid(desc);auto start=std::chrono::steady_clock::now();grid.assign(lights);
auto ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
std::vector<std::array<std::uint32_t,2>> headers;std::vector<std::uint32_t> indices;grid.gpuReceiverData(headers,indices);
std::cout<<"grid "<<scale<<' '<<grid.clusterCount()<<' '<<grid.gpuIndexData().size()<<' '<<indices.size()<<' '<<ms<<'\n';
for(unsigned coarse=0;coarse<24;++coarse){std::uint64_t counts[4]{};
for(unsigned z=coarse*scale;z<(coarse+1)*scale;++z)for(unsigned y=0;y<desc.y;++y)for(unsigned x=0;x<desc.x;++x){auto cell=(z*desc.y+y)*desc.x+x;for(unsigned r=0;r<4;++r)counts[r]+=headers[cell*4+r][1];}
std::cout<<"slice "<<scale<<' '<<coarse;for(auto count:counts)std::cout<<' '<<double(count)/(desc.x*desc.y*scale);std::cout<<'\n';
}}
}
'''
(out/'grid_scope.cpp').write_text(text)
if '--inside' not in sys.argv:
    raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-B',str(__file__),'--inside']).returncode)
command=['cl','/nologo','/std:c++17','/EHsc','/O2','/I'+str(root/'src'),str(out/'grid_scope.cpp'),'/Fo'+str(out/'grid_scope.obj'),'/Fe'+str(out/'grid_scope.exe'),'/link','/INCREMENTAL:NO']
with (out/'build.log').open('wb') as log: subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
result=subprocess.run([str(out/'grid_scope.exe')],capture_output=True,check=True)
(out/'scope.txt').write_bytes(result.stdout); print(result.stdout.decode())
(out/'provenance.json').write_text(json.dumps({'input':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'gridHeaderSha256':hashlib.sha256((root/'src/render/ClusteredLightGrid.hpp').read_bytes()).hexdigest(),'scope':'Frozen 16-light static fixture; uniform cluster weighting, not actual fragment invocation weighting'},indent=2))
