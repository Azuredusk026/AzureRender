from pathlib import Path
import shutil,sys,struct,json,subprocess
out=Path(__file__).resolve().parent;prior=out.parent/'20261109-225636-hair-base-sample-region-0c13c0'
for name in ['dxbc_util.py','D3D12TokenizedProgramFormat.hpp','LICENSE-RenderDoc.txt','checksum-source.json','header-source.json']:
 shutil.copyfile(prior/name,out/name)
sys.path.insert(0,str(out))
from dxbc_util import chunks,words,instructions,opcode,inst,dest,source,imm,fbits,rebuild,checksum
raw=(prior/'native-original.shader').read_bytes();assert checksum(raw)==raw[4:20]
fields=[dict(name='normal',nativeInput=3,variable='%worldNormal_0',type='%v3float',components=3),dict(name='tangent',nativeInput=4,variable='%worldTangent',type='%v4float',components=4)]
cases=[];sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
for field in fields:
 for component in range(field['components']):
  for shift in [0,12,24]:
   name=f'{field["name"]}-{component}-{shift}'
   parts=chunks(raw);index=next(i for i,(kind,_) in enumerate(parts) if kind in [b'SHEX',b'SHDR'])
   w=words(parts[index][1]);items=list(instructions(w));declared=next(item for item in items if item[2]==opcode('DCL_TEMPS'))
   scratch=w[declared[1]+1];w[declared[1]+1]=scratch+1
   returns=[item for item in items if item[2]==opcode('RET')];assert len(returns)==1
   extra=[]
   for mask,offset in [(1,shift),(2,shift+6)]:
    operand=source(field['nativeInput'],component);operand[0]|=1<<12
    extra+=inst('USHR',dest(scratch),operand,imm(offset))
    extra+=inst('AND',dest(scratch),source(scratch),imm(63))
    extra+=inst('UTOF',dest(scratch),source(scratch))
    extra+=inst('MUL',dest(scratch),source(scratch),imm(fbits(1/64)))
    extra+=inst('MOV',dest(0,mask,True),source(scratch))
   end=returns[0][1];w[end:end]=extra;w[1]=len(w);parts[index]=(parts[index][0],struct.pack('<'+'I'*len(w),*w))
   code=rebuild(raw,parts);assert checksum(code)==code[4:20];(out/(name+'.dxbc')).write_bytes(code)
   text=(prior/'sample-0-0.spvasm').read_text()
   text=text.replace('%sample_probe_shift_r = OpConstant %uint 0',f'%sample_probe_shift_r = OpConstant %uint {shift}').replace('%sample_probe_shift_g = OpConstant %uint 6',f'%sample_probe_shift_g = OpConstant %uint {shift+6}')
   text=text.replace('%sample_probe_value = OpCompositeExtract %float %8245 0',f'%basis_probe_loaded = OpLoad {field["type"]} {field["variable"]}\n%sample_probe_value = OpCompositeExtract %float %basis_probe_loaded {component}')
   (out/(name+'.spvasm')).write_text(text)
   for command in [[str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/(name+'.spvasm')),'-o',str(out/(name+'.spv'))],[str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/(name+'.spv'))]]:subprocess.run(command,check=True)
   cases.append(dict(name=name,field=field['name'],component=component,components=field['components'],shift=shift))
(out/'cases.json').write_text(json.dumps(cases,indent=2))
material=out.parent/'20261109-231408-hair-material-sample-region-5f9f16'
(out/'collect.py').write_text((material/'collect.py').read_text().replace(material.name,out.name))
runner=(material/'run.py').read_text()
runner=runner.replace('raise SystemExit(result.returncode)',"import json\nstate=json.loads((out/'probe-results.json').read_text())\nraise SystemExit(result.returncode if result.returncode else (0 if state['status']=='qualified' else 1))")
(out/'run.py').write_text(runner)
print('Prepared 21 paired interpolated normal and tangent probes; original blue retained')
