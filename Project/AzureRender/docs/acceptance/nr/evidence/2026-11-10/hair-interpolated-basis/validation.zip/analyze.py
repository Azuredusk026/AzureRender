from pathlib import Path
import json,struct,math,numpy as np
out=Path(__file__).resolve().parent;d=json.loads((out/'probe-results.json').read_text())
assert d['status']=='qualified' and len(d['captures'])==2
allowed={'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU','NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image'}
assert set(d['captures'][0]['debugMessages'])<=allowed and not d['captures'][1]['debugMessages']
samples={}
for c in d['captures']:
 assert len(c['runs'])==21 and c['baselineRestored'] and all(r['qualified'] for r in c['runs'])
 samples[c['label']]={}
 for field,components in [('normal',3),('tangent',4)]:
  words=np.zeros((len(d['points']),components),dtype='<u4')
  for row in c['runs']:
   case=row['case']
   if case['field']==field:words[:,case['component']] |= np.array(row['values'],dtype='<u4')<<case['shift']
  assert np.isfinite(words.view('<f4')).all();samples[c['label']][field]=words
material=json.loads((out.parent/'20261109-231408-hair-material-sample-region-5f9f16/results.json').read_text())
stable={tuple(r['pixel']):r['exact'] for r in material['rows'] if r['field']=='parameters'}
rows=[];summary={}
for field in ['normal','tangent']:
 a=samples['native'][field];b=samples['vulkan'][field]
 canonical=a.copy();canonical[:,0]^=np.uint32(0x80000000)
 delta=abs(canonical.view('<f4')-b.view('<f4'))
 selected=[]
 for i,pixel in enumerate(d['points']):
  row=dict(field=field,pixel=pixel,nativeBits=a[i].tolist(),vulkanBits=b[i].tolist(),native=a[i].view('<f4').tolist(),vulkan=b[i].view('<f4').tolist(),
   reflectionXMaximumAbsolute=float(delta[i].max()),parameterSampleExact=stable[tuple(pixel)])
  selected.append(row);rows.append(row)
 summary[field]=dict(points=len(selected),reflectionXExactPoints=int(np.all(canonical==b,axis=1).sum()),reflectionXMaximumAbsolute=float(delta.max()),
  stableParameterMaxAbsolute=max(r['reflectionXMaximumAbsolute'] for r in selected if r['parameterSampleExact']))
report=dict(status='qualified-raw-interpolated-basis',summary=summary,rows=rows,qualification=d,
 mappingScope='Raw values are authoritative. X-reflection statistics are a separately labeled coordinate control; tangent W is retained. The material tangent-sign adapter remains a distinct input.',
 scope='31 remaining full-color failures after native visibility source control. Original B channel preserved over the complete 290x310 crop in every paired version.')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(summary,indent=2));print('First point:',rows[0],rows[31])
