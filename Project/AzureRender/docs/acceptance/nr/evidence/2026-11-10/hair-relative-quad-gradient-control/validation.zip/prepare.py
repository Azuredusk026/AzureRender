from pathlib import Path
import re,subprocess,shutil,json
out=Path(__file__).resolve().parent;prior=out.parent/'20261110-112936-hair-relative-fine-gradient-control-d57425';sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
shutil.copyfile(prior/'vertex.spv',out/'vertex.spv');shutil.copyfile(prior/'candidate.spv',out/'control.spv');source=(prior/'candidate.spvasm').read_text();(out/'control.spvasm').write_text(source)
source=source.replace('OpCapability Shader','OpCapability Shader\nOpCapability GroupNonUniform\nOpCapability GroupNonUniformQuad',1)
source=source.replace('       %main = OpFunction','%quad_scope = OpConstant %uint 3\n%quad_lane2 = OpConstant %uint 2\n%quad_lane0 = OpConstant %uint 0\n       %main = OpFunction',1)
lines=[];count=0
for line in source.splitlines():
 m=re.fullmatch(r'(%\S+) = OpImageSampleExplicitLod (%\S+) (%\S+) (%\S+) Grad (%fine_control_\d+_dx) (%fine_control_\d+_dy)',line)
 if not m:lines.append(line);continue
 result,output,sampler,coord,dx,dy=m.groups();prefix='%quad_control_'+str(count)
 lines += [f'{prefix}_dx = OpGroupNonUniformQuadBroadcast %v2float %quad_scope {dx} %quad_lane2',f'{prefix}_dy = OpGroupNonUniformQuadBroadcast %v2float %quad_scope {dy} %quad_lane0',f'{result} = OpImageSampleExplicitLod {output} {sampler} {coord} Grad {prefix}_dx {prefix}_dy'];count+=1
assert count==22,count
(out/'candidate.spvasm').write_text('\n'.join(lines)+'\n')
subprocess.run([str(sdk/'spirv-as.exe'),'--target-env','vulkan1.1',str(out/'candidate.spvasm'),'-o',str(out/'candidate.spv')],check=True)
subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.1',str(out/'candidate.spv')],check=True)
(out/'operations.json').write_text(json.dumps(dict(replacedOperations=count,dxQuadLane=2,dyQuadLane=0,scope='Subgroup',target='vulkan1.1'),indent=2));print('22 flipped-quad substitutions validated')
