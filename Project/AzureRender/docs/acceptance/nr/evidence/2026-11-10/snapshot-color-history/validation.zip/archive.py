from pathlib import Path
import json,hashlib,zipfile,shutil,sys,collections,re
root=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest
active=json.loads((out/'capture-results.json').read_text());initial=json.loads((out/'initial-validation/capture-results.json').read_text());restored=json.loads((out/'restore-results.json').read_text())
assert active['metadata']['snapshotHistoryPrepared'] and not active['validationClean'] and all(x['changedPixels']==0 for x in active['frames']) and len(active['frames'])==4
assert restored['playerTextIdentical'] and len(restored['checks'])==4
log=(out/'capture.log').read_text(errors='replace');errors=[x for x in log.splitlines() if x.startswith('Validation Error:')]
vuids=collections.Counter(re.search(r'\[ (VUID-.*?) \]',x)[1] for x in errors)
assert dict(vuids)=={'VUID-VkGraphicsPipelineCreateInfo-renderPass-06041':4,'VUID-vkCmdDrawIndexed-blendEnable-04727':10}
protected=json.loads(Path('D:/Projects/.handoffs/handoffs/2026/11/20261109-213523-codex-azurerender-01a1b11a-f582-7181-b5ac-/working-file-hashes.json').read_text())
paths=['docs/acceptance/p5/closure/source-evidence/'+x for x in ['interruption.json','manifest.json','performance-provenance-green.log','performance-provenance-red.log']]+['src/app/AzureRenderSupport.cpp','src/rhi/GpuAllocator.hpp','src/rhi/VulkanRhi.cpp','tests/MaterialPipelinePolicyTests.cpp','tests/MotionRecordingTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native/character_surfaces.py','tools/test_native_character_surfaces.py']
assert all(digest(root/p)==protected[p] for p in paths)
summary=dict(status='strict-four-frames-passed-integer-blend-validation-failed',baselineCommit='604de4a',activeCapture=active,initialInactiveCapture=initial,restore=restored,validationErrors=14,validationVuids=vuids,identityImageBytes1440p=2560*1440*4*2,wholeFrameTimingRuns=0,formalRuns=0,protectedFilesUnchanged=13,adopted=False,nativeFourFrameCaptures=2,nativeOutputDirectoryRejections=1,recordingAliasRejections=1)
shutil.copyfile(root/'build/runs/20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json',out/'frozen-project-inputs.json')
evidence=root/'docs/acceptance/nr/evidence/2026-11-10/snapshot-color-history';evidence.mkdir(parents=True,exist_ok=True)
files=[p for p in out.rglob('*') if p.is_file() and p.suffix not in ['.exe','.png'] and not any(part in ['runtime','tmp','frames','frames-corrected'] for part in p.relative_to(out).parts) and (p.name not in ['budget.json','process.log'] or p.parent!=out)]
archive=evidence/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,p.relative_to(out).as_posix())
assert archive.stat().st_size<8*1024**2
summary['archive']={'name':archive.name,'bytes':archive.stat().st_size,'sha256':digest(archive)};summary['members']=[dict(name=p.relative_to(out).as_posix(),bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(files)]
(evidence/'results.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(archive) as z:
 for m in summary['members']:assert hashlib.sha256(z.read(m['name'])).hexdigest()==m['sha256']
for name in ['runtime','frames','frames-corrected']:
 p=(out/name).resolve();assert p.parent==out.resolve() and out.resolve().parent==(root/'build/runs').resolve()
 if p.exists():shutil.rmtree(p)
for p in out.glob('*.exe'):p.unlink()
print(json.dumps(summary['archive']));print('archive members',len(files),'protected',len(paths),'restored',restored['playerTextIdentical'])
