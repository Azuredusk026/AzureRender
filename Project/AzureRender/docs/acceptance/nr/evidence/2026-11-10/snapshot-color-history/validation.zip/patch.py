from pathlib import Path
import json,hashlib
root=Path.cwd();out=Path(__file__).resolve().parent
files=['src/scenes/CharacterSceneRenderer.hpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterShadowHistory.inc','src/scenes/CharacterMaterialSampling.inc','src/scenes/CharacterSurfaceOverlays.inc']
for name in files:
 p=root/name;backup=out/(p.name+'.baseline');assert not backup.exists();backup.write_bytes(p.read_bytes())
def change(name,old,new,count=1):
 p=root/name;s=p.read_text();assert s.count(old)==count,(name,old,s.count(old));p.write_text(s.replace(old,new))
h=files[0];c=files[1];hist=files[2];mat=files[3];surf=files[4]
change(h,'    bool shadowHistoryCapable_=false,shadowHistoryRecorded_=false;','    bool shadowHistoryCapable_=false,shadowHistoryRecorded_=false;\n    bool snapshotHistoryCapable_=false;\n    std::array<GpuTexture,kMaxFramesInFlight> snapshotHistoryIds_{};\n    std::array<bool,kMaxFramesInFlight> snapshotHistoryWritten_{};')
change(c,'    shadowHistoryCapable_=false;','    snapshotHistoryCapable_=context.fragmentPrimitiveIdentity&&context.fragmentStorageAtomics&&context.fragmentQuadControl\n        &&context.rasterizationSamples==VK_SAMPLE_COUNT_1_BIT&&limits.maxColorAttachments>=3\n        &&limits.maxPerStageDescriptorStorageBuffers>=requirements.fragmentBuffers+1\n        &&limits.maxDescriptorSetStorageBuffers>=requirements.descriptorSetBuffers+1\n        &&limits.maxPerStageDescriptorSampledImages>=requirements.sampledImageSlots+3;\n    shadowHistoryCapable_=false;')
change(hist,'    if(!shadowHistoryCapable_)return;','    if(!shadowHistoryCapable_&&!snapshotHistoryCapable_)return;')
change(hist,'        shadowHistory_=std::make_unique','        if(shadowHistoryCapable_)shadowHistory_=std::make_unique')
change(hist,'    if(!shadowHistory_)return;\n    for(auto entry:', '''    if(snapshotHistoryCapable_){
        rhi_->writeDescriptorBuffer({set,49,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,shadowHistoryInputs_.at(slot).buffer,shadowHistoryInputs_.at(slot).size});
        const auto previous=slot^1U;
        rhi_->writeDescriptorImage({set,50,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,snapshotHistoryIds_.at(previous).view,overlaySceneDepth_.at(previous).sampler,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL});
        rhi_->writeDescriptorImage({set,51,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,opaqueSceneColor_.at(previous).view,overlaySceneDepth_.at(previous).sampler,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL});
        rhi_->writeDescriptorImage({set,52,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,overlaySceneDepth_.at(previous).view,overlaySceneDepth_.at(previous).sampler,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL});
    }
    if(!shadowHistory_)return;
    for(auto entry:''')
change(hist,'shadowHistoryRecorded_=false;shadowHistoryClear_.reset();if(!shadowHistory_)return;','shadowHistoryRecorded_=false;shadowHistoryClear_.reset();if(!shadowHistory_&&!snapshotHistoryCapable_)return;')
change(hist,'    append(gizmoTranslation_);','    if(snapshotHistoryCapable_){\n        identity.insert(identity.end(),uniform+41*4+1,uniform+43*4);\n        for(const auto& light:packedLights_){const auto* values=reinterpret_cast<const float*>(&light);identity.insert(identity.end(),values,values+sizeof(light)/sizeof(float));}\n    }\n    append(gizmoTranslation_);')
change(hist,'    shadowHistoryClear_=shadowHistory_->prepareClear(slot,0);','    if(shadowHistory_)shadowHistoryClear_=shadowHistory_->prepareClear(slot,0);')
change(hist,'    if(!shadowHistory_||!shadowHistoryClear_)return;\n    const auto& previous=shadowHistory_->buffer(slot^1U,0);const auto& inputs=shadowHistoryInputs_.at(slot);\n    commands.bufferBarrier({previous.buffer,0,previous.size,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_ACCESS_MEMORY_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT});', '''    if(!shadowHistory_&&!snapshotHistoryCapable_)return;
    if(snapshotHistoryCapable_){
        const auto previous=slot^1U;
        for(const auto image:{snapshotHistoryIds_.at(previous).image.image,opaqueSceneColor_.at(previous).image.image,overlaySceneDepth_.at(previous).image.image})
            commands.imageBarrier({image,snapshotHistoryWritten_.at(previous)?VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL:VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,1,
                VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_ACCESS_MEMORY_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT});
    }
    const auto& inputs=shadowHistoryInputs_.at(slot);
    if(shadowHistory_){const auto& previous=shadowHistory_->buffer(slot^1U,0);
        commands.bufferBarrier({previous.buffer,0,previous.size,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_ACCESS_MEMORY_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT});}''')
change(hist,'    shadowHistory_->recordClear(commands,*shadowHistoryClear_);shadowHistoryClear_.reset();shadowHistoryRecorded_=true;','    if(shadowHistory_&&shadowHistoryClear_)shadowHistory_->recordClear(commands,*shadowHistoryClear_);shadowHistoryClear_.reset();shadowHistoryRecorded_=true;')
change(hist,'    if(shadowHistory_&&shadowHistoryRecorded_&&submission>shadowHistorySubmission_){','    if((shadowHistory_||snapshotHistoryCapable_)&&shadowHistoryRecorded_&&submission>shadowHistorySubmission_){\n        if(snapshotHistoryCapable_)snapshotHistoryWritten_.at(currentFrame_)=true;')
change(hist,'    if(!shadowHistory_)return;const auto& inputs=shadowHistoryInputs_.at(slot);','    if(!shadowHistory_&&!snapshotHistoryCapable_)return;const auto& inputs=shadowHistoryInputs_.at(slot);')
# Images are normal attachments, so the last depth-winning writer owns identity.
change(c,'    pass.depthAttachment=2;pass.externalReadDependency=true;', '    if(snapshotHistoryCapable_)pass.attachments.push_back({VK_FORMAT_R32_UINT,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,true,true,false});\n    pass.depthAttachment=2;pass.externalReadDependency=true;')
change(c,'        if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)attachments.push_back', '        if(snapshotHistoryCapable_){auto& id=snapshotHistoryIds_[frame];id.image=allocator_->createImage2D(context.renderExtent.width,context.renderExtent.height,VK_FORMAT_R32_UINT,VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT|VK_IMAGE_USAGE_SAMPLED_BIT);id.view=rhi_->createImageView(id.image.image,VK_FORMAT_R32_UINT,VK_IMAGE_ASPECT_COLOR_BIT,1);attachments.push_back(id.view);}\n        if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)attachments.push_back')
change(c,'    destroyShadowHistory();','    destroyShadowHistory();snapshotHistoryWritten_={};')
change(c,'        auto& color=opaqueSceneColor_[i];','        auto& id=snapshotHistoryIds_[i];if(id.view)rhi_->destroyImageView(id.view);allocator_->destroyImage(id.image);id={};\n        auto& color=opaqueSceneColor_[i];')
change(c,'    if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)overlayBegin.clearValues.push_back', '    if(snapshotHistoryCapable_){VkClearValue id{};id.color.uint32[0]=UINT32_MAX;overlayBegin.clearValues.push_back(id);}\n    if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)overlayBegin.clearValues.push_back')
change(c,'    if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)begin.clearValues.push_back', '    if(snapshotHistoryCapable_){VkClearValue id{};id.color.uint32[0]=UINT32_MAX;begin.clearValues.push_back(id);}\n    if(surfaceRadiance_)for(unsigned kind=0;kind<SurfaceRadianceCache::kAttachments;++kind)begin.clearValues.push_back')
change(c,'    std::optional<RenderGraph::ResourceId> radianceStatisticsResource;', '''    if(snapshotHistoryCapable_){
        rhi::ImageBarrierDesc id{};id.image=snapshotHistoryIds_.at(context.currentFrame).image.image;
        graph.attachment(prepass,graph.importImage("snapshot-history-id",id),RenderGraphUsage::ColorAttachment,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
        const auto previous=context.currentFrame^1U;
        for(const auto image:{snapshotHistoryIds_.at(previous).image.image,opaqueSceneColor_.at(previous).image.image,overlaySceneDepth_.at(previous).image.image}){
            rhi::ImageBarrierDesc state{};state.image=image;state.newLayout=VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
            graph.use(prepass,graph.importImage("snapshot-history-previous",state),RenderGraphUsage::Sampled,false);
        }
    }
    std::optional<RenderGraph::ResourceId> radianceStatisticsResource;''')
change(c,'(shadowHistory_?3U:0U)','(shadowHistory_?3U:snapshotHistoryCapable_?1U:0U)',2)
change(c,'+ (viewFog_?2U:0U) + (outlineProjectionEnabled_', '+ (viewFog_?2U:0U) + (snapshotHistoryCapable_?3U:0U) + (outlineProjectionEnabled_')
change(c,'+(viewFog_?2U:0U))}', '+(viewFog_?2U:0U)+(snapshotHistoryCapable_?3U:0U))}')
change(c,'        if(shadowHistory_)for(unsigned binding:{45U,46U,49U})', '        if(snapshotHistoryCapable_){bindings.push_back({49,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT});for(unsigned b:{50U,51U,52U})bindings.push_back({b,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_FRAGMENT_BIT});}\n        if(shadowHistory_)for(unsigned binding:{45U,46U,49U})',2)
change(c,'surfaceRadiance_?6U:2U','surfaceRadiance_?6U:snapshotHistoryCapable_?3U:2U',2)
change(c,'depthDesc.colorWriteMasks[1]=0xf;','depthDesc.colorWriteMasks[1]=0xf;if(snapshotHistoryCapable_)depthDesc.colorWriteMasks[2]=VK_COLOR_COMPONENT_R_BIT;')
change(c,'desc.colorWriteMasks[1]=VK_COLOR_COMPONENT_R_BIT;','desc.colorWriteMasks[1]=VK_COLOR_COMPONENT_R_BIT;if(snapshotHistoryCapable_)desc.colorWriteMasks[2]=VK_COLOR_COMPONENT_R_BIT;')
change(c,'shell.colorWriteMasks[1]=VK_COLOR_COMPONENT_R_BIT;','shell.colorWriteMasks[1]=VK_COLOR_COMPONENT_R_BIT;if(snapshotHistoryCapable_)shell.colorWriteMasks[2]=VK_COLOR_COMPONENT_R_BIT;')
change(c,'if(surfaceRadiance_||shadowHistory_){','if(surfaceRadiance_||shadowHistory_||snapshotHistoryCapable_){')
change(c,'         << "  \\"shadowHistoryPrepared\\": "', '         << "  \\"shadowHistoryPrepared\\": "',0) if False else None
marker='         << "  \\"shadowHistoryPrepared'
# Insert a separate stable JSON key through the adjacent normal stream statement.
s=(root/c).read_text();needle='         << "  \\"shadowHistoryPrepared'.replace('\\"','\\"')
line=next(x for x in s.splitlines() if '"shadowHistoryPrepared' in x)
s=s.replace(line,'         << "  \\"snapshotHistoryPrepared\\": " << (snapshotHistoryCapable_?"true":"false") << ",\\n"\n'.replace('\\"','\\"')+line)
(root/c).write_text(s)
change(mat,'    VkShaderModule historyVertex=VK_NULL_HANDLE;', '    VkShaderModule historyVertex=VK_NULL_HANDLE;\n    VkShaderModule snapshotVertex=VK_NULL_HANDLE,snapshotReuse=VK_NULL_HANDLE;')
change(mat,'        VkShaderModule cachedColor=VK_NULL_HANDLE,cachedSnapshot=VK_NULL_HANDLE;', '''        if(needed&&early&&snapshotHistoryCapable_){
            auto vertex=vertexPath;vertex.insert(vertex.rfind(".vert.spv"),"_snapshot_history");snapshotVertex=rhi_->createShaderModule(readBinaryFile(vertex));
            const auto found=std::find_if(materialShaderVariants_.begin(),materialShaderVariants_.end(),[&](const auto& v){return v.scene==earlySnapshotModule;});
            if(found==materialShaderVariants_.end())throw std::logic_error("Snapshot history source unavailable");
            auto file=found->path;file.insert(file.rfind(".frag.spv"),"_snapshot_reuse");snapshotReuse=createMaterialShaderModule(file);
        }
        VkShaderModule cachedColor=VK_NULL_HANDLE,cachedSnapshot=VK_NULL_HANDLE;''')
change(mat,'            if(early){auto covered=desc;covered.fragmentShader=earlySnapshotModule;', '            if(early){auto covered=desc;covered.fragmentShader=earlySnapshotModule;\n                if(snapshotVertex){covered.vertexShader=snapshotVertex;covered.fragmentShader=snapshotReuse;}')
# All returns of the initialization function release its temporary vertex module.
text=(root/mat).read_text();text=text.replace('if(historyVertex)rhi_->destroyShaderModule(historyVertex);','if(historyVertex)rhi_->destroyShaderModule(historyVertex);if(snapshotVertex)rhi_->destroyShaderModule(snapshotVertex);');(root/mat).write_text(text)
change(mat,'surfaceRadiance_?6U:2U','surfaceRadiance_?6U:snapshotHistoryCapable_?3U:2U')
change(mat,'desc.colorWriteMasks[1]=0xf;', 'desc.colorWriteMasks[1]=0xf;if(snapshotHistoryCapable_)desc.colorWriteMasks[2]=VK_COLOR_COMPONENT_R_BIT;')
change(surf,'        desc.colorWriteMasks[0]=VK_COLOR_COMPONENT_R_BIT|VK_COLOR_COMPONENT_G_BIT|VK_COLOR_COMPONENT_B_BIT;', '        desc.colorWriteMasks[0]=VK_COLOR_COMPONENT_R_BIT|VK_COLOR_COMPONENT_G_BIT|VK_COLOR_COMPONENT_B_BIT;\n        if(pass&&snapshotHistoryCapable_)desc.colorWriteMasks[2]=VK_COLOR_COMPONENT_R_BIT;')
for name in files:(out/(Path(name).name+'.diagnostic')).write_bytes((root/name).read_bytes())
(out/'source-change.json').write_text(json.dumps({name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files},indent=2))
print('Private host patch applied')
