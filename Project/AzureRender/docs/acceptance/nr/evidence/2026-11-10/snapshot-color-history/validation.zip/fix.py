from pathlib import Path
import json,shutil
root=Path.cwd();out=Path(__file__).resolve().parent
initial=out/'initial-validation';initial.mkdir(exist_ok=True)
for name in ['capture.log','capture-results.json','capture-command.json','runtime.json','private-programs.json','candidate-build-provenance.json','candidate-build.log','mesh.frag','character_depth.frag','outline_depth.frag']:
 p=out/name
 if p.exists():shutil.copyfile(p,initial/name)
for p in out.glob('*.baseline'):
 name=p.name.removesuffix('.baseline');shutil.copyfile(root/'src/scenes'/name,initial/(name+'.diagnostic'))
p=root/'src/scenes/CharacterSceneRenderer.cpp';s=p.read_text()
needle='        VkShaderModule simpleDepthVertex=VK_NULL_HANDLE;'
assert s.count(needle)==1
s=s.replace(needle,'        const auto prefillDepthModule=rhi_->createShaderModule(mainFragment(bindlessTextures_?"/character_snapshot_depth_bindless_no_history.frag.spv":"/character_snapshot_depth_no_history.frag.spv"));\n'+needle)
s=s.replace('auto prefill=desc;prefill.colorWriteMasks.assign(prefill.colorAttachmentCount,0);prefill.depthBias=true;','auto prefill=desc;prefill.fragmentShader=prefillDepthModule;prefill.colorWriteMasks.assign(prefill.colorAttachmentCount,0);prefill.depthBias=true;')
needle='        }catch(...){if(simpleDepthVertex)rhi_->destroyShaderModule(simpleDepthVertex);rhi_->destroyShaderModule(simpleDepthModule);throw;}'
assert s.count(needle)==1
s=s.replace(needle,needle.replace('throw;','rhi_->destroyShaderModule(prefillDepthModule);throw;'))
s=s.replace('        rhi_->destroyShaderModule(simpleDepthVertex);rhi_->destroyShaderModule(simpleDepthModule);','        rhi_->destroyShaderModule(simpleDepthVertex);rhi_->destroyShaderModule(simpleDepthModule);rhi_->destroyShaderModule(prefillDepthModule);')
p.write_text(s)
p=out/'shaders.py';s=p.read_text();s=s.replace("*p['arguments'],'--target-env=vulkan1.3','-I'", "*p['arguments'],*(['--target-env=vulkan1.2'] if 'AZURE_SNAPSHOT_REUSE=1' in defines else []),'-I'")
s=s.replace("compile(p,out/source,defines,output)\n  elif source=='mesh.vert'", "compile(p,out/source,defines,output)\n   if source=='character_depth.frag':shutil.copyfile(build/'shaders'/output,runtime/'shaders'/output.replace('.frag.spv','_no_history.frag.spv'))\n  elif source=='mesh.vert'")
s=s.replace('import json,os,subprocess,sys,hashlib','import json,os,subprocess,sys,hashlib,shutil')
p.write_text(s)
(out/'private-programs.json').unlink()
for name in ['capture-results.json','runtime.json']:
 p=out/name
 if p.exists():p.unlink()
print('Removed SPIR-V demote capability and isolated prefill attachment outputs')
