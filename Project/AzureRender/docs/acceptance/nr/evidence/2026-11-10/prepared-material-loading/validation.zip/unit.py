from pathlib import Path
import os,sys,subprocess,json
r=Path.cwd();o=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tools'));from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'))
with (o/'unit-build.log').open('wb') as f:subprocess.run([str(r/'tools/msvc_env.bat'),'cmake','--build','build/ninja-msvc-release','--target','AzureMaterialTextureSharingTests','-j','3'],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=300)
with (o/'unit-tests.log').open('wb') as f:subprocess.run([str(r/'build/ninja-msvc-release/AzureMaterialTextureSharingTests.exe'),str(r/'build/ninja-msvc-release/shaders')],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=30)
print((o/'unit-tests.log').read_text())
