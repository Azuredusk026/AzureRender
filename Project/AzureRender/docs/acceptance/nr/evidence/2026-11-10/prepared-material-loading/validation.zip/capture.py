import json,os,subprocess,sys,time
from pathlib import Path
import numpy as np
from PIL import Image
from memory_observer import run_observed
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,digest,verify
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));os.environ.update(DOTNET_ROOT='D:/Tools/dotnet9',VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer')
os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','AZURE_CPU_WORK_REPORT']:os.environ.pop(key,None)
verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*(build/'shaders').glob('*.spv')]}
lock=json.loads((root/'build/runs/20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text());assert all(digest(Path(p))==h for p,h in lock.items())
reference=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint'
command=json.loads((reference/'command.json').read_text());command[0]=str(build/'AzurePlayer.exe');command[command.index('--capture-dir')+1]=str(out/'frames');command[command.index('--runtime-report')+1]=str(out/'runtime.json');command+=['--resource-root',str(build)]
(out/'capture-command.json').write_text(json.dumps(command,indent=2));start=time.monotonic()
assert not (out/'frames').exists(), 'Capture output must be fresh'
with (out/'capture.log').open('wb') as log:p=run_observed(command,log,out)
rows=[]
for image in sorted((out/'frames').glob('frame_*.png')):
    a=np.asarray(Image.open(image).convert('RGB'));b=np.asarray(Image.open(reference/'frames'/image.name).convert('RGB'));diff=np.abs(a.astype('i2')-b.astype('i2'))
    rows.append(dict(frame=image.name,sha256=digest(image),changedPixels=int(np.count_nonzero(np.any(diff,axis=2))),maximumByteError=int(diff.max()),pngIdentical=digest(image)==digest(reference/'frames'/image.name)))
manifest=json.loads((out/'frames/capture_manifest.json').read_text());log=(out/'capture.log').read_text(errors='replace')
report=dict(materialTextureCache=manifest['materialTextureCache'],sceneLoad=manifest['sceneLoad'],exitCode=p.returncode,seconds=time.monotonic()-start,frames=rows,validationClean=not any(x in log for x in ['Validation Error:','Validation Warning:','SYNC-HAZARD','VUID-']),allocatorZero='Allocator after unload: buffers=0 images=0' in log,defaultIsolationDisabled=not manifest['defaultIsolationSelected'],shadowHistoryDisabled=not manifest['shadowHistoryPrepared'],sourceUnchanged=inputs(root)==before,productsUnchanged=all(digest(Path(p))==h for p,h in products.items()),projectInputsUnchanged=all(digest(Path(p))==h for p,h in lock.items()))
(out/'capture-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
assert p.returncode==0 and len(rows)==4 and all(r['changedPixels']==0 and r['pngIdentical'] for r in rows)
cache=report['materialTextureCache'];assert cache['referencedPixelBytes']>0 and cache['releasedIdentityStorageBytes']<cache['releasedIdentityBytes']
assert cache['sealed'] and cache['retainedPixelBytes']==0 and cache['releasedIdentityBytes']==1664821444 and cache['residentBytes']+cache['channelSavedBytes']==2155557400 and cache['compactedTextures']>0 and cache['channelSavedBytes']>0 and cache['uniqueTextures']==385
assert all(report[k] for k in ['validationClean','allocatorZero','defaultIsolationDisabled','shadowHistoryDisabled','sourceUnchanged','productsUnchanged','projectInputsUnchanged'])
