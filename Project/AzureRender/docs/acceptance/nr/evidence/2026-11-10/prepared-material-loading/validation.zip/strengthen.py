from pathlib import Path
import sys,os,json,subprocess,hashlib
r=Path.cwd();o=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tools'));from artifact_maintenance import managed_environment
from build_provenance import inputs,verify,digest
os.environ.update(managed_environment(o/'tmp'));before=inputs(r)
os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
reports=[]
for config in ['Release','Debug']:
 b=r/('build/ninja-msvc-'+config.lower());old=json.loads((b/'build-provenance.json').read_text());targets=list(old['buildScope']['testProducts']);cmd=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(b),'--config',config]
 for t in targets:cmd+=['--test-target',t]
 with (o/(config.lower()+'-field-build.log')).open('wb') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=180)
 new=json.loads((b/'build-provenance.json').read_text());changed=[p for p,h in old['products'].items() if new['products'].get(p)!=h]
 assert changed==[str(b/'AzureMaterialTextureSharingTests.exe')],changed
 with (o/(config.lower()+'-field-tests.log')).open('wb') as f:subprocess.run([str(b/'AzureMaterialTextureSharingTests.exe'),str(b/'shaders')],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=60)
 (o/(config.lower()+'-final-build-provenance.json')).write_text(json.dumps(new,indent=2));verify(r,new);reports.append(dict(config=config,onlyChangedProduct=changed,unchangedRuntimeAndOtherTests=True,fieldGoldenInputs=13))
assert inputs(r)==before
(o/'field-qualification.json').write_text(json.dumps(dict(checks=reports,productionSourceUnchanged=True),indent=2));print('Independent 13-field golden inputs passed; only the selected test products changed')
