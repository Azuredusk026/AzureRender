from pathlib import Path
import sys,subprocess
out=Path(__file__).resolve().parent
for name in ['calibration-warm','recheck-clear-warm']:
 print('Running '+name,flush=True)
 subprocess.run([sys.executable,'-X','utf8','-B',str(out/name/'run_compare.py')],check=True,timeout=380)
