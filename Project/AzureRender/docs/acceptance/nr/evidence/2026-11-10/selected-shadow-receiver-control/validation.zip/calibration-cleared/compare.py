from pathlib import Path
import json,hashlib,sys,traceback
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261110-155849-selected-shadow-receiver-control-c1c21e/calibration-cleared';a=root/'build/runs/20261110-135028-compact-texture-gpu-cost-25d5da'
state=json.loads((a/'state.json').read_text());profile=json.loads((a/'events/profile.json').read_text());report=dict(bothRolesUseIdentityReplacement=True,clearBeforeRoleSwitch=True,status='starting',scope='Identical captured SPIR-V replacement calibration',captureSha256=state['captureSha256']);cap=None;c=None
save=lambda:(out/'compare-state.json').write_text(json.dumps(report,indent=2))
def durations():return {int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
try:
 save();cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 shaders={k:v for k,v in profile['shaders'].items() if any(n.startswith(('mesh','character_snapshot')) for n in v['programFiles'])};compiled={};baselines={};rows=[]
 for key,entry in shaders.items():
  event=next(r['event'] for r in profile['measurements'] if r['shader']==key);c.SetFrameEvent(event,True);pipe=c.GetPipelineState();shader=pipe.GetShader(rd.ShaderStage.Pixel)
  raw=bytes(pipe.GetShaderReflection(rd.ShaderStage.Pixel).rawBytes);assert hashlib.sha256(raw).hexdigest()==entry['sha256']
  program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,raw,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert program!=rd.ResourceId.Null(),errors
  baselineProgram,baselineErrors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,raw,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert baselineProgram!=rd.ResourceId.Null(),baselineErrors
  baselines[key]=(shader,baselineProgram)
  compiled[key]=(shader,program);rows.append(dict(shader=key,sha256=entry['sha256'],sameRawBytes=True,programFiles=entry['programFiles'],errors=errors))
 for key,(original,unused) in compiled.items():assert str(original)==key,'Original resource identity changed'
 def applyOverrides(mapping):
  for original,unused in compiled.values():c.RemoveReplacement(original)
  for original,replacement in mapping.values():c.ReplaceResource(original,replacement)
 report['programs']=rows;pixel=json.loads((a/'profile-state.json').read_text());last={}
 for row in pixel['pixelEvents']:
  if not row['hasChildren'] and row['shader'] in shaders:
   colors=tuple(row.get('colorTargets',[]));last[colors]=max(last.get(colors,0),row['event'])
 events=sorted(set(last.values())|{max(r['event'] for r in profile['measurements'] if r['kind']=='draw')});controls={}
 for event in events:
  c.SetFrameEvent(event,True)
  for index,target in enumerate(c.GetPipelineState().GetOutputTargets()):
   if target.resource!=rd.ResourceId.Null():controls[(event,index)]=(target.resource,bytes(c.GetTextureData(target.resource,rd.Subresource())))
 applyOverrides(compiled)
 durations()
 applyOverrides(baselines)
 durations();report['timings']=[dict(mode='baseline',milliseconds=durations())];save()
 applyOverrides(compiled)
 comparisons=[]
 for (event,index),(resource,data) in controls.items():
  c.SetFrameEvent(event,True);value=bytes(c.GetTextureData(resource,rd.Subresource()));comparisons.append(dict(event=event,target=index,equal=value==data,baselineSha256=hashlib.sha256(data).hexdigest(),replacementSha256=hashlib.sha256(value).hexdigest()))
 for unused in range(2):report['timings'].append(dict(mode='candidate',milliseconds=durations()));save()
 applyOverrides(baselines)
 report['timings'].append(dict(mode='baseline',milliseconds=durations()));matched={r['event'] for r in profile['measurements'] if r['shader'] in shaders}
 report['summary']=[dict(mode=r['mode'],allEventMs=sum(r['milliseconds'].values()),matchedEventMs=sum(ms for e,ms in r['milliseconds'].items() if e in matched)) for r in report['timings']]
 report.update(status='compared',allTargetsEqual=all(v['equal'] for v in comparisons),comparisons=comparisons);save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='compared' else 1)
