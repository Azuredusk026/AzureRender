from pathlib import Path
import renderdoc as rd
import json,hashlib,sys,traceback
out=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261110-103733-hair-normal-param-mip-content-0d8625')
main=Path('D:/Projects/FYP/Project/AzureRender')
cases=[('native',main/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc',950,[(17,'parameters'),(18,'normals')]),
       ('vulkan',main/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc',493,[(12,'parameters'),(8,'normals')])]
report=dict(status='starting',textures=[]);cap=None;c=None
try:
    for label,path,event,bindings in cases:
        cap=rd.OpenCaptureFile();assert cap.OpenFile(str(path),'',None)==rd.ResultCode.Succeeded
        status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
        c.SetFrameEvent(event,True);pipe=c.GetPipelineState();reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
        for binding,field in bindings:
            matches=[]
            for used in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel):
                resource=reflection.readOnlyResources[used.access.index]
                if resource.fixedBindNumber==binding:matches.append(used)
            assert len(matches)==1,(label,len(matches))
            used=matches[0];target=used.descriptor.resource
            texture=next(t for t in c.GetTextures() if t.resourceId==target)
            row=dict(label=label,field=field,event=event,binding=binding,resource=str(target),
                format=texture.format.Name(),width=texture.width,height=texture.height,mips=texture.mips,files=[])
            report['textures'].append(row)
            assert texture.width>0 and texture.height>0 and texture.mips>0,row
            for mip in range(texture.mips):
                save=rd.TextureSave();save.resourceId=target;save.destType=rd.FileType.DDS;save.mip=mip
                destination=out/f'{label}-{field}-{mip}.dds'
                result=c.SaveTexture(save,str(destination));assert result==rd.ResultCode.Succeeded,str(result)
                raw=destination.read_bytes()
                row['files'].append(dict(mip=mip,name=destination.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
            row['debugMessages']=[str(m.description) for m in c.GetDebugMessages()]
        c.Shutdown();c=None;cap.Shutdown();cap=None
        (out/'export-state.json').write_text(json.dumps(report,indent=2)+'\n')
    report['status']='exported'
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
    if c:c.Shutdown()
    if cap:cap.Shutdown()
    (out/'export-state.json').write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if report['status']=='exported' else 1)
