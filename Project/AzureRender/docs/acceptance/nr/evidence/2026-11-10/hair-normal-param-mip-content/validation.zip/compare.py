from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image,__version__ as pillow_version
out=Path(__file__).resolve().parent
state=json.loads((out/'export-state.json').read_text());assert state['status']=='exported' and len(state['textures'])==4
expected={'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU','NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image'}
for t in state['textures']:
 assert not t['debugMessages'] if t['label']=='vulkan' else set(t['debugMessages'])<=expected
 for f in t['files']:
  raw=(out/f['name']).read_bytes();assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256']
rows=[]
for field in ['parameters','normals']:
 a=next(t for t in state['textures'] if t['label']=='native' and t['field']==field)
 b=next(t for t in state['textures'] if t['label']=='vulkan' and t['field']==field)
 assert (a['width'],a['height'],a['mips'])==(b['width'],b['height'],b['mips'])
 for mip in range(a['mips']):
  native=np.array(Image.open(out/f'native-{field}-{mip}.dds').convert('RGBA'))
  candidate=np.array(Image.open(out/f'vulkan-{field}-{mip}.dds').convert('RGBA'))
  assert native.shape==candidate.shape==(max(1,a['height']>>mip),max(1,a['width']>>mip),4)
  canonical=candidate.copy()
  if field=='normals':canonical[:,:,[1,3]]=255-canonical[:,:,[1,3]]
  delta=abs(native.astype('i4')-canonical.astype('i4'))
  raw=abs(native.astype('i4')-candidate.astype('i4'))
  flip=abs(native[::-1].astype('i4')-canonical.astype('i4'))
  rows.append(dict(field=field,mip=mip,extent=list(native.shape[:2]),texels=int(native.shape[0]*native.shape[1]),differentPixels=int(np.any(delta,axis=2).sum()),maxByteError=int(delta.max()),differentComponentsPerChannel=np.count_nonzero(delta,axis=(0,1)).tolist(),maxPerChannel=delta.max(axis=(0,1)).tolist(),rawDifferentPixels=int(np.any(raw,axis=2).sum()),verticalFlipDifferentPixels=int(np.any(flip,axis=2).sum()),nativeDecodedSha256=hashlib.sha256(native.tobytes()).hexdigest(),vulkanDecodedSha256=hashlib.sha256(candidate.tobytes()).hexdigest(),canonicalVulkanSha256=hashlib.sha256(canonical.tobytes()).hexdigest()))
report=dict(status='actual-bound-texture-content-audited',mips=rows,export=state,pillowVersion=pillow_version,allParametersExact=all(r['differentPixels']==0 for r in rows if r['field']=='parameters'),allCanonicalNormalsExact=all(r['differentPixels']==0 for r in rows if r['field']=='normals'),scope='DDS/Pillow decoded content only. Normal G/A uses byte complement. Actual filtered sample values and color gates remain separate.')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['export','mips']},indent=2))
for r in rows:print(r['field'],r['mip'],r['differentPixels'],r['maxByteError'],r['maxPerChannel'])
