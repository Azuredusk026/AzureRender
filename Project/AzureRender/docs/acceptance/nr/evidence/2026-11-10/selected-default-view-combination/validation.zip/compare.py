from pathlib import Path
import json,hashlib,sys,traceback,struct,subprocess,math,re
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261110-162938-selected-default-view-combination-001ae4';a=root/'build/runs/20261110-135028-compact-texture-gpu-cost-25d5da'
state=json.loads((a/'state.json').read_text());profile=json.loads((a/'events/profile.json').read_text());report=dict(referenceUsesReplacement=True,status='starting',sourceBase='274615b',scope='Current 720p replay; Retain selected receiver positions and gradients; all four derivative expressions preserved; selected receiver plus ordinary-main default view; both timed roles use replacement pipelines; native acceptance is separate',captureSha256=state['captureSha256']);cap=None;c=None
def save():(out/'compare-state.json').write_text(json.dumps(report,indent=2))
def durations():
 for unused in range(16):c.SetFrameEvent(max(r['event'] for r in profile['measurements'] if r['kind']=='draw'),True)
 return {int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
try:
 save();cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 shaders={k:dict(v,programFile=next(n for n in v['programFiles'] if n.startswith(('mesh','character_snapshot')))) for k,v in profile['shaders'].items() if any(n.startswith(('mesh','character_snapshot')) for n in v['programFiles'])};compiled={};baselines={};rows=[]
 manifest=json.loads((root/'build/ninja-msvc-release/shader-reload.json').read_text());source=root/'shaders';private=out/'candidate-source';private.mkdir()
 original=(source/'mesh.frag').read_text();assert original.count('camera.renderingParameters.w')==1
 (private/'selected_receiver.glsl').write_bytes((out/'selected_receiver.glsl').read_bytes())
 oldHeader='float sampleCascadeShadow(int cascade,float normalDotLight,vec2 depthGradient,float normalCurvature) {';assert original.count(oldHeader)==1
 original=original.replace(oldHeader,'float sampleCascadeShadow(int cascade,float normalDotLight,vec2 depthGradient,float normalCurvature,vec3 projectedPosition) {')
 position='vec3 p=shadowPositions[cascade].xyz/shadowPositions[cascade].w;';assert original.count(position)==1;original=original.replace(position,'vec3 p=projectedPosition;')
 declaration='vec2 shadowReceiverGradients[4];';assert original.count(declaration)==1
 original=original.replace(declaration,'#include "selected_receiver.glsl"\nAzureSelectedShadowReceiver selectedShadowReceiver;\nfloat shadowReceiverDepth;\nint shadowReceiverCascade;')
 selection='float depth=dot(worldPosition-camera.cameraPosition.xyz,camera.cameraForward.xyz);\n    int c=depth<=camera.cascadeSplits.x?0:(depth<=camera.cascadeSplits.y?1:(depth<=camera.cascadeSplits.z?2:3));';assert original.count(selection)==1
 original=original.replace(selection,'float depth=shadowReceiverDepth;\n    int c=shadowReceiverCascade;')
 entry='void prepareShadowReceiver() {';assert original.count(entry)==1
 initial='\n    shadowReceiverDepth=dot(worldPosition-camera.cameraPosition.xyz,camera.cameraForward.xyz);\n    float depth=shadowReceiverDepth;\n    shadowReceiverCascade=depth<=camera.cascadeSplits.x?0:(depth<=camera.cascadeSplits.y?1:(depth<=camera.cascadeSplits.z?2:3));\n    selectedShadowReceiver=azureEmptyShadowReceiver();'
 original=original.replace(entry,entry+initial)
 assignment=next(line for line in original.splitlines() if 'shadowReceiverGradients[i]=' in line)
 retained=assignment.replace('shadowReceiverGradients[i]=','vec2 gradient=')+'\n        if(i==shadowReceiverCascade){selectedShadowReceiver.currentPosition=p;selectedShadowReceiver.currentGradient=gradient;}\n        if(i==shadowReceiverCascade+1){selectedShadowReceiver.nextPosition=p;selectedShadowReceiver.nextGradient=gradient;}'
 original=original.replace(assignment,retained)
 first='sampleCascadeShadow(c,normalDotLight,shadowReceiverGradients[c],shadowReceiverCurvature)';second='sampleCascadeShadow(c+1,normalDotLight,shadowReceiverGradients[c+1],shadowReceiverCurvature)';assert original.count(first)==1 and original.count(second)==1
 original=original.replace(first,'sampleCascadeShadow(c,normalDotLight,selectedShadowReceiver.currentGradient,shadowReceiverCurvature,selectedShadowReceiver.currentPosition)').replace(second,'sampleCascadeShadow(c+1,normalDotLight,selectedShadowReceiver.nextGradient,shadowReceiverCurvature,selectedShadowReceiver.nextPosition)')
 assert 'shadowReceiverGradients' not in original
 parameters={}
 for key,entry in shaders.items():
  event=next(r['event'] for r in profile['measurements'] if r['shader']==key);c.SetFrameEvent(event,True);pipe=c.GetPipelineState();shader=pipe.GetShader(rd.ShaderStage.Pixel)
  reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel);assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==entry['sha256']
  baselineProgram,baselineErrors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,bytes(reflection.rawBytes),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert baselineProgram!=rd.ResourceId.Null(),baselineErrors
  baselines[key]=(shader,baselineProgram)
  descriptor=pipe.GetConstantBlock(rd.ShaderStage.Pixel,0,0).descriptor
  raw=bytes(c.GetBufferData(descriptor.resource,descriptor.byteOffset+108,4));bits=struct.unpack('<I',raw)[0];radius=struct.unpack('<f',raw)[0];assert math.isfinite(radius)
  filename=entry['programFile'];assert filename not in parameters or parameters[filename]==bits;parameters[filename]=bits
  candidateText=original;viewChanges=[];viewInputs=None
  fragment=c.GetVulkanPipelineState().fragmentShader
  originalSpec=dict(ids=list(fragment.specializationIds),dataHex=bytes(fragment.specializationData).hex());assert str(fragment.resourceId)==str(shader)
  if filename.startswith('mesh'):
   lighting=struct.unpack('<f',bytes(c.GetBufferData(descriptor.resource,descriptor.byteOffset+64,4)))[0]
   qa=struct.unpack('<4f',bytes(c.GetBufferData(descriptor.resource,descriptor.byteOffset+128,16)))
   trace=struct.unpack('<4f',bytes(c.GetBufferData(descriptor.resource,descriptor.byteOffset+512,16)))
   assert lighting==1.0 and qa[0]==0.0 and qa[1]==0.0 and qa[2]==1.0 and trace[0]==2.0,(filename,lighting,qa,trace)
   viewInputs=dict(lighting=lighting,qa=qa,trace=trace)
   for field,threshold,value in [('clusterLighting','>.5','true'),('clusterLighting','<.5','false'),('screenReflectionTrace','>.5','true'),('screenReflectionTrace','>1.5','true')]:
    pattern=r'camera\.'+field+r'\.x\s*'+re.escape(threshold[0])+r'\s*'+re.escape(threshold[1:])
    candidateText,count=re.subn(pattern,lambda m:'(azureOrdinaryOpaque?'+value+':('+m.group(0)+'))',candidateText);viewChanges.append(dict(pattern=pattern,count=count))
   for name,pattern,value in [('render',r'int qaIsolationMode = int\(floor\(AZURE_QA_ISOLATION \+ 0\.5\)\);','int qaIsolationMode = azureOrdinaryOpaque?0:int(floor(AZURE_QA_ISOLATION + 0.5));'),('effect',r'int qaEffectMode = int\(floor\(camera\.qaParameters\.y \+ 0\.5\)\);','int qaEffectMode = azureOrdinaryOpaque?0:int(floor(camera.qaParameters.y + 0.5));'),('enabled',r'bool qaEffectDisabled = camera\.qaParameters\.z < 0\.5;','bool qaEffectDisabled = azureOrdinaryOpaque?false:camera.qaParameters.z < 0.5;')]:
    candidateText,count=re.subn(pattern,value,candidateText);assert count==1,(name,count);viewChanges.append(dict(name=name,count=count))
  shader_source=private/('combined-'+str(bits)+'-'+filename[:-4]);shader_source.write_text(candidateText)
  specification=next(v for v in manifest['programs'] if v['output']==filename);assert specification['source']=='mesh.frag'
  command=[manifest['compiler'],*specification['arguments'],*['-D'+d for d in specification['defines']],'-I'+str(source),str(shader_source),'-o',str(out/filename)]
  built=subprocess.run(command,capture_output=True,text=True,timeout=30);(out/(filename+'.build.json')).write_text(json.dumps(dict(command=command,returncode=built.returncode,stdout=built.stdout,stderr=built.stderr),indent=2));assert built.returncode==0,built.stderr
  validated=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe',str(out/filename)],capture_output=True,text=True,timeout=15);assert validated.returncode==0,validated.stderr
  program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/entry['programFile']).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel);assert program!=rd.ResourceId.Null(),errors
  compiled[key]=(shader,program);rows.append(dict(shader=key,file=entry['programFile'],event=event,shadowRadius=radius,shadowRadiusBits=bits,viewInputs=viewInputs,viewChanges=viewChanges,originalSpecialization=originalSpec,errors=errors))
 for key,(original,unused) in compiled.items():assert str(original)==key,'Original resource identity changed'
 def applyOverrides(mapping):
  for original,unused in compiled.values():c.RemoveReplacement(original)
  for original,replacement in mapping.values():c.ReplaceResource(original,replacement)
 report.update(status='compiled',programs=rows,clearBeforeRoleSwitch=True,consecutiveWarmReplays=16);save()
 draws=sorted((r for r in profile['measurements'] if r['kind']=='draw'),key=lambda x:x['seconds'],reverse=True)
 pixel=json.loads((a/'profile-state.json').read_text());last={}
 for row in pixel['pixelEvents']:
  if not row['hasChildren'] and row['shader'] in shaders:
   colors=tuple(row.get('colorTargets',[]));last[colors]=max(last.get(colors,0),row['event'])
 events=sorted(set(last.values())|{max(r['event'] for r in draws)})
 report['comparedEvents']=events
 controls={}
 for event in events:
  c.SetFrameEvent(event,True)
  for index,target in enumerate(c.GetPipelineState().GetOutputTargets()):
   if target.resource!=rd.ResourceId.Null():controls[(event,index)]=(target.resource,bytes(c.GetTextureData(target.resource,rd.Subresource())))
 applyOverrides(compiled)
 durations() # Warm candidate pipelines before the retained ABBA batch.
 applyOverrides(baselines)
 durations() # Warm all original pipelines again before the retained baseline.
 report['status']='baseline-read';report['timings']=[dict(mode='baseline',milliseconds=durations())];save()
 applyOverrides(compiled)
 comparisons=[]
 for (event,index),(resource,data) in controls.items():
  c.SetFrameEvent(event,True);value=bytes(c.GetTextureData(resource,rd.Subresource()));comparisons.append(dict(event=event,target=index,bytes=len(data),equal=value==data,baselineSha256=hashlib.sha256(data).hexdigest(),candidateSha256=hashlib.sha256(value).hexdigest()))
 report.update(status='candidate-read',comparisons=comparisons);save()
 for unused in range(2):report['timings'].append(dict(mode='candidate',milliseconds=durations()));save()
 applyOverrides(baselines)
 report['timings'].append(dict(mode='baseline',milliseconds=durations()))
 matched={r['event'] for r in profile['measurements'] if r['shader'] in shaders}
 report['summary']=[dict(mode=r['mode'],allEventMs=sum(r['milliseconds'].values()),matchedEventMs=sum(ms for e,ms in r['milliseconds'].items() if e in matched)) for r in report['timings']]
 report.update(status='compared',allTargetsEqual=all(r['equal'] for r in comparisons));save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='compared' else 1)
