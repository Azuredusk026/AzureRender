from pathlib import Path
import os,subprocess,sys,json
root=Path.cwd();out=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'tools'));from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
with (out/'driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'classify.py')],cwd=out,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=180)
s=json.loads((out/'scope.json').read_text());assert p.returncode==0 and s['status']=='classified-target-scope',s
print(s['status'],s['events'],len(s['groups']))
