from pathlib import Path
import json,sys,traceback,collections,hashlib
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261110-205154-complete-capture-cost-map-6a2a0d';source=root/'build/runs/20261110-135028-compact-texture-gpu-cost-25d5da'
profile=json.loads((source/'events/profile.json').read_text());capture=json.loads((source/'state.json').read_text());cap=None;c=None;report=dict(status='starting',sourceHead='1eea1ee',captureSourceHead='274615b',captureSha256=capture['captureSha256'])
def save():(out/'structured-api.json').write_text(json.dumps(report,indent=2))
try:
 save();cap=rd.OpenCaptureFile();assert cap.OpenFile(capture['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 structured=c.GetStructuredFile();samples=[]
 for chunk in structured.chunks:
  if any(x in chunk.name for x in ['vkCmdBindPipeline','vkCmdDrawIndexed','vkCmdExecuteCommands']):
   if sum(x['name']==chunk.name for x in samples)>=2:continue
   samples.append(dict(name=chunk.name,api=dir(chunk),children=[dict(name=x.name,api=dir(x),basic=str(x.data.basic),dataNames=dir(x.data),typeNames=dir(x.type),base=str(x.type.basetype)) for x in [chunk.GetChild(i) for i in range(chunk.NumChildren())]]))
  if len(samples)>=6:break
 report['structuredSamples']=samples
 actions={}
 def walk(items):
  for a in items:actions[a.eventId]=a;walk(a.children)
 walk(c.GetRootActions());textures={str(t.resourceId):t for t in c.GetTextures()};resources={str(r.resourceId):r.name for r in c.GetResources()};groups={};pixels={r['event']:r for r in json.loads((source/'profile-state.json').read_text())['pixelEvents']}
 for row in profile['measurements']:
  a=actions[row['event']];depth=str(a.depthOut);colors=[str(r) for r in a.outputs if r!=rd.ResourceId.Null()];key=json.dumps([row['kind'],depth,colors]);g=groups.setdefault(key,dict(kind=row['kind'],depth=depth,colors=colors,events=[],milliseconds=0,psInvocations=0,samplesPassed=0,indices=0))
  g['events'].append(row['event']);g['milliseconds']+=row['seconds']*1000;px=pixels.get(row['event'],{});g['psInvocations']+=px.get('ps',0);g['samplesPassed']+=px.get('samplesPassed',0);g['indices']+=int(a.numIndices)*int(a.numInstances)
 rows=sorted(groups.values(),key=lambda g:g['milliseconds'],reverse=True);report.update(status='grouped',groups=rows);save()
 shaderFiles=collections.defaultdict(list)
 for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv'):shaderFiles[hashlib.sha256(p.read_bytes()).hexdigest()].append(p.name)
 byevent={r['event']:r for r in profile['measurements']}
 for g in rows:
  g['targets']=[dict(resource=resource,name=resources.get(resource),width=textures[resource].width,height=textures[resource].height,format=textures[resource].format.Name()) for resource in [g['depth'],*g['colors']] if resource in textures]
  event=max(g['events'],key=lambda e:byevent[e]['seconds']);c.SetFrameEvent(event,True);pipe=c.GetPipelineState();g['representativeEvent']=event;g['shaders']=[]
  for stage in ([rd.ShaderStage.Compute] if g['kind']=='dispatch' else [rd.ShaderStage.Vertex,rd.ShaderStage.Pixel]):
   r=pipe.GetShaderReflection(stage)
   if r:
    sha=hashlib.sha256(bytes(r.rawBytes)).hexdigest();g['shaders'].append(dict(stage=str(stage),resource=str(pipe.GetShader(stage)),sha256=sha,programFiles=shaderFiles.get(sha,[])))
  save()
 report.update(status='classified-target-scope',events=sum(len(g['events']) for g in rows),sumEventMs=sum(g['milliseconds'] for g in rows),scope='All measured events grouped by recorded action targets; program identities describe representative event only; no new timings');save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='classified-target-scope' else 1)
