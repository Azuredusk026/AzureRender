from pathlib import Path
import json,sys,traceback,collections,hashlib,struct
import renderdoc as rd
root=Path('D:/Projects/FYP/Project/AzureRender');out=root/'build/runs/20261110-205154-complete-capture-cost-map-6a2a0d';source=root/'build/runs/20261110-135028-compact-texture-gpu-cost-25d5da'
profile=json.loads((source/'events/profile.json').read_text());capture=json.loads((source/'state.json').read_text());cap=None;c=None;report=dict(status='starting',sourceHead='1eea1ee',captureSourceHead='274615b',captureSha256=capture['captureSha256'])
def save():(out/'pipeline-scope.json').write_text(json.dumps(report,indent=2))
try:
 save();cap=rd.OpenCaptureFile();assert cap.OpenFile(capture['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 actions={}
 def walk(items):
  for a in items:actions[a.eventId]=a;walk(a.children)
 walk(c.GetRootActions());textures={str(t.resourceId):t for t in c.GetTextures()};resources={str(r.resourceId):r.name for r in c.GetResources()};groups={};pixels={r['event']:r for r in json.loads((source/'profile-state.json').read_text())['pixelEvents']}
 for row in profile['measurements']:
  a=actions[row['event']];depth=str(a.depthOut);colors=[str(r) for r in a.outputs if r!=rd.ResourceId.Null()];key=json.dumps([row['kind'],depth,colors]);g=groups.setdefault(key,dict(kind=row['kind'],depth=depth,colors=colors,events=[],milliseconds=0,psInvocations=0,samplesPassed=0,indices=0))
  g['events'].append(row['event']);g['milliseconds']+=row['seconds']*1000;px=pixels.get(row['event'],{});g['psInvocations']+=px.get('ps',0);g['samplesPassed']+=px.get('samplesPassed',0);g['indices']+=int(a.numIndices)*int(a.numInstances)
 structured=c.GetStructuredFile();bound={};pipelineForChunk={}
 for i,chunk in enumerate(structured.chunks):
  if chunk.name=='vkBeginCommandBuffer':
   field=chunk.FindChild('commandBuffer')
   if field:bound[str(field.AsResourceId())]={}
  if chunk.name=='vkCmdBindPipeline':
   command=str(chunk.FindChild('commandBuffer').AsResourceId());point=chunk.FindChild('pipelineBindPoint').AsInt();pipeline=str(chunk.FindChild('pipeline').AsResourceId());bound.setdefault(command,{})[point]=pipeline
  if chunk.name.startswith('vkCmdDraw') or chunk.name.startswith('vkCmdDispatch'):
   field=chunk.FindChild('commandBuffer');point=1 if chunk.name.startswith('vkCmdDispatch') else 0
   assert field is not None
   pipelineForChunk[i]=bound.get(str(field.AsResourceId()),{}).get(point)
 byevent={r['event']:r for r in profile['measurements']};full={};eventRows=[]
 for row in profile['measurements']:
  a=actions[row['event']];cursor=a;matches=[]
  while cursor and not matches:
   matches=[e.chunkIndex for e in cursor.events if e.chunkIndex in pipelineForChunk];cursor=cursor.parent
  assert matches,('no recorded draw ancestor',row['event'])
  chunk=matches[-1];pipeline=pipelineForChunk[chunk];assert pipeline,('no bound pipeline',row['event'],chunk)
  g=full.setdefault((row['kind'],pipeline),dict(kind=row['kind'],pipeline=pipeline,events=[],milliseconds=0,psInvocations=0,samplesPassed=0,indices=0))
  g['events'].append(row['event']);g['milliseconds']+=row['seconds']*1000;px=pixels.get(row['event'],{});g['psInvocations']+=px.get('ps',0);g['samplesPassed']+=px.get('samplesPassed',0);g['indices']+=int(a.numIndices)*int(a.numInstances)
  eventRows.append(dict(row,pipeline=pipeline,chunkIndex=chunk))
 rows=sorted(full.values(),key=lambda g:g['milliseconds'],reverse=True);assert len(rows)<=256
 report.update(status='pipeline-mapped',groups=rows,events=len(eventRows));(out/'mapped-events.json').write_text(json.dumps(eventRows,indent=2));save()
 shaderFiles=collections.defaultdict(list)
 for p in (root/'build/ninja-msvc-release/shaders').glob('*.spv'):shaderFiles[hashlib.sha256(p.read_bytes()).hexdigest()].append(p.name)
 for g in rows:
  event=max(g['events'],key=lambda e:byevent[e]['seconds']);c.SetFrameEvent(event,True);pipe=c.GetPipelineState();g['representativeEvent']=event;g['shaders']=[]
  actual=str(pipe.GetComputePipelineObject() if g['kind']=='dispatch' else pipe.GetGraphicsPipelineObject());assert actual==g['pipeline'],('pipeline identity',event,actual,g['pipeline'])
  g['depth']=str(pipe.GetDepthTarget().resource) if g['kind']=='draw' else 'ResourceId::0';g['colors']=[str(t.resource) for t in pipe.GetOutputTargets() if t.resource!=rd.ResourceId.Null()] if g['kind']=='draw' else []
  g['targets']=[dict(resource=resource,name=resources.get(resource),width=textures[resource].width,height=textures[resource].height,format=textures[resource].format.Name()) for resource in [g['depth'],*g['colors']] if resource in textures]
  for stage in ([rd.ShaderStage.Compute] if g['kind']=='dispatch' else [rd.ShaderStage.Vertex,rd.ShaderStage.Pixel]):
   r=pipe.GetShaderReflection(stage)
   if r:
    sha=hashlib.sha256(bytes(r.rawBytes)).hexdigest();g['shaders'].append(dict(stage=str(stage),resource=str(pipe.GetShader(stage)),sha256=sha,programFiles=shaderFiles.get(sha,[])))
  if g['kind']=='draw':
   stage=c.GetVulkanPipelineState().fragmentShader;reflection=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
   variables=[v for b in reflection.constantBlocks if b.compileConstants for v in b.variables] if reflection else []
   assert len(variables)==len(stage.specializationIds)
   g['specialization']=[dict(name=v.name,id=int(stage.specializationIds[i]),offset=v.byteOffset,valueU32=struct.unpack_from('<I',bytes(stage.specializationData),v.byteOffset)[0]) for i,v in enumerate(variables)]
  save()
 report.update(status='classified-all-pipelines',events=sum(len(g['events']) for g in rows),sumEventMs=sum(g['milliseconds'] for g in rows),scope='All measured events mapped from recorded command-buffer pipeline bindings; each distinct pipeline validated against replay state; no new timings');save()
except Exception:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
sys.exit(0 if report['status']=='classified-target-scope' else 1)
