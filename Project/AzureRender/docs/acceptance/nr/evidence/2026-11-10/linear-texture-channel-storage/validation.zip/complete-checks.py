from pathlib import Path
import os,sys,json,subprocess,xml.etree.ElementTree as ET
r=Path.cwd();o=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tools'));from artifact_maintenance import managed_environment
from build_provenance import verify,inputs
os.environ.update(managed_environment(o/'tmp'));before=inputs(r)
with (o/'debug-null-rhi-pass.log').open('wb') as log:subprocess.run([str(r/'tools/msvc_env.bat'),'ctest','--test-dir','build/ninja-msvc-debug','-C','Debug','--output-on-failure','--no-tests=error','-R','^AzureRender.NullRhiPass$','--output-junit',str(o/'debug-null-rhi-pass.xml')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
cases=ET.parse(o/'debug-null-rhi-pass.xml').findall('.//testcase');assert len(cases)==1 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
partial=json.loads((o/'debug-partial-results.json').read_text());release=ET.parse(o/'release-tests.xml').findall('.//testcase');assert len(release)==13
for config in ['Release','Debug']:verify(r,json.loads((r/('build/ninja-msvc-'+config.lower())/'build-provenance.json').read_text()))
assert inputs(r)==before
(o/'build-results.json').write_text(json.dumps(dict(checks=[dict(config='Release',tests=13,skips=0),dict(config='Debug',tests=len(partial['passedTests'])+1,skips=0)],debugBatchTimeoutPreserved=True,sourceUnchanged=True,cacheCasesPerConfiguration=13),indent=2))
print('26 effective checks passed; initial outer timeout remains recorded')
