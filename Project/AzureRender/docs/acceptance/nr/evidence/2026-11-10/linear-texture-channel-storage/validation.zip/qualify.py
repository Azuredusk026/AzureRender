from pathlib import Path
import runpy
out=Path(__file__).resolve().parent
for name in ['complete-checks.py','intel.py','capture.py']:
 print('Running '+name,flush=True)
 runpy.run_path(str(out/name),run_name='__main__')
