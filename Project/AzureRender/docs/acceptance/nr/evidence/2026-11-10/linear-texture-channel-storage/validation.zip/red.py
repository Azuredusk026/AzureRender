from pathlib import Path
import os,sys,subprocess,json
r=Path.cwd();o=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'))
command=[str(r/'tools/msvc_env.bat'),'cmake','--build','build/ninja-msvc-release','--target','AzureSampledTextureCacheTests','-j','3']
with (o/'red-build.log').open('wb') as f:p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=120)
s=(o/'red-build.log').read_text(errors='replace');assert p.returncode!=0 and 'channelSavedBytes' in s and 'override' in s
(o/'red.json').write_text(json.dumps(dict(exitCode=p.returncode,expectedMissingContract=True)))
print('Expected missing-contract compilation failure confirmed')
