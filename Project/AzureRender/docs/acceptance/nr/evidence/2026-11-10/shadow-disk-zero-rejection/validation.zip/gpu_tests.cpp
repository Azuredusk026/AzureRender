#include "private_fixture.hpp"
#include "resources/BinaryFile.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <random>
#include <vector>
using namespace azurerender;
int main(int argc,char** argv)try{
 if(argc!=2)throw std::invalid_argument("Expected weight comparison shader");
 constexpr unsigned count=1048576;std::vector<std::array<float,4>> values;values.reserve(count);
 for(float radius:{0.F,.0000001F,.03125F,.125F,.5F,1.F,3.F,6.F,8.F,16.F}){int bound=int(std::ceil(radius+.5F));for(unsigned f=0;f<256;++f){float fx=float(f)/256,fy=float((f*37)%256)/256;
  for(int y=-bound;y<=bound;y+=2)for(int x=-bound;x<=bound;x+=2)values.push_back({float(x)-fx,float(y)-fy,radius,0});}}
 const auto footprints=values.size();std::mt19937 random(0x41bc63);
 while(values.size()<count){float radius=std::max(.125F,float(random()&0xfffff)/65536.F),x=float(random()&0xfffff)/1048576.F*36-18,y=float(random()&0xfffff)/1048576.F*36-18;
  if(values.size()%4==0){float angle=float(random()&0xfffff)/1048576.F*6.283185307F,reach=radius+.5F;float scale=1+float(int(random()%5)-2)*0.0000001F;
   x=std::cos(angle)*reach*scale;y=std::sin(angle)*reach*scale;if(x<0)x-=1;if(y<0)y-=1;}
  values.push_back({x,y,radius,0});}
 if(values.size()!=count)throw std::runtime_error("Weight test domain size mismatch");
 test::VulkanComputeFixture host(false,false,false,false,false,false,true);auto& backend=*host.backend;
 rhi::GpuBuffer inputs{},differences{},rejections{};VkDescriptorSetLayout setLayout{};VkDescriptorPool pool{};VkPipelineLayout layout{};VkShaderModule shader{};VkPipeline pipeline{};
 auto cleanup=std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*){if(pipeline)backend.destroyPipeline(pipeline);if(shader)backend.destroyShaderModule(shader);if(layout)backend.destroyPipelineLayout(layout);if(pool)backend.destroyDescriptorPool(pool);if(setLayout)backend.destroyDescriptorSetLayout(setLayout);host.allocator.destroyBuffer(rejections);host.allocator.destroyBuffer(differences);host.allocator.destroyBuffer(inputs);});
 inputs=host.allocator.createBuffer(values.size()*sizeof(values[0]),VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
 differences=host.allocator.createBuffer(values.size()*16,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);rejections=host.allocator.createBuffer(values.size()*4,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
 std::memcpy(inputs.mapped,values.data(),inputs.size);host.allocator.flush(inputs,0,inputs.size);
 setLayout=backend.createDescriptorSetLayout({{0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},{1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},{2,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT}});
 rhi::DescriptorPoolDesc description;description.sizes={{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,3}};description.maxSets=1;pool=backend.createDescriptorPool(description);auto set=backend.allocateDescriptorSets(pool,setLayout,1).front();
 backend.writeDescriptorBuffer({set,0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,inputs.buffer,inputs.size});backend.writeDescriptorBuffer({set,1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,differences.buffer,differences.size});backend.writeDescriptorBuffer({set,2,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,rejections.buffer,rejections.size});
 const rhi::PushConstantRangeDesc push{VK_SHADER_STAGE_COMPUTE_BIT,4};layout=backend.createPipelineLayout(setLayout,&push);shader=backend.createShaderModule(readBinaryFile(argv[1]));pipeline=backend.createComputePipeline({shader,layout});
 host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer){commands.bufferBarrier({inputs.buffer,0,inputs.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT});
  commands.bindComputePipeline(pipeline);commands.bindComputeDescriptorSet(layout,set);commands.pushConstants(layout,VK_SHADER_STAGE_COMPUTE_BIT,0,&count,4);commands.dispatch((count+63)/64,1,1);
  for(const auto* buffer:{&differences,&rejections})commands.bufferBarrier({buffer->buffer,0,buffer->size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});});
 host.allocator.invalidate(differences,0,differences.size);host.allocator.invalidate(rejections,0,rejections.size);
 const auto diff=static_cast<const std::array<unsigned,4>*>(differences.mapped);const auto rejected=static_cast<const unsigned*>(rejections.mapped);std::uint64_t zeros=0,footprintZeros=0;
 for(unsigned i=0;i<count;++i){if(diff[i]!=std::array<unsigned,4>{0,0,0,0})throw std::runtime_error("Weight mismatch at "+std::to_string(i)+" offset="+std::to_string(values[i][0])+","+std::to_string(values[i][1])+" radius="+std::to_string(values[i][2]));
  if(rejected[i]>1)throw std::runtime_error("Invalid rejection marker");zeros+=rejected[i];if(i<footprints)footprintZeros+=rejected[i];}
 if(!zeros||!footprintZeros)throw std::runtime_error("Zero rejection positive control is empty");
 cleanup.reset();if(host.errors.load())throw std::runtime_error("Vulkan validation error or warning");
 std::cout<<host.properties.deviceName<<": inputs="<<count<<" exactComponents="<<count*4<<" rejected="<<zeros<<" footprintInputs="<<footprints<<" footprintRejected="<<footprintZeros<<" validation=enabled\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
