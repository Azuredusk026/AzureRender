vec4 azureCandidateDiskWeights(vec2 offset,float radius,out bool rejected){
 vec2 nearest=min(abs(offset),abs(offset+1.0));float reach=radius+.5;
 rejected=dot(nearest,nearest)>reach*reach+.001;
 if(rejected)return vec4(0);
 return shadowDiskQuadWeights(offset,radius);
}
