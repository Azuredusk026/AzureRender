from pathlib import Path
import subprocess,sys
out=Path(__file__).resolve().parent
for name,timeout in [('qualify_gpu.py',240),('run_compare.py',380)]:
 print('Running '+name,flush=True)
 subprocess.run([sys.executable,'-X','utf8','-B',str(out/name)],check=True,timeout=timeout)
