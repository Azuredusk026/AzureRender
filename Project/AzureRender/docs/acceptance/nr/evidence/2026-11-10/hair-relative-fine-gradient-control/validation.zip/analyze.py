from pathlib import Path
import json,zlib,runpy,numpy as np,struct
out=Path(__file__).resolve().parent;b=runpy.run_path(str(out/'baseline.py'));expected=b['expected'];mask=b['mask'];bad=b['bad'];state=json.loads((out/'state.json').read_text());assert state['status']=='qualified' and state['cleanupBaselineRestored'] and not state['debugMessages']
assert all(v['geometryBaselineRestored'] for v in state['variants']) 
control=None;failedControl=None;rows=[]
for name in ['control','candidate']:
 a=np.frombuffer(zlib.decompress((out/(name+'-final.zlib')).read_bytes()),dtype='u1').reshape(310,290,4)[:,:,[2,1,0]].astype('i4');delta=abs(a-expected);failed=mask&(delta.max(axis=2)>1)
 if name=='control':control=a;failedControl=failed;assert int(failed.sum())==2 and int(delta[mask].max())==6
 rows.append(dict(name=name,maskPixels=int(mask.sum()),pixelsOverOneByte=int(failed.sum()),maximumByteError=int(delta[mask].max()),meanAbsoluteByteError=float(delta[mask].mean()),resolvedOriginalFailures=int((bad&~failed).sum()),newOriginalFailures=int((~bad&failed).sum()),resolvedControlFailures=int((failedControl&~failed).sum()),newControlFailures=int((~failedControl&failed).sum()),changedHairPixels=int((np.any(a!=control,axis=2)&mask).sum()),failures=[dict(pixel=[int(x+1140),int(y+130)],absoluteError=delta[y,x].tolist()) for y,x in zip(*np.where(failed))]))
report=dict(status='qualified-relative-fine-gradient-control',rows=rows,state=state,operations=json.loads((out/'operations.json').read_text()),productionChanged=False,overallVisualAcceptance='failed-user-review',scope='Private fine derivative control after source camera projection, source visibility, selected-main saturation and storage-grid controls. Frozen17017 mask and one-byte threshold unchanged; this diagnostic does not imply portable production equivalence.')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['state','operations']},indent=2))
