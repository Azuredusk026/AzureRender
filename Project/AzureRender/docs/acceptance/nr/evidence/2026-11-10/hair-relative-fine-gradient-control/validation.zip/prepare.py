from pathlib import Path
import subprocess,re,json,shutil
out=Path(__file__).resolve().parent;prior=out.parent/'20261110-112309-hair-relative-projection-control-b9da17';sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
shutil.copyfile(prior/'candidate.spv',out/'vertex.spv');shutil.copyfile(prior/'fragment.spv',out/'control.spv')
subprocess.run([str(sdk/'spirv-dis.exe'),str(out/'control.spv'),'-o',str(out/'control.spvasm')],check=True)
source=(out/'control.spvasm').read_text();definitions={m[1]:m[2] for line in source.splitlines() if (m:=re.match(r'\s*(%\S+) = (.+)$',line))};bindings={m[1]:int(m[2]) for m in re.finditer(r'OpDecorate (%\S+) Binding (\d+)',source)}
selected={1,2,3,5,6,7,8,12};lines=[];operations=[]
for line in source.splitlines():
 m=re.fullmatch(r'\s*(%\S+) = OpImageSampleImplicitLod (%\S+) (%\S+) (%\S+)',line)
 if not m:lines.append(line);continue
 result,output,sampler,coord=m.groups();load=re.fullmatch(r'OpLoad %\S+ (%\S+)',definitions.get(sampler,''))
 if not load or bindings.get(load[1]) not in selected:lines.append(line);continue
 prefix='%fine_control_'+str(len(operations));lines += [f'{prefix}_dx = OpDPdxFine %v2float {coord}',f'{prefix}_dy = OpDPdyFine %v2float {coord}',f'{result} = OpImageSampleExplicitLod {output} {sampler} {coord} Grad {prefix}_dx {prefix}_dy'];operations.append(dict(result=result,binding=bindings[load[1]],coordinate=coord))
assert len(operations)==22,len(operations)
text='\n'.join(lines)+'\n'
if 'OpCapability DerivativeControl' not in text:text=text.replace('OpCapability Shader','OpCapability Shader\nOpCapability DerivativeControl',1)
(out/'candidate.spvasm').write_text(text)
subprocess.run([str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/'candidate.spvasm'),'-o',str(out/'candidate.spv')],check=True)
subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/'candidate.spv')],check=True)
(out/'operations.json').write_text(json.dumps(operations,indent=2));print('22 fine derivative substitutions validated')
