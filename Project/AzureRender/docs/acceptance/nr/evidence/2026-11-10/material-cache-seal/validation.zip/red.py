from pathlib import Path
import os,subprocess,sys,json
root=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
with (out/'red.log').open('wb') as log:p=subprocess.run(['cmake','--build','--preset','msvc-release','--target','AzureSampledTextureCacheTests','-j','3'],stdout=log,stderr=subprocess.STDOUT)
text=(out/'red.log').read_text(errors='replace');assert p.returncode!=0 and 'C2039' in text and 'seal' in text and 'releasedIdentityBytes' in text
(out/'red-result.json').write_text(json.dumps(dict(expectedCompileFailure=True,exitCode=p.returncode,reason='New seal lifecycle contract is absent'),indent=2));print('RED: new lifecycle contract is absent, as expected')
