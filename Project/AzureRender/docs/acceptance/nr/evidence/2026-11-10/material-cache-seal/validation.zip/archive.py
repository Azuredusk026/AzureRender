from pathlib import Path
import json,hashlib,zipfile,sys,shutil,re,subprocess
root=Path.cwd();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify
for config in ['debug','release']:verify(root,json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text()))
capture=json.loads((out/'capture-results.json').read_text());checks=json.loads((out/'build-results.json').read_text());sharing=json.loads((out/'sharing-results.json').read_text());memory=json.loads((out/'memory-observations.json').read_text())
assert capture['exitCode']==0 and capture['validationClean'] and capture['allocatorZero'] and len(capture['frames'])==4 and all(f['changedPixels']==0 and f['pngIdentical'] for f in capture['frames'])
assert sharing['totalEffectiveChecks']==20 and all(c['previousRuntimeAndTestProductsIdentical'] for c in sharing['checks'])
cache=capture['materialTextureCache'];assert cache['sealed'] and cache['retainedPixelBytes']==0 and cache['releasedIdentityBytes']==1664821444
protected=json.loads(Path('D:/Projects/.handoffs/handoffs/2026/11/20261109-213523-codex-azurerender-01a1b11a-f582-7181-b5ac-/working-file-hashes.json').read_text())
paths=['docs/acceptance/p5/closure/source-evidence/'+x for x in ['interruption.json','manifest.json','performance-provenance-green.log','performance-provenance-red.log']]+['src/app/AzureRenderSupport.cpp','src/rhi/GpuAllocator.hpp','src/rhi/VulkanRhi.cpp','tests/MaterialPipelinePolicyTests.cpp','tests/MotionRecordingTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native/character_surfaces.py','tools/test_native_character_surfaces.py'];assert all(digest(root/p)==protected[p] for p in paths)
sourceFiles=['src/render/SampledTextureCache.hpp','src/render/SampledTextureCache.cpp','src/scenes/CharacterSceneRenderer.cpp','tests/SampledTextureCacheTests.cpp','tests/NullRhiPassTests.cpp','tests/MaterialTextureSharingTests.cpp']
for name in sourceFiles:
 dest=out/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,dest)
(out/'source-diff.patch').write_bytes(subprocess.check_output(['git','diff','--',*sourceFiles]))
shutil.copyfile(root/'build/runs/20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json',out/'frozen-project-inputs.json')
log=(out/'capture.log').read_text(errors='replace');times=[int(x)/1000 for x in re.findall(r'\[(\d+)\].*Capture progress:',log)];rows=[x for x in memory['samples'] if times[0]-.5<=x['unixSeconds']<=times[-1]+.1];assert rows
observations=dict(peakWorkingSetBytes=memory['peakWorkingSetBytes'],captureWindowSamples=len(rows),captureWindowWorkingSetMinimumBytes=min(x['workingSetBytes'] for x in rows),captureWindowWorkingSetMaximumBytes=max(x['workingSetBytes'] for x in rows),formalMemoryBudgetEvaluation='pending')
summary=dict(status='seal-lifecycle-and-strict-four-frames-passed',sourceBase='63ac7ea',red=json.loads((out/'red-result.json').read_text()),build=checks,sharing=sharing,capture=capture,memoryObservation=observations,protectedFilesUnchanged=13,bothConfigurationsVerified=True,wholeFrameTimingRuns=0,formalRuns=0,overallStatus='failed-user-review')
evidence=root/'docs/acceptance/nr/evidence/2026-11-10/material-cache-seal';evidence.mkdir(parents=True,exist_ok=True)
files=[p for p in out.rglob('*') if p.is_file() and p.suffix not in ['.png','.exe'] and not any(part in ['frames','tmp'] for part in p.relative_to(out).parts) and p.name not in ['budget.json','process.log']]
# Preserve the actual capture manifest alongside source/product receipts.
shutil.copyfile(out/'frames/capture_manifest.json',out/'capture-manifest.json');files.append(out/'capture-manifest.json')
archive=evidence/'validation.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,p.relative_to(out).as_posix())
assert archive.stat().st_size<8*1024**2
summary['archive']=dict(name=archive.name,bytes=archive.stat().st_size,sha256=digest(archive));summary['members']=[dict(name=p.relative_to(out).as_posix(),bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(files)]
(evidence/'results.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(archive) as z:
 for m in summary['members']:assert hashlib.sha256(z.read(m['name'])).hexdigest()==m['sha256']
p=(out/'frames').resolve();assert p.parent==out.resolve() and out.resolve().parent==(root/'build/runs').resolve();shutil.rmtree(p)
print(json.dumps(summary['archive']));print(json.dumps(observations));print('members',len(files),'protected',len(paths))
