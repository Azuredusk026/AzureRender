from pathlib import Path
import json,os,shutil,subprocess,sys,xml.etree.ElementTree as ET
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest,verify
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads',PYTHONDONTWRITEBYTECODE='1')
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8','-B',str(__file__),'--inside']).returncode)
targets=['AzureSampledTextureCacheTests','AzureRenderNullRhiPassTests','AzureOutlineProjectionTests','AzureMotionRecordingTests','AzureDepthPrefillRecordingTests','AzureMaterialClassEarlyDepthTests','AzureRenderNullRhiTests','AzureMaterialTextureSharingTests']
checks=[]
for config in ['Release','Debug']:
 previous=json.loads((out/(config.lower()+'-build-provenance.json')).read_text());now=inputs(root)
 delta=[p for p in now.keys()|previous['source'].keys() if now.get(p)!=previous['source'].get(p)]
 assert delta==[],delta  # Runtime inputs exclude test-only sources; prior product hashes are checked below.
 build=root/('build/ninja-msvc-'+config.lower());command=[sys.executable,'-X','utf8','-B','tools/build_provenance.py','build','--build-dir',str(build),'--config',config]
 for target in targets:command+=['--test-target',target]
 with (out/(config.lower()+'-sharing-build.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=470)
 shutil.copyfile(build/'build-provenance.json',out/(config.lower()+'-final-build-provenance.json'))
 assert all(digest(Path(p))==h for p,h in previous['products'].items()),'Previously tested runtime or test products changed'
 command=['ctest','--test-dir',str(build),'-C',config,'--output-on-failure','--no-tests=error','-R',r'^AzureRender.MaterialTextureSharing$','--output-junit',str(out/(config.lower()+'-sharing.xml'))]
 with (out/(config.lower()+'-sharing.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
 cases=ET.parse(out/(config.lower()+'-sharing.xml')).findall('.//testcase');assert len(cases)==1 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
 verify(root,json.loads((build/'build-provenance.json').read_text()))
 checks.append(dict(config=config,additionalTests=1,previousRuntimeAndTestProductsIdentical=True,reusedChecks=9,skips=0));print(json.dumps(checks[-1]),flush=True)
(out/'sharing-results.json').write_text(json.dumps(dict(checks=checks,totalEffectiveChecks=20,runtimeSourceUnchanged=True,testSourceDelta=['tests/MaterialTextureSharingTests.cpp']),indent=2))
