void sealed_bindings() {
    rhi::NullRhi backend;backend.collectImageUploads=true;
    SampledTextureCache cache(backend.allocator(),backend);
    const auto pixels=checker();const auto binding=cache.acquire(pixels,request());
    const auto before=cache.statistics();const auto live=backend.allocator().statistics();
    const auto calls=backend.calls.size();
    require(!cache.sealed(),"New caches accept complete identity comparisons");
    cache.seal();cache.seal();
    require(cache.sealed(),"Sealing is an explicit persistent state");
    const auto sealed=cache.statistics();
    require(sealed.retainedPixelBytes==0&&sealed.releasedIdentityBytes==pixels.size(),
        "Repeated sealing releases one identity allocation and preserves cumulative release bytes");
    require(sealed.requests==before.requests&&sealed.hits==before.hits
        &&sealed.uniqueTextures==before.uniqueTextures&&sealed.residentBytes==before.residentBytes,
        "Sealing preserves residency and acquisition statistics");
    require(backend.calls.size()==calls&&backend.allocator().statistics().liveImages==live.liveImages
        &&backend.allocator().statistics().liveImageBytes==live.liveImageBytes,
        "Sealing retains the exact GPU objects without backend operations");
    auto owned=pixels;const auto capacity=owned.capacity();
    reject([&]{cache.acquire(pixels,request());});
    reject([&]{cache.acquire(std::move(owned),request());});
    require(owned==pixels&&owned.capacity()==capacity,"Rejected sealed requests preserve input ownership");
    require(backend.calls.size()==calls&&cache.statistics().requests==before.requests
        &&cache.statistics().hashedPixelBytes==before.hashedPixelBytes,
        "Sealed requests reject before hashing, allocation or statistics mutation");
    cache.clear();
    require(!cache.sealed()&&cache.statistics().releasedIdentityBytes==0
        &&backend.allocator().statistics().liveImages==0,
        "Clear releases resident resources and starts a writable lifecycle");
    const auto next=cache.acquire(pixels,request());
    require(next.view!=binding.view&&next.sampler!=binding.sampler
        &&cache.statistics().retainedPixelBytes==pixels.size(),
        "A fresh lifecycle owns new bindings and full comparison bytes");
}

void sealed_empty_cache() {
    rhi::NullRhi backend;
    SampledTextureCache cache(backend.allocator(),backend);
    cache.seal();cache.seal();
    require(cache.sealed()&&cache.statistics().releasedIdentityBytes==0
        &&cache.statistics().retainedPixelBytes==0,"An empty cache can finish its write phase");
    reject([&]{cache.acquire(checker(),request());});
    require(backend.calls.empty(),"An empty sealed cache rejects without GPU operations");
    cache.clear();cache.clear();
    require(!cache.sealed(),"Repeated clear keeps the cache writable");
    cache.acquire(checker(),request());cache.seal();
    require(cache.statistics().releasedIdentityBytes==16,"Sealing after reuse accounts for actual identity bytes");
}
