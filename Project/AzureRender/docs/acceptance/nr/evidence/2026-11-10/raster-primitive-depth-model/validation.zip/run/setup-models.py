from pathlib import Path
import json,numpy as np
out=Path(__file__).parent;c=json.loads((out/'native-config.json').read_text());query=np.fromfile(c['queries'],dtype='<f4').reshape(-1,4);points=query[:,:2].astype('f8')+.5;clip=np.fromfile(out.parent/'20261110-195442-actual-vertex-clip-readback-c52555/nvidia-clips.bin',dtype='<f4').reshape(-1,3,4);w=clip[:,:,3];half=np.array([1280,720],dtype='f4')
words=np.fromfile(out.parent/'20261110-003031-reciprocal-compact-profile-4e7929/correction.bin',dtype='<u4');bits=w.view('u4');mantissa=bits&0x7fffff;normalized=(mantissa|0x3f800000).view('f4');near=(np.float32(1)/normalized).astype('f4');codes=(words[mantissa>>4]>>((mantissa&15)*2))&3;assert (codes<3).all();native=((near.view('u4').astype('i8')+codes.astype('i8')-1).astype('u4')).view('f4');native=np.ldexp(native,127-((bits>>23)&255).astype('i4')).astype('f4');rcp=(np.float32(1)/w).astype('f4')
screens={}
for name,r in [('nearest',rcp),('native',native)]:
 ndc=(clip[:,:,:2]*r[:,:,None]).astype('f4');screens[name+'-f32-fma']=np.rint((ndc.astype('f8')*half+half).astype('f4').astype('f8')*256)/256;screens[name+'-f32-muladd']=np.rint(((ndc*half).astype('f4')+half).astype('f4').astype('f8')*256)/256;screens[name+'-wide']=np.rint((clip[:,:,:2].astype('f8')*r[:,:,None].astype('f8')*half+half)*256)/256
ndc=(clip[:,:,:2]/w[:,:,None]).astype('f4');screens['divide-f32-muladd']=np.rint(((ndc*half).astype('f4')+half).astype('f4').astype('f8')*256)/256;screens['divide-wide']=np.rint((clip[:,:,:2].astype('f8')/w[:,:,None]*half+half)*256)/256
zs={'double-divide':clip[:,:,2].astype('f8')/w,'float-divide':(clip[:,:,2]/w).astype('f4').astype('f8'),'native-wide-product':clip[:,:,2].astype('f8')*native.astype('f8'),'native-f32-product':(clip[:,:,2]*native).astype('f4').astype('f8')};rows=[]
f32=lambda x:np.asarray(x,dtype='f4');fma=lambda a,b,c:f32(np.asarray(a,dtype='f8')*np.asarray(b,dtype='f8')+np.asarray(c,dtype='f8'))
def metrics(device,sn,zn,anchor,evaluation,depth,actual,valid):
 ulp=abs(depth.view('u4').astype('i8')-actual.view('u4').astype('i8'));return {'device':device,'screen':sn,'z':zn,'anchor':anchor,'evaluation':evaluation,'valid':int(valid.sum()),'exact':int(((ulp==0)&valid).sum()),'withinOneUlp':int(((ulp<=1)&valid).sum()),'maxUlp':int(ulp[valid].max())}
for device in ['nvidia','intel']:
 ids=np.fromfile(out/f'{device}-primitive-selected.bin',dtype='<f4').astype('i4');actual=np.fromfile(out/f'{device}-depth-selected.bin',dtype='<f4')
 for sn,screen in screens.items():
  t=screen[ids];dx=t[:,1]-t[:,0];dy=t[:,2]-t[:,0];den=dx[:,0]*dy[:,1]-dy[:,0]*dx[:,1];valid=abs(den)>1e-20;den=np.where(valid,den,1)
  for zn,z in zs.items():
   z=z[ids];dzx=z[:,1]-z[:,0];dzy=z[:,2]-z[:,0];a=(dzx*dy[:,1]-dzy*dx[:,1])/den;b=(dzy*dx[:,0]-dzx*dy[:,0])/den;p=points-t[:,0];ideal=f32(z[:,0]+a*p[:,0]+b*p[:,1]);rows.append(metrics(device,sn,zn,'none','wide-plane',ideal,actual,valid))
   for anchor in ['global','vertex','floor-vertex','tile8','tile8-center','tile16-center']:
    if anchor=='global':origin=np.zeros_like(points)
    elif anchor=='vertex':origin=t[:,0]
    elif anchor=='floor-vertex':origin=np.floor(t[:,0])
    else:
     tile=8 if anchor.startswith('tile8') else 16;origin=np.floor(points/tile)*tile+(.5 if anchor.endswith('center') else 0)
    at=f32(z[:,0]+a*(origin[:,0]-t[:,0,0])+b*(origin[:,1]-t[:,0,1]));af=f32(a);bf=f32(b);delta=f32(points-origin)
    for order in ['x-first','y-first','separate']:
     if order=='x-first':depth=fma(bf,delta[:,1],fma(af,delta[:,0],at))
     elif order=='y-first':depth=fma(af,delta[:,0],fma(bf,delta[:,1],at))
     else:depth=f32(f32(at+f32(af*delta[:,0]))+f32(bf*delta[:,1]))
     rows.append(metrics(device,sn,zn,anchor,order,depth,actual,valid))
(out/'setup-model-results.json').write_text(json.dumps(rows,indent=2)+'\n')
for device in ['nvidia','intel']:print(device,json.dumps(sorted([r for r in rows if r['device']==device],key=lambda r:(-r['exact'],-r['withinOneUlp']))[:4],indent=2))
