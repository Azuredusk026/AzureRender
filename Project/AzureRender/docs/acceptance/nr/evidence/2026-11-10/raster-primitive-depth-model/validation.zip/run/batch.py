from pathlib import Path
import sys,json,subprocess,os,re,numpy as np
out=Path(__file__).resolve().parent;build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release';prior=out.parent/'20261110-173835-reference-depth-coverage-4b4afc';wrapper=subprocess.list2cmdline(['D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'])
with (out/'build.log').open('wb') as log:
 for command in json.loads((out/'build-commands.json').read_text()):
  r=subprocess.run(wrapper+' '+command,cwd=build,shell=True,stdout=log,stderr=subprocess.STDOUT);assert r.returncode==0,r.returncode
config=json.loads((out/'native-config.json').read_text());q=np.fromfile(config['queries'],dtype='<f4').reshape(-1,4);x=q[:,0].astype(int);y=q[:,1].astype(int);rows=[]
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(build)+';'+env['PATH'])
 baseline=np.fromfile(prior/f'native-{device}-r32.bin',dtype='<f4').reshape(1440,2560)[y,x]
 for channel,name in [(0,'depth'),(1,'primitive')]:
  c={**config,'channel':channel};path=out/(device+'-config.json');path.write_text(json.dumps(c,indent=2)+'\n');prefix=out/(device+'-'+name)
  with (out/(device+'-'+name+'.log')).open('wb') as log:r=subprocess.run([str(out/'native-coverage.exe'),str(out/'shaders'),str(path),str(prefix)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
  text=(out/(device+'-'+name+'.log')).read_text(errors='replace');assert r.returncode==0 and not re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I),text[-3000:]
  d32=np.fromfile(str(prefix)+'-selected-d32.bin',dtype='<f4');assert np.array_equal(d32.view('u4'),baseline.view('u4')),(device,name,'D32 identity failed')
  data=np.fromfile(str(prefix)+'-r32.bin',dtype='<f4').reshape(1440,2560)[y,x];data.tofile(out/f'{device}-{name}-selected.bin')
  if channel==0:assert np.array_equal(data.view('u4'),baseline.view('u4')),(device,'R32 identity failed')
  else:assert ((data==np.floor(data))&(data>=0)&(data<14348)).all()
  rows.append({'device':device,'mode':name,'depthControlExact':True});(out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(device,name,'qualified',flush=True)
