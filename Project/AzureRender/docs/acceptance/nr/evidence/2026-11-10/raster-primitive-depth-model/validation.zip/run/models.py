from pathlib import Path
import json,numpy as np
out=Path(__file__).parent;config=json.loads((out/'native-config.json').read_text());q=np.fromfile(config['queries'],dtype='<f4').reshape(-1,4);points=q[:,:2].astype('f8')+.5
clip=np.fromfile(out.parent/'20261110-195442-actual-vertex-clip-readback-c52555/nvidia-clips.bin',dtype='<f4').reshape(-1,3,4);w=clip[:,:,3];ndc64=clip[:,:,:2].astype('f8')/w[:,:,None];ndc32=(clip[:,:,:2]/w[:,:,None]).astype('f4');rcp=(np.float32(1)/w).astype('f4');ndcRcp=(clip[:,:,:2]*rcp[:,:,None]).astype('f4');half=np.array([1280,720],dtype='f4')
screens={'double':ndc64*half+half,'divide-f32-fma':(ndc32.astype('f8')*half+half).astype('f4').astype('f8'),'divide-f32-mul-add':((ndc32*half).astype('f4')+half).astype('f4').astype('f8'),'rcp-f32-fma':(ndcRcp.astype('f8')*half+half).astype('f4').astype('f8'),'rcp-f32-mul-add':((ndcRcp*half).astype('f4')+half).astype('f4').astype('f8')}
zValues={'double-divide':clip[:,:,2].astype('f8')/w,'f32-divide':(clip[:,:,2]/w).astype('f4').astype('f8'),'f32-rcp-multiply':(clip[:,:,2]*rcp).astype('f4').astype('f8')};rows=[]
for device in ['nvidia','intel']:
 ids=np.fromfile(out/f'{device}-primitive-selected.bin',dtype='<f4').astype('i4');actual=np.fromfile(out/f'{device}-depth-selected.bin',dtype='<f4')
 for screenName,screen in screens.items():
  for bits in [None,4,8,16]:
   vertices=screen if bits is None else np.rint(screen*(1<<bits))/(1<<bits);t=vertices[ids];d0=t[:,1]-t[:,0];d1=t[:,2]-t[:,0];p=points-t[:,0];den=d0[:,0]*d1[:,1]-d1[:,0]*d0[:,1];valid=abs(den)>1e-20
   u=np.divide(p[:,0]*d1[:,1]-d1[:,0]*p[:,1],den,out=np.zeros(len(p)),where=valid);v=np.divide(d0[:,0]*p[:,1]-p[:,0]*d0[:,1],den,out=np.zeros(len(p)),where=valid)
   for zName,z in zValues.items():
    zs=z[ids];depth=(zs[:,0]+u*(zs[:,1]-zs[:,0])+v*(zs[:,2]-zs[:,0])).astype('f4');ulp=np.abs(depth.view('u4').astype('i8')-actual.view('u4').astype('i8'));rows.append({'device':device,'screen':screenName,'snapBits':bits,'depth':zName,'valid':int(valid.sum()),'exact':int(((ulp==0)&valid).sum()),'withinOneUlp':int(((ulp<=1)&valid).sum()),'medianUlp':float(np.median(ulp[valid])),'maxUlp':int(ulp[valid].max())})
(out/'double-plane-models.json').write_text(json.dumps(rows,indent=2)+'\n')
for device in ['nvidia','intel']:
 selected=sorted([r for r in rows if r['device']==device],key=lambda r:(-r['exact'],-r['withinOneUlp']))[:5];print(device,json.dumps(selected,indent=2))
