from pathlib import Path
import hashlib,json,zipfile,re
engine=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender');out=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda n:json.loads((out/n).read_text(encoding='utf-8'));runs=read('runs.json');assert len(runs)==4 and all(x['depthControlExact'] for x in runs);result=read('primitive-results.json');assert result['all97FailurePrimitiveDifferences']==1
files={'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.json','.py','.log','.bin','.cpp','.hpp','.frag'}};files.update({'run/shaders/'+p.name:p for p in (out/'shaders').iterdir() if p.is_file()})
doc=engine/'docs/acceptance/nr/raster-primitive-depth-model.md';files['source/docs/acceptance/nr/raster-primitive-depth-model.md']=doc
files['inputs/common-actual-clips.bin']=out.parent/'20261110-195442-actual-vertex-clip-readback-c52555/nvidia-clips.bin';files['inputs/reciprocal-correction.bin']=out.parent/'20261110-003031-reciprocal-compact-profile-4e7929/correction.bin';config=read('native-config.json');files['inputs/queries.bin']=Path(config['queries'])
dest=engine/'docs/acceptance/nr/evidence/2026-11-10/raster-primitive-depth-model';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.writestr('manifest.json',json.dumps(members,ensure_ascii=False,indent=2))
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,value in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==value['sha256']
result.update(status='qualified-primitive-identity-numeric-models-diagnostic-only',overall='failed-user-review',sourceCommit='4fdcc7b',deviceCaps={d:read(d+'-depth-caps.json') for d in ['nvidia','intel']},defaultRegression=read('default-regression-reuse.json'),archive={'members':len(members)+1,'bytes':archive.stat().st_size,'sha256':sha(archive)})
(dest/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for link in re.findall(r'\]\(([^)]+)\)',doc.read_text(encoding='utf-8')):assert (doc.parent/link).exists(),link
print(json.dumps(result['archive']))
