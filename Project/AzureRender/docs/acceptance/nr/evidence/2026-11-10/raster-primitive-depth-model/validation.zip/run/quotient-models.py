from pathlib import Path
import json,numpy as np
out=Path(__file__).parent;c=json.loads((out/'native-config.json').read_text());q=np.fromfile(c['queries'],dtype='<f4').reshape(-1,4);points=q[:,:2].astype('f8')+.5;clip=np.fromfile(out.parent/'20261110-195442-actual-vertex-clip-readback-c52555/nvidia-clips.bin',dtype='<f4').reshape(-1,3,4);w=clip[:,:,3];half=np.array([1280,720],dtype='f4');ndc=(clip[:,:,:2]/w[:,:,None]).astype('f4');screen=np.rint(((ndc*half).astype('f4')+half).astype('f4').astype('f8')*256)/256;rows=[]
for device in ['nvidia','intel']:
 ids=np.fromfile(out/f'{device}-primitive-selected.bin',dtype='<f4').astype('i4');actual=np.fromfile(out/f'{device}-depth-selected.bin',dtype='<f4');t=screen[ids];d0=t[:,1]-t[:,0];d1=t[:,2]-t[:,0];p=points-t[:,0];den=d0[:,0]*d1[:,1]-d1[:,0]*d0[:,1];u=(p[:,0]*d1[:,1]-d1[:,0]*p[:,1])/den;v=(d0[:,0]*p[:,1]-p[:,0]*d0[:,1])/den;weights=np.column_stack([1-u-v,u,v]);cw=w[ids].astype('f8');cz=clip[ids,:,2].astype('f8')
 for rw in ['wide','float']:
  inverse=1/cw if rw=='wide' else (np.float32(1)/cw.astype('f4')).astype('f4').astype('f8');sumInverse=(weights*inverse).sum(1);n=(weights*cz*inverse).sum(1);clipPerspective=n/sumInverse;clipLinear=(weights*cz).sum(1)
  for name,values in [('perspective-then-product',clipPerspective.astype('f4')*sumInverse.astype('f4')),('linear-then-product',clipLinear.astype('f4')*sumInverse.astype('f4')),('perspective-wide-product',(clipPerspective.astype('f4').astype('f8')*sumInverse).astype('f4')),('linear-wide-product',(clipLinear.astype('f4').astype('f8')*sumInverse).astype('f4'))]:
   values=values.astype('f4');ulp=abs(values.view('u4').astype('i8')-actual.view('u4').astype('i8'));rows.append({'device':device,'reciprocal':rw,'evaluation':name,'exact':int((ulp==0).sum()),'withinOneUlp':int((ulp<=1).sum()),'maxUlp':int(ulp.max())})
(out/'quotient-model-results.json').write_text(json.dumps(rows,indent=2)+'\n')
for device in ['nvidia','intel']:print(device,json.dumps(sorted([r for r in rows if r['device']==device],key=lambda r:-r['exact'])[:3],indent=2))
