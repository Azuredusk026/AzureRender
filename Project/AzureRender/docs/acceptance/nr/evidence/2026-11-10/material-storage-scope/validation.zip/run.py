from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest,verify
os.environ.update(managed_environment(out/'tmp'));os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',DOTNET_ROOT='D:/Tools/dotnet9',AZURE_IMAGE_STORAGE_AUDIT='1',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(key,None)
verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
programs=json.loads((out/'baseline-programs.json').read_text());assert all(digest(Path(p))==h for p,h in programs.items())
lock=json.loads((root/'build/runs/20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text());assert all(digest(Path(p))==h for p,h in lock.items())
project=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
command=[str(build/'AzurePlayer.exe'),'--project',str(project),'--resource-root',str(build),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','24','--smoke-frames','2','--runtime-report',str(out/'runtime.json')]
(out/'command.json').write_text(json.dumps(command,indent=2));start=time.monotonic()
with (out/'native.log').open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=460)
log=(out/'native.log').read_text(errors='replace');rows=[];batches=[]
fields=['group','bucket','width','height','format','mipLevels','semantic','alphaCutoff','residentBytes','retainedBytes','minFilter','magFilter','addressU','addressV','addressW','maximumLod','mipmapLinear','maximumAnisotropy','mipBias']
for line in log.splitlines():
    if line.startswith('AZURE_IMAGE_STORAGE '):
        values=line.split()[1:];assert len(values)==len(fields);rows.append({k:float(v) if k in ['alphaCutoff','maximumLod','maximumAnisotropy','mipBias'] else int(v) for k,v in zip(fields,values)})
    elif line.startswith('AZURE_IMAGE_STORAGE_SUMMARY '):
        values=list(map(int,line.split()[1:]));assert len(values)==6
        batch=dict(zip(['uniqueTextures','equivalentImages','residentBytes','samplerVariantDuplicateBytes','samplerVariantDuplicateRetainedBytes','counterResidentBytes'],values));batch['rows']=rows;rows=[];batches.append(batch)
assert p.returncode==0 and 'AZURE_IMAGE_STORAGE_FAILED' not in log
batch=max(batches,key=lambda b:b['uniqueTextures']);assert len(batch['rows'])==batch['uniqueTextures'] and batch['uniqueTextures']==385
assert sum(r['residentBytes'] for r in batch['rows'])==batch['residentBytes']==batch['counterResidentBytes']
report=dict(exitCode=p.returncode,seconds=time.monotonic()-start,materialImageStorage=batch,validationClean=not any(x in log for x in ['Validation Error:','Validation Warning:','SYNC-HAZARD','VUID-']),allocatorZero='Allocator after unload: buffers=0 images=0' in log,sourceUnchanged=inputs(root)==before,programsUnchanged=all(digest(Path(p))==h for p,h in programs.items()),projectInputsUnchanged=all(digest(Path(p))==h for p,h in lock.items()),nativeImageCaptures=0,wholeFrameTimingRuns=0)
(out/'results.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='materialImageStorage'}));print(json.dumps({k:v for k,v in batch.items() if k!='rows'}))
assert all(report[k] for k in ['validationClean','allocatorZero','sourceUnchanged','programsUnchanged','projectInputsUnchanged'])
