from pathlib import Path
import hashlib,json
root=Path.cwd();out=Path(__file__).resolve().parent;p=root/'src/render/SampledTextureCache.cpp'
assert not (out/'SampledTextureCache.cpp.baseline').exists()
raw=p.read_bytes();(out/'SampledTextureCache.cpp.baseline').write_bytes(raw)
text=raw.decode();text=text.replace('#include <cmath>','#include <cmath>\n#include <cstdlib>\n#include <iostream>')
needle='void SampledTextureCache::clear() noexcept { entries_.clear(); statistics_ = {}; }'
replacement=r'''void SampledTextureCache::clear() noexcept {
    if(const auto* audit=std::getenv("AZURE_IMAGE_STORAGE_AUDIT");audit&&audit[0]=='1')try {
        std::vector<const Entry*> representatives;
        std::uint64_t resident=0,duplicate=0,retainedDuplicate=0;
        const auto sameImage=[](const SampledTextureUpload& a,const SampledTextureUpload& b){
            return a.width==b.width&&a.height==b.height&&a.format==b.format
                &&a.mipLevels==b.mipLevels&&a.semantic==b.semantic&&a.alphaCutoff==b.alphaCutoff
                &&(a.mipLevels!=0||(a.sampler.filter==VK_FILTER_LINEAR)==(b.sampler.filter==VK_FILTER_LINEAR));
        };
        for(const auto& item:entries_){const auto& e=*item.second;const auto& u=e.upload;
            unsigned levels=u.mipLevels;if(!levels){levels=1;for(unsigned w=u.width,h=u.height;w>1||h>1;++levels){w=std::max(1U,w/2);h=std::max(1U,h/2);}}
            const auto bytes=byteCount(u.width,u.height,levels);resident+=bytes;
            std::size_t group=0;
            for(;group<representatives.size();++group){const auto& prior=*representatives[group];if(sameImage(prior.upload,u)&&prior.pixels==e.pixels)break;}
            if(group==representatives.size())representatives.push_back(&e);else{duplicate+=bytes;retainedDuplicate+=e.pixels.size();}
            std::cout<<"AZURE_IMAGE_STORAGE "<<group<<' '<<item.first<<' '<<u.width<<' '<<u.height<<' '<<unsigned(u.format)<<' '<<levels<<' '<<unsigned(u.semantic)<<' '<<u.alphaCutoff<<' '<<bytes<<' '<<e.pixels.size()
                <<' '<<unsigned(u.sampler.filter)<<' '<<unsigned(u.sampler.effectiveMagFilter())<<' '<<unsigned(u.sampler.addressU)<<' '<<unsigned(u.sampler.addressV)<<' '<<unsigned(u.sampler.addressW)
                <<' '<<u.sampler.maxLod<<' '<<u.sampler.mipmapLinear<<' '<<u.sampler.maxAnisotropy<<' '<<u.sampler.mipLodBias<<'\n';
        }
        std::cout<<"AZURE_IMAGE_STORAGE_SUMMARY "<<entries_.size()<<' '<<representatives.size()<<' '<<resident<<' '<<duplicate<<' '<<retainedDuplicate<<' '<<statistics_.residentBytes<<'\n';
    }catch(...){std::cout<<"AZURE_IMAGE_STORAGE_FAILED\n";}
    entries_.clear();statistics_={};
}'''
assert needle in text;text=text.replace(needle,replacement)
p.write_bytes(text.encode());(out/'SampledTextureCache.cpp.diagnostic').write_bytes(p.read_bytes())
(out/'source-change.json').write_text(json.dumps(dict(path=str(p),baselineSha256=hashlib.sha256(raw).hexdigest(),diagnosticSha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2))
