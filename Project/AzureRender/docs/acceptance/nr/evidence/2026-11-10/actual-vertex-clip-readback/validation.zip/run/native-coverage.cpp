#define main syntheticDepthCoverageMain
#include "native-synthetic.cpp"
#undef main
#include "resources/BinaryFile.hpp"
#include <nlohmann/json.hpp>
#include <fstream>

namespace azurerender::diagnostic {
VkCommandBuffer feedbackCommands{};VkBuffer feedbackBuffer{};VkDeviceSize feedbackBytes{};
PFN_vkCmdBindTransformFeedbackBuffersEXT bindFeedback{};PFN_vkCmdBeginTransformFeedbackEXT beginFeedback{};PFN_vkCmdEndTransformFeedbackEXT endFeedback{};
void feedbackBegin(){const VkDeviceSize offset=0;bindFeedback(feedbackCommands,0,1,&feedbackBuffer,&offset,&feedbackBytes);beginFeedback(feedbackCommands,0,0,nullptr,nullptr);}
void feedbackEnd(){endFeedback(feedbackCommands,0,0,nullptr,nullptr);}
void prepareFeedback(VkDevice device){bindFeedback=reinterpret_cast<PFN_vkCmdBindTransformFeedbackBuffersEXT>(vkGetDeviceProcAddr(device,"vkCmdBindTransformFeedbackBuffersEXT"));beginFeedback=reinterpret_cast<PFN_vkCmdBeginTransformFeedbackEXT>(vkGetDeviceProcAddr(device,"vkCmdBeginTransformFeedbackEXT"));endFeedback=reinterpret_cast<PFN_vkCmdEndTransformFeedbackEXT>(vkGetDeviceProcAddr(device,"vkCmdEndTransformFeedbackEXT"));if(!bindFeedback||!beginFeedback||!endFeedback)throw std::runtime_error("Transform feedback entry points unavailable");}
}

int main(int argc,char** argv)try{
    if(argc!=4)throw std::invalid_argument("Expected shader directory, native surface config and output prefix");
    const auto c=nlohmann::json::parse(std::ifstream(argv[2]));test::VulkanComputeFixture host(true);auto& backend=*host.backend;prepareFeedback(host.device);
    {
        DepthInputs inputs(host);const auto positions=readBinaryFile(c["positions"].get<std::string>()),uv=readBinaryFile(c["uv"].get<std::string>()),indices=readBinaryFile(c["indices"].get<std::string>()),profileBytes=readBinaryFile(c["profile"].get<std::string>());
        if(positions.size()%16||uv.size()!=positions.size()/2||indices.size()%12||profileBytes.size()!=80)throw std::invalid_argument("Native depth surface sizes differ");
        ReferenceClipProjectionProfile profile;std::memcpy(&profile.parameters,profileBytes.data(),80);
        std::vector<std::vector<char>> mips;for(const auto& name:c["mips"])mips.push_back(readBinaryFile(name.get<std::string>()));
        rhi::SamplerDesc sampled;sampled.filter=VK_FILTER_LINEAR;sampled.mipmapLinear=false;sampled.maxLod=1000;sampled.mipLodBias=0;
        const auto texture=inputs.texture(c["width"],c["height"],VK_FORMAT_BC7_UNORM_BLOCK,mips,sampled);
        const auto p=inputs.buffer(positions.data(),positions.size(),VK_BUFFER_USAGE_VERTEX_BUFFER_BIT),u=inputs.buffer(uv.data(),uv.size(),VK_BUFFER_USAGE_VERTEX_BUFFER_BIT),i=inputs.buffer(indices.data(),indices.size(),VK_BUFFER_USAGE_INDEX_BUFFER_BIT);
        ReferenceDepthGeometry geometry{p.buffer,i.buffer,static_cast<unsigned>(positions.size()/16),static_cast<unsigned>(indices.size()/4)};
        geometry.surface.cullMode=VK_CULL_MODE_BACK_BIT;geometry.surface.frontFace=VK_FRONT_FACE_COUNTER_CLOCKWISE;
        geometry.surface.alpha=ReferenceDepthAlpha{u.buffer,texture.first,texture.second};geometry.surface.alpha->channel=0;geometry.surface.alpha->cutoff=c["cutoff"];geometry.surface.alpha->lodBias=c["lodBias"];
        feedbackBytes=VkDeviceSize(geometry.indexCount)*16;const auto feedback=inputs.buffer(nullptr,static_cast<std::size_t>(feedbackBytes),VK_BUFFER_USAGE_TRANSFORM_FEEDBACK_BUFFER_BIT_EXT);feedbackBuffer=feedback.buffer;ReferenceDepthGpu producer(backend,{2560,1440},1,{},ReferenceDepthShaders::loadMasked(argv[1]));const auto values=inputs.render(producer,0,profile,{geometry});host.allocator.invalidate(feedback,0,feedbackBytes);{std::ofstream clips(std::string(argv[3])+"-clips.bin",std::ios::binary);clips.write(static_cast<const char*>(feedback.mapped),static_cast<std::streamsize>(feedbackBytes));if(!clips)throw std::runtime_error("Clip feedback export failed");}
        std::ofstream image(std::string(argv[3])+"-r32.bin",std::ios::binary);image.write(reinterpret_cast<const char*>(values.data()),2560*1440*4);if(!image)throw std::runtime_error("Native R32 export failed");
        const auto queries=readBinaryFile(c["queries"].get<std::string>());if(queries.size()%16)throw std::invalid_argument("Native queries malformed");const auto q=reinterpret_cast<const float*>(queries.data());std::vector<float> selected;
        for(unsigned k=0;k<queries.size()/16;++k){const unsigned x=static_cast<unsigned>(q[k*4]),y=static_cast<unsigned>(q[k*4+1]);if(x>=2560||y>=1440)throw std::invalid_argument("Native query outside output");selected.push_back(values[2560*1440+y*2560+x]);}
        std::ofstream depth(std::string(argv[3])+"-selected-d32.bin",std::ios::binary);depth.write(reinterpret_cast<const char*>(selected.data()),static_cast<std::streamsize>(selected.size()*4));if(!depth)throw std::runtime_error("Native D32 export failed");
    }
    if(host.errors.load()||host.allocator.statistics().liveBuffers||host.allocator.statistics().liveImages)throw std::runtime_error("Native masked depth validation or cleanup failed");
    std::cout<<host.properties.deviceName<<": native BC7 alpha, front-face winding and masked depth production, validation and cleanup passed\n";return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
