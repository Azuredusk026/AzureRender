from pathlib import Path
import hashlib,json,zipfile,re
engine=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender');out=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result=json.loads((out/'results.json').read_text());assert result['status']=='qualified-vertex-output' and all(r['depthIdentityQualified'] and r['differentUniqueVertices']==0 and r['bitExactComponents']==172176 for r in result['devices'])
files={'run/'+p.name:p for p in out.iterdir() if p.is_file() and p.suffix in {'.json','.py','.log','.bin','.cpp','.hpp','.vert'}};files.update({'run/shaders/'+p.name:p for p in (out/'shaders').iterdir() if p.is_file()})
config=json.loads((out/'native-config.json').read_text())
for key in ['positions','indices','profile','uv','queries']:files['inputs/'+Path(config[key]).name]=Path(config[key])
files['inputs/source-422-vertices.bin']=out.parent/'20261110-165124-reference-depth-source-4d1d7d/source-422-vertices.bin'
doc=engine/'docs/acceptance/nr/actual-vertex-clip-readback.md';files['source/docs/acceptance/nr/actual-vertex-clip-readback.md']=doc
for name in ['src/render/ReferenceDepth.hpp','src/render/ReferenceDepth.cpp','src/render/ReferenceFmaShader.hpp','src/render/ReferenceClipProjection.hpp','shaders/reference_clip_projection.glsl','shaders/reference_depth.vert','shaders/reference_depth.frag']:files['source/'+name]=engine/name
dest=engine/'docs/acceptance/nr/evidence/2026-11-10/actual-vertex-clip-readback';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip';members={name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.writestr('manifest.json',json.dumps(members,ensure_ascii=False,indent=2))
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,value in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==value['sha256']
result.update(overall='failed-user-review',sourceCommit='701b735',defaultRegression=json.loads((out/'default-regression-reuse.json').read_text()),archive={'members':len(members)+1,'bytes':archive.stat().st_size,'sha256':sha(archive)})
(dest/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for link in re.findall(r'\]\(([^)]+)\)',doc.read_text(encoding='utf-8')):assert (doc.parent/link).exists(),link
print(json.dumps(result['archive']))
