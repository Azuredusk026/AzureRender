from pathlib import Path
out=Path(__file__).resolve().parent;prior=out.parent/'20261110-173835-reference-depth-coverage-4b4afc'
source=(prior/'native-coverage.cpp').read_text(encoding='utf-8')
hook='''
namespace azurerender::diagnostic {
VkCommandBuffer feedbackCommands{};VkBuffer feedbackBuffer{};VkDeviceSize feedbackBytes{};
PFN_vkCmdBindTransformFeedbackBuffersEXT bindFeedback{};PFN_vkCmdBeginTransformFeedbackEXT beginFeedback{};PFN_vkCmdEndTransformFeedbackEXT endFeedback{};
void feedbackBegin(){const VkDeviceSize offset=0;bindFeedback(feedbackCommands,0,1,&feedbackBuffer,&offset,&feedbackBytes);beginFeedback(feedbackCommands,0,0,nullptr,nullptr);}
void feedbackEnd(){endFeedback(feedbackCommands,0,0,nullptr,nullptr);}
void prepareFeedback(VkDevice device){bindFeedback=reinterpret_cast<PFN_vkCmdBindTransformFeedbackBuffersEXT>(vkGetDeviceProcAddr(device,"vkCmdBindTransformFeedbackBuffersEXT"));beginFeedback=reinterpret_cast<PFN_vkCmdBeginTransformFeedbackEXT>(vkGetDeviceProcAddr(device,"vkCmdBeginTransformFeedbackEXT"));endFeedback=reinterpret_cast<PFN_vkCmdEndTransformFeedbackEXT>(vkGetDeviceProcAddr(device,"vkCmdEndTransformFeedbackEXT"));if(!bindFeedback||!beginFeedback||!endFeedback)throw std::runtime_error("Transform feedback entry points unavailable");}
}
'''
source=source.replace('#include <fstream>','#include <fstream>\n'+hook)
source=source.replace('auto& backend=*host.backend;','auto& backend=*host.backend;prepareFeedback(host.device);')
needle='ReferenceDepthGpu producer(backend,{2560,1440},1,{},ReferenceDepthShaders::loadMasked(argv[1]));';assert needle in source
source=source.replace(needle,'feedbackBytes=VkDeviceSize(geometry.indexCount)*16;const auto feedback=inputs.buffer(nullptr,static_cast<std::size_t>(feedbackBytes),VK_BUFFER_USAGE_TRANSFORM_FEEDBACK_BUFFER_BIT_EXT);feedbackBuffer=feedback.buffer;'+needle)
needle='const auto values=inputs.render(producer,0,profile,{geometry});';assert needle in source
source=source.replace(needle,needle+'host.allocator.invalidate(feedback,0,feedbackBytes);{std::ofstream clips(std::string(argv[3])+"-clips.bin",std::ios::binary);clips.write(static_cast<const char*>(feedback.mapped),static_cast<std::streamsize>(feedbackBytes));if(!clips)throw std::runtime_error("Clip feedback export failed");}')
(out/'native-coverage.cpp').write_text(source,encoding='utf-8')
print('Private actual vertex readback caller prepared')
