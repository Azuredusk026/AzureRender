from pathlib import Path
import sys,subprocess,json,os,re,time
out=Path(__file__).resolve().parent;root=out.parents[2];build=out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release';commands=json.loads((out/'build-commands.json').read_text());wrapper=subprocess.list2cmdline(['D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'])
with (out/'build.log').open('wb') as log:
 for command in commands:
  r=subprocess.run(wrapper+' '+command,cwd=build,shell=True,stdout=log,stderr=subprocess.STDOUT);assert r.returncode==0,r.returncode
rows=[]
for device in ['nvidia','intel']:
 env=os.environ.copy()
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
 env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',PATH=str(build)+';'+env['PATH'])
 prefix=out/device;command=[str(out/'native-coverage.exe'),str(out/'shaders'),str(out/'native-config.json'),str(prefix)];started=time.monotonic()
 with (out/(device+'.log')).open('wb') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=110)
 text=(out/(device+'.log')).read_text(errors='replace');rows.append({'device':device,'exitCode':r.returncode,'seconds':time.monotonic()-started,'validationClean':not bool(re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I)),'command':command});(out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(device,r.returncode,text[-2000:],flush=True)
 assert r.returncode==0 and rows[-1]['validationClean'],text[-3000:]
