from pathlib import Path
import sys,time,json
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as shared
out=Path(__file__).resolve().parent;configuration='FinalBatch'
name=out.name
started=time.monotonic()
while True:
 context=shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-triangle-edge-helpers-'+configuration.lower(),out)
 try:context.__enter__();break
 except ValueError as error:
  if not any(s in str(error) for s in ['busy','still running']):raise
  if time.monotonic()-started>=180:raise TimeoutError('Queue wait ended; no build executed')
  time.sleep(1)
try:
 result=shared.maintenance.guarded_run(out.parents[1],name,[sys.executable,str(out/'checks.py')],660)
 (out/(configuration.lower()+'-execution.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
finally:context.__exit__(None,None,None)
sys.exit(result.get('exitCode',2))
