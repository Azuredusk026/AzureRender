from pathlib import Path
import sys,json,subprocess
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
out=Path(__file__).resolve().parent
for configuration,name in [('Release','20261110-030251-hair-main-chroma-public-9e799c'),('Debug','20261110-031856-hair-main-chroma-debug-668bf2')]:
 r=s.maintenance.guarded_run(out.parents[1],name,[sys.executable,str(out/'build.py'),configuration],180)
 (out/(configuration.lower()+'-build-execution.json')).write_text(json.dumps(r,indent=2));assert r.get('exitCode')==0,r
raise SystemExit(subprocess.run([sys.executable,str(out/'gpu.py')],timeout=240).returncode)
