from pathlib import Path
import json,os,re,subprocess
out=Path(__file__).resolve().parent;root=out.parents[2];rows=[]
for configuration,folder in [('release','20261110-030251-hair-main-chroma-public-9e799c/release'),('debug','20261110-031856-hair-main-chroma-debug-668bf2/debug')]:
 build=root/'build/runs'/folder
 for device in ['nvidia','intel']:
  env=os.environ.copy()
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT']:env.pop(key,None)
  env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
  command=[str(build/'AzureMaterialUvGradientsGpuTests.exe'),str(build/'shaders/material_uv_gradients_test.vert.spv'),str(build/'shaders/material_uv_gradients_test.frag.spv')]
  name=configuration+'-'+device
  with (out/(name+'-gpu.log')).open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  text=(out/(name+'-gpu.log')).read_text(errors='replace');row=dict(configuration=configuration,device=device,exitCode=result.returncode,command=command,validationClean=not bool(re.search(r'VUID-|Validation (?:Error|Warning)|SYNC-HAZARD',text,re.I)));rows.append(row)
  (out/'gpu-results.json').write_text(json.dumps(rows,indent=2))
  print(name,result.returncode,text[-1000:],flush=True)
  assert result.returncode==0 and row['validationClean'],text[-2000:]
  assert '8716 pixels / 34864 exact components' in text
  assert ('NVIDIA' in text)==(device=='nvidia')
