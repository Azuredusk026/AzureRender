import renderdoc as rd
from pathlib import Path
import json,hashlib,traceback,sys,zlib
out=Path(r"D:\Projects\FYP-worktrees\nr-quality\Project\AzureRender\build\runs\20261110-141407-material-mirrored-uv-policy-1a9615");report={'status':'starting','cases':[]};cap=None;c=None
try:
 for label,folder in [('reference','capture2-shadow-indexed-reference'),('independent','capture3-shadow-indexed-independent')]:
  path=out/folder/'capture_frame1.rdc';cap=rd.OpenCaptureFile();assert cap.OpenFile(str(path),'',None)==rd.ResultCode.Succeeded
  options=rd.ReplayOptions();options.forceGPUVendor=rd.GPUVendor.Intel;status,c=cap.OpenCapture(options,None);assert status==rd.ResultCode.Succeeded
  row={'label':label,'capture':str(path),'captureSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'textures':[],'shadowDraws':[]};report['cases'].append(row)
  def flat(actions):
   for a in actions:
    yield a
    yield from flat(a.children)
  actions=list(flat(c.GetRootActions()));c.SetFrameEvent(actions[-1].eventId,True)
  for texture in c.GetTextures():
   depth=texture.format.compType==rd.CompType.Depth
   if not ((texture.width==16 and texture.height==16 and texture.mips==5) or depth):continue
   info={'resource':str(texture.resourceId),'width':texture.width,'height':texture.height,'layers':texture.arraysize,'mips':texture.mips,'format':texture.format.Name(),'depth':depth,'files':[]}
   for layer in range(texture.arraysize):
    for mip in range(texture.mips if not depth else 1):
     data=bytes(c.GetTextureData(texture.resourceId,rd.Subresource(mip,layer,0)));name=label+'-'+str(texture.resourceId).replace('::','-')+'-l'+str(layer)+'-m'+str(mip)+'.zlib';(out/name).write_bytes(zlib.compress(data,9));info['files'].append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
   row['textures'].append(info)
  hashes={hashlib.sha256(p.read_bytes()).hexdigest():p.name for p in (out.parent/'20261110-030251-hair-main-chroma-public-9e799c/release/shaders').glob('shadow*.frag.spv')}
  for a in actions:
   if not (a.flags&rd.ActionFlags.Drawcall):continue
   c.SetFrameEvent(a.eventId,True);pipe=c.GetPipelineState();reflection=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
   if not reflection:continue
   shaderhash=hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()
   if shaderhash not in hashes:continue
   record={'event':a.eventId,'shader':hashes[shaderhash],'shaderSha256':shaderhash,'samplers':[],'resources':[]}
   for bound in pipe.GetSamplers(rd.ShaderStage.Fragment):
    desc=bound.descriptor;values={}
    for key in ['addressU','addressV','addressW','mipBias','minLOD','maxLOD','maxAnisotropy','filter']:
     if hasattr(desc,key):values[key]=str(getattr(desc,key))
    record['samplers'].append(values)
   for bound in pipe.GetReadOnlyResources(rd.ShaderStage.Fragment):record['resources'].append({'resource':str(bound.descriptor.resource),'accessIndex':bound.access.index})
   mesh=c.GetPostVSData(0,0,rd.MeshDataStage.VSOut);record['vertexStride']=mesh.vertexByteStride;record['indexStride']=mesh.indexByteStride;record['numIndices']=mesh.numIndices
   for kind,rid in [('vertices',mesh.vertexResourceId),('indices',mesh.indexResourceId)]:
    data=bytes(c.GetBufferData(rid,0,0));name=label+'-e'+str(a.eventId)+'-'+kind+'.bin';(out/name).write_bytes(data);record[kind]={'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
   row['shadowDraws'].append(record)
  row['messages']=[str(m.description) for m in c.GetDebugMessages()];c.Shutdown();c=None;cap.Shutdown();cap=None
 report['status']='exported'
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (out/'shadow-resource-export.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='exported' else 1)
