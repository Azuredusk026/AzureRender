from pathlib import Path
import json,os,subprocess,hashlib,re,shutil
import numpy as np
from PIL import Image
out=Path(__file__).resolve().parent;source=out/'matrix-release-intel-shadow/coverage';summary=json.loads((source/'summary.json').read_text());images={};rows=[]
env=os.environ.copy();env.update(VK_LOADER_DRIVERS_SELECT='*igvk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
for row in summary['cases']:
 label=row['name'];target=out/('baseline-off-'+label);target.mkdir()
 original=source/label
 for name in row['inputs']:
  src=original/name;dst=target/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
 for model_path in target.rglob('*.gltf'):
  model=json.loads(model_path.read_text())
  for material in model.get('materials',[]):
   profile=material.get('extras',{}).get('azureRenderMaterial',{});profile['features']=[x for x in profile.get('features',[]) if x!='mirrored-coarse-uv']
  model_path.write_text(json.dumps(model,indent=2))
 command=list(row['command']);command[command.index('--project')+1]=str(target/'lab/lab.azureproject');command[command.index('--capture-dir')+1]=str(target/'frames');command[command.index('--runtime-report')+1]=str(target/'runtime.json')
 (target/'command.json').write_text(json.dumps(command,indent=2))
 with (target/'player.log').open('wb') as log:r=subprocess.run(command,cwd=target/'lab',env=env,stdout=log,stderr=log,timeout=180)
 text=(target/'player.log').read_text(errors='replace');assert r.returncode==0 and 'Allocator after unload: buffers=0 images=0' in text and not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)',text),text[-2000:]
 image=target/'frames/frame_000000.png';images[label]=np.asarray(Image.open(image).convert('RGB'));rows.append(dict(name=label,exitCode=r.returncode,sha256=hashlib.sha256(image.read_bytes()).hexdigest(),device=json.loads((target/'frames/gpu_capabilities.json').read_text())['device_name']));print(label,'captured',flush=True)
a,b=images.values();ys,xs=np.where(np.any(a!=b,axis=2));result=dict(status='diagnosed',changedPixels=len(xs),maximumByteDifference=int(abs(a.astype('i4')-b.astype('i4')).max()),differences=[dict(x=int(x),y=int(y),a=a[y,x].tolist(),b=b[y,x].tolist()) for x,y in zip(xs,ys)],cases=rows)
(out/'baseline-shadow-control-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
