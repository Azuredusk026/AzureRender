from pathlib import Path
import renderdoc as rd
import json,zlib,hashlib,traceback,sys
out=Path(r"D:\Projects\FYP-worktrees\nr-quality\Project\AzureRender\build\runs\20261110-141407-material-mirrored-uv-policy-1a9615");result={'status':'starting','cases':[]};cap=None;c=None;original=None;replacement=None
try:
 for label,folder in [('reference','capture2-shadow-indexed-reference'),('independent','capture3-shadow-indexed-independent')]:
  cap=rd.OpenCaptureFile();assert cap.OpenFile(str(out/folder/'capture_frame1.rdc'),'',None)==rd.ResultCode.Succeeded
  options=rd.ReplayOptions();options.forceGPUVendor=rd.GPUVendor.Intel;status,c=cap.OpenCapture(options,None);assert status==rd.ResultCode.Succeeded
  def snapshot():
   c.SetFrameEvent(156,True);target=c.GetPipelineState().GetOutputTargets()[0].resource;return bytes(c.GetTextureData(target,rd.Subresource()))
  baseline=snapshot();original=c.GetPipelineState().GetShader(rd.ShaderStage.Fragment);row={'label':label,'variants':[]};result['cases'].append(row)
  (out/(label+'-shadow-original-hdr.zlib')).write_bytes(zlib.compress(baseline,9))
  for variant in ['control','fine']:
   code=(out/(label+'-shadow-'+variant+'.spv')).read_bytes();replacement,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,code,rd.ShaderCompileFlags(),rd.ShaderStage.Fragment);assert replacement!=rd.ResourceId.Null(),errors
   c.ReplaceResource(original,replacement);actual=snapshot();(out/(label+'-shadow-'+variant+'-hdr.zlib')).write_bytes(zlib.compress(actual,9));entry={'name':variant,'bytes':len(actual),'sha256':hashlib.sha256(actual).hexdigest(),'exactOriginal':actual==baseline};row['variants'].append(entry)
   if variant=='control':assert actual==baseline,entry
   c.RemoveReplacement(original);c.FreeTargetResource(replacement);replacement=None;assert snapshot()==baseline
  row['messages']=[str(m.description) for m in c.GetDebugMessages()];c.Shutdown();c=None;cap.Shutdown();cap=None;original=None
 result['status']='qualified'
except Exception:result.update(status='failed',error=traceback.format_exc())
finally:
 if c:
  if original:c.RemoveReplacement(original)
  if replacement:c.FreeTargetResource(replacement)
  c.Shutdown()
 if cap:cap.Shutdown()
 (out/'shadow-fine-state.json').write_text(json.dumps(result,indent=2))
sys.exit(0 if result['status']=='qualified' else 1)
