from pathlib import Path
import os,subprocess,json
out=Path(__file__).resolve().parent
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES']:os.environ.pop(key,None)
os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*'
os.environ['VK_LAYER_PATH']='D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64'
os.environ['VK_INSTANCE_LAYERS']='VK_LAYER_RENDERDOC_Capture'
os.environ['ENABLE_VULKAN_RENDERDOC_CAPTURE']='1'
for key in ['APPDATA','LOCALAPPDATA']:
 p=out/'tmp'/key.lower();p.mkdir(parents=True,exist_ok=True);os.environ[key]=str(p)
os.environ['RENDERDOC_DEBUG_LOG_FILE']=str(out/'tmp/renderdoc.log');os.environ['RDOC_DEBUG_LOG_FILE']=str(out/'tmp/renderdoc.log')
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
with (out/'capture-shadow-driver.log').open('wb') as log:r=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'collect-shadow-captures.py')],startupinfo=startup,creationflags=subprocess.CREATE_NO_WINDOW,stdout=log,stderr=subprocess.STDOUT,timeout=400)
v=json.loads((out/'one-shadow-capture-launch.json').read_text());assert r.returncode==0 and v['status']=='queued',v
import ctypes,time,hashlib
handle=ctypes.windll.kernel32.OpenProcess(0x100000|0x1000,False,v['pid']);deadline=time.monotonic()+180
if handle:
 try:
  while ctypes.windll.kernel32.WaitForSingleObject(handle,100)==258:
   if time.monotonic()>deadline:raise TimeoutError('Declared capture target still active')
 finally:ctypes.windll.kernel32.CloseHandle(handle)
folder=out/'capture3-shadow-indexed-independent';files=list(folder.glob('*.rdc'));assert len(files)==1
v.update(status='recorded',rdc=str(files[0]),bytes=files[0].stat().st_size,sha256=hashlib.sha256(files[0].read_bytes()).hexdigest());(out/'one-shadow-capture-result.json').write_text(json.dumps(v,indent=2));print(json.dumps(v,indent=2))
