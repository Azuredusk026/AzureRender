import renderdoc as rd
import json,sys,subprocess,traceback
from pathlib import Path
out=Path(r"D:\Projects\FYP-worktrees\nr-quality\Project\AzureRender\build\runs\20261110-141407-material-mirrored-uv-policy-1a9615");report={'status':'starting'};control=None
try:
 r=json.loads((out/'one-shadow-capture-request.json').read_text());options=rd.CaptureOptions();options.apiValidation=True;options.hookIntoChildren=False
 launch=rd.ExecuteAndInject(r['source']['path'],r['working_directory'],subprocess.list2cmdline(r['arguments']),[],str(Path(r['output'])/'capture'),options,False)
 assert launch.result==rd.ResultCode.Succeeded,str(launch.result)
 control=rd.CreateTargetControl('',launch.ident,'Azure quality queued frame',False);assert control
 report.update(pid=control.GetPID(),ident=launch.ident);control.QueueCapture(1,1);control.Shutdown();control=None;report['status']='queued'
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:
 if control:control.Shutdown()
 (out/'one-shadow-capture-launch.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='queued' else 1)
