import renderdoc as rd
import sys,json,traceback,time
from pathlib import Path
out=Path(r"D:\Projects\FYP-worktrees\nr-quality\Project\AzureRender\build\runs\20261110-141407-material-mirrored-uv-policy-1a9615")
sys.path.insert(0,str(out.parents[2]/'tools/native_render'));from renderdoc_worker import capture_target
report={'status':'running','cases':[]}
try:
 for request in json.loads((out/'shadow-capture-requests.json').read_text()):
  row={'status':'starting','messages':[],'artifacts':[],'output':request['output']};report['cases'].append(row);capture_target(rd,request,row)
  assert row['status']=='captured',row
 report['status']='captured'
except Exception:report.update(status='failed',error=traceback.format_exc())
finally:(out/'shadow-capture-state.json').write_text(json.dumps(report,indent=2))
sys.exit(0 if report['status']=='captured' else 1)
