from pathlib import Path
import sys,json,os,time,subprocess,hashlib
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools');import shared_resources as s
out=Path(__file__).resolve().parent;root=out.parents[2];owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
previous=json.loads((out/'matrix-results.json').read_text()) if (out/'matrix-results.json').exists() else []
rows=[r for r in previous if r.get('status')=='reused-preserved-qualified-group' or r.get('result',{}).get('exitCode')==0]
completed={(r['configuration'],r['device'],r['group']) for r in rows}
groups=['generic-red-aa0','hair-red-aa0','hair-red-aa4','shadow','object-shadow','hair-shell-red-aa0']
for configuration,folder in [('Release','20261110-030251-hair-main-chroma-public-9e799c/release'),('Debug','20261110-031856-hair-main-chroma-debug-668bf2/debug')]:
 build=root/'build/runs'/folder
 for device in ['nvidia','intel']:
  for group in [*groups,'solid']:
   if (configuration,device,group) in completed:continue
   if configuration=='Release' and device=='nvidia' and group in groups[:-1]:
    rows.append(dict(configuration=configuration,device=device,group=group,status='reused-preserved-qualified-group'));continue
   while (out/'pause-matrix').exists():time.sleep(.2)
   label=configuration.lower()+'-'+device+'-'+group;output=out/('matrix-'+label)
   command=[sys.executable,str(root/'tools/test_material_uv_policy_gpu.py'),'--executable',str(build/'AzurePlayer.exe'),'--output',str(output),'--expected-validation','enabled' if configuration=='Debug' else 'disabled','--section','solid' if group=='solid' else 'coverage']
   if group!='solid':command+=['--case',group]
   env=dict(VK_LOADER_DRIVERS_SELECT='*igvk64*' if device=='intel' else '*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
   old={key:os.environ.get(key) for key in env};os.environ.update(env)
   for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
   started=time.monotonic()
   while True:
    lease=s.lease(s.DEFAULT_QUEUE,owner,'quality-material-uv-'+label,out)
    try:lease.__enter__();break
    except ValueError as error:
     if not any(w in str(error) for w in ['busy','still running']):raise
     if time.monotonic()-started>=180:raise TimeoutError('Queue not acquired for '+label)
     time.sleep(1)
   try:
    print('START',label,flush=True);result=s.maintenance.guarded_run(root/'build',out.name,command,600)
    (out/(label+'-execution.json')).write_text(json.dumps(result,indent=2))
    (out/(label+'-process.log')).write_bytes((out/'process.log').read_bytes())
   finally:
    lease.__exit__(None,None,None)
    for key,value in old.items():
     if value is None:os.environ.pop(key,None)
     else:os.environ[key]=value
   row=dict(configuration=configuration,device=device,group=group,result=result);rows.append(row);(out/'matrix-results.json').write_text(json.dumps(rows,indent=2))
   assert result.get('exitCode')==0 and result.get('reason') is None,result
   print('PASS',label,flush=True)
print('All matrix groups passed',flush=True)
