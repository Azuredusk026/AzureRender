import hashlib,json,zipfile,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
assert (out/'restored-build-provenance.json').exists()
sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,inputs
assert inputs(root)==json.loads((out/'baseline-source.json').read_text())
for config in ['release','debug']:
    build=root/('build/ninja-msvc-'+config)
    verify(root,json.loads((build/'build-provenance.json').read_text()))
    assert 'AZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION:BOOL=OFF' in (build/'CMakeCache.txt').read_text()
for name in ['AzureDepthPrefillRecordingTests','AzureMaterialClassEarlyDepthTests']:
    with (out/(name+'-restored.log')).open('wb') as log:subprocess.run([str(root/'build/ninja-msvc-release'/(name+'.exe')),str(root/'build/ninja-msvc-release/shaders')],stdout=log,stderr=subprocess.STDOUT,check=True)
cost=json.loads((out/'cost-results.json').read_text());capture=json.loads((out/'capture-results.json').read_text());programs=json.loads((out/'private-programs.json').read_text())
assert cost['affectedRangeReductionFraction']<.05 and len(capture['frames'])==4 and all(r['changedPixels']==0 for r in capture['frames'])
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((out/'baseline-products.json').read_text());assert all(digest(Path(p))==sha for p,sha in base.items() if p.endswith('.spv'))
evidence=root/'docs/acceptance/nr/evidence/2026-11-10/computed-view-controls';evidence.mkdir(parents=True,exist_ok=True)
names=['prepare-executed.py','prepare.py','capture.py','cost.py','archive.py','mesh.frag','baseline-source.json','baseline-products.json','candidate-build-provenance.json','restored-build-provenance.json','private-programs.json','capture-command.json','capture-results.json','capture.log','AzureDepthPrefillRecordingTests.log','AzureMaterialClassEarlyDepthTests.log','cost-results.json','startup-environment.json','configure.log','build.log','restore-configure.log','restore-build.log','private-program-build.log','frames/capture_manifest.json']
names+=['AzureDepthPrefillRecordingTests-restored.log','AzureMaterialClassEarlyDepthTests-restored.log']
for role in ['before','candidate','after']:
    names += ['cost-'+role+'/'+name for name in ['command.json','timing.json','timing.csv','environment.json','process.log']]
with zipfile.ZipFile(evidence/'validation.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for name in names:archive.write(out/name,name)
assert (evidence/'validation.zip').stat().st_size<8*1024*1024
report=dict(status='strict-compatibility-passed-efficiency-gate-failed',baselineCommit='c67eb8e',privateProgramCount=len(programs['compiled']),originalActivePrograms=678,originalResidentPrograms=len([p for p in base if p.endswith('.spv')]),originalResidentProgramsRestored=True,capture=capture,cost=cost,adoptionGate=dict(maximumBracketDriftFraction=.03,minimumWholeFrameReductionFraction=.02,minimumAffectedRangeReductionFraction=.05,minimumDriftMultiple=2),productionAdopted=False,defaultIsolationOptionRestoredOff=True,formalPerformancePassed=False,archiveBytes=(evidence/'validation.zip').stat().st_size,archiveSha256=digest(evidence/'validation.zip'),archiveFiles=[dict(name=n,bytes=(out/n).stat().st_size,sha256=digest(out/n)) for n in names])
(evidence/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','archiveBytes','archiveSha256','originalResidentPrograms']}))
