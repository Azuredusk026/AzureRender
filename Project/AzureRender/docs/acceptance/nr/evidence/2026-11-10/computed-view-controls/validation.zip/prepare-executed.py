import hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release'
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,inputs,verify
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(out/'tmp'))
os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
if '--inside' not in sys.argv:
    raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-B',str(__file__),'--inside']).returncode)
mode=sys.argv[-1] if sys.argv[-1]!='--inside' else 'prepare'
def call(label,args):
    with (out/(label+'.log')).open('wb') as log:subprocess.run(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT,check=True)
if mode=='restore':
    call('restore-configure',['cmake','--preset','msvc-release','-DAZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION=OFF'])
    call('restore-build',[sys.executable,'-B','tools/build_provenance.py','build','--build-dir',build,'--config','Release','--test-target','AzureDepthPrefillRecordingTests','--test-target','AzureMaterialClassEarlyDepthTests'])
    shutil.copyfile(build/'build-provenance.json',out/'restored-build-provenance.json');print('Restored and recorded default Release products');raise SystemExit(0)
assert not (out/'baseline-products.json').exists()
verify(root,json.loads((build/'build-provenance.json').read_text()))
(out/'baseline-source.json').write_text(json.dumps(inputs(root),indent=2))
base={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}
(out/'baseline-products.json').write_text(json.dumps(base,indent=2));shutil.copyfile(build/'AzurePlayer.exe',out/'baseline-AzurePlayer.exe')
call('configure',['cmake','--preset','msvc-release','-DAZURE_ENABLE_DEFAULT_ISOLATION_SPECIALIZATION=ON'])
call('build',[sys.executable,'-B','tools/build_provenance.py','build','--build-dir',build,'--config','Release','--test-target','AzureDepthPrefillRecordingTests','--test-target','AzureMaterialClassEarlyDepthTests'])
shutil.copyfile(build/'build-provenance.json',out/'candidate-build-provenance.json')
shutil.copyfile(build/'AzurePlayer.exe',out/'candidate-AzurePlayer.exe')
runtime=out/'runtime';(runtime/'shaders').mkdir(parents=True)
for p in sorted((build/'shaders').glob('*.spv')):os.link(p,runtime/'shaders'/p.name)
text=(root/'shaders/mesh.frag').read_text();before=text
replacements=[]
for name,threshold,value in [('clusterLighting','>.5','true'),('clusterLighting','<.5','false'),('screenReflectionTrace','>.5','true'),('screenReflectionTrace','>1.5','true')]:
    op=threshold[0];number=threshold[1:]
    pattern=r'camera\.'+name+r'\.x\s*'+re.escape(op)+r'\s*'+re.escape(number)
    text,count=re.subn(pattern,'('+value+')',text);replacements.append(dict(pattern=pattern,count=count,replacement=value))
text,count=re.subn(r'int qaEffectMode = int\(floor\(camera\.qaParameters\.y \+ 0\.5\)\);','int qaEffectMode = 0;',text);assert count==1
text,count=re.subn(r'bool qaEffectDisabled = camera\.qaParameters\.z < 0\.5;','bool qaEffectDisabled = false;',text);assert count==1
(out/'mesh.frag').write_text(text)
manifest=json.loads((build/'shader-reload.json').read_text());programs=[p for p in manifest['programs'] if p['source']=='mesh.frag' and '_isolation0.frag.spv' in p['output']]
assert len(programs)==64,len(programs)
compiled=[]
with (out/'private-program-build.log').open('wb') as log:
    for p in programs:
        path=runtime/'shaders'/p['output'];assert path.is_file();path.unlink()
        command=[manifest['compiler'],*('-D'+x for x in p['defines']),*p['arguments'],'-I'+str(root/'shaders'),str(out/'mesh.frag'),'-o',str(path)]
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
        subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.3','--relax-block-layout',str(path)],stdout=log,stderr=subprocess.STDOUT,check=True)
        compiled.append(dict(program=p,sha256=digest(path),bytes=path.stat().st_size))
assert all(digest(Path(p))==sha for p,sha in base.items() if p.endswith('.spv'))
assert inputs(root)==json.loads((out/'baseline-source.json').read_text())
(out/'private-programs.json').write_text(json.dumps(dict(sourceBeforeSha256=hashlib.sha256(before.encode()).hexdigest(),sourceAfterSha256=digest(out/'mesh.frag'),replacements=replacements,compiled=compiled,scope='Existing default-isolation pipeline selection restricts this private program family to ordinary main opaque surfaces; test input requires scene lighting, beauty/default effect and computed reflection'),indent=2))
print('Prepared 64 private programs; production source and base shaders unchanged',flush=True)
