from pathlib import Path
import json,zlib,math,numpy as np
out=Path(__file__).resolve().parent;d=json.loads((out/'state.json').read_text());assert d['status']=='qualified' and len(d['captures'])==1;c=d['captures'][0];assert c['sourceControlQualified'] and c['baselineRestored'] and not c['debugMessages'] and len(c['runs'])==9 and all(r['qualified'] for r in c['runs']);mixed=np.zeros((31,3),dtype='<u4')
for r in c['runs']:
 q=r['case'];v=np.array(r['values'],dtype='<u4')
 if q['shift']==24:assert (v<=255).all()
 mixed[:,q['component']]|=v<<q['shift']
a=mixed[:,0].astype('u8');b=mixed[:,1].astype('u8');e=mixed[:,2].astype('u8');w=np.stack([(3*a-b-e)&0xffffffff,(b-a)&0xffffffff,(e-a)&0xffffffff],axis=1).astype('<u4');assert np.isfinite(w.view('<f4')).all()
def r11code(value,m):
 value=float(value)
 if value<=0:return 0
 exponent=math.frexp(value)[1]-1
 if exponent>15:return 31<<m
 if exponent < -14:return int(math.floor(math.ldexp(value,14+m)))
 return ((exponent+15)<<m)|int(math.floor((math.ldexp(value,-exponent)-1)*(1<<m)))
native=json.loads((out.parent/'20261110-013009-hair-final-float-values-c03e78/results.json').read_text());lookup={tuple(r['pixel']):r for r in native['rows']};stored=np.frombuffer(zlib.decompress((out/'pre-vulkan-stored-baseline.zlib').read_bytes()),dtype='<u2').reshape(310,290,4);rows=[]
for i,p in enumerate(d['points']):
 n=lookup[tuple(p)];v=w[i].view('<f4');half=v.astype('<f2');bits=half.view('<u2').copy();bits[abs(half.astype('f8'))>abs(v.astype('f8'))]-=1;target=stored[p[1]-130,p[0]-1140,:3];codes=[r11code(x,m) for x,m in zip(v,[6,6,5])];rows.append(dict(pixel=p,vulkanBits=w[i].tolist(),vulkan=v.tolist(),native=n['native'],maximumAbsolute=float(abs(v-np.array(n['native'])).max()),halfTowardZeroQualified=bool(np.all(bits==target)),r11Codes=codes,nativeCodes=n['nativeStoredCodes'],r11Exact=codes==n['nativeStoredCodes']))
r=dict(status='qualified-corrected-final-float',points=31,halfTowardZeroQualified=sum(x['halfTowardZeroQualified'] for x in rows),r11Exact=sum(x['r11Exact'] for x in rows),maximumAbsolute=max(x['maximumAbsolute'] for x in rows),rows=rows,qualification=d,execution=json.loads((out/'execution.json').read_text()),scope='Actual Vulkan final F32 values after private measured-visibility and selected-main control. Mixed integer encoding retains all RGB data dependencies; full blue crop qualification remains required.');(out/'results.json').write_text(json.dumps(r,indent=2)+'\n');print({k:v for k,v in r.items() if k not in ['rows','qualification','execution']});assert r['halfTowardZeroQualified']==31
