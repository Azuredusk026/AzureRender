from pathlib import Path
import json,subprocess
out=Path(__file__).resolve().parent
base=out.parent/'20261110-025538-hair-selected-main-composite-d0b96a';text=(base/'candidate.spvasm').read_text();sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin');cases=[]
for component in range(3):
 for shift in [0,12,24]:
  name=f'color-{component}-{shift}'
  declarations=f'''%final_probe_scale = OpConstant %float 0.015625
%final_probe_mask = OpConstant %uint 63
%final_probe_shift_r = OpConstant %uint {shift}
%final_probe_shift_g = OpConstant %uint {shift+6}
'''
  start=text.index('       %main = OpFunction');t=text[:start]+declarations+text[start:];start=t.index('%main = OpFunction');end=t.index('OpFunctionEnd',start);body=t[start:end];assert body.count('OpReturn\n')==1
  probe=f'''%final_probe_original = OpLoad %v4float %outputColor
%final_probe_red = OpCompositeExtract %float %final_probe_original 0
%final_probe_green = OpCompositeExtract %float %final_probe_original 1
%final_probe_blue = OpCompositeExtract %float %final_probe_original 2
%final_probe_red_bits = OpBitcast %uint %final_probe_red
%final_probe_green_bits = OpBitcast %uint %final_probe_green
%final_probe_blue_bits = OpBitcast %uint %final_probe_blue
%final_probe_rg = OpIAdd %uint %final_probe_red_bits %final_probe_green_bits
%final_probe_rgb = OpIAdd %uint %final_probe_rg %final_probe_blue_bits
%final_probe_extra = OpCompositeExtract %float %final_probe_original {component}
%final_probe_extra_bits = OpBitcast %uint %final_probe_extra
%final_probe_bits = OpIAdd %uint %final_probe_rgb {'%uint_0' if component==0 else '%final_probe_extra_bits'}
%final_probe_rs = OpShiftRightLogical %uint %final_probe_bits %final_probe_shift_r
%final_probe_gs = OpShiftRightLogical %uint %final_probe_bits %final_probe_shift_g
%final_probe_rb = OpBitwiseAnd %uint %final_probe_rs %final_probe_mask
%final_probe_gb = OpBitwiseAnd %uint %final_probe_gs %final_probe_mask
%final_probe_rf = OpConvertUToF %float %final_probe_rb
%final_probe_gf = OpConvertUToF %float %final_probe_gb
%final_probe_r = OpFMul %float %final_probe_rf %final_probe_scale
%final_probe_g = OpFMul %float %final_probe_gf %final_probe_scale
%final_probe_b = OpCompositeExtract %float %final_probe_original 2
%final_probe_a = OpCompositeExtract %float %final_probe_original 3
%final_probe_color = OpCompositeConstruct %v4float %final_probe_r %final_probe_g %final_probe_b %final_probe_a
OpStore %outputColor %final_probe_color
OpReturn
'''
  t=t[:start]+body.replace('OpReturn\n',probe)+t[end:];(out/(name+'.spvasm')).write_text(t)
  for cmd in [[str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/(name+'.spvasm')),'-o',str(out/(name+'.spv'))],[str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/(name+'.spv'))]]:subprocess.run(cmd,check=True)
  cases.append(dict(name=name,component=component,shift=shift))
(out/'cases.json').write_text(json.dumps(cases,indent=2));print('Prepared nine corrected-composite Vulkan final-float probes')
