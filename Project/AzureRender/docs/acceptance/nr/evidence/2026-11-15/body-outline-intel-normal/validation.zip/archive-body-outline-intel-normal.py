"""Archive the live Intel normal comparison and the capture fingerprints."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


root=Path(__file__).resolve().parent
target=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/body-outline-intel-normal'
read=lambda path:json.loads(path.read_bytes())
relative='body-outline-normal-intel'
live=read(root/relative/'results.json')
comparative=read(root/'body-outline-intel-normal-comparison.json')
assert comparative['status']=='measured-live-intel-shaded-normal'
assert comparative['counts']==dict(points=1118,outputWithinFive=1088,nativeAddressWithinFive=1060)
assert len(comparative['controls'])==4
assert max(row['angularError'] for row in comparative['controls'])<.43
manifest=read(root/relative/'frames/capture_manifest.json')
caps=read(root/relative/'frames/gpu_capabilities.json')
assert manifest['qaIsolation']=='shaded-normal' and caps['vendor_id']==0x8086
assert comparative['playerSha256']==live['playerSha256']
target.mkdir(parents=True,exist_ok=True)
members=('score-body-outline-intel-normal.py','archive-body-outline-intel-normal.py',
    'body-outline-source-footprint.json','body-outline-screen-normal-states.json',
    'body-outline-local-rim-radial-model.json','body-outline-intel-normal-comparison.json',
    f'{relative}/results.json',f'{relative}/command.json',
    f'{relative}/frames/capture_manifest.json',f'{relative}/frames/gpu_capabilities.json')
zpath=target/'validation.zip'
with ZipFile(zpath,'w',ZIP_DEFLATED) as archive:
    for filename in members:archive.write(root/filename,filename)
with ZipFile(zpath) as archive:
    assert archive.testzip() is None
    checks={member:sha256(archive.read(member)).hexdigest() for member in members}
assert checks=={member:sha256((root/member).read_bytes()).hexdigest() for member in members}
del comparative['rows']
comparative['frameSha256']=live['frameSha256']
comparative['overallVisualAcceptance']='failed-user-review'
comparative['archive']=dict(sha256=sha256(zpath.read_bytes()).hexdigest(),members=checks)
(target/'results.json').write_text(json.dumps(comparative,indent=2)+'\n',encoding='utf8')
