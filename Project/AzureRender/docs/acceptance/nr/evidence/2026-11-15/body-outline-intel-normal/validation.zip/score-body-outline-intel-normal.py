"""Compare live shaded-normal output with the original shell input."""
from hashlib import sha256
from pathlib import Path
import json

import numpy as np


root=Path(__file__).resolve().parent
read=lambda path:json.loads(path.read_bytes())
source=read(root/'body-outline-source-footprint.json')
model=read(root/'body-outline-screen-normal-states.json')
path=root/'body-outline-normal-intel/results.json'
actual=read(path)
assert actual['status']=='sampled' and actual['mode']=='shaded-normal'
assert len(source['points'])==len(actual['points'])==1118
assert sha256((path.parent/'frames/frame_000000.png').read_bytes()).hexdigest()==actual['frameSha256']
expected={tuple(row[:2]):row for row in source['points']}


def norm(encoded):
    x=np.asarray(encoded)/255
    value=np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)*2-1
    return value/np.linalg.norm(value)


def decode(word):
    x=(word&1023)/1023*2-1
    z=((word>>10)&1023)/1023*2-1
    y=1-abs(x)-abs(z)
    if y<0:x,z=(1-abs(z))*np.sign(x),(1-abs(x))*np.sign(z)
    n=np.asarray([-x,y,z])
    return n/np.linalg.norm(n)


def angle(v,u):
    return float(np.degrees(np.arccos(np.clip(v@u,-1,1))))


rows=[]
for row in actual['points']:
    data=expected[tuple(row['point'])]
    assert row['sourceAddress']==data[2:4]
    desired=decode(data[6])
    rows.append(dict(point=row['point'],sourceAddress=row['sourceAddress'],
        outputAngle=angle(norm(row['fragmentBytes']),desired),
        sourceAddressAngle=angle(norm(row['sourceAddressBytes']),desired)))
controls={tuple(row['point']):row for row in model['points']}
key=[]
for row in actual['controls']:
    original=controls[tuple(row['point'])]
    assert row['sourcePixel']==original['nativeSampleDisplay'] and row['nativeNormal']==original['authoredNormal']
    key.append(dict(point=row['point'],sourceAddress=row['sourcePixel'],
        angularError=angle(norm(row['actual']),np.asarray(row['nativeNormal'])*[-1,1,1])))
rows_by_point={tuple(row['point']):row for row in rows}
highlights=[]
for rim in read(root/'body-outline-local-rim-radial-model.json')['worst']:
    row=rows_by_point[tuple(rim['point'])]
    highlights.append(dict(point=rim['point'],nvidiaDisplayError=rim['baselineError'],intelNormalDegrees=row['outputAngle']))
assert len(highlights)==12 and all(row['intelNormalDegrees']<1.5 for row in highlights)
summary=dict(status='measured-live-intel-shaded-normal',playerSha256=actual['playerSha256'],
    inputSha256=sha256(path.read_bytes()).hexdigest(),
    counts=dict(points=len(rows),outputWithinFive=sum(row['outputAngle']<5 for row in rows),
                nativeAddressWithinFive=sum(row['sourceAddressAngle']<5 for row in rows)),
    controls=key, largeNvidiaColorResidualControls=highlights,rows=rows)
(root/'body-outline-intel-normal-comparison.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print(summary['counts'],key)
