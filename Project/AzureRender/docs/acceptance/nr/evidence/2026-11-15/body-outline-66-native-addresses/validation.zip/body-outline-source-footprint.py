"""Recover source normal addresses over the full reference shell footprint."""
from pathlib import Path
import json
import runpy

import numpy as np

run=Path(__file__).resolve().parent
g=runpy.run_path(str(run/'body-outline-uv-albedo.py'))
n=runpy.run_path(str(run/'body-outline-screen-normal-states.py'))
trace=g['trace']
read=g['read']
cb0=np.fromfile(trace/'ps-cb0.bin','<f4').reshape(-1,4)
cb1=np.fromfile(trace/'ps-cb1.bin','<f4').reshape(-1,4)
assert tuple(cb1[0,:2])==(2560.,1440.)
normal=n['normal']
src_xyz=g['vertices'][:,6:9]
tri=g['tri']

def source_address(x,y,primitive):
    bary,_=g['bary'](np.array([x+.5,y+.5]),tri[primitive:primitive+1],g['screen'])
    i=tri[primitive]
    w=bary[0]*g['pixel_w'][i]
    pos=(w@src_xyz[i])/w.sum()
    proj=pos@cb0[32:35]+cb0[35]
    sx=(proj[0]/proj[3])*.5+.5-cb1[19,2]
    sy=.5-(proj[1]/proj[3])*.5-cb1[19,3]
    return np.asarray([sx,sy])*cb1[0,:2]

for p in n['rows'][:4]:
    x,y=p['point']
    s=source_address(x,y,g['source_triangle'](x,y))
    assert np.floor(s).astype(int).tolist()==[p['nativeSampleDisplay'][0],1439-p['nativeSampleDisplay'][1]],(p,s)

mask=g['orig_depth']!=g['depth']
yy,xx=np.where(mask)
assert len(yy)==1184
def select(x,y):
    q=np.array([x+.5,y+.5])
    snapped,area=g['bary'](q,tri,g['pos'])
    passing=np.flatnonzero((snapped>=-1e-12).all(1)&(area<0))
    assert len(passing)>0,'no covered back face'
    idx=tri[passing]
    z=np.sum(snapped[passing]*g['pixel_z'][idx],axis=1)
    target=g['depth'][y,x]
    diff=np.abs(z-target)
    best=int(np.argmin(diff))
    assert diff[best]<=1.5e-8,(int(passing[best]),float(diff[best]))
    return int(passing[best])

rows=[];missing=[]
for x,y in zip(xx,yy):
    try:
        i=select(int(x),int(y))
    except AssertionError as failure:
        missing.append([int(x),int(y),repr(failure.args)])
        continue
    s=source_address(x,y,i)
    a,b=map(int,np.floor(s))
    assert 0<=a<2560 and 0<=b<1440
    rows.append([int(x),int(y),a,1439-b,int(i),s.tolist(),int(normal[b,a]),int(normal[1439-y,x])])
assert len(rows)+len(missing)==1184 and len(rows)>0
addr=np.array([p[:4] for p in rows])
packed=np.array([p[6:] for p in rows],dtype='<u4')
repro=n['decode'](packed[:,0])
fixed=n['decode'](packed[:,1])
anglerad=np.arccos(np.clip((repro*fixed).sum(1),-1,1))
angles=np.degrees(anglerad)
values,counts=np.unique(addr[:,2:]-addr[:,:2],axis=0,return_counts=True)
result=dict(status='source-footprint',nativeCoverage=1184,reconstructed=len(rows),
    offsetCounts=[dict(offset=v.tolist(),count=int(c)) for v,c in zip(values,counts)],
    differingNormal=int(np.count_nonzero(angles>1e-4)),angleOver90=int(np.count_nonzero(angles>90)),
    emptyAtSource=int(np.count_nonzero((packed[:,0]&0xfffff)==0)),
    emptyAtOutput=int(np.count_nonzero((packed[:,1]&0xfffff)==0)),
    quantilesDegrees=np.quantile(angles,[0,.25,.5,.75,.95,1]).tolist(),missing=missing)
print(json.dumps(result,indent=2))
result.update(points=rows)
(run/'body-outline-source-footprint.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
