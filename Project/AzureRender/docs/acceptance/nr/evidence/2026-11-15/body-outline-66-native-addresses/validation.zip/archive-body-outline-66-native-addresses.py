from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile

root=Path(__file__).resolve().parent
output=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/body-outline-66-native-addresses'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
record=read(root/'body-outline-66-native-addresses.json')
assert record['matchedTriangleCount']==record['nativeArithmeticMatches']==len(record['samples'])==66
assert (record['predictedAddressMatches'],record['snappedAddressMatches'])==(39,40)
members={name:root/name for name in ('archive-body-outline-66-native-addresses.py',
    'body-outline-66-native-addresses.py','body-outline-66-native-addresses.json',
    'body-outline-source-footprint.py','trace-body-outline-addresses-source.json',
    'trace-body-outline-addresses-request.json','trace-body-outline-source.py',
    'body-outline-unqualified-depth-probe.json')}
output.mkdir(parents=True,exist_ok=True)
package=output/'validation.zip'
with ZipFile(package,'w',ZIP_DEFLATED) as archive:
    for name,path in members.items():archive.write(path,name)
with ZipFile(package) as archive:
    assert archive.testzip() is None
    atlas={name:sha256(archive.read(name)).hexdigest() for name in members}
assert atlas=={name:digest(path) for name,path in members.items()}
record['archive']=dict(sha256=digest(package),members=atlas)
record['strictScreenNormalAddress']='failed'
(output/'results.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
