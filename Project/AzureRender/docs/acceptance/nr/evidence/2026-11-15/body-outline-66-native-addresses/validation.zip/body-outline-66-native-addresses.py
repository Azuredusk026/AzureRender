from pathlib import Path
import contextlib
import io
import json
import runpy
import numpy as np

root=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
with contextlib.redirect_stdout(io.StringIO()):
    native_context=runpy.run_path(str(root/'body-outline-source-footprint.py'))
previous={tuple(row['point']):row for row in read(root/'body-outline-unqualified-depth-probe.json')['records']}
new=read(root/'trace-body-outline-addresses-source.json')
assert new['status']=='qualified' and len(previous)==len(new['points'])==66
m=native_context['g']
float32=np.float32
cb0,cb1=native_context['cb0'],native_context['cb1']
matrix=cb0[32:36][:,[0,1,3]]


def transformed_position(position):
    x,y,z=position.astype(float32)
    partial=(matrix[1]*y).astype(float32)
    partial=(matrix[0].astype(float)*float(x)+partial).astype(float32)
    partial=(matrix[2].astype(float)*float(z)+partial).astype(float32)
    return (partial+matrix[3]).astype(float32)


def pixel_address(clip):
    offset=clip[2]*cb1[19,2:4]
    ndc=(clip[:2]+offset*[-2,2]).astype(float32)/clip[2]
    uv=(ndc*.5+.5).astype(float32)
    return np.asarray([uv[0],float32(1-uv[1])],dtype=float32)*cb1[0,:2]


samples=[]
for row in new['points']:
    x,y=row['point']
    point=(x,y)
    assert len(previous[point]['inside'])==1
    match=previous[point]['inside'][0]
    assert match['triangle']==row['primitive']
    hardware_clip=np.asarray(row['clip'],dtype=float32)
    subpixel=np.asarray(row['floatAddress'],dtype=float32)
    address=np.asarray(row['addressBits'],dtype='<f4').view('<u4')
    exact=pixel_address(hardware_clip)
    assert np.array_equal(exact,subpixel) and np.array_equal(np.floor(exact),address)
    ideal=native_context['source_address'](x,y,row['primitive'])
    indices=m['tri'][row['primitive']]
    bary,_=m['bary'](np.asarray([x+.5,y+.5]),indices[None,:],m['pos'])
    weights=bary[0]*m['pixel_w'][indices]
    position=(weights@native_context['src_xyz'][indices])/weights.sum()
    snapped=pixel_address(transformed_position(position))
    from_clip=np.linalg.solve(matrix[:3].T.astype(float),hardware_clip.astype(float)-matrix[3])
    samples.append(dict(point=[x,y],primitive=row['primitive'],depthError=match['depthError'],
        address=address.tolist(),hardwareSubpixel=subpixel.tolist(),hardwareClip=hardware_clip.tolist(),
        predictedSubpixel=ideal.tolist(),snappedSubpixel=snapped.tolist(),
        predictedExact=bool(np.array_equal(np.floor(ideal),address)),
        snappedExact=bool(np.array_equal(np.floor(snapped),address)),
        inferredPosition=from_clip.tolist(),snappedPosition=position.tolist()))
result=dict(status='measured-native-triangles-and-addresses',samples=samples,matchedTriangleCount=len(samples),
    nativeArithmeticMatches=len(samples),predictedAddressMatches=sum(r['predictedExact'] for r in samples),
    snappedAddressMatches=sum(r['snappedExact'] for r in samples),
    idealMismatches=[r['point'] for r in samples if not r['predictedExact']],
    snappedMismatches=[r['point'] for r in samples if not r['snappedExact']])
(root/'body-outline-66-native-addresses.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print({key:value for key,value in result.items() if key!='samples'})
