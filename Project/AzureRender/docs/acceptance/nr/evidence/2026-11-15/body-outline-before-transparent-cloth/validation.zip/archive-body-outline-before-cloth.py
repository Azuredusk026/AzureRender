from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile

run=Path(__file__).resolve().parent
stage=run/'body-outline-before-transparent-cloth'
read=lambda path:json.loads(path.read_bytes())
digest=lambda path:sha256(path.read_bytes()).hexdigest()
report=read(stage/'results.json')
assert report['status']=='measured-native-transparent-primitive-order'
provenance=read(stage/'preflight.json')
assert provenance==report['source']
assert digest(stage/'body-native-lit-outline-production-native-order.gltf')==provenance['candidate']
assert provenance['currentChildren'][0]==provenance['outline'] and provenance['cloth'] in provenance['currentChildren']
files={'body-outline-before-transparent-cloth.py':run/'body-outline-before-transparent-cloth.py',
    'archive-body-outline-before-cloth.py':Path(__file__)}
for path in ('preflight.json','results.json'):files[f'{stage.name}/{path}']=stage/path
for adapter,after in [('nvidia',[1,1,4,37]),('intel',[2,2,4,36])]:
    sample=report['devices'][adapter]
    assert sample['changedOutside']==sample['newOverOne']==0
    assert sample['metrics']['cloth']['count']==57 and sample['metrics']['cloth']['overEight']==[56,5]
    assert sample['metrics']['outline']['count']==1112 and sample['metrics']['outline']['changed']==0
    assert [row['peak'][1] for row in sample['probes'][:4]]==after
    folder=stage/adapter
    assert digest(folder/'frames/frame_000000.png')==sample['frame']
    assert read(folder/'receipt.json')['frame']==sample['frame']
    hardware=read(folder/'frames/gpu_capabilities.json')
    assert hardware['vendor_id']==(0x10de if adapter=='nvidia' else 0x8086)
    for name in ('receipt.json','command.json','runtime.json','player.log','frames/capture_manifest.json','frames/gpu_capabilities.json'):
        files[f'{stage.name}/{adapter}/{name}']=folder/name
save=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/body-outline-before-transparent-cloth'
save.mkdir(parents=True,exist_ok=True)
zip_path=save/'validation.zip'
with ZipFile(zip_path,'w',ZIP_DEFLATED) as archive:
    for name,path in files.items():archive.write(path,name)
with ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    checks={name:sha256(archive.read(name)).hexdigest() for name in files}
assert checks=={name:digest(path) for name,path in files.items()}
report['archive']=dict(sha256=digest(zip_path),members=checks)
report['overall']='failed-user-review'
(save/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print([(name,row['metrics']['cloth']['overEight']) for name,row in report['devices'].items()])

