"""Retest final body and cloth color with the native primitive order."""
from contextlib import ExitStack
from hashlib import file_digest
import json
import os
from pathlib import Path
import runpy
import sys

import numpy as np


root=Path(__file__).resolve().parent
body=root.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
controls=root.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
fixture=grid/'iris-overlay-geometry-project'
stage=root/'body-outline-before-transparent-cloth'
name='body-native-lit-outline-blend-depth'
character='body-native-lit-outline-production'
helper=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
score=runpy.run_path(str(grid/'static-quality.py'))
read=lambda p:json.loads(p.read_bytes())


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def dump(path,data):
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')


def reserve(planned):
    sys.path.insert(0,str(root.parents[2]/'tools'))
    from artifact_budget import check
    budget=check(root.parents[1],run=root,planned=planned)
    assert budget['allowed'],budget


def prepare():
    reserve(105_000_000)
    stage.mkdir(exist_ok=True)
    source=body/f'{character}-ordered.gltf'
    original=source.read_bytes()
    document=json.loads(original)
    nodes,materials,meshes=(document[name] for name in ('nodes','materials','meshes'))

    def names(node):
        if 'mesh' not in node:return []
        return [materials[p['material']]['name'] for p in meshes[node['mesh']]['primitives']]

    cloth,=[i for i,node in enumerate(nodes) if 'M_actor_laevat_cloth_03' in names(node)]
    outline,=[i for i,node in enumerate(nodes) if 'M_actor_laevat_body_01_lit_outline' in names(node)]
    _,parent=next((i,node) for i,node in enumerate(nodes) if cloth in node.get('children',[]))
    siblings=parent['children']
    assert siblings[-1]==outline and cloth in siblings and siblings.count(outline)==1
    before=list(siblings)
    after=[outline,*siblings[:-1]]
    encode=lambda value:b'"children":'+json.dumps(value,separators=(',',':')).encode()
    assert original.count(encode(before))==1
    corrected=original.replace(encode(before),encode(after))
    assert corrected.replace(encode(after),encode(before))==original
    target=stage/f'{character}-native-order.gltf'
    target.write_bytes(corrected)
    artifact=dict(original=sha(source),candidate=sha(target),parent=parent['name'],
                  outline=outline,cloth=cloth,previousChildren=before,currentChildren=after,
                  originalBytes=len(original),candidateBytes=len(corrected))
    dump(stage/'preflight.json',artifact)
    print(json.dumps(artifact))


def capture(device,original,alternate,artifact):
    out=stage/device
    result=out/'frames/frame_000000.png'
    saved=out/'receipt.json'
    if saved.is_file():
        report=read(saved)
        assert sha(result)==report['frame'] and report['mesh']==artifact['candidate']
        return result
    if out.exists():
        out.rename(stage/f'{device}-interrupted-{len(list(stage.glob(device+"-interrupted-*")))+1}')
    out.mkdir(exist_ok=True)
    material=original/f'{name}.azurematerial'
    old=read(original/'results.json')
    assert sha(material)==old['materialSha256']
    surface=read(material)['surface']['materials'][0]
    profile=surface['extras']['azureRenderMaterial']
    assert surface['alphaMode']=='BLEND' and profile['blendDepth']['write']
    assert profile['nprDiffuse']['rimOrigin']['node']=='CapturedBodyOrigin'
    paths={
        fixture/'character'/f'{character}.gltf':alternate,
        fixture/'materials'/material.name:material,
        fixture/'materials'/f'{material.name}.azmeta':body/f'{material.name}.azmeta',
        fixture/'scene'/f'{name}.azurelevel':body/f'{name}.azurelevel',
        fixture/f'{name}.azureproject':body/f'{name}.azureproject',
    }
    for path in list(paths):
        sidecar=path.name+'.azmeta'
        if (body/sidecar).is_file() and not path.with_name(sidecar).exists():
            paths[path.with_name(sidecar)]=body/sidecar
    argv=read(original/'command.json')
    assert sha(Path(argv[0]))==old['playerSha256']
    for flag,substitute in (('--capture-dir',out/'frames'),('--runtime-report',out/'runtime.json')):
        argv[argv.index(flag)+1]=str(substitute)
    with ExitStack() as cleanup:
        for dest,source in paths.items():
            assert not dest.exists(),dest
            dest.hardlink_to(source)
            cleanup.callback(dest.unlink)
            if dest.suffix in ('.azureproject','.azurelevel'):
                sidecar=dest.with_name(dest.name+'.azmeta')
                if sidecar not in paths:
                    assert not sidecar.exists()
                    cleanup.callback(sidecar.unlink,missing_ok=True)
        frame=helper['invoke'](device,argv,out)/'frame_000000.png'
        assert frame==result and frame.is_file()
    dump(saved,dict(frame=sha(frame),mesh=artifact['candidate'],player=old['playerSha256'],material=old['materialSha256']))
    return frame


def run():
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==root
    programs=runpy.run_path(str(body/'face-quality-candidate-catalog.py'))
    fingerprints=programs['retained_catalog'](body)
    programs['restore'](fingerprints)
    assert {p.name:programs['sha'](p) for p in ((body/'msaa-release')/'shaders').glob('*.spv')}==fingerprints
    reserve(9_000_000)
    artifact=read(stage/'preflight.json')
    source=body/f'{character}-ordered.gltf'
    vertex=stage/f'{character}-native-order.gltf'
    assert sha(source)==artifact['original'] and sha(vertex)==artifact['candidate']
    reference=score['image'](score['reference_path']).astype(np.int16)
    ownership=controls/'body-visible-ownership-points.bin'
    x,y,owners=np.fromfile(ownership,'<u2').reshape(-1,3).T
    cover=np.zeros(reference.shape[:2],dtype=bool)
    cover[y,x]=True
    assert int(cover.sum())==1184
    qualified={}
    indices={'all':np.ones(len(x),dtype=bool),'outline':owners==1018,'cloth':owners==1383}
    native=read(body/'body-native-late-cloth-traces/component-analysis.json')
    source_at={tuple(row['point']):row for row in native['witnesses']}
    for device in ('nvidia','intel'):
        control=body/f'body-outline-beauty-transparent-highlights-captured-origin-{device}'
        path=control/'frames/frame_000000.png'
        assert sha(path)==read(control/'results.json')['frameSha256']
        frame=capture(device,control,vertex,artifact)
        before,after=[score['image'](p).astype(np.int16) for p in (path,frame)]
        baseline,actual=[np.abs(p-reference).max(2) for p in (before,after)]
        change=np.any(before!=after,axis=2)
        metrics={}
        for area,mask in indices.items():
            metrics[area]=dict(count=int(mask.sum()),changed=int(change[y,x][mask].sum()),
                overOne=[int((e[y,x][mask]>1).sum()) for e in (baseline,actual)],
                overEight=[int((e[y,x][mask]>8).sum()) for e in (baseline,actual)],
                peak=[int(e[y,x][mask].max()) for e in (baseline,actual)])
        probes=[]
        for px,py in ((1252,839),(1255,837),(1152,797),(1234,789),(1258,971)):
            probe=dict(point=[px,py],reference=reference[py,px].tolist(),default=before[py,px].tolist(),
                ordered=after[py,px].tolist(),peak=[int(e[py,px]) for e in (baseline,actual)])
            if (px,py) in source_at:
                row=source_at[px,py]
                linear=before[py,px].astype(float)/255
                destination=np.where(linear<=.04045,linear/12.92,((linear+.055)/1.055)**2.4)
                blend=row['alpha']*np.asarray(row['shader'])+(1-row['alpha'])*destination
                predicted=np.rint(255*np.where(blend<=.0031308,12.92*blend,1.055*blend**(1/2.4)-.055)).astype(int)
                probe['simulatedNativeClothOnControl']=predicted.tolist()
            probes.append(probe)
        qualified[device]=dict(frame=sha(frame),original=sha(path),metrics=metrics,changedOutside=int(change[~cover].sum()),
            newOverOne=int(((baseline<=1)&(actual>1)).sum()),probes=probes)
        print(device,json.dumps(qualified[device]),flush=True)
    result=dict(status='measured-native-transparent-primitive-order',nativeThreshold='unchanged',
        source=artifact,reference=sha(score['reference_path']),devices=qualified)
    dump(stage/'results.json',result)


if sys.argv[1:]==['preflight']:prepare()
else:
    assert not sys.argv[1:]
    run()
