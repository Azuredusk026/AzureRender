#include "rhi/PipelineCacheStore.hpp"
#include <chrono>
#include <filesystem>
#include <iostream>

using namespace azurerender::rhi;
using Clock = std::chrono::steady_clock;

int main(int argc, char** argv) {
    if (argc != 3) return 2;
    const auto start = Clock::now();
    const auto profile = shaderCacheProfile(argv[1]);
    const auto profiled = Clock::now();
    if (!profile || *profile != 3734923352506864252ULL) return 3;
    PipelineCacheIdentity identity;
    identity.vendor = 0x10de;
    identity.device = 0x28e0;
    identity.driver = 0x94d3c000;
    identity.uuid = {0xe5,0xfd,0x15,0xff,0x5c,0xca,0x63,0x38,0x70,0x21,0xa4,0x93,0x88,0xfd,0x1d,0xc4};
    identity.profile = *profile;
    PipelineCacheStore store(argv[2], identity);
    const auto read = Clock::now();
    const auto bytes = store.load();
    const auto loaded = Clock::now();
    std::cout << "profile=" << *profile << " size=" << bytes.size()
              << " profileMs=" << std::chrono::duration<double,std::milli>(profiled - start).count()
              << " loadMs=" << std::chrono::duration<double,std::milli>(loaded - read).count() << '\n';
    return bytes.empty() ? 4 : 0;
}
