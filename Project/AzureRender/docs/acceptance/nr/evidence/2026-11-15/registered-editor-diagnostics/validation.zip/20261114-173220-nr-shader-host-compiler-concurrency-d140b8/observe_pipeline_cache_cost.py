"""Measure the real cache identity and load functions under the two normal build modes."""
from pathlib import Path
import json, os, re, subprocess, sys
from isolated_link import catalog, hash_file, quoted, replace_one

here = Path(__file__).resolve().parent
root = here.parents[2]
test = 'AzurePipelineCacheStoreTests'
product = 'PipelineCacheCost'


def link(build, config, objects, out, stem):
    [row] = json.loads(catalog(build, 'compdb', '-x', f'CXX_EXECUTABLE_LINKER__{test}_{config}'))
    line = row['command']; start = line.index('&& ') + 3; line = line[start:line.index(' &&', start)]
    line = replace_one(line, fr'CMakeFiles\{test}.dir\tests\PipelineCacheStoreTests.cpp.obj', ' '.join(map(quoted, objects)))
    directory = out / ('link-' + stem); directory.mkdir()
    line = replace_one(line, ' --intdir=CMakeFiles' + chr(92) + test + '.dir', ' --intdir=' + quoted(directory))
    if config == 'Debug':
        line = replace_one(line, ' /INCREMENTAL ', ' /INCREMENTAL:NO ')
        line, count = re.subn(r'(?i)(?<![\w:])/debug(?=\s|$)', '/DEBUG:NONE', line); assert count == 1
    for flag, ext in (('/out:', '.exe'), ('/implib:', '.lib'), ('/pdb:', '.pdb')):
        line = replace_one(line, flag + test + ext, flag + quoted(out / (stem + ext)))
    return line


def main(out):
    if os.environ.get('VSCMD_ARG_TGT_ARCH') != 'x64':
        return subprocess.call([str(root/'tools/msvc_env.bat'), sys.executable, '-B', '-X', 'utf8', __file__, str(out)])
    shaders = here/'release/shaders'
    cache = root/'build/cache/vulkan'
    source_cache = cache/'vk1-10de-28e0-94d3c000-e5fd15ff5cca63387021a49388fd1dc4-33d51d00297b927c.azpc'
    assert source_cache.stat().st_size == 134212559
    fingerprint = hash_file(source_cache)
    result = {}
    for config in ('Debug', 'Release'):
        build = root/'build'/('ninja-msvc-' + config.lower())
        folder = out/config.lower(); folder.mkdir()
        object_path = fr'CMakeFiles\{test}.dir\tests\PipelineCacheStoreTests.cpp.obj'
        command = catalog(build, 'commands', '-s', object_path)
        command = replace_one(command, str(root/'tests/PipelineCacheStoreTests.cpp'), str(here/'pipeline_cache_cost.cpp'))
        obj = folder/(product + '.obj')
        command = replace_one(command, '/Fo' + object_path, '/Fo' + quoted(obj))
        command, count = re.subn(r'/Fd[^ ]+', lambda _: '/Fd' + quoted(folder/'compile.pdb'), command); assert count == 1
        with (folder/'build.log').open('xb') as log:
            subprocess.run(command, cwd=build, check=True, stdout=log, stderr=subprocess.STDOUT, timeout=75)
            subprocess.run(link(build, config, [obj], folder, product), cwd=build, check=True, stdout=log, stderr=subprocess.STDOUT, timeout=90)
        env = os.environ | {'PATH': os.pathsep.join((str(build), os.environ['PATH']))}
        rows = []
        for _ in range(2):
            row = subprocess.check_output([str(folder/(product+'.exe')), str(shaders), str(cache)], cwd=build, env=env, timeout=70, text=True).strip()
            print(config, row, flush=True); rows.append(row)
        result[config] = rows
    assert fingerprint == hash_file(source_cache)
    (out/'cost.json').write_text(json.dumps({'cacheSha256':fingerprint,'timings':result}, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main(Path(sys.argv[1]).resolve()))
