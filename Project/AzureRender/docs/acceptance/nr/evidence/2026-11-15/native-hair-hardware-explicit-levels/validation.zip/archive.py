"""Save two-adapter native hardware texture level comparisons."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile


root=Path(__file__).resolve().parent
target=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/native-hair-hardware-explicit-levels'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
base_file=root/'hair-native-owner-hardware-comparison.json'
source_file=root/'hair-native-owner-hardware-mips-comparison.json'
baseline=read(base_file)
report=read(source_file)
assert report['status']==baseline['status']=='qualified-native-ownership'
members={'comparison.json':source_file,'previous-controls.json':base_file,
         'capture.py':root/'hair-native-owner-control.py','archive.py':Path(__file__)}
checks=(
    ((1243,342),3,2),
    ((1322,263),2,1),
    ((1327,287),1,1),
    ((1333,312),2,2),
    ((1280,195),1,1),
)
for ordinal,(row,old,(point,nvidia,intel)) in enumerate(zip(report['points'],baseline['points'],checks,strict=True)):
    assert row['point']==old['point']==list(point)
    for name in ('primitive','nativeTargetAbsolute','packedLanes'):
        assert row[name]==old[name]
    for device,level in (('nvidia',nvidia),('intel',intel)):
        actual=row['matchingMips'][device]
        assert actual['normal']==actual['base']==[level] and level in actual['layer']
    if ordinal==1:
        assert row['matchingMips']['intel']['layer']==[0,1]
    assert len(row['explicitMips'])==36
for device in ('nvidia','intel'):
    folder=root/f'hair-native-owner-hardware-mips-{device}'
    raw=read(folder/'results.json')
    assert raw['status']=='qualified' and raw['device']==device and len(raw['hardwareLanes'])==41
    for name in ('results.json','request.json','replay.log'):
        members[f'{device}/{name}']=folder/name
target.mkdir(parents=True,exist_ok=True)
archive=target/'validation.zip'
with ZipFile(archive,'w',ZIP_DEFLATED) as output:
    for name,path in members.items():output.write(path,name)
with ZipFile(archive) as saved:
    assert saved.testzip() is None
    hashes={name:sha256(saved.read(name)).hexdigest() for name in members}
assert hashes=={name:digest(path) for name,path in members.items()}
report['archive']=dict(sha256=digest(archive),members=hashes)
report['testedPerDeviceShaderPrograms']=41
report['acceptance']='open-original-frozen-rgb'
(target/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(archive)
