"""Verify current Release packages before sealing their registered Windows results."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import sqlite3
import sys
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile


run = Path(__file__).resolve().parent
root = run.parents[2]
build = root / "build/ninja-msvc-release"
destination = root / "docs/acceptance/nr/evidence/2026-11-15/registered-cache-retention-packages"
sys.path.insert(0, str(root / "tools"))
from build_game import verify_package


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def main():
    prefix = run / "release-cache-retention-packages"
    ctest = read(prefix.with_suffix(".json"))
    assert ctest["status"] == "passed" and ctest["selectedTests"] == ctest["tests"] == 5
    proof = run / "release-products.json"
    assert ctest["provenanceChecked"]["products"] == digest(proof)
    assert ctest["provenanceChecked"]["junit"] == digest(prefix.with_suffix(".xml"))
    assert ctest["provenanceChecked"]["testNames"] == digest(prefix.with_suffix(".txt"))
    cases = {x.get("name"): x for x in ET.parse(prefix.with_suffix(".xml")).findall(".//testcase")}
    assert cases.keys() == set(prefix.with_suffix(".txt").read_text(encoding="utf-8").splitlines())
    assert all(case.find("failure") is None and case.find("skipped") is None for case in cases.values())
    accepted = read(proof)["products"][str(build / "AzurePlayer.exe")]
    assert accepted == digest(build / "AzurePlayer.exe")
    files = {"source/" + path.name: path for path in (Path(__file__), proof, prefix.with_suffix(".json"),
             prefix.with_suffix(".txt"), prefix.with_suffix(".xml"))}
    for lane in ("ordinary", "filesystem-fixtures"):
        for suffix in (".log", ".xml", ".txt"):
            path = run / (prefix.name + "-" + lane + suffix)
            files["source/" + path.name] = path
    packages = {}
    for directory, expected_name, extra in (("game-package", "Windows Game", ("editor-report.json", "player-report.json",
                                            "editor.log", "player.log", "failure-rollback.log")),
                                          ("playable-package", "Azure Exploration", ("cycles.summary.json", "cycles.log",
                                            "entry.log", "editor.log"))):
        out = build / directory
        evidence = out / "evidence"
        summary = read(evidence / "summary.json")
        assert summary["status"] == "passed"
        target = Path(summary["package"])
        assert target.name == expected_name and target.parent == out
        assert all(summary[key] for key in ("movedDirectory", "sourceUnavailable", "engineUnavailable", "tamperRejected"))
        assert "System32" in summary["isolatedPath"]
        assert digest(target / "bin/AzurePlayer.exe") == accepted
        manifest = verify_package(target)
        assert len(manifest["files"]) == summary["files"]
        files[directory + "/game_manifest.json"] = target / "game_manifest.json"
        files.update((directory + "/" + name, evidence / name) for name in ("summary.json", *extra))
        packages[directory] = dict(path=str(target), playerSha256=accepted, files=summary["files"],
                                   manifestSha256=digest(target / "game_manifest.json"))
        if directory == "playable-package":
            assert read(evidence / "cycles.summary.json") == summary["cycles"]
            assert summary["cycles"]["switches"] == summary["cycles"]["restarts"] == 20
            packages[directory]["moves"] = {"switches": 20, "restarts": 20}
    with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro", uri=True) as db:
        facts = db.execute("SELECT id,state,exit_code FROM jobs WHERE id IN (1001,1005) ORDER BY id").fetchall()
    assert facts == [(1001, "failed", 75), (1005, "succeeded", 0)]
    destination.mkdir()
    archive = destination / "verification.zip"
    hashes = {name: digest(path) for name, path in files.items()}
    with ZipFile(archive, "x", ZIP_DEFLATED, compresslevel=6) as out:
        for name, path in files.items():
            out.write(path, name)
    with ZipFile(archive) as out:
        assert set(out.namelist()) == hashes.keys() and out.testzip() is None
        assert all(sha256(out.read(name)).hexdigest() == value for name, value in hashes.items())
    receipt = dict(status="passed", tests={name: float(case.get("time")) for name,case in cases.items()},
                   packages=packages, dispatch=facts, archive=dict(sha256=digest(archive), files=hashes))
    (destination / "results.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print("Verified", len(cases), "registered tests and", len(packages), "packaged runtimes")


if __name__ == "__main__":
    main()
