"""Reproduce native body receiver raster positions with float32 viewport coordinates."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


root=Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
old=grid/'next-body-normal-decoder-model.py'
text=old.read_text(encoding='utf8')
prefix,separator,_=text.partition('\nresult=dict(samples=')
assert separator
state={'__file__':str(old)}
exec(compile(prefix,str(old),'exec'),state)
source=state['scope']
body,clip,xy,points,vertices,triangles=[source[name] for name in ('body','clip','xy','points','vertices','indices')]
ndc=clip[:,:2].astype(np.float32)/clip[:,3,None].astype(np.float32)
half=np.asarray([1280,720],np.float32)
ndc*=np.asarray([1,-1],np.float32)
grid_snap=lambda value:np.rint(value*256)/256
viewports={
    'doublePrecision':grid_snap(source['screen']),
    'float32SeparatelyRounded':grid_snap(ndc*half+half).astype(float),
}
inputs=state['raw']
levels={}
for mode in ('fractional','rounded'):
    textures=[]
    offset=128
    for level in range(11):
        width=max(1,1024>>level)
        size=max(1,(width+3)//4)**2*16
        textures.append(state['decode'](inputs[offset:offset+size],width,mode))
        offset+=size
    assert offset==len(inputs)
    levels[mode]=textures


def one_viewport(label,screen):
    selected,_,delta,other,_=source['locate'](screen)
    assert np.all(selected>=0),(label,np.unique(selected,return_counts=True))
    q=triangles[selected]
    raster=screen[q]
    a,b,c=raster.transpose(1,0,2)
    ab,ac=b-a,c-a
    area=ab[:,0]*ac[:,1]-ab[:,1]*ac[:,0]
    reference=np.column_stack((body[:,8]&1023,(body[:,8]>>10)&1023)).astype(np.int32)
    face=np.where(area<0,1.,-1.)
    state.update(a=a,ab=ab,ac=ac,det=area,inv_w=1/clip[q,3])
    interpolate=state['interpolate']
    frame=interpolate(points,vertices[q,9:16])
    normal,tangent=frame[:,:3],frame[:,3:6]
    bitangent=np.cross(normal,tangent)*frame[:,6:7]
    raw_uv=vertices[q,4:6]
    uv=interpolate(points,raw_uv)
    state.update(coordinates=uv,normal=normal,tangent=tangent,bitangent=bitangent)
    origin=(xy&~1)+.5
    around=[interpolate(origin+step,raw_uv) for step in ((0,0),(1,0),(0,1),(1,1))]
    dx=(around[1]-around[0])*1024
    dy=(around[2]-around[0])*1024
    footprint=state['footprint']
    distance=np.maximum(np.maximum(footprint(dx),footprint(dy)),11/16*np.maximum(footprint(dx+dy),footprint(dx-dy)))
    level=np.clip(np.floor(np.log2(distance)-.5),0,10).astype(int)
    summary={}
    for mode,storage in levels.items():
        packed=np.stack([state['pack'](state['sample'](asset,256),face) for asset in storage])
        errors=np.abs(packed-reference[None]).max(axis=2)
        estimated=packed[level,np.arange(len(level))]
        chosen=errors[level,np.arange(len(level))]
        good=delta<=1
        baseline_common=good&(state['selected'][:,4]<=1)
        saved=root/f'body-receiver-{label}-{mode}-estimated.bin'
        estimate=(estimated[:,0].astype(np.uint32)|(estimated[:,1].astype(np.uint32)<<10))
        estimate.astype('<u4').tofile(saved)
        summary[mode]=dict(attachmentSha256=sha256(saved.read_bytes()).hexdigest(),levels=np.bincount(level,minlength=11).tolist(),
            exact=int((chosen==0).sum()),withinOne=int((chosen<=1).sum()),differentOfOne=int((chosen==1).sum()),
            withinQualifiedDepth=dict(samples=int(good.sum()),exact=int((good&(chosen==0)).sum()),
                    withinOne=int((good&(chosen<=1)).sum())),
            commonDepth=dict(samples=int(baseline_common.sum()),exact=int((baseline_common&(chosen==0)).sum()),
                    withinOne=int((baseline_common&(chosen<=1)).sum())),
            exactAnyMip=int((errors.min(0)==0).sum()))
    record=dict(exactDepth=int((delta==0).sum()),withinOneUlp=int((delta<=1).sum()),withinTwoUlp=int((delta<=2).sum()),
                worseThanTwoUlp=int((delta>2).sum()),distinct=int((other>delta).sum()),models=summary)
    print(label,json.dumps(record),flush=True)
    return record


result={label:one_viewport(label,screen) for label,screen in viewports.items()}
assert result['doublePrecision']['withinOneUlp']==7997
assert result['float32SeparatelyRounded']['withinOneUlp']==8827
proof=dict(status='measured-viewport-body-receiver',scope=9116,notes='independent geometry and source normal filtering model',
           sourceGeometry=source['manifest']['vertexData']['rawSha256'],
           sourceIndices=source['manifest']['indexData']['rawSha256'],models=result)
(root/'body-receiver-viewport-normal.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
