"""Check body receiver shadow comparisons from retained depth, normals, and atlases."""
from hashlib import file_digest,sha256
from io import BytesIO
import itertools
import json
from pathlib import Path
import re
import subprocess
import zipfile

import numpy as np


root=Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
scope=root.parent/'20261112-213454-reference-raster-source-a825da/body'
numerics=root.parent/'20261112-053111-intel-reference-visibility-sources-5238e2'
calibration=root.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
shaders=root.parents[2]/'shaders'
read=lambda p:json.loads(p.read_bytes())
configuration=read(calibration/'receiver-calibration.json')
native_params=np.fromfile(numerics/'parameters.bin','<f4',count=52)
assert len(native_params)==52
matrix=native_params[:16].reshape(4,4)
reciprocal_extent=native_params[16:18]
offset=native_params[18:20]
record=native_params[24:52]
project=record[:16].reshape(4,4)
light,light_bias,normal_bias,filter_radius,floor_depth,rectangle=(
    record[16:19],record[19],record[20],record[21:23],record[23],record[24:28])
dims=np.array([4096,2048],dtype=np.int32)
assert configuration['atlasExtent']==dims.tolist()
assert tuple(reciprocal_extent)==tuple(np.float32(1)/np.array(configuration['extent'],np.float32))
low=np.ceil(rectangle[:2]*dims-.5).astype(int)
high=np.ceil((rectangle[:2]+rectangle[2:])*dims-.5).astype(int)
read_atlas=lambda path:np.fromfile(path,'<u2').reshape(dims[1],dims[0])
profile=Path(configuration['profile'])
if profile.is_file():
    codes=profile.read_bytes()
else:
    reference='Project/AzureRender/docs/acceptance/nr/evidence/2026-11-10/reciprocal-compact-profile/validation.zip'
    archived=subprocess.check_output(['git','show',f'HEAD:{reference}'],cwd=root.parents[2])
    with zipfile.ZipFile(BytesIO(archived)) as receipt:
        codes=receipt.read('correction.bin')
assert sha256(codes).hexdigest()=='bbda0d685ab5a66767c2c3881a67dff147e1f5a2c766db1f6dd5b63fecedcf2c'
arithmetic=np.frombuffer(codes,'<u4')
assert len(arithmetic)==(1<<19)
policy_text=(shaders/'screen_object_visibility.frag').read_text(encoding='utf8')
disk=np.array([int(i) for i in re.findall(r'\b(\d+)u\b',policy_text.split('const uvec4 disk[16]=')[1].split(';',1)[0])],
              dtype='<u4').view('<f4').reshape(16,4)
assert disk.shape==(16,4)


def hash_file(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def fma(a,b,c):
    return (np.asarray(a,dtype=np.float64)*np.asarray(b,dtype=np.float64)+c).astype(np.float32)


def reciprocal(value):
    bits=value.view('<u4')
    mantissa=bits&0x7fffff
    exponent=(bits>>23)&255
    code=(arithmetic[mantissa>>4]>>((mantissa&15)*2))&3
    assert np.all((exponent>0)&(exponent<=252)) and np.all(code<=2)
    normalized=(mantissa|0x3f800000).view('<f4')
    rounded=(np.float32(1)/normalized).view('<u4')
    rounded=(rounded+code-1)^(bits&0x80000000)
    return np.ldexp(rounded.view('<f4'),127-exponent.astype(np.int32))


def emulate(x,y,z,normals,atlas,atlas_forward):
    p=np.column_stack((x,y)).astype(np.float32)+offset
    ndc=fma(fma(p,reciprocal_extent,0),2,-1)
    clip=-ndc[:,1,None]*matrix[1]
    clip=fma(ndc[:,0,None],matrix[0],clip)
    clip=fma(z[:,None],matrix[2],clip)+matrix[3]
    world=clip[:,:3]*reciprocal(clip[:,3])[:,None]
    lanes=np.column_stack((normals&1023,(normals>>10)&1023)).astype(np.float32)/np.float32(1023)
    octa=fma(lanes,2,-1)
    normal=np.column_stack((octa[:,0],np.float32(1)-np.abs(octa).sum(1),octa[:,1]))
    folded=(np.float32(1)-np.abs(octa[:,::-1]))*np.where(octa>=0,np.float32(1),np.float32(-1))
    neg=normal[:,1]<0
    normal[neg,0],normal[neg,2]=folded[neg,0],folded[neg,1]
    normal*= (np.float32(1)/np.sqrt((normal*normal).sum(1)))[:,None]
    amount=np.float32(1)-np.clip((normal*light).sum(1),0,.9)
    biased=fma(-light,(amount*light_bias)[:,None],world)
    biased=fma(normal,(amount*normal_bias)[:,None],biased)
    q=fma(project[0,:3],biased[:,0,None],biased[:,1,None]*project[1,:3])
    q=fma(project[2,:3],biased[:,2,None],q)+project[3,:3]
    q[:,2]=np.maximum(q[:,2],floor_depth)
    uv=fma(q[:,:2],rectangle[2:],rectangle[:2])
    phase=((x&3)<<2)|(y&3)
    rotation=disk[phase,:2]
    count=np.zeros(len(x),dtype=np.float32)
    accumulator=np.zeros_like(count)
    for dx,dy in disk[:,2:]:
        rx=fma(dx,rotation[:,0],-dy*rotation[:,1])
        ry=fma(dy,rotation[:,0],dx*rotation[:,1])
        point=fma(np.column_stack((rx,ry)),filter_radius,uv)
        texel=point*dims.astype(np.float32)-.5
        base=np.floor(np.rint(texel*256)/256).astype(np.int32)
        levels=[]
        for shift in ((0,1),(1,1),(1,0),(0,0)):
            target=base+shift
            valid=(target>=low).all(1)&(target<high).all(1)
            taps=np.zeros(len(x),dtype=np.float32)
            h=atlas[target[valid,1],target[valid,0]].astype(np.float32)/np.float32(65535)
            taps[valid]=np.float32(1)-h if atlas_forward else h
            levels.append(taps-q[:,2])
        difference=np.column_stack(levels)
        active=difference>=0
        count+=active.sum(1).astype(np.float32)
        accumulator+=np.where(active,difference,0).sum(1)
    mask=(count>0)&(q[:,2]<1)&(q[:,:2]>0).all(1)&(q[:,:2]<1).all(1)
    safe=np.maximum(count,1)
    stages=fma(count,.03125,-1)
    sign=np.sign(stages)
    t=fma(-sign,stages,1)
    t2=t*t
    ratio=np.clip((np.float32(1)/q[:,2])*(accumulator/safe),0,1)
    adjusted=fma(ratio,fma(-t2,t,t),t2*t)
    fraction=np.where(mask,np.minimum(fma(-sign*(1-adjusted),.5,.5),1),1)
    return np.rint(255*fraction).astype(np.int16),count.astype(int),q


def summarized(error):
    return dict(peak=int(np.abs(error).max()),overOne=int((np.abs(error)>1).sum()),exact=int((error==0).sum()))


d3d_atlas=read_atlas(configuration['atlas'])
known=np.fromfile(scope/'nvidia-receiver.bin','<u4').reshape(49384,9)
body=known[:,7]==328
x,y=known[body,:2].astype(np.int32).T
ref=known[body,2].astype(np.int16)
native_depth=np.fromfile(configuration['depth'],'<f4').reshape(1440,2560)[y,x]
native_normals=np.fromfile(configuration['normals'],'<u4').reshape(1440,2560)[y,x]
assert np.array_equal(native_normals,known[body,8]) and len(x)==9116
native_render,native_taps,_=emulate(x,y,native_depth,native_normals,d3d_atlas,False)
native_agreement=summarized(native_render-ref)
print('native',native_agreement,flush=True)
results={}
atlas_manifest=read(numerics/'cross-device-live-atlas.json')
paths={'nvidia':root.parent/'20261112-041837-reference-object-shadow-raster-capture-60f161/atlas.bin',
       'intel':numerics/'atlas.bin'}
cases=tuple(itertools.product((False,True),repeat=3))
viewport=root/'body-receiver-viewport-normal.json'
viewport_models=read(viewport)['models'] if viewport.is_file() else {}
for device,atlas_path in paths.items():
    assert hash_file(atlas_path)==atlas_manifest[device]['sha256']
    atlas=read_atlas(atlas_path)
    folder=grid/f'release-{device}-frames'
    planes=read(folder/'reference-planes.json')
    with zipfile.ZipFile(folder/'reference-planes.zip') as archive:
        objects=[]
        for label,typ in (('reference-depth-r32.bin','<f4'),('reference-normals-a2b10g10r10.bin','<u4')):
            p=planes[label]
            raw=archive.read(p['archiveEntry'])
            assert sha256(raw).hexdigest()==p['sha256']
            objects.append(np.frombuffer(raw,typ).reshape(1440,2560)[y,x])
    depth,normals=objects
    actual=np.fromfile(scope/f'{device}-receiver.bin','<u4').reshape(49384,9)[body,3].astype(np.int16)
    values={}
    tap_counts={}
    metrics={}
    for d,n,a in cases:
        label=''.join(str(int(v)) for v in (d,n,a))
        test,taps,_=emulate(x,y,native_depth if d else depth,native_normals if n else normals,
                            d3d_atlas if a else atlas,not a)
        values[label]=test
        tap_counts[label]=taps
        metrics[label]=summarized(test-ref)
    estimated=values['000']
    baseline=summarized(estimated-actual)
    assert baseline['peak']<=1 and baseline['overOne']==0
    support=(np.abs(estimated-actual)<=1)
    failures=(np.abs(actual-ref)>1)&support
    points=[]
    unpack_normal=lambda p:np.column_stack((p&1023,(p>>10)&1023)).astype(int)
    differences=unpack_normal(normals)-unpack_normal(native_normals)
    for i in np.flatnonzero(failures):
        points.append(dict(point=[int(x[i]),int(y[i])],native=int(ref[i]),player=int(actual[i]),estimated=int(estimated[i]),
            depthExact=bool(depth[i]==native_depth[i]),normalExact=bool(np.all(differences[i]==0)),
            depthUlp=int(depth.view('<u4')[i])-int(native_depth.view('<u4')[i]),octNormalDelta=differences[i].tolist(),
            supportedCases={key:[int(t[i]),int(tap_counts[key][i])] for key,t in values.items()}))
    results[device]=dict(modelVsActual=baseline,cases=metrics,supportedFailurePoints=points,
                         depthExactAmongSupported=int(sum(p['depthExact'] for p in points)),
                         normalExactAmongSupported=int(sum(p['normalExact'] for p in points)))
    normal_models={}
    for label,observed in viewport_models.items():
        for mode,description in observed['models'].items():
            path=root/f'body-receiver-{label}-{mode}-estimated.bin'
            assert hash_file(path)==description['attachmentSha256']
            modeled=np.fromfile(path,'<u4')
            hypothetical,_,_=emulate(x,y,depth,modeled,atlas,True)
            owned,_,_=emulate(x,y,native_depth,modeled,d3d_atlas,False)
            error=np.abs(hypothetical-ref)
            normal_models[label+'-'+mode]=dict(retainedDepthAndAtlas=summarized(hypothetical-ref),
                originalDepthAndAtlas=summarized(owned-ref),newOverOne=int(((np.abs(actual-ref)<=1)&(error>1)).sum()))
    results[device]['modeledNormalInputs']=normal_models
    print(device,baseline,metrics,'supported failures',len(points),flush=True)
    print(device,normal_models,flush=True)
result=dict(status='modeled-body-visibility-operands',scope=9116,shader=hash_file(shaders/'screen_object_visibility.frag'),
    nativeAttachmentReplay=native_agreement,operands=['depth','octNormal','atlas'],devices=results)
(root/'body-receiver-physical-inputs.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
