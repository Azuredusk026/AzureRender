"""Save the verified body receiver operand experiment."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile


root=Path(__file__).resolve().parent
target=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/body-receiver-operands'
scope=root.parent/'20261112-213454-reference-raster-source-a825da/body'
calibration=root.parent/'20261110-003435-visibility-numeric-contract-4f95e7'
numerics=root.parent/'20261112-053111-intel-reference-visibility-sources-5238e2'
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
record=root/'body-receiver-physical-inputs.json'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
result=read(record)
assert result['status']=='modeled-body-visibility-operands' and result['scope']==9116
shader=root.parents[2]/'shaders/screen_object_visibility.frag'
assert digest(shader)==result['shader']
assert result['nativeAttachmentReplay']['overOne']==0
paths={
    'result.json':record,
    'model.py':root/'body-receiver-physical-inputs.py',
    'fragment.glsl':shader,
    'archive.py':Path(__file__),
    'calibration.json':calibration/'receiver-calibration.json',
    'atlas-sources.json':numerics/'cross-device-live-atlas.json',
    'parameters.bin':numerics/'parameters.bin',
}
viewport=root/'body-receiver-viewport-normal.json'
source=read(viewport)
assert source['scope']==9116 and source['status']=='measured-viewport-body-receiver'
assert source['models']['doublePrecision']['withinOneUlp']==7997
assert source['models']['float32SeparatelyRounded']['withinOneUlp']==8827
paths['viewport/model.py']=root/'body-receiver-viewport-normal.py'
paths['viewport/result.json']=viewport
for key,model in source['models'].items():
    for mode,summary in model['models'].items():
        filename=f'body-receiver-{key}-{mode}-estimated.bin'
        reference=root/filename
        assert summary['attachmentSha256']==digest(reference) and reference.stat().st_size==9116*4
        paths[f'viewport/{filename}']=reference
result['viewport']=source
for device,expectation in (('nvidia',(46,5,5,0)),('intel',(77,42,2,0))):
    data=result['devices'][device]
    assert len(data['supportedFailurePoints'])==expectation[0]
    assert data['modelVsActual']['overOne']==0
    assert tuple(data['cases'][case]['overOne'] for case in ('000','010','110','111'))==expectation
    paths[f'{device}/stored-attachments.json']=grid/f'release-{device}-frames/reference-planes.json'
    paths[f'{device}/original-capture-receipt.json']=scope/f'{device}-results.json'
result['originalAttachmentInputs']={}
setup=read(paths['calibration.json'])
for name in ('depth','normals','atlas','queries','expected'):
    location=Path(setup[name])
    result['originalAttachmentInputs'][name]=dict(path=str(location),sha256=digest(location))
target.mkdir(parents=True,exist_ok=True)
archive=target/'validation.zip'
with ZipFile(archive,'w',ZIP_DEFLATED) as output:
    for name,path in paths.items():output.write(path,name)
with ZipFile(archive) as saved:
    assert saved.testzip() is None
    hashes={name:sha256(saved.read(name)).hexdigest() for name in paths}
assert hashes=={name:digest(path) for name,path in paths.items()}
result['archive']=dict(sha256=digest(archive),members=hashes)
result['overallAcceptance']='open-production-receiver'
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(archive)
