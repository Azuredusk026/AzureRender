"""Reconstruct the native cloth environment weight and its Player deltas."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


root=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
path=root/'cloth-environment-source.json'
trace=read(path)
comparison=read(root/'cloth-environment-composition.json')
assert trace['status']=='qualified' and len(trace['points'])==3
assert comparison['nativeTraceSha256']==sha256(path.read_bytes()).hexdigest()
rows=[]
for point,measured in zip(trace['points'],comparison['witnesses'],strict=True):
    assert point['point']==measured['point']
    st=point['states']
    rgb=np.asarray(st['1621']['r18'][:3])
    material=np.asarray(st['1622']['r16'][:3])
    spec=np.asarray(st['1624']['r17'][1:4])
    n_dot_view=st['1622']['r12'][0]
    lobe=material*(1-n_dot_view)/n_dot_view*spec+spec
    assert np.abs(lobe-st['1625']['r16'][:3]).max()<1.e-6
    multiplier=st['1628']['r3'][3]
    tint=np.asarray(st['1629']['r15'][:3])
    native=lobe*multiplier*tint
    product=native*rgb*.25
    assert np.abs(product-measured['nativeExposedIndirect']).max()<1.e-7
    player_rgb=np.asarray(measured['player']['indirect-radiance'])
    player_response=np.asarray(measured['player']['indirect-response'])
    # Hold one operand fixed to quantify its effect at the same raster location.
    player_with_cube=player_response*rgb*.25
    player_with_lobe=native*player_rgb*.25
    direction=np.asarray(measured['nativeCubeDirection'])
    rows.append(dict(point=point['point'],NdotV=n_dot_view,faceReflectance=material.tolist(),baseLobe=spec.tolist(),
        nativeResponse=native.tolist(),nativeRadiance=rgb.tolist(),nativeReflection=direction.tolist(),
        playerResponse=player_response.tolist(),playerRadiance=player_rgb.tolist(),
        fixedEnvironmentWithPlayerResponse=player_with_cube.tolist(),fixedResponseWithPlayerEnvironment=player_with_lobe.tolist(),
        nativeExposedIndirect=product.tolist(),
        updateEnvironmentError=float(np.abs(product-player_with_cube).max()),
        updateResponseError=float(np.abs(product-player_with_lobe).max())))
assert all(.00<row['nativeResponse'][0]<.05 for row in rows)
report=dict(status='measured-independent-material-cube-operands',witnesses=rows)
(root/'cloth-environment-native-response.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print([(r['point'],r['nativeResponse'],r['updateEnvironmentError'],r['updateResponseError']) for r in rows])
