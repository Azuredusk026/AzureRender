from hashlib import sha256
from pathlib import Path
import json, os, struct, subprocess, traceback
import renderdoc as rd

out=Path(os.environ['AZURE_ENGINE_IRIS_MIP_REPLAY'])
request=json.loads((out/'request.json').read_bytes())
points=list(struct.iter_unpack('<II',Path(request['points']).read_bytes()))
shaders={key:value for key,value in json.loads(Path(request['catalog']).read_bytes()).items()}
record=dict(status='failed',events=[])
cap=rd.OpenCaptureFile()
controller=None
replacements=[]

def walk(actions):
    for a in actions:
        yield a
        yield from walk(a.children)

def compile_probe(rule,mode):
    sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
    source=Path(request['source'])
    assert sha256(source.read_bytes()).hexdigest()==request['sourceSha256']
    text=source.read_text()
    modes={
        'legacy-rim':'beautyColor+vec3(0.19533129,0.018207679,0.018207679)*(2.49*radianceScale*smoothstep(0.765,1.0,1.0-abs(dot(shadedNormal,viewDirection))))',
        'width-only':'beautyColor+vec3(0.19533129,0.018207679,0.018207679)*(2.49*radianceScale*smoothstep(0.235,1.0,1.0-abs(dot(shadedNormal,viewDirection))))',
        'signed-rim':'beautyColor+vec3(0.19533129,0.018207679,0.018207679)*(2.49*radianceScale*smoothstep(0.235,1.0,1.0-clamp(dot(shadedNormal,viewDirection),0.0,1.0)))',
        'facing':'vec3(clamp(dot(shadedNormal,viewDirection)*.5+.5,0,1))',
        'indirect-radiance':'sceneReflectionRadiance',
        'indirect-response':'sceneReflectionResponse',
        'indirect-product':'ambientSpecular',
        'reflect-vector':'reflectionDirection*.5+.5',
        'roughness':'vec3(roughness, material.styleParameters.z, dielectricSpecularWeight)'}
    marker='    vec3 qaColor = beautyColor;'
    assert text.count(marker)==1
    text=text.replace(marker, marker+'\n    if(AZURE_MATERIAL_CLASS==4U && AZURE_ALPHA_MODE==2) {outputColor=vec4('+modes[mode]+',1);return;}')
    path=out/f'mesh-{mode}.frag'; path.write_text(text)
    result=path.with_suffix('.spv')
    cmd=[str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+flag for flag in rule['defines']),'-I'+str(source.parent),str(path),'-o',str(result)]
    subprocess.run(cmd,check=True)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(result)],check=True)
    return result.read_bytes()

try:
    assert cap.OpenFile(request['capture'],'',None)==rd.ResultCode.Succeeded
    options=rd.ReplayOptions()
    options.forceGPUVendor=rd.GPUVendor.nVidia
    options.forceGPUDeviceID=0x28e0
    result,controller=cap.OpenCapture(options,None)
    assert result==rd.ResultCode.Succeeded and controller
    props=controller.GetAPIProperties()
    assert props.pipelineType==rd.GraphicsAPI.Vulkan and props.vendor==rd.GPUVendor.nVidia and not props.degraded
    desc={str(d.resourceId):d for d in controller.GetTextures()}
    for action in walk(controller.GetRootActions()):
        if not action.flags&rd.ActionFlags.Drawcall or action.numIndices!=10698 or action.eventId!=967:
            continue
        controller.SetFrameEvent(action.eventId,True)
        pipe=controller.GetPipelineState()
        ref=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
        if not ref:
            continue
        push=bytes(controller.GetVulkanPipelineState().pushconsts)
        raw=bytes(ref.rawBytes)
        digest=sha256(raw).hexdigest()
        targets=[slot.resource for slot in pipe.GetOutputTargets() if str(slot.resource) in desc]
        row=dict(event=action.eventId,shaderSha256=digest,names=[name for name,h in shaders.items() if h==digest],
            classAndFlags=push[112:128].hex(),targets=[dict(id=str(t),format=desc[str(t)].format.Name(),width=desc[str(t)].width,height=desc[str(t)].height) for t in targets])
        record['events'].append(row)
        name=next((n for n in row['names'] if n.startswith('mesh') and 'snapshot' not in n),None)
        if name is None or not targets:
            continue
        color=targets[0]; d=desc[str(color)]
        if (d.width,d.height)!=(2560,1440):
            continue
        rules=json.loads(Path(request['rules']).read_bytes())['programs']
        rule,=[p for p in rules if p['output']==name]
        original=pipe.GetShader(rd.ShaderStage.Fragment)
        row['shaderResource']=str(original)
        row['selection']={}
        def extract(label):
            controller.SetFrameEvent(action.eventId,True)
            payload=bytes(controller.GetTextureData(color,rd.Subresource()))
            assert len(payload)%(d.width*d.height)==0
            stride=len(payload)//(d.width*d.height)
            assert stride in (4,8,16)
            selected_digests={}
            for convention,coords in (('direct',points),('flipped',[(x,d.height-1-y) for x,y in points])):
                selected=b''.join(payload[(y*d.width+x)*stride:(y*d.width+x+1)*stride] for x,y in coords)
                (out/f"{action.eventId}-{label}-{convention}.bin").write_bytes(selected)
                selected_digests[convention]=sha256(selected).hexdigest()
            row['selection'][label]=dict(stride=stride,fullSha256=sha256(payload).hexdigest(),selectedSha256=selected_digests)
            return payload
        baseline=extract('baseline')
        modes=request.get('modes',["legacy-rim","width-only","signed-rim","facing"])
        for level in (None,*modes):
            code=raw if level is None else compile_probe(rule,level)
            replacement,errors=controller.BuildTargetShader(ref.entryPoint,rd.ShaderEncoding.SPIRV,code,rd.ShaderCompileFlags(),rd.ShaderStage.Fragment)
            assert replacement!=rd.ResourceId.Null(),errors
            replacements.append((original,replacement))
            controller.ReplaceResource(original,replacement)
            trial=extract('copy' if level is None else f'mip{level}')
            if level is None:
                assert trial==baseline
            controller.RemoveReplacement(original)
            controller.FreeTargetResource(replacement)
            replacements.pop()
        assert extract('restored')==baseline
    assert all(len([row for row in record['events'] if label in row.get('selection',{})])==1
        for label in ('baseline','copy','restored',*('mip'+mode for mode in modes)))
    record['status']='qualified'
except Exception:
    record['error']=traceback.format_exc()
finally:
    if controller:
        for original,replacement in replacements:
            controller.RemoveReplacement(original)
            controller.FreeTargetResource(replacement)
        controller.Shutdown()
    cap.Shutdown()
    (out/'results.json').write_text(json.dumps(record,indent=2)+'\n')
os._exit(0 if record['status']=='qualified' else 1)



