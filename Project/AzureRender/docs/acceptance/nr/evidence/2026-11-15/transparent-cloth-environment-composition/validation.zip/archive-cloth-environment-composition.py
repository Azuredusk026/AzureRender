"""Archive the transparent cloth environment composition receipts."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


here=Path(__file__).resolve().parent
output=here.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/transparent-cloth-environment-composition'
result=json.loads((here/'cloth-environment-composition.json').read_bytes())
assert result['status']=='measured-player-environment-lanes' and len(result['witnesses'])==3
assert all(row['shaderProductError']<2.5e-5 for row in result['witnesses'])
assert max(row['nativeIndirectError'] for row in result['witnesses'])>.016
members=['analyze-cloth-environment.py','archive-cloth-environment-composition.py',
         'cloth-native-light-lanes.json','cloth-environment-composition.json',
         'cloth-directional-rim-worker.py','cloth-environment-replay/request.json','cloth-environment-replay/results.json']
for lane in ('indirect-radiance','indirect-response','indirect-product','reflect-vector','roughness'):
    members.append(f'cloth-environment-replay/967-mip{lane}-direct.bin')
output.mkdir(parents=True,exist_ok=True)
path=output/'validation.zip'
with ZipFile(path,'w',ZIP_DEFLATED) as archive:
    for member in members:archive.write(here/member,member)
with ZipFile(path) as archive:
    assert archive.testzip() is None
    checksums={member:sha256(archive.read(member)).hexdigest() for member in members}
assert checksums=={member:sha256((here/member).read_bytes()).hexdigest() for member in members}
result['overallVisualAcceptance']='failed-user-review'
result['archive']=dict(sha256=sha256(path.read_bytes()).hexdigest(),members=checksums)
(output/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(result['archive']['sha256'])
