"""Compare the transparent cloth's sampled and composed environment lanes."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


root=Path(__file__).resolve().parent
replay=root/'cloth-environment-replay'
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda path:json.loads(path.read_bytes())
receipt=read(replay/'results.json')
assert receipt['status']=='qualified'
event,=[e for e in receipt['events'] if e['event']==967]
draw=event['selection']
assert draw['baseline']==draw['copy']==draw['restored']
source=read(root/'cloth-native-light-lanes.json')
assert source['status']=='qualified-native-lanes' and len(source['rows'])==3
request=read(replay/'request.json')
frozen_source=Path(request['source']).read_text()
assert 'ambientSpecular*=radianceScale;' in frozen_source
material=read(grid/'engine-cloth-components/request.json')
assert material['capture']==request['capture']
locations=np.fromfile(grid/'skin-residual-points.bin','<u4').reshape(-1,2)
lookup={tuple(point):i for i,point in enumerate(locations)}
assert len(lookup)==len(locations)


def samples(label):
    payload=(replay/f'967-mip{label}-direct.bin').read_bytes()
    assert sha256(payload).hexdigest()==draw['mip'+label]['selectedSha256']['direct']
    data=np.frombuffer(payload,'<f2').reshape(-1,4).astype(float)
    assert len(data)==len(locations)
    return data


modes=('indirect-radiance','indirect-response','indirect-product','reflect-vector','roughness')
lanes={label:samples(label) for label in modes}
rows=[]
for r in source['rows']:
    pos=tuple(r['point'])
    pixel=lookup[pos]
    raw={label:values[pixel,:3] for label,values in lanes.items()}
    assert all(values[pixel,3]==1 for values in lanes.values())
    assert all(np.isfinite(values).all() for values in raw.values())
    native=np.array(r['native']['indirectSpecular'])
    rgb=raw['indirect-product']
    product=raw['indirect-radiance']*raw['indirect-response']*.25
    assert np.abs(product-rgb).max()<4e-5
    assert np.array_equal(rgb,r['playerRawLanes']['environment'])
    rows.append(dict(point=r['point'],player={key:values.tolist() for key,values in raw.items()},
        nativeExposedIndirect=native.tolist(),playerExposedIndirect=rgb.tolist(),
        shaderProductError=float(np.abs(product-rgb).max()),
        nativeIndirectError=float(np.abs(rgb-native).max()),
        calculatedProduct=product.tolist()))
output=dict(status='measured-player-environment-lanes',sourceShader=event['shaderSha256'],
            originalRestored=draw['baseline']['fullSha256'],materialRadianceScale=.25,witnesses=rows)
(root/'cloth-environment-composition.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf8')
print([(row['point'],row['shaderProductError'],row['nativeIndirectError']) for row in rows])
