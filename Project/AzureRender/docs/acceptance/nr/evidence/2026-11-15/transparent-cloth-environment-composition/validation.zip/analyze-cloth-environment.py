"""Compare the transparent cloth's sampled and composed environment lanes."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


root=Path(__file__).resolve().parent
replay=root/'cloth-environment-replay'
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda path:json.loads(path.read_bytes())
receipt=read(replay/'results.json')
assert receipt['status']=='qualified'
event,=[e for e in receipt['events'] if e['event']==967]
draw=event['selection']
assert draw['baseline']==draw['copy']==draw['restored']
source=read(root/'cloth-native-light-lanes.json')
assert source['status']=='qualified-native-lanes' and len(source['rows'])==3
request=read(replay/'request.json')
assert request['sourceSha256']=='167177f8fd3a4ff84f9a9ba163ce7ef245c7cfb092ea1e76d0c957c801d4bfa8'
frozen_probe=(replay/'mesh-indirect-product.frag').read_text()
assert 'ambientSpecular*=radianceScale;' in frozen_probe
assert 'outputColor=vec4(ambientSpecular,1);return;' in frozen_probe
material=read(grid/'engine-cloth-components/request.json')
assert material['capture']==request['capture']
native_trace_path=root/'cloth-environment-source.json'
native_trace=read(native_trace_path)
assert native_trace['status']=='qualified'
cube=native_trace['textures']['22']
assert (cube['width'],cube['height'],cube['mips'],cube['slices'],cube['format'])==(128,128,8,6,'BC6_UFLOAT')
assert 't22' in native_trace['program']['1620']
native_states={tuple(row['point']):row['states'] for row in native_trace['points']}
locations=np.fromfile(grid/'skin-residual-points.bin','<u4').reshape(-1,2)
lookup={tuple(point):i for i,point in enumerate(locations)}
assert len(lookup)==len(locations)


def samples(label):
    payload=(replay/f'967-mip{label}-direct.bin').read_bytes()
    assert sha256(payload).hexdigest()==draw['mip'+label]['selectedSha256']['direct']
    data=np.frombuffer(payload,'<f2').reshape(-1,4).astype(float)
    assert len(data)==len(locations)
    return data


modes=('indirect-radiance','indirect-response','indirect-product','reflect-vector','roughness')
lanes={label:samples(label) for label in modes}
rows=[]
for r in source['rows']:
    pos=tuple(r['point'])
    pixel=lookup[pos]
    raw={label:values[pixel,:3] for label,values in lanes.items()}
    assert all(values[pixel,3]==1 for values in lanes.values())
    assert all(np.isfinite(values).all() for values in raw.values())
    native=np.array(r['native']['indirectSpecular'])
    state=native_states[pos]
    sampled=np.asarray(state['1621']['r18'][:3])
    response_product=np.asarray(state['1629']['r16'][:3])
    tint=np.asarray(state['1629']['r15'][:3])
    assert np.abs(response_product*tint*.25-native).max()<1e-7
    rgb=raw['indirect-product']
    product=raw['indirect-radiance']*raw['indirect-response']*.25
    assert np.abs(product-rgb).max()<4e-5
    assert np.array_equal(rgb,r['playerRawLanes']['environment'])
    rows.append(dict(point=r['point'],player={key:values.tolist() for key,values in raw.items()},
        nativeExposedIndirect=native.tolist(),playerExposedIndirect=rgb.tolist(),
        nativeCubeLod=state['1620']['r3'][3],nativeCubeSample=sampled.tolist(),
        nativeCubeDirection=state['1620']['r27'][:3],
        nativeTint=tint.tolist(),nativeResponseAndSample=response_product.tolist(),
        shaderProductError=float(np.abs(product-rgb).max()),
        nativeIndirectError=float(np.abs(rgb-native).max()),
        calculatedProduct=product.tolist()))
output=dict(status='measured-player-environment-lanes',sourceShader=event['shaderSha256'],
            nativeCube=cube,nativeTraceSha256=sha256(native_trace_path.read_bytes()).hexdigest(),
            originalRestored=draw['baseline']['fullSha256'],materialRadianceScale=.25,witnesses=rows)
(root/'cloth-environment-composition.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf8')
print([(row['point'],row['shaderProductError'],row['nativeIndirectError']) for row in rows])
