from hashlib import sha256
from pathlib import Path
import json
import math
import os
import re
import subprocess
import traceback

key='AZURE_NR_CLOTH_ENV_TRACE'
out=Path(os.environ[key]) if key in os.environ else Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')

def worker():
    import renderdoc as rd
    job=read(out/'cloth-environment-source-request.json')
    result=dict(status='failed',points=[],textures={})
    cap=rd.OpenCaptureFile();ctl=None
    try:
        assert cap.OpenFile(job['native'],'',None)==rd.ResultCode.Succeeded
        opts=rd.ReplayOptions();opts.forceGPUVendor=rd.GPUVendor.nVidia;opts.forceGPUDeviceID=0x28e0
        code,ctl=cap.OpenCapture(opts,None)
        assert code==rd.ResultCode.Succeeded and ctl
        info=ctl.GetAPIProperties()
        assert info.vendor==rd.GPUVendor.nVidia and not info.degraded and info.pipelineType==rd.GraphicsAPI.D3D11
        ctl.SetFrameEvent(1383,True)
        pipe=ctl.GetPipelineState();stage=rd.ShaderStage.Fragment
        shader=pipe.GetShaderReflection(stage)
        assert sha256(bytes(shader.rawBytes)).hexdigest()==job['shaderSha256']
        asm=ctl.DisassembleShader(pipe.GetGraphicsPipelineObject(),shader,'')
        (out/'cloth-environment-native-1383.asm').write_text(asm,encoding='utf8')
        programs={int(m.group(1)):m.group(2).strip() for m in re.finditer(r'^\s*(\d+):([^\r\n]+)',asm,re.M)}
        assert 1620 in programs and 1629 in programs
        result['program']={i:programs[i] for i in range(1598,1632) if i in programs}
        cube={int(i) for i in re.findall(r'dcl_resource_texturecube[^\r\n]*\bt(\d+)',asm,re.I)}
        assert cube,cube
        textures={str(t.resourceId):t for t in ctl.GetTextures()}
        for desc in pipe.GetReadOnlyResources(stage,False):
            slot=shader.readOnlyResources[desc.access.index].fixedBindNumber
            if slot not in cube:continue
            binding=desc.descriptor
            texture=textures[str(binding.resource)]
            result['textures'][slot]=dict(resource=str(binding.resource),width=texture.width,height=texture.height,
                mips=texture.mips,slices=texture.arraysize,firstMip=binding.firstMip,numMips=binding.numMips,
                format=texture.format.Name())
        assert set(result['textures'])==cube,(result['textures'],cube)
        for point in job['points']:
            x,y=point['x'],point['y'];ctl.SetFrameEvent(1383,True)
            args=rd.DebugPixelInputs();args.primitive=point['primitive']
            trace=ctl.DebugPixel(x,1439-y,args);assert trace and trace.debugger
            regs={};states={};count=0
            try:
                while True:
                    block=ctl.ContinueDebug(trace.debugger)
                    if not block:break
                    for step in block:
                        for change in step.changes:
                            v=change.after
                            if v.name:regs[v.name]=[n if math.isfinite(n) else None for n in list(v.value.f32v)[:4]]
                        i=int(step.nextInstruction)
                        if 1598<=i<=1640:states[i]=dict(regs)
                        count+=1
                    assert count<20000
            finally:ctl.FreeTrace(trace)
            assert all(i in states for i in (1620,1629)),[x,y,sorted(states)]
            result['points'].append(dict(point=[x,y],states=states,primitive=point['primitive'],steps=count))
        result['status']='qualified'
    except Exception:result['error']=traceback.format_exc()
    finally:
        if ctl:ctl.Shutdown()
        cap.Shutdown()
        write(out/'cloth-environment-source.json',result)
    os._exit(0 if result['status']=='qualified' else 1)

def launch():
    from hashlib import file_digest
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==out
    job=read(grid/'native-face-masks/request.json')
    with Path(job['native']).open('rb') as f:assert file_digest(f,'sha256').hexdigest()==job['captureSha256']
    job['points']=[row for row in read(grid/'native-face-cloth-full-trace/results.json')['samples'] if row['event']==1383]
    assert len(job['points'])==3
    job['shaderSha256']=read(grid/'native-face-skin-stages/results.json')['geometry']['1383']['pixelShaderSha256']
    write(out/'cloth-environment-source-request.json',job)
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    with (out/'cloth-environment-source.log').open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__))],
            cwd=out,env=dict(os.environ,**{key:str(out)}),stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=210)
    result=read(out/'cloth-environment-source.json')
    assert child.returncode==0 and result['status']=='qualified',result.get('error')

if key in os.environ:worker()
elif __name__=='__main__':launch()

