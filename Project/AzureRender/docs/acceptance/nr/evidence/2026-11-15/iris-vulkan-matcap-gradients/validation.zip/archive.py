"""Retain the exact Vulkan gradient cases and their native correspondence."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile


root=Path(__file__).resolve().parent
peer=root.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
target=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/iris-vulkan-matcap-gradients'
render=root/'iris-vulkan-footprint-nvidia-matcap'
check=root/'iris-matcap-vulkan-gradient-agreement.json'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
result=read(check)
replay=read(render/'results.json')
assert result['status']=='measured-player-iris-gradients'
assert replay['status']=='qualified' and replay['copyControlExact'] and replay['baselineRestored']
assert result['summary']['nvidia']['matcap']['allMatches']==252
assert result['summary']['nvidia']['matcapGradFine']['allMatches']==250
assert result['primaryPoint']['point']==[1262,257]
assert result['primaryPoint']['implicit'][3]==0 and result['primaryPoint']['fine'][3]>.062
files={
    'readback/results.json':render/'results.json',
    'readback/request.json':render/'request.json',
    'readback/progress.json':render/'progress.json',
    'readback/iris-vulkan-footprint.py':peer/'iris-vulkan-footprint.py',
    'fit/score.py':peer/'score-iris-matcap.py',
    'fit/score.json':root/'iris-matcap-score.json',
    'fit/agreement.py':root/'iris-matcap-vulkan-gradient-agreement.py',
    'fit/agreement.json':check,
    'fit/native-levels.json':root/'iris-native-matcap-d3d-vulkan-owned-levels.json',
    'archive.py':Path(__file__),
}
assert all(path.is_file() for path in files.values())
assert digest(files['readback/results.json'])==result['sourceCaptureSha256']['results.json']
target.mkdir(parents=True,exist_ok=True)
archive=target/'validation.zip'
with ZipFile(archive,'w',ZIP_DEFLATED) as output:
    for name,path in files.items():output.write(path,name)
with ZipFile(archive) as saved:
    assert saved.testzip() is None
    hashes={name:sha256(saved.read(name)).hexdigest() for name in files}
assert hashes=={name:digest(path) for name,path in files.items()}
result['archive']=dict(sha256=digest(archive),members=hashes)
result['acceptance']='open-original-rgb'
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(archive)
