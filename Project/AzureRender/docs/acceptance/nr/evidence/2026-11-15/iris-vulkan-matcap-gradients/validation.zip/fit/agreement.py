"""Compare NVIDIA Player MatCap gradients with both native D3D references."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


root=Path(__file__).resolve().parent
native_path=root/'iris-native-matcap-d3d-vulkan-owned-levels.json'
readback_path=root/'iris-vulkan-footprint-nvidia-matcap/results.json'
score_path=root/'iris-matcap-score.json'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
native,readback,score=map(read,(native_path,readback_path,score_path))
assert readback['status']=='qualified' and readback['copyControlExact'] and readback['baselineRestored']
assert score['status']=='measured-iris-matcap' and all(score['nativeTextureLevelsIdentical'])
points=[tuple(p) for p in readback['points']]
assert len(points)==len(set(points))==255 and set(points)=={tuple(p) for p in native['points']}
order={tuple(p):i for i,p in enumerate(native['points'])}
samples=readback['diagnostics']
names=('matcap','matcapGradCoarse','matcapGradFine')
runs={name:np.asarray(samples[name]['rows']) for name in names}
assert np.array_equal(runs['matcap'],runs['matcapGradCoarse'])
explicit=np.asarray([samples[f'matcapLevel{i}']['rows'] for i in range(9)])
assert explicit.shape==(9,255,4)
assert np.array_equal(explicit[0],explicit[1])
# The retained sampler has a bias of -1. The rendered implicit sample must
# agree with its queried authored level after the explicit argument is shifted.
authored_lookup=np.maximum(np.arange(9)-1,0)
footprint={name:np.max(np.abs(candidate[None,:,:]-explicit),axis=2)==0 for name,candidate in runs.items()}
levels={name:[sorted({int(x) for x in authored_lookup[found]}) for found in result.T]
        for name,result in footprint.items()}
query=np.asarray(samples['matcapLod']['rows'])[:,0].astype(int)
assert all(allocation in matches for allocation,matches in zip(query,levels['matcap']))
seam={tuple(p) for p in native['commonLevelSevenPoints']}
summary={}
for device in ('nvidia','intel'):
    native_rows=native['nativeHardware'][device]['rows']
    expected=[native_rows[order[p]] for p in points]
    mode_results={}
    for name,rows in levels.items():
        hits=[bool(set(a)&set(b)) for a,b in zip(rows,expected)]
        mode_results[name]=dict(allMatches=sum(hits),commonSeamMatches=sum(hit for hit,p in zip(hits,points) if p in seam),
            missing=[list(p) for p,hit in zip(points,hits) if not hit])
    common=[i for i,p in enumerate(points) if p in seam]
    assert all(7 in levels['matcap'][i] or 7 in levels['matcapGradFine'][i] for i in common)
    summary[device]=mode_results
nvidia=summary['nvidia']
assert nvidia['matcap']['allMatches']==252 and nvidia['matcapGradFine']['allMatches']==250
assert all(stats['commonSeamMatches']==19 for stats in nvidia.values())
index=points.index((1262,257))
native_rgba=np.asarray(score['witnesses'][0]['nativeRgba'])
assert np.max(np.abs(native_rgba-runs['matcapGradFine'][index]))<.000002
rows=[]
for i,point in enumerate(points):
    if any(levels[name][i]!=levels['matcap'][i] for name in names):
        rows.append(dict(point=list(point),queryLod=query[i].item(),
            original=levels['matcap'][i],fine=levels['matcapGradFine'][i],
            native={device:native['nativeHardware'][device]['rows'][order[point]] for device in ('nvidia','intel')}))
report=dict(status='measured-player-iris-gradients',referenceComparison='native D3D texture level',
    sourceCaptureSha256={p.name:digest(p) for p in (native_path,readback_path,score_path)},summary=summary,
    nonEquivalentFootprints=rows,primaryPoint=dict(point=list(points[index]),
        implicit=runs['matcap'][index].tolist(),fine=runs['matcapGradFine'][index].tolist(),native=native_rgba.tolist(),
        uvDifference=score['witnesses'][0]['maxUvError'],nativeSourceSubstitutionPeak=score['witnesses'][0]['maxBeautyLinearDelta']))
(root/'iris-matcap-vulkan-gradient-agreement.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(summary=summary,primaryPoint=report['primaryPoint'])))
