"""Measure coordinate, mip selection and final color for iris MatCap."""
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import struct

import numpy as np
from PIL import Image


root=Path(__file__).resolve().parent
matcap_run=root.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e'
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
body=root.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
read=lambda p:json.loads(p.read_bytes())
native_file=matcap_run/'trace-iris-matcap-inputs.json'
vulkan_file=matcap_run/'iris-vulkan-footprint-nvidia-matcap/results.json'
native=read(native_file)
vulkan=read(vulkan_file)
assert native['status']==vulkan['status']=='qualified'
assert vulkan['copyControlExact'] and vulkan['baselineRestored']
assert read(vulkan_file.with_name('request.json'))['matcapDiagnostics']
eye=read(body/'eye-native-public-nvidia-projected/face-iris-public-main-frame.azurematerial')
mat=eye['surface']['materials'][0]
profile=mat['extras']['azureRenderMaterial']['eyeSurface']
image_index=eye['surface']['textures'][profile['matcapTexture']]['source']
texture=eye['textures'][str(image_index)]['asset']
path=grid/'iris-overlay-geometry-project/materials'/f'{texture}.dds'
dds=path.read_bytes()
assert struct.unpack_from('<2I',dds,12)==(256,256) and struct.unpack_from('<I',dds,128)[0]==99
assert native['texture']['format']=='BC7_SRGB'
start=148
levels=[]
exact=[]
for i,(level,desc) in enumerate(native['texture']['levels'].items()):
    assert int(level)==i and desc['width']==max(1,256>>i)
    expected=(matcap_run/desc['path']).read_bytes()
    assert sha256(expected).hexdigest()==desc['sha256']
    size=desc['bytes']
    exact.append(dds[start:start+size]==expected)
    header=bytearray(dds[:148])
    struct.pack_into('<3I',header,12,desc['width'],desc['width'],size)
    struct.pack_into('<I',header,28,1)
    with Image.open(BytesIO(header+expected)) as decoded:
        tile=np.asarray(decoded.convert('RGBA'),dtype=float)/255
        srgb=tile[:,:,:3]
        tile[:,:,:3]=np.where(srgb<=.04045,srgb/12.92,((srgb+.055)/1.055)**2.4)
        levels.append(tile)
    start+=size
assert start==len(dds) and len(levels)==9
assert struct.unpack_from('<f',(root/'iris-native-846-cb1.bin').read_bytes(),26*16)[0]==-1


def sample(texture,uv):
    dimension=len(texture)
    continuous=np.asarray(uv)*dimension-.5
    x,y=np.floor(continuous).astype(int)
    fx,fy=continuous-(x,y)
    x0,x1=np.clip((x,x+1),0,dimension-1)
    y0,y1=np.clip((y,y+1),0,dimension-1)
    return (1-fy)*((1-fx)*texture[y0,x0]+fx*texture[y0,x1])+fy*((1-fx)*texture[y1,x0]+fx*texture[y1,x1])


diagnostics=vulkan['diagnostics']
locations={tuple(point):index for index,point in enumerate(vulkan['points'])}
report=dict(status='measured-iris-matcap',nativeTextureLevelsIdentical=exact,
    nativeTraceSha256=sha256(native_file.read_bytes()).hexdigest(),
    vulkanReadbackSha256=sha256(vulkan_file.read_bytes()).hexdigest(),
    playerTextureSha256=sha256(dds).hexdigest(),witnesses=[])
for row in native['points']:
    index=locations[tuple(row['point'])]
    lane=lambda key:np.asarray(diagnostics[key]['rows'][index])
    native_uv=np.asarray(row['samples']['462']['r6'][:2])
    native_rgba=np.asarray(row['samples']['463']['r6'])
    player_uv=(lane('matcapUV')[:2]+lane('matcapUV')[2:])/16
    player_rgba=lane('matcap')
    lod=lane('matcapLod')[:2].tolist()
    reconstructed=[sample(tex,native_uv) for tex in levels]
    native_errors=[float(np.abs(r-native_rgba).max()) for r in reconstructed]
    player_errors=[float(np.abs(lane(f'matcapLevel{i}')-player_rgba).max()) for i in range(9)]
    gradients=lane('matcapRawGradient')/32
    player_sample_gradient_errors={key:float(np.abs(lane(key)-player_rgba).max())
                                   for key in ('matcapGradCoarse','matcapGradFine')}
    lod_argument=int(np.argmin(player_errors))
    authored_lod=max(lod_argument-1,0)
    assert authored_lod==int(lod[0]),(row['point'],lod,lod_argument)
    observed=lane('observed')[:3]
    corrected=lane('matcapNativeOnly')[:3]
    report['witnesses'].append(dict(point=row['point'],nativeUv=native_uv.tolist(),playerUv=player_uv.tolist(),
        maxUvError=float(np.abs(native_uv-player_uv).max()), nativeRgba=native_rgba.tolist(),
        playerRgba=player_rgba.tolist(),nativeAuthoredMipErrors=native_errors,playerExplicitMipErrors=player_errors,
        playerQueryLod=lod,playerCoarseGradient=gradients.tolist(),playerSampleGradientErrors=player_sample_gradient_errors,
        nativeNearestMip=int(np.argmin(native_errors)),playerNearestMip=authored_lod,playerExplicitLodArgument=lod_argument,
        beautyBefore=observed.tolist(),beautyNativeSample=corrected.tolist(),
        maxBeautyLinearDelta=float(np.abs(corrected-observed).max())))
assert all(min(r['nativeAuthoredMipErrors'])<.003 for r in report['witnesses']),report
assert [r['nativeNearestMip'] for r in report['witnesses']]==[7,4,4]
(matcap_run/'iris-matcap-score.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(report))
