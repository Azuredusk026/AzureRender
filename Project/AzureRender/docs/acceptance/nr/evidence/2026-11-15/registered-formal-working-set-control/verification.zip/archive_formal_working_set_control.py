"""Seal the fifteen-round reference with the unmodified working-set gate."""
import csv
from hashlib import sha256
import json
from pathlib import Path
import re
import sqlite3
from zipfile import ZipFile, ZIP_DEFLATED


run = Path(__file__).resolve().parent
root = run.parents[2]
formal = run/'formal'
target = root/'docs/acceptance/nr/evidence/2026-11-15/registered-formal-working-set-control'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def main():
    verified = read(formal/'summary.json')
    assert not verified['passed'] and verified['budgets']['stableWorkingSetGrowth'] == .05
    assert list(verified['rounds']) == ['standard','editor','stress','exploration','platformer']
    receipt = read(run/'formal-runtime-provenance.json')
    assert all(verified['products'][item]==value for item,value in receipt['products'].items())
    raw_gpu = ('memory.json','environment.json','json','csv','stderr.log','stdout.log','input.json')
    files = {f'formal/{name}':formal/name for name in ('summary.json','frozen-inputs.json')}
    candidates = ('archive_formal_working_set_control.py','formal-command.json','formal-runtime-provenance.json',
                  'previous-runtime-manifest-sha256.txt','cooling-control-preflight.json','fan-ready.json','fan-restored.json',
                  'power-policy-before.json','power-policy-observations.json','power-policy-ready.json','power-policy-restored.json',
                  'prepare_max_fan_replay.py','run_max_fan_measurement.ps1','run_balanced_epp_measurement.ps1')
    files.update({name:run/name for name in candidates})
    report = {}
    for load,runs in verified['rounds'].items():
        assert len(runs) == 3
        detected=[]
        for i,case in enumerate(runs,1):
            assert case['warmup']==300 and case['samples']==1800 and not case['passed']
            assert [failure.split(':')[0] for failure in case['budgetFailures']]==['stableWorkingSetGrowth']
            key = f'{load}-{i}'
            anchor = formal/key
            files.update({f'formal/{key}.{name}':anchor.with_suffix('.'+name) for name in raw_gpu})
            if load=='editor':
                files[f'formal/{key}.editor.json'] = anchor.with_suffix('.editor.json')
            memory = read(anchor.with_suffix('.memory.json'))
            assert len(memory)>=10
            end = memory[len(memory)//2:]
            peak = max(end,key=lambda v:v['working'])
            reproduced = peak['working']/end[0]['working']-1
            assert reproduced == case['stableWorkingSetGrowth']
            assert memory[-1]['seconds']-peak['seconds'] < 1.0
            with anchor.with_suffix('.csv').open() as stream:
                assert list(map(int,(row['frame'] for row in csv.DictReader(stream))))==list(range(1,2101))
            lines = anchor.with_suffix('.stderr.log').read_text(encoding='utf-8',errors='replace')
            loaded = re.search(r'Pipeline cache loaded: bytes=(\d+), state=loaded',lines)
            saved = re.search(r'Pipeline cache saved: bytes=(\d+), state=stored, requests=(\d+), hits=(\d+), feedback=(\d+)',lines)
            assert loaded and saved
            data = list(map(int,saved.groups()))
            detected.append(dict(workingSetGrowth=reproduced, peakWorkingBytes=peak['working'],
                                 stableStartWorkingBytes=end[0]['working'], secondsFromPeakToLastObservation=memory[-1]['seconds']-peak['seconds'],
                                 gpuP95Ms=case['gpu']['p95'],cpuP95Ms=case['cpu']['p95'],
                                 loadedCacheBytes=int(loaded[1]),writtenCacheBytes=data[0],pipelineRequests=data[1],
                                 pipelineHits=data[2],validFeedback=data[3]))
        report[load]=detected
    before = read(run/'power-policy-before.json')
    restored = read(run/'power-policy-restored.json')
    fan = read(run/'fan-restored.json')
    assert before['original']==restored['active'] and before['values']==restored['values']
    assert fan['automatic'] and fan['balanced'] and not fan['maximum']
    runtime = root/'build/ninja-msvc-release/build-provenance.json'
    assert digest(runtime)==(run/'previous-runtime-manifest-sha256.txt').read_text().strip()
    with sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True) as queue:
        db = queue.execute('select id,state,exit_code from jobs where id=986').fetchone()
    assert db==(986,'failed',1)
    target.mkdir()
    zip_path = target/'verification.zip'
    hashes = {name:digest(path) for name,path in files.items()}
    with ZipFile(zip_path,'w',compression=ZIP_DEFLATED,compresslevel=6) as archive:
        for name,path in files.items():
            archive.write(path,name)
    with ZipFile(zip_path) as archive:
        assert set(archive.namelist())==hashes.keys() and archive.testzip() is None
        assert all(sha256(archive.read(name)).hexdigest()==expected for name,expected in hashes.items())
    data = dict(status='stable-working-set-gate-failed',sourceCommit=verified['sourceCommit'],passed=0,rounds=15,
                workloads=report,dispatch=db,restoredPowerPlan=restored,restoredFan=fan,
                archive=dict(sha256=digest(zip_path),files=hashes))
    (target/'results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Verified source, 15 original rounds and',len(hashes),'archive members',zip_path.stat().st_size)


if __name__=='__main__':
    main()
