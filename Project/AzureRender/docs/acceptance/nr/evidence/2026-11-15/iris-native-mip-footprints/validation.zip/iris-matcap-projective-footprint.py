"""Check reconstruction of bottom-row / left-column iris MatCap gradients."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


root=Path(__file__).resolve().parent
model=root/'iris-matcap-native-quad-model.py'
state={'__file__':str(model)}
exec(compile(model.read_text(encoding='utf-8-sig').split('\nresults={device:',1)[0],str(model),'exec'),state)
view,normal_scale,inputs,read,manifest,points=[state[k] for k in ('view','normal_scale','input_geometry','read','source','points')]
quads=read(root/'iris-matcap-native-quad-model.json')


def matcap(values):
    uv=values[:,0:2]
    normal=values[:,2:5]
    tangent=values[:,5:8]
    sign=values[:,8:9]
    radial=(uv-np.floor(uv))*np.float32(2)-np.float32(1)
    depth=np.sqrt(np.maximum(np.float32(1)-np.sum(radial*radial,axis=1),np.float32(0)))
    local=radial*-np.float32(normal_scale)
    bitangent=np.cross(normal,tangent)*sign
    world=tangent*local[:,0:1]+bitangent*local[:,1:2]+normal*depth[:,None]
    eye=world@view.astype(np.float32)
    return eye[:,0:2]*(np.float32(.5)/np.sqrt(np.sum(eye*eye,axis=1)))[:,None]+np.float32(.5)


records={}
for label,fields in manifest['devices'].items():
    layout,triangles=inputs(label,fields['geometry'])
    position,attrs=layout[0],np.column_stack([layout[i] for i in (1,3,4)]).astype(float)
    ndc=position[:,:2]/position[:,3:4]
    viewport=np.asarray([1280,720],np.float32)
    locations=(np.rint((ndc+1)*viewport*256)/256).astype(float)
    inverse_w=1.0/position[:,3].astype(float)
    audit=quads['devices'][label]['points']
    result=[]
    for point,row in zip(points,audit):
        assert row['point']==list(point)
        ids=triangles[row['triangle']]
        a,b,c=locations[ids]
        x,y=np.asarray(point,dtype=np.int32)
        offsets=np.asarray([(0,0),(1,0),(0,1),(1,1)])
        lanes=np.array([x&~1,y&~1])+offsets+.5
        columns=np.column_stack([b-a,c-a])
        weights=(lanes-a)@np.linalg.inv(columns).T
        weights=np.column_stack([1-weights.sum(1),weights])
        reciprocal=weights@inverse_w[ids]
        vary=(weights@(attrs[ids]*inverse_w[ids,None]))/reciprocal[:,None]
        payload=(vary.astype(np.float32)*reciprocal.astype(np.float32)[:,None])
        homogeneous=np.column_stack((payload,reciprocal.astype(np.float32)))
        iy,ix=y&1,x&1
        index=2*iy+ix
        dx=homogeneous[2*iy+1]-homogeneous[2*iy]
        dy=homogeneous[ix+2]-homogeneous[ix]
        reconstructed=homogeneous[index]+(offsets[:,0:1]-ix).astype(np.float32)*dx+(offsets[:,1:2]-iy).astype(np.float32)*dy
        predicted=matcap(reconstructed[:,:9]/reconstructed[:,9:10])
        direct=matcap(vary.astype(np.float32))
        gradients=np.stack((predicted[3]-predicted[2],predicted[2]-predicted[0]))
        truth=np.asarray(row['modes']['coarseBottomLeft']['gradient'])
        rho=np.linalg.norm(gradients,axis=1).max()*256
        level=int(np.clip(np.floor(np.log2(max(rho,1e-12))-.5),0,8))
        result.append(dict(point=list(point),level=level,native=row['expectedLevel'],matches=level in row['expectedLevel'],
            agreesDouble=level==row['modes']['coarseBottomLeft']['level'],matcapError=float(np.abs(direct-predicted).max()),
            gradientError=float(np.abs(truth-gradients).max())))
    maximum=max(row['matcapError'] for row in result)
    exact=sum(row['agreesDouble'] for row in result)
    native=sum(row['matches'] for row in result)
    records[label]=dict(matcapPeakCoordinateError=maximum,mipMatchesAnalytic=exact,actualNativeMipMatches=native,rows=result)
    assert exact>=254 and maximum<.001,(label,maximum,exact)
    print(label,maximum,exact,native,flush=True)
proof=dict(status='measured-projective-matcap-reconstruction',scope=len(points),devices=records,
    geometryModelSha256=sha256((root/'iris-matcap-native-quad-model.json').read_bytes()).hexdigest())
(root/'iris-matcap-projective-footprint.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')

