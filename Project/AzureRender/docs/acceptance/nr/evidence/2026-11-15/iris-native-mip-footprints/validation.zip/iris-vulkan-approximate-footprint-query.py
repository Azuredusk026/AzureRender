"""Compare Vulkan MatCap mip selection with the native texture footprint models."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


def axis_approximation(gradient):
    components = np.abs(gradient)
    return components.max(axis=1) + (11 / 32) * components.min(axis=1)


def score(source, native):
    raw = source.read_bytes()
    replay = json.loads(raw)
    assert replay['status'] == 'qualified'
    assert replay['device'] == 'nvidia' and replay['copyControlExact'] and replay['baselineRestored']
    points = replay['points']
    assert points == native['points'] and len(points) == len({tuple(point) for point in points}) == 255
    diagnostic = replay['diagnostics']
    raw_gradient = diagnostic['matcapRawGradient']
    query_lod = diagnostic['matcapLod']
    footprint = np.asarray(raw_gradient['rows']).reshape(-1, 2, 2) / 32
    query = np.asarray(query_lod['rows'])[:, :2]
    actual = query[:, 0].astype('i4')
    assert np.isfinite(footprint).all() and np.isfinite(query).all()
    assert np.array_equal(query[:, 0], actual) and actual.min() >= 0 and actual.max() <= 8
    dx, dy = footprint.transpose(1, 0, 2)
    axes = np.maximum(axis_approximation(dx), axis_approximation(dy))
    diagonals = (11 / 16) * np.maximum(axis_approximation(dx + dy), axis_approximation(dx - dy))
    measures = {
        'euclidean': np.maximum(np.linalg.norm(dx, axis=1), np.linalg.norm(dy, axis=1)),
        'diagonal': np.maximum(axes, diagonals),
    }
    selected = {}
    for name, footprint_measure in measures.items():
        lods = np.log2(np.maximum(footprint_measure * 256, 1.e-12)) - 1
        levels = np.clip(np.floor(lods + .5), 0, 8).astype('i4')
        matches = levels == actual
        selected[name] = {
            'matches': int(matches.sum()),
            'mismatches': [
                dict(point=points[index], hardware=int(actual[index]), computed=int(levels[index]),
                     hardwareLod=float(query[index, 1]), proposedLod=float(lods[index]))
                for index in np.flatnonzero(~matches)
            ],
        }
    return dict(source=sha256(raw).hexdigest(),
                programs={key: diagnostic[key]['shaderSha256'] for key in ('matcapRawGradient', 'matcapLod')},
                attachments={key: diagnostic[key]['attachmentSha256'] for key in ('matcapRawGradient', 'matcapLod')},
                levels=selected)


def main():
    run = Path(__file__).resolve().parent
    other = run.parent / '20261114-135148-face-receiver-diagnostics-7509b1'
    nvidia = run / 'iris-vulkan-footprint-nvidia-matcap/results.json'
    intel = other / 'iris-vulkan-footprint-intel/results.json'
    native = json.loads((run / 'iris-native-matcap-d3d-vulkan-owned-levels.json').read_bytes())
    comparison = score(nvidia, native)
    intel_raw = intel.read_bytes()
    replay = json.loads(intel_raw)
    assert replay['status'] == 'failed' and replay['device'] == 'intel'
    assert 'VK_EXT_depth_bias_control' in replay['error']
    result = dict(status='measured-vulkan-iris-query-lod-compared', points=255,
        devices=dict(nvidia=comparison,
            intel=dict(status='unsupported-capture-extension', extension='VK_EXT_depth_bias_control',
                       source=sha256(intel_raw).hexdigest())))
    (run / 'iris-vulkan-approximate-footprint-query.json').write_text(
        json.dumps(result, indent=2) + '\n', encoding='utf8')
    print({name: value['matches'] for name, value in comparison['levels'].items()}, flush=True)


if __name__ == '__main__':
    main()
