"""Separate ideal iris mip thresholds from measured adapter selection."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


run=Path(__file__).resolve().parent
read=lambda path:json.loads(path.read_bytes())
gradient_file=run/'iris-matcap-hardware-lod-derivatives.json'
quad_file=run/'iris-matcap-native-quad-model.json'
gradient=read(gradient_file)
quad=read(quad_file)
raw=read(run/'iris-native-matcap-coordinates/results.json')
assert gradient['status']=='measured-hardware-picker-derivatives'

def lod(length):
    return np.clip(np.floor(np.log2(np.maximum(length*256,1.e-12))-.5),0,8).astype('i4')


reports={}
for adapter,device in quad['devices'].items():
    points=np.asarray([row['point'] for row in device['points']])
    coarse=np.asarray([row['modes']['coarseBottomLeft']['gradient'] for row in device['points']])
    fine=np.asarray([row['modes']['fine']['gradient'] for row in device['points']])
    native=[set(row['expectedLevel']) for row in device['points']]
    expected=gradient['devices'][adapter]['samples']['coarse-largestEuclidean']
    theory_footprint=expected['distances']
    holdout=(points[:,0]+2*points[:,1])%7>=4
    vec=lambda a:np.max(np.linalg.norm(a,axis=-1),axis=1)
    component=lambda a:np.max(np.abs(a),axis=(1,2))
    sqrt_eigenvalue=np.linalg.svd(coarse,compute_uv=False)[:,0]
    dx,dy=coarse[:,0],coarse[:,1]
    diag=lambda g:np.abs(g).max(axis=1)+11/32*np.abs(g).min(axis=1)
    def diagonal(x,y):
        cardinal=np.maximum(diag(x),diag(y))
        crossing=(11/16)*np.maximum(diag(x+y),diag(x-y))
        return np.maximum(cardinal,crossing)
    magnitudes=np.stack([np.asarray(raw['devices'][adapter]['cases'][axis+'-coarse']['values'])
                         for axis in ('x','y')],axis=1)
    precise_signs=magnitudes*np.sign(coarse)
    projected_max=diagonal(dx,dy)
    rules={
        'native-readback-euclidean':np.asarray(theory_footprint)/256,
        'coarse-axis-length':vec(coarse),
        'coarse-axis-component':component(coarse),
        'coarse-axis-manhattan':np.abs(coarse).sum(axis=2).max(axis=1),
        'coarse-ellipse-major-axis':sqrt_eigenvalue,
        'coarse-diagonal-footprint':projected_max,
        'hardware-magnitude-with-analytic-sign':diagonal(precise_signs[:,0],precise_signs[:,1]),
        'fine-axis-length':vec(fine),
    }
    totals={}
    for name,rho in rules.items():
        result=lod(rho)
        fits=np.asarray([level in permitted for level,permitted in zip(result,native)])
        totals[name]=dict(calibration=int((fits&~holdout).sum()),holdout=int((fits&holdout).sum()),
            total=int(fits.sum()),matchesSeam=int(sum(fit and allowed=={7} for fit,allowed in zip(fits,native))))
    discrepancies=[]
    for pos,row in enumerate(device['points']):
        implied=expected['chosen'][pos]
        if implied in native[pos]:continue
        factor=expected['distances'][pos]
        interval=np.asarray([factor*.985,factor*1.015],dtype=float)/256
        inferred=lod(interval).tolist()
        first_error=abs(np.log2(factor)-.5-np.rint(np.log2(factor)-.5))
        discrepancies.append(dict(point=row['point'],hardware=sorted(native[pos]),coarseReadbackLevel=implied,
            readbackRangeAtOneAndHalfPercent=inferred,nearestBoundaryLogDistance=float(first_error),
            coarseAnalytic=coarse[pos].tolist(),fineAnalytic=fine[pos].tolist()))
    reports[adapter]=dict(holdoutPoints=int(holdout.sum()),mipModels=totals,hardwareDiscrepancies=discrepancies)
    print(adapter,totals,[(q['point'],q['hardware'],q['coarseReadbackLevel'],q['readbackRangeAtOneAndHalfPercent'])
                          for q in discrepancies],flush=True)
proof=dict(status='measured-native-iris-mip-footprint-methods',inputShaders=dict(gradient=sha256(gradient_file.read_bytes()).hexdigest(),
    quad=sha256(quad_file.read_bytes()).hexdigest()),deviceResults=reports)
assert reports['nvidia']['mipModels']['coarse-diagonal-footprint']['total']==255
assert reports['intel']['mipModels']['coarse-axis-length']['total']==255
(run/'iris-native-coarse-threshold-alternatives.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')

