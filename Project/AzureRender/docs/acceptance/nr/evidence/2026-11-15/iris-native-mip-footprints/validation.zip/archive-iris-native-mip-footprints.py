from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile

run=Path(__file__).resolve().parent
read=lambda name:json.loads((run/name).read_bytes())
match=read('iris-native-coarse-threshold-alternatives.json')
model=read('iris-matcap-projective-footprint.json')
differential=read('iris-matcap-hardware-lod-derivatives.json')
assert match['status']=='measured-native-iris-mip-footprint-methods'
assert model['status']=='measured-projective-matcap-reconstruction'
assert model['scope']==255
selected={'nvidia':'coarse-diagonal-footprint','intel':'coarse-axis-length'}
devices={}
for adapter,rule in selected.items():
    sample=match['deviceResults'][adapter]
    assert sample['holdoutPoints']==112
    evidence=sample['mipModels'][rule]
    assert evidence==dict(calibration=143,holdout=112,total=255,matchesSeam=20)
    assert model['devices'][adapter]['mipMatchesAnalytic']==255
    unique=differential['devices'][adapter]['samples']['coarse-largestEuclidean']['uniquePoints']
    devices[adapter]=dict(rule=rule,matchingSamples=evidence,uniqueLevels=unique,
        projectiveCoordinateError=model['devices'][adapter]['matcapPeakCoordinateError'])
assert match['deviceResults']['nvidia']['mipModels']['hardware-magnitude-with-analytic-sign']['total']==255
output=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/iris-native-mip-footprints'
output.mkdir(parents=True,exist_ok=True)
destination=output/'validation.zip'
query=read('iris-vulkan-approximate-footprint-query.json')
assert query['status']=='measured-vulkan-iris-query-lod-compared' and query['points']==255
assert query['devices']['nvidia']['levels']['euclidean']['matches']==242
assert query['devices']['nvidia']['levels']['diagonal']['matches']==255
assert query['devices']['intel']['extension']=='VK_EXT_depth_bias_control'
names=['archive-iris-native-mip-footprints.py','iris-native-coarse-threshold-alternatives.py',
       'iris-native-coarse-threshold-alternatives.json','iris-matcap-projective-footprint.py',
       'iris-matcap-projective-footprint.json','iris-vulkan-approximate-footprint-query.py',
       'iris-vulkan-approximate-footprint-query.json','iris-native-matcap-d3d-vulkan-owned-levels.json',
       'iris-vulkan-footprint-nvidia-matcap/request.json','iris-vulkan-footprint-nvidia-matcap/results.json']
members={name:run/name for name in names}
intel='iris-vulkan-footprint-intel/results.json'
members[intel]=run.parent/'20261114-135148-face-receiver-diagnostics-7509b1'/intel
assert query['devices']['nvidia']['source']==sha256(members[names[-1]].read_bytes()).hexdigest()
assert query['devices']['intel']['source']==sha256(members[intel].read_bytes()).hexdigest()
with ZipFile(destination,'w',ZIP_DEFLATED) as archive:
    for name,path in members.items():archive.write(path,name)
with ZipFile(destination) as archive:
    assert archive.testzip() is None
    hashes={name:sha256(archive.read(name)).hexdigest() for name in members}
assert hashes=={name:sha256(path.read_bytes()).hexdigest() for name,path in members.items()}
report=dict(status='measured-native-iris-mip-footprint-equivalence',overall='failed-user-review',
    sourcePrograms=match['inputShaders'],scope=255,devices=devices,
    vulkanQuery=dict(nvidiaMatches={name:result['matches'] for name,result in query['devices']['nvidia']['levels'].items()},
                     intelReplay=query['devices']['intel']['status']),
    archive=dict(sha256=sha256(destination.read_bytes()).hexdigest(),members=hashes))
(output/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(devices,flush=True)

