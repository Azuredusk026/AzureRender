from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile

run=Path(__file__).resolve().parent
read=lambda name:json.loads((run/name).read_bytes())
match=read('iris-native-coarse-threshold-alternatives.json')
model=read('iris-matcap-projective-footprint.json')
differential=read('iris-matcap-hardware-lod-derivatives.json')
assert match['status']=='measured-native-iris-mip-footprint-methods'
assert model['status']=='measured-projective-matcap-reconstruction'
assert model['scope']==255
selected={'nvidia':'coarse-diagonal-footprint','intel':'coarse-axis-length'}
devices={}
for adapter,rule in selected.items():
    sample=match['deviceResults'][adapter]
    assert sample['holdoutPoints']==112
    evidence=sample['mipModels'][rule]
    assert evidence==dict(calibration=143,holdout=112,total=255,matchesSeam=20)
    assert model['devices'][adapter]['mipMatchesAnalytic']==255
    unique=differential['devices'][adapter]['samples']['coarse-largestEuclidean']['uniquePoints']
    devices[adapter]=dict(rule=rule,matchingSamples=evidence,uniqueLevels=unique,
        projectiveCoordinateError=model['devices'][adapter]['matcapPeakCoordinateError'])
assert match['deviceResults']['nvidia']['mipModels']['hardware-magnitude-with-analytic-sign']['total']==255
output=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/iris-native-mip-footprints'
output.mkdir(parents=True,exist_ok=True)
destination=output/'validation.zip'
names=['archive-iris-native-mip-footprints.py','iris-native-coarse-threshold-alternatives.py',
       'iris-native-coarse-threshold-alternatives.json','iris-matcap-projective-footprint.py',
       'iris-matcap-projective-footprint.json']
with ZipFile(destination,'w',ZIP_DEFLATED) as archive:
    for name in names:archive.write(run/name,name)
with ZipFile(destination) as archive:
    assert archive.testzip() is None
    hashes={name:sha256(archive.read(name)).hexdigest() for name in names}
assert hashes=={name:sha256((run/name).read_bytes()).hexdigest() for name in names}
report=dict(status='measured-native-iris-mip-footprint-equivalence',overall='failed-user-review',
    sourcePrograms=match['inputShaders'],scope=255,devices=devices,
    archive=dict(sha256=sha256(destination.read_bytes()).hexdigest(),members=hashes))
(output/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(devices,flush=True)

