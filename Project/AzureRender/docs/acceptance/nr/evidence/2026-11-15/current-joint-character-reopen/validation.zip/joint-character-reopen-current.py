"""Check the persisted joint-motion project with the current Player."""
from hashlib import file_digest
from pathlib import Path
import json
import runpy
import sys

import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
reference=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-012115-joint-scene-dynamics-e9e4e1')
utility=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read,invoke=(utility[k] for k in ('read','invoke'))
lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==run
build=run/'msaa-release'
player=build/'AzurePlayer.exe'
def hash_file(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()

product=hash_file(player)
assert product=='1a30d925a674ddb1d95876cb80181106a0217e12a7228a35b5980b134954cb69'
historic=read(reference/'joint-reopen-verification.json')
saved=read(reference/'joint-motion-loop-v2-capture.json')
name='joint-character-reopen-current'
out=run/name
if out.exists():
    assert not (out/'results.json').is_file()
    out.rename(run/(name+'-interrupted-'+str(len(list(run.glob(name+'-interrupted-*')))+1)))
out.mkdir()
cmd=saved['command'].copy()
cmd[0]=str(player)
for flag,value in (('--capture-frames',4),('--capture-dir',out/'frames'),('--runtime-report',out/'runtime.json')):
    cmd[cmd.index(flag)+1]=str(value)
cmd.extend(('--resource-root',str(build)))
actual=invoke('nvidia',cmd,out)
caps=read(actual/'gpu_capabilities.json')
manifest=read(actual/'capture_manifest.json')
runtime=read(out/'runtime.json')
assert len(runtime['animations'])==historic['animationInstances']==11
assert not runtime['scriptErrors'] and not runtime['presentationErrors']
assert manifest['screenReflectionHistoryValid'] and manifest['capturedFrames']==4
assert len(list(actual.glob('frame_*.png')))==4
def as_image(path):
    with Image.open(path) as image:
        return np.asarray(image.convert('RGB'),dtype='i2')
frames=[]
for frame in historic['frames']:
    stem=frame['frame']
    ref=reference/'joint-motion-reopen/frames'/stem
    assert hash_file(ref)==frame['reopenSha256']==frame['firstSha256']
    delta=np.abs(as_image(ref)-as_image(actual/stem)).max(2)
    frames.append(dict(frame=stem,sha256=hash_file(actual/stem),
        originalReopenSha256=frame['reopenSha256'],differingPixels=int((delta>0).sum()),
        overOne=int((delta>1).sum()),peak=int(delta.max())))
assert len({r['sha256'] for r in frames})==4
result=dict(status='current-persisted-project-reopens',nativeContinuousVisualAcceptance='pending',
    historicalDriverUnqualified=True,projectSha256=hash_file(Path(cmd[cmd.index('--project')+1])),
    playerSha256=product,device=caps['device_name'],driverVersion=caps['driver_version'],
    animationInstances=len(runtime['animations']),frames=frames)
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
