"""Match the native mip selected in hardware to recorded MatCap derivatives."""
from hashlib import sha256
import json
from pathlib import Path
import struct

import numpy as np


root=Path(__file__).resolve().parent
coord_path=root/'iris-native-matcap-coordinates/results.json'
levels_path=root/'iris-native-matcap-d3d-vulkan-owned-levels.json'
sampler_path=root/'iris-native-846-samplers.json'
read=lambda p:json.loads(p.read_bytes())
hash_file=lambda p:sha256(p.read_bytes()).hexdigest()
capture,levels,samplers=map(read,(coord_path,levels_path,sampler_path))
assert capture['status']=='qualified'
assert levels['status']=='measured-matcap-level-selection'
assert capture['coordinates']==levels['points']
assert samplers['0']==dict(minify='FilterMode.Linear',magnify='FilterMode.Linear',mip='FilterMode.Point',
                          address=['AddressMode.ClampEdge','AddressMode.ClampEdge'],bias=0.0,
                          minimum=0.0,maximum=1000.0,anisotropy=0.0)
stage=root.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
bias=struct.unpack_from('<f',(stage/'iris-native-846-cb1.bin').read_bytes(),26*16)[0]
assert bias==-1
points=np.asarray(capture['coordinates'])
shared={tuple(x) for x in levels['commonLevelSevenPoints']}
seam=np.asarray([tuple(p) in shared for p in points])
assert int(seam.sum())==20 and len(points)==255


def nearest(rho):
    return np.clip(np.floor(np.log2(np.maximum(rho,1e-12))+bias+.5),0,8).astype(np.int16)


summaries={}
for device,native in capture['devices'].items():
    assert native['baselineRestored']
    expected=levels['nativeHardware'][device]['rows']
    unique=np.asarray([v[0] if len(v)==1 else -1 for v in expected])
    cases=native['cases']
    resulting={}
    for policy in ('coarse','fine'):
        dx=np.asarray(cases['x-'+policy]['values'])*256
        dy=np.asarray(cases['y-'+policy]['values'])*256
        rho={name:np.maximum(metric(dx),metric(dy)) for name,metric in (
            ('largestEuclidean',lambda v:np.linalg.norm(v,axis=1)),
            ('largestComponent',lambda v:v.max(1)),
            ('largestManhattan',lambda v:v.sum(1)),
        )}
        for metric,dist in rho.items():
            chosen=nearest(dist)
            matches=np.asarray([int(level) in allowed for level,allowed in zip(chosen,expected)])
            result=dict(allMatches=int(matches.sum()),uniqueMatches=int((matches&(unique>=0)).sum()),
                        uniquePoints=int((unique>=0).sum()),sharedLevelSevenMatches=int(matches[seam].sum()),
                        distances=dist.tolist(),chosen=chosen.tolist(),mismatches=points[~matches].tolist())
            resulting[policy+'-'+metric]=result
    order=sorted(resulting, key=lambda name:(-resulting[name]['allMatches'],-resulting[name]['sharedLevelSevenMatches'],name))
    diagnostics=[]
    for point in ((1262,257),(1260,262),(1302,265)):
        index,=np.flatnonzero((points==point).all(1))
        diagnostics.append(dict(point=list(point),hardware=expected[index],
            derivativeMagnitude={name:row['values'][index] for name,row in cases.items() if name[0] in ('x','y')},
            policy={name:int(resulting[name]['chosen'][index]) for name in order}))
    summaries[device]=dict(samples=resulting,preference=order,controls=diagnostics)
    print(device,[(name,resulting[name]['allMatches'],resulting[name]['sharedLevelSevenMatches']) for name in order])
    print(json.dumps(diagnostics))
report=dict(status='measured-hardware-picker-derivatives',textureResolution=[256,256],shaderBias=bias,
    inputHashes={p.name:hash_file(p) for p in (coord_path,levels_path,sampler_path)},devices=summaries)
(root/'iris-matcap-hardware-lod-derivatives.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
