"""Read native iris MatCap coordinates and derivative magnitudes from D3D11."""
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import traceback

key='AZURE_NR_D3D_IRIS_COORDINATES'
root=Path(os.environ[key]).parent if key in os.environ else Path(__file__).resolve().parent
folder=root/'iris-native-matcap-coordinates'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')


def worker():
    import renderdoc as rd
    job=read(folder/'request.json')
    sys.path.insert(0,job['utilities'])
    from dxbc_util import checksum,chunks,dest,imm,inst,instructions,opcode,opcodes,rebuild,source,words

    def variant(raw,case):
        assert checksum(raw)==raw[4:20]
        parts=chunks(raw)
        section,=[i for i,p in enumerate(parts) if p[0] in (b'SHEX',b'SHDR')]
        program=words(parts[section][1])
        temp=source_at=return_at=None
        for _,at,op,size in instructions(program):
            if op==opcode('DCL_TEMPS'):
                temp=program[at+1]
                assert temp==30
                program[at+1]+=1
            elif op==opcode('SAMPLE_B'):
                command=program[at:at+size]
                if command[-6]==14:
                    assert source_at is None and command[-2:]==[1,26]
                    source_at=at
            elif op==opcode('RET'):
                assert return_at is None
                return_at=at
        assert None not in (temp,source_at,return_at)
        values=[]
        for channel in range(2):
            if case=='uv':
                values+=inst('MOV',dest(temp,1<<channel),source(6,channel))
            else:
                axis,accuracy=case
                target=dest(temp,1<<channel)
                argument=source(6,channel)
                derivative=opcodes['D3D11_SB_OPCODE_DERIV_RT'+axis+'_'+accuracy]
                values+=[derivative|((1+len(target)+len(argument))<<24),*target,*argument]
                values+=inst('MUL',target,source(temp,channel),source(temp,channel))
        values+=inst('MOV',dest(temp,4),imm(0))
        out=sum((inst('MOV',dest(0,1<<i,True),source(temp,i)) for i in range(3)),[])
        program[return_at:return_at]=out
        program[source_at:source_at]=values
        program[1]=len(program)
        parts[section]=(parts[section][0],struct.pack('<{}I'.format(len(program)),*program),*parts[section][2:])
        return rebuild(raw,parts)

    def decode(values):
        result=[]
        for shift,precision in ((0,6),(11,6)):
            packed=(values>>shift)&((1<<(5+precision))-1)
            exponent=packed>>precision
            mantissa=packed&((1<<precision)-1)
            value=math.ldexp(mantissa,-14-precision) if exponent==0 else math.ldexp(1+mantissa/(1<<precision),exponent-15)
            result.append(value)
        return result

    capture=rd.OpenCaptureFile()
    result=dict(status='failed',devices={})
    try:
        assert capture.OpenFile(job['capture'],'',None)==rd.ResultCode.Succeeded
        points=list(struct.iter_unpack('<II',Path(job['points']).read_bytes()))
        assert len(points)==255
        result['coordinates']=points
        offsets=[((1439-y)*2560+x)*4 for x,y in points]
        for tag,vendor,device in [('nvidia',rd.GPUVendor.nVidia,0x28e0),('intel',rd.GPUVendor.Intel,0xa788)]:
            options=rd.ReplayOptions()
            options.forceGPUVendor=vendor
            options.forceGPUDeviceID=device
            status,ctl=capture.OpenCapture(options,None)
            assert status==rd.ResultCode.Succeeded and ctl
            try:
                properties=ctl.GetAPIProperties()
                assert properties.pipelineType==rd.GraphicsAPI.D3D11 and properties.vendor==vendor and not properties.degraded
                ctl.SetFrameEvent(846,True)
                pipe=ctl.GetPipelineState()
                shader=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
                raw=bytes(shader.rawBytes)
                assert sha256(raw).hexdigest()==job['pixelShaderSha256']
                vertex=pipe.GetShaderReflection(rd.ShaderStage.Vertex)
                mesh=ctl.GetPostVSData(0,0,rd.MeshDataStage.VSOut)
                vertices=bytes(ctl.GetBufferData(mesh.vertexResourceId,mesh.vertexByteOffset,0))
                indexes=bytes(ctl.GetBufferData(mesh.indexResourceId,mesh.indexByteOffset,mesh.numIndices*mesh.indexByteStride))
                assert len(vertices)%mesh.vertexByteStride==0
                assert len(indexes)==mesh.numIndices*mesh.indexByteStride
                (folder/f'{tag}-vertices.bin').write_bytes(vertices)
                (folder/f'{tag}-indices.bin').write_bytes(indexes)
                geometry=dict(vertexStride=int(mesh.vertexByteStride),indexStride=int(mesh.indexByteStride),
                    baseVertex=int(mesh.baseVertex),vertexBytes=len(vertices),indexBytes=len(indexes),
                    verticesSha256=sha256(vertices).hexdigest(),indicesSha256=sha256(indexes).hexdigest(),
                    signature=[dict(name=l.semanticIdxName,components=int(l.compCount),type=int(l.varType),
                                    register=int(l.regIndex),systemValue=str(l.systemValue))
                               for l in vertex.outputSignature])
                original=pipe.GetShader(rd.ShaderStage.Fragment)
                target=pipe.GetOutputTargets()[0].resource
                assert str(target)=='ResourceId::141976'
                def attachment():
                    ctl.SetFrameEvent(846,True)
                    data=bytes(ctl.GetTextureData(target,rd.Subresource()))
                    assert len(data)==2560*1440*4
                    return data
                baseline=attachment()
                cases={}
                for case in ('copy','uv',('X','COARSE'),('Y','COARSE'),('X','FINE'),('Y','FINE')):
                    label=case if isinstance(case,str) else '-'.join(case).lower()
                    write(folder/'progress.json',dict(device=tag,case=label,captured=list(cases)))
                    program=raw if label=='copy' else variant(raw,case)
                    patch,error=ctl.BuildTargetShader('main',rd.ShaderEncoding.DXBC,program,rd.ShaderCompileFlags(),rd.ShaderStage.Fragment)
                    assert patch!=rd.ResourceId.Null(),error
                    ctl.ReplaceResource(original,patch)
                    try:
                        data=attachment()
                    finally:
                        ctl.RemoveReplacement(original)
                        ctl.FreeTargetResource(patch)
                    assert (data==baseline)==(label=='copy')
                    rows=[decode(struct.unpack_from('<I',data,offset)[0]) for offset in offsets]
                    if not isinstance(case,str):
                        rows=[[math.sqrt(value) for value in row] for row in rows]
                    cases[label]=dict(shaderSha256=sha256(program).hexdigest(),targetSha256=sha256(data).hexdigest(),values=rows)
                assert attachment()==baseline
                result['devices'][tag]=dict(cases=cases,geometry=geometry,baselineRestored=True)
            finally:
                ctl.Shutdown()
        result['status']='qualified'
    except Exception:
        result['error']=traceback.format_exc()
    finally:
        capture.Shutdown()
        write(folder/'results.json',result)
    os._exit(0 if result['status']=='qualified' else 1)


def launch():
    from hashlib import file_digest
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==root
    job=read(root/'iris-native-matcap-footprint/request.json')
    assert read(root/'iris-native-matcap-footprint/results.json')['status']=='qualified'
    with Path(job['capture']).open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==job['captureSha256']
    if folder.exists():
        assert not (folder/'results.json').is_file() or read(folder/'results.json')['status']!='qualified'
        folder.rename(folder.with_name(folder.name+'-interrupted-'+str(len(list(root.glob(folder.name+'-interrupted-*')))+1)))
    folder.mkdir()
    write(folder/'request.json',job)
    startup=subprocess.STARTUPINFO()
    startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=0
    with (folder/'replay.log').open('wb') as log:
        ret=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=folder,env=dict(os.environ,**{key:str(folder)}),stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=160)
    result=read(folder/'results.json')
    assert ret.returncode==0 and result['status']=='qualified',result.get('error')


if key in os.environ:
    try:
        worker()
    except BaseException:
        write(folder/'worker-error.json',dict(error=traceback.format_exc()))
        os._exit(1)
elif __name__=='__main__':
    launch()
