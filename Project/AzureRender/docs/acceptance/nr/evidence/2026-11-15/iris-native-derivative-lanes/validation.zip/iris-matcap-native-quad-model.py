"""Predict iris MatCap gradients from the native post-vertex triangle quads."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


root=Path(__file__).resolve().parent
diagnostics=root.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
capture=root/'iris-native-matcap-coordinates/results.json'
level_reference=root/'iris-native-matcap-d3d-vulkan-owned-levels.json'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
source=read(capture)
levels=read(level_reference)
assert source['status']=='qualified' and source['coordinates']==levels['points']
points=[tuple(row) for row in source['coordinates']]
assert len(points)==255
seam={tuple(row) for row in levels['commonLevelSevenPoints']}
assert len(seam)==20
cb0=np.fromfile(diagnostics/'iris-native-846-cb0.bin','<f4').reshape(-1,4)
cb6=np.fromfile(diagnostics/'iris-native-846-cb6.bin','<f4').reshape(-1,4)
view=cb0[:3,:3].astype(float)
normal_scale=float(cb6[17,1])


def input_geometry(device,geometry):
    vertex_path=capture.parent/f'{device}-vertices.bin'
    index_path=capture.parent/f'{device}-indices.bin'
    assert digest(vertex_path)==geometry['verticesSha256'] and digest(index_path)==geometry['indicesSha256']
    assert geometry['vertexStride']%4==0
    data=np.fromfile(vertex_path,'<f4').reshape(-1,geometry['vertexStride']//4)
    index_dtype={2:'<u2',4:'<u4'}[geometry['indexStride']]
    indices=np.fromfile(index_path,index_dtype).reshape(-1,3).astype(int)+geometry['baseVertex']
    assert indices.min()>=0 and indices.max()<len(data)
    signature=geometry['signature']
    assert sum(row['components'] for row in signature)==data.shape[1],signature
    offset=0
    layout={}
    for row in signature:
        size=row['components']
        layout[row['register']]=data[:,offset:offset+size]
        offset+=size
    assert [layout[reg].shape[1] for reg in (0,1,3,4)]==[4,2,3,4],signature
    return layout,indices


def solve(device,native,expected):
    layout,indices=input_geometry(device,native['geometry'])
    xform=layout[0]
    ndc=xform[:,:3]/xform[:,3,None]
    viewport=np.array([1280,720],dtype=np.float32)
    positions=(np.rint((ndc[:,:2]+1)*viewport*256)/256).astype(float)
    a,b,c=positions[indices].transpose(1,0,2)
    ux,uy=(b-a).T
    vx,vy=(c-a).T
    area=ux*vy-vx*uy
    safe_area=np.where(area!=0,area,1)
    z=ndc[:,2][indices].astype(float)
    inverse_w=1/xform[:,3].astype(float)
    attributes=np.column_stack((layout[1],layout[3],layout[4])).astype(float)

    def primitive(p):
        dx,dy=(np.asarray(p)+.5-a).T
        s,t=(dx*vy-dy*vx)/safe_area,(ux*dy-uy*dx)/safe_area
        weights=np.column_stack([1-s-t,s,t])
        covered=np.flatnonzero((weights>=-1e-10).all(1)&(area!=0))
        assert len(covered)>0,p
        return int(covered[np.argmax((weights*z).sum(1)[covered])])

    def uv_matcap(p,tri):
        dx,dy=np.asarray(p)+.5-a[tri]
        s=(dx*vy[tri]-dy*vx[tri])/safe_area[tri]
        t=(ux[tri]*dy-uy[tri]*dx)/safe_area[tri]
        vertex_ids=indices[tri]
        weights=np.asarray([1-s-t,s,t])*inverse_w[vertex_ids]
        values=(weights@attributes[vertex_ids])/weights.sum()
        uv=values[:2]
        normal=values[2:5]
        tangent=values[5:8]
        bitangent=np.cross(normal,tangent)*values[8]
        radial=(uv-np.floor(uv))*2-1
        matcap_local=np.r_[-radial*normal_scale,np.sqrt(max(1-radial@radial,0))]
        normal_world=(np.column_stack((tangent,bitangent,normal))@matcap_local)@view
        return .5*normal_world[:2]/np.linalg.norm(normal_world)+.5,uv

    definitions=('fine','coarseTopLeft','coarseBottomLeft','coarseTopRight','coarseBottomRight')
    output=[]
    for i,(x,y) in enumerate(points):
        index=primitive((x,y))
        x0,y0=x&~1,y&~1
        grid=np.asarray([[uv_matcap((x0+dx,y0+dy),index)[0] for dx in range(2)] for dy in range(2)])
        tiles=np.asarray([[uv_matcap((x0+dx,y0+dy),index)[1] for dx in range(2)] for dy in range(2)])
        tile=np.floor(tiles)
        gx,gy=grid[:,1]-grid[:,0],grid[1]-grid[0]
        fine=np.asarray([gx[y-y0],gy[x-x0]])
        crossing=bool(np.any(tile[y-y0,0]!=tile[y-y0,1]) or np.any(tile[0,x-x0]!=tile[1,x-x0]))
        pairs=(fine,np.asarray([gx[0],gy[0]]),np.asarray([gx[1],gy[0]]),np.asarray([gx[0],gy[1]]),np.asarray([gx[1],gy[1]]))
        case=native['cases']
        center=grid[y-y0,x-x0]
        hardware_coord=np.asarray(case['uv']['values'][i])
        correction={}
        for name,pair in zip(definitions,pairs):
            analytic=np.abs(pair)
            tag='fine' if name=='fine' else 'coarse'
            observed=np.asarray([case[f'{axis}-{tag}']['values'][i] for axis in ('x','y')])
            gradient_error=float(np.abs(observed-analytic).max())
            rho=float(np.linalg.norm(pair,axis=1).max())*256
            level=int(np.clip(np.floor(np.log2(max(rho,1e-12))-.5),0,8))
            correction[name]=dict(gradientError=gradient_error,level=level,nativeLevelMatch=level in expected[i],
                                  gradient=pair.tolist(),surfaceCrossing=crossing)
        output.append(dict(point=[x,y],triangle=index,center=center.tolist(),hardwareCenter=hardware_coord.tolist(),
            centerError=float(np.abs(center-hardware_coord).max()),expectedLevel=expected[i],
            fineUvTileCrossing=crossing,modes=correction))
    totals={}
    seam_points=[row for row in output if tuple(row['point']) in seam]
    for name in definitions:
        error=np.asarray([row['modes'][name]['gradientError'] for row in output])
        totals[name]=dict(lodMatches=sum(row['modes'][name]['nativeLevelMatch'] for row in output),
            absoluteGradientP95=float(np.percentile(error,95)),absoluteGradientPeak=float(error.max()),
            seamLodMatches=sum(row['modes'][name]['nativeLevelMatch'] for row in seam_points))
    print(device,'center bounds',np.quantile([s['centerError'] for s in output],[0,.5,.95,1]).tolist(),
          'quad',json.dumps(totals),flush=True)
    return dict(totals=totals,points=output)


results={device:solve(device,row,levels['nativeHardware'][device]['rows']) for device,row in source['devices'].items()}
record=dict(status='measured-post-vertex-matcap-quad',capture=digest(capture),levels=digest(level_reference),devices=results)
(root/'iris-matcap-native-quad-model.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
