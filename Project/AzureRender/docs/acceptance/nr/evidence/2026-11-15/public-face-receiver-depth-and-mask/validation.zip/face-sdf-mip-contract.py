"""Build and run the opt-in face-mask sampling contract on the shared machine."""
from hashlib import file_digest
from pathlib import Path
import json
import os
import runpy
import subprocess
import sys


root = Path(__file__).resolve().parent
config = 'msaa-release'
work = root.parents[2]
control = runpy.run_path(str(root / 'face-quality-batch.py'))
lock = json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state'] == 'held' and Path(lock['output']) == root
mode = sys.argv[1]
assert mode in ('red', 'green')
if mode == 'red':
    # The retained executable already produced the failure with the original
    # authored face mask. Preserve that readback while the worktree advances.
    evidence = root.parent / '20261114-150229-face-native-geometry-mask-sampling-d5d93e/face-mask-authored-material-validator/red.json'
    red = json.loads(evidence.read_bytes())
    assert red['code'] == 1 and 'fixed lookup sampler violated at slot 4' in red['diagnostic']
    print(json.dumps(red, indent=2))
    sys.exit(0)
player = root / config / 'AzurePlayer.exe'
candidate = root / 'face-sdf-product'
candidate.mkdir(exist_ok=True)
def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()
inputs=['CMakeLists.txt','src/assets/GltfLoader.cpp','src/assets/GltfLoader.hpp','src/assets/MaterialData.cpp',
        'src/assets/MaterialSurfaceProfile.hpp','tests/CharacterRepairTests.cpp']
revisions={name:digest(work/name) for name in inputs}
expected = '1a30d925a674ddb1d95876cb80181106a0217e12a7228a35b5980b134954cb69'
assert digest(player) == expected
output = root / config
catalog = output/'shaders'
previous_shaders={path.name:digest(path) for path in catalog.glob('*.spv')}
assert len(previous_shaders)==895
settings=(output/'CMakeCache.txt').read_text(encoding='utf8')
configured=f'CMAKE_RUNTIME_OUTPUT_DIRECTORY:PATH={candidate.as_posix()}'
runtime=[line for line in settings.splitlines() if line.startswith('CMAKE_RUNTIME_OUTPUT_DIRECTORY:')]
assert not runtime or runtime == [configured]
configure = [control['entry'], control['cmake'], '-S', str(work), '-B', str(output),
             '-DCMAKE_RUNTIME_OUTPUT_DIRECTORY:PATH=' + candidate.as_posix()]
args = [control['entry'], control['cmake'], '--build', str(output),
        '--target', 'AzureCharacterRepairTests', 'AzureMaterialValidator', '--parallel', '3']
try:
    if not runtime:
        assert control['log']('face-sdf-output-configure', subprocess.list2cmdline(configure),
                              dict(shell=True, cwd=work), 220) == 0
    assert control['log'](f'face-sdf-mip-{mode}-build',
                          subprocess.list2cmdline(args), dict(shell=True, cwd=work), 1550) == 0
finally:
    restore=[control['entry'],control['cmake'],'-S',str(work),'-B',str(output),'-U','CMAKE_RUNTIME_OUTPUT_DIRECTORY']
    assert control['log']('face-sdf-output-restore',subprocess.list2cmdline(restore),
                          dict(shell=True,cwd=work),220)==0
assert digest(player) == expected
assert {path.name:digest(path) for path in catalog.glob('*.spv')}==previous_shaders
args = [str(candidate/'AzureCharacterRepairTests.exe'), str(work/'assets_public/third_person/material_fixture.gltf')]
env=dict(os.environ)
env['PATH']=str(output)+os.pathsep+env['PATH']
code = control['log'](f'face-sdf-mip-{mode}', args, dict(cwd=work,env=env), 280)
assert code == 0
generated = root.parent / '20261114-150229-face-native-geometry-mask-sampling-d5d93e/face-mask-authored-validation.py'
assert control['log'](f'face-sdf-mip-{mode}-validator', [sys.executable, str(generated), 'green',
    str(candidate / 'AzureMaterialValidator.exe')], dict(cwd=work,env=env), 100) == 0
verify = json.loads((generated.parent/'face-mask-authored-material-validator/green.json').read_bytes())
red = json.loads((generated.parent/'face-mask-authored-material-validator/red.json').read_bytes())
assert verify['overrideSha256']==red['overrideSha256'] and verify['maskSha256']==red['maskSha256']
assert verify['validatorSha256']!=red['validatorSha256']
assert verify['code']==0
assert revisions=={name:digest(work/name) for name in inputs}
report=dict(status='qualified',retainedPlayer=expected,candidateValidator=verify['validatorSha256'],
            shaderCatalogCount=len(previous_shaders),mask=verify['maskSha256'],sourceInputs=revisions)
(root/'face-sdf-mip-contract-receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
