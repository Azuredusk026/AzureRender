"""Repeat device-qualified material cases and the current-driver frozen sequence."""
from pathlib import Path
import json
import os
import runpy
import subprocess
import sys


root=Path(__file__).resolve().parent
stage_name=os.environ.get('AZURE_NR_FACE_RELEASE_STAGE','face-quality-release')
assert stage_name in ('face-quality-release','face-quality-release-isolated-mask')
stage=root/stage_name
hold=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert hold['state']=='held' and Path(hold['output'])==root
receipt=json.loads((stage/'test-receipt.json').read_bytes())
assert all(len(receipt['captures'][device])==9 for device in ('nvidia','intel'))
catalog=runpy.run_path(str(root/'face-quality-candidate-catalog.py'))
with catalog['activate'](receipt['compiledPrograms']) as resources:
    os.environ['PATH']=str(resources)+os.pathsep+os.environ['PATH']
    for device in ('nvidia','intel'):
        for mode in ('mask','nearest'):
            folder=stage/f'public-{mode}-{device}'
            if (folder/'accepted.json').is_file():continue
            subprocess.run([sys.executable,str(root/'face-quality-production.py'),device,mode],check=True,timeout=250)
    frozen=stage/'frozen-current-face-and-iris/results.json'
    if not frozen.is_file():
        subprocess.run([sys.executable,str(root/'frozen-current-face-and-iris.py'),'face-quality-release'],check=True,timeout=930)
qualified=json.loads(frozen.read_bytes())
assert qualified['sameDriverStatus']=='passed' and qualified['playerSha256']==receipt['executable']
