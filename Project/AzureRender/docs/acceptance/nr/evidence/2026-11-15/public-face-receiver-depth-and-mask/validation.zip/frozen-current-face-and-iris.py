from hashlib import file_digest
from pathlib import Path
import json
import os
import runpy
import sys

import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
helper=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read,invoke=helper['read'],helper['invoke']
def digest(p):
    with p.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()

def main(mode='retained'):
    assert mode in ('retained','face-quality-release','recover-finished-candidate')
    recovering=mode=='recover-finished-candidate'
    if recovering:mode='face-quality-release'
    state=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    if recovering:
        assert state['state']!='held' or Path(state['output'])!=run
    else:
        assert state['state']=='held' and Path(state['output'])==run
    stage_name=os.environ.get('AZURE_NR_FACE_RELEASE_STAGE','face-quality-release')
    assert stage_name in ('face-quality-release','face-quality-release-isolated-mask')
    build=run/('msaa-release' if mode=='retained' else stage_name)
    resources=run/'msaa-release'
    player=build/'AzurePlayer.exe'
    retained_player='1a30d925a674ddb1d95876cb80181106a0217e12a7228a35b5980b134954cb69'
    expected_player=retained_player if mode=='retained' else read(build/'link-receipt.json')['newPlayer']
    if mode!='retained':
        assert read(build/'test-receipt.json')['executable']==expected_player
    assert digest(player)==expected_player
    previous=run/'frozen-face-compat'
    frozen=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames')
    def captures(p):return sorted(p.glob('frame_*.png'))
    expected=read(previous/'results.json')['actual']
    assert len(expected)==4
    assert [digest(p) for p in captures(previous/'frames')]==expected
    strict_expected=[e['expectedSha256'] for e in read(grid/'default-four-results.json')['frames']]
    assert len(strict_expected)==4
    strict_images=captures(frozen)
    assert [digest(p) for p in strict_images]==strict_expected
    retained=read(run/'frozen-retained-driver-controls.json')
    assert [row['historicalOnCurrentDriverSha256'] for row in retained['frames']]==expected
    output=(run if mode=='retained' else build)/'frozen-current-face-and-iris'
    if output.exists() and not recovering:
        assert not (output/'results.json').exists()
        output.rename(output.with_name(f'{output.name}-interrupted-{len(list(output.parent.glob(output.name+"-interrupted-*")))+1}'))
    if not recovering:output.mkdir()
    command=read(grid/'default-four-command.json')
    command[0]=str(player)
    command[command.index('--resource-root')+1]=str(resources)
    command[command.index('--capture-dir')+1]=str(output/'frames')
    command[command.index('--runtime-report')+1]=str(output/'runtime.json')
    material=read(run/'eye-native-public-nvidia-projected/results.json')
    assert material['playerSha256']==retained_player
    fingerprint_before={p.name:digest(p) for p in (resources/'shaders').glob('*.spv')}
    assert len(fingerprint_before)==895
    if recovering:
        catalog=runpy.run_path(str(run/'face-quality-candidate-catalog.py'))
        assert fingerprint_before==catalog['retained_catalog'](run)
        assert command==read(output/'command.json')
        assert not (output/'results.json').exists()
        assert 'Captured frames: 4 at 24 fps' in (output/'player.log').read_text(encoding='utf8')
        frames=output/'frames'
        manifest=read(frames/'capture_manifest.json')
        assert (manifest['width'],manifest['height'],manifest['capturedFrames'],manifest['renderedFrames'])==(2560,1440,4,4)
    else:
        frames=invoke('nvidia',command,output)
        assert [digest(player),{p.name:digest(p) for p in (resources/'shaders').glob('*.spv')}]==[expected_player,fingerprint_before]
    actual=captures(frames)
    assert len(actual)==4
    caps=read(frames/'gpu_capabilities.json')
    assert caps['device_id']==0x28e0
    driver=caps['driver_version']
    assert (driver>>22,(driver>>14)&255)==(595,79)
    assert not list(frames.glob('reference-*'))
    unpack=lambda p:np.asarray(Image.open(p).convert('RGB'),dtype=np.int16)
    rows=[]
    for i,frame in enumerate(actual):
        sha=digest(frame)
        result=dict(frame=frame.name,sha256=sha,sameDriverExpectedSha256=expected[i],sameDriverExact=sha==expected[i],
                    frozenExpectedSha256=strict_expected[i],frozenExact=sha==strict_expected[i])
        image=unpack(frame)
        d=np.abs(image-unpack(strict_images[i])).max(2)
        same=np.abs(image-unpack(previous/'frames'/frame.name)).max(2)
        result.update(frozenDifferingPixels=int((d>0).sum()),frozenOverOne=int((d>1).sum()),frozenPeak=int(d.max()))
        result.update(sameDriverDifferingPixels=int((same>0).sum()),sameDriverPeak=int(same.max()))
        rows.append(result)
    report=dict(playerSha256=expected_player,shaderSetCount=len(fingerprint_before),driver='595.79',driverVersion=driver,
        recoveredCompletedCapture=recovering,frozenDriver='592.82',sameDriverStatus='passed' if all(row['sameDriverExact'] for row in rows) else 'failed',
        originalFrozenStatus='passed' if all(row['frozenExact'] for row in rows) else 'failed',frames=rows)
    (output/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print(json.dumps(report))
    assert report['sameDriverStatus']=='passed',report

if __name__=='__main__':main(*sys.argv[1:])

