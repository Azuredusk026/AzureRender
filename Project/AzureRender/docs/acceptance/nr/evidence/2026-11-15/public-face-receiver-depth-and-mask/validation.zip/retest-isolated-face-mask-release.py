import os
from pathlib import Path
import subprocess
import sys

run=Path(__file__).resolve().parent
environment=dict(os.environ,AZURE_NR_FACE_RELEASE_STAGE='face-quality-release-isolated-mask')
batches={'build':(('link-face-quality-release.py',1400),),
         'gpu':(('test-face-quality-release.py',900),('retest-face-quality-production.py',1350))}
for script,timeout in batches[sys.argv[1]]:
    path=run/f'isolated-mask-{script.removesuffix(".py")}.log'
    with path.open('wb') as log:
        child=subprocess.run([sys.executable,str(run/script)],env=environment,stdout=log,
                             stderr=subprocess.STDOUT,timeout=timeout)
    if child.returncode:
        print(path.read_text(encoding='utf8',errors='replace')[-6000:],flush=True)
    child.check_returncode()
    print(script,'verified',flush=True)
