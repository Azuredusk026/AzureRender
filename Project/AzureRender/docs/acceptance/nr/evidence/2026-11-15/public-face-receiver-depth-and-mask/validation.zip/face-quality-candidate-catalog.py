"""Use the verified Release catalog with a small candidate shader replacement."""
from contextlib import contextmanager
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil


root=Path(__file__).resolve().parent
baseline=root/'msaa-release'
stage_name=os.environ.get('AZURE_NR_FACE_RELEASE_STAGE','face-quality-release')
assert stage_name in ('face-quality-release','face-quality-release-isolated-mask')
candidate=root/stage_name
catalog=baseline/'shaders'
backups=candidate/'original-shaders'
programs=candidate/'candidate-shaders'
read=lambda path:json.loads(path.read_bytes())
sha=lambda path:sha256(path.read_bytes()).hexdigest()


def retained_catalog(root):
    # Fingerprints from the original MSAA Release GPU runs on both vendors.
    catalogs=[]
    for capture in ('opaque-sheet-nvidia-0','opaque-sheet-intel-4'):
        rows=read(root/capture/'report.json')['inputFingerprints']
        catalogs.append({Path(name).name:value for name,value in rows.items()
                         if Path(name).parent==root/'msaa-release/shaders' and name.endswith('.spv')})
    assert len(catalogs[0])==895 and catalogs[0]==catalogs[1]
    return catalogs[0]


def restore(fingerprints):
    if not backups.is_dir():return
    for original in sorted(backups.glob('*.spv')):
        assert sha(original)==fingerprints[original.name]
        original.replace(catalog/original.name)
        (catalog/(original.name+'.quality-tmp')).unlink(missing_ok=True)


@contextmanager
def activate(compiled, *, alternate_run=None):
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    if alternate_run is not None:
        assert alternate_run.parent == root.parent and alternate_run.name == '20261114-150229-face-native-geometry-mask-sampling-d5d93e'
    assert lock['state']=='held' and Path(lock['output'])==(alternate_run or root)
    expected=retained_catalog(root)
    restore(expected)
    assert {entry.name:sha(entry) for entry in catalog.glob('*.spv')}==expected
    backups.mkdir(exist_ok=True)
    try:
        for name,digest in compiled.items():
            target=catalog/name
            source=programs/name
            assert sha(source)==digest
            # Only the directory entries of the retained files move. Keeping
            # their inodes preserves the other tasks' read-only links.
            target.replace(backups/name)
            temporary=catalog/(name+'.quality-tmp')
            try:
                shutil.copyfile(source,temporary)
                temporary.replace(target)
            finally:
                temporary.unlink(missing_ok=True)
        assert {name:sha(catalog/name) for name in compiled}==compiled
        yield baseline
    finally:
        restore(expected)
        assert {entry.name:sha(entry) for entry in catalog.glob('*.spv')}==expected
