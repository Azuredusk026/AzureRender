"""Compile active shader variants and exercise the new Player on both adapters."""
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys


root=Path(__file__).resolve().parent
work=root.parents[2]
stage_name=os.environ.get('AZURE_NR_FACE_RELEASE_STAGE','face-quality-release')
assert stage_name in ('face-quality-release','face-quality-release-isolated-mask')
stage=root/stage_name
product=stage/'AzurePlayer.exe'
baseline=root/'msaa-release'
batch=runpy.run_path(str(root/'face-quality-batch.py'))
catalog=runpy.run_path(str(root/'face-quality-candidate-catalog.py'))
lock=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lock['state']=='held' and Path(lock['output'])==root
sha=lambda path:sha256(path.read_bytes()).hexdigest()
read=lambda path:json.loads(path.read_bytes())
write=lambda path,obj:path.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf8')
if not (stage/'link-receipt.json').is_file():
    print('The queued Release link has no current receipt.',flush=True)
    sys.exit(75)
receipt=read(stage/'link-receipt.json')
assert sha(product)==receipt['newPlayer']
assert all(sha(work/name)==digest for name,digest in receipt['inputs'].items())
source=work/'shaders/mesh.frag'
rules={r['output']:r for r in read(baseline/'shader-reload.json')['programs']}
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
programs=catalog['programs']
programs.mkdir(exist_ok=True)
assert len(list((baseline/'shaders').glob('*.spv')))==895
selected={'mesh.frag.spv','mesh_bindless.frag.spv','mesh_object_lighting.frag.spv',
          'mesh_object_early_lighting.frag.spv','mesh_object_bindless_lighting.frag.spv',
          'mesh_object_bindless_early_lighting.frag.spv','mesh_object.frag.spv','mesh_object_bindless.frag.spv',
          'mesh_lighting.frag.spv','mesh_bindless_lighting.frag.spv','mesh_early_lighting.frag.spv','mesh_bindless_early_lighting.frag.spv',
          'character_snapshot.frag.spv','character_snapshot_bindless.frag.spv',
          'character_snapshot_object.frag.spv','character_snapshot_object_bindless.frag.spv',
          'character_snapshot_object_lighting.frag.spv','character_snapshot_object_bindless_lighting.frag.spv',
          'mesh_object_samples_lighting.frag.spv','mesh_object_bindless_samples_lighting.frag.spv',
          'mesh_samples_lighting.frag.spv','mesh_bindless_samples_lighting.frag.spv'}
assert selected<=rules.keys()
selected.update(name for name in rules
                if name in {'mesh_samples.frag.spv','mesh_bindless_samples.frag.spv',
                            'mesh_object_samples.frag.spv','mesh_object_bindless_samples.frag.spv'})
compiled={}
for name in sorted(selected):
    matches=rules[name]
    assert matches['source']=='mesh.frag'
    target=programs/name
    command=[str(sdk/'glslc.exe'),*matches['arguments'],*('-D'+flag for flag in matches['defines']),
              '-I'+str(source.parent),str(source),'-o',str(target)]
    if target.exists():assert not os.path.samefile(target,baseline/'shaders'/name)
    subprocess.run(command,check=True,timeout=60)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(target)],
                   check=True,timeout=45)
    compiled[name]=sha(target)
report=dict(executable=sha(product),shaderSource=sha(source),compiledPrograms=compiled,captures={})
write(stage/'test-receipt.json',report)


def exercise(adapter, resources):
    output=stage/f'nearest-{adapter}'
    if output.exists():
        prior=read(output/'summary.json') if (output/'summary.json').is_file() else {}
        if prior.get('playerSha256')==report['executable'] and len(prior.get('metrics',{}))==9 and not prior['failures']:
            report['captures'][adapter]=prior['metrics']
            write(stage/'test-receipt.json',report)
            return
        count=len(list(stage.glob(output.name+'-interrupted-*')))+1
        output.rename(output.with_name(f'{output.name}-interrupted-{count}'))
    args=[sys.executable,str(work/'tools/test_material_composite_gpu.py'),'--nearest-depth-only',
          '--expected-validation','disabled','--executable',str(product),'--output',str(output)]
    environment=batch['env_for'](adapter)
    environment.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
    environment['AZURERENDER_RESOURCE_ROOT']=str(resources)
    environment['PATH']=str(baseline)+os.pathsep+environment['PATH']
    assert batch['log'](f'nearest-receiver-cases-{adapter}',args,
                       dict(cwd=work,env=environment),530)==0
    summary=read(output/'summary.json')
    assert summary['playerSha256']==report['executable'] and not summary['failures']
    report['captures'][adapter]=summary['metrics']
    write(stage/'test-receipt.json',report)


with catalog['activate'](compiled) as resources:
    for adapter in ('nvidia','intel'):
        exercise(adapter,resources)
