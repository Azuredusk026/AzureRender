"""Capture the authored-mask and nearest-depth options on the native controls."""
from contextlib import contextmanager
from hashlib import file_digest
import json
import os
from pathlib import Path
import runpy
import sys
from uuid import NAMESPACE_URL, uuid5

import numpy as np
from PIL import Image


root=Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
mask_run=root.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e'
radial=root.parent/'20261114-051632-face-local-radial-light-retest-ea8fb6'
fixture=grid/'iris-overlay-geometry-project'
stage_name=os.environ.get('AZURE_NR_FACE_RELEASE_STAGE','face-quality-release')
assert stage_name in ('face-quality-release','face-quality-release-isolated-mask')
stage=root/stage_name
helper=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
measure=runpy.run_path(str(mask_run/'face-geometry-mask-actual.py'))['measure']
score=runpy.run_path(str(grid/'static-quality.py'))
read=lambda p:json.loads(p.read_bytes())


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def prepare(control,output,mode):
    tag=f'face-quality-public-{mode}'
    source=Path(read(control/'command.json')[2])
    project=read(source if mode=='mask' else root/'face-candidate'/source.name)
    scene_name=project['startupScene'].split(':/',1)[1]
    materials=output/'inputs'
    materials.mkdir()
    staged={}
    if mode=='mask':
        scene=read(fixture/'scene'/scene_name)
        original=mask_run/'assets-sdf'
        probe='face-native-geometry-mask-sampling-sdf'
        material=read(original/(probe+'.azurematerial'))
        surface=material['surface']
        face=surface['materials'][0]
        profile=face['extras']['azureRenderMaterial']['faceSdf']
        profile['maskSampling']='authored-mip'
        target=surface['textures'][profile['maskTexture']]['source']
        fixture_texture=face['pbrMetallicRoughness'].pop('metallicRoughnessTexture')['index']
        assert fixture_texture==len(surface['textures'])-1
        previous=surface['textures'].pop()['source']
        material['textures'][str(target)]=material['textures'].pop(str(previous))
        dds=original/(probe+'.dds')
        texture_id=str(uuid5(NAMESPACE_URL,tag+'/texture'))
        meta=read(dds.with_suffix('.dds.azmeta'))
        meta['id']=texture_id
        material['textures'][str(target)]['asset']=texture_id
        staged[f'materials/{tag}.dds']=dds
        staged[f'materials/{tag}.dds.azmeta']=meta
        node=next(node for node in scene['nodes'] if node['id']=='hero')
        slot='name:'+face['name']
    else:
        original=root/'face-candidate'
        scene=read(original/scene_name)
        for asset in original.glob('late-face-overlay-*'):
            relative='materials' if '.azurematerial' in asset.name or '.dds' in asset.name else 'character'
            location=f'{relative}/{asset.name}'
            target=fixture/location
            if target.exists():
                assert asset.name.endswith('.bin.azmeta')
                for sidecar in (target,asset):
                    data=read(sidecar)
                    assert data['schemaVersion']==1 and not data.get('dependencies') and not data.get('settings')
                continue
            staged[location]=asset
        material=read(original/'late-face-overlay-1358.azurematerial')
        face=material['surface']['materials'][0]
        face['extras']['azureRenderMaterial']['composite']['depthPrepass']=True
        node=next(node for node in scene['nodes'] if node['id']=='late-face-overlay-1358')
        slot='name:'+face['name']
        del staged['materials/late-face-overlay-1358.azurematerial']
        del staged['materials/late-face-overlay-1358.azurematerial.azmeta']
    assert slot in node['materialSlots']
    material_id=str(uuid5(NAMESPACE_URL,tag+'/material'))
    node['materialSlots'][slot]=material_id
    project['startupScene']=f'stage:/{tag}.azurelevel'
    staged.update({f'{tag}.azureproject':project,f'scene/{tag}.azurelevel':scene,
        f'materials/{tag}.azurematerial':material,
        f'materials/{tag}.azurematerial.azmeta':dict(schemaVersion=1,id=material_id,dependencies=[],settings={})})
    for name,data in staged.items():
        if not isinstance(data,Path):
            record=materials/Path(name).name
            write(record,data)
            staged[name]=record
    return tag,staged


@contextmanager
def mount(assets):
    links=[]
    try:
        for name,source in assets.items():
            target=fixture/name
            target.hardlink_to(source)
            links.append((target,source))
        yield
    finally:
        for target,source in reversed(links):
            if target.is_file() and os.path.samefile(target,source):
                target.unlink()
            if target.suffix in ('.azureproject','.azurelevel'):
                meta=target.with_name(target.name+'.azmeta')
                if meta.is_file():
                    meta.replace(source.with_name(meta.name))


def capture(device,mode):
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==root
    assert device in ('nvidia','intel') and mode in ('mask','nearest')
    product=stage/'AzurePlayer.exe'
    tests=read(stage/'test-receipt.json')
    assert digest(product)==tests['executable'] and device in tests['captures']
    control=(radial/f'production-{device}-enabled') if mode=='mask' else root/f'face-{device}-pair'
    output=stage/f'public-{mode}-{device}'
    if output.exists():
        assert not (output/'accepted.json').is_file()
        count=len(list(stage.glob(output.name+'-interrupted-*')))+1
        output.rename(output.with_name(f'{output.name}-interrupted-{count}'))
    output.mkdir()
    tag,assets=prepare(control,output,mode)
    command=read(control/'command.json')
    command[0]=str(product)
    for flag,value in {'--project':fixture/(tag+'.azureproject'),'--capture-dir':output/'frames',
                        '--resource-root':root/'msaa-release','--runtime-report':output/'runtime.json'}.items():
        if flag in command:
            command[command.index(flag)+1]=str(value)
        else:
            command.extend((flag,str(value)))
    with mount(assets):
        frame=helper['invoke'](device,command,output)/'frame_000000.png'
    inputs=dict(overlayPair=mode=='nearest',player=tests['executable'],programs=tests['compiledPrograms'],
                fixture={name:digest(source) for name,source in assets.items()})
    measure(device,frame,inputs)
    results=read(output/'results.json')
    before,after=results['samples']['traced']['errors']
    if mode=='mask':
        assert after[0]<=before[0] and after[1]<=before[1],results['samples']['traced']
        assert results['regions']['outsideFace']['changed']==0,results['regions']
        if stage_name=='face-quality-release-isolated-mask':
            assert before[:2]==[41,35] and after[0]<=4 and after[1]<=2,results['samples']['traced']
            face=results['regions']['face']
            assert face['newOverOne']==0 and face['overEight'][1]<=face['overEight'][0],face
    else:
        points=[row['point'] for row in read(root/'face-multiply-overlap-audit.json')['devices'][device]['details']
                if len(row['triangles'])==2 and row['exponentErrors'][2]<=2]
        assert len(points)==12
        x,y=np.asarray(points).T
        ref,old,new=[score['image'](p).astype(np.int16) for p in
                     (score['reference_path'],control/'frames/frame_000000.png',frame)]
        error=lambda image:np.abs(image[y,x]-ref[y,x]).max(1).tolist()
        results['nearestWitnesses']=dict(points=points,oldError=error(old),newError=error(new))
        write(output/'results.json',results)
        assert max(error(new))<=2 and max(error(new))<max(error(old)),results['nearestWitnesses']
    write(output/'accepted.json',dict(status='passed-production-controls',frame=results['frameSha256']))


if __name__=='__main__':
    capture(*sys.argv[1:])
