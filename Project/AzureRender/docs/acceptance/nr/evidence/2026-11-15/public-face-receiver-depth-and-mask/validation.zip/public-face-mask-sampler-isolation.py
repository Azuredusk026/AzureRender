"""Isolate full-frame differences introduced by the authored face mask."""
from contextlib import contextmanager
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys

import numpy as np
from PIL import Image


run = Path(__file__).resolve().parent
project = run.parents[2]
previous = run.parent / '20261114-125923-body-lit-outline-depth-order-a29b63'
baseline_resources = previous / 'msaa-release'
stage = previous / 'face-quality-release'
output = run / 'public-face-mask-sampler-isolation'
harness = runpy.run_path(str(previous / 'face-quality-production.py'))
catalog = runpy.run_path(str(previous / 'face-quality-candidate-catalog.py'))
read = harness['read']
write = harness['write']
digest = harness['digest']
fixture = harness['fixture']
trace = [[1259, 301], [1295, 310]]
programs = ('mesh_object_lighting.frag.spv', 'mesh_object_early_lighting.frag.spv')
sdk = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')


def replace(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def source_variant(source, mode):
    if mode == 'split-sampler-control':
        declaration='vec3 materialNprLitAlbedo('
        source=replace(source,declaration,
            'bool useIsolatedFaceMask(){return AZURE_MATERIAL_CLASS==2U && textureQueryLevels(AZ_TEX_METALLIC_ROUGHNESS)==9;}' + chr(10) + declaration)
        source=replace(source,'''        bool authoredMaskMip=materialSurfaceProfiles.profiles[profileIndex].rows[20].z>.5;
        vec2 mask=authoredMaskMip?textureLod(AZ_TEX_STYLE_MASK,textureCoordinate,0.0).rg
            :azureSamplePrimaryUv(AZ_TEX_STYLE_MASK,textureCoordinate).rg;
''','        vec2 mask=azureSamplePrimaryUv(AZ_TEX_STYLE_MASK,textureCoordinate).rg;' + chr(10))
        source=replace(source,'vec4 packedMaterial = azureSamplePrimaryUv(AZ_TEX_METALLIC_ROUGHNESS,textureCoordinate);',
            'vec4 packedMaterial = useIsolatedFaceMask()?vec4(1,1,0,1):azureSamplePrimaryUv(AZ_TEX_METALLIC_ROUGHNESS,textureCoordinate);')
        return replace(source,'''        bool authoredMaskMip=materialSurfaceProfiles.profiles[material.materialPadding>>1U].rows[20].z>.5;
        faceSdfGeometryMask=authoredMaskMip?azureSamplePrimaryUv(AZ_TEX_STYLE_MASK,textureCoordinate).g
''','        faceSdfGeometryMask=useIsolatedFaceMask()?azureSamplePrimaryUv(AZ_TEX_METALLIC_ROUGHNESS,textureCoordinate).g' + chr(10))
    if mode == 'gradient-zero-lookup':
        return replace(source, 'authoredMaskMip?textureLod(AZ_TEX_STYLE_MASK,textureCoordinate,0.0).rg',
            'authoredMaskMip?textureGrad(AZ_TEX_STYLE_MASK,textureCoordinate,vec2(0.0),vec2(0.0)).rg')
    assert mode == 'original-sdf-sites'
    lookup = '''float dualFaceGeometryMask() {
    bool authoredMaskMip=materialSurfaceProfiles.profiles[material.materialPadding>>1U].rows[20].z>.5;
    return authoredMaskMip?azureSamplePrimaryUv(AZ_TEX_STYLE_MASK,textureCoordinate).g
        :textureLod(AZ_TEX_STYLE_MASK,textureCoordinate,0.0).g;
}

'''
    declaration = 'float dualFaceRampCoordinate(vec3 direction, vec3 normal, out vec4 distanceSample, float geometryMask)'
    source = replace(source, declaration,
        lookup + 'float dualFaceRampCoordinate(vec3 direction, vec3 normal, out vec4 distanceSample)')
    source = replace(source, '    return faceSdfRampCoordinate(distanceSample,geometryMask,localLight,localCamera,',
        '    return faceSdfRampCoordinate(distanceSample,dualFaceGeometryMask(),localLight,localCamera,')
    source = replace(source, '    float faceSdfGeometryMask=0.0;\n', '')
    source = replace(source, '''        bool authoredMaskMip=materialSurfaceProfiles.profiles[material.materialPadding>>1U].rows[20].z>.5;
        faceSdfGeometryMask=authoredMaskMip?azureSamplePrimaryUv(AZ_TEX_STYLE_MASK,textureCoordinate).g
            :textureLod(AZ_TEX_STYLE_MASK,textureCoordinate,0.0).g;
''', '')
    for name in ('faceSdfSample', 'localDistanceSample', 'distanceValue'):
        source = replace(source, f',{name},faceSdfGeometryMask);', f',{name});')
    return replace(source, 'headFrame,shadedNormal,faceSdfGeometryMask);',
        'headFrame,shadedNormal,dualFaceGeometryMask());')


@contextmanager
def shader_variant(mode, tests, resources):
    if mode == 'same-player-default':
        yield {name:tests['compiledPrograms'][name] for name in programs}
        return
    variant_dir = output/f'shaders-{mode}'
    variant_dir.mkdir(parents=True,exist_ok=True)
    source = run/'public-face-mask-sampler-isolation-source.frag'
    assert digest(source) == tests['shaderSource']
    variant = variant_dir/f'{mode}.frag'
    variant.write_text(source_variant(source.read_text(encoding='utf8'),mode),encoding='utf8')
    rules = {rule['output']:rule for rule in read(resources/'shader-reload.json')['programs']}
    hashes = {}
    changed = []
    try:
        for name in programs:
            target = variant_dir/name
            rule = rules[name]
            subprocess.run([str(sdk/'glslc.exe'), *rule['arguments'],
                *('-D'+flag for flag in rule['defines']), '-I'+str(project/'shaders'),
                str(variant), '-o', str(target)], check=True, timeout=60)
            subprocess.run([str(sdk/'spirv-val.exe'), '--target-env', 'vulkan1.3', '--relax-block-layout',
                str(target)], check=True, timeout=45)
            active = resources/'shaders'/name
            assert digest(active) == tests['compiledPrograms'][name]
            temporary = active.with_name(active.name+'.quality-tmp')
            shutil.copyfile(target,temporary)
            temporary.replace(active)
            changed.append(active)
            hashes[name] = digest(active)
        yield hashes
    finally:
        for active in changed:
            canonical = stage/'candidate-shaders'/active.name
            assert digest(canonical) == tests['compiledPrograms'][active.name]
            temporary = active.with_name(active.name+'.quality-tmp')
            shutil.copyfile(canonical,temporary)
            temporary.replace(active)


def capture(device, mode, resources, hashes, tests):
    folder = output / f'{device}-{mode}'
    previous_summary = folder / 'receipt.json'
    if previous_summary.is_file():
        result = read(previous_summary)
        if (result['programs'] == hashes and result['shaderSource'] == tests['shaderSource']
                and digest(folder/'frames/frame_000000.png') == result['frameSha256']):
            return result
    if folder.is_dir():
        count = len(list(output.glob(folder.name + '-interrupted-*')))
        folder.rename(output / f'{folder.name}-interrupted-{count+1}')
    folder.mkdir()
    control = harness['radial'] / f'production-{device}-enabled'
    options = read(control/'command.json')
    options[0] = str(stage/'AzurePlayer.exe')
    for name, value in {
        '--resource-root': resources, '--capture-dir': folder/'frames',
        '--runtime-report': folder/'runtime.json',
    }.items():
        if name in options:
            options[options.index(name)+1] = str(value)
        else:
            options.extend((name, str(value)))
    assets = {}
    if mode=='split-sampler-control':
        tag='face-native-geometry-mask-sampling-sdf'
        inputs=run/'assets-sdf'
        for relative in (f'{tag}.azureproject',f'scene/{tag}.azurelevel',f'materials/{tag}.azurematerial',
                         f'materials/{tag}.azurematerial.azmeta',f'materials/{tag}.dds',f'materials/{tag}.dds.azmeta'):
            assets[relative]=inputs/Path(relative).name
        options[options.index('--project')+1]=str(fixture/(tag+'.azureproject'))
    elif mode != 'same-player-default':
        tag, assets = harness['prepare'](control, folder, 'mask')
        options[options.index('--project')+1] = str(fixture/(tag+'.azureproject'))
    with harness['mount'](assets):
        frame = harness['helper']['invoke'](device, options, folder)/'frame_000000.png'
    image = lambda src: np.asarray(Image.open(src).convert('RGB'), dtype=np.int16)
    native = image(harness['score']['reference_path'])
    expected = image(control/'frames/frame_000000.png')
    isolated = image(run/f'capture-{device}-sdf/frames/frame_000000.png')
    candidate = image(frame)
    old_error = np.abs(expected-native).max(2)
    error = np.abs(candidate-native).max(2)
    changed = np.abs(candidate-isolated).max(2)
    faces = Image.open(harness['grid']/'native-face-masks/face.png').convert('L')
    face = np.asarray(faces)>0
    result = dict(programs=hashes, player=tests['executable'], shaderSource=tests['shaderSource'],
        frameSha256=digest(frame), overOne=int((error[face]>1).sum()),
        newOverOne=int(((old_error<=1)&(error>1)).sum()),
        overEight=int((error[face]>8).sum()), outsideFace=int(((candidate!=expected).any(2)&~face).sum()),
        changedFromIsolated=int((changed>0).sum()), peakFromIsolated=int(changed.max()),
        probes=[dict(point=[x,y], native=native[y,x].tolist(), baseline=expected[y,x].tolist(),
            isolated=isolated[y,x].tolist(), actual=candidate[y,x].tolist()) for x,y in trace])
    write(previous_summary, result)
    print(device, mode, json.dumps(result), flush=True)
    return result


def main(device):
    assert device in ('intel', 'nvidia')
    lock = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state'] == 'held' and Path(lock['output']) == run
    tests = read(stage/'test-receipt.json')
    assert digest(stage/'AzurePlayer.exe') == tests['executable']
    expected = catalog['retained_catalog'](previous)
    assert {p.name:digest(p) for p in (baseline_resources/'shaders').glob('*.spv')} == expected
    os.environ['PATH'] = str(baseline_resources)+os.pathsep+os.environ['PATH']
    result = {}
    output.mkdir(exist_ok=True)
    with catalog['activate'](tests['compiledPrograms'],alternate_run=run) as resources:
        for mode in ('same-player-default', 'split-sampler-control', 'gradient-zero-lookup', 'original-sdf-sites'):
            with shader_variant(mode,tests,resources) as hashes:
                result[mode] = capture(device,mode,resources,hashes,tests)
            if mode=='split-sampler-control' and result[mode]['changedFromIsolated']==0:
                break
    write(output/f'{device}.json', result)


if __name__ == '__main__':
    main(*sys.argv[1:])
