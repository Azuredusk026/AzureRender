"""Archive the renderer contracts and the native-pose retest from the same Player."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


root=Path(__file__).resolve().parent
mask_run=root.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e'
prior=root/'face-quality-release'
stage=root/'face-quality-release-isolated-mask'
project=root.parents[2]
target=project/'docs/acceptance/nr/evidence/2026-11-15/public-face-receiver-depth-and-mask'
read=lambda p:json.loads(p.read_bytes())


def digest(path):
    with path.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()


test=read(stage/'test-receipt.json')
link=read(stage/'link-receipt.json')
assert link['newPlayer']==test['executable']==digest(stage/'AzurePlayer.exe')
assert len(test['compiledPrograms'])==26
assert digest(project/'shaders/mesh.frag')==test['shaderSource']
assert all(digest(project/name)==saved for name,saved in link['inputs'].items())
contract=read(root/'face-sdf-mip-contract-receipt.json')
assert contract['status']=='qualified'
members={name:root/name for name in ('face-sdf-mip-contract-receipt.json','face-sdf-mip-green.log',
    'face-sdf-mip-green-validator.log','face-sdf-mip-contract.py','archive-public-face-quality.py',
    'test-face-quality-release.py','face-quality-production.py','face-quality-candidate-catalog.py',
    'retest-isolated-face-mask-release.py','retest-face-quality-production.py','frozen-current-face-and-iris.py')}
for name in ('link-receipt.json','test-receipt.json'):
    members[name]=stage/name
for name in ('red.json','green.json'):
    members['original-material-validator/'+name]=mask_run/'face-mask-authored-material-validator'/name
results={}
for device in ('nvidia','intel'):
    directory=stage/f'nearest-{device}'
    raw=read(directory/'summary.json')
    assert not raw['failures'] and len(raw['captures'])==11 and len(raw['metrics'])==9
    assert raw['playerSha256']==test['executable']
    members[f'{directory.name}/summary.json']=directory/'summary.json'
    details={}
    for mode in ('mask','nearest'):
        folder=stage/f'public-{mode}-{device}'
        frame=folder/'frames/frame_000000.png'
        actual=read(folder/'results.json')
        control=read(folder/'accepted.json')
        assert actual['input']['player']==link['newPlayer']
        assert actual['input']['programs']==test['compiledPrograms']
        assert control['status']=='passed-production-controls'
        assert actual['frameSha256']==control['frame']==digest(frame)
        assert actual['regions']['outsideFace']['changed']==0
        if mode=='mask':
            assert actual['regions']['face']['newOverOne']==0
            assert all(a<=b for a,b in zip(actual['samples']['traced']['errors'][1][:2],(4,2)))
            members[f'first-candidate/{folder.name}/results.json']=prior/folder.name/'results.json'
        else:
            assert len(actual['nearestWitnesses']['newError'])==12
            assert max(actual['nearestWitnesses']['newError'])<=2
        details[mode]=actual
        for name in ('command.json','results.json','accepted.json','frames/gpu_capabilities.json'):
            members[f'{folder.name}/{name}']=folder/name
    results[device]=dict(syntheticMetrics=raw['metrics'],capturedCases=len(raw['captures']),nativePose=details)
frozen=stage/'frozen-current-face-and-iris/results.json'
frozen_receipt=read(frozen)
assert frozen_receipt['sameDriverStatus']=='passed' and frozen_receipt['playerSha256']==link['newPlayer']
members['frozen-current-face-and-iris/results.json']=frozen
first_mask=read(prior/'public-mask-intel/results.json')
assert first_mask['regions']['face']['newOverOne']==2
isolated=mask_run/'public-face-mask-sampler-isolation'
isolated_result=read(isolated/'intel.json')
assert isolated_result['split-sampler-control']['changedFromIsolated']==0
for name in ('intel.json','intel-same-player-default/receipt.json','intel-split-sampler-control/receipt.json'):
    members[f'intel-sampler-control/{name}']=isolated/name
members['public-face-mask-sampler-isolation.py']=mask_run/'public-face-mask-sampler-isolation.py'
target.mkdir(parents=True,exist_ok=True)
package=target/'validation.zip'
with ZipFile(package,'w',ZIP_DEFLATED) as archive:
    for name,path in members.items():archive.write(path,name)
with ZipFile(package) as archive:
    assert archive.testzip() is None
    checks={name:sha256(archive.read(name)).hexdigest() for name in members}
assert checks=={name:digest(path) for name,path in members.items()}
output=dict(status='qualified-public-controls',overallVisualAcceptance='failed-user-review',
    executable=test['executable'],shaderCandidates=len(test['compiledPrograms']),devices=results,
    originalFrozen=frozen_receipt,archive=dict(sha256=digest(package),members=checks))
(target/'results.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf8')
