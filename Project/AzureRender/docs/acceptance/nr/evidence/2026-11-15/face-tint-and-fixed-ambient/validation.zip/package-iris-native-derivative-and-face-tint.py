"""Package native iris hardware gradients and face tint holdout measurements."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


run=Path(__file__).resolve().parent
evidence=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-15'
read=lambda path:json.loads(path.read_bytes())
digest=lambda data:sha256(data).hexdigest()

def package(name,result,members):
    destination=evidence/name
    destination.mkdir(parents=True,exist_ok=True)
    archive_path=destination/'validation.zip'
    with ZipFile(archive_path,'w',ZIP_DEFLATED) as archive:
        for member in members:archive.write(run/member,member)
    with ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        manifest={member:digest(archive.read(member)) for member in members}
    assert manifest=={member:digest((run/member).read_bytes()) for member in members}
    result['archive']=dict(sha256=digest(archive_path.read_bytes()),members=manifest)
    (destination/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')


request_dir='iris-native-matcap-coordinates/'
graph=read(run/'iris-matcap-hardware-lod-derivatives.json')
quads=read(run/'iris-matcap-native-quad-model.json')
replay=read(run/(request_dir+'results.json'))
assert len(replay['coordinates'])==255 and replay['status']=='qualified'
hardware={}
for label,data in graph['devices'].items():
    modes=data['samples']
    chosen=modes['coarse-largestEuclidean']
    assert chosen['allMatches']=={'nvidia':247,'intel':255}[label] and chosen['sharedLevelSevenMatches']==20
    geometry=quads['devices'][label]['totals']
    assert geometry['coarseBottomLeft']['lodMatches']==chosen['allMatches']
    peak=next(row for row in data['controls'] if row['point']==[1262,257])
    assert peak['hardware']==[7] and peak['derivativeMagnitude']['x-coarse']==peak['derivativeMagnitude']['x-fine']
    geometry_inputs=replay['devices'][label]['geometry']
    for kind in ('vertices','indices'):
        path=run/(request_dir+label+'-'+kind+'.bin')
        assert digest(path.read_bytes())==geometry_inputs[kind+'Sha256']
    hardware[label]=dict(coarseEuclideanMatches=chosen['allMatches'],fineEuclideanMatches=modes['fine-largestEuclidean']['allMatches'],
                         coarseSeamMatches=chosen['sharedLevelSevenMatches'],nativePeakControl=peak,quadModel=geometry)
package('iris-native-derivative-lanes',
    dict(status='measured-native-iris-derivative-lanes',overall='failed-user-review',scope=255,
         nativeSharedMipSeven=20,shaderMipBias=graph['shaderBias'],devices=hardware),
    ['package-iris-native-derivative-and-face-tint.py','iris-native-matcap-coordinates.py',
     request_dir+'request.json',request_dir+'results.json','iris-matcap-hardware-lod-derivatives.py',
     'iris-matcap-hardware-lod-derivatives.json','iris-matcap-native-quad-model.py','iris-matcap-native-quad-model.json',
     'iris-native-matcap-d3d-vulkan-owned-levels.json',*[request_dir+f'{label}-{item}.bin'
        for label in hardware for item in ('vertices','indices')]])

mask=read(run/'face-tint-mask-footprint.json')
tint=read(run/'face-view-tint-geometric-inputs.json')
ambient=read(run/'fixed-pose-native-ambient-source.json')
actual=read(run/'face-tint-residual-native/results.json')
controls=mask['newNativeControls']
assert actual['status']=='qualified' and tint['heldOutNativeTrace'] and len(controls)==6
assert all(x['states']['339']['r19'][:3]==ambient['playerScene']['faceAmbient'] for x in actual['samples'])
filter_peak=max(row['peakFilterError'] for row in controls)
factor_peak=max(row['errors']['factor'] for row in tint['newControls'])
assert filter_peak<.00023 and factor_peak<.000048
assert ambient['worldGiRetainedImagePairs']==24 and len(ambient['irisNativeWitnesses'])==8 and len(ambient['clothNativeWitnesses'])==4
positive={}
for device,data in tint['overshoots'].items():
    assert data['undershotNegative']==[0,0,0]
    positive[device]=data['overshotPositive']
package('face-tint-and-fixed-ambient',
    dict(status='measured-face-tint-holdout-and-fixed-pose-ambient',overall='failed-user-review',
         holdoutPoints=[row['point'] for row in controls],holdoutAuthoredMips=[row['level'] for row in controls],
         holdoutMaskPeak=filter_peak,holdoutTintFactorPeak=factor_peak,upwardErrorsByRgb=positive,ambient=ambient),
    ['package-iris-native-derivative-and-face-tint.py','face-tint-residual-native-trace.py',
     'face-tint-residual-native/request.json','face-tint-residual-native/results.json','face-tint-mask-footprint.py',
     'face-tint-mask-footprint.json','face-view-tint-geometric-inputs.py','face-view-tint-geometric-inputs.json',
     'fixed-pose-native-ambient-source.py','fixed-pose-native-ambient-source.json'])
print(f'iris {hardware["nvidia"]["coarseEuclideanMatches"]}/{hardware["intel"]["coarseEuclideanMatches"]}; face mask {filter_peak}, tint factor {factor_peak}',flush=True)

