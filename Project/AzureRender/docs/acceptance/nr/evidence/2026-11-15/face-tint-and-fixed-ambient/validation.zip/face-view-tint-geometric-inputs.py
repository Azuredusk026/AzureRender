"""Reconstruct face view tint from native geometry and signed face inputs."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


root=Path(__file__).resolve().parent
model=root/'face-tint-mask-footprint.py'
state={'__file__':str(model)}
exec(compile(model.read_text(encoding='utf-8-sig').split('\ncontrol_path=',1)[0],str(model),'exec'),state)
read,position,vertices,triangles,clip_w,a,x0,y0,x1,y1,safe_area=(
    state[name] for name in ('read','position','vertices','triangles','clip_w','a','x0','y0','x1','y1','safe_area'))
stages=read(root/'trace-face-view-mask.json')
native=read(root/'face-view-mask-math.json')
params={}
for key,record in stages['constants'].items():
    raw=(root/f'face-view-mask-cb{key}.bin').read_bytes()
    assert sha256(raw).hexdigest()==record['sha256']
    params[int(key)]=np.frombuffer(raw,'<f4').reshape(-1,4).astype(float)
camera=params[0][:3,2]
orthographic=params[1][4,3]
surface_sign=params[6][1,1]*2-1
low,high=native['blueScaleRange']
tint=np.asarray(native['nativeTint'])
native_path=root/'face-tint-residual-native/results.json'
replayed=read(native_path) if native_path.is_file() else None
if replayed:
    assert replayed['status']=='qualified'
else:
    print('Waiting for newly submitted native traces, old controls loaded.',flush=True)


def unit(v):
    return v/np.linalg.norm(v)


def calculate(point):
    data=position(point)
    owner=data['primitive']
    triangle=triangles[owner]
    dx,dy=np.asarray(point)+.5-a[owner]
    su=(dx*y1[owner]-dy*x1[owner])/safe_area[owner]
    sv=(x0[owner]*dy-y0[owner]*dx)/safe_area[owner]
    w=np.asarray([1-su-sv,su,sv])/clip_w[triangle]
    p,normal=(w@vertices[triangle,6:12]/w.sum()).reshape(2,3)
    geom=unit(normal)
    view=unit(orthographic*(camera+p)-p)
    facing=float(np.clip(geom@view,0,1))
    rgba=np.asarray(data['authoredRgba'])
    simple=rgba[0]*(low+(high-low)*rgba[2])
    weight=.85*(1-facing)*simple
    data.update(view=view.tolist(),normal=geom.tolist(),world=p.tolist(),nativeFacing=facing,geometryWeight=1.,
                modelWeight=weight,modelFactor=(1-weight+weight*tint).tolist())
    return data


def compare(data,registers,owner):
    assert data['primitive']==owner
    actual_view=np.asarray(registers['9']['r2'][:3])
    actual_normal=np.asarray(registers['76']['r13'][:3])
    actual_world=np.asarray(registers['9'].get('v2',[None]*4)[:3])
    actual_weight=registers['351']['r8'][3]
    actual_factor=np.asarray(registers['353']['r18'][:3])
    return dict(view=float(np.abs(actual_view-data['view']).max()),
         normal=float(np.abs(actual_normal-data['normal']).max()),
         world=None if actual_world[0] is None else float(np.abs(actual_world.astype(float)-data['world']).max()),
         weight=float(abs(actual_weight-data['modelWeight'])),
         factor=float(np.abs(actual_factor-data['modelFactor']).max()),
         actualWeight=actual_weight,actualFactor=actual_factor.tolist())


controls=[]
for row in stages['points']:
    p=row['sample']['point']
    estimated=calculate(p)
    errors=compare(estimated,row['registers'],row['sample']['primitive'])
    controls.append(dict(point=p,geometry=estimated,errors=errors))
print('control max view, normal, weight, factor',
    *(max(row['errors'][k] for row in controls) for k in ('view','normal','weight','factor')),flush=True)
assert max(row['errors']['view'] for row in controls)<.001
assert max(row['errors']['normal'] for row in controls)<.001
assert max(row['errors']['factor'] for row in controls)<.001
replacement_controls=[]
for row in replayed['samples'] if replayed else []:
    data=calculate(row['point'])
    errors=compare(data,row['states'],row['primitive'])
    replacement_controls.append(dict(point=row['point'],geometry=data,errors=errors))

overshoots=read(root/'face-tint-combined-introduced-pixels.json')
summary={}
for label,samples in overshoots.items():
    rows=[]
    for sample in samples:
        data=calculate([sample['x'],sample['y']])
        errors=np.asarray(sample['tintSdf'])-sample['reference']
        base_error=np.asarray(sample['before'])-sample['reference']
        rows.append(dict(point=data['point'],level=data['level'],modelWeight=data['modelWeight'],
                         modelFactor=data['modelFactor'],before=base_error.tolist(),after=errors.tolist()))
    after=np.asarray([row['after'] for row in rows])
    summary[label]=dict(rows=rows,overshotPositive=(after>1).sum(axis=0).tolist(),
        undershotNegative=(after<-1).sum(axis=0).tolist(),
        medianNativeViewTint=np.median(np.asarray([row['modelFactor'] for row in rows]),axis=0).tolist())
    print(label,summary[label]['overshotPositive'],summary[label]['undershotNegative'],summary[label]['medianNativeViewTint'],flush=True)
proof=dict(status='measured-face-view-geometric-input',controlCount=len(controls),controls=controls,
    heldOutNativeTrace=bool(replayed),newControls=replacement_controls,overshoots=summary,
    constants=dict(nativeCamera=camera.tolist(),orthographicWeight=orthographic,nativeBackFaceSign=surface_sign))
(root/'face-view-tint-geometric-inputs.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')

