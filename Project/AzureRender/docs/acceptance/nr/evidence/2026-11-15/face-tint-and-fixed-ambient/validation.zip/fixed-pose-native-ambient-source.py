"""Verify the actual ambient fallback in the frozen character replay."""
from hashlib import file_digest,sha256
import json
from pathlib import Path
import re
import struct


run=Path(__file__).resolve().parent
read=lambda path:json.loads(path.read_bytes())
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
receiver=run.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
body=run.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
original=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c')
constants=[run/'face-view-mask-cb1.bin',receiver/'iris-native-846-cb1.bin',body/'body-outline-1018-cb1.bin']
buffer=constants[0].read_bytes()
assert all(path.read_bytes()==buffer for path in constants)
read_vec=lambda register:struct.unpack_from('<4f',buffer,register*16)
fallback_control=read_vec(111)[1]
assert fallback_control==1
face,eye=read_vec(113)[:3],read_vec(112)[:3]
events={804:(117,337,'r19',113),846:(104,327,'r17',112),1018:(74,263,'r6',113),1383:(81,305,'r15',112)}
shader_source={}
for owner,(test,assign,register,constant) in events.items():
    raw=(original/f'native-e{owner}.dxbc').read_bytes()
    assembly=(original/f'native-e{owner}.asm').read_text(encoding='utf-8-sig')
    assert re.search(rf'\b{test}:\s+lt .*cb1\[111\]\.y, l\(0\.500000\)',assembly)
    assert re.search(rf'\b{assign}:\s+mov {register}\.\w+, cb1\[{constant}\]\.\w+',assembly)
    shader_source[owner]=dict(sha256=sha256(raw).hexdigest(),branchInstruction=test,
        fallbackInstruction=assign,constant=constant,rgb=read_vec(constant)[:3])


def trace_values(path,owner):
    test,assignment,register,constant=events[owner]
    current={}
    sampled=None
    executed_fallback=False
    for line,registers in read(path):
        current.update(registers)
        if line==assignment:
            executed_fallback=True
        if line==assignment+1:
            sampled=current[register][:3]
            break
    assert executed_fallback and sampled==list(read_vec(constant)[:3]),(path,sampled,executed_fallback)
    return dict(file=path.name,hash=sha256(path.read_bytes()).hexdigest(),rgb=sampled)


face_trace=read(run/'trace-face-view-mask.json')
assert face_trace['status']=='qualified' and face_trace['constants']['1']['sha256']==sha256(buffer).hexdigest()
assert len(face_trace['points'])==12
iris_traces=[trace_values(path,846) for path in sorted(receiver.glob('iris-native-846-trace-*.json'))]
cloth_traces=[trace_values(path,1383) for path in sorted((body/'body-native-late-cloth-traces').glob('e1383-*.json'))]
assert len(iris_traces)==8 and len(cloth_traces)==4

scene=grid/'iris-overlay-geometry-project/scene/face-native-radial-local-production.azurelevel'
data=read(scene)
profile=data['renderSettings']['nprLighting']
assert profile['enabled'] and not profile['useSceneIrradiance'] and profile['ambientColor']==list(face)
assert not data.get('irradianceVolume')
probe=data['reflectionProbe']
assert probe['enabled'] and probe['intensity']==.5
matcap_shader=(original/'native-e846.asm').read_text(encoding='utf-8-sig')
assert re.search(r'\b462:\s+sample_b\(texture2d\).*t14\.',matcap_shader)

floor=read(original/'floor-irradiance-results.json')
assert len(floor['frames'])==24
for row in floor['frames']:
    for mode,hash_expected in zip(('fixed','gi-off'),row['sha256']):
        img=original/f"floor-{mode}-{row['visibility']}"/'frames'/f"frame_{row['frame']:06d}.png"
        with img.open('rb') as stream:
            assert file_digest(stream,'sha256').hexdigest()==hash_expected,img
retained_stats={k:[row['regions'][k] for row in floor['frames'] if row['frame']==11] for k in ('centerFloor','leftFloor')}
proof=dict(status='measured-native-fixed-pose-ambient-source',frame=10401,cb1Sha256=sha256(buffer).hexdigest(),
    fallbackFlag=fallback_control,nativePrograms=shader_source,faceNativeWitnessCount=len(face_trace['points']),
    irisNativeWitnesses=iris_traces,clothNativeWitnesses=cloth_traces,
    playerScene=dict(sha256=sha256(scene.read_bytes()).hexdigest(),sceneIrradiance=profile['useSceneIrradiance'],
        irradiationVolumePresent=bool(data.get('irradianceVolume')),faceAmbient=profile['ambientColor'],
        reflectionProbe=probe['texture'],reflectionIntensity=probe['intensity']),
    irisMatcapOwnTextureSlot=14,irisMatcapSampleInstruction=462,worldGiRetainedImagePairs=24,
    worldGiFloorRetainedStatistics=retained_stats)
(run/'fixed-pose-native-ambient-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(sha256(buffer).hexdigest(),face,eye,len(iris_traces),len(cloth_traces),len(floor['frames']),flush=True)

