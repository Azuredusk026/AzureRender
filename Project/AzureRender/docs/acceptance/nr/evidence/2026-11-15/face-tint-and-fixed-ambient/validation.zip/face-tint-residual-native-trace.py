from hashlib import sha256
import json
import math
import os
from pathlib import Path
import subprocess
import traceback

key='AZURE_NR_FACE_TINT_RESIDUAL_TRACE'
root=Path(os.environ[key]).parent if key in os.environ else Path(__file__).resolve().parent
source=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
folder=root/'face-tint-residual-native'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')


def worker():
    import renderdoc as rd
    req=read(folder/'request.json')
    capture=rd.OpenCaptureFile()
    ctl=None
    result=dict(status='failed',samples=[])
    try:
        assert capture.OpenFile(req['native'],'',None)==rd.ResultCode.Succeeded
        opts=rd.ReplayOptions()
        opts.forceGPUVendor=rd.GPUVendor.nVidia
        opts.forceGPUDeviceID=0x28e0
        status,ctl=capture.OpenCapture(opts,None)
        assert status==rd.ResultCode.Succeeded and ctl
        api=ctl.GetAPIProperties()
        assert api.pipelineType==rd.GraphicsAPI.D3D11 and api.vendor==rd.GPUVendor.nVidia and not api.degraded
        ctl.SetFrameEvent(804,True)
        pipe=ctl.GetPipelineState()
        pixel=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
        assert sha256(bytes(pixel.rawBytes)).hexdigest()==req['shader']
        target=pipe.GetOutputTargets()[0].resource
        assert str(target)=='ResourceId::141976'
        for x,y in req['points']:
            write(folder/'progress.json',dict(point=[x,y],done=len(result['samples'])))
            ctl.SetFrameEvent(804,True)
            history=[step for step in ctl.PixelHistory(target,x,1439-y,rd.Subresource(),rd.CompType.Typeless)
                     if step.eventId==804 and not (step.depthTestFailed or step.stencilTestFailed or step.backfaceCulled or step.shaderDiscarded)]
            assert history,(x,y)
            point=history[-1]
            inputs=rd.DebugPixelInputs()
            inputs.primitive=point.primitiveID
            ctl.SetFrameEvent(804,True)
            trace=ctl.DebugPixel(x,1439-y,inputs)
            assert trace and trace.debugger,(x,y,inputs.primitive)
            exact={}
            state={}
            count=0
            try:
                while True:
                    block=ctl.ContinueDebug(trace.debugger)
                    if not block:break
                    for step in block:
                        for update in step.changes:
                            data=update.after
                            if data.name:
                                state[data.name]=[v if math.isfinite(v) else None for v in list(data.value.f32v)[:4]]
                        pc=int(step.nextInstruction)
                        if 25<=pc<=80 or 339<=pc<=354 or pc in (9,370,371,435,438,748,749):
                            exact[pc]=dict(state)
                        count+=1
                    assert count<20000
            finally:
                ctl.FreeTrace(trace)
            assert {33,52,69,70,76}<=exact.keys()
            result['samples'].append(dict(point=[x,y],primitive=int(point.primitiveID),
                nativeOutput=list(point.shaderOut.col.floatValue)[:4],states=exact,totalInstructions=count))
        result['status']='qualified'
    except Exception:
        result['error']=traceback.format_exc()
    finally:
        if ctl:ctl.Shutdown()
        capture.Shutdown()
        write(folder/'results.json',result)
    os._exit(0 if result['status']=='qualified' else 1)


def launch():
    from hashlib import file_digest
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==root
    req=read(source/'native-face-masks/request.json')
    req['shader']=read(source/'native-face-skin-stages/results.json')['geometry']['804']['pixelShaderSha256']
    with Path(req['native']).open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==req['captureSha256']
    source_results=read(root/'face-tint-combined-introduced-pixels.json')
    common={(row['x'],row['y']) for row in source_results['nvidia']}&{(row['x'],row['y']) for row in source_results['intel']}
    rows=[(1301,306),(1296,310),(1288,315),(1240,268)]
    assert set(rows)<=common
    req['points']=[*rows,(1280,318),(1279,318)]
    if folder.is_dir():
        assert not (folder/'results.json').is_file() or read(folder/'results.json')['status']!='qualified'
        folder.rename(root/(folder.name+'-interrupted-'+str(len(list(root.glob(folder.name+'-interrupted-*')))+1)))
    folder.mkdir()
    write(folder/'request.json',req)
    setup=subprocess.STARTUPINFO()
    setup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    setup.wShowWindow=0
    with (folder/'replay.log').open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=folder,env=dict(os.environ,**{key:str(folder)}),startupinfo=setup,stdout=log,stderr=subprocess.STDOUT,timeout=150)
    result=read(folder/'results.json')
    assert child.returncode==0 and result['status']=='qualified',result.get('error')


if key in os.environ:
    try:
        worker()
    except BaseException:
        write(folder/'worker-error.json',dict(error=traceback.format_exc()))
        os._exit(1)
elif __name__=='__main__':
    launch()
