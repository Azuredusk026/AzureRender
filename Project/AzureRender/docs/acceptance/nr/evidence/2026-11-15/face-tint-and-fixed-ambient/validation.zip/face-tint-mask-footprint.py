"""Reconstruct source face-mask filtering at new view-tint residuals."""
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import struct

import numpy as np
from PIL import Image


root=Path(__file__).resolve().parent
stage=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d/native-face-skin-stages'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
source=read(stage/'results.json')
geometry=source['geometry']['804']
paths=[stage/f'{name}-804.bin' for name in ('vertex','index')]
assert [digest(p) for p in paths]==[geometry[n+'Sha256'] for n in ('vertex','index')]
assert (geometry['vertexStride'],geometry['indexStride'],geometry['baseVertex'])==(116,2,0)
vertices=np.fromfile(paths[0],'<f4').reshape(-1,29)
triangles=np.fromfile(paths[1],'<u2').reshape(-1,3)
ndc=vertices[:,:3]/vertices[:,3,None]
screen=(np.rint((ndc[:,:2]+1)*np.asarray([1280,720],np.float32)*256)/256).astype(float)
a,b,c=screen[triangles].transpose(1,0,2)
x0,y0=(b-a).T
x1,y1=(c-a).T
area=x0*y1-x1*y0
safe_area=np.where(area!=0,area,1)
depth=ndc[:,2][triangles].astype(float)
clip_w=vertices[:,3].astype(float)
mips=[]
for record in source['faceTextures']['20']['levels']:
    path=stage/record['path']
    raw=path.read_bytes()
    assert sha256(raw).hexdigest()==record['sha256'] and len(raw)==record['size']
    size=256>>len(mips)
    header=b'DDS '+struct.pack('<31I',124,0x81007,size,size,len(raw),0,1,*([0]*11),32,4,0x30315844,
                               0,0,0,0,0,0x1000,0,0,0,0)
    with Image.open(BytesIO(header+struct.pack('<5I',98,3,0,1,0)+raw)) as image:
        mips.append(np.asarray(image.convert('RGBA'),dtype=float)/255)
assert len(mips)==9


def texel(texture,uv):
    dimensions=np.asarray(texture.shape[:2][::-1])
    coordinate=uv*dimensions-.5
    base=np.floor(coordinate).astype(int)
    frac=np.rint((coordinate-base)*256)/256
    total=np.zeros(4)
    for ox,oy in ((0,0),(1,0),(0,1),(1,1)):
        x,y=np.clip(base+(ox,oy),0,dimensions-1)
        total+=texture[y,x]*(frac[0] if ox else 1-frac[0])*(frac[1] if oy else 1-frac[1])
    return total


def position(point):
    px,py=point
    dx,dy=(np.asarray(point)+.5-a).T
    s,t=(dx*y1-dy*x1)/safe_area,(x0*dy-y0*dx)/safe_area
    weights=np.column_stack([1-s-t,s,t])
    candidates=np.flatnonzero((weights>=-1e-12).all(1)&(area>0))
    assert len(candidates)>0,point
    chosen=int(candidates[np.argmax((weights*depth).sum(1)[candidates])])
    faces=triangles[chosen]
    uv_input=vertices[faces,4:6]

    def uv(point):
        dx,dy=np.asarray(point)+.5-a[chosen]
        s=(dx*y1[chosen]-dy*x1[chosen])/safe_area[chosen]
        t=(x0[chosen]*dy-y0[chosen]*dx)/safe_area[chosen]
        weights=np.asarray([1-s-t,s,t])/clip_w[faces]
        return (weights@uv_input)/weights.sum()

    center=uv(point)
    horizontal=uv((px|1,py))-uv((px&~1,py))
    vertical=uv((px,py|1))-uv((px,py&~1))
    level_float=float(np.log2(256*max(np.linalg.norm(horizontal),np.linalg.norm(vertical)))-1)
    level=int(np.clip(np.floor(level_float+.5),0,len(mips)-1))
    authored,base=texel(mips[level],center),texel(mips[0],center)
    return dict(point=list(point),primitive=chosen,lod=level_float,level=level,authoredRgba=authored.tolist(),
                zeroRgba=base.tolist(),rgbaDifference=(authored-base).tolist(),uv=center.tolist())


def check_trace(row,point,primitive,registers):
    value=np.asarray(registers['70']['r11'])
    assert row['point']==list(point) and row['primitive']==primitive,(row,primitive)
    error=float(np.abs(np.asarray(row['authoredRgba'])-value).max())
    return dict(**row,nativeRgba=value.tolist(),peakFilterError=error)


control_path=root/'trace-face-view-mask.json'
controls=[]
for row in read(control_path)['points']:
    sample=row['sample']
    control=check_trace(position(sample['point']),sample['point'],sample['primitive'],row['registers'])
    assert control['peakFilterError']<=.00061
    controls.append(control)
assert len(controls)==12
introduced=root/'face-tint-combined-introduced-pixels.json'
summary={}
for device,rows in read(introduced).items():
    samples=[dict(**position((row['x'],row['y'])),peakDisplayError=row['peak']) for row in rows]
    by_mip=np.bincount([row['level'] for row in samples],minlength=9).tolist()
    blue=np.asarray([row['rgbaDifference'][2] for row in samples])
    summary[device]=dict(byMip=by_mip,peakBlueChange=float(np.abs(blue).max()),samples=samples)
    print(device,by_mip,summary[device]['peakBlueChange'])
assert summary['nvidia']['byMip'][:3]==[22,7,1] and summary['intel']['byMip'][:3]==[18,9,1]
hardware=root/'face-tint-residual-native/results.json'
native_hardware=[]
if hardware.is_file():
    trace=read(hardware)
    assert trace['status']=='qualified'
    for native in trace['samples']:
        states=native['states']
        row=check_trace(position(native['point']),native['point'],native['primitive'],states)
        row.update(viewWeight=states['351']['r8'][3],viewFactor=states['353']['r18'][:3])
        native_hardware.append(row)
    print('held out',[(row['point'],row['level'],row['peakFilterError']) for row in native_hardware])
report=dict(status='measured-native-and-modeled-residuals',sourceCapture=source['status'],
    controlInputs={p.name:digest(p) for p in (control_path,introduced,*paths)},
    controls=controls,residuals=summary,newNativeControls=native_hardware)
(root/'face-tint-mask-footprint.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
