"""Resolve native D16 producer and identify post-bias hardware depths."""
from hashlib import sha256
import json
from pathlib import Path


run=Path(__file__).resolve().parent
stage=run/'body-atlas-depth-history'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
native_file=stage/'results.json'
source=read(native_file)
request=read(stage/'request.json')
owner_file=run/'body-receiver-atlas-texel-producers.json'
owner=read(owner_file)
assert source['status']=='qualified'
captures=source['captures']
assert captures['native']['format']=='R16_TYPELESS' and 'D16' in captures['current']['format']
assert all(captures[tag]['atlas']==request['captures'][tag]['atlasSha256'] for tag in captures)
taps=owner['differences']['nvidia']['witnesses']
assert len(taps)==5
samples=[]
for left,right,entry in zip(captures['native']['results'],captures['current']['results'],request['points']):
    point=left['point']
    assert point==right['point']==entry['point']
    original=left['finalCommonDepth']
    live=right['finalCommonDepth']
    before=int(original)
    assert live==before+1 and (original,live)==(entry['native'],entry['current'])
    selected=taps[','.join(map(str,point))]
    winner_event=191 if point==[2552,1681] else 237
    assert selected['native']==[winner_event,original] and selected['liveVulkanCode']==live
    last_report=left['history'][-1]
    assert abs(last_report['depthAfter']*65535-before)<.003
    candidates=[h for h in left['history'] if h['event']==winner_event and not
                   any(h[name] for name in ('depthTestFailed','shaderDiscarded','backfaceCulled','stencilTestFailed'))]
    winner=candidates[-1]
    raw=winner['shaderDepth']*65535
    depth_units=raw-8
    assert round(depth_units)==original and 0<depth_units-original<.5
    last_vulkan=right['history'][-1]
    assert abs((1-last_vulkan['depthAfter'])*65535-live)<.003
    quality='draw-level' if last_vulkan['primitive']==0xffffffff else 'per-primitive'
    samples.append(dict(point=point, producer=winner_event,nativePrimitive=winner['primitive'],
         originalDepth=original,currentDepth=live,
         winningShaderDepthUnits=raw,nativeShaderDepthLessEight=depth_units,
         biasedDepthDistanceToUpperHalf=original+.5-depth_units,
         vulkanObservedEvent=last_vulkan['event'],vulkanHistoryGranularity=quality,
         vulkanHistoryDepthFailureFlag=last_vulkan['depthTestFailed'],
         historicalVulkanProducer=selected['historicVulkan'][0]))
print(samples,flush=True)
result=dict(status='measured-native-and-player-d16-depth-history',source=digest(native_file),
           atlasCapture={tag:request['captures'][tag]['inputSha256'] for tag in captures},
           atlasAttachment={tag:captures[tag]['atlas'] for tag in captures},samples=samples,
           nativeThreshold='unchanged',unresolved='vulkan-subpixel-depth')
(run/'body-atlas-hardware-depth-history-analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
