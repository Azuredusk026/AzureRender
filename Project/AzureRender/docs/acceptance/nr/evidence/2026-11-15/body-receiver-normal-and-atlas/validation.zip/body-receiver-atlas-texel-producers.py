"""Attribute body atlas comparison flips to their actual producer events."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import subprocess
import zipfile
import zlib

import numpy as np


root=Path(__file__).resolve().parent
prior=root/'body-receiver-atlas-texels.py'
state={'__file__':str(prior)}
exec(compile(prior.read_text(encoding='utf-8-sig').split('\nrecord=dict(status=',1)[0],str(prior),'exec'),state)
key='Project/AzureRender/docs/acceptance/nr/evidence/2026-11-12/native-atlas-and-receiver-producers'
get=lambda name:subprocess.check_output(['git','show',f'HEAD:{key}/{name}'],cwd=root.parents[2])
retained=readback=get('validation.zip')
identity=json.loads(get('results.json'))
archive=zipfile.ZipFile(BytesIO(retained))
manifests={}
producers={}
atlas_native,paths=state['atlas_native'],state['paths']
report=state['results']
tile=np.s_[1024:2048,2048:3072]
names={ 'native':'native-atlas-producers', 'historicVulkan':'vulkan-atlas-producers'}
texels=sorted({tuple(item['texel']) for sample in report.values() for item in sample['overOneSourceTexels']})
for variant,folder in names.items():
    info=json.loads(archive.read(f'{folder}/{folder}.json'))
    assert info['status']=='qualified'
    manifests[variant]=info['atlasSha256']
    increments={coord:[] for coord in texels}
    previous_mask=None
    all_codes={}
    for name,value in info['stages'].items():
        if 'tile' not in value:continue
        rule=value['tile']
        packed=archive.read(f"{folder}/{rule['path']}")
        assert sha256(packed).hexdigest()==rule['sha256']
        decoded=zlib.decompress(packed)
        assert len(decoded)==len(range(1024))**2*2 and sha256(decoded).hexdigest()==value['tileSha256']
        layer=np.frombuffer(decoded,'<u2').reshape(1024,1024)
        current=layer if variant=='native' else 65535-layer
        for xx,yy in texels:
            old=previous_mask[yy-1024,xx-2048] if previous_mask is not None else 0
            code=current[yy-1024,xx-2048]
            if old!=code:
                increments[(xx,yy)].append([int(name),int(code)])
        previous_mask=current
    assert previous_mask is not None
    if variant=='native':
        np.testing.assert_array_equal(previous_mask,atlas_native[tile])
    for coord,events in increments.items():
        assert events
        all_codes[','.join(map(str,coord))]=events
    producers[variant]=all_codes

used=state['matrix'].reshape(-1,2)
unique=np.unique(used,axis=0)
xx,yy=unique.T
difference_metrics={}
for label,path in paths.items():
    actual_atlas=state['state']['read_atlas'](path)
    differ=65535-actual_atlas[yy,xx].astype('i4')-atlas_native[yy,xx].astype('i4')
    both_filled=(actual_atlas[yy,xx]<65535)&(atlas_native[yy,xx]>0)
    count=lambda deltas:{str(value):int((deltas==value).sum()) for value in (-2,-1,0,1,2)}
    difference_metrics[label]=dict(fullyCovered=int(both_filled.sum()),frequencies=count(differ[both_filled]),
        oneProducerCovered=int(((actual_atlas[yy,xx]<65535)!=(atlas_native[yy,xx]>0)).sum()),
        peak=int(np.abs(differ[both_filled]).max()))
    witnessed={}
    for column,row in texels:
        key=f'{column},{row}'
        native_events=producers['native'][key]
        old_events=producers['historicVulkan'][key]
        witnessed[key]={'native':native_events[-1], 'historicVulkan':old_events[-1],
                         'liveVulkanCode':65535-int(actual_atlas[row,column])}
    difference_metrics[label]['witnesses']=witnessed
    print(label,difference_metrics[label],flush=True)
record=dict(status='measured-body-atlas-producer-ownership',sourceArchive=sha256(retained).hexdigest(),
            archivedAtlas=manifests,producers=producers,differences=difference_metrics)
(root/'body-receiver-atlas-texel-producers.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')

