"""Compare fixed native body normal mips against the raster and BC5 model."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


run=Path(__file__).resolve().parent
analysis=run/'body-receiver-viewport-normal.py'
state={'__file__':str(analysis)}
exec(compile(analysis.read_text().split('\nresult={label:',1)[0],str(analysis),'exec'),state)
source,old=state['source'],state['state']
body,clip,xy,points,vertices,triangles=[source[key] for key in ('body','clip','xy','points','vertices','indices')]
root=run.parent/'20261113-010018-receiver-body-explicit-mips-747472/body-explicit-mips'
manifest=json.loads((root/'body-explicit-mips.json').read_bytes())
assert np.array_equal(np.fromfile(root/'points.bin','<u4').reshape(-1,2),xy)
main=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c')
assert sha256((main/'native-e328.dxbc').read_bytes()).hexdigest()==manifest['devices']['nvidia']['pixelShaderSha256']
assert manifest['devices']['nvidia']['pixelShaderSha256']==manifest['devices']['intel']['pixelShaderSha256']


def packed(data):
    return np.stack([data&1023,(data>>10)&1023],axis=-1).astype('i4')


actual={}
for adapter,record in manifest['devices'].items():
    assert record['baselineRestored'] and record['copyControlExact']
    rows=[]
    for mip,data in record['mips'].items():
        raw=(root/f'{adapter}-mip-{int(mip):02}.bin').read_bytes()
        assert sha256(raw).hexdigest()==data['sha256']
        rows.append(packed(np.frombuffer(raw,'<u4')))
    actual[adapter]=np.stack(rows)


screen=state['viewports']['float32SeparatelyRounded']
owner,_,delta,runner_up,_=source['locate'](screen)
eligible=(delta<=1)&(runner_up>delta)
holdout=(xy[:,0]%7+3*xy[:,1]%7)%7>=4
assert 8200<eligible.sum()<=8827 and 3000<(holdout&eligible).sum()<4000
q=triangles[owner]
a,b,c=screen[q].transpose(1,0,2)
ab,ac=b-a,c-a
det=ab[:,0]*ac[:,1]-ab[:,1]*ac[:,0]
orientation=np.where(det<0,1.,-1.)
old.update(a=a,ab=ab,ac=ac,det=det,inv_w=1/clip[q,3])
interpolate=old['interpolate']
frame=interpolate(points,vertices[q,9:16])
normal,tangent=frame[:,:3],frame[:,3:6]
handedness=frame[:,6:7]
coords=interpolate(points,vertices[q,4:6])
bitangent=np.cross(normal,tangent)*handedness
old.update(coordinates=coords,normal=normal,tangent=tangent,bitangent=bitangent)


def f32(x):
    return np.asarray(x,np.float32)


def fma(a,b,c):
    return f32(np.asarray(a,np.float64)*np.asarray(b,np.float64)+np.asarray(c,np.float64))


def dot(a,b):
    return fma(a[:,2],b[:,2],fma(a[:,1],b[:,1],f32(a[:,0]*b[:,0])))


def normalize(value):
    return value*f32(1.0/np.sqrt(dot(value,value)))[:,None]


def ordered_pack(sample,encoded_precision=None):
    if encoded_precision:
        sample=np.rint(sample*encoded_precision)/encoded_precision
    raw=f32(sample/255)
    nxy=fma(raw,2.,-1.)
    nz=np.sqrt(np.maximum(f32(1)-np.minimum(fma(nxy[:,1],nxy[:,1],nxy[:,0]*nxy[:,0]),f32(1)),f32(0)))
    n,t=f32(normal),f32(tangent)
    indices=[1,2,0]
    inverted=[2,0,1]
    b=fma(n[:,indices],t[:,inverted],-(n[:,inverted]*t[:,indices]))*f32(handedness)
    basis=fma(nz[:,None],n,fma(nxy[:,0:1],t,b*nxy[:,1:2]))
    basis=normalize(normalize(basis)*f32(orientation[:,None]))
    total=f32(np.abs(basis[:,0])+np.abs(basis[:,1]))+np.abs(basis[:,2])
    mapped=basis[:,[0,2]]/total[:,None]
    signs=np.where(mapped>=0,f32(1),f32(-1))
    fold=(f32(1)-np.abs(mapped[:,::-1]))*signs
    mapped=np.where(basis[:,1:2]<=0,fold,mapped)
    return np.rint(np.clip(fma(mapped,.5,.5).astype(float),0,1)*1023).astype('i4')


def sample(tex,precision,rounding,kind):
    address=(f32(coords) if kind=='float32' else coords)*len(tex)-.5
    lower=np.floor(address)
    relative=address-lower
    if precision:
        relative=rounding(relative*precision)/precision
    lower=lower.astype('i8')
    x0,y0=(lower%len(tex)).T
    x1,y1=((lower+1)%len(tex)).T
    fx,fy=relative[:,0:1],relative[:,1:2]
    return (tex[y0,x0]*(1-fx)+tex[y0,x1]*fx)*(1-fy)+(tex[y1,x0]*(1-fx)+tex[y1,x1]*fx)*fy


modes={'fractional':state['levels']['fractional'],'rounded':state['levels']['rounded']}
for n in (4095,65535):
    modes[f'unorm{n}']=[np.rint(t*(n/255))*(255/n) for t in modes['fractional']]
configs=[(decode,precision,rounding,address,arithmetic,None)
         for decode in modes
         for precision,rounding in ((0,'round'),(64,'round'),(128,'round'),(256,'round'),(256,'floor'),(512,'round'),(1024,'round'))
         for address in ('double','float32')
         for arithmetic in ('double','float32')]
configs += [('fractional',256,'round','float32','float32',precision) for precision in (1,16,256)]
counts={}
for decode,precision,rounding,address,arithmetic,sample_round in configs:
    predicted=[]
    for texture in modes[decode]:
        encoded=sample(texture,precision,{'round': np.rint,'floor': np.floor}[rounding],address)
        predicted.append(old['pack'](encoded,orientation) if arithmetic=='double' else ordered_pack(encoded,sample_round))
    predicted=np.stack(predicted)
    name='-'.join(map(str,(decode,precision,rounding,address,arithmetic,sample_round)))
    counts[name]={}
    for adapter,target in actual.items():
        delta=np.abs(predicted-target).max(axis=-1)
        equality=lambda chosen:(delta[:,chosen]==0).sum(axis=1).tolist()
        over=lambda chosen:(delta[:,chosen]>1).sum(axis=1).tolist()
        counts[name][adapter]=dict(exact=equality(eligible),aboveOne=over(eligible),
            calibrationExact=equality(eligible&~holdout),heldOutExact=equality(eligible&holdout),
            heldOutAboveOne=over(eligible&holdout),worst=delta[:,eligible].max(axis=1).tolist())
    if name=='fractional-256-round-double-double-None':
        base=predicted


base_name='fractional-256-round-double-double-None'
both=actual['nvidia']-actual['intel']
result=dict(status='measured-native-body-explicit-mip-reconstruction',scope=len(xy),qualified=int(eligible.sum()),
    heldOut=int((eligible&holdout).sum()),sourceSha256=manifest['devices']['nvidia']['pixelShaderSha256'],
    sourceExplicitManifestSha256=sha256((root/'body-explicit-mips.json').read_bytes()).hexdigest(),
    sourceTextureSha256=sha256(old['raw']).hexdigest(),baseline=base_name,options=counts, adapters={})
for label in actual:
    exact=lambda mode,split,mips:sum(counts[mode][label][split][m] for m in mips)
    groups={'all':range(11),'authoredFirstThree':range(3),'constantMip':[10]}
    result['adapters'][label]={}
    for group,mips in groups.items():
        best=sorted(counts,key=lambda key:-exact(key,'calibrationExact',mips))[:6]
        best=[base_name,*best]
        result['adapters'][label][group]={key:dict(fit=exact(key,'calibrationExact',mips),
                                                    heldOut=exact(key,'heldOutExact',mips),
                                                    heldOutOverOne=exact(key,'heldOutAboveOne',mips)) for key in best}
    print(label,result['adapters'][label],flush=True)
result['adapterAttachmentDifferences']=(np.abs(both[:,eligible]).max(axis=-1)>0).sum(axis=1).tolist()
result['adapterAttachmentDifferencesOverOne']=(np.abs(both[:,eligible]).max(axis=-1)>1).sum(axis=1).tolist()
print('eligible',result['qualified'],'heldout',result['heldOut'],'adapterMismatches',result['adapterAttachmentDifferences'],
      'overOne',result['adapterAttachmentDifferencesOverOne'],flush=True)
(run/'body-receiver-normal-explicit-reconstruction.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')

