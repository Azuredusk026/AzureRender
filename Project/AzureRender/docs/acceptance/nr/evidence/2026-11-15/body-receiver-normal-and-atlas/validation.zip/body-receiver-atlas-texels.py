"""Identify D16 texels that change body receiver comparisons on retained inputs."""
from hashlib import sha256
from pathlib import Path
import json

import numpy as np


root=Path(__file__).resolve().parent
prior=root/'body-receiver-physical-inputs.py'
state={'__file__':str(prior)}
exec(compile(prior.read_text(encoding='utf-8-sig').split('\ncases=tuple',1)[0],str(prior),'exec'),state)
x,y,depth,normals,atlas_native,ref,native_vis,paths,dims,disk,low,high,rect,radius=[
    state[key] for key in ('x','y','native_depth','native_normals','d3d_atlas','ref','native_render','paths',
                           'dims','disk','low','high','rectangle','filter_radius')]
emulate,fma=state['emulate'],state['fma']
_,native_count,positions=emulate(x,y,depth,normals,atlas_native,False)
assert len(x)==9116
def taps():
    uv=fma(positions[:,:2],rect[2:],rect[:2])
    rotation=disk[((x&3)<<2)|(y&3),:2]
    for index,(dx,dy) in enumerate(disk[:,2:]):
        rx=fma(dx,rotation[:,0],-dy*rotation[:,1])
        ry=fma(dy,rotation[:,0],dx*rotation[:,1])
        sample=fma(np.column_stack((rx,ry)),radius,uv)
        base=np.floor(np.rint((sample*dims.astype(np.float32)-.5)*256)/256).astype('i4')
        for corner,shift in enumerate(((0,1),(1,1),(1,0),(0,0))):
            yield index,corner,base+shift


points=np.column_stack((x,y))
matrix=np.stack([target for _,_,target in taps()],axis=1)
valid=(matrix>=low).all(2)&(matrix<high).all(2)
assert np.all(valid)
reference=atlas_native[matrix[:,:,1],matrix[:,:,0]]
native_active=reference.astype(np.float32)/np.float32(65535)>=positions[:,2,None]
np.testing.assert_array_equal(native_active.sum(1),native_count)
results={}
for tag,source in paths.items():
    data=state['read_atlas'](source)
    assert state['hash_file'](source)==state['atlas_manifest'][tag]['sha256']
    bits=65535-data[matrix[:,:,1],matrix[:,:,0]].astype(np.int32)
    actual_active=np.float32(1)-data[matrix[:,:,1],matrix[:,:,0]].astype(np.float32)/np.float32(65535)>=positions[:,2,None]
    actual_vis,actual_count,_=emulate(x,y,depth,normals,data,True)
    np.testing.assert_array_equal(actual_active.sum(1),actual_count)
    selected=np.abs(actual_vis-ref)>1
    changes={}
    witnesses=[]
    delta=actual_active!=native_active
    for lane in np.flatnonzero(selected):
        distances=[]
        for index in np.flatnonzero(delta[lane]):
            xx,yy=matrix[lane,index]
            src=int(reference[lane,index])
            dst=int(bits[lane,index])
            tap=dict(texel=[int(xx),int(yy)],nativeCode=src,playerCode=dst,delta=dst-src,
                     before=bool(native_active[lane,index]),after=bool(actual_active[lane,index]))
            locations=changes.setdefault((int(xx),int(yy)),{**tap,'bodyPoints':[]})
            locations['bodyPoints'].append(points[lane].tolist())
            distances.append(dict(**tap,tapNumber=int(index)))
        witnesses.append(dict(point=points[lane].tolist(),nativeTarget=int(ref[lane]),nativeModel=int(native_vis[lane]),
            playerAtlasOnly=int(actual_vis[lane]),depth=float(positions[lane,2]),receiverDepthAtlasCode=float(positions[lane,2]*65535),
            nativeTapCount=int(native_count[lane]),playerTapCount=int(actual_count[lane]),flipped=distances))

    flip_mask=delta.any(1)
    different_codes=bits!=reference
    selected_matrix=matrix[delta]
    common={tuple(key):int(n) for key,n in zip(*np.unique(selected_matrix,axis=0,return_counts=True))}
    results[tag]=dict(visitedDistinctTexels=int(len(np.unique(matrix.reshape(-1,2),axis=0))),
        sampledCodeDifferences=int(different_codes.sum()),sampledComparisonDifferences=int(delta.sum()),
        pointsWithComparisonDifference=int(flip_mask.sum()),comparisonDifferencesAtOverOne=int(delta[selected].sum()),
        pointsWithAtlasOnlyError=len(witnesses),witnesses=witnesses,overOneSourceTexels=[
            dict(**value,comparisonOccurrencesAtAllPoints=common[key]) for key,value in changes.items()])
    print(tag,'visited',results[tag]['visitedDistinctTexels'],'comparisons',int(delta.sum()),
          'points',int(flip_mask.sum()),'witnesses',witnesses,flush=True)

record=dict(status='measured-retained-body-atlas-texel-ownership',scope=len(points),sourceDepthIsNative=True,
    sourceNormalsAreNative=True,channelBits=16,devices=results,
    confirmationSha256=sha256((root/'body-receiver-physical-inputs.json').read_bytes()).hexdigest())
(root/'body-receiver-atlas-texels.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')

