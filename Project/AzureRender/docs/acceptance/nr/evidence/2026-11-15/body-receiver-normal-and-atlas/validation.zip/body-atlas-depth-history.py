"""Read both shadow atlas attachments and their per-texel depth history."""
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import traceback


key='AZURE_NR_ATLAS_DEPTH_HISTORY'
run=Path(os.environ[key]).parent if key in os.environ else Path(__file__).resolve().parent
out=run/'body-atlas-depth-history'
read=lambda path:json.loads(path.read_bytes())
write=lambda path,value:path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
vulkan=run.parent/'20261112-041837-reference-object-shadow-raster-capture-60f161'


def worker():
    import renderdoc as rd
    report=dict(status='failed',captures={})
    req=read(out/'request.json')
    try:
        for tag,source in req['captures'].items():
            capture=rd.OpenCaptureFile()
            controller=None
            try:
                assert capture.OpenFile(source['input'],'',None)==rd.ResultCode.Succeeded
                flags=rd.ReplayOptions()
                flags.forceGPUVendor=rd.GPUVendor.nVidia
                flags.forceGPUDeviceID=0x28e0
                status,controller=capture.OpenCapture(flags,None)
                assert status==rd.ResultCode.Succeeded and controller
                props=controller.GetAPIProperties()
                pipeline=rd.GraphicsAPI.D3D11 if tag=='native' else rd.GraphicsAPI.Vulkan
                assert props.pipelineType==pipeline and props.vendor==rd.GPUVendor.nVidia and not props.degraded
                texture,=[item for item in controller.GetTextures() if str(item.resourceId)==source['atlasResource']]
                assert (texture.width,texture.height)==(4096,2048)
                assert texture.format.Name()=='R16_TYPELESS' if tag=='native' else 'D16' in texture.format.Name()
                resource=texture.resourceId
                controller.SetFrameEvent(source['observer'],True)
                attachment=bytes(controller.GetTextureData(resource,rd.Subresource()))
                assert len(attachment)==4096*2048*2 and sha256(attachment).hexdigest()==source['atlasSha256']
                records=[]
                def sane(value):
                    return float(value) if value is not None and math.isfinite(value) and value>=0 else None
                for row in req['points']:
                    x,y=row['point']
                    actual=struct.unpack_from('<H',attachment,(y*4096+x)*2)[0]
                    if tag!='native':
                        actual=65535-actual
                    assert actual==row[tag],(row,actual)
                    values=[]
                    result=None
                    for comp_type in (rd.CompType.Typeless,getattr(rd.CompType,'Depth',rd.CompType.Typeless)):
                        controller.SetFrameEvent(source['observer'],True)
                        trial=controller.PixelHistory(resource,x,y,rd.Subresource(),comp_type)
                        if trial:
                            result=trial
                            break
                    assert result,(tag,row)
                    for fragment in result:
                        if int(fragment.eventId)>source['observer']:
                            continue
                        values.append(dict(event=int(fragment.eventId),primitive=int(fragment.primitiveID),
                            depthBefore=sane(fragment.preMod.depth),shaderDepth=sane(fragment.shaderOut.depth),
                            depthAfter=sane(fragment.postMod.depth),depthTestFailed=bool(fragment.depthTestFailed),
                            shaderDiscarded=bool(fragment.shaderDiscarded),backfaceCulled=bool(fragment.backfaceCulled),
                            stencilTestFailed=bool(fragment.stencilTestFailed)))
                    assert values,(tag,row)
                    records.append(dict(point=row['point'],finalCommonDepth=actual,history=values,componentType=str(comp_type)))
                report['captures'][tag]=dict(atlas=source['atlasSha256'],format=texture.format.Name(),
                    observer=source['observer'],results=records,messages=[item.description for item in controller.GetDebugMessages()])
            finally:
                if controller:controller.Shutdown()
                capture.Shutdown()
        report['status']='qualified'
    except Exception:
        report['error']=traceback.format_exc()
    finally:
        write(out/'results.json',report)
    os._exit(0 if report['status']=='qualified' else 1)


def launch():
    from hashlib import file_digest
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==run
    helper=read(grid/'native-face-masks/request.json')
    vk=read(vulkan/'shadow-raster-gpu-proof.json')
    points=read(run/'body-receiver-atlas-texel-producers.json')['differences']['nvidia']['witnesses']
    assert len(points)==5
    expected={
        'native':dict(input=helper['native'],inputSha256=helper['captureSha256'],
                      observer=699,atlasResource='ResourceId::158089',
                      atlasSha256='86daee0e01e9c33207679b094bdf5cf31a26d2f93754f11abf6c44df1faecf57'),
        'current':dict(input=vk['capture']['path'],inputSha256=vk['capture']['sha256'],
                       observer=vk['event'],atlasResource=vk['atlas']['resource'],atlasSha256=vk['atlas']['sha256']),
    }
    for capture in expected.values():
        with Path(capture['input']).open('rb') as stream:
            assert file_digest(stream,'sha256').hexdigest()==capture['inputSha256']
    if out.exists():
        assert not (out/'results.json').exists() or read(out/'results.json')['status']!='qualified'
        out.rename(out.with_name(out.name+'-interrupted-'+str(1+len(list(run.glob(out.name+'-interrupted-*'))))))
    out.mkdir()
    write(out/'request.json',dict(captures=expected,points=[
        dict(point=list(map(int,point.split(','))),native=row['native'][-1],current=row['liveVulkanCode'])
        for point,row in points.items()]))
    environment=dict(os.environ,**{key:str(out)})
    environment['VK_DRIVER_FILES']=str(grid/'nv-vk64-active-absolute.json')
    setup=subprocess.STARTUPINFO()
    setup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    setup.wShowWindow=0
    with (out/'replay.log').open('wb') as log:
        result=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=out,env=environment,stdout=log,stderr=subprocess.STDOUT,startupinfo=setup,timeout=190)
    report=read(out/'results.json')
    assert result.returncode==0 and report['status']=='qualified',report.get('error')


if key in os.environ:
    try:
        worker()
    except BaseException:
        write(out/'worker-error.json',dict(error=traceback.format_exc()))
        os._exit(1)
elif __name__=='__main__':
    launch()

