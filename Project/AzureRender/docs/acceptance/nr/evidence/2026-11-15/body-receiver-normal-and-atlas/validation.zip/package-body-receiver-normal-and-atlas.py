"""Archive fixed-mip measurements and verified body atlas texel provenance."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


run=Path(__file__).resolve().parent
archive_root=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/body-receiver-normal-and-atlas'
read=lambda path:json.loads(path.read_bytes())
digest=lambda raw:sha256(raw).hexdigest()
normal=read(run/'body-receiver-normal-explicit-reconstruction.json')
texels=read(run/'body-receiver-atlas-texels.json')
owners=read(run/'body-receiver-atlas-texel-producers.json')
assert normal['scope']==texels['scope']==9116 and normal['qualified']==8827 and normal['heldOut']==3793
assert normal['status']=='measured-native-body-explicit-mip-reconstruction'
assert texels['status']=='measured-retained-body-atlas-texel-ownership'
assert owners['status']=='measured-body-atlas-producer-ownership'
assert len(owners['producers']['native'])==5
assert [codes[-1][0] for codes in owners['producers']['native'].values()].count(237)==4
base=normal['options'][normal['baseline']]
normal_metrics={}
atlas_metrics={}
for label,exact,over,flip,count in [('nvidia',77216,61,6,5),('intel',94596,0,2,2)]:
    assert sum(base[label]['exact'])==exact and sum(base[label]['aboveOne'])==over
    normal_metrics[label]=dict(exact=exact,overOne=over,perMipOverOne=base[label]['aboveOne'])
    pixels=texels['devices'][label]
    assert pixels['pointsWithAtlasOnlyError']==count and pixels['sampledComparisonDifferences']==flip
    assert all(tap['delta']==1 for row in pixels['witnesses'] for tap in row['flipped'])
    measurements=owners['differences'][label]
    assert measurements['oneProducerCovered']==0 and pixels['visitedDistinctTexels']==10922
    atlas_metrics[label]=dict(onlyAtlasOverOne=count,comparisonFlips=flip,
        largestDisplayDifference=max(abs(row['nativeTarget']-row['playerAtlasOnly']) for row in pixels['witnesses']),
        nativeProducerMapping=measurements['witnesses'],sampledCodeDifferences=measurements['frequencies'])
members=['package-body-receiver-normal-and-atlas.py','body-receiver-normal-explicit-reconstruction.py',
    'body-receiver-normal-explicit-reconstruction.json','body-receiver-atlas-texels.py','body-receiver-atlas-texels.json',
    'body-receiver-atlas-texel-producers.py','body-receiver-atlas-texel-producers.json']
archive_root.mkdir(parents=True,exist_ok=True)
file=archive_root/'validation.zip'
with ZipFile(file,'w',ZIP_DEFLATED) as archive:
    for name in members:archive.write(run/name,name)
with ZipFile(file) as archive:
    assert archive.testzip() is None
    manifest={name:digest(archive.read(name)) for name in members}
assert manifest=={name:digest((run/name).read_bytes()) for name in members}
result=dict(status='measured-native-body-receiver-normal-and-atlas',overall='failed-user-review',
    originalScope=normal['scope'],qualifiedNormalGeometry=normal['qualified'],heldOutNormals=normal['heldOut'],
    explicitNormalMipCount=11,normalMetrics=normal_metrics,atlasMetrics=atlas_metrics,distinctAtlasTexels=10922,
    residualAtlasTexels=5,nativeAtlasProducerEvents=owners['producers']['native'],
    sourceInputs=dict(pixelShader=normal['sourceSha256'],mipManifest=normal['sourceExplicitManifestSha256'],
        normalTexture=normal['sourceTextureSha256'],atlasValidation=owners['sourceArchive'],
        visibilityModel=texels['confirmationSha256']),
    archive=dict(sha256=digest(file.read_bytes()),members=manifest))
(archive_root/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(normal_metrics,flush=True)

