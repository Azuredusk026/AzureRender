"""Measure original skin coverage by last native draw on paired Player images."""
from hashlib import file_digest
import gzip
import json
from pathlib import Path
import runpy
import sys
import cv2
import numpy as np
from PIL import Image


root=Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
radial=root.parent/'20261114-051632-face-local-radial-light-retest-ea8fb6'
cloth=root.parent/'20261114-144753-cloth-directional-rim-actual-4b9034'
read=lambda p:json.loads(p.read_bytes())
score=runpy.run_path(str(grid/'static-quality.py'))
reference=score['image'](score['reference_path'])
base=grid/'native-face-masks/skin.png'
with Image.open(base) as image:
    skin=np.asarray(image.convert('L'))>0
assert int(skin.sum())==47458
owner=np.zeros(skin.shape,dtype=np.uint16)
native_attachment_inputs=[]

def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()

assets=score['cloth']
for record in read(assets/'variant-targets.json')['draws']:
    if record['event']==1383:continue
    paths=[assets/'variant-targets'/entry['path'] for entry in record['outputs']]
    a,b=map(score['native_words'],paths)
    owner[(a!=b)&skin]=record['event']
    native_attachment_inputs.extend(paths)
stored=score['stages']/'post-opaque-ownership'
for record in read(stored/'manifest.json')['events']:
    paths=[stored/name for name in record['files']]
    a,b=[np.frombuffer(gzip.decompress(p.read_bytes()),'<u4').reshape(skin.shape)[::-1] for p in paths]
    owner[(a!=b)&skin]=record['event']
    native_attachment_inputs.extend(paths)
regions={'completeSkinCoverage':skin}
counts={str(value):int(count) for value,count in zip(*np.unique(owner[skin],return_counts=True))}
for event,count in counts.items():
    if count>=80:regions[event]=skin&(owner==int(event))
assert counts['0']==43647
assert counts['1383']==2878
distance=cv2.distanceTransform(skin.astype(np.uint8),cv2.DIST_L2,5)
earlier=skin&(owner==0)
devices={}
for device in ('nvidia','intel'):
    frames={
        'radialFace':radial/f'production-{device}-enabled/frames/frame_000000.png',
        'outlineHighlights':root/f'body-outline-beauty-transparent-highlights-{device}/frames/frame_000000.png',
        'clothDirectional':cloth/f'cloth-directional-{device}/frames/frame_000000.png',
    }
    if 'captured-rim' in sys.argv:
        frames['capturedOutlineOrigin']=root/f'body-outline-beauty-transparent-highlights-captured-origin-{device}/frames/frame_000000.png'
    devices[device]={}
    for version,p in frames.items():
        img=score['image'](p)
        measurements=score['compare'](reference,img,regions)
        errors=np.abs(reference.astype(np.int16)-img.astype(np.int16)).max(2)
        for name,mask in regions.items():
            selection=errors[mask]
            measurements[name].update(overOne=int((selection>1).sum()),overEight=int((selection>8).sum()),peak=int(selection.max()))
        edge={}
        if version in ('outlineHighlights','capturedOutlineOrigin'):
            edge['samples']=[dict(pixels=int(selection.sum()),outsideDistance=margin,
                                  overOne=int((errors[selection]>1).sum()),
                                  overEight=int((errors[selection]>8).sum()))
                             for margin in (0,1,2,3,4,5,6,8,12,16)
                             for selection in (earlier&(distance>margin),)]
            large=earlier&(errors>8)
            assert not np.any(large&(distance>6))
            edge['maxDistanceForOverEight']=float(distance[large].max(initial=0))
            location=np.unravel_index(np.argmax(np.where(earlier,errors,-1)),skin.shape)
            edge['worst']=dict(point=[int(location[1]),int(location[0])],reference=reference[location].tolist(),
                               player=img[location].tolist(),error=int(errors[location]))
        devices[device][version]=dict(frame=digest(p),metrics=measurements,boundary=edge)
        print(device,version,'skin',measurements['completeSkinCoverage'],'cloth',measurements['1383'],flush=True)
data=dict(status='measured-native-skin-surface-composition',reference=digest(score['reference_path']),
    mask=digest(base),nativeEvents=counts,normalExit=True,devices=devices,
    nativeAttachments={str(item):digest(item) for item in native_attachment_inputs})
(root/'body-skin-coverage-composition.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
