"""Package validated skin-region comparisons without duplicating capture images."""
from hashlib import file_digest
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile


root=Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
radial=root.parent/'20261114-051632-face-local-radial-light-retest-ea8fb6'
cloth=root.parent/'20261114-144753-cloth-directional-rim-actual-4b9034'
target=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/body-skin-coverage-composition'
record=root/'body-skin-coverage-composition.json'
read=lambda p:json.loads(p.read_bytes())


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


data=read(record)
assert data['status']=='measured-native-skin-surface-composition'
assert data['nativeEvents']=={'0':43647,'1018':89,'1038':39,'1079':577,'1116':228,'1383':2878}
files={
    record.name:record,
    'script.py':root/'body-skin-coverage-composition.py',
    'archive.py':Path(__file__),
    'skin.png':grid/'native-face-masks/skin.png',
    'mask-source.json':grid/'native-face-masks/result.json',
}
assert digest(files['skin.png'])==data['mask']==read(files['mask-source.json'])['masks']['skin']['sha256']
for device,expected_cloth,expected_interior in (('nvidia',260,11018),('intel',262,10522)):
    versions=data['devices'][device]
    outline=versions['outlineHighlights']
    boundary=outline['boundary']
    assert boundary['samples'][0]['overEight']==444
    assert boundary['samples'][6]==dict(pixels=30561,outsideDistance=6,overOne=expected_interior,overEight=0)
    assert 5.3<boundary['maxDistanceForOverEight']<5.5
    assert boundary['worst']['point']==[1197,854] and boundary['worst']['error']==81
    assert versions['radialFace']['metrics']['1383']['overEight']==1000
    assert versions['clothDirectional']['metrics']['1383']['overEight']==expected_cloth
    assert outline['metrics']['completeSkinCoverage']['passed']
    for variant,folder in (('radialFace',radial/f'production-{device}-enabled'),
                           ('outlineHighlights',root/f'body-outline-beauty-transparent-highlights-{device}'),
                           ('clothDirectional',cloth/f'cloth-directional-{device}')):
        frame=folder/'frames/frame_000000.png'
        assert digest(frame)==versions[variant]['frame']
        for name in ('command.json','frames/gpu_capabilities.json','frames/capture_manifest.json','results.json'):
            if (folder/name).is_file():files[f'{device}/{variant}/{name}']=folder/name
target.mkdir(parents=True,exist_ok=True)
package=target/'validation.zip'
with ZipFile(package,'w',ZIP_DEFLATED) as archive:
    for name,path in files.items():archive.write(path,name)
with ZipFile(package) as archive:
    assert archive.testzip() is None
    members={name:archive.read(name) for name in files}
assert members=={name:path.read_bytes() for name,path in files.items()}
from hashlib import sha256
data['archive']=dict(sha256=digest(package),members={name:sha256(blob).hexdigest() for name,blob in members.items()})
(target/'results.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
print(target)
