Shader hash 470960a7-cb4a1ba0-d458436f-4eb55c2a

ps_5_0
      dcl_globalFlags refactoringAllowed
      dcl_constantbuffer cb0[45], immediateIndexed
      dcl_constantbuffer cb1[141], immediateIndexed
      dcl_constantbuffer cb2[4086], dynamicIndexed
      dcl_constantbuffer cb3[2054], dynamicIndexed
      dcl_constantbuffer cb4[4], immediateIndexed
      dcl_constantbuffer cb5[66], immediateIndexed
      dcl_constantbuffer cb6[17], immediateIndexed
      dcl_sampler s0, mode_default
      dcl_sampler s1, mode_default
      dcl_sampler s2, mode_comparison
      dcl_resource_structured t0, 4
      dcl_resource_structured t1, 16
      dcl_resource_raw t2
      dcl_resource_texture2d (float,float,float,float) t3
      dcl_resource_texture2d (float,float,float,float) t4
      dcl_resource_texture3d (float,float,float,float) t5
      dcl_resource_texture3d (float,float,float,float) t6
      dcl_resource_texture3d (float,float,float,float) t7
      dcl_resource_texture3d (float,float,float,float) t8
      dcl_resource_texture3d (float,float,float,float) t9
      dcl_resource_texture3d (float,float,float,float) t10
      dcl_resource_texture2d (float,float,float,float) t11
      dcl_resource_texture2d (float,float,float,float) t12
      dcl_resource_texture2d (float,float,float,float) t13
      dcl_resource_texture2d (float,float,float,float) t14
      dcl_resource_texture3d (float,float,float,float) t15
      dcl_input_ps_siv linear noperspective v0.w, position
      dcl_input_ps linear v1.xy
      dcl_input_ps linear v2.xyz
      dcl_input_ps linear v3.xyz
      dcl_input_ps linear v5.xyz
      dcl_input_ps linear v6.xyz
      dcl_input_ps nointerpolation v7.x
      dcl_output o0.xyzw
      dcl_output o1.xyzw
      dcl_temps 30
   0: mov r0.x, cb0[0].z
   1: mov r0.y, cb0[1].z
   2: mov r0.z, cb0[2].z
   3: add r1.xyz, r0.xyzx, v2.xyzx
   4: mad r1.xyz, cb1[4].wwww, r1.xyzx, -v2.xyzx
   5: dp3 r0.w, r1.xyzx, r1.xyzx
   6: max r1.w, r0.w, l(0.000000)
   7: rsq r1.w, r1.w
   8: mul r1.xyz, r1.wwww, r1.xyzx
   9: ishl r2.x, v7.x, l(4)
  10: and r2.y, l(16), cb2[r2.x + 4].w
  11: if_nz r2.y
  12:   iadd r2.y, l(2), cb2[r2.x + 5].x
  13:   ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r3.x, r2.y, l(12), t1.xxxx
  14:   ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r3.y, cb2[r2.x + 5].x, l(12), t1.xxxx
  15: else
  16:   mov r3.xy, cb2[r2.x + 3].zxzz
  17: endif
  18: sample_b(texture2d)(float,float,float,float) r2.yzw, v1.xyxx, t14.wxyz, s1, cb1[26].x
  19: add r4.xyz, v2.xyzx, cb0[44].xyzx
  20: add r3.xz, -r3.yyxy, r4.xxzx
  21: dp3 r3.w, v3.xyzx, v3.xyzx
  22: rsq r3.w, r3.w
  23: mul r5.xyz, r3.wwww, v3.xyzx
  24: mov r3.y, l(0.000061)
  25: dp3 r3.w, r3.xyzx, r3.xyzx
  26: rsq r3.w, r3.w
  27: mul r3.xyz, r3.wwww, r3.xyzx
  28: ne r3.w, l(0), cb6[15].w
  29: mul r2.yzw, r2.yyzw, cb6[6].xxyz
  30: mul r6.xyz, r2.yzwy, cb6[14].zzzz
  31: dp3 r4.w, r6.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
  32: mad r2.yzw, r2.yyzw, cb6[14].zzzz, -r4.wwww
  33: mad r2.yzw, cb6[14].wwww, r2.yyzw, r4.wwww
  34: movc r2.yzw, r3.wwww, cb6[16].xxyz, r2.yyzw
  35: mul r6.xyz, r2.wyzw, l(12.920000, 12.920000, 12.920000, 0.000000)
  36: log r7.xyz, abs(r2.wyzw)
  37: mul r7.xyz, r7.xyzx, l(0.416667, 0.416667, 0.416667, 0.000000)
  38: exp r7.xyz, r7.xyzx
  39: mad r7.xyz, r7.xyzx, l(1.055000, 1.055000, 1.055000, 0.000000), l(-0.055000, -0.055000, -0.055000, 0.000000)
  40: ge r8.xyz, l(0.003131, 0.003131, 0.003131, 0.000000), r2.wyzw
  41: movc_sat r6.xyz, r8.xyzx, r6.xyzx, r7.xyzx
  42: mul r7.xw, r6.xxxz, l(31.000000, 0.000000, 0.000000, 0.968750)
  43: round_ni r3.w, r7.x
  44: mad r7.yz, r6.yyzy, l(0.000000, 0.030273, 0.968750, 0.000000), l(0.000000, 0.000488, 0.015625, 0.000000)
  45: mad r7.x, r3.w, l(0.031250), r7.y
  46: mul r6.yzw, v2.yyyy, cb0[33].xxyw
  47: mad r6.yzw, cb0[32].xxyw, v2.xxxx, r6.yyzw
  48: mad r6.yzw, cb0[34].xxyw, v2.zzzz, r6.yyzw
  49: add r6.yzw, r6.yyzw, cb0[35].xxyw
  50: mul r8.xy, r6.wwww, cb1[19].zwzz
  51: mad r6.yz, -r8.xxyx, l(0.000000, 2.000000, -2.000000, 0.000000), r6.yyzy
  52: div r6.yz, r6.yyzy, r6.wwww
  53: mad r8.xy, r6.yzyy, l(0.500000, 0.500000, 0.000000, 0.000000), l(0.500000, 0.500000, 0.000000, 0.000000)
  54: add r8.z, -r8.y, l(1.000000)
  55: mul r6.yz, r8.xxzx, cb1[0].xxyx
  56: ftou r8.xy, r6.yzyy
  57: mov r8.z, l(0)
  58: ld_indexable(texture2d)(float,float,float,float) r6.yz, r8.xyzz, t13.zxyw
  59: mad r6.yz, r6.yyzy, l(0.000000, 2.000000, 2.000000, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
  60: dp2 r4.w, l(1.000000, 1.000000, 0.000000, 0.000000), abs(r6.yzyy)
  61: add r9.y, -r4.w, l(1.000000)
  62: lt r4.w, r9.y, l(0)
  63: ge r10.xy, r6.yzyy, l(0, 0, 0, 0)
  64: add r10.zw, -abs(r6.zzzy), l(0.000000, 0.000000, 1.000000, 1.000000)
  65: movc r10.xy, r10.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
  66: mul r10.xy, r10.xyxx, r10.zwzz
  67: movc r9.xz, r4.wwww, r10.xxyx, r6.yyzy
  68: dp3 r4.w, r9.xyzx, r9.xyzx
  69: rsq r4.w, r4.w
  70: mul r9.xyz, r4.wwww, r9.xyzx
  71: add r4.w, l(1.000000), -cb1[29].x
  72: mad r4.w, cb1[122].w, r4.w, cb1[29].x
  73: mul r4.w, r4.w, cb1[27].x
  74: lt r5.w, cb1[111].y, l(0.500000)
  75: if_nz r5.w
  76:   mad r6.yzw, cb0[6].xxzy, -cb1[137].wwww, cb1[135].xxzy
  77:   add r6.yzw, r4.xxzy, -r6.yyzw
  78:   max r5.w, abs(r6.z), abs(r6.y)
  79:   add r5.w, r5.w, l(-464.000000)
  80:   mul_sat r5.w, r5.w, l(0.031250)
  81:   add r6.y, abs(r6.w), l(-208.000000)
  82:   mul_sat r6.y, r6.y, l(0.031250)
  83:   max r5.w, r5.w, r6.y
  84:   ne r6.y, l(0), cb1[135].w
  85:   lt r6.z, r5.w, l(1.000000)
  86:   and r6.y, r6.z, r6.y
  87:   if_nz r6.y
  88:     mad r6.yzw, cb0[6].xxzy, -cb1[137].yyyy, cb1[135].xxzy
  89:     add r6.yzw, r4.xxzy, -r6.yyzw
  90:     max r6.y, abs(r6.z), abs(r6.y)
  91:     add r6.y, r6.y, l(-29.000000)
  92:     add r6.z, abs(r6.w), l(-13.000000)
  93:     mul_sat r6.yz, r6.yyzy, l(0.000000, 0.500000, 0.500000, 0.000000)
  94:     max r6.y, r6.z, r6.y
  95:     lt r6.z, r6.y, l(1.000000)
  96:     if_nz r6.z
  97:       mad r10.xyz, r4.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
  98:       mul r11.xyz, r10.xyzx, cb1[136].xyzx
  99:       round_ni r11.xyz, r11.xyzx
 100:       mad r10.xyz, r10.xyzx, cb1[136].xyzx, -r11.xyzx
 101:       sample_l(texture3d)(float,float,float,float) r11.xyw, r10.xyzx, t5.yzwx, s1, l(0)
 102:       add r6.z, -r6.y, l(1.000000)
 103:       mul r6.w, l(0.500000), cb1[136].y
 104:       mad r7.y, -cb1[136].y, l(0.500000), l(1.000000)
 105:       max r6.w, r6.w, r10.y
 106:       min r6.w, r7.y, r6.w
 107:       mul r10.w, r6.w, l(0.333333)
 108:       sample_l(texture3d)(float,float,float,float) r12.xyzw, r10.xwzx, t6.xyzw, s0, l(0)
 109:       mad r6.w, r12.w, r6.z, r5.w
 110:       add r13.xyz, r10.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 111:       sample_l(texture3d)(float,float,float,float) r13.xyz, r13.xyzx, t6.xyzw, s0, l(0)
 112:       mad r13.xyz, r13.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 113:       mul r13.xyz, r11.yyyy, r13.xyzx
 114:       mov r13.w, r11.y
 115:       mul r13.xyzw, r6.zzzz, r13.xyzw
 116:       add r10.xyz, r10.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 117:       sample_l(texture3d)(float,float,float,float) r10.xyz, r10.xyzx, t6.xyzw, s0, l(0)
 118:       mad r10.xyz, r10.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 119:       mul r10.xyz, r11.xxxx, r10.xyzx
 120:       mov r10.w, r11.x
 121:       mul r10.xyzw, r6.zzzz, r10.xyzw
 122:       mad r12.xyz, r12.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 123:       mul r11.xyz, r11.wwww, r12.xyzx
 124:       mul r11.xyzw, r6.zzzz, r11.xyzw
 125:     else
 126:       mov r13.xyzw, l(0, 0, 0, 0)
 127:       mov r10.xyzw, l(0, 0, 0, 0)
 128:       mov r11.xyzw, l(0, 0, 0, 0)
 129:       mov r6.w, r5.w
 130:     endif
 131:     mad r12.xyz, cb0[6].xzyx, -cb1[137].zzzz, cb1[135].xzyx
 132:     add r12.xyz, r4.xzyx, -r12.xyzx
 133:     max r6.z, abs(r12.y), abs(r12.x)
 134:     add r6.z, r6.z, l(-116.000000)
 135:     mul_sat r6.z, r6.z, l(0.125000)
 136:     add r7.y, abs(r12.z), l(-52.000000)
 137:     mul_sat r7.y, r7.y, l(0.125000)
 138:     max r6.z, r6.z, r7.y
 139:     lt r7.y, r6.z, l(1.000000)
 140:     if_nz r7.y
 141:       mad r12.xyz, r4.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 142:       mul r14.xyz, r12.xyzx, cb1[136].xyzx
 143:       round_ni r14.xyz, r14.xyzx
 144:       mad r12.xyz, r12.xyzx, cb1[136].xyzx, -r14.xyzx
 145:       sample_l(texture3d)(float,float,float,float) r14.xyw, r12.xyzx, t7.yzwx, s1, l(0)
 146:       add r7.y, -r6.z, l(1.000000)
 147:       mul r6.y, r6.y, r7.y
 148:       mul r7.y, l(0.500000), cb1[136].y
 149:       mad r15.x, -cb1[136].y, l(0.500000), l(1.000000)
 150:       max r7.y, r7.y, r12.y
 151:       min r7.y, r15.x, r7.y
 152:       mul r12.w, r7.y, l(0.333333)
 153:       sample_l(texture3d)(float,float,float,float) r15.xyzw, r12.xwzx, t8.xyzw, s0, l(0)
 154:       mad r6.w, r15.w, r6.y, r6.w
 155:       add r16.xyz, r12.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 156:       sample_l(texture3d)(float,float,float,float) r16.xyz, r16.xyzx, t8.xyzw, s0, l(0)
 157:       mad r16.xyz, r16.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 158:       mul r16.xyz, r14.yyyy, r16.xyzx
 159:       mov r16.w, r14.y
 160:       mad r13.xyzw, r16.xyzw, r6.yyyy, r13.xyzw
 161:       add r12.xyz, r12.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 162:       sample_l(texture3d)(float,float,float,float) r12.xyz, r12.xyzx, t8.xyzw, s0, l(0)
 163:       mad r12.xyz, r12.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 164:       mul r12.xyz, r14.xxxx, r12.xyzx
 165:       mov r12.w, r14.x
 166:       mad r10.xyzw, r12.xyzw, r6.yyyy, r10.xyzw
 167:       mad r12.xyz, r15.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 168:       mul r14.xyz, r14.wwww, r12.xyzx
 169:       mad r11.xyzw, r14.xyzw, r6.yyyy, r11.xyzw
 170:     endif
 171:     lt r6.y, l(0), r6.z
 172:     if_nz r6.y
 173:       mad r12.xyz, r4.xyzx, l(0.125000, 0.125000, 0.125000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 174:       mul r14.xyz, r12.xyzx, cb1[136].xyzx
 175:       mul r15.xyz, l(0.500000, 0.500000, 0.500000, 0.000000), cb1[136].xyzx
 176:       round_ni r14.xyz, r14.xyzx
 177:       mad r12.xyz, r12.xyzx, cb1[136].xyzx, -r14.xyzx
 178:       mad r14.xyz, -cb1[136].xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), l(1.000000, 1.000000, 1.000000, 0.000000)
 179:       max r12.xyz, r15.xyzx, r12.xyzx
 180:       min r12.xyz, r14.xyzx, r12.xyzx
 181:       sample_l(texture3d)(float,float,float,float) r16.xyw, r12.xyzx, t9.yzwx, s1, l(0)
 182:       add r6.y, -r5.w, l(1.000000)
 183:       mul r6.y, r6.y, r6.z
 184:       max r6.z, r15.y, r12.y
 185:       min r6.z, r14.y, r6.z
 186:       mul r12.w, r6.z, l(0.333333)
 187:       sample_l(texture3d)(float,float,float,float) r14.xyzw, r12.xwzx, t10.xyzw, s0, l(0)
 188:       add r15.xyz, r12.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 189:       sample_l(texture3d)(float,float,float,float) r15.xyz, r15.xyzx, t10.xyzw, s0, l(0)
 190:       mad r15.xyz, r15.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 191:       mul r15.xyz, r16.yyyy, r15.xyzx
 192:       mov r15.w, r16.y
 193:       mad r13.xyzw, r15.xyzw, r6.yyyy, r13.xyzw
 194:       add r12.xyz, r12.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 195:       sample_l(texture3d)(float,float,float,float) r12.xyz, r12.xyzx, t10.xyzw, s0, l(0)
 196:       mad r12.xyz, r12.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 197:       mul r12.xyz, r16.xxxx, r12.xyzx
 198:       mov r12.w, r16.x
 199:       mad r10.xyzw, r12.xyzw, r6.yyyy, r10.xyzw
 200:       mad r12.xyz, r14.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 201:       mul r16.xyz, r16.wwww, r12.xyzx
 202:       mad r11.xyzw, r16.xyzw, r6.yyyy, r11.xyzw
 203:       mad r6.w, r14.w, r6.y, r6.w
 204:     endif
 205:     mad_sat r6.y, r6.w, l(2.000000), l(-1.000000)
 206:     add r12.x, -r5.w, r6.y
 207:     add r5.w, r5.w, r6.y
 208:     mul r12.y, r5.w, l(0.500000)
 209:   else
 210:     mov r13.xyzw, l(0, 0, 0, 0)
 211:     mov r10.xyzw, l(0, 0, 0, 0)
 212:     mov r11.xyzw, l(0, 0, 0, 0)
 213:     mov r12.xy, l(0.000000, 1.000000, 0.000000, 0.000000)
 214:   endif
 215:   mul r14.xyzw, r12.yyyx, cb1[138].xyzw
 216:   mad r14.y, r14.w, l(0.500000), r14.y
 217:   mul r6.yz, r12.yyxy, cb1[138].wwyw
 218:   mad r14.w, r6.z, l(0.375000), r6.y
 219:   add r11.xyzw, r11.xyzw, r14.xyzw
 220:   mul r14.xyzw, r12.yyyx, cb1[139].xyzw
 221:   mad r14.y, r14.w, l(0.500000), r14.y
 222:   mul r6.yz, r12.yyxy, cb1[139].wwyw
 223:   mad r14.w, r6.z, l(0.375000), r6.y
 224:   add r10.xyzw, r10.xyzw, r14.xyzw
 225:   mul r14.xyzw, r12.yyyx, cb1[140].xyzw
 226:   mad r14.y, r14.w, l(0.500000), r14.y
 227:   mul r6.yz, r12.yyxy, cb1[140].wwyw
 228:   mad r14.w, r6.z, l(0.375000), r6.y
 229:   add r12.xyzw, r13.xyzw, r14.xyzw
 230:   mov r9.w, l(1.000000)
 231:   dp4 r13.x, r11.xyzw, r9.xyzw
 232:   dp4 r13.y, r10.xyzw, r9.xyzw
 233:   dp4 r13.z, r12.xyzw, r9.xyzw
 234:   max r6.yzw, r13.xxyz, l(0, 0, 0, 0)
 235:   mul r13.xyz, r4.wwww, r6.yzwy
 236:   mul r14.xyz, r10.xyzx, l(0.715200, 0.715200, 0.715200, 0.000000)
 237:   mad r14.xyz, r11.xyzx, l(0.212600, 0.212600, 0.212600, 0.000000), r14.xyzx
 238:   mad r14.xyz, r12.xyzx, l(0.072200, 0.072200, 0.072200, 0.000000), r14.xyzx
 239:   dp3 r5.w, r14.xyzx, r14.xyzx
 240:   max r5.w, r5.w, l(0.000000)
 241:   rsq r5.w, r5.w
 242:   mul r14.xyz, r5.wwww, r14.xyzx
 243:   mov r14.y, abs(r14.y)
 244:   mov r14.w, l(1.000000)
 245:   dp4 r11.x, r11.xyzw, r14.xyzw
 246:   dp4 r11.y, r10.xyzw, r14.xyzw
 247:   dp4 r11.z, r12.xyzw, r14.xyzw
 248:   max r10.xyz, r11.xyzx, l(0, 0, 0, 0)
 249:   dp3 r5.w, r13.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 250:   mad_sat r7.y, r5.w, l(10.000000), l(-0.100000)
 251:   mul r7.y, r7.y, l(0.500000)
 252:   mad r6.yzw, r6.yyzw, r4.wwww, -r5.wwww
 253:   mad r6.yzw, r7.yyyy, r6.yyzw, r5.wwww
 254:   max r11.xyz, r6.yzwy, l(0.001000, 0.001000, 0.001000, 0.000000)
 255:   max r5.w, r6.z, r6.y
 256:   max r5.w, r6.w, r5.w
 257:   max r5.w, r5.w, l(0.001000)
 258:   div r6.yzw, r11.xxyz, r5.wwww
 259:   max r5.w, r10.y, r10.x
 260:   max r5.w, r10.z, r5.w
 261:   mul r4.w, r4.w, r5.w
 262: else
 263:   mov r6.yzw, cb1[113].xxyz
 264: endif
 265: dp3 r5.w, r9.xyzx, r1.xyzx
 266: mov_sat r7.y, r5.w
 267: mad r9.w, r7.y, l(0.850000), l(0.150000)
 268: add r9.w, -r9.w, l(1.000000)
 269: mul_sat r9.w, r9.w, cb6[12].x
 270: add r10.x, -r9.w, l(1.000000)
 271: mad r10.xyz, cb6[13].xyzx, r9.wwww, r10.xxxx
 272: mul r2.yzw, r2.yyzw, r10.xxyz
 273: mul r10.xyz, r2.yzwy, l(0.960000, 0.960000, 0.960000, 0.000000)
 274: sample_l(texture2d)(float,float,float,float) r11.xyz, r7.xzxx, t12.xyzw, s0, l(0)
 275: add r7.xz, r7.xxwx, l(0.031250, 0.000000, 0.015625, 0.000000)
 276: sample_l(texture2d)(float,float,float,float) r7.xzw, r7.xzxx, t12.xwyz, s0, l(0)
 277: mad r3.w, r6.x, l(31.000000), -r3.w
 278: add r7.xzw, -r11.xxyz, r7.xxzw
 279: mad r7.xzw, r3.wwww, r7.xxzw, r11.xxyz
 280: mul r7.xzw, r7.xxzw, l(0.960000, 0.000000, 0.960000, 0.960000)
 281: max r2.x, cb2[r2.x + 4].z, cb2[r2.x + 4].y
 282: add r2.x, -r2.x, l(1.000000)
 283: lt r2.x, r2.x, l(0.990000)
 284: max r3.w, v5.z, l(0.000000)
 285: div r11.xy, v5.xyxx, r3.wwww
 286: max r3.w, v6.z, l(0.000000)
 287: div r11.zw, v6.xxxy, r3.wwww
 288: add r11.xy, -r11.zwzz, r11.xyxx
 289: mul r12.xy, r11.xyxx, l(0.500000, -0.500000, 0.000000, 0.000000)
 290: sqrt r12.xy, abs(r12.xyxx)
 291: sqrt r12.xy, r12.xyxx
 292: mov r11.z, -r11.y
 293: lt r11.yw, l(0, 0, 0, 0), r11.xxxz
 294: lt r11.xz, r11.xxzx, l(0, 0, 0, 0)
 295: iadd r11.xy, -r11.ywyy, r11.xzxx
 296: itof r11.xy, r11.xyxx
 297: mul r11.xy, r11.xyxx, r12.xyxx
 298: mad r11.xy, r11.xyxx, l(0.500000, 0.500000, 0.000000, 0.000000), l(0.500000, 0.500000, 0.000000, 0.000000)
 299: and r3.w, r2.x, l(1.000000)
 300: add r11.zw, -r11.xxxy, l(0.000000, 0.000000, 0.500000, 0.500000)
 301: mad o1.xy, r3.wwww, r11.zwzz, r11.xyxx
 302: movc o1.w, r2.x, l(0.700000), l(0.400000)
 303: add r11.xyz, cb1[114].xyzx, -cb3[3].xyzx
 304: mad r11.xyz, cb1[122].yyyy, r11.xyzx, cb3[3].xyzx
 305: add r2.x, cb1[115].w, -cb3[3].w
 306: mad r2.x, cb1[122].w, r2.x, cb3[3].w
 307: mul r12.xyz, r2.xxxx, r11.xyzx
 308: ld_indexable(texture2d)(float,float,float,float) r13.xy, r8.xyzz, t4.xyzw
 309: add r3.w, r13.x, l(-1.000000)
 310: mad r3.w, cb5[34].x, r3.w, l(1.000000)
 311: add r6.x, -r3.w, l(1.000000)
 312: mad r3.w, cb1[111].z, r6.x, r3.w
 313: mul r13.xzw, r7.xxzw, cb1[110].zzzz
 314: mul r14.xyz, r13.xzwx, l(0.650000, 0.650000, 0.650000, 0.000000)
 315: add r15.xyz, cb1[121].xyzx, cb3[0].xyzx
 316: mad r15.xyz, cb1[111].wwww, r15.xyzx, -cb3[0].xyzx
 317: dp3 r6.x, r9.xyzx, r15.xyzx
 318: mad r6.x, cb1[121].w, cb1[122].x, r6.x
 319: max r6.x, r6.x, l(-1.000000)
 320: min r6.x, r6.x, l(1.000000)
 321: mad r15.x, r6.x, l(0.500000), l(0.500000)
 322: mov r15.y, l(0.500000)
 323: sample_l(texture2d)(float,float,float,float) r15.xyzw, r15.xyxx, t11.xyzw, s0, l(0)
 324: max r6.x, r15.y, r15.x
 325: max r6.x, r15.z, r6.x
 326: min r8.z, r15.y, r15.x
 327: min r8.z, r15.z, r8.z
 328: add r6.x, r6.x, -r8.z
 329: min r8.z, r13.y, l(1.000000)
 330: min r8.z, r15.w, r8.z
 331: dp3 r9.w, r9.xyzx, cb1[116].xyzx
 332: add_sat r9.w, r9.w, cb1[117].x
 333: mad r9.w, r9.w, cb1[117].y, cb1[117].z
 334: mul r10.w, r8.z, cb1[111].y
 335: add r16.xyz, -r6.yzwy, l(1.000000, 1.000000, 1.000000, 0.000000)
 336: mad r6.yzw, r10.wwww, r16.xxyz, r6.yyzw
 337: mul r6.yzw, r6.yyzw, r9.wwww
 338: dp3 r9.w, r14.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 339: mad r14.xyz, r13.xzwx, l(0.650000, 0.650000, 0.650000, 0.000000), -r9.wwww
 340: mad r14.xyz, r14.xyzx, l(1.200000, 1.200000, 1.200000, 0.000000), r9.wwww
 341: add_sat r9.w, r13.y, r15.w
 342: mad r16.xyz, r7.xzwx, cb1[110].zzzz, -r14.xyzx
 343: mad r14.xyz, r9.wwww, r16.xyzx, r14.xyzx
 344: mad r16.xyz, r2.yzwy, l(0.960000, 0.960000, 0.960000, 0.000000), -r14.xyzx
 345: mad r14.xyz, r8.zzzz, r16.xyzx, r14.xyzx
 346: add r9.w, -r6.x, l(1.000000)
 347: mad r15.xyz, r15.xyzx, r6.xxxx, r9.wwww
 348: mul r15.xyz, r14.xyzx, r15.xyzx
 349: dp3 r6.x, r10.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 350: mad r16.xyz, r2.yzwy, l(0.960000, 0.960000, 0.960000, 0.000000), -r6.xxxx
 351: mad r16.xyz, r16.xyzx, l(1.200000, 1.200000, 1.200000, 0.000000), r6.xxxx
 352: mad r16.xyz, -r7.xzwx, cb1[110].zzzz, r16.xyzx
 353: mad r13.xzw, r13.yyyy, r16.xxyz, r13.xxzw
 354: dp3 r6.x, r14.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 355: dp3 r9.w, r15.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 356: max r9.w, r9.w, l(0.001000)
 357: div r9.w, l(1.000000, 1.000000, 1.000000, 1.000000), r9.w
 358: mul r6.x, r6.x, r9.w
 359: max r6.x, r6.x, l(0)
 360: min r6.x, r6.x, l(1.500000)
 361: mad r14.xyz, r15.xyzx, r6.xxxx, -r13.xzwx
 362: mad r13.xzw, r3.wwww, r14.xxyz, r13.xxzw
 363: mad r6.x, r4.w, l(0.350000), l(0.650000)
 364: min r6.x, r6.x, l(1.500000)
 365: max r14.xy, r4.wwww, l(1.250000, 0.000000, 0.000000, 0.000000)
 366: min r14.xy, r14.xyxx, l(1.750000, 1.500000, 0.000000, 0.000000)
 367: add r4.w, -r6.x, r14.x
 368: mad r4.w, cb1[111].x, r4.w, r6.x
 369: mul r14.xzw, r4.wwww, r6.yyzw
 370: mul r14.xzw, r14.xxzw, cb1[110].wwww
 371: dp3 r4.w, r12.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 372: mad r12.xyz, r11.xyzx, r2.xxxx, -r4.wwww
 373: mad r12.xyz, r8.zzzz, r12.xyzx, r4.wwww
 374: mul r6.xyz, r6.yzwy, r14.yyyy
 375: add r2.x, l(1.000000), -cb1[122].y
 376: mad r11.xyz, r11.xyzx, cb1[122].yyyy, r2.xxxx
 377: mad r6.xyz, r6.xyzx, r11.xyzx, r12.xyzx
 378: mad r6.xyz, r6.xyzx, cb1[110].yyyy, -r14.xzwx
 379: mad r6.xyz, r3.wwww, r6.xyzx, r14.xzwx
 380: mul r11.xyz, r13.xzwx, r6.xyzx
 381: dp3 r2.x, r11.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 382: add r4.w, r2.x, l(-0.500000)
 383: max r4.w, r4.w, l(0)
 384: min r4.w, r4.w, l(0.500000)
 385: mul r11.z, cb0[0].x, cb1[119].x
 386: mul r11.x, cb0[1].x, cb1[119].x
 387: mul r11.y, cb0[2].x, cb1[119].x
 388: mul r12.z, cb0[0].y, cb1[119].y
 389: mul r12.x, cb0[1].y, cb1[119].y
 390: mul r12.y, cb0[2].y, cb1[119].y
 391: add r11.xyz, r11.xyzx, r12.xyzx
 392: mov r12.xz, cb1[119].yyxy
 393: mov r12.y, l(0)
 394: add r11.xyz, r11.xyzx, -r12.xyzx
 395: mad r11.xyz, cb1[125].wwww, r11.xyzx, r12.xyzx
 396: mul r12.xyz, r11.xyzx, cb0[6].zxyz
 397: mad r11.xyz, cb0[6].yzxy, r11.yzxy, -r12.xyzx
 398: dp3 r6.w, r11.xyzx, r11.xyzx
 399: rsq r6.w, r6.w
 400: mul r11.xyz, r6.wwww, r11.xyzx
 401: add r5.w, -abs(r5.w), l(1.000000)
 402: utof r12.xy, r8.xyxx
 403: mul r12.zw, r12.xxxy, l(0.000000, 0.000000, 0.031250, 0.031250)
 404: round_ni r12.zw, r12.zzzw
 405: mad r6.w, r12.w, cb4[2].y, r12.z
 406: mul r6.w, r6.w, l(8.000000)
 407: ftoi r6.w, r6.w
 408: mad r8.z, -cb1[3].y, cb4[3].w, v0.w
 409: round_ni r8.z, r8.z
 410: add r9.w, l(-1.000000), cb4[2].w
 411: max r10.w, r8.z, l(0)
 412: min r9.w, r9.w, r10.w
 413: mul r10.w, r9.w, l(8.000000)
 414: ftoi r10.w, r10.w
 415: mad r4.w, r4.w, r4.w, l(1.000000)
 416: mad r6.xyz, r6.xyzx, r13.xzwx, -r2.xxxx
 417: mad r6.xyz, r4.wwww, r6.xyzx, r2.xxxx
 418: mad r12.zw, cb1[119].wwww, l(0.000000, 0.000000, -0.600000, -0.400000), l(0.000000, 0.000000, 0.800000, 0.900000)
 419: add r2.x, -r12.z, r12.w
 420: add r4.w, r5.w, -r12.z
 421: div r2.x, l(1.000000, 1.000000, 1.000000, 1.000000), r2.x
 422: mul_sat r2.x, r2.x, r4.w
 423: mad r4.w, r2.x, l(-2.000000), l(3.000000)
 424: mul r2.x, r2.x, r2.x
 425: mul r2.x, r2.x, r4.w
 426: mul r14.xyz, r2.xxxx, cb1[118].xyzx
 427: mul r14.xyz, r14.xyzx, cb1[118].wwww
 428: dp3 r2.x, r3.xyzx, r11.xyzx
 429: add_sat r2.x, r2.x, l(1.000000)
 430: min r2.x, r13.y, r2.x
 431: mul r14.xyz, r2.xxxx, r14.xyzx
 432: mad r15.xyz, r2.yzwy, l(0.960000, 0.960000, 0.960000, 0.000000), l(-0.250000, -0.250000, -0.250000, 0.000000)
 433: mad r15.xyz, cb1[119].zzzz, r15.xyzx, l(0.250000, 0.250000, 0.250000, 0.000000)
 434: dp3_sat r2.x, r11.xyzx, r9.xyzx
 435: mul r11.xyz, r2.xxxx, r15.xyzx
 436: mad r6.xyz, r14.xyzx, r11.xyzx, r6.xyzx
 437: ge r2.x, r9.w, r8.z
 438: iadd r4.w, r6.w, cb4[0].z
 439: iadd r6.w, r10.w, cb4[0].w
 440: add r3.w, -r3.w, l(1.000000)
 441: mad r3.w, r3.w, l(-0.250000), l(0.750000)
 442: mad r2.yzw, r2.yyzw, l(0.000000, 0.960000, 0.960000, 0.960000), l(0.000000, -0.500000, -0.500000, -0.500000)
 443: mov r11.w, l(1.000000)
 444: mov r14.xyz, r6.xyzx
 445: mov r8.z, l(0)
 446: loop
 447:   ilt r9.w, l(7), r8.z
 448:   breakc_nz r9.w
 449:   iadd r9.w, r4.w, r8.z
 450:   ld_structured_indexable(structured_buffer, stride=4)(mixed,mixed,mixed,mixed) r9.w, r9.w, l(0), t0.xxxx
 451:   iadd r10.w, r6.w, r8.z
 452:   ld_structured_indexable(structured_buffer, stride=4)(mixed,mixed,mixed,mixed) r10.w, r10.w, l(0), t0.xxxx
 453:   and r9.w, r9.w, r10.w
 454:   and r9.w, r2.x, r9.w
 455:   ishl r10.w, r8.z, l(5)
 456:   mov r15.xyz, r14.xyzx
 457:   mov r12.z, r9.w
 458:   loop
 459:     breakc_z r12.z
 460:     firstbit_lo r12.w, r12.z
 461:     ishl r13.y, l(1), r12.w
 462:     xor r13.y, r12.z, r13.y
 463:     iadd r12.w, r10.w, r12.w
 464:     bfi r16.xyz, l(29, 29, 29, 0), l(3, 3, 3, 0), r12.wwww, l(1, 5, 6, 0)
 465:     ftou r14.w, cb3[r16.y + 6].w
 466:     and r15.w, r14.w, l(1)
 467:     ieq r15.w, r15.w, l(1)
 468:     if_nz r15.w
 469:       add r11.xyz, r4.xyzx, -cb3[r16.x + 6].xyzx
 470:       and r17.xyz, l(0x0000ffff, 0x0000ffff, 0x0000ffff, 0), cb3[r16.y + 6].xzyx
 471:       and r18.xyz, l(0x0000ffff, 0x0000ffff, 0x0000ffff, 0), cb3[r16.z + 6].yxzy
 472:       ushr r19.xyz, cb3[r16.y + 6].xzyx, l(16, 16, 16, 0)
 473:       ushr r20.xyz, cb3[r16.z + 6].yxzy, l(16, 16, 16, 0)
 474:       f16tof32 r17.xyz, r17.xyzx
 475:       f16tof32 r18.xyz, r18.xyzx
 476:       f16tof32 r19.xyz, r19.xyzx
 477:       f16tof32 r20.xyw, r20.yxyz
 478:       mov r21.xz, r17.xxzx
 479:       mov r21.yw, r19.xxxz
 480:       dp4 r15.w, r11.xyzw, r21.xyzw
 481:       mov r19.x, r17.y
 482:       mov r19.z, r18.y
 483:       mov r19.w, r20.x
 484:       dp4 r16.y, r11.xyzw, r19.xyzw
 485:       mov r20.xz, r18.xxzx
 486:       dp4 r11.x, r11.xyzw, r20.xyzw
 487:       bfi r11.y, l(29), l(3), r12.w, l(7)
 488:       max r11.z, abs(r15.w), abs(r16.y)
 489:       max r11.x, abs(r11.x), r11.z
 490:       mad r11.z, cb3[r11.y + 6].x, l(0.500000), l(0.500000)
 491:       add r11.x, -r11.z, r11.x
 492:       mad r11.y, -cb3[r11.y + 6].x, l(0.500000), l(0.500000)
 493:       div_sat r11.x, r11.x, r11.y
 494:       add r11.x, -r11.x, l(1.000000)
 495:       mul r11.x, r11.x, r11.x
 496:     else
 497:       mov r11.x, l(1.000000)
 498:     endif
 499:     lt r11.y, r11.x, l(0.001000)
 500:     if_nz r11.y
 501:       mov r12.z, r13.y
 502:       continue
 503:     endif
 504:     ishl r11.y, r12.w, l(3)
 505:     ftou r11.z, cb3[r11.y + 6].w
 506:     uge r15.w, r11.z, l(4)
 507:     if_nz r15.w
 508:       mov r17.xyz, r15.xyzx
 509:     endif
 510:     if_z r15.w
 511:       lt r15.w, cb3[r11.y + 6].w, l(1.500000)
 512:       if_nz r15.w
 513:         bfi r15.w, l(29), l(3), r12.w, l(3)
 514:         ieq r16.y, l(16), cb3[r15.w + 6].w
 515:         add r16.w, cb1[122].z, cb3[r15.w + 6].z
 516:         lt r16.w, r16.w, l(0.500000)
 517:         or r16.y, r16.w, r16.y
 518:         if_z r16.y
 519:           bfi r16.yw, l(0, 29, 0, 29), l(0, 3, 0, 3), r12.wwww, l(0, 2, 0, 4)
 520:           and r11.z, r11.z, l(1)
 521:           ieq r12.w, r11.z, l(0)
 522:           not r17.w, r12.w
 523:           lt r18.x, l(0), cb3[r16.y + 6].z
 524:           and r17.w, r17.w, r18.x
 525:           ieq r18.x, l(4), cb3[r15.w + 6].w
 526:           movc r11.z, r11.z, l(0), l(1.000000)
 527:           mad r18.y, cb3[r16.y + 6].y, l(0.500000), l(0.500000)
 528:           add r19.z, r18.y, -abs(cb3[r16.y + 6].x)
 529:           add r19.x, -r19.z, cb3[r16.y + 6].y
 530:           add r18.y, -abs(r19.z), l(1.000000)
 531:           add r18.y, -abs(r19.x), r18.y
 532:           max r18.y, r18.y, l(0.000488)
 533:           ge r18.z, cb3[r16.y + 6].x, l(0)
 534:           movc r19.y, r18.z, r18.y, -r18.y
 535:           dp3 r18.y, r19.xyzx, r19.xyzx
 536:           rsq r18.y, r18.y
 537:           mul r18.yzw, r18.yyyy, r19.xxyz
 538:           add r19.x, cb3[r16.w + 6].y, cb3[r16.w + 6].y
 539:           max r19.x, r19.x, l(0.100000)
 540:           and r19.y, r18.x, l(1.000000)
 541:           add r19.x, r19.x, -cb3[r16.z + 6].w
 542:           mad r16.z, r19.y, r19.x, cb3[r16.z + 6].w
 543:           add r19.xyz, -r4.xyzx, cb3[r16.x + 6].xyzx
 544:           dp3 r19.w, r19.yzxy, -r18.yzwy
 545:           lt r20.x, l(0.500000), cb3[r16.w + 6].z
 546:           and r20.x, r18.x, r20.x
 547:           and r20.x, r20.x, l(1.000000)
 548:           mul r20.x, r11.z, r20.x
 549:           mad r20.yzw, -r18.wwyz, r19.wwww, -r19.xxyz
 550:           mad r19.xyz, r20.xxxx, r20.yzwy, r19.xyzx
 551:           dp3 r19.w, r19.xyzx, r19.xyzx
 552:           rsq r20.x, r19.w
 553:           mul r20.xyz, r19.xyzx, r20.xxxx
 554:           if_nz r17.w
 555:             mul r21.xyz, r18.wyzw, cb3[r16.y + 6].zzzz
 556:             mad r22.xyz, -r21.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), r19.xyzx
 557:             mad r21.xyz, r21.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), r19.xyzx
 558:             dp3 r20.w, r22.xyzx, r22.xyzx
 559:             sqrt r20.w, r20.w
 560:             dp3 r21.w, r21.xyzx, r21.xyzx
 561:             sqrt r21.w, r21.w
 562:             mul r23.xyz, r18.yzwy, r20.xyzx
 563:             mad r23.xyz, r18.wyzw, r20.yzxy, -r23.xyzx
 564:             mul r24.xyz, r18.yzwy, r23.xyzx
 565:             mad r23.xyz, r23.zxyz, r18.zwyz, -r24.xyzx
 566:             dp3 r22.w, r23.xyzx, r23.xyzx
 567:             rsq r22.w, r22.w
 568:             mul r20.xyz, r22.wwww, r23.xyzx
 569:             dp3 r22.w, r22.xyzx, r21.xyzx
 570:             mad r22.w, r20.w, r21.w, r22.w
 571:             mad r22.w, r22.w, l(0.500000), l(1.000000)
 572:             div r22.w, l(1.000000, 1.000000, 1.000000, 1.000000), r22.w
 573:             dp3 r22.x, r20.xyzx, r22.xyzx
 574:             div r20.w, r22.x, r20.w
 575:             dp3 r21.x, r20.xyzx, r21.xyzx
 576:             div r21.x, r21.x, r21.w
 577:             add r20.w, r20.w, r21.x
 578:             mul_sat r20.w, r20.w, l(0.500000)
 579:             mul r20.w, r20.w, r22.w
 580:           else
 581:             mov r20.w, l(1.000000)
 582:           endif
 583:           lt r21.x, r16.z, l(0)
 584:           if_nz r21.x
 585:             mul r21.x, cb3[r16.x + 6].w, cb3[r16.x + 6].w
 586:             mul r21.x, r19.w, r21.x
 587:             mad r21.x, -r21.x, r21.x, l(1.000000)
 588:             max r21.x, r21.x, l(0)
 589:             add r19.w, r19.w, l(1.000000)
 590:             div r19.w, l(1.000000, 1.000000, 1.000000, 1.000000), r19.w
 591:             and r17.w, r17.w, l(1.000000)
 592:             add r21.y, -r19.w, r20.w
 593:             mad r17.w, r17.w, r21.y, r19.w
 594:             mul r19.w, r21.x, r21.x
 595:             mul r17.w, r17.w, r19.w
 596:           else
 597:             mul r19.xyz, r19.xyzx, cb3[r16.x + 6].wwww
 598:             dp3 r19.x, r19.xyzx, r19.xyzx
 599:             min r19.x, r19.x, l(1.000000)
 600:             add r19.x, -r19.x, l(1.000000)
 601:             log r19.x, r19.x
 602:             mul r16.z, r16.z, r19.x
 603:             exp r16.z, r16.z
 604:             mul r17.w, r16.z, r20.w
 605:           endif
 606:           dp3 r16.z, r20.yzxy, -r18.yzwy
 607:           add r16.z, r16.z, -cb3[r16.y + 6].z
 608:           mul_sat r16.z, r16.z, cb3[r16.y + 6].w
 609:           mad r16.z, r16.z, r16.z, l(-1.000000)
 610:           mad r11.z, r11.z, r16.z, l(1.000000)
 611:           mul r11.z, r11.z, r17.w
 612:           mul r11.x, r11.x, r11.z
 613:           lt r11.z, l(0.000100), r11.x
 614:           if_nz r11.z
 615:             if_nz r18.x
 616:               mul r11.z, r11.x, cb3[r16.w + 6].x
 617:               add r18.yzw, -r15.xxyz, cb3[r11.y + 6].xxyz
 618:               mad r18.yzw, r11.zzzz, r18.yyzw, r15.xxyz
 619:             endif
 620:             if_z r18.x
 621:               dp3 r11.z, r9.xyzx, r20.xyzx
 622:               mov_sat r16.z, r11.z
 623:               if_nz cb3[r15.w + 6].w
 624:                 and r14.w, r14.w, l(2)
 625:                 ine r14.w, r14.w, l(0)
 626:                 or r12.w, r12.w, r14.w
 627:                 if_nz r12.w
 628:                   ftoi r14.w, cb3[r15.w + 6].x
 629:                 else
 630:                   add r19.xyz, r4.xyzx, -cb3[r16.x + 6].xyzx
 631:                   lt r21.xyz, abs(r19.yzzy), abs(r19.xxyx)
 632:                   and r17.w, r21.y, r21.x
 633:                   lt r19.xyz, l(0, 0, 0, 0), r19.xyzx
 634:                   and r19.w, l(1023), cb3[r16.y + 6].w
 635:                   ubfe r21.xy, l(10, 10, 0, 0), l(10, 20, 0, 0), cb3[r16.y + 6].wwww
 636:                   movc r16.y, r19.x, r19.w, r21.x
 637:                   and r19.x, l(1023), cb3[r15.w + 6].x
 638:                   movc r19.x, r19.y, r21.y, r19.x
 639:                   ubfe r19.yw, l(0, 10, 0, 10), l(0, 10, 0, 20), cb3[r15.w + 6].xxxx
 640:                   movc r19.y, r19.z, r19.y, r19.w
 641:                   movc r19.x, r21.z, r19.x, r19.y
 642:                   movc r16.y, r17.w, r16.y, r19.x
 643:                   ieq r17.w, r16.y, l(1023)
 644:                   movc r14.w, r17.w, l(-1), r16.y
 645:                 endif
 646:                 ige r16.y, r14.w, l(0)
 647:                 if_nz r16.y
 648:                   add r19.xyz, r4.xyzx, -cb3[r16.x + 6].xyzx
 649:                   imad r14.w, r14.w, l(96), cb5[65].x
 650:                   iadd r21.xyzw, r14.wwww, l(64, 16, 32, 48)
 651:                   and r21.xyzw, r21.xyzw, l(-4, -4, -4, -4)
 652:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r16.xy, r21.x, t2.xyxx
 653:                   and r17.w, r14.w, l(-4)
 654:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r22.xyzw, r17.w, t2.xyzw
 655:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r23.xyzw, r21.y, t2.xyzw
 656:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r24.xyzw, r21.z, t2.xyzw
 657:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r25.xyzw, r21.w, t2.xyzw
 658:                   dp3 r17.w, r19.xyzx, r19.xyzx
 659:                   max r17.w, r17.w, l(0.000000)
 660:                   rsq r17.w, r17.w
 661:                   mul r19.xyz, r17.wwww, r19.xyzx
 662:                   mad r19.xyz, -r19.xyzx, r16.xxxx, r4.xyzx
 663:                   mul r16.x, r16.y, l(5.000000)
 664:                   mad r19.xyz, r5.xyzx, r16.xxxx, r19.xyzx
 665:                   mul r23.xyzw, r19.yyyy, r23.xyzw
 666:                   mad r22.xyzw, r22.xyzw, r19.xxxx, r23.xyzw
 667:                   mad r19.xyzw, r24.xyzw, r19.zzzz, r22.xyzw
 668:                   add r19.xyzw, r25.xyzw, r19.xyzw
 669:                   div r19.xyz, r19.xyzx, r19.wwww
 670:                   iadd r14.w, r14.w, l(80)
 671:                   and r14.w, r14.w, l(-4)
 672:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r22.xyzw, r14.w, t2.xyzw
 673:                   ge r21.yzw, l(0, 0, 0, 0), r19.xxyz
 674:                   ge r23.xyz, r19.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 675:                   add r16.xy, -r22.xyxx, r22.zwzz
 676:                   mad r16.xy, r19.xyxx, r16.xyxx, r22.xyxx
 677:                   mad r22.xy, r16.xyxx, cb5[64].zwzz, l(0.500000, 0.500000, 0.000000, 0.000000)
 678:                   round_ni r22.xy, r22.xyxx
 679:                   mad r16.xy, r16.xyxx, cb5[64].zwzz, -r22.xyxx
 680:                   add r24.xyzw, r16.xxyy, l(0.500000, 1.000000, 0.500000, 1.000000)
 681:                   mul r25.xyzw, r24.xxzz, r24.xxzz
 682:                   add r22.zw, -r16.xxxy, l(0.000000, 0.000000, 1.000000, 1.000000)
 683:                   min r24.xz, r16.xxyx, l(0, 0, 0, 0)
 684:                   max r26.xy, r16.xyxx, l(0, 0, 0, 0)
 685:                   mul r27.xy, r22.zwzz, l(0.160000, 0.160000, 0.000000, 0.000000)
 686:                   mad r26.xy, -r26.xyxx, r26.xyxx, r24.ywyy
 687:                   add r26.xy, r26.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 688:                   mul r26.xy, r26.xyxx, l(0.160000, 0.160000, 0.000000, 0.000000)
 689:                   mul r25.xz, r25.xxzx, l(0.080000, 0.000000, 0.080000, 0.000000)
 690:                   mad r16.xy, r25.ywyy, l(0.500000, 0.500000, 0.000000, 0.000000), -r16.xyxx
 691:                   mul r28.xy, r16.xyxx, l(0.160000, 0.160000, 0.000000, 0.000000)
 692:                   mad r16.xy, -r24.xzxx, r24.xzxx, r22.zwzz
 693:                   add r16.xy, r16.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 694:                   mul r29.xy, r16.xyxx, l(0.160000, 0.160000, 0.000000, 0.000000)
 695:                   mul r16.xy, r24.ywyy, l(0.160000, 0.160000, 0.000000, 0.000000)
 696:                   mov r28.z, r29.x
 697:                   mov r28.w, r16.x
 698:                   mov r27.z, r26.x
 699:                   mov r27.w, r25.x
 700:                   add r24.xyzw, r27.zwxz, r28.zwxz
 701:                   mov r29.z, r28.y
 702:                   mov r29.w, r16.y
 703:                   mov r26.z, r27.y
 704:                   mov r26.w, r25.z
 705:                   add r25.xyz, r26.zywz, r29.zywz
 706:                   div r27.xyz, r27.xzwx, r24.zwyz
 707:                   add r27.xyz, r27.xyzx, l(-2.500000, -0.500000, 1.500000, 0.000000)
 708:                   mul r27.xyz, r27.xyzx, cb5[64].xxxx
 709:                   div r26.xyz, r26.zywz, r25.xyzx
 710:                   add r26.xyz, r26.xyzx, l(-2.500000, -0.500000, 1.500000, 0.000000)
 711:                   mul r26.xyw, r26.xyxz, cb5[64].yyyy
 712:                   mul r28.xyzw, r24.zwyz, r25.xxxy
 713:                   mov r27.w, r26.x
 714:                   mad r29.xyzw, r22.xyxy, cb5[64].xyxy, r27.xwyw
 715:                   sample_c_lz(texture2d)(float,float,float,float) r14.w, r29.xyxx, t3.xxxx, s2, r19.z
 716:                   sample_c_lz(texture2d)(float,float,float,float) r16.x, r29.zwzz, t3.xxxx, s2, r19.z
 717:                   mul r16.x, r16.x, r28.y
 718:                   mad r14.w, r28.x, r14.w, r16.x
 719:                   mad r16.xy, r22.xyxx, cb5[64].xyxx, r27.zwzz
 720:                   sample_c_lz(texture2d)(float,float,float,float) r16.x, r16.xyxx, t3.xxxx, s2, r19.z
 721:                   mad r14.w, r28.z, r16.x, r14.w
 722:                   mov r26.z, r27.x
 723:                   mad r29.xyzw, r22.xyxy, cb5[64].xyxy, r26.zyzw
 724:                   sample_c_lz(texture2d)(float,float,float,float) r16.x, r29.xyxx, t3.xxxx, s2, r19.z
 725:                   mad r14.w, r28.w, r16.x, r14.w
 726:                   mul r28.xyzw, r24.xyzw, r25.yyzz
 727:                   mov r26.xz, r27.yyzy
 728:                   mad r27.xyzw, r22.xyxy, cb5[64].xyxy, r26.xyzy
 729:                   sample_c_lz(texture2d)(float,float,float,float) r16.x, r27.xyxx, t3.xxxx, s2, r19.z
 730:                   mad r14.w, r28.x, r16.x, r14.w
 731:                   sample_c_lz(texture2d)(float,float,float,float) r16.x, r27.zwzz, t3.xxxx, s2, r19.z
 732:                   mad r14.w, r28.y, r16.x, r14.w
 733:                   sample_c_lz(texture2d)(float,float,float,float) r16.x, r29.zwzz, t3.xxxx, s2, r19.z
 734:                   mad r14.w, r28.z, r16.x, r14.w
 735:                   iadd r16.x, r21.x, l(8)
 736:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r16.xy, r16.x, t2.xyxx
 737:                   add r22.zw, -r19.xxxy, l(0.000000, 0.000000, 1.000000, 1.000000)
 738:                   min r19.xy, r19.xyxx, r22.zwzz
 739:                   or r21.xyz, r21.yzwy, r23.xyzx
 740:                   or r17.w, r21.y, r21.x
 741:                   or r17.w, r21.z, r17.w
 742:                   and r20.w, r19.z, l(0x7fffffff)
 743:                   ult r20.w, l(0x7f800000), r20.w
 744:                   or r17.w, r17.w, r20.w
 745:                   mad r21.xyzw, r22.xyxy, cb5[64].xyxy, r26.xwzw
 746:                   sample_c_lz(texture2d)(float,float,float,float) r20.w, r21.xyxx, t3.xxxx, s2, r19.z
 747:                   mad r14.w, r28.w, r20.w, r14.w
 748:                   mul r20.w, r24.y, r25.z
 749:                   sample_c_lz(texture2d)(float,float,float,float) r19.z, r21.zwzz, t3.xxxx, s2, r19.z
 750:                   mad r14.w, r20.w, r19.z, r14.w
 751:                   add r16.x, -r19.w, r16.x
 752:                   mul r16.x, r16.x, l(0.250000)
 753:                   min r19.x, r19.y, r19.x
 754:                   min r16.x, r16.x, r19.x
 755:                   mul_sat r16.x, r16.x, l(20.000000)
 756:                   mad r19.x, r16.x, l(-2.000000), l(3.000000)
 757:                   mul r16.x, r16.x, r16.x
 758:                   mul r16.x, r16.x, r19.x
 759:                   min r16.x, r16.x, r16.y
 760:                   movc r12.w, r12.w, r16.x, r16.y
 761:                   add r14.w, r14.w, l(-1.000000)
 762:                   movc r14.w, r17.w, l(0), r14.w
 763:                   mad r12.w, r12.w, r14.w, l(1.000000)
 764:                 else
 765:                   dp3 r14.w, r3.xyzx, r20.xyzx
 766:                   add_sat r12.w, r14.w, l(1.000000)
 767:                 endif
 768:               else
 769:                 mov r12.w, l(1.000000)
 770:               endif
 771:               if_z cb3[r15.w + 6].w
 772:                 mul r19.xyz, r11.xxxx, cb3[r11.y + 6].xyzx
 773:                 add r14.w, l(1.000000), -cb3[r16.w + 6].y
 774:                 max r16.x, r19.y, r19.x
 775:                 max r16.x, r19.z, r16.x
 776:                 mul r16.x, r3.w, r16.x
 777:                 max r16.x, r16.x, l(1.000000)
 778:                 div r16.x, l(1.000000, 1.000000, 1.000000, 1.000000), r16.x
 779:                 mad r14.w, r16.x, cb3[r16.w + 6].y, r14.w
 780:                 mul r19.xyz, r14.wwww, cb3[r11.y + 6].xyzx
 781:                 mul r14.w, l(0.500000), cb3[r16.w + 6].x
 782:                 add_sat r16.x, r11.z, l(0.500000)
 783:                 mad r16.y, -cb3[r16.w + 6].x, l(0.500000), l(1.000000)
 784:                 mad r14.w, r16.x, r16.y, r14.w
 785:                 mul r19.xyz, r14.wwww, r19.xyzx
 786:                 mov r21.xyz, r13.xzwx
 787:                 mov r22.xyz, r13.xzwx
 788:               else
 789:                 ieq r14.w, l(3), cb3[r15.w + 6].w
 790:                 if_nz r14.w
 791:                   mad r16.xy, cb3[r16.w + 6].xxxx, l(-0.600000, -0.400000, 0.000000, 0.000000), l(0.800000, 0.900000, 0.000000, 0.000000)
 792:                   add r14.w, -r16.x, r16.y
 793:                   add r16.x, r5.w, -r16.x
 794:                   div r14.w, l(1.000000, 1.000000, 1.000000, 1.000000), r14.w
 795:                   mul_sat r14.w, r14.w, r16.x
 796:                   mad r16.x, r14.w, l(-2.000000), l(3.000000)
 797:                   mul r14.w, r14.w, r14.w
 798:                   mul r14.w, r14.w, r16.x
 799:                   mul r14.w, r12.w, r14.w
 800:                   mul r11.x, r11.x, r14.w
 801:                   mul r23.xyz, r20.zxyz, cb0[6].xyzx
 802:                   mad r20.xyz, cb0[6].zxyz, r20.xyzx, -r23.xyzx
 803:                   mul r23.xyz, r20.xyzx, cb0[6].zxyz
 804:                   mad r20.xyz, cb0[6].yzxy, r20.yzxy, -r23.xyzx
 805:                   dp3 r14.w, r20.xyzx, r20.xyzx
 806:                   rsq r14.w, r14.w
 807:                   mul r20.xyz, r14.wwww, r20.xyzx
 808:                   dp3_sat r16.z, r9.xyzx, -r20.xyzx
 809:                   mad r21.xyz, cb3[r16.w + 6].yyyy, r2.yzwy, l(0.500000, 0.500000, 0.500000, 0.000000)
 810:                   mov r22.xyz, l(0, 0, 0, 0)
 811:                 else
 812:                   ieq r14.w, l(1), cb3[r15.w + 6].w
 813:                   if_nz r14.w
 814:                     add r11.z, r11.z, cb3[r16.w + 6].x
 815:                     max_sat r11.z, r11.z, l(-1.000000)
 816:                     mul r16.z, r12.w, r11.z
 817:                     mul r22.xyz, r7.xzwx, cb3[r16.w + 6].yyyy
 818:                   else
 819:                     mov r22.xyz, l(0, 0, 0, 0)
 820:                   endif
 821:                   and r21.xyz, r10.xyzx, r14.wwww
 822:                 endif
 823:                 mov r19.xyz, cb3[r11.y + 6].xyzx
 824:               endif
 825:               mul r11.xyz, r11.xxxx, r19.xyzx
 826:               add r16.xyw, r21.xyxz, -r22.xyxz
 827:               mad r16.xyz, r16.zzzz, r16.xywx, r22.xyzx
 828:               mad r15.xyz, r11.xyzx, r16.xyzx, r15.xyzx
 829:             endif
 830:           else
 831:             mov r18.x, l(0)
 832:           endif
 833:           movc r15.xyz, r18.xxxx, r18.yzwy, r15.xyzx
 834:         endif
 835:       endif
 836:     else
 837:       mov r15.xyz, r17.xyzx
 838:     endif
 839:     mov r12.z, r13.y
 840:   endloop
 841:   mov r14.xyz, r15.xyzx
 842:   iadd r8.z, r8.z, l(1)
 843: endloop
 844: lt r2.x, l(0.500000), cb6[3].x
 845: if_nz r2.x
 846:   dp3 r2.x, r14.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 847:   add r2.yzw, -r2.xxxx, r14.xxyz
 848:   mad r2.xyz, cb6[3].zzzz, r2.yzwy, r2.xxxx
 849:   add r2.xyz, r2.xyzx, l(-0.500000, -0.500000, -0.500000, 0.000000)
 850:   mad r2.xyz, cb6[3].wwww, r2.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000)
 851:   mul r3.xyz, r2.xyzx, cb6[3].yyyy
 852:   mad r2.xyz, -r2.xyzx, cb6[3].yyyy, cb6[8].xyzx
 853:   mad r2.xyz, cb6[8].wwww, r2.xyzx, r3.xyzx
 854:   add r2.w, l(1.000000), -cb6[4].x
 855:   add r3.x, -r7.y, l(1.000000)
 856:   add r3.y, -r2.w, l(1.000000)
 857:   add r2.w, -r2.w, r3.x
 858:   div r3.x, l(1.000000, 1.000000, 1.000000, 1.000000), r3.y
 859:   mul_sat r2.w, r2.w, r3.x
 860:   mad r3.x, r2.w, l(-2.000000), l(3.000000)
 861:   mul r2.w, r2.w, r2.w
 862:   mul r2.w, r2.w, r3.x
 863:   mul r3.xyz, r2.wwww, cb6[9].xyzx
 864:   mad r14.xyz, r3.xyzx, cb6[4].yyyy, r2.xyzx
 865: endif
 866: mul r2.xyz, r14.xyzx, cb1[27].yyyy
 867: lt r2.w, cb1[122].w, l(0.500000)
 868: if_nz r2.w
 869:   mul r2.w, r0.w, r1.w
 870:   mad r3.x, r4.y, cb1[74].w, cb1[75].w
 871:   mad r3.y, r2.w, cb1[72].w, -cb1[71].w
 872:   max r3.xy, r3.xyxx, l(0.010000, 0.000000, 0.000000, 0.000000)
 873:   mul r3.z, r3.x, l(-1.442695)
 874:   exp r3.z, r3.z
 875:   add r3.z, -r3.z, l(1.000000)
 876:   div r3.x, r3.z, r3.x
 877:   mad r3.z, r4.y, cb1[74].w, cb1[76].w
 878:   mul r3.z, r3.z, l(1.442695)
 879:   exp r3.z, r3.z
 880:   mul r3.x, r3.z, r3.x
 881:   mul r3.x, r3.x, -r3.y
 882:   mul r3.xyz, r3.xxxx, cb1[73].xyzx
 883:   mul r3.xyz, r3.xyzx, l(1.442695, 1.442695, 1.442695, 0.000000)
 884:   exp r3.xyz, r3.xyzx
 885:   dp3 r3.w, -r1.xyzx, cb1[72].xyzx
 886:   mad r4.x, cb1[73].w, cb1[73].w, l(1.000000)
 887:   dp2 r4.y, r3.wwww, cb1[73].wwww
 888:   add r4.x, -r4.y, r4.x
 889:   lt r4.y, l(0), cb1[83].z
 890:   if_nz r4.y
 891:     and r8.w, l(7), cb1[26].w
 892:     imad r4.yzw, r8.xxyw, l(0, 0x0019660d, 0x0019660d, 0x0019660d), l(0.000000, 0.014584, 0.014584, 0.014584)
 893:     imad r4.y, r4.z, r4.w, r4.y
 894:     imad r4.z, r4.w, r4.y, r4.z
 895:     imad r4.w, r4.y, r4.z, r4.w
 896:     imad r5.x, r4.z, r4.w, r4.y
 897:     dp3 r0.x, -r1.xyzx, -r0.xyzx
 898:     lt r0.y, l(0.000000), r0.x
 899:     div r0.x, l(1.000000, 1.000000, 1.000000, 1.000000), r0.x
 900:     and r0.x, r0.x, r0.y
 901:     mul r0.x, r0.x, cb1[83].w
 902:     div r0.y, l(1.000000, 1.000000, 1.000000, 1.000000), r2.w
 903:     mul r0.z, r0.y, r0.x
 904:     mad r4.y, r0.z, v2.y, cb0[44].y
 905:     mad r0.z, -r0.z, v2.y, v2.y
 906:     mad r0.x, -r0.x, r0.y, l(1.000000)
 907:     mul r0.y, r2.w, r0.x
 908:     mul r5.z, r0.z, cb1[77].z
 909:     mul r0.z, r0.z, cb1[80].x
 910:     max r0.z, r0.z, l(-127.000000)
 911:     add r5.w, r4.y, -cb1[77].x
 912:     mul r5.w, r5.w, cb1[77].z
 913:     max r5.zw, r5.zzzw, l(0.000000, 0.000000, -127.000000, -127.000000)
 914:     exp r5.w, -r5.w
 915:     mul r5.w, r5.w, cb1[77].y
 916:     lt r6.x, l(0.000000), abs(r5.z)
 917:     exp r6.y, -r5.z
 918:     add r6.y, -r6.y, l(1.000000)
 919:     div r6.y, r6.y, r5.z
 920:     mad r5.z, -r5.z, l(0.240227), l(0.693147)
 921:     movc r5.z, r6.x, r6.y, r5.z
 922:     add r4.y, r4.y, -cb1[80].z
 923:     mul r4.y, r4.y, cb1[80].x
 924:     max r4.y, r4.y, l(-127.000000)
 925:     exp r4.y, -r4.y
 926:     mul r4.y, r4.y, cb1[80].y
 927:     lt r6.x, l(0.000000), abs(r0.z)
 928:     exp r6.y, -r0.z
 929:     add r6.y, -r6.y, l(1.000000)
 930:     div r6.y, r6.y, r0.z
 931:     mad r0.z, -r0.z, l(0.240227), l(0.693147)
 932:     movc r0.z, r6.x, r6.y, r0.z
 933:     mul r0.z, r0.z, r4.y
 934:     mad r0.z, r5.w, r5.z, r0.z
 935:     mad_sat r5.zw, r2.wwww, cb1[78].wwwy, cb1[78].zzzx
 936:     mul r0.y, r0.y, r0.z
 937:     exp r0.y, -r0.y
 938:     min r0.y, r0.y, l(1.000000)
 939:     max r0.y, r0.y, cb1[79].w
 940:     add r0.y, r5.w, r0.y
 941:     add r0.y, r5.z, r0.y
 942:     min r0.y, r0.y, l(1.000000)
 943:     imad r5.y, r4.w, r5.x, r4.z
 944:     ushr r4.yz, r5.xxyx, l(0, 16, 16, 0)
 945:     utof r4.yz, r4.yyzy
 946:     mad r4.yz, r4.yyzy, l(0.000000, 0.000031, 0.000031, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
 947:     mad r4.yz, r4.yyzy, cb1[87].wwww, r12.xxyx
 948:     mul r6.xy, r4.yzyy, cb1[85].xyxx
 949:     mad r4.y, v0.w, cb1[84].x, cb1[84].y
 950:     log r4.y, r4.y
 951:     mul r4.y, r4.y, cb1[84].z
 952:     div r6.z, r4.y, cb1[83].z
 953:     sample_l(texture3d)(float,float,float,float) r6.xyzw, r6.xyzx, t15.xyzw, s0, l(0)
 954:     add r4.y, v0.w, -cb1[86].z
 955:     mul_sat r4.y, r4.y, l(1000000.000000)
 956:     add r6.xyzw, r6.xyzw, l(-0.000000, -0.000000, -0.000000, -1.000000)
 957:     mad r6.xyzw, r4.yyyy, r6.xyzw, l(0.000000, 0.000000, 0.000000, 1.000000)
 958:     add r4.y, -r0.y, l(1.000000)
 959:     dp3_sat r4.z, r1.xyzx, cb1[81].xyzx
 960:     log r4.z, r4.z
 961:     mul r4.z, r4.z, cb1[82].w
 962:     exp r4.z, r4.z
 963:     mul r5.xyw, r4.zzzz, cb1[82].xyxz
 964:     mad r0.x, r0.x, r2.w, -cb1[81].w
 965:     max r0.x, r0.x, l(0)
 966:     mul r0.x, r0.x, r0.z
 967:     exp r0.x, -r0.x
 968:     min r0.x, r0.x, l(1.000000)
 969:     add r0.x, -r0.x, l(1.000000)
 970:     mul r5.xyw, r0.xxxx, r5.xyxw
 971:     add r0.x, -r5.z, l(1.000000)
 972:     mul r5.xyz, r0.xxxx, r5.xywx
 973:     mad r4.yzw, cb1[79].xxyz, r4.yyyy, r5.xxyz
 974:     mad r4.yzw, r4.yyzw, r6.wwww, r6.xxyz
 975:     mul r0.x, r0.y, r6.w
 976:   else
 977:     mul r0.y, v2.y, cb1[77].z
 978:     mul r0.z, v2.y, cb1[80].x
 979:     max r0.yz, r0.yyzy, l(0.000000, -127.000000, -127.000000, 0.000000)
 980:     add r5.x, cb0[44].y, -cb1[77].x
 981:     mul r5.x, r5.x, cb1[77].z
 982:     max r5.x, r5.x, l(-127.000000)
 983:     exp r5.x, -r5.x
 984:     mul r5.x, r5.x, cb1[77].y
 985:     lt r5.y, l(0.000000), abs(r0.y)
 986:     exp r5.z, -r0.y
 987:     add r5.z, -r5.z, l(1.000000)
 988:     div r5.z, r5.z, r0.y
 989:     mad r0.y, -r0.y, l(0.240227), l(0.693147)
 990:     movc r0.y, r5.y, r5.z, r0.y
 991:     add r5.y, cb0[44].y, -cb1[80].z
 992:     mul r5.y, r5.y, cb1[80].x
 993:     max r5.y, r5.y, l(-127.000000)
 994:     exp r5.y, -r5.y
 995:     mul r5.y, r5.y, cb1[80].y
 996:     lt r5.z, l(0.000000), abs(r0.z)
 997:     exp r5.w, -r0.z
 998:     add r5.w, -r5.w, l(1.000000)
 999:     div r5.w, r5.w, r0.z
1000:     mad r0.z, -r0.z, l(0.240227), l(0.693147)
1001:     movc r0.z, r5.z, r5.w, r0.z
1002:     mul r0.z, r0.z, r5.y
1003:     mad r0.y, r5.x, r0.y, r0.z
1004:     mad_sat r5.xy, r2.wwww, cb1[78].wyww, cb1[78].zxzz
1005:     mul r0.z, r2.w, r0.y
1006:     exp r0.z, -r0.z
1007:     min r0.z, r0.z, l(1.000000)
1008:     max r0.z, r0.z, cb1[79].w
1009:     add r0.z, r5.y, r0.z
1010:     add r0.z, r5.x, r0.z
1011:     min r0.x, r0.z, l(1.000000)
1012:     dp3_sat r1.x, r1.xyzx, cb1[81].xyzx
1013:     log r1.x, r1.x
1014:     mul r1.x, r1.x, cb1[82].w
1015:     exp r1.x, r1.x
1016:     mul r1.xyz, r1.xxxx, cb1[82].xyzx
1017:     mad r0.w, r0.w, r1.w, -cb1[81].w
1018:     max r0.w, r0.w, l(0)
1019:     mul r0.y, r0.w, r0.y
1020:     exp r0.y, -r0.y
1021:     min r0.y, r0.y, l(1.000000)
1022:     add r0.yz, -r0.yyxy, l(0.000000, 1.000000, 1.000000, 0.000000)
1023:     mul r1.xyz, r0.yyyy, r1.xyzx
1024:     add r0.y, -r5.x, l(1.000000)
1025:     mul r1.xyz, r0.yyyy, r1.xyzx
1026:     mad r4.yzw, cb1[79].xxyz, r0.zzzz, r1.xxyz
1027:   endif
1028:   mul r0.yzw, r0.xxxx, r3.xxyz
1029:   mad r1.x, r3.w, r3.w, l(1.000000)
1030:   mul r1.x, r1.x, l(0.059683)
1031:   mad r1.xyz, cb1[74].xyzx, r1.xxxx, cb1[76].xyzx
1032:   mad r1.w, -cb1[73].w, cb1[73].w, l(1.000000)
1033:   mul r2.w, r4.x, l(12.566371)
1034:   sqrt r3.w, r4.x
1035:   mul r2.w, r2.w, r3.w
1036:   max r2.w, r2.w, l(0.001000)
1037:   div r1.w, r1.w, r2.w
1038:   mad_sat r1.xyz, cb1[75].xyzx, r1.wwww, r1.xyzx
1039:   mul r1.xyz, r1.xyzx, l(255.000000, 255.000000, 255.000000, 0.000000)
1040:   add r3.xyz, -r3.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
1041:   mul r1.xyz, r1.xyzx, r3.xyzx
1042:   mad r1.xyz, r1.xyzx, r0.xxxx, r4.yzwy
1043:   mad r2.xyz, r2.xyzx, r0.yzwy, r1.xyzx
1044: endif
1045: mov o0.xyz, r2.xyzx
1046: mov o0.w, l(1.000000)
1047: mov o1.z, l(1.000000)
1048: ret
