"""Compare independent hardware triangle identity at unresolved depth positions."""
from hashlib import sha256
from pathlib import Path
import json
import runpy
import numpy as np

run=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
g=runpy.run_path(str(run/'body-outline-source-footprint.py'),run_name='source_footprint')
previous={tuple(r['point']):r for r in read(run/'body-outline-unqualified-depth-probe.json')['records']}
new=read(run/'trace-body-outline-source.json')
assert new['status']=='qualified'
controls=[]
for row in new['points']:
    point=tuple(row['point'])
    if point not in previous:
        continue
    x,y=point
    path=run/row['file']
    assert sha256(path.read_bytes()).hexdigest()==row['sha256']
    prior=previous[point]['inside']
    assert len(prior)==1
    state={}
    lanes=None
    hardware_float=hardware_clip=None
    for pc,changes in read(path):
        state.update(changes)
        if pc==50:hardware_clip=np.asarray(state['r6'][1:4],dtype=np.float32)
        if pc==56:hardware_float=np.asarray(state['r6'][1:3])
        if pc==64:
            lanes=state['r8'][:2]
            break
    assert lanes is not None
    address=np.asarray(lanes,dtype='<f4').view('<u4')
    assert hardware_float is not None and np.array_equal(np.floor(hardware_float),address)
    shape_sample=g['source_address'](x,y,row['primitive'])
    shape_address=np.floor(shape_sample).astype(int)
    a=g['g']
    indices=a['tri'][row['primitive']]
    snapped,_=a['bary'](np.asarray([x+.5,y+.5]),indices[None,:],a['pos'])
    weights=snapped[0]*a['pixel_w'][indices]
    position=(weights@g['src_xyz'][indices])/weights.sum()
    f32=np.float32
    def dot_clip(p):
        x,y,z=p.astype(f32)
        rows=g['cb0'][32:36][:,[0,1,3]]
        product=(rows[1]*y).astype(f32)
        product=(rows[0].astype(float)*float(x)+product).astype(f32)
        product=(rows[2].astype(float)*float(z)+product).astype(f32)
        return (product+rows[3]).astype(f32)
    def pixels(p):
        offset=p[2]*g['cb1'][19,2:4]
        ndc=(p[:2]+offset*[-2,2]).astype(f32)/p[2]
        uv=(ndc*.5+.5).astype(f32)
        return np.asarray([uv[0],f32(1-uv[1])],dtype=f32)*g['cb1'][0,:2]
    pixel=pixels(dot_clip(position))
    assert hardware_clip is not None
    native_math=pixels(hardware_clip)
    assert np.array_equal(native_math,hardware_float) and np.array_equal(np.floor(native_math),address)
    native_interpolant=np.linalg.solve(g['cb0'][32:35][:,[0,1,3]].T.astype(float),
                                       hardware_clip.astype(float)-g['cb0'][35][[0,1,3]])
    controls.append(dict(point=[x,y],hardwarePrimitive=row['primitive'],projectedPrimitive=prior[0]['triangle'],
        hardwareAddress=address.tolist(),projectedAddress=shape_address.tolist(),
        tracedSubpixelAddress=hardware_float.tolist(),projectedSubpixelAddress=shape_sample.tolist(),
        subpixelResidual=(hardware_float-shape_sample).tolist(),
        snappedSubpixelAddress=pixel.tolist(),snappedResidual=(hardware_float-pixel).tolist(),
        nativeRegistersClip=hardware_clip.tolist(),nativeRegisterProjectedAddress=native_math.tolist(),
        nativeRegisterProjectedError=(hardware_float-native_math).tolist(),
        snappedModelPosition=position.tolist(),inferredNativePosition=native_interpolant.tolist(),
        depthError=prior[0]['depthError'],primitiveExact=row['primitive']==prior[0]['triangle'],
        addressExact=bool(np.array_equal(address,shape_address))))
assert len(controls)==3
result=dict(status='compared',projectedAddressGate='failed' if not all(r['addressExact'] for r in controls) else 'passed',
            geometry=controls)
(run/'body-outline-geometry-witnesses.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
assert all(r['primitiveExact'] and r['addressExact'] for r in controls),result
