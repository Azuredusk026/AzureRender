"""Verify exact-product CTest reruns and the isolated editor-cache checks."""
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
from zipfile import ZipFile, ZIP_DEFLATED

from focused_retry import digest, records, status, verify


run = Path(__file__).resolve().parent
root = run.parents[2]
cold = run.parent/'20261115-095836-nr-editor-cold-pipeline-diagnostic-45f30c'
storage = run.parent/'20261114-173220-nr-shader-host-compiler-concurrency-d140b8'
target = root/'docs/acceptance/nr/evidence/2026-11-15/registered-host-and-storage-recoveries'


def read(path):
    return json.loads(path.read_bytes())


def verify_sources():
    expected_jobs = {971:('failed',8),972:('succeeded',0),973:('failed',8),
                     975:('failed',8),976:('succeeded',0),977:('failed',8),982:('succeeded',0),
                     983:('succeeded',0),984:('succeeded',0)}
    with sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True) as db:
        commands = {job:db.execute('select task,state,exit_code from jobs where id=?',(job,)).fetchone()
                    for job in expected_jobs}
    assert all(commands[job][1:]==expected for job,expected in expected_jobs.items())
    files = {'archive_host_and_storage_recoveries.py':Path(__file__).resolve(),
             'release-products.json':run/'release-products.json',
             'release-inventory.json':run/'release-inventory.json',
             'release-tests-source.json':run/'release-tests-source.json'}
    recovered = {}
    for group, first, retry in ((12,971,972),(13,973,976),(14,975,983)):
        tag = f'release-gpu-{group:02d}'
        rerun = tag+'-focused-retry-01'
        receipt = run/(rerun+'-receipt.json')
        recorded = verify(receipt)
        assert recorded['original']==tag and recorded['retest']==rerun and not recorded['unresolved']
        cases = records(run/(rerun+'.xml'))
        assert all(status(cases[name])=='passed' for name in recorded['recovered'])
        for name in recorded['recovered']:
            recovered[name] = dict(originalJob=first,retestJob=retry,seconds=float(cases[name].get('time')))
        for identifier in (tag,rerun):
            for ext in ('.json','.xml','.txt','.log'):
                name = identifier+ext
                files[name]=run/name
        files[receipt.name]=receipt
    assert set(recovered)=={'AzureRender.SamplingHostGpu','AzureAssets.ProceduralHost',
                            'AzureEngine.ManagedWorkflows.coreclr','AzureEngine.LocomotionBlendGpu'}
    sampling = read(cold/'control-results.json')
    procedural = read(cold/'control-retest-results.json')
    assert sampling['editorSha256']==procedural['editorSha256']==read(cold/'staging.json')['editor']
    assert sampling['driver']==procedural['driver']=='595.79'
    assert [row['exitCode'] for row in sampling['fixtures']]==[0,1]
    assert [row['exitCode'] for row in procedural['fixtures']]==[0]
    ok = (sampling['fixtures'][0],procedural['fixtures'][0])
    assert all('bytes=0, state=empty' in rec for row in ok for rec in row['cache'] if ' loaded:' in rec)
    managed_case = root/'build/ninja-msvc-release/managed-workflows/coreclr/summary.json'
    managed = read(managed_case)
    assert managed['status']=='passed' and managed['backend']=='coreclr'
    assert all(managed['package'][key] for key in ('moved','sourceUnavailable','engineUnavailable','tamperRejected'))
    files['coreclr-package-summary.json']=managed_case
    for name in ('staging.json','procedural-tool-products.json','control-results.json','control-retest-results.json',
                 'control/SamplingHostGpu/summary.json','control/ProceduralHost/registered-command.log',
                 'control-retest/ProceduralHost/summary.json','control-retest/ProceduralHost/registered-command.log',
                 'cold_editor_probe.py'):
        files['cold/'+name] = cold/name
    reclaimed = read(storage/'reclaimed-staging-copies.json')
    assert reclaimed['status']=='reclaimed' and reclaimed['releasesBytes']==sum(info['bytes'] for info in reclaimed['files'].values())
    assert (storage/'.finished').is_file()
    files['reclaimed-staging-copies.json']=storage/'reclaimed-staging-copies.json'
    report = dict(recovered=recovered,dispatch=commands,isolatedColdChecks={row['name']:row['seconds'] for row in ok},
                  cleanup=dict(files=len(reclaimed['files']), bytes=reclaimed['releasesBytes']),coreclrPackage=managed['package'])
    return report, files


def archive(report,files):
    target.mkdir()
    bundle = target/'verification.zip'
    checksums = {name:digest(path) for name,path in files.items()}
    with ZipFile(bundle,'w',compression=ZIP_DEFLATED,compresslevel=6) as package:
        for name,path in files.items():
            package.write(path,name)
    with ZipFile(bundle) as package:
        assert set(package.namelist())==checksums.keys() and package.testzip() is None
        assert all(sha256(package.read(name)).hexdigest()==expected for name,expected in checksums.items())
    report['archive']=dict(sha256=digest(bundle),files=checksums)
    (target/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Verified archive members',len(files))
    print(report['recovered'])


if __name__ == '__main__':
    archive(*verify_sources())
