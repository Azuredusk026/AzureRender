"""Replay both editor fixtures with exact products and independent pipeline caches."""
import argparse
from hashlib import file_digest
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time


run = Path(__file__).resolve().parent
root = run.parents[2]
build = root / 'build/ninja-msvc-release'
matrix = run.parent / '20261115-064800-nr-material-cache-regression-4d7a62'
package = run / 'editor-package'
shared = package / 'share/AzureRender'
exe = package / 'bin/AzureRender.exe'
fixtures = ('AzureRender.SamplingHostGpu', 'AzureAssets.ProceduralHost')
try:
    original = json.loads((matrix / 'release-products.json').read_bytes())
    inventory = json.loads((matrix / 'release-inventory.json').read_bytes())['tests']
except OSError as error:
    raise RuntimeError('The verified Release build is required') from error


def digest(path):
    with path.open('rb') as file:
        return file_digest(file, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n',encoding='utf-8')


def stage():
    assets = root / 'assets_public'
    package.mkdir()
    exe.parent.mkdir()
    shutil.copyfile(build / exe.name, exe)
    shutil.copytree(assets, shared / 'assets_public', ignore=shutil.ignore_patterns('.azure'))
    shutil.copyfile(build / 'runtime-build-Release.json', shared / 'runtime-build.json')
    shaders = shared / 'shaders'
    shaders.mkdir()
    copied = {}
    for source in sorted((build / 'shaders').glob('*.spv')):
        destination = shaders / source.name
        shutil.copyfile(source, destination)
        copied[source.name] = original['products'][str(source)]
    assert len(copied) == 897
    application = original['products'][str(build / exe.name)]
    assert digest(exe) == application
    proof = dict(editor=application, shaders=copied,
                 stagingManifest=digest(shared / 'runtime-build.json'),
                 registeredSource={t['name']:t['command'][1] for t in inventory if t['name'] in fixtures})
    save(run / 'staging.json',proof)
    print('Staged',len(copied),'programs and exact registered Release editor')


def stage_procedural_tools():
    compiler = build / 'AzureGeometryCompiler.exe'
    destination = exe.parent / compiler.name
    shutil.copyfile(compiler,destination)
    products = {str(destination):original['products'][str(compiler)]}
    scripts = [root/'tools/ai_bridge.py', *sorted((root/'tools/ai').rglob('*.py'))]
    for path in scripts:
        relative = path.relative_to(root)
        destination = shared / relative
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,destination)
        products[str(destination)] = original['source'][relative.as_posix()]
    assert all(digest(Path(name)) == sha for name,sha in products.items())
    save(run/'procedural-tool-products.json',products)


def exercise(role, application, selected):
    proof = read(run / 'staging.json')
    assert digest(shared / 'runtime-build.json') == proof['stagingManifest']
    assert all(digest(shared / 'shaders' / name) == sha for name, sha in proof['shaders'].items())
    identity = digest(application)
    if role.startswith('control'):
        assert application == exe and identity == proof['editor']
    assert application.parent == exe.parent
    driver = subprocess.check_output(['nvidia-smi.exe','--query-gpu=driver_version','--format=csv,noheader'],text=True).strip()
    assert driver == '595.79', driver
    environment = dict(os.environ, VK_LOADER_DRIVERS_SELECT='*nv-vk64*', DOTNET_ROOT='D:/Tools/dotnet9')
    environment['PATH'] = os.pathsep.join(map(str,(build,build/'vcpkg_installed/x64-windows/bin',environment['PATH'])))
    for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES','VK_LAYER_VALIDATE_SYNC','VK_LOADER_DEBUG'):
        environment.pop(key,None)
    rows = []
    if role == 'control-retest':
        assert selected == ['AzureAssets.ProceduralHost']
        assert all(digest(Path(name)) == sha for name,sha in read(run/'procedural-tool-products.json').items())
    for name in selected:
        info = next(row for row in inventory if row['name']==name)
        command = info['command'].copy()
        source = Path(command[1])
        assert digest(source) == original['source'][source.relative_to(root).as_posix()]
        budget = next(p['value'] for p in info['properties'] if p['name']=='TIMEOUT')
        fixture = name.split('.')[-1]
        directory = run/role/fixture
        directory.mkdir(parents=True)
        command[0] = sys.executable
        command[command.index('--executable')+1] = str(application)
        command[command.index('--output')+1] = str(directory)
        start = time.monotonic()
        with (directory/'registered-command.log').open('wb') as log:
            process = subprocess.run(command,cwd=root,env=environment,timeout=budget,stdout=log,stderr=subprocess.STDOUT)
        spent = round(time.monotonic()-start, 3)
        parts = [p for p in directory.rglob('stderr.log') if p.is_file()]
        cache = [line for p in parts for line in p.read_text(encoding='utf-8',errors='replace').splitlines()
                 if 'Pipeline cache loaded' in line or 'Pipeline cache saved' in line]
        assert cache and all('bytes=0, state=empty' in line for line in cache if ' loaded:' in line), cache
        row = dict(name=name, seconds=spent, timeoutSeconds=budget, exitCode=process.returncode,
                   command=command, cache=cache)
        rows.append(row)
        save(run/(role+'-results.json'),dict(editorSha256=identity, driver=driver,fixtures=rows))
        print(name,process.returncode,spent,flush=True)
    return 0 if all(row['exitCode']==0 for row in rows) else 8


if __name__ == '__main__':
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('mode',choices=('stage','stage-procedural-tools','control','control-retest','candidate'))
    parser.add_argument('--application',type=Path,default=exe)
    parser.add_argument('--fixture',action='append',choices=fixtures)
    args = parser.parse_args()
    if args.mode == 'stage':
        stage()
    elif args.mode == 'stage-procedural-tools':
        stage_procedural_tools()
    else:
        raise SystemExit(exercise(args.mode,args.application.resolve(),args.fixture or list(fixtures)))
