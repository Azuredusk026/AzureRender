"""Verify the original fifteen-round protocol and seal the cache-retention results."""
import csv
from hashlib import file_digest, sha256
import argparse
import json
from pathlib import Path
import re
import sqlite3
import sys
from zipfile import ZIP_DEFLATED, ZipFile


run = Path(__file__).resolve().parent
root = run.parents[2]
formal = run / "formal"
sys.path.insert(0, str(root / "tools"))
from performance_budget import BUDGETS, validate_round, working_set_growth


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def verify():
    report = read(formal / "summary.json")
    assert report["budgets"] == BUDGETS
    assert list(report["rounds"]) == ["standard", "editor", "stress", "exploration", "platformer"]
    assert report["products"] == read(formal / "frozen-inputs.json")["products"]
    provenance = read(run / "formal-runtime-provenance.json")
    assert provenance["registeredBuildReceiptSha256"] == digest(run / "release-products.json")
    assert all(report["products"][name] == value for name, value in provenance["products"].items())
    generated = root / "build/ninja-msvc-release/build-provenance.json"
    assert digest(generated) == (run / "previous-runtime-manifest-sha256.txt").read_text().strip()
    plan = read(run / "power-policy-restored.json")
    initial = read(run / "power-policy-before.json")
    assert initial["original"] == plan["active"] and initial["values"] == plan["values"]
    fan = read(run / "fan-restored.json")
    assert fan["automatic"] and fan["balanced"] and not fan["maximum"]
    with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro", uri=True) as connection:
        [dispatch] = connection.execute(
            "SELECT id,state,exit_code FROM jobs WHERE output=? AND task=? ORDER BY id DESC LIMIT 1",
            (str(run), "formal-five-workloads-15-rounds-settled-repeat"),
        ).fetchall()
    assert report["passed"] == (dispatch[1:] == ("succeeded", 0))
    evidence = {}
    raw = []
    for load, rounds in report["rounds"].items():
        assert len(rounds) == 3
        is_editor = load == "editor"
        evidence[load] = []
        for i, case in enumerate(rounds, 1):
            assert case["warmup"] == 300 and case["samples"] == 1800
            base = formal / f"{load}-{i}"
            extensions = [".memory.json", ".environment.json", ".json", ".csv", ".stderr.log",
                          ".stdout.log", ".input.json"]
            if is_editor:
                extensions.append(".editor.json")
            raw.extend(base.with_suffix(ext) for ext in extensions)
            memory = read(base.with_suffix(".memory.json"))
            assert case["workingSetSamplesBytes"] == [row["working"] for row in memory]
            assert case["peakWorkingSetBytes"] == max(row["peak"] for row in memory)
            assert case["stableWorkingSetGrowth"] == working_set_growth(case["workingSetSamplesBytes"])
            assert case["budgetFailures"] == validate_round(case, editor=is_editor)
            assert case["passed"] == (not case["budgetFailures"])
            assert all(row["driver"] == "595.79" for row in case["environment"]["runObservations"])
            with base.with_suffix(".csv").open() as stream:
                assert [int(row["frame"]) for row in csv.DictReader(stream)] == list(range(1, 2101))
            lines = base.with_suffix(".stderr.log").read_text(encoding="utf-8", errors="replace")
            loaded = re.search(r"Pipeline cache loaded: bytes=(\d+), state=(\S+)", lines)
            saved = re.search(r"Pipeline cache saved: bytes=(\d+), state=(\w+), requests=(\d+), hits=(\d+), feedback=(\d+)", lines)
            assert loaded and saved
            count, state, requests, hits, feedback = saved.groups()
            if state == "retained":
                assert int(count) == 0 and int(requests) != 0 and requests == hits == feedback
            evidence[load].append(dict(
                passed=case["passed"], failures=case["budgetFailures"], workingSetGrowth=case["stableWorkingSetGrowth"],
                peakWorkingSetBytes=case["peakWorkingSetBytes"], gpuP95Ms=case["gpu"]["p95"],
                cpuP95Ms=case["cpu"]["p95"], physicsP95Ms=case["physics"]["p95"], cacheState=state,
                loadedCacheBytes=int(loaded[1]), writtenCacheBytes=int(count), pipelineRequests=int(requests),
                pipelineHits=int(hits), validFeedback=int(feedback),
            ))
    count = sum(row["passed"] for rounds in evidence.values() for row in rounds)
    assert report["passed"] == (count == 15)
    files = [Path(__file__), *(formal / name for name in ("summary.json", "frozen-inputs.json")), *raw]
    files.extend(run / name for name in ("release-build-results.json", "source-activation.json", "formal-command.json",
        "formal-runtime-provenance.json", "previous-runtime-manifest-sha256.txt", "cooling-control-preflight.json",
        "prepare_max_fan_replay.py", "measurement.log", "measurement.stderr.log", "fan-ready.json",
        "fan-restored.json", "fan-observations.json", "power-policy-before.json", "power-policy-observations.json",
        "power-policy-ready.json", "power-policy-restored.json", "startup-cpu-observations.json"))
    return dict(passed=count, rounds=15, sourceCommit=report["sourceCommit"], driver="595.79", workloads=evidence,
                dispatch=dispatch, restoredPowerPlan=plan, restoredFan=fan), files


def archive(result, files, target):
    target.mkdir()
    package = target / "verification.zip"
    hashes = {path.relative_to(run).as_posix(): digest(path) for path in files}
    with ZipFile(package, "x", compression=ZIP_DEFLATED, compresslevel=6) as output:
        for path in files:
            output.write(path, path.relative_to(run).as_posix())
    with ZipFile(package) as output:
        assert set(output.namelist()) == hashes.keys() and output.testzip() is None
        assert all(sha256(output.read(name)).hexdigest() == value for name, value in hashes.items())
    result["archive"] = dict(sha256=digest(package), files=hashes)
    (target / "results.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--archive", type=Path)
    arguments = parser.parse_args()
    result, files = verify()
    if arguments.archive:
        archive(result, files, arguments.archive)
    print("Passed", result["passed"], "of 15 rounds;", len(files), "verified files")
    raise SystemExit(0 if result["passed"] == 15 else 1)
