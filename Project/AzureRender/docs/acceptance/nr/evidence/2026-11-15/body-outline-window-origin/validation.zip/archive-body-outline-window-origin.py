from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile

run=Path(__file__).resolve().parent
read=lambda p:json.loads((run/p).read_bytes())
input_path='trace-body-outline-address-controls-source.json'
capture=read(input_path)
base=read('body-outline-viewport-float-address-check.json')
calculation=read('body-outline-address-rounding-independent.json')
assert capture['status']=='qualified' and len(capture['points'])==39
assert sha256((run/input_path).read_bytes()).hexdigest()==calculation['qualifiedSourceSha256']
assert base['status']=='measured-original-plus-independent'
tested=calculation['models']['divideF32-top-down-mul-even']
assert tested==dict(reconstructedDepth=dict(matches=66,errors=[]),independent=dict(matches=39,errors=[]))
failure=base['controlGroups']['independent']['metrics']['float32ScaleTranslate']['mismatches']
assert failure==[[1272,1080]]
comparison=next(row for row in base['controlGroups']['independent']['samples'] if row['point']==failure[0])
assert comparison['hardware'][1]<360<comparison['predicted']['float32ScaleTranslate'][1]
assert calculation['sourceFootprint']==1118 and len(calculation['changedAddresses'])==327
output=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/body-outline-window-origin'
output.mkdir(parents=True,exist_ok=True)
file=output/'validation.zip'
names=['archive-body-outline-window-origin.py','body-outline-address-rounding-independent.py',
       'body-outline-address-rounding-independent.json','body-outline-viewport-float-address-check.py',
       'body-outline-viewport-float-address-check.json','trace-body-outline-source.py',
       input_path,'trace-body-outline-address-controls-request.json','trace-body-outline-addresses-source.json']
with ZipFile(file,'w',ZIP_DEFLATED) as archive:
    for name in names:archive.write(run/name,name)
with ZipFile(file) as archive:
    assert archive.testzip() is None
    checks={name:sha256(archive.read(name)).hexdigest() for name in names}
assert checks=={name:sha256((run/name).read_bytes()).hexdigest() for name in names}
proof=dict(status='qualified-native-outline-window-origin-controls',overall='failed-user-review',
    actualAddressesMatch=105,independentSamples=39,underlyingClipCoordinatePrecision=32,
    subpixelGridBits=8,origin='top-left',directCase=comparison,fullSourceFootprint=1118,
    modeledAddressesDifferingFromContinuous=327,archive=dict(sha256=sha256(file.read_bytes()).hexdigest(),members=checks))
(output/'results.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(proof['actualAddressesMatch'],proof['modeledAddressesDifferingFromContinuous'])

