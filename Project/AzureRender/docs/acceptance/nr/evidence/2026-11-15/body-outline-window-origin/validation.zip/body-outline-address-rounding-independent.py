"""Separate viewport division and fixed point rounding on independent outline samples."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


run=Path(__file__).resolve().parent
baseline=run/'body-outline-viewport-float-address-check.py'
state={'__file__':str(baseline)}
exec(compile(baseline.read_text(encoding='utf-8-sig').split('\nprevious={',1)[0],str(baseline),'exec'),state)
clip,extent,predict,indices=[state[key] for key in ('clip','extent','predict','indices')]
audit=json.loads((run/'body-outline-viewport-float-address-check.json').read_bytes())
assert audit['status']=='measured-original-plus-independent'
w=clip[:,3:4]
ratio={}
ratio['divideF32']=clip[:,:2]/w
ratio['divideF64']=clip[:,:2].astype('f8')/w
ratio['reciprocalF32']=clip[:,:2]*(np.float32(1)/w)
ratio['reciprocalF64Rounded']=(clip[:,:2].astype(float)*(np.float64(1)/w)).astype('f4')
repo=run.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e/body-receiver-physical-inputs.py'
source={'__file__':str(repo)}
exec(compile(repo.read_text(encoding='utf-8-sig').split('\nd3d_atlas=',1)[0],str(repo),'exec'),source)
ratio['nativeShaderReciprocal']=clip[:,:2]*source['reciprocal'](w)
configs={}
for name,coords in ratio.items():
    outputs={'sum-first':(coords+1)*extent,
             'multiply-first':coords*extent+extent,
             'fused-viewport':(coords.astype(float)*extent+extent).astype(coords.dtype),
             'float64-viewport':coords.astype(float)*extent+extent}
    native_y=coords.copy()
    native_y[:,1]*=-1
    top_down_outputs={'top-down-sum':(native_y+1)*extent,'top-down-mul':native_y*extent+extent,
        'top-down-fused':(native_y.astype(float)*extent+extent).astype(coords.dtype)}
    for method,top_down in top_down_outputs.items():
        adequate=top_down.astype(float)
        adequate[:,1]=2*extent[1]-adequate[:,1]
        outputs[method]=adequate
    for approach,screen in outputs.items():
        position=(screen*256).astype('f8')
        choices={'even':np.rint(position),'upward-tie':np.floor(position+.5),
            'downward-tie':np.ceil(position-.5)}
        for policy,selector in choices.items():
            mode='-'.join([name,approach,policy])
            raster=selector/256
            result={}
            for group,test in audit['controlGroups'].items():
                missed=[]
                for row in test['samples']:
                    x,y=row['point']
                    actual=predict(x,y,row['primitive'],raster)
                    if np.array_equal(np.floor(actual),row['address']):
                        continue
                    missed.append(dict(point=row['point'],predicted=actual.tolist(),observed=row['hardware']))
                result[group]=dict(matches=len(test['samples'])-len(missed),errors=missed)
            configs[mode]=result
fitting=[(tag,test['independent']['matches']) for tag,test in configs.items() if test['reconstructedDepth']['matches']==66]
print('all original at 66',len(fitting), 'highest independent', sorted(fitting,key=lambda n:-n[1])[:12],flush=True)
expected=ratio['divideF32'].copy()
expected[:,1]*=-1
raster=np.rint((expected*extent+extent)*256).astype(float)/256
raster[:,1]=2*extent[1]-raster[:,1]
canonical=configs['divideF32-top-down-mul-even']
assert canonical['reconstructedDepth']['matches']==66 and canonical['independent']['matches']==39
origin=json.loads((run/'body-outline-source-footprint.json').read_bytes())['points']
changes=[]
for x,y,left,top,primitive,*_ in origin:
    address=np.floor(predict(x,y,primitive,raster)).astype('i4')
    sampled=[int(address[0]),1439-int(address[1])]
    if sampled!=[left,top]:
        changes.append(dict(point=[x,y],continuous=[left,top],nativeViewport=sampled))
assert len(origin)==1118
print('source model changed',len(changes),'of',len(origin),flush=True)
vertices=indices[3803]
report={name:{'ndc':item[vertices].tolist(),'viewport':((item[vertices]*extent+extent)*256).tolist()} for name,item in ratio.items()}
(result_path:=run/'body-outline-address-rounding-independent.json').write_text(json.dumps(dict(
    status='measured-independent-viewport-arithmetic',models=configs,triangle3803=report,sourceFootprint=len(origin),changedAddresses=changes,
    qualifiedSourceSha256=sha256((run/'trace-body-outline-address-controls-source.json').read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf8')
print(report,flush=True)

