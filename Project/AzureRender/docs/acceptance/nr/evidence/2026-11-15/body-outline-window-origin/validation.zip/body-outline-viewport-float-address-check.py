"""Compare float32 viewport raster coordinates against native fragment addresses."""
from hashlib import file_digest
from pathlib import Path
import json

import numpy as np


root=Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
trace=root.parent/'20261114-032642-body-outline-native-shading-a58fc7'
geometry=grid/'native-face-skin-stages'
read=lambda p:json.loads(p.read_bytes())


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


source=read(geometry/'results.json')['geometry']['1018']
vertex_path,index_path=[geometry/f'{name}-1018.bin' for name in ('vertex','index')]
for name,path in (('vertex',vertex_path),('index',index_path)):
    assert digest(path)==source[name+'Sha256']
verts=np.fromfile(vertex_path,'<f4').reshape(-1,23)
indices=np.fromfile(index_path,'<u2').reshape(-1,3)+source['baseVertex']
clip=verts[:,:4]
world=verts[:,6:9].astype(np.float64)
reciprocal_w=1/clip[:,3].astype(np.float64)
cb0,cb1=[np.fromfile(trace/f'ps-cb{i}.bin','<f4').reshape(-1,4) for i in (0,1)]
matrix=cb0[32:36][:,[0,1,3]]
extent=cb1[0,:2]*.5
assert tuple(extent)==(1280,720)
ndc32=clip[:,:2]/clip[:,3,None]
ndc64=clip[:,:2].astype(np.float64)/clip[:,3,None]
float_snap=lambda screen:np.rint(screen*256)/256
screens={
    'continuousFloat64':(ndc64+1)*extent,
    'snappedFloat64':float_snap((ndc64+1)*extent),
    'float32TranslateScale':float_snap((ndc32+1)*extent),
    'float32ScaleTranslate':float_snap(ndc32*extent+extent),
    'float32FusedScaleTranslate':float_snap((ndc32.astype(np.float64)*extent+extent).astype(np.float32)),
}


def position(point, triangle, screen):
    a,b,c=screen[triangle].astype(np.float64)
    u0,v0=b-a
    u1,v1=c-a
    dx,dy=point-a
    area=u0*v1-u1*v0
    assert area!=0
    s,t=(dx*v1-dy*u1)/area,(u0*dy-v0*dx)/area
    barycentric=np.asarray([1-s-t,s,t])
    weights=barycentric*reciprocal_w[triangle]
    return weights@world[triangle]/weights.sum()


def shader_transform(value):
    x,y,z=value.astype(np.float32)
    partial=matrix[1]*y
    partial=(matrix[0].astype(np.float64)*x+partial).astype(np.float32)
    partial=(matrix[2].astype(np.float64)*z+partial).astype(np.float32)
    return partial+matrix[3]


def shader_address(value):
    offset=value[2]*cb1[19,2:4]
    ndc=(value[:2]+offset*np.asarray([-2,2],np.float32))/value[2]
    uv=ndc*.5+.5
    return np.asarray([uv[0],np.float32(1-uv[1])],dtype=np.float32)*cb1[0,:2]


def predict(x,y,primitive,screen):
    pos=position(np.array([x+.5,y+.5]),indices[primitive],screen)
    return shader_address(shader_transform(pos))


previous={tuple(row['point']):row['primitive'] for row in read(root/'body-outline-66-native-addresses.json')['samples']}
baseline=read(root/'body-outline-source-footprint.json')['points']
normal_set={(row[0],row[1]):row[4] for row in baseline}
inputs={}
groups={}
for label,suffix in (('reconstructedDepth','addresses'),('independent','address-controls')):
    report=root/f'trace-body-outline-{suffix}-source.json'
    if not report.is_file():
        assert label=='independent'
        continue
    source=read(report)
    assert source['status']=='qualified' and len(source['points'])>0
    inputs[report.name]=digest(report)
    samples=[]
    for row in source['points']:
        x,y=row['point']
        primitive=row['primitive']
        assert (previous if label=='reconstructedDepth' else normal_set)[x,y]==primitive,row
        address=np.asarray(row['addressBits'],dtype='<f4').view('<u4')
        hardware=shader_address(np.asarray(row['clip'],dtype=np.float32))
        assert np.array_equal(hardware,row['floatAddress']) and np.array_equal(np.floor(hardware),address)
        predicted={name:predict(x,y,primitive,screen) for name,screen in screens.items()}
        samples.append(dict(point=[x,y],primitive=primitive,address=address.tolist(),
            hardware=hardware.tolist(),predicted={name:v.tolist() for name,v in predicted.items()},
            matches={name:bool(np.array_equal(np.floor(v),address)) for name,v in predicted.items()}))
    measures={}
    for name in screens:
        error=np.asarray([np.asarray(row['predicted'][name])-row['hardware'] for row in samples])
        mismatches=[row['point'] for row in samples if not row['matches'][name]]
        measures[name]=dict(integerMatches=len(samples)-len(mismatches),meanAbsSubpixel=float(np.abs(error).mean()),
                            maxAbsSubpixel=float(np.abs(error).max()),mismatches=mismatches)
    groups[label]=dict(count=len(samples),metrics=measures,samples=samples)
    print(label,len(samples),json.dumps(measures))
assert groups['reconstructedDepth']['count']==66
assert all(groups['reconstructedDepth']['metrics'][name]['integerMatches']==66
           for name in ('float32TranslateScale','float32ScaleTranslate'))
if 'independent' in groups:
    assert 36<=groups['independent']['count']<=66
    assert not (set(previous)&{tuple(row['point']) for row in groups['independent']['samples']})
basis=screens['float32TranslateScale']
full_predictions=[]
for x,y,old_x,old_y,primitive,*_ in baseline:
    value=np.floor(predict(x,y,primitive,basis)).astype(int)
    point=[int(value[0]),1439-int(value[1])]
    if point!=[old_x,old_y]:full_predictions.append(dict(point=[x,y],continuous=[old_x,old_y],float32=point))
result=dict(status='measured-original-plus-independent' if 'independent' in groups else 'measured-original',
    nativeSources=inputs,fullFootprintChangedAddresses=full_predictions,controlGroups=groups)
(root/'body-outline-viewport-float-address-check.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print('full footprint changed addresses',len(full_predictions),'of',len(baseline))
