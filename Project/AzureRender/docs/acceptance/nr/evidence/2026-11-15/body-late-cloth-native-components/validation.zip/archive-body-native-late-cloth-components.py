"""Archive the late cloth blend witnesses and trace-to-frame correspondence."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile


root=Path(__file__).resolve().parent
stage=root/'body-native-late-cloth-traces'
target=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/body-late-cloth-native-components'
cloth=root.parent/'20261114-144753-cloth-directional-rim-actual-4b9034'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
computed=read(stage/'component-analysis.json')
trace=read(stage/'results.json')
assert trace['status']=='qualified' and computed['status']=='measured-native-late-cloth-components'
assert computed['sourceTrace']==digest(stage/'results.json')
assert [row['point'] for row in computed['witnesses']]==[row['point'] for row in trace['draws']]
assert read(stage/'request.json')['attachment']=='ResourceId::141925'
paths={p.name:p for p in (Path(__file__),root/'body-native-late-cloth-components.py',
                         root/'body-native-late-cloth-traces.py',stage/'component-analysis.json',
                         stage/'request.json',stage/'results.json')}
for row in trace['draws']:
    p=stage/row['traceFile']
    assert digest(p)==row['sha256']
    paths['registers/'+p.name]=p
for device in ('nvidia','intel'):
    entry=cloth/f'cloth-directional-{device}/results.json'
    paths[f'{device}/cloth-directional.json']=entry
    confirmed=root/f'body-outline-beauty-transparent-highlights-captured-origin-{device}/results.json'
    paths[f'{device}/outline-origin.json']=confirmed
    assert [k['players'][device]['clothDirectional']['peak'] for k in computed['witnesses']]==[3,1,2,5]
target.mkdir(parents=True,exist_ok=True)
archive=target/'validation.zip'
with ZipFile(archive,'w',ZIP_DEFLATED) as output:
    for name,path in paths.items():output.write(path,name)
with ZipFile(archive) as stored:
    assert stored.testzip() is None
    contents={name:sha256(stored.read(name)).hexdigest() for name in paths}
assert contents=={name:digest(path) for name,path in paths.items()}
computed['archive']=dict(sha256=digest(archive),members=contents)
computed['qualification']='source-and-independent-player-fixtures'
(target/'results.json').write_text(json.dumps(computed,indent=2)+'\n',encoding='utf8')
print(archive)
