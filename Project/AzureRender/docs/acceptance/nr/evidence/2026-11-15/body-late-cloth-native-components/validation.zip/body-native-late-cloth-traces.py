"""Trace the last native transparent-cloth draws over the outlined body."""
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import subprocess
import traceback

key='AZURE_NR_LATE_CLOTH_OWNER_TRACE'
root=Path(os.environ[key]).parent if key in os.environ else Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
name='body-native-late-cloth-traces'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,obj:p.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf8')


def trace(folder):
    import renderdoc as rd
    job=read(folder/'request.json')
    result=dict(status='failed',event=1383,draws=[])
    capture=rd.OpenCaptureFile()
    ctl=None
    try:
        assert capture.OpenFile(job['native'],'',None)==rd.ResultCode.Succeeded
        options=rd.ReplayOptions()
        options.forceGPUVendor=rd.GPUVendor.nVidia
        options.forceGPUDeviceID=0x28e0
        status,ctl=capture.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and ctl
        props=ctl.GetAPIProperties()
        assert props.vendor==rd.GPUVendor.nVidia and not props.degraded and props.pipelineType==rd.GraphicsAPI.D3D11
        ctl.SetFrameEvent(1383,True)
        pipeline=ctl.GetPipelineState()
        shader=pipeline.GetShaderReflection(rd.ShaderStage.Fragment)
        assert sha256(bytes(shader.rawBytes)).hexdigest()==job['shaderSha256']
        target=pipeline.GetOutputTargets()[0].resource
        attachment=job['attachment']
        assert str(target)==attachment
        for x,y in job['points']:
            write(folder/'progress.json',dict(point=[x,y],completed=[item['point'] for item in result['draws']]))
            ctl.SetFrameEvent(1383,True)
            mods=ctl.PixelHistory(target,x,1439-y,rd.Subresource(),rd.CompType.Typeless)
            draws=[entry for entry in mods if entry.eventId==1383 and not (entry.depthTestFailed or entry.stencilTestFailed
                or entry.backfaceCulled or entry.shaderDiscarded)]
            assert draws,(x,y)
            for hit in draws:
                ctl.SetFrameEvent(1383,True)
                params=rd.DebugPixelInputs()
                params.primitive=hit.primitiveID
                debug=ctl.DebugPixel(x,1439-y,params)
                assert debug and debug.debugger,(x,y,params.primitive)
                states=[]
                try:
                    while True:
                        steps=ctl.ContinueDebug(debug.debugger)
                        if not steps:break
                        for step in steps:
                            changes={}
                            for change in step.changes:
                                after=change.after
                                if after.name:
                                    changes[after.name]=[
                                        value if math.isfinite(value) else None for value in list(after.value.f32v)[:4]]
                            states.append([int(step.nextInstruction),changes])
                        assert len(states)<20000,(x,y,len(states))
                finally:
                    ctl.FreeTrace(debug)
                assert any(regs.get('o0') for _,regs in states)
                path=folder/f'e1383-{x}-{y}-{int(hit.primitiveID)}.json'
                write(path,states)
                color=lambda item:list(item.col.floatValue)[:4]
                result['draws'].append(dict(point=[x,y],primitive=int(hit.primitiveID),
                    before=color(hit.preMod),source=color(hit.shaderOut),after=color(hit.postMod),
                    traceFile=path.name,sha256=sha256(path.read_bytes()).hexdigest(),steps=len(states)))
        result['status']='qualified'
    except Exception:
        result['error']=traceback.format_exc()
    finally:
        if ctl:ctl.Shutdown()
        capture.Shutdown()
        write(folder/'results.json',result)
    os._exit(0 if result['status']=='qualified' else 1)


def main():
    from hashlib import file_digest
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==root
    folder=root/name
    if folder.is_dir():
        assert not (folder/'results.json').is_file() or read(folder/'results.json')['status']!='qualified'
        folder.rename(root/f'{name}-interrupted-{len(list(root.glob(name+"-interrupted-*")))+1}')
    folder.mkdir()
    job=read(grid/'native-face-masks/request.json')
    with Path(job['native']).open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==job['captureSha256']
    job['shaderSha256']=read(grid/'native-face-skin-stages/results.json')['geometry']['1383']['pixelShaderSha256']
    manifest=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/post-opaque-ownership/manifest.json')
    record,=[row for row in read(manifest)['events'] if row['event']==1383]
    job['attachment']=record['target']
    assert job['attachment']=='ResourceId::141925'
    ownership=read(root/'body-outline-remaining-draw-ownership.json')['devices']['nvidia']['events']['1383']['witnesses']
    job['points']=[ownership[0]['point'],ownership[1]['point'],[1152,797],[1234,789]]
    assert all(point in [row['point'] for row in ownership] for point in job['points'][:3])
    write(folder/'request.json',job)
    startup=subprocess.STARTUPINFO()
    startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=0
    with (folder/'replay.log').open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=folder,env=dict(os.environ,**{key:str(folder)}),stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=210)
    outcome=read(folder/'results.json')
    assert child.returncode==0 and outcome['status']=='qualified',outcome.get('error')


if key in os.environ:
    trace(Path(os.environ[key]))
elif __name__=='__main__':
    main()
