"""Reconstruct the original transparent cloth contribution at outline witnesses."""
from hashlib import file_digest
import json
from pathlib import Path
import runpy

import numpy as np


root=Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
cloth=root.parent/'20261114-144753-cloth-directional-rim-actual-4b9034'
stage=root/'body-native-late-cloth-traces'
read=lambda p:json.loads(p.read_bytes())
base=read(stage/'results.json')
assert base['status']=='qualified' and len(base['draws'])==4
score=runpy.run_path(str(grid/'static-quality.py'))
frozen=score['image'](score['reference_path']).astype(np.int16)


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def display(color):
    linear=np.clip(color,0,1)
    return np.rint(np.where(linear<=.0031308,12.92*linear,1.055*linear**(1/2.4)-.055)*255).astype(np.int16)


renders={}
for device in ('nvidia','intel'):
    folders={
        'outlineOrigin':root/f'body-outline-beauty-transparent-highlights-captured-origin-{device}',
        'clothDirectional':cloth/f'cloth-directional-{device}',
    }
    renders[device]={}
    for name,folder in folders.items():
        expected=read(folder/'results.json')
        path=folder/'frames/frame_000000.png'
        assert digest(path)==expected['frameSha256']
        renders[device][name]=score['image'](path).astype(np.int16)


rows=[]
for row in base['draws']:
    state={}
    at={}
    needed={26,1470,1471,1483,1484,1505,1549,1564,1568,1601,1629,1630,1640,2147,2168,2169,2173,2350}
    blob=stage/row['traceFile']
    assert digest(blob)==row['sha256']
    for instruction,updates in read(blob):
        state.update(updates)
        if instruction in needed:
            at[instruction]=dict(state)

    def lane(step,register,idx=slice(0,3)):
        return np.asarray(at[step][register],dtype=float)[idx]

    diffuse=lane(1471,'r23')*lane(1470,'r11',3)
    direct_specular=lane(1483,'r10')
    assert np.abs(diffuse+direct_specular-lane(1484,'r10')).max()<2e-7
    saturated=lane(1549,'r10')
    rim_first=lane(1564,'r6',slice(1,4))
    rim_tinted=rim_first*lane(1568,'r20',[0,2,3])
    main_rim=rim_tinted+lane(1601,'r18')
    indirect_specular=lane(1629,'r16')*lane(1629,'r15')
    before_loop=lane(1640,'r16')
    assert np.abs(saturated+main_rim+indirect_specular-before_loop).max()<2e-7
    post_loop=lane(2147,'r16')
    local=post_loop-before_loop
    material_rim=lane(2169,'r16')-lane(2168,'r1')
    adjustment=lane(2168,'r1')-post_loop
    post_adjustment=lane(2169,'r16')
    values=np.asarray(row['source'],dtype=float)
    shader,alpha=values[:3],values[3]
    traced=lane(2350,'o0')
    assert alpha==lane(2350,'o0',3)==lane(2173,'o0',3)
    scaling=.25
    before=np.asarray(row['before'][:3])*scaling
    after=np.asarray(row['after'][:3])*scaling
    prediction=shader*scaling*alpha+before*(1-alpha)
    closure=np.abs(prediction-after).max()
    assert closure<.004
    x,y=row['point']
    expected=frozen[y,x]
    assert np.abs(display(after)-expected).max()<=1
    components={
        'mainDiffuse':diffuse,
        'mainSpecular':direct_specular,
        'mainSaturation':saturated-diffuse-direct_specular,
        'directionalRim':main_rim,
        'indirectSpecular':indirect_specular,
        'localLights':local,
        'colorAdjustment':adjustment,
        'materialRim':material_rim,
        'fogAndExposure':traced-post_adjustment,
    }
    assert np.abs(sum(components.values())-traced).max()<3e-7
    rows.append(dict(point=[x,y],primitive=row['primitive'],alpha=alpha,shader=(shader*scaling).tolist(),
        normalDotView=lane(1505,'r13',3).item(),nativeBefore=before.tolist(),nativeAfter=after.tolist(),
        blendPredicted=prediction.tolist(),blendRoundingPeak=float(closure),reference=expected.tolist(),
        beforeDisplay=display(before).tolist(),afterDisplay=display(after).tolist(),
        traceOutput=(traced*scaling).tolist(),traceToHardwarePeak=float(np.abs(traced-shader).max()*scaling),
        primaryDiffuseRedFraction=float(diffuse[0]/traced[0]),
        nativeComponents={name:(component*scaling).tolist() for name,component in components.items()},
        players={device:{name:dict(color=im[y,x].tolist(),peak=int(np.abs(im[y,x]-expected).max()))
                        for name,im in variants.items()} for device,variants in renders.items()}))
assert all(row['primaryDiffuseRedFraction']>.975 for row in rows[:2])
assert all(row['nativeComponents']['materialRim']==[0,0,0] for row in rows[:2])
result=dict(status='measured-native-late-cloth-components',colorSpace='linear exposure 0.25',
            sourceTrace=digest(stage/'results.json'),reference=digest(score['reference_path']),witnesses=rows)
(stage/'component-analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps([dict(point=row['point'],alpha=row['alpha'],redFraction=row['primaryDiffuseRedFraction'],
    materialRim=row['nativeComponents']['materialRim'],candidates=row['players']) for row in rows]))
