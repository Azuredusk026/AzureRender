from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile

root=Path(__file__).resolve().parent
evidence=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()


def archive(name,report,members):
    target=evidence/name
    target.mkdir(parents=True,exist_ok=True)
    members['archive-current-dynamic-and-hair-owner.py']=Path(__file__)
    package=target/'validation.zip'
    with ZipFile(package,'w',ZIP_DEFLATED) as output:
        for relative,file in members.items():output.write(file,relative)
    with ZipFile(package) as output:
        assert output.testzip() is None
        checks={relative:sha256(output.read(relative)).hexdigest() for relative in members}
    assert checks=={relative:digest(file) for relative,file in members.items()}
    report['archive']=dict(sha256=digest(package),members=checks)
    (target/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')


folder=root/'joint-character-reopen-current'
dynamic=read(folder/'results.json')
retained=read(root/'retained-character-motion.json')
assert dynamic['status']=='current-persisted-project-reopens' and dynamic['animationInstances']==retained['animationInstances']==11
assert retained['exactReopen'] and retained['archivedOriginalFrames']==retained['archivedClosedLoopFrames']==192
assert dynamic['historicalDriverUnqualified'] and dynamic['nativeContinuousVisualAcceptance']=='pending'
assert len(dynamic['frames'])==4
for item in dynamic['frames']:
    assert digest(folder/'frames'/item['frame'])==item['sha256']
assert [row['overOne'] for row in dynamic['frames']]==[28,48,56,62]
archive('current-joint-character-reopen',dict(current=dynamic,retained=retained),{
    **{name:folder/name for name in ('results.json','command.json','frames/capture_manifest.json','frames/gpu_capabilities.json')},
    **{name:root/name for name in ('joint-character-reopen-current.py','retained-character-motion.json')},
})

result_path=root/'hair-native-owner-hardware-comparison.json'
hair=read(result_path)
assert hair['status']=='qualified-native-ownership'
assert len(hair['points'])==5 and all(row['primitive'][0]==row['primitive'][1] for row in hair['points'])
assert max(row['nativeTargetAbsolute'] for row in hair['points'])==.1484375
assert [key for row in hair['points'] if all(val[0]==val[1] for val in row['packedLanes'].values())
        for key in [row['point']]]==[[1280,195]]
members={name:root/name for name in ('hair-native-owner-control.py','hair-native-owner-hardware-comparison.json')}
for vendor in ('nvidia','intel'):
    local=root/f'hair-native-owner-hardware-{vendor}'
    receipt=read(local/'results.json')
    assert receipt['status']=='qualified' and len(receipt['points'])==5
    assert set(receipt['hardwareLanes'])=={'copy','base','layer','normal','alpha'}
    members.update({f'{vendor}/{name}':local/name for name in ('request.json','results.json')})
archive('native-hair-hardware-owners',hair,members)
