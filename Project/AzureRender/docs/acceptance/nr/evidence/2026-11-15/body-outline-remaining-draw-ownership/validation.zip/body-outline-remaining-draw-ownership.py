"""Separate remaining body-outline errors from draws that overwrite it."""
import gzip
from hashlib import file_digest
import json
from pathlib import Path
import runpy
import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
diagnostics=run.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
read=lambda p:json.loads(p.read_bytes())
score=runpy.run_path(str(grid/'static-quality.py'))
stage=score['stages']/'post-opaque-ownership'
owner_data=diagnostics/'body-visible-ownership-points.bin'
reference=score['reference_path']

def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()

def pixels(path):
    with Image.open(path) as image:
        return np.asarray(image.convert('RGB'),dtype=np.int16)

def packed(path):
    return np.frombuffer(gzip.decompress(path.read_bytes()),'<u4').reshape(1440,2560)[::-1]

def rgb(words):
    channels=[]
    for shift,bits in ((0,6),(11,6),(22,5)):
        lane=(words>>shift)&((1<<(bits+5))-1)
        exponent=(lane>>bits).astype(int)
        fraction=lane&((1<<bits)-1)
        channels.append(np.where(exponent==0,np.ldexp(fraction.astype(float),-14-bits),
                                 np.ldexp(1+fraction/(1<<bits),exponent-15)))
    linear=np.clip(np.stack(channels,axis=-1)*.25,0,1)
    return np.rint(np.where(linear<=.0031308,12.92*linear,1.055*linear**(1/2.4)-.055)*255).astype(np.int16)

points=np.fromfile(owner_data,'<u2').reshape(-1,3)
assert points.shape==(1184,3)
x,y,owner=points.T
a=stage/'1018-1018.bin.gz'
b=stage/'1383-1383.bin.gz'
c=stage/'1383-1382.bin.gz'
outline_stage=rgb(packed(a)[y,x])
cloth_after=rgb(packed(b)[y,x])
cloth_before=rgb(packed(c)[y,x])
final= pixels(reference)[y,x]
device_records={}
for device in ('nvidia','intel'):
    folder=run/f'body-outline-beauty-transparent-highlights-{device}'
    frame=folder/'frames/frame_000000.png'
    metadata=read(folder/'results.json')
    assert digest(frame)==metadata['frameSha256']
    actual=pixels(frame)[y,x]
    error=np.abs(actual-final).max(1)
    stage_error=np.abs(actual-outline_stage).max(1)
    residual=np.abs(outline_stage-final).max(1)
    masks={}
    for source in sorted(set(owner)):
        region=owner==source
        indices=np.where(region)[0]
        order=sorted(indices,key=lambda i:(-int(error[i]),int(y[i]),int(x[i])))[:10]
        masks[str(source)]=dict(pixels=len(indices),stageOverEight=int((stage_error[region]>8).sum()),
            finalOverEight=int((error[region]>8).sum()),nativeStageToFinalOverEight=int((residual[region]>8).sum()),
            witnesses=[dict(point=[int(x[i]),int(y[i])],actual=actual[i].tolist(),
                nativeOutline=outline_stage[i].tolist(),nativeFinal=final[i].tolist(),nativeClothBefore=cloth_before[i].tolist(),
                nativeClothAfter=cloth_after[i].tolist(),stagePeak=int(stage_error[i]),finalPeak=int(error[i])) for i in order])
    worst=sorted(range(len(error)),key=lambda i:(-int(error[i]),int(y[i]),int(x[i])))[:7]
    assert all(owner[i]==1383 for i in worst)
    assert masks['1018']['nativeStageToFinalOverEight']==0
    assert masks['1383']['nativeStageToFinalOverEight']==57
    device_records[device]=dict(frame=metadata['frameSha256'],events=masks)
result=dict(status='measured-final-draw-ownership',strictVisualAcceptance='failed-user-review',
    inputSha256={path.name:digest(path) for path in (owner_data,reference,a,b,c)},devices=device_records)
(run/'body-outline-remaining-draw-ownership.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
for device,data in device_records.items():
    summary={e:[r['pixels'],r['stageOverEight'],r['finalOverEight']] for e,r in data['events'].items()}
    worst={e:[w['point'] for w in data['events'][e]['witnesses'][:3]] for e in ('1018','1383')}
    print(device,summary,worst)
