from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile

root=Path(__file__).resolve().parent
target=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/body-outline-remaining-draw-ownership'
record=root/'body-outline-remaining-draw-ownership.json'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
data=json.loads(record.read_bytes())
assert data['status']=='measured-final-draw-ownership'
files={name:root/name for name in ('body-outline-remaining-draw-ownership.py',
    'body-outline-remaining-draw-ownership.json','archive-body-outline-remaining-draw-ownership.py')}
for gpu,count in (('nvidia',177),('intel',178)):
    saved=root/f'body-outline-beauty-transparent-highlights-{gpu}'
    receipt=json.loads((saved/'results.json').read_bytes())
    evidence=data['devices'][gpu]
    assert receipt['frameSha256']==evidence['frame']==digest(saved/'frames/frame_000000.png')
    responses=evidence['events']
    assert (responses['1018']['finalOverEight'],responses['1383']['finalOverEight'])==(count,56)
    assert responses['1383']['witnesses'][0]['point']==[1252,839]
    for name in ('results.json','frames/gpu_capabilities.json','command.json'):
        files[f'{gpu}/{name}']=saved/name
target.mkdir(parents=True,exist_ok=True)
package=target/'validation.zip'
with ZipFile(package,'w',ZIP_DEFLATED) as archive:
    for name,path in files.items():archive.write(path,name)
with ZipFile(package) as archive:
    assert archive.testzip() is None
    hashes={name:sha256(archive.read(name)).hexdigest() for name in files}
assert hashes=={name:digest(path) for name,path in files.items()}
data['archive']=dict(sha256=digest(package),members=hashes)
(target/'results.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
