"""Preserve the stopped shader-host fixture on the recovery volume before releasing its reservation."""
from hashlib import file_digest
import json
import os
from pathlib import Path
import shutil
import sqlite3
import sys


run = Path(__file__).resolve().parent
root = run.parents[2]
sys.path.insert(0, str(root / "tools"))
from artifact_maintenance import inventory, measure, pool_budget


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def main():
    with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro", uri=True) as connection:
        assert connection.execute("SELECT state,reason FROM jobs WHERE id=1066").fetchone() == (
            "budget-stopped", "managed-pool-limit")
        assert not connection.execute("SELECT id FROM jobs WHERE output=? AND state IN ('pending','running')",
                                      (str(run),)).fetchall()
    fixture = run / "tmp/azure shader host ngdtt6r2"
    assert fixture.resolve() == fixture and fixture.parent.parent == run
    local = Path(os.environ["LOCALAPPDATA"]).resolve(strict=True)
    archive = local / "AzureRender/build-recovery"
    assert local.anchor.casefold() == "c:\\" and archive.resolve() == archive and archive.is_dir()
    destination = archive / (run.name + "-aborted-shader-host")
    assert destination.parent == archive
    path = run / "aborted-shader-host-copy.json"
    if path.is_file():
        recorded = json.loads(path.read_bytes())
        assert not fixture.exists() and recorded["archive"] == str(destination)
        expected = {key: recorded[key] for key in ("files", "directories", "bytes")}
        assert inventory(destination) == expected
        print("Verified and preserved", expected["bytes"], "bytes and", len(expected["files"]), "files")
        print(json.dumps(pool_budget(root / "build", run=run, used=measure(run))))
        return
    assert fixture.is_dir() and not destination.exists()
    expected = inventory(fixture)
    shutil.copytree(fixture, destination)
    received = inventory(destination)
    assert received == expected, (received["bytes"], expected["bytes"])
    receipt = dict(source=str(fixture), archive=str(destination), **expected)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    assert inventory(fixture) == expected and fixture.resolve() == fixture and fixture.parent == run / "tmp"
    shutil.rmtree(fixture)
    assert not fixture.exists()
    result = pool_budget(root / "build", run=run, used=measure(run))
    print("Verified and preserved", expected["bytes"], "bytes and", len(expected["files"]), "files")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
