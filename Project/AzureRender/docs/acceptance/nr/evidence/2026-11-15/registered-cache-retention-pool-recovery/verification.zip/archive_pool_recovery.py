"""Seal the exact registered replay and catalog recovery receipts."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import sqlite3
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

from focused_retry import digest


run = Path(__file__).resolve().parent
root = run.parents[2]
target = root / "docs/acceptance/nr/evidence/2026-11-15/registered-cache-retention-pool-recovery"


def read(path):
    return json.loads(path.read_bytes())


def main():
    prefix = run / "release-gpu-14"
    original = run / "release-gpu-14-pool-stop"
    output = read(prefix.with_suffix(".json"))
    assert output["status"] == "passed" and output["tests"] == output["selectedTests"] == 5
    assert not output["failed"] and not output["skipped"]
    assert output["provenanceChecked"]["products"] == digest(run / "release-products.json")
    assert output["provenanceChecked"]["junit"] == digest(prefix.with_suffix(".xml"))
    assert output["provenanceChecked"]["testNames"] == digest(prefix.with_suffix(".txt"))
    assert prefix.with_suffix(".txt").read_bytes() == (original / "release-gpu-14.txt").read_bytes()
    names = {x.get("name"): x for x in ET.parse(prefix.with_suffix(".xml")).findall(".//testcase")}
    assert len(names) == 5 and all(x.find("failure") is None and x.find("skipped") is None for x in names.values())
    assert "TimeoutError: timed out" in (original / "release-gpu-14.log").read_text(encoding="utf-8", errors="replace")
    capacity = read(run / "registered-pool-capacity-recovery.json")
    assert len(capacity["archived"]) == 3 and capacity["recoveredBytes"] == 705311360
    fixture = read(run / "aborted-shader-host-copy.json")
    assert len(fixture["files"]) == 905 and fixture["bytes"] == 173483260
    assert Path(fixture["archive"]).is_dir() and not Path(fixture["source"]).exists()
    with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro", uri=True) as db:
        jobs = db.execute("SELECT id,task,state,exit_code,reason FROM jobs WHERE id IN (1066,1073,1074) ORDER BY id").fetchall()
    assert [(row[0],row[2],row[3],row[4]) for row in jobs] == [(1066,"budget-stopped",1,"managed-pool-limit"),
        (1073,"succeeded",0,None),(1074,"succeeded",0,None)]
    with sqlite3.connect((root / "build/maintenance/artifact-index.sqlite3").as_uri()+"?mode=ro", uri=True) as db:
        for item in capacity["archived"]:
            [row] = db.execute("SELECT data FROM runs WHERE name=?", (item["name"],)).fetchone()
            state = json.loads(row)
            assert state["status"] == "released" and state["reservedBytes"] == 0
            with Path(item["archive"]).open("rb") as stream:
                assert state["archiveSha256"] == item["archiveSha256"] == file_digest(stream, "sha256").hexdigest()
    files = [*original.iterdir(), Path(__file__), *(prefix.with_suffix(suffix) for suffix in (".json",".xml",".txt",".log")),
             *(run / name for name in ("release-gpu-14-queue.log", "registered-pool-capacity-recovery.json",
                 "aborted-shader-host-copy.json", "archive_expired_shader_runs.py", "preserve_aborted_shader_host.py",
                 "release-products.json"))]
    members = {p.relative_to(run).as_posix(): digest(p) for p in files}
    target.mkdir()
    archive = target / "verification.zip"
    with ZipFile(archive, "x", ZIP_DEFLATED, compresslevel=6) as out:
        for name in sorted(members):
            out.write(run / name, name)
    with ZipFile(archive) as out:
        assert set(out.namelist()) == members.keys() and out.testzip() is None
        assert all(sha256(out.read(name)).hexdigest() == value for name,value in members.items())
    report = dict(status="passed", recoveredManagedPoolBytes=capacity["recoveredBytes"], catalogs=capacity["archived"],
                  abortedFixture=dict(archive=fixture["archive"], bytes=fixture["bytes"], files=len(fixture["files"])),
                  resolvedTests={name:float(x.get("time")) for name,x in names.items()}, dispatch=jobs,
                  archive=dict(sha256=digest(archive), files=members))
    (target / "results.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
