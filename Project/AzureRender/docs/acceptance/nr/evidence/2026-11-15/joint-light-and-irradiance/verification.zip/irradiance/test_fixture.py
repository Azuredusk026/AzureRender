from pathlib import Path
import json
import hashlib
import os
import re
import subprocess
import sys
import time
root=Path.cwd();run=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import managed_environment
build=root/'build/ninja-msvc-release'
fixture=build/'AzureIrradianceClipmapGpuTests.exe'
prepared=json.loads((run/'prepare-results.json').read_bytes())
asset=Path(prepared['fixture']['asset'])
positions=Path(prepared['fixture']['positions'])
assert hashlib.sha256(asset.read_bytes()).hexdigest()==prepared['fixture']['assetSha256']
env=managed_environment(run/'tmp')
env['PATH']=os.pathsep.join((str(build),'D:/Tools/VulkanSDK/1.4.350.0/Bin',env['PATH']))
results=[]
for device,vk in ('nvidia','*nv-vk64*'),('intel','*igvk64*'):
    env['VK_LOADER_DRIVERS_SELECT']=vk
    for label,extra in (('default',[]),('disabled',['--disabled']),('mirrored',['--mirrored']),
                        ('native',[str(asset),str(positions),'--sample-only'])):
        control=[]
        for role in ('base','candidate'):
            a=[str(fixture),str(run/('compute-'+role+'.spv')),*extra]
            t=time.monotonic()
            p=subprocess.run(a,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=80)
            stem=run/f'{device}-{label}-{role}'
            stem.with_suffix('.stdout').write_bytes(p.stdout)
            stem.with_suffix('.stderr').write_bytes(p.stderr)
            control.append(dict(role=role,seconds=time.monotonic()-t,rc=p.returncode,sha256=hashlib.sha256(p.stdout).hexdigest()))
            if p.returncode:
                sys.stderr.write(p.stderr.decode('utf-8','replace'))
                p.check_returncode()
        if label=='native':
            outputs=[(run/f'{device}-{label}-{role}.stdout').read_text().splitlines() for role in ('base','candidate')]
            assert all(len(x)==prepared['fixture']['queries'] for x in outputs)
            changed=sum(aa!=bb for aa,bb in zip(*outputs))
        else:
            changed=0
        results.append(dict(device=device,case=label,changedQueries=changed,controls=control))
        (run/'fixture-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
reports=[q for q in results if q['case']=='native']
assert len(reports)==2
print(json.dumps(dict(nativeReports=reports),indent=2),flush=True)
sys.exit(0 if all(q['changedQueries']==0 for q in reports) else 8)
