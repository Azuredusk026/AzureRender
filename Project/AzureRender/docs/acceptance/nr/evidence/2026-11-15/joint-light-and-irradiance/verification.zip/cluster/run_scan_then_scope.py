from pathlib import Path
import subprocess
import sys

out=Path(__file__).resolve().parent
for phase in ('run_replay.py','cone_scope.py'):
    code=subprocess.call([sys.executable,'-B','-X','utf8',str(out/phase)],cwd=out.parents[2])
    if code:
        raise SystemExit(code)
