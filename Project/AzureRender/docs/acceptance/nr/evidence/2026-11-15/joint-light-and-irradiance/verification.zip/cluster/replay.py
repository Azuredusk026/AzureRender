from hashlib import sha256
from pathlib import Path
from collections import Counter
import json
from itertools import accumulate
import struct
import traceback
import sys
import renderdoc as rd

run=Path(__file__).resolve().parent
captured=run.parent/'20261111-001050-quad-feature-device-capture-4798d1'
state=json.loads((captured/'state.json').read_bytes())
mapping=json.loads((captured/'pipeline-scope.json').read_bytes())
report=dict(status='started',captureSha256=state['captureSha256'])
def save():
    (run/'actual-clusters.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def block_words(data, variables, name):
    variable=next(x for x in variables if x.name==name)
    return list(struct.unpack_from('<4f',data,variable.byteOffset))

save()
cap=rd.OpenCaptureFile()
control=None
try:
    source=Path(state['capture'])
    assert source.stat().st_size==state['bytes']
    h=sha256()
    with source.open('rb') as source_file:
        for segment in iter(lambda:source_file.read(2**20),b''): h.update(segment)
    assert h.hexdigest()==state['captureSha256']==mapping['captureSha256']
    assert cap.OpenFile(str(source),'',None)==rd.ResultCode.Succeeded
    status,control=cap.OpenCapture(rd.ReplayOptions(),None)
    assert status==rd.ResultCode.Succeeded
    stage=rd.ShaderStage.Pixel
    top=mapping['groups'][:2]
    assert all(any(x['name']=='azureOrdinaryOpaque' and x['valueU32']==1 for x in g['specialization']) for g in top)
    report['passes']=[]
    for scope,g in zip(('main','snapshot'),top):
        event=g['representativeEvent']
        control.SetFrameEvent(event,True)
        pipe=control.GetPipelineState()
        reflection=pipe.GetShaderReflection(stage)
        assert str(pipe.GetGraphicsPipelineObject())==g['pipeline']
        shader=next(x for x in g['shaders'] if x['stage']==str(stage))
        assert sha256(bytes(reflection.rawBytes)).hexdigest()==shader['sha256']
        camera_index=next(i for i,b in enumerate(reflection.constantBlocks) if b.fixedBindNumber==0 and b.bufferBacked)
        camera_def=reflection.constantBlocks[camera_index]
        camera=pipe.GetConstantBlock(stage,camera_index,0).descriptor
        camera_bytes=bytes(control.GetBufferData(camera.resource,camera.byteOffset,camera_def.byteSize))
        values=dict((x,block_words(camera_bytes,camera_def.variables,x)) for x in ('clusterGrid','clusterDepth','cameraPosition','cameraForward','cameraRight','cameraUp'))
        bindings={}
        binding_scan=[]
        resource_classes=(('read-only',reflection.readOnlyResources,pipe.GetReadOnlyResources(stage)),
                          ('storage',reflection.readWriteResources,pipe.GetReadWriteResources(stage)))
        for category, declarations, descriptor_accesses in resource_classes:
            wanted={i:resource for i,resource in enumerate(declarations)
                    if resource.fixedBindSetOrSpace==0 and resource.fixedBindNumber in (14,15,16)
                    and not resource.isTexture}
            for access in descriptor_accesses:
                resource=wanted.get(access.access.index)
                if resource is None:
                    continue
                number=resource.fixedBindNumber
                descriptor=access.descriptor
                assert descriptor.resource!=rd.ResourceId.Null() and descriptor.byteSize>0
                assert number not in bindings,number
                bindings[number]=descriptor
                binding_scan.append(dict(category=category,name=resource.name,binding=number,
                                         resource=str(descriptor.resource),bytes=descriptor.byteSize))
            report.setdefault('descriptorScans',[]).append(dict(role=scope,category=category,
                declared=[(i,b.fixedBindNumber,b.name) for i,b in wanted.items()],
                accesses=[(x.access.index,str(x.access.type)) for x in descriptor_accesses]))
        assert set(bindings)=={14,15,16},binding_scan
        nx,ny,nz,count=map(int,values['clusterGrid'])
        assert (nx,ny,nz)==(16,9,24) and 1<=count<=128
        def binding(number,suffix,size):
            d=bindings[number]
            assert size<=d.byteSize
            data=bytes(control.GetBufferData(d.resource,d.byteOffset,size))
            assert len(data)==size
            (run/(scope+'-'+suffix+'.bin')).write_bytes(data)
            return data,dict(binding=number,resource=str(d.resource),offset=d.byteOffset,bytes=size,sha256=sha256(data).hexdigest())
        header,h=binding(15,'headers',nx*ny*nz*4*8)
        header=list(struct.iter_unpack('<2I',header))
        assert all(offset==sum_count for sum_count,(offset,n) in zip(accumulate([0]+[n for _,n in header]),header))
        index,i=binding(16,'indices',sum(n for _,n in header)*4)
        index=struct.unpack('<'+'I'*(len(index)//4), index)
        assert all(k<count for k in index)
        lights,l=binding(14,'lights',count*144)
        lights=list(struct.iter_unpack('<36f',lights))
        references=[Counter() for k in range(4)]
        lengths=[Counter() for k in range(4)]
        for j,(offset,n) in enumerate(header):
            references[j%4].update(index[offset:offset+n])
            lengths[j%4][n]+=1
        rows=[]
        for n,light in enumerate(lights):
            rows.append(dict(index=n,positionRadius=light[:4],direction=light[8:11],outerCos=light[11],innerCos=light[12],kind=int(light[13]),falloff=int(light[14]),boxEnabled=bool(light[28]),receiverBits=int(light[31]),response=int(light[32]),references=[r[n] for r in references]))
        offset=next(x.byteOffset for x in camera_def.variables if x.name=='screenReflectionWorldToClip')
        values['worldToClip']=list(struct.unpack_from('<16f',camera_bytes,offset))
        depth=list(g['targets'])[0]
        assert depth['resource']==g['depth'] and depth['format']=='D32'
        pass_end=max(e for group in mapping['groups'] if group['depth']==depth['resource'] and group['colors']==g['colors'] for e in group['events'])
        control.SetFrameEvent(pass_end,True)
        resource=control.GetPipelineState().GetDepthTarget().resource
        assert str(resource)==depth['resource']
        raw=bytes(control.GetTextureData(resource,rd.Subresource(0,0,0)))
        assert len(raw)==depth['width']*depth['height']*4
        (run/(scope+'-depth.bin')).write_bytes(raw)
        texture=dict(depth,event=pass_end,sha256=sha256(raw).hexdigest(),bytes=len(raw))
        report['passes'].append(dict(role=scope,event=event,shaderSha256=shader['sha256'],values=values,bindings=[h,i,l],descriptorCategories=binding_scan,lights=rows,lengths=lengths,depth=texture))
        save()
    assert [x['sha256'] for x in report['passes'][0]['bindings']]==[x['sha256'] for x in report['passes'][1]['bindings']]
    report['status']='read-back'
    save()
except Exception:
    report.update(status='failed',error=traceback.format_exc())
    save()
    raise
finally:
    if control: control.Shutdown()
    cap.Shutdown()
sys.exit(0)
