"""Verify the frozen fixture inputs, then execute the two adapters and replay."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

out=Path(__file__).resolve().parent
root=out.parents[2]
build=root/'build/ninja-msvc-release'
prior=out.parent/'20261115-064800-nr-material-cache-regression-4d7a62/release-products.json'
executable=build/'AzureIrradianceClipmapGpuTests.exe'
receipt=json.loads(prior.read_bytes())
digest=lambda path:sha256(path.read_bytes()).hexdigest()
for data in (executable,build/'shaders/irradiance_clipmap_test.comp.spv'):
    assert digest(data)==receipt['products'][str(data.resolve())]
assert (out/'compute-base.spv').read_bytes()==(build/'shaders/irradiance_clipmap_test.comp.spv').read_bytes()
prepared=json.loads((out/'prepare-results.json').read_bytes())
positions=Path(prepared['fixture']['positions'])
expected=''.join('{} {} {}\n'.format(i*13.25-106.25,j*16.75-11.5,k*73.25-180.25)
    for i in range(17) for j in range(9) for k in range(6))
assert positions.read_text(encoding='utf-8')==expected
for phase in ('test_fixture.py','run_replay.py'):
    with (out/(Path(phase).stem+'-verified.log')).open('wb') as log:
        result=subprocess.run([sys.executable,'-B','-X','utf8',str(out/phase)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit(result.returncode)
print('Completed eight fixture comparisons and capture replay.',flush=True)
