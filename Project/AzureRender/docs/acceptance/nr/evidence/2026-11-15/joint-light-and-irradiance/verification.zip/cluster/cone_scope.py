from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import math
import struct
import sys
import numpy as np
run=Path(__file__).resolve().parent

def read(path,sha):
    data=path.read_bytes()
    assert sha256(data).hexdigest()==sha
    return data

def box_about(near,far,nx,ny,nz,x,y,z,scale,offset):
    depths=near*np.exp(math.log(far/near)*np.asarray((z,z+1))/nz)
    depths*=np.asarray((1-2e-4,1+2e-4))
    ends=[]
    for cell,num,s,o in zip((x,y),(nx,ny),scale,offset):
        slopes=((np.asarray((cell,cell+1))*2/num-1)-o+np.asarray((-5e-4,5e-4)))/s
        bounds=slopes[:,None]*depths[None,:]
        ends.append([bounds.min(),bounds.max()])
    ends.append(depths.tolist())
    return np.asarray(ends).T

def conservative_zero(low,high,center,axis,cosine):
    a=low-center;b=high-center
    upper_dot=np.maximum(a*axis,b*axis).sum(axis=-1)
    closest=np.maximum(np.maximum(a,-b),0)
    minimum_distance=np.sqrt((closest*closest).sum(axis=-1))
    uncertainty=128*np.finfo(np.float32).eps*(1+np.maximum(np.abs(a),np.abs(b)).sum(axis=-1))
    return upper_dot+uncertainty < cosine*np.maximum(minimum_distance,.001)

def check_predicate():
    rng=np.random.default_rng(3534)
    low=rng.uniform(-2,2,size=(8192,3))
    high=low+rng.uniform(0,3,size=low.shape)
    emitter=rng.uniform(-3,3,size=low.shape)
    axes=rng.normal(size=low.shape)
    axes/=np.linalg.norm(axes,axis=1)[:,None]
    for cosine in (.01,.25,.5,.9,.99):
        omitted=conservative_zero(low,high,emitter,axes,cosine)
        if cosine==.5: assert 0<omitted.sum()<len(omitted)
        delta=(low[:,None,:]+(high-low)[:,None,:]*rng.uniform(size=(len(low),20,3))-emitter[:,None,:]).astype(np.float32)
        faxis=axes.astype(np.float32)
        dot=(delta*faxis[:,None,:]).sum(axis=2,dtype=np.float32)
        length=np.maximum(np.sqrt((delta*delta).sum(axis=2,dtype=np.float32)),np.float32(.001))
        assert (dot[omitted]/length[omitted] < np.float32(cosine)).all()
    # The closed hard-cone boundary and any cone intersection stay included.
    assert not conservative_zero(np.array([0,0,0]),np.array([1,1,1]),np.array([0,0,0]),np.array([0,0,1]),.5)
    assert not conservative_zero(np.array([1,0,1]),np.array([1,0,1]),np.array([0,0,0]),np.array([0,0,1]),1/math.sqrt(2))
    assert conservative_zero(np.array([-1,-1,-5]),np.array([1,1,-3]),np.array([0,0,0]),np.array([0,0,1]),.5)

def analyze(scope):
    role=scope['role']; c=scope['values']
    nx,ny,nz,count=map(int,c['clusterGrid'])
    near,far,w,h=c['clusterDepth'];w,h=int(w),int(h)
    assert near>0 and far>near
    camera=np.array(c['cameraPosition'][:3])
    basis=np.array([c[key][:3] for key in ('cameraRight','cameraUp','cameraForward')])
    assert np.allclose(basis@basis.T,np.eye(3),atol=1e-5)
    mat=np.array(c['worldToClip']).reshape(4,4).T
    assert np.allclose(mat[3,:3],basis[2],atol=1e-4)
    p=(mat[:3,:3]@basis.T)
    assert max(abs(p[0,1]),abs(p[1,0]))<1e-4
    scale=(p[0,0],p[1,1])
    offsets=(p[0,2],p[1,2])
    bb=np.stack([box_about(near,far,nx,ny,nz,x,y,z,scale,offsets) for z in range(nz) for y in range(ny) for x in range(nx)])
    raw=[read(run/(role+'-'+name+'.bin'),info['sha256']) for name,info in zip(('headers','indices','lights'),scope['bindings'])]
    hrows=np.frombuffer(raw[0],dtype='<u4').reshape(-1,4,2)
    ids=np.frombuffer(raw[1],dtype='<u4')
    lights=np.frombuffer(raw[2],dtype='<f4').reshape(-1,36)
    assert len(lights)==count
    pixels=scope['depth']
    d=np.frombuffer(read(run/(role+'-depth.bin'),pixels['sha256']),dtype='<f4').reshape(pixels['height'],pixels['width'])
    assert (w,h)==(pixels['width'],pixels['height'])
    assert np.isfinite(d).all() and (d>=0).all() and (d<=1).all()
    # Vulkan perspective z_ndc = P22 + P23 / viewDepth.
    clip_constant=float(mat[2,3]+mat[2,:3]@camera)
    view_depth=clip_constant/(d.astype(np.float64)-p[2,2])
    valid=(d<1)&(view_depth>0)
    x=np.minimum(((np.arange(w)+.5)*nx/w).astype(np.int32),nx-1)
    y=np.minimum(((np.arange(h)+.5)*ny/h).astype(np.int32),ny-1)
    z=(np.clip(np.log(np.maximum(view_depth,near)/near)/math.log(far/near),0,.999999)*nz).astype(np.int32)
    hist=np.bincount(((z*ny+y[:,None])*nx+x[None,:])[valid],minlength=nx*ny*nz)
    assert valid.sum()==hist.sum() and hist.sum()>w*h//4
    stats=[]
    for category in (0,2):
        baseline=hrows[:,category,1].astype(np.int64)
        all_omitted=np.zeros(len(bb),np.int64)
        by_light=[]
        for i,light in enumerate(lights):
            cosine=float(light[11]);mode,receiver,response=map(int,(light[13],light[31],light[32]))
            if mode!=1 or response>=2 or receiver!=1 or not (0<cosine<=1):
                continue
            present=np.asarray([i in ids[o:int(o)+int(n)] for o,n in hrows[:,category]],dtype=np.bool_)
            center=basis@(light[:3]-camera)
            axis=basis@light[8:11].astype(np.float64)
            assert abs(np.linalg.norm(axis)-1)<.003
            cut=present&conservative_zero(bb[:,0],bb[:,1],center,axis,cosine)
            all_omitted+=cut
            by_light.append(dict(index=i,memberships=int(present.sum()),cut=int(cut.sum()),
                depthPixelVisits=int(hist@present),cutDepthPixelVisits=int(hist@cut)))
        stats.append(dict(range=category,base=int(baseline.sum()),cut=int(all_omitted.sum()),depthPixelVisits=int(hist@baseline),cutDepthPixelVisits=int(hist@all_omitted),lights=by_light))
    return dict(role=role,depthPixels=int(hist.sum()),allPixels=w*h,ranges=stats,activeCells=int(np.count_nonzero(hist)),projectionScales=scale,projectionOffsets=offsets)

check_predicate()
if sys.argv[1:]==['self-test']:
    print('Positive, boundary and 819200 independent simulated points verified')
else:
    source=json.loads((run/'actual-clusters.json').read_bytes())
    assert source['status']=='read-back'
    results=dict(status='measured',captureSha256=source['captureSha256'],sourcePasses=source['passes'],passes=[analyze(s) for s in source['passes']])
    (run/'cone-scope.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(results['passes']))
