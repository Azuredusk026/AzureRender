"""Verify the process-scoped CPU efficiency control and preserve a paired receipt."""
import csv
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
from zipfile import ZipFile, ZIP_DEFLATED


run = Path(__file__).resolve().parent
root = run.parents[2]
day = root / 'docs/acceptance/nr/evidence/2026-11-15'
control = day / 'joint-80w-maximum-fan'
target = day / 'joint-80w-player-cpu-efficiency'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def range_starts(row):
    return [part['frameMs']['p95'] for part in row['windows']]


def verify():
    identity = read(run / 'cooling-control-result-identity.json')
    origin = read(control / 'results.json')
    assert identity['measurement'] == origin['product']
    hashes = {'results.json': 'resultSha256', 'environment.json': 'telemetrySha256',
              'timing.csv': 'timingCsvSha256', 'measure_overlay.py': 'instrumentedMeasureSha256',
              'player_process_qos.py': 'executionPolicySourceSha256'}
    assert all(digest(run / path) == identity[key] for path, key in hashes.items())
    assert identity['executionPolicy'] == read(run / 'player-qos.json')
    policy = identity['executionPolicy']['applied']
    assert policy['controlMask'] & 1 and policy['stateMask'] & 1
    result = read(run / 'results.json')
    assert result['warmup'] == 300 and result['frames'] == 1800 and result['allocatorZero']
    assert result['gpuPowerLimitWatts'] == [80.0] and result['driver'] == '595.79'
    with (run / 'timing.csv').open() as stream:
        timings = list(csv.DictReader(stream))
    assert [int(row['frame']) for row in timings] == list(range(1, 2101))
    sorted_times = sorted(float(row['frameMs']) for row in timings[300:])
    idx = .95 * (len(sorted_times) - 1)
    calculated_p95 = sorted_times[int(idx)] + (idx-int(idx))*(sorted_times[int(idx)+1]-sorted_times[int(idx)])
    assert abs(calculated_p95 - result['timings']['frameMs']['p95']) < 1e-6
    env = read(run / 'environment.json')
    telemetry = env['startup'] + env['runObservations'] + [env['final']]
    assert all(sample['powerLimitWatts'] == 80.0 and sample['driver'] == '595.79' for sample in telemetry)
    assert sum(sample['thermalSlowdown']['software'] for sample in telemetry) == result['softwareThermalSlowdownObservations']
    restored = read(run / 'fan-restored.json')
    assert restored['automatic'] and restored['balanced'] and not restored['maximum']
    assert read(run / 'attempt-965-fan-restored.json')['automatic']
    assert read(run / 'fan-observations.json')[-1] == restored
    with ZipFile(control / 'verification.zip') as archive:
        assert digest(control / 'verification.zip') == origin['archive']['sha256']
        baseline_command = json.loads(archive.read('command.json'))['command']
    current_command = read(run / 'command.json')['command']
    ignored = baseline_command.index('--gpu-timing-output') + 1
    assert baseline_command[:ignored] == current_command[:ignored]
    assert baseline_command[ignored + 1:] == current_command[ignored + 1:]
    with sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro', uri=True) as db:
        jobs = db.execute('select id,task,state,exit_code from jobs where id in (965,969) order by id').fetchall()
    assert jobs[0][0] == 965 and jobs[0][2:] == ('failed', 1)
    expected_status = ('succeeded', 0) if all(result['gates'].values()) else ('failed', 8)
    assert jobs[1][0] == 969 and jobs[1][2:] == expected_status
    return dict(status='diagnostic', dispatch=jobs, measurement=result, processPolicy=policy,
                sameProduct=identity['measurement'], restored=restored,
                baselinePath=control.relative_to(root).as_posix()+'/results.json',
                p95ByWindow=dict(control=range_starts(origin['measurements']), diagnostic=range_starts(result)),
                startC=[sample['temperature'] for sample in env['startup']])


def save(result):
    names = ('archive_cpu_efficiency.py','check_process_qos.py','command.json',
             'cooling-control-preflight.json','cooling-control-result-identity.json',
             'environment.json','fan-before.json','fan-observations.json','fan-ready.json','fan-restored.json',
             'measurement.log','measurement.stderr.log','measure_overlay.py',
             'player-qos.json','player.log','player_process_qos.py','prepare_max_fan_replay.py',
             'process-memory.json','process.log','results.json','run_max_fan_measurement.ps1','timing.csv','timing.json')
    parts = [run / name for name in names] + sorted(run.glob('attempt-965-*'))
    hashes = {path.name:digest(path) for path in parts}
    target.mkdir()
    package = target / 'verification.zip'
    with ZipFile(package,'w',compression=ZIP_DEFLATED,compresslevel=6) as archive:
        for path in parts:
            archive.write(path,path.name)
    with ZipFile(package) as archive:
        assert set(archive.namelist()) == hashes.keys() and archive.testzip() is None
        assert all(sha256(archive.read(name)).hexdigest() == sha for name,sha in hashes.items())
    result['archive'] = dict(sha256=digest(package), files=hashes)
    (target / 'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:result['measurement'][key] for key in
                      ('gates','timings','peakTemperatureC','softwareThermalSlowdownObservations')}, indent=2))


if __name__ == '__main__':
    save(verify())
