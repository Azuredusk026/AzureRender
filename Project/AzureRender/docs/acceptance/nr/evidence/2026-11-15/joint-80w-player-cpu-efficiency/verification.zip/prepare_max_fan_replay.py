"""Verify and prepare the 80 W cooling control without changing the machine."""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile


root = Path.cwd().resolve()
runs = root/'build/runs'
base = runs/'20261114-034546-nr-joint-nonlocal-80w-timing-c8b31a'
placement = runs/'20261114-032038-nr-joint-nonlocal-image-candidate-92047b'
candidate = Path('D:/Projects/FYP-worktrees/nr-integration-verified/Project/AzureRender')
baseline_command = runs/'20261114-011046-nr-joint-59579-max-fan-control-c9091a/command.json'
archive = root/'docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope/validation.zip'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def proof():
    sys.path.insert(0,str(candidate/'tools'))
    from build_provenance import verify

    prior = load(base/'results.json')
    assert prior['driver']=='595.79' and prior['gpuPowerLimitWatts']==[80.0]
    assert prior['warmup']==300 and prior['frames']==1800 and prior['gates']['deviceLocal']
    assert not (prior['gates']['thermalAndAC'] or prior['gates']['gpuP95'])
    material = load(placement/'candidate-receipt.json')
    source = Path(material['baseReceiptPath'])
    assert digest(source)==material['baseReceiptSha256']
    verify(candidate,load(source))
    assert all(digest(Path(name))==sha for name,sha in material['inputsAndProducts'].items())
    assert material['inputsAndProducts'][str(placement/'AzurePlayer.exe')]==digest(placement/'AzurePlayer.exe')
    with ZipFile(archive) as package:
        frozen = json.loads(package.read('run/frozen-project-inputs.json'))
        command = json.loads(package.read('run/diagnostic-1080p60/command.json'))['command']
    prior_command = load(baseline_command)['command']
    assert len(command)==len(prior_command)
    mutable = {0,command.index('--resource-root')+1,command.index('--gpu-timing-output')+1}
    assert all(value==prior_command[index] for index,value in enumerate(command) if index not in mutable)
    assert len(frozen)==1729 and all(digest(Path(name))==sha for name,sha in frozen.items())
    script = base/'measure_overlay.py'
    ast.parse(script.read_bytes(),filename=str(script))
    return {'measurementPath':str(script),'measurementSha256':digest(script),
            'sourceCommit':material['commit'],'placementReceiptSha256':digest(placement/'candidate-receipt.json'),
            'playerPath':str(placement/'AzurePlayer.exe'),'playerSha256':digest(placement/'AzurePlayer.exe'),
            'frozenArchiveSha256':digest(archive),'frozenInputs':len(frozen),'sourceResultsSha256':digest(base/'results.json'),
            'displayDriver':'595.79','gpuPowerLimitWatts':80.0, 'powerMode':'balanced','fanMode':'maximum',
            'minimumObservedFanRpm':5600,'warmupFrames':300,'measuredFrames':1800,
            'gates':{'gpuP95Ms':16.6,'cpuWorkP95Ms':8,'deviceLocalBytes':1610612736,
                     'workingSetBytes':2147483648,'softwareThermalSlowdownSamples':0}}


def preflight(out):
    receipt = proof()
    script = Path(receipt['measurementPath'])
    assert digest(script)==receipt['measurementSha256']
    measured_source(script.read_bytes())
    (out/'cooling-control-preflight.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(receipt['sourceCommit'],receipt['frozenInputs'],receipt['playerSha256'],flush=True)


def measured_source(code):
    original = code.decode("utf-8")
    line_end = "\r\n" if "\r\n" in original else "\n"
    needle = line_end.join(("    try:", "        while player.poll() is None:"))
    assert original.count(needle) == 1
    tagged = [
        "    try:",
        "        from player_process_qos import query, set_energy_efficient",
        '        before_policy = query(player.pid)',
        '        policy = set_energy_efficient(player.pid)',
        '        save("player-qos.json", {"pid": player.pid, "previous": before_policy, "applied": policy,',
        '                                 "observedAtUnixSeconds": time.time()})',
        "        while player.poll() is None:",
    ]
    variant = original.replace(needle, line_end.join(tagged))
    ast.parse(variant)
    return variant.encode("utf-8")


def execute_here():
    out = Path(__file__).resolve().parent
    receipt = load(out/'cooling-control-preflight.json')
    marker = load(out/'fan-ready.json')
    assert marker['selected']==receipt['fanMode'] and marker['powerMode']==receipt['powerMode']
    assert isinstance(marker['rpm'],int) and marker['rpm']>=receipt['minimumObservedFanRpm']
    assert marker['original']=='automatic' and marker['source']=='OMEN Gaming Hub'
    observed = datetime.fromisoformat(marker['observedAt'])
    assert observed.utcoffset() is not None
    assert 0<=(datetime.now(timezone.utc)-observed).total_seconds()<300, 'Refresh the fan observation at the GPU lease boundary'
    assert receipt==proof()
    measure = Path(receipt['measurementPath'])
    code = measure.read_bytes()
    assert hashlib.sha256(code).hexdigest()==receipt['measurementSha256']
    (out/'measure_overlay.py').write_bytes(measured_source(code))
    subprocess.run([sys.executable,'-B','-X','utf8',str(out/'measure_overlay.py')],cwd=root,check=True,timeout=925)
    result = load(out/'results.json')
    assert result['source']==receipt['sourceCommit']
    assert result['driver']==receipt['displayDriver'] and result['gpuPowerLimitWatts']==[receipt['gpuPowerLimitWatts']]
    assert result['warmup']==receipt['warmupFrames'] and result['frames']==receipt['measuredFrames'] and result['allocatorZero']
    assert not result['gates']['thermalAndAC'] or result['softwareThermalSlowdownObservations']==0
    policy = load(out/'player-qos.json')
    assert policy['applied']['controlMask'] & 1 and policy['applied']['stateMask'] & 1
    provenance={'fanModeObservation':marker,'measurement':receipt,'resultSha256':digest(out/'results.json'),
                'executionPolicy':policy, 'executionPolicySourceSha256':digest(out/'player_process_qos.py'),
                'instrumentedMeasureSha256':digest(out/'measure_overlay.py'),
                'telemetrySha256':digest(out/'environment.json'),'timingCsvSha256':digest(out/'timing.csv')}
    (out/'cooling-control-result-identity.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
    for key,value in result['gates'].items():
        print(key,value,flush=True)
    return 0 if all(result['gates'].values()) else 8


if __name__=='__main__':
    parser=argparse.ArgumentParser(__doc__)
    action=parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--preflight',type=Path)
    action.add_argument('--measure-after-confirmed-max-fan',action='store_true')
    args=parser.parse_args()
    if args.preflight:
        preflight(args.preflight)
    else:
        raise SystemExit(execute_here())
