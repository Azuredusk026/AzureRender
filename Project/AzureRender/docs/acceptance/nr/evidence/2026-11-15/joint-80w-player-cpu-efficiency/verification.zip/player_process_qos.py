from contextlib import contextmanager
import ctypes
from ctypes import wintypes


PROCESS_SET_INFORMATION = 0x0200
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
PROCESS_POWER_THROTTLING = 4
EXECUTION_SPEED = 0x1


class PowerThrottlingState(ctypes.Structure):
    _fields_ = [('version', wintypes.ULONG), ('control_mask', wintypes.ULONG),
                ('state_mask', wintypes.ULONG)]


kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
kernel.CloseHandle.restype = wintypes.BOOL
for call in (kernel.GetProcessInformation, kernel.SetProcessInformation):
    call.argtypes = (wintypes.HANDLE, ctypes.c_int, ctypes.POINTER(PowerThrottlingState), wintypes.DWORD)
    call.restype = wintypes.BOOL


@contextmanager
def process_handle(pid, permissions):
    handle = kernel.OpenProcess(permissions, False, pid)
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        yield handle
    finally:
        kernel.CloseHandle(handle)


def read_policy(handle):
    state = PowerThrottlingState(version=1)
    if not kernel.GetProcessInformation(handle, PROCESS_POWER_THROTTLING, ctypes.byref(state), ctypes.sizeof(state)):
        raise ctypes.WinError(ctypes.get_last_error())
    return {'version': state.version, 'controlMask': state.control_mask, 'stateMask': state.state_mask}


def query(pid):
    with process_handle(pid, PROCESS_QUERY_LIMITED_INFORMATION) as handle:
        return read_policy(handle)


def set_energy_efficient(pid):
    with process_handle(pid, PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_SET_INFORMATION) as handle:
        request = PowerThrottlingState(version=1, control_mask=EXECUTION_SPEED, state_mask=EXECUTION_SPEED)
        if not kernel.SetProcessInformation(handle, PROCESS_POWER_THROTTLING, ctypes.byref(request), ctypes.sizeof(request)):
            raise ctypes.WinError(ctypes.get_last_error())
        receipt = read_policy(handle)
        if not receipt['controlMask'] & EXECUTION_SPEED or not receipt['stateMask'] & EXECUTION_SPEED:
            raise RuntimeError(f'Windows did not confirm execution-speed policy for process {pid}')
        return receipt
