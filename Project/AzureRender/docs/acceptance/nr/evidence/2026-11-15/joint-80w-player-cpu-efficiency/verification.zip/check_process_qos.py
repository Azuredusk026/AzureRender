import os
import subprocess
import sys

from player_process_qos import query, set_energy_efficient


def main():
    parent_before = query(os.getpid())
    command = [sys.executable, '-B', '-c', 'import time; time.sleep(30)']
    with subprocess.Popen(command) as control, subprocess.Popen(command) as tagged:
        try:
            control_before = query(control.pid)
            assert not query(tagged.pid)['stateMask'] & 1
            receipt = set_energy_efficient(tagged.pid)
            assert receipt['version'] == 1
            assert receipt['controlMask'] & 1 and receipt['stateMask'] & 1
            assert receipt == query(tagged.pid)
            assert query(control.pid) == control_before
            assert query(os.getpid()) == parent_before
        finally:
            tagged.terminate()
            control.terminate()
    print('The two child processes and parent retained independent execution policies.')


if __name__ == '__main__':
    main()
