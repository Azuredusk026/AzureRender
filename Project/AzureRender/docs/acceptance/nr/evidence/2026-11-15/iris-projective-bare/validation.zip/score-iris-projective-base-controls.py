"""Locate the base-map contribution at retained projective iris residuals."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


root = Path(__file__).resolve().parent
grid = root.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
body = root.parent / '20261114-125923-body-lit-outline-depth-order-a29b63'
read = lambda filename: json.loads(filename.read_bytes())
digest = lambda filename: sha256(filename.read_bytes()).hexdigest()
source = read(root / 'iris-native-matcap-d3d-vulkan-owned-levels.json')
native_path = root / 'trace-iris-matcap-inputs.json'
lanes_path = body / 'iris-native-intel-sample-lanes/results.json'
trace = read(native_path)
capture = read(lanes_path)
known = read(root / 'iris-projective-residuals.json')
assert trace['status'] == 'qualified' and capture['status'] == 'measured-intel-live'
assert capture['points'] == [sample['point'] for sample in trace['points']]
folder = grid / 'iris-explicit-mips'
receipts = read(folder / 'iris-explicit-mips.json')
point_order = np.fromfile(grid / 'native-iris-stages/points.bin', '<u4').reshape(-1, 2).tolist()
assert source['points'] == point_order and len(point_order) == 255
index = [point_order.index(point) for point in capture['points']]
native_base_mips = {}
for tag in ('nvidia','intel'):
    receipt = receipts['devices'][tag]
    samples = [folder / f'{tag}-implicit.bin', *[folder / f'{tag}-mip-{mip:02d}.bin' for mip in range(10)]]
    assert [digest(p) for p in samples] == [receipt['implicitSha256'], *
        [receipt['mips'][str(mip)]['sha256'] for mip in range(10)]]
    baseline, *fixed = [np.fromfile(path, '<u4')[index] for path in samples]
    matched = np.stack(fixed) == baseline
    assert matched.any(axis=0).all()
    native_base_mips[tag] = [np.flatnonzero(match).tolist() for match in matched.T]
rounded_srgb = lambda linear: np.rint(np.where(linear <= .0031308, linear * 12.92,
    1.055 * np.power(linear, 1/2.4) - .055) * 255).astype('i2').tolist()
witnesses = []
for row, native, player, alphas in zip(source['witnesses'], trace['points'],
                       capture['lanes']['baseRgb'], capture['lanes']['alphaAndLod']):
    point = native['point']
    assert row['point'] == point
    registers = native['samples']['63']['r9'][:4]
    original = np.asarray(registers)
    levels = {tag: selected[len(witnesses)] for tag, selected in native_base_mips.items()}
    entry = dict(point=point, nativeBase=original.tolist(), playerBase=[*player,alphas[0]],
        nativeBaseLevels=levels, playerBaseLevel=round(alphas[2]*16-1),
        rgbBaseMaxDifference=float(np.abs(original[:3]-player).max()),
        nativeBaseRgbSrgb8=rounded_srgb(original[:3]), playerBaseRgbSrgb8=rounded_srgb(np.asarray(player)),
        nativeMatcapLevels=row['nativeLevels'], playerMatcapLevel=row['playerLevel'],
        allSourcesUnderOne=all(np.abs(original[:3]-player)<=1/255))
    residual=next((item for item in known['devices']['intel']['rows'] if item['point']==point),None)
    entry['projectiveIntelError']=None if residual is None else residual['currentError']
    witnesses.append(entry)
print(json.dumps(witnesses, ensure_ascii=False, indent=2), flush=True)
(root/'iris-projective-base-controls.json').write_text(json.dumps(dict(status='measured-base-sampler-residual-controls',
    witnesses=witnesses, sources={p.name: digest(p) for p in (native_path, lanes_path, folder/'iris-explicit-mips.json')}),
    indent=2)+'\n', encoding='utf8')
