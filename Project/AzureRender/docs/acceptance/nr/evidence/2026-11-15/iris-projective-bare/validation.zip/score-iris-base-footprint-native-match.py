"""Compare measured Vulkan base UV gradients to original D3D base mip selections."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


root = Path(__file__).resolve().parent
grid = root.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
diagnostics = root.parent / '20261114-135148-face-receiver-diagnostics-7509b1'
source = diagnostics / 'iris-vulkan-footprint-nvidia/results.json'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: sha256(p.read_bytes()).hexdigest()
region = read(source)
assert region['status'] == 'qualified' and region['copyControlExact'] and region['baselineRestored']
points = region['points']
assert len(points) == 255
assert (np.fromfile(grid/'native-iris-stages/points.bin','<u4').reshape(-1,2)==np.asarray(points)).all()
native_folder = grid / 'iris-explicit-mips'
native_file = native_folder / 'iris-explicit-mips.json'
frozen = read(native_file)
assert frozen['status'] == 'qualified'
map_scopes = {}
for device, reference in frozen['devices'].items():
    stages = [native_folder / f'{device}-implicit.bin',
              *[native_folder / f'{device}-mip-{level:02d}.bin' for level in range(10)]]
    assert [sha(path) for path in stages] == [reference['implicitSha256'],
        *[reference['mips'][str(level)]['sha256'] for level in range(10)]]
    implicit, *explicit = [np.fromfile(path,'<u4') for path in stages]
    map_scopes[device] = implicit == np.asarray(explicit)
    assert map_scopes[device].any(axis=0).all()
attribution = diagnostics / 'iris-projected-native-t13-mip4.bin'
assert attribution.stat().st_size == 1024
size = int(np.sqrt(attribution.stat().st_size)) * 16
assert size == 512
facts = region['diagnostics']
hardware = np.asarray(facts['originalLod']['rows'])
assert np.array_equal(hardware[:,0], hardware[:,0].astype(int))
levels={'hardwareQuery': hardware[:,0].astype(int)}
axis = lambda p: np.abs(p).max(axis=1)+(11/32)*np.abs(p).min(axis=1)
footprints = {}
for rate in ('Fine','Coarse'):
    d_x,d_y=np.asarray(facts['derivative'+rate]['rows']).reshape(-1,2,2).transpose(1,0,2)*size/2048
    footprints[rate] = {
        'axis':np.maximum(np.linalg.norm(d_x,axis=1),np.linalg.norm(d_y,axis=1)),
        'diagonal':np.maximum(np.maximum(axis(d_x),axis(d_y)),(11/16)*np.maximum(axis(d_x+d_y),axis(d_x-d_y))),
    }
    for mode, values in footprints[rate].items():
        levels[rate+mode] = np.clip(np.floor(np.log2(np.maximum(values,1.e-12))-.5),0,9).astype(int)
times = {'vulkan':sha(source), 'nativeMipSources':sha(native_file)}
interesting = [[1261,260], [1261,261], [1260,262], [1302,265]]
reconstructed = {}
for method, selected in levels.items():
    assert selected.min()>=0 and selected.max()<=9
    flags = {dev:scope[selected,np.arange(len(points))] for dev, scope in map_scopes.items()}
    reconstructed[method] = dict(matches={tag:int(mask.sum()) for tag,mask in flags.items()},
        controls=[dict(point=point, candidate=int(selected[points.index(point)]),
            native={tag:np.flatnonzero(values[:,points.index(point)]).tolist() for tag,values in map_scopes.items()})
            for point in interesting],
        mismatches={tag:[points[index] for index in np.flatnonzero(~mask)] for tag,mask in flags.items()})
print({k:(v['matches'],[(r['point'],r['candidate'],r['native']) for r in v['controls']]) for k,v in reconstructed.items()},flush=True)
(root/'iris-base-footprint-native-match.json').write_text(json.dumps(dict(status='measured-base-mip-footprint-agreement',
    scope=len(points),textureSize=size, inputs=times, methods=reconstructed),indent=2)+'\n',encoding='utf8')
