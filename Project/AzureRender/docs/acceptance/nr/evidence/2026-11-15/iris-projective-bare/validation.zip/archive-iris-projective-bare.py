from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


run = Path(__file__).resolve().parent
stage = run / 'iris-matcap-differential-player/earlyProjectiveCoarse'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
receipt = read(stage / 'bare-results.json')
remainder = read(run / 'iris-projective-residuals.json')
sources = read(run / 'iris-projective-base-controls.json')
methods = read(run / 'iris-base-footprint-native-match.json')
assert all(report['scope'] == 255 for report in (receipt, remainder, methods))
assert receipt['stage'] == 'bare' and receipt['preflight'] == digest(stage/'preflight.json')
assert remainder['native']['overlayCount'] == 94
assert methods['methods']['Finediagonal']['matches'] == dict(nvidia=255, intel=250)
assert methods['methods']['Fineaxis']['matches'] == dict(nvidia=250, intel=255)
control = {tuple(case['point']): case for case in sources['witnesses']}
assert control[(1302,265)]['nativeBaseLevels']==dict(nvidia=[5],intel=[4])
assert control[(1302,265)]['playerBaseLevel']==4
assert control[(1302,265)]['nativeMatcapLevels']==dict(nvidia=[4],intel=[4])
assert control[(1302,265)]['playerMatcapLevel']==4
assert control[(1260,262)]['nativeBaseLevels']==dict(nvidia=[5],intel=[4])
devices = {}
files = {name:run/name for name in ('archive-iris-projective-bare.py', 'score-iris-projective-residuals.py',
    'score-iris-projective-base-controls.py', 'score-iris-base-footprint-native-match.py',
    'iris-projective-residuals.json', 'iris-projective-base-controls.json', 'iris-base-footprint-native-match.json',
    'nr-iris-matcap-projective-coarse-two-adapters-queue.log')}
files.update({name:stage/name for name in ('bare-results.json','preflight.json','mesh.frag')})
for device, errors, point, vendor in (('nvidia',[10,9],[19,1],0x10de),('intel',[19,18],[18,1],0x8086)):
    summary = receipt['devices'][device]['false']
    assert summary['outsideIrisChanged'] == summary['newOverOne'] == 0
    assert summary['overOne'] == errors
    assert [item['before'] for item in summary['witnesses'] if item['point']==[1262,257]] == [point[0]]
    assert [item['after'] for item in summary['witnesses'] if item['point']==[1262,257]] == [point[1]]
    frames = stage / f'{device}-bare/frames'
    assert digest(frames/'frame_000000.png') == summary['frame']
    capability = read(frames/'gpu_capabilities.json')
    assert capability['vendor_id'] == vendor
    files.update({f'{device}/{name}':frames/name for name in ('capture_manifest.json','gpu_capabilities.json')})
    files[f'{device}/command.json'] = frames.parent/'command.json'
    devices[device] = dict(frame=summary['frame'], control=summary['control'], overOne=summary['overOne'],
          peak=summary['peak'], outsideChanged=0, newOverOne=0, seam=point,
          nativeOverlayRegions=remainder['devices'][device]['regions'],
          unresolvedPeak=remainder['devices'][device]['rows'][0])
out = run.parents[2] / 'docs/acceptance/nr/evidence/2026-11-15/iris-projective-bare'
out.mkdir(parents=True, exist_ok=True)
destination = out / 'validation.zip'
with ZipFile(destination,'w',ZIP_DEFLATED) as archive:
    for name,path in files.items():
        archive.write(path,name)
with ZipFile(destination) as archive:
    assert archive.testzip() is None
    hashes = {name:sha256(archive.read(name)).hexdigest() for name in files}
assert hashes == {name:digest(path) for name,path in files.items()}
report = dict(status='qualified-projective-iris-no-overlay', overall='failed-user-review', scope=255,
    reference=receipt['reference'], native=remainder['native'], devices=devices,
    fullColor='open', baseMipTargets={name:methods['methods'][name]['matches']
            for name in ('hardwareQuery','Finediagonal','Fineaxis')},
    highestIntelBaseControls=[control[(1302,265)],control[(1260,262)]],
    archive=dict(sha256=digest(destination),members=hashes))
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print({tag:entry['overOne'] for tag,entry in devices.items()}, flush=True)
