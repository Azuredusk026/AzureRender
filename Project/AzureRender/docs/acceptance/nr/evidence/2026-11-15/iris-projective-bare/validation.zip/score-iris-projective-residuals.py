"""Score completed no-overlay projective captures against both native iris attachments."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import runpy

import numpy as np


run = Path(__file__).resolve().parent
body = run.parent / '20261114-125923-body-lit-outline-depth-order-a29b63'
tools = runpy.run_path(str(run / 'iris-matcap-differential-player.py'), run_name='iris_residual_score')
read, digest, score, unpack, display = [tools[key] for key in ('read', 'digest', 'score', 'unpack', 'display')]
stage = run / 'iris-matcap-differential-player/earlyProjectiveCoarse'
manifest = read(stage / 'bare-results.json')
evidence = read(run / 'iris-native-matcap-d3d-vulkan-owned-levels.json')
assert manifest['stage'] == 'bare' and manifest['scope'] == len(evidence['points']) == 255
points = np.asarray(evidence['points'])
x, y = points.T


def raw_at_frame(event):
    path = score['stages'] / 'post-opaque-ownership' / f'1245-{event}.bin.gz'
    data = gzip.decompress(path.read_bytes())
    return np.frombuffer(data, '<u4').reshape(1440, 2560)[::-1][y, x], sha256(data).hexdigest()


old_native, before_sha = raw_at_frame(1244)
overlay_native, after_sha = raw_at_frame(1245)
has_overlay = old_native != overlay_native
expected = display(unpack(old_native))
assert has_overlay.sum() == 94
sample_lanes = read(body / 'iris-native-intel-sample-lanes/results.json')
assert sample_lanes['status'] == 'measured-intel-live'
known_intel = {tuple(point): index for index, point in enumerate(sample_lanes['points'])}
result = dict(status='measured-projective-iris-residual-split', scope=255,
              native=dict(before=before_sha, after=after_sha, overlayCount=94), devices={})
for device in ('nvidia', 'intel'):
    proof = manifest['devices'][device]['false']
    paths = [body / f'iris-native-main-frame-uncovered-{device}/frames/frame_000000.png',
             stage / f'{device}-bare/frames/frame_000000.png']
    assert [digest(path) for path in paths] == [proof['control'], proof['frame']]
    images = [score['image'](image)[y, x].astype(np.int16) for image in paths]
    errors = [np.abs(image - expected).max(axis=1) for image in images]
    assert [int((error > 1).sum()) for error in errors] == proof['overOne']
    assert [int(error.max()) for error in errors] == proof['peak']
    by_cover = {label: [int(((error > 1) & mask).sum()) for error in errors]
        for label, mask in (('nativeOverlayCovered', has_overlay), ('exposed', ~has_overlay))}
    _, warped = errors
    rows = []
    for index in np.argsort(-warped, kind='stable'):
        if warped[index] <= 1:
            break
        point = tuple(points[index].tolist())
        known = known_intel.get(point)
        row = dict(point=list(point), rawNativeOverlayOwner=bool(has_overlay[index]),
                   previousError=int(errors[0][index]), currentError=int(warped[index]),
                   linearSamplerLevels={adapter: row['rows'][index] for adapter, row in evidence['nativeHardware'].items()},
                   signedDelta=(images[1][index] - expected[index]).tolist(),
                   nativeDisplay=expected[index].tolist())
        if known is not None:
            row['retainedIntelPlayerLevel'] = round(sample_lanes['lanes']['matcapGeometry'][known][2] * 16 - 1)
        rows.append(row)
    result['devices'][device] = dict(regions=by_cover, rows=rows)
    print(device, by_cover, rows[:4], flush=True)
(run / 'iris-projective-residuals.json').write_text(json.dumps(result, indent=2)+'\n',encoding='utf8')
