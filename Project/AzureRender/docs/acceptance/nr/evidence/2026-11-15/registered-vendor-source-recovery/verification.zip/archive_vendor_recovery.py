"""Seal the source-integrity interruption and the exact registered replay."""
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

from focused_retry import digest


run = Path(__file__).resolve().parent
root = run.parents[2]
target = root / "docs/acceptance/nr/evidence/2026-11-15/registered-vendor-source-recovery"


def read(path):
    return json.loads(path.read_bytes())


def cases(path):
    rows = ET.parse(path).findall(".//testcase")
    assert len(rows) == 9 and all(row.find("failure") is None and row.find("skipped") is None for row in rows)
    return {row.get("name"): float(row.get("time")) for row in rows}


def main():
    initial = run / "release-gpu-13-source-drift"
    repair = run / "registered-source-files-recovered.json"
    data = read(repair)
    assert all(digest(initial / name) == sha for name, sha in data["preservedFailure"].items())
    assert len(data["files"]) == 34
    original = cases(initial / "release-gpu-13.xml")
    selected = run / "release-gpu-13.txt"
    replay = cases(run / "release-gpu-13.xml")
    assert original.keys() == replay.keys() == set(selected.read_text(encoding="utf-8").splitlines())
    report = read(run / "release-gpu-13.json")
    assert report["status"] == "passed" and report["selectedTests"] == report["tests"] == 9
    binding = report["provenanceChecked"]
    assert binding["products"] == digest(run / "release-products.json")
    assert binding["junit"] == digest(run / "release-gpu-13.xml")
    assert binding["testNames"] == digest(selected)
    with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro", uri=True) as database:
        jobs = database.execute("SELECT id,task,state,exit_code FROM jobs WHERE id IN (1052,1057,1061,1064) ORDER BY id").fetchall()
    assert [(id,state,code) for id,_,state,code in jobs] == [(1052,"failed",1),(1057,"failed",1),
        (1061,"succeeded",0),(1064,"succeeded",0)]
    raw = [*initial.iterdir(), repair, Path(__file__), *(run / name for name in (
        "release-gpu-13.log", "release-gpu-13.xml", "release-gpu-13.json", "release-gpu-13.txt",
        "release-gpu-13-queue.log", "source-restore-1057-process.log", "repair_registered_source_files.py",
        "release-products.json", "debug-products.json"))]
    manifest = {path.relative_to(run).as_posix():digest(path) for path in raw}
    target.mkdir()
    output = target / "verification.zip"
    with ZipFile(output, "x", ZIP_DEFLATED, compresslevel=6) as archive:
        for path in raw:
            archive.write(path, path.relative_to(run).as_posix())
    with ZipFile(output) as archive:
        assert set(archive.namelist()) == manifest.keys() and archive.testzip() is None
        assert all(sha256(archive.read(name)).hexdigest() == value for name, value in manifest.items())
    saved = dict(status="passed", restoredTrackedFiles=len(data["files"]),
                 releasedProducts=data["releaseProductCount"], debugProducts=data["debugProductCount"],
                 casesBeforeProvenanceFailure=original, acceptedReplayCases=replay, dispatch=jobs,
                 archive=dict(sha256=digest(output), files=manifest))
    (target / "results.json").write_text(json.dumps(saved, indent=2) + "\n", encoding="utf-8")
    print("Verified 34 restored files and nine registered replay results")


if __name__ == "__main__":
    main()
