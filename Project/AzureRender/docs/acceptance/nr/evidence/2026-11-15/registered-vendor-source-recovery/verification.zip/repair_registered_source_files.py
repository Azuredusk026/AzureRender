"""Recover the missing vendored files from the unchanged index and reverify the registered inputs."""
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
from tempfile import NamedTemporaryFile


run = Path(__file__).resolve().parent
project = run.parents[2]
repository = project.parents[1]
vendor = project / "third_party"
scope = "Project/AzureRender/third_party"
sys.path.insert(0, str(project / "tools"))
from build_provenance import inputs, verify


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def git(*arguments, **kwargs):
    return subprocess.check_output(["git", *arguments], cwd=repository, **kwargs)


def tracked_entries():
    values = {}
    for raw in git("ls-files", "-s", "-z", "--", scope).split(b"\0"):
        if raw:
            attributes, path = raw.split(b"\t", 1)
            mode, blob, stage = attributes.decode("ascii").split()
            assert stage == "0" and mode in ("100644", "100755")
            values[path.decode("utf-8")] = blob
    return values


def main():
    shared = read(Path("D:/Projects/FYP-coordination/resources/current.json"))
    assert shared["owner"] == "01a1d0a8-a74c-7cc0-85e8-540a6653098a"
    assert shared["task"] == "restore-registered-vendored-source-files" and Path(shared["output"]).resolve() == run
    assert vendor.resolve() == vendor and vendor.is_dir()
    with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro", uri=True) as db:
        assert db.execute("select state,exit_code from jobs where id=1052").fetchone() == ("failed", 1)
    protected = read(run / "protected-files.json")
    assert all(digest(project / name) == checksum for name, checksum in protected.items())
    first, second = [read(run / (config + "-products.json")) for config in ("release", "debug")]
    assert first["source"] == second["source"]
    expected = first["source"]
    before = inputs(project)
    changed = sorted(name for name in expected.keys() | before.keys() if expected.get(name) != before.get(name))
    assert all(name.startswith("third_party/dotnet/") for name in changed), changed
    assert not git("diff", "--cached", "--", scope)
    entries = tracked_entries()
    deleted = git("ls-files", "--deleted", "-z", "--", scope)
    restore = [name.decode("utf-8") for name in deleted.split(b"\0") if name]
    assert len(set(restore)) == len(restore) and set(restore) <= entries.keys()
    registration = {}
    for name in restore:
        path = repository / name
        assert not path.exists() and path.is_relative_to(vendor) and path.resolve() == path
        registration[name] = dict(indexBlob=entries[name])
    print("Missing runtime inputs", changed, "missing tracked vendored files", len(restore), flush=True)
    if restore:
        git("checkout-index", "--stdin", "-z", input=deleted)
    normalized = []
    for name in changed:
        path = project / name
        actual = path.read_bytes()
        if sha256(actual).hexdigest() == expected[name]:
            continue
        relative = path.relative_to(repository).as_posix()
        canonical = git("cat-file", "blob", entries[relative])
        assert sha256(canonical).hexdigest() == expected[name]
        assert actual == canonical.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
        with NamedTemporaryFile("wb", dir=path.parent, prefix=path.name + "-", suffix=".pending", delete=False) as stream:
            pending = Path(stream.name)
            stream.write(canonical)
        assert path.read_bytes() == actual
        os.replace(pending, path)
        normalized.append(name)
    for name in entries:
        path = repository / name
        assert path.is_file() and path.resolve() == path
        assert git("hash-object", "--path=" + name, name).decode().strip() == entries[name]
        registration[name] = dict(indexBlob=entries[name], sha256=digest(path))
    assert tracked_entries() == entries and not git("ls-files", "--deleted", "-z", "--", scope)
    assert expected == inputs(project) and all(digest(project / name) == checksum for name, checksum in protected.items())
    for proof in (first, second):
        verify(project, proof)
    report = {"scope": scope, "failedTestShard": 1052, "sourceInputsRecovered": changed,
              "checkoutLineEndingsRecovered": normalized, "files": registration,
              "preservedFailure": {p.name: digest(p) for p in (run / "release-gpu-13-source-drift").iterdir()},
              "releaseProductCount": len(first["products"]), "debugProductCount": len(second["products"])}
    with (run / "registered-source-files-recovered.json").open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print("Both registered build fingerprints verified", flush=True)


if __name__ == "__main__":
    main()
