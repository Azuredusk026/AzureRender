"""Archive the independently captured shell response on both adapters."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


root=Path(__file__).resolve().parent
output=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/body-outline-transparent-highlights'
read=lambda path:json.loads(path.read_bytes())
digest=lambda path:sha256(path.read_bytes()).hexdigest()
members=['archive-body-outline-transparent-highlights.py','body-outline-light-comparison.py',
    'body-outline-player-isolation.py','body-outline-local-rim-radial-model.json']
results={}
for device,previous,after,vendor in (('nvidia',626,242,0x10de),('intel',627,243,0x8086)):
    summary=f'body-outline-highlight-result-{device}.json'
    report=read(root/summary)
    assert report['referencePixels']==1184 and report['nativeCoverageOverEight']==[previous,after]
    assert report['nativeCoveragePeak']==[88,77] and report['focusPeak']==[5,5]
    assert report['changedOutside']==report['newGlobalOverOne']==0
    traces={}
    members.append(summary)
    for mode in ('beauty','beauty-transparent-highlights','rim-transparent-highlights'):
        record=f'body-outline-{mode}-{device}'
        source=root/record
        detail=read(source/'results.json')
        assert digest(source/'frames/frame_000000.png')==detail['frameSha256']
        assert read(source/'frames/gpu_capabilities.json')['vendor_id']==vendor
        traces[mode]={k:detail[k] for k in ('frameSha256','materialSha256','playerSha256')}
        members.extend(record+'/'+name for name in ('command.json','results.json','frames/gpu_capabilities.json'))
    assert len({entry['playerSha256'] for entry in traces.values()})==1
    report['captures']=traces
    results[device]=report
output.mkdir(parents=True,exist_ok=True)
package=output/'validation.zip'
with ZipFile(package,'w',ZIP_DEFLATED) as archive:
    for name in members:archive.write(root/name,name)
with ZipFile(package) as archive:
    assert archive.testzip() is None
    hashes={name:sha256(archive.read(name)).hexdigest() for name in members}
assert hashes=={name:digest(root/name) for name in members}
(output/'results.json').write_text(json.dumps(dict(status='measured-native-shell-local-light',
    overallVisualAcceptance='failed-user-review',devices=results,
    archive=dict(sha256=digest(package),members=hashes)),indent=2)+'\n',encoding='utf8')
