"""Read Player shell normals in a qualified, scene-camera diagnostic."""
from hashlib import file_digest
from pathlib import Path
import json
import os
import runpy
import sys

import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
fixture=grid/'iris-overlay-geometry-project'
helper=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read,invoke=helper['read'],helper['invoke']
def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()

device,*options=sys.argv[1:]
assert device in ('nvidia','intel')
mode=options[0] if options else 'shaded-normal'
assert len(options)<=1 and mode in ('shaded-normal','ambient','albedo','direct-diffuse','object-shadow-visibility',
    'beauty','beauty-transparent-highlights','rim-transparent-highlights')
highlights=mode.endswith('-transparent-highlights')
view=mode.removesuffix('-transparent-highlights')
check_only=os.environ.get('AZURE_BODY_ISOLATION_CPU_PREFLIGHT')=='1'
sys.path.insert(0,str(run.parents[2]/'tools'))
from artifact_budget import check
preflight=check(run.parents[1],run=run,planned=5_000_000)
assert preflight['allowed'],preflight
if not check_only:
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==run
name='body-native-lit-outline-blend-depth'
oldname='body-native-lit-outline-production'
folder=run/(f'body-outline-normal-{device}' if mode=='shaded-normal' else f'body-outline-{mode}-{device}')
if not check_only and folder.exists():
    assert not (folder/'results.json').is_file()
    folder.rename(run/f'{folder.name}-interrupted-{len(list(run.glob(folder.name+"-interrupted-*")))+1}')
if not check_only:folder.mkdir()
base=run/f'body-blend-{device}'
argv=read(base/'command.json')
build=run/'msaa-release'
expected='1a30d925a674ddb1d95876cb80181106a0217e12a7228a35b5980b134954cb69'
assert digest(build/'AzurePlayer.exe')==expected
argv[0]=str(build/'AzurePlayer.exe')
for flag,value in (('--resource-root',build),('--capture-dir',folder/'frames'),('--runtime-report',folder/'runtime.json')):
    argv[argv.index(flag)+1]=str(value)
if view!='beauty':
    argv.extend(('--qa-isolation',view))
material_source=run/f'{name}.azurematerial'
if highlights:
    material=read(material_source)
    options=material['surface']['materials'][0]['extras']['azureRenderMaterial']['nprDiffuse']
    assert 'transparentHighlights' not in options
    options['transparentHighlights']=True
    material_source=folder/material_source.name
    if not check_only:material_source.write_text(json.dumps(material,indent=2)+'\n',encoding='utf8')
assets={
    fixture/'character'/f'{oldname}.gltf':run/f'{oldname}-ordered.gltf',
    fixture/'materials'/f'{name}.azurematerial':material_source,
    fixture/'materials'/f'{name}.azurematerial.azmeta':run/f'{name}.azurematerial.azmeta',
    fixture/'scene'/f'{name}.azurelevel':run/f'{name}.azurelevel',
    fixture/f'{name}.azureproject':run/f'{name}.azureproject',
}
for path in list(assets):
    meta=path.with_suffix(path.suffix+'.azmeta')
    if not meta.exists() and (run/meta.name).exists():assets[meta]=run/meta.name
if check_only:
    assert all(not dest.exists() and (source.is_file() or (highlights and source==material_source))
               for dest,source in assets.items()),assets
    print(json.dumps(dict(device=device,mode=mode,files=len(assets),playerSha256=expected)))
    raise SystemExit(0)
owned=[]
try:
    for dest,source in assets.items():
        assert not dest.exists(),dest
        dest.hardlink_to(source)
        owned.append((dest,source))
    frame=invoke(device,argv,folder)/'frame_000000.png'
    assert frame.is_file()
finally:
    for dest,source in reversed(owned):
        if dest.is_file() and os.path.samefile(dest,source):dest.unlink()
        meta=dest.with_suffix(dest.suffix+'.azmeta')
        if meta.is_file() and dest.suffix in ('.azureproject','.azurelevel') and meta not in assets:
            meta.replace(folder/meta.name)

pixels=np.asarray(Image.open(frame).convert('RGB'),dtype='u1')
assert pixels.shape==(1440,2560,3)
footprint=read(run/'body-outline-source-footprint.json')
points={tuple(p[:2]):p for p in footprint['points']}
witness=read(run/'body-outline-screen-normal-states.json')['points']
report=dict(status='sampled',device=device,mode=mode,playerSha256=expected,frameSha256=digest(frame),
    materialSha256=digest(material_source),
    points=[dict(point=[int(x),int(y)],sourceAddress=row[2:4],fragmentBytes=pixels[y,x].tolist(),
        sourceAddressBytes=pixels[row[3],row[2]].tolist()) for (x,y),row in points.items()],
    controls=[dict(point=p['point'],sourcePixel=p['nativeSampleDisplay'],
        actual=pixels[p['point'][1],p['point'][0]].tolist(),nativeNormal=p['authoredNormal']) for p in witness])
(folder/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({a:b for a,b in report.items() if a!='points'}))

