"""Measure late body-shell highlights with the exact same Player and pose."""
from pathlib import Path
import json
import runpy
import subprocess
import sys
import numpy as np

run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
scorer=runpy.run_path(str(grid/'static-quality.py'))
image=lambda p:scorer['image'](p).astype('i2')
ref=image(scorer['reference_path'])
gd=grid/'native-body-outline-depth'
pre,post=[np.fromfile(gd/f'depth-{event}.bin','<u4').reshape(1440,2560,2)[::-1,:,0] for event in (1017,1018)]
cover=pre!=post
npix=int(cover.sum())
assert npix==1184
x,y=np.asarray(read(grid/'face-skin-overlay-ownership.json')['skin']['1018']['locations']).T
assert len(x)==61
for dev in sys.argv[1:]:
    assert dev in ('nvidia','intel')
    for mode in ('beauty','beauty-transparent-highlights','rim-transparent-highlights'):
        folder=run/f'body-outline-{mode}-{dev}'
        if (folder/'results.json').is_file():continue
        subprocess.run([sys.executable,str(run/'body-outline-player-isolation.py'),dev,mode],check=True,timeout=250)
    old,new,rim=[run/f'body-outline-{m}-{dev}' for m in ('beauty','beauty-transparent-highlights','rim-transparent-highlights')]
    assert len({read(p/'results.json')['playerSha256'] for p in (old,new,rim)})==1
    frame=lambda q:image(q/'frames/frame_000000.png')
    base,hi,ri=map(frame,(old,new,rim))
    historic=image(run/f'body-blend-{dev}/frames/frame_000000.png')
    historical_error=np.abs(historic-base).max(2)
    err0,err1=(np.abs(im-ref).max(2) for im in (base,hi))
    delta=np.abs(hi-base).max(2)
    z=np.asarray([1270,1037,1325,1120,1325,1118,1319,938]).reshape(-1,2)
    result=dict(status='measured',referencePixels=npix,changedInside=int((delta[cover]>0).sum()),
        changedOutside=int((delta[~cover]>0).sum()),changedOutsideOverOne=int((delta[~cover]>1).sum()),
        nativeCoverageOverEight=[int((e[cover]>8).sum()) for e in (err0,err1)],
        nativeCoverageOverOne=[int((e[cover]>1).sum()) for e in (err0,err1)],
        nativeCoveragePeak=[int(e[cover].max()) for e in (err0,err1)],
        focusOverEight=[int((e[y,x]>8).sum()) for e in (err0,err1)],
        focusPeak=[int(e[y,x].max()) for e in (err0,err1)],
        newGlobalOverOne=int(((err0<=1)&(err1>1)).sum()),
        currentDifferentFromHistoricalPixels=int((historical_error>0).sum()),currentHistoricalPeak=int(historical_error.max()),
        points=[dict(point=[int(xp),int(yp)],before=base[yp,xp].tolist(),after=hi[yp,xp].tolist(),
            reference=ref[yp,xp].tolist(),rimView=ri[yp,xp].tolist()) for xp,yp in z])
    if dev=='nvidia':
        target=read(run/'body-outline-local-rim-radial-model.json')['worst'][0]
        px,py=target['point']
        result['primaryRimModelControl']=dict(point=target['point'],predicted=target['hypothetical'],
            actual=hi[py,px].tolist(),absoluteError=int(np.abs(hi[py,px]-target['hypothetical']).max()))
    (run/f'body-outline-highlight-result-{dev}.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(dev,json.dumps(result),flush=True)

