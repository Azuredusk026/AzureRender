"""Bound the face base-texture change from the measured geometry sources."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import runpy
import struct

import numpy as np
from PIL import Image


run=Path(__file__).resolve().parent
s=runpy.run_path(str(run/'score-face-opaque-primitive-residuals.py'),run_name='face_sampling_scope')
samples=[item for item in s['output'] if item['edgeResidual']]
native=s['native']
geometry=(s['indices_native'],s['indices_player'])
positions=(s['upper'],s['player_screen'])
depths=(s['native_w'],s['player_depth'])
uvs=(native[:,4:6],s['texcoord'])
source=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d/native-face-skin-stages'
record=json.loads((source/'results.json').read_bytes())['faceTextures']['18']
extent=record['width']
assert extent==record['height']==1024
assert record['format']=='BC7_SRGB' and len(record['levels'])==11
bias=float(np.fromfile(run/'face-view-mask-cb1.bin','<f4')[26*4])
assert bias==-1.0


def color_texture():
    textures=[]
    for index,row in enumerate(record['levels']):
        pixel_size=max(1,extent>>index)
        raw=(source/row['path']).read_bytes()
        assert sha256(raw).hexdigest()==row['sha256'] and len(raw)==row['size']
        header=b'DDS '+struct.pack('<31I',124,0x81007,pixel_size,pixel_size,len(raw),0,1,*([0]*11),32,4,
            0x30315844,0,0,0,0,0,0x1000,0,0,0,0)
        with Image.open(BytesIO(header+struct.pack('<5I',99,3,0,1,0)+raw)) as image:
            rgb=np.asarray(image.convert('RGB'),dtype=float)/255
        textures.append(np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4))
    return textures


def planar(quad,local):
    space,tri,w,uv=(data[local] for data in (positions,geometry,depths,uvs))
    index=tri[quad['index']]
    a,b,c=(np.rint(space[index]*256)/256).astype(float)
    basis=np.stack((b-a,c-a),axis=1)
    inverse=np.linalg.inv(basis)
    reciprocals=1/w[index]
    values=uv[index]
    def evaluate(x,y):
        u,v=inverse@(np.array([x+.5,y+.5])-a)
        bary=np.array([1-u-v,u,v])*reciprocals
        return bary@values/bary.sum()
    return evaluate


def footprint(uv):
    x,y=uv
    axes=lambda point:np.abs(point).max()+(11/32)*np.abs(point).min()
    return max(axes(x),axes(y),(11/16)*max(axes(x+y),axes(x-y)))


def sample(texture,coord):
    uv=coord*np.asarray(texture.shape[:2][::-1])-.5
    lo=np.floor(uv).astype(int)
    fraction=np.rint((uv-lo)*256)/256
    blended=np.zeros(3)
    height,width=texture.shape[:2]
    for dx,dy in ((0,0),(0,1),(1,0),(1,1)):
        x,y=(lo+np.array([dx,dy]))%[width,height]
        weight=(fraction[0] if dx else 1-fraction[0])*(fraction[1] if dy else 1-fraction[1])
        blended+=texture[y,x]*weight
    return blended


textures=color_texture()
observations=[]
for row in samples:
    x,y=row['point']
    native_model,player_model=[planar(row[label],index) for index,label in enumerate(('modelNative','modelPlayer'))]
    coords=[np.asarray(model(x,y)) for model in (native_model,player_model)]
    assert np.abs(coords-np.asarray([row['modelNative']['uv'],row['modelPlayer']['uv']])).max()<1.e-7
    levels=[]
    for model in (native_model,player_model):
        # Display coordinates count upward relative to the D3D attachment rows.
        x0,y0=x&~1,y&~1
        dx=model(x0+1,y0+1)-model(x0,y0+1)
        dy=model(x0,y0+1)-model(x0,y0)
        lod=np.log2(max(footprint((dx,dy))*extent,1.e-12))+bias
        levels.append(int(np.clip(np.floor(lod+.5),0,len(textures)-1)))
    on_same_mip=[np.max(np.abs(sample(texture,coords[0])-sample(texture,coords[1]))) for texture in textures]
    pair=[sample(textures[level],coord) for level,coord in zip(levels,coords)]
    observations.append(dict(point=[x,y],levels=levels,positionShiftAtBase=row['atlas1024UvTexelMax'],
        maxSameMipLinearDifference=float(max(on_same_mip)),
        linearDifferenceAtNativeModelMip=float(on_same_mip[levels[0]]),
        linearDifferenceWithSelectedMips=float(np.abs(pair[0]-pair[1]).max())))
print('modeled mip changes',sum(s['levels'][0]!=s['levels'][1] for s in observations),flush=True)
print(sorted(observations,key=lambda row:-row['linearDifferenceWithSelectedMips'])[:7],flush=True)
(run/'face-opaque-projection-texture-controls.json').write_text(json.dumps(
    dict(status='modeled-original-face-base-texture-geometry-effect',body='opaque-face-event-804',
         controls=len(observations),observations=observations),indent=2)+'\n',encoding='utf8')
