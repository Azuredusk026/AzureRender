"""Match captured face and body topology, controls, and viewport geometry."""
from hashlib import file_digest
import json
import math
import struct
from pathlib import Path

import numpy as np
from PIL import Image


run=Path(__file__).resolve().parent
body=run.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
native=grid/'native-face-skin-stages'
fixture=grid/'iris-overlay-geometry-project/character'
stage=run/'body-outline-before-transparent-cloth'
read=lambda p:json.loads(p.read_bytes())
scene=body/'body-native-lit-outline-blend-depth.azurelevel'
model=stage/'body-native-lit-outline-production-native-order.gltf'
display=stage/'nvidia/frames/capture_manifest.json'
capture=read(display)
inventory=read(native/'results.json')
assert inventory['status']=='qualified'
definition=read(model)
width,height=2560,1440
node=next(node for node in read(scene)['nodes'] if node['id']=='camera')
camera=np.asarray(node['components']['azure.transform']['data']['translation'])
up=np.asarray(capture['cameraUp'])
forward=np.asarray([0.,up[2],-up[1]])
right=np.cross(forward,up)
assert np.allclose(right,[1,0,0])
lens=capture['cameraLens']
half_tan=math.tan(lens['verticalFovRadians']*.5)
lens_offset=np.asarray(lens['offsetNdc'])
span=np.asarray([width,height])/2
component={5126:'<f4',5125:'<u4',5123:'<u2'}
buffers={}


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def rows(number):
    accessor=definition['accessors'][number]
    view=definition['bufferViews'][accessor['bufferView']]
    shape={'VEC2':2,'VEC3':3,'VEC4':4,'SCALAR':1}[accessor['type']]
    dtype=np.dtype(component[accessor['componentType']])
    assert view.get('byteStride',shape*dtype.itemsize)==shape*dtype.itemsize
    uri=definition['buffers'][view['buffer']]['uri']
    source=fixture/uri
    if uri not in buffers:
        assert source.is_file()
        buffers[uri]=source
    offset=view.get('byteOffset',0)+accessor.get('byteOffset',0)
    return np.fromfile(source,dtype,count=shape*accessor['count'],offset=offset).reshape(-1,shape)


def read_public_glb(path):
    with path.open('rb') as stream:
        magic,version,size=struct.unpack('<4sII',stream.read(12))
        assert (magic,version,size)==(b'glTF',2,path.stat().st_size)
        length,name=struct.unpack('<I4s',stream.read(8))
        assert name==b'JSON'
        doc=json.loads(stream.read(length))
        _,name=struct.unpack('<I4s',stream.read(8))
        assert name==b'BIN\x00'
        return doc,stream.tell()


def verify_public_face_source(positions,indices,uv):
    fixed=body/'face-quality-release-isolated-mask/public-combined-nvidia'
    candidate_scene=fixed/'face-quality-native-production-combined.azurelevel'
    control=read(candidate_scene)
    owner,=[resource for resource in control['resources'] if resource['id']=='hero']
    raw_path=fixture/owner['asset'].split(':/',1)[1]
    doc,offset=read_public_glb(raw_path)
    native_camera,=[node for node in control['nodes'] if node['id']=='camera']
    assert native_camera['components']['azure.transform']['data']==node['components']['azure.transform']['data']
    manifest=read(fixed/'frames/capture_manifest.json')
    for field in ('cameraLens','cameraUp'):
        assert capture[field]==manifest[field]
    face,=[mesh for mesh in doc['meshes'] if mesh.get('name')=='S_actor_laevat_face_01_lod0']
    raw,=face['primitives']
    data=(raw['attributes']['POSITION'],raw['indices'], raw['attributes']['TEXCOORD_0'])
    for handle,target in zip(data,(positions,indices,uv)):
        accessor=doc['accessors'][handle]
        view=doc['bufferViews'][accessor['bufferView']]
        assert view['buffer']==0
        data_start=offset+accessor.get('byteOffset',0)+view.get('byteOffset',0)
        decoded=np.fromfile(raw_path,np.dtype(component[accessor['componentType']]),count=target.size,offset=data_start)
        assert np.array_equal(decoded.reshape(target.shape),target)
    return dict(scene=sha(candidate_scene),asset=sha(raw_path),capture=sha(fixed/'frames/capture_manifest.json'))


def project(world):
    relative=world-camera
    depth=relative@forward
    assert np.isfinite(depth).all() and (depth>0).all()
    ndc=np.column_stack(((relative@right)/(half_tan*width/height*depth),-(relative@up)/(half_tan*depth)))
    return (ndc+lens_offset+1)*span,depth


def raster_mask(screen, indexed):
    mask=np.zeros((height,width),np.bool_)
    subpixels=np.rint(screen*256).astype(np.int64)
    for triangle in subpixels[indexed]:
        lo=np.maximum(np.ceil((triangle.min(axis=0)-128)/256).astype(int),0)
        hi=np.minimum(np.floor((triangle.max(axis=0)-128)/256).astype(int),[width-1,height-1])
        if np.any(lo>hi):continue
        first,second=triangle[1:]-triangle[0]
        area=first[0]*second[1]-first[1]*second[0]
        if not area:continue
        if area<0:triangle=triangle[[0,2,1]]
        x,y=np.meshgrid(np.arange(lo[0],hi[0]+1)*256+128,np.arange(lo[1],hi[1]+1)*256+128)
        visible=np.ones(x.shape,np.bool_)
        for start,end in zip(triangle,np.roll(triangle,-1,axis=0)):
            dx,dy=end-start
            edge=dx*(y-start[1])-dy*(x-start[0])
            if dy<0 or (dy==0 and dx>0):
                visible&=edge>=0
            else:
                visible&=edge>0
        mask[lo[1]:hi[1]+1,lo[0]:hi[0]+1]|=visible
    return mask


def evaluate(event,name,highlights):
    mesh,=[item for item in definition['meshes'] if item.get('name')==name]
    prim,=mesh['primitives']
    xyz=rows(prim['attributes']['POSITION'])
    tx=rows(prim['attributes']['TEXCOORD_0'])
    trace=inventory['geometry'][str(event)]
    vdata=native/f'vertex-{event}.bin'
    idata=native/f'index-{event}.bin'
    assert sha(vdata)==trace['vertexSha256'] and sha(idata)==trace['indexSha256']
    original=np.fromfile(vdata,'<f4').reshape(-1,trace['vertexStride']//4)
    assert len(xyz)==len(original)
    index=rows(prim['indices']).reshape(-1,3)
    indices=np.fromfile(idata,'<u2').reshape(-1,3)
    assert len(indices)==len(index)
    sharing=(np.sort(index,axis=1)==np.sort(indices,axis=1)).all(axis=1)
    equal_count=int(sharing.sum())
    source_world=original[:,6:9]*[-1,1,1]+camera
    distance=np.linalg.norm(xyz-source_world,axis=1)
    native_clip=original[:,:4]
    native_ndc=native_clip[:,:2]/native_clip[:,3,None]
    native_viewport=(native_ndc.astype(float)*[1,-1]+1)*span
    native_screen=native_viewport.copy()
    native_screen[:,1]=height-native_viewport[:,1]
    player_screen,player_depth=project(xyz)
    separation=np.abs(player_screen-native_screen)
    quantization=lambda value:np.rint(value*256).astype(int)
    quantized=np.any(quantization(native_screen)!=quantization(player_screen),axis=1)
    projected=[raster_mask(vertices,tessellation) for vertices,tessellation in
               ((native_screen,indices),(player_screen,index))]
    before,after=projected
    difference=before^after
    coordinates=np.column_stack(np.where(difference)[::-1]).tolist()
    high_shift=[position for position in highlights if difference[position[1],position[0]]]
    scope='face' if event==804 else 'skin'
    with Image.open(grid/f'native-face-masks/{scope}.png') as picture:
        mask=np.asarray(picture.convert('L'))>0
    inside=[int((mask&domain).sum()) for domain in projected]
    visible_missing=[np.column_stack(np.where(mask&~domain)[::-1]).tolist() for domain in projected]
    public=verify_public_face_source(xyz,index,tx) if event==804 else None
    return dict(vertices=len(xyz), triangles=len(indices),sameIndexedTriangleCount=equal_count,
        projectedCoverage=[int(mask.sum()) for mask in projected],
        coverageDifferences=coordinates, highErrorInCoverageDiff=high_shift,
        nativeVisibleScope=int(mask.sum()),nativeVisibleCovered=inside,nativeVisibleMissing=visible_missing,
        facePublicSource=public,
        exactWorldPositions=int((distance==0).sum()),worldPositionMaxMeters=float(distance.max()),
        viewportPixelPeak=separation.max(axis=0).tolist(),viewportPixelP95=np.percentile(separation,95,axis=0).tolist(),
        quantizedVerticesDiffering=int(quantized.sum()), depthMaxError=float(np.abs(player_depth-native_clip[:,3]).max()),
        exactUvCount=int(np.all(tx==original[:,4:6],axis=1).sum()),
        uvPeak=np.abs(tx-original[:,4:6]).max(axis=0).tolist(),
        mirroredVUvPeak=np.abs(tx-(original[:,4:6]*[1,-1]+[0,1])).max(axis=0).tolist(),
        nativeVertex=trace['vertexSha256'], nativeIndex=trace['indexSha256'])


public_face=read(run/'public-face-remaining-owner-residual.json')
high_sets=[{tuple(row['point']) for row in public_face['devices'][tag]['opaqueEdge'][1]['aboveEight']}
           for tag in ('nvidia','intel')]
face_focus=sorted(high_sets[0]&high_sets[1])
assert len(face_focus)==49
results={name:evaluate(event,mesh,face_focus if name=='face' else []) for name,event,mesh in (
    ('body',783,'S_actor_laevat_body_01_lod0'),('face',804,'S_actor_laevat_face_01_lod0'))}
print(results,flush=True)
report=dict(status='measured-fixed-pose-geometry-source-comparison', events=results,
    sources={path.name:sha(path) for path in (model,scene,display,*buffers.values())})
(run/'fixed-pose-face-and-body-geometry.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
