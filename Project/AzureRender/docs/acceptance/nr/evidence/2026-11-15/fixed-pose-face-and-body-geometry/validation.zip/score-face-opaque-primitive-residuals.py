"""Test if the shared facial edge color residuals share the original visible triangle."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


run=Path(__file__).resolve().parent
base=run/'score-fixed-pose-face-and-body-geometry.py'
state={'__file__':str(base)}
code=base.read_text(encoding='utf8').split('\npublic_face=read(',1)[0]
assert '\npublic_face=read(' in base.read_text(encoding='utf8')
exec(compile(code,str(base),'exec'),state)
read,model,grid,settings,project,rows,height=[state[key] for key in
    ('read','model','grid','definition','project','rows','height')]
face_material='S_actor_laevat_face_01_lod0'
source=read(run/'public-face-remaining-owner-residual.json')
native_trace=run/'trace-face-view-mask.json'
traced=read(native_trace)
confirmed={tuple(row['sample']['point']):row['sample']['primitive'] for row in traced['points']}
e804=grid/'native-face-skin-stages'
manifest=read(e804/'results.json')['geometry']['804']
vpath,ipath=(e804/f'{label}-804.bin' for label in ('vertex','index'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert (digest(vpath),digest(ipath))==(manifest['vertexSha256'],manifest['indexSha256'])
native=np.fromfile(vpath,'<f4').reshape(-1,manifest['vertexStride']//4)
indices_native=np.fromfile(ipath,'<u2').reshape(-1,3)
mesh,=[item for item in settings['meshes'] if item.get('name')==face_material]
primitive,=mesh['primitives']
position=rows(primitive['attributes']['POSITION'])
texcoord=rows(primitive['attributes']['TEXCOORD_0']).copy()
texcoord[:,1]=1-texcoord[:,1]
indices_player=rows(primitive['indices']).reshape(-1,3)
assert np.array_equal(np.sort(indices_native,1),np.sort(indices_player,1))
xys,native_w=native[:,:2]/native[:,3,None],native[:,3]
upper=(xys*np.array([1,-1],dtype='f4')+np.float32(1))*np.array([1280,720],dtype='f4')
upper[:,1]=np.float32(height)-upper[:,1]
player_screen,player_depth=project(position)


def probe(point, coordinates, triangles, depth, uv):
    quantized=(np.rint(coordinates*256)/256).astype('f8')
    a,b,c=quantized[triangles].transpose(1,0,2)
    ab,ac=b-a,c-a
    area=ab[:,0]*ac[:,1]-ab[:,1]*ac[:,0]
    safe=np.where(area,area,1)
    dx,dy=(np.asarray(point)+.5-a).T
    u=(dx*ac[:,1]-dy*ac[:,0])/safe
    v=(ab[:,0]*dy-ab[:,1]*dx)/safe
    weights=np.column_stack((1-u-v,u,v))
    covered=np.flatnonzero(np.all(weights>=0,1)&(area!=0))
    if not len(covered):
        return None
    weighted=weights[covered]/depth[triangles[covered]]
    most_close=int(np.argmax(weighted.sum(1)))
    prim=int(covered[most_close])
    bary=weighted[most_close]/weighted[most_close].sum()
    return dict(index=prim,uv=(bary@uv[triangles[prim]]).tolist(),coverage=int(len(covered)))


candidates=set()
joint=[{tuple(p['point']) for p in source['devices'][dev]['opaqueEdge'][1]['aboveEight']}
       for dev in ('nvidia','intel')]
for points in joint:
    candidates.update(points)
assert len(candidates)==49
output=[]
for point in sorted(candidates|confirmed.keys()):
    left=probe(point,upper,indices_native,native_w,native[:,4:6])
    right=probe(point,player_screen,indices_player,player_depth,texcoord)
    witness=confirmed.get(point)
    row=dict(point=point,edgeResidual=point in candidates,sourcePrimitive=witness,modelNative=left,modelPlayer=right,
             sameSurfacePrimitive=bool(left and right and left['index']==right['index']))
    if row['sameSurfacePrimitive']:
        row['atlas1024UvTexelMax']=float(np.abs(np.asarray(left['uv'])-right['uv']).max()*1024)
    output.append(row)
validation=[row for row in output if row['sourcePrimitive'] is not None]
known_owners=sum(row['sourcePrimitive']==row['modelNative']['index'] for row in validation if row['modelNative'])
all_edge=[row for row in output if row['edgeResidual']]
keep=[row for row in all_edge if row['sameSurfacePrimitive']]
print('reference triangle controls',known_owners,len(validation),'equal on edge',len(keep),len(all_edge),
      'max uv texels',max(row['atlas1024UvTexelMax'] for row in keep),flush=True)
print('owner mismatches',[(r['point'],r['sourcePrimitive'],r['modelNative']['index'] if r['modelNative'] else None)
      for r in validation if not r['modelNative'] or r['sourcePrimitive']!=r['modelNative']['index']],flush=True)
report=dict(status='measured-opaque-face-projection-triangle-model',
    readbackControls=len(validation),matchedNativePrimitives=known_owners,
    edgeResiduals=len(all_edge),bothModelsSamePrimitive=len(keep),maximumUvTexelDifference=max(row['atlas1024UvTexelMax'] for row in keep),
    nativeTrace=digest(native_trace),asset=digest(model),results=output)
(run/'face-opaque-primitive-residuals.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
