"""Read the preserved native stages at the isolated mesh coverage witnesses."""
from hashlib import sha256
import json
from pathlib import Path
import runpy

import numpy as np


run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
folder=run/'body-native-skin-interior-stages-unchanged-history-failed'
retained=run/'body-outline-before-transparent-cloth'
read=lambda p:json.loads(p.read_bytes())
score=runpy.run_path(str(grid/'static-quality.py'))
decoder=runpy.run_path(str(run/'iris-matcap-differential-player.py'),run_name='bodyContour')
verify=read(run/'preserved-native-skin-controls.json')
model=read(run/'fixed-pose-face-and-body-geometry.json')['events']['body']
xy=np.fromfile(folder/'points.bin','<u2').reshape(-1,2)
points=model['nativeVisibleMissing'][1]
assert points==[[1181,898],[1199,951]]
a,b=[np.where(np.all(xy==point,axis=1))[0].item() for point in points]
native_words={}
for stage,meta in sorted(verify['anchors'].items(),key=lambda value:int(value[0])):
    raw=(folder/f'nvidia-{stage}.bin').read_bytes()
    assert sha256(raw).hexdigest()==meta['nvidiaSnapshot']
    native_words[int(stage)]=np.frombuffer(raw,'<u4')[[a,b]]
stages=[782,783,1383]
source=score['image'](score['reference_path'])
original=read(retained/'results.json')
comparison={}
for tag in original['devices']:
    frame=retained/tag/'frames/frame_000000.png'
    assert score['sha'](frame)==original['devices'][tag]['frame']
    comparison[tag]=score['image'](frame)
proof={}
for index,(x,y) in enumerate(points):
    sequence=[]
    old=None
    for mark,value in native_words.items():
        word=value[index]
        if old!=word or mark in stages:
            display=decoder['display'](decoder['unpack'](np.array([word],'<u4')))[0]
            sequence.append(dict(stage=mark,packed=int(word),display=display.tolist(),
                candidateErrors={device:int(np.abs(image[y,x].astype('i2')-display).max())
                                 for device,image in comparison.items()}))
        old=word
    assert sequence[-1]['display']==source[y,x].tolist()
    proof[f'{x},{y}']=dict(nativeSequence=sequence,
        actual={device:image[y,x].tolist() for device,image in comparison.items()})
    print((x,y),proof[f'{x},{y}'])
(run/'body-contour-raw-stage-controls.json').write_text(json.dumps(dict(
    status='measured-frozen-body-contour-stage-readback',points=proof),indent=2)+'\n',encoding='utf8')
