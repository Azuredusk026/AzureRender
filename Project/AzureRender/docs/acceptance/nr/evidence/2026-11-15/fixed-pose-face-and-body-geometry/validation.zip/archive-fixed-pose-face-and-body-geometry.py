from hashlib import sha256
import json
from pathlib import Path
import runpy
from zipfile import ZIP_DEFLATED,ZipFile


run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
order=run/'body-outline-before-transparent-cloth'
score=runpy.run_path(str(grid/'static-quality.py'))
read=lambda p:json.loads(p.read_bytes())
payload=read(run/'fixed-pose-face-and-body-geometry.json')
assert payload['status']=='measured-fixed-pose-geometry-source-comparison'
body=payload['events']['body']
face=payload['events']['face']
assert body['exactWorldPositions']==body['exactUvCount']==3289
assert body['sameIndexedTriangleCount']==body['triangles']==5679
assert face['sameIndexedTriangleCount']==face['triangles']==2906 and face['vertices']==1792
assert face['nativeVisibleCovered']==[3663,3663] and isinstance(face['facePublicSource'],dict)
assert face['projectedCoverage']==[11462,11462] and face['coverageDifferences']==face['highErrorInCoverageDiff']==[]
assert max(face['viewportPixelPeak'])<.018
assert body['coverageDifferences']==[[1181,898]] and body['nativeVisibleCovered']==[47457,47456]
assert body['nativeFloat32VisibleMissing']==[]
assert body['nativeFloat32VulkanModelDisagreement']==[[1181,898],[1199,951]]
assert face['nativeFloat32VisibleMissing']==face['nativeFloat32VulkanModelDisagreement']==[]
contour=read(run/'body-contour-raw-stage-controls.json')
for side in contour['points'].values():
    before,skin,after=side['nativeSequence']
    assert [before['stage'],skin['stage'],after['stage']]==[782,783,1383]
    assert skin['packed']==after['packed']!=before['packed']
reference_path=score['reference_path']
ref=score['image'](reference_path).astype('i2')
sources={}
order_result=read(order/'results.json')
replay_points=body['nativeVisibleMissing'][1]
for device in ('nvidia','intel'):
    frame=order/device/'frames/frame_000000.png'
    sha=score['sha'](frame)
    assert sha==order_result['devices'][device]['frame']
    actual=score['image'](frame).astype('i2')
    sources[device]=dict(frame=sha,locationErrors=[
        dict(point=[x,y], original=ref[y,x].tolist(),rendered=actual[y,x].tolist(),
             maximum=int(abs(actual[y,x]-ref[y,x]).max())) for x,y in replay_points])
files={name:run/name for name in ('archive-fixed-pose-face-and-body-geometry.py',
    'score-fixed-pose-face-and-body-geometry.py','fixed-pose-face-and-body-geometry.json',
    'score-native-body-contour-stage-controls.py','body-contour-raw-stage-controls.json')}
for tag in sources:
    name=f'{tag}/frames/capture_manifest.json'
    files[name]=order/name
out=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/fixed-pose-face-and-body-geometry'
out.mkdir(parents=True,exist_ok=True)
destination=out/'validation.zip'
with ZipFile(destination,'w',ZIP_DEFLATED) as archive:
    for name,path in files.items():
        archive.write(path,name)
with ZipFile(destination) as archive:
    assert archive.testzip() is None
    checks={name:sha256(archive.read(name)).hexdigest() for name in files}
assert checks=={name:score['sha'](path) for name,path in files.items()}
payload.update(overall='failed-user-review', scope='isolated-fixed-pose-projection-reconstruction',renderedBodyControls=sources,nativeContourStages=contour['points'],
               frozenReference=score['sha'](reference_path),
               archive=dict(sha256=score['sha'](destination),members=checks))
(out/'results.json').write_text(json.dumps(payload,indent=2)+'\n',encoding='utf8')
print(sources,flush=True)
