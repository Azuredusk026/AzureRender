"""Verify the archived CTest matrix against the exact standard build products."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile, ZIP_DEFLATED

from focused_retry import digest, records, status, verify as verify_retry


run = Path(__file__).resolve().parent
root = run.parents[2]
sys.path.insert(0, str(root / 'tools'))
from build_provenance import verify as verify_build


def read(name):
    return json.loads((run / name).read_bytes())


def verify_matrix(require_complete):
    members = {'archive_completed_matrix.py', 'controller.py', 'focused_retry.py', 'full.py',
               'registered-seed.json', 'registered-evidence-transfer.json', 'protected-files.json'}
    protected = read('protected-files.json')
    assert all(digest(root / name) == expected for name, expected in protected.items())
    seeds = read('registered-seed.json')
    returned = {}
    for config, count in (('release', 607), ('debug', 605)):
        inventory = read(config + '-inventory.json')['tests']
        expected = {row['name']:row for row in inventory}
        assert len(expected) == len(inventory) == count
        source_receipt = config + '-tests-source.json'
        product_receipt = config + '-products.json'
        inventory_receipt = config + '-inventory.json'
        if require_complete:
            source = {p.relative_to(root).as_posix():digest(p) for p in (root / 'tests').rglob('*') if p.is_file()}
            assert source == read(source_receipt)
            verify_build(root, read(product_receipt))
        members.update((source_receipt, product_receipt, inventory_receipt, config + '-build-results.json'))
        seed = seeds[config]
        for name, sha in (seed['provenance'] | seed['junit']).items():
            assert digest(run / name) == sha, name
            members.add(name)
        outcomes = {}
        inherited = set()
        for name in seed['junit']:
            for case, item in records(run / name).items():
                assert case in expected and status(item) == 'passed', case
                outcomes[case] = 'passed'
                inherited.add(case)
        shard_pattern = re.compile(rf'{config}-(cpu|gpu)-[0-9]{{2}}\.json')
        for shard in sorted(run.glob(config + '-*.json')):
            if not shard_pattern.fullmatch(shard.name):
                continue
            report = read(shard.name)
            if 'selectedTests' not in report:
                continue
            xml = shard.with_suffix('.xml')
            names = shard.with_suffix('.txt')
            required_fingerprints = {name:digest(path) for name,path in
                                     [('products',run/product_receipt), ('registry',run/inventory_receipt),
                                      ('source',run/source_receipt), ('junit',xml), ('testNames',names)]}
            assert report['provenanceChecked'] == required_fingerprints, shard.name
            chosen = names.read_text(encoding='utf-8').splitlines()
            assert len(set(chosen)) == len(chosen) == report['selectedTests']
            original = records(xml)
            extra = set(original) - set(chosen)
            assert extra == set(report['automaticFixtureTests'])
            assert set(chosen) <= set(original) <= expected.keys()
            assert len(original) == report['tests']
            for name, case in original.items():
                observed = status(case)
                if observed != 'passed' or name not in outcomes:
                    outcomes[name] = observed
            members.update((shard.name, xml.name, names.name))
        recovered = {}
        for receipt in sorted(run.glob(config + '-*-*-focused-retry-*-receipt.json')):
            retest = verify_retry(receipt)
            members.add(receipt.name)
            members.update(retest['identity'])
            members.update(retest['retestIdentity'])
            for name in retest['recovered']:
                if outcomes.get(name) in ('failed','skipped'):
                    outcomes[name] = 'passed'
                    recovered[name] = receipt.name
        counts = Counter(outcomes.values())
        state = dict(expected=count, passed=counts['passed'], failed=counts['failed'],
                     skipped=counts['skipped'], pending=len(expected)-len(outcomes),
                     inherited=len(inherited), verifiedReruns=recovered)
        if require_complete:
            assert state['passed'] == count and not (state['failed'] or state['skipped'] or state['pending']), state
        returned[config] = state
    return returned, members


def archive(destination, results, members):
    destination.mkdir()
    path = destination / 'verification.zip'
    with ZipFile(path, 'w', compression=ZIP_DEFLATED, compresslevel=6) as package:
        for name in sorted(members):
            package.write(run / name, name)
    checksums = {name:digest(run / name) for name in sorted(members)}
    import hashlib
    with ZipFile(path) as package:
        assert set(package.namelist()) == members and package.testzip() is None
        assert all(hashlib.sha256(package.read(name)).hexdigest() == hash_value
                   for name, hash_value in checksums.items())
    head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip()
    receipt = dict(state='passed', head=head, configurations=results,
                   archive=dict(sha256=digest(path), files=checksums))
    (destination / 'results.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--archive', type=Path)
    args = parser.parse_args()
    summary, files = verify_matrix(require_complete=args.archive is not None)
    if args.archive:
        archive(args.archive, summary, files)
    print(json.dumps(summary, indent=2))
