"""Verify the complete CPU selection on the current Release and Debug products."""
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile

from archive_completed_matrix import verify_matrix
from focused_retry import digest, records, status, verify as verify_retry


run = Path(__file__).resolve().parent
root = run.parents[2]
target = root / "docs/acceptance/nr/evidence/2026-11-15/registered-cache-retention-cpu"


def read(name):
    return json.loads((run / name).read_bytes())


def cpu_cases(inventory):
    return {entry["name"] for entry in inventory["tests"]
            if "gpu" not in next((p["value"] for p in entry["properties"] if p["name"] == "LABELS"), [])}


def collect(config, seed, files):
    expected = cpu_cases(read(config + "-inventory.json"))
    results = defaultdict(set)
    captures = {}
    files.update((config + "-products.json", config + "-inventory.json",
                  config + "-tests-source.json", config + "-build-results.json"))
    files.update(seed["junit"])
    files.update(seed["provenance"])
    for junit in seed["junit"]:
        for name, case in records(run / junit).items():
            if name in expected:
                assert status(case) == "passed"
                results[name].add("passed")
                captures[name] = junit
    regex = re.compile(config + r"-cpu-\d\d\.json$")
    for report in sorted(run.glob(config + "-cpu-*.json")):
        if not regex.fullmatch(report.name):
            continue
        junit = report.with_suffix(".xml")
        record = read(report.name)
        observed = records(junit)
        assert expected >= observed.keys()
        assert record["provenanceChecked"]["junit"] == digest(junit)
        files.update((report.name, junit.name, report.with_suffix(".txt").name))
        for name, case in observed.items():
            results[name].add(status(case))
            if status(case) == "passed":
                captures[name] = junit.name
    recovered = {}
    for receipt in sorted(run.glob(config + "-cpu-*-focused-retry-*-receipt.json")):
        verified = verify_retry(receipt)
        files.add(receipt.name)
        files.update(verified["identity"])
        files.update(verified["retestIdentity"])
        for name in verified["recovered"]:
            assert name in expected and results[name] & {"failed", "skipped"}
            results[name] = {"passed"}
            recovered[name] = receipt.name
            captures[name] = verified["retest"] + ".xml"
    assert len(expected) == 333 and expected == results.keys() == captures.keys()
    assert all(outcomes == {"passed"} for outcomes in results.values())
    return dict(passed=len(expected), registered=len(expected), recovered=recovered,
                tests=dict(sorted(captures.items())))


def main():
    verify_matrix(require_complete=False)
    files = {Path(__file__).name, "archive_completed_matrix.py", "focused_retry.py",
             "registered-seed.json", "registered-evidence-transfer.json", "protected-files.json"}
    seed = read("registered-seed.json")
    outcome = {config: collect(config, seed[config], files) for config in ("release", "debug")}
    target.mkdir()
    package = target / "verification.zip"
    values = {name:digest(run / name) for name in sorted(files)}
    with ZipFile(package, "x", ZIP_DEFLATED, compresslevel=6) as archive:
        for name in sorted(files):
            archive.write(run / name, name)
    with ZipFile(package) as archive:
        assert set(archive.namelist()) == files and archive.testzip() is None
        assert all(sha256(archive.read(name)).hexdigest() == expect for name, expect in values.items())
    outcome["archive"] = dict(sha256=digest(package), files=values)
    (target / "results.json").write_text(json.dumps(outcome, indent=2) + "\n", encoding="utf-8")
    print("Release and Debug 333 of 333 CPU cases each;", len(values), "verified records")


if __name__ == "__main__":
    main()
