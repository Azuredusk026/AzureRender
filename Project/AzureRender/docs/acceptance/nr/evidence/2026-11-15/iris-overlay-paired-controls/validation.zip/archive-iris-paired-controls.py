"""Archive both actual iris captures with the eye-shadow draw toggled."""
import json
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root=Path(__file__).resolve().parent
destination=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/iris-overlay-paired-controls'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
members={'archive-iris-paired-controls.py':Path(__file__),'iris-overlay-main-frame-isolation.py':root/'iris-overlay-main-frame-isolation.py'}
data={}
for adapter,over_one in (('nvidia',(3,15,7)),('intel',(6,17,13))):
    folder=root/f'iris-native-main-frame-uncovered-{adapter}'
    enabled=root/f'eye-native-public-{adapter}-projected'
    record=read(folder/'results.json')
    assert digest(folder/'frames/frame_000000.png')==record['disabledFrameSha256']
    assert digest(enabled/'frames/frame_000000.png')==record['enabledFrameSha256']
    assert record['coveredCount']==94 and record['exactCoverage'] and record['outsideIrisChanged']==0
    assert tuple(record[k]['overOne'] for k in ('underlyingOnCovered','currentCovered','currentBare'))==over_one
    assert record['witnesses'][0]['point']==[1262,257] and record['witnesses'][0]['sourceBaseReplacementError']<=1
    assert read(folder/'frames/gpu_capabilities.json')['vendor_id']==(0x10de if adapter=='nvidia' else 0x8086)
    for label,path in (('shadow-on',enabled),('shadow-off',folder)):
        for name in ('results.json','command.json','frames/capture_manifest.json','frames/gpu_capabilities.json'):
            members[f'{adapter}/{label}/{name}']=path/name
    data[adapter]=record
destination.mkdir(parents=True,exist_ok=True)
package=destination/'validation.zip'
with ZipFile(package,'w',ZIP_DEFLATED) as archive:
    for name,path in members.items():archive.write(path,name)
with ZipFile(package) as archive:
    assert archive.testzip() is None
    hashes={name:sha256(archive.read(name)).hexdigest() for name in members}
assert hashes=={name:digest(path) for name,path in members.items()}
(destination/'results.json').write_text(json.dumps(dict(status='qualified-coverage',overallVisualAcceptance='failed-user-review',
    devices=data,archiveSha256=digest(package),members=hashes),indent=2)+'\n',encoding='utf8')
