"""Attribute the projected iris residual to underlying radiance or eye-geometry multiplication."""
from hashlib import file_digest, sha256
from pathlib import Path
import gzip
import json
import os
import runpy
import sys

import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
grid=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
reader=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read, dump, invoke=(reader[k] for k in ('read','dump','invoke'))
score=runpy.run_path(str(grid/'static-quality.py'))
fixture=grid/'iris-overlay-geometry-project'
coords=np.fromfile(grid/'native-iris-stages/points.bin','<u4').reshape(255,2)
x,y=coords.T

def digest(p):
    with p.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()

def frame(path):
    with Image.open(path) as im:return np.asarray(im.convert('RGB'),dtype=np.int16)

def linear(rgb):
    s=np.clip(rgb/255,0,1)
    return np.where(s<=.04045,s/12.92,((s+.055)/1.055)**2.4)

def display(rgb):
    t=np.clip(rgb,0,1)
    return np.rint(np.where(t<=.0031308,12.92*t,1.055*t**(1/2.4)-.055)*255).astype(np.int16)

def unpack(words):
    out=[]
    for shift,bits in ((0,6),(11,6),(22,5)):
        v=(words>>shift)&((1<<(bits+5))-1)
        p=(v>>bits).astype(int)
        m=v&((1<<bits)-1)
        out.append(np.where(p==0,np.ldexp(m.astype(float),-14-bits),np.ldexp(1+m/(1<<bits),p-15))*.25)
    return np.column_stack(out)

def summary(d,g):
    e=np.abs(d[g]).max(1)
    return dict(pixels=len(e),overOne=int((e>1).sum()),overEight=int((e>8).sum()),peak=int(e.max()))

def launch(device):
    assert device in ('nvidia','intel')
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==run
    qualified=run/f'eye-native-public-{device}-projected'
    q=read(qualified/'results.json')
    enabled=qualified/'frames/frame_000000.png'
    assert digest(enabled)==q['frameSha256']
    name=f'iris-native-main-frame-uncovered-{device}-control'
    out=run/f'iris-native-main-frame-uncovered-{device}'
    if out.exists():
        out.rename(run/f'{out.name}-previous-{len(list(run.glob(out.name+"-previous-*")))+1}')
    out.mkdir()
    project,level,material,sidecar=(read(qualified/('face-iris-public-main-frame.'+suffix)) for suffix in
        ('azureproject','azurelevel','azurematerial','azurematerial.azmeta'))
    before,=[n for n in level['nodes'] if n['id']=='native-eye-shadow']
    assert before['resourceId']=='native-eye-shadow'
    level['nodes'].remove(before)
    project['startupScene']=f'stage:/{name}.azurelevel'
    doc=qualified/'face-iris-public-main-frame.azurematerial'
    meta=doc.with_suffix('.azurematerial.azmeta')
    links=[]
    for filename,data in ((f'{name}.azureproject',project),(f'scene/{name}.azurelevel',level)):
        staged=out/Path(filename).name;dump(staged,data);links.append((fixture/filename,staged))
    links += [(fixture/'materials'/doc.name,doc),(fixture/'materials'/meta.name,meta)]
    cmd=read(qualified/'command.json')
    assert digest(Path(cmd[0]))==q['playerSha256']
    for flag,value in (('--project',fixture/f'{name}.azureproject'),('--capture-dir',out/'frames'),('--runtime-report',out/'runtime.json')):
        cmd[cmd.index(flag)+1]=str(value)
    attached=[]
    try:
        for destination,staged in links:
            if destination.is_file():
                assert digest(destination)==digest(staged),destination
                continue
            assert not destination.exists(),destination
            destination.hardlink_to(staged);attached.append((destination,staged))
        disabled=invoke(device,cmd,out)/'frame_000000.png'
    finally:
        for destination,staged in reversed(attached):
            if destination.is_file() and os.path.samefile(destination,staged):destination.unlink()
            if destination.suffix in ('.azureproject','.azurelevel'):
                generated=destination.with_name(destination.name+'.azmeta')
                if generated.is_file():generated.replace(out/generated.name)
    analyze(device, disabled, enabled, q, out)

def analyze(device, disabled, enabled, q, out):
    read_native=score['stages']/'post-opaque-ownership'
    manifest=read(read_native/'manifest.json')
    overlay,=[record for record in manifest['events'] if record['event']==1245]
    source_stage=[]
    assert set(overlay['files'])=={'1245-1244.bin.gz','1245-1245.bin.gz'}
    for filename in sorted(overlay['files']):
        raw=gzip.decompress((read_native/filename).read_bytes())
        assert len(raw)==2560*1440*4
        source_stage.append(np.frombuffer(raw,'<u4').reshape(1440,2560)[::-1][y,x])
    native_pre,native_post=map(unpack,source_stage)
    mask=source_stage[0]!=source_stage[1]
    assert int(mask.sum())==94
    a,b=(frame(f) for f in (disabled,enabled))
    actual_pre,actual_post=(f[y,x] for f in (a,b))
    visible=frame(score['reference_path'])[y,x]
    reference_stage_error=summary(visible-display(native_post),np.ones(len(x),dtype=bool))
    same_outside_iris=np.ones(a.shape[:2],dtype=bool)
    same_outside_iris[y,x]=False
    delta=(a!=b).any(2)
    coverage_missing=mask&~delta[y,x]
    coverage_added=~mask&delta[y,x]
    native_factor=np.divide(native_post,native_pre,out=np.ones_like(native_post),where=native_pre>0)
    actual_pre_l,actual_post_l=linear(actual_pre),linear(actual_post)
    factor=np.divide(actual_post_l,actual_pre_l,out=np.ones_like(actual_post_l),where=actual_pre_l>0)
    base_source_err=np.abs(actual_pre-display(native_pre)).max(1)
    overlay_source_err=np.abs(actual_post-visible).max(1)
    impose_factor=display(actual_pre_l*native_factor)
    impose_base=display(native_pre*factor)
    assert int((overlay_source_err>1).sum())==q['irisOverOne']
    lo,hi=(linear(actual_pre+delta) for delta in (-.5,.5))
    flo=np.divide(linear(actual_post-.5),hi,out=np.ones_like(hi),where=hi>0)
    fhi=np.divide(linear(actual_post+.5),lo,out=np.ones_like(lo),where=lo>0)
    min_drift=np.maximum(np.maximum(flo-native_factor,native_factor-fhi),0)
    report=dict(device=device,status='source-isolation',nativeReferenceSha256=digest(score['reference_path']),
        runPlayerSha256=q['playerSha256'],enabledFrameSha256=digest(enabled),disabledFrameSha256=digest(disabled),
        coveredCount=int(mask.sum()),exactCoverage=not bool(coverage_missing.any() or coverage_added.any()),
        nativePostToReference=reference_stage_error,
        coverageMissing=coords[coverage_missing].tolist(),coverageAdded=coords[coverage_added].tolist(),
        outsideIrisChanged=int(delta[same_outside_iris].sum()),
        underlyingOnCovered=summary(actual_pre-display(native_pre),mask),
        currentCovered=summary(actual_post-visible,mask),currentBare=summary(actual_post-visible,~mask),
        estimatedNativeFactorOnPlayerBase=summary(impose_factor-visible,mask),
        estimatedPlayerFactorOnNativeBase=summary(impose_base-visible,mask),
        nativeFactorCaveat='The source linear target is packed R11G11B10 and Player factors have an interval inferred from eight-bit output.',
        witnesses=[])
    for i in np.flatnonzero(mask & (overlay_source_err>1)):
        report['witnesses'].append(dict(point=coords[i].tolist(),currentError=int(overlay_source_err[i]),
            preError=int(base_source_err[i]),preNative=display(native_pre[i]).tolist(),prePlayer=actual_pre[i].tolist(),
            postNative=visible[i].tolist(),postPlayer=actual_post[i].tolist(),
            factorNative=native_factor[i].tolist(),factorPlayer=factor[i].tolist(),factorMinDrift=min_drift[i].tolist(),
            sourceBaseReplacementError=int(abs(impose_base[i]-visible[i]).max()),
            sourceFactorReplacementError=int(abs(impose_factor[i]-visible[i]).max())))
    report['witnesses'].sort(key=lambda r:-r['currentError'])
    dump(out/'results.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='witnesses'}))
    print(json.dumps(report['witnesses'][:3]))
    assert report['exactCoverage'] and reference_stage_error['peak']==0,report

if __name__=='__main__':launch(*sys.argv[1:])

