$ErrorActionPreference='Stop'
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes
$element=[System.Windows.Automation.AutomationElement]
$scope=[System.Windows.Automation.TreeScope]
$root=$element::RootElement
$windowName=[System.Windows.Automation.PropertyCondition]::new($element::NameProperty,'OMEN Gaming Hub')
$window=$root.FindFirst($scope::Children,$windowName)
$created=$null -eq $window
$leaveReady=$false
function Visible-Controls($window) {
    $nodes=$window.FindAll($scope::Descendants,[System.Windows.Automation.Condition]::TrueCondition)
    for ($i=0;$i -lt $nodes.Count;$i++) {
        $node=$nodes.Item($i)
        if (!$node.Current.IsOffscreen) { $node }
    }
}
function Select-Visible($nodes,[string]$id) {
    $list=@($nodes | Where-Object { $_.Current.AutomationId -eq $id -and $_.Current.IsEnabled })
    if ($list.Count -eq 1) { return $list[0] }
    if ($list.Count -lt 2) { return $null }
    $rectangles=@($list | ForEach-Object { $_.Current.BoundingRectangle.ToString() } | Sort-Object -Unique)
    if ($rectangles.Count -eq 1 -and !$list[0].Current.BoundingRectangle.IsEmpty) { return $list[0] }
    return $null
}
function Describe-Controls($nodes) {
    for ($i=0;$i -lt $nodes.Count;$i++) {
        $node=$nodes[$i]
        $r=$node.Current
        if ($r.Name -notmatch 'Fan|RPM|Mode|Performance|OMEN 16|性能|风扇|转速|模式|平衡|自动|最大|自定义|手动|^\d{3,4}$' -and
            $r.AutomationId -notmatch 'Fan|RPM|Mode|Performance|Systemvitals') { continue }
        $state=$null
        $choice=$null
        if ($node.TryGetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern,[ref]$choice)) {
            $state=[string]$choice.Current.IsSelected
        } elseif ($node.TryGetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern,[ref]$choice)) {
            $state=[string]$choice.Current.ToggleState
        }
        [pscustomobject]@{Order=$i;Name=$r.Name;Id=$r.AutomationId;Type=$r.ControlType.ProgrammaticName;
            Help=$r.HelpText;State=$state;Enabled=$r.IsEnabled;Rect=$r.BoundingRectangle.ToString();
            Patterns=@($node.GetSupportedPatterns() | ForEach-Object ProgrammaticName)}
    }
}
$actions=[System.Collections.Generic.List[string]]::new()
$closer=$null
try {
    if ($created) {
        $app=@(Get-StartApps | Where-Object Name -eq 'OMEN Gaming Hub')
        if ($app.Count -ne 1 -or $app[0].AppID -ne 'AD2F1837.OMENCommandCenter_v10z8vjag6ke6!AD2F1837.OMENCommandCenter') {
            throw 'The verified local OMEN Gaming Hub app was not found.'
        }
        Start-Process -FilePath "$env:SystemRoot\explorer.exe" -ArgumentList ('shell:AppsFolder\'+$app[0].AppID) -WindowStyle Hidden
        $deadline=(Get-Date).AddSeconds(36)
        do {
            Start-Sleep -Milliseconds 900
            $window=$root.FindFirst($scope::Children,$windowName)
        } until ($null -ne $window -or (Get-Date) -ge $deadline)
        if ($null -eq $window) { throw 'Expected the verified app window after launch.' }
    }
    $hasWindowPattern=$window.TryGetCurrentPattern([System.Windows.Automation.WindowPattern]::Pattern,[ref]$closer)
    if ($hasWindowPattern -and $closer.Current.WindowVisualState.ToString() -eq 'Minimized') {
        $closer.SetWindowVisualState([System.Windows.Automation.WindowVisualState]::Normal)
    }
    $deadline=(Get-Date).AddSeconds(70)
    do {
        $nodes=@(Visible-Controls $window)
        $known=@(Describe-Controls $nodes)
        if (@($known | Where-Object Name -Match '风扇控制|风扇转速|风扇速度|Fan Control|Fan Speed').Count) {
            $leaveReady=$true
            break
        }
        $manager=Select-Visible $nodes 'SystemvitalsPerformanceControlButton'
        $tab=Select-Visible $nodes 'PerformancecontrolTab'
        $homeCard=Select-Visible $nodes 'OMEN 16'
        $side=Select-Visible $nodes 'OMEN X LAPTOP'
        if ($null -ne $manager -and !$actions.Contains('performance-tile')) {
            $manager.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
            $actions.Add('performance-tile')
        } elseif ($null -ne $tab -and !$actions.Contains('performance-tab') -and !$actions.Contains('performance-tile')) {
            $switch=$tab.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
            if ($switch.Current.ToggleState.ToString() -eq 'Off') {
                $switch.Toggle()
                $actions.Add('performance-tab')
            }
        } elseif ($null -ne $homeCard -and !$actions.Contains('device-card')) {
            $homeCard.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
            $actions.Add('device-card')
        } elseif ($null -ne $side -and !$actions.Contains('device-sidebar')) {
            $switch=$side.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
            if ($switch.Current.ToggleState.ToString() -eq 'Off') {
                $switch.Toggle()
                $actions.Add('device-sidebar')
            }
        }
        Start-Sleep -Milliseconds 1100
    } until ((Get-Date) -ge $deadline)
    $report=[pscustomobject]@{Status=$(if ($leaveReady) { 'performance-controls-observed' } else { 'fan-panel-unresolved' });
        Title=$window.Current.Name; ProcessId=$window.Current.ProcessId; Handle=$window.Current.NativeWindowHandle;
        Opened=$created;Time=(Get-Date).ToString('o');Actions=$actions;Controls=$known}
    $report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$PSScriptRoot/omen-performance-controls.json" -Encoding utf8
    $report | ConvertTo-Json -Depth 6
}
finally {
    if ($created -and $null -ne $closer) {
        if ($leaveReady) { $closer.SetWindowVisualState([System.Windows.Automation.WindowVisualState]::Minimized) }
        else { $closer.Close() }
    }
}
