$ErrorActionPreference = 'Stop'
$setting = 50
$group = 'SUB_PROCESSOR'
$variants = @('PERFEPP','PERFEPP1')
$balanced = [Guid]'381b4222-f694-41f0-9685-ff5bb260df2e'
$temporary = [Guid]::NewGuid()
$inventory = [System.Collections.Generic.List[object]]::new()
$created = $false
$measurementExit = 1
$powercfg = (Get-Command powercfg.exe).Source

function Invoke-PowerCfg([string[]]$Arguments) {
    $output = & $powercfg @Arguments 2>&1
    if ($LASTEXITCODE -ne 0) { throw "powercfg $($Arguments -join ' ') returned $LASTEXITCODE. $output" }
    return ($output -join "`n")
}

function Read-ActivePlan {
    $output = Invoke-PowerCfg @('/getactivescheme')
    $value = [Regex]::Match($output, '\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b')
    if (!$value.Success) { throw 'No active Windows power plan GUID.' }
    return [Guid]$value.Value
}

function Read-Epp([Guid]$Plan) {
    $byCoreClass = [ordered]@{}
    foreach ($alias in $variants) {
        $query = Invoke-PowerCfg @('/qh', $Plan.ToString(), $group, $alias)
        $indices = [Regex]::Matches($query, '(?im):\s*0x([0-9a-f]{8})\s*$')
        if ($indices.Count -lt 2) { throw "The AC and DC EPP values for $alias were unavailable." }
        $byCoreClass[$alias] = [pscustomobject]@{
            ac = [Convert]::ToInt32($indices[$indices.Count - 2].Groups[1].Value, 16)
            dc = [Convert]::ToInt32($indices[$indices.Count - 1].Groups[1].Value, 16)
        }
    }
    return $byCoreClass
}

$original = Read-ActivePlan
if ($original -ne $balanced) { throw 'The current Windows power plan differs from the paired balanced control.' }
$before = Read-Epp $original
if ($before.PERFEPP.ac -ne 25 -or $before.PERFEPP1.ac -ne 25) {
    throw 'The current AC energy preference differs from the paired control.'
}
[pscustomobject]@{original=$original;temporary=$temporary;values=$before} |
    ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$PSScriptRoot/power-policy-before.json" -Encoding utf8
try {
    Invoke-PowerCfg @('/duplicatescheme', $original.ToString(), $temporary.ToString()) | Out-Null
    $created = $true
    Invoke-PowerCfg @('/changename', $temporary.ToString(), 'AzureRender processor energy preference diagnostic') | Out-Null
    foreach ($alias in $variants) {
        Invoke-PowerCfg @('/setacvalueindex', $temporary.ToString(), $group, $alias, [string]$setting) | Out-Null
    }
    $asSet = Read-Epp $temporary
    foreach ($alias in $variants) {
        if ($asSet[$alias].ac -ne $setting -or $asSet[$alias].dc -ne $before[$alias].dc) {
            throw "The temporary plan did not retain the expected AC and DC values for $alias."
        }
    }
    if ((Read-ActivePlan) -ne $original) { throw 'The active Windows power plan changed before measurement.' }
    Invoke-PowerCfg @('/setactive', $temporary.ToString()) | Out-Null
    if ((Read-ActivePlan) -ne $temporary) { throw 'The temporary power plan did not become active.' }
    [pscustomobject]@{active=$temporary; values=$asSet; time=(Get-Date).ToString('o')} |
        ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$PSScriptRoot/power-policy-ready.json" -Encoding utf8
    $start = [System.Diagnostics.ProcessStartInfo]::new()
    $start.FileName = (Get-Process -Id $PID).Path
    $start.WorkingDirectory = (Resolve-Path "$PSScriptRoot/../../..").Path
    $start.CreateNoWindow = $true
    $start.UseShellExecute = $false
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    foreach ($argument in @('-NoLogo','-NoProfile','-File',"$PSScriptRoot/run_max_fan_measurement.ps1")) {
        $start.ArgumentList.Add($argument)
    }
    $process = [System.Diagnostics.Process]::Start($start)
    try {
        $stdout = $process.StandardOutput.ReadToEndAsync()
        $stderr = $process.StandardError.ReadToEndAsync()
        do {
            try { $inventory.Add([pscustomobject]@{time=(Get-Date).ToString('o'); active=(Read-ActivePlan)}) }
            catch { $inventory.Add([pscustomobject]@{time=(Get-Date).ToString('o'); error=$_.Exception.Message}) }
        } until ($process.WaitForExit(10000))
        $measurementExit = $process.ExitCode
        $stdout.GetAwaiter().GetResult() | Set-Content -LiteralPath "$PSScriptRoot/fan-controller.stdout.log" -Encoding utf8
        $stderr.GetAwaiter().GetResult() | Set-Content -LiteralPath "$PSScriptRoot/fan-controller.stderr.log" -Encoding utf8
    }
    finally { $process.Dispose() }
    if ($inventory.Count -eq 0 -or @($inventory | Where-Object {$_.error -or $_.active -ne $temporary}).Count -gt 0 -or
        (Read-ActivePlan) -ne $temporary) { throw 'The temporary power plan did not remain active for the full run.' }
}
finally {
    $inventory | ConvertTo-Json -AsArray -Depth 3 | Set-Content -LiteralPath "$PSScriptRoot/power-policy-observations.json" -Encoding utf8
    $current = Read-ActivePlan
    if ($current -eq $temporary) {
        Invoke-PowerCfg @('/setactive', $original.ToString()) | Out-Null
        $current = Read-ActivePlan
    }
    if ($created -and $current -ne $temporary) { Invoke-PowerCfg @('/delete', $temporary.ToString()) | Out-Null }
    $asRestored = Read-Epp $original
    $restored = [pscustomobject]@{active=$current; values=$asRestored; time=(Get-Date).ToString('o')}
    $restored | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$PSScriptRoot/power-policy-restored.json" -Encoding utf8
    if ($current -ne $original -or ($asRestored | ConvertTo-Json -Depth 4 -Compress) -ne
        ($before | ConvertTo-Json -Depth 4 -Compress)) { throw 'The initial Windows plan and EPP values were not restored.' }
}
exit $measurementExit
