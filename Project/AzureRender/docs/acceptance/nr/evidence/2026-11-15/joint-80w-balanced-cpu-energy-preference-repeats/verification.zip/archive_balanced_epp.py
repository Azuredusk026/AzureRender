"""Verify the joint-scene measurement, observed CPU preference and restoration."""
import argparse
import csv
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
from zipfile import ZipFile, ZIP_DEFLATED


original = Path(__file__).resolve().parent
root = original.parents[2]
date = root / 'docs/acceptance/nr/evidence/2026-11-15'
members = ('budget.json','command.json','cooling-control-preflight.json','cooling-control-result-identity.json',
           'environment.json','fan-before.json','fan-controller.stdout.log','fan-controller.stderr.log',
           'fan-observations.json','fan-ready.json','fan-restored.json','measure_overlay.py','measurement.log',
           'measurement.stderr.log','observe_omen_performance.ps1','omen-performance-controls.json',
           'player.log','power-policy-before.json','power-policy-observations.json','power-policy-ready.json',
           'power-policy-restored.json','prepare_max_fan_replay.py','process-memory.json','process.log','results.json',
           'run_balanced_epp_measurement.ps1','run_max_fan_measurement.ps1','timing.csv','timing.json')


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def verify(run):
    identity = read(run/'cooling-control-result-identity.json')
    main = read(date/'joint-80w-maximum-fan/results.json')
    assert identity['measurement'] == main['product']
    for path, key in [('results.json','resultSha256'),('environment.json','telemetrySha256'),('timing.csv','timingCsvSha256')]:
        assert digest(run/path) == identity[key]
    assert digest(run/'measure_overlay.py') == main['product']['measurementSha256']
    result = read(run/'results.json')
    gates = identity['measurement']['gates']
    assert (result['warmup'],result['frames'],result['driver'],result['gpuPowerLimitWatts'])==(300,1800,'595.79',[80.0])
    assert result['allocatorZero']
    assert (result['nonlocalAllocations'],result['nonlocalBytes']) == (224,1588625408)
    before = read(run/'power-policy-before.json')
    ready = read(run/'power-policy-ready.json')
    restored = read(run/'power-policy-restored.json')
    assert before['original'] == restored['active'] == '381b4222-f694-41f0-9685-ff5bb260df2e'
    assert before['values'] == restored['values'] == {key:{'ac':25,'dc':50} for key in ('PERFEPP','PERFEPP1')}
    observations = read(run/'power-policy-observations.json')
    assert len(observations)>=10 and all(obs['active'] == ready['active'] for obs in observations)
    assert before['temporary'] == ready['active'] and ready['active'] != restored['active']
    assert ready['values'] == {key:{'ac':50,'dc':50} for key in ('PERFEPP','PERFEPP1')}
    fan = read(run/'fan-restored.json')
    assert fan['automatic'] and fan['balanced'] and not fan['maximum']
    assert read(run/'fan-observations.json')[-1] == fan
    with ZipFile(date/'joint-80w-maximum-fan/verification.zip') as archive:
        baseline = json.loads(archive.read('command.json'))['command']
    changed = read(run/'command.json')['command']
    pos = baseline.index('--gpu-timing-output')+1
    assert baseline[:pos] == changed[:pos] and baseline[pos+1:] == changed[pos+1:]
    with (run/'timing.csv').open() as handle:
        frames = list(csv.DictReader(handle))
    assert [int(row['frame']) for row in frames] == list(range(1,2101))
    times = sorted(float(row['frameMs']) for row in frames[300:])
    rank = .95*(len(times)-1)
    p95 = times[int(rank)]+(rank-int(rank))*(times[int(rank)+1]-times[int(rank)])
    assert abs(result['timings']['frameMs']['p95']-p95)<1e-6
    telemetry = read(run/'environment.json')
    observed = telemetry['startup']+telemetry['runObservations']+[telemetry['final']]
    assert all(value['powerLimitWatts']==80.0 and value['driver']=='595.79' for value in observed)
    slowdown = sum(value['thermalSlowdown']['software'] for value in observed)
    assert slowdown == result['softwareThermalSlowdownObservations']
    assert result['gates'] == {
        'fixed80W':True,'thermalAndAC':not result['environmentFailures'], 'gpuP95':p95<=gates['gpuP95Ms'],
        'cpuP95':result['timings']['cpuWorkMs']['p95']<=gates['cpuWorkP95Ms'],
        'deviceLocal':result['deviceLocalPeakBytes']<=gates['deviceLocalBytes'],
        'workingSet':result['workingSetPeakBytes']<=gates['workingSetBytes']}
    expected = ('succeeded',0) if all(result['gates'].values()) else ('failed',8)
    authority='file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro'
    with sqlite3.connect(authority,uri=True) as db:
        receipt = db.execute('select id,task,state,exit_code from jobs where output=? order by id desc limit 1',(str(run),)).fetchone()
    assert receipt[2:] == expected
    return dict(dispatch=receipt, run=run.name, results=result, product=identity['measurement'],
                recordedPreference=dict(before=before, ready=ready, samples=len(observations), restored=restored),
                restoredFan=fan, startupTemperaturesC=[value['temperature'] for value in telemetry['startup']],
                framePacing=read(run/'timing.json')['framePacing'])


def save(runs, destination):
    outcomes = [verify(run) for run in runs]
    destination.mkdir()
    files = {'archive_balanced_epp.py':Path(__file__).resolve()}
    files.update({f'{run.name}/{name}':run/name for run in runs for name in members})
    hashes = {name:digest(path) for name,path in files.items()}
    package = destination/'verification.zip'
    with ZipFile(package,'w',compression=ZIP_DEFLATED,compresslevel=6) as bundle:
        for name,path in files.items():
            bundle.write(path,name)
    with ZipFile(package) as bundle:
        assert set(bundle.namelist()) == hashes.keys() and bundle.testzip() is None
        assert all(sha256(bundle.read(name)).hexdigest()==value for name,value in hashes.items())
    passed = sum(all(outcome['results']['gates'].values()) for outcome in outcomes)
    data = dict(passedRounds=passed,totalRounds=len(outcomes),rounds=outcomes,
                archive=dict(sha256=digest(package),files=hashes))
    (destination/'results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for outcome in outcomes:
        result=outcome['results']
        print(outcome['dispatch'],result['gates'],result['timings']['frameMs']['p95'],result['timings']['cpuWorkMs']['p95'])
    print('Verified archive members',len(hashes))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('destination',type=Path)
    parser.add_argument('runs',nargs='*',type=Path)
    options = parser.parse_args()
    save([run.resolve() for run in options.runs] or [original],options.destination)
