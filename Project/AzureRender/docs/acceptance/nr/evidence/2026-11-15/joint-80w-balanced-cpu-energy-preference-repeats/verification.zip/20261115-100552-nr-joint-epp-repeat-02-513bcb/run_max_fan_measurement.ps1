$ErrorActionPreference='Stop'
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes
$anchor=Get-Content -LiteralPath "$PSScriptRoot/cooling-control-preflight.json" -Raw | ConvertFrom-Json
$project=(Resolve-Path "$PSScriptRoot/../../..").Path
$python=(Resolve-Path "$project/build/reinstall-environment/venv/Scripts/python.exe").Path
$element=[System.Windows.Automation.AutomationElement]
$scope=[System.Windows.Automation.TreeScope]
$root=$element::RootElement
$windowName=[System.Windows.Automation.PropertyCondition]::new($element::NameProperty,'OMEN Gaming Hub')
$window=$root.FindFirst($scope::Children,$windowName)
$closer=$null
$stateBefore=$null
$closeOwned=$false
$requestedMax=$false
$measurementExit=0
$balanceId='PerformancecontrolPowerBalancedButton'
$autoId='PerformancecontrolThermalAutoButton'
$maxId='PerformancecontrolThermalMaxButton'
$rpmId='ThermalControlFanSpeedRpm'
$trace=[System.Collections.Generic.List[object]]::new()
function Read-Control([string]$id) {
    $condition=[System.Windows.Automation.PropertyCondition]::new($element::AutomationIdProperty,$id)
    $items=$window.FindAll($scope::Descendants,$condition)
    $visible=@(
        for ($i=0;$i -lt $items.Count;$i++) {
            $control=$items.Item($i)
            if (!$control.Current.IsOffscreen -and $control.Current.IsEnabled) { $control }
        }
    )
    if ($visible.Count -ne 1) { throw "Expected one visible $id control." }
    return $visible[0]
}
function Read-Selection([string]$id) {
    $control=Read-Control $id
    return $control.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern)
}
function Observe-Thermal {
    $rpmLabel=(Read-Control $rpmId).Current.Name
    if ($rpmLabel -notmatch '^(\d{3,4})\s*RPM$') { throw 'The fan speed is not available as an RPM reading.' }
    $rpm=[int]$Matches[1]
    [pscustomobject]@{
        time=(Get-Date).ToString('o');rpm=$rpm
        balanced=(Read-Selection $balanceId).Current.IsSelected
        automatic=(Read-Selection $autoId).Current.IsSelected
        maximum=(Read-Selection $maxId).Current.IsSelected
    }
}
try {
    if ($null -eq $window) {
        & "$PSScriptRoot/observe_omen_performance.ps1" | Out-Null
        $window=$root.FindFirst($scope::Children,$windowName)
        if ($null -eq $window) { throw 'The OMEN fan panel is unavailable.' }
    }
    $last=Get-Content -LiteralPath "$PSScriptRoot/omen-performance-controls.json" -Raw | ConvertFrom-Json
    $closeOwned=$last.Opened -and $last.ProcessId -eq $window.Current.ProcessId -and $last.Handle -eq $window.Current.NativeWindowHandle
    if ($window.TryGetCurrentPattern([System.Windows.Automation.WindowPattern]::Pattern,[ref]$closer)) {
        $stateBefore=$closer.Current.WindowVisualState
        if ($stateBefore.ToString() -eq 'Minimized') {
            $closer.SetWindowVisualState([System.Windows.Automation.WindowVisualState]::Normal)
        }
    }
    if ($null -eq $window.FindFirst($scope::Descendants,
        [System.Windows.Automation.PropertyCondition]::new($element::AutomationIdProperty,$maxId))) {
        & "$PSScriptRoot/observe_omen_performance.ps1" | Out-Null
    }
    $before=Observe-Thermal
    $trace.Add($before)
    if (!$before.balanced -or !$before.automatic -or $before.maximum) {
        throw 'The paired fan control requires the observed balanced and automatic starting profile.'
    }
    $before | ConvertTo-Json | Set-Content -LiteralPath "$PSScriptRoot/fan-before.json" -Encoding utf8
    $requestedMax=$true
    (Read-Selection $maxId).Select()
    $deadline=(Get-Date).AddSeconds(155)
    do {
        Start-Sleep -Seconds 3
        $current=Observe-Thermal
        $trace.Add($current)
        if ($current.balanced -and $current.maximum -and $current.rpm -ge $anchor.minimumObservedFanRpm) { break }
    } until ((Get-Date) -ge $deadline)
    if (!$current.balanced -or !$current.maximum -or $current.rpm -lt $anchor.minimumObservedFanRpm) {
        throw 'The selected maximum fan mode did not reach the observed target RPM.'
    }
    $ready=[pscustomobject]@{source='OMEN Gaming Hub';original='automatic';selected='maximum';
        powerMode='balanced';rpm=$current.rpm;observedAt=$current.time}
    $ready | ConvertTo-Json | Set-Content -LiteralPath "$PSScriptRoot/fan-ready.json" -Encoding utf8
    Write-Output "Verified maximum fan speed $($current.rpm) RPM at $($current.time)."
    $cmd=[System.Diagnostics.ProcessStartInfo]::new()
    $cmd.FileName=$python
    $cmd.WorkingDirectory=$project
    $cmd.CreateNoWindow=$true
    $cmd.UseShellExecute=$false
    $cmd.RedirectStandardOutput=$true
    $cmd.RedirectStandardError=$true
    foreach ($entry in @('-B','-X','utf8',"$PSScriptRoot/prepare_max_fan_replay.py",'--measure-after-confirmed-max-fan')) {
        $cmd.ArgumentList.Add($entry)
    }
    $process=[System.Diagnostics.Process]::Start($cmd)
    $stdout=$process.StandardOutput.ReadToEndAsync()
    $stderr=$process.StandardError.ReadToEndAsync()
    try {
        while (!$process.WaitForExit(5000)) {
            try { $trace.Add((Observe-Thermal)) }
            catch { $trace.Add([pscustomobject]@{time=(Get-Date).ToString('o');observationError=$_.Exception.Message}) }
        }
        $measurementExit=$process.ExitCode
        $stdout.GetAwaiter().GetResult() | Set-Content -LiteralPath "$PSScriptRoot/measurement.log" -Encoding utf8
        $stderr.GetAwaiter().GetResult() | Set-Content -LiteralPath "$PSScriptRoot/measurement.stderr.log" -Encoding utf8
    }
    finally { $process.Dispose() }
}
finally {
    try {
        if ($requestedMax) {
            $autoNow=Read-Selection $autoId
            $maxNow=Read-Selection $maxId
            if ($maxNow.Current.IsSelected -and !$autoNow.Current.IsSelected) {
                $autoNow.Select()
                $deadline=(Get-Date).AddSeconds(35)
                do {
                    Start-Sleep -Milliseconds 800
                    $autoNow=Read-Selection $autoId
                } until ($autoNow.Current.IsSelected -or (Get-Date) -ge $deadline)
            }
            try { $restored=Observe-Thermal }
            catch {
                $restored=[pscustomobject]@{time=(Get-Date).ToString('o');
                    automatic=$autoNow.Current.IsSelected;observationError=$_.Exception.Message}
            }
            $trace.Add($restored)
            $restored | ConvertTo-Json | Set-Content -LiteralPath "$PSScriptRoot/fan-restored.json" -Encoding utf8
            if (!$restored.automatic) { throw 'The automatic fan profile could not be verified after the run.' }
        }
    }
    finally {
        $trace | ConvertTo-Json -Depth 4 -AsArray | Set-Content -LiteralPath "$PSScriptRoot/fan-observations.json" -Encoding utf8
        if ($null -ne $closer) {
            if ($closeOwned) { $closer.Close() }
            elseif ($null -ne $stateBefore -and $stateBefore.ToString() -eq 'Minimized') { $closer.SetWindowVisualState($stateBefore) }
        }
    }
}
exit $measurementExit
