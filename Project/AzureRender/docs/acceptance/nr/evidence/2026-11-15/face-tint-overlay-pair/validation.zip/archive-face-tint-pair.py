"""Archive dual-adapter face tint in the retained two-overlay variant."""
from hashlib import sha256
from pathlib import Path
import json
from zipfile import ZIP_DEFLATED, ZipFile


root=Path(__file__).resolve().parent
output=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/face-tint-overlay-pair'
read=lambda path:json.loads(path.read_bytes())
sha=lambda path:sha256(path.read_bytes()).hexdigest()
members=['archive-face-tint-pair.py','face-geometry-mask-actual.py','face-view-mask-math.json',
         'assets-tint-base-pair/mesh-face-geometry-mask.frag','assets-tint-base-pair/prepared.json']
devices={}
for device,over_one,over_eight,introduced in (('nvidia',[366,215],[64,15],30),('intel',[376,219],[66,17],28)):
    relative=f'capture-{device}-tint-base-pair'
    directory=root/relative
    receipt=read(directory/'results.json')
    assert receipt['input']['overlayPair'] and receipt['input']['mode']=='tint-base'
    assert sha(directory/'frames/frame_000000.png')==receipt['frameSha256']
    assert receipt['regions']['face']['overOne']==over_one and receipt['regions']['face']['overEight']==over_eight
    assert receipt['regions']['face']['newOverOne']==introduced
    assert not any(receipt['regions'][key]['changed'] for key in ('iris','outsideFace'))
    assert receipt['samples']['traced']['errors'][1][:2]==[41,34]
    manifest=read(directory/'frames/capture_manifest.json')
    hardware=read(directory/'frames/gpu_capabilities.json')
    assert manifest['qaCamera']=='scene' and hardware['vendor_id']==(0x10de if device=='nvidia' else 0x8086)
    devices[device]=dict(frame=receipt['frameSha256'],control=receipt['baselineSha256'],
        shaderInput=receipt['input'],face=receipt['regions']['face'],
        iris=receipt['regions']['iris'],outsideFace=receipt['regions']['outsideFace'],
        trackedFaceLocations=receipt['samples']['traced'])
    members.extend(f'{relative}/{name}' for name in ('command.json','results.json','frames/capture_manifest.json','frames/gpu_capabilities.json'))
nvidia_mask='capture-nvidia-tint-base-sdf-pair'
mask=read(root/nvidia_mask/'results.json')
assert mask['input']['overlayPair'] and mask['input']['mode']=='tint-base-sdf'
assert sha(root/nvidia_mask/'frames/frame_000000.png')==mask['frameSha256']
assert mask['regions']['face']['overOne']==[366,212] and mask['regions']['face']['overEight']==[64,12]
assert mask['regions']['face']['newOverOne']==30 and mask['samples']['traced']['errors'][1][:2]==[1,4]
assert not any(mask['regions'][key]['changed'] for key in ('iris','outsideFace'))
members.extend([f'{nvidia_mask}/command.json',f'{nvidia_mask}/results.json',
    'assets-tint-base-sdf-pair/mesh-face-geometry-mask.frag','assets-tint-base-sdf-pair/prepared.json'])
output.mkdir(parents=True,exist_ok=True)
archive_path=output/'validation.zip'
with ZipFile(archive_path,'w',ZIP_DEFLATED) as archive:
    for name in members:archive.write(root/name,name)
with ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    checks={name:sha256(archive.read(name)).hexdigest() for name in members}
assert checks=={name:sha(root/name) for name in members}
result=dict(status='measured-actual-face-tint-and-overlays',overallVisualAcceptance='failed-user-review',
    devices=devices,nvidiaWithSdfMask=mask,archive=dict(sha256=sha(archive_path),members=checks))
(output/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
