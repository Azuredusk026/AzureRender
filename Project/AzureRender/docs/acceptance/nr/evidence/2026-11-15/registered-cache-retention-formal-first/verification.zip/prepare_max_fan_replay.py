"""Run the registered formal performance entry with verified temporary cooling controls."""
from datetime import datetime, timezone
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import NamedTemporaryFile


out = Path(__file__).resolve().parent
root = Path.cwd().resolve()
build = root / 'build/ninja-msvc-release'
baseline = out
sys.path.insert(0, str(root/'tools'))
from build_provenance import product_paths, verify


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open('rb') as handle:
        return file_digest(handle,'sha256').hexdigest()


def atomic_write(path, data):
    with NamedTemporaryFile(mode='wb',dir=path.parent,prefix=path.name+'-',suffix='.pending',delete=False) as handle:
        temporary = Path(handle.name)
        handle.write(data)
    try:
        os.replace(temporary,path)
    finally:
        temporary.unlink(missing_ok=True)


def main():
    assert sys.argv[1:] == ['--measure-after-confirmed-max-fan']
    fan = read(out/'fan-ready.json')
    plan = read(out/'power-policy-ready.json')
    stamp = datetime.fromisoformat(fan['observedAt'])
    assert 0 <= (datetime.now(timezone.utc)-stamp).total_seconds() < 120
    assert fan['selected']=='maximum' and fan['original']=='automatic' and fan['powerMode']=='balanced' and fan['rpm']>=5600
    assert plan['values']=={key:{'ac':50,'dc':50} for key in ('PERFEPP','PERFEPP1')}
    provenance=baseline/'release-products.json'
    exact=read(provenance)
    runtime={str(path.resolve()):exact['products'][str(path.resolve())] for path in product_paths(build,'Release')}
    proof=dict(exact, products=runtime, registeredBuildReceiptSha256=digest(provenance), configuration='Release')
    verify(root,proof)
    encoded=(json.dumps(proof,indent=2)+'\n').encode('utf-8')
    runtime_manifest=build/'build-provenance.json'
    previous=runtime_manifest.read_bytes()
    (out/'formal-runtime-provenance.json').write_bytes(encoded)
    (out/'previous-runtime-manifest-sha256.txt').write_text(sha256(previous).hexdigest()+'\n',encoding='utf-8')
    driver=subprocess.check_output(['nvidia-smi.exe','--query-gpu=driver_version','--format=csv,noheader'],text=True).strip()
    assert driver=='595.79',driver
    env=dict(os.environ, VK_LOADER_DRIVERS_SELECT='*nv-vk64*',DOTNET_ROOT='D:/Tools/dotnet9')
    env['PATH']=os.pathsep.join(map(str,(build,build/'vcpkg_installed/x64-windows/bin',env['PATH'])))
    for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES','VK_LAYER_VALIDATE_SYNC',
                'VK_LOADER_DEBUG','AZURERENDER_RESOURCE_ROOT','AZURE_DISABLE_COMPUTED_MATERIAL_VIEW','AZURE_DIAGNOSTIC_NONLOCAL_TEXTURES'):
        env.pop(key,None)
    folder=out/'formal'
    command=[sys.executable,'-B','-X','utf8',str(root/'tools/run_playable_performance.py'),
             '--player',str(build/'AzurePlayer.exe'),'--editor',str(build/'AzureRender.exe'),
             '--exploration',str(root/'assets_public/exploration/project.azureproject'),
             '--platformer',str(root/'assets_public/platformer/project.azureproject'),'--output',str(folder)]
    (out/'formal-command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
    assert runtime_manifest.read_bytes()==previous
    atomic_write(runtime_manifest,encoded)
    try:
        result = subprocess.run(command,env=env,cwd=root,timeout=5900)
        report=read(folder/'summary.json')
        assert set(report['rounds'])=={'standard','editor','stress','exploration','platformer'}
        assert all(len(rows)==3 for rows in report['rounds'].values())
        assert report['passed'] == (result.returncode==0)
        assert all(rounding['warmup']==300 and rounding['samples']==1800 for rounds in report['rounds'].values()
                   for rounding in rounds if 'warmup' in rounding)
        assert all(sample['driver']==driver for rounds in report['rounds'].values() for rounding in rounds
                   for sample in rounding.get('environment',{}).get('runObservations',[]))
        verify(root,proof)
    finally:
        if runtime_manifest.read_bytes()!=encoded:
            raise RuntimeError('The generated runtime provenance was replaced during measurement')
        atomic_write(runtime_manifest,previous)
        assert runtime_manifest.read_bytes()==previous
    return result.returncode


if __name__ == '__main__':
    raise SystemExit(main())
