from hashlib import sha256
import json
from pathlib import Path
import runpy
import subprocess
import sys
import numpy as np
from PIL import Image

root=Path(__file__).resolve().parent
target=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
source=root/'body-outline-remaining-draw-ownership.json'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
scores=runpy.run_path(str(target/'static-quality.py'))
reference=scores['image'](scores['reference_path']).astype(np.int16)
q=root.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
points=np.fromfile(q/'body-visible-ownership-points.bin','<u2').reshape(-1,3)
x,y,owner=points.T
cover=np.zeros(reference.shape[:2],dtype=bool)
cover[y,x]=True
base_mode='beauty-transparent-highlights'
records=read(source)['devices']
mode=base_mode+'-captured-origin'
result=dict(status='measured-captured-rim-origin',strictVisualAcceptance='failed-user-review',
            originalOwnerReceipt=digest(source),devices={})
for device in ('nvidia','intel'):
    outputs=[]
    for label in (mode,'rim-transparent-highlights-captured-origin'):
        folder=root/f'body-outline-{label}-{device}'
        if not (folder/'results.json').is_file():
            subprocess.run([sys.executable,str(root/'body-outline-player-isolation.py'),device,label],
                           check=True,timeout=250)
        frame=folder/'frames/frame_000000.png'
        record=read(folder/'results.json')
        assert digest(frame)==record['frameSha256']
        outputs.append((frame,record))
    control=root/f'body-outline-{base_mode}-{device}/frames/frame_000000.png'
    assert digest(control)==records[device]['frame']
    old,actual,rim=[scores['image'](path).astype(np.int16) for path in (control,outputs[0][0],outputs[1][0])]
    delta=np.abs(old-actual).max(2)
    errors=[np.abs(image-reference).max(2) for image in (old,actual)]
    new_outside=int((delta[~cover]>0).sum())
    assert new_outside==0
    result['devices'][device]=dict(player=outputs[0][1]['playerSha256'],frame=digest(outputs[0][0]),rim=digest(outputs[1][0]),
        material=outputs[0][1]['materialSha256'],changedOutside=new_outside,
        regions={name:dict(count=int(region.sum()),overOne=[int((e[y,x][region]>1).sum()) for e in errors],
                           overEight=[int((e[y,x][region]>8).sum()) for e in errors],
                           peak=[int(e[y,x][region].max()) for e in errors])
                  for name,region in [('all',np.ones(len(x),bool)),('outline',owner==1018),('laterCloth',owner==1383)]},
        probes=[dict(point=[px,py],reference=reference[py,px].tolist(),previous=old[py,px].tolist(),
                       actual=actual[py,px].tolist(),rim=rim[py,px].tolist()) for px,py in
                ((1258,971),(1255,920),(1255,921),(1252,839),(1255,837),(1325,1120))])
    stats=result['devices'][device]['regions']['outline']['overEight']
    assert stats[1]<stats[0],result['devices'][device]
(root/'body-outline-native-rim-origin-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
