from hashlib import sha256
from pathlib import Path
import math
import json
import os
import subprocess
import sys
import traceback

key='AZURE_NR_BODY_OUTLINE_LANES'
out=Path(os.environ[key]) if key in os.environ else Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')

def worker():
    import renderdoc as rd
    mode=os.environ.get('AZURE_NR_BODY_OUTLINE_MODE','')
    extra=mode in ('addresses','address-controls')
    key_name='trace-body-outline'+('-'+mode if mode else '')
    job=read(out/(key_name+'-request.json'))
    result=dict(status='failed',bindings={},points=[])
    cap=rd.OpenCaptureFile()
    ctl=None
    try:
        assert cap.OpenFile(job['native'],'',None)==rd.ResultCode.Succeeded
        opt=rd.ReplayOptions();opt.forceGPUVendor=rd.GPUVendor.nVidia;opt.forceGPUDeviceID=0x28e0
        status,ctl=cap.OpenCapture(opt,None)
        assert status==rd.ResultCode.Succeeded and ctl
        props=ctl.GetAPIProperties()
        assert props.vendor==rd.GPUVendor.nVidia and not props.degraded and props.pipelineType==rd.GraphicsAPI.D3D11
        ctl.SetFrameEvent(1018,True)
        pipe=ctl.GetPipelineState()
        stage=rd.ShaderStage.Fragment
        shader=pipe.GetShaderReflection(stage)
        assert sha256(bytes(shader.rawBytes)).hexdigest()==job['shaderSha256']
        asm=ctl.DisassembleShader(pipe.GetGraphicsPipelineObject(),shader,'')
        (out/'native-outline-1018.asm').write_text(asm,encoding='utf8')
        for i,c in enumerate(shader.constantBlocks):
            d=pipe.GetConstantBlock(stage,i,0).descriptor
            if d.resource==rd.ResourceId.Null():continue
            b=bytes(ctl.GetBufferData(d.resource,d.byteOffset,d.byteSize))
            path=out/f'body-outline-1018-cb{c.fixedBindNumber}.bin'
            if mode:
                assert path.read_bytes()==b
            else:
                path.write_bytes(b)
            result['bindings'][c.fixedBindNumber]=dict(bytes=len(b),sha256=sha256(b).hexdigest())
        bound = {shader.readOnlyResources[slot.access.index].fixedBindNumber: slot.descriptor
                 for slot in pipe.GetReadOnlyResources(stage)}
        t14 = bound[14]
        assert str(t14.resource)=='ResourceId::85442' and t14.format.Name()=='BC7_SRGB'
        texture,=[t for t in ctl.GetTextures() if t.resourceId==t14.resource]
        assert 0<texture.width<=4096 and 0<texture.height<=4096 and 0<texture.mips<=13
        result['albedoTexture']=dict(id=str(t14.resource),viewFormat=t14.format.Name(),firstMip=t14.firstMip,
                                    width=texture.width,height=texture.height,mips={})
        for mip in range(0 if mode else texture.mips):
            raw=bytes(ctl.GetTextureData(t14.resource,rd.Subresource(mip,0,0)))
            blocks=((max(1,texture.width>>mip)+3)//4)*((max(1,texture.height>>mip)+3)//4)
            assert len(raw)==blocks*16,(mip,len(raw))
            tex=out/f'native-body-outline-albedo-{mip:02d}.bin'
            tex.write_bytes(raw)
            result['albedoTexture']['mips'][mip]=dict(path=tex.name,sha256=sha256(raw).hexdigest(),bytes=len(raw))
        target=pipe.GetOutputTargets()[0].resource
        assert str(target)=='ResourceId::141976'
        for x,y in job['points']:
            ctl.SetFrameEvent(1018,True)
            history=ctl.PixelHistory(target,x,1439-y,rd.Subresource(),rd.CompType.Typeless)
            hits=[h for h in history if h.eventId==1018 and not (h.depthTestFailed or h.stencilTestFailed or h.backfaceCulled or h.shaderDiscarded)]
            assert hits,(x,y)
            final=hits[-1]
            ctl.SetFrameEvent(1018,True)
            params=rd.DebugPixelInputs();params.primitive=final.primitiveID
            trace=ctl.DebugPixel(x,1439-y,params)
            assert trace and trace.debugger,(x,y)
            records=[];step_count=0
            state={}
            clip=uv=address=None
            try:
                while True:
                    batch=ctl.ContinueDebug(trace.debugger)
                    if not batch:break
                    for row in batch:
                        changes={}
                        for change in row.changes:
                            var=change.after
                            if var.name and var.name.startswith(('v','r','o')):
                                lanes=list(var.value.f32v)[:4]
                                changes[var.name]=[v if math.isfinite(v) else None for v in lanes]
                        instruction=int(row.nextInstruction)
                        if extra:
                            state.update(changes)
                            if instruction==50:clip=state['r6'][1:4]
                            if instruction==56:uv=state['r6'][1:3]
                            if instruction==64:address=state['r8'][:2]
                        else:
                            records.append([instruction,changes])
                        step_count+=1
                    if extra and address is not None:break
                    assert step_count<20000
            finally:ctl.FreeTrace(trace)
            base=dict(point=[x,y],primitive=int(final.primitiveID),rgb=list(final.shaderOut.col.floatValue)[:3],
                before=list(final.preMod.col.floatValue)[:3],after=list(final.postMod.col.floatValue)[:3],
                steps=step_count)
            if extra:
                assert all(value is not None for value in (clip,uv,address))
                base.update(clip=clip,floatAddress=uv,addressBits=address)
            else:
                suffix='-residual' if mode=='residuals' else ''
                path=out/f'body-outline{suffix}-trace-{x}-{y}.json'
                write(path,records)
                base.update(file=path.name,sha256=sha256(path.read_bytes()).hexdigest())
            result['points'].append(base)
            if extra and len(result['points'])%8==0:
                write(out/(key_name+'-checkpoint.json'),dict(status='capturing',points=result['points']))
        assert len(result['points'])==len(job['points'])
        result['status']='qualified'
    except Exception:result['error']=traceback.format_exc()
    finally:
        if ctl:ctl.Shutdown()
        cap.Shutdown()
        write(out/(key_name+'-source.json'),result)
    os._exit(0 if result['status']=='qualified' else 1)

def launch():
    from hashlib import file_digest
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==out
    assert sys.argv[1:] in ([],['addresses'],['residuals'],['address-controls'])
    mode=sys.argv[1] if len(sys.argv)>1 else ''
    extra=mode in ('addresses','address-controls')
    key_name='trace-body-outline'+('-'+mode if mode else '')
    job=read(grid/'native-face-masks/request.json')
    with Path(job['native']).open('rb') as stream:assert file_digest(stream,'sha256').hexdigest()==job['captureSha256']
    job['shaderSha256']=read(grid/'native-face-skin-stages/results.json')['geometry']['1018']['pixelShaderSha256']
    reconstruction=read(out/'body-outline-unqualified-depth-probe.json')['records']
    indices=range(len(reconstruction)) if extra else (0,len(reconstruction)//2,len(reconstruction)-1)
    geometry_controls=[reconstruction[i]['point'] for i in indices]
    job['lightPoints']=[[1325,1120],[1325,1118],[1270,1028],[1270,1037]]
    job['points']=geometry_controls if extra else job['lightPoints']+geometry_controls
    if mode=='address-controls':
        rows=read(out/'body-outline-source-footprint.json')['points']
        assert len(rows)==1118
        groups={}
        for row in rows:
            x,y,_,_,_,coords,_,_=row
            closest=min(abs(c-round(c)) for c in coords)
            groups.setdefault(y//120,[]).append((closest,x,y))
        selected=[]
        for band,items in sorted(groups.items()):
            if len(items)<2:continue
            ranked=sorted(items)
            chosen=[*ranked[:4],*ranked[len(ranked)//2:len(ranked)//2+2]]
            selected.extend([[x,y] for _,x,y in dict.fromkeys(chosen)])
        assert len(selected)==len({tuple(xy) for xy in selected}) and 36<=len(selected)<=66
        assert not ({tuple(xy) for xy in selected}&{tuple(entry['point']) for entry in reconstruction})
        job['points']=selected
    if mode=='residuals':
        ownership=read(out/'body-outline-remaining-draw-ownership.json')['devices']['nvidia']['events']
        shell=[row['point'] for row in ownership['1018']['witnesses'][:3]]
        covered=[row['point'] for row in ownership['1383']['witnesses'][:2]]
        job['points']=shell+covered+[[1325,1120]]
        assert len({tuple(xy) for xy in job['points']})==6
    write(out/(key_name+'-request.json'),job)
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    with (out/(key_name+'-source.log')).open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__))],
           cwd=out,env=dict(os.environ,**{key:str(out),'AZURE_NR_BODY_OUTLINE_MODE':mode}),
           stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=1440 if extra else 210)
    report=read(out/(key_name+'-source.json'))
    assert child.returncode==0 and report['status']=='qualified',report.get('error')

if key in os.environ:worker()
elif __name__=='__main__':launch()
