"""Seal both configurations' cache qualification and exact frozen public captures."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import sqlite3
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile


run = Path(__file__).resolve().parent
root = run.parents[2]
target = root / "docs/acceptance/nr/evidence/2026-11-15/registered-cache-retention-frozen"


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def main():
    results = read(run / "cache-retention-frozen-results.json")
    assert set(results) == {"release", "debug"}
    framed = {}
    files = [Path(__file__), run / "run_frozen_cache_retention.py", run / "source-activation.json",
             run / "cache-retention-frozen-results.json", run / "first-frozen-qualification-process.log",
             run / "debug-volume-995.log", run / "debug-volume-998.log", run / "debug-all-build.log"]
    recovery = []
    for path in sorted(run.glob("debug-volume-*-result.json")):
        report = read(path)
        archive_path = Path(report["path"])
        assert archive_path.is_dir() and report["freeAfter"] > report["freeBefore"]
        journal = path.with_name(path.name.removesuffix("-result.json") + ".jsonl")
        rows = [json.loads(line) for line in journal.read_bytes().splitlines()]
        copied = {row["archived"]: row for row in rows if row["state"] == "verified-copy"}
        moved = [row for row in rows if row["state"] == "relocated"]
        assert all(copied[row["archived"]]["sha256"] == row["sha256"] for row in moved)
        assert sum(row["allocatedBytes"] for row in moved) == report["relocatedAllocatedBytes"]
        assert all(Path(row["archived"]).parent == archive_path and Path(row["archived"]).stat().st_size == row["size"] for row in moved)
        recovery.append(dict(report, files=len(moved)))
        files.extend((path, journal))
    for config, data in results.items():
        capture = run / (config + "-retention-visual")
        assert read(capture / "results.json") == data
        files.extend(path for path in capture.iterdir() if path.is_file())
        for name in ("products", "build-results", "inventory", "tests-source"):
            files.append(run / (config + "-" + name + ".json"))
        registered = run / (config + "-cache-retention-frozen")
        proof = data["ctest"]
        assert proof == read(registered.with_suffix(".json")) and proof["status"] == "passed"
        stamp = proof["provenanceChecked"]
        assert stamp["products"] == digest(run / (config + "-products.json"))
        assert stamp["junit"] == digest(registered.with_suffix(".xml"))
        assert stamp["testNames"] == digest(registered.with_suffix(".txt"))
        cases = ET.parse(registered.with_suffix(".xml")).findall(".//testcase")
        assert len(cases) == 5 and all(case.find("failure") is None and case.find("skipped") is None for case in cases)
        files.extend(registered.with_suffix(ext) for ext in (".json", ".xml", ".txt", ".log"))
        observations = {}
        assert set(data["routes"]) == {"indexed", "fixed", "vertex"}
        for name, route in data["routes"].items():
            assert digest(capture / (name + "-summary.json")) == route["summarySha256"]
            assert len(route["frames"]) == 7
            for frame, row in route["frames"].items():
                assert row["captureSha256"] == row["referenceSha256"] and row["pixelDifferences"] == 0
                assert digest(root / "assets_public/baselines/character" / (frame + ".png")) == row["referenceSha256"]
                assert digest(capture / (name + "-" + frame + "-capture_manifest.json")) == row["manifestSha256"]
                assert digest(capture / (name + "-" + frame + "-gpu_capabilities.json")) == row["deviceSha256"]
            observations[name] = 7
        framed[config] = dict(registeredTests=len(cases), captures=observations, frameCount=sum(observations.values()))
    with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro", uri=True) as database:
        dispatch = database.execute("SELECT id,state,exit_code FROM jobs WHERE id IN (999,1004) ORDER BY id").fetchall()
        links = database.execute("SELECT id,state,exit_code,reason FROM jobs WHERE id IN (995,998,1003) ORDER BY id").fetchall()
    assert dispatch == [(999,"failed",1),(1004,"succeeded",0)]
    assert links == [(995,"budget-stopped",1,"volume-reserve"),(998,"budget-stopped",1,"volume-reserve"),
                     (1003,"succeeded",0,None)]
    target.mkdir()
    package = target / "verification.zip"
    members = {path.relative_to(run).as_posix(): digest(path) for path in files}
    with ZipFile(package, "x", ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            archive.write(path, path.relative_to(run).as_posix())
    with ZipFile(package) as archive:
        assert set(archive.namelist()) == members.keys() and archive.testzip() is None
        assert all(sha256(archive.read(name)).hexdigest() == checksum for name, checksum in members.items())
    receipt = dict(driver="595.79", rgbDifferencePixels=0, pngDigestMismatchCount=0,
                   configurations=framed, dispatch=dispatch, debugBuildDispatch=links, symbolRecovery=recovery,
                   archive=dict(sha256=digest(package), files=members))
    (target / "results.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
