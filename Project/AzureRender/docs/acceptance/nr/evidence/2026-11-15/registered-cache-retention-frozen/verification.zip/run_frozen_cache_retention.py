"""Retest the frozen public routes and pipeline cache on both standard builds."""
from hashlib import file_digest
import json
from pathlib import Path
import shutil
import subprocess
import sys
from zipfile import ZipFile


run = Path(__file__).resolve().parent
root = run.parents[2]
earlier = root / "docs/acceptance/nr/evidence/2026-11-15/integrated-frozen-public/verification.zip"
routes = {
    "indexed": ("AzureRender.VisualRegression", "visual-regression"),
    "fixed": ("AzureRender.VisualRegressionLegacyDescriptors", "visual-regression-legacy"),
    "vertex": ("AzureRender.VisualRegressionLegacySkinning", "visual-regression-legacy-skinning"),
}
tests = ["AzureRender.PipelineCacheStore", "AzureRender.VulkanPipelineCache", *(value[0] for value in routes.values())]


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def write(path, data):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")


def driver():
    return subprocess.check_output(["nvidia-smi.exe", "--query-gpu=driver_version", "--format=csv,noheader"],
                                   text=True).strip()


def verify_routes(out, build, reference):
    out.mkdir(exist_ok=True)
    rows = {}
    for route, (_, folder_name) in routes.items():
        folder = build / folder_name
        summary = build / (folder_name + "-summary.json")
        data = read(summary)
        assert data["tolerance"] == "strict" and data["failureCount"] == 0 and data["caseCount"] == 7
        assert {row["name"] for row in data["results"]} == reference[route]["frames"].keys()
        shutil.copy2(summary, out / (route + "-summary.json"))
        result = {}
        for row in data["results"]:
            assert row["status"] == "passed" and row["changedPixelRatio"] == 0 and row["meanAbsoluteRgbError"] == 0
            name = row["name"]
            case = folder / name
            expected = reference[route]["frames"][name]["referenceSha256"]
            baseline = root / "assets_public/baselines/character" / (name + ".png")
            captured = case / "frame_000000.png"
            assert digest(captured) == digest(baseline) == expected
            manifest = case / "capture_manifest.json"
            device = case / "gpu_capabilities.json"
            assert read(device)["vendor_id"] == 0x10DE and read(device)["driver_version"] == 2496905216
            for src in (manifest, device):
                shutil.copy2(src, out / (route + "-" + name + "-" + src.name))
            result[name] = dict(pixelDifferences=0, captureSha256=expected, referenceSha256=expected,
                                manifestSha256=digest(manifest), deviceSha256=digest(device))
        rows[route] = dict(summarySha256=digest(summary), frames=result)
    return rows


def main():
    assert driver() == "595.79"
    results = {}
    with ZipFile(earlier) as archive:
        for config, expected in (("release", 607), ("debug", 605)):
            receipt = read(run / (config + "-build-results.json"))
            assert receipt["status"] == "built" and receipt["tests"] == expected
            label = config + "-cache-retention-frozen"
            listing = run / (label + ".txt")
            ctest_result = listing.with_suffix(".json")
            if not ctest_result.is_file():
                listing.write_text("".join(name + "\n" for name in tests), encoding="utf-8")
                command = [sys.executable, "-B", "-X", "utf8", str(run / "full.py"),
                           "suite", config.capitalize(), "--select", label]
                subprocess.run(command, cwd=root, check=True)
            ctest = read(listing.with_suffix(".json"))
            assert ctest["status"] == "passed" and ctest["selectedTests"] == len(tests)
            for key, path in (("products",run/(config+"-products.json")),("registry",run/(config+"-inventory.json")),
                ("source",run/(config+"-tests-source.json")),("junit",listing.with_suffix(".xml")),("testNames",listing)):
                assert ctest["provenanceChecked"][key] == digest(path)
            original = json.loads(archive.read(config + "/frozen-visual.json"))
            build = root / ("build/ninja-msvc-" + config)
            evidence = verify_routes(run / (config + "-retention-visual"), build, original)
            assert driver() == "595.79"
            results[config] = dict(ctest=ctest, routes=evidence)
            capture_receipt = run / (config + "-retention-visual/results.json")
            if capture_receipt.is_file():
                assert read(capture_receipt) == results[config]
            else:
                write(capture_receipt, results[config])
    write(run / "cache-retention-frozen-results.json", results)


if __name__ == "__main__":
    main()
