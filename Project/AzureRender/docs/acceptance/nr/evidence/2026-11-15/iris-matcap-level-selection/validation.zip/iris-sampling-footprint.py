from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import subprocess
import sys
import traceback

KEY='AZURE_NR_IRIS_NATIVE_FOOTPRINT'
ROOT=Path(os.environ[KEY+'_ROOT']) if KEY in os.environ else Path(__file__).resolve().parent
GRID=ROOT.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')


def worker():
    folder=Path(os.environ[KEY])
    job=read(folder/'request.json')
    def checkpoint(stage, **data):
        write(folder/'progress.json',dict(stage=stage,**data))
    checkpoint('importing-replay')
    import renderdoc as rd
    sys.path.insert(0,job['utilities'])
    from dxbc_util import checksum,chunks,fbits,imm,instructions,opcode,rebuild,words

    def replace_bias(raw,bias,slot=13,explicit_level=False):
        assert checksum(raw)==raw[4:20]
        parts=chunks(raw)
        part,=[i for i,(kind,_) in enumerate(parts) if kind in (b'SHEX',b'SHDR')]
        body=words(parts[part][1])
        samples=[(at,n) for pc,at,op,n in instructions(body) if op==opcode('SAMPLE_B')]
        assert len(samples)==2
        at,n=samples[slot-13]
        source=body[at:at+n]
        assert source[-2:]==[1,26] and source[-6]==slot
        program=source[:-3]+imm(fbits(bias))
        program[0]=(program[0]&0x80ffffff)|(len(program)<<24)
        if explicit_level:program[0]=(program[0]&0x80fff800)|opcode('SAMPLE_L')|(len(program)<<24)
        body[at:at+n]=program
        body[1]=len(body)
        parts[part]=(parts[part][0],struct.pack('<'+'I'*len(body),*body))
        return rebuild(raw,parts)

    source=GRID/'iris-explicit-mips'
    coords=list(struct.iter_unpack('<II',Path(job['points']).read_bytes()))
    offsets=[((1439-y)*2560+x)*4 for x,y in coords]
    assert len(offsets)==255
    capture=rd.OpenCaptureFile()
    report=dict(status='running',devices={})
    try:
        checkpoint('opening-capture')
        assert capture.OpenFile(job['capture'],'',None)==rd.ResultCode.Succeeded
        for name,vendor,device in (('nvidia',rd.GPUVendor.nVidia,0x28e0),('intel',rd.GPUVendor.Intel,0xa788)):
            opts=rd.ReplayOptions();opts.forceGPUVendor=vendor;opts.forceGPUDeviceID=device
            checkpoint('opening-device',device=name)
            status,ctl=capture.OpenCapture(opts,None)
            assert status==rd.ResultCode.Succeeded and ctl
            original=replacement=None
            try:
                info=ctl.GetAPIProperties()
                assert info.vendor==vendor and info.pipelineType==rd.GraphicsAPI.D3D11 and not info.degraded
                checkpoint('seeking-draw',device=name)
                ctl.SetFrameEvent(846,True)
                pipe=ctl.GetPipelineState()
                stage=rd.ShaderStage.Fragment
                target=pipe.GetOutputTargets()[0].resource
                assert str(target)=='ResourceId::141976'
                original=pipe.GetShader(stage)
                raw=bytes(pipe.GetShaderReflection(stage).rawBytes)
                assert sha256(raw).hexdigest()==job['pixelShaderSha256']

                def attachment():
                    ctl.SetFrameEvent(846,True)
                    data=bytes(ctl.GetTextureData(target,rd.Subresource()))
                    assert len(data)==2560*1440*4
                    return data

                def select(data):
                    return b''.join(data[offset:offset+4] for offset in offsets)

                checkpoint('reading-original',device=name)
                baseline=attachment()
                previous=read(source/'iris-explicit-mips.json')['devices'][name]
                assert sha256(baseline).hexdigest()==previous['attachmentSha256']
                levels={}
                for level in range(10):
                    payload=(source/f'{name}-mip-{level:02d}.bin').read_bytes()
                    assert sha256(payload).hexdigest()==previous['mips'][str(level)]['sha256']
                    levels[level]=list(struct.iter_unpack('<I',payload))
                row=dict(attachmentSha256=sha256(baseline).hexdigest(),cases={})
                report['devices'][name]=row
                if job.get('matcapLevels'):
                    selected=select(baseline)
                    for level in (None,*range(9)):
                        checkpoint('explicit-matcap-level',device=name,level=level)
                        program=raw if level is None else replace_bias(raw,level,slot=14,explicit_level=True)
                        replacement,error=ctl.BuildTargetShader('main',rd.ShaderEncoding.DXBC,program,rd.ShaderCompileFlags(),stage)
                        assert replacement!=rd.ResourceId.Null(),error
                        ctl.ReplaceResource(original,replacement)
                        result=attachment()
                        if level is None:assert result==baseline
                        payload=select(result)
                        row['cases']['copy' if level is None else str(level)]=dict(sha256=sha256(payload).hexdigest(),
                            packed=[v[0] for v in struct.iter_unpack('<I',payload)])
                        ctl.RemoveReplacement(original);ctl.FreeTargetResource(replacement);replacement=None
                    assert attachment()==baseline
                    assert selected==struct.pack('<255I',*row['cases']['copy']['packed'])
                    row['baselineRestored']=True
                    continue
                for delta in (None,0,-.125,-.0625,-.03125,-.015625,-.0078125,-.00390625,.00390625,.0078125,.015625,.03125,.0625,.125):
                    key='copy' if delta is None else str(delta)
                    program=raw if delta is None else replace_bias(raw,-1+delta)
                    replacement,error=ctl.BuildTargetShader('main',rd.ShaderEncoding.DXBC,program,rd.ShaderCompileFlags(),stage)
                    assert replacement!=rd.ResourceId.Null(),error
                    ctl.ReplaceResource(original,replacement)
                    result=attachment()
                    if delta in (None,0):assert result==baseline,(name,key)
                    payload=select(result)
                    values=list(struct.iter_unpack('<I',payload))
                    matches=[[lod for lod,samples in levels.items() if samples[i]==value] for i,value in enumerate(values)]
                    assert all(matches),(name,key,[coords[i] for i,v in enumerate(matches) if not v])
                    row['cases'][key]=dict(attachmentSha256=sha256(result).hexdigest(),
                        regionSha256=sha256(payload).hexdigest(),selectedLevels=matches)
                    ctl.RemoveReplacement(original);ctl.FreeTargetResource(replacement);replacement=None
                assert attachment()==baseline
                row['baselineRestored']=True
            finally:
                if replacement and replacement!=rd.ResourceId.Null():
                    ctl.RemoveReplacement(original);ctl.FreeTargetResource(replacement)
                ctl.Shutdown()
        report['status']='qualified'
    except Exception:report.update(status='failed',error=traceback.format_exc())
    finally:
        capture.Shutdown()
        write(folder/'results.json',report)
    os._exit(0 if report['status']=='qualified' else 1)


def launch():
    from hashlib import file_digest
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert sys.argv[1:] in ([],['matcap'])
    matcap=sys.argv[1:]==['matcap']
    output=ROOT.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e' if matcap else ROOT
    assert lock['state']=='held' and Path(lock['output'])==output
    source=read(GRID/'iris-explicit-mips/request.json')
    with Path(source['capture']).open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==source['captureSha256']
    source['matcapLevels']=matcap
    folder=output/('iris-native-matcap-footprint' if matcap else 'iris-native-bias-footprint')
    if folder.is_dir():
        assert not (folder/'results.json').is_file() or read(folder/'results.json')['status']!='qualified'
        count=len(list(output.glob(folder.name+'-interrupted-*')))
        folder.rename(output/f'{folder.name}-interrupted-{count+1}')
    folder.mkdir()
    write(folder/'request.json',source)
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    with (folder/'replay.log').open('wb') as log:
        ret=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=folder,env=dict(os.environ,**{KEY:str(folder),KEY+'_ROOT':str(ROOT)}),stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=620 if matcap else 260)
    result=read(folder/'results.json')
    assert ret.returncode==0 and result['status']=='qualified',result.get('error')

if KEY in os.environ:
    try:
        worker()
    except BaseException:
        write(Path(os.environ[KEY])/'worker-error.json',dict(error=traceback.format_exc()))
        os._exit(1)
elif __name__=='__main__':launch()
