from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile

root=Path(__file__).resolve().parent
body=root.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
probe=root.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
target=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/iris-matcap-level-selection'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
data=read(root/'iris-native-matcap-d3d-vulkan-owned-levels.json')
assert data['status']=='measured-matcap-level-selection' and data['identicalNativeAndMaterialMipPayloads']==9
source=read(root/'trace-iris-matcap-inputs.json')
members={name:root/name for name in ('iris-native-matcap-d3d-vulkan-owned-levels.py',
    'iris-native-matcap-d3d-vulkan-owned-levels.json','archive-iris-matcap-level-selection.py',
    'trace-iris-matcap-inputs.json','iris-native-846-samplers.json','iris-native-matcap-footprint/request.json',
    'iris-native-matcap-footprint/results.json')}
members.update({name:probe/name for name in ('iris-sampling-footprint.py','trace-iris-base-inputs.py')})
members.update({'intel-player/'+name:body/'iris-native-intel-sample-lanes'/name
               for name in ('results.json','unchanged/command.json','unchanged/frames/gpu_capabilities.json')})
members['iris-intel-live-sampling.py']=body/'iris-intel-live-sampling.py'
for item in source['texture']['levels'].values():
    members['native-texture/'+item['path']]=root/item['path']
    assert sha(root/item['path'])==item['sha256']
target.mkdir(parents=True,exist_ok=True)
zip_path=target/'validation.zip'
with ZipFile(zip_path,'w',ZIP_DEFLATED) as archive:
    for name,filename in members.items():archive.write(filename,name)
with ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    hashes={name:sha256(archive.read(name)).hexdigest() for name in members}
assert hashes=={name:sha(filename) for name,filename in members.items()}
data['archive']=dict(sha256=sha(zip_path),members=hashes)
(target/'results.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
