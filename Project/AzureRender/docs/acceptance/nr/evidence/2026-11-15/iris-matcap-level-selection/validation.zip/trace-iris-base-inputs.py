from hashlib import sha256
from pathlib import Path
import json
import math
import os
import re
import subprocess
import sys
import traceback

key='AZURE_NR_IRIS_BASE_TRACE'
out=Path(os.environ[key]) if key in os.environ else Path(__file__).resolve().parent
g=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')

def trace():
    import renderdoc as rd
    prefix=os.environ.get('AZURE_NR_IRIS_BASE_TRACE_PREFIX','trace-iris-base')
    job=read(out/(prefix+'-request.json'))
    report=dict(status='failed',constants={},points=[])
    cap=rd.OpenCaptureFile();ctl=None
    try:
        assert cap.OpenFile(job['capture'],'',None)==rd.ResultCode.Succeeded
        opt=rd.ReplayOptions();opt.forceGPUVendor=rd.GPUVendor.nVidia;opt.forceGPUDeviceID=0x28e0
        state,ctl=cap.OpenCapture(opt,None)
        assert state==rd.ResultCode.Succeeded and ctl
        props=ctl.GetAPIProperties()
        assert props.vendor==rd.GPUVendor.nVidia and props.pipelineType==rd.GraphicsAPI.D3D11 and not props.degraded
        ctl.SetFrameEvent(846,True)
        pipe=ctl.GetPipelineState();stage=rd.ShaderStage.Fragment
        shader=pipe.GetShaderReflection(stage)
        assert sha256(bytes(shader.rawBytes)).hexdigest()==job['pixelShaderSha256']
        asm=ctl.DisassembleShader(pipe.GetGraphicsPipelineObject(),shader,'')
        asm_path=out/'iris-native-846.asm'
        if asm_path.is_file():
            assert asm_path.read_text(encoding='utf8').replace('\r\n','\n')==asm.replace('\r\n','\n')
        else:
            asm_path.write_text(asm,encoding='utf8')
        samples=[(int(k),op) for k,op in re.findall(r'^\s*(\d+):\s*(\S+[^\n]*)',asm,re.M) if op.startswith('sample')]
        primary=[(k,op) for k,op in samples if re.search(r'\bt13\.',op)]
        assert len(primary)==1 and 'sample_b' in primary[0][1]
        report['samples']=samples
        if prefix=='trace-iris-matcap':
            samplers={}
            for entry in pipe.GetSamplers(stage):
                binding=shader.samplers[entry.access.index].fixedBindNumber
                descriptor=entry.sampler
                samplers[binding]=dict(minify=str(descriptor.filter.minify),magnify=str(descriptor.filter.magnify),
                    mip=str(descriptor.filter.mip),address=[str(descriptor.addressU),str(descriptor.addressV)],
                    bias=descriptor.mipBias,minimum=descriptor.minLOD,maximum=descriptor.maxLOD,
                    anisotropy=descriptor.maxAnisotropy)
            assert {0,1}<=samplers.keys()
            write(out/'iris-native-846-samplers.json',samplers)
            descriptor,=[r.descriptor for r in pipe.GetReadOnlyResources(stage)
                         if shader.readOnlyResources[r.access.index].fixedBindNumber==14]
            tex,=[t for t in ctl.GetTextures() if t.resourceId==descriptor.resource]
            assert (tex.width,tex.height,tex.mips,descriptor.format.Name())==(256,256,9,'BC7_SRGB')
            levels={}
            for level in range(tex.mips):
                data=bytes(ctl.GetTextureData(tex.resourceId,rd.Subresource(level,0,0)))
                dim=max(1,tex.width>>level)
                assert len(data)==((dim+3)//4)**2*16
                path=out/f'iris-matcap-native-t14-mip{level}.bin'
                path.write_bytes(data)
                levels[level]=dict(path=path.name,width=dim,bytes=len(data),sha256=sha256(data).hexdigest())
            report['texture']=dict(resource=str(tex.resourceId),format=descriptor.format.Name(),levels=levels)
        elif prefix=='trace-iris-projected-residual':
            texture_slot,=[r.descriptor for r in pipe.GetReadOnlyResources(stage)
                           if shader.readOnlyResources[r.access.index].fixedBindNumber==13]
            tex,=[t for t in ctl.GetTextures() if t.resourceId==texture_slot.resource]
            assert (tex.width,tex.height,tex.mips,texture_slot.format.Name())==(512,512,10,'BC7_SRGB')
            raw_levels={}
            for level in (4,5):
                data=bytes(ctl.GetTextureData(tex.resourceId,rd.Subresource(level,0,0)))
                assert len(data)==(((tex.width>>level)+3)//4)**2*16
                path=out/f'iris-projected-native-t13-mip{level}.bin'
                path.write_bytes(data)
                raw_levels[level]=dict(path=path.name,bytes=len(data),sha256=sha256(data).hexdigest())
            report['texture']=dict(resource=str(tex.resourceId),format=texture_slot.format.Name(),levels=raw_levels)
        need={k for i,_ in samples for k in (i,i+1)}
        if prefix=='trace-iris-matcap':need.update(range(452,470))
        for i,block in enumerate(shader.constantBlocks):
            d=pipe.GetConstantBlock(stage,i,0).descriptor
            payload=bytes(ctl.GetBufferData(d.resource,d.byteOffset,d.byteSize))
            name=f'iris-native-846-cb{block.fixedBindNumber}.bin'
            path=out/name
            if path.is_file():
                assert path.read_bytes()==payload
            else:
                path.write_bytes(payload)
            report['constants'][name]=dict(sha256=sha256(payload).hexdigest(),bytes=len(payload))
        for candidate in job['points']:
            x,y=candidate['point']; prim=candidate['primitive']
            params=rd.DebugPixelInputs();params.primitive=prim
            hit=ctl.DebugPixel(x,1439-y,params)
            assert hit and hit.debugger
            live={}; selected={}; updates=[]; count=0
            try:
                while True:
                    batch=ctl.ContinueDebug(hit.debugger)
                    if not batch:break
                    for step in batch:
                        k=int(step.nextInstruction); changed={}
                        for item in step.changes:
                            reg=item.after
                            if reg.name:
                                changed[reg.name]=[v if math.isfinite(v) else None for v in list(reg.value.f32v)[:4]]
                        live.update(changed)
                        if changed:updates.append([k,changed])
                        if k in need:selected[k]=dict(live)
                        count+=1
                    assert count<20000
            finally:ctl.FreeTrace(hit)
            assert primary[0][0]+1 in selected,(candidate,count)
            label='matcap-' if prefix=='trace-iris-matcap' else ''
            tracefile=out/f'iris-native-846-{label}trace-{x}-{y}.json'
            tracefile.write_text(json.dumps(updates,separators=(',',':'))+'\n')
            report['points'].append(dict(point=candidate['point'],primitive=prim,
                  samples=selected,steps=count,file=tracefile.name,sha256=sha256(tracefile.read_bytes()).hexdigest()))
        report['status']='qualified'
    except Exception:report['error']=traceback.format_exc()
    finally:
        if ctl:ctl.Shutdown()
        cap.Shutdown()
        write(out/(prefix+'-inputs.json'),report)
    os._exit(0 if report['status']=='qualified' else 1)

def launch():
    global out
    from hashlib import file_digest
    if sys.argv[1:]==['matcap']:
        out=out.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e'
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==out
    job=read(g/'iris-explicit-mips/request.json')
    with Path(job['capture']).open('rb') as stream:assert file_digest(stream,'sha256').hexdigest()==job['captureSha256']
    extra=sys.argv[1:] in (['projected'],['matcap'])
    if extra:
        selected={(1262,257),(1302,265),(1260,262)}
        samples=read(g/'native-iris-bottom-history/results.json')['shaderSamples']
        job['points']=[dict(point=[row['x'],row['y']],primitive=row['primitive'])
                       for row in samples if (row['x'],row['y']) in selected]
        assert len(job['points'])==len(selected)
        prefix='trace-iris-matcap' if sys.argv[1:]==['matcap'] else 'trace-iris-projected-residual'
    else:
        assert len(sys.argv)==1
        stat=read(out/'iris-bare-radiance-budget.json')
        job['points']=[*stat['worst'][:4],next(r for r in stat['rows'] if r['point']==[1261,261])]
        prefix='trace-iris-base'
    write(out/(prefix+'-request.json'),job)
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    with (out/(prefix+'-inputs.log')).open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__))],
              cwd=out,env=dict(os.environ,**{key:str(out),'AZURE_NR_IRIS_BASE_TRACE_PREFIX':prefix}),
              stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=220)
    report=read(out/(prefix+'-inputs.json'))
    assert child.returncode==0 and report['status']=='qualified',report.get('error')

if key in os.environ:trace()
elif __name__=='__main__':launch()
