"""Read Intel samples at native coordinates through the normal Player entry point."""
from contextlib import ExitStack
from hashlib import file_digest
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys

import numpy as np
from PIL import Image


root=Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
probe=root.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
work=root.parents[2]
build=root/'msaa-release'
control=root/'iris-native-main-frame-uncovered-intel'
fixture=grid/'iris-overlay-geometry-project'
helper=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
read=lambda p:json.loads(p.read_bytes())
write=lambda p,value:p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')


def digest(path):
    with path.open('rb') as stream:return file_digest(stream,'sha256').hexdigest()


def run():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==root
    observed=read(control/'results.json')
    assert observed['status']=='source-isolation'
    player=build/'AzurePlayer.exe'
    assert digest(player)==observed['runPlayerSha256']
    command=read(control/'command.json')
    assert player==Path(command[0])
    control_project=Path(command[2])
    assert control_project.parent==fixture
    document=read(control/control_project.name)
    level_name=document['startupScene'].split(':/',1)[1]
    level=read(control/level_name)
    settings=level['renderSettings']
    assert settings['antiAliasing']==0 and not any(settings[key] for key in ('bloomEnabled','toneMapping'))
    assert all(node['id']!='native-eye-shadow' for node in level['nodes'])
    tag='iris-native-intel-sample-lanes'
    document['startupScene']=f'stage:/{tag}.azurelevel'
    output=root/tag
    output.mkdir(exist_ok=True)
    assert not (output/'results.json').is_file()
    files={fixture/(tag+'.azureproject'):document,fixture/'scene'/(tag+'.azurelevel'):level}
    retained_material=root/'eye-native-public-intel-projected/face-iris-public-main-frame.azurematerial'
    fingerprints=runpy.run_path(str(root/'face-quality-candidate-catalog.py'))['retained_catalog'](root)
    for previous in root.glob(tag+'*'):
        if not previous.is_dir():continue
        for saved in previous.glob('*/*.spv.original'):
            name=saved.name.removesuffix('.original')
            assert digest(saved)==fingerprints[name]
            saved.replace(build/'shaders'/name)
    assert {path.name:digest(path) for path in (build/'shaders').glob('*.spv')}==fingerprints
    source=subprocess.check_output(['git','show','42677a3:Project/AzureRender/shaders/mesh.frag'],cwd=work,encoding='utf8')
    marker='    vec3 qaColor = beautyColor;'
    assert source.count(marker)==1
    programs=('mesh_object_early_lighting.frag.spv','mesh_object_lighting.frag.spv',
              'mesh_object_early.frag.spv','mesh_object.frag.spv')
    rules={r['output']:r for r in read(build/'shader-reload.json')['programs']}
    sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
    native=read(probe/'iris-projected-source-inputs.json')['reconstruction']
    points=np.asarray([r['point'] for r in native],dtype=int)
    x,y=points.T
    channels=dict(baseRgb='baseColor.rgb',matcapRgb='eyeMatcap.rgb',
        alphaAndLod='vec3(baseColor.a,eyeMatcap.a,(textureQueryLod(AZ_TEX_BASE_COLOR,eyeCoordinates.baseUv).x+1.0)/16.0)',
        matcapGeometry='vec3(eyeCoordinates.matcapUv,(textureQueryLod(AZ_TEX_MATCAP,eyeCoordinates.matcapUv).x+1.0)/16.0)')
    # The normal spatial resolve converts to sRGB. Its inverse cancels the
    # transfer so the PNG stores the rounded data bytes directly.
    encode='vec3 codes=clamp(VALUES,0.0,1.0); vec3 v=mix(codes/12.92,pow((codes+.055)/1.055,vec3(2.4)),greaterThan(codes,vec3(.04045)));'
    gather={}
    captures={}
    with ExitStack() as run_cleanup:
        for material in (retained_material,retained_material.with_suffix('.azurematerial.azmeta')):
            target=fixture/'materials'/material.name
            if target.exists():
                assert digest(target)==digest(material)
                continue
            target.hardlink_to(material)
            run_cleanup.callback(target.unlink)
        for target,data in files.items():
            local=output/target.name
            write(local,data)
            target.hardlink_to(local)
            run_cleanup.callback(target.unlink)
            meta=target.with_name(target.name+'.azmeta')
            assert not meta.exists()
            run_cleanup.callback(meta.unlink,missing_ok=True)
        shaders=build/'shaders'
        resources=build
        for label,expression in {'unchanged':None,**channels}.items():
            frame_rows=[]
            for byte in (None,) if expression is None else ('high','low'):
                part=label+('-'+byte if byte else '')
                stage=output/part
                png=stage/'frames/frame_000000.png'
                if stage.is_dir() and not png.is_file():
                    assert not list(stage.glob('*.spv.original'))
                    count=len(list(output.glob(part+'-interrupted-*')))
                    stage.rename(output/f'{part}-interrupted-{count+1}')
                stage.mkdir(exist_ok=True)
                compiled={}
                if expression is not None:
                    value='floor(clamp('+expression+',0.0,1.0)*65535.0+.5)'
                    codes=(('floor('+value+'/256.0)') if byte=='high' else ('mod('+value+',256.0)'))+'/255.0'
                    glsl=source.replace(marker,marker+chr(10)+'    if(eyeRadial){'+encode.replace('VALUES',codes)
                        +'outputColor=vec4(v,1.0);outputDisplayMask=vec4(0.0);return;}')
                    src=stage/'sample.frag'
                    if png.is_file():
                        assert src.read_text(encoding='utf8')==glsl
                    else:
                        src.write_text(glsl,encoding='utf8')
                    for name in programs:
                        rule=rules[name]
                        target=stage/name
                        if not png.is_file():
                            compiler=[str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+flag for flag in rule['defines']),
                                      '-I'+str(work/'shaders'),str(src),'-o',str(target)]
                            subprocess.run(compiler,check=True,timeout=50)
                        subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(target)],
                                       check=True,timeout=45)
                        compiled[name]=target
                args=command.copy()
                for flag,value in {'--project':fixture/(tag+'.azureproject'),'--capture-dir':stage/'frames',
                                    '--resource-root':resources,'--runtime-report':stage/'runtime.json'}.items():
                    args[args.index(flag)+1]=str(value)
                if png.is_file():
                    assert read(stage/'command.json')==args
                    manifest=read(png.parent/'capture_manifest.json')
                    caps=read(png.parent/'gpu_capabilities.json')
                    assert (caps['vendor_id'],caps['device_id'])==(0x8086,0xa788)
                    assert (manifest['width'],manifest['height'],manifest['capturedFrames'])==(2560,1440,1)
                    captures[part]=dict(frameSha256=digest(png),driver=caps['driver_version'],
                        shaderPrograms={name:digest(binary) for name,binary in compiled.items()})
                    if byte is None:
                        assert captures[part]['frameSha256']==observed['disabledFrameSha256']
                    with Image.open(png) as im:frame_rows.append(np.asarray(im.convert('RGB'),dtype=np.uint32)[y,x])
                    continue
                with ExitStack() as program_cleanup:
                    for name,probe_program in compiled.items():
                        target=shaders/name
                        saved=stage/(name+'.original')
                        assert not saved.exists() and digest(target)==fingerprints[name]
                        target.replace(saved)
                        program_cleanup.callback(saved.replace,target)
                        probe_program.replace(target)
                        program_cleanup.callback(target.replace,probe_program)
                    assert len(list(shaders.glob('*.spv')))==895
                    frame=helper['invoke']('intel',args,stage)/'frame_000000.png'
                    caps=read(frame.parent/'gpu_capabilities.json')
                    assert caps['vendor_id']==0x8086 and caps['device_id']==0xa788
                    captures[part]=dict(frameSha256=digest(frame),driver=caps['driver_version'],
                        shaderPrograms={name:digest(shaders/name) for name in compiled})
                    if byte is None:
                        assert captures[part]['frameSha256']==observed['disabledFrameSha256']
                    with Image.open(frame) as im:frame_rows.append(np.asarray(im.convert('RGB'),dtype=np.uint32)[y,x])
            if expression is not None:gather[label]=((frame_rows[0]*256+frame_rows[1])/65535.0).tolist()
    assert {path.name:digest(path) for path in (build/'shaders').glob('*.spv')}==fingerprints
    assert all(np.isfinite(values).all() for values in gather.values())
    write(output/'results.json',dict(status='measured-intel-live',player=digest(player),
        unchangedControl=observed['disabledFrameSha256'],captures=captures,points=points.tolist(),lanes=gather))
    print(json.dumps(gather))


if __name__=='__main__':run()
