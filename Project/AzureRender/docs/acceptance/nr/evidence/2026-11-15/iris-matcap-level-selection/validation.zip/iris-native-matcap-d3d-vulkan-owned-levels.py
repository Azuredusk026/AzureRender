"""Compare the original hardware MatCap selection with exact Player sampling."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import struct

root=Path(__file__).resolve().parent
body=root.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
probe=root.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
native_folder=root/'iris-native-matcap-footprint'
request=read(native_folder/'request.json')
points=list(struct.iter_unpack('<II',Path(request['points']).read_bytes()))
assert len(points)==255
source=read(native_folder/'results.json')
assert source['status']=='qualified'
by_device={}
for subset,info in source['devices'].items():
    assert info['baselineRestored']
    cases=info['cases']
    old=cases['copy']['packed']
    match=[[mip for mip in range(9) if cases[str(mip)]['packed'][index]==value]
           for index,value in enumerate(old)]
    assert all(match)
    by_device[subset]=dict(unique=Counter(str(row[0]) for row in match if len(row)==1),
        ambiguous=sum(len(row)>1 for row in match),rows=match)
nvidia,intel=(by_device[side]['rows'] for side in ('nvidia','intel'))
direct=body/'iris-native-intel-sample-lanes/results.json'
live=read(direct)
assert live['status']=='measured-intel-live'
assert len(live['captures'])==9
assert live['unchangedControl']==read(body/'iris-native-main-frame-uncovered-intel/results.json')['disabledFrameSha256']
texture=root/'trace-iris-matcap-inputs.json'
trace=read(texture)
assert trace['status']=='qualified'
fixture=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d/iris-overlay-geometry-project'
material=read(body/'eye-native-public-nvidia-projected/face-iris-public-main-frame.azurematerial')
surface=material['surface']; eye=surface['materials'][0]['extras']['azureRenderMaterial']['eyeSurface']
slot=surface['textures'][eye['matcapTexture']]['source']
asset=material['textures'][str(slot)]['asset']
dds=fixture/'materials'/(asset+'.dds')
payload=dds.read_bytes()
assert struct.unpack_from('<II',payload,12)==(256,256)
assert struct.unpack_from('<I',payload,28)[0]==9 and struct.unpack_from('<I',payload,128)[0]==99
offset=148
for item in trace['texture']['levels'].values():
    texels=(root/item['path']).read_bytes()
    assert sha256(texels).hexdigest()==item['sha256']
    assert payload[offset:offset+item['bytes']]==texels
    offset+=item['bytes']
assert offset==len(payload)
common=[list(point) for point,a,b in zip(points,nvidia,intel) if a==b==[7]]
assert len(common)==20
inputs={path.name:digest(path) for path in (native_folder/'results.json',native_folder/'request.json',
    direct,texture,root/'iris-native-846-samplers.json')}
data=dict(status='measured-matcap-level-selection',nativeOverOneGate='open',inputs=inputs,points=points,
    identicalNativeAndMaterialMipPayloads=9,materialTextureSha256=digest(dds),
    nativeHardware=by_device,commonLevelSevenPoints=common,
    differingUniqueLod=sum(len(a)==len(b)==1 and a!=b for a,b in zip(nvidia,intel)),witnesses=[])
for i,xy in enumerate(live['points']):
    native_trace,=[trace_row for trace_row in trace['points'] if trace_row['point']==xy]
    index=points.index(tuple(xy))
    u,v,level=live['lanes']['matcapGeometry'][i]
    actual=[*live['lanes']['matcapRgb'][i],live['lanes']['alphaAndLod'][i][1]]
    uv=native_trace['samples']['462']['r6'][:2]
    native_value=native_trace['samples']['463']['r6']
    data['witnesses'].append(dict(point=xy,playerCoordinates=[u,v],nativeCoordinates=uv,
        coordinateMaxError=max(abs(a-b) for a,b in zip((u,v),uv)),
        playerRgba=actual,nvidiaTraceRgba=native_value,playerLevel=round(level*16-1),
        nativeLevels={'nvidia':nvidia[index],'intel':intel[index]}))
first=data['witnesses'][0]
assert first['point']==[1262,257] and first['playerLevel']==3
assert first['nativeLevels']==dict(nvidia=[7],intel=[7]) and first['coordinateMaxError']<1.e-4
assert data['differingUniqueLod']==6
(root/'iris-native-matcap-d3d-vulkan-owned-levels.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
print(json.dumps(data['witnesses']))
