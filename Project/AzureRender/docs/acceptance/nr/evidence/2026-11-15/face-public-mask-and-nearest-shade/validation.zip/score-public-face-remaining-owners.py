"""Partition the production face residual by native draw ownership."""
from hashlib import file_digest
import gzip
import json
from pathlib import Path
import runpy

import cv2
import numpy as np
from PIL import Image


run = Path(__file__).resolve().parent
grid = run.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
body = run.parent / '20261114-125923-body-lit-outline-depth-order-a29b63'
stage = body / 'face-quality-release-isolated-mask'
scoring = runpy.run_path(str(grid / 'static-quality.py'))
read = lambda path: json.loads(path.read_bytes())
shape = (1440, 2560)


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def load_attachment(path):
    with gzip.open(path, 'rb') as stream:
        return np.frombuffer(stream.read(), '<u4').reshape(shape)[::-1]


def signed_stats(image, native, sample):
    signed = image[sample] - native[sample]
    error = np.abs(signed).max(axis=1)
    if not error.size:
        return dict(count=0, overOne=0, overEight=0, peak=0, aboveEight=[])
    y, x = np.where(sample)
    high = np.flatnonzero(error > 8)
    return dict(count=len(error), overOne=int((error > 1).sum()), overEight=len(high),
        peak=int(error.max()), aboveEight=[
            dict(point=[int(x[index]), int(y[index])], error=int(error[index]), signed=signed[index].tolist())
            for index in high[np.argsort(-error[high], kind='stable')]])


def main():
    ownership = scoring['stages'] / 'post-opaque-ownership'
    manifest = read(ownership / 'manifest.json')
    native_path = scoring['reference_path']
    source = read(stage / 'native-combined-summary.json')
    reference = scoring['image'](native_path).astype(np.int16)
    face = np.asarray(Image.open(grid / 'native-face-masks/face.png').convert('L')) > 0
    core = cv2.erode(face.astype('u1'), np.ones((13, 13), 'u1')).astype(bool)
    assert (face.sum(), core.sum()) == (3663, 1176)
    y, x = np.where(face)
    owner_ids = np.zeros(len(x), dtype=np.uint16)
    inputs = {}
    for event in manifest['events']:
        after, before = [ownership / path for path in event['files']]
        samples = [load_attachment(path)[y, x] for path in (after, before)]
        changed = samples[0] != samples[1]
        owner_ids[changed] = event['event']
        if changed.any():
            inputs[str(event['event'])] = dict(changed=int(changed.sum()), after=sha(after), before=sha(before))
    source_events = {int(event): int((owner_ids == event).sum()) for event in np.unique(owner_ids)}
    assert source_events[1230] == 41 and source_events[1358] == 264
    owner = np.full(shape, -1, dtype=np.int16)
    owner[y, x] = owner_ids
    assert not np.any(core & np.isin(owner, [1230, 1358]))
    masks = {f'nativeEvent{event}': owner == event for event in source_events if event}
    masks['opaqueCore'] = core & (owner == 0)
    masks['opaqueEdge'] = face & ~core & (owner == 0)
    coverage = np.zeros(shape, 'u1')
    for mask in masks.values():
        coverage += mask
    assert np.array_equal(coverage, face)

    frames = {}
    devices = {}
    for device in ('nvidia', 'intel'):
        saved = source['devices'][device]
        control = body / f'face-{device}-pair/frames/frame_000000.png'
        candidate = stage / f'public-combined-{device}/frames/frame_000000.png'
        frames[device] = dict(control=sha(control), candidate=sha(candidate))
        assert frames[device] == dict(control=saved['baselineSha256'], candidate=saved['frameSha256'])
        images = [scoring['image'](path).astype(np.int16) for path in (control, candidate)]
        losses = {label: [signed_stats(img, reference, mask) for img in images] for label, mask in masks.items()}
        for stage_index in range(2):
            assert sum(cell[stage_index]['overOne'] for cell in losses.values()) == saved['regions']['face']['overOne'][stage_index]
            assert sum(cell[stage_index]['overEight'] for cell in losses.values()) == saved['regions']['face']['overEight'][stage_index]
        devices[device] = losses
        print(device, {name: [(r['count'], r['overOne'], r['overEight'], r['peak']) for r in cells]
                       for name, cells in losses.items()}, flush=True)
    common_edge = [set(tuple(row['point']) for row in devices[device]['opaqueEdge'][1]['aboveEight'])
                   for device in ('nvidia', 'intel')]
    jointly_owned = common_edge[0] & common_edge[1]
    source_trace = run / 'trace-face-view-mask.json'
    original_trace = read(source_trace)
    covered_trace = {tuple(row['sample']['point']): row['sample']['primitive'] for row in original_trace['points']}
    traced_edges = {point: covered_trace[point] for point in sorted(jointly_owned & covered_trace.keys())}
    same_sign = {}
    for side in devices:
        cells = [row for row in devices[side]['opaqueEdge'][1]['aboveEight'] if tuple(row['point']) in jointly_owned]
        same_sign[side] = sum(all(channel < 0 for channel in row['signed']) for row in cells)
    comparison = dict(commonOpaqueEdgeOverEight=len(jointly_owned), allChannelsBelowReference=same_sign,
        tracedOriginalOpaque804=[dict(point=list(point), primitive=primitive) for point, primitive in traced_edges.items()],
        nativeTraceSha256=sha(source_trace))
    print('common', comparison, flush=True)
    result = dict(status='measured-public-face-owner-residual', reference=sha(native_path),
        manifest=sha(ownership / 'manifest.json'), inputs=inputs, frames=frames, devices=devices, comparison=comparison)
    (run / 'public-face-remaining-owner-residual.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf8')


if __name__ == '__main__':
    main()
