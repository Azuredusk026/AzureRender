"""Exercise the authored face mask and nearest hair shade in one native pose."""
from pathlib import Path
import json
import os
import runpy
import numpy as np

root=Path(__file__).resolve().parent
stage=root/'face-quality-release-isolated-mask'
os.environ['AZURE_NR_FACE_RELEASE_STAGE']=stage.name
harness=runpy.run_path(str(root/'face-quality-production.py'))
catalog=runpy.run_path(str(root/'face-quality-candidate-catalog.py'))
read,write,digest=(harness[k] for k in ('read','write','digest'))
fixture=harness['fixture']
batch_name='face-quality-native-production-combined'
product=stage/'AzurePlayer.exe'
lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lock['state']=='held' and Path(lock['output'])==root
test=read(stage/'test-receipt.json')
assert digest(product)==test['executable']
assert read(stage/'frozen-current-face-and-iris/results.json')['sameDriverStatus']=='passed'


def capture(device):
    older=root/f'face-{device}-pair'
    radial=harness['radial']/f'production-{device}-enabled'
    output=stage/f'public-combined-{device}'
    if (output/'results.json').is_file():
        result=read(output/'results.json')
        assert result['input']['player']==test['executable']
        assert result['frameSha256']==digest(output/'frames/frame_000000.png')
        return result
    if output.is_dir():
        output.rename(output.with_name(output.name+'-interrupted-'+str(len(list(stage.glob(output.name+'-interrupted-*')))+1)))
    output.mkdir()
    ingredients=output/'recipe'
    ingredients.mkdir()
    for name in ('mask','nearest'): (ingredients/name).mkdir()
    nearest_tag,assets=harness['prepare'](older,ingredients/'nearest','nearest')
    mask_tag,mask=harness['prepare'](radial,ingredients/'mask','mask')
    project=read(assets.pop(nearest_tag+'.azureproject'))
    scene=read(assets.pop('scene/'+nearest_tag+'.azurelevel'))
    hero=next(node for node in scene['nodes'] if node['id']=='hero')
    face=read(mask['materials/'+mask_tag+'.azurematerial'])['surface']['materials'][0]
    meta=read(mask['materials/'+mask_tag+'.azurematerial.azmeta'])
    hero['materialSlots']['name:'+face['name']]=meta['id']
    project['startupScene']='stage:/'+batch_name+'.azurelevel'
    project_path=output/(batch_name+'.azureproject')
    scene_path=output/(batch_name+'.azurelevel')
    write(project_path,project)
    write(scene_path,scene)
    assets.update({batch_name+'.azureproject':project_path,'scene/'+batch_name+'.azurelevel':scene_path})
    assets.update({name:path for name,path in mask.items() if name.startswith('materials/')})
    args=read(older/'command.json')
    args[0]=str(product)
    for flag,value in {'--project':fixture/project_path.name,'--capture-dir':output/'frames',
                       '--resource-root':root/'msaa-release','--runtime-report':output/'runtime.json'}.items():
        if flag in args:args[args.index(flag)+1]=str(value)
        else:args.extend((flag,str(value)))
    with harness['mount'](assets):
        frame=harness['helper']['invoke'](device,args,output)/'frame_000000.png'
    qualification=dict(overlayPair=True,player=test['executable'],programs=test['compiledPrograms'],
        fixture={name:digest(p) for name,p in assets.items()})
    harness['measure'](device,frame,qualification)
    saved=read(output/'results.json')
    positions=[row['point'] for row in read(root/'face-multiply-overlap-audit.json')['devices'][device]['details']
               if len(row['triangles'])==2 and row['exponentErrors'][2]<=2]
    assert len(positions)==12
    x,y=np.asarray(positions).T
    scorer=harness['score']
    reference=scorer['image'](scorer['reference_path']).astype(np.int16)
    actual=scorer['image'](frame).astype(np.int16)
    saved['nearestWitnesses']=dict(points=positions,peak=int(np.abs(reference[y,x]-actual[y,x]).max()))
    saved['samePlayerMaskFrame']=read(stage/f'public-mask-{device}/results.json')['frameSha256']
    write(output/'results.json',saved)
    return saved


with catalog['activate'](test['compiledPrograms']) as resources:
    os.environ['PATH']=str(resources)+os.pathsep+os.environ['PATH']
    data={device:capture(device) for device in ('nvidia','intel')}
for receiver in data.values():
    assert receiver['regions']['outsideFace']['changed']==0
    assert receiver['nearestWitnesses']['peak']<=2
    assert all(actual<=maximum for actual,maximum in zip(receiver['samples']['traced']['errors'][1][:2],(4,2)))
    assert receiver['regions']['face']['newOverOne']==0
write(stage/'native-combined-summary.json',dict(status='paired-public-material-controls',overallVisualAcceptance='failed-user-review',devices=data))
