"""Package the linked face mask and hair shade regression."""
from hashlib import file_digest,sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile


run=Path(__file__).resolve().parent
build=run/'face-quality-release-isolated-mask'
read=lambda p:json.loads(p.read_bytes())
receipt=read(build/'test-receipt.json')
combined=read(build/'native-combined-summary.json')
assert combined['status']=='paired-public-material-controls'
programs=receipt['compiledPrograms']
assert len(programs)==26
assert receipt['executable']=='54e66fd9a0565915d1883dcb5e2fef6c5f773dcc5c5dc65b0be7f8008933c8a6'
members=['face-quality-native-production-combined.py','archive-face-quality-native-combined.py',
    'face-quality-release-isolated-mask/test-receipt.json','face-quality-release-isolated-mask/native-combined-summary.json',
    'nr-face-combined-production-mask-and-nearest-shade-queue.log']
devices={}
for tag,one,eight,vendor in [('nvidia',[366,355],[64,50],0x10de),('intel',[376,366],[66,52],0x8086)]:
    directory=build/f'public-combined-{tag}'
    row=read(directory/'results.json')
    assert row==combined['devices'][tag]
    assert row['input']['player']==receipt['executable'] and row['input']['programs']==programs
    with (directory/'frames/frame_000000.png').open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==row['frameSha256']
    assert read(directory/'frames/gpu_capabilities.json')['vendor_id']==vendor
    editor=read(directory/'frames/capture_manifest.json')
    assert editor['qaCamera']=='scene' and editor['qaLight']=='scene'
    face=row['regions']['face']
    assert face['count']==3663 and face['changed']==34 and face['newOverOne']==0
    assert face['overOne']==one and face['overEight']==eight
    for scope in ('iris','outsideFace','faceCore'):
        assert row['regions'][scope]['changed']==row['regions'][scope]['newOverOne']==0
    assert row['samples']['traced']['errors'][1][:2]==[4,2]
    assert row['nearestWitnesses']['peak']<=2 and len(row['nearestWitnesses']['points'])==12
    devices[tag]=dict(input=row['input'],frame=row['frameSha256'],regions=row['regions'],
                      mouth=[row['samples']['traced']['errors'][i][:2] for i in (0,1)],
                      nearestWitnesses=row['nearestWitnesses'])
    members.extend(str((directory/name).relative_to(run)).replace('\\','/') for name in
        ('command.json','results.json','runtime.json','player.log','frames/capture_manifest.json','frames/gpu_capabilities.json'))
output=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/face-public-mask-and-nearest-shade'
output.mkdir(parents=True,exist_ok=True)
recipe=output/'validation.zip'
support=run.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e'
ownership_files=('score-public-face-remaining-owners.py','public-face-remaining-owner-residual.json',
                 'trace-face-view-mask.json')
ownership=read(support/ownership_files[1])
assert ownership['status']=='measured-public-face-owner-residual'
summary=ownership['comparison']
assert summary['commonOpaqueEdgeOverEight']==49
assert summary['allChannelsBelowReference']==dict(nvidia=49,intel=49)
assert len(summary['tracedOriginalOpaque804'])==10
assert summary['nativeTraceSha256']==sha256((support/ownership_files[2]).read_bytes()).hexdigest()
for device in devices:
    assert ownership['frames'][device]['candidate']==devices[device]['frame']
    assert ownership['frames'][device]['control']==combined['devices'][device]['baselineSha256']
    assert ownership['devices'][device]['opaqueEdge'][1]['overEight']==49
    shade=[entry['overEight'] for entry in ownership['devices'][device]['nativeEvent1358']]
    assert shade=={'nvidia':[13,1],'intel':[14,2]}[device]
member_paths={name:run/name for name in members}
member_paths.update({name:support/name for name in ownership_files})
with ZipFile(recipe,'w',ZIP_DEFLATED) as archive:
    for name,path in member_paths.items():archive.write(path,name)
with ZipFile(recipe) as archive:
    assert archive.testzip() is None
    manifest={name:sha256(archive.read(name)).hexdigest() for name in member_paths}
assert manifest=={name:sha256(path.read_bytes()).hexdigest() for name,path in member_paths.items()}
proof=dict(status='qualified-linked-face-mask-and-nearest-hair-shade',overall='failed-user-review',
    player=receipt['executable'],programs=programs,devices=devices,nativeOwnerResidual=summary,
    archive=dict(sha256=sha256(recipe.read_bytes()).hexdigest(),members=manifest))
(output/'results.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print([(tag,case['regions']['face']['overOne'],case['regions']['face']['overEight']) for tag,case in devices.items()],flush=True)

