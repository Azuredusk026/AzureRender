from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile

run=Path(__file__).resolve().parent
path=run/'frozen-cross-driver-pixel-locations.json'
result=json.loads(path.read_bytes())
assert result['status']=='measured-original-cross-driver-frozen-difference'
assert result['testStatus']=='failed'
assert result['devices']==['592.82','595.79']
rows=result['frameEvidence']
assert [r['differing'] for r in rows]==[228,330,397,421]
assert [len(r['overOneDetails']) for r in rows]==[0,3,4,4]
primary=lambda r:next(x['pixels'] for x in r['grid128'] if x['tile']==[17,1])
assert [primary(r) for r in rows]==[203,200,203,204]
out=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/frozen-cross-driver-spatial'
out.mkdir(parents=True,exist_ok=True)
package=out/'validation.zip'
sources=[path.name,'frozen-cross-driver-pixel-locations.py','package-frozen-cross-driver-spatial.py']
with ZipFile(package,'w',ZIP_DEFLATED) as archive:
    for name in sources:archive.write(run/name,name)
with ZipFile(package) as archive:
    assert archive.testzip() is None
    checks={name:sha256(archive.read(name)).hexdigest() for name in sources}
assert checks=={name:sha256((run/name).read_bytes()).hexdigest() for name in sources}
proof=dict(status=result['status'],testStatus='failed',drivers=result['devices'],
   differing=[r['differing'] for r in rows],overOne=[len(r['overOneDetails']) for r in rows],
   primarySceneCeilingTile=dict(pixelBounds=[2176,128,2304,256],differing=[primary(r) for r in rows]),
   archive=dict(sha256=sha256(package.read_bytes()).hexdigest(),members=checks))
(out/'results.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(proof['primarySceneCeilingTile'],flush=True)

