"""Measure spatial and signed channel differences between the frozen driver captures."""
from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path

import numpy as np
from PIL import Image


run=Path(__file__).resolve().parent
stage=run.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
actual=stage/'face-quality-release-isolated-mask/frozen-current-face-and-iris'
native=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames')
receipt=json.loads((actual/'results.json').read_bytes())
assert receipt['sameDriverStatus']=='passed' and receipt['originalFrozenStatus']=='failed'
def verify(path,expected):
    with path.open('rb') as f:
        assert file_digest(f,'sha256').hexdigest()==expected
    with Image.open(path) as image:
        return np.asarray(image.convert('RGB'),dtype='i2')


output=[]
difference_hits={}
for frame in receipt['frames']:
    label=frame['frame']
    legacy=verify(native/label,frame['frozenExpectedSha256'])
    current=verify(actual/'frames'/label,frame['sha256'])
    delta=current-legacy
    error=np.abs(delta).max(2)
    y,x=np.where(error>0)
    assert len(x)==frame['frozenDifferingPixels'] and int(error.max())==frame['frozenPeak']
    assert int((error>1).sum())==frame['frozenOverOne']
    entries=[]
    for yy,xx in zip(y,x):
        difference_hits[(xx,yy)]=difference_hits.get((xx,yy),0)+1
        if error[yy,xx]>1:
            crop=np.s_[max(0,yy-1):yy+2,max(0,xx-1):xx+2]
            entries.append(dict(point=[int(xx),int(yy)],changedFrom=legacy[yy,xx].tolist(),
                changedTo=current[yy,xx].tolist(),difference=delta[yy,xx].tolist(),
                historyNeighborhood=legacy[crop].tolist(),currentNeighborhood=current[crop].tolist()))
    region_counts=Counter((int(xx)//128,int(yy)//128) for xx,yy in zip(x,y))
    signed_counts=Counter(tuple(map(int,row)) for row in delta[y,x])
    row=dict(name=label,differing=len(x),bounds=[int(x.min()),int(y.min()),int(x.max()),int(y.max())],
        grid128=[dict(tile=list(cell),pixels=count) for cell,count in region_counts.most_common()],
        signedRgb=[dict(value=list(rgb),pixels=count) for rgb,count in signed_counts.most_common()],
        overOneDetails=entries)
    print(label,len(x),row['bounds'],region_counts.most_common(6),signed_counts.most_common(6),
        [(entry['point'],entry['difference']) for entry in entries],flush=True)
    output.append(row)
result=dict(status='measured-original-cross-driver-frozen-difference',devices=[receipt['frozenDriver'],receipt['driver']],
    frameEvidence=output,commonCoordinates=Counter(difference_hits.values()),testStatus='failed')
(run/'frozen-cross-driver-pixel-locations.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')

