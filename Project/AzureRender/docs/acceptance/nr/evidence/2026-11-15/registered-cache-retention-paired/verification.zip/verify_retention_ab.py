"""Verify paired cache-retention performance and preserve its raw observations."""
from hashlib import file_digest, sha256
import argparse
import json
from pathlib import Path
import re
import sqlite3
import sys
from zipfile import ZIP_DEFLATED, ZipFile


run = Path(__file__).resolve().parent
root = run.parents[2]
sys.path.insert(0, str(root / "tools"))
from performance_budget import validate_round, working_set_growth


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def verify_case(path, observations, expected_digest, editor):
    memory = read(path.with_suffix(".memory.json"))
    timing = read(path.with_suffix(".json"))
    cache_log = path.with_suffix(".stderr.log").read_text(encoding="utf-8").splitlines()
    [cache] = [line for line in cache_log if "Pipeline cache saved:" in line]
    assert cache in observations["cacheLog"]
    assert observations["playerSha256"] == expected_digest
    assert observations["workingSetSamplesBytes"] == [row["working"] for row in memory]
    assert observations["peakWorkingSetBytes"] == max(row["peak"] for row in memory)
    assert len(timing["cpuFrame"]["workSamplesMs"]) == 2100
    assert observations["stableWorkingSetGrowth"] == working_set_growth(observations["workingSetSamplesBytes"])
    assert observations["budgetFailures"] == validate_round(observations, editor=editor)
    assert observations["passed"] == (not observations["budgetFailures"])
    assert all(row["driver"] == "595.79" for row in observations["environment"]["runObservations"])
    match = re.search(r"bytes=(\d+), state=(\w+), requests=(\d+), hits=(\d+), feedback=(\d+)$", cache)
    assert match, cache
    size, state, requests, hits, feedback = match.groups()
    result = {key: observations[key] for key in ("warmup", "samples", "gpu", "cpu", "physics",
        "stableWorkingSetGrowth", "peakWorkingSetBytes", "budgetFailures", "passed", "playerSha256")}
    result["cache"] = dict(state=state, writtenBytes=int(size), requests=int(requests),
                           hits=int(hits), validFeedback=int(feedback))
    return result


def verify():
    candidate = read(run / "release/build-receipt.json")
    results = read(run / "working-set/results.json")
    assert results.keys() == {"standard", "editor"}
    assert b"C2039" in (run / "release/test-store-red.log").read_bytes()
    for name, expected in candidate["outputs"].items():
        assert digest(run / "release" / (name + ".exe")) == expected
    restored_power = read(run / "power-policy-restored.json")
    initial_power = read(run / "power-policy-before.json")
    assert initial_power["original"] == restored_power["active"]
    assert initial_power["values"] == restored_power["values"]
    restored_fan = read(run / "fan-restored.json")
    assert restored_fan["balanced"] and restored_fan["automatic"] and not restored_fan["maximum"]
    assert read(run / "fan-ready.json")["rpm"] >= 5600
    with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro", uri=True) as connection:
        db = connection.execute("SELECT id,task,state,exit_code FROM jobs WHERE output=? AND task IN (?,?) ORDER BY id",
            (str(run), "cache-retention-working-set-isolated-release", "cache-retention-original-workload-ab"))
        build, measurement = db.fetchall()
    assert build[2:] == ("succeeded", 0)
    assert measurement[2] in ("succeeded", "failed")
    evidence = {}
    for fixture, cases in results.items():
        is_editor = fixture == "editor"
        binary = "AzureRender" if is_editor else "AzurePlayer"
        [reference] = [value for path, value in candidate["original"].items() if Path(path).stem == binary]
        assert cases.keys() == {"reference", "candidate"}
        evidence[fixture] = {}
        for role, expected in (("reference", reference), ("candidate", candidate["outputs"][binary])):
            path = run / "working-set" / (role + "-" + fixture)
            evidence[fixture][role] = verify_case(path, cases[role], expected, is_editor)
    paired_pass = all(row["candidate"]["passed"] and row["candidate"]["cache"]["state"] == "retained"
                      and row["reference"]["cache"]["state"] == "stored"
                      and any(failure.startswith("stableWorkingSetGrowth:") for failure in row["reference"]["budgetFailures"])
                      for row in evidence.values())
    assert paired_pass == (measurement[3] == 0)
    return dict(passed=paired_pass, driver="595.79", loads=evidence, dispatch=[build, measurement],
                powerRestored=restored_power, fanRestored=restored_fan)


def archive(output, result):
    members = ["cache-retention.patch", "build_cache_retention_candidate.py", "verify_retention_ab.py",
               "prepare_max_fan_replay.py", "release/build-receipt.json", "measurement.log", "measurement.stderr.log"]
    members += [p.name for p in run.glob("power-policy-*.json")]
    members += [p.name for p in run.glob("fan-*.json")]
    members += [p.relative_to(run).as_posix() for p in (run / "release").glob("*.log")]
    members += [p.relative_to(run).as_posix() for p in (run / "working-set").iterdir() if p.is_file()]
    expected = {name: digest(run / name) for name in members}
    output.mkdir()
    archive = output / "verification.zip"
    with ZipFile(archive, "x", compression=ZIP_DEFLATED, compresslevel=6) as data:
        for name in sorted(expected):
            data.write(run / name, name)
    with ZipFile(archive) as data:
        assert set(data.namelist()) == expected.keys() and data.testzip() is None
        assert all(sha256(data.read(name)).hexdigest() == value for name, value in expected.items())
    result["archive"] = dict(members=expected, sha256=digest(archive))
    (output / "results.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--archive", type=Path)
    args = parser.parse_args()
    result = verify()
    if args.archive:
        archive(args.archive, result)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["passed"] else 1)
