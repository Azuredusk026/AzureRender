"""Compare identical formal fixtures on the current and cache-retention hosts."""
from datetime import datetime, timezone
from hashlib import file_digest
import json
import os
from pathlib import Path
import subprocess
import sys


out = Path(__file__).resolve().parent
root = out.parents[2]
build = root/'build/ninja-msvc-release'
matrix = out.parent/'20261115-064800-nr-material-cache-regression-4d7a62'
sys.path.insert(0,str(root/'tools'))
from run_playable_performance import fixture, run


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open('rb') as file:
        return file_digest(file,'sha256').hexdigest()


def main():
    assert sys.argv[1:] == ['--measure-after-confirmed-max-fan']
    fan = read(out/'fan-ready.json')
    policy = read(out/'power-policy-ready.json')
    timestamp = datetime.fromisoformat(fan['observedAt'])
    assert 0 <= (datetime.now(timezone.utc)-timestamp).total_seconds() < 120
    assert fan['selected']=='maximum' and fan['original']=='automatic' and fan['powerMode']=='balanced' and fan['rpm']>=5600
    assert policy['values']=={key:{'ac':50,'dc':50} for key in ('PERFEPP','PERFEPP1')}
    registered = read(matrix/'release-products.json')['products']
    candidate = read(out/'release/build-receipt.json')['outputs']
    env = dict(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',AZURERENDER_RESOURCE_ROOT=str(build), DOTNET_ROOT='D:/Tools/dotnet9')
    env['PATH']=os.pathsep.join(map(str,(build,build/'vcpkg_installed/x64-windows/bin',os.environ['PATH'])))
    for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES','VK_LAYER_VALIDATE_SYNC','VK_LOADER_DEBUG'):
        os.environ.pop(key,None)
    os.environ.update(env)
    driver = subprocess.check_output(['nvidia-smi.exe','--query-gpu=driver_version','--format=csv,noheader'],text=True).strip()
    assert driver=='595.79'
    observations = out/'working-set'
    observations.mkdir()
    results = {}
    for load in ('standard','editor'):
        project = observations/load
        fixture(project)
        authored = {p.relative_to(project):digest(p) for p in project.rglob('*') if p.is_file() and '.azure' not in p.parts}
        executable = 'AzureRender' if load=='editor' else 'AzurePlayer'
        scopes = {'reference':(build/(executable+'.exe'),registered[str(build/(executable+'.exe'))]),
                  'candidate':(out/'release'/(executable+'.exe'),candidate[executable])}
        for role,(binary,identity) in scopes.items():
            assert digest(binary)==identity
            os.environ['AZURERENDER_EDITOR_CONFIG']=str(observations/(role+'-'+load+'-config'))
            base = observations/(role+'-'+load)
            observed = run(binary,project/'project.azureproject',base,editor=load=='editor')
            observed['cacheLog'] = [line for line in base.with_suffix('.stderr.log').read_text(encoding='utf-8').splitlines()
                                     if 'Pipeline cache loaded' in line or 'Pipeline cache saved' in line]
            observed['playerSha256']=identity
            results.setdefault(load,{})[role]=observed
            (observations/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
            assert all(digest(project/path)==value for path,value in authored.items())
    for cases in results.values():
        assert any(failure.startswith('stableWorkingSetGrowth:') for failure in cases['reference']['budgetFailures'])
        assert any('state=stored' in line for line in cases['reference']['cacheLog'])
        assert not cases['candidate']['budgetFailures'], cases['candidate']['budgetFailures']
        assert any('state=retained' in line for line in cases['candidate']['cacheLog'])
    return 0


if __name__=='__main__':
    raise SystemExit(main())
