"""Build the pipeline-cache shutdown correction without modifying the registered builds."""
import difflib
import json
import os
from pathlib import Path
import re
import subprocess
import sys


task = Path(__file__).resolve().parent
root = task.parents[2]
source = task/'source'
origin = task.parent/'20261114-173220-nr-shader-host-compiler-concurrency-d140b8'
matrix = task.parent/'20261115-064800-nr-material-cache-regression-4d7a62'
sys.path.insert(0,str(origin))
from isolated_link import catalog, hash_file, quoted, replace_one


def overlay(name, changes):
    original = (root/name).read_text(encoding='utf-8')
    updated = original
    for before, after in changes:
        updated = replace_one(updated,before,after)
    edited = source/name
    edited.parent.mkdir(parents=True,exist_ok=True)
    edited.write_text(updated,encoding='utf-8')
    with (task/'cache-retention.patch').open('a',encoding='utf-8',newline='') as patch:
        path = 'Project/AzureRender/'+name
        patch.writelines(difflib.unified_diff(original.splitlines(True),updated.splitlines(True),'a/'+path,'b/'+path))


def test_source():
    anchor = '    require(first.save(data),"First cache must persist");require(first.load()==data,"Stored cache must load its original payload");'
    cases = '''
    PipelineCacheStore retained(root/"retained",id,limits);
    require(!retained.retain(data.size()),"A missing cache must request a flush");
    require(retained.save(data),"Retention fixture must start with a written cache");
    const auto older = std::filesystem::file_time_type::clock::now()-std::chrono::seconds(60);
    std::filesystem::last_write_time(retained.file(),older);
    require(!retained.retain(data.size()+1),"A different serialized size must request a flush");
    require(std::filesystem::last_write_time(retained.file())==older,"Rejection must preserve the cache timestamp");
    require(retained.retain(data.size()),"A matching cache must remain available");
    require(std::filesystem::last_write_time(retained.file())>older&&retained.load()==data,"Retention must refresh the file and preserve the payload");
    auto wrongEnvelope = *encoded;
    wrongEnvelope[0] ^= 1;
    write(retained.file(),wrongEnvelope);
    require(!retained.retain(data.size()),"A replaced envelope must request a flush");'''
    overlay('tests/PipelineCacheStoreTests.cpp',[(anchor,anchor+cases)])


def implementation():
    header = '    bool save(const PipelineCacheBytes&) const noexcept;'
    overlay('src/rhi/PipelineCacheStore.hpp',[(header,header+'\n    bool retain(std::uint64_t payloadBytes) const noexcept;')])
    retain_store = '''bool PipelineCacheStore::retain(std::uint64_t payloadBytes) const noexcept {
    try {
        namespace fs = std::filesystem;
        if (directory_.empty() || payloadBytes < 32 || limits_.maximumFileBytes < headerBytes
            || payloadBytes > limits_.maximumFileBytes - headerBytes)
            return false;
        const auto target = file();
        const auto lockPath = directory_ / ".pool.lock";
        if (!safePath(target) || !safePath(lockPath))
            return false;
        PoolLock lock(lockPath);
        if (!lock || !fs::is_regular_file(target) || fs::file_size(target) != headerBytes + payloadBytes)
            return false;
        PipelineCacheBytes header(headerBytes);
        {
            std::ifstream input(target, std::ios::binary);
            if (!input.read(reinterpret_cast<char*>(header.data()), static_cast<std::streamsize>(header.size())))
                return false;
        }
        if (!std::equal(magic.begin(), magic.end(), header.begin()) || get(header, 8, 4) != identity_.vendor
            || get(header, 12, 4) != identity_.device || get(header, 16, 4) != identity_.driver
            || !std::equal(identity_.uuid.begin(), identity_.uuid.end(), header.begin() + 20)
            || get(header, 36, 8) != payloadBytes)
            return false;
        fs::last_write_time(target, fs::file_time_type::clock::now());
        return true;
    } catch (...) {
        return false;
    }
}
'''
    anchor = 'bool PipelineCacheStore::save(const PipelineCacheBytes& payload)const noexcept{try{'
    overlay('src/rhi/PipelineCacheStore.cpp',[(anchor,retain_store+anchor)])
    header = '    bool flush() noexcept;'
    overlay('src/rhi/VulkanPipelineCache.hpp',[(header,'    bool retainLoadedCache() noexcept;\n'+header)])
    retain_driver = '''bool VulkanPipelineCache::retainLoadedCache() noexcept {
    if (!cache_ || statistics_.loadedBytes == 0)
        return false;
    std::size_t currentSize = 0;
    if (vkGetPipelineCacheData(device_, cache_, &currentSize, nullptr) != VK_SUCCESS
        || currentSize != statistics_.loadedBytes || !store_.retain(currentSize))
        return false;
    statistics_.writeState = "retained";
    return true;
}
'''
    anchor = 'bool VulkanPipelineCache::flush()noexcept{try{'
    overlay('src/rhi/VulkanPipelineCache.cpp',[(anchor,retain_driver+anchor)])
    anchor = '        if(pipelineCache_){\n            pipelineCache_->flush();'
    replacement = '''        if(pipelineCache_){
            const bool allCacheHits = cacheUsage.requests != 0 && cacheUsage.feedback == cacheUsage.requests
                && cacheUsage.hits == cacheUsage.requests;
            if (!allCacheHits || !pipelineCache_->retainLoadedCache())
                pipelineCache_->flush();'''
    overlay('src/app/AzureRenderApp.cpp',[(anchor,replacement)])


class IsolatedBuild:
    def __init__(self, config):
        self.config = config
        self.build = root/'build'/('ninja-msvc-'+config.lower())
        self.out = task/config.lower()
        self.out.mkdir()
        self.commands = []

    def run(self, name, command, fail=False):
        self.commands.append(dict(name=name,command=command))
        path = self.out/(name+'.log')
        with path.open('xb') as log:
            result = subprocess.run(command,cwd=self.build,stdout=log,stderr=subprocess.STDOUT,timeout=480)
        if fail:
            diagnostic = path.read_text(encoding='utf-8',errors='replace')
            assert result.returncode and 'C2039' in diagnostic and 'retain' in diagnostic, diagnostic
        else:
            assert result.returncode==0,path

    def compile(self, target, filename, tag, fail=False):
        key = ('CMakeFiles/'+target+'.dir/'+filename+'.obj').replace('/','\\')
        obj = self.out/(tag+'.obj')
        original = root/filename
        line = replace_one(catalog(self.build,'commands','-s',key),str(original),str(source/filename))
        line = replace_one(line,'/Fo'+key,'/Fo'+quoted(obj))
        line,count = re.subn(r'/Fd[^ ]+',lambda _: '/Fd'+quoted(self.out/(tag+'.pdb')),line)
        assert count==1
        line = replace_one(line,' /TP ',' /TP /I'+quoted(source/'src')+' ')
        line += ' /I'+quoted(original.parent)
        self.run(tag,line,fail=fail)
        return key,obj

    def link(self, target, replacement, *additional):
        [row] = json.loads(catalog(self.build,'compdb','-x',f'CXX_EXECUTABLE_LINKER__{target}_{self.config}'))
        line=row['command']
        start=line.index('&& ')+3
        line=line[start:line.index(' &&',start)]
        intdir=self.out/(target+'-link')
        intdir.mkdir()
        line=replace_one(line,' --intdir=CMakeFiles\\'+target+'.dir',' --intdir='+quoted(intdir))
        if replacement:
            line=replace_one(line,replacement[0],quoted(replacement[1]))
        line=replace_one(line,' /out:', ' '+' '.join(map(quoted,additional))+' /out:')
        if self.config=='Debug':
            line=replace_one(line,' /INCREMENTAL ',' /INCREMENTAL:NO ')
        line=re.sub(r'(?i)(?<![\w:])/debug(?=\s|$)','/DEBUG:NONE',line)
        for flag,ext in (('/out:','.exe'),('/implib:','.lib'),('/pdb:','.pdb')):
            line=replace_one(line,flag+target+ext,flag+quoted(self.out/(target+ext)))
        self.run('link-'+target,line)

    def build_candidate(self):
        targets=('AzurePipelineCacheStoreTests','AzureRender','AzurePlayer')
        frozen={self.build/(name+'.exe'):hash_file(self.build/(name+'.exe')) for name in targets}
        receipt=json.loads((matrix/(self.config.lower()+'-products.json')).read_bytes())
        assert all(receipt['products'][str(path)]==sha for path,sha in frozen.items())
        tests='tests/PipelineCacheStoreTests.cpp'
        store=self.compile('AzureRenderCore','src/rhi/PipelineCacheStore.cpp','store')[1]
        backend=self.compile('AzureRenderCore','src/rhi/VulkanPipelineCache.cpp','cache')[1]
        self.link(targets[0],self.compile(targets[0],tests,'test-store-green'),store)
        output = self.out/'test-artifacts/pipeline-cache-store'
        self.run('run-store-tests',[str(self.out/(targets[0]+'.exe')),str(output)])
        for name in targets[1:]:
            _,module=self.compile(name+'Host','src/app/AzureRenderApp.cpp','app-'+name)
            self.link(name,None,module,store,backend)
        assert all(hash_file(path)==sha for path,sha in frozen.items())
        data=dict(configuration=self.config, original={str(path):sha for path,sha in frozen.items()},
                  outputs={name:hash_file(self.out/(name+'.exe')) for name in targets}, commands=self.commands)
        (self.out/'build-receipt.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    if os.environ.get('VSCMD_ARG_TGT_ARCH')!='x64':
        raise SystemExit(subprocess.call([str(root/'tools/msvc_env.bat'),sys.executable,'-B','-X','utf8',__file__,*sys.argv[1:]]))
    assert sys.argv[1:] in (['Release'],['Release','Debug'])
    release=IsolatedBuild('Release')
    test_source()
    release.compile('AzurePipelineCacheStoreTests','tests/PipelineCacheStoreTests.cpp','test-store-red',fail=True)
    implementation()
    release.build_candidate()
    if 'Debug' in sys.argv[1:]:
        IsolatedBuild('Debug').build_candidate()
