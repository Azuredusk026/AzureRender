"""Archive three unleased, expired shader catalogs and return their reservations to the managed pool."""
import json
from pathlib import Path
import sqlite3
import sys
import time


run = Path(__file__).resolve().parent
root = run.parents[2]
build = root / "build"
sys.path.insert(0, str(root / "tools"))
from artifact_cleanup import remove_artifact
from artifact_maintenance import (database, digest, expected_inventory, git_state, inventory,
    lifecycle, maintenance_lock, metadata, pack, protected_names, real_path, reservation, rows,
    run_path, save, tracked_paths)


catalogs = (
    "20261110-224505-shader-catalog-b23715",
    "20261110-171927-shader-catalog-acef63",
    "20261110-181220-shader-catalog-dbf230",
)


def read(path):
    return json.loads(path.read_bytes())


def main():
    guard = read(Path("D:/Projects/FYP-coordination/resources/current.json"))
    assert guard["owner"] == "01a1d0a8-a74c-7cc0-85e8-540a6653098a" and guard["state"] == "held"
    assert guard["task"] == "archive-expired-catalogs-for-remaining-matrix" and Path(guard["output"]).resolve() == run
    assert (run / "registered-pool-capacity-recovery.json").is_file()
    before = git_state(root)
    tracked = tracked_paths(root)
    report = []
    with maintenance_lock(build):
        with database(build) as db:
            prior = rows(db)
        for name in catalogs:
            record = prior[name]
            path = run_path(build, name)
            assert path.resolve() == path and path.parent == build / "runs"
            assert record["status"] == "closed" and not record.get("processPid") and name not in protected_names(prior)
            assert not any(p == path or path in p.parents for p in tracked)
            marker = path / ".finished"
            retain = record["retentionDays"] * 86400
            assert marker.is_file() and not (path / ".keep").exists()
            assert time.time() - max(marker.stat().st_mtime, record["closed"]) >= retain
            evidence = real_path(record["evidence"])
            assert evidence.parent == metadata(build) / "evidence" and digest(evidence) == record["evidenceSha256"]
            with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro", uri=True) as dispatch:
                assert not dispatch.execute("SELECT id FROM jobs WHERE output=? AND state IN ('pending','running')",
                                            (str(path),)).fetchall()
            pack(build, name, record, deadline=time.monotonic() + 260)
            expected = expected_inventory(record)
            assert inventory(path) == expected and git_state(root) == before
            with database(build, True) as db:
                db.execute("BEGIN IMMEDIATE")
                snapshot = rows(db)
                latest = snapshot[name]
                assert lifecycle(latest) == lifecycle(record) and name not in protected_names(snapshot)
                assert latest["archive"] == record["archive"] and latest["archiveSha256"] == record["archiveSha256"]
                assert digest(Path(latest["archive"])) == latest["archiveSha256"]
                assert time.time() - marker.stat().st_mtime >= retain and not (path / ".keep").exists()
                assert path.resolve() == path and path.parent == build / "runs"
                remove_artifact(build, path, tracked, apply=True)
                latest.update(status="released", reservedBytes=0, released=time.time(), retainRecovery=True)
                save(db, name, latest)
            assert not path.exists()
            report.append(dict(name=name, bytes=expected["bytes"], archive=latest["archive"],
                               archiveSha256=latest["archiveSha256"], files=len(expected["files"])))
            print(json.dumps(report[-1]), flush=True)
        with database(build) as db:
            remaining = reservation(rows(db))
    assert git_state(root) == before
    out = dict(archived=report, recoveredBytes=sum(item["bytes"] for item in report), reservedAfter=remaining)
    with (run / "registered-pool-next-capacity-recovery.json").open("x", encoding="utf-8") as stream:
        json.dump(out, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
