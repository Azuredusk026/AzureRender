from pathlib import Path
from hashlib import sha256
import json,subprocess
r=Path(__file__).resolve().parent
root=Path.cwd().resolve()
parent=r.parent
r.mkdir(exist_ok=True)
reference=parent/'reference/mesh.frag'
text=reference.read_text(encoding='utf-8')
base='''#if defined(AZURE_PROBE_FIELD)
#if defined(AZURE_EXTENDED_MATERIAL_LIGHTING)
    vec3 reflectionDiffuseIncident=textureLod(AZ_TEX_ENVIRONMENT,directionToEquirectangular(indirectDiffuseNormal),float(textureQueryLevels(AZ_TEX_ENVIRONMENT)-1)).rgb*(globalDiffuseEnvironment?globalEnvironmentIntensity:camera.clusterLighting.y);
#else
    vec3 reflectionDiffuseIncident=textureLod(AZ_TEX_ENVIRONMENT,directionToEquirectangular(indirectDiffuseNormal),float(textureQueryLevels(AZ_TEX_ENVIRONMENT)-1)).rgb*camera.clusterLighting.y;
#endif
#endif'''
variant='''#if defined(AZURE_PROBE_FIELD)
#if defined(AZURE_EXTENDED_MATERIAL_LIGHTING)
    bool useProbeFieldDiffuse=camera.probeParameters.x>.5&&!globalReflectionEnvironment&&reflectionLayerPlusOne==0U;
#else
    bool useProbeFieldDiffuse=camera.probeParameters.x>.5;
#endif
    vec3 reflectionDiffuseIncident=vec3(0);
    if(useProbeFieldDiffuse){
#if defined(AZURE_EXTENDED_MATERIAL_LIGHTING)
        reflectionDiffuseIncident=textureLod(AZ_TEX_ENVIRONMENT,directionToEquirectangular(indirectDiffuseNormal),float(textureQueryLevels(AZ_TEX_ENVIRONMENT)-1)).rgb*(globalDiffuseEnvironment?globalEnvironmentIntensity:camera.clusterLighting.y);
#else
        reflectionDiffuseIncident=textureLod(AZ_TEX_ENVIRONMENT,directionToEquirectangular(indirectDiffuseNormal),float(textureQueryLevels(AZ_TEX_ENVIRONMENT)-1)).rgb*camera.clusterLighting.y;
#endif
    }
#endif'''
assert text.count(base)==1
text=text.replace(base,variant)
for a,b in (
 ('        reflectionDiffuseIncident=mix(reflectionDiffuseIncident,volume.rgb,volume.w);','        if(useProbeFieldDiffuse)reflectionDiffuseIncident=mix(reflectionDiffuseIncident,volume.rgb,volume.w);'),
 ('    if(globalDiffuseEnvironment&&!globalReflectionEnvironment){','    if(globalDiffuseEnvironment&&useProbeFieldDiffuse){')):
 count=text.count(a)
 assert count in (1,2)
 if count==2: text=text.replace(a,b,1)
 else: text=text.replace(a,b)
assert text.count('if(useProbeFieldDiffuse)')==2
candidate=r/'mesh.frag';candidate.write_text(text,encoding='utf-8')
base_manifest=json.loads((parent/'prepare-results.json').read_bytes())
historical=r.parents[1]/'20261110-212504-material-view-determinism-4162f2'
manifest=json.loads((historical/'unroll-build.json').read_bytes())
headers=r.parents[1]/'20261110-215730-shader-catalog-c25e8a/work/1/source'
assert headers.is_dir()
for m in base_manifest['mapped']:
 role=m['role']; command=next(x['command'] for x in manifest['commands'] if x['output']==m['program'])
 cmd=[command[0],*(x for x in command if x.startswith(('-D','--target-env'))),'-I'+str(headers),'-I'+str(root/'shaders')]
 for label,src in [('base',reference),('candidate',candidate)]:
  output=r/(role+'-'+label+'.spv')
  p=subprocess.run([*cmd,str(src),'-o',str(output)],capture_output=True)
  (r/(role+'-'+label+'.log')).write_bytes(p.stdout+p.stderr)
  p.check_returncode()
  subprocess.run([str(Path(command[0]).with_name('spirv-val.exe')),'--target-env','vulkan1.0',str(output)],check=True)
  h=sha256(output.read_bytes()).hexdigest(); key='baselineSha256' if label=='base' else 'candidateSha256'
  if label=='base':assert h==m[key]==sha256((parent/(role+'-base.spv')).read_bytes()).hexdigest(),h
  else:assert h!=m['baselineSha256']; m[key]=h
# Falsify each form of the predicate when any required factor is removed.
from itertools import product
rows=[]
for ext, probe, global_ref, fixed_layer in product((False,True),repeat=4):
 old_use=probe and (not ext or (not global_ref and not fixed_layer))
 available=(probe and not global_ref and not fixed_layer) if ext else probe
 assert old_use==available
 rows.append(dict(extended=ext,probe=probe,globalReflection=global_ref,explicitLayer=fixed_layer,required=old_use))
assert any(v['required'] for v in rows) and any(not v['required'] for v in rows)
base_manifest.update(variation='probe field diffuse on use',predicateRows=rows)
(r/'prepare-results.json').write_text(json.dumps(base_manifest,indent=2)+'\n',encoding='utf-8')
print([(m['role'],m['baselineSha256'][:12],m['candidateSha256'][:12]) for m in base_manifest['mapped']])
