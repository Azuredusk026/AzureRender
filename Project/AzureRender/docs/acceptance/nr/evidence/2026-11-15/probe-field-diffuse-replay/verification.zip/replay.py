from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import sys
import traceback
import renderdoc as rd

r=Path(__file__).resolve().parent
c=r.parents[1]/'20261111-001050-quad-feature-device-capture-4798d1'
capture=json.loads((c/'state.json').read_bytes())
source=Path(capture['capture'])
mapping=json.loads((c/'pipeline-scope.json').read_bytes())
profile=json.loads((c/'events/profile.json').read_bytes())
end=max(q['event'] for q in profile['measurements'])
prepared=json.loads((r/'prepare-results.json').read_bytes())
result=dict(status='starting',captureSha256=capture['captureSha256'],comparisons=[],timings=[])
def save():
    p=r/'replay-results.json'
    p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')

def fingerprint(data): return sha256(data).hexdigest()

def check_structural_control():
    submitted=json.loads((r/'prepare-results.json').read_bytes())
    assert submitted['variation']=='probe field diffuse on use'
    assert len(submitted['predicateRows'])==16
    for row in submitted['predicateRows']:
        selected=row['probe'] and (not row['extended'] or not row['globalReflection'] and not row['explicitLayer'])
        assert selected==row['required']
check_structural_control()
save()
cap=rd.OpenCaptureFile();ctl=None
try:
    identity=sha256()
    with source.open('rb') as f:
        for block in iter(lambda:f.read(2**20),b''): identity.update(block)
    assert identity.hexdigest()==result['captureSha256']==mapping['captureSha256']
    assert cap.OpenFile(str(source),'',None)==rd.ResultCode.Succeeded
    status,ctl=cap.OpenCapture(rd.ReplayOptions(),None)
    assert status==rd.ResultCode.Succeeded
    rows=mapping['groups']
    roles={}
    stage=rd.ShaderStage.Pixel
    for ref in prepared['mapped']:
        representative=ref['representativeEvent']
        role=ref['role']
        ctl.SetFrameEvent(representative,True)
        s=ctl.GetPipelineState()
        rendered=s.GetShaderReflection(stage)
        assert fingerprint(bytes(rendered.rawBytes))==ref['baselineSha256']
        shader=s.GetShader(stage)
        matches=[g for g in rows if any(x['resource']==str(shader) for x in g['shaders'])]
        ids={e for g in matches for e in g['events']}
        assert len(ids)>200
        targets=[g for g in rows if g['depth']==matches[0]['depth'] and g['colors']==matches[0]['colors']]
        assert targets and all(g['depth']==matches[0]['depth'] and g['colors']==matches[0]['colors'] for g in matches)
        out_event=max(e for g in targets for e in g['events'])
        variants=[]
        for name in ('base','candidate'):
            program=(r/(role+'-'+name+'.spv')).read_bytes()
            assert fingerprint(program)==ref['baselineSha256' if name=='base' else 'candidateSha256']
            swap,error=ctl.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,program,rd.ShaderCompileFlags(),stage)
            assert swap!=rd.ResourceId.Null(),error
            variants.append(swap)
        roles[role]=dict(events=ids,end=out_event,color=matches[0]['colors'],depth=matches[0]['depth'],shader=shader,swaps=variants)
    def switch(role):
        for name,info in roles.items():
            key=info['shader']
            ctl.RemoveReplacement(key)
            if role!='raw':
                ctl.ReplaceResource(key,info['swaps'][1 if role=='both' or role==name else 0])
        ctl.SetFrameEvent(0,True)
    def outputs():
        output={}
        for scope,info in roles.items():
            ctl.SetFrameEvent(info['end'],True)
            pipe=ctl.GetPipelineState()
            attachments=[pipe.GetDepthTarget()]+[t for t in pipe.GetOutputTargets() if t.resource!=rd.ResourceId.Null()]
            assert [str(t.resource) for t in attachments]==[info['depth'],*info['color']]
            for i,desc in enumerate(attachments):
                key=scope+'-'+str(desc.resource)
                output[key]=bytes(ctl.GetTextureData(desc.resource,rd.Subresource(desc.firstMip,desc.firstSlice,0)))
                assert len(output[key])>=1280*720
        # Event end can be a compute dispatch. Pick the final presentation draw
        # by the captured spatial anti-aliasing program and attachment identity.
        ctl.SetFrameEvent(final_event,True)
        final=ctl.GetPipelineState().GetOutputTargets()[0]
        assert str(final.resource)==final_resource
        output['present-'+final_resource]=bytes(ctl.GetTextureData(final.resource,rd.Subresource(final.firstMip,final.firstSlice,0)))
        assert len(output['present-'+final_resource])>=1280*720
        return output
    final_group=next(g for g in rows if g['kind']=='draw' and any('spatial_antialiasing.frag.spv' in s['programFiles'] for s in g['shaders']))
    final_event=max(final_group['events'])
    final_resource=final_group['colors'][0]
    switch('raw')
    raw=outputs()
    switch('base')
    base=outputs()
    assert base==raw
    red=dict(base)
    key=next(iter(red))
    red[key]=bytes((red[key][0]^1,))+red[key][1:]
    assert sum(x!=y for x,y in zip(base[key],red[key]))==1
    result['baseline']={key:dict(sha256=fingerprint(data),bytes=len(data)) for key,data in base.items()}
    save()
    for role in ('main','snapshot','both'):
        switch(role)
        output=outputs()
        row=dict(role=role,exact=base==output,images={})
        for key,data in output.items():
            expect=base[key]
            row['images'][key]=dict(sha256=fingerprint(data),bytes=len(data),changedBytes=0 if expect==data else sum(x!=y for x,y in zip(expect,data))+abs(len(expect)-len(data)))
        result['comparisons'].append(row)
        save()
    if all(x['exact'] for x in result['comparisons']):
        for role in ('base','both','both','base'):
            switch(role)
            for _ in range(8): ctl.SetFrameEvent(end,True)
            values=[]
            for _ in range(4):
                counters={int(x.eventId):float(x.value.d)*1000.0 for x in ctl.FetchCounters([rd.GPUCounter.EventGPUDuration])}
                values.append({role:sum(counters[e] for e in info['events']) for role,info in roles.items()})
            result['timings'].append(dict(role=role,values=values,medians={key:median(v[key] for v in values) for key in roles}))
            save()
    result['status']='measured'
    save()
except Exception:
    result.update(status='failed',error=traceback.format_exc())
    save()
    raise
finally:
    if ctl: ctl.Shutdown()
    cap.Shutdown()
sys.exit(0)
