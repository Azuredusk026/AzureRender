from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import subprocess
import sys
import traceback

KEY='AZURE_NR_IRIS_VULKAN_FOOTPRINT'
ROOT=Path(os.environ[KEY]).parent if KEY in os.environ else Path(__file__).resolve().parent
GRID=ROOT.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')

def worker(folder):
    import renderdoc as rd
    options=rd.ReplayOptions()
    job=read(folder/'request.json')
    device=job['device']
    options.forceGPUVendor=rd.GPUVendor.nVidia if device=='nvidia' else rd.GPUVendor.Intel
    options.forceGPUDeviceID=0x28e0 if device=='nvidia' else 0xa788
    capture=rd.OpenCaptureFile()
    ctl=None
    original=replacement=None
    result=dict(status='failed',device=device,diagnostics={})
    try:
        assert capture.OpenFile(job['capture'],'',None)==rd.ResultCode.Succeeded
        code,ctl=capture.OpenCapture(options,None)
        assert code==rd.ResultCode.Succeeded and ctl,str(code)
        gpu=ctl.GetAPIProperties()
        assert gpu.pipelineType==rd.GraphicsAPI.Vulkan and gpu.vendor==options.forceGPUVendor and not gpu.degraded
        ctl.SetFrameEvent(897,True)
        pipe=ctl.GetPipelineState()
        stage=rd.ShaderStage.Fragment
        reflection=pipe.GetShaderReflection(stage)
        original=pipe.GetShader(stage)
        raw=bytes(reflection.rawBytes)
        assert sha256(raw).hexdigest()==job['shaderSha256']
        target=pipe.GetOutputTargets()[0].resource
        desc,=[item for item in ctl.GetTextures() if item.resourceId==target]
        assert (desc.width,desc.height,desc.format.Name())==(2560,1440,'R16G16B16A16_FLOAT')
        points=list(struct.iter_unpack('<II',(GRID/'native-iris-stages/points.bin').read_bytes()))
        assert len(points)==255
        source=Path(job['source'])
        shader=source.read_text(encoding='utf8')
        rule,=[r for r in read(Path(job['rules']))['programs'] if r['output']==job['shader']]
        sample='baseColor=texture(AZ_TEX_BASE_COLOR,eyeCoordinates.baseUv);'
        assert shader.count(sample)==1
        uv='eyeCoordinates.baseUv'
        cases=dict(
            originalLod=f'vec4(textureQueryLod(AZ_TEX_BASE_COLOR,{uv}),{uv})',
            explicitQueryBase=f'vec4(textureLod(AZ_TEX_BASE_COLOR,{uv},textureQueryLod(AZ_TEX_BASE_COLOR,{uv}).x+1.0))',
            derivativeFine=f'vec4(dFdxFine({uv}),dFdyFine({uv}))*2048.0',
            derivativeCoarse=f'vec4(dFdxCoarse({uv}),dFdyCoarse({uv}))*2048.0')
        trials={}
        for quality in ('Fine','Coarse'):
            for scale in ('1.0','.5'):
                trials[quality.lower()+'Hardware'+('Half' if scale=='.5' else 'Full')]=(
                    f'textureGrad(AZ_TEX_BASE_COLOR,{uv},dFdx{quality}({uv}) * {scale},dFdy{quality}({uv}) * {scale})')
            setup=f'vec2 px=vec2(textureSize(AZ_TEX_BASE_COLOR,0)); vec2 dx=dFdx{quality}({uv})*px,dy=dFdy{quality}({uv})*px;'
            for name,length in (('Axis','max(length(dx),length(dy))'),
                ('Component','max(max(abs(dx.x),abs(dx.y)),max(abs(dy.x),abs(dy.y)))'),
                ('TextureAxis','max(length(vec2(dx.x,dy.x)),length(vec2(dx.y,dy.y)))'),
                ('AxisDiagonal','exp2(azureAxisDiagonalMipLod(dx,dy))'),
                ('Ellipse','exp2(azureEllipseMajorAxisLod(dx,dy))')):
                expression=f'log2(max({length},1e-6))'
                trials[quality.lower()+name]=setup+f'baseColor=textureLod(AZ_TEX_BASE_COLOR,{uv},floor({expression}+0.5));'
        result['points']=points
        sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
        def make(label,statement):
            if statement is None:return raw
            if label=='observed':
                return source.with_suffix('.spv').read_bytes()
            path=folder/(label+'.frag')
            if statement.startswith('replace-matcap:'):
                lookup='eyeMatcap=eyeNpr?texture(AZ_TEX_MATCAP,eyeCoordinates.matcapUv):textureLod(AZ_TEX_MATCAP,eyeCoordinates.matcapUv,0.0);'
                assert shader.count(lookup)==1
                code=shader.replace(lookup,'eyeMatcap='+statement[len('replace-matcap:'):]+';')
            elif statement.startswith('after:'):
                code=shader.replace(output_marker,output_marker+
                    '\n    if(eyeRadial){outputColor='+statement[len('after:'):]+';return;}')
            elif label in trials:
                code=shader.replace(sample,statement).replace(output_marker,output_marker+
                    '\n    if(eyeRadial){outputColor=baseColor;return;}')
            else:
                code=shader.replace(sample,statement)
            if label.endswith(("AxisDiagonal","Ellipse")):
                code=code.replace('#include "material_primary_uv.glsl"','#include "material_primary_uv.glsl"\n#include "texture_footprint.glsl"')
            path.write_text(code,encoding='utf8')
            binary=path.with_suffix('.spv')
            subprocess.run([str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+v for v in rule['defines']),
                '-I'+str(Path(job['include'])),str(path),'-o',str(binary)],check=True)
            subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(binary)],check=True)
            return binary.read_bytes()
        def capture_frame():
            ctl.SetFrameEvent(897,True)
            data=bytes(ctl.GetTextureData(target,rd.Subresource()))
            assert len(data)==2560*1440*8
            return data
        baseline=capture_frame()
        output_marker='    vec3 qaColor = beautyColor;'
        assert shader.count(output_marker)==1
        late_cases={'base':'baseColor','matcap':'eyeMatcap','ramp':'classRampRgba',
            'rampCoordinate':'vec4(rampCoordinate,eyeViewRampAlpha,eyeCoordinates.whiteMask,1.0)',
            'preciseUV':'vec4(fract(eyeCoordinates.baseUv*16.0),floor(eyeCoordinates.baseUv*16.0))',
            'uvAndNormal':'vec4(eyeCoordinates.lightingNormal,eyeCoordinates.whiteMask)'}
        entries=[('copy',None),('observed',sample),
                *((n,'outputColor='+expr+'; return;') for n,expr in cases.items()),
                *((n,'after:'+expr) for n,expr in late_cases.items()),
                *((n,expr if 'baseColor=' in expr else 'baseColor='+expr+';') for n,expr in trials.items())]
        if job.get('matcapDiagnostics'):
            uv='eyeCoordinates.matcapUv'
            native=read(ROOT/'trace-iris-projected-residual-inputs.json')
            assert native['status']=='qualified'
            native_sample=dict()
            for point in native['points']:
                x,y=point['point']
                values=point['samples']['463']['r6']
                native_sample[f'all(equal(ivec2(gl_FragCoord.xy),ivec2({x},{y})))']=f'vec4({",".join(map(str,values))})'
            injected=''.join(f'{condition}?{value}:' for condition,value in native_sample.items())
            entries=[('copy',None),('observed',sample),('matcap','after:eyeMatcap'),
                ('matcapUV',f'after:vec4(fract({uv}*16.0),floor({uv}*16.0))'),
                ('matcapLod',f'after:vec4(textureQueryLod(AZ_TEX_MATCAP,{uv}),{uv})'),
                *((f'matcapLevel{i}',f'after:textureLod(AZ_TEX_MATCAP,{uv},{float(i)})') for i in range(8)),
                ('matcapNativeOnly','replace-matcap:'+injected+
                 f'(eyeNpr?texture(AZ_TEX_MATCAP,{uv}):textureLod(AZ_TEX_MATCAP,{uv},0.0))')]
        for label,statement in entries:
            code=make(label,statement)
            replacement,error=ctl.BuildTargetShader(reflection.entryPoint,rd.ShaderEncoding.SPIRV,code,rd.ShaderCompileFlags(),stage)
            assert replacement!=rd.ResourceId.Null(),error
            ctl.ReplaceResource(original,replacement)
            data=capture_frame()
            if label=='copy':assert data==baseline
            if label=='observed':
                assert sha256(code).hexdigest()==job['observedShaderSha256']
                assert data!=baseline
            rows=[]
            for x,y in points:rows.append(struct.unpack_from('<4e',data,8*(y*2560+x)))
            result['diagnostics'][label]=dict(attachmentSha256=sha256(data).hexdigest(),
                shaderSha256=sha256(code).hexdigest(),rows=rows)
            ctl.RemoveReplacement(original);ctl.FreeTargetResource(replacement);replacement=None
        assert capture_frame()==baseline
        result.update(status='qualified',copyControlExact=True,baselineRestored=True)
    except Exception:result['error']=traceback.format_exc()
    finally:
        if ctl:
            if replacement and replacement!=rd.ResourceId.Null():
                ctl.RemoveReplacement(original);ctl.FreeTargetResource(replacement)
            ctl.Shutdown()
        capture.Shutdown()
        write(folder/'results.json',result)
    os._exit(0 if result['status']=='qualified' else 1)

def launch(device,retry=None):
    from hashlib import file_digest
    run=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert run['state']=='held' and Path(run['output'])==ROOT
    assert device in ('nvidia','intel')
    assert retry in (None,'sample-lanes','matcap')
    previous=ROOT/'iris-engine-main-direction'
    job=read(previous/'request.json')
    with Path(job['capture']).open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()=='6960267c0d71e4d05b6bfe0e2730c332ed71955f1fde6d69eb7d8aadf13eff24'
    existing=read(previous/'results.json')
    assert existing['status']=='qualified'
    source=previous/'mesh-scene-head-frame.frag'
    assert sha256(source.with_suffix('.spv').read_bytes()).hexdigest()==existing['lanes']['scene-head-frame']['shader']
    folder=ROOT/(f'iris-vulkan-footprint-{device}'+('-matcap' if retry=='matcap' else ''))
    if folder.exists():
        assert retry=='sample-lanes' or not (folder/'results.json').is_file() or read(folder/'results.json')['status']!='qualified'
        folder.rename(ROOT/(folder.name+'-interrupted-'+str(len(list(ROOT.glob(folder.name+'-interrupted-*')))+1)))
    folder.mkdir()
    job.update(device=device,include=str(Path(job['source']).parent),source=str(source),
        observedShaderSha256=existing['lanes']['scene-head-frame']['shader'],sampleLanes=retry=='sample-lanes',
        matcapDiagnostics=retry=='matcap')
    write(folder/'request.json',job)
    env=dict(os.environ,**{KEY:str(folder)})
    for k in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LOADER_DRIVERS_SELECT'):env.pop(k,None)
    if device=='intel':env['VK_LOADER_DRIVERS_SELECT']='*igvk64*'
    else:env['VK_DRIVER_FILES']=str(GRID/'nv-vk64-active-absolute.json')
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    with (folder/'replay.log').open('wb') as log:
        ret=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=280)
    result=read(folder/'results.json')
    assert ret.returncode==0 and result['status']=='qualified',result.get('error')

if KEY in os.environ:worker(Path(os.environ[KEY]))
elif __name__=='__main__':launch(*sys.argv[1:])






