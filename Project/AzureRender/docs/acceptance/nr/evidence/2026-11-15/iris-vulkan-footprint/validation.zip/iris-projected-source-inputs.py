"""Reproduce the native iris sample and compare its screen-space inputs."""
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import struct

import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p:json.loads(p.read_bytes())
trace=read(out/'trace-iris-projected-residual-inputs.json')
assert trace['status']=='qualified'
src=grid/'iris-overlay-geometry-project/materials/78aceced-9df2-5a59-a58b-f288adb30cb4.dds'
dds=src.read_bytes()
assert struct.unpack_from('<2I',dds,12)==(512,512) and struct.unpack_from('<I',dds,128)[0]==99
level_start=148
levels={}
source_texture=trace['texture']['levels']
for mip in range(10):
    n=512>>mip
    sz=((n+3)//4)**2*16
    if mip in (4,5):
        desc=source_texture[str(mip)]
        expected=(out/desc['path']).read_bytes()
        assert len(expected)==sz and sha256(expected).hexdigest()==desc['sha256']
        authored=dds[level_start:level_start+sz]
        header=bytearray(dds[:148])
        struct.pack_into('<3I',header,12,n,n,sz)
        struct.pack_into('<I',header,28,1)
        def decode(data):
            with Image.open(BytesIO(header+data)) as image:
                values=np.asarray(image.convert('RGBA'),dtype=float)/255.
            color=values[:,:,:3]
            values[:,:,:3]=np.where(color<=.04045,color/12.92,((color+.055)/1.055)**2.4)
            return values
        levels[mip]=(decode(expected),decode(authored),expected==authored)
    level_start+=sz
assert level_start==len(dds)
def bilinear(img, uv):
    size=img.shape[0]
    x,y=np.asarray(uv)*size-.5
    j,i=int(np.floor(x)),int(np.floor(y))
    s,t=x-j,y-i
    return (1-t)*((1-s)*img[i%size,j%size]+s*img[i%size,(j+1)%size])+t*((1-s)*img[(i+1)%size,j%size]+s*img[(i+1)%size,(j+1)%size])
sample_mips=read(out/'iris-projected-source-memory.json')['points']['nvidia']
assigned={tuple(r['point']):r['sourceMips'][0] for r in sample_mips}
out_rows=[]
for row in trace['points']:
    xy=tuple(row['point'])
    k=assigned[xy]
    uv=row['samples']['62']['r4'][2:4]
    native=np.asarray(row['samples']['63']['r9'])
    expected,authored,same=levels[k]
    modeled=bilinear(expected,uv)
    modeled_player=bilinear(authored,uv)
    native_lanes=dict(base=native.tolist(),matcap=row['samples']['463']['r6'],
        ramp=row['samples']['395']['r26'],rampCoordinate=row['samples']['394']['r18'][0],
        viewRampAlpha=row['samples']['403']['r5'][3])
    record=dict(point=list(xy),mip=k,nativeUV=uv,nativeRGBA=native.tolist(),nativeLanes=native_lanes,
        decodedRGBA=modeled.tolist(),authoredRGBA=modeled_player.tolist(),
        linearDiff=float(abs(modeled-native).max()),mipBytesExact=same)
    out_rows.append(record)
device_results={}
for device in ('nvidia','intel'):
    path=out/f'iris-vulkan-footprint-{device}/results.json'
    vulkan=read(path) if path.is_file() else {}
    if vulkan.get('status')!='qualified':continue
    offset={tuple(p):i for i,p in enumerate(vulkan['points'])}
    for row in out_rows:
        i=offset[tuple(row['point'])]
        lanes={key:vulkan['diagnostics'][key]['rows'][i]
               for key in ('originalLod','preciseUV','base','matcap','ramp','rampCoordinate','uvAndNormal')}
        uv=(np.asarray(lanes['preciseUV'][:2])+lanes['preciseUV'][2:])/16.0
        assert np.max(abs(uv-lanes['originalLod'][2:4]))<.001
        predicted={str(mip):bilinear(value[1],uv) for mip,value in levels.items()}
        errors={mip:float(abs(value-np.asarray(lanes['base'])).max()) for mip,value in predicted.items()}
        best=min(errors,key=errors.get)
        source_lanes=row['nativeLanes']
        differences={key:float(abs(np.asarray(lanes[key])-source_lanes[key]).max()) for key in ('base','matcap','ramp')}
        differences['rampCoordinate']=abs(lanes['rampCoordinate'][0]-source_lanes['rampCoordinate'])
        differences['viewRampAlpha']=abs(lanes['rampCoordinate'][1]-source_lanes['viewRampAlpha'])
        row.setdefault('vulkan',{})[device]=dict(lanes=lanes,authoredMipErrors=errors,sourceLaneDelta=differences,
            authoredBestMip=int(best),authoredRgbaAtBestMip=predicted[best].tolist())
    device_results[device]=dict(copy=vulkan['copyControlExact'],restored=vulkan['baselineRestored'])
result=dict(status='qualified-native-texture',playerTextureSha256=sha256(dds).hexdigest(),
    sourceTexture=trace['texture'],reconstruction=out_rows,vulkanControls=device_results)
(out/'iris-projected-source-inputs.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result))
assert all(r['linearDiff']<.003 for r in out_rows),result




