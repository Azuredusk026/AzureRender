"""Archive the matching eye-color sampling probes and their hardware readback."""
from hashlib import sha256
from pathlib import Path
import json
from zipfile import ZipFile, ZIP_DEFLATED


root=Path(__file__).resolve().parent
target=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-15/iris-vulkan-footprint'
read=lambda path:json.loads(path.read_bytes())
score=read(root/'iris-vulkan-footprint-score.json')
hardware='iris-vulkan-footprint-nvidia'
assert score['status']=='measured-vulkan-footprint'
assert score['device']=='nvidia' and score['explicitQueryBase']==dict(exact=255,maximum=0)
assert score['hardwareReplaySha256']==sha256((root/hardware/'results.json').read_bytes()).hexdigest()
assert all(score['fullIris'][name]['equalToPlayerBase']==255
           for name in ('coarseHardwareFull','coarseAxisDiagonal','coarseEllipse'))
assert all(row['playerIntoNativeBaseRgb']==0 for row in score['witnesses'])
assert score['witnesses'][0]['playerIntoNativeMatcapAlpha']>.06
intel=read(root/'iris-vulkan-footprint-intel/results.json')
assert intel['status']=='failed' and 'VK_EXT_depth_bias_control' in intel['error']
score['intelReplay']=dict(status='unsupported-capture-extension',requiredExtension='VK_EXT_depth_bias_control')
score['overallVisualAcceptance']='failed-user-review'
members=['iris-vulkan-footprint.py','score-iris-vulkan-footprint.py','archive-iris-vulkan-footprint.py',
    'trace-iris-projected-residual-inputs.json','iris-projected-source-inputs.py',
    'iris-projected-source-inputs.json','iris-projected-native-t13-mip4.bin','iris-projected-native-t13-mip5.bin',
    f'{hardware}/request.json',f'{hardware}/results.json','iris-vulkan-footprint-intel/results.json']
target.mkdir(parents=True,exist_ok=True)
with ZipFile(target/'validation.zip','w',ZIP_DEFLATED) as archive:
    for member in members:archive.write(root/member,member)
with ZipFile(target/'validation.zip') as archive:
    assert archive.testzip() is None
    checksums={member:sha256(archive.read(member)).hexdigest() for member in members}
assert checksums=={member:sha256((root/member).read_bytes()).hexdigest() for member in members}
score['archive']=dict(sha256=sha256((target/'validation.zip').read_bytes()).hexdigest(),members=checksums)
(target/'results.json').write_text(json.dumps(score,indent=2)+'\n',encoding='utf8')
print(score['archive']['sha256'])
