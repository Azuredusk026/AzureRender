"""Score actual iris samples against the verified native mip lanes."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


out=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
path=out/'iris-vulkan-footprint-nvidia/results.json'
control=read(path)
assert read(path.with_name('request.json'))['sampleLanes'] is True
assert control['status']=='qualified' and control['copyControlExact'] and control['baselineRestored']
diagnostics=control['diagnostics']
points={tuple(xy):index for index,xy in enumerate(control['points'])}
assert len(points)==255
sample=lambda label:np.asarray(diagnostics[label]['rows'],dtype=float)
base=sample('base')
control_vs_explicit=np.abs(sample('explicitQueryBase')-base).max(1)
assert np.isfinite(control_vs_explicit).all()
source=read(out/'iris-projected-source-inputs.json')
assert source['status']=='qualified-native-texture'
recon=source['reconstruction']
assert len(recon)==3 and all(row['mipBytesExact'] for row in recon)
variants=[label for label in diagnostics if label.startswith(('fine','coarse'))]
report=dict(status='measured-vulkan-footprint',witnesses=[],device='nvidia')
report['nativePlayerBaseMip4And5Exact']=True
report['explicitQueryBase']=dict(exact=int((control_vs_explicit==0).sum()),maximum=float(control_vs_explicit.max()))
assert len(variants)==14
assert (control_vs_explicit==0).all()
report['fullIris']={label:dict(equalToPlayerBase=int(np.all(sample(label)==base,axis=1).sum()),
    maximumRgbDifference=float(np.abs(sample(label)[:,:3]-base[:,:3]).max()),
    maximumAlphaDifference=float(np.abs(sample(label)[:,3]-base[:,3]).max())) for label in variants}
for witness in recon:
    pos=tuple(witness['point'])
    row=points[pos]
    reference=np.asarray(witness['nativeRGBA'])
    player=base[row]
    target=sample('matcap')[row]
    native=witness['nativeLanes']
    matcap_delta=np.abs(target-native['matcap'])
    base_delta=np.abs(player-reference)
    uv=sample('preciseUV')[row]
    uv=(uv[:2]+uv[2:])/16
    choices={label:float(np.abs(sample(label)[row,:3]-reference[:3]).max()) for label in variants}
    report['witnesses'].append(dict(point=witness['point'],mip=witness['mip'],
        playerIntoNativeBaseRgb=float(base_delta[:3].max()),playerIntoNativeBaseAlpha=float(base_delta[3]),
        playerIntoNativeMatcapRgb=float(matcap_delta[:3].max()),playerIntoNativeMatcapAlpha=float(matcap_delta[3]),
        nativeRamp=native['rampCoordinate'],playerRamp=float(sample('rampCoordinate')[row,0]),
        lod=sample('originalLod')[row].tolist(),candidates=dict(sorted(choices.items(),key=lambda item:item[1])),
        uvPlayer=uv.tolist(),uvNative=witness['nativeUV'],
        uvMaximumDifference=float(np.abs(uv-witness['nativeUV']).max())))
report['hardwareReplaySha256']=sha256(path.read_bytes()).hexdigest()
(out/'iris-vulkan-footprint-score.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(explicit=report['explicitQueryBase'],witnesses=report['witnesses'])))
