from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import sys
import renderdoc as rd

run=Path(__file__).resolve().parent
capture_run=run.parent/"20261111-001050-quad-feature-device-capture-4798d1"
metadata=json.loads((capture_run/"state.json").read_bytes())
plan=json.loads((run/"plan.json").read_bytes())
src=Path(metadata["capture"])
digest=sha256()
with src.open("rb") as f:
    for block in iter(lambda:f.read(1024*1024),b""):
        digest.update(block)
assert digest.hexdigest()==metadata["captureSha256"]
profile=json.loads((capture_run/"events/profile.json").read_bytes())
last=max(row["event"] for row in profile["measurements"])
cap=rd.OpenCaptureFile()
assert cap.OpenFile(str(src),"",None)==rd.ResultCode.Succeeded
status,control=cap.OpenCapture(rd.ReplayOptions(),None)
assert status==rd.ResultCode.Succeeded
stage=rd.ShaderStage.Compute
summary={"captureSha256":metadata["captureSha256"],"reference":{},"variants":{}}
def save():
    (run/"replay-results.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
def outputs(row):
    control.SetFrameEvent(row["event"],True)
    pipe=control.GetPipelineState()
    entries=pipe.GetReadWriteResources(stage)
    results={}
    for bound in entries:
        d=bound.descriptor
        if d.resource==rd.ResourceId.Null():
            continue
        key=(str(d.resource),d.firstMip,d.firstSlice)
        results[key]=bytes(control.GetTextureData(d.resource,rd.Subresource(d.firstMip,d.firstSlice,0)))
    assert len(results)==row["storageOutputs"],(row["event"],list(results))
    assert all(len(v)>0 for v in results.values())
    return results
def pixels(values):
    return [{ "resource":key[0],"mip":key[1],"slice":key[2],"bytes":len(data),"sha256":sha256(data).hexdigest()} for key,data in sorted(values.items())]
def compare(expected,current):
    assert set(expected)==set(current)
    return [{"resource":key[0],"exact":expected[key]==current[key],"changedBytes":0 if expected[key]==current[key] else sum(a!=b for a,b in zip(expected[key],current[key]))+abs(len(expected[key])-len(current[key]))}
            for key in sorted(expected)]
def switch(mode):
    for role,(original,base,candidate) in selectors.items():
        control.RemoveReplacement(original)
        if mode!="raw":
            control.ReplaceResource(original,candidate if role in mode else base)
    control.SetFrameEvent(0,True)
def timing():
    for _ in range(8):
        control.SetFrameEvent(last,True)
    result=[]
    observed={v["event"] for v in plan.values()}
    for _ in range(4):
        counters={int(v.eventId):float(v.value.d)*1000 for v in control.FetchCounters([rd.GPUCounter.EventGPUDuration])}
        assert observed<=counters.keys()
        result.append({role:counters[row["event"]] for role,row in plan.items()})
    return result
try:
    selectors={}
    for role,row in plan.items():
        control.SetFrameEvent(row["event"],True)
        pipe=control.GetPipelineState()
        original=pipe.GetShader(stage)
        reflection=pipe.GetShaderReflection(stage)
        assert sha256(bytes(reflection.rawBytes)).hexdigest()==row["referenceSha256"]
        before=Path(row["reference"]).read_bytes()
        assert sha256(before).hexdigest()==row["referenceSha256"]
        updated=(run/row["program"]).read_bytes()
        assert before!=updated
        targets=[]
        for program in (before,updated):
            shader,error=control.BuildTargetShader("main",rd.ShaderEncoding.SPIRV,program,rd.ShaderCompileFlags(),stage)
            assert shader!=rd.ResourceId.Null(),error
            targets.append(shader)
        selectors[role]=(original,*targets)
    switch("raw")
    expected={role:outputs(row) for role,row in plan.items()}
    switch("baseline")
    for role,row in plan.items():
        copied=outputs(row)
        assert copied==expected[role],(role,compare(expected[role],copied))
        summary["reference"][role]=pixels(copied)
        # The comparison must detect a one-byte change in the actual output.
        red=dict(copied)
        key=next(iter(red))
        red[key]=bytes((red[key][0]^1,))+red[key][1:]
        assert sum(x["changedBytes"] for x in compare(expected[role],red))==1
    save()
    for role in plan:
        switch(role)
        values={name:compare(expected[name],outputs(row)) for name,row in plan.items()}
        summary["variants"][role]=values
        save()
    accepted=[role for role,values in summary["variants"].items() if all(item["exact"] for output in values.values() for item in output)]
    summary["eligibleForTiming"]=accepted
    save()
    if accepted:
        combined="+".join(accepted)
        switch(combined)
        combined_pixels={name:compare(expected[name],outputs(row)) for name,row in plan.items()}
        summary["combined"]=combined_pixels
        assert all(item["exact"] for output in combined_pixels.values() for item in output)
        roles=("baseline",*accepted,*reversed(accepted),"baseline")
        summary["timing"]=[]
        for mode in roles:
            switch(mode)
            result=timing()
            summary["timing"].append({"role":mode,"samplesMs":result,"medianMs":{name:median(r[name] for r in result) for name in plan}})
            save()
    summary["status"]="measured"
    save()
    print(json.dumps(summary["timing"] if accepted else summary["variants"]),flush=True)
finally:
    control.Shutdown()
    cap.Shutdown()
sys.exit(0)
