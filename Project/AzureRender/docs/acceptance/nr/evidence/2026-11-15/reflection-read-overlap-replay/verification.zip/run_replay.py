from pathlib import Path
import json
import os
import subprocess
import sys

run=Path(__file__).resolve().parent
sys.path.insert(0,str(Path.cwd()/"tools"))
from artifact_maintenance import managed_environment

startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
with (run/"replay.log").open("wb") as log:
    subprocess.run(["D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe","--python",str(run/"replay_entry.py")],
        cwd=run,env=managed_environment(run/"tmp"),stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,check=True,timeout=350)
result=json.loads((run/"replay-results.json").read_bytes())
assert result["status"]=="measured"
print({key:value for key,value in result.items() if key in ("eligibleForTiming","status")},flush=True)
