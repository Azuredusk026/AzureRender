from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import subprocess
import sys

root=Path.cwd()
run=Path(__file__).resolve().parent
build=Path("D:/Projects/FYP-worktrees/nr-integration-verified/Project/AzureRender/build/catalog-computed")
manifest=json.loads((build/"shader-reload.json").read_bytes())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

expected={
    14022:("reflection_trace_packed.comp.spv","7e23f88e362db04579bd8b8e57094009325d7a246d4809d487b03b0d9b5a0de0"),
    14060:("reflection_spatial_filter.comp.spv","7e305dcfc3227ad7f98d8a8832c976b378a4f62007b2044943e29fc98e1d76bc"),
}
# Freeze source, reference, and output bindings before preparing candidates.
plan={
    "trace": {"event":14022,"storageOutputs":2},
    "filter":{"event":14060,"storageOutputs":1},
}
for row in plan.values():
    name,digest=expected[row["event"]]
    row.update(program=name,reference=str(build/"shaders"/name),referenceSha256=digest)
    assert sha(Path(row["reference"]))==digest
(run/"plan.json").write_text(json.dumps(plan,indent=2)+"\n",encoding="utf-8")

# Speculatively prefetch adjacent marches on odd iterations. A sample is
# accepted only by the original scalar progression; the same distance,
# projection, intersection, and refinement are used in their original order.
source=root/"shaders"
trace=(source/"screen_space_reflection.glsl").read_text(encoding="utf-8")
before="""    for(int i=1;i<=256;++i){
        if(i>steps)break;
        float distance=trace.y*float(i)/float(steps);
        if(!screenReflectionProjectClip(clipOrigin+clipDirection*distance,uv))return vec4(0);
        float surfaceDepth=texture(depth,uv).r;
        float delta=depthOrigin+depthDirection*distance-surfaceDepth;"""
after="""#if defined(AZURE_REFLECTION_RAW_HIT)
    vec2 followingUv=vec2(0);
    float followingDistance=0.0,followingDepth=0.0;
    bool followingValid=false;
#endif
    for(int i=1;i<=256;++i){
        if(i>steps)break;
        float distance,surfaceDepth;
#if defined(AZURE_REFLECTION_RAW_HIT)
        if((i&1)==0){
            if(!followingValid)return vec4(0);
            uv=followingUv;distance=followingDistance;surfaceDepth=followingDepth;
        }else{
            distance=trace.y*float(i)/float(steps);
            if(!screenReflectionProjectClip(clipOrigin+clipDirection*distance,uv))return vec4(0);
            followingDistance=trace.y*float(i+1)/float(steps);
            followingValid=i<steps&&screenReflectionProjectClip(clipOrigin+clipDirection*followingDistance,followingUv);
            surfaceDepth=texture(depth,uv).r;
            followingDepth=followingValid?texture(depth,followingUv).r:0.0;
        }
#else
        distance=trace.y*float(i)/float(steps);
        if(!screenReflectionProjectClip(clipOrigin+clipDirection*distance,uv))return vec4(0);
        surfaceDepth=texture(depth,uv).r;
#endif
        float delta=depthOrigin+depthDirection*distance-surfaceDepth;"""
assert trace.count(before)==1
(run/"screen_space_reflection.glsl").write_text(trace.replace(before,after),encoding="utf-8")
(run/"reflection_trace.comp").write_bytes((source/"reflection_trace.comp").read_bytes())
bundle=root/"docs/acceptance/nr/evidence/2026-11-09/bounded-compute-reductions/validation.zip"
with ZipFile(bundle) as archive:
    filter_source=archive.read("candidate-source/shaders/reflection_spatial_filter.comp")
    filter_golden=archive.read("candidate-programs/release/reflection_spatial_filter.comp.spv")
(run/"reflection_spatial_filter.comp").write_bytes(filter_source)
for name in ("reflection_trace_packed.comp.spv","reflection_trace_float.comp.spv","reflection_spatial_filter.comp.spv"):
    spec=next(x for x in manifest["programs"] if x["output"]==name)
    target=run/name
    cmd=[manifest["compiler"],*spec["arguments"],*("-D"+d for d in spec["defines"]),"-I"+str(source),str(run/spec["source"]),"-o",str(target)]
    compile=subprocess.run(cmd,capture_output=True,text=True)
    if compile.returncode:
        print(compile.stderr, file=sys.stderr)
        raise SystemExit(compile.returncode)
    validator=Path(manifest["compiler"]).with_name("spirv-val.exe")
    subprocess.run([str(validator),"--target-env","vulkan1.0",str(target)],check=True)
    assert sha(target)!=sha(build/"shaders"/name)
    print(name,sha(target),flush=True)
    if name.startswith("reflection_spatial_filter"):
        assert target.read_bytes()==filter_golden
