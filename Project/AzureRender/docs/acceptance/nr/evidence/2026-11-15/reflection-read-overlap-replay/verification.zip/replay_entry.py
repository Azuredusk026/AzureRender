from pathlib import Path
import os
import sys
import traceback
run=Path.cwd().resolve()
assert (run/"replay_entry.py").is_file()
p=run/"replay.py"
log=run/"replay-status.txt"
log.write_text("started\n",encoding="utf-8")
try:
    exec(compile(p.read_bytes(),str(p),"exec"),{"__file__":str(p),"__name__":"__main__"})
except SystemExit as exit:
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(exit.code)
except Exception:
    log.write_text(traceback.format_exc(),encoding="utf-8")
    os._exit(2)
