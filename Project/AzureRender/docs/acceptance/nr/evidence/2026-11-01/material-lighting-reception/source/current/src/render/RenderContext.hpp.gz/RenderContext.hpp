#pragma once
#include <map>

#include <vulkan/vulkan.h>

#include <cstdint>
#include <array>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "render/EnvironmentAsset.hpp"
#include "animation/AnimationClipSample.hpp"
#include "render/RenderCamera.hpp"
#include "scene/SceneDescription.hpp"

// Defined in assets/GltfLoader.hpp (global namespace).
struct LoadedAsset;
struct AssetPose;
struct ExpressionPose;

namespace azurerender {

namespace rhi {
class IGpuAllocator;
class IRhi;
class ICommandRecorder;
}

struct RenderSettings;
class MotionVectorTarget;
struct TemporalPreparedFrame;

// Opt-in per-frame submission counters. The engine owns the storage and passes
// a pointer through RenderContext; a scene renderer increments the fields while
// recording so the performance baseline can report CPU-side submission cost.
// The pointer is null unless counter collection is active, so every call site
// must check before use.
struct SceneSubmissionCounters {
    std::uint64_t indirectDrawCalls = 0;
    std::uint64_t instances = 0;
    std::uint64_t visibleInstances = 0;
    std::uint64_t drawCalls = 0;
    std::uint64_t descriptorSetBinds = 0;
    std::uint64_t pipelineBinds = 0;
    std::uint64_t pushConstantUpdates = 0;
};

// Standardized scene state the engine can read from a scene renderer for
// editor integration (picking, gizmos, HUD). A renderer without pickable
// geometry (e.g. the blackhole renderer) leaves the pointer null.
struct RendererSceneState {
    std::uint32_t accumulatedSamples=0,targetSamples=0;
    struct Pickable { std::string node; const LoadedAsset* asset=nullptr; std::array<float,16> model{}; const AssetPose* pose=nullptr; std::array<float,2> morph{}; };
    std::vector<Pickable> pickables;
    const LoadedAsset* asset = nullptr;
    const float* modelMatrix = nullptr;  // 16 floats, column-major
    std::int32_t selectedPrimitiveIndex = -1;
    std::size_t primitiveCount = 0;
    const TemporalPreparedFrame* temporalFrame = nullptr;
};

// Declares what a scene renderer needs from the engine-owned frame.
// The engine uses this to decide which attachments/passes exist before the
// renderer is loaded, so a scene renderer can never silently depend on a
// resource the engine does not provide.
struct SceneRendererCapabilities {
    static constexpr std::uint32_t kApiVersion = 7;

    bool requiresSceneDepth = true;
    bool requiresSceneNormal = true;
    // Diagnostic view names shown by the engine HUD / technical sequence.
    // Index 0 must be the Beauty (final composite) name.
    std::vector<std::string> diagnosticViewNames;
    bool supportsProjectionOffset=false;
    bool supportsMotionVectors=false;
    bool supportsMultisampleShading=false;
    bool supportsMaterialDisplayTransform=false;
    bool supportsMaterialLightingReception=false;
};
inline void validateSceneRendererCamera(const SceneRendererCapabilities& capabilities,const CameraViewDescriptor& camera){
    if((camera.projectionOffsetX!=0||camera.projectionOffsetY!=0)&&!capabilities.supportsProjectionOffset)
        throw std::invalid_argument("Scene renderer does not support camera projection offsets");
}

inline void validateSceneRendererCapabilities(
    const SceneRendererCapabilities& capabilities) {
    if (capabilities.diagnosticViewNames.empty()
        || capabilities.diagnosticViewNames.front() != "Beauty") {
        throw std::invalid_argument(
            "Scene renderer diagnostic view 0 must be Beauty");
    }
}

// Per-frame state the engine hands to every scene renderer. Scene-specific
// simulation state (camera, animation, QA flags) is forwarded here so the
// engine stays the single owner of host-level input while the renderer owns
// the scene rendering itself.
struct NodeAnimationFrame {
    std::string node;
    std::uint32_t clip = 0;
    double time = 0;
    bool loop = true;
    std::uint32_t previousClip = 0;
    double previousTime = 0;
    float blend = 1;
    bool previousLoop = true;
    std::array<float, 2> morph{};
    std::vector<float> morphOverrides;
    std::shared_ptr<const ExpressionPose> expression;
    float expressionWeight=1;
    std::vector<AnimationClipSample> samples;
};
struct SceneFrameData {
    float deltaSeconds = 0.0F;
    double timeSeconds = 0.0;

    const RenderSettings* renderSettings = nullptr;
    std::shared_ptr<const scene::SceneDescription> sceneSnapshot;
    std::vector<NodeAnimationFrame> animations;

    float cameraPosition[3]{0.0F, 0.0F, 0.0F};
    float cameraTarget[3]{0.0F, 0.0F, 0.0F};
    bool cameraOverride=false;
    RenderCamera camera;
    float rotationAngle = 0.0F;

    std::uint32_t qaIsolationMode = 0;
    std::uint32_t qaEffectMode = 0;
    bool qaEffectEnabled = true;
    bool qaHarnessEnabled = false;
    bool qaLightScan = false;

    std::uint64_t capturedFrames = 0;
    std::uint32_t captureFps = 60;
    bool captureActive = false;
    bool technicalSequence = false;
    std::uint32_t technicalSequenceChapter =
        std::numeric_limits<std::uint32_t>::max();
    std::uint32_t currentFrame = 0;

    // Editor interaction state the engine forwards for highlight/gizmo use.
    std::int32_t selectedPrimitiveIndex = -1;
    float gizmoTranslation[3]{0.0F, 0.0F, 0.0F};
    float gizmoRotation[3]{0.0F, 0.0F, 0.0F};
    float gizmoScale[3]{1.0F, 1.0F, 1.0F};
    bool gizmoActive = false;

    std::uint32_t swapchainWidth = 0;
    std::uint32_t swapchainHeight = 0;
};

// Read-only Vulkan context the engine provides to a scene renderer for the
// lifetime of its load. All objects except the per-frame command buffer and
// framebuffer are owned by the engine and outlive the renderer; the renderer
// must never destroy them.
struct RenderContext {
    const std::map<std::string,std::shared_ptr<const LoadedAsset>>* preparedMeshes=nullptr;
    VkDevice device = VK_NULL_HANDLE;
    VkPhysicalDevice physicalDevice = VK_NULL_HANDLE;
    VkQueue graphicsQueue = VK_NULL_HANDLE;
    std::uint32_t graphicsQueueFamily = 0;
    VkCommandPool commandPool = VK_NULL_HANDLE;

    // Engine-owned GPU allocator. Scene renderers route every buffer and
    // image allocation through it and never create a private allocator.
    rhi::IGpuAllocator* allocator = nullptr;

    // Resource creation backend for everything except memory (descriptors,
    // pipelines, samplers, views, render passes, one-shot uploads).
    rhi::IRhi* rhi = nullptr;
    // Recording backend for the current frame; valid only inside recordScene.
    rhi::ICommandRecorder* commands = nullptr;

    // Descriptor indexing is enabled on the device and renderers may build a
    // global texture array instead of per-material descriptor sets. False
    // selects the fixed-table path.
    bool bindlessTextures = false;
    // Ordinary descriptor-layout limits queried from the active physical
    // device. Zero denotes unknown capacity and prevents indexed selection.
    VkPhysicalDeviceLimits descriptorLimits{};

    // R16G16B16A16_SFLOAT supports storage-image writes on this device.
    bool rgba16fStorageImage = false;

    // Compute execution is supported by the active queue.
    bool computeShaders = false;
    // Skinning/morph is enabled for this run; false selects vertex skinning.
    bool computeSkinning = false;
    bool gpuCulling = false;
    bool visibilityPrototype = false;
    bool multiDrawIndirect = false;
    std::uint32_t maxDrawIndirectCount = 1;

    // Frustum culling by instance bounds. Renderers may skip instances
    // outside the view frustum; when false every instance is submitted.
    bool cullingEnabled = true;
    bool faceCullingEnabled = true;
    bool depthTestEnabled = true;

    // QA stress knob: how many clones of the default asset entity the
    // renderer submits per frame.
    std::uint32_t qaInstanceCount = 1;

    std::uint32_t maxFramesInFlight = 2;
    std::uint32_t currentFrame = 0;
    std::uint32_t imageIndex = 0;
    VkCommandBuffer commandBuffer = VK_NULL_HANDLE;

    VkExtent2D renderExtent{};
    VkExtent2D swapchainExtent{};
    VkFormat sceneColorFormat = VK_FORMAT_UNDEFINED;
    VkFormat depthFormat = VK_FORMAT_UNDEFINED;
    VkFormat normalFormat = VK_FORMAT_R8G8B8A8_UNORM;
    // Optional R8_UNORM scene-display coverage, attached after the normal target.
    bool displayMaskEnabled=false;

    VkSampleCountFlagBits rasterizationSamples=VK_SAMPLE_COUNT_1_BIT;
    VkRenderPass sceneRenderPass = VK_NULL_HANDLE;
    VkRenderPass postProcessRenderPass = VK_NULL_HANDLE;
    VkPipelineLayout postProcessPipelineLayout = VK_NULL_HANDLE;
    VkDescriptorSetLayout postProcessDescriptorSetLayout = VK_NULL_HANDLE;
    VkSampler screenAttachmentSampler = VK_NULL_HANDLE;

    // Engine-owned shadow map (fixed resolution, engine-sampled by the
    // post-process Shadow Map diagnostic). A scene renderer records into it
    // through its own shadow pipeline; renderers without a shadow pass may
    // leave the map unrendered (contents undefined until cleared).
    VkFormat shadowFormat = VK_FORMAT_UNDEFINED;
    VkRenderPass shadowRenderPass = VK_NULL_HANDLE;
    VkFramebuffer shadowFramebuffer = VK_NULL_HANDLE;
    VkImageView shadowImageView = VK_NULL_HANDLE;
    VkImage shadowImage = VK_NULL_HANDLE;
    VkSampler shadowSampler = VK_NULL_HANDLE;
    std::uint32_t shadowMapSize = 2048;

    // Current in-flight scene framebuffer the renderer records into.
    VkFramebuffer sceneFramebuffer = VK_NULL_HANDLE;

    // Scene content the renderer instantiates on onLoad: referenced assets
    // and placed nodes. Single-asset scenes carry exactly one resource and
    // one node.
    scene::SceneDescription scene;
    bool sceneWorldCoordinates = false;
    // Directory holding compiled .spv shaders for renderer pipelines.
    std::string shaderDirectory;
    // Scene-independent environment source. Renderers may sample the shared
    // equirectangular representation or provide their own GPU convolution.
    SceneEnvironmentSource environment;
    std::string rampAtlasPath;

    // GPU timing hooks: the renderer writes timestamps 0..2 around its scene
    // passes when gpuTimingEnabled is true; the engine writes the final one.
    VkQueryPool timestampQueryPool = VK_NULL_HANDLE;
    std::uint32_t timestampQueryCount = 0;
    bool gpuTimingEnabled = false;

    // Non-owning; null when submission counters are not being collected.
    SceneSubmissionCounters* submissionCounters = nullptr;

    const RenderSettings* renderSettings = nullptr;
    // View-owned output. Retire renderer recording before replacing this target.
    MotionVectorTarget* motionOutput = nullptr;
};
inline std::uint32_t sceneColorAttachmentCount(const RenderContext& context) noexcept {
    return context.displayMaskEnabled?3U:2U;
}
inline VkClearValue sceneDisplayMaskClearValue() noexcept {
    VkClearValue value{};value.color.float32[0]=1;return value;
}

}  // namespace azurerender
