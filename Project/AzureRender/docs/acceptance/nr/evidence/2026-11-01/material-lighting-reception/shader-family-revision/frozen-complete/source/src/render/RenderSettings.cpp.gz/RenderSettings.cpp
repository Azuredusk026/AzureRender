#include "RenderSettings.hpp"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <nlohmann/json.hpp>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace azurerender {

namespace {

struct ShowcaseLook {
    std::string name;
    GradeSettings grade;
    BloomSettings bloom;
    OutlineSettings outline;
};

std::vector<ShowcaseLook>& showcaseLooks() {
    static std::vector<ShowcaseLook> looks;
    return looks;
}

template <std::size_t Size>
std::array<float, Size> readFloatArray(
    const nlohmann::json& json,
    const char* field) {
    const auto values = json.at(field).get<std::vector<float>>();
    if (values.size() != Size) {
        throw std::runtime_error(std::string(field) + " has invalid length");
    }
    std::array<float, Size> result{};
    std::copy(values.begin(), values.end(), result.begin());
    return result;
}

}  // namespace

void loadShowcasePresetCatalog(const std::filesystem::path& path) {
    std::ifstream input(path);
    if (!input) {
        throw std::runtime_error("Unable to open showcase look catalog: " + path.string());
    }
    const nlohmann::json root = nlohmann::json::parse(input);
    if (root.at("schemaVersion").get<std::uint32_t>()
            != kShowcasePresetVersion) {
        throw std::runtime_error("Unsupported showcase look catalog schema");
    }
    std::vector<ShowcaseLook> loaded;
    for (const auto& item : root.at("looks")) {
        ShowcaseLook look;
        look.name = item.at("name").get<std::string>();
        const auto& grade = item.at("grade");
        look.grade.exposureEv = grade.at("exposureEv").get<float>();
        look.grade.saturation = grade.at("saturation").get<float>();
        look.grade.contrast = grade.at("contrast").get<float>();
        look.grade.tint = readFloatArray<3>(grade, "tint");
        const auto& bloom = item.at("bloom");
        look.bloom.threshold = bloom.at("threshold").get<float>();
        look.bloom.strength = bloom.at("strength").get<float>();
        const auto& outline = item.at("outline");
        look.outline.strength = outline.at("strength").get<float>();
        look.outline.color = readFloatArray<3>(outline, "color");
        loaded.push_back(std::move(look));
    }
    if (loaded.size() != 5) {
        throw std::runtime_error("Showcase look catalog must define five looks");
    }
    showcaseLooks() = std::move(loaded);
}

std::string_view blackholeQualityName(const BlackholeQuality quality) {
    switch (quality) {
    case BlackholeQuality::Performance: return "performance";
    case BlackholeQuality::Balanced: return "balanced";
    case BlackholeQuality::Cinematic: return "cinematic";
    }
    return "unknown";
}

std::string_view blackholeCameraName(const BlackholeCamera camera) {
    switch (camera) {
    case BlackholeCamera::Front: return "front";
    case BlackholeCamera::OrbitLeft: return "orbit-left";
    case BlackholeCamera::High: return "high";
    case BlackholeCamera::Close: return "close";
    case BlackholeCamera::OverShoulder: return "over-shoulder";
    }
    return "unknown";
}

BlackholeQualityParameters blackholeQualityParameters(
    const BlackholeQuality quality) {
    switch (quality) {
    case BlackholeQuality::Performance: return {600, 1, 0.85F};
    case BlackholeQuality::Balanced: return {1100, 1, 0.65F};
    case BlackholeQuality::Cinematic: return {1800, 4, 0.48F};
    }
    throw std::invalid_argument("Unknown blackhole quality profile");
}

bool blackholeHistoryNeedsReset(
    const BlackholeSettings& previous,
    const BlackholeSettings& current) noexcept {
    return previous.quality != current.quality
        || previous.camera != current.camera;
}

RenderSettings migrateRenderSettings(
    RenderSettings settings,
    const std::uint32_t sourceSchemaVersion) {
    if (sourceSchemaVersion == 0
        || sourceSchemaVersion > RenderSettings::kSchemaVersion) {
        throw std::invalid_argument("Unsupported RenderSettings schema version");
    }
    if (sourceSchemaVersion < 4) {
        settings.sceneType = SceneType::Character;
    }
    if (sourceSchemaVersion < 5) {
        settings.blackhole = {};
    }
    if (sourceSchemaVersion < 6) {
        settings.characterPresentation = {};
    }
    if (sourceSchemaVersion < 7) {
        settings.shadow = {};
    }
    if (sourceSchemaVersion < 8) {
        settings.cameraNear=.1F;settings.cameraFar=100;settings.shadowDistance=100;
    }
    if (sourceSchemaVersion < 9) settings.antiAliasing = 1;
    if(sourceSchemaVersion<19&&settings.antiAliasing>3)
        throw std::invalid_argument("Multisample anti-aliasing requires RenderSettings version 19");
    if(sourceSchemaVersion<18&&settings.antiAliasing>2)
        throw std::invalid_argument("Temporal anti-aliasing requires RenderSettings version 18");
    if (sourceSchemaVersion < 14) settings.grade.lut = {};
    if (sourceSchemaVersion < 15) settings.environmentSpecularModel=EnvironmentSpecularModel::LegacySchlick;
    if(sourceSchemaVersion<16)settings.screenSpaceReflection={};
    if(sourceSchemaVersion<17)settings.nprLighting={};
    validateRenderSettings(settings);
    return settings;
}

std::string_view showcasePresetName(const std::uint32_t preset) {
    const auto& looks = showcaseLooks();
    return preset < looks.size() ? std::string_view(looks[preset].name)
                                 : std::string_view("Unknown");
}

void applyShowcasePresetLook(
    RenderSettings& settings,
    const std::uint32_t preset) {
    const auto& looks = showcaseLooks();
    if (preset >= looks.size()) {
        throw std::invalid_argument("showcasePreset must be within 0 and 4");
    }

    settings.showcasePreset = preset;
    settings.stylizedLightingEnabled = true;
    settings.innerOutlineEnabled = true;
    settings.silhouetteOutlineEnabled = true;
    settings.grade.toneMappingEnabled = true;
    settings.bloom.enabled = true;

    settings.grade = looks[preset].grade;
    settings.bloom = looks[preset].bloom;
    settings.outline = looks[preset].outline;
}

void validateRenderSettings(const RenderSettings& settings) {
    validateScreenSpaceReflection(settings.screenSpaceReflection);
    validateNprLighting(settings.nprLighting);
    const auto requireRange = [](
                                  const float value,
                                  const float minimum,
                                  const float maximum,
                                  const char* name) {
        if (!std::isfinite(value) || value < minimum || value > maximum) {
            throw std::invalid_argument(
                std::string(name) + " must be within "
                + std::to_string(minimum) + " and "
                + std::to_string(maximum));
        }
    };
    if(settings.pathTraceSamples<1||settings.pathTraceSamples>65536||settings.pathTraceBounces<1||settings.pathTraceBounces>16) throw std::invalid_argument("Path tracing requires 1..65536 samples and 1..16 bounces");
    if(environmentSpecularModelName(settings.environmentSpecularModel)=="unknown")
        throw std::invalid_argument("Unknown environment specular model");
    if (static_cast<std::uint32_t>(settings.sky.mode)>2) throw std::invalid_argument("Unknown sky mode");
    requireRange(settings.sky.intensity,0.F,32.F,"sky.intensity");
    requireRange(settings.sky.rotationDegrees,-360.F,360.F,"sky.rotationDegrees");
    for(float value:settings.sky.color)requireRange(value,0.F,1.F,"sky.color");
    if (blackholeQualityName(settings.blackhole.quality) == "unknown") {
        throw std::invalid_argument("Unknown blackhole quality profile");
    }
    if (blackholeCameraName(settings.blackhole.camera) == "unknown") {
        throw std::invalid_argument("Unknown blackhole camera preset");
    }

    requireRange(settings.outline.silhouetteWidthPixels,0.F,8.F,"outline.silhouetteWidthPixels");
    if (settings.antiAliasing > 4) throw std::invalid_argument("Unknown anti-aliasing quality");
    requireRange(settings.styleMaskStrength, 0.0F, 2.0F, "styleMaskStrength");
    requireRange(settings.cameraNear,.01F,10,"cameraNear");
    requireRange(settings.cameraFar,.01F,5000,"cameraFar");
    requireRange(settings.shadowDistance,.01F,5000,"shadowDistance");
    if (settings.cameraNear>=settings.cameraFar || settings.shadowDistance<=settings.cameraNear
        || settings.shadowDistance>settings.cameraFar)
        throw std::invalid_argument("Camera requires near < shadowDistance <= far");
    requireRange(
        settings.diffuseBandThreshold,
        0.05F,
        0.95F,
        "diffuseBandThreshold");
    if (settings.showcasePreset > 4) {
        throw std::invalid_argument("showcasePreset must be within 0 and 4");
    }
    if (settings.diagnosticView > 4) {
        throw std::invalid_argument("diagnosticView must be within 0 and 4");
    }
    requireRange(settings.faceSdf.threshold, 0.0F, 1.0F, "faceSdf.threshold");
    requireRange(settings.faceSdf.softness, 0.001F, 0.5F, "faceSdf.softness");
    requireRange(
        settings.faceSdf.noseShadowStrength,
        0.0F,
        1.0F,
        "faceSdf.noseShadowStrength");
    requireRange(
        settings.faceSdf.jawShadowStrength,
        0.0F,
        1.0F,
        "faceSdf.jawShadowStrength");
    for (const float channel : settings.faceSdf.shadowColor) {
        requireRange(channel, 0.0F, 1.0F, "faceSdf.shadowColor channel");
    }
    requireRange(settings.bloom.threshold, 0.0F, 8.0F, "bloom.threshold");
    validateUnlitEffectFrame(settings.unlitEffects);
    requireRange(settings.bloom.strength, 0.0F, 2.0F, "bloom.strength");
    requireRange(settings.outline.strength, 0.0F, 2.0F, "outline.strength");
    requireRange(
        settings.shadow.maximumFilterRadiusTexels,
        1.0F,
        16.0F,
        "shadow.maximumFilterRadiusTexels");
    requireRange(
        settings.outline.depthThreshold,
        0.001F,
        2.0F,
        "outline.depthThreshold");
    requireRange(
        settings.outline.normalThreshold,
        0.001F,
        1.0F,
        "outline.normalThreshold");
    for (const float channel : settings.outline.color) {
        requireRange(channel, 0.0F, 8.0F, "outline.color channel");
    }
    requireRange(settings.grade.exposureEv, -8.0F, 8.0F, "grade.exposureEv");
    requireRange(settings.grade.saturation, 0.0F, 2.0F, "grade.saturation");
    requireRange(settings.grade.contrast, 0.0F, 2.0F, "grade.contrast");
    if(!std::isfinite(settings.grade.lut.exposureMultiplier)||settings.grade.lut.exposureMultiplier<=0
        ||settings.grade.lut.exposureMultiplier>65536.F)
        throw std::invalid_argument("grade.lut.exposureMultiplier must be finite and in (0,65536]");
    if(settings.grade.lut.asset.size()>4096||settings.grade.lut.asset.find('\0')!=std::string::npos)
        throw std::invalid_argument("grade.lut.asset reference is invalid");
    for (const float channel : settings.grade.tint) {
        requireRange(channel, 0.0F, 2.0F, "grade.tint channel");
    }
}

}  // namespace azurerender

#include "foundation/SettingRegistry.hpp"
namespace azurerender {
void registerRenderSettings(SettingRegistry& r) {
    r.add({"render.shadowDistance","Shadow coverage distance in metres",100.0,.01,5000.,false,true,false});
    r.add({"render.antiAliasing","Anti-aliasing: off, edge adaptive, supersampling, temporal, multisampling",1,0.,4.,false,true,false});
    r.add({"render.diagnosticView","Diagnostic view: beauty, normal, outline, shadow, depth",0,0.,4.,false,true,false});
    r.add({"render.exposure","Temporary exposure in EV",0.0,-8.,8.,false,true,false});
    r.add({"render.blackholeQuality","Blackhole quality: performance, balanced, cinematic",2,0.,2.,false,true,false,false});
}
}
