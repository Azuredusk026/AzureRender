#include "SampleSceneRenderer.hpp"

#include "rhi/Rhi.hpp"

#include <array>
#include <stdexcept>

namespace azurerender {

SceneRendererCapabilities SampleSceneRenderer::capabilities() const {
    SceneRendererCapabilities capabilities;
    capabilities.diagnosticViewNames = {"Beauty"};
    capabilities.supportsProjectionOffset=true;
    return capabilities;
}

void SampleSceneRenderer::onLoad(const RenderContext& context) {
    if (loaded_) {
        throw std::logic_error("Sample renderer is already loaded");
    }
    if (context.device == VK_NULL_HANDLE
        || context.sceneRenderPass == VK_NULL_HANDLE) {
        throw std::invalid_argument("Sample renderer requires a valid host context");
    }
    sky_.load(context);
    loaded_ = true;
}

bool SampleSceneRenderer::reuseScene(const RenderContext& context) {
    return loaded_ && context.scene.resources.empty();
}

void SampleSceneRenderer::onSwapchainRecreate(const RenderContext& context) {
    if (!loaded_ || context.sceneRenderPass == VK_NULL_HANDLE) {
        throw std::logic_error("Sample renderer recreate outside loaded lifecycle");
    }
    sky_.resize(context);
}

void SampleSceneRenderer::updateFrame(const SceneFrameData& frame) {
    if (!loaded_) {
        throw std::logic_error("Sample renderer update before load");
    }
    sky_.update(frame);
}

void SampleSceneRenderer::recordScene(const RenderContext& context) {
    if (!loaded_ || context.commands == nullptr
        || context.sceneFramebuffer == VK_NULL_HANDLE) {
        throw std::logic_error("Sample renderer record outside valid frame");
    }
    if (context.shadowRenderPass != VK_NULL_HANDLE
        && context.shadowFramebuffer != VK_NULL_HANDLE) {
        VkClearValue shadowClear{};
        shadowClear.depthStencil = {1.0F, 0};
        rhi::RenderPassBeginDesc shadowPass{};
        shadowPass.renderPass = context.shadowRenderPass;
        shadowPass.framebuffer = context.shadowFramebuffer;
        shadowPass.extent = {context.shadowMapSize, context.shadowMapSize};
        shadowPass.clearValues = {shadowClear};
        context.commands->beginRenderPass(shadowPass);
        context.commands->endRenderPass();
    }
    if (context.gpuTimingEnabled
        && context.timestampQueryPool != VK_NULL_HANDLE) {
        context.commands->writeTimestamp(
            context.timestampQueryPool,
            1,
            VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
    }
    rhi::RenderPassBeginDesc pass{};
    pass.renderPass = context.sceneRenderPass;
    pass.framebuffer = context.sceneFramebuffer;
    pass.extent = context.renderExtent;
    VkClearValue clearColor{};
    clearColor.color = {{0.025F, 0.045F, 0.065F, 1.0F}};
    VkClearValue clearDepth{};
    clearDepth.depthStencil = {1.0F, 0};
    VkClearValue clearNormal{};
    clearNormal.color = {{0.5F, 0.5F, 1.0F, 0.0F}};
    pass.clearValues = {clearColor, clearDepth, clearNormal};
    if(context.displayMaskEnabled)pass.clearValues.push_back(sceneDisplayMaskClearValue());
    context.commands->beginRenderPass(pass);
    context.commands->setViewport(static_cast<float>(context.renderExtent.width),static_cast<float>(context.renderExtent.height));
    context.commands->setScissor(context.renderExtent);
    sky_.draw(*context.commands);
    context.commands->endRenderPass();
    if (context.gpuTimingEnabled
        && context.timestampQueryPool != VK_NULL_HANDLE) {
        context.commands->writeTimestamp(
            context.timestampQueryPool,
            2,
            VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
    }
}

void SampleSceneRenderer::onUnload(const RenderContext&) {
    sky_.release();
    loaded_ = false;
}

}  // namespace azurerender
