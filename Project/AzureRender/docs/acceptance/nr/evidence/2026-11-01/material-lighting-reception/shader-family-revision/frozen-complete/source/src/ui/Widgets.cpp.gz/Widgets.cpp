#include "ui/localization/Localization.hpp"
#include <cstring>
#include <vector>
#include "Widgets.hpp"
#include "UiScopes.hpp"
#include <algorithm>
namespace azurerender::ui {

bool combo(const char* label,int* current,const char* items){
    std::vector<const char*> translated;
    for(const char* item=items;*item;item+=std::strlen(item)+1)translated.push_back(tr(item));
    return ImGui::Combo(tr(label),current,translated.data(),static_cast<int>(translated.size()));
}
bool inputText(const char* label,std::string& value,ImGuiInputTextFlags flags) {
    const auto resize=[](ImGuiInputTextCallbackData* data)->int {
        auto& text=*static_cast<std::string*>(data->UserData);text.resize(static_cast<std::size_t>(data->BufTextLen));data->Buf=text.data();return 0;
    };
    return ImGui::InputText(label,value.data(),value.capacity()+1,flags|ImGuiInputTextFlags_CallbackResize,resize,&value);
}
bool inputTextMultiline(const char* label,std::string& value,ImVec2 size) {
    const auto resize=[](ImGuiInputTextCallbackData* data)->int {
        auto& text=*static_cast<std::string*>(data->UserData);text.resize(static_cast<std::size_t>(data->BufTextLen));data->Buf=text.data();return 0;
    };
    return ImGui::InputTextMultiline(label,value.data(),value.capacity()+1,size,ImGuiInputTextFlags_CallbackResize,resize,&value);
}
bool button(const char* label,const ButtonOptions& options) {
    const auto theme=ThemeTokens::dark();ScopedStyle style;
    const bool filled=!options.selected&&(options.variant==ButtonVariant::Primary||options.variant==ButtonVariant::Danger);
    style.color(ImGuiCol_Button,options.selected?theme.selected:options.variant==ButtonVariant::Primary?theme.accent:options.variant==ButtonVariant::Danger?theme.error:theme.control)
        .color(ImGuiCol_ButtonHovered,filled?theme.accent:theme.hover).color(ImGuiCol_ButtonActive,filled?theme.accent:theme.selected);
    if(filled)style.color(ImGuiCol_Text,theme.recessed);
    ScopedDisabled disabled(options.disabled);const auto clicked=ImGui::Button(label,options.size);
    if(!options.tooltip.empty()&&ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled))ImGui::SetTooltip("%s",options.tooltip.c_str());
    return clicked;
}
void propertyRow(const char* label,const UiMetrics& metrics,const std::function<void()>& draw) {
    ScopedId id(label);ImGui::TextUnformatted(tr(label));ImGui::SameLine(metrics.propertyLabelWidth);ImGui::SetNextItemWidth(-1);draw();
}
}
