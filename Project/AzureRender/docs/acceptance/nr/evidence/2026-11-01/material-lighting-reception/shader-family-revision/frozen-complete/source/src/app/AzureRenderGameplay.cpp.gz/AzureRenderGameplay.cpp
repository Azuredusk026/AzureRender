#include "app/AzureRenderApp.hpp"
#include "app/AzureRenderInternal.hpp"
#include "extensions/ISceneRenderer.hpp"
#include "scenes/BuiltinRendererCatalog.hpp"
#include "platform/GlfwFrontend.hpp"
#if AZURE_WITH_EDITOR
#include "editor/EditorSession.hpp"
#include "editor/EditorAutomation.hpp"
#include "editor/ImGuiEditorLayer.hpp"
#endif
using namespace azurerender::internal;
azurerender::RuntimeLifecycle* AzureRenderApp::activeRuntime(){
#if AZURE_WITH_EDITOR
    if(runOptions_.editorSession)return runOptions_.editorSession->runtime();
#endif
    return &runtime_;
}
azurerender::GameRuntime* AzureRenderApp::activeGame(){
#if AZURE_WITH_EDITOR
    if(runOptions_.editorSession)return runOptions_.editorSession->game();
#endif
    return gameRuntime_.get();
}
azurerender::IScriptRuntime* AzureRenderApp::activeScripts(){
#if AZURE_WITH_EDITOR
    if(runOptions_.editorSession)return runOptions_.editorSession->scripts();
#endif
    return scriptRuntime_.get();
}
azurerender::PresentationRuntime* AzureRenderApp::activePresentation(){
#if AZURE_WITH_EDITOR
    if(runOptions_.editorSession)return runOptions_.editorSession->presentation();
#endif
    return presentationRuntime_.get();
}
azurerender::AssetDatabase* AzureRenderApp::activeAssets(){
#if AZURE_WITH_EDITOR
    if(runOptions_.editorSession){auto* levels=runOptions_.editorSession->levels();return levels?&levels->assets():nullptr;}
#endif
    return levelSession_?&levelSession_->assets():nullptr;
}
bool AzureRenderApp::preloadLevelRenderer(const azurerender::Level& level,bool allowActiveReuse){
    if(allowActiveReuse && rendererResourceKey_==level.resourceKey && renderSettings_.sceneType==level.scene.renderSettings.sceneType && sceneRenderer_ && sceneRenderer_->name()==azurerender::BuiltinRendererCatalog::documentRendererId(level.scene.renderSettings.sceneType,!level.scene.resources.empty())){
        return true;
    }
    azurerender::RenderContext context;buildRenderContext(context);context.scene=level.scene.renderDescription();context.preparedMeshes=&level.preparedMeshes;
    if(!preparedRenderer_ || preparedResourceKey_!=level.resourceKey || preparedRenderSettings_.sceneType!=level.scene.renderSettings.sceneType){
        releasePreparedRenderer();
        auto registry=azurerender::BuiltinRendererCatalog::createRegistry();
        preparedRenderer_=registry.create(azurerender::BuiltinRendererCatalog::documentRendererId(level.scene.renderSettings.sceneType,!context.scene.resources.empty()));
        preparedRenderSettings_=azurerender::resolveRenderSettings(*engineSettings_,level.scene.renderSettings);preparedResourceKey_=level.resourceKey;preparedRendererReady_=false;
    }
    if(preparedRendererReady_)return true;
    context.renderSettings=&preparedRenderSettings_;
    try{preparedRendererReady_=preparedRenderer_->prepareLoad(context,4.0);return preparedRendererReady_;}
    catch(...){preparedRenderer_->onUnload(context);preparedRenderer_.reset();preparedResourceKey_.clear();throw;}
}
void AzureRenderApp::prepareLevelRenderer(const azurerender::Level& level){
#if AZURE_WITH_EDITOR
    invalidatePreviews();
#endif
    azurerender::RenderContext context;buildRenderContext(context);context.scene=level.scene.renderDescription();
    auto targetSettings=azurerender::resolveRenderSettings(*engineSettings_,level.scene.renderSettings);context.renderSettings=&targetSettings;
    if(rendererResourceKey_==level.resourceKey && sceneRenderer_ && sceneRenderer_->name()==azurerender::BuiltinRendererCatalog::documentRendererId(level.scene.renderSettings.sceneType,!context.scene.resources.empty()) && sceneRenderer_->reuseScene(context)){
        renderSettings_=level.scene.renderSettings;return;
    }
    if(preparedResourceKey_!=level.resourceKey || !preparedRendererReady_){
        // A rejected active instance cannot satisfy the fallback preparation.
        while(!preloadLevelRenderer(level,false)){}
    }
    // The previous scene remains cached. Only reusing a renderer with work
    // still in flight needs GPU retirement; ordinary alternating loads reuse
    // a renderer whose last submission completed many frames earlier.
    if(preparedRendererLastSubmission_>graphicsCompleted_){
        vkCheck(vkDeviceWaitIdle(device_),"vkDeviceWaitIdle(renderer reuse)");
        graphicsCompleted_=graphicsSubmission_;
    }
    static_cast<void>(preparedRenderer_->reuseScene(context));
    sceneRenderer_.swap(preparedRenderer_);
    preparedResourceKey_=rendererResourceKey_;rendererResourceKey_=level.resourceKey;
    preparedRenderSettings_=renderSettings_;renderSettings_=level.scene.renderSettings;
    preparedRendererReady_=static_cast<bool>(preparedRenderer_);
    preparedRendererLastSubmission_=graphicsSubmission_;
}
void AzureRenderApp::releasePreparedRenderer(){
    if(preparedRenderer_){
        if(preparedRendererLastSubmission_>graphicsCompleted_){
            vkCheck(vkDeviceWaitIdle(device_),"vkDeviceWaitIdle(renderer eviction)");
            graphicsCompleted_=graphicsSubmission_;
        }
        azurerender::RenderContext context;buildRenderContext(context);
        preparedRenderer_->onUnload(context);preparedRenderer_.reset();
    }
    preparedResourceKey_.clear();preparedRendererReady_=false;preparedRendererLastSubmission_=0;
}
void AzureRenderApp::synchronizeEditorRuntime(){
#if AZURE_WITH_EDITOR
    if(!runOptions_.editorSession)return;
    auto& session=*runOptions_.editorSession;
    session.pollTasks();
    if(editorAutomation_)editorAutomation_->advance(gameplayFrame_,session);
    if(!session.playing() && editorRenderResources_.needsReload(session.viewScene()))
        static_cast<void>(session.execute(azurerender::EditorCommand::ReloadAssets));
    if(session.consumeRuntimeReset()){
        if(session.playing() && !editorWasPlaying_){savedEditorCamera_=cameraPosition_;savedEditorTarget_=cameraTarget_;}
        if(!session.playing() && editorWasPlaying_){cameraPosition_=savedEditorCamera_;cameraTarget_=savedEditorTarget_;}
        editorWasPlaying_=session.playing();gameViewportFocus_=false;gameCursorPrimed_=false;
        glfwSetInputMode(frontend_->nativeHandle(),GLFW_CURSOR,GLFW_CURSOR_NORMAL);
        vkCheck(vkDeviceWaitIdle(device_),"vkDeviceWaitIdle(editor runtime)");gameUi_.reset();gameUiPath_.clear();
        invalidatePreviews();graphicsCompleted_=graphicsSubmission_;renderViews_->complete(graphicsCompleted_);
        azurerender::RenderContext context;buildRenderContext(context);if(sceneRenderer_){sceneRenderer_->onUnload(context);sceneRenderer_.reset();}
        renderSettings_=session.viewScene().renderSettings;createSceneRenderer();
        if(session.playing()){if(session.levels()){
                rendererResourceKey_=session.levels()->current().resourceKey;
                session.levels()->setPrepareHandler([this](const auto& level){prepareLevelRenderer(level);});
                session.levels()->setPreloadHandler([this](const auto& level){return preloadLevelRenderer(level);});
                session.levels()->setReadinessHandler([this](const auto& level){return (sceneRenderer_ && sceneRenderer_->name()==azurerender::BuiltinRendererCatalog::documentRendererId(level.scene.renderSettings.sceneType,!level.scene.resources.empty()) && rendererResourceKey_==level.resourceKey) || (preparedRendererReady_ && preparedRenderSettings_.sceneType==level.scene.renderSettings.sceneType && preparedResourceKey_==level.resourceKey);});
            }}
        else session.context().attachRenderSettings(renderSettings_);
    }
    if(!session.playing())session.context().attachRenderSettings(renderSettings_);
    if(!session.playing() && session.context().reloadChangedAssets())static_cast<void>(session.execute(azurerender::EditorCommand::ReloadAssets));
#endif
}
void AzureRenderApp::synchronizeGameUi(){
    auto* presentation=activePresentation();auto* assets=activeAssets();const auto reference=presentation?presentation->uiDocument():std::string();
    const auto path=assets&&!reference.empty()?assets->resolveReference(reference).generic_u8string():std::string();
    if(path!=gameUiPath_){
        gameUi_.reset();gameUiPath_.clear();
        if(!path.empty()){
            if(!gameUiRenderer_)gameUiRenderer_=std::make_unique<azurerender::GameUiRenderer>(*rhi_,postProcessRenderPass_,resourceLocator_.shaderDirectory());
            gameUi_=std::make_unique<azurerender::GameUi>(std::filesystem::u8path(path),resourceLocator_.publicAsset("fonts/LatoLatin-Regular.ttf"),*gameUiRenderer_);gameUiPath_=path;
            gameUi_->setActionHandler([this](std::string action){
                auto* runtime=activeRuntime();if(!runtime)return;
                if(action=="pause"){
                    if(runtime->state()==azurerender::RuntimeLifecycle::State::Running)runtime->pause();
                    else if(runtime->state()==azurerender::RuntimeLifecycle::State::Paused)runtime->resume();
                }else if(action=="restart"){
                    auto* levels=levelSession_.get();
#if AZURE_WITH_EDITOR
                    if(runOptions_.editorSession)levels=runOptions_.editorSession->levels();
#endif
                    if(levels){levels->request(levels->currentReference());
                        if(runtime->state()==azurerender::RuntimeLifecycle::State::Paused)runtime->resume();}
                }
            });
        }
    }
    if(auto* scripts=activeScripts())scripts->setUiHandler([this](std::string id,std::string text){if(gameUi_)gameUi_->setText(id,text);});
#if AZURE_WITH_EDITOR
    if(editorLayer_)editorLayer_->setGameUi(gameUi_.get());
#endif
}
void AzureRenderApp::updateGameUi(double delta){
    synchronizeGameUi();
    if(auto* presentation=activePresentation()){
        animationFrames_+=presentation->animations().size();audioStarts_=std::max(audioStarts_,presentation->audioStarts());
        for(const auto& error:presentation->errors())if(std::find(presentationErrors_.begin(),presentationErrors_.end(),error)==presentationErrors_.end())presentationErrors_.push_back(error);
    }
    if(!gameUi_)return;
    gameUiRenderer_->beginFrame(++uiSerial_,renderExtent_);
    float densityX=1,densityY=1;glfwGetWindowContentScale(frontend_->nativeHandle(),&densityX,&densityY);
    gameUi_->resize(static_cast<int>(renderExtent_.width),static_cast<int>(renderExtent_.height),densityX);
#if AZURE_WITH_EDITOR
    if(!runOptions_.editorSession)
#endif
    {
        double x=0,y=0;int width=1,height=1;glfwGetCursorPos(frontend_->nativeHandle(),&x,&y);glfwGetWindowSize(frontend_->nativeHandle(),&width,&height);
        gameUi_->pointer(static_cast<int>(x*renderExtent_.width/std::max(width,1)),static_cast<int>(y*renderExtent_.height/std::max(height,1)),glfwGetMouseButton(frontend_->nativeHandle(),GLFW_MOUSE_BUTTON_LEFT)==GLFW_PRESS);
    }
    gameUi_->update(delta);gameUi_->render();
}
