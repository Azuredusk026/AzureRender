#include "render/ReflectionRay.hpp"
#include "render/ScreenReflectionGpu.hpp"
#include "render/LinearMath.hpp"
#include "resources/BinaryFile.hpp"
#include "support/VulkanComputeFixture.hpp"
#include "support/ComputeTexture.hpp"
#include <cstring>
#include <filesystem>
using namespace azurerender;
namespace {
void require(bool v,const char* message){if(!v)throw std::runtime_error(message);}
constexpr unsigned width=65,height=33;
bool centralMirrorHit(const ReflectionTraceView& view,bool ortho,bool moved,unsigned outputWidth,unsigned outputHeight){
    // Independent mirror-plane intersection for the actual selected source sample.
    const auto x=unsigned((float(outputWidth/2)+.5F)/outputWidth*width);
    const auto y=unsigned((float(outputHeight/2)+.5F)/outputHeight*height);
    const float u=(float(x)+.5F)/width*2-1,v=(float(y)+.5F)/height*2-1;
    const float a=(u+(ortho?-view.projection[12]:view.projection[8]))/view.projection[0];
    const float b=(v+(ortho?-view.projection[13]:view.projection[9]))/view.projection[5];
    constexpr float nz=.8660254037844386F;
    const float cameraX=view.right[0]*a+view.up[0]*b;
    const float depth=ortho?3+.5F/nz*cameraX:3/(1-.5F/nz*cameraX);
    std::array<float,3> origin{},direction{};
    for(unsigned c=0;c<3;++c){origin[c]=view.forward[c]*depth+(view.right[c]*a+view.up[c]*b)*(ortho?1.F:depth);
        direction[c]=view.forward[c]+(ortho?0.F:view.right[c]*a+view.up[c]*b);}
    const float dot=.5F*direction[0]+nz*direction[2];direction[0]-=dot;direction[2]-=2*nz*dot;
    const float t=(-2-origin[2])/direction[2];if(t<=0)return false;
    std::array<float,4> point{origin[0]+t*direction[0],origin[1]+t*direction[1],-2,1},clip{};
    if(point[0]<(moved?2.5F:1.5F))return false;
    for(unsigned row=0;row<4;++row)for(unsigned column=0;column<4;++column)clip[row]+=view.worldToClip[column*4+row]*point[column];
    return clip[3]>0&&std::abs(clip[0])<=clip[3]&&std::abs(clip[1])<=clip[3]&&clip[2]>=0&&clip[2]<=clip[3];
}
void fixture(test::VulkanComputeFixture& host,const ReflectionTraceShaders& rayShaders,const ReflectionPyramidShaders& pyramidShaders,
    const std::vector<char>& filterShader,const std::vector<char>& depthShader,bool packed,unsigned mode,bool composed,bool reduced=false,const ReflectionTemporalShaders* temporal=nullptr){
    const unsigned outputWidth=reduced?width/2:width,outputHeight=reduced?height/2:height;
    const bool ortho=mode==1||mode==3,rolled=mode==2,moved=mode==4;
    ReflectionTraceView view;view.right=rolled?std::array<float,3>{0,1,0}:std::array<float,3>{1,0,0};
    view.up=rolled?std::array<float,3>{-1,0,0}:std::array<float,3>{0,1,0};view.forward={0,0,-1};
    view.projection=ortho?internal::orthographic(-3,3,-2,2,.1F,100.F):internal::perspective(1.57079632679F,float(width)/height,.1F,100.F);
    if(mode==3){view.projection[12]=-.05F;view.projection[13]=.02F;}
    view.worldToClip=internal::multiply(view.projection,internal::lookAt({0,0,0},view.forward,view.up));
    std::vector<float> surfaces,colors;
    constexpr float nz=.8660254037844386F;
    const float octX=.5F/(.5F+nz);
    for(unsigned y=0;y<height;++y)for(unsigned x=0;x<width;++x){
        const float u=(float(x)+.5F)/width*2-1,v=(float(y)+.5F)/height*2-1;
        const float a=(u+(ortho?-view.projection[12]:view.projection[8]))/view.projection[0];
        const float b=(v+(ortho?-view.projection[13]:view.projection[9]))/view.projection[5];
        const float cameraX=view.right[0]*a+view.up[0]*b;
        float depth=ortho?3+.5F/nz*cameraX:3/(1-.5F/nz*cameraX);
        if(depth<=0)depth=1000000;
        const float wallX=ortho?cameraX:cameraX*2;
        const bool wall=wallX>=(moved?2.5F:1.5F)&&depth>2;
        surfaces.insert(surfaces.end(),wall?std::initializer_list<float>{2,.5F,.5F,1}:std::initializer_list<float>{depth,octX*.5F+.5F,.5F,0});
        colors.insert(colors.end(),wall?std::initializer_list<float>{1,.2F,.1F,1}:std::initializer_list<float>{0,0,0,1});
    }
    test::ComputeTexture surface(*host.backend,width,height,1,4,VK_FORMAT_R32G32B32A32_SFLOAT,surfaces);
    test::ComputeTexture color(*host.backend,width,height,1,4,VK_FORMAT_R32G32B32A32_SFLOAT,colors);
    ReflectionSignalPyramidGpu signals(*host.backend,{outputWidth,outputHeight},1,2,packed?ReflectionPyramidPrecision::RequirePacked:ReflectionPyramidPrecision::Float32,pyramidShaders);
    const auto formats=signals.base(0);ReflectionRayGpu ray(*host.backend,{outputWidth,outputHeight},2,formats.colorFormat,formats.confidenceFormat,rayShaders);
    ReflectionSpatialFilterGpu filter(*host.backend,{outputWidth,outputHeight},2,filterShader);
    std::unique_ptr<ScreenReflectionGpu> combined;
    if(composed)combined=std::make_unique<ScreenReflectionGpu>(*host.backend,VkExtent2D{width,height},2,
        ScreenReflectionShaders{depthShader,filterShader,rayShaders,pyramidShaders,temporal?*temporal:ReflectionTemporalShaders{}},7,packed?ReflectionPyramidPrecision::RequirePacked:ReflectionPyramidPrecision::Float32,reduced?2U:1U,temporal!=nullptr);
    std::unique_ptr<test::ComputeTexture> motion,acceptance,rejection;
    if(temporal){
        motion=std::make_unique<test::ComputeTexture>(*host.backend,width,height,1,2,VK_FORMAT_R32G32_SFLOAT,std::vector<float>(width*height*2,0));
        acceptance=std::make_unique<test::ComputeTexture>(*host.backend,outputWidth,outputHeight,1,1,VK_FORMAT_R32_SFLOAT,std::vector<float>(outputWidth*outputHeight,1));
        rejection=std::make_unique<test::ComputeTexture>(*host.backend,outputWidth,outputHeight,1,1,VK_FORMAT_R32_SFLOAT,std::vector<float>(outputWidth*outputHeight,0));
        VkCommandBuffer abandoned{};VkCommandBufferAllocateInfo allocation{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        allocation.commandPool=host.pool;allocation.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;allocation.commandBufferCount=1;
        test::vkRequire(vkAllocateCommandBuffers(host.device,&allocation,&abandoned),"allocate abandoned reflection commands");
        try{
            VkCommandBufferBeginInfo begin{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};test::vkRequire(vkBeginCommandBuffer(abandoned,&begin),"begin abandoned reflection commands");
            rhi::VulkanCommandRecorder commands(abandoned);ScreenSpaceReflectionSettings settings;settings.enabled=true;settings.maxDistance=12;settings.maxSteps=128;
            ScreenReflectionHistoryInputs history;history.motion=motion->view;history.acceptance=acceptance->view;history.parameters.minimumColor=0;
            combined->record(commands,0,{surface.view,color.view,width,height},view,settings,&history);
            test::vkRequire(vkEndCommandBuffer(abandoned),"end abandoned reflection commands");
            vkFreeCommandBuffers(host.device,host.pool,1,&abandoned);abandoned=VK_NULL_HANDLE;
        }catch(...){if(abandoned)vkFreeCommandBuffers(host.device,host.pool,1,&abandoned);throw;}
    }
    std::array<rhi::GpuBuffer,2> buffers{};
    try{
        for(auto& buffer:buffers)buffer=host.allocator.createBuffer(outputWidth*outputHeight*16,VK_BUFFER_USAGE_TRANSFER_DST_BIT,true);
        host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer){
            if(combined){
                for(unsigned slot=0;slot<2;++slot){ScreenSpaceReflectionSettings settings;settings.enabled=slot==0;settings.maxDistance=12;settings.maxSteps=128;
                    ScreenReflectionHistoryInputs history;
                    if(temporal){history.motion=motion->view;history.acceptance=acceptance->view;history.parameters.minimumColor=0;
                        history.parameters.historyValid=slot!=0;
                        if(slot){history.previousColor=combined->history(0).color;history.previousConfidence=combined->history(0).confidence;}}
                    combined->record(commands,slot,{surface.view,color.view,width,height},view,settings,temporal?&history:nullptr);}
            }else{
                for(unsigned slot=0;slot<2;++slot){signals.beginBaseWrite(commands,slot);ScreenSpaceReflectionSettings settings;
                    settings.enabled=slot==0;settings.maxDistance=12;settings.maxSteps=128;
                    ray.record(commands,slot,{surface.view,color.view,width,height},signals.base(slot),view,settings);}
                for(unsigned slot=0;slot<2;++slot){signals.record(commands,slot,surface.view,1,{});const auto signal=signals.output(slot);
                    ReflectionFilterInputViews input{surface.view,surface.view,signal.color,outputWidth,outputHeight,1,1};input.confidence=signal.confidence;input.confidenceLevels=1;input.roughnessChannel=3;
                    ReflectionFilterParameters parameters;parameters.maxLod=0;filter.record(commands,slot,input,parameters);}
            }
            for(unsigned slot=0;slot<2;++slot){
                const auto output=combined?combined->output(slot):filter.output(slot);
                commands.imageBarrier({output.image,output.layout,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,1,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT});
                commands.copyImageToBuffer(output.image,buffers[slot].buffer,{outputWidth,outputHeight});
                commands.imageBarrier({output.image,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,output.layout,1,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_ACCESS_TRANSFER_READ_BIT,VK_ACCESS_SHADER_READ_BIT});
                commands.bufferBarrier({buffers[slot].buffer,0,buffers[slot].size,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});}
        });
        for(unsigned slot=0;slot<2;++slot){auto& buffer=buffers[slot];host.allocator.invalidate(buffer,0,buffer.size);const auto* data=static_cast<const float*>(buffer.mapped);
            for(unsigned i=0;i<outputWidth*outputHeight*4;++i)require(std::isfinite(data[i]),"Nonfinite reflection ray/filter output");
            const auto* center=data+((outputHeight/2)*outputWidth+outputWidth/2)*4;
            std::cout<<"Trace composed="<<composed<<" reduced="<<reduced<<" packed="<<packed<<" mode="<<mode<<" slot="<<slot<<" center="<<center[0]<<','<<center[1]<<','<<center[2]<<','<<center[3]<<'\n';
            if(slot||!centralMirrorHit(view,ortho,moved,outputWidth,outputHeight))require(center[0]==0&&center[3]==0,"Disabled or analytically invisible reflector must have no central ray hit");
            else {require(center[3]>.5F,"Analytic mirror must hit the visible emissive wall");const std::array<float,3> expected{1,.2F,.1F};
                for(unsigned c=0;c<3;++c)require(std::abs(center[c]-expected[c])<(packed?.02F:1e-5F),"Reflected radiance differs from independent wall color");}
        }
        if(temporal){
            ScreenReflectionHistoryInputs history;history.motion=motion->view;history.acceptance=acceptance->view;
            history.parameters.minimumColor=0;history.parameters.historyValid=true;history.parameters.varianceScale=10;
            history.previousColor=combined->history(1).color;history.previousConfidence=combined->history(1).confidence;
            ScreenSpaceReflectionSettings settings;settings.enabled=true;settings.maxDistance=12;settings.maxSteps=128;
            host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer){
                combined->record(commands,0,{surface.view,color.view,width,height},view,settings,&history);
                const auto output=combined->output(0);
                commands.imageBarrier({output.image,output.layout,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,1,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT});
                commands.copyImageToBuffer(output.image,buffers[1].buffer,{outputWidth,outputHeight});
                commands.bufferBarrier({buffers[1].buffer,0,buffers[1].size,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
            });
            host.allocator.invalidate(buffers[1],0,buffers[1].size);
            const auto* first=static_cast<const float*>(buffers[0].mapped);const auto* next=static_cast<const float*>(buffers[1].mapped);
            unsigned changed=0;for(unsigned i=0;i<outputWidth*outputHeight*4;++i){require(std::isfinite(next[i]),"Nonfinite composed temporal output");if(std::abs(first[i]-next[i])>1e-6F)++changed;}
            require(changed>0,"Accepted reflection history must change the composed output near signal boundaries");
            std::cout<<"Temporal composed reduced="<<reduced<<" packed="<<packed<<" changed="<<changed<<'\n';
            history.previousColor=combined->history(0).color;history.previousConfidence=combined->history(0).confidence;history.acceptance=rejection->view;
            host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer){
                combined->record(commands,1,{surface.view,color.view,width,height},view,settings,&history);
                const auto output=combined->output(1);
                commands.imageBarrier({output.image,output.layout,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,1,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT});
                commands.copyImageToBuffer(output.image,buffers[1].buffer,{outputWidth,outputHeight});
                commands.bufferBarrier({buffers[1].buffer,0,buffers[1].size,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
            });
            host.allocator.invalidate(buffers[1],0,buffers[1].size);
            require(std::memcmp(buffers[0].mapped,buffers[1].mapped,outputWidth*outputHeight*16)==0,"Zero acceptance must recover the exact current-only composed output");
        }
        for(auto& buffer:buffers)host.allocator.destroyBuffer(buffer);
    }catch(...){for(auto& buffer:buffers)host.allocator.destroyBuffer(buffer);throw;}
}
}
int main(int argc,char** argv)try{
    require(argc==7,"Expected packed/wide ray and pyramid shaders, then filter shader");test::VulkanComputeFixture host;
    const ReflectionTraceShaders rays{readBinaryFile(argv[1]),readBinaryFile(argv[2])};
    const ReflectionPyramidShaders pyramids{readBinaryFile(argv[3]),readBinaryFile(argv[4])};const auto filter=readBinaryFile(argv[5]);const auto depth=readBinaryFile(argv[6]);
    const auto directory=std::filesystem::path(argv[5]).parent_path().u8string();
    const ReflectionTemporalShaders temporal{readBinaryFile(directory+"/reflection_temporal_packed.comp.spv"),readBinaryFile(directory+"/reflection_temporal_float.comp.spv")};
    for(bool composed:{false,true})for(bool packed:{false,true})for(unsigned mode=0;mode<5;++mode)fixture(host,rays,pyramids,filter,depth,packed,mode,composed);
    for(bool composed:{false,true})for(bool packed:{false,true})for(unsigned mode=0;mode<5;++mode)fixture(host,rays,pyramids,filter,depth,packed,mode,composed,true);
    for(bool reduced:{false,true})for(bool packed:{false,true})fixture(host,rays,pyramids,filter,depth,packed,0,true,reduced,&temporal);
    require(host.errors==0&&!host.allocator.statistics().liveImages&&!host.allocator.statistics().liveBuffers,"Reflection ray validation or retirement failed");
    std::cout<<"PASS: 80 full/half outputs plus 16 temporal outputs, perspective/orthographic/rolled/offset/motion, validation=0 resources=0\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
