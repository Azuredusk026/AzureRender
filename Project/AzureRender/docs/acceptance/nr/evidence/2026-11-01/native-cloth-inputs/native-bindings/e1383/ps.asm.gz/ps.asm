Shader hash 73713d50-09808949-df9c06e7-88f78a4d

ps_5_0
      dcl_globalFlags refactoringAllowed
      dcl_immediateConstantBuffer {
			{ 1.000000, 0, 0, 0}, 
			{ 0, 1.000000, 0, 0}, 
			{ 0, 0, 1.000000, 0}, 
			{ 0, 0, 0, 1.000000}, 
			{ -0.399656, 0.916665, -0.942016, -0.399062}, 
			{ 0.124512, -0.992218, 0.945586, -0.768907}, 
			{ 0.852354, 0.522965, -0.094184, -0.929389}, 
			{ -0.229312, 0.973353, 0.344959, 0.293878}, 
			{ -0.772406, 0.635129, -0.915886, 0.457714}, 
			{ 0.792753, -0.609544, -0.815442, -0.879125}, 
			{ -0.578050, 0.816002, -0.382775, 0.276768}, 
			{ -0.831130, -0.556079, 0.974844, 0.756484}, 
			{ 0.807795, 0.589464, 0.443233, -0.975116}, 
			{ 0.471415, 0.881911, 0.537430, -0.473734}, 
			{ -0.313974, -0.949432, -0.264969, -0.418930}, 
			{ -0.945007, -0.327051, 0.791975, 0.190902}, 
			{ -0.185037, -0.982732, -0.241888, 0.997065}, 
			{ -0.933756, 0.357911, -0.814100, 0.914376}, 
			{ -0.997614, 0.069036, 0.199841, 0.786414}, 
			{ 0.306128, 0.951990, 0.143832, -0.141008}, 
			{ 2, 1, -1.000000, 1.000000}, 
			{ 2, 1, 1.000000, 1.000000}, 
			{ 0, 2, 1.000000, -1.000000}, 
			{ 0, 2, 1.000000, 1.000000}, 
			{ 0, 1, 1.000000, 1.000000}, 
			{ 0, 1, -1.000000, 1.000000} }
      dcl_constantbuffer cb0[45], immediateIndexed
      dcl_constantbuffer cb1[141], immediateIndexed
      dcl_constantbuffer cb2[4094], dynamicIndexed
      dcl_constantbuffer cb3[2054], dynamicIndexed
      dcl_constantbuffer cb4[4], immediateIndexed
      dcl_constantbuffer cb5[395], dynamicIndexed
      dcl_constantbuffer cb6[10], immediateIndexed
      dcl_constantbuffer cb7[160], dynamicIndexed
      dcl_sampler s0, mode_default
      dcl_sampler s1, mode_default
      dcl_sampler s2, mode_comparison
      dcl_resource_structured t0, 4
      dcl_resource_structured t1, 16
      dcl_resource_raw t2
      dcl_resource_texture2d (float,float,float,float) t3
      dcl_resource_texture2d (float,float,float,float) t4
      dcl_resource_texture2d (float,float,float,float) t5
      dcl_resource_texture2d (float,float,float,float) t6
      dcl_resource_texture2d (float,float,float,float) t7
      dcl_resource_texture3d (float,float,float,float) t8
      dcl_resource_texture3d (float,float,float,float) t9
      dcl_resource_texture3d (float,float,float,float) t10
      dcl_resource_texture3d (float,float,float,float) t11
      dcl_resource_texture3d (float,float,float,float) t12
      dcl_resource_texture3d (float,float,float,float) t13
      dcl_resource_texture2d (float,float,float,float) t14
      dcl_resource_texture2d (float,float,float,float) t15
      dcl_resource_texture2d (float,float,float,float) t16
      dcl_resource_texture2d (float,float,float,float) t17
      dcl_resource_texture2d (float,float,float,float) t18
      dcl_resource_texture2d (float,float,float,float) t19
      dcl_resource_texture2d (float,float,float,float) t20
      dcl_resource_texture2d (float,float,float,float) t21
      dcl_resource_texturecube (float,float,float,float) t22
      dcl_resource_texture2d (float,float,float,float) t23
      dcl_resource_texture3d (float,float,float,float) t24
      dcl_input_ps_siv linear noperspective v0.xyw, position
      dcl_input_ps linear v1.xy
      dcl_input_ps linear v2.xyz
      dcl_input_ps linear v3.xyz
      dcl_input_ps linear v4.xyzw
      dcl_input_ps linear v5.xyz
      dcl_input_ps linear v6.xyz
      dcl_input_ps linear v7.xyz
      dcl_input_ps linear v8.xyz
      dcl_input_ps nointerpolation v9.x
      dcl_input_ps_sgv nointerpolation v10.x, isfrontface
      dcl_output o0.xyzw
      dcl_output o1.xyzw
      dcl_temps 34
   0: mov r0.x, cb0[0].z
   1: mov r0.y, cb0[1].z
   2: mov r0.z, cb0[2].z
   3: add r1.xyz, r0.xyzx, v2.xyzx
   4: mad r1.xyz, cb1[4].wwww, r1.xyzx, -v2.xyzx
   5: dp3 r0.w, r1.xyzx, r1.xyzx
   6: max r1.w, r0.w, l(0.000000)
   7: rsq r1.w, r1.w
   8: mul r2.xyz, r1.wwww, r1.xyzx
   9: ishl r2.w, v9.x, l(4)
  10: and r3.x, l(16), cb2[r2.w + 4].w
  11: if_nz r3.x
  12:   iadd r3.y, l(2), cb2[r2.w + 5].x
  13:   ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.x, r3.y, l(12), t1.xxxx
  14:   ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.y, cb2[r2.w + 5].x, l(12), t1.xxxx
  15: else
  16:   mov r4.xy, cb2[r2.w + 3].zxzz
  17: endif
  18: sample_b(texture2d)(float,float,float,float) r5.xyzw, v1.xyxx, t19.xyzw, s1, cb1[26].x
  19: sample_b(texture2d)(float,float,float,float) r6.xyzw, v1.xyxx, t20.xyzw, s1, cb1[26].x
  20: add r3.y, -r6.w, l(1.000000)
  21: mul r5.xyzw, r5.xyzw, cb6[6].xyzw
  22: add r7.xyz, v2.xyzx, cb0[44].xyzx
  23: add r4.xz, -r4.yyxy, r7.xxzx
  24: mov r4.y, l(0.000061)
  25: dp3 r3.z, r4.xyzx, r4.xyzx
  26: rsq r3.z, r3.z
  27: mul r4.xyz, r3.zzzz, r4.xyzx
  28: sample_b(texture2d)(float,float,float,float) r8.xyz, v1.xyxx, t21.xywz, s1, cb1[26].x
  29: mul r8.x, r8.x, r8.z
  30: mad r3.zw, r8.xxxy, l(0.000000, 0.000000, 2.000000, 2.000000), l(0.000000, 0.000000, -1.000000, -1.000000)
  31: dp2 r4.w, r3.zwzz, r3.zwzz
  32: min r4.w, r4.w, l(1.000000)
  33: add r4.w, -r4.w, l(1.000000)
  34: sqrt r4.w, r4.w
  35: max r4.w, r4.w, l(0.000000)
  36: mul r3.zw, r3.zzzw, cb6[0].wwww
  37: mul r8.xyz, r5.xyzx, cb6[4].zzzz
  38: dp3 r7.w, r8.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
  39: mad r8.xyz, r5.xyzx, cb6[4].zzzz, -r7.wwww
  40: mad r8.xyz, cb6[4].wwww, r8.xyzx, r7.wwww
  41: mul r9.xyz, v3.zxyz, v4.yzxy
  42: mad r9.xyz, v3.yzxy, v4.zxyz, -r9.xyzx
  43: mul r9.xyz, r9.xyzx, v4.wwww
  44: mul r9.xyz, r3.wwww, r9.xyzx
  45: mad r9.xyz, r3.zzzz, v4.xyzx, r9.xyzx
  46: mad r9.xyz, r4.wwww, v3.xyzx, r9.xyzx
  47: mad r3.z, cb6[1].y, l(2.000000), l(-1.000000)
  48: movc r3.z, v10.x, l(1.000000), r3.z
  49: dp3 r3.w, r9.xyzx, r9.xyzx
  50: max r3.w, r3.w, l(0.000000)
  51: rsq r3.w, r3.w
  52: mul r9.xyz, r3.wwww, r9.xyzx
  53: mul r10.xyz, r3.zzzz, r9.xyzx
  54: dp3 r3.w, v3.xyzx, v3.xyzx
  55: rsq r3.w, r3.w
  56: mul r9.xzw, r3.wwww, v3.xxyz
  57: mul r9.xzw, r3.zzzz, r9.xxzw
  58: ftou r11.xy, v0.xyxx
  59: lt r3.w, l(0.500000), cb1[120].x
  60: movc r3.w, r3.w, cb1[120].y, cb2[r2.w + 13].x
  61: and r4.w, r3.w, l(255)
  62: utof r12.x, r4.w
  63: ubfe r13.xy, l(8, 8, 0, 0), l(8, 16, 0, 0), r3.wwww
  64: utof r12.yz, r13.xxyx
  65: ushr r3.w, r3.w, l(24)
  66: utof r12.w, r3.w
  67: mul r13.xyzw, r12.xyzw, l(0.003922, 0.003922, 0.003922, 0.003922)
  68: add r3.w, cb1[120].w, -cb2[r2.w + 13].y
  69: mad r3.w, cb1[120].x, r3.w, cb2[r2.w + 13].y
  70: add r3.w, -r7.y, r3.w
  71: add r3.w, r3.w, l(0.200000)
  72: mul_sat r3.w, r3.w, l(2.857143)
  73: mad r4.w, r3.w, l(-2.000000), l(3.000000)
  74: mul r3.w, r3.w, r3.w
  75: mul r3.w, r3.w, r4.w
  76: mul r3.w, r13.y, r3.w
  77: max r4.w, r3.w, r13.z
  78: add r7.w, l(1.000000), -cb1[29].x
  79: mad r7.w, cb1[122].w, r7.w, cb1[29].x
  80: mul r7.w, r7.w, cb1[27].x
  81: lt r8.w, cb1[111].y, l(0.500000)
  82: if_nz r8.w
  83:   mad r14.xyz, cb0[6].xzyx, -cb1[137].wwww, cb1[135].xzyx
  84:   add r14.xyz, r7.xzyx, -r14.xyzx
  85:   max r8.w, abs(r14.y), abs(r14.x)
  86:   add r8.w, r8.w, l(-464.000000)
  87:   mul_sat r8.w, r8.w, l(0.031250)
  88:   add r11.w, abs(r14.z), l(-208.000000)
  89:   mul_sat r11.w, r11.w, l(0.031250)
  90:   max r8.w, r8.w, r11.w
  91:   ne r11.w, l(0), cb1[135].w
  92:   lt r12.y, r8.w, l(1.000000)
  93:   and r11.w, r11.w, r12.y
  94:   if_nz r11.w
  95:     mad r14.xyz, cb0[6].xzyx, -cb1[137].yyyy, cb1[135].xzyx
  96:     add r14.xyz, r7.xzyx, -r14.xyzx
  97:     max r11.w, abs(r14.y), abs(r14.x)
  98:     add r11.w, r11.w, l(-29.000000)
  99:     mul_sat r11.w, r11.w, l(0.500000)
 100:     add r12.y, abs(r14.z), l(-13.000000)
 101:     mul_sat r12.y, r12.y, l(0.500000)
 102:     max r11.w, r11.w, r12.y
 103:     lt r12.y, r11.w, l(1.000000)
 104:     if_nz r12.y
 105:       mad r14.xyz, r7.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 106:       mul r15.xyz, r14.xyzx, cb1[136].xyzx
 107:       round_ni r15.xyz, r15.xyzx
 108:       mad r14.xyz, r14.xyzx, cb1[136].xyzx, -r15.xyzx
 109:       sample_l(texture3d)(float,float,float,float) r15.xyw, r14.xyzx, t8.yzwx, s1, l(0)
 110:       add r12.y, -r11.w, l(1.000000)
 111:       mul r12.z, l(0.500000), cb1[136].y
 112:       mad r13.y, -cb1[136].y, l(0.500000), l(1.000000)
 113:       max r12.z, r12.z, r14.y
 114:       min r12.z, r13.y, r12.z
 115:       mul r14.w, r12.z, l(0.333333)
 116:       sample_l(texture3d)(float,float,float,float) r16.xyzw, r14.xwzx, t9.xyzw, s0, l(0)
 117:       mad r12.z, r16.w, r12.y, r8.w
 118:       add r17.xyz, r14.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 119:       sample_l(texture3d)(float,float,float,float) r17.xyz, r17.xyzx, t9.xyzw, s0, l(0)
 120:       mad r17.xyz, r17.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 121:       mul r17.xyz, r15.yyyy, r17.xyzx
 122:       mov r17.w, r15.y
 123:       mul r17.xyzw, r12.yyyy, r17.xyzw
 124:       add r14.xyz, r14.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 125:       sample_l(texture3d)(float,float,float,float) r14.xyz, r14.xyzx, t9.xyzw, s0, l(0)
 126:       mad r14.xyz, r14.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 127:       mul r14.xyz, r15.xxxx, r14.xyzx
 128:       mov r14.w, r15.x
 129:       mul r14.xyzw, r12.yyyy, r14.xyzw
 130:       mad r16.xyz, r16.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 131:       mul r15.xyz, r15.wwww, r16.xyzx
 132:       mul r15.xyzw, r12.yyyy, r15.xyzw
 133:     else
 134:       mov r17.xyzw, l(0, 0, 0, 0)
 135:       mov r14.xyzw, l(0, 0, 0, 0)
 136:       mov r15.xyzw, l(0, 0, 0, 0)
 137:       mov r12.z, r8.w
 138:     endif
 139:     mad r16.xyz, cb0[6].xzyx, -cb1[137].zzzz, cb1[135].xzyx
 140:     add r16.xyz, r7.xzyx, -r16.xyzx
 141:     max r12.y, abs(r16.y), abs(r16.x)
 142:     add r12.y, r12.y, l(-116.000000)
 143:     mul_sat r12.y, r12.y, l(0.125000)
 144:     add r13.y, abs(r16.z), l(-52.000000)
 145:     mul_sat r13.y, r13.y, l(0.125000)
 146:     max r12.y, r12.y, r13.y
 147:     lt r13.y, r12.y, l(1.000000)
 148:     if_nz r13.y
 149:       mad r16.xyz, r7.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 150:       mul r18.xyz, r16.xyzx, cb1[136].xyzx
 151:       round_ni r18.xyz, r18.xyzx
 152:       mad r16.xyz, r16.xyzx, cb1[136].xyzx, -r18.xyzx
 153:       sample_l(texture3d)(float,float,float,float) r18.xyw, r16.xyzx, t10.yzwx, s1, l(0)
 154:       add r13.y, -r12.y, l(1.000000)
 155:       mul r11.w, r11.w, r13.y
 156:       mul r13.y, l(0.500000), cb1[136].y
 157:       mad r13.z, -cb1[136].y, l(0.500000), l(1.000000)
 158:       max r13.y, r13.y, r16.y
 159:       min r13.y, r13.z, r13.y
 160:       mul r16.w, r13.y, l(0.333333)
 161:       sample_l(texture3d)(float,float,float,float) r19.xyzw, r16.xwzx, t11.xyzw, s0, l(0)
 162:       mad r12.z, r19.w, r11.w, r12.z
 163:       add r20.xyz, r16.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 164:       sample_l(texture3d)(float,float,float,float) r20.xyz, r20.xyzx, t11.xyzw, s0, l(0)
 165:       mad r20.xyz, r20.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 166:       mul r20.xyz, r18.yyyy, r20.xyzx
 167:       mov r20.w, r18.y
 168:       mad r17.xyzw, r20.xyzw, r11.wwww, r17.xyzw
 169:       add r16.xyz, r16.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 170:       sample_l(texture3d)(float,float,float,float) r16.xyz, r16.xyzx, t11.xyzw, s0, l(0)
 171:       mad r16.xyz, r16.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 172:       mul r16.xyz, r18.xxxx, r16.xyzx
 173:       mov r16.w, r18.x
 174:       mad r14.xyzw, r16.xyzw, r11.wwww, r14.xyzw
 175:       mad r16.xyz, r19.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 176:       mul r18.xyz, r18.wwww, r16.xyzx
 177:       mad r15.xyzw, r18.xyzw, r11.wwww, r15.xyzw
 178:     endif
 179:     lt r11.w, l(0), r12.y
 180:     if_nz r11.w
 181:       mad r16.xyz, r7.xyzx, l(0.125000, 0.125000, 0.125000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 182:       mul r18.xyz, r16.xyzx, cb1[136].xyzx
 183:       mul r19.xyz, l(0.500000, 0.500000, 0.500000, 0.000000), cb1[136].xyzx
 184:       round_ni r18.xyz, r18.xyzx
 185:       mad r16.xyz, r16.xyzx, cb1[136].xyzx, -r18.xyzx
 186:       mad r18.xyz, -cb1[136].xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), l(1.000000, 1.000000, 1.000000, 0.000000)
 187:       max r16.xyz, r19.xyzx, r16.xyzx
 188:       min r16.xyz, r18.xyzx, r16.xyzx
 189:       sample_l(texture3d)(float,float,float,float) r20.xyw, r16.xyzx, t12.yzwx, s1, l(0)
 190:       add r11.w, -r8.w, l(1.000000)
 191:       mul r11.w, r11.w, r12.y
 192:       max r12.y, r19.y, r16.y
 193:       min r12.y, r18.y, r12.y
 194:       mul r16.w, r12.y, l(0.333333)
 195:       sample_l(texture3d)(float,float,float,float) r18.xyzw, r16.xwzx, t13.xyzw, s0, l(0)
 196:       add r19.xyz, r16.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 197:       sample_l(texture3d)(float,float,float,float) r19.xyz, r19.xyzx, t13.xyzw, s0, l(0)
 198:       mad r19.xyz, r19.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 199:       mul r19.xyz, r20.yyyy, r19.xyzx
 200:       mov r19.w, r20.y
 201:       mad r17.xyzw, r19.xyzw, r11.wwww, r17.xyzw
 202:       add r16.xyz, r16.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 203:       sample_l(texture3d)(float,float,float,float) r16.xyz, r16.xyzx, t13.xyzw, s0, l(0)
 204:       mad r16.xyz, r16.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 205:       mul r16.xyz, r20.xxxx, r16.xyzx
 206:       mov r16.w, r20.x
 207:       mad r14.xyzw, r16.xyzw, r11.wwww, r14.xyzw
 208:       mad r16.xyz, r18.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 209:       mul r20.xyz, r20.wwww, r16.xyzx
 210:       mad r15.xyzw, r20.xyzw, r11.wwww, r15.xyzw
 211:       mad r12.z, r18.w, r11.w, r12.z
 212:     endif
 213:     mad_sat r11.w, r12.z, l(2.000000), l(-1.000000)
 214:     add r16.x, -r8.w, r11.w
 215:     add r8.w, r8.w, r11.w
 216:     mul r16.y, r8.w, l(0.500000)
 217:   else
 218:     mov r17.xyzw, l(0, 0, 0, 0)
 219:     mov r14.xyzw, l(0, 0, 0, 0)
 220:     mov r15.xyzw, l(0, 0, 0, 0)
 221:     mov r16.xy, l(0.000000, 1.000000, 0.000000, 0.000000)
 222:   endif
 223:   mul r18.xyzw, r16.yyyx, cb1[138].xyzw
 224:   mad r18.y, r18.w, l(0.500000), r18.y
 225:   mul r12.yz, r16.yyxy, cb1[138].wwyw
 226:   mad r18.w, r12.z, l(0.375000), r12.y
 227:   add r15.xyzw, r15.xyzw, r18.xyzw
 228:   mul r18.xyzw, r16.yyyx, cb1[139].xyzw
 229:   mad r18.y, r18.w, l(0.500000), r18.y
 230:   mul r12.yz, r16.yyxy, cb1[139].wwyw
 231:   mad r18.w, r12.z, l(0.375000), r12.y
 232:   add r14.xyzw, r14.xyzw, r18.xyzw
 233:   mul r18.xyzw, r16.yyyx, cb1[140].xyzw
 234:   mad r18.y, r18.w, l(0.500000), r18.y
 235:   mul r12.yz, r16.yyxy, cb1[140].wwyw
 236:   mad r18.w, r12.z, l(0.375000), r12.y
 237:   add r16.xyzw, r17.xyzw, r18.xyzw
 238:   mov r10.w, l(1.000000)
 239:   dp4 r17.x, r15.xyzw, r10.xyzw
 240:   dp4 r17.y, r14.xyzw, r10.xyzw
 241:   dp4 r17.z, r16.xyzw, r10.xyzw
 242:   max r17.xyz, r17.xyzx, l(0, 0, 0, 0)
 243:   mul r18.xyz, r7.wwww, r17.xyzx
 244:   mul r19.xyz, r14.xyzx, l(0.715200, 0.715200, 0.715200, 0.000000)
 245:   mad r19.xyz, r15.xyzx, l(0.212600, 0.212600, 0.212600, 0.000000), r19.xyzx
 246:   mad r19.xyz, r16.xyzx, l(0.072200, 0.072200, 0.072200, 0.000000), r19.xyzx
 247:   dp3 r8.w, r19.xyzx, r19.xyzx
 248:   max r8.w, r8.w, l(0.000000)
 249:   rsq r8.w, r8.w
 250:   mul r19.xyz, r8.wwww, r19.xyzx
 251:   mov r19.y, abs(r19.y)
 252:   mov r19.w, l(1.000000)
 253:   dp4 r15.x, r15.xyzw, r19.xyzw
 254:   dp4 r15.y, r14.xyzw, r19.xyzw
 255:   dp4 r15.z, r16.xyzw, r19.xyzw
 256:   max r14.xyz, r15.xyzx, l(0, 0, 0, 0)
 257:   ge r8.w, r18.y, r18.z
 258:   and r8.w, r8.w, l(1.000000)
 259:   mov r15.xy, r18.zyzz
 260:   mov r15.zw, l(0.000000, 0.000000, -1.000000, 0.666667)
 261:   mad r16.xy, r17.yzyy, r7.wwww, -r15.xyxx
 262:   mov r16.zw, l(0.000000, 0.000000, 1.000000, -1.000000)
 263:   mad r15.xyzw, r8.wwww, r16.xyzw, r15.xyzw
 264:   ge r8.w, r18.x, r15.x
 265:   and r8.w, r8.w, l(1.000000)
 266:   mov r16.xyz, r15.xywx
 267:   mov r16.w, r18.x
 268:   mov r15.xyw, r16.wywx
 269:   add r15.xyzw, -r16.xyzw, r15.xyzw
 270:   mad r15.xyzw, r8.wwww, r15.xyzw, r16.xyzw
 271:   min r8.w, r15.y, r15.w
 272:   add r8.w, -r8.w, r15.x
 273:   add r10.w, -r15.y, r15.w
 274:   mad r11.w, r8.w, l(6.000000), l(0.000100)
 275:   div r10.w, r10.w, r11.w
 276:   add r10.w, r10.w, r15.z
 277:   frc r10.w, abs(r10.w)
 278:   add r11.w, r15.x, l(0.000100)
 279:   div r8.w, r8.w, r11.w
 280:   add r16.xyzw, r10.wwww, l(-0.500000, 1.000000, 0.666667, 0.333333)
 281:   add r10.w, abs(r16.x), l(-0.450000)
 282:   mul_sat r10.w, r10.w, l(-10.000001)
 283:   mad r11.w, r10.w, l(-2.000000), l(3.000000)
 284:   mul r10.w, r10.w, r10.w
 285:   mul r10.w, r10.w, r11.w
 286:   mad r10.w, r10.w, l(-0.350000), l(0.700000)
 287:   mov_sat r15.x, r15.x
 288:   mul r10.w, r10.w, r15.x
 289:   min r8.w, r8.w, r10.w
 290:   add r10.w, -r8.w, l(2.000000)
 291:   div r10.w, l(2.000000), r10.w
 292:   frc r15.xyz, r16.yzwy
 293:   mad r15.xyz, r15.xyzx, l(6.000000, 6.000000, 6.000000, 0.000000), l(-3.000000, -3.000000, -3.000000, 0.000000)
 294:   add_sat r15.xyz, abs(r15.xyzx), l(-1.000000, -1.000000, -1.000000, 0.000000)
 295:   add r15.xyz, r15.xyzx, l(-1.000000, -1.000000, -1.000000, 0.000000)
 296:   mad r15.xyz, r8.wwww, r15.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 297:   mul r15.xyz, r10.wwww, r15.xyzx
 298:   max r8.w, r14.y, r14.x
 299:   max r8.w, r14.z, r8.w
 300:   mul r7.w, r7.w, r8.w
 301:   mov r8.w, l(1.000000)
 302: else
 303:   mov r19.xyz, l(0, 0, 0, 0)
 304:   mov r18.xyz, l(1.000000, 1.000000, 1.000000, 0.000000)
 305:   mov r15.xyz, cb1[112].xyzx
 306:   mov r8.w, l(0)
 307: endif
 308: mad r10.w, r12.x, l(0.003922), r4.w
 309: min r10.w, r10.w, l(1.000000)
 310: add r10.w, r10.w, -cb6[5].x
 311: lt r10.w, l(0.010000), r10.w
 312: if_nz r10.w
 313:   add r10.w, -r6.x, l(1.000000)
 314:   mul r14.xyz, r5.xyzx, r10.wwww
 315:   dp3 r11.w, r14.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 316:   add r11.w, r11.w, l(-0.350000)
 317:   mul_sat r11.w, r11.w, l(-4.000000)
 318:   mad r12.y, r11.w, l(-2.000000), l(3.000000)
 319:   mul r11.w, r11.w, r11.w
 320:   mul r12.z, r11.w, r12.y
 321:   mul r14.xyzw, v8.xyxz, l(1.000000, -1.000000, 1.000000, 1.000000)
 322:   movc r14.xyzw, r3.xxxx, r14.xyzw, v8.xzxy
 323:   mul r16.xyzw, r14.xyzw, cb1[120].zzzz
 324:   movc r17.yz, r3.xxxx, v7.zzyz, v7.yyzy
 325:   mov r17.x, v7.x
 326:   add r20.xyz, abs(r17.xyzx), l(-0.200000, -0.200000, -0.200000, 0.000000)
 327:   mul r21.xyz, r20.xyzx, r20.xyzx
 328:   mul r21.xyz, r20.xyzx, r21.xyzx
 329:   max r21.xyz, r21.xyzx, l(0.000061, 0.000061, 0.000061, 0.000000)
 330:   dp3 r13.y, r21.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 331:   div r21.xyz, r21.xyzx, r13.yyyy
 332:   sample_b(texture2d)(float,float,float,float) r22.xyzw, r16.zyzz, t16.xyzw, s1, cb1[26].x
 333:   sample_b(texture2d)(float,float,float,float) r23.xyzw, r16.zwzz, t16.xyzw, s1, cb1[26].x
 334:   mul r23.xyzw, r21.zzzz, r23.xyzw
 335:   mad r22.xyzw, r22.xyzw, r21.yyyy, r23.xyzw
 336:   sample_b(texture2d)(float,float,float,float) r23.xyzw, r16.ywyy, t16.xyzw, s1, cb1[26].x
 337:   mad r21.xyzw, r23.xyzw, r21.xxxx, r22.xyzw
 338:   add r13.yz, -r21.wwww, l(0.000000, 0.800000, 0.450000, 0.000000)
 339:   mul r22.xyz, r10.yyxy, l(0.200000, 0.000000, 1.000000, 0.000000)
 340:   mad_sat r14.x, r13.x, r10.w, r22.x
 341:   add r13.y, -r13.y, r14.x
 342:   mul_sat r13.y, r13.y, l(3.333333)
 343:   mad r14.x, r13.y, l(-2.000000), l(3.000000)
 344:   mul r13.y, r13.y, r13.y
 345:   mul r13.y, r13.y, r14.x
 346:   mul_sat r3.w, r3.w, r10.w
 347:   add r3.w, -r13.z, r3.w
 348:   mul_sat r3.w, r3.w, l(1.538461)
 349:   mad r10.w, r3.w, l(-2.000000), l(3.000000)
 350:   mul r3.w, r3.w, r3.w
 351:   mul r3.w, r3.w, r10.w
 352:   max r3.w, r3.w, r13.y
 353:   add r10.w, r6.x, l(-0.500000)
 354:   mul_sat r10.w, r10.w, l(4.000000)
 355:   mad r13.y, r10.w, l(-2.000000), l(3.000000)
 356:   mul r10.w, r10.w, r10.w
 357:   mul r10.w, r10.w, r13.y
 358:   add r6.w, -r6.w, l(0.200000)
 359:   mul_sat r6.w, r6.w, l(-5.000000)
 360:   mad r13.y, r6.w, l(-2.000000), l(3.000000)
 361:   mul r6.w, r6.w, r6.w
 362:   mul r6.w, r6.w, r13.y
 363:   mad r13.y, r6.w, r12.z, r10.w
 364:   min r13.y, r13.y, l(1.000000)
 365:   max r13.x, r4.w, r13.x
 366:   mul r13.z, r13.x, r13.y
 367:   ge r12.x, l(2.550000), r12.x
 368:   and r12.x, r12.x, l(1.000000)
 369:   ge r14.x, r4.w, l(0.010000)
 370:   and r14.x, r14.x, l(1.000000)
 371:   mul r12.x, r12.x, r14.x
 372:   eq r12.x, r12.x, l(0)
 373:   add r4.w, -r4.w, l(1.000000)
 374:   movc r17.yw, r12.xxxx, l(0.000000, 3.000000, 0.000000, 4.345600), r4.wwww
 375:   mad r22.xw, -r13.yyyy, r13.xxxx, l(1.000000, 0.000000, 0.000000, 1.010000)
 376:   movc r4.w, r12.x, cb1[20].x, l(1.000000)
 377:   mul r23.xyz, r16.yzwy, l(20.000000, 20.000000, 20.000000, 0.000000)
 378:   mul r24.xyz, r16.yzwy, l(34.345600, 34.345600, 34.345600, 0.000000)
 379:   max r20.xyz, r20.xyzx, l(0, 0, 0, 0)
 380:   mul r20.xyz, r20.xyzx, r20.xyzx
 381:   mul r25.xyz, r20.xyzx, r20.xyzx
 382:   mul r25.xyz, r25.xyzx, r25.xyzx
 383:   mul r20.xyz, r20.xyzx, r25.xyzx
 384:   dp3 r14.x, r20.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 385:   max r14.x, r14.x, l(0.000061)
 386:   div r20.xyz, r20.xyzx, r14.xxxx
 387:   round_ni r25.xyzw, r23.yxyz
 388:   mul r26.xyzw, r25.xyzw, l(123.339996, 456.209991, 123.339996, 456.209991)
 389:   frc r26.xyzw, r26.xyzw
 390:   add r27.xyzw, r26.xyzw, l(34.345001, 34.345001, 34.345001, 34.345001)
 391:   dp2 r14.x, r26.xyxx, r27.xyxx
 392:   add r23.yw, r14.xxxx, r26.xxxy
 393:   mul r14.x, r23.w, r23.y
 394:   add r15.w, r23.w, r23.y
 395:   frc r14.x, r14.x
 396:   frc r15.w, r15.w
 397:   add r28.xyzw, r25.xyzw, l(114.514000, 114.514000, 114.514000, 114.514000)
 398:   mul r28.xyzw, r28.xyzw, l(123.339996, 456.209991, 123.339996, 456.209991)
 399:   frc r28.xyzw, r28.xyzw
 400:   add r29.xyzw, r28.xyzw, l(34.345001, 34.345001, 34.345001, 34.345001)
 401:   dp2 r18.w, r28.xyxx, r29.xyxx
 402:   add r23.yw, r18.wwww, r28.xxxy
 403:   mul r18.w, r23.w, r23.y
 404:   add r19.w, r23.w, r23.y
 405:   frc r26.x, r18.w
 406:   frc r26.y, r19.w
 407:   mad r18.w, r14.x, l(0.400000), l(0.600000)
 408:   mul r19.w, r18.w, l(0.250000)
 409:   mad r25.xyzw, r16.zyzw, l(20.000000, 20.000000, 20.000000, 20.000000), -r25.xyzw
 410:   mad r23.yw, r26.xxxy, l(0.000000, 2.000000, 0.000000, 2.000000), l(0.000000, -1.000000, 0.000000, -1.000000)
 411:   mad r23.yw, r23.yyyw, l(0.000000, 0.250000, 0.000000, 0.250000), r25.xxxy
 412:   add r23.yw, r23.yyyw, l(0.000000, -0.500000, 0.000000, -0.500000)
 413:   mul r25.x, r23.y, l(1.250000)
 414:   lt r20.w, r23.w, l(0)
 415:   movc r20.w, r20.w, l(1.250000), l(0.750000)
 416:   mul r25.y, r20.w, r23.w
 417:   mad r14.x, r4.w, r17.y, r14.x
 418:   frc r20.w, r14.x
 419:   mov_sat r14.x, r14.x
 420:   mad r14.x, r14.x, l(0.630000), l(0.220000)
 421:   movc r14.x, r12.x, r20.w, r14.x
 422:   add r23.yw, r14.xxxx, l(0.000000, -0.200000, 0.000000, -0.850000)
 423:   mul_sat r23.yw, r23.yyyw, l(0.000000, 50.000011, 0.000000, -3.333333)
 424:   mad r27.xy, r23.ywyy, l(-2.000000, -2.000000, 0.000000, 0.000000), l(3.000000, 3.000000, 0.000000, 0.000000)
 425:   mul r23.yw, r23.yyyw, r23.yyyw
 426:   mul r23.yw, r23.yyyw, r27.xxxy
 427:   mul r14.x, r23.w, r23.y
 428:   dp2 r20.w, r25.xyxx, r25.xyxx
 429:   sqrt r20.w, r20.w
 430:   mad r18.w, -r18.w, l(0.250000), r20.w
 431:   div r20.w, l(1.000000, 1.000000, 1.000000, 1.000000), -r19.w
 432:   mul_sat r18.w, r18.w, r20.w
 433:   mad r20.w, r18.w, l(-2.000000), l(3.000000)
 434:   mul r18.w, r18.w, r18.w
 435:   mul r18.w, r18.w, r20.w
 436:   ge r18.w, r18.w, l(0.001000)
 437:   and r18.w, r18.w, l(1.000000)
 438:   mul r14.x, r14.x, r18.w
 439:   add r15.w, r15.w, l(-0.100000)
 440:   ge r15.w, r15.w, r22.x
 441:   and r15.w, r15.w, l(1.000000)
 442:   mul r14.x, r14.x, r15.w
 443:   mul r15.w, r20.y, r14.x
 444:   dp2 r18.w, r26.zwzz, r27.zwzz
 445:   add r23.yw, r18.wwww, r26.zzzw
 446:   mul r18.w, r23.w, r23.y
 447:   add r20.w, r23.w, r23.y
 448:   frc r18.w, r18.w
 449:   frc r20.w, r20.w
 450:   dp2 r21.w, r28.zwzz, r29.zwzz
 451:   add r23.yw, r21.wwww, r28.zzzw
 452:   mul r21.w, r23.w, r23.y
 453:   add r23.y, r23.w, r23.y
 454:   frc r27.x, r21.w
 455:   frc r27.y, r23.y
 456:   mad r21.w, r18.w, l(0.400000), l(0.600000)
 457:   mul r23.y, r21.w, l(0.250000)
 458:   mad r26.yz, r27.xxyx, l(0.000000, 2.000000, 2.000000, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
 459:   mad r25.zw, r26.yyyz, l(0.000000, 0.000000, 0.250000, 0.250000), r25.zzzw
 460:   add r25.zw, r25.zzzw, l(0.000000, 0.000000, -0.500000, -0.500000)
 461:   mul r28.x, r25.z, l(1.250000)
 462:   lt r23.w, r25.w, l(0)
 463:   movc r23.w, r23.w, l(1.250000), l(0.750000)
 464:   mul r28.y, r23.w, r25.w
 465:   mad r18.w, r4.w, r17.y, r18.w
 466:   frc r23.w, r18.w
 467:   mov_sat r18.w, r18.w
 468:   mad r18.w, r18.w, l(0.630000), l(0.220000)
 469:   movc r18.w, r12.x, r23.w, r18.w
 470:   add r25.zw, r18.wwww, l(0.000000, 0.000000, -0.200000, -0.850000)
 471:   mul_sat r25.zw, r25.zzzw, l(0.000000, 0.000000, 50.000011, -3.333333)
 472:   mad r26.yz, r25.zzwz, l(0.000000, -2.000000, -2.000000, 0.000000), l(0.000000, 3.000000, 3.000000, 0.000000)
 473:   mul r25.zw, r25.zzzw, r25.zzzw
 474:   mul r25.zw, r25.zzzw, r26.yyyz
 475:   mul r18.w, r25.w, r25.z
 476:   dp2 r23.w, r28.xyxx, r28.xyxx
 477:   sqrt r23.w, r23.w
 478:   mad r21.w, -r21.w, l(0.250000), r23.w
 479:   div r23.w, l(1.000000, 1.000000, 1.000000, 1.000000), -r23.y
 480:   mul_sat r21.w, r21.w, r23.w
 481:   mad r23.w, r21.w, l(-2.000000), l(3.000000)
 482:   mul r21.w, r21.w, r21.w
 483:   mul r21.w, r21.w, r23.w
 484:   ge r21.w, r21.w, l(0.001000)
 485:   and r21.w, r21.w, l(1.000000)
 486:   mul r18.w, r18.w, r21.w
 487:   add r20.w, r20.w, l(-0.100000)
 488:   ge r20.w, r20.w, r22.x
 489:   and r20.w, r20.w, l(1.000000)
 490:   mul r18.w, r18.w, r20.w
 491:   mul r20.w, r20.z, r18.w
 492:   round_ni r23.xz, r23.xxzx
 493:   mul r25.zw, r23.xxxz, l(0.000000, 0.000000, 123.339996, 456.209991)
 494:   frc r25.zw, r25.zzzw
 495:   add r26.yz, r25.zzwz, l(0.000000, 34.345001, 34.345001, 0.000000)
 496:   dp2 r21.w, r25.zwzz, r26.yzyy
 497:   add r25.zw, r21.wwww, r25.zzzw
 498:   mul r21.w, r25.w, r25.z
 499:   add r23.w, r25.w, r25.z
 500:   frc r21.w, r21.w
 501:   frc r23.w, r23.w
 502:   add r25.zw, r23.xxxz, l(0.000000, 0.000000, 114.514000, 114.514000)
 503:   mul r25.zw, r25.zzzw, l(0.000000, 0.000000, 123.339996, 456.209991)
 504:   frc r25.zw, r25.zzzw
 505:   add r26.yz, r25.zzwz, l(0.000000, 34.345001, 34.345001, 0.000000)
 506:   dp2 r24.w, r25.zwzz, r26.yzyy
 507:   add r25.zw, r24.wwww, r25.zzzw
 508:   mul r24.w, r25.w, r25.z
 509:   add r25.z, r25.w, r25.z
 510:   frc r29.x, r24.w
 511:   frc r29.y, r25.z
 512:   mad r24.w, r21.w, l(0.400000), l(0.600000)
 513:   mul r25.z, r24.w, l(0.250000)
 514:   mad r23.xz, r16.yywy, l(20.000000, 0.000000, 20.000000, 0.000000), -r23.xxzx
 515:   mad r26.yz, r29.xxyx, l(0.000000, 2.000000, 2.000000, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
 516:   mad r23.xz, r26.yyzy, l(0.250000, 0.000000, 0.250000, 0.000000), r23.xxzx
 517:   add r23.xz, r23.xxzx, l(-0.500000, 0.000000, -0.500000, 0.000000)
 518:   mul r30.x, r23.x, l(1.250000)
 519:   lt r23.x, r23.z, l(0)
 520:   movc r23.x, r23.x, l(1.250000), l(0.750000)
 521:   mul r30.y, r23.x, r23.z
 522:   mad r17.y, r4.w, r17.y, r21.w
 523:   frc r21.w, r17.y
 524:   mov_sat r17.y, r17.y
 525:   mad r17.y, r17.y, l(0.630000), l(0.220000)
 526:   movc r17.y, r12.x, r21.w, r17.y
 527:   add r23.xz, r17.yyyy, l(-0.200000, 0.000000, -0.850000, 0.000000)
 528:   mul_sat r23.xz, r23.xxzx, l(50.000011, 0.000000, -3.333333, 0.000000)
 529:   mad r26.yz, r23.xxzx, l(0.000000, -2.000000, -2.000000, 0.000000), l(0.000000, 3.000000, 3.000000, 0.000000)
 530:   mul r23.xz, r23.xxzx, r23.xxzx
 531:   mul r23.xz, r23.xxzx, r26.yyzy
 532:   mul r17.y, r23.z, r23.x
 533:   dp2 r21.w, r30.xyxx, r30.xyxx
 534:   sqrt r21.w, r21.w
 535:   mad r21.w, -r24.w, l(0.250000), r21.w
 536:   div r23.x, l(1.000000, 1.000000, 1.000000, 1.000000), -r25.z
 537:   mul_sat r21.w, r21.w, r23.x
 538:   mad r23.x, r21.w, l(-2.000000), l(3.000000)
 539:   mul r21.w, r21.w, r21.w
 540:   mul r21.w, r21.w, r23.x
 541:   ge r21.w, r21.w, l(0.001000)
 542:   and r21.w, r21.w, l(1.000000)
 543:   mul r17.y, r17.y, r21.w
 544:   add r21.w, r23.w, l(-0.100000)
 545:   ge r21.w, r21.w, r22.x
 546:   and r21.w, r21.w, l(1.000000)
 547:   mul r17.y, r17.y, r21.w
 548:   mul r21.w, r20.x, r17.y
 549:   div r23.xz, r25.xxyx, r19.wwww
 550:   max r23.xz, r23.xxzx, l(-1.000000, 0.000000, -1.000000, 0.000000)
 551:   min r23.xz, r23.xxzx, l(1.000000, 0.000000, 1.000000, 0.000000)
 552:   mad r23.w, r26.x, l(0.250000), l(0.250000)
 553:   mul r23.xz, r23.wwww, r23.xxzx
 554:   mul r23.xz, r14.xxxx, r23.xxzx
 555:   div r25.xy, r28.xyxx, r23.yyyy
 556:   max r25.xy, r25.xyxx, l(-1.000000, -1.000000, 0.000000, 0.000000)
 557:   min r25.xy, r25.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 558:   mad r23.w, r27.x, l(0.250000), l(0.250000)
 559:   mul r25.xy, r23.wwww, r25.xyxx
 560:   mul r25.xy, r18.wwww, r25.xyxx
 561:   mul r25.xy, r20.zzzz, r25.xyxx
 562:   mad r23.xz, r23.xxzx, r20.yyyy, r25.xxyx
 563:   div r25.xy, r30.xyxx, r25.zzzz
 564:   max r25.xy, r25.xyxx, l(-1.000000, -1.000000, 0.000000, 0.000000)
 565:   min r25.xy, r25.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 566:   mad r23.w, r29.x, l(0.250000), l(0.250000)
 567:   mul r25.xy, r23.wwww, r25.xyxx
 568:   mul r25.xy, r17.yyyy, r25.xyxx
 569:   mad r23.xz, r25.xxyx, r20.xxxx, r23.xxzx
 570:   max r15.w, r15.w, r20.w
 571:   max r15.w, r15.w, r21.w
 572:   round_ni r26.xyzw, r24.yxyz
 573:   mul r27.xyzw, r26.xyzw, l(123.339996, 456.209991, 123.339996, 456.209991)
 574:   frc r27.xyzw, r27.xyzw
 575:   add r28.xyzw, r27.xyzw, l(34.345001, 34.345001, 34.345001, 34.345001)
 576:   dp2 r20.w, r27.xyxx, r28.xyxx
 577:   add r24.yw, r20.wwww, r27.xxxy
 578:   mul r20.w, r24.w, r24.y
 579:   add r21.w, r24.w, r24.y
 580:   frc r20.w, r20.w
 581:   frc r21.w, r21.w
 582:   add r29.xyzw, r26.xyzw, l(114.514000, 114.514000, 114.514000, 114.514000)
 583:   mul r29.xyzw, r29.xyzw, l(123.339996, 456.209991, 123.339996, 456.209991)
 584:   frc r29.xyzw, r29.xyzw
 585:   add r30.xyzw, r29.xyzw, l(34.345001, 34.345001, 34.345001, 34.345001)
 586:   dp2 r23.w, r29.xyxx, r30.xyxx
 587:   add r24.yw, r23.wwww, r29.xxxy
 588:   mul r23.w, r24.w, r24.y
 589:   add r24.y, r24.w, r24.y
 590:   frc r25.x, r23.w
 591:   frc r25.y, r24.y
 592:   mad r23.w, r20.w, l(0.400000), l(0.600000)
 593:   mul r24.y, r23.w, l(0.250000)
 594:   mad r26.xyzw, r16.xyzw, l(34.345600, 34.345600, 34.345600, 34.345600), -r26.xyzw
 595:   mad r25.yw, r25.xxxy, l(0.000000, 2.000000, 0.000000, 2.000000), l(0.000000, -1.000000, 0.000000, -1.000000)
 596:   mad r25.yw, r25.yyyw, l(0.000000, 0.250000, 0.000000, 0.250000), r26.xxxy
 597:   add r25.yw, r25.yyyw, l(0.000000, -0.500000, 0.000000, -0.500000)
 598:   mul r26.x, r25.y, l(1.250000)
 599:   lt r16.x, r25.w, l(0)
 600:   movc r16.x, r16.x, l(1.250000), l(0.750000)
 601:   mul r26.y, r16.x, r25.w
 602:   mad r16.x, r4.w, r17.w, r20.w
 603:   frc r20.w, r16.x
 604:   mov_sat r16.x, r16.x
 605:   mad r16.x, r16.x, l(0.630000), l(0.220000)
 606:   movc r16.x, r12.x, r20.w, r16.x
 607:   add r25.yw, r16.xxxx, l(0.000000, -0.200000, 0.000000, -0.850000)
 608:   mul_sat r25.yw, r25.yyyw, l(0.000000, 50.000011, 0.000000, -3.333333)
 609:   mad r27.xy, r25.ywyy, l(-2.000000, -2.000000, 0.000000, 0.000000), l(3.000000, 3.000000, 0.000000, 0.000000)
 610:   mul r25.yw, r25.yyyw, r25.yyyw
 611:   mul r25.yw, r25.yyyw, r27.xxxy
 612:   mul r16.x, r25.w, r25.y
 613:   dp2 r20.w, r26.xyxx, r26.xyxx
 614:   sqrt r20.w, r20.w
 615:   mad r20.w, -r23.w, l(0.250000), r20.w
 616:   div r23.w, l(1.000000, 1.000000, 1.000000, 1.000000), -r24.y
 617:   mul_sat r20.w, r20.w, r23.w
 618:   mad r23.w, r20.w, l(-2.000000), l(3.000000)
 619:   mul r20.w, r20.w, r20.w
 620:   mul r20.w, r20.w, r23.w
 621:   ge r20.w, r20.w, l(0.001000)
 622:   and r20.w, r20.w, l(1.000000)
 623:   mul r16.x, r16.x, r20.w
 624:   add r20.w, r21.w, l(-0.100000)
 625:   ge r20.w, r20.w, r22.x
 626:   and r20.w, r20.w, l(1.000000)
 627:   mul r16.x, r16.x, r20.w
 628:   mul r20.w, r20.y, r16.x
 629:   dp2 r21.w, r27.zwzz, r28.zwzz
 630:   add r25.yw, r21.wwww, r27.zzzw
 631:   mul r21.w, r25.w, r25.y
 632:   add r23.w, r25.w, r25.y
 633:   frc r21.w, r21.w
 634:   frc r23.w, r23.w
 635:   dp2 r24.w, r29.zwzz, r30.zwzz
 636:   add r25.yw, r24.wwww, r29.zzzw
 637:   mul r24.w, r25.w, r25.y
 638:   add r25.y, r25.w, r25.y
 639:   frc r27.x, r24.w
 640:   frc r27.y, r25.y
 641:   mad r24.w, r21.w, l(0.400000), l(0.600000)
 642:   mul r25.y, r24.w, l(0.250000)
 643:   mad r27.yz, r27.xxyx, l(0.000000, 2.000000, 2.000000, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
 644:   mad r26.zw, r27.yyyz, l(0.000000, 0.000000, 0.250000, 0.250000), r26.zzzw
 645:   add r26.zw, r26.zzzw, l(0.000000, 0.000000, -0.500000, -0.500000)
 646:   mul r28.x, r26.z, l(1.250000)
 647:   lt r25.w, r26.w, l(0)
 648:   movc r25.w, r25.w, l(1.250000), l(0.750000)
 649:   mul r28.y, r25.w, r26.w
 650:   mad r21.w, r4.w, r17.w, r21.w
 651:   frc r25.w, r21.w
 652:   mov_sat r21.w, r21.w
 653:   mad r21.w, r21.w, l(0.630000), l(0.220000)
 654:   movc r21.w, r12.x, r25.w, r21.w
 655:   add r26.zw, r21.wwww, l(0.000000, 0.000000, -0.200000, -0.850000)
 656:   mul_sat r26.zw, r26.zzzw, l(0.000000, 0.000000, 50.000011, -3.333333)
 657:   mad r27.yz, r26.zzwz, l(0.000000, -2.000000, -2.000000, 0.000000), l(0.000000, 3.000000, 3.000000, 0.000000)
 658:   mul r26.zw, r26.zzzw, r26.zzzw
 659:   mul r26.zw, r26.zzzw, r27.yyyz
 660:   mul r21.w, r26.w, r26.z
 661:   dp2 r25.w, r28.xyxx, r28.xyxx
 662:   sqrt r25.w, r25.w
 663:   mad r24.w, -r24.w, l(0.250000), r25.w
 664:   div r25.w, l(1.000000, 1.000000, 1.000000, 1.000000), -r25.y
 665:   mul_sat r24.w, r24.w, r25.w
 666:   mad r25.w, r24.w, l(-2.000000), l(3.000000)
 667:   mul r24.w, r24.w, r24.w
 668:   mul r24.w, r24.w, r25.w
 669:   ge r24.w, r24.w, l(0.001000)
 670:   and r24.w, r24.w, l(1.000000)
 671:   mul r21.w, r21.w, r24.w
 672:   add r23.w, r23.w, l(-0.100000)
 673:   ge r23.w, r23.w, r22.x
 674:   and r23.w, r23.w, l(1.000000)
 675:   mul r21.w, r21.w, r23.w
 676:   mul r23.w, r20.z, r21.w
 677:   round_ni r24.xz, r24.xxzx
 678:   mul r26.zw, r24.xxxz, l(0.000000, 0.000000, 123.339996, 456.209991)
 679:   frc r26.zw, r26.zzzw
 680:   add r27.yz, r26.zzwz, l(0.000000, 34.345001, 34.345001, 0.000000)
 681:   dp2 r24.w, r26.zwzz, r27.yzyy
 682:   add r26.zw, r24.wwww, r26.zzzw
 683:   mul r24.w, r26.w, r26.z
 684:   add r25.w, r26.w, r26.z
 685:   frc r24.w, r24.w
 686:   frc r25.w, r25.w
 687:   add r26.zw, r24.xxxz, l(0.000000, 0.000000, 114.514000, 114.514000)
 688:   mul r26.zw, r26.zzzw, l(0.000000, 0.000000, 123.339996, 456.209991)
 689:   frc r26.zw, r26.zzzw
 690:   add r27.yz, r26.zzwz, l(0.000000, 34.345001, 34.345001, 0.000000)
 691:   dp2 r27.y, r26.zwzz, r27.yzyy
 692:   add r26.zw, r26.zzzw, r27.yyyy
 693:   mul r27.y, r26.w, r26.z
 694:   add r26.z, r26.w, r26.z
 695:   frc r29.x, r27.y
 696:   frc r29.y, r26.z
 697:   mad r26.z, r24.w, l(0.400000), l(0.600000)
 698:   mul r26.w, r26.z, l(0.250000)
 699:   mad r24.xz, r16.yywy, l(34.345600, 0.000000, 34.345600, 0.000000), -r24.xxzx
 700:   mad r27.yz, r29.xxyx, l(0.000000, 2.000000, 2.000000, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
 701:   mad r24.xz, r27.yyzy, l(0.250000, 0.000000, 0.250000, 0.000000), r24.xxzx
 702:   add r24.xz, r24.xxzx, l(-0.500000, 0.000000, -0.500000, 0.000000)
 703:   mul r30.x, r24.x, l(1.250000)
 704:   lt r24.x, r24.z, l(0)
 705:   movc r24.x, r24.x, l(1.250000), l(0.750000)
 706:   mul r30.y, r24.x, r24.z
 707:   mad r4.w, r4.w, r17.w, r24.w
 708:   frc r17.w, r4.w
 709:   mov_sat r4.w, r4.w
 710:   mad r4.w, r4.w, l(0.630000), l(0.220000)
 711:   movc r4.w, r12.x, r17.w, r4.w
 712:   add r24.xz, r4.wwww, l(-0.200000, 0.000000, -0.850000, 0.000000)
 713:   mul_sat r24.xz, r24.xxzx, l(50.000011, 0.000000, -3.333333, 0.000000)
 714:   mad r27.yz, r24.xxzx, l(0.000000, -2.000000, -2.000000, 0.000000), l(0.000000, 3.000000, 3.000000, 0.000000)
 715:   mul r24.xz, r24.xxzx, r24.xxzx
 716:   mul r24.xz, r24.xxzx, r27.yyzy
 717:   mul r4.w, r24.z, r24.x
 718:   dp2 r12.x, r30.xyxx, r30.xyxx
 719:   sqrt r12.x, r12.x
 720:   mad r12.x, -r26.z, l(0.250000), r12.x
 721:   div r17.w, l(1.000000, 1.000000, 1.000000, 1.000000), -r26.w
 722:   mul_sat r12.x, r12.x, r17.w
 723:   mad r17.w, r12.x, l(-2.000000), l(3.000000)
 724:   mul r12.x, r12.x, r12.x
 725:   mul r12.x, r12.x, r17.w
 726:   ge r12.x, r12.x, l(0.001000)
 727:   and r12.x, r12.x, l(1.000000)
 728:   mul r4.w, r4.w, r12.x
 729:   add r12.x, r25.w, l(-0.100000)
 730:   ge r12.x, r12.x, r22.x
 731:   and r12.x, r12.x, l(1.000000)
 732:   mul r4.w, r4.w, r12.x
 733:   mul r12.x, r20.x, r4.w
 734:   div r24.xy, r26.xyxx, r24.yyyy
 735:   max r24.xy, r24.xyxx, l(-1.000000, -1.000000, 0.000000, 0.000000)
 736:   min r24.xy, r24.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 737:   mad r17.w, r25.x, l(0.250000), l(0.250000)
 738:   mul r24.xy, r17.wwww, r24.xyxx
 739:   mul r24.xy, r16.xxxx, r24.xyxx
 740:   div r24.zw, r28.xxxy, r25.yyyy
 741:   max r24.zw, r24.zzzw, l(0.000000, 0.000000, -1.000000, -1.000000)
 742:   min r24.zw, r24.zzzw, l(0.000000, 0.000000, 1.000000, 1.000000)
 743:   mad r16.x, r27.x, l(0.250000), l(0.250000)
 744:   mul r24.zw, r16.xxxx, r24.zzzw
 745:   mul r24.zw, r21.wwww, r24.zzzw
 746:   mul r24.zw, r20.zzzz, r24.zzzw
 747:   mad r24.xy, r24.xyxx, r20.yyyy, r24.zwzz
 748:   div r24.zw, r30.xxxy, r26.wwww
 749:   max r24.zw, r24.zzzw, l(0.000000, 0.000000, -1.000000, -1.000000)
 750:   min r24.zw, r24.zzzw, l(0.000000, 0.000000, 1.000000, 1.000000)
 751:   mad r16.x, r29.x, l(0.250000), l(0.250000)
 752:   mul r24.zw, r16.xxxx, r24.zzzw
 753:   mul r24.zw, r4.wwww, r24.zzzw
 754:   mad r24.xy, r24.zwzz, r20.xxxx, r24.xyxx
 755:   max r4.w, r20.w, r23.w
 756:   max r4.w, r4.w, r12.x
 757:   mul r12.x, r14.x, r19.w
 758:   mul r12.x, r20.y, r12.x
 759:   mul r14.x, r18.w, r23.y
 760:   mul r14.x, r20.z, r14.x
 761:   mul r16.x, r17.y, r25.z
 762:   mul r16.x, r20.x, r16.x
 763:   max r14.x, r14.x, r16.x
 764:   max r12.x, r12.x, r14.x
 765:   ge r12.x, l(0.010000), r12.x
 766:   and r12.x, r12.x, l(1.000000)
 767:   mad r17.yw, r24.xxxy, r12.xxxx, r23.xxxz
 768:   mad r17.yw, r21.xxxy, l(0.000000, 2.000000, 0.000000, 2.000000), r17.yyyw
 769:   add r17.yw, r17.yyyw, l(0.000000, -1.000000, 0.000000, -1.000000)
 770:   mul r14.x, cb1[20].x, cb1[120].z
 771:   mul r20.y, r14.x, l(0.750000)
 772:   dp2 r14.x, r17.xzxx, r17.xzxx
 773:   max r14.x, r14.x, l(0.000000)
 774:   rsq r14.x, r14.x
 775:   mul r23.x, r14.x, v7.x
 776:   mov r23.y, l(0)
 777:   mul r23.z, r14.x, r17.z
 778:   add r21.xyw, abs(r23.xyxz), l(-0.200000, -0.200000, 0.000000, -0.200000)
 779:   mul r23.xyz, r21.xywx, r21.xywx
 780:   mul r21.xyw, r21.xyxw, r23.xyxz
 781:   max r21.xyw, r21.xyxw, l(0.000061, 0.000061, 0.000000, 0.000061)
 782:   dp3 r14.x, r21.xywx, l(1.000000, 1.000000, 1.000000, 0.000000)
 783:   div r17.xz, r21.xxwx, r14.xxxx
 784:   sample_b(texture2d)(float,float,float,float) r21.xyw, r16.zwzz, t17.xywz, s1, cb1[26].x
 785:   sample_b(texture2d)(float,float,float,float) r16.xyz, r16.ywyy, t17.xyzw, s1, cb1[26].x
 786:   mul r16.xyz, r17.xxxx, r16.xyzx
 787:   mad r16.xyz, r21.xywx, r17.zzzz, r16.xyzx
 788:   mad r16.xy, r16.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
 789:   mov r20.x, l(0)
 790:   mad r14.xyzw, r14.zwyw, cb1[120].zzzz, r20.xyxy
 791:   sample_b(texture2d)(float,float,float,float) r14.x, r14.xyxx, t17.wxyz, s1, cb1[26].x
 792:   sample_b(texture2d)(float,float,float,float) r14.y, r14.zwzz, t17.xwyz, s1, cb1[26].x
 793:   mul r14.y, r17.x, r14.y
 794:   mad r14.x, r14.x, r17.z, r14.y
 795:   mul r14.xy, r14.xxxx, r16.xyxx
 796:   mad r14.xy, r14.xyxx, r13.zzzz, r17.ywyy
 797:   ge r14.w, r15.w, l(0.010000)
 798:   and r14.w, r14.w, l(1.000000)
 799:   mul r14.w, r14.w, r15.w
 800:   mul r4.w, r4.w, r12.x
 801:   max r4.w, r4.w, r14.w
 802:   ge r12.x, r21.z, r22.w
 803:   and r12.x, r12.x, l(1.000000)
 804:   max r4.w, r4.w, r12.x
 805:   add r12.x, -r16.z, l(1.000000)
 806:   mad r12.x, r13.y, r13.x, -r12.x
 807:   mul_sat r12.x, r12.x, l(9.999998)
 808:   mad r13.x, r12.x, l(-2.000000), l(3.000000)
 809:   mul r12.x, r12.x, r12.x
 810:   mul r12.x, r12.x, r13.x
 811:   mul r12.x, r13.z, r12.x
 812:   max r4.w, r4.w, r12.x
 813:   dp2 r12.x, r14.xyxx, r14.xyxx
 814:   min r12.x, r12.x, l(1.000000)
 815:   add r12.x, -r12.x, l(1.000000)
 816:   sqrt r12.x, r12.x
 817:   max r14.z, r12.x, l(0.000000)
 818:   dp3 r12.x, r14.xyzx, r14.xyzx
 819:   rsq r12.x, r12.x
 820:   mul r13.xyz, r12.xxxx, r14.xyzx
 821:   mad r14.xy, -r10.zyzz, l(1.000000, 0.000000, 0.000000, 0.000000), r22.yzyy
 822:   dp2 r12.x, r14.xyxx, r14.xyxx
 823:   lt r14.z, l(0.000061), r12.x
 824:   rsq r12.x, r12.x
 825:   mul r14.xy, r12.xxxx, r14.xyxx
 826:   movc r16.y, r14.z, r14.x, l(1.000000)
 827:   and r16.x, r14.y, r14.z
 828:   min r12.x, r3.y, l(0.050000)
 829:   add r14.x, -r3.y, r12.x
 830:   mad r14.x, r4.w, r14.x, r3.y
 831:   mad r11.w, -r12.y, r11.w, l(1.000000)
 832:   mul r11.w, r3.w, r11.w
 833:   mad r6.w, -r6.w, r12.z, l(1.000000)
 834:   mul r6.w, r6.w, r11.w
 835:   mad r6.w, r6.w, l(-0.500000), l(1.000000)
 836:   mov r16.z, l(0)
 837:   mul r14.yzw, r10.yyzx, r16.xxyz
 838:   mad r14.yzw, r16.zzxy, r10.zzxy, -r14.yyzw
 839:   mul r14.yzw, r13.yyyy, r14.yyzw
 840:   mad r14.yzw, r16.yyzx, r13.xxxx, r14.yyzw
 841:   mad r13.xyz, r10.xyzx, r13.zzzz, r14.yzwy
 842:   dp3 r11.w, r13.xyzx, r13.xyzx
 843:   rsq r11.w, r11.w
 844:   mad r13.xyz, r13.xyzx, r11.wwww, -r10.xyzx
 845:   mad r13.xyz, r4.wwww, r13.xyzx, r10.xyzx
 846:   dp3 r11.w, r13.xyzx, r13.xyzx
 847:   rsq r11.w, r11.w
 848:   mul r13.xyz, r11.wwww, r13.xyzx
 849:   mul r3.w, r12.z, r3.w
 850:   mad r3.w, -r3.w, l(0.200000), r14.x
 851:   min r11.w, r14.x, l(0.200000)
 852:   max r3.y, r3.w, r11.w
 853:   mul r8.xyz, r6.wwww, r8.xyzx
 854:   dp3 r3.w, r5.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 855:   add r3.w, r3.w, l(-0.700000)
 856:   mul_sat r3.w, r3.w, l(-2.500000)
 857:   mad r11.w, r3.w, l(-2.000000), l(3.000000)
 858:   mul r3.w, r3.w, r3.w
 859:   mul r3.w, r3.w, r11.w
 860:   mad r3.w, r3.w, l(0.500000), l(1.000000)
 861:   mul r10.w, r10.w, r4.w
 862:   mad r14.xyz, r5.xyzx, r3.wwww, -r5.xyzx
 863:   mad r14.xyz, r10.wwww, r14.xyzx, r5.xyzx
 864:   mul r5.xyz, r6.wwww, r14.xyzx
 865:   mov r3.w, r4.w
 866: else
 867:   mov r13.xyz, r10.xyzx
 868:   mov r3.w, l(0)
 869:   mov r12.x, l(0.010000)
 870:   mov r4.w, l(0)
 871: endif
 872: mad r6.w, r12.w, l(0.003922), -cb6[5].x
 873: lt r6.w, l(0.010000), r6.w
 874: if_nz r6.w
 875:   mul r14.xyz, v8.xzyx, l(1.000000, 1.000000, -1.000000, 0.000000)
 876:   movc r14.xyz, r3.xxxx, r14.xyzx, v8.xyzx
 877:   mul r14.xzw, r14.xxyz, cb1[120].zzzz
 878:   movc r16.yz, r3.xxxx, v7.zzyz, v7.yyzy
 879:   mov r16.x, v7.x
 880:   add r16.xzw, abs(r16.xxyz), l(-0.200000, 0.000000, -0.200000, -0.200000)
 881:   mul r17.xyz, r16.xzwx, r16.xzwx
 882:   mul r16.xzw, r16.xxzw, r17.xxyz
 883:   max r16.xzw, r16.xxzw, l(0.000061, 0.000000, 0.000061, 0.000061)
 884:   dp3 r3.x, r16.xzwx, l(1.000000, 1.000000, 1.000000, 0.000000)
 885:   div r16.xzw, r16.xxzw, r3.xxxx
 886:   sample_b(texture2d)(float,float,float,float) r17.xyzw, r14.xwxx, t18.xyzw, s1, cb1[26].x
 887:   sample_b(texture2d)(float,float,float,float) r20.xyzw, r14.xzxx, t18.xyzw, s1, cb1[26].x
 888:   mul r20.xyzw, r16.wwww, r20.xyzw
 889:   mad r17.xyzw, r17.xyzw, r16.zzzz, r20.xyzw
 890:   sample_b(texture2d)(float,float,float,float) r20.xyzw, r14.wzww, t18.xyzw, s1, cb1[26].x
 891:   mad r17.xyzw, r20.xyzw, r16.xxxx, r17.xyzw
 892:   add r3.x, r14.y, l(-0.350000)
 893:   mul_sat r3.x, r3.x, l(-6.666667)
 894:   mad r6.w, r3.x, l(-2.000000), l(3.000000)
 895:   mul r3.x, r3.x, r3.x
 896:   mul r3.x, r3.x, r6.w
 897:   mul r6.w, r12.w, l(0.011765)
 898:   min r6.w, r6.w, l(1.000000)
 899:   mad r3.x, r3.x, r6.w, r13.w
 900:   min r3.x, r3.x, l(1.000000)
 901:   add r6.w, -r3.x, l(2.000000)
 902:   mad r6.w, -r3.x, r6.w, l(2.000000)
 903:   mad r10.w, r16.y, l(0.650000), r17.z
 904:   add r10.w, r10.w, l(0.350000)
 905:   add r6.w, -r6.w, r10.w
 906:   mul_sat r6.w, r6.w, l(2.857144)
 907:   mad r10.w, r6.w, l(-2.000000), l(3.000000)
 908:   mul r6.w, r6.w, r6.w
 909:   mul r6.w, r6.w, r10.w
 910:   mul r10.w, r6.z, r6.z
 911:   and r11.w, v10.x, l(1.000000)
 912:   mul r10.w, r10.w, r11.w
 913:   mul r6.w, r6.w, r10.w
 914:   add r10.w, -r6.x, l(1.000000)
 915:   mul r12.yzw, r5.xxyz, r10.wwww
 916:   dp3 r10.w, r12.yzwy, l(0.212673, 0.715152, 0.072175, 0.000000)
 917:   add r10.w, r10.w, l(-0.350000)
 918:   mul_sat r10.w, r10.w, l(-4.000000)
 919:   mad r11.w, r10.w, l(-2.000000), l(3.000000)
 920:   mul r10.w, r10.w, r10.w
 921:   mad r10.w, -r11.w, r10.w, l(1.000000)
 922:   mul r3.x, r3.x, r10.w
 923:   mul r3.x, r17.w, r3.x
 924:   mad r10.w, r16.y, l(0.250000), l(0.750000)
 925:   mul r3.x, r3.x, r10.w
 926:   mad r3.x, r3.x, l(-0.500000), l(1.000000)
 927:   mad r12.yz, r17.xxyx, l(0.000000, 2.000000, 2.000000, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
 928:   dp2 r10.w, r12.yzyy, r12.yzyy
 929:   min r10.w, r10.w, l(1.000000)
 930:   add r10.w, -r10.w, l(1.000000)
 931:   sqrt r10.w, r10.w
 932:   max r14.z, r10.w, l(0.000000)
 933:   add r14.xy, r12.yzyy, r12.yzyy
 934:   add r12.yzw, r14.xxyz, l(0.000000, -0.000000, -0.000000, -1.000000)
 935:   mad r12.yzw, r6.wwww, r12.yyzw, l(0.000000, 0.000000, 0.000000, 1.000000)
 936:   dp3 r10.w, r12.yzwy, r12.yzwy
 937:   max r10.w, r10.w, l(0.000061)
 938:   rsq r10.w, r10.w
 939:   mul r12.yzw, r10.wwww, r12.yyzw
 940:   mad r10.w, -r10.y, r10.y, l(1.000000)
 941:   ge r10.w, r10.w, l(0.010000)
 942:   and r14.y, r10.w, l(1.000000)
 943:   mad r3.z, r9.y, r3.z, -r10.z
 944:   mad r3.z, r14.y, r3.z, r10.z
 945:   movc r14.z, r10.w, l(0), l(1.000000)
 946:   mov r14.x, l(0)
 947:   mad r14.xyz, -r10.xyzx, r3.zzzz, r14.xyzx
 948:   mad r3.z, -r3.z, r3.z, l(1.000000)
 949:   max r3.z, r3.z, l(0.000100)
 950:   rsq r3.z, r3.z
 951:   mul r14.xyz, r3.zzzz, r14.xyzx
 952:   mul r16.xyz, r10.yzxy, r14.zxyz
 953:   mad r16.xyz, r14.yzxy, r10.zxyz, -r16.xyzx
 954:   mul r14.xyz, r12.zzzz, r14.xyzx
 955:   mad r14.xyz, r16.xyzx, r12.yyyy, r14.xyzx
 956:   mad r12.yzw, r10.xxyz, r12.wwww, r14.xxyz
 957:   mul r3.z, r6.w, l(4.000000)
 958:   min r3.z, r3.z, l(1.000000)
 959:   add r9.y, -r3.y, l(0.900000)
 960:   mad r3.y, r3.z, r9.y, r3.y
 961:   mul r14.xyz, r3.xxxx, r8.xyzx
 962:   mad r16.xyz, -r8.xyzx, r3.xxxx, l(0.308000, 0.308000, 0.308000, 0.000000)
 963:   mad r8.xyz, r6.wwww, r16.xyzx, r14.xyzx
 964:   mul r14.xyz, r3.xxxx, r5.xyzx
 965:   mad r16.xyz, -r5.xyzx, r3.xxxx, l(0.880000, 0.880000, 0.880000, 0.000000)
 966:   mad r5.xyz, r6.wwww, r16.xyzx, r14.xyzx
 967:   mad r6.x, r6.w, -r6.x, r6.x
 968: else
 969:   mov r12.yzw, r10.xxyz
 970: endif
 971: mad r3.x, -r6.x, l(0.960000), l(0.960000)
 972: mul r14.xyz, r3.xxxx, r5.xyzx
 973: mul r3.z, r6.y, l(0.040000)
 974: mad r16.xyz, -r6.yyyy, l(0.040000, 0.040000, 0.040000, 0.000000), r5.xyzx
 975: mad r16.xyz, r6.xxxx, r16.xyzx, r3.zzzz
 976: mul r8.xyz, r3.xxxx, r8.xyzx
 977: mul r3.z, r3.y, r3.y
 978: max r3.z, r3.z, l(0.007813)
 979: mul r6.y, r3.z, r3.z
 980: max r6.w, v5.z, l(0.000000)
 981: div r17.xy, v5.xyxx, r6.wwww
 982: max r6.w, v6.z, l(0.000000)
 983: div r17.zw, v6.xxxy, r6.wwww
 984: add r17.xy, -r17.zwzz, r17.xyxx
 985: mul r20.xy, r17.xyxx, l(0.500000, -0.500000, 0.000000, 0.000000)
 986: sqrt r20.xy, abs(r20.xyxx)
 987: sqrt r20.xy, r20.xyxx
 988: mov r17.z, -r17.y
 989: lt r17.yw, l(0, 0, 0, 0), r17.xxxz
 990: lt r17.xz, r17.xxzx, l(0, 0, 0, 0)
 991: iadd r17.xy, -r17.ywyy, r17.xzxx
 992: itof r17.xy, r17.xyxx
 993: mul r17.xy, r17.xyxx, r20.xyxx
 994: mad o1.xy, r17.xyxx, l(0.500000, 0.500000, 0.000000, 0.000000), l(0.500000, 0.500000, 0.000000, 0.000000)
 995: lt r4.w, l(0.100000), r4.w
 996: movc o1.w, r4.w, l(0.700000), l(0.400000)
 997: add r17.xyz, cb1[121].xyzx, cb3[0].xyzx
 998: mad r17.xyz, cb1[111].wwww, r17.xyzx, -cb3[0].xyzx
 999: mov r17.w, l(0.000061)
1000: dp3 r4.w, r17.xzwx, r17.xzwx
1001: rsq r4.w, r4.w
1002: mul r20.xyz, r4.wwww, r17.xwzx
1003: add r21.xyzw, cb1[115].xyzw, -cb3[3].xyzw
1004: mad r21.xyzw, cb1[122].yyyw, r21.xyzw, cb3[3].xyzw
1005: mul r22.xyz, r21.wwww, r21.xyzx
1006: utof r2.w, cb2[r2.w + 5].z
1007: log r2.w, r2.w
1008: add r2.w, r2.w, l(-8.000000)
1009: ge r4.w, r2.w, l(0)
1010: lt r6.w, r2.w, cb5[234].z
1011: and r4.w, r4.w, r6.w
1012: if_nz r4.w
1013:   ftoi r2.w, r2.w
1014:   dp3 r4.w, r9.xzwx, cb5[r2.w + 203].xyzx
1015:   max r4.w, r4.w, l(0)
1016:   min r4.w, r4.w, l(0.900000)
1017:   add r4.w, -r4.w, l(1.000000)
1018:   ishl r6.w, r2.w, l(2)
1019:   mul r23.xy, r4.wwww, cb5[r2.w + 188].xyxx
1020:   mad r23.xzw, -cb5[r2.w + 203].xxyz, r23.xxxx, r7.xxyz
1021:   mad r23.xyz, r9.xzwx, r23.yyyy, r23.xzwx
1022:   mul r24.xyz, r23.yyyy, cb5[r6.w + 129].xyzx
1023:   mad r23.xyw, cb5[r6.w + 128].xyxz, r23.xxxx, r24.xyxz
1024:   mad r23.xyz, cb5[r6.w + 130].xyzx, r23.zzzz, r23.xywx
1025:   add r23.xyz, r23.xyzx, cb5[r6.w + 131].xyzx
1026:   max r4.w, r23.z, l(0.010000)
1027:   ge r23.zw, l(0, 0, 0, 0), r23.xxxy
1028:   ge r24.xy, r23.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
1029:   ge r6.w, r4.w, l(1.000000)
1030:   or r23.zw, r23.zzzw, r24.xxxy
1031:   or r9.y, r23.w, r23.z
1032:   or r6.w, r6.w, r9.y
1033:   if_z r6.w
1034:     mul r9.y, l(4.000000), cb5[233].x
1035:     mad r23.xy, r23.xyxx, cb5[r2.w + 218].zwzz, cb5[r2.w + 218].xyxx
1036:     bfi r2.w, l(2), l(2), r11.x, l(0)
1037:     bfi r2.w, l(2), l(0), r11.y, r2.w
1038:     mul r23.zw, l(0.000000, 0.000000, 1.000000, -1.000000), icb[r2.w + 4].xxxy
1039:     mov r24.xy, l(0, 0, 0, 0)
1040:     mov r10.w, l(0)
1041:     loop
1042:       uge r11.w, r10.w, l(16)
1043:       breakc_nz r11.w
1044:       dp2 r25.x, icb[r10.w + 4].zwzz, r23.zwzz
1045:       dp2 r25.y, icb[r10.w + 4].wzww, icb[r2.w + 4].xyxx
1046:       mad r24.zw, r25.xxxy, r9.yyyy, r23.xxxy
1047:       gather4(texture2d)(float,float,float,float) r25.xyzw, r24.zwzz, t5.xyzw, s0.x
1048:       add r25.xyzw, -r4.wwww, r25.xyzw
1049:       ge r26.xyzw, r25.xyzw, l(0, 0, 0, 0)
1050:       and r26.xyzw, r26.xyzw, l(1.000000, 1.000000, 1.000000, 1.000000)
1051:       dp4 r11.w, r25.xyzw, r26.xyzw
1052:       add r25.x, r11.w, r24.x
1053:       dp4 r11.w, r26.xyzw, l(1.000000, 1.000000, 1.000000, 1.000000)
1054:       add r25.y, r11.w, r24.y
1055:       iadd r11.w, r10.w, l(1)
1056:       mov r24.xy, r25.xyxx
1057:       mov r10.w, r11.w
1058:       continue
1059:     endloop
1060:     mad r2.w, r24.y, l(0.031250), l(-1.000000)
1061:     lt r9.y, l(0), r2.w
1062:     lt r10.w, r2.w, l(0)
1063:     iadd r9.y, -r9.y, r10.w
1064:     itof r9.y, r9.y
1065:     mad r2.w, -r9.y, r2.w, l(1.000000)
1066:     mul r10.w, r2.w, r2.w
1067:     mul r11.w, r2.w, r10.w
1068:     div r13.w, l(1.000000, 1.000000, 1.000000, 1.000000), r24.y
1069:     mul r13.w, r13.w, r24.x
1070:     div r4.w, l(1.000000, 1.000000, 1.000000, 1.000000), r4.w
1071:     mul_sat r4.w, r4.w, r13.w
1072:     mad r2.w, -r10.w, r2.w, r2.w
1073:     mad r2.w, r4.w, r2.w, r11.w
1074:     add r2.w, -r2.w, l(1.000000)
1075:     mul r2.w, r9.y, r2.w
1076:     mad r2.w, -r2.w, l(0.500000), l(0.500000)
1077:     min r2.w, r2.w, l(1.000000)
1078:   endif
1079:   mov r4.w, l(1.000000)
1080: else
1081:   mov r2.w, l(1.000000)
1082:   mov r6.w, l(0)
1083: endif
1084: movc r2.w, r6.w, r4.w, r2.w
1085: lt r4.w, cb5[35].w, l(0.990000)
1086: if_nz r4.w
1087:   ftoi r4.w, cb5[35].x
1088:   ieq r6.w, r4.w, l(2)
1089:   movc r23.xyz, r6.wwww, cb5[20].xyzx, cb0[44].xyzx
1090:   add r23.xyz, r7.xyzx, -r23.xyzx
1091:   dp3 r6.w, r23.xyzx, r23.xyzx
1092:   add r6.w, -r6.w, cb5[34].w
1093:   mul_sat r6.w, r6.w, cb5[34].z
1094:   max r6.w, r6.w, cb5[36].x
1095:   lt r9.y, l(0), r6.w
1096:   if_nz r9.y
1097:     ilt r4.w, l(0), r4.w
1098:     if_nz r4.w
1099:       add r23.xyz, r7.xyzx, -cb5[20].xyzx
1100:       add r24.xyz, r7.xyzx, -cb5[21].xyzx
1101:       add r25.xyz, r7.xyzx, -cb5[22].xyzx
1102:       add r26.xyz, r7.xyzx, -cb5[23].xyzx
1103:       dp3 r4.w, r23.xyzx, r23.xyzx
1104:       dp3 r9.y, r24.xyzx, r24.xyzx
1105:       dp3 r10.w, r25.xyzx, r25.xyzx
1106:       dp3 r11.w, r26.xyzx, r26.xyzx
1107:       lt r23.x, r4.w, cb5[20].w
1108:       lt r23.y, r9.y, cb5[21].w
1109:       lt r23.z, r10.w, cb5[22].w
1110:       lt r23.w, r11.w, cb5[23].w
1111:       and r24.xyzw, r23.xyzw, l(1.000000, 1.000000, 1.000000, 1.000000)
1112:       movc r23.xyz, r23.xyzx, l(-1.000000, -1.000000, -1.000000, 0.000000), l(0x80000000, 0x80000000, 0x80000000, 0)
1113:       add r23.xyz, r23.xyzx, r24.yzwy
1114:       max r24.yzw, r23.xxyz, l(0, 0, 0, 0)
1115:       dp4 r4.w, r24.xyzw, l(4.000000, 3.000000, 2.000000, 1.000000)
1116:       add r4.w, -r4.w, l(4.000000)
1117:       max r4.w, r4.w, l(0)
1118:       min r4.w, r4.w, l(3.000000)
1119:       max r4.w, r4.w, cb5[34].y
1120:       ftou r9.y, r4.w
1121:       ishl r9.y, r9.y, l(2)
1122:       mul r23.xyz, r7.yyyy, cb5[r9.y + 1].xyzx
1123:       mad r23.xyz, cb5[r9.y + 0].xyzx, r7.xxxx, r23.xyzx
1124:       mad r23.xyz, cb5[r9.y + 2].xyzx, r7.zzzz, r23.xyzx
1125:       add r23.xyz, r23.xyzx, cb5[r9.y + 3].xyzx
1126:       ge r24.xyz, l(0, 0, 0, 0), r23.xyzx
1127:       ge r25.xyz, r23.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
1128:       or r24.xyz, r24.xyzx, r25.xyzx
1129:       or r9.y, r24.y, r24.x
1130:       or r9.y, r24.z, r9.y
1131:       and r10.w, r23.z, l(0x7fffffff)
1132:       ult r10.w, l(0x7f800000), r10.w
1133:       or r24.z, r9.y, r10.w
1134:       ftoi r4.w, r4.w
1135:       mad r23.xy, r23.xyxx, cb5[r4.w + 28].zwzz, cb5[r4.w + 28].xyxx
1136:       mad r25.xy, r23.xyxx, cb5[32].zwzz, l(0.500000, 0.500000, 0.000000, 0.000000)
1137:       round_ni r25.xy, r25.xyxx
1138:       mad r23.xy, r23.xyxx, cb5[32].zwzz, -r25.xyxx
1139:       add r26.xyzw, r23.xxyy, l(0.500000, 1.000000, 0.500000, 1.000000)
1140:       mul r27.xw, r26.xxxz, r26.xxxz
1141:       min r25.zw, r23.xxxy, l(0, 0, 0, 0)
1142:       max r26.xz, r23.xxyx, l(0, 0, 0, 0)
1143:       mad r28.xy, r27.xwxx, l(0.500000, 0.500000, 0.000000, 0.000000), -r23.xyxx
1144:       add r23.xy, -r23.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
1145:       mad r23.xy, -r25.zwzz, r25.zwzz, r23.xyxx
1146:       mad r25.zw, -r26.xxxz, r26.xxxz, r26.yyyw
1147:       mov r26.x, r28.x
1148:       mov r26.y, r23.x
1149:       mov r26.z, r25.z
1150:       mov r26.w, r27.x
1151:       mul r26.xyzw, r26.xyzw, l(0.444440, 0.444440, 0.444440, 0.222220)
1152:       mov r27.x, r28.y
1153:       mov r27.y, r23.y
1154:       mov r27.z, r25.w
1155:       mul r27.xyzw, r27.xyzw, l(0.444440, 0.444440, 0.444440, 0.222220)
1156:       add r28.xyzw, r26.ywyw, r26.xzxz
1157:       add r29.xyzw, r27.yyww, r27.xxzz
1158:       div r23.xy, r26.ywyy, r28.zwzz
1159:       add r23.xy, r23.xyxx, l(-1.500000, 0.500000, 0.000000, 0.000000)
1160:       mul r26.xy, r23.xyxx, cb5[32].xxxx
1161:       div r23.xy, r27.ywyy, r29.ywyy
1162:       add r23.xy, r23.xyxx, l(-1.500000, 0.500000, 0.000000, 0.000000)
1163:       mul r26.zw, r23.xxxy, cb5[32].yyyy
1164:       mul r27.xyzw, r28.xyzw, r29.xyzw
1165:       mad r28.xyzw, r25.xyxy, cb5[32].xyxy, r26.xzyz
1166:       sample_c_lz(texture2d)(float,float,float,float) r4.w, r28.xyxx, t3.xxxx, s2, r23.z
1167:       sample_c_lz(texture2d)(float,float,float,float) r9.y, r28.zwzz, t3.xxxx, s2, r23.z
1168:       mul r9.y, r9.y, r27.y
1169:       mad r4.w, r27.x, r4.w, r9.y
1170:       mad r25.xyzw, r25.xyxy, cb5[32].xyxy, r26.xwyw
1171:       sample_c_lz(texture2d)(float,float,float,float) r9.y, r25.xyxx, t3.xxxx, s2, r23.z
1172:       mad r4.w, r27.z, r9.y, r4.w
1173:       sample_c_lz(texture2d)(float,float,float,float) r9.y, r25.zwzz, t3.xxxx, s2, r23.z
1174:       mad r4.w, r27.w, r9.y, r4.w
1175:       movc r24.x, r24.z, l(1.000000), r4.w
1176:     else
1177:       mov r24.xz, l(1.000000, 0.000000, 0.000000, 0.000000)
1178:     endif
1179:   else
1180:     mov r24.xz, l(1.000000, 0.000000, 0.000000, 0.000000)
1181:   endif
1182:   lt r4.w, r6.w, l(1.000000)
1183:   lt r9.y, l(0.500000), cb5[36].x
1184:   or r4.w, r4.w, r9.y
1185:   if_nz r4.w
1186:     dp3 r4.w, r9.xzwx, cb3[0].xyzx
1187:     max r4.w, r4.w, l(0)
1188:     min r4.w, r4.w, l(0.900000)
1189:     add r4.w, -r4.w, l(1.000000)
1190:     mul r23.xy, r4.wwww, cb5[264].xyxx
1191:     mad r23.xzw, -cb3[0].xxyz, r23.xxxx, r7.xxyz
1192:     mad r23.xyz, r9.xzwx, r23.yyyy, r23.xzwx
1193:     mul r25.xy, r23.yyyy, cb5[261].xyxx
1194:     mad r25.xy, cb5[260].xyxx, r23.xxxx, r25.xyxx
1195:     mad r25.xy, cb5[262].xyxx, r23.zzzz, r25.xyxx
1196:     add r25.xy, r25.xyxx, cb5[263].xyxx
1197:     lt r25.zw, l(0, 0, 0, 0), r25.xxxy
1198:     and r4.w, r25.w, r25.z
1199:     lt r25.zw, r25.xxxy, l(0.000000, 0.000000, 1.000000, 1.000000)
1200:     and r9.y, r25.w, r25.z
1201:     and r4.w, r4.w, r9.y
1202:     if_nz r4.w
1203:       mul r4.w, r25.y, cb5[265].z
1204:       round_ni r4.w, r4.w
1205:       add r4.w, r25.x, r4.w
1206:       mul r4.w, r4.w, cb5[265].y
1207:       ftou r4.w, r4.w
1208:       umin r4.w, r4.w, l(127)
1209:       and r9.y, l(0x0000ffff), cb5[r4.w + 267].x
1210:       f16tof32 r25.x, r9.y
1211:       ge r9.y, r25.x, l(0)
1212:       if_nz r9.y
1213:         mov r26.x, cb5[256].x
1214:         mov r26.y, cb5[257].x
1215:         mov r26.z, cb5[258].x
1216:         mov r26.w, cb5[r4.w + 267].y
1217:         mov r23.w, l(1.000000)
1218:         dp4 r26.x, r26.xyzw, r23.xyzw
1219:         mov r27.x, cb5[256].y
1220:         mov r27.y, cb5[257].y
1221:         mov r27.z, cb5[258].y
1222:         mov r27.w, cb5[r4.w + 267].z
1223:         dp4 r26.y, r27.xyzw, r23.xyzw
1224:         mov r27.x, cb5[256].z
1225:         mov r27.y, cb5[257].z
1226:         mov r27.z, cb5[258].z
1227:         mov r27.w, cb5[r4.w + 267].w
1228:         dp4 r9.y, r27.xyzw, r23.xyzw
1229:         lt r23.xy, l(0, 0, 0, 0), r26.xyxx
1230:         lt r10.w, l(0), r9.y
1231:         and r11.w, r23.y, r23.x
1232:         and r10.w, r10.w, r11.w
1233:         lt r23.xy, r26.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
1234:         lt r11.w, r9.y, l(1.000000)
1235:         and r13.w, r23.y, r23.x
1236:         and r11.w, r11.w, r13.w
1237:         and r10.w, r10.w, r11.w
1238:         if_nz r10.w
1239:           ushr r4.w, cb5[r4.w + 267].x, l(16)
1240:           f16tof32 r25.y, r4.w
1241:           mad r23.xy, r26.xyxx, cb5[264].zwzz, r25.xyxx
1242:           mad r23.zw, r23.xxxy, cb5[266].zzzw, l(0.000000, 0.000000, 0.500000, 0.500000)
1243:           round_ni r23.zw, r23.zzzw
1244:           mad r23.xy, r23.xyxx, cb5[266].zwzz, -r23.zwzz
1245:           add r25.xyzw, r23.xxyy, l(0.500000, 1.000000, 0.500000, 1.000000)
1246:           mul r26.xw, r25.xxxz, r25.xxxz
1247:           min r25.xz, r23.xxyx, l(0, 0, 0, 0)
1248:           max r27.xy, r23.xyxx, l(0, 0, 0, 0)
1249:           mad r27.zw, r26.xxxw, l(0.000000, 0.000000, 0.500000, 0.500000), -r23.xxxy
1250:           add r23.xy, -r23.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
1251:           mad r23.xy, -r25.xzxx, r25.xzxx, r23.xyxx
1252:           mad r25.xy, -r27.xyxx, r27.xyxx, r25.ywyy
1253:           mov r28.x, r27.z
1254:           mov r28.y, r23.x
1255:           mov r28.z, r25.x
1256:           mov r28.w, r26.x
1257:           mul r28.xyzw, r28.xyzw, l(0.444440, 0.444440, 0.444440, 0.222220)
1258:           mov r26.x, r27.w
1259:           mov r26.y, r23.y
1260:           mov r26.z, r25.y
1261:           mul r25.xyzw, r26.xyzw, l(0.444440, 0.444440, 0.444440, 0.222220)
1262:           add r26.xyzw, r28.ywyw, r28.xzxz
1263:           add r27.xyzw, r25.yyww, r25.xxzz
1264:           div r23.xy, r28.ywyy, r26.zwzz
1265:           add r23.xy, r23.xyxx, l(-1.500000, 0.500000, 0.000000, 0.000000)
1266:           mul r28.xy, r23.xyxx, cb5[266].xxxx
1267:           div r23.xy, r25.ywyy, r27.ywyy
1268:           add r23.xy, r23.xyxx, l(-1.500000, 0.500000, 0.000000, 0.000000)
1269:           mul r28.zw, r23.xxxy, cb5[266].yyyy
1270:           mul r25.xyzw, r26.xyzw, r27.xyzw
1271:           mad r26.xyzw, r23.zwzw, cb5[266].xyxy, r28.xzyz
1272:           sample_c_lz(texture2d)(float,float,float,float) r4.w, r26.xyxx, t7.xxxx, s2, r9.y
1273:           sample_c_lz(texture2d)(float,float,float,float) r10.w, r26.zwzz, t7.xxxx, s2, r9.y
1274:           mul r10.w, r10.w, r25.y
1275:           mad r4.w, r25.x, r4.w, r10.w
1276:           mad r23.xyzw, r23.zwzw, cb5[266].xyxy, r28.xwyw
1277:           sample_c_lz(texture2d)(float,float,float,float) r10.w, r23.xyxx, t7.xxxx, s2, r9.y
1278:           mad r4.w, r25.z, r10.w, r4.w
1279:           sample_c_lz(texture2d)(float,float,float,float) r9.y, r23.zwzz, t7.xxxx, s2, r9.y
1280:           mad r24.y, r25.w, r9.y, r4.w
1281:         else
1282:           mov r24.y, l(1.000000)
1283:         endif
1284:       else
1285:         mov r24.y, l(1.000000)
1286:       endif
1287:     else
1288:       mov r24.y, l(1.000000)
1289:     endif
1290:     movc r24.x, r24.z, r24.y, r24.x
1291:   else
1292:     mov r24.y, l(1.000000)
1293:   endif
1294:   add r4.w, -r24.y, r24.x
1295:   mad r4.w, r6.w, r4.w, r24.y
1296:   min r6.w, r24.x, r24.y
1297:   add r6.w, -r4.w, r6.w
1298:   mad r4.w, cb5[36].x, r6.w, r4.w
1299:   lt r6.w, l(0.001000), r4.w
1300:   if_nz r6.w
1301:     add r23.xyz, r7.xyzx, -cb1[93].xyzx
1302:     mad r23.yw, cb1[96].xxxz, r23.yyyy, r23.xxxz
1303:     mul r24.xy, r23.ywyy, cb1[94].zzzz
1304:     mul r24.zw, cb1[95].xxxy, cb1[105].wwww
1305:     add r25.xyz, r7.xyzx, -cb1[97].xyzx
1306:     mul r24.xy, r24.xyxx, cb1[95].wwww
1307:     mad r25.xy, cb1[96].xzxx, r25.yyyy, r25.xzxx
1308:     mad r25.xy, r25.xyxx, cb1[98].xxxx, -r24.xyxx
1309:     mad r24.xy, cb1[97].wwww, r25.xyxx, r24.xyxx
1310:     mad r25.xy, cb1[98].yzyy, cb1[105].wwww, -r24.zwzz
1311:     mad r25.xy, cb1[97].wwww, r25.xyxx, r24.zwzz
1312:     add r24.xy, r24.xyxx, r25.xyxx
1313:     sample_l(texture2d)(float,float,float,float) r24.xy, r24.xyxx, t6.xyzw, s1, l(0)
1314:     mad r23.yw, r23.yyyw, cb1[94].zzzz, r24.zzzw
1315:     sample_l(texture2d)(float,float,float,float) r6.w, r23.ywyy, t6.yzwx, s1, l(0)
1316:     add r9.y, -r24.x, r24.y
1317:     mad r9.y, cb1[97].w, r9.y, r24.x
1318:     dp2 r10.w, r23.xzxx, r23.xzxx
1319:     sqrt r10.w, r10.w
1320:     add r11.w, -cb1[94].x, cb1[94].y
1321:     add r10.w, r10.w, -cb1[94].x
1322:     div r11.w, l(1.000000, 1.000000, 1.000000, 1.000000), r11.w
1323:     mul_sat r10.w, r10.w, r11.w
1324:     mad r11.w, r10.w, l(-2.000000), l(3.000000)
1325:     mul r10.w, r10.w, r10.w
1326:     mul r10.w, r10.w, r11.w
1327:     add r9.y, -r6.w, r9.y
1328:     mad r6.w, r10.w, r9.y, r6.w
1329:     add r6.w, r6.w, l(-1.000000)
1330:     mad r6.w, cb1[95].z, r6.w, l(1.000000)
1331:     mul r4.w, r4.w, r6.w
1332:   endif
1333:   add r6.w, -r4.w, cb5[35].z
1334:   mad r4.w, cb5[35].w, r6.w, r4.w
1335: else
1336:   mov r4.w, cb5[35].z
1337: endif
1338: add r2.w, r2.w, l(-1.000000)
1339: mad r2.w, cb5[34].x, r2.w, l(1.000000)
1340: add r4.w, r4.w, l(-1.000000)
1341: mad r4.w, cb5[34].x, r4.w, l(1.000000)
1342: add r6.w, -r4.w, l(1.000000)
1343: mad r4.w, cb1[111].z, r6.w, r4.w
1344: dp3 r6.w, r12.yzwy, r17.xyzx
1345: mul r23.xyz, r8.xyzx, cb1[110].zzzz
1346: mul r24.xyz, r23.xyzx, l(0.650000, 0.650000, 0.650000, 0.000000)
1347: dp3 r9.y, r14.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1348: dp2 r10.w, cb0[6].xzxx, cb0[6].xzxx
1349: rsq r10.w, r10.w
1350: mul r25.xy, r10.wwww, cb0[6].xzxx
1351: dp2 r10.w, r20.xzxx, r25.xyxx
1352: mov_sat r10.w, -r10.w
1353: add r25.xy, l(1.000000, 1.000000, 0.000000, 0.000000), -cb1[122].xyxx
1354: mad r11.w, r6.w, l(0.500000), l(-1.000000)
1355: mad r11.w, -r6.w, r11.w, -r6.w
1356: add r13.w, l(0.750000), -abs(cb0[6].y)
1357: add_sat r13.w, r13.w, r13.w
1358: mad r14.w, r13.w, l(-2.000000), l(3.000000)
1359: mul r13.w, r13.w, r13.w
1360: mul r13.w, r13.w, r14.w
1361: mul r13.w, r10.w, r13.w
1362: mul r13.w, r25.x, r13.w
1363: add r11.w, r11.w, l(0.500000)
1364: mad r6.w, r13.w, r11.w, r6.w
1365: mad r6.w, cb1[121].w, cb1[122].x, r6.w
1366: max r6.w, r6.w, l(-1.000000)
1367: min r6.w, r6.w, l(1.000000)
1368: mad r26.x, r6.w, l(0.500000), l(0.500000)
1369: mov r26.yw, l(0.000000, 0.500000, 0.000000, 0.500000)
1370: sample_l(texture2d)(float,float,float,float) r27.xyzw, r26.xyxx, t14.xyzw, s0, l(0)
1371: max r6.w, r27.y, r27.x
1372: max r6.w, r27.z, r6.w
1373: min r11.w, r27.y, r27.x
1374: min r11.w, r27.z, r11.w
1375: add r6.w, r6.w, -r11.w
1376: dp3 r11.w, r12.yzwy, cb0[6].xyzx
1377: mad r26.z, r11.w, l(0.500000), l(0.500000)
1378: sample_l(texture2d)(float,float,float,float) r11.w, r26.zwzz, t14.xyzw, s0, l(0)
1379: mul r13.w, r2.w, r6.z
1380: min r14.w, r6.z, r2.w
1381: min r15.w, r27.w, r14.w
1382: mul r16.w, r11.w, r13.w
1383: dp3 r10.x, r10.xyzx, cb1[116].xyzx
1384: add_sat r10.x, r10.x, cb1[117].x
1385: mad r10.x, r10.x, cb1[117].y, cb1[117].z
1386: mul r10.y, r15.w, cb1[111].y
1387: add r26.xyz, -r15.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
1388: mad r26.xyz, r10.yyyy, r26.xyzx, r15.xyzx
1389: mul r10.xyz, r10.xxxx, r26.xyzx
1390: mad r17.w, r7.w, l(0.350000), l(0.650000)
1391: min r17.w, r17.w, l(1.500000)
1392: max r26.xyz, r7.wwww, l(1.250000, 0.000000, 0.500000, 0.000000)
1393: min r26.xyz, r26.xyzx, l(1.750000, 1.500000, 1.500000, 0.000000)
1394: add r7.w, -r17.w, r26.x
1395: mad r7.w, cb1[111].x, r7.w, r17.w
1396: mul r28.xyz, r7.wwww, r10.xyzx
1397: mul r28.xyz, r28.xyzx, cb1[110].wwww
1398: dp3 r7.w, r22.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1399: mad r22.xyz, r21.xyzx, r21.wwww, -r7.wwww
1400: mad r22.xyz, r15.wwww, r22.xyzx, r7.wwww
1401: mul r10.xyz, r10.xyzx, r26.yyyy
1402: mad r25.yzw, r21.xxyz, cb1[122].yyyy, r25.yyyy
1403: mad r10.xyz, r10.xyzx, r25.yzwy, r22.xyzx
1404: mad r10.xyz, r10.xyzx, cb1[110].yyyy, -r28.xyzx
1405: mad r10.xyz, r4.wwww, r10.xyzx, r28.xyzx
1406: dp3 r7.w, r24.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1407: mad r22.xyz, r23.xyzx, l(0.650000, 0.650000, 0.650000, 0.000000), -r7.wwww
1408: mad r22.xyz, r22.xyzx, l(1.200000, 1.200000, 1.200000, 0.000000), r7.wwww
1409: mad_sat r7.w, r11.w, r13.w, r27.w
1410: mad r24.xyz, r8.xyzx, cb1[110].zzzz, -r22.xyzx
1411: mad r22.xyz, r7.wwww, r24.xyzx, r22.xyzx
1412: mad r24.xyz, r5.xyzx, r3.xxxx, -r22.xyzx
1413: mad r22.xyz, r15.wwww, r24.xyzx, r22.xyzx
1414: add r7.w, -r6.w, l(1.000000)
1415: mad r24.xyz, r27.xyzx, r6.wwww, r7.wwww
1416: mul r24.xyz, r22.xyzx, r24.xyzx
1417: mad r25.yzw, r5.xxyz, r3.xxxx, -r9.yyyy
1418: mad r25.yzw, r25.yyzw, l(0.000000, 1.200000, 1.200000, 1.200000), r9.yyyy
1419: mad r25.yzw, -r8.xxyz, cb1[110].zzzz, r25.yyzw
1420: mad r23.xyz, r16.wwww, r25.yzwy, r23.xyzx
1421: dp3 r6.w, r22.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1422: dp3 r7.w, r24.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1423: max r7.w, r7.w, l(0.001000)
1424: div r7.w, l(1.000000, 1.000000, 1.000000, 1.000000), r7.w
1425: mul r6.w, r6.w, r7.w
1426: max r6.w, r6.w, l(0)
1427: min r6.w, r6.w, l(1.500000)
1428: mad r22.xyz, r24.xyzx, r6.wwww, -r23.xyzx
1429: mad r22.xyz, r4.wwww, r22.xyzx, r23.xyzx
1430: mad r6.w, -r11.w, r13.w, r15.w
1431: mad r6.w, r4.w, r6.w, r16.w
1432: add r7.w, l(1.000000), -cb1[110].z
1433: mad r7.w, r6.w, r7.w, cb1[110].z
1434: add r11.w, r17.y, l(-0.500000)
1435: mad r23.y, r4.w, r11.w, l(0.500000)
1436: dp3_sat r24.x, r13.xyzx, r2.xyzx
1437: mov r23.xz, cb0[6].xxzx
1438: dp3 r11.w, r23.xyzx, r23.xyzx
1439: max r11.w, r11.w, l(0.000000)
1440: rsq r11.w, r11.w
1441: mul r23.xyz, r11.wwww, r23.xyzx
1442: add r23.xyz, r23.xyzx, r23.xyzx
1443: mad r17.xyz, r17.xyzx, r4.wwww, r23.xyzx
1444: add r11.w, r4.w, l(2.000000)
1445: mad r17.xyz, r2.xyzx, r11.wwww, r17.xyzx
1446: dp3 r11.w, r17.xyzx, r17.xyzx
1447: rsq r11.w, r11.w
1448: mul r17.xyz, r11.wwww, r17.xyzx
1449: dp3 r11.w, r13.xyzx, r17.xyzx
1450: mad r13.w, r11.w, r6.y, -r11.w
1451: mad r11.w, r13.w, r11.w, l(1.000000)
1452: mul r11.w, r11.w, r11.w
1453: ne r13.w, r6.y, r11.w
1454: div r6.y, r6.y, r11.w
1455: movc r6.y, r13.w, r6.y, l(1.000000)
1456: mul r17.x, r24.x, r24.x
1457: mad r11.w, r3.z, r3.z, l(0.000100)
1458: div r11.w, l(1.000000, 1.000000, 1.000000, 1.000000), r11.w
1459: div r11.w, r6.y, r11.w
1460: mad r13.w, r24.x, r24.x, -r11.w
1461: mad r23.x, cb6[1].x, r13.w, r11.w
1462: add r11.w, -r6.x, l(1.000000)
1463: mul r23.y, r3.y, r11.w
1464: sample_l(texture2d)(float,float,float,float) r23.xyz, r23.xyxx, t15.xyzw, s0, l(0)
1465: mul r25.yzw, r16.xxyz, r23.xxyz
1466: mad r23.xyz, r16.xyzx, r23.xyzx, -r16.xyzx
1467: mad r16.xyz, cb6[1].xxxx, r23.xyzx, r16.xyzx
1468: add r11.w, l(1.000000), -cb6[1].z
1469: mad r11.w, r5.w, cb6[1].z, r11.w
1470: mul r23.xyz, r10.xyzx, r22.xyzx
1471: mad r13.w, r24.x, l(2.000000), r3.z
1472: add r13.w, r13.w, l(0.000100)
1473: div r13.w, l(0.500000), r13.w
1474: mad r6.y, r6.y, r13.w, l(-0.000061)
1475: max r6.y, r6.y, l(0)
1476: min r6.y, r6.y, l(20.000000)
1477: mul r26.xyw, r6.yyyy, r25.yzyw
1478: mad r6.y, r6.w, l(0.500000), l(0.500000)
1479: mul r6.y, r7.w, r6.y
1480: mul r10.xyz, r6.yyyy, r10.xyzx
1481: mul r10.xyz, r10.xyzx, r26.xywx
1482: mul r10.xyz, r10.xyzx, cb1[123].wwww
1483: mad r10.xyz, r23.xyzx, r11.wwww, r10.xyzx
1484: dp3 r6.y, r10.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1485: add r6.w, r6.y, l(-0.500000)
1486: max r6.w, r6.w, l(0)
1487: min r6.w, r6.w, l(0.500000)
1488: mul r23.z, cb0[0].x, cb1[119].x
1489: mul r23.x, cb0[1].x, cb1[119].x
1490: mul r23.y, cb0[2].x, cb1[119].x
1491: mul r27.z, cb0[0].y, cb1[119].y
1492: mul r27.x, cb0[1].y, cb1[119].y
1493: mul r27.y, cb0[2].y, cb1[119].y
1494: add r23.xyz, r23.xyzx, r27.xyzx
1495: mov r27.xz, cb1[119].yyxy
1496: mov r27.y, l(0)
1497: add r23.xyz, r23.xyzx, -r27.xyzx
1498: mad r23.xyz, cb1[125].wwww, r23.xyzx, r27.xyzx
1499: mul r26.xyw, r23.xyxz, cb0[6].zxzy
1500: mad r23.xyz, cb0[6].yzxy, r23.yzxy, -r26.xywx
1501: dp3 r13.w, r23.xyzx, r23.xyzx
1502: rsq r13.w, r13.w
1503: mul r23.xyz, r13.wwww, r23.xyzx
1504: dp3 r13.w, r2.xyzx, r12.yzwy
1505: add r26.xy, -abs(r13.wwww), l(1.000000, 0.400000, 0.000000, 0.000000)
1506: dp3 r15.w, r20.xyzx, r12.yzwy
1507: add r16.w, -r4.w, l(1.000000)
1508: add r12.x, -r3.y, r12.x
1509: mad r3.w, r3.w, r12.x, r3.y
1510: mul r20.y, r3.w, r3.w
1511: mul r17.z, r24.x, r17.x
1512: mul r12.x, r20.y, r20.y
1513: mul r20.z, r20.y, r12.x
1514: mov r24.yzw, l(0.000000, 0.036546, 9.063200, 0.990440)
1515: dp2 r27.x, l(3.327070, 1.000000, 0.000000, 0.000000), r24.xyxx
1516: dp2 r27.y, l(-9.047560, 1.000000, 0.000000, 0.000000), r24.xzxx
1517: mov r20.x, l(1.000000)
1518: dp2 r12.x, r27.xyxx, r20.xyxx
1519: mov r17.yw, l(0.000000, 9.044010, 0.000000, 1.000000)
1520: dp3 r27.x, l(3.596850, -1.367720, 1.000000, 0.000000), r17.xzwx
1521: dp3 r27.y, l(-16.317400, 1.000000, 9.229490, 0.000000), r17.xyzx
1522: mov r28.x, l(5.565890)
1523: mov r28.yz, r17.xxzx
1524: dp3 r27.z, l(1.000000, 19.788601, -20.212299, 0.000000), r28.xyzx
1525: dp3 r18.w, r27.xyzx, r20.xyzx
1526: div r12.x, r12.x, r18.w
1527: dp2 r27.x, l(-1.285140, 1.000000, 0.000000, 0.000000), r24.xwxx
1528: mov r17.x, l(1.296780)
1529: mov r17.y, r24.x
1530: dp2 r27.y, l(1.000000, -0.755907, 0.000000, 0.000000), r17.xyxx
1531: dp2 r18.w, r27.xyxx, r20.xyxx
1532: dp3 r27.x, l(2.923380, 59.418800, 1.000000, 0.000000), r17.yzwy
1533: mov r17.xw, l(20.322500, 0.000000, 0.000000, 121.563004)
1534: dp3 r27.y, l(1.000000, -27.030199, 222.591995, 0.000000), r17.xyzx
1535: dp3 r27.z, l(626.130005, 316.627014, 1.000000, 0.000000), r17.yzwy
1536: dp3 r17.x, r27.xyzx, r20.xyzx
1537: div r17.x, r18.w, r17.x
1538: mad r17.yzw, r16.xxyz, r12.xxxx, r17.xxxx
1539: add r12.x, r12.x, r17.x
1540: dp3 r17.x, -r2.xyzx, r13.xyzx
1541: add r17.x, r17.x, r17.x
1542: mad r20.xyz, r13.xyzx, -r17.xxxx, -r2.xyzx
1543: dp2 r27.x, r20.zxzz, cb1[126].xyxx
1544: mul r17.x, r20.x, cb1[126].x
1545: mad r27.z, r20.z, cb1[126].y, -r17.x
1546: mad r6.w, r6.w, r6.w, l(1.000000)
1547: add r10.xyz, -r6.yyyy, r10.xyzx
1548: mad r10.xyz, r6.wwww, r10.xyzx, r6.yyyy
1549: mad r6.yw, cb1[119].wwww, l(0.000000, -0.600000, 0.000000, -0.400000), l(0.000000, 0.800000, 0.000000, 0.900000)
1550: add r6.w, -r6.y, r6.w
1551: add r6.y, -r6.y, r26.x
1552: div r6.w, l(1.000000, 1.000000, 1.000000, 1.000000), r6.w
1553: mul_sat r6.y, r6.w, r6.y
1554: mad r6.w, r6.y, l(-2.000000), l(3.000000)
1555: mul r6.y, r6.y, r6.y
1556: mul r6.y, r6.y, r6.w
1557: mul r20.xzw, r6.yyyy, cb1[118].xxyz
1558: mul r20.xzw, r20.xxzw, cb1[118].wwww
1559: dp3 r6.y, r4.xyzx, r23.xyzx
1560: add_sat r6.y, r6.y, l(1.000000)
1561: min r6.y, r6.z, r6.y
1562: min r2.w, r2.w, r6.y
1563: mul r6.yzw, r2.wwww, r20.xxzw
1564: mad r20.xzw, r5.xxyz, r3.xxxx, l(-0.250000, 0.000000, -0.250000, -0.250000)
1565: mad r20.xzw, cb1[119].zzzz, r20.xxzw, l(0.250000, 0.000000, 0.250000, 0.250000)
1566: dp3_sat r2.w, r23.xyzx, r12.yzwy
1567: mul r20.xzw, r2.wwww, r20.xxzw
1568: max r2.w, r18.y, r18.x
1569: max r2.w, r18.z, r2.w
1570: mul r2.w, r2.w, l(0.500000)
1571: max r2.w, r2.w, l(1.000000)
1572: div r2.w, l(1.000000, 1.000000, 1.000000, 1.000000), r2.w
1573: mul r18.xyz, r2.wwww, r18.xyzx
1574: mad r21.xyz, r21.xyzx, r21.wwww, -r18.xyzx
1575: mad r18.xyz, r4.wwww, r21.xyzx, r18.xyzx
1576: dp3 r2.w, r19.xyzx, r12.yzwy
1577: mul r17.x, r8.w, r2.w
1578: mad r18.w, r15.w, l(0.500000), l(-1.000000)
1579: mad r15.w, -r15.w, r18.w, l(0.500000)
1580: mad r2.w, -r2.w, r8.w, r15.w
1581: mad_sat r2.w, r4.w, r2.w, r17.x
1582: mul r18.xyz, r2.wwww, r18.xyzx
1583: mad r2.w, r10.w, r4.w, r16.w
1584: mul r2.w, r25.x, r2.w
1585: mul r18.xyz, r2.wwww, r18.xyzx
1586: mul_sat r2.w, r26.y, l(5.000000)
1587: mad r8.w, r2.w, l(-2.000000), l(3.000000)
1588: mul r2.w, r2.w, r2.w
1589: mul r2.w, r2.w, r8.w
1590: mul r18.xyz, r2.wwww, r18.xyzx
1591: mul r18.xyz, r14.wwww, r18.xyzx
1592: add r2.w, r9.y, l(-0.100000)
1593: mul_sat r2.w, r2.w, l(-16.666666)
1594: mad r8.w, r2.w, l(-2.000000), l(3.000000)
1595: mul r2.w, r2.w, r2.w
1596: mul r2.w, r2.w, r8.w
1597: mad r2.w, r2.w, r4.w, r16.w
1598: mul r18.xyz, r2.wwww, r18.xyzx
1599: max r19.xyz, r14.xyzx, l(0.150000, 0.150000, 0.150000, 0.000000)
1600: mul r18.xyz, r18.xyzx, r19.xyzx
1601: mad r6.yzw, r6.yyzw, r20.xxzw, r18.xxyz
1602: add r6.yzw, r6.yyzw, r10.xxyz
1603: utof r10.xy, r11.xyxx
1604: mul r10.zw, r10.xxxy, l(0.000000, 0.000000, 0.031250, 0.031250)
1605: round_ni r10.zw, r10.zzzw
1606: mad r2.w, r10.w, cb4[2].y, r10.z
1607: mul r2.w, r2.w, l(8.000000)
1608: ftoi r2.w, r2.w
1609: mad r4.w, -cb1[3].y, cb4[3].w, v0.w
1610: round_ni r4.w, r4.w
1611: add r8.w, l(-1.000000), cb4[2].w
1612: max r9.y, r4.w, l(0)
1613: min r8.w, r8.w, r9.y
1614: mul r9.y, r8.w, l(8.000000)
1615: ftoi r9.y, r9.y
1616: max r3.w, r3.w, l(0.001000)
1617: log r3.w, r3.w
1618: mad r3.w, r3.w, l(1.200000), l(5.000000)
1619: mov r27.y, r20.y
1620: sample_l(texturecube)(float,float,float,float) r18.xyz, r27.xyzx, t22.xyzw, s0, r3.w
1621: add r3.w, -r12.x, l(1.000000)
1622: div r3.w, r3.w, r12.x
1623: mul r16.xyz, r3.wwww, r16.xyzx
1624: mad r16.xyz, r16.xyzx, r17.yzwy, r17.yzwy
1625: mul r16.xyz, r16.xyzx, r18.xyzx
1626: mul r3.w, r26.z, cb1[110].w
1627: mul r3.w, r7.w, r3.w
1628: mul r16.xyz, r3.wwww, r16.xyzx
1629: mad r6.yzw, r16.xxyz, r15.xxyz, r6.yyzw
1630: ge r3.w, r8.w, r4.w
1631: iadd r2.w, r2.w, cb4[0].z
1632: iadd r4.w, r9.y, cb4[0].w
1633: mad r7.w, r16.w, l(-0.250000), l(0.750000)
1634: mad r5.xyz, r5.xyzx, r3.xxxx, l(-0.500000, -0.500000, -0.500000, 0.000000)
1635: add r3.x, -r3.z, l(0.010000)
1636: ge r6.x, r6.x, l(0.500000)
1637: and r6.x, r6.x, l(1.000000)
1638: mov r15.w, l(1.000000)
1639: mov r16.xyz, r6.yzwy
1640: mov r8.w, l(0)
1641: loop
1642:   ilt r9.y, l(7), r8.w
1643:   breakc_nz r9.y
1644:   iadd r9.y, r2.w, r8.w
1645:   ld_structured_indexable(structured_buffer, stride=4)(mixed,mixed,mixed,mixed) r9.y, r9.y, l(0), t0.xxxx
1646:   iadd r10.z, r4.w, r8.w
1647:   ld_structured_indexable(structured_buffer, stride=4)(mixed,mixed,mixed,mixed) r10.z, r10.z, l(0), t0.xxxx
1648:   and r9.y, r9.y, r10.z
1649:   and r9.y, r3.w, r9.y
1650:   ishl r10.z, r8.w, l(5)
1651:   mov r17.xyz, r16.xyzx
1652:   mov r10.w, r9.y
1653:   loop
1654:     breakc_z r10.w
1655:     firstbit_lo r12.x, r10.w
1656:     ishl r14.w, l(1), r12.x
1657:     xor r14.w, r10.w, r14.w
1658:     iadd r12.x, r10.z, r12.x
1659:     bfi r18.xyzw, l(29, 29, 29, 29), l(3, 3, 3, 3), r12.xxxx, l(1, 5, 6, 7)
1660:     ftou r16.w, cb3[r18.y + 6].w
1661:     and r17.w, r16.w, l(1)
1662:     ieq r17.w, r17.w, l(1)
1663:     if_nz r17.w
1664:       add r15.xyz, r7.xyzx, -cb3[r18.x + 6].xyzx
1665:       and r19.xyz, l(0x0000ffff, 0x0000ffff, 0x0000ffff, 0), cb3[r18.y + 6].xzyx
1666:       and r20.xyz, l(0x0000ffff, 0x0000ffff, 0x0000ffff, 0), cb3[r18.z + 6].yxzy
1667:       ushr r21.xyz, cb3[r18.y + 6].xzyx, l(16, 16, 16, 0)
1668:       ushr r23.xyz, cb3[r18.z + 6].yxzy, l(16, 16, 16, 0)
1669:       f16tof32 r19.xyz, r19.xyzx
1670:       f16tof32 r20.xyz, r20.xyzx
1671:       f16tof32 r21.xyz, r21.xyzx
1672:       f16tof32 r23.xyw, r23.yxyz
1673:       mov r27.xz, r19.xxzx
1674:       mov r27.yw, r21.xxxz
1675:       dp4 r17.w, r15.xyzw, r27.xyzw
1676:       mov r21.x, r19.y
1677:       mov r21.z, r20.y
1678:       mov r21.w, r23.x
1679:       dp4 r18.y, r15.xyzw, r21.xyzw
1680:       mov r23.xz, r20.xxzx
1681:       dp4 r15.x, r15.xyzw, r23.xyzw
1682:       max r15.y, abs(r17.w), abs(r18.y)
1683:       max r15.x, abs(r15.x), r15.y
1684:       mad r15.y, cb3[r18.w + 6].x, l(0.500000), l(0.500000)
1685:       add r15.x, -r15.y, r15.x
1686:       mad r15.y, -cb3[r18.w + 6].x, l(0.500000), l(0.500000)
1687:       div_sat r15.x, r15.x, r15.y
1688:       add r15.x, -r15.x, l(1.000000)
1689:       mul r15.x, r15.x, r15.x
1690:     else
1691:       mov r15.x, l(1.000000)
1692:     endif
1693:     lt r15.y, r15.x, l(0.001000)
1694:     if_nz r15.y
1695:       mov r10.w, r14.w
1696:       continue
1697:     endif
1698:     ishl r15.y, r12.x, l(3)
1699:     ftou r15.z, cb3[r15.y + 6].w
1700:     uge r17.w, r15.z, l(4)
1701:     if_nz r17.w
1702:       mov r19.xyz, r17.xyzx
1703:     endif
1704:     if_z r17.w
1705:       lt r17.w, cb3[r15.y + 6].w, l(1.500000)
1706:       if_nz r17.w
1707:         bfi r17.w, l(29), l(3), r12.x, l(3)
1708:         ieq r18.y, l(16), cb3[r17.w + 6].w
1709:         add r19.w, cb1[122].z, cb3[r17.w + 6].z
1710:         lt r19.w, r19.w, l(0.500000)
1711:         or r18.y, r18.y, r19.w
1712:         if_z r18.y
1713:           bfi r20.xy, l(29, 29, 0, 0), l(3, 3, 0, 0), r12.xxxx, l(2, 4, 0, 0)
1714:           and r12.x, r15.z, l(1)
1715:           ieq r15.z, r12.x, l(0)
1716:           not r18.y, r15.z
1717:           lt r19.w, l(0), cb3[r20.x + 6].z
1718:           and r18.y, r18.y, r19.w
1719:           ieq r19.w, l(4), cb3[r17.w + 6].w
1720:           movc r20.z, r12.x, l(0), l(1.000000)
1721:           mad r20.w, cb3[r20.x + 6].y, l(0.500000), l(0.500000)
1722:           add r21.z, r20.w, -abs(cb3[r20.x + 6].x)
1723:           add r21.x, -r21.z, cb3[r20.x + 6].y
1724:           add r20.w, -abs(r21.z), l(1.000000)
1725:           add r20.w, -abs(r21.x), r20.w
1726:           max r20.w, r20.w, l(0.000488)
1727:           ge r21.w, cb3[r20.x + 6].x, l(0)
1728:           movc r21.y, r21.w, r20.w, -r20.w
1729:           dp3 r20.w, r21.xyzx, r21.xyzx
1730:           rsq r20.w, r20.w
1731:           mul r21.xyz, r20.wwww, r21.xyzx
1732:           add r20.w, cb3[r20.y + 6].y, cb3[r20.y + 6].y
1733:           max r20.w, r20.w, l(0.100000)
1734:           and r21.w, r19.w, l(1.000000)
1735:           add r20.w, r20.w, -cb3[r18.z + 6].w
1736:           mad r18.z, r21.w, r20.w, cb3[r18.z + 6].w
1737:           add r23.xyz, -r7.xyzx, cb3[r18.x + 6].xyzx
1738:           dp3 r20.w, r23.yzxy, -r21.xyzx
1739:           lt r21.w, l(0.500000), cb3[r20.y + 6].z
1740:           and r21.w, r19.w, r21.w
1741:           and r21.w, r21.w, l(1.000000)
1742:           mul r21.w, r20.z, r21.w
1743:           mad r24.yzw, -r21.zzxy, r20.wwww, -r23.xxyz
1744:           mad r23.xyz, r21.wwww, r24.yzwy, r23.xyzx
1745:           dp3 r20.w, r23.xyzx, r23.xyzx
1746:           rsq r21.w, r20.w
1747:           mul r24.yzw, r21.wwww, r23.xxyz
1748:           if_nz r18.y
1749:             mul r26.yzw, r21.zzxy, cb3[r20.x + 6].zzzz
1750:             mad r27.xyz, -r26.yzwy, l(0.500000, 0.500000, 0.500000, 0.000000), r23.xyzx
1751:             mad r26.yzw, r26.yyzw, l(0.000000, 0.500000, 0.500000, 0.500000), r23.xxyz
1752:             dp3 r21.w, r27.xyzx, r27.xyzx
1753:             sqrt r21.w, r21.w
1754:             dp3 r22.w, r26.yzwy, r26.yzwy
1755:             sqrt r22.w, r22.w
1756:             mul r28.xyz, r21.xyzx, r24.yzwy
1757:             mad r28.xyz, r21.zxyz, r24.zwyz, -r28.xyzx
1758:             mul r29.xyz, r21.xyzx, r28.xyzx
1759:             mad r28.xyz, r28.zxyz, r21.yzxy, -r29.xyzx
1760:             dp3 r23.w, r28.xyzx, r28.xyzx
1761:             rsq r23.w, r23.w
1762:             mul r24.yzw, r23.wwww, r28.xxyz
1763:             dp3 r23.w, r27.xyzx, r26.yzwy
1764:             mad r23.w, r21.w, r22.w, r23.w
1765:             mad r23.w, r23.w, l(0.500000), l(1.000000)
1766:             div r23.w, l(1.000000, 1.000000, 1.000000, 1.000000), r23.w
1767:             dp3 r25.x, r24.yzwy, r27.xyzx
1768:             div r21.w, r25.x, r21.w
1769:             dp3 r25.x, r24.yzwy, r26.yzwy
1770:             div r22.w, r25.x, r22.w
1771:             add r21.w, r21.w, r22.w
1772:             mul_sat r21.w, r21.w, l(0.500000)
1773:             mul r21.w, r21.w, r23.w
1774:           else
1775:             mov r21.w, l(1.000000)
1776:           endif
1777:           lt r22.w, r18.z, l(0)
1778:           if_nz r22.w
1779:             mul r22.w, cb3[r18.x + 6].w, cb3[r18.x + 6].w
1780:             mul r22.w, r20.w, r22.w
1781:             mad r22.w, -r22.w, r22.w, l(1.000000)
1782:             max r22.w, r22.w, l(0)
1783:             add r20.w, r20.w, l(1.000000)
1784:             div r20.w, l(1.000000, 1.000000, 1.000000, 1.000000), r20.w
1785:             and r23.w, r18.y, l(1.000000)
1786:             add r25.x, -r20.w, r21.w
1787:             mad r20.w, r23.w, r25.x, r20.w
1788:             mul r22.w, r22.w, r22.w
1789:             mul r20.w, r20.w, r22.w
1790:           else
1791:             mul r26.yzw, r23.xxyz, cb3[r18.x + 6].wwww
1792:             dp3 r22.w, r26.yzwy, r26.yzwy
1793:             min r22.w, r22.w, l(1.000000)
1794:             add r22.w, -r22.w, l(1.000000)
1795:             log r22.w, r22.w
1796:             mul r18.z, r18.z, r22.w
1797:             exp r18.z, r18.z
1798:             mul r20.w, r18.z, r21.w
1799:           endif
1800:           dp3 r18.z, r24.zwyz, -r21.xyzx
1801:           add r18.z, r18.z, -cb3[r20.x + 6].z
1802:           mul_sat r18.z, r18.z, cb3[r20.x + 6].w
1803:           mad r18.z, r18.z, r18.z, l(-1.000000)
1804:           mad r18.z, r20.z, r18.z, l(1.000000)
1805:           mul r18.z, r18.z, r20.w
1806:           ftoi r20.z, cb3[r18.w + 6].w
1807:           not r18.y, r18.y
1808:           ige r20.w, r20.z, l(0)
1809:           and r18.y, r18.y, r20.w
1810:           if_nz r18.y
1811:             if_z r12.x
1812:               ishl r12.x, r20.z, l(2)
1813:               mul r21.xyz, r7.yyyy, cb7[r12.x + 33].xywx
1814:               mad r21.xyz, cb7[r12.x + 32].xywx, r7.xxxx, r21.xyzx
1815:               mad r21.xyz, cb7[r12.x + 34].xywx, r7.zzzz, r21.xyzx
1816:               add r21.xyz, r21.xyzx, cb7[r12.x + 35].xywx
1817:               div_sat r21.xy, r21.xyxx, r21.zzzz
1818:               mad r21.xy, r21.xyxx, cb7[r20.z + 0].zwzz, cb7[r20.z + 0].xyxx
1819:             else
1820:               ishl r12.x, r20.z, l(2)
1821:               dp3 r27.x, -r23.xyzx, cb7[r12.x + 32].xyzx
1822:               dp3 r27.y, -r23.xyzx, cb7[r12.x + 33].xyzx
1823:               dp3 r27.z, -r23.xyzx, cb7[r12.x + 34].xyzx
1824:               lt r12.x, abs(r27.x), abs(r27.y)
1825:               and r12.x, r12.x, l(1)
1826:               dp2 r18.y, abs(r27.xyxx), icb[r12.x + 0].xyxx
1827:               lt r18.y, r18.y, abs(r27.z)
1828:               movc r12.x, r18.y, l(2), r12.x
1829:               dp3 r18.y, r27.xyzx, icb[r12.x + 0].xyzx
1830:               lt r18.y, r18.y, l(0)
1831:               bfi r12.x, l(31), l(1), r12.x, r18.y
1832:               ushr r18.y, r12.x, l(1)
1833:               dp3 r18.y, r27.xyzx, icb[r18.y + 0].xyzx
1834:               div r20.w, l(0.000244), cb7[r20.z + 0].w
1835:               add r20.w, -r20.w, l(0.500000)
1836:               utof r21.z, r12.x
1837:               ult r21.w, r12.x, l(2)
1838:               and r21.w, r21.w, l(2)
1839:               dp2 r21.w, r27.xzxx, icb[r21.w + 0].xzxx
1840:               mul r21.w, r21.w, icb[r12.x + 20].z
1841:               div r21.w, r21.w, abs(r18.y)
1842:               mad r21.z, r21.w, r20.w, r21.z
1843:               add r21.z, r21.z, l(0.500000)
1844:               mul_sat r23.x, r21.z, l(0.166667)
1845:               iadd r21.z, l(-1), icb[r12.x + 20].y
1846:               dp2 r21.z, r27.yzyy, icb[r21.z + 0].xyxx
1847:               mul r12.x, r21.z, icb[r12.x + 20].w
1848:               div r12.x, r12.x, abs(r18.y)
1849:               mad_sat r23.y, -r12.x, r20.w, l(0.500000)
1850:               mad r21.xy, r23.xyxx, cb7[r20.z + 0].zwzz, cb7[r20.z + 0].xyxx
1851:             endif
1852:             sample_l(texture2d)(float,float,float,float) r12.x, r21.xyxx, t23.xyzw, s0, l(0)
1853:             mul r18.z, r12.x, r18.z
1854:           endif
1855:           mul r12.x, r15.x, r18.z
1856:           lt r15.x, l(0.000100), r12.x
1857:           if_nz r15.x
1858:             if_nz r19.w
1859:               add r15.x, l(1.000000), -cb3[r20.y + 6].w
1860:               dp3 r18.y, r9.xzwx, r24.yzwy
1861:               add_sat r18.y, r18.y, l(0.500000)
1862:               mad r18.z, r18.y, l(-2.000000), l(3.000000)
1863:               mul r18.y, r18.y, r18.y
1864:               mul r18.y, r18.y, r18.z
1865:               mad r15.x, r18.y, cb3[r20.y + 6].w, r15.x
1866:               mul r15.x, r15.x, cb3[r20.y + 6].x
1867:               mul r15.x, r12.x, r15.x
1868:               add r21.xyz, -r17.xyzx, cb3[r15.y + 6].xyzx
1869:               mad r21.xyz, r15.xxxx, r21.xyzx, r17.xyzx
1870:             endif
1871:             if_z r19.w
1872:               dp3 r15.x, r12.yzwy, r24.yzwy
1873:               mov_sat r18.y, r15.x
1874:               if_nz cb3[r17.w + 6].w
1875:                 and r16.w, r16.w, l(2)
1876:                 ine r16.w, r16.w, l(0)
1877:                 or r15.z, r15.z, r16.w
1878:                 if_nz r15.z
1879:                   ftoi r16.w, cb3[r17.w + 6].x
1880:                 else
1881:                   add r23.xyz, r7.xyzx, -cb3[r18.x + 6].xyzx
1882:                   lt r26.yzw, abs(r23.yyzz), abs(r23.xxxy)
1883:                   and r18.z, r26.z, r26.y
1884:                   lt r23.xyz, l(0, 0, 0, 0), r23.xyzx
1885:                   and r20.z, l(1023), cb3[r20.x + 6].w
1886:                   ubfe r20.xw, l(10, 0, 0, 10), l(10, 0, 0, 20), cb3[r20.x + 6].wwww
1887:                   movc r20.x, r23.x, r20.z, r20.x
1888:                   and r20.z, l(1023), cb3[r17.w + 6].x
1889:                   movc r20.z, r23.y, r20.w, r20.z
1890:                   ubfe r23.xy, l(10, 10, 0, 0), l(10, 20, 0, 0), cb3[r17.w + 6].xxxx
1891:                   movc r20.w, r23.z, r23.x, r23.y
1892:                   movc r20.z, r26.w, r20.z, r20.w
1893:                   movc r18.z, r18.z, r20.x, r20.z
1894:                   ieq r20.x, r18.z, l(1023)
1895:                   movc r16.w, r20.x, l(-1), r18.z
1896:                 endif
1897:                 ige r18.z, r16.w, l(0)
1898:                 if_nz r18.z
1899:                   add r20.xzw, r7.xxyz, -cb3[r18.x + 6].xxyz
1900:                   imad r16.w, r16.w, l(96), cb5[65].x
1901:                   iadd r23.xyzw, r16.wwww, l(64, 16, 32, 48)
1902:                   and r23.xyzw, r23.xyzw, l(-4, -4, -4, -4)
1903:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r18.xz, r23.x, t2.xxyx
1904:                   and r21.w, r16.w, l(-4)
1905:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r27.xyzw, r21.w, t2.xyzw
1906:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r28.xyzw, r23.y, t2.xyzw
1907:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r29.xyzw, r23.z, t2.xyzw
1908:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r30.xyzw, r23.w, t2.xyzw
1909:                   dp3 r21.w, r20.xzwx, r20.xzwx
1910:                   max r21.w, r21.w, l(0.000000)
1911:                   rsq r21.w, r21.w
1912:                   mul r20.xzw, r20.xxzw, r21.wwww
1913:                   mad r20.xzw, -r20.xxzw, r18.xxxx, r7.xxyz
1914:                   mul r18.x, r18.z, l(5.000000)
1915:                   mad r20.xzw, r9.xxzw, r18.xxxx, r20.xxzw
1916:                   mul r28.xyzw, r20.zzzz, r28.xyzw
1917:                   mad r27.xyzw, r27.xyzw, r20.xxxx, r28.xyzw
1918:                   mad r27.xyzw, r29.xyzw, r20.wwww, r27.xyzw
1919:                   add r27.xyzw, r30.xyzw, r27.xyzw
1920:                   div r20.xzw, r27.xxyz, r27.wwww
1921:                   iadd r16.w, r16.w, l(80)
1922:                   and r16.w, r16.w, l(-4)
1923:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r28.xyzw, r16.w, t2.xyzw
1924:                   ge r23.yzw, l(0, 0, 0, 0), r20.xxzw
1925:                   ge r26.yzw, r20.xxzw, l(0.000000, 1.000000, 1.000000, 1.000000)
1926:                   add r18.xz, -r28.xxyx, r28.zzwz
1927:                   mad r18.xz, r20.xxzx, r18.xxzx, r28.xxyx
1928:                   mad r27.xy, r18.xzxx, cb5[64].zwzz, l(0.500000, 0.500000, 0.000000, 0.000000)
1929:                   round_ni r27.xy, r27.xyxx
1930:                   mad r18.xz, r18.xxzx, cb5[64].zzwz, -r27.xxyx
1931:                   add r28.xyzw, r18.xxzz, l(0.500000, 1.000000, 0.500000, 1.000000)
1932:                   mul r29.xyzw, r28.xxzz, r28.xxzz
1933:                   add r28.xz, -r18.xxzx, l(1.000000, 0.000000, 1.000000, 0.000000)
1934:                   min r30.xy, r18.xzxx, l(0, 0, 0, 0)
1935:                   max r30.zw, r18.xxxz, l(0, 0, 0, 0)
1936:                   mul r31.xy, r28.xzxx, l(0.160000, 0.160000, 0.000000, 0.000000)
1937:                   mad r30.zw, -r30.zzzw, r30.zzzw, r28.yyyw
1938:                   add r30.zw, r30.zzzw, l(0.000000, 0.000000, 1.000000, 1.000000)
1939:                   mul r32.xy, r30.zwzz, l(0.160000, 0.160000, 0.000000, 0.000000)
1940:                   mul r29.xz, r29.xxzx, l(0.080000, 0.000000, 0.080000, 0.000000)
1941:                   mad r18.xz, r29.yywy, l(0.500000, 0.000000, 0.500000, 0.000000), -r18.xxzx
1942:                   mul r33.xy, r18.xzxx, l(0.160000, 0.160000, 0.000000, 0.000000)
1943:                   mad r18.xz, -r30.xxyx, r30.xxyx, r28.xxzx
1944:                   add r18.xz, r18.xxzx, l(1.000000, 0.000000, 1.000000, 0.000000)
1945:                   mul r30.xy, r18.xzxx, l(0.160000, 0.160000, 0.000000, 0.000000)
1946:                   mul r18.xz, r28.yywy, l(0.160000, 0.000000, 0.160000, 0.000000)
1947:                   mov r33.z, r30.x
1948:                   mov r33.w, r18.x
1949:                   mov r31.z, r32.x
1950:                   mov r31.w, r29.x
1951:                   add r28.xyzw, r31.zwxz, r33.zwxz
1952:                   mov r30.z, r33.y
1953:                   mov r30.w, r18.z
1954:                   mov r32.z, r31.y
1955:                   mov r32.w, r29.z
1956:                   add r29.xyz, r30.zywz, r32.zywz
1957:                   div r30.xyz, r31.xzwx, r28.zwyz
1958:                   add r30.xyz, r30.xyzx, l(-2.500000, -0.500000, 1.500000, 0.000000)
1959:                   mul r30.xyz, r30.xyzx, cb5[64].xxxx
1960:                   div r31.xyz, r32.zywz, r29.xyzx
1961:                   add r31.xyz, r31.xyzx, l(-2.500000, -0.500000, 1.500000, 0.000000)
1962:                   mul r31.xyw, r31.xyxz, cb5[64].yyyy
1963:                   mul r32.xyzw, r28.zwyz, r29.xxxy
1964:                   mov r30.w, r31.x
1965:                   mad r33.xyzw, r27.xyxy, cb5[64].xyxy, r30.xwyw
1966:                   sample_c_lz(texture2d)(float,float,float,float) r16.w, r33.xyxx, t4.xxxx, s2, r20.w
1967:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r33.zwzz, t4.xxxx, s2, r20.w
1968:                   mul r18.x, r18.x, r32.y
1969:                   mad r16.w, r32.x, r16.w, r18.x
1970:                   mad r18.xz, r27.xxyx, cb5[64].xxyx, r30.zzwz
1971:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r18.xzxx, t4.xxxx, s2, r20.w
1972:                   mad r16.w, r32.z, r18.x, r16.w
1973:                   mov r31.z, r30.x
1974:                   mad r33.xyzw, r27.xyxy, cb5[64].xyxy, r31.zyzw
1975:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r33.xyxx, t4.xxxx, s2, r20.w
1976:                   mad r16.w, r32.w, r18.x, r16.w
1977:                   mul r32.xyzw, r28.xyzw, r29.yyzz
1978:                   mov r31.xz, r30.yyzy
1979:                   mad r30.xyzw, r27.xyxy, cb5[64].xyxy, r31.xyzy
1980:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r30.xyxx, t4.xxxx, s2, r20.w
1981:                   mad r16.w, r32.x, r18.x, r16.w
1982:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r30.zwzz, t4.xxxx, s2, r20.w
1983:                   mad r16.w, r32.y, r18.x, r16.w
1984:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r33.zwzz, t4.xxxx, s2, r20.w
1985:                   mad r16.w, r32.z, r18.x, r16.w
1986:                   iadd r18.x, r23.x, l(8)
1987:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r18.xz, r18.x, t2.xxyx
1988:                   add r28.xz, -r20.xxzx, l(1.000000, 0.000000, 1.000000, 0.000000)
1989:                   min r20.xz, r20.xxzx, r28.xxzx
1990:                   or r23.xyz, r23.yzwy, r26.yzwy
1991:                   or r21.w, r23.y, r23.x
1992:                   or r21.w, r23.z, r21.w
1993:                   and r22.w, r20.w, l(0x7fffffff)
1994:                   ult r22.w, l(0x7f800000), r22.w
1995:                   or r21.w, r21.w, r22.w
1996:                   mad r23.xyzw, r27.xyxy, cb5[64].xyxy, r31.xwzw
1997:                   sample_c_lz(texture2d)(float,float,float,float) r22.w, r23.xyxx, t4.xxxx, s2, r20.w
1998:                   mad r16.w, r32.w, r22.w, r16.w
1999:                   mul r22.w, r28.y, r29.z
2000:                   sample_c_lz(texture2d)(float,float,float,float) r20.w, r23.zwzz, t4.xxxx, s2, r20.w
2001:                   mad r16.w, r22.w, r20.w, r16.w
2002:                   add r18.x, -r27.w, r18.x
2003:                   mul r18.x, r18.x, l(0.250000)
2004:                   min r20.x, r20.z, r20.x
2005:                   min r18.x, r18.x, r20.x
2006:                   mul_sat r18.x, r18.x, l(20.000000)
2007:                   mad r20.x, r18.x, l(-2.000000), l(3.000000)
2008:                   mul r18.x, r18.x, r18.x
2009:                   mul r18.x, r18.x, r20.x
2010:                   min r18.x, r18.x, r18.z
2011:                   movc r15.z, r15.z, r18.x, r18.z
2012:                   add r16.w, r16.w, l(-1.000000)
2013:                   movc r16.w, r21.w, l(0), r16.w
2014:                   mad r15.z, r15.z, r16.w, l(1.000000)
2015:                 else
2016:                   dp3 r16.w, r4.xyzx, r24.yzwy
2017:                   add_sat r15.z, r16.w, l(1.000000)
2018:                 endif
2019:               else
2020:                 mov r15.z, l(1.000000)
2021:               endif
2022:               if_z cb3[r17.w + 6].w
2023:                 mul r20.xzw, r12.xxxx, cb3[r15.y + 6].xxyz
2024:                 add r16.w, l(1.000000), -cb3[r20.y + 6].y
2025:                 max r18.x, r20.z, r20.x
2026:                 max r18.x, r20.w, r18.x
2027:                 mul r18.x, r7.w, r18.x
2028:                 max r18.x, r18.x, l(1.000000)
2029:                 div r18.x, l(1.000000, 1.000000, 1.000000, 1.000000), r18.x
2030:                 mad r16.w, r18.x, cb3[r20.y + 6].y, r16.w
2031:                 mul r20.xzw, r16.wwww, cb3[r15.y + 6].xxyz
2032:                 mul r16.w, l(0.250000), cb3[r20.y + 6].x
2033:                 add_sat r18.x, r15.x, l(0.500000)
2034:                 mad r18.z, -cb3[r20.y + 6].x, l(0.250000), l(1.000000)
2035:                 mad r16.w, r18.x, r18.z, r16.w
2036:                 mul r20.xzw, r16.wwww, r20.xxzw
2037:                 mov r23.xyz, r22.xyzx
2038:                 mov r26.yzw, r22.xxyz
2039:                 mov r16.w, l(1.000000)
2040:                 mov r18.x, l(0)
2041:               else
2042:                 ieq r18.z, l(3), cb3[r17.w + 6].w
2043:                 if_nz r18.z
2044:                   mad r27.xy, cb3[r20.y + 6].xxxx, l(-0.600000, -0.400000, 0.000000, 0.000000), l(0.800000, 0.900000, 0.000000, 0.000000)
2045:                   add r18.z, -r27.x, r27.y
2046:                   add r21.w, r26.x, -r27.x
2047:                   div r18.z, l(1.000000, 1.000000, 1.000000, 1.000000), r18.z
2048:                   mul_sat r18.z, r18.z, r21.w
2049:                   mad r21.w, r18.z, l(-2.000000), l(3.000000)
2050:                   mul r18.z, r18.z, r18.z
2051:                   mul r18.z, r18.z, r21.w
2052:                   mul r18.z, r15.z, r18.z
2053:                   mul r12.x, r12.x, r18.z
2054:                   mul r27.xyz, r24.wyzw, cb0[6].xyzx
2055:                   mad r27.xyz, cb0[6].zxyz, r24.yzwy, -r27.xyzx
2056:                   mul r28.xyz, r27.xyzx, cb0[6].zxyz
2057:                   mad r27.xyz, cb0[6].yzxy, r27.yzxy, -r28.xyzx
2058:                   dp3 r18.z, r27.xyzx, r27.xyzx
2059:                   rsq r18.z, r18.z
2060:                   mul r27.xyz, r18.zzzz, r27.xyzx
2061:                   dp3_sat r18.y, r12.yzwy, -r27.xyzx
2062:                   mad r23.xyz, cb3[r20.y + 6].yyyy, r5.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000)
2063:                   mov r26.yzw, l(0, 0, 0, 0)
2064:                   mov r16.w, l(1.000000)
2065:                   mov r18.x, l(0)
2066:                 else
2067:                   ieq r18.z, l(1), cb3[r17.w + 6].w
2068:                   if_nz r18.z
2069:                     add r15.x, r15.x, cb3[r20.y + 6].x
2070:                     max_sat r15.x, r15.x, l(-1.000000)
2071:                     mul r18.y, r15.z, r15.x
2072:                     mul r26.yzw, r8.xxyz, cb3[r20.y + 6].yyyy
2073:                     mov r16.w, l(1.000000)
2074:                     mov r18.x, l(0)
2075:                   else
2076:                     ieq r15.x, l(2), cb3[r17.w + 6].w
2077:                     if_nz r15.x
2078:                       add r15.z, l(0.050000), cb3[r20.y + 6].x
2079:                       add r15.z, r3.y, -r15.z
2080:                       mul_sat r15.z, r15.z, l(-10.000000)
2081:                       mad r21.w, r15.z, l(-2.000000), l(3.000000)
2082:                       mul r15.z, r15.z, r15.z
2083:                       mul r15.z, r15.z, r21.w
2084:                       add r21.w, l(1.000000), -cb3[r20.y + 6].z
2085:                       mad r21.w, r6.x, cb3[r20.y + 6].z, r21.w
2086:                       mul r16.w, r15.z, r21.w
2087:                     else
2088:                       mov r16.w, l(1.000000)
2089:                     endif
2090:                     and r18.x, r15.x, cb3[r20.y + 6].y
2091:                     mov r26.yzw, l(0, 0, 0, 0)
2092:                   endif
2093:                   and r23.xyz, r14.xyzx, r18.zzzz
2094:                 endif
2095:                 mov r20.xzw, cb3[r15.y + 6].xxyz
2096:               endif
2097:               ine r15.x, l(3), cb3[r17.w + 6].w
2098:               if_nz r15.x
2099:                 mad r15.x, r18.x, r3.x, r3.z
2100:                 mad r24.yzw, r1.xxyz, r1.wwww, r24.yyzw
2101:                 dp3 r15.y, r24.yzwy, r24.yzwy
2102:                 rsq r15.y, r15.y
2103:                 mul r24.yzw, r15.yyyy, r24.yyzw
2104:                 dp3 r15.y, r13.xyzx, r24.yzwy
2105:                 mul r15.z, r15.x, r15.x
2106:                 mad r17.w, r15.y, r15.z, -r15.y
2107:                 mad r15.y, r17.w, r15.y, l(1.000000)
2108:                 mul r15.y, r15.y, r15.y
2109:                 ne r17.w, r15.y, r15.z
2110:                 div r15.y, r15.z, r15.y
2111:                 movc r15.y, r17.w, r15.y, l(1.000000)
2112:                 mad r15.x, r24.x, l(2.000000), r15.x
2113:                 add r15.x, r15.x, l(0.000100)
2114:                 div r15.x, l(0.500000), r15.x
2115:                 mad r15.x, r15.y, r15.x, l(-0.000061)
2116:                 max r15.x, r15.x, l(0)
2117:                 min r15.x, r15.x, l(20.000000)
2118:                 mul r15.xyz, r15.xxxx, r25.yzwy
2119:                 mul r15.xyz, r16.wwww, r15.xyzx
2120:                 mul r15.xyz, r15.xyzx, cb3[r18.w + 6].zzzz
2121:               else
2122:                 mov r15.xyz, l(0, 0, 0, 0)
2123:               endif
2124:               mul r18.xzw, r12.xxxx, r20.xxzw
2125:               add r20.xyz, r23.xyzx, -r26.yzwy
2126:               mad r20.xyz, r18.yyyy, r20.xyzx, r26.yzwy
2127:               mul r20.xyz, r18.xzwx, r20.xyzx
2128:               mul r15.xyz, r15.xyzx, r18.xzwx
2129:               mul r15.xyz, r18.yyyy, r15.xyzx
2130:               mad r15.xyz, r20.xyzx, r11.wwww, r15.xyzx
2131:               add r17.xyz, r15.xyzx, r17.xyzx
2132:             endif
2133:           else
2134:             mov r19.w, l(0)
2135:           endif
2136:           movc r17.xyz, r19.wwww, r21.xyzx, r17.xyzx
2137:         endif
2138:       endif
2139:     else
2140:       mov r17.xyz, r19.xyzx
2141:     endif
2142:     mov r10.w, r14.w
2143:   endloop
2144:   mov r16.xyz, r17.xyzx
2145:   iadd r8.w, r8.w, l(1)
2146: endloop
2147: lt r1.x, l(0.500000), cb6[3].x
2148: if_nz r1.x
2149:   dp3 r1.x, r16.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
2150:   add r3.xyz, -r1.xxxx, r16.xyzx
2151:   mad r1.xyz, cb6[3].zzzz, r3.xyzx, r1.xxxx
2152:   add r1.xyz, r1.xyzx, l(-0.500000, -0.500000, -0.500000, 0.000000)
2153:   mad r1.xyz, cb6[3].wwww, r1.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000)
2154:   mul r3.xyz, r1.xyzx, cb6[3].yyyy
2155:   mad r1.xyz, -r1.xyzx, cb6[3].yyyy, cb6[8].xyzx
2156:   mad r1.xyz, cb6[8].wwww, r1.xyzx, r3.xyzx
2157:   add r2.w, l(1.000000), -cb6[4].x
2158:   mov_sat r13.w, r13.w
2159:   add r3.x, -r13.w, l(1.000000)
2160:   add r3.y, -r2.w, l(1.000000)
2161:   add r2.w, -r2.w, r3.x
2162:   div r3.x, l(1.000000, 1.000000, 1.000000, 1.000000), r3.y
2163:   mul_sat r2.w, r2.w, r3.x
2164:   mad r3.x, r2.w, l(-2.000000), l(3.000000)
2165:   mul r2.w, r2.w, r2.w
2166:   mul r2.w, r2.w, r3.x
2167:   mul r3.xyz, r2.wwww, cb6[9].xyzx
2168:   mad r16.xyz, r3.xyzx, cb6[4].yyyy, r1.xyzx
2169: endif
2170: mul r1.xyz, r16.xyzx, cb1[27].yyyy
2171: eq r2.w, l(1.000000), cb6[2].x
2172: movc o0.w, r2.w, r5.w, l(1.000000)
2173: lt r2.w, cb1[122].w, l(0.500000)
2174: if_nz r2.w
2175:   mul r2.w, r0.w, r1.w
2176:   mad r3.x, r7.y, cb1[74].w, cb1[75].w
2177:   mad r3.y, r2.w, cb1[72].w, -cb1[71].w
2178:   max r3.xy, r3.xyxx, l(0.010000, 0.000000, 0.000000, 0.000000)
2179:   mul r3.z, r3.x, l(-1.442695)
2180:   exp r3.z, r3.z
2181:   add r3.z, -r3.z, l(1.000000)
2182:   div r3.x, r3.z, r3.x
2183:   mad r3.z, r7.y, cb1[74].w, cb1[76].w
2184:   mul r3.z, r3.z, l(1.442695)
2185:   exp r3.z, r3.z
2186:   mul r3.x, r3.z, r3.x
2187:   mul r3.x, r3.x, -r3.y
2188:   mul r3.xyz, r3.xxxx, cb1[73].xyzx
2189:   mul r3.xyz, r3.xyzx, l(1.442695, 1.442695, 1.442695, 0.000000)
2190:   exp r3.xyz, r3.xyzx
2191:   dp3 r3.w, -r2.xyzx, cb1[72].xyzx
2192:   mad r4.x, cb1[73].w, cb1[73].w, l(1.000000)
2193:   dp2 r4.y, r3.wwww, cb1[73].wwww
2194:   add r4.x, -r4.y, r4.x
2195:   lt r4.y, l(0), cb1[83].z
2196:   if_nz r4.y
2197:     and r11.z, l(7), cb1[26].w
2198:     imad r4.yzw, r11.xxyz, l(0, 0x0019660d, 0x0019660d, 0x0019660d), l(0.000000, 0.014584, 0.014584, 0.014584)
2199:     imad r4.y, r4.z, r4.w, r4.y
2200:     imad r4.z, r4.w, r4.y, r4.z
2201:     imad r4.w, r4.y, r4.z, r4.w
2202:     imad r5.x, r4.z, r4.w, r4.y
2203:     dp3 r0.x, -r2.xyzx, -r0.xyzx
2204:     lt r0.y, l(0.000000), r0.x
2205:     div r0.x, l(1.000000, 1.000000, 1.000000, 1.000000), r0.x
2206:     and r0.x, r0.x, r0.y
2207:     mul r0.x, r0.x, cb1[83].w
2208:     div r0.y, l(1.000000, 1.000000, 1.000000, 1.000000), r2.w
2209:     mul r0.z, r0.y, r0.x
2210:     mad r4.y, r0.z, v2.y, cb0[44].y
2211:     mad r0.z, -r0.z, v2.y, v2.y
2212:     mad r0.x, -r0.x, r0.y, l(1.000000)
2213:     mul r0.y, r2.w, r0.x
2214:     mul r5.z, r0.z, cb1[77].z
2215:     mul r0.z, r0.z, cb1[80].x
2216:     max r0.z, r0.z, l(-127.000000)
2217:     add r5.w, r4.y, -cb1[77].x
2218:     mul r5.w, r5.w, cb1[77].z
2219:     max r5.zw, r5.zzzw, l(0.000000, 0.000000, -127.000000, -127.000000)
2220:     exp r5.w, -r5.w
2221:     mul r5.w, r5.w, cb1[77].y
2222:     lt r6.x, l(0.000000), abs(r5.z)
2223:     exp r6.y, -r5.z
2224:     add r6.y, -r6.y, l(1.000000)
2225:     div r6.y, r6.y, r5.z
2226:     mad r5.z, -r5.z, l(0.240227), l(0.693147)
2227:     movc r5.z, r6.x, r6.y, r5.z
2228:     add r4.y, r4.y, -cb1[80].z
2229:     mul r4.y, r4.y, cb1[80].x
2230:     max r4.y, r4.y, l(-127.000000)
2231:     exp r4.y, -r4.y
2232:     mul r4.y, r4.y, cb1[80].y
2233:     lt r6.x, l(0.000000), abs(r0.z)
2234:     exp r6.y, -r0.z
2235:     add r6.y, -r6.y, l(1.000000)
2236:     div r6.y, r6.y, r0.z
2237:     mad r0.z, -r0.z, l(0.240227), l(0.693147)
2238:     movc r0.z, r6.x, r6.y, r0.z
2239:     mul r0.z, r0.z, r4.y
2240:     mad r0.z, r5.w, r5.z, r0.z
2241:     mad_sat r5.zw, r2.wwww, cb1[78].wwwy, cb1[78].zzzx
2242:     mul r0.y, r0.y, r0.z
2243:     exp r0.y, -r0.y
2244:     min r0.y, r0.y, l(1.000000)
2245:     max r0.y, r0.y, cb1[79].w
2246:     add r0.y, r5.w, r0.y
2247:     add r0.y, r5.z, r0.y
2248:     min r0.y, r0.y, l(1.000000)
2249:     imad r5.y, r4.w, r5.x, r4.z
2250:     ushr r4.yz, r5.xxyx, l(0, 16, 16, 0)
2251:     utof r4.yz, r4.yyzy
2252:     mad r4.yz, r4.yyzy, l(0.000000, 0.000031, 0.000031, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
2253:     mad r4.yz, r4.yyzy, cb1[87].wwww, r10.xxyx
2254:     mul r6.xy, r4.yzyy, cb1[85].xyxx
2255:     mad r4.y, v0.w, cb1[84].x, cb1[84].y
2256:     log r4.y, r4.y
2257:     mul r4.y, r4.y, cb1[84].z
2258:     div r6.z, r4.y, cb1[83].z
2259:     sample_l(texture3d)(float,float,float,float) r6.xyzw, r6.xyzx, t24.xyzw, s0, l(0)
2260:     add r4.y, v0.w, -cb1[86].z
2261:     mul_sat r4.y, r4.y, l(1000000.000000)
2262:     add r6.xyzw, r6.xyzw, l(-0.000000, -0.000000, -0.000000, -1.000000)
2263:     mad r6.xyzw, r4.yyyy, r6.xyzw, l(0.000000, 0.000000, 0.000000, 1.000000)
2264:     add r4.y, -r0.y, l(1.000000)
2265:     dp3_sat r4.z, r2.xyzx, cb1[81].xyzx
2266:     log r4.z, r4.z
2267:     mul r4.z, r4.z, cb1[82].w
2268:     exp r4.z, r4.z
2269:     mul r5.xyw, r4.zzzz, cb1[82].xyxz
2270:     mad r0.x, r0.x, r2.w, -cb1[81].w
2271:     max r0.x, r0.x, l(0)
2272:     mul r0.x, r0.x, r0.z
2273:     exp r0.x, -r0.x
2274:     min r0.x, r0.x, l(1.000000)
2275:     add r0.x, -r0.x, l(1.000000)
2276:     mul r5.xyw, r0.xxxx, r5.xyxw
2277:     add r0.x, -r5.z, l(1.000000)
2278:     mul r5.xyz, r0.xxxx, r5.xywx
2279:     mad r4.yzw, cb1[79].xxyz, r4.yyyy, r5.xxyz
2280:     mad r4.yzw, r4.yyzw, r6.wwww, r6.xxyz
2281:     mul r0.x, r0.y, r6.w
2282:   else
2283:     mul r0.y, v2.y, cb1[77].z
2284:     mul r0.z, v2.y, cb1[80].x
2285:     max r0.yz, r0.yyzy, l(0.000000, -127.000000, -127.000000, 0.000000)
2286:     add r5.x, cb0[44].y, -cb1[77].x
2287:     mul r5.x, r5.x, cb1[77].z
2288:     max r5.x, r5.x, l(-127.000000)
2289:     exp r5.x, -r5.x
2290:     mul r5.x, r5.x, cb1[77].y
2291:     lt r5.y, l(0.000000), abs(r0.y)
2292:     exp r5.z, -r0.y
2293:     add r5.z, -r5.z, l(1.000000)
2294:     div r5.z, r5.z, r0.y
2295:     mad r0.y, -r0.y, l(0.240227), l(0.693147)
2296:     movc r0.y, r5.y, r5.z, r0.y
2297:     add r5.y, cb0[44].y, -cb1[80].z
2298:     mul r5.y, r5.y, cb1[80].x
2299:     max r5.y, r5.y, l(-127.000000)
2300:     exp r5.y, -r5.y
2301:     mul r5.y, r5.y, cb1[80].y
2302:     lt r5.z, l(0.000000), abs(r0.z)
2303:     exp r5.w, -r0.z
2304:     add r5.w, -r5.w, l(1.000000)
2305:     div r5.w, r5.w, r0.z
2306:     mad r0.z, -r0.z, l(0.240227), l(0.693147)
2307:     movc r0.z, r5.z, r5.w, r0.z
2308:     mul r0.z, r0.z, r5.y
2309:     mad r0.y, r5.x, r0.y, r0.z
2310:     mad_sat r5.xy, r2.wwww, cb1[78].wyww, cb1[78].zxzz
2311:     mul r0.z, r2.w, r0.y
2312:     exp r0.z, -r0.z
2313:     min r0.z, r0.z, l(1.000000)
2314:     max r0.z, r0.z, cb1[79].w
2315:     add r0.z, r5.y, r0.z
2316:     add r0.z, r5.x, r0.z
2317:     min r0.x, r0.z, l(1.000000)
2318:     dp3_sat r2.x, r2.xyzx, cb1[81].xyzx
2319:     log r2.x, r2.x
2320:     mul r2.x, r2.x, cb1[82].w
2321:     exp r2.x, r2.x
2322:     mul r2.xyz, r2.xxxx, cb1[82].xyzx
2323:     mad r0.w, r0.w, r1.w, -cb1[81].w
2324:     max r0.w, r0.w, l(0)
2325:     mul r0.y, r0.w, r0.y
2326:     exp r0.y, -r0.y
2327:     min r0.y, r0.y, l(1.000000)
2328:     add r0.yz, -r0.yyxy, l(0.000000, 1.000000, 1.000000, 0.000000)
2329:     mul r2.xyz, r0.yyyy, r2.xyzx
2330:     add r0.y, -r5.x, l(1.000000)
2331:     mul r2.xyz, r0.yyyy, r2.xyzx
2332:     mad r4.yzw, cb1[79].xxyz, r0.zzzz, r2.xxyz
2333:   endif
2334:   mul r0.yzw, r0.xxxx, r3.xxyz
2335:   mad r1.w, r3.w, r3.w, l(1.000000)
2336:   mul r1.w, r1.w, l(0.059683)
2337:   mad r2.xyz, cb1[74].xyzx, r1.wwww, cb1[76].xyzx
2338:   mad r1.w, -cb1[73].w, cb1[73].w, l(1.000000)
2339:   mul r2.w, r4.x, l(12.566371)
2340:   sqrt r3.w, r4.x
2341:   mul r2.w, r2.w, r3.w
2342:   max r2.w, r2.w, l(0.001000)
2343:   div r1.w, r1.w, r2.w
2344:   mad_sat r2.xyz, cb1[75].xyzx, r1.wwww, r2.xyzx
2345:   mul r2.xyz, r2.xyzx, l(255.000000, 255.000000, 255.000000, 0.000000)
2346:   add r3.xyz, -r3.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
2347:   mul r2.xyz, r2.xyzx, r3.xyzx
2348:   mad r2.xyz, r2.xyzx, r0.xxxx, r4.yzwy
2349:   mad o0.xyz, r1.xyzx, r0.yzwy, r2.xyzx
2350: else
2351:   mov o0.xyz, r1.xyzx
2352: endif
2353: mov o1.z, l(1.000000)
2354: ret
