Shader hash 0cb58f83-d99f41b5-893098d2-55cc6a63
ps_5_0
      dcl_globalFlags refactoringAllowed
      dcl_immediateConstantBuffer {
			{ 1.000000, 0, 0, 0}, 
			{ 0, 1.000000, 0, 0}, 
			{ 0, 0, 1.000000, 0}, 
			{ 0, 0, 0, 1.000000}, 
			{ 2, 1, -1.000000, 1.000000}, 
			{ 2, 1, 1.000000, 1.000000}, 
			{ 0, 2, 1.000000, -1.000000}, 
			{ 0, 2, 1.000000, 1.000000}, 
			{ 0, 1, 1.000000, 1.000000}, 
			{ 0, 1, -1.000000, 1.000000} }
      dcl_constantbuffer cb0[45], immediateIndexed
      dcl_constantbuffer cb1[141], immediateIndexed
      dcl_constantbuffer cb2[4094], dynamicIndexed
      dcl_constantbuffer cb3[2054], dynamicIndexed
      dcl_constantbuffer cb4[4], immediateIndexed
      dcl_constantbuffer cb5[66], immediateIndexed
      dcl_constantbuffer cb6[10], immediateIndexed
      dcl_constantbuffer cb7[160], dynamicIndexed
      dcl_sampler s0, mode_default
      dcl_sampler s1, mode_default
      dcl_sampler s2, mode_comparison
      dcl_resource_structured t0, 4
      dcl_resource_structured t1, 16
      dcl_resource_raw t2
      dcl_resource_texture2d (float,float,float,float) t3
      dcl_resource_texture2d (float,float,float,float) t4
      dcl_resource_texture3d (float,float,float,float) t5
      dcl_resource_texture3d (float,float,float,float) t6
      dcl_resource_texture3d (float,float,float,float) t7
      dcl_resource_texture3d (float,float,float,float) t8
      dcl_resource_texture3d (float,float,float,float) t9
      dcl_resource_texture3d (float,float,float,float) t10
      dcl_resource_texture2d (float,float,float,float) t11
      dcl_resource_texture2d (float,float,float,float) t12
      dcl_resource_texture2d (float,float,float,float) t13
      dcl_resource_texture2d (float,float,float,float) t14
      dcl_resource_texture2d (float,float,float,float) t15
      dcl_resource_texture2d (float,float,float,float) t16
      dcl_resource_texture2d (float,float,float,float) t17
      dcl_resource_texture2d (float,float,float,float) t18
      dcl_resource_texture2d (float,float,float,float) t19
      dcl_resource_texture2d (float,float,float,float) t20
      dcl_resource_texturecube (float,float,float,float) t21
      dcl_resource_texture2d (float,float,float,float) t22
      dcl_resource_texture3d (float,float,float,float) t23
      dcl_input_ps_siv linear noperspective v0.xyw, position
      dcl_input_ps linear v1.xy
      dcl_input_ps linear v2.xyz
      dcl_input_ps linear v3.xyz
      dcl_input_ps linear v4.xyzw
      dcl_input_ps linear v5.xyz
      dcl_input_ps linear v6.xyz
      dcl_input_ps linear v7.xyz
      dcl_input_ps linear v8.xyz
      dcl_input_ps nointerpolation v9.x
      dcl_input_ps_sgv nointerpolation v10.x, isfrontface
      dcl_output o0.xyzw
      dcl_output o1.xyzw
      dcl_temps 35
   0: mov r0.x, cb0[0].z
   1: mov r0.y, cb0[1].z
   2: mov r0.z, cb0[2].z
   3: add r1.xyz, r0.xyzx, v2.xyzx
   4: mad r1.xyz, cb1[4].wwww, r1.xyzx, -v2.xyzx
   5: dp3 r0.w, r1.xyzx, r1.xyzx
   6: max r1.w, r0.w, l(0.000000)
   7: rsq r1.w, r1.w
   8: mul r2.xyz, r1.wwww, r1.xyzx
   9: ishl r2.w, v9.x, l(4)
  10: and r3.x, l(16), cb2[r2.w + 4].w
  11: if_nz r3.x
  12:   iadd r3.y, l(2), cb2[r2.w + 5].x
  13:   ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.x, r3.y, l(12), t1.xxxx
  14:   ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.y, cb2[r2.w + 5].x, l(12), t1.xxxx
  15: else
  16:   mov r4.xy, cb2[r2.w + 3].zxzz
  17: endif
  18: sample_b(texture2d)(float,float,float,float) r5.xyzw, v1.xyxx, t17.xyzw, s1, cb1[26].x
  19: sample_b(texture2d)(float,float,float,float) r6.xyzw, v1.xyxx, t18.xyzw, s1, cb1[26].x
  20: add r3.y, -r6.w, l(1.000000)
  21: mul r5.xyzw, r5.xyzw, cb6[6].xyzw
  22: add r7.xyz, v2.xyzx, cb0[44].xyzx
  23: add r4.xz, -r4.yyxy, r7.xxzx
  24: mov r4.y, l(0.000061)
  25: dp3 r3.z, r4.xyzx, r4.xyzx
  26: rsq r3.z, r3.z
  27: mul r4.xyz, r3.zzzz, r4.xyzx
  28: sample_b(texture2d)(float,float,float,float) r8.xyz, v1.xyxx, t19.xywz, s1, cb1[26].x
  29: mul r8.x, r8.x, r8.z
  30: mad r3.zw, r8.xxxy, l(0.000000, 0.000000, 2.000000, 2.000000), l(0.000000, 0.000000, -1.000000, -1.000000)
  31: dp2 r4.w, r3.zwzz, r3.zwzz
  32: min r4.w, r4.w, l(1.000000)
  33: add r4.w, -r4.w, l(1.000000)
  34: sqrt r4.w, r4.w
  35: max r4.w, r4.w, l(0.000000)
  36: mul r3.zw, r3.zzzw, cb6[0].wwww
  37: mul r8.xyz, r5.zxyz, l(12.920000, 12.920000, 12.920000, 0.000000)
  38: log r9.xyz, abs(r5.zxyz)
  39: mul r9.xyz, r9.xyzx, l(0.416667, 0.416667, 0.416667, 0.000000)
  40: exp r9.xyz, r9.xyzx
  41: mad r9.xyz, r9.xyzx, l(1.055000, 1.055000, 1.055000, 0.000000), l(-0.055000, -0.055000, -0.055000, 0.000000)
  42: ge r10.xyz, l(0.003131, 0.003131, 0.003131, 0.000000), r5.zxyz
  43: movc_sat r8.xyz, r10.xyzx, r8.xyzx, r9.xyzx
  44: mul r9.xw, r8.xxxz, l(31.000000, 0.000000, 0.000000, 0.968750)
  45: round_ni r7.w, r9.x
  46: mad r9.yz, r8.yyzy, l(0.000000, 0.030273, 0.968750, 0.000000), l(0.000000, 0.000488, 0.015625, 0.000000)
  47: mad r9.x, r7.w, l(0.031250), r9.y
  48: sample_l(texture2d)(float,float,float,float) r8.yzw, r9.xzxx, t13.wxyz, s0, l(0)
  49: add r9.xy, r9.xwxx, l(0.031250, 0.015625, 0.000000, 0.000000)
  50: sample_l(texture2d)(float,float,float,float) r9.xyz, r9.xyxx, t13.xyzw, s0, l(0)
  51: mad r7.w, r8.x, l(31.000000), -r7.w
  52: add r9.xyz, -r8.yzwy, r9.xyzx
  53: mad r8.xyz, r7.wwww, r9.xyzx, r8.yzwy
  54: sample_b(texture2d)(float,float,float,float) r9.xyz, v1.xyxx, t20.xyzw, s1, cb1[26].x
  55: mul r10.xyz, v3.zxyz, v4.yzxy
  56: mad r10.xyz, v3.yzxy, v4.zxyz, -r10.xyzx
  57: mul r10.xyz, r10.xyzx, v4.wwww
  58: mul r10.xyz, r3.wwww, r10.xyzx
  59: mad r10.xyz, r3.zzzz, v4.xyzx, r10.xyzx
  60: mad r10.xyz, r4.wwww, v3.xyzx, r10.xyzx
  61: mad r3.z, cb6[1].y, l(2.000000), l(-1.000000)
  62: movc r3.z, v10.x, l(1.000000), r3.z
  63: dp3 r3.w, r10.xyzx, r10.xyzx
  64: max r3.w, r3.w, l(0.000000)
  65: rsq r3.w, r3.w
  66: mul r10.xyz, r3.wwww, r10.xyzx
  67: mul r11.xyz, r3.zzzz, r10.xyzx
  68: dp3 r3.w, v3.xyzx, v3.xyzx
  69: rsq r3.w, r3.w
  70: mul r10.xzw, r3.wwww, v3.xxyz
  71: mul r10.xzw, r3.zzzz, r10.xxzw
  72: ftou r12.xy, v0.xyxx
  73: lt r3.w, l(0.500000), cb1[120].x
  74: movc r3.w, r3.w, cb1[120].y, cb2[r2.w + 13].x
  75: and r4.w, r3.w, l(255)
  76: utof r13.x, r4.w
  77: ubfe r14.xy, l(8, 8, 0, 0), l(8, 16, 0, 0), r3.wwww
  78: utof r13.yz, r14.xxyx
  79: ushr r3.w, r3.w, l(24)
  80: utof r13.w, r3.w
  81: mul r14.xyzw, r13.xyzw, l(0.003922, 0.003922, 0.003922, 0.003922)
  82: add r3.w, cb1[120].w, -cb2[r2.w + 13].y
  83: mad r2.w, cb1[120].x, r3.w, cb2[r2.w + 13].y
  84: add r2.w, -r7.y, r2.w
  85: add r2.w, r2.w, l(0.200000)
  86: mul_sat r2.w, r2.w, l(2.857143)
  87: mad r3.w, r2.w, l(-2.000000), l(3.000000)
  88: mul r2.w, r2.w, r2.w
  89: mul r2.w, r2.w, r3.w
  90: mul r2.w, r14.y, r2.w
  91: max r3.w, r2.w, r14.z
  92: add r4.w, l(1.000000), -cb1[29].x
  93: mad r4.w, cb1[122].w, r4.w, cb1[29].x
  94: mul r4.w, r4.w, cb1[27].x
  95: lt r7.w, cb1[111].y, l(0.500000)
  96: if_nz r7.w
  97:   mad r15.xyz, cb0[6].xzyx, -cb1[137].wwww, cb1[135].xzyx
  98:   add r15.xyz, r7.xzyx, -r15.xyzx
  99:   max r7.w, abs(r15.y), abs(r15.x)
 100:   add r7.w, r7.w, l(-464.000000)
 101:   mul_sat r7.w, r7.w, l(0.031250)
 102:   add r8.w, abs(r15.z), l(-208.000000)
 103:   mul_sat r8.w, r8.w, l(0.031250)
 104:   max r7.w, r7.w, r8.w
 105:   ne r8.w, l(0), cb1[135].w
 106:   lt r9.w, r7.w, l(1.000000)
 107:   and r8.w, r8.w, r9.w
 108:   if_nz r8.w
 109:     mad r15.xyz, cb0[6].xzyx, -cb1[137].yyyy, cb1[135].xzyx
 110:     add r15.xyz, r7.xzyx, -r15.xyzx
 111:     max r8.w, abs(r15.y), abs(r15.x)
 112:     add r8.w, r8.w, l(-29.000000)
 113:     mul_sat r8.w, r8.w, l(0.500000)
 114:     add r9.w, abs(r15.z), l(-13.000000)
 115:     mul_sat r9.w, r9.w, l(0.500000)
 116:     max r8.w, r8.w, r9.w
 117:     lt r9.w, r8.w, l(1.000000)
 118:     if_nz r9.w
 119:       mad r15.xyz, r7.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 120:       mul r16.xyz, r15.xyzx, cb1[136].xyzx
 121:       round_ni r16.xyz, r16.xyzx
 122:       mad r15.xyz, r15.xyzx, cb1[136].xyzx, -r16.xyzx
 123:       sample_l(texture3d)(float,float,float,float) r16.xyw, r15.xyzx, t5.yzwx, s1, l(0)
 124:       add r9.w, -r8.w, l(1.000000)
 125:       mul r13.y, l(0.500000), cb1[136].y
 126:       mad r13.z, -cb1[136].y, l(0.500000), l(1.000000)
 127:       max r13.y, r13.y, r15.y
 128:       min r13.y, r13.z, r13.y
 129:       mul r15.w, r13.y, l(0.333333)
 130:       sample_l(texture3d)(float,float,float,float) r17.xyzw, r15.xwzx, t6.xyzw, s0, l(0)
 131:       mad r13.y, r17.w, r9.w, r7.w
 132:       add r18.xyz, r15.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 133:       sample_l(texture3d)(float,float,float,float) r18.xyz, r18.xyzx, t6.xyzw, s0, l(0)
 134:       mad r18.xyz, r18.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 135:       mul r18.xyz, r16.yyyy, r18.xyzx
 136:       mov r18.w, r16.y
 137:       mul r18.xyzw, r9.wwww, r18.xyzw
 138:       add r15.xyz, r15.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 139:       sample_l(texture3d)(float,float,float,float) r15.xyz, r15.xyzx, t6.xyzw, s0, l(0)
 140:       mad r15.xyz, r15.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 141:       mul r15.xyz, r16.xxxx, r15.xyzx
 142:       mov r15.w, r16.x
 143:       mul r15.xyzw, r9.wwww, r15.xyzw
 144:       mad r17.xyz, r17.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 145:       mul r16.xyz, r16.wwww, r17.xyzx
 146:       mul r16.xyzw, r9.wwww, r16.xyzw
 147:     else
 148:       mov r18.xyzw, l(0, 0, 0, 0)
 149:       mov r15.xyzw, l(0, 0, 0, 0)
 150:       mov r16.xyzw, l(0, 0, 0, 0)
 151:       mov r13.y, r7.w
 152:     endif
 153:     mad r17.xyz, cb0[6].xzyx, -cb1[137].zzzz, cb1[135].xzyx
 154:     add r17.xyz, r7.xzyx, -r17.xyzx
 155:     max r9.w, abs(r17.y), abs(r17.x)
 156:     add r9.w, r9.w, l(-116.000000)
 157:     mul_sat r9.w, r9.w, l(0.125000)
 158:     add r13.z, abs(r17.z), l(-52.000000)
 159:     mul_sat r13.z, r13.z, l(0.125000)
 160:     max r9.w, r9.w, r13.z
 161:     lt r13.z, r9.w, l(1.000000)
 162:     if_nz r13.z
 163:       mad r17.xyz, r7.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 164:       mul r19.xyz, r17.xyzx, cb1[136].xyzx
 165:       round_ni r19.xyz, r19.xyzx
 166:       mad r17.xyz, r17.xyzx, cb1[136].xyzx, -r19.xyzx
 167:       sample_l(texture3d)(float,float,float,float) r19.xyw, r17.xyzx, t7.yzwx, s1, l(0)
 168:       add r13.z, -r9.w, l(1.000000)
 169:       mul r8.w, r8.w, r13.z
 170:       mul r13.z, l(0.500000), cb1[136].y
 171:       mad r14.y, -cb1[136].y, l(0.500000), l(1.000000)
 172:       max r13.z, r13.z, r17.y
 173:       min r13.z, r14.y, r13.z
 174:       mul r17.w, r13.z, l(0.333333)
 175:       sample_l(texture3d)(float,float,float,float) r20.xyzw, r17.xwzx, t8.xyzw, s0, l(0)
 176:       mad r13.y, r20.w, r8.w, r13.y
 177:       add r21.xyz, r17.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 178:       sample_l(texture3d)(float,float,float,float) r21.xyz, r21.xyzx, t8.xyzw, s0, l(0)
 179:       mad r21.xyz, r21.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 180:       mul r21.xyz, r19.yyyy, r21.xyzx
 181:       mov r21.w, r19.y
 182:       mad r18.xyzw, r21.xyzw, r8.wwww, r18.xyzw
 183:       add r17.xyz, r17.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 184:       sample_l(texture3d)(float,float,float,float) r17.xyz, r17.xyzx, t8.xyzw, s0, l(0)
 185:       mad r17.xyz, r17.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 186:       mul r17.xyz, r19.xxxx, r17.xyzx
 187:       mov r17.w, r19.x
 188:       mad r15.xyzw, r17.xyzw, r8.wwww, r15.xyzw
 189:       mad r17.xyz, r20.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 190:       mul r19.xyz, r19.wwww, r17.xyzx
 191:       mad r16.xyzw, r19.xyzw, r8.wwww, r16.xyzw
 192:     endif
 193:     lt r8.w, l(0), r9.w
 194:     if_nz r8.w
 195:       mad r17.xyz, r7.xyzx, l(0.125000, 0.125000, 0.125000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 196:       mul r19.xyz, r17.xyzx, cb1[136].xyzx
 197:       mul r20.xyz, l(0.500000, 0.500000, 0.500000, 0.000000), cb1[136].xyzx
 198:       round_ni r19.xyz, r19.xyzx
 199:       mad r17.xyz, r17.xyzx, cb1[136].xyzx, -r19.xyzx
 200:       mad r19.xyz, -cb1[136].xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), l(1.000000, 1.000000, 1.000000, 0.000000)
 201:       max r17.xyz, r20.xyzx, r17.xyzx
 202:       min r17.xyz, r19.xyzx, r17.xyzx
 203:       sample_l(texture3d)(float,float,float,float) r21.xyw, r17.xyzx, t9.yzwx, s1, l(0)
 204:       add r8.w, -r7.w, l(1.000000)
 205:       mul r8.w, r8.w, r9.w
 206:       max r9.w, r20.y, r17.y
 207:       min r9.w, r19.y, r9.w
 208:       mul r17.w, r9.w, l(0.333333)
 209:       sample_l(texture3d)(float,float,float,float) r19.xyzw, r17.xwzx, t10.xyzw, s0, l(0)
 210:       add r20.xyz, r17.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 211:       sample_l(texture3d)(float,float,float,float) r20.xyz, r20.xyzx, t10.xyzw, s0, l(0)
 212:       mad r20.xyz, r20.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 213:       mul r20.xyz, r21.yyyy, r20.xyzx
 214:       mov r20.w, r21.y
 215:       mad r18.xyzw, r20.xyzw, r8.wwww, r18.xyzw
 216:       add r17.xyz, r17.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 217:       sample_l(texture3d)(float,float,float,float) r17.xyz, r17.xyzx, t10.xyzw, s0, l(0)
 218:       mad r17.xyz, r17.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 219:       mul r17.xyz, r21.xxxx, r17.xyzx
 220:       mov r17.w, r21.x
 221:       mad r15.xyzw, r17.xyzw, r8.wwww, r15.xyzw
 222:       mad r17.xyz, r19.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 223:       mul r21.xyz, r21.wwww, r17.xyzx
 224:       mad r16.xyzw, r21.xyzw, r8.wwww, r16.xyzw
 225:       mad r13.y, r19.w, r8.w, r13.y
 226:     endif
 227:     mad_sat r8.w, r13.y, l(2.000000), l(-1.000000)
 228:     add r17.x, -r7.w, r8.w
 229:     add r7.w, r7.w, r8.w
 230:     mul r17.y, r7.w, l(0.500000)
 231:   else
 232:     mov r18.xyzw, l(0, 0, 0, 0)
 233:     mov r15.xyzw, l(0, 0, 0, 0)
 234:     mov r16.xyzw, l(0, 0, 0, 0)
 235:     mov r17.xy, l(0.000000, 1.000000, 0.000000, 0.000000)
 236:   endif
 237:   mul r19.xyzw, r17.yyyx, cb1[138].xyzw
 238:   mad r19.y, r19.w, l(0.500000), r19.y
 239:   mul r13.yz, r17.yyxy, cb1[138].wwyw
 240:   mad r19.w, r13.z, l(0.375000), r13.y
 241:   add r16.xyzw, r16.xyzw, r19.xyzw
 242:   mul r19.xyzw, r17.yyyx, cb1[139].xyzw
 243:   mad r19.y, r19.w, l(0.500000), r19.y
 244:   mul r13.yz, r17.yyxy, cb1[139].wwyw
 245:   mad r19.w, r13.z, l(0.375000), r13.y
 246:   add r15.xyzw, r15.xyzw, r19.xyzw
 247:   mul r19.xyzw, r17.yyyx, cb1[140].xyzw
 248:   mad r19.y, r19.w, l(0.500000), r19.y
 249:   mul r13.yz, r17.yyxy, cb1[140].wwyw
 250:   mad r19.w, r13.z, l(0.375000), r13.y
 251:   add r17.xyzw, r18.xyzw, r19.xyzw
 252:   mov r11.w, l(1.000000)
 253:   dp4 r18.x, r16.xyzw, r11.xyzw
 254:   dp4 r18.y, r15.xyzw, r11.xyzw
 255:   dp4 r18.z, r17.xyzw, r11.xyzw
 256:   max r18.xyz, r18.xyzx, l(0, 0, 0, 0)
 257:   mul r19.xyz, r4.wwww, r18.xyzx
 258:   mul r20.xyz, r15.xyzx, l(0.715200, 0.715200, 0.715200, 0.000000)
 259:   mad r20.xyz, r16.xyzx, l(0.212600, 0.212600, 0.212600, 0.000000), r20.xyzx
 260:   mad r20.xyz, r17.xyzx, l(0.072200, 0.072200, 0.072200, 0.000000), r20.xyzx
 261:   dp3 r7.w, r20.xyzx, r20.xyzx
 262:   max r7.w, r7.w, l(0.000000)
 263:   rsq r7.w, r7.w
 264:   mul r20.xyz, r7.wwww, r20.xyzx
 265:   mov r20.y, abs(r20.y)
 266:   mov r20.w, l(1.000000)
 267:   dp4 r16.x, r16.xyzw, r20.xyzw
 268:   dp4 r16.y, r15.xyzw, r20.xyzw
 269:   dp4 r16.z, r17.xyzw, r20.xyzw
 270:   max r15.xyz, r16.xyzx, l(0, 0, 0, 0)
 271:   ge r7.w, r19.y, r19.z
 272:   and r7.w, r7.w, l(1.000000)
 273:   mov r16.xy, r19.zyzz
 274:   mov r16.zw, l(0.000000, 0.000000, -1.000000, 0.666667)
 275:   mad r17.xy, r18.yzyy, r4.wwww, -r16.xyxx
 276:   mov r17.zw, l(0.000000, 0.000000, 1.000000, -1.000000)
 277:   mad r16.xyzw, r7.wwww, r17.xyzw, r16.xyzw
 278:   ge r7.w, r19.x, r16.x
 279:   and r7.w, r7.w, l(1.000000)
 280:   mov r17.xyz, r16.xywx
 281:   mov r17.w, r19.x
 282:   mov r16.xyw, r17.wywx
 283:   add r16.xyzw, -r17.xyzw, r16.xyzw
 284:   mad r16.xyzw, r7.wwww, r16.xyzw, r17.xyzw
 285:   min r7.w, r16.y, r16.w
 286:   add r7.w, -r7.w, r16.x
 287:   add r8.w, -r16.y, r16.w
 288:   mad r9.w, r7.w, l(6.000000), l(0.000100)
 289:   div r8.w, r8.w, r9.w
 290:   add r8.w, r8.w, r16.z
 291:   frc r8.w, abs(r8.w)
 292:   add r9.w, r16.x, l(0.000100)
 293:   div r7.w, r7.w, r9.w
 294:   add r17.xyzw, r8.wwww, l(-0.500000, 1.000000, 0.666667, 0.333333)
 295:   add r8.w, abs(r17.x), l(-0.450000)
 296:   mul_sat r8.w, r8.w, l(-10.000001)
 297:   mad r9.w, r8.w, l(-2.000000), l(3.000000)
 298:   mul r8.w, r8.w, r8.w
 299:   mul r8.w, r8.w, r9.w
 300:   mad r8.w, r8.w, l(-0.350000), l(0.700000)
 301:   mov_sat r16.x, r16.x
 302:   mul r8.w, r8.w, r16.x
 303:   min r7.w, r7.w, r8.w
 304:   add r8.w, -r7.w, l(2.000000)
 305:   div r8.w, l(2.000000), r8.w
 306:   frc r16.xyz, r17.yzwy
 307:   mad r16.xyz, r16.xyzx, l(6.000000, 6.000000, 6.000000, 0.000000), l(-3.000000, -3.000000, -3.000000, 0.000000)
 308:   add_sat r16.xyz, abs(r16.xyzx), l(-1.000000, -1.000000, -1.000000, 0.000000)
 309:   add r16.xyz, r16.xyzx, l(-1.000000, -1.000000, -1.000000, 0.000000)
 310:   mad r16.xyz, r7.wwww, r16.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 311:   mul r16.xyz, r8.wwww, r16.xyzx
 312:   max r7.w, r15.y, r15.x
 313:   max r7.w, r15.z, r7.w
 314:   mul r4.w, r4.w, r7.w
 315:   mov r7.w, l(1.000000)
 316: else
 317:   mov r20.xyz, l(0, 0, 0, 0)
 318:   mov r19.xyz, l(1.000000, 1.000000, 1.000000, 0.000000)
 319:   mov r16.xyz, cb1[112].xyzx
 320:   mov r7.w, l(0)
 321: endif
 322: mad r8.w, r13.x, l(0.003922), r3.w
 323: min r8.w, r8.w, l(1.000000)
 324: add r8.w, r8.w, -cb6[5].x
 325: lt r8.w, l(0.010000), r8.w
 326: if_nz r8.w
 327:   add r8.w, -r6.x, l(1.000000)
 328:   mul r15.xyz, r5.xyzx, r8.wwww
 329:   dp3 r9.w, r15.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 330:   add r9.w, r9.w, l(-0.350000)
 331:   mul_sat r9.w, r9.w, l(-4.000000)
 332:   mad r11.w, r9.w, l(-2.000000), l(3.000000)
 333:   mul r9.w, r9.w, r9.w
 334:   mul r13.y, r9.w, r11.w
 335:   mul r15.xyzw, v8.xyxz, l(1.000000, -1.000000, 1.000000, 1.000000)
 336:   movc r15.xyzw, r3.xxxx, r15.xyzw, v8.xzxy
 337:   mul r17.xyzw, r15.xyzw, cb1[120].zzzz
 338:   movc r18.yz, r3.xxxx, v7.zzyz, v7.yyzy
 339:   mov r18.x, v7.x
 340:   add r21.xyz, abs(r18.xyzx), l(-0.200000, -0.200000, -0.200000, 0.000000)
 341:   mul r22.xyz, r21.xyzx, r21.xyzx
 342:   mul r22.xyz, r21.xyzx, r22.xyzx
 343:   max r22.xyz, r22.xyzx, l(0.000061, 0.000061, 0.000061, 0.000000)
 344:   dp3 r13.z, r22.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 345:   div r22.xyz, r22.xyzx, r13.zzzz
 346:   sample_b(texture2d)(float,float,float,float) r23.xyzw, r17.zyzz, t14.xyzw, s1, cb1[26].x
 347:   sample_b(texture2d)(float,float,float,float) r24.xyzw, r17.zwzz, t14.xyzw, s1, cb1[26].x
 348:   mul r24.xyzw, r22.zzzz, r24.xyzw
 349:   mad r23.xyzw, r23.xyzw, r22.yyyy, r24.xyzw
 350:   sample_b(texture2d)(float,float,float,float) r24.xyzw, r17.ywyy, t14.xyzw, s1, cb1[26].x
 351:   mad r22.xyzw, r24.xyzw, r22.xxxx, r23.xyzw
 352:   add r14.yz, -r22.wwww, l(0.000000, 0.800000, 0.450000, 0.000000)
 353:   mul r23.xyz, r11.yyxy, l(0.200000, 0.000000, 1.000000, 0.000000)
 354:   mad_sat r13.z, r14.x, r8.w, r23.x
 355:   add r13.z, -r14.y, r13.z
 356:   mul_sat r13.z, r13.z, l(3.333333)
 357:   mad r14.y, r13.z, l(-2.000000), l(3.000000)
 358:   mul r13.z, r13.z, r13.z
 359:   mul r13.z, r13.z, r14.y
 360:   mul_sat r2.w, r2.w, r8.w
 361:   add r2.w, -r14.z, r2.w
 362:   mul_sat r2.w, r2.w, l(1.538461)
 363:   mad r8.w, r2.w, l(-2.000000), l(3.000000)
 364:   mul r2.w, r2.w, r2.w
 365:   mul r2.w, r2.w, r8.w
 366:   max r2.w, r2.w, r13.z
 367:   add r8.w, r6.x, l(-0.500000)
 368:   mul_sat r8.w, r8.w, l(4.000000)
 369:   mad r13.z, r8.w, l(-2.000000), l(3.000000)
 370:   mul r8.w, r8.w, r8.w
 371:   mul r8.w, r8.w, r13.z
 372:   add r6.w, -r6.w, l(0.200000)
 373:   mul_sat r6.w, r6.w, l(-5.000000)
 374:   mad r13.z, r6.w, l(-2.000000), l(3.000000)
 375:   mul r6.w, r6.w, r6.w
 376:   mul r6.w, r6.w, r13.z
 377:   mad r13.z, r6.w, r13.y, r8.w
 378:   min r13.z, r13.z, l(1.000000)
 379:   max r14.x, r3.w, r14.x
 380:   mul r14.y, r13.z, r14.x
 381:   ge r13.x, l(2.550000), r13.x
 382:   and r13.x, r13.x, l(1.000000)
 383:   ge r14.z, r3.w, l(0.010000)
 384:   and r14.z, r14.z, l(1.000000)
 385:   mul r13.x, r13.x, r14.z
 386:   eq r13.x, r13.x, l(0)
 387:   add r3.w, -r3.w, l(1.000000)
 388:   movc r18.yw, r13.xxxx, l(0.000000, 3.000000, 0.000000, 4.345600), r3.wwww
 389:   mad r23.xw, -r13.zzzz, r14.xxxx, l(1.000000, 0.000000, 0.000000, 1.010000)
 390:   movc r3.w, r13.x, cb1[20].x, l(1.000000)
 391:   mul r24.xyz, r17.yzwy, l(20.000000, 20.000000, 20.000000, 0.000000)
 392:   mul r25.xyz, r17.yzwy, l(34.345600, 34.345600, 34.345600, 0.000000)
 393:   max r21.xyz, r21.xyzx, l(0, 0, 0, 0)
 394:   mul r21.xyz, r21.xyzx, r21.xyzx
 395:   mul r26.xyz, r21.xyzx, r21.xyzx
 396:   mul r26.xyz, r26.xyzx, r26.xyzx
 397:   mul r21.xyz, r21.xyzx, r26.xyzx
 398:   dp3 r14.z, r21.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 399:   max r14.z, r14.z, l(0.000061)
 400:   div r21.xyz, r21.xyzx, r14.zzzz
 401:   round_ni r26.xyzw, r24.yxyz
 402:   mul r27.xyzw, r26.xyzw, l(123.339996, 456.209991, 123.339996, 456.209991)
 403:   frc r27.xyzw, r27.xyzw
 404:   add r28.xyzw, r27.xyzw, l(34.345001, 34.345001, 34.345001, 34.345001)
 405:   dp2 r14.z, r27.xyxx, r28.xyxx
 406:   add r24.yw, r14.zzzz, r27.xxxy
 407:   mul r14.z, r24.w, r24.y
 408:   add r15.x, r24.w, r24.y
 409:   frc r14.z, r14.z
 410:   frc r15.x, r15.x
 411:   add r29.xyzw, r26.xyzw, l(114.514000, 114.514000, 114.514000, 114.514000)
 412:   mul r29.xyzw, r29.xyzw, l(123.339996, 456.209991, 123.339996, 456.209991)
 413:   frc r29.xyzw, r29.xyzw
 414:   add r30.xyzw, r29.xyzw, l(34.345001, 34.345001, 34.345001, 34.345001)
 415:   dp2 r16.w, r29.xyxx, r30.xyxx
 416:   add r24.yw, r16.wwww, r29.xxxy
 417:   mul r16.w, r24.w, r24.y
 418:   add r19.w, r24.w, r24.y
 419:   frc r27.x, r16.w
 420:   frc r27.y, r19.w
 421:   mad r16.w, r14.z, l(0.400000), l(0.600000)
 422:   mul r19.w, r16.w, l(0.250000)
 423:   mad r26.xyzw, r17.zyzw, l(20.000000, 20.000000, 20.000000, 20.000000), -r26.xyzw
 424:   mad r24.yw, r27.xxxy, l(0.000000, 2.000000, 0.000000, 2.000000), l(0.000000, -1.000000, 0.000000, -1.000000)
 425:   mad r24.yw, r24.yyyw, l(0.000000, 0.250000, 0.000000, 0.250000), r26.xxxy
 426:   add r24.yw, r24.yyyw, l(0.000000, -0.500000, 0.000000, -0.500000)
 427:   mul r26.x, r24.y, l(1.250000)
 428:   lt r20.w, r24.w, l(0)
 429:   movc r20.w, r20.w, l(1.250000), l(0.750000)
 430:   mul r26.y, r20.w, r24.w
 431:   mad r14.z, r3.w, r18.y, r14.z
 432:   frc r20.w, r14.z
 433:   mov_sat r14.z, r14.z
 434:   mad r14.z, r14.z, l(0.630000), l(0.220000)
 435:   movc r14.z, r13.x, r20.w, r14.z
 436:   add r24.yw, r14.zzzz, l(0.000000, -0.200000, 0.000000, -0.850000)
 437:   mul_sat r24.yw, r24.yyyw, l(0.000000, 50.000011, 0.000000, -3.333333)
 438:   mad r28.xy, r24.ywyy, l(-2.000000, -2.000000, 0.000000, 0.000000), l(3.000000, 3.000000, 0.000000, 0.000000)
 439:   mul r24.yw, r24.yyyw, r24.yyyw
 440:   mul r24.yw, r24.yyyw, r28.xxxy
 441:   mul r14.z, r24.w, r24.y
 442:   dp2 r20.w, r26.xyxx, r26.xyxx
 443:   sqrt r20.w, r20.w
 444:   mad r16.w, -r16.w, l(0.250000), r20.w
 445:   div r20.w, l(1.000000, 1.000000, 1.000000, 1.000000), -r19.w
 446:   mul_sat r16.w, r16.w, r20.w
 447:   mad r20.w, r16.w, l(-2.000000), l(3.000000)
 448:   mul r16.w, r16.w, r16.w
 449:   mul r16.w, r16.w, r20.w
 450:   ge r16.w, r16.w, l(0.001000)
 451:   and r16.w, r16.w, l(1.000000)
 452:   mul r14.z, r14.z, r16.w
 453:   add r15.x, r15.x, l(-0.100000)
 454:   ge r15.x, r15.x, r23.x
 455:   and r15.x, r15.x, l(1.000000)
 456:   mul r14.z, r14.z, r15.x
 457:   mul r15.x, r21.y, r14.z
 458:   dp2 r16.w, r27.zwzz, r28.zwzz
 459:   add r24.yw, r16.wwww, r27.zzzw
 460:   mul r16.w, r24.w, r24.y
 461:   add r20.w, r24.w, r24.y
 462:   frc r16.w, r16.w
 463:   frc r20.w, r20.w
 464:   dp2 r21.w, r29.zwzz, r30.zwzz
 465:   add r24.yw, r21.wwww, r29.zzzw
 466:   mul r21.w, r24.w, r24.y
 467:   add r22.w, r24.w, r24.y
 468:   frc r28.x, r21.w
 469:   frc r28.y, r22.w
 470:   mad r21.w, r16.w, l(0.400000), l(0.600000)
 471:   mul r22.w, r21.w, l(0.250000)
 472:   mad r24.yw, r28.xxxy, l(0.000000, 2.000000, 0.000000, 2.000000), l(0.000000, -1.000000, 0.000000, -1.000000)
 473:   mad r24.yw, r24.yyyw, l(0.000000, 0.250000, 0.000000, 0.250000), r26.zzzw
 474:   add r24.yw, r24.yyyw, l(0.000000, -0.500000, 0.000000, -0.500000)
 475:   mul r29.x, r24.y, l(1.250000)
 476:   lt r24.y, r24.w, l(0)
 477:   movc r24.y, r24.y, l(1.250000), l(0.750000)
 478:   mul r29.y, r24.y, r24.w
 479:   mad r16.w, r3.w, r18.y, r16.w
 480:   frc r24.y, r16.w
 481:   mov_sat r16.w, r16.w
 482:   mad r16.w, r16.w, l(0.630000), l(0.220000)
 483:   movc r16.w, r13.x, r24.y, r16.w
 484:   add r24.yw, r16.wwww, l(0.000000, -0.200000, 0.000000, -0.850000)
 485:   mul_sat r24.yw, r24.yyyw, l(0.000000, 50.000011, 0.000000, -3.333333)
 486:   mad r26.zw, r24.yyyw, l(0.000000, 0.000000, -2.000000, -2.000000), l(0.000000, 0.000000, 3.000000, 3.000000)
 487:   mul r24.yw, r24.yyyw, r24.yyyw
 488:   mul r24.yw, r24.yyyw, r26.zzzw
 489:   mul r16.w, r24.w, r24.y
 490:   dp2 r24.y, r29.xyxx, r29.xyxx
 491:   sqrt r24.y, r24.y
 492:   mad r21.w, -r21.w, l(0.250000), r24.y
 493:   div r24.y, l(1.000000, 1.000000, 1.000000, 1.000000), -r22.w
 494:   mul_sat r21.w, r21.w, r24.y
 495:   mad r24.y, r21.w, l(-2.000000), l(3.000000)
 496:   mul r21.w, r21.w, r21.w
 497:   mul r21.w, r21.w, r24.y
 498:   ge r21.w, r21.w, l(0.001000)
 499:   and r21.w, r21.w, l(1.000000)
 500:   mul r16.w, r16.w, r21.w
 501:   add r20.w, r20.w, l(-0.100000)
 502:   ge r20.w, r20.w, r23.x
 503:   and r20.w, r20.w, l(1.000000)
 504:   mul r16.w, r16.w, r20.w
 505:   mul r20.w, r21.z, r16.w
 506:   round_ni r24.xy, r24.xzxx
 507:   mul r24.zw, r24.xxxy, l(0.000000, 0.000000, 123.339996, 456.209991)
 508:   frc r24.zw, r24.zzzw
 509:   add r26.zw, r24.zzzw, l(0.000000, 0.000000, 34.345001, 34.345001)
 510:   dp2 r21.w, r24.zwzz, r26.zwzz
 511:   add r24.zw, r21.wwww, r24.zzzw
 512:   mul r21.w, r24.w, r24.z
 513:   add r24.z, r24.w, r24.z
 514:   frc r21.w, r21.w
 515:   frc r24.z, r24.z
 516:   add r26.zw, r24.xxxy, l(0.000000, 0.000000, 114.514000, 114.514000)
 517:   mul r26.zw, r26.zzzw, l(0.000000, 0.000000, 123.339996, 456.209991)
 518:   frc r26.zw, r26.zzzw
 519:   add r27.yz, r26.zzwz, l(0.000000, 34.345001, 34.345001, 0.000000)
 520:   dp2 r24.w, r26.zwzz, r27.yzyy
 521:   add r26.zw, r24.wwww, r26.zzzw
 522:   mul r24.w, r26.w, r26.z
 523:   add r25.w, r26.w, r26.z
 524:   frc r30.x, r24.w
 525:   frc r30.y, r25.w
 526:   mad r24.w, r21.w, l(0.400000), l(0.600000)
 527:   mul r25.w, r24.w, l(0.250000)
 528:   mad r24.xy, r17.ywyy, l(20.000000, 20.000000, 0.000000, 0.000000), -r24.xyxx
 529:   mad r26.zw, r30.xxxy, l(0.000000, 0.000000, 2.000000, 2.000000), l(0.000000, 0.000000, -1.000000, -1.000000)
 530:   mad r24.xy, r26.zwzz, l(0.250000, 0.250000, 0.000000, 0.000000), r24.xyxx
 531:   add r24.xy, r24.xyxx, l(-0.500000, -0.500000, 0.000000, 0.000000)
 532:   mul r31.x, r24.x, l(1.250000)
 533:   lt r24.x, r24.y, l(0)
 534:   movc r24.x, r24.x, l(1.250000), l(0.750000)
 535:   mul r31.y, r24.x, r24.y
 536:   mad r18.y, r3.w, r18.y, r21.w
 537:   frc r21.w, r18.y
 538:   mov_sat r18.y, r18.y
 539:   mad r18.y, r18.y, l(0.630000), l(0.220000)
 540:   movc r18.y, r13.x, r21.w, r18.y
 541:   add r24.xy, r18.yyyy, l(-0.200000, -0.850000, 0.000000, 0.000000)
 542:   mul_sat r24.xy, r24.xyxx, l(50.000011, -3.333333, 0.000000, 0.000000)
 543:   mad r26.zw, r24.xxxy, l(0.000000, 0.000000, -2.000000, -2.000000), l(0.000000, 0.000000, 3.000000, 3.000000)
 544:   mul r24.xy, r24.xyxx, r24.xyxx
 545:   mul r24.xy, r24.xyxx, r26.zwzz
 546:   mul r18.y, r24.y, r24.x
 547:   dp2 r21.w, r31.xyxx, r31.xyxx
 548:   sqrt r21.w, r21.w
 549:   mad r21.w, -r24.w, l(0.250000), r21.w
 550:   div r24.x, l(1.000000, 1.000000, 1.000000, 1.000000), -r25.w
 551:   mul_sat r21.w, r21.w, r24.x
 552:   mad r24.x, r21.w, l(-2.000000), l(3.000000)
 553:   mul r21.w, r21.w, r21.w
 554:   mul r21.w, r21.w, r24.x
 555:   ge r21.w, r21.w, l(0.001000)
 556:   and r21.w, r21.w, l(1.000000)
 557:   mul r18.y, r18.y, r21.w
 558:   add r21.w, r24.z, l(-0.100000)
 559:   ge r21.w, r21.w, r23.x
 560:   and r21.w, r21.w, l(1.000000)
 561:   mul r18.y, r18.y, r21.w
 562:   mul r21.w, r21.x, r18.y
 563:   div r24.xy, r26.xyxx, r19.wwww
 564:   max r24.xy, r24.xyxx, l(-1.000000, -1.000000, 0.000000, 0.000000)
 565:   min r24.xy, r24.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 566:   mad r24.z, r27.x, l(0.250000), l(0.250000)
 567:   mul r24.xy, r24.zzzz, r24.xyxx
 568:   mul r24.xy, r14.zzzz, r24.xyxx
 569:   div r24.zw, r29.xxxy, r22.wwww
 570:   max r24.zw, r24.zzzw, l(0.000000, 0.000000, -1.000000, -1.000000)
 571:   min r24.zw, r24.zzzw, l(0.000000, 0.000000, 1.000000, 1.000000)
 572:   mad r26.x, r28.x, l(0.250000), l(0.250000)
 573:   mul r24.zw, r24.zzzw, r26.xxxx
 574:   mul r24.zw, r16.wwww, r24.zzzw
 575:   mul r24.zw, r21.zzzz, r24.zzzw
 576:   mad r24.xy, r24.xyxx, r21.yyyy, r24.zwzz
 577:   div r24.zw, r31.xxxy, r25.wwww
 578:   max r24.zw, r24.zzzw, l(0.000000, 0.000000, -1.000000, -1.000000)
 579:   min r24.zw, r24.zzzw, l(0.000000, 0.000000, 1.000000, 1.000000)
 580:   mad r26.x, r30.x, l(0.250000), l(0.250000)
 581:   mul r24.zw, r24.zzzw, r26.xxxx
 582:   mul r24.zw, r18.yyyy, r24.zzzw
 583:   mad r24.xy, r24.zwzz, r21.xxxx, r24.xyxx
 584:   max r15.x, r15.x, r20.w
 585:   max r15.x, r15.x, r21.w
 586:   round_ni r26.xyzw, r25.yxyz
 587:   mul r27.xyzw, r26.xyzw, l(123.339996, 456.209991, 123.339996, 456.209991)
 588:   frc r27.xyzw, r27.xyzw
 589:   add r28.xyzw, r27.xyzw, l(34.345001, 34.345001, 34.345001, 34.345001)
 590:   dp2 r20.w, r27.xyxx, r28.xyxx
 591:   add r24.zw, r20.wwww, r27.xxxy
 592:   mul r20.w, r24.w, r24.z
 593:   add r21.w, r24.w, r24.z
 594:   frc r20.w, r20.w
 595:   frc r21.w, r21.w
 596:   add r29.xyzw, r26.xyzw, l(114.514000, 114.514000, 114.514000, 114.514000)
 597:   mul r29.xyzw, r29.xyzw, l(123.339996, 456.209991, 123.339996, 456.209991)
 598:   frc r29.xyzw, r29.xyzw
 599:   add r30.xyzw, r29.xyzw, l(34.345001, 34.345001, 34.345001, 34.345001)
 600:   dp2 r24.z, r29.xyxx, r30.xyxx
 601:   add r24.zw, r24.zzzz, r29.xxxy
 602:   mul r25.y, r24.w, r24.z
 603:   add r24.z, r24.w, r24.z
 604:   frc r27.x, r25.y
 605:   frc r27.y, r24.z
 606:   mad r24.z, r20.w, l(0.400000), l(0.600000)
 607:   mul r24.w, r24.z, l(0.250000)
 608:   mad r26.xyzw, r17.xyzw, l(34.345600, 34.345600, 34.345600, 34.345600), -r26.xyzw
 609:   mad r28.xy, r27.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
 610:   mad r26.xy, r28.xyxx, l(0.250000, 0.250000, 0.000000, 0.000000), r26.xyxx
 611:   add r26.xy, r26.xyxx, l(-0.500000, -0.500000, 0.000000, 0.000000)
 612:   mul r28.x, r26.x, l(1.250000)
 613:   lt r17.x, r26.y, l(0)
 614:   movc r17.x, r17.x, l(1.250000), l(0.750000)
 615:   mul r28.y, r17.x, r26.y
 616:   mad r17.x, r3.w, r18.w, r20.w
 617:   frc r20.w, r17.x
 618:   mov_sat r17.x, r17.x
 619:   mad r17.x, r17.x, l(0.630000), l(0.220000)
 620:   movc r17.x, r13.x, r20.w, r17.x
 621:   add r26.xy, r17.xxxx, l(-0.200000, -0.850000, 0.000000, 0.000000)
 622:   mul_sat r26.xy, r26.xyxx, l(50.000011, -3.333333, 0.000000, 0.000000)
 623:   mad r29.xy, r26.xyxx, l(-2.000000, -2.000000, 0.000000, 0.000000), l(3.000000, 3.000000, 0.000000, 0.000000)
 624:   mul r26.xy, r26.xyxx, r26.xyxx
 625:   mul r26.xy, r26.xyxx, r29.xyxx
 626:   mul r17.x, r26.y, r26.x
 627:   dp2 r20.w, r28.xyxx, r28.xyxx
 628:   sqrt r20.w, r20.w
 629:   mad r20.w, -r24.z, l(0.250000), r20.w
 630:   div r24.z, l(1.000000, 1.000000, 1.000000, 1.000000), -r24.w
 631:   mul_sat r20.w, r20.w, r24.z
 632:   mad r24.z, r20.w, l(-2.000000), l(3.000000)
 633:   mul r20.w, r20.w, r20.w
 634:   mul r20.w, r20.w, r24.z
 635:   ge r20.w, r20.w, l(0.001000)
 636:   and r20.w, r20.w, l(1.000000)
 637:   mul r17.x, r17.x, r20.w
 638:   add r20.w, r21.w, l(-0.100000)
 639:   ge r20.w, r20.w, r23.x
 640:   and r20.w, r20.w, l(1.000000)
 641:   mul r17.x, r17.x, r20.w
 642:   mul r20.w, r21.y, r17.x
 643:   dp2 r21.w, r27.zwzz, r28.zwzz
 644:   add r26.xy, r21.wwww, r27.zwzz
 645:   mul r21.w, r26.y, r26.x
 646:   add r24.z, r26.y, r26.x
 647:   frc r21.w, r21.w
 648:   frc r24.z, r24.z
 649:   dp2 r25.y, r29.zwzz, r30.zwzz
 650:   add r26.xy, r25.yyyy, r29.zwzz
 651:   mul r25.y, r26.y, r26.x
 652:   add r26.x, r26.y, r26.x
 653:   frc r29.x, r25.y
 654:   frc r29.y, r26.x
 655:   mad r25.y, r21.w, l(0.400000), l(0.600000)
 656:   mul r26.x, r25.y, l(0.250000)
 657:   mad r27.yz, r29.xxyx, l(0.000000, 2.000000, 2.000000, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
 658:   mad r26.yz, r27.yyzy, l(0.000000, 0.250000, 0.250000, 0.000000), r26.zzwz
 659:   add r26.yz, r26.yyzy, l(0.000000, -0.500000, -0.500000, 0.000000)
 660:   mul r30.x, r26.y, l(1.250000)
 661:   lt r26.y, r26.z, l(0)
 662:   movc r26.y, r26.y, l(1.250000), l(0.750000)
 663:   mul r30.y, r26.y, r26.z
 664:   mad r21.w, r3.w, r18.w, r21.w
 665:   frc r26.y, r21.w
 666:   mov_sat r21.w, r21.w
 667:   mad r21.w, r21.w, l(0.630000), l(0.220000)
 668:   movc r21.w, r13.x, r26.y, r21.w
 669:   add r26.yz, r21.wwww, l(0.000000, -0.200000, -0.850000, 0.000000)
 670:   mul_sat r26.yz, r26.yyzy, l(0.000000, 50.000011, -3.333333, 0.000000)
 671:   mad r27.yz, r26.yyzy, l(0.000000, -2.000000, -2.000000, 0.000000), l(0.000000, 3.000000, 3.000000, 0.000000)
 672:   mul r26.yz, r26.yyzy, r26.yyzy
 673:   mul r26.yz, r26.yyzy, r27.yyzy
 674:   mul r21.w, r26.z, r26.y
 675:   dp2 r26.y, r30.xyxx, r30.xyxx
 676:   sqrt r26.y, r26.y
 677:   mad r25.y, -r25.y, l(0.250000), r26.y
 678:   div r26.y, l(1.000000, 1.000000, 1.000000, 1.000000), -r26.x
 679:   mul_sat r25.y, r25.y, r26.y
 680:   mad r26.y, r25.y, l(-2.000000), l(3.000000)
 681:   mul r25.y, r25.y, r25.y
 682:   mul r25.y, r25.y, r26.y
 683:   ge r25.y, r25.y, l(0.001000)
 684:   and r25.y, r25.y, l(1.000000)
 685:   mul r21.w, r21.w, r25.y
 686:   add r24.z, r24.z, l(-0.100000)
 687:   ge r24.z, r24.z, r23.x
 688:   and r24.z, r24.z, l(1.000000)
 689:   mul r21.w, r21.w, r24.z
 690:   mul r24.z, r21.z, r21.w
 691:   round_ni r25.xy, r25.xzxx
 692:   mul r26.yz, r25.xxyx, l(0.000000, 123.339996, 456.209991, 0.000000)
 693:   frc r26.yz, r26.yyzy
 694:   add r27.yz, r26.yyzy, l(0.000000, 34.345001, 34.345001, 0.000000)
 695:   dp2 r25.z, r26.yzyy, r27.yzyy
 696:   add r26.yz, r25.zzzz, r26.yyzy
 697:   mul r25.z, r26.z, r26.y
 698:   add r26.y, r26.z, r26.y
 699:   frc r25.z, r25.z
 700:   add r26.zw, r25.xxxy, l(0.000000, 0.000000, 114.514000, 114.514000)
 701:   mul r26.zw, r26.zzzw, l(0.000000, 0.000000, 123.339996, 456.209991)
 702:   frc r26.yzw, r26.yyzw
 703:   add r27.yz, r26.zzwz, l(0.000000, 34.345001, 34.345001, 0.000000)
 704:   dp2 r27.y, r26.zwzz, r27.yzyy
 705:   add r26.zw, r26.zzzw, r27.yyyy
 706:   mul r27.y, r26.w, r26.z
 707:   add r26.z, r26.w, r26.z
 708:   frc r31.x, r27.y
 709:   frc r31.y, r26.z
 710:   mad r26.z, r25.z, l(0.400000), l(0.600000)
 711:   mul r26.w, r26.z, l(0.250000)
 712:   mad r25.xy, r17.ywyy, l(34.345600, 34.345600, 0.000000, 0.000000), -r25.xyxx
 713:   mad r27.yz, r31.xxyx, l(0.000000, 2.000000, 2.000000, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
 714:   mad r25.xy, r27.yzyy, l(0.250000, 0.250000, 0.000000, 0.000000), r25.xyxx
 715:   add r25.xy, r25.xyxx, l(-0.500000, -0.500000, 0.000000, 0.000000)
 716:   mul r32.x, r25.x, l(1.250000)
 717:   lt r25.x, r25.y, l(0)
 718:   movc r25.x, r25.x, l(1.250000), l(0.750000)
 719:   mul r32.y, r25.x, r25.y
 720:   mad r3.w, r3.w, r18.w, r25.z
 721:   frc r18.w, r3.w
 722:   mov_sat r3.w, r3.w
 723:   mad r3.w, r3.w, l(0.630000), l(0.220000)
 724:   movc r3.w, r13.x, r18.w, r3.w
 725:   add r25.xy, r3.wwww, l(-0.200000, -0.850000, 0.000000, 0.000000)
 726:   mul_sat r25.xy, r25.xyxx, l(50.000011, -3.333333, 0.000000, 0.000000)
 727:   mad r27.yz, r25.xxyx, l(0.000000, -2.000000, -2.000000, 0.000000), l(0.000000, 3.000000, 3.000000, 0.000000)
 728:   mul r25.xy, r25.xyxx, r25.xyxx
 729:   mul r25.xy, r25.xyxx, r27.yzyy
 730:   mul r3.w, r25.y, r25.x
 731:   dp2 r13.x, r32.xyxx, r32.xyxx
 732:   sqrt r13.x, r13.x
 733:   mad r13.x, -r26.z, l(0.250000), r13.x
 734:   div r18.w, l(1.000000, 1.000000, 1.000000, 1.000000), -r26.w
 735:   mul_sat r13.x, r13.x, r18.w
 736:   mad r18.w, r13.x, l(-2.000000), l(3.000000)
 737:   mul r13.x, r13.x, r13.x
 738:   mul r13.x, r13.x, r18.w
 739:   ge r13.x, r13.x, l(0.001000)
 740:   and r13.x, r13.x, l(1.000000)
 741:   mul r3.w, r3.w, r13.x
 742:   add r13.x, r26.y, l(-0.100000)
 743:   ge r13.x, r13.x, r23.x
 744:   and r13.x, r13.x, l(1.000000)
 745:   mul r3.w, r3.w, r13.x
 746:   mul r13.x, r21.x, r3.w
 747:   div r25.xy, r28.xyxx, r24.wwww
 748:   max r25.xy, r25.xyxx, l(-1.000000, -1.000000, 0.000000, 0.000000)
 749:   min r25.xy, r25.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 750:   mad r18.w, r27.x, l(0.250000), l(0.250000)
 751:   mul r25.xy, r18.wwww, r25.xyxx
 752:   mul r25.xy, r17.xxxx, r25.xyxx
 753:   div r26.xy, r30.xyxx, r26.xxxx
 754:   max r26.xy, r26.xyxx, l(-1.000000, -1.000000, 0.000000, 0.000000)
 755:   min r26.xy, r26.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 756:   mad r17.x, r29.x, l(0.250000), l(0.250000)
 757:   mul r26.xy, r17.xxxx, r26.xyxx
 758:   mul r26.xy, r21.wwww, r26.xyxx
 759:   mul r26.xy, r21.zzzz, r26.xyxx
 760:   mad r25.xy, r25.xyxx, r21.yyyy, r26.xyxx
 761:   div r26.xy, r32.xyxx, r26.wwww
 762:   max r26.xy, r26.xyxx, l(-1.000000, -1.000000, 0.000000, 0.000000)
 763:   min r26.xy, r26.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 764:   mad r17.x, r31.x, l(0.250000), l(0.250000)
 765:   mul r26.xy, r17.xxxx, r26.xyxx
 766:   mul r26.xy, r3.wwww, r26.xyxx
 767:   mad r25.xy, r26.xyxx, r21.xxxx, r25.xyxx
 768:   max r3.w, r20.w, r24.z
 769:   max r3.w, r3.w, r13.x
 770:   mul r13.x, r14.z, r19.w
 771:   mul r13.x, r21.y, r13.x
 772:   mul r14.z, r16.w, r22.w
 773:   mul r14.z, r21.z, r14.z
 774:   mul r16.w, r18.y, r25.w
 775:   mul r16.w, r21.x, r16.w
 776:   max r14.z, r14.z, r16.w
 777:   max r13.x, r13.x, r14.z
 778:   ge r13.x, l(0.010000), r13.x
 779:   and r13.x, r13.x, l(1.000000)
 780:   mad r18.yw, r25.xxxy, r13.xxxx, r24.xxxy
 781:   mad r18.yw, r22.xxxy, l(0.000000, 2.000000, 0.000000, 2.000000), r18.yyyw
 782:   add r18.yw, r18.yyyw, l(0.000000, -1.000000, 0.000000, -1.000000)
 783:   mul r14.z, cb1[20].x, cb1[120].z
 784:   mul r21.y, r14.z, l(0.750000)
 785:   dp2 r14.z, r18.xzxx, r18.xzxx
 786:   max r14.z, r14.z, l(0.000000)
 787:   rsq r14.z, r14.z
 788:   mul r24.x, r14.z, v7.x
 789:   mov r24.y, l(0)
 790:   mul r24.z, r14.z, r18.z
 791:   add r22.xyw, abs(r24.xyxz), l(-0.200000, -0.200000, 0.000000, -0.200000)
 792:   mul r24.xyz, r22.xywx, r22.xywx
 793:   mul r22.xyw, r22.xyxw, r24.xyxz
 794:   max r22.xyw, r22.xyxw, l(0.000061, 0.000061, 0.000000, 0.000061)
 795:   dp3 r14.z, r22.xywx, l(1.000000, 1.000000, 1.000000, 0.000000)
 796:   div r18.xz, r22.xxwx, r14.zzzz
 797:   sample_b(texture2d)(float,float,float,float) r22.xyw, r17.zwzz, t15.xywz, s1, cb1[26].x
 798:   sample_b(texture2d)(float,float,float,float) r17.xyz, r17.ywyy, t15.xyzw, s1, cb1[26].x
 799:   mul r17.xyz, r18.xxxx, r17.xyzx
 800:   mad r17.xyz, r22.xywx, r18.zzzz, r17.xyzx
 801:   mad r17.xy, r17.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
 802:   mov r21.x, l(0)
 803:   mad r21.xyzw, r15.zwyw, cb1[120].zzzz, r21.xyxy
 804:   sample_b(texture2d)(float,float,float,float) r14.z, r21.xyxx, t15.xywz, s1, cb1[26].x
 805:   sample_b(texture2d)(float,float,float,float) r15.y, r21.zwzz, t15.xwyz, s1, cb1[26].x
 806:   mul r15.y, r18.x, r15.y
 807:   mad r14.z, r14.z, r18.z, r15.y
 808:   mul r15.yz, r14.zzzz, r17.xxyx
 809:   mad r18.xy, r15.yzyy, r14.yyyy, r18.ywyy
 810:   ge r14.z, r15.x, l(0.010000)
 811:   and r14.z, r14.z, l(1.000000)
 812:   mul r14.z, r14.z, r15.x
 813:   mul r3.w, r3.w, r13.x
 814:   max r3.w, r3.w, r14.z
 815:   ge r13.x, r22.z, r23.w
 816:   and r13.x, r13.x, l(1.000000)
 817:   max r3.w, r3.w, r13.x
 818:   add r13.x, -r17.z, l(1.000000)
 819:   mad r13.x, r13.z, r14.x, -r13.x
 820:   mul_sat r13.x, r13.x, l(9.999998)
 821:   mad r13.z, r13.x, l(-2.000000), l(3.000000)
 822:   mul r13.x, r13.x, r13.x
 823:   mul r13.x, r13.x, r13.z
 824:   mul r13.x, r14.y, r13.x
 825:   max r3.w, r3.w, r13.x
 826:   dp2 r13.x, r18.xyxx, r18.xyxx
 827:   min r13.x, r13.x, l(1.000000)
 828:   add r13.x, -r13.x, l(1.000000)
 829:   sqrt r13.x, r13.x
 830:   max r18.z, r13.x, l(0.000000)
 831:   dp3 r13.x, r18.xyzx, r18.xyzx
 832:   rsq r13.x, r13.x
 833:   mul r14.xyz, r13.xxxx, r18.xyzx
 834:   mad r13.xz, -r11.zzyz, l(1.000000, 0.000000, 0.000000, 0.000000), r23.yyzy
 835:   dp2 r15.x, r13.xzxx, r13.xzxx
 836:   lt r15.y, l(0.000061), r15.x
 837:   rsq r15.x, r15.x
 838:   mul r13.xz, r13.xxzx, r15.xxxx
 839:   movc r17.y, r15.y, r13.x, l(1.000000)
 840:   and r17.x, r13.z, r15.y
 841:   min r13.x, r3.y, l(0.050000)
 842:   add r13.z, -r3.y, r13.x
 843:   mad r13.z, r3.w, r13.z, r3.y
 844:   mad r9.w, -r11.w, r9.w, l(1.000000)
 845:   mul r9.w, r2.w, r9.w
 846:   mad r6.w, -r6.w, r13.y, l(1.000000)
 847:   mul r6.w, r6.w, r9.w
 848:   mad r6.w, r6.w, l(-0.500000), l(1.000000)
 849:   mov r17.z, l(0)
 850:   mul r15.xyz, r11.yzxy, r17.xyzx
 851:   mad r15.xyz, r17.zxyz, r11.zxyz, -r15.xyzx
 852:   mul r15.xyz, r14.yyyy, r15.xyzx
 853:   mad r15.xyz, r17.yzxy, r14.xxxx, r15.xyzx
 854:   mad r14.xyz, r11.xyzx, r14.zzzz, r15.xyzx
 855:   dp3 r9.w, r14.xyzx, r14.xyzx
 856:   rsq r9.w, r9.w
 857:   mad r14.xyz, r14.xyzx, r9.wwww, -r11.xyzx
 858:   mad r14.xyz, r3.wwww, r14.xyzx, r11.xyzx
 859:   dp3 r9.w, r14.xyzx, r14.xyzx
 860:   rsq r9.w, r9.w
 861:   mul r14.xyz, r9.wwww, r14.xyzx
 862:   mul r2.w, r13.y, r2.w
 863:   mad r2.w, -r2.w, l(0.200000), r13.z
 864:   min r9.w, r13.z, l(0.200000)
 865:   max r3.y, r2.w, r9.w
 866:   mul r8.xyz, r6.wwww, r8.xyzx
 867:   dp3 r2.w, r5.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 868:   add r2.w, r2.w, l(-0.700000)
 869:   mul_sat r2.w, r2.w, l(-2.500000)
 870:   mad r9.w, r2.w, l(-2.000000), l(3.000000)
 871:   mul r2.w, r2.w, r2.w
 872:   mul r2.w, r2.w, r9.w
 873:   mad r2.w, r2.w, l(0.500000), l(1.000000)
 874:   mul r8.w, r8.w, r3.w
 875:   mad r15.xyz, r5.xyzx, r2.wwww, -r5.xyzx
 876:   mad r15.xyz, r8.wwww, r15.xyzx, r5.xyzx
 877:   mul r5.xyz, r6.wwww, r15.xyzx
 878:   mov r2.w, r3.w
 879: else
 880:   mov r14.xyz, r11.xyzx
 881:   mov r2.w, l(0)
 882:   mov r13.x, l(0.010000)
 883:   mov r3.w, l(0)
 884: endif
 885: mad r6.w, r13.w, l(0.003922), -cb6[5].x
 886: lt r6.w, l(0.010000), r6.w
 887: if_nz r6.w
 888:   mul r15.xyz, v8.xzyx, l(1.000000, 1.000000, -1.000000, 0.000000)
 889:   movc r15.xyz, r3.xxxx, r15.xyzx, v8.xyzx
 890:   mul r15.xzw, r15.xxyz, cb1[120].zzzz
 891:   movc r17.yz, r3.xxxx, v7.zzyz, v7.yyzy
 892:   mov r17.x, v7.x
 893:   add r17.xzw, abs(r17.xxyz), l(-0.200000, 0.000000, -0.200000, -0.200000)
 894:   mul r18.xyz, r17.xzwx, r17.xzwx
 895:   mul r17.xzw, r17.xxzw, r18.xxyz
 896:   max r17.xzw, r17.xxzw, l(0.000061, 0.000000, 0.000061, 0.000061)
 897:   dp3 r3.x, r17.xzwx, l(1.000000, 1.000000, 1.000000, 0.000000)
 898:   div r17.xzw, r17.xxzw, r3.xxxx
 899:   sample_b(texture2d)(float,float,float,float) r18.xyzw, r15.xwxx, t16.xyzw, s1, cb1[26].x
 900:   sample_b(texture2d)(float,float,float,float) r21.xyzw, r15.xzxx, t16.xyzw, s1, cb1[26].x
 901:   mul r21.xyzw, r17.wwww, r21.xyzw
 902:   mad r18.xyzw, r18.xyzw, r17.zzzz, r21.xyzw
 903:   sample_b(texture2d)(float,float,float,float) r21.xyzw, r15.wzww, t16.xyzw, s1, cb1[26].x
 904:   mad r18.xyzw, r21.xyzw, r17.xxxx, r18.xyzw
 905:   add r3.x, r15.y, l(-0.350000)
 906:   mul_sat r3.x, r3.x, l(-6.666667)
 907:   mad r6.w, r3.x, l(-2.000000), l(3.000000)
 908:   mul r3.x, r3.x, r3.x
 909:   mul r3.x, r3.x, r6.w
 910:   mul r6.w, r13.w, l(0.011765)
 911:   min r6.w, r6.w, l(1.000000)
 912:   mad r3.x, r3.x, r6.w, r14.w
 913:   min r3.x, r3.x, l(1.000000)
 914:   add r6.w, -r3.x, l(2.000000)
 915:   mad r6.w, -r3.x, r6.w, l(2.000000)
 916:   mad r8.w, r17.y, l(0.650000), r18.z
 917:   add r8.w, r8.w, l(0.350000)
 918:   add r6.w, -r6.w, r8.w
 919:   mul_sat r6.w, r6.w, l(2.857144)
 920:   mad r8.w, r6.w, l(-2.000000), l(3.000000)
 921:   mul r6.w, r6.w, r6.w
 922:   mul r6.w, r6.w, r8.w
 923:   mul r8.w, r6.z, r6.z
 924:   and r9.w, v10.x, l(1.000000)
 925:   mul r8.w, r8.w, r9.w
 926:   mul r6.w, r6.w, r8.w
 927:   add r8.w, -r6.x, l(1.000000)
 928:   mul r13.yzw, r5.xxyz, r8.wwww
 929:   dp3 r8.w, r13.yzwy, l(0.212673, 0.715152, 0.072175, 0.000000)
 930:   add r8.w, r8.w, l(-0.350000)
 931:   mul_sat r8.w, r8.w, l(-4.000000)
 932:   mad r9.w, r8.w, l(-2.000000), l(3.000000)
 933:   mul r8.w, r8.w, r8.w
 934:   mad r8.w, -r9.w, r8.w, l(1.000000)
 935:   mul r3.x, r3.x, r8.w
 936:   mul r3.x, r18.w, r3.x
 937:   mad r8.w, r17.y, l(0.250000), l(0.750000)
 938:   mul r3.x, r3.x, r8.w
 939:   mad r3.x, r3.x, l(-0.500000), l(1.000000)
 940:   mad r13.yz, r18.xxyx, l(0.000000, 2.000000, 2.000000, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
 941:   dp2 r8.w, r13.yzyy, r13.yzyy
 942:   min r8.w, r8.w, l(1.000000)
 943:   add r8.w, -r8.w, l(1.000000)
 944:   sqrt r8.w, r8.w
 945:   max r15.z, r8.w, l(0.000000)
 946:   add r15.xy, r13.yzyy, r13.yzyy
 947:   add r13.yzw, r15.xxyz, l(0.000000, -0.000000, -0.000000, -1.000000)
 948:   mad r13.yzw, r6.wwww, r13.yyzw, l(0.000000, 0.000000, 0.000000, 1.000000)
 949:   dp3 r8.w, r13.yzwy, r13.yzwy
 950:   max r8.w, r8.w, l(0.000061)
 951:   rsq r8.w, r8.w
 952:   mul r13.yzw, r8.wwww, r13.yyzw
 953:   mad r8.w, -r11.y, r11.y, l(1.000000)
 954:   ge r8.w, r8.w, l(0.010000)
 955:   and r15.y, r8.w, l(1.000000)
 956:   mad r3.z, r10.y, r3.z, -r11.z
 957:   mad r3.z, r15.y, r3.z, r11.z
 958:   movc r15.z, r8.w, l(0), l(1.000000)
 959:   mov r15.x, l(0)
 960:   mad r15.xyz, -r11.xyzx, r3.zzzz, r15.xyzx
 961:   mad r3.z, -r3.z, r3.z, l(1.000000)
 962:   max r3.z, r3.z, l(0.000100)
 963:   rsq r3.z, r3.z
 964:   mul r15.xyz, r3.zzzz, r15.xyzx
 965:   mul r17.xyz, r11.yzxy, r15.zxyz
 966:   mad r17.xyz, r15.yzxy, r11.zxyz, -r17.xyzx
 967:   mul r15.xyz, r13.zzzz, r15.xyzx
 968:   mad r15.xyz, r17.xyzx, r13.yyyy, r15.xyzx
 969:   mad r13.yzw, r11.xxyz, r13.wwww, r15.xxyz
 970:   mul r3.z, r6.w, l(4.000000)
 971:   min r3.z, r3.z, l(1.000000)
 972:   add r8.w, -r3.y, l(0.900000)
 973:   mad r3.y, r3.z, r8.w, r3.y
 974:   mul r15.xyz, r3.xxxx, r8.xyzx
 975:   mad r17.xyz, -r8.xyzx, r3.xxxx, l(0.308000, 0.308000, 0.308000, 0.000000)
 976:   mad r8.xyz, r6.wwww, r17.xyzx, r15.xyzx
 977:   mul r15.xyz, r3.xxxx, r5.xyzx
 978:   mad r17.xyz, -r5.xyzx, r3.xxxx, l(0.880000, 0.880000, 0.880000, 0.000000)
 979:   mad r5.xyz, r6.wwww, r17.xyzx, r15.xyzx
 980:   mad r6.x, r6.w, -r6.x, r6.x
 981: else
 982:   mov r13.yzw, r11.xxyz
 983: endif
 984: mad r3.x, -r6.x, l(0.960000), l(0.960000)
 985: mul r15.xyz, r3.xxxx, r5.xyzx
 986: mul r3.z, r6.y, l(0.040000)
 987: mad r17.xyz, -r6.yyyy, l(0.040000, 0.040000, 0.040000, 0.000000), r5.xyzx
 988: mad r17.xyz, r6.xxxx, r17.xyzx, r3.zzzz
 989: mul r8.xyz, r3.xxxx, r8.xyzx
 990: mul r3.z, r3.y, r3.y
 991: max r3.z, r3.z, l(0.007813)
 992: mul r6.y, r3.z, r3.z
 993: max r6.w, v5.z, l(0.000000)
 994: div r18.xy, v5.xyxx, r6.wwww
 995: max r6.w, v6.z, l(0.000000)
 996: div r18.zw, v6.xxxy, r6.wwww
 997: add r18.xy, -r18.zwzz, r18.xyxx
 998: mul r21.xy, r18.xyxx, l(0.500000, -0.500000, 0.000000, 0.000000)
 999: sqrt r21.xy, abs(r21.xyxx)
1000: sqrt r21.xy, r21.xyxx
1001: mov r18.z, -r18.y
1002: lt r18.yw, l(0, 0, 0, 0), r18.xxxz
1003: lt r18.xz, r18.xxzx, l(0, 0, 0, 0)
1004: iadd r18.xy, -r18.ywyy, r18.xzxx
1005: itof r18.xy, r18.xyxx
1006: mul r18.xy, r18.xyxx, r21.xyxx
1007: mad o1.xy, r18.xyxx, l(0.500000, 0.500000, 0.000000, 0.000000), l(0.500000, 0.500000, 0.000000, 0.000000)
1008: lt r3.w, l(0.100000), r3.w
1009: movc o1.w, r3.w, l(0.700000), l(0.400000)
1010: add r18.xyz, cb1[121].xyzx, cb3[0].xyzx
1011: mad r18.xyz, cb1[111].wwww, r18.xyzx, -cb3[0].xyzx
1012: mov r18.w, l(0.000061)
1013: dp3 r3.w, r18.xzwx, r18.xzwx
1014: rsq r3.w, r3.w
1015: mul r21.xyz, r3.wwww, r18.xwzx
1016: add r22.xyzw, cb1[115].xyzw, -cb3[3].xyzw
1017: mad r22.xyzw, cb1[122].yyyw, r22.xyzw, cb3[3].xyzw
1018: mul r23.xyz, r22.wwww, r22.xyzx
1019: mov r12.z, l(0)
1020: ld_indexable(texture2d)(float,float,float,float) r24.xy, r12.xyzz, t4.xyzw
1021: add r3.w, r24.x, l(-1.000000)
1022: mad r3.w, cb5[34].x, r3.w, l(1.000000)
1023: add r6.w, -r3.w, l(1.000000)
1024: mad r3.w, cb1[111].z, r6.w, r3.w
1025: dp3 r6.w, r13.yzwy, r18.xyzx
1026: mul r24.xzw, r8.xxyz, cb1[110].zzzz
1027: mul r25.xyz, r24.xzwx, l(0.650000, 0.650000, 0.650000, 0.000000)
1028: dp3 r8.w, r15.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1029: dp2 r9.w, cb0[6].xzxx, cb0[6].xzxx
1030: rsq r9.w, r9.w
1031: mul r26.xy, r9.wwww, cb0[6].xzxx
1032: dp2 r9.w, r21.xzxx, r26.xyxx
1033: mov_sat r9.w, -r9.w
1034: add r26.xy, l(1.000000, 1.000000, 0.000000, 0.000000), -cb1[122].xyxx
1035: mad r10.y, r6.w, l(0.500000), l(-1.000000)
1036: mad r10.y, -r6.w, r10.y, -r6.w
1037: add r11.w, l(0.750000), -abs(cb0[6].y)
1038: add_sat r11.w, r11.w, r11.w
1039: mad r12.z, r11.w, l(-2.000000), l(3.000000)
1040: mul r11.w, r11.w, r11.w
1041: mul r11.w, r11.w, r12.z
1042: mul r11.w, r9.w, r11.w
1043: mul r11.w, r26.x, r11.w
1044: add r10.y, r10.y, l(0.500000)
1045: mad r6.w, r11.w, r10.y, r6.w
1046: mad r6.w, cb1[121].w, cb1[122].x, r6.w
1047: max r6.w, r6.w, l(-1.000000)
1048: min r6.w, r6.w, l(1.000000)
1049: mad r27.x, r6.w, l(0.500000), l(0.500000)
1050: mov r27.yw, l(0.000000, 0.500000, 0.000000, 0.500000)
1051: sample_l(texture2d)(float,float,float,float) r28.xyzw, r27.xyxx, t11.xyzw, s0, l(0)
1052: max r6.w, r28.y, r28.x
1053: max r6.w, r28.z, r6.w
1054: min r10.y, r28.y, r28.x
1055: min r10.y, r28.z, r10.y
1056: add r6.w, r6.w, -r10.y
1057: dp3 r10.y, r13.yzwy, cb0[6].xyzx
1058: mad r27.z, r10.y, l(0.500000), l(0.500000)
1059: sample_l(texture2d)(float,float,float,float) r10.y, r27.zwzz, t11.xwyz, s0, l(0)
1060: mul r11.w, r6.z, r24.y
1061: min r12.z, r6.z, r24.y
1062: min r14.w, r28.w, r12.z
1063: mul r15.w, r10.y, r11.w
1064: dp3 r11.x, r11.xyzx, cb1[116].xyzx
1065: add_sat r11.x, r11.x, cb1[117].x
1066: mad r11.x, r11.x, cb1[117].y, cb1[117].z
1067: mul r11.y, r14.w, cb1[111].y
1068: add r27.xyz, -r16.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
1069: mad r27.xyz, r11.yyyy, r27.xyzx, r16.xyzx
1070: mul r11.xyz, r11.xxxx, r27.xyzx
1071: mad r16.w, r4.w, l(0.350000), l(0.650000)
1072: min r16.w, r16.w, l(1.500000)
1073: max r27.xyz, r4.wwww, l(1.250000, 0.000000, 0.500000, 0.000000)
1074: min r27.xyz, r27.xyzx, l(1.750000, 1.500000, 1.500000, 0.000000)
1075: add r4.w, -r16.w, r27.x
1076: mad r4.w, cb1[111].x, r4.w, r16.w
1077: mul r29.xyz, r4.wwww, r11.xyzx
1078: mul r29.xyz, r29.xyzx, cb1[110].wwww
1079: dp3 r4.w, r23.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1080: mad r23.xyz, r22.xyzx, r22.wwww, -r4.wwww
1081: mad r23.xyz, r14.wwww, r23.xyzx, r4.wwww
1082: mul r11.xyz, r11.xyzx, r27.yyyy
1083: mad r26.yzw, r22.xxyz, cb1[122].yyyy, r26.yyyy
1084: mad r11.xyz, r11.xyzx, r26.yzwy, r23.xyzx
1085: mad r11.xyz, r11.xyzx, cb1[110].yyyy, -r29.xyzx
1086: mad r11.xyz, r3.wwww, r11.xyzx, r29.xyzx
1087: dp3 r4.w, r25.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1088: mad r23.xyz, r24.xzwx, l(0.650000, 0.650000, 0.650000, 0.000000), -r4.wwww
1089: mad r23.xyz, r23.xyzx, l(1.200000, 1.200000, 1.200000, 0.000000), r4.wwww
1090: mad_sat r4.w, r10.y, r11.w, r28.w
1091: mad r25.xyz, r8.xyzx, cb1[110].zzzz, -r23.xyzx
1092: mad r23.xyz, r4.wwww, r25.xyzx, r23.xyzx
1093: mad r25.xyz, r5.xyzx, r3.xxxx, -r23.xyzx
1094: mad r23.xyz, r14.wwww, r25.xyzx, r23.xyzx
1095: add r4.w, -r6.w, l(1.000000)
1096: mad r25.xyz, r28.xyzx, r6.wwww, r4.wwww
1097: mul r25.xyz, r23.xyzx, r25.xyzx
1098: mad r26.yzw, r5.xxyz, r3.xxxx, -r8.wwww
1099: mad r26.yzw, r26.yyzw, l(0.000000, 1.200000, 1.200000, 1.200000), r8.wwww
1100: mad r26.yzw, -r8.xxyz, cb1[110].zzzz, r26.yyzw
1101: mad r24.xzw, r15.wwww, r26.yyzw, r24.xxzw
1102: dp3 r4.w, r23.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1103: dp3 r6.w, r25.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1104: max r6.w, r6.w, l(0.001000)
1105: div r6.w, l(1.000000, 1.000000, 1.000000, 1.000000), r6.w
1106: mul r4.w, r4.w, r6.w
1107: max r4.w, r4.w, l(0)
1108: min r4.w, r4.w, l(1.500000)
1109: mad r23.xyz, r25.xyzx, r4.wwww, -r24.xzwx
1110: mad r23.xyz, r3.wwww, r23.xyzx, r24.xzwx
1111: mad r4.w, -r10.y, r11.w, r14.w
1112: mad r4.w, r3.w, r4.w, r15.w
1113: add r6.w, l(1.000000), -cb1[110].z
1114: mad r6.w, r4.w, r6.w, cb1[110].z
1115: add r10.y, r18.y, l(-0.500000)
1116: mad r25.y, r3.w, r10.y, l(0.500000)
1117: dp3_sat r28.x, r14.xyzx, r2.xyzx
1118: mov r25.xz, cb0[6].xxzx
1119: dp3 r10.y, r25.xyzx, r25.xyzx
1120: max r10.y, r10.y, l(0.000000)
1121: rsq r10.y, r10.y
1122: mul r24.xzw, r10.yyyy, r25.xxyz
1123: add r24.xzw, r24.xxzw, r24.xxzw
1124: mad r18.xyz, r18.xyzx, r3.wwww, r24.xzwx
1125: add r10.y, r3.w, l(2.000000)
1126: mad r18.xyz, r2.xyzx, r10.yyyy, r18.xyzx
1127: dp3 r10.y, r18.xyzx, r18.xyzx
1128: rsq r10.y, r10.y
1129: mul r18.xyz, r10.yyyy, r18.xyzx
1130: dp3 r10.y, r14.xyzx, r18.xyzx
1131: mad r11.w, r10.y, r6.y, -r10.y
1132: mad r10.y, r11.w, r10.y, l(1.000000)
1133: mul r10.y, r10.y, r10.y
1134: ne r11.w, r6.y, r10.y
1135: div r6.y, r6.y, r10.y
1136: movc r6.y, r11.w, r6.y, l(1.000000)
1137: mul r18.x, r28.x, r28.x
1138: mad r10.y, r3.z, r3.z, l(0.000100)
1139: div r10.y, l(1.000000, 1.000000, 1.000000, 1.000000), r10.y
1140: div r10.y, r6.y, r10.y
1141: mad r11.w, r28.x, r28.x, -r10.y
1142: mad r25.x, cb6[1].x, r11.w, r10.y
1143: add r10.y, -r6.x, l(1.000000)
1144: mul r25.y, r3.y, r10.y
1145: sample_l(texture2d)(float,float,float,float) r24.xzw, r25.xyxx, t12.xwyz, s0, l(0)
1146: mul r25.xyz, r17.xyzx, r24.xzwx
1147: mad r24.xzw, r17.xxyz, r24.xxzw, -r17.xxyz
1148: mad r17.xyz, cb6[1].xxxx, r24.xzwx, r17.xyzx
1149: add r10.y, l(1.000000), -cb6[1].z
1150: mad r10.y, r5.w, cb6[1].z, r10.y
1151: mul r24.xzw, r11.xxyz, r23.xxyz
1152: mad r11.w, r28.x, l(2.000000), r3.z
1153: add r11.w, r11.w, l(0.000100)
1154: div r11.w, l(0.500000), r11.w
1155: mad r6.y, r6.y, r11.w, l(-0.000061)
1156: max r6.y, r6.y, l(0)
1157: min r6.y, r6.y, l(20.000000)
1158: mul r26.yzw, r6.yyyy, r25.xxyz
1159: mad r4.w, r4.w, l(0.500000), l(0.500000)
1160: mul r4.w, r6.w, r4.w
1161: mul r11.xyz, r4.wwww, r11.xyzx
1162: mul r11.xyz, r11.xyzx, r26.yzwy
1163: mul r11.xyz, r11.xyzx, cb1[123].wwww
1164: mad r11.xyz, r24.xzwx, r10.yyyy, r11.xyzx
1165: dp3 r4.w, r11.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1166: add r6.y, r4.w, l(-0.500000)
1167: max r6.y, r6.y, l(0)
1168: min r6.y, r6.y, l(0.500000)
1169: mul r29.z, cb0[0].x, cb1[119].x
1170: mul r29.x, cb0[1].x, cb1[119].x
1171: mul r29.y, cb0[2].x, cb1[119].x
1172: mul r30.z, cb0[0].y, cb1[119].y
1173: mul r30.x, cb0[1].y, cb1[119].y
1174: mul r30.y, cb0[2].y, cb1[119].y
1175: add r24.xzw, r29.xxyz, r30.xxyz
1176: mov r29.xz, cb1[119].yyxy
1177: mov r29.y, l(0)
1178: add r24.xzw, r24.xxzw, -r29.xxyz
1179: mad r24.xzw, cb1[125].wwww, r24.xxzw, r29.xxyz
1180: mul r26.yzw, r24.xxzw, cb0[6].zzxy
1181: mad r24.xzw, cb0[6].yyzx, r24.zzwx, -r26.yyzw
1182: dp3 r11.w, r24.xzwx, r24.xzwx
1183: rsq r11.w, r11.w
1184: mul r24.xzw, r11.wwww, r24.xxzw
1185: dp3 r11.w, r2.xyzx, r13.yzwy
1186: add r26.yz, -abs(r11.wwww), l(0.000000, 1.000000, 0.400000, 0.000000)
1187: dp3 r14.w, r21.xyzx, r13.yzwy
1188: add r15.w, -r3.w, l(1.000000)
1189: add r13.x, -r3.y, r13.x
1190: mad r2.w, r2.w, r13.x, r3.y
1191: mul r21.y, r2.w, r2.w
1192: mul r18.z, r28.x, r18.x
1193: mul r13.x, r21.y, r21.y
1194: mul r21.z, r21.y, r13.x
1195: mov r28.yzw, l(0.000000, 0.036546, 9.063200, 0.990440)
1196: dp2 r27.x, l(3.327070, 1.000000, 0.000000, 0.000000), r28.xyxx
1197: dp2 r27.y, l(-9.047560, 1.000000, 0.000000, 0.000000), r28.xzxx
1198: mov r21.x, l(1.000000)
1199: dp2 r13.x, r27.xyxx, r21.xyxx
1200: mov r18.yw, l(0.000000, 9.044010, 0.000000, 1.000000)
1201: dp3 r29.x, l(3.596850, -1.367720, 1.000000, 0.000000), r18.xzwx
1202: dp3 r29.y, l(-16.317400, 1.000000, 9.229490, 0.000000), r18.xyzx
1203: mov r30.x, l(5.565890)
1204: mov r30.yz, r18.xxzx
1205: dp3 r29.z, l(1.000000, 19.788601, -20.212299, 0.000000), r30.xyzx
1206: dp3 r16.w, r29.xyzx, r21.xyzx
1207: div r13.x, r13.x, r16.w
1208: dp2 r27.x, l(-1.285140, 1.000000, 0.000000, 0.000000), r28.xwxx
1209: mov r18.x, l(1.296780)
1210: mov r18.y, r28.x
1211: dp2 r27.y, l(1.000000, -0.755907, 0.000000, 0.000000), r18.xyxx
1212: dp2 r16.w, r27.xyxx, r21.xyxx
1213: dp3 r29.x, l(2.923380, 59.418800, 1.000000, 0.000000), r18.yzwy
1214: mov r18.xw, l(20.322500, 0.000000, 0.000000, 121.563004)
1215: dp3 r29.y, l(1.000000, -27.030199, 222.591995, 0.000000), r18.xyzx
1216: dp3 r29.z, l(626.130005, 316.627014, 1.000000, 0.000000), r18.yzwy
1217: dp3 r17.w, r29.xyzx, r21.xyzx
1218: div r16.w, r16.w, r17.w
1219: mad r18.xyz, r17.xyzx, r13.xxxx, r16.wwww
1220: add r13.x, r13.x, r16.w
1221: dp3 r16.w, -r2.xyzx, r14.xyzx
1222: add r16.w, r16.w, r16.w
1223: mad r21.xyz, r14.xyzx, -r16.wwww, -r2.xyzx
1224: dp2 r29.x, r21.zxzz, cb1[126].xyxx
1225: mul r16.w, r21.x, cb1[126].x
1226: mad r29.z, r21.z, cb1[126].y, -r16.w
1227: mad r6.y, r6.y, r6.y, l(1.000000)
1228: add r11.xyz, -r4.wwww, r11.xyzx
1229: mad r11.xyz, r6.yyyy, r11.xyzx, r4.wwww
1230: mad r21.xz, cb1[119].wwww, l(-0.600000, 0.000000, -0.400000, 0.000000), l(0.800000, 0.000000, 0.900000, 0.000000)
1231: add r4.w, -r21.x, r21.z
1232: add r6.y, -r21.x, r26.y
1233: div r4.w, l(1.000000, 1.000000, 1.000000, 1.000000), r4.w
1234: mul_sat r4.w, r4.w, r6.y
1235: mad r6.y, r4.w, l(-2.000000), l(3.000000)
1236: mul r4.w, r4.w, r4.w
1237: mul r4.w, r4.w, r6.y
1238: mul r21.xzw, r4.wwww, cb1[118].xxyz
1239: mul r21.xzw, r21.xxzw, cb1[118].wwww
1240: dp3 r4.w, r4.xyzx, r24.xzwx
1241: add_sat r4.w, r4.w, l(1.000000)
1242: min r4.w, r6.z, r4.w
1243: min r4.w, r24.y, r4.w
1244: mul r21.xzw, r4.wwww, r21.xxzw
1245: mad r27.xyw, r5.xyxz, r3.xxxx, l(-0.250000, -0.250000, 0.000000, -0.250000)
1246: mad r27.xyw, cb1[119].zzzz, r27.xyxw, l(0.250000, 0.250000, 0.000000, 0.250000)
1247: dp3_sat r4.w, r24.xzwx, r13.yzwy
1248: mul r24.xyz, r4.wwww, r27.xywx
1249: max r4.w, r19.y, r19.x
1250: max r4.w, r19.z, r4.w
1251: mul r4.w, r4.w, l(0.500000)
1252: max r4.w, r4.w, l(1.000000)
1253: div r4.w, l(1.000000, 1.000000, 1.000000, 1.000000), r4.w
1254: mul r19.xyz, r4.wwww, r19.xyzx
1255: mad r22.xyz, r22.xyzx, r22.wwww, -r19.xyzx
1256: mad r19.xyz, r3.wwww, r22.xyzx, r19.xyzx
1257: dp3 r4.w, r20.xyzx, r13.yzwy
1258: mul r6.y, r7.w, r4.w
1259: mad r6.z, r14.w, l(0.500000), l(-1.000000)
1260: mad r6.z, -r14.w, r6.z, l(0.500000)
1261: mad r4.w, -r4.w, r7.w, r6.z
1262: mad_sat r4.w, r3.w, r4.w, r6.y
1263: mul r19.xyz, r4.wwww, r19.xyzx
1264: mad r4.w, r9.w, r3.w, r15.w
1265: mul r4.w, r26.x, r4.w
1266: mul r19.xyz, r4.wwww, r19.xyzx
1267: mul_sat r4.w, r26.z, l(5.000000)
1268: mad r6.y, r4.w, l(-2.000000), l(3.000000)
1269: mul r4.w, r4.w, r4.w
1270: mul r4.w, r4.w, r6.y
1271: mul r19.xyz, r4.wwww, r19.xyzx
1272: mul r19.xyz, r12.zzzz, r19.xyzx
1273: add r4.w, r8.w, l(-0.100000)
1274: mul_sat r4.w, r4.w, l(-16.666666)
1275: mad r6.y, r4.w, l(-2.000000), l(3.000000)
1276: mul r4.w, r4.w, r4.w
1277: mul r4.w, r4.w, r6.y
1278: mad r3.w, r4.w, r3.w, r15.w
1279: mul r19.xyz, r3.wwww, r19.xyzx
1280: max r20.xyz, r15.xyzx, l(0.150000, 0.150000, 0.150000, 0.000000)
1281: mul r19.xyz, r19.xyzx, r20.xyzx
1282: mad r19.xyz, r21.xzwx, r24.xyzx, r19.xyzx
1283: add r11.xyz, r11.xyzx, r19.xyzx
1284: utof r6.yz, r12.xxyx
1285: mul r19.xy, r6.yzyy, l(0.031250, 0.031250, 0.000000, 0.000000)
1286: round_ni r19.xy, r19.xyxx
1287: mad r3.w, r19.y, cb4[2].y, r19.x
1288: mul r3.w, r3.w, l(8.000000)
1289: ftoi r3.w, r3.w
1290: mad r4.w, -cb1[3].y, cb4[3].w, v0.w
1291: round_ni r4.w, r4.w
1292: add r7.w, l(-1.000000), cb4[2].w
1293: max r8.w, r4.w, l(0)
1294: min r7.w, r7.w, r8.w
1295: mul r8.w, r7.w, l(8.000000)
1296: ftoi r8.w, r8.w
1297: mul r9.xyz, r9.xyzx, cb6[7].xyzx
1298: mul r9.xyz, r9.xyzx, cb6[1].wwww
1299: mad r9.xyz, r9.xyzx, r10.yyyy, r11.xyzx
1300: max r2.w, r2.w, l(0.001000)
1301: log r2.w, r2.w
1302: mad r2.w, r2.w, l(1.200000), l(5.000000)
1303: mov r29.y, r21.y
1304: sample_l(texturecube)(float,float,float,float) r11.xyz, r29.xyzx, t21.xyzw, s0, r2.w
1305: add r2.w, -r13.x, l(1.000000)
1306: div r2.w, r2.w, r13.x
1307: mul r17.xyz, r2.wwww, r17.xyzx
1308: mad r17.xyz, r17.xyzx, r18.xyzx, r18.xyzx
1309: mul r11.xyz, r11.xyzx, r17.xyzx
1310: mul r2.w, r27.z, cb1[110].w
1311: mul r2.w, r6.w, r2.w
1312: mul r11.xyz, r2.wwww, r11.xyzx
1313: mad r9.xyz, r11.xyzx, r16.xyzx, r9.xyzx
1314: ge r2.w, r7.w, r4.w
1315: iadd r3.w, r3.w, cb4[0].z
1316: iadd r4.w, r8.w, cb4[0].w
1317: mad r6.w, r15.w, l(-0.250000), l(0.750000)
1318: mad r5.xyz, r5.xyzx, r3.xxxx, l(-0.500000, -0.500000, -0.500000, 0.000000)
1319: add r3.x, -r3.z, l(0.010000)
1320: ge r6.x, r6.x, l(0.500000)
1321: and r6.x, r6.x, l(1.000000)
1322: mov r16.w, l(1.000000)
1323: mov r11.xyz, r9.xyzx
1324: mov r7.w, l(0)
1325: loop
1326:   ilt r8.w, l(7), r7.w
1327:   breakc_nz r8.w
1328:   iadd r8.w, r3.w, r7.w
1329:   ld_structured_indexable(structured_buffer, stride=4)(mixed,mixed,mixed,mixed) r8.w, r8.w, l(0), t0.xxxx
1330:   iadd r9.w, r4.w, r7.w
1331:   ld_structured_indexable(structured_buffer, stride=4)(mixed,mixed,mixed,mixed) r9.w, r9.w, l(0), t0.xxxx
1332:   and r8.w, r8.w, r9.w
1333:   and r8.w, r2.w, r8.w
1334:   ishl r9.w, r7.w, l(5)
1335:   mov r17.xyz, r11.xyzx
1336:   mov r12.z, r8.w
1337:   loop
1338:     breakc_z r12.z
1339:     firstbit_lo r13.x, r12.z
1340:     ishl r14.w, l(1), r13.x
1341:     xor r14.w, r12.z, r14.w
1342:     iadd r13.x, r9.w, r13.x
1343:     bfi r18.xyzw, l(29, 29, 29, 29), l(3, 3, 3, 3), r13.xxxx, l(1, 5, 6, 7)
1344:     ftou r15.w, cb3[r18.y + 6].w
1345:     and r17.w, r15.w, l(1)
1346:     ieq r17.w, r17.w, l(1)
1347:     if_nz r17.w
1348:       add r16.xyz, r7.xyzx, -cb3[r18.x + 6].xyzx
1349:       and r19.xyz, l(0x0000ffff, 0x0000ffff, 0x0000ffff, 0), cb3[r18.y + 6].xzyx
1350:       and r20.xyz, l(0x0000ffff, 0x0000ffff, 0x0000ffff, 0), cb3[r18.z + 6].yxzy
1351:       ushr r21.xyz, cb3[r18.y + 6].xzyx, l(16, 16, 16, 0)
1352:       ushr r22.xyz, cb3[r18.z + 6].yxzy, l(16, 16, 16, 0)
1353:       f16tof32 r19.xyz, r19.xyzx
1354:       f16tof32 r20.xyz, r20.xyzx
1355:       f16tof32 r21.xyz, r21.xyzx
1356:       f16tof32 r22.xyw, r22.yxyz
1357:       mov r24.xz, r19.xxzx
1358:       mov r24.yw, r21.xxxz
1359:       dp4 r17.w, r16.xyzw, r24.xyzw
1360:       mov r21.x, r19.y
1361:       mov r21.z, r20.y
1362:       mov r21.w, r22.x
1363:       dp4 r18.y, r16.xyzw, r21.xyzw
1364:       mov r22.xz, r20.xxzx
1365:       dp4 r16.x, r16.xyzw, r22.xyzw
1366:       max r16.y, abs(r17.w), abs(r18.y)
1367:       max r16.x, abs(r16.x), r16.y
1368:       mad r16.y, cb3[r18.w + 6].x, l(0.500000), l(0.500000)
1369:       add r16.x, -r16.y, r16.x
1370:       mad r16.y, -cb3[r18.w + 6].x, l(0.500000), l(0.500000)
1371:       div_sat r16.x, r16.x, r16.y
1372:       add r16.x, -r16.x, l(1.000000)
1373:       mul r16.x, r16.x, r16.x
1374:     else
1375:       mov r16.x, l(1.000000)
1376:     endif
1377:     lt r16.y, r16.x, l(0.001000)
1378:     if_nz r16.y
1379:       mov r12.z, r14.w
1380:       continue
1381:     endif
1382:     ishl r16.y, r13.x, l(3)
1383:     ftou r16.z, cb3[r16.y + 6].w
1384:     uge r17.w, r16.z, l(4)
1385:     if_nz r17.w
1386:       mov r19.xyz, r17.xyzx
1387:     endif
1388:     if_z r17.w
1389:       lt r17.w, cb3[r16.y + 6].w, l(1.500000)
1390:       if_nz r17.w
1391:         bfi r17.w, l(29), l(3), r13.x, l(3)
1392:         ieq r18.y, l(16), cb3[r17.w + 6].w
1393:         add r19.w, cb1[122].z, cb3[r17.w + 6].z
1394:         lt r19.w, r19.w, l(0.500000)
1395:         or r18.y, r18.y, r19.w
1396:         if_z r18.y
1397:           bfi r20.xy, l(29, 29, 0, 0), l(3, 3, 0, 0), r13.xxxx, l(2, 4, 0, 0)
1398:           and r13.x, r16.z, l(1)
1399:           ieq r16.z, r13.x, l(0)
1400:           not r18.y, r16.z
1401:           lt r19.w, l(0), cb3[r20.x + 6].z
1402:           and r18.y, r18.y, r19.w
1403:           ieq r19.w, l(4), cb3[r17.w + 6].w
1404:           movc r20.z, r13.x, l(0), l(1.000000)
1405:           mad r20.w, cb3[r20.x + 6].y, l(0.500000), l(0.500000)
1406:           add r21.z, r20.w, -abs(cb3[r20.x + 6].x)
1407:           add r21.x, -r21.z, cb3[r20.x + 6].y
1408:           add r20.w, -abs(r21.z), l(1.000000)
1409:           add r20.w, -abs(r21.x), r20.w
1410:           max r20.w, r20.w, l(0.000488)
1411:           ge r21.w, cb3[r20.x + 6].x, l(0)
1412:           movc r21.y, r21.w, r20.w, -r20.w
1413:           dp3 r20.w, r21.xyzx, r21.xyzx
1414:           rsq r20.w, r20.w
1415:           mul r21.xyz, r20.wwww, r21.xyzx
1416:           add r20.w, cb3[r20.y + 6].y, cb3[r20.y + 6].y
1417:           max r20.w, r20.w, l(0.100000)
1418:           and r21.w, r19.w, l(1.000000)
1419:           add r20.w, r20.w, -cb3[r18.z + 6].w
1420:           mad r18.z, r21.w, r20.w, cb3[r18.z + 6].w
1421:           add r22.xyz, -r7.xyzx, cb3[r18.x + 6].xyzx
1422:           dp3 r20.w, r22.yzxy, -r21.xyzx
1423:           lt r21.w, l(0.500000), cb3[r20.y + 6].z
1424:           and r21.w, r19.w, r21.w
1425:           and r21.w, r21.w, l(1.000000)
1426:           mul r21.w, r20.z, r21.w
1427:           mad r24.xyz, -r21.zxyz, r20.wwww, -r22.xyzx
1428:           mad r22.xyz, r21.wwww, r24.xyzx, r22.xyzx
1429:           dp3 r20.w, r22.xyzx, r22.xyzx
1430:           rsq r21.w, r20.w
1431:           mul r24.xyz, r21.wwww, r22.xyzx
1432:           if_nz r18.y
1433:             mul r26.xzw, r21.zzxy, cb3[r20.x + 6].zzzz
1434:             mad r27.xyz, -r26.xzwx, l(0.500000, 0.500000, 0.500000, 0.000000), r22.xyzx
1435:             mad r26.xzw, r26.xxzw, l(0.500000, 0.000000, 0.500000, 0.500000), r22.xxyz
1436:             dp3 r21.w, r27.xyzx, r27.xyzx
1437:             sqrt r21.w, r21.w
1438:             dp3 r22.w, r26.xzwx, r26.xzwx
1439:             sqrt r22.w, r22.w
1440:             mul r28.yzw, r21.xxyz, r24.xxyz
1441:             mad r28.yzw, r21.zzxy, r24.yyzx, -r28.yyzw
1442:             mul r29.xyz, r21.xyzx, r28.yzwy
1443:             mad r28.yzw, r28.wwyz, r21.yyzx, -r29.xxyz
1444:             dp3 r23.w, r28.yzwy, r28.yzwy
1445:             rsq r23.w, r23.w
1446:             mul r24.xyz, r23.wwww, r28.yzwy
1447:             dp3 r23.w, r27.xyzx, r26.xzwx
1448:             mad r23.w, r21.w, r22.w, r23.w
1449:             mad r23.w, r23.w, l(0.500000), l(1.000000)
1450:             div r23.w, l(1.000000, 1.000000, 1.000000, 1.000000), r23.w
1451:             dp3 r24.w, r24.xyzx, r27.xyzx
1452:             div r21.w, r24.w, r21.w
1453:             dp3 r24.w, r24.xyzx, r26.xzwx
1454:             div r22.w, r24.w, r22.w
1455:             add r21.w, r21.w, r22.w
1456:             mul_sat r21.w, r21.w, l(0.500000)
1457:             mul r21.w, r21.w, r23.w
1458:           else
1459:             mov r21.w, l(1.000000)
1460:           endif
1461:           lt r22.w, r18.z, l(0)
1462:           if_nz r22.w
1463:             mul r22.w, cb3[r18.x + 6].w, cb3[r18.x + 6].w
1464:             mul r22.w, r20.w, r22.w
1465:             mad r22.w, -r22.w, r22.w, l(1.000000)
1466:             max r22.w, r22.w, l(0)
1467:             add r20.w, r20.w, l(1.000000)
1468:             div r20.w, l(1.000000, 1.000000, 1.000000, 1.000000), r20.w
1469:             and r23.w, r18.y, l(1.000000)
1470:             add r24.w, -r20.w, r21.w
1471:             mad r20.w, r23.w, r24.w, r20.w
1472:             mul r22.w, r22.w, r22.w
1473:             mul r20.w, r20.w, r22.w
1474:           else
1475:             mul r26.xzw, r22.xxyz, cb3[r18.x + 6].wwww
1476:             dp3 r22.w, r26.xzwx, r26.xzwx
1477:             min r22.w, r22.w, l(1.000000)
1478:             add r22.w, -r22.w, l(1.000000)
1479:             log r22.w, r22.w
1480:             mul r18.z, r18.z, r22.w
1481:             exp r18.z, r18.z
1482:             mul r20.w, r18.z, r21.w
1483:           endif
1484:           dp3 r18.z, r24.yzxy, -r21.xyzx
1485:           add r18.z, r18.z, -cb3[r20.x + 6].z
1486:           mul_sat r18.z, r18.z, cb3[r20.x + 6].w
1487:           mad r18.z, r18.z, r18.z, l(-1.000000)
1488:           mad r18.z, r20.z, r18.z, l(1.000000)
1489:           mul r18.z, r18.z, r20.w
1490:           ftoi r20.z, cb3[r18.w + 6].w
1491:           not r18.y, r18.y
1492:           ige r20.w, r20.z, l(0)
1493:           and r18.y, r18.y, r20.w
1494:           if_nz r18.y
1495:             if_z r13.x
1496:               ishl r13.x, r20.z, l(2)
1497:               mul r21.xyz, r7.yyyy, cb7[r13.x + 33].xywx
1498:               mad r21.xyz, cb7[r13.x + 32].xywx, r7.xxxx, r21.xyzx
1499:               mad r21.xyz, cb7[r13.x + 34].xywx, r7.zzzz, r21.xyzx
1500:               add r21.xyz, r21.xyzx, cb7[r13.x + 35].xywx
1501:               div_sat r21.xy, r21.xyxx, r21.zzzz
1502:               mad r21.xy, r21.xyxx, cb7[r20.z + 0].zwzz, cb7[r20.z + 0].xyxx
1503:             else
1504:               ishl r13.x, r20.z, l(2)
1505:               dp3 r27.x, -r22.xyzx, cb7[r13.x + 32].xyzx
1506:               dp3 r27.y, -r22.xyzx, cb7[r13.x + 33].xyzx
1507:               dp3 r27.z, -r22.xyzx, cb7[r13.x + 34].xyzx
1508:               lt r13.x, abs(r27.x), abs(r27.y)
1509:               and r13.x, r13.x, l(1)
1510:               dp2 r18.y, abs(r27.xyxx), icb[r13.x + 0].xyxx
1511:               lt r18.y, r18.y, abs(r27.z)
1512:               movc r13.x, r18.y, l(2), r13.x
1513:               dp3 r18.y, r27.xyzx, icb[r13.x + 0].xyzx
1514:               lt r18.y, r18.y, l(0)
1515:               bfi r13.x, l(31), l(1), r13.x, r18.y
1516:               ushr r18.y, r13.x, l(1)
1517:               dp3 r18.y, r27.xyzx, icb[r18.y + 0].xyzx
1518:               div r20.w, l(0.000244), cb7[r20.z + 0].w
1519:               add r20.w, -r20.w, l(0.500000)
1520:               utof r21.z, r13.x
1521:               ult r21.w, r13.x, l(2)
1522:               and r21.w, r21.w, l(2)
1523:               dp2 r21.w, r27.xzxx, icb[r21.w + 0].xzxx
1524:               mul r21.w, r21.w, icb[r13.x + 4].z
1525:               div r21.w, r21.w, abs(r18.y)
1526:               mad r21.z, r21.w, r20.w, r21.z
1527:               add r21.z, r21.z, l(0.500000)
1528:               mul_sat r22.x, r21.z, l(0.166667)
1529:               iadd r21.z, l(-1), icb[r13.x + 4].y
1530:               dp2 r21.z, r27.yzyy, icb[r21.z + 0].xyxx
1531:               mul r13.x, r21.z, icb[r13.x + 4].w
1532:               div r13.x, r13.x, abs(r18.y)
1533:               mad_sat r22.y, -r13.x, r20.w, l(0.500000)
1534:               mad r21.xy, r22.xyxx, cb7[r20.z + 0].zwzz, cb7[r20.z + 0].xyxx
1535:             endif
1536:             sample_l(texture2d)(float,float,float,float) r13.x, r21.xyxx, t22.xyzw, s0, l(0)
1537:             mul r18.z, r13.x, r18.z
1538:           endif
1539:           mul r13.x, r16.x, r18.z
1540:           lt r16.x, l(0.000100), r13.x
1541:           if_nz r16.x
1542:             if_nz r19.w
1543:               add r16.x, l(1.000000), -cb3[r20.y + 6].w
1544:               dp3 r18.y, r10.xzwx, r24.xyzx
1545:               add_sat r18.y, r18.y, l(0.500000)
1546:               mad r18.z, r18.y, l(-2.000000), l(3.000000)
1547:               mul r18.y, r18.y, r18.y
1548:               mul r18.y, r18.y, r18.z
1549:               mad r16.x, r18.y, cb3[r20.y + 6].w, r16.x
1550:               mul r16.x, r16.x, cb3[r20.y + 6].x
1551:               mul r16.x, r13.x, r16.x
1552:               add r21.xyz, -r17.xyzx, cb3[r16.y + 6].xyzx
1553:               mad r21.xyz, r16.xxxx, r21.xyzx, r17.xyzx
1554:             endif
1555:             if_z r19.w
1556:               dp3 r16.x, r13.yzwy, r24.xyzx
1557:               mov_sat r18.y, r16.x
1558:               if_nz cb3[r17.w + 6].w
1559:                 and r15.w, r15.w, l(2)
1560:                 ine r15.w, r15.w, l(0)
1561:                 or r15.w, r15.w, r16.z
1562:                 if_nz r15.w
1563:                   ftoi r16.z, cb3[r17.w + 6].x
1564:                 else
1565:                   add r22.xyz, r7.xyzx, -cb3[r18.x + 6].xyzx
1566:                   lt r26.xzw, abs(r22.yyzz), abs(r22.xxxy)
1567:                   and r18.z, r26.z, r26.x
1568:                   lt r22.xyz, l(0, 0, 0, 0), r22.xyzx
1569:                   and r20.z, l(1023), cb3[r20.x + 6].w
1570:                   ubfe r20.xw, l(10, 0, 0, 10), l(10, 0, 0, 20), cb3[r20.x + 6].wwww
1571:                   movc r20.x, r22.x, r20.z, r20.x
1572:                   and r20.z, l(1023), cb3[r17.w + 6].x
1573:                   movc r20.z, r22.y, r20.w, r20.z
1574:                   ubfe r22.xy, l(10, 10, 0, 0), l(10, 20, 0, 0), cb3[r17.w + 6].xxxx
1575:                   movc r20.w, r22.z, r22.x, r22.y
1576:                   movc r20.z, r26.w, r20.z, r20.w
1577:                   movc r18.z, r18.z, r20.x, r20.z
1578:                   ieq r20.x, r18.z, l(1023)
1579:                   movc r16.z, r20.x, l(-1), r18.z
1580:                 endif
1581:                 ige r18.z, r16.z, l(0)
1582:                 if_nz r18.z
1583:                   add r20.xzw, r7.xxyz, -cb3[r18.x + 6].xxyz
1584:                   imad r16.z, r16.z, l(96), cb5[65].x
1585:                   iadd r22.xyzw, r16.zzzz, l(64, 16, 32, 48)
1586:                   and r22.xyzw, r22.xyzw, l(-4, -4, -4, -4)
1587:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r18.xz, r22.x, t2.xxyx
1588:                   and r21.w, r16.z, l(-4)
1589:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r27.xyzw, r21.w, t2.xyzw
1590:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r29.xyzw, r22.y, t2.xyzw
1591:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r30.xyzw, r22.z, t2.xyzw
1592:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r31.xyzw, r22.w, t2.xyzw
1593:                   dp3 r21.w, r20.xzwx, r20.xzwx
1594:                   max r21.w, r21.w, l(0.000000)
1595:                   rsq r21.w, r21.w
1596:                   mul r20.xzw, r20.xxzw, r21.wwww
1597:                   mad r20.xzw, -r20.xxzw, r18.xxxx, r7.xxyz
1598:                   mul r18.x, r18.z, l(5.000000)
1599:                   mad r20.xzw, r10.xxzw, r18.xxxx, r20.xxzw
1600:                   mul r29.xyzw, r20.zzzz, r29.xyzw
1601:                   mad r27.xyzw, r27.xyzw, r20.xxxx, r29.xyzw
1602:                   mad r27.xyzw, r30.xyzw, r20.wwww, r27.xyzw
1603:                   add r27.xyzw, r31.xyzw, r27.xyzw
1604:                   div r20.xzw, r27.xxyz, r27.wwww
1605:                   iadd r16.z, r16.z, l(80)
1606:                   and r16.z, r16.z, l(-4)
1607:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r29.xyzw, r16.z, t2.xyzw
1608:                   ge r22.yzw, l(0, 0, 0, 0), r20.xxzw
1609:                   ge r26.xzw, r20.xxzw, l(1.000000, 0.000000, 1.000000, 1.000000)
1610:                   add r18.xz, -r29.xxyx, r29.zzwz
1611:                   mad r18.xz, r20.xxzx, r18.xxzx, r29.xxyx
1612:                   mad r27.xy, r18.xzxx, cb5[64].zwzz, l(0.500000, 0.500000, 0.000000, 0.000000)
1613:                   round_ni r27.xy, r27.xyxx
1614:                   mad r18.xz, r18.xxzx, cb5[64].zzwz, -r27.xxyx
1615:                   add r29.xyzw, r18.xxzz, l(0.500000, 1.000000, 0.500000, 1.000000)
1616:                   mul r30.xyzw, r29.xxzz, r29.xxzz
1617:                   add r28.yz, -r18.xxzx, l(0.000000, 1.000000, 1.000000, 0.000000)
1618:                   min r29.xz, r18.xxzx, l(0, 0, 0, 0)
1619:                   max r31.xy, r18.xzxx, l(0, 0, 0, 0)
1620:                   mul r32.xy, r28.yzyy, l(0.160000, 0.160000, 0.000000, 0.000000)
1621:                   mad r31.xy, -r31.xyxx, r31.xyxx, r29.ywyy
1622:                   add r31.xy, r31.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
1623:                   mul r31.xy, r31.xyxx, l(0.160000, 0.160000, 0.000000, 0.000000)
1624:                   mul r30.xz, r30.xxzx, l(0.080000, 0.000000, 0.080000, 0.000000)
1625:                   mad r18.xz, r30.yywy, l(0.500000, 0.000000, 0.500000, 0.000000), -r18.xxzx
1626:                   mul r33.xy, r18.xzxx, l(0.160000, 0.160000, 0.000000, 0.000000)
1627:                   mad r18.xz, -r29.xxzx, r29.xxzx, r28.yyzy
1628:                   add r18.xz, r18.xxzx, l(1.000000, 0.000000, 1.000000, 0.000000)
1629:                   mul r34.xy, r18.xzxx, l(0.160000, 0.160000, 0.000000, 0.000000)
1630:                   mul r18.xz, r29.yywy, l(0.160000, 0.000000, 0.160000, 0.000000)
1631:                   mov r33.z, r34.x
1632:                   mov r33.w, r18.x
1633:                   mov r32.z, r31.x
1634:                   mov r32.w, r30.x
1635:                   add r29.xyzw, r32.zwxz, r33.zwxz
1636:                   mov r34.z, r33.y
1637:                   mov r34.w, r18.z
1638:                   mov r31.z, r32.y
1639:                   mov r31.w, r30.z
1640:                   add r28.yzw, r31.zzyw, r34.zzyw
1641:                   div r30.xyz, r32.xzwx, r29.zwyz
1642:                   add r30.xyz, r30.xyzx, l(-2.500000, -0.500000, 1.500000, 0.000000)
1643:                   mul r30.xyz, r30.xyzx, cb5[64].xxxx
1644:                   div r31.xyz, r31.zywz, r28.yzwy
1645:                   add r31.xyz, r31.xyzx, l(-2.500000, -0.500000, 1.500000, 0.000000)
1646:                   mul r31.xyw, r31.xyxz, cb5[64].yyyy
1647:                   mul r32.xyzw, r28.yyyz, r29.zwyz
1648:                   mov r30.w, r31.x
1649:                   mad r33.xyzw, r27.xyxy, cb5[64].xyxy, r30.xwyw
1650:                   sample_c_lz(texture2d)(float,float,float,float) r16.z, r33.xyxx, t3.xxxx, s2, r20.w
1651:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r33.zwzz, t3.xxxx, s2, r20.w
1652:                   mul r18.x, r18.x, r32.y
1653:                   mad r16.z, r32.x, r16.z, r18.x
1654:                   mad r18.xz, r27.xxyx, cb5[64].xxyx, r30.zzwz
1655:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r18.xzxx, t3.xxxx, s2, r20.w
1656:                   mad r16.z, r32.z, r18.x, r16.z
1657:                   mov r31.z, r30.x
1658:                   mad r33.xyzw, r27.xyxy, cb5[64].xyxy, r31.zyzw
1659:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r33.xyxx, t3.xxxx, s2, r20.w
1660:                   mad r16.z, r32.w, r18.x, r16.z
1661:                   mul r32.xyzw, r28.zzww, r29.xyzw
1662:                   mov r31.xz, r30.yyzy
1663:                   mad r30.xyzw, r27.xyxy, cb5[64].xyxy, r31.xyzy
1664:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r30.xyxx, t3.xxxx, s2, r20.w
1665:                   mad r16.z, r32.x, r18.x, r16.z
1666:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r30.zwzz, t3.xxxx, s2, r20.w
1667:                   mad r16.z, r32.y, r18.x, r16.z
1668:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r33.zwzz, t3.xxxx, s2, r20.w
1669:                   mad r16.z, r32.z, r18.x, r16.z
1670:                   iadd r18.x, r22.x, l(8)
1671:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r18.xz, r18.x, t2.xxyx
1672:                   add r28.yz, -r20.xxzx, l(0.000000, 1.000000, 1.000000, 0.000000)
1673:                   min r20.xz, r20.xxzx, r28.yyzy
1674:                   or r22.xyz, r22.yzwy, r26.xzwx
1675:                   or r21.w, r22.y, r22.x
1676:                   or r21.w, r22.z, r21.w
1677:                   and r22.x, r20.w, l(0x7fffffff)
1678:                   ult r22.x, l(0x7f800000), r22.x
1679:                   or r21.w, r21.w, r22.x
1680:                   mad r22.xyzw, r27.xyxy, cb5[64].xyxy, r31.xwzw
1681:                   sample_c_lz(texture2d)(float,float,float,float) r22.x, r22.xyxx, t3.xxxx, s2, r20.w
1682:                   mad r16.z, r32.w, r22.x, r16.z
1683:                   mul r22.x, r28.w, r29.y
1684:                   sample_c_lz(texture2d)(float,float,float,float) r20.w, r22.zwzz, t3.xxxx, s2, r20.w
1685:                   mad r16.z, r22.x, r20.w, r16.z
1686:                   add r18.x, -r27.w, r18.x
1687:                   mul r18.x, r18.x, l(0.250000)
1688:                   min r20.x, r20.z, r20.x
1689:                   min r18.x, r18.x, r20.x
1690:                   mul_sat r18.x, r18.x, l(20.000000)
1691:                   mad r20.x, r18.x, l(-2.000000), l(3.000000)
1692:                   mul r18.x, r18.x, r18.x
1693:                   mul r18.x, r18.x, r20.x
1694:                   min r18.x, r18.x, r18.z
1695:                   movc r15.w, r15.w, r18.x, r18.z
1696:                   add r16.z, r16.z, l(-1.000000)
1697:                   movc r16.z, r21.w, l(0), r16.z
1698:                   mad r15.w, r15.w, r16.z, l(1.000000)
1699:                 else
1700:                   dp3 r16.z, r4.xyzx, r24.xyzx
1701:                   add_sat r15.w, r16.z, l(1.000000)
1702:                 endif
1703:               else
1704:                 mov r15.w, l(1.000000)
1705:               endif
1706:               if_z cb3[r17.w + 6].w
1707:                 mul r20.xzw, r13.xxxx, cb3[r16.y + 6].xxyz
1708:                 add r16.z, l(1.000000), -cb3[r20.y + 6].y
1709:                 max r18.x, r20.z, r20.x
1710:                 max r18.x, r20.w, r18.x
1711:                 mul r18.x, r6.w, r18.x
1712:                 max r18.x, r18.x, l(1.000000)
1713:                 div r18.x, l(1.000000, 1.000000, 1.000000, 1.000000), r18.x
1714:                 mad r16.z, r18.x, cb3[r20.y + 6].y, r16.z
1715:                 mul r20.xzw, r16.zzzz, cb3[r16.y + 6].xxyz
1716:                 mul r16.z, l(0.250000), cb3[r20.y + 6].x
1717:                 add_sat r18.x, r16.x, l(0.500000)
1718:                 mad r18.z, -cb3[r20.y + 6].x, l(0.250000), l(1.000000)
1719:                 mad r16.z, r18.x, r18.z, r16.z
1720:                 mul r20.xzw, r16.zzzz, r20.xxzw
1721:                 mov r22.xyz, r23.xyzx
1722:                 mov r26.xzw, r23.xxyz
1723:                 mov r16.z, l(1.000000)
1724:                 mov r18.x, l(0)
1725:               else
1726:                 ieq r18.z, l(3), cb3[r17.w + 6].w
1727:                 if_nz r18.z
1728:                   mad r27.xy, cb3[r20.y + 6].xxxx, l(-0.600000, -0.400000, 0.000000, 0.000000), l(0.800000, 0.900000, 0.000000, 0.000000)
1729:                   add r18.z, -r27.x, r27.y
1730:                   add r21.w, r26.y, -r27.x
1731:                   div r18.z, l(1.000000, 1.000000, 1.000000, 1.000000), r18.z
1732:                   mul_sat r18.z, r18.z, r21.w
1733:                   mad r21.w, r18.z, l(-2.000000), l(3.000000)
1734:                   mul r18.z, r18.z, r18.z
1735:                   mul r18.z, r18.z, r21.w
1736:                   mul r18.z, r15.w, r18.z
1737:                   mul r13.x, r13.x, r18.z
1738:                   mul r27.xyz, r24.zxyz, cb0[6].xyzx
1739:                   mad r27.xyz, cb0[6].zxyz, r24.xyzx, -r27.xyzx
1740:                   mul r28.yzw, r27.xxyz, cb0[6].zzxy
1741:                   mad r27.xyz, cb0[6].yzxy, r27.yzxy, -r28.yzwy
1742:                   dp3 r18.z, r27.xyzx, r27.xyzx
1743:                   rsq r18.z, r18.z
1744:                   mul r27.xyz, r18.zzzz, r27.xyzx
1745:                   dp3_sat r18.y, r13.yzwy, -r27.xyzx
1746:                   mad r22.xyz, cb3[r20.y + 6].yyyy, r5.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000)
1747:                   mov r26.xzw, l(0, 0, 0, 0)
1748:                   mov r16.z, l(1.000000)
1749:                   mov r18.x, l(0)
1750:                 else
1751:                   ieq r18.z, l(1), cb3[r17.w + 6].w
1752:                   if_nz r18.z
1753:                     add r16.x, r16.x, cb3[r20.y + 6].x
1754:                     max_sat r16.x, r16.x, l(-1.000000)
1755:                     mul r18.y, r15.w, r16.x
1756:                     mul r26.xzw, r8.xxyz, cb3[r20.y + 6].yyyy
1757:                     mov r16.z, l(1.000000)
1758:                     mov r18.x, l(0)
1759:                   else
1760:                     ieq r15.w, l(2), cb3[r17.w + 6].w
1761:                     if_nz r15.w
1762:                       add r16.x, l(0.050000), cb3[r20.y + 6].x
1763:                       add r16.x, r3.y, -r16.x
1764:                       mul_sat r16.x, r16.x, l(-10.000000)
1765:                       mad r21.w, r16.x, l(-2.000000), l(3.000000)
1766:                       mul r16.x, r16.x, r16.x
1767:                       mul r16.x, r16.x, r21.w
1768:                       add r21.w, l(1.000000), -cb3[r20.y + 6].z
1769:                       mad r21.w, r6.x, cb3[r20.y + 6].z, r21.w
1770:                       mul r16.z, r16.x, r21.w
1771:                     else
1772:                       mov r16.z, l(1.000000)
1773:                     endif
1774:                     and r18.x, r15.w, cb3[r20.y + 6].y
1775:                     mov r26.xzw, l(0, 0, 0, 0)
1776:                   endif
1777:                   and r22.xyz, r15.xyzx, r18.zzzz
1778:                 endif
1779:                 mov r20.xzw, cb3[r16.y + 6].xxyz
1780:               endif
1781:               ine r15.w, l(3), cb3[r17.w + 6].w
1782:               if_nz r15.w
1783:                 mad r15.w, r18.x, r3.x, r3.z
1784:                 mad r24.xyz, r1.xyzx, r1.wwww, r24.xyzx
1785:                 dp3 r16.x, r24.xyzx, r24.xyzx
1786:                 rsq r16.x, r16.x
1787:                 mul r24.xyz, r16.xxxx, r24.xyzx
1788:                 dp3 r16.x, r14.xyzx, r24.xyzx
1789:                 mul r16.y, r15.w, r15.w
1790:                 mad r17.w, r16.x, r16.y, -r16.x
1791:                 mad r16.x, r17.w, r16.x, l(1.000000)
1792:                 mul r16.x, r16.x, r16.x
1793:                 ne r17.w, r16.x, r16.y
1794:                 div r16.x, r16.y, r16.x
1795:                 movc r16.x, r17.w, r16.x, l(1.000000)
1796:                 mad r15.w, r28.x, l(2.000000), r15.w
1797:                 add r15.w, r15.w, l(0.000100)
1798:                 div r15.w, l(0.500000), r15.w
1799:                 mad r15.w, r16.x, r15.w, l(-0.000061)
1800:                 max r15.w, r15.w, l(0)
1801:                 min r15.w, r15.w, l(20.000000)
1802:                 mul r24.xyz, r15.wwww, r25.xyzx
1803:                 mul r16.xyz, r16.zzzz, r24.xyzx
1804:                 mul r16.xyz, r16.xyzx, cb3[r18.w + 6].zzzz
1805:               else
1806:                 mov r16.xyz, l(0, 0, 0, 0)
1807:               endif
1808:               mul r18.xzw, r13.xxxx, r20.xxzw
1809:               add r20.xyz, r22.xyzx, -r26.xzwx
1810:               mad r20.xyz, r18.yyyy, r20.xyzx, r26.xzwx
1811:               mul r20.xyz, r18.xzwx, r20.xyzx
1812:               mul r16.xyz, r16.xyzx, r18.xzwx
1813:               mul r16.xyz, r18.yyyy, r16.xyzx
1814:               mad r16.xyz, r20.xyzx, r10.yyyy, r16.xyzx
1815:               add r17.xyz, r16.xyzx, r17.xyzx
1816:             endif
1817:           else
1818:             mov r19.w, l(0)
1819:           endif
1820:           movc r17.xyz, r19.wwww, r21.xyzx, r17.xyzx
1821:         endif
1822:       endif
1823:     else
1824:       mov r17.xyz, r19.xyzx
1825:     endif
1826:     mov r12.z, r14.w
1827:   endloop
1828:   mov r11.xyz, r17.xyzx
1829:   iadd r7.w, r7.w, l(1)
1830: endloop
1831: lt r1.x, l(0.500000), cb6[3].x
1832: if_nz r1.x
1833:   dp3 r1.x, r11.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1834:   add r3.xyz, -r1.xxxx, r11.xyzx
1835:   mad r1.xyz, cb6[3].zzzz, r3.xyzx, r1.xxxx
1836:   add r1.xyz, r1.xyzx, l(-0.500000, -0.500000, -0.500000, 0.000000)
1837:   mad r1.xyz, cb6[3].wwww, r1.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000)
1838:   mul r3.xyz, r1.xyzx, cb6[3].yyyy
1839:   mad r1.xyz, -r1.xyzx, cb6[3].yyyy, cb6[8].xyzx
1840:   mad r1.xyz, cb6[8].wwww, r1.xyzx, r3.xyzx
1841:   add r2.w, l(1.000000), -cb6[4].x
1842:   mov_sat r11.w, r11.w
1843:   add r3.x, -r11.w, l(1.000000)
1844:   add r3.y, -r2.w, l(1.000000)
1845:   add r2.w, -r2.w, r3.x
1846:   div r3.x, l(1.000000, 1.000000, 1.000000, 1.000000), r3.y
1847:   mul_sat r2.w, r2.w, r3.x
1848:   mad r3.x, r2.w, l(-2.000000), l(3.000000)
1849:   mul r2.w, r2.w, r2.w
1850:   mul r2.w, r2.w, r3.x
1851:   mul r3.xyz, r2.wwww, cb6[9].xyzx
1852:   mad r11.xyz, r3.xyzx, cb6[4].yyyy, r1.xyzx
1853: endif
1854: mul r1.xyz, r11.xyzx, cb1[27].yyyy
1855: eq r2.w, l(1.000000), cb6[2].x
1856: movc o0.w, r2.w, r5.w, l(1.000000)
1857: lt r2.w, cb1[122].w, l(0.500000)
1858: if_nz r2.w
1859:   mul r2.w, r0.w, r1.w
1860:   mad r3.x, r7.y, cb1[74].w, cb1[75].w
1861:   mad r3.y, r2.w, cb1[72].w, -cb1[71].w
1862:   max r3.xy, r3.xyxx, l(0.010000, 0.000000, 0.000000, 0.000000)
1863:   mul r3.z, r3.x, l(-1.442695)
1864:   exp r3.z, r3.z
1865:   add r3.z, -r3.z, l(1.000000)
1866:   div r3.x, r3.z, r3.x
1867:   mad r3.z, r7.y, cb1[74].w, cb1[76].w
1868:   mul r3.z, r3.z, l(1.442695)
1869:   exp r3.z, r3.z
1870:   mul r3.x, r3.z, r3.x
1871:   mul r3.x, r3.x, -r3.y
1872:   mul r3.xyz, r3.xxxx, cb1[73].xyzx
1873:   mul r3.xyz, r3.xyzx, l(1.442695, 1.442695, 1.442695, 0.000000)
1874:   exp r3.xyz, r3.xyzx
1875:   dp3 r3.w, -r2.xyzx, cb1[72].xyzx
1876:   mad r4.x, cb1[73].w, cb1[73].w, l(1.000000)
1877:   dp2 r4.y, r3.wwww, cb1[73].wwww
1878:   add r4.x, -r4.y, r4.x
1879:   lt r4.y, l(0), cb1[83].z
1880:   if_nz r4.y
1881:     and r12.w, l(7), cb1[26].w
1882:     imad r4.yzw, r12.xxyw, l(0, 0x0019660d, 0x0019660d, 0x0019660d), l(0.000000, 0.014584, 0.014584, 0.014584)
1883:     imad r4.y, r4.z, r4.w, r4.y
1884:     imad r4.z, r4.w, r4.y, r4.z
1885:     imad r4.w, r4.y, r4.z, r4.w
1886:     imad r5.x, r4.z, r4.w, r4.y
1887:     dp3 r0.x, -r2.xyzx, -r0.xyzx
1888:     lt r0.y, l(0.000000), r0.x
1889:     div r0.x, l(1.000000, 1.000000, 1.000000, 1.000000), r0.x
1890:     and r0.x, r0.x, r0.y
1891:     mul r0.x, r0.x, cb1[83].w
1892:     div r0.y, l(1.000000, 1.000000, 1.000000, 1.000000), r2.w
1893:     mul r0.z, r0.y, r0.x
1894:     mad r4.y, r0.z, v2.y, cb0[44].y
1895:     mad r0.z, -r0.z, v2.y, v2.y
1896:     mad r0.x, -r0.x, r0.y, l(1.000000)
1897:     mul r0.y, r2.w, r0.x
1898:     mul r5.z, r0.z, cb1[77].z
1899:     mul r0.z, r0.z, cb1[80].x
1900:     max r0.z, r0.z, l(-127.000000)
1901:     add r5.w, r4.y, -cb1[77].x
1902:     mul r5.w, r5.w, cb1[77].z
1903:     max r5.zw, r5.zzzw, l(0.000000, 0.000000, -127.000000, -127.000000)
1904:     exp r5.w, -r5.w
1905:     mul r5.w, r5.w, cb1[77].y
1906:     lt r6.x, l(0.000000), abs(r5.z)
1907:     exp r6.w, -r5.z
1908:     add r6.w, -r6.w, l(1.000000)
1909:     div r6.w, r6.w, r5.z
1910:     mad r5.z, -r5.z, l(0.240227), l(0.693147)
1911:     movc r5.z, r6.x, r6.w, r5.z
1912:     add r4.y, r4.y, -cb1[80].z
1913:     mul r4.y, r4.y, cb1[80].x
1914:     max r4.y, r4.y, l(-127.000000)
1915:     exp r4.y, -r4.y
1916:     mul r4.y, r4.y, cb1[80].y
1917:     lt r6.x, l(0.000000), abs(r0.z)
1918:     exp r6.w, -r0.z
1919:     add r6.w, -r6.w, l(1.000000)
1920:     div r6.w, r6.w, r0.z
1921:     mad r0.z, -r0.z, l(0.240227), l(0.693147)
1922:     movc r0.z, r6.x, r6.w, r0.z
1923:     mul r0.z, r0.z, r4.y
1924:     mad r0.z, r5.w, r5.z, r0.z
1925:     mad_sat r5.zw, r2.wwww, cb1[78].wwwy, cb1[78].zzzx
1926:     mul r0.y, r0.y, r0.z
1927:     exp r0.y, -r0.y
1928:     min r0.y, r0.y, l(1.000000)
1929:     max r0.y, r0.y, cb1[79].w
1930:     add r0.y, r5.w, r0.y
1931:     add r0.y, r5.z, r0.y
1932:     min r0.y, r0.y, l(1.000000)
1933:     imad r5.y, r4.w, r5.x, r4.z
1934:     ushr r4.yz, r5.xxyx, l(0, 16, 16, 0)
1935:     utof r4.yz, r4.yyzy
1936:     mad r4.yz, r4.yyzy, l(0.000000, 0.000031, 0.000031, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
1937:     mad r4.yz, r4.yyzy, cb1[87].wwww, r6.yyzy
1938:     mul r6.xy, r4.yzyy, cb1[85].xyxx
1939:     mad r4.y, v0.w, cb1[84].x, cb1[84].y
1940:     log r4.y, r4.y
1941:     mul r4.y, r4.y, cb1[84].z
1942:     div r6.z, r4.y, cb1[83].z
1943:     sample_l(texture3d)(float,float,float,float) r6.xyzw, r6.xyzx, t23.xyzw, s0, l(0)
1944:     add r4.y, v0.w, -cb1[86].z
1945:     mul_sat r4.y, r4.y, l(1000000.000000)
1946:     add r6.xyzw, r6.xyzw, l(-0.000000, -0.000000, -0.000000, -1.000000)
1947:     mad r6.xyzw, r4.yyyy, r6.xyzw, l(0.000000, 0.000000, 0.000000, 1.000000)
1948:     add r4.y, -r0.y, l(1.000000)
1949:     dp3_sat r4.z, r2.xyzx, cb1[81].xyzx
1950:     log r4.z, r4.z
1951:     mul r4.z, r4.z, cb1[82].w
1952:     exp r4.z, r4.z
1953:     mul r5.xyw, r4.zzzz, cb1[82].xyxz
1954:     mad r0.x, r0.x, r2.w, -cb1[81].w
1955:     max r0.x, r0.x, l(0)
1956:     mul r0.x, r0.x, r0.z
1957:     exp r0.x, -r0.x
1958:     min r0.x, r0.x, l(1.000000)
1959:     add r0.x, -r0.x, l(1.000000)
1960:     mul r5.xyw, r0.xxxx, r5.xyxw
1961:     add r0.x, -r5.z, l(1.000000)
1962:     mul r5.xyz, r0.xxxx, r5.xywx
1963:     mad r4.yzw, cb1[79].xxyz, r4.yyyy, r5.xxyz
1964:     mad r4.yzw, r4.yyzw, r6.wwww, r6.xxyz
1965:     mul r0.x, r0.y, r6.w
1966:   else
1967:     mul r0.y, v2.y, cb1[77].z
1968:     mul r0.z, v2.y, cb1[80].x
1969:     max r0.yz, r0.yyzy, l(0.000000, -127.000000, -127.000000, 0.000000)
1970:     add r5.x, cb0[44].y, -cb1[77].x
1971:     mul r5.x, r5.x, cb1[77].z
1972:     max r5.x, r5.x, l(-127.000000)
1973:     exp r5.x, -r5.x
1974:     mul r5.x, r5.x, cb1[77].y
1975:     lt r5.y, l(0.000000), abs(r0.y)
1976:     exp r5.z, -r0.y
1977:     add r5.z, -r5.z, l(1.000000)
1978:     div r5.z, r5.z, r0.y
1979:     mad r0.y, -r0.y, l(0.240227), l(0.693147)
1980:     movc r0.y, r5.y, r5.z, r0.y
1981:     add r5.y, cb0[44].y, -cb1[80].z
1982:     mul r5.y, r5.y, cb1[80].x
1983:     max r5.y, r5.y, l(-127.000000)
1984:     exp r5.y, -r5.y
1985:     mul r5.y, r5.y, cb1[80].y
1986:     lt r5.z, l(0.000000), abs(r0.z)
1987:     exp r5.w, -r0.z
1988:     add r5.w, -r5.w, l(1.000000)
1989:     div r5.w, r5.w, r0.z
1990:     mad r0.z, -r0.z, l(0.240227), l(0.693147)
1991:     movc r0.z, r5.z, r5.w, r0.z
1992:     mul r0.z, r0.z, r5.y
1993:     mad r0.y, r5.x, r0.y, r0.z
1994:     mad_sat r5.xy, r2.wwww, cb1[78].wyww, cb1[78].zxzz
1995:     mul r0.z, r2.w, r0.y
1996:     exp r0.z, -r0.z
1997:     min r0.z, r0.z, l(1.000000)
1998:     max r0.z, r0.z, cb1[79].w
1999:     add r0.z, r5.y, r0.z
2000:     add r0.z, r5.x, r0.z
2001:     min r0.x, r0.z, l(1.000000)
2002:     dp3_sat r2.x, r2.xyzx, cb1[81].xyzx
2003:     log r2.x, r2.x
2004:     mul r2.x, r2.x, cb1[82].w
2005:     exp r2.x, r2.x
2006:     mul r2.xyz, r2.xxxx, cb1[82].xyzx
2007:     mad r0.w, r0.w, r1.w, -cb1[81].w
2008:     max r0.w, r0.w, l(0)
2009:     mul r0.y, r0.w, r0.y
2010:     exp r0.y, -r0.y
2011:     min r0.y, r0.y, l(1.000000)
2012:     add r0.yz, -r0.yyxy, l(0.000000, 1.000000, 1.000000, 0.000000)
2013:     mul r2.xyz, r0.yyyy, r2.xyzx
2014:     add r0.y, -r5.x, l(1.000000)
2015:     mul r2.xyz, r0.yyyy, r2.xyzx
2016:     mad r4.yzw, cb1[79].xxyz, r0.zzzz, r2.xxyz
2017:   endif
2018:   mul r0.yzw, r0.xxxx, r3.xxyz
2019:   mad r1.w, r3.w, r3.w, l(1.000000)
2020:   mul r1.w, r1.w, l(0.059683)
2021:   mad r2.xyz, cb1[74].xyzx, r1.wwww, cb1[76].xyzx
2022:   mad r1.w, -cb1[73].w, cb1[73].w, l(1.000000)
2023:   mul r2.w, r4.x, l(12.566371)
2024:   sqrt r3.w, r4.x
2025:   mul r2.w, r2.w, r3.w
2026:   max r2.w, r2.w, l(0.001000)
2027:   div r1.w, r1.w, r2.w
2028:   mad_sat r2.xyz, cb1[75].xyzx, r1.wwww, r2.xyzx
2029:   mul r2.xyz, r2.xyzx, l(255.000000, 255.000000, 255.000000, 0.000000)
2030:   add r3.xyz, -r3.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
2031:   mul r2.xyz, r2.xyzx, r3.xyzx
2032:   mad r2.xyz, r2.xyzx, r0.xxxx, r4.yzwy
2033:   mad o0.xyz, r1.xyzx, r0.yzwy, r2.xyzx
2034: else
2035:   mov o0.xyz, r1.xyzx
2036: endif
2037: mov o1.z, l(1.000000)
2038: ret
