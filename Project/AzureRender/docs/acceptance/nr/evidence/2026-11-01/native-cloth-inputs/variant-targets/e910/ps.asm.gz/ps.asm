Shader hash 0fb48066-c31956e9-43704fd3-8582cda4

ps_5_0
      dcl_globalFlags refactoringAllowed
      dcl_immediateConstantBuffer {
			{ 1.000000, 0, 0, 0}, 
			{ 0, 1.000000, 0, 0}, 
			{ 0, 0, 1.000000, 0}, 
			{ 0, 0, 0, 1.000000}, 
			{ 2, 1, -1.000000, 1.000000}, 
			{ 2, 1, 1.000000, 1.000000}, 
			{ 0, 2, 1.000000, -1.000000}, 
			{ 0, 2, 1.000000, 1.000000}, 
			{ 0, 1, 1.000000, 1.000000}, 
			{ 0, 1, -1.000000, 1.000000} }
      dcl_constantbuffer cb0[45], immediateIndexed
      dcl_constantbuffer cb1[141], immediateIndexed
      dcl_constantbuffer cb2[4094], dynamicIndexed
      dcl_constantbuffer cb3[2054], dynamicIndexed
      dcl_constantbuffer cb4[4], immediateIndexed
      dcl_constantbuffer cb5[66], immediateIndexed
      dcl_constantbuffer cb6[27], immediateIndexed
      dcl_constantbuffer cb7[160], dynamicIndexed
      dcl_sampler s0, mode_default
      dcl_sampler s1, mode_default
      dcl_sampler s2, mode_comparison
      dcl_resource_structured t0, 4
      dcl_resource_structured t1, 16
      dcl_resource_raw t2
      dcl_resource_texture2d (float,float,float,float) t3
      dcl_resource_texture2d (float,float,float,float) t4
      dcl_resource_texture3d (float,float,float,float) t5
      dcl_resource_texture3d (float,float,float,float) t6
      dcl_resource_texture3d (float,float,float,float) t7
      dcl_resource_texture3d (float,float,float,float) t8
      dcl_resource_texture3d (float,float,float,float) t9
      dcl_resource_texture3d (float,float,float,float) t10
      dcl_resource_texture2d (float,float,float,float) t11
      dcl_resource_texture2d (float,float,float,float) t12
      dcl_resource_texture2d (float,float,float,float) t13
      dcl_resource_texture2d (float,float,float,float) t14
      dcl_resource_texture2d (float,float,float,float) t15
      dcl_resource_texture2d (float,float,float,float) t16
      dcl_resource_texture2d (float,float,float,float) t17
      dcl_resource_texture2d (float,float,float,float) t18
      dcl_resource_texture2d (float,float,float,float) t19
      dcl_resource_texturecube (float,float,float,float) t20
      dcl_resource_texture2d (float,float,float,float) t21
      dcl_resource_texture2d (float,float,float,float) t22
      dcl_resource_texture2d (float,float,float,float) t23
      dcl_resource_texture3d (float,float,float,float) t24
      dcl_input_ps_siv linear noperspective v0.xyw, position
      dcl_input_ps linear v1.xy
      dcl_input_ps linear v1.zw
      dcl_input_ps linear v2.xyz
      dcl_input_ps linear v3.xyz
      dcl_input_ps linear v4.xyzw
      dcl_input_ps linear v5.xyz
      dcl_input_ps linear v6.xyz
      dcl_input_ps linear v7.xyz
      dcl_input_ps linear v8.xyz
      dcl_input_ps nointerpolation v9.x
      dcl_input_ps_sgv nointerpolation v10.x, isfrontface
      dcl_output o0.xyzw
      dcl_output o1.xyzw
      dcl_temps 36
   0: mov r0.x, cb0[0].z
   1: mov r0.y, cb0[1].z
   2: mov r0.z, cb0[2].z
   3: add r1.xyz, r0.xyzx, v2.xyzx
   4: mad r1.xyz, cb1[4].wwww, r1.xyzx, -v2.xyzx
   5: dp3 r1.w, r1.xyzx, r1.xyzx
   6: max r2.x, r1.w, l(0.000000)
   7: rsq r2.x, r2.x
   8: mul r2.yzw, r1.xxyz, r2.xxxx
   9: ishl r3.x, v9.x, l(4)
  10: and r3.y, l(16), cb2[r3.x + 4].w
  11: if_nz r3.y
  12:   iadd r3.z, l(2), cb2[r3.x + 5].x
  13:   ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.x, r3.z, l(12), t1.xxxx
  14:   ld_structured_indexable(structured_buffer, stride=16)(mixed,mixed,mixed,mixed) r4.y, cb2[r3.x + 5].x, l(12), t1.xxxx
  15: else
  16:   mov r4.xy, cb2[r3.x + 3].zxzz
  17: endif
  18: mad r5.xyzw, cb6[25].xyzw, cb1[105].wwww, v1.xyxy
  19: sample_b(texture2d)(float,float,float,float) r6.xyzw, r5.xyxx, t16.xyzw, s1, cb1[26].x
  20: mul r6.xyzw, r6.xyzw, cb6[6].xyzw
  21: sample_b(texture2d)(float,float,float,float) r7.xyzw, v1.xyxx, t17.xyzw, s1, cb1[26].x
  22: add r3.z, -r7.w, l(1.000000)
  23: add r8.xyz, v2.xyzx, cb0[44].xyzx
  24: add r4.xz, -r4.yyxy, r8.xxzx
  25: mov r4.y, l(0.000061)
  26: dp3 r3.w, r4.xyzx, r4.xyzx
  27: rsq r3.w, r3.w
  28: mul r4.xyz, r3.wwww, r4.xyzx
  29: sample_b(texture2d)(float,float,float,float) r9.xyz, v1.xyxx, t18.xywz, s1, cb1[26].x
  30: mul r9.x, r9.x, r9.z
  31: mad r5.xy, r9.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
  32: dp2 r3.w, r5.xyxx, r5.xyxx
  33: min r3.w, r3.w, l(1.000000)
  34: add r3.w, -r3.w, l(1.000000)
  35: sqrt r3.w, r3.w
  36: max r3.w, r3.w, l(0.000000)
  37: mul r5.xy, r5.xyxx, cb6[0].wwww
  38: mul r9.xyz, r6.xyzx, cb6[4].zzzz
  39: dp3 r4.w, r9.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
  40: mad r9.xyz, r6.xyzx, cb6[4].zzzz, -r4.wwww
  41: mad r9.xyz, cb6[4].wwww, r9.xyzx, r4.wwww
  42: sample_b(texture2d)(float,float,float,float) r10.xyzw, r5.zwzz, t19.xyzw, s1, cb1[26].x
  43: mul r11.xyz, v3.zxyz, v4.yzxy
  44: mad r11.xyz, v3.yzxy, v4.zxyz, -r11.xyzx
  45: mul r11.xyz, r11.xyzx, v4.wwww
  46: mul r5.yzw, r5.yyyy, r11.xxyz
  47: mad r5.xyz, r5.xxxx, v4.xyzx, r5.yzwy
  48: mad r5.xyz, r3.wwww, v3.xyzx, r5.xyzx
  49: mad r3.w, cb6[1].y, l(2.000000), l(-1.000000)
  50: movc r3.w, v10.x, l(1.000000), r3.w
  51: dp3 r4.w, r5.xyzx, r5.xyzx
  52: max r4.w, r4.w, l(0.000000)
  53: rsq r4.w, r4.w
  54: mul r5.xyz, r4.wwww, r5.xyzx
  55: mul r11.xyz, r3.wwww, r5.xyzx
  56: dp3 r4.w, v3.xyzx, v3.xyzx
  57: rsq r4.w, r4.w
  58: mul r5.xzw, r4.wwww, v3.xxyz
  59: mul r5.xzw, r3.wwww, r5.xxzw
  60: ftou r12.xy, v0.xyxx
  61: lt r4.w, l(0.500000), cb1[120].x
  62: movc r4.w, r4.w, cb1[120].y, cb2[r3.x + 13].x
  63: and r8.w, r4.w, l(255)
  64: utof r13.x, r8.w
  65: ubfe r14.xy, l(8, 8, 0, 0), l(8, 16, 0, 0), r4.wwww
  66: utof r13.yz, r14.xxyx
  67: ushr r4.w, r4.w, l(24)
  68: utof r13.w, r4.w
  69: mul r14.xyzw, r13.xyzw, l(0.003922, 0.003922, 0.003922, 0.003922)
  70: add r4.w, cb1[120].w, -cb2[r3.x + 13].y
  71: mad r4.w, cb1[120].x, r4.w, cb2[r3.x + 13].y
  72: add r4.w, -r8.y, r4.w
  73: add r4.w, r4.w, l(0.200000)
  74: mul_sat r4.w, r4.w, l(2.857143)
  75: mad r8.w, r4.w, l(-2.000000), l(3.000000)
  76: mul r4.w, r4.w, r4.w
  77: mul r4.w, r4.w, r8.w
  78: mul r4.w, r14.y, r4.w
  79: max r8.w, r4.w, r14.z
  80: add r9.w, l(1.000000), -cb1[29].x
  81: mad r9.w, cb1[122].w, r9.w, cb1[29].x
  82: mul r9.w, r9.w, cb1[27].x
  83: lt r13.y, cb1[111].y, l(0.500000)
  84: if_nz r13.y
  85:   mad r15.xyz, cb0[6].xzyx, -cb1[137].wwww, cb1[135].xzyx
  86:   add r15.xyz, r8.xzyx, -r15.xyzx
  87:   max r13.y, abs(r15.y), abs(r15.x)
  88:   add r13.y, r13.y, l(-464.000000)
  89:   add r13.z, abs(r15.z), l(-208.000000)
  90:   mul_sat r13.yz, r13.yyzy, l(0.000000, 0.031250, 0.031250, 0.000000)
  91:   max r13.y, r13.z, r13.y
  92:   ne r13.z, l(0), cb1[135].w
  93:   lt r14.y, r13.y, l(1.000000)
  94:   and r13.z, r13.z, r14.y
  95:   if_nz r13.z
  96:     mad r15.xyz, cb0[6].xzyx, -cb1[137].yyyy, cb1[135].xzyx
  97:     add r15.xyz, r8.xzyx, -r15.xyzx
  98:     max r13.z, abs(r15.y), abs(r15.x)
  99:     add r13.z, r13.z, l(-29.000000)
 100:     mul_sat r13.z, r13.z, l(0.500000)
 101:     add r14.y, abs(r15.z), l(-13.000000)
 102:     mul_sat r14.y, r14.y, l(0.500000)
 103:     max r13.z, r13.z, r14.y
 104:     lt r14.y, r13.z, l(1.000000)
 105:     if_nz r14.y
 106:       mad r15.xyz, r8.xyzx, l(2.000000, 2.000000, 2.000000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 107:       mul r16.xyz, r15.xyzx, cb1[136].xyzx
 108:       round_ni r16.xyz, r16.xyzx
 109:       mad r15.xyz, r15.xyzx, cb1[136].xyzx, -r16.xyzx
 110:       sample_l(texture3d)(float,float,float,float) r16.xyw, r15.xyzx, t5.yzwx, s1, l(0)
 111:       add r14.y, -r13.z, l(1.000000)
 112:       mul r14.z, l(0.500000), cb1[136].y
 113:       mad r17.x, -cb1[136].y, l(0.500000), l(1.000000)
 114:       max r14.z, r14.z, r15.y
 115:       min r14.z, r17.x, r14.z
 116:       mul r15.w, r14.z, l(0.333333)
 117:       sample_l(texture3d)(float,float,float,float) r17.xyzw, r15.xwzx, t6.xyzw, s0, l(0)
 118:       mad r14.z, r17.w, r14.y, r13.y
 119:       add r18.xyz, r15.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 120:       sample_l(texture3d)(float,float,float,float) r18.xyz, r18.xyzx, t6.xyzw, s0, l(0)
 121:       mad r18.xyz, r18.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 122:       mul r18.xyz, r16.yyyy, r18.xyzx
 123:       mov r18.w, r16.y
 124:       mul r18.xyzw, r14.yyyy, r18.xyzw
 125:       add r15.xyz, r15.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 126:       sample_l(texture3d)(float,float,float,float) r15.xyz, r15.xyzx, t6.xyzw, s0, l(0)
 127:       mad r15.xyz, r15.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 128:       mul r15.xyz, r16.xxxx, r15.xyzx
 129:       mov r15.w, r16.x
 130:       mul r15.xyzw, r14.yyyy, r15.xyzw
 131:       mad r17.xyz, r17.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 132:       mul r16.xyz, r16.wwww, r17.xyzx
 133:       mul r16.xyzw, r14.yyyy, r16.xyzw
 134:     else
 135:       mov r18.xyzw, l(0, 0, 0, 0)
 136:       mov r15.xyzw, l(0, 0, 0, 0)
 137:       mov r16.xyzw, l(0, 0, 0, 0)
 138:       mov r14.z, r13.y
 139:     endif
 140:     mad r17.xyz, cb0[6].xzyx, -cb1[137].zzzz, cb1[135].xzyx
 141:     add r17.xyz, r8.xzyx, -r17.xyzx
 142:     max r14.y, abs(r17.y), abs(r17.x)
 143:     add r14.y, r14.y, l(-116.000000)
 144:     mul_sat r14.y, r14.y, l(0.125000)
 145:     add r17.x, abs(r17.z), l(-52.000000)
 146:     mul_sat r17.x, r17.x, l(0.125000)
 147:     max r14.y, r14.y, r17.x
 148:     lt r17.x, r14.y, l(1.000000)
 149:     if_nz r17.x
 150:       mad r17.xyz, r8.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 151:       mul r19.xyz, r17.xyzx, cb1[136].xyzx
 152:       round_ni r19.xyz, r19.xyzx
 153:       mad r17.xyz, r17.xyzx, cb1[136].xyzx, -r19.xyzx
 154:       sample_l(texture3d)(float,float,float,float) r19.xyw, r17.xyzx, t7.yzwx, s1, l(0)
 155:       add r20.x, -r14.y, l(1.000000)
 156:       mul r13.z, r13.z, r20.x
 157:       mul r20.x, l(0.500000), cb1[136].y
 158:       mad r20.y, -cb1[136].y, l(0.500000), l(1.000000)
 159:       max r17.y, r17.y, r20.x
 160:       min r17.y, r20.y, r17.y
 161:       mul r17.w, r17.y, l(0.333333)
 162:       sample_l(texture3d)(float,float,float,float) r20.xyzw, r17.xwzx, t8.xyzw, s0, l(0)
 163:       mad r14.z, r20.w, r13.z, r14.z
 164:       add r21.xyz, r17.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 165:       sample_l(texture3d)(float,float,float,float) r21.xyz, r21.xyzx, t8.xyzw, s0, l(0)
 166:       mad r21.xyz, r21.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 167:       mul r21.xyz, r19.yyyy, r21.xyzx
 168:       mov r21.w, r19.y
 169:       mad r18.xyzw, r21.xyzw, r13.zzzz, r18.xyzw
 170:       add r17.xyz, r17.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 171:       sample_l(texture3d)(float,float,float,float) r17.xyz, r17.xyzx, t8.xyzw, s0, l(0)
 172:       mad r17.xyz, r17.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 173:       mul r17.xyz, r19.xxxx, r17.xyzx
 174:       mov r17.w, r19.x
 175:       mad r15.xyzw, r17.xyzw, r13.zzzz, r15.xyzw
 176:       mad r17.xyz, r20.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 177:       mul r19.xyz, r19.wwww, r17.xyzx
 178:       mad r16.xyzw, r19.xyzw, r13.zzzz, r16.xyzw
 179:     endif
 180:     lt r13.z, l(0), r14.y
 181:     if_nz r13.z
 182:       mad r17.xyz, r8.xyzx, l(0.125000, 0.125000, 0.125000, 0.000000), l(0.500000, 0.500000, 0.500000, 0.000000)
 183:       mul r19.xyz, r17.xyzx, cb1[136].xyzx
 184:       mul r20.xyz, l(0.500000, 0.500000, 0.500000, 0.000000), cb1[136].xyzx
 185:       round_ni r19.xyz, r19.xyzx
 186:       mad r17.xyz, r17.xyzx, cb1[136].xyzx, -r19.xyzx
 187:       mad r19.xyz, -cb1[136].xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), l(1.000000, 1.000000, 1.000000, 0.000000)
 188:       max r17.xyz, r20.xyzx, r17.xyzx
 189:       min r17.xyz, r19.xyzx, r17.xyzx
 190:       sample_l(texture3d)(float,float,float,float) r21.xyw, r17.xyzx, t9.yzwx, s1, l(0)
 191:       add r13.z, -r13.y, l(1.000000)
 192:       mul r13.z, r13.z, r14.y
 193:       max r14.y, r20.y, r17.y
 194:       min r14.y, r19.y, r14.y
 195:       mul r17.w, r14.y, l(0.333333)
 196:       sample_l(texture3d)(float,float,float,float) r19.xyzw, r17.xwzx, t10.xyzw, s0, l(0)
 197:       add r20.xyz, r17.xwzx, l(0.000000, 0.666667, 0.000000, 0.000000)
 198:       sample_l(texture3d)(float,float,float,float) r20.xyz, r20.xyzx, t10.xyzw, s0, l(0)
 199:       mad r20.xyz, r20.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 200:       mul r20.xyz, r21.yyyy, r20.xyzx
 201:       mov r20.w, r21.y
 202:       mad r18.xyzw, r20.xyzw, r13.zzzz, r18.xyzw
 203:       add r17.xyz, r17.xwzx, l(0.000000, 0.333333, 0.000000, 0.000000)
 204:       sample_l(texture3d)(float,float,float,float) r17.xyz, r17.xyzx, t10.xyzw, s0, l(0)
 205:       mad r17.xyz, r17.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 206:       mul r17.xyz, r21.xxxx, r17.xyzx
 207:       mov r17.w, r21.x
 208:       mad r15.xyzw, r17.xyzw, r13.zzzz, r15.xyzw
 209:       mad r17.xyz, r19.xyzx, l(4.000000, 4.000000, 4.000000, 0.000000), l(-2.000000, -2.000000, -2.000000, 0.000000)
 210:       mul r21.xyz, r21.wwww, r17.xyzx
 211:       mad r16.xyzw, r21.xyzw, r13.zzzz, r16.xyzw
 212:       mad r14.z, r19.w, r13.z, r14.z
 213:     endif
 214:     mad_sat r13.z, r14.z, l(2.000000), l(-1.000000)
 215:     add r17.x, -r13.y, r13.z
 216:     add r13.y, r13.y, r13.z
 217:     mul r17.y, r13.y, l(0.500000)
 218:   else
 219:     mov r18.xyzw, l(0, 0, 0, 0)
 220:     mov r15.xyzw, l(0, 0, 0, 0)
 221:     mov r16.xyzw, l(0, 0, 0, 0)
 222:     mov r17.xy, l(0.000000, 1.000000, 0.000000, 0.000000)
 223:   endif
 224:   mul r19.xyzw, r17.yyyx, cb1[138].xyzw
 225:   mad r19.y, r19.w, l(0.500000), r19.y
 226:   mul r13.yz, r17.yyxy, cb1[138].wwyw
 227:   mad r19.w, r13.z, l(0.375000), r13.y
 228:   add r16.xyzw, r16.xyzw, r19.xyzw
 229:   mul r19.xyzw, r17.yyyx, cb1[139].xyzw
 230:   mad r19.y, r19.w, l(0.500000), r19.y
 231:   mul r13.yz, r17.yyxy, cb1[139].wwyw
 232:   mad r19.w, r13.z, l(0.375000), r13.y
 233:   add r15.xyzw, r15.xyzw, r19.xyzw
 234:   mul r19.xyzw, r17.yyyx, cb1[140].xyzw
 235:   mad r19.y, r19.w, l(0.500000), r19.y
 236:   mul r13.yz, r17.yyxy, cb1[140].wwyw
 237:   mad r19.w, r13.z, l(0.375000), r13.y
 238:   add r17.xyzw, r18.xyzw, r19.xyzw
 239:   mov r11.w, l(1.000000)
 240:   dp4 r18.x, r16.xyzw, r11.xyzw
 241:   dp4 r18.y, r15.xyzw, r11.xyzw
 242:   dp4 r18.z, r17.xyzw, r11.xyzw
 243:   max r18.xyz, r18.xyzx, l(0, 0, 0, 0)
 244:   mul r19.xyz, r9.wwww, r18.xyzx
 245:   mul r20.xyz, r15.xyzx, l(0.715200, 0.715200, 0.715200, 0.000000)
 246:   mad r20.xyz, r16.xyzx, l(0.212600, 0.212600, 0.212600, 0.000000), r20.xyzx
 247:   mad r20.xyz, r17.xyzx, l(0.072200, 0.072200, 0.072200, 0.000000), r20.xyzx
 248:   dp3 r11.w, r20.xyzx, r20.xyzx
 249:   max r11.w, r11.w, l(0.000000)
 250:   rsq r11.w, r11.w
 251:   mul r20.xyz, r11.wwww, r20.xyzx
 252:   mov r20.y, abs(r20.y)
 253:   mov r20.w, l(1.000000)
 254:   dp4 r16.x, r16.xyzw, r20.xyzw
 255:   dp4 r16.y, r15.xyzw, r20.xyzw
 256:   dp4 r16.z, r17.xyzw, r20.xyzw
 257:   max r15.xyz, r16.xyzx, l(0, 0, 0, 0)
 258:   ge r11.w, r19.y, r19.z
 259:   and r11.w, r11.w, l(1.000000)
 260:   mov r16.xy, r19.zyzz
 261:   mov r16.zw, l(0.000000, 0.000000, -1.000000, 0.666667)
 262:   mad r17.xy, r18.yzyy, r9.wwww, -r16.xyxx
 263:   mov r17.zw, l(0.000000, 0.000000, 1.000000, -1.000000)
 264:   mad r16.xyzw, r11.wwww, r17.xyzw, r16.xyzw
 265:   ge r11.w, r19.x, r16.x
 266:   and r11.w, r11.w, l(1.000000)
 267:   mov r17.xyz, r16.xywx
 268:   mov r17.w, r19.x
 269:   mov r16.xyw, r17.wywx
 270:   add r16.xyzw, -r17.xyzw, r16.xyzw
 271:   mad r16.xyzw, r11.wwww, r16.xyzw, r17.xyzw
 272:   min r11.w, r16.y, r16.w
 273:   add r11.w, -r11.w, r16.x
 274:   add r13.y, -r16.y, r16.w
 275:   mad r13.z, r11.w, l(6.000000), l(0.000100)
 276:   div r13.y, r13.y, r13.z
 277:   add r13.y, r13.y, r16.z
 278:   frc r13.y, abs(r13.y)
 279:   add r13.z, r16.x, l(0.000100)
 280:   div r11.w, r11.w, r13.z
 281:   add r17.xyzw, r13.yyyy, l(-0.500000, 1.000000, 0.666667, 0.333333)
 282:   add r13.y, abs(r17.x), l(-0.450000)
 283:   mul_sat r13.y, r13.y, l(-10.000001)
 284:   mad r13.z, r13.y, l(-2.000000), l(3.000000)
 285:   mul r13.y, r13.y, r13.y
 286:   mul r13.y, r13.y, r13.z
 287:   mad r13.y, r13.y, l(-0.350000), l(0.700000)
 288:   mov_sat r16.x, r16.x
 289:   mul r13.y, r13.y, r16.x
 290:   min r11.w, r11.w, r13.y
 291:   add r13.y, -r11.w, l(2.000000)
 292:   div r13.y, l(2.000000), r13.y
 293:   frc r16.xyz, r17.yzwy
 294:   mad r16.xyz, r16.xyzx, l(6.000000, 6.000000, 6.000000, 0.000000), l(-3.000000, -3.000000, -3.000000, 0.000000)
 295:   add_sat r16.xyz, abs(r16.xyzx), l(-1.000000, -1.000000, -1.000000, 0.000000)
 296:   add r16.xyz, r16.xyzx, l(-1.000000, -1.000000, -1.000000, 0.000000)
 297:   mad r16.xyz, r11.wwww, r16.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 298:   mul r16.xyz, r13.yyyy, r16.xyzx
 299:   max r11.w, r15.y, r15.x
 300:   max r11.w, r15.z, r11.w
 301:   mul r9.w, r9.w, r11.w
 302:   mov r11.w, l(1.000000)
 303: else
 304:   mov r20.xyz, l(0, 0, 0, 0)
 305:   mov r19.xyz, l(1.000000, 1.000000, 1.000000, 0.000000)
 306:   mov r16.xyz, cb1[112].xyzx
 307:   mov r11.w, l(0)
 308: endif
 309: mad r13.y, r13.x, l(0.003922), r8.w
 310: min r13.y, r13.y, l(1.000000)
 311: add r13.y, r13.y, -cb6[5].x
 312: lt r13.y, l(0.010000), r13.y
 313: if_nz r13.y
 314:   add r13.y, -r7.x, l(1.000000)
 315:   mul r15.xyz, r6.xyzx, r13.yyyy
 316:   dp3 r13.z, r15.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 317:   add r13.z, r13.z, l(-0.350000)
 318:   mul_sat r13.z, r13.z, l(-4.000000)
 319:   mad r14.y, r13.z, l(-2.000000), l(3.000000)
 320:   mul r13.z, r13.z, r13.z
 321:   mul r14.z, r13.z, r14.y
 322:   mul r15.xyzw, v8.xyxz, l(1.000000, -1.000000, 1.000000, 1.000000)
 323:   movc r15.xyzw, r3.yyyy, r15.xyzw, v8.xzxy
 324:   mul r17.xyzw, r15.xyzw, cb1[120].zzzz
 325:   movc r18.yz, r3.yyyy, v7.zzyz, v7.yyzy
 326:   mov r18.x, v7.x
 327:   add r21.xyz, abs(r18.xyzx), l(-0.200000, -0.200000, -0.200000, 0.000000)
 328:   mul r22.xyz, r21.xyzx, r21.xyzx
 329:   mul r22.xyz, r21.xyzx, r22.xyzx
 330:   max r22.xyz, r22.xyzx, l(0.000061, 0.000061, 0.000061, 0.000000)
 331:   dp3 r15.x, r22.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 332:   div r22.xyz, r22.xyzx, r15.xxxx
 333:   sample_b(texture2d)(float,float,float,float) r23.xyzw, r17.zyzz, t13.xyzw, s1, cb1[26].x
 334:   sample_b(texture2d)(float,float,float,float) r24.xyzw, r17.zwzz, t13.xyzw, s1, cb1[26].x
 335:   mul r24.xyzw, r22.zzzz, r24.xyzw
 336:   mad r23.xyzw, r23.xyzw, r22.yyyy, r24.xyzw
 337:   sample_b(texture2d)(float,float,float,float) r24.xyzw, r17.ywyy, t13.xyzw, s1, cb1[26].x
 338:   mad r22.xyzw, r24.xyzw, r22.xxxx, r23.xyzw
 339:   add r18.yw, -r22.wwww, l(0.000000, 0.800000, 0.000000, 0.450000)
 340:   mul r23.xyz, r11.yyxy, l(0.200000, 0.000000, 1.000000, 0.000000)
 341:   mad_sat r15.x, r14.x, r13.y, r23.x
 342:   add r15.x, -r18.y, r15.x
 343:   mul_sat r15.x, r15.x, l(3.333333)
 344:   mad r16.w, r15.x, l(-2.000000), l(3.000000)
 345:   mul r15.x, r15.x, r15.x
 346:   mul r15.x, r15.x, r16.w
 347:   mul_sat r4.w, r4.w, r13.y
 348:   add r4.w, -r18.w, r4.w
 349:   mul_sat r4.w, r4.w, l(1.538461)
 350:   mad r13.y, r4.w, l(-2.000000), l(3.000000)
 351:   mul r4.w, r4.w, r4.w
 352:   mul r4.w, r4.w, r13.y
 353:   max r4.w, r4.w, r15.x
 354:   add r13.y, r7.x, l(-0.500000)
 355:   mul_sat r13.y, r13.y, l(4.000000)
 356:   mad r15.x, r13.y, l(-2.000000), l(3.000000)
 357:   mul r13.y, r13.y, r13.y
 358:   mul r13.y, r13.y, r15.x
 359:   add r7.w, -r7.w, l(0.200000)
 360:   mul_sat r7.w, r7.w, l(-5.000000)
 361:   mad r15.x, r7.w, l(-2.000000), l(3.000000)
 362:   mul r7.w, r7.w, r7.w
 363:   mul r7.w, r7.w, r15.x
 364:   mad r15.x, r7.w, r14.z, r13.y
 365:   min r15.x, r15.x, l(1.000000)
 366:   max r14.x, r8.w, r14.x
 367:   mul r16.w, r14.x, r15.x
 368:   ge r13.x, l(2.550000), r13.x
 369:   and r13.x, r13.x, l(1.000000)
 370:   ge r18.y, r8.w, l(0.010000)
 371:   and r18.y, r18.y, l(1.000000)
 372:   mul r13.x, r13.x, r18.y
 373:   eq r13.x, r13.x, l(0)
 374:   add r8.w, -r8.w, l(1.000000)
 375:   movc r18.yw, r13.xxxx, l(0.000000, 3.000000, 0.000000, 4.345600), r8.wwww
 376:   mad r23.xw, -r15.xxxx, r14.xxxx, l(1.000000, 0.000000, 0.000000, 1.010000)
 377:   movc r8.w, r13.x, cb1[20].x, l(1.000000)
 378:   mul r24.xyz, r17.yzwy, l(20.000000, 20.000000, 20.000000, 0.000000)
 379:   mul r25.xyz, r17.yzwy, l(34.345600, 34.345600, 34.345600, 0.000000)
 380:   max r21.xyz, r21.xyzx, l(0, 0, 0, 0)
 381:   mul r21.xyz, r21.xyzx, r21.xyzx
 382:   mul r26.xyz, r21.xyzx, r21.xyzx
 383:   mul r26.xyz, r26.xyzx, r26.xyzx
 384:   mul r21.xyz, r21.xyzx, r26.xyzx
 385:   dp3 r19.w, r21.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
 386:   max r19.w, r19.w, l(0.000061)
 387:   div r21.xyz, r21.xyzx, r19.wwww
 388:   round_ni r26.xyzw, r24.yxyz
 389:   mul r27.xyzw, r26.xyzw, l(123.339996, 456.209991, 123.339996, 456.209991)
 390:   frc r27.xyzw, r27.xyzw
 391:   add r28.xyzw, r27.xyzw, l(34.345001, 34.345001, 34.345001, 34.345001)
 392:   dp2 r19.w, r27.xyxx, r28.xyxx
 393:   add r24.yw, r19.wwww, r27.xxxy
 394:   mul r19.w, r24.w, r24.y
 395:   add r20.w, r24.w, r24.y
 396:   frc r19.w, r19.w
 397:   frc r20.w, r20.w
 398:   add r29.xyzw, r26.xyzw, l(114.514000, 114.514000, 114.514000, 114.514000)
 399:   mul r29.xyzw, r29.xyzw, l(123.339996, 456.209991, 123.339996, 456.209991)
 400:   frc r29.xyzw, r29.xyzw
 401:   add r30.xyzw, r29.xyzw, l(34.345001, 34.345001, 34.345001, 34.345001)
 402:   dp2 r21.w, r29.xyxx, r30.xyxx
 403:   add r24.yw, r21.wwww, r29.xxxy
 404:   mul r21.w, r24.w, r24.y
 405:   add r22.w, r24.w, r24.y
 406:   frc r27.x, r21.w
 407:   frc r27.y, r22.w
 408:   mad r21.w, r19.w, l(0.400000), l(0.600000)
 409:   mul r22.w, r21.w, l(0.250000)
 410:   mad r26.xyzw, r17.zyzw, l(20.000000, 20.000000, 20.000000, 20.000000), -r26.xyzw
 411:   mad r24.yw, r27.xxxy, l(0.000000, 2.000000, 0.000000, 2.000000), l(0.000000, -1.000000, 0.000000, -1.000000)
 412:   mad r24.yw, r24.yyyw, l(0.000000, 0.250000, 0.000000, 0.250000), r26.xxxy
 413:   add r24.yw, r24.yyyw, l(0.000000, -0.500000, 0.000000, -0.500000)
 414:   mul r26.x, r24.y, l(1.250000)
 415:   lt r24.y, r24.w, l(0)
 416:   movc r24.y, r24.y, l(1.250000), l(0.750000)
 417:   mul r26.y, r24.y, r24.w
 418:   mad r19.w, r8.w, r18.y, r19.w
 419:   frc r24.y, r19.w
 420:   mov_sat r19.w, r19.w
 421:   mad r19.w, r19.w, l(0.630000), l(0.220000)
 422:   movc r19.w, r13.x, r24.y, r19.w
 423:   add r24.yw, r19.wwww, l(0.000000, -0.200000, 0.000000, -0.850000)
 424:   mul_sat r24.yw, r24.yyyw, l(0.000000, 50.000011, 0.000000, -3.333333)
 425:   mad r28.xy, r24.ywyy, l(-2.000000, -2.000000, 0.000000, 0.000000), l(3.000000, 3.000000, 0.000000, 0.000000)
 426:   mul r24.yw, r24.yyyw, r24.yyyw
 427:   mul r24.yw, r24.yyyw, r28.xxxy
 428:   mul r19.w, r24.w, r24.y
 429:   dp2 r24.y, r26.xyxx, r26.xyxx
 430:   sqrt r24.y, r24.y
 431:   mad r21.w, -r21.w, l(0.250000), r24.y
 432:   div r24.y, l(1.000000, 1.000000, 1.000000, 1.000000), -r22.w
 433:   mul_sat r21.w, r21.w, r24.y
 434:   mad r24.y, r21.w, l(-2.000000), l(3.000000)
 435:   mul r21.w, r21.w, r21.w
 436:   mul r21.w, r21.w, r24.y
 437:   ge r21.w, r21.w, l(0.001000)
 438:   and r21.w, r21.w, l(1.000000)
 439:   mul r19.w, r19.w, r21.w
 440:   add r20.w, r20.w, l(-0.100000)
 441:   ge r20.w, r20.w, r23.x
 442:   and r20.w, r20.w, l(1.000000)
 443:   mul r19.w, r19.w, r20.w
 444:   mul r20.w, r21.y, r19.w
 445:   dp2 r21.w, r27.zwzz, r28.zwzz
 446:   add r24.yw, r21.wwww, r27.zzzw
 447:   mul r21.w, r24.w, r24.y
 448:   add r24.y, r24.w, r24.y
 449:   frc r21.w, r21.w
 450:   frc r24.y, r24.y
 451:   dp2 r24.w, r29.zwzz, r30.zwzz
 452:   add r27.yz, r24.wwww, r29.zzwz
 453:   mul r24.w, r27.z, r27.y
 454:   add r25.w, r27.z, r27.y
 455:   frc r28.x, r24.w
 456:   frc r28.y, r25.w
 457:   mad r24.w, r21.w, l(0.400000), l(0.600000)
 458:   mul r25.w, r24.w, l(0.250000)
 459:   mad r27.yz, r28.xxyx, l(0.000000, 2.000000, 2.000000, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
 460:   mad r26.zw, r27.yyyz, l(0.000000, 0.000000, 0.250000, 0.250000), r26.zzzw
 461:   add r26.zw, r26.zzzw, l(0.000000, 0.000000, -0.500000, -0.500000)
 462:   mul r29.x, r26.z, l(1.250000)
 463:   lt r26.z, r26.w, l(0)
 464:   movc r26.z, r26.z, l(1.250000), l(0.750000)
 465:   mul r29.y, r26.z, r26.w
 466:   mad r21.w, r8.w, r18.y, r21.w
 467:   frc r26.z, r21.w
 468:   mov_sat r21.w, r21.w
 469:   mad r21.w, r21.w, l(0.630000), l(0.220000)
 470:   movc r21.w, r13.x, r26.z, r21.w
 471:   add r26.zw, r21.wwww, l(0.000000, 0.000000, -0.200000, -0.850000)
 472:   mul_sat r26.zw, r26.zzzw, l(0.000000, 0.000000, 50.000011, -3.333333)
 473:   mad r27.yz, r26.zzwz, l(0.000000, -2.000000, -2.000000, 0.000000), l(0.000000, 3.000000, 3.000000, 0.000000)
 474:   mul r26.zw, r26.zzzw, r26.zzzw
 475:   mul r26.zw, r26.zzzw, r27.yyyz
 476:   mul r21.w, r26.w, r26.z
 477:   dp2 r26.z, r29.xyxx, r29.xyxx
 478:   sqrt r26.z, r26.z
 479:   mad r24.w, -r24.w, l(0.250000), r26.z
 480:   div r26.z, l(1.000000, 1.000000, 1.000000, 1.000000), -r25.w
 481:   mul_sat r24.w, r24.w, r26.z
 482:   mad r26.z, r24.w, l(-2.000000), l(3.000000)
 483:   mul r24.w, r24.w, r24.w
 484:   mul r24.w, r24.w, r26.z
 485:   ge r24.w, r24.w, l(0.001000)
 486:   and r24.w, r24.w, l(1.000000)
 487:   mul r21.w, r21.w, r24.w
 488:   add r24.y, r24.y, l(-0.100000)
 489:   ge r24.y, r24.y, r23.x
 490:   and r24.y, r24.y, l(1.000000)
 491:   mul r21.w, r21.w, r24.y
 492:   mul r24.y, r21.z, r21.w
 493:   round_ni r24.xz, r24.xxzx
 494:   mul r26.zw, r24.xxxz, l(0.000000, 0.000000, 123.339996, 456.209991)
 495:   frc r26.zw, r26.zzzw
 496:   add r27.yz, r26.zzwz, l(0.000000, 34.345001, 34.345001, 0.000000)
 497:   dp2 r24.w, r26.zwzz, r27.yzyy
 498:   add r26.zw, r24.wwww, r26.zzzw
 499:   mul r24.w, r26.w, r26.z
 500:   add r26.z, r26.w, r26.z
 501:   frc r24.w, r24.w
 502:   frc r26.z, r26.z
 503:   add r27.yz, r24.xxzx, l(0.000000, 114.514000, 114.514000, 0.000000)
 504:   mul r27.yz, r27.yyzy, l(0.000000, 123.339996, 456.209991, 0.000000)
 505:   frc r27.yz, r27.yyzy
 506:   add r28.yz, r27.yyzy, l(0.000000, 34.345001, 34.345001, 0.000000)
 507:   dp2 r26.w, r27.yzyy, r28.yzyy
 508:   add r27.yz, r26.wwww, r27.yyzy
 509:   mul r26.w, r27.z, r27.y
 510:   add r27.y, r27.z, r27.y
 511:   frc r30.x, r26.w
 512:   frc r30.y, r27.y
 513:   mad r26.w, r24.w, l(0.400000), l(0.600000)
 514:   mul r27.y, r26.w, l(0.250000)
 515:   mad r24.xz, r17.yywy, l(20.000000, 0.000000, 20.000000, 0.000000), -r24.xxzx
 516:   mad r27.zw, r30.xxxy, l(0.000000, 0.000000, 2.000000, 2.000000), l(0.000000, 0.000000, -1.000000, -1.000000)
 517:   mad r24.xz, r27.zzwz, l(0.250000, 0.000000, 0.250000, 0.000000), r24.xxzx
 518:   add r24.xz, r24.xxzx, l(-0.500000, 0.000000, -0.500000, 0.000000)
 519:   mul r31.x, r24.x, l(1.250000)
 520:   lt r24.x, r24.z, l(0)
 521:   movc r24.x, r24.x, l(1.250000), l(0.750000)
 522:   mul r31.y, r24.x, r24.z
 523:   mad r18.y, r8.w, r18.y, r24.w
 524:   frc r24.x, r18.y
 525:   mov_sat r18.y, r18.y
 526:   mad r18.y, r18.y, l(0.630000), l(0.220000)
 527:   movc r18.y, r13.x, r24.x, r18.y
 528:   add r24.xz, r18.yyyy, l(-0.200000, 0.000000, -0.850000, 0.000000)
 529:   mul_sat r24.xz, r24.xxzx, l(50.000011, 0.000000, -3.333333, 0.000000)
 530:   mad r27.zw, r24.xxxz, l(0.000000, 0.000000, -2.000000, -2.000000), l(0.000000, 0.000000, 3.000000, 3.000000)
 531:   mul r24.xz, r24.xxzx, r24.xxzx
 532:   mul r24.xz, r24.xxzx, r27.zzwz
 533:   mul r18.y, r24.z, r24.x
 534:   dp2 r24.x, r31.xyxx, r31.xyxx
 535:   sqrt r24.x, r24.x
 536:   mad r24.x, -r26.w, l(0.250000), r24.x
 537:   div r24.z, l(1.000000, 1.000000, 1.000000, 1.000000), -r27.y
 538:   mul_sat r24.x, r24.z, r24.x
 539:   mad r24.z, r24.x, l(-2.000000), l(3.000000)
 540:   mul r24.x, r24.x, r24.x
 541:   mul r24.x, r24.x, r24.z
 542:   ge r24.x, r24.x, l(0.001000)
 543:   and r24.x, r24.x, l(1.000000)
 544:   mul r18.y, r18.y, r24.x
 545:   add r24.x, r26.z, l(-0.100000)
 546:   ge r24.x, r24.x, r23.x
 547:   and r24.x, r24.x, l(1.000000)
 548:   mul r18.y, r18.y, r24.x
 549:   mul r24.x, r21.x, r18.y
 550:   div r24.zw, r26.xxxy, r22.wwww
 551:   max r24.zw, r24.zzzw, l(0.000000, 0.000000, -1.000000, -1.000000)
 552:   min r24.zw, r24.zzzw, l(0.000000, 0.000000, 1.000000, 1.000000)
 553:   mad r26.x, r27.x, l(0.250000), l(0.250000)
 554:   mul r24.zw, r24.zzzw, r26.xxxx
 555:   mul r24.zw, r19.wwww, r24.zzzw
 556:   div r26.xy, r29.xyxx, r25.wwww
 557:   max r26.xy, r26.xyxx, l(-1.000000, -1.000000, 0.000000, 0.000000)
 558:   min r26.xy, r26.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 559:   mad r26.z, r28.x, l(0.250000), l(0.250000)
 560:   mul r26.xy, r26.zzzz, r26.xyxx
 561:   mul r26.xy, r21.wwww, r26.xyxx
 562:   mul r26.xy, r21.zzzz, r26.xyxx
 563:   mad r24.zw, r24.zzzw, r21.yyyy, r26.xxxy
 564:   div r26.xy, r31.xyxx, r27.yyyy
 565:   max r26.xy, r26.xyxx, l(-1.000000, -1.000000, 0.000000, 0.000000)
 566:   min r26.xy, r26.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 567:   mad r26.z, r30.x, l(0.250000), l(0.250000)
 568:   mul r26.xy, r26.zzzz, r26.xyxx
 569:   mul r26.xy, r18.yyyy, r26.xyxx
 570:   mad r24.zw, r26.xxxy, r21.xxxx, r24.zzzw
 571:   max r20.w, r20.w, r24.y
 572:   max r20.w, r20.w, r24.x
 573:   round_ni r26.xyzw, r25.yxyz
 574:   mul r28.xyzw, r26.xyzw, l(123.339996, 456.209991, 123.339996, 456.209991)
 575:   frc r28.xyzw, r28.xyzw
 576:   add r29.xyzw, r28.xyzw, l(34.345001, 34.345001, 34.345001, 34.345001)
 577:   dp2 r24.x, r28.xyxx, r29.xyxx
 578:   add r24.xy, r24.xxxx, r28.xyxx
 579:   mul r25.y, r24.y, r24.x
 580:   add r24.x, r24.y, r24.x
 581:   frc r24.y, r25.y
 582:   frc r24.x, r24.x
 583:   add r30.xyzw, r26.xyzw, l(114.514000, 114.514000, 114.514000, 114.514000)
 584:   mul r30.xyzw, r30.xyzw, l(123.339996, 456.209991, 123.339996, 456.209991)
 585:   frc r30.xyzw, r30.xyzw
 586:   add r31.xyzw, r30.xyzw, l(34.345001, 34.345001, 34.345001, 34.345001)
 587:   dp2 r25.y, r30.xyxx, r31.xyxx
 588:   add r27.xz, r25.yyyy, r30.xxyx
 589:   mul r25.y, r27.z, r27.x
 590:   add r27.x, r27.z, r27.x
 591:   frc r28.x, r25.y
 592:   frc r28.y, r27.x
 593:   mad r25.y, r24.y, l(0.400000), l(0.600000)
 594:   mul r27.x, r25.y, l(0.250000)
 595:   mad r26.xyzw, r17.xyzw, l(34.345600, 34.345600, 34.345600, 34.345600), -r26.xyzw
 596:   mad r27.zw, r28.xxxy, l(0.000000, 0.000000, 2.000000, 2.000000), l(0.000000, 0.000000, -1.000000, -1.000000)
 597:   mad r26.xy, r27.zwzz, l(0.250000, 0.250000, 0.000000, 0.000000), r26.xyxx
 598:   add r26.xy, r26.xyxx, l(-0.500000, -0.500000, 0.000000, 0.000000)
 599:   mul r29.x, r26.x, l(1.250000)
 600:   lt r17.x, r26.y, l(0)
 601:   movc r17.x, r17.x, l(1.250000), l(0.750000)
 602:   mul r29.y, r17.x, r26.y
 603:   mad r17.x, r8.w, r18.w, r24.y
 604:   frc r24.y, r17.x
 605:   mov_sat r17.x, r17.x
 606:   mad r17.x, r17.x, l(0.630000), l(0.220000)
 607:   movc r17.x, r13.x, r24.y, r17.x
 608:   add r26.xy, r17.xxxx, l(-0.200000, -0.850000, 0.000000, 0.000000)
 609:   mul_sat r26.xy, r26.xyxx, l(50.000011, -3.333333, 0.000000, 0.000000)
 610:   mad r27.zw, r26.xxxy, l(0.000000, 0.000000, -2.000000, -2.000000), l(0.000000, 0.000000, 3.000000, 3.000000)
 611:   mul r26.xy, r26.xyxx, r26.xyxx
 612:   mul r26.xy, r26.xyxx, r27.zwzz
 613:   mul r17.x, r26.y, r26.x
 614:   dp2 r24.y, r29.xyxx, r29.xyxx
 615:   sqrt r24.y, r24.y
 616:   mad r24.y, -r25.y, l(0.250000), r24.y
 617:   div r25.y, l(1.000000, 1.000000, 1.000000, 1.000000), -r27.x
 618:   mul_sat r24.y, r24.y, r25.y
 619:   mad r25.y, r24.y, l(-2.000000), l(3.000000)
 620:   mul r24.y, r24.y, r24.y
 621:   mul r24.y, r24.y, r25.y
 622:   ge r24.y, r24.y, l(0.001000)
 623:   and r24.y, r24.y, l(1.000000)
 624:   mul r17.x, r17.x, r24.y
 625:   add r24.x, r24.x, l(-0.100000)
 626:   ge r24.x, r24.x, r23.x
 627:   and r24.x, r24.x, l(1.000000)
 628:   mul r17.x, r17.x, r24.x
 629:   mul r24.x, r21.y, r17.x
 630:   dp2 r24.y, r28.zwzz, r29.zwzz
 631:   add r26.xy, r24.yyyy, r28.zwzz
 632:   mul r24.y, r26.y, r26.x
 633:   add r25.y, r26.y, r26.x
 634:   frc r24.y, r24.y
 635:   frc r25.y, r25.y
 636:   dp2 r26.x, r30.zwzz, r31.zwzz
 637:   add r26.xy, r26.xxxx, r30.zwzz
 638:   mul r27.z, r26.y, r26.x
 639:   add r26.x, r26.y, r26.x
 640:   frc r30.x, r27.z
 641:   frc r30.y, r26.x
 642:   mad r26.x, r24.y, l(0.400000), l(0.600000)
 643:   mul r26.y, r26.x, l(0.250000)
 644:   mad r27.zw, r30.xxxy, l(0.000000, 0.000000, 2.000000, 2.000000), l(0.000000, 0.000000, -1.000000, -1.000000)
 645:   mad r26.zw, r27.zzzw, l(0.000000, 0.000000, 0.250000, 0.250000), r26.zzzw
 646:   add r26.zw, r26.zzzw, l(0.000000, 0.000000, -0.500000, -0.500000)
 647:   mul r31.x, r26.z, l(1.250000)
 648:   lt r26.z, r26.w, l(0)
 649:   movc r26.z, r26.z, l(1.250000), l(0.750000)
 650:   mul r31.y, r26.z, r26.w
 651:   mad r24.y, r8.w, r18.w, r24.y
 652:   frc r26.z, r24.y
 653:   mov_sat r24.y, r24.y
 654:   mad r24.y, r24.y, l(0.630000), l(0.220000)
 655:   movc r24.y, r13.x, r26.z, r24.y
 656:   add r26.zw, r24.yyyy, l(0.000000, 0.000000, -0.200000, -0.850000)
 657:   mul_sat r26.zw, r26.zzzw, l(0.000000, 0.000000, 50.000011, -3.333333)
 658:   mad r27.zw, r26.zzzw, l(0.000000, 0.000000, -2.000000, -2.000000), l(0.000000, 0.000000, 3.000000, 3.000000)
 659:   mul r26.zw, r26.zzzw, r26.zzzw
 660:   mul r26.zw, r26.zzzw, r27.zzzw
 661:   mul r24.y, r26.w, r26.z
 662:   dp2 r26.z, r31.xyxx, r31.xyxx
 663:   sqrt r26.z, r26.z
 664:   mad r26.x, -r26.x, l(0.250000), r26.z
 665:   div r26.z, l(1.000000, 1.000000, 1.000000, 1.000000), -r26.y
 666:   mul_sat r26.x, r26.z, r26.x
 667:   mad r26.z, r26.x, l(-2.000000), l(3.000000)
 668:   mul r26.x, r26.x, r26.x
 669:   mul r26.x, r26.x, r26.z
 670:   ge r26.x, r26.x, l(0.001000)
 671:   and r26.x, r26.x, l(1.000000)
 672:   mul r24.y, r24.y, r26.x
 673:   add r25.y, r25.y, l(-0.100000)
 674:   ge r25.y, r25.y, r23.x
 675:   and r25.y, r25.y, l(1.000000)
 676:   mul r24.y, r24.y, r25.y
 677:   mul r25.y, r21.z, r24.y
 678:   round_ni r25.xz, r25.xxzx
 679:   mul r26.xz, r25.xxzx, l(123.339996, 0.000000, 456.209991, 0.000000)
 680:   frc r26.xz, r26.xxzx
 681:   add r27.zw, r26.xxxz, l(0.000000, 0.000000, 34.345001, 34.345001)
 682:   dp2 r26.w, r26.xzxx, r27.zwzz
 683:   add r26.xz, r26.wwww, r26.xxzx
 684:   mul r26.w, r26.z, r26.x
 685:   add r26.x, r26.z, r26.x
 686:   frc r26.xz, r26.xxwx
 687:   add r27.zw, r25.xxxz, l(0.000000, 0.000000, 114.514000, 114.514000)
 688:   mul r27.zw, r27.zzzw, l(0.000000, 0.000000, 123.339996, 456.209991)
 689:   frc r27.zw, r27.zzzw
 690:   add r28.yz, r27.zzwz, l(0.000000, 34.345001, 34.345001, 0.000000)
 691:   dp2 r26.w, r27.zwzz, r28.yzyy
 692:   add r27.zw, r26.wwww, r27.zzzw
 693:   mul r26.w, r27.w, r27.z
 694:   add r27.z, r27.w, r27.z
 695:   frc r32.x, r26.w
 696:   frc r32.y, r27.z
 697:   mad r26.w, r26.z, l(0.400000), l(0.600000)
 698:   mul r27.z, r26.w, l(0.250000)
 699:   mad r25.xz, r17.yywy, l(34.345600, 0.000000, 34.345600, 0.000000), -r25.xxzx
 700:   mad r28.yz, r32.xxyx, l(0.000000, 2.000000, 2.000000, 0.000000), l(0.000000, -1.000000, -1.000000, 0.000000)
 701:   mad r25.xz, r28.yyzy, l(0.250000, 0.000000, 0.250000, 0.000000), r25.xxzx
 702:   add r25.xz, r25.xxzx, l(-0.500000, 0.000000, -0.500000, 0.000000)
 703:   mul r33.x, r25.x, l(1.250000)
 704:   lt r25.x, r25.z, l(0)
 705:   movc r25.x, r25.x, l(1.250000), l(0.750000)
 706:   mul r33.y, r25.x, r25.z
 707:   mad r8.w, r8.w, r18.w, r26.z
 708:   frc r18.w, r8.w
 709:   mov_sat r8.w, r8.w
 710:   mad r8.w, r8.w, l(0.630000), l(0.220000)
 711:   movc r8.w, r13.x, r18.w, r8.w
 712:   add r25.xz, r8.wwww, l(-0.200000, 0.000000, -0.850000, 0.000000)
 713:   mul_sat r25.xz, r25.xxzx, l(50.000011, 0.000000, -3.333333, 0.000000)
 714:   mad r28.yz, r25.xxzx, l(0.000000, -2.000000, -2.000000, 0.000000), l(0.000000, 3.000000, 3.000000, 0.000000)
 715:   mul r25.xz, r25.xxzx, r25.xxzx
 716:   mul r25.xz, r25.xxzx, r28.yyzy
 717:   mul r8.w, r25.z, r25.x
 718:   dp2 r13.x, r33.xyxx, r33.xyxx
 719:   sqrt r13.x, r13.x
 720:   mad r13.x, -r26.w, l(0.250000), r13.x
 721:   div r18.w, l(1.000000, 1.000000, 1.000000, 1.000000), -r27.z
 722:   mul_sat r13.x, r13.x, r18.w
 723:   mad r18.w, r13.x, l(-2.000000), l(3.000000)
 724:   mul r13.x, r13.x, r13.x
 725:   mul r13.x, r13.x, r18.w
 726:   ge r13.x, r13.x, l(0.001000)
 727:   and r13.x, r13.x, l(1.000000)
 728:   mul r8.w, r8.w, r13.x
 729:   add r13.x, r26.x, l(-0.100000)
 730:   ge r13.x, r13.x, r23.x
 731:   and r13.x, r13.x, l(1.000000)
 732:   mul r8.w, r8.w, r13.x
 733:   mul r13.x, r21.x, r8.w
 734:   div r25.xz, r29.xxyx, r27.xxxx
 735:   max r25.xz, r25.xxzx, l(-1.000000, 0.000000, -1.000000, 0.000000)
 736:   min r25.xz, r25.xxzx, l(1.000000, 0.000000, 1.000000, 0.000000)
 737:   mad r18.w, r28.x, l(0.250000), l(0.250000)
 738:   mul r25.xz, r18.wwww, r25.xxzx
 739:   mul r25.xz, r17.xxxx, r25.xxzx
 740:   div r26.xy, r31.xyxx, r26.yyyy
 741:   max r26.xy, r26.xyxx, l(-1.000000, -1.000000, 0.000000, 0.000000)
 742:   min r26.xy, r26.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 743:   mad r17.x, r30.x, l(0.250000), l(0.250000)
 744:   mul r26.xy, r17.xxxx, r26.xyxx
 745:   mul r26.xy, r24.yyyy, r26.xyxx
 746:   mul r26.xy, r21.zzzz, r26.xyxx
 747:   mad r25.xz, r25.xxzx, r21.yyyy, r26.xxyx
 748:   div r26.xy, r33.xyxx, r27.zzzz
 749:   max r26.xy, r26.xyxx, l(-1.000000, -1.000000, 0.000000, 0.000000)
 750:   min r26.xy, r26.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 751:   mad r17.x, r32.x, l(0.250000), l(0.250000)
 752:   mul r26.xy, r17.xxxx, r26.xyxx
 753:   mul r26.xy, r8.wwww, r26.xyxx
 754:   mad r25.xz, r26.xxyx, r21.xxxx, r25.xxzx
 755:   max r8.w, r24.x, r25.y
 756:   max r8.w, r8.w, r13.x
 757:   mul r13.x, r19.w, r22.w
 758:   mul r13.x, r21.y, r13.x
 759:   mul r17.x, r21.w, r25.w
 760:   mul r17.x, r21.z, r17.x
 761:   mul r18.y, r18.y, r27.y
 762:   mul r18.y, r21.x, r18.y
 763:   max r17.x, r17.x, r18.y
 764:   max r13.x, r13.x, r17.x
 765:   ge r13.x, l(0.010000), r13.x
 766:   and r13.x, r13.x, l(1.000000)
 767:   mad r18.yw, r25.xxxz, r13.xxxx, r24.zzzw
 768:   mad r18.yw, r22.xxxy, l(0.000000, 2.000000, 0.000000, 2.000000), r18.yyyw
 769:   add r18.yw, r18.yyyw, l(0.000000, -1.000000, 0.000000, -1.000000)
 770:   mul r17.x, cb1[20].x, cb1[120].z
 771:   mul r21.y, r17.x, l(0.750000)
 772:   dp2 r17.x, r18.xzxx, r18.xzxx
 773:   max r17.x, r17.x, l(0.000000)
 774:   rsq r17.x, r17.x
 775:   mul r24.x, r17.x, v7.x
 776:   mov r24.y, l(0)
 777:   mul r24.z, r17.x, r18.z
 778:   add r22.xyw, abs(r24.xyxz), l(-0.200000, -0.200000, 0.000000, -0.200000)
 779:   mul r24.xyz, r22.xywx, r22.xywx
 780:   mul r22.xyw, r22.xyxw, r24.xyxz
 781:   max r22.xyw, r22.xyxw, l(0.000061, 0.000061, 0.000000, 0.000061)
 782:   dp3 r17.x, r22.xywx, l(1.000000, 1.000000, 1.000000, 0.000000)
 783:   div r18.xz, r22.xxwx, r17.xxxx
 784:   sample_b(texture2d)(float,float,float,float) r22.xyw, r17.zwzz, t14.xywz, s1, cb1[26].x
 785:   sample_b(texture2d)(float,float,float,float) r17.xyz, r17.ywyy, t14.xyzw, s1, cb1[26].x
 786:   mul r17.xyz, r18.xxxx, r17.xyzx
 787:   mad r17.xyz, r22.xywx, r18.zzzz, r17.xyzx
 788:   mad r17.xy, r17.xyxx, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
 789:   mov r21.x, l(0)
 790:   mad r21.xyzw, r15.zwyw, cb1[120].zzzz, r21.xyxy
 791:   sample_b(texture2d)(float,float,float,float) r15.y, r21.xyxx, t14.xwyz, s1, cb1[26].x
 792:   sample_b(texture2d)(float,float,float,float) r15.z, r21.zwzz, t14.xywz, s1, cb1[26].x
 793:   mul r15.z, r18.x, r15.z
 794:   mad r15.y, r15.y, r18.z, r15.z
 795:   mul r15.yz, r15.yyyy, r17.xxyx
 796:   mad r18.xy, r15.yzyy, r16.wwww, r18.ywyy
 797:   ge r15.y, r20.w, l(0.010000)
 798:   and r15.y, r15.y, l(1.000000)
 799:   mul r15.y, r15.y, r20.w
 800:   mul r8.w, r8.w, r13.x
 801:   max r8.w, r8.w, r15.y
 802:   ge r13.x, r22.z, r23.w
 803:   and r13.x, r13.x, l(1.000000)
 804:   max r8.w, r8.w, r13.x
 805:   add r13.x, -r17.z, l(1.000000)
 806:   mad r13.x, r15.x, r14.x, -r13.x
 807:   mul_sat r13.x, r13.x, l(9.999998)
 808:   mad r14.x, r13.x, l(-2.000000), l(3.000000)
 809:   mul r13.x, r13.x, r13.x
 810:   mul r13.x, r13.x, r14.x
 811:   mul r13.x, r16.w, r13.x
 812:   max r8.w, r8.w, r13.x
 813:   dp2 r13.x, r18.xyxx, r18.xyxx
 814:   min r13.x, r13.x, l(1.000000)
 815:   add r13.x, -r13.x, l(1.000000)
 816:   sqrt r13.x, r13.x
 817:   max r18.z, r13.x, l(0.000000)
 818:   dp3 r13.x, r18.xyzx, r18.xyzx
 819:   rsq r13.x, r13.x
 820:   mul r15.xyz, r13.xxxx, r18.xyzx
 821:   mad r17.xy, -r11.zyzz, l(1.000000, 0.000000, 0.000000, 0.000000), r23.yzyy
 822:   dp2 r13.x, r17.xyxx, r17.xyxx
 823:   lt r14.x, l(0.000061), r13.x
 824:   rsq r13.x, r13.x
 825:   mul r17.xy, r13.xxxx, r17.xyxx
 826:   movc r18.y, r14.x, r17.x, l(1.000000)
 827:   and r18.x, r14.x, r17.y
 828:   min r13.x, r3.z, l(0.050000)
 829:   add r14.x, -r3.z, r13.x
 830:   mad r14.x, r8.w, r14.x, r3.z
 831:   mad r13.z, -r14.y, r13.z, l(1.000000)
 832:   mul r13.z, r4.w, r13.z
 833:   mad r7.w, -r7.w, r14.z, l(1.000000)
 834:   mul r7.w, r7.w, r13.z
 835:   mad r7.w, r7.w, l(-0.500000), l(1.000000)
 836:   mov r18.z, l(0)
 837:   mul r17.xyz, r11.yzxy, r18.xyzx
 838:   mad r17.xyz, r18.zxyz, r11.zxyz, -r17.xyzx
 839:   mul r17.xyz, r15.yyyy, r17.xyzx
 840:   mad r15.xyw, r18.yzyx, r15.xxxx, r17.xyxz
 841:   mad r15.xyz, r11.xyzx, r15.zzzz, r15.xywx
 842:   dp3 r13.z, r15.xyzx, r15.xyzx
 843:   rsq r13.z, r13.z
 844:   mad r15.xyz, r15.xyzx, r13.zzzz, -r11.xyzx
 845:   mad r15.xyz, r8.wwww, r15.xyzx, r11.xyzx
 846:   dp3 r13.z, r15.xyzx, r15.xyzx
 847:   rsq r13.z, r13.z
 848:   mul r15.xyz, r13.zzzz, r15.xyzx
 849:   mul r4.w, r14.z, r4.w
 850:   mad r4.w, -r4.w, l(0.200000), r14.x
 851:   min r13.z, r14.x, l(0.200000)
 852:   max r3.z, r4.w, r13.z
 853:   mul r9.xyz, r7.wwww, r9.xyzx
 854:   dp3 r4.w, r6.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 855:   add r4.w, r4.w, l(-0.700000)
 856:   mul_sat r4.w, r4.w, l(-2.500000)
 857:   mad r13.z, r4.w, l(-2.000000), l(3.000000)
 858:   mul r4.w, r4.w, r4.w
 859:   mul r4.w, r4.w, r13.z
 860:   mad r4.w, r4.w, l(0.500000), l(1.000000)
 861:   mul r13.y, r13.y, r8.w
 862:   mad r14.xyz, r6.xyzx, r4.wwww, -r6.xyzx
 863:   mad r14.xyz, r13.yyyy, r14.xyzx, r6.xyzx
 864:   mul r6.xyz, r7.wwww, r14.xyzx
 865:   mov r4.w, r8.w
 866: else
 867:   mov r15.xyz, r11.xyzx
 868:   mov r4.w, l(0)
 869:   mov r13.x, l(0.010000)
 870:   mov r8.w, l(0)
 871: endif
 872: mad r7.w, r13.w, l(0.003922), -cb6[5].x
 873: lt r7.w, l(0.010000), r7.w
 874: if_nz r7.w
 875:   mul r14.xyz, v8.xzyx, l(1.000000, 1.000000, -1.000000, 0.000000)
 876:   movc r14.xyz, r3.yyyy, r14.xyzx, v8.xyzx
 877:   mul r17.xyz, r14.xyzx, cb1[120].zzzz
 878:   movc r18.yz, r3.yyyy, v7.zzyz, v7.yyzy
 879:   mov r18.x, v7.x
 880:   add r18.xzw, abs(r18.xxyz), l(-0.200000, 0.000000, -0.200000, -0.200000)
 881:   mul r21.xyz, r18.xzwx, r18.xzwx
 882:   mul r18.xzw, r18.xxzw, r21.xxyz
 883:   max r18.xzw, r18.xxzw, l(0.000061, 0.000000, 0.000061, 0.000061)
 884:   dp3 r7.w, r18.xzwx, l(1.000000, 1.000000, 1.000000, 0.000000)
 885:   div r18.xzw, r18.xxzw, r7.wwww
 886:   sample_b(texture2d)(float,float,float,float) r21.xyzw, r17.xzxx, t15.xyzw, s1, cb1[26].x
 887:   sample_b(texture2d)(float,float,float,float) r22.xyzw, r17.xyxx, t15.xyzw, s1, cb1[26].x
 888:   mul r22.xyzw, r18.wwww, r22.xyzw
 889:   mad r21.xyzw, r21.xyzw, r18.zzzz, r22.xyzw
 890:   sample_b(texture2d)(float,float,float,float) r17.xyzw, r17.zyzz, t15.xyzw, s1, cb1[26].x
 891:   mad r17.xyzw, r17.xyzw, r18.xxxx, r21.xyzw
 892:   add r7.w, r14.y, l(-0.350000)
 893:   mul_sat r7.w, r7.w, l(-6.666667)
 894:   mad r13.y, r7.w, l(-2.000000), l(3.000000)
 895:   mul r7.w, r7.w, r7.w
 896:   mul r7.w, r7.w, r13.y
 897:   mul r13.y, r13.w, l(0.011765)
 898:   min r13.y, r13.y, l(1.000000)
 899:   mad r7.w, r7.w, r13.y, r14.w
 900:   min r7.w, r7.w, l(1.000000)
 901:   add r13.y, -r7.w, l(2.000000)
 902:   mad r13.y, -r7.w, r13.y, l(2.000000)
 903:   mad r13.z, r18.y, l(0.650000), r17.z
 904:   add r13.z, r13.z, l(0.350000)
 905:   add r13.y, -r13.y, r13.z
 906:   mul_sat r13.y, r13.y, l(2.857144)
 907:   mad r13.z, r13.y, l(-2.000000), l(3.000000)
 908:   mul r13.y, r13.y, r13.y
 909:   mul r13.y, r13.y, r13.z
 910:   mul r13.z, r7.z, r7.z
 911:   and r13.w, v10.x, l(1.000000)
 912:   mul r13.z, r13.w, r13.z
 913:   mul r13.y, r13.z, r13.y
 914:   add r13.z, -r7.x, l(1.000000)
 915:   mul r14.xyz, r6.xyzx, r13.zzzz
 916:   dp3 r13.z, r14.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
 917:   add r13.z, r13.z, l(-0.350000)
 918:   mul_sat r13.z, r13.z, l(-4.000000)
 919:   mad r13.w, r13.z, l(-2.000000), l(3.000000)
 920:   mul r13.z, r13.z, r13.z
 921:   mad r13.z, -r13.w, r13.z, l(1.000000)
 922:   mul r7.w, r7.w, r13.z
 923:   mul r7.w, r17.w, r7.w
 924:   mad r13.z, r18.y, l(0.250000), l(0.750000)
 925:   mul r7.w, r7.w, r13.z
 926:   mad r7.w, r7.w, l(-0.500000), l(1.000000)
 927:   mad r13.zw, r17.xxxy, l(0.000000, 0.000000, 2.000000, 2.000000), l(0.000000, 0.000000, -1.000000, -1.000000)
 928:   dp2 r14.x, r13.zwzz, r13.zwzz
 929:   min r14.x, r14.x, l(1.000000)
 930:   add r14.x, -r14.x, l(1.000000)
 931:   sqrt r14.x, r14.x
 932:   max r14.z, r14.x, l(0.000000)
 933:   add r14.xy, r13.zwzz, r13.zwzz
 934:   add r14.xyz, r14.xyzx, l(-0.000000, -0.000000, -1.000000, 0.000000)
 935:   mad r14.xyz, r13.yyyy, r14.xyzx, l(0.000000, 0.000000, 1.000000, 0.000000)
 936:   dp3 r13.z, r14.xyzx, r14.xyzx
 937:   max r13.z, r13.z, l(0.000061)
 938:   rsq r13.z, r13.z
 939:   mul r14.xyz, r13.zzzz, r14.xyzx
 940:   mad r13.z, -r11.y, r11.y, l(1.000000)
 941:   ge r13.z, r13.z, l(0.010000)
 942:   and r17.y, r13.z, l(1.000000)
 943:   mad r3.w, r5.y, r3.w, -r11.z
 944:   mad r3.w, r17.y, r3.w, r11.z
 945:   movc r17.z, r13.z, l(0), l(1.000000)
 946:   mov r17.x, l(0)
 947:   mad r17.xyz, -r11.xyzx, r3.wwww, r17.xyzx
 948:   mad r3.w, -r3.w, r3.w, l(1.000000)
 949:   max r3.w, r3.w, l(0.000100)
 950:   rsq r3.w, r3.w
 951:   mul r17.xyz, r3.wwww, r17.xyzx
 952:   mul r18.xyz, r11.yzxy, r17.zxyz
 953:   mad r18.xyz, r17.yzxy, r11.zxyz, -r18.xyzx
 954:   mul r17.xyz, r14.yyyy, r17.xyzx
 955:   mad r14.xyw, r18.xyxz, r14.xxxx, r17.xyxz
 956:   mad r14.xyz, r11.xyzx, r14.zzzz, r14.xywx
 957:   mul r17.xyz, r6.xyzx, r7.wwww
 958:   mad r18.xyz, -r6.xyzx, r7.wwww, l(0.880000, 0.880000, 0.880000, 0.000000)
 959:   mad r6.xyz, r13.yyyy, r18.xyzx, r17.xyzx
 960:   mad r7.x, r13.y, -r7.x, r7.x
 961:   mul r17.xyz, r7.wwww, r9.xyzx
 962:   mad r18.xyz, -r9.xyzx, r7.wwww, l(0.308000, 0.308000, 0.308000, 0.000000)
 963:   mad r9.xyz, r13.yyyy, r18.xyzx, r17.xyzx
 964:   mul r3.w, r13.y, l(4.000000)
 965:   min r3.w, r3.w, l(1.000000)
 966:   add r5.y, -r3.z, l(0.900000)
 967:   mad r3.z, r3.w, r5.y, r3.z
 968: else
 969:   mov r14.xyz, r11.xyzx
 970: endif
 971: mul r17.xyzw, cb6[16].zzzw, cb6[22].xyzw
 972: lt r3.w, cb6[16].y, l(1.500000)
 973: if_nz r3.w
 974:   add r13.yz, -v1.xxyx, v1.zzwz
 975:   mad r18.xy, cb6[16].yyyy, r13.yzyy, v1.xyxx
 976: else
 977:   lt r3.w, cb6[16].y, l(2.500000)
 978:   if_nz r3.w
 979:     movc r18.yz, r3.yyyy, v8.zzyz, v8.yyzy
 980:     mov r18.w, v8.x
 981:     dp3 r3.w, r18.yzwy, r18.yzwy
 982:     max r3.w, r3.w, l(0.000000)
 983:     rsq r3.w, r3.w
 984:     mul r13.yz, r3.wwww, r18.wwzw
 985:     div r3.w, r13.z, r13.y
 986:     lt r5.y, abs(r3.w), l(1.000000)
 987:     div r7.w, l(1.000000, 1.000000, 1.000000, 1.000000), abs(r3.w)
 988:     movc r7.w, r5.y, abs(r3.w), r7.w
 989:     mul r13.w, r7.w, r7.w
 990:     mad r14.w, r13.w, l(0.087293), l(-0.301895)
 991:     mad r13.w, r14.w, r13.w, l(1.000000)
 992:     mul r14.w, r7.w, r13.w
 993:     mad r7.w, -r13.w, r7.w, l(1.570796)
 994:     movc r5.y, r5.y, r14.w, r7.w
 995:     lt r3.w, r3.w, l(0)
 996:     movc r3.w, r3.w, -r5.y, r5.y
 997:     ge r5.y, r13.z, l(0)
 998:     movc r5.y, r5.y, l(3.141593), l(-3.141593)
 999:     lt r7.w, r13.y, l(0)
1000:     and r7.w, r7.w, l(1.000000)
1001:     mad r3.w, r5.y, r7.w, r3.w
1002:     mad r18.x, r3.w, l(0.159155), l(0.500000)
1003:   else
1004:     utof r13.yz, r12.xxyx
1005:     div r13.yz, r13.yyzy, cb1[5].xxyx
1006:     mad r21.xy, r13.yzyy, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
1007:     div r3.w, r21.y, cb1[5].x
1008:     mul r21.z, r3.w, cb1[5].y
1009:     mov r0.w, cb0[3].z
1010:     mov r22.xyz, cb2[r3.x + 3].xyzx
1011:     mov r22.w, l(1.000000)
1012:     dp4 r3.w, r0.xyzw, r22.xyzw
1013:     add r3.w, -r3.w, -cb1[3].y
1014:     max r3.w, r3.w, l(0)
1015:     add r3.w, r3.w, l(-1.000000)
1016:     mad r3.w, cb6[18].w, r3.w, l(1.000000)
1017:     mul r18.xy, r3.wwww, r21.xzxx
1018:   endif
1019: endif
1020: lt r13.yz, l(0.000000, 0.500000, 0.500000, 0.000000), cb6[17].xxzx
1021: lt r3.w, cb6[17].y, l(1.500000)
1022: if_nz r3.w
1023:   add r18.zw, -v1.xxxy, v1.zzzw
1024:   mad r21.xy, cb6[17].yyyy, r18.zwzz, v1.xyxx
1025: else
1026:   lt r3.w, cb6[17].y, l(2.500000)
1027:   if_nz r3.w
1028:     movc r21.yz, r3.yyyy, v8.zzyz, v8.yyzy
1029:     mov r21.w, v8.x
1030:     dp3 r3.y, r21.yzwy, r21.yzwy
1031:     max r3.y, r3.y, l(0.000000)
1032:     rsq r3.y, r3.y
1033:     mul r3.yw, r3.yyyy, r21.wwwz
1034:     div r5.y, r3.w, r3.y
1035:     lt r7.w, abs(r5.y), l(1.000000)
1036:     div r13.w, l(1.000000, 1.000000, 1.000000, 1.000000), abs(r5.y)
1037:     movc r13.w, r7.w, abs(r5.y), r13.w
1038:     mul r14.w, r13.w, r13.w
1039:     mad r15.w, r14.w, l(0.087293), l(-0.301895)
1040:     mad r14.w, r15.w, r14.w, l(1.000000)
1041:     mul r15.w, r13.w, r14.w
1042:     mad r13.w, -r14.w, r13.w, l(1.570796)
1043:     movc r7.w, r7.w, r15.w, r13.w
1044:     lt r5.y, r5.y, l(0)
1045:     movc r5.y, r5.y, -r7.w, r7.w
1046:     ge r3.w, r3.w, l(0)
1047:     movc r3.w, r3.w, l(3.141593), l(-3.141593)
1048:     lt r3.y, r3.y, l(0)
1049:     and r3.y, r3.y, l(1.000000)
1050:     mad r3.y, r3.w, r3.y, r5.y
1051:     mad r21.x, r3.y, l(0.159155), l(0.500000)
1052:   else
1053:     utof r3.yw, r12.xxxy
1054:     div r3.yw, r3.yyyw, cb1[5].xxxy
1055:     mad r22.xy, r3.ywyy, l(2.000000, 2.000000, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
1056:     div r3.y, r22.y, cb1[5].x
1057:     mul r22.z, r3.y, cb1[5].y
1058:     mov r0.w, cb0[3].z
1059:     mov r23.xyz, cb2[r3.x + 3].xyzx
1060:     mov r23.w, l(1.000000)
1061:     dp4 r0.w, r0.xyzw, r23.xyzw
1062:     add r0.w, -r0.w, -cb1[3].y
1063:     max r0.w, r0.w, l(0)
1064:     add r0.w, r0.w, l(-1.000000)
1065:     mad r0.w, cb6[18].w, r0.w, l(1.000000)
1066:     mul r21.xy, r0.wwww, r22.xzxx
1067:   endif
1068: endif
1069: movc r3.xy, r13.yyyy, r21.xyxx, r18.xyxx
1070: mad r3.xy, cb6[19].zwzz, cb1[105].wwww, r3.xyxx
1071: mad r3.xy, r3.xyxx, cb6[24].xyxx, cb6[24].zwzz
1072: sample_l(texture2d)(float,float,float,float) r21.xyzw, r3.xyxx, t22.xyzw, s1, l(0)
1073: mad r3.xy, cb6[18].zzzz, r21.xxxx, r18.xyxx
1074: mad r3.xy, cb6[19].xyxx, cb1[105].wwww, r3.xyxx
1075: mad r3.xy, r3.xyxx, cb6[23].xyxx, cb6[23].zwzz
1076: sample_l(texture2d)(float,float,float,float) r18.xyzw, r3.xyxx, t21.xyzw, s1, l(0)
1077: mov r3.x, l(1.000000)
1078: mov r3.w, r18.x
1079: add r22.xyzw, -r18.xyzw, r3.xxxw
1080: mad r18.xyzw, cb6[16].xxxx, r22.xyzw, r18.xyzw
1081: mul r22.xyzw, r17.xyzw, r18.xyzw
1082: mad r0.w, cb6[18].y, l(2.020000), l(-1.010000)
1083: add r0.w, -r0.w, r21.x
1084: mov_sat r3.x, -r0.w
1085: mov_sat r0.w, r0.w
1086: mul r0.w, r0.w, r22.w
1087: movc r3.y, r13.z, r0.w, l(1.000000)
1088: mul r3.y, r3.y, r6.w
1089: lt r3.w, cb6[18].x, l(0.500000)
1090: movc r13.yzw, r3.wwww, v3.xxyz, r14.xxyz
1091: dp3 r3.w, r2.yzwy, r13.yzwy
1092: add_sat r3.w, r3.w, cb6[15].x
1093: log r3.w, r3.w
1094: mul r3.w, r3.w, cb6[15].z
1095: exp r3.w, r3.w
1096: add r5.y, -r3.w, l(1.000000)
1097: add r3.w, r3.w, -r5.y
1098: mad r3.w, cb6[15].w, r3.w, r5.y
1099: mad r5.y, -r7.x, l(0.960000), l(0.960000)
1100: mul r13.yzw, r5.yyyy, r6.xxyz
1101: mul r6.w, r7.y, l(0.040000)
1102: mad r17.xyz, -r7.yyyy, l(0.040000, 0.040000, 0.040000, 0.000000), r6.xyzx
1103: mad r17.xyz, r7.xxxx, r17.xyzx, r6.wwww
1104: mul r9.xyz, r5.yyyy, r9.xyzx
1105: mul r6.w, r3.z, r3.z
1106: max r6.w, r6.w, l(0.007813)
1107: mul r7.y, r6.w, r6.w
1108: max r7.w, v5.z, l(0.000000)
1109: div r18.xy, v5.xyxx, r7.wwww
1110: max r7.w, v6.z, l(0.000000)
1111: div r23.xy, v6.xyxx, r7.wwww
1112: add r18.xy, r18.xyxx, -r23.xyxx
1113: mul r23.xy, r18.xyxx, l(0.500000, -0.500000, 0.000000, 0.000000)
1114: sqrt r23.xy, abs(r23.xyxx)
1115: sqrt r23.xy, r23.xyxx
1116: mov r18.z, -r18.y
1117: lt r23.zw, l(0, 0, 0, 0), r18.xxxz
1118: lt r18.xy, r18.xzxx, l(0, 0, 0, 0)
1119: iadd r18.xy, -r23.zwzz, r18.xyxx
1120: itof r18.xy, r18.xyxx
1121: mul r18.xy, r18.xyxx, r23.xyxx
1122: mad o1.xy, r18.xyxx, l(0.500000, 0.500000, 0.000000, 0.000000), l(0.500000, 0.500000, 0.000000, 0.000000)
1123: lt r7.w, l(0.100000), r8.w
1124: movc o1.w, r7.w, l(0.700000), l(0.400000)
1125: add r18.xyz, cb1[121].xyzx, cb3[0].xyzx
1126: mad r23.xyz, cb1[111].wwww, r18.xyzx, -cb3[0].xyzx
1127: mov r23.w, l(0.000061)
1128: dp3 r7.w, r23.xzwx, r23.xzwx
1129: rsq r7.w, r7.w
1130: mul r18.xyz, r7.wwww, r23.xwzx
1131: add r24.xyzw, cb1[115].xyzw, -cb3[3].xyzw
1132: mad r24.xyzw, cb1[122].yyyw, r24.xyzw, cb3[3].xyzw
1133: mul r25.xyz, r24.wwww, r24.xyzx
1134: mov r12.z, l(0)
1135: ld_indexable(texture2d)(float,float,float,float) r26.xy, r12.xyzz, t4.xyzw
1136: add r7.w, r26.x, l(-1.000000)
1137: mad r7.w, cb5[34].x, r7.w, l(1.000000)
1138: add r8.w, -r7.w, l(1.000000)
1139: mad r7.w, cb1[111].z, r8.w, r7.w
1140: dp3 r8.w, r14.xyzx, r23.xyzx
1141: mul r26.xzw, r9.xxyz, cb1[110].zzzz
1142: mul r27.xyz, r26.xzwx, l(0.650000, 0.650000, 0.650000, 0.000000)
1143: dp3 r12.z, r13.yzwy, l(0.212673, 0.715152, 0.072175, 0.000000)
1144: dp2 r14.w, cb0[6].xzxx, cb0[6].xzxx
1145: rsq r14.w, r14.w
1146: mul r28.xy, r14.wwww, cb0[6].xzxx
1147: dp2 r14.w, r18.xzxx, r28.xyxx
1148: mov_sat r14.w, -r14.w
1149: add r28.xy, l(1.000000, 1.000000, 0.000000, 0.000000), -cb1[122].xyxx
1150: mad r15.w, r8.w, l(0.500000), l(-1.000000)
1151: mad r15.w, -r8.w, r15.w, -r8.w
1152: add r16.w, l(0.750000), -abs(cb0[6].y)
1153: add_sat r16.w, r16.w, r16.w
1154: mad r19.w, r16.w, l(-2.000000), l(3.000000)
1155: mul r16.w, r16.w, r16.w
1156: mul r16.w, r16.w, r19.w
1157: mul r16.w, r14.w, r16.w
1158: mul r16.w, r28.x, r16.w
1159: add r15.w, r15.w, l(0.500000)
1160: mad r8.w, r16.w, r15.w, r8.w
1161: mad r8.w, cb1[121].w, cb1[122].x, r8.w
1162: max r8.w, r8.w, l(-1.000000)
1163: min r8.w, r8.w, l(1.000000)
1164: mad r29.x, r8.w, l(0.500000), l(0.500000)
1165: mov r29.yw, l(0.000000, 0.500000, 0.000000, 0.500000)
1166: sample_l(texture2d)(float,float,float,float) r30.xyzw, r29.xyxx, t11.xyzw, s0, l(0)
1167: max r8.w, r30.y, r30.x
1168: max r8.w, r30.z, r8.w
1169: min r15.w, r30.y, r30.x
1170: min r15.w, r30.z, r15.w
1171: add r8.w, r8.w, -r15.w
1172: dp3 r15.w, r14.xyzx, cb0[6].xyzx
1173: mad r29.z, r15.w, l(0.500000), l(0.500000)
1174: sample_l(texture2d)(float,float,float,float) r15.w, r29.zwzz, t11.xyzw, s0, l(0)
1175: mul r16.w, r7.z, r26.y
1176: min r19.w, r7.z, r26.y
1177: min r20.w, r30.w, r19.w
1178: mul r22.w, r15.w, r16.w
1179: dp3 r11.x, r11.xyzx, cb1[116].xyzx
1180: add_sat r11.x, r11.x, cb1[117].x
1181: mad r11.x, r11.x, cb1[117].y, cb1[117].z
1182: mul r11.y, r20.w, cb1[111].y
1183: add r29.xyz, -r16.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
1184: mad r29.xyz, r11.yyyy, r29.xyzx, r16.xyzx
1185: mul r11.xyz, r11.xxxx, r29.xyzx
1186: mad r23.w, r9.w, l(0.350000), l(0.650000)
1187: min r23.w, r23.w, l(1.500000)
1188: max r29.xyz, r9.wwww, l(1.250000, 0.000000, 0.500000, 0.000000)
1189: min r29.xyz, r29.xyzx, l(1.750000, 1.500000, 1.500000, 0.000000)
1190: add r9.w, -r23.w, r29.x
1191: mad r9.w, cb1[111].x, r9.w, r23.w
1192: mul r31.xyz, r9.wwww, r11.xyzx
1193: mul r31.xyz, r31.xyzx, cb1[110].wwww
1194: dp3 r9.w, r25.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1195: mad r25.xyz, r24.xyzx, r24.wwww, -r9.wwww
1196: mad r25.xyz, r20.wwww, r25.xyzx, r9.wwww
1197: mul r11.xyz, r11.xyzx, r29.yyyy
1198: mad r28.yzw, r24.xxyz, cb1[122].yyyy, r28.yyyy
1199: mad r11.xyz, r11.xyzx, r28.yzwy, r25.xyzx
1200: mad r11.xyz, r11.xyzx, cb1[110].yyyy, -r31.xyzx
1201: mad r11.xyz, r7.wwww, r11.xyzx, r31.xyzx
1202: dp3 r9.w, r27.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1203: mad r25.xyz, r26.xzwx, l(0.650000, 0.650000, 0.650000, 0.000000), -r9.wwww
1204: mad r25.xyz, r25.xyzx, l(1.200000, 1.200000, 1.200000, 0.000000), r9.wwww
1205: mad_sat r9.w, r15.w, r16.w, r30.w
1206: mad r27.xyz, r9.xyzx, cb1[110].zzzz, -r25.xyzx
1207: mad r25.xyz, r9.wwww, r27.xyzx, r25.xyzx
1208: mad r27.xyz, r6.xyzx, r5.yyyy, -r25.xyzx
1209: mad r25.xyz, r20.wwww, r27.xyzx, r25.xyzx
1210: add r9.w, -r8.w, l(1.000000)
1211: mad r27.xyz, r30.xyzx, r8.wwww, r9.wwww
1212: mul r27.xyz, r25.xyzx, r27.xyzx
1213: mad r28.yzw, r6.xxyz, r5.yyyy, -r12.zzzz
1214: mad r28.yzw, r28.yyzw, l(0.000000, 1.200000, 1.200000, 1.200000), r12.zzzz
1215: mad r28.yzw, -r9.xxyz, cb1[110].zzzz, r28.yyzw
1216: mad r26.xzw, r22.wwww, r28.yyzw, r26.xxzw
1217: dp3 r8.w, r25.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1218: dp3 r9.w, r27.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1219: max r9.w, r9.w, l(0.001000)
1220: div r9.w, l(1.000000, 1.000000, 1.000000, 1.000000), r9.w
1221: mul r8.w, r8.w, r9.w
1222: max r8.w, r8.w, l(0)
1223: min r8.w, r8.w, l(1.500000)
1224: mad r25.xyz, r27.xyzx, r8.wwww, -r26.xzwx
1225: mad r25.xyz, r7.wwww, r25.xyzx, r26.xzwx
1226: mad r8.w, -r15.w, r16.w, r20.w
1227: mad r8.w, r7.w, r8.w, r22.w
1228: add r9.w, l(1.000000), -cb1[110].z
1229: mad r9.w, r8.w, r9.w, cb1[110].z
1230: add r15.w, r23.y, l(-0.500000)
1231: mad r27.y, r7.w, r15.w, l(0.500000)
1232: dp3_sat r30.x, r15.xyzx, r2.yzwy
1233: mov r27.xz, cb0[6].xxzx
1234: dp3 r15.w, r27.xyzx, r27.xyzx
1235: max r15.w, r15.w, l(0.000000)
1236: rsq r15.w, r15.w
1237: mul r26.xzw, r15.wwww, r27.xxyz
1238: add r26.xzw, r26.xxzw, r26.xxzw
1239: mad r23.xyz, r23.xyzx, r7.wwww, r26.xzwx
1240: add r15.w, r7.w, l(2.000000)
1241: mad r23.xyz, r2.yzwy, r15.wwww, r23.xyzx
1242: dp3 r15.w, r23.xyzx, r23.xyzx
1243: rsq r15.w, r15.w
1244: mul r23.xyz, r15.wwww, r23.xyzx
1245: dp3 r15.w, r15.xyzx, r23.xyzx
1246: mad r16.w, r15.w, r7.y, -r15.w
1247: mad r15.w, r16.w, r15.w, l(1.000000)
1248: mul r15.w, r15.w, r15.w
1249: ne r16.w, r7.y, r15.w
1250: div r7.y, r7.y, r15.w
1251: movc r7.y, r16.w, r7.y, l(1.000000)
1252: mul r23.x, r30.x, r30.x
1253: mad r15.w, r6.w, r6.w, l(0.000100)
1254: div r15.w, l(1.000000, 1.000000, 1.000000, 1.000000), r15.w
1255: div r15.w, r7.y, r15.w
1256: mad r16.w, r30.x, r30.x, -r15.w
1257: mad r27.x, cb6[1].x, r16.w, r15.w
1258: add r15.w, -r7.x, l(1.000000)
1259: mul r27.y, r3.z, r15.w
1260: sample_l(texture2d)(float,float,float,float) r26.xzw, r27.xyxx, t12.xwyz, s0, l(0)
1261: mul r27.xyz, r17.xyzx, r26.xzwx
1262: mad r26.xzw, r17.xxyz, r26.xxzw, -r17.xxyz
1263: mad r17.xyz, cb6[1].xxxx, r26.xzwx, r17.xyzx
1264: add r15.w, l(1.000000), -cb6[1].z
1265: mad r15.w, r3.y, cb6[1].z, r15.w
1266: mul r26.xzw, r11.xxyz, r25.xxyz
1267: mad r16.w, r30.x, l(2.000000), r6.w
1268: add r16.w, r16.w, l(0.000100)
1269: div r16.w, l(0.500000), r16.w
1270: mad r7.y, r7.y, r16.w, l(-0.000061)
1271: max r7.y, r7.y, l(0)
1272: min r7.y, r7.y, l(20.000000)
1273: mul r28.yzw, r7.yyyy, r27.xxyz
1274: mad r7.y, r8.w, l(0.500000), l(0.500000)
1275: mul r7.y, r9.w, r7.y
1276: mul r11.xyz, r7.yyyy, r11.xyzx
1277: mul r11.xyz, r11.xyzx, r28.yzwy
1278: mul r11.xyz, r11.xyzx, cb1[123].wwww
1279: mad r11.xyz, r26.xzwx, r15.wwww, r11.xyzx
1280: dp3 r7.y, r11.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1281: add r8.w, r7.y, l(-0.500000)
1282: max r8.w, r8.w, l(0)
1283: min r8.w, r8.w, l(0.500000)
1284: mul r31.z, cb0[0].x, cb1[119].x
1285: mul r31.x, cb0[1].x, cb1[119].x
1286: mul r31.y, cb0[2].x, cb1[119].x
1287: mul r32.z, cb0[0].y, cb1[119].y
1288: mul r32.x, cb0[1].y, cb1[119].y
1289: mul r32.y, cb0[2].y, cb1[119].y
1290: add r26.xzw, r31.xxyz, r32.xxyz
1291: mov r31.xz, cb1[119].yyxy
1292: mov r31.y, l(0)
1293: add r26.xzw, r26.xxzw, -r31.xxyz
1294: mad r26.xzw, cb1[125].wwww, r26.xxzw, r31.xxyz
1295: mul r28.yzw, r26.xxzw, cb0[6].zzxy
1296: mad r26.xzw, cb0[6].yyzx, r26.zzwx, -r28.yyzw
1297: dp3 r16.w, r26.xzwx, r26.xzwx
1298: rsq r16.w, r16.w
1299: mul r26.xzw, r16.wwww, r26.xxzw
1300: dp3 r16.w, r2.yzwy, r14.xyzx
1301: add r28.yz, -abs(r16.wwww), l(0.000000, 1.000000, 0.400000, 0.000000)
1302: dp3 r18.x, r18.xyzx, r14.xyzx
1303: add r18.y, -r7.w, l(1.000000)
1304: add r13.x, -r3.z, r13.x
1305: mad r4.w, r4.w, r13.x, r3.z
1306: mul r31.y, r4.w, r4.w
1307: mul r23.z, r30.x, r23.x
1308: mul r13.x, r31.y, r31.y
1309: mul r31.z, r31.y, r13.x
1310: mov r30.yzw, l(0.000000, 0.036546, 9.063200, 0.990440)
1311: dp2 r29.x, l(3.327070, 1.000000, 0.000000, 0.000000), r30.xyxx
1312: dp2 r29.y, l(-9.047560, 1.000000, 0.000000, 0.000000), r30.xzxx
1313: mov r31.x, l(1.000000)
1314: dp2 r13.x, r29.xyxx, r31.xyxx
1315: mov r23.yw, l(0.000000, 9.044010, 0.000000, 1.000000)
1316: dp3 r32.x, l(3.596850, -1.367720, 1.000000, 0.000000), r23.xzwx
1317: dp3 r32.y, l(-16.317400, 1.000000, 9.229490, 0.000000), r23.xyzx
1318: mov r33.x, l(5.565890)
1319: mov r33.yz, r23.xxzx
1320: dp3 r32.z, l(1.000000, 19.788601, -20.212299, 0.000000), r33.xyzx
1321: dp3 r18.z, r32.xyzx, r31.xyzx
1322: div r13.x, r13.x, r18.z
1323: dp2 r29.x, l(-1.285140, 1.000000, 0.000000, 0.000000), r30.xwxx
1324: mov r23.x, l(1.296780)
1325: mov r23.y, r30.x
1326: dp2 r29.y, l(1.000000, -0.755907, 0.000000, 0.000000), r23.xyxx
1327: dp2 r18.z, r29.xyxx, r31.xyxx
1328: dp3 r32.x, l(2.923380, 59.418800, 1.000000, 0.000000), r23.yzwy
1329: mov r23.xw, l(20.322500, 0.000000, 0.000000, 121.563004)
1330: dp3 r32.y, l(1.000000, -27.030199, 222.591995, 0.000000), r23.xyzx
1331: dp3 r32.z, l(626.130005, 316.627014, 1.000000, 0.000000), r23.yzwy
1332: dp3 r20.w, r32.xyzx, r31.xyzx
1333: div r18.z, r18.z, r20.w
1334: mad r23.xyz, r17.xyzx, r13.xxxx, r18.zzzz
1335: add r13.x, r13.x, r18.z
1336: dp3 r18.z, -r2.yzwy, r15.xyzx
1337: add r18.z, r18.z, r18.z
1338: mad r29.xyw, r15.xyxz, -r18.zzzz, -r2.yzyw
1339: dp2 r31.x, r29.wxww, cb1[126].xyxx
1340: mul r18.z, r29.x, cb1[126].x
1341: mad r31.z, r29.w, cb1[126].y, -r18.z
1342: mul r10.xyz, r10.xyzx, cb6[7].xyzx
1343: mul r10.xyz, r10.xyzx, cb6[1].wwww
1344: lt r18.z, l(0.500000), cb6[26].x
1345: mul r20.w, cb1[105].w, cb6[26].y
1346: sincos r20.w, null, r20.w
1347: mad r20.w, r20.w, l(0.500000), l(0.500000)
1348: add r22.w, -cb6[26].z, cb6[26].w
1349: mad r20.w, r20.w, r22.w, cb6[26].z
1350: add r20.w, r20.w, l(-1.000000)
1351: mad r10.w, r10.w, r20.w, l(1.000000)
1352: movc r10.w, r18.z, r10.w, l(1.000000)
1353: mad r17.w, r17.w, r18.w, r21.w
1354: mul_sat r17.w, r17.w, cb6[20].w
1355: mul r21.xyz, r17.wwww, r21.xyzx
1356: mad r21.xyz, r21.xyzx, cb6[20].xyzx, r22.xyzx
1357: mul r22.xyz, r3.xxxx, cb6[21].xyzx
1358: mad r22.xyz, r22.xyzx, cb6[16].zzzz, -r21.xyzx
1359: mad r21.xyz, r3.xxxx, r22.xyzx, r21.xyzx
1360: mul r3.x, r3.w, cb6[21].w
1361: add r22.xyz, -r21.xyzx, cb6[21].xyzx
1362: mad r21.xyz, r3.xxxx, r22.xyzx, r21.xyzx
1363: mov_sat r0.w, r0.w
1364: add r3.x, l(1.000000), -cb6[15].y
1365: mad r3.x, r3.w, cb6[15].y, r3.x
1366: mul r0.w, r0.w, r3.x
1367: mul r21.xyz, r0.wwww, r21.xyzx
1368: mad r10.xyz, r10.xyzx, r10.wwww, r21.xyzx
1369: mad r0.w, r8.w, r8.w, l(1.000000)
1370: add r11.xyz, -r7.yyyy, r11.xyzx
1371: mad r11.xyz, r0.wwww, r11.xyzx, r7.yyyy
1372: mad r3.xw, cb1[119].wwww, l(-0.600000, 0.000000, 0.000000, -0.400000), l(0.800000, 0.000000, 0.000000, 0.900000)
1373: add r0.w, -r3.x, r3.w
1374: add r3.x, -r3.x, r28.y
1375: div r0.w, l(1.000000, 1.000000, 1.000000, 1.000000), r0.w
1376: mul_sat r0.w, r0.w, r3.x
1377: mad r3.x, r0.w, l(-2.000000), l(3.000000)
1378: mul r0.w, r0.w, r0.w
1379: mul r0.w, r0.w, r3.x
1380: mul r21.xyz, r0.wwww, cb1[118].xyzx
1381: mul r21.xyz, r21.xyzx, cb1[118].wwww
1382: dp3 r0.w, r4.xyzx, r26.xzwx
1383: add_sat r0.w, r0.w, l(1.000000)
1384: min r0.w, r7.z, r0.w
1385: min r0.w, r26.y, r0.w
1386: mul r21.xyz, r0.wwww, r21.xyzx
1387: mad r22.xyz, r6.xyzx, r5.yyyy, l(-0.250000, -0.250000, -0.250000, 0.000000)
1388: mad r22.xyz, cb1[119].zzzz, r22.xyzx, l(0.250000, 0.250000, 0.250000, 0.000000)
1389: dp3_sat r0.w, r26.xzwx, r14.xyzx
1390: mul r22.xyz, r0.wwww, r22.xyzx
1391: max r0.w, r19.y, r19.x
1392: max r0.w, r19.z, r0.w
1393: mul r0.w, r0.w, l(0.500000)
1394: max r0.w, r0.w, l(1.000000)
1395: div r0.w, l(1.000000, 1.000000, 1.000000, 1.000000), r0.w
1396: mul r19.xyz, r0.wwww, r19.xyzx
1397: mad r24.xyz, r24.xyzx, r24.wwww, -r19.xyzx
1398: mad r19.xyz, r7.wwww, r24.xyzx, r19.xyzx
1399: dp3 r0.w, r20.xyzx, r14.xyzx
1400: mul r3.x, r11.w, r0.w
1401: mad r3.w, r18.x, l(0.500000), l(-1.000000)
1402: mad r3.w, -r18.x, r3.w, l(0.500000)
1403: mad r0.w, -r0.w, r11.w, r3.w
1404: mad_sat r0.w, r7.w, r0.w, r3.x
1405: mul r18.xzw, r0.wwww, r19.xxyz
1406: mad r0.w, r14.w, r7.w, r18.y
1407: mul r0.w, r28.x, r0.w
1408: mul r18.xzw, r0.wwww, r18.xxzw
1409: mul_sat r0.w, r28.z, l(5.000000)
1410: mad r3.x, r0.w, l(-2.000000), l(3.000000)
1411: mul r0.w, r0.w, r0.w
1412: mul r0.w, r0.w, r3.x
1413: mul r18.xzw, r0.wwww, r18.xxzw
1414: mul r18.xzw, r19.wwww, r18.xxzw
1415: add r0.w, r12.z, l(-0.100000)
1416: mul_sat r0.w, r0.w, l(-16.666666)
1417: mad r3.x, r0.w, l(-2.000000), l(3.000000)
1418: mul r0.w, r0.w, r0.w
1419: mul r0.w, r0.w, r3.x
1420: mad r0.w, r0.w, r7.w, r18.y
1421: mul r7.yzw, r0.wwww, r18.xxzw
1422: max r18.xzw, r13.yyzw, l(0.150000, 0.000000, 0.150000, 0.150000)
1423: mul r7.yzw, r7.yyzw, r18.xxzw
1424: mad r7.yzw, r21.xxyz, r22.xxyz, r7.yyzw
1425: add r7.yzw, r7.yyzw, r11.xxyz
1426: utof r3.xw, r12.xxxy
1427: mul r11.xy, r3.xwxx, l(0.031250, 0.031250, 0.000000, 0.000000)
1428: round_ni r11.xy, r11.xyxx
1429: mad r0.w, r11.y, cb4[2].y, r11.x
1430: mul r0.w, r0.w, l(8.000000)
1431: ftoi r0.w, r0.w
1432: mad r8.w, -cb1[3].y, cb4[3].w, v0.w
1433: round_ni r8.w, r8.w
1434: add r10.w, l(-1.000000), cb4[2].w
1435: max r11.x, r8.w, l(0)
1436: min r10.w, r10.w, r11.x
1437: mul r11.x, r10.w, l(8.000000)
1438: ftoi r11.x, r11.x
1439: mad r7.yzw, r10.xxyz, r15.wwww, r7.yyzw
1440: max r4.w, r4.w, l(0.001000)
1441: log r4.w, r4.w
1442: mad r4.w, r4.w, l(1.200000), l(5.000000)
1443: mov r31.y, r29.y
1444: sample_l(texturecube)(float,float,float,float) r10.xyz, r31.xyzx, t20.xyzw, s0, r4.w
1445: add r4.w, -r13.x, l(1.000000)
1446: div r4.w, r4.w, r13.x
1447: mul r11.yzw, r4.wwww, r17.xxyz
1448: mad r11.yzw, r11.yyzw, r23.xxyz, r23.xxyz
1449: mul r10.xyz, r10.xyzx, r11.yzwy
1450: mul r4.w, r29.z, cb1[110].w
1451: mul r4.w, r9.w, r4.w
1452: mul r10.xyz, r4.wwww, r10.xyzx
1453: mad r7.yzw, r10.xxyz, r16.xxyz, r7.yyzw
1454: ge r4.w, r10.w, r8.w
1455: iadd r0.w, r0.w, cb4[0].z
1456: iadd r8.w, r11.x, cb4[0].w
1457: mad r9.w, r18.y, l(-0.250000), l(0.750000)
1458: mad r6.xyz, r6.xyzx, r5.yyyy, l(-0.500000, -0.500000, -0.500000, 0.000000)
1459: add r5.y, -r6.w, l(0.010000)
1460: ge r7.x, r7.x, l(0.500000)
1461: and r7.x, r7.x, l(1.000000)
1462: mov r10.w, l(1.000000)
1463: mov r11.xyz, r7.yzwy
1464: mov r11.w, l(0)
1465: loop
1466:   ilt r12.z, l(7), r11.w
1467:   breakc_nz r12.z
1468:   iadd r12.z, r0.w, r11.w
1469:   ld_structured_indexable(structured_buffer, stride=4)(mixed,mixed,mixed,mixed) r12.z, r12.z, l(0), t0.xxxx
1470:   iadd r13.x, r8.w, r11.w
1471:   ld_structured_indexable(structured_buffer, stride=4)(mixed,mixed,mixed,mixed) r13.x, r13.x, l(0), t0.xxxx
1472:   and r12.z, r12.z, r13.x
1473:   and r12.z, r4.w, r12.z
1474:   ishl r13.x, r11.w, l(5)
1475:   mov r16.xyz, r11.xyzx
1476:   mov r14.w, r12.z
1477:   loop
1478:     breakc_z r14.w
1479:     firstbit_lo r17.x, r14.w
1480:     ishl r17.y, l(1), r17.x
1481:     xor r17.y, r14.w, r17.y
1482:     iadd r17.x, r13.x, r17.x
1483:     bfi r18.xyzw, l(29, 29, 29, 29), l(3, 3, 3, 3), r17.xxxx, l(1, 5, 6, 7)
1484:     ftou r17.z, cb3[r18.y + 6].w
1485:     and r17.w, r17.z, l(1)
1486:     ieq r17.w, r17.w, l(1)
1487:     if_nz r17.w
1488:       add r10.xyz, r8.xyzx, -cb3[r18.x + 6].xyzx
1489:       and r19.xyz, l(0x0000ffff, 0x0000ffff, 0x0000ffff, 0), cb3[r18.y + 6].xzyx
1490:       and r20.xyz, l(0x0000ffff, 0x0000ffff, 0x0000ffff, 0), cb3[r18.z + 6].yxzy
1491:       ushr r21.xyz, cb3[r18.y + 6].xzyx, l(16, 16, 16, 0)
1492:       ushr r22.xyz, cb3[r18.z + 6].yxzy, l(16, 16, 16, 0)
1493:       f16tof32 r19.xyz, r19.xyzx
1494:       f16tof32 r20.xyz, r20.xyzx
1495:       f16tof32 r21.xyz, r21.xyzx
1496:       f16tof32 r22.xyw, r22.yxyz
1497:       mov r23.xz, r19.xxzx
1498:       mov r23.yw, r21.xxxz
1499:       dp4 r17.w, r10.xyzw, r23.xyzw
1500:       mov r21.x, r19.y
1501:       mov r21.z, r20.y
1502:       mov r21.w, r22.x
1503:       dp4 r18.y, r10.xyzw, r21.xyzw
1504:       mov r22.xz, r20.xxzx
1505:       dp4 r10.x, r10.xyzw, r22.xyzw
1506:       max r10.y, abs(r17.w), abs(r18.y)
1507:       max r10.x, abs(r10.x), r10.y
1508:       mad r10.y, cb3[r18.w + 6].x, l(0.500000), l(0.500000)
1509:       add r10.x, -r10.y, r10.x
1510:       mad r10.y, -cb3[r18.w + 6].x, l(0.500000), l(0.500000)
1511:       div_sat r10.x, r10.x, r10.y
1512:       add r10.x, -r10.x, l(1.000000)
1513:       mul r10.x, r10.x, r10.x
1514:     else
1515:       mov r10.x, l(1.000000)
1516:     endif
1517:     lt r10.y, r10.x, l(0.001000)
1518:     if_nz r10.y
1519:       mov r14.w, r17.y
1520:       continue
1521:     endif
1522:     ishl r10.y, r17.x, l(3)
1523:     ftou r10.z, cb3[r10.y + 6].w
1524:     uge r17.w, r10.z, l(4)
1525:     if_nz r17.w
1526:       mov r19.xyz, r16.xyzx
1527:     endif
1528:     if_z r17.w
1529:       lt r17.w, cb3[r10.y + 6].w, l(1.500000)
1530:       if_nz r17.w
1531:         bfi r17.w, l(29), l(3), r17.x, l(3)
1532:         ieq r18.y, l(16), cb3[r17.w + 6].w
1533:         add r19.w, cb1[122].z, cb3[r17.w + 6].z
1534:         lt r19.w, r19.w, l(0.500000)
1535:         or r18.y, r18.y, r19.w
1536:         if_z r18.y
1537:           bfi r20.xy, l(29, 29, 0, 0), l(3, 3, 0, 0), r17.xxxx, l(2, 4, 0, 0)
1538:           and r10.z, r10.z, l(1)
1539:           ieq r17.x, r10.z, l(0)
1540:           not r18.y, r17.x
1541:           lt r19.w, l(0), cb3[r20.x + 6].z
1542:           and r18.y, r18.y, r19.w
1543:           ieq r19.w, l(4), cb3[r17.w + 6].w
1544:           movc r20.z, r10.z, l(0), l(1.000000)
1545:           mad r20.w, cb3[r20.x + 6].y, l(0.500000), l(0.500000)
1546:           add r21.z, r20.w, -abs(cb3[r20.x + 6].x)
1547:           add r21.x, -r21.z, cb3[r20.x + 6].y
1548:           add r20.w, -abs(r21.z), l(1.000000)
1549:           add r20.w, -abs(r21.x), r20.w
1550:           max r20.w, r20.w, l(0.000488)
1551:           ge r21.w, cb3[r20.x + 6].x, l(0)
1552:           movc r21.y, r21.w, r20.w, -r20.w
1553:           dp3 r20.w, r21.xyzx, r21.xyzx
1554:           rsq r20.w, r20.w
1555:           mul r21.xyz, r20.wwww, r21.xyzx
1556:           add r20.w, cb3[r20.y + 6].y, cb3[r20.y + 6].y
1557:           max r20.w, r20.w, l(0.100000)
1558:           and r21.w, r19.w, l(1.000000)
1559:           add r20.w, r20.w, -cb3[r18.z + 6].w
1560:           mad r18.z, r21.w, r20.w, cb3[r18.z + 6].w
1561:           add r22.xyz, -r8.xyzx, cb3[r18.x + 6].xyzx
1562:           dp3 r20.w, r22.yzxy, -r21.xyzx
1563:           lt r21.w, l(0.500000), cb3[r20.y + 6].z
1564:           and r21.w, r19.w, r21.w
1565:           and r21.w, r21.w, l(1.000000)
1566:           mul r21.w, r20.z, r21.w
1567:           mad r23.xyz, -r21.zxyz, r20.wwww, -r22.xyzx
1568:           mad r22.xyz, r21.wwww, r23.xyzx, r22.xyzx
1569:           dp3 r20.w, r22.xyzx, r22.xyzx
1570:           rsq r21.w, r20.w
1571:           mul r23.xyz, r21.wwww, r22.xyzx
1572:           if_nz r18.y
1573:             mul r24.xyz, r21.zxyz, cb3[r20.x + 6].zzzz
1574:             mad r26.xyz, -r24.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), r22.xyzx
1575:             mad r24.xyz, r24.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000), r22.xyzx
1576:             dp3 r21.w, r26.xyzx, r26.xyzx
1577:             sqrt r21.w, r21.w
1578:             dp3 r22.w, r24.xyzx, r24.xyzx
1579:             sqrt r22.w, r22.w
1580:             mul r28.xzw, r21.xxyz, r23.xxyz
1581:             mad r28.xzw, r21.zzxy, r23.yyzx, -r28.xxzw
1582:             mul r29.xyz, r21.xyzx, r28.xzwx
1583:             mad r28.xzw, r28.wwxz, r21.yyzx, -r29.xxyz
1584:             dp3 r23.w, r28.xzwx, r28.xzwx
1585:             rsq r23.w, r23.w
1586:             mul r23.xyz, r23.wwww, r28.xzwx
1587:             dp3 r23.w, r26.xyzx, r24.xyzx
1588:             mad r23.w, r21.w, r22.w, r23.w
1589:             mad r23.w, r23.w, l(0.500000), l(1.000000)
1590:             div r23.w, l(1.000000, 1.000000, 1.000000, 1.000000), r23.w
1591:             dp3 r24.w, r23.xyzx, r26.xyzx
1592:             div r21.w, r24.w, r21.w
1593:             dp3 r24.x, r23.xyzx, r24.xyzx
1594:             div r22.w, r24.x, r22.w
1595:             add r21.w, r21.w, r22.w
1596:             mul_sat r21.w, r21.w, l(0.500000)
1597:             mul r21.w, r21.w, r23.w
1598:           else
1599:             mov r21.w, l(1.000000)
1600:           endif
1601:           lt r22.w, r18.z, l(0)
1602:           if_nz r22.w
1603:             mul r22.w, cb3[r18.x + 6].w, cb3[r18.x + 6].w
1604:             mul r22.w, r20.w, r22.w
1605:             mad r22.w, -r22.w, r22.w, l(1.000000)
1606:             max r22.w, r22.w, l(0)
1607:             add r20.w, r20.w, l(1.000000)
1608:             div r20.w, l(1.000000, 1.000000, 1.000000, 1.000000), r20.w
1609:             and r23.w, r18.y, l(1.000000)
1610:             add r24.x, -r20.w, r21.w
1611:             mad r20.w, r23.w, r24.x, r20.w
1612:             mul r22.w, r22.w, r22.w
1613:             mul r20.w, r20.w, r22.w
1614:           else
1615:             mul r24.xyz, r22.xyzx, cb3[r18.x + 6].wwww
1616:             dp3 r22.w, r24.xyzx, r24.xyzx
1617:             min r22.w, r22.w, l(1.000000)
1618:             add r22.w, -r22.w, l(1.000000)
1619:             log r22.w, r22.w
1620:             mul r18.z, r18.z, r22.w
1621:             exp r18.z, r18.z
1622:             mul r20.w, r18.z, r21.w
1623:           endif
1624:           dp3 r18.z, r23.yzxy, -r21.xyzx
1625:           add r18.z, r18.z, -cb3[r20.x + 6].z
1626:           mul_sat r18.z, r18.z, cb3[r20.x + 6].w
1627:           mad r18.z, r18.z, r18.z, l(-1.000000)
1628:           mad r18.z, r20.z, r18.z, l(1.000000)
1629:           mul r18.z, r18.z, r20.w
1630:           ftoi r20.z, cb3[r18.w + 6].w
1631:           not r18.y, r18.y
1632:           ige r20.w, r20.z, l(0)
1633:           and r18.y, r18.y, r20.w
1634:           if_nz r18.y
1635:             if_z r10.z
1636:               ishl r10.z, r20.z, l(2)
1637:               mul r21.xyz, r8.yyyy, cb7[r10.z + 33].xywx
1638:               mad r21.xyz, cb7[r10.z + 32].xywx, r8.xxxx, r21.xyzx
1639:               mad r21.xyz, cb7[r10.z + 34].xywx, r8.zzzz, r21.xyzx
1640:               add r21.xyz, r21.xyzx, cb7[r10.z + 35].xywx
1641:               div_sat r21.xy, r21.xyxx, r21.zzzz
1642:               mad r21.xy, r21.xyxx, cb7[r20.z + 0].zwzz, cb7[r20.z + 0].xyxx
1643:             else
1644:               ishl r10.z, r20.z, l(2)
1645:               dp3 r24.x, -r22.xyzx, cb7[r10.z + 32].xyzx
1646:               dp3 r24.y, -r22.xyzx, cb7[r10.z + 33].xyzx
1647:               dp3 r24.z, -r22.xyzx, cb7[r10.z + 34].xyzx
1648:               lt r10.z, abs(r24.x), abs(r24.y)
1649:               and r10.z, r10.z, l(1)
1650:               dp2 r18.y, abs(r24.xyxx), icb[r10.z + 0].xyxx
1651:               lt r18.y, r18.y, abs(r24.z)
1652:               movc r10.z, r18.y, l(2), r10.z
1653:               dp3 r18.y, r24.xyzx, icb[r10.z + 0].xyzx
1654:               lt r18.y, r18.y, l(0)
1655:               bfi r10.z, l(31), l(1), r10.z, r18.y
1656:               ushr r18.y, r10.z, l(1)
1657:               dp3 r18.y, r24.xyzx, icb[r18.y + 0].xyzx
1658:               div r20.w, l(0.000244), cb7[r20.z + 0].w
1659:               add r20.w, -r20.w, l(0.500000)
1660:               utof r21.z, r10.z
1661:               ult r21.w, r10.z, l(2)
1662:               and r21.w, r21.w, l(2)
1663:               dp2 r21.w, r24.xzxx, icb[r21.w + 0].xzxx
1664:               mul r21.w, r21.w, icb[r10.z + 4].z
1665:               div r21.w, r21.w, abs(r18.y)
1666:               mad r21.z, r21.w, r20.w, r21.z
1667:               add r21.z, r21.z, l(0.500000)
1668:               mul_sat r22.x, r21.z, l(0.166667)
1669:               iadd r21.z, l(-1), icb[r10.z + 4].y
1670:               dp2 r21.z, r24.yzyy, icb[r21.z + 0].xyxx
1671:               mul r10.z, r21.z, icb[r10.z + 4].w
1672:               div r10.z, r10.z, abs(r18.y)
1673:               mad_sat r22.y, -r10.z, r20.w, l(0.500000)
1674:               mad r21.xy, r22.xyxx, cb7[r20.z + 0].zwzz, cb7[r20.z + 0].xyxx
1675:             endif
1676:             sample_l(texture2d)(float,float,float,float) r10.z, r21.xyxx, t23.yzxw, s0, l(0)
1677:             mul r18.z, r10.z, r18.z
1678:           endif
1679:           mul r10.x, r10.x, r18.z
1680:           lt r10.z, l(0.000100), r10.x
1681:           if_nz r10.z
1682:             if_nz r19.w
1683:               add r10.z, l(1.000000), -cb3[r20.y + 6].w
1684:               dp3 r18.y, r5.xzwx, r23.xyzx
1685:               add_sat r18.y, r18.y, l(0.500000)
1686:               mad r18.z, r18.y, l(-2.000000), l(3.000000)
1687:               mul r18.y, r18.y, r18.y
1688:               mul r18.y, r18.y, r18.z
1689:               mad r10.z, r18.y, cb3[r20.y + 6].w, r10.z
1690:               mul r10.z, r10.z, cb3[r20.y + 6].x
1691:               mul r10.z, r10.z, r10.x
1692:               add r21.xyz, -r16.xyzx, cb3[r10.y + 6].xyzx
1693:               mad r21.xyz, r10.zzzz, r21.xyzx, r16.xyzx
1694:             endif
1695:             if_z r19.w
1696:               dp3 r10.z, r14.xyzx, r23.xyzx
1697:               mov_sat r18.y, r10.z
1698:               if_nz cb3[r17.w + 6].w
1699:                 and r17.z, r17.z, l(2)
1700:                 ine r17.z, r17.z, l(0)
1701:                 or r17.x, r17.z, r17.x
1702:                 if_nz r17.x
1703:                   ftoi r17.z, cb3[r17.w + 6].x
1704:                 else
1705:                   add r22.xyz, r8.xyzx, -cb3[r18.x + 6].xyzx
1706:                   lt r24.xyz, abs(r22.yzzy), abs(r22.xxyx)
1707:                   and r18.z, r24.y, r24.x
1708:                   lt r22.xyz, l(0, 0, 0, 0), r22.xyzx
1709:                   and r20.z, l(1023), cb3[r20.x + 6].w
1710:                   ubfe r20.xw, l(10, 0, 0, 10), l(10, 0, 0, 20), cb3[r20.x + 6].wwww
1711:                   movc r20.x, r22.x, r20.z, r20.x
1712:                   and r20.z, l(1023), cb3[r17.w + 6].x
1713:                   movc r20.z, r22.y, r20.w, r20.z
1714:                   ubfe r22.xy, l(10, 10, 0, 0), l(10, 20, 0, 0), cb3[r17.w + 6].xxxx
1715:                   movc r20.w, r22.z, r22.x, r22.y
1716:                   movc r20.z, r24.z, r20.z, r20.w
1717:                   movc r18.z, r18.z, r20.x, r20.z
1718:                   ieq r20.x, r18.z, l(1023)
1719:                   movc r17.z, r20.x, l(-1), r18.z
1720:                 endif
1721:                 ige r18.z, r17.z, l(0)
1722:                 if_nz r18.z
1723:                   add r20.xzw, r8.xxyz, -cb3[r18.x + 6].xxyz
1724:                   imad r17.z, r17.z, l(96), cb5[65].x
1725:                   iadd r22.xyzw, r17.zzzz, l(64, 16, 32, 48)
1726:                   and r22.xyzw, r22.xyzw, l(-4, -4, -4, -4)
1727:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r18.xz, r22.x, t2.xxyx
1728:                   and r21.w, r17.z, l(-4)
1729:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r24.xyzw, r21.w, t2.xyzw
1730:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r26.xyzw, r22.y, t2.xyzw
1731:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r29.xyzw, r22.z, t2.xyzw
1732:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r31.xyzw, r22.w, t2.xyzw
1733:                   dp3 r21.w, r20.xzwx, r20.xzwx
1734:                   max r21.w, r21.w, l(0.000000)
1735:                   rsq r21.w, r21.w
1736:                   mul r20.xzw, r20.xxzw, r21.wwww
1737:                   mad r20.xzw, -r20.xxzw, r18.xxxx, r8.xxyz
1738:                   mul r18.x, r18.z, l(5.000000)
1739:                   mad r20.xzw, r5.xxzw, r18.xxxx, r20.xxzw
1740:                   mul r26.xyzw, r20.zzzz, r26.xyzw
1741:                   mad r24.xyzw, r24.xyzw, r20.xxxx, r26.xyzw
1742:                   mad r24.xyzw, r29.xyzw, r20.wwww, r24.xyzw
1743:                   add r24.xyzw, r31.xyzw, r24.xyzw
1744:                   div r20.xzw, r24.xxyz, r24.wwww
1745:                   iadd r17.z, r17.z, l(80)
1746:                   and r17.z, r17.z, l(-4)
1747:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r26.xyzw, r17.z, t2.xyzw
1748:                   ge r22.yzw, l(0, 0, 0, 0), r20.xxzw
1749:                   ge r24.xyz, r20.xzwx, l(1.000000, 1.000000, 1.000000, 0.000000)
1750:                   add r18.xz, -r26.xxyx, r26.zzwz
1751:                   mad r18.xz, r20.xxzx, r18.xxzx, r26.xxyx
1752:                   mad r26.xy, r18.xzxx, cb5[64].zwzz, l(0.500000, 0.500000, 0.000000, 0.000000)
1753:                   round_ni r26.xy, r26.xyxx
1754:                   mad r18.xz, r18.xxzx, cb5[64].zzwz, -r26.xxyx
1755:                   add r29.xyzw, r18.xxzz, l(0.500000, 1.000000, 0.500000, 1.000000)
1756:                   mul r31.xyzw, r29.xxzz, r29.xxzz
1757:                   add r26.zw, -r18.xxxz, l(0.000000, 0.000000, 1.000000, 1.000000)
1758:                   min r28.xz, r18.xxzx, l(0, 0, 0, 0)
1759:                   max r29.xz, r18.xxzx, l(0, 0, 0, 0)
1760:                   mul r32.xy, r26.zwzz, l(0.160000, 0.160000, 0.000000, 0.000000)
1761:                   mad r29.xz, -r29.xxzx, r29.xxzx, r29.yywy
1762:                   add r29.xz, r29.xxzx, l(1.000000, 0.000000, 1.000000, 0.000000)
1763:                   mul r33.xy, r29.xzxx, l(0.160000, 0.160000, 0.000000, 0.000000)
1764:                   mul r29.xz, r31.xxzx, l(0.080000, 0.000000, 0.080000, 0.000000)
1765:                   mad r18.xz, r31.yywy, l(0.500000, 0.000000, 0.500000, 0.000000), -r18.xxzx
1766:                   mul r31.xy, r18.xzxx, l(0.160000, 0.160000, 0.000000, 0.000000)
1767:                   mad r18.xz, -r28.xxzx, r28.xxzx, r26.zzwz
1768:                   add r18.xz, r18.xxzx, l(1.000000, 0.000000, 1.000000, 0.000000)
1769:                   mul r34.xy, r18.xzxx, l(0.160000, 0.160000, 0.000000, 0.000000)
1770:                   mul r18.xz, r29.yywy, l(0.160000, 0.000000, 0.160000, 0.000000)
1771:                   mov r31.z, r34.x
1772:                   mov r31.w, r18.x
1773:                   mov r32.z, r33.x
1774:                   mov r32.w, r29.x
1775:                   add r35.xyzw, r31.zwxz, r32.zwxz
1776:                   mov r34.z, r31.y
1777:                   mov r34.w, r18.z
1778:                   mov r33.z, r32.y
1779:                   mov r33.w, r29.z
1780:                   add r28.xzw, r33.zzyw, r34.zzyw
1781:                   div r29.xyz, r32.xzwx, r35.zwyz
1782:                   add r29.xyz, r29.xyzx, l(-2.500000, -0.500000, 1.500000, 0.000000)
1783:                   mul r29.xyz, r29.xyzx, cb5[64].xxxx
1784:                   div r30.yzw, r33.zzyw, r28.xxzw
1785:                   add r30.yzw, r30.yyzw, l(0.000000, -2.500000, -0.500000, 1.500000)
1786:                   mul r31.xyw, r30.yzyw, cb5[64].yyyy
1787:                   mul r32.xyzw, r28.xxxz, r35.zwyz
1788:                   mov r29.w, r31.x
1789:                   mad r33.xyzw, r26.xyxy, cb5[64].xyxy, r29.xwyw
1790:                   sample_c_lz(texture2d)(float,float,float,float) r17.z, r33.xyxx, t3.xxxx, s2, r20.w
1791:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r33.zwzz, t3.xxxx, s2, r20.w
1792:                   mul r18.x, r18.x, r32.y
1793:                   mad r17.z, r32.x, r17.z, r18.x
1794:                   mad r18.xz, r26.xxyx, cb5[64].xxyx, r29.zzwz
1795:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r18.xzxx, t3.xxxx, s2, r20.w
1796:                   mad r17.z, r32.z, r18.x, r17.z
1797:                   mov r31.z, r29.x
1798:                   mad r33.xyzw, r26.xyxy, cb5[64].xyxy, r31.zyzw
1799:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r33.xyxx, t3.xxxx, s2, r20.w
1800:                   mad r17.z, r32.w, r18.x, r17.z
1801:                   mul r32.xyzw, r28.zzww, r35.xyzw
1802:                   mov r31.xz, r29.yyzy
1803:                   mad r29.xyzw, r26.xyxy, cb5[64].xyxy, r31.xyzy
1804:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r29.xyxx, t3.xxxx, s2, r20.w
1805:                   mad r17.z, r32.x, r18.x, r17.z
1806:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r29.zwzz, t3.xxxx, s2, r20.w
1807:                   mad r17.z, r32.y, r18.x, r17.z
1808:                   sample_c_lz(texture2d)(float,float,float,float) r18.x, r33.zwzz, t3.xxxx, s2, r20.w
1809:                   mad r17.z, r32.z, r18.x, r17.z
1810:                   iadd r18.x, r22.x, l(8)
1811:                   ld_raw(rawbuffer)(mixed,mixed,mixed,mixed) r18.xz, r18.x, t2.xxyx
1812:                   add r26.zw, -r20.xxxz, l(0.000000, 0.000000, 1.000000, 1.000000)
1813:                   min r20.xz, r20.xxzx, r26.zzwz
1814:                   or r22.xyz, r22.yzwy, r24.xyzx
1815:                   or r21.w, r22.y, r22.x
1816:                   or r21.w, r22.z, r21.w
1817:                   and r22.x, r20.w, l(0x7fffffff)
1818:                   ult r22.x, l(0x7f800000), r22.x
1819:                   or r21.w, r21.w, r22.x
1820:                   mad r22.xyzw, r26.xyxy, cb5[64].xyxy, r31.xwzw
1821:                   sample_c_lz(texture2d)(float,float,float,float) r22.x, r22.xyxx, t3.xxxx, s2, r20.w
1822:                   mad r17.z, r32.w, r22.x, r17.z
1823:                   mul r22.x, r28.w, r35.y
1824:                   sample_c_lz(texture2d)(float,float,float,float) r20.w, r22.zwzz, t3.xxxx, s2, r20.w
1825:                   mad r17.z, r22.x, r20.w, r17.z
1826:                   add r18.x, -r24.w, r18.x
1827:                   mul r18.x, r18.x, l(0.250000)
1828:                   min r20.x, r20.z, r20.x
1829:                   min r18.x, r18.x, r20.x
1830:                   mul_sat r18.x, r18.x, l(20.000000)
1831:                   mad r20.x, r18.x, l(-2.000000), l(3.000000)
1832:                   mul r18.x, r18.x, r18.x
1833:                   mul r18.x, r18.x, r20.x
1834:                   min r18.x, r18.x, r18.z
1835:                   movc r17.x, r17.x, r18.x, r18.z
1836:                   add r17.z, r17.z, l(-1.000000)
1837:                   movc r17.z, r21.w, l(0), r17.z
1838:                   mad r17.x, r17.x, r17.z, l(1.000000)
1839:                 else
1840:                   dp3 r17.z, r4.xyzx, r23.xyzx
1841:                   add_sat r17.x, r17.z, l(1.000000)
1842:                 endif
1843:               else
1844:                 mov r17.x, l(1.000000)
1845:               endif
1846:               if_z cb3[r17.w + 6].w
1847:                 mul r20.xzw, r10.xxxx, cb3[r10.y + 6].xxyz
1848:                 add r17.z, l(1.000000), -cb3[r20.y + 6].y
1849:                 max r18.x, r20.z, r20.x
1850:                 max r18.x, r20.w, r18.x
1851:                 mul r18.x, r9.w, r18.x
1852:                 max r18.x, r18.x, l(1.000000)
1853:                 div r18.x, l(1.000000, 1.000000, 1.000000, 1.000000), r18.x
1854:                 mad r17.z, r18.x, cb3[r20.y + 6].y, r17.z
1855:                 mul r20.xzw, r17.zzzz, cb3[r10.y + 6].xxyz
1856:                 mul r17.z, l(0.250000), cb3[r20.y + 6].x
1857:                 add_sat r18.x, r10.z, l(0.500000)
1858:                 mad r18.z, -cb3[r20.y + 6].x, l(0.250000), l(1.000000)
1859:                 mad r17.z, r18.x, r18.z, r17.z
1860:                 mul r20.xzw, r17.zzzz, r20.xxzw
1861:                 mov r22.xyz, r25.xyzx
1862:                 mov r24.xyz, r25.xyzx
1863:                 mov r17.z, l(1.000000)
1864:                 mov r18.x, l(0)
1865:               else
1866:                 ieq r18.z, l(3), cb3[r17.w + 6].w
1867:                 if_nz r18.z
1868:                   mad r26.xy, cb3[r20.y + 6].xxxx, l(-0.600000, -0.400000, 0.000000, 0.000000), l(0.800000, 0.900000, 0.000000, 0.000000)
1869:                   add r18.z, -r26.x, r26.y
1870:                   add r21.w, -r26.x, r28.y
1871:                   div r18.z, l(1.000000, 1.000000, 1.000000, 1.000000), r18.z
1872:                   mul_sat r18.z, r18.z, r21.w
1873:                   mad r21.w, r18.z, l(-2.000000), l(3.000000)
1874:                   mul r18.z, r18.z, r18.z
1875:                   mul r18.z, r18.z, r21.w
1876:                   mul r18.z, r17.x, r18.z
1877:                   mul r10.x, r10.x, r18.z
1878:                   mul r26.xyz, r23.zxyz, cb0[6].xyzx
1879:                   mad r26.xyz, cb0[6].zxyz, r23.xyzx, -r26.xyzx
1880:                   mul r28.xzw, r26.xxyz, cb0[6].zzxy
1881:                   mad r26.xyz, cb0[6].yzxy, r26.yzxy, -r28.xzwx
1882:                   dp3 r18.z, r26.xyzx, r26.xyzx
1883:                   rsq r18.z, r18.z
1884:                   mul r26.xyz, r18.zzzz, r26.xyzx
1885:                   dp3_sat r18.y, r14.xyzx, -r26.xyzx
1886:                   mad r22.xyz, cb3[r20.y + 6].yyyy, r6.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000)
1887:                   mov r24.xyz, l(0, 0, 0, 0)
1888:                   mov r17.z, l(1.000000)
1889:                   mov r18.x, l(0)
1890:                 else
1891:                   ieq r18.z, l(1), cb3[r17.w + 6].w
1892:                   if_nz r18.z
1893:                     add r10.z, r10.z, cb3[r20.y + 6].x
1894:                     max_sat r10.z, r10.z, l(-1.000000)
1895:                     mul r18.y, r17.x, r10.z
1896:                     mul r24.xyz, r9.xyzx, cb3[r20.y + 6].yyyy
1897:                     mov r17.z, l(1.000000)
1898:                     mov r18.x, l(0)
1899:                   else
1900:                     ieq r10.z, l(2), cb3[r17.w + 6].w
1901:                     if_nz r10.z
1902:                       add r17.x, l(0.050000), cb3[r20.y + 6].x
1903:                       add r17.x, r3.z, -r17.x
1904:                       mul_sat r17.x, r17.x, l(-10.000000)
1905:                       mad r21.w, r17.x, l(-2.000000), l(3.000000)
1906:                       mul r17.x, r17.x, r17.x
1907:                       mul r17.x, r17.x, r21.w
1908:                       add r21.w, l(1.000000), -cb3[r20.y + 6].z
1909:                       mad r21.w, r7.x, cb3[r20.y + 6].z, r21.w
1910:                       mul r17.z, r17.x, r21.w
1911:                     else
1912:                       mov r17.z, l(1.000000)
1913:                     endif
1914:                     and r18.x, r10.z, cb3[r20.y + 6].y
1915:                     mov r24.xyz, l(0, 0, 0, 0)
1916:                   endif
1917:                   and r22.xyz, r13.yzwy, r18.zzzz
1918:                 endif
1919:                 mov r20.xzw, cb3[r10.y + 6].xxyz
1920:               endif
1921:               ine r10.y, l(3), cb3[r17.w + 6].w
1922:               if_nz r10.y
1923:                 mad r10.y, r18.x, r5.y, r6.w
1924:                 mad r23.xyz, r1.xyzx, r2.xxxx, r23.xyzx
1925:                 dp3 r10.z, r23.xyzx, r23.xyzx
1926:                 rsq r10.z, r10.z
1927:                 mul r23.xyz, r10.zzzz, r23.xyzx
1928:                 dp3 r10.z, r15.xyzx, r23.xyzx
1929:                 mul r17.x, r10.y, r10.y
1930:                 mad r17.w, r10.z, r17.x, -r10.z
1931:                 mad r10.z, r17.w, r10.z, l(1.000000)
1932:                 mul r10.z, r10.z, r10.z
1933:                 ne r17.w, r10.z, r17.x
1934:                 div r10.z, r17.x, r10.z
1935:                 movc r10.z, r17.w, r10.z, l(1.000000)
1936:                 mad r10.y, r30.x, l(2.000000), r10.y
1937:                 add r10.y, r10.y, l(0.000100)
1938:                 div r10.y, l(0.500000), r10.y
1939:                 mad r10.y, r10.z, r10.y, l(-0.000061)
1940:                 max r10.y, r10.y, l(0)
1941:                 min r10.y, r10.y, l(20.000000)
1942:                 mul r23.xyz, r10.yyyy, r27.xyzx
1943:                 mul r17.xzw, r17.zzzz, r23.xxyz
1944:                 mul r17.xzw, r17.xxzw, cb3[r18.w + 6].zzzz
1945:               else
1946:                 mov r17.xzw, l(0, 0, 0, 0)
1947:               endif
1948:               mul r10.xyz, r10.xxxx, r20.xzwx
1949:               add r18.xzw, r22.xxyz, -r24.xxyz
1950:               mad r18.xzw, r18.yyyy, r18.xxzw, r24.xxyz
1951:               mul r18.xzw, r10.xxyz, r18.xxzw
1952:               mul r10.xyz, r17.xzwx, r10.xyzx
1953:               mul r10.xyz, r18.yyyy, r10.xyzx
1954:               mad r10.xyz, r18.xzwx, r15.wwww, r10.xyzx
1955:               add r16.xyz, r10.xyzx, r16.xyzx
1956:             endif
1957:           else
1958:             mov r19.w, l(0)
1959:           endif
1960:           movc r16.xyz, r19.wwww, r21.xyzx, r16.xyzx
1961:         endif
1962:       endif
1963:     else
1964:       mov r16.xyz, r19.xyzx
1965:     endif
1966:     mov r14.w, r17.y
1967:   endloop
1968:   mov r11.xyz, r16.xyzx
1969:   iadd r11.w, r11.w, l(1)
1970: endloop
1971: lt r0.w, l(0.500000), cb6[3].x
1972: if_nz r0.w
1973:   dp3 r0.w, r11.xyzx, l(0.212673, 0.715152, 0.072175, 0.000000)
1974:   add r1.xyz, -r0.wwww, r11.xyzx
1975:   mad r1.xyz, cb6[3].zzzz, r1.xyzx, r0.wwww
1976:   add r1.xyz, r1.xyzx, l(-0.500000, -0.500000, -0.500000, 0.000000)
1977:   mad r1.xyz, cb6[3].wwww, r1.xyzx, l(0.500000, 0.500000, 0.500000, 0.000000)
1978:   mul r4.xyz, r1.xyzx, cb6[3].yyyy
1979:   mad r1.xyz, -r1.xyzx, cb6[3].yyyy, cb6[8].xyzx
1980:   mad r1.xyz, cb6[8].wwww, r1.xyzx, r4.xyzx
1981:   add r0.w, l(1.000000), -cb6[4].x
1982:   mov_sat r16.w, r16.w
1983:   add r3.z, -r16.w, l(1.000000)
1984:   add r4.x, -r0.w, l(1.000000)
1985:   add r0.w, -r0.w, r3.z
1986:   div r3.z, l(1.000000, 1.000000, 1.000000, 1.000000), r4.x
1987:   mul_sat r0.w, r0.w, r3.z
1988:   mad r3.z, r0.w, l(-2.000000), l(3.000000)
1989:   mul r0.w, r0.w, r0.w
1990:   mul r0.w, r0.w, r3.z
1991:   mul r4.xyz, r0.wwww, cb6[9].xyzx
1992:   mad r11.xyz, r4.xyzx, cb6[4].yyyy, r1.xyzx
1993: endif
1994: mul r1.xyz, r11.xyzx, cb1[27].yyyy
1995: eq r0.w, l(1.000000), cb6[2].x
1996: movc o0.w, r0.w, r3.y, l(1.000000)
1997: lt r0.w, cb1[122].w, l(0.500000)
1998: if_nz r0.w
1999:   mul r0.w, r1.w, r2.x
2000:   mad r3.y, r8.y, cb1[74].w, cb1[75].w
2001:   mad r3.z, r0.w, cb1[72].w, -cb1[71].w
2002:   max r3.yz, r3.yyzy, l(0.000000, 0.010000, 0.000000, 0.000000)
2003:   mul r4.x, r3.y, l(-1.442695)
2004:   exp r4.x, r4.x
2005:   add r4.x, -r4.x, l(1.000000)
2006:   div r3.y, r4.x, r3.y
2007:   mad r4.x, r8.y, cb1[74].w, cb1[76].w
2008:   mul r4.x, r4.x, l(1.442695)
2009:   exp r4.x, r4.x
2010:   mul r3.y, r3.y, r4.x
2011:   mul r3.y, r3.y, -r3.z
2012:   mul r4.xyz, r3.yyyy, cb1[73].xyzx
2013:   mul r4.xyz, r4.xyzx, l(1.442695, 1.442695, 1.442695, 0.000000)
2014:   exp r4.xyz, r4.xyzx
2015:   dp3 r3.y, -r2.yzwy, cb1[72].xyzx
2016:   mad r3.z, cb1[73].w, cb1[73].w, l(1.000000)
2017:   dp2 r4.w, r3.yyyy, cb1[73].wwww
2018:   add r3.z, r3.z, -r4.w
2019:   lt r4.w, l(0), cb1[83].z
2020:   if_nz r4.w
2021:     and r12.w, l(7), cb1[26].w
2022:     imad r5.xyz, r12.xywx, l(0x0019660d, 0x0019660d, 0x0019660d, 0), l(0.014584, 0.014584, 0.014584, 0.000000)
2023:     imad r4.w, r5.y, r5.z, r5.x
2024:     imad r5.x, r5.z, r4.w, r5.y
2025:     imad r5.y, r4.w, r5.x, r5.z
2026:     imad r6.x, r5.x, r5.y, r4.w
2027:     dp3 r0.x, -r2.yzwy, -r0.xyzx
2028:     lt r0.y, l(0.000000), r0.x
2029:     div r0.x, l(1.000000, 1.000000, 1.000000, 1.000000), r0.x
2030:     and r0.x, r0.x, r0.y
2031:     mul r0.x, r0.x, cb1[83].w
2032:     div r0.y, l(1.000000, 1.000000, 1.000000, 1.000000), r0.w
2033:     mul r0.z, r0.y, r0.x
2034:     mad r4.w, r0.z, v2.y, cb0[44].y
2035:     mad r0.z, -r0.z, v2.y, v2.y
2036:     mad r0.x, -r0.x, r0.y, l(1.000000)
2037:     mul r0.y, r0.w, r0.x
2038:     mul r5.z, r0.z, cb1[77].z
2039:     mul r0.z, r0.z, cb1[80].x
2040:     max r0.z, r0.z, l(-127.000000)
2041:     add r5.w, r4.w, -cb1[77].x
2042:     mul r5.w, r5.w, cb1[77].z
2043:     max r5.zw, r5.zzzw, l(0.000000, 0.000000, -127.000000, -127.000000)
2044:     exp r5.w, -r5.w
2045:     mul r5.w, r5.w, cb1[77].y
2046:     lt r6.z, l(0.000000), abs(r5.z)
2047:     exp r6.w, -r5.z
2048:     add r6.w, -r6.w, l(1.000000)
2049:     div r6.w, r6.w, r5.z
2050:     mad r5.z, -r5.z, l(0.240227), l(0.693147)
2051:     movc r5.z, r6.z, r6.w, r5.z
2052:     add r4.w, r4.w, -cb1[80].z
2053:     mul r4.w, r4.w, cb1[80].x
2054:     max r4.w, r4.w, l(-127.000000)
2055:     exp r4.w, -r4.w
2056:     mul r4.w, r4.w, cb1[80].y
2057:     lt r6.z, l(0.000000), abs(r0.z)
2058:     exp r6.w, -r0.z
2059:     add r6.w, -r6.w, l(1.000000)
2060:     div r6.w, r6.w, r0.z
2061:     mad r0.z, -r0.z, l(0.240227), l(0.693147)
2062:     movc r0.z, r6.z, r6.w, r0.z
2063:     mul r0.z, r0.z, r4.w
2064:     mad r0.z, r5.w, r5.z, r0.z
2065:     mad_sat r5.zw, r0.wwww, cb1[78].wwwy, cb1[78].zzzx
2066:     mul r0.y, r0.y, r0.z
2067:     exp r0.y, -r0.y
2068:     min r0.y, r0.y, l(1.000000)
2069:     max r0.y, r0.y, cb1[79].w
2070:     add r0.y, r5.w, r0.y
2071:     add r0.y, r5.z, r0.y
2072:     min r0.y, r0.y, l(1.000000)
2073:     imad r6.y, r5.y, r6.x, r5.x
2074:     ushr r5.xy, r6.xyxx, l(16, 16, 0, 0)
2075:     utof r5.xy, r5.xyxx
2076:     mad r5.xy, r5.xyxx, l(0.000031, 0.000031, 0.000000, 0.000000), l(-1.000000, -1.000000, 0.000000, 0.000000)
2077:     mad r3.xw, r5.xxxy, cb1[87].wwww, r3.xxxw
2078:     mul r6.xy, r3.xwxx, cb1[85].xyxx
2079:     mad r3.x, v0.w, cb1[84].x, cb1[84].y
2080:     log r3.x, r3.x
2081:     mul r3.x, r3.x, cb1[84].z
2082:     div r6.z, r3.x, cb1[83].z
2083:     sample_l(texture3d)(float,float,float,float) r6.xyzw, r6.xyzx, t24.xyzw, s0, l(0)
2084:     add r3.x, v0.w, -cb1[86].z
2085:     mul_sat r3.x, r3.x, l(1000000.000000)
2086:     add r6.xyzw, r6.xyzw, l(-0.000000, -0.000000, -0.000000, -1.000000)
2087:     mad r6.xyzw, r3.xxxx, r6.xyzw, l(0.000000, 0.000000, 0.000000, 1.000000)
2088:     add r3.x, -r0.y, l(1.000000)
2089:     dp3_sat r3.w, r2.yzwy, cb1[81].xyzx
2090:     log r3.w, r3.w
2091:     mul r3.w, r3.w, cb1[82].w
2092:     exp r3.w, r3.w
2093:     mul r5.xyw, r3.wwww, cb1[82].xyxz
2094:     mad r0.x, r0.x, r0.w, -cb1[81].w
2095:     max r0.x, r0.x, l(0)
2096:     mul r0.x, r0.x, r0.z
2097:     exp r0.x, -r0.x
2098:     min r0.x, r0.x, l(1.000000)
2099:     add r0.x, -r0.x, l(1.000000)
2100:     mul r5.xyw, r0.xxxx, r5.xyxw
2101:     add r0.x, -r5.z, l(1.000000)
2102:     mul r5.xyz, r0.xxxx, r5.xywx
2103:     mad r5.xyz, cb1[79].xyzx, r3.xxxx, r5.xyzx
2104:     mad r5.xyz, r5.xyzx, r6.wwww, r6.xyzx
2105:     mul r0.x, r0.y, r6.w
2106:   else
2107:     mul r0.y, v2.y, cb1[77].z
2108:     mul r0.z, v2.y, cb1[80].x
2109:     max r0.yz, r0.yyzy, l(0.000000, -127.000000, -127.000000, 0.000000)
2110:     add r3.x, cb0[44].y, -cb1[77].x
2111:     mul r3.x, r3.x, cb1[77].z
2112:     max r3.x, r3.x, l(-127.000000)
2113:     exp r3.x, -r3.x
2114:     mul r3.x, r3.x, cb1[77].y
2115:     lt r3.w, l(0.000000), abs(r0.y)
2116:     exp r4.w, -r0.y
2117:     add r4.w, -r4.w, l(1.000000)
2118:     div r4.w, r4.w, r0.y
2119:     mad r0.y, -r0.y, l(0.240227), l(0.693147)
2120:     movc r0.y, r3.w, r4.w, r0.y
2121:     add r3.w, cb0[44].y, -cb1[80].z
2122:     mul r3.w, r3.w, cb1[80].x
2123:     max r3.w, r3.w, l(-127.000000)
2124:     exp r3.w, -r3.w
2125:     mul r3.w, r3.w, cb1[80].y
2126:     lt r4.w, l(0.000000), abs(r0.z)
2127:     exp r5.w, -r0.z
2128:     add r5.w, -r5.w, l(1.000000)
2129:     div r5.w, r5.w, r0.z
2130:     mad r0.z, -r0.z, l(0.240227), l(0.693147)
2131:     movc r0.z, r4.w, r5.w, r0.z
2132:     mul r0.z, r0.z, r3.w
2133:     mad r0.y, r3.x, r0.y, r0.z
2134:     mad_sat r3.xw, r0.wwww, cb1[78].wwwy, cb1[78].zzzx
2135:     mul r0.z, r0.w, r0.y
2136:     exp r0.z, -r0.z
2137:     min r0.z, r0.z, l(1.000000)
2138:     max r0.z, r0.z, cb1[79].w
2139:     add r0.z, r3.w, r0.z
2140:     add r0.z, r3.x, r0.z
2141:     min r0.x, r0.z, l(1.000000)
2142:     dp3_sat r0.w, r2.yzwy, cb1[81].xyzx
2143:     log r0.w, r0.w
2144:     mul r0.w, r0.w, cb1[82].w
2145:     exp r0.w, r0.w
2146:     mul r2.yzw, r0.wwww, cb1[82].xxyz
2147:     mad r0.w, r1.w, r2.x, -cb1[81].w
2148:     max r0.w, r0.w, l(0)
2149:     mul r0.y, r0.w, r0.y
2150:     exp r0.y, -r0.y
2151:     min r0.y, r0.y, l(1.000000)
2152:     add r0.yz, -r0.yyxy, l(0.000000, 1.000000, 1.000000, 0.000000)
2153:     mul r2.xyz, r0.yyyy, r2.yzwy
2154:     add r0.y, -r3.x, l(1.000000)
2155:     mul r2.xyz, r0.yyyy, r2.xyzx
2156:     mad r5.xyz, cb1[79].xyzx, r0.zzzz, r2.xyzx
2157:   endif
2158:   mul r0.yzw, r0.xxxx, r4.xxyz
2159:   mad r1.w, r3.y, r3.y, l(1.000000)
2160:   mul r1.w, r1.w, l(0.059683)
2161:   mad r2.xyz, cb1[74].xyzx, r1.wwww, cb1[76].xyzx
2162:   mad r1.w, -cb1[73].w, cb1[73].w, l(1.000000)
2163:   mul r2.w, r3.z, l(12.566371)
2164:   sqrt r3.x, r3.z
2165:   mul r2.w, r2.w, r3.x
2166:   max r2.w, r2.w, l(0.001000)
2167:   div r1.w, r1.w, r2.w
2168:   mad_sat r2.xyz, cb1[75].xyzx, r1.wwww, r2.xyzx
2169:   mul r2.xyz, r2.xyzx, l(255.000000, 255.000000, 255.000000, 0.000000)
2170:   add r3.xyz, -r4.xyzx, l(1.000000, 1.000000, 1.000000, 0.000000)
2171:   mul r2.xyz, r2.xyzx, r3.xyzx
2172:   mad r2.xyz, r2.xyzx, r0.xxxx, r5.xyzx
2173:   mad o0.xyz, r1.xyzx, r0.yzwy, r2.xyzx
2174: else
2175:   mov o0.xyz, r1.xyzx
2176: endif
2177: mov o1.z, l(1.000000)
2178: ret
