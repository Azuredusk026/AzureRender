"""Repeat the measured probe until a baseline ground-reflection change is present."""
import json
from pathlib import Path
import runpy
import sqlite3
import subprocess
import sys
from zipfile import ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
body=runpy.run_path(str(M/'joint-character-referenced-body.py'),run_name='reflection_storage_camera')
glsl=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='reflection_storage_catalog')
R,B=glsl['R'],glsl['B']
H,art,check,read,write,sha=[glsl[k] for k in ('H','art','check','read','write','sha')]
C=M/'joint-character-referenced-body'
O=M/'joint-intel-reflection-source-probe'
variants=tuple('mesh_object_clipmap_field'+suffix+'.frag.spv' for suffix in ('','_early','_lighting','_early_lighting'))
glsl['activate_links'].__wrapped__.__globals__['home']=O
assert body['OUT']==C
old='''    vec3 qaColor = beautyColor;
    if (qaIsolationMode == 1) {'''
new='''    vec3 qaColor = beautyColor;
#if !defined(AZURE_OPAQUE_SNAPSHOT)
        vec2 probe = AZURE_FRAGMENT_COORD.xy;
        if (qaIsolationMode==0 && camera.screenReflectionTrace.x>1.5 &&
            all(greaterThanEqual(probe,vec2(0))) && probe.x<640 && probe.y<360) {
            ivec2 origin=ivec2(probe)*2;
            uint signature=2166136261U;
            for (int tap=0;tap<4;++tap) {
                uvec4 sampleBits=floatBitsToUint(texelFetch(opaqueSceneColor,origin+ivec2(tap%2,tap/2),0));
                for (int channel=0;channel<4;++channel)
                    signature=(signature^sampleBits[channel])*16777619U;
            }
            // Mix the upper bits of expanded half-float inputs before encoding 18 bits.
            signature^=signature>>16;
            signature*=2246822519U;
            signature^=signature>>13;
            signature*=3266489917U;
            signature^=signature>>16;
            qaColor=vec3(.12)+vec3(signature&63U,(signature>>6)&63U,(signature>>12)&63U)*(.58/63.);
        }
        // Keep the reflection comparisons off the opaque source reporting area.
        probe.x-=640.;
        if (qaIsolationMode==0 && camera.screenReflectionTrace.x>1.5 && all(greaterThanEqual(probe,vec2(0)))
            && probe.x<576 && probe.y<72) {
            int lane=int(probe.x)/96;
            int kind=lane%3;
            vec2 anchor=vec2(mod(probe.x,96),probe.y)+vec2(896,lane>=3 ? 160 : 608);
            vec4 sampleValue=sampleComputedScreenReflection(anchor/vec2(textureSize(opaqueSceneColor,0)));
            qaColor=kind==1 ? vec3(clamp(sampleValue.a,0,1))
                    : max(vec3(0),sampleValue.rgb)/(vec3(1)+max(vec3(0),sampleValue.rgb));
            if (kind==2) {
                vec4 surface=texelFetch(overlaySceneDepth,ivec2(anchor),0);
                qaColor=vec3(clamp(surface.r/(32+surface.r),0,1),surface.gb);
            }
        }
#endif
    if (qaIsolationMode == 1) {'''


def source_input():
    p=W/'shaders/mesh.frag'
    s=p.read_text(encoding='utf8')
    assert s.count(old)==1
    assert 'layout(rgba32f,binding=37) uniform readonly image2D computedScreenReflection;' in s
    baseline=subprocess.check_output(['git','show','75837a6:Project/AzureRender/shaders/mesh.frag'],cwd=W,encoding='utf8')
    assert s==baseline
    rule={entry['output']:entry['defines'] for entry in read(R/'msaa-release/shader-reload.json')['programs']}
    assert all(set(rule[k])>={'AZURE_IRRADIANCE_CLIPMAP=1','AZURE_PROBE_FIELD=1'} for k in variants)
    return p,s.replace(old,new)


def run():
    from hashlib import sha256
    from zipfile import ZIP_DEFLATED
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    assert check(B,run=M,planned=5_900_000)['allowed']
    E=W/'docs/acceptance/nr/evidence/2026-11-16/joint-intel-reflection-opaque-input'
    q=read(E/'qualification.json')
    assert sha(E/'validation.zip')==q['archiveSha256']
    ref=cv2.imread(str(M/'character-six-view-inputs/intel-back-detail/frames/frame_000000.png'),cv2.IMREAD_UNCHANGED)
    assert ref.shape==(720,1280,4)
    with ZipFile(E/'validation.zip') as z, ZipFile(__import__('io').BytesIO(z.read('b/frame-xor.zip'))) as iz:
        control=ref^np.frombuffer(iz.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
    assert sha256(control.tobytes()).hexdigest()==q['reads']['b']['frame']['raw']
    p,expected=source_input()
    src=O/'mesh.frag'
    assert src.read_text(encoding='utf8')==expected and sha(src)==q['diagnosticSource'] and sha(p)==q['source']
    programs=q['programs']
    assert all(sha(O/'programs'/k)==v for k,v in programs.items())
    core,assets,_=body['prepare']()
    assert core['player']==q['player']
    with art.database(B) as c:
        pinned=art.rows(c)[R.name]
    assert pinned['status']=='closed'
    records=[]
    score_path=O/'known-floor-witnesses.json'
    art.resume(B,R.name)
    try:
        with glsl['activate_links'](programs),body['temporary_descriptor'](assets[1]) as descriptor:
            for i in range(1,6):
                assert check(B,run=M,planned=2_250_000)['allowed']
                tag=f'opaque-source-floor-{i}'
                completed=body['capture']('intel',tag,descriptor)
                tiled=C/f'intel-{tag}.zip'
                assert sha(tiled)==completed['archive']
                with ZipFile(tiled) as z:
                    frame=ref^np.frombuffer(z.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
                assert sha256(frame.tobytes()).hexdigest()==completed['raw']
                delta=control^frame
                target=C/f'intel-{tag}-vs-probe-b.zip'
                with ZipFile(target,'x',ZIP_DEFLATED,compresslevel=9) as z:
                    z.writestr('frame.bgra-xor',delta.tobytes())
                with ZipFile(target) as z:
                    assert z.testzip() is None
                    recovered=control^np.frombuffer(z.read('frame.bgra-xor'),np.uint8).reshape(ref.shape)
                    assert np.array_equal(recovered,frame)
                assert tiled.resolve()==tiled and tiled.parent==C and not tiled.stat().st_file_attributes&1024
                tiled.unlink()
                diff=np.max(np.abs(frame.astype(np.int16)-control),axis=2)
                tiles={'opaqueSource':np.s_[:360,:640],
                       'groundReflectionRgb':np.s_[:72,640:736],
                       'groundConfidence':np.s_[:72,736:832],
                       'groundSurfaceProbe':np.s_[:72,832:928],
                       'upperReflectionRgb':np.s_[:72,928:1024],
                       'upperReflectionConfidence':np.s_[:72,1024:1120],
                       'upperSurfaceProbe':np.s_[:72,1120:1216],
                       'groundBeauty':np.s_[608:680,896:992],
                       'upperBeauty':np.s_[160:232,896:992]}
                checks={key:dict(pixels=int(np.count_nonzero(diff[slice])),peak=int(diff[slice].max()))
                        for key,slice in tiles.items()}
                scores=checks['groundBeauty']['pixels']
                kind='ground-reproduced' if scores>0 else 'ground-stable'
                entry=dict(name=tag,frame=completed,archive=sha(target),deltaDonor=q['reads']['b']['frame']['raw'],
                           state=kind,checks=checks)
                records.append(entry)
                write(score_path,dict(status=kind,player=core['player'],programs=programs,records=records))
                print(tag,kind,checks,flush=True)
                if scores:
                    break
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=90)
    with art.database(B) as c:
        result=art.rows(c)[R.name]
    assert result['status']=='closed' and result['manifestSha256']==pinned['manifestSha256']


if __name__=='__main__':
    run()
