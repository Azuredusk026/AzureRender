"""Read three opaque wall contribution signatures while preserving its color."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import runpy
import subprocess
import sys
from zipfile import ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
C=M/'joint-character-referenced-body'
O=M/'joint-intel-opaque-wall-source-color-and-input-groups'
g=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='wall_owner_catalog')
H,R,B,art,check,read,write,sha=[g[k] for k in ('H','R','B','art','check','read','write','sha')]
body=runpy.run_path(str(M/'joint-character-referenced-body.py'),run_name='wall_owner_body')
g['activate_links'].__wrapped__.__globals__['home']=O
scene=tuple('mesh_object_clipmap_field'+suffix+'.frag.spv' for suffix in ('','_early','_lighting','_early_lighting'))
snap=tuple('character_snapshot'+obj+'_clipmap_field'+suffix+'.frag.spv'
           for obj in ('','_object') for suffix in ('','_early','_lighting','_early_lighting'))


def substitute(s,old,new):
    assert s.count(old)==1,old
    return s.replace(old,new)


def template():
    p=M/'wall-probe-original-mesh.frag'
    assert sha(p)=='2df45c56e9f58a3b6bb18ade2ae2796f6cbab336be2e6a84a0953fde08101fd3'
    s=p.read_text(encoding='utf8')
    s=substitute(s,'''    vec3 qaColor = beautyColor;
    if (qaIsolationMode == 1) {''','''    vec3 qaColor = beautyColor;
#if !defined(AZURE_OPAQUE_SNAPSHOT)
    vec2 probe=AZURE_FRAGMENT_COORD.xy;
    if(qaIsolationMode==0 && camera.screenReflectionTrace.x>1.5 &&
       all(greaterThanEqual(probe,vec2(0))) && probe.x<480 && probe.y<72) {
        if(probe.x<288){
            uint lane=uint(floor(probe.x/96.));
            ivec2 source=ivec2(mod(probe.x,96.),probe.y)+ivec2(896,160);
            float markerAlpha=texelFetch(opaqueSceneColor,source,0).a;
            uint code=uint(max(floor(markerAlpha+.5)-16.,0.));
            uint digit=(code>>(3U*lane))&7U;
            const float levels[8]=float[8](.023,.05,.095,.165,.275,.435,.665,.99);
            qaColor=vec3(levels[digit]);
        }else if(probe.x>=384.){
            ivec2 source=ivec2(probe.x-384.,probe.y)+ivec2(896,160);
            vec3 color=max(vec3(0),texelFetch(opaqueSceneColor,source,0).rgb);
            qaColor=color/(vec3(1)+color);
        }else{
            uint digit=uint(floor((probe.x-288)/12.));
            const float levels[8]=float[8](.023,.05,.095,.165,.275,.435,.665,.99);
            qaColor=vec3(levels[digit]);
        }
    }
#endif
    if (qaIsolationMode == 1) {''')
    s=substitute(s,'''void main()''','''uint wallProbeHash(uint seed,vec3 value) {
    uvec3 v=floatBitsToUint(value);
    seed=(seed ^ v.r)*0x9e3779b1U;
    seed=(seed ^ v.g)*0x85ebca77U;
    seed=(seed ^ v.b)*0xc2b2ae3dU;
    return seed^(seed>>16);
}
void main()''')
    s=substitute(s,'''    if(AZURE_MATERIAL_CLASS==2U)outputColor.a=2.0;
    vec3 snapshotNormal=shadedNormal;''','''    if(AZURE_MATERIAL_CLASS==2U)outputColor.a=2.0;
    ivec2 source=ivec2(AZURE_FRAGMENT_COORD.xy);
    if((material.materialPadding>>1U)==307U&&
       all(greaterThanEqual(source,ivec2(896,160)))&&all(lessThan(source,ivec2(992,232)))) {
        uint tex=wallProbeHash(0x4ca9bc12U,baseColor.rgb);
        tex=wallProbeHash(tex,normalSample.xyz);
        tex=wallProbeHash(tex,vec3(roughness,metallic,outputAlpha));
        tex=wallProbeHash(tex,emissive);
        uint direct=wallProbeHash(0xad5e8bb1U,directDiffuse);
        direct=wallProbeHash(direct,directSpecular);
        direct=wallProbeHash(direct,rimLighting);
        uint indirect=wallProbeHash(0x153e54e9U,ambientDiffuse);
        indirect=wallProbeHash(indirect,ambientSpecular);
        outputColor.a=float(16U+(tex&7U)+((direct&7U)<<3U)+((indirect&7U)<<6U));
    }
    vec3 snapshotNormal=shadedNormal;''')
    return p,s


def run():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    budget=check(B,run=M,planned=11_000_000)
    assert budget['allowed'],budget
    p,s=template()
    (O/'programs').mkdir(parents=True,exist_ok=True)
    modified=O/'mesh.frag'
    modified.write_text(s,encoding='utf8')
    rules={p['output']:p for p in read(R/'msaa-release/shader-reload.json')['programs']}
    programs={}
    for name in scene+snap:
        assert 'AZURE_PROBE_FIELD=1' in rules[name]['defines']
        H['compile_program'](modified,O/'programs'/name,name,diagnostics=O/'compile'/f'{name}.log')
        programs[name]=sha(O/'programs'/name)
    original_spatial=W/'shaders/spatial_antialiasing.frag'
    spatial=original_spatial.read_text(encoding='utf8')
    spatial=substitute(spatial,'    if(resolve.options.x>1.5){','''    if(gl_FragCoord.x<480.0&&gl_FragCoord.y<72.0){
        ivec2 extent=textureSize(linearSource,0);
        ivec2 pixel=clamp(ivec2(screenUv*vec2(extent)),ivec2(0),extent-1);
        value=texelFetch(linearSource,pixel,0).rgb;
    }else if(resolve.options.x>1.5){''')
    spatial_source=O/'spatial_antialiasing.frag'
    spatial_source.write_text(spatial,encoding='utf8')
    label='spatial_antialiasing.frag.spv'
    spatial_binary=O/'programs'/label
    H['compile_program'](spatial_source,spatial_binary,label,diagnostics=O/'compile'/f'{label}.log')
    programs[label]=sha(spatial_binary)
    ref_path=M/'character-six-view-inputs/intel-back-detail/frames/frame_000000.png'
    ref=cv2.imread(str(ref_path),cv2.IMREAD_UNCHANGED)
    assert ref.shape==(720,1280,4)
    paired=W/'docs/acceptance/nr/evidence/2026-11-16/joint-intel-reflection-ground-paired-panels'
    q=read(paired/'qualification.json')
    assert sha(paired/'validation.zip')==q['archiveSha256']
    original=[]
    with ZipFile(paired/'validation.zip') as z:
        for tag in q['groundPair']:
            with ZipFile(BytesIO(z.read(f'{tag}/frame-xor.zip'))) as zz:
                actual=ref^np.frombuffer(zz.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
            assert sha256(actual.tobytes()).hexdigest()==q['reads'][tag]['frame']['raw']
            original.append(actual)
    relevant=np.any(original[0][:72,288:384]!=original[1][:72,288:384],axis=2)
    assert relevant.sum()==456
    core,assets,_=body['prepare']()
    assert core['player']==q['player']
    with art.database(B) as db:
        pinned=art.rows(db)[R.name]
    assert pinned['status']=='closed'
    images={}
    comparison={}
    ids={}
    art.resume(B,R.name)
    try:
        with g['activate_links'](programs),body['temporary_descriptor'](assets[1]) as descriptor:
            for label in ('a','b','c','d','e'):
                name=f'opaque-wall-source-color-and-inputs-{label}'
                row=body['capture']('intel',name,descriptor)
                path=C/f'intel-{name}'
                manifest=read(path/'frames/capture_manifest.json')
                assert manifest['qaIsolation']=='beauty' and manifest['screenReflectionProducer']=='linear-temporal'
                assert manifest['irradianceResourceKind']=='clipmap' and manifest['objectShadowPrepared']
                with ZipFile(C/f'intel-{name}.zip') as z:
                    frame=ref^np.frombuffer(z.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
                assert sha256(frame.tobytes()).hexdigest()==row['raw']
                legend=[]
                for i in range(8):
                    stripe=frame[:72,288+i*12:300+i*12,:3]
                    rgb,n=np.unique(stripe.reshape((-1,3)),axis=0,return_counts=True)
                    best=np.argmax(n)
                    assert n[best]>=200,(label,i,int(n[best]))
                    legend.append(rgb[best])
                legend=np.asarray(legend)
                assert all(len(np.unique(legend[:,channel]))==8 for channel in range(3)),legend
                valid=np.ones((72,96),bool)
                decoded=np.zeros((72,96),dtype=np.int16)
                for digit in range(3):
                    tile=frame[:72,digit*96:(digit+1)*96,:3].astype(np.int16)
                    bins=np.max(np.abs(tile[:,:,None,:]-legend[None,None,:,:]),axis=3)
                    nearest=np.sort(bins,axis=2)[:,:,:2]
                    valid&=(nearest[:,:,0]<=10)&(nearest[:,:,1]-nearest[:,:,0]>=5)
                    decoded+=bins.argmin(axis=2).astype(np.int16)<<(3*digit)
                decoded+=16
                decoded[~valid]=-1
                verified=relevant&(decoded>=16)&(decoded<528)
                print(label,'qualified colors',int(verified.sum()),'legend',legend.tolist(),flush=True)
                assert verified.sum()==456,(label,int(verified.sum()))
                group_codes=decoded[verified]-16
                groups={name:np.bincount((group_codes>>(3*i))&7,minlength=8).tolist()
                        for i,name in enumerate(('materialTextures','directLighting','indirectLighting'))}
                images[label]=frame
                ids[label]=decoded
                data=dict(outputs=row,matchedDisputedPixels=int(verified.sum()),signatureHistograms=groups)
                comparison[label]=data
                write(O/'witness.json',dict(status='capturing',results=comparison))
                print(label,groups,flush=True)
                compare_pair=next((k for k in images if k!=label and
                    not np.array_equal(frame[608:680,896:992],images[k][608:680,896:992]) and
                    not np.array_equal(frame[:72,384:480],images[k][:72,384:480])),None)
                if compare_pair:
                    break
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=320)
    with art.database(B) as db:
        end=art.rows(db)[R.name]
    assert end['status']=='closed' and end['manifestSha256']==pinned['manifestSha256']
    stats=None
    if compare_pair:
        previous,current=[ids[k] for k in (compare_pair,label)]
        coverage=relevant&(previous>=16)&(current>=16)
        coverage&=(previous<528)&(current<528)
        assert np.count_nonzero(coverage)==456
        differences=(previous-16)^(current-16)
        changed={name:int(np.count_nonzero(coverage&(((differences>>(3*i))&7)!=0)))
                 for i,name in enumerate(('materialTextures','directLighting','indirectLighting'))}
        a,b=[images[k] for k in (compare_pair,label)]
        source_delta=np.any(a[:72,384:480]!=b[:72,384:480],axis=2)
        measured_change=coverage&source_delta
        assert np.count_nonzero(measured_change)>100
        scoped={name:int(np.count_nonzero(measured_change&(((differences>>(3*i))&7)!=0)))
                for i,name in enumerate(('materialTextures','directLighting','indirectLighting'))}
        stats=dict(labels=[compare_pair,label],changedSignatures=changed,
                   changedSourceSignatures=scoped,pairedPixels=int(np.count_nonzero(coverage)),
                   sourceRgbChanged=int(np.count_nonzero(source_delta)),
                   pairedChangedSource=int(np.count_nonzero(measured_change)),
                   groundBeautyChanged=int(np.count_nonzero(np.any(a[608:680,896:992]!=b[608:680,896:992],axis=2))),
                   upperBeautyChanged=int(np.count_nonzero(np.any(a[160:232,896:992]!=b[160:232,896:992],axis=2))))
    d=dict(status='measured-opaque-wall-inputs-with-ground-wave',sampleResults=comparison,paired=stats,
           shaderPrograms=programs,source=sha(p),modifiedSource=sha(modified),displayProbeSource=sha(spatial_source))
    write(O/'qualification.json',d)


if __name__=='__main__':
    run()
