"""Measure native unsigned output precision on the current iris with all overlays composed."""
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
B=W/'build'
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
G=M.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
C=R/'face-quality-release-isolated-mask'
F=G/'iris-overlay-geometry-project'
mode='covered-iris-and-unsigned-output'
O=M/'readonly-iris-prepack-blue-transport-srgb'
old_player=M/'projected-history-layer-release/AzurePlayerCaptureFaceFixture.exe'
environment=('AZR_NR_QA_OVERLAY_ROOT','AZR_NR_QA_OVERLAY_SCENE')
tag='face-quality-native-production-combined'
variants=tuple(f'mesh{obj}{ending}.frag.spv' for obj in ('','_object')
        for ending in ('','_early','_lighting','_early_lighting','_uvquad','_coverage_uvquad'))
hash_path=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
def write(p,d):
    p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')


def fixture_sources():
    source=C/'public-combined-nvidia'
    exact=read(source/'results.json')['input']['fixture']
    assert exact==read(C/'public-combined-intel/results.json')['input']['fixture']
    mask=source/'recipe/mask/inputs'
    nearest=source/'recipe/nearest/inputs'
    base_mask=M/'assets-sdf/face-native-geometry-mask-sampling-sdf.dds'
    files={}
    for k,v in exact.items():
        relative=Path(k)
        name=relative.name
        if k.startswith('scene/') or relative.parent==Path('.'):
            p=source/name
        elif name.endswith('public-mask.dds'):
            p=base_mask
        elif name.startswith('face-quality-public-mask.'):
            p=mask/name
        elif name.startswith('face-quality-public-nearest.'):
            p=nearest/name
        else:
            p=R/'face-candidate'/name
        assert hash_path(p)==v,(p,v)
        if relative.parent!=Path('.'):
            files[k]=p
    files[f'scene/{tag}.azurelevel.azmeta']=source/(tag+'.azurelevel.azmeta')
    for name in ('late-face-overlay-1230','late-face-overlay-1358'):
        key=f'character/{name}.bin.azmeta'
        assert (F/key).is_file()
        files[key]=F/key
    data=read(files[f'scene/{tag}.azurelevel'])
    rewrites={}
    for resource in data['resources']:
        value=resource['asset']
        if value.startswith('character:/late-face-overlay-'):
            resource['asset']='qa_'+value
            rewrites[value]=resource['asset']
    assert len(rewrites)==2
    before_id='f919b7a6-ca12-5772-b0e2-83cd5b5a046a'
    after_id='4bbdeb78-3dd1-5fe4-b5ba-b4a911b6071b'
    before=F/'materials'/f'{before_id}.azurematerial'
    after=F/'materials/face-iris-public-main-frame.azurematerial'
    field=lambda material:material['surface']['materials'][0]['extras']['azureRenderMaterial']['eyeSurface']['lightingInputs']
    base=read(before)
    change=field(read(after))['mainRampFrame']
    assert 'mainRampFrame' not in field(base)
    assert change==dict(schemaVersion=1,node='capture_material_frame_10401',basis=[1,0,0,0,1,0,0,0,1])
    field(base)['mainRampFrame']=change
    assert base==read(after)
    meta=after.with_name(after.name+'.azmeta')
    assert read(meta)['id']==after_id
    hero,=[node for node in data['nodes'] if node['id']=='hero']
    key='name:M_actor_laevat_iris_01'
    assert hero['materialSlots'][key]==before_id
    hero['materialSlots'][key]=after_id
    removed=[n for n in data['nodes'] if n['id']=='native-eye-shadow']
    assert len(removed)==1 and removed[0]['resourceId']=='native-eye-shadow'
    data['nodes']=[n for n in data['nodes'] if n['id']!='native-eye-shadow']
    return files,data,dict(disabledEyeShadow=True,resourcePaths=rewrites,irisLightFrame=dict(before=before_id,after=after_id,
                         oldMaterial=hash_path(before),authoredMaterial=hash_path(after),authoredMeta=hash_path(meta),frame=change))


def collect_sources():
    shader='Project/AzureRender/shaders/mesh.frag'
    r=read(C/'test-receipt.json')
    canonical=subprocess.check_output(['git','show','3923ae9:'+shader],cwd=W)
    assert r['shaderSource'] in {sha256(canonical).hexdigest(),sha256(canonical.replace(b'\n',b'\r\n')).hexdigest()}
    source=canonical.decode()
    prior=runpy.run_path(str(M/'iris-matcap-projective-player.py'),run_name='combined_iris_projective_helper')
    native_model=read(M/'iris-matcap-projective-footprint.json')
    base_model=read(M/'iris-base-footprint-native-match.json')
    assert native_model['scope']==base_model['scope']==255
    assert all(result['mipMatchesAnalytic']==255 for result in native_model['devices'].values())
    assert base_model['methods']['Finediagonal']['matches']['nvidia']==255
    eye_path=F/'materials/f919b7a6-ca12-5772-b0e2-83cd5b5a046a.azurematerial'
    eye_material=read(eye_path)
    surface=eye_material['surface']
    sampler_index=surface['materials'][0]['pbrMetallicRoughness']['baseColorTexture']['index']
    asset=eye_material['textures'][str(surface['textures'][sampler_index]['source'])]['asset']
    settings=read(F/'materials'/f'{asset}.dds.azmeta')['settings']['texture']
    assert (settings['mipBias'],settings['mipFilter'],settings['filter'],settings['anisotropy'])==(-1,'nearest','linear',1)
    source=source.replace('void main()\n','#include "texture_footprint.glsl"\n'+prior['helper']+'void main()\n',1)
    eyes='    CharacterEyeCoordinates eyeCoordinates;'
    base='        baseColor=texture(AZ_TEX_BASE_COLOR,eyeCoordinates.baseUv);'
    matcap='        eyeMatcap=eyeNpr?texture(AZ_TEX_MATCAP,eyeCoordinates.matcapUv):textureLod(AZ_TEX_MATCAP,eyeCoordinates.matcapUv,0.0);'
    assert source.count(eyes)==source.count(base)==source.count(matcap)==1
    source=source.replace(eyes,eyes+'\n    vec4 projectedEyeMatcap=vec4(0);')
    source=source.replace(base,'''        vec2 baseUv=eyeCoordinates.baseUv;
        vec2 baseExtent=vec2(textureSize(AZ_TEX_BASE_COLOR,0));
        float baseLod=azureAxisDiagonalMipLod(dFdxFine(baseUv)*baseExtent,dFdyFine(baseUv)*baseExtent);
        baseColor=textureLod(AZ_TEX_BASE_COLOR,baseUv,floor(baseLod+.5));
        mat2 footprint=projectedMatcapGradients(originalUv,worldNormal,worldTangent,worldToView,
            eyeProfile.shape.y,eyeCoordinates.matcapUv);
        projectedEyeMatcap=textureGrad(AZ_TEX_MATCAP,eyeCoordinates.matcapUv,footprint[0],footprint[1]);''')
    source=source.replace(matcap,matcap.replace('texture(AZ_TEX_MATCAP,eyeCoordinates.matcapUv)','projectedEyeMatcap'))

    before='    outputColor=azureMaterialOutputPrecision(outputColor,materialFeatureEnabled(67108864U)>.5);'
    after='    outputColor=azureMaterialOutputPrecision(outputColor,materialFeatureEnabled(67108864U)>.5 || (eyeRadial&&qaIsolationMode==0));'
    assert source.count(before)==1
    edited=source.replace(before,after)
    packets='''#if !defined(AZURE_OPAQUE_SNAPSHOT)
    if (eyeRadial && qaIsolationMode == 0) {
        ivec2 p = ivec2(AZURE_FRAGMENT_COORD.xy);
        uint word = floatBitsToUint(qaColor.b) >> 8u;
        uvec3 code = uvec3(word & 255u, (word >> 8u) & 255u, word >> 16u);
        if (p == ivec2(1252,255)) code = uvec3(17,127,231);
        if (p == ivec2(1253,255)) code = uvec3(23,115,239);
        vec3 displayCode = vec3(code) / 255.0;
        outputColor.rgb = mix(displayCode / 12.92, pow((displayCode + 0.055) / 1.055, vec3(2.4)),
                              greaterThan(displayCode, vec3(0.04045)));
    }
#endif'''
    prepared='    float innerOutlineParticipation ='
    assert edited.count(prepared)==1
    edited=edited.replace(prepared,packets+'\n'+prepared)
    return canonical,edited,r


def store_delta(dest,ref,candidate):
    p=dest/'frame-xor.zip'
    with ZipFile(p,'x',ZIP_DEFLATED,compresslevel=9) as out:
        out.writestr('frame.bgra-xor',np.bitwise_xor(ref,candidate).tobytes())
    with ZipFile(p) as out:
        assert out.testzip() is None
        restored=ref^np.frombuffer(out.read('frame.bgra-xor'),np.uint8).reshape(ref.shape)
        assert np.array_equal(restored,candidate)
    return hash_path(p)


def run():
    sys.path.insert(0,str(W/'tools'))
    import artifact_maintenance as art
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    budget=check(B,run=M,planned=9_500_000)
    assert budget['allowed'],budget
    build=read(M/'readonly-face-fixture-source/qualification.json')
    assert hash_path(old_player)==build['candidatePlayer'] and build['readOnlyProjectAssets']
    files,scene,rewrites=fixture_sources()
    O.mkdir(exist_ok=True)
    fixture=O/'fixture'
    for directory in ('scene','materials','character'):
        (fixture/directory).mkdir(parents=True,exist_ok=True)
    level=f'scene/{tag}.azurelevel'
    input_before={}
    for name,source in files.items():
        p=fixture/name
        input_before[str(source)]=hash_path(source)
        if name==level:
            write(p,scene)
        else:
            p.write_bytes(source.read_bytes())
            assert hash_path(p)==input_before[str(source)]
    canonical,edited,test=collect_sources()
    source=O/'mesh.frag'
    source.write_text(edited,encoding='utf8')
    headers=subprocess.check_output(['git','show','3923ae9:Project/AzureRender/shaders/unlit_blend.glsl'],cwd=W)
    (O/'unlit_blend.glsl').write_bytes(headers)
    original=O/'original-mesh.frag'
    original.write_bytes(canonical)
    programs=O/'programs'
    programs.mkdir(exist_ok=True)
    helpers=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='face_tint_program')
    compiler=helpers['H']['compile_program']
    for name in variants:
        compiler(source,programs/name,name,diagnostics=O/'compile'/f'{name}.log')
    resolve_source=W/'shaders/spatial_antialiasing.frag'
    spatial=resolve_source.read_text(encoding='utf8')
    anchor='    vec3 value;'
    assert spatial.count(anchor)==1
    spatial=spatial.replace(anchor,'''    if(gl_FragCoord.x>=1248.0&&gl_FragCoord.x<1316.0&&gl_FragCoord.y>=251.0&&gl_FragCoord.y<274.0){
        ivec2 extent=textureSize(linearSource,0);
        ivec2 pixel=clamp(ivec2(screenUv*vec2(extent)),ivec2(0),extent-1);
        outputColor=vec4(texelFetch(linearSource,pixel,0).rgb,1);
        return;
    }
'''+anchor)
    transport=O/'spatial_antialiasing.frag'
    transport.write_text(spatial,encoding='utf8')
    resolve='spatial_antialiasing.frag.spv'
    compiler(transport,programs/resolve,resolve,diagnostics=O/'compile'/f'{resolve}.log')
    active=variants+(resolve,)
    programs_changed={name:hash_path(programs/name) for name in active}
    os.environ['AZURE_NR_FACE_RELEASE_STAGE']=C.name
    catalog=runpy.run_path(str(R/'face-quality-candidate-catalog.py'),run_name='face_tint_checked_catalog')
    helper=runpy.run_path(str(R/'face-quality-production.py'),run_name='face_tint_capture_tool')
    invoke=helper['helper']['invoke']
    native_path=Path(helper['score']['reference_path'])
    native=cv2.imread(str(native_path),-1)
    face=cv2.imread(str(G/'native-face-masks/face.png'),0)>0
    eye=cv2.imread(str(G/'native-face-masks/iris.png'),0)>0
    assert native.shape[:2]==(1440,2560) and native.shape[2] in (3,4) and np.count_nonzero(face)==3663 and np.count_nonzero(eye)==255,(native.shape,np.count_nonzero(face),np.count_nonzero(eye))
    group=read(M/'public-face-remaining-owner-residual.json')
    region=[{tuple(item['point']) for item in group['devices'][k]['opaqueEdge'][1]['aboveEight']}
            for k in ('nvidia','intel')]
    x,y=np.array(sorted(set.intersection(*region))).T
    assert len(x)==49
    original_catalog=test['compiledPrograms']
    retained=catalog['retained_catalog'](R)
    baseline_shaders=retained|original_catalog
    assert set(programs_changed)<=set(baseline_shaders)
    with art.database(B) as data:
        pinned=art.rows(data)[R.name]
    assert pinned['status']=='closed'

    qualified=W/'docs/acceptance/nr/evidence/2026-11-16/face-combined-native-tint'
    measured=read(qualified/'qualification.json')
    assert hash_path(qualified/'validation.zip')==measured['archiveSha256']
    assert measured['executable']==hash_path(old_player) and measured['inputs']==input_before
    diagnostics={}
    for device in ('nvidia','intel'):
        prior=measured['samples'][f'{device}-control']
        reference=C/f'public-combined-{device}/frames/frame_000000.png'
        assert prior['changed']==0 and prior['png']==prior['control']==hash_path(reference)
        diagnostics[f'{device}-control']=prior
    out=O/'qualification.json'
    prior_paths={str(p):hash_path(p) for p in (
        F/'materials/f919b7a6-ca12-5772-b0e2-83cd5b5a046a.azurematerial',
        F/'materials/face-iris-public-main-frame.azurematerial',
        F/'materials/face-iris-public-main-frame.azurematerial.azmeta')}
    input_before.update(prior_paths)
    def capture(device,mode,root):
        assert check(B,run=M,planned=2_040_000)['allowed']
        reference=C/f'public-combined-{device}'
        control_path=reference/'frames/frame_000000.png'
        assert hash_path(control_path)==group['frames'][device]['candidate']
        ctrl=cv2.imread(str(control_path),-1)
        assert ctrl.shape[:2]==native.shape[:2] and ctrl.shape[2] in (3,4),ctrl.shape
        dest=O/f'{device}-{mode}'
        dest.mkdir()
        args=read(reference/'command.json')
        args[0]=str(old_player)
        for name,value in {'--project':F/'eye-shadow-authored-tint.azureproject',
                           '--resource-root':root,'--runtime-report':dest/'runtime.json',
                           '--capture-dir':dest/'frames'}.items():
            args[args.index(name)+1]=str(value)
        assert not any(k in os.environ for k in environment)
        os.environ.update(zip(environment,(str(fixture),tag+'.azurelevel')))
        try:
            frame=invoke(device,args,dest)/'frame_000000.png'
        finally:
            for k in environment:
                os.environ.pop(k,None)
        runtime=read(dest/'runtime.json')
        assert not runtime['scriptErrors'] and not runtime['presentationErrors']
        log=(dest/'player.log').read_text('utf8',errors='replace')
        assert 'Fixed-step capture fixture:' in log and 'Character texture access: fixed' in log
        before=read(reference/'frames/capture_manifest.json')
        after=read(dest/'frames/capture_manifest.json')
        for key in ('width','height','qaCamera','qaLight','screenReflectionProducer','objectShadowPrepared'):
            assert before.get(key)==after.get(key),key
        actual=cv2.imread(str(frame),-1)
        assert actual.shape==ctrl.shape
        delta=np.abs(actual[:,:,:3].astype(np.int16)-ctrl[:,:,:3]).max(2)
        base_error=np.abs(ctrl[:,:,:3].astype(np.int16)-native[:,:,:3]).max(2)
        error=np.abs(actual[:,:,:3].astype(np.int16)-native[:,:,:3]).max(2)
        row=dict(raw=sha256(actual.tobytes()).hexdigest(),png=hash_path(frame),control=hash_path(control_path),
                 deltaArchive=store_delta(dest,ctrl,actual),
                 changed=int(np.count_nonzero(delta)),outsideFace=int(np.count_nonzero(delta[~face])),
                 irisChanged=int(np.count_nonzero(delta[eye])),
                 face=dict(overOne=int(np.count_nonzero(error[face]>1)),overEight=int(np.count_nonzero(error[face]>8)),
                    peak=int(error[face].max()),newOverOne=int(np.count_nonzero((error[face]>1)&(base_error[face]<=1)))),
                 iris=dict(overOne=int(np.count_nonzero(error[eye]>1)),controlOverOne=int(np.count_nonzero(base_error[eye]>1)),
                           peak=int(error[eye].max()),controlPeak=int(base_error[eye].max()),
                           newOverOne=int(np.count_nonzero((error[eye]>1)&(base_error[eye]<=1))),
                           outsideIris=int(np.count_nonzero(delta[~eye]))))
        assert frame.resolve()==frame and not frame.stat().st_file_attributes&1024
        assert hash_path(frame)==row['png']
        frame.unlink()
        diagnostics[f'{device}-{mode}']=row
        write(out,dict(status='capturing',samples=diagnostics))
        print(device,mode,row,flush=True)
        points=np.fromfile(G/'native-iris-stages/points.bin','<u4').reshape(255,2)
        x,y=points.T
        payload=actual[y,x,2::-1].astype(np.uint32)
        calibration=payload[:2].tolist()
        assert calibration==[[17,127,231],[23,115,239]],calibration
        bits=(payload[:,0]|(payload[:,1]<<8)|(payload[:,2]<<16))<<8
        values=bits.view(np.float32)
        assert np.isfinite(values[2:]).all() and (values[2:]>=0).all() and values[2:].max()<10
        native_report=read(G/'native-iris-bottom-history/results.json')
        source_values={(r['x'],r['y']):r['shaderOut'][2]*.25 for r in native_report['shaderSamples']}
        rows=[]
        for i,pt in enumerate(points):
            if i<2:continue
            real=values[i].item()
            n=source_values[tuple(pt)]
            rows.append(dict(point=pt.tolist(),encoded=payload[i].tolist(),valueLow=real,
                             valueHigh=np.array([bits[i]+255],np.uint32).view(np.float32)[0].item(),
                             nativeShaderBlue=n,difference=real-n))
        row['blueLaneTransport']=dict(calibration=calibration,measured=len(rows),rows=rows)
        print('blue-lane',device,[r for r in rows if r['point'] in ([1308,266],[1253,259],[1254,259],[1251,262],[1261,262],[1256,265])],flush=True)
        write(out,dict(status='capturing',samples=diagnostics))

    art.resume(B,R.name)
    try:
        with catalog['activate'](original_catalog,alternate_run=M) as resources:
            replaced=[]
            try:
                for name in active:
                    target=resources/'shaders'/name
                    saved=target.with_name(target.name+'.face-tint-original')
                    assert hash_path(target)==baseline_shaders[name] and not saved.exists()
                    target.replace(saved)
                    replaced.append((target,saved))
                    target.hardlink_to(programs/name)
                    assert hash_path(target)==programs_changed[name]
                for device in ('nvidia','intel'):
                    capture(device,'native-tint',resources)
            finally:
                for target,saved in reversed(replaced):
                    assert hash_path(saved)==baseline_shaders[target.name]
                    saved.replace(target)
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=320)
    with art.database(B) as data:
        end=art.rows(data)[R.name]
    assert end['status']=='closed' and end['manifestSha256']==pinned['manifestSha256']
    assert all(hash_path(Path(p))==v for p,v in input_before.items())
    write(out,dict(status='measured-iris-blue-prepack-transport',calibrationPassed=True,
        executable=hash_path(old_player),inputs=input_before,pathRewrites=rewrites,
        source=hash_path(original),diagnosticSource=hash_path(source),transportSource=hash_path(transport),changedPrograms=programs_changed,tintConsumer=mode,samples=diagnostics))


if __name__=='__main__':
    run()
