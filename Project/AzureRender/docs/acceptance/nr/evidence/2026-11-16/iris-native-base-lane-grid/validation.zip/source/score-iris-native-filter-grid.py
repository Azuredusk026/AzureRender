"""Rank sampler interpolation models on held-out native iris fragments."""
import json
from hashlib import sha256
from pathlib import Path
import runpy

import numpy as np

M=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
api=runpy.run_path(str(M/'iris-native-filter-precision-model.py'),run_name='base_sampler_model')
q=M/'iris-native-base-lane-grid/results.json'
a=read(q)
assert a['status']=='qualified-dual-device-native-base-lanes'
points,matching=api['mip_candidates']()
assert a['points']==points
layers=api['load_layers']()
fold=np.array([(x*17431+y*3191)%7<2 for x,y in points])
assert 45<fold.sum()<95


def sampler_inputs(uv,image):
    size=len(image)
    fp=uv*size-.5
    xy=np.floor(fp).astype(int)
    x,y=xy.T
    fractional=fp-xy
    taps=np.stack([image[i%size,j%size,:3] for i,j in ((y,x),(y,x+1),(y+1,x),(y+1,x+1))],axis=1)
    return fractional,taps


def predict(fractional,taps,subtexel,rule,inputBits,output):
    v=fractional
    if subtexel:
        v=rule(v*2**subtexel)/2**subtexel
    x,y=v.T
    weights=np.column_stack(((1-x)*(1-y),x*(1-y),(1-x)*y,x*y))
    colors=taps
    if inputBits:
        k=2**inputBits
        colors=np.rint(colors*k)/k
    rgb=np.einsum('ij,ijk->ik',weights,colors)
    if output=='half':
        return rgb.astype(np.float16).astype(float)
    if output=='exact':
        return rgb
    output_bits=int(output.removeprefix('fixed'))
    k=2**output_bits
    return np.rint(rgb*k)/k


def summary(errors,use):
    p=errors[use]
    assert len(p)
    return dict(count=len(p),median=float(np.median(p)),p95=float(np.quantile(p,.95)),worst=float(p.max()),
                atMostOneOver255=int((p<=1/255).sum()),atMostOneIn1024=int((p<=1/1024).sum()))


def stats(dev,rec):
    assert rec['originalRestored']
    uv,raw=[np.column_stack([np.array(rec['lanes'][f'{key}-{i}']['values'])[:,1] for i in range(n)])
            for key,n in (('uv',2),('rgb',3))]
    chosen=matching[dev].sum(axis=1)==1
    assert (chosen&fold).sum()>40 and (chosen&~fold).sum()>130
    level=np.argmax(matching[dev],axis=1)
    support=np.zeros((len(uv),2))
    pixels=np.zeros((len(uv),4,3))
    for l,t in enumerate(layers):
        mask=level==l
        support[mask],pixels[mask]=sampler_inputs(uv[mask],t)
    rank=[]
    witness_raw={}
    for address in ([1308,266],[1255,258],[1261,262],[1260,262]):
        index=points.index(address)
        witness_raw[str(address)]=dict(point=address,value=raw[index].tolist(),uv=uv[index].tolist(),
                                       mipCandidates=np.flatnonzero(matching[dev][index]).tolist())
    for bits,rule in [(0,np.rint),*((i,r) for i in range(5,11) for r in (np.rint,np.floor,np.ceil))]:
        for inputBits in (0,8,10,12,14,16):
            for output in ('half','exact','fixed8','fixed10','fixed12','fixed14'):
                pred=predict(support,pixels,bits,rule,inputBits,output)
                errors=np.max(abs(pred-raw),axis=1)
                config=dict(subtexel=bits,rounding=rule.__name__,texelLinear=inputBits,output=output)
                rank.append(dict(model=config,fit=summary(errors,chosen&~fold),holdout=summary(errors,chosen&fold)))
    default,=[r for r in rank if r['model']==dict(subtexel=0,rounding='rint',texelLinear=0,output='exact')]
    rank.sort(key=lambda r:(r['fit']['p95'],r['fit']['median']))
    return dict(eligible=int(chosen.sum()),baseline=default,study=rank[:8],anchors=witness_raw)


res={dev:stats(dev,record) for dev,record in a['devices'].items()}
manifest=dict(status='ranked-native-iris-filter-candidates-on-held-out-points',measurement=digest(q),devices=res,
              scope='CPU filter matching on original device sampled base color; engine beauty acceptance is separate')
path=M/'iris-native-base-lane-grid/filter-grid-model.json'
path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
for device,r in res.items():
    print(device,r['baseline'],r['study'][0])
