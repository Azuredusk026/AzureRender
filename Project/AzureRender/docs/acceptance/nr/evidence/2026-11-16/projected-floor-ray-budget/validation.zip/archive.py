"""Archive the source-qualified, unmerged 32-step floor candidate and CPU witness."""
from difflib import unified_diff
from hashlib import sha256
import json
from pathlib import Path
import runpy
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

M=Path(__file__).resolve().parent
candidate=M/'projected-reflection-32-step-candidate.py'
cpu=M/'preview-projected-ray-step-cpu.py'
v=runpy.run_path(str(candidate),run_name='step_candidate')
src=v['sources']()
_,original,changed,_=v['variant_source'](src)
patch=''.join(unified_diff(original.splitlines(keepends=True),changed.splitlines(keepends=True),
                         fromfile='a/Project/AzureRender/shaders/projected_reflection_trace.hlsl',
                         tofile='b/Project/AzureRender/shaders/projected_reflection_trace.hlsl'))
assert sum(line.startswith('+float4') or line.startswith('+uint4') for line in patch.splitlines())==2
out=v['OUT']
read=v['READ']
cpu_output=read(out/'cpu-ray-search-preview.json')
depth=M/'native-floor-reflection-inputs/aligned-depth-preview.json'
check=read(depth)
assert check['status']=='provisional-later-native-depth'
assert src['baselineSteps']==128 and src['candidateMaximumSteps']==32
for region in ('centerFloor','cyanRing','archivedFloor'):
    e=cpu_output['regions'][region]
    assert e['controlVsCapturedGpu']['agreement']>=.98 and e['controlVsCapturedGpu']['onlyB']==0
    assert e['candidateVsNativeOutput']['agreement']>e['baselineVsNativeOutput']['agreement']
    assert e['candidateVsNativeOutput']['onlyB']<e['baselineVsNativeOutput']['onlyB']
assert all(check['orientationAtTwoMillimeters']['reverseRows'][k]>23000 for k in ('centerFloor','archivedFloor'))
files={'projected-step-candidate.patch':patch.encode('utf8'),
       'candidate-player.py':candidate.read_bytes(),
       'cpu-ray-search-preview.py':cpu.read_bytes(),
       'score-native-floor-reflection-inputs.py':(M/'score-native-floor-reflection-inputs.py').read_bytes(),
       'aligned-depth-preview.json':depth.read_bytes(),
       'archive.py':Path(__file__).read_bytes()}
target=M.parents[2]/'docs/acceptance/nr/evidence/2026-11-16/projected-floor-ray-budget'
target.mkdir(parents=True,exist_ok=True)
with ZipFile(target/'validation.zip','w',compression=ZIP_DEFLATED) as z:
    for name,data in sorted(files.items()):
        z.writestr(ZipInfo(name,(2026,11,16,0,0,0)),data,compress_type=ZIP_DEFLATED)
def sha(data):return sha256(data).hexdigest()
members={name:sha(data) for name,data in files.items()}
with ZipFile(target/'validation.zip') as z:
    assert z.testzip() is None and {name:sha(z.read(name)) for name in z.namelist()}==members
(out/'candidate.patch').write_bytes(files['projected-step-candidate.patch'])
result=dict(status='candidate-prepared-paired-player-pending',scope='projected joint scene',
            playerPairedCaptureJob=1274,nativeReadbackJob=1271,
            source=src,coordinateVerification=check['orientationAtTwoMillimeters'],
            cpuRaySearch=cpu_output,
            thresholds=dict(staticSsim=.95,medianRelativeLumaError=.1,frozenOriginalFourRgbMaximumByteDifference=0),
            archive=dict(sha256=sha((target/'validation.zip').read_bytes()),members=members))
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print('Verified single-factor candidate and three CPU ray-search rectangles')

