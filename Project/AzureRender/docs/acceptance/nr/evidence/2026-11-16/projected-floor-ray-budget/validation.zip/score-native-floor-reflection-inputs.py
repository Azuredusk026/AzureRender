"""Compare actual native display-floor reflection inputs in the same view."""
from hashlib import sha256
import json
from pathlib import Path
import sys

import numpy as np

M = Path(__file__).resolve().parent
OUT = M/'native-floor-reflection-inputs'
ROOT = Path('D:/Projects/FYP/Project/AzureRender')
BASE = ROOT/'build/runs'
VULKAN = BASE/'20261031-122504-projected-footprint-quality-5daf40/capture-inputs-v2'
NATIVE = BASE/'20261029-052336-native-hierarchical-reflection-52b603'
DEPTH = BASE/'20261028-155222-native-floor-reflection-source-9dcd8c'
REGIONS = dict(centerFloor=(505,495,775,585), cyanRing=(520,530,635,590),
               archivedFloor=(530,550,730,680))
CROP = (500,480,790,700)
STORAGE_CROP = (500,20,790,240)
PERCENT = (0,10,50,90,100)
FRAME = (720,1280)
read = lambda p: json.loads(p.read_bytes())
digest = lambda raw: sha256(raw).hexdigest()


def unpack(path, expected_hash, dtype, shape):
    raw = path.read_bytes()
    assert digest(raw) == expected_hash, path
    return np.frombuffer(raw, dtype=dtype).reshape(shape)


def cut(a, r):
    x,y,u,v = r
    return a[y:v,x:u]


def local(r):
    x,y,u,v = r
    l,t,rr,b = CROP
    assert l <= x < u <= rr and t <= y < v <= b
    return (x-l,y-t,u-l,v-t)


def rays(r):
    x,y,u,v = r
    xx,yy = np.meshgrid((np.arange(x,u)+.5)*2/FRAME[1]-1, (np.arange(y,v)+.5)*2/FRAME[0]-1)
    return np.stack([xx,yy], axis=-1)


def reconstruct(d, r, inverse):
    xy = rays(r)
    clip = np.concatenate((xy,d[...,None],np.ones_like(d[...,None])), axis=-1)
    v = clip @ inverse
    return v[...,:3] / v[...,3:]


def oct_decode(rg):
    x,z = np.moveaxis(rg.astype(np.float64)*2-1, -1, 0)
    y = 1-abs(x)-abs(z)
    a = np.where(y<0,np.where(x>=0,1,-1)*(1-abs(z)),x)
    b = np.where(y<0,np.where(z>=0,1,-1)*(1-abs(x)),z)
    vec = np.stack([a,y,b],axis=-1)
    return vec / np.linalg.norm(vec,axis=-1,keepdims=True)


def summary(a, m):
    return [float(x) for x in np.percentile(a[m], PERCENT)] if np.any(m) else None


def decode_reflected_color(words):
    channels = []
    for shift,mantissa in ((0,6),(11,6),(22,5)):
        v = words>>shift
        e = ((v>>mantissa)&31).astype(np.int32)
        m = (v&((1<<mantissa)-1))/float(1<<mantissa)
        assert np.all(e<31)
        channels.append(np.where(e==0,np.ldexp(m,-14),np.ldexp(1+m,e-15)))
    return np.stack(channels,axis=-1)


def correlation(a,b,m):
    return float(np.corrcoef(a[m],b[m])[0,1]) if np.count_nonzero(m)>2 and np.std(a[m])>0 and np.std(b[m])>0 else None


def subset(mask, nz, vz, nc, vc, nf, vf, nr=None, vr=None, angle=None):
    common = mask & (nc>0) & (vc>0)
    r = dict(samples=int(np.count_nonzero(mask)), nativeConfidence=summary(nc/255,mask),
             playerConfidence=summary(vc/255,mask), bothHit=int(np.count_nonzero(common)),
             nativeOnlyHit=int(np.count_nonzero(mask & (nc>0) & (vc==0))),
             playerOnlyHit=int(np.count_nonzero(mask & (vc>0) & (nc==0))),
             forwardMeters=dict(native=summary(nz,mask),player=summary(vz,mask), playerMinusNative=summary(vz-nz,mask)),
             bothHitLod=dict(native=summary(nf,common),player=summary(vf,common),playerMinusNative=summary(vf-nf,common)))
    if nr is not None:
        assert vr is not None and angle is not None
        r.update(roughness=dict(native=summary(nr,mask),player=summary(vr,mask),playerMinusNative=summary(vr-nr,mask)),
                 worldNormalAngleDegrees=summary(angle,mask))
    return r


def self_test(mats):
    region = (620,530,623,531)
    z = np.array([[2,10,40]], dtype=float)
    for mat in mats:
        xy = rays(region)
        d = (1/z-mat[3,3]-xy[...,0]*mat[0,3]-xy[...,1]*mat[1,3])/mat[2,3]
        assert np.all((d>0)&(d<1))
        v = reconstruct(d,region,mat)
        np.testing.assert_allclose(v[...,2], -z, atol=1e-12)
        h = np.concatenate((v,np.ones_like(v[...,:1])),axis=-1) @ np.linalg.inv(mat)
        np.testing.assert_allclose(h[...,:2]/h[...,3:],xy,atol=1e-12)
    expected = np.array([[0,1,0],[0,-1,0],[1,0,0],[0,0,-1]],dtype=float)
    np.testing.assert_allclose(oct_decode(np.array([[.5,.5],[1,1],[1,.5],[.5,0]])),expected)
    np.testing.assert_allclose(decode_reflected_color(np.array([0,960|(896<<11)|(512<<22),1],dtype=np.uint32)),
                               [[0,0,0],[1,.5,2],[2**-20,0,0]])


def main(provisional):
    vmeta = read(VULKAN/'summary.json')
    nmeta = read(NATIVE/'event-8702.json')
    native_vars = [[v['float32'] for v in block['variables']] for block in nmeta['blocks']]
    nmatrix = np.array(native_vars[0][12:16],dtype=float)
    vmatrix = np.array(vmeta['frameRows'][6:10], dtype=float)
    self_test((nmatrix,vmatrix))
    assert nmeta['event'] == 8702 and vmeta['event'] == 21668
    assert native_vars[2][0][:2] == vmeta['frameRows'][25][:2] == [1280,720]
    max_lod = native_vars[2][5][1]
    assert max_lod == vmeta['frameRows'][29][1] == 6
    # Camera direction and position agree after reflection of the world X axis.
    basis = np.array(native_vars[0][:3])[:,:3]*np.array([[-1],[1],[1]])
    player_basis = np.array(vmeta['frameRows'][:3])[:,:3]
    np.testing.assert_allclose(basis,player_basis,atol=5e-7)
    np.testing.assert_array_equal(np.array(native_vars[0][7][:3])*[-1,1,1],vmeta['frameRows'][22][:3])
    np.testing.assert_allclose(np.array(native_vars[0][8:11]),np.array(vmeta['frameRows'][3:6]),atol=2e-7)
    nref = read(ROOT/'docs/acceptance/nr/evidence/2026-10-29/native-ray-source/summary.json')
    ref = {d['resource']:d['referenceSha256'] for d in nref['payloads']}
    nc = cut(unpack(NATIVE/'reference-15781.bin',ref[15781],'u1',FRAME)[::-1],CROP)
    nf = cut(unpack(NATIVE/'reference-16501.bin',ref[16501],'<u2',(*FRAME,2))[::-1],CROP)[...,1]*max_lod/65535
    nl = decode_reflected_color(cut(unpack(NATIVE/'reference-15861.bin',ref[15861],'<u4',FRAME)[::-1],CROP))
    vm = {d['name']:d['data'] for d in vmeta['inputs']+vmeta['outputs'] if 'data' in d}
    def vulkan(name,dtype,components=0):
        source = vm[name]
        return cut(unpack(VULKAN/source['file'],source['sha256'],dtype,(*FRAME,components) if components else FRAME),CROP)
    vd = vulkan('currentDepth','<f4')
    vc = vulkan('outputConfidence','u1')
    vf = vulkan('outputFootprint','<u2',2)[...,1]*max_lod/65535
    vl = decode_reflected_color(vulkan('outputColor','<u4'))
    before = next(x for x in vmeta['files'] if x['file']=='confidence-before-dispatch.bin')
    vic = cut(unpack(VULKAN/before['file'],before['sha256'],'u1',FRAME),CROP)
    valid_v = vulkan('surfaceMask','u1')>127
    vmaterial = vulkan('normalRoughness','<f4',4)
    late_depth = next(z for z in read(DEPTH/'native-reflection-filter.json')['textures'] if z['id']==16447)['levels'][0]
    raw_late_depth = unpack(DEPTH/late_depth['path'],late_depth['sha256'],'<f4',FRAME)
    old = cut(raw_late_depth[::-1],CROP)
    if provisional:
        nd,nrough,angle,ground,nmask,nic = old,None,None,None,None,None
        readback = None
    else:
        readback = read(OUT/'results.json')
        assert readback['status'] == 'qualified' and readback['event'] == nmeta['event']
        assert tuple(readback['region']) == CROP and readback['capturedShader'] == nmeta['sha256']
        assert tuple(readback['storageRegion']) == STORAGE_CROP and readback['storageRows'] == 'reversed-to-display'
        nfmeta = {d['name']:d for d in readback['files']}
        def native(name, dtype):
            x,y,u,v = CROP
            return unpack(OUT/(name+'.bin'),nfmeta[name]['sha256'],dtype,(v-y,u-x))
        nd = native('current-depth','<f4')
        nmask = native('long-search-mask','u1')
        nic = native('initial-confidence','u1')
        assert nfmeta['trace-confidence']['fullSha256'] == ref[15781]
        np.testing.assert_array_equal(native('trace-confidence','u1'),nc)
        packed = native('normal-roughness','<u4')
        nrgb = np.stack(tuple((packed>>shift)&1023 for shift in (0,10,20)),axis=-1)/1023
        nrough = nrgb[...,2]
        nnormal = oct_decode(nrgb[...,:2])*[-1,1,1]
        vnormal = oct_decode(vmaterial[...,:2])
        angle = np.degrees(np.arccos(np.clip(np.sum(nnormal*vnormal,axis=-1),-1,1)))
        ground = (nnormal[...,1] >= .9) & (vnormal[...,1] >= .9)
    nz,vz = (-reconstruct(arr,CROP,mat)[...,2] for arr,mat in ((nd,nmatrix),(vd,vmatrix)))
    orientation_checks = {}
    for mode,raw in (('raw',raw_late_depth),('reverseRows',raw_late_depth[::-1]),
                     ('reverseColumns',raw_late_depth[:,::-1]),('reverseBoth',raw_late_depth[::-1,::-1])):
        candidate = -reconstruct(cut(raw,CROP),CROP,nmatrix)[...,2]
        strict = valid_v & (abs(candidate-vz)<=.002)
        orientation_checks[mode] = {k:int(np.count_nonzero(cut(strict,local(r)))) for k,r in REGIONS.items()}
    assert all(orientation_checks['reverseRows'][k]>orientation_checks[mode][k]
               for k in REGIONS for mode in ('raw','reverseColumns','reverseBoth'))
    valid = valid_v & np.isfinite(nz) & np.isfinite(vz) & (nd>0) & (nd<=1) & (vd>0) & (vd<=1)
    luma_weights = np.array([.2126,.7152,.0722])
    nl,vl = nl@luma_weights,vl@luma_weights
    assert np.all(np.isfinite(nl)) and np.all(np.isfinite(vl))
    def stats(region):
        r = local(region)
        ss = lambda a:cut(a,r)
        good = ss(valid)
        args = tuple(ss(a) for a in (nz,vz,nc,vc,nf,vf))
        n,v = args[:2]
        result = dict(halfRectangle=region, texels=int(good.size))
        extra = (None,None,None) if provisional else tuple(ss(a) for a in (nrough,vmaterial[...,2],angle))
        result['validDepth']=subset(good,*args,*extra)
        d = abs(n-v)
        result['matchedViewDepth']={str(t):subset(good&(d<=t),*args,*extra) for t in (.02,.05,.10,.20)}
        tight = good & (d<=.02)
        n_hit,v_hit = ss(nc)>0,ss(vc)>0
        common = tight & n_hit & v_hit
        a,b = ss(nl),ss(vl)
        result['traceLuma'] = dict(native=summary(a,common),player=summary(b,common),
                                   absoluteDelta=summary(abs(a-b),common),correlation=correlation(a,b,common))
        result['playerInitialEligibility'] = summary(ss(vic)/255,tight)
        if not provisional:
            likely_floor = ss(ground) & (ss(angle)<=10)
            result['depthAndUpwardNormal']={str(t):subset(good&likely_floor&(d<=t),*args,*extra)
                                          for t in (.02,.05,.10,.20)}
            result['nativeLongSearchMaskCount']=int(np.count_nonzero(ss(nmask)>127))
            n_on,v_on = ss(nic)>0,ss(vic)>0
            result['initialEligibility']=dict(both=int(np.count_nonzero(tight & n_on & v_on)),
                                              nativeOnly=int(np.count_nonzero(tight & n_on & ~v_on)),
                                              playerOnly=int(np.count_nonzero(tight & ~n_on & v_on)),
                                              nativeConfidence=summary(ss(nic)/255,tight),
                                              bothInitiallyEligibleNativeOnlyHit=int(np.count_nonzero(tight & n_on & v_on & n_hit & ~v_hit)),
                                              bothInitiallyEligiblePlayerOnlyHit=int(np.count_nonzero(tight & n_on & v_on & ~n_hit & v_hit)))
        return result
    result = dict(status='provisional-later-native-depth' if provisional else 'paired-actual-attachment-measurement',
                  nativeEvent=8702,nativeLaterSameResourceEvent=8811,playerEvent=21668,
                  cameraBasisMaximumAbsolute=abs(basis-player_basis).max(),
                  cameraProjectionMaximumAbsolute=abs(np.array(native_vars[0][8:11])-np.array(vmeta['frameRows'][3:6])).max(),
                  percentiles=PERCENT,maxLod=max_lod,region=CROP,
                  orientationAtTwoMillimeters=orientation_checks,
                  nativeLaterDepthSha256=late_depth['sha256'],sameDepthAsLater=np.array_equal(nd.view('<u4'),old.view('<u4')),
                  nativeReadback=readback,playerAttachmentSha256={k:vm[k]['sha256'] for k in
                  ('currentDepth','outputConfidence','outputFootprint','outputColor','surfaceMask','normalRoughness')},
                  playerInitialConfidenceSha256=before['sha256'],
                  nativeRayOutputSha256={str(k):ref[k] for k in (15781,16501,15861)},
                  regions={k:stats(r) for k,r in REGIONS.items()})
    OUT.mkdir(exist_ok=True)
    (OUT/('aligned-depth-preview.json' if provisional else 'aligned-results.json')).write_text(
        json.dumps(result,indent=2)+'\n',encoding='utf8')
    for k,s in result['regions'].items():
        source = s['matchedViewDepth'] if provisional else s['depthAndUpwardNormal']
        print(k,s['texels'],s['validDepth']['samples'],
              [(t,d['samples'],d['bothHit'],d['bothHitLod']['playerMinusNative'][2] if d['bothHit'] else None)
               for t,d in source.items()],flush=True)


if __name__ == '__main__':
    assert sys.argv[1:] in ([],['preview'])
    main(sys.argv[1:]==['preview'])

