"""Paired production Player captures for the projected-reflection ray budget."""
from hashlib import file_digest
import json
from pathlib import Path
import runpy
import subprocess
import sys

import cv2
import numpy as np

M = Path(__file__).resolve().parent
W = M.parents[2]
R = M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
G = M.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
MAIN = Path('D:/Projects/FYP/Project/AzureRender')
HOST = R/'msaa-release'
PLAYER = HOST/'AzurePlayer.exe'
PLAYER_SHA = '1a30d925a674ddb1d95876cb80181106a0217e12a7228a35b5980b134954cb69'
SHADER = 'projected_reflection_trace.comp.spv'
OUT = M/'projected-reflection-32-step-candidate'
FDIR = OUT/'programs'
PYTOOLS = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
ARGS = ['-spirv','-T','cs_6_0','-E','main','-HV','2018','-fspv-target-env=vulkan1.1',
        '-fvk-b-shift','0','0','-fvk-t-shift','1','0','-fvk-s-shift','8','0','-fvk-u-shift','9','0','-Od']
READ = lambda p: json.loads(p.read_bytes())
inputs_phase = runpy.run_path(str(M/'score-joint-native-floor.py'),run_name='step_budget_scoring')
score = inputs_phase['measure']
img = inputs_phase['img']
golden = READ(W/'docs/acceptance/nr/evidence/2026-11-16/joint-scene-native-floor/results.json')
regions = golden['rectangles']
forbid = ('qaCameraPosition','qaCameraTarget','cameraLens','cameraUp','gradeSettings','bloomSettings','nprLighting',
          'screenReflectionAlgorithmRequested','screenReflectionAlgorithm','screenReflectionProducer',
          'screenReflectionHistorySubmission','screenReflectionHistoryInputSubmission','screenReflectionLevels',
          'sceneTriangles','skinnedVertices','transparentTriangles','width','height','fps','capturedFrames')
catalog = runpy.run_path(str(R/'face-quality-candidate-catalog.py'))
invoke = runpy.run_path(str(G/'iris-production-frozen-recovery.py'))['invoke']


def sha(p):
    with p.open('rb') as s:
        return file_digest(s,'sha256').hexdigest()


def write(p,data):
    p.write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')


def sources():
    paired = MAIN/'build/runs/20261031-113415-projected-main-history-93cbc0'
    record, = [row for row in READ(paired/'full-projects.json') if row['kind']=='actor']
    project, level = (MAIN/record[k] for k in ('project','level'))
    assert sha(project)==record['projectSha256'] and sha(level)==record['levelSha256']
    settings = READ(level)['renderSettings']['screenSpaceReflection']
    assert settings['enabled'] and settings['algorithm']=='projected' and settings['maxSteps']==128
    native_path = MAIN/'build/runs/20261029-052336-native-hierarchical-reflection-52b603/event-8702.json'
    native = READ(native_path)
    assert native['sha256']=='9874977ebc47e87ed0a006b7bebd51f525126c4f584bc4a6abc95282ba291faa'
    block, = [x for x in native['blocks'] if x['variables'][0]['name']=='cb2_v0']
    v, = [x for x in block['variables'] if x['name']=='cb2_v3']
    native_steps = int(v['float32'][0])
    assert native_steps==32
    early = MAIN/'build/runs/20261031-122504-projected-footprint-quality-5daf40/capture-inputs-v2/summary.json'
    assert READ(early)['frameRows'][28][0]==settings['maxSteps']
    assert sha(PLAYER)==PLAYER_SHA and sha(HOST/'shaders'/SHADER)==catalog['retained_catalog'](R)[SHADER]
    assert sha(inputs_phase['replay'])==golden['frames']['gameBackbuffer']['sha256']
    return dict(project=str(project),projectSha256=record['projectSha256'],level=str(level),levelSha256=record['levelSha256'],
                nativeEvent=8702,nativeEventConstants=sha(native_path),playerShaderConstants=sha(early),
                baselineSteps=settings['maxSteps'],candidateMaximumSteps=native_steps,settings=settings,
                player=PLAYER_SHA,baselineShader=catalog['retained_catalog'](R)[SHADER],
                source=sha(W/'shaders/projected_reflection_trace.hlsl'))


def variant_source(provenance):
    source = W/'shaders/projected_reflection_trace.hlsl'
    text = source.read_text(encoding='utf8')
    assert text.count('stepConfig.xxxx')==2
    replacement = f'min(stepConfig.xxxx,{float(provenance["candidateMaximumSteps"]):.1f})'
    changed = text.replace('stepConfig.xxxx',replacement)
    assert changed.replace(replacement,'stepConfig.xxxx')==text
    return source,text,changed,replacement


def compile_candidate(provenance):
    # Rebuild the production source with the exact retained CMake DXC command.
    FDIR.mkdir(parents=True,exist_ok=True)
    control = OUT/'control.comp.spv'
    candidate = OUT/'projected_reflection_trace-32.hlsl'
    source,_,changed,replacement = variant_source(provenance)
    candidate.write_text(changed,encoding='utf8')
    out = FDIR/SHADER
    for a,b in ((source,control),(candidate,out)):
        subprocess.run([str(PYTOOLS/'dxc.exe'),*ARGS,'-Fo',str(b),str(a)],check=True,timeout=45)
        subprocess.run([str(PYTOOLS/'spirv-val.exe'),'--target-env','vulkan1.1',str(b)],check=True,timeout=45)
    assert sha(control)==provenance['baselineShader']
    assert sha(out)!=sha(control)
    return dict(source=sha(candidate),binary=sha(out),control=sha(control),
                compiler=sha(PYTOOLS/'dxc.exe'),arguments=ARGS,substitution=replacement)


def run_capture(device, mode, provenance, expected_shader):
    folder = OUT/(mode+'-'+device)
    record = folder/'result.json'
    previous = read_checkpoint(record,folder,expected_shader)
    if previous is not None:
        return previous
    if folder.exists():
        i=1
        while (OUT/(folder.name+f'-incomplete-{i}')).exists():
            i+=1
        folder.rename(OUT/(folder.name+f'-incomplete-{i}'))
    folder.mkdir()
    assert sha(HOST/'shaders'/SHADER)==expected_shader
    args = [str(PLAYER),'--project',provenance['project'],
            '--width','2560','--height','1440','--capture-fps','60','--capture-frames','3','--fixed-frame-step',
            '--qa-camera','scene','--qa-light','scene','--capture-dir',str(folder/'frames'),
            '--runtime-report',str(folder/'runtime.json'),'--resource-root',str(HOST)]
    frames = invoke(device,args,folder)
    manifest = READ(frames/'capture_manifest.json')
    gpu = READ(frames/'gpu_capabilities.json')
    assert (manifest['width'],manifest['height'],manifest['fps'],manifest['capturedFrames'])==(2560,1440,60,3)
    assert manifest['screenReflectionProducer']=='projected-history'
    assert manifest['screenReflectionHistoryValid'] and manifest['screenReflectionHistoryInputSubmission']==2
    assert (gpu['vendor_id'],gpu['device_id'])==((0x10de,0x28e0) if device=='nvidia' else (0x8086,0xa788))
    for metadata in ('qaCameraPosition','qaCameraTarget','cameraLens','cameraUp'):
        assert manifest[metadata]==golden['camera'][metadata], (metadata,manifest[metadata],golden['camera'][metadata])
    output = dict(device=device,mode=mode,driver=gpu['driver_version'],shader=expected_shader,
                  captureManifest=sha(frames/'capture_manifest.json'),runtime=sha(folder/'runtime.json'),
                  command=args,images=[sha(frames/f'frame_{i:06d}.png') for i in range(3)])
    write(record,output)
    print(device,mode,output['images'],flush=True)
    return output


def read_checkpoint(path,folder,fingerprint):
    if not path.is_file():
        return None
    r=READ(path)
    assert r['shader']==fingerprint and sha(folder/'frames/capture_manifest.json')==r['captureManifest']
    assert r['images']==[sha(folder/'frames'/f'frame_{i:06d}.png') for i in range(3)]
    return r


def measure_pair(device):
    fields=tuple(OUT/(x+'-'+device)/'frames' for x in ('baseline','candidate'))
    a,b = [READ(x/'capture_manifest.json') for x in fields]
    assert all(a[k]==b[k] for k in forbid)
    reference = img(inputs_phase['replay'])
    for f in fields:
        assert READ(f/'gpu_capabilities.json')['driver_version']==READ(fields[0]/'gpu_capabilities.json')['driver_version']
    def count(reference,control,candidate):
        before = abs(reference.astype(np.int16)-control).max(axis=2)
        after = abs(reference.astype(np.int16)-candidate).max(axis=2)
        return dict(baselineOverOne=int((before>1).sum()),candidateOverOne=int((after>1).sum()),
                    newlyOverOne=int(((before<=1)&(after>1)).sum()),recovered=int(((before>1)&(after<=1)).sum()),
                    changed=int(np.any(control!=candidate,axis=2).sum()))
    per_frame=[]
    for i in range(3):
        ctrl,cand=[img(x/f'frame_{i:06d}.png') for x in fields]
        result={}
        for name,(x,y,u,v) in regions.items():
            f,c,r=[src[y:v,x:u] for src in (ctrl,cand,reference)]
            result[name]=dict(baseline=score(f,r),candidate=score(c,r),pixels=count(r,f,c))
        per_frame.append(result)
    return per_frame


def assess(results):
    floors=('centerFloor','cyanRing')
    controls=('ceiling','leftDoor','rightWall','leftFloor')
    per=(frame for device in results.values() for frame in device['frames'])
    decisions=[]
    for frame in per:
        delta={k:v['candidate']['ssim']-v['baseline']['ssim'] for k,v in frame.items()}
        luma={k:v['candidate']['medianLumaRelativeError']-v['baseline']['medianLumaRelativeError'] for k,v in frame.items()}
        decisions.append(dict(ssimDelta=delta,medianLumaRelativeErrorDelta=luma,
            positive=all(delta[k]>0 and luma[k]<=0 for k in floors)
                     and all(delta[k]>=0 and luma[k]<=0 for k in controls)
                     and delta['complete']>=0, allFormalFloorGates=all(
                frame[k]['candidate']['ssim']>=.95 and frame[k]['candidate']['medianLumaRelativeError']<=.1
                for k in ('complete',*floors,*controls))))
    return dict(frames=decisions,allPairsPositive=all(row['positive'] for row in decisions),
                allFormalFloorGates=all(row['allFormalFloorGates'] for row in decisions),
                frozenOriginalFourRequired=True)


def run():
    lock=READ(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9'
    assert lock['state']=='held' and Path(lock['output'])==M
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    budget = check(M.parents[1],run=M,planned=37_000_000)
    assert budget['allowed'],budget
    provenance=sources()
    OUT.mkdir(exist_ok=True)
    p=compile_candidate(provenance)
    write(OUT/'candidate-receipt.json',dict(provenance=provenance,program=p))
    cv2.setNumThreads(1)
    results={}
    for device in ('nvidia','intel'):
        with catalog['activate']({},alternate_run=M):
            a=run_capture(device,'baseline',provenance,p['control'])
        with catalog['activate']({SHADER:p['binary']},alternate_run=M,source_dir=FDIR):
            b=run_capture(device,'candidate',provenance,p['binary'])
        results[device]=dict(baseline=a,candidate=b,frames=measure_pair(device))
        write(OUT/'checkpoint.json',results)
    assert sources()==provenance
    verdict=assess(results)
    write(OUT/'results.json',dict(status='qualified-measurement',scope='projected joint scene production pass',
                                  source=provenance,program=p,devices=results,verdict=verdict))
    print(json.dumps(dict(allPairsPositive=verdict['allPairsPositive'],formalFloorGates=verdict['allFormalFloorGates'])),flush=True)


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(json.dumps(sources()),flush=True)
    else:
        assert sys.argv[1:]==['run']
        run()

