"""CPU replay of the four-at-a-time ray-depth search on retained Vulkan attachments."""
import json
from pathlib import Path
import runpy

import numpy as np

M = Path(__file__).resolve().parent
shared = runpy.run_path(str(M/'score-native-floor-reflection-inputs.py'))
read,unpack,cut,local,oct_decode = (shared[k] for k in ('read','unpack','cut','local','oct_decode'))
VULKAN,NATIVE,ROOT,CROP,FRAME,REGIONS = (shared[k] for k in ('VULKAN','NATIVE','ROOT','CROP','FRAME','REGIONS'))
NATIVE_RECEIPT = ROOT/'docs/acceptance/nr/evidence/2026-10-29/native-ray-source/summary.json'
OUT = M/'projected-reflection-32-step-candidate'
q = read(VULKAN/'summary.json')
vm = {x['name']:x['data'] for x in q['inputs']+q['outputs'] if 'data' in x}
before = next(x for x in q['files'] if x['file']=='confidence-before-dispatch.bin')
rows = np.asarray(q['frameRows'],np.float32)
H,W = FRAME
assert rows[29,3]>.5 and rows[28,0]==128 and rows[25,:2].tolist()==[W,H]
assert q['event']==21668 and q['api']=='GraphicsAPI.Vulkan'
dispatch, = [row for row in q['candidates'] if row['event']==q['event']]
tiles = ((W+7)//8,(H+7)//8)
assert dispatch['dispatch']==[tiles[0]*tiles[1],1,1]
worklist = unpack(VULKAN/vm['worklist']['file'],vm['worklist']['sha256'],'<u4',(tiles[0]*tiles[1],))
expected_tiles = ((np.arange(tiles[0],dtype='u4')[:,None]<<16) |
                  np.arange(tiles[1],dtype='u4')[None,:]).ravel()
np.testing.assert_array_equal(np.sort(worklist), expected_tiles)
nd = next(x for x in read(NATIVE_RECEIPT)['payloads'] if x['resource']==15781)
npc = cut(unpack(NATIVE/'reference-15781.bin',nd['referenceSha256'],'u1',FRAME)[::-1],CROP)>0
data = lambda key,typ,shape:unpack(VULKAN/vm[key]['file'],vm[key]['sha256'],typ,shape)
pc = cut(data('outputConfidence','u1',FRAME),CROP)>0
pd = data('currentDepth','<f4',FRAME)
rgba = cut(data('normalRoughness','<f4',(*FRAME,4)),CROP)
mask = cut(data('surfaceMask','u1',FRAME),CROP)>127
eligible = cut(unpack(VULKAN/before['file'],before['sha256'],'u1',FRAME),CROP)>0
x,y,u,v = CROP
xx,yy = np.meshgrid(np.arange(x,u,dtype=np.float32)+.5,np.arange(y,v,dtype=np.float32)+.5)
origin = np.stack((xx/W,yy/H,cut(pd,CROP)),axis=-1).astype(np.float32)
ndc = origin.copy()
ndc[...,:2] = ndc[...,:2]*2-1
xyzw = ndc @ rows[6:9] + rows[9]
incident = xyzw[...,:3]/xyzw[...,3,None]
normalize = lambda z: z / np.linalg.norm(z,axis=-1,keepdims=True)
normal = oct_decode(rgba[...,:2]).astype(np.float32)@rows[:3,:3]
incident = normalize(incident)
direction = incident - np.float32(2)*np.sum(incident*normal,axis=-1,keepdims=True)*normal
d = direction @ rows[3:6] + np.concatenate((ndc,np.ones_like(ndc[...,0,None])),axis=-1)
delta = d[...,:3]/d[...,3,None]-ndc
half = np.linalg.norm(delta[...,:2],axis=-1)*.5
with np.errstate(divide='ignore',invalid='ignore'):
    clip_remainder = np.maximum(np.abs(ndc[...,:2]*half[...,None]+delta[...,:2])-half[...,None],0)
    clip_scale = np.min(1-clip_remainder/np.abs(delta[...,:2]),axis=-1)/half
    unstepped = delta*clip_scale[...,None]
assert np.all(np.isfinite(unstepped[eligible]))
native_floor = read(M/'native-floor-reflection-inputs/aligned-depth-preview.json')
assert native_floor['orientationAtTwoMillimeters']['reverseRows']['centerFloor']>23000

def phase(x, y):
    # The shader's exact source constants in the retained program.
    def f(u):return np.uint32(u).view(np.float32)
    seed = np.trunc(rows[26,0])
    f0 = f(0x3d897143)*(x+seed*f(0x40054fdf))+f(0x3bbf4590)*(y+seed*f(0x409bbe77))
    f1 = (f0-np.floor(f0))*f(0x4253ee82)
    return f1-np.floor(f1)

def sample(uv):
    q=np.clip(uv,0,1)
    p=np.floor(q*np.array([W,H],dtype=np.float32)).astype(np.int32)
    return pd[np.minimum(p[...,1],H-1),np.minimum(p[...,0],W-1)]

def search(max_steps):
    count=np.where(mask,max_steps,max(4,(max_steps+7)//8)).astype(np.float32)
    tolerance=np.maximum(np.abs(unstepped[...,2])/count,.0001)
    step=unstepped*np.array([.5,.5,1],dtype=np.float32)/count[...,None]
    step_length=np.max(np.abs(step[...,:2]*np.array([W,H],dtype=np.float32)),axis=-1)
    start=np.where(step_length<1,1/(step_length+np.float32(.001)),phase(xx,yy))
    point=origin+step*start[...,None]
    prev=point[...,2]-sample(point[...,:2])
    hit=np.zeros(eligible.shape,dtype=bool)
    checked=np.zeros(eligible.shape,dtype=np.float32)
    edge=np.zeros(eligible.shape,dtype=np.float32)
    for i in range(0,max_steps,4):
        active=eligible&~hit&(i<count)
        if not np.any(active):break
        # Fixed point sampler; the four passes share the previous depth delta.
        for lane in range(1,5):
            at=point+step*lane
            diff=at[...,2]-sample(at[...,:2])
            owns=active&(np.abs(diff+tolerance)<tolerance)&~hit
            with np.errstate(divide='ignore',invalid='ignore'):
                blend=np.clip(prev[owns]/(prev[owns]-diff[owns]),0,1)
            t=i+lane-1+blend
            uv=(point[owns]+step[owns]*(lane-1+blend[...,None]))[...,:2]
            edge[owns]=np.minimum(np.min(uv,axis=-1),1-np.max(uv,axis=-1))
            checked[owns]=t
            hit|=owns
            prev=diff
        point+=step*4
    return (hit&(edge>.5/255*rows[26,1])),checked

def compare(a,b):
    return dict(common=int((a&b).sum()),onlyA=int((a&~b).sum()),onlyB=int((~a&b).sum()),
                agreement=float((a==b).mean()),iou=float((a&b).sum()/max(1,(a|b).sum())))

a,sa=search(128)
b,sb=search(32)
results={}
for k,r in REGIONS.items():
    x0,y0,u0,v0=local(r)
    slc=(slice(y0,v0),slice(x0,u0))
    p0,p1,player,native=(x[slc] for x in (a,b,pc,npc))
    results[k]=dict(controlVsCapturedGpu=compare(p0,player),baselineToCandidate=compare(p0,p1),
                    baselineVsNativeOutput=compare(p0,native),candidateVsNativeOutput=compare(p1,native))
OUT.mkdir(exist_ok=True)
result=dict(status='cpu-geometric-search-only',scope='Ignores history, motion acceptance and temporal resolve',
            referenceNativeFrame=3534,referenceVulkanEvent=21668,testedSteps=[128,32],dispatch=dispatch,
            playerInputs={k:vm[k]['sha256'] for k in ('worklist','currentDepth','surfaceMask','normalRoughness','outputConfidence')},
            playerInitialConfidence=before['sha256'],nativeTraceConfidence=nd['referenceSha256'],
            regions=results)
(OUT/'cpu-ray-search-preview.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result),flush=True)

