"""Reconstruct native face diffuse and incident lighting at the matched controls."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


run=Path(__file__).resolve().parent
path=run/'face-opaque-main-light-lanes/results.json'
report=json.loads(path.read_bytes())
assert report['status']=='qualified'
weights=np.array([.21267290413379669,.7151522040367126,.07217500358819962])
buffer=(run/'face-view-mask-cb1.bin').read_bytes()
color_source=json.loads((run/'trace-face-view-mask.json').read_bytes())['constants']['1']
assert sha256(buffer).hexdigest()==color_source['sha256']
cb=np.frombuffer(buffer,'<f4').reshape(-1,4)
devices={}
for tag, samples in report['samples'].items():
    assert len(samples)==6
    rows=[]
    for pixel in samples:
        registers=pixel['states']
        get=lambda step,reg:np.asarray(registers[str(step)][reg],dtype=float)
        tint=get(354,'r18')[:3]
        lit=get(690,'r20')[:3]*get(690,'r3')[2]
        surface=cb[110,2]*get(686,'r10')[:3]
        dark=get(686,'r19')[:3]
        share=get(686,'r9')[3]
        lit_mask=get(690,'r12')[2]
        blend=(dark+(surface-dark)*share)*(1-lit_mask)+lit*lit_mask
        mix_error=float(np.max(np.abs(blend-get(690,'r19')[:3])))
        ramp=get(690,'r27')[:3]
        chroma=float(ramp.max()-ramp.min())
        curve=blend*(1-chroma+ramp*chroma)
        outdoor=curve*np.clip((blend@weights)/max(curve@weights,.001),0,1.5)
        indoor=get(706,'r22')[:3]
        scene_visibility=get(707,'r10')[3]
        diffuse=indoor+(outdoor-indoor)*scene_visibility
        diffuse_error=float(np.max(np.abs(diffuse-get(707,'r19')[:3])))
        assert max(mix_error,diffuse_error)<2.e-6,(tag,pixel['point'],mix_error,diffuse_error)
        incoming=get(681,'r17')[:3]
        main=diffuse*incoming
        rgb=np.asarray(pixel['shaderRGB'])
        rows.append(dict(point=pixel['point'],origin=pixel['origin'],primitive=pixel['primitive'],
            tint=tint.tolist(),incident=incoming.tolist(),albedo=lit.tolist(),litMask=lit_mask,sceneVisibility=scene_visibility,
            diffuse=diffuse.tolist(),mainDiffuse=main.tolist(),remainingLinearRgb=(rgb-main).tolist(),
            materialStateError=mix_error,diffuseResponseError=diffuse_error,shaderRgb=rgb.tolist()))
    print(tag,[(row['point'],row['litMask'],row['remainingLinearRgb']) for row in rows],flush=True)
    devices[tag]=rows
(run/'face-opaque-main-light-native-score.json').write_text(json.dumps(dict(
    status='measured-native-face-diffuse-and-lighting-terms',source=sha256(path.read_bytes()).hexdigest(),
    devices=devices),indent=2)+'\n',encoding='utf8')
