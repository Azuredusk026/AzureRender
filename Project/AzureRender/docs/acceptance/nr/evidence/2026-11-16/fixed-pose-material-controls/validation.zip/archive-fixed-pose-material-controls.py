"""Archive the physical fixed-pose candidate decisions."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

work = Path(__file__).resolve().parent
inputs = {
    'body': work/'body-opaque-main-saturation-player',
    'cloth': work/'first-cloth-shell-source-fixture',
    'atlas': work/'body-atlas-depth-states',
    'face': work/'face-opaque-main-light-lanes',
}
load = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
measured = {name: load(path/'results.json') for name, path in inputs.items()}
face = load(work/'face-opaque-main-light-native-score.json')
atlas, body, cloth = (measured[k] for k in ('atlas', 'body', 'cloth'))
assert atlas['status']==measured['face']['status']=='qualified'
assert body['allGates']=='open' and not cloth['candidateQualified']
a, b = (atlas['devices'][k]['final'] for k in ('native', 'current'))
assert len(a)==5 and [q-p for p,q in zip(a,b)]==[1]*5
members = {f'{k}/results.json':v/'results.json' for k,v in inputs.items()}
members.update({p.name:p for p in (
    Path(__file__), work/'face-opaque-main-light-native-score.json',
    work/'body-opaque-main-saturation-player.py', work/'native-first-cloth-shell-player.py',
    work/'score-face-opaque-main-light-lanes.py')})
members['body/preflight.json']=inputs['body']/'preflight.json'
members['cloth/input-receipt.json']=inputs['cloth']/'input-receipt.json'
for device, interior, new in (('nvidia',[11018,627],6), ('intel',[10522,581],17)):
    d=body['devices'][device]
    e=cloth['devices'][device]
    assert d['layers']['interior']['overOne']==interior
    assert d['layers']['skin']['newOverOne']==new and not d['outsideSkinChanged']
    assert d['frame']==digest(inputs['body']/device/'frames/frame_000000.png')
    assert e['fullFrameNewOverOne']==19 and e['probe']['error']==[41,41]
    assert len(face['devices'][device])==6
    assert max(r['diffuseResponseError'] for r in face['devices'][device]) < 6e-8
    for scope, receipt in (('body','receipt.json'),('cloth','capture-receipt.json')):
        members[f'{scope}/{device}/{receipt}']=inputs[scope]/device/receipt
destination = work.parents[2]/'docs/acceptance/nr/evidence/2026-11-16/fixed-pose-material-controls'
destination.mkdir(parents=True,exist_ok=True)
z = destination/'validation.zip'
with ZipFile(z,'w') as file:
    for name,path in sorted(members.items()):
        i=ZipInfo(name,(2026,11,16,0,0,0))
        i.compress_type=ZIP_DEFLATED
        file.writestr(i,path.read_bytes())
with ZipFile(z) as file:
    assert file.testzip() is None
    for name,path in members.items():
        assert sha256(file.read(name)).hexdigest()==digest(path)
report=dict(status='measured; strict gates open',productionCandidates={'body':False,'cloth':False},
            body=body,cloth=cloth,atlasFinal={'native':a,'player':b},
            faceDiffuse={d:dict(points=len(l),maxLinearError=max(r['diffuseResponseError'] for r in l))
                         for d,l in face['devices'].items()},
            archive=dict(sha256=digest(z),members={k:digest(v) for k,v in members.items()}))
(destination/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(report['archive']['sha256'])
