"""Measure the original first cloth shell in the fixed-pose Player."""
from contextlib import ExitStack, contextmanager
from hashlib import sha256
from pathlib import Path
import json
import os
import runpy
import subprocess
import sys

import numpy as np


run = Path(__file__).resolve().parent
make = runpy.run_path(str(run / 'native-first-cloth-shell-fixture.py'))
files = make['files']
grid = files['grid']
body, stage, name, old_name = (make[key] for key in ('body', 'stage', 'name', 'old_name'))
read, digest, save = (make[key] for key in ('read', 'digest', 'save'))
fixture = grid / 'iris-overlay-geometry-project'
before = run / 'body-outline-before-transparent-cloth'
owner = '01a1d0a9-829a-7c11-a7a8-017e743887d9'
task = 'nr-first-cloth-shell-from-native-output-two-adapters'
host = 'D:/Tools/Python311/python.exe'
python = 'D:/Projects/FYP/Project/AzureRender/build/reinstall-environment/venv/Scripts/python.exe'
dispatch = 'D:/Projects/FYP-coordination/tools/dispatch.py'


def inputs(*, materialized=True):
    receipt = read(stage / 'input-receipt.json')
    paths = {}
    for relative, fingerprint in receipt['candidateInputs'].items():
        path = stage / Path(relative).name
        if materialized or path.exists():
            assert digest(path) == fingerprint
        paths[fixture / relative] = path
    original_project = body / (old_name + '.azureproject')
    original_level = body / (old_name + '.azurelevel')
    project = read(original_project)
    level = read(original_level)
    hero = next(resource for resource in level['resources'] if resource['id'] == 'hero')
    assert hero['asset'] == 'character:/body-native-lit-outline-production.gltf'
    hero['asset'] = f'character:/{name}.gltf'
    project['startupScene'] = f'stage:/{name}.azurelevel'
    for relative, payload in ((name + '.azureproject', project), (f'scene/{name}.azurelevel', level)):
        path = stage / Path(relative).name
        save(path, payload)
        paths[fixture / relative] = path
    return paths



def restore_baseline():
    source = make['source_model']
    receipt = read(before / 'preflight.json')
    origin = body / 'body-native-lit-outline-production-ordered.gltf'
    assert digest(origin) == receipt['original']
    raw = origin.read_bytes()
    children = lambda key: b'"children":' + json.dumps(receipt[key], separators=(',', ':')).encode()
    old, new = [children(key) for key in ('previousChildren', 'currentChildren')]
    assert raw.count(old) == 1
    restored = raw.replace(old, new)
    assert sha256(restored).hexdigest() == receipt['candidate']
    if source.exists():
        assert digest(source) == receipt['candidate']
    else:
        source.write_bytes(restored)
        assert digest(source) == receipt['candidate']
    return source, restored


@contextmanager
def materialize_fixture():
    baseline, baseline_bytes = restore_baseline()
    compiled = make['prepare'](materialize=False)
    data = read(stage / 'input-receipt.json')['candidateInputs']
    assert {name: sha256(payload).hexdigest() for name, payload in compiled.items()} == data
    target = stage / (name + '.gltf')
    assert not target.exists() or digest(target) == data['character/' + target.name]
    # Only one full GLTF is stored during this capture. The order-only baseline
    # has an independently verified byte-for-byte reconstruction above.
    try:
        baseline.unlink()
        if not target.exists():
            target.write_bytes(compiled['character/' + target.name])
        yield
    finally:
        if target.exists():
            target.unlink()
        if not baseline.exists():
            baseline.write_bytes(baseline_bytes)
        assert digest(baseline) == sha256(baseline_bytes).hexdigest()


def capture(tag, paths, helper):
    control = before / tag
    control_receipt = read(control / 'receipt.json')
    control_png = control / 'frames/frame_000000.png'
    assert digest(control_png) == control_receipt['frame']
    material = body / f'body-outline-beauty-transparent-highlights-captured-origin-{tag}' / (old_name + '.azurematerial')
    metadata = body / (material.name + '.azmeta')
    assert digest(material) == control_receipt['material']
    linked = {**paths, fixture / 'materials' / material.name: material, fixture / 'materials' / metadata.name: metadata}
    output = stage / tag
    result = output / 'capture-receipt.json'
    frame = output / 'frames/frame_000000.png'
    command = read(control / 'command.json')
    assert digest(Path(command[0])) == control_receipt['player']
    for flag, value in (('--project', fixture / (name + '.azureproject')),
                        ('--capture-dir', output / 'frames'), ('--runtime-report', output / 'runtime.json')):
        command[command.index(flag) + 1] = str(value)
    if result.is_file():
        prior = read(result)
        assert [prior['frame'], prior['base'], prior['candidate'], prior['command']] == [
            digest(frame), digest(control_png), digest(stage / 'input-receipt.json'), command]
        return frame, control_png
    if output.exists():
        interrupted = len(list(stage.glob(tag + '-interrupted-*'))) + 1
        output.rename(stage / f'{tag}-interrupted-{interrupted}')
    output.mkdir()
    with ExitStack() as cleanup:
        for path, source in linked.items():
            if path.exists():
                assert os.path.samefile(path, source), path
            else:
                path.hardlink_to(source)
            cleanup.callback(path.unlink)
            if path.name.startswith(name) and path.suffix in ('.azurelevel', '.azureproject', '.gltf', '.bin'):
                sidecar = path.with_name(path.name + '.azmeta')
                cleanup.callback(sidecar.unlink, missing_ok=True)
        assert helper['invoke'](tag, command, output) / 'frame_000000.png' == frame
        gpu = read(frame.parent / 'gpu_capabilities.json')
        assert gpu['device_id'] == (0x28e0 if tag == 'nvidia' else 0xa788)
        capture = read(frame.parent / 'capture_manifest.json')
        prior_capture = read(control_png.parent / 'capture_manifest.json')
        for field in ('cameraLens', 'cameraUp', 'qaCameraPosition', 'qaCameraTarget', 'width', 'height'):
            assert capture[field] == prior_capture[field], field
    save(result, dict(frame=digest(frame), base=digest(control_png), candidate=digest(stage / 'input-receipt.json'),
                      command=command, device=gpu['device_id'], driver=gpu['driver_version']))
    return frame, control_png


def validate_runtime():
    lease = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state'] == 'held' and Path(lease['output']) == run
    sys.path.insert(0, str(run.parents[2] / 'tools'))
    from artifact_budget import check
    budget = check(run.parents[1], run=run, planned=20000000)
    assert budget['allowed'], budget
    catalog = runpy.run_path(str(body / 'face-quality-candidate-catalog.py'))
    canonical = catalog['retained_catalog'](body)
    catalog['restore'](canonical)
    assert {p.name: catalog['sha'](p) for p in (body / 'msaa-release/shaders').glob('*.spv')} == canonical



def run_suite():
    validate_runtime()
    with materialize_fixture():
        score_captures()


def score_captures():
    paths = inputs()
    owner_mask = files['last_skin_owner']()
    exact = owner_mask == 1079
    assert exact.sum() == 577
    ambiguous = read(run / 'body-native-cloth-outline-topology.json')[0]['triangleCompatibility']['2.5e-05']
    unresolved = np.zeros_like(exact)
    points = np.asarray(ambiguous['unresolvedSkinCoordinates'])
    unresolved[points[:, 1], points[:, 0]] = True
    assert (unresolved & exact).sum() == 20
    helper = runpy.run_path(str(grid / 'iris-production-frozen-recovery.py'))
    score = runpy.run_path(str(grid / 'static-quality.py'))
    target = score['image'](score['reference_path']).astype(np.int16)
    devices = {}
    for tag in ('nvidia', 'intel'):
        candidate, baseline = capture(tag, paths, helper)
        previous, current = [score['image'](path).astype(np.int16) for path in (baseline, candidate)]
        errors = (np.abs(previous - target).max(axis=2), np.abs(current - target).max(axis=2))
        changed = (previous != current).any(axis=2)
        metrics = {}
        for key, mask in (('firstShell', exact), ('unresolvedGeometry', unresolved),
                          ('otherSkin', (owner_mask != 0) & ~exact)):
            metrics[key] = dict(count=int(mask.sum()), changed=int((changed & mask).sum()),
                                overOne=[int((error[mask] > 1).sum()) for error in errors],
                                overEight=[int((error[mask] > 8).sum()) for error in errors],
                                peak=[int(error[mask].max()) for error in errors])
        new_over_one = int(((errors[0] <= 1) & (errors[1] > 1)).sum())
        x, y = 1274, 523
        qualified = (new_over_one == 0 and (metrics['firstShell']['overEight'][1] < metrics['firstShell']['overEight'][0])
                     and int(errors[1][y, x]) <= int(errors[0][y, x]))
        devices[tag] = dict(metrics=metrics, fullFrameNewOverOne=new_over_one,
                            changedOutsideFirstShell=int((changed & ~exact).sum()),
                            probe=dict(point=[x, y], reference=target[y, x].tolist(),
                                       previous=previous[y, x].tolist(), current=current[y, x].tolist(),
                                       error=[int(error[y, x]) for error in errors]), qualified=qualified)
        print(tag, json.dumps(devices[tag]), flush=True)
    save(stage / 'results.json', dict(status='measured', candidateQualified=all(r['qualified'] for r in devices.values()),
         source=read(stage / 'input-receipt.json'), nativeGate='unchanged',
         reference=digest(score['reference_path']), devices=devices))


def submit():
    queue = json.loads(subprocess.check_output([host, dispatch, 'status', '--limit', '160']))
    assert not any(row['owner'] == owner and row['task'] == task for row in (*queue['pending'], *queue['running']))
    log = run / (task + '-queue.log')
    with log.open('xb') as stream:
        process = subprocess.Popen([host, dispatch, 'run', '--build', str(run.parents[1]), '--owner', owner,
            '--task', task, '--run', run.name, '--kind', 'gpu', '--priority', 'P1', '--estimate', '190',
            '--wait-timeout', '43200', '--timeout', '480', '--command', python, str(Path(__file__).resolve()), 'run'],
            stdin=subprocess.DEVNULL, stdout=stream, stderr=stream, creationflags=subprocess.CREATE_NO_WINDOW)
    print(process.pid)


if __name__ == '__main__':
    command, = sys.argv[1:]
    if command == 'prepare':
        staged = inputs(materialized=False)
        print(len(staged), sum(source.is_file() for source in staged.values()))
    elif command == 'run':
        run_suite()
    else:
        assert command == 'submit'
        submit()
