"""Measure native main-light saturation on the retained opaque skin material."""
import json
import os
from pathlib import Path
import runpy
import sys

import cv2
import numpy as np
from PIL import Image


run = Path(__file__).resolve().parent
body = run.parent / '20261114-125923-body-lit-outline-depth-order-a29b63'
grid = run.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
order_stage = run / 'body-outline-before-transparent-cloth'
output = run / 'body-opaque-main-saturation-player'
iris = runpy.run_path(str(run/'iris-matcap-differential-player.py'), run_name='skin_shader_build')
sha=iris['digest']
read=iris['read']
write=iris['write']
root=run.parents[2]
catalog = runpy.run_path(str(body/'face-quality-candidate-catalog.py'))
baseline = read(order_stage/'results.json')
order = read(order_stage/'preflight.json')
score = runpy.run_path(str(grid/'static-quality.py'))
native_dir = score['stages']
original = native_dir/'native-e783.asm'
original_dx = native_dir/'native-e783.dxbc'
native_shader = read(grid/'native-face-skin-stages/results.json')['geometry']['783']['pixelShaderSha256']
source_report = run/'preserved-native-skin-controls.json'
proposal = run/'opaque-skin-main-saturation-display-model.json'


def prepare():
    assert sha(original_dx)==native_shader
    native=original.read_text(encoding='utf8')
    original_steps=('1168: dp3 r2.w, r12.xyzx', '1192: mad r6.x, r6.x, r6.x, l(1.000000)',
                    '1194: mad r12.xyz, r6.xxxx, r12.xyzx, r2.wwww')
    assert all(step in native for step in original_steps)
    derived=read(proposal)
    assert derived['source']==sha(source_report)
    assert all(derived['devices'][device]['interior']['overOne'][1]<
               derived['devices'][device]['interior']['overOne'][0] for device in derived['devices'])
    base=root/'shaders/mesh.frag'
    code=base.read_text(encoding='utf8')
    hook='        sceneMainDiffuse=response.color*illumination.direct;\n        beautyColor+=combinedAmbient+combinedDirect-ambientDiffuse-directDiffuse;'
    assert code.count(hook)==1
    replacement='''        sceneMainDiffuse=response.color*illumination.direct;
        if(nprDiffuse&&AZURE_MATERIAL_CLASS==1U&&AZURE_ALPHA_MODE==0) {
            vec3 mainDiffuse=combinedAmbient+sceneMainDiffuse;
            float brightnessSaturation=characterMainBrightnessSaturation(mainDiffuse);
            combinedAmbient=characterDiffuseSaturation(combinedAmbient,brightnessSaturation);
            vec3 saturatedMain=characterDiffuseSaturation(sceneMainDiffuse,brightnessSaturation);
            combinedDirect+=saturatedMain-sceneMainDiffuse;
            sceneMainDiffuse=saturatedMain;
        }
        beautyColor+=combinedAmbient+combinedDirect-ambientDiffuse-directDiffuse;'''
    output.mkdir(exist_ok=True)
    sources=output/'resources/shaders'
    sources.mkdir(parents=True,exist_ok=True)
    generated=output/'mesh.frag'
    generated.write_text(code.replace(hook,replacement),encoding='utf8')
    shaders={}
    for name in iris['programs']:
        iris['compile_program'](generated,sources/name,name)
        shaders[name]=sha(sources/name)
    return dict(shaderSource=sha(base),variant=sha(generated),programs=shaders,nativeProgram=native_shader,
                nativeAssembly=sha(original),retainedModel=sha(proposal),source=sha(source_report))


def capture(device):
    path=run/'body-outline-before-transparent-cloth.py'
    namespace={'__file__':str(path)}
    prefix=path.read_text(encoding='utf8').split("\nif sys.argv[1:]==['preflight']:",1)[0]
    exec(compile(prefix,str(path),'exec'),namespace)
    namespace['stage']=output
    control=body/f'body-outline-beauty-transparent-highlights-captured-origin-{device}'
    model=order_stage/'body-native-lit-outline-production-native-order.gltf'
    assert sha(model)==order['candidate']
    return namespace['capture'](device,control,model,order)


def metrics(original, candidate, frozen, area):
    a,b=[np.abs(image[area]-frozen[area]).max(axis=1) for image in (original,candidate)]
    return dict(scope=len(a), changed=int(np.any(original[area]!=candidate[area],axis=1).sum()),
        overOne=[int((value>1).sum()) for value in (a,b)], overEight=[int((value>8).sum()) for value in (a,b)],
        peak=[int(value.max(initial=0)) for value in (a,b)], newOverOne=int(((a<=1)&(b>1)).sum()))


def main():
    iris['check_budget']()
    lock=read(iris['lease_file'])
    assert lock['state']=='held' and Path(lock['output'])==run
    receipt=prepare()
    preflight=output/'preflight.json'
    if preflight.is_file():
        assert read(preflight)==receipt
    write(preflight,receipt)
    canonical=catalog['retained_catalog'](body)
    catalog['restore'](canonical)
    chosen=output/'resources/shaders'
    masks={}
    with Image.open(grid/'native-face-masks/skin.png') as picture:
        masks['skin']=np.asarray(picture.convert('L'))>0
    prev=run/'body-native-skin-interior-stages-unchanged-history-failed'
    x,y=np.fromfile(prev/'points.bin','<u2').reshape(-1,2).T
    assert len(x)==47458 and bool(masks['skin'][y,x].all()) and int(masks['skin'].sum())==len(x)
    packed_before,packed_after=[np.fromfile(prev/f'nvidia-{event}.bin','<u4') for event in (783,1383)]
    preserved=read(source_report)
    assert sha(prev/'nvidia-783.bin')==preserved['anchors']['783']['nvidiaSnapshot']
    assert sha(prev/'nvidia-1383.bin')==preserved['anchors']['1383']['nvidiaSnapshot']
    independent=np.zeros_like(masks['skin'])
    independent[y,x]=packed_before==packed_after
    distance=cv2.distanceTransform(masks['skin'].astype('u1'),cv2.DIST_L2,5)
    masks['interior']=independent&(distance>6)
    masks['edge']=independent&(distance<=6)
    masks['covered']=masks['skin']&~independent
    assert [int(mask.sum()) for mask in masks.values()]==[47458,30561,13086,3811]
    native=score['image'](score['reference_path']).astype(np.int16)
    devices={}
    with catalog['activate'](receipt['programs'],alternate_run=run,source_dir=chosen):
        for device in ('nvidia','intel'):
            current=order_stage/device/'frames/frame_000000.png'
            actual=capture(device)
            assert sha(current)==baseline['devices'][device]['frame']
            reference,candidate=[score['image'](path).astype(np.int16) for path in (current,actual)]
            changed=np.any(reference!=candidate,axis=2)
            summary={name:metrics(reference,candidate,native,mask) for name,mask in masks.items()}
            devices[device]=dict(control=sha(current),frame=sha(actual),layers=summary,
                                 outsideSkinChanged=int((changed&~masks['skin']).sum()))
            print(device,devices[device],flush=True)
    write(output/'results.json',dict(status='measured-opaque-skin-main-light-saturation',devices=devices,
          preflight=sha(preflight),reference=sha(score['reference_path']),allGates='open'))


if __name__=='__main__':
    main()
