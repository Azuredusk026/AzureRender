"""Measure the native-resolution temporal resolve in the unchanged joint project."""
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import sys
from zipfile import ZipFile, ZIP_DEFLATED

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
O=M/'joint-current-temporal-resolve'
H=runpy.run_path(str(M/'run-immutable-scene-glyph-capture.py'),run_name='joint_temporal_actual')
S=H['S']
read,write,fingerprint=[H[k] for k in ('read','write','sha')]
P=H['PLAYER']


def run():
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    assert check(W/'build',run=M,planned=28_000_000)['allowed']
    assert all(not os.environ.get(k) for k in H['ENV'])
    source=H['immutable_index']()
    assert fingerprint(P)==read(H['qualification'])['candidatePlayer']
    tree=H['tree_stamp']()
    gold=S['img'](H['gold'])
    O.mkdir()
    reports={}
    for gpu in ('nvidia','intel'):
        base=M/f'projected-reflection-32-step-candidate/baseline-{gpu}'
        initial=read(base/'result.json')
        exact_path,exact_result,exact_frames=H['one'](gpu,'baseline',None)
        original_manifest=read(exact_path/'frames/capture_manifest.json')
        args=read(M/f'projected-reflection-native-phase-candidate/candidate-{gpu}/command.json')
        args[0]=str(P)
        out=O/gpu
        out.mkdir()
        for k,v in (('--capture-frames','2'),('--capture-dir',out/'frames'),('--runtime-report',out/'runtime.json')):
            args[args.index(k)+1]=str(v)
        assert args[args.index('--project')+1]==str(H['project'])
        if '--anti-aliasing' in args:
            args[args.index('--anti-aliasing')+1]='temporal'
        else:
            args.extend(('--anti-aliasing','temporal'))
        S['invoke'](gpu,args,out)
        actual=read(out/'frames/capture_manifest.json')
        caps=read(out/'frames/gpu_capabilities.json')
        assert caps['driver_version']==initial['driver']
        assert all(actual[k]==original_manifest[k] for k in S['forbid']),{k:(actual[k],original_manifest[k]) for k in S['forbid'] if actual[k]!=original_manifest[k]}
        assert actual['capturedFrames']==2 and actual['screenReflectionProducer']=='projected-history'
        log=(out/'player.log').read_text(encoding='utf8',errors='replace')
        assert 'Capture resource ' not in log
        rt=read(out/'runtime.json')
        assert not rt['presentationErrors'] and not rt['scriptErrors']
        temporal={k:v for k,v in actual.items() if 'temporal' in k.lower() or 'alias' in k.lower()}
        rows=[]
        for i in range(2):
            name=f'frame_{i:06d}.png'
            ctrlpath=base/'frames'/name
            p=out/'frames'/name
            assert fingerprint(ctrlpath)==initial['images'][i]
            ctrl,frame=(cv2.imread(str(f),cv2.IMREAD_UNCHANGED) for f in (ctrlpath,p))
            assert ctrl.shape==frame.shape==(1440,2560,4)
            source_rgb=H['pixels'](exact_frames,name)
            actual_rgb=cv2.cvtColor(frame,cv2.COLOR_BGRA2RGB)
            metrics={}
            for key,(x,y,u,v) in S['regions'].items():
                native,base_rgb,curr=(data[y:v,x:u] for data in (gold,source_rgb,actual_rgb))
                before,after=(np.abs(a.astype(np.int16)-native).max(2) for a in (base_rgb,curr))
                metrics[key]=dict(baseline=S['score'](base_rgb,native),candidate=S['score'](curr,native),
                    changed=int(np.count_nonzero(np.any(base_rgb!=curr,axis=2))),
                    newOverOne=int(np.count_nonzero((before<=1)&(after>1))))
            encoded=out/f'delta-{i}.zip'
            with ZipFile(encoded,'x',ZIP_DEFLATED,compresslevel=9) as z:
                z.writestr('bgra-xor',np.bitwise_xor(ctrl,frame).tobytes())
            with ZipFile(encoded) as z:
                assert z.testzip() is None
                decoded=ctrl^np.frombuffer(z.read('bgra-xor'),np.uint8).reshape(ctrl.shape)
                assert np.array_equal(decoded,frame)
            rows.append(dict(png=fingerprint(p),xorDonorPng=initial['images'][i],comparisonPng=exact_result['files']['frames/'+name],
                raw=sha256(frame.tobytes()).hexdigest(),deltaArchive=fingerprint(encoded),metrics=metrics))
            assert p.resolve()==p and not p.stat().st_file_attributes&1024
            p.unlink()
        reports[gpu]=dict(temporal=temporal,rows=rows,gpu=caps['driver_version'],
                         loadedReflection=actual['screenReflectionProducer'])
        write(O/'qualification.json',dict(status='capturing-temporal-display-resolve',reports=reports))
        print(gpu,{k:temporal[k] for k in temporal if 'alias' in k.lower() or 'frame' in k.lower()},
              [{k:(r['metrics'][k]['candidate']['ssim'],r['metrics'][k]['candidate']['medianLumaRelativeError'])
               for k in ('centerFloor','cyanRing')} for r in rows],flush=True)
    assert H['immutable_index']()==source and H['tree_stamp']()==tree
    write(O/'qualification.json',dict(status='measured-temporal-display-resolve-on-actual-joint-scene',reports=reports,
         immutable=source,player=fingerprint(P),formalReflectionAcceptance=False))


if __name__=='__main__':
    run()
