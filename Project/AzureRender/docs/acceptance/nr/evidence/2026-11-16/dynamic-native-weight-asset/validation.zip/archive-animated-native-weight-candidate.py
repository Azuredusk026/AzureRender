from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile,ZipInfo

run=Path(__file__).resolve().parent
out=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-16/dynamic-native-weight-asset'
digest=lambda b:sha256(b).hexdigest()
read=lambda p:json.loads((run/p).read_bytes())
plan='animated-body-native-rig-original-weight-codes.json'
deformation='animated-body-serialized-native-weight-clips.json'
fixture='animated-body-native-weights-fixture.json'
asset=read(plan)
score=read(deformation)
dependency=read(fixture)
assert score['asset']==asset['serializedSha256']==dependency['sources']['candidateAsset']
assert asset['originalWeightCodes']=={'65534':354,'65535':2517,'65536':418}
assert (asset['activeVertexCount'],asset['untouchedAnimationCount'],asset['untouchedSkinCount'])==(3289,10,1)
assert sum(len(q['poses']) for q in score['clips'])==score['poses']==70
assert score['seams']==245 and score['largestSeam']['maxSeamM']==0
assert score['newDegenerate']==score['newlyDegenerateVsNormalized']==0
assert 0 < score['worstShift']['maxShiftM'] < .00005
dependencies=dict(count=len(dependency['inputs']),bytes=dependency['bytes'],sources=dependency['sources'])
files={k:(run/k).read_bytes() for k in (plan,deformation,fixture,Path(__file__).name,
      'build-animated-body-topology-candidate.py','score-serialized-native-body-animated-weights.py',
      'score-animated-body-topology-deformation.py','plan-animated-body-topology-fixture.py',
      'run-animated-body-topology-fixture.py')}
out.mkdir(parents=True,exist_ok=True)
target=out/'validation.zip'
with ZipFile(target,'w') as z:
    for name,data in sorted(files.items()):
        z.writestr(ZipInfo(name,(2026,11,16,0,0,0)),data,compress_type=ZIP_DEFLATED)
with ZipFile(target) as z:
    assert z.testzip() is None
    assert {name:z.read(name) for name in z.namelist()}==files
result=dict(status='quantized animated asset validated in CPU geometry; Player verification pending',
            productionAssetAccepted=False,assembledBodyAsset=asset,fixtureDependencies=dependencies,
            motion={k:v for k,v in score.items() if k!='clips'},
            archive=dict(sha256=digest(target.read_bytes()),members={name:digest(data) for name,data in files.items()}))
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(result['archive']['sha256'])
