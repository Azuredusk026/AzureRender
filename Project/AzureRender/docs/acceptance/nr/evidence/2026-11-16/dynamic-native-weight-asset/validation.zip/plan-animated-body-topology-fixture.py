"""Collect exactly the actor and dependencies for a paired geometry-only animation fixture."""
from copy import deepcopy
from hashlib import file_digest
import json
from pathlib import Path
import re
import runpy
import sys

run=Path(__file__).resolve().parent
six=runpy.run_path(str(run/'character-six-view-inputs.py'),run_name='actor_pose')
read=lambda p:json.loads(p.read_bytes())
guid=re.compile(r'[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}',re.I)
def sha(p):
    with p.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()
light_fixture=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261101-113436-full-body-native-comparison-0a653b/project/scene/fullbody-source-aa0.azurelevel')

def values(a):
    if isinstance(a,dict):
        for v in a.values():yield from values(v)
    elif isinstance(a,list):
        for v in a:yield from values(v)
    elif isinstance(a,str):
        yield a

def prepare(native_weights=False):
    _,project,level,scene,actor=six['source_inputs']()
    project_doc=read(project)
    mounts={k['name']:k['path'] for k in project_doc['mounts']}
    old=read(light_fixture)
    assert not old['sceneImports'] and len(old['resources'])==1
    hero,=[n for n in scene['nodes'] if n['id']=='hero']
    assert len(hero['materialSlots'])==13
    a,=[i for i,n in enumerate(old['nodes']) if n['id']=='hero']
    translation=[x-y for x,y in zip(hero['components']['azure.transform']['data']['translation'],
                                     old['nodes'][a]['components']['azure.transform']['data']['translation'])]
    old['nodes'][a]=hero
    for i,node in enumerate(old['nodes']):
        assert node['parentId'] in ('','hero')
        if i!=a and not node['parentId']:
            tx=node['components']['azure.transform']['data']
            tx['translation']=[x+y for x,y in zip(tx['translation'],translation)]
    old['resources']=[v for v in scene['resources'] if v['id']=='hero']
    assert len(old['resources'])==1
    # Keep fixture-level lights and adjust their explicit authored positions along with the nodes.
    for q in old['lights']:
        p=q.get('position')
        if isinstance(p,list):
            q['position']=[x+y for x,y in zip(p,translation)]
    assert len(old['lights'])==10
    old['id']='body-topology'
    index={}
    gathered={}
    used_mounts=set()
    root=project.parent
    for mount in ('assets','candidate','character','stage'):
        directory=root/mounts[mount]
        for metadata in directory.rglob('*.azmeta'):
            if any(s.startswith('.') for s in metadata.relative_to(directory).parts):
                continue
            info=read(metadata)
            if 'id' not in info:
                continue
            entry=metadata.with_suffix('')
            if not entry.is_file():
                continue
            assert info['id'] not in index,(info['id'],entry,index.get(info['id']))
            index[info['id']]=(metadata,info,entry,mount)

    def virtual(text):
        mount,tail=text.split(':/',1)
        if mount=='engine':
            return
        assert mount in mounts,text
        path=(root/mounts[mount]/tail).resolve()
        assert path.is_relative_to(root) and path.is_file(),text
        register(path,mount)

    def deps(iterable):
        for value in iterable:
            if ':/' in value:
                virtual(value)
            elif guid.fullmatch(value):
                assert value in index,value
                meta,info,entry,mount=index[value]
                assert meta==entry.with_name(entry.name+'.azmeta')
                register(entry,mount)

    def register(p,mount):
        assert p.is_relative_to(root/mounts[mount]),p
        if p in gathered:
            return
        assert p.is_file()
        gathered[p]=sha(p)
        used_mounts.add(mount)
        meta=p.with_name(p.name+'.azmeta')
        if meta.is_file():
            gathered[meta]=sha(meta)
            deps(read(meta).get('dependencies',[]))
        if p.suffix in ('.azurematerial','.json'):
            deps(values(read(p)))

    deps(values(old))
    with actor.open('rb') as f:
        import struct
        h=struct.unpack('<5I',f.read(20))
        assert (h[0],h[1],h[4])==(0x46546c67,2,0x4e4f534a)
        data=json.loads(f.read(h[3]))
    for image in data['images']:
        assert image.get('uri') and ':' not in image['uri']
        p=(actor.parent/image['uri']).resolve()
        register(p,'character')
    assert actor in gathered
    observed=read(run/('animated-body-native-rig-original-weight-codes.json'
                       if native_weights else 'animated-body-topology-candidate.json'))
    assert sha(actor)==observed['originalGlb']
    baseline=deepcopy(project_doc)
    baseline['startupScene']='stage:/body-topology.azurelevel'
    baseline['mounts']=[entry for entry in baseline['mounts'] if entry['name'] in used_mounts|{'stage'}]
    # Both controls use the same project, scene, materials and animation. Only the selected file payload changes.
    assert not old['sceneImports'] and {m['name'] for m in baseline['mounts']}==used_mounts|{'stage'}
    files={p.relative_to(root).as_posix():dict(sha256=v,bytes=p.stat().st_size) for p,v in sorted(gathered.items())}
    report=dict(status='planned-isolated-body-topology-fixture',assetVariant=observed['variant'],
                sourceRoot=str(root),assetPath=actor.relative_to(root).as_posix(),
                inputs=files,bytes=sum(q['bytes'] for q in files.values()),project=baseline,level=old,
                sources=dict(project=sha(project),dynamicLevel=sha(level),isolatedLevel=sha(light_fixture),originalAsset=sha(actor),
                             candidateAsset=observed['serializedSha256']))
    return report

if __name__=='__main__':
    assert sys.argv[1:] in (['preflight'],['preflight','--native-weights'])
    exact='--native-weights' in sys.argv
    receipt=prepare(exact)
    name='animated-body-native-weights-fixture.json' if exact else 'animated-body-topology-fixture.json'
    (run/name).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
    print(receipt['status'],len(receipt['inputs']),receipt['bytes'],[q['name'] for q in receipt['project']['mounts']])
