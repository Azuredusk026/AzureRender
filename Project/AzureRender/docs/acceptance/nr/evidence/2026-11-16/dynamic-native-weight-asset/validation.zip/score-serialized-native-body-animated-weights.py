"""Validate the skinning inputs decoded from the byte-exact candidate asset."""
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import runpy
import struct
import numpy as np

run = Path(__file__).resolve().parent
animation = runpy.run_path(str(run/'score-animated-body-topology-deformation.py'), run_name='body_pose')
build = animation['src']
payload, report = build['serialize'](True, True)
assert sha256(payload).hexdigest() == report['serializedSha256']
saved = json.loads((run/'animated-body-native-rig-original-weight-codes.json').read_bytes())
assert saved == json.loads(json.dumps(report))
magic, version, total, njson, kind = struct.unpack_from('<5I',payload)
assert (magic,version,total,kind) == (0x46546c67,2,len(payload),0x4e4f534a)
doc=json.loads(payload[20:20+njson])
length, bin_kind = struct.unpack_from('<2I',payload,20+njson)
assert bin_kind==0x004e4942 and length==len(payload)-(28+njson)
data=memoryview(payload)[28+njson:]
mesh,=[m for m in doc['meshes'] if m['name']=='S_actor_laevat_body_01_lod0']
primitive,=mesh['primitives']
assert primitive['extras']['azurePreserveSkinWeightCodes'] is True

def array(index, semantic, dtype, n, kind):
    a=doc['accessors'][index]
    v=doc['bufferViews'][a['bufferView']]
    assert a['componentType']==kind and v['buffer']==0 and a.get('byteOffset',0)==0
    start=v['byteOffset']
    encoded=data[start:start+v['byteLength']]
    assert sha256(encoded).hexdigest()==report['candidateInputHashes'][semantic]
    return np.frombuffer(encoded,dtype).reshape(a['count'],n),a

attr=primitive['attributes']
p,_=array(attr['POSITION'],'POSITION','<f4',3,5126)
j,_=array(attr['JOINTS_0'],'JOINTS_0','<u2',4,5123)
raw,accessor=array(attr['WEIGHTS_0'],'WEIGHTS_0','<u2',4,5123)
assert accessor['normalized'] is True
indices,ix= array(primitive['indices'],'INDICES','<u2',1,5123)
assert ix['type']=='SCALAR' and ix['count']%3==0
indices=indices.reshape(-1,3)
assert np.unique(indices).size==len(p)==len(j)==len(raw)==3289
w=raw.astype(float)/65535
w_norm=w/w.sum(1,keepdims=True)
xyz=np.column_stack((p,np.ones(len(p))))
geom=animation['surfaces']
rest,_=geom(p,indices)
adjacency={}
pairs=[]
grid=np.floor(p/1e-5).astype(int)
for i,key in enumerate(grid):
    for d in product((-1,0,1),repeat=3):
        for k in adjacency.get(tuple(key+d),[]):
            if np.linalg.norm(p[i]-p[k])<=1e-5:
                pairs.append((k,i))
    adjacency.setdefault(tuple(key),[]).append(i)
seams=np.asarray(pairs,dtype=int)
assert len(seams) and len(rest)==5679

def vertex(joints, weights):
    return np.einsum('vabc,va,vc->vb',joints[j],weights,xyz)[:,:3]

def compare(matrices):
    v, prior=(vertex(matrices, weights) for weights in (w,w_norm))
    current,_=geom(v,indices)
    norm,_=geom(prior,indices)
    assert np.max(abs(v))<10 and np.isfinite(v).all()
    deviations=np.linalg.norm(v-prior,axis=-1)
    def gaps(p):
        return np.linalg.norm(p[seams[:,0]]-p[seams[:,1]],axis=-1)
    seam,norm_seam=gaps(v),gaps(prior)
    return dict(newDegenerate=int(((rest>1e-12)&(current<=1e-12)).sum()),
                newlyDegenerateVsNormalized=int(((norm>1e-12)&(current<=1e-12)).sum()),
                maxShiftM=float(deviations.max()),maxSeamM=float(seam.max()),
                maxSeamIncreaseM=float((seam-norm_seam).max()),
                pointMaxShift=int(deviations.argmax()),worstSeam=seams[seam.argmax()].tolist())

clips=[]
for clip in doc['animations']:
    events=animation['sampler'](clip)
    times=np.linspace(min(x[3][0] for x in events),max(x[3][-1] for x in events),7)
    clips.append(dict(name=clip['name'],poses=[dict(time=float(t),**compare(animation['evaluate'](events,t)))
                                             for t in times]))
all_poses=[dict(clip=clip['name'],**p) for clip in clips for p in clip['poses']]
worst=lambda k:max(all_poses,key=lambda a:a[k])
assert len(all_poses)==70
summary=dict(status='measured CPU deformation from serialized native-precision glTF; Player validation pending',
             asset=report['serializedSha256'],poses=len(all_poses),seams=len(seams),
             worstShift=worst('maxShiftM'),largestSeam=worst('maxSeamM'),worstSeamIncrease=worst('maxSeamIncreaseM'),
             newDegenerate=sum(p['newDegenerate'] for p in all_poses),
             newlyDegenerateVsNormalized=sum(p['newlyDegenerateVsNormalized'] for p in all_poses))
(run/'animated-body-serialized-native-weight-clips.json').write_text(json.dumps(dict(**summary,clips=clips),indent=2)+'\n',encoding='utf8')
print(json.dumps(summary))
