from pathlib import Path
from hashlib import sha256
import itertools
import json
import numpy as np

M=Path(__file__).resolve().parent
P=M/'retained-body-cloth-actual-vertex-outputs'
N=M/'body-native-cloth-outline-geometry'
read=lambda p:json.loads(p.read_bytes())
dig=lambda p:sha256(p.read_bytes()).hexdigest()
player=read(P/'results.json')
native=read(N/'results.json')
assert player['status']=='retained-body-cloth-actual-vertex-outputs' and native['status']=='qualified'


def extract(stage,engine):
    if engine:
        r=player['vertexOutputs'][stage]
        f=r['files']
        position,index=[P/f[k]['file'] for k in ('clip','indices')]
        assert all(dig(q)==f[k]['sha256'] for q,k in ((position,'clip'),(index,'indices')))
        assert r['baseVertex']==0 and r['outputSignature'][0]=='ShaderBuiltin.Position'
        v=np.fromfile(position,'<f4').reshape(-1,4)
        ix=np.fromfile(index,'<u'+str(r['indexStride'])).reshape(-1,3)
        assert len(v)==r['vertexCount'] and ix.size==r['drawIndices']
    else:
        r=native['devices']['nvidia'][stage]['geometry']
        f=r['position.bin']
        g=r['index.bin']
        position,index=(N/f['file'],N/g['file'])
        assert dig(position)==f['sha256'] and dig(index)==g['sha256']
        v=np.fromfile(position,'<f4').reshape(-1,23)[:,:4]
        ix=np.fromfile(index,'<u2').reshape(-1,3)
    assert np.all(v[:,3]>0) and int(ix.max())<len(v) and np.isfinite(v).all()
    screen=(v[:,:2]/v[:,3,None]+np.float32(1))*np.array([1280,720],np.float32)
    return np.column_stack((screen,v[:,3]))[ix],dict(vertices=dig(position),indices=dig(index))


def covered(triangles,sites):
    xy=np.rint(triangles[:,:,:2]*256).astype(np.int64)
    a,b=xy[:,1]-xy[:,0],xy[:,2]-xy[:,0]
    signed=a[:,0]*b[:,1]-a[:,1]*b[:,0]
    xy=np.where((signed<0)[:,None,None],xy[:,[0,2,1]],xy)
    edge=np.roll(xy,-1,axis=1)-xy
    top=(edge[:,:,1]<0)|((edge[:,:,1]==0)&(edge[:,:,0]>0))
    result={}
    for x,y in sites:
        delta=np.array([x*256+128,y*256+128])-xy
        c=edge[:,:,0]*delta[:,:,1]-edge[:,:,1]*delta[:,:,0]
        inside=np.all((c>0)|((c==0)&top),axis=1)&(signed!=0)
        result[(x,y)]=np.flatnonzero(inside).tolist()
    return result


def near_triangle(native_triangle,player_triangles):
    ref=native_triangle[:,:2]
    means=player_triangles[:,:,:2].mean(1)
    distance=np.sum((means-ref.mean(0))**2,axis=1)
    candidates=np.argpartition(distance,12)[:12]
    closest=None
    for i in candidates:
        for order in itertools.permutations(range(3)):
            tri=player_triangles[i,list(order)]
            delta=tri-native_triangle
            displacement=np.linalg.norm(delta[:,:2],axis=1).max()
            if closest is None or displacement<closest['maximumXYDisplacement']:
                closest=dict(playerTriangle=int(i),maximumXYDisplacement=float(displacement),
                             orderedCorners=order,deltaScreenXYAndClipW=delta.tolist(),
                             originalVertices=native_triangle.tolist(),playerVertices=tri.tolist())
    return closest


cases={}
for pe,ne,sites in (
        ('839','1079',[(1200,379),(1206,374),(1201,379),(1274,523)]),
        ('845','1116',[(1197,854),(1211,830)])):
    a,ap=extract(pe,True)
    b,bp=extract(ne,False)
    km=covered(a,sites)
    kn=covered(b,sites)
    if pe=='839':
        assert km[(1200,379)]==km[(1206,374)]==[]
        assert kn[(1200,379)]==[22868] and kn[(1206,374)]==[22811,22866]
        assert 22876 in km[(1201,379)] and 19607 in km[(1274,523)]
    else:
        assert km[(1211,830)]==[19439] and kn[(1211,830)]==[31,303,19492]
    cases[ne]=dict(playerEvent=pe,nativeFaces=len(b),playerFaces=len(a),playerSource=ap,nativeSource=bp,
        samples=[dict(point=site,nativeCandidates=kn[site],playerCandidates=km[site],
                      closest=[dict(nativeTriangle=i,**near_triangle(b[i],a)) for i in kn[site]]) for site in sites])
out=M/'body-cloth-actual-vertex-overlap.json'
out.write_text(json.dumps(dict(status='measured-recorded-native-player-cloth-vertex-coverage',cases=cases),
                          indent=2)+'\n',encoding='utf8')
for e,value in cases.items():
    print(e,[(p['point'],len(p['nativeCandidates']),len(p['playerCandidates']),
              [round(x['maximumXYDisplacement'],5) for x in p['closest']]) for p in value['samples']])
