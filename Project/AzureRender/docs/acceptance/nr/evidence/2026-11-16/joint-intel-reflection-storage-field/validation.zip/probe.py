"""Read the bound compute reflection in a small reporting area of the same beauty frame."""
import json
from pathlib import Path
import runpy
import subprocess
import sys
from zipfile import ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
body=runpy.run_path(str(M/'joint-character-referenced-body.py'),run_name='reflection_storage_camera')
glsl=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='reflection_storage_catalog')
R,B=glsl['R'],glsl['B']
H,art,check,read,write,sha=[glsl[k] for k in ('H','art','check','read','write','sha')]
C=M/'joint-character-referenced-body'
O=M/'joint-intel-reflection-storage-field-probe'
variants=tuple('mesh_object_clipmap_field'+suffix+'.frag.spv' for suffix in ('','_early','_lighting','_early_lighting'))
glsl['activate_links'].__wrapped__.__globals__['home']=O
assert body['OUT']==C
old='''    vec3 qaColor = beautyColor;
    if (qaIsolationMode == 1) {'''
new='''    vec3 qaColor = beautyColor;
#if !defined(AZURE_OPAQUE_SNAPSHOT)
        // Report sampled raw reflection and confidence from the disputed floor area.
        vec2 probe = AZURE_FRAGMENT_COORD.xy;
        if (qaIsolationMode==0 && camera.screenReflectionTrace.x>1.5 && all(greaterThanEqual(probe,vec2(0)))
            && probe.x<576 && probe.y<72) {
            int lane=int(probe.x)/96;
            int kind=lane%3;
            vec2 anchor=vec2(mod(probe.x,96),probe.y)+vec2(896,lane>=3 ? 160 : 608);
            vec4 sampleValue=sampleComputedScreenReflection(anchor/vec2(textureSize(opaqueSceneColor,0)));
            qaColor=kind==1 ? vec3(clamp(sampleValue.a,0,1))
                    : max(vec3(0),sampleValue.rgb)/(vec3(1)+max(vec3(0),sampleValue.rgb));
            if (kind==2) {
                vec4 surface=texelFetch(overlaySceneDepth,ivec2(anchor),0);
                qaColor=vec3(clamp(surface.r/(32+surface.r),0,1),surface.gb);
            }
        }
#endif
    if (qaIsolationMode == 1) {'''


def source_input():
    p=W/'shaders/mesh.frag'
    s=p.read_text(encoding='utf8')
    assert s.count(old)==1
    assert 'layout(rgba32f,binding=37) uniform readonly image2D computedScreenReflection;' in s
    baseline=subprocess.check_output(['git','show','75837a6:Project/AzureRender/shaders/mesh.frag'],cwd=W,encoding='utf8')
    assert s==baseline
    rule={entry['output']:entry['defines'] for entry in read(R/'msaa-release/shader-reload.json')['programs']}
    assert all(set(rule[k])>={'AZURE_IRRADIANCE_CLIPMAP=1','AZURE_PROBE_FIELD=1'} for k in variants)
    return p,s.replace(old,new)


def run():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    budget=check(B,run=M,planned=8_900_000)
    assert budget['allowed'],budget
    basecode,changed=source_input()
    (O/'programs').mkdir(parents=True,exist_ok=True)
    source=O/'mesh.frag'
    source.write_text(changed,encoding='utf8')
    for name in variants:
        H['compile_program'](source,O/'programs'/name,name,diagnostics=O/'compile'/f'{name}.log')
    programs={name:sha(O/'programs'/name) for name in variants}
    core,assets,_=body['prepare']()
    with art.database(B) as c:
        pinned=art.rows(c)[R.name]
    assert pinned['status']=='closed'
    base=M/'character-six-view-inputs/intel-back-detail/frames/frame_000000.png'
    ref=cv2.imread(str(base),cv2.IMREAD_UNCHANGED)
    assert ref.shape==(720,1280,4)
    old_group={}
    for mode in ('native','native-repeat','serial-a'):
        with ZipFile(C/f'intel-{mode}.zip') as z:
            old_group[mode]=ref^np.frombuffer(z.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
    reads={}
    pixels={}
    art.resume(B,R.name)
    try:
        with glsl['activate_links'](programs), body['temporary_descriptor'](assets[1]) as descriptor:
            for label,serial in (('a',False),('b',False),('serial',True)):
                args=[]
                if serial:
                    args.append('--disable-parallel-recording')
                kind=f'storage-field-probe-{label}'
                d=body['capture']('intel',kind,descriptor,args)
                manifest=read(C/f'intel-{kind}/frames/capture_manifest.json')
                assert manifest['qaIsolation']=='beauty' and manifest['screenReflectionProducer']=='linear-temporal'
                assert manifest['irradianceResourceKind']=='clipmap' and manifest['objectShadowPrepared']
                log=(C/f'intel-{kind}'/'player.log').read_text('utf8',errors='replace')
                assert 'Reflection field: 12 local probes' in log and 'Character texture access: fixed' in log
                with ZipFile(C/f'intel-{kind}.zip') as z:
                    pixels[label]=ref^np.frombuffer(z.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
                m=pixels[label]
                reads[label]=dict(frame=d,againstKnown={
                     k:int(np.any(x[72:]!=m[72:],axis=2).sum()) for k,x in old_group.items()})
                assert min(reads[label]['againstKnown'].values())<5000,reads[label]
                assert min(np.any(x[:72,:576]!=m[:72,:576],axis=2).sum() for x in old_group.values())>1000
                write(O/'readbacks.json',reads)
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=90)
    with art.database(B) as c:
        result=art.rows(c)[R.name]
    assert result['status']=='closed' and result['manifestSha256']==pinned['manifestSha256']
    pairs={}
    for a,b in [('a','b'),('a','serial'),('b','serial')]:
        diff=np.abs(pixels[a].astype(np.int16)-pixels[b].astype(np.int16)).max(axis=2)
        pairs[a+'-'+b]=dict(
            storedRgbChanged=int((diff[:72,:96]>0).sum()),
            storedConfidenceChanged=int((diff[:72,96:192]>0).sum()),
            floorInputSurfaceChanged=int((diff[:72,192:288]>0).sum()),
            upperStoredRgbChanged=int((diff[:72,288:384]>0).sum()),
            upperStoredConfidenceChanged=int((diff[:72,384:480]>0).sum()),
            upperInputSurfaceChanged=int((diff[:72,480:576]>0).sum()),
            realFloorChanged=int((diff[608:680,896:992]>0).sum()),
            realUpperChanged=int((diff[160:232,896:992]>0).sum()),
            otherImageChanged=int((diff[72:]>0).sum()))
    r=dict(status='measured-reflection-storage-in-same-frame',reads=reads,pairs=pairs,
           player=core['player'],programs=programs,source=sha(basecode),diagnosticSource=sha(source))
    write(O/'qualification.json',r)
    print(pairs)


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(sha(source_input()[0]))
    else:
        run()
