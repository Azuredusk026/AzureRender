"""Track actual face rim perturbations through the retained Vulkan display output."""
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import traceback

key='AZR_RETAINED_FACE_DISPLAY_READBACK'
root=Path(os.environ[key]).parents[1] if key in os.environ else Path(__file__).resolve().parent
group=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
out=Path(os.environ[key]).parent if key in os.environ else root/'retained-face-display-readback'
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
points=[[1306,304],[1313,297],[1312,298],[1301,306],[1296,310],[1288,315]]
variables=('sceneMainDiffuse','ambientDiffuse','rimLighting','directSpecular','ambientSpecular','beautyColor')
read=lambda p:json.loads(Path(p).read_bytes())
write=lambda p,d:Path(p).write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
sha=lambda b:sha256(b).hexdigest()


def override(assembly,var):
    main,tail=assembly.split('OpFunctionEnd',1)
    declaration=rf'%{var} = OpVariable %_ptr_Function_v3float Function'
    assert re.search(declaration,main),var
    matches=list(re.finditer(r'^ +OpStore %outputColor %\w+\s*$',main,re.M))
    assert len(matches)>=1
    m=matches[-1]
    replacement=f'''   %azr_probe_vec = OpLoad %v3float %{var}
     %azr_probe_r = OpCompositeExtract %float %azr_probe_vec 0
     %azr_probe_g = OpCompositeExtract %float %azr_probe_vec 1
     %azr_probe_b = OpCompositeExtract %float %azr_probe_vec 2
   %azr_probe_rgb = OpCompositeConstruct %v4float %azr_probe_r %azr_probe_g %azr_probe_b %float_1
                  OpStore %outputColor %azr_probe_rgb'''
    return main[:m.start()]+replacement+main[m.end():]+'OpFunctionEnd'+tail


def contribution_gain(assembly,var,gain):
    assembly=assembly.replace('\r\n','\n')
    main,tail=assembly.split('OpFunctionEnd',1)
    stores=list(re.finditer(rf'^ +OpStore %{var} %\w+\s*$',main,re.M))
    assert len(stores)>=2,var
    boundary=stores[-1].end()
    loads=list(re.finditer(rf'^ *(%\w+) = OpLoad %v3float %{var} *$',main[boundary:],re.M))
    assert len(loads)>=1,(var,len(loads))
    for i,m in reversed(list(enumerate(loads))):
        label=f'%azr_{var}_value_{i}'
        code=(f'{label} = OpLoad %v3float %{var}\n'
              f'{m[1]} = OpVectorTimesScalar %v3float {label} %azr_{var}_gain')
        main=main[:boundary+m.start()]+code+main[boundary+m.end():]
    marker=re.search(r'^ *%main = OpFunction ',main,re.M)
    assert marker
    main=main[:marker.start()]+f'%azr_{var}_gain = OpConstant %float {gain}\n'+main[marker.start():]
    return main+'OpFunctionEnd'+tail


def worker():
    import renderdoc as rd
    req=read(out/'request.json')
    cap=rd.OpenCaptureFile();ctl=None;replace=None;original=None
    result=dict(status='incomplete',request=req,variables={})
    try:
        assert cap.OpenFile(req['capture'],'',None)==rd.ResultCode.Succeeded
        options=rd.ReplayOptions()
        options.forceGPUVendor=rd.GPUVendor.nVidia;options.forceGPUDeviceID=0x28e0
        status,ctl=cap.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and ctl is not None
        props=ctl.GetAPIProperties()
        assert props.pipelineType==rd.GraphicsAPI.Vulkan and props.vendor==rd.GPUVendor.nVidia and not props.degraded
        event=req['event'];ctl.SetFrameEvent(event,True)
        def walk(rows):
            for a in rows:
                yield a
                yield from walk(a.children)
        draw,=[a for a in walk(ctl.GetRootActions()) if a.eventId==event]
        assert draw.numIndices==8718 and draw.flags&rd.ActionFlags.Drawcall
        pipe=ctl.GetPipelineState();stage=rd.ShaderStage.Fragment
        ref=pipe.GetShaderReflection(stage);original=pipe.GetShader(stage);raw=bytes(ref.rawBytes)
        assert sha(raw)==req['shader']
        assert bytes(ctl.GetVulkanPipelineState().pushconsts)[112:128].hex()==req['push']
        color=pipe.GetOutputTargets()[0].resource
        tex,=[t for t in ctl.GetTextures() if t.resourceId==color]
        assert (str(color),tex.width,tex.height,tex.format.Name())==('ResourceId::175',2560,1440,'R16G16B16A16_FLOAT')
        textures={str(t.resourceId):t for t in ctl.GetTextures()}
        actions=list(walk(ctl.GetRootActions()))
        presents=[a for a in actions if a.flags&rd.ActionFlags.Present]
        scan=[]
        for a in actions[-35:]:
            scan.append(dict(event=a.eventId,flags=int(a.flags),name=a.customName,
                             source=str(a.copySource),destination=str(a.copyDestination),
                             colors=[str(t) for t in a.outputs]))
        swaps={k:dict(format=t.format.Name(),extent=[t.width,t.height]) for k,t in textures.items()
               if t.creationFlags&rd.TextureCategory.SwapBuffer}
        result['endActions']=scan
        result['swapTextures']=swaps
        assert presents and swaps
        last=presents[-1]
        present_targets=[str(t) for t in (last.copyDestination,last.copySource,*last.outputs)
                         if str(t) in swaps]
        if not present_targets:
            hits=[str(a.copyDestination) for a in actions[-35:] if str(a.copyDestination) in swaps]
            present_targets=hits or list(swaps)
        assert len(set(present_targets))==1,present_targets
        dst=textures[present_targets[-1]]
        assert (dst.width,dst.height)==(2560,1440),swaps
        fmt=dst.format.Name()
        assert fmt.startswith(('B8G8R8A8','R8G8B8A8')),fmt
        swizzle=(2,1,0) if fmt.startswith('B8') else (0,1,2)
        result['display']=dict(event=last.eventId,target=str(dst.resourceId),format=fmt,rgbChannels=swizzle)

        def sample_attachment(e):
            ctl.SetFrameEvent(e,True)
            payload=bytes(ctl.GetTextureData(color,rd.Subresource()))
            assert len(payload)==tex.width*tex.height*8
            return dict(imageSha256=sha(payload),values=[struct.unpack_from('<4e',payload,8*(tex.width*y+x))
                            for x,y in req['points']])

        def sample(e):
            opaque=sample_attachment(e)
            ctl.SetFrameEvent(last.eventId,True)
            payload=bytes(ctl.GetTextureData(dst.resourceId,rd.Subresource()))
            assert len(payload)==dst.width*dst.height*4
            values=[tuple(payload[4*(dst.width*y+x)+k] for k in swizzle) for x,y in req['points']]
            final_scene=sample_attachment(last.eventId)
            return dict(attachment=opaque,display=dict(imageSha256=sha(payload),values=values),
                        lastScene=final_scene)
        result['baseline']=sample(event)
        result['preceding']=sample(event-1)
        assert result['baseline']['attachment']['imageSha256']==req['baseline']
        result['history']=[]
        ctl.SetFrameEvent(event,True)
        for x,y in req['points']:
            hit=[h for h in ctl.PixelHistory(color,x,y,rd.Subresource(),rd.CompType.Typeless)
                 if h.eventId==event and not (h.depthTestFailed or h.stencilTestFailed or h.backfaceCulled or h.shaderDiscarded)]
            result['history'].append([dict(primitive=int(h.primitiveID),rgb=list(h.shaderOut.col.floatValue),
                before=list(h.preMod.col.floatValue),after=list(h.postMod.col.floatValue)) for h in hit])
        result['coveredWitnesses']=[bool(v) for v in result['history']]
        assert any(result['coveredWitnesses'][:3]) and any(result['coveredWitnesses'][3:])
        def modify(code):
            nonlocal replace
            replace,err=ctl.BuildTargetShader(ref.entryPoint,rd.ShaderEncoding.SPIRV,code,rd.ShaderCompileFlags(),stage)
            assert replace!=rd.ResourceId.Null(),err
            ctl.ReplaceResource(original,replace)
            try:return sample(event)
            finally:
                ctl.RemoveReplacement(original);ctl.FreeTargetResource(replace);replace=None
        result['copy']=modify(raw)
        assert result['copy']==result['baseline']
        asm=subprocess.run([str(sdk/'spirv-dis.exe'),'-','-o','-'],input=raw,capture_output=True,check=True,timeout=30).stdout.decode('utf8')
        version=re.search(r'^; Version: (\S+)',asm,re.M)[1]
        target={'1.0':'vulkan1.0','1.3':'vulkan1.1','1.4':'vulkan1.1spv1.4','1.5':'vulkan1.2','1.6':'vulkan1.3'}[version]
        variants={'rimOne':contribution_gain(asm,'sceneRim',1.0),
                  'rimZero':contribution_gain(asm,'sceneRim',0.0),
                  'withoutLocal':contribution_gain(asm,'clusteredDiffuse',0.0),
                  'withoutLocalOrRim':contribution_gain(
                      contribution_gain(asm,'sceneRim',0.0),'clusteredDiffuse',0.0)}
        for v,source in variants.items():
            assembled=subprocess.run([str(sdk/'spirv-as.exe'),'--target-env',target,'-','-o','-'],
                input=source.encode('utf8'),capture_output=True,timeout=30)
            assert assembled.returncode==0,assembled.stderr.decode('utf8')
            compiled=assembled.stdout
            assert compiled and sha(compiled)!=sha(raw)
            valid=subprocess.run([str(sdk/'spirv-val.exe'),'--target-env',target,'--relax-block-layout','-'],
                                 input=compiled,capture_output=True,timeout=30)
            assert valid.returncode==0,valid.stderr.decode('utf8')
            result['variables'][v]=dict(program=sha(compiled),**modify(compiled))
            write(out/'checkpoint.json',result)
        assert all(result['coveredWitnesses'])
        assert all(result['variables']['rimOne'][k]==result['baseline'][k] for k in ('attachment','display','lastScene'))
        assert result['variables']['rimZero']['attachment']['imageSha256']!=result['baseline']['attachment']['imageSha256']
        result['restored']=sample(event)
        assert result['restored']==result['baseline']
        result['status']='qualified-retained-player-face-lighting'
    except BaseException:
        result['error']=traceback.format_exc()
    finally:
        write(out/'results.json',result)
        if ctl:
            if replace is not None and replace!=rd.ResourceId.Null():
                ctl.RemoveReplacement(original);ctl.FreeTargetResource(replace)
            ctl.Shutdown()
        cap.Shutdown()
    os._exit(0 if result['status'].startswith('qualified') else 1)


def request():
    from hashlib import file_digest
    previous=read(group/'engine-face-color/results.json')
    old=read(group/'engine-face-color/request.json')
    assert previous['status']=='qualified'
    row,=[r for r in previous['events'] if r['event']==876]
    assert row['names']==['mesh_object_early_lighting.frag.spv']
    with open(old['capture'],'rb') as stream:
        identity=file_digest(stream,'sha256').hexdigest()
    assert identity=='6960267c0d71e4d05b6bfe0e2730c332ed71955f1fde6d69eb7d8aadf13eff24'
    assert bytes.fromhex(row['classAndFlags'])[0]==2
    return dict(event=876,shader=row['shaderSha256'],push=row['classAndFlags'],capture=old['capture'],captureSha256=identity,
                baseline=row['selection']['baseline']['fullSha256'],points=points,groups=['dark']*3+['bright']*3)


def run():
    global out
    lease=read('D:/Projects/FYP-coordination/resources/current.json')
    assert lease['state']=='held' and lease['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9' and Path(lease['output'])==root
    sys.path.insert(0,str(root.parents[2]/'tools'))
    from artifact_budget import check
    budget=check(root.parents[1],run=root,planned=140000)
    assert budget['allowed'],budget
    out.mkdir(exist_ok=True)
    req=request()
    req['probe']='retained-display-lineage'
    write(out/'request.json',req)
    env=dict(os.environ,**{key:str(out/'request.json'),'VK_DRIVER_FILES':str(group/'nv-vk64-active-absolute.json')})
    si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
    with (out/'replay.log').open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
             cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=si,timeout=360)
    receipt=read(out/'results.json')
    assert receipt['request']==req and child.returncode==0 and receipt['status'].startswith('qualified'),receipt.get('error')
    for name,rows in receipt['variables'].items():print(name,rows['display']['values'])


if key in os.environ:
    worker()
elif __name__=='__main__':
    a,=sys.argv[1:]
    if a=='preflight':print(json.dumps(request()))
    else:
        assert a=='run';run()
