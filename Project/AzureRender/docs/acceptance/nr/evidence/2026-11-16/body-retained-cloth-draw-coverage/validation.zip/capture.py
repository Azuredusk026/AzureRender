from hashlib import sha256
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import traceback

k='AZR_NR_RETAINED_BODY_CLOTH_PEAK'
M=Path(os.environ[k]).parents[1] if k in os.environ else Path(__file__).resolve().parent
W=M.parents[2]
G=M.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
O=M/'retained-body-cloth-peak-color-stages-compatible'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,a:p.write_text(json.dumps(a,indent=2)+'\n',encoding='utf8')
positions=((1200,379),(1206,374),(1197,854),(1211,830),(1274,523),(1201,379))
def digest(p):
    from hashlib import file_digest
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()


def worker():
    import renderdoc as rd
    req=read(Path(os.environ[k]))
    write(O/'progress.json',dict(stage='worker-entered',capture=req['capture']))
    cap=rd.OpenCaptureFile()
    ctl=None
    result=dict(status='failed',request=req)
    try:
        assert cap.OpenFile(req['capture'],'',None)==rd.ResultCode.Succeeded
        options=rd.ReplayOptions()
        options.forceGPUVendor=rd.GPUVendor.nVidia
        options.forceGPUDeviceID=0x28e0
        code,ctl=cap.OpenCapture(options,None)
        assert code==rd.ResultCode.Succeeded and ctl
        write(O/'progress.json',dict(stage='capture-open'))
        props=ctl.GetAPIProperties()
        assert props.pipelineType==rd.GraphicsAPI.Vulkan and props.vendor==rd.GPUVendor.nVidia and not props.degraded
        def walk(rows):
            for a in rows:
                yield a
                yield from walk(a.children)
        actions=list(walk(ctl.GetRootActions()))
        last=[a for a in actions if a.flags&rd.ActionFlags.Present][-1]
        ctl.SetFrameEvent(req['controlEvent'],True)
        pipe=ctl.GetPipelineState()
        target=pipe.GetOutputTargets()[0].resource
        assert str(target)=='ResourceId::175'
        tex={str(t.resourceId):t for t in ctl.GetTextures()}
        image=tex[str(target)]
        assert (image.width,image.height,image.format.Name())==(2560,1440,'R16G16B16A16_FLOAT')
        swaps={s:t for s,t in tex.items() if t.creationFlags&rd.TextureCategory.SwapBuffer}
        options=[str(t) for t in (last.copyDestination,last.copySource,*last.outputs) if str(t) in swaps]
        if not options:
            options=[str(a.copyDestination) for a in actions[-35:] if str(a.copyDestination) in swaps] or list(swaps)
        assert len(set(options))==1,options
        display=swaps[options[-1]]
        fmt=display.format.Name()
        assert fmt.startswith(('B8G8R8A8','R8G8B8A8')),fmt
        swizzle=(2,1,0) if fmt.startswith('B8') else (0,1,2)
        ctl.SetFrameEvent(last.eventId,True)
        fp=bytes(ctl.GetTextureData(display.resourceId,rd.Subresource()))
        assert len(fp)==2560*1440*4
        result.update(playerDisplaySha256=sha256(fp).hexdigest(),displayEvent=last.eventId,attachment=str(target),points=[])
        result['points']=[]
        assert len(req['points'])==len(req['currentFixedPoseRGB'])==6
        for (x,y),now in zip(req['points'],req['currentFixedPoseRGB']):
            actual=[fp[4*(2560*y+x)+i] for i in swizzle]
            result['points'].append(dict(point=[x,y],retainedDisplay=actual,currentFixedPose=now,exact=actual==now,draws=[]))
        write(O/'results.json',result)
        earlier=[]
        scene=[a for a in actions if a.flags&rd.ActionFlags.Drawcall and target in a.outputs and a.eventId>=730]
        assert len(scene)<=58 and len(scene)>=6 and any(a.eventId==876 for a in scene),(len(scene),[a.eventId for a in scene])
        result['sceneCandidates']=[dict(event=a.eventId,indices=a.numIndices,name=a.customName) for a in scene]
        write(O/'progress.json',dict(stage='display-witnesses-read',candidates=result['sceneCandidates']))
        for a in scene:
            ctl.SetFrameEvent(a.eventId,True)
            raw=bytes(ctl.GetTextureData(target,rd.Subresource()))
            assert len(raw)==2560*1440*8
            colors=[struct.unpack_from('<4e',raw,8*(2560*y+x)) for x,y in req['points']]
            for index,color in enumerate(colors):
                if not earlier or color!=earlier[index]:
                    result['points'][index]['draws'].append(dict(event=a.eventId,indices=a.numIndices,after=color))
            earlier=colors
            result['lastAppliedEvent']=a.eventId
            write(O/'results.json',result)
        result.update(status='retained-body-and-cloth-color-stages',
                      exactCurrentWitnesses=sum(p['exact'] for p in result['points']))
    except Exception:
        result['error']=traceback.format_exc()
    finally:
        write(O/'results.json',result)
        if ctl:ctl.Shutdown()
        cap.Shutdown()
    os._exit(0 if result['status']=='retained-body-and-cloth-color-stages' else 1)


def run():
    from PIL import Image
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    assert check(W/'build',run=M,planned=185_000)['allowed']
    old=read(G/'engine-face-color/request.json')
    candidate=Path(old['capture'])
    target='6960267c0d71e4d05b6bfe0e2730c332ed71955f1fde6d69eb7d8aadf13eff24'
    assert digest(candidate)==target
    reference=R/'face-quality-release-isolated-mask/public-combined-nvidia/frames/frame_000000.png'
    with Image.open(reference) as im:
        sample=[list(im.convert('RGB').getpixel(p)) for p in positions]
    O.mkdir()
    job=O/'request.json'
    write(job,dict(capture=str(candidate),captureSha256=target,currentFixedPoseSha256=digest(reference),controlEvent=876,
                   points=positions,currentFixedPoseRGB=sample))
    env=dict(os.environ,**{k:str(job),'VK_DRIVER_FILES':str(G/'nv-vk64-active-absolute.json')})
    si=subprocess.STARTUPINFO()
    si.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow=0
    with (O/'replay.log').open('wb') as diagnostics:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe',
                             '--python',str(Path(__file__).resolve())],cwd=O,env=env,
                             stdout=diagnostics,stderr=subprocess.STDOUT,startupinfo=si,timeout=370)
    report=read(O/'results.json')
    assert child.returncode==0 and report['status']=='retained-body-and-cloth-color-stages',report.get('error')
    assert report['request']==read(job)
    print(report['exactCurrentWitnesses'],[(p['point'],[x['event'] for x in p['draws']]) for p in report['points']])

if k in os.environ:
    worker()
elif __name__=='__main__':
    run()
