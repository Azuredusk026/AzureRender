"""Read the observed native temporal blend for registered reflection sources."""
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import traceback

KEY='AZURE_NR_NATIVE_REFLECTION_TEMPORAL_SAMPLES'
M=Path(os.environ[KEY]).parent if KEY in os.environ else Path(__file__).resolve().parent
out=M/'projected-history-temporal-samples'
src=M/'projected-history-native-temporal-writer'
read=lambda p:json.loads(Path(p).read_bytes())
write=lambda p,v:Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf8')
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
stages={25:['r3','r2'],66:['r15'],151:['r17'],155:['r15'],162:['r17'],168:['r12'],
    173:['r6'],184:['r7'],191:['r6'],324:['r0'],339:['r0'],376:['r6'],379:['r3'],
    384:['r1'],387:['r3'],411:['r0','r1','r3'],412:['r2'],413:['r0'],422:['o0'],423:['o0']}


def request():
    p=read(src/'request.json')
    q=read(src/'results.json')
    e=q['events']['11195']
    assert q['request']==digest(src/'request.json') and e['disassembly']==digest(src/'event-11195.asm')
    c=read(src/'hdr-source-comparison.json')
    glyphs=[x for x in c['points'] if x['draws']==[10480]]
    assert len(glyphs)==27
    glyphs.sort(key=lambda x:(x['hdr']['nativePrevious'][0],x['point']))
    rows=[dict(point=v,kind='crate') for v in p['points']]
    rows.extend(dict(point=x['point'],kind='glyph') for x in (glyphs[3],glyphs[13],glyphs[23]))
    assert len({tuple(x['point']) for x in rows})==8
    return dict(capture=p['capture'],event=11195,shader=e['hash'],resources=dict(
       history=p['prior'], current=e['read']['0']['resource']['resource'], resolved=p['nextImage']),
       rows=rows, reference=digest(src/'results.json'), assembly=e['disassembly'])


def worker():
    import renderdoc as rd
    req=read(out/'request.json')
    result=dict(status='failed',request=digest(out/'request.json'),rows=[])
    cap=rd.OpenCaptureFile()
    c=None
    try:
        write(out/'progress.json',dict(stage='open'))
        assert cap.OpenFile(req['capture'],'',None)==rd.ResultCode.Succeeded
        status,c=cap.OpenCapture(rd.ReplayOptions(),None)
        assert status==rd.ResultCode.Succeeded and c
        api=c.GetAPIProperties()
        assert api.pipelineType==rd.GraphicsAPI.D3D11 and not api.degraded
        result['adapter']=str(api.vendor)
        t={str(a.resourceId):a.resourceId for a in c.GetTextures()}
        c.SetFrameEvent(req['event'],True)
        pipe=c.GetPipelineState()
        shader=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
        assert hashlib.sha256(bytes(shader.rawBytes)).hexdigest()==req['shader']
        assert str(pipe.GetOutputTargets()[0].resource)==req['resources']['resolved']
        for row in req['rows']:
            x,y=row['point']
            y=1439-y
            write(out/'progress.json',dict(row=row,done=len(result['rows'])))
            c.SetFrameEvent(req['event'],True)
            picked={name:list(c.PickPixel(t[r],x,y,rd.Subresource(),rd.CompType.Typeless).floatValue)
                    for name,r in req['resources'].items()}
            trace=c.DebugPixel(x,y,rd.DebugPixelInputs())
            assert trace and trace.debugger,row
            states={}
            state={}
            count=0
            try:
                while True:
                    block=c.ContinueDebug(trace.debugger)
                    if not block:
                        break
                    for step in block:
                        count+=1
                        pc=int(step.nextInstruction)
                        for change in step.changes:
                            a=change.after
                            if a.name:
                                state[a.name]=[v if math.isfinite(v) else None for v in list(a.value.f32v)[:4]]
                        if pc in stages:
                            states[str(pc)]={name:state[name] for name in stages[pc] if name in state}
                    assert count<50000
            finally:
                c.FreeTrace(trace)
            assert {'66','184','379','411','413','423'}<=states.keys(), states.keys()
            v=states['423']['o0']
            picked_output=picked['resolved']
            tolerance=[max(.000003,abs(q)/512) for q in picked_output]
            assert all(abs(a-b)<=eps for a,b,eps in zip(v,picked_output,tolerance)), (row,v,picked_output)
            alpha=states['411']['r0'][1]
            assert 0<=alpha<=1
            cur=states['411']['r1'][:3]
            old=[states['411']['r3'][i] for i in (0,2,3)]
            mixed=states['413']['r0'][1:]
            assert all(abs(a-alpha*b-(1-alpha)*q)<.000002 for a,b,q in zip(mixed,old,cur)), (row,mixed,old,cur,alpha)
            result['rows'].append(dict(**row,picked=picked,historyWeight=alpha,
                currentCompressed=cur,clippedHistoryCompressed=old,mixedCompressed=mixed,states=states))
        result['status']='qualified-native-reflection-temporal-weights'
    except BaseException:
        result['error']=traceback.format_exc()
    finally:
        write(out/'results.json',result)
        if c:
            c.Shutdown()
        cap.Shutdown()
    os._exit(0 if result['status'].startswith('qualified') else 1)


def run():
    t=read('D:/Projects/FYP-coordination/resources/current.json')
    assert t['state']=='held' and Path(t['output'])==M
    sys.path.insert(0,str(M.parents[2]/'tools'))
    from artifact_budget import check
    assert check(M.parents[1],run=M,planned=425_000)['allowed']
    out.mkdir(exist_ok=True)
    p=out/'request.json'
    write(p,request())
    start=subprocess.STARTUPINFO()
    start.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    with (out/'replay.log').open('wb') as f:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=out,env=dict(os.environ,**{KEY:str(out)}),startupinfo=start,stdout=f,stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,timeout=160)
    result=read(out/'results.json')
    assert child.returncode==0 and result['status'].startswith('qualified') and result['request']==digest(p),result.get('error')
    print([(r['point'],r['kind'],r['historyWeight']) for r in result['rows']])


if KEY in os.environ:
    worker()
elif __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(request())
    else:
        run()
