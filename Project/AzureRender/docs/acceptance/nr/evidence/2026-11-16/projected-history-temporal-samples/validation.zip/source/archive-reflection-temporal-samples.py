"""Archive pointwise RGB reconstruction and blend weight evidence."""
import json
from hashlib import sha256
from pathlib import Path
import sqlite3
from zipfile import ZIP_DEFLATED, ZipFile

M=Path(__file__).resolve().parent
src=M/'projected-history-temporal-samples'
out=M.parents[2]/'docs/acceptance/nr/evidence/2026-11-16'/src.name
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
q=read(src/'results.json')
req=read(src/'request.json')
assert q['status']=='qualified-native-reflection-temporal-weights'
assert q['request']==digest(src/'request.json')
assert req['reference']==digest(M/'projected-history-native-temporal-writer/results.json')
assert len(q['rows'])==8
reduced=[]
for p in q['rows']:
    row={k:p[k] for k in ('point','kind','historyWeight','picked')}
    a=p['historyWeight']
    assert abs(a-.5)>.32
    row['gain']=[x-y for x,y in zip(p['picked']['resolved'][:3],p['picked']['current'][:3])]
    if row['kind']=='crate':
        assert min(row['gain'])>0
    rgb=p['states']['423']['o0']
    row['maxOutputTraceError']=max(abs(x-y) for x,y in zip(rgb,p['picked']['resolved']))
    row['maxCompressedBlendError']=max(abs(x-(a*y+(1-a)*z)) for x,y,z in
        zip(p['mixedCompressed'],p['clippedHistoryCompressed'],p['currentCompressed']))
    assert row['maxCompressedBlendError']<.000002
    reduced.append(row)
conn=sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True)
task,state,code,elapsed=conn.execute('select task,state,exit_code,run_seconds from jobs where id=1464').fetchone()
assert (state,code)==('succeeded',0)
out.mkdir(parents=True,exist_ok=True)
files={'raw/request.json':src/'request.json','raw/results.json':src/'results.json',
    'raw/dispatch-run.log':M/'retest-native-reflection-temporal-weights.log',
    'source/projected-history-sample-temporal-resolve.py':M/'projected-history-sample-temporal-resolve.py',
    'source/archive-reflection-temporal-samples.py':M/'archive-reflection-temporal-samples.py'}
zip_path=out/'validation.zip'
with ZipFile(zip_path,'w',ZIP_DEFLATED,compresslevel=9) as archive:
    for name,f in files.items():
        archive.write(f,name)
with ZipFile(zip_path) as archive:
    fingerprints={name:sha256(archive.read(name)).hexdigest() for name in files}
    assert archive.testzip() is None and fingerprints=={name:digest(f) for name,f in files.items()}
minmax={}
for kind in ('crate','glyph'):
    group=[r['historyWeight'] for r in reduced if r['kind']==kind]
    minmax[kind]=[min(group),max(group)]
result=dict(status=q['status'],strictReflection=False,pairedPlayerCandidate=False,event=req['event'],replayAdapter=q['adapter'],
    resources=req['resources'], shader=req['shader'], verifiedBlendSpace='compressed luminance and chroma',
    blendWeights=minmax,rows=reduced,queue=dict(id=1464,task=task,state=state,exitCode=code,elapsedSeconds=elapsed),
    validation=dict(archive=digest(zip_path),files=fingerprints))
(out/'qualification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print([(k,v) for k,v in minmax.items()],zip_path.stat().st_size)
