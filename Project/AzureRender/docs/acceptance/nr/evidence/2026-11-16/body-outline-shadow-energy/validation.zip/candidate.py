"""Pair the actual Player with a one-term original outline energy candidate."""
from hashlib import file_digest
import json
from pathlib import Path
import runpy
import subprocess
import sys
import numpy as np

run = Path(__file__).resolve().parent
work = run.parents[2]
body = run.parent / '20261114-125923-body-lit-outline-depth-order-a29b63'
grid = run.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
receiver = run.parent / '20261114-135148-face-receiver-diagnostics-7509b1'
out = run / 'body-outline-native-shadow-energy-player'
read = lambda p: json.loads(p.read_bytes())
stages = runpy.run_path(str(run/'outline-shadow-stage-readback.py'), run_name='outline_energy')
reference_reader = runpy.run_path(str(grid/'static-quality.py'))
ownership = receiver / 'body-visible-ownership-points.bin'
score = read(run/'outline-native-energy-qualification.json')
raw = read(body/'body-outline-native-shadow-lut-player/strict-comparison.json')
measure = read(run/'outline-shadow-stage-readback-v2/results.json')
shader = 'mesh_object.frag.spv'

def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()

assert score['originalTintMatched'] and score['bodyReadback'] == sha(run/'outline-shadow-stage-readback-v2/results.json')
assert abs(score['nativeSceneShadowMultiplier'] - .55) < 2e-8 and score['nativePaletteMultiplier'] == .96
assert raw['ownership'] == sha(ownership) and raw['reference'] == sha(reference_reader['reference_path'])
assert score['nativeReference'] == raw['originalTrace']

def prepare():
    scope = '    vec3 shadow=materialFeatureEnabled(4096U)>.5?sampleShadowColorLut(AZ_TEX_SHADOW_COLOR_LUT,base.rgb):base.rgb;'
    commit = measure['shader']['commit']
    original = subprocess.check_output(['git','show',f'{commit}:Project/AzureRender/shaders/mesh.frag'],
                                      cwd=work,encoding='utf8')
    addition = '''
    if(AZURE_MATERIAL_CLASS==1U && AZURE_ALPHA_MODE==2 && (material.materialPadding>>1U)==22U
        && materialFeatureEnabled(524288U)>.5 && materialFeatureEnabled(4096U)>.5
        && profile.rows[3].z>1.5 && profile.rows[3].w>.5) {
        shadow *= (0.96 * 0.55);
    }'''
    assert original.count(scope) == 1
    return original,original.replace(scope,scope+addition)

def summarize(e):
    return dict(overOne=int((e>1).sum()),overEight=int((e>8).sum()),peak=int(e.max()))

def execute():
    lease = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and lease['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9'
    assert Path(lease['output']) == run
    sys.path.insert(0,str(work/'tools'))
    from artifact_budget import check
    receipt = check(work/'build',run=run,planned=18_000_000)
    assert receipt['allowed'],receipt
    out.mkdir(exist_ok=True)
    sources=out/'shaders'
    sources.mkdir(exist_ok=True)
    source=out/'mesh.frag'
    binary=sources/shader
    compile_program=stages['compiler']['compile_program']
    capture = stages['capture']
    capture.__globals__['output']=out
    original,altered=prepare()
    source.write_text(original,encoding='utf8')
    compile_program(source,binary,shader)
    original_hash=sha(binary)
    assert original_hash == measure['shader']['original'][shader]
    source.write_text(altered,encoding='utf8')
    compile_program(source,binary,shader)
    digest=sha(binary)
    assert digest != original_hash
    reference=reference_reader['image'](reference_reader['reference_path']).astype(np.int16)
    x,y,owner=np.fromfile(ownership,'<u2').reshape(-1,3).T
    coverage=np.zeros(reference.shape[:2],bool)
    coverage[y,x]=True
    assert int(coverage.sum())==1184 and int((owner==1018).sum())==1112
    frames={}
    for device in ('nvidia','intel'):
        frame=capture(device,None,label='reference')
        original_frame=stages['source']/f'native-shadow-{device}/frames/frame_000000.png'
        assert sha(original_frame)==raw['devices'][device]['attachment']
        new_image=reference_reader['image'](frame).astype(np.int16)
        assert np.array_equal(new_image,reference_reader['image'](original_frame)),f'{device} stock mismatch'
        frames[device]=dict(reference=sha(frame),color=new_image)
    with stages['catalog']['activate']({shader:digest},alternate_run=run,source_dir=sources):
        for device in frames:
            frame=capture(device,None,label='candidate')
            frames[device]['candidate']=sha(frame)
            frames[device]['candidateColor']=reference_reader['image'](frame).astype(np.int16)
    results={}
    for device,row in frames.items():
        a,b=row.pop('color'),row.pop('candidateColor')
        old,new=(np.abs(p-reference).max(2) for p in (a,b))
        fresh=(old<=1)&(new>1)
        changed=np.any(a!=b,axis=2)
        def subset(mask):
            return dict(reference=summarize(old[mask]),candidate=summarize(new[mask]),
                        newOverOne=int((fresh&mask).sum()),changed=int((changed&mask).sum()))
        regions={}
        for kind,selection in [('contour',owner==1018),('laterDraws',owner!=1018)]:
            mask=np.zeros(coverage.shape,bool)
            mask[y[selection],x[selection]]=True
            regions[kind]=subset(mask)
        regions['outside']=subset(~coverage)
        regions['full']=subset(np.ones_like(coverage))
        passes=(regions['contour']['candidate']['peak']<=1 and not fresh.any()
                and regions['outside']['changed']==0 and regions['laterDraws']['changed']==0)
        results[device]=dict(**row,regions=regions,strictPass=bool(passes))
        print(device,json.dumps(regions),flush=True)
    report=dict(status='passes local gate' if all(row['strictPass'] for row in results.values()) else 'strict gate open',
                source=sha(run/'outline-native-energy-qualification.json'),modifiedProgram=shader,
                stockProgram=original_hash,candidateProgram=digest,player=raw['player'],
                reference=raw['reference'],ownership=raw['ownership'],devices=results)
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')

if sys.argv[1:]==['prepare']:
    a,b=prepare()
    assert a!=b
    print('Native outline energy candidate has one scoped source change.')
elif sys.argv[1:]==['run']:
    execute()
else:
    raise SystemExit('Expected prepare or run')
