"""Build a fixed-step capture entry point that reads a small supplemental fixture."""
import ast
import json
from hashlib import sha256
import os
from pathlib import Path
import runpy
import subprocess
import sys

run=Path(__file__).resolve().parent
work=run.parents[2]
body=run.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
base=body/'msaa-release'
combined=run/'projected-history-layer-release'
out=run/'readonly-face-fixture-source'
exe=combined/'AzurePlayerCaptureFaceFixture.exe'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
environment=('AZR_NR_QA_OVERLAY_ROOT', 'AZR_NR_QA_OVERLAY_SCENE')
anchor='            initial.projectStartup = std::make_shared<const azurerender::ProjectStartup>(\n                azurerender::Project::load(std::filesystem::u8path(projectPath)));'
patch='            auto projectSource=azurerender::Project::load(std::filesystem::u8path(projectPath));\n            if (qaOverlayRoot) {\n                const auto root=std::filesystem::u8path(qaOverlayRoot);\n                const auto scene=std::filesystem::u8path(qaOverlayScene);\n                if (!root.is_absolute() || !std::filesystem::is_directory(root) ||\n                    scene!=scene.filename() || scene.extension()!=".azurelevel" ||\n                    !std::filesystem::is_regular_file(root/"scene"/scene))\n                    throw std::runtime_error("Invalid fixed-step capture fixture");\n                for (const auto& [name, directory] : std::map<std::string,std::string>{\n                    {"qa_stage","scene"},{"qa_materials","materials"},{"qa_character","character"}}) {\n                    const auto folder=root/directory;\n                    if (!std::filesystem::is_directory(folder) || !projectSource.mounts.emplace(name,folder).second)\n                        throw std::runtime_error("Invalid capture fixture mount: "+name);\n                }\n                projectSource.startupScene="qa_stage:/"+scene.generic_u8string();\n                std::cout << "Fixed-step capture fixture: " << root.generic_u8string() << std::endl;\n            }\n            initial.projectStartup = std::make_shared<const azurerender::ProjectStartup>(std::move(projectSource));'
guard='        const char* qaOverlayRoot=std::getenv("AZR_NR_QA_OVERLAY_ROOT");\n        const char* qaOverlayScene=std::getenv("AZR_NR_QA_OVERLAY_SCENE");\n        if (qaOverlayRoot || qaOverlayScene) {\n            const auto has = [&](const char* flag) { return std::find(args.begin(), args.end(), flag) != args.end(); };\n            if (!qaOverlayRoot || !*qaOverlayRoot || !qaOverlayScene || !*qaOverlayScene ||\n                projectPath.empty() || check || !createPath.empty() || has("--scene") ||\n                !has("--capture-dir") || !has("--capture-frames") || !has("--fixed-frame-step"))\n                throw std::runtime_error("Capture fixture requires a fixed-step project capture");\n        }\n'

def checked_source():
    base_path=work/'src/player/main.cpp'
    old=base_path.read_text(encoding='utf8')
    frozen=subprocess.check_output(['git','show','75837a6:Project/AzureRender/src/player/main.cpp'],cwd=work,text=True,encoding='utf8')
    assert frozen==old and old.count(anchor)==1
    assert old.count('        AzureRenderOptions initial;')==1
    revised=old.replace(anchor,patch).replace('        AzureRenderOptions initial;',guard+'        AzureRenderOptions initial;')
    return digest(base_path),revised


def build():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and lease['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9' and Path(lease['output'])==run
    sys.path.insert(0,str(work/'tools'))
    from artifact_budget import check
    b=check(run.parents[1],run=run,planned=10_600_000)
    assert b['allowed'],b
    baseline=read(combined/'link-receipt.json')
    assert digest(combined/'AzurePlayer.exe')==baseline['newPlayer']
    assert all(digest(work/f)==q for f,q in baseline['inputs'].items())
    old,source=checked_source()
    out.mkdir(exist_ok=True)
    native=out/'main.cpp'
    native.write_text(source,encoding='utf8')
    driver=runpy.run_path(str(body/'face-quality-batch.py'),run_name='verified_compiler')
    cmake=Path(driver['cmake'])
    ninja=cmake.parents[2]/'Ninja'/'ninja.exe'
    schema=ast.parse((run/'build-camera-pose-player.py').read_text(encoding='utf8'))
    args_fn,=[p for p in schema.body if isinstance(p,ast.FunctionDef) and p.name=='windows_arguments']
    scope={}
    exec(compile(ast.Module(body=[args_fn],type_ignores=[]),'argument_expansion','exec'),scope)
    rules=subprocess.check_output([str(ninja),'-C',str(base),'-t','commands','AzurePlayer'],text=True).splitlines()
    entry,=[v for v in rules if v.endswith(str(work/'src/player/main.cpp'))]
    cl=scope['windows_arguments'](entry)
    assert Path(cl[0]).name.lower()=='cl.exe'
    obj=out/'main.cpp.obj'
    for flag,name in (('/Fo',obj),('/Fd',out/'main.pdb')):
        at,=[i for i,v in enumerate(cl) if v.startswith(flag)]
        cl[at]=flag+str(name)
    cl[-1]=str(native)
    stock=run/'immutable-scene-capture-source'
    cache_obj=stock/'AssetDatabase.cpp.obj'
    cache_native=stock/'AssetDatabase.cpp'
    cache_receipt=read(stock/'qualification.json')
    assert cache_receipt['readOnlyProjectAssets']
    assert digest(cache_obj)==cache_receipt['assetDatabaseObject']
    assert digest(cache_native)==cache_receipt['assetDatabaseDiagnostic']
    rsp=out/'player.rsp'
    previous=(combined/'player.rsp').read_text(encoding='ascii').splitlines()
    assert str(combined/'main.cpp.obj') in previous[0]
    rsp.write_text('\n'.join([subprocess.list2cmdline([str(obj),str(cache_obj)]),*previous[1:]])+'\n',encoding='ascii')
    linker=baseline['linkCommand'].copy()
    for i,value in enumerate(linker):
        if value.startswith('--intdir='):
            intdir=out/'link-intermediates'
            intdir.mkdir(exist_ok=True)
            linker[i]='--intdir='+str(intdir)
        elif value.startswith('@'):linker[i]='@'+str(rsp)
        elif value.lower().startswith('/out:'):linker[i]='/out:'+str(exe)
        elif value.lower().startswith('/implib:'):linker[i]='/implib:'+str(out/'entry.lib')
        elif value.lower().startswith('/pdb:'):linker[i]='/pdb:'+str(out/'entry.pdb')
    env={k:v for k,v in os.environ.items() if k not in environment}
    for stage,command in (('compile',cl),('link',linker)):
        args=[driver['entry'],*command]
        res=subprocess.run(subprocess.list2cmdline(args),shell=True,cwd=base,env=env,capture_output=True,timeout=145)
        (out/(stage+'.log')).write_bytes(res.stdout+res.stderr)
        assert res.returncode==0,(stage,res.stdout[-4000:],res.stderr[-2000:])
    good=subprocess.run([str(exe),'--help'],env=env,capture_output=True,timeout=20)
    failure=subprocess.run([str(exe),'--help'],env=dict(env,**{environment[0]:'fixture'}),capture_output=True,timeout=20)
    assert good.returncode==0 and 'fixed-step project capture' in failure.stderr.decode('ascii') and failure.returncode!=0
    r=dict(status='linked-readonly-fixture-capture-entry',sourcePlayer=baseline['newPlayer'],trace=baseline['programs'],
           entrySource=old,diagnosticSource=digest(native),candidatePlayer=digest(exe),
           negativeCliExit=failure.returncode,entryObject=digest(obj),readOnlyProjectAssets=True,
           assetDatabaseSource=cache_receipt['assetDatabaseSource'],assetDatabaseDiagnostic=digest(cache_native),
           assetDatabaseObject=digest(cache_obj))
    (out/'qualification.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
    print(json.dumps(r),flush=True)


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:print(checked_source()[0])
    else:build()
