from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

run=Path(__file__).resolve().parent
body=run.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
stages=run/'outline-shadow-stage-readback-v2'
destination=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-16/body-outline-energy-stage'
dig=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
final=read(run/'outline-native-energy-qualification.json')
capture=read(stages/'results.json')
trace=read(body/'trace-body-outline-shadow-lut-source.json')
assert final['bodyReadback']==dig(stages/'results.json')
assert final['nativeReference']==dig(body/'trace-body-outline-shadow-lut-source.json')
assert abs(final['effectiveShadowPaletteMultiplier']-.528)<1e-7
files={k:run/k for k in ('outline-native-energy-qualification.json','outline-shadow-stage-readback.py',
                          'score-outline-native-energy.py',Path(__file__).name)}
files['hardware/stages.json']=stages/'results.json'
files['hardware/mesh.frag']=stages/'mesh.frag'
files['original/trace-receipt.json']=body/'trace-body-outline-shadow-lut-source.json'
files['original/outline-constants.bin']=body/'body-outline-1018-cb1.bin'
files['original/outline-disassembly.asm']=body/'native-outline-1018-fxc.asm'
assert dig(files['original/outline-constants.bin'])==final['shaderConstants']==trace['bindings']['1']['sha256']
for r in trace['points']:
    source=body/r['file']
    assert dig(source)==r['sha256']
    files['original/'+source.name]=source
for kind, samples in final['devices'].items():
    for mode,fingerprint in capture['devices'][kind]['frames'].items():
        p=stages/f'{kind}-{mode}/frames/frame_000000.png'
        assert dig(p)==fingerprint
    for key in ('tint','unscaledPalette','sceneWeightedPalette'):
        assert max(abs(x) for r in samples for x in r['difference'][key])==1
    assert max(abs(x) for r in samples for x in r['difference']['currentUnmatchedScale'])==35
    assert max(abs(x) for r in samples for x in r['difference']['mainPreSaturation'])==45
destination.mkdir(parents=True,exist_ok=True)
target=destination/'validation.zip'
with ZipFile(target,'w') as z:
    for name,p in sorted(files.items()):
        info=ZipInfo(name,(2026,11,16,0,0,0))
        z.writestr(info,p.read_bytes(),compress_type=ZIP_DEFLATED)
members={k:dig(v) for k,v in files.items()}
with ZipFile(target) as z:
    assert z.testzip() is None
    assert {k:sha256(z.read(k)).hexdigest() for k in z.namelist()}==members
final['archive']=dict(sha256=dig(target),members=members)
final['productionCandidateAccepted']=False
(destination/'results.json').write_text(json.dumps(final,indent=2)+'\n',encoding='utf8')
print(dig(target))
