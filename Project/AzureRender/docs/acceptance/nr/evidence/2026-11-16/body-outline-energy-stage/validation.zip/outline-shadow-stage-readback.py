"""Observe outline ownership, albedo, lookup response, and first lighting in Player."""
from contextlib import ExitStack
from hashlib import file_digest
import json
from pathlib import Path
import runpy
import subprocess
import sys

import numpy as np
from PIL import Image


M = Path(__file__).resolve().parent
R = M.parent / '20261114-125923-body-lit-outline-depth-order-a29b63'
G = M.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
source = R / 'body-outline-native-shadow-lut-player'
fixture = G / 'iris-overlay-geometry-project'
output = M / 'outline-shadow-stage-readback-v2'
build = R / 'msaa-release'
catalog = runpy.run_path(str(R / 'face-quality-candidate-catalog.py'))
compiler = runpy.run_path(str(M / 'iris-matcap-differential-player.py'), run_name='outline_stages')
invoke = runpy.run_path(str(G / 'iris-production-frozen-recovery.py'))['invoke']
read = lambda path: json.loads(path.read_bytes())
programs = ('mesh_object.frag.spv',)
reference = read(R / 'trace-body-outline-shadow-lut-source.json')
marker = [0.0625, 0.5, 0.9375]
scope = '''    bool isBodyOutlineReadback = AZURE_MATERIAL_CLASS==1U && AZURE_ALPHA_MODE==2
        && (material.materialPadding>>1U)==22U
        && materialFeatureEnabled(524288U)>.5 && materialFeatureEnabled(4096U)>.5
        && materialSurfaceProfiles.profiles[material.materialPadding>>1U].rows[3].z>1.5
        && materialSurfaceProfiles.profiles[material.materialPadding>>1U].rows[3].w>.5;
    vec3 outlineMainReadback=vec3(-1.0);'''
modes = ('roughness', 'metallic', 'direct-specular', 'reflection')


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')


def checks():
    sys.path.insert(0, str(M.parents[2] / 'tools'))
    from artifact_budget import check
    receipt = check(M.parents[1], run=M, planned=15_000_000)
    assert receipt['allowed'], receipt
    assert sha(build / 'AzurePlayer.exe') == read(source / 'results.json')['player']


def compile_variants():
    shaders = output / 'shaders'
    shaders.mkdir(parents=True, exist_ok=True)
    fingerprint = catalog['retained_catalog'](R)
    path = output / 'mesh.frag'
    workspace = M.parents[2]
    for commit in ('4d9068b', '8dfc5d7', 'e63ef54'):
        baseline = subprocess.check_output(['git', 'show', f'{commit}:Project/AzureRender/shaders/mesh.frag'],
                                           cwd=workspace, encoding='utf8')
        path.write_text(baseline, encoding='utf8')
        for name in programs:
            compiler['compile_program'](path, shaders / name, name)
        if all(sha(shaders / name) == fingerprint[name] for name in programs):
            break
    else:
        raise RuntimeError('Could not reproduce retained outline programs')
    code = baseline
    for anchor, replacement in (
        ('    vec3 sceneMainDiffuse = vec3(0.0);',
         '    vec3 sceneMainDiffuse = vec3(0.0);\n' + scope),
        ('        vec3 combinedAmbient=response.color*illumination.ambient;',
         '''        if(isBodyOutlineReadback)
            outlineMainReadback=response.color*(illumination.ambient+illumination.direct);
        vec3 combinedAmbient=response.color*illumination.ambient;'''),
        ('    outputColor = vec4(qaColor, outputAlpha);',
         '''    if(isBodyOutlineReadback && qaIsolationMode>=17 && qaIsolationMode<=20) {
        if(qaIsolationMode==17) {
            qaColor=vec3(.0625,.5,.9375);
        } else {
            int lane=qaIsolationMode-18;
            vec3 lookup=sampleShadowColorLut(AZ_TEX_SHADOW_COLOR_LUT,baseColor.rgb);
            qaColor=vec3(baseColor[lane],lookup[lane],outlineMainReadback[lane]);
        }
    }
    outputColor = vec4(qaColor, outputAlpha);'''),
    ):
        assert code.count(anchor) == 1, anchor
        code = code.replace(anchor, replacement)
    path.write_text(code, encoding='utf8')
    for name in programs:
        compiler['compile_program'](path, shaders / name, name)
    result = dict(commit=commit, shaderSource=sha(path), original={name:fingerprint[name] for name in programs},
                  program={name:sha(shaders / name) for name in programs})
    assert all(result['program'][name] != fingerprint[name] for name in programs)
    if (output / 'preflight.json').is_file():
        assert read(output / 'preflight.json') == result
    write(output / 'preflight.json', result)
    return result


def capture(device, mode, label=None):
    folder = output / f'{device}-{label if label is not None else mode}'
    folder.mkdir(exist_ok=True)
    original = source / f'native-shadow-{device}'
    selected = read(source / 'results.json')['devices'][device]['native-shadow']
    scene = 'body-native-lit-outline-blend-depth'
    character = 'body-native-lit-outline-production'
    material = original / (scene + '.azurematerial')
    assert sha(material) == selected['material']
    project = read(R / (scene + '.azureproject'))
    assert project['startupScene'].endswith(scene + '.azurelevel')
    pins = {fixture / 'character' / (character + '.gltf'): R / (character + '-ordered.gltf'),
            fixture / 'materials' / material.name: material,
            fixture / 'materials' / (material.name + '.azmeta'): R / (material.name + '.azmeta'),
            fixture / 'scene' / (scene + '.azurelevel'): R / (scene + '.azurelevel'),
            fixture / (scene + '.azureproject'): R / (scene + '.azureproject')}
    for destination in list(pins):
        meta = destination.with_name(destination.name + '.azmeta')
        if not meta.exists() and (R / meta.name).is_file():
            pins[meta] = R / meta.name
    command = read(original / 'command.json')
    assert Path(command[0]) == build / 'AzurePlayer.exe'
    assert '--qa-isolation' not in command
    for option, value in (('--capture-dir', folder / 'frames'), ('--runtime-report', folder / 'runtime.json')):
        command[command.index(option) + 1] = str(value)
    if mode is not None:
        command.extend(('--qa-isolation', mode))
    with ExitStack() as cleanup:
        for destination, path in pins.items():
            assert not destination.exists(), destination
            destination.hardlink_to(path)
            cleanup.callback(destination.unlink)
            if destination.suffix in ('.azurelevel', '.azureproject'):
                meta = destination.with_name(destination.name + '.azmeta')
                if meta not in pins and not meta.exists():
                    cleanup.callback(meta.unlink, missing_ok=True)
        frames = invoke(device, command, folder)
    manifest = read(frames / 'capture_manifest.json')
    if mode is not None:
        assert manifest['qaIsolation'] == mode
    else:
        assert manifest.get('qaIsolation') == baseline_isolation(original)
    assert manifest['width'] == 2560 and manifest['height'] == 1440
    assert manifest['bloomSettings']['enabled'] is False and manifest['gradeSettings']['toneMappingEnabled'] is False
    profile, = [q for q in manifest['materialInventory'] if q['index']==22]
    assert profile['name']=='M_actor_laevat_body_01_lit_outline' and profile['features']==536577
    gpu = read(frames / 'gpu_capabilities.json')
    assert not gpu['resource_access']['enabled']['descriptor_indexing']
    baseline_manifest = read(original / 'frames/capture_manifest.json')
    assert all(manifest[key] == baseline_manifest[key] for key in ('cameraLens', 'cameraUp', 'gradeSettings'))
    return frames / 'frame_000000.png'


def baseline_isolation(folder):
    return read(folder/'frames/capture_manifest.json').get('qaIsolation')


def original_rows():
    result = {}
    for witness in reference['points']:
        path = R / witness['file']
        assert sha(path) == witness['sha256']
        state, sampled = {}, {}
        for pc, values in read(path):
            state.update(values)
            if pc == 23:
                sampled['albedo'] = state['r2'][1:4]
            elif pc == 314:
                sampled['shadowLookup'] = [state['r13'][i] for i in (0, 2, 3)]
            elif pc == 380:
                sampled['mainDiffuse'] = (np.asarray([state['r13'][i] for i in (0, 2, 3)]) *
                                          np.asarray(state['r6'][:3])).tolist()
        assert set(sampled) == {'albedo', 'shadowLookup', 'mainDiffuse'}
        result[tuple(witness['point'])] = sampled
    return result


def srgb(values):
    x = np.clip(np.asarray(values, dtype=float), 0, 1)
    return np.rint(np.where(x <= .0031308, 12.92*x, 1.055*x**(1/2.4)-.055)*255).astype(int)


def run():
    assert reference['status'] == 'qualified'
    checks()
    lease = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state'] == 'held' and Path(lease['output']) == M
    build_receipt = compile_variants()
    originals = original_rows()
    addresses = [*originals, (1199,951), (1181,898)]
    expected_marker = srgb(marker)
    results = {}
    with catalog['activate'](build_receipt['program'], alternate_run=M, source_dir=output/'shaders'):
        for device in ('nvidia','intel'):
            frame_data = {}
            for mode in modes:
                frame = capture(device,mode)
                with Image.open(frame) as image:
                    values = [list(image.getpixel(point)[:3]) for point in addresses]
                frame_data[mode] = dict(image=sha(frame), samples=values)
                print(device, mode, values, flush=True)
                if mode=='roughness':
                    assert sum(np.max(np.abs(expected_marker-row))<=1 for row in values[:4])>=3, (device, values)
            rows = []
            for index, ((x,y), raw_marker) in enumerate(zip(addresses, frame_data['roughness']['samples'])):
                native = originals.get((x,y))
                decoded = np.asarray([frame_data[mode]['samples'][index] for mode in modes[1:]], dtype=int).T
                native_display = srgb(list(native.values())).tolist() if native else None
                rows.append(dict(point=[x,y], marker=raw_marker,
                                 markerMaxError=int(np.abs(expected_marker-raw_marker).max()),
                                 playerLanesAsDisplay=decoded.tolist(), nativeLinear=native,
                                 nativeLanesAsDisplay=native_display,
                                 displayDifferences=(decoded-native_display).tolist() if native else None))
            assert sum(row['markerMaxError'] <= 1 for row in rows[:4]) >= 3, (device, rows)
            results[device] = dict(frames={mode: row['image'] for mode, row in frame_data.items()}, samples=rows)
            write(output/'checkpoint.json', results)
    write(output/'results.json', dict(status='measured-outline-stage-lanes', shader=build_receipt,
                                      player=sha(build/'AzurePlayer.exe'), marker=expected_marker.tolist(),
                                      source=sha(R/'trace-body-outline-shadow-lut-source.json'), devices=results))


if __name__ == '__main__':
    if sys.argv[1:] == ['preflight']:
        checks()
        print(json.dumps(compile_variants()), flush=True)
    elif sys.argv[1:] == ['run']:
        run()
    else:
        raise SystemExit('Expected preflight or run')
