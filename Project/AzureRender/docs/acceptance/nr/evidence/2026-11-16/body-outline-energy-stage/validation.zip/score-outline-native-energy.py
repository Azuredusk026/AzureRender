"""Align the actual Player lanes with the same operations in the native draw."""
from hashlib import sha256
import json
from pathlib import Path
import struct
import numpy as np

run = Path(__file__).resolve().parent
src = run.parent / '20261114-125923-body-lit-outline-depth-order-a29b63'
folder = run / 'outline-shadow-stage-readback-v2'
read = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
capture = read(folder / 'results.json')
reference = read(src / 'trace-body-outline-shadow-lut-source.json')
assert capture['status'] == 'measured-outline-stage-lanes' and reference['status'] == 'qualified'
assert capture['source'] == digest(src / 'trace-body-outline-shadow-lut-source.json')
constants = src / 'body-outline-1018-cb1.bin'
assert digest(constants) == reference['bindings']['1']['sha256']
scene = struct.unpack_from('<f', constants.read_bytes(), 110 * 16 + 8)[0]
luma = np.array([.21267290413379669, .7151522040367126, .07217500358819962])

def to_display(linear):
    v = np.clip(linear, 0, 1)
    return 255 * np.where(v <= .0031308, 12.92 * v, 1.055 * v**(1 / 2.4) - .055)

def to_linear(encoded):
    v = encoded / 255
    return np.where(v <= .04045, v / 12.92, ((v + .055) / 1.055)**2.4)

rows = {}
for item in reference['points']:
    original = src / item['file']
    assert digest(original) == item['sha256']
    state, snap = {}, {}
    for pc, changes in read(original):
        state.update(changes)
        if pc in (35, 275, 277, 278, 280, 281, 314, 380, 418):
            snap[pc] = state.copy()
    rgb = np.array([0, 2, 3])
    tint = np.array(snap[35]['r2'][1:4])
    lerp = snap[278]['r3'][3]
    palette = np.array(snap[275]['r11'][:3]) * (1 - lerp) + np.array(snap[277]['r7'])[rgb] * lerp
    weighted = np.array(snap[314]['r13'])[rgb]
    np.testing.assert_allclose(np.array(snap[280]['r7'])[rgb], palette, atol=2e-7, rtol=0)
    np.testing.assert_allclose(np.array(snap[281]['r7'])[rgb], .96 * palette, atol=2e-7, rtol=0)
    np.testing.assert_allclose(weighted, .96 * scene * palette, atol=2e-7, rtol=0)
    pre_saturation = np.array(snap[380]['r13'])[rgb] * np.array(snap[380]['r6'][:3])
    final = np.array(snap[418]['r6'][:3])
    grey = pre_saturation @ luma
    np.testing.assert_allclose(final, pre_saturation + min(.5, max(0, grey - .5))**2 *
                              (pre_saturation - grey), atol=2e-7, rtol=0)
    rows[tuple(item['point'])] = dict(tint=tint, palette=palette, weighted=weighted, mainPreSaturation=pre_saturation)

reports = {}
for device, group in capture['devices'].items():
    for mode, expected in group['frames'].items():
        assert digest(folder / f'{device}-{mode}/frames/frame_000000.png') == expected
    samples = []
    for entry in group['samples']:
        coord = tuple(entry['point'])
        if coord not in rows:
            continue
        assert entry['markerMaxError'] <= 1
        stages = rows[coord]
        player = np.array(entry['playerLanesAsDisplay'])
        source = {k: np.rint(to_display(v)).astype(int) for k, v in stages.items()}
        rounded_scaled = np.rint(to_display(to_linear(player[1]) * .96 * scene)).astype(int)
        errors = dict(tint=player[0]-source['tint'], unscaledPalette=player[1]-source['palette'],
                      sceneWeightedPalette=rounded_scaled-source['weighted'],
                      currentUnmatchedScale=player[1]-source['weighted'],
                      mainPreSaturation=player[2]-source['mainPreSaturation'])
        samples.append(dict(point=coord, player=player.tolist(), native={k:v.tolist() for k,v in source.items()},
                            modeledScaledPalette=rounded_scaled.tolist(), difference={k:v.tolist() for k,v in errors.items()}))
    assert len(samples) == 4 and max(abs(x) for q in samples for x in q['difference']['tint']) <= 1
    reports[device] = samples
out = dict(status='measured native and Player at corresponding stage boundaries',
           originalTintMatched=True, nativeSceneShadowMultiplier=scene, nativePaletteMultiplier=.96,
           effectiveShadowPaletteMultiplier=.96*scene, devices=reports, bodyReadback=digest(folder/'results.json'),
           shaderConstants=digest(constants), nativeReference=digest(src/'trace-body-outline-shadow-lut-source.json'))
(run/'outline-native-energy-qualification.json').write_text(json.dumps(out, indent=2)+'\n',encoding='utf8')
for device, samples in reports.items():
    print(device,{k:max(abs(e) for s in samples for e in s['difference'][k]) for k in samples[0]['difference']})
