"""Read exact float32 values from the original body normal sampler."""
from hashlib import sha256
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import traceback


environment='AZURE_NR_BODY_RAW_SAMPLE'
run=Path(os.environ[environment]).parent if environment in os.environ else Path(__file__).resolve().parent
folder=run/'body-native-normal-raw-samples'
utility=run.parent/'20261112-053111-intel-reference-visibility-sources-5238e2/native-normal-explicit-mips'
sys.path.insert(0,str(utility))
from dxbc_util import checksum,chunks,dest,fbits,imm,inst,instructions,opcode,rebuild,source,words

read=lambda path:json.loads(path.read_bytes())
write=lambda path,value:path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')


def probe(raw,signal,channel,level):
    assert checksum(raw)==raw[4:20]
    parts=chunks(raw)
    section,=[i for i,(kind,_) in enumerate(parts) if kind in (b'SHEX',b'SHDR')]
    code=words(parts[section][1])
    temp=None
    sample=None
    exit_at=None
    for _,at,op,size in instructions(code):
        if op==opcode('DCL_TEMPS'):
            temp=code[at+1]
            assert temp==3
            code[at+1]+=2
        if sample is None and op==opcode('SAMPLE_B'):
            sample=at,size,code[at:at+size]
        if op==opcode('RET'):
            assert exit_at is None
            exit_at=at
    assert None not in (temp,sample,exit_at)
    at,size,command=sample
    assert command[-6:][0]==1 and command[-2:]==[1,26],command
    code_sample=command
    if level is not None:
        code_sample=command[:-3]+imm(fbits(level))
        code_sample[0]=(code_sample[0]&0x80fff800)|opcode('SAMPLE_L')|(len(code_sample)<<24)
    options={'sample':source(1,channel),'uv':[source(1,channel)[0]|(1<<12),1],
             'constant':imm(0x3fc12345)}
    incoming=options[signal]
    if signal=='sample':
        patched_sample=code_sample+inst('MOV',dest(temp),incoming)
        incoming=source(temp)
    else:
        patched_sample=code_sample

    output=inst('MOV',dest(temp),incoming)
    for index,maximum in enumerate((1023,1023,1023,3)):
        lane=source(temp+1)
        if index:
            output+=inst('USHR',dest(temp+1),source(temp),imm(10*index))
            output+=inst('AND',dest(temp+1),lane,imm(maximum))
        else:
            output+=inst('AND',dest(temp+1),source(temp),imm(maximum))
        output+=inst('UTOF',dest(temp+1),lane)
        output+=inst('MUL',dest(3,1<<index,True),lane,imm(fbits(1/maximum)))
    code[exit_at:exit_at]=output
    code[at:at+size]=patched_sample
    code[1]=len(code)
    parts[section]=(parts[section][0],struct.pack('<{}I'.format(len(code)),*code))
    return rebuild(raw,parts)


def worker():
    import renderdoc as rd
    job=read(folder/'request.json')
    capture=rd.OpenCaptureFile()
    report=dict(status='failed',devices={})
    try:
        assert capture.OpenFile(job['capture'],'',None)==rd.ResultCode.Succeeded
        points_raw=Path(job['points']).read_bytes()
        assert sha256(points_raw).hexdigest()==job['pointsSha256']
        # The retained point file already uses the native attachment row order.
        points=list(struct.iter_unpack('<II',points_raw))
        assert all(0<=x<2560 and 0<=y<1440 for x,y in points)
        offsets=[(y*2560+x)*4 for x,y in points]
        assert len(offsets)==9116
        for label,vendor,device in [('nvidia',rd.GPUVendor.nVidia,0x28e0),('intel',rd.GPUVendor.Intel,0xa788)]:
            options=rd.ReplayOptions()
            options.forceGPUVendor=vendor
            options.forceGPUDeviceID=device
            code,controller=capture.OpenCapture(options,None)
            assert code==rd.ResultCode.Succeeded and controller
            try:
                properties=controller.GetAPIProperties()
                assert properties.pipelineType==rd.GraphicsAPI.D3D11 and properties.vendor==vendor and not properties.degraded
                controller.SetFrameEvent(328,True)
                pipe=controller.GetPipelineState()
                reflection=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
                raw=bytes(reflection.rawBytes)
                assert sha256(raw).hexdigest()==job['pixelShaderSha256']
                original=pipe.GetShader(rd.ShaderStage.Fragment)
                target=pipe.GetOutputTargets()[3].resource
                texture_binding,=[r for r in pipe.GetReadOnlyResources(rd.ShaderStage.Fragment)
                    if reflection.readOnlyResources[r.access.index].fixedBindNumber==1]
                textures={str(t.resourceId):t for t in controller.GetTextures()}
                assert str(target)=='ResourceId::141952'
                assert 'R10G10B10A2' in textures[str(target)].format.Name()
                texture=textures[str(texture_binding.descriptor.resource)]
                assert texture.mips==11 and 'BC5' in texture.format.Name()
                sampler,=[item.sampler for item in pipe.GetSamplers(rd.ShaderStage.Fragment)]
                def take():
                    controller.SetFrameEvent(328,True)
                    image=bytes(controller.GetTextureData(target,rd.Subresource()))
                    assert len(image)==2560*1440*4
                    return image
                def sparse(data):
                    return b''.join(data[offset:offset+4] for offset in offsets)
                baseline=take()
                measured=dict(sparse=sha256(sparse(baseline)).hexdigest(),attachment=sha256(baseline).hexdigest())
                assert measured==job['baseline'][label],(label,measured,job['baseline'][label])
                records={}
                for test,signal,channel,mip in [('copy',None,0,None),('constant','constant',0,None),
                    ('uv-x','uv',0,None),('uv-y','uv',1,None)]+[
                    (f'sample-{kind}-{axis}','sample',component,level)
                    for kind,level in [('implicit',None)]+[(str(level),level) for level in range(11)]
                    for axis,component in [('r',0),('g',1)]]:
                    write(folder/'progress.json',dict(device=label,case=test,completed=list(records)))
                    program=raw if signal is None else probe(raw,signal,channel,mip)
                    shader,error=controller.BuildTargetShader('main',rd.ShaderEncoding.DXBC,program,
                                                               rd.ShaderCompileFlags(),rd.ShaderStage.Fragment)
                    assert shader!=rd.ResourceId.Null(),error
                    controller.ReplaceResource(original,shader)
                    try:
                        frame=take()
                    finally:
                        controller.RemoveReplacement(original)
                        controller.FreeTargetResource(shader)
                    control=signal is None
                    assert (frame==baseline)==control
                    selected=sparse(frame)
                    if test=='constant':
                        assert selected==struct.pack('<I',0x3fc12345)*len(offsets),(
                            selected[:12].hex(),len(selected),sum(value==0x3fc12345 for value, in struct.iter_unpack('<I',selected)))
                    (folder/f'{label}-{test}.bin').write_bytes(selected)
                    records[test]=dict(valuesSha256=sha256(selected).hexdigest(),targetSha256=sha256(frame).hexdigest(),
                                       shaderSha256=sha256(program).hexdigest())
                assert take()==baseline
                report['devices'][label]=dict(cases=records,gpuDeviceID=device,texture=str(texture.resourceId),
                    textureFormat=texture.format.Name(),samplerFilter=[str(sampler.filter.minify),str(sampler.filter.mip)],
                    samplerBias=sampler.mipBias,baselineRestored=True)
            finally:
                controller.Shutdown()
        report['status']='qualified'
    except BaseException:
        report['error']=traceback.format_exc()
    finally:
        capture.Shutdown()
        write(folder/'results.json',report)
    os._exit(0 if report['status']=='qualified' else 1)


def launch():
    from hashlib import file_digest
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==run
    retained=run.parent/'20261113-010018-receiver-body-explicit-mips-747472/body-explicit-mips'
    request=read(retained/'request.json')
    manifest=read(retained/'body-explicit-mips.json')
    assert manifest['status']=='qualified'
    with Path(request['capture']).open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==request['captureSha256']
    request['pointsSha256']=sha256(Path(request['points']).read_bytes()).hexdigest()
    request['baseline']={label:dict(sparse=record['implicitSha256'],attachment=record['attachmentSha256'])
        for label,record in manifest['devices'].items()}
    assert all(sha256((retained/f'{label}-implicit.bin').read_bytes()).hexdigest()==data['sparse']
        for label,data in request['baseline'].items())
    if folder.exists():
        assert not (folder/'results.json').exists() or read(folder/'results.json')['status']!='qualified'
        folder.rename(folder.with_name(folder.name+'-interrupted-'+str(len(list(run.glob(folder.name+'-interrupted-*')))+1)))
    folder.mkdir()
    write(folder/'request.json',request)
    hidden=subprocess.STARTUPINFO()
    hidden.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    hidden.wShowWindow=0
    with (folder/'replay.log').open('wb') as log:
        result=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=folder,env=dict(os.environ,**{environment:str(folder)}),stdout=log,stderr=subprocess.STDOUT,
            startupinfo=hidden,timeout=320)
    report=read(folder/'results.json')
    assert result.returncode==0 and report['status']=='qualified',report.get('error')


if environment in os.environ:
    try:
        worker()
    except BaseException:
        write(folder/'worker-error.json',dict(error=traceback.format_exc()))
        os._exit(1)
elif __name__=='__main__':
    launch()

