"""Separate body normal sampler and shader arithmetic using exact D3D readback."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


run=Path(__file__).resolve().parent
script=run/'body-receiver-normal-explicit-reconstruction.py'
state={'__file__':str(script)}
exec(compile(script.read_text(encoding='utf-8-sig').split('\nmodes={',1)[0],str(script),'exec'),state)
old,coords,xy,eligible,holdout,explicit,pack32=[state[key] for key in
    ('old','coords','xy','eligible','holdout','actual','ordered_pack')]
original=run/'body-native-normal-raw-samples'
manifest=json.loads((original/'results.json').read_bytes())
assert manifest['status']=='qualified'
assert all(raw['baselineRestored'] for raw in manifest['devices'].values())
mips_before=state['state']['levels']['fractional']


def read(tag,case):
    row=manifest['devices'][tag]['cases'][case]
    raw=(original/f'{tag}-{case}.bin').read_bytes()
    assert sha256(raw).hexdigest()==row['valuesSha256']
    return np.frombuffer(raw,'<f4')


def report(actual,predicted):
    delta=np.abs(actual-predicted).max(axis=1)
    return dict(exact=int(((actual==predicted).all(axis=1)&eligible).sum()),
        withinOne=int(((delta<=1)&eligible).sum()),worst=float(delta[eligible].max()),
        heldOutExact=int(((actual==predicted).all(axis=1)&eligible&holdout).sum()),
        heldOutWithinOne=int(((delta<=1)&eligible&holdout).sum()))


same={} 
proof=dict(status='measured-native-normal-input-differences',scope=len(xy),qualified=int(eligible.sum()),
     heldOut=int((eligible&holdout).sum()),sourceSha256=sha256((original/'results.json').read_bytes()).hexdigest(),devices={})
sample=state['sample']
for tag in manifest['devices']:
    control=read(tag,'constant').view('<u4')
    assert np.all(control==0x3fc12345)
    uv=np.column_stack((read(tag,'uv-x'),read(tag,'uv-y')))
    assert np.isfinite(uv).all()
    same[tag]={'uv':uv}
    expected=explicit[tag]
    raw_implicit=np.column_stack([read(tag,f'sample-implicit-{axis}') for axis in ('r','g')])
    same[tag]['implicit']=raw_implicit
    packed_implicit=state['packed'](read(tag,'copy').view('<u4'))
    proof['devices'][tag]=device=dict(
        uvAbsoluteMaximum=float(np.abs(uv-coords)[eligible].max()),
        uvAbsoluteMedian=float(np.median(np.abs(uv-coords)[eligible])),
        uvRoundedEqual=int((np.all(uv==coords.astype('f4'),axis=1)&eligible).sum()),
        packingFromExactImplicit=report(packed_implicit,pack32(raw_implicit.astype(float)*255)),
        mips={},
    )
    for level,texture in enumerate(mips_before):
        exact=np.column_stack((read(tag,f'sample-{level}-r'),read(tag,f'sample-{level}-g')))
        assert np.isfinite(exact).all() and np.all((exact>=0)&(exact<=1))
        same[tag][level]=exact
        meter={}
        for label,coordinates in [('rasterUv',coords),('hardwareUv',uv)]:
            state['coords']=coordinates
            estimate=sample(texture,256,np.rint,'float32')/255
            err=np.abs(exact-estimate)
            meter[label]=dict(max=float(err[eligible].max()),
                median=float(np.median(err[eligible])),
                medianBias=np.median((exact-estimate)[eligible],axis=0).tolist(),
                heldOutExact=int((np.all(exact==estimate.astype('f4'),axis=1)&eligible&holdout).sum()),
                heldOutWithinUnorm16=int(((err.max(axis=1)<=1/65535)&eligible&holdout).sum()))
        base=pack32(exact.astype(float)*255)
        device['mips'][level]=dict(rawComparison=meter,packingFromExactSamples=report(expected[level],base))
    print(tag,device['packingFromExactImplicit'],device['uvAbsoluteMaximum'],flush=True)


for name in ('uv','implicit',*range(11)):
    r0,r1=[same[tag][name] for tag in ('nvidia','intel')]
    delta=np.abs(r0-r1).max(axis=1)
    proof.setdefault('nativeDeviceDifference',{})[name]=dict(exact=int(((delta==0)&eligible).sum()),
                                                           peak=float(delta[eligible].max()),
                                                           overOneUnorm16=int(((delta>1/65535)&eligible).sum()))
print(proof['nativeDeviceDifference'],flush=True)
(run/'body-native-normal-raw-samples-analysis.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')

