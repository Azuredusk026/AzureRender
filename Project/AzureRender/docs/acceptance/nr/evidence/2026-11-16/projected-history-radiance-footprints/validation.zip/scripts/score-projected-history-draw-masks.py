"""Associate same-address radiance failures with independently retained original draw masks."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import runpy
import subprocess
import sys

import numpy as np
from PIL import Image

root = Path(__file__).resolve().parent
rgb = runpy.run_path(str(root / 'score-projected-history-chroma.py'))
local = runpy.run_path(str(root / 'score-projected-history-local-radiance.py'))
s, b = rgb['s'], rgb['b']
main = Path('D:/Projects/FYP/Project/AzureRender')
museum = root.parents[2]
docs = 'Project/AzureRender/docs/acceptance/nr/evidence/2026-10-28/'
read = lambda data: json.loads(data)
hash_bytes = lambda raw: sha256(raw).hexdigest()
catalog = {
    'central-glyph-composition': (10480, 9160, 10875),
    'captured-logistics-boxes': (6587, 6600, 6613, 6626, 6652),
    'opaque-logistics-rings': (5066, 5078),
}
groups = dict(centralGlyph=(10480,), logisticsBoxes=catalog['captured-logistics-boxes'],
              opaqueCyanRing=catalog['opaque-logistics-rings'], forwardFog=(9160,10875))


def retained_masks():
    masks, provenance = {}, {}
    for label, events in catalog.items():
        path = docs + label + '.json'
        tracked = subprocess.run(['git', 'show', 'HEAD:' + path], cwd=museum, check=True, stdout=subprocess.PIPE).stdout
        manifest = read(tracked)
        archive = main / manifest['run']
        artifacts = {a['path']: a['sha256'] for a in manifest['artifacts']}
        if label == 'opaque-logistics-rings':
            desc = (archive / 'opaque-ring-inputs.json').read_bytes()
            assert artifacts['opaque-ring-inputs.json'] == hash_bytes(desc)
            desc = {x['event']:x for x in read(desc)['draws']}
        for event in events:
            name = ('actual-' if label == 'captured-logistics-boxes' else '') + f'event-{event}/contribution.pgm'
            payload = (archive / name).read_bytes()
            sha = hash_bytes(payload)
            data = np.asarray(Image.open(BytesIO(payload)))
            assert data.shape == (1440, 2560) and not np.any((data != 0) & (data != 255))
            count = int(np.count_nonzero(data))
            expected = artifacts.get(name)
            if label == 'opaque-logistics-rings':
                assert count == desc[event]['contributingPixels']
            else:
                assert expected == sha, (event, sha)
            masks[event] = data[::-1] != 0
            provenance[str(event)] = dict(manifest=path, manifestSha256=hash_bytes(tracked), file=str(archive/name),
                sha256=sha, storedFlipY=True, count=count,
                check='draw-count from qualified original attachment readback' if expected is None else 'tracked exact digest')
    return masks, provenance


def summary(m, delta, weight):
    vals, w = delta[m], weight[m]
    if not len(vals): return dict(count=0, negativeEnergy=0.)
    return dict(count=len(vals), medianSignedLuma=float(np.median(vals)),
                negative=int((vals<0).sum()), severeNegative=int((vals<-.10).sum()),
                negativeEnergy=float(np.maximum(-vals,0)@w))


def score():
    masks, refs = retained_masks()
    depths, ids, coord, canonical, conf, trace, colors, receipts = rgb['load']()
    result = dict(status='qualified-same-address-draw-mask-intersection', previousDepth=ids,
        playerPriorColorSha256=receipts['fullSha256'], masks=refs, routes={},
        interpretation='Current native frame draw contribution footprint only; this does not independently establish the exact previous-frame contribution or visibility order. Source samples compare previous HDR point values at matching pick locations and prior-depth world positions.')
    for route in rgb['tags']:
        nc = canonical[route].copy()
        nc[...,1] = 65535-nc[...,1]
        pc = canonical[route]
        wn,nv,_=s['world_from_history'](nc, depths['native'], s['N'], True)
        wp,pv,_=s['world_from_history'](pc, depths['player'], s['V'], False)
        a,c = (colors[t][route] for t in rgb['tags'])
        kh = np.minimum(conf['native'], conf['player'])
        overlap = nv & pv & (np.linalg.norm(wn-wp,axis=-1)<=.02) & (kh>0)
        overlap &= s['coherently_sampled'](s['compressed_rgb'](colors[route][route]),trace[route])
        for w,h in ((1280,720),(2560,1440)):
            overlap &= s['stable_indices'](coord[route][...,0],w)&s['stable_indices'](coord[route][...,1],h)
        delta = (s['compressed_rgb'](c) - s['compressed_rgb'](a)) @ s['weight']
        px = local['inverse_indices'](pc)
        active = {k:v[px[...,1],px[...,0]] for k,v in masks.items()}
        coverage = {key:np.logical_or.reduce([active[x] for x in g]) for key,g in groups.items()}
        lookup = {**coverage, **{str(k):v for k,v in active.items()}}
        count = np.stack(list(coverage.values())).sum(axis=0)
        routed = result['routes'][route] = {}
        for name,region in b['REGIONS'].items():
            cut = lambda x: b['cut'](x,b['local'](region))
            a = cut(overlap)
            d = cut(delta)
            wgt = cut(kh)
            values = {k:summary(a&cut(x),d,wgt) for k,x in lookup.items()}
            total = summary(a,d,wgt)
            assert total['negativeEnergy'] > 0
            values['knownUnion'] = summary(a&cut(count>0),d,wgt)
            values['knownOverlap'] = summary(a&cut(count>1),d,wgt)
            values['outsideKnown'] = summary(a&cut(count==0),d,wgt)
            assert values['knownUnion']['count']+values['outsideKnown']['count']==len(wgt[a])
            assert abs(values['knownUnion']['negativeEnergy']+values['outsideKnown']['negativeEnergy']-total['negativeEnergy'])<1e-10
            for info in values.values():
                info['negativeEnergyShare']=info['negativeEnergy']/total['negativeEnergy']
            routed[name]=dict(total=total, byMask=values)
            print(route,name,total,[(k,v.get('medianSignedLuma'),v['count'],round(v['negativeEnergyShare'],3))
                for k,v in values.items() if k in groups or k in ('knownUnion','knownOverlap','outsideKnown')])
    picks=read((s['floor']/'history-source-producer-witnesses.json').read_bytes())
    result['witnesses']={}
    for route, regions in picks['groups'].items():
        result['witnesses'][route]={}
        for region, families in regions.items():
            result['witnesses'][route][region]={kind:[dict(pixel=r['previousPixelXY'],events=[
                k for k,x in masks.items() if x[r['previousPixelXY'][1],r['previousPixelXY'][0]]])
                for r in records] for kind,records in families.items()}
    landmark=result['witnesses']['native']['centerFloor']
    assert all(10480 in x['events'] for x in landmark['neutralDarker'])
    assert sum(bool(set(groups['logisticsBoxes'])&set(x['events'])) for x in landmark['warmDarker'])==7
    assert all(5066 in x['events'] for x in landmark['cyanClose'])
    (s['floor']/'history-source-draw-mask-intersection.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    assert sys.argv[1:]==['score']
    score()
