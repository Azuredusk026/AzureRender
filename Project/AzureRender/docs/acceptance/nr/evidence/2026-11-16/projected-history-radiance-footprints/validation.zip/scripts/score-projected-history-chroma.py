"""Separate fixed-address prior radiance from actual trace endpoint drift."""
from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys

import numpy as np

root=Path(__file__).resolve().parent
s=runpy.run_path(str(root/'score-projected-history-coordinates.py'))
f,b,read=s['source'],s['base'],s['read']
box=b['CROP'];height=box[3]-box[1];width=box[2]-box[0]
tags=('native','player')


def load():
    d,ids,manifest,rows=s['original_history_depths']()
    entry,=[q for q in rows if q['role']=='previousColor']
    raw=(manifest.parent/entry['file']).read_bytes()
    assert len(raw)==entry['bytes'] and sha256(raw).hexdigest()==entry['sha256']
    path=s['floor']
    record=read(path/'results.json')
    receipt=read(path/'player/history-source-reduced.json')
    assert receipt['originalRestored'] and set(receipt['routes'])==set(tags)
    coords={}; conf={}; rgb={}; canonical={}
    output={t:{} for t in tags}
    old=f['reader']['at_history_uv']
    for route in tags:
        a=record[route]
        assert a['status']=='qualified' and a['baselineRestored']
        hdr,uv,c=a['outputs']['coordinates']
        assert receipt['routes'][route]['coordinateSha256']==uv
        coords[route]=s['check_snapshot'](path/route/'history-uv.bin',uv,'<u2',(height,width,2))
        conf[route]=s['check_snapshot'](path/route/'trace-confidence.bin',c,'u1',(height,width))/255
        rgb[route]=s['decode'](s['check_snapshot'](path/route/'trace-color.bin',hdr,'<u4',(height,width)))
        canonical[route]=coords[route].copy()
        if route=='native':canonical[route][...,1]=65535-canonical[route][...,1]
        colors=old(raw,2560,1440,True,route=='native',coords[route].tobytes())
        output['native'][route]=np.frombuffer(colors,'<f2').reshape((height,width,4))[...,:3].astype(np.float64)
        rec=receipt['routes'][route]['sha256']
        path1=path/'player'/f'prior-color-at-{route}.bin'
        output['player'][route]=s['check_snapshot'](path1,rec,'<f2',(height,width,4))[...,:3].astype(np.float64)
    return d,ids,coords,canonical,conf,rgb,output,receipt


def score():
    depth,ids,coords,canonical,conf,rgb,color,receipt=load()
    byRoute={}
    for route in tags:
        ncoords=canonical[route].copy();ncoords[...,1]=65535-ncoords[...,1]
        wn,nv,_=s['world_from_history'](ncoords,depth['native'],s['N'],True)
        wp,pv,_=s['world_from_history'](canonical[route],depth['player'],s['V'],False)
        both=nv&pv
        for k,(w,h) in enumerate(((1280,720),(2560,1440))):
            both &= s['stable_indices'](coords[route][...,0],w)&s['stable_indices'](coords[route][...,1],h)
        here=np.linalg.norm(wn-wp,axis=-1)
        a,p=[color[t][route] for t in tags]
        rawL=[v@s['weight'] for v in (a,p)]
        compL=[s['compressed_rgb'](v)@s['weight'] for v in (a,p)]
        visible=(conf['native']>0)&(conf['player']>0)
        both &= visible&s['coherently_sampled'](s['compressed_rgb'](color[route][route]),rgb[route])
        # Classes here use prior source chroma; a source mesh/material identity is not inferred.
        chroma=a.max(axis=-1)-a.min(axis=-1)
        colorBands=dict(neutral=chroma<=.15*np.maximum(a.max(axis=-1),.04),
                        cyan=(np.minimum(a[...,1],a[...,2])>1.25*a[...,0])&(chroma>.02),
                        warm=(a[...,0]>1.25*a[...,2])&(chroma>.02))
        out={}
        for name,region in b['REGIONS'].items():
            cut=lambda a:b['cut'](a,b['local'](region))
            same=cut(both&(here<=.02))
            nl,pl=(cut(v) for v in rawL)
            n,p=(cut(v) for v in compL)
            stats={}
            for kind,select in {'all':np.ones_like(both,dtype=bool),**colorBands}.items():
                m=same&cut(select)
                if not m.any(): continue
                pq=lambda x:np.percentile(x[m],[10,50,90]).tolist()
                stats[kind]=dict(samples=int(m.sum()),nativeHdrLuma=pq(nl),playerHdrLuma=pq(pl),
                    playerMinusNativeCompressedLuma=pq(p-n),playerBelowNative=int((m&(p<n)).sum()),
                    playerLumaZeroButNativeNot=int((m&(p==0)&(n>0)).sum()))
            out[name]=stats
        byRoute[route]=out
    result=dict(status='fixed-address-history-radiance-diag',previousDepth=ids,playerHistory=receipt['fullSha256'],
        scope='Same actual sample address within each route; native and Player history depths resolve to a world point within two centimeters.',
        bySampleRoute=byRoute)
    (s['floor']/'history-source-fixed-address-chroma.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    for route,o in byRoute.items():
        for name in ('centerFloor','cyanRing'):
            print(route,name,json.dumps(o[name]))


if __name__=='__main__':
    assert sys.argv[1:]==['score'];score()
