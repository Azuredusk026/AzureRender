"""Test whether small shifts of the original native source explain Player prior radiance."""
from hashlib import sha256
import itertools
import json
from pathlib import Path
import runpy
import sys

import numpy as np

root = Path(__file__).resolve().parent
study = runpy.run_path(str(root / 'score-projected-history-chroma.py'))
s, b = study['s'], study['b']
radii = (0, 1, 2, 4, 8)
weight = s['weight']


def stats(values):
    return np.percentile(values, (10, 50, 90)).tolist()


def inverse_indices(uv):
    return np.minimum(np.floor(uv.astype(np.float64) * (2560, 1440) / 65535).astype(np.intp), (2559, 1439))


def neighborhood(native, labels, player):
    xx, yy = labels.T
    out = {}
    best_rgb = np.full(len(xx), np.inf)
    best_luma = np.full(len(xx), np.inf)
    actual = native[yy, xx]
    err_rgb = np.max(np.abs(actual - player), axis=-1)
    player_l = player @ weight
    err_luma = np.abs(actual @ weight - player_l)
    model = {}
    for radius in radii:
        for dx, dy in itertools.product(range(-radius, radius + 1), repeat=2):
            if max(abs(dx), abs(dy)) != radius:
                continue
            moved = native[np.clip(yy + dy, 0, native.shape[0] - 1), np.clip(xx + dx, 0, native.shape[1] - 1)]
            other_rgb = np.max(np.abs(moved - player), axis=-1)
            other_luma = np.abs(moved @ weight - player_l)
            best_rgb = np.minimum(best_rgb, other_rgb)
            best_luma = np.minimum(best_luma, other_luma)
            if radius <= 2:
                model[(dx, dy)] = other_rgb
        out[str(radius)] = dict(oracleBestAbsoluteRgb=stats(best_rgb), oracleBestAbsoluteLuma=stats(best_luma),
                                unresolvedOverPoint02=int((best_rgb > .02).sum()),
                                unresolvedLumaOverPoint02=int((best_luma > .02).sum()))
    # Fit only one scene-wide subpixel proxy. Selection and verification use different 32px tiles.
    fits = []
    for bit in (0, 1):
        train = (((xx // 32) + (yy // 32)) % 2) == bit
        if train.sum() >= 10 and (~train).sum() >= 10:
            choice = min(model, key=lambda off: (np.mean(model[off][train]), abs(off[0])+abs(off[1]), off))
            fits.append(dict(trainFold=bit, nativeOffset=choice, trainCount=int(train.sum()), testCount=int((~train).sum()),
                             testBaselineMeanAbsoluteRgb=float(err_rgb[~train].mean()),
                             testShiftedMeanAbsoluteRgb=float(model[choice][~train].mean())))
    return dict(count=len(xx), disjointTileFixedShift=fits, absoluteErrorByLocalRadius=out)


def self_test():
    y, x = np.mgrid[:96, :96]
    a = (y * 97 + x) / 9312.
    frame = np.stack((a, a, a), axis=-1)
    coords = np.array([(i, j) for i in range(10, 87, 3) for j in range(10, 87, 3)])
    xx, yy = coords.T
    result = neighborhood(frame, coords, frame[yy + 1, xx - 1])
    assert all(x['nativeOffset'] == (-1, 1) and x['testShiftedMeanAbsoluteRgb'] == 0 for x in result['disjointTileFixedShift'])
    assert result['absoluteErrorByLocalRadius']['0']['oracleBestAbsoluteRgb'][1] > 0
    assert result['absoluteErrorByLocalRadius']['1']['oracleBestAbsoluteRgb'][2] == 0
    source = np.zeros((64, 64, 3), dtype=np.float64)
    result = neighborhood(source, np.array([(i, i) for i in range(10, 45)]), np.ones((35, 3)))
    assert result['absoluteErrorByLocalRadius']['8']['unresolvedOverPoint02'] == 35


def score():
    depth, ids, coords, canonical, conf, rgb, color, receipt = study['load']()
    _, _, path, rows = s['original_history_depths']()
    entry, = [r for r in rows if r['role'] == 'previousColor']
    raw = (path.parent / entry['file']).read_bytes()
    assert sha256(raw).hexdigest() == entry['sha256']
    nimg = s['compressed_rgb'](np.frombuffer(raw[:entry['levels'][0]['bytes']], '<f2').reshape(1440, 2560, 4)[::-1, :, :3])
    result = dict(status='qualified-local-source-color-control', nativeHistory=entry['sha256'],
                  playerHistory=receipt['fullSha256'], scopes={},
                  format='Native point samples at exact dequantized display addresses; distances in native source pixels. Oracle chooses best independent neighbor per address. The shared integer offset is cross-validated over disjoint 32-pixel tiles.')
    for route in study['tags']:
        ncoords = canonical[route].copy()
        ncoords[..., 1] = 65535 - ncoords[..., 1]
        pcoords = canonical[route]
        wn, nv, _ = s['world_from_history'](ncoords, depth['native'], s['N'], True)
        wp, pv, _ = s['world_from_history'](pcoords, depth['player'], s['V'], False)
        n, p = color['native'][route], color['player'][route]
        ncomp, pcomp = (s['compressed_rgb'](v) for v in (n, p))
        delta = (pcomp - ncomp) @ weight
        m = nv & pv & (np.linalg.norm(wn - wp, axis=-1) <= .02) & (conf['native'] > 0) & (conf['player'] > 0)
        m &= s['coherently_sampled'](s['compressed_rgb'](color[route][route]), rgb[route])
        for w,h in ((1280,720),(2560,1440)):
            m &= s['stable_indices'](coords[route][...,0],w) & s['stable_indices'](coords[route][...,1],h)
        pixels = inverse_indices(pcoords)
        assert np.all(nimg[pixels[..., 1][m], pixels[..., 0][m]] == ncomp[m]), route
        chroma = n.max(axis=-1) - n.min(axis=-1)
        classes = dict(all=np.ones_like(m), severeNeutral=(delta < -.10) & (chroma <= .15 * np.maximum(n.max(axis=-1), .04)),
                       severeWarm=(delta < -.10) & (n[...,0] > 1.25 * n[...,2]) & (chroma > .02),
                       cyan=(np.minimum(n[...,1], n[...,2]) > 1.25 * n[...,0]) & (chroma > .02))
        group = result['scopes'][route] = {}
        for name, region in b['REGIONS'].items():
            cut = lambda a: b['cut'](a, b['local'](region))
            by_class = group[name] = {}
            for kind, band in classes.items():
                mask = cut(m & band)
                if not mask.any():
                    continue
                by_class[kind] = neighborhood(nimg, cut(pixels)[mask], cut(pcomp)[mask])
                x = by_class[kind]['absoluteErrorByLocalRadius']
                print(route, name, kind, int(mask.sum()), 'p50-rgb', [round(x[str(rad)]['oracleBestAbsoluteRgb'][1], 5) for rad in radii],
                      'remaining >.02', [x[str(rad)]['unresolvedOverPoint02'] for rad in radii])
    (s['floor'] / 'history-source-local-radiance.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    self_test()
    assert sys.argv[1:] == ['score']
    score()
