"""Plot retained numeric radiance samples in their source image coordinates."""
from hashlib import sha256
import json
from pathlib import Path
import runpy

from PIL import Image, ImageDraw, ImageFont
import numpy as np

root=Path(__file__).resolve().parent
s=runpy.run_path(str(root/'score-projected-history-coordinates.py'))
_,_,manifest,rows=s['original_history_depths']()
entry,=[r for r in rows if r['role']=='previousColor']
p=(manifest.parent/entry['file']).read_bytes()
assert sha256(p).hexdigest()==entry['sha256']
tex=np.frombuffer(p[:entry['levels'][0]['bytes']],'<f2').reshape(1440,2560,4)[::-1]
receipt=json.loads((s['floor']/'history-source-producer-witnesses.json').read_bytes())
proof=receipt['groups']['native']['centerFloor']
x,y,u,v=1000,520,1580,800
num=lambda a:np.clip(np.rint(np.where(a<.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055)*255),0,255).astype('u1')
color=lambda a:num(s['compressed_rgb'](a))
reference=s['base']['ROOT']/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame3534-replayed.png'
src=Image.open(reference).convert('RGB').crop((x,y,u,v))
native=Image.fromarray(color(tex[y:v,x:u]))
out=Image.new('RGB',(u-x+20,2*(v-y)+90),(20,20,20))
D=ImageDraw.Draw(out)
fonts='C:/Windows/Fonts/msyh.ttc'
font=ImageFont.truetype(fonts,17)
small=ImageFont.truetype(fonts,11)
names={'neutralDarker':'中性偏暗','warmDarker':'暖色偏暗','cyanClose':'青色接近'}
palette={'neutralDarker':'#ffe66d','warmDarker':'#ff7b82','cyanClose':'#5ee4ed'}
for iy,(title,layer) in enumerate((('原生上一帧颜色附件（线性读回）',native),('原生当前帧显示（位置参照）',src))):
    h=10+iy*(v-y+35)
    D.text((10,h),title,font=font,fill='white')
    out.paste(layer,(10,h+27))
    for kind in proof:
        for k,r in enumerate(proof[kind],1):
            px,py=r['previousPixelXY']
            a,b=10+px-x,h+27+py-y
            D.ellipse((a-3,b-3,a+3,b+3),outline=palette[kind],width=1)
            D.text((a+4,b-8),str(k),font=small,fill=palette[kind],stroke_width=1,stroke_fill='black')
    for i,(kind,label) in enumerate(names.items()):
        D.text((180+100*i,h),label,font=small,fill=palette[kind])
out.save(s['floor']/'history-source-witness-positions.png',optimize=True)
