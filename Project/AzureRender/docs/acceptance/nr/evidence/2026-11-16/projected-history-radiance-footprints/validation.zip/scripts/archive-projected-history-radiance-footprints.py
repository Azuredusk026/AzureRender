"""Archive same-address source radiance and original draw coverage."""
from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile, ZIP_DEFLATED, ZipInfo

root=Path(__file__).resolve().parent
source=root/'projected-history-coordinates'
dest=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-16/projected-history-radiance-footprints'
read=lambda path:json.loads(path.read_bytes())
digest=lambda raw:sha256(raw).hexdigest()

files=('score-projected-history-chroma.py','score-projected-history-local-radiance.py',
       'score-projected-history-draw-masks.py','plan-projected-history-producer-witnesses.py',
       'plot-projected-history-source-witnesses.py','archive-projected-history-radiance-footprints.py')
items=('history-source-fixed-address-chroma.json','history-source-local-radiance.json',
       'history-source-draw-mask-intersection.json','history-source-producer-witnesses.json',
       'history-source-witness-positions.png')


def build():
    values=read(source/'history-source-draw-mask-intersection.json')
    local=read(source/'history-source-local-radiance.json')
    chroma=read(source/'history-source-fixed-address-chroma.json')
    assert (values['status'],local['status'],chroma['status'])==('qualified-same-address-draw-mask-intersection',
        'qualified-local-source-color-control','fixed-address-history-radiance-diag')
    assert values['playerPriorColorSha256']==local['playerHistory']==chroma['playerHistory']
    docs={}
    payloads={f'scripts/{n}':(root/n).read_bytes() for n in files}
    payloads.update({f'readback/{n}':(source/n).read_bytes() for n in items})
    for k,v in values['masks'].items():
        raw=Path(v['file']).read_bytes()
        assert digest(raw)==v['sha256']
        payloads[f'original-draw-footprints/{k}.pgm']=raw
    for route in ('native','player'):
        docs[route]={}
        for roi in ('centerFloor','cyanRing'):
            row=values['routes'][route][roi]
            local_row=local['scopes'][route][roi]
            ch=chroma['bySampleRoute'][route][roi]
            assert row['total']['count']==local_row['all']['count']==ch['all']['samples']
            assert 0.85<row['byMask']['knownUnion']['negativeEnergyShare']<0.95
            q=local_row['severeNeutral']['absoluteErrorByLocalRadius']
            docs[route][roi]=dict(samples=row['total']['count'], weight='Minimum of the native and Player trace confidence',
                 negativeCompressedLuma=row['total']['negativeEnergy'],
                 drawFootprintShare={k:row['byMask'][k]['negativeEnergyShare']
                    for k in ('centralGlyph','logisticsBoxes','opaqueCyanRing','knownUnion','knownOverlap')},
                 centralGlyphMedianSignedCompressedLuma=row['byMask']['centralGlyph']['medianSignedLuma'],
                 cyanRingMedianSignedCompressedLuma=row['byMask']['opaqueCyanRing']['medianSignedLuma'],
                 severeNeutralMaxAbsRgbMedian=[q[str(r)]['oracleBestAbsoluteRgb'][1] for r in (0,1,2)],
                 allSampleFixedShiftCrossValidation=local_row['all']['disjointTileFixedShift'])
    result=dict(status='source-radiance-localized-formal-gates-open', scope='Prior HDR at paired screen addresses whose prior depth positions agree within 2 cm.',
        sourceComparison=values['interpretation'],
        baseline='projected-history-bilateral-endpoints/results.json',
        candidateDecision='Inspect whether the captured color producer includes the central glyph composition before choosing a scene history source. The footprint intersection alone does not establish the cause of the prior-frame deficit.',
        previousDepth=values['previousDepth'],nativePriorColorSha256=local['nativeHistory'],
        playerPriorColorSha256=local['playerHistory'], paired=docs,
        originalDrawFootprints={k:{j:w for j,w in v.items() if j!='file'} for k,v in values['masks'].items()},
        selectedWitnesses=values['witnesses']['native']['centerFloor'],
        entries={n:digest(v) for n,v in sorted(payloads.items())})
    return result,payloads


def verify(result,payloads):
    old=read(dest/'results.json')
    assert old.pop('archiveSha256')==digest((dest/'validation.zip').read_bytes())
    assert old==result
    with ZipFile(dest/'validation.zip') as z:
        assert z.testzip() is None and set(z.namelist())==set(payloads)
        for n,raw in payloads.items():
            assert z.read(n)==raw and digest(raw)==result['entries'][n]
    print('Verified',len(payloads),'archive entries and all four scoring scopes')


if __name__=='__main__':
    result,payloads=build()
    if sys.argv[1:]==['write']:
        dest.mkdir(parents=True,exist_ok=True)
        with ZipFile(dest/'validation.zip','w',compression=ZIP_DEFLATED,compresslevel=9) as z:
            for n,raw in sorted(payloads.items()):
                z.writestr(ZipInfo(n,date_time=(2026,11,16,0,0,0)),raw,ZIP_DEFLATED,9)
        (dest/'results.json').write_text(json.dumps(dict(result,archiveSha256=digest((dest/'validation.zip').read_bytes())),
             indent=2)+'\n',encoding='utf-8')
    else:
        assert sys.argv[1:]==['verify']
    verify(result,payloads)
