"""Choose paired source texels to trace the two prior color producers."""
from hashlib import sha256
import json
from pathlib import Path
import runpy

import numpy as np

root=Path(__file__).resolve().parent
chroma=runpy.run_path(str(root/'score-projected-history-chroma.py'))
s,b,read=chroma['s'],chroma['b'],chroma['read']
depth,depth_ids,coords,canonical,conf,rgb,color,receipt=chroma['load']()
roi=b['CROP']
sizes=np.array([2560,1440])
stable_limit=6  # Display pixels between witness texels; a locally repeated address counts once.
groups={}
for route in ('native','player'):
    n=canonical[route].copy();n[...,1]=65535-n[...,1]
    wn,nvalid,_=s['world_from_history'](n,depth['native'],s['N'],True)
    wp,pvalid,uv=s['world_from_history'](canonical[route],depth['player'],s['V'],False)
    same=np.linalg.norm(wn-wp,axis=-1)<=.02
    valid=nvalid&pvalid&same&(conf['native']>0)&(conf['player']>0)
    for w,h in ((1280,720),(2560,1440)):
        valid &= s['stable_indices'](coords[route][...,0],w)&s['stable_indices'](coords[route][...,1],h)
    valid &= s['coherently_sampled'](s['compressed_rgb'](color[route][route]),rgb[route])
    a,p=[color[x][route] for x in ('native','player')]
    luma_diff=(s['compressed_rgb'](p)-s['compressed_rgb'](a))@s['weight']
    addressed=(uv*sizes).astype(np.int64)
    chroma_value=a.max(axis=-1)-a.min(axis=-1)
    neutral=chroma_value<=.15*np.maximum(a.max(axis=-1),.04)
    cyan=(np.minimum(a[...,1],a[...,2])>1.25*a[...,0])&(chroma_value>.02)
    warm=(a[...,0]>1.25*a[...,2])&(chroma_value>.02)
    groups[route]={}
    for region,box in b['REGIONS'].items():
        if region not in ('centerFloor','cyanRing'): continue
        local=b['local'](box)
        cut=lambda v:b['cut'](v,local)
        here={};groups[route][region]=here
        for tag,mask,stat in (
            ('neutralDarker',neutral&(luma_diff<0),luma_diff),
            ('warmDarker',warm&(luma_diff<0),luma_diff),
            ('cyanClose',cyan,np.abs(luma_diff))):
            indexes=np.argwhere(cut(valid&mask))
            assert indexes.size>0
            iy,ix=indexes.T
            order=np.argsort(cut(stat)[iy,ix],kind='stable')
            ids=[]
            rows=[]
            for j in order:
                qx,qy=ix[j]+local[0],iy[j]+local[1]
                xy=addressed[qy,qx]
                if any(np.max(abs(xy-old))<stable_limit for old in ids): continue
                ids.append(xy)
                rows.append(dict(halfReflectionXY=[int(qx)+roi[0],int(qy)+roi[1]],
                                 previousPixelXY=xy.tolist(),worldNative=wn[qy,qx].tolist(),worldPlayer=wp[qy,qx].tolist(),
                                 nativeHdr=a[qy,qx].tolist(),playerHdr=p[qy,qx].tolist(),
                                 deltaCompressedLuma=float(luma_diff[qy,qx])))
                if len(rows)==8: break
            here[tag]=rows
            print(route,region,tag,[(r['previousPixelXY'],round(r['deltaCompressedLuma'],5)) for r in rows],flush=True)
proof=dict(status='prepared-fixed-address-history-stage-witnesses',
           sourceInputs={'player':receipt['fullSha256'],'depth':depth_ids}, groups=groups,
           selection='At most eight per chroma witness kind, with source display texels separated by at least six pixels.')
(s['floor']/'history-source-producer-witnesses.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
