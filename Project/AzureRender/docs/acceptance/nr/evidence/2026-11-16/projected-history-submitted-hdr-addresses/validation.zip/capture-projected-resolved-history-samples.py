from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
O=M/'projected-resolved-history-actual-samples'
REFERENCE=M/'joint-projected-resolved-hdr-valid-steps'
EREF=W/'docs/acceptance/nr/evidence/2026-11-16/projected-history-color-lineage'
build=M/'projected-resolved-history-probe'
P=M/'projected-history-layer-release/AzurePlayerResolvedHistoryProbe.exe'
kernel='projected_reflection_trace.comp.spv'
env=('AZR_NR_QA_PROJECTED_RESOLVED_HISTORY','AZR_NR_QA_RESOLVED_COLOR_READBACK')
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,r:p.write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
S0=M/'projected-reflection-32-step-candidate'
AA=M/'joint-current-temporal-resolve'
HDR=M/'joint-projected-previous-resolved-hdr-retry'


def restored(gpu,index,shape,combined):
    p=S0/f'baseline-{gpu}/frames/frame_{index:06d}.png'
    raw=cv2.imread(str(p),-1)
    assert raw.shape==shape and sha(p)==read(p.parents[1]/'result.json')['images'][index]
    for stage in (AA,HDR,REFERENCE):
        row=read(stage/'qualification.json')['reports'][gpu]['rows'][index]
        delta=stage/gpu/f'delta-{index}.zip'
        assert sha(delta)==row['deltaArchive']
        with ZipFile(delta) as z:
            assert z.testzip() is None
            raw^=np.frombuffer(z.read('bgra-xor'),np.uint8).reshape(shape)
        assert sha256(raw.tobytes()).hexdigest()==row['raw']
    return raw


def run():
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    from artifact_maintenance import database,resume,rows
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    q=read(build/'qualification.json')
    assert q['status']=='built-projected-resolved-history-probe' and sha(P)==q['candidate']
    active=read(REFERENCE/'qualification.json')
    assert active['status']=='measured-resolved-hdr-with-native-step-bound' and active['historyValidOnly']
    assert sha(REFERENCE/'programs'/kernel)==active['program']
    root=runpy.run_path(str(M/'run-immutable-scene-glyph-capture.py'),run_name='readback_actual_joint_scene')
    catalog=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='readback_historical_programs')
    R=catalog['R']
    catalog['activate_links'].__wrapped__.__globals__['home']=O
    in_before=root['immutable_index']()
    stamp=root['tree_stamp']()
    assert in_before==active['immutable']
    source=read(EREF/'results.json')
    with ZipFile(EREF/'validation.zip') as z:
        assert z.testzip() is None and sha(EREF/'validation.zip')==source['archiveSha256']
        native_data=z.read('native-results.json')
        assert sha256(native_data).hexdigest()==source['files']['native-results.json']
        native_rows=json.loads(native_data)['samples']
    assert len(native_rows)==source['sourceAddresses']==74
    order=[tuple(r['pixel']) for r in native_rows]
    assert len(set(order))==len(order)
    native=np.array([r['nativeHdr'] for r in native_rows],dtype=np.float64)
    opaque=np.array([r['playerHdr'] for r in native_rows],dtype=np.float64)
    def compressed_luma(arr):
        return (arr@(.2126,.7152,.0722))/(1+arr.max(axis=1))
    desc=set('/'.join(v) for r in native_rows for v in r['groups'])
    subgroups={k:np.array([k in map('/'.join,r['groups']) for r in native_rows]) for k in sorted(desc)}
    subgroups['all']=np.ones(len(order),bool)
    O.mkdir()
    public=O/'programs'
    public.mkdir()
    (public/kernel).hardlink_to(REFERENCE/'programs'/kernel)
    assert sha(public/kernel)==active['program']
    with database(W/'build') as db:
        previous=rows(db)[R.name]
    assert previous['status']=='closed'
    observations={}
    resume(W/'build',R.name)
    try:
        with catalog['activate_links']({kernel:active['program']}):
            for gpu in ('nvidia','intel'):
                budget=check(W/'build',run=M,planned=14_200_000)
                assert budget['allowed'],budget
                directory=O/gpu
                directory.mkdir()
                signal=directory/'submitted-hdr.bin'
                signal.with_suffix('.bin.points').write_text(''.join(f'{x} {y}\n' for x,y in order),encoding='utf8')
                args=read(REFERENCE/gpu/'command.json')
                args[0]=str(P)
                for flag,p in (('--capture-dir',directory/'frames'),('--runtime-report',directory/'runtime.json')):
                    args[args.index(flag)+1]=str(p)
                assert args[args.index('--project')+1]==str(root['project'])
                assert not any(k in os.environ for k in env)
                os.environ.update(zip(env,('1',str(signal))))
                try:
                    root['S']['invoke'](gpu,args,directory)
                finally:
                    for key in env:os.environ.pop(key)
                log=(directory/'player.log').read_text(encoding='utf8',errors='replace')
                assert log.count('QA projected reflection uses submitted HDR resolve 1')==1
                assert 'Allocator after unload: buffers=0 images=0' in log
                runtime=read(directory/'runtime.json')
                assert not runtime['presentationErrors'] and not runtime['scriptErrors']
                signal_data=signal.read_bytes()
                assert len(signal_data)==len(order)*8
                measured=np.frombuffer(signal_data,'<f2').reshape(len(order),4).astype(np.float64)
                assert np.isfinite(measured).all() and np.all(measured[:,:3]>=0)
                br=compressed_luma(opaque)-compressed_luma(native)
                val=compressed_luma(measured[:,:3])-compressed_luma(native)
                groups={}
                for label,selector in subgroups.items():
                    groups[label]=dict(count=int(selector.sum()),opaqueMedianAbsolute=float(np.median(np.abs(br[selector]))),
                                       submittedMedianAbsolute=float(np.median(np.abs(val[selector]))),
                                       improved=int(np.count_nonzero(np.abs(val[selector])<np.abs(br[selector]))),
                                       worsened=int(np.count_nonzero(np.abs(val[selector])>np.abs(br[selector]))))
                picture=[]
                for i in range(2):
                    f=directory/'frames'/f'frame_{i:06d}.png'
                    act=cv2.imread(str(f),-1)
                    ref=restored(gpu,i,act.shape,active)
                    data=np.bitwise_xor(act,ref).tobytes()
                    zfile=directory/f'delta-{i}.zip'
                    with ZipFile(zfile,'x',ZIP_DEFLATED,compresslevel=9) as z:z.writestr('bgra-xor',data)
                    with ZipFile(zfile) as z:
                        eq=ref^np.frombuffer(z.read('bgra-xor'),np.uint8).reshape(act.shape)
                        assert np.array_equal(eq,act)
                    picture.append(dict(png=sha(f),raw=sha256(act.tobytes()).hexdigest(),delta=sha(zfile),
                                        changed=int(np.count_nonzero(np.any(act!=ref,axis=2)))))
                    assert f.resolve()==f and not f.stat().st_file_attributes&1024
                    f.unlink()
                observations[gpu]=dict(samples=sha(signal),display=picture,groups=groups,
                     points=[dict(pixel=order[i],native=native[i].tolist(),earlierOpaque=opaque[i].tolist(),submitted=measured[i].tolist(),
                                  absoluteLumaError=float(abs(val[i]))) for i in range(len(order))])
                write(O/'qualification.json',dict(status='capturing',gpu=observations))
                print(gpu,observations[gpu]['groups']['all'],picture,flush=True)
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=320)
    with database(W/'build') as db:
        end=rows(db)[R.name]
    assert end['status']=='closed' and end['manifestSha256']==previous['manifestSha256']
    assert root['immutable_index']()==in_before and root['tree_stamp']()==stamp
    write(O/'qualification.json',dict(status='measured-submitted-hdr-at-native-addresses',debugPlayer=q['candidate'],
                                         nativeStage=sha(EREF/'results.json'),sampleCount=len(order),gpu=observations))

if __name__=='__main__':
    run()
