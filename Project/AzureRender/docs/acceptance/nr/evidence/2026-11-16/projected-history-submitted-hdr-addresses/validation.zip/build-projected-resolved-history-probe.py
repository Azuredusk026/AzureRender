"""Link a read-only capture build for the submitted history color attachment."""
import ast
from hashlib import file_digest
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from zipfile import ZIP_LZMA, ZipFile

M=Path(__file__).resolve().parent
W=M.parents[2]
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
release=R/'msaa-release'
base=M/'projected-history-layer-release'
reference=M/'immutable-scene-capture-source'
prior=M/'projected-resolved-history-trial'
O=M/'projected-resolved-history-probe'
exe=base/'AzurePlayerResolvedHistoryProbe.exe'
read=lambda p:json.loads(p.read_bytes())
key='AZR_NR_QA_PROJECTED_RESOLVED_HISTORY'

def sha(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()


def replace(source,old,new):
    assert source.count(old)==1,old
    return source.replace(old,new)


def build_sources():
    f=W/'src/app/AzureRenderFrame.cpp'
    verified=read(prior/'qualification.json')
    assert verified['status']=='built-projected-resolved-history-trial'
    assert sha(base/'AzurePlayerResolvedHistoryTrial.exe')==verified['candidate']
    source=prior/f.name
    assert sha(source)==verified['sources'][f.name]
    app='#include <filesystem>\n#include <fstream>\n'+source.read_text(encoding='utf8')
    anchor='        hdr.submission=temporalReconstruction_->historySubmission();'
    block=r"""        if (const char* path = std::getenv("AZR_NR_QA_RESOLVED_COLOR_READBACK")) {
            const auto destination = std::filesystem::u8path(path);
            auto coordinateFile = destination;
            coordinateFile += ".points";
            std::ifstream coordinates(coordinateFile);
            if (!coordinates || std::filesystem::exists(destination))
                throw std::runtime_error("Invalid submitted HDR readback files");
            const auto extent = renderExtent_;
            if (extent.width != 2560 || extent.height != 1440)
                throw std::runtime_error("Submitted HDR readback requires the reference viewport");
            std::vector<std::array<unsigned, 2>> points;
            unsigned x, y;
            while (coordinates >> x >> y) {
                if (x >= extent.width || y >= extent.height || points.size() >= 8192)
                    throw std::runtime_error("Invalid submitted HDR readback coordinate");
                points.push_back({x, y});
            }
            if (!coordinates.eof() || points.empty())
                throw std::runtime_error("Missing submitted HDR readback coordinates");
            const auto bytes = VkDeviceSize(extent.width) * extent.height * 8;
            auto staging = gpuAllocator_.createBuffer(bytes, VK_BUFFER_USAGE_TRANSFER_DST_BIT, true);
            try {
                rhi_->executeOneShot([&](azurerender::rhi::ICommandRecorder& commands) {
                    const auto shaderStages = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT | VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT;
                    azurerender::rhi::ImageBarrierDesc state{};
                    state.image = hdr.image;
                    state.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
                    state.oldLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
                    state.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
                    state.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | shaderStages;
                    state.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_SHADER_READ_BIT;
                    state.dstStageMask = VK_PIPELINE_STAGE_TRANSFER_BIT;
                    state.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
                    commands.imageBarrier(state);
                    commands.copyImageToBuffer(hdr.image, staging.buffer, extent);
                    state.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
                    state.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
                    state.srcStageMask = VK_PIPELINE_STAGE_TRANSFER_BIT;
                    state.srcAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
                    state.dstStageMask = shaderStages;
                    state.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
                    commands.imageBarrier(state);
                });
                gpuAllocator_.invalidate(staging, 0, bytes);
                const auto* pixels = static_cast<const char*>(staging.mapped);
                std::ofstream file(destination, std::ios::binary);
                for (const auto& p : points)
                    file.write(pixels + 8 * (std::size_t(p[1]) * extent.width + p[0]), 8);
                if (!file)
                    throw std::runtime_error("Could not write submitted HDR sample pixels");
            } catch (...) {
                gpuAllocator_.destroyBuffer(staging);
                throw;
            }
            gpuAllocator_.destroyBuffer(staging);
        }"""
    app=replace(app,anchor,anchor+'\n'+block)
    return {O/f.name:app},(f,)


def run():
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    budget=check(W/'build',run=M,planned=24_000_000)
    assert budget['allowed'],budget
    assert not exe.exists()
    expected=read(reference/'qualification.json')
    assert sha(base/'AzurePlayerCaptureResource.exe')==expected['candidatePlayer']
    assert sha(reference/'AssetDatabase.cpp.obj')==expected['assetDatabaseObject']
    sources,compile_units=build_sources()
    for p,value in sources.items():
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(value,encoding='utf8')
    compiler=runpy.run_path(str(R/'face-quality-batch.py'),run_name='hdr_trial_compiler')
    ninja=Path(compiler['cmake']).parents[2]/'Ninja/ninja.exe'
    schema=ast.parse((M/'build-camera-pose-player.py').read_text(encoding='utf8'))
    fn,=[p for p in schema.body if isinstance(p,ast.FunctionDef) and p.name=='windows_arguments']
    scope={}
    exec(compile(ast.Module(body=[fn],type_ignores=[]),'argv','exec'),scope)
    commands=subprocess.check_output([str(ninja),'-C',str(release),'-t','commands','AzurePlayer'],text=True).splitlines()
    tasks=[]
    objs=[]
    for p in compile_units:
        cmd,=[line for line in commands if line.endswith(str(p))]
        args=scope['windows_arguments'](cmd)
        output=O/(p.name+'.obj')
        objs.append(output)
        for option,value in [('/Fo',output),('/Fd',O/(p.stem+'.pdb'))]:
            i,=[i for i,arg in enumerate(args) if arg.startswith(option)]
            args[i]=option+str(value)
        args.insert(1,'/I'+str(prior/'include'))
        args[-1:]=['/I'+str(prior), '/I'+str(p.parent), str(O/p.name)]
        tasks.append((p.stem,args))
    receipt=read(reference/'main-object-compaction.json')
    archive=Path(receipt['archive'])
    assert sha(archive)==receipt['archiveSha']
    restored=O/'capture-entry-main.cpp.obj'
    with ZipFile(archive) as z, restored.open('xb') as file:
        file.write(z.read(receipt['member']))
    assert sha(restored)==receipt['sha256']==expected['entryObject']
    base_proof=read(prior/'qualification.json')
    scene=O/'CharacterSceneRenderer.cpp.obj'
    zipped=prior/'objects.zip'
    assert sha(zipped)==base_proof['objectArchive']
    with ZipFile(zipped) as z, scene.open('xb') as file:
        file.write(z.read(scene.name))
    assert sha(scene)==base_proof['objects'][scene.name]
    link_source=(reference/'player.rsp').read_text(encoding='ascii').splitlines()
    assert str(reference/'main.cpp.obj') in link_source[0]
    rsp=O/'player.rsp'
    head=link_source[0].replace(str(reference/'main.cpp.obj'),str(restored))
    rsp.write_text('\n'.join([head+' '+subprocess.list2cmdline([str(p) for p in [*objs,scene]]),*link_source[1:]])+'\n',encoding='ascii')
    opt=read(base/'link-receipt.json')['linkCommand'].copy()
    for i,v in enumerate(opt):
        if v.startswith('--intdir='):
            parts=O/'link-intermediates'
            parts.mkdir(exist_ok=True)
            opt[i]='--intdir='+str(parts)
        elif v.startswith('@'):opt[i]='@'+str(rsp)
        elif v.lower().startswith('/out:'):opt[i]='/out:'+str(exe)
        elif v.lower().startswith('/implib:'):opt[i]='/implib:'+str(O/'entry.lib')
        elif v.lower().startswith('/pdb:'):opt[i]='/pdb:'+str(O/'entry.pdb')
    tasks.append(('link',opt))
    env={k:v for k,v in os.environ.items() if k not in (key,'AZR_NR_QA_RESOURCE_ID','AZR_NR_QA_RESOURCE_PATH')}
    try:
        for name,command in tasks:
            result=subprocess.run(subprocess.list2cmdline([compiler['entry'],*command]),shell=True,cwd=release,
                                  env=env,capture_output=True,timeout=235)
            (O/f'{name}.log').write_bytes(result.stdout+result.stderr)
            assert result.returncode==0,(name,result.stdout[-5000:],result.stderr[-1500:])
    finally:
        assert not restored.stat().st_file_attributes&1024 and sha(restored)==expected['entryObject']
        restored.unlink()
        assert scene.resolve()==scene and sha(scene)==base_proof['objects'][scene.name]
        scene.unlink()
    good=subprocess.run([str(exe),'--help'],env=env,capture_output=True,timeout=20)
    assert good.returncode==0 and b'--capture-frames' in good.stdout
    artifacts={p.name:sha(p) for p in objs}
    packed=O/'objects.zip'
    assert check(W/'build',run=M,planned=1_000_000)['allowed']
    with ZipFile(packed,'x',ZIP_LZMA) as z:
        for p in objs:z.write(p,p.name)
    with ZipFile(packed) as z:
        assert z.testzip() is None
        from hashlib import sha256
        assert all(sha256(z.read(p.name)).hexdigest()==artifacts[p.name] for p in objs)
    for p in objs:
        assert p.resolve()==p and p.parent==O and not p.stat().st_file_attributes&1024 and sha(p)==artifacts[p.name]
        p.unlink()
    record=dict(status='built-projected-resolved-history-probe',candidate=sha(exe),baseline=expected['candidatePlayer'],
                sources={str(p.relative_to(O)):sha(p) for p in sources},objects=artifacts,objectArchive=sha(packed))
    (O/'qualification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
    print(record,flush=True)


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print([str(p.relative_to(O)) for p in build_sources()[0]])
    else:
        run()
