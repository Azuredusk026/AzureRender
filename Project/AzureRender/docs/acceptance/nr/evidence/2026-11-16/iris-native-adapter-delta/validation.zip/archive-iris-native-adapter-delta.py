"""Verify the two native implicit controls and their one-texture mip interventions."""

from hashlib import sha256
import json
from pathlib import Path
import sys
import zipfile

import numpy as np

run = Path(__file__).resolve().parent
grid = run.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
dest = run.parents[2] / 'docs/acceptance/nr/evidence/2026-11-16/iris-native-adapter-delta'
sides = ('nvidia', 'intel')
digest = lambda bytes_: sha256(bytes_).hexdigest()
read = lambda path: json.loads(path.read_bytes())


def pack(array):
    return np.asarray(array, dtype='<u4').tobytes()


def collect():
    base = grid/'iris-explicit-mips'
    matcap = run/'iris-native-matcap-footprint'
    points = (grid/'native-iris-stages/points.bin').read_bytes()
    requests = [read(p/'request.json') for p in (base,matcap)]
    assert all(Path(r['points']).read_bytes() == points for r in requests)
    assert 'matcapLevels' not in requests[0] and requests[1]['matcapLevels'] is True
    identity = {k:requests[0][k] for k in ('captureSha256','pixelShaderSha256')}
    assert all(requests[1][k]==v for k,v in identity.items())
    a, b = read(base/'iris-explicit-mips.json'), read(matcap/'results.json')
    assert a['status'] == b['status'] == 'qualified'
    proof = {'points.bin': points, 'source-identity.json': json.dumps(identity,sort_keys=True).encode(),
             'base-source.json': (base/'iris-explicit-mips.json').read_bytes(),
             'matcap-source.json': (matcap/'results.json').read_bytes()}
    for side in sides:
        for f in [f'{side}-implicit.bin', *(f'{side}-mip-{i:02d}.bin' for i in range(10))]:
            proof[f] = (base/f).read_bytes()
    return proof


def srgb(p, scale=1):
    def channel(v, n):
        f, e = v & ((1 << n)-1), (v >> n).astype('i4')
        assert (e < 31).all()
        return np.ldexp(np.where(e==0, f, (1 << n)+f).astype('f8'), np.maximum(e,1)-15-n)
    linear = np.stack((channel(p & 2047,6), channel((p >> 11) & 2047,6), channel(p >> 22,5)),axis=-1)
    x = np.clip(linear*scale,0,1)
    return np.rint(np.where(x <= .0031308,12.92*x,1.055*x**(1/2.4)-.055)*255).astype('i2')


def score(proof):
    points=np.frombuffer(proof['points.bin'],'<u4').reshape(-1,2)
    assert len(points)==255 and len(set(map(tuple,points)))==len(points)
    a, b = (json.loads(proof[k]) for k in ('base-source.json','matcap-source.json'))
    source = {}
    for side in sides:
        base, matcap=a['devices'][side], b['devices'][side]
        implicit=proof[f'{side}-implicit.bin']
        assert digest(implicit)==base['implicitSha256']
        assert matcap['baselineRestored'] and pack(matcap['cases']['copy']['packed'])==implicit
        br=[]; mr=[]
        for i in range(10):
            blob=proof[f'{side}-mip-{i:02d}.bin']
            assert digest(blob)==base['mips'][str(i)]['sha256']
            br.append(np.frombuffer(blob,'<u4'))
            if i<9: mr.append(np.asarray(matcap['cases'][str(i)]['packed'],'<u4'))
        ip=np.frombuffer(implicit,'<u4')
        assert ip.shape==(len(points),) and np.asarray(br).shape==(10,len(points)) and np.asarray(mr).shape==(9,len(points))
        source[side]=(ip,np.asarray(br),np.asarray(mr))
    (n,nb,nm),(i,ib,im) = (source[s] for s in sides)
    delta=lambda n,i,scale=1: np.abs(srgb(n,scale)-srgb(i,scale)).max(axis=-1)
    base_match,matcap_match = [(nl==n,il==i) for nl,il in ((nb,ib),(nm,im))]
    assert all(x.any(axis=0).all() for x in (*base_match,*matcap_match))
    d, qualified = delta(n,i), delta(n,i,.25)
    histogram=lambda values: {str(k):v for k,v in zip(*(p.tolist() for p in np.unique(values,return_counts=True)))}
    controls=[]
    for k in np.flatnonzero((d>2)|(qualified>2)):
        row=dict(point=points[k].tolist(),implicitPacked=[int(n[k]),int(i[k])],
                 implicitClippedSrgb8=[srgb(n[k]).tolist(),srgb(i[k]).tolist()], implicitMax=int(d[k]),
                 bareComparisonRgb8=[srgb(n[k],.25).tolist(),srgb(i[k],.25).tolist()],
                 bareComparisonMax=int(qualified[k]))
        for name, (nl,il), matches in (('base',(nb,ib),base_match),('matcap',(nm,im),matcap_match)):
            levels={s:np.flatnonzero(h[:,k]).tolist() for s,h in zip(sides,matches,strict=True)}
            fixed=delta(nl[:,k],il[:,k])
            bare=delta(nl[:,k],il[:,k],.25)
            row[name]=dict(implicitCompatibleLevels=levels,
                implicitLevelSetsDisjoint=not bool(set(levels[sides[0]]) & set(levels[sides[1]])),
                fixedSameLevelDelta=fixed.tolist(),
                bothAtNvidiaImplicitLevels=[int(fixed[j]) for j in levels['nvidia']],
                bothAtIntelImplicitLevels=[int(fixed[j]) for j in levels['intel']],
                bareComparisonAtNvidiaImplicitLevels=[int(bare[j]) for j in levels['nvidia']])
        controls.append(row)
    assert len(controls)==8 and int(d.max())==29 and int(np.count_nonzero(n!=i))==124
    assert int(qualified.max())==28 and int((qualified>2).sum())==6
    identity=json.loads(proof['source-identity.json'])
    assert all(len(x)==64 and int(x,16) for x in identity.values())
    return dict(status='verified-native-e846-adapter-diagnostic',event=846,points=len(points),adapters=list(sides),
        identity=identity,packedDifferent=int(np.count_nonzero(n!=i)),clippedSrgb8MaxDeltaHistogram=histogram(d),
        bareComparisonDisplay=dict(linearMultiplier=.25, maxDeltaHistogram=histogram(qualified)),
        controls=controls,sourceSha256={k:digest(v) for k,v in proof.items()},
        scope='Direct and standard bare-comparison RGB conversion of the native R11G11B10 attachment at event 846. The final eye overlay, display pipeline, and formal reference are separate.')


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        p=collect();r=score(p)
    elif sys.argv[1:]==['produce']:
        p=collect();r=score(p);dest.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(dest/'validation.zip','w',zipfile.ZIP_DEFLATED) as archive:
            for name,data in sorted(p.items()):archive.writestr(name,data)
            archive.write(Path(__file__),Path(__file__).name)
        r['archiveSha256']=digest((dest/'validation.zip').read_bytes())
        (dest/'results.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
    else:
        assert sys.argv[1:]==['verify']
        expected=read(dest/'results.json'); archive_path=dest/'validation.zip'
        assert expected.pop('archiveSha256') == digest(archive_path.read_bytes())
        with zipfile.ZipFile(archive_path) as archive:
            assert archive.testzip() is None
            assert set(archive.namelist())==set(expected['sourceSha256'])|{Path(__file__).name}
            assert archive.read(Path(__file__).name)==Path(__file__).read_bytes()
            p={k:archive.read(k) for k in expected['sourceSha256']}
        r=score(p);assert r==expected
    print(r['clippedSrgb8MaxDeltaHistogram'],r['bareComparisonDisplay'], [
        (v['point'], v['bareComparisonMax'], [(a,v[a]['implicitLevelSetsDisjoint'],v[a]['bareComparisonAtNvidiaImplicitLevels'])
                                        for a in ('base','matcap')]) for v in r['controls']])
