"""Measure iris residuals against cover ownership and actual native mip controls."""
import gzip
from pathlib import Path
import runpy
import numpy as np

root=Path(__file__).resolve().parent
h=runpy.run_path(str(root/'iris-matcap-differential-player.py'),run_name='iris_controls')
read,digest,write=(h[k] for k in ('read','digest','write'))
src=h['stage']/'earlyProjectiveCoarseBaseFineDiagonal'
body=h['body']
s=h['score']
case=src.name
receipts=[root/'iris-native-matcap-d3d-vulkan-owned-levels.json',
          root/'iris-matcap-projective-footprint.json',root/'iris-base-footprint-native-match.json',src/'results.json']
native,mip,base,result=map(read,receipts)
assert result['stage']=='covered'
assert digest(s['reference_path'])==result['reference']
assert digest(src/'preflight.json')==result['preflight']
pts=native['points']
x,y=np.asarray(pts).T
folder=s['stages']/'post-opaque-ownership'
def tex(e):
    return np.frombuffer(gzip.decompress((folder/f'1245-{e}.bin.gz').read_bytes()),'<u4').reshape(1440,2560)[::-1][y,x]

opaque=tex(1244)
overlay=tex(1245)!=opaque
assert overlay.sum()==94
reference={True:s['image'](s['reference_path'])[y,x].astype(np.int16),False:h['display'](h['unpack'](opaque))}
output={}
for device,phases in result['devices'].items():
    assert [p['point'] for p in mip['devices'][device]['rows']]==pts
    match=np.array([p['matches'] for p in mip['devices'][device]['rows']])
    assert (~match).sum()==255-mip['devices'][device]['actualNativeMipMatches']
    output[device]={}
    for cover in (False,True):
        key=str(cover).lower()
        q=phases[key]
        m='covered' if cover else 'bare'
        p=src/f'{device}-{m}'/'frames/frame_000000.png'
        old=body/(f'eye-native-public-{device}-projected' if cover else f'iris-native-main-frame-uncovered-{device}')/'frames/frame_000000.png'
        assert digest(p)==q['frame'] and digest(old)==q['control']
        original=s['image'](old)
        candidate=s['image'](p)
        full=(candidate!=original).any(axis=2)
        full[y,x]=False
        v=np.stack([a[y,x].astype(np.int16)-reference[cover] for a in (original,candidate)])
        residual=abs(v).max(axis=2)>1
        assert q['peak']==abs(v).max(axis=(1,2)).tolist() and q['overOne']==residual.sum(axis=1).tolist()
        assert int((residual[1]&~residual[0]).sum())==q['newOverOne']==0 and q['outsideIrisChanged']==full.sum()==0
        selected=residual[1]
        extra=selected&overlay
        output[device][m]=dict(overOne=q['overOne'],peak=q['peak'],noNewOrOutside=True,
            overlapWithNativeCover=int(extra.sum()),outsideNativeCover=int((selected&~overlay).sum()),
            matcapLevelMismatchOverlap=int((selected&~match).sum()),
            overOneByChannel=(abs(v[1])>1).sum(axis=0).tolist(),
            residual=[dict(point=point,baselineDelta=v[0,i].tolist(),candidateDelta=v[1,i].tolist(),
               covered=bool(overlay[i]),matcapControl=mip['devices'][device]['rows'][i])
               for i,point in enumerate(pts) if selected[i]])
    bare={tuple(row['point']) for row in output[device]['bare']['residual']}
    cover={tuple(row['point']) for row in output[device]['covered']['residual']}
    output[device]['commonResidualPixels']=len(bare&cover)
receipt=dict(status='measured-candidate-residual-overlap',strictAcceptance='failed',regions=255,nativeCoveredPixels=94,
  receipts={p.name:digest(p) for p in receipts},devices=output)
write(src/'residual-attribution.json',receipt)
for k,v in output.items():
    print(k,{phase:{f:x for f,x in item.items() if f!='residual'} if isinstance(item,dict) else item for phase,item in v.items()})
