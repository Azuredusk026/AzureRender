"""Render the projected iris footprint, without subgroup lane operations."""
from hashlib import sha256
import gzip
import json
from pathlib import Path
import runpy
import sys

import numpy as np


root=Path(__file__).resolve().parent
main=runpy.run_path(str(root/'iris-matcap-differential-player.py'),run_name='iris_gradient_controls')
stage,build,body,workspace=[main[name] for name in ('stage','build','body','workspace')]
read,write,digest,score=[main[name] for name in ('read','write','digest','score')]


def canonical_base_sampler():
    records={}
    for tag in ('nvidia','intel'):
        material=body/f'eye-native-public-{tag}-projected/face-iris-public-main-frame.azurematerial'
        raw=read(material)
        surface=raw['surface'];spec=surface['materials'][0]['pbrMetallicRoughness']['baseColorTexture']['index']
        asset=raw['textures'][str(surface['textures'][spec]['source'])]['asset']
        meta=main['fixture']/'materials'/f'{asset}.dds.azmeta'
        settings=read(meta)['settings']['texture']
        assert (settings['mipBias'],settings['mipFilter'],settings['filter'],settings['anisotropy'])==(-1,'nearest','linear',1)
        records[tag]=dict(material=digest(material),samplerMeta=digest(meta),mipBias=settings['mipBias'])
    assert records['nvidia']['samplerMeta']==records['intel']['samplerMeta']
    return records


helper="""
vec2 projectedMatcapUv(vec2 uv,vec3 normal,vec4 tangent,mat3 worldToView,float normalScale){
    vec2 radial=fract(uv)*2.0-1.0;
    vec3 local=vec3(-radial*normalScale,sqrt(max(1.0-dot(radial,radial),0.0)));
    vec3 bitangent=cross(normal,tangent.xyz)*tangent.w;
    vec3 viewNormal=characterEyeSafeNormalize(worldToView*mat3(tangent.xyz,bitangent,normal)*local);
    return viewNormal.xy*.5+.5;
}

mat2 projectedMatcapGradients(vec2 uv,vec3 normal,vec4 tangent,mat3 transform,float normalScale,vec2 centerUv){
    vec2 lane=vec2(ivec2(gl_FragCoord.xy)&ivec2(1));
    vec2 offsets[3]=vec2[3](-lane,vec2(0,1)-lane,vec2(1,1)-lane);
    float reciprocalW=gl_FragCoord.w;
    vec2 uvOverW=uv*reciprocalW;
    vec3 normalOverW=normal*reciprocalW;
    vec4 tangentOverW=tangent*reciprocalW;
    vec2 stepW=vec2(dFdxFine(reciprocalW),dFdyFine(reciprocalW));
    mat2 uvStep=mat2(dFdxFine(uvOverW),dFdyFine(uvOverW));
    mat2x3 normalStep=mat2x3(dFdxFine(normalOverW),dFdyFine(normalOverW));
    mat2x4 tangentStep=mat2x4(dFdxFine(tangentOverW),dFdyFine(tangentOverW));
    mat2 fallback=mat2(dFdxCoarse(centerUv),dFdyCoarse(centerUv));
    vec2 coords[3];
    for(int sampleIndex=0;sampleIndex<3;++sampleIndex){
        vec2 offset=offsets[sampleIndex];
        float w=reciprocalW+dot(stepW,offset);
        if(w<=0.0)return fallback;
        coords[sampleIndex]=projectedMatcapUv((uvOverW+uvStep*offset)/w,
            (normalOverW+normalStep*offset)/w,(tangentOverW+tangentStep*offset)/w,transform,normalScale);
    }
    return mat2(coords[2]-coords[1],coords[1]-coords[0]);
}

"""


def preflight(folder, align_base):
    model=read(root/'iris-matcap-projective-footprint.json')
    assert model['scope']==255 and all(result['mipMatchesAnalytic']==255 for result in model['devices'].values())
    source=stage/'earlySeamPreserve/mesh.frag'
    original=read(stage/'preflight.json')
    assert digest(source)==original['cases']['earlySeamPreserve']['source']
    code=source.read_text(encoding='utf8')
    start=code.index('        vec2 eyeUv=earlyEyeCoordinates.matcapUv;')
    stop=code.index('    }\n',start)
    new=('        mat2 footprint=projectedMatcapGradients(originalUv,worldNormal,worldTangent,worldToView,\n'
         '            earlyEyeProfile.shape.y,earlyEyeCoordinates.matcapUv);\n'
         '        earlyEyeMatcap=textureGrad(AZ_TEX_MATCAP,earlyEyeCoordinates.matcapUv,footprint[0],footprint[1]);\n')
    code=code[:start]+new+code[stop:]
    assert code.count('void main()\n')==1
    code=code.replace('void main()\n',helper+'void main()\n',1)
    if align_base:
        base_model=read(root/'iris-base-footprint-native-match.json')
        assert base_model['scope']==255
        assert base_model['methods']['Finediagonal']['matches']['nvidia']==255
        base_sampler=canonical_base_sampler()
        # This diagnostic calls the standalone helper outside the optional sampling branch.
        code=code.replace('void main()\n','#include "texture_footprint.glsl"\n\nvoid main()\n',1)
        lookup='baseColor=texture(AZ_TEX_BASE_COLOR,eyeCoordinates.baseUv);'
        assert code.count(lookup)==1
        explicit_sample='''vec2 baseUv=eyeCoordinates.baseUv;
        vec2 baseExtent=vec2(textureSize(AZ_TEX_BASE_COLOR,0));
        float baseLod=azureAxisDiagonalMipLod(dFdxFine(baseUv)*baseExtent,dFdyFine(baseUv)*baseExtent);
        baseColor=textureLod(AZ_TEX_BASE_COLOR,baseUv,floor(baseLod+.5));'''
        code=code.replace(lookup,explicit_sample)
    folder.mkdir(exist_ok=True)
    source=folder/'mesh.frag'
    source.write_text(code,encoding='utf8')
    shader_dir=folder/'resources/shaders'
    shader_dir.mkdir(parents=True,exist_ok=True)
    for program in main['programs']:
        diagnostic = folder/'compile'/f'{program}.log' if align_base else None
        main['compile_program'](source,shader_dir/program,program,diagnostics=diagnostic)
    receipt=dict(source=digest(source),programs={program:digest(shader_dir/program) for program in main['programs']},
                 quadModel=digest(root/'iris-matcap-projective-footprint.json'),baseShader=original['sourceCommit'])
    if align_base:
        receipt['baseFootprints']=digest(root/'iris-base-footprint-native-match.json')
        receipt['baseSampler']=base_sampler
    write(folder/'preflight.json',receipt)
    return receipt


def run(covered_phase=False, align_base=False):
    case='earlyProjectiveCoarseBaseFineDiagonal' if align_base else 'earlyProjectiveCoarse'
    folder=stage/case
    main['check_budget']()
    lease=read(main['lease_file'])
    assert lease['state']=='held' and Path(lease['output'])==root
    entry=preflight(folder, align_base)
    main['prepare'](dict(cases={case:entry}))
    data=read(root/'iris-native-matcap-d3d-vulkan-owned-levels.json')
    xy=np.asarray(data['points'])
    x,y=xy.T
    assert len(x)==255
    native=score['stages']/'post-opaque-ownership'
    load=lambda index:np.frombuffer(gzip.decompress((native/f'1245-{index}.bin.gz').read_bytes()),'<u4').reshape(1440,2560)[::-1][y,x]
    before_overlay,after_overlay=[load(index) for index in (1244,1245)]
    covered=before_overlay!=after_overlay
    assert int(covered.sum())==94
    expected={False:main['display'](main['unpack'](before_overlay)),
              True:score['image'](score['reference_path'])[y,x].astype(np.int16)}
    prior=folder/'bare-results.json'
    observations={}
    if covered_phase:
        validated=read(prior)
        assert validated['stage']=='bare' and validated['scope']==len(xy)
        assert validated['preflight']==digest(folder/'preflight.json')
        assert validated['reference']==digest(score['reference_path'])
        observations=validated['devices']
        for tag in ('nvidia','intel'):
            previous=folder/f'{tag}-bare/frames/frame_000000.png'
            assert observations[tag]['false']['frame']==digest(previous)
    for tag in ('nvidia','intel'):
        tested=observations.setdefault(tag,{})
        if covered_phase:
            bare=tested['false']
            if bare['outsideIrisChanged'] or bare['newOverOne'] or bare['overOne'][0]<=bare['overOne'][1]:
                continue
        for cover in (covered_phase,):
            path=body/(f'eye-native-public-{tag}-projected' if cover else f'iris-native-main-frame-uncovered-{tag}')
            origin=path/'frames/frame_000000.png'
            actual=main['draw'](tag,case,cover)
            colors=[score['image'](frame).astype(np.int16) for frame in (origin,actual)]
            errors=[np.abs(layer[y,x]-expected[cover]).max(1) for layer in colors]
            before,after=errors
            outside=np.any(colors[0]!=colors[1],axis=2)
            outside[y,x]=False
            result=dict(frame=digest(actual),control=digest(origin),overOne=[int((error>1).sum()) for error in errors],
                peak=[int(e.max()) for e in errors],outsideIrisChanged=int(outside.sum()),
                newOverOne=int(((before<=1)&(after>1)).sum()),witnesses=[
                   dict(point=point.tolist(),before=int(a),after=int(b))
                   for point,a,b in zip(xy,before,after) if a!=b])
            tested[str(cover).lower()]=result
            print(tag,cover,{key:value for key,value in result.items() if key not in ('witnesses','frame','control')},flush=True)

    result=dict(status='measured-projective-coarse-iris-player',devices=observations,scope=len(xy),
        stage='covered' if covered_phase else 'bare',preflight=digest(folder/'preflight.json'),
        reference=digest(score['reference_path']))
    if not covered_phase:write(folder/'bare-results.json',result)
    write(folder/'results.json',result)


if __name__=='__main__':
    args=sys.argv[1:]
    assert len(args)==len(set(args))<=2 and set(args)<={'covered','canonical-base'}
    run('covered' in args,'canonical-base' in args)

