"""Link one frame-recording diagnostic translation unit against the preserved Release."""
import ast
from hashlib import file_digest
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys

M=Path(__file__).resolve().parent
W=M.parents[2]
B=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
release=B/'msaa-release'
combined=M/'projected-history-layer-release'
reference=M/'immutable-scene-capture-source'
target=M/'inline-secondary-diagnostic-player'
exe=combined/'AzurePlayerInlineSecondary.exe'
key='AZR_NR_QA_INLINE_SECONDARY'
primaryMode='reflection-primary'
original='    recordingWorkers_.runAdaptive(std::move(recordingTasks));'
replacement='''    const char* inlineSecondary = std::getenv("AZR_NR_QA_INLINE_SECONDARY");
    if (inlineSecondary && inlineSecondary[0]=='1' && inlineSecondary[1]=='\\0') {
        if (recordingTasks.empty())
            throw std::logic_error("QA inline secondary mode requires recorded pass chunks");
        const auto caller = recordingWorkers_.recordingThreadCount()-1;
        azurerender::RuntimeDiagnostics::instance().info("render","QA inline secondary command recording");
        for (auto& task : recordingTasks) task(caller);
    } else {
        recordingWorkers_.runAdaptive(std::move(recordingTasks));
    }'''


def sha(p):
    with Path(p).open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


read=lambda p:json.loads(p.read_bytes())


def controls():
    old=W/'src/app/AzureRenderFrame.cpp'
    body=old.read_text(encoding='utf8')
    retained=subprocess.check_output(['git','show','75837a6:Project/AzureRender/src/app/AzureRenderFrame.cpp'],cwd=W,encoding='utf8')
    assert body==retained and body.count(original)==1
    program=read(reference/'qualification.json')
    assert sha(combined/'AzurePlayerCaptureResource.exe')==program['candidatePlayer']
    for name,key in [('main.cpp.obj','entryObject'),('AssetDatabase.cpp.obj','assetDatabaseObject')]:
        assert sha(reference/name)==program[key]
    order='''    std::vector<azurerender::RenderGraph::PassId> recordingOrder;
    if (!runOptions_.parallelRecordingDisabled) {
        recordingOrder.reserve(graph.executionOrder().size());
        for (const auto pass : graph.executionOrder())
            if (graph.passes()[pass].parallelRecording)
                recordingOrder.push_back(pass);
    }'''
    assert body.count(order)==1
    revisedOrder='''    const auto* recordingDiagnostic = std::getenv("AZR_NR_QA_INLINE_SECONDARY");
    const bool reflectionPrimary=recordingDiagnostic && std::string_view(recordingDiagnostic)=="reflection-primary";
    bool foundReflection=false;
    std::vector<azurerender::RenderGraph::PassId> recordingOrder;
    if (!runOptions_.parallelRecordingDisabled) {
        recordingOrder.reserve(graph.executionOrder().size());
        for (const auto pass : graph.executionOrder()) {
            const auto& description=graph.passes()[pass];
            if (reflectionPrimary && description.name=="character-compute-reflection") {
                foundReflection=true;
                continue;
            }
            if (description.parallelRecording) recordingOrder.push_back(pass);
        }
    }
    if (reflectionPrimary) {
        if (!foundReflection)
            throw std::logic_error("QA primary mode requires a reflection compute pass");
        azurerender::RuntimeDiagnostics::instance().info("render","QA reflection compute recorded in primary command buffer");
    }'''
    return old,'#include <cstdlib>\n#include <string_view>\n'+body.replace(original,replacement).replace(order,revisedOrder)


def run():
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    if exe.exists() and (target/'qualification.json').is_file():
        from zipfile import ZipFile
        e=W/'docs/acceptance/nr/evidence/2026-11-16/joint-character-secondary-recording'
        verified=read(e/'qualification.json')
        assert sha(e/'validation.zip')==verified['validation']['archive']
        with ZipFile(e/'validation.zip') as z:
            assert json.loads(z.read('build/qualification.json'))==read(target/'qualification.json')
            assert z.read('build/AzureRenderFrame.cpp')==(target/'AzureRenderFrame.cpp').read_bytes()
        assert sha(exe)==read(target/'qualification.json')['player']
        growth=2_600_000
    else:
        growth=12_950_000
    budget=check(W/'build',run=M,planned=growth)
    assert budget['allowed'],budget
    source,revised=controls()
    target.mkdir(exist_ok=True)
    text=target/source.name
    text.write_text(revised,encoding='utf8')
    obj=target/'AzureRenderFrame.cpp.obj'
    driver=runpy.run_path(str(B/'face-quality-batch.py'),run_name='inline_secondary_compiler')
    ninja=Path(driver['cmake']).parents[2]/'Ninja/ninja.exe'
    schema=ast.parse((M/'build-camera-pose-player.py').read_text(encoding='utf8'))
    fn,=[p for p in schema.body if isinstance(p,ast.FunctionDef) and p.name=='windows_arguments']
    ns={}
    exec(compile(ast.Module(body=[fn],type_ignores=[]),'inline_secondary_arguments','exec'),ns)
    commands=subprocess.check_output([str(ninja),'-C',str(release),'-t','commands','AzurePlayer'],text=True).splitlines()
    cl_line,=[line for line in commands if line.endswith(str(source))]
    cl=ns['windows_arguments'](cl_line)
    assert Path(cl[0]).name.lower()=='cl.exe'
    for flag,name in [('/Fo',obj),('/Fd',target/'diagnostic.pdb')]:
        i,=[i for i,v in enumerate(cl) if v.startswith(flag)]
        cl[i]=flag+str(name)
    cl[-1:]=['/I'+str(source.parent),str(text)]
    rsp=target/'player.rsp'
    link_source=(reference/'player.rsp').read_text(encoding='ascii').splitlines()
    assert str(reference/'main.cpp.obj') in link_source[0] and str(reference/'AssetDatabase.cpp.obj') in link_source[0]
    rsp.write_text('\n'.join([link_source[0]+' '+subprocess.list2cmdline([str(obj)]),*link_source[1:]])+'\n',encoding='ascii')
    options=read(combined/'link-receipt.json')['linkCommand']
    linker=options.copy()
    for i,value in enumerate(linker):
        if value.startswith('--intdir='):
            path=target/'link-intermediates'
            path.mkdir(exist_ok=True)
            linker[i]='--intdir='+str(path)
        elif value.startswith('@'):
            linker[i]='@'+str(rsp)
        elif value.lower().startswith('/out:'):
            linker[i]='/out:'+str(exe)
        elif value.lower().startswith('/implib:'):
            linker[i]='/implib:'+str(target/'diagnostic.lib')
        elif value.lower().startswith('/pdb:'):
            linker[i]='/pdb:'+str(target/'link.pdb')
    env={k:v for k,v in os.environ.items() if k not in (key,'AZR_NR_QA_RESOURCE_ID','AZR_NR_QA_RESOURCE_PATH')}
    for name,args in [('compile',cl),('link',linker)]:
        cmd=subprocess.list2cmdline([driver['entry'],*args])
        built=subprocess.run(cmd,shell=True,cwd=release,env=env,capture_output=True,timeout=175)
        (target/f'{name}.log').write_bytes(built.stdout+built.stderr)
        assert built.returncode==0,(name,built.stdout[-3500:],built.stderr[-3500:])
    help=subprocess.run([str(exe),'--help'],env=env,capture_output=True,timeout=20)
    assert help.returncode==0 and b'--disable-parallel-recording' in help.stdout
    q=dict(status='linked-inline-secondary-diagnostic',source=sha(source),diagnostic=sha(text),object=sha(obj),
           player=sha(exe),immutableSourcePlayer=sha(combined/'AzurePlayerCaptureResource.exe'),
           introduction='Optional primary recording for reflection compute only; normal preparation and other pass buffers are retained.',
           supportedModes=['1',primaryMode])
    (target/'qualification.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
    print(q)


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(controls()[0])
    else:
        run()
