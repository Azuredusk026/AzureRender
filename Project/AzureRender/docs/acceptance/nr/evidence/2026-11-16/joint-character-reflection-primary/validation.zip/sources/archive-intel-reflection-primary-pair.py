"""Archive equivalent primary-buffer captures and the separate sync validation run."""
import json
from hashlib import sha256
from pathlib import Path
import sqlite3
from zipfile import ZIP_DEFLATED, ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
S=M/'joint-character-referenced-body'
B=M/'inline-secondary-diagnostic-player'
O=M.parents[2]/'docs/acceptance/nr/evidence/2026-11-16/joint-character-reflection-primary'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
test=read(S/'intel-reflection-primary-qualification.json')
serial=read(S/'intel-serial-qualification.json')
validation=read(S/'intel-sync-validation-qualification.json')
assert test['identical'] and test['first']['png']==test['repeat']['png']==serial['first']['png']
assert test['diagnostic']==read(B/'qualification.json')
assert test['diagnostic']['diagnostic']==sha(B/'AzureRenderFrame.cpp')
base=M/'character-six-view-inputs/intel-back-detail/frames/frame_000000.png'
img=cv2.imread(str(base),-1)
assert img.shape==(720,1280,4)
contents={}
for suffix,data in [('reflection-primary-a',test['first']),('reflection-primary-b',test['repeat']),
                    ('synchronization-validation',validation['frame'])]:
    path=S/f'intel-{suffix}'
    archive=S/(path.name+'.zip')
    assert sha(base)==data['referencePng'] and sha(archive)==data['archive']
    with ZipFile(archive) as z:
        assert z.testzip() is None
        result=img^np.frombuffer(z.read('frame_000000.bgra-xor'),np.uint8).reshape(img.shape)
    assert sha256(result.tobytes()).hexdigest()==data['raw']
    assert read(path/'runtime.json')==read(S/'intel-native/runtime.json')
    contents['frames/'+archive.name]=archive
    for f in ('command.json','runtime.json','result.json','player.log','frames/capture_manifest.json','frames/gpu_capabilities.json'):
        contents[f'player/{suffix}/{f}']=path/f
checked=S/'intel-synchronization-validation/player.log'
assert validation['log']==sha(checked)
assert validation['layoutAndSync']==[]
assert 'Insert instance layer "VK_LAYER_KHRONOS_validation"' in checked.read_text('utf8',errors='replace')
for p in ('AzureRenderFrame.cpp','compile.log','link.log','qualification.json','player.rsp'):
    contents['build/'+p]=B/p
for p in ('intel-reflection-primary-qualification.json','intel-sync-validation-qualification.json'):
    contents['raw/'+p]=S/p
for p in ('build-inline-secondary-diagnostic-player.py','joint-character-referenced-body.py','archive-intel-reflection-primary-pair.py'):
    contents['sources/'+p]=M/p
cx=sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True)
jobs=[]
for i in (1486,1487,1488):
    task,state,code,elapsed=cx.execute('select task,state,exit_code,run_seconds from jobs where id=?',(i,)).fetchone()
    assert (state,code)==('succeeded',0)
    jobs.append(dict(id=i,task=task,state=state,exitCode=code,elapsedSeconds=elapsed))
O.mkdir(parents=True,exist_ok=True)
target=O/'validation.zip'
with ZipFile(target,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in contents.items():
        z.write(str(p),name)
with ZipFile(target) as z:
    receipt={name:sha256(z.read(name)).hexdigest() for name in contents}
    assert z.testzip() is None and receipt=={name:sha(p) for name,p in contents.items()}
q=dict(status='verified-intel-reflection-primary-repeat',strictBodyAcceptance=False,repeatedFrameExact=True,
       matchesExistingSerial=True,settingsScope='only linear-temporal reflection-compute recording differed',
       primaryFrame=test['first'],synchronizationFindings=validation['layoutAndSync'],queue=jobs,
       validation=dict(archive=sha(target),files=receipt))
(O/'qualification.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(target.stat().st_size)
