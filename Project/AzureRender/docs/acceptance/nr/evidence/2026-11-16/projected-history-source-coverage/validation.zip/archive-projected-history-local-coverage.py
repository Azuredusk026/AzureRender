"""Freeze the local SSIM model and independently verify its two regional scores."""

from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys
from zipfile import ZIP_DEFLATED, ZipFile

import cv2
import numpy as np


run = Path(__file__).resolve().parent
dest = run.parents[2] / 'docs/acceptance/nr/evidence/2026-11-16/projected-history-source-coverage'
model = run/'preview-projected-history-filter.py'
digest = lambda blob: sha256(blob).hexdigest()
read = lambda p: json.loads(p.read_bytes())
cases = ('glyph','known-draws','registered-source')
regions = ('centerFloor','cyanRing')


def metrics(a,b,mask):
    def ssim(a,b):
        x,y = (cv2.cvtColor(z.astype('f4')/255,cv2.COLOR_RGB2GRAY) for z in (a,b))
        blur=lambda v:cv2.GaussianBlur(v,(11,11),1.5)
        A,B=blur(x),blur(y)
        return (2*A*B+.01**2)/(A*A+B*B+.01**2)*(2*(blur(x*y)-A*B)+.03**2)/(blur(x*x)-A*A+blur(y*y)-B*B+.03**2)
    score=ssim(a,b)
    affected=cv2.dilate(mask.astype('u1'),np.ones((11,11),'u1'),borderType=cv2.BORDER_REFLECT_101)!=0
    ceiling=min(1.,(np.sum(score[~affected],dtype='f8')+np.count_nonzero(affected))/score.size)
    test=a.copy();test[mask]=b[mask]
    return dict(baselineSsim=float(score.mean(dtype='f8')), conditionalSsimCeiling=float(ceiling),
                eligibleFullPixels=int(mask.sum()),affectedSsimWindows=int(affected.sum()),
                idealDirectReferenceCopySsim=float(ssim(test,b).mean(dtype='f8')))


def verify(data,payload):
    assert data['status']=='conditional-local-source-coverage-model' and data['gpuFilterCalibration']=='pending'
    assert set(data['controls'])==set(cases) and {k:digest(v) for k,v in payload.items()}==data['payloadSha256']
    for region in regions:
        old_area=None
        for case in cases:
            q=data['controls'][case][region]; x,y,X,Y=q['fullBounds']; shape=(Y-y,X-x)
            assert old_area is None or shape==old_area; old_area=shape
            img=lambda role:np.frombuffer(payload[f'{region}/{role}.rgb8'],'u1').reshape(*shape,3)
            n=shape[0]*shape[1]; raw=payload[f'{region}/{case}.mask']
            assert len(raw)==(n+7)//8 and q['pixels']==n
            bit=np.unpackbits(np.frombuffer(raw,'u1'),bitorder='little')
            assert not bit[n:].any(); mask=bit[:n].reshape(shape)!=0
            actual=metrics(img('baseline'),img('reference'),mask)
            for k,v in actual.items():
                assert abs(q[k]-v)<1e-6,(region,case,k,q[k],v)
    assert all(data['controls']['glyph'][k]['conditionalSsimCeiling']<.95 for k in regions)
    assert all(data['controls']['known-draws'][k]['idealDirectReferenceCopySsim']>=.95 for k in regions)


def main():
    cv2.setNumThreads(1)
    if sys.argv[1:]==['produce']:
        m=runpy.run_path(str(model),run_name='coverage_archival')
        C,shader,ds,p,foot=m['model']()
        payload={}
        controls={k:m['source_test'](C,ds,p,foot,coverage=True,oracle=None if k=='glyph' else k,artifacts=payload) for k in cases}
        payload[model.name]=model.read_bytes()
        payload[Path(__file__).name]=Path(__file__).read_bytes()
        result=dict(status='conditional-local-source-coverage-model',gpuFilterCalibration='pending',filterShader=shader,
            controls=controls,payloadSha256={k:digest(v) for k,v in sorted(payload.items())})
        verify(result,payload)
        dest.mkdir(exist_ok=True,parents=True)
        with ZipFile(dest/'validation.zip','w',ZIP_DEFLATED) as archive:
            for k,v in sorted(payload.items()):archive.writestr(k,v)
        result['archiveSha256']=digest((dest/'validation.zip').read_bytes())
        (dest/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    else:
        assert sys.argv[1:]==['verify']
        result=read(dest/'results.json')
        path=dest/'validation.zip'
        assert result['archiveSha256']==digest(path.read_bytes())
        with ZipFile(path) as archive:
            assert archive.testzip() is None and set(archive.namelist())==set(result['payloadSha256'])
            payload={k:archive.read(k) for k in archive.namelist()}
        verify(result,payload)
    print({a:{k:[v['eligibleFullPixels'],round(v['idealDirectReferenceCopySsim'],6),round(v['conditionalSsimCeiling'],6)]
             for k,v in d.items() if k in regions} for a,d in result['controls'].items()})


if __name__=='__main__':
    main()
