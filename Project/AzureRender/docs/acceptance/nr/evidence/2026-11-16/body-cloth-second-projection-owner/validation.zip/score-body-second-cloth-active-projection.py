from hashlib import sha256
from pathlib import Path
import json
import runpy
import numpy as np

m=Path(__file__).resolve().parent
probe=m/'retained-body-cloth-draw-slots'
read=lambda p:json.loads(p.read_bytes())
data=read(probe/'results.json')
assert data['secondShellEvents']==['851'] and data['events']['845']['slot']==2
p=data['events']['851']
assert p['slot']==21 and p['record']['params'][3]==2
assert p['record']['params']==data['events']['839']['record']['params']
assert p['pixelHistory']['(1211, 830)']==[{'primitive':19449,'rejected':True,'passed':False}]
assert all(t['rejected'] for t in p['pixelHistory']['(1197, 854)'])
h=lambda p:sha256(p.read_bytes()).hexdigest()
a,b=probe/'e851-clip.bin',probe/'e851-index.bin'
assert h(a)==p['clipSha256'] and h(b)==p['indexSha256']
v=np.fromfile(a,'<f4').reshape(-1,4)
i=np.fromfile(b,'<u'+str(p['indexStride'])).reshape(-1,3)
assert len(v)==p['vertexCount'] and i.size==p['numIndices']
converter=lambda c:(c[:,:2]/c[:,3,None]+np.float32(1))*np.array([1280,720],np.float32)
a=np.column_stack((converter(v),v[:,3]))[i]
scope=runpy.run_path(str(m/'score-native-player-cloth-vertex-output-overlap.py'))
native,_=scope['extract']('1116',False)
sites=[(1197,854),(1211,830)]
vulkan=scope['covered'](a,sites)
d3d=scope['covered'](native,sites)
result={}
for q in sites:
    result[str(q)]=dict(actualPlayerCandidates=vulkan[q],nativeCandidates=d3d[q],
         actualPlayerFragmentTests=p['pixelHistory'][str(q)],
         nearestCorners=[dict(nativeTriangle=j,**scope['near_triangle'](native[j],a)) for j in d3d[q]])
    print(q,result[str(q)]['actualPlayerCandidates'],result[str(q)]['nativeCandidates'],
          [round(r['maximumXYDisplacement'],5) for r in result[str(q)]['nearestCorners']])
(m/'body-second-cloth-active-projection-comparison.json').write_text(json.dumps(
    dict(status='measured-second-cloth-projection-at-color-draw',source=h(probe/'results.json'),
      secondOpaqueBaseEvent=845,secondClothProjectionEvent=851,sourceSlot=21,results=result),
      indent=2)+'\n',encoding='utf8')
