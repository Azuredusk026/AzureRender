"""Read the vertex projection records bound at the retained cloth draws."""
from hashlib import sha256
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import traceback

KEY='AZR_NR_CLOTH_BOUND_PROJECTION'
M=Path(os.environ[KEY]).parents[1] if KEY in os.environ else Path(__file__).resolve().parent
O=M/'retained-body-cloth-draw-slots'
G=M.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
read=lambda p: json.loads(p.read_bytes())
write=lambda p,v: p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
hash_bytes=lambda data:sha256(data).hexdigest()


def worker():
    import renderdoc as rd

    job=Path(os.environ[KEY])
    cfg=read(job)
    result=dict(status='failed',request=hash_bytes(job.read_bytes()),events={})
    cap=rd.OpenCaptureFile()
    ctl=None
    try:
        assert cap.OpenFile(cfg['capture'],'',None)==rd.ResultCode.Succeeded
        options=rd.ReplayOptions()
        options.forceGPUVendor=rd.GPUVendor.nVidia
        options.forceGPUDeviceID=0x28e0
        status,ctl=cap.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and ctl
        info=ctl.GetAPIProperties()
        assert info.pipelineType==rd.GraphicsAPI.Vulkan and info.vendor==rd.GPUVendor.nVidia and not info.degraded
        stage=rd.ShaderStage.Vertex
        def walk(rows):
            for row in rows:
                yield row
                yield from walk(row.children)

        actions={str(row.eventId):row for row in walk(ctl.GetRootActions())}
        for event,action in actions.items():
            count=action.numIndices
            if count not in (102927,61923) or not action.flags&rd.ActionFlags.Drawcall:
                continue
            ctl.SetFrameEvent(action.eventId,True)
            pipe=ctl.GetPipelineState()
            targets=pipe.GetOutputTargets()
            if not targets or str(targets[0].resource)!='ResourceId::175':
                continue
            draw=ctl.GetVulkanPipelineState()
            push=bytes(draw.pushconsts)
            shader=pipe.GetShaderReflection(stage)
            fragment=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
            if shader is None or fragment is None:
                continue
            slot=struct.unpack_from('<I',push,124)[0]>>1
            bindings=shader.readWriteResources
            bound=pipe.GetReadWriteResources(stage)
            storage=[v.descriptor for v in bound if bindings[v.access.index].fixedBindNumber==30]
            packed=None
            if storage:
                b,=storage
                record=bytes(ctl.GetBufferData(b.resource,b.byteOffset+16+slot*64,64))
                packed=dict(params=struct.unpack_from('<4f',record),color=struct.unpack_from('<4f',record,48),
                            dataResource=str(b.resource),geometry=struct.unpack_from('<4I',record,16))
            result['events'][event]=dict(slot=slot,vertex=hash_bytes(bytes(shader.rawBytes)),
                fragment=hash_bytes(bytes(fragment.rawBytes)),numIndices=count,indexOffset=action.indexOffset,
                push=push.hex(),record=packed,depth=dict(test=getattr(draw.depthStencil,'depthTestEnable',None),
                     write=getattr(draw.depthStencil,'depthWriteEnable',None),operation=str(getattr(draw.depthStencil,'depthCompareOp',None))))
            write(O/'results.json',result)
        assert result['events']['839']['slot']==20 and result['events']['845']['slot']==2
        result['secondShellEvents']=[e for e,v in result['events'].items() if v['slot']==21]
        for e in result['secondShellEvents']:
            action=actions[e]
            ctl.SetFrameEvent(action.eventId,True)
            pipe=ctl.GetPipelineState()
            post=ctl.GetPostVSData(0,0,rd.MeshDataStage.VSOut)
            assert post.numIndices==61923 and post.vertexByteStride>=16 and post.indexByteStride in (2,4)
            v=bytes(ctl.GetBufferData(post.vertexResourceId,post.vertexByteOffset,0))
            i=bytes(ctl.GetBufferData(post.indexResourceId,post.indexByteOffset,post.numIndices*post.indexByteStride))
            assert len(v)%post.vertexByteStride==0
            clip=b''.join(v[k:k+16] for k in range(0,len(v),post.vertexByteStride))
            row=result['events'][e]
            row.update(vertexCount=len(clip)//16,indexStride=post.indexByteStride,
                       clipSha256=hash_bytes(clip),indexSha256=hash_bytes(i))
            (O/f'e{e}-clip.bin').write_bytes(clip)
            (O/f'e{e}-index.bin').write_bytes(i)
            result['events'][e]['pixelHistory']={}
            target=pipe.GetOutputTargets()[0].resource
            for x,y in ((1197,854),(1211,830)):
                h=ctl.PixelHistory(target,x,y,rd.Subresource(),rd.CompType.Typeless)
                records=[dict(primitive=a.primitiveID,rejected=a.depthTestFailed,passed=not any(getattr(a,k,False) for k in ('depthTestFailed','stencilTestFailed','backfaceCulled','shaderDiscarded','scissorClipped','sampleMasked'))) for a in h if a.eventId==action.eventId]
                result['events'][e]['pixelHistory'][str((x,y))]=records
        result['status']='measured-bound-cloth-projection-records'
    except BaseException:
        result['error']=traceback.format_exc()
    finally:
        write(O/'results.json',result)
        if ctl:
            ctl.Shutdown()
        cap.Shutdown()
    os._exit(int(result['status']=='failed'))


def run():
    from hashlib import file_digest

    sys.path.insert(0,str(M.parents[2]/'tools'))
    from artifact_budget import check
    import runpy
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    budget=check(M.parents[1],run=M,planned=14_000_000)
    if not budget['allowed']:
        runpy.run_path(str(M/'compact-verified-iris-capture-frames.py'))['run']('compact')
    assert check(M.parents[1],run=M,planned=900_000)['allowed']
    prior=read(M/'retained-body-cloth-actual-vertex-outputs/results.json')
    assert prior['status']=='retained-body-cloth-actual-vertex-outputs'
    cap=Path(prior['request']['capture'])
    with cap.open('rb') as stream:
        assert file_digest(stream,'sha256').hexdigest()==prior['request']['captureSha256']
    vertex=prior['vertexOutputs']
    assert vertex['839']['shader']==vertex['845']['shader']
    overlap=read(M/'body-cloth-actual-vertex-overlap.json')
    events={v['playerEvent']:sorted(set(p for s in v['samples'] for p in
            [*s['playerCandidates'],*(q['playerTriangle'] for q in s['closest'])]))
            for v in overlap['cases'].values()}
    assert all(events.values())
    O.mkdir(exist_ok=True)
    job=O/'request.json'
    write(job,dict(capture=str(cap),captureSha256=prior['request']['captureSha256'],shader=vertex['839']['shader'],events=events))
    env=dict(os.environ,**{KEY:str(job),'VK_DRIVER_FILES':str(G/'nv-vk64-active-absolute.json')})
    startup=subprocess.STARTUPINFO()
    startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=0
    with (O/'replay.log').open('wb') as log:
        p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=O,env=env,startupinfo=startup,stdout=log,stderr=subprocess.STDOUT,timeout=385)
    result=read(O/'results.json')
    assert p.returncode==0 and result['status']=='measured-bound-cloth-projection-records',result
    assert result['request']==hash_bytes(job.read_bytes())
    for event,row in result['events'].items():
        print(event,row['slot'],row['numIndices'],row['record'],row.get('pixelHistory'))


if KEY in os.environ:
    worker()
elif __name__=='__main__':
    run()





