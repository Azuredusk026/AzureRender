"""Retain the calibrated dual-adapter native hair and body attachment checks."""
from hashlib import sha256
import io
import json
from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED

run = Path(__file__).resolve().parent
work = run.parents[2]
body = run.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
root = work/'docs/acceptance/nr/evidence/2026-11-16'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: sha256(p.read_bytes()).hexdigest()


def archive(name, result, members):
    folder = root/name
    folder.mkdir(parents=True,exist_ok=True)
    memory = io.BytesIO()
    members = {**members, Path(__file__).name:Path(__file__)}
    with ZipFile(memory,'w') as zipped:
        for label,path in sorted(members.items()):
            zi = ZipInfo(label,(2026,11,16,0,0,0))
            zi.compress_type = ZIP_DEFLATED
            zipped.writestr(zi,path.read_bytes())
    blob = memory.getvalue()
    with ZipFile(io.BytesIO(blob)) as zipped:
        assert zipped.testzip() is None
        for label,path in members.items():
            assert sha256(zipped.read(label)).hexdigest()==sha(path)
    (folder/'validation.zip').write_bytes(blob)
    result['archive'] = dict(sha256=sha256(blob).hexdigest(),bytes=len(blob),
                             members={k:sha(v) for k,v in members.items()})
    (folder/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(name,result['archive']['sha256'])


hair = body/'hair-native-owner-hardware-light-comparison.json'
stages = read(hair)
qualified = ('nvidia','intel')
assert stages['status']=='qualified-native-ownership' and len(stages['points'])==5
members = {hair.name:hair, 'hair-native-owner-control.py':body/'hair-native-owner-control.py'}
first_source_mismatch = {}
for row in stages['points']:
    assert row['primitive'][0] == row['primitive'][1]
    sample_inputs = ('base','layer','normal','alpha')
    changed = lambda values: values[0]!=values[1]
    if any(changed(row['packedLanes'][k]) for k in sample_inputs):
        state = 'sample-inputs'
    elif changed(row['lightingLanes']['striped-diffuse']):
        assert not changed(row['lightingLanes']['pre-stripe-diffuse'])
        state = 'striped-diffuse'
    elif changed(row['lightingLanes']['post-light-loop']):
        assert all(not changed(row['lightingLanes'][k]) for k in
                   ('pre-stripe-diffuse','striped-diffuse','main-specular','continued-diffuse'))
        state = 'post-light-loop'
    else:
        assert all(not changed(x) for x in row['lightingLanes'].values())
        state = 'exact-control'
    first_source_mismatch[','.join(map(str,row['point']))] = state
assert sorted(first_source_mismatch.values()) == ['exact-control','post-light-loop','sample-inputs','sample-inputs','striped-diffuse']
for device in qualified:
    folder = body/f'hair-native-owner-hardware-light-{device}'
    receipt = read(folder/'results.json')
    assert receipt['status']=='qualified' and receipt['hardwareLanes']['copy']['sameAsFinalAttachment']
    assert set(receipt['bindings']) == {'16','17','18'}
    for k in ('post-light-loop','before-environment'):
        marker = receipt['hardwareLanes'][k]['markerCheck']
        assert marker['packed']==[marker['expected']]*5 and marker['expected']==1880752896
    members.update({f'{device}/{name}':folder/name for name in ('request.json','results.json')})
archive('native-hair-lighting-lanes',dict(frame=10401,event=950,firstMeasuredDifferences=first_source_mismatch,
             scope='Native hardware attachment controls; complete hair color remains a separate gate',
             **stages),members)

normal = run/'body-native-normal-raw-samples'
analysis = run/'body-native-normal-raw-samples-analysis.json'
receipt, score = read(normal/'results.json'), read(analysis)
assert receipt['status'] == 'qualified'
assert score['status'] == 'measured-native-normal-input-differences'
assert (score['qualified'],score['heldOut']) == (8827,3793)
for device in qualified:
    d = receipt['devices'][device]
    assert d['baselineRestored'] and d['textureFormat']=='BC5_UNORM'
    assert len(score['devices'][device]['mips'])==11
    implicit = score['devices'][device]['packingFromExactImplicit']
    assert implicit['withinOne']==8827 and implicit['heldOutWithinOne']==3793 and implicit['worst']==1
assert score['nativeDeviceDifference']['implicit']['overOneUnorm16'] == 7526
assert score['nativeDeviceDifference']['10']['exact'] == 8827
selected = {name:run/name for name in ('body-native-normal-raw-samples.py','score-body-native-normal-raw-samples.py',
                                      analysis.name)}
selected['readback/results.json'] = normal/'results.json'
archive('native-body-normal-raw-samples',dict(event=328,result=score,
        hardwareReadbackSha256=sha(normal/'results.json')),selected)

iris = run/'iris-matcap-differential-player/earlyProjectiveCoarse'
score = read(iris/'results.json')
assert score['stage']=='covered' and score['scope']==255
assert score['preflight']==sha(iris/'preflight.json')
expected = dict(nvidia=([22,21],[15,12]),intel=([30,29],[27,27]))
members = {k:iris/k for k in ('preflight.json','results.json','bare-results.json')}
for device in qualified:
    result = score['devices'][device]['true']
    assert (result['overOne'],result['peak'])==expected[device]
    assert result['newOverOne']==result['outsideIrisChanged']==0
    captured = iris/f'{device}-covered'
    assert result['frame']==read(captured/'draw-receipt.json')['frame']==sha(captured/'frames/frame_000000.png')
    members.update({f'{device}/{name}':captured/name for name in
                    ('draw-receipt.json','frames/gpu_capabilities.json','frames/capture_manifest.json','player.log')})
archive('iris-projective-covered',dict(validation='qualified paired experiment',fullIrisAccepted=False,
        admissibleMaximumByteDifference=1,**score),members)
