"""Compare CPU bilinear filtering of authored pixels against native hardware lanes."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import struct

import numpy as np
from PIL import Image

M=Path(__file__).resolve().parent
G=M.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
P=M.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
read=lambda path:json.loads(path.read_bytes())
digest=lambda b:sha256(b).hexdigest()
f=G/'iris-explicit-mips'
mat=read(R/'eye-native-public-nvidia-projected/face-iris-public-main-frame.azurematerial')
s=mat['surface']
idx=s['materials'][0]['pbrMetallicRoughness']['baseColorTexture']['index']
handle=s['textures'][idx]['source']
asset=mat['textures'][str(handle)]['asset']
file=G/'iris-overlay-geometry-project/materials'/(asset+'.dds')
bc=file.read_bytes()
width,height=struct.unpack_from('<II',bc,12)
dxgi,=struct.unpack_from('<I',bc,128)
assert (width,height,dxgi)==(512,512,99)


def load_layers():
    offset=148
    out=[]
    for level in range(10):
        n=max(1,width>>level)
        length=((n+3)//4)**2*16
        data=bc[offset:offset+length]
        if level in (4,5):
            assert data==(P/f'iris-projected-native-t13-mip{level}.bin').read_bytes()
        header=(124,0x81007,n,n,length,0,0,*([0]*11),32,4,int.from_bytes(b'DX10','little'),0,0,0,0,0,0x1000,0,0,0,0,99,3,0,1,0)
        a=np.asarray(Image.open(BytesIO(struct.pack('<4s36I',b'DDS ',*header)+data)).convert('RGBA')).astype(float)/255
        assert a.shape==(n,n,4)
        a[:,:,:3]=np.where(a[:,:,:3]<=.04045,a[:,:,:3]/12.92,((a[:,:,:3]+.055)/1.055)**2.4)
        out.append(a)
        offset+=length
    assert offset==len(bc)
    return out


def mip_candidates():
    q=read(f/'iris-explicit-mips.json')
    args=read(M/'iris-native-matcap-d3d-vulkan-owned-levels.json')
    p=G/'native-iris-stages/points.bin'
    points=np.frombuffer(p.read_bytes(),'<u4').reshape(-1,2).tolist()
    assert points==args['points']
    result={}
    for dev,c in q['devices'].items():
        source=(f/f'{dev}-implicit.bin').read_bytes()
        assert digest(source)==c['implicitSha256']
        b=np.frombuffer(source,'<u4')
        lanes=[]
        for level in range(10):
            data=(f/f'{dev}-mip-{level:02d}.bin').read_bytes()
            assert digest(data)==c['mips'][str(level)]['sha256']
            lanes.append(np.frombuffer(data,'<u4')==b)
        result[dev]=np.asarray(lanes).T
    return points,result


def samples(layers,uv,level):
    region=layers[level]
    n=len(region)
    q=np.asarray(uv)*n-.5
    base=np.floor(q).astype(int)
    frac=q-base
    x,y=base
    taps=np.array([region[i%n,j%n] for i,j in ((y,x),(y,x+1),(y+1,x),(y+1,x+1))])
    def sample(fx,fy):
        return taps.T@np.array([(1-fx)*(1-fy),fx*(1-fy),(1-fx)*fy,fx*fy])
    m={'float':sample(*frac)}
    for bits in (6,7,8,9,10,11,12):
        for rounding,name in ((np.floor,'floor'),(np.round,'nearest')):
            sc=2**bits
            m[f'{name}{bits}']=sample(*(rounding(frac*sc)/sc))
    return dict(fraction=frac.tolist(),indices=base.tolist(),taps=taps.tolist(),predictions={k:v.tolist() for k,v in m.items()})


def main():
    points,mips=mip_candidates()
    layers=load_layers()
    out={}
    for dev in ('nvidia','intel'):
        src=M/('iris-packing-boundary-native-intel' if dev=='intel' else 'iris-packing-boundary-native')/'results.json'
        q=read(src)
        assert q['status']=='qualified-native-iris-packing-boundary'
        rows=[]
        for r in q['rows']:
            p=r['point']
            coords=r['states']['62']['r4'][2:]
            observed=r['states']['63']['r9']
            levels=np.flatnonzero(mips[dev][points.index(p)])
            report={}
            expected=np.asarray(observed)
            partial=[]
            for i in levels:
                a=samples(layers,coords,int(i))
                report[str(i)]=a
                for k,v in a['predictions'].items():
                    x=np.asarray(v)
                    rounded=np.array(x); rounded[:3]=rounded[:3].astype('f2').astype('f8')
                    partial.extend((dict(level=int(i),metric=k,fp16=False,err=float(abs(x[:3]-expected[:3]).max())),
                                    dict(level=int(i),metric=k,fp16=True,err=float(abs(rounded[:3]-expected[:3]).max()))))
            partial.sort(key=lambda a:a['err'])
            rows.append(dict(point=p,uv=coords,observed=observed,perLevel=report,ranked=partial,levels=levels.tolist()))
            print(dev,p,levels.tolist(),partial[:2])
        out[dev]=dict(source=digest(src.read_bytes()),rows=rows)
    (M/'iris-native-filter-precision-model.json').write_text(json.dumps(dict(source=digest(bc),comparison=out),indent=2)+'\n',encoding='utf8')


if __name__=='__main__':
    main()
