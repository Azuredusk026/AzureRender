"""Archive the exact dual-adapter outcome for the isolated 32-step floor experiment."""
from hashlib import file_digest,sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo
run=Path(__file__).resolve().parent
W=run.parents[2]
exp=run/'projected-reflection-32-step-candidate'
archive=W/'docs/acceptance/nr/evidence/2026-11-16/projected-floor-ray-budget-player'
read=lambda p:json.loads(p.read_bytes())
def sha(p):
    with p.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()

def verify():
    primary=exp/'results.json'
    pair=read(primary)
    assert pair['status']=='qualified-measurement'
    assert set(pair['devices'])=={'nvidia','intel'} and pair['source']['candidateMaximumSteps']==32
    assert pair['source']['baselineSteps']==128
    main_p=exp/'candidate-receipt.json'
    main=read(main_p)
    assert (main['provenance'],main['program'])==(pair['source'],pair['program'])
    assert main['program']['binary']!=main['program']['control']==main['provenance']['baselineShader']
    artifacts={'results.json':primary,'candidate-receipt.json':main_p,Path(__file__).name:Path(__file__)}
    artifacts['candidate.patch']=exp/'candidate.patch'
    artifacts['measurement.py']=run/'projected-reflection-32-step-candidate.py'
    regions=('centerFloor','cyanRing')
    interesting={}
    for device,data in pair['devices'].items():
        interesting[device]={}
        assert len(data['frames'])==3 and data['baseline']['driver']==data['candidate']['driver']
        for mode in ('baseline','candidate'):
            item=data[mode]
            folder=exp/(mode+'-'+device)
            manifest=folder/'frames/capture_manifest.json'
            assert sha(manifest)==item['captureManifest'] and sha(folder/'runtime.json')==item['runtime']
            assert item['images']==[sha(folder/f'frames/frame_{i:06d}.png') for i in range(3)]
            assert item['shader']==main['program']['control' if mode=='baseline' else 'binary']
            for name in ('frames/capture_manifest.json','frames/gpu_capabilities.json','result.json'):
                artifacts[f'{mode}-{device}/{name}']=folder/name
            interesting[device][mode]={r:dict(ssim=[x[r][mode]['ssim'] for x in data['frames']],
                                               luma=[x[r][mode]['medianLumaRelativeError'] for x in data['frames']])
                                        for r in regions}
    d=pair['verdict']
    assert len(d['frames'])==6 and d['frozenOriginalFourRequired']
    prequalified=all(d[k] for k in ('allPairsPositive','allFormalFloorGates','noIntroducedNeighborErrors',
                                    'noNetIncreaseInFloorErrors'))
    return {**pair, 'regionalEligibilityForFrozenTest':prequalified,
            'formalAcceptance':'requires-original-frozen-four' if prequalified else 'failed-regional-qualification',
            'floorMetrics':interesting},artifacts

def write():
    report,items=verify()
    archive.mkdir(parents=True,exist_ok=True)
    p=archive/'validation.zip'
    with ZipFile(p,'w') as f:
        for name,file in sorted(items.items()):
            i=ZipInfo(name,(2026,11,16,0,0,0));i.compress_type=ZIP_DEFLATED
            f.writestr(i,file.read_bytes())
    with ZipFile(p) as f:
        assert f.testzip() is None
        assert all(sha256(f.read(k)).hexdigest()==sha(v) for k,v in items.items())
    report['archive']=dict(sha256=sha(p),members={k:sha(v) for k,v in items.items()})
    (archive/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print(json.dumps(dict(status=report['formalAcceptance'], floor=report['floorMetrics'], zip=report['archive']['sha256'])))

if __name__=='__main__':
    write()
