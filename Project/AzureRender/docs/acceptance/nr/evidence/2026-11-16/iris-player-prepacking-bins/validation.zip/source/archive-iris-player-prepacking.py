"""Record bounded GPU evidence for the residual RGB error before packing."""
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
from zipfile import ZIP_DEFLATED, ZipFile

M=Path(__file__).resolve().parent
src=M/'iris-player-prepacking-bins'
native=M/'iris-packing-boundary-native'
out=M.parents[2]/'docs/acceptance/nr/evidence/2026-11-16'/src.name
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
q=read(src/'results.json')
n=read(native/'results.json')
assert n['status']=='qualified-native-iris-packing-boundary'
assert q['status']=='measured-player-prepacking-bins'
assert q['programArchive']==digest(src/'programs.zip')
assert n['request']==digest(native/'request.json')
assert sha256((src/'mesh.frag').read_bytes()).hexdigest()==q['source']
conn=sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True)
receipt=[]
for i in (1461,1462,1463):
    row=conn.execute('select task,state,exit_code,run_seconds from jobs where id=?',(i,)).fetchone()
    assert row[1]==('failed' if i==1461 else 'succeeded')
    receipt.append(dict(id=i,task=row[0],state=row[1],exitCode=row[2],elapsedSeconds=row[3]))
files={'native/request.json':native/'request.json','native/results.json':native/'results.json','player/results.json':src/'results.json'}
for dev,v in q['probes'].items():
    assert v['exactOutside'] and v['pixels']==digest(src/f'{dev}-probe-pixels.npz')
    assert len(v['rows'])==4
    assert not read(src/f'{dev}-probe/runtime.json')['presentationErrors']
    files[f'player/{dev}-pixels.npz']=src/f'{dev}-probe-pixels.npz'
    for name in ('frames/capture_manifest.json','frames/gpu_capabilities.json','command.json','runtime.json'):
        files[f'player/{dev}/{name}']=src/f'{dev}-probe'/name
for name in ('iris-packing-boundary-native.py','iris-player-prepacking-bins.py','archive-iris-player-prepacking.py','run-with-stage-log.py'):
    files[f'source/{name}']=M/name
for name in ('iris-packing-boundary-native','iris-packing-boundary-native-retest','iris-player-prepacking-bins'):
    files[f'logs/{name}.log']=M/f'retest-{name}.log'
assert len(q['probes'])==2
witnesses={}
for dev,xy,i in [('nvidia',[1308,266],2),('intel',[1255,258],1),('intel',[1261,262],0)]:
    row,=[r for r in q['probes'][dev]['rows'] if r['point']==xy]
    interval,=row['possibleRawIntervals'][i]
    v=row['native'][i]
    assert interval[0]>v or interval[1]<v
    witnesses[dev+':'+str(xy)]=dict(point=xy,channel='RGB'[i],native=v,inferredRawPlayer=interval,
         delta=[x-v for x in interval],bareDisplay=row['bareDisplay'][i],truncatedDisplay=row['packedDisplay'][i])
assert .390625==witnesses['nvidia:[1308, 266]']['inferredRawPlayer'][1]
out.mkdir(parents=True,exist_ok=True)
z=out/'validation.zip'
with ZipFile(z,'w',ZIP_DEFLATED,compresslevel=9) as archive:
    for k,v in files.items():
        archive.write(v,k)
with ZipFile(z) as archive:
    proof={name:sha256(archive.read(name)).hexdigest() for name in files}
    assert archive.testzip() is None and proof=={k:digest(v) for k,v in files.items()}
record=dict(status='probed-two-device-iris-color-before-packing',strictAcceptance=False,embeddedPythonLaunchRetest=True,
    rawScale=.25, scope='Diagnostic range inferred from observed marker and both matched beauty outputs; empty intervals are unresolved.',
    channelWitnesses=witnesses, deviceProbes=q['probes'], nativeShader=read(native/'request.json')['pixelShaderSha256'],
    player=q['player'], programs=q['programs'], shaderSource=q['source'],queue=receipt, validation=dict(archive=digest(z),files=proof))
(out/'qualification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(z.stat().st_size,[(k,r['delta']) for k,r in witnesses.items()])
