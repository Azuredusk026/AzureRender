"""Read only the native iris shader stages at three registered residuals."""
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import traceback

key = 'AZURE_NR_IRIS_PACKING_BOUNDARY'
root = Path(os.environ[key]).parent if key in os.environ else Path(__file__).resolve().parent
folder = root/'iris-packing-boundary-native'
read = lambda p: json.loads(Path(p).read_bytes())
write = lambda p,v: Path(p).write_text(json.dumps(v, indent=2, allow_nan=False)+'\n', encoding='utf8')
coord = Path('D:/Projects/FYP-coordination')
points = [[1308,266],[1255,258],[1261,262]]
control = [1260,262]
milestones = {61,62,63,760,761,762,764,765,766,767,768,769,770,1108,1109,1189,1193,1198,1199,1203}


def plan():
    q = read(root.parents[2]/'docs/acceptance/nr/evidence/2026-11-16/iris-unsigned-output-precision/qualification.json')
    s = read(root/'iris-native-matcap-d3d-vulkan-owned-levels.json')
    assert all(p in s['points'] for p in points+[control])
    assert any(r['point']==points[0] and r['before']==[0,0,0] and r['after']==[0,0,-2]
               for r in q['devices']['nvidia']['onlyChanged'])
    assert [row[:2] for row in q['displayBinControl']['intel']['retainedImpossiblePoints']]==points[1:]
    src = read(root/'trace-iris-matcap-request.json')
    return dict(capture=src['capture'], captureSha256=src['captureSha256'], pixelShaderSha256=src['pixelShaderSha256'],
                points=points+[control], event=846)


def digest(path):
    from hashlib import file_digest
    with Path(path).open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def worker():
    import renderdoc as rd
    import hashlib
    write(folder/'progress.json', dict(status='opened-embedded-python'))
    req = read(folder/'request.json')
    capture = rd.OpenCaptureFile()
    ctl = None
    result = dict(status='failed', request=hashlib.sha256((folder/'request.json').read_bytes()).hexdigest(), rows=[])
    try:
        assert capture.OpenFile(req['capture'], '', None)==rd.ResultCode.Succeeded
        opts = rd.ReplayOptions()
        opts.forceGPUVendor = rd.GPUVendor.nVidia
        opts.forceGPUDeviceID = 0x28e0
        status, ctl = capture.OpenCapture(opts, None)
        assert status==rd.ResultCode.Succeeded and ctl
        api = ctl.GetAPIProperties()
        assert api.pipelineType==rd.GraphicsAPI.D3D11 and api.vendor==rd.GPUVendor.nVidia and not api.degraded
        result['api'] = str(api.pipelineType)
        result['vendor'] = str(api.vendor)
        event = req['event']
        ctl.SetFrameEvent(event, True)
        pipe = ctl.GetPipelineState()
        pixel = pipe.GetShaderReflection(rd.ShaderStage.Fragment)
        assert hashlib.sha256(bytes(pixel.rawBytes)).hexdigest()==req['pixelShaderSha256']
        target = pipe.GetOutputTargets()[0].resource
        result['resource'] = str(target)
        for x,y in req['points']:
            write(folder/'progress.json', dict(point=[x,y], count=len(result['rows'])))
            ctl.SetFrameEvent(event, True)
            history = [a for a in ctl.PixelHistory(target, x, 1439-y, rd.Subresource(), rd.CompType.Typeless)
                       if a.eventId==event and not (a.depthTestFailed or a.stencilTestFailed or a.backfaceCulled or a.shaderDiscarded)]
            assert history, (x,y)
            hit = history[-1]
            inputs = rd.DebugPixelInputs()
            inputs.primitive = hit.primitiveID
            ctl.SetFrameEvent(event, True)
            trace = ctl.DebugPixel(x, 1439-y, inputs)
            assert trace and trace.debugger, (x,y)
            state, states, count = {}, {}, 0
            try:
                while True:
                    block = ctl.ContinueDebug(trace.debugger)
                    if not block:
                        break
                    for step in block:
                        count += 1
                        pc = int(step.nextInstruction)
                        for item in step.changes:
                            after = item.after
                            if after.name:
                                state[after.name] = [v if math.isfinite(v) else None for v in list(after.value.f32v)[:4]]
                        if pc in milestones:
                            states[str(pc)] = dict(state)
                    assert count < 20000
            finally:
                ctl.FreeTrace(trace)
            assert {'62','1199'} <= states.keys()
            result['rows'].append(dict(point=[x,y], primitive=int(hit.primitiveID), states=states,
                eventOutput=list(hit.shaderOut.col.floatValue)[:3], eventComposite=list(hit.postMod.col.floatValue)[:3],
                instructionCount=count))
        result['status'] = 'qualified-native-iris-packing-boundary'
    except BaseException:
        result['error'] = traceback.format_exc()
    finally:
        write(folder/'results.json', result)
        if ctl:
            ctl.Shutdown()
        capture.Shutdown()
    os._exit(0 if result['status'].startswith('qualified') else 1)


def launch():
    req = plan()
    lease = read(coord/'resources/current.json')
    assert lease['state']=='held' and Path(lease['output'])==root
    sys.path.insert(0, str(root.parents[2]/'tools'))
    from artifact_budget import check
    assert check(root.parents[1], run=root, planned=850_000)['allowed']
    assert digest(req['capture'])==req['captureSha256']
    folder.mkdir(exist_ok=True)
    q = folder/'request.json'
    write(q, req)
    setup = subprocess.STARTUPINFO()
    setup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    setup.wShowWindow = 0
    with (folder/'replay.log').open('wb') as log:
        result = subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=folder, env=dict(os.environ, **{key:str(folder)}), startupinfo=setup, stdout=log,
            stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, timeout=135)
    r = read(folder/'results.json')
    assert result.returncode==0 and r['status'].startswith('qualified') and r['request']==digest(q), r.get('error')
    print([(row['point'], row['primitive'], row['states']['1199']['o0'][:3], row['eventComposite']) for row in r['rows']])


if key in os.environ:
    worker()
elif __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(plan())
    else:
        launch()
