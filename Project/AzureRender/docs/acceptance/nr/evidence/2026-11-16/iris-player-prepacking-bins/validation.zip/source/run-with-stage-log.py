import pathlib, subprocess, sys
run=pathlib.Path(__file__).resolve().parent
name, script, *args=sys.argv[1:]
assert name.replace('-', '').isalnum() and '/' not in script and '\\' not in script
logfile=run / ('retest-' + name + '.log')
with logfile.open('wb') as log:
    result = subprocess.run([sys.executable, str(run / script), *args], stdout=log, stderr=subprocess.STDOUT)
print(logfile.read_text(encoding='utf-8', errors='replace'))
sys.exit(result.returncode)
