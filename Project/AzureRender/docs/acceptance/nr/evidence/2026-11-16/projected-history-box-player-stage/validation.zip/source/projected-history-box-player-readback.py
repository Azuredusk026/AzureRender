"""Cross-check actual Player opacity-snapshot inputs at the five registered native box pixels."""
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import traceback

KEY='AZR_QA_BOX_SNAPSHOT_PAIR'
M=Path(os.environ[KEY]).resolve().parents[1] if KEY in os.environ else Path(__file__).resolve().parent
O=M/'projected-history-box-player-readback'
read=lambda p:json.loads(Path(p).read_bytes())
write=lambda p,d:Path(p).write_text(json.dumps(d,indent=2,allow_nan=False)+'\n',encoding='utf-8')
digest=lambda p:sha256(Path(p).read_bytes()).hexdigest()


def compressed(rgb):
    return [max(0.,v/(1.+max(rgb[:3]))) for v in rgb[:3]]


def oct_normal(encoded,fold):
    a,b=[2*v-1 for v in encoded]
    c=1-abs(a)-abs(b)
    if c<0:
        a,b=math.copysign(1-abs(b),a),math.copysign(1-abs(a),b)
    xyz=[a,b,c] if fold=='z' else [-a,c,b]
    length=math.sqrt(sum(x*x for x in xyz))
    return [x/length for x in xyz]


def request():
    prior=M/'projected-history-player-lineage'
    source=M/'projected-history-box-native-readback/results.json'
    paired=read(source)
    assert paired['status']=='qualified-registered-crate-native-gbuffer'
    proof=read(prior/'checkpoint.json')
    assert proof['status']=='qualified-current-snapshot-source'
    manifest=read(prior/'request.json')
    selected=[]
    for label,draw in paired['draws'].items():
        slots=draw['gbufferByOutputSlot']
        for i,p in enumerate(draw['points']):
            qp=p['source']
            assert qp['event']==int(label) and qp['unrestrictedNativeEightPixelBestRgb']>.02
            assert len(qp['nativeUV'])==len(qp['playerUV'])==2
            assert qp['maxPlaneDistanceMeters']<=.005 and max(abs(x-y) for x,y in zip(qp['nativeUV'],qp['playerUV']))<=.002
            normal,base=(slots[str(slot)]['after'][i] for slot in (3,4))
            selected.append(dict(known=qp,nativeGbufferNormal=normal,nativeGbufferBase=base,
                nativeEarlier=p['actualNativePrior'],nativeCurrentStages=p['nativeCurrentHdrStages']))
    assert len(selected)==len({tuple(p['known']['previousPixelXY']) for p in selected})==5
    return dict(history=proof,capture=manifest['capture'],traceShader=manifest['shader'],selected=selected,
                nativeSource=digest(source),playerSource=digest(prior/'checkpoint.json'))


def worker(p):
    import renderdoc as rd
    req=read(p)
    result=dict(status='unqualified',request=digest(p))
    cap=rd.OpenCaptureFile()
    ctl=None
    try:
        write(O/'progress.json',dict(stage='open-file'))
        assert cap.OpenFile(req['capture'],'',None)==rd.ResultCode.Succeeded
        write(O/'progress.json',dict(stage='open-replay'))
        status,ctl=cap.OpenCapture(rd.ReplayOptions(),None)
        assert status==rd.ResultCode.Succeeded and str(ctl.GetAPIProperties().pipelineType)=='GraphicsAPI.Vulkan'
        r=req['history']
        write(O/'progress.json',dict(stage='trace',event=r['traceEvent']))
        ctl.SetFrameEvent(r['traceEvent'],True)
        stage=rd.ShaderStage.Compute
        pipe=ctl.GetPipelineState()
        sh=pipe.GetShaderReflection(stage)
        assert sha256(bytes(sh.rawBytes)).hexdigest()==req['traceShader']
        look=lambda cc,s: {sh.readOnlyResources[x.access.index].fixedBindNumber:x.descriptor.resource
                      for x in cc.GetReadOnlyResources(s)}
        bindings=look(pipe,stage)
        assert str(bindings[2])==r['priorColorResource']
        t={str(x.resourceId):x for x in ctl.GetTextures()}
        ids=[r['priorColorResource'],r['currentColorResource'],r['currentSurfaceResource']]
        tex=[t[key] for key in ids]
        assert [(x.width,x.height,x.format.Name()) for x in tex]==[
          (2560,1440,'R16G16B16A16_FLOAT'),(2560,1440,'R16G16B16A16_FLOAT'),(2560,1440,'R32G32B32A32_FLOAT')]
        def colors(resource,points):
            return [list(ctl.PickPixel(resource.resourceId,x,y,rd.Subresource(),rd.CompType.Typeless).floatValue)
                    for x,y in points]
        points=[tuple(x['known']['previousPixelXY']) for x in req['selected']]
        write(O/'progress.json',dict(stage='read-pixels',points=points))
        old,current,surface=[colors(x,points) for x in tex]
        ctl.SetFrameEvent(r['currentColorLastSurfaceWriter']['event'],True)
        pipe=ctl.GetPipelineState()
        targets=[str(x.resource) for x in pipe.GetOutputTargets()]
        assert targets[:2]==ids[1:]
        assert colors(tex[1],points)==current and colors(tex[2],points)==surface
        tol=1e-6
        weights=(.2126,.7152,.0722)
        delta=lambda a,b:sum(w*(x-y) for w,x,y in zip(weights,compressed(a),compressed(b)))
        records=[]
        for q,ph,pc,ps in zip(req['selected'],old,current,surface):
            assert all(abs(x-y)<=tol for x,y in zip(compressed(ph),q['known']['compressedPlayer']))
            nn=oct_normal(q['nativeGbufferNormal'][:2],'y')
            pp=oct_normal(ps[1:3],'z')
            dot=max(-1,min(1,sum(x*y for x,y in zip(nn,pp))))
            assert len(ps)==4 and all(math.isfinite(x) for x in ps)
            native=q['nativeEarlier']
            nshade=q['nativeCurrentStages']['9002']
            records.append(dict(**q,playerEarlier=ph,playerCurrent=pc,playerSurface=ps,
                currentNormalAngleDegrees=math.degrees(math.acos(dot)),playerNormal=pp,nativeNormalMirroredX=nn,
                rawPerceptualRoughnessDifference=ps[3]-q['nativeGbufferNormal'][2],
                previousCompressedLumaDifference=delta(ph,native),
                currentComparedWithNativeFirstShading=delta(pc,nshade),
                withinPlayerCurrentMinusPrevious=delta(pc,ph),
                withinNativeFirstShadingMinusPrevious=delta(nshade,native)))
        result.update(status='qualified-player-crate-current-snapshot',events=dict(trace=r['traceEvent'],
                      snapshot=r['currentColorLastSurfaceWriter']['event']),resources=ids,points=records,
                      scope='Current-frame normals are same-coordinate observations. Prior-frame surface matching was independently qualified; this readback does not assert current-frame material ownership.')
    except BaseException:result['error']=traceback.format_exc()
    finally:
        write(O/'results.json',result)
        if ctl is not None:ctl.Shutdown()
        cap.Shutdown()
    os._exit(0 if result['status'].startswith('qualified') else 1)


def run():
    lock=read('D:/Projects/FYP-coordination/resources/current.json')
    assert lock['state']=='held' and Path(lock['output'])==M
    sys.path.insert(0,str(M.parents[2]/'tools'))
    from artifact_budget import check
    assert check(M.parents[1],run=M,planned=440_000)['allowed']
    O.mkdir(exist_ok=True)
    p=O/'request.json'
    write(p,request())
    info=subprocess.STARTUPINFO()
    info.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    info.wShowWindow=0
    with (O/'replay.log').open('wb') as log:
        res=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=O,env=dict(os.environ,**{KEY:str(p)}),stdout=log,stderr=subprocess.STDOUT,startupinfo=info,timeout=200)
    q=read(O/'results.json')
    assert res.returncode==0 and q['status'].startswith('qualified') and q['request']==digest(p),q
    print(json.dumps([{k:x[k] for k in ('currentNormalAngleDegrees','rawPerceptualRoughnessDifference',
        'previousCompressedLumaDifference','currentComparedWithNativeFirstShading',
        'withinPlayerCurrentMinusPrevious','withinNativeFirstShadingMinusPrevious')} for x in q['points']]),flush=True)


if KEY in os.environ:
    worker(os.environ[KEY])
elif __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print([x['known']['previousPixelXY'] for x in request()['selected']])
        assert oct_normal([.5,.5],'z')==[0,0,1] and oct_normal([.5,.5],'y')==[0,1,0]
    else:run()

