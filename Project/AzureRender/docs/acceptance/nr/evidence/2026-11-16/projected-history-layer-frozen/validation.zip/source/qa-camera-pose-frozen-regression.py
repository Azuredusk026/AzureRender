"""Verify a camera-enabled runtime preserves the unmodified frozen four captures."""
from pathlib import Path
from contextlib import contextmanager, nullcontext
import runpy
import subprocess
import sys

import numpy as np
from PIL import Image

run = Path(__file__).resolve().parent
suite = runpy.run_path(str(run / 'character-six-view-inputs.py'))
read, digest, write = (suite[k] for k in ('read', 'digest', 'write'))
grid, body, release, camera_build = (suite[k] for k in ('grid', 'body', 'release', 'camera_build'))
invoke = suite['helpers']['invoke']
original = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c'
                '/snapshot-shell-order-regression/release-joint/frames')
retained = body / 'frozen-face-compat/frames'
combined=sys.argv[1:]==['combined-player']
out = run / ('projected-history-layer-frozen-regression' if combined else 'qa-camera-pose-frozen-regression')

lease = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lease['state'] == 'held' and Path(lease['output']) == run
candidate=run/'projected-history-layer-release' if combined else camera_build
receipt = read(candidate / 'link-receipt.json')
player = candidate / 'AzurePlayer.exe'
assert receipt['commandLineTests'] == 'passed' and digest(player) == receipt['newPlayer']
assert digest(release / 'AzurePlayer.exe') == receipt['oldPlayer']
expected_retained = read(retained.parent / 'results.json')['actual']
expected_original = [row['expectedSha256'] for row in read(grid / 'default-four-results.json')['frames']]
assert len(expected_retained) == len(expected_original) == 4
plan = read(grid / 'default-four-command.json')
plan[0] = str(player)
for flag, value in (('--resource-root', release), ('--capture-dir', out / 'frames'),
                    ('--runtime-report', out / 'runtime.json')):
    plan[plan.index(flag) + 1] = str(value)
assert '--qa-camera-pose' not in plan
if out.exists():
    assert not (out / 'results.json').is_file()
    out.rename(out.with_name(out.name + '-interrupted-' + str(len(list(run.glob(out.name + '-interrupted-*'))) + 1)))
out.mkdir()
if combined:
    sys.path.insert(0,str(run.parents[2]/'tools'))
    from artifact_budget import check
    import artifact_maintenance
    assert check(run.parents[1],run=run,planned=20_000_000)['allowed']
    fixture=runpy.run_path(str(run/'projected-reflection-radiance-layer-fixture.py'),run_name='programs_for_no_layer_regression')
    @contextmanager
    def while_replaying():
        b=run.parents[1]
        with artifact_maintenance.database(b) as c:
            records=artifact_maintenance.rows(c)
        source=records[body.name]
        assert source['status']=='closed' and body.name in artifact_maintenance.protected_names(records)
        assert (body/'.finished').is_file() and not source.get('processPid')
        artifact_maintenance.resume(b,body.name)
        try:
            with fixture['programs']() as actual:
                yield actual
        finally:
            subprocess.run([sys.executable,str(run.parents[2]/'tools/artifact_cleanup.py'),'--finish',str(body)],
                           timeout=90,check=True)
        with artifact_maintenance.database(b) as c:
            restored=artifact_maintenance.rows(c)[body.name]
        assert restored['status']=='closed' and restored['manifestSha256']==source['manifestSha256']
    published=while_replaying()
else:
    published=nullcontext((player,release,{}))
with published as (exe,resources,shader_hashes):
    assert (exe,resources)==(player,release)
    frames = invoke('nvidia', plan, out)
caps = read(frames / 'gpu_capabilities.json')
retained_caps = read(retained / 'gpu_capabilities.json')
assert (caps['vendor_id'], caps['device_id'], caps['driver_version']) == (
    retained_caps['vendor_id'], retained_caps['device_id'], retained_caps['driver_version'])
for name in ('qaCameraPosition', 'qaCameraTarget', 'cameraLens', 'gradeSettings', 'width', 'height',
             'screenReflectionAlgorithm', 'capturedFrames'):
    assert read(frames / 'capture_manifest.json')[name] == read(retained / 'capture_manifest.json')[name], name

def difference(a, b):
    with Image.open(a) as first, Image.open(b) as second:
        d = abs(np.asarray(first.convert('RGB'), dtype=np.int16) - np.asarray(second.convert('RGB'), dtype=np.int16)).max(2)
    return dict(differingPixels=int((d > 0).sum()), overOne=int((d > 1).sum()), peak=int(d.max()))

rows = []
for i, path in enumerate(sorted(frames.glob('frame_*.png'))):
    same, historical = retained / path.name, original / path.name
    assert digest(same) == expected_retained[i] and digest(historical) == expected_original[i]
    rows.append(dict(frame=path.name, sha256=digest(path), sameDriver=difference(path, same),
                     originalFrozen=difference(path, historical)))
assert len(rows) == 4
report = dict(player=receipt['newPlayer'], retainedPlayer=receipt['oldPlayer'], currentDriver=caps['driver_version'],
              programs=shader_hashes,
              sameDriverExact=all(r['sameDriver']['peak'] == 0 for r in rows),
              originalFrozenExact=all(r['originalFrozen']['peak'] == 0 for r in rows), frames=rows)
write(out / 'results.json', report)
assert report['sameDriverExact'], report
