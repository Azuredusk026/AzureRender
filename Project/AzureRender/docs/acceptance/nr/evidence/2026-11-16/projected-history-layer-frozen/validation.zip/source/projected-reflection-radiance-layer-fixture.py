"""Prepare a conditional Player fixture for explicitly submitted transparent history color."""
import base64
import copy
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import struct
import runpy
import tempfile
import sys

import numpy as np
from PIL import Image

root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parents[2]/'tools'))
import test_screen_space_reflections_gpu as lab
from test_unlit_texture_layers_gpu import profile, png_uri

base=np.array([.09,.13,.18])
red=np.array([.76,.06,.02])
blue=np.array([.05,.11,.70])
alpha_red=.25
alpha_blue=.375
mix=lambda bg,rgb,a:bg*(1-a)+rgb*a
one=mix(base,red,alpha_red)
two=mix(one,blue,alpha_blue)
three=mix(two,np.array([.05,.65,.04]),.5)
policy='projected-history'
fit=lambda v: list(map(float,v))
cases={
    'base':(base,[]),
    'oracle-one':(one,[]),
    'oracle-two':(two,[]),
    'regular-one':(base,[(red,alpha_red,.004,'transparent')]),
    'history-one':(base,[(red,alpha_red,.004,policy)]),
    'history-two':(base,[(red,alpha_red,.004,policy),(blue,alpha_blue,.008,policy)]),
    'history-ordinary-in-front':(base,[(red,alpha_red,.004,policy),(blue,alpha_blue,.008,policy),
                         (np.array([.05,.65,.04]),.5,.012,'transparent')]),
    'history-occluded':(base,[(red,alpha_red,-.012,policy)]),
    'history-zero':(base,[(red,0.,.004,policy)]),
}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())


def authored(folder,name):
    main,layers=cases[name]
    project,expected=lab.prepare(folder,dict(name=name,algorithm='projected',frames=2))
    target=project.parent/'assets/target.gltf'
    m=json.loads(target.read_bytes())
    orig=copy.deepcopy(m['meshes'][0]['primitives'][0])
    def material(rgb):
        return dict(doubleSided=False,pbrMetallicRoughness=dict(baseColorFactor=[*fit(rgb),1.]),
            extras=dict(azureRenderMaterial=dict(schemaVersion=2,**{'class':'generic'},
               features=['unlit-surface'],surface=dict(schemaVersion=1,lighting='unlit'))))
    m['materials']=[material(main)]
    if layers:
        raw=bytearray(base64.b64decode(m['buffers'][0]['uri'].split(',')[1]))
        def access(data,t,n):
            raw.extend(b'\0'*(-len(raw)%4))
            offset=len(raw);raw.extend(data)
            m['bufferViews'].append(dict(buffer=0,byteOffset=offset,byteLength=len(data)))
            m['accessors'].append(dict(bufferView=len(m['bufferViews'])-1,componentType=5126,count=n,type=t))
            return len(m['accessors'])-1
        uv=access(struct.pack('<8f',*(.5,)*8),'VEC2',4)
        pos=struct.unpack_from('<12f',raw)
        for rgb,a,z,submission in layers:
            layer=profile()
            layer.update(tint=[*fit(rgb),a],blendTint=[0,0,0,0],composite='alpha',depthCompare='less-or-equal',
                         submission=submission,softIntersection=dict(enabled=False,distance=1,bias=0),
                         highlightExpansion=dict(threshold=1,gain=0))
            m['materials'].append(dict(alphaMode='BLEND',doubleSided=False,extras=dict(azureRenderMaterial=dict(
               schemaVersion=2,**{'class':'generic'},features=['unlit-surface','unlit-texture-layers'],surface=layer))))
            xyz=list(pos)
            xyz[2::3]=[z]*4
            ip=access(struct.pack('<12f',*xyz),'VEC3',4)
            m['accessors'][ip].update(min=np.array(xyz).reshape(4,3).min(0).tolist(),
                                       max=np.array(xyz).reshape(4,3).max(0).tolist())
            primitive=copy.deepcopy(orig)
            primitive['attributes'].update(POSITION=ip,TEXCOORD_0=uv)
            primitive['material']=len(m['materials'])-1
            m['meshes'][0]['primitives'].append(primitive)
        m['buffers'][0]=dict(byteLength=len(raw),uri='data:application/octet-stream;base64,'+base64.b64encode(raw).decode())
        m['images']=[dict(uri=png_uri(np.full((1,1,4),255,dtype=np.uint8)))]
        m['textures']=[dict(source=0)]
    lab.write_json(target,m)
    return project,expected


def preflight(folder):
    lab.self_test()
    outputs={}
    models={}
    for name in cases:
        p, o=authored(folder/name,name)
        models[name]=json.loads((p.parent/'assets/target.gltf').read_bytes())
        assert np.count_nonzero(lab.polygon_mask(o['reflectionPolygon'],.7))>12
        outputs[name]={q.relative_to(p.parent).as_posix():sha(q) for q in sorted(p.parent.rglob('*')) if q.is_file()}
    pt=lambda g,i:g['materials'][i]['extras']['azureRenderMaterial']['surface']
    regular,marked=models['regular-one'],models['history-one']
    assert pt(regular,1)['submission']=='transparent' and pt(marked,1)['submission']==policy
    pt(regular,1)['submission']=policy
    assert regular==marked
    hist=pt(models['history-ordinary-in-front'],3)
    assert hist['submission']=='transparent'
    np.testing.assert_allclose(one,[.2575,.1125,.14],rtol=0,atol=1e-14)
    np.testing.assert_allclose(two,[.1796875,.1115625,.35],rtol=0,atol=1e-14)
    assert np.linalg.norm(two-mix(mix(base,blue,alpha_blue),red,alpha_red))>.08
    assert len({o['assets/target.gltf'] for o in outputs.values()})==len(cases)
    return dict(status='fixture-inputs-preflight-only',surfacePolicyProposal=policy,
        oracle=dict(base=fit(base),one=fit(one),two=fit(two),withOrdinarySheet=fit(three)),inputs=outputs,
        capturePlan=dict(controls='Reflection first submission equals base; marked second submission matches opaque color oracle; ordinary, occluded and zero-alpha variants retain base throughout.',
            composed='Marked two-layer variant retains ordered alpha. Ordinary front sheet changes beauty according to its alpha and leaves reflected color equal to the marked two-layer case.',
            rejection='The baseline Player must reject the unknown submitted-history policy at material parsing. A parser-only implementation must still fail the positive reflection comparison.'))
@contextmanager
def programs():
    body=root.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
    catalog=runpy.run_path(str(body/'face-quality-candidate-catalog.py'))
    release=catalog['baseline']
    shaders=catalog['catalog']
    candidate=root/'projected-history-layer-release'
    installed=candidate/'programs'
    receipt=read(candidate/'link-receipt.json')
    player=candidate/'AzurePlayer.exe'
    assert sha(player)==receipt['newPlayer'] and sha(release/'AzurePlayer.exe')==receipt['oldPlayer']
    expected=catalog['retained_catalog'](body)
    published=receipt['programs']
    trace='projected_reflection_trace.comp.spv'
    extras=set(published)-{trace}
    assert extras=={'character_projected_history.frag.spv','character_projected_history_bindless.frag.spv'}
    for key in published:assert sha(installed/key)==published[key]
    # Recover a prior interrupted publication by removing only our verified program links.
    for key in sorted(extras):
        dest=shaders/key
        if dest.exists():
            assert dest.samefile(installed/key) and sha(dest)==published[key]
            dest.unlink()
    with catalog['activate']({trace:published[trace]},alternate_run=root,source_dir=installed):
        try:
            for key in sorted(extras):(shaders/key).hardlink_to(installed/key)
            yield player,release,published
        finally:
            for key in sorted(extras):
                dest=shaders/key
                if dest.exists():
                    assert dest.samefile(installed/key) and sha(dest)==published[key]
                    dest.unlink()
    assert {p.name:sha(p) for p in shaders.glob('*.spv')}==expected


def run_fixture(device):
    assert device in ('nvidia','intel')
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==root
    from artifact_budget import check
    case_bytes=1_000_000 # Two 320x240 RGB8 frames, small project and validation receipts.
    allocation=check(root.parents[1],run=root,planned=case_bytes)
    assert allocation['allowed'],allocation
    out=root/'projected-history-layer-player-fixture'/device
    out.mkdir(exist_ok=True,parents=True)
    group=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
    invoke=runpy.run_path(str(group/'iris-production-frozen-recovery.py'))['invoke']
    images,records={},{}
    masks=None
    with programs() as (player,release,published):
        for name in cases:
            folder=out/name
            checkpoint=folder/'result.json'
            if not checkpoint.is_file():
                allocation=check(root.parents[1],run=root,planned=case_bytes)
                assert allocation['allowed'],allocation
                if folder.exists():
                    n=len(list(out.glob(name+'-interrupted-*')))+1
                    folder.rename(out/f'{name}-interrupted-{n}')
                project,oracle=authored(folder,name)
                target=project.parent/'assets/target.gltf'
                fingerprint=sha(target)
                cmd=[str(player),'--project',str(project),'--resource-root',str(release),'--width',str(lab.WIDTH),
                     '--height',str(lab.HEIGHT),'--capture-dir',str(folder/'frames'),'--capture-frames','2',
                     '--capture-fps','4','--fixed-frame-step','--qa-camera','scene','--qa-light','scene',
                     '--qa-isolation','beauty','--runtime-report',str(folder/'runtime.json')]
                if device=='intel':cmd+=['--disable-bindless','--disable-compute-skinning','--disable-parallel-recording']
                print(device,name,'rendering',flush=True)
                frames=invoke(device,cmd,folder)
                assert sha(target)==fingerprint
                manifest=read(frames/'capture_manifest.json')
                runtime=read(folder/'runtime.json')
                assert not runtime['scriptErrors'] and not runtime['presentationErrors']
                assert manifest['screenReflectionProducer']=='projected-history',manifest['screenReflectionProducer']
                assert manifest['screenReflectionHistoryValid'] and manifest['screenReflectionHistoryInputSubmission']>=1
                assert manifest['screenReflectionTemporalPreparation']=='projected-temporal'
                lab.write_json(checkpoint,dict(command=cmd,player=sha(player),programs=published,input=fingerprint,
                    output={q.name:sha(q) for q in sorted(frames.glob('frame_*.png'))},
                    manifest=sha(frames/'capture_manifest.json')))
            report=read(checkpoint)
            assert report['player']==sha(player) and report['programs']==published
            assert len(report['output'])==2 and report['manifest']==sha(folder/'frames/capture_manifest.json')
            assert report['input']==sha(folder/'assets/target.gltf')
            images[name]=[]
            for filename,fingerprint in report['output'].items():
                image=folder/'frames'/filename
                assert sha(image)==fingerprint
                with Image.open(image) as f:images[name].append(np.asarray(f.convert('RGB')).astype(np.int16))
            records[name]=report
            oracle=lab.oracle(lab.LEFT)
            masks=dict(reflection=lab.polygon_mask(oracle['reflectionPolygon'],.7),source=lab.polygon_mask(oracle['sourcePolygon'],.6))

    region=masks['reflection']
    rows={}
    def require(case,other,label,frame,mask,limit=0):
        d=abs(images[case][frame]-images[other][frame])[mask]
        rows[label]=dict(peak=int(d.max()),pixels=int((d.max(axis=1)>limit).sum()),mean=float(d.mean()),limit=limit)
    for name in ('regular-one','history-one','history-two','history-ordinary-in-front','history-occluded','history-zero'):
        require(name,'base',name+'-first-reflection',0,region)
    for name in ('regular-one','history-occluded','history-zero'):
        require(name,'base',name+'-second-reflection',1,region)
    for name,oracle in (('history-one','oracle-one'),('history-two','oracle-two')):
        require(name,oracle,name+'-second-oracle',1,region,lab.BUDGETS['maximumCompatibilityByteError'])
    require('history-ordinary-in-front','history-two','ordinary-front-second-reflection',1,region)
    require('history-one','regular-one','opt-in-only-source-beauty',1,masks['source'])
    source=abs(images['history-ordinary-in-front'][1]-images['history-two'][1])[masks['source']]
    difference={k:int((abs(images[k][1]-images['base'][1]).max(axis=-1)[region]>2).sum()) for k in ('history-one','history-two')}
    lab.write_json(out/'results.json',dict(status='passed' if (all(not row['pixels'] for row in rows.values())
        and min(difference.values())>=12 and source.max()>2) else 'failed',checks=rows,reflectionChangedOver2=difference,
        ordinarySourceMax=int(source.max()),records=records))
    print(device,rows,difference,int(source.max()),flush=True)
    assert all(not row['pixels'] for row in rows.values()),rows
    assert min(difference.values())>=12 and source.max()>2


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        with tempfile.TemporaryDirectory(prefix='azr-projected-history-layer-') as t:
            out=preflight(Path(t))
        report=root/'projected-history-coordinates/history-radiance-layer-fixture-preflight.json'
        report.write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
        print(out['status'],len(out['inputs']),out['oracle'])
    else:
        assert len(sys.argv)==3 and sys.argv[1]=='run'
        run_fixture(sys.argv[2])
