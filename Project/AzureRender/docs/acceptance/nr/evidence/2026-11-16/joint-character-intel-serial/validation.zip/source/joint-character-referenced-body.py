"""Pair the dynamic body in the full scene using verified external glTF buffer ranges."""
from contextlib import contextmanager
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import struct
import subprocess
import sys
from urllib.parse import quote, unquote
from zipfile import ZIP_DEFLATED, ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
OUT=M/'joint-character-referenced-body'
cams=runpy.run_path(str(M/'character-six-view-inputs.py'),run_name='joint_body_cameras')
build=runpy.run_path(str(M/'build-animated-body-topology-candidate.py'),run_name='joint_body_asset')
_, project, level, scene, actor=cams['source_inputs']()
source=M/'character-six-view-inputs'
player=M/'projected-history-layer-release/AzurePlayerCaptureResource.exe'
proof=M/'immutable-scene-capture-source/qualification.json'
read,write,sha=[cams[k] for k in ('read','write','digest')]
assert player.is_file() and sha(player)==read(proof)['candidatePlayer']
assert actor.name=='hero-idle-loop-v2.glb'
original_hash='b1f9d78053c0e36c966502847c0a90688307a3d98808db93ff8465a620e6e883'
candidate_hash='7775d3c775a5446211850f9193460b58b478e419a6ee3d76fd78b3b2ab5de24b'
env_keys=('AZR_NR_QA_RESOURCE_ID','AZR_NR_QA_RESOURCE_PATH')


def parse(binary):
    magic, version, total, json_size, kind=struct.unpack_from('<5I',binary)
    chunk, bin_kind=struct.unpack_from('<2I',binary,20+json_size)
    start=28+json_size
    assert (magic,version,total,kind,bin_kind)==(0x46546c67,2,len(binary),0x4e4f534a,0x4e4942)
    assert chunk==len(binary)-start and start%4==0
    return json.loads(binary[20:20+json_size]),memoryview(binary)[start:],start


def inputs():
    original=actor.read_bytes()
    assert sha256(original).hexdigest()==original_hash
    root_model, old_data, offset=parse(original)
    assert root_model==build['model'] and old_data==memoryview(build['program'])
    assert len(root_model['buffers'])==1
    rebuilt,receipt=build['serialize'](True,True)
    assert sha256(rebuilt).hexdigest()==receipt['serializedSha256']==candidate_hash
    candidate, data, _=parse(rebuilt)
    assert data[:len(old_data)]==old_data
    assert all(v==candidate[key] for key,v in root_model.items() if key not in {'accessors','bufferViews','buffers','meshes'})
    return original,root_model,candidate,data,old_data,offset,receipt


def rebase(model,data,original,prefix,outdir,offset):
    file=outdir/'hero.gltf'
    def reference(absolute):
        uri=quote(Path(os.path.relpath(absolute,outdir)).as_posix(),safe='/.-_')
        assert (outdir/unquote(uri)).resolve()==absolute.resolve()
        return uri
    shifted=json.loads(json.dumps(model))
    shifted['buffers']=[{'byteLength':len(original),'uri':reference(actor)}]
    images={}
    for original_image,image in zip(model['images'],shifted['images'],strict=True):
        original_uri=original_image.get('uri','')
        if not original_uri or original_uri.startswith('data:'):
            continue
        absolute=(actor.parent/unquote(original_uri)).resolve(strict=True)
        assert absolute.is_relative_to(actor.parent.resolve()) and absolute.is_file()
        new=reference(absolute)
        assert unquote(new)==new
        image['uri']=new
        images[original_uri]=[str(absolute),sha(absolute)]
        meta=absolute.with_name(absolute.name+'.azmeta')
        if meta.is_file():
            assert (outdir/(new+'.azmeta')).resolve()==meta
            images[original_uri].append(sha(meta))
    appended=data[prefix:]
    if appended:
        shifted['buffers'].append({'byteLength':len(appended),'uri':'body.bin'})
    ranges=[]
    for candidate,view in zip(model['bufferViews'],shifted['bufferViews'],strict=True):
        begin,end=candidate.get('byteOffset',0),candidate.get('byteOffset',0)+candidate['byteLength']
        assert candidate.get('buffer',0)==0 and 0<=begin<end<=len(data)
        if end<=prefix:
            view['buffer'],view['byteOffset']=0,begin+offset
            actual=memoryview(original)[begin+offset:end+offset]
        else:
            assert begin>=prefix
            view['buffer'],view['byteOffset']=1,begin-prefix
            actual=appended[begin-prefix:end-prefix]
        assert data[begin:end]==actual
        ranges.append(sha256(actual).hexdigest())
    return file,shifted,appended,ranges,images


def prepare():
    original,base,candidate,data,old,offset,receipt=inputs()
    base_asset=rebase(base,old,original,len(old),OUT/'identity',offset)
    candidate_asset=rebase(candidate,data,original,len(old),OUT/'native',offset)
    assert base_asset[3]==candidate_asset[3][:len(base_asset[3])] and base_asset[4]==candidate_asset[4]
    assert len(candidate_asset[2])<300_000 and len(base_asset[2])==0
    core={'originalActor':original_hash,'expandedCandidate':candidate_hash,
          'project':sha(project),'level':sha(level),'player':sha(player),'images':base_asset[4],
          'references':{},'developmentScope':'full scene single frame at retained camera'}
    for name,(path,desc,extra,ranges,_) in [('identity',base_asset),('native',candidate_asset)]:
        core['references'][name]={'path':str(path),'referencedViews':len(ranges),'rangeDigest':sha256(''.join(ranges).encode()).hexdigest(),'newBytes':len(extra)}
    return core,(base_asset,candidate_asset),receipt


@contextmanager
def temporary_descriptor(asset):
    path,desc,extra,_,_=asset
    path.parent.mkdir(parents=True,exist_ok=True)
    assert path.parent.resolve().parent==OUT.resolve() and not path.parent.is_symlink()
    payload={path:json.dumps(desc,ensure_ascii=False,separators=(',',':')).encode('utf8')}
    if extra:
        payload[path.with_name('body.bin')]=bytes(extra)
    assert all(not f.exists() for f in payload)
    archive=OUT/f'{path.parent.name}-asset.zip'
    if not archive.is_file():
        with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=8) as z:
            for f,v in payload.items():
                z.writestr(f.name,v)
    with ZipFile(archive) as z:
        assert z.testzip() is None and all(z.read(f.name)==p for f,p in payload.items())
    for f,p in payload.items():
        f.write_bytes(p)
    try:
        yield path
    finally:
        for f,p in payload.items():
            assert f.resolve().parent==path.parent.resolve() and not f.is_symlink() and f.read_bytes()==p
            f.unlink()


def save_delta(frame,baseline,dev,mode):
    a,b=(cv2.imread(str(x),cv2.IMREAD_UNCHANGED) for x in (baseline,frame))
    assert a.shape==b.shape==(720,1280,4)
    diff=np.abs(a.astype(np.int16)-b.astype(np.int16)).max(axis=2)
    change=np.argwhere(diff>0)
    x0=y0=x1=y1=None
    if len(change):
        y0,x0=map(int,change.min(axis=0))
        y1,x1=map(int,change.max(axis=0))
    d=np.bitwise_xor(a,b)
    target=OUT/f'{dev}-{mode}.zip'
    with ZipFile(target,'w',ZIP_DEFLATED,compresslevel=8) as z:
        z.writestr('frame_000000.bgra-xor',d.tobytes())
    with ZipFile(target) as z:
        assert z.testzip() is None
        restored=np.bitwise_xor(a,np.frombuffer(z.read('frame_000000.bgra-xor'),dtype=np.uint8).reshape(a.shape))
        assert np.array_equal(restored,b)
    return dict(png=sha(frame),referencePng=sha(baseline),raw=sha256(b.tobytes()).hexdigest(),
                archive=sha(target),changed=int(len(change)),overOne=int((diff>1).sum()),peak=int(diff.max()),
                bounds=[x0,y0,x1,y1])


def capture(dev,mode,asset,flags=()):
    assert not any(k in os.environ for k in env_keys)
    prior=source/f'{dev}-back-detail'
    previous=read(prior/'result.json')
    ref=prior/'frames/frame_000000.png'
    assert sha(ref)==previous['sha256']
    d=OUT/f'{dev}-{mode}'
    d.mkdir()
    command=read(prior/'command.json')
    command[0]=str(player)
    assert command[command.index('--project')+1]==str(project)
    assert not any(flag in command for flag in flags)
    command.extend(flags)
    for flag,new in (('--capture-dir',d/'frames'),('--runtime-report',d/'runtime.json')):
        command[command.index(flag)+1]=str(new)
    if asset:
        os.environ.update(zip(env_keys,('hero',str(asset))))
    try:
        cams['helpers']['invoke'](dev,command,d)
    finally:
        for key in env_keys:
            os.environ.pop(key,None)
    log=(d/'player.log').read_text(encoding='utf8',errors='replace')
    if asset:
        assert 'Capture resource hero:' in log
    rt=read(d/'runtime.json')
    assert len(rt['animations'])==11 and not rt['presentationErrors'] and not rt['scriptErrors']
    manifest=read(d/'frames/capture_manifest.json')
    old=read(prior/'frames/capture_manifest.json')
    for key in ('width','height','capturedFrames','qaCameraPosition','qaCameraTarget','cameraLens','cameraUp'):
        assert manifest[key]==old[key],key
    caps=read(d/'frames/gpu_capabilities.json')
    expected=read(prior/'frames/gpu_capabilities.json')
    assert all(caps[k]==expected[k] for k in ('vendor_id','device_id','driver_version'))
    frame=d/'frames/frame_000000.png'
    record=save_delta(frame,ref,dev,mode)
    assert frame.resolve().parent==(d/'frames').resolve() and not frame.is_symlink() and sha(frame)==record['png']
    frame.unlink()
    write(d/'result.json',record)
    return record


def run(dev,repeat=False,serial=False):
    assert dev in ('nvidia','intel')
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    budget=check(W/'build',run=M,planned=4_500_000 if repeat else 5_200_000)
    assert budget['allowed'],budget
    core,assets,receipt=prepare()
    if serial:
        assert dev=='intel'
        measured=read(OUT/f'{dev}-qualification.json')
        assert measured['immutable']==core
        args=['--disable-parallel-recording']
        with temporary_descriptor(assets[1]) as path:
            a=capture(dev,'serial-a',path,args)
            b=capture(dev,'serial-b',path,args)
        write(OUT/'intel-serial-qualification.json',dict(
            first=a,repeat=b,identical=a['raw']==b['raw'],immutable=core,flags=args))
        assert sha(actor)==core['originalActor'] and sha(project)==core['project'] and sha(level)==core['level']
        print(dev,a['changed'],b['changed'],a['raw']==b['raw'])
        return
    if repeat:
        assert dev=='intel'
        measured=read(OUT/f'{dev}-qualification.json')
        assert measured['immutable']==core
        with temporary_descriptor(assets[1]) as path:
            again=capture(dev,'native-repeat',path)
        write(OUT/'intel-repeat-qualification.json',dict(
            prior=measured['candidate'],repeat=again,identical=measured['candidate']['raw']==again['raw'],immutable=core))
        assert sha(actor)==core['originalActor'] and sha(project)==core['project'] and sha(level)==core['level']
        print(dev,again['changed'],again['bounds'])
        return
    with temporary_descriptor(assets[0]) as path:
        exact=capture(dev,'identity',path)
    if exact['changed']:
        current=capture(dev,'original',None)
        assert current['raw']==exact['raw'],(current,exact)
    else:
        current=exact
    with temporary_descriptor(assets[1]) as path:
        variant=capture(dev,'native',path)
    assert variant['raw']!=current['raw']
    for p,k in [(project,'project'),(level,'level'),(actor,'originalActor')]:
        assert sha(p)==core[k]
    for row in core['images'].values():
        p,*fingerprints=row
        assert row[1]==sha(Path(p))
        if len(fingerprints)==2:
            assert fingerprints[-1]==sha(Path(p+'.azmeta'))
    write(OUT/f'{dev}-qualification.json',dict(status='rendered-referenced-native-body-full-scene',
        identity=exact,currentBaseline=current,candidate=variant,immutable=core,candidateGeometry=receipt,strictComparison=False))
    print(dev,exact['changed'],variant['changed'],variant['bounds'],flush=True)


if __name__=='__main__':
    sys.path.insert(0,str(W/'tools'))
    if sys.argv[1:]==['preflight']:
        result,_,_=prepare()
        result['images']=len(result['images'])
        print(result)
    elif sys.argv[1:]==['intel','repeat']:
        run('intel',repeat=True)
    elif sys.argv[1:]==['intel','serial']:
        run('intel',serial=True)
    elif len(sys.argv)==2:
        run(sys.argv[1])
