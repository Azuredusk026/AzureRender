from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
S=M/'body-native-skin-interior-stages'
O=M/'readonly-body-saturation-precision-all-programs'
N=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-cloth-reference.png')
E=W/'docs/acceptance/nr/evidence/2026-11-16/body-joint-saturation-precision'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
result=read(O/'qualification.json')
assert result['status']=='paired-full-frame-skin-captures' and not result['productionBodyAcceptance']
for key,val in result['changedPrograms'].items():
    assert digest(O/'programs'/key)==val
coords=np.fromfile(S/'points.bin','<u2').reshape(-1,2)
x,y=coords.T
mask=np.zeros((1440,2560),dtype=np.uint8)
mask[y,x]=1
distance=cv2.distanceTransform(mask,cv2.DIST_L2,5)[y,x]
outside_distance=cv2.distanceTransform(1-mask,cv2.DIST_L2,5)
native=cv2.imread(str(N),-1)[:,:,:3].astype(np.int16)
source=read(S/'results.json')
watch=[(1200,379),(1206,374),(1197,854),(1211,830)]
classifications={}
files={Path(__file__):Path(__file__).name,O/'mesh.frag':'mesh.frag',
       M/'readonly-body-saturation-precision-all-programs.py':'capture.py',
       M/'retest-body-saturation-active-programs-retry.log':'dispatch.log',S/'points.bin':'skin-points.bin'}
for d,tally in (('nvidia',(1583,2358,2819)),('intel',(2065,2461,2799))):
    name=d+'-native-tint'
    reference=R/f'face-quality-release-isolated-mask/public-combined-{d}/frames/frame_000000.png'
    sample=result['samples'][name]
    assert digest(reference)==sample['control']
    control=cv2.imread(str(reference),-1)
    archive=O/name/'frame-xor.zip'
    assert digest(archive)==sample['deltaArchive']
    with ZipFile(archive) as z:
        assert z.testzip() is None
        actual=control^np.frombuffer(z.read('frame.bgra-xor'),np.uint8).reshape(control.shape)
    assert sha256(actual.tobytes()).hexdigest()==sample['raw']
    original_error=np.abs(control[:,:,:3].astype(np.int16)-native).max(2)[y,x]
    current_error=np.abs(actual[:,:,:3].astype(np.int16)-native).max(2)[y,x]
    words={}
    for e,row in source['devices'][d]['frames'].items():
        path=S/row['file']
        assert digest(path)==row['croppedSha256']
        words[int(e)]=np.fromfile(path,'<u4')
        if e in ('783','1383'):
            files[path]=path.name
    later=words[783]!=words[1383]
    groups={}
    for k,area in [('OpaqueInterior',(distance>6)&~later),('OpaqueEdge',(distance<=6)&~later),('LaterNativeDraw',later)]:
        groups[k]=dict(pixels=int(np.count_nonzero(area)),baselineOverOne=int(np.count_nonzero(area&(original_error>1))),
                candidateOverOne=int(np.count_nonzero(area&(current_error>1))),
                newOverOne=int(np.count_nonzero(area&(original_error<=1)&(current_error>1))),peak=int(current_error[area].max()))
    assert tuple(v['candidateOverOne'] for v in groups.values())==tally
    assert sum(tally)==sample['skin']['overOne'] and sum(v['newOverOne'] for v in groups.values())==sample['skin']['newOverOne']
    outside=(mask==0)&np.any(actual[:,:,:3]!=control[:,:,:3],axis=2)
    assert np.count_nonzero(outside)==sample['skin']['outsideSkin']
    events=sorted(words)
    cases=[]
    for px,py in watch:
        i,=np.flatnonzero((x==px)&(y==py))
        draws=[a for b,a in zip(events,events[1:]) if words[a][i]!=words[b][i]]
        assert current_error[i]==original_error[i]
        cases.append(dict(point=[px,py],peak=int(current_error[i]),nativeDraws=draws,skinDistance=float(distance[i])))
    assert [p['nativeDraws'] for p in cases]==[[783,1079],[783,1079],[783],[783,1116]]
    classifications[d]=dict(groups=groups,furthestOutsideChangePixels=float(outside_distance[outside].max()),witnesses=cases)
    for sub in ('frame-xor.zip','frames/capture_manifest.json','runtime.json','command.json','player.log'):
        files[O/name/sub]=name+'/'+sub
E.mkdir()
archive=E/'validation.zip'
with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as z:
    for p,label in files.items():
        z.write(p,label)
with ZipFile(archive) as z:
    assert z.testzip() is None
result.update(nativeReference=digest(N),nativeStageSelection=digest(S/'results.json'),skinClassification=classifications,archiveSha256=digest(archive))
(E/'qualification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print({d:x['witnesses'] for d,x in classifications.items()})
