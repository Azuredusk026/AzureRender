"""Measure the opaque snapshot material owner at the varying wall pixels."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import runpy
import subprocess
import sys
from zipfile import ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
C=M/'joint-character-referenced-body'
O=M/'joint-intel-opaque-wall-owner-grayscale'
g=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='wall_owner_catalog')
H,R,B,art,check,read,write,sha=[g[k] for k in ('H','R','B','art','check','read','write','sha')]
body=runpy.run_path(str(M/'joint-character-referenced-body.py'),run_name='wall_owner_body')
g['activate_links'].__wrapped__.__globals__['home']=O
scene=tuple('mesh_object_clipmap_field'+suffix+'.frag.spv' for suffix in ('','_early','_lighting','_early_lighting'))
snap=tuple('character_snapshot'+obj+'_clipmap_field'+suffix+'.frag.spv'
           for obj in ('','_object') for suffix in ('','_early','_lighting','_early_lighting'))


def substitute(s,old,new):
    assert s.count(old)==1,old
    return s.replace(old,new)


def template():
    p=W/'shaders/mesh.frag'
    s=p.read_text(encoding='utf8')
    s=substitute(s,'''    vec3 qaColor = beautyColor;
    if (qaIsolationMode == 1) {''','''    vec3 qaColor = beautyColor;
#if !defined(AZURE_OPAQUE_SNAPSHOT)
    vec2 probe=AZURE_FRAGMENT_COORD.xy;
    if(qaIsolationMode==0 && camera.screenReflectionTrace.x>1.5 &&
       all(greaterThanEqual(probe,vec2(0))) && probe.x<480 && probe.y<72) {
        if(probe.x<288){
            uint lane=uint(floor(probe.x/96.));
            ivec2 source=ivec2(mod(probe.x,96.),probe.y)+ivec2(896,160);
            float markerAlpha=texelFetch(opaqueSceneColor,source,0).a;
            uint code=uint(max(floor(markerAlpha+.5),0.));
            uint digit=(code>>(4U*lane))&15U;
            qaColor=vec3(.045)+vec3(digit)*.028;
        }else{
            float digit=floor((probe.x-288)/12.);
            qaColor=vec3(.045+(.028*digit));
        }
    }
#endif
    if (qaIsolationMode == 1) {''')
    s=substitute(s,'''    if(AZURE_MATERIAL_CLASS==2U)outputColor.a=2.0;
    vec3 snapshotNormal=shadedNormal;''','''    if(AZURE_MATERIAL_CLASS==2U)outputColor.a=2.0;
    ivec2 source=ivec2(AZURE_FRAGMENT_COORD.xy);
    if(all(greaterThanEqual(source,ivec2(896,160)))&&all(lessThan(source,ivec2(992,232))))
        outputColor.a=float((material.materialPadding>>1U)+16U);
    vec3 snapshotNormal=shadedNormal;''')
    return p,s


def run():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    assert check(B,run=M,planned=11_000_000)['allowed']
    p,s=template()
    (O/'programs').mkdir(parents=True,exist_ok=True)
    modified=O/'mesh.frag'
    modified.write_text(s,encoding='utf8')
    rules={p['output']:p for p in read(R/'msaa-release/shader-reload.json')['programs']}
    programs={}
    for name in scene+snap:
        assert 'AZURE_PROBE_FIELD=1' in rules[name]['defines']
        H['compile_program'](modified,O/'programs'/name,name,diagnostics=O/'compile'/f'{name}.log')
        programs[name]=sha(O/'programs'/name)
    ref_path=M/'character-six-view-inputs/intel-back-detail/frames/frame_000000.png'
    ref=cv2.imread(str(ref_path),cv2.IMREAD_UNCHANGED)
    assert ref.shape==(720,1280,4)
    paired=W/'docs/acceptance/nr/evidence/2026-11-16/joint-intel-reflection-ground-paired-panels'
    q=read(paired/'qualification.json')
    assert sha(paired/'validation.zip')==q['archiveSha256']
    original=[]
    with ZipFile(paired/'validation.zip') as z:
        for tag in q['groundPair']:
            with ZipFile(BytesIO(z.read(f'{tag}/frame-xor.zip'))) as zz:
                actual=ref^np.frombuffer(zz.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
            assert sha256(actual.tobytes()).hexdigest()==q['reads'][tag]['frame']['raw']
            original.append(actual)
    relevant=np.any(original[0][:72,288:384]!=original[1][:72,288:384],axis=2)
    assert relevant.sum()==456
    core,assets,_=body['prepare']()
    assert core['player']==q['player']
    with art.database(B) as db:
        pinned=art.rows(db)[R.name]
    assert pinned['status']=='closed'
    images={}
    comparison={}
    ids={}
    art.resume(B,R.name)
    try:
        with g['activate_links'](programs),body['temporary_descriptor'](assets[1]) as descriptor:
            for label in ('a','b','c','d','e'):
                name=f'opaque-wall-owner-grayscale-{label}'
                row=body['capture']('intel',name,descriptor)
                path=C/f'intel-{name}'
                manifest=read(path/'frames/capture_manifest.json')
                assert manifest['qaIsolation']=='beauty' and manifest['screenReflectionProducer']=='linear-temporal'
                assert manifest['irradianceResourceKind']=='clipmap' and manifest['objectShadowPrepared']
                with ZipFile(C/f'intel-{name}.zip') as z:
                    frame=ref^np.frombuffer(z.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
                assert sha256(frame.tobytes()).hexdigest()==row['raw']
                legend=[]
                for i in range(16):
                    stripe=frame[:72,288+i*12:300+i*12,:3]
                    rgb,n=np.unique(stripe.reshape((-1,3)),axis=0,return_counts=True)
                    best=np.argmax(n)
                    assert n[best]>=200,(label,i,int(n[best]))
                    legend.append(rgb[best])
                legend=np.asarray(legend)
                assert all(len(np.unique(legend[:,channel]))==16 for channel in range(3)),legend
                valid=np.ones((72,96),bool)
                decoded=np.zeros((72,96),dtype=np.int16)
                for digit in range(3):
                    tile=frame[:72,digit*96:(digit+1)*96,:3].astype(np.int16)
                    bins=np.max(np.abs(tile[:,:,None,:]-legend[None,None,:,:]),axis=3)
                    nearest=bins.min(2)
                    valid&=(nearest<=1)&((bins==nearest[:,:,None]).sum(axis=2)==1)
                    decoded+=bins.argmin(axis=2).astype(np.int16)<<(4*digit)
                decoded[~valid]=-1
                verified=relevant&(decoded>=16)&(decoded<512)
                assert verified.sum()>200,(label,int(verified.sum()))
                candidates={int(k-16):int(v) for k,v in zip(*np.unique(decoded[verified],return_counts=True))}
                images[label]=frame
                ids[label]=decoded
                data=dict(outputs=row,matchedDisputedPixels=int(verified.sum()),globalMaterials=candidates)
                comparison[label]=data
                write(O/'witness.json',dict(status='capturing',results=comparison))
                print(label,candidates,flush=True)
                compare_pair=next((k for k in images if k!=label and not np.array_equal(
                    frame[160:232,896:992],images[k][160:232,896:992])),None)
                if compare_pair:
                    break
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=320)
    with art.database(B) as db:
        end=art.rows(db)[R.name]
    assert end['status']=='closed' and end['manifestSha256']==pinned['manifestSha256']
    stats=None
    if compare_pair:
        previous,current=[ids[k] for k in (compare_pair,label)]
        coverage=relevant&(previous>=16)&(current>=16)
        stats=dict(labels=[compare_pair,label],materialIdsChanged=int(np.count_nonzero(coverage&(previous!=current))),
                   pairedOwners=int(np.count_nonzero(coverage)),
                   upperBeautyChanged=int(np.count_nonzero(np.any(
                    images[compare_pair][160:232,896:992]!=images[label][160:232,896:992],axis=2))))
    d=dict(status='measured-opaque-wall-source-material-owner',sampleResults=comparison,paired=stats,
           shaderPrograms=programs,source=sha(p),modifiedSource=sha(modified))
    write(O/'qualification.json',d)


if __name__=='__main__':
    run()
