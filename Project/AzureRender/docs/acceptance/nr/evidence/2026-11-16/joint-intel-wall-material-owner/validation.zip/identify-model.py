from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import struct
from zipfile import ZipFile

m=Path(__file__).resolve().parent
q=m/'joint-character-referenced-body'
original='intel-ground-paired-panels-a'
p=Path(json.loads((q/original/'command.json').read_bytes())[2])
d=json.loads(p.read_bytes())
mounts={x['name']:p.parent/x['path'] for x in d['mounts']}
def file_for(ref):
    if ':/' in ref:
        a,b=ref.split(':/',1)
        return (mounts[a]/b).resolve()
    return registered[ref]
a,b=d['startupScene'].split(':/')
level=mounts[a]/b
stage=json.loads(level.read_bytes())
assert not any(j.get('prefabSource') for j in stage['nodes'])
wanted={r['asset'] for r in stage['resources'] if ':/' not in r['asset']}
registered={}
for mount in mounts.values():
    for meta in mount.rglob('*.azmeta'):
        obj=json.loads(meta.read_bytes())
        identifier=obj.get('id')
        if identifier in wanted:
            target=meta.with_suffix('').resolve()
            assert identifier not in registered or registered[identifier]==target
            registered[identifier]=target
assert set(registered)==wanted,(len(registered),len(wanted))
hero_pack=q/'native-asset.zip'
with ZipFile(hero_pack) as z:
    assert z.testzip() is None
    hero_model=json.loads(z.read('hero.gltf'))
base=[]
for row in stage['resources']:
    k=row['id']
    path=file_for(row['asset'])
    if k=='hero':
        path=q/'native/hero.gltf'
    base.append((k,path,()))
lookup={k:path for k,path,_ in base}
refs=set()
variants=[]
first={}
for node in stage['nodes']:
    k=node.get('resourceId','')
    slots=node.get('materialSlots',{})
    if slots:
        new=k+'::materials::'+node['id']
        variants.append((new,lookup[k],tuple(sorted(slots.items()))))
        first.setdefault(k,new)
        k=new
    refs.add(k)
rows=base+variants
by_id={row[0]:i for i,row in enumerate(rows)}
replaced=set()
for i,(k,_,_) in enumerate(base):
    if k not in refs and k in first:
        j=by_id[first[k]]
        rows[i],rows[j]=rows[j],rows[i]
        replaced.add(k)
log=(q/original/'player.log').read_text(encoding='utf8',errors='replace')
assert '[2] AzureRender_ShowcasePlatform -> showcase' in log
seen=set()
total=0
hits=[]
def model_schema(path):
    if path==q/'native/hero.gltf':
        return hero_model
    if path.suffix.lower()=='.glb':
        with path.open('rb') as f:
            header,version,size=struct.unpack('<4sII',f.read(12))
            assert (header,version)==(b'glTF',2)
            length,kind=struct.unpack('<I4s',f.read(8))
            assert kind==b'JSON'
            return json.loads(f.read(length))
    return json.loads(path.read_bytes())
for k,path,slots in rows:
    if k in replaced or (path,slots) in seen:
        continue
    seen.add((path,slots))
    model=model_schema(path)
    materials=model.get('materials',[])
    if total<=307<total+len(materials)+1:
        ix=307-total
        hits.append((k,path,slots,total,ix,materials[ix] if ix<len(materials) else {'name':'FallbackMaterial'}))
    platform_material=int(len(seen)==1)
    total+=len(materials)+1+platform_material
assert f'Character texture access: fixed, requested slots={total*9+2},' in log
assert len(hits)==1
k,path,slots,base_index,j,material=hits[0]
parents=[dict(id=n['id'],name=n.get('name')) for n in stage['nodes'] if n.get('resourceId')==k]
result=dict(materialCount=total,fixedTextureSlots=total*9+2,distinctResources=len(seen),resource=k,model=str(path),
            slotOverrides=slots,globalMaterialBase=base_index,localMaterialIndex=j,material=material,nodes=parents,
            sourceLevelSha256=sha256(level.read_bytes()).hexdigest(),projectSha256=sha256(p.read_bytes()).hexdigest())
(m/'joint-intel-snapshot-material-identity.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print({key:result[key] for key in ('materialCount','resource','model','globalMaterialBase','localMaterialIndex')})
print(material)
print(parents[:5])
