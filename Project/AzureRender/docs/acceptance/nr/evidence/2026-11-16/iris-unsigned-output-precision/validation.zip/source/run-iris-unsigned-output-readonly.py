"""Exercise material output precision on verified existing, unoccluded iris inputs."""
import gzip
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys

import numpy as np

M=Path(__file__).resolve().parent
old=runpy.run_path(str(M/'run-iris-unsigned-output-precision.py'),run_name='iris_precision_measure')
H,W,R,FIX,ROOT,CASE=(old[k] for k in ('H','W','R','FIX','ROOT','CASE'))
read,sha,write,art,check=(old[k] for k in ('read','sha','write','art','check'))
B=W/'build'
OUT=M/'iris-unsigned-output-readonly'
project=FIX/'iris-native-main-frame-uncovered-control.azureproject'
qualification=M/'immutable-scene-capture-source/qualification.json'
player=M/'projected-history-layer-release/AzurePlayerCaptureResource.exe'
original='    outputColor=azureMaterialOutputPrecision(outputColor,materialFeatureEnabled(67108864U)>.5);'
replacement='    outputColor=azureMaterialOutputPrecision(outputColor,materialFeatureEnabled(67108864U)>.5 || (eyeNpr&&qaIsolationMode==0));'


def inputs():
    model=read(project)
    level=FIX/'scene'/model['startupScene'].split(':/',1)[1]
    main=H['score']
    gold=main['stages']/'post-opaque-ownership/1245-1244.bin.gz'
    coords=np.asarray(read(M/'iris-native-matcap-d3d-vulkan-owned-levels.json')['points']).T
    x,y=coords
    expected=H['display'](H['unpack'](np.frombuffer(gzip.decompress(gold.read_bytes()),'<u4').reshape(1440,2560)[::-1][y,x]))
    sources={}
    for g in ('nvidia','intel'):
        stored=R/f'iris-native-main-frame-uncovered-{g}'
        c=read(stored/'command.json')
        m=read(stored/Path(c[c.index('--project')+1]).name)
        v=read(stored/m['startupScene'].split(':/',1)[1])
        assert read(level)==v
        m['startupScene']=model['startupScene']
        assert m==model
        sources[g]=c
    return coords,expected,dict(project=sha(project),level=sha(level),native=sha(gold)),sources


def provision():
    pre=read(CASE/'preflight.json')
    source=CASE/'mesh.frag'
    base=source.read_text('utf-8')
    assert sha(source)==pre['source'] and base.count(original)==1
    modified=base.replace(original,replacement)
    assert modified.replace(replacement,original)==base
    if not OUT.is_dir():OUT.mkdir()
    candidate=OUT/'mesh.frag'
    candidates=OUT/'programs'
    candidates.mkdir(exist_ok=True)
    candidate.write_text(modified,encoding='utf-8')
    for program in H['programs']:
        assert sha(CASE/'resources/shaders'/program)==pre['programs'][program]
        H['compile_program'](candidate,candidates/program,program,diagnostics=OUT/'compile'/f'{program}.log')
    record=dict(baseSource=pre['source'],candidateSource=sha(candidate),basePrograms=pre['programs'],
                candidatePrograms={n:sha(candidates/n) for n in H['programs']},
                sourceChange='Reuse the unsigned 11/11/10 truncation at final iris color output.')
    write(OUT/'shader-receipt.json',record)
    return record


def capture(g,command,mode):
    folder=OUT/f'{g}-{mode}'
    folder.mkdir()
    args=command.copy()
    args[0]=str(player)
    fields=(('--project',project),('--resource-root',ROOT),('--capture-dir',folder/'frames'),('--runtime-report',folder/'runtime.json'))
    for key,path in fields:args[args.index(key)+1]=str(path)
    assert all(k not in os.environ for k in ('AZR_NR_QA_RESOURCE_ID','AZR_NR_QA_RESOURCE_PATH'))
    H['helpers']['invoke'](g,args,folder)
    m=read(folder/'frames/capture_manifest.json')
    prev=read(CASE/f'{g}-bare/frames/capture_manifest.json')
    for key in ('width','height','capturedFrames','qaCameraPosition','qaCameraTarget','cameraLens','cameraUp',
                'nprLighting','gradeSettings','screenReflectionAlgorithm'):
        assert m[key]==prev[key],key
    cap=read(folder/'frames/gpu_capabilities.json')
    expected=read(CASE/f'{g}-bare/frames/gpu_capabilities.json')
    assert all(cap[k]==expected[k] for k in ('vendor_id','device_id','driver_version'))
    rt=read(folder/'runtime.json')
    assert not rt['presentationErrors'] and not rt['scriptErrors']
    return folder/'frames/frame_000000.png'


def run():
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==M
    q=read(qualification)
    assert sha(player)==q['candidatePlayer'] and q['readOnlyProjectAssets']
    budget=check(B,run=M,planned=7_600_000)
    assert budget['allowed'],budget
    coords,expected,immutable,commands=inputs()
    r=provision()
    catalog=H['catalog_api']
    with art.database(B) as c:prior=art.rows(c)
    pinned=prior[R.name]
    assert pinned['status']=='closed' and R.name in art.protected_names(prior)
    art.resume(B,R.name)
    try:
        rows={}
        for g,command in commands.items():
            with catalog['activate'](r['basePrograms'],alternate_run=M,source_dir=CASE/'resources/shaders'):
                control=capture(g,command,'control')
            known=CASE/f'{g}-bare/frames/frame_000000.png'
            ch=sha(control)
            assert ch==sha(known),(g,ch,sha(known))
            assert control.resolve().parent==(OUT/f'{g}-control/frames').resolve() and not control.is_symlink()
            write(control.parent.parent/'control-receipt.json',dict(exact=True,sha256=ch))
            control.unlink()
            with catalog['activate'](r['candidatePrograms'],alternate_run=M,source_dir=OUT/'programs'):
                candidate=capture(g,command,'candidate')
            row=old['measure'](g,'bare',candidate,coords,expected)
            row['controlExact']=True
            rows[g]=row
            print(json.dumps((g,{k:v for k,v in row.items() if k!='onlyChanged'})),flush=True)
            write(OUT/'partial.json',rows)
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=90)
    with art.database(B) as c:restored=art.rows(c)[R.name]
    assert restored['status']=='closed' and restored['manifestSha256']==pinned['manifestSha256']
    assert immutable==inputs()[2]
    write(OUT/'qualification.json',dict(status='measured-two-device-bare-iris-output-precision',
        programs=r,player=sha(player),immutable=immutable,devices=rows,
        strictBare=all(m['peak'][1]<=1 and m['newOverOne']==m['outsideIrisChanged']==0 for m in rows.values()),
        coveredPending=True))


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(inputs()[2])
    else:
        assert not sys.argv[1:]
        run()

