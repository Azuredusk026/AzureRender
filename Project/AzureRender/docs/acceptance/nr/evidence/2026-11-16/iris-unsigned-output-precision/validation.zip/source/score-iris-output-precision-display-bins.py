"""Bound the effect of unsigned output precision from exact display-code bins."""
from pathlib import Path
import gzip
import json
import runpy
import numpy as np

M=Path(__file__).resolve().parent
T=runpy.run_path(str(M/'iris-matcap-differential-player.py'),run_name='iris_output_transfer')
B=T['stage']/'earlyProjectiveCoarseBaseFineDiagonal'
read,digest,write,display=(T[k] for k in ('read','digest','write','display'))
x,y=np.asarray(read(M/'iris-native-matcap-d3d-vulkan-owned-levels.json')['points']).T
S=T['score']
native=S['stages']/'post-opaque-ownership/1245-1244.bin.gz'
reference=display(T['unpack'](np.frombuffer(gzip.decompress(native.read_bytes()),'<u4').reshape(1440,2560)[::-1][y,x]))
linear=lambda q:np.where(q<=.04045,q/12.92,((q+.055)/1.055)**2.4)
mant=np.array([6,6,5])
def floor(value):
    np.testing.assert_array_less(-.001,value)
    exponent=np.maximum(-14,np.frexp(value)[1]-1)
    quantum=np.exp2(exponent-mant)
    return np.floor(value/quantum)*quantum
assert np.array_equal(floor(np.array([[1.015,1.02,1.03]])),[[1,1.015625,1]])
report={}
ref=read(B/'results.json')
for gpu in ('nvidia','intel'):
    file=B/f'{gpu}-bare/frames/frame_000000.png'
    receipt=ref['devices'][gpu]['false']
    assert receipt['frame']==digest(file)
    image=S['image'](file)[y,x].astype(np.int16)
    d=abs(image-reference).max(axis=1)
    assert (d>1).sum()==receipt['overOne'][1] and d.max()==receipt['peak'][1]
    bounds=linear(np.stack([np.clip((image+n)/255,0,1) for n in (-.5,0,.5)]))
    # RGBA16F input has finite bin edges. Half of one binary16 step
    # bounds the pre-store value on either side of that interval.
    q=np.spacing(bounds.astype('f2')).astype('f8')*.5
    bounds[0]=np.maximum(bounds[0]-q[0],0)
    bounds[-1]+=q[-1]
    lo,center,hi=display(floor(bounds))
    outside=np.maximum.reduce([lo-reference,reference-hi,np.zeros_like(reference)]).max(axis=1)
    max_worst=np.maximum(abs(lo-reference),abs(hi-reference)).max(axis=1)
    nominal=abs(center-reference).max(axis=1)
    report[gpu]=dict(beforeOverOne=int((d>1).sum()), beforePeak=int(d.max()),
        nominalOverOne=int((nominal>1).sum()), nominalPeak=int(nominal.max()),
        lowestPossibleOverOne=int((outside>1).sum()),lowestPossiblePeak=int(outside.max()),
        guaranteedCurrentFailuresFixed=int(((d>1)&(max_worst<=1)).sum()),
        newAtNominal=int(((d<=1)&(nominal>1)).sum()),
        guaranteedNew=int(((d<=1)&(outside>1)).sum()),
        retainedImpossiblePoints=[(int(a),int(b),int(e)) for a,b,e in zip(x,y,outside) if e>1])
print(json.dumps(report))
write(M/'iris-output-precision-display-bins.json',dict(status='theoretical-display-bin-control',scope=len(x),
    native=digest(native),inputProof=digest(B/'results.json'),devices=report))

