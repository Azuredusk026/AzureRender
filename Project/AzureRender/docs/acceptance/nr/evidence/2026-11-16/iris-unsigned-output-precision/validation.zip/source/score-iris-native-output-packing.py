"""Qualify unsigned target packing against preserved native shader outputs."""
import gzip
import json
from pathlib import Path
import runpy
import numpy as np

M=Path(__file__).resolve().parent
X=M.parent/'20261114-135148-face-receiver-diagnostics-7509b1'
h=runpy.run_path(str(M/'iris-matcap-differential-player.py'),run_name='packing_reference')
read,digest,write=[h[x] for x in ('read','digest','write')]
native=h['score']['stages']/'post-opaque-ownership/1245-1244.bin.gz'
raw=np.frombuffer(gzip.decompress(native.read_bytes()),'<u4').reshape(1440,2560)[::-1]
geometry=read(M/'iris-native-matcap-d3d-vulkan-owned-levels.json')
points={tuple(p) for p in geometry['points']}
receipt=read(M/'trace-iris-matcap-inputs.json')
scan=[*sorted(X.glob('iris-native-846-trace-*.json')),*sorted(M.glob('iris-native-846-matcap-trace-*.json'))]
proof=[]
for path in scan:
    x,y=map(int,path.stem.split('-')[-2:])
    if path.parent==M:
        expected,=[p['sha256'] for p in receipt['points'] if p['point']==[x,y]]
        assert expected==digest(path)
    assert (x,y) in points
    trace=read(path)
    shader=[(step,r['o0'][:3]) for step,r in trace if 'o0' in r]
    step,v=shader[-1]
    assert step==1199 and len(v)==3 and min(v)>0
    actual=h['unpack'](np.array([raw[y,x]]))[0]*4
    q=np.exp2(np.frexp(v)[1]-1-np.array([6,6,5]))
    f=np.floor(v/q)*q
    n=np.rint(v/q)*q
    proof.append(dict(point=[x,y],file=str(path),sha256=digest(path),nativeShaderOutput=v,
                      packedTarget=actual.tolist(),towardZero=f.tolist(),nearestEven=n.tolist(),
                      towardZeroExactChannels=int((f==actual).sum()),nearestEvenExactChannels=int((n==actual).sum())))
a,b=[sum(p[k] for p in proof) for k in ('towardZeroExactChannels','nearestEvenExactChannels')]
assert len(proof)==11 and len({tuple(p['point']) for p in proof})==8
assert a==33 and b<33
q=dict(status='qualified-native-iris-color-packing',nativeAttachment=digest(native),
       event=846,tracks=len(proof),uniquePoints=8,totalChannels=33,towardZeroExact=a,nearestEvenExact=b,rows=proof)
write(M/'iris-native-output-packing-proof.json',q)
print(a,b)

