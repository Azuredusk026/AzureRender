"""Apply the existing unsigned material-output precision to the paired iris draws."""
from contextlib import ExitStack
import gzip
import json
from pathlib import Path
import runpy
import subprocess
import sys
import uuid

import numpy as np

M=Path(__file__).resolve().parent
H=runpy.run_path(str(M/'iris-matcap-differential-player.py'),run_name='iris_precision_controls')
W,R,G,FIX,ROOT=(H[k] for k in ('workspace','body','grid','fixture','build'))
read,sha,write=(H[k] for k in ('read','digest','write'))
CASE=H['stage']/'earlyProjectiveCoarseBaseFineDiagonal'
OUT=M/'iris-unsigned-output-precision'
B=W/'build'
sys.path.insert(0,str(W/'tools'))
import artifact_maintenance as art
from artifact_budget import check

name='face-iris-public-main-frame.azurematerial'
feature='r11g11b10-output'
new_id=str(uuid.uuid5(uuid.NAMESPACE_URL,'azurerender:nr:iris:unsigned-output-stage'))
new_name='nr-iris-unsigned-output.azurematerial'


def materials():
    paths=[R/f'eye-native-public-{g}-projected'/name for g in ('nvidia','intel')]
    mats=[read(p) for p in paths]
    assert mats[0]==mats[1]
    p=FIX/'materials'/name
    assert sha(p)==sha(paths[0])==sha(paths[1])
    doc=read(p)
    fl=doc['surface']['materials'][0]['extras']['azureRenderMaterial']['features']
    assert feature not in fl and 'eye-radial-surface' in fl
    fl.append(feature)
    assert doc['surface']['materials'][0]['alphaMode']=='OPAQUE'
    side=read(p.with_name(name+'.azmeta'))
    old=side['id']
    side['id']=new_id
    return p,old,doc,side


def capture(g,mode,old_id):
    cover=mode=='covered'
    control=R/(f'eye-native-public-{g}-projected' if cover else f'iris-native-main-frame-uncovered-{g}')
    args=read(control/'command.json')
    proj=Path(args[args.index('--project')+1])
    assert proj.parent==FIX
    model=read(control/proj.name)
    scene=read(control/model['startupScene'].split(':/',1)[1])
    assert any(x['id']=='native-eye-shadow' for x in scene['nodes'])==cover
    hero,=[x for x in scene['nodes'] if x['id']=='hero']
    slot,=[k for k,v in hero['materialSlots'].items() if v==old_id]
    assert slot=='name:M_actor_laevat_iris_01'
    hero['materialSlots'][slot]=new_id
    stem=f'nr-iris-output-precision-{g}-{mode}'
    folder=OUT/f'{g}-{mode}'
    folder.mkdir()
    local_project=folder/(stem+'.azureproject')
    local_scene=folder/(stem+'.azurelevel')
    model['startupScene']='stage:/'+local_scene.name
    write(local_project,model)
    write(local_scene,scene)
    links={FIX/local_project.name:local_project,FIX/'scene'/local_scene.name:local_scene}
    for flag,value in (('--project',FIX/local_project.name),('--capture-dir',folder/'frames'),
                       ('--runtime-report',folder/'runtime.json')):
        args[args.index(flag)+1]=str(value)
    with ExitStack() as stack:
        for dest,src in links.items():
            assert not dest.exists()
            dest.hardlink_to(src)
            stack.callback(dest.unlink)
            if dest.suffix=='.azurelevel':
                meta=dest.with_name(dest.name+'.azmeta')
                assert not meta.exists()
                stack.callback(meta.unlink,missing_ok=True)
        H['helpers']['invoke'](g,args,folder)
    rt=read(folder/'runtime.json')
    assert not rt['presentationErrors'] and not rt['scriptErrors']
    c=read(folder/'frames/gpu_capabilities.json')
    oldc=read(CASE/f'{g}-{mode}'/'frames/gpu_capabilities.json')
    assert (c['vendor_id'],c['device_id'],c['driver_version'])==(oldc['vendor_id'],oldc['device_id'],oldc['driver_version'])
    return folder/'frames/frame_000000.png'


def measure(g,mode,frame,coords,expected):
    score=H['score']
    old=CASE/f'{g}-{mode}'/'frames/frame_000000.png'
    proof=read(CASE/'results.json')['devices'][g][str(mode=='covered').lower()]
    assert sha(old)==proof['frame']
    before,after=(score['image'](p).astype(np.int16) for p in (old,frame))
    x,y=coords
    outside=np.any(before!=after,axis=2)
    outside[y,x]=False
    d=np.stack([p[y,x]-expected for p in (before,after)])
    peaks=abs(d).max(axis=-1)
    assert proof['peak'][1]==int(peaks[0].max()) and proof['overOne'][1]==int((peaks[0]>1).sum())
    return dict(frame=sha(frame),control=sha(old),outsideIrisChanged=int(outside.sum()),
                overOne=(peaks>1).sum(axis=1).tolist(),peak=peaks.max(axis=1).tolist(),
                newOverOne=int(((peaks[0]<=1)&(peaks[1]>1)).sum()),
                onlyChanged=[dict(point=[int(x[i]),int(y[i])],before=d[0,i].tolist(),after=d[1,i].tolist())
                   for i in range(len(x)) if np.any(d[0,i]!=d[1,i])])


def run():
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==M
    reservation=check(B,run=M,planned=6_500_000)
    assert reservation['allowed'],reservation
    fixture_budget=check(B,run=G,planned=1_700_000)
    assert fixture_budget['allowed'],fixture_budget
    OUT.mkdir()
    unchanged,old_id,doc,side=materials()
    base_digest=sha(unchanged)
    material=OUT/new_name
    meta=OUT/(new_name+'.azmeta')
    write(material,doc)
    write(meta,side)
    validate=read(material)
    assert validate['surface']['materials'][0]['extras']['azureRenderMaterial']['features'].pop()==feature
    assert validate==read(unchanged)
    shaders=read(CASE/'preflight.json')['programs']
    assert all(sha(CASE/'resources/shaders'/n)==v for n,v in shaders.items())
    score=H['score']
    coords=np.asarray(read(M/'iris-native-matcap-d3d-vulkan-owned-levels.json')['points']).T
    x,y=coords
    n=score['stages']/'post-opaque-ownership/1245-1244.bin.gz'
    raw=np.frombuffer(gzip.decompress(n.read_bytes()),'<u4').reshape(1440,2560)[::-1][y,x]
    expected={'bare':H['display'](H['unpack'](raw)),
              'covered':score['image'](score['reference_path'])[y,x].astype(np.int16)}
    with art.database(B) as c:
        rec=art.rows(c)
    pinned=rec[R.name]
    assert pinned['status']=='closed' and R.name in art.protected_names(rec)
    art.resume(B,R.name)
    try:
        with ExitStack() as cleanup:
            for src in (material,meta):
                dest=FIX/'materials'/src.name
                assert not dest.exists()
                dest.hardlink_to(src)
                cleanup.callback(dest.unlink)
            catalog=H['catalog_api']
            scores={}
            with catalog['activate'](shaders,alternate_run=M,source_dir=CASE/'resources/shaders'):
                for g in ('nvidia','intel'):
                    scores[g]={}
                    for mode in ('bare','covered'):
                        r=measure(g,mode,capture(g,mode,old_id),coords,expected[mode])
                        scores[g][mode]=r
                        print(json.dumps((g,mode,{k:v for k,v in r.items() if k!='onlyChanged'})),flush=True)
                        write(OUT/'partial.json',scores)
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=90)
    with art.database(B) as c: recovered=art.rows(c)[R.name]
    assert recovered['status']=='closed' and recovered['manifestSha256']==pinned['manifestSha256']
    assert base_digest==sha(unchanged)
    write(OUT/'qualification.json',dict(status='measured-iris-unsigned-output-precision',
        material={'baseline':base_digest,'variant':sha(material),'precision':feature,'oldId':old_id,'newId':new_id},
        programs=shaders, native={'bare':sha(n),'covered':sha(score['reference_path'])},
        baseline=sha(CASE/'results.json'),devices=scores,strict=all(
            m['peak'][1]<=1 and m['newOverOne']==m['outsideIrisChanged']==0 for g in scores.values() for m in g.values())))


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        p,old,d,s=materials()
        print(sha(p),old,s['id'])
    else:run()

