"""Isolate the native local diffuse addition at its actual color attachment."""
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import traceback

KEY='AZURE_NR_NATIVE_LOCAL_DIFFUSE_OUTPUT'
M=Path(os.environ[KEY]).parent if KEY in os.environ else Path(__file__).resolve().parent
OUT=M/'face-native-diffuse-at-output'
read=lambda p:json.loads(Path(p).read_bytes())
write=lambda p,v:Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
h=lambda b:sha256(b).hexdigest()


def plan():
    native=read(M/'trace-face-view-mask-request.json')
    m=M/'trace-iris-matcap-request.json'
    source=read(M.parents[2]/'docs/acceptance/nr/evidence/2026-11-16/face-local-light-lanes/results.json')
    expected=source['devices']
    points=[r['point'] for r in expected['nvidia']]
    assert len(points)==6 and points==[r['point'] for r in expected['intel']]
    asm=M.parent/'20261112-231945-projected-hair-reference-grid-4b775d/native-face-skin-stages/pixel-804.txt'
    lines=asm.read_text(encoding='utf8').splitlines()
    expected_ops={1396:'mul r18.xyz, r18.xyzx, r22.xyzx',1397:'mul r18.xyz, r19.wwww, r18.xyzx',
              1398:'mad r18.xyz, r22.xyzx, r26.xyzx, r18.xyzx',1399:'add r21.xyz, r18.xyzx, r21.xyzx'}
    assert all([v.strip().split(':',1)[1].strip() for v in lines if v.strip().startswith(str(i)+':')]==[s]
               for i,s in expected_ops.items())
    first_ftou=next(int(v.strip().split(':',1)[0]) for v in lines if ': ftou ' in v)
    assert first_ftou==76
    return dict(capture=native['native'],captureSha256=native['captureSha256'],
        pixelShaderSha256=native['nativeShader'],points=points,utilities=read(m)['utilities'],
        assembly=h(asm.read_bytes()),event=804,body={'target':'ResourceId::141976','disabledInstruction':1398,
        'utilityInstructionBase':first_ftou})


def unpack(n):
    values=[]
    for shift,bits in ((0,6),(11,6),(22,5)):
        word=(n>>shift)&((1<<(bits+5))-1)
        exponent=word>>bits
        mant=word&((1<<bits)-1)
        v=math.ldexp(mant,-14-bits) if exponent==0 else math.ldexp(1+mant/(1<<bits),exponent-15)
        values.append(v)
    return values


def worker():
    import renderdoc as rd
    q=read(OUT/'request.json')
    sys.path.insert(0,q['utilities'])
    from dxbc_util import checksum,chunks,instructions,opcode,rebuild,words

    def without_add(raw):
        assert checksum(raw)==raw[4:20]
        tables=chunks(raw)
        j,=[i for i,part in enumerate(tables) if part[0] in (b'SHEX',b'SHDR')]
        w=words(tables[j][1])
        index=q['body']['disabledInstruction']-q['body']['utilityInstructionBase']
        i,at,op,n=next(t for t in instructions(w) if t[0]==index)
        assert i==index and op==opcode('MAD')
        assert w[at+2:at+n:2]==[18,22,26,18],w[at:at+n]
        assert next(t[2] for t in instructions(w) if t[0]==index+1)==opcode('ADD')
        del w[at:at+n]
        w[1]=len(w)
        prev=tables[j]
        tables[j]=(prev[0],struct.pack('<{}I'.format(len(w)),*w),*prev[2:])
        return rebuild(raw,tables)

    cap=rd.OpenCaptureFile()
    result=dict(status='failed',request=h((OUT/'request.json').read_bytes()),devices={})
    try:
        write(OUT/'progress.json',dict(stage='open'))
        assert cap.OpenFile(q['capture'],'',None)==rd.ResultCode.Succeeded
        for name,vendor,id in [('nvidia',rd.GPUVendor.nVidia,0x28e0),('intel',rd.GPUVendor.Intel,0xa788)]:
            opts=rd.ReplayOptions()
            opts.forceGPUVendor=vendor
            opts.forceGPUDeviceID=id
            status,c=cap.OpenCapture(opts,None)
            assert status==rd.ResultCode.Succeeded and c
            try:
                api=c.GetAPIProperties()
                assert api.pipelineType==rd.GraphicsAPI.D3D11 and api.vendor==vendor and not api.degraded
                c.SetFrameEvent(q['event'],True)
                pipe=c.GetPipelineState()
                r=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
                shader=pipe.GetShader(rd.ShaderStage.Pixel)
                raw=bytes(r.rawBytes)
                assert h(raw)==q['pixelShaderSha256']
                dst=pipe.GetOutputTargets()[0].resource
                assert str(dst)==q['body']['target']
                def texture():
                    c.SetFrameEvent(q['event'],True)
                    b=bytes(c.GetTextureData(dst,rd.Subresource()))
                    assert len(b)==2560*1440*4
                    return b
                base=texture()
                records={}
                for tag,code in [('copy',raw),('diffuseDisabled',without_add(raw))]:
                    write(OUT/'progress.json',dict(device=name,mode=tag))
                    new,error=c.BuildTargetShader('main',rd.ShaderEncoding.DXBC,code,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
                    assert new!=rd.ResourceId.Null(),error
                    c.ReplaceResource(shader,new)
                    try:
                        actual=texture()
                    finally:
                        c.RemoveReplacement(shader)
                        c.FreeTargetResource(new)
                    assert (actual==base)==(tag=='copy')
                    vals=[struct.unpack_from('<I',actual,((1439-y)*2560+x)*4)[0] for x,y in q['points']]
                    records[tag]=dict(program=h(code),target=h(actual),
                        samples=[dict(point=xy,word=n,rgb=unpack(n)) for xy,n in zip(q['points'],vals)])
                    if tag!='copy':
                        (OUT/f'{name}-diffuse-disabled.dxbc').write_bytes(code)
                assert texture()==base
                result['devices'][name]=dict(records=records,baselineRestored=True)
            finally:
                c.Shutdown()
        result['status']='qualified-native-local-diffuse-at-output'
    except BaseException:
        result['error']=traceback.format_exc()
    finally:
        cap.Shutdown()
        write(OUT/'results.json',result)
    os._exit(int(result['status']=='failed'))


def run():
    from hashlib import file_digest
    sys.path.insert(0,str(M.parents[2]/'tools'))
    from artifact_budget import check
    lease=read('D:/Projects/FYP-coordination/resources/current.json')
    assert lease['state']=='held' and Path(lease['output'])==M
    assert check(M.parents[1],run=M,planned=550_000)['allowed']
    req=plan()
    with Path(req['capture']).open('rb') as fd:
        assert file_digest(fd,'sha256').hexdigest()==req['captureSha256']
    OUT.mkdir(exist_ok=True)
    f=OUT/'request.json'
    write(f,req)
    startup=subprocess.STARTUPINFO()
    startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=0
    with (OUT/'replay.log').open('wb') as log:
        r=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe',
                         '--python',str(Path(__file__).resolve())],cwd=OUT,
                         env=dict(os.environ,**{KEY:str(OUT)}),startupinfo=startup,stdin=subprocess.DEVNULL,
                         stdout=log,stderr=subprocess.STDOUT,timeout=160)
    q=read(OUT/'results.json')
    assert r.returncode==0 and q['status']=='qualified-native-local-diffuse-at-output',q.get('error')
    print(list(q['devices']))


if KEY in os.environ:
    worker()
elif __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(plan())
    else:
        run()
