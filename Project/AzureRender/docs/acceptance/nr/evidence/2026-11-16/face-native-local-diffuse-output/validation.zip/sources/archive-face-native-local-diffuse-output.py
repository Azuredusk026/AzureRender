"""Archive original local-diffuse toggles and paired Player attachment measurements."""
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
from zipfile import ZipFile,ZIP_DEFLATED

M=Path(__file__).resolve().parent
n=M/'face-native-diffuse-at-output'
E=M.parents[2]/'docs/acceptance/nr/evidence/2026-11-16'
O=E/'face-native-local-diffuse-output'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
q=read(n/'results.json')
c=read(n/'comparison.json')
v=E/'face-local-light-output/qualification.json'
assert q['status']=='qualified-native-local-diffuse-at-output' and not c['strictFaceAcceptance']
assert q['request']==digest(n/'request.json')
assert c['inputDigests']==dict(native=digest(n/'results.json'),player=digest(v))
files={f'native/{x}':n/x for x in ('request.json','results.json','comparison.json')}
for dev,r in q['devices'].items():
    assert r['baselineRestored']
    dx=n/f'{dev}-diffuse-disabled.dxbc'
    assert r['records']['diffuseDisabled']['program']==digest(dx)
    files['native/'+dx.name]=dx
    z=c['nativeDeviceComparisons'][dev]
    assert 2.6<z['gainFromDark']<2.65
    assert z['completeAttachmentSweeps']['3.0']['peak']>z['completeAttachmentSweeps']['1.0']['peak']
for name in ('face-native-diffuse-at-output.py','compare-face-local-diffuse-attachments.py','archive-face-native-local-diffuse-output.py'):
    files['sources/'+name]=M/name
files['native/replay.log']=M/'retest-face-native-local-diffuse-output.log'
cx=sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True)
task,state,code,elapsed=cx.execute('select task,state,exit_code,run_seconds from jobs where id=1499').fetchone()
assert (state,code)==('succeeded',0)
O.mkdir(parents=True,exist_ok=True)
z=O/'validation.zip'
with ZipFile(z,'w',ZIP_DEFLATED,compresslevel=9) as archive:
    for name,p in files.items():
        archive.write(p,name)
with ZipFile(z) as archive:
    proof={k:sha256(archive.read(k)).hexdigest() for k in files}
    assert archive.testzip() is None and proof=={k:digest(p) for k,p in files.items()}
c['queue']=dict(id=1499,task=task,state=state,exitCode=code,elapsedSeconds=elapsed)
c['validation']=dict(archive=digest(z),members=proof)
(O/'qualification.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf8')
print(z.stat().st_size)
