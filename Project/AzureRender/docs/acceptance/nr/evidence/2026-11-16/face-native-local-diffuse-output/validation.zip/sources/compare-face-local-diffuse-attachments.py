"""Compare the two measured local-diffuse attachment changes on the registered faces."""
import json
from hashlib import sha256
from pathlib import Path

import numpy as np

M=Path(__file__).resolve().parent
E=M.parents[2]/'docs/acceptance/nr/evidence/2026-11-16'
N=M/'face-native-diffuse-at-output/results.json'
P=E/'face-local-light-output/qualification.json'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
n,p=read(N),read(P)
assert n['status']=='qualified-native-local-diffuse-at-output'
assert p['gains']==[0,1,1.5,2,2.5,3]
assert p['status']=='measured-player-output-local-diffuse'
source_by_address={tuple(x['point']):x for x in p['rows']}
rows={}
for k,v in n['devices'].items():
    scope=[]
    v=v['records']
    for a,b in zip(v['copy']['samples'],v['diffuseDisabled']['samples'],strict=True):
        assert a['point']==b['point']
        q=source_by_address[tuple(a['point'])]
        amount=(np.array(a['rgb'])-np.array(b['rgb']))*.25
        local=np.array(q['affectsBeautyRgb'])
        precision=max(abs(local-(np.array(q['rgbSweep'][1])-np.array(q['rgbSweep'][0]))))
        assert precision<=1e-8 and (amount>0).all() and (local>0).all()
        gain=float(np.dot(local,amount)/np.dot(local,local))
        scope.append(dict(point=a['point'],group=q['group'],nativeAddedQuarter=amount.tolist(),
            nativeCompleteQuarter=(np.array(a['rgb'])*.25).tolist(),
            playerAdded=local.tolist(),leastSquaresGain=gain,redGain=float(amount[0]/local[0]),
            differenceAtGainOne=(amount-local).tolist()))
    group=[x for x in scope if x['group']=='dark']
    holdout=[x for x in scope if x['group']!='dark']
    assert len(group)==len(holdout)==3
    a=np.asarray([x['nativeAddedQuarter'] for x in group])
    b=np.asarray([x['playerAdded'] for x in group])
    global_gain=float((a*b).sum()/(b*b).sum())
    def score(samples,gain):
        d=np.asarray([gain*np.array(x['playerAdded'])-np.array(x['nativeAddedQuarter']) for x in samples])
        return dict(mae=float(abs(d).mean()),peak=float(abs(d).max()))
    stats={k:{str(g):score(r,g) for g in (1,global_gain)} for k,r in [('dark',group),('brightHoldout',holdout)]}
    clipped={}
    for idx,gain in enumerate(p['gains']):
        e=np.asarray([np.array(source_by_address[tuple(x['point'])]['rgbSweep'][idx])-x['nativeCompleteQuarter'] for x in scope])
        clipped[str(gain)]=dict(peak=float(abs(e).max()),mae=float(abs(e).mean()))
    assert all(clipped[str(g)]['peak']>clipped['1.0']['peak'] for g in p['gains'] if g>1)
    rows[k]=dict(gainFromDark=global_gain,scores=stats,samples=scope,completeAttachmentSweeps=clipped)
    print(k,[round(x['redGain'],4) for x in scope],global_gain,stats)
out=dict(status='compared-local-diffuse-at-actual-color-attachments',strictFaceAcceptance=False,
    inputDigests=dict(native=sha(N),player=sha(P)),referenceRadianceScale=.25,
    playerRecordedCapture=p['capture'],nativeDeviceComparisons=rows)
(N.parent/'comparison.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
