"""Compare the 3534 backbuffer with the preserved paired scene captures."""
from hashlib import file_digest
import json
import os
from pathlib import Path

import cv2
import numpy as np
from PIL import Image


out = Path(__file__).resolve().parent / 'joint-native-floor'
engine = Path('D:/Projects/FYP/Project/AzureRender')
runs = engine / 'build/runs'
capture = runs / '20261022-201845-endfield-capture-954719'
replay = capture / 'Endfield-games-child_frame3534-replayed.png'
present = capture / 'Endfield-games-child_frame3534.png'
joint = runs / '20261103-234012-character-reference-stages-5abe6c'
recent = runs / '20261114-020728-nr-joint-59579-main-visual-1bcbe5/baseline-original-four/frames'
projected = runs / '20261031-122504-projected-footprint-quality-5daf40/capture-indexed/frames'
paired = runs / '20261031-113415-projected-main-history-93cbc0'
production = joint / 'snapshot-shell-order-regression/release-joint/frames'
disabled = joint / 'current-joint-gi-off-capture/frames'
read = lambda path: json.loads(path.read_bytes())
stable_keys = ('qaCameraPosition', 'qaCameraTarget', 'cameraLens', 'cameraUp', 'screenReflectionAlgorithm',
               'screenReflectionProducer', 'screenReflectionLevels', 'width', 'height')


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def img(path):
    with Image.open(path) as image:
        return np.array(image.convert('RGB'), dtype=np.uint8)


def luma(rgb):
    return cv2.cvtColor(np.asarray(rgb, dtype=np.float32) / 255, cv2.COLOR_RGB2GRAY)


def contrast_structure(x, y, ax, ay, blur):
    return (2*(blur(x*y)-ax*ay)+.03**2) / (blur(x*x)-ax*ax+blur(y*y)-ay*ay+.03**2)


def measure(candidate, reference):
    rgb_diff = candidate.astype(np.int16) - reference.astype(np.int16)
    x, y = luma(candidate), luma(reference)
    blur = lambda image: cv2.GaussianBlur(image, (11, 11), 1.5)
    a, b = blur(x), blur(y)
    ssim = (2*a*b+.01**2)/(a*a+b*b+.01**2)*contrast_structure(x, y, a, b, blur)
    med_source, med_candidate = map(float, (np.median(y), np.median(x)))
    matched = np.minimum(x*(med_source/med_candidate), 1) if med_candidate > 0 else x
    matched_blur = blur(matched)
    matched_ssim = (2*matched_blur*b+.01**2)/(matched_blur**2+b*b+.01**2)*contrast_structure(
        matched, y, matched_blur, b, blur)
    return dict(pixels=int(x.size), ssim=float(ssim.mean()), medianReference=med_source,
                medianCandidate=med_candidate, medianLumaRelativeError=(abs(med_candidate-med_source)/med_source
                if med_source > 0 else None), meanAbsByte=float(np.abs(rgb_diff).mean()),
                diagnosticMedianMatchedLumaSsim=float(matched_ssim.mean()),
                medianSignedRgbBytes=np.median(rgb_diff, axis=(0, 1)).tolist(),
                exactPixels=int(np.all(rgb_diff == 0, axis=2).sum()), peak=int(np.abs(rgb_diff).max()))


def frozen_algorithm_pairs():
    provenance = {}
    for row in read(paired/'full-projects.json'):
        path_a, path_b = (engine/row[key] for key in ('sourceLevel','level'))
        assert sha(path_a) == row['sourceSha256'] and sha(path_b) == row['levelSha256']
        a, b = read(path_a), read(path_b)
        original = a['renderSettings']['screenSpaceReflection']
        candidate = b['renderSettings']['screenSpaceReflection']
        assert original['schemaVersion'] == 1 and candidate['schemaVersion'] == 2
        assert candidate['algorithm'] == 'projected'
        a['renderSettings']['screenSpaceReflection'] = {**original, 'schemaVersion': 2, 'algorithm': 'projected'}
        assert a == b
        provenance[row['kind']] = dict(linear=sha(path_a), projected=sha(path_b), onlyField='screenSpaceReflection.algorithm')
    return provenance


def main():
    cv2.setNumThreads(1)
    if os.name == 'nt':
        import ctypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.GetCurrentProcess.restype = ctypes.c_void_p
        kernel.SetPriorityClass.argtypes = (ctypes.c_void_p, ctypes.c_uint)
        assert kernel.SetPriorityClass(kernel.GetCurrentProcess(), 0x40)  # Idle priority for CPU scoring.
    capture_receipt = capture / 'Endfield-games-child_frame3534-backbuffer-receipt.json'
    save = read(capture_receipt)['result']
    assert save['ok'] and save['data']['rid'] == 'ResourceId::406'
    assert Path(save['data']['path']).name == replay.name
    snapshots = {'gamePresent':present, 'gameBackbuffer':replay, 'irradianceEnabled': production/'frame_000000.png',
                 'irradianceDisabled': disabled/'frame_000000.png', 'registeredCapture': recent/'frame_000000.png',
                 'archivedProjected': projected/'frame_000000.png'}
    assert sha(snapshots['irradianceEnabled']) == '4faf27a0d379b247e9a0a98d77dd8a8c2622ad689dc914428ca8df7944b79387'
    assert sha(snapshots['irradianceDisabled']) == '33560f3cbeec77d1d75c979fea4d51dfe0c072730bffe5c9f332d8bd258f0d2d'
    p, d, n, prev = [read(path/'capture_manifest.json') for path in (production, disabled, recent, projected)]
    assert all(p[key] == d[key] for key in stable_keys)
    assert all(n[key] == d[key] for key in ('qaCameraPosition', 'qaCameraTarget', 'width', 'height'))
    assert np.allclose(n['cameraLens']['offsetNdc'], p['cameraLens']['offsetNdc'], rtol=0, atol=1e-12)
    assert abs(n['cameraLens']['verticalFovRadians']-p['cameraLens']['verticalFovRadians']) < 1e-12
    assert all(prev[key] == p[key] for key in ('qaCameraPosition','qaCameraTarget','cameraLens','cameraUp'))
    assert prev['screenReflectionProducer'] == 'projected-history' and p['screenReflectionProducer'] == 'linear-temporal'
    frame = {k:img(path) for k,path in snapshots.items()}
    assert frame['gamePresent'].shape == (1152,2048,3)
    assert all(image.shape == (1440,2560,3) for key,image in frame.items() if key != 'gamePresent')
    existing = read(joint/'floor-fixed-results.json')['regions']
    assert existing['centerFloor'] == [1010, 990, 1550, 1170]
    assert existing['rightWall'] == [1920,390,2480,620]
    bounds = {'complete': [0,0,2560,1440], **existing}
    comparisons = {}
    for candidate, reference in (('irradianceEnabled','gameBackbuffer'), ('irradianceDisabled','gameBackbuffer'),
                                 ('registeredCapture','gameBackbuffer'), ('archivedProjected','gameBackbuffer'),
                                 ('registeredCapture','irradianceEnabled')):
        comparisons[f'{candidate}:{reference}'] = {
            name: measure(frame[candidate][y:v,x:u], frame[reference][y:v,x:u])
            for name, (x,y,u,v) in bounds.items()}
    reports = read(paired/'full-capture-summary.json')
    assert reports['status'] == 'passed' and len(reports['cases']) == 4
    pair = {row['name']: row for row in reports['cases']}
    pairs = {}
    for kind in ('environment','actor'):
        rows = [pair[label + '-' + kind] for label in ('linear','projected')]
        states = [row['capture'] for row in rows]
        keys = ('qaCameraPosition', 'qaCameraTarget', 'cameraLens', 'cameraUp', 'gradeSettings',
                'width', 'height', 'fps', 'capturedFrames', 'screenReflectionHistoryInputSubmission')
        assert all(states[0][key] == states[1][key] for key in keys)
        assert [state['screenReflectionProducer'] for state in states] == ['linear-temporal', 'projected-history']
        check = []
        for i in range(3):
            data = {}
            for row in rows:
                sample = row['images'][i]
                path = paired / ('full-' + row['name']) / 'frames' / sample['frame']
                assert sha(path) == sample['sha256']
                images = img(path)
                metrics = {name:measure(images[y:v,x:u], frame['gameBackbuffer'][y:v,x:u])
                           for name, (x,y,u,v) in bounds.items()}
                data[row['name'].split('-')[0]] = dict(frame=sample, regions=metrics)
            check.append(data)
        pairs[kind] = check
    result = dict(status='same-camera-archived-scene-display-comparison', gameFrame=3534,
        gameResource=save['data']['rid'], gameBackbufferReceipt=sha(capture_receipt),
        camera={key:p[key] for key in stable_keys}, rectangles=bounds, pairs=comparisons,
        frames={k:{'file':str(path),'sha256':sha(path),'size':list(frame[k].shape[:2][::-1])}
                for k,path in snapshots.items()},
        playerManifests={str(path/'capture_manifest.json'):sha(path/'capture_manifest.json')
                         for path in (production,disabled,recent,projected)},
        historicalReflectionPair=dict(receipt=sha(paired/'full-capture-summary.json'), player=reports['playerSha256'],
                                      levels=frozen_algorithm_pairs(), byScene=pairs),
        conditions=dict(irradiancePair='irradianceVolume.enabled only',
            projectedArchive='same camera; scene, program and captures from independent archive',
            medianMatched='diagnostic scaling of each display-luma region by the ratio of medians'),
        scope='Archived outputs and display values. Direct display metrics carry the original acceptance gates.')
    out.mkdir(exist_ok=True)
    (out/'results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    for pair, regions in comparisons.items():
        print(pair, [(region,round(v['ssim'],4),round(v['meanAbsByte'],3),
                      round(v['medianLumaRelativeError'],4) if v['medianLumaRelativeError'] is not None else None)
                      for region,v in regions.items()])
    for kind, records in pairs.items():
        print(kind, [[(round(row[mode]['regions'][r]['ssim'], 4), round(row[mode]['regions'][r]['meanAbsByte'],3))
                      for row in records for mode in ('linear','projected')]
                     for r in ('centerFloor','cyanRing')])


if __name__ == '__main__':
    main()
