"""Preserve the fixed-camera scene and paired reflection measurements."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
import runpy
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


M = Path(__file__).resolve().parent
score = M / 'score-joint-native-floor.py'
inputs = runpy.run_path(str(score), run_name='floor_provenance')
out = inputs['out']
target = M.parents[2] / 'docs/acceptance/nr/evidence/2026-11-16/joint-scene-native-floor'
read = inputs['read']
sha = inputs['sha']

result = read(out/'results.json')
assert result['status'] == 'same-camera-archived-scene-display-comparison'
assert result['gameFrame'] == 3534 and result['gameResource'] == 'ResourceId::406'
assert result['historicalReflectionPair']['levels'] == inputs['frozen_algorithm_pairs']()
for record in result['frames'].values():
    assert sha(Path(record['file'])) == record['sha256']
for name, digest in result['playerManifests'].items():
    assert sha(Path(name)) == digest
assert result['pairs']['registeredCapture:irradianceEnabled']['complete']['exactPixels'] == 3_686_400 - 228
for kind in ('environment','actor'):
    records = result['historicalReflectionPair']['byScene'][kind]
    assert len(records) == 3
    for row in records:
        for region in ('centerFloor','cyanRing'):
            before, after = [row[mode]['regions'][region] for mode in ('linear','projected')]
            assert before['ssim'] < after['ssim'] < .95
            assert before['meanAbsByte'] > after['meanAbsByte']

receipt = inputs['capture']/'Endfield-games-child_frame3534-backbuffer-receipt.json'
assert sha(receipt) == result['gameBackbufferReceipt']
files = {'analysis.py':score, 'archive.py':Path(__file__).resolve(), 'native-backbuffer-receipt.json':receipt,
         'reflection-full-projects.json':inputs['paired']/'full-projects.json',
         'reflection-full-captures.json':inputs['paired']/'full-capture-summary.json',
         'fixed-floor-regions.json':inputs['joint']/'floor-fixed-results.json'}
for key in ('production','disabled','recent','projected'):
    files[f'{key}-manifest.json'] = inputs[key]/'capture_manifest.json'
target.mkdir(parents=True, exist_ok=True)
with ZipFile(target/'validation.zip', 'w', compression=ZIP_DEFLATED) as archive:
    for name, path in sorted(files.items()):
        archive.writestr(ZipInfo(name, (2026, 11, 16, 0, 0, 0)), path.read_bytes(), compress_type=ZIP_DEFLATED)
with ZipFile(target/'validation.zip') as archive:
    assert archive.testzip() is None
    members = {name:sha256(archive.read(name)).hexdigest() for name in archive.namelist()}
assert members == {name:sha(path) for name,path in files.items()}
result['archive'] = dict(sha256=sha(target/'validation.zip'), members=members)
(target/'results.json').write_text(json.dumps(result,indent=2)+'\n', encoding='utf8')
print(f"{len(members)} verified files; complete, central floor and cyan ring gates remain open")
