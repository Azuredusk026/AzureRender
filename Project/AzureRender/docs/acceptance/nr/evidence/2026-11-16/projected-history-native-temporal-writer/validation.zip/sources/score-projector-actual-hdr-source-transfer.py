"""Compare measured prior and current HDR source colors at the same 74 locations."""
from pathlib import Path
from hashlib import sha256
import json
import numpy as np

M=Path(__file__).resolve().parent
N=M/'projected-history-native-lineage/results.json'
P=M/'projected-history-player-lineage/results.json'
T=M/'projected-history-native-temporal-writer/results.json'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
n,p,t=map(read,(N,P,T))
assert t['status']=='qualified-native-history-temporal-writer-bindings'
assert n['priorColor']==t['events']['11195']['read']['4']['resource']['resource']
nativeTemporal=t['events']['11195']['targets'][0]['resource']
main='ResourceId::175'
last='27513'
a=p['mainTargets'][main]
assert '27531' in [str(r['event']) for r in a['readersAfterFinalWrite'] if r['usage']=='ResourceUsage.PS_Resource']
assert last==max(a['writes'],key=int)
inputs=n['samples']
samples=p['snapshot']['samples']
assert len(inputs)==len(samples)==74
assert [q['pixel'] for q in inputs]==[q['previousPixelXY'] for q in samples]
assert all(x['playerHdr']==y['previousColor'][:3] for x,y in zip(inputs,samples))
assert all(y['previousColor']==y['currentColor'] for y in samples)
keys=('nativePrevious','nativeTemporal','playerOpaque','playerLastMain')
def rgb(q):return np.asarray(q,float)[:,:3]
sources={k:rgb(v) for k,v in zip(keys,(
    [q['nativeHdr'] for q in inputs],
    [q['candidateHdrByResource'][nativeTemporal] for q in inputs],
    [q['playerHdr'] for q in inputs],
    a['writes'][last]['colors']))}
def compress(q):return np.maximum(0,q/(1+q.max(axis=1,keepdims=True)))
weights=np.array([.2126,.7152,.0722])
vals={k:compress(v)@weights for k,v in sources.items()}
out={}
subsets={'all':np.ones(len(inputs),bool),'glyphOnly':np.array([q['drawEvents']==[10480] for q in inputs]),
    'boxesWithoutGlyph':np.array([10480 not in q['drawEvents'] and len(q['drawEvents'])>0 for q in inputs]),
    'both':np.array([10480 in q['drawEvents'] and len(q['drawEvents'])>1 for q in inputs])}
for label,use in subsets.items():
 cases={}
 for r in ('nativePrevious','nativeTemporal'):
  before=abs(vals['playerOpaque']-vals[r])
  after=abs(vals['playerLastMain']-vals[r])
  counts=dict(samples=int(use.sum()),improved=int((use&(after+1e-8<before)).sum()),
    worsened=int((use&(after>before+1e-8)).sum()),unchanged=int((use&(abs(after-before)<=1e-8)).sum()))
  if counts['samples']:
   counts.update(meanAbsolute=[float(before[use].mean()),float(after[use].mean())],
    highError=[int((use&(before>.10)).sum()),int((use&(after>.10)).sum())])
  assert counts['samples']==counts['improved']+counts['worsened']+counts['unchanged']
  cases[r]=counts
 out[label]=cases
scope='Same-address HDR attachment comparison; temporal history and current color can have different visibility and times. This is not a replay of native temporal accumulation.'
q=dict(status='compared-actual-hdr-attachment-sources',scope=scope,
  nativeTemporal={'event':11195,'resource':nativeTemporal},playerLastMain={'event':int(last),'resource':main,'sha256':a['writes'][last]['sha256']},
  inputs={f.name+':'+f.parent.name:sha(f) for f in (N,P,T)},grouped=out,
  points=[dict(point=pt['pixel'],draws=pt['drawEvents'],hdr={k:v[i].tolist() for k,v in sources.items()}) for i,pt in enumerate(inputs)])
(M/'projected-history-native-temporal-writer/hdr-source-comparison.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(json.dumps(out))

