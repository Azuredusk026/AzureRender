"""Identify the actual native temporal writer sharing the reflection input."""
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

KEY='AZR_QA_NATIVE_HISTORY_TAA'
M=Path(os.environ[KEY]).resolve().parents[1] if KEY in os.environ else Path(__file__).resolve().parent
OUT=M/'projected-history-native-temporal-writer'
read=lambda p:json.loads(Path(p).read_bytes())
write=lambda p,q:Path(p).write_text(json.dumps(q,indent=2,allow_nan=False)+'\n',encoding='utf8')
hash_bytes=lambda b:sha256(b).hexdigest()
digest=lambda p:hash_bytes(Path(p).read_bytes())


def inputs():
    p=M/'projected-history-native-lineage'
    r=read(p/'results.json')
    q=read(p/'request.json')
    assert r['status']=='qualified-current-native-contribution'
    assert q['request']['event']==8702 and r['priorColor']=='ResourceId::14664'
    uses=r['activeHalfColorAttachments'][r['priorColor']]['usage']
    assert [u['event'] for u in uses]==[8702,8713,8723,11195]
    assert uses[-1]['usage']=='ResourceUsage.PS_Resource'
    next_image,=[v for v,u in r['lateFullResHalfColorStages'].items() if u['event']==11195]
    known=read(M/'projected-history-box-player-readback/results.json')
    assert known['status']=='qualified-player-crate-current-snapshot'
    points=[x['known']['previousPixelXY'] for x in known['points']]
    return dict(capture=q['request']['capture'],prior=r['priorColor'],priorSha256=r['priorColorSha256'],
        nextImage=next_image,nextImageSha256=r['lateFullResHalfColorStages'][next_image]['sha256'],
        sourceCapture=digest(p/'results.json'),proof=digest(M/'projected-history-box-player-readback/results.json'),
        points=points,expected=[x['nativeEarlier'] for x in known['points']],
        events=[11045,11072,11081,11099,11108,11117,11127,11195,11205,11359])


def replay(path):
    import renderdoc as rd
    plan=read(path)
    result=dict(status='unqualified',request=digest(path))
    c=None; cap=rd.OpenCaptureFile()
    try:
        write(OUT/'progress.json',dict(stage='open'))
        assert cap.OpenFile(plan['capture'],'',None)==rd.ResultCode.Succeeded
        status,c=cap.OpenCapture(rd.ReplayOptions(),None)
        assert status==rd.ResultCode.Succeeded and str(c.GetAPIProperties().pipelineType)=='GraphicsAPI.D3D11'
        t={str(x.resourceId):x for x in c.GetTextures()}
        names={str(x.resourceId):x.name for x in c.GetResources()}
        points=plan['points']
        def sample(name):
            if name not in t:return None
            target=t[name]
            if not (target.width,target.height)==(2560,1440):return None
            return [list(c.PickPixel(target.resourceId,x,1439-y,rd.Subresource(),rd.CompType.Typeless).floatValue) for x,y in points]
        def identify(r):
            s=str(r); z=t.get(s)
            return dict(resource=s,format=z.format.Name() if z else None,
                        size=[z.width,z.height] if z else None,name=names.get(s))
        def describe(rs,reflection):
            names={}
            for x in rs:
                entry=reflection[x.access.index]
                key=str(entry.fixedBindNumber)
                assert key not in names
                names[key]=dict(resource=identify(x.descriptor.resource),name=entry.name)
            return names
        rows={}
        for e in plan['events']:
            write(OUT/'progress.json',dict(stage='event',event=e))
            c.SetFrameEvent(e,True)
            pipe=c.GetPipelineState()
            sh=c.GetPipelineState().GetShaderReflection(rd.ShaderStage.Compute)
            stage=rd.ShaderStage.Compute
            if e==11195:
                stage=rd.ShaderStage.Pixel
                sh=pipe.GetShaderReflection(stage)
            assert sh is not None
            used=describe(pipe.GetReadOnlyResources(stage),sh.readOnlyResources)
            output=describe(pipe.GetReadWriteResources(stage),sh.readWriteResources)
            rtv=[identify(x.resource) for x in pipe.GetOutputTargets() if x.resource!=rd.ResourceId.Null()]
            blocks={}
            for i,b in enumerate(sh.constantBlocks):
                slot=b.fixedBindNumber
                block=pipe.GetConstantBlock(stage,i,0)
                d=block.descriptor
                n=min(1024,d.byteSize)
                if n>0 and d.resource!=rd.ResourceId.Null():
                    payload=bytes(c.GetBufferData(d.resource,d.byteOffset,n))
                    blocks[str(slot)]=dict(name=b.name, binding=str(d.resource),offset=d.byteOffset,
                        bytes=d.byteSize,payloadHex=payload.hex(),sha256=hash_bytes(payload))
            row=dict(stage=str(stage),hash=hash_bytes(bytes(sh.rawBytes)), read=used,write=output,
                targets=rtv,constants=blocks)
            if e in (11127,11195):
                asm=c.DisassembleShader(pipe.GetGraphicsPipelineObject() if e==11195 else pipe.GetComputePipelineObject(),sh,'')
                assert asm and len(asm)<300_000
                file=OUT/('event-'+str(e)+'.asm')
                file.write_text(asm,encoding='utf8')
                row['disassembly']=digest(file)
            if e==11195:
                assert len(rtv)==1 and rtv[0]['resource']==plan['nextImage']
                assert sum(x['resource']['resource']==plan['prior'] for x in used.values())==1
                assert sample(plan['prior'])==plan['expected']
                rw=t[plan['nextImage']]
                assert hash_bytes(bytes(c.GetTextureData(rw.resourceId,rd.Subresource())))==plan['nextImageSha256']
                row['sampledSources']={slot:sample(entry['resource']['resource']) for slot,entry in used.items() 
                                       if entry['resource']['format'] not in ['R32_FLOAT','D32_FLOAT']}
                row['samples']=sample(plan['nextImage'])
            rows[str(e)]=row
        result.update(status='qualified-native-history-temporal-writer-bindings',events=rows)
    except BaseException:
        result['error']=traceback.format_exc()
    finally:
        write(OUT/'results.json',result)
        if c is not None:c.Shutdown()
        cap.Shutdown()
    os._exit(0 if result['status'].startswith('qualified') else 1)


def run():
    lock=read('D:/Projects/FYP-coordination/resources/current.json')
    assert lock['state']=='held' and Path(lock['output'])==M
    sys.path.insert(0,str(M.parents[2]/'tools'))
    from artifact_budget import check
    assert check(M.parents[1],run=M,planned=1_200_000)['allowed']
    OUT.mkdir(exist_ok=True)
    p=OUT/'request.json'
    write(p,inputs())
    start=subprocess.STARTUPINFO()
    start.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    start.wShowWindow=0
    with (OUT/'replay.log').open('wb') as log:
        r=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe',
            '--python',str(Path(__file__).resolve())],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
            cwd=OUT,env=dict(os.environ,**{KEY:str(p)}),timeout=200,startupinfo=start)
    q=read(OUT/'results.json')
    assert r.returncode==0 and q['status'].startswith('qualified') and q['request']==digest(p),q.get('error')
    e=q['events']['11195']
    print(e['hash'],e['read'],e['targets'],flush=True)


if KEY in os.environ:
    replay(os.environ[KEY])
elif __name__=='__main__':
    if sys.argv[1:]==['preflight']:print(inputs())
    else:run()

