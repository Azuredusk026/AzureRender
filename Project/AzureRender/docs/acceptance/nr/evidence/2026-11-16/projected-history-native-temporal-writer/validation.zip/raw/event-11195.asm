Shader hash 10a3f2f8-4518c548-bc519098-e9ac7b87

ps_5_0
      dcl_globalFlags refactoringAllowed
      dcl_immediateConstantBuffer {
			{ 27, 0, 0, 0}, 
			{ 54, 0, 0, 0}, 
			{ 216, 0, 0, 0}, 
			{ 432, 0, 0, 0} }
      dcl_constantbuffer cb0[27], immediateIndexed
      dcl_constantbuffer cb1[12], immediateIndexed
      dcl_sampler s0, mode_default
      dcl_sampler s1, mode_default
      dcl_resource_texture2d (float,float,float,float) t0
      dcl_resource_texture2d (float,float,float,float) t1
      dcl_resource_texture2d (float,float,float,float) t2
      dcl_resource_texture2d (float,float,float,float) t3
      dcl_resource_texture2d (float,float,float,float) t4
      dcl_input_ps_siv linear noperspective v0.xy, position
      dcl_output o0.xyzw
      dcl_temps 23
   0: mul r0.xy, v0.xyxx, cb1[7].zwzz
   1: mul r0.zw, v0.xxxy, cb1[8].xxxy
   2: round_ni r1.xyzw, r0.zwzw
   3: ftoi r1.xyzw, r1.xyzw
   4: mad r0.zw, v0.xxxy, cb1[8].xxxy, -cb0[19].xxxy
   5: add r2.xy, l(-0.500000, -0.500000, 0.000000, 0.000000), cb1[6].xyxx
   6: max r0.zw, r0.zzzw, l(0.000000, 0.000000, 0.500000, 0.500000)
   7: min r0.zw, r2.xxxy, r0.zzzw
   8: round_ni r0.zw, r0.zzzw
   9: ftoi r2.xy, r0.zwzz
  10: add r0.zw, r0.zzzw, l(0.000000, 0.000000, 0.500000, 0.500000)
  11: mul r0.zw, r0.zzzw, cb1[6].zzzw
  12: sample_b(texture2d)(float,float,float,float) r0.z, r0.zwzz, t1.yzxw, s0, cb0[26].x
  13: mov r2.zw, l(0, 0, 0, 0)
  14: ld_indexable(texture2d)(float,float,float,float) r3.xyzw, r2.xyzw, t2.xyzw
  15: mad r2.zw, abs(r3.xxxy), l(0.000000, 0.000000, 2.000000, 2.000000), l(0.000000, 0.000000, -1.000000, -1.000000)
  16: mul r2.zw, r2.zzzw, r2.zzzw
  17: mul r2.zw, r2.zzzw, r2.zzzw
  18: add r4.xyzw, r3.xyww, l(-0.500000, -0.500000, -0.600000, -0.300000)
  19: lt r3.xy, l(0, 0, 0, 0), r4.xyxx
  20: lt r4.xy, r4.xyxx, l(0, 0, 0, 0)
  21: iadd r3.xy, -r3.xyxx, r4.xyxx
  22: itof r3.xy, r3.xyxx
  23: mul r2.zw, r2.zzzw, r3.xxxy
  24: mad r3.xy, v0.xyxx, cb1[7].zwzz, -r2.zwzz
  25: lt r0.w, l(0.900000), r3.w
  26: and r0.w, r0.w, l(1.000000)
  27: lt r4.xy, abs(r4.zwzz), l(0.100000, 0.100000, 0.000000, 0.000000)
  28: movc r1.xyzw, r4.xxxx, r1.xyzw, r2.xyxy
  29: ftoi r5.xyzw, cb1[6].xyxy
  30: iadd r6.xyzw, r1.zwzw, l(-1, -1, 0, -1)
  31: imax r6.xyzw, r6.xyzw, l(0, 0, 0, 0)
  32: imin r6.xyzw, r5.zwxy, r6.zwxy
  33: mov r7.xy, r6.zwzz
  34: mov r7.zw, l(0, 0, 0, 0)
  35: ld_indexable(texture2d)(float,float,float,float) r7.xyz, r7.xyzw, t0.xyzw
  36: min r7.xyz, -r7.xyzx, l(0, 0, 0, 0)
  37: dp3 r8.w, -r7.xzyx, l(1.000000, 1.000000, 2.000000, 0.000000)
  38: dp2 r9.y, -r7.xzxx, l(2.000000, -2.000000, 0.000000, 0.000000)
  39: dp3 r9.z, -r7.xzyx, l(-1.000000, -1.000000, 2.000000, 0.000000)
  40: mov r6.zw, l(0, 0, 0, 0)
  41: ld_indexable(texture2d)(float,float,float,float) r6.xyz, r6.xyzw, t0.xyzw
  42: min r6.xyz, -r6.xyzx, l(0, 0, 0, 0)
  43: dp3 r10.x, -r6.xzyx, l(1.000000, 1.000000, 2.000000, 0.000000)
  44: dp2 r10.y, -r6.xzxx, l(2.000000, -2.000000, 0.000000, 0.000000)
  45: dp3 r10.z, -r6.xzyx, l(-1.000000, -1.000000, 2.000000, 0.000000)
  46: iadd r11.xyzw, r1.zwzw, l(1, -1, -1, 0)
  47: imax r11.xyzw, r11.xyzw, l(0, 0, 0, 0)
  48: imin r11.xyzw, r5.zwxy, r11.zwxy
  49: mov r12.xy, r11.zwzz
  50: mov r12.zw, l(0, 0, 0, 0)
  51: ld_indexable(texture2d)(float,float,float,float) r12.xyz, r12.xyzw, t0.xyzw
  52: min r12.xyz, -r12.xyzx, l(0, 0, 0, 0)
  53: dp3 r13.x, -r12.xzyx, l(1.000000, 1.000000, 2.000000, 0.000000)
  54: dp2 r13.y, -r12.xzxx, l(2.000000, -2.000000, 0.000000, 0.000000)
  55: dp3 r13.z, -r12.xzyx, l(-1.000000, -1.000000, 2.000000, 0.000000)
  56: mov r11.zw, l(0, 0, 0, 0)
  57: ld_indexable(texture2d)(float,float,float,float) r11.xyz, r11.xyzw, t0.xyzw
  58: min r11.xyz, -r11.xyzx, l(0, 0, 0, 0)
  59: dp3 r14.x, -r11.xzyx, l(1.000000, 1.000000, 2.000000, 0.000000)
  60: dp2 r14.y, -r11.xzxx, l(2.000000, -2.000000, 0.000000, 0.000000)
  61: dp3 r14.z, -r11.xzyx, l(-1.000000, -1.000000, 2.000000, 0.000000)
  62: imax r2.xy, r1.zwzz, l(0, 0, 0, 0)
  63: imin r15.xy, r5.xyxx, r2.xyxx
  64: mov r15.zw, l(0, 0, 0, 0)
  65: ld_indexable(texture2d)(float,float,float,float) r15.xyz, r15.xyzw, t0.xyzw
  66: min r15.xyz, -r15.xyzx, l(0, 0, 0, 0)
  67: dp3 r16.x, -r15.xzyx, l(1.000000, 1.000000, 2.000000, 0.000000)
  68: dp2 r16.y, -r15.xzxx, l(2.000000, -2.000000, 0.000000, 0.000000)
  69: dp3 r16.z, -r15.xzyx, l(-1.000000, -1.000000, 2.000000, 0.000000)
  70: iadd r17.xyzw, r1.zwzw, l(1, 0, -1, 1)
  71: imax r17.xyzw, r17.xyzw, l(0, 0, 0, 0)
  72: imin r17.xyzw, r5.zwxy, r17.zwxy
  73: mov r18.xy, r17.zwzz
  74: mov r18.zw, l(0, 0, 0, 0)
  75: ld_indexable(texture2d)(float,float,float,float) r18.xyz, r18.xyzw, t0.xyzw
  76: min r18.xyz, -r18.xyzx, l(0, 0, 0, 0)
  77: dp3 r19.x, -r18.xzyx, l(1.000000, 1.000000, 2.000000, 0.000000)
  78: dp2 r19.y, -r18.xzxx, l(2.000000, -2.000000, 0.000000, 0.000000)
  79: dp3 r19.z, -r18.xzyx, l(-1.000000, -1.000000, 2.000000, 0.000000)
  80: mov r17.zw, l(0, 0, 0, 0)
  81: ld_indexable(texture2d)(float,float,float,float) r17.xyz, r17.xyzw, t0.xyzw
  82: min r17.xyz, -r17.xyzx, l(0, 0, 0, 0)
  83: dp3 r20.x, -r17.xzyx, l(1.000000, 1.000000, 2.000000, 0.000000)
  84: dp2 r20.y, -r17.xzxx, l(2.000000, -2.000000, 0.000000, 0.000000)
  85: dp3 r20.z, -r17.xzyx, l(-1.000000, -1.000000, 2.000000, 0.000000)
  86: iadd r1.xyzw, r1.xyzw, l(0, 1, 1, 1)
  87: imax r1.xyzw, r1.xyzw, l(0, 0, 0, 0)
  88: imin r1.xyzw, r5.zwxy, r1.zwxy
  89: mov r5.xy, r1.zwzz
  90: mov r5.zw, l(0, 0, 0, 0)
  91: ld_indexable(texture2d)(float,float,float,float) r5.xyz, r5.xyzw, t0.xyzw
  92: min r5.xyz, -r5.xyzx, l(0, 0, 0, 0)
  93: dp3 r21.x, -r5.xzyx, l(1.000000, 1.000000, 2.000000, 0.000000)
  94: dp2 r21.y, -r5.xzxx, l(2.000000, -2.000000, 0.000000, 0.000000)
  95: dp3 r21.z, -r5.xzyx, l(-1.000000, -1.000000, 2.000000, 0.000000)
  96: mov r1.zw, l(0, 0, 0, 0)
  97: ld_indexable(texture2d)(float,float,float,float) r1.xyz, r1.xyzw, t0.xyzw
  98: min r1.xyz, -r1.xyzx, l(0, 0, 0, 0)
  99: dp3 r22.x, -r1.xzyx, l(1.000000, 1.000000, 2.000000, 0.000000)
 100: dp2 r22.y, -r1.xzxx, l(2.000000, -2.000000, 0.000000, 0.000000)
 101: dp3 r22.z, -r1.xzyx, l(-1.000000, -1.000000, 2.000000, 0.000000)
 102: mul r6.xyz, -r6.xyzx, cb1[9].yyyy
 103: mad r6.xyz, -r7.xyzx, cb1[9].xxxx, r6.xyzx
 104: mad r6.xyz, -r12.xyzx, cb1[9].zzzz, r6.xyzx
 105: mad r6.xyz, -r11.xyzx, cb1[9].wwww, r6.xyzx
 106: mad r6.xyz, -r15.xyzx, cb1[10].xxxx, r6.xyzx
 107: mad r6.xyz, -r18.xyzx, cb1[10].yyyy, r6.xyzx
 108: mad r6.xyz, -r17.xyzx, cb1[10].zzzz, r6.xyzx
 109: mad r5.xyz, -r5.xyzx, cb1[10].wwww, r6.xyzx
 110: mad r1.xyz, -r1.xyzx, cb1[11].xxxx, r5.xyzx
 111: add r1.w, cb1[9].y, cb1[9].x
 112: add r1.w, r1.w, cb1[9].z
 113: add r1.w, r1.w, cb1[9].w
 114: add r1.w, r1.w, cb1[10].x
 115: add r1.w, r1.w, cb1[10].y
 116: add r1.w, r1.w, cb1[10].z
 117: add r1.w, r1.w, cb1[10].w
 118: add r1.w, r1.w, cb1[11].x
 119: div r1.w, l(1.000000, 1.000000, 1.000000, 1.000000), r1.w
 120: mul r1.xyz, r1.wwww, r1.xyzx
 121: dp3 r5.x, r1.xzyx, l(1.000000, 1.000000, 2.000000, 0.000000)
 122: mul r2.xy, r3.xyxx, cb1[7].xyxx
 123: mad r4.zw, r3.xxxy, cb1[7].xxxy, l(0.000000, 0.000000, -0.500000, -0.500000)
 124: round_ni r4.zw, r4.zzzw
 125: add r6.xyzw, r4.zwzw, l(0.500000, 0.500000, -0.500000, -0.500000)
 126: mad r7.xy, r3.yxyy, cb1[7].yxyy, -r6.yxyy
 127: mul r7.zw, r7.yyyx, r7.yyyx
 128: mul r11.xy, r7.yxyy, r7.zwzz
 129: mad r11.zw, r7.wwwz, r7.xxxy, r7.xxxy
 130: mad r11.zw, -r11.zzzw, l(0.000000, 0.000000, 0.500000, 0.500000), r7.wwwz
 131: mul r12.xy, r7.wzww, l(2.500000, 2.500000, 0.000000, 0.000000)
 132: mad r11.xy, r11.yxyy, l(1.500000, 1.500000, 0.000000, 0.000000), -r12.xyxx
 133: add r11.xy, r11.xyxx, l(1.000000, 1.000000, 0.000000, 0.000000)
 134: mad r7.xy, r7.zwzz, r7.yxyy, -r7.zwzz
 135: mul r7.zw, r7.xxxy, l(0.000000, 0.000000, 0.500000, 0.500000)
 136: add r12.xy, -r11.wzww, l(1.000000, 1.000000, 0.000000, 0.000000)
 137: add r12.xy, -r11.yxyy, r12.xyxx
 138: mad r7.xy, -r7.xyxx, l(0.500000, 0.500000, 0.000000, 0.000000), r12.xyxx
 139: add r11.xy, r7.yxyy, r11.xyxx
 140: mul r12.zw, r6.zzzw, cb1[7].zzzw
 141: div r6.zw, l(1.000000, 1.000000, 1.000000, 1.000000), r11.yyyx
 142: mad r6.xy, r7.xyxx, r6.zwzz, r6.xyxx
 143: mul r12.xy, r6.xyxx, cb1[7].zwzz
 144: add r4.zw, r4.zzzw, l(0.000000, 0.000000, 2.500000, 2.500000)
 145: mul_sat r6.xw, r4.zzzw, cb1[7].zzzw
 146: mul r4.zw, r11.zzzw, r11.yyyx
 147: mul r1.w, r11.x, r11.y
 148: mul r7.xy, r7.zwzz, r11.xyxx
 149: mov_sat r15.xyzw, r12.xwzy
 150: sample_l(texture2d)(float,float,float,float) r17.xyz, r15.xyxx, t4.xyzw, s1, l(0)
 151: dp3 r3.w, r17.xyzx, l(0.212600, 0.715200, 0.072200, 0.000000)
 152: add r3.w, r3.w, l(1.000000)
 153: div r17.xyz, r17.xyzx, r3.wwww
 154: sample_l(texture2d)(float,float,float,float) r15.xyz, r15.zwzz, t4.xyzw, s1, l(0)
 155: dp3 r3.w, r15.xyzx, l(0.212600, 0.715200, 0.072200, 0.000000)
 156: add r3.w, r3.w, l(1.000000)
 157: div r15.xyz, r15.xyzx, r3.wwww
 158: mul r15.xyz, r4.wwww, r15.xyzx
 159: mad r15.xyz, r17.xyzx, r4.zzzz, r15.xyzx
 160: mov_sat r11.zw, r12.xxxy
 161: sample_l(texture2d)(float,float,float,float) r17.xyz, r11.zwzz, t4.xyzw, s1, l(0)
 162: dp3 r3.w, r17.xyzx, l(0.212600, 0.715200, 0.072200, 0.000000)
 163: add r3.w, r3.w, l(1.000000)
 164: div r17.xyz, r17.xyzx, r3.wwww
 165: mad r15.xyz, r17.xyzx, r1.wwww, r15.xyzx
 166: mov_sat r6.yz, r12.yyxy
 167: sample_l(texture2d)(float,float,float,float) r12.xyz, r6.xyxx, t4.xyzw, s1, l(0)
 168: dp3 r1.w, r12.xyzx, l(0.212600, 0.715200, 0.072200, 0.000000)
 169: add r1.w, r1.w, l(1.000000)
 170: div r12.xyz, r12.xyzx, r1.wwww
 171: mad r12.xyz, r12.xyzx, r7.xxxx, r15.xyzx
 172: sample_l(texture2d)(float,float,float,float) r6.xyz, r6.zwzz, t4.xyzw, s1, l(0)
 173: dp3 r1.w, r6.xyzx, l(0.212600, 0.715200, 0.072200, 0.000000)
 174: add r1.w, r1.w, l(1.000000)
 175: div r6.xyz, r6.xyzx, r1.wwww
 176: mad r6.xyz, r6.xyzx, r7.yyyy, r12.xyzx
 177: add r1.w, r4.w, r4.z
 178: mad r1.w, r11.y, r11.x, r1.w
 179: mad r1.w, r7.z, r11.x, r1.w
 180: mad r1.w, r7.w, r11.y, r1.w
 181: div r1.w, l(1.000000, 1.000000, 1.000000, 1.000000), r1.w
 182: mul r6.xyz, r1.wwww, r6.xyzx
 183: sample_l(texture2d)(float,float,float,float) r7.xyzw, r3.xyxx, t4.xyzw, s1, l(0)
 184: dp3 r1.w, r6.xyzx, l(0.212600, 0.715200, 0.072200, 0.000000)
 185: add r1.w, -r1.w, l(1.000000)
 186: div r6.xyz, r6.xyzx, r1.wwww
 187: mul r11.xyzw, r7.xyzw, l(0.200000, 0.200000, 0.200000, 0.900000)
 188: mul r7.xyz, r7.xyzx, l(1.800000, 1.800000, 1.800000, 0.000000)
 189: max r6.xyz, r6.xyzx, r11.xyzx
 190: min r6.xyz, r7.xyzx, r6.xyzx
 191: dp3 r7.x, r6.xzyx, l(1.000000, 1.000000, 2.000000, 0.000000)
 192: dp2 r7.y, r6.xzxx, l(2.000000, -2.000000, 0.000000, 0.000000)
 193: dp3 r7.z, r6.xzyx, l(-1.000000, -1.000000, 2.000000, 0.000000)
 194: mad r1.w, r3.z, l(1023.000000), l(0.500000)
 195: ftou r1.w, r1.w
 196: ubfe r1.w, l(1), l(1), r1.w
 197: utof r1.w, r1.w
 198: frc r2.xy, r2.xyxx
 199: add r2.xy, -r2.xyxx, l(0.500000, 0.500000, 0.000000, 0.000000)
 200: add r2.xy, abs(r2.xyxx), abs(r2.xyxx)
 201: add r3.zw, l(0.000000, 0.000000, 1.000000, 1.000000), -cb1[7].zzzw
 202: lt r3.zw, r3.zzzw, r3.xxxy
 203: lt r3.xy, r3.xyxx, cb1[7].zwzz
 204: or r3.xz, r3.yywy, r3.xxzx
 205: or r3.x, r3.x, r3.z
 206: and r3.y, r3.x, l(1.000000)
 207: add r0.w, r0.w, cb1[5].x
 208: add_sat r0.w, r1.w, r0.w
 209: max r3.z, r8.w, r16.x
 210: min r3.w, r8.w, r16.x
 211: div r3.z, r3.z, r3.w
 212: lt r3.w, l(0), r3.z
 213: lt r3.z, r3.z, l(1.900000)
 214: and r3.z, r3.z, r3.w
 215: min r8.z, r8.w, l(100000.000000)
 216: mov r8.y, l(16)
 217: movc r6.yzw, r3.zzzz, l(0.000000, 0.000000, 100000.000000, 0.000000), r8.yyzw
 218: max r3.w, r10.x, r16.x
 219: min r4.z, r10.x, r16.x
 220: div r3.w, r3.w, r4.z
 221: lt r4.z, l(0), r3.w
 222: lt r3.w, r3.w, l(1.900000)
 223: and r3.w, r3.w, r4.z
 224: movc r6.x, r3.z, l(19), l(18)
 225: min r12.z, r10.x, r6.z
 226: max r12.w, r10.x, r6.w
 227: mov r12.y, r6.y
 228: movc r6.yzw, r3.wwww, r6.xxzw, r12.yyzw
 229: max r3.z, r13.x, r16.x
 230: min r3.w, r13.x, r16.x
 231: div r3.z, r3.z, r3.w
 232: lt r3.w, l(0), r3.z
 233: lt r3.z, r3.z, l(1.900000)
 234: and r3.z, r3.z, r3.w
 235: or r6.x, r6.y, l(20)
 236: min r12.z, r13.x, r6.z
 237: max r12.w, r13.x, r6.w
 238: mov r12.y, r6.y
 239: movc r6.yzw, r3.zzzz, r6.xxzw, r12.yyzw
 240: max r3.z, r14.x, r16.x
 241: min r3.w, r14.x, r16.x
 242: div r3.z, r3.z, r3.w
 243: lt r3.w, l(0), r3.z
 244: lt r3.z, r3.z, l(1.900000)
 245: and r3.z, r3.z, r3.w
 246: or r6.x, r6.y, l(24)
 247: min r12.z, r14.x, r6.z
 248: max r12.w, r14.x, r6.w
 249: mov r12.y, r6.y
 250: movc r6.yzw, r3.zzzz, r6.xxzw, r12.yyzw
 251: max r3.z, r16.x, r19.x
 252: min r3.w, r16.x, r19.x
 253: div r3.z, r3.z, r3.w
 254: lt r3.w, l(0), r3.z
 255: lt r3.z, r3.z, l(1.900000)
 256: and r3.z, r3.z, r3.w
 257: or r6.x, r6.y, l(48)
 258: min r12.z, r19.x, r6.z
 259: max r12.w, r19.x, r6.w
 260: mov r12.y, r6.y
 261: movc r6.yzw, r3.zzzz, r6.xxzw, r12.yyzw
 262: max r3.z, r16.x, r20.x
 263: min r3.w, r16.x, r20.x
 264: div r3.z, r3.z, r3.w
 265: lt r3.w, l(0), r3.z
 266: lt r3.z, r3.z, l(1.900000)
 267: and r3.z, r3.z, r3.w
 268: or r6.x, r6.y, l(80)
 269: min r12.z, r20.x, r6.z
 270: max r12.w, r20.x, r6.w
 271: mov r12.y, r6.y
 272: movc r6.yzw, r3.zzzz, r6.xxzw, r12.yyzw
 273: max r3.z, r16.x, r21.x
 274: min r3.w, r16.x, r21.x
 275: div r3.z, r3.z, r3.w
 276: lt r3.w, l(0), r3.z
 277: lt r3.z, r3.z, l(1.900000)
 278: and r3.z, r3.z, r3.w
 279: or r6.x, r6.y, l(144)
 280: min r12.z, r21.x, r6.z
 281: max r12.w, r21.x, r6.w
 282: mov r12.y, r6.y
 283: movc r6.yzw, r3.zzzz, r6.xxzw, r12.yyzw
 284: max r3.z, r16.x, r22.x
 285: min r3.w, r16.x, r22.x
 286: div r3.z, r3.z, r3.w
 287: lt r3.w, l(0), r3.z
 288: lt r3.z, r3.z, l(1.900000)
 289: and r3.z, r3.z, r3.w
 290: or r6.x, r6.y, l(272)
 291: min r8.y, r22.x, r6.z
 292: max r8.z, r22.x, r6.w
 293: mov r8.x, r6.y
 294: movc r6.xyz, r3.zzzz, r6.xzwx, r8.xyzx
 295: lt r3.z, r6.z, r16.x
 296: lt r3.w, r16.x, r6.y
 297: or r3.z, r3.w, r3.z
 298: if_nz r3.z
 299:   mov r3.zw, l(0, 0, 0, 0)
 300:   loop
 301:     ilt r4.z, r3.w, l(4)
 302:     if_nz r4.z
 303:       and r4.z, r6.x, icb[r3.w + 0].x
 304:       ieq r4.z, r4.z, icb[r3.w + 0].x
 305:       if_nz r4.z
 306:         mov r3.z, l(-1)
 307:         break
 308:       endif
 309:       iadd r3.w, r3.w, l(1)
 310:       mov r3.z, l(0)
 311:       continue
 312:     else
 313:       mov r3.z, l(0)
 314:       break
 315:     endif
 316:     mov r3.z, l(0)
 317:   endloop
 318:   movc r3.z, r3.z, l(0), l(1.000000)
 319: else
 320:   mov r3.z, l(0)
 321: endif
 322: max r3.z, r11.w, r3.z
 323: sample_l(texture2d)(float,float,float,float) r0.x, r0.xyxx, t3.xyzw, s1, l(0)
 324: lt r0.x, l(0), r0.x
 325: movc r0.x, r0.x, l(0), l(1.000000)
 326: add r0.x, -r0.w, r0.x
 327: movc r0.y, r3.x, l(-1.000000), l(0x80000000)
 328: add r0.x, r0.y, r0.x
 329: add r0.x, r0.x, -cb1[1].w
 330: add r0.y, abs(r2.w), abs(r2.z)
 331: lt r0.y, l(0.300000), r0.y
 332: movc r0.y, r0.y, l(-1.000000), l(0x80000000)
 333: add r0.x, r0.y, r0.x
 334: movc r0.y, r4.x, l(-1.000000), l(0x80000000)
 335: add r0.x, r0.y, r0.x
 336: add r0.x, r0.x, -cb1[2].w
 337: max r0.x, r0.x, l(0)
 338: mul r0.x, r0.x, r3.z
 339: ge r0.y, r0.x, l(0.100000)
 340: and r0.y, r0.y, l(1.000000)
 341: mov r9.x, r8.w
 342: mul r6.xyz, r10.xyzx, r10.xyzx
 343: mad r6.xyz, r9.xyzx, r9.xyzx, r6.xyzx
 344: add r8.xyz, r9.xyzx, r10.xyzx
 345: mad r6.xyz, r13.xyzx, r13.xyzx, r6.xyzx
 346: add r8.xyz, r13.xyzx, r8.xyzx
 347: mad r6.xyz, r14.xyzx, r14.xyzx, r6.xyzx
 348: add r8.xyz, r14.xyzx, r8.xyzx
 349: mad r6.xyz, r16.xyzx, r16.xyzx, r6.xyzx
 350: add r8.xyz, r16.xyzx, r8.xyzx
 351: mad r6.xyz, r19.xyzx, r19.xyzx, r6.xyzx
 352: add r8.xyz, r19.xyzx, r8.xyzx
 353: mad r6.xyz, r20.xyzx, r20.xyzx, r6.xyzx
 354: add r8.xyz, r20.xyzx, r8.xyzx
 355: mad r6.xyz, r21.xyzx, r21.xyzx, r6.xyzx
 356: add r8.xyz, r21.xyzx, r8.xyzx
 357: mad r6.xyz, r22.xyzx, r22.xyzx, r6.xyzx
 358: add r8.xyz, r22.xyzx, r8.xyzx
 359: mul r9.xyz, r8.xyzx, l(0.111111, 0.111111, 0.111111, 0.000000)
 360: mul r9.xyz, r9.xyzx, r9.xyzx
 361: mad r6.xyz, r6.xyzx, l(0.111111, 0.111111, 0.111111, 0.000000), -r9.xyzx
 362: sqrt r6.xyz, abs(r6.xyzx)
 363: add r9.xyz, r6.xyzx, l(-20.000000, -20.000000, -20.000000, 0.000000)
 364: mul_sat r9.xyz, r9.xyzx, l(0.050000, 0.050000, 0.050000, 0.000000)
 365: mad r10.xyz, r9.xyzx, l(-2.000000, -2.000000, -2.000000, 0.000000), l(3.000000, 3.000000, 3.000000, 0.000000)
 366: mul r9.xyz, r9.xyzx, r9.xyzx
 367: mul r9.xyz, r9.xyzx, r10.xyzx
 368: mad r9.xyz, -r9.xyzx, l(0.700000, 0.700000, 0.700000, 0.000000), l(1.250000, 1.250000, 1.250000, 0.000000)
 369: mul r6.xyz, r6.xyzx, r9.xyzx
 370: mad r9.xyz, r8.xyzx, l(0.111111, 0.111111, 0.111111, 0.000000), -r6.xyzx
 371: min r9.xyz, r16.xyzx, r9.xyzx
 372: mad r6.xyz, r8.xyzx, l(0.111111, 0.111111, 0.111111, 0.000000), r6.xyzx
 373: max r6.xyz, r16.xyzx, r6.xyzx
 374: max r8.xyz, r7.xyzx, r9.xyzx
 375: min r6.xyz, r6.xyzx, r8.xyzx
 376: movc r3.x, r3.x, l(0), r0.y
 377: add r7.xyz, -r6.xyzx, r7.xyzx
 378: mad r3.xzw, r3.xxxx, r7.xxyz, r6.xxyz
 379: dp2 r5.y, r1.xzxx, l(2.000000, -2.000000, 0.000000, 0.000000)
 380: dp3 r5.z, r1.xzyx, l(-1.000000, -1.000000, 2.000000, 0.000000)
 381: add r1.xyz, -r16.xyzx, r5.xyzx
 382: mad r1.xyz, r1.wwww, r1.xyzx, r16.xyzx
 383: add r1.w, r1.x, l(1.000000)
 384: div r1.xyz, r1.xyzx, r1.wwww
 385: add r1.w, r3.x, l(1.000000)
 386: div r3.xzw, r3.xxzw, r1.wwww
 387: mad r1.w, abs(r2.w), cb0[18].y, abs(r2.z)
 388: and r2.zw, r4.xxxy, l(0.000000, 0.000000, 1.000000, 1.000000)
 389: mad r0.z, r0.z, l(256.000000), l(-1.000000)
 390: mad r0.z, r2.w, r0.z, l(1.000000)
 391: add r2.w, -cb1[3].y, cb1[3].z
 392: mad r0.z, r1.w, r0.z, -cb1[3].y
 393: div r1.w, l(1.000000, 1.000000, 1.000000, 1.000000), r2.w
 394: mul_sat r0.z, r0.z, r1.w
 395: mad r1.w, r0.z, l(-2.000000), l(3.000000)
 396: mul r0.z, r0.z, r0.z
 397: mul r0.z, r0.z, r1.w
 398: add r1.w, -cb1[0].z, cb1[0].w
 399: mad r0.z, r0.z, r1.w, cb1[0].z
 400: max r1.w, r2.y, r2.x
 401: add r2.x, -r0.z, l(0.820000)
 402: mad r0.z, r1.w, r2.x, r0.z
 403: add r1.w, r2.z, r3.y
 404: add_sat r1.w, r1.w, cb1[2].w
 405: add r2.x, -r0.z, cb1[4].x
 406: mad r0.z, r1.w, r2.x, r0.z
 407: add r1.w, -r0.z, cb1[2].z
 408: mad r0.z, r0.w, r1.w, r0.z
 409: add r0.w, -r0.z, l(0.900000)
 410: mad r0.y, r0.y, r0.w, r0.z
 411: add r2.xyz, -r1.xyzx, r3.xzwx
 412: mad r0.yzw, r0.yyyy, r2.xxyz, r1.xxyz
 413: add r1.x, -r0.y, l(1.000000)
 414: max r1.x, r1.x, l(0.001000)
 415: div r0.yzw, r0.yyzw, r1.xxxx
 416: mul r1.xyz, r0.yzwy, l(0.250000, 0.250000, 0.250000, 0.000000)
 417: add r2.yz, r1.yyzy, r1.xxxx
 418: mad r2.x, -r0.w, l(0.250000), r2.y
 419: mad r0.y, r0.y, l(0.250000), -r1.y
 420: mad r2.w, -r0.w, l(0.250000), r0.y
 421: max o0.xyz, r2.xzwx, l(0, 0, 0, 0)
 422: mov o0.w, r0.x
 423: ret
