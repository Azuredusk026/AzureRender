"""Verify the original model controls and the complete Player body captures."""
import json
from hashlib import sha256
from pathlib import Path
import sqlite3
import sys
from zipfile import ZIP_DEFLATED, ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
input=M/'joint-character-referenced-body'
render=M/'character-six-view-inputs'
out=M.parents[2]/'docs/acceptance/nr/evidence/2026-11-16'/input.name
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
cx=sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True)
files={}
runs={}
delta={}
for dev,i in [('nvidia',1465),('intel',1470),('intel-repeat',int(sys.argv[1]))]:
    task,state,code,elapsed=cx.execute('select task,state,exit_code,run_seconds from jobs where id=?',(i,)).fetchone()
    assert (state,code)==('succeeded',0)
    result=read(input/f'{dev}-qualification.json')
    if dev!='intel-repeat':
        assert result['status']=='rendered-referenced-native-body-full-scene'
        assert result['identity']['changed']==0 and result['identity']['png']==result['identity']['referencePng']
        candidate=result['candidate']
        platform=dev
        variant=f'{dev}-native'
        leafs=(f'{dev}-identity',variant)
    else:
        candidate=result['repeat']
        platform='intel'
        variant='intel-native-repeat'
        leafs=(variant,)
    baseline=render/f'{platform}-back-detail/frames/frame_000000.png'
    a=cv2.imread(str(baseline),cv2.IMREAD_UNCHANGED)
    assert a.shape==(720,1280,4)
    assert digest(baseline)==candidate['referencePng']
    z=input/f'{variant}.zip'
    assert digest(z)==candidate['archive']
    with ZipFile(z) as archive:
        assert archive.testzip() is None
        b=a^np.frombuffer(archive.read('frame_000000.bgra-xor'),np.uint8).reshape(a.shape)
        assert sha256(b.tobytes()).hexdigest()==candidate['raw']
    d=np.abs(a.astype(np.int16)-b.astype(np.int16)).max(axis=2)
    assert [int((d>0).sum()),int((d>1).sum()),int(d.max())]==[candidate[k] for k in ('changed','overOne','peak')]
    delta[dev]=d
    for leaf in leafs:
        for p in ('command.json','runtime.json','result.json','frames/capture_manifest.json','frames/gpu_capabilities.json'):
            files[f'player/{leaf}/{p}']=input/leaf/p
        files[f'frames/{leaf}.zip']=input/f'{leaf}.zip'
    runs[dev]=dict(task=task,id=i,status=state,exitCode=code,elapsedSeconds=elapsed,
        baseline=candidate['referencePng'],difference=candidate)
    files[f'data/{dev}-qualification.json']=input/f'{dev}-qualification.json'
    files[f'logs/{dev}.log']=M/f'retest-joint-character-referenced-body-{dev}.log'
changed=lambda d,p: int((d[p[1]:p[3]+1,p[0]:p[2]+1]>1).sum())
shoulder=[718,270,733,275]
floor=[906,628,944,656]
metrics={dev:dict(bodyCrop=changed(d,shoulder),floorCrop=changed(d,floor),overOne=int((d>1).sum()))
          for dev,d in delta.items()}
metrics['overlap']=int(((delta['nvidia']>1)&(delta['intel']>1)).sum())
verify=read(input/'intel-repeat-qualification.json')
matches=runs['intel']['difference']['raw']==runs['intel-repeat']['difference']['raw']
assert verify['identical']==matches
assets={}
for name in ('identity','native'):
    path=input/f'{name}-asset.zip'
    with ZipFile(path) as archive:
        assert archive.testzip() is None and 'hero.gltf' in archive.namelist()
        doc=json.loads(archive.read('hero.gltf'))
        asset=dict(archive=digest(path),bufferCounts=len(doc['buffers']),views=len(doc['bufferViews']),
                   imageCount=len(doc['images']))
        if name=='native':
            assert archive.getinfo('body.bin').file_size==270884
            asset['newBodyBufferSha256']=sha256(archive.read('body.bin')).hexdigest()
        assets[name]=asset
    files[f'assets/{name}.zip']=path
for name in ('joint-character-referenced-body.py','build-animated-body-topology-candidate.py','archive-joint-character-referenced-body.py'):
    files[f'source/{name}']=M/name
out.mkdir(parents=True,exist_ok=True)
z=out/'validation.zip'
with ZipFile(z,'w',ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in files.items():
        archive.write(path,name)
with ZipFile(z) as archive:
    proof={name:sha256(archive.read(name)).hexdigest() for name in files}
    assert proof=={name:digest(p) for name,p in files.items()} and archive.testzip() is None
q=dict(status='verified-full-scene-native-body-candidate-frames',allVisualAcceptance=False,
       deviceSourceControlExact=True,repeatExact=matches,captures=runs,output=metrics,
       cropCoordinates={'body':shoulder,'floor':floor},assets=assets,
       frameCountPerCapture=1,validation=dict(archive=digest(z),members=proof))
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
print(metrics,matches,z.stat().st_size)
