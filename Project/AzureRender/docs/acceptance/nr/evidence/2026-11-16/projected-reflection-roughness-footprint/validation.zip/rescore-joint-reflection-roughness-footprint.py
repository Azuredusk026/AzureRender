"""Re-score both completed reflection captures after the dispatcher interrupted archiving."""
from hashlib import sha256
from pathlib import Path
import json
import re
import runpy
from zipfile import ZIP_DEFLATED, ZipFile

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

M=Path(__file__).resolve().parent
W=M.parents[2]
Q=M/'joint-projected-resolved-hdr-valid-steps'
O=M/'joint-reflection-roughness-footprint'
S=O/'nvidia'
E=W/'docs/acceptance/nr/evidence/2026-11-16/projected-reflection-roughness-footprint'
read=lambda path:json.loads(path.read_bytes())
h=lambda path:sha256(path.read_bytes()).hexdigest()
hdr=runpy.run_path(str(M/'capture-projected-resolved-history-samples.py'),run_name='roughness_retained_hdr')
H=runpy.run_path(str(M/'run-immutable-scene-glyph-capture.py'),run_name='roughness_native_fixture')
fixture=read(Q/'qualification.json')
native=H['S']['img'](H['gold']).astype(np.uint8)
assert fixture['immutable']==H['immutable_index']()
log=(S/'player.log').read_text(encoding='utf8',errors='replace')
assert 'Allocator after unload: buffers=0 images=0' in log
assert not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log,re.I)
rt=read(S/'runtime.json')
assert not rt['presentationErrors'] and not rt['scriptErrors']
caps=read(S/'frames/gpu_capabilities.json')
assert caps['vendor_id']==0x10de
manifest=read(S/'frames/capture_manifest.json')
assert manifest['capturedFrames']==2 and manifest['screenReflectionProducer']=='projected-history'
assert log.count('QA projected reflection uses submitted HDR resolve 1')==1
assert all(manifest[k]==read(Q/'nvidia/frames/capture_manifest.json')[k] for k in H['S']['forbid'])
sharpness=lambda data:float(np.std(cv2.Laplacian(cv2.cvtColor(data,cv2.COLOR_RGB2GRAY).astype(np.float32),cv2.CV_32F)))
rects=H['S']['regions']
score=H['S']['score']
comparisons=[]
E.mkdir(exist_ok=True)
with ZipFile(E/'validation.zip','w',ZIP_DEFLATED,compresslevel=9) as bundle:
    for path in [O/'reflection_spatial_filter.comp',M/'capture-joint-reflection-roughness-footprint.py',
                 Path(__file__),S/'command.json',S/'runtime.json',S/'player.log',
                 S/'frames/capture_manifest.json',S/'frames/gpu_capabilities.json',
                 O/'programs/reflection_spatial_filter.comp.spv']:
        bundle.write(path,path.relative_to(M).as_posix())
    for i in range(2):
        path=S/'frames'/f'frame_{i:06d}.png'
        data=path.read_bytes()
        assert data.endswith(b'\x00\x00\x00\x00IEND\xaeB\x60\x82')
        actual=cv2.imdecode(np.frombuffer(data,np.uint8),-1)
        assert actual.shape==(1440,2560,4)
        old=hdr['restored']('nvidia',i,actual.shape,fixture)
        delta=np.bitwise_xor(actual,old).tobytes()
        member=f'frame-{i}.bgra-xor'
        bundle.writestr(member,delta)
        base_rgb=cv2.cvtColor(old,cv2.COLOR_BGRA2RGB)
        result_rgb=cv2.cvtColor(actual,cv2.COLOR_BGRA2RGB)
        stats={}
        for r,(x,y,u,v) in rects.items():
            a,b,c=[t[y:v,x:u] for t in (base_rgb,result_rgb,native)]
            before,after=[np.abs(p.astype(np.int16)-c).max(2) for p in (a,b)]
            stats[r]=dict(control=score(a,c),candidate=score(b,c),
                highFrequency=[sharpness(t) for t in (c,a,b)],
                newOverOne=int(((before<=1)&(after>1)).sum()))
        comparisons.append(dict(sha256=h(path),raw=sha256(actual.tobytes()).hexdigest(),metrics=stats,
                                delta=sha256(delta).hexdigest(),member=member))
        print(i,{r:stats[r] for r in ('centerFloor','cyanRing')})
    cards=(native,base_rgb,result_rgb)
    image=Image.new('RGB',(1260,441),(23,24,26))
    draw=ImageDraw.Draw(image)
    font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',18)
    for n,(text,data) in enumerate(zip(('原生参考','已合成 HDR 历史对照','粗糙度过滤候选'),cards)):
        x=15+n*415
        p=Image.fromarray(data)
        draw.text((x,9),text,font=font,fill='white')
        image.paste(p.resize((402,226),Image.Resampling.LANCZOS),(x,40))
        image.paste(p.crop((970,964,1580,1190)).resize((402,149),Image.Resampling.LANCZOS),(x,277))
    image.save(E/'comparison.png')
with ZipFile(E/'validation.zip') as bundle:
    assert bundle.testzip() is None
    for row in comparisons:
        assert sha256(bundle.read(row['member'])).hexdigest()==row['delta']
out=dict(status='rescored-completed-nvidia-projected-reflection-filter',job=1622,
    dispatchResult='budget-stopped-after-completed-capture',candidatePrograms={p.name:h(p) for p in (O/'programs').glob('*.spv')},
    reference=h(H['gold']),captureManifest=h(S/'frames/capture_manifest.json'),frames=comparisons,validationArchive=h(E/'validation.zip'))
(E/'qualification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
