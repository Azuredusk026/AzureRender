"""Measure a roughness-dependent filter footprint in the actual joint scene."""
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json
import os
import runpy
import subprocess
import sys
import time

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
O=M/'joint-reflection-roughness-footprint'
Q=M/'joint-projected-resolved-hdr-valid-steps'
src=W/'shaders/reflection_spatial_filter.comp'
shader='reflection_spatial_filter.comp.spv'
trace='projected_reflection_trace.comp.spv'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
h=lambda p:sha256(p.read_bytes()).hexdigest()


def run(adapters):
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    from artifact_maintenance import database, rows, resume
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    b=check(W/'build',run=M,planned=7_400_000)
    assert b['allowed'],b
    original=read(Q/'qualification.json')
    assert original['historyValidOnly']
    hdr=runpy.run_path(str(M/'capture-projected-resolved-history-samples.py'),run_name='retained_reflection_color')
    H=runpy.run_path(str(M/'run-immutable-scene-glyph-capture.py'),run_name='joint_reflection_fixture')
    score=H['S']['score']
    native=H['S']['img'](H['gold']).astype(np.uint8)
    assert original['immutable']==H['immutable_index']()
    tree=H['tree_stamp']()
    O.mkdir(exist_ok=True)
    programs=O/'programs'
    programs.mkdir(exist_ok=True)
    modifiers=src.read_text('utf8')
    pattern='    float lod=clamp(surface.r,0,1)*parameters.rows[0].z;'
    assert modifiers.count(pattern)==1
    modifiers=modifiers.replace(pattern,pattern+'''
    bool projected=parameters.rows[3].x>.5&&parameters.rows[3].y==1.;
    if(projected)
        lod=min(lod+.65*smoothstep(.05,.9,lod),parameters.rows[0].z);''')
    pattern='        confidence=clamp(textureLod(confidencePyramid,uv,floor(lod)).r,0,1);'
    assert modifiers.count(pattern)==1
    modifiers=modifiers.replace(pattern,'''        float lower=floor(lod),upper=min(lower+1.,parameters.rows[0].z);
        float lowConfidence=textureLod(confidencePyramid,uv,lower).r;
        if(projected) {
            float highConfidence=textureLod(confidencePyramid,uv,upper).r;
            lowConfidence=mix(lowConfidence,highConfidence,lod-lower);
        }
        confidence=clamp(lowConfidence,0,1);''')
    candidate=O/src.name
    candidate.write_text(modifiers,encoding='utf8')
    config=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='reflection_footprint_programs')
    config['activate_links'].__wrapped__.__globals__['home']=O
    sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
    subprocess.run([str(sdk/'glslc.exe'),'--target-env=vulkan1.3','-O',str(candidate),'-o',str(programs/shader)],
                   check=True,timeout=45)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3',str(programs/shader)],check=True,timeout=45)
    if not (programs/trace).exists():
        (programs/trace).hardlink_to(Q/'programs'/trace)
    assert h(programs/trace)==original['program']
    expected={name:h(programs/name) for name in (shader,trace)}
    report={}
    sharpness=lambda x:float(np.std(cv2.Laplacian(cv2.cvtColor(x,cv2.COLOR_RGB2GRAY).astype(np.float32),cv2.CV_32F)))

    with database(W/'build') as d:
        pinned=rows(d)[R.name]
    assert pinned['status']=='closed'
    resume(W/'build',R.name)
    try:
        with config['activate_links'](expected):
            for gpu in adapters:
                out=O/gpu
                out.mkdir()
                args=read(Q/gpu/'command.json')
                assert args[args.index('--project')+1]==str(H['project'])
                for name,target in (('--capture-dir',out/'frames'),('--runtime-report',out/'runtime.json')):
                    args[args.index(name)+1]=str(target)
                results=[]
                token='AZR_NR_QA_PROJECTED_RESOLVED_HISTORY'
                assert token not in os.environ
                os.environ[token]='1'
                try:
                    with ThreadPoolExecutor(max_workers=1) as work:
                        capture=work.submit(H['S']['invoke'],gpu,args,out)
                        for i in range(2):
                            f=out/'frames'/f'frame_{i:06d}.png'
                            data=None
                            while data is None:
                                if f.is_file():
                                    try:
                                        attempt=f.read_bytes()
                                    except PermissionError:
                                        attempt=b''
                                    if attempt.endswith(b'\x00\x00\x00\x00IEND\xaeB\x60\x82'):
                                        data=attempt
                                if data is None:
                                    if capture.done():
                                        capture.result()
                                        if not f.is_file():raise RuntimeError(f'Capture did not publish {f}')
                                    time.sleep(.3)
                            actual=cv2.imdecode(np.frombuffer(data,np.uint8),-1)
                            assert actual.shape==(1440,2560,4)
                            base=hdr['restored'](gpu,i,actual.shape,original)
                            delta=np.bitwise_xor(base,actual)
                            slot=out/f'frame-{i}.xor.zip'
                            with ZipFile(slot,'x',ZIP_DEFLATED,compresslevel=9) as z:
                                z.writestr('bgra-xor',delta.tobytes())
                            with ZipFile(slot) as z:
                                assert z.testzip() is None
                                restored=base^np.frombuffer(z.read('bgra-xor'),np.uint8).reshape(base.shape)
                                assert np.array_equal(restored,actual)
                            assert h(f)==sha256(data).hexdigest() and f.resolve()==f and not f.stat().st_file_attributes&1024
                            f.unlink()
                            new=cv2.cvtColor(actual,cv2.COLOR_BGRA2RGB)
                            old=cv2.cvtColor(base,cv2.COLOR_BGRA2RGB)
                            metrics={}
                            for name,(x,y,u,v) in H['S']['regions'].items():
                                a,b,c=(p[y:v,x:u] for p in (old,new,native))
                                metrics[name]=dict(original=score(a,c),candidate=score(b,c),
                                    highFrequency=[sharpness(p) for p in (c,a,b)],
                                    changed=int(np.count_nonzero(np.any(a!=b,axis=2))))
                            results.append(dict(index=i,metrics=metrics,archive=h(slot),png=sha256(data).hexdigest()))
                            print(gpu,i,{r:metrics[r] for r in ('centerFloor','cyanRing')},flush=True)
                        capture.result()
                finally:
                    os.environ.pop(token)
                manifest=read(out/'frames/capture_manifest.json')
                assert manifest['screenReflectionProducer']=='projected-history' and manifest['capturedFrames']==2
                actual=read(out/'runtime.json')
                assert not actual['presentationErrors'] and not actual['scriptErrors']
                report[gpu]=results
                write(O/'qualification.json',dict(status='capturing',results=report))
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=460)
    with database(W/'build') as d:
        closure=rows(d)[R.name]
    assert closure['status']=='closed' and closure['manifestSha256']==pinned['manifestSha256']
    assert H['tree_stamp']()==tree and H['immutable_index']()==original['immutable']
    write(O/'qualification.json',dict(status='measured-projected-reflection-roughness-footprint',
        source=h(src),probe=h(candidate),programs=expected,results=report))


if __name__=='__main__':
    run(sys.argv[1:] or ['nvidia'])
