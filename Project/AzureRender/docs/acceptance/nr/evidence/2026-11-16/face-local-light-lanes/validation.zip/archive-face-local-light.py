"""Archive exact original face radiance across the local-light loop."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import struct
import sys
import zipfile

root=Path(__file__).resolve().parent
dest=root.parents[2]/'docs/acceptance/nr/evidence/2026-11-16/face-local-light-lanes'
scr=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d/native-face-skin-stages/pixel-804.txt'
data=root/'face-opaque-main-light-lanes/results.json'
score=root/'face-opaque-main-light-native-score.json'
get=lambda p:json.loads(p.read_bytes())
digest=lambda b:sha256(b).hexdigest()
names=('registers.json','constants-1.bin','constants-6.bin','blend-program.txt')


def compute(inputs):
    program=inputs[names[3]].decode('utf8')
    verify={887:'mov r20.xyz, r7.xyzx', 899:'mov r21.xyz, r20.xyzx', 1412:'mov r20.xyz, r21.xyzx',
        1415:'lt r1.x, l(0.500000), cb6[3].x', 1439:'mul r1.xyz, r20.xyzx, cb1[27].yyyy',
        1618:'mov o0.xyz, r1.xyzx'}
    for k,v in verify.items():
        key=str(k)+':'
        line,=[line for line in program.splitlines() if line.strip().startswith(key)]
        assert line.strip()[len(key):].strip()==v
    a,b=[list(struct.iter_unpack('<4f',inputs[n])) for n in names[1:3]]
    assert a[27][1]==1 and b[3][0]==0
    captures=json.loads(inputs[names[0]])
    rows={}
    for adapter,items in captures.items():
        out=[]
        for item in items:
            pre=tuple(item['beforeR20']); disp=tuple(item['mainR7'])
            post=tuple(item['afterR20']); at1600=tuple(item['preFinalFogR1'])
            end=tuple(item['finalR1'])
            assert pre==disp and post==at1600==end
            assert item['preFinalFogTransmittance']==[1.,1.,1.]
            native=tuple(item['nativePixelHistoryRgb'])
            assert max(abs(a-b) for a,b in zip(native,end,strict=True))<6e-6, (adapter,item['point'],native,end)
            terms=[max(abs(a-b) for a,b in zip(pre,item['measuredMainDiffuse'],strict=True))]
            mask='darkEdge' if item['point'] in [[1306,304],[1313,297],[1312,298]] else 'brightHoldout'
            assert mask==item['origin']
            local=[b-a for a,b in zip(pre,post,strict=True)]
            assert min(local)>0
            assert 0 < terms[0]<.02
            out.append(dict(point=item['point'],origin=mask,primitive=item['primitive'],beforeLocalLights=list(pre),
                afterLocalLights=list(post),localLightContribution=local,displayTransformBetweenStages='identity',
                measuredDirectDiffuseDifference=terms[0]))
        assert len(out)==6 and len({tuple(x['point']) for x in out})==6
        rows[adapter]=out
    assert set(rows)=={'nvidia','intel'}
    dark=[q['localLightContribution'][0] for a in rows.values() for q in a if q['origin']=='darkEdge']
    hold=[q['localLightContribution'][0] for a in rows.values() for q in a if q['origin']=='brightHoldout']
    assert min(dark)>1 and max(dark)<1.40 and min(hold)<.28
    return dict(beamWindow='native event 804 registers before and after the local-light loop',darkRedRange=[min(dark),max(dark)],
                brightRedRange=[min(hold),max(hold)],devices=rows)


def archive():
    proof=get(root/'trace-face-view-mask.json')
    tables={}
    for i in (1,6):
        b=(root/f'face-view-mask-cb{i}.bin').read_bytes()
        assert digest(b)==proof['constants'][str(i)]['sha256']
        tables[f'constants-{i}.bin']=b
    a,b=get(data),get(score)
    assert a['status']=='qualified' and b['source']==digest(data.read_bytes())
    paired={}
    for adapter,pixels in a['samples'].items():
        paired[adapter]=[]
        for x,y in zip(pixels,b['devices'][adapter],strict=True):
            assert x['point']==y['point'] and x['primitive']==y['primitive']
            r=lambda step,key: x['states'][str(step)][key][:3]
            paired[adapter].append(dict(point=x['point'],origin=x['origin'],primitive=x['primitive'],
                mainR7=r(831,'r7'),beforeR20=r(1000,'r20'),afterR20=r(1600,'r20'),preFinalFogR1=r(1600,'r1'),
                preFinalFogTransmittance=r(1600,'r3'),finalR1=r(1620,'r1'),nativePixelHistoryRgb=x['shaderRGB'],
                measuredMainDiffuse=y['mainDiffuse']))
    tables[names[0]]=json.dumps(paired,indent=2).encode()
    tables[names[3]]=scr.read_bytes()
    return tables,digest(data.read_bytes()),digest(score.read_bytes())


if sys.argv[1:]==['build']:
    inputs, a, b=archive()
    report=compute(inputs)
    report.update(status='native-face-scoped-local-light-radiance',captureTraceSha256=a,
                  directDiffuseProofSha256=b, inputs={k:digest(v) for k,v in inputs.items()})
    dest.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(dest/'validation.zip','w') as z:
        for k,v in sorted({**inputs,'archive-face-local-light.py':Path(__file__).read_bytes()}.items()):
            z.writestr(zipfile.ZipInfo(k,(2026,11,16,0,0,0)),v,zipfile.ZIP_DEFLATED,compresslevel=9)
    report['archiveSha256']=digest((dest/'validation.zip').read_bytes())
    (dest/'results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
else:
    assert sys.argv[1:]==['verify']
    q=get(dest/'results.json'); b=(dest/'validation.zip').read_bytes()
    assert digest(b)==q['archiveSha256']
    with zipfile.ZipFile(BytesIO(b)) as z:
        assert not z.testzip()
        got={k:z.read(k) for k in names}
    assert q['inputs']=={k:digest(v) for k,v in got.items()}
    test=compute(got)
    assert test=={k:q[k] for k in test}
    print(test['darkRedRange'],test['brightRedRange'],q['archiveSha256'])
