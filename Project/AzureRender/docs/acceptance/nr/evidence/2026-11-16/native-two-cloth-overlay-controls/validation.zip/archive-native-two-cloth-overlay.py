from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo
run=Path(__file__).resolve().parent
r=run.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/body-outline-cloth-composition'
native=run/'body-native-cloth-outline-geometry'
root=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-16/native-two-cloth-overlay-controls'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
d=read(native/'results.json'); score=run/'body-native-cloth-outline-topology.json'; rows=read(score)
assert d['status']=='qualified' and set(d['devices'])=={'nvidia','intel'}
assert [r['event'] for r in rows]==[1079,1116]
a,b=[row['triangleCompatibility']['2.5e-05'] for row in rows]
assert (a['unresolvedOwnedSkin'],b['unresolvedOwnedSkin'])==(20,5)
assert a['noCompatibleOwnedSkin']==b['noCompatibleOwnedSkin']==0
result=read(r/'results.json')
assert result['status']=='measured-combination'
files={'native/results.json':native/'results.json','native/request.json':native/'request.json',
       score.name:score,Path(__file__).name:Path(__file__),
       'score.py':run/'score-body-native-cloth-outline-topology.py','composition/results.json':r/'results.json',
       'composition/preflight.json':r/'preflight.json',
       'composition.py':r.parent/'body-outline-cloth-composition.py'}
assert set(result['devices'])=={'nvidia','intel'}
for tag,wanted in (('nvidia',(1002,5338,2640)),('intel',(1014,5315,2650))):
    row=result['devices'][tag]
    triple=row['combinedNewOverOne'],row['overEight']['origin']['wholeCloth1383'],row['overEight']['directional-ordered']['wholeCloth1383']
    assert triple==wanted
    for mode in ('packed','directional','directional-ordered'):
        key=f'{mode}-{tag}'
        loc=r/key
        files[f'composition/{key}/capture_manifest.json']=loc/'frames/capture_manifest.json'
        files[f'composition/{key}/gpu_capabilities.json']=loc/'frames/gpu_capabilities.json'
aggregate=dict(status='measured; strict thresholds open',productionCompositionAccepted=False,topology=rows,
               productionComposition=result)
root.mkdir(parents=True,exist_ok=True)
p=root/'validation.zip'
with ZipFile(p,'w') as z:
    for name,file in sorted(files.items()):
        i=ZipInfo(name,(2026,11,16,0,0,0));i.compress_type=ZIP_DEFLATED
        z.writestr(i,file.read_bytes())
with ZipFile(p) as z:
    assert z.testzip() is None
    assert all(sha256(z.read(k)).hexdigest()==sha(v) for k,v in files.items())
aggregate['archive']={'sha256':sha(p),'members':{name:sha(file) for name,file in files.items()}}
(root/'results.json').write_text(json.dumps(aggregate,indent=2)+'\n',encoding='utf8')
print(aggregate['archive']['sha256'])
