"""Recover the pre-extrusion geometry of the original cloth shell."""
from collections import Counter, defaultdict
import gzip
from hashlib import file_digest
from itertools import permutations
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image


run = Path(__file__).resolve().parent
grid = run.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
body = run.parent / '20261114-125923-body-lit-outline-depth-order-a29b63'
fixture = grid / 'iris-overlay-geometry-project/character'
candidate = run / 'body-outline-before-transparent-cloth/body-native-lit-outline-production-native-order.gltf'
retained = run / 'body-native-cloth-outline-geometry-trace-cleanup-failed'
original = run / 'body-native-cloth-outline-geometry'
width, height = 2560, 1440
native_color = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/post-opaque-ownership')


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def load_accessor(doc, accessor_number):
    accessor = doc['accessors'][accessor_number]
    view = doc['bufferViews'][accessor['bufferView']]
    lanes = {'VEC2': 2, 'VEC3': 3, 'SCALAR': 1}[accessor['type']]
    dtype = np.dtype({5126: '<f4', 5123: '<u2'}[accessor['componentType']])
    assert view.get('byteStride', lanes * dtype.itemsize) == lanes * dtype.itemsize
    buffer = fixture / doc['buffers'][view['buffer']]['uri']
    offset = view.get('byteOffset', 0) + accessor.get('byteOffset', 0)
    return np.fromfile(buffer, dtype, accessor['count'] * lanes, offset=offset).reshape(-1, lanes)


def clip_offset(clip, normal, constants):
    frame, viewport, material = (constants[n] for n in (0, 1, 3))
    camera_rows = frame[32:35]
    weights = normal @ camera_rows[:, :2]
    length = np.linalg.norm(weights, axis=1, keepdims=True)
    direction = np.divide(weights, length, out=np.zeros_like(weights), where=length != 0)
    assert viewport[1, 0] == width and viewport[1, 1] == height
    direction[:, 0] *= height / width
    angle_reciprocal = float(-1 / frame[9, 1])
    assert 0 < angle_reciprocal < 1
    square = angle_reciprocal ** 2
    angle = angle_reciprocal * (1 + square * (-.301895 + .087293 * square))
    scale = (math.pi / 8) / angle * material[12, 0]
    mask = np.clip(clip[:, 3] * angle * 4.583663, 0, 1)
    offset = .005 * direction * (scale * mask[:, None])
    maximum = ((math.pi / 2) / angle)
    limit = np.minimum(np.maximum(clip[:, 3], 0), maximum)[:, None] * viewport[1, 2:]
    return np.sign(offset) * np.maximum(np.abs(offset), limit)


def percentiles(values):
    finite = values[np.isfinite(values)]
    return np.percentile(finite, [0, 50, 95, 99, 100]).tolist() if finite.size else None


def map_vertices(world, original_uv, reference, candidate_uv):
    by_uv = defaultdict(list)
    scale = 100000
    candidate_keys = np.rint(candidate_uv.astype(float) * scale).astype(int)
    native_keys = np.rint(original_uv.astype(float) * scale).astype(int)
    for index, key in enumerate(candidate_keys):
        by_uv[tuple(key)].append(index)
    mapping = np.full(len(world), -1, dtype=int)
    errors = np.full(len(world), np.nan)
    uv_errors = np.full(len(world), np.nan)
    for index, (u, v) in enumerate(native_keys):
        matches = by_uv.get((u, v), [])
        if not matches:
            matches = [item for du in (-1, 0, 1) for dv in (-1, 0, 1)
                       for item in by_uv.get((u + du, v + dv), ())]
        if not matches:
            continue
        delta = np.linalg.norm(reference[matches] - world[index], axis=1)
        best = int(delta.argmin())
        mapping[index] = matches[best]
        errors[index] = delta[best]
        uv_errors[index] = np.abs(candidate_uv[matches[best]] - original_uv[index]).max()
    return mapping, errors, uv_errors



def triangle_coverage(native_positions, native_uv, native_triangles, target_positions, target_uv,
                      target_triangles, position_tolerance=.000025):
    triangles_for_vertex = defaultdict(list)
    for slot, triangle in enumerate(target_triangles):
        for vertex in triangle:
            triangles_for_vertex[int(vertex)].append(slot)
    lookup = defaultdict(list)
    bins = np.rint(target_uv.astype(float) * 100000).astype(int)
    for vertex, key in enumerate(bins):
        lookup[tuple(key)].append(vertex)
    keys = np.rint(native_uv * 100000).astype(int)
    allowed = []
    for index, (u, v) in enumerate(keys):
        close_uv = [vertex for x in (-1, 0, 1) for y in (-1, 0, 1)
                    for vertex in lookup.get((u + x, v + y), ())]
        options = np.asarray(close_uv, dtype=int)
        near = np.linalg.norm(target_positions[options] - native_positions[index], axis=1) < position_tolerance
        uv_ok = np.abs(target_uv[options] - native_uv[index]).max(axis=1) < .000001
        allowed.append(set(options[near & uv_ok]))
    result = np.full(len(native_triangles), -1, dtype=int)
    for slot, primitive in enumerate(native_triangles):
        eligible = [allowed[int(vertex)] for vertex in primitive]
        if not all(eligible):
            continue
        smallest = min(eligible, key=len)
        candidates = {target for vertex in smallest for target in triangles_for_vertex[vertex]}
        result[slot] = any(
            all(vertex in corners for vertex, corners in zip(order, eligible))
            for target in candidates for order in permutations(target_triangles[target]))
    return result



def rasterize(screen, triangles):
    output = np.zeros((height, width), dtype=bool)
    fixed = np.rint(screen * 256).astype(np.int64)
    for triangle in fixed[triangles]:
        low = np.maximum(np.ceil((triangle.min(axis=0) - 128) / 256).astype(int), 0)
        high = np.minimum(np.floor((triangle.max(axis=0) - 128) / 256).astype(int), [width - 1, height - 1])
        if np.any(low > high):
            continue
        first, second = triangle[1:] - triangle[0]
        area = first[0] * second[1] - first[1] * second[0]
        if area == 0:
            continue
        if area < 0:
            triangle = triangle[[0, 2, 1]]
        x, y = np.meshgrid(np.arange(low[0], high[0] + 1) * 256 + 128,
                           np.arange(low[1], high[1] + 1) * 256 + 128)
        inside = np.ones(x.shape, dtype=bool)
        for start, end in zip(triangle, np.roll(triangle, -1, axis=0)):
            dx, dy = end - start
            cross = dx * (y - start[1]) - dy * (x - start[0])
            inside &= cross >= 0 if dy < 0 or (dy == 0 and dx > 0) else cross > 0
        output[low[1]:high[1] + 1, low[0]:high[0] + 1] |= inside
    return output


def last_skin_owner():
    owners = np.zeros((height, width), dtype=np.uint16)
    for draw in read(native_color / 'manifest.json')['events']:
        after, before = [np.frombuffer(gzip.decompress((native_color / path).read_bytes()), '<u4')
                         .reshape(height, width)[::-1] for path in draw['files']]
        owners[after != before] = draw['event']
    with Image.open(grid / 'native-face-masks/skin.png') as image:
        skin = np.asarray(image.convert('L')) > 0
    owners[~skin] = 0
    return owners


def topology(event, name, source, owners):
    stem = source / f'nvidia-{event}'
    files = [Path(str(stem) + '-' + suffix) for suffix in
             ('position.bin', 'index.bin', 'vs-cb0.bin', 'vs-cb1.bin', 'vs-cb3.bin')]
    vertex_file, index_file, *constant_files = files
    indexes = np.fromfile(index_file, '<u2').reshape(-1, 3)
    vertex_count = int(indexes.max()) + 1
    stride = vertex_file.stat().st_size // (4 * vertex_count)
    assert stride == 23 and vertex_file.stat().st_size == 4 * stride * vertex_count
    vertices = np.fromfile(vertex_file, '<f4').reshape(vertex_count, stride).astype(float)
    assert np.isfinite(vertices[:, :15]).all()
    constants = {index: np.fromfile(path, '<f4').reshape(-1, 4)
                 for index, path in zip((0, 1, 3), constant_files)}
    scene = read(body / 'body-native-lit-outline-blend-depth.azurelevel')
    camera = next(node for node in scene['nodes'] if node['id'] == 'camera')
    camera_position = np.array(camera['components']['azure.transform']['data']['translation'])
    doc = read(candidate)
    mesh = next(item for item in doc['meshes'] if item.get('name') == name)
    primitive = mesh['primitives'][-1]
    positions = load_accessor(doc, primitive['attributes']['POSITION'])
    uv = load_accessor(doc, primitive['attributes']['TEXCOORD_0'])
    authored_indices = load_accessor(doc, primitive['indices']).reshape(-1, 3)
    frame, viewport = constants[0], constants[1]
    base_clip = vertices[:, 6:9] @ frame[32:35] + frame[35]
    assert np.abs(base_clip[:, 3] - vertices[:, 3]).max() < 2e-6
    assert np.array_equal(vertices[:, 3], vertices[:, 18])
    jitter = vertices[:, 3, None] * viewport[19, 2:] * [2, -2]
    assert np.max(np.abs(vertices[:, :2] + jitter - vertices[:, 16:18])) < 1e-6
    scale = np.array([width / 2, height / 2]) / vertices[:, 3, None]
    displacement = vertices[:, 16:18] - base_clip[:, :2]
    predicted = clip_offset(vertices[:, :4], vertices[:, 9:12], constants)
    screen_residual = np.abs((predicted - displacement) * scale)
    reference = vertices[:, 6:9] * [-1, 1, 1] + camera_position
    uv_raw = vertices[:, 4:6]
    candidate_attributes = np.column_stack((positions, uv))
    _, canonical = np.unique(candidate_attributes, axis=0, return_inverse=True)
    cases = {}
    for option, original_uv in (('identity', uv_raw), ('flipV', uv_raw * [1, -1] + [0, 1])):
        mapping, errors, uv_errors = map_vertices(reference, original_uv, positions, uv)
        close = (mapping >= 0) & (errors < .000025) & (uv_errors < .000001)
        native_valid = close[indexes].all(axis=1)
        target = Counter(map(tuple, np.sort(canonical[authored_indices], axis=1)))
        mapped = Counter(map(tuple, np.sort(canonical[mapping[indexes[native_valid]]], axis=1)))
        identity = np.flatnonzero(close)
        cases[option] = dict(uvMatched=int((mapping >= 0).sum()), verified=int(close.sum()),
                             uniqueAuthoredAttributes=int(len(set(canonical[mapping[close]]))),
                             geometryQuantiles=percentiles(errors), uvQuantiles=percentiles(uv_errors),
                             exactTrianglesByAttributes=int(sum((target & mapped).values())),
                             matchedTriangles=int(native_valid.sum()),
                             indexIdentity=int(np.count_nonzero(mapping[identity] == identity)),
                             nativeOnlyMatchedTriangles=int(sum((mapped - target).values())))
    native_uv = uv_raw * [1, -1] + [0, 1]
    screen = ((vertices[:, :2].astype('<f4') / vertices[:, 3, None].astype('<f4')) *
              np.array([1, -1], dtype='<f4') + np.float32(1)) * np.array([width / 2, height / 2], dtype='<f4')
    screen[:, 1] = np.float32(height) - screen[:, 1]
    skin = owners == event
    assert skin.sum() == {1079: 577, 1116: 228}[event]
    compatible = {}
    for tolerance in (.000025, .00005, .0005):
        identity = triangle_coverage(reference, native_uv, indexes, positions, uv, authored_indices, tolerance)
        missing = rasterize(screen, indexes[identity == 0])
        unresolved = rasterize(screen, indexes[identity < 0])
        overlap = unresolved & skin
        compatible[tolerance] = dict(unresolvedTriangles=int((identity < 0).sum()),
            matchingTriangles=int((identity == 1).sum()), noCompatibleTriangles=int((identity == 0).sum()),
            noCompatibleRasterized=int(missing.sum()), noCompatibleOwnedSkin=int((missing & skin).sum()),
            unresolvedRasterized=int(unresolved.sum()), unresolvedOwnedSkin=int(overlap.sum()),
            unresolvedSkinCoordinates=np.column_stack(np.where(overlap)[::-1]).tolist())
    return dict(event=event, fileSha256={p.name: digest(p) for p in files}, triangleCompatibility=compatible,
                nativeVertices=vertex_count, nativeTriangles=len(indexes), candidateVertices=len(positions),
                candidateTriangles=len(authored_indices), candidateSha256=digest(candidate),
                nativeShellOffsetPx=np.max(np.abs(displacement * scale), axis=0).tolist(),
                offsetFormulaResidualPx=np.max(screen_residual, axis=0).tolist(),
                offsetFormulaPercentile99Px=np.percentile(screen_residual, 99, axis=0).tolist(),
                coordinateMapping=cases)


def main():
    owners = last_skin_owner()
    results = [topology(1079, 'S_actor_laevat_cloth_01_lod0', retained, owners)]
    native_results = original / 'results.json'
    if native_results.is_file() and read(native_results)['status'] == 'qualified':
        results.append(topology(1116, 'S_actor_laevat_cloth_02_lod0', original, owners))
    output = run / 'body-native-cloth-outline-topology.json'
    output.write_text(json.dumps(results, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    for entry in results:
        print(entry['event'], entry['nativeShellOffsetPx'], entry['offsetFormulaResidualPx'], {t: {k: v for k, v in s.items() if k != 'unresolvedSkinCoordinates'} for t, s in entry['triangleCompatibility'].items()})


if __name__ == '__main__':
    main()
