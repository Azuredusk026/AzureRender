"""Render the captured outline origin and directional cloth in the same pose."""
from contextlib import nullcontext
from hashlib import file_digest
import gzip
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys

import numpy as np

root=Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
cloth=root.parent/'20261114-144753-cloth-directional-rim-actual-4b9034'
fixture=grid/'iris-overlay-geometry-project'
retained=root/'msaa-release'
workspace=root.parents[2]
stage=root/'body-outline-cloth-composition'
native_order=root.parent/'20261114-150229-face-native-geometry-mask-sampling-d5d93e/body-outline-before-transparent-cloth'
order_mesh=native_order/'body-native-lit-outline-production-native-order.gltf' 
resources=stage/'resources'
ready=stage/'preflight.json'
outline='body-native-lit-outline-blend-depth'
character='body-native-lit-outline-production'
directional='cloth-directional-rim-source-control'
slot='name:M_actor_laevat_cloth_03'
variants=('mesh_object_lighting.frag.spv','mesh_object_early_lighting.frag.spv')
read=lambda p:json.loads(p.read_bytes())
helper=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
catalog_api=runpy.run_path(str(root/'face-quality-candidate-catalog.py'))
fingerprint=catalog_api['retained_catalog']


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def write(path,data):
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')


def check_budget():
    sys.path.insert(0,str(workspace/'tools'))
    from artifact_budget import check
    budget=check(root.parents[1],run=root,planned=18_000_000)
    assert budget['allowed'],budget


def preflight():
    check_budget()
    stage.mkdir(exist_ok=True)
    shaders=resources/'shaders'
    shaders.mkdir(parents=True,exist_ok=True)
    sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
    rules={r['output']:r for r in read(retained/'shader-reload.json')['programs']}
    canonical=fingerprint(root)
    anchor='float facing=1.0-abs(dot(shadedNormal,viewDirection));'
    cloth_source=cloth/'cloth-directional-assets/mesh-cloth-directional.frag'
    replacement,=[line.strip() for line in cloth_source.read_text(encoding='utf8').splitlines()
                  if line.strip().startswith('float viewDot=dot(shadedNormal,viewDirection); float facing=')]
    assert 'AZURE_MATERIAL_CLASS==4U && AZURE_ALPHA_MODE==2' in replacement
    candidate=stage/'mesh.frag'
    for commit in ('e63ef54','8dfc5d7','4d9068b'):
        base=subprocess.check_output(['git','show',f'{commit}:Project/AzureRender/shaders/mesh.frag'],
                                     cwd=workspace,text=True,encoding='utf8')
        candidate.write_text(base,encoding='utf8')
        for name in variants:
            rule=rules[name]
            subprocess.run([str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+m for m in rule['defines']),
                            '-I'+str(workspace/'shaders'),str(candidate),'-o',str(shaders/name)],
                           check=True)
        if all(digest(shaders/name)==canonical[name] for name in variants):
            break
    else:
        raise RuntimeError('Retained fragment programs could not be reproduced')
    assert base.count(anchor)==1
    candidate.write_text(base.replace(anchor,replacement),encoding='utf8')
    for name in variants:
        rule=rules[name]
        subprocess.run([str(sdk/'glslc.exe'),*rule['arguments'],*('-D'+m for m in rule['defines']),
                        '-I'+str(workspace/'shaders'),str(candidate),'-o',str(shaders/name)],
                       check=True)
        subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',
                        str(shaders/name)],check=True)
    record=dict(sourceCommit=commit,source=digest(candidate),original={name:canonical[name] for name in variants},
                candidate={name:digest(shaders/name) for name in variants})
    assert all(record['candidate'][name]!=canonical[name] for name in variants)
    write(ready,record)
    print(json.dumps(record))


def validate_resources(record,canonical):
    assert {name:digest(resources/'shaders'/name) for name in variants}==record['candidate']
    catalog_api['restore'](canonical)
    assert {entry.name:digest(entry) for entry in (retained/'shaders').glob('*.spv')}==canonical


def capture(device, mode, expected_player, record):
    output=stage/f'{mode}-{device}'
    pose=root/f'body-outline-beauty-transparent-highlights-captured-origin-{device}'
    material=pose/f'{outline}.azurematerial'
    control=read(pose/'results.json')
    assert control['playerSha256']==expected_player and digest(material)==control['materialSha256']
    scene=read(root/f'{outline}.azurelevel')
    hero,=[n for n in scene['nodes'] if n['id']=='hero']
    assert hero['materialSlots'][slot]=='17024246-ec8a-5c32-b68c-b6f1f9d8ff10'
    if mode=='packed':
        packed=fixture/'materials/cloth-native-packed-parameters.azurematerial.azmeta'
        hero['materialSlots'][slot]=read(packed)['id']
    else:
        directory=cloth/'cloth-directional-assets'
        hero['materialSlots'][slot]=read(directory/f'{directional}.azurematerial.azmeta')['id']
    output.mkdir(exist_ok=True)
    scene_file=output/f'{outline}.azurelevel'
    write(scene_file,scene)
    sources={
        fixture/'character'/f'{character}.gltf':order_mesh if mode=='directional-ordered' else root/f'{character}-ordered.gltf',
        fixture/'materials'/material.name:material,
        fixture/'materials'/f'{material.name}.azmeta':root/f'{material.name}.azmeta',
        fixture/'scene'/scene_file.name:scene_file,
        fixture/f'{outline}.azureproject':root/f'{outline}.azureproject',
    }
    if mode.startswith('directional'):
        for name in (f'{directional}.azurematerial',f'{directional}.azurematerial.azmeta'):
            sources[fixture/'materials'/name]=directory/name
    for destination in list(sources):
        name=destination.name+'.azmeta'
        original=root/name
        mount=destination.with_name(name)
        if original.is_file() and not mount.exists():sources[mount]=original
    mounts=[]
    argv=read(root/f'body-blend-{device}/command.json')
    argv[0]=str(retained/'AzurePlayer.exe')
    for flag,path in (('--capture-dir',output/'frames'),('--runtime-report',output/'runtime.json'),
                      ('--resource-root',retained)):
        argv[argv.index(flag)+1]=str(path)
    try:
        for destination,source in sources.items():
            assert not destination.exists(),destination
            destination.hardlink_to(source)
            mounts.append((destination,source))
        change=(catalog_api['activate'](record['candidate'],source_dir=resources/'shaders')
                if mode.startswith('directional') else nullcontext())
        with change:
            frame=helper['invoke'](device,argv,output)/'frame_000000.png'
        assert frame.is_file()
    finally:
        for destination,source in reversed(mounts):
            if destination.is_file() and os.path.samefile(destination,source):destination.unlink()
            meta=destination.with_name(destination.name+'.azmeta')
            if meta.is_file() and destination.suffix in ('.azureproject','.azurelevel') and meta not in sources:
                meta.replace(output/meta.name)
    return frame


def run():
    check_budget()
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==root
    record=read(ready)
    canonical=fingerprint(root)
    validate_resources(record,canonical)
    player=digest(retained/'AzurePlayer.exe')
    assert player=='1a30d925a674ddb1d95876cb80181106a0217e12a7228a35b5980b134954cb69'
    scores=runpy.run_path(str(grid/'static-quality.py'))
    reference=scores['image'](scores['reference_path']).astype(np.int16)
    owner_file=root.parent/'20261114-135148-face-receiver-diagnostics-7509b1/body-visible-ownership-points.bin'
    x,y,owner=np.fromfile(owner_file,'<u2').reshape(-1,3).T
    region_masks={'event1018':np.zeros(reference.shape[:2],bool),
                  'event1383':np.zeros(reference.shape[:2],bool)}
    for name,mask in region_masks.items():
        subset=owner==int(name[5:])
        mask[y[subset],x[subset]]=True
    focus=np.asarray(read(cloth.parent/'20261114-135148-face-receiver-diagnostics-7509b1/cloth-directional-replay-summary.json')['points'])
    diagnostic=np.zeros(reference.shape[:2],bool)
    diagnostic[focus[:,1],focus[:,0]]=True
    region_masks['clothDirectionalControls']=diagnostic
    provenance=read(native_order/'results.json')
    assert provenance['status']=='measured-native-transparent-primitive-order'
    assert digest(order_mesh)==provenance['source']['candidate']
    stage_dir=scores['stages']/'post-opaque-ownership'
    cloth_draw,=[record for record in read(stage_dir/'manifest.json')['events'] if record['event']==1383]
    frames_raw=[np.frombuffer(gzip.decompress((stage_dir/name).read_bytes()),'<u4').reshape(reference.shape[:2])[::-1]
                for name in cloth_draw['files']]
    region_masks['wholeCloth1383']=frames_raw[0]!=frames_raw[1]
    assert int(region_masks['wholeCloth1383'].sum())==27832
    readings={}
    for device in ('nvidia','intel'):
        pose=root/f'body-outline-beauty-transparent-highlights-captured-origin-{device}'
        base=pose/'frames/frame_000000.png'
        assert digest(base)==read(pose/'results.json')['frameSha256']
        frames={'origin':base}
        order_frame=native_order/device/'frames/frame_000000.png'
        assert digest(order_frame)==provenance['devices'][device]['frame']
        frames['nativeOrder']=order_frame
        for mode in ('packed','directional','directional-ordered'):
            frames[mode]=capture(device,mode,player,record)
        images={name:scores['image'](p).astype(np.int16) for name,p in frames.items()}
        errors={name:np.abs(image-reference).max(2) for name,image in images.items()}
        packed_error=errors['packed']
        directional_error=errors['directional']
        native_order_errors=errors['nativeOrder']
        combined_errors=errors['directional-ordered']
        combined_change=np.any(images['nativeOrder']!=images['directional-ordered'],axis=2)
        readings[device]=dict(frames={name:digest(p) for name,p in frames.items()},
            combinedChangedOutsideOriginalCloth=int(combined_change[~region_masks['wholeCloth1383']].sum()),
            combinedNewOverOne=int(((native_order_errors<=1)&(combined_errors>1)).sum()),
            combinedWitnessErrors={f'{x},{y}':[int(image[y,x]) for image in (native_order_errors,combined_errors)]
                                    for x,y in ((1252,839),(1255,837),(1152,797),(1234,789))},
            changesFromPacked=int(np.any(images['packed']!=images['directional'],axis=2).sum()),
            newFrameOverOne=int(((packed_error<=1)&(directional_error>1)).sum()),
            overOne={name:{kind:int((e[mask]>1).sum()) for kind,mask in region_masks.items()} for name,e in errors.items()},
            overEight={name:{kind:int((e[mask]>8).sum()) for kind,mask in region_masks.items()} for name,e in errors.items()},
            maxAtControls={name:int(e[diagnostic].max()) for name,e in errors.items()})
        print(device,json.dumps(readings[device]),flush=True)
    report=dict(status='measured-combination',reference=digest(scores['reference_path']),
                player=player,shaderPrograms=record,nativeOrderAsset=provenance['source'],devices=readings)
    write(stage/'results.json',report)
    assert all(digest(retained/'shaders'/name)==digest_ for name,digest_ in canonical.items())
    assert all(x['overEight']['directional']['clothDirectionalControls']<
               x['overEight']['packed']['clothDirectionalControls'] for x in readings.values()),report


if sys.argv[1:]==['preflight']:preflight()
else:
    assert not sys.argv[1:]
    run()
