"""Link a capture trial using the submitted HDR resolve as projected reflection history."""
import ast
from hashlib import file_digest
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from zipfile import ZIP_LZMA, ZipFile

M=Path(__file__).resolve().parent
W=M.parents[2]
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
release=R/'msaa-release'
base=M/'projected-history-layer-release'
reference=M/'immutable-scene-capture-source'
O=M/'projected-resolved-history-trial'
exe=base/'AzurePlayerResolvedHistoryTrial.exe'
read=lambda p:json.loads(p.read_bytes())
key='AZR_NR_QA_PROJECTED_RESOLVED_HISTORY'

def sha(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()


def replace(source,old,new):
    assert source.count(old)==1,old
    return source.replace(old,new)


def build_sources():
    f=W/'src/app/AzureRenderFrame.cpp'
    c=W/'src/scenes/CharacterSceneRenderer.cpp'
    t=W/'src/render/TemporalReconstruction.hpp'
    h=W/'src/scenes/CharacterSceneRenderer.hpp'
    s=W/'src/scenes/CharacterScreenReflection.inc'
    texts={p:p.read_text(encoding='utf8') for p in (f,c,t,h,s)}
    for p,value in texts.items():
        old=subprocess.check_output(['git','show','75837a6:Project/AzureRender/'+p.relative_to(W).as_posix()],
                                    cwd=W,encoding='utf8')
        assert old==value,p
    bridge='''#pragma once
#include <cstdint>
#include <vulkan/vulkan.h>
namespace azurerender {
struct CaptureResolvedHistory {
    VkImage image=VK_NULL_HANDLE;
    VkImageView view=VK_NULL_HANDLE;
    std::uint64_t submission=0;
};
extern thread_local CaptureResolvedHistory captureResolvedHistory;
}
'''
    app='#include "CaptureResolvedHistory.hpp"\n#include <cstdlib>\n#include <string_view>\n'+texts[f]
    app=replace(app,'using namespace azurerender::internal;',
        'thread_local azurerender::CaptureResolvedHistory azurerender::captureResolvedHistory;\n\nusing namespace azurerender::internal;')
    app=replace(app,'    auto sceneResources=resources;',
        '''    azurerender::captureResolvedHistory={};
    const char* trial=std::getenv("AZR_NR_QA_PROJECTED_RESOLVED_HISTORY");
    if (trial && std::string_view(trial)=="1" && temporalReady && temporalReconstruction_->preparedHistoryValid()) {
        auto& hdr=azurerender::captureResolvedHistory;
        hdr.image=temporalReconstruction_->submittedColorImage();
        hdr.view=temporalReconstruction_->submittedColorView();
        hdr.submission=temporalReconstruction_->historySubmission();
    }
    auto sceneResources=resources;''')
    temporal=replace(texts[t],'''    bool preparedHistoryValid() const noexcept{return pending_&&pending_->valid;}''',
        '''    bool preparedHistoryValid() const noexcept{return pending_&&pending_->valid;}
    VkImage submittedColorImage() const noexcept {return images_[1+historyIndex_].image;}
    VkImageView submittedColorView() const noexcept {return views_[1+historyIndex_];}''')
    decl='    void recordScreenReflection(rhi::ICommandRecorder&,unsigned,const ReflectionTraceInputs&,const ReflectionTraceView&,const ScreenSpaceReflectionSettings&);'
    header=replace(texts[h],decl,decl[:-2]+',VkImageView overrideResolved=VK_NULL_HANDLE);')
    scene='#include "CaptureResolvedHistory.hpp"\n'+texts[c]
    old='''        const auto producer=graph.addCommandPass("character-compute-reflection",[this,slot,view,settings,inputs](rhi::ICommandRecorder& commands){
            recordScreenReflection(commands,slot,inputs,view,settings);
        },true);'''
    new='''        const auto candidate=captureResolvedHistory;
        const bool resolved=projectedReflectionHistoryPrepared_&&reflectionHistoryAvailable(slot)&&
            candidate.image&&candidate.view&&candidate.submission==reflectionHistorySubmission_;
        const auto previousResolved=resolved?candidate.view:VK_NULL_HANDLE;
        if(resolved) RuntimeDiagnostics::instance().info("render","QA projected reflection uses submitted HDR resolve "+
            std::to_string(candidate.submission));
        const auto producer=graph.addCommandPass("character-compute-reflection",[this,slot,view,settings,inputs,previousResolved](rhi::ICommandRecorder& commands){
            recordScreenReflection(commands,slot,inputs,view,settings,previousResolved);
        },true);'''
    scene=replace(scene,old,new)
    scene=replace(scene,'            rhi::ImageBarrierDesc previous;previous.image=opaqueSceneColor_[reflectionHistorySlot_].image.image;',
       '''            rhi::ImageBarrierDesc previous;
            previous.image=resolved?candidate.image:opaqueSceneColor_[reflectionHistorySlot_].image.image;''')
    scene=replace(scene,'''            if(projectedHistoryLayerPass_){
                previous.image=projectedHistoryLayer_[reflectionHistorySlot_].image.image;''',
       '''            if(projectedHistoryLayerPass_&&!resolved){
                previous.image=projectedHistoryLayer_[reflectionHistorySlot_].image.image;''')
    signature='void CharacterSceneRenderer::recordScreenReflection(rhi::ICommandRecorder& commands,unsigned slot,const ReflectionTraceInputs& inputs,const ReflectionTraceView& view,const ScreenSpaceReflectionSettings& settings){'
    reflection=replace(texts[s],signature,signature[:-2]+',VkImageView overrideResolved){')
    reflection=replace(reflection,'''            history={reflectionHistorySlot_,opaqueSceneColor_[reflectionHistorySlot_].view,reflectionHistoryView_,
                projectedHistoryLayer_[reflectionHistorySlot_].view};''',
        '''            history={reflectionHistorySlot_,overrideResolved?overrideResolved:opaqueSceneColor_[reflectionHistorySlot_].view,
                reflectionHistoryView_,overrideResolved?VK_NULL_HANDLE:projectedHistoryLayer_[reflectionHistorySlot_].view};''')
    return {O/f.name:app,O/c.name:scene,O/s.name:reflection,O/'CaptureResolvedHistory.hpp':bridge,
            O/'include/render'/t.name:temporal,O/'include/scenes'/h.name:header},(f,c)


def run():
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    assert check(W/'build',run=M,planned=31_000_000)['allowed']
    assert not exe.exists()
    expected=read(reference/'qualification.json')
    assert sha(base/'AzurePlayerCaptureResource.exe')==expected['candidatePlayer']
    assert sha(reference/'AssetDatabase.cpp.obj')==expected['assetDatabaseObject']
    sources,compile_units=build_sources()
    for p,value in sources.items():
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(value,encoding='utf8')
    compiler=runpy.run_path(str(R/'face-quality-batch.py'),run_name='hdr_trial_compiler')
    ninja=Path(compiler['cmake']).parents[2]/'Ninja/ninja.exe'
    schema=ast.parse((M/'build-camera-pose-player.py').read_text(encoding='utf8'))
    fn,=[p for p in schema.body if isinstance(p,ast.FunctionDef) and p.name=='windows_arguments']
    scope={}
    exec(compile(ast.Module(body=[fn],type_ignores=[]),'argv','exec'),scope)
    commands=subprocess.check_output([str(ninja),'-C',str(release),'-t','commands','AzurePlayer'],text=True).splitlines()
    tasks=[]
    objs=[]
    for p in compile_units:
        cmd,=[line for line in commands if line.endswith(str(p))]
        args=scope['windows_arguments'](cmd)
        output=O/(p.name+'.obj')
        objs.append(output)
        for option,value in [('/Fo',output),('/Fd',O/(p.stem+'.pdb'))]:
            i,=[i for i,arg in enumerate(args) if arg.startswith(option)]
            args[i]=option+str(value)
        args.insert(1,'/I'+str(O/'include'))
        args[-1:]=['/I'+str(p.parent), str(O/p.name)]
        tasks.append((p.stem,args))
    receipt=read(reference/'main-object-compaction.json')
    archive=Path(receipt['archive'])
    assert sha(archive)==receipt['archiveSha']
    restored=O/'capture-entry-main.cpp.obj'
    with ZipFile(archive) as z, restored.open('xb') as file:
        file.write(z.read(receipt['member']))
    assert sha(restored)==receipt['sha256']==expected['entryObject']
    link_source=(reference/'player.rsp').read_text(encoding='ascii').splitlines()
    assert str(reference/'main.cpp.obj') in link_source[0]
    rsp=O/'player.rsp'
    head=link_source[0].replace(str(reference/'main.cpp.obj'),str(restored))
    rsp.write_text('\n'.join([head+' '+subprocess.list2cmdline([str(p) for p in objs]),*link_source[1:]])+'\n',encoding='ascii')
    opt=read(base/'link-receipt.json')['linkCommand'].copy()
    for i,v in enumerate(opt):
        if v.startswith('--intdir='):
            parts=O/'link-intermediates'
            parts.mkdir(exist_ok=True)
            opt[i]='--intdir='+str(parts)
        elif v.startswith('@'):opt[i]='@'+str(rsp)
        elif v.lower().startswith('/out:'):opt[i]='/out:'+str(exe)
        elif v.lower().startswith('/implib:'):opt[i]='/implib:'+str(O/'entry.lib')
        elif v.lower().startswith('/pdb:'):opt[i]='/pdb:'+str(O/'entry.pdb')
    tasks.append(('link',opt))
    env={k:v for k,v in os.environ.items() if k not in (key,'AZR_NR_QA_RESOURCE_ID','AZR_NR_QA_RESOURCE_PATH')}
    try:
        for name,command in tasks:
            result=subprocess.run(subprocess.list2cmdline([compiler['entry'],*command]),shell=True,cwd=release,
                                  env=env,capture_output=True,timeout=235)
            (O/f'{name}.log').write_bytes(result.stdout+result.stderr)
            assert result.returncode==0,(name,result.stdout[-5000:],result.stderr[-1500:])
    finally:
        assert not restored.stat().st_file_attributes&1024 and sha(restored)==expected['entryObject']
        restored.unlink()
    good=subprocess.run([str(exe),'--help'],env=env,capture_output=True,timeout=20)
    assert good.returncode==0 and b'--capture-frames' in good.stdout
    artifacts={p.name:sha(p) for p in objs}
    packed=O/'objects.zip'
    assert check(W/'build',run=M,planned=10_000_000)['allowed']
    with ZipFile(packed,'x',ZIP_LZMA) as z:
        for p in objs:z.write(p,p.name)
    with ZipFile(packed) as z:
        assert z.testzip() is None
        from hashlib import sha256
        assert all(sha256(z.read(p.name)).hexdigest()==artifacts[p.name] for p in objs)
    for p in objs:
        assert p.resolve()==p and p.parent==O and not p.stat().st_file_attributes&1024 and sha(p)==artifacts[p.name]
        p.unlink()
    record=dict(status='built-projected-resolved-history-trial',candidate=sha(exe),baseline=expected['candidatePlayer'],
                sources={str(p.relative_to(O)):sha(p) for p in sources},objects=artifacts,objectArchive=sha(packed))
    (O/'qualification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
    print(record,flush=True)


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print([str(p.relative_to(O)) for p in build_sources()[0]])
    else:
        run()
