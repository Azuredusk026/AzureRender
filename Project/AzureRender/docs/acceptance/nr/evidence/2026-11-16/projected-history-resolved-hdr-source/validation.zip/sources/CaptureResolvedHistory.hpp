#pragma once
#include <cstdint>
#include <vulkan/vulkan.h>
namespace azurerender {
struct CaptureResolvedHistory {
    VkImage image=VK_NULL_HANDLE;
    VkImageView view=VK_NULL_HANDLE;
    std::uint64_t submission=0;
};
extern thread_local CaptureResolvedHistory captureResolvedHistory;
}
