#pragma once
#include "render/MotionVectorTarget.hpp"
#include "render/RenderGraph.hpp"
#include "render/TemporalViewState.hpp"
#include <array>
#include <memory>
#include <optional>
#include <string>
namespace azurerender {
struct TemporalSceneSource {
    VkImage color=VK_NULL_HANDLE;VkImageView colorView=VK_NULL_HANDLE;
    VkImage depth=VK_NULL_HANDLE;VkImageView depthView=VK_NULL_HANDLE;
    VkImage displayMask=VK_NULL_HANDLE;VkImageView displayMaskView=VK_NULL_HANDLE;
};
// One view's native-resolution HDR history. Sources and their depth views are
// borrowed. Retire recording and GPU work before destruction or replacement.
class TemporalReconstruction final {
public:
    static constexpr std::uint64_t kBytesPerPixel=52,kMaximumBytes=512ULL*1024*1024;
    static constexpr std::uint64_t kDisplayMaskBytesPerPixel=8;
    static constexpr VkFormat kDisplayMaskHistoryFormat=VK_FORMAT_R16G16_SFLOAT;
    TemporalReconstruction(rhi::IRhi&,rhi::IGpuAllocator&,VkExtent2D,VkFormat depthFormat,
        std::vector<TemporalSceneSource>,const std::string& shaderDirectory,MotionVectorTarget* sharedMotion=nullptr);
    ~TemporalReconstruction();
    TemporalReconstruction(const TemporalReconstruction&)=delete;
    TemporalReconstruction& operator=(const TemporalReconstruction&)=delete;
    MotionVectorTarget& motion() noexcept{return *motion_;}
    std::array<RenderGraph::ResourceId,2> importMotion(RenderGraph&,const std::string&) const;
    void prepare(const TemporalPreparedFrame&,std::uint32_t frame,std::uint32_t source);
    std::optional<RenderGraph::ResourceId> schedule(RenderGraph&,RenderGraph::ResourceId color,RenderGraph::ResourceId depth,
        std::array<RenderGraph::ResourceId,2> motion,const std::string& name,RenderGraph::ResourceId displayMask=UINT32_MAX);
    bool hasDisplayMask() const noexcept{return displayMaskEnabled_;}
    std::uint64_t displayMaskByteSize() const noexcept{return hasDisplayMask()?std::uint64_t(extent_.width)*extent_.height*kDisplayMaskBytesPerPixel:0;}
    VkImageView displayMaskView(unsigned index)const{if(!hasDisplayMask()||index>=2)throw std::out_of_range("Display history index");return views_[5+index];}
    unsigned preparedDisplayMaskIndex()const {if(!pending_)throw std::logic_error("Display history requires a prepared frame");return pending_->next;}
    bool commit(std::uint64_t submission) noexcept;
    void cancel() noexcept {pending_.reset();recorded_=false;}
    std::uint64_t byteSize() const noexcept{return bytes_;}
    std::uint64_t historySubmission() const noexcept{return lastSubmission_;}
    std::uint32_t historyIndex() const noexcept{return historyIndex_;}
    bool preparedHistoryValid() const noexcept{return pending_&&pending_->valid;}
    VkImage submittedColorImage() const noexcept {return images_[1+historyIndex_].image;}
    VkImageView submittedColorView() const noexcept {return views_[1+historyIndex_];}
private:
    struct Pending {std::uint32_t frame=0,source=0,previous=0,next=1;bool valid=false;};
    rhi::IRhi& rhi_;rhi::IGpuAllocator& allocator_;VkExtent2D extent_{};
    std::vector<TemporalSceneSource> sources_;
    std::unique_ptr<MotionVectorTarget> ownedMotion_;
    MotionVectorTarget* motion_=nullptr;
    // Scratch HDR, two HDR histories, two colour-surface depth histories.
    std::array<rhi::GpuImage,7> images_{};std::array<VkImageView,7> views_{};
    bool displayMaskEnabled_=false;
    std::array<rhi::GpuBuffer,2> uniforms_{};
    VkSampler sampler_=VK_NULL_HANDLE;VkRenderPass copyPass_=VK_NULL_HANDLE,resolvePass_=VK_NULL_HANDLE;
    VkFramebuffer copyFramebuffer_=VK_NULL_HANDLE;std::vector<VkFramebuffer> resolveFramebuffers_;
    std::array<VkDescriptorSetLayout,2> descriptors_{};VkDescriptorPool pool_=VK_NULL_HANDLE;
    std::vector<VkDescriptorSet> copySets_,resolveSets_;
    std::array<VkPipelineLayout,2> layouts_{};std::array<VkPipeline,2> pipelines_{};
    std::optional<Pending> pending_;bool recorded_=false;
    std::uint32_t historyIndex_=0;std::uint64_t lastSubmission_=0,bytes_=0;
    void reset() noexcept;
};
}
