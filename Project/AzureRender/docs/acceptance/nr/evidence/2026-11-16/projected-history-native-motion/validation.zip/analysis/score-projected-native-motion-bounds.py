"""Bound native pre-motion displacement from original packed motion and measured history UV."""
from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys

import numpy as np

root=Path(__file__).resolve().parent
s=runpy.run_path(str(root/'score-projected-history-coordinates.py'))
b,read=s['base'],s['read']


def decode(words):
    n=np.float32(1023)
    rg=np.stack((words&1023,(words>>10)&1023),axis=-1).astype(np.float32)/n
    d=np.abs(rg)*np.float32(2)-np.float32(1)
    d*=d
    return np.sign(rg-.5)*(d*d)


def invert(motion, endpoint, uncertainty):
    height,width=motion.shape[:2]
    scale=np.array([width,height],dtype=np.float64)
    prior=endpoint*scale
    pix=np.floor(prior).astype(np.int64)
    assert (pix>=0).all() and (pix<scale).all()
    bin_ids=pix[:,1]*width+pix[:,0]
    relevant=np.zeros(width*height,dtype=bool)
    relevant[bin_ids]=True
    sy,sx=np.indices((height,width),dtype=np.int32)
    source=np.stack([sx,sy],axis=-1).reshape(-1,2)
    d=motion.reshape(-1,2).astype(np.float64)*scale
    low=source-d
    margin=uncertainty*scale
    bins=np.floor(low-margin).astype(np.int32)
    assert np.max(2*margin)<1
    pairs=[]
    # A translated single-pixel cell plus the quantization margin intersects at most three bins per axis.
    for dy in range(3):
        y=bins[:,1]+dy
        for dx in range(3):
            x=bins[:,0]+dx
            within=(x>=0)&(x<width)&(y>=0)&(y<height)
            bucket=np.where(within,y*width+x,0)
            ix=np.flatnonzero(within&relevant[bucket])
            pairs.append(np.column_stack((bucket[ix],ix)))
    pairs=np.vstack(pairs)
    order=np.argsort(pairs[:,0],kind='stable')
    bucket=pairs[:,0][order]; source_id=pairs[:,1][order]
    lower=np.searchsorted(bucket,bin_ids,'left')
    upper=np.searchsorted(bucket,bin_ids,'right')
    count=np.zeros(len(prior),dtype=np.int32)
    min_move=np.full(len(prior),np.nan)
    max_move=min_move.copy()
    for i,(lo,hi) in enumerate(zip(lower,upper)):
        candidates=source_id[lo:hi]
        expected=prior[i]+d[candidates]
        possible=((expected+margin>=source[candidates]) & (expected-margin<=source[candidates]+1)).all(axis=1)
        checked=candidates[possible]
        count[i]=len(checked)
        if len(checked):
            displacement=np.linalg.norm(d[checked],axis=1)
            min_move[i]=displacement.min()
            max_move[i]=displacement.max()
    return count,min_move,max_move


def score():
    _,_,manifest,rows=s['original_history_depths']()
    motion,=[r for r in rows if r['role']=='motion']
    assert (motion['binding'],motion['source']['resource'],motion['format'])==(4,'ResourceId::16508','R10G10B10A2_UNORM')
    W,H=(motion[k] for k in ('width','height'))
    raw=s['check_snapshot'](manifest.parent/motion['file'],motion['sha256'],'<u4',(H,W))
    n=s['source']['n']
    assert n['blocks'][2]['variables'][2]['float32'][2]==0.0
    folder=s['floor']/'native'
    proof=read(folder/'results.json')
    assert proof['status']=='qualified' and proof['baselineRestored']
    _,uv_id,conf_id=proof['outputs']['coordinates']
    x,y,r,t=b['CROP'];shape=(t-y,r-x)
    measured=s['check_snapshot'](folder/'history-uv.bin',uv_id,'<u2',(*shape,2))
    confidence=s['check_snapshot'](folder/'trace-confidence.bin',conf_id,'u1',shape)
    mask=(confidence>0)&((measured>0)&(measured<65535)).all(axis=2)
    count,lo,hi=invert(decode(raw),measured[mask]/65535.,.5/65535+1e-6)
    assert (count>0).mean()>.95, dict(missing=int((count==0).sum()),total=int(count.size))
    count_full=np.full(shape,-1);count_full[mask]=count
    lo_full=np.full(shape,np.nan);lo_full[mask]=lo
    hi_full=np.full(shape,np.nan);hi_full[mask]=hi
    rows={}
    for name,box in b['REGIONS'].items():
        sl=lambda a:b['cut'](a,b['local'](box))
        cnt=sl(count_full); valid=cnt>0
        pct=lambda a:np.percentile(sl(a)[valid],[10,50,90,99,100]).tolist()
        rows[name]=dict(endpoints=int((cnt>=0).sum()),inverted=int(valid.sum()),uniqueMotionCell=int((cnt==1).sum()),
                        minimumPossibleDisplacementRenderPixels=pct(lo_full),
                        maximumPossibleDisplacementRenderPixels=pct(hi_full),
                        unconditionallyAtMostHalfPixel=int((sl(hi_full)<=.5).sum()))
    result=dict(status='qualified-native-motion-interval-inversion',originalMotionSha256=motion['sha256'],
            actualNativeHistoryUvSha256=uv_id,confidenceSha256=conf_id,regions=rows,
            scope='Native motion filter is point sampled. Bounds reflect all compatible source cells and do not assert Player motion.')
    (s['floor']/'native-motion-inverse-bounds.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result))


def preflight():
    assert decode(np.asarray([0,1023|(1023<<10)],dtype='u4')).tolist()==[[-1.,-1.],[1.,1.]]
    u=np.array([[.42,.42],[.66,.76],[.66,.75]])
    field=np.zeros((4,4,2))
    field[1,2]=[.2,.0]
    c,low,high=invert(field,u,1e-5)
    np.testing.assert_equal(c,[2,1,2])
    np.testing.assert_allclose(low,[0,0,0]);np.testing.assert_allclose(high,[.8,0,0])


if __name__=='__main__':
    preflight()
    assert sys.argv[1:] in (['preflight'],['score'])
    if sys.argv[1:]==['score']:
        score()
