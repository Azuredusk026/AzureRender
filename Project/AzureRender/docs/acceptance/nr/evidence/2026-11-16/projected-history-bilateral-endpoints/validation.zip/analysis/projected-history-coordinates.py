"""Read the actual point-sampled reflection history UV without changing the color or confidence."""
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import struct
import subprocess
import sys
import traceback

key = 'AZURE_NR_PROJECTED_COORDINATE_REQUEST'
run = Path(os.environ[key]).parents[2] if key in os.environ else Path(__file__).resolve().parent
out = run/'projected-history-coordinates'
historical = Path('D:/Projects/FYP/Project/AzureRender/build/runs')
native = historical/'20261029-052336-native-hierarchical-reflection-52b603'
util = run.parent/'20261112-053111-intel-reference-visibility-sources-5238e2/native-normal-explicit-mips'
if key not in os.environ:
    sys.path.insert(0,str(util))
    from dxbc_util import checksum, chunks, dest, fbits, imm, inst, instructions, opcode, opcodes, rebuild, words
original_path = native/'event-8702.dxbc'
source_commit = '01776f284e6df309f7e2fba5bf0b2ca3f1005d47'
size, rectangle = (1280,720), (500,480,790,700)
digest = lambda b:sha256(b).hexdigest()
read = lambda p:json.loads(p.read_bytes())
def write(p,a):
    p.write_text(json.dumps(a,indent=2)+'\n',encoding='utf8')

def native_patch(code, marker=False):
    assert checksum(code)==code[4:20]
    parts=chunks(code)
    section,=[i for i,(n,_) in enumerate(parts) if n in (b'SHEX',b'SHDR')]
    program=words(parts[section][1])
    index={i+4:(a,op,n) for i,a,op,n in instructions(program) if i is not None}
    sample,op,_=index[320]
    assert op==opcode('SAMPLE_L') and program[sample+5:sample+7]==[0x100046,2]
    store,op,n=index[327]
    assert op==opcodes['D3D11_SB_OPCODE_STORE_UAV_TYPED'] and program[store+1:store+n]==[0x11e0f2,1,0x100546,0,0x100046,4]
    temps,=[a for _,a,op,n in instructions(program) if op==opcode('DCL_TEMPS') and n==2]
    assert program[temps+1]==14
    assembly = original_path.with_suffix('.asm').read_text(encoding='utf-8-sig')
    assert assembly.count('320:') == 1 and 'r13.' not in assembly.split('320:',1)[1]
    source = [0x100046,2] if not marker else imm(fbits(.2))
    new = inst('MOV',dest(13,3),source)
    original = program.copy()
    program[store+n-2:store+n]=[0x100046,13]
    program[sample:sample]=new
    program[1]=len(program)
    recovered=program.copy()
    del recovered[sample:sample+len(new)]
    recovered[store+n-2:store+n]=original[store+n-2:store+n]
    recovered[1]=original[1]
    assert recovered==original
    parts[section]=(parts[section][0],struct.pack('<{}I'.format(len(program)),*program))
    result=rebuild(code,parts)
    assert checksum(result)==result[4:20] and len(result)>len(code)
    return result

def request(tag):
    src=runpy.run_path(str(run/'projected-history-source-replay.py'),run_name='projected_prior_input')
    item=src['request'](tag)
    if tag=='native':
        item['outputs']={row['shader_binding_index']:row['resource']
                         for row in read(native/'event-8702.json')['outputs']}
        item['outputBinds']=[0,1,2]
    else:
        summary=read(historical/'20261031-122504-projected-footprint-quality-5daf40/capture-inputs-v2/summary.json')
        item['outputs']={row['fixedBindNumber']:row['resource'] for row in summary['outputs']}
        item['outputBinds']=[9,10,11]
        worklist,=[row for row in summary['rawReadWrite'] if row['name']=='worklist']
        assert (worklist['fixedBindNumber'],worklist['resource'],worklist['format'])==(1,'ResourceId::9331','Undefined')
        item['storageBuffers']={1:worklist['resource']}
    assert sorted(item['outputs'])==item['outputBinds']
    return item

def inputs():
    preflight=[request(d) for d in ('native','player')]
    assert digest(original_path.read_bytes())==preflight[0]['shader']
    original=original_path.read_bytes()
    overlay, marker=map(lambda flag:native_patch(original,flag),(False,True))
    assert len({digest(x) for x in (original,overlay,marker)})==3
    engine=subprocess.check_output(['git','show',f'{source_commit}:Project/AzureRender/shaders/projected_reflection_trace.hlsl'],
                                   cwd=run.parents[2])
    assert digest(engine)== 'a39752c08b25001c3b9c8ec06e7f81469c5c4f33ef6a65d718e6cf71fc95e6a0'
    sampler=b'float4 v320=previousColor.SampleLevel('
    report=b'outputFootprint[outputPixel]=asfloat(r4.xyxx);'
    assert engine.count(sampler)==engine.count(report)==1
    variants=[engine.replace(sampler,b'float2 qaHistoryUv=asfloat(r2.xy);\n'+sampler).replace(
              report,b'outputFootprint[outputPixel]=float4('+value+b', 0, 0);') 
              for value in (b'qaHistoryUv', b'float2(.2,.2)')]
    return preflight,(overlay,marker),engine,variants

def trace_version(archived):
    path = run.parents[2]/'shaders/projected_reflection_trace.hlsl'
    active = path.read_bytes().replace(b'\r\n',b'\n')
    archived = archived.replace(b'\r\n',b'\n')
    original = b'if(motion.w==1)return 1;'
    current = b'if(motion.w==1||motion.w==4)return 1;'
    assert archived.count(original)==1
    assert active == archived.replace(original,current)
    retained = run.parent/'20261114-125923-body-lit-outline-depth-order-a29b63/msaa-release/shaders/projected_reflection_trace.comp.spv'
    assert digest(retained.read_bytes())=='9b77643b12d533f69e7a159ba975dfaf75e56253429371d6f7470ea6a567e20a'
    return dict(archivedTrace=request('player')['shader'], currentTrace=digest(retained.read_bytes()),
                currentAlsoAcceptsProjectedOutlineMotionClass=4,
                endpointComparisonScope='Archived real Player capture; current paired production validation remains required.')


def region(raw, bpp, flip):
    width,height=size; x,y,u,v=rectangle
    assert len(raw)==bpp*width*height
    rows=(height-1-row if flip else row for row in range(y,v))
    return b''.join(raw[(row*width+x)*bpp:(row*width+u)*bpp] for row in rows)

def readback(path):
    job=read(path)
    device=job['device']
    storage=path.parent
    result=dict(status='failed')
    source=None
    controller=None
    active=None
    original=None
    stage_log=storage/'worker-checkpoint.json'
    def checkpoint(stage, **extra):
        write(stage_log,dict(stage=stage,device=device,request=job['shader'],**extra))
    try:
        checkpoint('worker-start')
        import renderdoc as rd
        source=rd.OpenCaptureFile()
        assert source.OpenFile(job['capture'],'',None)==rd.ResultCode.Succeeded
        state,controller=source.OpenCapture(rd.ReplayOptions(),None)
        assert state==rd.ResultCode.Succeeded and controller is not None
        assert str(controller.GetAPIProperties().pipelineType)=='GraphicsAPI.'+job['api']
        checkpoint('capture-opened')
        controller.SetFrameEvent(job['event'],True)
        stage=rd.ShaderStage.Compute
        pipe=controller.GetPipelineState()
        shader=pipe.GetShaderReflection(stage)
        original=pipe.GetShader(stage)
        assert digest(bytes(shader.rawBytes))==job['shader']
        output={str(shader.readWriteResources[r.access.index].fixedBindNumber):r.descriptor.resource
                for r in pipe.GetReadWriteResources(stage)}
        mapped={k:str(v) for k,v in output.items()}
        buffers=job.get('storageBuffers',{})
        expected={**job['outputs'],**buffers}
        assert mapped==expected, (mapped,expected)
        if buffers:
            descriptions={str(buf.resourceId):buf for buf in controller.GetBuffers()}
            for slot, resource in buffers.items():
                assert str(output[slot])==resource and resource in descriptions
        textures={str(t.resourceId):t for t in controller.GetTextures()}
        binding=[str(i) for i in job['outputBinds']]
        def capture():
            regions=[]
            for slot,fmt,bpp in zip(binding,('R11G11B10_FLOAT','R16G16_UNORM','R8_UNORM'),(4,4,1)):
                resource=output[slot]
                texture=textures[str(resource)]
                assert texture.format.Name()==fmt and (texture.width,texture.height)==size
                data=bytes(controller.GetTextureData(resource,rd.Subresource(0,0,0)))
                regions.append(region(data,bpp,job['flip']))
            return regions
        base=capture()
        tracked=sum(x>0 for x in base[2]); assert tracked>10000
        result=dict(status='running', control=[digest(x) for x in base], hits=tracked)
        checkpoint('original-verified',control=result['control'],hits=tracked)
        history_raw, history_sample, history_receipt = None, None, None
        if device=='player' and not job.get('preMotionProbe',False):
            bound={shader.readOnlyResources[row.access.index].fixedBindNumber:row.descriptor
                   for row in pipe.GetReadOnlyResources(stage)}
            metadata=next(row for row in job['inputs'] if row['name']=='prior-color')
            bound_color=bound[metadata['bind']]
            assert str(bound_color.resource)==metadata['resource'] and bound_color.firstMip==0
            texture=textures[metadata['resource']]
            assert (texture.width,texture.height)==(2560,1440) and texture.format.Name()==metadata['format']
            history_raw=bytes(controller.GetTextureData(bound_color.resource,rd.Subresource(0,0,0)))
            assert len(history_raw)==2560*1440*8
            reader=runpy.run_path(str(run/'projected-history-source-replay.py'),run_name='history_point_replay')
            history_sample=reader['at_history_uv']
            history_receipt=dict(attachment=metadata,fullSha256=digest(history_raw),routes={},originalRestored=False,
                                 originalControlAtRead=result['control'],event=job['event'],originalShader=job['shader'])
            if 'knownNativeRoute' in job:
                route=job['knownNativeRoute']; raw=Path(route['path']).read_bytes()
                assert len(raw)==290*220*4 and digest(raw)==route['sha256']
                sample=history_sample(history_raw,2560,1440,False,True,raw)
                (storage/'prior-color-at-native.bin').write_bytes(sample)
                history_receipt['routes']['native']=dict(sha256=digest(sample),bytes=len(sample),coordinateSha256=digest(raw))
            (storage/'trace-color-before.bin').write_bytes(base[0])
            (storage/'trace-confidence-before.bin').write_bytes(base[2])
            write(storage/'history-source-reduced.json',history_receipt)
        checked={}
        for mode in ('marker','coordinates'):
            program=(storage/(mode+'.bin')).read_bytes()
            assert digest(program)==job['programs'][mode]
            replacement,errmsg=controller.BuildTargetShader(
                shader.entryPoint,rd.ShaderEncoding.DXBC if job['flip'] else rd.ShaderEncoding.SPIRV,
                program,rd.ShaderCompileFlags(),stage)
            assert replacement!=rd.ResourceId.Null(),errmsg
            checkpoint('shader-built',mode=mode,program=digest(program))
            active=replacement
            controller.ReplaceResource(original,replacement)
            controller.SetFrameEvent(job['event'],True)
            measured=capture()
            assert base[0]==measured[0] and base[2]==measured[2], [digest(x) for x in measured]
            controller.RemoveReplacement(original)
            controller.FreeTargetResource(active)
            active=None
            if mode=='marker':
                mismatched=sum(
                    confidence>0 and (u,v)!=(13107,13107)
                    for confidence,(u,v) in zip(base[2],struct.iter_unpack('<HH',measured[1])))
                assert mismatched==0,mismatched
            else:
                assert digest(measured[1]) != digest(base[1])
                (storage/'history-uv.bin').write_bytes(measured[1])
                if history_raw is not None:
                    sample=history_sample(history_raw,2560,1440,False,False,measured[1])
                    (storage/'prior-color-at-player.bin').write_bytes(sample)
                    history_receipt['routes']['player']=dict(sha256=digest(sample),bytes=len(sample),coordinateSha256=digest(measured[1]))
                    write(storage/'history-source-reduced.json',history_receipt)
            checked[mode]=[digest(x) for x in measured]
            checkpoint('diagnostic-output-qualified',mode=mode,outputs=checked)
        controller.SetFrameEvent(job['event'],True)
        assert base==capture()
        if history_raw is not None:
            current_hash=digest(bytes(controller.GetTextureData(bound_color.resource,rd.Subresource(0,0,0))))
            assert current_hash==history_receipt['fullSha256']
            history_receipt['originalRestored']=True
            write(storage/'history-source-reduced.json',history_receipt)
        (storage/'trace-color.bin').write_bytes(base[0])
        (storage/'trace-confidence.bin').write_bytes(base[2])
        result.update(status='qualified',outputs=checked,baselineRestored=True)
        checkpoint('original-restored',outputs=checked)
    except BaseException:
        result.update(status='failed',error=traceback.format_exc())
    finally:
        if controller is not None:
            if active is not None and original is not None:
                controller.RemoveReplacement(original)
                controller.FreeTargetResource(active)
            controller.Shutdown()
        if source is not None:
            source.Shutdown()
        write(storage/'results.json',result)
    os._exit(0 if result['status']=='qualified' else 1)

def launch(pre_motion=False):
    global out
    request_rows, native_edits, engine, engine_edits = inputs()
    if pre_motion:
        out=run/'projected-ray-search-coordinates'
        probe=runpy.run_path(str(run/'projected-ray-search-coordinate-programs.py'),run_name='ray_search_probe')
        native_edits=(probe['patch_native'](original_path.read_bytes()), native_edits[1])
        engine_edits=(probe['patch_player'](engine),engine_edits[1])
        for row in request_rows:
            row['preMotionProbe']=True
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and lease['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9'
    assert Path(lease['output'])==run
    sys.path.insert(0,str(run.parents[2]/'tools'))
    from artifact_budget import check
    budget=check(run.parents[1],run=run,planned=6_000_000)
    assert budget['allowed'],budget
    out.mkdir(exist_ok=True)
    write(out/'version-provenance.json',trace_version(engine))
    compiler=runpy.run_path(str(run/'projected-reflection-32-step-candidate.py'),run_name='projected_ray_budget')
    tools=compiler['PYTOOLS']
    programs={}
    for job in request_rows:
        tag=job['device']
        dest=out/tag
        dest.mkdir(exist_ok=True)
        modes=('coordinates','marker')
        if tag=='native':
            for mode,program in zip(modes,native_edits):
                (dest/(mode+'.bin')).write_bytes(program)
        else:
            log=dest/'compile.log'
            with log.open('wb') as stream:
                for mode,code in zip(('original',*modes),(engine,*engine_edits)):
                    text,program=(dest/(mode+ext) for ext in ('.hlsl','.bin'))
                    text.write_bytes(code)
                    subprocess.run([str(tools/'dxc.exe'),*compiler['ARGS'],'-Fo',str(program),str(text)],
                                   check=True,timeout=45,stdout=stream,stderr=subprocess.STDOUT)
                    subprocess.run([str(tools/'spirv-val.exe'),'--target-env','vulkan1.1',str(program)],
                                   check=True,timeout=45,stdout=stream,stderr=subprocess.STDOUT)
            assert digest((dest/'original.bin').read_bytes())==job['shader']
        job['programs']={name:digest((dest/(name+'.bin')).read_bytes()) for name in modes}
        programs[tag]=job
    reports={}
    errors={}
    for tag,job in programs.items():
        dest=out/tag
        path=dest/'request.json'
        if tag=='player' and 'native' in reports and not pre_motion:
            native_uv=out/'native/history-uv.bin'
            native_hash=reports['native']['outputs']['coordinates'][1]
            assert digest(native_uv.read_bytes())==native_hash
            job['knownNativeRoute']=dict(path=str(native_uv),sha256=native_hash)
        if (dest/'results.json').is_file() and (dest/'request.json').is_file():
            previous=read(dest/'results.json')
            if previous['status']=='qualified':
                assert read(path)==json.loads(json.dumps(job))
                assert all(expected==digest((dest/(name+'.bin')).read_bytes())
                           for expected,name in zip(previous['outputs']['coordinates'],
                                                    ('trace-color','history-uv','trace-confidence')))
                reports[tag]=previous
                continue
        try:
            write(path,job)
            startup=subprocess.STARTUPINFO()
            startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
            startup.wShowWindow=0
            with (dest/'replay.log').open('wb') as stream:
                child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
                                     cwd=dest,env=dict(os.environ,**{key:str(path)}),
                                     stdout=stream,stderr=subprocess.STDOUT,startupinfo=startup,timeout=280)
            receipt=read(dest/'results.json')
            assert child.returncode==0 and receipt['status']=='qualified',receipt.get('error')
            assert all(expected==digest((dest/(name+'.bin')).read_bytes())
                       for expected,name in zip(receipt['outputs']['coordinates'],
                                       ('trace-color','history-uv','trace-confidence')))
            reports[tag]=receipt
        except Exception:
            errors[tag]=traceback.format_exc()
            write(out/'partial-results.json',dict(qualified=reports,errors=errors))
    if errors:
        write(out/'partial-results.json',dict(qualified=reports,errors=errors))
        raise RuntimeError({tag:diag.strip().splitlines()[-1] for tag,diag in errors.items()})
    write(out/'results.json',reports)


if key in os.environ:
    readback(Path(os.environ[key]))
elif __name__=='__main__' and sys.argv[1:]==['preflight']:
    q, v, s, vs = inputs()
    print(json.dumps(dict(requests=q,native=[digest(a) for a in v],playerSource=[digest(a) for a in vs])))

elif __name__=='__main__' and sys.argv[1:] in (['run'],['pre-motion']):
    launch(pre_motion=sys.argv[1:]==['pre-motion'])
