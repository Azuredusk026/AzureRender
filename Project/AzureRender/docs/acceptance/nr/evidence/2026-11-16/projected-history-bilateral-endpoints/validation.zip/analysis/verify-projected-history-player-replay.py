"""Check original Player attachments against the retained same-event Vulkan export."""
from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys

import numpy as np

run = Path(__file__).resolve().parent
tool = runpy.run_path(str(run/'projected-history-coordinates.py'))
scorer = runpy.run_path(str(run/'score-projected-history-coordinates.py'))
retained = scorer['base']['VULKAN']
read, region = tool['read'], tool['region']
source = read(retained/'summary.json')
expected = tool['request']('player')
out = tool['out']/'player'
assert source['event'] == expected['event'] == 21668
assert sha256((retained/'shader.spv').read_bytes()).hexdigest() == expected['shader']
width, height = tool['size']
x, y, right, bottom = tool['rectangle']
dimensions = (bottom-y, right-x)


def original_outputs():
    result = {}
    for item, name, scalar in (
        ('outputColor', 'color', '<u4'),
        ('outputFootprint', 'footprint', '<u4'),
        ('outputConfidence', 'confidence', 'u1'),
    ):
        row, = [row for row in source['outputs'] if row['name'] == item]
        data = row['data']
        raw = (retained/data['file']).read_bytes()
        assert sha256(raw).hexdigest() == data['sha256']
        assert (row['width'], row['height']) == (width, height)
        kind = np.dtype(scalar)
        assert len(raw) == data['bytes'] == width*height*kind.itemsize
        result[name] = np.frombuffer(region(raw,kind.itemsize,False),dtype=kind).reshape(dimensions)
    return result


def differences(new, old):
    mismatch = new != old
    return dict(total=new.size, exact=int((~mismatch).sum()), different=int(mismatch.sum()),
                archivedSha256=sha256(old.tobytes()).hexdigest(), replaySha256=sha256(new.tobytes()).hexdigest())


def run_check(archived):
    receipt = read(out/'results.json')
    assert receipt['status'] == 'qualified' and receipt['baselineRestored']
    hdr, footprints, confidence = receipt['control']
    replayed = dict(color=scorer['check_snapshot'](out/'trace-color.bin',hdr,'<u4',dimensions),
                    confidence=scorer['check_snapshot'](out/'trace-confidence.bin',confidence,'u1',dimensions))
    # The unchanged original footprint is hashed but is only written as coordinates by the diagnostic.
    proof = dict(
        event=expected['event'], shader=expected['shader'], rectangle=tool['rectangle'],
        replayWithinSessionExact=receipt['baselineRestored'],
        priorExport={name:differences(value,archived[name]) for name,value in replayed.items()},
        originalFootprintHashEqual=(footprints == sha256(archived['footprint'].tobytes()).hexdigest()),
    )
    decoded = {name: scorer['decode'](image['color'])@scorer['weight']
               for name,image in (('archived',archived),('replay',replayed))}
    delta = abs(decoded['archived']-decoded['replay'])
    mask = (archived['confidence']>0)&(replayed['confidence']>0)
    for name,r in scorer['base']['REGIONS'].items():
        def crop(a):
            return scorer['base']['cut'](a,scorer['base']['local'](r))
        valid=crop(mask)
        if valid.any():
            proof.setdefault('regions',{})[name] = dict(commonPositiveConfidence=int(valid.sum()),
                packedColorDifference=int((valid&crop(archived['color']!=replayed['color'])).sum()),
                absoluteCompressedLumaDifference=np.percentile(crop(delta)[valid],[50,90,99,100]).tolist())
    (tool['out']/'player-same-event-export-check.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
    print(json.dumps(proof))


archived = original_outputs()
if sys.argv[1:] == ['preflight']:
    assert (archived['confidence']>0).sum()>10000
    assert differences(np.asarray([1,2]),np.asarray([1,3]))['different']==1
    print(json.dumps({name:sha256(v.tobytes()).hexdigest() for name,v in archived.items()}))
elif sys.argv[1:] == ['check']:
    run_check(archived)
else:
    raise SystemExit('expected preflight or check')
