"""Screen position effect of deterministic trace phase, validated against observed Player UV."""
from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys

import numpy as np

root=Path(__file__).resolve().parent
s=runpy.run_path(str(root/'score-projected-history-coordinates.py'))
b=s['base']
folder=s['floor']


def fma(x,y,z): return (np.asarray(x,np.float64)*np.asarray(y,np.float64)+np.asarray(z,np.float64)).astype(np.float32)


def phase(x,y,seed):
    f=lambda u: np.uint32(u).view(np.float32)
    a=fma(seed,f(0x40054fdf),x)
    b=fma(seed,f(0x409bbe77),y)
    h=fma(b,f(0x3bbf4590),a*f(0x3d897143))
    h=(h-np.floor(h))*f(0x4253ee82)
    return h-np.floor(h)


def geometry():
    q=s['source']['v']
    data={x['name']:x['data'] for x in q['inputs']+q['outputs'] if 'data' in x}
    v=np.asarray(q['frameRows'],dtype=np.float32)
    h,w=b['FRAME']
    assert v[25,:2].tolist()==[w,h] and v[29,3]==1
    sample=lambda k,t,shape:s['check_snapshot'](b['VULKAN']/data[k]['file'],data[k]['sha256'],t,shape)
    crop=b['CROP'];l,t,r,bt=crop
    cm=lambda a:b['cut'](a,crop)
    depth=sample('currentDepth','<f4',(h,w))
    mask=cm(sample('surfaceMask','u1',(h,w)))>127
    normal=cm(sample('normalRoughness','<f4',(h,w,4)))[...,:2]
    init=next(x for x in q['files'] if x['file']=='confidence-before-dispatch.bin')
    eligible=cm(s['check_snapshot'](b['VULKAN']/init['file'],init['sha256'],'u1',(h,w)))>0
    size=np.array([w,h],dtype=np.float32)
    xx,yy=np.meshgrid(np.arange(l,r,dtype=np.float32)+.5,np.arange(t,bt,dtype=np.float32)+.5)
    uv=np.stack((xx*v[25,2],yy*v[25,3]),axis=-1)
    nd=fma(uv,2,-1)
    z=cm(depth)
    norm=lambda x:x/np.linalg.norm(x,axis=-1,keepdims=True)
    cp=fma(nd[...,0,None],v[6],nd[...,1,None]*v[7])
    cp=fma(z[...,None],v[8],cp)+v[9]
    incident=norm(cp[...,:3]/cp[...,3,None])
    nrm=b['oct_decode'](normal).astype(np.float32)
    nrm=fma(nrm[...,0,None],v[0,:3],nrm[...,1,None]*v[1,:3])
    nrm=fma(b['oct_decode'](normal)[...,2,None].astype(np.float32),v[2,:3],nrm)
    dot=fma(incident[...,2],nrm[...,2],fma(incident[...,1],nrm[...,1],incident[...,0]*nrm[...,0]))
    reflect=fma(nrm,-2*dot[...,None],incident)
    xyzw=fma(reflect[...,0,None],v[3],reflect[...,1,None]*v[4])
    xyzw=fma(reflect[...,2,None],v[5],xyzw)
    n_xyz=np.concatenate((nd,z[...,None]),axis=-1)
    xyzw+=np.concatenate((n_xyz,np.ones_like(z)[...,None]),axis=-1)
    slope=xyzw[...,:3]/xyzw[...,3,None]-n_xyz
    half=np.linalg.norm(slope[...,:2],axis=-1)*np.float32(.5)
    with np.errstate(divide='ignore',invalid='ignore'):
        beyond=np.maximum(np.abs(fma(nd,half[...,None],slope[...,:2]))-half[...,None],0)
        limit=np.min(1-beyond/np.abs(slope[...,:2]),axis=-1)/half
        delta=slope*limit[...,None]
    assert np.isfinite(delta[eligible]).all()
    return v,depth,mask,eligible,(xx,yy),np.concatenate((uv,z[...,None]),axis=-1),delta,size


def trace(g,steps,seed,invert_y=False):
    v,depth,mask,eligible,(x,y),origin,delta,size=g
    count=np.where(mask,steps,max(4,int(np.ceil(steps/8)))).astype(np.float32)
    tolerance=np.maximum(abs(delta[...,2])/count,np.float32(.0001))
    step=(delta*np.array([.5,.5,1],dtype=np.float32))*(1/count[...,None])
    length=np.max(abs(step[...,:2]*size),axis=-1)
    jitter=phase(x,size[1]-y if invert_y else y,np.float32(seed))
    initial=np.where(length<1,1/(length+np.float32(.001)),jitter)
    cur=fma(step,initial[...,None],origin)
    def get(p):
        uv=np.clip(p[...,:2],0,1)
        tex=(uv*size).astype(np.int32)
        return depth[np.minimum(tex[...,1],int(size[1]-1)),np.minimum(tex[...,0],int(size[0]-1))]
    prev=cur[...,2]-get(cur)
    hit=np.zeros(count.shape,dtype=bool)
    found=np.zeros((*count.shape,2),dtype=np.float32)
    for i in range(0,steps,4):
        active=eligible&~hit&(i<count)
        if not active.any():break
        for lane in range(1,5):
            p=fma(step,lane,cur)
            difference=p[...,2]-get(p)
            owns=active&~hit&(abs(difference+tolerance)<tolerance)
            with np.errstate(divide='ignore',invalid='ignore'):
                u=np.clip(prev[owns]/(prev[owns]-difference[owns]),0,1)+np.float32(lane-1)
            found[owns]=fma(step[owns],u[...,None],cur[owns])[...,:2]
            hit|=owns
            prev=difference
        cur=fma(step,4,cur)
    return found,hit


def observations():
    cap= b['CROP'];w,h=(cap[i+2]-cap[i] for i in (0,1))
    models=read_ledgers={t:b['read'](folder/t/'results.json') for t in ('native','player')}
    coords,active={},{}
    for tag,obs in models.items():
        assert obs['status']=='qualified' and obs['baselineRestored']
        _,c,q=obs['outputs']['coordinates']
        path=folder/tag
        f=s['check_snapshot'](path/'history-uv.bin',c,'<u2',(h,w,2)).astype(np.float64)/65535
        if tag=='native': f[...,1]=1-f[...,1]
        coords[tag]=f
        active[tag]=s['check_snapshot'](path/'trace-confidence.bin',q,'u1',(h,w))>0
    return coords,active


def score():
    g=geometry()
    coords,active=observations()
    available=active['player']&active['native']
    scale=g[-1]*2
    # Native frame uses phase 42 in its own raster coordinates; physical trace resolution is identical.
    jobs=[(128,0,False),(128,42,False),(128,42,True),(32,0,False),(32,42,False),(32,0,True),(32,42,True)]
    traces={k:trace(g,*k) for k in jobs}
    joint=available&np.logical_and.reduce([o[1] for o in traces.values()])
    _,_,manifest,items=s['original_history_depths']()
    entry,=[o for o in items if o['role']=='previousColor']
    raw=(manifest.parent/entry['file']).read_bytes()
    assert len(raw)==entry['bytes'] and sha256(raw).hexdigest()==entry['sha256']
    hdr=np.frombuffer(raw[:entry['levels'][0]['bytes']],dtype='<f2').reshape(1440,2560,4)
    point=runpy.run_path(str(root/'score-projected-native-history-color-motion.py'))['point']
    flipped=lambda xy:xy*[1.,-1.]+[0.,1.]
    sample,addr=point(flipped(coords['native']),hdr)
    expected=s['compressed_rgb'](sample)@s['weight']
    m={}
    d={}
    for k,(pos,_) in traces.items():
        values,good=point(flipped(pos),hdr)
        joint &= good
        m[k]=s['compressed_rgb'](values)@s['weight']
        d[k]=np.linalg.norm((pos-coords['native'])*scale,axis=-1)
    joint &= addr

    result=dict(status='cpu-trace-phase-control', scope='Game ray search preview. Retains Player geometry and omits the history-motion acceptance stage.',cases={})
    for steps,seed,rev in jobs:
        key=(steps,seed,rev)
        uv,rays=traces[key]
        distances={tag:np.linalg.norm((uv-coords[tag])*scale,axis=-1) for tag in coords}
        case={}
        for name,box in b['REGIONS'].items():
            cut=lambda a:b['cut'](a,b['local'](box))
            eligible=cut(available&rays)
            metrics={tag:np.percentile(cut(delta)[eligible],[10,50,90,99]).tolist()
                     for tag,delta in distances.items()}
            common=cut(joint)
            assert common.any(),name
            dist=np.percentile(cut(d[key])[common],[50,90,99]).tolist()
            error=abs(cut(m[key]-expected)[common])
            case[name]=dict(samples=int(eligible.sum()),sameFixedNativeColorControl={
                'sharedSamples':int(common.sum()),'distancePixelsMedianP90P99':dist,
                'lumaMeanAbs':float(error.mean()),'lumaMedianAbs':float(np.median(error))},
                existingPlayerPositiveGeometricHit=int(cut(active['player']&rays).sum()),
                rawTraceToObservedPriorEndpointPixels=metrics,
                withinHalfPixelOfObservedPlayer=int((eligible&(cut(distances['player'])<=.5)).sum()))
        result['cases'][f'{steps}-{seed}-{rev}']=case
        print(steps,seed,rev,case['centerFloor'],case['cyanRing'],flush=True)
    (folder/'player-trace-phase-cpu.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')


if __name__=='__main__':
    assert sys.argv[1:] in (['preflight'],['score'])
    np.testing.assert_allclose(fma(np.array([1.,2.]),2,3),[5.,7.])
    assert np.all((phase(np.arange(15)+.5,np.arange(15)+.5,42)>=0)&(phase(np.arange(15)+.5,np.arange(15)+.5,42)<1))
    if sys.argv[1:]==['score']:score()
