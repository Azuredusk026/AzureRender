"""Separate a source substitution at actual native UV from the residual to the Player ray."""
from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys

import numpy as np

run=Path(__file__).resolve().parent
f=runpy.run_path(str(run/'score-projected-history-coordinates.py'),run_name='endpoint_helpers')
s=f['source']; c=f['base']; folder=s['out']; verify=f['check_snapshot']
read=lambda p:json.loads(p.read_bytes())
box=c['CROP']; w,h=(box[i+2]-box[i] for i in (0,1))
coef=np.array([.2126,.7152,.0722])


def decompose(n, p_at_n, p):
    source=p_at_n-n
    endpoint=p-p_at_n
    np.testing.assert_allclose(source+endpoint,p-n,atol=3e-8)
    return source,endpoint


def score(reduced=False):
    npath=f['floor']/'native'; nrec=read(npath/'results.json')
    assert nrec['status']=='qualified' and nrec['baselineRestored']
    rgb_id,uv_id,confidence_id=nrec['outputs']['coordinates']
    uv=verify(npath/'history-uv.bin',uv_id,'<u2',(h,w,2))
    n0=f['decode'](verify(npath/'trace-color.bin',rgb_id,'<u4',(h,w)))
    nc=verify(npath/'trace-confidence.bin',confidence_id,'u1',(h,w))
    pf=c['VULKAN']; old=read(pf/'summary.json')
    assert old['event']==21668
    collector=s['reader']
    provenance={}
    if reduced:
        nd,depth_ids,manifest,rows=f['original_history_depths']()
        marker=read(f['floor']/'player/history-source-reduced.json')
        path=f['floor']/'player/prior-color-at-native.bin'; key=marker['routes']['native']
        assert key['coordinateSha256']==uv_id and key['bytes']==h*w*8
        assert marker['attachment']==next(row for row in collector['request']('player')['inputs'] if row['name']=='prior-color')
        assert marker['event']==21668 and marker['originalShader']==collector['request']('player')['shader']
        control=marker['originalControlAtRead']
        player_baseline={key:verify(f['floor']/'player'/file,control[i],kind,(h,w))
            for key,file,i,kind in (('color','trace-color-before.bin',0,'<u4'),
                                     ('confidence','trace-confidence-before.bin',2,'u1'))}
        entry=next(row for row in rows if row['role']=='previousColor')
        raw=(manifest.parent/entry['file']).read_bytes()
        assert sha256(raw).hexdigest()==entry['sha256']
        pixels=collector['at_history_uv'](raw,2560,1440,True,True,uv.tobytes())
        sci=dict(native=f['compressed_rgb'](np.frombuffer(pixels,dtype='<f2').reshape(h,w,4)),
                 player=f['compressed_rgb'](verify(path,key['sha256'],'<f2',(h,w,4))))
        provenance=dict(native=sha256(pixels).hexdigest(),player=key['sha256'])
    else:
        previous=read(folder/'readback.json')
        assert set(previous)=={'native','player'}
        sci={}
        nd={}
        for t,row in previous.items():
            assert row['status']=='qualified' and row['request']['routes']['native']['sha256']==uv_id
            proof=row['associatedColors']['native']
            assert proof['coordinateSha256']==uv_id
            pixels=verify(folder/t/'prior-color-at-native.bin',proof['sha256'],'<f2',(h,w,4))
            sci[t]=f['compressed_rgb'](pixels)
            line=next(e for e in row['payloads'] if e['name']=='prior-depth')
            nd[t]=verify(folder/t/'prior-depth.bin',line['sha256'],'<f4',f['shape'])
        provenance={t:previous[t]['associatedColors']['native']['sha256'] for t in sci}
    nworld,nvisible,_=f['world_from_history'](uv,nd['native'],f['N'],True)
    puv=uv.copy();puv[...,1]=65535-puv[...,1]
    pworld,pvisible,_=f['world_from_history'](puv,nd['player'],f['V'],False)
    distance=np.linalg.norm(nworld-pworld,axis=-1)
    store={e['name']:e['data'] for group in ('outputs','inputs') for e in old[group] if 'data' in e}
    pdata=lambda name,t:c['cut'](verify(pf/store[name]['file'],store[name]['sha256'],t,f['shape']),box)
    pc=player_baseline['confidence'] if reduced else pdata('outputConfidence','u1')
    p0=f['decode'](player_baseline['color'] if reduced else pdata('outputColor','<u4'))
    nnew=read(f['geometry']/'results.json')
    depthMeta=next(x for x in nnew['files'] if x['name']=='current-depth')
    dN=verify(f['geometry']/'current-depth.bin',depthMeta['sha256'],'<f4',(h,w))
    dP=pdata('currentDepth','<f4')
    nmeta=read(c['NATIVE']/'event-8702.json')
    nm=np.array([x['float32'] for x in nmeta['blocks'][0]['variables'][12:16]],dtype=float)
    vm=np.asarray(old['frameRows'][6:10],dtype=float)
    receiver=np.abs(c['reconstruct'](dN,box,nm)[...,2]-c['reconstruct'](dP,box,vm)[...,2])<=.02
    stable=np.ones((h,w),dtype=bool)
    for u_resolution,v_resolution in ((2560,1440),(1280,720)):
        stable &= f['stable_indices'](uv[...,0],u_resolution)&f['stable_indices'](uv[...,1],v_resolution)
    expected=f['coherently_sampled'](sci['native'],n0)
    common=receiver&(nc>0)&(pc>0)&stable&nvisible&pvisible&expected
    nn=n0@coef; pn=sci['player']@coef; pp=p0@coef
    source,route=decompose(nn,pn,pp)
    regions=read(s['root']/'docs/acceptance/nr/evidence/2026-11-16/joint-scene-native-floor/results.json')['rectangles']
    report=dict(status='measured-actual-history-at-fixed-native-endpoints', nativeUvSha256=uv_id,
      scope='One order of comparison: substitute Player prior color while keeping the original native endpoint, then compare to the actual Player reflection. Treat the residual as a change of endpoint and packed output precision. The two-way decomposition uses both readbacks.',
      sourceAttachmentSha256=provenance,regions={})
    for name in ('centerFloor','cyanRing'):
        rect=[v//2-box[i%2] for i,v in enumerate(regions[name])];sub=lambda x:c['cut'](x,rect)
        per={}
        for limit in (.02,.05,.1):
            mask=sub(common&(distance<=limit))
            assert mask.any(),(name,limit)
            q=lambda a:np.percentile(sub(a)[mask],(10,50,90)).tolist()
            total=sum(abs(sub(pp-nn)[mask])); by_source=sum(abs(sub(source)[mask])); by_route=sum(abs(sub(route)[mask]))
            per[f'{limit:.2f}']=dict(matchedSamples=int(mask.sum()),nativeLuma=q(nn),playerLumaUsingNativeUv=q(pn),
                playerActualLuma=q(pp),sourceDelta=q(source),routeAndPackingDelta=q(route),
                sourceAbsolute=by_source,routeAndPackingAbsolute=by_route,observedAbsolute=total,
                sourceFractionOfAbsoluteContributions=float(by_source/(by_source+by_route)))
        report['regions'][name]=dict(eligible=int(sub(common).sum()),byDepth=per)
    p=(f['floor'] if reduced else folder)/'fixed-native-route-comparison.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    for name,row in report['regions'].items():print(name,row['byDepth']['0.02'])


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        a,b=decompose(np.array([.3,.02,.1]),np.array([.2,.2,.05]),np.array([.1,.03,.05]))
        np.testing.assert_allclose(a,[-.1,.18,-.05]);np.testing.assert_allclose(b,[-.1,-.17,0])
        print('Coordinate basis:',s['registration']())
        d=read(c['VULKAN']/'summary.json');names={v['name'] for v in d['inputs']+d['outputs'] if 'data' in v}
        assert {'outputColor','outputConfidence','currentDepth'}<=names
    else:
        assert sys.argv[1:] in (['score'],['score-reduced']);score(reduced=sys.argv[1:]==['score-reduced'])
