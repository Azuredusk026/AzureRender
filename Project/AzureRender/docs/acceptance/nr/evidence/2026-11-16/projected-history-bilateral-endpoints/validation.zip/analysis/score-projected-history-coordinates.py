"""Use the hardware history sample coordinates to separate ray location and radiance."""
from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys

import numpy as np

root=Path(__file__).resolve().parent
source=runpy.run_path(str(root/'score-projected-history-source.py'))
read=source['read']
shape,N,V=source['shape'],source['nmat'],source['vmat']
floor=root/'projected-history-coordinates'
base=runpy.run_path(str(root/'score-native-floor-reflection-inputs.py'))
geometry=base['OUT']
decode=base['decode_reflected_color']
weight=np.array([.2126,.7152,.0722])


def world_from_history(uv_raw, depth, matrix, native=False):
    height,width=depth.shape
    uv=np.asarray(uv_raw,dtype=np.float64)/65535.
    if native:
        uv=uv.copy()
        uv[...,1]=1-uv[...,1]
    xy=(uv*np.array([width,height])).astype(np.int64)
    i=np.minimum(width-1,xy[...,0]); j=np.minimum(height-1,xy[...,1])
    d=depth[j,i]
    mask=np.isfinite(d)&(d>0)&(d<=1)
    p=np.concatenate((uv*2-1,np.where(mask,d,.1)[...,None],np.ones_like(d[...,None])),axis=-1)
    v=source['homogeneous'](p,matrix)
    if native: v*=source['flip']
    mask&=np.isfinite(v).all(axis=-1)
    return v,mask,uv


def check_snapshot(source_path,fingerprint,dtype,dimensions):
    raw=source_path.read_bytes()
    assert sha256(raw).hexdigest()==fingerprint,source_path
    return np.frombuffer(raw,dtype=dtype).reshape(dimensions)


def stable_indices(quantized, size):
    q=quantized.astype(np.int64)
    low=np.clip(((2*q-1)*size)//(2*65535),0,size-1)
    high=np.clip(((2*q+1)*size)//(2*65535),0,size-1)
    return low==high


def compressed_rgb(linear):
    rgb=linear[..., :3].astype(np.float64)
    den=1+rgb.max(axis=-1,keepdims=True)
    assert (den>0).all()
    return np.maximum(rgb/den,0)


def coherently_sampled(expected, observed):
    base=np.floor(np.log2(np.maximum(expected, 2**-14))).astype(np.int64)
    ulp=np.exp2(base-np.asarray([6,6,5]))
    return (abs(expected-observed) <= ulp + 3e-7).all(axis=-1)


def original_history_depths():
    rd=source['reader']
    native=rd['native_fixture'](rd['request']('native'),None)
    manifest=Path(native['replaySource']['manifest'])
    rows=read(manifest)['textures']
    nd=next(row for row in rows if row['role']=='previousDepth')
    pd=next(row for row in source['v']['inputs'] if row['name']=='previousDepth')['data']
    raw=(manifest.parent/nd['file']).read_bytes()
    assert len(raw)==nd['bytes'] and sha256(raw).hexdigest()==nd['sha256']
    n=np.frombuffer(raw[:nd['levels'][0]['bytes']],dtype='<f4').reshape(shape)[::-1]
    v=check_snapshot(rd['current'].parent/pd['file'],pd['sha256'],'<f4',shape)
    return dict(native=n,player=v),dict(native=nd['sha256'],player=pd['sha256']),manifest,rows


def reduced_resources(capture,w,h):
    depths,depth_ids,manifest,rows=original_history_depths()
    entry=next(row for row in rows if row['role']=='previousColor')
    raw=(manifest.parent/entry['file']).read_bytes()
    assert len(raw)==entry['bytes'] and sha256(raw).hexdigest()==entry['sha256']
    rd=source['reader']
    rec=read(floor/'player/history-source-reduced.json')
    assert rec['originalRestored'] and set(rec['routes'])=={'native','player'}
    assert rec['attachment']==next(row for row in rd['request']('player')['inputs'] if row['name']=='prior-color')
    exact=dict(native={},player={})
    for route,meta in rec['routes'].items():
        uv_id=capture[route]['outputs']['coordinates'][1]
        coords=(floor/route/'history-uv.bin').read_bytes()
        assert sha256(coords).hexdigest()==uv_id==meta['coordinateSha256'] and len(coords)==h*w*4
        x=rd['at_history_uv'](raw,2560,1440,True,route=='native',coords)
        exact['native'][route]=compressed_rgb(np.frombuffer(x,dtype='<f2').reshape((h,w,4)))
        y=check_snapshot(floor/'player'/f'prior-color-at-{route}.bin',meta['sha256'],'<f2',(h,w,4))
        assert meta['bytes']==y.nbytes and np.isfinite(y).all()
        exact['player'][route]=compressed_rgb(y)
    return depths,exact,dict(origDepthIds=depth_ids,nativePriorColor=entry['sha256'],playerPriorColor=rec['fullSha256'])


def score(reduced=False):
    calibrated=source['registration']()
    capture=read(floor/'results.json')
    assert set(capture)=={'native','player'}
    previous={} if reduced else read(source['out']/'readback.json')
    assert reduced or set(previous)==set(capture)
    rectangle=base['CROP']
    w,h=(rectangle[i+2]-rectangle[i] for i in (0,1))
    confidence,uv,depth,color,world,finite,coordinates={},{},{},{},{},{},{}
    compressed,exact={},{}
    provenance=None
    if reduced:
        depth,exact,provenance=reduced_resources(capture,w,h)
    for tag,record in capture.items():
        assert record['status']=='qualified' and record['baselineRestored']
        control, marker, linked = record['control'], record['outputs']['marker'], record['outputs']['coordinates']
        assert control[0]==marker[0]==linked[0] and control[2]==marker[2]==linked[2]
        mat=N if tag=='native' else V
        c,d,e=map(lambda p: floor/tag/(p+'.bin'),('trace-color','history-uv','trace-confidence'))
        compressed[tag]=decode(check_snapshot(c,linked[0],'<u4',(h,w)))
        color[tag]=compressed[tag]@weight
        confidence[tag]=check_snapshot(e,linked[2],'u1',(h,w))/255
        coordinates[tag]=check_snapshot(d,linked[1],'<u2',(h,w,2))
        if not reduced:
            old,=[v for v in previous[tag]['payloads'] if v['name']=='prior-depth']
            depth[tag]=check_snapshot(source['out']/tag/'prior-depth.bin',old['sha256'],'<f4',shape)
            exact[tag]={}
            for route, value in previous[tag].get('associatedColors',{}).items():
                path=source['out']/tag/f'prior-color-at-{route}.bin'
                assert value['coordinateSha256']==capture[route]['outputs']['coordinates'][1]
                pixels=check_snapshot(path,value['sha256'],'<f2',(h,w,4))
                assert np.isfinite(pixels).all()
                exact[tag][route]=compressed_rgb(pixels)
        world[tag],finite[tag],uv[tag]=world_from_history(coordinates[tag],depth[tag],mat,tag=='native')
    associated=all(set(d)=={'native','player'} for d in exact.values())
    r=read(geometry/'results.json')
    native,=[x for x in r['files'] if x['name']=='current-depth']
    depthN=check_snapshot(geometry/'current-depth.bin',native['sha256'],'<f4',(h,w))
    player=base['VULKAN']
    exported=read(player/'summary.json')
    info,=[q['data'] for q in exported['inputs'] if q['name']=='currentDepth']
    depthV=base['cut'](check_snapshot(player/info['file'],info['sha256'],'<f4',shape),rectangle)
    # Use the matrices bound to this dispatch at the current primary ground surface.
    nmeta=read(base['NATIVE']/'event-8702.json')
    nm=np.array([x['float32'] for x in nmeta['blocks'][0]['variables'][12:16]],dtype=float)
    vm=np.asarray(exported['frameRows'][6:10],dtype=float)
    sameSurface=np.abs(base['reconstruct'](depthN,rectangle,nm)[...,2]-
                       base['reconstruct'](depthV,rectangle,vm)[...,2])<=.02
    common=(confidence['native']>0)&(confidence['player']>0)&sameSurface
    valid=common&finite['native']&finite['player']
    if associated:
        stable={t:stable_indices(q[...,0],2560)&stable_indices(q[...,1],1440) for t,q in coordinates.items()}
        observed={t:coherently_sampled(exact[t][t],c) for t,c in compressed.items()}
        color_control={t:valid&stable[t] for t in stable}
        eligible=valid&stable['native']&stable['player']
        verified=eligible&observed['native']&observed['player']
        nn,np_,pn,pp=[exact[a][b]@weight for a,b in (('native','native'),('native','player'),
                                                      ('player','native'),('player','player'))]
        location=((np_-nn)+(pp-pn))*.5
        radiance=((pn-nn)+(pp-np_))*.5
        np.testing.assert_allclose(location+radiance,pp-nn,atol=1e-12)
    worldDistance=np.linalg.norm(world['native']-world['player'],axis=-1)
    pixelDistance=np.linalg.norm((uv['native']-uv['player'])*np.array([2560,1440]),axis=-1)
    luma=np.abs(color['native']-color['player'])
    energy=np.abs(color['native']*confidence['native']-color['player']*confidence['player'])
    def percentiles(a,m):
        return np.percentile(a[m],(10,50,90)).tolist() if m.any() else None
    def scene(box):
        tab=lambda a:base['cut'](a,base['local'](box))
        accepted,allCommon=tab(valid),tab(common)
        result=dict(commonRays=int(allCommon.sum()),validPriorDepth=int(accepted.sum()),
                    worldDistanceMeters=percentiles(tab(worldDistance),accepted),
                    historySamplingDistancePixels=percentiles(tab(pixelDistance),accepted))
        total=tab(energy)[accepted].sum()
        for t in (.02,.05,.10,.25):
            match=accepted&(tab(worldDistance)<=t)
            result[str(t)]=dict(matched=int(match.sum()),signalAbsLumaError=percentiles(tab(luma),match),
                               contributionToPairedLumaError=float(tab(energy)[match].sum()/total) if total else None)
        if associated:
            good=tab(verified)
            rows={}
            for tag in ('native','player'):
                control=tab(color_control[tag])
                n=int(control.sum())
                same=int((control&tab(observed[tag])).sum())
                rows[tag]=dict(eligible=n,consistent=same,rate=same/n if n else None)
            sharedConfidence=np.minimum(tab(confidence['native']),tab(confidence['player']))
            def energies(mask):
                l=tab(location)[mask]; r=tab(radiance)[mask]; w=sharedConfidence[mask]
                ls=float(np.sum(abs(l)*w)); rs=float(np.sum(abs(r)*w))
                return dict(samples=int(mask.sum()),weightedLocationAbs=ls,weightedRadianceAbs=rs,
                    weightedJointAbs=float(np.sum(abs(l+r)*w)),
                    radianceFractionOfCombinedAbsolute=rs/(ls+rs) if ls+rs else None)
            result['pointColor']=dict(checkedAddresses=int(tab(eligible).sum()),coherent=int(good.sum()),
                sameCaptureColor=rows,absoluteLocationLuma=percentiles(tab(abs(location)),good),
                absoluteRadianceLuma=percentiles(tab(abs(radiance)),good),
                signedRadianceLuma=percentiles(tab(radiance),good),
                sameWorldAbsoluteRadianceLuma=percentiles(tab(abs(radiance)),good&(tab(worldDistance)<=.05)),
                contributionEnergy=energies(good),
                contributionEnergyByWorldLimit={str(t):energies(good&(tab(worldDistance)<=t)) for t in (.02,.05,.10)},
                fullResolutionColorSource='both original RGBA16F inputs sampled at both captured endpoints')
        return result
    scores={k:scene(b) for k,b in base['REGIONS'].items()}
    result=dict(status='measured-hardware-prior-endpoints', calibration=calibrated,
                exactPointColors=associated,regions=scores)
    if reduced:
        result['reducedReadback']=provenance
    (floor/('comparison-reduced.json' if reduced else 'comparison.json')).write_text(
        json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps(result))


def selftest():
    raw=np.array([[[16384,16384]]],dtype='u2')
    d=np.ones((2,2))
    d[0,0]=.125;d[1,0]=.25
    a,ms,aw=world_from_history(raw,d,np.eye(4))
    b,ns,bw=world_from_history(raw,d,np.eye(4),True)
    assert ms.item() and ns.item()
    np.testing.assert_allclose(a[...,2],.125)
    np.testing.assert_allclose(b[...,2],.25)
    np.testing.assert_allclose(aw+bw,[[[2*16384/65535,1.]]])
    assert stable_indices(np.array([0,10000,65535]),2560).all()
    np.testing.assert_array_equal(stable_indices(np.array([32767,32768]),2560),[False,True])
    measured=compressed_rgb(np.asarray([2.,1.,.5,0.]))
    np.testing.assert_allclose(measured,[2/3,1/3,1/6])
    assert coherently_sampled(measured, measured).item()
    assert not coherently_sampled(measured, measured+0.1).item()
    print(json.dumps(source['registration']()))


if __name__=='__main__':
    selftest()
    if sys.argv[1:] in (['score'],['score-reduced']):
        score(reduced=sys.argv[1:]==['score-reduced'])
    else:
        assert sys.argv[1:]==['preflight']
