"""Check rest geometry and six camera framing on the persisted animated asset."""
from collections import defaultdict
from hashlib import file_digest
from itertools import permutations
import json
import math
from pathlib import Path
import runpy
import struct

import numpy as np

run=Path(__file__).resolve().parent
api=runpy.run_path(str(run/'character-six-view-inputs.py'),run_name='dynamic_asset_source')
_,project,level,scene,actor=api['source_inputs']()
camera=api['camera_inputs'](scene,actor)
base=api['grid']/'native-face-skin-stages'
ref=json.loads((base/'results.json').read_bytes())
digest=lambda path:api['digest'](path)


def pair(native,source,tolerance):
    """Maximum one-to-one UV triangle matching, independent of winding or rounding edges."""
    perm=list(permutations(range(3)))
    maps=defaultdict(list)
    for i,xy in enumerate(np.floor(native.mean(1)/tolerance).astype(int)):
        maps[tuple(xy)].append(i)
    adj=[]
    for i,(x,y) in enumerate(np.floor(source.mean(1)/tolerance).astype(int)):
        nearby=[j for a in (-1,0,1) for b in (-1,0,1) for j in maps.get((x+a,y+b),[])]
        a=source[i]
        matched=[]
        for j in nearby:
            delta=min(float(np.max(abs(a-native[j,list(p)]))) for p in perm)
            if delta<=tolerance:
                matched.append((delta,j))
        adj.append([j for _,j in sorted(matched)])
    native_to_public={}
    def augment(i,visited):
        for j in adj[i]:
            if j in visited:continue
            visited.add(j)
            k=native_to_public.get(j)
            if k is None or augment(k,visited):
                native_to_public[j]=i
                return True
        return False
    for i in sorted(range(len(adj)),key=lambda i:len(adj[i])):
        augment(i,set())
    absent_player=sorted(set(range(len(source)))-set(native_to_public.values()))
    absent_native=sorted(set(range(len(native)))-native_to_public.keys())
    return dict(matched=len(native_to_public),assetOnly=absent_player,nativeOnly=absent_native,mapping=native_to_public)


def native_only_vertex_reuse(native_uv, native_ind, asset_uv, asset_ind, result, radius):
    candidate=defaultdict(list)
    for j,xy in enumerate(np.floor(asset_uv/radius).astype(int)):
        candidate[tuple(xy)].append(j)
    survivors=set()
    support=defaultdict(set)
    perms=list(permutations(range(3)))
    for i,j in result['mapping'].items():
        n,p=native_ind[i],asset_ind[j]
        best=min(perms,key=lambda x:np.max(abs(native_uv[n]-asset_uv[p[list(x)]])))
        p=p[list(best)]
        for a,b in zip(n,p):
            support[int(a)].add(int(b))
    missing=[]
    unresolved=[]
    choices={}
    for i in np.unique(native_ind[result['nativeOnly']].flatten()):
        x,y=np.floor(native_uv[i]/radius).astype(int)
        matches={j for a in (-1,0,1) for b in (-1,0,1) for j in candidate.get((x+a,y+b),[])
                 if np.max(abs(native_uv[i]-asset_uv[j]))<=radius}
        supported=matches&support[int(i)]
        if len(matches)==0:
            missing.append(int(i))
        elif len(supported)==1 or len(matches)==1:
            survivors.add(int(i))
            choices[int(i)]=next(iter(supported if len(supported)==1 else matches))
        else:
            unresolved.append(int(i))
    need=set(missing)|set(unresolved)
    return dict(totalNativeVertices=len(need)+len(survivors),uniquelyReusable=len(survivors),
                absentFromAsset=len(missing),ambiguousFromAsset=len(unresolved),
                nativeOnlyTrianglesWithExistingRigVertices=sum(all(int(i) in survivors for i in native_ind[k])
                                                                 for k in result['nativeOnly']))


def load_program():
    with actor.open('rb') as stream:
        magic,version,_,l,typ=struct.unpack('<5I',stream.read(20))
        assert (magic,version,typ)==(0x46546c67,2,0x4e4f534a)
        mesh=json.loads(stream.read(l))
        length,kind=struct.unpack('<2I',stream.read(8))
        assert kind==0x4e4942
        raw=stream.read(length)
    return mesh,raw


def world_face_framing(v):
    rot=math.radians(camera['heroTransform']['rotation'][1])
    mat=np.array([[math.cos(rot),0,-math.sin(rot)],[0,1,0],[math.sin(rot),0,math.cos(rot)]])
    world=v@mat+camera['heroTransform']['translation']
    regions={}
    for tag,pose in camera['views'].items():
        if tag=='back-detail':continue
        f=np.array(pose['forward']); right=np.cross(f,[0,1,0]); delta=world-pose['t']
        d=delta@f
        k=math.tan(math.radians(pose['fov']/2))
        xy=np.column_stack((.5+.5*(delta@right)/(k*d*(16/9)),.5-.5*delta[:,1]/(k*d)))
        assert xy.min()>.1 and xy.max()<.9 and min(d)>.1
        regions[tag]=dict(bounds=[xy.min(0).tolist(),xy.max(0).tolist()],distance=[float(min(d)),float(max(d))])
    return regions


def score():
    model,raw=load_program()
    kind={5126:'<f4',5123:'<u2',5125:'<u4'}
    extent={'SCALAR':1,'VEC2':2,'VEC3':3}
    meshes={p['name']:p for p in model['meshes']}
    def read(a):
        info=model['accessors'][a]
        view=model['bufferViews'][info['bufferView']]
        dtype=np.dtype(kind[info['componentType']])
        n=extent[info['type']]
        assert view['buffer']==0 and not info.get('sparse')
        d=dtype.itemsize
        return np.ndarray((info['count'],n),dtype=dtype,buffer=raw,offset=view.get('byteOffset',0)+info.get('byteOffset',0),
                          strides=(view.get('byteStride',d*n),d))
    results={}
    framing={}
    for part,event in (('body',783),('face',804)):
        prim,=meshes[f'S_actor_laevat_{part}_01_lod0']['primitives']
        asset=read(prim['attributes']['POSITION'])
        u=read(prim['attributes']['TEXCOORD_0']).astype(float)
        indices=read(prim['indices']).reshape(-1,3)
        if part=='face':
            u[:,1]=1-u[:,1]
            framing=world_face_framing(asset)
        vpath,ipath=(base/f'{name}-{event}.bin' for name in ('vertex','index'))
        actual=ref['geometry'][str(event)]; hashes=(digest(vpath),digest(ipath))
        assert hashes==(actual['vertexSha256'],actual['indexSha256'])
        v=np.fromfile(vpath,'<f4').reshape(-1,actual['vertexStride']//4)[:,4:6].astype(float)
        nind=np.fromfile(ipath,'<u2').reshape(-1,3)
        sourceModel=asset[indices]
        area=np.linalg.norm(np.cross(sourceModel[:,1]-sourceModel[:,0],sourceModel[:,2]-sourceModel[:,0]),axis=1)/2
        stats={}
        for radius in (1.e-6,1.e-5,1.25e-4):
            matched=pair(v[nind],u[indices],radius)
            reuse=native_only_vertex_reuse(v,nind,u,indices,matched,radius) if part=='body' else None
            unpaired=matched.pop('assetOnly')
            nativeOnly=matched.pop('nativeOnly')
            height=sourceModel[unpaired,:,1]
            stats[str(radius)]=dict(matched=matched['matched'],assetOnly=len(unpaired),nativeOnly=len(nativeOnly),
                       fixedPosedToDynamicUvAgreement=matched['matched']/len(nind),
                       restAreaFractionUnpaired=float(area[unpaired].sum()/area.sum()),
                       indexOnlyRepairEligibility=reuse,
                       restYUnpaired=np.percentile(height,(0,10,50,90,100)).tolist() if len(height) else None)
        results[part]=dict(use='UV correspondence only; does not qualify animated silhouettes',assetTriangles=len(indices),
                           nativeTriangles=len(nind),nativeFiles=hashes,event=event,thresholds=stats)
    report=dict(status='measured-asset-structure-and-framing',project=digest(project),level=digest(level),
                actor=digest(actor),dynamicAnimations=len(model['animations']),cameraFramingAtRest=framing,triangleUV=results)
    (run/'character-dynamic-rest-inputs-score.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print(json.dumps(report))

if __name__=='__main__':
    x=np.array([[[0.,0.],[1.,0.],[1.,1.]],[[0.,0.],[1.,0.],[1.,1.]]])
    assert pair(x,x[[1,0]][:,[0,2,1]]+1e-8,1e-6)['matched']==2
    assert pair(x,x[:1],1e-6)['nativeOnly']==[1]
    score()
