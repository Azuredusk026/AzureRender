"""Capture six world-space views of the persisted joint-scene actor."""
from hashlib import file_digest
import json
import math
from pathlib import Path
import runpy
import struct
import sys

import numpy as np
from PIL import Image, ImageDraw


run = Path(__file__).resolve().parent
grid = run.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
body = run.parent / '20261114-125923-body-lit-outline-depth-order-a29b63'
release = body / 'msaa-release'
camera_build = run / 'qa-camera-pose-release'
dynamic = body / 'joint-character-reopen-current'
out = run / 'character-six-view-inputs'
views = {
    'face-front': 0, 'face-three-quarter-left': 45, 'face-three-quarter-right': -45,
    'face-side-left': 90, 'face-side-right': -90, 'back-detail': 180,
}
helpers = runpy.run_path(str(grid / 'iris-production-frozen-recovery.py'))
read = helpers['read']


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def camera_inputs(scene, actor):
    hero = next(node for node in scene['nodes'] if node['id'] == 'hero')
    transform = hero['components']['azure.transform']['data']
    assert hero['parentId'] == '' and transform['scale'] == [1, 1, 1]
    pitch, hero_yaw, roll = transform['rotation']
    assert pitch == roll == 0

    with actor.open('rb') as stream:
        magic, version, _, length, chunk = struct.unpack('<5I', stream.read(20))
        assert (magic, version, chunk) == (0x46546C67, 2, 0x4E4F534A)
        gltf = json.loads(stream.read(length))
    meshes = {mesh['name']: mesh for mesh in gltf['meshes']}
    face = meshes['S_actor_laevat_face_01_lod0']['primitives'][0]
    positions = gltf['accessors'][face['attributes']['POSITION']]
    low, high = np.array(positions['min']), np.array(positions['max'])
    assert low[1] > 1.4 and low[2] < 0 < high[2]
    face_center = (low + high) / 2
    assert abs(face_center[0]) < 1e-5 and face_center[2] > 0

    turn = math.radians(hero_yaw)
    base = np.array(transform['translation'])
    cameras = {}
    for name, relative in views.items():
        back = name == 'back-detail'
        target = base + ([0, 1.02, 0] if back else
                         [math.sin(turn) * face_center[2], face_center[1], math.cos(turn) * face_center[2]])
        yaw = (hero_yaw + relative + 180) % 360 - 180
        angle = math.radians(yaw)
        forward = np.array([-math.sin(angle), 0, -math.cos(angle)])
        position = target - (1.47 if back else .62) * forward
        cameras[name] = dict(angle=relative, t=position.tolist(), rot=[0, yaw, 0],
                            target=target.tolist(), forward=forward.tolist(), fov=47 if back else 40)
    return dict(faceBounds=[low.tolist(), high.tolist()], heroTransform=transform, views=cameras)


def source_inputs():
    command = read(dynamic / 'command.json')
    project = Path(command[2])
    descriptor = read(project)
    mounts = {item['name']: item['path'] for item in descriptor['mounts']}
    stage, relative = descriptor['startupScene'].split(':/', 1)
    level = project.parent / mounts[stage] / relative
    scene = read(level)
    camera = next(node for node in scene['nodes'] if node['id'] == 'camera')
    assert camera['parentId'] == ''
    enabled = [node['id'] for node in scene['nodes']
               if node.get('components', {}).get('azure.camera', {}).get('data', {}).get('enabled', False)]
    assert enabled == ['camera']
    resource = next(item for item in scene['resources'] if item['id'] == 'hero')
    mount, relative = resource['asset'].split(':/', 1)
    actor = project.parent / mounts[mount] / relative
    assert actor.name == 'hero-idle-loop-v2.glb'
    return command, project, level, scene, actor


def player_capture(tag, name, pose, common, inputs):
    path = out / f'{tag}-{name}'
    result = path / 'result.json'
    frame = path / 'frames/frame_000000.png'
    if result.is_file():
        evidence = read(result)
        assert digest(frame) == evidence['sha256'] and evidence['command'] == common
        assert evidence['camera'] == name and evidence['cameraInput'] == inputs
        assert digest(path / 'runtime.json') == evidence['runtimeReport']
        assert digest(path / 'frames/capture_manifest.json') == evidence['captureManifest']
        return evidence
    if path.exists():
        previous = len(list(out.glob(path.name + '-interrupted-*')))
        path.rename(out / (path.name + f'-interrupted-{previous + 1}'))
    path.mkdir()
    frame_folder = helpers['invoke'](tag, common, path)
    assert frame_folder == path / 'frames' and frame.is_file()
    manifest = read(frame_folder / 'capture_manifest.json')
    gpu = read(frame_folder / 'gpu_capabilities.json')
    runtime = read(path / 'runtime.json')
    assert len(runtime['animations']) == 11 and not runtime['scriptErrors'] and not runtime['presentationErrors']
    assert (manifest['qaCamera'], manifest['qaLight'], manifest['width'], manifest['height'],
            manifest['capturedFrames']) == ('scene', 'scene', 1280, 720, 1)
    assert (gpu['vendor_id'], gpu['device_id']) == ((0x10de, 0x28e0) if tag == 'nvidia' else (0x8086, 0xa788))
    position = np.array(manifest['qaCameraPosition'])
    forward = np.array(manifest['qaCameraTarget']) - position
    assert abs(position - pose['t']).max() < 0.00008, (name, position, pose)
    assert abs(forward - pose['forward']).max() < 0.00012, (name, forward, pose)
    assert abs(manifest['cameraLens']['verticalFovRadians'] - math.radians(pose['fov'])) < 1e-5
    assert manifest['cameraLens']['offsetNdc'] == [0, 0]
    with Image.open(frame) as image:
        assert image.size == (1280, 720)
        values = np.asarray(image.convert('RGB'))
    assert np.ptp(values) > 0
    evidence = dict(camera=name, cameraInput=inputs, sha256=digest(frame), driver=gpu['driver_version'],
                    device=gpu['device_id'], meanRgb=values.mean(axis=(0, 1)).tolist(), extent=[1280, 720],
                    command=common, captureManifest=digest(frame_folder / 'capture_manifest.json'),
                    runtimeReport=digest(path / 'runtime.json'), animationInstances=len(runtime['animations']),
                    appliedCameraPosition=position.tolist(), appliedCameraForward=forward.tolist())
    write(result, evidence)
    return evidence


def make_contact_sheet(devices):
    width, height, spacing = 384, 216, 12
    columns, header, caption = tuple(devices), 32, 20
    board = Image.new('RGB', (2*width + 3*spacing, header + len(views)*(height+caption+spacing)), (18, 20, 24))
    text = ImageDraw.Draw(board)
    for col, device in enumerate(columns):
        x = spacing + col*(width + spacing)
        text.text((x, 11), device.upper(), (239, 242, 248))
        for row, capture in enumerate(devices[device]):
            name = capture['camera']
            y = header + row*(height + caption + spacing)
            text.text((x, y), name, (210, 216, 230))
            path = out / f'{device}-{name}/frames/frame_000000.png'
            assert digest(path) == capture['sha256']
            with Image.open(path) as image:
                board.paste(image.convert('RGB').resize((width, height), Image.Resampling.LANCZOS), (x, y+caption))
    path = out / 'six-view-comparison.png'
    board.save(path)
    return dict(file=path.name, sha256=digest(path), width=board.width, height=board.height)


def run_suite(batches=4):
    assert 1 <= batches <= 12
    lease = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state'] == 'held' and Path(lease['output']) == run
    sys.path.insert(0, str(run.parents[2] / 'tools'))
    from artifact_budget import check
    budget = check(run.parents[1], run=run, planned=22000000)
    assert budget['allowed'], budget
    command, project, level, scene, actor = source_inputs()
    inputs = camera_inputs(scene, actor)
    asset_hash, project_hash, level_hash = map(digest, (actor, project, level))
    dynamic_evidence = read(dynamic / 'results.json')
    assert dynamic_evidence['projectSha256'] == project_hash and dynamic_evidence['animationInstances'] == 11
    receipt = read(camera_build / 'link-receipt.json')
    assert digest(release / 'AzurePlayer.exe') == receipt['oldPlayer'] == dynamic_evidence['playerSha256']
    player = camera_build / 'AzurePlayer.exe'
    player_hash = digest(player)
    assert player_hash == receipt['newPlayer'] and receipt['commandLineTests'] == 'passed'
    out.mkdir(exist_ok=True)
    write(out / 'camera-inputs.json', inputs)
    devices = {tag: [] for tag in ('nvidia', 'intel')}
    new_captures = 0
    for name, pose in inputs['views'].items():
        target = (np.array(pose['t']) + pose['forward']).tolist()
        camera_input = dict(project=project_hash, level=level_hash, runtimeTarget=target, **pose)
        for tag, results in devices.items():
            output = out / f'{tag}-{name}'
            fresh = not (output / 'result.json').is_file()
            if fresh and new_captures == batches:
                continue
            args = command.copy()
            args[0] = str(player)
            for flag, value in (('--width', '1280'), ('--height', '720'),
                                ('--capture-frames', '1'), ('--capture-dir', output / 'frames'),
                                ('--runtime-report', output / 'runtime.json')):
                args[args.index(flag) + 1] = str(value)
            assert Path(args[args.index('--project') + 1]) == project
            assert Path(args[args.index('--resource-root') + 1]) == release
            args.extend(('--qa-camera-pose', *(format(q, '.9g') for q in (*pose['t'], *target, pose['fov']))))
            results.append(player_capture(tag, name, pose, args, camera_input))
            new_captures += fresh
            print(tag, name, results[-1]['sha256'], flush=True)
    progress = dict(completed={tag: [row['camera'] for row in rows] for tag, rows in devices.items()},
                    newCaptures=new_captures, required=len(views)*len(devices))
    write(out / 'checkpoint.json', progress)
    if any(len(results) != len(views) for results in devices.values()):
        print(json.dumps(progress), flush=True)
        return
    for results in devices.values():
        assert len({result['sha256'] for result in results}) == len(views)
    assert tuple(map(digest, (actor, project, level, player))) == (asset_hash, project_hash, level_hash, player_hash)
    result = dict(status='qualified-six-camera-inputs', overallVisualAcceptance='regional-comparison-pending',
                  asset=asset_hash, project=project_hash, startupLevel=level_hash, player=player_hash,
                  cameras=digest(out / 'camera-inputs.json'), devices=devices, dynamicPoseEvidence=dynamic_evidence,
                  contactSheet=make_contact_sheet(devices))
    write(out / 'results.json', result)


if __name__ == '__main__':
    if sys.argv[1:] == ['--preflight']:
        *_, scene, actor = source_inputs()
        print(json.dumps(camera_inputs(scene, actor)))
    else:
        assert len(sys.argv) <= 2
        run_suite(*(int(s) for s in sys.argv[1:]))
