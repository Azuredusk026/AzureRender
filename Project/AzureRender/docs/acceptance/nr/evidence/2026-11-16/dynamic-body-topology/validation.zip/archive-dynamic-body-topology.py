from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

run=Path(__file__).resolve().parent
native=run.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
out=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-16/dynamic-body-topology'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
framing=read(run/'character-dynamic-rest-inputs-score.json')
qualified=read(run/'animated-body-topology-candidate.json')
rig=read(run/'body-native-rest-rig-correspondence.json')
raw=read(native/'native-body-outline-input-retest/results.json')
assert raw['status']=='qualified'
assert framing['status']=='measured-asset-structure-and-framing'
assert framing['actor']==qualified['originalGlb']
assert (qualified['identicalOriginalTriangles'],qualified['removedTriangles'],qualified['replacedTriangles'])==(5610,169,69)
assert qualified['originalAttributeBytesUnchanged'] and qualified['untouchedAnimationCount']==10
assert qualified['maxTriangleUvComponentError']<=1e-6 and qualified['untouchedSkinCount']==1
assert qualified['appendedForMissingUv']==31
assert qualified['windingEvidence']['reversed']==5610
assert framing['triangleUV']['face']['thresholds']['1e-06']['matched']==2906
assert rig['matchedTriangles']==5610 and rig['positionWithinTenMicrometers']==3247
files={name:run/name for name in
       ('body-native-rest-rig-correspondence.py','build-animated-body-topology-candidate.py',
        'character-dynamic-rest-inputs-score.py','character-six-view-inputs.py',
        'character-dynamic-rest-inputs-score.json','body-native-rest-rig-correspondence.json',
        'animated-body-topology-candidate.json',Path(__file__).name)}
files['source/native-outline-inputs.json']=native/'native-body-outline-input-retest/results.json'
files['source/native-face-and-body-geometry.json']=native/'native-face-skin-stages/results.json'

out.mkdir(parents=True,exist_ok=True)
archive=out/'validation.zip'
with ZipFile(archive,'w') as z:
    for name,path in sorted(files.items()):
        info=ZipInfo(name,(2026,11,16,0,0,0));info.compress_type=ZIP_DEFLATED
        z.writestr(info,path.read_bytes())
with ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(sha256(z.read(name)).hexdigest()==sha(path) for name,path in files.items())
(out/'results.json').write_text(json.dumps(dict(status='topology verified; visual acceptance pending',
   productionAssetAccepted=False,dynamicAsset=framing,nativeRestRig=rig,candidate=qualified,
   archive=dict(sha256=sha(archive),members={k:sha(v) for k,v in files.items()})),
   indent=2)+'\n',encoding='utf8')
print(sha(archive))
