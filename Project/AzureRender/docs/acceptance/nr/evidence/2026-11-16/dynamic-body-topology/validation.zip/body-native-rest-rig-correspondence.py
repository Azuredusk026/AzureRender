"""Qualify an exact native rest-vertex and rig mapping before any dynamic topology changes."""
from collections import Counter
from pathlib import Path
from itertools import permutations,product
import json
import runpy
import numpy as np

root=Path(__file__).resolve().parent
core=runpy.run_path(str(root/'character-dynamic-rest-inputs-score.py'),run_name='body_dynamic_rest')
assets=core['api']['grid']/'native-body-outline-input-retest'
read=lambda p:json.loads(p.read_bytes())
sha=core['digest']
slots=read(assets/'results.json')
assert slots['status']=='qualified'
model,raw=core['load_program']()

def data(a):
    entry=model['accessors'][a]; view=model['bufferViews'][entry['bufferView']]
    dtype=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[entry['componentType']])
    dims={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[entry['type']]; s=dtype.itemsize
    values=np.ndarray((entry['count'],dims),dtype=dtype,buffer=raw,
        offset=view.get('byteOffset',0)+entry.get('byteOffset',0),strides=(view.get('byteStride',s*dims),s))
    if entry.get('normalized'):
        assert dtype.kind=='u'
        return values.astype(float)/np.iinfo(dtype).max
    return values

bs=core['base']; defs=core['ref']['geometry']
ip=bs/'index-783.bin'; iq=bs/'index-1018.bin'
assert sha(ip)==defs['783']['indexSha256'] and sha(iq)==defs['1018']['indexSha256']
native_tri=np.fromfile(ip,'<u2').reshape(-1,3)
outline_tri=np.fromfile(iq,'<u2').reshape(-1,3)
assert np.array_equal(native_tri,outline_tri) or np.array_equal(np.sort(native_tri,axis=1),np.sort(outline_tri,axis=1))
n=int(native_tri.max())+1
buf={}
def vertex(slot,offset,type_,columns):
    entry,=[row for row in slots['bindings'] if row['index']==slot]
    p=assets/entry['path']
    if p not in buf:
        assert sha(p)==entry['sha256'];buf[p]=p.read_bytes()
    d=np.dtype(type_)
    return np.ndarray((n,columns),dtype=d,buffer=buf[p],offset=offset,
                      strides=(entry['stride'],d.itemsize))

posa=vertex(0,0,'<f4',3)
tuva=vertex(1,0,'<f4',2)
wp=vertex(2,0,'<u2',4).astype(float)/65535.
jp=vertex(2,8,'u1',4)
stream=bs/'vertex-783.bin'
assert sha(stream)==defs['783']['vertexSha256']
sample=np.fromfile(stream,'<f4').reshape(-1,defs['783']['vertexStride']//4)
assert np.array_equal(tuva,sample[:,4:6])
body,=[a for a in model['meshes'] if a['name']=='S_actor_laevat_body_01_lod0']
p,=body['primitives']; positions,uv,w,j=[data(p['attributes'][a]) for a in ('POSITION','TEXCOORD_0','WEIGHTS_0','JOINTS_0')]
idx=data(p['indices']).reshape(-1,3)
answer=core['pair'](tuva[native_tri].astype(float),uv[idx].astype(float),1e-6)
matches=set()
uv_orders=list(permutations(range(3)))
for nt,dt in answer['mapping'].items():
    a,b=native_tri[nt],idx[dt]
    order=min(uv_orders,key=lambda q:np.max(abs(tuva[a]-uv[b[list(q)]])))
    for i,k in zip(a,b[list(order)]):
        matches.add((int(i),int(k)))
ii,ki=np.asarray(sorted(matches)).T
nraw=posa[ii]; base=positions[ki]
space=[]
for order in permutations(range(3)):
    for signs in product((-1,1),repeat=3):
        xyz=nraw[:,order]*signs
        t=np.median(base-xyz,axis=0)
        delta=np.linalg.norm(base-(xyz+t),axis=1)
        space.append((float(np.median(delta)),order,signs,t,delta))
_,order,signs,translation,errors=min(space,key=lambda row:row[0])
witness=np.flatnonzero(errors<1e-5)
votes=Counter()
weight_quality=[]
for s in witness:
    a,b=ii[s],ki[s]
    src=np.argsort(wp[a]); dst=np.argsort(w[b])
    weight_quality.append(float(np.max(abs(wp[a,src]-w[b,dst]))))
    for k,l in zip(src,dst):
        value=wp[a,k]
        if value>1e-4 and abs(value-w[b,l])<3e-5 and np.sum(abs(wp[a]-value)<3e-5)==1:
            votes[int(jp[a,k]),int(j[b,l])]+=1
active_native=np.unique(jp[np.unique(native_tri[answer['nativeOnly']])][wp[np.unique(native_tri[answer['nativeOnly']])]>0])
candidates={int(k):dict((str(l),v) for (i,l),v in votes.most_common() if i==k) for k in active_native}
report=dict(matchVertices=len(matches), positionAxes=order, positionSigns=signs,
            translation=translation.tolist(), positionError=np.percentile(errors,[0,10,50,90,100]).tolist(),
            positionWithinTenMicrometers=len(witness),
            weightMaxDifference=np.percentile(weight_quality,[0,50,90,100]).tolist() if weight_quality else None,
            nativeBoneMappingVotes=candidates, nativePositionAndWeightBinding=assets.name,
            exactUvAgreement=len(tuva),matchedTriangles=answer['matched'])
def normalize(a):
    return a/np.linalg.norm(a,axis=1,keepdims=True)

def native_tangent_frame(encoding):
    assert np.all(encoding&0x40000000)
    x,y,a=[((encoding>>shift)&1023).astype(np.int16) for shift in (0,10,20)]
    x,y,a=[np.where(c>=512,c-1024,c)/511. for c in (x,y,a)]
    z=1-abs(x)-abs(y)
    normal=normalize(np.column_stack((np.where(z<0,np.where(x>=0,1,-1)*(1-abs(y)),x),
                                     np.where(z<0,np.where(y>=0,1,-1)*(1-abs(x)),y),z)))
    v=normal[:,[1,2,0]]-normal[:,[2,0,1]]
    v=normalize(v-(v*normal).sum(axis=1,keepdims=True)*normal)
    q=normalize(np.column_stack((1-abs(a),a)))
    tangent=v*q[:,0,None]+np.cross(normal,v)*q[:,1,None]
    orientation=((encoding>>31)*2).astype(float)-1
    return normal,tangent,orientation

packed=vertex(0,12,'<u4',1)[:,0]
report['verticesWithPackedFrame']=int((packed&0x40000000!=0).sum())
if report['verticesWithPackedFrame']==len(packed):
    native_normal,native_tangent,native_orientation=native_tangent_frame(packed)
    modern_normal,modern_tangent=[data(p['attributes'][name]) for name in ('NORMAL','TANGENT')]
    def angles(stage,output):
        cos=(normalize(stage[ii][:,order]*signs)*normalize(output[ki][:,:3])).sum(axis=1)
        return np.percentile(np.rad2deg(np.arccos(np.clip(cos,-1,1))),[0,10,50,90,99,100]).tolist()
    report['tangentFrame']=dict(normalAnglesDegrees=angles(native_normal,modern_normal),
                    tangentAnglesDegrees=angles(native_tangent,modern_tangent),
                    mirroredHandMatches=int((native_orientation[ii]*-1==modern_tangent[ki][:,3]).sum()))
(root/'body-native-rest-rig-correspondence.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(report))
