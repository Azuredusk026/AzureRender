"""Render a matched body-geometry comparison without modifying the persisted joint scene."""
from contextlib import contextmanager
import json
import math
import os
from pathlib import Path
import runpy
from shutil import copyfile
import sys

import cv2
import numpy as np
from PIL import Image

source=Path(__file__).resolve().parent
prep=runpy.run_path(str(source/'plan-animated-body-topology-fixture.py'),run_name='fixture_inputs')
six=prep['six']
read=prep['read']
sha=prep['sha']
write=six['write']
owner='01a1d0a9-829a-7c11-a7a8-017e743887d9'

def inputs(angle=28,native_weights=False):
    name='animated-body-native-weights-fixture.json' if native_weights else 'animated-body-topology-fixture.json'
    d=read(source/name)
    original=Path(d['sourceRoot'])
    level=d['level']
    hero,=[x for x in level['nodes'] if x['id']=='hero']
    root=hero['components']['azure.transform']['data']
    center=np.array(root['translation'])+[0.,1.23,0.]
    theta=math.radians(root['rotation'][1]+angle)
    facing=np.array([math.sin(theta),0.,math.cos(theta)])
    pos=center+facing*.94
    fov=49.
    shift=np.array(root['translation'])+[0.,1.23,0.]-pos
    assert np.allclose(shift,-facing*.94)
    camera=dict(position=pos.tolist(),target=center.tolist(),facing=(-facing).tolist(),fov=fov,
                args=['--qa-camera-pose',*(format(n,'.9g') for n in (*pos,*center,fov))])
    actor_hash=d['sources']['originalAsset']
    assert sha(original/d['assetPath'])==actor_hash
    return d,original,camera

def copy_inputs(target,d,original):
    root=target/'project'
    for relative,record in d['inputs'].items():
        origin=original/relative
        dst=root/relative
        assert sha(origin)==record['sha256']
        dst.parent.mkdir(exist_ok=True,parents=True)
        if not dst.is_file():
            copyfile(origin,dst)
        assert sha(dst)==record['sha256']
    stage,relative=d['project']['startupScene'].split(':/',1)
    mount,=[x['path'] for x in d['project']['mounts'] if x['name']==stage]
    level=root/mount/relative
    level.parent.mkdir(exist_ok=True)
    project=root/'body-topology.azureproject'
    for f,contents in ((level,d['level']),(project,d['project'])):
        if f.is_file():
            assert read(f)==contents
        else:
            write(f,contents)
    return root,project,level

@contextmanager
def geometry_control(root,d,scratch,original,mode):
    asset=root/d['assetPath']
    original_hash=d['sources']['originalAsset']
    assert sha(asset)==original_hash
    use=asset
    if mode=='candidate':
        candidate=scratch/'candidate-payload.glb'
        candidate_hash=d['sources']['candidateAsset']
        if not candidate.exists():
            # Prefer the proven serializer and independently verify both the written and frozen input digests.
            build=runpy.run_path(str(source/'build-animated-body-topology-candidate.py'),run_name='candidate_mesh')
            exact=d.get('assetVariant')=='native-body-rig-uint16-source-weights'
            payload,details=build['serialize'](exact,exact)
            assert details['serializedSha256']==candidate_hash
            pending=candidate.with_suffix('.tmp')
            pending.write_bytes(payload)
            os.replace(pending,candidate)
        assert sha(candidate)==candidate_hash
        prior=asset.with_suffix('.control')
        assert not prior.exists()
        os.replace(asset,prior)
        try:
            copyfile(candidate,asset)
            assert sha(asset)==candidate_hash
            yield candidate_hash
        finally:
            os.replace(prior,asset)
            assert sha(asset)==original_hash
    else:
        assert mode=='original'
        yield original_hash
    assert sha(original/d['assetPath'])==original_hash

def capture(scratch,project,device,mode,datum,cam,player,asset):
    out=scratch/f'{mode}-{device}'
    evidence=out/'result.json'
    images=('frame_000000.png','frame_000001.png')
    paths=[out/'frames'/name for name in images]
    command=[str(player),'--project',str(project),'--resource-root',str(six['release']),
             '--capture-dir',str(out/'frames'),'--runtime-report',str(out/'runtime.json'),
             '--width','1280','--height','720','--capture-frames','2','--capture-fps','24','--fixed-frame-step',
             '--qa-camera','scene','--qa-light','scene','--qa-animation',*cam['args']]
    if evidence.is_file():
        saved=read(evidence)
        assert saved['command']==command and saved['asset']==asset
        assert all(sha(path)==saved['frames'][path.name] for path in paths)
        return saved
    if out.exists():
        out.rename(out.with_name(out.name+f'-interrupted-{len(list(scratch.glob(out.name+"-interrupted-*")))+1}'))
    out.mkdir()
    frame_dir=six['helpers']['invoke'](device,command,out)
    assert frame_dir==out/'frames'
    manifest=read(frame_dir/'capture_manifest.json')
    actual=read(frame_dir/'gpu_capabilities.json')
    runtime=read(out/'runtime.json')
    assert not runtime['scriptErrors'] and not runtime['presentationErrors']
    assert (actual['vendor_id'],actual['device_id'])==((0x10de,0x28e0) if device=='nvidia' else (0x8086,0xa788))
    assert (manifest['width'],manifest['height'],manifest['capturedFrames'],manifest['fps'])==(1280,720,2,24)
    assert np.max(abs(np.asarray(manifest['qaCameraPosition'])-cam['position']))<8e-5
    assert manifest['cameraLens']['offsetNdc']==[0,0]
    orientation=np.asarray(manifest['qaCameraTarget'])-manifest['qaCameraPosition']
    orientation/=np.linalg.norm(orientation)
    assert np.max(abs(orientation-cam['facing']))<1.2e-4
    assert abs(manifest['cameraLens']['verticalFovRadians']-math.radians(cam['fov']))<1e-5
    state,=[s for s in runtime['animations'] if s['node']=='hero']
    assert len(runtime['animations'])==1 and state['clip']==datum.get('fixtureClip',9) and state['time']>0
    r=dict(device=device,mode=mode,driver=actual['driver_version'],asset=asset,
           player=sha(player),frames={p.name:sha(p) for p in paths},command=command,
           runtime=sha(out/'runtime.json'),animation=state,animationFrames=runtime['animationFrames'],
           fixedSteps=runtime['fixedSteps'],captureManifest=sha(frame_dir/'capture_manifest.json'))
    write(evidence,r)
    return r

def compare(scratch,device,original,candidate):
    for key in ('driver','player','animation','animationFrames','fixedSteps'):
        assert original[key]==candidate[key],(key,original[key],candidate[key])
    scores={}
    for filename in original['frames']:
        arrays=[]
        for a in (original,candidate):
            f=scratch/(a['mode']+'-'+device)/'frames'/filename
            assert sha(f)==a['frames'][filename]
            with Image.open(f) as i:
                arrays.append(np.array(i.convert('RGB'),dtype=np.int16))
        x,y=arrays
        delta=np.max(np.abs(x-y),axis=2)
        # The fixture's stable background is sampled at its upper and lower borders.
        bg=x[0,0]
        assert all(np.all(i[0,0]==bg) and np.all(i[-1,-1]==bg) for i in arrays)
        base_mask=np.max(np.abs(x-bg),axis=2)>2
        alt_mask=np.max(np.abs(y-bg),axis=2)>2
        assert 0<base_mask.mean()<.8 and 0<alt_mask.mean()<.8
        def bounds(mask):
            xy=np.argwhere(mask)
            return (*xy.min(0).tolist(),*xy.max(0).tolist())
        def groups(mask):
            n, labels, stats, centers=cv2.connectedComponentsWithStats(mask.astype(np.uint8))
            return sorted(stats[1:,4].tolist(),reverse=True)
        over=delta>1
        scores[filename]=dict(maxRgbDelta=int(delta.max()),changedOverOne=int(over.sum()),
                              changeBounds=bounds(over) if np.any(over) else None,
                              formerVisible=int(base_mask.sum()),candidateVisible=int(alt_mask.sum()),
                              appearingPixels=int((alt_mask&~base_mask).sum()),disappearingPixels=int((base_mask&~alt_mask).sum()),
                              edgeChangeGroups=groups(alt_mask^base_mask)[:30])
    return scores

def run(target,native_weights=False):
    state=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert state['owner']==owner and state['state']=='held' and Path(state['output'])==target
    datum,origin,camera=inputs(native_weights=native_weights)
    scratch=target/('paired-native-weight-capture' if native_weights else 'paired-torso-capture')
    scratch.mkdir(exist_ok=True)
    build=six['camera_build']
    if native_weights:
        build=build.with_name('qa-camera-pose-native-weights-release')
        green=read(source/'native-weight-import-test-green/receipt.json')
        assert green['mode']=='green' and green['testExit']==0
    receipt=read(build/'link-receipt.json')
    player=build/'AzurePlayer.exe'
    if native_weights:
        assert receipt['inputs']['src/assets/GltfLoader.cpp']==green['input']['src/assets/GltfLoader.cpp']
    assert sha(player)==receipt['newPlayer'] and receipt['commandLineTests']=='passed'
    root,project,level=copy_inputs(target,datum,origin)
    records={}
    for mode in ('original','candidate'):
        with geometry_control(root,datum,scratch,origin,mode) as asset:
            records[mode]={tag:capture(scratch,project,tag,mode,datum,camera,player,asset) for tag in ('nvidia','intel')}
    for rel,record in datum['inputs'].items():
        assert sha(root/rel)==record['sha256'] and sha(origin/rel)==record['sha256'],rel
    write(scratch/'results.json',dict(status='measured-isolated-dynamic-body-geometry',nativeDynamicReferenceAccepted=False,
          assetVariant=datum.get('assetVariant'),project=sha(project),level=sha(level),camera=camera,records=records,
          comparisons={tag:compare(scratch,tag,records['original'][tag],records['candidate'][tag]) for tag in ('nvidia','intel')}))

if __name__=='__main__':
    exact='--native-weights' in sys.argv
    args=[q for q in sys.argv[1:] if q!='--native-weights']
    if args==['preflight']:
        d,original,camera=inputs(native_weights=exact)
        print(json.dumps(dict(bytes=d['bytes'],camera=camera,source=sha(original/d['assetPath']))))
    else:
        assert len(args)==2 and args[0]=='run'
        run(Path(args[1]).resolve(),native_weights=exact)
