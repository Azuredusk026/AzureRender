"""Prepare a geometry-only animation fixture from exact original and candidate data."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import runpy
import struct
import sys

root=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_bytes())
sha=lambda b:sha256(b).hexdigest()


def unpack_glb(raw):
    magic,version,sz,n,typ=struct.unpack_from('<5I',raw)
    assert (magic,version,sz,typ)==(0x46546c67,2,len(raw),0x4e4f534a)
    nb,bt=struct.unpack_from('<2I',raw,20+n)
    assert bt==0x004e4942 and 28+n+nb==sz
    return json.loads(raw[20:20+n]),raw[28+n:]


def glb(doc,body):
    head=json.dumps(doc,ensure_ascii=False,separators=(',',':')).encode('utf8')
    head+=b' '*(-len(head)%4)
    body=bytes(body)+b'\0'*(-len(body)%4)
    return struct.pack('<5I',0x46546c67,2,28+len(head)+len(body),len(head),0x4e4f534a)+head+struct.pack('<2I',len(body),0x004e4942)+body


def pruned(raw):
    old,body=unpack_glb(raw)
    assert len(old['skins'])==1 and len(old['animations'])==10
    material=dict(name='Geometry coverage',pbrMetallicRoughness=dict(baseColorFactor=[.72,.39,.18,1]),
        extras=dict(azureRenderMaterial=dict(schemaVersion=2,**{'class':'generic'},features=['unlit-surface'],
                                            surface=dict(schemaVersion=1,lighting='unlit'))))
    g={k:deepcopy(old[k]) for k in ('asset','scene','scenes','nodes','skins')}
    g['meshes']=[deepcopy(old['meshes'][0])]
    prim,=g['meshes'][0]['primitives']
    assert g['meshes'][0]['name']=='S_actor_laevat_body_01_lod0' and not prim.get('targets')
    prim['material']=0;g['materials']=[material]
    ids={};vw={};blobs={};view_cache={};accessor_cache={}
    g['bufferViews']=[];g['accessors']=[];packed=bytearray()
    def map_a(i):
        if i in ids:return ids[i]
        a=deepcopy(old['accessors'][i]);assert not a.get('sparse')
        v=a['bufferView']
        if v not in vw:
            view=deepcopy(old['bufferViews'][v])
            assert view['buffer']==0 and not view.get('extensions')
            begin=view.get('byteOffset',0)
            end=begin+view['byteLength']
            block=body[begin:end]
            assert len(block)==view['byteLength']
            blobs[v]=sha(block)
            view.pop('byteOffset',None)
            sig=(json.dumps(view,sort_keys=True,separators=(',',':')),block)
            if sig not in view_cache:
                packed.extend(b'\0'*(-len(packed)%4))
                view['byteOffset']=len(packed);packed.extend(block)
                view_cache[sig]=len(g['bufferViews'])
                g['bufferViews'].append(view)
            vw[v]=view_cache[sig]
        a['bufferView']=vw[v]
        sig=json.dumps(a,sort_keys=True,separators=(',',':'))
        if sig not in accessor_cache:
            accessor_cache[sig]=len(g['accessors'])
            g['accessors'].append(a)
        ids[i]=accessor_cache[sig]
        return ids[i]
    body_nodes=[i for i,n in enumerate(g['nodes']) if n.get('mesh')==0]
    assert len(body_nodes)==1 and g['nodes'][body_nodes[0]]['skin']==0
    for i,n in enumerate(g['nodes']):
        if i not in body_nodes:
            for k in ('mesh','skin','weights'):n.pop(k,None)
    attrs=deepcopy(prim['attributes']);indices=prim['indices']
    prim['attributes']={key:map_a(idx) for key,idx in attrs.items()}
    prim['indices']=map_a(indices)
    for s in g['skins']:s['inverseBindMatrices']=map_a(s['inverseBindMatrices'])
    source_clip=old['animations'][9];clip=deepcopy(source_clip)
    assert clip['name']=='a_actor_laevat_idle_loop_closed'
    assert {v['target']['path'] for v in clip['channels']}=={'translation','rotation','scale'}
    for s in clip['samplers']:
        for k in ('input','output'):s[k]=map_a(s[k])
    g['animations']=[clip]
    g['buffers']=[dict(byteLength=len(packed))]
    p=glb(g,packed)
    after,bits=unpack_glb(p)
    assert after==g
    for old_v,new_v in vw.items():
        a=after['bufferViews'][new_v];start=a['byteOffset']
        assert sha(bits[start:start+a['byteLength']])==blobs[old_v]
    for before,after_a in ids.items():
        lhs=deepcopy(old['accessors'][before]);lhs['bufferView']=vw[lhs['bufferView']]
        assert g['accessors'][after_a]==lhs
    identity=lambda names:{str(i):blobs[old['accessors'][a]['bufferView']] for i,a in names.items()}
    source_clip_access={f'{i}.{k}':s[k] for i,s in enumerate(source_clip['samplers']) for k in ('input','output')}
    return p,dict(source=sha(raw),slim=sha(p),bytes=len(p),skin=old['skins'],
        nodeTransforms=[{k:v for k,v in n.items() if k not in ('mesh','skin','weights')} for n in old['nodes']],
        clipChannels=source_clip['channels'],clipPayload=identity(source_clip_access),
        attributes=identity({**attrs,'INDICES':indices}),triangles=old['accessors'][indices]['count']//3,
        exactWeightOptIn=bool(prim.get('extras',{}).get('azurePreserveSkinWeightCodes')))


def prepare():
    fixture=read(root/'animated-body-native-weights-fixture.json')
    source=Path(fixture['sourceRoot'])/fixture['assetPath']
    base=source.read_bytes(); assert sha(base)==fixture['sources']['originalAsset']
    build=runpy.run_path(str(root/'build-animated-body-topology-candidate.py'),run_name='native_geometry')
    cand,raw=build['serialize'](True,True)
    assert raw['serializedSha256']==sha(cand)==fixture['sources']['candidateAsset']
    a,x=pruned(base); b,y=pruned(cand)
    frozen=('skin','nodeTransforms','clipChannels','clipPayload')
    assert all(x[k]==y[k] for k in frozen)
    assert (x['triangles'],y['triangles'])==(5779,5679) and not x['exactWeightOptIn'] and y['exactWeightOptIn']
    return (a,b),dict(status='verified-reduced-geometry-inputs',productionAppearanceScope=False,sourceClip=9,fixtureClip=0,
        variants=[{k:v for k,v in q.items() if k not in frozen} for q in (x,y)],
        frozenEvidence={k:sha(json.dumps(x[k],sort_keys=True,separators=(',',':')).encode('utf8')) for k in frozen})


def capture(device):
    lease=read('D:/Projects/FYP-coordination/resources/current.json')
    assert lease['state']=='held' and lease['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9' and Path(lease['output'])==root
    run=runpy.run_path(str(root/'run-animated-body-topology-fixture.py'),run_name='paired_geometry')
    put,filehash=run['write'],run['sha']
    payloads,report=prepare()
    descriptor,origin,cam=run['inputs'](native_weights=True)
    l=deepcopy(descriptor['level'])
    l['nodes']=[n for n in l['nodes'] if n['id'] in ('camera','hero')]
    actor,=[n for n in l['nodes'] if n['id']=='hero']
    actor['components'].pop('azure.object-shadow')
    assert len(actor.pop('materialSlots'))==13
    l['resources']=[x for x in l['resources'] if x['id']=='hero']
    l['lights']=[];l['sceneImports']=[]
    l['renderSettings'].pop('nprLighting')
    l['renderSettings']['sceneLighting']=False
    version=deepcopy(descriptor['project'])
    version['id']='body-geometry-control';version['name']='body-geometry-control'
    version['mounts']=[v for v in version['mounts'] if v['name']!='candidate']
    mounts={v['name']:v['path'] for v in version['mounts']}
    assert set(mounts)=={'assets','character','stage'}
    anim=Path(mounts['assets'])/'locomotion-idle-loop-v2.json'
    assert filehash(origin/anim)==descriptor['inputs'][anim.as_posix()]['sha256']
    state=read(origin/anim)
    idle,=[copy for copy in state['states'] if copy['name']==state['initial']]
    assert idle['clip']==report['sourceClip'] and idle['loop'] and not state['transitions']
    idle['clip']=report['fixtureClip'];state['states']=[idle]
    scratch=root/'compact-dynamic-geometry-probe'
    scratch.mkdir(exist_ok=True)
    build=run['six']['camera_build'].with_name('qa-camera-pose-native-weights-release')
    player=build/'AzurePlayer.exe'
    assert filehash(player)==read(build/'link-receipt.json')['newPlayer']
    records={}
    for mode,program,item in zip(('original','candidate'),payloads,report['variants']):
        target=scratch/f'project-{mode}'
        for v in mounts.values():(target/v).mkdir(parents=True,exist_ok=True)
        packed=target/descriptor['assetPath']
        if not packed.exists():packed.write_bytes(program)
        assert filehash(packed)==item['slim']
        project=target/'body-topology.azureproject'
        level=target/mounts['stage']/'body-topology.azurelevel'
        for path,value in ((project,version),(level,l),(target/anim,state)):
            if not path.is_file():put(path,value)
            assert read(path)==value
        records[mode]=run['capture'](scratch,project,device,mode,report,cam,player,item['slim'])
    scores=run['compare'](scratch,device,records['original'],records['candidate'])
    report.update(status='rendered-control',scope='dynamic geometry only',strictJointSceneAcceptance='pending',
                  camera=cam,device=device,records=records,scores=scores)
    put(scratch/f'{device}-qualification.json',report)
    print(device,json.dumps(scores))


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        frames,record=prepare()
        print(json.dumps(record))
    else:
        assert sys.argv[1] in ('nvidia','intel')
        capture(sys.argv[1])
