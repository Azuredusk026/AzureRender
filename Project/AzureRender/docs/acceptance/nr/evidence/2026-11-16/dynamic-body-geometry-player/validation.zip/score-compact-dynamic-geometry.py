"""Locate the dynamic Player silhouette changes on exact source triangles."""
from hashlib import sha256
import json
import math
from pathlib import Path
import runpy

import numpy as np
from PIL import Image

root=Path(__file__).resolve().parent
out=root/'compact-dynamic-geometry-probe'
load=lambda p:json.loads(p.read_bytes())
helpers=runpy.run_path(str(root/'compact-dynamic-geometry-control.py'),run_name='load_control')
evaluate=runpy.run_path(str(root/'score-animated-body-topology-deformation.py'),run_name='pose')
cover=runpy.run_path(str(root/'score-animated-body-captured-pose.py'),run_name='coverage')['coverage']
cover.__globals__['extent']=np.array([1280.,720.])


def geometry(mode):
    path=out/f'project-{mode}/content-character/hero-idle-loop-v2.glb'
    data,raw=helpers['unpack_glb'](path.read_bytes())
    def access(i):
        a=data['accessors'][i];v=data['bufferViews'][a['bufferView']]
        t=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']])
        n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
        return np.ndarray((a['count'],n),t,raw,v.get('byteOffset',0)+a.get('byteOffset',0),
                          strides=(v.get('byteStride',t.itemsize*n),t.itemsize))
    p,=data['meshes'][0]['primitives']
    g={k:access(v) for k,v in p['attributes'].items() if k in ('POSITION','WEIGHTS_0','JOINTS_0','TEXCOORD_0')}
    native=bool(p.get('extras',{}).get('azurePreserveSkinWeightCodes'))
    assert native==(mode=='candidate')
    w=g['WEIGHTS_0'].astype(float)
    w=w/65535 if native else w/w.sum(1,keepdims=True)
    return (g['POSITION'],w,g['JOINTS_0'],g['TEXCOORD_0'],access(p['indices']).reshape(-1,3))


def projection(points,manifest,transform):
    a=math.radians(transform['rotation'][1])
    spin=np.array([[math.cos(a),0,math.sin(a)],[0,1,0],[-math.sin(a),0,math.cos(a)]])
    eye=np.array(manifest['qaCameraPosition'])
    direction=np.array(manifest['qaCameraTarget'])-eye
    direction/=np.linalg.norm(direction)
    right=np.cross(direction,manifest['cameraUp']);right/=np.linalg.norm(right)
    up=np.cross(right,direction)
    rel=points@spin.T+transform['translation']-eye
    depth=rel@direction
    assert min(depth)>manifest['cameraNear']
    lens=360/math.tan(manifest['cameraLens']['verticalFovRadians']/2)
    return np.column_stack((640+(rel@right)/depth*lens,360-(rel@up)/depth*lens))


def score():
    result=load(out/'nvidia-qualification.json')
    peer=load(out/'intel-qualification.json')
    assert result['scores']==peer['scores']
    level=load(out/'project-original/scene/body-topology.azurelevel')
    hero,=[node for node in level['nodes'] if node['id']=='hero']
    transform=hero['components']['azure.transform']['data']
    modes=('original','candidate')
    geo={mode:geometry(mode) for mode in modes}
    manifests={mode:load(out/f'{mode}-nvidia/frames/capture_manifest.json') for mode in modes}
    same=('qaCameraPosition','qaCameraTarget','cameraUp','cameraLens','cameraNear')
    assert all(manifests['original'][k]==manifests['candidate'][k] for k in same)
    clip=evaluate['sampler'](evaluate['model']['animations'][9])
    keys={}
    for mode,(xyz,w,j,uv,ind) in geo.items():
        k=[tuple(sorted(tuple(v) for v in t)) for t in np.rint(uv[ind]*1e6).astype('i8')]
        keys[mode]=(k,set(k))
    unique={mode:np.array([k not in keys[modes[1-i]][1] for k in keys[mode][0]],dtype=bool)
            for i,mode in enumerate(modes)}
    frames={}
    for name in result['scores']:
        observed={}
        for mode in modes:
            mask0=None
            for device in ('nvidia','intel'):
                p=out/f'{mode}-{device}/frames'/name
                qualification=result if device=='nvidia' else peer
                assert sha256(p.read_bytes()).hexdigest()==qualification['records'][mode]['frames'][name]
                img=np.array(Image.open(p).convert('RGB')).astype('i2')
                mask=(abs(img-img[0,0]).max(2)>2)
                if mask0 is not None: assert np.array_equal(mask0,mask)
                mask0=mask
            observed[mode]=mask0
        lost=observed['original']&~observed['candidate']
        added=~observed['original']&observed['candidate']
        scores={}
        for step in (0,1,2,3):
            mat=evaluate['evaluate'](clip,step/60)
            models={}
            for mode,(xyz,w,j,uv,ind) in geo.items():
                deform=np.einsum('nvij,nj,nv->ni',mat[j],np.column_stack((xyz,np.ones(len(xyz)))),w)
                px=projection(deform[:,:3],manifests[mode],transform)
                witness=lost if mode=='original' else added
                q=np.rint(px*256).astype('i8')[ind]
                a=q[:,1]-q[:,0];b=q[:,2]-q[:,0]
                area=a[:,0]*b[:,1]-a[:,1]*b[:,0]
                trials={}
                for winding,keep in (('both',area!=0),('CW',area>0),('CCW',area<0)):
                    full=cover(px,ind[keep])
                    delta=cover(px,ind[unique[mode]&keep])
                    only=delta&~cover(px,ind[~unique[mode]&keep])
                    trials[winding]=dict(maskPixels=int(full.sum()),maskMismatch=int((full^observed[mode]).sum()),
                        observedChange=int(witness.sum()),observedChangeOnOnlyUniqueTriangles=int((witness&only).sum()),
                        observedChangeOnUniqueTriangles=int((witness&delta).sum()))
                win=min(trials,key=lambda k:trials[k]['maskMismatch'])
                models[mode]=dict(winding=win,**trials[win])
            scores[step]=models
        winner=min(scores,key=lambda i:sum(v['maskMismatch'] for v in scores[i].values()))
        frames[name]=dict(bestStep=winner,poseScores=scores)
    return dict(status='measured-player-triangle-attribution',uniqueUvTriangles={mode:int(q.sum()) for mode,q in unique.items()},frames=frames)


if __name__=='__main__':
    print(json.dumps(score(),indent=2))
