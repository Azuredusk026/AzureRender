"""Separate the remaining body saturation edge errors by their signed channels and ownership."""
from collections import Counter
import json
from pathlib import Path
import runpy

import numpy as np
import cv2

M=Path(__file__).resolve().parent
u=runpy.run_path(str(M/'body-opaque-main-saturation-player.py'),run_name='body_signed_edge_proof')
S=u['score']
sha,read,write=[u[k] for k in ('sha','read','write')]
native=S['reference_path']
ref=S['image'](native).astype(np.int16)
r=read(u['output']/'results.json')
path=M/'body-native-skin-interior-stages-unchanged-history-failed'
point=np.fromfile(path/'points.bin','<u2').reshape(-1,2)
assert point.shape==(47458,2)
registered={tuple(x):i for i,x in enumerate(point)}
mask=np.zeros(ref.shape[:2],np.uint8)
mask[point[:,1],point[:,0]]=1
distance=cv2.distanceTransform(mask,cv2.DIST_L2,5)
series={}
for dev in ('nvidia','intel'):
    files=[p/dev/'frames/frame_000000.png' for p in (u['order_stage'],u['output'])]
    assert [sha(p) for p in files]==[r['devices'][dev][k] for k in ('control','frame')]
    before,after=[S['image'](p).astype(np.int16)-ref for p in files]
    need=(abs(before).max(2)<=1)&(abs(after).max(2)>1)
    xx,yy=np.nonzero(need)[::-1]
    assert len(xx)==r['devices'][dev]['layers']['skin']['newOverOne']
    raw={}
    for event in (783,1383):
        source=path/f'nvidia-{event}.bin'
        raw[event]=np.fromfile(source,'<u4')
        assert len(raw[event])==len(point)
    p=[]
    for x,y in zip(xx,yy,strict=True):
        i=registered[(x,y)]
        edgeDistance=float(distance[y,x])
        d=after[y,x]
        assert abs(d).max()==2
        ownerEqual=bool(raw[783][i]==raw[1383][i])
        row=dict(point=[int(x),int(y)],distanceFromNativeBodyBoundary=edgeDistance,
                 finalNativePackedColorUnchangedSinceBody=ownerEqual,
                 preexistingDelta=before[y,x].tolist(),saturationDelta=d.tolist(),
                 needsHigherRgb=[int(k) for k in np.flatnonzero(d<-1)],
                 needsLowerRgb=[int(k) for k in np.flatnonzero(d>1)])
        p.append(row)
    interior=sum(row['distanceFromNativeBodyBoundary']>6 and row['finalNativePackedColorUnchangedSinceBody'] for row in p)
    assert interior==r['devices'][dev]['layers']['interior']['newOverOne']
    counts=Counter('higher' if row['needsHigherRgb'] else 'lower' for row in p)
    assert counts['higher']>0 and counts['lower']>0
    ownership=Counter('bodyUntilFinal' if row['finalNativePackedColorUnchangedSinceBody'] else 'laterNativeColorChange' for row in p)
    series[dev]=dict(samples=p,needChannelCorrection=counts,nativeOwnership=ownership,
                     interiorCount=interior,source=[sha(p) for p in files])
rec=dict(status='qualified-signed-body-edge-candidate-controls',source=sha(u['output']/'results.json'),native=sha(native),
         scope='pixels newly outside unchanged one-color-step tolerance',productionBodyAcceptance=False,devices=series)
write(M/'body-saturation-edge-direction.json',rec)
print({k:(v['needChannelCorrection'],v['nativeOwnership']) for k,v in series.items()})
