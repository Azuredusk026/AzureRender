"""Lossless pair delta for two owned generated glyph captures."""
import hashlib
import json
import pathlib
import sys
import zipfile
import cv2
import numpy as np

M=pathlib.Path(__file__).resolve().parent
out=M/'immutable-scene-glyph'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=lambda a:hashlib.sha256(a.tobytes()).hexdigest()
write=lambda p,obj:p.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')
label,gpu,max_bytes,record_mode=sys.argv[1:]
assert all(c.isalnum() or c=='-' for c in label)
assert gpu in ('nvidia','intel')
report=out/f'{gpu}-qualification.json'
record=read(report)
base=M/f'projected-reflection-32-step-candidate/baseline-{gpu}/frames'
roots={p.name:p for p in out.iterdir() if p.is_dir()}
folders=[p for p in roots.values() if p.name.startswith(gpu+'-candidate') and
         (p/'result.json').is_file() and read(p/'result.json')==record['scores']['candidate']]
folder,=folders
images=roots[folder.name+'-images']
assert images.resolve().parent==out.resolve() and not images.is_symlink()
archive=out/f'{gpu}-{label}-deltas.zip'
receipt=out/f'{gpu}-{label}-receipt.json'
saved=out/f'{gpu}-{label}-qualification.json'
names=[f'frame_{i:06d}.png' for i in range(2)]
cv2.setNumThreads(1)
proof={}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for key in names:
        x,y=base/key,images/key
        assert y.resolve().parent==images.resolve() and not y.is_symlink()
        reconstructed=record['scores'].get('retainedControlDelta')
        ref=(reconstructed['frames'][key]['inputPng'] if reconstructed else record['scores']['baseline']['files']['frames/'+key])
        assert sha(x)==ref
        assert sha(y)==record['scores']['candidate']['files']['frames/'+key]
        a,b=[cv2.imread(str(p),cv2.IMREAD_UNCHANGED) for p in (x,y)]
        assert a.shape==b.shape==(1440,2560,4) and a.dtype==b.dtype==np.uint8
        d=np.bitwise_xor(a,b)
        z.writestr(key+'.bgra-xor',d.tobytes())
        proof[key]=dict(baselinePng=sha(x),candidatePng=sha(y),baselineBgra=raw(a),candidateBgra=raw(b),
                        shape=list(a.shape),xorBgra=raw(d))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and archive.stat().st_size<=int(max_bytes)
    for key in names:
        a=cv2.imread(str(base/key),cv2.IMREAD_UNCHANGED)
        d=np.frombuffer(z.read(key+'.bgra-xor'),dtype=np.uint8).reshape(a.shape)
        b=np.bitwise_xor(a,d)
        assert raw(a)==proof[key]['baselineBgra'] and raw(d)==proof[key]['xorBgra']
        assert raw(b)==proof[key]['candidateBgra']
saved.write_bytes(report.read_bytes())
write(receipt,dict(label=label,device=gpu,algorithm='BGRA8 XOR against exact retained control, deflated',frames=proof,
                   originalQualification=sha(saved),archiveSha256=sha(archive),archiveBytes=archive.stat().st_size))
assert record_mode in ('keep','release-verified-copies')
if record_mode=='release-verified-copies':
    for key in names:
        target=images/key
        assert target.resolve().parent==images.resolve() and sha(target)==proof[key]['candidatePng']
        target.unlink()
print(receipt,archive.stat().st_size,sha(archive))

