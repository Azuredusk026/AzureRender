"""Measure a single transparent history input in the immutable joint scene."""
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import zipfile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
P=runpy.run_path(str(M/'projected-reflection-native-phase-candidate.py'),run_name='capture_scoring')
S=P['S']
read,write,sha=(P[k] for k in ('read','write','sha'))
W,R,ROOT=S['W'],S['R'],S['HOST']
B=W/'build'
OUT=M/'immutable-scene-glyph'
PROGRAM=M/'projected-history-layer-release'
PLAYER=PROGRAM/'AzurePlayerCaptureResource.exe'
RESOURCE='captured-central-glyph-10480'
ENV=('AZR_NR_QA_RESOURCE_ID','AZR_NR_QA_RESOURCE_PATH')
source=read(M/'projected-reflection-native-phase-candidate/candidate-receipt.json')['source']
project,level=(Path(source[k]) for k in ('project','level'))
glyph=project.parent/'captured-central-glyph/event-10480.gltf'
gold=S['inputs_phase']['replay']
fixture=runpy.run_path(str(M/'projected-reflection-radiance-layer-fixture.py'),run_name='immutable_scene_programs')
qualification=M/'immutable-scene-capture-source/qualification.json'
sys.path.insert(0,str(W/'tools'))
import artifact_maintenance
from artifact_budget import check


def geometry(doc):
    entry=doc['materials'][0]
    assert len(doc['materials'])==1 and entry['alphaMode']=='BLEND'
    assert all(b['uri'].startswith('data:') for b in doc['buffers'])
    azure=entry['extras']['azureRenderMaterial']
    assert azure['class']=='emissive'
    assert azure['surface']['schemaVersion']==2
    return azure['surface']


def immutable_index():
    assert (sha(project),sha(level))==(source['projectSha256'],source['levelSha256'])
    record,=[x for x in read(level)['resources'] if x['id']==RESOURCE]
    assert record['asset']=='centralglyph:/event-10480.gltf'
    scene=read(level)
    assert any(x.get('resourceId')==RESOURCE and x.get('visible',True) for x in scene['nodes'])
    textures=[glyph.parent/x['uri'] for x in read(glyph)['images']]
    sidecars=[p.with_name(p.name+'.azmeta') for p in textures]
    assert all(read(p)['settings']['texture']['mipBias']==-1.0 for p in sidecars)
    return {p.relative_to(project.parent).as_posix():sha(p) for p in (project,level,glyph,*textures,*sidecars)}


def tree_stamp():
    stamp=hashlib.sha256()
    for path in sorted(project.parent.rglob('*')):
        f=path.stat()
        stamp.update(repr((str(path.relative_to(project.parent)),f.st_size,f.st_mtime_ns)).encode())
    return stamp.hexdigest()


def candidate():
    original=read(glyph)
    assert 'submission' not in geometry(original)
    path=OUT/'asset-with-samplers'/glyph.name
    path.parent.mkdir(parents=True,exist_ok=True)
    refs={}
    for i,entry in enumerate(original['images']):
        name=entry['uri']
        assert name==f'10480-{i}.dds'
        ref,output=(glyph.parent/name,path.parent/name)
        if not output.is_file():
            shutil.copyfile(ref,output)
        assert sha(ref)==sha(output)
        refs[name]=sha(ref)
        meta=ref.with_name(ref.name+'.azmeta')
        candidate_meta=output.with_name(output.name+'.azmeta')
        if not candidate_meta.is_file():
            shutil.copyfile(meta,candidate_meta)
        assert read(candidate_meta)['settings']['texture']['mipBias']==-1.0
        assert sha(meta)==sha(candidate_meta)
        refs[meta.name]=sha(meta)
    geometry(original)['submission']='projected-history'
    if not path.is_file():write(path,original)
    altered=read(path)
    assert geometry(altered).pop('submission')=='projected-history' and altered==read(glyph)
    return path,dict(source=sha(glyph),variant=sha(path),textures=refs)


@contextmanager
def programs():
    with artifact_maintenance.database(B) as c:
        records=artifact_maintenance.rows(c)
    old=records[R.name]
    assert old['status']=='closed' and R.name in artifact_maintenance.protected_names(records)
    assert (R/'.finished').is_file() and not old.get('processPid')
    artifact_maintenance.resume(B,R.name)
    try:
        with fixture['programs']() as current:
            yield current
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],timeout=90,check=True)
        with artifact_maintenance.database(B) as c:
            recovered=artifact_maintenance.rows(c)[R.name]
        assert recovered['status']=='closed' and recovered['manifestSha256']==old['manifestSha256']


@contextmanager
def replacement(path):
    initial={key:os.environ.pop(key,None) for key in ENV}
    try:
        if path is not None:os.environ.update(zip(ENV,(RESOURCE,str(path))))
        yield
    finally:
        for key,value in initial.items():
            os.environ.pop(key,None)
            if value is not None:os.environ[key]=value


def raw_digest(array):
    return hashlib.sha256(array.tobytes()).hexdigest()


def preserve_actual_baseline(gpu,folder,expected,row,reference):
    archive=OUT/f'{gpu}-actual-baseline-deltas.zip'
    evidence=OUT/f'{gpu}-actual-baseline-deltas.json'
    names=[f'frame_{i:06d}.png' for i in range(2)]
    paths=[OUT/f'{gpu}-baseline-images'/f for f in names]
    if not evidence.is_file():
        proof={}
        with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
            for i,(n,x) in enumerate(zip(names,paths,strict=True)):
                assert x.resolve().parent==(OUT/f'{gpu}-baseline-images').resolve() and not x.is_symlink()
                assert sha(x)==row['files']['frames/'+n] and sha(reference/n)==expected['images'][i]
                a,b=(cv2.imread(str(y),cv2.IMREAD_UNCHANGED) for y in (reference/n,x))
                assert a.shape==b.shape==(1440,2560,4) and a.dtype==b.dtype==np.uint8
                d=np.bitwise_xor(a,b)
                delta=np.abs(a.astype(np.int16)-b).max(axis=2)
                proof[n]=dict(inputPng=sha(reference/n),actualPng=sha(x),actualDecodedBgra=raw_digest(b),
                              baselineDecodedBgra=raw_digest(a),different=int((delta>0).sum()),
                              overOne=int((delta>1).sum()),peak=int(delta.max()))
                z.writestr(n+'.bgra-xor',d.tobytes())
        assert archive.stat().st_size<1_000_000
        write(evidence,dict(frames=proof,archiveSha256=sha(archive),capture=sha(folder/'result.json')))
    proof=read(evidence)
    assert proof['archiveSha256']==sha(archive) and proof['capture']==sha(folder/'result.json')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for i,n in enumerate(names):
            control=reference/n
            entry=proof['frames'][n]
            assert sha(control)==entry['inputPng']==expected['images'][i]
            baseline=cv2.imread(str(control),cv2.IMREAD_UNCHANGED)
            raw=np.frombuffer(z.read(n+'.bgra-xor'),dtype='u1').reshape(baseline.shape)
            result=np.bitwise_xor(baseline,raw)
            assert raw_digest(result)==entry['actualDecodedBgra']
            x=paths[i]
            if x.is_file():
                assert sha(x)==entry['actualPng']==row['files']['frames/'+n]
                assert raw_digest(cv2.imread(str(x),cv2.IMREAD_UNCHANGED))==entry['actualDecodedBgra']
                x.unlink()
    return (reference,archive,proof['frames'])


def pixels(source,name):
    if isinstance(source,tuple):
        folder,archive,proof=source
        base=cv2.imread(str(folder/name),cv2.IMREAD_UNCHANGED)
        with zipfile.ZipFile(archive) as z:
            raw=np.frombuffer(z.read(name+'.bgra-xor'),dtype='u1').reshape(base.shape)
        result=np.bitwise_xor(base,raw)
        assert raw_digest(result)==proof[name]['actualDecodedBgra']
        return cv2.cvtColor(result,cv2.COLOR_BGRA2RGB)
    return S['img'](source/name)


def one(gpu,label,path):
    folder=OUT/f'{gpu}-{label}'
    control=M/f'projected-reflection-32-step-candidate/baseline-{gpu}'
    expected=read(control/'result.json')
    names=tuple(f'frame_{i:06d}.png' for i in range(2))
    if path is None and (folder/'result.json').is_file():
        row=read(folder/'result.json')
        assert row['player']==sha(PLAYER) and row['input']==sha(glyph)
        assert row['driver']==expected['driver']
        if not row['matchesRetainedWholePng']:
            for f,h in row['files'].items():
                if Path(f).name not in names:assert sha(folder/f)==h
            return folder,row,preserve_actual_baseline(gpu,folder,expected,row,control/'frames')
        for f,h in row['files'].items():
            name=Path(f).name
            if name in names:
                original=control/'frames'/name
                assert sha(original)==h==expected['images'][names.index(name)]
            else:
                assert sha(folder/f)==h
        return folder,row,control/'frames'
    common=OUT/f'{gpu}-{label}-images'
    if path is not None and folder.exists():
        for i in range(1,32):
            attempt=OUT/f'{gpu}-{label}-retest-{i}'
            if not attempt.exists():
                folder=attempt
                common=attempt.with_name(attempt.name+'-images')
                break
    checkpoint=folder/'result.json'
    assert not folder.exists() and not common.exists(), (folder,common)
    folder.mkdir()
    args=read(M/f'projected-reflection-native-phase-candidate/candidate-{gpu}/command.json')
    args[0]=str(PLAYER)
    for key,value in (('--capture-frames','2'),('--capture-dir',common),('--runtime-report',folder/'runtime.json')):
        args[args.index(key)+1]=str(value)
    assert args[args.index('--project')+1]==str(project)
    with replacement(path):
        S['invoke'](gpu,args,folder)
    log=(folder/'player.log').read_text(errors='replace')
    assert (f'Capture resource {RESOURCE}:' in log)==(path is not None)
    if path is not None:assert path.as_posix() in log
    runtime=read(folder/'runtime.json')
    assert runtime['presentationErrors']==[] and runtime['scriptErrors']==[]
    metadata=folder/'frames'
    metadata.mkdir()
    for name in ('capture_manifest.json','gpu_capabilities.json'):
        shutil.copyfile(common/name,metadata/name)
    caps=read(metadata/'gpu_capabilities.json')
    vendor=(0x10de,0x28e0) if gpu=='nvidia' else (0x8086,0xa788)
    assert (caps['vendor_id'],caps['device_id'])==vendor
    assert caps['driver_version']==expected['driver']
    files=('command.json','player.log','runtime.json','frames/capture_manifest.json','frames/gpu_capabilities.json')
    images=[sha(common/name) for name in names]
    row=dict(player=sha(PLAYER),input=sha(path) if path else sha(glyph),driver=caps['driver_version'],
             files={f:sha(folder/f) for f in files}|{'frames/'+name:h for name,h in zip(names,images)})
    if path is None:
        row['matchesRetainedWholePng']=images==expected['images'][:2]
        write(checkpoint,row)
        if not row['matchesRetainedWholePng']:
            return folder,row,preserve_actual_baseline(gpu,folder,expected,row,control/'frames')
        assert images==[sha(control/'frames'/name) for name in names]
    else:
        write(checkpoint,row)
    print(gpu,label,row['driver'],images,flush=True)
    return folder,row,(control/'frames' if path is None else common)


def analyze(gpu,baseline,variant):
    a,ra,a_pixels=baseline
    b,rb,b_pixels=variant
    x,y=(read(p/'frames/capture_manifest.json') for p in (a,b))
    assert ra['driver']==rb['driver']
    assert all(x[k]==y[k] for k in S['forbid'])
    assert (x['width'],x['height'],x['fps'],x['capturedFrames'])==(2560,1440,60,2)
    assert x['screenReflectionProducer']=='projected-history'
    assert all(q['screenReflectionHistoryValid'] and q['screenReflectionHistoryInputSubmission']==1 for q in (x,y))
    for k in ('qaCameraPosition','qaCameraTarget','cameraLens','cameraUp'):
        assert x[k]==S['golden']['camera'][k]
    expected=read(M/f'projected-reflection-32-step-candidate/baseline-{gpu}/result.json')
    assert expected['driver']==ra['driver']
    assert sha(gold)==S['golden']['frames']['gameBackbuffer']['sha256']
    reference=S['img'](gold)
    rows=[]
    firstExact=False
    for i in range(2):
        name=f'frame_{i:06d}.png'
        p,q=(pixels(f,name) for f in (a_pixels,b_pixels))
        d=abs(p.astype(np.int16)-q).max(axis=-1)
        if i==0:firstExact=not d.any()
        rows.append(dict(controlMatchesPreviousPlayer=ra['files']['frames/'+name]==expected['images'][i],
                         changed=int((d>0).sum()), overOne=int((d>1).sum()), peak=int(d.max()),
                         regions=P['evaluate'](p,q,reference)))
    provenance=None if not isinstance(a_pixels,tuple) else dict(archive=sha(a_pixels[1]),frames=a_pixels[2])
    return dict(baseline=ra,candidate=rb,firstFrameExact=firstExact,secondFrameChange=bool(rows[1]['changed']),
                retainedControlDelta=provenance,frames=rows)


def run(gpu):
    assert gpu in ('nvidia','intel')
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and lock['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9' and Path(lock['output'])==M
    compiled=read(qualification)
    assert compiled['readOnlyProjectAssets'] and compiled['candidatePlayer']==sha(PLAYER)
    cv2.setNumThreads(1)
    immutable=immutable_index()
    stamp=tree_stamp()
    old=M/f'projected-reflection-native-phase-candidate/candidate-{gpu}/frames'
    # The original baseline renderer requires an empty capture directory. Release
    # only the two exact replay duplicates after independently revalidating both.
    baseline=None
    if (OUT/f'{gpu}-baseline/result.json').is_file():
        baseline=one(gpu,'baseline',None)
        keep,record,reference=baseline
        allowed=(OUT/f'{gpu}-frames',OUT/f'{gpu}-baseline-images')
        for folder in allowed:
            if not folder.is_dir() or isinstance(reference,tuple):continue
            assert folder.resolve().parent==OUT.resolve() and not folder.is_symlink()
            for i in range(2):
                name=f'frame_{i:06d}.png'
                duplicate=folder/name
                if duplicate.is_file():
                    assert duplicate.resolve().parent==folder.resolve() and not duplicate.is_symlink()
                    assert sha(duplicate)==sha(reference/name)==record['files']['frames/'+name]
                    duplicate.unlink()
    estimate=sum((old/f'frame_{i:06d}.png').stat().st_size for i in range(2))+1_650_000
    budget=check(B,run=M,planned=estimate)
    assert budget['allowed'],budget
    path,materials=candidate()
    with programs() as (default,roots,shaders):
        assert default.parent==PLAYER.parent and roots==ROOT and shaders==compiled['trace']
        if baseline is None:
            baseline=one(gpu,'baseline',None)
            unused,record,reference=baseline
            for i in range(2):
                name=f'frame_{i:06d}.png'
                duplicate=OUT/f'{gpu}-baseline-images'/name
                if not isinstance(reference,tuple):
                    assert sha(duplicate)==sha(reference/name)==record['files']['frames/'+name]
                    duplicate.unlink()
        variant=one(gpu,'candidate',path)
    assert immutable_index()==immutable and tree_stamp()==stamp
    scores=analyze(gpu,baseline,variant)
    report=dict(status='measured-joint-scene-glyph-only', immutableInputs=immutable, inputTreeStamp=stamp,
                material=materials, programs=compiled, golden=sha(gold), scores=scores)
    write(OUT/f'{gpu}-qualification.json',report)
    print(json.dumps(dict(firstFrameExact=scores['firstFrameExact'],secondFrameChange=scores['secondFrameChange'],
                         frames=[(f['changed'],f['peak']) for f in scores['frames']],
                         keepsStrictGatesOpen=True)),flush=True)


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(json.dumps(immutable_index()))
    else:
        device,=sys.argv[1:]
        run(device)

