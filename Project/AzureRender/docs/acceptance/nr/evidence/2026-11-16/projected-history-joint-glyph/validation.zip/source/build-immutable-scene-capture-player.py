"""Build a capture-only entry point with a single immutable resource intervention."""
import ast
import json
from hashlib import sha256
import os
from pathlib import Path
import runpy
import subprocess
import sys

run=Path(__file__).resolve().parent
work=run.parents[2]
body=run.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
base=body/'msaa-release'
combined=run/'projected-history-layer-release'
out=run/'immutable-scene-capture-source'
exe=combined/'AzurePlayerCaptureResource.exe'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
environment=('AZR_NR_QA_RESOURCE_ID','AZR_NR_QA_RESOURCE_PATH')
anchor='''            initial.projectStartup = std::make_shared<const azurerender::ProjectStartup>(
                azurerender::Project::load(std::filesystem::u8path(projectPath)));'''
patch='''            auto startup = std::make_shared<azurerender::ProjectStartup>(
                azurerender::Project::load(std::filesystem::u8path(projectPath)));
            if (qaResourceId) {
                // This diagnostic owns the mutable startup before sharing its const view.
                // Only the renderer's path changes. Asset resolution and Level data are prepared normally.
                auto& level = const_cast<azurerender::Level&>(startup->level());
                auto& resources = level.scene.resources;
                const auto location = std::filesystem::u8path(qaResourcePath);
                if (!location.is_absolute() || !std::filesystem::is_regular_file(location)
                    || (location.extension() != ".gltf" && location.extension() != ".glb"))
                    throw std::runtime_error("Expected an absolute glTF capture resource path");
                const auto resource = std::find_if(resources.begin(), resources.end(),
                    [&](const auto& current) { return current.id == qaResourceId; });
                if (resource == resources.end())
                    throw std::runtime_error("Capture resource ID is absent from the startup scene");
                if (std::none_of(level.scene.nodes.begin(), level.scene.nodes.end(),
                    [&](const auto& node) { return node.resourceId == resource->id && node.visible; }))
                    throw std::runtime_error("Capture resource is not used by a visible startup node");
                std::cout << "Capture resource " << resource->id << ": "
                          << resource->path.generic_u8string() << " => " << location.generic_u8string() << '\\n';
                resource->path = location.lexically_normal();
            }
            initial.projectStartup = std::move(startup);'''
guard='''        const char* qaResourceId = std::getenv("AZR_NR_QA_RESOURCE_ID");
        const char* qaResourcePath = std::getenv("AZR_NR_QA_RESOURCE_PATH");
        if (qaResourceId || qaResourcePath) {
            const auto has = [&](const char* flag) { return std::find(args.begin(), args.end(), flag) != args.end(); };
            if (!qaResourceId || !*qaResourceId || !qaResourcePath || !*qaResourcePath ||
                projectPath.empty() || check || !createPath.empty() || has("--scene") ||
                !has("--capture-dir") || !has("--capture-frames") || !has("--fixed-frame-step"))
                throw std::runtime_error("Capture resource override requires two values and a fixed-step project capture");
        }
'''


def checked_source():
    base_path=work/'src/player/main.cpp'
    old=base_path.read_text(encoding='utf8')
    frozen=subprocess.check_output(['git','show','75837a6:Project/AzureRender/src/player/main.cpp'],cwd=work,text=True,encoding='utf8')
    assert frozen==old and old.count(anchor)==1
    assert old.count('        AzureRenderOptions initial;')==1
    revised=old.replace(anchor,patch).replace('        AzureRenderOptions initial;',guard+'        AzureRenderOptions initial;')
    return digest(base_path),revised


def build():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and lease['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9' and Path(lease['output'])==run
    sys.path.insert(0,str(work/'tools'))
    from artifact_budget import check
    b=check(run.parents[1],run=run,planned=6_000_000)
    assert b['allowed'],b
    baseline=read(combined/'link-receipt.json')
    assert digest(combined/'AzurePlayer.exe')==baseline['newPlayer']
    assert all(digest(work/f)==q for f,q in baseline['inputs'].items())
    old,source=checked_source()
    out.mkdir(exist_ok=True)
    native=out/'main.cpp'
    native.write_text(source,encoding='utf8')
    driver=runpy.run_path(str(body/'face-quality-batch.py'),run_name='verified_compiler')
    cmake=Path(driver['cmake'])
    ninja=cmake.parents[2]/'Ninja'/'ninja.exe'
    schema=ast.parse((run/'build-camera-pose-player.py').read_text(encoding='utf8'))
    args_fn,=[p for p in schema.body if isinstance(p,ast.FunctionDef) and p.name=='windows_arguments']
    scope={}
    exec(compile(ast.Module(body=[args_fn],type_ignores=[]),'argument_expansion','exec'),scope)
    rules=subprocess.check_output([str(ninja),'-C',str(base),'-t','commands','AzurePlayer'],text=True).splitlines()
    entry,=[v for v in rules if v.endswith(str(work/'src/player/main.cpp'))]
    cl=scope['windows_arguments'](entry)
    assert Path(cl[0]).name.lower()=='cl.exe'
    obj=out/'main.cpp.obj'
    for flag,name in (('/Fo',obj),('/Fd',out/'main.pdb')):
        at,=[i for i,v in enumerate(cl) if v.startswith(flag)]
        cl[at]=flag+str(name)
    cl[-1]=str(native)
    cache_path=work/'src/runtime/AssetDatabase.cpp'
    cache_source=cache_path.read_text(encoding='utf8')
    patches={
      'else { meta = {{': 'else { throw std::runtime_error("Read-only capture found an asset without metadata: "+path.u8string()); meta = {{',
      'changed.push_back(entry.first); cache(project_': 'changed.push_back(entry.first); if(false) cache(project_',
      '    cache(path, record); return bytes(record.path);': '    return bytes(record.path);',
    }
    for before,after in patches.items():
        assert cache_source.count(before)==1
        cache_source=cache_source.replace(before,after)
    cache_native=out/'AssetDatabase.cpp'
    cache_native.write_text(cache_source,encoding='utf8')
    cache_entry,=[v for v in rules if v.endswith(str(cache_path))]
    cache_cl=scope['windows_arguments'](cache_entry)
    cache_obj=out/'AssetDatabase.cpp.obj'
    for flag,name in (('/Fo',cache_obj),('/Fd',out/'asset-database.pdb')):
        at,=[i for i,v in enumerate(cache_cl) if v.startswith(flag)]
        cache_cl[at]=flag+str(name)
    cache_cl[-1]=str(cache_native)
    rsp=out/'player.rsp'
    previous=(combined/'player.rsp').read_text(encoding='ascii').splitlines()
    assert str(combined/'main.cpp.obj') in previous[0]
    rsp.write_text('\n'.join([subprocess.list2cmdline([str(obj),str(cache_obj)]),*previous[1:]])+'\n',encoding='ascii')
    linker=baseline['linkCommand'].copy()
    for i,value in enumerate(linker):
        if value.startswith('--intdir='):
            intdir=out/'link-intermediates'
            intdir.mkdir(exist_ok=True)
            linker[i]='--intdir='+str(intdir)
        elif value.startswith('@'):linker[i]='@'+str(rsp)
        elif value.lower().startswith('/out:'):linker[i]='/out:'+str(exe)
        elif value.lower().startswith('/implib:'):linker[i]='/implib:'+str(out/'entry.lib')
        elif value.lower().startswith('/pdb:'):linker[i]='/pdb:'+str(out/'entry.pdb')
    assert obj.is_file() and digest(obj)==read(out/'qualification.json')['entryObject']
    env={k:v for k,v in os.environ.items() if k not in environment}
    for stage,command in (('compile-cache',cache_cl),('link',linker)):
        args=[driver['entry'],*command]
        res=subprocess.run(subprocess.list2cmdline(args),shell=True,cwd=base,env=env,capture_output=True,timeout=145)
        (out/(stage+'.log')).write_bytes(res.stdout+res.stderr)
        assert res.returncode==0,(stage,res.stdout[-4000:],res.stderr[-2000:])
    good=subprocess.run([str(exe),'--help'],env=env,capture_output=True,timeout=20)
    failure=subprocess.run([str(exe),'--help'],env=dict(env,**{environment[0]:'glyph'}),capture_output=True,timeout=20)
    assert good.returncode==0 and 'fixed-step project capture' in failure.stderr.decode('ascii') and failure.returncode!=0
    r=dict(status='linked-capture-only-resource-override',sourcePlayer=baseline['newPlayer'],trace=baseline['programs'],
           entrySource=old,diagnosticSource=digest(native),candidatePlayer=digest(exe),
           negativeCliExit=failure.returncode,entryObject=digest(obj),readOnlyProjectAssets=True,
           assetDatabaseSource=digest(cache_path),assetDatabaseDiagnostic=digest(cache_native),
           assetDatabaseObject=digest(cache_obj))
    (out/'qualification.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
    print(json.dumps(r),flush=True)


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:print(checked_source()[0])
    else:build()
