"""Archive the explicit glyph-only trial with compact exact color recovery."""
from pathlib import Path
from hashlib import sha256
import json
import sqlite3
import zipfile
import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
E=M/'immutable-scene-glyph'
D=W/'docs/acceptance/nr/evidence/2026-11-16/projected-history-joint-glyph'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
raw=lambda a:sha256(a.tobytes()).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
cv2.setNumThreads(1)
db=sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True)
queue={}
for id in (1451,1452,1453,1454,1455,1457):
    task,state,exit_code=db.execute('select task,state,exit_code from jobs where id=?',(id,)).fetchone()
    queue[str(id)]=dict(task=task,state=state,exitCode=exit_code)
for i in (1451,1453,1454,1457):assert queue[str(i)]['state']=='succeeded'
for i in (1452,1455):assert queue[str(i)]['state']=='failed'
records={g:read(E/f'{g}-samplers-qualification.json') for g in ('nvidia','intel')}
assert all(q['scores']['firstFrameExact'] and q['scores']['secondFrameChange'] for q in records.values())
assert records['nvidia']['scores'].get('retainedControlDelta') is None
last=records['intel']['scores']['retainedControlDelta']
assert [k['different'] for k in last['frames'].values()]==[46,18]
assert all(q['programs']['readOnlyProjectAssets'] for q in records.values())
assert records['nvidia']['inputTreeStamp']==records['intel']['inputTreeStamp']
assert records['nvidia']['immutableInputs']==records['intel']['immutableInputs']
reject=read(E/'nvidia-no-sampler-qualification.json')
assert not reject['scores']['firstFrameExact'] and reject['scores']['frames'][0]['changed']==60783
assert all(q['scores']['frames'][1]['regions']['centerFloor']['candidate']['ssim']<.95 for q in records.values())
assert all(q['scores']['frames'][1]['regions']['cyanRing']['candidate']['ssim']<.95 for q in records.values())
assert all(any(r['pixels']['newlyOverOne'] for name,r in q['scores']['frames'][1]['regions'].items()
               if name not in ('complete','centerFloor','cyanRing')) for q in records.values())

archive_files={}
put=lambda p,name:archive_files.__setitem__(name,p)
for g,l in (('nvidia','no-sampler'),('nvidia','samplers'),('intel','samplers')):
    prefix=f'{g}-{l}'
    r=read(E/(prefix+'-receipt.json'))
    q=read(E/(prefix+'-qualification.json'))
    f=E/(prefix+'-deltas.zip')
    assert r['archiveSha256']==sha(f)
    assert r['originalQualification']==sha(E/(prefix+'-qualification.json'))
    earlier=M/f'projected-reflection-32-step-candidate/baseline-{g}/frames'
    with zipfile.ZipFile(f) as nested:
        assert nested.testzip() is None
        for key,check in r['frames'].items():
            x=earlier/key
            assert sha(x)==check['baselinePng']
            a=cv2.imread(str(x),cv2.IMREAD_UNCHANGED)
            d=np.frombuffer(nested.read(key+'.bgra-xor'),dtype=np.uint8).reshape(a.shape)
            assert raw(a)==check['baselineBgra'] and raw(d)==check['xorBgra']
            col=np.bitwise_xor(a,d)
            assert raw(col)==check['candidateBgra']
    for n in ('deltas.zip','receipt.json','qualification.json'):put(E/(prefix+'-'+n),f'captures/{prefix}/{n}')
    try_folder,=[c for c in E.iterdir() if c.name.startswith(g+'-candidate') and
                (c/'result.json').is_file() and read(c/'result.json')==q['scores']['candidate']]
    for rel,h in q['scores']['candidate']['files'].items():
        if rel.endswith('.png'):continue
        p=try_folder/rel
        assert sha(p)==h
        put(p,f'captures/{prefix}/candidate/{rel}')
for g in ('nvidia','intel'):
    for rel,h in records[g]['scores']['baseline']['files'].items():
        if rel.endswith('.png'):continue
        p=E/f'{g}-baseline'/rel
        assert sha(p)==h
        put(p,f'captures/{g}-baseline/{rel}')
for name in ('intel-actual-baseline-deltas.json','intel-actual-baseline-deltas.zip'):
    put(E/name,f'captures/intel-baseline/{name}')
assert sha(E/'intel-actual-baseline-deltas.zip')==last['archive']
with zipfile.ZipFile(E/'intel-actual-baseline-deltas.zip') as z:
    assert z.testzip() is None
    folder=M/'projected-reflection-32-step-candidate/baseline-intel/frames'
    for name,k in last['frames'].items():
        assert sha(folder/name)==k['inputPng']
        base=cv2.imread(str(folder/name),cv2.IMREAD_UNCHANGED)
        variant=np.bitwise_xor(base,np.frombuffer(z.read(name+'.bgra-xor'),dtype=np.uint8).reshape(base.shape))
        assert raw(variant)==k['actualDecodedBgra']
for name in ('build-immutable-scene-capture-player.py','run-immutable-scene-glyph-capture.py',
             'compact-immutable-glyph-pair.py','archive-immutable-scene-glyph.py'):
    put(M/name,'source/'+name)
for name in ('main.cpp','AssetDatabase.cpp','qualification.json'):
    put(M/'immutable-scene-capture-source'/name,'build/'+name)
for name in ('retest-joint-glyph-nvidia-sampler-sidecars.log','retest-joint-glyph-intel-actual-baseline-paired.log',
             'retest-joint-glyph-intel-sampler-sidecars.log','retest-immutable-joint-scene-glyph-nvidia.log'):
    put(M/name,'logs/'+name)
mat=E/'asset-with-samplers'
for p in sorted(mat.iterdir()):
    if p.suffix=='.dds':continue
    put(p,'asset/'+p.name)

D.mkdir(parents=True,exist_ok=True)
archive=D/'validation.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for key,p in sorted(archive_files.items()):z.write(p,key)
assert archive.stat().st_size<8*1024*1024
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and all(z.read(k)==p.read_bytes() for k,p in archive_files.items())
details={}
for g,q in records.items():
    f=q['scores']['frames'][1]['regions']
    details[g]={'firstExact':q['scores']['firstFrameExact'],'secondChanged':q['scores']['frames'][1]['changed'],
                'regions':{k:dict(baselineSsim=f[k]['baseline']['ssim'],candidateSsim=f[k]['candidate']['ssim'],
                                  baselineLumaError=f[k]['baseline']['medianLumaRelativeError'],
                                  candidateLumaError=f[k]['candidate']['medianLumaRelativeError'],
                                  addedOverOne=f[k]['pixels']['newlyOverOne'],peak=f[k]['candidate']['peak']) for k in f},
                'driver':q['scores']['candidate']['driver']}
write(D/'qualification.json',dict(status='qualified-readonly-pair-rejected-single-glyph', gate='open',
   formal=dict(targetSsim=.95,targetMedianRelativeLumaError=.10,neighborNewOverOne=0,peakRgb=1,originalFrozenExact=True),
   queue=queue,results=details,intelRetainedControlDrift=last,diagnosticMissingSamplerFirstFrameChanged=60783,
   candidateInputs=records['nvidia']['material'],immutableInputs=records['nvidia']['immutableInputs'],
   validation=dict(archiveSha256=sha(archive),files={k:sha(p) for k,p in archive_files.items()})))
print(archive.stat().st_size,sha(archive))
print(details)

