"""Link the checked loader into the existing read-only fixture Player."""
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile, ZIP_LZMA
import json
import runpy
import subprocess
import sys

M=Path(__file__).resolve().parent
W=M.parents[2]
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
H=R/'msaa-release'
P=M/'projected-history-layer-release'
F=M/'readonly-face-fixture-source'
A=M/'body-saturation-production-validation'
O=M/'body-saturation-production-player'
read=lambda p:json.loads(p.read_bytes())
h=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')


def run():
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M and lease['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9'
    q=read(A/'qualification.json')
    assert q['status']=='passed-production-character-repair-with-new-loader'
    assert all(h(Path(path))==sha for path,sha in q['source'].items())
    loader=A/'GltfLoader.cpp.obj'
    test=A/'CharacterRepairTests.cpp.obj'
    assert h(loader)==q['loaderObject']
    O.mkdir(exist_ok=True)

    def compact(p,expected):
        packed=O/(p.name+'.zip')
        if packed.is_file() and not p.exists():
            with ZipFile(packed) as z:
                assert sha256(z.read(p.name)).hexdigest()==expected
            return
        assert p.resolve()==p and p.parent==A and (p.name in ('GltfLoader.cpp.obj','CharacterRepairTests.cpp.obj'))
        assert not p.stat().st_file_attributes&1024 and h(p)==expected
        memory=BytesIO()
        with ZipFile(memory,'w',ZIP_LZMA) as z:
            z.write(p,p.name)
        value=memory.getvalue()
        budget=check(W/'build',run=M,planned=len(value)+20_000)
        assert budget['allowed'],budget
        with packed.open('xb') as fp:
            fp.write(value)
        with ZipFile(packed) as z:
            assert z.testzip() is None and sha256(z.read(p.name)).hexdigest()==expected
        p.unlink()

    compact(test,q['testObject'])
    budget=check(W/'build',run=M,planned=8_050_000)
    assert budget['allowed'],budget
    fixture=read(F/'qualification.json')
    before=read(F/'main-object-compaction.json')
    old=Path(before['archive'])
    assert fixture['readOnlyProjectAssets'] and h(P/'AzurePlayerCaptureFaceFixture.exe')==fixture['candidatePlayer']
    assert h(old)==before['archiveSha'] and before['sha256']==fixture['entryObject']
    recovered=O/'main.cpp.obj'
    with ZipFile(old) as z:
        data=z.read(before['member'])
    assert sha256(data).hexdigest()==fixture['entryObject']
    recovered.write_bytes(data)
    rsp_in=(F/'player.rsp').read_text(encoding='ascii').splitlines()
    assert str(F/'main.cpp.obj') in rsp_in[0]
    rsp=O/'player.rsp'
    rsp.write_text(rsp_in[0].replace(str(F/'main.cpp.obj'),str(recovered))+' '+str(loader)+'\n'+'\n'.join(rsp_in[1:])+'\n',encoding='ascii')
    exe=P/'AzurePlayerOpaqueSkinSaturation.exe'
    link=read(P/'link-receipt.json')['linkCommand'].copy()
    intermediate=O/'link'
    intermediate.mkdir(exist_ok=True)
    repl={'--intdir=':intermediate,'@':rsp,'/out:':exe,'/implib:':O/'Player.lib','/pdb:':O/'Player.pdb'}
    link=[next((k+str(v) for k,v in repl.items() if a.lower().startswith(k)),a) for a in link]
    tool=runpy.run_path(str(R/'face-quality-batch.py'),run_name='skin_optin_player_toolchain')['entry']
    try:
        task=subprocess.run(subprocess.list2cmdline([tool,*link]),shell=True,cwd=H,capture_output=True,timeout=220)
        (O/'build.log').write_bytes(task.stdout+task.stderr)
        assert task.returncode==0,task.stdout[-3000:]
    finally:
        assert h(recovered)==fixture['entryObject']
        recovered.unlink()
    control=subprocess.run([str(exe),'--help'],capture_output=True,timeout=15)
    assert control.returncode==0 and b'--capture-frames' in control.stdout
    compact(loader,q['loaderObject'])
    write(O/'qualification.json',dict(status='linked-opaque-skin-main-brightness-player',executable=h(exe),
        compiledProfile=q['loaderObject'],fixturePlayer=fixture['candidatePlayer'],testReceipt=h(A/'qualification.json'),
        source=q['source'],links={'testObject':h(O/(test.name+'.zip')),'loaderObject':h(O/(loader.name+'.zip'))}))
    print(read(O/'qualification.json'),flush=True)


if __name__=='__main__':
    run()
