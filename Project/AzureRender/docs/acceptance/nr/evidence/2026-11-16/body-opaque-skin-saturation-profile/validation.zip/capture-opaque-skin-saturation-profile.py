"""Capture the opt-in skin lighting profile on the unchanged full-character fixture."""
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from hashlib import sha256
from zipfile import ZIP_DEFLATED, ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
B=W/'build'
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
G=M.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
C=R/'face-quality-release-isolated-mask'
F=G/'iris-overlay-geometry-project'
O=M/'body-saturation-production-captures'
P=M/'projected-history-layer-release/AzurePlayerOpaqueSkinSaturation.exe'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
h=lambda p:sha256(p.read_bytes()).hexdigest()
env=('AZR_NR_QA_OVERLAY_ROOT','AZR_NR_QA_OVERLAY_SCENE')
tag='face-quality-native-production-combined'
source_path=W/'shaders/mesh.frag'
native_path=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-cloth-reference.png')


def run():
    sys.path.insert(0,str(W/'tools'))
    import artifact_maintenance as art
    from artifact_budget import check
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and lock['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9' and Path(lock['output'])==M
    budget=check(B,run=M,planned=9_500_000)
    assert budget['allowed'],budget
    built=read(M/'body-saturation-production-player/qualification.json')
    assert built['status']=='linked-opaque-skin-main-brightness-player' and h(P)==built['executable']
    assert h(source_path)==built['source'][str(source_path)]
    values=runpy.run_path(str(M/'readonly-body-saturation-precision-all-programs.py'),run_name='skin_fixture_sources')
    files,scene,_=values['fixture_sources']()
    O.mkdir(exist_ok=True)
    fixture=O/'fixture'
    for name,p in files.items():
        q=fixture/name
        q.parent.mkdir(parents=True,exist_ok=True)
        q.write_bytes(p.read_bytes())
        assert h(q)==h(p)
    hashes={str(p):h(p) for p in files.values()}
    k='name:M_actor_laevat_body_01'
    hero,=[p for p in scene['nodes'] if p['id']=='hero']
    original=hero['materialSlots'][k]
    assert original=='89d76420-10fe-5b1a-80a3-0880ad842506'
    material=F/'materials'/f'{original}.azurematerial'
    meta=material.with_name(material.name+'.azmeta')
    hashes.update({str(p):h(p) for p in (material,meta)})
    profile=read(material)
    surface=profile['surface']['materials'][0]
    contract=surface['extras']['azureRenderMaterial']
    assert contract['class']=='skin' and contract['schemaVersion']==2 and surface.get('alphaMode','OPAQUE')=='OPAQUE'
    assert 'mainBrightnessSaturation' not in contract['nprDiffuse']
    contract['nprDiffuse']['mainBrightnessSaturation']=True
    metadata=read(meta)
    assert metadata['id']==original
    chosen='12566037-60d4-53ef-a2dd-fbf50c8a47d5'
    metadata['id']=chosen
    candidate=fixture/'materials'/f'{chosen}.azurematerial'
    write(candidate,profile)
    write(candidate.with_name(candidate.name+'.azmeta'),metadata)
    shaders=O/'programs'
    shaders.mkdir(exist_ok=True)
    compile=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='skin_compiler')['H']['compile_program']
    variants=values['variants']
    for name in variants:
        compile(source_path,shaders/name,name,diagnostics=O/'compile'/f'{name}.log')
    changed={n:h(shaders/n) for n in variants}
    os.environ['AZURE_NR_FACE_RELEASE_STAGE']=C.name
    catalog=runpy.run_path(str(R/'face-quality-candidate-catalog.py'),run_name='skin_catalog')
    invoke=runpy.run_path(str(R/'face-quality-production.py'),run_name='skin_capture')['helper']['invoke']
    history=read(C/'test-receipt.json')['compiledPrograms']
    baseline=catalog['retained_catalog'](R)|history
    native=cv2.imread(str(native_path),-1)
    mask=cv2.imread(str(G/'native-face-masks/skin.png'),0)>0
    assert mask.sum()==47458 and native.shape[:2]==(1440,2560) and native.shape[2] in (3,4)
    summary={}
    with art.database(B) as d:
        pinned=art.rows(d)[R.name]
    assert pinned['status']=='closed'
    art.resume(B,R.name)
    try:
        with catalog['activate'](history,alternate_run=M) as assets:
            swapped=[]
            try:
                for n in variants:
                    p=assets/'shaders'/n
                    backup=p.with_name(p.name+'.skin-profile-replay-original')
                    assert not backup.exists() and h(p)==baseline[n]
                    p.replace(backup)
                    swapped.append((p,backup))
                    p.hardlink_to(shaders/n)
                for gpu in ('nvidia','intel'):
                    actual={}
                    for mode,slot in (('control',original),('enabled',chosen)):
                        hero['materialSlots'][k]=slot
                        write(fixture/'scene'/f'{tag}.azurelevel',scene)
                        output=O/f'{gpu}-{mode}'
                        output.mkdir()
                        args=read(C/f'public-combined-{gpu}/command.json')
                        args[0]=str(P)
                        for flag,v in (('--resource-root',assets),('--project',F/'eye-shadow-authored-tint.azureproject'),
                                       ('--runtime-report',output/'runtime.json'),('--capture-dir',output/'frames')):
                            args[args.index(flag)+1]=str(v)
                        assert all(key not in os.environ for key in env)
                        os.environ.update(zip(env,(str(fixture),tag+'.azurelevel')))
                        try:
                            frame=invoke(gpu,args,output)/'frame_000000.png'
                        finally:
                            for key in env:os.environ.pop(key)
                        pixels=cv2.imread(str(frame),-1)
                        assert pixels.shape[:2]==native.shape[:2] and pixels.shape[2] in (3,4)
                        runtime=read(output/'runtime.json')
                        log=(output/'player.log').read_text('utf8',errors='replace')
                        assert not runtime['scriptErrors'] and not runtime['presentationErrors']
                        assert 'Allocator after unload: buffers=0 images=0' in log
                        actual[mode]=pixels
                        earlier=C/f'public-combined-{gpu}/frames/frame_000000.png'
                        before=cv2.imread(str(earlier),-1)
                        archive=output/'frame-xor.zip'
                        with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as z:
                            z.writestr('bgra-xor',np.bitwise_xor(before,pixels).tobytes())
                        with ZipFile(archive) as z:
                            rebuilt=before^np.frombuffer(z.read('bgra-xor'),np.uint8).reshape(pixels.shape)
                        assert np.array_equal(rebuilt,pixels) and frame.resolve()==frame and not frame.stat().st_file_attributes&1024
                        write(output/'frame-receipt.json',dict(png=h(frame),archive=h(archive),control=h(earlier),scene=h(fixture/'scene'/f'{tag}.azurelevel')))
                        frame.unlink()
                    a,b=[actual[l][:,:,:3].astype(np.int16) for l in ('control','enabled')]
                    c=native[:,:,:3].astype(np.int16)
                    before=np.abs(a-c).max(2)
                    after=np.abs(b-c).max(2)
                    spatial=np.any(a!=b,axis=2)
                    summary[gpu]=dict(changed=int(spatial.sum()),outsideSkinChanged=int(np.count_nonzero(spatial&~mask)),
                        controlOverOne=int(np.count_nonzero((before>1)&mask)),enabledOverOne=int(np.count_nonzero((after>1)&mask)),
                        newOverOne=int(np.count_nonzero((before<=1)&(after>1)&mask)),
                        enabledPeak=int(after[mask].max()),averageBefore=float(before[mask].mean()),averageAfter=float(after[mask].mean()))
                    print(gpu,summary[gpu],flush=True)
                    assert summary[gpu]['outsideSkinChanged']==0 and summary[gpu]['averageAfter']<summary[gpu]['averageBefore']
            finally:
                for p,backup in reversed(swapped):
                    assert h(backup)==baseline[p.name]
                    backup.replace(p)
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=460)
    with art.database(B) as d:
        end=art.rows(d)[R.name]
    assert end['status']=='closed' and end['manifestSha256']==pinned['manifestSha256']
    assert all(h(Path(path))==val for path,val in hashes.items())
    write(O/'qualification.json',dict(status='measured-explicit-opaque-skin-main-brightness-profile',devices=summary,
        executable=h(P),source=h(source_path),material=h(candidate),shaders=changed,inputs=hashes))


if __name__=='__main__':
    run()

