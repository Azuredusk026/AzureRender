"""Compile the current loader and run the production CharacterRepair test."""
import ast
from hashlib import file_digest
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys

M=Path(__file__).resolve().parent
W=M.parents[2]
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
host=R/'msaa-release'
O=M/'body-saturation-production-validation'
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
ninja=Path('D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe')

def h(p):
    with p.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


def run():
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9' and lock['state']=='held' and Path(lock['output'])==M
    capacity=check(W/'build',run=M,planned=2_100_000 if (O/'CharacterRepairTests.cpp.obj').is_file() else 14_000_000)
    assert capacity['allowed'],capacity
    O.mkdir(exist_ok=True)
    entry=runpy.run_path(str(R/'face-quality-batch.py'),run_name='production_skin_saturation_toolchain')['entry']
    fn=next(node for node in ast.parse((M/'build-camera-pose-player.py').read_text('utf8')).body
            if isinstance(node,ast.FunctionDef) and node.name=='windows_arguments')
    ctx={}
    exec(compile(ast.Module(body=[fn],type_ignores=[]),'argv','exec'),ctx)
    args=ctx['windows_arguments']
    def execute(argv,stage,timeout=240):
        p=subprocess.run(subprocess.list2cmdline([entry,*argv]),shell=True,cwd=host,capture_output=True,timeout=timeout)
        (O/(stage+'.log')).write_bytes(p.stdout+p.stderr)
        assert p.returncode==0,(stage,p.stdout[-3000:],p.stderr[-1200:])
    source=[W/'src/assets/GltfLoader.cpp',W/'tests/CharacterRepairTests.cpp']
    header=W/'src/assets/MaterialRimResponse.hpp'
    shader=W/'shaders/mesh.frag'
    before={str(p):h(p) for p in (*source,header,shader)}
    target='AzureCharacterRepairTests'
    commands=subprocess.check_output([str(ninja),'-C',str(host),'-t','commands',target],text=True).splitlines()
    objects=[]
    for p in source:
        command,=[line for line in commands if line.endswith(str(p))]
        argv=args(command)
        output=O/(p.name+'.obj')
        for option,x in [('/Fo',output),('/Fd',O/(p.stem+'.pdb'))]:
            at,=[i for i,a in enumerate(argv) if a.startswith(option)]
            argv[at]=option+str(x)
        if not output.is_file():
            execute(argv,p.stem)
        objects.append(output)
    link,=[line for line in commands if 'vs_link_exe' in line and '/out:'+target+'.exe' in line]
    start=link.index(' -- ',link.index(' --manifests '))+4
    end=link.index(' && ',start)
    argv=args(link[start:end].rstrip())
    exe=O/(target+'.exe')
    for i,a in enumerate(argv):
        for prefix,value in (('/out:',exe),('/implib:',O/(target+'.lib')),('/pdb:',O/(target+'.pdb'))):
            if a.lower().startswith(prefix):
                argv[i]=prefix+str(value)
        if a.endswith('CharacterRepairTests.cpp.obj'):
            argv[i]=str(objects[1])
    argv.insert(3,str(objects[0]))
    response=O/'character-repair.rsp'
    response.write_text(subprocess.list2cmdline(argv[1:])+'\n',encoding='ascii')
    execute([argv[0],'@'+str(response)],'character-repair-link')
    sample=W/'assets_public/third_person/material_fixture.gltf'
    assert sample.is_file()
    env=dict(os.environ,PATH=str(host)+os.pathsep+os.environ['PATH'])
    result=subprocess.run([str(exe),str(sample)],cwd=O,env=env,timeout=120,capture_output=True)
    (O/'character-repair-test.log').write_bytes(result.stdout+result.stderr)
    assert result.returncode==0,(result.stdout[-5000:],result.stderr[-3000:])
    assert {str(p):h(p) for p in (*source,header,shader)}==before
    report=dict(status='passed-production-character-repair-with-new-loader',
           source=before,loaderObject=h(objects[0]),testObject=h(objects[1]),
           testBinary=h(exe),fixture=h(sample),fullTestExit=result.returncode)
    write(O/'qualification.json',report)
    print(report,flush=True)


if __name__=='__main__':
    run()

