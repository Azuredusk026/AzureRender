from hashlib import sha256
import json
from pathlib import Path
import runpy
import subprocess
import sys

M=Path(__file__).resolve().parent
W=M.parents[2]
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
O=M/'opaque-skin-main-saturation-contract'
source=r'''
#include "assets/MaterialSurfaceProfile.hpp"
#include <iostream>
using namespace azurerender;
int main() {
    AssetMaterial skin;
    skin.materialClass=AssetMaterialClass::Skin;
    skin.materialProfileVersion=2;
    skin.alphaMode=AssetAlphaMode::Opaque;
    skin.nprDiffuse.present=true;
    skin.materialFeatures=MaterialFeatureNprDiffuse;
    if(packMaterialSurfaceProfile(skin).rows[12][3]!=0.F)return 2;
    skin.nprDiffuse.mainBrightnessSaturation=true;
    try {
        if(packMaterialSurfaceProfile(skin).rows[12][3]!=1.F)return 3;
    } catch(const std::invalid_argument& error) {
        std::cerr << error.what() << '\n';
        return 11;
    }
    skin.alphaMode=AssetAlphaMode::Blend;
    try { (void)packMaterialSurfaceProfile(skin);return 4; }
    catch(const std::invalid_argument& error) {
        if(std::string(error.what()).find("nprDiffuse.mainBrightnessSaturation")==std::string::npos)return 5;
    }
    return 0;
}
'''
mode=sys.argv[1]
assert mode in ('red','green')
O.mkdir(exist_ok=True)
path=O/'test.cpp'
path.write_text(source,encoding='utf8')
toolchain=runpy.run_path(str(R/'face-quality-batch.py'),run_name='skin_saturation_toolchain')
cl=Path('D:/Tools/VS2022BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/cl.exe')
cache=next(line for line in (R/'msaa-release/CMakeCache.txt').read_text(encoding='utf8').splitlines() if line.startswith('Vulkan_INCLUDE_DIR:PATH='))
vk=Path(cache.split('=',1)[1])
assert (vk/'vulkan/vulkan.h').is_file()
include=Path('D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-debug/vcpkg_installed/x64-windows/include')
exe=O/f'test-{mode}.exe'
args=[toolchain['entry'],str(cl),'/nologo','/O2','/MT','/EHsc','/std:c++20','/utf-8','/I'+str(vk),'/I'+str(W/'src'),'/I'+str(include),
      '/Fo'+str(O)+chr(92),'/Fe'+str(exe),str(path),str(W/'src/assets/UnlitTextureLayers.cpp')]
build=subprocess.run(subprocess.list2cmdline(args),shell=True,cwd=O,timeout=65,capture_output=True)
(O/f'{mode}-build.log').write_bytes(build.stdout+build.stderr)
assert build.returncode==0,(build.stdout,build.stderr)
run=subprocess.run([str(exe)],cwd=O,timeout=8,capture_output=True)
record=dict(mode=mode,exitCode=run.returncode,stderr=run.stderr.decode(errors='replace'),header=sha256((W/'src/assets/MaterialRimResponse.hpp').read_bytes()).hexdigest())
(O/f'{mode}.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(record,flush=True)
assert run.returncode==(11 if mode=='red' else 0)


