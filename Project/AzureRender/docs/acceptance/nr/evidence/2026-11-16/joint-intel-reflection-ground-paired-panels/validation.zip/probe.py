"""Read opaque source and stable-covered floor reflection panels in the same frame."""
import json
from pathlib import Path
import runpy
import subprocess
import sys
from zipfile import ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
body=runpy.run_path(str(M/'joint-character-referenced-body.py'),run_name='reflection_storage_camera')
glsl=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='reflection_storage_catalog')
R,B=glsl['R'],glsl['B']
H,art,check,read,write,sha=[glsl[k] for k in ('H','art','check','read','write','sha')]
C=M/'joint-character-referenced-body'
O=M/'joint-intel-reflection-ground-paired-panels'
variants=tuple('mesh_object_clipmap_field'+suffix+'.frag.spv' for suffix in ('','_early','_lighting','_early_lighting'))
glsl['activate_links'].__wrapped__.__globals__['home']=O
assert body['OUT']==C
old='''    vec3 qaColor = beautyColor;
    if (qaIsolationMode == 1) {'''
new='''    vec3 qaColor = beautyColor;
#if !defined(AZURE_OPAQUE_SNAPSHOT)
        // Report sampled raw reflection and confidence from the disputed floor area.
        vec2 probe = AZURE_FRAGMENT_COORD.xy;
        if (qaIsolationMode==0 && camera.screenReflectionTrace.x>1.5 && all(greaterThanEqual(probe,vec2(0)))
            && probe.x<576 && probe.y<72) {
            int lane=int(probe.x)/96;
            int kind=lane%3;
            vec2 anchor=vec2(mod(probe.x,96),probe.y)+vec2(896,lane>=3 ? 160 : 608);
            vec4 sampleValue=sampleComputedScreenReflection(anchor/vec2(textureSize(opaqueSceneColor,0)));
            qaColor=kind==1 ? vec3(clamp(sampleValue.a,0,1))
                    : max(vec3(0),sampleValue.rgb)/(vec3(1)+max(vec3(0),sampleValue.rgb));
            if (kind==2) {
                vec4 surface=texelFetch(overlaySceneDepth,ivec2(anchor),0);
                qaColor=vec3(clamp(surface.r/(32+surface.r),0,1),surface.gb);
            }
            if (lane==3) {
                vec3 source=max(vec3(0),texelFetch(opaqueSceneColor,ivec2(anchor),0).rgb);
                qaColor=source/(vec3(1)+source);
            }
            if (lane==4) {
                vec4 source=texelFetch(opaqueSceneColor,ivec2(anchor),0);
                qaColor=vec3(.12+.7*clamp(source.a/32,0,1));
            }
        }
#endif
    if (qaIsolationMode == 1) {'''


def source_input():
    p=W/'shaders/mesh.frag'
    s=p.read_text(encoding='utf8')
    assert s.count(old)==1
    assert 'layout(rgba32f,binding=37) uniform readonly image2D computedScreenReflection;' in s
    baseline=subprocess.check_output(['git','show','75837a6:Project/AzureRender/shaders/mesh.frag'],cwd=W,encoding='utf8')
    assert s==baseline
    rule={entry['output']:entry['defines'] for entry in read(R/'msaa-release/shader-reload.json')['programs']}
    assert all(set(rule[k])>={'AZURE_IRRADIANCE_CLIPMAP=1','AZURE_PROBE_FIELD=1'} for k in variants)
    return p,s.replace(old,new)


def run():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    budget=check(B,run=M,planned=4_950_000)
    assert budget['allowed'],budget
    basecode,changed=source_input()
    (O/'programs').mkdir(parents=True,exist_ok=True)
    source=O/'mesh.frag'
    source.write_text(changed,encoding='utf8')
    for name in variants:
        H['compile_program'](source,O/'programs'/name,name,diagnostics=O/'compile'/f'{name}.log')
    programs={name:sha(O/'programs'/name) for name in variants}
    core,assets,_=body['prepare']()
    with art.database(B) as c:
        pinned=art.rows(c)[R.name]
    assert pinned['status']=='closed'
    base=M/'character-six-view-inputs/intel-back-detail/frames/frame_000000.png'
    ref=cv2.imread(str(base),cv2.IMREAD_UNCHANGED)
    assert ref.shape==(720,1280,4)
    old_group={}
    for mode in ('native','native-repeat','serial-a'):
        with ZipFile(C/f'intel-{mode}.zip') as z:
            old_group[mode]=ref^np.frombuffer(z.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
    reads={}
    pixels={}
    art.resume(B,R.name)
    try:
        with glsl['activate_links'](programs), body['temporary_descriptor'](assets[1]) as descriptor:
            ground_pair=None
            for label in ('a','b','c','d','e','f'):
                assert check(B,run=M,planned=1_700_000)['allowed']
                kind=f'ground-paired-panels-{label}'
                d=body['capture']('intel',kind,descriptor)
                manifest=read(C/f'intel-{kind}/frames/capture_manifest.json')
                assert manifest['qaIsolation']=='beauty' and manifest['screenReflectionProducer']=='linear-temporal'
                assert manifest['irradianceResourceKind']=='clipmap' and manifest['objectShadowPrepared']
                log=(C/f'intel-{kind}'/'player.log').read_text('utf8',errors='replace')
                assert 'Reflection field: 12 local probes' in log and 'Character texture access: fixed' in log
                with ZipFile(C/f'intel-{kind}.zip') as z:
                    pixels[label]=ref^np.frombuffer(z.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
                m=pixels[label]
                reads[label]=dict(frame=d,againstKnown={
                     k:int(np.any(x[72:]!=m[72:],axis=2).sum()) for k,x in old_group.items()})
                assert min(reads[label]['againstKnown'].values())<5000,reads[label]
                for ix in (0,1,2,3,4,5):
                    panel=m[:72,ix*96:(ix+1)*96]
                    observed=min(np.count_nonzero(np.any(x[:72,ix*96:(ix+1)*96]!=panel,axis=2)) for x in old_group.values())
                    assert observed>2000,(label,ix,observed)
                for key in pixels:
                    if key!=label and not np.array_equal(pixels[key][608:680,896:992],m[608:680,896:992]):
                        ground_pair=(key,label)
                        break
                write(O/'readbacks.json',reads)
                if ground_pair:
                    break
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=90)
    with art.database(B) as c:
        result=art.rows(c)[R.name]
    assert result['status']=='closed' and result['manifestSha256']==pinned['manifestSha256']
    pairs={}
    requested=[(a,b) for i,a in enumerate(pixels) for b in list(pixels)[i+1:]]
    for a,b in requested:
        diff=np.abs(pixels[a].astype(np.int16)-pixels[b].astype(np.int16)).max(axis=2)
        pairs[a+'-'+b]=dict(
            storedRgbChanged=int((diff[:72,:96]>0).sum()),
            storedConfidenceChanged=int((diff[:72,96:192]>0).sum()),
            floorInputSurfaceChanged=int((diff[:72,192:288]>0).sum()),
            upperOpaqueSourceRgbChanged=int((diff[:72,288:384]>0).sum()),
            upperOpaqueSourceAlphaChanged=int((diff[:72,384:480]>0).sum()),
            upperInputSurfaceChanged=int((diff[:72,480:576]>0).sum()),
            realFloorChanged=int((diff[608:680,896:992]>0).sum()),
            realUpperChanged=int((diff[160:232,896:992]>0).sum()),
            otherImageChanged=int((diff[72:]>0).sum()))
    r=dict(status='paired-ground-reflection-and-opaque-source',reads=reads,pairs=pairs,groundPair=ground_pair,
           player=core['player'],programs=programs,source=sha(basecode),diagnosticSource=sha(source))
    write(O/'qualification.json',r)
    print(pairs)


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(sha(source_input()[0]))
    else:
        run()
