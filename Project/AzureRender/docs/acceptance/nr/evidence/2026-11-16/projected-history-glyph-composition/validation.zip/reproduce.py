"""Evaluate a previous-color-only emissive composition on the actual glyph footprint."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import runpy
import struct
import subprocess
import sys

import numpy as np
from PIL import Image

root=Path(__file__).resolve().parent
m=runpy.run_path(str(root/'score-projected-history-draw-masks.py'))
s,b,rgb=m['s'],m['b'],m['rgb']
file=m['read'];digest=lambda x:sha256(x).hexdigest()


def inputs():
    path=m['docs']+'central-glyph-composition.json'
    tracked=subprocess.run(['git','show','HEAD:'+path],cwd=m['museum'],check=True,stdout=subprocess.PIPE).stdout
    info=file(tracked); archive=m['main']/info['run']
    hashes={a['path']:a['sha256'] for a in info['artifacts']}
    read=lambda n: (archive/n).read_bytes()
    def old(n):
        x=read(n);assert digest(x)==hashes[n],n
        return x
    event='event-10480'
    geometry=np.frombuffer(old(f'{event}/post-vertices-0.bin'),'<f4').reshape(-1,23)
    indices=np.frombuffer(old(f'{event}/post-indices-0.bin'),'<u2').reshape(-1,3)
    camera=np.frombuffer(old(f'{event}/ps-cb0.bin'),'<f4').reshape(-1,4)
    profile=file(old('central-glyph-receipt.json'))
    docs=file(old('runtime-inputs.json')); texture={r['resource']:r for r in docs['textures']}
    images=[]
    for index,row in enumerate(profile['textures']):
        t=texture[row['resource']]
        levels=[]
        for mip,f in enumerate(t['files']):
            w,h=max(1,t['width']>>mip),max(1,t['height']>>mip)
            header=bytearray(read(f'full-candidate/captured-central-glyph/10480-{index}.dds')[:148])
            struct.pack_into('<II',header,12,h,w); struct.pack_into('<I',header,28,1)
            a=np.asarray(Image.open(BytesIO(bytes(header)+old('native-mips/'+f['file']))).convert('RGBA')).astype('f8')/255
            a[:,:,:3]=np.where(a[:,:,:3]<=.04045,a[:,:,:3]/12.92,((a[:,:,:3]+.055)/1.055)**2.4)
            levels.append(a)
        images.append(levels)
    return geometry,indices,camera,profile,images,file(old('central-pixel-history.json')),digest(tracked)


def precompute(geometry,indices):
    for v in geometry[indices]:
        screen=(v[:,:2]/v[:,3,None]*.5+.5)*[2560,1440]
        inv=np.linalg.inv(np.vstack((screen.T,np.ones(3)))).T
        yield (v,inv,1/v[:,3])


def shade(scene, xy, prim):
    vs,iv,iw=scene['prims'][prim]
    x,y=xy.T
    one=np.ones(len(x))
    def interpolate(xp,yp):
        b=np.stack((xp,yp,one),axis=-1)@iv
        w=b*iw
        return w@vs/w.sum(axis=-1,keepdims=True), b
    pc,bar=interpolate(x+.5,y+.5)
    left=x//2*2+.5
    top=(y+1)//2*2-.5
    vx0,_=interpolate(left,y+.5);vx1,_=interpolate(left+1,y+.5)
    vy0,_=interpolate(x+.5,top);vy1,_=interpolate(x+.5,top+1)
    samples=[]
    for (a,b),levels,t in zip(((4,6),(10,12),(8,10)),scene['images'],scene['profile']['textures'],strict=True):
        h,w=levels[0].shape[:2]
        rho=np.maximum(np.linalg.norm((vx1[:,a:b]-vx0[:,a:b])*[w,h],axis=-1),
                       np.linalg.norm((vy1[:,a:b]-vy0[:,a:b])*[w,h],axis=-1))
        lod=np.floor(np.log2(np.maximum(rho,1e-9))+t['mipBias']+.5).clip(0,len(levels)-1).astype(int)
        rgba=np.zeros((len(x),4))
        for i,z in enumerate(levels):
            m=lod==i
            if not m.any():continue
            hh,ww=z.shape[:2]
            u=pc[m,a:b]*[ww,hh]-.5
            ij=np.floor(u).astype(int); ix,iy=ij.T
            frac=u-ij; fx,fy=frac.T
            rgba[m]=(1-fy[:,None])*((1-fx[:,None])*z[iy%hh,ix%ww]+fx[:,None]*z[iy%hh,(ix+1)%ww])+fy[:,None]*(
              (1-fx[:,None])*z[(iy+1)%hh,ix%ww]+fx[:,None]*z[(iy+1)%hh,(ix+1)%ww])
        samples.append(rgba)
    depths=bar@(vs[:,2]/vs[:,3])
    q=np.stack(((x+.5)/1280-1,1-(1439-y+.5)/720,depths,one),axis=-1)
    cam=scene['camera']
    world=q@cam[24:28]
    view_z=np.abs((world[:,:3]/world[:,3:4])@cam[:3,2]+cam[3,2])
    p=scene['profile']['profile']; n,f=(p['viewDepthFade'][k] for k in ('near','far'))
    fade=((view_z-n[0])/(n[1]-n[0])).clip(0,1)*((f[1]-view_z)/(f[1]-f[0])).clip(0,1)
    a=samples[0][:,0]*samples[2][:,0]*fade
    c=np.asarray(p['tint'][:3])+samples[1][:,:3]*p['blendTint'][:3]
    c+=np.maximum(c-p['highlightExpansion']['threshold'],0)*p['highlightExpansion']['gain']
    return np.column_stack((c*a[:,None],a))


def score():
    g,i,cam,profile,tex,history,prov=inputs()
    scene=dict(prims=list(precompute(g,i)),profile=profile,images=tex,camera=cam)
    exact=[]
    for a in history['pixels']:
        if a['target']!=15739:continue
        for e in a['history']:
            if e['event']==10480 and not e['depthTestFailed'] and not e['discarded']:
                inp=np.array([[a['x'],a['finalY']]])
                pred=shade(scene,inp,e['primitive'])[0]
                exact.append(float(np.abs(pred-e['shader']).max()))
    assert len(exact)==5 and max(exact)<=.000671,exact
    reconstructed=g[:,:4].astype('f8')@cam[24:28].astype('f8')
    gprev=g.copy()
    gprev[:,:4]=reconstructed@np.linalg.inv(s['N'])
    chip=lambda v:(v[:,:2]/v[:,3:4]+1)*np.array((1280,720))
    shift=chip(gprev)-chip(g)
    assert np.max(np.abs(shift-(.5,-1/3)))<.001
    prior_cam=cam.copy();prior_cam[24:28]=s['N']
    previous=dict(prims=list(precompute(gprev,i)),profile=profile,images=tex,camera=prior_cam)
    masks,_=m['retained_masks']()
    footprint=masks[10480]
    dep,ids,coords,canonical,conf,trace,colors,receipt=rgb['load']()
    result=dict(status='bounded-glyph-composition-source-oracle', sourceManifestSha256=prov,
                controlCount=len(exact), controlMaximumError=max(exact), previousDepth=ids,
                playerPriorColor=receipt['fullSha256'], cases={},
                priorMinusCurrentCameraShiftPixelRange=[shift.min(axis=0).tolist(),shift.max(axis=0).tolist()],
                scope='Use the current native glyph material and geometry at unique projected primitives, composited only over old Player prior color. Earlier screen projection uses the captured earlier trace camera. Previous material animation phase and final filtering are not measured.')
    for route in ('native','player'):
        pc=canonical[route]
        nc=pc.copy();nc[...,1]=65535-nc[...,1]
        wn,nv,_=s['world_from_history'](nc,dep['native'],s['N'],True)
        wp,pv,_=s['world_from_history'](pc,dep['player'],s['V'],False)
        a,c=(colors[t][route] for t in ('native','player'))
        weight=np.minimum(conf['native'],conf['player'])
        xy=m['local']['inverse_indices'](pc)
        valid=nv & pv & (np.linalg.norm(wn-wp,axis=-1)<=.02) & (weight>0) & footprint[xy[...,1],xy[...,0]]
        valid &= s['coherently_sampled'](s['compressed_rgb'](colors[route][route]),trace[route])
        for w,h in ((1280,720),(2560,1440)):
            valid &= s['stable_indices'](coords[route][...,0],w)&s['stable_indices'](coords[route][...,1],h)
        reports=result['cases'][route]={}
        for roi,region in b['REGIONS'].items():
            cut=lambda v:b['cut'](v,b['local'](region))
            mask=cut(valid)
            if not mask.any():continue
            points=cut(xy)[mask];x,y=points.T
            pt=np.column_stack((x+.5,y+.5,np.ones(len(x))))
            scopes={k:np.stack([np.min(pt@v[1],axis=-1)>.00001 for v in v['prims']],axis=-1)
                    for k,v in (('currentNativeProjection',scene),('priorNativeProjection',previous))}
            unique=np.logical_and.reduce([z.sum(axis=-1)==1 for z in scopes.values()])
            xr,pr=[cut(t)[mask][unique] for t in (a,c)]
            if not len(pr):continue
            luma=lambda color:s['compressed_rgb'](color)@s['weight']
            base=luma(pr)-luma(xr)
            w=cut(weight)[mask][unique]
            reports[roi]=dict(footprintAddressSamples=len(x),uniquePrimitiveSamples=len(pr),
                    baseMedian=float(np.median(base)),baselineMeanWeightedAbsoluteLuma=float(np.abs(base)@w/w.sum()),
                    overshootAbovePoint02Before=int((base>.02).sum()))
            for kind,model in (('currentNativeProjection',scene),('priorNativeProjection',previous)):
                ids=scopes[kind].argmax(axis=-1)
                layer=np.zeros((len(x),4))
                for j in range(i.shape[0]):
                    use=unique&(ids==j)
                    if use.any():
                        layer[use]=shade(model,points[use],j)
                layer=layer[unique]; assert np.all((0<=layer[:,3])&(layer[:,3]<=1))
                expected=layer[:,:3]+pr*(1-layer[:,3:4])
                cand=luma(expected)-luma(xr)
                reports[roi][kind]=dict(positiveSource=int((layer[:,3]>0).sum()),
                    remainingNegativeAbovePoint02=int((cand<-.02).sum()),compositedMedian=float(np.median(cand)),
                    compositedMeanWeightedAbsoluteLuma=float(np.abs(cand)@w/w.sum()),
                    overshootAbovePoint02After=int((cand>.02).sum()))
            print(route,roi,reports[roi])
    (s['floor']/'history-source-glyph-composition-oracle.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    assert sys.argv[1:]==['score']
    score()
