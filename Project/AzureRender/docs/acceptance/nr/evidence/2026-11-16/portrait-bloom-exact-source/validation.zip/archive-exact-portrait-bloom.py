from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

run = Path(__file__).resolve().parent
out = run.parents[2] / 'docs/acceptance/nr/evidence/2026-11-16/portrait-bloom-exact-source'
baseline = run.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
previous = run.parent / '20261114-051420-portrait-native-bloom-footprint-6dd233'
hash_bytes = lambda b: sha256(b).hexdigest()
read = lambda p: json.loads(p.read_bytes())
score = read(run / 'bloom-exact-comparison.json')
receipt = read(run / 'exact-probe-receipts.json')
assert score['status'] == 'qualified-same-camera-source' and receipt['status'] == 'qualified'
assert set(score['devices']) == set(receipt['devices']) == {'nvidia', 'intel'}
for device, row in score['devices'].items():
    for lane in ('low', 'high'):
        image = run / f'exact-{device}-{lane}' / 'frames/frame_000000.png'
        assert hash_bytes(image.read_bytes()) == receipt['devices'][device][lane]
    eye = row['currentPlayer']['eye-left']
    assert eye['peak'] == 90 and eye['overOne'] == {'nvidia': 418, 'intel': 415}[device]
    assert row['losslessBase']['eye-left']['peak'] == {'nvidia': 1, 'intel': 13}[device]
    assert row['nativeFilter']['eye-left']['peak'] == 52
    assert .14 < row['currentBloomAtEye'][2] < .15 and .05 < row['nativeBloomAtEye'][2] < .06
    assert row['nativeFilter']['hair-crown']['overOne'] > 5000
paths = {name: run / name for name in ('bloom-exact-comparison.json', 'exact-probe-receipts.json',
         'compare-exact.py', 'retry-expired-portrait-probes.py', 'float-high.frag', 'float-low.frag',
         Path(__file__).name)}
paths['source/portrait-results.json'] = baseline / 'portrait-results.json'
paths['source/native-math.py'] = previous / 'native-math.py'
paths['source/native-footprint-results.json'] = previous / 'results.json'
staged = {name: path.read_bytes() for name, path in paths.items()}
out.mkdir(parents=True, exist_ok=True)
archive = out / 'validation.zip'
with ZipFile(archive, 'w') as z:
    for name, data in sorted(staged.items()):
        info = ZipInfo(name, (2026, 11, 16, 0, 0, 0))
        info.compress_type = ZIP_DEFLATED
        z.writestr(info, data)
with ZipFile(archive) as z:
    assert z.testzip() is None
    assert {name: z.read(name) for name in z.namelist()} == staged
report = dict(status='measured source; native same-camera output and adoption pending',
              productionBloomChanged=False, affectedEyePoint=[667, 808], comparison=score,
              probe=receipt, archive=dict(sha256=hash_bytes(archive.read_bytes()),
                                           members={name: hash_bytes(data) for name, data in staged.items()}))
(out / 'results.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf8')
print(report['archive']['sha256'])
