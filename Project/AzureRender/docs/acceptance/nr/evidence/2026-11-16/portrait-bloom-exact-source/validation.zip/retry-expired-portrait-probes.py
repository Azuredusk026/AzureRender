"""Retry expired portrait capture requests through the shared lease."""
import json
from pathlib import Path
import subprocess
import sys


run=Path(__file__).resolve().parent
dispatch=Path('D:/Projects/FYP-coordination/tools/dispatch.py')
host='D:/Tools/Python311/python.exe'
capture='D:/Projects/FYP/Project/AzureRender/build/reinstall-environment/venv/Scripts/python.exe'
owner='01a1d0a9-829a-7c11-a7a8-017e743887d9'
task='nr-portrait-float-recover-after-queue-timeout'
read=lambda path:json.loads(path.read_bytes())


def combined():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==run
    for tag in ('nvidia','intel'):
        for lane in ('high','low'):
            subprocess.run([sys.executable,str(run/'probe.py'),tag,lane],check=True,timeout=175)
    receipt=read(run/'exact-probe-receipts.json')
    assert receipt['status']=='qualified'
    subprocess.run([sys.executable,str(run/'compare-exact.py')],check=True,timeout=45)


def queue():
    snapshot=json.loads(subprocess.check_output([host,str(dispatch),'status','--limit','300']))
    held=[*snapshot['pending'],*snapshot['running']]
    assert not any(row['owner']==owner and row['id'] in (701,702) for row in held)
    assert not any(row['owner']==owner and row['task']==task for row in held)
    receipts=run/'exact-probe-receipts.json'
    if receipts.exists() and read(receipts)['status']=='qualified':
        return
    known={row['id']:row for row in snapshot['recent'] if row['owner']==owner}
    assert all(i in known and known[i]['state']=='wait-timeout' for i in (701,702))
    log_name=task+'-'+str(1+len(list(run.glob(task+'-*-queue.log'))))+'-queue.log'
    with (run/log_name).open('xb') as log:
        proc=subprocess.Popen([host,str(dispatch),'run','--build',str(run.parents[1]),'--owner',owner,
            '--task',task,'--run',run.name,'--kind','gpu','--priority','P2','--estimate','130',
            '--wait-timeout','43200','--timeout','520','--command',capture,str(Path(__file__).resolve()),'run'],
            stdin=subprocess.DEVNULL,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
    print(proc.pid,flush=True)


if __name__=='__main__':
    assert sys.argv[1:] in ([],['run'])
    combined() if sys.argv[1:] else queue()

