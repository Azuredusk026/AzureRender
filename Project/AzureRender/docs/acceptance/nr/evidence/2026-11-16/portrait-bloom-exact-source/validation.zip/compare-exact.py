from hashlib import sha256
from pathlib import Path
import json
import runpy

import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
prior=out.parent/'20261114-051420-portrait-native-bloom-footprint-6dd233'
grid=out.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
source=out.parent/'20261114-032805-portrait-eye-bloom-source-dcf1c9'
recovered=out.parent/'20261114-044051-native-bloom-pixel-reconstruction-940538'
composite=out.parent/'20261114-034154-portrait-native-bloom-composition-f3b56a'
case_paths=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261101-043757-material-display-transform-93d6e0/native-final-comparison.json')
read=lambda path:json.loads(path.read_bytes())
receipt=read(out/'results.json')
assert receipt['status']=='qualified'
old=read(prior/'results.json')
scope=read(grid/'portrait-results.json')
ref_path=Path(read(case_paths)['comparisons'][1]['reference'])
assert sha256(ref_path.read_bytes()).hexdigest()==scope['referenceSha256']
math=runpy.run_path(str(prior/'native-math.py'),run_name='bloom_math')
pack,unpack,sample=(math[k] for k in ('pack','unpack','sample'))
rows=math['passes']
assert math['out']==recovered
weight=np.fromfile(composite/'6834-1598-compose-cb1.bin','<f4').reshape(-1,4)[9,0]
def rgb(path):
    with Image.open(path) as im:
        return np.asarray(im.convert('RGB'))
def encode(linear):
    linear=np.clip(linear,0,1)
    srgb=np.where(linear<=.0031308,linear*12.92,1.055*linear**(1/2.4)-.055)
    return np.rint(srgb*255).astype('u1')
def decode(srgb):
    srgb=srgb.astype(np.float32)/255
    return np.where(srgb<=.04045,srgb/12.92,((srgb+.055)/1.055)**2.4)
def assess(candidate,reference,bounds):
    result={}
    for name,record in bounds.items():
        x0,y0,x1,y1=record['bounds']
        error=np.abs(candidate[y0:y1,x0:x1].astype(np.int16)-reference[y0:y1,x0:x1]).max(2)
        y,x=np.unravel_index(int(np.argmax(error)),error.shape)
        result[name]=dict(overOne=int((error>1).sum()),peak=int(error.max()),worstPoint=[int(x+x0),int(y+y0)])
    return result

ref=rgb(ref_path)
report=dict(status='qualified-same-camera-source',reference='same-camera linear fixture with bloom disabled',
            fullNativeReference='different camera and pose',devices={})
for dev,measure in receipt['devices'].items():
    loaded=[]
    for lane in ['high','low']:
        file=out/f'exact-{dev}-{lane}/frames/frame_000000.png'
        assert sha256(file.read_bytes()).hexdigest()==measure[lane]
        loaded.append(rgb(file).astype('<u2'))
    words=(loaded[0]<<8)|loaded[1]
    assert sha256(words.tobytes()).hexdigest()==measure['hdrSha256']
    hdr=words.view('<f2').astype(np.float32)
    w,h=hdr.shape[1],hdr.shape[0]
    res=lambda row,width,height:dict(rows[row],width=width,height=height)
    quantize=lambda value:unpack(pack(value))
    layers=[quantize(math['extract'](res(1410,(w+1)//2,(h+1)//2),hdr,resize=True))]
    for event in (1419,1428,1437,1446,1455,1464,1473,1482):
        high=layers[-1]
        layers.append(quantize(math['downsample'](res(event,(high.shape[1]+1)//2,(high.shape[0]+1)//2),high,resize=True)))
    low=layers.pop()
    for event,high in zip((1491,1500,1509,1518,1527,1536,1545,1554),reversed(layers)):
        low=quantize(math['upsample'](res(event,high.shape[1],high.shape[0]),low,high,resize=True))
    y,x=np.ogrid[:h,:w]
    native=sample(low,(x+.5)*.5-.5,(y+.5)*.5-.5)*weight
    local=decode(rgb(source/f'{dev}-direct-bloom/frames/frame_000000.png'))*.25
    current=rgb(grid/f'portrait-{dev}-frames/frame_000000.png')
    base=encode(hdr)
    estimate=encode(hdr+native)
    bounds=scope['cases'][dev]['regions']
    report['devices'][dev]=dict(nativeBloomAtEye=native[808,667].tolist(),currentBloomAtEye=local[808,667].tolist(),
        priorApproximateBloomAtEye=old['devices'][dev]['nativeCompositeLinear'],point=[667,808],
        losslessBase=assess(base,ref,bounds),nativeFilter=assess(estimate,ref,bounds),
        currentPlayer=assess(current,ref,bounds),localAnalytical=assess(encode(hdr+local),ref,bounds),
        currentToLocalModel=assess(encode(hdr+local),current,bounds))
    print(dev,report['devices'][dev]['nativeBloomAtEye'],flush=True)
(out/'bloom-exact-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
