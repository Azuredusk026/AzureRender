"""Read the original event-950 owners and three sampling inputs per witness."""
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import subprocess
import struct
import sys
import traceback

key = 'AZURE_NR_HAIR_OWNER_TRACE'
root = Path(os.environ[key]).parent if key in os.environ else Path(__file__).resolve().parent
grid = root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
load = lambda p: json.loads(p.read_bytes())
write = lambda p, value: p.write_text(json.dumps(value, indent=2)+'\n', encoding='utf8')
lighting_anchors={
    'pre-stripe-diffuse':(1270,'MUL',16),
    'striped-diffuse':(1277,'MOV',16),
    'main-specular':(1270,'MUL',14),
    'continued-diffuse':(1293,'ADD',16),
    'post-light-loop':(1930,'LT',16),
    'before-environment':(1954,'EQ',1),
}


def trace_hardware_lanes(controller,pipe,shader,target,request,rd):
    sys.path.insert(0,request['utilities'])
    from dxbc_util import checksum,chunks,dest,fbits,imm,inst,instructions,opcode,rebuild,source,words
    raw=bytes(shader.rawBytes)
    assert checksum(raw)==raw[4:20]
    original=pipe.GetShader(rd.ShaderStage.Fragment)
    offsets=[((1439-y)*2560+x)*4 for x,y in request['points']]
    assert len(offsets)==5

    def frame():
        controller.SetFrameEvent(950,True)
        data=bytes(controller.GetTextureData(target,rd.Subresource()))
        assert len(data)==2560*1440*4
        return data

    def shader_with_output(lane,level=None,sentinel=False):
        parts=chunks(raw)
        part,=[i for i,(kind,_) in enumerate(parts) if kind in (b'SHEX',b'SHDR')]
        body=words(parts[part][1]);insert={};replacements=[];end=None;slot_registers={16:9,17:10,18:13};seen=set()
        names={16:'base',17:'layer',18:'normal'}
        anchor=lighting_anchors.get(lane)
        for index,at,op,n in instructions(body):
            if op==opcode('DCL_TEMPS'):
                assert body[at+1]==39
                body[at+1]+=3
            if index==0:assert op==opcode('FTOU')
            if anchor is not None and index is not None and index+118==anchor[0]:
                _,expected,register=anchor
                assert op==opcode(expected), (lane,index,op)
                values=(.125,.25,.5)
                sampling=[imm(fbits(values[c])) if sentinel else source(register,c) for c in range(3)]
                insert[at]=sum((inst('MOV',dest(39,1<<c),incoming) for c,incoming in enumerate(sampling)),[])
            if op==opcode('SAMPLE_B'):
                command=body[at:at+n]
                slot=command[-6]
                if slot not in slot_registers:continue
                assert slot not in seen and command[-2:]==[1,26]
                seen.add(slot)
                if lane not in (names[slot],'alpha'):continue
                operand=1
                while command[operand-1]&0x80000000:operand+=1
                assert command[operand+1]==slot_registers[slot],command
                scratch=39+slot-16
                components=(3,) if lane=='alpha' else range(3)
                insert[at+n]=sum((inst('MOV',dest(scratch,1<<c),source(slot_registers[slot],c)) for c in components),[])
                if level is not None:
                    sample=command[:-3]+imm(fbits(level))
                    sample[0]=(sample[0]&0x80fff800)|opcode('SAMPLE_L')|(len(sample)<<24)
                    replacements.append((at,n,sample))
            if op==opcode('RET'):end=at
        assert seen==slot_registers.keys() and end is not None
        if anchor is not None:
            assert len(insert)==1
            channels=[(39,c) for c in range(3)]
        elif lane=='alpha':
            channels=[(39+c,3) for c in range(3)]
        else:
            selected,=[slot for slot,value in names.items() if value==lane]
            channels=[(39+selected-16,c) for c in range(3)]
        insert[end]=sum((inst('MOV',dest(0,1<<c,True),source(reg,lane_id))
                         for c,(reg,lane_id) in enumerate(channels)),[])
        edits=[*replacements,*((at,0,code) for at,code in insert.items())]
        for at,count,code in sorted(edits,key=lambda edit:edit[:2],reverse=True):
            body[at:at+count]=code
        body[1]=len(body)
        parts[part]=(parts[part][0],struct.pack(f'<{len(body)}I',*body))
        return rebuild(raw,parts)

    baseline=frame()
    output={}
    runs=[(case,None) for case in ('copy','base','layer','normal','alpha')]
    if request.get('hardwareExplicitMips'):
        runs.extend((lane,level) for lane in ('base','layer','normal') for level in range(12))
    if request.get('hardwareLighting'):
        runs.extend((lane,None) for lane in lighting_anchors)
    def replay(code):
        replacement,error=controller.BuildTargetShader('main',rd.ShaderEncoding.DXBC,code,
            rd.ShaderCompileFlags(),rd.ShaderStage.Fragment)
        assert replacement!=rd.ResourceId.Null(),error
        controller.ReplaceResource(original,replacement)
        try:
            return frame()
        finally:
            controller.RemoveReplacement(original)
            controller.FreeTargetResource(replacement)
    read_packed=lambda data:[struct.unpack_from('<I',data,offset)[0] for offset in offsets]
    exact_marker=(12<<6)|(13<<(6+11))|(14<<(5+22))
    for lane,level in runs:
        case=lane if level is None else f'{lane}-{level}'
        if request.get('hardwareExplicitMips') or request.get('hardwareLighting'):
            print('replaying',request['device'],case,flush=True)
        code=raw if case=='copy' else shader_with_output(lane,level)
        data=replay(code)
        record=dict(stageSha256=sha256(data).hexdigest(),shaderSha256=sha256(code).hexdigest(),
                    packed=read_packed(data),sameAsFinalAttachment=data==baseline)
        if case=='copy':
            assert record['sameAsFinalAttachment']
        elif record['sameAsFinalAttachment']:
            assert lane in lighting_anchors,(request['device'],case)
            marker_code=shader_with_output(lane,level,sentinel=True)
            validation=replay(marker_code)
            seen=read_packed(validation)
            assert all(v==exact_marker for v in seen),(request['device'],case,seen,exact_marker)
            record['markerCheck']={'packed':seen,'expected':exact_marker,
                'shaderSha256':sha256(marker_code).hexdigest(),'attachmentSha256':sha256(validation).hexdigest()}
        output[case]=record
    assert frame()==baseline
    return output

def read_original(folder):
    import renderdoc as rd
    request = load(folder/'request.json')
    options = rd.ReplayOptions()
    options.forceGPUVendor = rd.GPUVendor.nVidia if request['device']=='nvidia' else rd.GPUVendor.Intel
    options.forceGPUDeviceID = 0x28e0 if request['device']=='nvidia' else 0xa788
    capture = rd.OpenCaptureFile()
    controller = None
    report = dict(status='failed', device=request['device'], points=[])
    try:
        assert capture.OpenFile(request['native'], '', None)==rd.ResultCode.Succeeded
        code, controller = capture.OpenCapture(options,None)
        assert code==rd.ResultCode.Succeeded and controller, str(code)
        api = controller.GetAPIProperties()
        assert api.vendor==options.forceGPUVendor and api.pipelineType==rd.GraphicsAPI.D3D11 and not api.degraded
        controller.SetFrameEvent(950,True)
        pipe = controller.GetPipelineState()
        shader = pipe.GetShaderReflection(rd.ShaderStage.Fragment)
        assert sha256(bytes(shader.rawBytes)).hexdigest()==request['shader']
        target = pipe.GetOutputTargets()[0].resource
        assert str(target)=='ResourceId::141976'
        report['bindings'] = {shader.readOnlyResources[r.access.index].fixedBindNumber:
            dict(id=str(r.descriptor.resource), format=r.descriptor.format.Name(), mip=r.descriptor.firstMip)
            for r in pipe.GetReadOnlyResources(rd.ShaderStage.Fragment)
            if shader.readOnlyResources[r.access.index].fixedBindNumber in (16,17,18)}
        wanted = {32:('v1',), 33:('r9',), 34:('r10',), 45:('r13',), 1277:('r3','r6','r14')}
        for x,y in request['points']:
            controller.SetFrameEvent(950,True)
            history = controller.PixelHistory(target,x,1439-y,rd.Subresource(),rd.CompType.Typeless)
            event = [h for h in history if h.eventId==950 and not
                     (h.depthTestFailed or h.stencilTestFailed or h.backfaceCulled or h.shaderDiscarded)]
            assert event,(x,y)
            final=event[-1]
            if request.get('hardwareLanes'):
                report['points'].append(dict(point=[x,y],primitive=int(final.primitiveID),
                    successfulFragments=[int(h.primitiveID) for h in event],
                    shaderOutput=list(final.shaderOut.col.floatValue)[:3],
                    originalTarget=list(final.postMod.col.floatValue)[:3]))
                continue
            controller.SetFrameEvent(950,True)
            inputs=rd.DebugPixelInputs()
            inputs.primitive=final.primitiveID
            trace=controller.DebugPixel(x,1439-y,inputs)
            assert trace and trace.debugger,(x,y,inputs.primitive)
            data={}
            current={}
            steps=0
            try:
                while True:
                    batch=controller.ContinueDebug(trace.debugger)
                    if not batch:break
                    for step in batch:
                        for item in step.changes:
                            register=item.after
                            if register.name:
                                current[register.name]=[v if math.isfinite(v) else None for v in list(register.value.f32v)[:4]]
                        instruction=int(step.nextInstruction)
                        if instruction in wanted:
                            data[instruction]={r:current[r] for r in wanted[instruction] if r in current}
                        steps+=1
                    assert steps<20000
            finally:
                controller.FreeTrace(trace)
            assert all(require in data for require in (32,33,34,45)), (data,steps)
            report['points'].append(dict(point=[x,y],primitive=int(final.primitiveID),
                successfulFragments=[int(h.primitiveID) for h in event],samples=data,
                shaderOutput=list(final.shaderOut.col.floatValue)[:3],
                originalTarget=list(final.postMod.col.floatValue)[:3]))
        if request.get('hardwareLanes'):
            controller.SetFrameEvent(950,True)
            report['hardwareLanes']=trace_hardware_lanes(controller,pipe,shader,target,request,rd)
        report['status']='qualified'
    except Exception:
        report['error']=traceback.format_exc()
    finally:
        if controller:controller.Shutdown()
        capture.Shutdown()
        write(folder/'results.json',report)
    os._exit(0 if report['status']=='qualified' else 1)

def launch():
    from hashlib import file_digest
    lock=load(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==root
    assert sys.argv[1:] in ([],['hardware'],['hardware-mips'],['hardware-light'])
    hardware=bool(sys.argv[1:])
    explicit=sys.argv[1:]==['hardware-mips']
    lighting=sys.argv[1:]==['hardware-light']
    job=load(grid/'native-face-masks/request.json')
    with Path(job['native']).open('rb') as stream:assert file_digest(stream,'sha256').hexdigest()==job['captureSha256']
    job['shader']='b84f4d70ba795ada599a0f78ca4f60c6d1efa39f2974e293d2d694e7222e5cee'
    job['hardwareLanes']=hardware
    job['hardwareExplicitMips']=explicit
    job['hardwareLighting']=lighting
    job['utilities']=str(root.parent/'20261112-053111-intel-reference-visibility-sources-5238e2/native-normal-explicit-mips')
    audit=load(root/'hair-native-mask-audit.json')
    assert audit['summary']['capturedPrimitiveMatches']==4
    job['points']=[[1243,342],[1322,263],[1327,287],[1333,312],[1280,195]]
    startup=subprocess.STARTUPINFO()
    startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=0
    errors={}
    tag='hair-native-owner'+('-hardware-mips' if explicit else '-hardware-light' if lighting else '-hardware' if hardware else '')
    for device in ('nvidia','intel'):
        folder=root/f'{tag}-{device}'
        folder.mkdir(exist_ok=True)
        write(folder/'request.json',dict(job,device=device))
        with (folder/'replay.log').open('wb') as log:
            child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__))],
                cwd=folder,env=dict(os.environ,**{key:str(folder)}),stdout=log,stderr=subprocess.STDOUT,
                startupinfo=startup,timeout=400 if explicit else 250)
        result=load(folder/'results.json')
        if child.returncode or result['status']!='qualified':errors[device]=result.get('error',child.returncode)
    assert not errors,errors
    reports={device:load(root/f'{tag}-{device}/results.json') for device in ('nvidia','intel')}
    coverage={tuple(row['display']):{tri['primitive'] for tri in row['snapped']} for row in audit['rows']}
    result=[]
    for index,(n,i) in enumerate(zip(reports['nvidia']['points'],reports['intel']['points'])):
        assert n['point']==i['point']
        expected=coverage[tuple(n['point'])]
        assert n['primitive'] in expected and i['primitive'] in expected, (n,i,expected)
        row=dict(point=n['point'],primitive=[n['primitive'],i['primitive']],
            nativeTargetAbsolute=max(abs(a-b) for a,b in zip(n['originalTarget'],i['originalTarget'])),
        )
        if hardware:
            row['packedLanes']={case:[reports[device]['hardwareLanes'][case]['packed'][index] for device in reports]
                                for case in ('copy','base','layer','normal','alpha')}
            if lighting:
                row['lightingLanes']={case:[reports[device]['hardwareLanes'][case]['packed'][index] for device in reports]
                                      for case in lighting_anchors}
            if explicit:
                lanes=tuple(reports['nvidia']['hardwareLanes'])
                assert lanes==tuple(reports['intel']['hardwareLanes'])
                row['explicitMips']={case:[reports[device]['hardwareLanes'][case]['packed'][index] for device in reports]
                    for case in lanes if '-' in case}
                row['matchingMips']={device:{lane:[level for level in range(12)
                    if data['hardwareLanes'][f'{lane}-{level}']['packed'][index]==data['hardwareLanes'][lane]['packed'][index]]
                    for lane in ('base','layer','normal')} for device,data in reports.items()}
        else:
            row['laneAbsolute']={str(step):max(abs(a-b) for a,b in zip(n['samples'][str(step)][reg],i['samples'][str(step)][reg]))
                                 for step,reg in ((33,'r9'),(34,'r10'),(45,'r13'))}
        result.append(row)
    write(root/f'{tag}-comparison.json',dict(status='qualified-native-ownership',points=result))
    print(json.dumps(result))

if key in os.environ:read_original(Path(os.environ[key]))
elif __name__=='__main__':launch()
