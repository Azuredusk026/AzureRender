"""Verify the capture pose using the active head joint and the skinned face."""
import json
import math
from pathlib import Path
import runpy
import struct
import sys

import numpy as np

root = Path(__file__).resolve().parent
old = root / 'character-six-view-inputs'
out = root / 'character-head-aligned-views'
source = runpy.run_path(str(root/'character-six-view-inputs.py'),run_name='character_views')
read, write, digest = (source[key] for key in ('read','write','digest'))


def unit(vector):
    return vector / np.linalg.norm(vector)


def angle(a,b):
    return math.degrees(math.acos(float(np.clip(np.dot(unit(a),unit(b)),-1,1))))


def projection(values, location, forward, lens=40):
    right = unit(np.cross(forward,[0.,1.,0.]))
    up = np.cross(right,forward)
    rel = values-location
    depth = rel@forward
    assert min(depth)>.2
    return np.column_stack((640+(rel@right)/depth*360/math.tan(math.radians(lens/2)),
                            360-(rel@up)/depth*360/math.tan(math.radians(lens/2))))


def setup():
    command, project, level, scene, actor = source['source_inputs']()
    result = read(old/'results.json')
    assert (digest(project),digest(level),digest(actor)) == (result['project'],result['startupLevel'],result['asset'])
    pose = dict()
    for dev in ('nvidia','intel'):
        for record in result['devices'][dev]:
            p=old/f"{dev}-{record['camera']}"/'runtime.json'
            assert digest(p)==record['runtimeReport']
            sample,=[x for x in read(p)['animations'] if x['node']=='hero']
            pose[dev]=sample
            assert sample==pose['nvidia']
    sample=pose['nvidia']
    assert sample['blend']==1 and sample['clip']==sample['previousClip']==9 and sample['morph']==[0.,0.]
    ev = runpy.run_path(str(root/'score-animated-body-topology-deformation.py'),run_name='verify_head_joint')
    m,bin_data = ev['model'],ev['buffer']
    p=actor.read_bytes()
    length,=struct.unpack_from('<I',p,12)
    assert json.loads(p[20:20+length])==m and p[28+length:28+length+len(bin_data)]==bin_data
    clip=m['animations'][sample['clip']]
    active=ev['evaluate'](ev['sampler'](clip),sample['time'])
    mesh,=[mesh for mesh in m['meshes'] if mesh['name']=='S_actor_laevat_face_01_lod0']
    attrs=mesh['primitives'][0]['attributes']
    get=lambda k: ev['get'](attrs[k])
    xyz, weights, joints = get('POSITION'),get('WEIGHTS_0'),get('JOINTS_0')
    rest=np.column_stack((xyz,np.ones(len(xyz))))
    skinned=np.einsum('nqij,nj,nq->ni',active[joints],rest,weights/weights.sum(1,keepdims=True))[:,:3]
    names={m['nodes'][ident]['name']:i for i,ident in enumerate(ev['joint_map'])}
    face_joint=names['Bip001_Head']
    assert np.max(abs(active[face_joint]-active[names['Face_Head']]))<3e-7
    eye_names=('eyeRtJoint','eyeLfJoint')
    eyes_joints=[names[k] for k in eye_names]
    eye_world=np.einsum('nij,nj->ni',active[eyes_joints],np.linalg.inv(ev['inv'][eyes_joints])[:,:,3])[:,:3]
    rig = source['camera_inputs'](scene,actor)['heroTransform']
    t=math.radians(rig['rotation'][1])
    rotation=np.array([[math.cos(t),0,math.sin(t)],[0,1,0],[-math.sin(t),0,math.cos(t)]])
    world=lambda local: local@rotation.T+rig['translation']
    front=unit(rotation @ active[face_joint,:3,2])
    target=world((skinned.min(0)+skinned.max(0))/2)
    coords=world(skinned)
    eyes=world(eye_world)
    shots=read(old/'camera-inputs.json')['views']
    fixed_forward=np.array(shots['face-front']['forward'])
    corrected={}
    for key,offset in (('head-front',0),('head-three-quarter-left',45),('head-three-quarter-right',-45)):
        rad=math.radians(offset)
        direction=np.array([[math.cos(rad),0,math.sin(rad)],[0,1,0],[-math.sin(rad),0,math.cos(rad)]])@front
        location=target+.62*direction
        direction=-direction
        pixels=projection(coords,location,direction)
        eye_pixels=projection(eyes,location,direction)
        assert pixels.min()>0 and (pixels.max(0)<[1280,720]).all()
        corrected[key]=dict(t=location.tolist(),target=target.tolist(),forward=direction.tolist(),fov=40,
                            faceBoundsPx=[pixels.min(0).tolist(),pixels.max(0).tolist()],
                            projectedEyeCentersPx=eye_pixels.tolist())
    old_alignment={key:angle(-np.array(value['forward']),front) for key,value in shots.items()}
    assert 35<angle(-fixed_forward,front)<41
    assert abs(old_alignment['face-three-quarter-right']-7)<2
    assert angle(-np.array(corrected['head-front']['forward']),front)<1e-5
    return command,dict(oldAngularErrorDegrees=old_alignment,headForward=front.tolist(),headJoint='Bip001_Head',
                        animation=sample,clipName=clip['name'],views=corrected,project=result['project'],
                        startupLevel=result['startupLevel'],asset=result['asset'],player=result['player'])


def capture(device,view):
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and lease['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9' and Path(lease['output'])==root
    command,inputs=setup()
    pose=inputs['views'][view]
    out.mkdir(exist_ok=True)
    source['player_capture'].__globals__['out']=out
    args=read(old/f'{device}-face-front'/'result.json')['command']
    original=dict(zip(args[-8:-7],args[-7:]))
    assert list(original)==['--qa-camera-pose'] and digest(Path(args[0]))==inputs['player']
    p=out/f'{device}-{view}'
    for flag,value in (('--capture-dir',p/'frames'),('--runtime-report',p/'runtime.json')):
        args[args.index(flag)+1]=str(value)
    target=np.array(pose['t'])+pose['forward']
    args[-7:]=[format(v,'.9g') for v in (*pose['t'],*target,pose['fov'])]
    camera=source['player_capture'](device,view,pose,args,dict(runtimeTarget=target.tolist(),**pose))
    sample,=[x for x in read(p/'runtime.json')['animations'] if x['node']=='hero']
    assert sample==inputs['animation']
    assert angle(-np.array(camera['appliedCameraForward']),inputs['headForward'])<(0.01 if view=='head-front' else 46.)
    write(out/'camera-inputs.json',inputs)
    print(device,view,camera['sha256'],pose['projectedEyeCentersPx'])


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(json.dumps(setup()[1]))
    else:
        capture(*sys.argv[1:])
