"""Read the native iris main light before and after saturation."""
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import traceback

KEY='AZURE_NR_D3D_IRIS_MAIN_LIGHT_LANES'
M=Path(os.environ[KEY]).parent if KEY in os.environ else Path(__file__).resolve().parent
out=M/'iris-native-main-light-lanes'
read=lambda p:json.loads(Path(p).read_bytes())
write=lambda p,v:Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
h=lambda b:sha256(b).hexdigest()


def worker():
    import renderdoc as rd
    cfg=read(out/'request.json')
    sys.path.insert(0,cfg['utilities'])
    from dxbc_util import checksum,chunks,dest,imm,inst,instructions,opcode,rebuild,source,words
    write(out/'progress.json',dict(stage='embedded'))

    def compile_lane(raw,kind,lane):
        assert checksum(raw)==raw[4:20]
        parts=chunks(raw)
        section,=[i for i,p in enumerate(parts) if p[0] in (b'SHEX',b'SHDR')]
        program=words(parts[section][1])
        write_at=temp=ret=None
        number=None
        selected=475 if kind=='main-before-saturation' else 485
        for _,at,op,n in instructions(program):
            if number is not None:
                number+=1
                if number==selected:
                    assert op==opcode('MAD') and program[at+1:at+3]==dest(6,7),(selected,op,program[at+1:at+3])
                    write_at=at+n
            if op==opcode('DCL_TEMPS'):
                temp=program[at+1]
                assert temp==30
                program[at+1]+=1
                number=-1
            elif op==opcode('RET'):
                assert ret is None
                ret=at
        assert None not in (write_at,temp,ret)
        register,index,before=(6,lane,write_at)
        a=[]
        for i,(shift,mask) in enumerate(((25,127),(18,127),(12,63))):
            dst=dest(temp,1<<i)
            a+=inst('USHR',dst,source(register,index),imm(shift))
            a+=inst('AND',dst,source(temp,i),imm(mask))
            a+=inst('UTOF',dst,source(temp,i))
        tail=sum((inst('MOV',dest(0,1<<i,True),source(temp,i)) for i in range(3)),[])
        program[ret:ret]=tail
        program[before:before]=a
        program[1]=len(program)
        p=parts[section]
        parts[section]=(p[0],struct.pack('<{}I'.format(len(program)),*program),*p[2:])
        return rebuild(raw,parts)

    def decode(word):
        lanes=[]
        for shift,bits in ((0,6),(11,6),(22,5)):
            value=(word>>shift)&((1<<(bits+5))-1)
            exponent=value>>bits
            mantissa=value&((1<<bits)-1)
            number=math.ldexp(mantissa,-14-bits) if exponent==0 else math.ldexp(1+mantissa/(1<<bits),exponent-15)
            assert number==int(number)
            lanes.append(int(number))
        assert all(lo<=c<=hi for c,(lo,hi) in zip(lanes,((0,127),(0,127),(0,63))))
        raw=(lanes[0]<<25)|(lanes[1]<<18)|(lanes[2]<<12)
        return [raw,struct.unpack('<f',struct.pack('<I',raw))[0]]

    cap=rd.OpenCaptureFile()
    result=dict(status='failed',request=h((out/'request.json').read_bytes()),devices={})
    try:
        points=list(struct.iter_unpack('<II',Path(cfg['points']).read_bytes()))
        assert len(points)==255
        pos=[((1439-y)*2560+x)*4 for x,y in points]
        assert cap.OpenFile(cfg['capture'],'',None)==rd.ResultCode.Succeeded
        for name,vendor,device in [('nvidia',rd.GPUVendor.nVidia,0x28e0),('intel',rd.GPUVendor.Intel,0xa788)]:
            opts=rd.ReplayOptions()
            opts.forceGPUVendor=vendor
            opts.forceGPUDeviceID=device
            status,c=cap.OpenCapture(opts,None)
            assert status==rd.ResultCode.Succeeded and c
            try:
                api=c.GetAPIProperties()
                assert api.pipelineType==rd.GraphicsAPI.D3D11 and api.vendor==vendor and not api.degraded
                c.SetFrameEvent(846,True)
                pipe=c.GetPipelineState()
                r=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
                dxbc=bytes(r.rawBytes)
                assert h(dxbc)==cfg['pixelShaderSha256']
                original=pipe.GetShader(rd.ShaderStage.Fragment)
                target=pipe.GetOutputTargets()[0].resource
                assert str(target)=='ResourceId::141976'
                def pixels():
                    c.SetFrameEvent(846,True)
                    d=bytes(c.GetTextureData(target,rd.Subresource()))
                    assert len(d)==2560*1440*4
                    return d
                base=pixels()
                records={}
                for kind,i in [('copy',0),('main-before-saturation',2),('main-after-saturation',2)]:
                    label=f'{kind}-{i}'
                    write(out/'progress.json',dict(adapter=name,lane=label))
                    code=dxbc if kind=='copy' else compile_lane(dxbc,kind,i)
                    p,err=c.BuildTargetShader('main',rd.ShaderEncoding.DXBC,code,rd.ShaderCompileFlags(),rd.ShaderStage.Fragment)
                    assert p!=rd.ResourceId.Null(),err
                    c.ReplaceResource(original,p)
                    try:
                        data=pixels()
                    finally:
                        c.RemoveReplacement(original)
                        c.FreeTargetResource(p)
                    assert (data==base)==(kind=='copy')
                    record=dict(shader=h(code),target=h(data))
                    if kind!='copy':
                        record['values']=[decode(struct.unpack_from('<I',data,j)[0]) for j in pos]
                        (out/f'{name}-{label}.dxbc').write_bytes(code)
                    records[label]=record
                assert h(pixels())==h(base)
                result['devices'][name]=dict(lanes=records,originalRestored=True)
            finally:
                c.Shutdown()
        result.update(status='qualified-dual-device-native-iris-main-light',points=points)
    except BaseException:
        result['error']=traceback.format_exc()
    finally:
        cap.Shutdown()
        write(out/'results.json',result)
    os._exit(int(result['status']=='failed'))


def launch():
    from hashlib import file_digest
    sys.path.insert(0,str(M.parents[2]/'tools'))
    from artifact_budget import check
    t=read('D:/Projects/FYP-coordination/resources/current.json')
    assert t['state']=='held' and Path(t['output'])==M
    assert check(M.parents[1],run=M,planned=465_000)['allowed']
    cfg=read(M/'iris-native-matcap-footprint/request.json')
    with Path(cfg['capture']).open('rb') as f:
        assert file_digest(f,'sha256').hexdigest()==cfg['captureSha256']
    out.mkdir(exist_ok=True)
    cfg['output']=str(out)
    write(out/'request.json',cfg)
    assert Path(cfg['points']).stat().st_size==8*255
    startup=subprocess.STARTUPINFO()
    startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=0
    with (out/'replay.log').open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=out,env=dict(os.environ,**{KEY:str(out)}),stdout=log,stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,timeout=300,startupinfo=startup)
    r=read(out/'results.json')
    assert child.returncode==0 and r['status']=='qualified-dual-device-native-iris-main-light',r.get('error')
    print(len(r['points']),list(r['devices']))


if KEY in os.environ:
    worker()
elif __name__=='__main__':
    launch()
