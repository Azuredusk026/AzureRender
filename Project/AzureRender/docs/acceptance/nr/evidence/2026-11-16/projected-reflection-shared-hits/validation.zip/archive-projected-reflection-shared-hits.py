"""Archive the independent geometric and shared-hit parts of the raw error."""
from hashlib import sha256
import io
import json
from pathlib import Path
import zipfile

run = Path(__file__).resolve().parent
work = run.parents[2]
read = lambda path: json.loads(path.read_bytes())
preview = run / 'native-floor-reflection-inputs/aligned-depth-preview.json'
source = read(preview)
assert source['status'] == 'provisional-later-native-depth'
assert (source['nativeEvent'], source['nativeLaterSameResourceEvent'], source['playerEvent']) == (8702, 8811, 21668)
assert source['cameraProjectionMaximumAbsolute'] < 2e-7
regions = ('centerFloor', 'cyanRing', 'archivedFloor')
rows = {}
for name in regions:
    row = source['regions'][name]
    aligned = row['matchedViewDepth']['0.02']
    residual = row['confidenceWeightedTraceResidual']
    split = residual['subregions']
    assert abs(sum(v['errorShare'] for v in split.values()) - 1) < 1e-12
    assert sum(v['samples'] for v in split.values()) == aligned['samples']
    assert split['bothHits']['samples'] == aligned['bothHit']
    assert split['nativeOnly']['samples'] == aligned['nativeOnlyHit']
    assert split['playerOnly']['samples'] == aligned['playerOnlyHit']
    assert split['neither']['absoluteLuma'] == 0
    assert split['bothHits']['errorShare'] > .75
    rows[name] = dict(halfRectangle=row['halfRectangle'], depthAlignedSamples=aligned['samples'],
                      bothHitCompressedLuma=row['traceLuma'], confidenceWeightedTraceResidual=residual)

names = (preview, run / 'score-native-floor-reflection-inputs.py', Path(__file__))
archive = io.BytesIO()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for path in names:
        entry = zipfile.ZipInfo(path.name, (2026, 11, 16, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(entry, path.read_bytes())
outputs = work / 'docs/acceptance/nr/evidence/2026-11-16/projected-reflection-shared-hits'
outputs.mkdir(exist_ok=True)
bundle = archive.getvalue()
(outputs / 'validation.zip').write_bytes(bundle)
result = dict(status='retained-trace-comparison', nativeGameFrame=3534, nativeEvent=source['nativeEvent'],
              nativeDepthEvent=source['nativeLaterSameResourceEvent'], playerEvent=source['playerEvent'],
              inputDepthAlignmentMeters=.02, resolvedAttachmentRows='native rows reversed to display',
              units='absolute Rec.709 luma of compressed RGB, multiplied by confidence',
              scope='Raw trace, prior to level generation, temporal filtering and final composition',
              nativeDepthSha256=source['nativeLaterDepthSha256'], nativeOutputSha256=source['nativeRayOutputSha256'],
              playerAttachmentSha256=source['playerAttachmentSha256'], regions=rows,
              validationZip=dict(bytes=len(bundle), sha256=sha256(bundle).hexdigest()))
(outputs / 'results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(result['validationZip'])
