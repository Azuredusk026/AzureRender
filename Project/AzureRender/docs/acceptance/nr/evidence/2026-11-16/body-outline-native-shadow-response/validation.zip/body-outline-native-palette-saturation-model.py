"""Validate the shadow saturation term against original body outline registers."""
from hashlib import sha256
import json
from pathlib import Path

import numpy as np


run=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
source=read(run/'trace-body-outline-shadow-lut-source.json')
assert source['status']=='qualified' and len(source['points'])==4
luma=np.asarray([.21267290413379669,.7151522040367126,.07217500358819962])
saturate=lambda color,amount:(color@luma)+(color-color@luma)*amount
mix=lambda a,b,t:a+(b-a)*t


def diffuse_color(lit,shadow,ramp,light,ao,shadow_mix,visibility):
    low=mix(saturate(.65*shadow,1.2),shadow,shadow_mix)
    combined=mix(low,lit,light)
    white_range=ramp.max()-ramp.min()
    tinted=combined*(1-white_range+ramp*white_range)
    outdoors=tinted*np.clip((combined@luma)/max(tinted@luma,.001),0,1.5)
    return mix(mix(shadow,saturate(lit,1.2),ao),outdoors,visibility)


rows=[]
for row in source['points']:
    original=run/row['file']
    current={}
    snapshots={}
    for instruction,registers in read(original):
        current.update(registers)
        if instruction in (314,324,331,342,344,363,380,381,418):
            snapshots[instruction]={key:np.asarray(value,dtype=float) for key,value in current.items()}
        if instruction==418:break
    lit=snapshots[314]['r10'][:3]
    shadow=snapshots[314]['r13'][[0,2,3]]
    ramp=snapshots[324]['r15'][:3]
    weights=[snapshots[331]['r8'][2],snapshots[344]['r13'][1],snapshots[342]['r9'][3],snapshots[363]['r3'][3]]
    expected=snapshots[363]['r13'][[0,2,3]]
    baseline=diffuse_color(lit,shadow,ramp,*weights)
    alternate=diffuse_color(lit,saturate(shadow,1.4),ramp,*weights)
    incident=snapshots[380]['r6'][:3]
    lit_stage=lambda color:saturate(color*incident,1+np.clip((color*incident)@luma-.5,0,.5)**2)
    assembled=lit_stage(baseline)
    alternate_assembled=lit_stage(alternate)
    expected_stage=snapshots[418]['r6'][:3]
    raw_error=float(np.abs(baseline-expected).max())
    light_error=float(np.abs(assembled-expected_stage).max())
    assert raw_error<2e-6 and light_error<2e-6,(row['point'],raw_error,light_error,weights)
    rows.append(dict(point=row['point'],source=sha256(original.read_bytes()).hexdigest(),
                    capturedPayload=source['shadowLookup']['sha256'],shadow=shadow.tolist(),weights=weights,
                    responseError=raw_error,litStageError=light_error,
                    extraSaturationEffect=(alternate_assembled-assembled).tolist()))
result=dict(status='measured-native-outline-shadow-response-control',sourceEvent=1018,
    supplementalSaturation=1.4,contribution='ambient-plus-primary-diffuse-before-local-light',witnesses=rows)
(run/'body-outline-native-palette-saturation-model.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print([(row['point'],row['extraSaturationEffect']) for row in rows],flush=True)

