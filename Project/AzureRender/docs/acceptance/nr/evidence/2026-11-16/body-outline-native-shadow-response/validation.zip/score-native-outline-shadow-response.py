"""Separate the measured outline LUT response from full-frame acceptance."""
from hashlib import file_digest
import json
from pathlib import Path
import runpy

import numpy as np


root = Path(__file__).resolve().parent
grid = root.parent / '20261112-231945-projected-hair-reference-grid-4b775d'
geometry = root.parent / '20261114-150229-face-native-geometry-mask-sampling-d5d93e'
receiver = root.parent / '20261114-135148-face-receiver-diagnostics-7509b1'
run = root / 'body-outline-native-shadow-lut-player'
ordered = geometry / 'body-outline-before-transparent-cloth'
read = lambda path: json.loads(path.read_bytes())
score = runpy.run_path(str(grid / 'static-quality.py'))


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


physical = read(run / 'results.json')
source = read(root / 'body-outline-native-palette-saturation-model.json')
order = read(ordered / 'results.json')
points = receiver / 'body-visible-ownership-points.bin'
assert source['sourceEvent'] == 1018 and len(source['witnesses']) == 4
assert max(w['litStageError'] for w in source['witnesses']) < 2e-6
assert all(w['capturedPayload'] == physical['source']['sha256'] for w in source['witnesses'])
assert physical['reference'] == sha(score['reference_path'])
reference = score['image'](score['reference_path']).astype(np.int16)
x, y, owner = np.fromfile(points, '<u2').reshape(-1, 3).T
coverage = np.zeros(reference.shape[:2], bool)
coverage[y, x] = True
assert int(coverage.sum()) == 1184 and int((owner == 1018).sum()) == 1112


def scores(difference):
    return dict(overOne=int((difference > 1).sum()), overEight=int((difference > 8).sum()),
                peak=int(difference.max()))


devices = {}
for device, modes in physical['devices'].items():
    folder = root / f'body-outline-beauty-transparent-highlights-captured-origin-{device}'
    before = folder / 'frames/frame_000000.png'
    after = run / f'native-shadow-{device}/frames/frame_000000.png'
    order_frame = ordered / device / 'frames/frame_000000.png'
    assert sha(before) == read(folder / 'results.json')['frameSha256'] == order['devices'][device]['original']
    assert sha(after) == modes['native-shadow']['frame']
    assert sha(order_frame) == order['devices'][device]['frame']
    a, b, c = (score['image'](path).astype(np.int16) for path in (before, after, order_frame))
    orig, candidate, reorder = (np.abs(image - reference).max(2) for image in (a, b, c))
    selection = owner == 1018
    assert np.array_equal(a[y, x][selection], c[y, x][selection])
    previous, current = (image[y, x][selection] for image in (orig, candidate))
    uncompensated = (orig <= 1) & (candidate > 1)
    outside = ~coverage & np.any(a != b, axis=2)
    def examine(mask):
        yy, xx = np.where(mask)
        return [dict(xy=[int(px), int(py)], before=a[py, px].tolist(), candidate=b[py, px].tolist(),
                     reference=reference[py, px].tolist(), order=c[py, px].tolist()) for py, px in zip(yy, xx)]
    assert int(uncompensated.sum()) == modes['native-shadow']['newOverOne']
    assert int(outside.sum()) == modes['native-shadow']['outside']
    largest = np.zeros(coverage.shape, bool)
    largest[y[selection], x[selection]] = current == current.max()
    devices[device] = dict(attachment=modes['native-shadow']['frame'], baseline=sha(before),
        order=sha(order_frame), source=modes['native-shadow']['palette'], original=scores(previous),
        candidate=scores(current), unchangedOrderForOutline=True,
        newOverOne=examine(uncompensated), outsideOwner=examine(outside), peak=examine(largest),
        recoveredOverOne=int(((previous > 1) & (current <= 1)).sum()),
        newPeakOverEight=int(((previous <= 8) & (current > 8)).sum()),
        strictPass=bool(max(current) <= 1 and not outside.any() and not uncompensated.any()))

result = dict(status='strict-gate-open', deviceOrder=['nvidia', 'intel'], sourceEvent=1018,
    originalTrace=sha(root / 'trace-body-outline-shadow-lut-source.json'),
    shadowPayload=physical['source']['sha256'], ownership=sha(points), reference=physical['reference'],
    shaderModel=sha(root / 'body-outline-native-palette-saturation-model.json'), player=physical['player'],
    retainedSamples=1112, originalVerticesUnchanged=True, devices=devices)
destination = run / 'strict-comparison.json'
destination.write_text(json.dumps(result, indent=2) + '\n', encoding='utf8')
for device, row in devices.items():
    print(device, row['original'], row['candidate'], f"new={len(row['newOverOne'])}",
          f"outside={len(row['outsideOwner'])}", row['peak'])
