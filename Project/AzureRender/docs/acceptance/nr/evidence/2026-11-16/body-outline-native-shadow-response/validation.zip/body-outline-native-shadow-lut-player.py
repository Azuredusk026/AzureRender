"""Exercise the native outline shadow color lookup through the public material."""
from contextlib import ExitStack
from hashlib import file_digest
from io import BytesIO
import json
import os
from pathlib import Path
import runpy
import struct
import subprocess
import sys
from uuid import NAMESPACE_URL,uuid5

import numpy as np
from PIL import Image


root=Path(__file__).resolve().parent
grid=root.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
fixture=grid/'iris-overlay-geometry-project'
stage=root/'body-outline-native-shadow-lut-player'
retained=root/'msaa-release'
helper=runpy.run_path(str(grid/'iris-production-frozen-recovery.py'))
score=runpy.run_path(str(grid/'static-quality.py'))
read=lambda p:json.loads(p.read_bytes())
name='body-native-lit-outline-blend-depth'
character='body-native-lit-outline-production'
transform='body-outline-native-shadow-lut'
player_digest='1a30d925a674ddb1d95876cb80181106a0217e12a7228a35b5980b134954cb69'


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def write(path,data):
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')


def source_texture():
    receipt=root/'trace-body-outline-shadow-lut-source.json'
    if not receipt.is_file() or read(receipt)['status']!='qualified':
        subprocess.run([sys.executable,str(root/'trace-body-outline-source.py'),'shadow-lut'],check=True,timeout=275)
    result=read(receipt)
    assert result['status']=='qualified'
    lookup=result['shadowLookup']
    source=root/lookup['file']
    assert digest(source)==lookup['sha256']
    native=source.read_bytes()
    width,height=lookup['dimensions']
    assert (width,height,lookup['format'])==(1024,32,'BC7_SRGB')
    header=b'DDS '+struct.pack('<31I',124,0x81007,height,width,len(native),0,1,*([0]*11),32,4,0x30315844,
                               0,0,0,0,0,0x1000,0,0,0,0)
    path=stage/(transform+'.png')
    with Image.open(BytesIO(header+struct.pack('<5I',99,3,0,1,0)+native)) as image:
        image.convert('RGBA').save(path)
    asset=str(uuid5(NAMESPACE_URL,'azurerender/captured-outline-10401/lut-t12'))
    write(path.with_suffix('.png.azmeta'),dict(schemaVersion=1,id=asset,dependencies=[],settings={}))
    return path,asset,lookup


def palette_identity(doc,profile,lookup):
    record=profile['shadowColorLut']
    assert record['schemaVersion']==1 and record['flipV'] is False
    source=doc['surface']['textures'][record['texture']]['source']
    asset=doc['textures'][str(source)]
    assert asset['usage']=='albedo'
    matches=[file for file in (fixture/'materials').glob('*.dds.azmeta')
             if read(file)['id']==asset['asset']]
    metadata,=matches
    texture=metadata.with_suffix('')
    raw=texture.read_bytes()
    assert raw[:4]==b'DDS ' and raw[84:88]==b'DX10' and struct.unpack_from('<I',raw,128)[0]==99
    assert file_digest(BytesIO(raw[148:]),'sha256').hexdigest()==lookup['sha256']
    return dict(asset=asset['asset'],file=texture.name,ddsSha256=digest(texture),
                payloadSha256=lookup['sha256'],flipV=record['flipV'],nativeResource=lookup['resource'])


def render(device,mode,lookup):
    origin=root/f'body-outline-beauty-transparent-highlights-captured-origin-{device}'
    baseline=read(origin/'results.json')
    material=origin/f'{name}.azurematerial'
    assert digest(material)==baseline['materialSha256']
    doc=read(material)
    profile=doc['surface']['materials'][0]['extras']['azureRenderMaterial']
    npr=profile['nprDiffuse']
    assert npr['rimOrigin']['node']=='CapturedBodyOrigin' and abs(npr['shadowSaturation']-1.4)<1e-6
    palette=palette_identity(doc,profile,lookup)
    assert mode=='native-shadow'
    npr.pop('shadowSaturation')
    output=stage/f'{mode}-{device}'
    output.mkdir(exist_ok=True)
    settings=output/material.name
    write(settings,doc)
    pins={
        fixture/'character'/f'{character}.gltf':root/f'{character}-ordered.gltf',
        fixture/'materials'/settings.name:settings,
        fixture/'materials'/f'{settings.name}.azmeta':root/f'{settings.name}.azmeta',
        fixture/'scene'/f'{name}.azurelevel':root/f'{name}.azurelevel',
        fixture/f'{name}.azureproject':root/f'{name}.azureproject',
    }
    for dest in list(pins):
        filename=dest.name+'.azmeta'
        if not dest.with_name(filename).exists() and (root/filename).is_file():
            pins[dest.with_name(filename)]=root/filename
    cmd=read(origin/'command.json')
    assert Path(cmd[0])==retained/'AzurePlayer.exe' and baseline['playerSha256']==player_digest
    for option,value in (('--capture-dir',output/'frames'),('--runtime-report',output/'runtime.json')):
        cmd[cmd.index(option)+1]=str(value)
    with ExitStack() as cleanup:
        for dest,source in pins.items():
            assert not dest.exists(),dest
            dest.hardlink_to(source)
            cleanup.callback(dest.unlink)
            if dest.suffix in ('.azureproject','.azurelevel'):
                meta=dest.with_name(dest.name+'.azmeta')
                if meta not in pins and not meta.exists():
                    cleanup.callback(meta.unlink,missing_ok=True)
        result=helper['invoke'](device,cmd,output)/'frame_000000.png'
    assert result.is_file()
    return result,settings,palette


def main():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==root
    programs=runpy.run_path(str(root/'face-quality-candidate-catalog.py'))
    fingerprints=programs['retained_catalog'](root)
    programs['restore'](fingerprints)
    assert {p.name:programs['sha'](p) for p in (retained/'shaders').glob('*.spv')}==fingerprints
    sys.path.insert(0,str(root.parents[2]/'tools'))
    from artifact_budget import check
    budget=check(root.parents[1],run=root,planned=12_000_000)
    assert budget['allowed'],budget
    assert digest(retained/'AzurePlayer.exe')==player_digest
    assert read(root/'body-outline-native-rim-origin-results.json')['status']=='measured-captured-rim-origin'
    stage.mkdir(exist_ok=True)
    texture,_,binding=source_texture()
    reference=score['image'](score['reference_path']).astype(np.int16)
    control=root.parent/'20261114-135148-face-receiver-diagnostics-7509b1/body-visible-ownership-points.bin'
    x,y,owners=np.fromfile(control,'<u2').reshape(-1,3).T
    cover=np.zeros(reference.shape[:2],bool)
    cover[y,x]=True
    retained_owner=owners==1018
    assert int(cover.sum())==1184 and int(retained_owner.sum())==1112
    devices={}
    for device in ('nvidia','intel'):
        folder=root/f'body-outline-beauty-transparent-highlights-captured-origin-{device}'
        original=folder/'frames/frame_000000.png'
        assert digest(original)==read(folder/'results.json')['frameSha256']
        base=score['image'](original).astype(np.int16)
        before=np.abs(base-reference).max(2)
        variants={}
        for mode in ('native-shadow',):
            path,material,palette=render(device,mode,binding)
            actual=score['image'](path).astype(np.int16)
            after=np.abs(actual-reference).max(2)
            changed=np.any(actual!=base,axis=2)
            region=after[y,x][retained_owner]
            stats=dict(frame=digest(path),material=digest(material),palette=palette,outside=int(changed[~cover].sum()),
                       newOverOne=int(((before<=1)&(after>1)).sum()),overOne=int((region>1).sum()),
                       overEight=int((region>8).sum()),peak=int(region.max()),
                       medianSignedRgb=np.median((actual-reference)[y,x][retained_owner],axis=0).tolist())
            variants[mode]=stats
            print(device,mode,json.dumps(stats),flush=True)
        devices[device]=variants
    write(stage/'results.json',dict(status='measured-native-outline-shadow-lookup',player=player_digest,
        source=binding,decodedImage=digest(texture),reference=digest(score['reference_path']),devices=devices))


if __name__=='__main__':main()
