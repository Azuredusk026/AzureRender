"""Retain replay inputs and the strict comparison of the two Player runs."""
from hashlib import file_digest, sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


root = Path(__file__).resolve().parent
run = root / 'body-outline-native-shadow-lut-player'
target = root.parents[2] / 'docs/acceptance/nr/evidence/2026-11-16/body-outline-native-shadow-response'
read = lambda path: json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


source = read(root / 'trace-body-outline-shadow-lut-source.json')
capture = read(run / 'results.json')
actual = read(run / 'strict-comparison.json')
model = read(root / 'body-outline-native-palette-saturation-model.json')
queue = root / 'nr-body-outline-native-shadow-saturation-two-adapters-host-retry-1208.log'
queue_result = read(queue)
assert queue_result['id'] == 1244 and queue_result['exit_code'] == 0 and queue_result['state'] == 'succeeded'
assert source['status'] == 'qualified' and actual['status'] == 'strict-gate-open'
assert actual['originalTrace'] == sha(root / 'trace-body-outline-shadow-lut-source.json')
assert actual['shaderModel'] == sha(root / 'body-outline-native-palette-saturation-model.json')
assert source['shadowLookup']['sha256'] == actual['shadowPayload']
assert all(w['litStageError'] <= 2.5e-8 for w in model['witnesses'])
files = {'dispatch.json': queue, 'physical-results.json': run / 'results.json',
         'native-lookup/' + source['shadowLookup']['file']: root / source['shadowLookup']['file']}
assert sha(files['native-lookup/' + source['shadowLookup']['file']]) == actual['shadowPayload']
for name in ('trace-body-outline-shadow-lut-source.json', 'trace-body-outline-source.py',
             'body-outline-native-palette-saturation-model.py', 'body-outline-native-palette-saturation-model.json',
             'body-outline-native-shadow-lut-player.py', 'score-native-outline-shadow-response.py',
             Path(__file__).name):
    files[name] = root / name
for point in source['points']:
    original = root / point['file']
    assert sha(original) == point['sha256']
    files['native-traces/' + original.name] = original
assert len(source['points']) == 4

for device, expected_vendor in (('nvidia', 0x10de), ('intel', 0x8086)):
    candidate = run / f'native-shadow-{device}'
    record = capture['devices'][device]['native-shadow']
    assert sha(candidate / 'frames/frame_000000.png') == record['frame'] == actual['devices'][device]['attachment']
    material = candidate / 'body-native-lit-outline-blend-depth.azurematerial'
    assert sha(material) == record['material']
    profile = read(material)['surface']['materials'][0]['extras']['azureRenderMaterial']
    assert 'shadowSaturation' not in profile['nprDiffuse'] and not profile['shadowColorLut']['flipV']
    gpu = read(candidate / 'frames/gpu_capabilities.json')
    assert gpu['vendor_id'] == expected_vendor
    actual['devices'][device]['physicalDevice'] = dict(name=gpu['device_name'], vendor=expected_vendor,
                                                     driver=gpu['driver_version'])
    assert not actual['devices'][device]['strictPass']
    for name in ('command.json', 'runtime.json', 'frames/capture_manifest.json', 'frames/gpu_capabilities.json',
                 material.name):
        files[f'{device}/{name}'] = candidate / name

target.mkdir(parents=True, exist_ok=True)
package = target / 'validation.zip'
with ZipFile(package, 'w', compression=ZIP_DEFLATED) as archive:
    for name, path in sorted(files.items()):
        archive.writestr(ZipInfo(name, (2026, 11, 16, 0, 0, 0)), path.read_bytes(), compress_type=ZIP_DEFLATED)
members = {name: sha(path) for name, path in files.items()}
with ZipFile(package) as archive:
    assert archive.testzip() is None
    assert members == {name: sha256(archive.read(name)).hexdigest() for name in archive.namelist()}
assert package.stat().st_size < 8 * 2**20
actual['archive'] = dict(sha256=sha(package), members=members)
actual['shaderWitnessMaximumLinearError'] = max(w['litStageError'] for w in model['witnesses'])
(target / 'results.json').write_text(json.dumps(actual, indent=2) + '\n', encoding='utf8')
print(f"{len(members)} verified files, {package.stat().st_size} bytes, GPU job {queue_result['id']}")
