from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

run = Path(__file__).resolve().parent
files = run / 'native-floor-reflection-inputs'
out = run.parents[2] / 'docs/acceptance/nr/evidence/2026-11-16/projected-floor-actual-inputs'
read = lambda p: json.loads(p.read_bytes())
digest = lambda b: sha256(b).hexdigest()
score = read(files / 'aligned-results.json')
native = read(files / 'results.json')
assert score['status'] == 'paired-actual-attachment-measurement'
assert score['nativeEvent'] == native['event'] == 8702 and score['playerEvent'] == 21668
assert score['sameDepthAsLater'] and score['nativeReadback'] == native
assert native['region'] == [500, 480, 790, 700] and native['storageRegion'] == [500, 20, 790, 240]
paths = {p.name: p for p in (files / 'aligned-results.json', files / 'request.json', files / 'results.json',
        run / 'native-floor-reflection-inputs.py', run / 'score-native-floor-reflection-inputs.py', Path(__file__))}
for row in native['files']:
    take = files / (row['name'] + '.bin')
    assert digest(take.read_bytes()) == row['sha256']
    paths['native/' + take.name] = take
assert native['storageRows'] == 'reversed-to-display'
for key, values in (('centerFloor',(24073,19043,.78146)),('cyanRing',(6900,6477,.87635))):
    group = score['regions'][key]
    pair = group['matchedViewDepth']['0.02']
    common = group['confidenceWeightedTraceResidual']['subregions']['bothHits']
    assert (pair['samples'],pair['bothHit'],common['samples']) == (*values[:2],values[1])
    assert abs(common['errorShare'] - values[2]) < 1e-5
    assert abs(pair['roughness']['playerMinusNative'][2]) < .001
    assert pair['worldNormalAngleDegrees'][2] < .3
out.mkdir(parents=True, exist_ok=True)
archive = out / 'validation.zip'
payload = {name: path.read_bytes() for name,path in paths.items()}
with ZipFile(archive,'w') as z:
    for name,data in sorted(payload.items()):
        info = ZipInfo(name,(2026,11,16,0,0,0))
        z.writestr(info,data,compress_type=ZIP_DEFLATED)
with ZipFile(archive) as z:
    assert z.testzip() is None
    assert {name:z.read(name) for name in z.namelist()} == payload
score['archive'] = dict(sha256=digest(archive.read_bytes()),members={k:digest(data) for k,data in payload.items()})
(out/'results.json').write_text(json.dumps(score,indent=2)+'\n',encoding='utf8')
print(score['archive']['sha256'])
