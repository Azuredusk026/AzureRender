"""Read the native reflected-floor depth and surface lanes from draw 8702."""
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback


KEY = 'AZURE_NR_NATIVE_FLOOR_INPUTS'
M = Path(os.environ[KEY]).parent if KEY in os.environ else Path(__file__).resolve().parent
OUT = M / 'native-floor-reflection-inputs'
base = Path('D:/Projects/FYP/Project/AzureRender/build/runs')
origin = base / '20261022-201845-endfield-capture-954719/Endfield-games-child_frame3534.rdc'
source = base / '20261029-052336-native-hierarchical-reflection-52b603'
rectangle = (500, 480, 790, 700)
storage_rectangle = (rectangle[0], 720-rectangle[3], rectangle[2], 720-rectangle[1])
bindings = {3: ('ResourceId::16447', 'R32_FLOAT', 'current-depth'),
            5: ('ResourceId::15777', 'R8_UNORM', 'long-search-mask'),
            6: ('ResourceId::16497', 'R10G10B10A2_UNORM', 'normal-roughness')}
read = lambda p: json.loads(p.read_bytes())


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf8')


def worker():
    import renderdoc as rd
    request = read(OUT / 'request.json')
    capture = rd.OpenCaptureFile()
    controller = None
    report = dict(status='failed', source=request['captureSha256'], event=8702, region=rectangle,
                  storageRegion=storage_rectangle, storageRows='reversed-to-display')
    try:
        assert capture.OpenFile(str(origin), '', None) == rd.ResultCode.Succeeded
        status, controller = capture.OpenCapture(rd.ReplayOptions(), None)
        assert status == rd.ResultCode.Succeeded and controller is not None
        assert controller.GetAPIProperties().pipelineType == rd.GraphicsAPI.D3D11
        controller.SetFrameEvent(8702, True)
        pipe = controller.GetPipelineState()
        shader = pipe.GetShaderReflection(rd.ShaderStage.Compute)
        assert sha256(bytes(shader.rawBytes)).hexdigest() == request['shaderSha256']
        actual = {shader.readOnlyResources[row.access.index].fixedBindNumber: row.descriptor.resource
                  for row in pipe.GetReadOnlyResources(rd.ShaderStage.Compute)}
        outputs = {shader.readWriteResources[row.access.index].fixedBindNumber: row.descriptor.resource
                   for row in pipe.GetReadWriteResources(rd.ShaderStage.Compute)}
        desc = {str(t.resourceId): t for t in controller.GetTextures()}
        x, y, u, v = storage_rectangle
        files = []
        def export(slot, rid, fmt, name, resource, event):
            texture = desc[rid]
            assert str(resource) == rid and texture.format.Name() == fmt
            assert (texture.width, texture.height, texture.arraysize) == (1280, 720, 1)
            raw = bytes(controller.GetTextureData(resource, rd.Subresource(0, 0, 0)))
            bpp, extra = divmod(len(raw), texture.width * texture.height)
            assert extra == 0 and bpp == (1 if fmt == 'R8_UNORM' else 4)
            index = (y * texture.width + x)*bpp
            height, stride, width = v-y, texture.width*bpp, (u-x)*bpp
            crop = b''.join(raw[index+i*stride:index+i*stride+width] for i in reversed(range(height)))
            assert len(crop) == height*width
            (OUT / (name + '.bin')).write_bytes(crop)
            files.append(dict(event=event, slot=slot, resource=rid, format=fmt, name=name, fullSha256=sha256(raw).hexdigest(),
                              length=len(crop), sha256=sha256(crop).hexdigest()))
            print(name, len(crop), flush=True)
        for slot, (rid, fmt, name) in bindings.items():
            export(slot,rid,fmt,name,actual[slot],8702)
        final = outputs[2]
        export(2,'ResourceId::15781','R8_UNORM','trace-confidence',final,8702)
        controller.SetFrameEvent(8691,True)
        prep_pipe = controller.GetPipelineState()
        prep_shader = prep_pipe.GetShaderReflection(rd.ShaderStage.Compute)
        assert sha256(bytes(prep_shader.rawBytes)).hexdigest() == request['prepareShaderSha256']
        prep = {prep_shader.readWriteResources[row.access.index].fixedBindNumber: row.descriptor.resource
                for row in prep_pipe.GetReadWriteResources(rd.ShaderStage.Compute)}
        assert prep[2] == final
        export(2,'ResourceId::15781','R8_UNORM','initial-confidence',prep[2],8691)
        report.update(status='qualified', capturedShader=request['shaderSha256'], files=files)
    except BaseException:
        report['error'] = traceback.format_exc()
    finally:
        if controller is not None:
            controller.Shutdown()
        capture.Shutdown()
        write(OUT/'results.json', report)
    os._exit(0 if report['status'] == 'qualified' else 1)


def preflight():
    summary = read(source/'receipt.json')
    declared, = [row for row in summary['events'] if row['event'] == 8702]
    prepare, = [row for row in summary['events'] if row['event'] == 8691]
    context = read(source/'event-8702.json')
    assert context['sha256'] == declared['sha256'] == sha256((source/'event-8702.dxbc').read_bytes()).hexdigest()
    assert prepare['sha256'] == sha256((source/'event-8691.dxbc').read_bytes()).hexdigest()
    for slot,(rid,fmt,name) in bindings.items():
        row, = [row for row in context['inputs'] if row['shader_binding_index'] == slot]
        assert (row['resource'], row['texture']['format']) == (rid,fmt), name
        assert (row['texture']['width'], row['texture']['height']) == (1280,720)
    return dict(source=str(origin), captureSha256='5bf129d05acb43d41ab54042f6648c3d728decb253c94d0250037f01f0b778b3',
                event=8702, shaderSha256=declared['sha256'], prepareShaderSha256=prepare['sha256'], region=rectangle,
                bindingSource=sha256((source/'event-8702.json').read_bytes()).hexdigest())


def launch():
    from hashlib import file_digest
    queue = read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert queue['owner'] == '01a1d0a9-829a-7c11-a7a8-017e743887d9'
    assert queue['state'] == 'held' and Path(queue['output']) == M
    request = preflight()
    with origin.open('rb') as stream:
        assert file_digest(stream, 'sha256').hexdigest() == request['captureSha256']
    sys.path.insert(0, str(M.parents[2] / 'tools'))
    from artifact_budget import check
    budget = check(M.parents[1], run=M, planned=2_000_000)
    assert budget['allowed'], budget
    OUT.mkdir(exist_ok=True)
    write(OUT/'request.json', request)
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = 0
    with (OUT/'replay.log').open('wb') as log:
        proc = subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe', '--python',
                               str(Path(__file__).resolve())], cwd=OUT, env=dict(os.environ, **{KEY:str(OUT)}),
                              startupinfo=startup, stdout=log, stderr=subprocess.STDOUT, timeout=265)
    export = read(OUT/'results.json')
    assert proc.returncode == 0 and export['status'] == 'qualified', export.get('error')
    names = {name for _,_,name in bindings.values()} | {'initial-confidence','trace-confidence'}
    expected = {name:sha256((OUT/(name+'.bin')).read_bytes()).hexdigest() for name in names}
    assert {row['name']:row['sha256'] for row in export['files']} == expected
    print(json.dumps(export), flush=True)


if KEY in os.environ:
    worker()
elif __name__ == '__main__':
    if sys.argv[1:] == ['preflight']:
        print(json.dumps(preflight()), flush=True)
    elif sys.argv[1:] == ['run']:
        launch()
    else:
        raise SystemExit('Expected preflight or run')
