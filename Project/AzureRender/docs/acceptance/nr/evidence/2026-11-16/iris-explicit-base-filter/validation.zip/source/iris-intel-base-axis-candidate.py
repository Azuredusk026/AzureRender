"""Test the measured Intel native base footprint independently of Matcap."""
import json
from pathlib import Path
import runpy
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

M=Path(__file__).resolve().parent
probe=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='base_axis_controls')
H,W,R,B,CASE=[probe[k] for k in ('H','W','R','B','CASE')]
read,sha,write,art,check=[probe[k] for k in ('read','sha','write','art','check')]
base=probe['base']
out=M/'iris-intel-base-axis-candidate'
probe['activate_links'].__wrapped__.__globals__['home']=out
base['capture'].__globals__['OUT']=out
original='        float baseLod=azureAxisDiagonalMipLod(dFdxFine(baseUv)*baseExtent,dFdyFine(baseUv)*baseExtent);'
new='''        vec2 baseDx=dFdxFine(baseUv)*baseExtent;
        vec2 baseDy=dFdyFine(baseUv)*baseExtent;
        float baseLod=log2(max(max(length(baseDx),length(baseDy)),1.17549435e-38));'''


def preflight():
    f=read(M/'iris-base-footprint-native-match.json')
    assert f['scope']==255 and f['status']=='measured-base-mip-footprint-agreement'
    p=[1261,262]
    assert p in f['methods']['Finediagonal']['mismatches']['intel']
    assert p not in f['methods']['Fineaxis']['mismatches']['intel']
    assert p not in f['methods']['Finediagonal']['mismatches']['nvidia']
    source=M/'iris-unsigned-output-readonly/mesh.frag'
    assert sha(source)==read(M/'iris-unsigned-output-readonly/shader-receipt.json')['candidateSource']
    text=source.read_text('utf8')
    assert text.count(original)==1 and text.count(new)==0
    return (text.replace(original,new),sha(source),{k:v['matches']['intel'] for k,v in f['methods'].items()})


def run():
    assert read(Path('D:/Projects/FYP-coordination/resources/current.json'))['state']=='held'
    assert Path(read(Path('D:/Projects/FYP-coordination/resources/current.json'))['output'])==M
    budget=check(B,run=M,planned=2_020_000)
    assert budget['allowed'],budget
    source,source_hash,projection=preflight()
    coords,native,immutable,commands=base['inputs']()
    c=out/'mesh.frag'
    (out/'programs').mkdir(parents=True,exist_ok=True)
    c.write_text(source,encoding='utf8')
    for name in H['programs']:
        path=out/'programs'/name
        assert path.is_file() and (out/'compile'/f'{name}.log').is_file()
        subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.3',
                        '--relax-block-layout',str(path)],check=True,timeout=45)
    receipts={n:sha(out/'programs'/n) for n in H['programs']}
    with art.database(B) as conn:
        pinned=art.rows(conn)[R.name]
    assert pinned['status']=='closed'
    art.resume(B,R.name)
    try:
        with probe['activate_links'](receipts):
            frame=base['capture']('intel',commands['intel'],'candidate')
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=90)
    with art.database(B) as conn:
        restored=art.rows(conn)[R.name]
    assert restored['status']=='closed' and restored['manifestSha256']==pinned['manifestSha256']
    assert immutable==base['inputs']()[2]
    control=M/'iris-unsigned-output-readonly/intel-candidate/frames/frame_000000.png'
    unaided=M/'iris-unsigned-output-readonly/intel-control/control-receipt.json'
    original_frame=CASE/'intel-bare/frames/frame_000000.png'
    assert sha(original_frame)==read(unaided)['sha256']
    trunc_q=read(M/'iris-unsigned-output-readonly/qualification.json')['devices']['intel']
    assert sha(control)==trunc_q['frame']
    image=H['score']['image']
    original_pixels,control_pixels,candidate_pixels=[image(p).astype(np.int16) for p in (original_frame,control,frame)]
    x,y=coords
    image_delta=np.any(original_pixels!=candidate_pixels,axis=2)
    image_delta[y,x]=False
    differences=np.stack((original_pixels,control_pixels,candidate_pixels))[:,y,x]-native
    peaks=abs(differences).max(axis=2)
    assert (peaks[:2]>1).sum(axis=1).tolist()==trunc_q['overOne']
    outside=int(image_delta.sum())
    new_original=int(((peaks[0]<=1)&(peaks[2]>1)).sum())
    new_control=int(((peaks[1]<=1)&(peaks[2]>1)).sum())
    proof=out/'pixels.npz'
    # Exact RGB difference list makes the small probe replayable even if it fails.
    yy,xx=np.nonzero(np.any(original_pixels!=candidate_pixels,axis=2))
    np.savez_compressed(proof,pixels=np.column_stack((xx,yy,candidate_pixels[yy,xx])))
    rebuilt=original_pixels.copy()
    pixels=np.load(proof)['pixels']
    rebuilt[pixels[:,1],pixels[:,0]]=pixels[:,2:]
    assert np.array_equal(rebuilt,candidate_pixels)
    r=dict(status='measured-intel-axis-footprint-candidate',strict=bool(outside==new_original==0 and peaks[2].max()<=1),
        player=sha(base['player']),candidateSource=sha(c),source=source_hash,programs=receipts,inputs=immutable,
        motionScope='registered bare iris, one fixed frame',hardwareProjection=projection,frame=sha(frame),control=sha(control),
        original=sha(original_frame),frameProbe=sha(proof),outside=outside,new=[new_original,new_control],
        peak=peaks.max(axis=1).tolist(),overOne=(peaks>1).sum(axis=1).tolist(),
        changed=[{'point':[int(x[i]),int(y[i])],'deltas':differences[:,i].tolist()}
                 for i in range(len(x)) if np.any(differences[1,i]!=differences[2,i])])
    write(out/'results.json',r)
    assert frame.resolve().parent==(out/'intel-candidate/frames').resolve() and not frame.is_symlink()
    frame.unlink()
    from hashlib import sha256
    archive=out/'programs.zip'
    with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=8) as z:
        for n in receipts:
            z.write(out/'programs'/n,n)
    with ZipFile(archive) as z:
        assert z.testzip() is None and {n:sha256(z.read(n)).hexdigest() for n in receipts}==receipts
    for n in receipts:
        path=out/'programs'/n
        assert not path.is_symlink() and sha(path)==receipts[n]
        path.unlink()
    print({k:r[k] for k in ('strict','outside','peak','overOne','new')})


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(preflight()[2])
    else:
        run()
