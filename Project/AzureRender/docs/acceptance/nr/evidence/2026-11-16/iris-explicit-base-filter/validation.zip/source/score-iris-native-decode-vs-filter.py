"""Separate hardware BC7 texel decode from the native sample interpolation."""
from hashlib import sha256
import json
from pathlib import Path
import runpy

import numpy as np

M=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
u=runpy.run_path(str(M/'iris-native-filter-precision-model.py'),run_name='decode_filter_comparison_inputs')
req=M/'iris-native-decoded-taps/request.json'
src=M/'iris-native-decoded-taps/results.json'
ref=M/'iris-native-base-lane-grid/results.json'
q=read(req)
t,g=map(read,(src,ref))
assert t['status']=='qualified-native-decoded-texel-taps' and t['request']==sha(req)
assert q['sourceGrid']==sha(ref) and g['points']==u['mip_candidates']()[0]
bc, cpu=u['bc'],u['load_layers']()
points, matches=u['mip_candidates']()
out={}


def linear(x):
    return np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)


def summarize(v):
    v=np.asarray(v).reshape(-1,3)
    maxes=abs(v).max(1)
    return dict(n=len(v),p50=float(np.median(maxes)),p95=float(np.quantile(maxes,.95)),
        max=float(maxes.max()),over1In255=int((maxes>1/255).sum()))


for dev, data in t['devices'].items():
    recorded={}
    h=[]
    offset=148
    for l in range(10):
        size=max(1,512>>l)
        n=((size+3)//4)**2*16
        h.append(sha256(bc[offset:offset+n]).hexdigest())
        offset+=n
    assert all(h[int(l)]==v for l,v in data['rawMips'].items())
    taps=data['taps']
    physical=np.array([v[:3] for l,x,y,v in taps])
    software=np.array([cpu[l][y,x,:3] for l,x,y,v in taps])
    hypotheses={'direct':summarize(physical-software),'srgbConverted':summarize(linear(physical)-software)}
    candidate=min(hypotheses,key=lambda k:hypotheses[k]['p95'])
    rgb=physical if candidate=='direct' else linear(physical)
    for (l,x,y,_),v in zip(taps,rgb,strict=True):
        recorded[(l,x,y)]=v
    target=g['devices'][dev]['lanes']
    model=[]
    for i,address in enumerate(points):
        levels=np.flatnonzero(matches[dev][i])
        if len(levels)!=1:
            continue
        l=int(levels[0])
        size=len(cpu[l])
        uv=np.array([target[f'uv-{k}']['values'][i][1] for k in range(2)])
        truth=np.array([target[f'rgb-{k}']['values'][i][1] for k in range(3)])
        fp=uv*size-.5
        x,y=np.floor(fp).astype(int)
        dx,dy=fp-[x,y]
        xx,yy=x%size,y%size
        nx,ny=(x+1)%size,(y+1)%size
        keys=[(l,xx,yy),(l,nx,yy),(l,xx,ny),(l,nx,ny)]
        w=np.array([(1-dx)*(1-dy),dx*(1-dy),(1-dx)*dy,dx*dy])
        a=w@np.array([recorded[k] for k in keys])
        b=w@np.array([cpu[l][q,p,:3] for _,p,q in keys])
        model.append(dict(point=address,level=l,native=truth.tolist(),fromMeasuredDecode=a.tolist(),
                          fromCpuDecode=b.tolist(),measuredDecodeDelta=(a-truth).tolist(),cpuDecodeDelta=(b-truth).tolist()))
    out[dev]=dict(colorEncoding=candidate,decodedTexelsVsCpu=hypotheses,rawMipHashes=data['rawMips'],
                  measuredDecodeThenLinearFilter=summarize([v['measuredDecodeDelta'] for v in model]),
                  cpuDecodeThenLinearFilter=summarize([v['cpuDecodeDelta'] for v in model]),points=model)
    print(dev,candidate,out[dev]['measuredDecodeThenLinearFilter'],out[dev]['cpuDecodeThenLinearFilter'])


result=dict(status='compared-native-texel-decodes-and-filter-inputs',inputs={x.name+':'+x.parent.name:sha(x) for x in (req,src,ref)},devices=out)
(src.parent/'decomposition.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
