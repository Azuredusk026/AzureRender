"""Read native BC7 texels that support the iris base footprint."""
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import traceback

KEY='AZURE_NR_IRIS_BC7_TAPS'
M=Path(os.environ[KEY]).parent if KEY in os.environ else Path(__file__).resolve().parent
src=M/'iris-native-base-lane-grid'
dst=M/'iris-native-decoded-taps'
read=lambda p:json.loads(Path(p).read_bytes())
write=lambda p,v:Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
s=lambda b:sha256(b).hexdigest()


def plan():
    import runpy
    m=runpy.run_path(str(M/'iris-native-filter-precision-model.py'),run_name='plan_native_bc7_taps')
    point,mips=m['mip_candidates']()
    a=read(src/'results.json')
    req=read(src/'request.json')
    assert a['status']=='qualified-dual-device-native-base-lanes' and a['points']==point
    assert a['request']==s((src/'request.json').read_bytes())
    q=[]
    for dev,v in a['devices'].items():
        taps=set()
        groups=set()
        for i,p in enumerate(point):
            levels=mips[dev][i].nonzero()[0]
            if len(levels)!=1:
                continue
            l=int(levels[0])
            groups.add(l)
            n=max(1,512>>l)
            u,v0=[v['lanes'][f'uv-{k}']['values'][i][1] for k in range(2)]
            x,y=(math.floor(u*n-.5),math.floor(v0*n-.5))
            for dx,dy in ((0,0),(0,1),(1,0),(1,1)):
                taps.add((l,(x+dx)%n,(y+dy)%n))
        assert len(taps)<1024
        q.append(dict(device=dev,taps=sorted(taps),levels=sorted(groups)))
    req['sampledInputs']=q
    req['sourceGrid']=s((src/'results.json').read_bytes())
    return req


def worker():
    import renderdoc as rd
    req=read(dst/'request.json')
    cap=rd.OpenCaptureFile()
    q=dict(status='failed',request=s((dst/'request.json').read_bytes()),devices={})
    try:
        write(dst/'progress.json',dict(stage='open'))
        assert cap.OpenFile(req['capture'],'',None)==rd.ResultCode.Succeeded
        for cfg in req['sampledInputs']:
            d=cfg['device']
            vendor,name=(rd.GPUVendor.nVidia,0x28e0) if d=='nvidia' else (rd.GPUVendor.Intel,0xa788)
            r=rd.ReplayOptions()
            r.forceGPUVendor, r.forceGPUDeviceID=vendor,name
            status,c=cap.OpenCapture(r,None)
            assert status==rd.ResultCode.Succeeded and c
            try:
                b=c.GetAPIProperties()
                assert b.pipelineType==rd.GraphicsAPI.D3D11 and b.vendor==vendor and not b.degraded
                c.SetFrameEvent(846,True)
                pipe=c.GetPipelineState()
                shader=pipe.GetShaderReflection(rd.ShaderStage.Pixel)
                assert s(bytes(shader.rawBytes))==req['pixelShaderSha256']
                t,=[x.descriptor.resource for x in pipe.GetReadOnlyResources(rd.ShaderStage.Pixel)
                       if shader.readOnlyResources[x.access.index].fixedBindNumber==13]
                args=[x for x in c.GetTextures() if x.resourceId==t]
                assert len(args)==1
                x=args[0]
                assert (x.width,x.height,x.mips)==(512,512,10) and x.format.Name()=='BC7_SRGB'
                hashes={str(i):s(bytes(c.GetTextureData(t,rd.Subresource(i,0,0)))) for i in cfg['levels']}
                taps=[]
                for i,(mip,px,py) in enumerate(cfg['taps']):
                    if i%50==0:
                        write(dst/'progress.json',dict(device=d,done=i,total=len(cfg['taps'])))
                    f=c.PickPixel(t,px,py,rd.Subresource(mip,0,0),rd.CompType.Typeless)
                    val=list(f.floatValue)[:4]
                    assert all(math.isfinite(v) and -.000001<=v<=1.000001 for v in val),(d,mip,px,py,val)
                    taps.append([mip,px,py,val])
                q['devices'][d]=dict(device=d,texture=str(t),format=x.format.Name(),rawMips=hashes,taps=taps)
            finally:
                c.Shutdown()
        q['status']='qualified-native-decoded-texel-taps'
    except BaseException:
        q['error']=traceback.format_exc()
    finally:
        cap.Shutdown()
        write(dst/'results.json',q)
    os._exit(int(q['status']=='failed'))


def run():
    from hashlib import file_digest
    sys.path.insert(0,str(M.parents[2]/'tools'))
    from artifact_budget import check
    lease=read('D:/Projects/FYP-coordination/resources/current.json')
    assert lease['state']=='held' and Path(lease['output'])==M
    assert check(M.parents[1],run=M,planned=600_000)['allowed']
    req=plan()
    with Path(req['capture']).open('rb') as f:
        assert file_digest(f,'sha256').hexdigest()==req['captureSha256']
    dst.mkdir(exist_ok=True)
    p=dst/'request.json'
    write(p,req)
    si=subprocess.STARTUPINFO()
    si.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow=0
    with (dst/'replay.log').open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=dst,env=dict(os.environ,**{KEY:str(dst)}),stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,
            startupinfo=si,timeout=180)
    q=read(dst/'results.json')
    assert child.returncode==0 and q['status']=='qualified-native-decoded-texel-taps',q.get('error')
    print({k:len(v['taps']) for k,v in q['devices'].items()})


if KEY in os.environ:
    worker()
elif __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print([(v['device'],v['levels'],len(v['taps'])) for v in plan()['sampledInputs']])
    else:
        run()
