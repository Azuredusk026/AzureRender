"""Test explicit bilinear RGB filtering at the fixed canonical iris mip."""
import json
from pathlib import Path
import runpy
import sys

M=Path(__file__).resolve().parent
reference=M/'iris-intel-base-axis-candidate.py'
device='nvidia' if sys.argv[1:]==['nvidia'] else 'intel'
if device=='nvidia':
    sys.argv.pop()
folder='iris-explicit-pixel-filter-candidate'+('-nvidia' if device=='nvidia' else '')
words=reference.read_text(encoding='utf8')
old_original="original='        float baseLod=azureAxisDiagonalMipLod(dFdxFine(baseUv)*baseExtent,dFdyFine(baseUv)*baseExtent);'"
old_mip="    assert f['scope']==255 and f['status']=='measured-base-mip-footprint-agreement'"
transition={
    "out=M/'iris-intel-base-axis-candidate'":f"out=M/'{folder}'",
    old_original:"original='        baseColor=textureLod(AZ_TEX_BASE_COLOR,baseUv,floor(baseLod+.5));'",
    old_mip:old_mip+'''\n    side=M.parent/'20261112-231945-projected-hair-reference-grid-4b775d/iris-overlay-geometry-project/materials/78aceced-9df2-5a59-a58b-f288adb30cb4.dds.azmeta'
    sampler=read(side)['settings']['texture']
    assert sampler['mipBias']==-1 and sampler['mipFilter']=='nearest'
    assert sampler['wrapU']==sampler['wrapV']=='repeat' ''',
    "planned=2_020_000":"planned=3_800_000",
    "        assert path.is_file() and (out/'compile'/f'{name}.log').is_file()\n        subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.3',\n                        '--relax-block-layout',str(path)],check=True,timeout=45)":
        "        H['compile_program'](c,path,name,diagnostics=out/'compile'/f'{name}.log')",
    "status='measured-intel-axis-footprint-candidate'":f"status='measured-{device}-explicit-bilinear-base-filter'",
}
if device=='nvidia':
    transition.update({
        "base['capture']('intel',commands['intel'],'candidate')":"base['capture']('nvidia',commands['nvidia'],'candidate')",
        "'iris-unsigned-output-readonly/intel-candidate/frames/frame_000000.png'":
            "'iris-unsigned-output-readonly/nvidia-candidate/frames/frame_000000.png'",
        "'iris-unsigned-output-readonly/intel-control/control-receipt.json'":
            "'iris-unsigned-output-readonly/nvidia-control/control-receipt.json'",
        "CASE/'intel-bare/frames/frame_000000.png'":"CASE/'nvidia-bare/frames/frame_000000.png'",
        "['devices']['intel']":"['devices']['nvidia']",
        "(out/'intel-candidate/frames').resolve()":"(out/'nvidia-candidate/frames').resolve()",
    })
for old,new in transition.items():
    assert words.count(old)==1,old
    words=words.replace(old,new)
start=words.index("new='''")
end=words.index("'''",start+7)+3
assert words[start:end].count('length(baseDx)')==1
words=words[:start]+'''new=original+"""\n        if(eyeNpr) {
            // The retained asset uses repeat/linear with a minus one nearest mip offset.
            int level = clamp(int(floor(baseLod+.5))-1,0,textureQueryLevels(AZ_TEX_BASE_COLOR)-1);
            ivec2 size = textureSize(AZ_TEX_BASE_COLOR,level);
            vec2 texel=baseUv*vec2(size)-.5;
            ivec2 low=ivec2(floor(texel));
            ivec2 p=(low % size + size) % size;
            ivec2 q=(p+1) % size;
            vec2 w=fract(texel);
            vec3 a=mix(texelFetch(AZ_TEX_BASE_COLOR,p,level).rgb,
                       texelFetch(AZ_TEX_BASE_COLOR,ivec2(q.x,p.y),level).rgb,w.x);
            vec3 b=mix(texelFetch(AZ_TEX_BASE_COLOR,ivec2(p.x,q.y),level).rgb,
                       texelFetch(AZ_TEX_BASE_COLOR,q,level).rgb,w.x);
            baseColor.rgb=mix(a,b,w.y);
        }"""'''+words[end:]
words=words.replace(
    "assert text.count(original)==1 and text.count(new)==0",
    "assert text.count(original)==1 and text.count(new)==0 and len(new)>len(original)")
code=compile(words,str(reference),'exec')
exec(code,dict(__file__=str(reference),__name__='__main__'))
