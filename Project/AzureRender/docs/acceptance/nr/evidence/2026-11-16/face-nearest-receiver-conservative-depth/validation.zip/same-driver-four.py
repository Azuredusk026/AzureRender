"""Compare the candidate shader on both retained four-frame reference sets."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from difflib import SequenceMatcher
from hashlib import sha256
import json
from pathlib import Path
import runpy
import subprocess
import sys
import time
from zipfile import ZIP_DEFLATED,ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
out=M/'face-conservative-depth-frozen-regression'
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
Q=M/'readonly-face-hair-shadow-conservative-receiver'
old=M/'projected-history-layer-frozen-regression'
E=W/'docs/acceptance/nr/evidence/2026-11-16'
native=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames')
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
len_footer=12
footer=b'\x00\x00\x00\x00IEND\xaeB\x60\x82'


def compare(a,b):
    d=abs(a[:,:,:3].astype(np.int16)-b[:,:,:3].astype(np.int16)).max(axis=2)
    return dict(differingPixels=int((d>0).sum()),overOne=int((d>1).sum()),peak=int(d.max()))


def retained_frame(name):
    owned=old/'frames'/name
    if owned.is_file():
        return owned
    recorded=read(M/'frozen-same-driver-frame-recovery.json')[name]
    reference=Path(recorded['retainedReference'])
    assert Path(recorded['originalPath'])==owned and digest(reference)==recorded['sha256']
    return reference


def image(p):
    a=cv2.imread(str(p),cv2.IMREAD_UNCHANGED)
    assert a.shape==(1440,2560,4),p
    return a


def process(path,scope):
    if not path.exists():
        return None
    try:
        data=path.read_bytes()
    except (FileNotFoundError,PermissionError):
        return None
    if len(data)<len_footer or data[-len_footer:]!=footer:
        return None
    assert path.resolve().parent==(out/'frames').resolve() and not path.stat().st_file_attributes&1024
    keep=retained_frame(path.name)
    gold=native/path.name
    a=cv2.imdecode(np.frombuffer(data,np.uint8),cv2.IMREAD_UNCHANGED)
    assert a.shape==(1440,2560,4)
    ref=image(keep)
    baseline=digest(keep)
    native_digest=digest(gold)
    assert baseline==scope['sha256'] and native_digest==scope['original']
    record=dict(frame=path.name,sha256=sha256(data).hexdigest(),reference=baseline,historical=native_digest,
                decoded=sha256(a.tobytes()).hexdigest(),sameDriver=compare(a,ref),historicalFrozen=compare(a,image(gold)))
    if record['sha256']!=baseline:
        patch=out/(path.stem+'-delta.zip')
        with ZipFile(patch,'w',ZIP_DEFLATED,compresslevel=6) as z:
            z.writestr('frame.bgra-xor',(a^ref).tobytes())
        with ZipFile(patch) as z:
            assert z.testzip() is None
            assert np.array_equal(ref^np.frombuffer(z.read('frame.bgra-xor'),np.uint8).reshape(a.shape),a)
        record['deltaArchive']=digest(patch)
    assert digest(path)==record['sha256']
    # Same captured bytes already exist, or the decoded image round-trips via the retained delta.
    try:
        path.unlink()
    except PermissionError:
        return None
    return record



@contextmanager
def mounted_candidate():
    import artifact_maintenance as art
    frozen=read(Q/'qualification.json')
    assert frozen['status']=='paired-full-frame-captures'
    assert frozen['samples']['nvidia-native-tint']['changed']==0
    assert frozen['samples']['intel-native-tint']['positions']==[[1321,271]]
    assert frozen['samples']['intel-native-tint']['witness']['after']==[185,121,101]
    old_source=(Q/'original-mesh.frag').read_text(encoding='utf8')
    new_source=(Q/'mesh.frag').read_text(encoding='utf8')
    assert digest(Q/'mesh.frag')==frozen['diagnosticSource']
    current=W/'shaders/mesh.frag'
    baseline=current.read_text(encoding='utf8')
    patched=baseline
    left,right=[v.splitlines(keepends=True) for v in (old_source,new_source)]
    diff=[v for v in SequenceMatcher(None,left,right,autojunk=False).get_opcodes() if v[0]!='equal']
    assert len(diff)==3 and all(v[0]=='insert' for v in diff)
    for _,i,_,a,b in diff:
        anchor=''.join(left[i:i+2])
        assert patched.count(anchor)==1,anchor
        patched=patched.replace(anchor,''.join(right[a:b])+anchor,1)
    source=out/'mesh.frag'
    source.write_text(patched,encoding='utf8')
    H=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='frozen_receiver_compiler')['H']
    fixture=runpy.run_path(str(M/'projected-reflection-radiance-layer-fixture.py'),run_name='frozen_receiver_shader_assets')
    catalog=runpy.run_path(str(R/'face-quality-candidate-catalog.py'),run_name='frozen_receiver_catalog')
    baseline_shaders=catalog['retained_catalog'](R)
    ref_rules=read(R/'msaa-release/shader-reload.json')['programs']
    programs={}
    variants=[r['output'] for r in ref_rules if r['output'].startswith('mesh_object_bindless_clipmap')
        and r['output'] in baseline_shaders and not set(r['defines'])&{'AZURE_ORDINARY_EARLY_DEPTH=1',
        'AZURE_GEOMETRY_SAMPLES=1','AZURE_OPAQUE_SNAPSHOT=1','AZURE_SURFACE_RADIANCE_REUSE=1','AZURE_VIEW_FOG=1'}]
    assert {'mesh_object_bindless_clipmap.frag.spv','mesh_object_bindless_clipmap_field.frag.spv'}<=set(variants)
    assert len(variants)<=12,variants
    program_root=out/'programs'
    program_root.mkdir()
    for name in sorted(variants):
        H['compile_program'](source,program_root/name,name,diagnostics=out/'compile'/f'{name}.log')
        decode=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-dis.exe',str(program_root/name)],
                              check=True,capture_output=True).stdout
        assert b'DepthReplacing' in decode and b'DepthLess' in decode and b'EarlyFragmentTests' not in decode
        programs[name]=digest(program_root/name)
    with art.database(W/'build') as c:
        pinned=art.rows(c)[R.name]
    assert pinned['status']=='closed'
    art.resume(W/'build',R.name)
    try:
        with fixture['programs']() as (_,release,mounted):
            replaced=[]
            try:
                for name,value in programs.items():
                    target=release/'shaders'/name
                    assert digest(target)==baseline_shaders[name]
                    backup=target.with_name(target.name+'.receiver-frozen-control')
                    assert not backup.exists()
                    target.replace(backup)
                    replaced.append((target,backup))
                    target.hardlink_to(program_root/name)
                    assert digest(target)==value
                yield dict(baseSource=digest(current),candidateSource=digest(source),programs=programs,
                           existingProjectedPrograms=mounted)
            finally:
                for target,backup in reversed(replaced):
                    assert digest(backup)==baseline_shaders[target.name]
                    backup.replace(target)
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=320)
    with art.database(W/'build') as c:
        retained=art.rows(c)[R.name]
    assert retained['status']=='closed' and retained['manifestSha256']==pinned['manifestSha256']


def run():
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    budget=check(W/'build',run=M,planned=22_000_000)
    assert budget['allowed'],budget
    body=runpy.run_path(str(M/'character-six-view-inputs.py'),run_name='primary_frozen_capture')
    invoke=body['helpers']['invoke']
    fixture=read(E/'projected-history-layer-frozen/qualification.json')
    build=read(M/'projected-history-layer-release/link-receipt.json')
    player=M/'projected-history-layer-release/AzurePlayer.exe'
    assert build['newPlayer']==digest(player) and fixture['sameDriverExact']
    cmd=read(old/'command.json')
    cmd[0]=str(player)
    for flag,path in (('--capture-dir',out/'frames'),('--runtime-report',out/'runtime.json')):
        cmd[cmd.index(flag)+1]=str(path)
    assert '--fixed-frame-step' in cmd and cmd[cmd.index('--capture-frames')+1]=='4'
    p=Path(cmd[cmd.index('--project')+1])
    p_before=digest(p)
    out.mkdir()
    plan={}
    for row,h in zip(fixture['frames'],fixture['retainedInputs']['originalFrozen'],strict=True):
        name=row['frame']
        assert row['sha256']==digest(retained_frame(name)) and h==digest(native/name)
        plan[name]=dict(**row,original=h)
    receipts={}
    with mounted_candidate() as programs:
        with ThreadPoolExecutor(max_workers=1) as pool:
            future=pool.submit(invoke,'nvidia',cmd,out)
            while len(receipts)<4:
                for name,row in plan.items():
                    if name not in receipts:
                        r=process(out/'frames'/name,row)
                        if r:
                            receipts[name]=r
                            write(out/'streamed-frames.json',receipts)
                if future.done():
                    future.result()
                    if len(receipts)!=4:
                        assert all((out/'frames'/p).exists() for p in plan if p not in receipts)
                if len(receipts)<4:
                    time.sleep(.15)
            frames=future.result()
    assert digest(p)==p_before
    caps=read(frames/'gpu_capabilities.json')
    expected=read(old/'frames/gpu_capabilities.json')
    assert all(caps[k]==expected[k] for k in ('vendor_id','device_id','driver_version'))
    got=read(frames/'capture_manifest.json')
    a=read(old/'frames/capture_manifest.json')
    keys=('capturedFrames','width','height','qaCameraPosition','qaCameraTarget','cameraLens','screenReflectionProducer')
    assert all(got[k]==a[k] for k in keys)
    report=dict(status='measured-face-conservative-depth-frozen',linkedPlayer=build['newPlayer'],scope=fixture['retainedInputs'],
                frames=receipts,sameDriverExact=all(r['sameDriver']['peak']==0 for r in receipts.values()),
                originalFrozenExact=all(r['historicalFrozen']['peak']==0 for r in receipts.values()),project=p_before,
                shaderPrograms=programs)
    write(out/'qualification.json',report)
    assert report['sameDriverExact'],[(n,v['sameDriver']) for n,v in receipts.items()]
    print([(n,v['sameDriver']['peak'],v['historicalFrozen']['peak']) for n,v in receipts.items()])


if __name__=='__main__':
    run()
