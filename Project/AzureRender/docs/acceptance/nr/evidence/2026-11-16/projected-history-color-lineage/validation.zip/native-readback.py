"""Read original native glyph contribution and candidate outgoing history producers."""
import hashlib
import json
import math
import os
from pathlib import Path
import runpy
import struct
import subprocess
import sys
import traceback

KEY = 'AZURE_NR_HISTORY_NATIVE_LINEAGE'
run = Path(os.environ[KEY]).parents[1] if KEY in os.environ else Path(__file__).resolve().parent
out = run / 'projected-history-native-lineage'
proof_path = run / 'projected-history-coordinates/history-source-producer-witnesses.json'
intersections = run / 'projected-history-coordinates/history-source-draw-mask-intersection.json'
read = lambda p: json.loads(Path(p).read_bytes())
digest = lambda data: hashlib.sha256(data).hexdigest()
write = lambda p,d: p.write_text(json.dumps(d, indent=2)+'\n',encoding='utf-8')


def data():
    sources = runpy.run_path(str(run/'projected-history-source-replay.py'))
    req = sources['request']('native')
    proof = read(proof_path)
    identity = read(intersections)
    assert identity['status']=='qualified-same-address-draw-mask-intersection'
    samples = {}
    for route, regions in proof['groups'].items():
        for region, groups in regions.items():
            for kind, entries in groups.items():
                for e, mask in zip(entries,identity['witnesses'][route][region][kind],strict=True):
                    xy=tuple(e['previousPixelXY'])
                    assert tuple(mask['pixel'])==xy
                    row=samples.setdefault(xy,dict(pixel=xy,nativeHdr=e['nativeHdr'],playerHdr=e['playerHdr'],
                                                    drawEvents=mask['events'],groups=[]))
                    assert row['nativeHdr']==e['nativeHdr'] and row['playerHdr']==e['playerHdr']
                    row['groups'].append([route,region,kind])
    assert len(samples)>=30
    return dict(request=req,samples=[samples[k] for k in sorted(samples)],currentTarget='ResourceId::15739',
        currentTargetFormat='R11G11B10_FLOAT', priorExpectedSha256=sources['native_fixture'](req,None)['payloads'][0]['fullSha256'],
        glyphShaderSha256=digest((sources['root']/'20261028-065136-native-central-emissive-identity-466ad8/event-10480/ps.dxbc').read_bytes()),
        witnessSha256=digest(proof_path.read_bytes()),maskReportSha256=digest(intersections.read_bytes()))


def plus(x,m):
    e,f = x>>m,x&((1<<m)-1)
    return math.ldexp(f,1-15-m) if e==0 else math.ldexp((1<<m)|f,e-15-m) if e<31 else math.inf


def decode(v):
    return tuple(plus((v>>bit)&((1<<width)-1),m) for bit,width,m in ((0,11,6),(11,11,6),(22,10,5)))


def pixels(raw, points, half):
    assert len(raw)==2560*1440*(8 if half else 4)
    get=lambda x,y: 2560*(1439-y)+x
    return [struct.unpack_from('<4e',raw,8*get(*xy))[:3] if half
          else decode(struct.unpack_from('<I',raw,4*get(*xy))[0]) for xy in points]


def stage(rd,c,resource,event,points,half=False):
    c.SetFrameEvent(event,True)
    raw = bytes(c.GetTextureData(resource,rd.Subresource()))
    return dict(event=event,sha256=digest(raw),colors=pixels(raw,points,half))


def worker(path):
    import renderdoc as rd
    req=read(path); result=dict(status='unqualified',requestSha256=digest(Path(path).read_bytes()))
    cap=rd.OpenCaptureFile(); c=None
    try:
        assert cap.OpenFile(req['request']['capture'],'',None)==rd.ResultCode.Succeeded
        status,c=cap.OpenCapture(rd.ReplayOptions(),None)
        assert status==rd.ResultCode.Succeeded and c is not None
        assert str(c.GetAPIProperties().pipelineType)=='GraphicsAPI.D3D11'
        textures={str(t.resourceId):t for t in c.GetTextures()}
        structure=c.GetStructuredFile(); actions={}
        def walk(al,parents):
            for a in al:
                name=a.GetName(structure)
                actions[a.eventId]=(a,name,parents)
                if a.children: walk(a.children,parents+[name])
        walk(c.GetRootActions(),[])
        target=textures[req['currentTarget']]
        assert (target.width,target.height,target.format.Name())==(2560,1440,req['currentTargetFormat'])
        prior=textures[req['request']['inputs'][0]['resource']]
        assert (prior.width,prior.height,prior.format.Name())==(2560,1440,'R16G16B16A16_FLOAT')
        pts=[r['pixel'] for r in req['samples']]
        return_prior=stage(rd,c,prior.resourceId,req['request']['event'],pts,True)
        assert return_prior['sha256']==req['priorExpectedSha256']
        assert len(req['samples'])==len(return_prior['colors'])
        assert all(tuple(r['nativeHdr'])==v for r,v in zip(req['samples'],return_prior['colors']))
        c.SetFrameEvent(10480,True)
        ps=c.GetPipelineState().GetShaderReflection(rd.ShaderStage.Pixel)
        assert digest(bytes(ps.rawBytes))==req['glyphShaderSha256']
        assert c.GetPipelineState().GetOutputTargets()[0].resource==target.resourceId
        assert actions[10480][0].numIndices==18
        use=list(c.GetUsage(target.resourceId))
        events=(9002,10366,10479,10480,10875,10975,11393)
        output={}
        for event in events:
            assert 0<event<=max(actions)
            output[str(event)]=stage(rd,c,target.resourceId,event,pts)
        assert all(output['10479']['colors'][i]!=output['10480']['colors'][i] for i,r in enumerate(req['samples'])
                   if ['native','centerFloor','neutralDarker'] in r['groups'])
        def describe(t,u):
            a=actions.get(u.eventId)
            return dict(event=u.eventId,usage=str(u.usage),action=a[1] if a else None,groups=a[2] if a else None,
                source=str(a[0].copySource) if a else None,destination=str(a[0].copyDestination) if a else None)
        candidates={}
        sampled={}
        for t in textures.values():
            if (t.width,t.height,t.format.Name())!=(2560,1440,'R16G16B16A16_FLOAT'):continue
            usage=list(c.GetUsage(t.resourceId))
            written=[u for u in usage if any(k in str(u.usage) for k in ('ColorTarget','CopyDst','ResolveDst','CS_RWResource'))]
            if not written and t.resourceId!=prior.resourceId:continue
            key=str(t.resourceId)
            candidates[key]=dict(mips=t.mips,usage=[describe(t,u) for u in usage])
            # Restrict texture reads to post-shading producers and distinct resource identities.
            later=[u.eventId for u in written if 10480<=u.eventId<max(actions)]
            if later and len(sampled)<12:
                ee=max(later)
                sampled[key]=stage(rd,c,t.resourceId,ee,pts,True)
        for i,r in enumerate(req['samples']):
            r['currentHdrByEvent']={k:v['colors'][i] for k,v in output.items()}
            r['candidateHdrByResource']={k:v['colors'][i] for k,v in sampled.items()}
        result.update(status='qualified-current-native-contribution', currentColor=req['currentTarget'],
            priorColor=str(prior.resourceId), priorColorSha256=return_prior['sha256'], draw=10480,
            drawShaderSha256=req['glyphShaderSha256'], stageDigests={k:v['sha256'] for k,v in output.items()},
            lateFullResHalfColorStages={k:{x:y for x,y in v.items() if x!='colors'} for k,v in sampled.items()},
            activeHalfColorAttachments=candidates, currentColorLateUsage=[describe(target,u) for u in use if u.eventId>=10480],
            samples=req['samples'])
    except BaseException:
        result['error']=traceback.format_exc()
    finally:
        write(out/'results.json',result)
        if c is not None: c.Shutdown()
        cap.Shutdown()
    os._exit(0 if result['status'].startswith('qualified') else 1)


def launch():
    lease=read('D:/Projects/FYP-coordination/resources/current.json')
    assert lease['state']=='held' and lease['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9' and Path(lease['output'])==run
    sys.path.insert(0,str(run.parents[2]/'tools'))
    from artifact_budget import check
    verdict=check(run.parents[1],run=run,planned=1_200_000)
    assert verdict['allowed'],verdict
    out.mkdir(exist_ok=True)
    p=out/'request.json'
    write(p,data())
    start=subprocess.STARTUPINFO();start.dwFlags|=subprocess.STARTF_USESHOWWINDOW;start.wShowWindow=0
    with (out/'replay.log').open('wb') as log:
        proc=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=out,env=dict(os.environ,**{KEY:str(p)}),stdout=log,stderr=subprocess.STDOUT,startupinfo=start,timeout=240)
    result=read(out/'results.json')
    assert proc.returncode==0 and result['status'].startswith('qualified'),result.get('error')
    assert result['requestSha256']==digest(p.read_bytes())
    print(result['status'],len(result['samples']),len(result['activeHalfColorAttachments']),
          [(k,v['event']) for k,v in result['lateFullResHalfColorStages'].items()])


if KEY in os.environ:
    worker(os.environ[KEY])
elif __name__=='__main__':
    assert decode((15<<6)|((15<<6)<<11)|((15<<5)<<22))==(1.,1.,1.)
    assert decode(0)==(0.,0.,0.)
    if sys.argv[1:]==['preflight']:
        d=data()
        print(len(d['samples']),d['glyphShaderSha256'],d['priorExpectedSha256'])
    else:
        assert sys.argv[1:]==['run']
        launch()
