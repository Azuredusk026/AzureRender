"""Compare the same addresses at original Player and native history producers."""

import hashlib
import json
import math
from pathlib import Path
from statistics import median
import sys

run = Path(__file__).resolve().parent
coord = run / 'projected-history-coordinates'
proof_path = coord / 'history-source-producer-witnesses.json'
load = lambda p: json.loads(p.read_bytes())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def witness_groups(proof):
    groups, points = {}, {}
    for route, regions in proof['groups'].items():
        for region, subsets in regions.items():
            for subset, rows in subsets.items():
                group = route, region, subset
                assert len(rows) >= 5 and group not in groups
                groups[group] = tuple(tuple(row['previousPixelXY']) for row in rows)
                assert len(set(groups[group])) == len(rows)
                for key, row in zip(groups[group], rows, strict=True):
                    value = tuple(row['nativeHdr']), tuple(row['playerHdr'])
                    assert all(len(c) == 3 and all(math.isfinite(x) for x in c) for c in value)
                    assert points.setdefault(key, value) == value
                    assert abs(luma(value[1])-luma(value[0])-row['deltaCompressedLuma']) < 1e-10
    return groups, points


def luma(rgb):
    rgb = tuple(rgb[:3]); assert len(rgb) == 3 and all(math.isfinite(x) for x in rgb), rgb
    den = 1+max(rgb); assert den > 0, rgb
    return sum(max(x/den,0)*w for x, w in zip(rgb, (.2126, .7152, .0722), strict=True))


def stats(a, b):
    d = [luma(y)-luma(x) for x, y in zip(a, b, strict=True)]
    return dict(count=len(d), medianSigned=median(d), medianAbsolute=median(map(abs,d)),
                abovePoint02=sum(x>.02 for x in d), belowMinusPoint02=sum(x<-.02 for x in d))


def score(proof, groups, points, native, player):
    assert native['status'] == 'qualified-current-native-contribution' and native['draw'] == 10480
    assert player['status'] == 'qualified-player-snapshot-producer'
    snapshot = player['snapshot']
    assert snapshot['status'] == 'qualified-current-snapshot-source' and snapshot['traceEvent'] == 21668
    assert snapshot['previousColorSha256'] == proof['sourceInputs']['player']
    assert player['request']['witnessesSha256'] == digest(proof_path)
    assert native['requestSha256'] == digest(run/'projected-history-native-lineage/request.json')
    assert load(run/'projected-history-native-lineage/request.json')['witnessSha256'] == digest(proof_path)
    ordered = [tuple(row['previousPixelXY']) for row in snapshot['samples']]
    ns = {tuple(row['pixel']): row for row in native['samples']}
    ps = dict(zip(ordered, snapshot['samples'], strict=True))
    assert len(ordered) == len(ns) == len(ps) == len(points) and ns.keys() == ps.keys() == points.keys()
    assert all(tuple(ns[k]['nativeHdr']) == n and tuple(ps[k]['previousColor'][:3]) == p for k, (n,p) in points.items())
    pt = {}
    for resource, target in player.get('mainTargets', {}).items():
        for event, write in target['writes'].items():
            pt[f'{resource}@{event}'] = dict(zip(ordered, write['colors'], strict=True))
    known = dict(glyph=10480, warmCrates=(6613,6652), cyanControls=(5066,5078))
    report = {}
    for group, keys in groups.items():
        np, pp = ([points[k][i] for k in keys] for i in (0,1))
        pc = [ps[k]['currentColor'] for k in keys]
        stages = {event:[ns[k]['currentHdrByEvent'][event] for k in keys] for event in ('10479','10480','11393')}
        late = {res:stats(np,[ns[k]['candidateHdrByResource'][res] for k in keys])
                for res in native['lateFullResHalfColorStages']}
        report['/'.join(group)] = dict(addresses=keys,
            nativeDrawSupport={k:sum(bool(set(v if isinstance(v,tuple) else (v,)) & set(ns[p]['drawEvents'])) for p in keys)
                               for k,v in known.items()},
            nativePriorToPlayerPrior=stats(np,pp), playerPriorToCurrent=stats(pp,pc),
            nativeBeforeToAfterGlyph=stats(stages['10479'],stages['10480']),
            nativePriorToPostGlyph=stats(np,stages['10480']),
            nativePriorToLastMain=stats(np,stages['11393']), nativePriorToLateHalfTargets=late,
            playerCurrentToMainStage={k:stats(pc,[v[p] for p in keys]) for k,v in pt.items()},
            nativePriorToPlayerMainStage={k:stats(np,[v[p] for p in keys]) for k,v in pt.items()})
    return dict(status='same-address-native-player-lineage-diagnostic', distinctAddresses=len(points),
                nativePriorSha256=native['priorColorSha256'], playerPriorSha256=snapshot['previousColorSha256'],
                playerCurrentSha256=snapshot['currentColorSha256'], witnessSha256=digest(proof_path),
                playerMainStages=list(pt), playerMainTargetsError=player.get('mainTargetsError'),
                groups=report, limitation='Later main target values alone cannot attribute the change to one Player draw.')


def main():
    proof = load(proof_path)
    groups, points = witness_groups(proof)
    if sys.argv[1:] == ['preflight']:
        assert stats([(0,0,0)],[(1,1,1)])['medianSigned'] == .5
        assert stats([(1,1,1)],[(0,0,0)])['belowMinusPoint02'] == 1
        print(len(groups),len(points),digest(proof_path))
        return
    assert sys.argv[1:] == ['score']
    n = run / 'projected-history-native-lineage/results.json'
    p = run / 'projected-history-player-lineage/results.json'
    d = score(proof, groups, points, load(n), load(p))
    d['receiptSha256'] = dict(native=digest(n),player=digest(p))
    target = coord / 'same-address-native-player-lineage.json'
    target.write_text(json.dumps(d, indent=2)+'\n',encoding='utf-8')
    print(target, d['status'], d['distinctAddresses'], d['playerMainStages'])


if __name__ == '__main__':
    main()
