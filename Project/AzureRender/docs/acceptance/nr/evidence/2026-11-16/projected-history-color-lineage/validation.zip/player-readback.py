"""Identify the current color producer via prepared depth and same-pass attachments."""
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import struct
import subprocess
import sys
import traceback

read=lambda p:json.loads(Path(p).read_bytes())
digest=lambda b:sha256(b).hexdigest()


def at(rd,ctl,image,width,height,points):
    raw=bytes(ctl.GetTextureData(image,rd.Subresource(0,0,0)))
    assert len(raw)==width*height*8
    return digest(raw),{(x,y):struct.unpack_from('<4e',raw,8*(width*y+x)) for (x,y) in points}


def player_snapshot(rd,ctl,req,work,prior_resource):
    event=req['event']
    assert req['device']=='player' and event==21668
    p=work/'projected-history-coordinates/history-source-producer-witnesses.json'
    proof=read(p)
    assert proof['status']=='prepared-fixed-address-history-stage-witnesses'
    samples={}
    for route in proof['groups'].values():
        for region in route.values():
            for stage in region.values():
                for row in stage:
                    point=tuple(row['previousPixelXY'])
                    value=tuple(row['playerHdr'])
                    assert point not in samples or samples[point]==value
                    samples[point]=value
    assert len(samples)>=30
    old=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261031-122504-projected-footprint-quality-5daf40/capture-inputs-v2/summary.json')
    legacy=read(old)
    stage=rd.ShaderStage.Compute
    ctl.SetFrameEvent(event,True)
    pipe=ctl.GetPipelineState()
    trace=pipe.GetShaderReflection(stage)
    assert digest(bytes(trace.rawBytes))==req['shader'] and legacy['event']==event
    bindings=lambda reflection,res,access:{getattr(reflection,access)[r.access.index].fixedBindNumber:r.descriptor.resource for r in res}
    bound=bindings(trace,pipe.GetReadOnlyResources(stage),'readOnlyResources')
    writes=bindings(trace,pipe.GetReadWriteResources(stage),'readWriteResources')
    captures={r['name']:r for r in legacy['inputs']+legacy['outputs']}
    expect=lambda name:captures[name]['resource']
    assert [str(bound[k]) for k in (2,4,6,7)]==[expect(n) for n in ('previousColor','currentDepth','surfaceMask','normalRoughness')]
    expected_prepare={1:expect('currentDepth'),2:expect('normalRoughness'),3:expect('surfaceMask'),4:expect('outputConfidence')}
    assert str(writes[11])==expected_prepare[4]
    depth=bound[4]
    all_actions={}
    structured=ctl.GetStructuredFile()
    def walk(actions,groups):
        for a in actions:
            if a.eventId>=event: continue
            name=a.GetName(structured)
            all_actions[a.eventId]=(a,name,groups)
            if a.children: walk(a.children,groups+[name])
    walk(ctl.GetRootActions(),[])
    options=[r.eventId for r in ctl.GetUsage(depth) if r.eventId in all_actions and all_actions[r.eventId][0].flags&rd.ActionFlags.Dispatch]
    assert options, [str(r.usage) for r in ctl.GetUsage(depth)]
    prep=[]
    for eid in sorted(set(options),reverse=True)[:8]:
        ctl.SetFrameEvent(eid,True)
        pipe=ctl.GetPipelineState()
        shader=pipe.GetShaderReflection(stage)
        if shader is None:continue
        ro=bindings(shader,pipe.GetReadOnlyResources(stage),'readOnlyResources')
        rw=bindings(shader,pipe.GetReadWriteResources(stage),'readWriteResources')
        if {i:str(v) for i,v in rw.items()}!=expected_prepare or set(ro)!={0}:continue
        prep.append((eid,ro[0],digest(bytes(shader.rawBytes))))
    assert len(prep)==1,[(eid,str(image),sha) for eid,image,sha in prep]
    peid,surface,shader=prep[0]
    textures={str(t.resourceId):t for t in ctl.GetTextures()}
    desc=textures[str(surface)]
    assert (desc.width,desc.height,desc.format.Name())==(2560,1440,'R32G32B32A32_FLOAT')
    candidates=[r.eventId for r in ctl.GetUsage(surface)
                if r.eventId<peid and r.eventId in all_actions and r.usage==rd.ResourceUsage.ColorTarget]
    assert candidates,[(r.eventId,str(r.usage)) for r in ctl.GetUsage(surface) if r.eventId<=peid]
    writer=max(candidates)
    ctl.SetFrameEvent(writer,True)
    pipe=ctl.GetPipelineState()
    outputs=[o.resource for o in pipe.GetOutputTargets()]
    assert len(outputs)>=2 and outputs[1]==surface and outputs[0]!=prior_resource
    curr=outputs[0]
    d=textures[str(curr)]
    assert (d.width,d.height,d.format.Name())==(2560,1440,'R16G16B16A16_FLOAT')
    ctl.SetFrameEvent(event,True)
    curhash,current=at(rd,ctl,curr,2560,1440,samples)
    prhash,prior=at(rd,ctl,prior_resource,2560,1440,samples)
    assert prhash==proof['sourceInputs']['player']
    assert all(prior[k][:3]==v for k,v in samples.items())
    return dict(status='qualified-current-snapshot-source',traceEvent=event,prepareEvent=peid,prepareShader=shader,
        prepareWrites=expected_prepare,currentSurfaceResource=str(surface),currentColorResource=str(curr),
        priorColorResource=str(prior_resource),currentColorSha256=curhash,previousColorSha256=prhash,
        currentColorLastSurfaceWriter=dict(event=writer,name=all_actions[writer][1],groups=all_actions[writer][2]),
        samples=[dict(previousPixelXY=list(k),currentColor=current[k],previousColor=prior[k]) for k in sorted(samples)])


KEY='AZURE_NR_HISTORY_PLAYER_LINEAGE'
run=Path(os.environ[KEY]).parents[1] if KEY in os.environ else Path(__file__).resolve().parent
out=run/'projected-history-player-lineage'
write=lambda p,r:p.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')


def main_targets(rd,ctl,event,points,current,prior):
    actions={}
    structured=ctl.GetStructuredFile()
    def walk(group,parents):
        for a in group:
            name=a.GetName(structured)
            actions[a.eventId]=(name,parents)
            if a.children: walk(a.children,parents+[name])
    walk(ctl.GetRootActions(),[])
    result={}
    for t in ctl.GetTextures():
        if (t.width,t.height,t.format.Name())!=(2560,1440,'R16G16B16A16_FLOAT'):continue
        if str(t.resourceId) in (current,prior):continue
        usage=list(ctl.GetUsage(t.resourceId))
        writers=sorted({u.eventId for u in usage if u.eventId>event and u.eventId in actions
                        and u.usage==rd.ResourceUsage.ColorTarget})
        if not writers:continue
        rendered={}
        for e in sorted(set((writers[0],writers[-1]))):
            label,parents=actions[e]
            ctl.SetFrameEvent(e,True)
            assert t.resourceId in [bound.resource for bound in ctl.GetPipelineState().GetOutputTargets()]
            fingerprint,values=at(rd,ctl,t.resourceId,2560,1440,points)
            rendered[str(e)]=dict(label=label,groups=parents,sha256=fingerprint,
                 colors=[values[p] for p in points])
        result[str(t.resourceId)]=dict(drawCount=len(writers),readersAfterFinalWrite=[
            dict(event=u.eventId,usage=str(u.usage),action=actions.get(u.eventId))
            for u in usage if u.eventId>writers[-1]],writes=rendered)
    assert result
    return result


def data():
    req=runpy.run_path(str(run/'projected-history-source-replay.py'))['request']('player')
    proof=run/'projected-history-coordinates/history-source-producer-witnesses.json'
    assert read(proof)['status']=='prepared-fixed-address-history-stage-witnesses'
    req['witnessesSha256']=digest(proof.read_bytes())
    return req


def filter_sample(rd,ctl,req):
    archive=Path(req['capture']).parents[1]
    receipt=read(archive/'filter-parameters/summary.json')
    expected_shader=read(archive/'filter-parameters/request.json')['shaderSha256']
    assert receipt['status']=='verified'
    event,=[r['event'] for r in receipt['events']]
    assert event==21729 and event>req['event']
    ctl.SetFrameEvent(event,True)
    pipe=ctl.GetPipelineState();stage=rd.ShaderStage.Compute
    sh=pipe.GetShaderReflection(stage)
    assert digest(bytes(sh.rawBytes))==expected_shader
    uniforms=pipe.GetConstantBlock(stage,0,0)
    assert uniforms.descriptor.byteSize>=64
    start=uniforms.descriptor.byteOffset
    raw=bytes(ctl.GetBufferData(uniforms.descriptor.resource,start,64))
    expected=tuple(v for r in receipt['events'][0]['rows'] for v in r)
    assert struct.unpack('<16f',raw)==expected
    images={sh.readWriteResources[r.access.index].fixedBindNumber:r.descriptor.resource for r in pipe.GetReadWriteResources(stage)}
    output=images[4]
    tx,=[i for i in ctl.GetTextures() if i.resourceId==output]
    assert (tx.width,tx.height,tx.format.Name())==(1280,720,'R32G32B32A32_FLOAT')
    p=bytes(ctl.GetTextureData(output,rd.Subresource()))
    assert len(p)==1280*720*16
    pixels=[(x,y) for y in range(7,720,11) for x in range(3,1280,17)]
    payload=b''.join(struct.pack('<HH',x,y)+p[16*(y*1280+x):16*(y*1280+x)+16] for x,y in pixels)
    (out/'filter-samples.bin').write_bytes(payload)
    return dict(event=event,resource=str(output),shaderSha256=digest(bytes(sh.rawBytes)),
        fullOutputSha256=digest(p),sampleSha256=digest(payload),samples=len(pixels),
        layout='little-endian uint16 x,y followed by four float32 values',parameters=receipt['events'][0]['rows'])


def worker(p):
    import renderdoc as rd
    result=dict(status='unqualified')
    cap=rd.OpenCaptureFile();ctl=None
    try:
        req=read(p)
        result['request']=req
        write(out/'progress.json',dict(stage='opening-file',event=req['event']))
        assert cap.OpenFile(req['capture'],'',None)==rd.ResultCode.Succeeded
        write(out/'progress.json',dict(stage='opening-capture',event=req['event']))
        status,ctl=cap.OpenCapture(rd.ReplayOptions(),None)
        assert status==rd.ResultCode.Succeeded and ctl is not None
        assert str(ctl.GetAPIProperties().pipelineType)=='GraphicsAPI.Vulkan'
        event=req['event']
        ctl.SetFrameEvent(event,True)
        stage=rd.ShaderStage.Compute
        pipe=ctl.GetPipelineState()
        sh=pipe.GetShaderReflection(stage)
        prior,=[r.descriptor.resource for r in pipe.GetReadOnlyResources(stage)
                if sh.readOnlyResources[r.access.index].fixedBindNumber==2]
        assert str(prior)==req['inputs'][0]['resource']
        assert req['witnessesSha256']==digest((run/'projected-history-coordinates/history-source-producer-witnesses.json').read_bytes())
        write(out/'progress.json',dict(stage='snapshot',event=event,prior=str(prior)))
        result['snapshot']=player_snapshot(rd,ctl,req,run,prior)
        write(out/'checkpoint.json',result['snapshot'])
        snapshot=result['snapshot']
        try:
            result['mainTargets']=main_targets(rd,ctl,event,[tuple(r['previousPixelXY']) for r in snapshot['samples']],
                                                snapshot['currentColorResource'],snapshot['priorColorResource'])
        except Exception:
            result['mainTargetsError']=traceback.format_exc()
        try:
            result['filteredColorControl']=filter_sample(rd,ctl,req)
        except Exception:
            result['filteredColorControlError']=traceback.format_exc()
        result['status']='qualified-player-snapshot-producer'
    except BaseException:
        result['error']=traceback.format_exc()
    finally:
        write(out/'results.json',result)
        if ctl is not None:ctl.Shutdown()
        cap.Shutdown()
    os._exit(0 if result['status'].startswith('qualified') else 1)


def launch():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and lease['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9' and Path(lease['output'])==run
    sys.path.insert(0,str(run.parents[2]/'tools'))
    from artifact_budget import check
    budget=check(run.parents[1],run=run,planned=1_200_000)
    assert budget['allowed'],budget
    out.mkdir(exist_ok=True)
    p=out/'request.json';write(p,data())
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    with (out/'replay.log').open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
                      cwd=out,env=dict(os.environ,**{KEY:str(p)}),stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=180)
    r=read(out/'results.json')
    assert child.returncode==0 and r['request']==read(p) and r['status']=='qualified-player-snapshot-producer',r.get('error')
    print(r['status'],r['snapshot']['prepareEvent'],r['snapshot']['currentColorLastSurfaceWriter'],
          len(r['snapshot']['samples']),list(r.get('mainTargets',{})),r.get('mainTargetsError',''))


if KEY in os.environ:
    worker(os.environ[KEY])
elif __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(json.dumps(data(),indent=2))
    else:
        assert sys.argv[1:]==['run']
        launch()
