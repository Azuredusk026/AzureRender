"""Controlled production candidate: one sample phase mapping on the 32-step control."""
import difflib
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import sys

import cv2
import numpy as np

M=Path(__file__).resolve().parent
S=runpy.run_path(str(M/'projected-reflection-32-step-candidate.py'),run_name='paired_step_controls')
retained=S['OUT']
out=M/'projected-reflection-native-phase-candidate'
programs=out/'programs'
read,write,sha=[S[k] for k in ('READ','write','sha')]
capture=S['run_capture']
phase_note=M/'projected-history-coordinates/player-trace-phase-cpu.json'


def input_controls():
    current=S['sources']()
    prior=read(retained/'candidate-receipt.json')
    # This experiment retains the original program while the worktree develops a separate candidate.
    if current['source']!=prior['provenance']['source']:
        archived=subprocess.check_output(['git','show',
            '88fd73c:Project/AzureRender/shaders/projected_reflection_trace.hlsl'],cwd=S['W'])
        candidates=[archived,archived.replace(b'\n',b'\r\n')]
        original,=[entry for entry in candidates if hashlib.sha256(entry).hexdigest()==prior['provenance']['source']]
        current['source']=hashlib.sha256(original).hexdigest()
    else:
        original=(S['W']/'shaders/projected_reflection_trace.hlsl').read_bytes()
    assert current==prior['provenance'] and prior['program']['control']==current['baselineShader']
    phase=read(phase_note)
    assert phase['status']=='cpu-trace-phase-control'
    for name in ('centerFloor','cyanRing'):
        old=phase['cases']['32-0-False'][name]['sameFixedNativeColorControl']
        new=phase['cases']['32-42-True'][name]['sameFixedNativeColorControl']
        assert old['sharedSamples']==new['sharedSamples']
        assert new['lumaMeanAbs']<old['lumaMeanAbs'] and new['distancePixelsMedianP90P99'][1]<old['distancePixelsMedianP90P99'][1]
    native=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261029-052336-native-hierarchical-reflection-52b603/event-8702.json')
    assert sha(native)==current['nativeEventConstants']
    phase_seed,_,_,_=read(native)['blocks'][2]['variables'][1]['float32']
    assert phase_seed==42.
    text=original.decode('utf8').replace('\r\n','\n')
    assert text.count('stepConfig.xxxx')==2
    variant=text.replace('stepConfig.xxxx',f'min(stepConfig.xxxx,{float(current["candidateMaximumSteps"]):.1f})')
    file=retained/'projected_reflection_trace-32.hlsl'
    assert file.read_text(encoding='utf8')==variant and sha(file)==prior['program']['source']
    assert sha(retained/'programs'/S['SHADER'])==prior['program']['binary']
    return current,prior,phase_seed


def program(source,seed):
    start='float4 v84=trunc(traceConfig.xxxx);r3.w=asuint(v84).w;'
    offset='float4 v85=mad(asfloat(r3.wwww),asfloat(uint4(0x00000000u,0x40054fdfu,0x409bbe77u,0x00000000u)),asfloat(r1.yyzy));r1.yz=asuint(v85).yz;'
    assert source.count(start)==1 and source.count(offset)==1
    mapped_seed=f'float4 v84=trunc(float4({seed:.1f},{seed:.1f},{seed:.1f},{seed:.1f}));r3.w=asuint(v84).w;'
    mapped_offset=('float4 qaPhaseCenter=asfloat(r1.yyzy);qaPhaseCenter.z=traceSize.y-qaPhaseCenter.z;\n'
                   +offset.replace('asfloat(r1.yyzy)','qaPhaseCenter'))
    candidate=source.replace(start,mapped_seed).replace(offset,mapped_offset)
    assert candidate.replace(mapped_seed,start).replace(mapped_offset,offset)==source
    return candidate


def controls(provenance,baseline_program):
    choices={'production':('baseline',baseline_program['control']),'phaseControl32':('candidate',baseline_program['binary'])}
    retained_pairs={}
    for gpu in ('nvidia','intel'):
        dev={}
        for tag,(label,expected) in choices.items():
            root=retained/f'{label}-{gpu}'
            rec=S['read_checkpoint'](root/'result.json',root,expected)
            assert rec and rec['device']==gpu and rec['mode']==label
            assert rec['driver']==read(root/'frames/gpu_capabilities.json')['driver_version']
            assert sha(root/'runtime.json')==rec['runtime']
            manifest=read(root/'frames/capture_manifest.json')
            assert manifest['screenReflectionHistoryValid'] and manifest['screenReflectionHistoryInputSubmission']==2
            assert '--project' in rec['command'] and provenance['project'] in rec['command']
            dev[tag]=(root,rec)
        retained_pairs[gpu]=dev
    return retained_pairs


def evaluate(a,b,gold):
    def counts(a,b,gold):
        da=abs(a.astype(np.int16)-gold).max(axis=-1)
        db=abs(b.astype(np.int16)-gold).max(axis=-1)
        return dict(baselineOverOne=int((da>1).sum()),candidateOverOne=int((db>1).sum()),
                    newlyOverOne=int(((da<=1)&(db>1)).sum()),recovered=int(((da>1)&(db<=1)).sum()),
                    changed=int(np.any(a!=b,axis=-1).sum()))
    rows={}
    for name,(x,y,u,v) in S['regions'].items():
        p,q,g=[img[y:v,x:u] for img in (a,b,gold)]
        rows[name]=dict(baseline=S['score'](p,g),candidate=S['score'](q,g),pixels=counts(p,q,g))
    return rows


def check_control(source,shader):
    out.mkdir(exist_ok=True)
    path=out/'control-32.comp.spv'
    t=S['PYTOOLS']
    subprocess.run([str(t/'dxc.exe'),*S['ARGS'],'-Fo',str(path),str(source)],check=True,timeout=45)
    subprocess.run([str(t/'spirv-val.exe'),'--target-env','vulkan1.1',str(path)],check=True,timeout=30)
    assert sha(path)==shader
    return sha(path)


def compile_candidate(prior,seed):
    source=retained/'projected_reflection_trace-32.hlsl'
    text=source.read_text(encoding='utf8')
    t=S['PYTOOLS']
    previous=check_control(source,prior['program']['binary'])
    modified=program(text,seed)
    local=out/'projected_reflection_trace-32-native-phase.hlsl'
    local.write_text(modified,encoding='utf8')
    delta=''.join(difflib.unified_diff(text.splitlines(keepends=True),modified.splitlines(keepends=True),
        fromfile='trace-32-step',tofile='trace-32-step-native-phase'))
    (out/'phase-only.diff').write_text(delta,encoding='utf8')
    programs.mkdir(exist_ok=True)
    dest=programs/S['SHADER']
    subprocess.run([str(t/'dxc.exe'),*S['ARGS'],'-Fo',str(dest),str(local)],check=True,timeout=45)
    subprocess.run([str(t/'spirv-val.exe'),'--target-env','vulkan1.1',str(dest)],check=True,timeout=30)
    assert sha(dest)!=previous
    return dict(baseline32=previous,candidate=sha(dest),candidateSource=sha(local),patch=sha(out/'phase-only.diff'),
                seed=seed,yAxis='height minus Vulkan pixel center',compiler=sha(t/'dxc.exe'),arguments=S['ARGS'])


def snapshots(gpu, record, baseline, reference):
    folder=out/f'candidate-{gpu}'
    assert record['device']==gpu
    paired={}
    a=read(folder/'frames/capture_manifest.json')
    for variant,(base,receipt) in baseline.items():
        d=read(base/'frames/capture_manifest.json')
        assert record['driver']==receipt['driver'],(gpu,record['driver'],receipt['driver'])
        assert all(a[k]==d[k] for k in S['forbid'])
        frames=[]
        for i in range(3):
            p,n=[s/'frames'/f'frame_{i:06d}.png' for s in (base,folder)]
            assert sha(p)==receipt['images'][i] and sha(n)==record['images'][i]
            frames.append(evaluate(S['img'](p),S['img'](n),reference))
        paired[variant]=dict(source=receipt,frames=frames)
    return dict(candidate=record,**paired)


def run():
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9' and lock['state']=='held' and Path(lock['output'])==M
    sys.path.insert(0,str(S['W']/'tools'))
    from artifact_budget import check
    budget=check(M.parents[1],run=M,planned=39_000_000)
    assert budget['allowed'],budget
    cv2.setNumThreads(1)
    provenance,prior,seed=input_controls()
    previous=controls(provenance,prior['program'])
    stage=compile_candidate(prior,seed)
    write(out/'candidate-receipt.json',dict(source=provenance,program=stage,cpuEvidence=sha(phase_note)))
    ref_path=S['inputs_phase']['replay']
    assert sha(ref_path)==S['golden']['frames']['gameBackbuffer']['sha256']
    reference=S['img'](ref_path)
    capture.__globals__['OUT']=out
    devices={}
    for gpu in ('nvidia','intel'):
        with S['catalog']['activate']({S['SHADER']:stage['candidate']},alternate_run=M,source_dir=programs):
            record=capture(gpu,'candidate',provenance,stage['candidate'])
        devices[gpu]=snapshots(gpu,record,previous[gpu],reference)
        write(out/'checkpoint.json',devices)
    assert input_controls()==(provenance,prior,seed)
    verdict={k:S['assess']({gpu:data[k] for gpu,data in devices.items()})
             for k in ('production','phaseControl32')}
    for k,row in verdict.items():
        strict=((region['candidate']['peak']<=1 and region['pixels']['newlyOverOne']==0)
                for device in devices.values() for frame in device[k]['frames']
                for region in frame.values())
        row['qualifiedRgbGate']=all(strict)
    write(out/'results.json',dict(status='measured-two-device-native-sample-phase',scope='Joint Player fixed scene; one phase mapping on measured 32 step control.',
        program=stage, source=provenance, devices=devices, verdict=verdict, originalFrozenRgbRequired=True))
    print(json.dumps({k:{v:entry[v] for v in ('allFormalFloorGates','allPairsPositive','noIntroducedNeighborErrors','qualifiedRgbGate')}
                      for k,entry in verdict.items()}),flush=True)


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        a,b,seed=input_controls()
        c=controls(a,b['program'])
        fixed=program((retained/'projected_reflection_trace-32.hlsl').read_text('utf-8'),seed)
        assert 'traceSize.y-qaPhaseCenter.z' in fixed and 'min(stepConfig.xxxx,32.0)' in fixed
        print(json.dumps(dict(phase=seed,base=b['program']['binary'],cpuEvidence=sha(phase_note),devices=list(c))))
    else:
        assert sys.argv[1:]==['run']
        run()
