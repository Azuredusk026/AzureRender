"""Distinguish depth comparison and primitive coverage at the Intel hair-shadow sample."""
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
B=W/'build'
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
G=M.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
C=R/'face-quality-release-isolated-mask'
F=G/'iris-overlay-geometry-project'
mode='depth-bypass'
O=M/'readonly-face-overlay-witness-depth-bypass'
old_player=M/'projected-history-layer-release/AzurePlayerCaptureFaceFixture.exe'
environment=('AZR_NR_QA_OVERLAY_ROOT','AZR_NR_QA_OVERLAY_SCENE')
tag='face-quality-native-production-combined'
variants=tuple(f'mesh{obj}{ending}.frag.spv' for obj in ('','_object')
        for ending in ('','_early','_lighting','_early_lighting'))
hash_path=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
def write(p,d):
    p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')


def fixture_sources():
    source=C/'public-combined-nvidia'
    exact=read(source/'results.json')['input']['fixture']
    assert exact==read(C/'public-combined-intel/results.json')['input']['fixture']
    mask=source/'recipe/mask/inputs'
    nearest=source/'recipe/nearest/inputs'
    base_mask=M/'assets-sdf/face-native-geometry-mask-sampling-sdf.dds'
    files={}
    for k,v in exact.items():
        relative=Path(k)
        name=relative.name
        if k.startswith('scene/') or relative.parent==Path('.'):
            p=source/name
        elif name.endswith('public-mask.dds'):
            p=base_mask
        elif name.startswith('face-quality-public-mask.'):
            p=mask/name
        elif name.startswith('face-quality-public-nearest.'):
            p=nearest/name
        else:
            p=R/'face-candidate'/name
        assert hash_path(p)==v,(p,v)
        if relative.parent!=Path('.'):
            files[k]=p
    files[f'scene/{tag}.azurelevel.azmeta']=source/(tag+'.azurelevel.azmeta')
    for name in ('late-face-overlay-1230','late-face-overlay-1358'):
        key=f'character/{name}.bin.azmeta'
        assert (F/key).is_file()
        files[key]=F/key
    data=read(files[f'scene/{tag}.azurelevel'])
    rewrites={}
    for resource in data['resources']:
        value=resource['asset']
        if value.startswith('character:/late-face-overlay-'):
            resource['asset']='qa_'+value
            rewrites[value]=resource['asset']
    assert len(rewrites)==2
    assert sum(p.stat().st_size for p in files.values())<500_000
    return files,data,rewrites


def collect_sources():
    shader='Project/AzureRender/shaders/mesh.frag'
    r=read(C/'test-receipt.json')
    canonical=subprocess.check_output(['git','show','3923ae9:'+shader],cwd=W)
    assert r['shaderSource'] in {sha256(canonical).hexdigest(),sha256(canonical.replace(b'\n',b'\r\n')).hexdigest()}
    older=(M/'assets-tint-base-sdf-pair/mesh-face-geometry-mask.frag').read_text(encoding='utf8')
    lo='vec3 materialNprLitAlbedo('
    hi='CharacterDiffuseResponse materialNprDiffuseResponse('
    assert all(item.count(lo)==item.count(hi)==1 for item in (older,canonical.decode()))
    replacement=older[older.index(lo):older.index(hi)]
    assert 'mix(1.0,.7,mask.b)' in replacement and 'AZ_TEX_STYLE_MASK' in replacement
    source=canonical.decode()
    original=source[source.index(lo):source.index(hi)]
    assert 'maskPolicy.y' in original
    texture_function='float authoredFaceGeometryMask(sampler2D mask, vec2 uv) {'
    i=source.index(texture_function)
    j=source.index('\n}',i)+2
    sampler=source[i:j].replace(texture_function,'vec4 authoredFaceTintMask(sampler2D mask, vec2 uv) {')
    sampler=sampler.replace('float bottom=', 'vec4 bottom=').replace('float top=', 'vec4 top=')
    assert sampler.count('level).g')==4
    sampler=sampler.replace('level).g','level)')
    blend_sample='vec3 mask=azureSamplePrimaryUv(AZ_TEX_STYLE_MASK,textureCoordinate).rgb;'
    assert replacement.count(blend_sample)==1
    replacement=replacement.replace(blend_sample,'bool authored=materialSurfaceProfiles.profiles[profileIndex].rows[20].z>.5;\n        vec3 mask=authored?authoredFaceTintMask(AZ_TEX_STYLE_MASK,textureCoordinate).rgb\n                         :azureSamplePrimaryUv(AZ_TEX_STYLE_MASK,textureCoordinate).rgb;')
    edited=source.replace(original,sampler+'\n'+replacement)
    before='    outputColor=azureMaterialOutputPrecision(outputColor,materialFeatureEnabled(67108864U)>.5);'
    after='    outputColor=azureMaterialOutputPrecision(outputColor,materialFeatureEnabled(67108864U)>.5 || (dualFaceSdf&&qaIsolationMode==0));'
    assert edited.count(before)==1
    edited=edited.replace(before,after)
    marker='    ivec2 inspectPixel=ivec2(AZURE_FRAGMENT_COORD.xy);\n    bool markerPixel=(all(lessThanEqual(abs(inspectPixel-ivec2(1264,261)),ivec2(5))) ||\n                      all(lessThanEqual(abs(inspectPixel-ivec2(1321,271)),ivec2(5)))) && qaIsolationMode==0;\n    if(multiplyComposite) {'
    original_branch='    if(multiplyComposite) {'
    assert edited.count(original_branch)==1
    edited=edited.replace(original_branch,marker)
    clip='            if(!receiverMatches || texelFetch(overlaySceneDepth,pixel,0).r>=100000.0)discard;'
    assert edited.count(clip)==1
    if mode=='depth-bypass':
        edited=edited.replace(clip,'            if((!receiverMatches || texelFetch(overlaySceneDepth,pixel,0).r>=100000.0) && !markerPixel)discard;')
    shade='        outputColor.rgb=mix(vec3(1.0),outputColor.rgb,compositeCoverage);'
    assert edited.count(shade)==1
    edited=edited.replace(shade,shade+'\n        if(markerPixel)outputColor.rgb*=vec3(.4,.5,.6);')
    edited=edited.replace('        if(markerPixel)outputColor.rgb*=vec3(.4,.5,.6);','        if(markerPixel){outputColor.rgb*=vec3(.4,.5,.6);gl_FragDepth=0.;}')
    early='layout(early_fragment_tests) in;'
    start='    azurePreparePrimaryUv(textureCoordinate);'
    assert edited.count(early)==edited.count(start)==1
    edited=edited.replace(early,'')
    edited=edited.replace(start,'    gl_FragDepth=gl_FragCoord.z;\n'+start)
    return canonical,edited,r


def store_delta(dest,ref,candidate):
    p=dest/'frame-xor.zip'
    with ZipFile(p,'x',ZIP_DEFLATED,compresslevel=9) as out:
        out.writestr('frame.bgra-xor',np.bitwise_xor(ref,candidate).tobytes())
    with ZipFile(p) as out:
        assert out.testzip() is None
        restored=ref^np.frombuffer(out.read('frame.bgra-xor'),np.uint8).reshape(ref.shape)
        assert np.array_equal(restored,candidate)
    return hash_path(p)


def run():
    sys.path.insert(0,str(W/'tools'))
    import artifact_maintenance as art
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    assert check(B,run=M,planned=7_200_000)['allowed']
    build=read(M/'readonly-face-fixture-source/qualification.json')
    assert hash_path(old_player)==build['candidatePlayer'] and build['readOnlyProjectAssets']
    files,scene,rewrites=fixture_sources()
    O.mkdir(exist_ok=True)
    fixture=O/'fixture'
    for directory in ('scene','materials','character'):
        (fixture/directory).mkdir(parents=True,exist_ok=True)
    level=f'scene/{tag}.azurelevel'
    input_before={}
    for name,source in files.items():
        p=fixture/name
        input_before[str(source)]=hash_path(source)
        if name==level:
            write(p,scene)
        else:
            p.write_bytes(source.read_bytes())
            assert hash_path(p)==input_before[str(source)]
    canonical,edited,test=collect_sources()
    source=O/'mesh.frag'
    source.write_text(edited,encoding='utf8')
    headers=subprocess.check_output(['git','show','3923ae9:Project/AzureRender/shaders/unlit_blend.glsl'],cwd=W)
    (O/'unlit_blend.glsl').write_bytes(headers)
    original=O/'original-mesh.frag'
    original.write_bytes(canonical)
    programs=O/'programs'
    programs.mkdir(exist_ok=True)
    helpers=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='face_tint_program')
    compiler=helpers['H']['compile_program']
    for name in variants:
        compiler(source,programs/name,name,diagnostics=O/'compile'/f'{name}.log')
    programs_changed={name:hash_path(programs/name) for name in variants}
    os.environ['AZURE_NR_FACE_RELEASE_STAGE']=C.name
    catalog=runpy.run_path(str(R/'face-quality-candidate-catalog.py'),run_name='face_tint_checked_catalog')
    helper=runpy.run_path(str(R/'face-quality-production.py'),run_name='face_tint_capture_tool')
    invoke=helper['helper']['invoke']
    native_path=Path(helper['score']['reference_path'])
    native=cv2.imread(str(native_path),-1)
    face=cv2.imread(str(G/'native-face-masks/face.png'),0)>0
    eye=cv2.imread(str(G/'native-face-masks/iris.png'),0)>0
    assert native.shape[:2]==(1440,2560) and native.shape[2] in (3,4) and np.count_nonzero(face)==3663 and eye.any(),(native.shape,np.count_nonzero(face),np.count_nonzero(eye))
    group=read(M/'public-face-remaining-owner-residual.json')
    region=[{tuple(item['point']) for item in group['devices'][k]['opaqueEdge'][1]['aboveEight']}
            for k in ('nvidia','intel')]
    x,y=np.array(sorted(set.intersection(*region))).T
    assert len(x)==49
    original_catalog=test['compiledPrograms']
    retained=catalog['retained_catalog'](R)
    baseline_shaders=retained|original_catalog
    assert set(programs_changed)<=set(baseline_shaders)
    with art.database(B) as data:
        pinned=art.rows(data)[R.name]
    assert pinned['status']=='closed'

    qualified=W/'docs/acceptance/nr/evidence/2026-11-16/face-combined-native-tint'
    measured=read(qualified/'qualification.json')
    assert hash_path(qualified/'validation.zip')==measured['archiveSha256']
    assert measured['executable']==hash_path(old_player) and measured['inputs']==input_before
    diagnostics={}
    for device in ('nvidia','intel'):
        prior=measured['samples'][f'{device}-control']
        reference=C/f'public-combined-{device}/frames/frame_000000.png'
        assert prior['changed']==0 and prior['png']==prior['control']==hash_path(reference)
        diagnostics[f'{device}-control']=prior
    out=O/'qualification.json'
    def capture(device,mode,root):
        assert check(B,run=M,planned=2_040_000)['allowed']
        reference=C/f'public-combined-{device}'
        control_path=reference/'frames/frame_000000.png'
        assert hash_path(control_path)==group['frames'][device]['candidate']
        ctrl=cv2.imread(str(control_path),-1)
        assert ctrl.shape[:2]==native.shape[:2] and ctrl.shape[2] in (3,4),ctrl.shape
        dest=O/f'{device}-{mode}'
        dest.mkdir()
        args=read(reference/'command.json')
        args[0]=str(old_player)
        for name,value in {'--project':F/'eye-shadow-authored-tint.azureproject',
                           '--resource-root':root,'--runtime-report':dest/'runtime.json',
                           '--capture-dir':dest/'frames'}.items():
            args[args.index(name)+1]=str(value)
        assert not any(k in os.environ for k in environment)
        os.environ.update(zip(environment,(str(fixture),tag+'.azurelevel')))
        try:
            frame=invoke(device,args,dest)/'frame_000000.png'
        finally:
            for k in environment:
                os.environ.pop(k,None)
        runtime=read(dest/'runtime.json')
        assert not runtime['scriptErrors'] and not runtime['presentationErrors']
        log=(dest/'player.log').read_text('utf8',errors='replace')
        assert 'Fixed-step capture fixture:' in log and 'Character texture access: fixed' in log
        before=read(reference/'frames/capture_manifest.json')
        after=read(dest/'frames/capture_manifest.json')
        for key in ('width','height','qaCamera','qaLight','screenReflectionProducer','objectShadowPrepared'):
            assert before.get(key)==after.get(key),key
        actual=cv2.imread(str(frame),-1)
        assert actual.shape==ctrl.shape
        delta=np.abs(actual[:,:,:3].astype(np.int16)-ctrl[:,:,:3]).max(2)
        base_error=np.abs(ctrl[:,:,:3].astype(np.int16)-native[:,:,:3]).max(2)
        error=np.abs(actual[:,:,:3].astype(np.int16)-native[:,:,:3]).max(2)
        row=dict(raw=sha256(actual.tobytes()).hexdigest(),png=hash_path(frame),control=hash_path(control_path),
                 deltaArchive=store_delta(dest,ctrl,actual),
                 changed=int(np.count_nonzero(delta)),outsideFace=int(np.count_nonzero(delta[~face])),
                 irisChanged=int(np.count_nonzero(delta[eye])),
                 face=dict(overOne=int(np.count_nonzero(error[face]>1)),overEight=int(np.count_nonzero(error[face]>8)),
                    peak=int(error[face].max()),newOverOne=int(np.count_nonzero((error[face]>1)&(base_error[face]<=1)))),
                 trackedFaceEdge=dict(improved=int(np.count_nonzero(error[y,x]<base_error[y,x])),
                    worsened=int(np.count_nonzero(error[y,x]>base_error[y,x])),peak=int(error[y,x].max())))
        assert frame.resolve()==frame and not frame.stat().st_file_attributes&1024
        assert hash_path(frame)==row['png']
        frame.unlink()
        diagnostics[f'{device}-{mode}']=row
        write(out,dict(status='capturing',samples=diagnostics))
        print(device,mode,row,flush=True)
        if mode=='control':
            assert np.array_equal(ctrl,actual),row
        else:
            assert row['changed']>0,row

    art.resume(B,R.name)
    try:
        with catalog['activate'](original_catalog,alternate_run=M) as resources:
            replaced=[]
            try:
                for name in variants:
                    target=resources/'shaders'/name
                    saved=target.with_name(target.name+'.face-tint-original')
                    assert hash_path(target)==baseline_shaders[name] and not saved.exists()
                    target.replace(saved)
                    replaced.append((target,saved))
                    target.hardlink_to(programs/name)
                    assert hash_path(target)==programs_changed[name]
                for device in ('nvidia','intel'):
                    capture(device,'native-tint',resources)
            finally:
                for target,saved in reversed(replaced):
                    assert hash_path(saved)==baseline_shaders[target.name]
                    saved.replace(target)
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=90)
    with art.database(B) as data:
        end=art.rows(data)[R.name]
    assert end['status']=='closed' and end['manifestSha256']==pinned['manifestSha256']
    assert all(hash_path(Path(p))==v for p,v in input_before.items())
    write(out,dict(status='paired-full-frame-captures',productionFaceAcceptance=all(
        diagnostics[f'{d}-native-tint']['face']['newOverOne']==0 and
        diagnostics[f'{d}-native-tint']['face']['peak']<=1 and
        diagnostics[f'{d}-native-tint']['outsideFace']==diagnostics[f'{d}-native-tint']['irisChanged']==0
        for d in ('nvidia','intel')),
        executable=hash_path(old_player),inputs=input_before,pathRewrites=rewrites,
        source=hash_path(original),diagnosticSource=hash_path(source),changedPrograms=programs_changed,tintConsumer=mode,samples=diagnostics))


if __name__=='__main__':
    run()
