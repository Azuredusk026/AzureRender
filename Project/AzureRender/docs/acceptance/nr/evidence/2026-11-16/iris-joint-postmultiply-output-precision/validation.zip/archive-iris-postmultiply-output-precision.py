from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
G=M.parent/'20261112-231945-projected-hair-reference-grid-4b775d'
S=G/'native-iris-stages'
O=M/'readonly-face-covered-iris-multiply-output-precision'
E=W/'docs/acceptance/nr/evidence/2026-11-16/iris-joint-postmultiply-output-precision'
N=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-cloth-reference.png')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())

result=read(O/'qualification.json')
assert result['status']=='paired-full-frame-iris-captures' and not result['productionIrisAcceptance']
assert len(result['changedPrograms'])==20
for name,want in result['changedPrograms'].items():
    assert digest(O/'programs'/name)==want
points=np.fromfile(S/'points.bin','<u4').reshape(255,2)
x,y=points.T
native=cv2.imread(str(N),-1)[y,x,2::-1]
stages=read(S/'native-iris-stages.json')
events={}
files={Path(__file__):Path(__file__).name,M/'readonly-face-covered-iris-multiply-output-precision.py':'capture.py',
       M/'retest-covered-iris-postmultiply-output-precision.log':'dispatch.log',O/'mesh.frag':'mesh.frag',
       S/'points.bin':'native-points.bin',S/'native-iris-stages.json':'native-stages.json'}
for key,row in stages['stages'].items():
    p=S/f'event-{key}.bin'
    assert digest(p)==row['selectionSha256']
    events[int(key)]=np.fromfile(p,'<u4')
    files[p]='native-'+p.name
composites=(1230,1245,1267,1291,1314,1339,1358,1383)
late={a:events[a]!=events[b] for b,a in zip(composites,composites[1:])}
coverage=late[1245]
assert np.count_nonzero(coverage)==94

rows={}
for d,expected in {'nvidia':(52,1,0,0,1),'intel':(56,10,1,5,5)}.items():
    case=d+'-native-tint'
    af=O/case
    c=R/f'face-quality-release-isolated-mask/public-combined-{d}/frames/frame_000000.png'
    sample=result['samples'][case]
    assert digest(c)==sample['control']
    ctrl=cv2.imread(str(c),-1)
    z=af/'frame-xor.zip'
    assert digest(z)==sample['deltaArchive']
    with ZipFile(z) as a:
        assert a.testzip() is None
        changed=ctrl^np.frombuffer(a.read('frame.bgra-xor'),np.uint8).reshape(ctrl.shape)
    assert sha256(changed.tobytes()).hexdigest()==sample['raw']
    prior=M/'readonly-face-covered-iris-framed-projected-native-precision'
    prior_report=read(prior/'qualification.json')['samples'][case]
    prior_archive=prior/case/'frame-xor.zip'
    assert digest(prior_archive)==prior_report['deltaArchive']
    with ZipFile(prior_archive) as z0:
        assert z0.testzip() is None
        before_overlay_test=ctrl^np.frombuffer(z0.read('frame.bgra-xor'),np.uint8).reshape(ctrl.shape)
    assert sha256(before_overlay_test.tobytes()).hexdigest()==prior_report['raw']
    before_packed=before_overlay_test[y,x,2::-1].astype(int)
    assert np.array_equal(before_packed[~coverage],changed[y,x,2::-1].astype(int)[~coverage])
    old_test=np.abs(before_packed-native).max(1)
    test_delta=np.abs(changed[y,x,2::-1].astype(int)-native).max(1)
    assert np.count_nonzero((old_test<=1)&(test_delta>1))==0
    before=ctrl[y,x,2::-1].astype(int)
    after=changed[y,x,2::-1].astype(int)
    b=np.abs(before-native).max(1)
    a=np.abs(after-native).max(1)
    covered=int(np.count_nonzero((a>1)&coverage))
    bare=int(np.count_nonzero((a>1)&~coverage))
    assert (int(np.count_nonzero(b>1)),int(np.count_nonzero(a>1)),int(np.count_nonzero((a>1)&(b<=1))),covered,bare)==expected
    assert not any(np.any(late[e]&(a>1)) for e in composites[2:])
    details=[dict(point=points[i].tolist(),before=before[i].tolist(),after=after[i].tolist(),native=native[i].tolist(),
                  beforePeak=int(b[i]),afterPeak=int(a[i]),nativeOverlay=bool(coverage[i])) for i in np.flatnonzero((a>1)|(b>1))]
    rows[d]=dict(coveredOverOne=covered,uncoveredOverOne=bare,lateOverlayOverOne=0,remaining=details)
    for p in (z,af/'frames/capture_manifest.json',af/'command.json',af/'runtime.json',af/'player.log'):
        files[p]=p.relative_to(O).as_posix()
E.mkdir()
archive=E/'validation.zip'
with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as z:
    for path,label in files.items():
        z.write(path,label)
with ZipFile(archive) as z:
    assert z.testzip() is None
result.update(nativeReference=digest(N),nativeOverlayCoverage=94,perPoint=rows,archiveSha256=digest(archive))
(E/'qualification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print({k:(v['coveredOverOne'],v['uncoveredOverOne']) for k,v in rows.items()})
