"""Trace which actual screen-space rays read the varying opaque source texels."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import runpy
import subprocess
import sys
from zipfile import ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
C=M/'joint-character-referenced-body'
O=M/'joint-intel-reflection-donor-membership-protected'
g=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='reflection_donor_catalog')
H,R,B,art,check,read,write,sha=[g[k] for k in ('H','R','B','art','check','read','write','sha')]
body=runpy.run_path(str(M/'joint-character-referenced-body.py'),run_name='reflection_donor_body')
g['activate_links'].__wrapped__.__globals__['home']=O
variants=tuple('mesh_object_clipmap_field'+suffix+'.frag.spv' for suffix in ('','_early','_lighting','_early_lighting'))
traces=('reflection_trace_packed.comp.spv','reflection_trace_float.comp.spv')


def substitute(s,old,new):
    assert s.count(old)==1,old
    return s.replace(old,new)


def masks():
    exact=W/'docs/acceptance/nr/evidence/2026-11-16/joint-intel-reflection-ground-paired-panels'
    record=read(exact/'qualification.json')
    assert sha(exact/'validation.zip')==record['archiveSha256']
    reference=M/'character-six-view-inputs/intel-back-detail/frames/frame_000000.png'
    ref=cv2.imread(str(reference),cv2.IMREAD_UNCHANGED)
    assert ref.shape==(720,1280,4)
    images=[]
    with ZipFile(exact/'validation.zip') as z:
        for tag in record['groundPair']:
            with ZipFile(BytesIO(z.read(f'{tag}/frame-xor.zip'))) as nested:
                actual=ref^np.frombuffer(nested.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
            assert sha256(actual.tobytes()).hexdigest()==record['reads'][tag]['frame']['raw']
            images.append(actual)
    diff=np.any(images[0]!=images[1],axis=2)
    texture=diff[:72,288:384].copy()
    raw=diff[:72,:96].copy()
    ground=diff[608:680,896:992].copy()
    assert (texture.sum(),raw.sum(),ground.sum())==(456,1583,1235)
    half_raw=raw.reshape((36,2,48,2)).any(axis=(1,3))
    return ref,texture,half_raw,ground


def program_sources():
    ref,region,half_raw,ground=masks()
    old_trace=W/'shaders/reflection_trace.comp'
    old_calls=W/'shaders/screen_space_reflection.glsl'
    old_filter=W/'shaders/reflection_spatial_filter.comp'
    old_mesh=W/'shaders/mesh.frag'
    src=O/'compute'
    src.mkdir(parents=True,exist_ok=True)
    coords=region.flatten().reshape((-1,32)).astype(np.uint32)
    words=coords@np.left_shift(np.uint32(1),np.arange(32,dtype=np.uint32))
    assert len(words)==216 and sum(int(v).bit_count() for v in words)==456
    table='\n    '.join(', '.join(f'0x{int(v):08x}U' for v in words[i:i+8])+(',' if i+8<len(words) else '')
                        for i in range(0,len(words),8))
    helper='''const uint auditedFaceOfWall[216]=uint[216](
    TABLE
);
bool insideChangingSource(ivec2 point){
    ivec2 local=point-ivec2(896,160);
    if(any(lessThan(local,ivec2(0)))||any(greaterThanEqual(local,ivec2(96,72))))return false;
    int index=local.y*96+local.x;
    return (auditedFaceOfWall[index/32]&(1U<<uint(index%32)))!=0U;
}
bool insideSourceBounds(ivec2 p){
    return all(greaterThanEqual(p,ivec2(907,170)))&&all(lessThanEqual(p,ivec2(943,215)));
}
vec3 screenReflectionRadiance(sampler2D source,sampler2D depth,vec2 uv,float hitDepth,float thickness){'''.replace('TABLE',table)
    calls=old_calls.read_text(encoding='utf8')
    calls=substitute(calls,'vec3 screenReflectionRadiance(sampler2D source,sampler2D depth,vec2 uv,float hitDepth,float thickness){',helper)
    calls=substitute(calls,'radiance+=texelFetch(source,p,0).rgb*w;total+=w;',
                    'radiance+=vec3(float(insideChangingSource(p)),float(insideSourceBounds(p)),1)*w;total+=w;')
    calls=substitute(calls,'    return total>1e-6?radiance/total:texture(source,uv).rgb;',
                    '''    ivec2 p=clamp(ivec2(floor(uv*vec2(extent))),ivec2(0),extent-1);
    return total>1e-6?radiance/total:vec3(float(insideChangingSource(p)),float(insideSourceBounds(p)),1);''')
    copied=src/old_calls.name
    copied.write_text(calls,encoding='utf8')
    trace=src/old_trace.name
    raw_trace=substitute(old_trace.read_text(encoding='utf8'),
        '        if(frame.viewport.w>.5)value.rgb/=1+max(max(value.r,value.g),value.b);','')
    raw_trace=substitute(raw_trace,'    imageStore(outputColor,p,vec4(value.rgb,1));imageStore(outputConfidence,p,vec4(value.a));',
        '    value.rgb=vec3(greaterThan(value.rgb,vec3(0)));\n    if(p.x==450) value=vec4(1,0,0,1);\n    imageStore(outputColor,p,vec4(value.rgb,1));imageStore(outputConfidence,p,vec4(value.a));')
    trace.write_text(raw_trace,encoding='utf8')
    filter_path=src/old_filter.name
    filter_path.write_text(substitute(old_filter.read_text(encoding='utf8'),
       '    imageStore(resultImage,ivec2(pixel),vec4(color,confidence));',
       '    vec3 reported=texelFetch(pointColor,ivec2(pixel),0).rgb;\n    if(pixel.x==453U) reported=vec3(0,1,0);\n    imageStore(resultImage,ivec2(pixel),vec4(reported,confidence));'),encoding='utf8')
    mesh_path=O/old_mesh.name
    mesh=old_mesh.read_text(encoding='utf8')
    mesh=substitute(mesh,'''    vec3 qaColor = beautyColor;
    if (qaIsolationMode == 1) {''','''    vec3 qaColor = beautyColor;
#if !defined(AZURE_OPAQUE_SNAPSHOT)
    vec2 probe=AZURE_FRAGMENT_COORD.xy;
    if(qaIsolationMode==0 && camera.screenReflectionTrace.x>1.5 &&
       all(greaterThanEqual(probe,vec2(0))) && probe.x<192 && probe.y<72) {
        vec3 flags=vec3(0);
        if(probe.x<96){
            vec3 membership=imageLoad(computedScreenReflection,ivec2(probe)+ivec2(448,272)).rgb;
            flags=vec3(greaterThan(membership,vec3(.5)));
        }else{
            int stripe=int((probe.x-96)/12);
            flags=vec3((stripe&1)!=0,(stripe&2)!=0,(stripe&4)!=0);
        }
        qaColor=vec3(.12)+flags*.62;
    }
#endif
    if (qaIsolationMode == 1) {''')
    mesh_path.write_text(mesh,encoding='utf8')
    return ref,half_raw,ground,mesh_path,trace,filter_path,copied


def run():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    assert check(B,run=M,planned=10_000_000)['allowed']
    ref,raw,ground,mesh,trace,flt,inc=program_sources()
    tools={**{k:mesh for k in variants},**{k:trace for k in traces},'reflection_spatial_filter.comp.spv':flt}
    rules={p['output']:p for p in read(R/'msaa-release/shader-reload.json')['programs']}
    assert all('AZURE_PROBE_FIELD=1' in rules[k]['defines'] for k in variants)
    (O/'programs').mkdir(exist_ok=True)
    programs={}
    for name,path in tools.items():
        H['compile_program'](path,O/'programs'/name,name,diagnostics=O/'compile'/f'{name}.log')
        programs[name]=sha(O/'programs'/name)
    with art.database(B) as db:
        pinned=art.rows(db)[R.name]
    assert pinned['status']=='closed'
    core,asset,_=body['prepare']()
    art.resume(B,R.name)
    label='reflection-donor-membership-protected'
    try:
        with g['activate_links'](programs),body['temporary_descriptor'](asset[1]) as path:
            frame=body['capture']('intel',label,path)
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=90)
    cap=C/f'intel-{label}'
    manifest=read(cap/'frames/capture_manifest.json')
    assert manifest['qaIsolation']=='beauty' and manifest['screenReflectionProducer']=='linear-temporal'
    assert not manifest['screenReflectionHistoryValid'] and manifest['screenReflectionHistoryInputSubmission']==0
    assert (manifest['screenReflectionWidth'],manifest['screenReflectionHeight'])==(640,360)
    with ZipFile(C/f'intel-{label}.zip') as z:
        image=ref^np.frombuffer(z.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
    assert sha256(image.tobytes()).hexdigest()==frame['raw']
    colors=[]
    rates=[]
    for i in range(8):
        stripe=image[:72,96+i*12:108+i*12,:3]
        code,n=np.unique(stripe.reshape((-1,3)),axis=0,return_counts=True)
        best=int(np.argmax(n))
        assert int(n[best])>300,(i,int(n[best]))
        colors.append(code[best])
        rates.append(int(n[best]))
    colors=np.asarray(colors)
    assert len(np.unique(colors,axis=0))==8,colors
    marker=image[:72,:96,:3]
    match=(marker[:,:,None,:]==colors[None,None,:,:]).all(axis=3)
    decoded=np.where(match.any(axis=2),match.argmax(axis=2),-1)
    tracingMarker=int(np.count_nonzero(decoded[:,2]==1))
    filterMarker=int(np.count_nonzero(decoded[:,5]==2))
    write(O/'compute-activation.json',dict(traceRedColumn=tracingMarker,filterGreenColumn=filterMarker,
        frame=frame,programs=programs,decodedCounts={str(i):int(np.count_nonzero(decoded==i)) for i in range(-1,8)}))
    assert tracingMarker>55 and filterMarker>55,(tracingMarker,filterMarker)
    decoded[:,(2,5)]=-1
    raw_roi=decoded[32:68,:48]
    assert raw_roi.shape==raw.shape
    read_fraction=float(np.count_nonzero(raw_roi>=0)/raw_roi.size)
    assert read_fraction>.55,read_fraction
    measure=lambda mask,flag:int(np.count_nonzero(mask&(decoded>=0)&((decoded&flag)!=0)))
    full=np.ones(decoded.shape,bool)
    disputed=np.zeros(decoded.shape,bool)
    disputed[32:68,:48]=raw
    q=dict(status='measured-raw-donor-membership-in-actual-reflection',
           pairedWitness='d8c6282',player=core['player'],frames=[frame],programs=programs,
           sourceShaders={str(p.relative_to(O)):sha(p) for p in (mesh,trace,flt,inc)},
           calibrationBgr=colors.tolist(),calibrationModalCounts=rates,
           traceMarkerCount=tracingMarker,filterMarkerCount=filterMarker,
           traceOutputSize=[640,360],rawRayTile=[448,272,544,344],
           pixels=dict(decoded=int(np.count_nonzero(decoded>=0)),anyHit=measure(full,4),
                changedSourceContributor=measure(full,1),changedSourceBoundsContributor=measure(full,2),
                disputedFilterAreaPixels=int(disputed.sum()),disputedRayDecoded=int(np.count_nonzero(disputed&(decoded>=0))),
                disputedRayHit=measure(disputed,4),disputedRayChangedSource=measure(disputed,1),
                disputedRayBounds=measure(disputed,2)),
           scope='binary ray membership above the temporal minimum color, before spatial filtering; a hit indicates non-zero source-tap weight')
    with art.database(B) as db:
        end=art.rows(db)[R.name]
    assert end['status']=='closed' and end['manifestSha256']==pinned['manifestSha256']
    np.save(O/'decoded-membership.npy',decoded,allow_pickle=False)
    write(O/'qualification.json',q)
    print(q['pixels'])


if __name__=='__main__':
    run()
