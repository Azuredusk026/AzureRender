from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

run = Path(__file__).resolve().parent
out = run.parents[2] / 'docs/acceptance/nr/evidence/2026-11-16/dynamic-body-native-weights'
digest = lambda data: sha256(data).hexdigest()
read = lambda name: json.loads((run / name).read_bytes())
prefix = 'animated-body-captured-pose'
names = dict(topology=prefix + '.json', normalized=prefix + '-native-rig.json',
             unpacked=prefix + '-native-rig-weight-preview.json')
scores = {name: read(file) for name, file in names.items()}
rig = read('animated-body-native-rig-candidate.json')
deformation = read('animated-body-topology-deformation.json')
for result in scores.values():
    c = result['coverage']
    assert (c['nativePixels'], c['inputReconstructionDifference']) == (136029, 0)
    assert (c['originalOutside'], c['originalMissing']) == (1923, 1)
    assert result['maxClipAbsoluteError'] < .001
assert len({json.dumps(result['source'], sort_keys=True) for result in scores.values()}) == 1
assert [(r['coverage']['candidateOutside'], r['coverage']['candidateMissing'])
        for r in scores.values()] == [(2, 2), (0, 2), (0, 0)]
assert scores['normalized']['candidateIndices'] == scores['unpacked']['candidateIndices']
assert scores['unpacked']['candidateIndices'] == rig['candidateInputHashes']['INDICES']
assert scores['unpacked']['originalWeightSumCodes'] == {'65534': 354, '65535': 2517, '65536': 418}
assert scores['unpacked']['coverage']['recoveredNative'] == 1
assert scores['unpacked']['coverage']['lostNative'] == 0
assert rig['untouchedAnimationCount'] == 10 and rig['untouchedSkinCount'] == 1
assert deformation['sampledPoseCount'] == 70 and deformation['newDegenerateCount'] == 0
members = {name: (run / name).read_bytes() for name in (
    *names.values(), 'animated-body-native-rig-candidate.json', 'animated-body-topology-deformation.json',
    'build-animated-body-topology-candidate.py', 'score-animated-body-captured-pose.py',
    'score-animated-body-topology-deformation.py', Path(__file__).name)}
out.mkdir(parents=True, exist_ok=True)
archive = out / 'validation.zip'
with ZipFile(archive, 'w') as z:
    for name, data in sorted(members.items()):
        info = ZipInfo(name, (2026, 11, 16, 0, 0, 0))
        info.compress_type = ZIP_DEFLATED
        z.writestr(info, data)
with ZipFile(archive) as z:
    assert z.testzip() is None
    assert {name: z.read(name) for name in z.namelist()} == members
report = dict(status='captured pose geometry matched; Player coverage and appearance pending',
              productionAssetAccepted=False, scores=scores, nativeRig=rig,
              topologyAnimationCheck=dict(sampledPoses=70, newDegenerateTriangles=0,
                                          largestAnimatedSeam=deformation['largestAnimatedSeam']),
              archive=dict(sha256=digest(archive.read_bytes()),
                           members={name: digest(data) for name, data in members.items()}))
(out / 'results.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf8')
print(report['archive']['sha256'])
