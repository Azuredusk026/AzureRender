"""Measure source skin deformation of the modified body faces without a display readback."""
from collections import Counter
import json
from pathlib import Path
import runpy

import numpy as np

run=Path(__file__).resolve().parent
src=runpy.run_path(str(run/'build-animated-body-topology-candidate.py'),run_name='topology')
api=src['api']
get=api['data']
model=src['model']
buffer=src['program']
nodes=model['nodes']
joint_map=np.array(model['skins'][0]['joints'])
part=np.array([item.get('translation',(0.,0.,0.)) for item in nodes],dtype=np.float64)
rot=np.array([item.get('rotation',(0.,0.,0.,1.)) for item in nodes],dtype=np.float64)
scl=np.array([item.get('scale',(1.,1.,1.)) for item in nodes],dtype=np.float64)
assert all('matrix' not in item for item in nodes)
roots=model['scenes'][model.get('scene',0)]['nodes']
walk=[]
def visit(index,parent):
    walk.append((index,parent))
    for child in nodes[index].get('children',[]):
        visit(child,index)
for i in roots:visit(i,-1)
assert len({i for i,p in walk})==len(walk)==len(nodes)
assert np.all((joint_map>=0)&(joint_map<len(nodes)))

inv_id=model['skins'][0]['inverseBindMatrices']
acc=model['accessors'][inv_id]
bv=model['bufferViews'][acc['bufferView']]
assert (acc['type'],acc['componentType'],acc['count'])==('MAT4',5126,len(joint_map))
assert bv.get('byteStride',64)==64
inv=np.frombuffer(buffer,count=len(joint_map)*16,dtype='<f4',
                  offset=bv.get('byteOffset',0)+acc.get('byteOffset',0)).reshape(-1,4,4).transpose(0,2,1)

def slerp(a,b,t):
    dot=np.dot(a,b)
    if dot<0:
        b=-b
        dot=-dot
    if dot>.9995:
        q=a+(b-a)*t
    else:
        phi=np.arccos(np.clip(dot,-1.,1.))
        q=(np.sin((1.-t)*phi)*a+np.sin(t*phi)*b)/np.sin(phi)
    return q/np.linalg.norm(q)

def matrices(tr,qu,sc):
    qu=qu/np.linalg.norm(qu,axis=1,keepdims=True)
    x,y,z,w=qu.T; I=np.ones(len(qu))
    a=np.stack((I-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w),
                 2*(x*y+z*w),I-2*(x*x+z*z),2*(y*z-x*w),
                 2*(x*z-y*w),2*(y*z+x*w),I-2*(x*x+y*y)),axis=1)
    local=np.broadcast_to(np.eye(4),(len(nodes),4,4)).copy()
    local[:,:3,:3]=a.reshape(-1,3,3)*sc[:,None,:]
    local[:,:3,3]=tr
    world=np.empty_like(local)
    for i,p in walk:
        world[i]=local[i] if p<0 else world[p]@local[i]
    return world[joint_map]@inv

def sampler(animation):
    data=[]
    for ch in animation['channels']:
        q=animation['samplers'][ch['sampler']]
        node,path=ch['target']['node'],ch['target']['path']
        signal,time=get(q['output']).astype(float),get(q['input']).reshape(-1)
        mode=q.get('interpolation','LINEAR')
        assert path in ('translation','rotation','scale') and mode in ('LINEAR','STEP')
        assert len(time)==len(signal) and (np.diff(time)>0).all()
        data.append((node,path,mode,time,signal))
    return data

def evaluate(data,t):
    values=dict(translation=part.copy(),rotation=rot.copy(),scale=scl.copy())
    for node,path,mode,times,keys in data:
        ix=np.searchsorted(times,t,'right')
        if ix==0 or ix==len(times):
            val=keys[0 if ix==0 else -1]
        elif mode=='STEP':
            val=keys[ix-1]
        else:
            f=(t-times[ix-1])/(times[ix]-times[ix-1])
            val=slerp(keys[ix-1],keys[ix],f) if path=='rotation' else keys[ix-1]+(keys[ix]-keys[ix-1])*f
        values[path][node]=val
    return matrices(*(values[k] for k in ('translation','rotation','scale')))

def surfaces(pos,idx):
    a,b,c=pos[idx].transpose(1,0,2)
    edges=np.linalg.norm(np.stack((b-a,c-b,a-c),axis=1),axis=-1)
    area=np.linalg.norm(np.cross(b-a,c-a),axis=1)*.5
    return area,edges

def pct(d):
    return np.percentile(d,[0,10,50,90,99,100]).tolist() if d.size else []

def compare():
    meshes,indices,d=src['prepare']()
    base=get(src['primitive']['attributes']['POSITION']).shape[0]
    assert all(src['dig'](a.tobytes())==d['candidateInputHashes'][k] for k,a in meshes.items())
    assert src['dig'](indices.tobytes())==d['candidateInputHashes']['INDICES']
    assert (len(indices),d['identicalOriginalTriangles'],d['replacedTriangles'])==(5679,5610,69)
    original=src['source_tri']
    removed=original[api['answer']['assetOnly']]
    inserted=indices[-d['replacedTriangles']:]
    p=meshes['POSITION'].astype(float)
    w=meshes['WEIGHTS_0'].astype(float)
    j=meshes['JOINTS_0']
    assert j.max()<len(joint_map) and np.max(abs(w.sum(1)-1))<1e-5
    xyz=np.column_stack((p,np.ones(len(p))))
    used_added=np.unique(inserted[inserted>=base])
    active=np.unique(indices[:d['identicalOriginalTriangles']])
    seam=[]
    for a in used_added:
        dist=np.linalg.norm(p[active]-p[a],axis=1)
        for b in active[dist<1e-5]:
            seam.append((int(a),int(b)))
    assert len(seam)>0
    seam=np.asarray(seam,dtype=int).reshape(-1,2)
    def metric(P, triangle):
        before,be=surfaces(p,triangle)
        after,ae=surfaces(P,triangle)
        return dict(minRestArea=float(before.min()),minPosedArea=float(after.min()),restDegenerateCount=int((before<=1e-12).sum()),
                    newDegenerateCount=int(((before>1e-12)&(after<=1e-12)).sum()),
                    areaRatio=pct(after[before>1e-12]/before[before>1e-12]),edgeDeviation=pct(abs(ae-be)))
    def one(J):
        vertices=np.einsum('vjik,vj,vk->vi',J[j],w,xyz)
        assert np.max(abs(vertices[:,3]-1))<1e-5 and np.isfinite(vertices).all()
        P=vertices[:,:3]
        assert np.max(np.abs(P))<10
        se=np.linalg.norm(P[seam[:,0]]-P[seam[:,1]],axis=1)
        return dict(inserted=metric(P,inserted),removed=metric(P,removed),seamGap=pct(se),
                    worstSeamPair=seam[se.argmax()].tolist())
    bind=one(matrices(part,rot,scl))
    clips=[]
    for animation in model['animations']:
        data=sampler(animation)
        start=min(x[3][0] for x in data)
        end=max(x[3][-1] for x in data)
        times=np.linspace(start,end,7)
        results=[one(evaluate(data,t)) for t in times]
        clips.append(dict(name=animation['name'],times=times.tolist(),data=results))
    assert len(clips)==10
    worst=max((f['seamGap'][-1],c['name'],t,f['worstSeamPair']) for c in clips for t,f in zip(c['times'],c['data']))
    result=dict(status='measured CPU animation geometry; GPU rendering and native dynamic reference pending',
                candidateSource=src['dig'](indices.tobytes()),sourceSkinJoints=len(joint_map),sampledPoseCount=70,
                insertedTriangles=len(inserted),removedTriangles=len(removed),appendedVerticesReferenced=len(used_added),
                adjacentCoincidentPairs=len(seam),seamRestBoundMeters=1e-5,bind=bind,
                newDegenerateCount=sum(f['inserted']['newDegenerateCount'] for c in clips for f in c['data']),
                largestAnimatedSeam=worst,clips=clips)
    (run/'animated-body-topology-deformation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print({k:v for k,v in result.items() if k!='clips'})

if __name__=='__main__':
    a=np.array([0.,0.,0.,1.]); b=np.array([0.,0.,1.,0.])
    assert np.allclose(slerp(a,b,.5),[0,0,2**-.5,2**-.5]) and np.array_equal(slerp(a,-a,.7),a)
    compare()
