"""Build only the animated body topology supported by native indexed geometry and rest bindings."""
from collections import Counter,defaultdict
from copy import deepcopy
from hashlib import sha256
from itertools import permutations
import json
from pathlib import Path
import runpy
import struct
import sys
import numpy as np

root=Path(__file__).resolve().parent
api=runpy.run_path(str(root/'body-native-rest-rig-correspondence.py'),run_name='native_static_rig_inputs')
native_uv, triangles=api['tuva'],api['native_tri']
uv,source_tri=api['uv'],api['idx']
model,program=api['model'],api['raw']
primitive=api['p']
read=api['data']
n=len(native_uv)
manifest=root/'animated-body-topology-candidate.json'
dig=lambda b:sha256(b).hexdigest()

def prepare(native_rig=False):
    assert api['order']==(0,2,1) and api['signs']==(-1,1,-1)
    assert abs(api['translation']).max()<2e-7
    axes=api['order']; signs=api['signs']
    vertex={'POSITION':api['posa'][:,axes]*signs, 'TEXCOORD_0':native_uv}
    snorm=api['vertex'](1,8,'i1',4)[:,:2].astype(float)
    assert snorm.min()>-128
    vertex['TEXCOORD_1']=(snorm/127.)*[1,-1]+[0,1]
    native_n,native_t,native_w=api['native_tangent_frame'](api['packed'])
    vertex['NORMAL']=native_n[:,axes]*signs
    vertex['TANGENT']=np.column_stack((native_t[:,axes]*signs,-native_w))
    existing={name:read(handle) for name,handle in primitive['attributes'].items()}
    counts=Counter(int(v) for v in source_tri.ravel())
    witnesses=defaultdict(Counter)
    for i,k in api['matches']:
        witnesses[i][k]+=counts[k]
    mapping=np.full(n,-1,dtype=np.int64)
    missing_uv=[]
    displaced=[]
    adjacency={}
    for i in range(n):
        match=np.flatnonzero(np.max(abs(uv-native_uv[i]),axis=1)<=1e-6)
        if not len(match):
            missing_uv.append(i)
            continue
        distance=np.linalg.norm(existing['POSITION'][match]-vertex['POSITION'][i],axis=1)
        good=match[distance<1e-5]
        if not len(good):
            displaced.append(i)
            continue
        adjacency[i]=sorted(map(int,good),key=lambda j:(-witnesses[i][j],np.linalg.norm(existing['POSITION'][j]-vertex['POSITION'][i]),j))
    owner={}
    def assign(i, seen):
        for k in adjacency[i]:
            if k in seen:
                continue
            seen.add(k)
            if k not in owner or assign(owner[k],seen):
                owner[k]=i
                return True
        return False
    for i in sorted(adjacency,key=lambda q:(len(adjacency[q]),-witnesses[q][adjacency[q][0]],q)):
        assign(i,set())
    for k,i in owner.items():
        mapping[i]=k
    split_duplicates=[i for i in adjacency if mapping[i]<0]
    additions=np.flatnonzero(mapping<0)
    assert len(additions)==len(missing_uv)+len(displaced)+len(split_duplicates)
    assert len(missing_uv)==31
    base=existing['POSITION'].shape[0]
    mapping[additions]=base+np.arange(len(additions))
    assert len(np.unique(mapping))==n
    weights=api['wp'][additions].copy()
    local_bones=api['jp'][additions]
    ranked=api['report']['nativeBoneMappingVotes']
    # Bone slot zero may occur only on ignored zero-weight lanes.
    relevant={int(k) for k in np.unique(local_bones[weights>0])}
    assert relevant<=ranked.keys(),(relevant,sorted(ranked.keys()),split_duplicates,displaced)
    assert all(len(ranked[k])==1 and next(iter(ranked[k].values()))>=32 for k in relevant)
    joint_map={k:int(next(iter(ranked[k]))) for k in relevant}
    converted=np.zeros_like(local_bones,dtype=np.uint16)
    for k,v in joint_map.items():converted[local_bones==k]=v
    assert weights.min()>=0 and np.max(abs(weights.sum(1)-1))<4/65535
    vertex['JOINTS_0']=converted
    vertex['WEIGHTS_0']=weights/weights.sum(1,keepdims=True)
    fields={}
    for k,old in existing.items():
        extra=vertex[k] if k in ('WEIGHTS_0','JOINTS_0') else vertex[k][additions]
        merged=np.vstack((old,extra.astype(old.dtype,copy=False)))
        assert np.array_equal(merged[:base],old)
        fields[k]=merged
    winding=Counter()
    for i,j in api['answer']['mapping'].items():
        a=native_uv[triangles[i]]
        b=uv[source_tri[j]]
        ori=min(permutations(range(3)),key=lambda q:np.max(abs(a-b[list(q)])))
        if np.max(abs(a-b[list(ori)]))<=1e-6:
            winding['same' if ori in ((0,1,2),(1,2,0),(2,0,1)) else 'reversed']+=1
    assert winding['reversed']>=5500 and winding['same']<=110,winding
    kept=sorted((j,i) for i,j in api['answer']['mapping'].items())
    unresolved=api['answer']['nativeOnly']
    # Keep original index order and exact contents where a reference face already exists.
    source_used=np.asarray([j for j,i in kept])
    native_used=np.asarray([i for j,i in kept])
    added=mapping[triangles[unresolved][:,[0,2,1]]].astype(source_tri.dtype)
    remap=np.concatenate((source_tri[source_used],added),axis=0)
    assert np.array_equal(remap[:len(source_used)],source_tri[source_used])
    assert (len(source_used),len(unresolved))==(5610,69)
    assert len(remap)==5679 and remap.max()<base+len(additions)
    if native_rig:
        # Replay the proven original rest geometry and bone weights across the body.
        # The matching source values for the UV and material frames remain assigned
        # to each corner; no screenshot values participate in the correspondence.
        definition=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261017-000956-endfield-native-3caf73/laevat-static/model.geometry.json')
        assert api['core']['digest'](definition)=='81f617bdd8c6154da6f8f3d40d35e7e6fcc98e74c77a275b658554b3ba0324c2'
        asset,=[m for m in json.loads(definition.read_bytes())['meshes'] if m['name']=='S_actor_laevat_body_01_lod0']
        names=[model['nodes'][k]['name'] for k in model['skins'][0]['joints']]
        authored=[]
        for bone in asset['bones']:
            local=bone['path'].rsplit('/',1)[1]
            assert names.count(local)==1
            authored.append(names.index(local))
        assert all(authored[k]==v for k,v in joint_map.items())
        native_fields={name:np.ascontiguousarray(table[mapping]).copy() for name,table in fields.items()}
        native_fields['POSITION']=vertex['POSITION'].astype(existing['POSITION'].dtype)
        native_fields['JOINTS_0']=np.asarray(authored,dtype=existing['JOINTS_0'].dtype)[api['jp']]
        native_weights=api['wp']
        assert (native_weights>=0).all() and np.max(abs(native_weights.sum(1)-1))<4/65535
        native_fields['WEIGHTS_0']=(native_weights/native_weights.sum(1,keepdims=True)).astype(existing['WEIGHTS_0'].dtype)
        fields={name:np.vstack((old,native_fields[name])) for name,old in existing.items()}
        aligned=[]
        for j,i in kept:
            q,r=triangles[i],source_tri[j]
            order=min(permutations(range(3)),key=lambda order:np.max(abs(native_uv[q[list(order)]]-uv[r])))
            assert order not in ((0,1,2),(1,2,0),(2,0,1))
            aligned.append(q[list(order)])
        remap=(base+np.concatenate((aligned,triangles[unresolved][:,[0,2,1]]))).astype(source_tri.dtype)
        added=remap[len(kept):]
        assert len(remap)==5679 and np.unique(remap).size==n
        assert all(np.array_equal(v[:base],existing[k]) for k,v in fields.items())
    max_uv_error=float(max(np.max(abs(fields['TEXCOORD_0'][added]-native_uv[triangles[unresolved][:,[0,2,1]]])),
                           max(min(np.max(abs(uv[source_tri[j]]-native_uv[triangles[i][list(q)]])) for q in permutations(range(3))) for j,i in kept)))
    assert max_uv_error<=1e-6,max_uv_error
    report=dict(status='prepared-in-memory-skinned-mesh-candidate',scope='isolated comparison; not a production asset',
                variant='native-body-rig' if native_rig else 'topology-only',sourceBonePalette=44 if native_rig else None,
                vertexCount=len(fields['POSITION']),activeVertexCount=len(np.unique(remap)),nativeVertexCount=n,
                triangles=len(remap),identicalOriginalTriangles=0 if native_rig else len(source_used),
                preservedSharedTriangleOrder=len(source_used),replacedTriangles=len(added),
                removedTriangles=len(source_tri)-len(source_used),windingEvidence=winding,
                appendedForMissingUv=len(missing_uv),appendedForPosition=len(displaced),boneCorrespondence=joint_map,
                appendedForDistinctNativeVertices=len(split_duplicates),maxTriangleUvComponentError=max_uv_error,
                originalAttributeBytesUnchanged=True,originalGlb=api['core']['digest'](api['core']['actor']),
                candidateInputHashes={k:dig(v.tobytes()) for k,v in {**fields,'INDICES':remap}.items()})
    return fields,remap,report

def serialize(native_rig=False):
    fields,indices,report=prepare(native_rig)
    canonical=(json.dumps(model,ensure_ascii=False,separators=(',',':'))).encode('utf8')
    fresh=json.loads(canonical)
    assert len(fresh['buffers'])==1 and 'uri' not in fresh['buffers'][0]
    assert fresh['buffers'][0]['byteLength']<=len(program)<fresh['buffers'][0]['byteLength']+4
    old_buffer=bytearray(program)
    assert len(old_buffer)%4==0
    index_mesh=next(i for i,m in enumerate(model['meshes']) if m['name']=='S_actor_laevat_body_01_lod0')
    body=fresh['meshes'][index_mesh]['primitives'][0]
    handles={**primitive['attributes'],'INDICES':primitive['indices']}
    out={**fields,'INDICES':indices.reshape(-1,1)}
    for semantic,values in out.items():
        acc=deepcopy(model['accessors'][handles[semantic]])
        assert 'sparse' not in acc and not acc.get('normalized')
        assert values.dtype.kind in 'uf' and values.dtype.isnative
        data_bytes=np.ascontiguousarray(values).tobytes()
        view=dict(buffer=0,byteOffset=len(old_buffer),byteLength=len(data_bytes),
                  target=34963 if semantic=='INDICES' else 34962)
        acc.update(bufferView=len(fresh['bufferViews']),byteOffset=0,count=len(values))
        for key,fn in [('min',np.min),('max',np.max)]:
            if key in acc or semantic=='POSITION':
                acc[key]=fn(values,axis=0).tolist()
        if semantic=='INDICES':
            body['indices']=len(fresh['accessors'])
        else:
            body['attributes'][semantic]=len(fresh['accessors'])
        fresh['accessors'].append(acc)
        fresh['bufferViews'].append(view)
        old_buffer.extend(data_bytes+b'\x00'*(-len(data_bytes)%4))
    fresh['buffers'][0]['byteLength']=len(old_buffer)
    assert all(fresh[key]==value for key,value in model.items() if key not in {'accessors','bufferViews','buffers','meshes'})
    assert all(q==p for i,(p,q) in enumerate(zip(model['meshes'],fresh['meshes'])) if i!=index_mesh)
    assert fresh['accessors'][:len(model['accessors'])]==model['accessors']
    assert fresh['bufferViews'][:len(model['bufferViews'])]==model['bufferViews']
    assert bytes(old_buffer[:len(program)])==program
    for name,values in out.items():
        acc=fresh['accessors'][body['indices'] if name=='INDICES' else body['attributes'][name]]
        view=fresh['bufferViews'][acc['bufferView']]
        win=memoryview(old_buffer)[view['byteOffset']:view['byteOffset']+view['byteLength']]
        assert dig(win)==report['candidateInputHashes'][name]
    json_bytes=json.dumps(fresh,ensure_ascii=False,separators=(',',':')).encode('utf8')
    json_bytes+=b' '*(-len(json_bytes)%4)
    total=28+len(json_bytes)+len(old_buffer)
    packed=struct.pack('<5I',0x46546c67,2,total,len(json_bytes),0x4e4f534a)+json_bytes
    packed+=struct.pack('<2I',len(old_buffer),0x4e4942)+old_buffer
    assert len(packed)==total
    report.update(serializedBytes=total,serializedSha256=dig(packed),preservedOriginalBufferBytes=len(program),
                  untouchedAnimationCount=len(fresh['animations']), untouchedSkinCount=len(fresh['skins']))
    return packed,report

if __name__=='__main__':
    args=sys.argv[1:]
    rig='--native-rig' in args
    args=[x for x in args if x!='--native-rig']
    assert args==['preflight'] or len(args)==2 and args[0]=='materialize'
    packed,result=serialize(rig)
    if args[0]=='materialize':
        target=Path(args[1]).resolve()
        assert target.is_relative_to(root.parent) and target.suffix=='.glb' and not target.exists(),target
        target.write_bytes(packed)
        assert dig(target.read_bytes())==result['serializedSha256']
    receipt=manifest if not rig else root/'animated-body-native-rig-candidate.json'
    receipt.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps(result))
