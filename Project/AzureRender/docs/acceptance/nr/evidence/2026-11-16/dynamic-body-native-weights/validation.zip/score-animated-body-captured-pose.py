"""Compare body topology with the actual positions and camera from native draw 783."""
import json
from pathlib import Path
from itertools import permutations
import runpy
import struct
import sys

import numpy as np

run=Path(__file__).resolve().parent
src=runpy.run_path(str(run/'build-animated-body-topology-candidate.py'),run_name='native_body_topology')
api=src['api']
pose=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-212213-native-binding-restoration-d39ea8')
read=lambda p:json.loads(p.read_bytes())
sha=api['core']['digest']
native=pose/'frame10401'
source_mesh=pose.parent/'20261017-000956-endfield-native-3caf73/laevat-static/model.geometry.json'
axes=np.array([0,2,1])
mirrored=np.array([-1.,1.,-1.])
to_raw=lambda data:np.asarray(data)[:,axes]*[-1.,-1.,1.]
extent=np.array([2560.,1440.])
assert (to_raw((api['posa'][:,axes]*mirrored))==api['posa']).all()

def positions(x,weights,joints,palette):
    h=np.column_stack((x,np.ones(len(x))))
    return np.einsum('vjik,vj,vk->vi',palette[joints],weights,h)

def screen(c):
    assert (c[:,3]>0).all()
    return (c[:,:2]/c[:,3,None]*[1,-1]+1)*.5*extent

def coverage(pos,triangles):
    bounds=extent.astype(int)
    shape=tuple(bounds[::-1])
    visible=np.zeros(shape,dtype=bool)
    subpixel=np.rint(pos*256.).astype(np.int64)
    for t in subpixel[triangles]:
        low=np.maximum(np.ceil((t.min(0)-128.)/256.).astype(int),0)
        high=np.minimum(np.floor((t.max(0)-128.)/256.).astype(int),bounds-1)
        if (low>high).any():
            continue
        a,b=t[1:]-t[0]
        area=a[0]*b[1]-a[1]*b[0]
        if not area:
            continue
        if area<0:
            t=t[[0,2,1]]
        x,y=np.meshgrid(np.arange(low[0],high[0]+1,dtype=np.int64)*256+128,
                        np.arange(low[1],high[1]+1,dtype=np.int64)*256+128)
        mask=np.ones(x.shape,dtype=bool)
        for start,end in zip(t,np.roll(t,-1,axis=0)):
            dx,dy=end-start
            f=dx*(y-start[1])-dy*(x-start[0])
            mask&=f>0 if dy>0 or (dy==0 and dx<0) else f>=0
        visible[low[1]:high[1]+1,low[0]:high[0]+1]|=mask
    return visible

def compare(native_rig=False, raw_weight_preview=False):
    m=read(pose/'frame10401-manifest.json')
    draw={e['eid']:e for e in m['events']}[783]
    assert draw['action']['instanceOffset']==0 and draw['action']['numIndices']==17037
    assert draw['stages']['VS']['bindings']['srv'][0]['descriptor']['resource']=='ResourceId::399'
    constants=native/'e783-vs-constants.json'
    pal=native/'e804-skin-matrices.bin'
    slots={b['slot']:{v['offset']//16:v['value'] for v in b['variables']} for b in read(constants)['data']['cbufs']}
    g=lambda slot,rows:np.asarray([slots[slot][i] for i in rows],dtype=float)
    bits=struct.pack('<64f',*(float(x) for x in g(2,range(16)).ravel()))
    flag,base=struct.unpack_from('<II',bits,76)
    assert (flag,base)==(52,24772)
    rest,=[m for m in read(source_mesh)['meshes'] if m['name']=='S_actor_laevat_body_01_lod0']
    p=np.fromfile(pal,'<f4').reshape(-1,4)
    total=len(rest['bones'])
    assert total==44 and api['jp'].max()<total
    bones=p[base+3:base+3+total*3].reshape(-1,3,4)
    mat=g(2,range(4))
    view=g(0,range(32,36))
    eye=g(0,[44])[0,:3]
    jitter=g(1,[19])[0,2:4]
    def clip(pos):
        rel=pos@mat[:3,:3]+(mat[3,:3]-eye)
        c=np.column_stack((rel,np.ones(len(rel))))@view
        c[:,:2]+=c[:,3,None]*jitter*[-2,2]
        return c
    n=clip(positions(api['posa'],api['wp'],api['jp'],bones))
    record=api['defs']['783']
    vb=api['bs']/'vertex-783.bin'
    assert sha(vb)==record['vertexSha256']
    raw=np.fromfile(vb,'<f4').reshape(-1,record['vertexStride']//4)[:,:4].astype(float)
    assert len(raw)==len(n)
    abs_err=np.max(abs(raw-n),axis=1)
    native_screen=screen(raw)
    model_screen=screen(n)
    px_err=np.linalg.norm(native_screen-model_screen,axis=1)
    assert px_err.max()<.015,(np.percentile(px_err,[0,10,50,90,100]).tolist(),abs_err.max())
    fields,candidate,report=src['prepare'](native_rig)
    topology=src['source_tri']
    joint_votes={}
    for (a,b),count in api['votes'].items():
        joint_votes.setdefault(a,[]).append((b,count))
    model=src['model']
    names=[model['nodes'][j]['name'] for j in model['skins'][0]['joints']]
    lookup={}
    for local,b in enumerate(rest['bones']):
        name=b['path'].rsplit('/',1)[1]
        assert names.count(name)==1,name
        lookup[names.index(name)]=local
    for k,buckets in joint_votes.items():
        if len(buckets)==1 and buckets[0][1]>=32:
            assert lookup[buckets[0][0]]==k,(k,buckets)
    assert len(set(lookup.values()))==len(lookup)
    j=fields['JOINTS_0'].copy().astype(int)
    w=fields['WEIGHTS_0'].astype(float)
    w_sum=api['wp'].sum(1)
    if raw_weight_preview:
        assert native_rig
        w[-len(api['wp']):]=api['wp']
    assert {int(q) for q in np.unique(j[w>0])}<=lookup.keys(),sorted(set(np.unique(j[w>0]))-lookup.keys())
    keys=np.zeros_like(j)
    for mapped,local in lookup.items():keys[j==mapped]=local
    geom=screen(clip(positions(to_raw(fields['POSITION']),w,keys,bones)))
    inds=src['triangles']
    # Assess candidate corners against measured native clip output with known UV order and winding.
    orders=list(permutations(range(3)))
    kept=sorted((j,i) for i,j in api['answer']['mapping'].items())
    if not native_rig:
        assert np.array_equal(candidate[:len(kept)],topology[[j for j,i in kept]])
    kept_error=[]
    candidate_kept_error=[]
    for j,i in kept:
        reference=inds[i]
        runtime=candidate[len(kept_error)]
        for mesh,table in ((topology[j],kept_error),(runtime,candidate_kept_error)):
            order=min(orders,key=lambda q:np.max(abs(api['tuva'][reference]-fields['TEXCOORD_0'][mesh[list(q)]])))
            table.append(np.linalg.norm(native_screen[reference]-geom[mesh[list(order)]],axis=1))
    wanted=inds[api['answer']['nativeOnly']][:,[0,2,1]]
    added=np.linalg.norm(native_screen[wanted]-geom[candidate[len(kept):]],axis=-1)
    pcts=lambda x:np.percentile(x,[0,50,90,99,100]).tolist()
    native_mask, exact_control=coverage(native_screen,inds),coverage(model_screen,inds)
    a,b=coverage(geom,topology),coverage(geom,candidate)
    assert np.array_equal(coverage(native_screen,inds[::-1,::-1]),native_mask)
    def near(pos,tris,point):
        xy=np.array(point)+.5
        seq=pos[tris]
        indices=np.flatnonzero(np.all(seq.min(1)<=xy+.15,axis=1)&np.all(seq.max(1)>=xy-.15,axis=1))
        if not len(indices):
            return []
        xy=np.rint(xy*256.)
        raw=np.rint(seq[indices]*256.)
        r=raw[:,[1,2,0]]-raw
        delta=xy-raw
        edge=(r[:,:,0]*delta[:,:,1]-r[:,:,1]*delta[:,:,0])/np.linalg.norm(r,axis=2).clip(min=1.)/256.
        values=np.maximum(edge.min(1),-edge.max(1))
        return [(int(k),float(np.round(v,6)),[int(j) for j in tris[k]]) for k,v in zip(indices,values) if v>=-.07]
    new_pts=np.argwhere(native_mask&a&~b)[:,::-1].tolist()
    witnesses={str(point):dict(native=near(native_screen,inds,point),baseline=near(geom,topology,point),
                              candidate=near(geom,candidate,point)) for point in new_pts}
    raster=dict(scope='draw geometry only; no blend, sample mask or depth from other draws',
        nativePixels=int(native_mask.sum()),inputReconstructionDifference=int((native_mask^exact_control).sum()),
        originalOutside=int((a&~native_mask).sum()), originalMissing=int((native_mask&~a).sum()),
        candidateOutside=int((b&~native_mask).sum()), candidateMissing=int((native_mask&~b).sum()),
        recoveredNative=int((native_mask&~a&b).sum()),lostNative=int((native_mask&a&~b).sum()),
        newlyUncoveredPointsXY=np.argwhere(native_mask&a&~b)[:,::-1].tolist(),
        candidateMissingPointsXY=np.argwhere(native_mask&~b)[:,::-1].tolist(),
        candidateOutsidePointsXY=np.argwhere(b&~native_mask)[:,::-1].tolist(),nearbyTriangles=witnesses)
    result=dict(status='measured using native captured pose and vertex projection',nativeBodyTriangles=len(inds),
        nativeSourceControlPixels=pcts(px_err),maxClipAbsoluteError=float(abs_err.max()),
        originalMatchedCornersPixels=pcts(kept_error),candidateNewCornersPixels=pcts(added),
        candidateMatchedCornersPixels=pcts(candidate_kept_error),variant=report['variant'],
        candidateNewCornersOverQuarterPixel=int((added>.25).sum()),candidateNewCornersOverOnePixel=int((added>1).sum()),
        rawWeightPreview=raw_weight_preview,
        originalWeightSumCodes={str(code):int(count) for code,count in zip(*np.unique(np.rint(w_sum*65535.).astype(int),return_counts=True))},
        coverage=raster,
        candidateIndices=report['candidateInputHashes']['INDICES'],
        source=dict(constants=sha(constants),palette=sha(pal),bodyBindGeometry=sha(source_mesh),postVertex=sha(vb),preamble=[flag,base]))
    name='animated-body-captured-pose-native-rig' if native_rig else 'animated-body-captured-pose'
    if raw_weight_preview:
        name+='-weight-preview'
    (run/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps(result))

if __name__=='__main__':
    assert sys.argv[1:] in ([],['--native-rig'],['--native-rig','--raw-weights-preview'])
    compare('--native-rig' in sys.argv,'--raw-weights-preview' in sys.argv)
