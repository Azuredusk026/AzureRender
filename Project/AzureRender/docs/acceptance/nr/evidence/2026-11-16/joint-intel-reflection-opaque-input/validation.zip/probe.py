"""Compare opaque snapshot signatures and bound compute reflection in the same beauty frame."""
import json
from pathlib import Path
import runpy
import sqlite3
import subprocess
import sys
from zipfile import ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
body=runpy.run_path(str(M/'joint-character-referenced-body.py'),run_name='reflection_storage_camera')
glsl=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='reflection_storage_catalog')
R,B=glsl['R'],glsl['B']
H,art,check,read,write,sha=[glsl[k] for k in ('H','art','check','read','write','sha')]
C=M/'joint-character-referenced-body'
O=M/'joint-intel-reflection-source-probe'
variants=tuple('mesh_object_clipmap_field'+suffix+'.frag.spv' for suffix in ('','_early','_lighting','_early_lighting'))
glsl['activate_links'].__wrapped__.__globals__['home']=O
assert body['OUT']==C
old='''    vec3 qaColor = beautyColor;
    if (qaIsolationMode == 1) {'''
new='''    vec3 qaColor = beautyColor;
#if !defined(AZURE_OPAQUE_SNAPSHOT)
        vec2 probe = AZURE_FRAGMENT_COORD.xy;
        if (qaIsolationMode==0 && camera.screenReflectionTrace.x>1.5 &&
            all(greaterThanEqual(probe,vec2(0))) && probe.x<640 && probe.y<360) {
            ivec2 origin=ivec2(probe)*2;
            uint signature=2166136261U;
            for (int tap=0;tap<4;++tap) {
                uvec4 sampleBits=floatBitsToUint(texelFetch(opaqueSceneColor,origin+ivec2(tap%2,tap/2),0));
                for (int channel=0;channel<4;++channel)
                    signature=(signature^sampleBits[channel])*16777619U;
            }
            // Mix the upper bits of expanded half-float inputs before encoding 18 bits.
            signature^=signature>>16;
            signature*=2246822519U;
            signature^=signature>>13;
            signature*=3266489917U;
            signature^=signature>>16;
            qaColor=vec3(.12)+vec3(signature&63U,(signature>>6)&63U,(signature>>12)&63U)*(.58/63.);
        }
        // Keep the reflection comparisons off the opaque source reporting area.
        probe.x-=640.;
        if (qaIsolationMode==0 && camera.screenReflectionTrace.x>1.5 && all(greaterThanEqual(probe,vec2(0)))
            && probe.x<576 && probe.y<72) {
            int lane=int(probe.x)/96;
            int kind=lane%3;
            vec2 anchor=vec2(mod(probe.x,96),probe.y)+vec2(896,lane>=3 ? 160 : 608);
            vec4 sampleValue=sampleComputedScreenReflection(anchor/vec2(textureSize(opaqueSceneColor,0)));
            qaColor=kind==1 ? vec3(clamp(sampleValue.a,0,1))
                    : max(vec3(0),sampleValue.rgb)/(vec3(1)+max(vec3(0),sampleValue.rgb));
            if (kind==2) {
                vec4 surface=texelFetch(overlaySceneDepth,ivec2(anchor),0);
                qaColor=vec3(clamp(surface.r/(32+surface.r),0,1),surface.gb);
            }
        }
#endif
    if (qaIsolationMode == 1) {'''


def source_input():
    p=W/'shaders/mesh.frag'
    s=p.read_text(encoding='utf8')
    assert s.count(old)==1
    assert 'layout(rgba32f,binding=37) uniform readonly image2D computedScreenReflection;' in s
    baseline=subprocess.check_output(['git','show','75837a6:Project/AzureRender/shaders/mesh.frag'],cwd=W,encoding='utf8')
    assert s==baseline
    rule={entry['output']:entry['defines'] for entry in read(R/'msaa-release/shader-reload.json')['programs']}
    assert all(set(rule[k])>={'AZURE_IRRADIANCE_CLIPMAP=1','AZURE_PROBE_FIELD=1'} for k in variants)
    return p,s.replace(old,new)


def run():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    budget=check(B,run=M,planned=4_400_000)
    assert budget['allowed'],budget
    basecode,changed=source_input()
    (O/'programs').mkdir(parents=True,exist_ok=True)
    source=O/'mesh.frag'
    source.write_text(changed,encoding='utf8')
    for name in variants:
        H['compile_program'](source,O/'programs'/name,name,diagnostics=O/'compile'/f'{name}.log')
    programs={name:sha(O/'programs'/name) for name in variants}
    core,assets,_=body['prepare']()
    with art.database(B) as c:
        pinned=art.rows(c)[R.name]
    prior_readbacks=O/'readbacks.json'
    previous=read(prior_readbacks) if prior_readbacks.exists() else {}
    if pinned['status']=='active':
        with sqlite3.connect('file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro',uri=True) as db:
            previous_job=db.execute('select task,state from jobs where id=1502').fetchone()
        assert previous_job==('nr-joint-character-intel-opaque-reflection-source-retest','budget-stopped')
        assert pinned['manifestSha256']=='1c071c68db674fd2fab82f4462a3d5c051fdc2228567d47075ea3c6cc004de44'
        assert set(previous)=={'a'}
        partial=C/'intel-opaque-source-probe-b'
        preserved=C/'intel-opaque-source-probe-b-budget-stopped-1502'
        assert not (C/'intel-opaque-source-probe-b.zip').exists()
        if partial.exists():
            assert partial.resolve()==partial and partial.parent==C and not partial.stat().st_file_attributes&1024
            assert not preserved.exists()
            partial.rename(preserved)
        assert preserved.is_dir() and preserved.resolve()==preserved
        catalog=glsl['catalog_api']
        retained=catalog['retained_catalog'](R)
        catalog['restore'](retained)
        assert {p.name:sha(p) for p in catalog['catalog'].glob('*.spv')}==retained
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=90)
        with art.database(B) as c:
            closed=art.rows(c)[R.name]
        assert closed['status']=='closed' and closed['manifestSha256']==pinned['manifestSha256']
        pinned=closed
    assert pinned['status']=='closed'
    asset=assets[1][0]
    temporary=(asset,asset.with_name('body.bin'))
    if any(path.exists() for path in temporary):
        assert set(previous)=={'a'}
        assert (C/'intel-opaque-source-probe-b-budget-stopped-1502').is_dir()
        with ZipFile(C/'native-asset.zip') as z:
            assert z.testzip() is None
            for path in temporary:
                assert path.resolve()==path and path.parent.parent==C and not path.stat().st_file_attributes&1024
                assert path.read_bytes()==z.read(path.name),path
        for path in temporary:
            path.unlink()
    base=M/'character-six-view-inputs/intel-back-detail/frames/frame_000000.png'
    ref=cv2.imread(str(base),cv2.IMREAD_UNCHANGED)
    assert ref.shape==(720,1280,4)
    old_group={}
    for mode in ('native','native-repeat','serial-a'):
        with ZipFile(C/f'intel-{mode}.zip') as z:
            old_group[mode]=ref^np.frombuffer(z.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
    reads={}
    pixels={}
    comparison_mask=np.ones(ref.shape[:2],bool)
    comparison_mask[:360,:640]=False
    comparison_mask[:72,640:1216]=False
    art.resume(B,R.name)
    try:
        with glsl['activate_links'](programs), body['temporary_descriptor'](assets[1]) as descriptor:
            for label,serial in (('a',False),('b',False),('serial',True)):
                args=[]
                if serial:
                    args.append('--disable-parallel-recording')
                kind=f'opaque-source-probe-{label}'
                if label in previous:
                    d=previous[label]['frame']
                    assert sha(C/f'intel-{kind}.zip')==d['archive']
                    assert read(C/f'intel-{kind}/result.json')==d
                else:
                    d=body['capture']('intel',kind,descriptor,args)
                manifest=read(C/f'intel-{kind}/frames/capture_manifest.json')
                assert manifest['qaIsolation']=='beauty' and manifest['screenReflectionProducer']=='linear-temporal'
                assert manifest['irradianceResourceKind']=='clipmap' and manifest['objectShadowPrepared']
                log=(C/f'intel-{kind}'/'player.log').read_text('utf8',errors='replace')
                assert 'Reflection field: 12 local probes' in log and 'Character texture access: fixed' in log
                with ZipFile(C/f'intel-{kind}.zip') as z:
                    pixels[label]=ref^np.frombuffer(z.read('frame_000000.bgra-xor'),np.uint8).reshape(ref.shape)
                from hashlib import sha256
                assert sha256(pixels[label].tobytes()).hexdigest()==d['raw']
                m=pixels[label]
                reads[label]=dict(frame=d,againstKnown={
                     k:int(np.any(x[comparison_mask]!=m[comparison_mask],axis=1).sum()) for k,x in old_group.items()})
                assert min(reads[label]['againstKnown'].values())<5000,reads[label]
                assert min(np.any(x[:72,640:1216]!=m[:72,640:1216],axis=2).sum() for x in old_group.values())>1000
                assert min(np.any(x[:360,:640]!=m[:360,:640],axis=2).sum() for x in old_group.values())>20000
                write(O/'readbacks.json',reads)
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=90)
    with art.database(B) as c:
        result=art.rows(c)[R.name]
    assert result['status']=='closed' and result['manifestSha256']==pinned['manifestSha256']
    pairs={}
    for a,b in [('a','b'),('a','serial'),('b','serial')]:
        diff=np.abs(pixels[a].astype(np.int16)-pixels[b].astype(np.int16)).max(axis=2)
        opaque=diff[:360,:640]
        y,x=np.where(opaque>0)
        pairs[a+'-'+b]=dict(
            opaqueSourceSignatureChanged=int(len(x)),
            opaqueSourceSignatureBounds=([int(x.min())*2,int(y.min())*2,int(x.max())*2+1,int(y.max())*2+1] if len(x) else None),
            opaqueSourceReportTwelveByEight=[int(np.count_nonzero(opaque[y:y+45,x:x+54]))
                                            for y in range(0,360,45) for x in range(0,640,54)],
            storedRgbChanged=int((diff[:72,640:736]>0).sum()),
            storedConfidenceChanged=int((diff[:72,736:832]>0).sum()),
            floorInputSurfaceChanged=int((diff[:72,832:928]>0).sum()),
            upperStoredRgbChanged=int((diff[:72,928:1024]>0).sum()),
            upperStoredConfidenceChanged=int((diff[:72,1024:1120]>0).sum()),
            upperInputSurfaceChanged=int((diff[:72,1120:1216]>0).sum()),
            realFloorChanged=int((diff[608:680,896:992]>0).sum()),
            realUpperChanged=int((diff[160:232,896:992]>0).sum()),
            nonReportingChanged=int((diff[comparison_mask]>0).sum()))
    r=dict(status='measured-opaque-snapshot-and-reflection-in-same-frame',reads=reads,pairs=pairs,
           player=core['player'],programs=programs,source=sha(basecode),diagnosticSource=sha(source))
    write(O/'qualification.json',r)
    print(pairs)


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(sha(source_input()[0]))
    else:
        run()
