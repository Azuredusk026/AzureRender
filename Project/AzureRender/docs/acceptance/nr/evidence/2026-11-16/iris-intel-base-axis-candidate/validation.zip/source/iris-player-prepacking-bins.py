"""Read material color before unsigned packing using a one-capture per adapter probe."""
from contextlib import contextmanager
import json
import math
import os
from pathlib import Path
import runpy
import struct
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

M = Path(__file__).resolve().parent
base = runpy.run_path(str(M/'run-iris-unsigned-output-readonly.py'),run_name='prepacking_reference')
H, W, R, B, CASE = [base[k] for k in ('H','W','R','B','CASE')]
read, sha, write, art, check = [base[k] for k in ('read','sha','write','art','check')]
home = M/'iris-player-prepacking-bins'
base['capture'].__globals__['OUT'] = home
catalog_api = H['catalog_api']
native=read(M/'iris-packing-boundary-native/results.json')
assert native['status']=='qualified-native-iris-packing-boundary'
anchors = {tuple(row['point']):row for row in native['rows']}

replacement = '''    if (eyeNpr && qaIsolationMode==0) {
        uvec3 mantissa = floatBitsToUint(max(vec3(0.0),outputColor.rgb));
        uvec3 marker = (mantissa >> uvec3(12,12,13)) & uvec3(255);
        vec3 encoded = vec3(marker) / 255.0;
        outputColor.rgb = mix(pow((encoded + 0.055) / 1.055, vec3(2.4)), encoded / 12.92,
                              lessThanEqual(encoded, vec3(0.04045)));
    } else {
'''+base['original']+'''
    }'''


@contextmanager
def activate_links(records):
    shared = catalog_api['catalog']
    restore = catalog_api['restore']
    backups = catalog_api['backups']
    retained = catalog_api['retained_catalog'](R)
    restore(retained)
    assert {p.name:sha(p) for p in shared.glob('*.spv')}==retained
    backups.mkdir(exist_ok=True)
    try:
        for name,fingerprint in records.items():
            p=home/'programs'/name
            assert sha(p)==fingerprint
            target=shared/name
            target.replace(backups/name)
            target.hardlink_to(p)
        assert {name:sha(shared/name) for name in records}==records
        yield
    finally:
        restore(retained)
        assert {p.name:sha(p) for p in shared.glob('*.spv')}==retained


def from_srgb(code):
    x=code/255
    return x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4


def to_screen(v):
    x=float(np.float16(min(1.0,max(0.0,v))))
    return int(round(255*(12.92*x if x<=.0031308 else 1.055*x**(1/2.4)-.055)))


def possibilities(code, before, packed, frac_bits):
    """Enumerate all raw bins consistent with both recorded beauty passes."""
    if not 0 < packed < 255:
        return []
    rows=[]
    for exponent in range(-16,2):
        width=math.ldexp(1,exponent-frac_bits)
        for b in range(1<<frac_bits,1<<(frac_bits+1)):
            if (b&7)!=(code>>5):
                continue
            q=b*width
            if packed!=to_screen(q):
                continue
            lo=q+(code&31)*width/32
            hi=lo+width/32
            if not to_screen(lo)-1<=before<=to_screen(hi)+1:
                continue
            rows.append([lo,hi])
    return rows


def preflight():
    assert all(to_screen(from_srgb(code))==code for code in range(256))
    def marker(v,bits):
        w,=struct.unpack('<I',struct.pack('<f',v))
        return (w>>(18-bits))&255
    for row in anchors.values():
        for v,q,bits in zip(row['states']['1199']['o0'],row['eventComposite'],[6,6,5]):
            v,q=v*.25,q*.25
            intervals=possibilities(marker(v,bits),to_screen(v),to_screen(q),bits)
            assert sum(lo<=v<hi for lo,hi in intervals)==1


def run():
    preflight()
    lock=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lock['state']=='held' and Path(lock['output'])==M
    assert check(B,run=M,planned=3_750_000)['allowed']
    coords,_,immutable,commands=base['inputs']()
    player=base['player']
    assert sha(player)==read(base['qualification'])['candidatePlayer']
    csrc=CASE/'mesh.frag'
    assert sha(csrc)==read(CASE/'preflight.json')['source']
    source=csrc.read_text('utf8')
    assert source.count(base['original'])==1
    (home/'programs').mkdir(parents=True,exist_ok=True)
    cand=home/'mesh.frag'
    cand.write_text(source.replace(base['original'],replacement),encoding='utf8')
    for n in H['programs']:
        H['compile_program'](cand,home/'programs'/n,n,diagnostics=home/'compile'/f'{n}.log')
    receipts={n:sha(home/'programs'/n) for n in H['programs']}
    with art.database(B) as conn:
        pinned=art.rows(conn)[R.name]
    assert pinned['status']=='closed'
    art.resume(B,R.name)
    result = dict(status='measured-player-prepacking-bins', source=sha(cand), programs=receipts,
                  immutable=immutable, player=sha(player), probes={}, stage='raw positive material RGB')
    try:
        for dev,command in commands.items():
            with activate_links(receipts):
                frame=base['capture'](dev,command,'probe')
            a=H['score']['image'](frame)
            bare=CASE/f'{dev}-bare/frames/frame_000000.png'
            trunc=M/'iris-unsigned-output-readonly'/f'{dev}-candidate/frames/frame_000000.png'
            b,s=map(H['score']['image'],(bare,trunc))
            x,y=coords
            outside=np.any(a!=b,axis=2)
            outside[y,x]=False
            assert not outside.any(),(dev,int(outside.sum()))
            patches=np.column_stack((x,y,a[y,x]))
            proof=home/f'{dev}-probe-pixels.npz'
            np.savez_compressed(proof,pixels=patches)
            recovered=b.copy()
            p=np.load(proof)['pixels']
            recovered[p[:,1],p[:,0]]=p[:,2:]
            assert np.array_equal(recovered,a)
            rows=[]
            for point,row in anchors.items():
                xx,yy=point
                codes=[int(v) for v in a[yy,xx]]
                unmodified=b[yy,xx].tolist()
                packed=s[yy,xx].tolist()
                ranges=[possibilities(*args) for args in zip(codes,unmodified,packed,[6,6,5])]
                rows.append(dict(point=point,native=[v*.25 for v in row['states']['1199']['o0'][:3]],codes=codes,
                                 bareDisplay=unmodified,packedDisplay=packed,possibleRawIntervals=ranges))
            result['probes'][dev]=dict(frame=sha(frame),baseline=sha(bare),packed=sha(trunc),
                pixels=sha(proof),exactOutside=True,rows=rows)
            write(home/'results.json',result)
            assert frame.resolve().parent==(home/f'{dev}-probe/frames').resolve() and not frame.is_symlink()
            frame.unlink()
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=90)
    with art.database(B) as conn:
        restored=art.rows(conn)[R.name]
    assert restored['status']=='closed' and restored['manifestSha256']==pinned['manifestSha256']
    assert immutable==base['inputs']()[2]
    archive=home/'programs.zip'
    with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
        for n in receipts:
            z.write(home/'programs'/n,n)
    with ZipFile(archive) as z:
        from hashlib import sha256
        assert z.testzip() is None and {n:sha256(z.read(n)).hexdigest() for n in receipts}==receipts
    for n in receipts:
        p=home/'programs'/n
        assert p.parent.resolve()==(home/'programs').resolve() and not p.is_symlink() and sha(p)==receipts[n]
        p.unlink()
    result['programArchive']=sha(archive)
    write(home/'results.json',result)
    print([v['rows'] for v in result['probes'].values()])


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        preflight()
    else:
        run()
