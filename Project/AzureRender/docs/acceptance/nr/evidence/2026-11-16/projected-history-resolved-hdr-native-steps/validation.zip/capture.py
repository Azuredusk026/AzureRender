"""Combine the native step bound with the previous submitted HDR resolve."""
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import sys
import subprocess
from zipfile import ZipFile, ZIP_DEFLATED

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
O=M/'joint-projected-resolved-hdr-native-step-bound'
H=runpy.run_path(str(M/'run-immutable-scene-glyph-capture.py'),run_name='joint_temporal_actual')
S=H['S']
read,write,fingerprint=[H[k] for k in ('read','write','sha')]
P=M/'projected-history-layer-release/AzurePlayerResolvedHistoryTrial.exe'
history_switch='AZR_NR_QA_PROJECTED_RESOLVED_HISTORY'


def run():
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    assert check(W/'build',run=M,planned=22_000_000)['allowed']
    assert all(not os.environ.get(k) for k in H['ENV'])
    source=H['immutable_index']()
    build=read(M/'projected-resolved-history-trial/qualification.json')
    assert fingerprint(P)==build['candidate'] and build['baseline']==fingerprint(H['PLAYER'])
    stage=M/'joint-current-temporal-resolve'
    control=read(stage/'qualification.json')
    assert control['status']=='measured-temporal-display-resolve-on-actual-joint-scene'
    assert control['player']==build['baseline'] and control['immutable']==source
    stage_hdr=M/'joint-projected-previous-resolved-hdr-retry'
    hd=read(stage_hdr/'qualification.json')
    assert hd['status']=='measured-projected-with-resolved-hdr-history' and hd['player']==fingerprint(P)
    assert hd['reports']['nvidia']['firstExact']
    intel_first=hd['reports']['intel']['rows'][0]
    assert intel_first['metrics']['complete']['changed']==4
    assert not any(intel_first['metrics'][r]['changed'] for r in ('centerFloor','cyanRing'))
    tree=H['tree_stamp']()
    gold=S['img'](H['gold'])
    O.mkdir()
    reports={}
    for gpu in ('nvidia','intel'):
        base=M/f'projected-reflection-32-step-candidate/baseline-{gpu}'
        initial=read(base/'result.json')
        exact=control['reports'][gpu]
        target_prior=hd['reports'][gpu]
        original_manifest=read(stage_hdr/gpu/'frames/capture_manifest.json')
        args=read(M/f'projected-reflection-native-phase-candidate/candidate-{gpu}/command.json')
        args[0]=str(P)
        out=O/gpu
        out.mkdir()
        for k,v in (('--capture-frames','2'),('--capture-dir',out/'frames'),('--runtime-report',out/'runtime.json')):
            args[args.index(k)+1]=str(v)
        assert args[args.index('--project')+1]==str(H['project'])
        if '--anti-aliasing' in args:
            args[args.index('--anti-aliasing')+1]='temporal'
        else:
            args.extend(('--anti-aliasing','temporal'))
        assert history_switch not in os.environ
        os.environ[history_switch]='1'
        try:
            S['invoke'](gpu,args,out)
        finally:
            os.environ.pop(history_switch)
        actual=read(out/'frames/capture_manifest.json')
        caps=read(out/'frames/gpu_capabilities.json')
        assert caps['driver_version']==initial['driver']
        assert all(actual[k]==original_manifest[k] for k in S['forbid']),{k:(actual[k],original_manifest[k]) for k in S['forbid'] if actual[k]!=original_manifest[k]}
        assert actual['capturedFrames']==2 and actual['screenReflectionProducer']=='projected-history'
        log=(out/'player.log').read_text(encoding='utf8',errors='replace')
        assert 'Capture resource ' not in log
        assert log.count('QA projected reflection uses submitted HDR resolve 1')==1,log[-3000:]
        rt=read(out/'runtime.json')
        assert not rt['presentationErrors'] and not rt['scriptErrors']
        temporal={k:v for k,v in actual.items() if 'temporal' in k.lower() or 'alias' in k.lower()}
        rows=[]
        for i in range(2):
            name=f'frame_{i:06d}.png'
            ctrlpath=base/'frames'/name
            p=out/'frames'/name
            assert fingerprint(ctrlpath)==initial['images'][i]
            ctrl,frame=(cv2.imread(str(f),cv2.IMREAD_UNCHANGED) for f in (ctrlpath,p))
            assert ctrl.shape==frame.shape==(1440,2560,4)
            witness=exact['rows'][i]
            baseline_archive=stage/gpu/f'delta-{i}.zip'
            assert witness['deltaArchive']==fingerprint(baseline_archive) and witness['xorDonorPng']==fingerprint(ctrlpath)
            with ZipFile(baseline_archive) as z:
                ctrl^=np.frombuffer(z.read('bgra-xor'),np.uint8).reshape(ctrl.shape)
            assert sha256(ctrl.tobytes()).hexdigest()==witness['raw']
            intermediate=witness
            witness=target_prior['rows'][i]
            previous_archive=stage_hdr/gpu/f'delta-{i}.zip'
            assert witness['deltaArchive']==fingerprint(previous_archive) and witness['xorDonorPng']==intermediate['png']
            with ZipFile(previous_archive) as z:
                ctrl^=np.frombuffer(z.read('bgra-xor'),np.uint8).reshape(ctrl.shape)
            assert sha256(ctrl.tobytes()).hexdigest()==witness['raw']
            source_rgb=cv2.cvtColor(ctrl,cv2.COLOR_BGRA2RGB)
            actual_rgb=cv2.cvtColor(frame,cv2.COLOR_BGRA2RGB)
            metrics={}
            for key,(x,y,u,v) in S['regions'].items():
                native,base_rgb,curr=(data[y:v,x:u] for data in (gold,source_rgb,actual_rgb))
                before,after=(np.abs(a.astype(np.int16)-native).max(2) for a in (base_rgb,curr))
                metrics[key]=dict(baseline=S['score'](base_rgb,native),candidate=S['score'](curr,native),
                    changed=int(np.count_nonzero(np.any(base_rgb!=curr,axis=2))),
                    newOverOne=int(np.count_nonzero((before<=1)&(after>1))))
            encoded=out/f'delta-{i}.zip'
            with ZipFile(encoded,'x',ZIP_DEFLATED,compresslevel=9) as z:
                z.writestr('bgra-xor',np.bitwise_xor(ctrl,frame).tobytes())
            with ZipFile(encoded) as z:
                assert z.testzip() is None
                decoded=ctrl^np.frombuffer(z.read('bgra-xor'),np.uint8).reshape(ctrl.shape)
                assert np.array_equal(decoded,frame)
            rows.append(dict(png=fingerprint(p),xorDonorPng=witness['png'],comparisonPng=witness['png'],
                raw=sha256(frame.tobytes()).hexdigest(),deltaArchive=fingerprint(encoded),metrics=metrics,
                equalTemporalControl=bool(np.array_equal(ctrl,frame))))
            assert p.resolve()==p and not p.stat().st_file_attributes&1024
            p.unlink()
        reports[gpu]=dict(temporal=temporal,rows=rows,gpu=caps['driver_version'],
                         loadedReflection=actual['screenReflectionProducer'],firstExact=rows[0]['equalTemporalControl'],
                         secondChanged=not rows[1]['equalTemporalControl'])
        write(O/'qualification.json',dict(status='capturing-projected-with-resolved-history',reports=reports))
        print(gpu,{k:temporal[k] for k in temporal if 'alias' in k.lower() or 'frame' in k.lower()},
              [{k:(r['metrics'][k]['candidate']['ssim'],r['metrics'][k]['candidate']['medianLumaRelativeError'])
               for k in ('centerFloor','cyanRing')} for r in rows],flush=True)
    assert H['immutable_index']()==source and H['tree_stamp']()==tree
    write(O/'qualification.json',dict(status='measured-resolved-hdr-with-native-step-bound',reports=reports,
         immutable=source,player=fingerprint(P),build=build,firstFramesExact=all(r['firstExact'] for r in reports.values()),
         formalReflectionAcceptance=False,traceMaximumSteps=32,program=shader_recipe['binary']))


def native_step_program():
    global shader_recipe
    import artifact_maintenance as art
    from artifact_budget import check
    g=runpy.run_path(str(M/'iris-player-prepacking-bins.py'),run_name='hdr_native_step_catalog')
    R=g['R']
    stage=M/'projected-reflection-32-step-candidate'
    receipt=read(stage/'candidate-receipt.json')
    shader='projected_reflection_trace.comp.spv'
    shader_recipe=receipt['program']
    record={shader:shader_recipe['binary']}
    assert fingerprint(stage/'programs'/shader)==record[shader]
    baseline=R/'msaa-release/shaders'/shader
    assert fingerprint(baseline)==shader_recipe['control']
    g['activate_links'].__wrapped__.__globals__['home']=stage
    with art.database(W/'build') as db:
        q=art.rows(db)[R.name]
    assert q['status']=='closed'
    art.resume(W/'build',R.name)
    try:
        with g['activate_links'](record):
            run()
    finally:
        subprocess.run([sys.executable,str(W/'tools/artifact_cleanup.py'),'--finish',str(R)],check=True,timeout=320)
    with art.database(W/'build') as db:
        after=art.rows(db)[R.name]
    assert after['status']=='closed' and after['manifestSha256']==q['manifestSha256']
    assert fingerprint(baseline)==shader_recipe['control']


if __name__=='__main__':
    native_step_program()
