"""Score the native readback independently, preserving the source and display coordinates."""
import ast
from hashlib import sha256
import json
from pathlib import Path
import runpy
import numpy as np

run=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes()); digest=lambda b:sha256(b).hexdigest()
cs=runpy.run_path(str(run/'score-projected-history-coordinates.py'),run_name='coordinate_score')
source=cs['source']; reader=source['reader']; c=Path(cs['floor'])/'native'
receipt=read(c/'results.json'); assert receipt['status']=='qualified' and receipt['baselineRestored']
control,marker,observed=(receipt['control'],receipt['outputs']['marker'],receipt['outputs']['coordinates'])
assert control[0]==marker[0]==observed[0] and control[2]==marker[2]==observed[2]
fixture=reader['native_fixture'](reader['request']('native'),None)
manifest=Path(fixture['replaySource']['manifest']); d=read(manifest)
crop=cs['base']['CROP']; w,h=(crop[i+2]-crop[i] for i in (0,1))
kind=cs['check_snapshot']
uv=kind(c/'history-uv.bin',observed[1],'<u2',(h,w,2))
confidence=kind(c/'trace-confidence.bin',observed[2],'u1',(h,w))
colors=kind(c/'trace-color.bin',observed[0],'<u4',(h,w))
assert int((confidence>0).sum())==receipt['hits']
entry=next(x for x in d['outputs'] if x['role']=='color')['reference']
record=(manifest.parent/entry['file']).read_bytes(); assert digest(record)==entry['sha256']
assert colors.tobytes()==runpy.run_path(str(run/'projected-history-coordinates.py'))['region'](record,4,True)
entry=next(x for x in d['textures'] if x['role']=='previousColor')
raw=(manifest.parent/entry['file']).read_bytes(); assert digest(raw)==entry['sha256']
point_bytes=reader['at_history_uv'](raw,2560,1440,True,True,uv.tobytes())
prior_rgb=np.frombuffer(point_bytes,dtype='<f2').reshape(h,w,4)[...,:3].astype(np.float32)
lin_luma=prior_rgb@np.array([.2126,.7152,.0722])
compressed=prior_rgb*(np.float32(1)/(np.float32(1)+prior_rgb.max(axis=-1,keepdims=True)))
codec=ast.parse((run/'preview-native-history-color-support.py').read_text())
fn=next(node for node in codec.body if isinstance(node,ast.FunctionDef) and node.name=='encode_channels')
ns={'np':np};exec(compile(ast.Module(body=[fn],type_ignores=[]),'fingerprinted-color-codec','exec'),ns)
packed=ns['encode_channels'](compressed)
safe=cs['stable_indices'](uv[...,0],2560)&cs['stable_indices'](uv[...,1],1440)
entry=next(x for x in d['textures'] if x['role']=='previousDepth')
raw=(manifest.parent/entry['file']).read_bytes(); assert digest(raw)==entry['sha256']
nd=np.frombuffer(raw[:entry['levels'][0]['bytes']],dtype='<f4').reshape((720,1280))[::-1]
entry=next(x for x in source['v']['inputs'] if x['name']=='previousDepth')['data']
pd=kind(reader['current'].parent/entry['file'],entry['sha256'],'<f4',(720,1280))
wn,n_valid,_=cs['world_from_history'](uv,nd,source['nmat'],True)
# Native UV y points up; the Player comparison uses the same display location.
flipped=uv.copy();flipped[...,1]=65535-flipped[...,1]
wp,p_valid,canonical_uv=cs['world_from_history'](flipped,pd,source['vmat'],False)
assert np.max(abs(canonical_uv[...,1]-(1-uv[...,1].astype(float)/65535))) < 1e-12
p_dist=np.linalg.norm(wn-wp,axis=-1)
regions=read(source['root']/'docs/acceptance/nr/evidence/2026-11-16/joint-scene-native-floor/results.json')['rectangles']
output=dict(status='qualified-native-history-endpoint-observations',capture=receipt,priorDepthSources={
    'native':fixture['payloads'][1]['fullSha256'],'player':entry['sha256']},historyColorPointSamples=digest(point_bytes),regions={})
for label in ('centerFloor','cyanRing'):
    local=tuple(v//2-crop[i%2] for i,v in enumerate(regions[label])); sub=lambda x:source['cut'](x,local)
    seen=sub(confidence)>0
    stable=seen&sub(safe)
    exact=stable&sub(packed==colors)
    assert int(exact.sum())>0
    matches=exact&sub(n_valid&p_valid)&sub(cs['stable_indices'](uv[...,0],1280)&cs['stable_indices'](uv[...,1],720))
    q=lambda data,mask:np.percentile(data[mask],(10,50,90)).tolist()
    output['regions'][label]=dict(hits=int(seen.sum()),stableTextureAddresses=int(stable.sum()),
        exactNativeOutputWords=int(exact.sum()), sourceLinearLuma=q(sub(lin_luma),exact),
        selectedScreenU=q(sub(canonical_uv[...,0]),exact), selectedScreenV=q(sub(canonical_uv[...,1]),exact),
        distinctSelection=int(np.unique(sub(uv)[exact],axis=0).shape[0]),sameDisplayHistoryDepthChecked=int(matches.sum()),
        depthWithinTwoCm=int((matches&(sub(p_dist)<=.02)).sum()),depthWithinTenCm=int((matches&(sub(p_dist)<=.10)).sum()),
        worldDifferenceAtNativeAddress=q(sub(p_dist),matches))
report=run/'projected-history-coordinates/native-endpoints-score.json'
report.write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
for k,v in output['regions'].items():print(k,v)
