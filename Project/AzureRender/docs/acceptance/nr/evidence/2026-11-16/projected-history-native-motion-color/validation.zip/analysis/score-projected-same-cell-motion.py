"""Cross-check actual motion inputs at the native ray's resolvable screen locations."""
from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys

import numpy as np

root=Path(__file__).resolve().parent
m=runpy.run_path(str(root/'projected-native-motion-inverse.py'))
s,b,read=m['s'],m['b'],m['read']
r=s['source']
C=b['CROP']; h,w=C[3]-C[1],C[2]-C[0]


def data():
    _,_,manifest,rows=s['original_history_depths']()
    motion,=[o for o in rows if o['role']=='motion']
    W,H=motion['width'],motion['height']
    assert (W,H)==(2560,1440) and motion['format']=='R10G10B10A2_UNORM'
    packed=s['check_snapshot'](manifest.parent/motion['file'],motion['sha256'],'<u4',(H,W))
    old,=[o for o in r['v']['inputs'] if o['name']=='motionInput']
    assert old['fixedBindNumber']==5 and old['format']=='R32G32B32A32_FLOAT'
    assert r['v']['frameRows'][29][2]>.5 and r['v']['frameRows'][27][2]==0
    assert r['n']['blocks'][2]['variables'][2]['float32'][2]==0
    x,y,u,v=old['regionXYXY']
    lin=s['check_snapshot'](b['VULKAN']/old['data']['file'],old['data']['sha256'],'<f4',(v-y,u-x,4))
    assert np.isfinite(lin).all()
    return manifest,rows,packed,lin,old,motion['sha256']


def depth(manifest, rows):
    n,=[o for o in rows if o['role']=='currentDepth']
    raw=(manifest.parent/n['file']).read_bytes()
    assert sha256(raw).hexdigest()==n['sha256']
    nd=np.frombuffer(raw[:n['levels'][0]['bytes']],dtype='<f4').reshape(s['shape'])[::-1]
    v,=[o['data'] for o in r['v']['inputs'] if o['name']=='currentDepth']
    vd=s['check_snapshot'](b['VULKAN']/v['file'],v['sha256'],'<f4',s['shape'])
    invN=np.asarray([o['float32'] for o in r['n']['blocks'][0]['variables'][24:28]])
    invP=np.asarray(r['v']['frameRows'][14:18])
    return nd,vd,invN,invP


def score():
    manifest,rows,packed,lin,old,motion_id=data()
    x,y,u,v=old['regionXYXY']
    H,W=packed.shape
    folder=s['floor']/'native'
    source=read(folder/'results.json')
    assert source['status']=='qualified' and source['baselineRestored']
    _,uv_id,conf_id=source['outputs']['coordinates']
    coords=s['check_snapshot'](folder/'history-uv.bin',uv_id,'<u2',(h,w,2))
    conf=s['check_snapshot'](folder/'trace-confidence.bin',conf_id,'u1',(h,w))
    eligible=(conf>0)&((coords>0)&(coords<65535)).all(axis=-1)
    motion=m['decode'](packed)
    _,_,_,native_source=m['invert'](motion,coords[eligible]/65535.,.5/65535.+1e-6,return_unique=True)
    known=np.full((h,w,2),-1)
    known[eligible]=native_source
    px,py=known[...,0],H-1-known[...,1]
    roi=(px>=x)&(px<u)&(py>=y)&(py<v)
    select=lambda mask:np.clip(mask,0,0)
    px=np.clip(px,0,W-1); py=np.clip(py,0,H-1)
    nvalues=motion[H-1-py,px].astype(np.float64)*[1,-1]
    pvalues=lin[np.clip(py-y,0,v-y-1),np.clip(px-x,0,u-x-1)]
    pdelta=pvalues[...,:2].astype(np.float64)+np.asarray(r['v']['frameRows'][26][2:4])
    d=nvalues-pdelta
    nd,pd,nm,pm=depth(manifest,rows)
    uv=np.stack(((px+.5)/W,(py+.5)/H),axis=-1)
    def world(plane, matrix):
        z=plane[py//2,px//2]
        c=np.concatenate((uv*2-1,z[...,None],np.ones_like(z[...,None])),axis=-1)
        with np.errstate(divide='ignore',invalid='ignore'):
            return r['homogeneous'](c,matrix),np.isfinite(z)&(z>0)&(z<=1)
    wn,nvalid=world(nd,nm)
    wp,pvalid=world(pd,pm)
    distance=np.linalg.norm(wn*r['flip']-wp,axis=-1)
    safe=roi&nvalid&pvalid&(distance<=.02)
    scale=np.asarray([W,H])
    output=dict(status='qualified-same-source-cell-motion-input-cross-check',motionSha256={
        'native':motion_id,'player':old['data']['sha256']}, nativeHistoryUvSha256=uv_id,
        playerMotionRoi=old['regionXYXY'],playerMotionUvOffset=r['v']['frameRows'][26][2:4],
        scope='Same display texel of a resolved native pre-motion source, with matching geometry. A Player ray is not tied to this texel by this test.',
        regions={})
    for name,box in b['REGIONS'].items():
        clip=lambda a:b['cut'](a,b['local'](box))
        used=clip(safe)
        statistics=lambda a:np.percentile(clip(np.linalg.norm(a*scale,axis=-1))[used],[10,50,90,99]).tolist() if used.any() else None
        codes,counts=np.unique(clip(pvalues)[used,3],return_counts=True)
        output['regions'][name]=dict(totalPositive=int(clip(eligible).sum()),nativeUnique=int((clip(known)[...,0]>=0).sum()),
            inPlayerMotionRoi=int(clip(roi).sum()),sameCurrentSurface=int(used.sum()),
            motionPixelsNative=statistics(nvalues),motionPixelsPlayer=statistics(pdelta),
            motionDifferencePixels=statistics(d),playerClasses={str(float(k)):int(v) for k,v in zip(codes,counts)})
    (s['floor']/'same-source-cell-motion-comparison.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output))


if __name__=='__main__':
    m['preflight']()
    assert sys.argv[1:] in (['preflight'],['score'])
    if sys.argv[1:]==['score']:
        score()
    else:
        manifest,rows,*_=data()
        depth(manifest,rows)
