"""Measure native ray-source motion beyond the camera-only projection."""
from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys

import numpy as np

root=Path(__file__).resolve().parent
m=runpy.run_path(str(root/'projected-native-motion-inverse.py'))
s,b,read=m['s'],m['b'],m['read']
r=s['source']


def projection(uv,depth,matrix,rewind):
    p0=np.concatenate((uv*2-1,depth[...,None],np.ones_like(depth[...,None])),axis=-1)
    before=p0@matrix
    p1=before@np.linalg.inv(rewind)
    with np.errstate(divide='ignore',invalid='ignore'):
        return p1[...,:2]/p1[...,3,None]*.5+.5


def score():
    depths,depth_evidence,manifest,table=s['original_history_depths']()
    r0,mt=(next(o for o in table if o['role']==role) for role in ('currentDepth','motion'))
    raw=(manifest.parent/r0['file']).read_bytes()
    assert len(raw)==r0['bytes'] and sha256(raw).hexdigest()==r0['sha256']
    nd=np.frombuffer(raw[:r0['levels'][0]['bytes']],dtype='<f4').reshape(s['shape'])[::-1]
    H,W=mt['height'],mt['width']
    packed=s['check_snapshot'](manifest.parent/mt['file'],mt['sha256'],'<u4',(H,W))
    crop=b['CROP'];h,w=crop[3]-crop[1],crop[2]-crop[0]
    p=s['floor']/'native'
    o=read(p/'results.json')
    assert o['status']=='qualified' and o['baselineRestored']
    _,ui,ci=o['outputs']['coordinates']
    c=s['check_snapshot'](p/'history-uv.bin',ui,'<u2',(h,w,2))
    cc=s['check_snapshot'](p/'trace-confidence.bin',ci,'u1',(h,w))
    use=(cc>0)&((c>0)&(c<65535)).all(axis=-1)
    motion=m['decode'](packed)
    shift=np.array([W,H])
    _,_,_,candidate=m['invert'](motion,c[use]/65535.,.5/65535.+1e-6,return_unique=True)
    coords=np.full((h,w,2),-1); coords[use]=candidate
    x,y=coords[...,0],coords[...,1]
    obs=(x>=0)&(y>=0)
    x=np.clip(x,0,W-1); y=np.clip(y,0,H-1)
    estimated=c/65535.+motion[y,x]
    before=estimated.copy(); before[...,1]=1-before[...,1]
    after=c/65535.; after[...,1]=1-after[...,1]
    dep=nd[(H-1-y)//2,x//2]
    valid=obs&np.isfinite(dep)&(dep>0)&(dep<=1)
    cv=np.asarray([a['float32'] for a in r['n']['blocks'][0]['variables'][24:28]])
    ideal=projection(before,dep,cv,s['N'])
    valid&=np.isfinite(ideal).all(axis=-1)
    data=dict(status='native-same-world-camera-control',nativeTraceUv=ui,motionSha256=mt['sha256'],
              currentDepthSha256=r0['sha256'], previousDepthSha256=depth_evidence['native'],
              scope='An inferred native source with a unique motion cell and finite current depth. The camera control projects a stationary world point with the original matrices.',
              regions={})
    for k,box in b['REGIONS'].items():
        cut=lambda q:b['cut'](q,b['local'](box))
        usable=cut(valid)
        a,p,c=(cut(np.linalg.norm(q*shift,axis=-1))[usable] for q in (after-before,ideal-before,after-ideal))
        pct=lambda v:np.percentile(v,[10,50,90,99,100]).tolist()
        data['regions'][k]=dict(usable=int(usable.sum()),nativeObservedMotionPixels=pct(a),
            stationaryPointCameraMotionPixels=pct(p),residualAfterStationaryCameraPixels=pct(c),
            residualOverHalfPixel=int((c>.5).sum()), residualOverOnePixel=int((c>1.).sum()))
    (s['floor']/'native-camera-motion-control.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
    print(json.dumps(data))


if __name__=='__main__':
    m['preflight']()
    x=np.array([[.25,.75],[.01,.99]]);z=np.full(2,.05)
    np.testing.assert_allclose(projection(x,z,s['N'],s['N']),x,atol=1e-12)
    assert sys.argv[1:] in (['preflight'],['score'])
    if sys.argv[1:]==['score']:
        score()
