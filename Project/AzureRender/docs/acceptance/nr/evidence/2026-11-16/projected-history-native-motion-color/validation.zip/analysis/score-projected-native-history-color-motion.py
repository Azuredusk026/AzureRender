"""Measure the native prior-color effect of removing only the actual reprojected motion."""
import ast
from hashlib import sha256
import json
import numpy as np
from pathlib import Path
import runpy
import sys

root=Path(__file__).resolve().parent
m=runpy.run_path(str(root/'projected-native-motion-inverse.py'))
s,b,read=m['s'],m['b'],m['read']
r=s['source']


def point(uv,color):
    h,w=color.shape[:2]
    scale=np.array([w,h])
    center=np.floor(uv*scale).astype(np.int64)
    radius=.5/65535.+1e-6
    stable=(np.floor((uv-radius)*scale)==np.floor((uv+radius)*scale)).all(axis=-1)
    x=np.clip(center[...,0],0,w-1);y=np.clip(center[...,1],0,h-1)
    return color[y,x],stable


def score():
    _,_,manifest,rows=s['original_history_depths']()
    motion,source=(next(o for o in rows if o['role']==tag) for tag in ('motion','previousColor'))
    H,W=motion['height'],motion['width']
    assert (source['height'],source['width'])==(H,W)==(1440,2560)
    packed=s['check_snapshot'](manifest.parent/motion['file'],motion['sha256'],'<u4',(H,W))
    raw=(manifest.parent/source['file']).read_bytes()
    assert len(raw)==source['bytes'] and sha256(raw).hexdigest()==source['sha256']
    color=np.frombuffer(raw[:source['levels'][0]['bytes']],dtype='<f2').reshape(H,W,4)
    crop=b['CROP'];h,w=crop[3]-crop[1],crop[2]-crop[0]
    folder=s['floor']/'native'
    capture=read(folder/'results.json')
    assert capture['status']=='qualified' and capture['baselineRestored']
    color_id,uv_id,conf_id=capture['outputs']['coordinates']
    exact=s['check_snapshot'](folder/'trace-color.bin',color_id,'<u4',(h,w))
    native_conf=s['check_snapshot'](folder/'trace-confidence.bin',conf_id,'u1',(h,w))
    uv=s['check_snapshot'](folder/'history-uv.bin',uv_id,'<u2',(h,w,2))
    nActive=(native_conf>0)&((uv>0)&(uv<65535)).all(axis=-1)
    v=r['v']
    pData={o['name']:o['data'] for o in v['outputs']}
    from_scene=lambda name,dtype:b['cut'](s['check_snapshot'](b['VULKAN']/pData[name]['file'],pData[name]['sha256'],dtype,s['shape']),crop)
    pcolor=s['decode'](from_scene('outputColor','<u4'))
    pconf=from_scene('outputConfidence','u1')
    t=m['decode'](packed)
    _,_,_,before_cell=m['invert'](t,uv[nActive]/65535.,.5/65535.+1e-6,return_unique=True)
    samples=np.full((h,w,2),-1);samples[nActive]=before_cell
    x,y=samples[...,0],samples[...,1]
    before=uv/65535.+t[np.clip(y,0,H-1),np.clip(x,0,W-1)]
    without,good1=point(before,color)
    actual,good2=point(uv/65535.,color)
    codec=ast.parse((root/'preview-native-history-color-support.py').read_text())
    fn=next(node for node in codec.body if isinstance(node,ast.FunctionDef) and node.name=='encode_channels')
    ns={'np':np}
    exec(compile(ast.Module(body=[fn],type_ignores=[]),'fingerprinted-color-codec','exec'),ns)
    def pack(values):
        rgb=values[...,:3].astype(np.float32)
        compressed=rgb*(np.float32(1)/(np.float32(1)+rgb.max(axis=-1,keepdims=True)))
        return ns['encode_channels'](compressed)
    actual_packed,bare_packed=pack(actual),pack(without)
    original=s['decode'](exact)
    candidate=s['decode'](bare_packed)
    consistent=actual_packed==exact
    native_depth_row=next(o for o in read(s['geometry']/'results.json')['files'] if o['name']=='current-depth')
    nd=s['check_snapshot'](s['geometry']/'current-depth.bin',native_depth_row['sha256'],'<f4',(h,w))
    vdepth=next(o['data'] for o in r['v']['inputs'] if o['name']=='currentDepth')
    pd=b['cut'](s['check_snapshot'](b['VULKAN']/vdepth['file'],vdepth['sha256'],'<f4',s['shape']),crop)
    nm=np.asarray([row['float32'] for row in r['n']['blocks'][0]['variables'][24:28]])
    pm=np.asarray(r['v']['frameRows'][14:18])
    receiving_surface=(np.linalg.norm(b['reconstruct'](nd,crop,nm)*r['flip']-b['reconstruct'](pd,crop,pm),axis=-1)<=.02)
    chosen=(x>=0)&(y>=0)&good1&good2&consistent&(pconf>0)&receiving_surface
    controls={}
    for name, box in b['REGIONS'].items():
        clip=lambda x:b['cut'](x,b['local'](box))
        eligible=clip(good2&nActive)
        mismatched=eligible & ~clip(consistent)
        print(name, 'packed control exact',int(eligible.sum()-mismatched.sum()),'of',int(eligible.sum()),flush=True)
        if name in ('centerFloor','cyanRing'):
            assert not mismatched.any(), (name,np.argwhere(mismatched).tolist())
        controls[name]=dict(stable=int(eligible.sum()), exact=int(eligible.sum()-mismatched.sum()),
                            excludedControls=np.argwhere(mismatched).tolist())

    conf=np.minimum(native_conf,pconf)/255
    weights=s['weight']
    nL,pL,bL=(d@weights for d in (original,pcolor,candidate))
    delta=bL-nL
    report=dict(status='native-rendered-history-source-motion-control',
                previousColor=source['sha256'], motion=motion['sha256'], coordinate=uv_id,nativeTrace=color_id,
                playerTrace=pData['outputColor']['sha256'],playerConfidence=pData['outputConfidence']['sha256'],
                scope='Fixed native prior HDR image, original native output and retained Player trace at the same receiving coordinate. The control samples the inferred pre-motion UV. Only unique native motion cells, stable source texels, reproduced native packed colors, and receiving surfaces within 2 cm are counted.',
                packedNativeControl=controls, regions={})
    for name,box in b['REGIONS'].items():
        sub=lambda a:b['cut'](a,b['local'](box))
        mask=sub(chosen)
        joint=lambda a:sub(a)[mask]
        wgt=joint(conf)
        orig=joint(nL-pL); moved=joint(delta)
        assert len(orig)>0 and np.sum(abs(orig)*wgt)>0
        v0,v1,v2=(float(np.sum(abs(j)*wgt)) for j in (orig,orig+moved,moved))
        report['regions'][name]=dict(samples=int(mask.sum()),samplesChanged=int((moved!=0).sum()),
            absoluteLumaMotionEffect=np.percentile(abs(moved),[50,90,99,100]).tolist(),
            weightedRawAbsoluteError=v0, weightedAbsoluteErrorWithoutNativeMotion=v1,
            weightedNativeMotionAbsoluteChange=v2, observedErrorFractionBoundFromOnlyNativeMotion=v2/v0,
            observedWeightedErrorRelativeChange=v1/v0-1)
    (s['floor']/'native-history-color-motion-control.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report))


if __name__=='__main__':
    m['preflight']()
    v,valid=point(np.array([[.1,.2],[.5,.2]]),np.zeros((2,2,4)))
    np.testing.assert_equal(valid,[True,False])
    assert sys.argv[1:] in (['preflight'],['score'])
    if sys.argv[1:]==['score']: score()
