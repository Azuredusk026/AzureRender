"""Relink the production reflection renderer against the retained Release inputs."""
import ast
from hashlib import file_digest,sha256
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys

M=Path(__file__).resolve().parent
W=M.parents[2]
R=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
release=R/'msaa-release'
base=M/'projected-history-layer-release'
reference=M/'immutable-scene-capture-source'
out=M/'primary-linear-reflection-build'
exe=base/'AzurePlayerPrimaryLinearReflection.exe'
read=lambda p:json.loads(p.read_bytes())


def sha(p):
    with Path(p).open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


def source_check():
    src=W/'src/scenes/CharacterSceneRenderer.cpp'
    new=src.read_text(encoding='utf8')
    before=subprocess.check_output(['git','show','40351a0:Project/AzureRender/src/scenes/CharacterSceneRenderer.cpp'],
                                   cwd=W,encoding='utf8')
    decl='''        // Keep the linear temporal reflection dispatch in the primary command buffer.
        const bool recordInSecondary=reflectionReprojection_==nullptr;
'''
    assert new.count(decl)==1
    changed='''            recordScreenReflection(commands,slot,inputs,view,settings);
        },recordInSecondary);'''
    assert new.count(changed)==1
    assert new.replace(decl,'').replace(changed,changed.replace('recordInSecondary','true'))==before
    return src


def build():
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    budget=check(W/'build',run=M,planned=20_850_000)
    assert budget['allowed'],budget
    src=source_check()
    q=read(reference/'qualification.json')
    assert q['candidatePlayer']==sha(base/'AzurePlayerCaptureResource.exe')
    assert q['entryObject']==sha(reference/'main.cpp.obj') and q['assetDatabaseObject']==sha(reference/'AssetDatabase.cpp.obj')
    out.mkdir(exist_ok=True)
    method=runpy.run_path(str(R/'face-quality-batch.py'),run_name='primary_linear_reflection_compiler')
    ninja=Path(method['cmake']).parents[2]/'Ninja/ninja.exe'
    schema=ast.parse((M/'build-camera-pose-player.py').read_text(encoding='utf8'))
    f,=[x for x in schema.body if isinstance(x,ast.FunctionDef) and x.name=='windows_arguments']
    n={}
    exec(compile(ast.Module(body=[f],type_ignores=[]),'linear_reflection_arguments','exec'),n)
    ops=subprocess.check_output([str(ninja),'-C',str(release),'-t','commands','AzurePlayer'],text=True).splitlines()
    line,=[v for v in ops if v.endswith(str(src))]
    cl=n['windows_arguments'](line)
    assert Path(cl[0]).name.lower()=='cl.exe'
    object_file=out/'CharacterSceneRenderer.cpp.obj'
    for flag,path in [('/Fo',object_file),('/Fd',out/'object.pdb')]:
        i,=[i for i,v in enumerate(cl) if v.startswith(flag)]
        cl[i]=flag+str(path)
    rsp=out/'player.rsp'
    p=(reference/'player.rsp').read_text(encoding='ascii').splitlines()
    assert all(str(reference/x) in p[0] for x in ('main.cpp.obj','AssetDatabase.cpp.obj'))
    rsp.write_text('\n'.join([p[0]+' '+subprocess.list2cmdline([str(object_file)]),*p[1:]])+'\n',encoding='ascii')
    opts=read(base/'link-receipt.json')['linkCommand']
    cmd=opts.copy()
    for i,v in enumerate(cmd):
        if v.startswith('@'):
            cmd[i]='@'+str(rsp)
        elif v.startswith('--intdir='):
            d=out/'link-intermediates'
            d.mkdir(exist_ok=True)
            cmd[i]='--intdir='+str(d)
        elif v.lower().startswith('/out:'):
            cmd[i]='/out:'+str(exe)
        elif v.lower().startswith('/implib:'):
            cmd[i]='/implib:'+str(out/'diagnostic.lib')
        elif v.lower().startswith('/pdb:'):
            cmd[i]='/pdb:'+str(out/'diagnostic.pdb')
    env={k:v for k,v in os.environ.items() if not k.startswith('AZR_NR_QA_')}
    for name,args in [('compile',cl),('link',cmd)]:
        line=subprocess.list2cmdline([method['entry'],*args])
        r=subprocess.run(line,shell=True,cwd=release,env=env,capture_output=True,timeout=250)
        (out/f'{name}.log').write_bytes(r.stdout+r.stderr)
        assert r.returncode==0,(name,r.stdout[-2600:],r.stderr[-2600:])
    t=subprocess.run([str(exe),'--help'],env=env,capture_output=True,timeout=25)
    assert t.returncode==0 and b'--disable-parallel-recording' in t.stdout
    rec=dict(status='linked-primary-linear-reflection-production-change',source=sha(src),object=sha(object_file),
             player=sha(exe),baselinePlayer=q['candidatePlayer'],
             compileCommand=cl,linkCommand=cmd,qaResourceOverrideOnly=True)
    (out/'qualification.json').write_text(json.dumps(rec,indent=2)+'\n',encoding='utf8')
    # The linked executable and build recipe suffice to repeat the captures.
    # Keep this explicitly produced compiler intermediate compact when the run budget permits.
    from io import BytesIO
    from zipfile import ZipFile,ZIP_LZMA
    buf=BytesIO()
    with ZipFile(buf,'w',ZIP_LZMA) as z:
        z.write(object_file,object_file.name)
    with ZipFile(buf) as z:
        assert z.testzip() is None and sha256(z.read(object_file.name)).hexdigest()==rec['object']
    payload=buf.getvalue()
    reservation=check(W/'build',run=M,planned=len(payload)+50000)
    if reservation['allowed']:
        compressed=out/'compiler-object.zip'
        compressed.write_bytes(payload)
        assert object_file.resolve().parent==out and not object_file.stat().st_file_attributes&1024
        assert sha(object_file)==rec['object'] and sha(compressed)==sha256(payload).hexdigest()
        object_file.unlink()
    print({k:rec[k] for k in ('status','source','object','player')})


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(sha(source_check()))
    else:
        build()
