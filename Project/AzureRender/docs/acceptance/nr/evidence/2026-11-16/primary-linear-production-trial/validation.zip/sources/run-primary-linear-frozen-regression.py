"""Compare the linked renderer with both checked four-frame reference sets."""
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
from pathlib import Path
import runpy
import sys
import time
from zipfile import ZIP_DEFLATED,ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
out=M/'primary-linear-frozen-regression'
old=M/'projected-history-layer-frozen-regression'
E=W/'docs/acceptance/nr/evidence/2026-11-16'
native=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames')
read=lambda p:json.loads(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
len_footer=12
footer=b'\x00\x00\x00\x00IEND\xaeB\x60\x82'


def compare(a,b):
    d=abs(a[:,:,:3].astype(np.int16)-b[:,:,:3].astype(np.int16)).max(axis=2)
    return dict(differingPixels=int((d>0).sum()),overOne=int((d>1).sum()),peak=int(d.max()))


def image(p):
    a=cv2.imread(str(p),cv2.IMREAD_UNCHANGED)
    assert a.shape==(1440,2560,4),p
    return a


def process(path,scope):
    if not path.exists():
        return None
    try:
        data=path.read_bytes()
    except (FileNotFoundError,PermissionError):
        return None
    if len(data)<len_footer or data[-len_footer:]!=footer:
        return None
    assert path.resolve().parent==(out/'frames').resolve() and not path.stat().st_file_attributes&1024
    keep=old/'frames'/path.name
    gold=native/path.name
    a=cv2.imdecode(np.frombuffer(data,np.uint8),cv2.IMREAD_UNCHANGED)
    assert a.shape==(1440,2560,4)
    ref=image(keep)
    baseline=digest(keep)
    native_digest=digest(gold)
    assert baseline==scope['sha256'] and native_digest==scope['original']
    record=dict(frame=path.name,sha256=sha256(data).hexdigest(),reference=baseline,historical=native_digest,
                decoded=sha256(a.tobytes()).hexdigest(),sameDriver=compare(a,ref),historicalFrozen=compare(a,image(gold)))
    if record['sha256']!=baseline:
        patch=out/(path.stem+'-delta.zip')
        with ZipFile(patch,'w',ZIP_DEFLATED,compresslevel=6) as z:
            z.writestr('frame.bgra-xor',(a^ref).tobytes())
        with ZipFile(patch) as z:
            assert z.testzip() is None
            assert np.array_equal(ref^np.frombuffer(z.read('frame.bgra-xor'),np.uint8).reshape(a.shape),a)
        record['deltaArchive']=digest(patch)
    assert digest(path)==record['sha256']
    # Same captured bytes already exist, or the decoded image round-trips via the retained delta.
    try:
        path.unlink()
    except PermissionError:
        return None
    return record


def run():
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    budget=check(W/'build',run=M,planned=14_000_000)
    assert budget['allowed'],budget
    body=runpy.run_path(str(M/'character-six-view-inputs.py'),run_name='primary_frozen_capture')
    glyph=runpy.run_path(str(M/'run-immutable-scene-glyph-capture.py'),run_name='primary_frozen_shader_mount')
    invoke=body['helpers']['invoke']
    fixture=read(E/'projected-history-layer-frozen/qualification.json')
    build=read(M/'primary-linear-reflection-build/qualification.json')
    player=M/'projected-history-layer-release/AzurePlayerPrimaryLinearReflection.exe'
    assert build['player']==digest(player) and fixture['sameDriverExact']
    assert build['source']==digest(W/'src/scenes/CharacterSceneRenderer.cpp')
    cmd=read(old/'command.json')
    cmd[0]=str(player)
    for flag,path in (('--capture-dir',out/'frames'),('--runtime-report',out/'runtime.json')):
        cmd[cmd.index(flag)+1]=str(path)
    assert '--fixed-frame-step' in cmd and cmd[cmd.index('--capture-frames')+1]=='4'
    p=Path(cmd[cmd.index('--project')+1])
    p_before=digest(p)
    out.mkdir()
    plan={}
    for row,h in zip(fixture['frames'],fixture['retainedInputs']['originalFrozen'],strict=True):
        name=row['frame']
        assert row['sha256']==digest(old/'frames'/name) and h==digest(native/name)
        plan[name]=dict(**row,original=h)
    receipts={}
    with glyph['programs']() as (_,_,programs):
        with ThreadPoolExecutor(max_workers=1) as pool:
            future=pool.submit(invoke,'nvidia',cmd,out)
            while len(receipts)<4:
                for name,row in plan.items():
                    if name not in receipts:
                        r=process(out/'frames'/name,row)
                        if r:
                            receipts[name]=r
                            write(out/'streamed-frames.json',receipts)
                if future.done():
                    future.result()
                    if len(receipts)!=4:
                        assert all((out/'frames'/p).exists() for p in plan if p not in receipts)
                if len(receipts)<4:
                    time.sleep(.15)
            frames=future.result()
    assert digest(p)==p_before
    caps=read(frames/'gpu_capabilities.json')
    expected=read(old/'frames/gpu_capabilities.json')
    assert all(caps[k]==expected[k] for k in ('vendor_id','device_id','driver_version'))
    got=read(frames/'capture_manifest.json')
    a=read(old/'frames/capture_manifest.json')
    keys=('capturedFrames','width','height','qaCameraPosition','qaCameraTarget','cameraLens','screenReflectionProducer')
    assert all(got[k]==a[k] for k in keys)
    report=dict(status='measured-primary-linear-reflection-frozen',linkedPlayer=build['player'],scope=fixture['retainedInputs'],
                frames=receipts,sameDriverExact=all(r['sameDriver']['peak']==0 for r in receipts.values()),
                originalFrozenExact=all(r['historicalFrozen']['peak']==0 for r in receipts.values()),project=p_before,
                shaderPrograms=programs)
    write(out/'qualification.json',report)
    assert report['sameDriverExact'],[(n,v['sameDriver']) for n,v in receipts.items()]
    print([(n,v['sameDriver']['peak'],v['historicalFrozen']['peak']) for n,v in receipts.items()])


if __name__=='__main__':
    run()
