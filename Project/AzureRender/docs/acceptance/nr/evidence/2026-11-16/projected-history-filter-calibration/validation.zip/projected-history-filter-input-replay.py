"""Read the exact reflection filter descriptor mip chains and isolate model error."""
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import struct
import subprocess
import sys
import traceback

KEY='AZURE_NR_FILTER_INPUT_REPLAY'
root=Path(os.environ[KEY]).parents[1] if KEY in os.environ else Path(__file__).resolve().parent
out=root/'projected-history-filter-input-replay'
digest=lambda data:sha256(data).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
write=lambda p,d:Path(p).write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
labels={0:'depth',1:'footprint',2:'color',3:'colorPoint',6:'confidence'}
base_names={0:'currentDepth',1:'outputFootprint',2:'outputColor',3:'outputColor',6:'outputConfidence'}


def request():
    base=runpy.run_path(str(root/'preview-projected-history-filter.py'))
    capture=read(base['disk']/'request.json')['capture']
    assert Path(capture).parent.name=='capture-indexed'
    old=read(root/'projected-history-player-lineage/results.json')['filteredColorControl']
    assert old['event']==21729
    found={r['name']:r for r in base['P']['inputs']+base['P']['outputs']}
    return dict(capture=capture,event=old['event'],shader=old['shaderSha256'],parameters=old['parameters'],
         base={str(i):dict(sha256=found[n]['data']['sha256'],resource=found[n]['resource']) for i,n in base_names.items()},
         sampleSha256=old['sampleSha256'])


def worker(p):
    d=read(p); result=dict(status='unqualified',request=d)
    cap=ctl=None
    try:
        write(out/'progress.json',dict(stage='worker-started'))
        import renderdoc as rd
        import zlib
        cap=rd.OpenCaptureFile()
        assert cap.OpenFile(d['capture'],'',None)==rd.ResultCode.Succeeded
        write(out/'progress.json',dict(stage='opening-capture'))
        status,ctl=cap.OpenCapture(rd.ReplayOptions(),None)
        assert status==rd.ResultCode.Succeeded and ctl is not None
        write(out/'progress.json',dict(stage='capture-opened'))
        ctl.SetFrameEvent(d['event'],True)
        pipe=ctl.GetPipelineState();stage=rd.ShaderStage.Compute
        shader=pipe.GetShaderReflection(stage)
        assert digest(bytes(shader.rawBytes))==d['shader']
        cb=pipe.GetConstantBlock(stage,0,0).descriptor
        assert list(struct.unpack('<16f',bytes(ctl.GetBufferData(cb.resource,cb.byteOffset,64))))==sum(d['parameters'],[])
        bindings={shader.readOnlyResources[o.access.index].fixedBindNumber:o.descriptor
                 for o in pipe.GetReadOnlyResources(stage)}
        resources={r.resourceId:r for r in ctl.GetTextures()}
        fetched={}
        for i,name in labels.items():
            b=bindings[i]; tex=resources[b.resource]
            requested=1 if i in (1,3) else 7
            length=b.numMips
            key=(str(b.resource),b.firstMip,length)
            info=dict(resource=str(b.resource),firstMip=b.firstMip,mipCount=length,format=tex.format.Name(),
                      dimensions=[tex.width,tex.height],expectedLevel0=d['base'][str(i)])
            result.setdefault('inputs',{})[name]=info
            if key in fetched:
                info['sameViewAs']=fetched[key]
                continue
            fetched[key]=name
            assert b.firstMip==0 and length>=requested and tex.mips>=requested,info
            assert (tex.width,tex.height)==(1280,720),info
            info['mips']=[]
            for k in range(requested):
                w,h=tex.width>>k,tex.height>>k
                raw=bytes(ctl.GetTextureData(b.resource,rd.Subresource(k,0,0)))
                assert len(raw)==w*h*(1 if i==6 else 4),(name,k,info['format'],len(raw))
                sha=digest(raw)
                entry=dict(mip=k,width=w,height=h,sha256=sha)
                if k==0:
                    entry['matchesRetained']=sha==d['base'][str(i)]['sha256']
                if k>0 or not entry['matchesRetained']:
                    f=out/f'{name}-{k}.bin'
                    if f.exists():
                        assert digest(f.read_bytes())==sha
                    else:
                        f=out/f'{name}-{k}.zlib'
                        encoded=zlib.compress(raw,6)
                        assert zlib.decompress(encoded)==raw
                        f.write_bytes(encoded)
                    entry['file']=f.name
                info['mips'].append(entry)
            write(out/'checkpoint.json',result)
        result['status']='qualified-exact-filter-inputs'
    except BaseException:
        result['error']=traceback.format_exc()
    finally:
        write(out/'results.json',result)
        if ctl is not None:ctl.Shutdown()
        if cap is not None:cap.Shutdown()
    os._exit(0 if result['status'].startswith('qualified') else 1)


def launch():
    lease=read('D:/Projects/FYP-coordination/resources/current.json')
    assert lease['state']=='held' and lease['owner']=='01a1d0a9-829a-7c11-a7a8-017e743887d9' and Path(lease['output'])==root
    sys.path.insert(0,str(root.parents[2]/'tools'))
    from artifact_budget import check
    # Existing exact depth mips remain in place; other inputs compress before they are stored.
    budget=check(root.parents[1],run=root,planned=1_410_000)
    assert budget['allowed'],budget
    out.mkdir(exist_ok=True)
    p=out/'request.json'; write(p,request())
    startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
    with (out/'replay.log').open('wb') as log:
        child=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
            cwd=out,env=dict(os.environ,**{KEY:str(p)}),stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=200)
    r=read(out/'results.json')
    assert child.returncode==0 and r['request']==read(p) and r['status']=='qualified-exact-filter-inputs',r.get('error')
    print(r['status'],[(k,v['resource'],v['format'],v['mipCount']) for k,v in r['inputs'].items()])


def score(regional=False):
    import numpy as np
    import zlib
    f=runpy.run_path(str(root/'preview-projected-history-filter.py'))
    r=read(out/'results.json'); d=r['request']
    assert r['status']=='qualified-exact-filter-inputs' and d==request()
    C,shader,ds,levels,foot=f['model']()
    assert shader==d['shader'] and np.array_equal(C,d['parameters'])
    def observed(name,fmt):
        entry=r['inputs'][name]
        entry=r['inputs'][entry['sameViewAs']] if 'sameViewAs' in entry else entry
        result=[]
        for k in entry['mips']:
            if 'file' in k:
                raw=(out/k['file']).read_bytes()
                if k['file'].endswith('.zlib'):raw=zlib.decompress(raw)
                assert digest(raw)==k['sha256']
                a=np.frombuffer(raw,fmt)
                tail=(-1,) if name=='footprint' else ()
                result.append(a.reshape((k['height'],k['width'])+tail))
            else:
                assert k['matchesRetained'] and k['mip']==0
                result.append(None)
        return result
    color=observed('color','<u4'); point=observed('colorPoint','<u4')
    assert len(color)==7 and len(point) in (1,7)
    assert (color[0] is None and point[0] is None) or np.array_equal(color[0],point[0])
    conf=observed('confidence','u1')
    actual_depth=[a if a is not None else ds[i] for i,a in enumerate(observed('depth','<f4'))]
    actual_levels=[(levels[i][0] if c is None else f['s']['decode'](c).astype('f4'),
                   levels[i][1] if a is None else a.astype('f4')/255) for i,(c,a) in enumerate(zip(color,conf))]
    base_foot=foot
    found_foot=observed('footprint','<u2')[0]
    if found_foot is not None:
        foot=found_foot[...,1]
    raw=(root/'projected-history-player-lineage/filter-samples.bin').read_bytes()
    assert digest(raw)==d['sampleSha256']
    sample=np.frombuffer(raw,dtype=[('x','<u2'),('y','<u2'),('rgba','<f4',(4,))])
    x,y=sample['x'].astype('i4'),sample['y'].astype('i4')
    sharp=foot[y,x].astype('f4')/65535*C[0][2]<C[0][3]
    results={}
    repyramid=f['pyramid'](*actual_levels[0],actual_depth,C)
    trunc_pyramid=f['pyramid'](*actual_levels[0],actual_depth,C,pack=np.floor)
    for label,dep,col,selected,linear in [('modeled',ds,levels,base_foot,False),('captured-footprint',ds,levels,foot,False),
                          ('captured-depth',actual_depth,levels,foot,False),('captured-signal',ds,actual_levels,foot,False),
                          ('captured-all',actual_depth,actual_levels,foot,False),
                          ('captured-all-linear-confidence',actual_depth,actual_levels,foot,True),
                          ('captured-mip0-rebuilt-pyramid-linear-confidence',actual_depth,repyramid,foot,True),
                          ('captured-mip0-truncated-pyramid-linear-confidence',actual_depth,trunc_pyramid,foot,True)]:
        error=np.abs(f['consume'](x,y,col,dep,selected,C,linear_confidence=linear)-sample['rgba'])
        rgb=error[:,:3].max(axis=-1);a=error[:,3]
        q=lambda v:np.percentile(v,[50,90,95,99,100]).tolist()
        results[label]=dict(rgb=q(rgb),confidence=q(a),sharpPeak=float(rgb[sharp].max()),
           calibrated=bool(np.percentile(rgb,95)<.016 and np.percentile(a,99)<.012))
    prepass=[dict(depth=float(np.abs(a-b).max()),color=float(np.abs(c-v).max()),confidence=float(np.abs(s-t).max()))
             for a,b,(c,s),(v,t) in zip(ds,actual_depth,levels,actual_levels)]
    mip_stats={}
    for name,pyramid in [('rounded',repyramid),('truncated',trunc_pyramid)]:
        mip_stats[name]=[dict(equal=float((q[0]==a[0]).mean()),mean=float((q[0]-a[0]).mean()),
            maximum=float(abs(q[0]-a[0]).max())) for q,a in zip(pyramid,actual_levels)]
    diagnosis=dict(status='measured-filter-input-ablation',event=d['event'],shader=shader,results=results,
        rebuiltMipStatistics=mip_stats,
        actualMipDifferences=prepass,changedFootprints=int((foot!=base_foot).sum()),
        changedSampleFootprints=int((foot[y,x]!=base_foot[y,x]).sum()),samples=len(sample),sharp=int(sharp.sum()))
    write(out/'comparison.json',diagnosis)
    print('p95 RGB / p99 confidence:',[(n,v['rgb'][2],v['confidence'][3]) for n,v in results.items()])
    if regional:
        assert results['captured-mip0-truncated-pyramid-linear-confidence']['calibrated']
        ranges={name:f['source_test'](C,actual_depth,trunc_pyramid,foot,coverage=True,oracle=kind,
                                      pack=np.floor,linear_confidence=True)
                for name,kind in [('glyph',None),('glyph-and-box','known-draws'),('registered','registered-source')]}
        report=dict(status='calibrated-source-coverage-prediction',comparisonSha256=digest((out/'comparison.json').read_bytes()),
                    jointSceneActualCapture='pending',regions=ranges)
        write(out/'regional.json',report)
        print([(k,[(i,v[i]['conditionalSsimCeiling'],v[i]['idealDirectReferenceCopySsim']) for i in ('centerFloor','cyanRing')])
               for k,v in ranges.items()])


if KEY in os.environ:
    worker(os.environ[KEY])
elif __name__=='__main__':
    action,=sys.argv[1:]
    {'run':launch,'preflight':lambda:print(json.dumps(request())),'score':score,'score-regional':lambda:score(True)}[action]()
