"""Replay the recorded reflection filter using its captures, then hold it fixed for a source change."""
from hashlib import sha256
from pathlib import Path
import json
import runpy
import sys

import numpy as np

root=Path(__file__).resolve().parent
glyph=runpy.run_path(str(root/'preview-projected-history-glyph-composition.py'))
s,b=glyph['s'],glyph['b']
disk=s['source']['reader']['current'].parent
read=lambda p:json.loads(p.read_bytes())
hash_bytes=lambda data:sha256(data).hexdigest()
P=s['source']['v']
kernel=np.array([1,3,3,1],dtype=np.float32)
width,height=1280,720


def required_input(name, kind, channels=0):
    match,=[a for a in P['inputs']+P['outputs'] if a['name']==name]
    assert (match['width'],match['height'])==(width,height)
    p=match['data']
    return s['check_snapshot'](disk/p['file'],p['sha256'],kind,(height,width,channels) if channels else (height,width))


def packed_round(rgb, reduction=np.rint):
    mantissa=np.array([6,6,5],dtype=np.int32)
    _, exp=np.frexp(rgb)
    step=np.exp2(np.maximum(exp-1,-14)-mantissa).astype('f4')
    return reduction(rgb/step)*step


def depth_levels(first,n):
    d=[first]
    for k in range(1,n):
        first=d[k-1];h,w=first.shape;v,u=np.mgrid[:h//2,:w//2]*2
        d.append(np.maximum.reduce([first[np.minimum(v+i,h-1),np.minimum(u+j,w-1)]
            for i in range(2+h%2) for j in range(2+w%2)]))
    return d


def radius_uv(out_w,out_h):
    yy,xx=np.mgrid[:out_h,:out_w]
    return (xx+.5)/out_w,(yy+.5)/out_h


def nearest(values,u,v):
    h,w=values.shape[:2]
    p=np.clip((u*w).astype(np.int32),0,w-1)
    q=np.clip((v*h).astype(np.int32),0,h-1)
    return values[q,p]


def linear(values,u,v):
    h,w=values.shape[:2]
    x=(u*w-.5).clip(0,w-1);y=(v*h-.5).clip(0,h-1)
    p=x.astype(np.int32);q=y.astype(np.int32)
    fx=(x-p)[...,None].astype('f4');fy=(y-q)[...,None].astype('f4')
    r=np.minimum(p+1,w-1);d=np.minimum(q+1,h-1)
    return (1-fy)*((1-fx)*values[q,p]+fx*values[q,r])+fy*((1-fx)*values[d,p]+fx*values[d,r])


def decode(d, rows):
    a,b,reciprocal,_=rows[1]
    z=(np.float64(a)*d.astype('f8')+b).astype('f4')
    return 1/np.maximum(z,1e-8) if reciprocal>.5 else z


def pyramid(color,conf,depth,C,pack=np.rint):
    levels=[(color,conf)]
    for k in range(1,len(depth)):
        h,w=depth[k].shape
        H,W=depth[k-1].shape
        v,u=np.mgrid[:h,:w]*2
        ref,fi=levels[-1]
        cu,cv=radius_uv(w,h)
        center=decode(nearest(depth[k],cu,cv),C)
        sig=np.zeros((h,w,3),dtype='f4')
        mask=np.zeros((h,w),dtype='f4')
        total=np.zeros((h,w),dtype='f4')
        for i in range(4):
            for j in range(4):
                x=u+i-1;y=v+j-1
                good=(0<=x)&(x<W)&(0<=y)&(y<H)
                dd=decode(nearest(depth[k-1],(x+.5)/W,(y+.5)/H),C)
                wgt=(kernel[i]*kernel[j]/64*np.exp(-C[1][3]*np.abs(dd-center))).astype('f4')
                xc=x.clip(0,W-1);yc=y.clip(0,H-1)
                total+=wgt
                sig+=ref[yc,xc]*(wgt*good)[...,None]
                mask+=fi[yc,xc]*(wgt*good)
        den=np.maximum(total,C[2][0])
        levels.append((packed_round(sig/den[...,None],pack),np.rint(mask*255/den)/255))
    return levels


def filter_level(x,y,depth,color,lod,center,C):
    total=np.zeros(len(x),dtype='f4');value=np.zeros((len(x),3),dtype='f4')
    w,h=width,height
    scale=2**lod
    for i in range(4):
        for j in range(4):
            u=(x+(i-1.5)*scale)/w;v=(y+(j-1.5)*scale)/h
            d=decode(nearest(depth,u,v),C)
            spatial=kernel[i]*kernel[j]/64
            weight=(np.exp(-C[1][3]*np.abs(d-center))*spatial).astype('f4')
            value+=linear(color,u,v)*weight[:,None]
            total+=weight
    return value/np.maximum(total[:,None],C[2][0])


def consume(x,y,p,ds,foot,C,linear_confidence=False):
    uv=(x+.5)/width,(y+.5)/height
    lc=foot[y,x].astype('f4')/65535*C[0][2]
    base=decode(ds[0][y,x],C)
    lower=np.floor(lc).astype('i4')
    colors=np.zeros((len(x),3),dtype='f4')
    conf=np.zeros(len(x),dtype='f4')
    for k,(cp,qp) in enumerate(p):
        pick=lower==k
        if not pick.any():continue
        a,b=x[pick],y[pick]
        if linear_confidence:
            value=linear(qp[...,None],uv[0][pick],uv[1][pick])[:,0]
            conf[pick]=np.rint(value*255)/255 if C[3][2]>.5 else value
        else:
            conf[pick]=nearest(qp,uv[0][pick],uv[1][pick])
        sharp=pick&(lc<C[0][3]); colors[sharp]=p[0][0][y[sharp],x[sharp]]
        if sharp.sum()==pick.sum():continue
        soft=pick&~sharp; h=min(k+1,len(p)-1)
        low=filter_level(x[soft],y[soft],ds[k],cp,k,base[soft],C)
        high=low if h==k else filter_level(x[soft],y[soft],ds[h],p[h][0],h,base[soft],C)
        colors[soft]=low+(lc[soft]-k)[:,None]*(high-low)
    assert np.isfinite(colors).all() and (colors>=0).all() and (colors<1).all()
    return np.column_stack((colors/(1-colors.max(axis=-1,keepdims=True)),conf))


def captured_filter():
    addr=s['source']['reader']['current'].parents[1]/'filter-parameters'
    old=read(addr/'summary.json'); q=read(addr/'request.json')
    assert old['status']=='verified' and old['events'][0]['event']==21729
    args=np.asarray(old['events'][0]['rows'],dtype='f4')
    assert np.array_equal(args[3],(1,1,1,0))
    exp=[(width,height),(6,.25),(.01,1),(1,.01)]
    assert np.allclose(args[0,2:],exp[1]) and np.allclose(args[2,:2],exp[2]) and np.allclose(args[1,2:],exp[3])
    return args,q['shaderSha256']


def model():
    C,filter_shader=captured_filter()
    raw=required_input('outputColor','<u4')
    color=s['decode'](raw).astype('f4')
    ds=depth_levels(required_input('currentDepth','<f4'),int(C[0][2])+1)
    conf=required_input('outputConfidence','u1').astype('f4')/255
    foot=required_input('outputFootprint','<u2',2)[...,1]
    assert np.array_equal(packed_round(color),color)
    levels=pyramid(color,conf,ds,C)
    return C,filter_shader,ds,levels,foot


def source_test(C,ds,p,foot,coverage=False,oracle=None,artifacts=None,pack=np.rint,linear_confidence=False):
    # Hold footprint, depth, and confidence fixed. Only replace the qualified
    # prior color stage, before packing and only where it is attributable.
    m=glyph['m'];s2=glyph['rgb']
    depths,depth_ids,coord,screen,conf,trace,col,prior=s2['load']()
    route='player'
    seg=screen[route];nav=seg.copy();nav[...,1]=65535-nav[...,1]
    native,n_ok,_=s['world_from_history'](nav,depths['native'],s['N'],True)
    player,p_ok,_=s['world_from_history'](seg,depths['player'],s['V'],False)
    xy=m['local']['inverse_indices'](seg)
    masks,ids=m['retained_masks']()
    a,c=col['native'][route],col['player'][route]
    mask=n_ok&p_ok&(np.linalg.norm(native-player,axis=-1)<=.02)&(np.minimum(conf['native'],conf[route])>0)
    mask &= s['coherently_sampled'](s['compressed_rgb'](c),trace[route])
    for w,h in ((1280,720),(2560,1440)):
        mask &= s['stable_indices'](coord[route][...,0],w)&s['stable_indices'](coord[route][...,1],h)
    if oracle is not None:
        assert coverage and oracle in ('known-draws','registered-source')
        events=(10480,6587,6600,6613,6626,6652)
        if oracle=='known-draws':
            mask &= np.logical_or.reduce([masks[k][xy[...,1],xy[...,0]] for k in events])
        comp=s['compressed_rgb'](a)
        # Remove encoder-level diagnostic noise; retain either sign of known same-address radiance differences.
        mask &= np.abs(comp-s['compressed_rgb'](c)).max(axis=-1)>.02
        x,y,X,Y=b['CROP'];signal=p[0][0].copy();view=signal[y:Y,x:X]
        view[mask]=packed_round(comp[mask].astype('f4'),pack)
        changed=(signal!=p[0][0]).any(axis=-1)
        assert changed.sum()>0 and changed.sum()<=mask.sum()
        result=dict(oracle=oracle,modifiedPackedHits=int(changed.sum()),depthSha256=depth_ids,
            thresholdMaxCompressedRgb=.02,playerEarlierColor=prior['fullSha256'],
            drawMaskSha256={str(k):ids[str(k)]['sha256'] for k in events} if oracle=='known-draws' else None)
        return local_display_bound(C,ds,p,pyramid(signal,p[0][1],ds,C,pack=pack),foot,result,artifacts,linear_confidence)
    mask &= masks[10480][xy[...,1],xy[...,0]]
    geo,ind,cam,profile,tex,history,prov=glyph['inputs']()
    raw=geo[:,:4].astype('f8')@cam[24:28].astype('f8')
    old=geo.copy();old[:,:4]=raw@np.linalg.inv(s['N'])
    oldcam=cam.copy();oldcam[24:28]=s['N']
    scene=dict(prims=list(glyph['precompute'](old,ind)),profile=profile,images=tex,camera=oldcam)
    points=xy[mask]
    pt=np.column_stack((points+.5,np.ones(len(points))))
    current=list(glyph['precompute'](geo,ind))
    labels=lambda prim:np.stack([np.min(pt@v[1],axis=-1)>.00001 for v in prim],axis=-1)
    orig=labels(current); eligible=labels(scene['prims'])
    unique=(eligible.sum(axis=-1)==1)&(orig.sum(axis=-1)==1)
    owners=eligible.argmax(axis=-1)
    layer=np.zeros((len(points),4))
    for j in range(len(ind)):
        owned=unique&(owners==j)
        if owned.any():layer[owned]=glyph['shade'](scene,points[owned],j)
    pr=c[mask]
    put=lambda rgb:s['compressed_rgb'](rgb).astype('f4')
    value=packed_round(put(layer[:,:3]+pr*(1-layer[:,3:4])),pack)
    x,y,X,Y=b['CROP']
    base=p[0][0]
    signal=base.copy()
    update=(layer[:,3]>0)&unique
    indices=np.flatnonzero(mask)[update]
    view=signal[y:Y,x:X]
    ty,tx=np.unravel_index(indices,mask.shape)
    view[ty,tx]=value[update]
    changed=(base!=signal).any(axis=-1)
    assert changed.sum()>0 and changed.sum()<=update.sum() and not changed[:y].any() and not changed[Y:].any()
    pruned=pyramid(signal,p[0][1],ds,C,pack=pack)
    result=dict(status='bounded-filter-response-source-only',modifiedPackedHits=int(changed.sum()),
        sourceMaskSha256=ids['10480']['sha256'],depthSha256=depth_ids,playerEarlierColor=prior['fullSha256'],
        scope='Only actual Player UV hits with depth registration and unique glyph triangle in both camera states. Direct appearance, other blend geometry, and compositing into the frame are outside this control.')
    if coverage:
        return local_display_bound(C,ds,p,pruned,foot,result,artifacts,linear_confidence)
    for name,region in b['REGIONS'].items():
        u,v,U,V=region
        assert X<=width and Y<=height and U<=width and V<=height
        v0,u0=np.mgrid[v:V,u:U]
        before=consume(u0.ravel(),v0.ravel(),p,ds,foot,C,linear_confidence)
        after=consume(u0.ravel(),v0.ravel(),pruned,ds,foot,C,linear_confidence)
        assert np.array_equal(before[:,3],after[:,3])
        d=(s['compressed_rgb'](after)-s['compressed_rgb'](before))@s['weight']
        k=(u0.ravel(),v0.ravel())
        result[name]=dict(total=len(d),sourceHits=int(changed[k[1],k[0]].sum()),
            filteredChanged=int((np.abs(d)>0).sum()),filteredAffectedAtPoint001=int((np.abs(d)>.001).sum()),
            filteredConfidenceWeightedMeanAbsoluteLuma=float(np.abs(d)@before[:,3]/max(before[:,3].sum(),.001)),
            filteredConfidenceWeightedMeanSignedLuma=float(d@before[:,3]/max(before[:,3].sum(),.001)),
            maximumFilteredCompressedLumaIncrease=float(np.max(d)))
    return result


def local_display_bound(C,ds,p,pruned,foot,result,artifacts=None,linear_confidence=False):
    import cv2
    phase=runpy.run_path(str(root/'projected-reflection-32-step-candidate.py'),run_name='coverage_only')
    stage=phase['inputs_phase']
    capture=Path(read(disk/'request.json')['capture'])
    assert capture.name=='capture_frame1.rdc' and capture.parent.name=='capture-indexed'
    old=capture.parent/'frames/frame_000001.png'
    baseline=stage['img'](old)
    original=stage['img'](stage['replay'])
    assert baseline.shape==original.shape==(height*2,width*2,3)
    result['status']='conditional-local-source-ssim-ceiling'
    result['scope']=('Modeled fixed input/filter; perfect SSIM permitted wherever the four-tap full-resolution sampler can '
        'see a changed color and nonzero confidence. Downstream spread (e.g. bloom) and extra source draws are outside this ceiling.')
    result['captureFrame']=old.name
    result['baselineSha256']=stage['sha'](old)
    result['referenceSha256']=stage['sha'](stage['replay'])
    luma, cs = stage['luma'],stage['contrast_structure']
    cv2.setNumThreads(1)
    for name in ('centerFloor','cyanRing'):
        x,y,X,Y=phase['regions'][name]
        sx=np.floor((np.arange(x,X)+.5)*.5-.5).astype('i4')
        sy=np.floor((np.arange(y,Y)+.5)*.5-.5).astype('i4')
        assert sx.min()>=0 and sy.min()>=0 and sx.max()+1<width and sy.max()+1<height
        v,u=np.mgrid[sy[0]:sy[-1]+2,sx[0]:sx[-1]+2]
        before=consume(u.ravel(),v.ravel(),p,ds,foot,C,linear_confidence)
        after=consume(u.ravel(),v.ravel(),pruned,ds,foot,C,linear_confidence)
        assert np.array_equal(before[:,3],after[:,3])
        hc=np.any(before[:,:3]!=after[:,:3],axis=-1).reshape(u.shape)
        ha=(before[:,3]>0).reshape(u.shape)
        bx,by=sx-sx[0],sy-sy[0]
        taps=lambda bit: np.logical_or.reduce([bit[np.ix_(by+j,bx+i)] for i in (0,1) for j in (0,1)])
        mask=taps(hc)&taps(ha)
        if artifacts is not None:
            for tag,value in (('baseline',baseline),('reference',original)):
                v=value[y:Y,x:X].tobytes()
                assert artifacts.setdefault(f'{name}/{tag}.rgb8',v)==v
            key=f"{name}/{result.get('oracle','glyph')}.mask"
            assert key not in artifacts
            artifacts[key]=np.packbits(mask,bitorder='little').tobytes()
        inside=cv2.dilate(mask.astype('u1'),np.ones((11,11),'u1'),borderType=cv2.BORDER_REFLECT_101)>0
        a,b=(luma(z[y:Y,x:X]) for z in (baseline,original)); blur=lambda z:cv2.GaussianBlur(z,(11,11),1.5)
        aa,bb=blur(a),blur(b)
        ssim=(2*aa*bb+.01**2)/(aa**2+bb**2+.01**2)*cs(a,b,aa,bb,blur)
        measured=float(np.mean(ssim,dtype='f8'))
        assert abs(measured-phase['score'](baseline[y:Y,x:X],original[y:Y,x:X])['ssim'])<1e-6
        ceiling=min(1.,measured+(1-ssim[inside]).sum(dtype='f8')/ssim.size)
        ideal=baseline[y:Y,x:X].copy();ideal[mask]=original[y:Y,x:X][mask]
        oracle=phase['score'](ideal,original[y:Y,x:X])['ssim']
        assert oracle<=ceiling+1e-6
        result[name]=dict(fullBounds=[x,y,X,Y],pixels=ssim.size,halfChanged=int(hc.sum()),
            eligibleFullPixels=int(mask.sum()),affectedSsimWindows=int(inside.sum()),baselineSsim=measured,
            idealDirectReferenceCopySsim=oracle,conditionalSsimCeiling=float(ceiling))
    return result


def run():
    C,shader,ds,p,foot=model()
    d=root/'projected-history-player-lineage'
    record=read(d/'results.json')['filteredColorControl']
    assert record['event']==21729 and record['shaderSha256']==shader and np.array_equal(C,record['parameters'])
    raw=(d/'filter-samples.bin').read_bytes()
    assert hash_bytes(raw)==record['sampleSha256']
    t=np.frombuffer(raw,dtype=[('x','<u2'),('y','<u2'),('rgba','<f4',(4,))])
    assert len(t)==record['samples']
    predicted=consume(t['x'].astype('i4'),t['y'].astype('i4'),p,ds,foot,C)
    original=t['rgba']
    assert original.shape==predicted.shape
    alpha=np.abs(original[:,3]-predicted[:,3])
    rgb=np.abs(original[:,:3]-predicted[:,:3]).max(axis=-1)
    sharp=foot[t['y'],t['x']].astype('f4')/65535*C[0][2]<C[0][3]
    obs=np.max(original[:,:3],axis=-1)
    relative=rgb/np.maximum(obs,.02)
    receipt=dict(status='diagnostic-filter-baseline',filterShader=shader,captured=record,num=int(len(t)),
        sharp=int(sharp.sum()),sharpPeak=float(rgb[sharp].max()),
        absRgbQuantiles=np.percentile(rgb,[50,90,95,99,100]).tolist(),
        relativeRgbQuantiles=np.percentile(relative,[50,90,95,99,100]).tolist(),
        absoluteConfidenceError=np.percentile(alpha,[50,90,95,99,100]).tolist())
    receipt['calibratedForSourceDiagnostic']=bool(np.percentile(rgb,95)<.016 and np.percentile(alpha,99)<.012)
    if receipt['calibratedForSourceDiagnostic']:
        receipt['sourceTest']=source_test(C,ds,p,foot)
    (s['floor']/'history-source-filter-baseline.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(receipt)


if __name__=='__main__':
    if sys.argv[1:] in (['preflight-coverage'],['preflight-coverage-oracles']):
        C,shader,ds,p,foot=model()
        if sys.argv[1:]==['preflight-coverage']:
            report=source_test(C,ds,p,foot,coverage=True)
            name='history-source-local-ssim-ceiling-preview.json'
        else:
            report={'controls':{what:source_test(C,ds,p,foot,coverage=True,oracle=what)
                                for what in ('known-draws','registered-source')}}
            name='history-source-oracle-ssim-ceiling-preview.json'
        report.update(filterShader=shader,gpuFilterCalibration='pending')
        (s['floor']/name).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
        print(report)
    elif sys.argv[1:] in (['preflight'],['preflight-source']):
        C,shader,ds,p,foot=model()
        x=np.arange(3,width,17);y=np.arange(7,height,11);x,y=np.meshgrid(x,y)
        result=consume(x.ravel(),y.ravel(),p,ds,foot,C)
        assert np.isfinite(result).all() and result.shape==(len(x.ravel()),4) and (0<result[:,3]).any()
        print('Retained inputs verified; simulated',len(result),'pixels; replay control pending.',shader)
        if sys.argv[1:]==['preflight-source']:
            print(source_test(C,ds,p,foot))
    else:
        assert sys.argv[1:]==['score']
        run()
