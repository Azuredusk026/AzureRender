"""Bound possible native source texels from exact packed trace colors and a real debugger witness."""
from hashlib import sha256
import json
from pathlib import Path
import runpy
import struct
import numpy as np

run=Path(__file__).resolve().parent
co=runpy.run_path(str(run/'projected-history-coordinates.py'),run_name='history')
s=runpy.run_path(str(run/'score-projected-history-source.py'))
read=lambda p:json.loads(p.read_bytes()); sha=lambda x:sha256(x).hexdigest()
f=Path(s['reader']['native_fixture'](s['reader']['request']('native'),None)['replaySource']['manifest'])
manifest=read(f)


def payload(role, side, kind, shape):
    row=next(x for x in manifest['textures' if side is None else 'outputs'] if x['role']==role)
    if side is not None: row=row[side]
    data=(f.parent/row['file']).read_bytes()
    assert sha(data)==row['sha256'] and len(data)==row['bytes']
    return np.frombuffer(data, dtype=kind).reshape(shape)


def encode_channels(rgb, nearest=False):
    masks=(6,6,5)
    assert rgb.dtype==np.float32 and np.isfinite(rgb).all()
    result=np.zeros(rgb.shape[:-1],dtype='uint32')
    for i,(mantissa,shift) in enumerate(zip(masks,(0,11,22))):
        values=np.maximum(rgb[...,i],np.float32(0))
        fraction, exponent=np.frexp(values)
        normal=exponent>=-13
        steps=np.where(normal,np.ldexp(fraction, mantissa+1),np.ldexp(values,14+mantissa))
        scaled=(np.rint(steps) if nearest else steps).astype('uint32')
        codes=scaled+(np.maximum(exponent+13,0).astype('uint32')<<mantissa)
        assert (codes < (1<<(mantissa+5))).all()
        result|=codes<<shift
    return result


source=payload('previousColor',None,'<f2',(1440,2560,4))[...,:3].astype('float32')
packed=payload('color','reference','<u4',(720,1280))
confidence=payload('confidence','reference','u1',(720,1280))
initial=payload('color','initial','<u4',(720,1280))
trace=co['native']/'ray-debug.json'
rs={};labels={}
for row in read(trace)['traces']['original']:
    rs.update(row['changes']);i=row['nextInstruction']
    if i in (320,321,326): labels[i]=rs.copy()
flt=lambda v:struct.unpack('<4f',struct.pack('<4I',*v))
px,py=labels[320]['r0'][:2];u,v=flt(labels[320]['r2'])[:2]
hx,hy=int(u*2560),int(v*1440)
sample=source[hy,hx]; assert np.array_equal(sample,flt(labels[321]['r1'])[1:])
compress=lambda rgb: rgb*(np.float32(1)/(np.float32(1)+rgb.max(axis=-1,keepdims=True)))
c=compress(source)
assert np.array_equal(c[hy,hx],flt(labels[326]['r2'])[:3])
code=packed[py,px]; assert code==encode_channels(c[hy,hx])!=encode_channels(c[hy,hx],nearest=True)
native=encode_channels(c)
index, first, counts=np.unique(native,return_index=True,return_counts=True)
rects=read(s['root']/'docs/acceptance/nr/evidence/2026-11-16/joint-scene-native-floor/results.json')['rectangles']
report=dict(status='qualified-one-debugger-witness-color-support',sourceManifest=sha(f.read_bytes()),
    debuggerWitness=dict(attachmentPixel=[px,py],previousUv=[u,v],sourceTexel=[hx,hy],packed=int(code),
        priorLinear=sample.tolist(), priorCompressed=c[hy,hx].tolist(),debuggerReportSha256=sha(trace.read_bytes())),
    scope='Each supported output color is compatible with one or more prior texels under this bit encoding. This is not coordinate readback or a spatial correspondence estimate.',
    regions={})
for name,box in rects.items():
    half=[x//2 for x in box]
    mask=s['cut'](confidence[::-1],half)>0
    expected=s['cut'](packed[::-1],half)[mask]
    j=np.searchsorted(index,expected)
    j=np.minimum(j,len(index)-1)
    hits=np.where(index[j]==expected,counts[j],0)
    valid=hits>0
    written=(s['cut'](packed[::-1],half)!=s['cut'](initial[::-1],half))[mask]
    unique_written=(hits==1)&written
    storage_y,full_x=np.divmod(first[j[unique_written]],2560)
    display_y=1439-storage_y
    endpoints=[]
    for level in range(0,1440,240):
        in_band=(display_y>=level)&(display_y<level+240)
        endpoints.append(dict(sourceRows=[level,level+240],count=int(in_band.sum())))
    row=dict(total=int(mask.sum()), compatible=int(valid.sum()), singleTexel=int((hits==1).sum()),
             sourceMultiplicity=np.percentile(hits[valid],(10,50,90)).tolist() if valid.any() else None)
    row.update(changedTraceWords=int(written.sum()),
               compatibleChangedWords=int((valid&written).sum()),
               uniqueChangedWords=int(unique_written.sum()),
               uniqueSourceRows=endpoints)
    report['regions'][name]=row
p=run/'projected-history-native-color-support.json'
p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
