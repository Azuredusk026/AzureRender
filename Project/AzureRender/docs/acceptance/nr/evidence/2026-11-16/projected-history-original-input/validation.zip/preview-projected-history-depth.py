"""Compare the two fingerprinted previous-depth inputs before reading radiance."""
from hashlib import sha256
import json
from pathlib import Path
import runpy
import numpy as np

run = Path(__file__).resolve().parent
sc = runpy.run_path(str(run/'score-projected-history-source.py'))
rd = sc['reader']
receipt_path = rd['root'].parents[1]/'docs/acceptance/nr/evidence/2026-10-31/ray-vulkan-reference/summary.json'
receipt = sc['read'](receipt_path)
fixture = receipt['fixture']
folder = rd['root'].parents[1]/Path(receipt['export']['parent']['file']).parent
assert fixture == sc['read'](folder/'manifest.json') and fixture['validation']['sampledTexturesUnchanged']
assert fixture['event'] == 8702 and fixture['originalShaderSha256'] == rd['request']('native')['shader']
nd, = (t for t in fixture['textures'] if t['role'] == 'previousDepth')
pd, = (t for t in sc['v']['inputs'] if t['name'] == 'previousDepth')
for rec,tag in ((nd,'native'),(pd,'player')):
    expected = rd['request'](tag)['inputs'][1]
    assert (rec['format'], rec['width'], rec['height']) == ('R32_FLOAT', 1280, 720)
    assert (rec['source'] if tag == 'native' else rec)['resource'] == expected['resource']
native = (folder/nd['file']).read_bytes()
assert len(native) == nd['bytes'] and sha256(native).hexdigest() == nd['sha256']
native = np.frombuffer(native[:nd['levels'][0]['bytes']],dtype='<f4').reshape(720,1280)[::-1]
player = sc['unpack'](rd['current'].parent/pd['data']['file'],pd['data']['sha256'],'<f4',(720,1280))
plan = sc['read'](sc['root']/'docs/acceptance/nr/evidence/2026-11-16/joint-scene-native-floor/results.json')
rectangles = {name:tuple(i//2 for i in box) for name,box in plan['rectangles'].items()}
report = dict(source='qualified-actual-prior-depth-attachments', registrations=sc['registration'](),
              native=dict(event=8702,sha256=nd['sha256']), player=dict(event=21668,sha256=pd['data']['sha256']),regions={})
for label,box in rectangles.items():
    n,p = (sc['cut'](t,box) for t in (native,player))
    valid = np.isfinite(n)&np.isfinite(p)&(n>0)&(p>0)&(n<=1)&(p<=1)
    with np.errstate(divide='ignore',invalid='ignore'):
        world_n = sc['reconstruct'](n,box,sc['nmat'])*sc['flip']
        world_p = sc['reconstruct'](p,box,sc['vmat'])
        d = np.linalg.norm(world_n-world_p,axis=-1)
    valid &= np.isfinite(d)
    row = dict(halfRectangle=box, valid=int(valid.sum()), total=n.size,
               matched={f'{limit:.2f}':int((valid&(d<=limit)).sum()) for limit in (.02,.05,.10)},
               worldDifferenceMeters=np.percentile(d[valid],(10,50,90,95,99)).tolist())
    report['regions'][label]=row
p = run/'projected-history-depth-preview.json'
p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
