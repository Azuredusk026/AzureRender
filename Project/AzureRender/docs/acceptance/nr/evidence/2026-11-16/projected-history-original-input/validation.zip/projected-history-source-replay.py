"""Read the actual prior color and depth bound to the same-camera ray passes."""
from array import array
from hashlib import sha256
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import traceback

key = 'AZURE_NR_PROJECTED_SOURCE_REQUEST'
run = Path(os.environ[key]).parents[2] if key in os.environ else Path(__file__).resolve().parent
root = Path('D:/Projects/FYP/Project/AzureRender/build/runs')
out = run / 'projected-history-source-replay'
old = root / '20261029-052336-native-hierarchical-reflection-52b603/event-8702.json'
current = root / '20261031-122504-projected-footprint-quality-5daf40/capture-inputs-v2/summary.json'
read = lambda p: json.loads(Path(p).read_bytes())


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def request(device):
    if device == 'native':
        source = read(old)
        capture = root / '20261022-201845-endfield-capture-954719/Endfield-games-child_frame3534.rdc'
        inputs = {row['shader_binding_index']: row for row in source['inputs']}
        assert source['sha256'] == '9874977ebc47e87ed0a006b7bebd51f525126c4f584bc4a6abc95282ba291faa'
        color, depth = inputs[1], inputs[2]
        assert (color['resource'], depth['resource']) == ('ResourceId::14664', 'ResourceId::14677')
        event, shader, api = 8702, source['sha256'], 'D3D11'
        flip, bindings = True, (1, 2)
    else:
        assert device == 'player'
        source = read(current)
        capture = Path(read(current.with_name('request.json'))['capture'])
        inputs = {row['name']: row for row in source['inputs']}
        color, depth = inputs['previousColor'], inputs['previousDepth']
        assert (color['resource'], depth['resource']) == ('ResourceId::9289', 'ResourceId::9332')
        event, shader, api = 21668, 'f5ec047bbab474b8bc0ab75bee6ffb2a77c7ffb3f36737356c964019442f1aa8', 'Vulkan'
        assert any(row['event'] == event and row['shaderSha256'] == shader for row in source['candidates'])
        flip, bindings = False, (color['fixedBindNumber'], depth['fixedBindNumber'])
    assert capture.is_file()
    assert (color['format'], depth['format']) == ('R16G16B16A16_FLOAT', 'R32_FLOAT')
    return dict(device=device, event=event, shader=shader, api=api, flip=flip, capture=str(capture),
                dataSource=sha256((old if flip else current).read_bytes()).hexdigest(),
                inputs=[dict(name='prior-color', bind=bindings[0], resource=color['resource'], format=color['format']),
                        dict(name='prior-depth', bind=bindings[1], resource=depth['resource'], format=depth['format'])])


def sample_color(raw, width, height, flip):
    pixels = memoryview(raw).cast('Q')
    assert width%2 == height%2 == 0 and len(pixels) == width*height
    def row(y):
        storage_y = height-1-y if flip else y
        p = pixels[storage_y*width:(storage_y+1)*width].tolist()
        return array('Q', p[1::2]).tobytes()
    return b''.join(row(y) for y in range(1, height, 2))


def preflight():
    raw = array('Q', range(16)).tobytes()
    for reverse, indices in ((False, [5,7,13,15]), (True, [9,11,1,3])):
        assert list(memoryview(sample_color(raw,4,4,reverse)).cast('Q')) == indices
    proof=struct.pack('<6H',0,0,16384,16384,65535,65535)
    assert list(memoryview(at_history_uv(raw,4,4,False,False,proof)).cast('Q'))==[0,5,15]
    assert list(memoryview(at_history_uv(raw,4,4,False,True,proof)).cast('Q'))==[12,9,3]
    return [request(tag) for tag in ('native','player')]


def at_history_uv(raw,width,height,source_flip,target_flip,coords):
    image=memoryview(raw).cast('Q')
    assert len(image)==width*height
    reverse=source_flip!=target_flip
    result=array('Q')
    for u,v in struct.iter_unpack('<2H',coords):
        x=min(width-1,u*width//65535)
        y=min(height-1,v*height//65535)
        if reverse:
            y=height-1-y
        result.append(image[y*width+x])
    return result.tobytes()


def history_routes():
    directory=run/'projected-history-coordinates'
    result=directory/'results.json'
    if not result.is_file():
        return {}
    result=read(result)
    assert set(result)=={'native','player'}
    routes={}
    for tag,d in result.items():
        assert d['status']=='qualified' and d['baselineRestored']
        target=directory/tag/'history-uv.bin'
        actual=sha256(target.read_bytes()).hexdigest()
        assert actual==d['outputs']['coordinates'][1]
        routes[tag]=dict(path=str(target),sha256=actual,flip=tag=='native')
    return routes


def crop_inputs(req, entry, raw, dest, exact):
    bpp = 8 if entry['name'] == 'prior-color' else 4
    dims = (2560,1440) if bpp == 8 else (1280,720)
    assert len(raw) == bpp*dims[0]*dims[1]
    data = sample_color(raw, *dims, req['flip']) if bpp == 8 else raw
    if bpp == 4 and req['flip']:
        width, height = dims[0]*4, dims[1]
        data = b''.join(raw[y*width:(y+1)*width] for y in reversed(range(height)))
    assert len(data) == 1280*720*bpp
    if dest is not None:
        (dest/(entry['name']+'.bin')).write_bytes(data)
    if bpp == 8:
        for route, record in req.get('routes',{}).items():
            coords = Path(record['path']).read_bytes()
            assert sha256(coords).hexdigest() == record['sha256'] and len(coords) == 290*220*4
            sampled = at_history_uv(raw,*dims,req['flip'],record['flip'],coords)
            if dest is not None:
                (dest/f'prior-color-at-{route}.bin').write_bytes(sampled)
            exact[route] = dict(sha256=sha256(sampled).hexdigest(),bytes=len(sampled),
                                coordinateSha256=record['sha256'])
    return dict(entry,sha256=sha256(data).hexdigest(),length=len(data),fullSha256=sha256(raw).hexdigest())


def native_fixture(req, dest):
    path = root.parents[1]/'docs/acceptance/nr/evidence/2026-10-31/ray-vulkan-reference/summary.json'
    receipt = read(path)
    source = root.parents[1]/Path(receipt['export']['parent']['file']).parent
    export = receipt['export']['result']
    fixture = receipt['fixture']
    assert fixture == read(source/'manifest.json')
    assert fixture['event'] == req['event'] and fixture['preEvent'] == req['event']-1
    assert fixture['originalShaderSha256'] == req['shader'] and export['status'] == 'passed'
    assert all(fixture['validation'][key] for key in ('sampledTexturesUnchanged','originalOutputsExact','originalRepeatedExact'))
    payloads, usage, exact = [], {}, {}
    for entry in req['inputs']:
        role = {'prior-color':'previousColor', 'prior-depth':'previousDepth'}[entry['name']]
        row = next(item for item in fixture['textures'] if item['role'] == role)
        assert (row['binding'],row['source']['resource'],row['format']) == (entry['bind'],entry['resource'],entry['format'])
        usage[entry['name']] = export['usage'][entry['resource']]
        assert usage[entry['name']] == [dict(event=req['event'],usage='ResourceUsage.CS_Resource')]
        raw = (source/row['file']).read_bytes()
        assert len(raw) == row['bytes'] and sha256(raw).hexdigest() == row['sha256']
        main = row['levels'][0]
        assert main['mip'] == main['offset'] == 0
        payloads.append(crop_inputs(req,entry,raw[:main['bytes']],dest,exact))
    return dict(status='qualified',request=req,payloads=payloads,associatedColors=exact,eventUsage=usage,
                replaySource=dict(manifest=str(source/'manifest.json'),receiptSha256=sha256(path.read_bytes()).hexdigest(),
                                  captureSha256=fixture['captureSha256'],unchangedAcrossDispatch=True))


def capture_usage(controller, resource, event):
    uses = tuple(controller.GetUsage(resource))
    ids = {use.eventId for use in uses if use.eventId <= event}
    structured = controller.GetStructuredFile()
    action_info = {}

    def visit(actions, ancestry):
        for action in actions:
            if action.eventId > event:
                continue
            name = action.GetName(structured)
            if action.eventId in ids:
                action_info[action.eventId] = dict(name=name, groups=ancestry,
                    flags=str(action.flags), outputs=[str(target) for target in action.outputs],
                    copySource=str(action.copySource), copyDestination=str(action.copyDestination))
            if action.children:
                visit(action.children, ancestry+[name])

    visit(controller.GetRootActions(), [])
    return [dict(event=use.eventId, usage=str(use.usage), action=action_info.get(use.eventId))
            for use in uses if use.eventId <= event]


def replay(command_path):
    import renderdoc as rd
    path = Path(command_path)
    req = read(path)
    dest = path.parent
    result = dict(status='error', request=req)
    capture, controller = rd.OpenCaptureFile(), None
    try:
        assert capture.OpenFile(req['capture'],'',None) == rd.ResultCode.Succeeded
        status, controller = capture.OpenCapture(rd.ReplayOptions(),None)
        assert status == rd.ResultCode.Succeeded and controller is not None
        assert str(controller.GetAPIProperties().pipelineType) == 'GraphicsAPI.'+req['api']
        controller.SetFrameEvent(req['event'],True)
        pipeline = controller.GetPipelineState()
        shader = pipeline.GetShaderReflection(rd.ShaderStage.Compute)
        assert sha256(bytes(shader.rawBytes)).hexdigest() == req['shader']
        resources = {shader.readOnlyResources[row.access.index].fixedBindNumber:row.descriptor
                     for row in pipeline.GetReadOnlyResources(rd.ShaderStage.Compute)}
        textures = {str(t.resourceId):t for t in controller.GetTextures()}
        payloads, exact, usage = [], {}, {}
        for entry in req['inputs']:
            desc = resources[entry['bind']]
            assert str(desc.resource) == entry['resource'] and desc.firstMip == 0
            try:
                usage[entry['name']] = capture_usage(controller, desc.resource, req['event'])
            except Exception:
                usage[entry['name']] = dict(error=traceback.format_exc())
            tex = textures[entry['resource']]
            bpp = 8 if entry['name'] == 'prior-color' else 4
            dims = (2560,1440) if bpp == 8 else (1280,720)
            assert (tex.width, tex.height) == dims and tex.format.Name() == entry['format']
            raw = bytes(controller.GetTextureData(desc.resource,rd.Subresource(0,0,0)))
            payloads.append(crop_inputs(req,entry,raw,dest,exact))
        result.update(status='qualified', payloads=payloads, associatedColors=exact, eventUsage=usage)
    except BaseException:
        result['error'] = traceback.format_exc()
    finally:
        if controller is not None:
            controller.Shutdown()
        capture.Shutdown()
        write(dest/'results.json',result)
    os._exit(0 if result['status'] == 'qualified' else 1)


def launch():
    lease = read('D:/Projects/FYP-coordination/resources/current.json')
    assert lease['state'] == 'held' and lease['owner'] == '01a1d0a9-829a-7c11-a7a8-017e743887d9'
    assert Path(lease['output']) == run
    sys.path.insert(0, str(run.parents[2]/'tools'))
    from artifact_budget import check
    routes=history_routes()
    budget = check(run.parents[1],run=run,planned=28_000_000 if routes else 24_000_000)
    assert budget['allowed'], budget
    reports = {}
    for req in preflight():
        req['routes']=routes
        dest = out/req['device']
        dest.mkdir(parents=True,exist_ok=True)
        p = dest/'request.json'
        if (dest/'results.json').is_file():
            previous = read(dest/'results.json')
            if previous['status'] == 'qualified':
                if previous['request'] == req and 'eventUsage' in previous:
                    reports[req['device']] = previous
                    continue
                assert {k:v for k,v in req.items() if k!='routes'}=={
                    k:v for k,v in previous['request'].items() if k!='routes'}
        write(p,req)
        if req['device'] == 'native':
            result = native_fixture(req,dest)
            write(dest/'results.json',result)
            reports[req['device']] = result
            continue
        startup = subprocess.STARTUPINFO()
        startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startup.wShowWindow = 0
        with (dest/'replay.log').open('wb') as log:
            child = subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(Path(__file__).resolve())],
                                   cwd=dest, env=dict(os.environ, **{key:str(p)}),
                                   startupinfo=startup, stdout=log, stderr=subprocess.STDOUT, timeout=290)
        result = read(dest/'results.json')
        assert child.returncode == 0 and result['status'] == 'qualified', result.get('error')
        reports[req['device']] = result
    write(out/'readback.json', reports)


if key in os.environ:
    replay(os.environ[key])
elif __name__ == '__main__':
    if sys.argv[1:] == ['preflight']:
        native, player = preflight()
        print(json.dumps(dict(native=native_fixture(native,None),player=player), indent=2))
    else:
        assert sys.argv[1:] == ['run']
        launch()
