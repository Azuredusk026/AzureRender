"""Compare depth-aligned history color without attributing it to a ray endpoint."""
import json
from pathlib import Path
import runpy
import sys

import numpy as np

run = Path(__file__).resolve().parent
base = runpy.run_path(str(run/'score-native-floor-reflection-inputs.py'))
reader = runpy.run_path(str(run/'projected-history-source-replay.py'))
read, unpack, rays, cut, reconstruct = (base[k] for k in ('read','unpack','rays','cut','reconstruct'))
root = run.parents[2]
out = reader['out']
shape = (720,1280)
flip = np.array([-1,1,1])
n = read(reader['old'])
v = read(reader['current'])
nmat = np.asarray([row['float32'] for row in n['blocks'][0]['variables'][61:65]])
vmat = np.asarray(v['frameRows'][18:22])
native_checks = (n['event'],n['sha256'])
assert native_checks == (8702,reader['request']('native')['shader'])
assert v['event'] == 21668


def homogeneous(points, matrix):
    world = points @ matrix
    return world[...,:3] / world[...,3,None]


def registration():
    samples = np.asarray([[x,y,d,1] for x in (-.6,0,.6)
                         for y in (-.5,0,.5) for d in (.01,.02,.05)])
    player = homogeneous(samples,vmat)
    a = homogeneous(samples,nmat) * flip
    b = homogeneous(samples*[1,-1,1,1],nmat) * flip
    good = float(np.linalg.norm(a-player,axis=-1).max())
    wrong = float(np.linalg.norm(b-player,axis=-1).max())
    assert good < .005 and wrong > 5
    return dict(calibratedMaxWorldDifferenceMeters=good, incorrectYAxisMaxWorldDifferenceMeters=wrong)


def compare():
    registered = registration()
    report = read(out/'readback.json')
    assert set(report) == {'native','player'}
    for name, record in report.items():
        assert record['status'] == 'qualified'
        assert {k:v for k,v in record['request'].items() if k!='routes'} == reader['request'](name)
        routes=record['request'].get('routes',{})
        associated=record.get('associatedColors',{})
        assert set(routes)==set(associated)
        assert all(routes[k]['sha256']==v['coordinateSha256'] for k,v in associated.items())
    def payload(tag,name,kind,channels=None):
        row, = [x for x in report[tag]['payloads'] if x['name'] == name]
        return unpack(out/tag/(name+'.bin'),row['sha256'],kind,(*shape,channels) if channels else shape)
    nd, vd = (payload(d,'prior-depth','<f4') for d in ('native','player'))
    retained_depth, = [x for x in v['inputs'] if x['name']=='previousDepth']
    assert report['player']['payloads'][1]['fullSha256'] == retained_depth['data']['sha256']
    nc, vc = (payload(d,'prior-color','<f2',4)[...,:3].astype(np.float32) for d in ('native','player'))
    geometry = np.isfinite(nd)&np.isfinite(vd)&(nd>0)&(vd>0)&(nd<=1)&(vd<=1)
    color = np.all(np.isfinite(nc)&np.isfinite(vc)&(nc>=0)&(vc>=0),axis=-1)
    weights = np.array([.2126,.7152,.0722])
    nl, vl = nc@weights, vc@weights
    nt, vt = (c/(1+c.max(axis=-1,keepdims=True)) @ weights for c in (nc,vc))
    primary = read(root/'docs/acceptance/nr/evidence/2026-11-16/joint-scene-native-floor/results.json')['rectangles']
    regions = {label:tuple(a//2 for a in box) for label,box in primary.items()}
    def pct(a, m):
        return np.percentile(a[m],(10,50,90)).tolist() if np.any(m) else None
    def scores(box):
        sub = lambda x:cut(x,box)
        trusted = sub(geometry)&sub(color)
        wp = reconstruct(sub(vd),box,vmat)
        wn = reconstruct(sub(nd),box,nmat)*flip
        d = np.linalg.norm(wp-wn,axis=-1)
        def per(limit):
            m = trusted&(d<=limit)
            return dict(samples=int(m.sum()),worldDifferenceMeters=pct(d,m),
                        sourceLumaNative=pct(sub(nl),m),sourceLumaPlayer=pct(sub(vl),m),
                        sourceLumaPlayerMinusNative=pct(sub(vl)-sub(nl),m),
                        compressedLumaNative=pct(sub(nt),m),compressedLumaPlayer=pct(sub(vt),m),
                        compressedLumaAbsoluteDifference=pct(abs(sub(nt)-sub(vt)),m))
        return dict(halfRectangle=box,validSamples=int(trusted.sum()),
                    worldMatch={str(l):per(l) for l in (.02,.05,.10)})
    data = dict(status='qualified-prior-color-cross-check',
                scope='Same display coordinate and reconstructed world surface; not a ray endpoint comparison',
                registration=registered, native=report['native'],player=report['player'],
                regions={name:scores(box) for name,box in regions.items()})
    (out/'comparison.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    for name,row in data['regions'].items():
        print(name,row['worldMatch']['0.02'])


if __name__ == '__main__':
    if sys.argv[1:] == ['preview']:
        print(json.dumps(registration()))
    else:
        assert sys.argv[1:] == ['score']
        compare()
