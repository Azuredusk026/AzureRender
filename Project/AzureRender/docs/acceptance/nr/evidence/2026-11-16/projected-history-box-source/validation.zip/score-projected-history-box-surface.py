"""Identify paired prior HDR samples by stationary logistics-box triangle and UV."""
import hashlib
import json
from pathlib import Path
import runpy
import struct
import subprocess

import numpy as np

root = Path(__file__).resolve().parent
draws = runpy.run_path(str(root/'score-projected-history-draw-masks.py'))
study, local = draws['rgb'], draws['local']
s, b, rd = study['s'], study['b'], study['f']['reader']
digest = lambda data: hashlib.sha256(data).hexdigest()
main = draws['main']
tracked = draws['docs']+'captured-logistics-boxes.json'
dims = np.array([2560,1440])


def asset():
    native = json.loads(subprocess.check_output(['git','show','HEAD:'+tracked],cwd=draws['museum']))
    d = main/native['run']
    source = (d/'captured-box-receipt.json').read_bytes()
    assert digest(source)==next(row['sha256'] for row in native['artifacts'] if row['path']=='captured-box-receipt.json')
    receipt=json.loads(source)
    argv=json.loads((main/'build/runs/20261031-122504-projected-footprint-quality-5daf40/capture-indexed/request.json').read_bytes())['arguments']
    pr=Path(argv[argv.index('--project')+1])
    pc=pr.read_bytes(); project=json.loads(pc)
    mounts={q['name']:pr.parent/q['path'] for q in project['mounts']}
    resolve=lambda address: mounts[address.split(':/')[0]]/address.split(':/')[1]
    level_bytes=resolve(project['startupScene']).read_bytes(); scene=json.loads(level_bytes)
    resource,=[q for q in scene['resources'] if q['id']=='captured-logistics-boxes']
    node,=[q for q in scene['nodes'] if q.get('resourceId')==resource['id']]
    assert node['parentId']=='captured-world-basis'
    basis,=[q for q in scene['nodes'] if q['id']==node['parentId']]
    trans=lambda q:q['components']['azure.transform']['data']
    assert trans(node)==dict(translation=[0,0,0],rotation=[0,0,0],scale=[1,1,1]) and not basis['parentId']
    assert trans(basis)==dict(translation=[0,0,0],rotation=[0,0,0],scale=[-1,1,1])
    glb=resolve(resource['asset']).read_bytes(); sha=digest(glb)
    assert sha==receipt['outputSha256'] and len(glb)==receipt['outputBytes']
    size, tag=struct.unpack_from('<I4s',glb,12); assert tag==b'JSON'
    model=json.loads(glb[20:20+size]); size2,tag2=struct.unpack_from('<I4s',glb,20+size)
    assert tag2==b'BIN\0' and size2==len(glb)-28-size and model['nodes']==[dict(mesh=0)]
    payload=memoryview(glb)[28+size:]
    def acc(index):
        a=model['accessors'][index]; v=model['bufferViews'][a['bufferView']]
        assert 'byteStride' not in v and v['buffer']==0 and 'normalized' not in a
        columns={'SCALAR':1,'VEC2':2,'VEC3':3}[a['type']]
        return np.frombuffer(payload,dtype={5123:'<u2',5126:'<f4'}[a['componentType']],
            count=a['count']*columns,offset=v['byteOffset']+a.get('byteOffset',0)).reshape(-1,columns)
    def triangles(q):
        ix=acc(q['indices']).ravel().reshape(-1,3)
        pos=acc(q['attributes']['POSITION']).astype(float)*trans(basis)['scale']
        uv=acc(q['attributes']['TEXCOORD_0']).astype(float)
        return pos[ix],uv[ix]
    prims=model['meshes'][0]['primitives']
    assert len(prims)==len(receipt['instances'])==22 and all(q['material']==0 for q in prims)
    assert model['materials'][0]['alphaMode']=='OPAQUE'
    return [triangles(q) for q in prims],receipt['instances'],dict(glb=sha, receipt=digest(source),
        project=digest(pc),level=digest(level_bytes),material=model['materials'][0]['name'])


def match(points, mesh, tolerance=.02):
    xyz, uv = mesh
    a=xyz[:,0]; u=xyz[:,1]-a; v=xyz[:,2]-a
    uu=np.einsum('ij,ij->i',u,u); vv=np.einsum('ij,ij->i',v,v); uvv=np.einsum('ij,ij->i',u,v)
    den=uu*vv-uvv*uvv
    valid=den>1e-15
    n=np.cross(u,v)/np.sqrt(np.where(valid,den,1))[:,None]
    tri=np.full(len(points),-1)
    distance=np.full(len(points),np.inf)
    margins=np.full(len(points),-np.inf)
    uvout=np.full((len(points),2),np.nan)
    bound=(points>=xyz.min(axis=(0,1))-tolerance).all(1)&(points<=xyz.max(axis=(0,1))+tolerance).all(1)
    rows=np.flatnonzero(bound)
    for chunk in range(0,len(rows),384):
        ids=rows[chunk:chunk+384]; offset=points[ids,None]-a[None]
        up=np.einsum('pti,ti->pt',offset,u); vp=np.einsum('pti,ti->pt',offset,v)
        x=(up*vv-vp*uvv)/np.where(valid,den,1); y=(vp*uu-up*uvv)/np.where(valid,den,1)
        margin=np.minimum(np.minimum(x,y),1-x-y)
        dist=np.abs(np.einsum('pti,ti->pt',offset,n))
        score=np.where(valid[None]&(margin>=0)&(dist<=tolerance),dist,np.inf)
        idx=score.argmin(axis=1); j=np.arange(len(idx)); accept=np.isfinite(score[j,idx])
        ids,j,k=ids[accept],j[accept],idx[accept]
        tri[ids]=k; distance[ids]=score[j,k]; margins[ids]=margin[j,k]
        xj=x[j,k,None]; yj=y[j,k,None]
        uvout[ids]=(1-xj-yj)*uv[k,0]+xj*uv[k,1]+yj*uv[k,2]
    return tri,distance,margins,uvout


def identify(points, meshes, shift=(0,0,0)):
    n=len(points)
    best=[np.full(n,-1),np.full(n,-1),np.full(n,np.inf),np.full(n,-np.inf),np.full((n,2),np.nan)]
    for i,(xyz,uv) in enumerate(meshes):
        t,dist,margin,out=match(points,(xyz+shift,uv))
        take=dist<best[2]
        for a,x in zip(best,[np.full(n,i),t,dist,margin,out]):
            a[take]=x[take]
    return best


def controls():
    xyz=np.array([[[0,0,0],[1,0,0],[0,1,0]],[[1,0,0],[1,1,0],[0,1,0]]])
    use,dist,margin,uv=match(np.array([[.1,.2,.001],[.9,.8,.01],[.2,.2,.021],[1.2,.5,0]]),
                             (xyz,xyz[...,:2]))
    np.testing.assert_array_equal(use,[0,1,-1,-1])
    np.testing.assert_allclose(uv[:2],[[.1,.2],[.9,.8]],atol=1e-12)
    np.testing.assert_allclose(dist[:2],[.001,.01],atol=1e-12)
    np.testing.assert_allclose(margin[:2],[.1,.1],atol=1e-12)


def score():
    controls()
    meshes,instances,asset_id=asset(); print(asset_id,flush=True)
    masks, refs = draws['retained_masks']()
    depth,ids,coords,canonical,conf,rgb,color,receipt=study['load']()
    events=draws['groups']['logisticsBoxes']
    mask=np.logical_or.reduce([masks[e] for e in events])
    manifest_rows=s['original_history_depths']()[2:]
    manifest, rows=manifest_rows
    hdr,=[q for q in rows if q['role']=='previousColor']
    raw=(manifest.parent/hdr['file']).read_bytes()
    assert digest(raw)==hdr['sha256']
    img=s['compressed_rgb'](np.frombuffer(raw[:hdr['levels'][0]['bytes']],'<f2').reshape(1440,2560,4)[::-1,:,:3])
    data_samples={}
    out=dict(nativeHistory=hdr['sha256'],status='stationary-captured-box-geometry-source-comparison',asset=asset_id,depth=ids,
        mask={str(i):refs[str(i)]['sha256'] for i in events},playerHistory=receipt['fullSha256'],routes={})
    for route in study['tags']:
        pixel=local['inverse_indices'](canonical[route])
        cxy=(pixel+.5)/dims*65535
        nxy=cxy.copy(); nxy[...,1]=65535-nxy[...,1]
        wn,nv,_=s['world_from_history'](nxy,depth['native'],s['N'],True)
        wp,pv,_=s['world_from_history'](cxy,depth['player'],s['V'],False)
        m=nv&pv&(np.linalg.norm(wn-wp,axis=-1)<=.02)&(conf['native']>0)&(conf['player']>0)
        for w,h in ((1280,720),(2560,1440)):
            m &= s['stable_indices'](coords[route][...,0],w)&s['stable_indices'](coords[route][...,1],h)
        m &= s['coherently_sampled'](s['compressed_rgb'](color[route][route]),rgb[route])
        boxmask=mask[pixel[...,1],pixel[...,0]]
        source_mask=m&boxmask
        pxy, first, back=np.unique(pixel[source_mask],axis=0,return_index=True,return_inverse=True)
        expected=np.array([z['event'] for z in instances])
        native, player=[identify(q[source_mask][first],meshes) for q in (wn,wp)]
        control_shift=(.1,.1,.1)
        nshift, pshift=[identify(q[source_mask][first],meshes,control_shift) for q in (wn,wp)]
        ni,nt,nd,nm,nu=native; pi,pt,pd,pm,pu=player
        maj=(ni>=0)&(pi==ni)&(nt==pt)
        first_mask=np.asarray([masks[e] for e in events])[:,pxy[:,1],pxy[:,0]]
        match_event=np.any((expected[ni][None,:]==np.asarray(events)[:,None])&first_mask,axis=0)
        duv=np.max(abs(nu-pu),axis=-1)
        def mapv(v):
            tmp=np.zeros(source_mask.shape,dtype=v.dtype); tmp[source_mask]=v[back]; return tmp
        counts={}
        ac,pc=[s['compressed_rgb'](color[q][route]) for q in study['tags']]
        delta=(pc-ac)@s['weight']; confidence=np.minimum(conf['native'],conf['player'])
        for key,m0 in {
            'pairedNearestTriangle':maj,
            'sourceEventMatchesDrawMask':maj&match_event,
            'nearInteriorUv':maj&match_event&(np.maximum(nd,pd)<=.005)&(np.minimum(nm,pm)>.02)&(duv<=.002),
            'nearInteriorUvStrict':maj&match_event&(np.maximum(nd,pd)<=.003)&(np.minimum(nm,pm)>.03)&(duv<=.001),
        }.items():
            im=mapv(m0)
            def stat(where):
                val=delta[where]; weight=confidence[where]
                return dict(samples=int(where.sum()), priorAddresses=len(np.unique(pixel[where],axis=0)),
                    medianCompressedLuma=float(np.median(val)) if len(val) else None,
                    negative=int((val<0).sum()), maximumDarkLuma=float(-val.min()) if len(val) else None,
                    negativeEnergy=float(np.maximum(-val,0)@weight))
            regions={}
            for name, box in b['REGIONS'].items():
                if name not in ('centerFloor','cyanRing'):continue
                scope=np.zeros_like(im); x0,y0,x1,y1=b['local'](box); scope[y0:y1,x0:x1]=True
                regions[name]=dict(qualified=stat(im&scope),maskOnly=stat(source_mask&scope))
            counts[key]=dict(addresses=int(m0.sum()),metrics=regions,
                surfaceDistancePercentiles=np.percentile(np.maximum(nd,pd)[m0],[10,50,90]).tolist() if m0.any() else None,
                uvDeltaPercentiles=np.percentile(duv[m0],[10,50,90]).tolist() if m0.any() else None)
        nsi,nst,nsd,nsm,nsu=nshift; psi,pst,psd,psm,psu=pshift
        shift=(nsi>=0)&(nsi==psi)&(nst==pst)&(np.maximum(nsd,psd)<=.005)&(np.minimum(nsm,psm)>.02)&(np.max(abs(nsu-psu),axis=-1)<=.002)
        strict=maj&match_event&(np.maximum(nd,pd)<=.005)&(np.minimum(nm,pm)>.02)&(duv<=.002)
        cert_idx=np.flatnonzero(strict)
        sampled_player=pc[source_mask][first][cert_idx]
        sampled_native=ac[source_mask][first][cert_idx]
        xx,yy=pxy[cert_idx].T
        np.testing.assert_equal(img[yy,xx],sampled_native)
        local_err=np.max(np.abs(sampled_native-sampled_player),axis=-1)
        best_err=local_err.copy()
        witness_luma=(sampled_player-sampled_native)@s['weight']
        offsets=np.array([(dx,dy) for dy in range(-8,9) for dx in range(-8,9)])
        choices=np.zeros((len(offsets),len(cert_idx)),dtype=float)
        for off,(dx,dy) in enumerate(offsets):
            nearby=img[np.clip(yy+dy,0,1439),np.clip(xx+dx,0,2559)]
            choices[off]=np.max(np.abs(nearby-sampled_player),axis=-1)
        np.testing.assert_array_equal(choices[144],local_err)
        best_err=choices.min(axis=0)
        err_map=np.full(len(pxy),np.inf); err_map[cert_idx]=best_err
        data_samples[route]=dict(x=xx.astype('<u2'), y=yy.astype('<u2'), native=sampled_native, player=sampled_player,
                                 best=best_err, same=local_err, support=np.zeros(len(xx),dtype=np.uint8))
        region_result={}
        for name, box in b['REGIONS'].items():
            if name not in ('centerFloor','cyanRing'):continue
            xp,yp,Xp,Yp=b['local'](box)
            support=np.zeros(m.shape,dtype=bool); support[yp:Yp,xp:Xp]=True
            supported=np.bincount(back,weights=support[source_mask],minlength=len(pxy))[cert_idx]>0
            data_samples[route]['support'] |= supported.astype(np.uint8)*{'centerFloor':1,'cyanRing':2}[name]
            severe=supported&(witness_luma<-.10)
            parity=((xx//32+yy//32)%2).astype(bool)
            fits=[]
            for fold in (False,True):
                train=supported&(parity==fold)
                test=supported&~(parity==fold)
                if not train.any() or not test.any(): continue
                before=float(local_err[test].mean())
                order=np.lexsort((offsets[:,1],offsets[:,0],abs(offsets).sum(1),choices[:,train].mean(axis=1)))
                k=order[0]
                after=float(choices[k,test].mean())
                fits.append(dict(offset=offsets[k].tolist(),train=int(train.sum()),test=int(test.sum()),
                    originalTestMeanRgb=before,fixedOffsetTestMeanRgb=after,
                    severeOriginalTestMeanRgb=float(local_err[test&severe].mean()) if (test&severe).any() else None,
                    severeFixedOffsetTestMeanRgb=float(choices[k,test&severe].mean()) if (test&severe).any() else None))
            region_result[name]=dict(certifiedAddresses=int(supported.sum()),lumaBelowPoint10=int(severe.sum()),
                disjointTileFixedShift=fits,
                severeStillRgbOverPoint02AtEight=int((severe&(best_err>.02)).sum()),
                severeStillRgbOverPoint05AtEight=int((severe&(best_err>.05)).sum()),
                severeMedianBestRgbAtEight=float(np.median(best_err[severe])) if severe.any() else None)
        certified=[]
        for i in cert_idx:
            p=tuple(pxy[i])
            samples=np.flatnonzero((pixel[...,0]==p[0])&(pixel[...,1]==p[1])&source_mask)
            vals=delta.ravel()[samples]
            certified.append(dict(previousPixelXY=list(map(int,p)),event=int(expected[ni[i]]),
                primitive=int(ni[i]),instance=instances[ni[i]]['instance'],triangle=int(nt[i]),nativeUV=nu[i].tolist(),playerUV=pu[i].tolist(),
                maxPlaneDistanceMeters=float(max(nd[i],pd[i])),deltaCompressedLuma=float(vals[0]), unrestrictedNativeEightPixelBestRgb=float(err_map[i])))
        best=[]
        for e in events:
            positive=sorted((q for q in certified if q['event']==e),key=lambda q:q['deltaCompressedLuma'])
            best.extend(positive[:4])
        out['routes'][route]=dict(maskAddresses=len(pxy), controls=dict(geometryTranslationMeters=control_shift,
            shiftedStillNearInteriorUvWithoutMaskEventCheck=int(shift.sum())),
            comparisons=counts, unrestrictedNeighborhoodBestRgb=region_result, largestDarknessWitnesses=best)
        print(route, 'registration', int(strict.sum()), 'translated', int(shift.sum()), 'local', json.dumps(region_result),flush=True)
    arrays={f'{route}_{k}':v for route, values in data_samples.items() for k,v in values.items()}
    from io import BytesIO
    package=BytesIO(); np.savez_compressed(package,**arrays); packed=package.getvalue()
    (s['floor']/'history-source-box-surface-arrays.npz').write_bytes(packed)
    out['pairedArraysSha256']=digest(packed)
    result=s['floor']/'history-source-box-surface-registration.json'
    result.write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')


if __name__=='__main__':
    score()
