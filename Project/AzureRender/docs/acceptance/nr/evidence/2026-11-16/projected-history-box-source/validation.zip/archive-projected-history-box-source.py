"""Archive the registered box color diagnostic and verify its portable paired counts."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import sys
import zipfile

import numpy as np

run=Path(__file__).resolve().parent
evidence=run.parents[2]/'docs/acceptance/nr/evidence/2026-11-16/projected-history-box-source'
paths=run/'projected-history-coordinates'
a='history-source-box-surface-arrays.npz'
res='history-source-box-surface-registration.json'
zipname='validation.zip'
w=np.array([.2126,.7152,.0722])
sha=lambda b:sha256(b).hexdigest()


def verify(results, payload):
    assert results['pairedArraysSha256']==sha(payload)
    with np.load(BytesIO(payload),allow_pickle=False) as z:
        for route in ('native','player'):
            x,y,n,p,b,s,original=[z[route+'_'+k] for k in ('x','y','native','player','best','support','same')]
            assert n.shape==p.shape==(len(x),3) and len(y)==len(x)==len(s)==len(b)
            assert ((x<2560)&(y<1440)&(s<=3)&(b>=0)&(b<=original)).all()
            assert len(np.unique(np.stack((x,y),axis=-1),axis=0))==len(x)
            assert (np.isfinite(n)&np.isfinite(p)).all()
            np.testing.assert_array_equal(np.max(abs(n-p),axis=-1),original)
            score=results['routes'][route]
            assert score['comparisons']['nearInteriorUv']['addresses']==len(x)
            control=score['controls']
            assert control['shiftedStillNearInteriorUvWithoutMaskEventCheck']<.02*len(x)
            dp=(p-n)@w
            for region,bit in [('centerFloor',1),('cyanRing',2)]:
                g=score['unrestrictedNeighborhoodBestRgb'][region]
                keep=(s&bit)!=0; sever=keep&(dp<-.10)
                assert int(keep.sum())==g['certifiedAddresses']
                assert int(sever.sum())==g['lumaBelowPoint10']
                assert int((sever&(b>.02)).sum())==g['severeStillRgbOverPoint02AtEight']
                assert int((sever&(b>.05)).sum())==g['severeStillRgbOverPoint05AtEight']
                assert abs(float(np.median(b[sever]))-g['severeMedianBestRgbAtEight'])<1e-14
                assert (dp[keep]<0).any()
                parity=((x//32+y//32)%2).astype(bool)
                for i,fit in enumerate(g['disjointTileFixedShift']):
                    test=keep&(parity!=bool(i))
                    assert fit['test']==int(test.sum()) and fit['train']==int(keep.sum()-test.sum())
                    assert abs(fit['originalTestMeanRgb']-float(original[test].mean()))<1e-14
                    assert fit['offset'][0]==0
                    assert (fit['offset'][1]<0) == (region=='centerFloor')
    print('Verified paired colors, both regions, spatial negative control and holdout directions.')


mode,=sys.argv[1:]
if mode=='build':
    results=json.loads((paths/res).read_bytes())
    payload=(paths/a).read_bytes()
    verify(results,payload)
    evidence.mkdir(parents=True,exist_ok=True)
    contents={a:payload,res:(paths/res).read_bytes(),
              'score-projected-history-box-surface.py':(run/'score-projected-history-box-surface.py').read_bytes(),
              'archive-projected-history-box-source.py':Path(__file__).read_bytes()}
    with zipfile.ZipFile(evidence/zipname,'w') as z:
        for name,data in sorted(contents.items()):
            ordinal=zipfile.ZipInfo(name,(2026,11,16,0,0,0))
            ordinal.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(ordinal,data,compresslevel=9)
    results['archiveSha256']=sha((evidence/zipname).read_bytes())
    results['scope']='Paired stationary source plane and UV, reflected through the retained native and Player history depths at one archived camera. The translated geometry is only a negative control. A closest independent neighboring color is a bound, not a common correction or texture proof.'
    (evidence/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf8')
else:
    assert mode=='verify'
    results=json.loads((evidence/'results.json').read_bytes())
    bundle=(evidence/zipname).read_bytes()
    assert results.pop('archiveSha256')==sha(bundle)
    results.pop('scope')
    with zipfile.ZipFile(BytesIO(bundle)) as z:
        assert not z.testzip()
        assert results==json.loads(z.read(res))
        verify(results,z.read(a))
    print(sha(bundle))
