"""Link a diagnostic that records the opaque snapshot in the primary command buffer."""
import ast
from hashlib import file_digest
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
from zipfile import ZipFile

M=Path(__file__).resolve().parent
W=M.parents[2]
B=M.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'
release=B/'msaa-release'
combined=M/'projected-history-layer-release'
reference=M/'immutable-scene-capture-source'
target=M/'primary-opaque-snapshot-diagnostic-player'
exe=combined/'AzurePlayerPrimaryOpaqueSnapshot.exe'
key='AZR_NR_QA_PRIMARY_OPAQUE_SNAPSHOT'

def sha(p):
    with Path(p).open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


read=lambda p:json.loads(p.read_bytes())


def controls():
    old=W/'src/app/AzureRenderFrame.cpp'
    body=old.read_text(encoding='utf8')
    retained=subprocess.check_output(['git','show','75837a6:Project/AzureRender/src/app/AzureRenderFrame.cpp'],cwd=W,encoding='utf8')
    assert body==retained
    program=read(reference/'qualification.json')
    assert sha(combined/'AzurePlayerCaptureResource.exe')==program['candidatePlayer']
    assert sha(reference/'AssetDatabase.cpp.obj')==program['assetDatabaseObject']
    order='''    std::vector<azurerender::RenderGraph::PassId> recordingOrder;
    if (!runOptions_.parallelRecordingDisabled) {
        recordingOrder.reserve(graph.executionOrder().size());
        for (const auto pass : graph.executionOrder())
            if (graph.passes()[pass].parallelRecording)
                recordingOrder.push_back(pass);
    }'''
    assert body.count(order)==1
    revisedOrder="""    const auto* snapshotDiagnostic=std::getenv("AZR_NR_QA_PRIMARY_OPAQUE_SNAPSHOT");
    const bool snapshotPrimary=snapshotDiagnostic && std::string_view(snapshotDiagnostic)=="1";
    bool foundSnapshot=false;
    std::vector<azurerender::RenderGraph::PassId> recordingOrder;
    if (!runOptions_.parallelRecordingDisabled) {
        recordingOrder.reserve(graph.executionOrder().size());
        for (const auto pass : graph.executionOrder()) {
            const auto& description=graph.passes()[pass];
            if (snapshotPrimary && description.name=="character-opaque-depth") {
                foundSnapshot=true;
                continue;
            }
            if (description.parallelRecording) recordingOrder.push_back(pass);
        }
    }
    if (snapshotPrimary) {
        if (!foundSnapshot)
            throw std::logic_error("QA primary snapshot mode requires the opaque snapshot pass");
        azurerender::RuntimeDiagnostics::instance().info("render","QA opaque snapshot recorded in primary command buffer");
    }"""
    return old,'#include <cstdlib>\n#include <string_view>\n'+body.replace(order,revisedOrder)


def run():
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    assert not exe.exists()
    budget=check(W/'build',run=M,planned=17_000_000)
    assert budget['allowed'],budget
    source,revised=controls()
    target.mkdir(exist_ok=True)
    text=target/source.name
    text.write_text(revised,encoding='utf8')
    obj=target/'AzureRenderFrame.cpp.obj'
    driver=runpy.run_path(str(B/'face-quality-batch.py'),run_name='inline_secondary_compiler')
    ninja=Path(driver['cmake']).parents[2]/'Ninja/ninja.exe'
    schema=ast.parse((M/'build-camera-pose-player.py').read_text(encoding='utf8'))
    fn,=[p for p in schema.body if isinstance(p,ast.FunctionDef) and p.name=='windows_arguments']
    ns={}
    exec(compile(ast.Module(body=[fn],type_ignores=[]),'inline_secondary_arguments','exec'),ns)
    commands=subprocess.check_output([str(ninja),'-C',str(release),'-t','commands','AzurePlayer'],text=True).splitlines()
    cl_line,=[line for line in commands if line.endswith(str(source))]
    cl=ns['windows_arguments'](cl_line)
    assert Path(cl[0]).name.lower()=='cl.exe'
    for flag,name in [('/Fo',obj),('/Fd',target/'diagnostic.pdb')]:
        i,=[i for i,v in enumerate(cl) if v.startswith(flag)]
        cl[i]=flag+str(name)
    cl[-1:]=['/I'+str(source.parent),str(text)]
    rsp=target/'player.rsp'
    link_source=(reference/'player.rsp').read_text(encoding='ascii').splitlines()
    original_entry=str(reference/'main.cpp.obj')
    entry_receipt=read(reference/'main-object-compaction.json')
    archive=Path(entry_receipt['archive'])
    assert sha(archive)==entry_receipt['archiveSha']
    restored=target/'capture-entry-main.cpp.obj'
    assert restored.resolve()==restored and not restored.exists()
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None and entry_receipt['member']=='main.cpp.obj'
        with restored.open('xb') as obj_out:
            obj_out.write(bundle.read(entry_receipt['member']))
    assert sha(restored)==entry_receipt['sha256']==read(reference/'qualification.json')['entryObject']
    assert original_entry in link_source[0] and str(reference/'AssetDatabase.cpp.obj') in link_source[0]
    link_source[0]=link_source[0].replace(original_entry,str(restored))
    rsp.write_text('\n'.join([link_source[0]+' '+subprocess.list2cmdline([str(obj)]),*link_source[1:]])+'\n',encoding='ascii')
    options=read(combined/'link-receipt.json')['linkCommand']
    linker=options.copy()
    for i,value in enumerate(linker):
        if value.startswith('--intdir='):
            path=target/'link-intermediates'
            path.mkdir(exist_ok=True)
            linker[i]='--intdir='+str(path)
        elif value.startswith('@'):
            linker[i]='@'+str(rsp)
        elif value.lower().startswith('/out:'):
            linker[i]='/out:'+str(exe)
        elif value.lower().startswith('/implib:'):
            linker[i]='/implib:'+str(target/'diagnostic.lib')
        elif value.lower().startswith('/pdb:'):
            linker[i]='/pdb:'+str(target/'link.pdb')
    env={k:v for k,v in os.environ.items() if k not in (key,'AZR_NR_QA_RESOURCE_ID','AZR_NR_QA_RESOURCE_PATH')}
    try:
        for name,args in [('compile',cl),('link',linker)]:
            cmd=subprocess.list2cmdline([driver['entry'],*args])
            built=subprocess.run(cmd,shell=True,cwd=release,env=env,capture_output=True,timeout=175)
            (target/f'{name}.log').write_bytes(built.stdout+built.stderr)
            assert built.returncode==0,(name,built.stdout[-3500:],built.stderr[-3500:])
    finally:
        assert sha(restored)==entry_receipt['sha256'] and not restored.stat().st_file_attributes&1024
        restored.unlink()
    help=subprocess.run([str(exe),'--help'],env=env,capture_output=True,timeout=20)
    assert help.returncode==0 and b'--disable-parallel-recording' in help.stdout
    q=dict(status='linked-primary-opaque-snapshot-diagnostic',source=sha(source),diagnostic=sha(text),object=sha(obj),
           player=sha(exe),immutableSourcePlayer=sha(combined/'AzurePlayerCaptureResource.exe'),
           introduction='Only the opaque-snapshot pass uses the primary recorder when enabled.',
           supportedModes=['1'])
    (target/'qualification.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf8')
    print(q)


if __name__=='__main__':
    if sys.argv[1:]==['preflight']:
        print(controls()[0])
    else:
        run()
