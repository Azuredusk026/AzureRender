"""Retest the existing full-body scene with only the opaque snapshot recorded inline."""
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import sys
from zipfile import ZipFile

import cv2
import numpy as np

M=Path(__file__).resolve().parent
W=M.parents[2]
O=M/'primary-opaque-snapshot-diagnostic-player'
P=M/'projected-history-layer-release/AzurePlayerPrimaryOpaqueSnapshot.exe'
key='AZR_NR_QA_PRIMARY_OPAQUE_SNAPSHOT'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
body=runpy.run_path(str(M/'joint-character-referenced-body.py'),run_name='snapshot_primary_capture')
C=body['OUT']


def raw_frame(dev,label,ref):
    path=C/f'{dev}-{label}.zip'
    with ZipFile(path) as z:
        data=z.read('frame_000000.bgra-xor')
    return ref^np.frombuffer(data,np.uint8).reshape(ref.shape)


def run():
    sys.path.insert(0,str(W/'tools'))
    from artifact_budget import check
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output'])==M
    assert check(W/'build',run=M,planned=6_300_000)['allowed']
    q=read(O/'qualification.json')
    assert q['status']=='linked-primary-opaque-snapshot-diagnostic' and q['player']==digest(P)
    core,assets,_=body['prepare']()
    assert core['player']==q['immutableSourcePlayer']
    result=O/'actual-qualification.json'
    previous=read(result) if result.is_file() else {'status':'capturing','records':{}}
    assert previous['status']=='capturing'
    records=previous['records']
    with body['temporary_descriptor'](assets[1]) as descriptor:
        for dev,limit,donors in (('intel',4,('serial-a','serial-b','native','native-repeat')),
                                 ('nvidia',1,('native',))):
            baseline=M/f'character-six-view-inputs/{dev}-back-detail/frames/frame_000000.png'
            ref=cv2.imread(str(baseline),-1)
            assert ref.shape==(720,1280,4)
            known={k:raw_frame(dev,k,ref) for k in donors}
            controls=known['serial-a' if dev=='intel' else 'native']
            device_data=records.setdefault(dev,[])
            for row in device_data:
                name=row['label']
                assert digest(C/f'{dev}-{name}.zip')==row['frame']['archive']
                assert sha256(raw_frame(dev,name,ref).tobytes()).hexdigest()==row['frame']['raw']
                log=(C/f'{dev}-{name}/player.log').read_text(encoding='utf8',errors='replace')
                assert 'QA opaque snapshot recorded in primary command buffer' in log
            if len({row['frame']['raw'] for row in device_data})>1:
                continue
            for i in range(1+len(device_data),limit+1):
                mode=f'primary-opaque-snapshot-{i}'
                assert check(W/'build',run=M,planned=1_750_000)['allowed']
                assert key not in os.environ
                os.environ[key]='1'
                try:
                    frame=body['capture'](dev,mode,descriptor,override_player=P)
                finally:
                    os.environ.pop(key)
                folder=C/f'{dev}-{mode}'
                log=(folder/'player.log').read_text(encoding='utf8',errors='replace')
                assert ('QA opaque snapshot recorded in primary command buffer' in log and
                        'Reflection field: 12 local probes' in log)
                manifest=read(folder/'frames/capture_manifest.json')
                assert manifest['qaIsolation']=='beauty' and manifest['screenReflectionProducer']=='linear-temporal'
                actual=raw_frame(dev,mode,ref)
                assert sha256(actual.tobytes()).hexdigest()==frame['raw']
                d=np.abs(actual.astype(np.int16)-controls.astype(np.int16)).max(2)
                data=dict(label=mode,frame=frame,againstKnown={k:int(np.count_nonzero(np.any(v!=actual,axis=2))) for k,v in known.items()},
                          controlChanged=int(np.count_nonzero(d)),controlOverOne=int(np.count_nonzero(d>1)),
                          controlPeak=int(d.max()),groundOverOne=int(np.count_nonzero(d[608:680,896:992]>1)),
                          upperOverOne=int(np.count_nonzero(d[160:232,896:992]>1)))
                device_data.append(data)
                print(dev,data,flush=True)
                result.write_text(json.dumps(dict(status='capturing',records=records),indent=2)+'\n',encoding='utf8')
                if len({x['frame']['raw'] for x in device_data})>1:
                    break
    devices={k:dict(repeatExact=len({s['frame']['raw'] for s in v})==1,
            serialExact=all(s['controlChanged']==0 for s in v),samples=v) for k,v in records.items()}
    full=len(records['intel'])==4 and all(d['repeatExact'] and d['serialExact'] for d in devices.values())
    d=dict(status='tested-primary-opaque-snapshot',request='only-opaque-snapshot-primary',devices=devices,
           focusedCandidateQualified=full,productionAcceptance=False,build=q)
    result.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')


if __name__=='__main__':
    run()
