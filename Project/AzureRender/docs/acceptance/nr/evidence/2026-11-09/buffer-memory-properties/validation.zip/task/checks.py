from pathlib import Path
import os,sys,json,shutil,zipfile
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
from build_provenance import verify,digest
os.environ.update(managed_environment(o/'tmp'));rows=json.loads((o/'checks.json').read_text()) if (o/'checks.json').exists() else []
with zipfile.ZipFile(r/'docs/acceptance/nr/evidence/2026-11-09/owned-image-conversion/validation.zip') as z:baseline=json.loads(z.read('builds.json'))
for c in sys.argv[1:] or ['release','debug']:
 b=r/('build/ninja-msvc-'+c);verify(r,json.loads((b/'build-provenance.json').read_text()))
 programs={p:sha for p,sha in baseline[c]['products'].items() if Path(p).parent==b/'shaders' and p.endswith('.spv')}
 assert len(programs)==675 and all(digest(Path(p))==sha for p,sha in programs.items())
 for target in ['AzureMaterialTextureSharingTests','AzureGpuBufferPolicyGpuTests','AzureVolumeImageUploadGpuTests']:
  for device,driver in ([('cpu','cpu')] if 'MaterialTexture' in target else [('nvidia','*nv-vk64*'),('intel','*igvk64*')]):
   os.environ['VK_LOADER_DRIVERS_SELECT']=driver
   for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES']:os.environ.pop(key,None)
   command=[str(b/(target+'.exe'))]
   if device=='cpu':command.append(str(b/'shaders'))
   execution=guarded_run(r/'build',o.name,command,120);label=c+'-'+target+'-'+device
   shutil.copyfile(o/'process.log',o/(label+'.log'));log=(o/'process.log').read_text(errors='replace')
   row=dict(configuration=c,device=device,target=target,execution=execution);rows.append(row);(o/'checks.json').write_text(json.dumps(rows,indent=2))
   print(label,execution['exitCode'],flush=True)
   assert execution['status']=='exited' and execution['exitCode']==0,(execution,log[-3000:])
   assert not any(x in log for x in ['Validation Error:','SYNC-HAZARD','VUID-'])
