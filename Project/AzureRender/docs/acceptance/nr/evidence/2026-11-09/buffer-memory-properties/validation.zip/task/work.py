from pathlib import Path
import os,sys,json,subprocess,time
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'))
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',*sys.argv[1:]],env=env).returncode)
mode=sys.argv[-1];start=time.monotonic()
if mode=='red':
 with (o/'red-build.log').open('wb') as log:subprocess.run(['cmake','--build','build/ninja-msvc-release','--target','AzureGpuBufferPolicyGpuTests','-j','3'],stdout=log,stderr=subprocess.STDOUT,check=True)
 os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
 with (o/'red-test.log').open('wb') as log:p=subprocess.run(['build/ninja-msvc-release/AzureGpuBufferPolicyGpuTests.exe'],stdout=log,stderr=subprocess.STDOUT)
 print((o/'red-test.log').read_text(),flush=True);assert p.returncode==1
else:
 assert mode in ['Release','Debug'];b=r/('build/ninja-msvc-'+mode.lower());command=[sys.executable,'-X','utf8','tools/build_provenance.py','build','--build-dir',str(b),'--config',mode]
 for target in ['AzureGpuBufferPolicyGpuTests','AzureVolumeImageUploadGpuTests','AzureMaterialTextureSharingTests']:command+=['--test-target',target]
 with (o/(mode.lower()+'-build.log')).open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 (o/(mode.lower()+'-build.json')).write_text(json.dumps(dict(exitCode=p.returncode,seconds=time.monotonic()-start,command=command),indent=2));print(mode,p.returncode,flush=True);raise SystemExit(p.returncode)
