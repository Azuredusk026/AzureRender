from pathlib import Path
import os,sys,json,shutil
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
from build_provenance import inputs,digest,verify
os.environ.update(managed_environment(o/'tmp'));b=r/'build/ninja-msvc-release'
verify(r,json.loads((b/'build-provenance.json').read_text()));source=inputs(r)
lock=json.loads((o.parent/'20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text());assert all(digest(Path(p))==sha for p,sha in lock.items())
project=o.parent/'20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['PATH']=str(b)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES']:os.environ.pop(key,None)
command=[str(b/'AzurePlayer.exe'),'--project',str(project),'--resource-root',str(b),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','24','--smoke-frames','2','--gpu-timing','--gpu-timing-output',str(o/'native-memory.json')]
execution=guarded_run(r/'build',o.name,command,300);shutil.copyfile(o/'process.log',o/'native.log');(o/'native-execution.json').write_text(json.dumps(execution,indent=2))
log=(o/'native.log').read_text(errors='replace');assert execution['status']=='exited' and execution['exitCode']==0
assert 'Allocator after unload: buffers=0 images=0' in log and not any(x in log for x in ['Validation Error:','SYNC-HAZARD','VUID-'])
data=json.loads((o/'native-memory.json').read_text());a=data['allocator'];p=a['bufferMemoryProperties']
assert p['samples']==a['bufferAllocations'] and p['liveDeviceLocalBytes']+p['liveNonDeviceLocalBytes']==a['liveBufferBytes']
assert p['liveMappedNonLocalDeviceBytes']<=p['liveMappedDeviceBytes']<=a['liveBufferBytes']
assert inputs(r)==source and all(digest(Path(p))==sha for p,sha in lock.items())
report=dict(status='observed-selected-buffer-memory-types',allocator=a,sourceUnchanged=True,inputsVerified=len(lock),sceneLoad=data['sceneLoad'],frames=2,formalPerformancePassed=False)
(o/'native-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
