#include "support/VulkanComputeFixture.hpp"
#include "resources/BinaryFile.hpp"
#include <nlohmann/json.hpp>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <limits>
using namespace azurerender;
int main(int argc,char** argv)try{
    if(argc!=3)throw std::invalid_argument("Expected reference and candidate shader paths");
    test::VulkanComputeFixture host;auto& backend=*host.backend;
    constexpr unsigned count=131072,warmup=128,samples=64,iterations=warmup+samples;
    auto output=host.allocator.createBuffer(count*4*sizeof(float),VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
    VkDescriptorSetLayout setLayout{};VkDescriptorPool pool{};VkPipelineLayout layout{};VkQueryPool queries{};
    std::vector<VkShaderModule> shaders;std::vector<VkPipeline> pipelines;
    auto cleanup=std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*){
        for(auto p:pipelines)backend.destroyPipeline(p);for(auto s:shaders)backend.destroyShaderModule(s);
        if(queries)vkDestroyQueryPool(host.device,queries,nullptr);if(layout)backend.destroyPipelineLayout(layout);
        if(pool)backend.destroyDescriptorPool(pool);if(setLayout)backend.destroyDescriptorSetLayout(setLayout);
        host.allocator.destroyBuffer(output);
    });
    setLayout=backend.createDescriptorSetLayout({{0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT}});
    rhi::DescriptorPoolDesc desc;desc.maxSets=1;desc.sizes={{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1}};
    pool=backend.createDescriptorPool(desc);auto set=backend.allocateDescriptorSets(pool,setLayout,1).front();
    backend.writeDescriptorBuffer({set,0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,output.buffer,output.size});
    layout=backend.createPipelineLayout(setLayout,nullptr);
    for(unsigned mode=0;mode<2;++mode){
        shaders.push_back(backend.createShaderModule(readBinaryFile(argv[mode+1])));
        pipelines.push_back(backend.createComputePipeline({shaders.back(),layout}));
    }
    VkQueryPoolCreateInfo query{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};query.queryType=VK_QUERY_TYPE_TIMESTAMP;query.queryCount=2*iterations;
    test::vkRequire(vkCreateQueryPool(host.device,&query,nullptr,&queries),"Create direct response timestamps");
    std::vector<float> reference; nlohmann::json rows=nlohmann::json::array();
    for(unsigned mode:{0U,1U,0U}){
        host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer native){
            vkCmdResetQueryPool(native,queries,0,2*iterations);
            commands.bindComputePipeline(pipelines[mode]);commands.bindComputeDescriptorSet(layout,set);
            for(unsigned i=0;i<iterations;++i){
                if(i)commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});
                commands.writeTimestamp(queries,2*i,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
                commands.dispatch(count/64,1,1);commands.writeTimestamp(queries,2*i+1,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
            }
            commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
        });
        host.allocator.invalidate(output,0,output.size);const auto values=static_cast<const float*>(output.mapped);
        if(reference.empty())reference.assign(values,values+count*4);
        std::size_t skipped=0;
        for(unsigned i=0;i<count;++i){
            if(std::memcmp(values+i*4,reference.data()+i*4,3*sizeof(float)))throw std::runtime_error("Direct specular RGB bit patterns differ from the independent expression");
            if(values[i*4+3]==0)++skipped;
        }
        if(mode==1&&skipped!=count/2)throw std::runtime_error("Zero-contribution half vectors must execute no specular work");
        std::array<std::uint64_t,2*iterations> ticks{};
        test::vkRequire(vkGetQueryPoolResults(host.device,queries,0,2*iterations,sizeof(ticks),ticks.data(),8,VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT),"Read direct response timestamps");
        const auto mask=host.timestampBits>=64?std::numeric_limits<std::uint64_t>::max():(std::uint64_t{1}<<host.timestampBits)-1;
        std::vector<double> milliseconds;double total=0;
        for(unsigned i=warmup;i<iterations;++i){double ms=double((ticks[2*i+1]-ticks[2*i])&mask)*host.properties.limits.timestampPeriod*1e-6;milliseconds.push_back(ms);total+=ms;}
        rows.push_back({{"mode",mode},{"meanMs",total/samples},{"milliseconds",milliseconds},{"skippedResponses",skipped}});
    }
    const double before=rows[0]["meanMs"],candidate=rows[1]["meanMs"],after=rows[2]["meanMs"],mean=(before+after)/2;
    std::cout<<nlohmann::json{{"device",host.properties.deviceName},{"cases",count},{"bitExact",true},{"roles",rows},{"reductionFraction",1-candidate/mean},{"driftFraction",std::abs(before-after)/mean},{"scope","Independent coherent and mixed zero-cosine inputs; native incidence fraction remains unmeasured"}}.dump()<<'\n';
    cleanup.reset();if(host.errors||host.allocator.statistics().liveBuffers||host.allocator.statistics().liveImages)throw std::runtime_error("Validation or resource release failed");
    return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
