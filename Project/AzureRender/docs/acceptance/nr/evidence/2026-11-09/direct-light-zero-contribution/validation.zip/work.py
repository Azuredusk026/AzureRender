from pathlib import Path
import os,sys,json,subprocess,time
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
os.environ.update(managed_environment(o/'tmp'))
mode=sys.argv[-1]
if '--inside' not in sys.argv:
 os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 result=guarded_run(r/'build',o.name,[str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',mode],600)
 (o/(mode+'-execution.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result));raise SystemExit(result['exitCode'])
b=r/'build/ninja-msvc-release'
with (o/(mode+'-build.log')).open('wb') as log:
 subprocess.run(['cmake','--build',str(b),'--target','AzureDirectLightResponseGpuTests','-j','3'],stdout=log,stderr=subprocess.STDOUT,check=True)
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['VK_INSTANCE_LAYERS']='VK_LAYER_KHRONOS_validation';os.environ['VK_LAYER_VALIDATE_SYNC']='1';os.environ['VK_LOADER_DEBUG']='error,layer';os.environ.pop('VK_LAYER_ENABLES',None)
for k in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(k,None)
command=[str(b/'AzureDirectLightResponseGpuTests.exe'),str(b/'shaders/direct_light_response_reference.comp.spv'),str(b/'shaders/direct_light_response_candidate.comp.spv')]
p=subprocess.run(command,capture_output=True);(o/(mode+'-test.log')).write_bytes(p.stdout+p.stderr)
if mode=='red':assert p.returncode==1 and b'Zero-contribution half vectors' in p.stderr
else:assert p.returncode==0,p.stderr.decode(errors='replace')
print('phase',mode,'actual exit',p.returncode,flush=True)
