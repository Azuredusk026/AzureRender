from pathlib import Path
import json,hashlib,subprocess,shutil,sys,zipfile
r=Path.cwd().resolve();o=r/'build/runs/20261109-163438-direct-light-zero-contribution-eb9674';sys.path.insert(0,str(r/'tools'))
from build_provenance import verify,digest
from artifact_maintenance import write_json,tracked_paths
from artifact_cleanup import remove_artifact
source=['CMakeLists.txt','shaders/direct_light_response_test.comp','shaders/direct_light_response.glsl','tests/DirectLightResponseGpuTests.cpp']
for rel in source:
 p=o/'candidate-source'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,p)
(o/'candidate.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','CMakeLists.txt']))
data=json.loads((o/'green-results.json').read_text());assert data['bitExact'] and data['reductionFraction']<.2
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
ph=lambda:hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest()
assert ph()=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
subprocess.run(['git','restore','--source=HEAD','--','CMakeLists.txt'],check=True)
for rel in source[1:]:
 p=(r/rel).resolve();assert p.is_relative_to(r/'shaders') or p.is_relative_to(r/'tests');assert not subprocess.check_output(['git','ls-files','--',rel]).strip();p.unlink()
tracked=tracked_paths(r);before=shutil.disk_usage(r).free;targets=[];b=r/'build/ninja-msvc-release'
for suffix in ['.exe','.pdb','.ilk']:targets.append(b/('AzureDirectLightResponseGpuTests'+suffix))
targets.append(b/'CMakeFiles/AzureDirectLightResponseGpuTests.dir')
for name in ['reference','candidate']:targets.append(b/f'shaders/direct_light_response_{name}.comp.spv')
removed=[]
for p in targets:
 if p.exists():removed.append(dict(path=str(p.resolve()),removed=remove_artifact(r/'build',p,tracked,apply=True)))
for config in ['release','debug']:verify(r,json.loads((r/f'build/ninja-msvc-{config}/build-provenance.json').read_text()))
assert ph()=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
result=dict(status='rejected-local-efficiency-and-restored',baselineCommit='7cc4cde',local=data,efficiencyGate=dict(minimumReductionFraction=.2,maximumReferenceDrift=.03,passed=False),nativeCaptures=0,nativeCostProcesses=0,primaryManifestsVerified=True,allOriginal675ProgramsRestored=True,protectedDiffSha256=ph(),formalPerformancePassed=False,overallVisualAcceptance='failed-user-review')
write_json(o/'results.json',result)
write_json(o/'cleanup.json',dict(removed=removed,freeBefore=before,freeAfter=shutil.disk_usage(r).free,observedFreedBytes=shutil.disk_usage(r).free-before))
print('Local gate failed; production sources and both primary manifests restored. Native executions: zero.')
