from pathlib import Path
import json,sys,hashlib,zipfile,shutil
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from build_provenance import verify,digest
from artifact_maintenance import write_json,tracked_paths
from artifact_cleanup import remove_artifact
for config in ['release','debug']:verify(r,json.loads((r/f'build/ninja-msvc-{config}/build-provenance.json').read_text()))
for rel in ['docs/plans/2026-11-09-direct-light-zero-contribution.md','docs/acceptance/nr/direct-light-zero-contribution.md']:
 p=o/'documentation'/Path(rel).name;p.parent.mkdir(exist_ok=True);shutil.copyfile(r/rel,p)
dest=r/'docs/acceptance/nr/evidence/2026-11-09/direct-light-zero-contribution';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
selected=[p for p in sorted(o.rglob('*')) if p.is_file() and 'tmp' not in p.relative_to(o).parts and p.suffix in ['.py','.json','.log','.cpp','.glsl','.comp','.patch','.txt','.md','.spv']]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in selected:z.write(p,p.relative_to(o).as_posix())
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in selected:assert hashlib.sha256(z.read(p.relative_to(o).as_posix())).hexdigest()==digest(p)
d=json.loads((o/'results.json').read_text());d['package']=dict(path=archive.relative_to(r).as_posix(),sha256=digest(archive),bytes=archive.stat().st_size,files=len(selected));write_json(dest/'results.json',d)
shutil.copyfile(o/'cleanup.json',dest/'cleanup.json')
p=o/'tmp'
if p.exists():remove_artifact(r/'build',p,tracked_paths(r),apply=True)
p=r/'docs/plans/2026-11-09-direct-light-zero-contribution.md';p.write_text(p.read_text().replace('- [ ] 同步结果','- [x] 同步结果'),encoding='utf-8')
print(json.dumps(d['package'],indent=2))
