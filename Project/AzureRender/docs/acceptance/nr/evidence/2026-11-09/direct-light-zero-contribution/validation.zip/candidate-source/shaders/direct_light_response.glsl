#ifndef AZURE_DIRECT_LIGHT_RESPONSE_GLSL
#define AZURE_DIRECT_LIGHT_RESPONSE_GLSL
#ifndef AZURE_DIRECT_LIGHT_WORK
#define AZURE_DIRECT_LIGHT_WORK()
#endif
// Both existing specular models have exactly zero energy at zero incidence.
// Keep the positive-incidence expression and its operation order intact.
vec3 directLightSpecular(vec3 f0,float roughness,float nl,float nv,
    vec3 normal,vec3 light,vec3 view,bool microfacet,float power) {
    if(nl==0.0)return vec3(0.0);
    AZURE_DIRECT_LIGHT_WORK();
    vec3 halfDirection=normalize(light+view);
    float specular=pow(max(dot(normal,halfDirection),0.0),power);
    return microfacet?directSurfaceSpecular(f0,roughness,nl,nv,
        max(dot(normal,halfDirection),0.0),max(dot(view,halfDirection),0.0))
        :f0*specular*nl*mix(0.7,0.12,roughness);
}
#endif
