from pathlib import Path
import os,sys,json,hashlib,zipfile,shutil,subprocess
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,tracked_paths,write_json,guarded_run
from artifact_cleanup import remove_artifact
from build_provenance import verify,digest
os.environ.update(managed_environment(o/'tmp'))
scope=json.loads((o/'scope.json').read_text());report={k:v for k,v in scope.items() if k not in ['rows','dynamicResources']};report.update(dynamicResourceCount=len(scope['dynamicResources']),status='policy-passed-runtime-not-integrated',newNativeImageProcesses=0,newFullFramePerformanceProcesses=0,newFullAssetCopies=0,builds={})
for config in ['release','debug']:
 b=r/('build/ninja-msvc-'+config);p=b/'build-provenance.json';m=json.loads(p.read_text());verify(r,m);shutil.copyfile(p,o/(config+'-build-provenance.json'))
 old=json.loads((r/'build/runs/20261109-204632-shadow-history-resources-c5dae1'/(config+'-build-provenance.json')).read_text())
 selected={path:sha for path,sha in old['products'].items() if Path(path).parent.name=='shaders' or Path(path).name in ['AzurePlayer.exe','AzureRender.exe','AzureGeometryCompiler.exe']}
 assert len(selected)==681
 for path,sha in selected.items():assert m['products'][path]==sha,path
 result=guarded_run(r/'build',o.name,[str(b/'AzureShadowHistoryPolicyTests.exe')],120);(o/(config+'-primary.log')).write_bytes((o/'process.log').read_bytes());write_json(o/(config+'-primary-execution.json'),result);assert result['exitCode']==0
 report['builds'][config]=dict(verified=True,primaryPolicyPassed=True,originalShaderCount=678,shaderAndRuntimeHashesUnchanged=True,sourceCount=len(m['source']))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
report['protectedDiffSha256']=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest();assert report['protectedDiffSha256']=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
report['policyChecks']=dict(projectedInteriorPoints=4096,unsubmittedFramesRejected=True,finiteBitwiseViews=True,boundedTriangleRanges=True,invalidProjectionFullFallback=True)
write_json(o/'results.json',report);dest=r/'docs/acceptance/nr/evidence/2026-11-09/shadow-history-runtime-scope';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
selected=[p for p in sorted(o.iterdir()) if p.is_file() and p.suffix in ['.py','.json','.log']]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in selected:z.write(p,p.name)
assert archive.stat().st_size<8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in selected:assert hashlib.sha256(z.read(p.name)).hexdigest()==digest(p)
report['package']=dict(bytes=archive.stat().st_size,files=len(selected),sha256=digest(archive));write_json(dest/'results.json',report)
before=shutil.disk_usage(r).free;tracked=tracked_paths(r);removed=[]
for p in [o/'tmp',o/'__pycache__',o/'policy.exe',o/'policy.obj']:
 if p.exists():
  assert p.resolve().is_relative_to(o.resolve());removed.append(dict(path=str(p.resolve()),removed=remove_artifact(r/'build',p,tracked,apply=True)))
after=shutil.disk_usage(r).free;write_json(o/'cleanup.json',dict(removed=removed,freeBefore=before,freeAfter=after,observedFreedBytes=after-before));print(json.dumps(dict(package=report['package'],observedFreedBytes=after-before)))
