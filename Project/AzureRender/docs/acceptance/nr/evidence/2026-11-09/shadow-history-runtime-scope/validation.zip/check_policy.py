from pathlib import Path
import os,sys,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
os.environ.update(managed_environment(o/'tmp'));os.environ.update(VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg')
mode=sys.argv[1];config=sys.argv[2] if len(sys.argv)>2 else 'Release';stem=mode+'-'+config.lower();binary=o/'policy.exe'
command=[str(r/'tools/msvc_env.bat'),'cl.exe','/nologo','/std:c++17','/EHsc','/W4','/WX','/utf-8','/O2' if config=='Release' else '/Od','/I'+str(r/'src'),'/I'+os.environ['VULKAN_SDK']+'/Include',str(r/'tests/ShadowHistoryPolicyTests.cpp'),'/Fo'+str(o/'policy.obj'),'/Fe'+str(binary),'/link','/INCREMENTAL:NO']
result=guarded_run(r/'build',o.name,command,120);(o/(stem+'-compile.log')).write_bytes((o/'process.log').read_bytes());assert result['exitCode']==0,(o/'process.log').read_text(errors='replace')
result=guarded_run(r/'build',o.name,[str(binary)],120);(o/(stem+'.log')).write_bytes((o/'process.log').read_bytes());(o/(stem+'-execution.json')).write_text(json.dumps(result,indent=2));print(result);print((o/'process.log').read_text(errors='replace'));assert result['exitCode']==(1 if mode.startswith('red') else 0)
