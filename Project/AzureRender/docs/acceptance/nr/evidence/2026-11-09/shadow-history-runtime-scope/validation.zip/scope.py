from pathlib import Path
import json,struct,collections,sys,hashlib
r=Path.cwd().resolve();o=Path(__file__).resolve().parent
p=r/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4'
lock=json.loads((r/'build/runs/20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text())
scene=json.loads((p/'scene/joint-dynamic-loop-v2.azurelevel').read_text())
mounts={m['name']:(p/m['path']).resolve() for m in json.loads((p/'joint-materials.azureproject').read_text())['mounts']}
registry={}
for name in lock:
 path=Path(name)
 if path.suffix=='.azmeta':
  meta=json.loads(path.read_text());registry[meta.get('id',meta.get('guid'))]=Path(str(path)[:-7])
print('registry',len(registry),'sample',list(registry.items())[:1])
nodes=collections.Counter(n['resourceId'] for n in scene['nodes'] if n.get('resourceId') and n.get('components',{}).get('azure.renderable',{}).get('data',{}).get('visible',True))
rows=[]
for resource in scene['resources']:
 path=registry.get(resource.get('asset'))
 if path is None and ':/' in resource.get('asset',''):
  mount,relative=resource['asset'].split(':/',1);path=mounts[mount]/relative
 if path is None:raise RuntimeError(('Unresolved resource',resource))
 if path.suffix=='.glb':
  with path.open('rb') as stream:
   header=stream.read(20);magic,version,total,size,kind=struct.unpack('<5I',header);assert magic==0x46546c67 and version==2 and kind==0x4e4f534a
   assert size<16*1024*1024;data=json.loads(stream.read(size))
 elif path.suffix=='.gltf':data=json.loads(path.read_text())
 else:raise RuntimeError(path)
 primitives=[v for m in data.get('meshes',[]) for v in m['primitives']]
 indices=sum(data['accessors'][v['indices']]['count'] for v in primitives if 'indices' in v)
 reasons=[]
 if data.get('skins'):reasons.append('skin')
 if data.get('animations'):reasons.append('animation')
 if any(v.get('targets') for v in primitives):reasons.append('morph')
 rows.append(dict(id=resource['id'],path=str(path.relative_to(p)),instances=nodes[resource['id']],indices=indices,primitives=len(primitives),dynamicReasons=reasons))
report=dict(status='metadata-scope-only',resources=len(rows),visibleMeshInstances=sum(nodes.values()),staticResources=sum(not x['dynamicReasons'] for x in rows),staticInstances=sum(x['instances'] for x in rows if not x['dynamicReasons']),dynamicResources=[x for x in rows if x['dynamicReasons']],staticTriangleKeyRange=sum(x['indices']*x['instances'] for x in rows if not x['dynamicReasons']),allInstanceIndices=sum(x['indices']*x['instances'] for x in rows),materialEligibilityMeasured=False,actualScreenCoverageMeasured=False,sourceLevelSha256=hashlib.sha256((p/'scene/joint-dynamic-loop-v2.azurelevel').read_bytes()).hexdigest(),rows=rows)
(o/'scope.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
