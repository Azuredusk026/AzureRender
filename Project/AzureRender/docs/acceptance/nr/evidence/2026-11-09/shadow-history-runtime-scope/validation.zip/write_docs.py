from pathlib import Path
import os
r=Path.cwd().resolve()
def write(name,text):
 p=r/name;q=p.with_name(p.name+'.tmp');q.write_text(text,encoding='utf-8');os.replace(q,p)
write('docs/acceptance/nr/shadow-history-runtime-scope.md','''# 阴影历史资格与失效策略

日期：2026-11-09。
状态：元数据范围及公共策略通过，运行时接入待完成。

## 资源范围

冻结关卡引用 374 项网格资源。
871 个可见实例中，860 个未声明骨骼、动画或形变。
其余十一项资源包含角色和动态物流几何。
静态实例需要的索引身份范围为 1354227。

以上数量依据关卡、资产标识及 glTF 元数据。
该静态范围属于接收资格的上界。
材质、运行时变换和实际屏幕覆盖继续由渲染器核对。
该范围支持继续接入，帧收益仍待测量。

## 公共策略

`ShadowHistoryPrimitiveRanges` 分配无碰撞三角形范围。
空范围、未对齐索引及容量溢出采用无效哨兵。
`ShadowHistoryViewIdentity` 核对输入位模式和资源代次。
历史资格只在写入命令提交后由调用方确认。

视图输入包含影响阴影的采样、光源及静态内容。
无效输入、跳过提交及显式取消均中断历史链。
调用方分别维护不同工作流的状态。
GPU 可见性依赖历史资源的显式同步。

动态边界投影覆盖盒体八个角点。
投影保留浮点运算误差及栅格边界余量。
前后位置的投影区域合并后参与过滤足迹核对。
无效投影、溢出及未知过滤足迹采用完整求值。

## 验证与边界

首轮红测复现身份分配接口的缺失。
生命周期红测复现未提交帧错误建立历史资格。
最终检查覆盖正交与透视投影的 4096 个内部点。
两配置核对身份、位模式、失效及最大过滤范围。

本单元的原生图像与整帧性能进程均为零。
生产渲染路径尚未消费该策略。
正式画面、CPU 与 GPU 预算保持现有标准。
整体状态仍为 `failed-user-review`。

接续见[实施计划](../../plans/2026-11-09-temporal-shadow-history.md)。
[结果清单](evidence/2026-11-09/shadow-history-runtime-scope/results.json)
与[精简证据](evidence/2026-11-09/shadow-history-runtime-scope/validation.zip)保存范围和检查记录。
''')
p='docs/plans/2026-11-09-temporal-shadow-history.md';s=(r/p).read_text();s=s.replace('- [ ] 根据实际静态范围决定运行时接入规模。','- [x] 核定元数据静态范围与公共失效策略。\n- [ ] 接入材质资格、实际动态边界和历史读写。');s+='''
## 实际范围与失效策略

871 个可见网格实例中，860 个具备静态元数据。
三角形身份范围约为一百三十五万，容量检查通过。
材质资格及屏幕命中比例继续在运行时核对。
范围见[资格与失效策略](../acceptance/nr/shadow-history-runtime-scope.md)。

视图按输入位模式核对，成功提交后确认历史资格。
投影按浮点误差界覆盖动态几何的前后位置。
资源代次、跳过提交及未知投影均触发完整求值。
实际历史读写接入后集中执行严格四帧与净收益检查。
''';write(p,s)
p='docs/plans/azure-engine-plan.md';s=(r/p).read_text().replace('后续接入实际失效范围，完整场景收益仍待验收。','[实际静态范围与策略](../acceptance/nr/shadow-history-runtime-scope.md)完成元数据及失效契约核对。\n后续接入运行时历史读写，完整场景收益仍待验收。');write(p,s)
p='README.md';s=(r/p).read_text().replace('[阴影历史资源]', '[历史资格策略](docs/acceptance/nr/shadow-history-runtime-scope.md)覆盖身份、投影误差和提交失效，实际读写继续接入。\n[阴影历史资源]');write(p,s)
