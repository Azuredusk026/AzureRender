from pathlib import Path
import json,sys,zipfile,xml.etree.ElementTree as ET
r=Path.cwd().resolve();o=r/'build/runs/20261109-015039-sparse-consumer-attribution-e39118';sys.path.insert(0,str(r/'tools'));from build_provenance import digest,verify
cases=[]
for name in ['nvidia.xml','intel.xml','precision-debug-nvidia.xml','precision-debug-intel.xml','release-default.xml','debug-default.xml']:
 for c in ET.parse(o/name).getroot().findall('testcase'):
  assert c.find('failure') is None;cases.append(dict(receipt=name,name=c.attrib['name'],skipped=c.find('skipped') is not None))
for config in ['release','debug']:
 b=r/('build/ninja-msvc-'+config);verify(r,json.loads((b/'build-provenance.json').read_text()));baseline=json.loads((o/(config+'-baseline-shaders.json')).read_text());assert {p.name:digest(p) for p in (b/'shaders').glob('*.spv')}==baseline and len(baseline)==674
native=json.loads((o/'native-metadata/results.json').read_text());s=native['statistics'];assert s['frames']==30 and s['sampleSpacing']==32 and native['validationTextClean'] and native['zeroAllocator']
fail=s['failureSamples'];analysis=dict(storedRecords=len(fail),pixelFailures=sum(x[0]==2 for x in fail),quadFailures=sum(x[0]==3 for x in fail),modeFailures=sum(x[0]==1 for x in fail),pixelFailuresWithSameInstanceAndMaterialDifferentPrimitiveAndFartherDepth=sum(x[0]==2 and x[5]==x[9] and x[7]==x[11] and x[6]!=x[10] and x[4]>x[8] for x in fail),scope='Last completed slot, first bounded records; ordering is not representative of all failures',quadToProducerInvocationRatio=s['quadMatches']/s['producerStores'])
assert analysis['pixelFailures']==15 and analysis['pixelFailuresWithSameInstanceAndMaterialDifferentPrimitiveAndFartherDepth']==15
(o/'failure-analysis.json').write_text(json.dumps(analysis,indent=2))
cleanup=[json.loads((o/n).read_text()) for n in ['release-program-cleanup.json','debug-program-cleanup.json','disabled-tests-cleanup.json']]
sources=['CMakeLists.txt','shaders/surface_radiance.glsl','shaders/surface_radiance_statistics.glsl','shaders/surface_radiance_probe.frag','src/render/SurfaceRadianceCache.cpp','src/render/SurfaceRadianceCache.hpp','src/scenes/CharacterMaterialSampling.inc','src/scenes/CharacterSceneRenderer.cpp','tests/SurfaceRadianceCacheGpuTests.cpp','tests/SurfaceRadianceStatisticsTests.cpp']
f=r/'docs/acceptance/nr/evidence/2026-11-09/sparse-consumer-attribution';f.mkdir(parents=True,exist_ok=True)
paths=[p for p in o.glob('*') if p.suffix in ['.json','.log','.xml','.py']]+[p for p in (o/'native-metadata').glob('*') if p.is_file()]+[o/('view-'+d)/(d+'-summary.json') for d in ['nvidia','intel']]
with zipfile.ZipFile(f/'validation.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for p in sorted(set(paths)):z.write(p,p.relative_to(o).as_posix())
assert (f/'validation.zip').stat().st_size<8*1024*1024
report=dict(sourceBase='db55c51d7db89807122ec69f7498472506b71ee9',status='attribution-completed-default-disabled',tests=cases,passed=sum(not c['skipped'] for c in cases),skipped=sum(c['skipped'] for c in cases),native=native,failureAnalysis=analysis,sourceHashes={p:digest(r/p) for p in sources},unchangedDefaultPrograms=674,unchangedNormalExperimentalPrograms=744,experimentalOptionsDefaultOff=True,cleanup=dict(files=sum(x['files'] for x in cleanup),logicalBytes=sum(x['logicalBytes'] for x in cleanup)),formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceZipBytes=(f/'validation.zip').stat().st_size,evidenceZipSha256=digest(f/'validation.zip'))
(f/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
p=r/'docs/development/artifact-manifest.json';d=json.loads(p.read_text());d['milestones'].insert(0,dict(path='runs/'+o.name,name='稀疏照明消费归因',status='AttributionCompletedDefaultDisabled',sourceBase='db55c51',evidence='docs/acceptance/nr/sparse-consumer-attribution.md',checksPassed=report['passed'],checksSkipped=report['skipped'],nativeProcesses=1,renderedFrames=32,capturedFrames=0,reclaimedFiles=report['cleanup']['files'],formalPerformancePassed=False));p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ['passed','skipped','cleanup','evidenceZipBytes']}))
