from pathlib import Path
import os,sys,subprocess,json
r=Path.cwd();o=Path(__file__).resolve().parent;(o/'tmp').mkdir(exist_ok=True);e=os.environ.copy();e.update(TEMP=str(o/'tmp'),TMP=str(o/'tmp'),TMPDIR=str(o/'tmp'),VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',VCPKG_ROOT='D:/Tools/vcpkg')
with (o/'red-build.log').open('wb') as log:p=subprocess.run([str(r/'tools/msvc_env.bat'),'cmake','--build',str(r/'build/ninja-msvc-release'),'--target','AzureSurfaceRadianceStatisticsTests','-j','3'],env=e,stdout=log,stderr=subprocess.STDOUT,timeout=120)
s=(o/'red-build.log').read_text(errors='replace');assert p.returncode and 'SurfaceRadianceCache' in s
(o/'red.json').write_text(json.dumps(dict(exitCode=p.returncode,missingDiagnosticRecordContract=True),indent=2));print('Missing bounded diagnostic record contract reproduced')
