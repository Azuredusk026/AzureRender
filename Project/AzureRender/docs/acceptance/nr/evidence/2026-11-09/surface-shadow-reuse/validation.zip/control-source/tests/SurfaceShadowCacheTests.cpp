#include "render/SurfaceRadianceCache.hpp"
#include "rhi/NullRhi.hpp"
#include <iostream>
using namespace azurerender;
void require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
int main()try{
 using Payload=SurfaceRadianceCache::Payload;rhi::NullRhi backend;
 require(SurfaceRadianceCache::supported(backend,{3840,2160},2,SurfaceRadianceCache::kMaximumBytes,Payload::ShadowVisibility),"Shadow payload fits the full-precision byte limit");
 require(!SurfaceRadianceCache::supported(backend,{UINT32_MAX,UINT32_MAX},8,SurfaceRadianceCache::kMaximumBytes,Payload::ShadowVisibility),"Shadow budget multiplication cannot overflow");
 {SurfaceRadianceCache cache(backend,{64,48},2,SurfaceRadianceCache::kMaximumBytes,false,false,0,0,Payload::ShadowVisibility);
  require(cache.attachmentCount()==2&&cache.bytes()==64ULL*48*20*2,"Shadow payload uses exactly twenty bytes per pixel");
  require(cache.attachmentFormat(0)==VK_FORMAT_R32_SFLOAT&&cache.attachmentFormat(1)==VK_FORMAT_R32G32B32A32_UINT,"Exact scalar and complete identity formats");
  require(cache.attachmentClearValue(1).color.uint32[2]==UINT32_MAX,"Unwritten pixels reject reuse");
  require(cache.texture(0,0).image.image!=cache.texture(1,0).image.image,"Frame slots have distinct ownership");
  bool rejected=false;try{cache.texture(0,2);}catch(const std::out_of_range&){rejected=true;}require(rejected,"Inactive attachments are inaccessible");
  require(backend.allocator().statistics().liveImages==4,"Two attachments per slot");
 }
 require(backend.allocator().statistics().liveImages==0,"All images release");
 backend.unavailableSampledFormats.insert(VK_FORMAT_R32_SFLOAT);
 require(!SurfaceRadianceCache::supported(backend,{64,48},2,SurfaceRadianceCache::kMaximumBytes,Payload::ShadowVisibility),"Missing scalar format rejects before allocation");
 backend.unavailableSampledFormats.clear();bool rejected=false;
 try{SurfaceRadianceCache cache(backend,{64,48},2,SurfaceRadianceCache::kMaximumBytes,false,true,1,0,Payload::ShadowVisibility);}catch(const std::invalid_argument&){rejected=true;}
 require(rejected&&backend.allocator().statistics().liveImages==0,"Draw selection belongs to the radiance payload");
 std::cout<<"Shadow payload formats, bounded size, invalid combinations and frame lifetime passed\n";
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
