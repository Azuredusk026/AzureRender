#if defined(AZURE_SURFACE_SHADOW_CACHE)
#include "surface_radiance_identity.glsl"
#include "surface_radiance_statistics.glsl"
#if !defined(AZURE_SURFACE_SHADOW_PROBE)
layout(location=15,component=1) flat in uvec2 surfaceShadowSource;
#endif
#if defined(AZURE_OPAQUE_SNAPSHOT)
layout(location=2) out float outputSurfaceShadow;
layout(location=3) out uvec4 outputSurfaceShadowIdentity;
#else
layout(binding=38) uniform sampler2D surfaceShadowValue;
layout(binding=39) uniform usampler2D surfaceShadowIdentity;
bool azureLoadSurfaceShadow(ivec2 pixel,uvec4 requested,out float visibility){
 visibility=2.0;
#if defined(AZURE_SURFACE_RADIANCE_DIAGNOSTICS)
 azureRadianceCount(1u);azureRadianceCount(2u);
#endif
 ivec2 extent=textureSize(surfaceShadowIdentity,0);
 if(requested.z==0xffffffffu||any(lessThan(pixel,ivec2(0)))||any(greaterThanEqual(pixel,extent)))return false;
 uvec4 stored=texelFetch(surfaceShadowIdentity,pixel,0);
 if(any(notEqual(requested,stored)))return false;
 float value=texelFetch(surfaceShadowValue,pixel,0).r;
 if((floatBitsToUint(value)&0x7f800000u)==0x7f800000u)return false;
 if(!(value>=0.0&&value<=1.0))return false;
 visibility=value;
#if defined(AZURE_SURFACE_RADIANCE_DIAGNOSTICS)
 azureRadianceCount(3u);
#endif
 return true;
}
#endif
#endif
