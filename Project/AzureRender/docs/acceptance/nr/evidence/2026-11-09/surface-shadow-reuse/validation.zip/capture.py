from pathlib import Path
import os,sys,json,time,shutil
import numpy as np
from PIL import Image
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';sys.path.insert(0,str(root/'tools'))
from task_environment import apply;apply(out)
from build_provenance import inputs,digest,verify
from artifact_maintenance import guarded_run
verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
assert json.loads((out/'workload-gate.json').read_text())['gatePassed']
checks=json.loads((out/'checks.json').read_text());assert len(json.loads((out/'check-cases.json').read_text()))==28 and all(row.get('exitCode',row.get('execution',{}).get('exitCode'))==0 for row in checks)
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}
lock=json.loads((out.parent/'20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text());assert all(digest(Path(p))==sha for p,sha in lock.items())
reference=out.parent/'20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint'
folder=out/'image-shadow-reuse';folder.mkdir(exist_ok=True);frames=folder/('frames-'+time.strftime('%H%M%S'));assert not frames.exists()
command=json.loads((reference/'command.json').read_text());command[0]=str(build/'AzurePlayer.exe');command[command.index('--capture-dir')+1]=str(frames);command[command.index('--runtime-report')+1]=str(folder/'runtime.json')
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
os.environ['VK_INSTANCE_LAYERS']='VK_LAYER_KHRONOS_validation'
os.environ['VK_LAYER_ENABLES']='VK_VALIDATION_FEATURE_ENABLE_SYNCHRONIZATION_VALIDATION_EXT';os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['TEMP','TMP','TMPDIR','SQLITE_TMPDIR']:os.environ[key]=str(out/'tmp')
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','AZURE_CPU_WORK_REPORT']:os.environ.pop(key,None)
shutil.copyfile(build/'build-provenance.json',folder/'build-provenance.json')
(folder/'source-before.json').write_text(json.dumps(before,indent=2))
(folder/'products-before.json').write_text(json.dumps(products,indent=2))
(folder/'command.json').write_text(json.dumps(command,indent=2));execution=guarded_run(root/'build',out.name,command,600)
(folder/'execution.json').write_text(json.dumps(execution,indent=2));assert execution['status']=='exited' and execution['exitCode']==0,execution
rows=[]
for path in sorted(frames.glob('frame_*.png')):
 actual=np.asarray(Image.open(path).convert('RGB'));expected=np.asarray(Image.open(reference/'frames'/path.name).convert('RGB'));delta=np.abs(actual.astype('i2')-expected.astype('i2'));ys,xs=np.where(np.any(delta,axis=2))
 points=[dict(x=int(x),y=int(y),expected=expected[y,x].tolist(),actual=actual[y,x].tolist()) for y,x in zip(ys[:32],xs[:32])]
 rows.append(dict(frame=path.name,sha256=digest(path),referenceSha256=digest(reference/'frames'/path.name),changedPixels=int(len(xs)),maximumByteDifference=int(delta.max()),firstChangedPoints=points))
log=(out/'process.log').read_text(errors='replace');(folder/'process.log').write_text(log)
manifest=json.loads((frames/'capture_manifest.json').read_text());metadata={k:v for k,v in manifest.items() if k.startswith(('conservativeOcclusion','defaultIsolation','surfaceRadiance','computeSkinning','shadowBounds','surfaceShadow')) or k in ['mainDepthSplitRecorded','vertexCapacity']}
report=dict(execution=execution,frames=rows,metadata=metadata,sourceInputsUnchanged=inputs(root)==before,productsUnchanged=all(digest(Path(p))==sha for p,sha in products.items()),projectInputsUnchanged=all(digest(Path(p))==sha for p,sha in lock.items()),validationLogClean=not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-']),zeroAllocator='Allocator after unload: buffers=0 images=0' in log,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review')
(folder/'results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
assert metadata['surfaceRadiancePrepared'] and metadata['surfaceShadowReusePrepared'] and metadata['surfaceShadowVariantModules']>0 and metadata['surfaceRadianceStatistics']['pixelMatches']>0 and metadata['computeSkinningVertexWords']==10 and metadata['shadowBoundsTilesPerGroup']==8
assert metadata['computeSkinningOutputBytes']==metadata['vertexCapacity']*40*2
assert len(rows)==4 and all(r['changedPixels']==0 for r in rows) and metadata['conservativeOcclusionPrepared']
assert all(report[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationLogClean','zeroAllocator'])
