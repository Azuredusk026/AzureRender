from pathlib import Path
import os,subprocess,sys,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',TEMP=str(o/'tmp'),TMP=str(o/'tmp'),TMPDIR=str(o/'tmp'),SQLITE_TMPDIR=str(o/'tmp'),VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],env=env).returncode)
rows=[]
for c in ['release','debug']:
 command=['cmake','--build',str(r/('build/ninja-msvc-'+c)),'--target','AzureSurfaceShadowViewGpuTests','--parallel','3']
 with (o/(c+'-fixture-build.log')).open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(configuration=c,command=command,exitCode=p.returncode));assert p.returncode==0
(o/'fixture-build.json').write_text(json.dumps(rows,indent=2));print(rows)
