from pathlib import Path
import json,sys,hashlib,zipfile
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from build_provenance import inputs,verify
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((o/'release-baseline-provenance.json').read_text());assert inputs(r)==proof['source']
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);verify(r,json.loads((b/'build-provenance.json').read_text()));assert {p.name:digest(p) for p in (b/'shaders').glob('*.spv')}==json.loads((o/(c+'-baseline-shaders.json')).read_text())
diagnostic=json.loads((o/'cost-results-v1.json').read_text());control=json.loads((o/'cost-control-results.json').read_text());assert diagnostic['gpuSavedMs']<0 and control['gpuSavedMs']<0
cases=json.loads((o/'diagnostic-check-cases.json').read_text());other=json.loads((o/'control-check-cases.json').read_text());restored=json.loads((o/'restoration-checks.json').read_text());assert len(cases)==28 and len(other)==8 and restored['passed']==6
images={name:json.loads((o/name/'results.json').read_text()) for name in ['image-shadow-reuse','image-shadow-reuse-control']}
assert all(len(d['frames'])==4 and all(x['changedPixels']==0 and x['sha256']==x['referenceSha256'] for x in d['frames']) and d['validationLogClean'] and d['zeroAllocator'] for d in images.values())
cleanup=[json.loads((o/n).read_text()) for n in ['release-experimental-cleanup.json','debug-experimental-cleanup.json','runtime-and-images-cleanup.json']];assert all(x['status']=='applied' for x in cleanup)
assert not (o/'baseline-runtime').exists()
f=r/'docs/acceptance/nr/evidence/2026-11-09/surface-shadow-reuse';f.mkdir(parents=True,exist_ok=True)
paths=[p for p in o.iterdir() if p.is_file() and (p.suffix in ['.json','.log','.xml','.py','.patch'] or p.name=='finite-lookup.comp.spv')]
for name in ['control-source','diagnostic-source','control-programs','diagnostic-programs']:
 paths.extend(p for p in (o/name).rglob('*') if p.is_file())
for folder in [p for p in o.iterdir() if p.is_dir() and (p.name.startswith(('image-shadow-reuse','cost-')) or 'view' in p.name)]:
 for p in folder.rglob('*'):
  if not p.is_file():continue
  if p.name in ['runtime.json','source-before.json','products-before.json','build-provenance.json']:continue
  if p.suffix in ['.json','.log','.csv','.jsonl']:paths.append(p)
with zipfile.ZipFile(f/'validation.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for p in sorted(set(paths)):z.write(p,p.relative_to(o).as_posix())
size=(f/'validation.zip').stat().st_size;assert size<8*1024*1024,size
report=dict(sourceBase='64e7cc36e7689b6202662aaac62a42a777ce3178',status='no-net-gain-entire-candidate-isolated',sourceHashes={},candidateChecks=cases,counterOffChecks=other,restorationChecks=restored,passed=42,skipped=0,canonicalNativeProcesses=2,frameCostProcesses=5,diagnosticCost=diagnostic,counterOffCost=control,nativeImages=images,nativeCoverage=json.loads((o/'native-coverage-gate.json').read_text()),restoration=json.loads((o/'source-restoration.json').read_text()),candidateSource=json.loads((o/'control-source.json').read_text()),diagnosticSource=json.loads((o/'diagnostic-source.json').read_text()),isolatedPrograms=json.loads((o/'isolated-programs.json').read_text()),unchangedDefaultProgramsPerConfiguration=675,cleanup=dict(files=sum(x['files'] for x in cleanup),logicalBytes=sum(x['logicalBytes'] for x in cleanup)),fixtureMetadataNote='The legacy quadCapable field in the reused view harness is its feature-selection boolean; shadow-mode constructors explicitly do not request quad control',formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceZipBytes=size,evidenceZipSha256=digest(f/'validation.zip'))
(f/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
p=r/'docs/development/artifact-manifest.json';d=json.loads(p.read_text());d['milestones'].insert(0,dict(path='runs/'+o.name,name='同帧表面阴影复用',status='NoNetGainCandidateIsolated',sourceBase='64e7cc3',evidence='docs/acceptance/nr/surface-shadow-reuse.md',checksPassed=42,canonicalNativeProcesses=2,frameCostProcesses=5,reclaimedFiles=report['cleanup']['files'],reclaimedLogicalBytes=report['cleanup']['logicalBytes'],formalPerformancePassed=False));p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(passed=42,evidenceBytes=size,cleanup=report['cleanup'])))
