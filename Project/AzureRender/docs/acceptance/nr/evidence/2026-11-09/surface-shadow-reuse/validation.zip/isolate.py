from pathlib import Path
import os,json,hashlib,shutil,subprocess,sys
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((o/'release-baseline-provenance.json').read_text());catalog=json.loads((o/'control-source.json').read_text());assert all(digest(r/n)==h for n,h in catalog.items())
gate=json.loads((o/'cost-control-results.json').read_text());assert gate['gpuSavedMs']<0
shaderCatalog=json.loads((r/'build/ninja-msvc-release/shader-reload.json').read_text());(o/'control-shader-catalog.json').write_text(json.dumps(shaderCatalog,indent=2))
selected=['mesh_object_bindless_clipmap_field_early_shadow_cache.frag.spv','character_snapshot_object_bindless_clipmap_field_early_shadow_cache.frag.spv','mesh_object_bindless_clipmap_field_shadow_cache.frag.spv','character_snapshot_object_bindless_clipmap_field_shadow_cache.frag.spv']
old=json.loads((o/'release-diagnostic-provenance.json').read_text());oldProducts={Path(p).name:h for p,h in old['products'].items()};programs=[]
for name in selected:
 p=r/'build/ninja-msvc-release/shaders'/name;target=o/'control-programs'/name;target.parent.mkdir(exist_ok=True);shutil.copyfile(p,target);programs.append(dict(role='counter-off',path=str(target.relative_to(o)),sha256=digest(target)))
 descriptor=next(x for x in shaderCatalog['programs'] if x['output']==name);target=o/'diagnostic-programs'/name;target.parent.mkdir(exist_ok=True)
 command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe',*['-D'+x for x in descriptor['defines']],'-DAZURE_SURFACE_RADIANCE_DIAGNOSTICS=1','-DAZURE_SURFACE_RADIANCE_SPARSE_DIAGNOSTICS=1',str(r/'shaders/mesh.frag'),'-o',str(target)]
 p=subprocess.run(command,capture_output=True,text=True);assert p.returncode==0,p.stderr;assert digest(target)==oldProducts[name],name
 programs.append(dict(role='diagnostic-reproduced-byte-exact',path=str(target.relative_to(o)),sha256=digest(target),command=command))
baselineShaders=json.loads((o/'release-baseline-shaders.json').read_text())
for p in (r/'build/ninja-msvc-release/shaders').glob('*.vert.spv'):
 if p.name in baselineShaders and digest(p)!=baselineShaders[p.name]:
  target=o/'control-programs'/p.name;shutil.copyfile(p,target);programs.append(dict(role='identity-vertex',path=str(target.relative_to(o)),sha256=digest(target)))
(o/'isolated-programs.json').write_text(json.dumps(programs,indent=2))
restored={};removed=[]
for name in catalog:
 p=r/name
 if subprocess.check_output(['git','ls-files','--',name]).strip():
  raw=subprocess.check_output(['git','show','HEAD:Project/AzureRender/'+name]);expected=proof['source'].get(name)
  variants=[raw,raw.replace(b'\r\n',b'\n'),raw.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')]
  data=next((v for v in variants if hashlib.sha256(v).hexdigest()==expected),None) if expected else raw
  assert data is not None,name;p.write_bytes(data);restored[name]=digest(p)
 else:
  assert digest(p)==catalog[name] and not p.is_symlink();p.unlink();removed.append(name)
sys.path.insert(0,str(r/'tools'));from build_provenance import inputs
assert inputs(r)==proof['source']
(o/'source-restoration.json').write_text(json.dumps(dict(status='restored',sourceInputs=len(proof['source']),sourceHashes=restored,removedCandidateSources=removed,productionEntry='64e7cc36e7689b6202662aaac62a42a777ce3178'),indent=2))
print('Restored original production inputs',len(proof['source']),'isolated programs',len(programs))
