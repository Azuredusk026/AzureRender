from pathlib import Path
import os,sys,subprocess,json,time,hashlib,stat
r=Path.cwd().resolve();o=Path(__file__).resolve().parent
from task_environment import apply
apply(o)
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',*sys.argv[1:]],env=env).returncode)
c=sys.argv[-1];assert c in ['Release','Debug'];b=r/('build/ninja-msvc-'+c.lower());baseline=json.loads((o/(c.lower()+'-baseline-shaders.json')).read_text());cleanup=[];kept=[]
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def unlink(p):
 assert p.resolve().is_relative_to(b.resolve()) and not p.is_symlink()
 for parent in [p,*p.parents]:
  if not parent.exists():continue
  info=parent.lstat();assert not getattr(info,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',1024)
  if parent==b:break
 assert not subprocess.check_output(['git','ls-files','--',str(p.relative_to(r))]).strip()
 cleanup.append(dict(path=str(p),sha256=digest(p),logicalBytes=p.stat().st_size));p.unlink()
start=time.monotonic()
with (o/(c.lower()+'-restored-build.log')).open('wb') as log:
 command=['cmake','-S',str(r),'-B',str(b),'-UAZURE_ENABLE_SURFACE_SHADOW_*'];subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 for p in (b/'shaders').glob('*.spv'):
  if p.name not in baseline:
   assert p.name.endswith('_shadow_cache.frag.spv') or p.name=='surface_shadow_lookup_test.comp.spv';unlink(p)
 for name in ['AzureSurfaceShadowCacheTests','AzureSurfaceShadowLookupGpuTests','AzureSurfaceShadowViewGpuTests']:
  for extension in ['.exe','.pdb']:
   p=b/(name+extension)
   if p.exists():unlink(p)
  p=b/(name+'.ilk')
  if p.exists():kept.append(dict(path=str(p),logicalBytes=p.stat().st_size,reason='ILK exclusion retained under prior cleanup blocking policy'))
  directory=b/'CMakeFiles'/(name+'.dir')
  if directory.exists():
   for p in directory.rglob('*'):
    if p.is_file() and p.suffix.lower() not in ['.ilk']:unlink(p)
   for p in sorted(directory.rglob('*'),key=lambda x:len(x.parts),reverse=True):
    if p.is_dir() and not any(p.iterdir()):p.rmdir()
   if not any(directory.iterdir()):directory.rmdir()
 command=[sys.executable,'-X','utf8','tools/build_provenance.py','build','--build-dir',str(b),'--config',c]
 for target in ['AzureSurfaceRadianceCacheTests','AzureShadowTileBoundsBatchTests','AzureRenderRenderGraphTests']:command+=['--test-target',target]
 p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
(o/(c.lower()+'-restored-build.json')).write_text(json.dumps(dict(exitCode=p.returncode,seconds=time.monotonic()-start,command=command),indent=2))
(o/(c.lower()+'-experimental-cleanup.json')).write_text(json.dumps(dict(status='applied',files=len(cleanup),logicalBytes=sum(x['logicalBytes'] for x in cleanup),items=cleanup,retained=kept),indent=2));print(c,p.returncode,'cleaned',len(cleanup),flush=True);raise SystemExit(p.returncode)
