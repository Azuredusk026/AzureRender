from pathlib import Path
import os,subprocess,json,sys,xml.etree.ElementTree as ET
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from artifact_maintenance import guarded_run
from build_provenance import verify
from task_environment import apply
apply(o);ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';rows=[];cases=[]
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);verify(r,json.loads((b/'build-provenance.json').read_text()))
 command=[ctest,'--test-dir',str(b),'-R',r'^AzureRender\.(SurfaceShadowCache|SurfaceRadianceCache)$','--output-on-failure','--no-tests=error','--output-junit',str(o/(c+'-control.xml'))]
 with (o/(c+'-control.log')).open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=60)
 assert p.returncode==0;rows.append(dict(configuration=c,command=command,exitCode=p.returncode))
 for case in ET.parse(o/(c+'-control.xml')).getroot().findall('testcase'):assert case.find('failure') is None and case.find('skipped') is None;cases.append(dict(configuration=c,name=case.attrib['name']))
b=r/'build/ninja-msvc-release'
for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 os.environ['VK_LOADER_DRIVERS_SELECT']=driver
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
 for kind,command in [('lookup',[str(b/'AzureSurfaceShadowLookupGpuTests.exe'),str(b/'shaders/surface_shadow_lookup_test.comp.spv')]),('view',[str(b/'AzureSurfaceShadowViewGpuTests.exe'),str(b/'shaders'),str(o/('control-'+device+'-view'))])]:
  execution=guarded_run(r/'build',o.name,command,180);log=(o/'process.log').read_text(errors='replace');(o/('control-'+device+'-'+kind+'.log')).write_text(log)
  rows.append(dict(device=device,kind=kind,command=command,execution=execution));(o/'control-checks.json').write_text(json.dumps(rows,indent=2));print(device,kind,execution['exitCode'],flush=True)
  assert execution['status']=='exited' and execution['exitCode']==0,(execution,log[-4000:]);assert not any(x in log for x in ['Validation Error:','SYNC-HAZARD','VUID-'])
  cases.append(dict(configuration='release',device=device,name='shadow-'+kind))
assert len(cases)==8;(o/'control-check-cases.json').write_text(json.dumps(cases,indent=2));print('8 affected counter-off checks passed',flush=True)
