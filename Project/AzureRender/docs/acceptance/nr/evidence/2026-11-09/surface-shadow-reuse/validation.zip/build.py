from pathlib import Path
import os,sys,subprocess,json,time
r=Path.cwd().resolve();o=Path(__file__).resolve().parent
from task_environment import apply;apply(o)
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',TEMP=str(o/'tmp'),TMP=str(o/'tmp'),TMPDIR=str(o/'tmp'),SQLITE_TMPDIR=str(o/'tmp'),VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',*sys.argv[1:]],cwd=r,env=env).returncode)
c=sys.argv[-1];assert c in ['Release','Debug'];b=r/('build/ninja-msvc-'+c.lower())
commands=[['cmake','-S',str(r),'-B',str(b),'-DAZURE_ENABLE_SURFACE_SHADOW_REUSE=ON','-DAZURE_ENABLE_SURFACE_SHADOW_DIAGNOSTICS=OFF','-DAZURE_ENABLE_SURFACE_RADIANCE_REUSE=OFF','-DAZURE_ENABLE_SURFACE_RADIANCE_DIAGNOSTICS=OFF','-DAZURE_ENABLE_SURFACE_RADIANCE_FRAME_SELECTION=OFF'],[sys.executable,'-X','utf8','tools/build_provenance.py','build','--build-dir',str(b),'--config',c]]
for target in ['AzureSurfaceShadowCacheTests','AzureSurfaceShadowLookupGpuTests','AzureSurfaceShadowViewGpuTests','AzureSurfaceRadianceCacheTests','AzureShadowFilteringGpuTests','AzureObjectShadowFilteringGpuTests','AzureTemporalViewGpuTests']:commands[1]+=['--test-target',target]
rows=[];start=time.monotonic()
with (o/(c.lower()+'-build.log')).open('wb') as log:
 for command in commands:
  p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT);rows.append(dict(command=command,exitCode=p.returncode))
  if p.returncode:break
(o/(c.lower()+'-build.json')).write_text(json.dumps(dict(results=rows,seconds=time.monotonic()-start),indent=2));print(c,rows[-1]['exitCode'],flush=True);raise SystemExit(p.returncode)
