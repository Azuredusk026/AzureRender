from pathlib import Path
import json,hashlib,subprocess,shutil,stat,datetime
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();items=[]
def remove(p,expected,base):
 assert p.resolve().is_relative_to(base.resolve()) and not p.is_symlink();assert digest(p)==expected
 for parent in [p,*p.parents]:
  info=parent.lstat();assert not getattr(info,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',1024)
  if parent==base:break
 assert not subprocess.check_output(['git','ls-files','--',str(p.relative_to(r))]).strip()
 items.append(dict(path=str(p),sha256=expected,logicalBytes=p.stat().st_size));p.unlink()
freeBefore=shutil.disk_usage(r).free
runtime=o/'baseline-runtime';catalog=json.loads((o/'baseline-runtime.json').read_text())['files']
assert {p.resolve() for p in runtime.rglob('*') if p.is_file()}=={Path(x['path']).resolve() for x in catalog}
for row in catalog:remove(Path(row['path']),row['sha256'],runtime)
(runtime/'shaders').rmdir();runtime.rmdir()
for folder in ['image-shadow-reuse','image-shadow-reuse-control']:
 report=json.loads((o/folder/'results.json').read_text());command=report['execution']['command'];frames=Path(command[command.index('--capture-dir')+1]);assert frames.resolve().is_relative_to(o.resolve())
 for row in report['frames']:
  assert row['sha256']==row['referenceSha256'] and row['changedPixels']==0;remove(frames/row['frame'],row['sha256'],o)
debug=r/'build/ninja-msvc-debug';start=datetime.datetime.strptime('20261109-045502','%Y%m%d-%H%M%S').timestamp()
# These three incremental databases were created by this candidate's new targets.
# Historical main-build ILK targets are outside this explicit list.
for name in ['AzureSurfaceShadowCacheTests.ilk','AzureSurfaceShadowLookupGpuTests.ilk','AzureSurfaceShadowViewGpuTests.ilk']:
 p=debug/name
 if p.exists():
  info=p.stat();assert info.st_ctime>=start and info.st_nlink==1,(name,info.st_ctime,start)
  assert not (r/'tests'/(name.removeprefix('Azure').removesuffix('.ilk')+'.cpp')).exists()
  remove(p,digest(p),debug)
report=dict(status='applied',files=len(items),logicalBytes=sum(x['logicalBytes'] for x in items),volumeFreeBefore=freeBefore,volumeFreeAfter=shutil.disk_usage(r).free,items=items)
(o/'runtime-and-images-cleanup.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='items'}))
