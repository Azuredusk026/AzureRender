from pathlib import Path
import os
def apply(run):
 temporary=Path(run).resolve()/'tmp'
 for key in ['TEMP','TMP','TMPDIR','SQLITE_TMPDIR']:os.environ[key]=str(temporary)
 for key,name in {'DOTNET_CLI_HOME':'dotnet-home','NUGET_PACKAGES':'nuget-packages','NUGET_HTTP_CACHE_PATH':'nuget-http','NUGET_PLUGINS_CACHE_PATH':'nuget-plugins','NUGET_SCRATCH':'nuget-scratch','DOTNET_BUNDLE_EXTRACT_BASE_DIR':'dotnet-extract'}.items():os.environ[key]=str(temporary/name)
 os.environ['DOTNET_CLI_TELEMETRY_OPTOUT']='1'
 os.environ['DOTNET_SKIP_FIRST_TIME_EXPERIENCE']='1'
