from pathlib import Path
import os,subprocess,json,sys,hashlib,xml.etree.ElementTree as ET
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from artifact_maintenance import guarded_run
from build_provenance import verify
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[];cases=[];lookup=json.loads((o/'finite-lookup-checks.json').read_text())
for device in ['nvidia','intel']:
 for case in ET.parse(o/('initial-release-'+device+'.xml')).getroot().findall('testcase'):
  if case.find('failure') is None and case.find('skipped') is None:cases.append(dict(configuration='release',device=device,name=case.attrib['name'],reusedFrom='initial-release-'+device+'.xml'))
 proof=next(x for x in lookup if x['device']==device);b=r/'build/ninja-msvc-release'
 assert digest(b/'AzureSurfaceShadowLookupGpuTests.exe')==proof['executableSha256'] and digest(b/'shaders/surface_shadow_lookup_test.comp.spv')==proof['shaderSha256']
 cases.append(dict(configuration='release',device=device,name='AzureRender.SurfaceShadowLookupGpu',reusedFrom='finite-lookup-checks.json'))
assert len(cases)==12
old=json.loads((o/'release-before-finite-repair-provenance.json').read_text());new=json.loads((r/'build/ninja-msvc-release/build-provenance.json').read_text())
changed=[p for p in old['products'] if old['products'][p]!=new['products'][p]];assert all('_shadow_cache.frag.spv' in p or p.endswith('surface_shadow_lookup_test.comp.spv') for p in changed),changed
(o/'finite-repair-scope.json').write_text(json.dumps(dict(changedProducts=changed,reusedReleaseChecks=12,scope='Resource, filtering, temporal view and lookup executable hashes unchanged; lookup shader matches the standalone two-device proof; graphics cache consumers revalidated below'),indent=2))
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);verify(r,json.loads((b/'build-provenance.json').read_text()))
 for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  os.environ.update(VK_LOADER_DRIVERS_SELECT=driver,TEMP=str(o/'tmp'),TMP=str(o/'tmp'),TMPDIR=str(o/'tmp'),SQLITE_TMPDIR=str(o/'tmp'))
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
  if c=='debug':
   pattern=r'^AzureRender\.(SurfaceShadowCache|SurfaceRadianceCache|SurfaceShadowLookupGpu|ShadowFilteringGpu|ObjectShadowFilteringGpu|TemporalViewGpu)$';xml=o/(c+'-'+device+'-final.xml')
   command=[ctest,'--test-dir',str(b),'-R',pattern,'--output-on-failure','--no-tests=error','--output-junit',str(xml)]
   with (o/(c+'-'+device+'-final-checks.log')).open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
   rows.append(dict(configuration=c,device=device,kind='ctest',command=command,exitCode=p.returncode));(o/'checks.json').write_text(json.dumps(rows,indent=2));print(c,device,'ctest',p.returncode,flush=True)
   assert p.returncode==0,(o/(c+'-'+device+'-final-checks.log')).read_text(errors='replace')[-5000:]
   for case in ET.parse(xml).getroot().findall('testcase'):
    assert case.find('failure') is None and case.find('skipped') is None;cases.append(dict(configuration=c,device=device,name=case.attrib['name']))
  folder=o/(c+'-'+device+'-final-shadow-view');folder.mkdir(exist_ok=True);command=[str(b/'AzureSurfaceShadowViewGpuTests.exe'),str(b/'shaders'),str(folder)]
  execution=guarded_run(r/'build',o.name,command,180);log=(o/'process.log').read_text(errors='replace');(folder/'process.log').write_text(log)
  rows.append(dict(configuration=c,device=device,kind='shadow-view',command=command,execution=execution));(o/'checks.json').write_text(json.dumps(rows,indent=2));print(c,device,'view',execution['exitCode'],flush=True)
  assert execution['status']=='exited' and execution['exitCode']==0,(execution,log[-5000:]);assert not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-'])
  cases.append(dict(configuration=c,device=device,name='AzureRender.SurfaceShadowViewGpu'))
assert len(cases)==28;(o/'check-cases.json').write_text(json.dumps(cases,indent=2));print('28 targeted checks passed, including explicitly bound reused checks',flush=True)
