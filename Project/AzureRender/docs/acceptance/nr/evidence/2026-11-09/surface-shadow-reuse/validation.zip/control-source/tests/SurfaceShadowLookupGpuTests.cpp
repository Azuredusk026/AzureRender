#include "support/VulkanComputeFixture.hpp"
#include "render/SurfaceRadianceCache.hpp"
#include "resources/BinaryFile.hpp"
#include <array>
#include <cstring>
#include <limits>
using namespace azurerender;
int main(int argc,char** argv)try{
 if(argc!=2)throw std::invalid_argument("Expected shadow lookup shader");
 test::VulkanComputeFixture host;auto& backend=*host.backend;
 std::array<rhi::GpuImage,2> images{};std::array<rhi::GpuBuffer,2> staging{};std::array<VkImageView,2> views{};
 rhi::GpuBuffer requests{},output{};VkSampler sampler{};VkDescriptorSetLayout setLayout{};VkDescriptorPool pool{};VkPipelineLayout layout{};VkShaderModule module{};VkPipeline pipeline{};
 auto cleanup=std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*){
  if(pipeline)backend.destroyPipeline(pipeline);if(module)backend.destroyShaderModule(module);if(layout)backend.destroyPipelineLayout(layout);
  if(pool)backend.destroyDescriptorPool(pool);if(setLayout)backend.destroyDescriptorSetLayout(setLayout);if(sampler)backend.destroySampler(sampler);
  for(unsigned i=0;i<2;++i){if(views[i])backend.destroyImageView(views[i]);host.allocator.destroyImage(images[i]);host.allocator.destroyBuffer(staging[i]);}
  host.allocator.destroyBuffer(requests);host.allocator.destroyBuffer(output);
 });
 constexpr unsigned count=768;std::array<float,count> values{};std::array<std::array<unsigned,4>,count> ids{},asked{};std::array<std::array<unsigned,2>,count> expected{};
 for(unsigned i=0;i<count;++i){
  values[i]=.500000059604644775390625F;ids[i]=surfaceRadianceIdentity(.25F,7,123,11,19).words;asked[i]=ids[i];
  switch(i%12){case 1:++asked[i][3];break;case 2:++asked[i][0];break;case 3:++asked[i][1];break;case 4:++asked[i][2];break;
   case 5:asked[i][2]=UINT32_MAX;break;case 6:ids[i][2]=UINT32_MAX;break;case 7:values[i]=std::numeric_limits<float>::quiet_NaN();break;
   case 8:values[i]=std::numeric_limits<float>::infinity();break;case 9:values[i]=-1e-20F;break;case 10:values[i]=1.00000011920928955078125F;break;case 11:values[i]=-0.F;break;}
  bool accepted=i%12==0||i%12==11;float result=accepted?values[i]:2.F;unsigned bits;std::memcpy(&bits,&result,4);expected[i]={accepted?1U:0U,bits};
 }
 for(unsigned i=0;i<2;++i){
  auto format=i==0?VK_FORMAT_R32_SFLOAT:VK_FORMAT_R32G32B32A32_UINT;images[i]=host.allocator.createImage2D(32,24,format,VK_IMAGE_USAGE_TRANSFER_DST_BIT|VK_IMAGE_USAGE_SAMPLED_BIT);
  views[i]=backend.createImageView(images[i].image,format,VK_IMAGE_ASPECT_COLOR_BIT,1);unsigned size=i==0?sizeof(values):sizeof(ids);
  staging[i]=host.allocator.createBuffer(size,VK_BUFFER_USAGE_TRANSFER_SRC_BIT,true);std::memcpy(staging[i].mapped,i==0?static_cast<const void*>(values.data()):ids.data(),size);host.allocator.flush(staging[i],0,size);
 }
 requests=host.allocator.createBuffer(sizeof(asked),VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);std::memcpy(requests.mapped,asked.data(),sizeof(asked));host.allocator.flush(requests,0,requests.size);
 output=host.allocator.createBuffer(sizeof(expected),VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
 rhi::SamplerDesc sample;sample.filter=VK_FILTER_NEAREST;sample.mipmapLinear=false;sampler=backend.createSampler(sample);
 setLayout=backend.createDescriptorSetLayout({{0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},{1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},{38,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_COMPUTE_BIT},{39,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,1,VK_SHADER_STAGE_COMPUTE_BIT}});
 rhi::DescriptorPoolDesc desc;desc.maxSets=1;desc.sizes={{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,2},{VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,2}};pool=backend.createDescriptorPool(desc);auto set=backend.allocateDescriptorSets(pool,setLayout,1).front();
 backend.writeDescriptorBuffer({set,0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,requests.buffer,requests.size});backend.writeDescriptorBuffer({set,1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,output.buffer,output.size});
 for(unsigned i=0;i<2;++i)backend.writeDescriptorImage({set,38+i,VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,views[i],sampler,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL});
 layout=backend.createPipelineLayout(setLayout,nullptr);module=backend.createShaderModule(readBinaryFile(argv[1]));pipeline=backend.createComputePipeline({module,layout});
 host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer native){
  for(unsigned i=0;i<2;++i){
   commands.bufferBarrier({staging[i].buffer,0,staging[i].size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT});
   commands.imageBarrier({images[i].image,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,VK_ACCESS_TRANSFER_WRITE_BIT});
   VkBufferImageCopy copy{};copy.imageSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};copy.imageExtent={32,24,1};vkCmdCopyBufferToImage(native,staging[i].buffer,images[i].image,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,&copy);
   commands.imageBarrier({images[i].image,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,1,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT});
  }
  commands.bufferBarrier({requests.buffer,0,requests.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT});
  commands.bindComputePipeline(pipeline);commands.bindComputeDescriptorSet(layout,set);commands.dispatch(count/64,1,1);
  commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
 });
 host.allocator.invalidate(output,0,output.size);if(std::memcmp(output.mapped,expected.data(),output.size)){
  const auto actual=static_cast<const std::array<unsigned,2>*>(output.mapped);
  for(unsigned i=0;i<count;++i)if(actual[i]!=expected[i]){std::cerr<<"Lookup mismatch at "<<i<<": "<<actual[i][0]<<','<<actual[i][1]<<" expected "<<expected[i][0]<<','<<expected[i][1]<<'\n';break;}
  throw std::runtime_error("Shadow lookup must preserve each matching pixel independently and reject every identity/value fault");
 }
 cleanup.reset();if(host.errors||host.allocator.statistics().liveBuffers||host.allocator.statistics().liveImages)throw std::runtime_error("Lookup validation or release failed");
 std::cout<<"768 exact scalar lookups: mixed-pixel identity, non-finite/out-of-range values and signed zero passed\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
