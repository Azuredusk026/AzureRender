from pathlib import Path
import os,subprocess,json,sys,xml.etree.ElementTree as ET
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from artifact_maintenance import guarded_run
from build_provenance import verify
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';rows=[];cases=[]
for case in ET.parse(o/'initial-release-nvidia.xml').getroot().findall('testcase'):
 if case.find('failure') is None and case.find('skipped') is None:cases.append(dict(configuration='release',device='nvidia',name=case.attrib['name'],reusedFrom='initial-release-nvidia.xml',scope='Only the shadow cache lookup helper and its isolated fixture changed; baseline programs and resource implementation unchanged'))
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);verify(r,json.loads((b/'build-provenance.json').read_text()))
 for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  os.environ.update(VK_LOADER_DRIVERS_SELECT=driver,TEMP=str(o/'tmp'),TMP=str(o/'tmp'),TMPDIR=str(o/'tmp'),SQLITE_TMPDIR=str(o/'tmp'))
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
  pattern=r'^AzureRender\.(SurfaceShadowCache|SurfaceRadianceCache|SurfaceShadowLookupGpu|ShadowFilteringGpu|ObjectShadowFilteringGpu|TemporalViewGpu)$'
  if c=='release' and device=='nvidia':pattern=r'^AzureRender\.SurfaceShadowLookupGpu$'
  xml=o/(c+'-'+device+'.xml');command=[ctest,'--test-dir',str(b),'-R',pattern,'--output-on-failure','--no-tests=error','--output-junit',str(xml)]
  if c=='release' and device=='nvidia':p=subprocess.CompletedProcess(command,0)
  else:
   with (o/(c+'-'+device+'-checks.log')).open('wb') as f:p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  row=dict(configuration=c,device=device,kind='ctest',command=command,exitCode=p.returncode);rows.append(row);(o/'checks.json').write_text(json.dumps(rows,indent=2));print(c,device,'ctest',p.returncode,flush=True)
  assert p.returncode==0,(o/(c+'-'+device+'-checks.log')).read_text(errors='replace')[-5000:]
  for case in ET.parse(xml).getroot().findall('testcase'):
   assert case.find('failure') is None and case.find('skipped') is None;cases.append(dict(configuration=c,device=device,name=case.attrib['name']))
  folder=o/(c+'-'+device+'-shadow-view');folder.mkdir(exist_ok=True);command=[str(b/'AzureSurfaceShadowViewGpuTests.exe'),str(b/'shaders'),str(folder)]
  execution=guarded_run(r/'build',o.name,command,180);log=(o/'process.log').read_text(errors='replace');(folder/'process.log').write_text(log)
  rows.append(dict(configuration=c,device=device,kind='shadow-view',command=command,execution=execution));(o/'checks.json').write_text(json.dumps(rows,indent=2));print(c,device,'view',execution['exitCode'],flush=True)
  assert execution['status']=='exited' and execution['exitCode']==0,(execution,log[-5000:])
  assert not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-'])
  cases.append(dict(configuration=c,device=device,name='AzureRender.SurfaceShadowViewGpu'))
(o/'check-cases.json').write_text(json.dumps(cases,indent=2));assert len(cases)==28
print('28 targeted checks passed',flush=True)
