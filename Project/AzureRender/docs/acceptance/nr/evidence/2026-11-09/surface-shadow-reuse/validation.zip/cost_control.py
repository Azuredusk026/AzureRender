from pathlib import Path
import json,os,sys,csv,shutil,collections
import numpy as np
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;b=r/'build/ninja-msvc-release';sys.path.insert(0,str(r/'tools'))
from task_environment import apply
from build_provenance import inputs,digest,verify
from artifact_maintenance import guarded_run
from gpu_environment import RunEnvironmentMonitor
apply(o);image=json.loads((o/'image-shadow-reuse-control/results.json').read_text());assert len(image['frames'])==4 and all(x['changedPixels']==0 for x in image['frames'])
assert image['metadata']['surfaceShadowReusePrepared'] and not image['metadata']['surfaceRadianceStatistics']['enabled']
assert json.loads((o/'native-coverage-gate.json').read_text())['gatePassed']
verify(r,json.loads((b/'build-provenance.json').read_text()));before=inputs(r);products={str(p):digest(p) for p in [b/'AzurePlayer.exe',*sorted((b/'shaders').glob('*.spv'))]}
baseline=json.loads((o/'baseline-runtime.json').read_text());assert len(baseline['files'])==676 and all(digest(Path(p['path']))==p['sha256'] for p in baseline['files'])
lock=json.loads((o.parent/'20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text());assert all(digest(Path(p))==sha for p,sha in lock.items())
project=o.parent/'20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['PATH']=str(b)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES','AZURE_CPU_WORK_REPORT']:os.environ.pop(key,None)
rows=[]
for label,runtime in [('candidate',b),('reference-after',o/'baseline-runtime')]:
 folder=o/('cost-control-'+label);folder.mkdir(exist_ok=True);assert not (folder/'timing.json').exists()
 command=[str(runtime/'AzurePlayer.exe'),'--project',str(project),'--resource-root',str(runtime),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','24','--smoke-frames','120','--gpu-timing','--gpu-pass-timing','--gpu-timing-output',str(folder/'timing.json')]
 (folder/'command.json').write_text(json.dumps(command,indent=2));environment={}
 with RunEnvironmentMonitor(environment,path=folder/'environment.json',interval=2):execution=guarded_run(r/'build',o.name,command,300)
 shutil.copyfile(o/'process.log',folder/'process.log');(folder/'execution.json').write_text(json.dumps(execution,indent=2));assert execution['status']=='exited' and execution['exitCode']==0,execution
 log=(folder/'process.log').read_text(errors='replace');assert 'Allocator after unload: buffers=0 images=0' in log and not any(x in log for x in ['Validation Error:','SYNC-HAZARD','VUID-'])
 data=json.loads((folder/'timing.json').read_text());samples=list(csv.DictReader((folder/'timing.csv').open()));selected=[x for x in samples if 61<=int(x['frame'])<=120];assert len(selected)==60 and [data['sceneWidth'],data['sceneHeight']]==[1920,1080]
 assert data.get('surfaceShadowReusePrepared',False)==(label=='candidate') and not data['surfaceRadianceStatistics']['enabled']
 summary={name:dict(mean=float(np.mean([float(x[key]) for x in selected])),p95=float(np.percentile([float(x[key]) for x in selected],95))) for name,key in [('gpu','frameMs'),('main','sceneMs'),('shadow','shadowMs')]}
 cpu=data['cpuFrame']['workSamplesMs'];assert len(cpu)==120;summary['cpu']=dict(mean=float(np.mean(cpu[60:])),p95=float(np.percentile(cpu[60:],95)))
 frames=[json.loads(line) for line in (folder/'timing.passes.jsonl').read_text().splitlines()];frames=[f for f in frames if 61<=f['frame']<=120];assert len(frames)==60
 grouped=collections.defaultdict(list)
 for frame in frames:
  for p in frame['passes']:
   if p['available']:grouped[p['name']].append(p['milliseconds'])
 for name in ['character-main','character-opaque-depth']:assert len(grouped[name])==60,(name,len(grouped[name]))
 passes={name:dict(samples=len(values),meanMs=float(np.mean(values)),p95Ms=float(np.percentile(values,95))) for name,values in grouped.items()}
 observations=environment['runObservations'];assert not environment['monitorErrors']
 envSummary=dict(acLineStates=sorted(set(x['hostPower']['acLineStatus'] for x in observations)),powerLimits=sorted(set(x['powerLimitWatts'] for x in observations if x['powerLimitWatts'] is not None)),thermalSlowdownObserved=any(any(v is True for v in x['thermalSlowdown'].values()) for x in observations))
 row=dict(label=label,summary=summary,passes=passes,environment=envSummary,execution=execution,metadata={k:v for k,v in data.items() if k.startswith(('surfaceShadow','surfaceRadiance','computeSkinning','shadowBounds'))});rows.append(row);(o/'cost-control-progress.json').write_text(json.dumps(rows,indent=2));print(json.dumps(dict(label=label,summary=summary,dominantPasses={k:v for k,v in passes.items() if k in ['character-main','character-opaque-depth']})),flush=True)
 assert inputs(r)==before and all(digest(Path(p))==sha for p,sha in products.items());assert all(digest(Path(p['path']))==p['sha256'] for p in baseline['files'])
assert all(digest(Path(p))==sha for p,sha in lock.items())
prior=json.loads((o/'cost-results-v1.json').read_text());anchor=prior['rows'][2]['summary']['gpu']['mean'];reference=rows[1]['summary']['gpu']['mean'];candidate=rows[0]['summary']['gpu']['mean']
report=dict(status='measured',rows=rows,gpuReferenceMean=reference,gpuCandidateMean=candidate,gpuSavedMs=reference-candidate,gpuReductionFraction=1-candidate/reference,priorReferenceAnchorMean=anchor,priorAnchorDriftFraction=abs(reference-anchor)/((reference+anchor)/2),priorAnchorComparableInstrumentation=False,pairedInstrumentation='GPU core and per-pass timestamps enabled for both fresh roles',sourceAndProductsUnchanged=True,projectInputsVerified=len(lock),formalPerformancePassed=False,scope='One new counter-off candidate and one fresh matched reference, with 60 warmup/60 selected frames each; prior same-input reference is a separate drift anchor with core timestamps only; no repeated three-process bracket')
(o/'cost-control-results.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='rows'}),flush=True)
