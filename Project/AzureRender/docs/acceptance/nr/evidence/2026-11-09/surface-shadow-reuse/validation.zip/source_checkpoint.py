from pathlib import Path
import json,hashlib,shutil,subprocess
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['CMakeLists.txt','src/app/AzureRenderApp.cpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','src/scenes/CharacterMaterialSampling.inc','src/render/SurfaceRadianceCache.cpp','src/render/SurfaceRadianceCache.hpp','shaders/mesh.frag','shaders/mesh.vert','shaders/surface_shadow_cache.glsl','shaders/surface_shadow_lookup_test.comp','tests/SurfaceShadowCacheTests.cpp','tests/SurfaceShadowLookupGpuTests.cpp','tests/SurfaceRadianceViewGpuTests.cpp']
misnamed=o/'diagnostic-source.patch'
if misnamed.exists():misnamed.rename(o/'control-initial-source.patch')
(o/'control-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--',*names]))
proof=json.loads((o/'release-diagnostic-provenance.json').read_text())['source'];current={};old={}
for name in names:
 p=r/name;dst=o/'control-source'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst);current[name]=digest(p)
 if name not in proof:continue
 data=p.read_text()
 if name=='CMakeLists.txt':
  data=data.replace('option(AZURE_ENABLE_SURFACE_SHADOW_DIAGNOSTICS "Enable sparse intrusive shadow-cache counters" OFF)\nif(AZURE_ENABLE_SURFACE_SHADOW_DIAGNOSTICS AND NOT AZURE_ENABLE_SURFACE_SHADOW_REUSE)\n    message(FATAL_ERROR "Shadow-cache diagnostics require AZURE_ENABLE_SURFACE_SHADOW_REUSE")\nendif()\n','')
  data=data.replace('    "$<$<BOOL:${AZURE_ENABLE_SURFACE_SHADOW_DIAGNOSTICS}>:AZURE_SURFACE_SHADOW_DIAGNOSTICS=1>"\n','')
  data=data.replace('set(_shadow_diagnostic_defines)\nif(AZURE_ENABLE_SURFACE_SHADOW_DIAGNOSTICS)\n    list(APPEND _shadow_diagnostic_defines AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1 AZURE_SURFACE_RADIANCE_SPARSE_DIAGNOSTICS=1)\nendif()\n','')
  data=data.replace('${_shadow_diagnostic_defines} OUTPUT_NAME','AZURE_SURFACE_RADIANCE_DIAGNOSTICS=1 AZURE_SURFACE_RADIANCE_SPARSE_DIAGNOSTICS=1 OUTPUT_NAME')
  data=data.replace(' AZURE_TEST_SURFACE_SHADOW_DIAGNOSTICS=$<BOOL:${AZURE_ENABLE_SURFACE_SHADOW_DIAGNOSTICS}>','')
 if name=='src/scenes/CharacterSceneRenderer.cpp':data=data.replace('#if defined(AZURE_SURFACE_RADIANCE_DIAGNOSTICS) || defined(AZURE_SURFACE_SHADOW_DIAGNOSTICS)','#if defined(AZURE_SURFACE_RADIANCE_DIAGNOSTICS) || defined(AZURE_SURFACE_SHADOW_PROGRAMS)')
 if name=='src/app/AzureRenderApp.cpp':
  data=data.replace('    fragmentPrimitiveIdentity_&=!runOptions_.qaDisableSurfaceRadianceReuse;\n#if defined(AZURE_SURFACE_SHADOW_DIAGNOSTICS)\n    fragmentPrimitiveIdentity_&=supportedSampler.fragmentStoresAndAtomics==VK_TRUE;\n    deviceFeatures.fragmentStoresAndAtomics=fragmentPrimitiveIdentity_?VK_TRUE:VK_FALSE;\n#endif','    fragmentPrimitiveIdentity_&=!runOptions_.qaDisableSurfaceRadianceReuse&&supportedSampler.fragmentStoresAndAtomics==VK_TRUE;\n    deviceFeatures.fragmentStoresAndAtomics=fragmentPrimitiveIdentity_?VK_TRUE:VK_FALSE;')
 variants=[data.encode(),data.replace('\r\n','\n').replace('\n','\r\n').encode()];matches=[v for v in variants if hashlib.sha256(v).hexdigest()==proof[name]];assert matches,('Cannot recover diagnostic source',name)
 dst=o/'diagnostic-source'/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(matches[0]);old[name]=digest(dst)
(o/'control-source.json').write_text(json.dumps(current,indent=2));(o/'diagnostic-source.json').write_text(json.dumps(dict(status='recovered-by-exact-inverse-and-verified-against-measured-source-manifest',sourceHashes=old),indent=2));print('Frozen control files',len(current),'verified diagnostic files',len(old))
