from pathlib import Path
import json,struct,math
out=Path(__file__).resolve().parent
report=json.loads((out/'probe-results.json').read_text())
assert report['status']=='qualified' and len(report['captures'])==2
allowed_native={
    'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU',
    'NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image'}
assert set(report['captures'][0]['debugMessages'])<=allowed_native
assert not report['captures'][1]['debugMessages']
groups={};flags={}
for capture in report['captures']:
    assert len(capture['runs'])==24 and capture['baselineRestored']
    assert all(row['qualified'] for row in capture['runs'])
    label=capture['label'];groups[label]={};flags[label]={}
    for field in ['parameters','normals']:
        words=[[0,0,0,0] for _ in report['points']]
        variations=[[] for _ in words]
        for row in capture['runs']:
            if row['case']['field']!=field:continue
            component=row['case']['component'];shift=row['case']['shift']
            for index,value in enumerate(row['values']):
                if shift==24:
                    variations[index].append(value>>8)
                    value&=255
                words[index][component]|=value<<shift
        assert all(0<=word<=0xffffffff for row in words for word in row)
        groups[label][field]=words;flags[label][field]=variations
rows=[];summary={}
decode=lambda row:[struct.unpack('<f',struct.pack('<I',value))[0] for value in row]
for field in ['parameters','normals']:
    selected=[]
    for index,pixel in enumerate(report['points']):
        native=groups['native'][field][index];vulkan=groups['vulkan'][field][index]
        a=decode(native);b=decode(vulkan);state=flags['vulkan'][field][index]
        assert all(math.isfinite(value) and 0<=value<=1 for value in a+b)
        consistent=all(value==0 for value in state)
        row=dict(field=field,pixel=pixel,nativeBits=native,vulkanBits=vulkan,native=a,vulkan=b,
                 consistencyFlags=state,consistent=consistent,exact=native==vulkan,
                 maximumAbsolute=max(abs(x-y) for x,y in zip(a,b)))
        selected.append(row);rows.append(row)
    summary[field]=dict(points=len(selected),consistentPoints=sum(row['consistent'] for row in selected),
        exactAmongConsistent=sum(row['consistent'] and row['exact'] for row in selected),
        differentAmongConsistent=sum(row['consistent'] and not row['exact'] for row in selected),
        maximumAbsoluteAmongConsistent=max((row['maximumAbsolute'] for row in selected if row['consistent']),default=None))
result=dict(status='qualified-material-input-comparison',summary=summary,rows=rows,qualification=report,
    scope='Actual original fragment texture reads; full-crop blue qualification retained. Consistency flags: bit0 varies across invocations, bit1 was never read. Only zero-flag points support a direct vector comparison.')
import numpy as np
normal_rows=[row for row in rows if row['field']=='normals']
parameter_rows=[row for row in rows if row['field']=='parameters']
a=np.array([row['native'] for row in normal_rows],dtype='<f4')*np.float32(2)-np.float32(1)
raw_b=np.array([row['vulkan'] for row in normal_rows],dtype='<f4')
b=raw_b*np.float32(2)-np.float32(1)
b[:,[1,3]]=np.float32(1)-raw_b[:,[1,3]]*np.float32(2)
delta=abs(a-b)
stable=np.array([row['exact'] for row in parameter_rows])
result['signedNormalComponents']=dict(nativeRule='2*RGBA-1',vulkanRule='(2R-1,1-2G,2B-1,1-2A)',
    exactPoints=int(np.all(a.view('<u4')==b.view('<u4'),axis=1).sum()),
    maxAbsolute=float(delta.max()),stableParameterPoints=int(stable.sum()),
    stableParameterMaxAbsolute=float(delta[stable].max()),
    rows=[dict(pixel=row['pixel'],native=a[index].tolist(),vulkan=b[index].tolist(),absoluteDifference=delta[index].tolist()) for index,row in enumerate(normal_rows)])
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(summary,indent=2))
