from pathlib import Path
import sys,json,struct,traceback,hashlib,zlib
import renderdoc as rd
out=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261109-231408-hair-material-sample-region-5f9f16')
sys.path.insert(0,str(out))

main=Path('D:/Projects/FYP/Project/AzureRender')
prior=out.parent/'20261109-221435-hair-color-closure-430845'
points=[p['pixel'] for p in json.loads((prior/'native-visibility-results.json').read_text())['points']]
cases=json.loads((out/'cases.json').read_text())
captures=[('native',main/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc',950),
          ('vulkan',main/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc',493)]
report=dict(status='starting',points=points,captures=[]);cap=None;c=None;shader=None;replacement=None
def save():(out/'probe-results.json').write_text(json.dumps(report,indent=2)+'\n')
def unsigned_float(word,mantissa):
    exponent=word>>mantissa;fraction=word&((1<<mantissa)-1)
    assert exponent!=31
    return fraction*2.0**(-14-mantissa) if exponent==0 else (1+fraction/float(1<<mantissa))*2.0**(exponent-15)
try:
    for label,path,event in captures:
        cap=rd.OpenCaptureFile();assert cap.OpenFile(str(path),'',None)==rd.ResultCode.Succeeded
        status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
        c.SetFrameEvent(event,True);pipe=c.GetPipelineState();shader=pipe.GetShader(rd.ShaderStage.Pixel)
        raw=bytes(pipe.GetShaderReflection(rd.ShaderStage.Pixel).rawBytes)
        (out/(label+'-original.shader')).write_bytes(raw)
        target=pipe.GetOutputTargets()[0].resource
        native=label=='native';stride=4 if native else 8
        def read():
            data=bytes(c.GetTextureData(target,rd.Subresource()));assert len(data)==2560*1440*stride
            return b''.join(data[((1439-y if native else y)*2560+1140)*stride:((1439-y if native else y)*2560+1430)*stride] for y in range(130,440))
        def blue(data):
            if native:return tuple(word[0]>>22 for word in struct.iter_unpack('<I',data))
            return b''.join(data[i+4:i+6] for i in range(0,len(data),8))
        baseline=read();baseline_blue=blue(baseline)
        row=dict(label=label,event=event,sourceShaderSha256=hashlib.sha256(raw).hexdigest(),runs=[])
        report['captures'].append(row);save()
        for case in cases:
            code=(out/(case['name']+'.dxbc')).read_bytes() if native else (out/(case['name']+'.spv')).read_bytes()
            if native:(out/(case['name']+'.dxbc')).write_bytes(code)
            replacement,errors=c.BuildTargetShader('main',rd.ShaderEncoding.DXBC if native else rd.ShaderEncoding.SPIRV,code,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
            assert replacement!=rd.ResourceId.Null(),errors
            c.ReplaceResource(shader,replacement);c.SetFrameEvent(event,True);data=read()
            actual_blue=blue(data);qualified=actual_blue==baseline_blue
            sample=dict(case=case,qualified=qualified,shaderSha256=hashlib.sha256(code).hexdigest(),values=[])
            row['runs'].append(sample);save()
            assert qualified,(label,case['name'],'blue channel changed')
            for x,y in points:
                offset=((y-130)*290+x-1140)*stride
                if native:
                    word=struct.unpack_from('<I',data,offset)[0]
                    values=[unsigned_float(word&2047,6),unsigned_float((word>>11)&2047,6)]
                else:values=list(struct.unpack_from('<4e',data,offset))[:2]
                digits=[int(round(value*64)) for value in values]
                assert all(0<=d<=63 for d in digits),digits
                sample['values'].append(digits[0]|(digits[1]<<6))
            c.RemoveReplacement(shader);c.FreeTargetResource(replacement);replacement=None;save()
        c.SetFrameEvent(event,True);assert read()==baseline
        row['baselineRestored']=True;row['debugMessages']=[str(m.description) for m in c.GetDebugMessages()]
        c.Shutdown();c=None;cap.Shutdown();cap=None;shader=None;save()
    report['status']='qualified'
except BaseException:report.update(status='failed',error=traceback.format_exc())
finally:
    if c:
        if shader:c.RemoveReplacement(shader)
        if replacement:c.FreeTargetResource(replacement)
        c.Shutdown()
    if cap:cap.Shutdown()
    save()
sys.exit(0 if report['status']=='qualified' else 1)
