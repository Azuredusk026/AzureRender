from pathlib import Path
import struct,subprocess
from dxbc_util import chunks,words,instructions,opcode,inst,dest,source,imm,fbits,rebuild,checksum
out=Path(__file__).resolve().parent
def native_probe(raw,component,shift,register,resource):
    assert checksum(raw)==raw[4:20]
    parts=chunks(raw);index=next(i for i,(kind,_) in enumerate(parts) if kind in [b'SHEX',b'SHDR'])
    w=words(parts[index][1]);items=list(instructions(w))
    declarations=[item for item in items if item[2]==opcode('DCL_TEMPS')];assert len(declarations)==1
    capture=w[declarations[0][1]+1];scratch=capture+1;w[declarations[0][1]+1]=capture+2
    samples=[]
    for pc,at,op,n in items:
        if op!=opcode('SAMPLE_B'):continue
        operand=at+1
        while w[operand-1]&0x80000000:operand+=1
        token=w[operand]
        resource16=any(((w[i]>>12)&255)==7 and w[i+1]==resource for i in range(operand+2,at+n-1))
        if ((token>>12)&255)==0 and w[operand+1]==register and resource16:samples.append((at,n))
    assert len(samples)==1,samples
    returns=[item for item in items if item[2]==opcode('RET')];assert len(returns)==1
    extra=[]
    for target,offset in [(1,shift),(2,shift+6)]:
        extra+=inst('USHR',dest(scratch),source(capture,component),imm(offset))
        extra+=inst('AND',dest(scratch),source(scratch),imm(63))
        extra+=inst('UTOF',dest(scratch),source(scratch))
        extra+=inst('MUL',dest(scratch),source(scratch),imm(fbits(1/64)))
        extra+=inst('MOV',dest(0,target,True),source(scratch))
    end=returns[0][1];w[end:end]=extra
    at,n=samples[0];w[at+n:at+n]=inst('MOV',dest(capture,15),[2|(1<<2)|(0xe4<<4)|(1<<20),register])
    w[1]=len(w);parts[index]=(parts[index][0],struct.pack('<'+'I'*len(w),*w))
    return rebuild(raw,parts)

