from pathlib import Path
import re,json,shutil,subprocess
out=Path(__file__).resolve().parent
prior=out.parent/'20261109-225636-hair-base-sample-region-0c13c0'
for name in ['dxbc_util.py','D3D12TokenizedProgramFormat.hpp','LICENSE-RenderDoc.txt','checksum-source.json','header-source.json']:
    shutil.copyfile(prior/name,out/name)
source=(prior/'probes.py').read_text().split('def prepare_vulkan():',1)[0]
source=source.replace('def native_probe(raw,component,shift):','def native_probe(raw,component,shift,register,resource):')
source=source.replace('w[i+1]==16','w[i+1]==resource').replace('w[operand+1]==9','w[operand+1]==register')
source=source.replace('dest(capture,7)','dest(capture,15)').replace('(1<<20),9])','(1<<20),register])')
(out/'native_probes.py').write_text(source)
import sys
sys.path.insert(0,str(out))
from native_probes import native_probe
raw=(prior/'native-original.shader').read_bytes()
template=(prior/'sample-0-0.spvasm').read_text()
fields=[dict(name='parameters',register=10,resource=17,variable='%parameters_0',value='%5696'),
        dict(name='normals',register=13,resource=18,variable='%packedNormals',value='%5714')]
cases=[]
for field in fields:
    for component in range(4):
        for shift in [0,12,24]:
            name=f'{field["name"]}-{component}-{shift}';text=template
            text=text.replace('%sample_probe_shift_r = OpConstant %uint 0',f'%sample_probe_shift_r = OpConstant %uint {shift}')
            text=text.replace('%sample_probe_shift_g = OpConstant %uint 6',f'%sample_probe_shift_g = OpConstant %uint {shift+6}')
            declarations=[]
            def existing_or_add(pattern,declaration):
                found=re.search(r'(%\S+) = '+pattern+r'\n',text)
                if found:return found[1]
                identifier='%material_probe_type_'+str(len(declarations))
                declarations.append(identifier+' = '+declaration)
                return identifier
            u4=existing_or_add('OpTypeVector %uint 4','OpTypeVector %uint 4')
            b4=existing_or_add('OpTypeVector %bool 4','OpTypeVector %bool 4')
            p4=existing_or_add('OpTypePointer Private %v4float','OpTypePointer Private %v4float')
            pb=existing_or_add('OpTypePointer Private %bool','OpTypePointer Private %bool')
            declarations += ['%material_probe_zero = OpConstantNull %v4float',
                '%material_probe_false = OpConstantFalse %bool','%material_probe_true = OpConstantTrue %bool',
                '%material_probe_uint2 = OpConstant %uint 2',
                f'%material_probe_capture = OpVariable {p4} Private %material_probe_zero',
                f'%material_probe_seen = OpVariable {pb} Private %material_probe_false',
                f'%material_probe_varied = OpVariable {pb} Private %material_probe_false']
            offset=text.index('       %main = OpFunction');text=text[:offset]+'\n'.join(declarations)+'\n'+text[offset:]
            needle=f'OpStore {field["variable"]} {field["value"]}'
            assert text.count(needle)==1
            hook=f'''%material_hook_old = OpLoad %v4float %material_probe_capture
%material_hook_old_bits = OpBitcast {u4} %material_hook_old
%material_hook_new_bits = OpBitcast {u4} {field['value']}
%material_hook_ne = OpINotEqual {b4} %material_hook_old_bits %material_hook_new_bits
%material_hook_any = OpAny %bool %material_hook_ne
%material_hook_seen = OpLoad %bool %material_probe_seen
%material_hook_changed = OpLogicalAnd %bool %material_hook_seen %material_hook_any
%material_hook_prior = OpLoad %bool %material_probe_varied
%material_hook_varied = OpLogicalOr %bool %material_hook_prior %material_hook_changed
OpStore %material_probe_varied %material_hook_varied
OpStore %material_probe_capture {field['value']}
OpStore %material_probe_seen %material_probe_true
'''
            text=text.replace(needle,needle+'\n'+hook)
            text=text.replace('%sample_probe_value = OpCompositeExtract %float %8245 0',
                f'%material_probe_loaded = OpLoad %v4float %material_probe_capture\n%sample_probe_value = OpCompositeExtract %float %material_probe_loaded {component}')
            if shift==24:
                needle='%sample_probe_gbits = OpBitwiseAnd %uint %sample_probe_gshift %sample_probe_mask'
                extra='''%material_probe_seen_value = OpLoad %bool %material_probe_seen
%material_probe_unseen = OpLogicalNot %bool %material_probe_seen_value
%material_probe_varied_value = OpLoad %bool %material_probe_varied
%material_probe_varied_uint = OpSelect %uint %material_probe_varied_value %uint_1 %uint_0
%material_probe_unseen_uint = OpSelect %uint %material_probe_unseen %material_probe_uint2 %uint_0
%material_probe_flags = OpBitwiseOr %uint %material_probe_varied_uint %material_probe_unseen_uint
%material_probe_flags_shifted = OpShiftLeftLogical %uint %material_probe_flags %material_probe_uint2
%sample_probe_gbits = OpBitwiseOr %uint %sample_probe_gbits_base %material_probe_flags_shifted'''
                text=text.replace(needle,needle.replace('%sample_probe_gbits =','%sample_probe_gbits_base =')+'\n'+extra)
            (out/(name+'.spvasm')).write_text(text)
            sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
            for command in [[str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/(name+'.spvasm')),'-o',str(out/(name+'.spv'))],
                            [str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/(name+'.spv'))]]:
                subprocess.run(command,check=True)
            (out/(name+'.dxbc')).write_bytes(native_probe(raw,component,shift,field['register'],field['resource']))
            cases.append(dict(name=name,field=field['name'],component=component,shift=shift))
(out/'cases.json').write_text(json.dumps(cases,indent=2))
print('Prepared 24 paired parameter and normal probes with per-invocation consistency flags')
