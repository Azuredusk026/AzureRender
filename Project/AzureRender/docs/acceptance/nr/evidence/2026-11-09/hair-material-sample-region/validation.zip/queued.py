from pathlib import Path
import sys,time,json
out=Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared
import artifact_maintenance as maintenance
deadline=time.monotonic()+120
print('Waiting for the shared queue for at most 120 seconds.',flush=True)
while True:
    lease=shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a','quality-hair-material-sample-bits',out)
    try:lease.__enter__()
    except ValueError:
        if time.monotonic()>=deadline:raise SystemExit('Shared queue wait deadline reached')
        time.sleep(2);continue
    break
try:
    print('Shared queue acquired.',flush=True)
    result=maintenance.guarded_run(out.parents[1],out.name,[sys.executable,str(out/'run.py')],240)
    (out/'execution.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
finally:lease.__exit__(None,None,None)
raise SystemExit(result.get('exitCode',1))
