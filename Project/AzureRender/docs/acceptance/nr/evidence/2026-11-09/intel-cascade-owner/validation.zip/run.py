from pathlib import Path
import os,sys,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
os.environ.update(managed_environment(o/'tmp'));os.environ['AZURE_CAPTURE_TASK']=str(o);os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*';os.environ['PATH']=str(r/'build/ninja-msvc-release')+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES','VK_LAYER_VALIDATE_SYNC','VK_LOADER_DEBUG']:os.environ.pop(key,None)
for key in ['RENDERDOC_DEBUG_LOG_FILE','RDOC_DEBUG_LOG_FILE']:os.environ[key]=str(o/'tmp/renderdoc.log')
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(o/'capture.py')]
result=guarded_run(r/'build',o.name,command,180);(o/'execution.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True);assert result['exitCode']==0,result
