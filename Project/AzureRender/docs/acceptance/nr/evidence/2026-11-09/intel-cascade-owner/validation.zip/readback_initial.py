from pathlib import Path
import os,json,struct,hashlib,traceback
import renderdoc as rd
r=Path('D:/Projects/FYP/Project/AzureRender');o=Path(os.environ['AZURE_CAPTURE_TASK']);allReports=[];cap=None;c=None
try:
 for number in [0,1]:
  folder=o/('initial-replay-'+str(number));folder.mkdir(exist_ok=True)
  cap=rd.OpenCaptureFile();assert cap.OpenFile(str(o/('initial_frame%d.rdc'%number)),'',None)==rd.ResultCode.Succeeded
  opts=rd.ReplayOptions();opts.forceGPUVendor=rd.GPUVendor.Intel
  status,c=cap.OpenCapture(opts,None);assert status==rd.ResultCode.Succeeded,str(status)
  structured=c.GetStructuredFile();actions=[]
  def walk(items):
   for a in items:actions.append(a);walk(a.children)
  walk(c.GetRootActions());textures={str(t.resourceId):t for t in c.GetTextures()};buffers={str(b.resourceId):b for b in c.GetBuffers()};names={str(x.resourceId):x.name for x in c.GetResources()}
  rows=[]
  for a in actions:
   if not a.flags&rd.ActionFlags.Drawcall:continue
   c.SetFrameEvent(a.eventId,True);p=c.GetPipelineState();row=dict(event=a.eventId,name=a.GetName(structured),indices=a.numIndices,outputs=[],stages=[])
   for stage in [rd.ShaderStage.Vertex,rd.ShaderStage.Pixel]:
    refl=p.GetShaderReflection(stage)
    if not refl:continue
    shader=dict(stage=str(stage),sha256=hashlib.sha256(bytes(refl.rawBytes)).hexdigest(),buffers=[])
    for used in list(p.GetConstantBlocks(stage))+list(p.GetReadOnlyResources(stage))+list(p.GetReadWriteResources(stage)):
     d=used.descriptor;key=str(d.resource)
     if key not in buffers:continue
     length=min(int(d.byteSize),65536)
     if length<=0:continue
     data=bytes(c.GetBufferData(d.resource,d.byteOffset,length));file='event-%d-%s-buffer-%s.bin'%(a.eventId,str(stage),key.replace('::','-'))
     (folder/file).write_bytes(data);shader['buffers'].append(dict(resource=key,name=names.get(key),fullSize=d.byteSize,offset=d.byteOffset,bytes=len(data),file=file,sha256=hashlib.sha256(data).hexdigest()))
    row['stages'].append(shader)
   for target in p.GetOutputTargets():
    key=str(target.resource)
    if key not in textures:continue
    t=textures[key]
    if t.width!=128 or t.height!=128:continue
    data=bytes(c.GetTextureData(t.resourceId,rd.Subresource()));file='event-%d-texture-%s.bin'%(a.eventId,key.replace('::','-'));(folder/file).write_bytes(data)
    row['outputs'].append(dict(resource=key,name=names.get(key),format=t.format.Name(),components=t.format.compCount,componentBytes=t.format.compByteWidth,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),file=file))
   rows.append(row)
  report=dict(capture=number,actions=rows,gpu=str(c.GetAPIProperties().localRenderer));(folder/'report.json').write_text(json.dumps(report,indent=2));allReports.append(report)
  c.Shutdown();c=None;cap.Shutdown();cap=None
 (o/'initial-readback.json').write_text(json.dumps(allReports,indent=2));code=0
except Exception:
 (o/'initial-readback-error.txt').write_text(traceback.format_exc());code=1
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 try:pyrenderdoc.Config().Close()
 except Exception:pass
 os._exit(code)
