from pathlib import Path
import os,sys,subprocess
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'));os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*'
if '--inside' not in sys.argv:raise SystemExit(subprocess.run([str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],env=os.environ).returncode)
with (o/'memory-build.log').open('wb') as log:subprocess.run(['cl','/nologo','/EHsc','/I','D:/Tools/VulkanSDK/1.4.350.0/Include',str(o/'memory.cpp'),'/Fo'+str(o/'memory.obj'),'/Fe'+str(o/'memory.exe'),'/link','/INCREMENTAL:NO','D:/Tools/VulkanSDK/1.4.350.0/Lib/vulkan-1.lib'],stdout=log,stderr=subprocess.STDOUT,check=True)
data=subprocess.check_output([str(o/'memory.exe')]);(o/'memory-properties.txt').write_bytes(data);print(data.decode(),flush=True)
