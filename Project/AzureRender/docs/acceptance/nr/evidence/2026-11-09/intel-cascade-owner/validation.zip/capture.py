from pathlib import Path
import os,sys,json,time,subprocess,traceback
import renderdoc as rd
r=Path('D:/Projects/FYP/Project/AzureRender');o=Path(os.environ['AZURE_CAPTURE_TASK']);captures=[];control=None
try:
 src=r/'build/runs/20261109-084026-clustered-receiver-ranges-3d190b/gpu-intel/local/front'
 args=json.loads((src/'command.json').read_text())[1:];args[args.index('--capture-dir')+1]=str(o/'frames-v2');args[args.index('--capture-frames')+1]='3'
 options=rd.CaptureOptions();options.apiValidation=False;options.debugOutputMute=False;options.hookIntoChildren=False;options.refAllResources=False
 modifications=[]
 for name,value in [('VK_LAYER_PATH','D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64;D:/Tools/VulkanSDK/1.4.350.0/Bin'),('VK_INSTANCE_LAYERS','VK_LAYER_RENDERDOC_Capture'),('ENABLE_VULKAN_RENDERDOC_CAPTURE','1'),('VK_LOADER_DRIVERS_SELECT','*igvk64*')]:
  m=rd.EnvironmentModification();m.name=name;m.value=value;m.mod=rd.EnvMod.Set;m.sep=rd.EnvSep.Platform;modifications.append(m)
 result=rd.ExecuteAndInject(str(r/'build/ninja-msvc-release/AzurePlayer.exe'),str(r),subprocess.list2cmdline(args),modifications,str(o/'capture'),options,False)
 if result.result!=rd.ResultCode.Succeeded:raise RuntimeError(str(result.result))
 deadline=time.monotonic()+15
 while time.monotonic()<deadline:
  control=rd.CreateTargetControl('',result.ident,'AzureRender stability',False)
  if control:break
  time.sleep(.05)
 if not control:raise RuntimeError('Target control unavailable')
 pid=control.GetPID();control.QueueCapture(1,2);deadline=time.monotonic()+150
 while time.monotonic()<deadline and control.Connected():
  msg=control.ReceiveMessage(None)
  if msg.type==rd.TargetControlMessageType.NewCapture:
   path=Path(msg.newCapture.path);captures.append(dict(path=str(path),frame=msg.newCapture.frameNumber,bytes=path.stat().st_size));(o/'captures.json').write_text(json.dumps(dict(pid=pid,captures=captures),indent=2))
   if len(captures)==2:break
  elif msg.type==rd.TargetControlMessageType.Disconnected:break
  else:time.sleep(.02)
 captures=[dict(path=str(p),bytes=p.stat().st_size) for p in sorted(o.glob('*.rdc'))]
 (o/'captures.json').write_text(json.dumps(dict(pid=pid,captures=captures),indent=2))
 if len(captures)!=2:raise RuntimeError('Expected two consecutive captures')
 print(json.dumps(dict(captures=captures)),flush=True)
 code=0
except Exception:
 (o/'capture-error.txt').write_text(traceback.format_exc());code=1
finally:
 if control:control.Shutdown()
 try:pyrenderdoc.Config().Close()
 except Exception:pass
 os._exit(code)
