from pathlib import Path
import os,sys,json,shutil,xml.etree.ElementTree as ET,zipfile
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
from build_provenance import verify,digest
os.environ.update(managed_environment(o/'tmp'));rows=json.loads((o/'checks.json').read_text()) if (o/'checks.json').exists() else []
baseline=r/'docs/acceptance/nr/evidence/2026-11-09/bounded-development-cache/validation.zip'
with zipfile.ZipFile(baseline) as archive:prior=json.loads(archive.read('builds.json'))
for c in sys.argv[1:] or ['release','debug']:
 assert c in ['release','debug'] and not any(x['configuration']==c for x in rows)
 b=r/('build/ninja-msvc-'+c);verify(r,json.loads((b/'build-provenance.json').read_text()))
 shaders={p:h for p,h in prior[c]['products'].items() if Path(p).parent==b/'shaders' and p.endswith('.spv')}
 assert len(shaders)==675 and all(digest(Path(p))==sha for p,sha in shaders.items())
 command=['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe','--test-dir',str(b),'-R',r'^(AzureAssets\.(ImageFormats|ExtendedImageFormats|RoundTrip)|AzureRender\.MaterialTextureSharing)$','--output-on-failure','--no-tests=error','--output-junit',str(o/(c+'-checks.xml'))]
 execution=guarded_run(r/'build',o.name,command,120);shutil.copyfile(o/'process.log',o/(c+'-checks.log'))
 assert execution['status']=='exited' and execution['exitCode']==0,(execution,(o/'process.log').read_text())
 cases=ET.parse(o/(c+'-checks.xml')).getroot().findall('testcase');assert len(cases)==4
 assert all(x.find('failure') is None and x.find('skipped') is None for x in cases)
 rows.append(dict(configuration=c,execution=execution,cases=[x.attrib for x in cases],shadersUnchanged=675));(o/'checks.json').write_text(json.dumps(rows,indent=2));print(c,'4 affected checks passed, 675 shaders unchanged',flush=True)
