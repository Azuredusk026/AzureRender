from pathlib import Path
import os,sys,json,subprocess,hashlib,zipfile,re
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,write_json,tracked_paths,measure
from artifact_cleanup import remove_artifact
from build_provenance import verify,digest
os.environ.update(managed_environment(o/'tmp'))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
diff=subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL);assert hashlib.sha256(diff).hexdigest()=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
builds={}
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);m=json.loads((b/'build-provenance.json').read_text());verify(r,m);builds[c]=dict(manifestSha256=digest(b/'build-provenance.json'),source=m['source'],products=m['products'])
checks=json.loads((o/'checks.json').read_text());assert len(checks)==2 and sum(len(x['cases']) for x in checks)==8
assert 'must transfer the existing pixel allocation' in (o/'red-test.log').read_text()
e=r/'docs/acceptance/nr/evidence/2026-11-09/owned-image-conversion';e.mkdir(parents=True,exist_ok=True)
sources=['src/assets/GltfLoader.cpp','src/assets/image/ImageCodec.cpp','src/assets/image/ImageCodec.hpp','tests/ImageCodecTests.cpp']
with zipfile.ZipFile(e/'validation.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(o.rglob('*')):
  if p.is_file() and p.suffix in ['.py','.json','.log','.xml'] and 'tmp' not in p.relative_to(o).parts:archive.write(p,'task/'+p.relative_to(o).as_posix())
 for name in sources:archive.write(r/name,'source/'+name)
 archive.writestr('builds.json',json.dumps(builds,indent=2))
assert (e/'validation.zip').stat().st_size<8*2**20
tracked=tracked_paths(r);cleanup=[]
if (o/'tmp').exists():
 size,_=remove_artifact(r/'build',o/'tmp',tracked,apply=True);cleanup.append(dict(path=str(o/'tmp'),logicalBytes=size))
result=dict(status='implemented-targeted-checks-passed',baselineCommit='047092937f2d80aa1eb43d4af651c318b2b36023',run=o.name,checks=checks,builds={c:dict(manifestSha256=m['manifestSha256'],sourceCount=len(m['source'])) for c,m in builds.items()},sourceHashes={name:digest(r/name) for name in sources},shadersUnchangedPerConfiguration=675,nativeCaptureCount=0,frameTimingProcessCount=0,ownershipContract='Valid UInt8 rvalue conversion preserves the original pixel allocation and byte values; borrowed conversion preserves its input; high precision conversion uses the same numeric path',fullSceneLoadingBenefitMeasured=False,formalPerformancePassed=False,visualStatus='failed-user-review',protectedUserDiffSha256=hashlib.sha256(diff).hexdigest(),cleanup=cleanup,remainingRunBytes=measure(o),archiveBytes=(e/'validation.zip').stat().st_size,archiveSha256=digest(e/'validation.zip'))
write_json(e/'results.json',result);write_json(o/'results.json',result)
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-09-owned-image-conversion.md','docs/development/image-conversion-ownership.md','docs/acceptance/nr/owned-image-conversion.md']:
 p=r/name
 for link in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in link and not link.startswith('#'):assert (p.parent/link.split('#')[0]).exists(),(name,link)
print(json.dumps(dict(status=result['status'],checks=8,remainingRunBytes=result['remainingRunBytes'],archiveBytes=result['archiveBytes']),indent=2))
