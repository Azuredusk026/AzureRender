from pathlib import Path
import os,sys,subprocess,json,time
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'))
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',*sys.argv[1:]],env=env).returncode)
label=sys.argv[-1]
if label=='red':
 with (o/'red-build.log').open('wb') as log:subprocess.run(['cmake','--build','build/ninja-msvc-release','--target','AzureImageCodecTests','-j','3'],stdout=log,stderr=subprocess.STDOUT,check=True)
 with (o/'red-test.log').open('wb') as log:result=subprocess.run(['build/ninja-msvc-release/AzureImageCodecTests.exe'],stdout=log,stderr=subprocess.STDOUT)
 print((o/'red-test.log').read_text(),flush=True);assert result.returncode==1
else:
 assert label in ['Release','Debug'];b=r/('build/ninja-msvc-'+label.lower());command=[sys.executable,'-X','utf8','tools/build_provenance.py','build','--build-dir',str(b),'--config',label]
 for target in ['AzureImageCodecTests','AzureExtendedImageFormatsTests','AzureMaterialTextureSharingTests','AzureAssetRoundTripTests']:command+=['--test-target',target]
 with (o/(label.lower()+'-build.log')).open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 (o/(label.lower()+'-build.json')).write_text(json.dumps(dict(exitCode=result.returncode,command=command),indent=2));print(label,result.returncode,flush=True);raise SystemExit(result.returncode)
