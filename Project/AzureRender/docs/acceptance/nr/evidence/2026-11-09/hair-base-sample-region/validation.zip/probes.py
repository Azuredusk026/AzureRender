from pathlib import Path
import struct,subprocess
from dxbc_util import chunks,words,instructions,opcode,inst,dest,source,imm,fbits,rebuild,checksum
out=Path(__file__).resolve().parent
def native_probe(raw,component,shift):
    assert checksum(raw)==raw[4:20]
    parts=chunks(raw);index=next(i for i,(kind,_) in enumerate(parts) if kind in [b'SHEX',b'SHDR'])
    w=words(parts[index][1]);items=list(instructions(w))
    declarations=[item for item in items if item[2]==opcode('DCL_TEMPS')];assert len(declarations)==1
    capture=w[declarations[0][1]+1];scratch=capture+1;w[declarations[0][1]+1]=capture+2
    samples=[]
    for pc,at,op,n in items:
        if op!=opcode('SAMPLE_B'):continue
        operand=at+1
        while w[operand-1]&0x80000000:operand+=1
        token=w[operand]
        resource16=any(((w[i]>>12)&255)==7 and w[i+1]==16 for i in range(operand+2,at+n-1))
        if ((token>>12)&255)==0 and w[operand+1]==9 and resource16:samples.append((at,n))
    assert len(samples)==1,samples
    returns=[item for item in items if item[2]==opcode('RET')];assert len(returns)==1
    extra=[]
    for target,offset in [(1,shift),(2,shift+6)]:
        extra+=inst('USHR',dest(scratch),source(capture,component),imm(offset))
        extra+=inst('AND',dest(scratch),source(scratch),imm(63))
        extra+=inst('UTOF',dest(scratch),source(scratch))
        extra+=inst('MUL',dest(scratch),source(scratch),imm(fbits(1/64)))
        extra+=inst('MOV',dest(0,target,True),source(scratch))
    end=returns[0][1];w[end:end]=extra
    at,n=samples[0];w[at+n:at+n]=inst('MOV',dest(capture,7),[2|(1<<2)|(0xe4<<4)|(1<<20),9])
    w[1]=len(w);parts[index]=(parts[index][0],struct.pack('<'+'I'*len(w),*w))
    return rebuild(raw,parts)

def prepare_vulkan():
    original=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261107-191143-hair-gradient-region-08b1f9/original-hair.spvasm').read_text()
    assert '%8245 = OpImageSampleImplicitLod %v4float %8243 %8244' in original
    cases=[]
    for component in range(3):
        for shift in [0,12,24]:
            name=f'sample-{component}-{shift}'
            text=original
            declarations=f'''%sample_probe_scale = OpConstant %float 0.015625
%sample_probe_mask = OpConstant %uint 63
%sample_probe_shift_r = OpConstant %uint {shift}
%sample_probe_shift_g = OpConstant %uint {shift+6}
'''
            start=text.index('       %main = OpFunction');text=text[:start]+declarations+text[start:]
            start=text.index('%main = OpFunction');end=text.index('OpFunctionEnd',start)
            body=text[start:end];assert body.count('OpReturn\n')==1
            probe=f'''%sample_probe_value = OpCompositeExtract %float %8245 {component}
%sample_probe_bits = OpBitcast %uint %sample_probe_value
%sample_probe_rshift = OpShiftRightLogical %uint %sample_probe_bits %sample_probe_shift_r
%sample_probe_gshift = OpShiftRightLogical %uint %sample_probe_bits %sample_probe_shift_g
%sample_probe_rbits = OpBitwiseAnd %uint %sample_probe_rshift %sample_probe_mask
%sample_probe_gbits = OpBitwiseAnd %uint %sample_probe_gshift %sample_probe_mask
%sample_probe_rf = OpConvertUToF %float %sample_probe_rbits
%sample_probe_gf = OpConvertUToF %float %sample_probe_gbits
%sample_probe_r = OpFMul %float %sample_probe_rf %sample_probe_scale
%sample_probe_g = OpFMul %float %sample_probe_gf %sample_probe_scale
%sample_probe_original = OpLoad %v4float %outputColor
%sample_probe_b = OpCompositeExtract %float %sample_probe_original 2
%sample_probe_a = OpCompositeExtract %float %sample_probe_original 3
%sample_probe_color = OpCompositeConstruct %v4float %sample_probe_r %sample_probe_g %sample_probe_b %sample_probe_a
OpStore %outputColor %sample_probe_color
OpReturn
'''
            text=text[:start]+body.replace('OpReturn\n',probe)+text[end:]
            (out/(name+'.spvasm')).write_text(text)
            sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
            for command in [[str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/(name+'.spvasm')),'-o',str(out/(name+'.spv'))],
                            [str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/(name+'.spv'))]]:
                subprocess.run(command,check=True)
            cases.append(dict(name=name,component=component,shift=shift))
    return cases

if __name__=='__main__':
    import json
    (out/'cases.json').write_text(json.dumps(prepare_vulkan(),indent=2))
