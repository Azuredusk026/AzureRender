from pathlib import Path
import hashlib,json,zipfile
out=Path(__file__).resolve().parent;root=out.parents[2]
report=json.loads((out/'results.json').read_text())
report['artifacts']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.suffix in ['.py','.spv','.dxbc','.shader']}
report['productionChanged']=False
evidence=root/'docs/acceptance/nr/evidence/2026-11-09/hair-base-sample-region'
evidence.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(evidence/'validation.zip','w',zipfile.ZIP_DEFLATED,6) as package:
    for p in out.iterdir():
        if p.is_file() and p.suffix in ['.py','.json','.spv','.dxbc','.shader','.spvasm','.hpp','.txt','.log']:package.write(p,p.name)
assert (evidence/'validation.zip').stat().st_size<8*1024*1024
report['archiveSha256']=hashlib.sha256((evidence/'validation.zip').read_bytes()).hexdigest()
(evidence/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(archiveBytes=(evidence/'validation.zip').stat().st_size,archiveSha256=report['archiveSha256']),indent=2))
