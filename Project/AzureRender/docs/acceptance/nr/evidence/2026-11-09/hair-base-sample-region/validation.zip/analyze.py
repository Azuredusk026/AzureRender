from pathlib import Path
import json,struct,math
out=Path(__file__).resolve().parent
report=json.loads((out/'probe-results.json').read_text())
assert report['status']=='qualified' and len(report['captures'])==2
samples={}
for capture in report['captures']:
    assert len(capture['runs'])==9 and capture['baselineRestored']
    assert all(row['qualified'] for row in capture['runs'])
    words=[[0,0,0] for _ in report['points']]
    for row in capture['runs']:
        component=row['case']['component'];shift=row['case']['shift']
        assert len(row['values'])==len(words)
        for index,value in enumerate(row['values']):words[index][component]|=value<<shift
    assert all(0<=word<=0xffffffff for row in words for word in row)
    samples[capture['label']]=words
rows=[]
for index,pixel in enumerate(report['points']):
    native=samples['native'][index];vulkan=samples['vulkan'][index]
    decode=lambda row:[struct.unpack('<f',struct.pack('<I',value))[0] for value in row]
    a=decode(native);b=decode(vulkan)
    assert all(math.isfinite(v) and 0<=v<=1 for v in a+b)
    rows.append(dict(pixel=pixel,nativeBits=native,vulkanBits=vulkan,native=a,vulkan=b,
                     exact=native==vulkan,maximumAbsolute=max(abs(x-y) for x,y in zip(a,b))))
result=dict(status='qualified-base-sample-comparison',points=len(rows),
    exactRgbPoints=sum(row['exact'] for row in rows),differentRgbPoints=sum(not row['exact'] for row in rows),
    maximumAbsolute=max(row['maximumAbsolute'] for row in rows),rows=rows,qualification=report,
    scope='Original fragment flow and discard retained. Blue channel of the full 290x310 crop must remain bitwise unchanged for every probe. Actual base sample RGB only; no complete quality claim.')
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['rows','qualification']},indent=2))
