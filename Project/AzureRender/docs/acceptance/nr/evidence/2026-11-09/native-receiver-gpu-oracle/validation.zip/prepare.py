from pathlib import Path
import json,runpy,contextlib,io,numpy as np,subprocess,sys
r=Path.cwd().resolve();o=r/'build/runs/20261109-172812-native-receiver-gpu-oracle-d9e5ba';old=r/'build/runs/20261109-164916-hair-receiver-precision-73ea3d';sys.path.insert(0,str(r/'tools'))
from artifact_budget import check
assert check(r/'build',run=o,planned=16*1024**2)['allowed']
with contextlib.redirect_stdout(io.StringIO()):d=runpy.run_path(str(old/'receiver_scope.py'))
keep=d['valid'];x=d['x'][keep];y=d['y'][keep];q=d['q'][keep];uv=d['uv'][keep];c3=d['c3'];count=len(x)
queries=np.zeros((count,3,4),dtype='<f4');queries[:,0,:2]=uv;queries[:,0,2]=q[:,2];queries[:,1,0]=x;queries[:,1,1]=y;queries[:,1,2]=np.float32(4*c3[233,0]*4096);queries[:,1,3]=np.float32(4*c3[233,0]*2048);queries[:,2]=c3[218];queries.tofile(o/'queries.bin');d['expected'][keep].tofile(o/'expected.u8');np.stack([x,y],axis=1).astype('<u4').tofile(o/'pixels.bin')
(o/'fixture.json').write_text(json.dumps(dict(width=4096,height=2048,forwardDepthPath=str(d['a']/'native-t2.bin'),queryPath=str(o/'queries.bin'),samples=count),indent=2))
s=(r/'tests/ObjectShadowFilteringGpuTests.cpp').read_text();s=s.replace('if(argc<2||argc>3)','if(argc!=4)').replace('if(argc==3){','if(argc>=3){')
a=s.index('        for(const auto& query:fixture.at("queries"))');b=s.index('        if(queries.size()',a)
s=s[:a]+'''        const auto raw=readBinaryFile(fixture.at("queryPath").get<std::string>());
        if(raw.size()%(3*sizeof(Vec4)))throw std::runtime_error("Invalid binary query stride");
        queries.resize(raw.size()/sizeof(Vec4));std::memcpy(queries.data(),raw.data(),raw.size());
        expected.resize(queries.size()/3,Vec4{});
'''+s[b:];s=s.replace('for(unsigned i=0;i<count;++i)for(unsigned c=0;c<4;++c){','for(unsigned i=0;i<std::min(count,11U);++i)for(unsigned c=0;c<4;++c){')
s=s.replace('    cleanup.reset();if(host.errors.load())', '''    {std::ofstream raw(argv[3],std::ios::binary);raw.write(reinterpret_cast<const char*>(actual+11),static_cast<std::streamsize>((count-11)*sizeof(Vec4)));}
    cleanup.reset();if(host.errors.load())''')
s=s.replace('Object shadow GPU: ','Receiver diagnostic collection: ');(o/'collector.cpp').write_text(s)
h=(r/'shaders/object_shadow.glsl').read_text();assert h.count('vec4 reversed=1.0-objectShadowGather')==1;h=h.replace('vec4 reversed=1.0-objectShadowGather','vec4 reversed=objectShadowGather').replace('if(any(lessThan(pixel,lo))||any(greaterThanEqual(pixel,hi)))return 1.0;','if(any(lessThan(pixel,lo))||any(greaterThanEqual(pixel,hi)))return 0.0;');(o/'object_shadow.glsl').write_text(h);(o/'filter.comp').write_text((r/'shaders/object_shadow_filter_test.comp').read_text())
n='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe';lines=subprocess.check_output([n,'-C',str(r/'build/ninja-msvc-release'),'-t','commands','AzureObjectShadowFilteringGpuTests'],text=True).splitlines();comp=next(v for v in lines if 'cl.exe' in v and 'ObjectShadowFilteringGpuTests.cpp' in v);link=lines[-1].split(' -- ',1)[1].removesuffix('"')
oldobj=r'CMakeFiles\AzureObjectShadowFilteringGpuTests.dir\tests\ObjectShadowFilteringGpuTests.cpp.obj';comp=comp.replace(oldobj,str(o/'collector.obj')).replace(r'/FdCMakeFiles\AzureObjectShadowFilteringGpuTests.dir'+chr(92),'/Fd'+str(o/'compiler.pdb')).replace(str(r/'tests/ObjectShadowFilteringGpuTests.cpp'),str(o/'collector.cpp'));comp+=' -I'+str(r/'tests')
link=link.replace(oldobj,str(o/'collector.obj'))
for suffix in ['exe','lib','pdb']:link=link.replace('AzureObjectShadowFilteringGpuTests.'+suffix,str(o/('collector.'+suffix)))
(o/'compile-command.txt').write_text(comp);(o/'link-command.txt').write_text(link)
(o/'scope.json').write_text(json.dumps(dict(samples=count,excluded=len(d['x'])-count,scope='Original native reverse-D16 texture and recorded CPU-derived receiver queries; diagnostic output only',sourceInputs=d['inputs']),indent=2));print('Prepared',count,'receiver queries without copying source textures')
