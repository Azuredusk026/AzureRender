from pathlib import Path
import os,sys,subprocess,json,time
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
os.environ.update(managed_environment(o/'tmp'))
if '--inside' not in sys.argv:
 os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 result=guarded_run(r/'build',o.name,[str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],300);(o/'grouped-execution.json').write_text(json.dumps(result,indent=2));print(result);raise SystemExit(result['exitCode'])
with (o/'grouped-build.log').open('wb') as log:
 for name in []:
  command=(o/name).read_text();subprocess.run(command,cwd=r/'build/ninja-msvc-release',shell=True,stdout=log,stderr=subprocess.STDOUT,check=True)
 for command in [['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe','-I'+str(o),str(o/'grouped.comp'),'-o',str(o/'grouped.spv')],['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe','--target-env','vulkan1.3',str(o/'grouped.spv')]]:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer');os.environ.pop('VK_LAYER_ENABLES',None);os.environ['PATH']=str(r/'build/ninja-msvc-release')+';'+os.environ['PATH']
for k in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(k,None)
with (o/'grouped-collection.log').open('wb') as log:p=subprocess.run([str(o/'collector.exe'),str(o/'grouped.spv'),str(o/'receiver-fixture.json'),str(o/'grouped-output.bin')],stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(p.returncode)
