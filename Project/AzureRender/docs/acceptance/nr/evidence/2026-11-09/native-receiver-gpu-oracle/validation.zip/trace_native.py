from pathlib import Path
import json,time,traceback,os
import renderdoc as rd
r=Path('D:/Projects/FYP/Project/AzureRender');o=Path(os.environ['AZURE_RECEIVER_TASK']);capture=r/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc';report=dict(status='starting',points=[]);cap=None;c=None
try:
 try:pyrenderdoc.Config().Close()
 except (AttributeError,NameError):pass
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(capture),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 for x,y in [(1304,155),(1245,257),(1324,289)]:
  c.SetFrameEvent(699,True);p=c.GetPipelineState();target=p.GetOutputTargets()[0].resource;py=1439-y;pixel=list(c.PickPixel(target,x,py,rd.Subresource(),rd.CompType.Typeless).floatValue)
  args=rd.DebugPixelInputs();args.primitive=0;trace=None;row=dict(pixel=[x,y],actualOutput=pixel,changes=[]);start=time.monotonic();steps=0
  try:
   trace=c.DebugPixel(x,py,args);assert trace and trace.debugger
   while True:
    states=c.ContinueDebug(trace.debugger)
    if not states:break
    for state in states:
     steps+=1
     if 0<=state.nextInstruction<=28 or 293<=state.nextInstruction<=307 or 337<=state.nextInstruction<=366:
      for change in state.changes:
       v=change.after;row['changes'].append(dict(instruction=state.nextInstruction,name=v.name,values=list(v.value.f32v)[:max(1,v.rows*v.columns)]))
    if steps>20000 or time.monotonic()-start>45:raise RuntimeError('Native producer trace exceeded its bound')
  finally:
   if trace:c.FreeTrace(trace)
  row['steps']=steps;row['seconds']=time.monotonic()-start;report['points'].append(row);(o/'native-producer-trace.json').write_text(json.dumps(report,indent=2))
 report['status']='traced';report['debugMessages']=[m.description for m in c.GetDebugMessages()][:30]
except BaseException:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (o/'native-producer-trace.json').write_text(json.dumps(report,indent=2))
os._exit(0 if report['status']=='traced' else 1)
