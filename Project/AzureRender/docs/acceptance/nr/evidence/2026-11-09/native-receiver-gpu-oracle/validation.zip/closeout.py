from pathlib import Path
import sys,os,json,hashlib,zipfile,subprocess
import numpy as np
r=Path.cwd().resolve(); o=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,tracked_paths
from artifact_cleanup import remove_artifact
from build_provenance import verify
os.environ.update(managed_environment(o/'tmp'))
expected=np.frombuffer((o/'expected.u8').read_bytes(),dtype=np.uint8).astype(np.int32)
results=[]
for mode in ['filter','receiver','fused','grouped']:
 actual=np.rint(np.clip(np.fromfile(o/(mode+'-output.bin'),dtype=np.float32).reshape(-1,4)[:,2],0,1)*255).astype(np.int32)
 assert len(actual)==len(expected)
 delta=np.abs(actual-expected)
 results.append(dict(mode=mode,samples=len(actual),exactPixels=int((delta==0).sum()),pixelsOverOneByte=int((delta>1).sum()),maximumByteError=int(delta.max())))
assert [(x['exactPixels'],x['pixelsOverOneByte'],x['maximumByteError']) for x in results]==[(48854,221,34)]+[(49082,40,21)]*3
checks={}
for config in ['debug','release']:
 p=r/'build'/('ninja-msvc-'+config)/'build-provenance.json'
 verify(r,json.loads(p.read_text(encoding='utf-8')));checks[config]='passed'
paths=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*paths],cwd=r)).hexdigest()
assert protected=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8',protected
for p in o.glob('*collection.log'):
 s=p.read_text(errors='replace');assert 'VK_LAYER_KHRONOS_validation' in s
 assert not any(x in s for x in ['VUID-','SYNC-HAZARD','Validation Error'])
e=r/'docs/acceptance/nr/evidence/2026-11-09/native-receiver-gpu-oracle';e.mkdir(parents=True,exist_ok=True)
report=dict(status='diagnosis-only-region-not-passed',results=results,traceQualification=json.loads((o/'trace-qualification.json').read_text()),primaryBuilds=checks,protectedDiffSha256=protected,newPlayerProcesses=0,newGameCaptureProcesses=0)
(o/'comparison.json').write_text(json.dumps(results,indent=2)+'\n')
with zipfile.ZipFile(e/'validation.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(o.iterdir()):
  if p.is_file() and p.suffix in ['.py','.cpp','.comp','.glsl','.json','.txt','.log'] and p.name not in ['budget.json']:
   z.write(p,p.name)
report['evidenceSha256']=hashlib.sha256((e/'validation.zip').read_bytes()).hexdigest()
report['evidenceBytes']=(e/'validation.zip').stat().st_size
assert report['evidenceBytes']<8*1024*1024
(e/'results.json').write_text(json.dumps(report,indent=2)+'\n')
tracked=tracked_paths(r)
cleanup=[]
for p in [o/'collector.exe',o/'collector.obj',*o.glob('*.spv'),o/'tmp']:
 if p.exists():
  assert p.resolve().is_relative_to(o.resolve())
  cleanup.append(remove_artifact(r/'build',p,tracked,apply=True))
(o/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
