from pathlib import Path
r=Path.cwd()
p=r/'src/render/ShadowTileBounds.hpp';s=p.read_text();s=s.replace('    unsigned objectCapacity_{};','    unsigned objectCapacity_{};\n    unsigned tilesPerGroup_=1;',1).replace('unsigned extent,unsigned objectCapacity=0){','unsigned extent,unsigned objectCapacity=0,unsigned tilesPerGroup=1){',1).replace('objectCapacity>kObjectShadowCapacity)','objectCapacity>kObjectShadowCapacity||(tilesPerGroup!=1&&tilesPerGroup!=8))',1).replace('tiles_=extent/8;objectCapacity_=objectCapacity;','tiles_=extent/8;objectCapacity_=objectCapacity;tilesPerGroup_=tilesPerGroup;',1).replace('commands.dispatch(tiles_,tiles_,1);','commands.dispatch((tiles_+tilesPerGroup_-1)/tilesPerGroup_,tiles_,1);',1).replace('    const rhi::GpuBuffer& buffer()const','    unsigned tilesPerGroup()const noexcept{return tilesPerGroup_;}\n    const rhi::GpuBuffer& buffer()const',1).replace('tiles_=0;objectCapacity_=0;','tiles_=0;objectCapacity_=0;tilesPerGroup_=1;',1);p.write_text(s)
p=r/'shaders/shadow_bounds.comp';s=p.read_text();s=s.replace('layout(local_size_x=4,local_size_y=4) in;','#if defined(AZURE_SHADOW_BOUNDS_BATCH)\nlayout(local_size_x=128,local_size_y=1) in;\n#else\nlayout(local_size_x=4,local_size_y=4) in;\n#endif',1).replace('shared vec2 tileBounds[16];','#if defined(AZURE_SHADOW_BOUNDS_BATCH)\nshared vec2 tileBounds[128];\n#else\nshared vec2 tileBounds[16];\n#endif',1)
m='''    ivec2 tile=ivec2(gl_WorkGroupID.xy),base=tile*8+ivec2(gl_LocalInvocationID.xy)*2;
    vec4 depths=textureGather(sourceDepth,(vec2(base)+1.0)/vec2(textureSize(sourceDepth,0)));
    uint i=gl_LocalInvocationIndex;''';assert m in s;s=s.replace(m,'''#if defined(AZURE_SHADOW_BOUNDS_BATCH)
    uint i=gl_LocalInvocationIndex,sampleIndex=i&15u;
    ivec2 tile=ivec2(int(gl_WorkGroupID.x*8u+i/16u),int(gl_WorkGroupID.y));
    bool valid=tile.x<textureSize(sourceDepth,0).x/8;
    ivec2 base=tile*8+ivec2(int(sampleIndex&3u),int(sampleIndex/4u))*2;
    vec4 depths=vec4(1);
    if(valid)depths=textureGather(sourceDepth,(vec2(base)+1.0)/vec2(textureSize(sourceDepth,0)));
#else
'''+m+''' 
#endif''',1)
m='        if(i<stride)tileBounds[i]=vec2(min(tileBounds[i].x,tileBounds[i+stride].x),max(tileBounds[i].y,tileBounds[i+stride].y));';assert m in s;s=s.replace(m,'''#if defined(AZURE_SHADOW_BOUNDS_BATCH)
        if(sampleIndex<stride)tileBounds[i]=vec2(min(tileBounds[i].x,tileBounds[i+stride].x),max(tileBounds[i].y,tileBounds[i+stride].y));
#else
'''+m+'\n#endif',1)
m='    if(i==0u)result.values[tile.y*(textureSize(sourceDepth,0).x/8)+tile.x]=tileBounds[0];';assert m in s;s=s.replace(m,'''#if defined(AZURE_SHADOW_BOUNDS_BATCH)
    if(sampleIndex==0u&&valid)result.values[tile.y*(textureSize(sourceDepth,0).x/8)+tile.x]=tileBounds[i];
#else
'''+m+'\n#endif',1);s=s.replace('    uint i=gl_LocalInvocationIndex; \n','    uint i=gl_LocalInvocationIndex;\n');p.write_text(s)
p=r/'src/scenes/CharacterSceneRenderer.cpp';s=p.read_text();s='''#if defined(AZURE_BATCHED_SHADOW_BOUNDS)
static constexpr unsigned kShadowBoundsTilesPerGroup=8;
#else
static constexpr unsigned kShadowBoundsTilesPerGroup=1;
#endif
'''+s
m='bounds->initialize(readBinaryFile(shaderDirectory_+"/shadow_bounds.comp.spv"),shadowImageView_,shadowSampler_,context.shadowMapSize,objectShadowPrepared_?kObjectShadowCapacity:0);';assert m in s;s=s.replace(m,'bounds->initialize(readBinaryFile(shaderDirectory_+(kShadowBoundsTilesPerGroup==8?"/shadow_bounds_batch.comp.spv":"/shadow_bounds.comp.spv")),shadowImageView_,shadowSampler_,context.shadowMapSize,objectShadowPrepared_?kObjectShadowCapacity:0,kShadowBoundsTilesPerGroup);',1)
m='         << "  \\"computeSkinningVertexWords\\": "'.replace('\\\\','\\');lines=s.splitlines(keepends=True);at=next(i for i,l in enumerate(lines) if '<< GpuSkinnedVertex::wordCount' in l);lines.insert(at+1,'         << "  \\"shadowBoundsTilesPerGroup\\": " << (shadowBounds_.at(currentFrame_)?shadowBounds_.at(currentFrame_)->tilesPerGroup():0) << ",\\n"\n'.replace('\\\\','\\'));p.write_text(''.join(lines))
p=r/'tests/ShadowTileBoundsBatchTests.cpp';s=p.read_text().replace('#include <iostream>','#include <iostream>\n#include <algorithm>');p.write_text(s)
o=r/'build/runs/20261109-034725-shadow-tile-batching-90fe3c';old=r/'build/runs/20261109-030048-bounded-compute-reductions-fec9f6'
s=(old/'candidate-source/tests/ShadowTileBoundsSubgroupGpuTests.cpp').read_text();s=s.replace('    if(!backend.supportsComputeSubgroupArithmetic())return 77;\n','').replace('    const bool timing=argc==3&&std::string(argv[2])=="--timing";','    const bool timing=argc==3&&std::string(argv[2])=="--timing",tailCase=argc==3&&std::string(argv[2])=="--tail";').replace('if(argc==3&&!timing)','if(argc==3&&!timing&&!tailCase)').replace('timing?4096:64','timing?4096:tailCase?40:64').replace('std::vector<unsigned>{0,1,2,1,0}:std::vector<unsigned>{0,1,2}','std::vector<unsigned>{0,1,1,0}:std::vector<unsigned>{0,1,0}').replace('/shadow_bounds_subgroup.comp.spv','/shadow_bounds_batch.comp.spv').replace('side,1,mode!=2','side,1,mode?8U:1U').replace('subgroup','batch').replace('Subgroup','Batch').replace('forced shared fallback','tail-safe groups').replace('Shared, batch and forced fallback','Single-tile and batched');(r/'tests/ShadowTileBoundsBatchGpuTests.cpp').write_text(s)
p=r/'CMakeLists.txt';s=p.read_text();m='compile_shader("${SHADER_SOURCE_DIR}/shadow_bounds.comp")';assert m in s;s=s.replace(m,m+'\nif(AZURE_ENABLE_BATCHED_SHADOW_BOUNDS)\ncompile_shader("${SHADER_SOURCE_DIR}/shadow_bounds.comp" DEFINES AZURE_SHADOW_BOUNDS_BATCH=1 OUTPUT_NAME shadow_bounds_batch.comp)\nendif()',1)
m='    add_test(NAME AzureRender.ShadowTileBoundsBatch COMMAND AzureShadowTileBoundsBatchTests)';assert m in s;s=s.replace(m,m+'''
    if(AZURE_ENABLE_BATCHED_SHADOW_BOUNDS)
        add_executable(AzureShadowTileBoundsBatchGpuTests tests/ShadowTileBoundsBatchGpuTests.cpp)
        target_link_libraries(AzureShadowTileBoundsBatchGpuTests PRIVATE AzureRenderCore)
        add_dependencies(AzureShadowTileBoundsBatchGpuTests AzureRenderShaders)
        add_test(NAME AzureRender.ShadowTileBoundsBatchGpu COMMAND AzureShadowTileBoundsBatchGpuTests "${SHADER_BINARY_DIR}")
        add_test(NAME AzureRender.ShadowTileBoundsBatchTailGpu COMMAND AzureShadowTileBoundsBatchGpuTests "${SHADER_BINARY_DIR}" --tail)
        set_tests_properties(AzureRender.ShadowTileBoundsBatchGpu AzureRender.ShadowTileBoundsBatchTailGpu PROPERTIES LABELS gpu SKIP_RETURN_CODE 77 RUN_SERIAL TRUE TIMEOUT 120)
    endif()
''',1);p.write_text(s)
s=(old/'build.py').read_text();s=s.replace("['cmake','-S',str(root),'-B',str(build)]","['cmake','-S',str(root),'-B',str(build),'-DAZURE_ENABLE_BATCHED_SHADOW_BOUNDS=ON']").replace("['AzureReflectionSpatialFilterTests','AzureReflectionSpatialFilterGpuTests','AzureShadowTileBoundsGpuTests','AzureShadowTileBoundsSubgroupGpuTests','AzureObjectShadowAtlasTests','AzureRenderRenderGraphTests']","['AzureShadowTileBoundsBatchTests','AzureShadowTileBoundsBatchGpuTests','AzureShadowTileBoundsGpuTests','AzureObjectShadowAtlasTests','AzureShadowFilteringGpuTests','AzureRenderRenderGraphTests']");(o/'build.py').write_text(s)
