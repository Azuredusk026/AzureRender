from pathlib import Path
import json,zipfile,sys,xml.etree.ElementTree as ET
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from build_provenance import digest,verify
cases=[]
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);verify(r,json.loads((b/'build-provenance.json').read_text()));assert 'AZURE_ENABLE_BATCHED_SHADOW_BOUNDS:BOOL=ON' in (b/'CMakeCache.txt').read_text()
 for suffix in ['nvidia','intel','adopted']:
  n=c+'-'+suffix+'.xml'
  for x in ET.parse(o/n).getroot().findall('testcase'):
   assert x.find('failure') is None and x.find('skipped') is None;cases.append(dict(receipt=n,name=x.attrib['name']))
assert len(cases)==28
image=json.loads((o/'image-shadow-batch/results.json').read_text());assert len(image['frames'])==4 and all(x['changedPixels']==0 and x['sha256']==x['referenceSha256'] for x in image['frames'])
assert image['metadata']['shadowBoundsTilesPerGroup']==8 and all(image[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationLogClean','zeroAllocator'])
gate=json.loads((o/'micro-gate.json').read_text());assert gate['gatePassed'];cost=json.loads((o/'cost-results-v1.json').read_text());assert cost['bracketStable'] and cost['gpuSavedMs']>0 and cost['gpuReductionFraction']>cost['bracketDriftFraction']
assert json.loads((o/'adoption-checks.json').read_text())['measuredReleaseProductsUnchanged']
cleanup=[json.loads((o/n).read_text()) for n in ['runtime-cleanup.json','identical-png-cleanup.json']]
sources=['CMakeLists.txt','shaders/shadow_bounds.comp','src/render/ShadowTileBounds.hpp','src/scenes/CharacterSceneRenderer.cpp','tests/ShadowTileBoundsBatchTests.cpp','tests/ShadowTileBoundsBatchGpuTests.cpp']
f=r/'docs/acceptance/nr/evidence/2026-11-09/shadow-tile-batching';f.mkdir(parents=True,exist_ok=True)
paths=[p for p in o.glob('*') if p.suffix in ['.json','.log','.xml','.py','.cpp']]
for name in ['image-shadow-batch','cost-v1-baseline-before','cost-v1-candidate','cost-v1-baseline-after']:
 paths.extend(p for p in (o/name).glob('*') if p.is_file() and p.suffix in ['.json','.log','.csv']);paths.extend((o/name).glob('frames-*/capture_manifest.json'))
with zipfile.ZipFile(f/'validation.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for p in sorted(set(paths)):z.write(p,p.relative_to(o).as_posix())
report=dict(sourceBase='32aa23da75f1ce198bd1cb853cf457c1e5b0240a',status='batched-shadow-bounds-integrated-exact-local-gain',tests=cases,passed=28,skipped=0,native=image,microGate=gate,calibration=json.loads((o/'micro-calibration.json').read_text()),cost=cost,scopeDecision=json.loads((o/'scope-decision.json').read_text()),sourceHashes={p:digest(r/p) for p in sources},programs=json.loads((o/'programs-check.json').read_text()),defaultBatch=8,measuredReleaseProductsUnchanged=True,validMicroProcesses=1,calibrationMicroProcesses=1,nativeImageProcesses=1,frameCostProcesses=3,cleanup=dict(files=sum(x['files'] for x in cleanup),logicalBytes=sum(x['logicalBytes'] for x in cleanup)),formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceZipBytes=(f/'validation.zip').stat().st_size,evidenceZipSha256=digest(f/'validation.zip'))
assert report['evidenceZipBytes']<8*1024*1024;(f/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
p=r/'docs/development/artifact-manifest.json';d=json.loads(p.read_text());d['milestones'].insert(0,dict(path='runs/'+o.name,name='阴影分块批处理',status='BatchedBoundsIntegratedExactLocalGain',sourceBase='32aa23d',evidence='docs/acceptance/nr/shadow-tile-batching.md',checksPassed=28,nativeFourFramesExact=True,frameCostProcesses=3,validMicroProcesses=1,calibrationMicroProcesses=1,gpuSavedMs=cost['gpuSavedMs'],kernelReductionFraction=gate['reductionFraction'],reclaimedFiles=report['cleanup']['files'],formalPerformancePassed=False));p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ['passed','cleanup','evidenceZipBytes']}))
