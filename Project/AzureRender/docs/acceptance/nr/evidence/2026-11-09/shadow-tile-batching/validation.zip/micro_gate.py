from pathlib import Path
import os,sys,json,hashlib
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from artifact_maintenance import guarded_run
b=r/'build/ninja-msvc-release';os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['PATH']=str(b)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
for key in ['TEMP','TMP','TMPDIR','SQLITE_TMPDIR']:os.environ[key]=str(o/'tmp')
command=[str(b/'AzureShadowTileBoundsBatchGpuTests.exe'),str(b/'shaders'),'--timing'];execution=guarded_run(r/'build',o.name,command,120);log=(o/'process.log').read_text(errors='replace');(o/'micro-gate.log').write_text(log)
assert execution['status']=='exited' and execution['exitCode']==0,execution
rows=[json.loads(line) for line in log.splitlines() if line.startswith('{"extent"')];assert len(rows)==1;data=rows[0];rows=data['timings'];assert [x['mode'] for x in rows]==[0,1,1,0] and all(x['warmup']==2048 and x['samples']==128 for x in rows)
reference=(rows[0]['meanMs']+rows[3]['meanMs'])/2;candidate=(rows[1]['meanMs']+rows[2]['meanMs'])/2;drift=abs(rows[0]['meanMs']-rows[3]['meanMs'])/reference;gain=1-candidate/reference
report=dict(status='measured',execution=execution,extent=data['extent'],rows=rows,referenceMeanMs=reference,candidateMeanMs=candidate,reductionFraction=gain,referenceDriftFraction=drift,gatePassed=drift<=.05 and gain>=.2,validationTextClean=not any(x in log for x in ['Validation Error:','SYNC-HAZARD','VUID-']),scope='Standalone synthetic 4096-square D32, repeated exact extrema, before/two candidates/after; GPU kernel attribution only; no frame gain claim')
(o/'micro-gate.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['rows','execution']}))
assert report['validationTextClean']
