from pathlib import Path
import json,hashlib,subprocess,stat,shutil
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;target=(o/'baseline-runtime').resolve()
assert target.parent==o and target.is_relative_to(r/'build/runs')
processes=subprocess.run(['powershell','-NoProfile','-Command','Get-Process -Name AzurePlayer -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id'],capture_output=True,text=True)
assert processes.returncode in [0,1] and not processes.stdout.strip() and not processes.stderr.strip()
cost=json.loads((o/'cost-results-v1.json').read_text());assert cost['bracketStable'] and cost['baselineRuntimeVerified']
rows=json.loads((o/'baseline-runtime.json').read_text())['files'];expected={Path(row['path']).resolve() for row in rows};assert len(rows)==675 and set(p.resolve() for p in target.rglob('*') if p.is_file())==expected
assert not subprocess.check_output(['git','ls-files','--',target.relative_to(r).as_posix()]).strip()
for row in rows:
 p=Path(row['path']);assert p.resolve().is_relative_to(target) and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 for parent in [p,*p.parents]:assert not parent.stat().st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT
receipt=r/'build/maintenance/shadow-tile-batching-runtime-cleanup.json';receipt.write_text(json.dumps(dict(status='planned',paths=rows),indent=2));free=shutil.disk_usage(r).free
for row in rows:
 p=Path(row['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];p.unlink()
(target/'shaders').rmdir();target.rmdir()
report=dict(status='applied',files=len(rows),logicalBytes=sum(x['bytes'] for x in rows),freeBeforeBytes=free,freeAfterBytes=shutil.disk_usage(r).free,paths=rows)
receipt.write_text(json.dumps(report,indent=2));(o/'runtime-cleanup.json').write_text(json.dumps(report,indent=2));print(dict(files=report['files'],logicalBytes=report['logicalBytes']))
