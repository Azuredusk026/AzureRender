from pathlib import Path
import json,sys,hashlib,os,subprocess
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from build_provenance import verify,digest
proof=json.loads((o/'cost-products-before.json').read_text());assert all(digest(Path(p))==sha for p,sha in proof.items())
rows=[];env=os.environ.copy();env.update(TEMP=str(o/'tmp'),TMP=str(o/'tmp'),TMPDIR=str(o/'tmp'),SQLITE_TMPDIR=str(o/'tmp'));ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);verify(r,json.loads((b/'build-provenance.json').read_text()));assert 'AZURE_ENABLE_BATCHED_SHADOW_BOUNDS:BOOL=ON' in (b/'CMakeCache.txt').read_text()
 baseline=json.loads((o/(c+'-baseline-shaders.json')).read_text());assert all(digest(b/'shaders'/name)==sha for name,sha in baseline.items())
 command=[ctest,'--test-dir',str(b),'-R',r'^AzureRender\.(ShadowTileBoundsBatch|ObjectShadowAtlas|RenderGraph)$','--output-on-failure','--no-tests=error','--output-junit',str(o/(c+'-adopted.xml'))]
 with (o/(c+'-adopted-checks.log')).open('wb') as f:result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 rows.append(dict(configuration=c,command=command,exitCode=result.returncode,defaultBatch=8,unchangedBaselinePrograms=674));print(c,result.returncode,flush=True);assert result.returncode==0
(o/'adoption-checks.json').write_text(json.dumps(dict(checks=rows,measuredReleaseProductsUnchanged=True),indent=2))
