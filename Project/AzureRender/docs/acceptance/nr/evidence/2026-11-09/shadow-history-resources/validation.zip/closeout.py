from pathlib import Path
import os,sys,json,hashlib,zipfile,shutil,subprocess
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,tracked_paths,write_json
from artifact_cleanup import remove_artifact
from build_provenance import verify,digest
os.environ.update(managed_environment(o/'tmp'))
report=dict(schemaVersion=1,status='resource-contract-passed-runtime-not-integrated',maximumBytes=128*1024*1024,bytesPerPixel=8,nativeTwoWorkflowBytes=1920*1080*8*4,frozenTwoWorkflowBytes=2560*1440*8*4,newNativeImageProcesses=0,newFullFramePerformanceProcesses=0,newFullAssetCopies=0,builds={},gpu=[])
for config in ['release','debug']:
 p=r/('build/ninja-msvc-'+config)/'build-provenance.json';m=json.loads(p.read_text());verify(r,m);shutil.copyfile(p,o/(config+'-build-provenance.json'))
 old=json.loads((r/'build/runs/20261109-195952-temporal-shadow-history-prototype-fa096c'/(config+'-build-provenance.json')).read_text())
 shaders={path:sha for path,sha in old['products'].items() if Path(path).parent.name=='shaders' and path.endswith('.spv')}
 assert len(shaders)==675
 for path,sha in shaders.items():assert m['products'][path]==sha,path
 report['builds'][config]=dict(verified=True,originalShaderCount=675,originalShaderHashesUnchanged=True,newShaders=3,sourceCount=len(m['source']))
 assert json.loads((o/('green-'+config+'-execution.json')).read_text())['exitCode']==0
 for device in ['nvidia','intel']:
  s=(o/(config+'-'+device+'.log')).read_text()
  assert '49152 ownership records' in s and 'zero validation errors and live allocations' in s
  assert not any(x in s for x in ['VUID-','SYNC-HAZARD','Validation Error','Validation Warning'])
  assert ('Using "NVIDIA' if device=='nvidia' else 'Using "Intel') in s
  report['gpu'].append(dict(configuration=config,device=device,tailClears=4,ownershipRecords=49152,slots=2,workflows=2,validationErrors=0,liveAllocationsAfterUnload=0))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
report['protectedDiffSha256']=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest()
assert report['protectedDiffSha256']=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
write_json(o/'results.json',report)
dest=r/'docs/acceptance/nr/evidence/2026-11-09/shadow-history-resources';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
selected=[p for p in sorted(o.iterdir()) if p.is_file() and p.suffix in ['.py','.json','.log']]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in selected:z.write(p,p.name)
assert archive.stat().st_size<8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in selected:assert hashlib.sha256(z.read(p.name)).hexdigest()==digest(p)
report['package']=dict(bytes=archive.stat().st_size,files=len(selected),sha256=digest(archive));write_json(dest/'results.json',report)
before=shutil.disk_usage(r).free;tracked=tracked_paths(r);removed=[]
for p in [o/'tmp',o/'__pycache__']:
 if p.exists():
  assert p.resolve().is_relative_to(o.resolve());removed.append(dict(path=str(p.resolve()),removed=remove_artifact(r/'build',p,tracked,apply=True)))
after=shutil.disk_usage(r).free;write_json(o/'cleanup.json',dict(removed=removed,freeBefore=before,freeAfter=after,observedFreedBytes=after-before));print(json.dumps(report))
