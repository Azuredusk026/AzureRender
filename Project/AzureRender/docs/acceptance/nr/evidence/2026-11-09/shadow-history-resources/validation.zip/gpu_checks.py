from pathlib import Path
import sys,os,json,re
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
os.environ.update(managed_environment(o/'tmp'))
config=sys.argv[1];b=r/('build/ninja-msvc-'+config.lower())
for name,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 for key in ['VK_LAYER_ENABLES','VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
 os.environ.update(VK_LOADER_DRIVERS_SELECT=driver,VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer')
 result=guarded_run(r/'build',o.name,[str(b/'AzureShadowHistoryCacheGpuTests.exe'),str(b/'shaders')],120)
 log=(o/'process.log').read_bytes();stem=config.lower()+'-'+name
 (o/(stem+'.log')).write_bytes(log);(o/(stem+'-execution.json')).write_text(json.dumps(result,indent=2))
 text=log.decode(errors='replace');print(stem,result);print(text[-600:])
 assert result['exitCode']==0
 assert 'Insert instance layer "VK_LAYER_KHRONOS_validation"' in text or 'Insert instance layer VK_LAYER_KHRONOS_validation' in text or 'VK_LAYER_KHRONOS_validation' in text
 assert '49152 ownership records' in text and 'zero validation errors and live allocations' in text
 assert not re.search(r'VUID-|SYNC-HAZARD|Validation Error|Validation Warning',text)
