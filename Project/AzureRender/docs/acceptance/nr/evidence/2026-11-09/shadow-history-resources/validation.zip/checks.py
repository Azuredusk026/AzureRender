from pathlib import Path
import sys,os,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
os.environ.update(managed_environment(o/'tmp'));mode=sys.argv[1];config=sys.argv[2] if len(sys.argv)>2 else 'Release';b=r/('build/ninja-msvc-'+config.lower())
result=guarded_run(r/'build',o.name,[str(b/'AzureShadowHistoryCacheTests.exe')],120)
(o/(mode+'-'+config.lower()+'-execution.json')).write_text(json.dumps(result,indent=2));(o/(mode+'-'+config.lower()+'.log')).write_bytes((o/'process.log').read_bytes());print(result);print((o/'process.log').read_text(errors='replace')[-800:]);assert result['exitCode']==(1 if mode=='red' else 0)
