from pathlib import Path
import numpy as np,json,hashlib,re,time
r=Path.cwd();o=Path(__file__).resolve().parent;a=r/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f';b=r/'build/runs/20261027-002548-native-hair-layer-region-closure-61c105';start=time.monotonic();f=np.float32
names=['producer-cb0.bin','producer-cb1.bin','producer-cb3.bin','native-t0.bin','native-t2.bin','native-t5.bin','native-t6.bin']
inputs={str(a/n):hashlib.sha256((a/n).read_bytes()).hexdigest() for n in names};inputs[str(b/'native-screen-visibility.bin')]=hashlib.sha256((b/'native-screen-visibility.bin').read_bytes()).hexdigest()
c0=np.fromfile(a/'producer-cb0.bin',dtype='<f4').reshape(-1,4);c1=np.fromfile(a/'producer-cb1.bin',dtype='<f4').reshape(-1,4);c3=np.fromfile(a/'producer-cb3.bin',dtype='<f4').reshape(-1,4)
depth=np.memmap(a/'native-t0.bin',dtype='<f4',mode='r',shape=(1440,2560));packed=np.memmap(a/'native-t6.bin',dtype='<u4',mode='r',shape=(1440,2560));identity=np.memmap(a/'native-t5.bin',dtype='<u4',mode='r',shape=(1440,2560));mask=np.memmap(b/'native-screen-visibility.bin',dtype='u1',mode='r',shape=(1440,2560,2));atlas=np.memmap(a/'native-t2.bin',dtype='<u2',mode='r',shape=(2048,4096))
y,x=np.mgrid[130:440,1140:1430];x=x.ravel();displayY=y.ravel();y=1439-displayY;valid=(identity[y,x]>=256)&(identity[y,x]<512);x=x[valid];y=y[valid];displayY=displayY[valid]
def mad(a,b,c):return (np.asarray(a,dtype=np.float64)*np.asarray(b,dtype=np.float64)+np.asarray(c,dtype=np.float64)).astype('<f4')
clipX=f(f(x)*c1[0,2]*f(2)-f(1));clipY=f(f(y)*c1[0,3]*f(2)-f(1));z=depth[y,x]
w=f(-clipY[:,None]*c0[25]);w=mad(clipX[:,None],c0[24],w);w=mad(z[:,None],c0[26],w);w=f(w+c0[27]);world=f(w[:,:3]/w[:,3,None])
p=packed[y,x];uv=np.stack([p&1023,(p>>10)&1023],axis=1).astype('<f4');uv[:,0]/=f(1023);uv[:,1]/=f(1023)
# Destination ZW reads source RG under the recorded DXBC swizzle.
# Validate both packed lanes with the established seven controls.
nxy=f(uv*2-1);ny=f(1-np.abs(nxy).sum(axis=1));normal=np.stack([nxy[:,0],ny,nxy[:,1]],axis=1);fold=ny<0
normal[fold,0]=(1-np.abs(nxy[fold,1]))*np.where(nxy[fold,0]>=0,1,-1);normal[fold,2]=(1-np.abs(nxy[fold,0]))*np.where(nxy[fold,1]>=0,1,-1);normal=f(normal/np.sqrt((normal*normal).sum(axis=1))[:,None])
controls=json.loads((a/'native-receivers.json').read_text());checks=[]
for c in controls:
 ix=np.where((x==c['pixel'][0])&(displayY==c['pixel'][1]))[0]
 if len(ix):
  i=ix[0];checks.append(dict(pixel=c['pixel'],worldError=float(np.max(np.abs(world[i]-c['world']))),normalError=float(np.max(np.abs(normal[i]-c['normal']))),packed=int(p[i])))
report=dict(status='input-layout-check',pixels=len(x),checks=checks,sourceInputs=inputs,seconds=time.monotonic()-start)
(o/'input-layout.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='sourceInputs'},indent=2))

assert len(checks)==7 and len(x)>40000
assert max(v['worldError'] for v in checks)<=2**-15 and max(v['normalError'] for v in checks)<2e-7
asm=(b/'visibility-producer.asm').read_text();disk=np.array([[float(v) for v in row.split(',')] for row in re.findall(r'\{ ([^{}]+)\}',asm)[:16]],dtype='<f4')
phase=((x&3)<<2)|(y&3);rotation=disk[phase,:2];light=c3[203,:3]
weight=f(1-np.clip(f((normal*light).sum(axis=1)),0,.9))
biased=mad(-light, f(weight*c3[188,0])[:,None],world);biased=mad(normal,f(weight*c3[188,1])[:,None],biased)
q=f(biased[:,1,None]*c3[129,:3]);q=mad(biased[:,0,None],c3[128,:3],q);q=mad(biased[:,2,None],c3[130,:3],q);q=f(q+c3[131,:3]);q[:,2]=np.maximum(q[:,2],f(.01));uv=mad(q[:,:2],c3[218,2:],c3[218,:2])
expected=mask[y,x,1];valid=(q[:,0]>0)&(q[:,0]<1)&(q[:,1]>0)&(q[:,1]<1)&(q[:,2]<1)
rows=[]
for quantized in [False,True]:
 fused=False
 count=np.zeros(len(x),dtype='<f4');delta=count.copy()
 for dx,dy in disk[:,2:]:
  rx=f(dx*rotation[:,0]-dy*rotation[:,1]);ry=f(dy*rotation[:,0]+dx*rotation[:,1]);rotated=np.stack([rx,ry],axis=1)
  tap=mad(rotated,f(4*c3[233,0]),uv) if fused else f(uv+f(rotated*f(4*c3[233,0])))
  texel=tap.astype('f8')*[4096,2048]-.5
  if quantized:texel=np.rint(texel*256)/256
  pixel=np.floor(texel).astype('i8');bx,by=pixel[:,0],pixel[:,1];samples=[]
  for ox,oy in [(0,1),(1,1),(1,0),(0,0)]:samples.append(f(atlas[np.clip(by+oy,0,2047),np.clip(bx+ox,0,4095)])/f(65535))
  values=np.stack(samples,axis=1);difference=f(values-q[:,2,None]);count=f(count+(difference>=0).sum(axis=1).astype('f4'));delta=f(delta+np.maximum(difference,0).sum(axis=1,dtype='f4'))
 t=f(f(2*count/f(64))-1);sign=np.sign(t);h=f(1-np.abs(t));cube=f(h*h*h);ratio=np.clip(f(f(delta/np.maximum(count,1))/q[:,2]),0,1);visibility=f(.5-f(.5*sign*f(1-f(cube+f(ratio*f(h-cube))))));visibility[count==0]=1;visibility[~valid]=1
 actual=np.floor(np.clip(visibility,0,1)*255+.5).astype('u1');error=np.abs(actual.astype('i2')-expected.astype('i2'))
 controlsResult=[]
 for c in controls:
  i=np.where((x==c['pixel'][0])&(displayY==c['pixel'][1]))[0][0];controlsResult.append(dict(pixel=c['pixel'],expected=int(expected[i]),actual=int(actual[i]),count=int(count[i]),q=q[i].tolist()))
 rows.append(dict(tapFused=fused,subtexelBits=8 if quantized else None,exactPixels=int((error==0).sum()),pixelsOverOneByte=int((error>1).sum()),maximumByteError=int(error.max()),controls=controlsResult))
report.update(status='offline-precision-scope',variants=rows,seconds=time.monotonic()-start,productionChanged=False,newNativeCaptures=0,qualification='CPU float32 emulation only; fused operations approximate captured arithmetic, GPU proof remains required')
(o/'offline-scope.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(pixels=len(x),variants=[{k:v for k,v in row.items() if k!='controls'} for row in rows],seconds=report['seconds']),indent=2))
