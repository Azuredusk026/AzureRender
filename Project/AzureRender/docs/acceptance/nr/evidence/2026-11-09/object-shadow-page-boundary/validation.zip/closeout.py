from pathlib import Path
import json,hashlib,subprocess,shutil,sys,zipfile,re
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from build_provenance import verify,digest
from artifact_maintenance import write_json,tracked_paths
from artifact_cleanup import remove_artifact
image=json.loads((o/'image-final-page-boundary/results.json').read_text());assert len(image['frames'])==4 and all(a['changedPixels']==0 and a['sha256']==a['referenceSha256'] for a in image['frames']);assert all(image[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationLogClean','zeroAllocator'])
checks=[];shaders={};builds={}
for config in ['release','debug']:
 checks+=json.loads((o/(config+'-filter-checks.json')).read_text());b=r/('build/ninja-msvc-'+config);m=json.loads((b/'build-provenance.json').read_text());verify(r,m);shutil.copyfile(b/'build-provenance.json',o/(config+'-build-provenance.json'));shaders[config]={p.name:digest(p) for p in (b/'shaders').glob('*.spv')};assert len(shaders[config])==675;builds[config]=dict(sourceCount=len(m['source']),products=len(m['products']),verified=True)
assert len(checks)==4 and all(a['execution']['exitCode']==0 and all(a[k] for k in ['validationLayerObserved','validationClean','sourceUnchanged']) for a in checks);assert shaders['release']==shaders['debug']
with zipfile.ZipFile(r/'docs/acceptance/nr/evidence/2026-11-09/compact-vertex-source/validation.zip') as z:
 baseline=json.loads(z.read('restored-release-build-provenance.json'))
 prior={Path(p).name:v for p,v in baseline['products'].items() if p.endswith('.spv') and Path(p).parent.name=='shaders'};assert len(prior)==675
changed=[n for n,v in shaders['release'].items() if prior[n]!=v];assert changed and all(n.endswith('.frag.spv') or n=='object_shadow_filter_test.comp.spv' for n in changed)
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py'];ph=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest();assert ph=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
for rel in ['shaders/object_shadow.glsl','tests/ObjectShadowFilteringGpuTests.cpp','docs/runtime/object-shadow.md','docs/plans/2026-11-09-hair-receiver-precision.md','docs/acceptance/nr/object-shadow-page-boundary.md']:
 p=o/'final-source'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,p)
(o/'original-object-shadow.glsl').write_bytes(subprocess.check_output(['git','show','HEAD:Project/AzureRender/shaders/object_shadow.glsl']))
result=dict(status='page-boundary-fixed-and-verified',baselineCommit='88c6f58',run=o.name,builds=builds,gpuChecks=checks,recordsAndQueriesPerCheck=24,newBoundaryCasesPerCheck=9,originalFrames=image['frames'],projectInputsVerified=1729,originalChangedPixels=0,validationClean=True,nativeAllocatorZero=True,changedPrograms=changed,unchangedVertexAndOtherComputePrograms=True,matching675ProgramsAcrossConfigurations=True,protectedDiffSha256=ph,newFullAssetCopies=0,newGpuResources=0,nativeCostProcesses=0,formalPerformancePassed=False,fullHairRegionPassed=False,overallVisualAcceptance='failed-user-review',offlineScope='49384 source object pixels in a rectangular region; CPU arithmetic emulation is not a GPU equivalence result')
write_json(o/'results.json',result);dest=r/'docs/acceptance/nr/evidence/2026-11-09/object-shadow-page-boundary';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
selected=[p for p in sorted(o.rglob('*')) if p.is_file() and 'tmp' not in p.relative_to(o).parts and p.suffix.lower() in {'.py','.json','.log','.cpp','.glsl','.comp','.md','.d16'}]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in selected:z.write(p,p.relative_to(o).as_posix())
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in selected:assert hashlib.sha256(z.read(p.relative_to(o).as_posix())).hexdigest()==digest(p)
result['package']=dict(path=archive.relative_to(r).as_posix(),sha256=digest(archive),bytes=archive.stat().st_size,files=len(selected));write_json(dest/'results.json',result)
byname={a['frame']:a for a in image['frames']};targets=[o/'tmp',o/'__pycache__']
for p in (o/'image-final-page-boundary').glob('frames-*/*.png'):
 assert digest(p)==byname[p.name]['sha256']==byname[p.name]['referenceSha256'];targets.append(p)
tracked=tracked_paths(r);before=shutil.disk_usage(r).free;removed=[]
for p in targets:
 if p.exists():removed.append(dict(path=str(p.resolve()),removed=remove_artifact(r/'build',p,tracked,apply=True)))
after=shutil.disk_usage(r).free;cleanup=dict(removed=removed,freeBefore=before,freeAfter=after,observedFreedBytes=after-before);write_json(dest/'cleanup.json',cleanup);write_json(o/'cleanup.json',cleanup)
print(json.dumps(dict(package=result['package'],changedPrograms=len(changed),observedFreedBytes=after-before),indent=2))
