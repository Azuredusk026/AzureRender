from pathlib import Path
import json,sys,os,array
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
os.environ.update(managed_environment(o/'tmp'));os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer');os.environ.pop('VK_LAYER_ENABLES',None)
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
w,h=32,16;depth=array.array('H',[65535 if x<16 else 0 for y in range(h) for x in range(w)]);p=o/'boundary-forward.d16';p.write_bytes(depth.tobytes())
queries=[]
for epsilon in [1/1024,1/2048,1/4096]:
 queries.append(dict(input=[[(15.5-epsilon)/w,.5,.5,0],[0,0,0,0],[0,0,.5,1]],expected=[1,0,1,1]))
f=o/'boundary.json';f.write_text(json.dumps(dict(width=w,height=h,forwardDepthPath=str(p),queries=queries),indent=2))
command=[str(r/'build/ninja-msvc-release/AzureObjectShadowFilteringGpuTests.exe'),str(r/'build/ninja-msvc-release/shaders/object_shadow_filter_test.comp.spv'),str(f)]
result=guarded_run(r/'build',o.name,command,120);(o/'boundary-red-execution.json').write_text(json.dumps(result,indent=2));(o/'boundary-red.log').write_bytes((o/'process.log').read_bytes());print(json.dumps(result));print((o/'process.log').read_text(errors='replace')[-600:])
