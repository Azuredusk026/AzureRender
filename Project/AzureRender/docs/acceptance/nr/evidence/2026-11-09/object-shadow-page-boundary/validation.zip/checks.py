from pathlib import Path
import json,os,sys,re
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
from build_provenance import verify,digest,inputs
os.environ.update(managed_environment(o/'tmp'));config=sys.argv[-1];b=r/('build/ninja-msvc-'+config.lower());verify(r,json.loads((b/'build-provenance.json').read_text()));before=inputs(r);rows=[]
for device,pattern in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 os.environ.update(VK_LOADER_DRIVERS_SELECT=pattern,VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer');os.environ.pop('VK_LAYER_ENABLES',None)
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
 command=[str(b/'AzureObjectShadowFilteringGpuTests.exe'),str(b/'shaders/object_shadow_filter_test.comp.spv')]
 result=guarded_run(r/'build',o.name,command,120);log=(o/'process.log').read_text(errors='replace');(o/(config.lower()+'-'+device+'-filter.log')).write_text(log)
 row=dict(configuration=config,device=device,execution=result,validationLayerObserved=bool(re.search(r'Insert.*VK_LAYER_KHRONOS_validation',log,re.I)),validationClean=not any(x in log for x in ['VUID-','Validation Error:','Validation Warning:','SYNC-HAZARD']),sourceUnchanged=before==inputs(r));rows.append(row)
 (o/(config.lower()+'-filter-checks.json')).write_text(json.dumps(rows,indent=2))
 assert result['exitCode']==0 and all(row[k] for k in ['validationLayerObserved','validationClean','sourceUnchanged']),row
 print(config,device,'passed',flush=True)
verify(r,json.loads((b/'build-provenance.json').read_text()))
