from pathlib import Path
import os,sys,json,shutil,zipfile
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
from build_provenance import verify,digest
os.environ.update(managed_environment(o/'tmp'))
with zipfile.ZipFile(r/'docs/acceptance/nr/evidence/2026-11-09/buffer-memory-properties/validation.zip') as z:baseline=json.loads(z.read('builds.json'))
rows=[]
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);m=json.loads((b/'build-provenance.json').read_text());verify(r,m)
 programs={p:s for p,s in baseline[c]['products'].items() if Path(p).parent==b/'shaders' and p.endswith('.spv')};assert len(programs)==675 and all(digest(Path(p))==sha for p,sha in programs.items())
 command=['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe','--test-dir',str(b),'-R','^AzureRender\.(ClusteredLightGrid|LightBuffer)$','-V','--output-junit',str(o/(c+'-checks.xml'))]
 result=guarded_run(r/'build',o.name,command,120);shutil.copyfile(o/'process.log',o/(c+'-checks.log'));assert result['exitCode']==0,result
 log=(o/(c+'-checks.log')).read_text();assert '100% tests passed' in log and 'out of 2' in log
 rows.append(dict(configuration=c,execution=result,shadersUnchanged=675));print(c,log[-1400:],flush=True)
(o/'cpu-checks.json').write_text(json.dumps(rows,indent=2))
