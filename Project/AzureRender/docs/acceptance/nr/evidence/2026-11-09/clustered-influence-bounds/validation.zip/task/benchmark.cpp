#include "render/ClusteredLightGrid.hpp"
#include "original_grid.hpp"
#include <chrono>
#include <iostream>
int main(){using namespace azurerender;std::vector<RenderLight> lights;
const std::array<float,16> view{-0.9999878201136746F,0.00029462673106120114F,-0.004926745314151049F,0.0F,2.1294115253106222e-11F,0.9982166726607188F,0.05969484418409373F,0.0F,0.004935547011341815F,0.05969411710757245F,-0.9982045144951239F,0.0F,-0.14311848420228582F,-0.771245214958957F,-24.996951770670794F,1.0F};
{RenderLight l;l.stableId=0;l.radius=1.0F;l.viewSpaceBounds=true;l.viewPosition={-0.14311848420228582F,-0.771245214958957F,24.996951770670794F};l.clusterPosition[2]=24.996951770670794F;
l.shape.type=LightKind::Directional;
l.shape.receivers.surfaces=true;l.shape.receivers.characters=false;
lights.push_back(l);}
{RenderLight l;l.stableId=1;l.radius=116.72999838669489F;l.viewSpaceBounds=true;l.viewPosition={-0.08068539735022567F,15.764705613634835F,0.1449234926242181F};l.clusterPosition[2]=0.1449234926242181F;
l.shape.receivers.surfaces=true;l.shape.receivers.characters=false;
l.shape.influenceBox.enabled=true;l.shape.influenceBox.worldToBox={{{-0.0294036865234375F,0.0F,0.0F,-0.018964538784530305F},{-0.0F,0.09454345703125F,0.0F,-0.6910711453529075F},{-0.0F,0.0F,0.044097900390625F,1.0211913927923888F}}};l.clusterBox=clusterInfluenceBox(l.shape.influenceBox,view);
lights.push_back(l);}
{RenderLight l;l.stableId=2;l.radius=38.20000096768143F;l.viewSpaceBounds=true;l.viewPosition={-16.316975031044056F,15.346302424400276F,7.052436019172302F};l.clusterPosition[2]=7.052436019172302F;
l.shape.receivers.surfaces=true;l.shape.receivers.characters=false;
l.shape.influenceBox.enabled=true;l.shape.influenceBox.worldToBox={{{-0.023895263671875F,-0.0F,-0.031829833984375F,-0.1600840178434737F},{-0.0F,0.11029052734375F,0.0F,-1.002936994889751F},{-0.054107666015625F,0.0F,0.040618896484375F,1.63233951368602F}}};l.clusterBox=clusterInfluenceBox(l.shape.influenceBox,view);
lights.push_back(l);}
{RenderLight l;l.stableId=3;l.radius=17.29999927174303F;l.viewSpaceBounds=true;l.viewPosition={-0.048025176613290324F,-7.859213307395555F,22.394920540261424F};l.clusterPosition[2]=22.394920540261424F;
l.shape.receivers.surfaces=true;l.shape.receivers.characters=false;
l.shape.influenceBox.enabled=true;l.shape.influenceBox.worldToBox={{{-0.08258056640625F,0.0F,0.0F,0.08649719243203435F},{-0.0F,0.06781005859375F,0.0F,0.8003002981422469F},{-0.0F,0.0F,0.0933837890625F,0.22031249821884558F}}};l.clusterBox=clusterInfluenceBox(l.shape.influenceBox,view);
lights.push_back(l);}
{RenderLight l;l.stableId=4;l.radius=29.100000368580226F;l.viewSpaceBounds=true;l.viewPosition={-20.297469001216417F,10.26996814223773F,7.265493065242047F};l.clusterPosition[2]=7.265493065242047F;
l.shape.receivers.surfaces=true;l.shape.receivers.characters=false;
l.shape.influenceBox.enabled=true;l.shape.influenceBox.worldToBox={{{-0.0889892578125F,0.0F,0.05877685546875F,2.541496518999338F},{-0.0F,0.25146484375F,0.0F,-1.237890605814755F},{0.038604736328125F,0.0F,0.058441162109375F,0.3320480107795447F}}};l.clusterBox=clusterInfluenceBox(l.shape.influenceBox,view);
lights.push_back(l);}
{RenderLight l;l.stableId=5;l.radius=20.50000076368454F;l.viewSpaceBounds=true;l.viewPosition={0.10370663734437542F,20.121080387257155F,37.31069372958264F};l.clusterPosition[2]=37.31069372958264F;
l.shape.receivers.surfaces=true;l.shape.receivers.characters=false;
l.shape.influenceBox.enabled=true;l.shape.influenceBox.worldToBox={{{-0.046478271484375F,0.0F,0.0F,0.050838012362874F},{-0.0F,0.129638671875F,-0.0268402099609375F,-1.0066324950748822F},{-0.0F,0.02667236328125F,0.1287841796875F,-3.1851709159091115F}}};l.clusterBox=clusterInfluenceBox(l.shape.influenceBox,view);
lights.push_back(l);}
{RenderLight l;l.stableId=6;l.radius=1.0F;l.viewSpaceBounds=true;l.viewPosition={0.5431051598537123F,-0.9991814694680604F,3.8486380061181436F};l.clusterPosition[2]=3.8486380061181436F;
l.shape.type=LightKind::Directional;
l.shape.receivers.surfaces=false;l.shape.receivers.characters=true;
lights.push_back(l);}
{RenderLight l;l.stableId=7;l.radius=0.45959470279340786F;l.viewSpaceBounds=true;l.viewPosition={0.42069153789222247F,0.4451097826175321F,3.4954506488758925F};l.clusterPosition[2]=3.4954506488758925F;
l.shape.receivers.surfaces=false;l.shape.receivers.characters=true;
lights.push_back(l);}
{RenderLight l;l.stableId=8;l.radius=0.26348876431281376F;l.viewSpaceBounds=true;l.viewPosition={0.7636684587528074F,0.5434009980924186F,3.688215091248598F};l.clusterPosition[2]=3.688215091248598F;
l.shape.receivers.surfaces=false;l.shape.receivers.characters=true;
lights.push_back(l);}
{RenderLight l;l.stableId=9;l.radius=0.14913939931828962F;l.viewSpaceBounds=true;l.viewPosition={0.5477654937049806F,0.7852436521179803F,3.663455249542995F};l.clusterPosition[2]=3.663455249542995F;
l.shape.receivers.surfaces=false;l.shape.receivers.characters=true;
lights.push_back(l);}
{RenderLight l;l.stableId=10;l.radius=0.17164486640212193F;l.viewSpaceBounds=true;l.viewPosition={0.519908376235947F,0.5445547223146755F,3.5848133304223913F};l.clusterPosition[2]=3.5848133304223913F;
l.shape.receivers.surfaces=false;l.shape.receivers.characters=true;
lights.push_back(l);}
{RenderLight l;l.stableId=11;l.radius=1.4999999552965178F;l.viewSpaceBounds=true;l.viewPosition={0.662931002979952F,0.07945452898951669F,4.976256718462192F};l.clusterPosition[2]=4.976256718462192F;
l.shape.characterResponse.present=true;l.shape.characterResponse.schemaVersion=3;l.shape.characterResponse.projectedDistance=true;
l.shape.receivers.surfaces=false;l.shape.receivers.characters=true;
lights.push_back(l);}
{RenderLight l;l.stableId=12;l.radius=1.1499999588727965F;l.viewSpaceBounds=true;l.viewPosition={1.5421161691954557F,0.24971776638005783F,3.223382293948959F};l.clusterPosition[2]=3.223382293948959F;
l.shape.receivers.surfaces=false;l.shape.receivers.characters=true;
lights.push_back(l);}
{RenderLight l;l.stableId=13;l.radius=0.5843336512292233F;l.viewSpaceBounds=true;l.viewPosition={0.9295224676453336F,0.7258607723014665F,3.4459856362600996F};l.clusterPosition[2]=3.4459856362600996F;
l.shape.receivers.surfaces=false;l.shape.receivers.characters=true;
lights.push_back(l);}
{RenderLight l;l.stableId=14;l.radius=0.20822144021007694F;l.viewSpaceBounds=true;l.viewPosition={0.5413486906304276F,0.6386314651197094F,3.59003255953571F};l.clusterPosition[2]=3.59003255953571F;
l.shape.receivers.surfaces=false;l.shape.receivers.characters=true;
lights.push_back(l);}
{RenderLight l;l.stableId=15;l.radius=1.1499999588727965F;l.viewSpaceBounds=true;l.viewPosition={1.369911001948845F,-0.680236939172302F,3.536552973043124F};l.clusterPosition[2]=3.536552973043124F;
l.shape.receivers.surfaces=false;l.shape.receivers.characters=true;
lights.push_back(l);}
ClusterGridDesc desc{16,9,24,.1F,10000.F,1.0312498882412913F,-1.8333331346511843F,false,-0.0002929684706032276F,7.717559492448345e-05F};OriginalGrid original({desc.x,desc.y,desc.z,desc.nearPlane,desc.farPlane,desc.projectionScaleX,desc.projectionScaleY,desc.orthographic,desc.projectionOffsetX,desc.projectionOffsetY});ClusteredLightGrid candidate(desc);
auto measure=[&](auto& grid){for(int i=0;i<20;++i)grid.assign(lights);auto start=std::chrono::steady_clock::now();for(int i=0;i<1000;++i)grid.assign(lights);return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()/1000;};
const auto base=measure(original),tight=measure(candidate);std::cout<<base<<' '<<tight<<' '<<original.gpuIndexData().size()<<' '<<candidate.gpuIndexData().size()<<std::endl;}