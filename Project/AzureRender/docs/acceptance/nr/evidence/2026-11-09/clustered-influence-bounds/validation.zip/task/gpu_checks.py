from pathlib import Path
import os,sys,json,re
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
os.environ.update(managed_environment(o/'tmp'))
if '--inside' in sys.argv:
 import test_character_local_light_gpu as fixture
 original=fixture.generate
 def generate(folder,mode):
  original(folder,mode);path=folder/'level.azurelevel';data=json.loads(path.read_text())
  data['lights'][0]['shape']['receivers']=dict(schemaVersion=1,surfaces=True,characters=False)
  path.write_text(json.dumps(data))
 fixture.generate=generate
 folder=o/('gpu-v2-'+sys.argv[-1]);fixture.run(r/'build/ninja-msvc-release/AzurePlayer.exe',folder,['pbr','pbr-zero-box','pbr-zero-box-fixed','pbr-zero-box-control','pbr-positive-box'],'disabled')
 for name in ['pbr','pbr-zero-box','pbr-zero-box-fixed','pbr-zero-box-control','pbr-positive-box']:
  log=(folder/name/'player.log').read_text();assert re.search(r'Insert.*VK_LAYER_KHRONOS_validation',log,re.I),name
 for name in ['pbr-zero-box','pbr-zero-box-fixed']:
  log=(folder/name/'player.log').read_text();assert '1 lights, 0 cluster references' in log,(name,log[-2000:])
else:
 rows=[]
 for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  os.environ['VK_LOADER_DRIVERS_SELECT']=driver;os.environ['VK_INSTANCE_LAYERS']='VK_LAYER_KHRONOS_validation';os.environ.pop('VK_LAYER_ENABLES',None);os.environ['VK_LAYER_VALIDATE_SYNC']='1';os.environ['VK_LOADER_DEBUG']='error,layer'
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
  command=[sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',device]
  result=guarded_run(r/'build',o.name,command,180);(o/('gpu-'+device+'-execution.json')).write_text(json.dumps(result,indent=2));assert result['exitCode']==0,result
  rows.append(dict(device=device,execution=result,report=json.loads((o/('gpu-v2-'+device)/'summary.json').read_text())))
 (o/'gpu-checks.json').write_text(json.dumps(rows,indent=2));print('Two devices: five surface light cases each passed',flush=True)
