import json, math
from pathlib import Path
import numpy as np
root=Path.cwd(); out=Path(__file__).resolve().parent
p=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/scene/joint-dynamic-loop-v2.azurelevel'
d=json.loads(p.read_text()); camera=next(n for n in d['nodes'] if n['id']=='camera')['components']; t=camera['azure.transform']['data']; c=camera['azure.camera']['data']
def rotation(v):
 x,y,z=np.radians(v);cx,sx=math.cos(x),math.sin(x);cy,sy=math.cos(y),math.sin(y);cz,sz=math.cos(z),math.sin(z)
 return np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]])@np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]])@np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])
rot=rotation(t['rotation'])
node_map={n['id']:n for n in d['nodes']}
def world_matrix(n):
 t=n['components']['azure.transform']['data'];m=np.eye(4);m[:3,:3]=rotation(t.get('rotation',[0,0,0]))@np.diag(t.get('scale',[1,1,1]));m[:3,3]=t.get('translation',[0,0,0]);parent=n.get('parentId');return world_matrix(node_map[parent])@m if parent else m
view=rot.T; pos=np.array(t['translation']); focal=1/math.tan(math.radians(c['fieldOfView'])/2); scales=[focal/(16/9),-focal]; offsets=[c['projectionOffsetX'],c['projectionOffsetY']]
def transform(p):
 v=view@(np.array(p)-pos);v[2]*=-1;return v
def members(lo,hi,far):
 lo=np.array(lo).copy();hi=np.array(hi).copy();lo[2]=max(lo[2],.1);hi[2]=min(hi[2],far)
 if any(hi<lo):return []
 limits=[]
 for axis,n in [(0,16),(1,9)]:
  vals=[v/q*scales[axis]+offsets[axis] for v in (lo[axis],hi[axis]) for q in (lo[2],hi[2])]
  a,b=min(vals),max(vals)
  if b< -1 or a>1:return []
  cell=lambda v:max(0,min(n-1,int((v+1)*.5*n)))
  limits.append(range(cell(a),cell(b)+1))
 slice=lambda v:min(23,int(max(0,min(.999999,math.log(v/.1)/math.log(far/.1)))*24))
 return [(x,y,z) for z in range(slice(lo[2]),slice(hi[2])+1) for y in limits[1] for x in limits[0]]
def count(lo,hi,far):return len(members(lo,hi,far))
def intersects(cell,rows,far):
 x,y,z=cell;zs=[.1*(far/.1)**(i/24) for i in (z,z+1)]
 corners=[]
 for a in [x,x+1]:
  for b in [y,y+1]:
   for q in zs:
    v=np.array([((2*a/16-1)-offsets[0])/scales[0]*q,((2*b/9-1)-offsets[1])/scales[1]*q,-q])
    world=rot@v+pos;corners.append(rows[:,:3]@world+rows[:,3])
 values=np.array(corners)
 return bool(np.all(np.min(values,axis=0)<=1.00001) and np.all(np.max(values,axis=0)>=-1.00001))
results=[]
for l in d['lights']:
 if not l.get('enabled',True):continue
 # Print bounded schema once when inspecting new fields.
 shape=l.get('shape',{}); box=shape.get('influenceBox',l.get('influenceBox',{}))
 node=next(n for n in d['nodes'] if n['id']==l['nodeId']); world=world_matrix(node)[:3,3];radius=l.get('radius',1); center=transform(world); lo=center-radius;hi=center+radius
 if l.get('type',shape.get('type')) in ['directional',2] or shape.get('characterResponse',{}).get('projectedDistance',False):before=after=3456
 else:
  before=count(lo,hi,10000);after=before
  if box.get('enabled'):
   rows=np.array(box['worldToBox']); inv=np.linalg.inv(rows[:,:3]);corners=[transform(inv@(np.array([i,j,k])-rows[:,3])) for i in [-1,1] for j in [-1,1] for k in [-1,1]]
   plane_count=sum(intersects(cell,rows,10000) for cell in members(lo,hi,10000)); bmin=np.min(corners,axis=0);bmax=np.max(corners,axis=0);after=count(np.maximum(lo,bmin),np.minimum(hi,bmax),10000)
 results.append(dict(id=l.get('id'),radius=radius,box=bool(box.get('enabled')),before=before,after=after,planeAfter=plane_count if box.get('enabled') else before))
print(json.dumps(results,indent=2));print('totals',sum(v['before'] for v in results),sum(v['after'] for v in results));(out/'scope.json').write_text(json.dumps(results,indent=2))
