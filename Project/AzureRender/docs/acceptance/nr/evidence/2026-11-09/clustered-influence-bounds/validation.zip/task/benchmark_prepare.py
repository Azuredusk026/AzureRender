"""The checked-in evidence carries benchmark.cpp and original_grid.hpp.
Rebuild them through work.py benchmark; the fixture's constants are frozen.
Use scope.py only for an independent approximate range calculation.
"""
from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
print(json.dumps({n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['benchmark.cpp','original_grid.hpp']}))
