from pathlib import Path
import os,sys,json,subprocess,hashlib,zipfile,re,shutil
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,write_json,tracked_paths,measure
from artifact_cleanup import remove_artifact
from build_provenance import verify,digest
os.environ.update(managed_environment(o/'tmp'))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
diff=subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL);protectedHash=hashlib.sha256(diff).hexdigest();assert protectedHash=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
builds={}
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);m=json.loads((b/'build-provenance.json').read_text());verify(r,m);builds[c]=dict(manifestSha256=digest(b/'build-provenance.json'),source=m['source'],products=m['products'])
cpu=json.loads((o/'cpu-checks.json').read_text());gpu=json.loads((o/'gpu-checks.json').read_text());image=json.loads((o/'image-cluster-bounds/results.json').read_text());cost=json.loads((o/'cost-results-v1.json').read_text())
assert len(cpu)==2 and all(v['execution']['exitCode']==0 and v['shadersUnchanged']==675 for v in cpu)
assert len(gpu)==2 and all(v['execution']['exitCode']==0 and v['report']['status']=='passed' and len(v['report']['captures'])==5 for v in gpu)
assert image['validationErrorFree'] and image['validationSettingsWarnings']==1 and len(image['frames'])==4 and all(v['changedPixels']==0 for v in image['frames'])
assert cost['bracketStable'] and cost['gpuSavedMs']>0 and cost['sourceAndProductsUnchanged']
assert 'A separated surface influence box must remove' in (o/'red-baseline.log').read_text()
for p,sha in json.loads((o/'cost-products-before.json').read_text()).items():assert digest(Path(p))==sha
lock=json.loads((o.parent/'20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text());assert all(digest(Path(p))==sha for p,sha in lock.items())
e=r/'docs/acceptance/nr/evidence/2026-11-09/clustered-influence-bounds';e.mkdir(parents=True,exist_ok=True)
sources=['src/render/ClusterLightInfluenceBox.hpp','src/render/ClusteredLightGrid.hpp','src/render/LightBuffer.hpp','src/scenes/CharacterSceneRenderer.cpp','tests/ClusteredLightGridTests.cpp']
with zipfile.ZipFile(e/'validation.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(o.rglob('*')):
  if p.is_file() and p.suffix in ['.py','.cpp','.hpp','.json','.csv','.log','.xml'] and 'tmp' not in p.relative_to(o).parts:archive.write(p,'task/'+p.relative_to(o).as_posix())
 for name in sources:archive.write(r/name,'source/'+name)
 archive.writestr('builds.json',json.dumps(builds,indent=2))
assert (e/'validation.zip').stat().st_size<8*2**20
with zipfile.ZipFile(e/'validation.zip') as archive:assert archive.testzip() is None
cleanup=[];tracked=tracked_paths(r);freeBefore=shutil.disk_usage(r).free
for p in [o/'tmp',o/'red-include',o/'baseline-player.exe',o/'benchmark.exe',o/'benchmark.obj',o/'red-baseline.exe',o/'red-baseline.obj']:
 if p.exists():
  assert o in p.resolve().parents
  size,_=remove_artifact(r/'build',p,tracked,apply=True);cleanup.append(dict(path=str(p),logicalBytes=size))
for p in sorted((o/'image-cluster-bounds').glob('frames-*/frame_*.png')):
 assert o in p.resolve().parents
 ref=o.parent/'20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames'/p.name
 assert digest(p)==digest(ref)
 size,_=remove_artifact(r/'build',p,tracked,apply=True);cleanup.append(dict(path=str(p),logicalBytes=size,source=str(ref)))
report=dict(status='implemented-verified',baselineCommit='af765a523256fe7e58e843c6b5df4027350764e5',run=o.name,cpuChecks=cpu,gpuChecks=gpu,strictOriginalFrames=image,localPerformance=cost,builds={c:dict(manifestSha256=m['manifestSha256'],sourceCount=len(m['source'])) for c,m in builds.items()},sourceHashes={name:digest(r/name) for name in sources},shadersUnchangedPerConfiguration=675,projectInputsVerified=len(lock),nativeImageRuns=1,nativeTimingRuns=3,formalPerformancePassed=False,visualStatus='failed-user-review',protectedUserDiffSha256=protectedHash,externalStorageUsed=False,cleanup=cleanup,reclaimedLogicalBytes=sum(v['logicalBytes'] for v in cleanup),observedFreeBytesDelta=shutil.disk_usage(r).free-freeBefore,remainingRunBytes=measure(o),archiveBytes=(e/'validation.zip').stat().st_size,archiveSha256=digest(e/'validation.zip'))
write_json(e/'results.json',report);write_json(o/'results.json',report)
for name in ['README.md','docs/plans/azure-engine-plan.md','docs/plans/2026-11-09-clustered-influence-bounds.md','docs/development/clustered-influence-bounds.md','docs/acceptance/nr/clustered-influence-bounds.md']:
 p=r/name
 for link in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in link and not link.startswith('#'):assert (p.parent/link.split('#')[0]).exists(),(name,link)
print(json.dumps({k:report[k] for k in ['status','reclaimedLogicalBytes','remainingRunBytes','archiveBytes','observedFreeBytesDelta']},indent=2))
