from pathlib import Path
import sys,os,json,shutil
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;old=o.parent/'20261109-181501-native-producer-gpu-intermediates-de1e3d';sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'))
for name in ['collector.cpp','filter.comp','object_shadow.glsl']:shutil.copyfile(old/name,o/name)
s=(o/'collector.cpp').read_text();needle='        queries.clear();expected.clear();';assert needle in s
s=s.replace(needle,'''        if(fixture.value("expandD16",false)){
            std::vector<char> expanded(std::size_t(width)*height*sizeof(float));
            for(std::size_t i=0;i<std::size_t(width)*height;++i){
                std::uint16_t value;std::memcpy(&value,pixels.data()+2*i,2);
                const float decoded=static_cast<float>(static_cast<double>(value)/65535.0);
                std::memcpy(expanded.data()+4*i,&decoded,sizeof(decoded));
            }
            pixels=std::move(expanded);format=VK_FORMAT_D32_SFLOAT;
        }
'''+needle)
s=s.replace('    rhi::GpuBuffer output{},records{};', '    rhi::GpuBuffer output{},records{};')
s=s.replace('    test::VulkanComputeFixture host;auto& backend=*host.backend;','    test::VulkanComputeFixture host;auto& backend=*host.backend;\n    std::cout<<"Device="<<host.properties.deviceName<<", subTexelPrecisionBits="<<host.properties.limits.subTexelPrecisionBits<<"\\n";')
(o/'collector.cpp').write_text(s)
fixture=json.loads((old/'fixture.json').read_text());fixture['expandD16']=False;(o/'fixture-d16.json').write_text(json.dumps(fixture,indent=2));fixture['expandD16']=True;(o/'fixture-d32.json').write_text(json.dumps(fixture,indent=2))
base=(o/'object_shadow.glsl').read_text()
for name,quantize in [('manual',False),('manual-grid',True)]:
 text=base;start=text.index('    if(all(greaterThanEqual(base-1,lo))');end=text.index('    return vec4(objectShadowPageTexel',start);text=text[:start]+text[end:]
 if quantize:text=text.replace('ivec2 base=ivec2(floor(uv*vec2(textureSize(sampler2D(depth,sharedSampler),0))-.5));','precise vec2 coordinate=uv*vec2(textureSize(sampler2D(depth,sharedSampler),0))-.5;\n    ivec2 base=ivec2(floor(roundEven(coordinate*256.0)/256.0));')
 (o/('object_shadow_'+name+'.glsl')).write_text(text)
 (o/(name+'.comp')).write_text((o/'filter.comp').read_text().replace('object_shadow.glsl','object_shadow_'+name+'.glsl'))
for name in ['compile-command.txt','link-command.txt']:
 (o/name).write_text((old/name).read_text().replace(str(old),str(o)).replace(old.as_posix(),o.as_posix()))
print('Prepared Intel footprint and D16 conversion controls without texture copies')
