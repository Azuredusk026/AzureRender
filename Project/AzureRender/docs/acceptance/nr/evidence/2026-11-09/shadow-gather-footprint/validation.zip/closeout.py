from pathlib import Path
import json,hashlib,subprocess,shutil,sys,zipfile,re
import numpy as np
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from build_provenance import verify,digest
from artifact_maintenance import write_json,tracked_paths
from artifact_cleanup import remove_artifact
image=json.loads((o/'image-shadow-footprint/results.json').read_text());assert len(image['frames'])==4 and all(a['changedPixels']==0 and a['sha256']==a['referenceSha256'] for a in image['frames'])
assert all(image[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationLogClean','zeroAllocator'])
checks=[];shaders={};builds={}
with zipfile.ZipFile(r/'docs/acceptance/nr/evidence/2026-11-09/material-facing-demand/validation.zip') as z:baseline=json.loads(z.read('release-build-provenance.json'))
prior={Path(p).name:v for p,v in baseline['products'].items() if p.endswith('.spv') and Path(p).parent.name=='shaders'};assert len(prior)==675
for config in ['release','debug']:
 checks+=json.loads((o/(config+'-filter-checks.json')).read_text());b=r/('build/ninja-msvc-'+config);m=json.loads((b/'build-provenance.json').read_text());verify(r,m);shutil.copyfile(b/'build-provenance.json',o/(config+'-build-provenance.json'));shaders[config]={p.name:digest(p) for p in (b/'shaders').glob('*.spv')};assert len(shaders[config])==675;builds[config]=dict(sourceCount=len(m['source']),products=len(m['products']),verified=True)
assert len(checks)==4 and all(a['execution']['exitCode']==0 and all(a[k] for k in ['validationLayerObserved','validationClean','sourceUnchanged']) for a in checks);assert shaders['release']==shaders['debug']
changed=[n for n,v in shaders['release'].items() if prior[n]!=v];assert changed and all(n.endswith('.frag.spv') or n=='object_shadow_filter_test.comp.spv' for n in changed)
for config in ['release','debug']:
 for device in ['intel','nvidia']:assert '27 records/queries' in (o/(config+'-'+device+'-filter.log')).read_text()
before=np.fromfile(o/'timing-before-output.bin',dtype='<u4');candidate=np.fromfile(o/'timing-candidate-output.bin',dtype='<u4');assert np.array_equal(before,candidate)
times={}
for role in ['before','candidate','after']:
 s=(o/('timing-'+role+'.log')).read_text();match=re.search(r'GPU_DIAGNOSTIC meanMs=([\d.]+) medianMs=([\d.]+) samples=(\d+)',s);assert match and match[3]=='64';times[role]=dict(meanMs=float(match[1]),medianMs=float(match[2]),samples=int(match[3]))
reference=(times['before']['meanMs']+times['after']['meanMs'])/2;timing=dict(roles=times,warmupsPerRole=32,referenceDrift=abs(times['before']['meanMs']-times['after']['meanMs'])/reference,reduction=1-times['candidate']['meanMs']/reference,scope='Isolated fixed receiver queries; not native whole-frame acceptance')
assert timing['referenceDrift']<.01 and timing['reduction']>-.02
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py'];ph=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest();assert ph=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
for rel in ['shaders/object_shadow.glsl','tests/ObjectShadowFilteringGpuTests.cpp','docs/runtime/object-shadow.md','docs/plans/2026-11-09-shadow-gather-footprint.md','docs/acceptance/nr/shadow-gather-footprint.md']:
 p=o/'final-source'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,p)
result=dict(status='fixed-footprint-verified',baselineCommit='fd415e2',run=o.name,builds=builds,gpuChecks=checks,recordsAndQueriesPerCheck=27,newInteriorBoundaryQueries=3,region=json.loads((o/'analysis.json').read_text()),samples=49384,nvidiaAllFloatOutputBitsUnchanged=True,isolatedTiming=timing,originalFrames=image['frames'],projectInputsVerified=1729,originalChangedPixels=0,validationClean=True,nativeAllocatorZero=True,changedPrograms=changed,unchangedVertexAndOtherComputePrograms=True,protectedDiffSha256=ph,newFullAssetCopies=0,newGpuResources=0,nativeImageProcesses=1,nativeCostProcesses=0,formalPerformancePassed=False,fullHairColorPassed=False,overallVisualAcceptance='failed-user-review');write_json(o/'results.json',result)
dest=r/'docs/acceptance/nr/evidence/2026-11-09/shadow-gather-footprint';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
selected=[p for p in sorted(o.rglob('*')) if p.is_file() and 'tmp' not in p.relative_to(o).parts and p.suffix.lower() in {'.py','.json','.log','.cpp','.glsl','.comp','.md','.txt'}]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in selected:z.write(p,p.relative_to(o).as_posix())
assert archive.stat().st_size<8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in selected:assert hashlib.sha256(z.read(p.relative_to(o).as_posix())).hexdigest()==digest(p)
result['package']=dict(bytes=archive.stat().st_size,files=len(selected),sha256=digest(archive));write_json(dest/'results.json',result)
targets=[o/'tmp',o/'__pycache__',*o.glob('*.exe'),*o.glob('*.obj'),*o.glob('*.spv'),*o.glob('*-output.bin')];byname={a['frame']:a for a in image['frames']}
for p in (o/'image-shadow-footprint').glob('frames-*/*.png'):
 assert digest(p)==byname[p.name]['sha256']==byname[p.name]['referenceSha256'];targets.append(p)
tracked=tracked_paths(r);free=shutil.disk_usage(r).free;removed=[]
for p in targets:
 if p.exists():
  assert p.resolve().is_relative_to(o.resolve());removed.append(dict(path=str(p.resolve()),removed=remove_artifact(r/'build',p,tracked,apply=True)))
after=shutil.disk_usage(r).free;cleanup=dict(removed=removed,freeBefore=free,freeAfter=after,observedFreedBytes=after-free);write_json(dest/'cleanup.json',cleanup);write_json(o/'cleanup.json',cleanup);print(json.dumps(dict(package=result['package'],changedPrograms=len(changed),observedFreedBytes=after-free),indent=2))
