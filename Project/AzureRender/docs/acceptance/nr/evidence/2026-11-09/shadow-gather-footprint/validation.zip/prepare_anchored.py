from pathlib import Path
o=Path(__file__).resolve().parent
s=(o/'object_shadow.glsl').read_text()
s=s.replace('ivec2 base=ivec2(floor(uv*vec2(textureSize(sampler2D(depth,sharedSampler),0))-.5));','vec2 extent=vec2(textureSize(sampler2D(depth,sharedSampler),0));\n    precise vec2 coordinate=uv*extent-.5;\n    ivec2 base=ivec2(floor(roundEven(coordinate*256.0)/256.0));')
s=s.replace('if(all(greaterThanEqual(base-1,lo))&&all(lessThan(base+2,hi)))','if(all(greaterThanEqual(base,lo))&&all(lessThan(base+1,hi)))')
s=s.replace('textureGather(sampler2D(depth,sharedSampler),uv);','textureGather(sampler2D(depth,sharedSampler),(vec2(base)+1.0)/extent);')
(o/'object_shadow_anchored.glsl').write_text(s);(o/'anchored.comp').write_text((o/'filter.comp').read_text().replace('object_shadow.glsl','object_shadow_anchored.glsl'))
s=(o/'check.py').read_text().replace("['compile-command.txt','link-command.txt']","[]").replace("['filter','manual','manual-grid']","['anchored']")
s=s.replace("[('filter','d16'),('manual','d16'),('manual-grid','d16'),('filter','d32'),('manual-grid','d32')]","[('anchored','d16')]").replace("'execution.json'","'anchored-execution.json'")
(o/'anchored_check.py').write_text(s)
print('Prepared fixed-footprint hardware gather control')
