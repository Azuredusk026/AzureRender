from pathlib import Path
o=Path(__file__).resolve().parent
s=(o/'collector.cpp').read_text().replace('#include <fstream>','#include <fstream>\n#include <algorithm>')
needle='    cleanup.reset();if(host.errors.load())';assert needle in s
code='''    if(!host.timestampBits)throw std::runtime_error("Timestamp support unavailable");
    VkQueryPool timingPool;VkQueryPoolCreateInfo timingDesc{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};
    timingDesc.queryType=VK_QUERY_TYPE_TIMESTAMP;timingDesc.queryCount=2;
    test::vkRequire(vkCreateQueryPool(host.device,&timingDesc,nullptr,&timingPool),"vkCreateQueryPool");
    std::vector<double> milliseconds;
    for(unsigned iteration=0;iteration<96;++iteration){
        host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer command){
            vkCmdResetQueryPool(command,timingPool,0,2);
            commands.bindComputePipeline(pipeline);commands.bindComputeDescriptorSet(layout,set);
            commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});
            vkCmdWriteTimestamp(command,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,timingPool,0);
            commands.dispatch(count,1,1);
            vkCmdWriteTimestamp(command,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,timingPool,1);
        });
        std::uint64_t ticks[2]{};
        test::vkRequire(vkGetQueryPoolResults(host.device,timingPool,0,2,sizeof(ticks),ticks,sizeof(ticks[0]),VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT),"vkGetQueryPoolResults");
        if(iteration>=32)milliseconds.push_back(double(ticks[1]-ticks[0])*host.properties.limits.timestampPeriod/1000000.0);
    }
    vkDestroyQueryPool(host.device,timingPool,nullptr);
    double total=0;for(auto ms:milliseconds)total+=ms;std::sort(milliseconds.begin(),milliseconds.end());
    std::cout<<"GPU_DIAGNOSTIC meanMs="<<total/milliseconds.size()<<" medianMs="<<(milliseconds[31]+milliseconds[32])*.5<<" samples="<<milliseconds.size()<<"\\n";
'''
s=s.replace(needle,code+needle);(o/'timing.cpp').write_text(s)
for name in ['compile-command.txt','link-command.txt']:
 (o/('timing-'+name)).write_text((o/name).read_text().replace('collector.cpp','timing.cpp').replace('collector.obj','timing.obj').replace('collector.exe','timing.exe'))
s=(o/'anchored_check.py').read_text().replace("[]:","['timing-compile-command.txt','timing-link-command.txt']:",1)
s=s.replace("['anchored']","[]").replace("'*igvk64*'","'*nv-vk64*'")
start=s.index("for mode,format in ")
s=s[:start]+'''for name,mode in [('before','filter'),('candidate','anchored'),('after','filter')]:
 with (o/('timing-'+name+'.log')).open('wb') as log:subprocess.run([str(o/'timing.exe'),str(o/(mode+'.spv')),str(o/'fixture-d16.json'),str(o/('timing-'+name+'-output.bin'))],stdout=log,stderr=subprocess.STDOUT,check=True)
'''
s=s.replace("'anchored-execution.json'","'timing-execution.json'");(o/'timing_check.py').write_text(s)
print('Prepared 32 warmups and 64 timestamps per bracket role')
