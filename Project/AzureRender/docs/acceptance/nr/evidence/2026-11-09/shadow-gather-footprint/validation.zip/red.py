from pathlib import Path
import sys,os,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
os.environ.update(managed_environment(o/'tmp'));os.environ.update(VK_LOADER_DRIVERS_SELECT='*igvk64*',VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer')
for k in ['VK_LAYER_ENABLES','VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(k,None)
b=r/'build/ninja-msvc-release';result=guarded_run(r/'build',o.name,[str(b/'AzureObjectShadowFilteringGpuTests.exe'),str(b/'shaders/object_shadow_filter_test.comp.spv')],120)
(o/'red-execution.json').write_text(json.dumps(result,indent=2));(o/'red.log').write_bytes((o/'process.log').read_bytes());print(result);print((o/'process.log').read_text(errors='replace')[-600:]);assert result['exitCode']==1
