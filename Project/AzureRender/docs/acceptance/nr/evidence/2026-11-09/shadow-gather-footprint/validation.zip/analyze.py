from pathlib import Path
import numpy as np,json
o=Path(__file__).resolve().parent;old=o.parent/'20261109-181501-native-producer-gpu-intermediates-de1e3d';expected=np.fromfile(old/'expected.u8',dtype='u1').astype('i4');rows=[]
for p in sorted(o.glob('*-output.bin')):
 actual=np.rint(np.fromfile(p,dtype='<f4').reshape(-1,4)[:,2]*255).astype('i4');d=abs(actual-expected)
 rows.append(dict(mode=p.name.removesuffix('-output.bin'),exactPixels=int((d==0).sum()),pixelsOverOneByte=int((d>1).sum()),maximumByteError=int(d.max())))
(o/'analysis.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
