from pathlib import Path
import json,hashlib
from PIL import Image, __version__ as pillow_version
import numpy as np
out=Path(__file__).resolve().parent
state=json.loads((out/'export-state.json').read_text())
assert state['status']=='exported' and len(state['textures'])==2
expected_messages={
    'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU',
    'NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image'}
assert not state['textures'][1]['debugMessages']
assert set(state['textures'][0]['debugMessages'])<=expected_messages
rows=[]
for mip in range(12):
    native=np.array(Image.open(out/f'native-{mip}.dds').convert('RGBA'))
    candidate=np.array(Image.open(out/f'vulkan-{mip}.dds').convert('RGBA'))
    assert native.shape==candidate.shape==(max(1,2048>>mip),max(1,2048>>mip),4)
    delta=abs(native.astype('i4')-candidate.astype('i4'))
    flipped=abs(native[::-1].astype('i4')-candidate.astype('i4'))
    rows.append(dict(mip=mip,extent=list(native.shape[:2]),rgbDifferentPixels=int(np.any(delta[:,:,:3]!=0,axis=2).sum()),
        maxRgbByteError=int(delta[:,:,:3].max()),alphaDifferentPixels=int((delta[:,:,3]!=0).sum()),
        verticalFlipRgbDifferentPixels=int(np.any(flipped[:,:,:3]!=0,axis=2).sum()),
        nativeDecodedSha256=hashlib.sha256(native.tobytes()).hexdigest(),vulkanDecodedSha256=hashlib.sha256(candidate.tobytes()).hexdigest(),
        nativeRgbSha256=hashlib.sha256(native[:,:,:3].tobytes()).hexdigest(),vulkanRgbSha256=hashlib.sha256(candidate[:,:,:3].tobytes()).hexdigest()))
report=dict(status='texture-content-audited',mips=rows,export=state,
    allRgbIdentical=all(row['rgbDifferentPixels']==0 for row in rows),pillowVersion=pillow_version,
    scope='Actual bound base-color DDS mip contents, BC7 decoded by Pillow. Shader interpolation and hardware sample rounding remain separate.')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(allRgbIdentical=report['allRgbIdentical'],mips=rows),indent=2))
