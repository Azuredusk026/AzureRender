from pathlib import Path
import json,hashlib,zipfile
out=Path(__file__).resolve().parent
root=out.parents[2]
report=json.loads((out/'results.json').read_text())
expected=json.loads(Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261107-184515-exact-hair-sampling-inputs-97a383/initial-inputs.json').read_text())
report['captures']=[]
for capture in expected['captures']:
    path=Path(capture['path']);digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    assert digest.hexdigest()==capture['sha256']
    report['captures'].append(dict(path=str(path),sha256=digest.hexdigest(),bytes=path.stat().st_size))
evidence=root/'docs/acceptance/nr/evidence/2026-11-09/hair-base-color-mip-content'
evidence.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(evidence/'validation.zip','w',zipfile.ZIP_DEFLATED,6) as package:
    for p in out.iterdir():
        if p.is_file() and p.suffix in ['.py','.json','.log']:package.write(p,p.name)
assert (evidence/'validation.zip').stat().st_size<8*1024*1024
report['archiveSha256']=hashlib.sha256((evidence/'validation.zip').read_bytes()).hexdigest()
(evidence/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(archiveBytes=(evidence/'validation.zip').stat().st_size,archiveSha256=report['archiveSha256'],allRgbIdentical=report['allRgbIdentical']),indent=2))
