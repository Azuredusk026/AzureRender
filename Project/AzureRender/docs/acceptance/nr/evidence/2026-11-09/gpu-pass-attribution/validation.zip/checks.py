from pathlib import Path
import os,subprocess,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;env=os.environ.copy();env.update(TEMP=str(o/'tmp'),TMP=str(o/'tmp'),TMPDIR=str(o/'tmp'),SQLITE_TMPDIR=str(o/'tmp'))
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';rows=[]
for c in ['release','debug']:
 command=[ctest,'--test-dir',str(r/('build/ninja-msvc-'+c)),'-R',r'^AzureRender\.(CommandLine|RenderGraph)$','--output-on-failure','--no-tests=error','--output-junit',str(o/(c+'.xml'))]
 with (o/(c+'-checks.log')).open('wb') as f:result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 rows.append(dict(configuration=c,command=command,exitCode=result.returncode));(o/'checks.json').write_text(json.dumps(rows,indent=2));print(c,result.returncode,flush=True)
 assert result.returncode==0,(o/(c+'-checks.log')).read_text(errors='replace')[-2500:]
