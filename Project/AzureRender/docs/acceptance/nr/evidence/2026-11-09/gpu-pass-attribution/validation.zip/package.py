from pathlib import Path
import json,zipfile,sys,xml.etree.ElementTree as ET
r=Path.cwd().resolve();o=r/'build/runs/20261109-022033-gpu-pass-attribution-89c3e2';sys.path.insert(0,str(r/'tools'));from build_provenance import digest,verify
cases=[]
for n in ['release.xml','debug.xml']:
 for c in ET.parse(o/n).getroot().findall('testcase'):
  assert c.find('failure') is None and c.find('skipped') is None;cases.append(dict(receipt=n,name=c.attrib['name']))
assert len(cases)==4
for c in ['release','debug']:verify(r,json.loads((r/('build/ninja-msvc-'+c)/'build-provenance.json').read_text()))
native=json.loads((o/'native-metadata/results.json').read_text());assert all(native[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationTextClean','zeroAllocator'])
sources=['src/app/AzureRenderApp.cpp','src/app/AzureRenderApp.hpp','src/app/AzureRenderCapture.cpp','src/app/AzureRenderFrame.cpp','src/app/AzureRenderOptions.hpp','src/app/CommandLine.cpp','src/render/RenderGraph.cpp','src/render/RenderGraph.hpp','tests/CommandLineTests.cpp','tests/RenderGraphTests.cpp']
f=r/'docs/acceptance/nr/evidence/2026-11-09/gpu-pass-attribution';f.mkdir(parents=True,exist_ok=True)
paths=[p for p in o.glob('*') if p.suffix in ['.json','.log','.xml','.py']]+[p for p in (o/'native-metadata').glob('*') if p.is_file()]
with zipfile.ZipFile(f/'validation.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for p in sorted(set(paths)):z.write(p,p.relative_to(o).as_posix())
report=dict(sourceBase='ae4bf23',status='pass-attribution-completed',tests=cases,passed=4,native=native,sourceHashes={p:digest(r/p) for p in sources},unchangedDefaultPrograms=674,passTimingDefaultOff=True,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceZipBytes=(f/'validation.zip').stat().st_size,evidenceZipSha256=digest(f/'validation.zip'))
assert report['evidenceZipBytes']<8*1024*1024;(f/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
p=r/'docs/development/artifact-manifest.json';d=json.loads(p.read_text());d['milestones'].insert(0,dict(path='runs/'+o.name,name='GPU 通道成本归因',status='PassAttributionCompleted',sourceBase='ae4bf23',evidence='docs/acceptance/nr/gpu-pass-attribution.md',checksPassed=4,nativeProcesses=1,renderedFrames=32,capturedFrames=0,formalPerformancePassed=False));p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'docs/acceptance/nr/gpu-pass-attribution.md').write_text('''# GPU 通道成本归因

## 结果与范围

通道计时通过两种配置的四项检查。
一次原生采集执行三十二帧，初始八帧单独排除。
其余二十四帧具有十九个可用通道结果。
同步日志无错误，卸载分配残留为零。

## 实际成本

场景尺寸为 1920×1080，采用默认渲染路径。
本次采集显式启用通道计时，未保存截图。
两端完成时间包含资源屏障及管线等待影响。
该数据用于热点归因，正式净收益另行比较。

| 通道 | 均值，毫秒 |
| --- | ---: |
| 最终绘制 | 8.982741 |
| 不透明快照 | 5.630677 |
| 反射计算 | 1.662409 |
| 级联阴影 | 1.446869 |
| 蒙皮 | 0.598936 |
| 反射运动数据 | 0.559147 |
| 阴影分块边界 | 0.475364 |
| 主深度 | 0.320128 |

蒙皮输出还被快照、阴影及最终绘制共同读取。
接续检查其数据宽度、写入量及跨通道复用。
反射运动数据的共享需单独核对数值契约。
候选按实际成本上限及精度要求进入实施。

## 兼容与预算

通道计时通过显式选项启用，默认关闭。
两种配置的 674 份着色程序保持摘要一致。
源码、程序及 1729 项原生输入摘要保持一致。
时间戳及名称表按帧槽与固定容量持有。

本单元没有执行性能对照及正式长采样。
CPU 八毫秒及 GPU 16.6 毫秒门槛保持有效。
整体画质保持 `failed-user-review`。
全部产物与精简证据保存在 D 盘项目内。

[结果摘要](evidence/2026-11-09/gpu-pass-attribution/results.json)保存分段与来源。
[精简证据](evidence/2026-11-09/gpu-pass-attribution/validation.zip)保存命令、日志和逐帧结果。
接口见[GPU 通道计时](../../development/gpu-pass-timing.md)。
任务见[实施计划](../../plans/2026-11-09-gpu-pass-attribution.md)。
''',encoding='utf-8')
p=r/'docs/plans/2026-11-09-gpu-pass-attribution.md';s=p.read_text(encoding='utf-8').replace('状态：实施中。','状态：归因完成。');s+='\n## 执行结果\n\n四项所属检查及一次原生采集通过。\n实际十九个通道的结果全部可用。\n蒙皮输出的数据宽度进入后续优化评估。\n详见[验收记录](../acceptance/nr/gpu-pass-attribution.md)。\n';p.write_text(s,encoding='utf-8')
for n,m,a in [('README.md','四像素组接受占消费采样约 30.23%，后续按主场景分段选择优化。','\n[GPU 通道归因](docs/acceptance/nr/gpu-pass-attribution.md)已接入显式分段计时。\n十九个通道均有实际结果，后续核对共享形变输出的数据成本。'),('docs/plans/azure-engine-plan.md','隐藏三角形样本与完整补充成本按主场景分段继续定位。','\n[GPU 通道归因](../acceptance/nr/gpu-pass-attribution.md)取得十九个通道的实际结果。\n快照与最终绘制合计约 14.61 毫秒，蒙皮约为 0.60 毫秒。\n共享形变输出的数据宽度进入后续优化范围。')]:
 p=r/n;s=p.read_text(encoding='utf-8');assert m in s;p.write_text(s.replace(m,m+a,1),encoding='utf-8')
p=r/'CHANGELOG.md';s=p.read_text(encoding='utf-8');at=s.find('\n## ');s=s[:at]+'\n## 2026-11-09 GPU 通道成本归因\n\n- 接入默认关闭的有界通道计时及帧槽回收。\n- 两种配置的四项检查通过，十九个原生通道结果可用。\n- 正式画质与帧预算继续按原条件验收。\n'+s[at:];p.write_text(s,encoding='utf-8')
s=(r/'build/runs/20261109-015039-sparse-consumer-attribution-e39118/commit.py').read_text().replace('sparse-consumer-attribution','gpu-pass-attribution').replace("'docs/development/surface-radiance-cache.md'","'docs/development/gpu-pass-timing.md'").replace('完成稀疏照明消费归因','接入有界 GPU 通道计时及热点归因');(o/'commit.py').write_text(s,encoding='utf-8')
print(report['evidenceZipBytes'])
