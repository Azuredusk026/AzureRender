from pathlib import Path
r=Path.cwd()
def edit(name,old,new):
 p=r/name;s=p.read_text(encoding='utf-8');assert old in s,(name,old);p.write_text(s.replace(old,new,1),encoding='utf-8')
edit('src/render/RenderGraph.hpp','bool useFullInlineCallback = false) const;','bool useFullInlineCallback = false,\n        const std::function<void(PassId, bool)>& passBoundary = {}) const;')
edit('src/render/RenderGraph.cpp','const std::function<bool(PassId)>& executeRecorded, bool useFullInlineCallback) const {','const std::function<bool(PassId)>& executeRecorded, bool useFullInlineCallback,\n    const std::function<void(PassId, bool)>& passBoundary) const {')
edit('src/render/RenderGraph.cpp','for (const auto pass : executionOrder_) {\n        const auto& buffers','for (const auto pass : executionOrder_) {\n        if(passBoundary)passBoundary(pass,true);\n        const auto& buffers')
edit('src/render/RenderGraph.cpp','if (passes_[pass].afterRenderPass) passes_[pass].afterRenderPass(*recorder);\n        }\n    }','if (passes_[pass].afterRenderPass) passes_[pass].afterRenderPass(*recorder);\n        }\n        if(passBoundary)passBoundary(pass,false);\n    }')
edit('src/app/AzureRenderOptions.hpp','bool gpuTimingEnabled = false;','bool gpuTimingEnabled = false;\n    bool gpuPassTimingEnabled = false;')
edit('src/app/CommandLine.cpp','[--gpu-timing] [--gpu-timing-output <json path>]','[--gpu-timing] [--gpu-pass-timing] [--gpu-timing-output <json path>]')
edit('src/app/CommandLine.cpp','"  --gpu-timing-output <json>          GPU pass timing\\n\\n"','"  --gpu-timing-output <json>          GPU frame timing\\n"\n    "  --gpu-pass-timing                  Bounded render-graph pass timing\\n\\n"')
edit('src/app/CommandLine.cpp','} else if (argument == "--gpu-timing") {','} else if (argument == "--gpu-pass-timing") {\n            parsed.options.gpuPassTimingEnabled = true;\n            parsed.options.gpuTimingEnabled = true;\n        } else if (argument == "--gpu-timing") {')
edit('src/app/AzureRenderApp.hpp','static constexpr std::uint32_t kTimestampQueryCount = 4;','static constexpr std::uint32_t kTimestampQueryCount = 4;\n    static constexpr std::uint32_t kMaximumTimedPasses = 64;')
edit('src/app/AzureRenderApp.hpp','std::vector<VkQueryPool> timestampQueryPools_;','std::vector<VkQueryPool> timestampQueryPools_;\n    std::array<std::vector<std::string>, kMaxFramesInFlight> timestampPassNames_;\n    struct GpuPassTimingSummary {std::string name;std::uint64_t samples=0;double totalMs=0,minMs=0,maxMs=0;};\n    std::vector<GpuPassTimingSummary> gpuPassTiming_;\n    void collectGpuPassTiming(std::size_t frameIndex);')
edit('src/app/AzureRenderApp.cpp','createInfo.queryCount = kTimestampQueryCount;','createInfo.queryCount = kTimestampQueryCount+(runOptions_.gpuPassTimingEnabled?2*kMaximumTimedPasses:0);')
edit('src/app/AzureRenderFrame.cpp','sceneContext.timestampQueryCount = kTimestampQueryCount;','sceneContext.timestampQueryCount = kTimestampQueryCount;')
edit('src/app/AzureRenderFrame.cpp','            kTimestampQueryCount);','            kTimestampQueryCount+(runOptions_.gpuPassTimingEnabled?2*kMaximumTimedPasses:0));')
old='    const auto executionStart = std::chrono::steady_clock::now();\n    graph.execute('
new='''    std::function<void(azurerender::RenderGraph::PassId,bool)> passTiming;
    std::vector<int> passSlots;
    if(runOptions_.gpuPassTimingEnabled){
        auto& names=timestampPassNames_[currentFrame_];names.clear();passSlots.assign(graph.passes().size(),-1);
        for(const auto pass:graph.executionOrder()){
            if(names.size()==kMaximumTimedPasses)break;
            passSlots[pass]=static_cast<int>(names.size());names.push_back(graph.passes()[pass].name);
        }
        passTiming=[&](azurerender::RenderGraph::PassId pass,bool begin){
            const int slot=passSlots[pass];if(slot<0)return;
            commandRecorder.writeTimestamp(timestampQueryPools_[currentFrame_],kTimestampQueryCount+2*static_cast<unsigned>(slot)+(begin?0:1),VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
        };
    }
    const auto executionStart = std::chrono::steady_clock::now();
    graph.execute('''
edit('src/app/AzureRenderFrame.cpp',old,new)
edit('src/app/AzureRenderFrame.cpp','}, runOptions_.parallelRecordingDisabled);','}, runOptions_.parallelRecordingDisabled,passTiming);')
edit('src/app/AzureRenderCapture.cpp','    appendFrameTimingCsv(shadowMs, sceneMs, postProcessMs, frameMs);','    collectGpuPassTiming(frameIndex);\n    appendFrameTimingCsv(shadowMs, sceneMs, postProcessMs, frameMs);')
p=r/'src/app/AzureRenderCapture.cpp';s=p.read_text(encoding='utf-8');marker='void AzureRenderApp::appendFrameTimingCsv('
method='''void AzureRenderApp::collectGpuPassTiming(const std::size_t frameIndex) {
    if(!runOptions_.gpuPassTimingEnabled)return;
    const auto& names=timestampPassNames_[frameIndex];if(names.empty())return;
    std::array<std::uint64_t,kMaximumTimedPasses*4> values{};
    const auto count=static_cast<std::uint32_t>(names.size()*2);
    const auto result=vkGetQueryPoolResults(device_,timestampQueryPools_[frameIndex],kTimestampQueryCount,count,
        count*2*sizeof(std::uint64_t),values.data(),2*sizeof(std::uint64_t),VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WITH_AVAILABILITY_BIT);
    if(result!=VK_SUCCESS&&result!=VK_NOT_READY)vkCheck(result,"vkGetQueryPoolResults(pass timestamps)");
    const auto mask=timestampValidBits_>=64?std::numeric_limits<std::uint64_t>::max():(std::uint64_t{1}<<timestampValidBits_)-1;
    nlohmann::json entries=nlohmann::json::array();
    for(std::size_t i=0;i<names.size();++i){
        if(!values[4*i+1]||!values[4*i+3]){entries.push_back({{"name",names[i]},{"available",false}});continue;}
        const auto ticks=(values[4*i+2]-values[4*i])&mask;
        const double ms=static_cast<double>(ticks)*timestampPeriodNanoseconds_*1.e-6;
        entries.push_back({{"name",names[i]},{"available",true},{"milliseconds",ms}});
        auto found=std::find_if(gpuPassTiming_.begin(),gpuPassTiming_.end(),[&](const auto& item){return item.name==names[i];});
        if(found==gpuPassTiming_.end()){
            if(gpuPassTiming_.size()==128)continue;
            gpuPassTiming_.push_back({names[i],1,ms,ms,ms});
        }else{++found->samples;found->totalMs+=ms;found->minMs=std::min(found->minMs,ms);found->maxMs=std::max(found->maxMs,ms);}
    }
    if(runOptions_.gpuTimingOutput.empty())return;
    auto path=std::filesystem::u8path(runOptions_.gpuTimingOutput);path.replace_extension(".passes.jsonl");
    std::ofstream output(path,std::ios::binary|(gpuTiming_.samples==1?std::ios::trunc:std::ios::app));
    if(output)output<<nlohmann::json{{"frame",gpuTiming_.samples},{"passes",std::move(entries)}}.dump()<<'\\n';
}

''';assert marker in s;p.write_text(s.replace(marker,method+marker,1),encoding='utf-8')
edit('src/app/AzureRenderCapture.cpp','    output\n        << std::fixed << std::setprecision(6)\n        << "{\\n"','''    nlohmann::json passTimings=nlohmann::json::array();
    for(const auto& pass:gpuPassTiming_)passTimings.push_back({{"name",pass.name},{"samples",pass.samples},{"averageMs",pass.totalMs/static_cast<double>(pass.samples)},{"minMs",pass.minMs},{"maxMs",pass.maxMs}});
    output
        << std::fixed << std::setprecision(6)
        << "{\\n"''')
edit('src/app/AzureRenderCapture.cpp','        << "  \\"samples\\": " << gpuTiming_.samples << ",\\n"','        << "  \\"samples\\": " << gpuTiming_.samples << ",\\n"') if False else None
# Add immediately before the uniquely named report timestamp-period field.
edit('src/app/AzureRenderCapture.cpp','        << "  \\"timestampPeriodNanoseconds\\": "','        << "  \\"timestampPeriodNanoseconds\\": "') if False else None
p=r/'src/app/AzureRenderCapture.cpp';s=p.read_text(encoding='utf-8');m='        << "  \\"runtimeTraceFrames\\": "' # spelling handled by literal below
m='        << "  \\"runtimeTraceFrames\\": "'.replace('\\\\','\\')
# Use line matching to avoid escaping the JSON key twice.
lines=s.splitlines(keepends=True);at=next(i for i,line in enumerate(lines) if '<< gameRouteFrames_.size()' in line)
lines.insert(at+1,'        << "  \\"gpuPassTimings\\": " << passTimings.dump() << ",\\n"\n'.replace('\\\\','\\'))
p.write_text(''.join(lines),encoding='utf-8')
