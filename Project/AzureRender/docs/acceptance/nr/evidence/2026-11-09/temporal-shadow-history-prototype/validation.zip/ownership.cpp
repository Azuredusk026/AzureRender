#include "support/VulkanComputeFixture.hpp"
#include "resources/BinaryFile.hpp"
#include <array>
#include <cstring>
using namespace azurerender;
int main(int argc,char** argv)try{
    if(argc!=3)throw std::invalid_argument("Expected vertex and fragment shaders");
    test::VulkanComputeFixture host(true,false,false,false,false,true);auto& backend=*host.backend;
    rhi::GpuImage image{};std::array<rhi::GpuBuffer,2> buffers{};
    VkImageView view{};VkRenderPass pass{};VkFramebuffer framebuffer{};
    VkDescriptorSetLayout setLayout{};VkDescriptorPool pool{};VkPipelineLayout layout{};VkShaderModule vertex{},fragment{};VkPipeline pipeline{};
    auto cleanup=std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*){
        if(pipeline)backend.destroyPipeline(pipeline);if(vertex)backend.destroyShaderModule(vertex);if(fragment)backend.destroyShaderModule(fragment);
        if(layout)backend.destroyPipelineLayout(layout);if(pool)backend.destroyDescriptorPool(pool);if(setLayout)backend.destroyDescriptorSetLayout(setLayout);
        if(framebuffer)backend.destroyFramebuffer(framebuffer);if(pass)backend.destroyRenderPass(pass);if(view)backend.destroyImageView(view);
        host.allocator.destroyImage(image);for(auto& buffer:buffers)host.allocator.destroyBuffer(buffer);
    });
    image=host.allocator.createImage2D(32,32,VK_FORMAT_R8G8B8A8_UNORM,VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT);
    view=backend.createImageView(image.image,VK_FORMAT_R8G8B8A8_UNORM,VK_IMAGE_ASPECT_COLOR_BIT,1);
    rhi::RenderPassDesc render;render.attachments={{VK_FORMAT_R8G8B8A8_UNORM,VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,true,true,false}};
    pass=backend.createRenderPass(render);framebuffer=backend.createFramebuffer({pass,{view},32,32});
    for(auto& buffer:buffers)buffer=host.allocator.createBuffer(1024*8,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
    setLayout=backend.createDescriptorSetLayout({{0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_FRAGMENT_BIT}});
    rhi::DescriptorPoolDesc poolDesc;poolDesc.maxSets=2;poolDesc.sizes={{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,2}};pool=backend.createDescriptorPool(poolDesc);
    const auto sets=backend.allocateDescriptorSets(pool,setLayout,2);
    for(unsigned i=0;i<2;++i)backend.writeDescriptorBuffer({sets[i],0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,buffers[i].buffer,buffers[i].size});
    const rhi::PushConstantRangeDesc push{VK_SHADER_STAGE_VERTEX_BIT,4};layout=backend.createPipelineLayout(setLayout,&push);
    vertex=backend.createShaderModule(readBinaryFile(argv[1]));fragment=backend.createShaderModule(readBinaryFile(argv[2]));
    rhi::GraphicsPipelineDesc graphics;graphics.vertexShader=vertex;graphics.fragmentShader=fragment;graphics.layout=layout;graphics.renderPass=pass;
    graphics.colorAttachmentCount=1;graphics.colorWriteMasks={0};graphics.depthTest=false;graphics.depthWrite=false;graphics.cullMode=VK_CULL_MODE_NONE;
    pipeline=backend.createGraphicsPipeline(graphics);
    unsigned checked=0;
    for(unsigned layers:{1U,32U,128U})for(unsigned iteration=0;iteration<8;++iteration)for(unsigned workflow=0;workflow<2;++workflow){
        auto& buffer=buffers[workflow];std::memset(buffer.mapped,0xff,buffer.size);host.allocator.flush(buffer,0,buffer.size);
        const unsigned seed=iteration*13+workflow*19;
        host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer){
            commands.bufferBarrier({buffer.buffer,0,buffer.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});
            commands.imageBarrier({image.image,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,1,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,VK_ACCESS_MEMORY_WRITE_BIT,VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT,VK_IMAGE_ASPECT_COLOR_BIT});
            rhi::RenderPassBeginDesc begin;begin.renderPass=pass;begin.framebuffer=framebuffer;begin.extent={32,32};begin.clearValues.resize(1);
            commands.beginRenderPass(begin);commands.setViewport(32,32);commands.setScissor({32,32});commands.bindPipeline(pipeline);commands.bindDescriptorSet(layout,sets[workflow]);
            commands.pushConstants(layout,VK_SHADER_STAGE_VERTEX_BIT,0,&seed,4);commands.draw(layers*3);commands.endRenderPass();
            commands.bufferBarrier({buffer.buffer,0,buffer.size,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
        });
        host.allocator.invalidate(buffer,0,buffer.size);const auto* values=static_cast<const std::uint32_t*>(buffer.mapped);
        for(unsigned pixel=0;pixel<1024;++pixel){
            const auto key=values[pixel*2],value=values[pixel*2+1];bool admitted=false;
            for(unsigned layer=0;layer<layers;++layer)admitted|=key==(layer+seed)%128;
            if(!admitted||value!=(key^0xa5a5a5a5U))throw std::runtime_error("Overlapping fragments produced a torn history record");
            ++checked;
        }
    }
    cleanup.reset();const auto stats=host.allocator.statistics();
    if(host.errors.load()||stats.liveBuffers||stats.liveImages)throw std::runtime_error("Fragment ownership validation or lifetime failure");
    std::cout<<"Fragment first-writer ownership: "<<checked<<" records across two workflows; zero validation errors; zero live allocations\n";
    return 0;
}catch(const test::VulkanFeatureUnavailable& e){std::cerr<<e.what()<<'\n';return 77;}
catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
