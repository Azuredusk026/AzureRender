from pathlib import Path
import json,shutil
o=Path(__file__).resolve().parent
for p in o.glob('timing-*.log'):shutil.copyfile(p,o/('unqualified-'+p.name))
for p in o.glob('fixture-*.json'):
 data=json.loads(p.read_text());data['baselineShaderPath']=str(o/'baseline.spv');p.write_text(json.dumps(data,indent=2))
s=(o/'timing.cpp').read_text();start=s.index('    if(!host.timestampBits)');end=s.index('    cleanup.reset();if(host.errors.load())',start)
paired='''    if(!host.timestampBits)throw std::runtime_error("Timestamp support unavailable");
    const auto referenceShader=backend.createShaderModule(readBinaryFile(historyFixture.at("baselineShaderPath").get<std::string>()));
    const auto referencePipeline=backend.createComputePipeline({referenceShader,layout});
    VkQueryPool timingPool;VkQueryPoolCreateInfo timingDesc{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};
    timingDesc.queryType=VK_QUERY_TYPE_TIMESTAMP;timingDesc.queryCount=6;
    test::vkRequire(vkCreateQueryPool(host.device,&timingDesc,nullptr,&timingPool),"vkCreateQueryPool");
    std::array<std::vector<double>,3> milliseconds;
    for(unsigned iteration=0;iteration<192;++iteration){
        host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer command){
            vkCmdResetQueryPool(command,timingPool,0,6);
            commands.bindComputeDescriptorSet(layout,set);
            for(unsigned role=0;role<3;++role){
                commands.bindComputePipeline(role==1?pipeline:referencePipeline);
                commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});
                vkCmdWriteTimestamp(command,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,timingPool,role*2);
                if(role==1&&historyFixture.value("cacheWrites",true)){
                    commands.bufferBarrier({historyWrite.buffer,0,historyBytes,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_MEMORY_READ_BIT|VK_ACCESS_MEMORY_WRITE_BIT,VK_ACCESS_TRANSFER_WRITE_BIT});
                    vkCmdFillBuffer(command,historyWrite.buffer,0,historyBytes,UINT32_MAX);
                    commands.bufferBarrier({historyWrite.buffer,0,historyBytes,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});
                }
                commands.dispatch(count,1,1);
                vkCmdWriteTimestamp(command,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,timingPool,role*2+1);
            }
        });
        std::uint64_t ticks[6]{};
        test::vkRequire(vkGetQueryPoolResults(host.device,timingPool,0,6,sizeof(ticks),ticks,sizeof(ticks[0]),VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT),"vkGetQueryPoolResults");
        if(iteration>=128)for(unsigned role=0;role<3;++role)
            milliseconds[role].push_back(double(ticks[role*2+1]-ticks[role*2])*host.properties.limits.timestampPeriod/1000000.0);
    }
    vkDestroyQueryPool(host.device,timingPool,nullptr);
    backend.destroyPipeline(referencePipeline);backend.destroyShaderModule(referenceShader);
    for(unsigned role=0;role<3;++role){
        auto& values=milliseconds[role];double total=0;for(auto ms:values)total+=ms;std::sort(values.begin(),values.end());
        std::cout<<"PAIRED_GPU role="<<role<<" meanMs="<<total/values.size()<<" medianMs="<<(values[31]+values[32])*.5<<" samples="<<values.size()<<"\\n";
    }
'''
(o/'timing.cpp').write_text(s[:start]+paired+s[end:]);print('Prepared same-submit baseline/candidate/baseline timestamps')
