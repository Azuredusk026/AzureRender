import math,struct,itertools
INVALID=0xffffffff
class PrimitiveRanges:
 def __init__(self):self.next=0
 def reserve(self,indexCount):
  if not isinstance(indexCount,int) or indexCount<=0 or self.next+indexCount>INVALID:return None
  base=self.next;self.next+=indexCount;return base
def primitive_key(base,firstIndex,triangle,indexCount):
 if min(base,firstIndex,triangle,indexCount)<0:return INVALID
 offset=firstIndex+triangle*3
 return base+offset if offset+2<indexCount and base+offset<INVALID else INVALID
class FrameIdentity:
 def __init__(self):self.previous=None
 def begin(self,values,extent,layoutChanged=False):
  valid=all(math.isfinite(v) for v in values) and all(v>0 for v in extent)
  current=(struct.pack('<'+'f'*len(values),*values),tuple(extent)) if valid else None
  reuse=current is not None and current==self.previous and not layoutChanged
  self.previous=current;return reuse
def dirty_rect(low,high,matrix,extent):
 # Column-major clip matrix. Invalid projective bounds dirty the full view.
 width,height=extent;full=(0,0,width,height);projected=[]
 if min(width,height)<=0:return full
 for corner in itertools.product(*[(a,b) for a,b in zip(low,high)]):
  v=(*corner,1.0);q=[sum(matrix[column*4+row]*v[column] for column in range(4)) for row in range(4)]
  if not all(math.isfinite(x) for x in q) or q[3]<=0:return full
  projected.append(((q[0]/q[3]*.5+.5)*width,(q[1]/q[3]*.5+.5)*height))
 return (min(width,max(0,math.floor(min(p[0] for p in projected))-2)),min(height,max(0,math.floor(min(p[1] for p in projected))-2)),
         max(0,min(width,math.ceil(max(p[0] for p in projected))+2)),max(0,min(height,math.ceil(max(p[1] for p in projected))+2)))
def intersects_footprint(rect,pixel,radius):
 if not all(math.isfinite(v) for v in (*pixel,radius)) or radius<0:return True
 if rect[0]>=rect[2] or rect[1]>=rect[3]:return False
 reach=math.ceil(radius+.5)+2
 return pixel[0]+reach>=rect[0] and pixel[0]-reach<rect[2] and pixel[1]+reach>=rect[1] and pixel[1]-reach<rect[3]
