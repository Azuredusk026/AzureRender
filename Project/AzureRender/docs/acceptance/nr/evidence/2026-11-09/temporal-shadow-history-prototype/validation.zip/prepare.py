from pathlib import Path
import sys,os,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;source=o.parent/'20261109-192439-intel-shadow-filter-precision-d28d29';data=o.parent/'20261109-181501-native-producer-gpu-intermediates-de1e3d'
sys.path.insert(0,str(r/'tools'));from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'))
s=(source/'collector.cpp').read_text().replace('    unsigned width=16,height=8;','    nlohmann::json historyFixture;\n    unsigned width=16,height=8;')
s=s.replace('width=fixture.at("width");height=', 'historyFixture=fixture;\n        width=fixture.at("width");height=')
s=s.replace('rhi::GpuBuffer output{},records{},queryBuffer{},staging{},clearStaging{};','rhi::GpuBuffer output{},records{},queryBuffer{},staging{},clearStaging{},historyRead{},historyWrite{},historyUpload{};')
s=s.replace('&queryBuffer,&staging,&clearStaging}', '&queryBuffer,&staging,&clearStaging,&historyRead,&historyWrite,&historyUpload}')
needle='    setLayout=backend.createDescriptorSetLayout('
at=s.index(needle)
s=s[:at]+'''    const VkDeviceSize historyBytes=expected.size()*8;
    historyRead=host.allocator.createBuffer(historyBytes,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT|VK_BUFFER_USAGE_TRANSFER_DST_BIT,false);
    historyWrite=host.allocator.createBuffer(historyBytes,VK_BUFFER_USAGE_STORAGE_BUFFER_BIT|VK_BUFFER_USAGE_TRANSFER_DST_BIT|VK_BUFFER_USAGE_TRANSFER_SRC_BIT,false);
    historyUpload=host.allocator.createBuffer(historyBytes,VK_BUFFER_USAGE_TRANSFER_SRC_BIT,true);
    const auto seed=readBinaryFile(historyFixture.at("seedPath").get<std::string>());
    if(seed.size()!=expected.size()*sizeof(Vec4))throw std::runtime_error("Invalid seed size");
    auto* entries=static_cast<std::uint32_t*>(historyUpload.mapped);
    for(unsigned index=0;index<expected.size();++index){
        const unsigned group=historyFixture.value("mixed",false)?index%100:(index/256)%100;
        entries[index*2]=group<historyFixture.value("hitPercent",0U)?index:UINT32_MAX;
        std::memcpy(entries+index*2+1,seed.data()+index*sizeof(Vec4),4);
    }
    host.allocator.flush(historyUpload,0,historyBytes);
    host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer command){
        commands.bufferBarrier({historyUpload.buffer,0,historyBytes,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT});
        VkBufferCopy copy{0,0,historyBytes};vkCmdCopyBuffer(command,historyUpload.buffer,historyRead.buffer,1,&copy);
        vkCmdFillBuffer(command,historyWrite.buffer,0,historyBytes,UINT32_MAX);
        for(auto* buffer:{&historyRead,&historyWrite})commands.bufferBarrier({buffer->buffer,0,historyBytes,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});
    });
'''+s[at:]
s=s.replace('{0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},','{0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},\n        {43,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},{44,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},')
s=s.replace('{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,3}', '{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,5}')
s=s.replace('    backend.writeDescriptorBuffer({set,0,','    backend.writeDescriptorBuffer({set,43,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,historyRead.buffer,historyBytes});\n    backend.writeDescriptorBuffer({set,44,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,historyWrite.buffer,historyBytes});\n    backend.writeDescriptorBuffer({set,0,')
(o/'collector.cpp').write_text(s)
for name in ['compile-command.txt','link-command.txt']:(o/name).write_text((source/name).read_text().replace(str(source),str(o)).replace(source.as_posix(),o.as_posix()))
(o/'object_shadow.glsl').write_text((source/'object_shadow_anchored.glsl').read_text())
s=(data/'filter.comp').read_text()
s=s.replace('#include "object_shadow.glsl"','''#include "object_shadow.glsl"
layout(set=0,binding=43,std430) readonly buffer History { uvec2 values[]; } history;
layout(set=0,binding=44,std430) buffer Current { uvec2 values[]; } current;
''')
needle='        vec2 filtered=objectShadowFilter(objectDepth,sharedSampler,a.xy,a.z,ivec2(b.xy),c,b.zw);'
assert needle in s
replacement='''        uint key=i-11u;
        vec2 filtered;
#if CACHE_MODE==2
        uvec2 previous=history.values[key];
        if(previous.x==key&&!isnan(uintBitsToFloat(previous.y)))filtered=vec2(uintBitsToFloat(previous.y),0);
        else
#endif
        filtered=objectShadowFilter(objectDepth,sharedSampler,a.xy,a.z,ivec2(b.xy),c,b.zw);
#if CACHE_MODE!=0
        if(atomicCompSwap(current.values[key].x,0xffffffffu,key)==0xffffffffu)
            current.values[key].y=floatBitsToUint(filtered.x);
#endif'''
s=s.replace(needle,replacement)
s=s.replace('vec2 clear=objectShadowFilter(clearDepth,sharedSampler,vec2(.5),a.z,ivec2(0),vec4(0,0,1,1),vec2(0));','vec2 clear=vec2(1,0);')
for name,mode in [('baseline',0),('producer',1),('consumer',2)]:(o/(name+'.comp')).write_text(s.replace('#version 450','#version 450\n#define CACHE_MODE '+str(mode)))
fixture=json.loads((source/'fixture-d16.json').read_text());fixture.update(seedPath=str(data/'filter-output.bin'),hitPercent=0,mixed=False)
for name,percent,mixed in [('cold',0,False),('warm',100,False),('coherent',80,False),('mixed',80,True)]:
 fixture.update(hitPercent=percent,mixed=mixed);(o/('fixture-'+name+'.json')).write_text(json.dumps(fixture,indent=2))
print('Prepared device-local eight-byte history with first-writer ownership')
