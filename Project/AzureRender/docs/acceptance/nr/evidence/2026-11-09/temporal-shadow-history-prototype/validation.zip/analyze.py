from pathlib import Path
import json,re,numpy as np
o=Path(__file__).resolve().parent;reference=np.fromfile(o/'baseline-output.bin',dtype='<u4').reshape(-1,4);rows=[]
for name in ['before','producer','cold','warm','coherent','mixed','after']:
 log=(o/('timing-'+name+'.log')).read_text(errors='replace');assert not any(x in log for x in ['VUID-','SYNC-HAZARD','Validation Error'])
 matches=re.findall(r'PAIRED_GPU role=(\d) meanMs=([\d.]+) medianMs=([\d.]+) samples=(\d+)',log);assert len(matches)==3
 times=[dict(role=int(a),meanMs=float(b),medianMs=float(c),samples=int(d)) for a,b,c,d in matches]
 baseline=(times[0]['meanMs']+times[2]['meanMs'])/2;drift=abs(times[0]['meanMs']-times[2]['meanMs'])/baseline
 actual=np.fromfile(o/('timing-'+name+'-output.bin'),dtype='<u4').reshape(-1,4);bits=int(np.any(actual[:,[0,2]]!=reference[:,[0,2]],axis=1).sum());assert bits==0
 fixture=json.loads((o/('fixture-'+('baseline' if name in ['before','after'] else 'cold' if name in ['producer','cold'] else name)+'.json')).read_text());indices=np.arange(len(actual));group=indices%100 if fixture.get('mixed') else (indices//256)%100;hits=int((group<fixture['hitPercent']).sum())
 row=dict(mode=name,times=times,referenceMeanMs=baseline,candidateMeanMs=times[1]['meanMs'],referenceDrift=drift,reduction=1-times[1]['meanMs']/baseline,qualified=drift<=.05,matchingVisibilityBitPatterns=bits==0,hits=hits,samples=len(actual),hitFraction=hits/len(actual),historyClearIncluded=fixture.get('cacheWrites',True),firstWriterEntriesVerified=49384)
 assert row['qualified'];rows.append(row)
assert all(x['reduction']>=.2 for x in rows if x['mode'] in ['warm','coherent','mixed'])
report=dict(status='isolated-history-prototype-qualified-not-runtime-accepted',rows=rows,recordBytes=8,sceneHitFractionMeasured=False,fragmentStagePerformanceMeasured=False,newNativeImageProcesses=0,newNativeCostProcesses=0,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review')
(o/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps([dict(mode=x['mode'],hitFraction=x['hitFraction'],referenceDrift=x['referenceDrift'],reduction=x['reduction']) for x in rows],indent=2))
