import unittest,random,math,itertools,json
from pathlib import Path
from policy import PrimitiveRanges,primitive_key,FrameIdentity,dirty_rect,intersects_footprint,INVALID
class PolicyTests(unittest.TestCase):
 def test_identity_ranges_do_not_collide(self):
  allocator=PrimitiveRanges();keys=set()
  for count in [6,18,300,9]:
   base=allocator.reserve(count)
   for triangle in range(count//3):
    key=primitive_key(base,0,triangle,count);self.assertNotIn(key,keys);keys.add(key)
  self.assertEqual(primitive_key(0,0,2,6),INVALID)
  allocator.next=INVALID-3;self.assertEqual(allocator.reserve(3),INVALID-3)
  self.assertIsNone(allocator.reserve(1));self.assertIsNone(allocator.reserve(-1))
 def test_view_change_and_reload_invalidate(self):
  state=FrameIdentity();self.assertFalse(state.begin([0.,1.],(128,96)))
  self.assertTrue(state.begin([0.,1.],(128,96)))
  self.assertFalse(state.begin([-0.,1.],(128,96)))
  self.assertFalse(state.begin([-0.,1.],(128,96),True))
  self.assertFalse(state.begin([math.nan,1.],(128,96)))
  self.assertFalse(state.begin([0.,1.],(128,96)))
  self.assertFalse(state.begin([0.,1.],(256,96)))
 def test_projected_rect_contains_interior_points(self):
  rng=random.Random(319);extent=(2048,2048);low=(-.2,-.3,-3.);high=(.4,.5,-1.5)
  orthographic=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]
  perspective=[1,0,0,0,0,1,0,0,0,0,1,-1,0,0,0,0]
  for matrix in [orthographic,perspective]:
   rect=dirty_rect(low,high,matrix,extent)
   for i in range(2048):
    p=[rng.uniform(a,b) for a,b in zip(low,high)]+[1]
    q=[sum(matrix[c*4+r]*p[c] for c in range(4)) for r in range(4)]
    xy=[(q[k]/q[3]*.5+.5)*extent[k] for k in range(2)]
    self.assertTrue(rect[0]<=xy[0]<rect[2] and rect[1]<=xy[1]<rect[3])
   self.assertEqual(dirty_rect(low,high,[0.]*16,extent),(0,0,2048,2048))
  rect=dirty_rect((-10,-10,-3),(-9,-9,-2),orthographic,extent)
  self.assertEqual(rect,(0,0,0,0));self.assertFalse(intersects_footprint(rect,(0,0),16))
 def test_filter_expansion_covers_moving_caster(self):
  rect=(100,100,120,120)
  self.assertTrue(intersects_footprint(rect,(85,110),16))
  self.assertFalse(intersects_footprint(rect,(50,110),16))
  self.assertTrue(intersects_footprint(rect,(math.nan,110),16))
 def test_first_writer_owns_the_pair(self):
  # All store orders allowed by two ordinary key/value writes include tears.
  torn=0
  for order in itertools.permutations([0,1,2,3]):
   if order.index(0)>order.index(1) or order.index(2)>order.index(3):continue
   key=value=None
   for operation in order:
    if operation%2==0:key=operation//2
    else:value=operation//2
   torn+=key!=value
  self.assertGreater(torn,0)
  for winner in [0,1]:
   key=INVALID;value=None
   for candidate in [winner,1-winner]:
    if key==INVALID:key=candidate;value=candidate
   self.assertEqual(key,value)
if __name__=='__main__':unittest.main()
