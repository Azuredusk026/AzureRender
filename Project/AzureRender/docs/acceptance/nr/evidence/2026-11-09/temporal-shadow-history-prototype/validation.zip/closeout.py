from pathlib import Path
import os,sys,json,hashlib,zipfile,shutil,subprocess
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,tracked_paths,write_json
from artifact_cleanup import remove_artifact
from build_provenance import verify,digest
os.environ.update(managed_environment(o/'tmp'))
policy=subprocess.run([sys.executable,'-X','utf8',str(o/'test_policy.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(o/'policy-check.log').write_text(policy.stdout);assert policy.returncode==0
report=json.loads((o/'analysis.json').read_text());ownership=[]
for device in ['nvidia','intel']:
 s=(o/('ownership-'+device+'.log')).read_text();assert '49152 records across two workflows' in s and 'zero live allocations' in s and not any(x in s for x in ['VUID-','SYNC-HAZARD','Validation Error'])
 ownership.append(dict(device=device,records=49152,workflows=2,maximumOverlappingLayers=128,validationClean=True,liveAllocationsAfterUnload=0))
builds={}
for config in ['release','debug']:
 p=r/('build/ninja-msvc-'+config)/'build-provenance.json';m=json.loads(p.read_text());verify(r,m);shutil.copyfile(p,o/(config+'-build-provenance.json'));builds[config]=dict(verified=True,sourceCount=len(m['source']))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py'];ph=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest();assert ph=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
report.update(ownership=ownership,policyChecks=5,builds=builds,protectedDiffSha256=ph,newFullAssetCopies=0,initialReadbackUsageFailureCorrected=True,interprocessTimingsQualified=False)
write_json(o/'results.json',report);dest=r/'docs/acceptance/nr/evidence/2026-11-09/temporal-shadow-history-prototype';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
selected=[p for p in sorted(o.iterdir()) if p.is_file() and p.suffix.lower() in ['.py','.cpp','.comp','.vert','.frag','.glsl','.txt','.json','.log']]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in selected:z.write(p,p.name)
assert archive.stat().st_size<8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in selected:assert hashlib.sha256(z.read(p.name)).hexdigest()==digest(p)
report['package']=dict(bytes=archive.stat().st_size,files=len(selected),sha256=digest(archive));write_json(dest/'results.json',report)
tracked=tracked_paths(r);before=shutil.disk_usage(r).free;removed=[]
for p in [o/'tmp',o/'__pycache__',*o.glob('*.exe'),*o.glob('*.obj'),*o.glob('*.spv'),*o.glob('*-output.bin')]:
 if p.exists():
  assert p.resolve().is_relative_to(o.resolve());removed.append(dict(path=str(p.resolve()),removed=remove_artifact(r/'build',p,tracked,apply=True)))
after=shutil.disk_usage(r).free;write_json(o/'cleanup.json',dict(removed=removed,freeBefore=before,freeAfter=after,observedFreedBytes=after-before));print(json.dumps(dict(package=report['package'],observedFreedBytes=after-before)))
