from pathlib import Path
import json
o=Path(__file__).resolve().parent;source=o.parent/'20261109-192439-intel-shadow-filter-precision-d28d29'
s=(o/'collector.cpp').read_text();s=s.replace('#include <fstream>','#include <fstream>\n#include <algorithm>')
s=s.replace('historyWrite{},historyUpload{};','historyWrite{},historyUpload{},historyReadback{};')
s=s.replace('&historyRead,&historyWrite,&historyUpload}', '&historyRead,&historyWrite,&historyUpload,&historyReadback}')
s=s.replace('    historyRead=host.allocator.createBuffer(', '    historyReadback=host.allocator.createBuffer(historyBytes,VK_BUFFER_USAGE_TRANSFER_DST_BIT,true);\n    historyRead=host.allocator.createBuffer(')
needle='    cleanup.reset();if(host.errors.load())';assert needle in s
timing=(source/'timing.cpp').read_text();start=timing.index('    if(!host.timestampBits)');end=timing.index('    cleanup.reset();if(host.errors.load())',start);timing=timing[start:end]
needleTimestamp='            vkCmdWriteTimestamp(command,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,timingPool,0);'
timing=timing.replace(needleTimestamp,needleTimestamp+'''
            if(historyFixture.value("cacheWrites",true)){
                commands.bufferBarrier({historyWrite.buffer,0,historyBytes,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_MEMORY_READ_BIT|VK_ACCESS_MEMORY_WRITE_BIT,VK_ACCESS_TRANSFER_WRITE_BIT});
                vkCmdFillBuffer(command,historyWrite.buffer,0,historyBytes,UINT32_MAX);
                commands.bufferBarrier({historyWrite.buffer,0,historyBytes,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});
            }
''')
ownership='''    host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer command){
        commands.bufferBarrier({historyWrite.buffer,0,historyBytes,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT|VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_ACCESS_SHADER_WRITE_BIT|VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT});
        VkBufferCopy copy{0,0,historyBytes};vkCmdCopyBuffer(command,historyWrite.buffer,historyReadback.buffer,1,&copy);
        commands.bufferBarrier({historyReadback.buffer,0,historyBytes,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
    });
    host.allocator.invalidate(historyReadback,0,historyBytes);
    const auto* historyActual=static_cast<const std::uint32_t*>(historyReadback.mapped);
    for(unsigned index=0;index<expected.size();++index){
        if(!historyFixture.value("cacheWrites",true)){
            if(historyActual[index*2]!=UINT32_MAX)throw std::runtime_error("Baseline must leave history invalid");
        }else{
            std::uint32_t visibility;std::memcpy(&visibility,&actual[index+11][0],4);
            if(historyActual[index*2]!=index||historyActual[index*2+1]!=visibility)throw std::runtime_error("History ownership or visibility bits differ");
        }
    }
    std::cout<<"History ownership verified: "<<expected.size()<<" entries\\n";
'''
s=s.replace(needle,ownership+timing+needle);(o/'timing.cpp').write_text(s)
for name in ['compile-command.txt','link-command.txt']:(o/('timing-'+name)).write_text((o/name).read_text().replace('collector.cpp','timing.cpp').replace('collector.obj','timing.obj').replace('collector.exe','timing.exe'))
fixture=json.loads((o/'fixture-cold.json').read_text());fixture['cacheWrites']=False;(o/'fixture-baseline.json').write_text(json.dumps(fixture,indent=2))
s=(o/'check.py').read_text().replace("['compile-command.txt','link-command.txt']","['timing-compile-command.txt','timing-link-command.txt']").replace("['baseline','producer','consumer']","[]")
start=s.index('for name,mode,fixture in ')
s=s[:start]+'''for name,mode,fixture in [('before','baseline','baseline'),('producer','producer','cold'),('cold','consumer','cold'),('warm','consumer','warm'),('coherent','consumer','coherent'),('mixed','consumer','mixed'),('after','baseline','baseline')]:
 with (o/('timing-'+name+'.log')).open('wb') as log:subprocess.run([str(o/'timing.exe'),str(o/(mode+'.spv')),str(o/('fixture-'+fixture+'.json')),str(o/('timing-'+name+'-output.bin'))],stdout=log,stderr=subprocess.STDOUT,check=True)
'''
s=s.replace("'execution.json'","'timing-execution.json'");(o/'timing_check.py').write_text(s)
print('Prepared full GPU clear, ownership readback and timestamp brackets')
