from pathlib import Path
o=Path(__file__).resolve().parent
for name in ['compile-command.txt','link-command.txt']:(o/('ownership-'+name)).write_text((o/name).read_text().replace('collector.cpp','ownership.cpp').replace('collector.obj','ownership.obj').replace('collector.exe','ownership.exe'))
s=(o/'check.py').read_text().replace("['compile-command.txt','link-command.txt']","['ownership-compile-command.txt','ownership-link-command.txt']").replace("['baseline','producer','consumer']","['ownership.vert','ownership.frag']").replace("str(o/(mode+'.comp'))","str(o/mode)")
start=s.index('for name,mode,fixture in ')
s=s[:start]+'''for name,pattern in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 os.environ['VK_LOADER_DRIVERS_SELECT']=pattern
 with (o/('ownership-'+name+'.log')).open('wb') as log:subprocess.run([str(o/'ownership.exe'),str(o/'ownership.vert.spv'),str(o/'ownership.frag.spv')],stdout=log,stderr=subprocess.STDOUT,check=True)
'''
s=s.replace("'execution.json'","'ownership-execution.json'");(o/'ownership_check.py').write_text(s)
print('Prepared overlapping-fragment ownership check on both devices')
