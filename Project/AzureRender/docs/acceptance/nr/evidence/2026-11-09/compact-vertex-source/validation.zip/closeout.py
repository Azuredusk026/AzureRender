from pathlib import Path
import hashlib,json,shutil,subprocess,sys,zipfile
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from build_provenance import verify,digest
from artifact_maintenance import write_json,tracked_paths
from artifact_cleanup import remove_artifact
def read(p):return json.loads(p.read_text())
checks=read(o/'final-checks.json');assert len(checks)==4 and all(x['execution']['exitCode']==0 for x in checks)
image=read(o/'image-final-compact-source-28/results.json');assert len(image['frames'])==4
assert all(f['changedPixels']==0 and f['sha256']==f['referenceSha256'] for f in image['frames'])
assert all(image[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationLogClean','zeroAllocator'])
cost=read(o/'cost-results-compact-source-28.json');assert cost['phaseEfficiencyGatePassed']
products=read(o/'cost-products-before.json');assert all(digest(Path(p))==s for p,s in products.items())
builds={};shaderSets={}
for config in ['release','debug']:
    b=r/('build/ninja-msvc-'+config);m=read(b/'build-provenance.json');verify(r,m)
    shutil.copyfile(b/'build-provenance.json',o/(config+'-final-build-provenance.json'))
    shaderSets[config]={p.name:digest(p) for p in (b/'shaders').glob('*.spv')};assert len(shaderSets[config])==675
    builds[config]=dict(verified=True,sourceCount=len(m['source']),productCount=len(m['products']))
assert shaderSets['release']==shaderSets['debug']
baseline=read(o/'baseline-runtime.json');changed=[n for n,v in baseline.items() if n.endswith('.spv') and shaderSets['release'][Path(n).name]!=v['sha256']]
assert not changed
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
ph=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],cwd=r)).hexdigest();assert ph=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
source=o/'final-source'
for rel in ['CMakeLists.txt','src/render/CompactVertexSource.hpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','shaders/mesh.vert','shaders/outline.vert','shaders/shadow.vert','shaders/outline_view_scaled.glsl','tests/CompactVertexSourceTests.cpp','tests/MotionRecordingTests.cpp']:
    p=source/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,p)
result=dict(status='implemented-functionally-verified',run=o.name,baselineCommit='b921613',builds=builds,checks=checks,componentChecks=20,releaseMaterialGpuCases=16,originalFrames=4,originalChangedPixels=0,changedVertexPrograms=changed,all675OriginalProgramsUnchanged=True,allFragmentAndComputeProgramsUnchanged=True,all675ProgramsMatchAcrossConfigurations=True,runtimeProductsUnchangedSinceCost=True,cost=cost,performanceSourceScope='Final 28-byte layout; original 675 shader programs retained. The 24-byte source and failed fourth-frame delta remain isolated.',graphicsVertexSourceStride=28,graphicsVertexSourceBytes=19952436,protectedDiffSha256=ph,thermalQualificationPassed=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review')
write_json(o/'results.json',result)
dest=r/'docs/acceptance/nr/evidence/2026-11-09/compact-vertex-source';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
selected=[p for p in sorted(o.rglob('*')) if p.is_file() and not any(x in {'baseline-runtime','tmp','__pycache__'} for x in p.relative_to(o).parts) and (p.suffix.lower() in {'.py','.cpp','.hpp','.vert','.glsl','.json','.jsonl','.csv','.log','.xml','.txt','.gltf','.azurelevel','.azureproject'} or p.name=='baseline-source.zip')]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in selected:z.write(p,p.relative_to(o).as_posix())
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p in selected:assert hashlib.sha256(z.read(p.relative_to(o).as_posix())).hexdigest()==digest(p)
result['package']=dict(path=archive.relative_to(r).as_posix(),sha256=digest(archive),bytes=archive.stat().st_size,files=len(selected));write_json(dest/'results.json',result)
tracked=tracked_paths(r);targets=[o/'baseline-runtime',o/'tmp',o/'__pycache__',o/'local.exe',o/'local.obj'];byname={f['frame']:f for f in image['frames']}
for p in (o/'image-final-compact-source-28').glob('frames-*/*.png'):
    assert digest(p)==byname[p.name]['sha256']==byname[p.name]['referenceSha256'];targets.append(p)
before=shutil.disk_usage(r).free;removed=[]
for p in targets:
    if p.exists():removed.append(dict(path=str(p),result=remove_artifact(r/'build',p,tracked,apply=True)))
after=shutil.disk_usage(r).free;cleanup=dict(removed=removed,freeBefore=before,freeAfter=after,observedFreedBytes=after-before)
write_json(o/'cleanup.json',cleanup);write_json(dest/'cleanup.json',cleanup)
print(json.dumps(dict(package=result['package'],changedVertexPrograms=len(changed),observedFreedBytes=after-before,freeBytes=after),indent=2))
