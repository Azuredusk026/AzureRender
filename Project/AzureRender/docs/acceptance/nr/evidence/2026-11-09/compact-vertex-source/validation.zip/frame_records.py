from pathlib import Path
import hashlib,json,sys
import numpy as np
from PIL import Image
r=Path.cwd();o=r/'build/runs/20261109-111635-compact-vertex-source-706378';reference=r/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint/frames'
rows=[]
for folder in ['image-24-rejected','image-final-input-lighting-batch','image-final-compact-source-28']:
 frames=list((o/folder).glob('frames-*'));assert len(frames)==1
 for p in sorted(frames[0].glob('frame_*.png')):
  a=np.asarray(Image.open(p).convert('RGB'));g=np.asarray(Image.open(reference/p.name).convert('RGB'));ys,xs=np.where(np.any(a!=g,axis=2));assert len(xs)<=14
  overrides=[dict(x=int(x),y=int(y),expected=g[y,x].tolist(),actual=a[y,x].tolist()) for y,x in zip(ys,xs)]
  restored=g.copy()
  for x in overrides:restored[x['y'],x['x']]=x['actual']
  assert np.array_equal(restored,a)
  rows.append(dict(path=str(p),reference=str(reference/p.name),width=a.shape[1],height=a.shape[0],actualPngSha256=hashlib.sha256(p.read_bytes()).hexdigest(),referencePngSha256=hashlib.sha256((reference/p.name).read_bytes()).hexdigest(),actualRgbSha256=hashlib.sha256(a.tobytes()).hexdigest(),referenceRgbSha256=hashlib.sha256(g.tobytes()).hexdigest(),changedPixels=len(xs),completeRgbOverrides=overrides,reconstructionVerified=True))
(o/'all-frame-lossless-deltas.json').write_text(json.dumps(rows,indent=2))
print('Verified complete lossless RGB records for',len(rows),'frames; no images generated')
