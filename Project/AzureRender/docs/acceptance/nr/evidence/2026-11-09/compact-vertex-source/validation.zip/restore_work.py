from pathlib import Path
import json,os,subprocess,sys,time
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
os.environ.update(managed_environment(o/'tmp'))
if '--inside' not in sys.argv:
    os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
    command=[str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',*sys.argv[1:]]
    result=guarded_run(r/'build',o.name,command,900);(o/(sys.argv[-1].lower()+'-execution.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result));raise SystemExit(result['exitCode'])
mode=sys.argv[-1];start=time.monotonic()
if mode in ['red','local']:
    command=['cl','/nologo','/std:c++17','/EHsc','/O2','/utf-8','/I'+str(r/'src'),'/ID:/Tools/VulkanSDK/1.4.350.0/Include','/I'+str(r/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/include'),str(r/'tests/CompactVertexSourceTests.cpp'),'/Fo'+str(o/'local.obj'),'/Fe'+str(o/'local.exe'),'/link','/INCREMENTAL:NO']
    with (o/(mode+'-build.log')).open('wb') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    result=subprocess.run([str(o/'local.exe')],capture_output=True);(o/(mode+'-test.log')).write_bytes(result.stdout+result.stderr)
    if mode=='red':assert result.returncode!=0 and b'exactly 24 bytes' in result.stderr
    else:assert result.returncode==0
    print((o/(mode+'-test.log')).read_text(),flush=True)
else:
    assert mode in ['Release','Debug'];command=[sys.executable,'-X','utf8','tools/build_provenance.py','build','--build-dir',str(r/('build/ninja-msvc-'+mode.lower())),'--config',mode]
    command+=['--runtime-only']
    with (o/('restore-'+mode.lower()+'-build.log')).open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    (o/('restore-'+mode.lower()+'-build.json')).write_text(json.dumps(dict(command=command,exitCode=result.returncode,seconds=time.monotonic()-start),indent=2));raise SystemExit(result.returncode)
