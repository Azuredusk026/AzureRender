#include "render/ClusteredLightGrid.hpp"
#include <iostream>
#include <random>
using namespace azurerender;
namespace {
unsigned axis(float v,unsigned n){return std::min(n-1,unsigned(std::clamp((v+1)*.5F*n,0.F,float(n-1))));}
unsigned slice(float z,const ClusterGridDesc& d){return std::min(d.z-1,unsigned(std::clamp(std::log(z/d.nearPlane)/std::log(d.farPlane/d.nearPlane),0.F,.999999F)*d.z));}
void require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
}
int main()try{
    ClusterGridDesc d{16,16,16,.1F,100.F};ClusteredLightGrid grid(d);RenderLight l;l.radius=9;l.viewSpaceBounds=true;l.viewPosition={0,0,10};l.clusterPosition[2]=10;
    l.shape.receivers.surfaces=true;l.shape.receivers.characters=false;grid.assign({l});
    require(grid.indicesFor(0,0,slice(18,d)).empty(),"A distant depth slice must exclude a sphere's impossible projected corner");
    const auto reduced=grid.gpuIndexData().size();
    l.shape.characterResponse.present=true;grid.assign({l});
    require(!grid.indicesFor(0,0,slice(18,d)).empty()&&grid.gpuIndexData().size()>reduced,"A response change must invalidate membership and preserve specialized response coverage");
    l.shape.characterResponse.present=false;grid.assign({l});
    require(grid.gpuIndexData().size()==reduced,"Removing a specialized response must restore sphere slicing");
    std::mt19937 random(0x453187);std::uniform_real_distribution<float> value(-1,1);std::size_t checked=0;
    for(bool ortho:{false,true})for(float offset:{-.3F,0.F,.4F})for(float scale:{-.7F,1.3F}){
        d.orthographic=ortho;d.projectionScaleX=scale;d.projectionScaleY=1.1F;d.projectionOffsetX=offset;d.projectionOffsetY=-offset*.5F;
        if(ortho){d.projectionScaleX*=.03F;d.projectionScaleY*=.03F;}
        grid.configure(d);l.viewPosition={2,-1,10};grid.assign({l});
        for(unsigned i=0;i<30000;++i){const float x=value(random)*9,y=value(random)*9,z=value(random)*9;
            if(double(x)*x+double(y)*y+double(z)*z>=81)continue;
            const float vx=x+l.viewPosition[0],vy=y+l.viewPosition[1],vz=z+10;
            if(vz<d.nearPlane||vz>d.farPlane)continue;
            const float px=vx*d.projectionScaleX/(ortho?1:vz)+d.projectionOffsetX,py=vy*d.projectionScaleY/(ortho?1:vz)+d.projectionOffsetY;
            if(px < -1||px>1||py < -1||py>1)continue;
            const auto& indices=grid.indicesFor(axis(px,d.x),axis(py,d.y),slice(vz,d));
            require(std::find(indices.begin(),indices.end(),0)!=indices.end(),"Every positive finite-sphere sample must retain its light");++checked;
        }
    }
    require(checked>100000,"The membership oracle must contain enough real positive samples");
    d={16,16,16,.1F,100.F};
    for(float depth:{-.5F,.1F,.5F,10.F,99.F})for(float radius:{.01F,.5F,2.F,20.F}){
        grid.configure(d);l.radius=radius;l.viewPosition={0,0,depth};l.clusterPosition[2]=depth;grid.assign({l});
        for(unsigned i=0;i<3000;++i){const float x=value(random)*radius,y=value(random)*radius,z=value(random)*radius;
            if(double(x)*x+double(y)*y+double(z)*z>=double(radius)*radius)continue;
            const float vz=depth+z;if(vz<d.nearPlane||vz>d.farPlane)continue;
            const float px=x/vz,py=y/vz;if(px < -1||px>1||py < -1||py>1)continue;
            require(!grid.indicesFor(axis(px,d.x),axis(py,d.y),slice(vz,d)).empty(),"Near-plane and far-plane clipping must retain positive sphere samples");++checked;
        }
    }
    std::cout<<checked<<" positive sphere samples retained across perspective, orthographic and offset views\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
