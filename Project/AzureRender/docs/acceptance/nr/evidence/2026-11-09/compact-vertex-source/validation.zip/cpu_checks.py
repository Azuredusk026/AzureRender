from pathlib import Path
import os,sys,json,shutil
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
from build_provenance import verify
os.environ.update(managed_environment(o/'tmp'))
config=sys.argv[1] if len(sys.argv)>1 else 'release';b=r/('build/ninja-msvc-'+config)
verify(r,json.loads((b/'build-provenance.json').read_text()))
command=['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe','--test-dir',str(b),'-R','^AzureRender\\.(CompactVertexSource|MotionRecording)$','-V','--output-junit',str(o/(config+'-cpu-final.xml'))]
result=guarded_run(r/'build',o.name,command,120);shutil.copyfile(o/'process.log',o/(config+'-cpu-final.log'));(o/(config+'-cpu-final.json')).write_text(json.dumps(result,indent=2))
assert result['exitCode']==0,result;print(config,'two component checks passed',flush=True)
