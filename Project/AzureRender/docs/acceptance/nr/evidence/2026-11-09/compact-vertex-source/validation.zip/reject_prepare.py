from pathlib import Path
import json,subprocess,hashlib,shutil,sys
r=Path.cwd().resolve();o=r/'build/runs/20261109-111635-compact-vertex-source-706378';sys.path.insert(0,str(r/'tools'))
from build_provenance import verify,digest
from artifact_maintenance import write_json
tracked=['CMakeLists.txt','src/render/ClusteredLightGrid.hpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','tests/MotionRecordingTests.cpp']
created=['src/render/CompactVertexSource.hpp','tests/CompactVertexSourceTests.cpp','tests/ClusteredLightSliceTests.cpp']
for rel in tracked+created:
 p=o/'rejected-final-source'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,p)
(o/'candidate-rejected.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--',*tracked]))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
ph=lambda:hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest()
assert ph()=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
subprocess.run(['git','restore','--source=HEAD','--',*tracked],check=True)
for rel in created:
 p=(r/rel).resolve();assert p.is_relative_to(r/'src') or p.is_relative_to(r/'tests');assert not subprocess.check_output(['git','ls-files','--',rel]).strip();p.unlink()
base=json.loads((o/'baseline-runtime.json').read_text());b=r/'build/ninja-msvc-release'
for rel,entry in base.items():
 p=o/'baseline-runtime'/rel;assert digest(p)==entry['sha256'];shutil.copyfile(p,b/rel)
m=json.loads((o/'baseline-build-provenance.json').read_text());verify(r,m);shutil.copyfile(o/'baseline-build-provenance.json',b/'build-provenance.json')
assert ph()=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
write_json(o/'restoration.json',dict(status='release-runtime-and-source-restored',baselineVerified=True,baselineFiles=len(base),protectedDiffSha256=ph(),debugRebuildPending=True))
print('Release baseline and owned source restored; protected diff unchanged')
