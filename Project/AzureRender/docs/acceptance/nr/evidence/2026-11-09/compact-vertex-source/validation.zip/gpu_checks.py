from pathlib import Path
import json,os,re,sys,shutil
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
from build_provenance import verify
os.environ.update(managed_environment(o/'tmp'))
if '--inside' in sys.argv:
    import test_character_local_light_gpu as local
    import test_projected_hair_gpu as hair
    folder=o/('gpu-'+sys.argv[-1]);folder.mkdir();player=r/'build/ninja-msvc-release/AzurePlayer.exe'
    local.run(player,folder/'local',['front','fixed','no-receiver','pbr-zero-box','pbr-positive-box'],'disabled')
    rows=[]
    for name in ['tangent-normal','tangent-normal-fixed','mirrored']:
        case=next(c for c in hair.cases() if c['name']==name);root=folder/name
        project,expected=hair.prepare(case,root);report,pixels=hair.capture(player,case,project,root,expected,False);rows.append(report)
    logs=list(folder.glob('*/player.log'))+list((folder/'local').glob('*/player.log'));assert len(logs)==8,len(logs)
    for p in logs:
        text=p.read_text(errors='replace');assert re.search(r'Insert.*VK_LAYER_KHRONOS_validation',text,re.I)
        assert not any(s in text for s in ['Validation Error:','Validation Warning:','SYNC-HAZARD','VUID-'])
    (folder/'results.json').write_text(json.dumps(dict(status='passed',cases=8,hair=rows,local=json.loads((folder/'local/summary.json').read_text()),validationLayerInsertions=len(logs)),indent=2))
else:
    verify(r,json.loads((r/'build/ninja-msvc-release/build-provenance.json').read_text()));rows=[]
    for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
        os.environ.update(VK_LOADER_DRIVERS_SELECT=driver,VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer');os.environ.pop('VK_LAYER_ENABLES',None)
        result=guarded_run(r/'build',o.name,[sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',device],450)
        rows.append(dict(device=device,execution=result));(o/'gpu-checks.json').write_text(json.dumps(rows,indent=2));assert result['exitCode']==0,result
        print(device,'eight geometry and material cases passed',flush=True)
