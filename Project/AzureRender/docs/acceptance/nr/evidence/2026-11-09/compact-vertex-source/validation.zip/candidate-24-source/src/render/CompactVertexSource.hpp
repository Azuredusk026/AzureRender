#pragma once
#include "assets/GltfLoader.hpp"
#include "rhi/Rhi.hpp"
#include <cstring>

namespace azurerender {
// Immutable graphics attributes; deformation reads the full source separately.
struct CompactVertexSource {
    std::array<float,3> position;
    std::array<float,2> texcoord;
    float browMask;
};
static_assert(sizeof(CompactVertexSource)==24);
static_assert(offsetof(CompactVertexSource,texcoord)==12&&offsetof(CompactVertexSource,browMask)==20);
inline std::vector<CompactVertexSource> compactVertexSources(const std::vector<AssetVertex>& source){
    std::vector<CompactVertexSource> packed(source.size());
    for(std::size_t i=0;i<source.size();++i){
        std::memcpy(packed[i].position.data(),source[i].position.data(),12);
        std::memcpy(packed[i].texcoord.data(),source[i].texcoord.data(),8);
        std::memcpy(&packed[i].browMask,&source[i].browMask,4);
    }
    return packed;
}
inline std::vector<rhi::VertexAttributeDesc> compactVertexSourceAttributes(const std::vector<rhi::VertexAttributeDesc>& source){
    std::vector<rhi::VertexAttributeDesc> result;result.reserve(source.size());
    for(auto attribute:source){
        if(attribute.binding==0){
            VkFormat expected;
            switch(attribute.location){
                case 0:expected=VK_FORMAT_R32G32B32_SFLOAT;attribute.offset=0;break;
                case 3:expected=VK_FORMAT_R32G32_SFLOAT;attribute.offset=12;break;
                case 8:expected=VK_FORMAT_R32_SFLOAT;attribute.offset=20;break;
                case 1:case 2:case 4:case 5:case 6:case 7:continue;
                default:throw std::invalid_argument("Unknown compact source attribute");
            }
            if(attribute.format!=expected)throw std::invalid_argument("Incompatible compact source attribute format");
        }
        result.push_back(attribute);
    }
    return result;
}
}
