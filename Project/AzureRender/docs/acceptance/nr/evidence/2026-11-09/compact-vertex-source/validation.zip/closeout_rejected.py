from pathlib import Path
import json,hashlib,shutil,subprocess,sys,zipfile
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from build_provenance import verify,digest
from artifact_maintenance import write_json,tracked_paths
from artifact_cleanup import remove_artifact
read=lambda p:json.loads(p.read_text())
checks=read(o/'final-checks.json');assert len(checks)==4 and all(x['execution']['exitCode']==0 for x in checks)
image=read(o/'image-final-compact-source-28/results.json');assert len(image['frames'])==4 and all(f['changedPixels']==0 and f['sha256']==f['referenceSha256'] for f in image['frames'])
cost=read(o/'cost-results-compact-source-28.json');assert cost['phaseEfficiencyGatePassed'] is False
assert read(o/'combined-rejection.json')['status']=='rejected-strict-image'
builds={};shaderSets={}
for config in ['release','debug']:
 b=r/('build/ninja-msvc-'+config);m=read(b/'build-provenance.json');verify(r,m);shutil.copyfile(b/'build-provenance.json',o/('restored-'+config+'-build-provenance.json'))
 shaderSets[config]={p.name:digest(p) for p in (b/'shaders').glob('*.spv')};assert len(shaderSets[config])==675
 builds[config]=dict(verified=True,sourceCount=len(m['source']),productCount=len(m['products']))
assert shaderSets['release']==shaderSets['debug']
base=read(o/'baseline-runtime.json');assert all(shaderSets['release'][Path(n).name]==v['sha256'] for n,v in base.items() if n.endswith('.spv'))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
ph=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest();assert ph=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
owned=['CMakeLists.txt','src/render/ClusteredLightGrid.hpp','src/scenes/CharacterSceneRenderer.cpp','src/scenes/CharacterSceneRenderer.hpp','tests/MotionRecordingTests.cpp'];assert not subprocess.check_output(['git','diff','--',*owned])
frames=read(o/'all-frame-lossless-deltas.json');assert len(frames)==12 and all(x['reconstructionVerified'] for x in frames)
result=dict(status='rejected-and-restored',run=o.name,baselineCommit='b921613',restoredBuilds=builds,checksScope='Final 28-byte candidate only, before restoration',componentChecks=20,releaseMaterialGpuCases=16,originalFrames=4,originalChangedPixels=0,all675OriginalProgramsUnchanged=True,cost28=cost,slice=dict(positiveSamples=185069,baselineReferences=14291,candidateReferences=14283,baselinePackedIndices=28192,candidatePackedIndices=28176,nativeCaptures=0,nativeCostRuns=0,adopted=False),protectedDiffSha256=ph,thermalQualificationPassed=False,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',newFullAssetCopies=0,allProjectPayloadsOnD=True)
write_json(o/'results.json',result)
dest=r/'docs/acceptance/nr/evidence/2026-11-09/compact-vertex-source';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
allowed={'.py','.cpp','.hpp','.vert','.frag','.glsl','.json','.jsonl','.csv','.log','.xml','.txt','.gltf','.azurelevel','.azureproject','.patch','.md'}
selected=[p for p in sorted(o.rglob('*')) if p.is_file() and not any(x in {'baseline-runtime','tmp','__pycache__'} for x in p.relative_to(o).parts) and p.suffix.lower() in allowed]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in selected:z.write(p,p.relative_to(o).as_posix())
assert archive.stat().st_size<=8*1024*1024,archive.stat().st_size
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in selected:assert hashlib.sha256(z.read(p.relative_to(o).as_posix())).hexdigest()==digest(p)
result['package']=dict(path=archive.relative_to(r).as_posix(),sha256=digest(archive),bytes=archive.stat().st_size,files=len(selected));write_json(dest/'results.json',result)
targets=[o/'baseline-runtime',o/'tmp',o/'__pycache__',o/'local.exe',o/'local.obj',o/'slice.exe',o/'slice.obj']
for config in ['debug','release']:
 b=r/('build/ninja-msvc-'+config)
 for suffix in ['.exe','.pdb','.ilk']:targets.append(b/('AzureRenderCompactVertexSourceTests'+suffix))
 targets.append(b/'CMakeFiles/AzureRenderCompactVertexSourceTests.dir')
for row in frames:
 p=Path(row['path']).resolve();assert p.is_relative_to(o);assert digest(p)==row['actualPngSha256'];targets.append(p)
tracked=tracked_paths(r);before=shutil.disk_usage(r).free;removed=[]
for p in targets:
 if p.exists():removed.append(dict(path=str(p),result=remove_artifact(r/'build',p,tracked,apply=True)))
after=shutil.disk_usage(r).free;cleanup=dict(removed=removed,freeBefore=before,freeAfter=after,observedFreedBytes=after-before)
write_json(o/'cleanup.json',cleanup);write_json(dest/'cleanup.json',cleanup)
print(json.dumps(dict(package=result['package'],cleanup=cleanup),indent=2))
