from pathlib import Path
import json,os,shutil,sys
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
from build_provenance import verify,digest
os.environ.update(managed_environment(o/'tmp'))
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer');os.environ.pop('VK_LAYER_ENABLES',None)
rows=json.loads((o/'final-checks.json').read_text()) if (o/'final-checks.json').exists() else []
for config in sys.argv[1:] or ['release','debug']:
    b=r/('build/ninja-msvc-'+config);manifest=json.loads((b/'build-provenance.json').read_text());verify(r,manifest)
    shutil.copyfile(b/'build-provenance.json',o/(config+'-final-build-provenance.json'))
    for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
        os.environ['VK_LOADER_DRIVERS_SELECT']=driver
        names='CompactVertexSource|MotionRecording|StaticSkinningRecording|NodeOpacityRecording|SkinningGpu|MotionVectorGpu|SharedMotionGpu' if device=='nvidia' else 'SkinningGpu|MotionVectorGpu|SharedMotionGpu'
        command=['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe','--test-dir',str(b),'-R','^AzureRender\\.('+names+')$','-V','--output-junit',str(o/(config+'-'+device+'-final.xml'))]
        result=guarded_run(r/'build',o.name,command,240);shutil.copyfile(o/'process.log',o/(config+'-'+device+'-final.log'))
        rows.append(dict(configuration=config,device=device,execution=result));(o/'final-checks.json').write_text(json.dumps(rows,indent=2));assert result['exitCode']==0,result
        log=(o/(config+'-'+device+'-final.log')).read_text(errors='replace');assert '100% tests passed' in log
        assert not any(s in log for s in ['Validation Error:','Validation Warning:','SYNC-HAZARD','VUID-'])
        print(config,device,'passed',flush=True)
