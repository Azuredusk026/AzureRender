#include "assets/GltfLoader.hpp"
#include "rhi/Rhi.hpp"
#include <cstring>
#include <iostream>
#include <stdexcept>
#if __has_include("render/CompactVertexSource.hpp")
#include "render/CompactVertexSource.hpp"
using namespace azurerender;
#else
using CompactVertexSource=AssetVertex;
std::vector<AssetVertex> compactVertexSources(const std::vector<AssetVertex>& source){return source;}
std::vector<azurerender::rhi::VertexAttributeDesc> compactVertexSourceAttributes(std::vector<azurerender::rhi::VertexAttributeDesc> a){return a;}
#endif
void requireCompact(bool value,const char* why){if(!value)throw std::runtime_error(why);}
int main()try{
    requireCompact(sizeof(CompactVertexSource)==24,"Computed graphics input must occupy exactly 24 bytes per vertex");
    std::vector<AssetVertex> source(257);std::uint32_t seed=0x12345678;
    for(auto& vertex:source){std::array<unsigned char,sizeof(AssetVertex)> bytes;
        for(auto& b:bytes){seed=seed*1664525U+1013904223U;b=static_cast<unsigned char>(seed>>24U);}
        std::memcpy(&vertex,bytes.data(),bytes.size());}
    const std::array<std::uint32_t,6> special{0,0x80000000,0x7fc12345,0xff800000,0x00000001,0x7f7fffff};
    std::memcpy(source[0].position.data(),special.data(),12);std::memcpy(source[0].texcoord.data(),special.data()+3,8);std::memcpy(&source[0].browMask,special.data()+5,4);
    const auto original=source;const auto packed=compactVertexSources(source);
    requireCompact(packed.size()==source.size()&&std::memcmp(source.data(),original.data(),source.size()*sizeof(AssetVertex))==0,"Packing must preserve source count and every original byte");
    for(std::size_t i=0;i<source.size();++i){const auto* bytes=reinterpret_cast<const unsigned char*>(&packed[i]);
        requireCompact(std::memcmp(bytes,source[i].position.data(),12)==0&&std::memcmp(bytes+12,source[i].texcoord.data(),8)==0&&std::memcmp(bytes+20,&source[i].browMask,4)==0,"Static attributes must retain exact bit patterns and offsets");}
    requireCompact(compactVertexSources({}).empty(),"Empty source must produce empty packed storage");
    using namespace azurerender::rhi;
    const std::vector<VertexAttributeDesc> raw{{0,VK_FORMAT_R32G32B32_SFLOAT,0},{1,VK_FORMAT_R32G32B32_SFLOAT,12},{2,VK_FORMAT_R32G32B32A32_SFLOAT,24},{3,VK_FORMAT_R32G32_SFLOAT,40},{4,VK_FORMAT_R32G32B32A32_UINT,48},{5,VK_FORMAT_R32G32B32A32_SFLOAT,64},{6,VK_FORMAT_R32G32B32_SFLOAT,80},{7,VK_FORMAT_R32G32B32_SFLOAT,92},{8,VK_FORMAT_R32_SFLOAT,104},{9,VK_FORMAT_R32G32B32A32_SFLOAT,4,1}};
    auto attributes=compactVertexSourceAttributes(raw);requireCompact(attributes.size()==4,"Packed input must retain only required source attributes and other bindings");
    const unsigned locations[]{0,3,8,9},offsets[]{0,12,20,4};
    for(unsigned i=0;i<4;++i)requireCompact(attributes[i].location==locations[i]&&attributes[i].offset==offsets[i]&&attributes[i].binding==(i==3?1:0),"Attribute adaptation must preserve locations, offsets and independent colour binding");
    auto bad=raw;bad.push_back({10,VK_FORMAT_R32_SFLOAT,0});bool rejected=false;
    try{compactVertexSourceAttributes(bad);}catch(const std::invalid_argument&){rejected=true;}requireCompact(rejected,"Unknown source attributes require an explicit layout extension");
    bad=raw;bad[3].format=VK_FORMAT_R32_UINT;rejected=false;
    try{compactVertexSourceAttributes(bad);}catch(const std::invalid_argument&){rejected=true;}requireCompact(rejected,"An incompatible packed attribute format must be rejected");
    std::cout<<"Compact source: 24-byte layout, 257 bit-exact records, binding isolation and format rejection passed\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
