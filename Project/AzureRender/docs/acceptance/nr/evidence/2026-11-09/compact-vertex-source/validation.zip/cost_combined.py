from pathlib import Path
import json,os,sys,csv,shutil
import numpy as np
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';sys.path.insert(0,str(root/'tools'))
tag=sys.argv[1] if len(sys.argv)>1 else 'v1'
from build_provenance import inputs,digest,verify
baseline=json.loads((out/'baseline-runtime.json').read_text());assert len(baseline)==676
assert all(digest(out/'baseline-runtime'/name)==v['sha256'] for name,v in baseline.items())
from artifact_maintenance import guarded_run,managed_environment
os.environ.update(managed_environment(out/'tmp'))
from gpu_environment import RunEnvironmentMonitor
for key in ['TEMP','TMP','TMPDIR','SQLITE_TMPDIR']:os.environ[key]=str(out/'tmp')
checks=json.loads((out/'gpu-checks-28.json').read_text());assert len(checks)==2 and all(row['execution']['exitCode']==0 for row in checks)
for device in ['nvidia','intel']:
 report=json.loads((out/('gpu-28-'+device)/'results.json').read_text());assert report['status']=='passed' and report['cases']==8 and report['validationLayerInsertions']==8
image=json.loads((out/'image-final-input-lighting-batch/results.json').read_text());assert len(image['frames'])==4 and all(row['changedPixels']==0 for row in image['frames'])
controls=json.loads((out/'combined-controls.json').read_text());assert len(controls)==4 and all(row['changedPixels']==0 for row in controls)
verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}

shutil.copyfile(build/'build-provenance.json',out/'cost-build-provenance.json')
(out/'cost-source-before.json').write_text(json.dumps(before,indent=2))
(out/'cost-products-before.json').write_text(json.dumps(products,indent=2))
lock=json.loads((out.parent/'20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text());assert all(digest(Path(p))==sha for p,sha in lock.items())
project=out.parent/'20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES','VK_LAYER_VALIDATE_SYNC','VK_LOADER_DEBUG','AZURE_CPU_WORK_REPORT']:os.environ.pop(key,None)
rows=[]
for label,exe in [('baseline-before',build/'AzurePlayer.exe'),('candidate',build/'AzurePlayer.exe'),('baseline-after',build/'AzurePlayer.exe')]:
 folder=out/('cost-'+tag+'-'+label);folder.mkdir(exist_ok=True);assert not (folder/'timing.json').exists()
 runtime=build if label=='candidate' else out/'baseline-runtime'
 exe=runtime/'AzurePlayer.exe'
 command=[str(exe),'--project',str(project),'--resource-root',str(runtime),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','24','--smoke-frames','600','--gpu-timing','--gpu-timing-output',str(folder/'timing.json'),'--runtime-report',str(folder/'runtime.json')]

 (folder/'command.json').write_text(json.dumps(dict(command=command,exeSha256=digest(exe)),indent=2))
 environment={}
 with RunEnvironmentMonitor(environment,path=folder/'environment.json',interval=2):
  execution=guarded_run(root/'build',out.name,command,300)
 shutil.copyfile(out/'process.log',folder/'process.log');(folder/'execution.json').write_text(json.dumps(execution,indent=2))
 assert execution['status']=='exited' and execution['exitCode']==0
 log=(folder/'process.log').read_text(errors='replace');assert 'Allocator after unload: buffers=0 images=0' in log and not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-'])
 data=json.loads((folder/'timing.json').read_text());samples=list(csv.DictReader((folder/'timing.csv').open()))
 selected=[r for r in samples if 301<=int(r['frame'])<=600];assert len(selected)==300
 assert [data['sceneWidth'],data['sceneHeight']]==[1920,1080], [data['sceneWidth'],data['sceneHeight']]
 if label=='candidate':assert data['graphicsVertexSourceStride']==28 and data['graphicsVertexSourceBytes']>0 and data['computeSkinningVertexWords']==10 and data['computeSkinningOutputBytes']==data['vertexCapacity']*40*2
 assert data.get('shadowBoundsTilesPerGroup',1)==8
 assert data['conservativeOcclusionPrepared'] and data['mainDepthSplitRecorded']
 assert not data.get('surfaceRadiancePrepared',False)
 summary={name:dict(mean=float(np.mean([float(r[key]) for r in selected])),p95=float(np.percentile([float(r[key]) for r in selected],95))) for name,key in [('gpu','frameMs'),('shadow','shadowMs'),('main','sceneMs'),('post','postProcessMs')]}
 cpu=data['cpuFrame']['workSamplesMs'];assert len(cpu)==600;summary['cpu']=dict(mean=float(np.mean(cpu[300:])),p95=float(np.percentile(cpu[300:],95)))
 observations=environment['runObservations'];assert not environment['monitorErrors']
 environmentSummary=dict(powerLimits=sorted(set(row['powerLimitWatts'] for row in observations if row['powerLimitWatts'] is not None)),acLineStates=sorted(set(row['hostPower']['acLineStatus'] for row in observations)),temperatures=[min(row['temperature'] for row in observations),max(row['temperature'] for row in observations)],graphicsClocks=[min(row['graphicsClockMHz'] for row in observations if row['graphicsClockMHz'] is not None),max(row['graphicsClockMHz'] for row in observations if row['graphicsClockMHz'] is not None)],thermalSlowdownObserved=any(any(value is True for value in row['thermalSlowdown'].values()) for row in observations),samples=len(observations))
 row=dict(label=label,selectedFrames=300,summary=summary,environment=environmentSummary,metadata={k:v for k,v in data.items() if k.startswith(('conservativeOcclusion','defaultIsolation','surfaceRadiance','computeSkinning','staticSkinning','shadowBounds','graphicsVertexSource','motionDescriptor')) or k in ['mainDepthSplitRecorded','vertexCapacity']},sceneExtent=[data['sceneWidth'],data['sceneHeight']]);rows.append(row);print(json.dumps(dict(label=label,summary=summary)),flush=True)
 assert inputs(root)==before and all(digest(Path(p))==sha for p,sha in products.items())
 assert all(digest(out/'baseline-runtime'/name)==v['sha256'] for name,v in baseline.items())
assert all(digest(Path(p))==sha for p,sha in lock.items())
b0=rows[0]['summary']['gpu']['mean'];b1=rows[2]['summary']['gpu']['mean'];referenceMean=(b0+b1)/2;candidate=rows[1]['summary']['gpu']['mean']
report=dict(status='diagnosed',rows=rows,bracketDriftFraction=abs(b1-b0)/referenceMean,bracketStable=abs(b1-b0)/referenceMean<=.03,gpuBaselineMean=referenceMean,gpuCandidateMean=candidate,gpuSavedMs=referenceMean-candidate,gpuReductionFraction=1-candidate/referenceMean,sourceAndProductsUnchanged=True,projectInputsVerified=len(lock),shadowBoundsTilesPerGroup=8,baselineRuntimeVerified=True,scope='Local diagnosis under recorded current power and thermal conditions, three hundred warmup and three hundred selected frames per process; before/candidate/after bracket; formal performance conditions remain pending',formalPerformancePassed=False)
main0=rows[0]['summary']['main']['mean'];main1=rows[2]['summary']['main']['mean'];mainRef=(main0+main1)/2;mainCandidate=rows[1]['summary']['main']['mean']
report.update(materialIntervalBaselineMean=mainRef,materialIntervalCandidateMean=mainCandidate,materialIntervalReductionFraction=1-mainCandidate/mainRef,materialIntervalBracketDriftFraction=abs(main1-main0)/mainRef)
shadow0=rows[0]['summary']['shadow']['mean'];shadow1=rows[2]['summary']['shadow']['mean'];shadowRef=(shadow0+shadow1)/2;shadowCandidate=rows[1]['summary']['shadow']['mean']
report.update(shadowBaselineMean=shadowRef,shadowCandidateMean=shadowCandidate,shadowReductionFraction=1-shadowCandidate/shadowRef,shadowBracketDriftFraction=abs(shadow1-shadow0)/shadowRef)
mainQualified=report['materialIntervalReductionFraction']>=.05 and report['materialIntervalBracketDriftFraction']<=.03
shadowQualified=report['shadowReductionFraction']>=.05 and report['shadowBracketDriftFraction']<=.03
report['phaseEfficiencyGatePassed']=report['bracketStable'] and report['gpuReductionFraction']>=max(.02,2*report['bracketDriftFraction']) and (mainQualified or shadowQualified)
(out/('cost-results-'+tag+'.json')).write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='rows'}),flush=True)
