from pathlib import Path
import json,os,shutil,sys,zipfile
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
from build_provenance import verify,digest
os.environ.update(managed_environment(o/'tmp'))
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer')
os.environ.pop('VK_LAYER_ENABLES',None)
with zipfile.ZipFile(r/'docs/acceptance/nr/evidence/2026-11-09/clustered-receiver-ranges/validation.zip') as z:
    baseline={c:json.loads(z.read(c+'-final-build-provenance.json')) for c in ['release','debug']}
rows=json.loads((o/'checks.json').read_text()) if (o/'checks.json').exists() else []
for config in sys.argv[1:] or ['release','debug']:
    b=r/('build/ninja-msvc-'+config);manifest=json.loads((b/'build-provenance.json').read_text());verify(r,manifest)
    shaders={p:s for p,s in baseline[config]['products'].items() if p.endswith('.spv')}
    assert len([p for p in shaders if Path(p).parent==b/'shaders'])==675 and all(digest(Path(p))==s for p,s in shaders.items())
    shutil.copyfile(b/'build-provenance.json',o/(config+'-build-provenance.json'))
    for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
        os.environ['VK_LOADER_DRIVERS_SELECT']=driver
        pattern='^AzureRender\\.(MotionRecording|MotionVectorGpu|SharedMotionGpu)$' if device=='nvidia' else '^AzureRender\\.(MotionVectorGpu|SharedMotionGpu)$'
        prefix=config+'-'+device
        command=['D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe','--test-dir',str(b),'-R',pattern,'-V','--output-junit',str(o/(prefix+'-checks.xml'))]
        result=guarded_run(r/'build',o.name,command,240);shutil.copyfile(o/'process.log',o/(prefix+'-checks.log'))
        rows.append(dict(configuration=config,device=device,execution=result,shadersUnchanged=675));(o/'checks.json').write_text(json.dumps(rows,indent=2))
        assert result['exitCode']==0,result
        log=(o/(prefix+'-checks.log')).read_text();assert '100% tests passed' in log
        assert not any(v in log for v in ['Validation Error:','Validation Warning:','SYNC-HAZARD','VUID-'])
        print(prefix,'passed',flush=True)
