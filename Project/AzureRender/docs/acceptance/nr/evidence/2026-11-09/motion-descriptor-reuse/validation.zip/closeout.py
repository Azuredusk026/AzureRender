from pathlib import Path
import hashlib,json,shutil,subprocess,sys,zipfile
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from build_provenance import verify,digest
from artifact_cleanup import remove_artifact
from artifact_maintenance import tracked_paths,write_json
def read(p):return json.loads(p.read_text())
checks=read(o/'checks.json');assert len(checks)==4 and all(c['execution']['exitCode']==0 for c in checks)
image=read(o/'image-final-motion-bindings/results.json')
assert len(image['frames'])==4 and all(f['changedPixels']==0 and f['sha256']==f['referenceSha256'] for f in image['frames'])
assert all(image[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationLogClean','zeroAllocator'])
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
ph=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],cwd=r)).hexdigest()
assert ph=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
builds={}
for config in ['release','debug']:
    manifest=read(r/('build/ninja-msvc-'+config)/'build-provenance.json');verify(r,manifest)
    shutil.copyfile(r/('build/ninja-msvc-'+config)/'build-provenance.json',o/(config+'-final-build-provenance.json'))
    builds[config]=dict(verified=True,sourceCount=len(manifest['source']),productCount=len(manifest['products']),runtimeShadersUnchanged=675)
assert read(o/'release-check-continuity.json')['unchangedAfterDebugLinkPolicy']
source=o/'source'
for rel in ['CMakeLists.txt','src/render/MotionVectorPass.hpp','src/render/MotionVectorPass.cpp','src/scenes/CharacterSceneRenderer.cpp','tests/MotionRecordingTests.cpp']:
    target=source/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,target)
result=dict(status='implemented-verified',baselineCommit='3afe6df',run=o.name,builds=builds,checks=checks,cpuChecks=2,gpuChecks=8,originalFrames=4,originalChangedPixels=0,motionDescriptors=image['motionDescriptors'],runtimeShadersUnchanged=675,validationErrors=0,protectedDiffSha256=ph,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',timingScope='No new steady-state performance run; exact elimination of redundant descriptor writes verified on native and component paths.',debugLinkInitialFailure='LNK1163 in VulkanRhi.cpp.obj while linking SharedMotionGpu; exact mechanism unproven. Three motion validation targets use full Debug links; final builds and checks passed.')
write_json(o/'results.json',result)
dest=r/'docs/acceptance/nr/evidence/2026-11-09/motion-descriptor-reuse';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
selected=[p for p in sorted(o.rglob('*')) if p.is_file() and not any(x in {'tmp','__pycache__'} for x in p.relative_to(o).parts) and p.suffix.lower() in {'.py','.cpp','.hpp','.json','.log','.xml','.csv','.txt'}]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in selected:z.write(p,p.relative_to(o).as_posix())
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p in selected:assert hashlib.sha256(z.read(p.relative_to(o).as_posix())).hexdigest()==digest(p)
result['package']=dict(path=archive.relative_to(r).as_posix(),sha256=digest(archive),bytes=archive.stat().st_size,files=len(selected));write_json(dest/'results.json',result)
frames=o/'image-final-motion-bindings';byname={f['frame']:f for f in image['frames']};targets=[]
for p in frames.glob('frames-*/*.png'):
    assert p.name in byname and digest(p)==byname[p.name]['sha256']==byname[p.name]['referenceSha256'];targets.append(p)
targets+=[o/'tmp',o/'__pycache__'];tracked=tracked_paths(r);before=shutil.disk_usage(r).free;removed=[]
for p in targets:
    if p.exists():removed.append(dict(path=str(p),result=remove_artifact(r/'build',p,tracked,apply=True)))
after=shutil.disk_usage(r).free;cleanup=dict(removed=removed,freeBefore=before,freeAfter=after,observedFreedBytes=after-before)
write_json(dest/'cleanup.json',cleanup);write_json(o/'cleanup.json',cleanup)
print(json.dumps(dict(package=result['package'],motionDescriptors=result['motionDescriptors'],cleanup=cleanup,checks=10,originalFrames=4),indent=2))
