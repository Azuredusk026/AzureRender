from pathlib import Path
import os,sys,json,subprocess,time,hashlib
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'))
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],env=env).returncode)
for config in ['Release','Debug']:
 b=r/('build/ninja-msvc-'+config.lower());digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 before={p.name:digest(p) for p in (b/'shaders').glob('*.spv')};assert len(before)==675
 command=[sys.executable,'-X','utf8','tools/build_provenance.py','build','--build-dir',str(b),'--config',config]
 for target in ['AzurePipelineCacheStoreTests','AzureVulkanPipelineCacheTests']:command+=['--test-target',target]
 start=time.monotonic()
 with (o/(config.lower()+'-build.log')).open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 after={p.name:digest(p) for p in (b/'shaders').glob('*.spv')}
 report=dict(exitCode=result.returncode,seconds=time.monotonic()-start,shaderCount=len(after),shadersUnchanged=before==after,command=command)
 (o/(config.lower()+'-build.json')).write_text(json.dumps(report,indent=2));print(config,report,flush=True)
 assert result.returncode==0 and before==after
