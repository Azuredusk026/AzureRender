from pathlib import Path
import os,sys,json,re,shutil
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run,database,rows,save,run_path
from build_provenance import inputs,digest,verify
os.environ.update(managed_environment(o/'tmp'));b=r/'build/ninja-msvc-release'
verify(r,json.loads((b/'build-provenance.json').read_text()));source=inputs(r)
dependencies=['20261103-234012-character-reference-stages-5abe6c','20261108-101326-gpu-transparent-indices-8ef9c7']
with database(r/'build',True) as db:
 db.execute('BEGIN IMMEDIATE');record=rows(db)[o.name];assert record['status']=='active' and not record.get('processPid')
 assert all(run_path(r/'build',name).is_dir() for name in dependencies)
 record['inputs']=dependencies;record['generation']+=1;save(db,o.name,record)
lock=json.loads((o.parent/dependencies[1]/'frozen-project-inputs.json').read_text());assert all(digest(Path(p))==sha for p,sha in lock.items())
project=o.parent/dependencies[0]/'qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['PATH']=str(b)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES']:os.environ.pop(key,None)
results=[]
for label in ['cold','warm']:
 folder=o/('native-'+label);folder.mkdir(exist_ok=True)
 command=[str(b/'AzurePlayer.exe'),'--project',str(project),'--resource-root',str(b),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','24','--smoke-frames','2','--gpu-timing','--gpu-timing-output',str(folder/'timing.json')]
 if label=='cold' and (folder/'process.log').exists():
  execution=json.loads((r/'build/maintenance/process-receipts'/(o.name+'.json')).read_text());assert execution['command']==command
 else:
  execution=guarded_run(r/'build',o.name,command,300);shutil.copyfile(o/'process.log',folder/'process.log')
 (folder/'execution.json').write_text(json.dumps(execution,indent=2))
 log=(folder/'process.log').read_text(errors='replace');assert execution['status']=='exited' and execution['exitCode']==0,execution
 assert 'Allocator after unload: buffers=0 images=0' in log and not any(x in log for x in ['Validation Error:','SYNC-HAZARD','VUID-'])
 loaded=re.search(r'Pipeline cache loaded: bytes=(\d+), state=([^,\r\n]+), profile=(\d+)',log)
 saved=re.search(r'Pipeline cache saved: bytes=(\d+), state=([^,\r\n]+), requests=(\d+), hits=(\d+)',log)
 pipeline=re.search(r'Scene load pipelines: ([\d.]+)\s*ms',log)
 assert loaded and saved and pipeline,(log[-4000:])
 row=dict(label=label,execution=execution,loadedBytes=int(loaded[1]),readState=loaded[2],profile=loaded[3],savedBytes=int(saved[1]),writeState=saved[2],requests=int(saved[3]),hits=int(saved[4]),pipelineMilliseconds=float(pipeline[1]))
 results.append(row);(o/'native-results.json').write_text(json.dumps(results,indent=2));print(row,flush=True)
 assert row['writeState']=='stored' and 0<row['savedBytes']<128*2**20
 if label=='cold':assert row['loadedBytes']==0
 else:assert row['loadedBytes']==results[0]['savedBytes'] and row['profile']==results[0]['profile']
 assert inputs(r)==source
assert all(digest(Path(p))==sha for p,sha in lock.items())
(o/'native-integrity.json').write_text(json.dumps(dict(sourceUnchanged=True,inputsVerified=len(lock),formalPerformancePassed=False),indent=2))
