from pathlib import Path
import os,sys,json,shutil
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
os.environ.update(managed_environment(o/'tmp'));rows=[]
for config in ['release','debug']:
 b=r/('build/ninja-msvc-'+config)
 for target in ['AzurePipelineCacheStoreTests','AzureVulkanPipelineCacheTests']:
  for driver in (['*nv-vk64*','*igvk64*'] if 'Vulkan' in target else ['cpu']):
   os.environ['VK_LOADER_DRIVERS_SELECT']=driver
   for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES']:os.environ.pop(key,None)
   args=[str(b/target)+'.exe']
   if driver=='cpu':args+=[str(o/'test-artifacts/pipeline-cache-store')]
   else:args+=[str(b/'shaders/shadow_bounds.comp.spv'),str(o/('cache-'+config+'-'+('nv' if 'nv-' in driver else 'intel')))]
   result=guarded_run(r/'build',o.name,args,120)
   label=config+'-'+target+'-'+driver.replace('*','');shutil.copyfile(o/'process.log',o/(label+'.log'))
   rows.append(dict(label=label,execution=result));(o/'checks.json').write_text(json.dumps(rows,indent=2));print(label,result['exitCode'],flush=True)
   assert result['status']=='exited' and result['exitCode']==0
