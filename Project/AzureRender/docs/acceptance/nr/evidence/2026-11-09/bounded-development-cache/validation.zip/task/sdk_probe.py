from pathlib import Path
import os,sys,json,subprocess
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
keys=['TEMP','TMP','TMPDIR','SQLITE_TMPDIR','DOTNET_CLI_HOME','NUGET_PACKAGES','NUGET_HTTP_CACHE_PATH','NUGET_PLUGINS_CACHE_PATH','NUGET_SCRATCH','DOTNET_BUNDLE_EXTRACT_BASE_DIR']
if '--child' in sys.argv:
 print(json.dumps({key:os.environ[key] for key in keys}));raise SystemExit()
env=managed_environment(o/'tmp');env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0')
result=subprocess.run([str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--child'],env=env,capture_output=True,text=True,check=True)
actual=json.loads(result.stdout);assert all(Path(p).is_relative_to(o/'tmp') for p in actual.values()),actual
sdk=subprocess.run(['D:/Tools/dotnet9/dotnet.exe','nuget','locals','all','--list'],env=env,capture_output=True,text=True,check=True)
assert 'C:\\Users' not in sdk.stdout and all(str(o/'tmp'/name) in sdk.stdout for name in ['nuget-packages','nuget-http','nuget-plugins','nuget-scratch']),sdk.stdout
(o/'sdk-probe.json').write_text(json.dumps(dict(environment=actual,nugetDirectories=sdk.stdout),indent=2));print('MSVC inherited all 10 D-drive paths; actual NuGet SDK paths verified',flush=True)
