from pathlib import Path
import os,sys,json,subprocess,hashlib,zipfile,re
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,write_json,tracked_paths,measure
from artifact_cleanup import remove_artifact
from build_provenance import verify,digest
os.environ.update(managed_environment(o/'tmp'))
assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
diff=subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL)
assert hashlib.sha256(diff).hexdigest()=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
builds={}
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);m=json.loads((b/'build-provenance.json').read_text());verify(r,m)
 builds[c]=dict(manifestSha256=digest(b/'build-provenance.json'),source=m['source'],products=m['products'],shaders=675)
e=r/'docs/acceptance/nr/evidence/2026-11-09/bounded-development-cache';e.mkdir(parents=True,exist_ok=True)
source=['src/rhi/PipelineCacheStore.hpp','src/rhi/PipelineCacheStore.cpp','src/rhi/VulkanPipelineCache.hpp','src/rhi/VulkanPipelineCache.cpp','src/app/AzureRenderApp.cpp','tests/PipelineCacheStoreTests.cpp','tests/VulkanPipelineCacheTests.cpp','tools/artifact_maintenance.py','tools/artifact_pipeline_cache.py','tools/test_artifact_maintenance.py','tools/test_artifact_pipeline_cache.py','tools/skills/azurerender-artifact-maintenance/SKILL.md']
with zipfile.ZipFile(e/'validation.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(o.rglob('*')):
  if p.is_file() and p.suffix in ['.py','.json','.log'] and not any(part in ['tmp','test-artifacts','cache-release-nv','cache-release-intel','cache-debug-nv','cache-debug-intel'] for part in p.relative_to(o).parts):archive.write(p,'task/'+p.relative_to(o).as_posix())
 for name in source:archive.write(r/name,'source/'+name)
 archive.writestr('builds.json',json.dumps(builds,indent=2))
assert (e/'validation.zip').stat().st_size<8*2**20
tracked=tracked_paths(r);cleanup=[]
for name in ['test-artifacts','cache-release-nv','cache-release-intel','cache-debug-nv','cache-debug-intel','tmp']:
 p=o/name
 if p.exists():
  size,_=remove_artifact(r/'build',p,tracked,apply=True);cleanup.append(dict(path=str(p),logicalBytes=size))
for p in list(o.glob('*.obj'))+list(o.glob('*.exe')):
 assert p.resolve().is_relative_to(o) and p.resolve() not in tracked and not p.is_symlink()
 size=p.stat().st_size;p.unlink();cleanup.append(dict(path=str(p),logicalBytes=size))
native=json.loads((o/'native-results.json').read_text());checks=json.loads((o/'checks.json').read_text())
pool=[dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p)) for p in (r/'build/cache/vulkan').glob('*.azpc')]
result=dict(status='implemented-verified',run=o.name,baselineCommit='d412ed383765d77a32cd0cdda73d3af7eb8787b1',native=native,checks=checks,builds={c:{k:v for k,v in b.items() if k not in ['source','products']} for c,b in builds.items()},maintenanceTests=dict(total=53,passed=52,skipped=1,skipReason='Symbolic link creation is unavailable'),sdk=json.loads((o/'sdk-probe.json').read_text()),shaderProgramsUnchanged=True,projectInputsVerified=1729,protectedUserDiffSha256=hashlib.sha256(diff).hexdigest(),formalPerformancePassed=False,visualStatus='failed-user-review',nativeScope='One cold and one warm startup, two frames each; no image capture or steady-state performance claim',pool=pool,cleanup=cleanup,cleanupLogicalBytes=sum(x['logicalBytes'] for x in cleanup),remainingRunBytes=measure(o),archiveBytes=(e/'validation.zip').stat().st_size,archiveSha256=digest(e/'validation.zip'))
write_json(e/'results.json',result);write_json(o/'results.json',result)
print(json.dumps({k:result[k] for k in ['status','cleanupLogicalBytes','remainingRunBytes','archiveBytes']},indent=2))
