from pathlib import Path
import json,sys,zipfile,xml.etree.ElementTree as ET
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from build_provenance import inputs,digest,verify
cases=[]
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);verify(r,json.loads((b/'build-provenance.json').read_text()));assert {p.name:digest(p) for p in (b/'shaders').glob('*.spv')}==json.loads((o/(c+'-baseline-shaders.json')).read_text())
 for suffix in ['nvidia','intel','restored']:
  n=c+'-'+suffix+'.xml'
  for x in ET.parse(o/n).getroot().findall('testcase'):
   assert x.find('failure') is None and x.find('skipped') is None;cases.append(dict(receipt=n,name=x.attrib['name']))
assert len(cases)==24
checks=json.loads((o/'checks.json').read_text());assert len(checks)==8 and all(x['exitCode']==0 for x in checks)
proof=json.loads((o/'baseline-build-provenance.json').read_text());assert inputs(r)==proof['source']
gate=json.loads((o/'micro-gate.json').read_text());assert not gate['gatePassed'] and gate['validationTextClean']
cleanup=[json.loads((o/n).read_text()) for n in ['runtime-cleanup.json','disabled-tests-cleanup.json','release-experimental-program-cleanup.json','debug-experimental-program-cleanup.json']];assert all(x['status']=='applied' for x in cleanup)
f=r/'docs/acceptance/nr/evidence/2026-11-09/bounded-compute-reductions';f.mkdir(parents=True,exist_ok=True)
paths=[p for p in o.glob('*') if p.suffix in ['.json','.log','.xml','.py','.patch']]+list((o/'candidate-source').rglob('*'))+list((o/'candidate-programs').rglob('*'));paths=[p for p in paths if p.is_file()]
with zipfile.ZipFile(f/'validation.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for p in sorted(set(paths)):z.write(p,p.relative_to(o).as_posix())
report=dict(sourceBase='e0728cfdb0910f28400ff06353c705b2908e8cc2',status='micro-efficiency-gate-not-passed-candidate-isolated',tests=cases,passed=24,skipped=0,pairedReferenceProcesses=4,microGate=gate,candidateSource=json.loads((o/'candidate-source.json').read_text()),restoration=json.loads((o/'source-restoration.json').read_text()),unchangedDefaultPrograms=674,sourceHashes={},canonicalNativeProcesses=0,frameCostProcesses=0,standaloneKernelTimingProcesses=1,cleanup=dict(files=sum(x['files'] for x in cleanup),logicalBytes=sum(x['logicalBytes'] for x in cleanup)),formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceZipBytes=(f/'validation.zip').stat().st_size,evidenceZipSha256=digest(f/'validation.zip'))
assert report['evidenceZipBytes']<8*1024*1024;(f/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
p=r/'docs/development/artifact-manifest.json';d=json.loads(p.read_text());d['milestones'].insert(0,dict(path='runs/'+o.name,name='计算归约效率门槛',status='MicroGateNotPassedCandidateIsolated',sourceBase='e0728cf',evidence='docs/acceptance/nr/bounded-compute-reductions.md',checksPassed=24,pairedReferenceProcesses=4,canonicalNativeProcesses=0,frameCostProcesses=0,standaloneKernelTimingProcesses=1,reclaimedFiles=report['cleanup']['files'],formalPerformancePassed=False));p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ['passed','cleanup','evidenceZipBytes']}))
