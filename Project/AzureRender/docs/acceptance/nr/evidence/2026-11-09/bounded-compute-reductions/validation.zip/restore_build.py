from pathlib import Path
import os,sys,subprocess,json,time,hashlib
root=Path.cwd().resolve();out=Path(__file__).resolve().parent
if '--inside' not in sys.argv:
 env=os.environ.copy();temporary=out/'tmp';temporary.mkdir(exist_ok=True)
 env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',TEMP=str(temporary),TMP=str(temporary),TMPDIR=str(temporary),SQLITE_TMPDIR=str(temporary),VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(root/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',*sys.argv[1:]],cwd=root,env=env).returncode)
configuration=sys.argv[-1];assert configuration in ['Release','Debug'];build=root/'build'/('ninja-msvc-'+configuration.lower())
hashfile=out/(configuration.lower()+'-baseline-shaders.json')
if not hashfile.exists():hashfile.write_text(json.dumps({q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in (build/'shaders').glob('*.spv')},indent=2))
commands=[['cmake','-S',str(root),'-B',str(build)],[sys.executable,'-X','utf8','tools/build_provenance.py','build','--build-dir',str(build),'--config',configuration]]
for target in ['AzureReflectionSpatialFilterTests','AzureObjectShadowAtlasTests','AzureRenderRenderGraphTests']:commands[1]+=['--test-target',target]
started=time.monotonic();results=[]
with (out/(configuration.lower()+'-restored-build.log')).open('wb') as log:
 for command in commands:
  r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
  if command[0]=='cmake' and r.returncode==0:
   extra=build/'shaders/shadow_bounds_subgroup.comp.spv';proof=json.loads((out/('candidate-'+configuration.lower()+'-provenance.json')).read_text());assert extra.is_file() and hashlib.sha256(extra.read_bytes()).hexdigest()==proof['products'][str(extra.resolve())]
   assert extra.resolve().parent==(build/'shaders').resolve() and not extra.is_symlink()
   row=dict(path=str(extra),bytes=extra.stat().st_size,sha256=hashlib.sha256(extra.read_bytes()).hexdigest());extra.unlink();(out/(configuration.lower()+'-experimental-program-cleanup.json')).write_text(json.dumps(dict(status='applied',paths=[row],files=1,logicalBytes=row['bytes']),indent=2))
  results.append(dict(command=command,exitCode=r.returncode))
  if r.returncode:break
(out/(configuration.lower()+'-restored-build.json')).write_text(json.dumps(dict(results=results,seconds=time.monotonic()-started),indent=2));print(configuration+' build exit '+str(r.returncode),flush=True)
raise SystemExit(r.returncode)
