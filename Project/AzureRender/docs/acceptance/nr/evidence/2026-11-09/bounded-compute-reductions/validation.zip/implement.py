from pathlib import Path
r=Path.cwd()
def edit(name,old,new):
 p=r/name;s=p.read_text();assert old in s,(name,old);p.write_text(s.replace(old,new,1))
edit('src/rhi/Rhi.hpp','    virtual bool supportsExactDepthBias() const noexcept {return false;}','    virtual bool supportsExactDepthBias() const noexcept {return false;}\n    virtual bool supportsComputeSubgroupArithmetic() const noexcept {return false;}')
edit('src/rhi/VulkanRhi.hpp','    bool supportsExactDepthBias() const noexcept override {return exactDepthBiasEnabled_;}','    bool supportsExactDepthBias() const noexcept override {return exactDepthBiasEnabled_;}\n    bool supportsComputeSubgroupArithmetic() const noexcept override;')
edit('src/rhi/VulkanRhi.cpp','using azurerender::internal::vkCheck;','''using azurerender::internal::vkCheck;

bool VulkanRhi::supportsComputeSubgroupArithmetic() const noexcept {
    if(!physicalDevice_)return false;
    VkPhysicalDeviceSubgroupProperties subgroup{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SUBGROUP_PROPERTIES};
    VkPhysicalDeviceProperties2 properties{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2};properties.pNext=&subgroup;
    vkGetPhysicalDeviceProperties2(physicalDevice_,&properties);
    const auto required=VK_SUBGROUP_FEATURE_BASIC_BIT|VK_SUBGROUP_FEATURE_ARITHMETIC_BIT;
    return properties.properties.apiVersion>=VK_API_VERSION_1_1
        &&(subgroup.supportedStages&VK_SHADER_STAGE_COMPUTE_BIT)
        &&(subgroup.supportedOperations&required)==required;
}
''')
edit('src/render/ShadowTileBounds.hpp','unsigned extent,unsigned objectCapacity=0){','unsigned extent,unsigned objectCapacity=0,bool allowSubgroups=true){')
edit('src/render/ShadowTileBounds.hpp','try{pipeline_=backend_.createComputePipeline({shader,layout_});}','try{rhi::ComputePipelineDesc pipeline{shader,layout_};if(!allowSubgroups)pipeline.specialization={{0,VK_FALSE}};pipeline_=backend_.createComputePipeline(pipeline);}')
edit('src/scenes/CharacterSceneRenderer.cpp','shaderDirectory_+"/shadow_bounds.comp.spv"','shaderDirectory_+(rhi_->supportsComputeSubgroupArithmetic()?"/shadow_bounds_subgroup.comp.spv":"/shadow_bounds.comp.spv")')
edit('shaders/shadow_bounds.comp','#version 450','#version 450\n#if defined(AZURE_SHADOW_BOUNDS_SUBGROUP)\n#extension GL_KHR_shader_subgroup_basic : require\n#extension GL_KHR_shader_subgroup_arithmetic : require\nlayout(constant_id=0) const bool allowSubgroups=true;\n#endif')
edit('shaders/shadow_bounds.comp','    tileBounds[i]=vec2(min(min(depths.x,depths.y),min(depths.z,depths.w)),max(max(depths.x,depths.y),max(depths.z,depths.w)));','''    vec2 bounds=vec2(min(min(depths.x,depths.y),min(depths.z,depths.w)),max(max(depths.x,depths.y),max(depths.z,depths.w)));
#if defined(AZURE_SHADOW_BOUNDS_SUBGROUP)
    if(allowSubgroups&&gl_NumSubgroups==1u){
        vec2 reduced=vec2(subgroupMin(bounds.x),subgroupMax(bounds.y));
        if(i==0u)result.values[tile.y*(textureSize(sourceDepth,0).x/8)+tile.x]=reduced;
        return;
    }
#endif
    tileBounds[i]=bounds;''')
edit('CMakeLists.txt','compile_shader("${SHADER_SOURCE_DIR}/shadow_bounds.comp")','compile_shader("${SHADER_SOURCE_DIR}/shadow_bounds.comp")\ncompile_shader("${SHADER_SOURCE_DIR}/shadow_bounds.comp" DEFINES AZURE_SHADOW_BOUNDS_SUBGROUP=1 OUTPUT_NAME shadow_bounds_subgroup.comp)')
edit('shaders/reflection_spatial_filter.comp','        vec3 a=filterLevel(base,centerDepth,low),b=filterLevel(base,centerDepth,high);','        vec3 a=filterLevel(base,centerDepth,low);\n        vec3 b=low==high?a:filterLevel(base,centerDepth,high);')
p=r/'tests/ReflectionSpatialFilterGpuTests.cpp';s=p.read_text();s=s.replace('void synthetic(test::VulkanComputeFixture& host,const std::vector<char>& shader){','void synthetic(test::VulkanComputeFixture& host,const std::vector<char>& shader,const std::vector<char>* reference=nullptr){',1)
m='    float maximum=0;unsigned captures=0;';assert m in s;s=s.replace(m,m+'\n    std::unique_ptr<ReflectionSpatialFilterGpu> original;\n    if(reference)original=std::make_unique<ReflectionSpatialFilterGpu>(*host.backend,VkExtent2D{width,height},1,*reference);',1)
m='        require(result==other,"Synthetic frame slots must match");';assert m in s;s=s.replace(m,m+'\n        if(original){const auto expected=capture(host,*original,0,views,parameters);require(expected.size()==result.size()&&std::memcmp(expected.data(),result.data(),result.size()*sizeof(float))==0,"Shared maximum mip must preserve the reference output bit pattern");}',1)
s=s.replace('require(argc==2||argc==4,','require(argc==2||argc==3||argc==4,',1).replace('else {synthetic(host,shader);confidenceFixture','else {const auto reference=argc==3?readBinaryFile(argv[2]):std::vector<char>{};synthetic(host,shader,reference.empty()?nullptr:&reference);confidenceFixture',1);p.write_text(s)
