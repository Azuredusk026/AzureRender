from pathlib import Path
r=Path.cwd();o=r/'build/runs/20261109-030048-bounded-compute-reductions-fec9f6'
for c in ['release','debug']:
 for suffix in ['build.log','build.json']:
  p=o/(c+'-'+suffix);assert p.exists();p.rename(o/(c+'-initial-failure-'+suffix))
p=r/'CMakeLists.txt';s=p.read_text();m='        set(shader_arguments_json "\\"--target-env=vulkan1.3\\"")\n    endif()';assert m in s;s=s.replace(m,'        set(shader_arguments_json "\\"--target-env=vulkan1.3\\"")\n    elseif("AZURE_SHADOW_BOUNDS_SUBGROUP=1" IN_LIST SHADER_DEFINES)\n        list(APPEND shader_define_args "--target-env=vulkan1.1")\n        set(shader_arguments_json "\\"--target-env=vulkan1.1\\"")\n    endif()',1);p.write_text(s)
p=r/'shaders/shadow_bounds.comp';s=p.read_text();s=s.replace('    vec2 bounds=','#if defined(AZURE_SHADOW_BOUNDS_SUBGROUP)\n    vec2 bounds=',1).replace('#if defined(AZURE_SHADOW_BOUNDS_SUBGROUP)\n    if(allowSubgroups','    if(allowSubgroups',1).replace('#endif\n    tileBounds[i]=bounds;','    tileBounds[i]=bounds;\n#else\n    tileBounds[i]=vec2(min(min(depths.x,depths.y),min(depths.z,depths.w)),max(max(depths.x,depths.y),max(depths.z,depths.w)));\n#endif',1);p.write_text(s)
p=r/'tests/ShadowTileBoundsSubgroupGpuTests.cpp';s=p.read_text();s=s.replace('#include <iostream>','#include <iostream>\n#include <limits>\n#include <nlohmann/json.hpp>')
s=s.replace('if(argc!=2)throw std::invalid_argument("Expected shader directory");','if(argc!=2&&argc!=3)throw std::invalid_argument("Expected shader directory and optional --timing");\n    const bool timing=argc==3&&std::string(argv[2])=="--timing";\n    if(argc==3&&!timing)throw std::invalid_argument("Unknown subgroup fixture option");')
s=s.replace('constexpr unsigned side=64;','if(timing&&!host.timestampBits)return 77;\n    const unsigned side=timing?4096:64;')
m='    for(unsigned mode=0;mode<3;++mode){';assert m in s;s=s.replace(m,'''    constexpr unsigned warmup=256,samples=128,iterations=warmup+samples;
    VkQueryPool timingPool=VK_NULL_HANDLE;
    auto timingCleanup=std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*){if(timingPool)vkDestroyQueryPool(host.device,timingPool,nullptr);});
    if(timing){VkQueryPoolCreateInfo desc{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};desc.queryType=VK_QUERY_TYPE_TIMESTAMP;desc.queryCount=2*iterations;test::vkRequire(vkCreateQueryPool(host.device,&desc,nullptr,&timingPool),"Create subgroup timing pool");}
    nlohmann::json timings=nlohmann::json::array();
    for(const unsigned mode:timing?std::vector<unsigned>{0,1,2,1,0}:std::vector<unsigned>{0,1,2}){''',1)
m='''        host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer){
            commands.bufferBarrier({buffer.buffer,0,buffer.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});
            bounds.record(commands);commands.bufferBarrier''';assert m in s;s=s.replace(m,'''        host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer native){
            commands.bufferBarrier({buffer.buffer,0,buffer.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});
            if(timing)vkCmdResetQueryPool(native,timingPool,0,2*iterations);
            for(unsigned i=0;i<(timing?iterations:1U);++i){
                if(i)commands.bufferBarrier({buffer.buffer,0,bounds.depthBoundsBytes(),VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});
                if(timing)commands.writeTimestamp(timingPool,2*i,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
                bounds.record(commands);
                if(timing)commands.writeTimestamp(timingPool,2*i+1,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
            }
            commands.bufferBarrier''',1)
m='        host.allocator.invalidate(buffer,0,buffer.size);';assert m in s;s=s.replace(m,'''        if(timing){
            std::array<std::uint64_t,2*iterations> ticks{};
            test::vkRequire(vkGetQueryPoolResults(host.device,timingPool,0,2*iterations,sizeof(ticks),ticks.data(),sizeof(std::uint64_t),VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT),"Read subgroup timing");
            const auto mask=host.timestampBits>=64?std::numeric_limits<std::uint64_t>::max():(std::uint64_t{1}<<host.timestampBits)-1;
            std::vector<double> milliseconds;double total=0;
            for(unsigned i=warmup;i<iterations;++i){const double ms=double((ticks[2*i+1]-ticks[2*i])&mask)*host.properties.limits.timestampPeriod*1.e-6;milliseconds.push_back(ms);total+=ms;}
            timings.push_back({{"mode",mode},{"warmup",warmup},{"samples",samples},{"meanMs",total/samples},{"milliseconds",milliseconds}});
        }
'''+m,1)
s=s.replace('    cleanup.reset();','    if(timing)std::cout<<nlohmann::json{{"extent",side},{"timings",timings}}.dump()<<\'\\n\';\n    timingCleanup.reset();\n    cleanup.reset();',1).replace('Shadow extrema: 64 tiles,','Shadow extrema: finite depth tiles,');p.write_text(s)
