from pathlib import Path
import json,sys,subprocess,os,hashlib
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from build_provenance import verify,inputs
expected=json.loads((o/'baseline-build-provenance.json').read_text())['source'];assert inputs(r)==expected
env=os.environ.copy();env.update(TEMP=str(o/'tmp'),TMP=str(o/'tmp'),TMPDIR=str(o/'tmp'),SQLITE_TMPDIR=str(o/'tmp'));rows=[]
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);verify(r,json.loads((b/'build-provenance.json').read_text()));baseline=json.loads((o/(c+'-baseline-shaders.json')).read_text());assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (b/'shaders').glob('*.spv')}==baseline and len(baseline)==674
 command=[ctest,'--test-dir',str(b),'-R',r'^AzureRender\.(ReflectionSpatialFilter|ObjectShadowAtlas|RenderGraph)$','--output-on-failure','--no-tests=error','--output-junit',str(o/(c+'-restored.xml'))]
 with (o/(c+'-restored-checks.log')).open('wb') as f:result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 rows.append(dict(configuration=c,command=command,exitCode=result.returncode,unchangedPrograms=674));(o/'restored-checks.json').write_text(json.dumps(rows,indent=2));print(c,result.returncode,flush=True);assert result.returncode==0
