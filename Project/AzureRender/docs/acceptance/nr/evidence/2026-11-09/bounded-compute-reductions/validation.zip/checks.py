from pathlib import Path
import os,subprocess,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;env=os.environ.copy();env.update(TEMP=str(o/'tmp'),TMP=str(o/'tmp'),TMPDIR=str(o/'tmp'),SQLITE_TMPDIR=str(o/'tmp'))
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe';rows=[]
for c in ['release','debug']:
 for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  env['VK_LOADER_DRIVERS_SELECT']=driver
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
  pattern=r'^AzureRender\.(ReflectionSpatialFilter|ReflectionSpatialFilterGpu|ShadowTileBoundsGpu|ShadowTileBoundsSubgroupGpu|ObjectShadowAtlas|RenderGraph)$' if device=='nvidia' else r'^AzureRender\.(ReflectionSpatialFilterGpu|ShadowTileBoundsGpu|ShadowTileBoundsSubgroupGpu)$'
  command=[ctest,'--test-dir',str(r/('build/ninja-msvc-'+c)),'-R',pattern,'--output-on-failure','--no-tests=error','--output-junit',str(o/(c+'-'+device+'.xml'))]
  with (o/(c+'-'+device+'-checks.log')).open('wb') as f:result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=150)
  rows.append(dict(configuration=c,device=device,command=command,exitCode=result.returncode));(o/'checks.json').write_text(json.dumps(rows,indent=2));print(c,device,result.returncode,flush=True)
  assert result.returncode==0,(o/(c+'-'+device+'-checks.log')).read_text(errors='replace')[-3500:]
  command=[str(r/('build/ninja-msvc-'+c)/'AzureReflectionSpatialFilterGpuTests.exe'),str(r/('build/ninja-msvc-'+c)/'shaders/reflection_spatial_filter.comp.spv'),str(o/'baseline-runtime/shaders/reflection_spatial_filter.comp.spv')]
  with (o/(c+'-'+device+'-reference.log')).open('wb') as f:result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
  rows.append(dict(configuration=c,device=device,kind='bitwise-filter-reference',command=command,exitCode=result.returncode));(o/'checks.json').write_text(json.dumps(rows,indent=2));print(c,device,'reference',result.returncode,flush=True)
  assert result.returncode==0,(o/(c+'-'+device+'-reference.log')).read_text(errors='replace')[-3500:]

