from pathlib import Path
import json,subprocess,sys,hashlib
r=Path.cwd();o=Path(__file__).resolve().parent;config=sys.argv[1].lower();b=r/('build/ninja-msvc-'+config);old=json.loads((o/(config+'-baseline-shaders.json')).read_text());rows=[]
for p in sorted((b/'shaders').glob('*.spv')):
 if p.name in old and hashlib.sha256(p.read_bytes()).hexdigest()==old[p.name]:continue
 result=subprocess.run(['D:/Tools/VulkanSDK/1.4.350.0/Bin/spirv-val.exe',str(p),'--relax-block-layout','--target-env','vulkan1.3'],capture_output=True,text=True)
 rows.append(dict(program=p.name,exitCode=result.returncode,diagnostic=result.stdout+result.stderr))
(o/(config+'-spirv-validation.json')).write_text(json.dumps(rows,indent=2));assert len(rows)==70 and all(row['exitCode']==0 for row in rows),[row for row in rows if row['exitCode']]
print(config+': all 70 new or modified programs pass Vulkan 1.3 SPIR-V validation')
