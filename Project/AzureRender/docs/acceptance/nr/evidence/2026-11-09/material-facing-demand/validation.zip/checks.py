from pathlib import Path
import sys,os,json,subprocess
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
os.environ.update(managed_environment(o/'tmp'))
mode=sys.argv[1];config=sys.argv[2] if len(sys.argv)>2 else 'release';b=r/('build/ninja-msvc-'+config)
targets=['AzureMaterialFacingDemandTests'] if mode=='red' else ['AzureMaterialFacingDemandTests','AzureMaterialClassEarlyDepthTests','AzureMaterialPipelinePolicyTests']
for target in targets:
 command=[str(b/(target+'.exe'))]+([] if target.endswith('PolicyTests') else [str(b/'shaders')])
 result=guarded_run(r/'build',o.name,command,120)
 name=mode+'-'+config+'-'+target
 (o/(name+'-execution.json')).write_text(json.dumps(result,indent=2))
 (o/(name+'.log')).write_bytes((o/'process.log').read_bytes())
 print(result);print((o/'process.log').read_text(errors='replace')[-1000:])
 assert result['exitCode']==(1 if mode=='red' else 0)
