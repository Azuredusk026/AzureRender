from pathlib import Path
import json,hashlib,subprocess,shutil,sys,zipfile,re
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from build_provenance import verify,digest
from artifact_maintenance import write_json,tracked_paths
from artifact_cleanup import remove_artifact
image=json.loads((o/'image-material-facing-demand/results.json').read_text())
assert len(image['frames'])==4 and all(a['changedPixels']==0 and a['sha256']==a['referenceSha256'] for a in image['frames'])
assert all(image[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationLogClean','zeroAllocator'])
checks=[];shaders={};builds={}
with zipfile.ZipFile(r/'docs/acceptance/nr/evidence/2026-11-09/object-shadow-page-boundary/validation.zip') as z:
 prior=json.loads(z.read('release-build-provenance.json'))
 prior={Path(p).name:v for p,v in prior['products'].items() if p.endswith('.spv') and Path(p).parent.name=='shaders'}
assert len(prior)==675
for config in ['release','debug']:
 b=r/('build/ninja-msvc-'+config);m=json.loads((b/'build-provenance.json').read_text());verify(r,m)
 shutil.copyfile(b/'build-provenance.json',o/(config+'-build-provenance.json'))
 shaders[config]={p.name:digest(p) for p in (b/'shaders').glob('*.spv')}
 assert shaders[config]==prior
 builds[config]=dict(sourceCount=len(m['source']),products=len(m['products']),verified=True)
 for target in ['AzureMaterialFacingDemandTests','AzureMaterialClassEarlyDepthTests','AzureMaterialPipelinePolicyTests']:
  p=o/('green-'+config+'-'+target+'-execution.json');check=json.loads(p.read_text());assert check['exitCode']==0
  checks.append(dict(config=config,target=target,execution=check))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
ph=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest()
assert ph=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
log=(o/'image-material-facing-demand/process.log').read_text();cache=re.search(r'Pipeline cache saved: bytes=(\d+), state=\w+, requests=(\d+), hits=(\d+), feedback=(\d+)',log)
assert cache and int(cache[2])==557
manifest=json.loads(next((o/'image-material-facing-demand').glob('frames-*/capture_manifest.json')).read_text())
for rel in ['src/scenes/CharacterMaterialSampling.inc','tests/MaterialClassEarlyDepthTests.cpp','tests/MaterialFacingDemandTests.cpp','CMakeLists.txt','docs/plans/2026-11-09-material-facing-demand.md']:
 p=o/'final-source'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,p)
result=dict(status='material-facing-demand-verified',baselineCommit='b47260f',run=o.name,builds=builds,checks=checks,nullBackendFacingCasesPerConfiguration=24,all675ShadersUnchanged=True,originalFrames=image['frames'],originalChangedPixels=0,projectInputsVerified=1729,validationClean=True,nativeAllocatorZero=True,protectedDiffSha256=ph,pipelineRequests=dict(baseline=645,candidate=int(cache[2]),reduced=88,reductionPercent=88/645*100,candidateCacheHits=int(cache[3]),baselineCacheHits=507),sceneLoad=manifest['sceneLoad'],initializationTimingIsNotPaired=True,nativeCostProcesses=0,newFullAssetCopies=0,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review')
write_json(o/'results.json',result)
dest=r/'docs/acceptance/nr/evidence/2026-11-09/material-facing-demand';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
selected=[p for p in sorted(o.rglob('*')) if p.is_file() and 'tmp' not in p.relative_to(o).parts and p.suffix.lower() in {'.py','.json','.log','.cpp','.inc','.txt','.md'}]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in selected:z.write(p,p.relative_to(o).as_posix())
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in selected:assert hashlib.sha256(z.read(p.relative_to(o).as_posix())).hexdigest()==digest(p)
result['package']=dict(path=archive.relative_to(r).as_posix(),sha256=digest(archive),bytes=archive.stat().st_size,files=len(selected));write_json(dest/'results.json',result)
targets=[o/'tmp',o/'__pycache__'];byname={a['frame']:a for a in image['frames']}
for p in (o/'image-material-facing-demand').glob('frames-*/*.png'):
 assert digest(p)==byname[p.name]['sha256']==byname[p.name]['referenceSha256'];targets.append(p)
tracked=tracked_paths(r);before=shutil.disk_usage(r).free;removed=[]
for p in targets:
 if p.exists():
  assert p.resolve().is_relative_to(o.resolve())
  removed.append(dict(path=str(p.resolve()),removed=remove_artifact(r/'build',p,tracked,apply=True)))
after=shutil.disk_usage(r).free;cleanup=dict(removed=removed,freeBefore=before,freeAfter=after,observedFreedBytes=after-before);write_json(dest/'cleanup.json',cleanup);write_json(o/'cleanup.json',cleanup)
print(json.dumps(dict(package=result['package'],pipelineRequests=result['pipelineRequests'],observedFreedBytes=after-before),indent=2))
