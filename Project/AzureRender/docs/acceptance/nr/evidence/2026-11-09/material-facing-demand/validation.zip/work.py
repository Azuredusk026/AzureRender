from pathlib import Path
import os,json,subprocess,sys,time
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
os.environ.update(managed_environment(o/'tmp'));mode=sys.argv[-1]
if '--inside' not in sys.argv:
 os.environ.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 d=guarded_run(r/'build',o.name,[str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',mode],900);(o/(mode.lower()+'-execution.json')).write_text(json.dumps(d,indent=2));print(d);raise SystemExit(d['exitCode'])
assert mode in ['Release','Debug'];b=r/('build/ninja-msvc-'+mode.lower())
command=[sys.executable,'-X','utf8','tools/build_provenance.py','build','--build-dir',str(b),'--config',mode,'--test-target','AzureMaterialFacingDemandTests']
command+=['--test-target','AzureMaterialClassEarlyDepthTests','--test-target','AzureMaterialPipelinePolicyTests']
with (o/(mode.lower()+'-build.log')).open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
(o/(mode.lower()+'-build.json')).write_text(json.dumps(dict(command=command,exitCode=result.returncode),indent=2));raise SystemExit(result.returncode)

