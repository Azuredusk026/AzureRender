from pathlib import Path
import struct,re,ctypes,json
o=Path(__file__).resolve().parent
header=(o/'D3D12TokenizedProgramFormat.hpp').read_text()
body=header.split('typedef enum D3D10_SB_OPCODE_TYPE {',1)[1].split('}',1)[0]
body=re.sub(r'//[^\n]*','',body);opcodes={};value=0
for item in body.split(','):
 item=item.strip()
 if not item:continue
 match=re.fullmatch(r'(\w+)(?:\s*=\s*(\d+))?',item)
 if not match:raise ValueError(item)
 if match[2]:value=int(match[2])
 opcodes[match[1]]=value;value+=1
def opcode(name):return opcodes['D3D10_SB_OPCODE_'+name]
def words(raw):return list(struct.unpack('<'+'I'*(len(raw)//4),raw))
def checksum(raw):
 # DXBC finalisation follows RenderDoc v1.46 DXBCContainer::HashContainer.
 # Padding adaptation is covered by LICENSE-RenderDoc.txt in this task.
 # Compression uses the existing OpenSSL implementation on D.
 lib=ctypes.CDLL('D:/Tools/Python311/DLLs/libcrypto-3.dll')
 lib.MD5_Init.argtypes=[ctypes.c_void_p];lib.MD5_Update.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t]
 ctx=(ctypes.c_uint32*128)();assert lib.MD5_Init(ctx)==1
 data=raw[20:];bits=len(data)*8;tail=data[len(data)//64*64:];prefix=data[:len(data)//64*64]
 if len(tail)>=56:
  final=tail+b'\x80'+b'\0'*(63-len(tail))+struct.pack('<I',bits)+b'\0'*56+struct.pack('<I',(bits>>2)|1)
 else:
  final=struct.pack('<I',bits)+tail+b'\x80'+b'\0'*(55-len(tail))+struct.pack('<I',(bits>>2)|1)
 padded=prefix+final;assert len(padded)%64==0
 assert lib.MD5_Update(ctx,ctypes.create_string_buffer(padded),len(padded))==1
 return bytes(ctx)[:16]
def blob_part(raw):
 dll=ctypes.WinDLL('d3dcompiler_47.dll');fn=dll.D3DSetBlobPart
 fn.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint,ctypes.c_uint,ctypes.c_void_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_void_p)];fn.restype=ctypes.c_long
 src=ctypes.create_string_buffer(raw);part=ctypes.create_string_buffer(b'AzureReceiverDiagnosticV1');blob=ctypes.c_void_p()
 hr=fn(src,len(raw),10,0,part,len(part)-1,ctypes.byref(blob))
 if hr<0:raise RuntimeError('D3DSetBlobPart failed: '+hex(hr&0xffffffff))
 table=ctypes.cast(blob,ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
 ptr=ctypes.WINFUNCTYPE(ctypes.c_void_p,ctypes.c_void_p)(table[3])(blob)
 size=ctypes.WINFUNCTYPE(ctypes.c_size_t,ctypes.c_void_p)(table[4])(blob)
 try:return ctypes.string_at(ptr,size)
 finally:ctypes.WINFUNCTYPE(ctypes.c_ulong,ctypes.c_void_p)(table[2])(blob)
def chunks(raw):
 assert raw[:4]==b'DXBC' and struct.unpack_from('<I',raw,24)[0]==len(raw)
 count=struct.unpack_from('<I',raw,28)[0];out=[]
 for off in struct.unpack_from('<'+'I'*count,raw,32):
  size=struct.unpack_from('<I',raw,off+4)[0];out.append((raw[off:off+4],raw[off+8:off+8+size]))
 return out
def rebuild(original,parts):
 data=bytearray(original[:32]);struct.pack_into('<I',data,28,len(parts));data.extend(b'\0'*(4*len(parts)))
 for index,(kind,payload) in enumerate(parts):
  assert len(data)%4==0;struct.pack_into('<I',data,32+4*index,len(data));data.extend(kind+struct.pack('<I',len(payload))+payload)
 struct.pack_into('<I',data,24,len(data));data[4:20]=checksum(bytes(data));return bytes(data)
def instructions(w):
 assert w[1]==len(w);at=2;pc=None
 while at<len(w):
  op=w[at]&0x7ff;n=w[at+1] if op==opcode('CUSTOMDATA') else (w[at]>>24)&0x7f
  assert n>0 and at+n<=len(w)
  if pc is None and op==opcode('FTOU'):pc=0
  yield pc,at,op,n
  if pc is not None:pc+=1
  at+=n
def inst(name,*operands):
 values=[x for operand in operands for x in operand];return [opcode(name)|((len(values)+1)<<24),*values]
def dest(reg,mask=1,output=False):return [2|(mask<<4)|((2 if output else 0)<<12)|(1<<20),reg]
def source(reg,component=0):return [2|(2<<2)|(component<<4)|(1<<20),reg]
def imm(value):return [1|(4<<12),value]
def fbits(f):return struct.unpack('<I',struct.pack('<f',f))[0]
def instrument(raw,point=None,component=0,byte=0):
 parts=chunks(raw);idx=next(i for i,(kind,_) in enumerate(parts) if kind in [b'SHEX',b'SHDR']);w=words(parts[idx][1]);items=list(instructions(w));numbered=[x for x in items if x[0] is not None]
 assert len(numbered)==367 and numbered[-1][2]==opcode('RET')
 extra=inst('MOV',dest(0,output=True),imm(0))
 if point is not None:
  capturePc,register=point[:2];swizzle=point[2] if len(point)>2 else 0xe4
  for pc,at,op,n in items:
   if op==opcode('DCL_TEMPS'):
    assert w[at+1]==11;w[at+1]=13
  end=numbered[-1][1]
  extra=inst('USHR',dest(12),source(11,component),imm(byte*8))+inst('AND',dest(12),source(12),imm(255))+inst('UTOF',dest(12),source(12))+inst('MUL',dest(12),source(12),imm(fbits(1/255)))+inst('MOV',dest(0,output=True),source(12))
  w[end:end]=extra
  _,at,_,n=next(x for x in numbered if x[0]==capturePc)
  w[at+n:at+n]=inst('MOV',dest(11,7),[2|(1<<2)|(swizzle<<4)|(1<<20),register])
  start=numbered[0][1];w[start:start]=inst('MOV',dest(11,7),imm(0))
 else:
  end=numbered[-1][1];w[end:end]=extra
 w[1]=len(w);parts[idx]=(parts[idx][0],struct.pack('<'+'I'*len(w),*w));return rebuild(raw,parts)
if __name__=='__main__':
 raw=(o/'producer.dxbc').read_bytes();assert checksum(raw)==raw[4:20];control=instrument(raw);(o/'control.dxbc').write_bytes(control)
 assert blob_part(control)[:4]==b'DXBC'
 assert len([i for i in instructions(words(next(p for k,p in chunks(control) if k in [b'SHEX',b'SHDR']))) if i[0] is not None])==368
 print(dict(originalBytes=len(raw),controlBytes=len(control),opcodeValues={k:opcode(k) for k in ['MOV','MUL','USHR','UTOF','DCL_TEMPS']},controlChecksum=control[4:20].hex()))
