from pathlib import Path
import os,sys,json,struct,traceback,time,hashlib
import renderdoc as rd
r=Path('D:/Projects/FYP/Project/AzureRender');o=Path(os.environ['AZURE_RECEIVER_TASK']);sys.path.insert(0,str(o))
from dxbc_probe import instrument
old=r/'build/runs/20261109-172812-native-receiver-gpu-oracle-d9e5ba'
pixels=list(struct.iter_unpack('<II',(old/'pixels.bin').read_bytes()));expected=(old/'expected.u8').read_bytes();assert len(pixels)==len(expected)==49384
cap=None;c=None;replacements=[];report=dict(status='starting',runs=[])
try:
 try:pyrenderdoc.Config().Close()
 except (AttributeError,NameError):pass
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(r/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc'),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 c.SetFrameEvent(699,True);p=c.GetPipelineState();shader=p.GetShader(rd.ShaderStage.Pixel);target=p.GetOutputTargets()[0].resource
 tex=next(t for t in c.GetTextures() if t.resourceId==target);report['texture']=dict(width=tex.width,height=tex.height,format=tex.format.Name())
 def read():
  raw=bytes(c.GetTextureData(target,rd.Subresource()));stride=len(raw)//(tex.width*tex.height);assert stride in [2,4]
  # Stored diagnostic pixel coordinates use the native bottom-up pixel convention.
  offsets=[(y*tex.width+x)*stride for x,y in pixels]
  return bytes(raw[i] for i in offsets),bytes(raw[i+1] for i in offsets)
 red,baseline=read();delta=[abs(a-b) for a,b in zip(baseline,expected)]
 report['baseline']=dict(exact=sum(x==0 for x in delta),maximumByteError=max(delta));assert not any(delta),report['baseline']
 raw=(o/'producer.dxbc').read_bytes()
 probes=[dict(name='control',point=None,component=0,byte=0)]
 if (o/'enable-intermediates').exists():
  stages=[('receiver',(305,1))]
  if (o/'enable-intermediates').read_text().strip()=='stages':stages=[('world',(13,2)),('normal',(26,3)),('biased',(301,1,0xf8))]
  if (o/'enable-intermediates').read_text().strip()=='homogeneous':stages=[('homogeneous',(12,2)),('homogeneous-w',(12,2,0xff)),('sampled-depth',(8,2,0))]
  probes=[dict(name=name+'-'+str(component)+'-'+str(byte),point=point,component=component,byte=byte) for name,point in stages for component in range(1 if name in ['homogeneous-w','sampled-depth'] else 3) for byte in range(4)]
 for probe in probes:
  start=time.monotonic();code=instrument(raw,probe['point'],probe['component'],probe['byte']);(o/(probe['name']+'.dxbc')).write_bytes(code)
  replacement,errors=c.BuildTargetShader('main',rd.ShaderEncoding.DXBC,code,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
  assert replacement!=rd.ResourceId.Null(),errors;replacements.append(replacement);c.ReplaceResource(shader,replacement);c.SetFrameEvent(699,True)
  values,actual=read();diff=[abs(a-b) for a,b in zip(actual,baseline)]
  row=dict(probe=probe,qualified=not any(diff),unchangedVisibilityPixels=sum(x==0 for x in diff),visibilityMaximumByteError=max(diff),seconds=time.monotonic()-start,shaderSha256=hashlib.sha256(code).hexdigest())
  if row['qualified']:(o/(probe['name']+'.u8')).write_bytes(values)
  report['runs'].append(row);(o/'probe-results.json').write_text(json.dumps(report,indent=2));c.RemoveReplacement(shader)
  assert row['qualified'],row
 report['status']='qualified';report['debugMessages']=[m.description for m in c.GetDebugMessages()][:20]
except BaseException:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:
  try:
   if 'shader' in locals():c.RemoveReplacement(shader)
   for replacement in replacements:c.FreeTargetResource(replacement)
  finally:c.Shutdown()
 if cap:cap.Shutdown()
 (o/'probe-results.json').write_text(json.dumps(report,indent=2))
os._exit(0 if report['status']=='qualified' else 1)
