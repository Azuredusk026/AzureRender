from pathlib import Path
o=Path(__file__).resolve().parent;s=(o/'native_receiver_homogeneous.glsl').read_text()
for name,split in [('precise',False),('split',True)]:
 text=s.replace('vec4 world=-clip.y','precise vec4 world=-clip.y')
 if split:
  import re
  text=re.sub(r'world=fma\(vec4\(clip.x\),(uintBitsToFloat\(uvec4\([^;]+?\)\)),world\);',r'world=vec4(clip.x)*\1+world;',text)
  text=re.sub(r'world=fma\(vec4\(inputValue.z\),(uintBitsToFloat\(uvec4\([^;]+?\)\)),world\);',r'world=vec4(inputValue.z)*\1+world;',text)
 (o/('native_receiver_'+name+'.glsl')).write_text(text)
 for output in ['homogeneous','filter']:
  shader=(o/'homogeneous.comp').read_text().replace('native_receiver_homogeneous.glsl','native_receiver_'+name+'.glsl')
  if output=='filter':shader=shader.replace('outputData.results[i]=homogeneousPosition;','outputData.results[i]=vec4(filtered,objectShadowUnorm8(filtered.x),clear.x);')
  (o/(name+'-'+output+'.comp')).write_text(shader)
script=(o/'stages_check.py').read_text().replace("['world','normal','biased']","['precise-homogeneous','precise-filter','split-homogeneous','split-filter']").replace("'stages-execution.json'","'precision-execution.json'")
(o/'precision_check.py').write_text(script)
print('Prepared precise fused and precise split projection controls')
