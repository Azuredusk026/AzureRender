from pathlib import Path
o=Path(__file__).resolve().parent
s=(o/'native_receiver_stages.glsl').read_text().replace('out vec3 biasedPosition)','out vec3 biasedPosition,out vec4 homogeneousPosition)')
s=s.replace('world.xyz/=world.w;','homogeneousPosition=world;world.xyz/=world.w;')
(o/'native_receiver_homogeneous.glsl').write_text(s)
s=(o/'world.comp').read_text().replace('native_receiver_stages.glsl','native_receiver_homogeneous.glsl')
s=s.replace('vec3 unusedNormal,measuredWorld,measuredBias;','vec3 unusedNormal,measuredWorld,measuredBias;vec4 homogeneousPosition;')
s=s.replace('a,unusedNormal,measuredWorld,measuredBias)','a,unusedNormal,measuredWorld,measuredBias,homogeneousPosition)')
s=s.replace('vec4(measuredWorld,1.0)','homogeneousPosition');(o/'homogeneous.comp').write_text(s)
s=(o/'stages_check.py').read_text().replace("['world','normal','biased']","['homogeneous']").replace("'stages-execution.json'","'homogeneous-execution.json'")
(o/'homogeneous_check.py').write_text(s);(o/'enable-intermediates').write_text('homogeneous')
print('Prepared sampled depth and homogeneous-position controls')
