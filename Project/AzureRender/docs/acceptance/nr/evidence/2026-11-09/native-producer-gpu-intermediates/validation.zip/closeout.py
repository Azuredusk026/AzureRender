from pathlib import Path
import json,hashlib,subprocess,shutil,sys,zipfile
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from build_provenance import verify,digest
from artifact_maintenance import write_json,tracked_paths
from artifact_cleanup import remove_artifact
old=o.parent/'20261109-172812-native-receiver-gpu-oracle-d9e5ba'
for name in ['receiver-queries.bin','expected.u8','pixels.bin']:
 shutil.copyfile(old/name,o/name)
fixture=json.loads((o/'coordinates-fixture.json').read_text());fixture['queryPath']=str(o/'receiver-queries.bin');write_json(o/'coordinates-fixture.json',fixture)
sources=json.loads((old/'scope.json').read_text())['sourceInputs']
assert all(digest(Path(p))==sha for p,sha in sources.items())
qualification=[]
for name,count in [('control-results.json',1),('receiver-probe-results.json',12),('stages-probe-results.json',36),('probe-results.json',20)]:
 data=json.loads((o/name).read_text());assert data['status']=='qualified' and len(data['runs'])==count
 assert all(x['qualified'] and x['unchangedVisibilityPixels']==49384 and x['visibilityMaximumByteError']==0 for x in data['runs'])
 qualification.append(dict(file=name,versions=count,unchangedPixelsPerVersion=49384))
precision=json.loads((o/'precision-analysis.json').read_text());good=next(x for x in precision if x['mode']=='precise');assert good['pixelsOverOneByte']==0 and good['homogeneousExactPixels']==49384
checks=[]
for p in sorted(o.glob('*collection.log')):
 s=p.read_text(errors='replace');assert 'VK_LAYER_KHRONOS_validation' in s and not any(x in s for x in ['VUID-','SYNC-HAZARD','Validation Error'])
 checks.append(dict(file=p.name,validationLayerObserved=True,validationClean=True))
builds={}
for config in ['release','debug']:
 p=r/('build/ninja-msvc-'+config)/'build-provenance.json';m=json.loads(p.read_text());verify(r,m);shutil.copyfile(p,o/(config+'-build-provenance.json'));builds[config]=dict(verified=True,sourceCount=len(m['source']))
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
ph=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest();assert ph=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
report=dict(status='nvidia-region-input-precision-diagnosed-intel-not-passed',run=o.name,samples=49384,sourceInputs=sources,originalShaderSha256=digest(o/'producer.dxbc'),qualification=qualification,region=json.loads((o/'analysis.json').read_text()),stages=json.loads((o/'stage-analysis.json').read_text())['stages'],homogeneous=json.loads((o/'homogeneous-analysis.json').read_text()),precision=precision,intelPrecision=json.loads((o/'intel-precision-analysis.json').read_text()),intelMeasuredReceiver=json.loads((o/'intel-measured-analysis.json').read_text()),checks=checks,builds=builds,protectedDiffSha256=ph,newPlayerProcesses=0,newGameCaptureProcesses=0,newPerformanceProcesses=0,newFullAssetCopies=0,formalPerformancePassed=False,fullHairColorPassed=False,overallVisualAcceptance='failed-user-review')
write_json(o/'results.json',report)
dest=r/'docs/acceptance/nr/evidence/2026-11-09/native-producer-gpu-intermediates';dest.mkdir(parents=True,exist_ok=True);package=dest/'validation.zip'
selected=[p for p in sorted(o.iterdir()) if p.is_file() and p.suffix.lower() in ['.py','.json','.txt','.log','.glsl','.comp','.cpp']]
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in selected:z.write(p,p.name)
assert package.stat().st_size<8*1024*1024
with zipfile.ZipFile(package) as z:
 assert z.testzip() is None
 for p in selected:assert hashlib.sha256(z.read(p.name)).hexdigest()==digest(p)
report['package']=dict(bytes=package.stat().st_size,files=len(selected),sha256=digest(package));write_json(dest/'results.json',report)
tracked=tracked_paths(r);before=shutil.disk_usage(r).free;removed=[]
for p in [o/'tmp',o/'__pycache__',o/'collector.exe',o/'collector.obj',*o.glob('*.spv')]:
 if p.exists():
  assert p.resolve().is_relative_to(o.resolve());removed.append(dict(path=str(p.resolve()),removed=remove_artifact(r/'build',p,tracked,apply=True)))
after=shutil.disk_usage(r).free;write_json(o/'cleanup.json',dict(removed=removed,freeBefore=before,freeAfter=after,observedFreedBytes=after-before));print(json.dumps(dict(package=report['package'],checks=len(checks),observedFreedBytes=after-before)))
