from pathlib import Path
import numpy as np,json
o=Path(__file__).resolve().parent;old=o.parent/'20261109-172812-native-receiver-gpu-oracle-d9e5ba'
report=json.loads((o/'probe-results.json').read_text());assert report['status']=='qualified' and len(report['runs'])==20 and all(x['qualified'] for x in report['runs'])
def decode(name,count):
 bits=np.zeros((49384,count),dtype='<u4')
 for component in range(count):
  for byte in range(4):bits[:,component]|=np.fromfile(o/(name+'-'+str(component)+'-'+str(byte)+'.u8'),dtype='u1').astype('u4')<<(byte*8)
 return bits.view('<f4')
depth=decode('sampled-depth',1).ravel();depth.tofile(o/'native-sampled-depth.bin')
native=np.column_stack([decode('homogeneous',3),decode('homogeneous-w',1)]);native.tofile(o/'native-homogeneous.bin')
actual=np.fromfile(o/'homogeneous-output.bin',dtype='<f4').reshape(-1,4);queries=np.fromfile(old/'receiver-queries.bin',dtype='<f4').reshape(-1,3,4).copy();sourceDepth=queries[:,0,2]
expected=np.fromfile(old/'expected.u8',dtype='u1').astype('i4');prior=np.rint(np.fromfile(old/'receiver-output.bin',dtype='<f4').reshape(-1,4)[:,2]*255).astype('i4');failed=abs(prior-expected)>1
sameDepth=depth==sourceDepth;sameH=np.all(native==actual,axis=1)
result=dict(sampledDepth=dict(exactPixels=int(sameDepth.sum()),maximumAbsoluteDifference=float(abs(depth-sourceDepth).max()),exactAmong40ErrorPixels=int((sameDepth&failed).sum())),homogeneous=dict(exactPixels=int(sameH.sum()),maximumAbsolutePerComponent=abs(native-actual).max(axis=0).tolist(),exactAmong40ErrorPixels=int((sameH&failed).sum())))
(o/'homogeneous-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
