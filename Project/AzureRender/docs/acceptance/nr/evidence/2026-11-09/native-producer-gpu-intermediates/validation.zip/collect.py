from pathlib import Path
import os,json,traceback,time
import renderdoc as rd
r=Path('D:/Projects/FYP/Project/AzureRender');o=Path(os.environ['AZURE_RECEIVER_TASK']);cap=None;c=None;report=dict(status='starting')
try:
 try:pyrenderdoc.Config().Close()
 except (AttributeError,NameError):pass
 cap=rd.OpenCaptureFile();assert cap.OpenFile(str(r/'build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc'),'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 c.SetFrameEvent(699,True);p=c.GetPipelineState();shader=p.GetShader(rd.ShaderStage.Pixel);reflection=p.GetShaderReflection(rd.ShaderStage.Pixel)
 raw=bytes(reflection.rawBytes);assert raw[:4]==b'DXBC';(o/'producer.dxbc').write_bytes(raw)
 report.update(status='collected',shader=str(shader),target=str(p.GetOutputTargets()[0].resource),bytes=len(raw),encodings=[str(x) for x in c.GetTargetShaderEncodings()])
except BaseException:report.update(status='failed',error=traceback.format_exc())
finally:
 if c:c.Shutdown()
 if cap:cap.Shutdown()
 (o/'collect.json').write_text(json.dumps(report,indent=2))
os._exit(0 if report['status']=='collected' else 1)
