from pathlib import Path
import json,urllib.request,hashlib,sys,os,subprocess
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'))
commit=subprocess.check_output(['git','ls-remote','https://github.com/microsoft/DirectX-Headers.git','HEAD'],timeout=20,text=True).split()[0]
url='https://raw.githubusercontent.com/microsoft/DirectX-Headers/'+commit+'/include/directx/D3D12TokenizedProgramFormat.hpp'
with urllib.request.urlopen(url,timeout=20) as f:raw=f.read(262144)
assert len(raw)<262144 and b'MIT' in raw
(o/'D3D12TokenizedProgramFormat.hpp').write_bytes(raw)
(o/'header-source.json').write_text(json.dumps(dict(url=url,commit=commit,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),license='MIT; opcode and operand format reference, no header code linked into production'),indent=2))
print(dict(commit=commit,bytes=len(raw)))
rdcommit=subprocess.check_output(['git','ls-remote','https://github.com/baldurk/renderdoc.git','refs/tags/v1.46','refs/tags/v1.46^{}'],timeout=20,text=True).splitlines()[-1].split()[0]
rdurl='https://raw.githubusercontent.com/baldurk/renderdoc/'+rdcommit+'/renderdoc/driver/shaders/dxbc/dxbc_container.cpp'
with urllib.request.urlopen(rdurl,timeout=20) as f:rdraw=f.read(262144)
assert len(rdraw)<262144
license=rdraw[:rdraw.index(b'******************************************************************************/')+len(b'******************************************************************************/')]
(o/'LICENSE-RenderDoc.txt').write_bytes(license+b'\n')
(o/'checksum-source.json').write_text(json.dumps(dict(url=rdurl,commit=rdcommit,sourceSha256=hashlib.sha256(rdraw).hexdigest(),license='MIT',adaptation='DXBCContainer::HashContainer final padding, using existing OpenSSL compression API; diagnostic container rehashing only.'),indent=2))
