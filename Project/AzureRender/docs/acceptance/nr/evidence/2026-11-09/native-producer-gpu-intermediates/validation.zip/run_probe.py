from pathlib import Path
import os,sys,subprocess,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
from build_provenance import inputs,digest
os.environ.update(managed_environment(o/'tmp'));os.environ['AZURE_RECEIVER_TASK']=str(o)
for key in ['APPDATA','LOCALAPPDATA']:
 p=o/'tmp'/key.lower();p.mkdir(exist_ok=True);os.environ[key]=str(p)
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES']:os.environ.pop(key,None)
os.environ['RENDERDOC_DEBUG_LOG_FILE']=str(o/'tmp/renderdoc.log');os.environ['RDOC_DEBUG_LOG_FILE']=str(o/'tmp/renderdoc.log')
if '--inside' not in sys.argv:
 before=inputs(r);products={str(p):digest(p) for p in [r/'build/ninja-msvc-release/AzurePlayer.exe',*sorted((r/'build/ninja-msvc-release/shaders').glob('*.spv'))]}
 result=guarded_run(r/'build',o.name,[sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],240);(o/'trace-execution.json').write_text(json.dumps(result,indent=2));assert inputs(r)==before and all(digest(Path(p))==v for p,v in products.items());print(result);raise SystemExit(result['exitCode'])
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
with (o/'trace-driver.log').open('wb') as log:p=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(o/'probe.py')],startupinfo=startup,creationflags=subprocess.CREATE_NO_WINDOW,stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(p.returncode)


