from pathlib import Path
o=Path(__file__).resolve().parent
s=(o/'native_receiver_stages.glsl').read_text();assert 'world.xyz/=world.w;' in s
s=s.replace('world.xyz/=world.w;','world.xyz*=1.0/world.w;');(o/'native_receiver_reciprocal.glsl').write_text(s)
for name,source in [('reciprocal-world','world.comp'),('reciprocal-filter','world.comp')]:
 text=(o/source).read_text().replace('native_receiver_stages.glsl','native_receiver_reciprocal.glsl')
 if name.endswith('filter'):text=text.replace('vec4(measuredWorld,1.0)','vec4(filtered,objectShadowUnorm8(filtered.x),clear.x)')
 (o/(name+'.comp')).write_text(text)
text=(o/'stages_check.py').read_text().replace("['world','normal','biased']","['reciprocal-world','reciprocal-filter']").replace("'stages-execution.json'","'reciprocal-execution.json'")
(o/'reciprocal_check.py').write_text(text)
print('Prepared reciprocal/multiply division control')
