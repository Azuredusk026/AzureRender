from pathlib import Path
import json
o=Path(__file__).resolve().parent
source=(o/'native_receiver.glsl').read_text()
source=source.replace('out vec3 normal)', 'out vec3 normal,out vec3 worldPosition,out vec3 biasedPosition)')
source=source.replace('world.xyz/=world.w;','world.xyz/=world.w;worldPosition=world.xyz;')
needle='vec3 projected=biased.y';assert needle in source
source=source.replace(needle,'biasedPosition=biased;\n'+needle)
(o/'native_receiver_stages.glsl').write_text(source)
source=(o/'coordinates.comp').read_text().replace('native_receiver.glsl','native_receiver_stages.glsl').replace('vec3 unusedNormal;vec3 receiver=reconstructNativeReceiver(a,unusedNormal);','vec3 unusedNormal,measuredWorld,measuredBias;vec3 receiver=reconstructNativeReceiver(a,unusedNormal,measuredWorld,measuredBias);')
for name,variable in [('world','measuredWorld'),('normal','unusedNormal'),('biased','measuredBias')]:
 (o/(name+'.comp')).write_text(source.replace('vec4(receiver,1.0)','vec4('+variable+',1.0)'))
script=(o/'filter_check.py').read_text().replace("['compile-command.txt','link-command.txt']","[]").replace("['filter','coordinates']","['world','normal','biased']").replace("'coordinates-fixture.json'","'coordinates-fixture.json'").replace("'filter-check-execution.json'","'stages-execution.json'")
(o/'stages_check.py').write_text(script)
(o/'enable-intermediates').write_text('stages')
print('Prepared world, normal and biased-position GPU stages')
