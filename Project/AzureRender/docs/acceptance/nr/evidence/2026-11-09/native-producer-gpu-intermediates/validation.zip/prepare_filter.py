from pathlib import Path
import os,sys,json,shutil,struct
import numpy as np
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;old=o.parent/'20261109-172812-native-receiver-gpu-oracle-d9e5ba'
sys.path.insert(0,str(r/'tools'));from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'))
report=json.loads((o/'probe-results.json').read_text());assert report['status']=='qualified' and len(report['runs'])==12 and all(x['qualified'] for x in report['runs'])
coords=np.zeros((49384,3),dtype='<u4')
for component in range(3):
 for byte in range(4):coords[:,component]|=np.fromfile(o/('receiver-'+str(component)+'-'+str(byte)+'.u8'),dtype='u1').astype('u4')<<(byte*8)
coords=coords.view('<f4');assert np.isfinite(coords).all();coords.tofile(o/'native-projected.bin')
queries=np.fromfile(old/'queries.bin',dtype='<f4').reshape(-1,3,4).copy()
queries[:,0,:2]=coords[:,:2]*queries[:,2,2:]+queries[:,2,:2]
queries[:,0,2]=np.maximum(coords[:,2],np.float32(.01));queries.tofile(o/'native-filter-queries.bin')
fixture=json.loads((old/'fixture.json').read_text());fixture['queryPath']=str(o/'native-filter-queries.bin');(o/'fixture.json').write_text(json.dumps(fixture,indent=2))
for name in ['collector.cpp','filter.comp','object_shadow.glsl','receiver.comp','native_receiver.glsl']:
 shutil.copyfile(old/name,o/name)
s=(o/'receiver.comp').read_text();needle='outputData.results[i]=vec4(filtered,objectShadowUnorm8(filtered.x),clear.x);'
assert needle in s;s=s.replace(needle,'outputData.results[i]=vec4(receiver,1.0);');(o/'coordinates.comp').write_text(s)
fixture=json.loads((old/'receiver-fixture.json').read_text());(o/'coordinates-fixture.json').write_text(json.dumps(fixture,indent=2))
for name in ['compile-command.txt','link-command.txt']:
 text=(old/name).read_text().replace(str(old),str(o)).replace(old.as_posix(),o.as_posix());(o/name).write_text(text)
print(dict(samples=len(coords),minimum=coords.min(axis=0).tolist(),maximum=coords.max(axis=0).tolist()))
