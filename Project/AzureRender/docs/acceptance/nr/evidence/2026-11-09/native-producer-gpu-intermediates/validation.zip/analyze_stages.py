from pathlib import Path
import numpy as np,json
o=Path(__file__).resolve().parent;report=json.loads((o/'probe-results.json').read_text());assert report['status']=='qualified' and len(report['runs'])==36 and all(x['qualified'] for x in report['runs'])
old=o.parent/'20261109-172812-native-receiver-gpu-oracle-d9e5ba';expected=np.fromfile(old/'expected.u8',dtype='u1').astype('i4');prior=np.rint(np.fromfile(old/'receiver-output.bin',dtype='<f4').reshape(-1,4)[:,2]*255).astype('i4');failed=abs(prior-expected)>1
result=[];allValues={}
for name in ['world','normal','biased']:
 bits=np.zeros((49384,3),dtype='<u4')
 for component in range(3):
  for byte in range(4):bits[:,component]|=np.fromfile(o/(name+'-'+str(component)+'-'+str(byte)+'.u8'),dtype='u1').astype('u4')<<(byte*8)
 native=bits.view('<f4');assert np.isfinite(native).all();native.tofile(o/('native-'+name+'.bin'))
 actual=np.fromfile(o/(name+'-output.bin'),dtype='<f4').reshape(-1,4)[:,:3].copy();delta=abs(actual-native);same=np.all(actual==native,axis=1)
 result.append(dict(stage=name,exactPixels=int(same.sum()),totalPixels=len(same),maxAbsolutePerComponent=delta.max(axis=0).tolist(),exactAmong40ErrorPixels=int((same&failed).sum()),errorPixelMaximumAbsolute=delta[failed].max(axis=0).tolist()))
 allValues[name]=(native,actual)
pixels=np.fromfile(old/'pixels.bin',dtype='<u4').reshape(-1,2);points=[]
for i in np.where(failed)[0][:10]:
 row=dict(pixel=[int(pixels[i,0]),1439-int(pixels[i,1])])
 for name,(native,actual) in allValues.items():row[name]=dict(native=native[i].tolist(),vulkan=actual[i].tolist())
 points.append(row)
(o/'stage-analysis.json').write_text(json.dumps(dict(stages=result,errorPoints=points),indent=2)+'\n');print(json.dumps(result,indent=2))
