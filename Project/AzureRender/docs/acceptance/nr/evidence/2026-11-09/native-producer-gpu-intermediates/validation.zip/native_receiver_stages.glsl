vec3 reconstructNativeReceiver(vec4 inputValue,out vec3 normal,out vec3 worldPosition,out vec3 biasedPosition) {
vec2 clip=fma(inputValue.xy*uintBitsToFloat(uvec4(1159725056u,1152647168u,969723085u,976620385u)).zw,vec2(2.0),vec2(-1.0));
vec4 world=-clip.y*uintBitsToFloat(uvec4(2887152347u,3198249871u,3145878232u,0u));
world=fma(vec4(clip.x),uintBitsToFloat(uvec4(3205463799u,2710536677u,799388135u,0u)),world);
world=fma(vec4(inputValue.z),uintBitsToFloat(uvec4(3309010823u,1161563220u,3308875657u,1092616089u)),world);
world+=uintBitsToFloat(uvec4(3169993671u,1026417668u,3213082447u,953122682u));
world.xyz/=world.w;worldPosition=world.xyz;
uint packed=floatBitsToUint(inputValue.w);
vec2 encoded=vec2(packed&1023u,(packed>>10)&1023u)/1023.0;
vec2 xy=fma(encoded,vec2(2.0),vec2(-1.0));
normal=vec3(xy.x,1.0-abs(xy.x)-abs(xy.y),xy.y);
if(normal.y<0.0)normal.xz=(1.0-abs(xy.yx))*mix(vec2(-1),vec2(1),greaterThanEqual(xy,vec2(0)));
normal*=inversesqrt(dot(normal,normal));
vec3 light=uintBitsToFloat(uvec4(3189165025u,3204950219u,3210071382u,0u)).xyz;
float weight=1.0-min(max(dot(normal,light),0.0),0.9);
vec3 biased=fma(-light,vec3(weight*uintBitsToFloat(uvec4(999880640u,1008269248u,986445056u,1132462080u)).x),world.xyz);
biased=fma(normal,vec3(weight*uintBitsToFloat(uvec4(999880640u,1008269248u,986445056u,1132462080u)).y),biased);
biasedPosition=biased;
vec3 projected=biased.y*uintBitsToFloat(uvec4(2988647367u,1051569977u,1046129533u,0u)).xyz;
projected=fma(vec3(biased.x),uintBitsToFloat(uvec4(1058945137u,3172385986u,1030951363u,0u)).xyz,projected);
projected=fma(vec3(biased.z),uintBitsToFloat(uvec4(3185520705u,3193291577u,1051480177u,0u)).xyz,projected);
projected+=uintBitsToFloat(uvec4(1125724457u,3274653762u,1113336375u,1065353216u)).xyz;
projected.z=max(projected.z,0.01);
projected.xy=fma(projected.xy,uintBitsToFloat(uvec4(1056964608u,1056964608u,1048576000u,1056964608u)).zw,uintBitsToFloat(uvec4(1056964608u,1056964608u,1048576000u,1056964608u)).xy);
return projected;
}
