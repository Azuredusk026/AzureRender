from pathlib import Path
o=Path(__file__).resolve().parent
s=(o/'precision_check.py').read_text().replace("['precise-homogeneous','precise-filter','split-homogeneous','split-filter']","['precise-homogeneous','precise-filter']").replace("'*nv-vk64*'","'*igvk64*'").replace("'precision-execution.json'","'intel-precision-execution.json'")
s=s.replace("for mode in ['precise-homogeneous','precise-filter']:\n fixture", "for mode in ['precise-homogeneous','precise-filter']:\n fixture")
s=s.replace("(mode+'-collection.log')","('intel-'+mode+'-collection.log')").replace("(mode+'-output.bin')","('intel-'+mode+'-output.bin')")
(o/'intel_precision_check.py').write_text(s)
print('Prepared Intel checks for the qualified projection')
