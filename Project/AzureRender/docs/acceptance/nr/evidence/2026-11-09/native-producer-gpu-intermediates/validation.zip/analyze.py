from pathlib import Path
import numpy as np,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;old=o.parent/'20261109-172812-native-receiver-gpu-oracle-d9e5ba'
expected=np.fromfile(old/'expected.u8',dtype='u1').astype('i4');actual=np.rint(np.fromfile(o/'filter-output.bin',dtype='<f4').reshape(-1,4)[:,2]*255).astype('i4');delta=abs(actual-expected)
q=np.fromfile(o/'native-filter-queries.bin',dtype='<f4').reshape(-1,3,4)[:,0,:3]
candidate=np.fromfile(o/'coordinates-output.bin',dtype='<f4').reshape(-1,4)[:,:3].copy()
prior=np.rint(np.fromfile(old/'receiver-output.bin',dtype='<f4').reshape(-1,4)[:,2]*255).astype('i4');priorDelta=abs(prior-expected)
pixels=np.fromfile(old/'pixels.bin',dtype='<u4').reshape(-1,2)
rows=[]
for i in np.where((priorDelta>1)|(delta>1))[0]:
 rows.append(dict(pixel=[int(pixels[i,0]),1439-int(pixels[i,1])],expected=int(expected[i]),reconstructedInputResult=int(prior[i]),measuredInputResult=int(actual[i]),nativeReceiver=q[i].tolist(),vulkanReceiver=candidate[i].tolist(),receiverDelta=(candidate[i]-q[i]).tolist()))
report=dict(status='diagnosed',samples=len(actual),measuredReceiverFilter=dict(exactPixels=int((delta==0).sum()),pixelsOverOneByte=int((delta>1).sum()),maximumByteError=int(delta.max())),reconstructedReceiverFilter=dict(exactPixels=int((priorDelta==0).sum()),pixelsOverOneByte=int((priorDelta>1).sum()),maximumByteError=int(priorDelta.max())),coordinateDifferences=dict(exactPixels=int(np.all(candidate==q,axis=1).sum()),maximumAbsolutePerComponent=abs(candidate-q).max(axis=0).tolist()),errorPoints=rows)
(o/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='errorPoints'},indent=2))
