from pathlib import Path
import hashlib,json,shutil,subprocess,sys,zipfile

root=Path.cwd().resolve();out=Path(__file__).resolve().parent
diag=out.parent/'20261109-092602-intel-first-frame-stability-fce74b'
sys.path.insert(0,str(root/'tools'))
from artifact_cleanup import remove_artifact
from artifact_maintenance import tracked_paths,write_json
from build_provenance import verify,digest

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return digest(p)
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
protected_hash=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],cwd=root)).hexdigest()
assert protected_hash=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8',protected_hash
builds={}
for config in ['release','debug']:
    p=root/('build/ninja-msvc-'+config)/'build-provenance.json'
    manifest=read(p);verify(root,manifest)
    builds[config]=dict(manifestSha256=sha(p),sourceCount=len(manifest['source']),productCount=len(manifest['products']),verified=True)
    shutil.copyfile(p,out/(config+'-final-build-provenance.json'))
assert all(all(v.values()) for v in read(out/'cpu-component-continuity.json').values())
image=read(out/'image-final-receiver-ranges/results.json')
assert len(image['frames'])==4 and all(f['changedPixels']==0 and f['sha256']==f['referenceSha256'] for f in image['frames'])
assert all(image[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationLogClean','zeroAllocator'])
gpu=read(out/'gpu-final.json')
assert len(gpu)==2 and all(r['execution']['exitCode']==0 and r['report']['status']=='passed' and r['report']['captures']==17 and r['report']['validationLayersVerified']==17 for r in gpu)
write_json(out/'final-verification.json',dict(builds=builds,protectedDiffSha256=protected_hash,cpuChecks=6,cpuProductsUnchangedAfterShaderFix=True,gpuCases=34,gpuFrames=38,originalFrames=4,originalChangedPixels=0,validationErrors=0,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review'))

evidence=root/'docs/acceptance/nr/evidence/2026-11-09'
def package(folder,name,include):
    destination=evidence/name;destination.mkdir(parents=True,exist_ok=True)
    target=destination/'validation.zip'
    selected=[p for p in sorted(folder.rglob('*')) if p.is_file() and include(p,p.relative_to(folder))]
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in selected:z.write(p,p.relative_to(folder).as_posix())
    assert target.stat().st_size<=8*1024*1024,(target,target.stat().st_size)
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        for p in selected:assert hashlib.sha256(z.read(p.relative_to(folder).as_posix())).hexdigest()==sha(p)
    return destination,dict(path=str(target.relative_to(root)),sha256=sha(target),bytes=target.stat().st_size,files=len(selected))

diag_source=diag/'fix-source';diag_source.mkdir(exist_ok=True)
for rel in ['shaders/mesh.frag','tools/test_character_local_light_gpu.py']:
    p=diag_source/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,p)
write_json(diag/'diagnosis.json',dict(status='resolved',cause='Scene cascade visibility consumed without an explicit surface directional owner in scene-lighting mode.',control='Disabling the unowned cascade makes the binding pair and static first-frame sequence byte-exact.',fix='Gate scene cascades by the existing mainLightDirection.w owner flag; retain legacy and explicit QA providers.',firstFrameWitness=dict(file='initial_frame0.rdc',sha256=sha(diag/'initial_frame0.rdc'),bytes=(diag/'initial_frame0.rdc').stat().st_size),finalGpuCases=34,firstFrameTolerance=0,originalFourFrameTolerance=0,formalPerformancePassed=False))
dd,dp=package(diag,'intel-cascade-owner',lambda p,r: not any(x in {'tmp','__pycache__'} for x in r.parts) and (p.suffix.lower() in {'.py','.cpp','.json','.log','.txt','.bin','.png','.frag'} or r.as_posix()=='initial_frame0.rdc'))
write_json(dd/'results.json',dict(**read(diag/'diagnosis.json'),package=dp,run=diag.name))

source=out/'final-source';source.mkdir(exist_ok=True)
for rel in ['CMakeLists.txt','src/render/ClusteredLightGrid.hpp','src/scenes/CharacterSceneRenderer.hpp','src/scenes/CharacterSceneRenderer.cpp','shaders/mesh.frag','shaders/unlit_blend.glsl','shaders/cluster_light_ranges.glsl','tests/ClusteredLightReceiverTests.cpp','tools/test_character_local_light_gpu.py']:
    p=source/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,p)
md,mp=package(out,'clustered-receiver-ranges',lambda p,r: not any(x in {'baseline-runtime','tmp','__pycache__'} for x in r.parts) and (p.suffix.lower() in {'.py','.cpp','.hpp','.glsl','.frag','.json','.csv','.jsonl','.log','.xml','.txt'} or r.as_posix()=='baseline-shader-source.zip'))
summary=dict(status='implemented-verified',baselineCommit='7ce992b',run=out.name,verification=read(out/'final-verification.json'),packet=read(out/'packet-size.json'),cost=read(out/'cost-results-v1.json'),costScope='Before cascade-owner fix; exact seven-file performance-source snapshot included. GPU delta close to reference drift; final formal gain unproven.',diagnosticEvidence=str((dd/'results.json').relative_to(root)),package=mp,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review')
write_json(md/'results.json',summary)

# Cleanup only explicitly owned, archived or reproducible task payloads.
tracked=tracked_paths(root);before=shutil.disk_usage(root).free;removed=[]
targets=[out/'baseline-runtime',out/'red.exe',out/'red.obj',out/'tmp',out/'__pycache__',diag/'tmp',diag/'memory.exe',diag/'memory.obj',diag/'initial-witness.zip']
targets += sorted(diag.glob('*.rdc'))
for image_dir in ['image-receiver-ranges','image-final-receiver-ranges']:
    result=read(out/image_dir/'results.json')
    byname={r['frame']:r for r in result['frames']}
    for p in (out/image_dir).glob('frames-*/*.png'):
        assert p.name in byname and sha(p)==byname[p.name]['sha256']==byname[p.name]['referenceSha256']
        targets.append(p)
for p in targets:
    if p.exists():
        size=remove_artifact(root/'build',p,tracked,apply=True)
        removed.append(dict(path=str(p),result=size))
after=shutil.disk_usage(root).free
cleanup=dict(removed=removed,freeBefore=before,freeAfter=after,observedFreedBytes=after-before,scope='Owned reproducible binaries, verified duplicate golden frames, verified archived diagnostic witness; current assets and source preserved.')
write_json(out/'closeout-cleanup.json',cleanup)
write_json(md/'cleanup.json',cleanup)
print(json.dumps(dict(mainPackage=mp,diagnosticPackage=dp,freeBytes=after,observedFreedBytes=after-before,removedTargets=len(removed),verification=read(out/'final-verification.json')),indent=2))
