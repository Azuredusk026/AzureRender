from pathlib import Path
import os,sys,json,re,importlib.util
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
os.environ.update(managed_environment(o/'tmp'))
if '--inside' in sys.argv:
 import test_character_local_light_gpu as local
 import test_character_color_blend_gpu as blend
 import emission_gpu
 folder=o/('gpu-final-'+sys.argv[-1]);folder.mkdir()
 player=r/'build/ninja-msvc-release/AzurePlayer.exe'
 local.run(player,folder/'local',['front','fixed','no-receiver','pbr-zero-box','pbr-positive-box'],'disabled')
 blend.run(player,folder/'blend',['single','fixed','two-layers','reverse-layers','projected','no-receiver','pbr','pbr-control'],'disabled')
 emission=emission_gpu.run(player,folder/'emission')
 logs=list(folder.glob('*/*/player.log'));assert len(logs)==17
 for p in logs:assert re.search(r'Insert.*VK_LAYER_KHRONOS_validation',p.read_text(),re.I)
 report=dict(status='passed',captures=17,emission=emission,local=json.loads((folder/'local/summary.json').read_text()),blend=json.loads((folder/'blend/summary.json').read_text()),validationLayersVerified=len(logs));(folder/'results.json').write_text(json.dumps(report,indent=2))
else:
 rows=[]
 for device,driver in [('intel','*igvk64*'),('nvidia','*nv-vk64*')]:
  os.environ['VK_LOADER_DRIVERS_SELECT']=driver;os.environ['VK_INSTANCE_LAYERS']='VK_LAYER_KHRONOS_validation';os.environ.pop('VK_LAYER_ENABLES',None);os.environ['VK_LAYER_VALIDATE_SYNC']='1';os.environ['VK_LOADER_DEBUG']='error,layer'
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
  result=guarded_run(r/'build',o.name,[sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',device],450);(o/('gpu-final-'+device+'-execution.json')).write_text(json.dumps(result,indent=2));assert result['exitCode']==0,result
  rows.append(dict(device=device,execution=result,report=json.loads((o/('gpu-final-'+device)/'results.json').read_text())))
 (o/'gpu-final.json').write_text(json.dumps(rows,indent=2));print('Two devices: seventeen final receiver and composition cases passed',flush=True)
