from pathlib import Path
import os,sys,json,re,shutil
import numpy as np
from PIL import Image
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
from build_provenance import digest
os.environ.update(managed_environment(o/'tmp'));os.environ['PATH']=str(r/'build/ninja-msvc-release')+';'+os.environ['PATH'];os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*';os.environ['VK_INSTANCE_LAYERS']='VK_LAYER_KHRONOS_validation';os.environ['VK_LAYER_VALIDATE_SYNC']='1';os.environ['VK_LOADER_DEBUG']='error,layer';os.environ.pop('VK_LAYER_ENABLES',None)
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
images={};rows=[]
for name in ['front','fixed']:
 source=o/'gpu-intel/local'/name;folder=o/'intel-no-cascade'/name;folder.mkdir(parents=True)
 command=json.loads((source/'command.json').read_text());command[0]=str(r/'build/ninja-msvc-release/AzurePlayer.exe');command[command.index('--capture-dir')+1]=str(folder/'frames');command+=['--resource-root',str(r/'build/ninja-msvc-release')]
 command[command.index('--capture-frames')+1]='2';command+=['--qa-effect','shadow','--qa-effect-state','disabled']
 result=guarded_run(r/'build',o.name,command,120);shutil.copyfile(o/'process.log',folder/'player.log');assert result['exitCode']==0
 log=(folder/'player.log').read_text();assert re.search(r'Insert.*VK_LAYER_KHRONOS_validation',log,re.I) and not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log)
 image=np.array(Image.open(folder/'frames/frame_000000.png'));images[name]=image;candidate=np.array(Image.open(source/'frames/frame_000000.png'));delta=np.abs(image.astype('i2')-candidate.astype('i2'))
 nextFrame=np.array(Image.open(folder/'frames/frame_000001.png'));temporalDelta=np.abs(image.astype('i2')-nextFrame.astype('i2'))
 rows.append(dict(name=name,initialVsNextChangedPixels=int(np.count_nonzero(np.any(temporalDelta,axis=2))),baselineVsCandidateChangedPixels=int(np.count_nonzero(np.any(delta,axis=2))),maximumByteDifference=int(delta.max()),baselineSha256=digest(folder/'frames/frame_000000.png'),candidateSha256=digest(source/'frames/frame_000000.png')))
delta=np.abs(images['front'].astype('i2')-images['fixed'].astype('i2'));report=dict(baselinePairChangedPixels=int(np.count_nonzero(np.any(delta,axis=2))),baselinePairMaximumByteDifference=int(delta.max()),rows=rows)
(o/'intel-no-cascade.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
