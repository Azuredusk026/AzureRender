from pathlib import Path
import os,sys,json,traceback
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
os.environ.update(managed_environment(o/'tmp'))
if '--inside' in sys.argv:
 import test_character_color_blend_gpu as blend
 import emission_gpu
 folder=o/'gpu-intel';player=r/'build/ninja-msvc-release/AzurePlayer.exe';report={}
 try:
  blend.run(player,folder/'blend',['single','fixed','two-layers','reverse-layers','projected','no-receiver','pbr','pbr-control'],'disabled');report['blend']='passed'
 except Exception:report['blend']='failed';report['blendError']=traceback.format_exc()
 try:report['emission']=dict(status='passed',captures=emission_gpu.run(player,folder/'emission-v3'))
 except Exception:report['emission']=dict(status='failed',error=traceback.format_exc())
 report['openStrictLocalComparison']=json.loads((folder/'local/summary.json').read_text())
 (folder/'remaining-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
 raise SystemExit(0 if report['blend']=='passed' and report['emission']['status']=='passed' else 1)
else:
 os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*';os.environ['VK_INSTANCE_LAYERS']='VK_LAYER_KHRONOS_validation';os.environ.pop('VK_LAYER_ENABLES',None);os.environ['VK_LAYER_VALIDATE_SYNC']='1';os.environ['VK_LOADER_DEBUG']='error,layer'
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
 result=guarded_run(r/'build',o.name,[sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],450);(o/'gpu-intel-remaining-execution.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
