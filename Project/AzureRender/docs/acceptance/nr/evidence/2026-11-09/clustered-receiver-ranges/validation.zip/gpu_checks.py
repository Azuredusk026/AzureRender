from pathlib import Path
import os,sys,json,re
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
os.environ.update(managed_environment(o/'tmp'))
if '--inside' in sys.argv:
 import test_character_local_light_gpu as local
 import test_character_color_blend_gpu as blend
 import emission_gpu
 folder=o/('gpu-'+sys.argv[-1]);folder.mkdir(exist_ok=True)
 player=r/'build/ninja-msvc-release/AzurePlayer.exe'
 if not (folder/'local/summary.json').exists() or json.loads((folder/'local/summary.json').read_text())['status']!='passed':local.run(player,folder/'local',['front','fixed','no-receiver','pbr-zero-box','pbr-positive-box'],'disabled')
 if not (folder/'blend/summary.json').exists() or json.loads((folder/'blend/summary.json').read_text())['status']!='passed':blend.run(player,folder/'blend',['single','fixed','two-layers','reverse-layers','projected','no-receiver','pbr','pbr-control'],'disabled')
 emission=emission_gpu.run(player,folder/'emission-v3')
 logs=[p for name in ['local','blend','emission-v3'] for p in (folder/name).glob('*/player.log')];assert len(logs)==17
 for path in logs:assert re.search(r'Insert.*VK_LAYER_KHRONOS_validation',path.read_text(),re.I),str(path)
 (folder/'results.json').write_text(json.dumps(dict(status='passed',captures=17,emission=emission,validationLayersVerified=len(logs)),indent=2))
else:
 rows=[]
 for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  os.environ['VK_LOADER_DRIVERS_SELECT']=driver;os.environ['VK_INSTANCE_LAYERS']='VK_LAYER_KHRONOS_validation';os.environ.pop('VK_LAYER_ENABLES',None);os.environ['VK_LAYER_VALIDATE_SYNC']='1';os.environ['VK_LOADER_DEBUG']='error,layer'
  for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
  result=guarded_run(r/'build',o.name,[sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',device],450)
  (o/('gpu-'+device+'-execution.json')).write_text(json.dumps(result,indent=2));assert result['exitCode']==0,result
  rows.append(dict(device=device,execution=result,report=json.loads((o/('gpu-'+device)/'results.json').read_text())))
 (o/'gpu-checks.json').write_text(json.dumps(rows,indent=2));print('Two devices: seventeen receiver and composition cases each passed',flush=True)
