from pathlib import Path
import os,sys,json,subprocess,time
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
os.environ.update(managed_environment(o/'tmp'))
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside',*sys.argv[1:]],env=env).returncode)
mode=sys.argv[-1];start=time.monotonic()
if mode in ['red','local']:
 with (o/(mode+'-build.log')).open('wb') as log:subprocess.run(['cl','/nologo','/std:c++17','/EHsc','/O2','/I'+str(r/'src'),str(r/'tests/ClusteredLightReceiverTests.cpp'),'/Fo'+str(o/'red.obj'),'/Fe'+str(o/'red.exe'),'/link','/INCREMENTAL:NO'],stdout=log,stderr=subprocess.STDOUT,check=True)
 p=subprocess.run([str(o/'red.exe')],capture_output=True);(o/(mode+'-test.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==(1 if mode=='red' else 0);print((o/(mode+'-test.log')).read_text(),flush=True)
else:
 assert mode in ['Release','Debug'];b=r/('build/ninja-msvc-'+mode.lower());command=[sys.executable,'-X','utf8','tools/build_provenance.py','build','--build-dir',str(b),'--config',mode]
 for target in ['AzureRenderClusteredLightGridTests','AzureRenderLightBufferTests','AzureRenderClusteredLightReceiverTests']:command+=['--test-target',target]
 with (o/(mode.lower()+'-build.log')).open('wb') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 (o/(mode.lower()+'-build.json')).write_text(json.dumps(dict(exitCode=p.returncode,seconds=time.monotonic()-start,command=command),indent=2));print(mode,p.returncode,flush=True);raise SystemExit(p.returncode)
