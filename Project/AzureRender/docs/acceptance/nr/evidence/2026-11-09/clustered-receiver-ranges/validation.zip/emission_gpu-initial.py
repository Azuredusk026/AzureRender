from pathlib import Path
import json,subprocess,re
import numpy as np
from PIL import Image
from native_render.light_lab import generate
from test_unlit_texture_layers_gpu import profile
from test_npr_diffuse_gpu import linear

def run(player,output):
 output.mkdir(parents=True,exist_ok=False);rows=[]
 for name in ['surface-opaque','character-opaque','surface-blend','character-blend','character-blend-fixed']:
  print(name,flush=True);folder=output/name;generate(folder,'point')
  Image.new('RGBA',(1,1),(255,255,255,255)).save(folder/'white.png')
  p=profile();p['tint']=[.2,.4,.6,1];p['softIntersection']['enabled']=False;p['colorBlendResponse']='attenuate-emission'
  path=folder/'plane.gltf';model=json.loads(path.read_text());model['images']=[dict(uri='white.png')];model['textures']=[dict(source=0)]
  material=dict(alphaMode='OPAQUE' if name.endswith('opaque') else 'BLEND',doubleSided=True,extras=dict(azureRenderMaterial=dict(schemaVersion=2,**{'class':'generic'},features=['unlit-surface','unlit-texture-layers'],surface=p)))
  model['materials']=[material];path.write_text(json.dumps(model))
  path=folder/'level.azurelevel';level=json.loads(path.read_text());level['nodes'][2]['components']['azure.transform']['data']['translation']=[.03125,-.03125,0]
  light=level['lights'][0];light.update(radius=2,intensity=1,color=[.9,.8,.7]);light['shape'].update(type='point',falloff='range-power',falloffExponent=2,receivers=dict(schemaVersion=1,surfaces=name.startswith('surface'),characters=name.startswith('character')),characterResponse=dict(schemaVersion=3,composition='color-blend',strength=.7,facingWeight=0,projectedDistance=False,order=0))
  level['renderSettings']['nprLighting']=dict(schemaVersion=1,enabled=True,ambientColor=[0,0,0],ambientDirection=[0,1,0],directionBias=0,directionGain=0,directionFloor=1,outdoorGain=1,shadowAmbientGain=1,indoorMix=0,litAmbientMix=0,mainColorMix=0,shadowOverride=1,useSceneIrradiance=False)
  path.write_text(json.dumps(level));command=[str(player),'--project',str(folder/'lab.azureproject'),'--width','128','--height','128','--capture-dir',str(folder/'frames'),'--capture-frames','1','--fixed-frame-step','--qa-camera','scene','--qa-light','scene']
  if name.endswith('fixed'):command+=['--disable-bindless','--disable-compute-skinning','--disable-parallel-recording']
  (folder/'command.json').write_text(json.dumps(command,indent=2))
  with (folder/'player.log').open('w',encoding='utf-8') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
  log=(folder/'player.log').read_text();assert re.search(r'Insert.*VK_LAYER_KHRONOS_validation',log,re.I) and not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]',log)
  assert 'Allocator after unload: buffers=0 images=0' in log
  image=np.asarray(Image.open(folder/'frames/frame_000000.png').convert('RGB'));measured=linear(image[64,64]);expected=np.array([.2,.4,.6])*(.3 if name.startswith('character') else 1);error=float(np.max(np.abs(measured-expected)))
  rows.append(dict(name=name,measured=measured.tolist(),expected=expected.tolist(),maximumLinearError=error));(output/'summary.json').write_text(json.dumps(dict(captures=rows),indent=2));assert error<=.008,(name,measured,expected,error)
 return rows
