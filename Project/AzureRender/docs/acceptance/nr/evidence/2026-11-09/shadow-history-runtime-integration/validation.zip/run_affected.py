from pathlib import Path
import os,json,sys,re,shutil,xml.etree.ElementTree as ET
root=Path.cwd();out=Path(__file__).resolve().parent;config=sys.argv[1];build=root/('build/ninja-msvc-'+config.lower())
sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import guarded_run,managed_environment
from shared_resources import lease
os.environ.update(managed_environment(out/'tmp'));os.environ['PATH']=str(build)+';'+os.environ['PATH']
os.environ['VK_INSTANCE_LAYERS']='VK_LAYER_KHRONOS_validation';os.environ['VK_LAYER_VALIDATE_SYNC']='1'
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(key,None)
selected=json.loads((out/'affected-tests.json').read_text());reports=[]
mode=sys.argv[2] if len(sys.argv)>2 else 'all'
schedule=[('nvidia','*nv-vk64*',False),('intel','*igvk64*',True)]
if mode=='intel':schedule=schedule[1:]
if mode=='prefill':schedule=[('prefill','*nv-vk64*',False)]
ctest='D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
with lease(Path('D:/Projects/FYP-coordination/resources'),os.environ['CODEX_THREAD_ID'],'history-default-'+config.lower()+'-checks',out):
 for device,driver,gpu in schedule:
  os.environ['VK_LOADER_DRIVERS_SELECT']=driver
  tests=[t['name'] for t in selected if not gpu or 'gpu' in t['labels']]
  if mode=='prefill':tests=['AzureRender.DepthPrefillRecording']
  label='default-'+config.lower()+'-'+device
  command=[ctest,'--test-dir',str(build),'-R','^('+'|'.join(re.escape(n) for n in tests)+')$','--output-on-failure','--output-junit',str(out/(label+'.xml'))]
  result=guarded_run(root/'build',out.name,command,600)
  shutil.copyfile(out/'process.log',out/(label+'.log'));xml=ET.parse(out/(label+'.xml')).getroot()
  report=dict(config=config,device=device,execution=result,tests=int(xml.get('tests',0)),failures=int(xml.get('failures',0)),skipped=sum(len(t.findall('skipped')) for t in xml.iter('testcase')))
  reports.append(report);print(json.dumps(report),flush=True)
  assert result['exitCode']==0 and report['tests']==len(tests) and report['failures']==0
(out/('default-'+config.lower()+'-'+mode+'-checks.json')).write_text(json.dumps(reports,indent=2))
