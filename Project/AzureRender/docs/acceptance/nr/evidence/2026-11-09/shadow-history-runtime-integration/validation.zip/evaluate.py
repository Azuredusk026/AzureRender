from pathlib import Path
import json,sys,os,shutil,time
root=Path.cwd(); out=Path(__file__).resolve().parent; sys.path.insert(0,str(root/'tools'))
from artifact_maintenance import guarded_run,managed_environment
from shared_resources import lease
from build_provenance import digest,inputs,verify
os.environ.update(managed_environment(out/'tmp'))
build=root/'build/ninja-msvc-release'
mode=sys.argv[1]
def run(name,command,timeout=120):
 with lease(Path('D:/Projects/FYP-coordination/resources'),os.environ['CODEX_THREAD_ID'],name,out):
  result=guarded_run(root/'build',out.name,list(map(str,command)),timeout)
 shutil.copyfile(out/'process.log',out/(name+'.log'))
 (out/(name+'.json')).write_text(json.dumps(result,indent=2))
 print(name,result['exitCode'],flush=True)
 return result
if mode=='checks':
 results=[]
 for target in ['AzureShadowHistoryRuntimePolicyTests','AzureShadowHistoryPolicyTests','AzureShadowHistoryCacheTests','AzureMaterialClassEarlyDepthTests','AzureMaterialFacingDemandTests','AzureShadowHistoryRecordingTests']:
  command=[build/(target+'.exe')]
  if target in ['AzureMaterialClassEarlyDepthTests','AzureMaterialFacingDemandTests','AzureShadowHistoryRecordingTests']:command += [build/'shaders']
  if target=='AzureShadowHistoryRecordingTests':command += [root]
  results.append(run(target,command))
 for label,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
  os.environ['VK_LOADER_DRIVERS_SELECT']=driver
  os.environ['VK_INSTANCE_LAYERS']='VK_LAYER_KHRONOS_validation';os.environ['VK_LAYER_VALIDATE_SYNC']='1'
  results.append(run('history-gpu-'+label,[build/'AzureShadowHistoryCacheGpuTests.exe',build/'shaders']))
 (out/'check-results.json').write_text(json.dumps(results,indent=2))
 assert all(r['exitCode']==0 and r['status']=='exited' for r in results)
elif mode=='capture':
 import numpy as np
 from PIL import Image
 before=inputs(root);verify(root,json.loads((build/'build-provenance.json').read_text()))
 ref=root/'build/runs/20261103-234012-character-reference-stages-5abe6c/snapshot-shell-order-regression/release-joint'
 lock=json.loads((root/'build/runs/20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text())
 assert all(digest(Path(p))==sha for p,sha in lock.items())
 command=json.loads((ref/'command.json').read_text());command[0]=str(build/'AzurePlayer.exe')
 frames=out/'frames-qualified';command[command.index('--capture-dir')+1]=str(frames);command[command.index('--runtime-report')+1]=str(out/'runtime.json')
 command+=['--resource-root',str(build)]
 os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['VK_INSTANCE_LAYERS']='VK_LAYER_KHRONOS_validation';os.environ['VK_LAYER_VALIDATE_SYNC']='1';os.environ['VK_LOADER_DEBUG']='error,layer'
 os.environ['PATH']=str(build)+';'+os.environ['PATH']
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','AZURE_CPU_WORK_REPORT']:os.environ.pop(key,None)
 result=run('native-capture',command,600)
 rows=[]
 for path in sorted(frames.glob('frame_*.png')):
  a=np.asarray(Image.open(path).convert('RGB'));b=np.asarray(Image.open(ref/'frames'/path.name).convert('RGB'));d=np.abs(a.astype('i2')-b.astype('i2'))
  rows.append(dict(frame=path.name,changedPixels=int(np.count_nonzero(np.any(d,axis=2))),maximumByteDifference=int(d.max()),sha256=digest(path)))
 manifest=json.loads((frames/'capture_manifest.json').read_text()) if (frames/'capture_manifest.json').exists() else {}
 log=(out/'native-capture.log').read_text(errors='replace')
 report=dict(execution=result,frames=rows,metadata={k:v for k,v in manifest.items() if k.startswith('shadowHistory')},validationClean=not any(v in log for v in ['Validation Error:','Validation Warning:','SYNC-HAZARD','VUID-']),allocatorZero='Allocator after unload: buffers=0 images=0' in log,sourceUnchanged=inputs(root)==before,projectInputsUnchanged=all(digest(Path(p))==sha for p,sha in lock.items()))
 (out/'capture-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
 assert report['metadata'].get('shadowHistoryPrepared') and report['metadata'].get('shadowHistorySampledRequests',0)>0, 'Actual history consumer is required'
 assert result['exitCode']==0 and len(rows)==4 and all(r['changedPixels']==0 for r in rows)
 assert all(report[k] for k in ['validationClean','allocatorZero','sourceUnchanged','projectInputsUnchanged'])
