from pathlib import Path
import json,subprocess,sys,shutil,os
out=Path(__file__).resolve().parent;config=sys.argv[1];os.environ['CMAKE_BUILD_PARALLEL_LEVEL']='3'
command=[sys.executable,'-B','tools/build_provenance.py','build','--build-dir','build/ninja-msvc-'+config.lower(),'--config',config]
for target in json.loads((out/'affected-targets.json').read_text()):command+=['--test-target',target]
subprocess.run(command,check=True)
shutil.copyfile(Path('build/ninja-msvc-'+config.lower())/'build-provenance.json',out/('default-'+config.lower()+'-provenance.json'))
