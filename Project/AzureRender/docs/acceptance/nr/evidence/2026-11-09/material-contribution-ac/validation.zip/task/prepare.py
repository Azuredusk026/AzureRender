from pathlib import Path
import os,sys,json,subprocess,zipfile,hashlib
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment
from build_provenance import inputs,digest,verify
from gpu_environment import snapshot
os.environ.update(managed_environment(o/'tmp'))
environment=snapshot();environment.pop('rawXml',None);assert environment['hostPower']['acLineStatus']==1 and not any(v is True for v in environment['thermalSlowdown'].values())
(o/'preflight-environment.json').write_text(json.dumps(environment,indent=2))
for c in ['release','debug']:verify(r,json.loads((r/('build/ninja-msvc-'+c)/'build-provenance.json').read_text()))
(o/'source-freeze.json').write_text(json.dumps(inputs(r),indent=2))
old=r/'build/runs/20261107-122133-material-contribution-cost-c567b5';capture=r/'build/runs/20261107-120731-uniform-texture-index-capture-4c96ea'
state=json.loads((capture/'state.json').read_text());assert digest(Path(state['capture']))==state['captureSha256']
(o/'capture.json').write_text(json.dumps(state,indent=2))
with zipfile.ZipFile(r/'docs/acceptance/nr/evidence/2026-11-07/material-contribution-cost/diagnosis.zip') as z:
 profile=json.loads(z.read('profile.json'));oldBuilds=json.loads(z.read('control-builds.json'))
 for kind in ['surface-shadow','irradiance','reflection-field','direct-lights']:
  for name in [kind+'/mesh.frag']+([kind+'/reflection_probe_field.glsl'] if kind=='reflection-field' else []):
   p=o/name;p.parent.mkdir(exist_ok=True);p.write_bytes(z.read(name))
(o/'profile.json').write_text(json.dumps(profile,indent=2))
source=o/'source';source.mkdir()
names=subprocess.check_output(['git','ls-tree','--full-tree','-r','--name-only','ce9616f','--','Project/AzureRender/shaders'],text=True).splitlines()
assert 50<len(names)<1024
for name in names:
 rel=Path(name).relative_to('Project/AzureRender/shaders')
 if rel.suffix not in ['.glsl','.frag','.vert','.comp']:continue
 p=source/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show','ce9616f:'+name]))
selected={x['file']:x for x in oldBuilds if x['control']=='surface-shadow'};assert len(selected)==11
expected={v['programFile']:v['sha256'] for v in profile['shaders'].values() if v['programFile'] in selected}
rows=[]
for kind in ['baseline','surface-shadow','irradiance','reflection-field','direct-lights']:
 folder=o/kind;folder.mkdir(exist_ok=True)
 for name,oldBuild in selected.items():
  defines=[x for x in oldBuild['command'] if x.startswith('-D')]
  shader=source/'mesh.frag' if kind=='baseline' else folder/'mesh.frag'
  command=['D:/Tools/VulkanSDK/1.4.350.0/Bin/glslc.exe',*defines,'-I'+str(folder),'-I'+str(source),str(shader),'-o',str(folder/name)]
  p=subprocess.run(command,capture_output=True,text=True);assert p.returncode==0,p.stderr
  sha=digest(folder/name);matches=sha==expected[name] if kind=='baseline' else sha==digest(old/kind/name)
  row=dict(control=kind,file=name,sha256=sha,reproducesRecordedProgram=matches,command=command);rows.append(row)
  (o/'builds.json').write_text(json.dumps(rows,indent=2))
  assert matches,(kind,name,sha,expected.get(name))
 print(kind,'11 programs reproduced exactly',flush=True)
