from pathlib import Path
import os,sys,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,guarded_run
from build_provenance import inputs,digest,verify
from gpu_environment import RunEnvironmentMonitor
os.environ.update(managed_environment(o/'tmp'));os.environ['AZURE_REPLAY_TASK']=str(o)
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES']:os.environ.pop(key,None)
os.environ['RENDERDOC_DEBUG_LOG_FILE']=str(o/'tmp/renderdoc.log')
os.environ['RDOC_DEBUG_LOG_FILE']=str(o/'tmp/renderdoc.log')
before=inputs(r);assert before==json.loads((o/'source-freeze.json').read_text())
products={str(p):digest(p) for p in [r/'build/ninja-msvc-release/AzurePlayer.exe',*sorted((r/'build/ninja-msvc-release/shaders').glob('*.spv'))]}
command=['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(o/'measure.py')]
environment={}
with RunEnvironmentMonitor(environment,path=o/'environment.json',interval=2):result=guarded_run(r/'build',o.name,command,300)
(o/'execution.json').write_text(json.dumps(result,indent=2));assert inputs(r)==before and all(digest(Path(p))==sha for p,sha in products.items())
measurement=json.loads((o/'measurement.json').read_text());print(json.dumps({k:v for k,v in measurement.items() if k not in ['roles','telemetry']},indent=2),flush=True)
assert result['status']=='exited' and result['exitCode']==0 and measurement['status']=='measured'
