from pathlib import Path
import os,sys,json,zipfile,subprocess,hashlib,shutil,re
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import managed_environment,tracked_paths,write_json,measure
from artifact_cleanup import remove_artifact
from build_provenance import inputs,digest,verify
os.environ.update(managed_environment(o/'tmp'));assert inputs(r)==json.loads((o/'source-freeze.json').read_text())
for c in ['release','debug']:verify(r,json.loads((r/('build/ninja-msvc-'+c)/'build-provenance.json').read_text()))
m=json.loads((o/'measurement.json').read_text());assert m['status']=='measured' and len(m['summary'])==4 and all(x['qualified'] for x in m['summary'])
env=json.loads((o/'environment.json').read_text());obs=env['runObservations'];assert len(obs)==37 and not env['monitorErrors'] and all(x['hostPower']['acLineStatus']==1 and not any(v is True for v in x['thermalSlowdown'].values()) for x in obs)
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
diff=subprocess.check_output(['git','diff','--binary','--',*protected],stderr=subprocess.DEVNULL);assert hashlib.sha256(diff).hexdigest()=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
e=r/'docs/acceptance/nr/evidence/2026-11-09/material-contribution-ac';e.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(e/'validation.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(o.rglob('*')):
  if p.is_file() and 'tmp' not in p.relative_to(o).parts:archive.write(p,'task/'+p.relative_to(o).as_posix())
assert (e/'validation.zip').stat().st_size<8*2**20
tracked=tracked_paths(r);before=shutil.disk_usage(r).free;cleanup=[]
for name in ['source','baseline','surface-shadow','irradiance','reflection-field','direct-lights','tmp']:
 p=o/name
 if p.exists():
  size,_=remove_artifact(r/'build',p,tracked,apply=True);cleanup.append(dict(path=str(p),logicalBytes=size))
after=shutil.disk_usage(r).free
report=dict(status='qualified-historical-cost-bounds',run=o.name,productionCommit='d388d2d',historicalShaderSource='ce9616f',capture=json.loads((o/'capture.json').read_text()),programsReproduced=55,matchedDraws=m['matchedDraws'],summary=m['summary'],stableRoleCount=len(m['roles']),measuredSweeps=sum(x['sweeps'] for x in m['roles']),untimedWarmReplays=sum(x['untimedWarmReplays'] for x in m['roles']),environment=dict(observations=len(obs),acStates=[1],monitorErrors=[],thermalSlowdownObserved=False,powerLimitMinimumWatts=min(x['powerLimitWatts'] for x in obs),powerLimitMaximumWatts=max(x['powerLimitWatts'] for x in obs)),initialAttempt=dict(status='rejected-instability',measuredSweeps=19,source='first-measurement.json'),productionSourceUnchanged=True,shadersUnchangedPerConfiguration=675,newNativeRuns=0,formalPerformancePassed=False,visualStatus='failed-user-review',protectedUserDiffSha256=hashlib.sha256(diff).hexdigest(),cleanup=cleanup,cleanupLogicalBytes=sum(x['logicalBytes'] for x in cleanup),freeBytesBeforeCleanup=before,freeBytesAfterCleanup=after,actualFreedBytes=after-before,remainingRunBytes=measure(o),archiveBytes=(e/'validation.zip').stat().st_size,archiveSha256=digest(e/'validation.zip'),next='Review active direct-light workload, including exact receiver qualification and specular work; retain shadow controls as compiler-inclusive bounds')
write_json(e/'results.json',report);write_json(o/'results.json',report)
for name in ['docs/acceptance/nr/material-contribution-ac.md','docs/acceptance/nr/material-contribution-cost.md','docs/plans/2026-11-07-material-contribution-cost.md','docs/plans/azure-engine-plan.md']:
 p=r/name
 for link in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://' not in link and not link.startswith('#'):assert (p.parent/link.split('#')[0]).exists(),(name,link)
print(json.dumps({k:report[k] for k in ['status','cleanupLogicalBytes','actualFreedBytes','remainingRunBytes','archiveBytes']},indent=2))
