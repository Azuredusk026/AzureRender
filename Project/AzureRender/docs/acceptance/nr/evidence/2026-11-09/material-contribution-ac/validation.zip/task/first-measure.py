from pathlib import Path
import os,sys,json,hashlib,traceback,time,statistics
import renderdoc as rd
r=Path('D:/Projects/FYP/Project/AzureRender');o=Path(os.environ['AZURE_REPLAY_TASK']);sys.path.insert(0,str(r/'tools'))
from gpu_environment import snapshot
report=dict(status='starting',scope='Historical exact-source component ablation under restored AC; output-changing controls are cost bounds, not compatible optimizations or native performance',roles=[],telemetry=[],maximumWarmupSweeps=16,stabilityFraction=.03)
cap=None;c=None;original={};compiled={};phase='initialization';exitCode=1
def save():(o/'measurement.json').write_text(json.dumps(report,indent=2))
def observe():
 s=snapshot();s.pop('rawXml',None)
 if s['hostPower']['acLineStatus']!=1 or any(v is True for v in s['thermalSlowdown'].values()):raise RuntimeError('AC or thermal condition changed')
 return s
def role(name):
 previous=[]
 for attempt in range(16):
  values={int(v.eventId):float(v.value.d)*1000 for v in c.FetchCounters([rd.GPUCounter.EventGPUDuration])}
  assert len(values)>3000 and all(v>=0 for v in values.values())
  total=sum(values.values());matchedTotal=sum(v for k,v in values.items() if k in matched)
  sample=dict(attempt=attempt,allEventMs=total,matchedEventMs=matchedTotal,values=values)
  previous.append(sample);report['telemetry'].append(dict(role=name,attempt=attempt,totalMs=total,matchedMs=matchedTotal,environment=observe()));save()
  if len(previous)>=3:
   recent=previous[-3:];totals=[x['allEventMs'] for x in recent];draws=[x['matchedEventMs'] for x in recent]
   if min(totals)>0 and max(totals)/min(totals)<=1.03 and min(draws)>0 and max(draws)/min(draws)<=1.03:
    result=dict(name=name,sweeps=len(previous),samples=recent,allEventMs=statistics.mean(totals),matchedEventMs=statistics.mean(draws))
    report['roles'].append(result);save();print(name,result['matchedEventMs'],flush=True);return result
 raise RuntimeError('Role failed to stabilize within sixteen bounded sweeps: '+name)
try:
 try:pyrenderdoc.Config().Close()
 except (AttributeError,NameError):pass
 state=json.loads((o/'capture.json').read_text());profile=json.loads((o/'profile.json').read_text());builds=json.loads((o/'builds.json').read_text())
 assert len(builds)==55 and all(x['reproducesRecordedProgram'] for x in builds)
 files={x['file'] for x in builds};shaders={k:v for k,v in profile['shaders'].items() if v['programFile'] in files}
 cap=rd.OpenCaptureFile();assert cap.OpenFile(state['capture'],'',None)==rd.ResultCode.Succeeded
 status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
 for kind in ['surface-shadow','irradiance','reflection-field','direct-lights']:compiled[kind]={}
 for key,entry in shaders.items():
  event=next(x['event'] for x in profile['rows'] if x['fragment']==key);c.SetFrameEvent(event,True);p=c.GetPipelineState();reflection=p.GetShaderReflection(rd.ShaderStage.Pixel)
  assert hashlib.sha256(bytes(reflection.rawBytes)).hexdigest()==entry['sha256'];original[key]=p.GetShader(rd.ShaderStage.Pixel)
  for kind in compiled:
   code=(o/kind/entry['programFile']).read_bytes();program,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,code,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
   assert program!=rd.ResourceId.Null(),errors;compiled[kind][key]=program
 matched={x['event'] for x in profile['rows'] if x['fragment'] in shaders};assert len(matched)==1009
 report.update(status='measuring',captureSha256=state['captureSha256'],matchedDraws=len(matched),originalShaders=len(original));save();baseline=role('baseline-before')
 report['summary']=[]
 for kind,programs in compiled.items():
  for key,program in programs.items():c.ReplaceResource(original[key],program)
  candidate=role(kind)
  for shader in original.values():c.RemoveReplacement(shader)
  after=role('baseline-after-'+kind)
  beforeMs=baseline['matchedEventMs'];afterMs=after['matchedEventMs'];bm=(beforeMs+afterMs)/2;cm=candidate['matchedEventMs'];drift=abs(beforeMs-afterMs)/bm
  result=dict(control=kind,baselineBeforeMs=beforeMs,baselineAfterMs=afterMs,baselineMeanMs=bm,candidateMeanMs=cm,savedMs=bm-cm,reductionFraction=1-cm/bm,referenceDriftFraction=drift,qualified=drift<=.05)
  report['summary'].append(result);save();print(json.dumps(result),flush=True)
  if drift>.05:raise RuntimeError('Reference bracket drift exceeded 5%; remaining controls deferred')
  baseline=after
 report.update(status='measured',formalPerformancePassed=False,newNativeRuns=0);save();exitCode=0
except BaseException:report.update(status='failed',error=traceback.format_exc());save()
finally:
 if c:
  for shader in original.values():
   try:c.RemoveReplacement(shader)
   except Exception:pass
  c.Shutdown()
 if cap:cap.Shutdown()
 save()
os._exit(exitCode)
