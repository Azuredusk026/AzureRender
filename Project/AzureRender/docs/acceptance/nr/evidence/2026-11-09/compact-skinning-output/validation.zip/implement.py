from pathlib import Path
r=Path.cwd()
(r/'src/render/SkinnedVertex.hpp').write_text('''#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
namespace azurerender {
struct GpuSkinnedVertex {
    std::array<float,3> position{},normal{};
    std::array<float,4> tangent{};
    static constexpr std::uint32_t wordCount=10;
};
static_assert(sizeof(GpuSkinnedVertex)==40&&offsetof(GpuSkinnedVertex,normal)==12&&offsetof(GpuSkinnedVertex,tangent)==24);
}
''')
(r/'shaders/skinned_vertex_layout.glsl').write_text('const uint azureSkinnedVertexWordCount=10u;\n')
for name in ['mesh.vert','outline.vert','shadow.vert']:
 p=r/'shaders'/name;s=p.read_text();needle='layout(std430, binding = 17) readonly buffer InstanceSkinnedVertices';assert needle in s
 s=s.replace(needle,'#include "skinned_vertex_layout.glsl"\n'+needle,1).replace('*27u+offset','*azureSkinnedVertexWordCount+offset');p.write_text(s)
p=r/'shaders/skin.comp';s=p.read_text();s=s.replace('#include "skin_position.glsl"','#include "skin_position.glsl"\n#include "skinned_vertex_layout.glsl"',1)
s=s.replace('(parameters.outputBase + instanceIndex * parameters.vertexCount + vertexIndex)*vertexWordCount','(parameters.outputBase + instanceIndex * parameters.vertexCount + vertexIndex)*azureSkinnedVertexWordCount')
old='''    for (uint word = 0u; word < vertexWordCount; ++word) {
        skinnedVertices.words[destination + word] = sourceVertices.words[base + word];
    }
''';assert old in s;s=s.replace(old,'')
a=s.index('    skinnedVertices.words[destination + 20u]');s=s[:a]+'    skinnedVertices.words[destination + 9u] = sourceVertices.words[base + 9u];\n}\n';p.write_text(s)
p=r/'src/scenes/CharacterSceneRenderer.cpp';s=p.read_text();s='#include "render/SkinnedVertex.hpp"\n'+s
s=s.replace('vertices+=mesh.vertices.size()*sizeof(AssetVertex)+mesh.vertexColors.size()*sizeof(std::array<float,4>);','vertices+=mesh.vertices.size()*sizeof(GpuSkinnedVertex);',1)
s=s.replace('VK_BUFFER_USAGE_STORAGE_BUFFER_BIT\n                |(i==1?VK_BUFFER_USAGE_VERTEX_BUFFER_BIT:0),i!=1','VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,i!=1',1)
s=s.replace('VK_BUFFER_USAGE_STORAGE_BUFFER_BIT\n                    | VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,','VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,',1)
s=s.replace('createOutputBuffers(static_cast<VkDeviceSize>(vertexCapacity_) * sizeof(AssetVertex), skinnedVertexBuffers_);','createOutputBuffers(static_cast<VkDeviceSize>(vertexCapacity_) * sizeof(GpuSkinnedVertex), skinnedVertexBuffers_);',1)
m='         << "  \\"computeSkinningPreparedVertices\\": "'.replace('\\\\','\\');lines=s.splitlines(keepends=True);at=next(i for i,l in enumerate(lines) if '<< preparedSkinningVertices' in l)
lines.insert(at+1,'         << "  \\"computeSkinningVertexWords\\": " << GpuSkinnedVertex::wordCount << ",\\n"\n'.replace('\\\\','\\'))
p.write_text(''.join(lines))
p=r/'tests/SkinningGpuTests.cpp';s=p.read_text();s='#include "render/SkinnedVertex.hpp"\n'+s;s=s.replace('number(9,1);','number(9,-1);');s=s.replace('81*sizeof(std::uint32_t)','32*sizeof(std::uint32_t)').replace('i<27','i<GpuSkinnedVertex::wordCount').replace('value(27)','value(10)').replace('value(54)','value(20)').replace('value(28)','value(11)').replace('value(55)','value(21)').replace('(instance+1)*27','(instance+1)*GpuSkinnedVertex::wordCount').replace('words+81','words+32').replace('normalized81words','normalized32words')
m='        if(!batched)baseline.assign(words,words+32);';add='''        for(unsigned i:{19U,29U})if(words[i]!=source[9])throw std::runtime_error("Tangent handedness bit pattern changed");
        for(unsigned i:{30U,31U})if(words[i]!=0xCDCDCDCDU)throw std::runtime_error("Compact output overwrote its trailing guard");
''';assert m in s;s=s.replace(m,add+m)
m='    cleanup.reset();';s=s.replace(m,'    host.allocator.invalidate(input,0,input.size);\n    if(std::memcmp(input.mapped,source.data(),sizeof(source))!=0)throw std::runtime_error("Immutable mesh source changed");\n'+m,1);p.write_text(s)
o=r/'build/runs/20261109-023357-compact-skinning-output-1c5f2c';old=r/'build/runs/20261109-022033-gpu-pass-attribution-89c3e2/build.py';s=old.read_text();s=s.replace("'--test-target','AzureRenderCommandLineTests','--test-target','AzureRenderRenderGraphTests'","'--test-target','AzureSkinningBatchTests','--test-target','AzureSkinningGpuTests','--test-target','AzureOutlineCoverageRecordingTests','--test-target','AzureMotionVectorPassTests'")
(o/'build.py').write_text(s)
