from pathlib import Path
import json,os,sys,csv,shutil
import numpy as np
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;build=root/'build/ninja-msvc-release';sys.path.insert(0,str(root/'tools'))
tag=sys.argv[1] if len(sys.argv)>1 else 'v1'
from build_provenance import inputs,digest,verify
from artifact_maintenance import guarded_run
from gpu_environment import RunEnvironmentMonitor
for key in ['TEMP','TMP','TMPDIR','SQLITE_TMPDIR']:os.environ[key]=str(out/'tmp')
image=json.loads((out/'image-compact-skinning/results.json').read_text());assert len(image['frames'])==4 and all(r['changedPixels']==0 for r in image['frames'])
assert image['metadata']['computeSkinningVertexWords']==10
assert 1-40/108>=.60
baseline=json.loads((out/'baseline-runtime.json').read_text());assert len(baseline['files'])==675
assert all(digest(Path(row['path']))==row['sha256'] for row in baseline['files'])
verify(root,json.loads((build/'build-provenance.json').read_text()));before=inputs(root)
products={str(p):digest(p) for p in [build/'AzurePlayer.exe',*sorted((build/'shaders').glob('*.spv'))]}
assert image['validationLogClean'] and image['zeroAllocator']
shutil.copyfile(build/'build-provenance.json',out/'cost-build-provenance.json')
(out/'cost-source-before.json').write_text(json.dumps(before,indent=2))
(out/'cost-products-before.json').write_text(json.dumps(products,indent=2))
lock=json.loads((out.parent/'20261108-101326-gpu-transparent-indices-8ef9c7/frozen-project-inputs.json').read_text());assert all(digest(Path(p))==sha for p,sha in lock.items())
project=out.parent/'20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject'
os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['PATH']=str(build)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','AZURE_CPU_WORK_REPORT']:os.environ.pop(key,None)
rows=[]
for label,exe in [('baseline-before',build/'AzurePlayer.exe'),('candidate',build/'AzurePlayer.exe'),('baseline-after',build/'AzurePlayer.exe')]:
 folder=out/('cost-'+tag+'-'+label);folder.mkdir(exist_ok=True);assert not (folder/'timing.json').exists()
 runtime=build if label=='candidate' else out/'baseline-runtime'
 exe=runtime/'AzurePlayer.exe'
 command=[str(exe),'--project',str(project),'--resource-root',str(runtime),'--width','1920','--height','1080','--qa-camera','scene','--qa-light','scene','--fixed-frame-step','--capture-fps','24','--smoke-frames','120','--gpu-timing','--gpu-timing-output',str(folder/'timing.json')]

 (folder/'command.json').write_text(json.dumps(dict(command=command,exeSha256=digest(exe)),indent=2))
 environment={}
 with RunEnvironmentMonitor(environment,path=folder/'environment.json',interval=2):
  execution=guarded_run(root/'build',out.name,command,300)
 shutil.copyfile(out/'process.log',folder/'process.log');(folder/'execution.json').write_text(json.dumps(execution,indent=2))
 assert execution['status']=='exited' and execution['exitCode']==0
 log=(folder/'process.log').read_text(errors='replace');assert 'Allocator after unload: buffers=0 images=0' in log and not any(s in log for s in ['Validation Error:','SYNC-HAZARD','VUID-'])
 data=json.loads((folder/'timing.json').read_text());samples=list(csv.DictReader((folder/'timing.csv').open()))
 selected=[r for r in samples if 61<=int(r['frame'])<=120];assert len(selected)==60
 assert [data['sceneWidth'],data['sceneHeight']]==[1920,1080], [data['sceneWidth'],data['sceneHeight']]
 if label=='candidate':assert data['computeSkinningVertexWords']==10 and data['computeSkinningOutputBytes']==data['vertexCapacity']*40*2
 assert data['conservativeOcclusionPrepared'] and data['mainDepthSplitRecorded']
 assert not data.get('surfaceRadiancePrepared',False)
 summary={name:dict(mean=float(np.mean([float(r[key]) for r in selected])),p95=float(np.percentile([float(r[key]) for r in selected],95))) for name,key in [('gpu','frameMs'),('shadow','shadowMs'),('main','sceneMs'),('post','postProcessMs')]}
 cpu=data['cpuFrame']['workSamplesMs'];assert len(cpu)==120;summary['cpu']=dict(mean=float(np.mean(cpu[60:])),p95=float(np.percentile(cpu[60:],95)))
 observations=environment['runObservations'];assert not environment['monitorErrors']
 environmentSummary=dict(powerLimits=sorted(set(row['powerLimitWatts'] for row in observations if row['powerLimitWatts'] is not None)),acLineStates=sorted(set(row['hostPower']['acLineStatus'] for row in observations)),temperatures=[min(row['temperature'] for row in observations),max(row['temperature'] for row in observations)],graphicsClocks=[min(row['graphicsClockMHz'] for row in observations if row['graphicsClockMHz'] is not None),max(row['graphicsClockMHz'] for row in observations if row['graphicsClockMHz'] is not None)],thermalSlowdownObserved=any(any(value is True for value in row['thermalSlowdown'].values()) for row in observations),samples=len(observations))
 row=dict(label=label,selectedFrames=60,summary=summary,environment=environmentSummary,metadata={k:v for k,v in data.items() if k.startswith(('conservativeOcclusion','defaultIsolation','surfaceRadiance','computeSkinning','staticSkinning')) or k in ['mainDepthSplitRecorded','vertexCapacity']},sceneExtent=[data['sceneWidth'],data['sceneHeight']]);rows.append(row);print(json.dumps(row),flush=True)
 assert inputs(root)==before and all(digest(Path(p))==sha for p,sha in products.items())
 assert all(digest(Path(row['path']))==row['sha256'] for row in baseline['files'])
assert all(digest(Path(p))==sha for p,sha in lock.items())
b0=rows[0]['summary']['gpu']['mean'];b1=rows[2]['summary']['gpu']['mean'];referenceMean=(b0+b1)/2;candidate=rows[1]['summary']['gpu']['mean']
report=dict(status='diagnosed',rows=rows,bracketDriftFraction=abs(b1-b0)/referenceMean,bracketStable=abs(b1-b0)/referenceMean<=.03,gpuBaselineMean=referenceMean,gpuCandidateMean=candidate,gpuSavedMs=referenceMean-candidate,gpuReductionFraction=1-candidate/referenceMean,sourceAndProductsUnchanged=True,projectInputsVerified=len(lock),outputMemoryReductionFraction=1-40/108,baselineRuntimeVerified=True,scope='Local diagnosis under recorded current power and thermal conditions, sixty warmup and sixty selected frames per process; before/candidate/after bracket; formal performance conditions remain pending',formalPerformancePassed=False)
(out/('cost-results-'+tag+'.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
