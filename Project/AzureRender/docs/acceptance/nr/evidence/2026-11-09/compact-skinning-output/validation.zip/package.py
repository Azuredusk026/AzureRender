from pathlib import Path
import json,zipfile,sys,xml.etree.ElementTree as ET
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from build_provenance import digest,verify
cases=[]
for c in ['release','debug']:
 verify(r,json.loads((r/('build/ninja-msvc-'+c)/'build-provenance.json').read_text()))
 for device in ['nvidia','intel']:
  n=c+'-'+device+'.xml'
  for x in ET.parse(o/n).getroot().findall('testcase'):
   assert x.find('failure') is None and x.find('skipped') is None;cases.append(dict(receipt=n,name=x.attrib['name']))
assert len(cases)==14
image=json.loads((o/'image-compact-skinning/results.json').read_text());assert len(image['frames'])==4 and all(x['changedPixels']==0 and x['sha256']==x['referenceSha256'] for x in image['frames'])
assert all(image[k] for k in ['sourceInputsUnchanged','productsUnchanged','projectInputsUnchanged','validationLogClean','zeroAllocator'])
cost=json.loads((o/'cost-results-v1.json').read_text());assert cost['bracketStable'] and cost['gpuSavedMs']>0 and cost['outputMemoryReductionFraction']>=.6
cleanup=[json.loads((o/n).read_text()) for n in ['runtime-cleanup.json','identical-png-cleanup.json']];assert all(x['status']=='applied' for x in cleanup)
sources=['shaders/mesh.vert','shaders/outline.vert','shaders/shadow.vert','shaders/skin.comp','shaders/skinned_vertex_layout.glsl','src/render/SkinnedVertex.hpp','src/scenes/CharacterSceneRenderer.cpp','tests/SkinningBatchTests.cpp','tests/SkinningGpuTests.cpp']
f=r/'docs/acceptance/nr/evidence/2026-11-09/compact-skinning-output';f.mkdir(parents=True,exist_ok=True)
paths=[p for p in o.glob('*') if p.suffix in ['.json','.log','.xml','.py']]
for name in ['image-compact-skinning','cost-v1-baseline-before','cost-v1-candidate','cost-v1-baseline-after']:
 paths.extend(p for p in (o/name).glob('*') if p.is_file() and p.suffix in ['.json','.log','.csv']);paths.extend((o/name).glob('frames-*/capture_manifest.json'))
with zipfile.ZipFile(f/'validation.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for p in sorted(set(paths)):z.write(p,p.relative_to(o).as_posix())
assert (f/'validation.zip').stat().st_size<8*1024*1024
capacity=image['metadata']['vertexCapacity'];before=capacity*108*2;after=image['metadata']['computeSkinningOutputBytes'];assert after==capacity*40*2
report=dict(sourceBase='3e73e5f2641aaa5261c02b43785109c74d6b1fe2',status='compact-output-integrated-visual-exact-local-gpu-gain',tests=cases,passed=14,skipped=0,native=image,cost=cost,sourceHashes={p:digest(r/p) for p in sources},programs=json.loads((o/'programs-check.json').read_text()),output=dict(vertexWords=10,vertexBytes=40,frameSlots=2,capacityVertices=capacity,baselineLogicalBytes=before,candidateLogicalBytes=after,savedLogicalBytes=before-after,reductionFraction=1-after/before),cleanup=dict(files=sum(x['files'] for x in cleanup),logicalBytes=sum(x['logicalBytes'] for x in cleanup)),formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceZipBytes=(f/'validation.zip').stat().st_size,evidenceZipSha256=digest(f/'validation.zip'))
(f/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
p=r/'docs/development/artifact-manifest.json';d=json.loads(p.read_text());d['milestones'].insert(0,dict(path='runs/'+o.name,name='紧凑蒙皮输出',status='CompactOutputIntegratedVisualExactLocalGpuGain',sourceBase='3e73e5f',evidence='docs/acceptance/nr/compact-skinning-output.md',checksPassed=14,nativeFourFramesExact=True,validComparisonProcesses=3,gpuSavedMs=cost['gpuSavedMs'],gpuReductionFraction=cost['gpuReductionFraction'],outputSavedLogicalBytes=before-after,reclaimedFiles=report['cleanup']['files'],formalPerformancePassed=False));p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ['passed','output','cleanup','evidenceZipBytes']}))
