from pathlib import Path
import json,hashlib,subprocess,stat,shutil
root=Path.cwd().resolve();out=Path(__file__).resolve().parent;rows=[]
for name in ['image-compact-skinning']:
 folder=out/name;report=json.loads((folder/'results.json').read_text());command=json.loads((folder/'command.json').read_text());frames=Path(command[command.index('--capture-dir')+1])
 for row in report['frames']:
  p=(frames/row['frame']).resolve();assert p.is_relative_to(out) and p.is_file() and row['sha256']==row['referenceSha256']
  for item in [p,*p.parents]:assert not item.stat().st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT
  sha=hashlib.sha256(p.read_bytes()).hexdigest();assert sha==row['sha256'];rows.append(dict(path=str(p),relative=p.relative_to(root).as_posix(),bytes=p.stat().st_size,sha256=sha))
assert len(rows)==4 and not subprocess.check_output(['git','ls-files','--',*[r['relative'] for r in rows]]).strip()
receipt=root/'build/maintenance/compact-skinning-output-identical-pngs.json';receipt.write_text(json.dumps(dict(status='planned',paths=rows),indent=2));free=shutil.disk_usage(root).free
for row in rows:
 p=Path(row['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];p.unlink()
report=dict(status='applied',files=4,logicalBytes=sum(r['bytes'] for r in rows),freeBeforeBytes=free,freeAfterBytes=shutil.disk_usage(root).free,paths=rows)
receipt.write_text(json.dumps(report,indent=2));(out/'identical-png-cleanup.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='paths'}))
