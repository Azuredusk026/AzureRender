from pathlib import Path
import json,zlib,hashlib
import numpy as np
from PIL import Image
out=Path(__file__).resolve().parent
main=Path('D:/Projects/FYP/Project/AzureRender')
baseline=json.loads((out/'baseline-results.json').read_text())
state=json.loads((out/'probe-state.json').read_text())
assert state['status']=='collected' and state['baselineRestored'] and not state['debugMessages']
native_path=main/'build/runs/20261027-002548-native-hair-layer-region-closure-61c105/native-screen-visibility.bin'
native=np.fromfile(native_path,dtype='u1').reshape(1440,2560,2)[::-1][130:440,1140:1430,1].astype('i4')
mask_path=main/'build/runs/20261023-105023-character-composite-contribution-diagnosis-acb8e5/native-hair-visible-mask.png'
mask=np.asarray(Image.open(mask_path).convert('L'))[130:440,1140:1430]!=0
values=np.frombuffer(zlib.decompress((out/'visibility-hdr.zlib').read_bytes()),dtype='<f2').reshape(310,290,4).astype('f4')
assert np.isfinite(values[mask]).all() and np.all(values[mask,:3]>=0) and np.all(values[mask,:3]<=1)
actual=np.rint(values[:,:,0]*255).astype('i4')
difference=abs(actual-native)
rows=[]
for point in baseline['points']:
    x,y=point['pixel'];x-=1140;y-=130
    rows.append(dict(pixel=point['pixel'],nativeVisibility=int(native[y,x]),actualVisibility=int(actual[y,x]),
                     visibilityByteError=int(difference[y,x]),colorByteError=max(point['absoluteError'])))
report=dict(status='diagnostic-only',maskPixels=int(mask.sum()),
    visibilityPixelsOverOneByte=int((difference[mask]>1).sum()),maximumVisibilityByteError=int(difference[mask].max()),
    colorFailureCount=len(rows),colorFailuresWithVisibilityOverOneByte=sum(p['visibilityByteError']>1 for p in rows),
    colorFailuresWithExactVisibility=sum(p['visibilityByteError']==0 for p in rows),
    points=rows,probe=state,nativeVisibilitySha256=hashlib.sha256(native_path.read_bytes()).hexdigest(),
    scope='Actual frozen Vulkan hair fragment receiver versus native screen visibility. Diagnostic shader substitution; full color pass requires independent validation.')
(out/'visibility-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['points','probe']},indent=2))
