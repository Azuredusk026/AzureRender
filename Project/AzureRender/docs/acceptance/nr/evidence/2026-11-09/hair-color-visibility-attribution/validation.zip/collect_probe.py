from pathlib import Path
import renderdoc as rd
import json,zlib,hashlib,traceback,sys,os
out=Path('D:/Projects/FYP-worktrees/nr-quality/Project/AzureRender/build/runs/20261109-221435-hair-color-closure-430845')
main=Path('D:/Projects/FYP/Project/AzureRender')
capture=main/'build/runs/20261027-022702-object-visibility-depth-reconstruction-c7312f/receiver-exact-gpu_frame2.rdc'
result=dict(status='starting');cap=None;c=None;replacement=None;original=None
variant=os.environ.get('HAIR_PROBE_VARIANT','visibility')
def digest_file(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
    return digest.hexdigest()
def snapshot():
    c.SetFrameEvent(493,True)
    target=c.GetPipelineState().GetOutputTargets()[0].resource
    raw=bytes(c.GetTextureData(target,rd.Subresource()))
    assert len(raw)==2560*1440*8
    return b''.join(raw[(y*2560+1140)*8:(y*2560+1430)*8] for y in range(130,440))
try:
    cap=rd.OpenCaptureFile();assert cap.OpenFile(str(capture),'',None)==rd.ResultCode.Succeeded
    status,c=cap.OpenCapture(rd.ReplayOptions(),None);assert status==rd.ResultCode.Succeeded
    baseline=snapshot();assert hashlib.sha256(baseline).hexdigest()=='5cb648f7489caac695a104eb40af7e204a964e29780d9681349de6af0d5b8057'
    original=c.GetPipelineState().GetShader(rd.ShaderStage.Pixel)
    replacement,errors=c.BuildTargetShader('main',rd.ShaderEncoding.SPIRV,(out/(variant+'.spv')).read_bytes(),rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
    assert replacement!=rd.ResourceId.Null(),errors
    c.ReplaceResource(original,replacement)
    probe=snapshot();(out/(variant+'-hdr.zlib')).write_bytes(zlib.compress(probe,9))
    if variant=='native-visibility':
        c.SetFrameEvent(567,True)
        target=c.GetPipelineState().GetOutputTargets()[0].resource
        raw=bytes(c.GetTextureData(target,rd.Subresource()));assert len(raw)==2560*1440*4
        crop=b''.join(raw[(y*2560+1140)*4:(y*2560+1430)*4] for y in range(130,440))
        (out/'native-visibility-final.zlib').write_bytes(zlib.compress(crop,9))
    messages=c.GetDebugMessages()
    result['debugMessages']=[str(m.description) for m in messages]
    c.RemoveReplacement(original);restored=snapshot();assert restored==baseline
    result.update(status='collected',baselineRestored=True,probeSha256=hashlib.sha256(probe).hexdigest(),captureSha256=digest_file(capture))
except Exception:result.update(status='failed',error=traceback.format_exc())
finally:
    if c:
        if original:c.RemoveReplacement(original)
        if replacement:c.FreeTargetResource(replacement)
        c.Shutdown()
    if cap:cap.Shutdown()
    (out/(variant+'-state.json')).write_text(json.dumps(result,indent=2)+'\n')
sys.exit(0 if result['status']=='collected' else 1)
