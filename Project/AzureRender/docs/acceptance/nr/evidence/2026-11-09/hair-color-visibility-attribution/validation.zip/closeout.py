from pathlib import Path
import hashlib,json,zipfile
out=Path(__file__).resolve().parent
root=out.parents[2]
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(status='attribution-verified-full-color-failed',productionChanged=False,
    baseline=json.loads((out/'baseline-results.json').read_text()),
    actualReceiver=json.loads((out/'visibility-results.json').read_text()),
    nativeVisibilityControl=json.loads((out/'native-visibility-results.json').read_text()),
    scope='Frozen historical capture; isolated diagnostic substitution. Current production, dynamic scenes and full quality remain pending.')
report['artifacts']={p.name:digest(p) for p in out.iterdir() if p.suffix in ['.py','.zlib','.spv','.spvasm']}
evidence=root/'docs/acceptance/nr/evidence/2026-11-09/hair-color-visibility-attribution'
evidence.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(evidence/'validation.zip','w',zipfile.ZIP_DEFLATED,6) as z:
    for p in out.iterdir():
        if p.is_file() and p.suffix in ['.py','.json','.zlib','.spv','.spvasm','.log']:z.write(p,p.name)
report['archiveSha256']=digest(evidence/'validation.zip')
report['archiveBytes']=(evidence/'validation.zip').stat().st_size
assert report['archiveBytes']<8*1024*1024
(evidence/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(archiveBytes=report['archiveBytes'],archiveSha256=report['archiveSha256']),indent=2))
