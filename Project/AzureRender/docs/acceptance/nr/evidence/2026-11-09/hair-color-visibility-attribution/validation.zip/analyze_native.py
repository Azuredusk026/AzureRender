from pathlib import Path
import json,zlib,runpy
import numpy as np
out=Path(__file__).resolve().parent
baseline=runpy.run_path(str(out/'baseline.py'))
expected=baseline['expected'];mask=baseline['mask'];frozen=baseline['frozen'];bad=baseline['bad']
state=json.loads((out/'native-visibility-state.json').read_text())
assert state['status']=='collected' and state['baselineRestored'] and not state['debugMessages']
actual=np.frombuffer(zlib.decompress((out/'native-visibility-final.zlib').read_bytes()),dtype='u1').reshape(310,290,4)[:,:,[2,1,0]].astype('i4')
delta=abs(actual-expected)
failed=mask&(delta.max(axis=2)>1)
rows=[]
for y,x in zip(*np.where(failed)):
    rows.append(dict(pixel=[int(x+1140),int(y+130)],reference=expected[y,x].tolist(),actual=actual[y,x].tolist(),
        absoluteError=delta[y,x].tolist(),wasBaselineFailure=bool(bad[y,x])))
result=dict(status='diagnostic-source-substitution',maskPixels=int(mask.sum()),
    pixelsOverOneByte=int(failed.sum()),maximumByteError=int(delta[mask].max()),
    meanAbsoluteByteError=float(delta[mask].mean()),resolvedBaselineFailures=int((bad&~failed).sum()),
    newFailures=int((~bad&failed).sum()),points=rows,probe=state,
    scope='Frozen native visibility lookup substitutes the receiver result in an isolated capture; no runtime implementation or formal pass claim.')
(out/'native-visibility-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['points','probe']},indent=2))
