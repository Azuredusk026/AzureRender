from pathlib import Path
import numpy as np
import subprocess
out=Path(__file__).resolve().parent
main=Path('D:/Projects/FYP/Project/AzureRender')
prior=main/'build/runs/20261107-191143-hair-gradient-region-08b1f9'
native=main/'build/runs/20261027-002548-native-hair-layer-region-closure-61c105/native-screen-visibility.bin'
data=np.fromfile(native,dtype='u1').reshape(1440,2560,2)[::-1][130:440,1140:1430,1].copy().ravel()
data=np.pad(data,(0,(-len(data))%4)).view('<u4')
unique=sorted(set(map(int,data)))
ids={value:f'%hair_native_word_{i}' for i,value in enumerate(unique)}
decl=[f'%hair_native_count = OpConstant %uint {len(data)}',
      '%hair_native_array = OpTypeArray %uint %hair_native_count',
      '%hair_native_array_ptr = OpTypePointer Private %hair_native_array',
      '%hair_native_uint_ptr = OpTypePointer Private %uint',
      '%hair_native_origin_x = OpConstant %int 1140',
      '%hair_native_origin_y = OpConstant %int 130',
      '%hair_native_width = OpConstant %int 290',
      '%hair_native_height = OpConstant %int 310',
      '%hair_native_uint4 = OpConstant %uint 4',
      '%hair_native_uint8 = OpConstant %uint 8',
      '%hair_native_uint255 = OpConstant %uint 255',
      '%hair_native_scale = OpConstant %float 0.00392156862745098']
decl += [f'{ids[v]} = OpConstant %uint {v}' for v in unique]
decl += ['%hair_native_words = OpConstantComposite %hair_native_array '+' '.join(ids[int(v)] for v in data),
         '%hair_native_storage = OpVariable %hair_native_array_ptr Private %hair_native_words']
text=(prior/'original-hair.spvasm').read_text()
offset=text.index('       %main = OpFunction')
text=text[:offset]+'\n'.join(decl)+'\n'+text[offset:]
needle='       %5293 = OpLoad %29 %mainShadowDepth'
assert text.count(needle)==1
body='''%hair_native_coord = OpLoad %v4float %gl_FragCoord
%hair_native_xf = OpCompositeExtract %float %hair_native_coord 0
%hair_native_yf = OpCompositeExtract %float %hair_native_coord 1
%hair_native_x = OpConvertFToS %int %hair_native_xf
%hair_native_y = OpConvertFToS %int %hair_native_yf
%hair_native_dx = OpISub %int %hair_native_x %hair_native_origin_x
%hair_native_dy = OpISub %int %hair_native_y %hair_native_origin_y
%hair_native_xlo = OpSGreaterThanEqual %bool %hair_native_dx %int_0
%hair_native_ylo = OpSGreaterThanEqual %bool %hair_native_dy %int_0
%hair_native_xhi = OpSLessThan %bool %hair_native_dx %hair_native_width
%hair_native_yhi = OpSLessThan %bool %hair_native_dy %hair_native_height
%hair_native_inx = OpLogicalAnd %bool %hair_native_xlo %hair_native_xhi
%hair_native_iny = OpLogicalAnd %bool %hair_native_ylo %hair_native_yhi
%hair_native_inside = OpLogicalAnd %bool %hair_native_inx %hair_native_iny
OpSelectionMerge %hair_native_continue None
OpBranchConditional %hair_native_inside %hair_native_lookup %hair_native_continue
%hair_native_lookup = OpLabel
%hair_native_row = OpIMul %int %hair_native_dy %hair_native_width
%hair_native_linear = OpIAdd %int %hair_native_row %hair_native_dx
%hair_native_index = OpBitcast %uint %hair_native_linear
%hair_native_word_index = OpUDiv %uint %hair_native_index %hair_native_uint4
%hair_native_byte_index = OpUMod %uint %hair_native_index %hair_native_uint4
%hair_native_shift = OpIMul %uint %hair_native_byte_index %hair_native_uint8
%hair_native_pointer = OpAccessChain %hair_native_uint_ptr %hair_native_storage %hair_native_word_index
%hair_native_word = OpLoad %uint %hair_native_pointer
%hair_native_shifted = OpShiftRightLogical %uint %hair_native_word %hair_native_shift
%hair_native_byte = OpBitwiseAnd %uint %hair_native_shifted %hair_native_uint255
%hair_native_float = OpConvertUToF %float %hair_native_byte
%hair_native_result = OpFMul %float %hair_native_float %hair_native_scale
OpReturnValue %hair_native_result
%hair_native_continue = OpLabel
'''
text=text.replace(needle,body+needle)
(out/'native-visibility.spvasm').write_text(text)
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
for command in [[str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/'native-visibility.spvasm'),'-o',str(out/'native-visibility.spv')],
                [str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/'native-visibility.spv')]]:
    subprocess.run(command,check=True)
print(f'Native visibility source control: {len(data)} packed words, {len(unique)} unique constants')
