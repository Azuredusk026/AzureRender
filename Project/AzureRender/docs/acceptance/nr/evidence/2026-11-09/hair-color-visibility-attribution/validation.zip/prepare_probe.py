from pathlib import Path
import subprocess
out=Path(__file__).resolve().parent
prior=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261107-191143-hair-gradient-region-08b1f9')
text=(prior/'original-hair.spvasm').read_text()
start=text.index('%main = OpFunction')
end=text.index('OpFunctionEnd',start)
body=text[start:end]
assert body.count('OpReturn\n')==1
probe='''%hair_probe_normal = OpLoad %v3float %shadedNormal
               OpStore %param_735 %hair_probe_normal
%hair_probe_visibility = OpFunctionCall %float %materialObjectVisibility_vf3_ %param_735
%hair_probe_color = OpCompositeConstruct %v4float %hair_probe_visibility %hair_probe_visibility %hair_probe_visibility %float_1
               OpStore %outputColor %hair_probe_color
               OpReturn
'''
body=body.replace('OpReturn\n',probe)
text=text[:start]+body+text[end:]
(out/'visibility.spvasm').write_text(text)
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
for command in [[str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/'visibility.spvasm'),'-o',str(out/'visibility.spv')],
                [str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/'visibility.spv')]]:
    subprocess.run(command,check=True)
