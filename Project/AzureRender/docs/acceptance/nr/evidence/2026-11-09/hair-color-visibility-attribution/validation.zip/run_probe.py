from pathlib import Path
import os, subprocess, sys
out=Path(__file__).resolve().parent
if len(sys.argv)>1:os.environ['HAIR_PROBE_VARIANT']=sys.argv[1]
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES']:os.environ.pop(key,None)
for key in ['APPDATA','LOCALAPPDATA']:
    p=out/'tmp'/key.lower();p.mkdir(parents=True,exist_ok=True);os.environ[key]=str(p)
os.environ['RENDERDOC_DEBUG_LOG_FILE']=str(out/'tmp/renderdoc.log')
os.environ['RDOC_DEBUG_LOG_FILE']=str(out/'tmp/renderdoc.log')
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
with (out/'probe-driver.log').open('wb') as log:
    result=subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(out/'collect_probe.py')],
        startupinfo=startup,creationflags=subprocess.CREATE_NO_WINDOW,stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(result.returncode)
