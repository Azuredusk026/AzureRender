from pathlib import Path
import json, zlib, hashlib
import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
main=Path('D:/Projects/FYP/Project/AzureRender')
prior=main/'build/runs/20261107-191143-hair-gradient-region-08b1f9'
native=main/'build/runs/20261023-033116-postvs-linear-verification-591bef/e950-linear-target.bin'
mask_path=main/'build/runs/20261023-105023-character-composite-contribution-diagnosis-acb8e5/native-hair-visible-mask.png'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(native)=='7590b5bbe131bdd9960f3357dd4240f5b48208ebee9a5f713197431f9bafcf6e'
assert digest(mask_path)=='298c2f71d5055769010c66b53d65137836a57efba0a3709f8bd37966f2d793c7'
x0,y0,x1,y1=1140,130,1430,440
packed=np.frombuffer(native.read_bytes(),dtype='<u4').reshape(1440,2560)[::-1][y0:y1,x0:x1]
channels=[]
for shift,bits in [(0,6),(11,6),(22,5)]:
    value=(packed>>shift)&((1<<(bits+5))-1)
    exponent=(value>>bits).astype('i4')
    mantissa=(value&((1<<bits)-1)).astype('f8')
    assert np.all(exponent!=31)
    channels.append(np.where(exponent==0,np.ldexp(mantissa,-14-bits),np.ldexp(1+mantissa/(1<<bits),exponent-15))*.25)
linear=np.stack(channels,axis=-1)
srgb=np.where(linear<=.0031308,12.92*linear,1.055*np.power(linear,1/2.4)-.055)
expected=np.rint(np.clip(srgb,0,1)*255).astype('i4')
frozen=np.frombuffer(zlib.decompress((prior/'original-final.zlib').read_bytes()),dtype='u1').reshape(y1-y0,x1-x0,4)[:,:,[2,1,0]]
mask=np.asarray(Image.open(mask_path).convert('L'))[y0:y1,x0:x1]!=0
assert int(mask.sum())==17017
difference=abs(frozen.astype('i4')-expected)
bad=mask&(difference.max(axis=2)>1)
assert int(bad.sum())==73 and int(difference[mask].max())==6
assert abs(float(difference[mask].mean())-.2899453487688782)<1e-12
receiver=main/'build/runs/20261109-172812-native-receiver-gpu-oracle-d9e5ba'
pixels=np.fromfile(receiver/'pixels.bin',dtype='<u4').reshape(-1,2)
visibility_expected=np.fromfile(receiver/'expected.u8',dtype='u1').astype(int)
visibility_actual=np.rint(np.fromfile(receiver/'receiver-output.bin',dtype='<f4').reshape(-1,4)[:,2]*255).astype(int)
lookup={(int(x),1439-int(y)):i for i,(x,y) in enumerate(pixels)}
points=[]
for y,x in zip(*np.where(bad)):
    position=(int(x+x0),int(y+y0))
    index=lookup.get(position)
    points.append(dict(pixel=list(position),reference=expected[y,x].tolist(),actual=frozen[y,x].tolist(),
        absoluteError=difference[y,x].tolist(),receiverIndex=index,
        receiverByteError=None if index is None else int(abs(visibility_actual[index]-visibility_expected[index]))))
report=dict(status='baseline-reproduced-quality-failed',maskPixels=int(mask.sum()),pixelsOverOneByte=int(bad.sum()),
    maximumByteError=int(difference[mask].max()),meanAbsoluteByteError=float(difference[mask].mean()),
    matchingReceiverFailures=sum(p['receiverByteError'] is not None and p['receiverByteError']>1 for p in points),
    unmatchedReceiverPixels=sum(p['receiverIndex'] is None for p in points),points=points,
    scope='Frozen historical capture; receiver diagnostic uses native source depth and atlas. Spatial correlation is not causal attribution.',
    inputs={str(p):digest(p) for p in [native,mask_path,prior/'original-final.zlib',receiver/'pixels.bin',receiver/'expected.u8',receiver/'receiver-output.bin']})
(out/'baseline-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['points','inputs']},indent=2))
