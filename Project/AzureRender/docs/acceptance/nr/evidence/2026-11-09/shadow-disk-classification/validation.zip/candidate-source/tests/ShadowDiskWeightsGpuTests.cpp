#include "support/VulkanComputeFixture.hpp"
#include "resources/BinaryFile.hpp"
#include <array>
#include <cstring>
#include <limits>
#include <nlohmann/json.hpp>
using namespace azurerender;
int main(int argc,char** argv)try{
    if(argc!=2&&argc!=3)throw std::invalid_argument("Expected shader and optional --timing");
    const bool timing=argc==3&&std::string(argv[2])=="--timing";
    if(argc==3&&!timing)throw std::invalid_argument("Unknown disk weight option");
    test::VulkanComputeFixture host;auto& backend=*host.backend;
    rhi::GpuBuffer output{};VkDescriptorSetLayout setLayout{};VkDescriptorPool pool{};
    VkPipelineLayout layout{};VkShaderModule shader{};std::array<VkPipeline,3> pipelines{};VkQueryPool queries{};
    auto cleanup=std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*){
        if(queries)vkDestroyQueryPool(host.device,queries,nullptr);
        for(auto pipeline:pipelines)if(pipeline)backend.destroyPipeline(pipeline);
        if(shader)backend.destroyShaderModule(shader);if(layout)backend.destroyPipelineLayout(layout);
        if(pool)backend.destroyDescriptorPool(pool);if(setLayout)backend.destroyDescriptorSetLayout(setLayout);
        host.allocator.destroyBuffer(output);
    });
    constexpr unsigned numericCount=1U<<20,workCount=65536,warmup=2048,samples=128,iterations=warmup+samples;
    output=host.allocator.createBuffer((8+workCount*4)*sizeof(unsigned),VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
    std::memset(output.mapped,0,output.size);host.allocator.flush(output,0,output.size);
    setLayout=backend.createDescriptorSetLayout({{0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT}});
    rhi::DescriptorPoolDesc desc;desc.maxSets=1;desc.sizes={{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1}};
    pool=backend.createDescriptorPool(desc);auto set=backend.allocateDescriptorSets(pool,setLayout,1).front();
    backend.writeDescriptorBuffer({set,0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,output.buffer,output.size});
    rhi::PushConstantRangeDesc push{VK_SHADER_STAGE_COMPUTE_BIT,sizeof(unsigned)};
    layout=backend.createPipelineLayout(setLayout,&push);shader=backend.createShaderModule(readBinaryFile(argv[1]));
    for(unsigned mode=0;mode<(timing?3U:1U);++mode)pipelines[mode]=backend.createComputePipeline({shader,layout,{{0,mode}}});
    auto dispatch=[&](rhi::ICommandRecorder& commands,unsigned mode,unsigned count){
        commands.bindComputePipeline(pipelines[mode]);commands.bindComputeDescriptorSet(layout,set);
        commands.pushConstants(layout,VK_SHADER_STAGE_COMPUTE_BIT,0,&count,sizeof(count));commands.dispatch((count+63)/64,1,1);
    };
    host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer){
        commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT|VK_ACCESS_SHADER_READ_BIT});
        dispatch(commands,0,numericCount);
        commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
    });
    host.allocator.invalidate(output,0,output.size);const auto words=static_cast<const unsigned*>(output.mapped);
    nlohmann::json numerical{{"count",words[0]},{"mismatches",words[1]},{"fallback",words[2]},{"zero",words[3]},{"one",words[4]}};
    std::cout<<nlohmann::json{{"numerical",numerical}}.dump()<<'\n';
    if(words[0]!=numericCount||words[1]||words[2]+words[3]+words[4]!=numericCount||!words[3]||!words[4])throw std::runtime_error("Conservative disk weights differ bitwise or coverage is incomplete");
    nlohmann::json timings=nlohmann::json::array();std::vector<unsigned> reference;
    if(timing){
        VkQueryPoolCreateInfo create{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};create.queryType=VK_QUERY_TYPE_TIMESTAMP;create.queryCount=2*iterations;
        test::vkRequire(vkCreateQueryPool(host.device,&create,nullptr,&queries),"Create disk timing pool");
        for(unsigned mode:{1U,2U,2U,1U}){
            host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer native){
                commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});
                vkCmdResetQueryPool(native,queries,0,2*iterations);
                for(unsigned i=0;i<iterations;++i){
                    if(i)commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});
                    commands.writeTimestamp(queries,2*i,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);dispatch(commands,mode,workCount);commands.writeTimestamp(queries,2*i+1,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
                }
                commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
            });
            std::array<std::uint64_t,2*iterations> ticks{};test::vkRequire(vkGetQueryPoolResults(host.device,queries,0,2*iterations,sizeof(ticks),ticks.data(),sizeof(std::uint64_t),VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT),"Read disk timings");
            const auto mask=host.timestampBits>=64?std::numeric_limits<std::uint64_t>::max():(std::uint64_t{1}<<host.timestampBits)-1;
            std::vector<double> milliseconds;double total=0;
            for(unsigned i=warmup;i<iterations;++i){const double ms=double((ticks[2*i+1]-ticks[2*i])&mask)*host.properties.limits.timestampPeriod*1.e-6;milliseconds.push_back(ms);total+=ms;}
            timings.push_back({{"mode",mode},{"warmup",warmup},{"samples",samples},{"meanMs",total/samples},{"milliseconds",milliseconds}});
            host.allocator.invalidate(output,0,output.size);
            const auto values=static_cast<const unsigned*>(output.mapped)+8;
            if(reference.empty())reference.assign(values,values+workCount*4);
            else if(std::memcmp(reference.data(),values,reference.size()*sizeof(unsigned)))throw std::runtime_error("Accumulated disk weights differ bitwise");
        }
        std::cout<<nlohmann::json{{"timings",timings}}.dump()<<'\n';
    }
    cleanup.reset();
    if(host.errors||host.allocator.statistics().liveBuffers||host.allocator.statistics().liveImages)throw std::runtime_error("Disk validation or release failed");
    std::cout<<"Shadow disk weights: exact constant classification and bounded fallback passed\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
