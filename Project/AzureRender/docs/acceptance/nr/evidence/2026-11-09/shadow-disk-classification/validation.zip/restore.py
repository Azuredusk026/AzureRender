from pathlib import Path
import os,sys,subprocess,json,hashlib,shutil
r=Path.cwd().resolve();o=Path(__file__).resolve().parent
if '--inside' not in sys.argv:
 env=os.environ.copy();env.update(VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',DOTNET_ROOT='D:/Tools/dotnet9',TEMP=str(o/'tmp'),TMP=str(o/'tmp'),TMPDIR=str(o/'tmp'),SQLITE_TMPDIR=str(o/'tmp'),VCPKG_BINARY_SOURCES='clear',VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
 raise SystemExit(subprocess.run([str(r/'tools/msvc_env.bat'),sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--inside'],cwd=r,env=env).returncode)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['CMakeLists.txt','shaders/shadow_compare.glsl','shaders/shadow_disk_weights_test.comp','tests/ShadowDiskWeightsGpuTests.cpp']
(o/'candidate-source.patch').write_bytes(subprocess.check_output(['git','diff','--','CMakeLists.txt','shaders/shadow_compare.glsl']))
catalog={}
for name in names:
 p=r/name;dest=o/'candidate-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);catalog[name]=digest(p)
(o/'candidate-source.json').write_text(json.dumps(catalog,indent=2))
spv=r/'build/ninja-msvc-release/shaders/shadow_disk_weights_test.comp.spv';shutil.copyfile(spv,o/spv.name)
baseline=json.loads((o/'baseline-provenance.json').read_text())['release']['source'];restored={}
for name in names[:2]:
 raw=subprocess.check_output(['git','show','HEAD:Project/AzureRender/'+name]);variants=[raw,raw.replace(b'\r\n',b'\n'),raw.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')]
 data=next(x for x in variants if hashlib.sha256(x).hexdigest()==baseline[name]);(r/name).write_bytes(data);restored[name]=digest(r/name)
for name in names[2:]:
 p=r/name;assert digest(p)==catalog[name];assert not subprocess.check_output(['git','ls-files','--',name]).strip();p.unlink()
command=['cmake','-S',str(r),'-B',str(r/'build/ninja-msvc-release'),'-DAZURE_ENABLE_SHADOW_DISK_CLASSIFICATION=OFF']
with (o/'restore-configure.log').open('wb') as f:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
paths=[spv,r/'build/ninja-msvc-release/AzureShadowDiskWeightsGpuTests.exe',r/'build/ninja-msvc-release/CMakeFiles/AzureShadowDiskWeightsGpuTests.dir/tests/ShadowDiskWeightsGpuTests.cpp.obj']
cleanup=[]
for p in paths:
 if not p.exists():continue
 assert p.resolve().is_relative_to((r/'build/ninja-msvc-release').resolve()) and not p.is_symlink()
 assert not subprocess.check_output(['git','ls-files','--',str(p.relative_to(r))]).strip()
 cleanup.append(dict(path=str(p),sha256=digest(p),logicalBytes=p.stat().st_size));p.unlink()
sys.path.insert(0,str(r/'tools'));from build_provenance import inputs,verify
assert inputs(r)==baseline
programs=json.loads((o/'baseline-shaders.json').read_text())
for c in ['release','debug']:
 b=r/('build/ninja-msvc-'+c);assert {p.name:digest(p) for p in (b/'shaders').glob('*.spv')}==programs[c];verify(r,json.loads((b/'build-provenance.json').read_text()))
report=dict(status='restored',restoredSourceHashes=restored,sourceInputs=len(baseline),programsPerConfiguration={c:len(programs[c]) for c in programs},existingVerificationReused=True,cleanup=dict(status='applied',files=len(cleanup),logicalBytes=sum(p['logicalBytes'] for p in cleanup),items=cleanup))
(o/'source-restoration.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='cleanup'}))
