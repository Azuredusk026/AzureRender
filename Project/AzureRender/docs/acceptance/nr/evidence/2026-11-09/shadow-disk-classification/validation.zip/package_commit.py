from pathlib import Path
import json,hashlib,subprocess,zipfile,re,sys
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(r/'tools'));from build_provenance import inputs,verify
proof=json.loads((o/'baseline-provenance.json').read_text());assert inputs(r)==proof['release']['source']
for c in ['release','debug']:verify(r,json.loads((r/('build/ninja-msvc-'+c)/'build-provenance.json').read_text()))
gate=json.loads((o/'local-gate.json').read_text());assert not gate['gatePassed'] and gate['validationTextClean'] and gate['numerical']['mismatches']==0
restoration=json.loads((o/'source-restoration.json').read_text());assert restoration['status']=='restored'
f=r/'docs/acceptance/nr/evidence/2026-11-09/shadow-disk-classification';f.mkdir(parents=True,exist_ok=True)
paths=[p for p in o.iterdir() if p.suffix in ['.json','.log','.py','.patch','.spv'] and p.is_file()]+[p for p in (o/'candidate-source').rglob('*') if p.is_file()]
with zipfile.ZipFile(f/'validation.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for p in sorted(paths):z.write(p,p.relative_to(o).as_posix())
report=dict(sourceBase='e2c50c9e5380d1b88e34ccfccf29eedeac48788a',status='local-efficiency-gate-not-passed-candidate-isolated',gate=gate,restoration=restoration,sourceHashes={},candidateSource=json.loads((o/'candidate-source.json').read_text()),newStandaloneGpuProcesses=1,canonicalNativeProcesses=0,frameCostProcesses=0,verificationReused='docs/acceptance/nr/shadow-tile-batching.md; identical 1673 inputs and 675 programs per configuration',formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',evidenceZipBytes=(f/'validation.zip').stat().st_size,evidenceZipSha256=digest(f/'validation.zip'))
assert report['evidenceZipBytes']<8*1024*1024;(f/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
p=r/'docs/development/artifact-manifest.json';d=json.loads(p.read_text());d['milestones'].insert(0,dict(path='runs/'+o.name,name='阴影圆盘权重分类',status='LocalGateNotPassedCandidateIsolated',sourceBase='e2c50c9',evidence='docs/acceptance/nr/shadow-disk-classification.md',numericCases=1048576,canonicalNativeProcesses=0,frameCostProcesses=0,standaloneGpuProcesses=1,formalPerformancePassed=False));p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
userHash=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected])).hexdigest();assert userHash=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
docs=['README.md','CHANGELOG.md','docs/development/artifact-manifest.json','docs/plans/azure-engine-plan.md','docs/plans/2026-11-09-shadow-disk-classification.md','docs/acceptance/nr/shadow-disk-classification.md','docs/acceptance/nr/evidence/2026-11-09/shadow-disk-classification/results.json','docs/acceptance/nr/evidence/2026-11-09/shadow-disk-classification/validation.zip']
for name in docs:
 if not name.endswith('.md'):continue
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',(r/name).read_text(encoding='utf-8')):
  if '://' not in target and not target.startswith('#'):assert ((r/name).parent/target.split('#')[0]).resolve().exists(),(name,target)
subprocess.run(['git','diff','--check'],check=True,stderr=subprocess.DEVNULL)
subprocess.run(['git','add','--',*docs],check=True,stderr=subprocess.DEVNULL)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines();assert set(staged)=={'Project/AzureRender/'+p for p in docs}
subprocess.run(['git','diff','--cached','--check'],check=True)
(o/'staged-stat.log').write_text(subprocess.check_output(['git','diff','--cached','--stat'],text=True))
title='feat(nr-performance): 完成圆盘权重分类效率评估';subprocess.run(['git','commit','-m',title],check=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();(o/'commit.json').write_text(json.dumps(dict(commit=commit,title=title,files=staged,protectedUserDiffSha256=userHash),ensure_ascii=False,indent=2));print(json.dumps(dict(commit=commit,evidenceBytes=report['evidenceZipBytes'])))
