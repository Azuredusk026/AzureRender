from pathlib import Path
import os,sys,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'));from artifact_maintenance import guarded_run
b=r/'build/ninja-msvc-release';os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*';os.environ['PATH']=str(b)+';'+os.environ['PATH']
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:os.environ.pop(key,None)
for key in ['TEMP','TMP','TMPDIR','SQLITE_TMPDIR']:os.environ[key]=str(o/'tmp')
command=[str(b/'AzureShadowDiskWeightsGpuTests.exe'),str(b/'shaders/shadow_disk_weights_test.comp.spv'),'--timing'];execution=guarded_run(r/'build',o.name,command,120)
log=(o/'process.log').read_text(errors='replace');(o/'local-gate.log').write_text(log)
assert execution['status']=='exited' and execution['exitCode']==0,(execution,log[-3000:])
data=[json.loads(line) for line in log.splitlines() if line.startswith('{"timings"')];assert len(data)==1;rows=data[0]['timings'];assert [x['mode'] for x in rows]==[1,2,2,1]
numeric=[json.loads(line)['numerical'] for line in log.splitlines() if line.startswith('{"numerical"')];assert len(numeric)==1
reference=(rows[0]['meanMs']+rows[3]['meanMs'])/2;candidate=(rows[1]['meanMs']+rows[2]['meanMs'])/2;drift=abs(rows[0]['meanMs']-rows[3]['meanMs'])/reference;gain=1-candidate/reference
report=dict(status='measured',execution=execution,numerical=numeric[0],rows=rows,referenceMeanMs=reference,candidateMeanMs=candidate,reductionFraction=gain,referenceDriftFraction=drift,gatePassed=drift<=.05 and gain>=.2,validationTextClean=not any(x in log for x in ['Validation Error:','SYNC-HAZARD','VUID-']),scope='Standalone radius-six-to-eight circular-weight loops; bitwise output and accumulated sums; kernel timing only')
(o/'local-gate.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['rows','execution']}))
assert report['validationTextClean']
