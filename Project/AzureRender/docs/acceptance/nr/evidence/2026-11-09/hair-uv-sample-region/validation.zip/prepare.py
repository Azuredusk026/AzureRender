from pathlib import Path
import sys,shutil,struct,json,subprocess
out=Path(__file__).resolve().parent
prior=out.parent/'20261109-225636-hair-base-sample-region-0c13c0'
for name in ['dxbc_util.py','D3D12TokenizedProgramFormat.hpp','LICENSE-RenderDoc.txt','checksum-source.json','header-source.json']:
    shutil.copyfile(prior/name,out/name)
sys.path.insert(0,str(out))
from dxbc_util import chunks,words,instructions,opcode,inst,dest,source,imm,fbits,rebuild,checksum
raw=(prior/'native-original.shader').read_bytes()
cases=[]
for component in range(2):
    for shift in [0,12,24]:
        name=f'uv-{component}-{shift}'
        parts=chunks(raw);index=next(i for i,(kind,_) in enumerate(parts) if kind in [b'SHEX',b'SHDR'])
        w=words(parts[index][1]);items=list(instructions(w))
        declared=next(item for item in items if item[2]==opcode('DCL_TEMPS'))
        scratch=w[declared[1]+1];w[declared[1]+1]=scratch+1
        returns=[item for item in items if item[2]==opcode('RET')];assert len(returns)==1
        extra=[]
        for mask,offset in [(1,shift),(2,shift+6)]:
            operand=source(1,component);operand[0]|=1<<12
            extra+=inst('USHR',dest(scratch),operand,imm(offset))
            extra+=inst('AND',dest(scratch),source(scratch),imm(63))
            extra+=inst('UTOF',dest(scratch),source(scratch))
            extra+=inst('MUL',dest(scratch),source(scratch),imm(fbits(1/64)))
            extra+=inst('MOV',dest(0,mask,True),source(scratch))
        end=returns[0][1];w[end:end]=extra;w[1]=len(w)
        parts[index]=(parts[index][0],struct.pack('<'+'I'*len(w),*w))
        code=rebuild(raw,parts);assert checksum(code)==code[4:20]
        (out/(name+'.dxbc')).write_bytes(code)
        text=(prior/'sample-0-0.spvasm').read_text()
        text=text.replace('%sample_probe_shift_r = OpConstant %uint 0',f'%sample_probe_shift_r = OpConstant %uint {shift}')
        text=text.replace('%sample_probe_shift_g = OpConstant %uint 6',f'%sample_probe_shift_g = OpConstant %uint {shift+6}')
        text=text.replace('%sample_probe_value = OpCompositeExtract %float %8245 0',
            f'%sample_probe_uv = OpLoad %v2float %textureCoordinate\n%sample_probe_value = OpCompositeExtract %float %sample_probe_uv {component}')
        (out/(name+'.spvasm')).write_text(text)
        sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
        for command in [[str(sdk/'spirv-as.exe'),'--target-env','vulkan1.0',str(out/(name+'.spvasm')),'-o',str(out/(name+'.spv'))],
                        [str(sdk/'spirv-val.exe'),'--target-env','vulkan1.0',str(out/(name+'.spv'))]]:subprocess.run(command,check=True)
        cases.append(dict(name=name,component=component,shift=shift))
(out/'cases.json').write_text(json.dumps(cases,indent=2))
collect=(prior/'collect.py').read_text().replace('20261109-225636-hair-base-sample-region-0c13c0',out.name).replace('from probes import native_probe','')
collect=collect.replace("code=native_probe(raw,case['component'],case['shift']) if native else", "code=(out/(case['name']+'.dxbc')).read_bytes() if native else")
(out/'collect.py').write_text(collect)
(out/'run.py').write_text((prior/'run.py').read_text())
print('Prepared six paired full-word UV probes with original blue preserved')
