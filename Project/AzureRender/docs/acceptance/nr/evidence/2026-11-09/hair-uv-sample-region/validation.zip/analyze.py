from pathlib import Path
import json,struct,math
out=Path(__file__).resolve().parent
report=json.loads((out/'probe-results.json').read_text())
assert report['status']=='qualified' and len(report['captures'])==2
allowed_native={
    'NVIDIA Nsight Perf SDK\nNVD3D11Counters::GetCounterAvailabilityImage\nNvPerf could not determine counter availability for this GPU',
    'NVIDIA Nsight Perf SDK\nNVD3D11Counters::Impl::TryInitializePerfSDK\nNvPerf could not initialize counter availability image'}
assert set(report['captures'][0]['debugMessages'])<=allowed_native and not report['captures'][1]['debugMessages']
material=json.loads((out.parent/'20261109-231408-hair-material-sample-region-5f9f16/results.json').read_text())
stable={tuple(row['pixel']):row['exact'] for row in material['rows'] if row['field']=='parameters'}
samples={}
for capture in report['captures']:
    assert len(capture['runs'])==6 and capture['baselineRestored']
    assert all(row['qualified'] for row in capture['runs'])
    words=[[0,0] for _ in report['points']]
    for row in capture['runs']:
        for index,value in enumerate(row['values']):words[index][row['case']['component']]|=value<<row['case']['shift']
    assert all(0<=word<=0xffffffff for row in words for word in row)
    samples[capture['label']]=words
rows=[]
decode=lambda row:[struct.unpack('<f',struct.pack('<I',value))[0] for value in row]
for index,pixel in enumerate(report['points']):
    a=samples['native'][index];b=samples['vulkan'][index];av=decode(a);bv=decode(b)
    assert all(math.isfinite(value) for value in av+bv)
    rows.append(dict(pixel=pixel,nativeBits=a,vulkanBits=b,native=av,vulkan=bv,exact=a==b,
        parameterSampleExact=stable[tuple(pixel)],maximumAbsolute=max(abs(x-y) for x,y in zip(av,bv))))
result=dict(status='qualified-uv-input-comparison',points=len(rows),exactPoints=sum(row['exact'] for row in rows),
    maximumAbsolute=max(row['maximumAbsolute'] for row in rows),
    exactAmongSixParameterDifferences=sum(row['exact'] and not row['parameterSampleExact'] for row in rows),
    exactAmong25ParameterMatches=sum(row['exact'] and row['parameterSampleExact'] for row in rows),
    rows=rows,qualification=report,
    scope='Actual interpolated UV inputs read from the original fragment flow with full-crop blue qualification. Sample gradients, LOD selection and filtering remain independent.')
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['rows','qualification']},indent=2))
