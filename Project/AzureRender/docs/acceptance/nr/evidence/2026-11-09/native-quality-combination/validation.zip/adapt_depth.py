from pathlib import Path
import shutil, hashlib, json
out = Path(__file__).resolve().parent
archive = out/'invalid-depth-convention'
archive.mkdir()
for p in [*out.glob('intel-*.bin'), *out.glob('nvidia-*.bin'),
          *out.glob('intel-*.log'), *out.glob('nvidia-*.log'), out/'results.json']:
    shutil.move(str(p), str(archive/p.name))
p = out/'object_shadow.glsl'
s = p.read_text()
assert 'greaterThanEqual(pixel,hi)))return 1.0;' in s
assert 'vec4 reversed=1.0-objectShadowGather' in s
s = s.replace('greaterThanEqual(pixel,hi)))return 1.0;', 'greaterThanEqual(pixel,hi)))return 0.0;')
s = s.replace('vec4 reversed=1.0-objectShadowGather', 'vec4 reversed=objectShadowGather')
p.write_text(s)
(out/'depth-adaptation.json').write_text(json.dumps(dict(
    reason='Native D16 stores reversed depth; diagnostic reads it directly.',
    changes=['outside-page native depth is zero', 'native stored depth is already reversed'],
    shaderSha256=hashlib.sha256(p.read_bytes()).hexdigest()), indent=2))
