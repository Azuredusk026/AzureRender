from pathlib import Path
import os, sys, subprocess, json

out = Path(__file__).resolve().parent
main = Path('D:/Projects/FYP/Project/AzureRender')
sdk = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
mode = sys.argv[1]
if mode in ['build', 'shaders']:
    with (out/'build.log').open('wb') as log:
        for name in (['compile-command.txt', 'link-command.txt'] if mode == 'build' else []):
            subprocess.run((out/name).read_text(), shell=True, check=True,
                           cwd=main/'build/ninja-msvc-release', stdout=log, stderr=subprocess.STDOUT)
        for shader in ['measured-filter', 'precise-filter', 'precise-homogeneous']:
            for command in [[str(sdk/'glslc.exe'), '-I'+str(out), str(out/(shader+'.comp')), '-o', str(out/(shader+'.spv'))],
                            [str(sdk/'spirv-val.exe'), '--target-env', 'vulkan1.3', str(out/(shader+'.spv'))]]:
                subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT)
else:
    os.environ.update(VK_LOADER_DRIVERS_SELECT='*igvk64*' if mode=='intel' else '*nv-vk64*',
                      VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LAYER_VALIDATE_SYNC='1', VK_LOADER_DEBUG='error,layer')
    for key in ['VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_ENABLES']:
        os.environ.pop(key, None)
    os.environ['PATH'] = str(main/'build/ninja-msvc-release')+';'+os.environ['PATH']
    for shader in ['measured-filter', 'precise-filter', 'precise-homogeneous']:
        fixture = out/('fixture.json' if shader=='measured-filter' else 'coordinates-fixture.json')
        with (out/(mode+'-'+shader+'.log')).open('wb') as log:
            subprocess.run([str(out/'collector.exe'), str(out/(shader+'.spv')), str(fixture),
                            str(out/(mode+'-'+shader+'.bin'))], check=True, stdout=log, stderr=subprocess.STDOUT)
print(mode+' completed')
