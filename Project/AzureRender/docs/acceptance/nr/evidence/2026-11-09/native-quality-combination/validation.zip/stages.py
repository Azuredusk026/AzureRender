from pathlib import Path
import subprocess, os, json, sys
import numpy as np
out=Path(__file__).resolve().parent
prior=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261109-181501-native-producer-gpu-intermediates-de1e3d')
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
source=(out/'precise-filter.comp').read_text()
needle='outputData.results[i]=vec4(filtered,objectShadowUnorm8(filtered.x),clear.x);'
assert source.count(needle)==1
os.environ.update(VK_LOADER_DRIVERS_SELECT='*igvk64*', VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LAYER_VALIDATE_SYNC='1', VK_LOADER_DEBUG='error,layer')
for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES']:os.environ.pop(key,None)
os.environ['PATH']='D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-release;'+os.environ['PATH']
report={}
expected=np.fromfile(prior/'expected.u8',dtype='u1').astype(int)
actual=np.rint(np.fromfile(out/'intel-precise-filter.bin',dtype='<f4').reshape(-1,4)[:,2]*255).astype(int)
failed=abs(actual-expected)>1
for stage,variable,native in [('world','measuredWorld','world'),('normal','unusedNormal','normal'),('biased','measuredBias','biased'),('receiver','receiver','receiver')]:
    shader=out/f'intel-stage-{stage}.comp'
    shader.write_text(source.replace(needle,f'outputData.results[i]=vec4({variable},1.0);'))
    with (out/f'intel-stage-{stage}.log').open('wb') as log:
        commands = [[str(sdk/'glslc.exe'),'-I'+str(out),str(shader),'-o',str(shader.with_suffix('.spv'))],
                        [str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3',str(shader.with_suffix('.spv'))],
                        [str(out/'collector.exe'),str(shader.with_suffix('.spv')),str(out/'coordinates-fixture.json'),str(shader.with_suffix('.bin'))]]
        for command in ([] if '--analyze-only' in sys.argv else commands):
            subprocess.run(command,check=True,stdout=log,stderr=subprocess.STDOUT)
    bits=np.zeros((49384,3),dtype='<u4')
    for component in range(3):
        for byte in range(4):
            bits[:,component]|=np.fromfile(prior/f'{native}-{component}-{byte}.u8',dtype='u1').astype('<u4')<<(byte*8)
    if stage=='receiver':
        query=np.fromfile(prior/'receiver-queries.bin',dtype='<f4').reshape(-1,3,4)
        native_values=bits.view('<f4').copy()
        native_values[:,:2]=native_values[:,:2]*query[:,2,2:]+query[:,2,:2]
        bits=native_values.view('<u4')
    values=np.fromfile(shader.with_suffix('.bin'),dtype='<f4').reshape(-1,4)[:,:3].copy()
    equal=np.all(values.view('<u4')==bits,axis=1)
    report[stage]=dict(exactPixels=int(equal.sum()), exactAmongFailedPixels=int((equal&failed).sum()),
                       maxAbsolutePerComponent=abs(values-bits.view('<f4')).max(axis=0).tolist())
(out/'stages-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
