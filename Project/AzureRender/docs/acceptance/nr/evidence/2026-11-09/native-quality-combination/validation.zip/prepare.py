from pathlib import Path
import hashlib, json, shutil

out = Path(__file__).resolve().parent
root = out.parents[2]
main = Path('D:/Projects/FYP/Project/AzureRender')
prior = main/'build/runs/20261109-181501-native-producer-gpu-intermediates-de1e3d'
files = ['collector.cpp', 'native_receiver_precise.glsl', 'precise-filter.comp',
         'precise-homogeneous.comp', 'coordinates-fixture.json', 'fixture.json']
fingerprints = {}
for name in files:
    src = prior/name
    fingerprints[str(src)] = hashlib.sha256(src.read_bytes()).hexdigest()
    shutil.copyfile(src, out/name)
shader = root/'shaders/object_shadow.glsl'
shutil.copyfile(shader, out/'object_shadow.glsl')
fingerprints[str(shader)] = hashlib.sha256(shader.read_bytes()).hexdigest()
# The measured-input control and reconstructed candidate use the same filter.
shutil.copyfile(prior/'filter.comp', out/'measured-filter.comp')
source = (out/'collector.cpp').read_text()
source = source.replace('test::VulkanComputeFixture host;auto& backend=*host.backend;',
    'test::VulkanComputeFixture host;std::cout << "Device: " << host.properties.deviceName << "\\n";auto& backend=*host.backend;')
(out/'collector.cpp').write_text(source)
for name in ['compile-command.txt', 'link-command.txt']:
    command = (prior/name).read_text().replace(str(prior), str(out))
    command = command.replace(str(main/'src'), str(root/'src'))
    command = command.replace(str(main/'tests'), str(root/'tests'))
    command = command.replace('/Fo'+str(out/'collector.obj'), '/Fo'+str(out/'collector.obj'))
    (out/name).write_text(command)
for p in [main/'build/ninja-msvc-release/AzureRenderCore.lib', main/'build/ninja-msvc-release/AzureFoundation.lib']:
    fingerprints[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
(out/'input-fingerprints.json').write_text(json.dumps(fingerprints, indent=2))
print('Prepared measured-filter, precise-filter and homogeneous controls')
