from pathlib import Path
import hashlib, json
import numpy as np

out = Path(__file__).resolve().parent
prior = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261109-181501-native-producer-gpu-intermediates-de1e3d')
expected = np.fromfile(prior/'expected.u8', dtype='u1').astype('i4')
assert len(expected) == 49384
bits = np.zeros((len(expected), 4), dtype='<u4')
for component in range(4):
    name = 'homogeneous' if component < 3 else 'homogeneous-w'
    index = component if component < 3 else 0
    for byte in range(4):
        part = np.fromfile(prior/f'{name}-{index}-{byte}.u8', dtype='u1')
        assert part.shape == expected.shape
        bits[:, component] |= part.astype('<u4') << (8*byte)
report = dict(samples=len(expected), byteThreshold=1, configurations={},
              sourceCommit='3f9c745', scope='native receiver diagnostic; full hair color remains pending')
for device in ['intel', 'nvidia']:
    rows = {}
    for mode in ['measured-filter', 'precise-filter', 'precise-homogeneous']:
        p = out/f'{device}-{mode}.bin'
        values = np.fromfile(p, dtype='<f4').reshape(-1, 4)
        assert values.shape == (len(expected), 4) and np.isfinite(values).all()
        log = (out/f'{device}-{mode}.log').read_text(errors='replace')
        assert 'zero validation errors' in log and 'Device: ' in log
        if mode == 'precise-homogeneous':
            differences = np.any(values.view('<u4') != bits, axis=1)
            row = dict(exactPixels=int((~differences).sum()),
                       maximumAbsolutePerComponent=np.abs(values-bits.view('<f4')).max(axis=0).tolist())
        else:
            assert np.all((values[:, 2] >= 0) & (values[:, 2] <= 1))
            difference = abs(np.rint(values[:, 2]*255).astype('i4')-expected)
            row = dict(exactPixels=int((difference==0).sum()),
                       pixelsOverOneByte=int((difference>1).sum()),
                       maximumByteError=int(difference.max()))
        row['sha256'] = hashlib.sha256(p.read_bytes()).hexdigest()
        row['deviceLine'] = next(line for line in log.splitlines() if line.startswith('Device: '))
        rows[mode] = row
    report['configurations'][device] = rows
report['passed'] = all(rows['precise-filter']['pixelsOverOneByte']==0 for rows in report['configurations'].values())
(out/'results.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
