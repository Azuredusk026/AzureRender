from pathlib import Path
import json, hashlib, zipfile, shutil
out=Path(__file__).resolve().parent
root=out.parents[2]
prior=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261109-181501-native-producer-gpu-intermediates-de1e3d')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results=json.loads((out/'results.json').read_text())
results['stageDiagnosis']=json.loads((out/'stages-results.json').read_text())
results['productionChanged']=False
results['inputs']={}
for name,expected in json.loads((prior/'results.json').read_text())['sourceInputs'].items():
    actual=digest(Path(name))
    assert actual==expected, name
    results['inputs'][name]=actual
for name in ['native-filter-queries.bin','receiver-queries.bin','expected.u8']:
    results['inputs'][str(prior/name)]=digest(prior/name)
results['artifacts']={p.name:digest(p) for p in out.iterdir() if p.suffix in ['.spv','.comp','.glsl','.exe','.bin','.py']}
for device in ['intel','nvidia']:
    for stage in ['measured-filter','precise-filter','precise-homogeneous']:
        text=(out/f'{device}-{stage}.log').read_text(errors='replace')
        assert 'zero validation errors' in text
results['inputLeaseTokens']=['external-input-bce46794747f4f63a5d5ee16b98a79ff','external-input-5420014f536f4182b1987571024a3571','external-input-bca77597245042a989c322e5297fe55a']
results['diagnosticLogLimit']='Stage readback collector returned success and enforces validation errors; standalone stage log files were truncated during offline reanalysis.'
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
evidence=root/'docs/acceptance/nr/evidence/2026-11-09/native-quality-combination'
evidence.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(evidence/'validation.zip','w',zipfile.ZIP_DEFLATED,6) as z:
    for p in out.iterdir():
        if p.is_file() and p.suffix in ['.py','.json','.comp','.glsl','.spv','.bin','.log','.txt']:
            z.write(p,p.name)
    z.write(prior/'expected.u8','reference/expected.u8')
assert (evidence/'validation.zip').stat().st_size<8*1024*1024
results['archiveSha256']=digest(evidence/'validation.zip')
(evidence/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(dict(archiveBytes=(evidence/'validation.zip').stat().st_size,archiveSha256=results['archiveSha256'],passed=results['passed']),indent=2))
