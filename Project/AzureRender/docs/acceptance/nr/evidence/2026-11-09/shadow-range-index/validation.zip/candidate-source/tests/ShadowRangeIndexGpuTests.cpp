#include "support/VulkanComputeFixture.hpp"
#include "resources/BinaryFile.hpp"
#include <array>
#include <algorithm>
#include <cstring>
#include <limits>
#include <nlohmann/json.hpp>
using namespace azurerender;
int main(int argc,char** argv)try{
 if(argc!=2&&argc!=3)throw std::invalid_argument("Expected shader directory and optional --timing");
 bool timing=argc==3&&std::string(argv[2])=="--timing";if(argc==3&&!timing)throw std::invalid_argument("Unknown range index option");
 test::VulkanComputeFixture host;auto& backend=*host.backend;
 const unsigned tiles=timing?512U:17U,count=timing?1920U*1080U:tiles*tiles*36U,profile=timing?1:0;
 rhi::GpuBuffer table{},output{};std::array<VkDescriptorSetLayout,2> sets{};VkDescriptorPool pool{};
 std::array<VkPipelineLayout,2> layouts{};std::array<VkShaderModule,2> modules{};std::array<VkPipeline,3> pipelines{};VkQueryPool queries{};
 auto cleanup=std::unique_ptr<void,std::function<void(void*)>>(&host,[&](void*){
  if(queries)vkDestroyQueryPool(host.device,queries,nullptr);for(auto p:pipelines)if(p)backend.destroyPipeline(p);
  for(auto m:modules)if(m)backend.destroyShaderModule(m);for(auto l:layouts)if(l)backend.destroyPipelineLayout(l);
  if(pool)backend.destroyDescriptorPool(pool);for(auto s:sets)if(s)backend.destroyDescriptorSetLayout(s);
  host.allocator.destroyBuffer(output);host.allocator.destroyBuffer(table);
 });
 table=host.allocator.createBuffer(3ULL*tiles*tiles*2*sizeof(float),VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
 output=host.allocator.createBuffer(count*2ULL*sizeof(float),VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,true);
 std::vector<std::array<float,2>> base(tiles*tiles);
 for(unsigned y=0;y<tiles;++y)for(unsigned x=0;x<tiles;++x){
  float a=float((x*73+y*29+(x^y)*31)%1025)/1024.F,b=float((x*43+y*139+(x^y)*53)%1025)/1024.F;
  base[y*tiles+x]={std::min(a,b),std::max(a,b)};
 }
 base[0]={0,0};base.back()={1,1};std::memcpy(table.mapped,base.data(),base.size()*sizeof(base[0]));host.allocator.flush(table,0,table.size);
 sets[0]=backend.createDescriptorSetLayout({{0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT}});
 sets[1]=backend.createDescriptorSetLayout({{0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT},{1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,1,VK_SHADER_STAGE_COMPUTE_BIT}});
 rhi::DescriptorPoolDesc desc;desc.maxSets=2;desc.sizes={{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,3}};pool=backend.createDescriptorPool(desc);
 std::array<VkDescriptorSet,2> descriptors{};
 for(unsigned i=0;i<2;++i){
  descriptors[i]=backend.allocateDescriptorSets(pool,sets[i],1).front();backend.writeDescriptorBuffer({descriptors[i],0,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,table.buffer,table.size});
  rhi::PushConstantRangeDesc push{VK_SHADER_STAGE_COMPUTE_BIT,i==0?8U:12U};layouts[i]=backend.createPipelineLayout(sets[i],&push);
  modules[i]=backend.createShaderModule(readBinaryFile(std::string(argv[1])+(i==0?"/shadow_range_build.comp.spv":"/shadow_range_index_test.comp.spv")));
 }
 backend.writeDescriptorBuffer({descriptors[1],1,VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,output.buffer,output.size});
 pipelines[0]=backend.createComputePipeline({modules[0],layouts[0]});
 for(unsigned mode=0;mode<2;++mode)pipelines[mode+1]=backend.createComputePipeline({modules[1],layouts[1],{{0,mode}}});
 auto build=[&](rhi::ICommandRecorder& commands){
  commands.bindComputePipeline(pipelines[0]);commands.bindComputeDescriptorSet(layouts[0],descriptors[0]);
  for(unsigned level=0;level<2;++level){
   unsigned push[]={tiles,level};commands.pushConstants(layouts[0],VK_SHADER_STAGE_COMPUTE_BIT,0,push,sizeof(push));commands.dispatch((tiles+7)/8,(tiles+7)/8,1);
   commands.bufferBarrier({table.buffer,0,table.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});
  }
 };
 auto query=[&](rhi::ICommandRecorder& commands,unsigned mode){
  commands.bindComputePipeline(pipelines[mode+1]);commands.bindComputeDescriptorSet(layouts[1],descriptors[1]);
  unsigned push[]={tiles,count,profile};commands.pushConstants(layouts[1],VK_SHADER_STAGE_COMPUTE_BIT,0,push,sizeof(push));commands.dispatch((count+63)/64,1,1);
 };
 std::vector<std::array<float,2>> expected(count);
 for(unsigned id=0;id<count;++id){
  unsigned pattern=profile==0?id%36:(id/64)%4,site=profile==0?id/36:id,x=site%tiles,y=(site/tiles)%tiles;
  unsigned width=profile==0?1+pattern%6:3+(pattern&1),height=profile==0?1+pattern/6:3+(pattern>>1);
  auto& range=expected[id];range={1,0};
  for(unsigned ty=y;ty<std::min(y+height,tiles);++ty)for(unsigned tx=x;tx<std::min(x+width,tiles);++tx){range[0]=std::min(range[0],base[ty*tiles+tx][0]);range[1]=std::max(range[1],base[ty*tiles+tx][1]);}
 }
 host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer){
  commands.bufferBarrier({table.buffer,0,table.size,VK_PIPELINE_STAGE_HOST_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_HOST_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});build(commands);
 });
 nlohmann::json timings=nlohmann::json::array();constexpr unsigned warmup=2048,samples=128,chunk=64;
 if(timing){VkQueryPoolCreateInfo create{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};create.queryType=VK_QUERY_TYPE_TIMESTAMP;create.queryCount=2*chunk;test::vkRequire(vkCreateQueryPool(host.device,&create,nullptr,&queries),"Create range timing pool");}
 for(unsigned mode:timing?std::vector<unsigned>{0,1,1,0}:std::vector<unsigned>{0,1}){
  std::vector<double> milliseconds;
  for(unsigned start=0;start<(timing?warmup+samples:1U);start+=timing?chunk:1U){
   unsigned iterations=timing?chunk:1U;
   host.submit([&](rhi::ICommandRecorder& commands,VkCommandBuffer native){
    if(timing)vkCmdResetQueryPool(native,queries,0,2*chunk);
    for(unsigned i=0;i<iterations;++i){
     commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_WRITE_BIT});
     commands.bufferBarrier({table.buffer,0,table.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT});
     if(timing)commands.writeTimestamp(queries,2*i,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
     if(mode&&timing)build(commands);query(commands,mode);
     if(timing)commands.writeTimestamp(queries,2*i+1,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
    }
    commands.bufferBarrier({output.buffer,0,output.size,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_HOST_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_HOST_READ_BIT});
   });
   if(timing&&start>=warmup){
    std::array<std::uint64_t,2*chunk> ticks{};test::vkRequire(vkGetQueryPoolResults(host.device,queries,0,2*chunk,sizeof(ticks),ticks.data(),sizeof(std::uint64_t),VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT),"Read range timing");
    auto mask=host.timestampBits>=64?std::numeric_limits<std::uint64_t>::max():(std::uint64_t{1}<<host.timestampBits)-1;
    for(unsigned i=0;i<chunk;++i)milliseconds.push_back(double((ticks[2*i+1]-ticks[2*i])&mask)*host.properties.limits.timestampPeriod*1.e-6);
   }
  }
  host.allocator.invalidate(output,0,output.size);if(std::memcmp(output.mapped,expected.data(),output.size))throw std::runtime_error("Range result differs bitwise from CPU rectangle extrema");
  if(timing){double total=0;for(double ms:milliseconds)total+=ms;timings.push_back({{"mode",mode},{"warmup",warmup},{"samples",samples},{"meanMs",total/samples},{"milliseconds",milliseconds}});}
 }
 std::cout<<nlohmann::json{{"tiles",tiles},{"count",count},{"timings",timings},{"exact",true},{"includesBuildCost",timing}}.dump()<<'\n';
 cleanup.reset();if(host.errors||host.allocator.statistics().liveBuffers||host.allocator.statistics().liveImages)throw std::runtime_error("Range validation or release failed");
 std::cout<<"Exact overlapping range tables, rectangle fallback and resource release passed\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
