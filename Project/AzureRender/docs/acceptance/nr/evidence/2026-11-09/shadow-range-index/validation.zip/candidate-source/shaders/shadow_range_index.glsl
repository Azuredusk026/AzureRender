#ifndef AZURE_SHADOW_RANGE_INDEX_GLSL
#define AZURE_SHADOW_RANGE_INDEX_GLSL
vec2 azureBaseShadowRange(ivec2 low,ivec2 high,int tiles){
 vec2 range=vec2(1,0);
 for(int y=low.y;y<=high.y;++y)for(int x=low.x;x<=high.x;++x){
  vec2 value=AZURE_SHADOW_RANGE_READ(y*tiles+x);
  range=vec2(min(range.x,value.x),max(range.y,value.y));
 }
 return range;
}
vec2 azureIndexedShadowRange(ivec2 low,ivec2 high,int tiles){
 ivec2 size=high-low+1;int level=min(findMSB(min(size.x,size.y)),2),side=1<<level;
 if(max(size.x,size.y)>2*side)return azureBaseShadowRange(low,high,tiles);
 ivec2 last=high-ivec2(side-1);int table=level*tiles*tiles;
 vec2 a=AZURE_SHADOW_RANGE_READ(table+low.y*tiles+low.x);
 vec2 b=AZURE_SHADOW_RANGE_READ(table+low.y*tiles+last.x);
 vec2 c=AZURE_SHADOW_RANGE_READ(table+last.y*tiles+low.x);
 vec2 d=AZURE_SHADOW_RANGE_READ(table+last.y*tiles+last.x);
 return vec2(min(min(a.x,b.x),min(c.x,d.x)),max(max(a.y,b.y),max(c.y,d.y)));
}
#endif
