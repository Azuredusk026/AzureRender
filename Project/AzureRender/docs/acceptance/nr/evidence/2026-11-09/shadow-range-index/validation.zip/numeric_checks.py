from pathlib import Path
import os,subprocess,json
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;b=r/'build/ninja-msvc-release';rows=[]
for device,driver in [('nvidia','*nv-vk64*'),('intel','*igvk64*')]:
 env=os.environ.copy();env.update(VK_LOADER_DRIVERS_SELECT=driver,TEMP=str(o/'tmp'),TMP=str(o/'tmp'),TMPDIR=str(o/'tmp'),SQLITE_TMPDIR=str(o/'tmp'))
 for key in ['VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
 command=[str(b/'AzureShadowRangeIndexGpuTests.exe'),str(b/'shaders')]
 with (o/(device+'-numeric.log')).open('wb') as log:p=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 text=(o/(device+'-numeric.log')).read_text(errors='replace');assert p.returncode==0 and not any(x in text for x in ['Validation Error:','VUID-','SYNC-HAZARD']),text[-3000:]
 data=[json.loads(line) for line in text.splitlines() if line.startswith('{')];assert len(data)==1 and data[0]['exact'] and data[0]['count']==10404
 rows.append(dict(device=device,command=command,exitCode=p.returncode,result=data[0]));print(device+' numerical passed',flush=True)
(o/'numeric-checks.json').write_text(json.dumps(rows,indent=2))
