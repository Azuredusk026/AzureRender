from pathlib import Path
import hashlib,json,shutil,subprocess,sys,zipfile
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from build_provenance import digest,verify
from artifact_maintenance import write_json,tracked_paths
from artifact_cleanup import remove_artifact
def read(p):return json.loads(p.read_text())
decision=read(o/'decision.json');cost=read(o/'cost-results-demand-v1.json');assert not cost['phaseEfficiencyGatePassed']
baseline=read(o/'baseline-build-provenance.json');builds={}
for config in ['release','debug']:
    b=r/('build/ninja-msvc-'+config);m=read(b/'build-provenance.json');verify(r,m)
    assert m['source']==baseline['source']
    builds[config]=dict(sourceInputsRestored=len(m['source']),verified=True)
for name,v in read(o/'baseline-runtime.json').items():
    assert digest(r/'build/ninja-msvc-release'/name)==v['sha256']==digest(o/'baseline-runtime'/name)
protected=['docs/acceptance/p5','src/app/AzureRenderPipeline.cpp','src/app/AzureRenderSupport.cpp','src/runtime/AssetDatabase.cpp','src/rhi/GpuAllocator.hpp','tests/MaterialPipelinePolicyTests.cpp','tests/ObjectShadowAtlasTests.cpp','tests/ShadowTileBoundsGpuTests.cpp','tools/endfield_native','tools/test_native_character_surfaces.py']
ph=hashlib.sha256(subprocess.check_output(['git','diff','--binary','--',*protected],cwd=r)).hexdigest();assert ph=='12eb4dfb3fb7568451c11a58931cd04c26fac58b2fd41ccee465ab045de88ed8'
controls=read(o/'controls.json');assert len(controls)==4 and all(v['changedPixels']==0 and v['inputsUnchanged'] for v in controls)
result=dict(status='isolated-not-adopted',baselineCommit='ffa5793',run=o.name,decision=decision,cost=cost,controls=controls,restoredBuilds=builds,restoredRuntimeFiles=676,protectedDiffSha256=ph,formalPerformancePassed=False,overallVisualAcceptance='failed-user-review',scope='Four small same-input comparisons and one before/candidate/after bracket. No candidate Debug build, full original four-frame capture or formal long run. Production restored byte-for-byte.')
write_json(o/'results.json',result)
dest=r/'docs/acceptance/nr/evidence/2026-11-09/presentation-environment-demand';dest.mkdir(parents=True,exist_ok=True);archive=dest/'validation.zip'
selected=[p for p in sorted(o.rglob('*')) if p.is_file() and not any(x in {'baseline-runtime','tmp','__pycache__'} for x in p.relative_to(o).parts) and (p.suffix.lower() in {'.py','.frag','.patch','.json','.jsonl','.csv','.log','.xml','.gltf','.azureproject','.azurelevel','.png','.azenv'} or p.name=='baseline-shader-source.zip')]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in selected:z.write(p,p.relative_to(o).as_posix())
assert archive.stat().st_size<=8*1024*1024
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p in selected:assert hashlib.sha256(z.read(p.relative_to(o).as_posix())).hexdigest()==digest(p)
result['package']=dict(path=archive.relative_to(r).as_posix(),sha256=digest(archive),bytes=archive.stat().st_size,files=len(selected));write_json(dest/'results.json',result)
before=shutil.disk_usage(r).free;removed=[];tracked=tracked_paths(r)
for p in [o/'baseline-runtime',o/'tmp',o/'__pycache__']:
    if p.exists():removed.append(dict(path=str(p),result=remove_artifact(r/'build',p,tracked,apply=True)))
after=shutil.disk_usage(r).free;cleanup=dict(removed=removed,freeBefore=before,freeAfter=after,observedFreedBytes=after-before)
write_json(o/'cleanup.json',cleanup);write_json(dest/'cleanup.json',cleanup)
print(json.dumps(dict(package=result['package'],restoredBuilds=builds,cleanup=cleanup),indent=2))
