from pathlib import Path
import copy,hashlib,json,os,re,shutil,sys
import numpy as np
from PIL import Image
r=Path.cwd().resolve();o=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'tools'))
from artifact_maintenance import guarded_run,managed_environment
from build_provenance import digest,verify
import test_environment_specular_gpu as env
import test_projected_hair_gpu as hair
os.environ.update(managed_environment(o/'tmp'))
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1',VK_LOADER_DEBUG='error,layer',VK_LOADER_DRIVERS_SELECT='*nv-vk64*')
os.environ.pop('VK_LAYER_ENABLES',None);b=r/'build/ninja-msvc-release';os.environ['PATH']=str(b)+';'+os.environ['PATH']
verify(r,json.loads((b/'build-provenance.json').read_text()))
reference=json.loads((r/'tests/fixtures/environment_specular/gpu_reference.json').read_text())['cases'][0]
rows=[]
for kind in ['pbr','hair']:
    for scene in [False,True]:
        name=('scene-' if scene else 'presentation-')+kind;folder=o/'controls'/name
        if kind=='pbr':project=env.fixture(folder,copy.deepcopy(reference))
        else:
            case=copy.deepcopy(hair.cases()[0])
            for side in ['left','right']:case[side].update(surfaceScale=.6,specularScale=1)
            prepared=hair.prepare(case,folder);project=prepared[0] if isinstance(prepared,tuple) else prepared
        levelPath=folder/'assets/scene.azurelevel';level=json.loads(levelPath.read_text());level['renderSettings']['sceneLighting']=scene
        levelPath.write_text(json.dumps(level));frozen={str(p):digest(p) for p in folder.rglob('*') if p.is_file()}
        images={};roleRows=[]
        for role,runtime in [('baseline',o/'baseline-runtime'),('candidate',b)]:
            target=folder/role;target.mkdir();command=[str(runtime/'AzurePlayer.exe'),'--project',str(project),'--resource-root',str(runtime),'--width','128','--height','128','--capture-frames','1','--capture-dir',str(target/'frames'),'--fixed-frame-step','--qa-camera','scene','--qa-light','scene']
            if kind=='pbr':command+=['--environment',str(folder/'assets/global.azenv')]
            (target/'command.json').write_text(json.dumps(command,indent=2));execution=guarded_run(r/'build',o.name,command,180)
            shutil.copyfile(o/'process.log',target/'process.log');assert execution['exitCode']==0,execution
            log=(target/'process.log').read_text(errors='replace');assert re.search(r'Insert.*VK_LAYER_KHRONOS_validation',log,re.I)
            assert not any(t in log for t in ['Validation Error:','Validation Warning:','SYNC-HAZARD','VUID-']) and 'Allocator after unload: buffers=0 images=0' in log
            p=target/'frames/frame_000000.png';images[role]=np.asarray(Image.open(p).convert('RGB'));roleRows.append(dict(role=role,execution=execution,sha256=digest(p)))
        delta=np.abs(images['candidate'].astype('i2')-images['baseline'].astype('i2'));changed=int(np.any(delta,axis=2).sum())
        rows.append(dict(name=name,roles=roleRows,changedPixels=changed,maximumByteDifference=int(delta.max()),baselinePeakByte=int(images['baseline'].max()),inputsUnchanged=all(digest(Path(p))==s for p,s in frozen.items())))
        (o/'controls.json').write_text(json.dumps(rows,indent=2));print(name,changed,'pixels',flush=True)
        assert changed==0 and rows[-1]['inputsUnchanged'] and rows[-1]['baselinePeakByte']>0
print('Four mode and material controls byte-exact',flush=True)
