import json
from pathlib import Path
import numpy as np
run=Path(__file__).resolve().parent;root=run.parents[2];source=root/'build/runs/20261026-062121-cloth-specular-ramp-capture-0e33fc';rows=[];weights=np.array([.21267290413379669,.7151522040367126,.07217500358819962]);cb1=np.fromfile(run/'native-bindings/e868/cb1.bin',dtype='<f4').reshape(-1,4);cb6=np.fromfile(run/'native-bindings/e868/cb6.bin',dtype='<f4').reshape(-1,4)
def sat(v,amount):return np.dot(v,weights)+(v-np.dot(v,weights))*amount
def response(base,metal,scale,ramp,litMask,aoMask,mix,scene):
 lit=base*(.96*(1-metal));shadow=lit*scale;shadowColor=sat(.65*shadow,1.2)*(1-mix)+shadow*mix;untinted=shadowColor*(1-litMask)+lit*litMask;chroma=ramp[:3].max()-ramp[:3].min();tinted=untinted*(1-chroma+ramp[:3]*chroma);indoor=shadow*(1-aoMask)+sat(lit,1.2)*aoMask;outdoor=tinted*np.clip(np.dot(untinted,weights)/max(np.dot(tinted,weights),.001),0,1.5);return indoor*(1-scene)+outdoor*scene
for record in json.loads((source/'native-trace-export.json').read_text())['traces']:
 trace=json.loads((source/record['path']).read_text());registers={};snapshots={}
 for state in trace['states']:
  for change in state['changes']:registers[change['after']['name']]=np.asarray(change['after']['float32_view'],dtype=float)
  if state['next_instruction'] in [1077,1098]:snapshots[state['next_instruction']]={k:v.copy() for k,v in registers.items()}
 a=snapshots[1077];b=snapshots[1098];base=a['r5'][:3];metal=1-a['r3'][0]/.96;ramp=a['r27'];litMask=a['r14'][3];aoMask=a['r11'][2];viewAlpha=a['r10'][3];scene=a['r3'][3];native=b['r22'][:3];scale=float(cb6[4,2]*cb1[110,2]);decoded=response(base,metal,scale,ramp,litMask,aoMask,np.clip(viewAlpha*aoMask+ramp[3],0,1),scene);current=response(base,metal,.5,ramp,litMask,aoMask,np.clip(aoMask+ramp[3],0,1),scene);candidate=response(base,metal,scale,ramp,litMask,aoMask,np.clip(aoMask+ramp[3],0,1),scene);error=float(np.max(abs(decoded-native)));assert error<1e-6
 rows.append(dict(pixel=trace['pixel'],combinedShadowScale=scale,sourceShadowAlbedoError=float(np.max(abs(a['r8'][:3]-base*a['r3'][0]*cb6[4,2]))),decodedResponseError=error,currentProfileResponseError=float(np.max(abs(current-native))),candidateProfileResponseError=float(np.max(abs(candidate-native))),nativeShadowMix=float(np.clip(viewAlpha*aoMask+ramp[3],0,1)),currentShadowMix=float(np.clip(aoMask+ramp[3],0,1))))
report=dict(status='verified-cloth4-diffuse-intermediates',points=rows,absoluteErrorBudget=1e-6,qualification='Source color-response reconstruction only; hardware composition and complete appearance remain separate.');(run/'cloth4-diffuse-proof.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(rows,indent=2))
