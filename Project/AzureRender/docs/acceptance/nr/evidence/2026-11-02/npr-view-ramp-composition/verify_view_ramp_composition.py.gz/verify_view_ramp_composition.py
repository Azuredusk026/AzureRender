import hashlib,json
from pathlib import Path
import numpy as np
run=Path(__file__).resolve().parent;root=run.parents[2]
old=root/'build/runs/20261026-062121-cloth-specular-ramp-capture-0e33fc'
luma=np.array([.21267290413379669,.7151522040367126,.07217500358819962])
sat=lambda x:np.dot(x,luma)+(x-np.dot(x,luma))*1.2000000476837158
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cases=[]
for row in json.loads((old/'native-trace-export.json').read_text())['traces']:
    cases.append((868,old/row['path'],'float32_view'))
for event in [889,910,928,1383]:cases.append((event,run/f'variant-trace-{event}.json','float32'))
rows=[]
for event,path,key in cases:
    trace=json.loads(path.read_text());regs={};snaps={}
    begin,indoorAt,end,maskAt={868:(1077,1089,1098,1100),889:(1090,1102,1111,1113),
        910:(1205,1217,1226,1228),928:(1205,1217,1226,1228),1383:(1409,1421,1430,1432)}[event]
    for state in trace['states']:
        for change in state['changes']:
            value=change['after'];regs[value['name']]=np.array(value[key],dtype=float)
        if state['next_instruction'] in [begin,indoorAt,end,maskAt]:
            snaps[state['next_instruction']]={n:v.copy() for n,v in regs.items()}
    a=snaps[begin];b=snaps[indoorAt];c=snaps[end];d=snaps[maskAt]
    if event==868:
        lit=a['r5'][:3]*a['r3'][0];shadow=a['r8'][:3]*.550000011920929
        ramp=a['r27'];raw=a['r11'][2];alpha=a['r10'][3];litMask=a['r14'][3];scene=a['r3'][3]
        nativeIndoor=b['r23'][[0,2,3]];native=c['r22'][:3];nativeMask=d['r4'][3]
    elif event==889:
        lit=a['r5'][:3]*a['r3'][0];shadow=a['r8'][:3]*.550000011920929
        ramp=a['r28'];raw=a['r11'][3];alpha=a['r10'][1];litMask=a['r14'][3];scene=a['r3'][3]
        nativeIndoor=b['r24'][[0,2,3]];native=c['r23'][:3];nativeMask=d['r4'][3]
    elif event in [910,928]:
        lit=a['r6'][:3]*a['r5'][1];shadow=a['r9'][:3]*.550000011920929
        ramp=a['r30'];raw=a['r16'][3];alpha=a['r15'][3];litMask=a['r20'][3];scene=a['r7'][3]
        nativeIndoor=b['r26'][[0,2,3]];native=c['r25'][:3];nativeMask=d['r8'][3]
    else:
        lit=a['r5'][:3]*a['r3'][0];shadow=a['r8'][:3]*.550000011920929
        ramp=a['r27'];raw=a['r13'][3];alpha=a['r11'][3];litMask=a['r15'][3];scene=a['r4'][3]
        nativeIndoor=b['r23'][:3];native=c['r22'][:3];nativeMask=d['r6'][3]
    weighted=alpha*raw;mix=np.clip(weighted+ramp[3],0,1)
    shade=sat(shadow*.64999997615814209)*(1-mix)+shadow*mix
    untinted=shade*(1-litMask)+lit*litMask;chroma=ramp[:3].max()-ramp[:3].min()
    tinted=untinted*(1-chroma+ramp[:3]*chroma)
    outdoor=tinted*np.clip(np.dot(untinted,luma)/max(np.dot(tinted,luma),.001),0,1.5)
    indoor=shadow*(1-weighted)+sat(lit)*weighted
    result=indoor*(1-scene)+outdoor*scene
    fullMask=weighted*(1-scene)+litMask*scene
    errors=dict(indoor=float(np.max(abs(indoor-nativeIndoor))),color=float(np.max(abs(result-native))),fullMask=float(abs(fullMask-nativeMask)))
    rows.append(dict(event=event,trace=str(path.relative_to(root)),traceSha256=sha(path),pixel=trace['pixel'],
        rawAoMask=float(raw),viewRampAlpha=float(alpha),indoorAoMask=float(weighted),sceneVisibility=float(scene),
        shadowMix=float(mix),errors=errors,defaultIndoorError=float(np.max(abs(shadow*(1-raw)+sat(lit)*raw-nativeIndoor)))))
    assert max(errors.values())<1e-6,(event,errors)
report=dict(status='verified-native-view-ramp-composition',absoluteErrorBudget=1e-6,points=rows,
    qualification='Actual native intermediate color, indoor composition and full-diffuse mask; hardware full-frame appearance remains separate.')
(run/'view-ramp-composition-proof.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],points=len(rows),maxima={k:max(r['errors'][k] for r in rows) for k in ['indoor','color','fullMask']},defaultIndoorMaximum=max(r['defaultIndoorError'] for r in rows))))
