"""Exercise the original maintenance-room switch in the normal Player."""
from argparse import ArgumentParser
from hashlib import file_digest
import json
import os
from pathlib import Path
import re
import subprocess
import sys

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent
ENGINE = ROOT.parents[2]
sys.path.insert(0,str(ENGINE/'tools'))
import test_screen_space_reflections_gpu as mirror

HOST = ROOT.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'/'msaa-release'
FRAMES = 12
FPS = 60
KEY = 70
INPUT = [dict(frame=4,action='key',key=KEY,down=True),dict(frame=5,action='key',key=KEY,down=False)]
PLATE_LEFT = [mirror.LEFT,mirror.TARGET_Y,0]
PLATE_RIGHT = [mirror.RIGHT,mirror.TARGET_Y,0]
LIGHT_LEFT = [-2.0,1.1,1.1]
LIGHT_RIGHT = [1.75,1.1,1.1]
WITNESS = [1.75,.75,0]
WITNESS_HALF = .24
CASES = (('switch-reflection',True,'reflection'),('idle-reflection',False,'reflection'),('switch-beauty',True,'beauty'))

SWITCH = """function interact(actor)
    local plate = self:find('guide-plate')
    local lamp = self:find('inspection-lamp')
    if actor ~= 'technician' or self:get('azure.door', 'open') then return end
    plate:set('azure.transform', 'translation', {0.7, 1, 0})
    lamp:set('azure.transform', 'translation', {1.75, 1.1, 1.1})
    self:set('azure.door', 'open', true)
    self:set('azure.interactable', 'prompt', 'Inspection route active')
end
"""


def load(path):
    return json.loads(path.read_bytes())


def write(path,value):
    mirror.write_json(path,value)


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def node(key, location, **components):
    values = {'azure.transform':mirror.component('azure.transform',dict(translation=location))}
    values.update({kind:mirror.component(kind,data) for kind,data in components.items()})
    return dict(id=key,components=values)


def prepare(path,action):
    project, _ = mirror.prepare(path,dict(name='maintenance-room',algorithm='projected'))
    configuration = load(project)
    configuration.update(id='maintenance-reflection-room',name='Guide Plate Inspection',runtime={
        'schemaVersion':1,'input':{'activate-route':[KEY]},
        'systems':[dict(id='interaction',config=dict(actor='technician',action='activate-route'))]})
    write(project,configuration)
    assets=path/'assets'
    level_path=assets/'scene.azurelevel'
    level=load(level_path)
    level.update(id='maintenance-reflection-room')
    level['nodes'][1]['id']='guide-plate'
    level['nodes'].extend([
        node('technician',[0,.8,2]),
        node('route-switch',[.2,.8,1.65],**{
            'azure.interactable':dict(range=2,prompt='Activate guide plate [F]'),
            'azure.script':dict(asset='assets:/switch.lua'),
            'azure.door':dict(requiredCount=1,open=False)}),
        node('inspection-lamp',LIGHT_LEFT),
    ])
    level['lights']=[dict(id='inspection-light',nodeId='inspection-lamp',color=[1,.94,.82],intensity=12,radius=2.7,enabled=True)]
    wall=dict(doubleSided=False,pbrMetallicRoughness=dict(baseColorFactor=[.62,.62,.62,1],
              metallicFactor=0,roughnessFactor=1))
    h=WITNESS_HALF
    mirror.gltf(assets/'inspection-card.gltf',[[-h,-h,0],[h,-h,0],[h,h,0],[-h,h,0]],[0,0,1],wall)
    level['resources'].append(dict(id='inspection-card',asset='assets:/inspection-card.gltf'))
    witness=node('inspection-card',WITNESS)
    witness['resourceId']='inspection-card'
    level['nodes'].append(witness)
    write(level_path,level)
    (assets/'switch.lua').write_text(SWITCH,encoding='utf-8')
    write(path/'actions.json',dict(schemaVersion=1,actions=INPUT if action else []))
    return project


def start(name, action, view, driver):
    path=ROOT/name
    project=path/'project.azureproject'
    sources=[path/name for name in ('project.azureproject','expected.json','actions.json')]
    sources.extend(p for p in sorted((path/'assets').iterdir()) if p.is_file() and not p.name.endswith('.azmeta'))
    inputs={p.relative_to(path).as_posix():sha(p) for p in sources}
    command=[str(HOST/'AzurePlayer.exe'),'--project',str(project),'--width','320','--height','240',
             '--capture-dir',str(path/'frames'),'--capture-frames',str(FRAMES),'--capture-fps',str(FPS),
             '--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation',view,
             '--runtime-report',str(path/'runtime.json'),'--game-actions',str(path/'actions.json')]
    layer = 'VK_LAYER_KHRONOS_validation'
    layer_root = 'D:/Tools/VulkanSDK/1.4.350.0/Bin'
    env=dict(os.environ,VK_DRIVER_FILES=str(driver),VK_LAYER_PATH=layer_root,
             VK_INSTANCE_LAYERS=layer,VK_LOADER_DEBUG='layer',VK_LAYER_VALIDATE_SYNC='1')
    info=subprocess.STARTUPINFO()
    info.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    info.wShowWindow=0
    run=subprocess.run(command,cwd=ENGINE,env=env,capture_output=True,timeout=65,startupinfo=info)
    log=run.stdout+run.stderr
    (path/'player.log').write_bytes(log)
    write(path/'receipt.json',dict(name=name,action=action,isolation=view,command=command,inputSha256=inputs,
         exitCode=run.returncode,driverSha256=sha(driver),validationLayer=layer,
         layerManifestSha256=sha(Path(layer_root)/'VkLayer_khronos_validation.json'),
         layerBinarySha256=sha(Path(layer_root)/'VkLayer_khronos_validation.dll'),synchronizationValidation=True))
    assert run.returncode==0,(name,run.returncode,log[-1800:])
    assert not re.search(rb'VUID-|Validation (?:Error|Warning)|\[validation warning\]|\[error\]',log,re.I),name
    assert b'Allocator after unload: buffers=0 images=0' in log,name
    assert all(sha(path/key)==value for key,value in inputs.items()),name


def frames(path):
    png=sorted((path/'frames').glob('frame_*.png'))
    assert len(png)==FRAMES,(path,len(png))
    return [np.asarray(Image.open(p).convert('RGB')) for p in png]


def checks():
    result={}
    left=mirror.oracle(mirror.LEFT)
    right=mirror.oracle(mirror.RIGHT)
    masks=[mirror.polygon_mask(ref['reflectionPolygon'],.65) for ref in (left,right)]
    witness=mirror.polygon_mask(mirror.project(mirror.target_corners(WITNESS[0])+[0,WITNESS[1]-mirror.TARGET_Y,0]),.35)
    assert witness.any()
    for name,action,view in CASES:
        path=ROOT/name
        images=frames(path)
        log=(path/'player.log').read_bytes()
        assert re.search(rb'Insert instance layer "VK_LAYER_KHRONOS_validation"',log),name
        assert not re.search(rb'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[validation warning\]',log,re.I),name
        assert b'Allocator after unload: buffers=0 images=0' in log,name
        meta=load(path/'frames/capture_manifest.json')
        route=load(path/'runtime.json')
        assert not route['scriptErrors'] and not route['presentationErrors'],(name,route['scriptErrors'],route['presentationErrors'])
        assert np.allclose(meta['qaCameraPosition'],mirror.CAMERA,atol=1e-5),name
        assert meta['screenReflectionAlgorithm']=='projected' and meta['screenReflectionHistoryValid'],name
        assert meta['screenReflectionProducer']=='projected-history',name
        assert route['replayedActions']==(len(INPUT) if action else 0),name
        timeline=route['routeFrames']
        assert timeline and not timeline[0]['doorOpen'],name
        state=[x['frame'] for x in timeline if x['doorOpen']]
        if action:
            assert state and INPUT[0]['frame']<=state[0]<=INPUT[0]['frame']+2,(name,state)
        else:
            assert not state,name
        nodes={node['id']:node for node in route['nodes']}
        assert np.allclose(nodes['guide-plate']['translation'],PLATE_RIGHT if action else PLATE_LEFT,atol=1e-6),name
        assert np.allclose(nodes['inspection-lamp']['translation'],LIGHT_RIGHT if action else LIGHT_LEFT,atol=1e-6),name
        linear=[mirror.linear(img) for img in images]
        patches=[[float(np.maximum(rgb[...,0]-.5*(rgb[...,1]+rgb[...,2]),0)[mask].mean())
                  for mask in masks] for rgb in linear]
        lighting=[float((rgb[...,0]*.2126+rgb[...,1]*.7152+rgb[...,2]*.0722)[witness].mean()) for rgb in linear]
        result[name]=dict(stateFrames=state,replayedActions=route['replayedActions'],fixedSteps=route['fixedSteps'],
            producer=meta['screenReflectionProducer'],historyInput=meta['screenReflectionHistoryInputSubmission'],
            redReflectionMeans=patches,lightingWitnessMean=lighting)
    write(ROOT/'measurements.json',result)
    idle=result['idle-reflection']['redReflectionMeans']
    live=result['switch-reflection']['redReflectionMeans']
    lit=result['switch-beauty']['lightingWitnessMean']
    gate=mirror.BUDGETS['minimumRedSignal']
    assert live[2][0]-live[2][1]>gate,(live,'initial reflection')
    assert live[-1][1]-live[-1][0]>gate,(live,'final reflection')
    assert idle[-1][0]-idle[-1][1]>gate,(idle,'idle reflection')
    assert live[-1][1]-idle[-1][1]>gate,(live,idle,'right reflection gain')
    assert idle[-1][0]-live[-1][0]>gate,(live,idle,'left reflection loss')
    assert lit[-1]-lit[2]>.015,(lit,'local light gain')
    print('PASS: switch state, reflection move, idle witness and lighting change')


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=('prepare','run','verify'))
    args=parser.parse_args()
    if args.operation=='prepare':
        for name,action,_ in CASES:
            prepare(ROOT/name,action)
    elif args.operation=='run':
        driver=ROOT.parent/'20261112-231945-projected-hair-reference-grid-4b775d'/'nv-vk64-active-absolute.json'
        retained=load(ROOT.parent/'20261119-220148-nr-player-same-frame-capture-31bfb3'/'request.json')
        assert sha(HOST/'AzurePlayer.exe')==retained['playerSha256']
        assert {p.name:sha(p) for p in (HOST/'shaders').glob('*.spv')}==retained['shaders']
        for name,action,view in CASES:
            start(name,action,view,driver)
        checks()
    else:
        checks()


if __name__=='__main__':
    main()

