"""Recompute the original switch evidence and verify the shared timeline."""
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
subprocess.run([sys.executable,'-B',str(ROOT/'switch_fixture.py'),'verify'],check=True)
measurements=json.loads((ROOT/'measurements.json').read_bytes())
beauty=measurements['switch-beauty']
idle=measurements['idle-reflection']
regions=beauty['redReflectionMeans']
light=beauty['lightingWitnessMean']
assert beauty['stateFrames'][0]==4
assert idle['stateFrames']==[]
assert all(v==idle['redReflectionMeans'][0] for v in idle['redReflectionMeans'])
assert regions[3][0]>.003 and not regions[3][1]
assert regions[4]==[0,0] and light[4]-light[3]>.015
assert regions[5][1]>.003 and not regions[5][0]
assert regions[5][1]-regions[5][0]>.003 and light[5]-light[3]>.015
assert all(v==regions[5] for v in regions[5:])
print('PASS: normal beauty contains both signals at frame 5; frame 4 records the transition')
