"""Read the two endpoint probes across the actual matched reflection regions."""
from hashlib import sha256
import json
import os
from pathlib import Path
import traceback
import zlib

import renderdoc as rd

ROOT=Path(os.environ['AZR_REFLECTION_REGIONAL_ROOT'])
REQUEST=json.loads((ROOT/'request.json').read_bytes())
SLOTS={
    'native':('read:1:texture1','read:2:texture2','read:3:texture3','write:0:uav0','write:1:uav1','write:2:uav2'),
    'player':('read:2:previousColor','read:3:previousDepth','read:4:currentDepth','write:9:outputColor','write:10:outputFootprint','write:11:outputConfidence'),
}


def write(path,data):
    (ROOT/path).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


def digest(raw):
    return sha256(raw).hexdigest()


def snapshot(ctl, resource):
    return bytes(ctl.GetTextureData(resource,rd.Subresource()))


def binding(pipe,stage,shader):
    for kind,used,decls in (('read',pipe.GetReadOnlyResources(stage),shader.readOnlyResources),
                            ('write',pipe.GetReadWriteResources(stage),shader.readWriteResources)):
        for item in used:
            d=item.descriptor
            dec=decls[item.access.index]
            if d.resource!=rd.ResourceId.Null():
                yield '{}:{}:{}'.format(kind,dec.fixedBindNumber,dec.name),d


def crop(data,label,width,height,bpp):
    x,y,r,b=REQUEST['crop']
    assert (width,height)==(1280,720)
    rows=range(y,b) if label=='player' else range(height-1-y,height-1-b,-1)
    return b''.join(data[(width*line+x)*bpp:(width*line+r)*bpp] for line in rows)


def save(name,data):
    encoded=zlib.compress(data,6)
    path=ROOT/(name+'.zlib')
    path.write_bytes(encoded)
    return dict(file=path.name,bytes=len(data),sha256=digest(data),encodedSha256=digest(encoded))


def read(label,job):
    cap=rd.OpenCaptureFile()
    ctl=None
    try:
        assert cap.OpenFile(job['capture'],'',None)==rd.ResultCode.Succeeded
        replay=rd.ReplayOptions()
        replay.forceGPUVendor=rd.GPUVendor.nVidia
        replay.forceGPUDeviceID=0x28e0
        status,ctl=cap.OpenCapture(replay,None)
        assert status==rd.ResultCode.Succeeded and not ctl.GetAPIProperties().degraded
        assert ctl.GetFrameInfo().frameNumber==job['frame']
        event=job['trace']['event']
        ctl.SetFrameEvent(event,True)
        pipe=ctl.GetPipelineState()
        stage=rd.ShaderStage.Compute
        shader=pipe.GetShaderReflection(stage)
        original=pipe.GetShader(stage)
        assert digest(bytes(shader.rawBytes))==job['expectedProgram']
        actual=dict(binding(pipe,stage,shader))
        assert set(actual)==set(job['trace']['bindings'])
        for key,expected in job['trace']['bindings'].items():
            value=actual[key]
            assert (str(value.resource),value.firstMip,value.numMips)==(expected['resource'],expected['firstMip'],expected['mipCount'])
        keys=('historyColor','historyDepth','currentDepth','color','footprint','confidence')
        formats={t.resourceId:t for t in ctl.GetTextures()}
        resources={name:actual[key].resource for name,key in zip(keys,SLOTS[label])}
        report=dict(frame=job['frame'],event=event,captureSha256=job['captureSha256'],
                    shader=job['expectedProgram'],control={},probes={})
        for n,key in zip(keys,SLOTS[label]):
            rid=resources[n]
            raw=snapshot(ctl,rid)
            t=formats[rid]
            expected=job['trace']['textures'][key][0]
            assert digest(raw)==expected['fullSha256']
            report['control'][n]=dict(resource=str(rid),format=t.format.Name(),fullSha256=digest(raw))
            if n in ('currentDepth','color','confidence'):
                bpp=len(raw)//(t.width*t.height)
                report['control'][n].update(save(label+'-'+n,crop(raw,label,t.width,t.height,bpp)))
        raw_outputs={n:report['control'][n]['fullSha256'] for n in ('color','footprint','confidence')}

        def outputs():
            return {name:digest(snapshot(ctl,resources[name])) for name in raw_outputs}

        encoding=rd.ShaderEncoding.SPIRV if label=='player' else rd.ShaderEncoding.DXBC
        for name,entry in REQUEST['programs'][label].items():
            bytecode=Path(entry['path']).read_bytes()
            assert digest(bytecode)==entry['sha256']
            target,error=ctl.BuildTargetShader(shader.entryPoint,encoding,bytecode,rd.ShaderCompileFlags(),stage)
            assert target!=rd.ResourceId.Null(),error
            try:
                ctl.ReplaceResource(original,target)
                ctl.SetFrameEvent(event,True)
                values=outputs()
                assert all(values[n]==raw_outputs[n] for n in ('color','confidence'))
                assert values['footprint']!=raw_outputs['footprint']
                region=crop(snapshot(ctl,resources['footprint']),label,1280,720,4)
                report['probes'][name]=dict(program=entry['sha256'],outputHashes=values,**save(label+'-'+name,region))
            finally:
                ctl.RemoveReplacement(original)
                ctl.FreeTargetResource(target)
        ctl.SetFrameEvent(event,True)
        report['restored']=outputs()
        assert report['restored']==raw_outputs
        prior=resources['historyColor']
        assert digest(snapshot(ctl,prior))==report['control']['historyColor']['fullSha256']
        return report
    finally:
        if ctl is not None:
            ctl.Shutdown()
        cap.Shutdown()


try:
    reports={}
    for label in ('native','player'):
        reports[label]=read(label,REQUEST['frames'][label])
        write('replay.json',reports)
except Exception:
    write('failure.json',dict(traceback=traceback.format_exc()))
    os._exit(1)
os._exit(0)
