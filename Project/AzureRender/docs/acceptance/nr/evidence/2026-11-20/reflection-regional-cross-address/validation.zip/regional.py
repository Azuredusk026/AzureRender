"""Score regional history lookup and observed temporal differences."""
import hashlib
from io import BytesIO
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile
import zlib

import numpy as np

ROOT=Path(__file__).resolve().parent
REQUEST=json.loads((ROOT/'request.json').read_bytes())
REPLAY=json.loads((ROOT/'replay.json').read_bytes())
X,Y,R,B=REQUEST['crop']
SHAPE=(B-Y,R-X)
WEIGHT=np.array([.2126,.7152,.0722])
NATIVE_FIXTURE='Project/AzureRender/docs/acceptance/nr/evidence/2026-10-29/reflection-temporal-fixture/'
REPO_EVIDENCE='Project/AzureRender/docs/acceptance/nr/evidence/2026-11-19/'


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def load_record(p):
    return json.loads(p.read_bytes())


def readback(folder,record):
    packed=(folder/record['file']).read_bytes()
    assert sha(packed)==record['encodedSha256']
    raw=zlib.decompress(packed)
    assert sha(raw)==record['sha256']
    if 'bytes' in record:
        assert len(raw)==record['bytes']
    return raw


def words(rgb):
    channels=[]
    for offset,mant in ((0,6),(11,6),(22,5)):
        p=(rgb>>offset)
        exponent=((p>>mant)&31).astype(int)
        assert np.all(exponent!=31)
        fraction=(p&((1<<mant)-1))/float(1<<mant)
        channels.append(np.where(exponent==0,np.ldexp(fraction,-14),np.ldexp(1+fraction,exponent-15)))
    return np.stack(channels,axis=-1)


def coordinates(packed,label,extent=(2560,1440)):
    t=packed.astype('f8')/65535
    size=np.array(extent)
    upper=np.minimum(np.floor((t+.5/65535)*size).astype(int),size-1)
    lower=np.maximum(np.floor((t-.5/65535)*size).astype(int),0)
    unique=np.all(upper==lower,axis=-1)
    xy=np.clip(np.floor(t*size).astype(int),0,size-1)
    if label=='native':
        xy[...,1]=size[1]-1-xy[...,1]
    return xy,unique


def gather():
    parent=ROOT.parent
    n=parent/'20261119-181852-nr-same-frame-reflection-lineage-ffb239'
    p=parent/'20261119-220148-nr-player-same-frame-capture-31bfb3'
    preread=load_record(n/'native-result.json')
    filter_record=preread['stages']['filter']['textures']['read:2:texture2'][0]
    aligned_ref=readback(n/'native',filter_record)
    assert filter_record['resource']=='ResourceId::16552'
    assert filter_record['rect']==[X,720-B,R,720-Y]
    history_reference=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261031-060648-ray-vulkan-a27711/frozen-inputs-portable/previousColor.bin').read_bytes()
    pv=load_record(p/'player-result.json')['stages']['trace']['textures']['read:2:previousColor'][0]
    history_player=readback(p/'player',pv)
    temporal_blob=subprocess.check_output(['git','show','560ecd2:'+NATIVE_FIXTURE+'fixture.zip'],cwd=ROOT.parents[2])
    receipt=json.loads(subprocess.check_output(['git','show','560ecd2:'+NATIVE_FIXTURE+'receipt.json'],cwd=ROOT.parents[2]))
    temporal_inputs=json.loads(subprocess.check_output(['git','show','560ecd2:'+NATIVE_FIXTURE+'temporal-inputs.json'],cwd=ROOT.parents[2]))
    assert receipt['frame']==3534 and sha(temporal_blob)==receipt['sha256']
    source={v['path']:v for v in temporal_inputs['textures']}
    assert filter_record['fullSha256']==source['temporal-color.bin']['sha256']
    with ZipFile(BytesIO(temporal_blob)) as z:
        temporal_raw=z.read('current-color.bin')
    assert sha(temporal_raw)==source['current-color.bin']['sha256']
    assert str(source['current-color.bin']['resource'])==REPLAY['native']['control']['color']['resource']
    ns=readback(ROOT,REPLAY['native']['control']['color'])
    raw_region=np.frombuffer(temporal_raw,'<u4').reshape(720,1280)[::-1][Y:B,X:R]
    images={}
    for label, data in (('native',history_reference),('player',history_player)):
        assert sha(data)==REPLAY[label]['control']['historyColor']['fullSha256']
        img=np.frombuffer(data,'<f2').reshape(1440,2560,4)
        images[label]=img[::-1] if label=='native' else img
    packed={}
    for label,row in REPLAY.items():
        assert row['restored']=={key:row['control'][key]['fullSha256'] for key in ('color','footprint','confidence')}
        job=REQUEST['frames'][label]
        assert row['captureSha256']==job['captureSha256'] and row['frame']==job['frame']
        for name in ('historyUv','hitUv'):
            probe=row['probes'][name]
            assert probe['program']==REQUEST['programs'][label][name]['sha256']
            assert all(probe['outputHashes'][key]==row['restored'][key] for key in ('color','confidence'))
            packed[label+'_'+name]=np.frombuffer(readback(ROOT,probe),'<u2').reshape(*SHAPE,2)
        for name,fmt in (('currentDepth','<f4'),('color','<u4'),('confidence','u1')):
            packed[label+'_'+name]=np.frombuffer(readback(ROOT,row['control'][name]),fmt).reshape(SHAPE)
    packed['native_temporal_input']=raw_region
    packed['native_temporal_output']=np.frombuffer(aligned_ref,'<u4').reshape(SHAPE)[::-1]
    assert packed['native_color'].tobytes()==ns
    for addr in images:
        xy,exact=coordinates(packed[addr+'_historyUv'],addr)
        x,y=xy.transpose(2,0,1)
        for label,img in images.items():
            packed[label+'_history_at_'+addr]=img[y,x,:3]
    proof=dict(temporalFixtureSha256=receipt['sha256'],input=source['current-color.bin'],output=source['temporal-color.bin'],
               filterFull=filter_record['fullSha256'])
    np.savez_compressed(ROOT/'samples.npz',**packed)
    (ROOT/'sources.json').write_text(json.dumps(proof,indent=2)+'\n')


def compression(rgb):
    vals=rgb.astype('f8')
    return vals/(1+np.max(vals,axis=-1,keepdims=True))


def encoded_compatible(compressed,observed):
    mant=np.array([6,6,5])
    exponent=np.maximum(-14,np.floor(np.log2(np.maximum(compressed,2.**-14))))
    precision=np.exp2(exponent-mant)
    return (abs(compressed-observed)<=precision+3e-7).all(axis=-1)


def median(v):
    return float(np.median(v)) if len(v) else None


def average(v):
    return float(np.mean(v)) if len(v) else None


def limits(label):
    c=REQUEST['frames'][label]['trace']['constants']
    p=np.frombuffer(bytes.fromhex(c[1 if label=='native' else 0]['hex']),'<f4').reshape(-1,4)
    v=p[2 if label=='native' else 24]
    return float(v[2]),float(v[3])


def score():
    results={}
    with np.load(ROOT/'samples.npz',allow_pickle=False) as load:
        a={n:load[n] for n in load.files}
    for label in ('native','player'):
        for name in ('historyUv','hitUv'):
            row=REPLAY[label]['probes'][name]
            assert sha(a[label+'_'+name].tobytes())==row['sha256']
        for name in ('currentDepth','color','confidence'):
            row=REPLAY[label]['control'][name]
            assert sha(a[label+'_'+name].tobytes())==row['sha256']
    authority=load_record(ROOT/'sources.json')
    assert authority['output']['sha256']==authority['filterFull']
    matched=np.ones(SHAPE,bool)
    depth={}
    display={}
    route={}
    available={}
    effective={}
    for label in ('native','player'):
        c0,c1=limits(label)
        d=a[label+'_currentDepth']
        depth[label]=np.where(d>0,1/(c0*d+c1),np.inf)
        display[label]=words(a[label+'_color'])
        route[label],available[label]=coordinates(a[label+'_historyUv'],label)
        effective[label]=encoded_compatible(compression(a[label+'_history_at_'+label]),display[label])
    with np.errstate(invalid='ignore'):
        matched=(abs(depth['native']-depth['player'])<=.02)&(a['native_confidence']>0)&(a['player_confidence']>0)
    sampled=matched&available['native']&available['player']&effective['native']&effective['player']
    hit={label:coordinates(a[label+'_hitUv'],label) for label in ('native','player')}
    ray_delta=np.linalg.norm(route['native']-route['player'],axis=-1)
    geometry_delta=hit['native'][0]-hit['player'][0]
    motion_delta=(route['native']-hit['native'][0])-(route['player']-hit['player'][0])
    assert np.array_equal(geometry_delta+motion_delta,route['native']-route['player'])
    same_pairs=sampled&hit['native'][1]&hit['player'][1]
    geometry_distance=np.linalg.norm(geometry_delta,axis=-1)
    motion_distance=np.linalg.norm(motion_delta,axis=-1)
    temporal_start=words(a['native_temporal_input'])@WEIGHT
    temporal_end=words(a['native_temporal_output'])@WEIGHT
    main_trace={label:rgb@WEIGHT for label,rgb in display.items()}
    signals={(src,rt):compression(a[src+'_history_at_'+rt])@WEIGHT
                  for src in ('native','player') for rt in ('native','player')}
    NN,NP,PN,PP=(signals[q] for q in (('native','native'),('native','player'),('player','native'),('player','player')))
    route_contribution=((NN-NP)+(PN-PP))*.5
    source_contribution=((NN-PN)+(NP-PP))*.5
    np.testing.assert_allclose((NN-PP)[sampled],(route_contribution+source_contribution)[sampled],atol=1e-12)
    for name,(x,y,r,b) in REQUEST['regions'].items():
        section=np.zeros(SHAPE,bool)
        section[y-Y:b-Y,x-X:r-X]=True
        both=section&matched
        valid=section&sampled
        assert np.count_nonzero(valid)>.7*np.count_nonzero(both)
        regions=[]
        for low,high in ((0,2),(2,8),(8,float('inf'))):
            which=valid&(ray_delta>=low)&(ray_delta<high)
            regions.append(dict(rangePx=[low,high if np.isfinite(high) else None],pixels=int(which.sum()),
                   currentMeanAbs=average(abs(NN-PP)[which]),nativeRouteOnBothMeanAbs=average(abs(NN-PN)[which]),
                   playerRouteOnBothMeanAbs=average(abs(NP-PP)[which]),
                   addressMeanAbs=average(abs(route_contribution)[which]),sourceMeanAbs=average(abs(source_contribution)[which])))
        pre=section&same_pairs
        transition=temporal_end-temporal_start
        residual_initial=temporal_start-main_trace['player']
        residual_final=temporal_end-main_trace['player']
        address=float(np.abs(route_contribution[valid]).sum())
        source=float(np.abs(source_contribution[valid]).sum())
        results[name]=dict(bounds=[x,y,r,b], matched=int(both.sum()),
            uniquelyReproduced=int(valid.sum()),medianAddressDifferencePixels=median(ray_delta[valid]),
            uniqueHitAndHistoryAddresses=int(pre.sum()),
            medianHitDifferencePixels=median(geometry_distance[pre]),
            medianReprojectionDifferencePixels=median(motion_distance[pre]),
            hitDistanceExceedsReprojectionDifference=int(np.count_nonzero((geometry_distance>motion_distance)&pre)),
            addressAbsoluteContributionFraction=address/(address+source),distanceBins=regions,
            nativeChangedBetweenPrimaryAndTemporalInput=int(np.count_nonzero((a['native_temporal_input']!=a['native_color'])&both)),
            nativeTemporalChanged=int(np.count_nonzero((a['native_temporal_input']!=a['native_temporal_output'])&both)),
            nativeTemporalMeanAbsoluteDelta=average(abs(transition)[both]),
            actualRawVsPlayerMeanAbsoluteResidual=average(abs(residual_initial)[both]),
            actualTemporalVsPlayerMeanAbsoluteResidual=average(abs(residual_final)[both]),
            nativeTemporalDeltaInSameDirection=int(((transition*residual_initial>0)&both).sum()))
    return results


if __name__=='__main__':
    capture=len(sys.argv)==2 and sys.argv[1]=='--record'
    if capture:gather()
    results=score()
    if capture:(ROOT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    else:assert results==load_record(ROOT/'results.json')
    print(json.dumps(results,indent=2))
    print('PASS: regional addresses, crossed history radiance and measured temporal increment')
