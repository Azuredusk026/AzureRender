"""Run one paired capture replay and an isolated driver availability check."""
from hashlib import file_digest
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
RUNS=ROOT.parent
PROBES=RUNS/'20261119-234745-nr-reflection-hit-history-address-d77bf2'
MANIFESTS=RUNS/'20261112-231945-projected-hair-reference-grid-4b775d'
SDK=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin/vulkaninfoSDK.exe')
QRENDERDOC=Path('D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe')


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


def write(name,value):
    (ROOT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def main():
    lease=load(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output']).resolve()==ROOT
    sources=load(PROBES/'request.json')
    request=dict(baseline='560ecd2',programs={},frames={},crop=[498,478,793,703],
        regions={'centerFloor':[505,495,775,585],'cyanRing':[520,530,635,590]},
        origin='display-top-left',probeName=['hitUv','historyUv'])
    for label, ext in (('native','.dxbc'),('player','.spv')):
        job=sources[label]
        capture=Path(job['capture'])
        assert sha(capture)==job['captureSha256']
        request['frames'][label]=job
        request['programs'][label]={}
        for name in request['probeName']:
            path=PROBES/(name+ext)
            assert sha(path)==job['probes'][name]
            request['programs'][label][name]=dict(path=str(path),sha256=sha(path))
    assert sha(QRENDERDOC)==sources['toolFingerprints']['qrenderdoc.exe']
    request['toolSha256']=sha(QRENDERDOC)
    write('request.json',request)
    info=subprocess.STARTUPINFO()
    info.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    info.wShowWindow=0
    driver=[]
    for key,name in (('reference','nv-vk64-absolute.json'),('active','nv-vk64-active-absolute.json')):
        path=MANIFESTS/name
        library=Path(load(path)['ICD']['library_path'])
        env=dict(os.environ)
        for var in ('VK_ICD_FILENAMES','VK_LOADER_DRIVERS_SELECT','VK_INSTANCE_LAYERS','VK_LAYER_ENABLES'):
            env.pop(var,None)
        env.update(VK_DRIVER_FILES=str(path),VK_LOADER_DEBUG='error,driver')
        cmd=[str(SDK),'--summary']
        with (ROOT/('driver-'+key+'.log')).open('wb') as out:
            proc=subprocess.run(cmd,env=env,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,timeout=30,startupinfo=info)
        driver.append(dict(label=key,exitCode=proc.returncode,manifest=str(path),manifestSha256=sha(path),
                           library=str(library),librarySha256=sha(library),sdkSha256=sha(SDK)))
        write('driver.json',driver)
    with (ROOT/'replay.log').open('wb') as log:
        subprocess.run([str(QRENDERDOC),'--python',str(ROOT/'regional_replay.py')],
            cwd=ROOT,env=dict(os.environ,AZR_REFLECTION_REGIONAL_ROOT=str(ROOT)),
            stdout=log,stderr=subprocess.STDOUT,timeout=180,startupinfo=info,check=True)


if __name__=='__main__':
    main()
