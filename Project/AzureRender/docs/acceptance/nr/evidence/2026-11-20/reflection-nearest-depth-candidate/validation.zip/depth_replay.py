"""Replay one changed depth preparation stage with original filter and materials."""
import hashlib
import json
import os
from pathlib import Path
import traceback
import zlib

import renderdoc as rd

ROOT=Path(os.environ['AZR_DEPTH_TEST_ROOT'])
REQ=json.loads((ROOT/'request.json').read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name,data):
    (ROOT/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


def snapshot(ctl,rid):
    return bytes(ctl.GetTextureData(rid,rd.Subresource()))


def publish(name,raw):
    enc=zlib.compress(raw,6)
    (ROOT/(name+'.zlib')).write_bytes(enc)
    return dict(file=name+'.zlib',sha256=sha(raw),encodedSha256=sha(enc),bytes=len(raw))


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


def bindings(ctl,stage,shader,write):
    pipe=ctl.GetPipelineState()
    used=pipe.GetReadWriteResources(stage) if write else pipe.GetReadOnlyResources(stage)
    desc=shader.readWriteResources if write else shader.readOnlyResources
    return {desc[r.access.index].name:r.descriptor.resource for r in used}


def replay():
    cap=rd.OpenCaptureFile()
    ctl=None
    result=dict(status='started')
    try:
        assert cap.OpenFile(REQ['capture']['path'],'',None)==rd.ResultCode.Succeeded
        opts=rd.ReplayOptions()
        opts.forceGPUVendor=rd.GPUVendor.nVidia
        opts.forceGPUDeviceID=0x28e0
        status,ctl=cap.OpenCapture(opts,None)
        assert status==rd.ResultCode.Succeeded and not ctl.GetAPIProperties().degraded
        assert ctl.GetFrameInfo().frameNumber==REQ['frame']
        textures={str(t.resourceId):t for t in ctl.GetTextures()}
        display=textures['ResourceId::154']
        assert (display.width,display.height)==(2560,1440)
        end=list(walk(ctl.GetRootActions()))[-1].eventId
        cs=rd.ShaderStage.Compute

        def shader(event):
            ctl.SetFrameEvent(event,True)
            return ctl.GetPipelineState().GetShaderReflection(cs)

        ref=shader(REQ['stage'])
        original=ctl.GetPipelineState().GetShader(cs)
        assert sha(bytes(ref.rawBytes))==REQ['programs']['control']
        prepared=bindings(ctl,cs,ref,True)
        assert set(prepared)==set(REQ['outputs'])
        surface=bindings(ctl,cs,ref,False)['sourceSurface']
        const=ctl.GetPipelineState().GetConstantBlock(cs,0,0).descriptor
        raw_const=bytes(ctl.GetBufferData(const.resource,const.byteOffset,32))
        assert len(raw_const)==32
        raw_surface=snapshot(ctl,surface)
        assert len(raw_surface)==2560*1440*16
        sourceR=bytearray(2560*1440*4)
        for i in range(4):
            sourceR[i::4]=raw_surface[i::16]
        result['source']=dict(resource=str(surface),fullSha256=sha(raw_surface),parameters=raw_const.hex(),
                              sha256Parameters=sha(raw_const),linearDepth=publish('surfaceDepth',sourceR))
        ref2=shader(REQ['trace'])
        trace=bindings(ctl,cs,ref2,True)
        wanted={'outputColor','outputConfidence','outputFootprint'}
        trace={key:rid for key,rid in trace.items() if key in wanted}
        assert set(trace)==wanted
        ref3=shader(REQ['filter'])
        filtered=bindings(ctl,cs,ref3,True)
        assert len(filtered)==1
        rid_filter=next(iter(filtered.values()))

        def sample():
            def step(event,slots):
                ctl.SetFrameEvent(event,True)
                return {name:snapshot(ctl,rid) for name,rid in slots.items()}
            out=step(REQ['stage'],prepared)
            out.update(step(REQ['trace'],trace))
            out.update(step(REQ['filter'],{'filtered':rid_filter}))
            ctl.SetFrameEvent(end,True)
            raw=snapshot(ctl,display.resourceId)
            rgb=bytearray(2560*1440*3)
            order=(2,1,0) if display.format.Name().startswith('B8G8') else (0,1,2)
            for i,p in enumerate(order):
                rgb[i::3]=raw[p::4]
            out['display']=bytes(rgb)
            return out

        baseline=sample()
        assert sha(baseline['display'])==REQ['originalDisplayRgbSha256']
        program=(ROOT/'candidate.spv').read_bytes()
        assert sha(program)==REQ['programs']['candidate']
        target,error=ctl.BuildTargetShader(ref.entryPoint,rd.ShaderEncoding.SPIRV,program,rd.ShaderCompileFlags(),cs)
        assert target!=rd.ResourceId.Null(),error
        try:
            ctl.ReplaceResource(original,target)
            candidate=sample()
            for name in ('preparedNormal','preparedMask','initialEligibility'):
                assert baseline[name]==candidate[name],name
            assert baseline['preparedDepth']!=candidate['preparedDepth']
            result['outputs']={}
            for name in baseline:
                record=dict(controlSha256=sha(baseline[name]),candidateSha256=sha(candidate[name]),
                    differenceBytes=sum(a!=b for a,b in zip(baseline[name],candidate[name])))
                if name=='preparedDepth':
                    record.update(control=publish('controlDepth',baseline[name]),candidate=publish('candidateDepth',candidate[name]))
                if name=='display' and record['differenceBytes']:
                    record['candidate']=publish('candidateDisplay',candidate[name])
                result['outputs'][name]=record
        finally:
            ctl.RemoveReplacement(original)
            ctl.FreeTargetResource(target)
        assert sample()==baseline
        result.update(status='verified',restored=True,resources={name:str(r) for name,r in prepared.items()},
            traceResources={name:str(r) for name,r in trace.items()},filterResource=str(rid_filter))
    finally:
        save('replay.json',result)
        if ctl is not None:
            ctl.Shutdown()
        cap.Shutdown()


try:
    replay()
except Exception:
    save('failure.json',dict(traceback=traceback.format_exc()))
    os._exit(1)
os._exit(0)
