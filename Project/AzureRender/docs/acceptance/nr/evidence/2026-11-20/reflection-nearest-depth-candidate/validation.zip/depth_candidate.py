"""Build and run a diagnostic reduction candidate with a frozen Player capture."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
ENGINE=ROOT.parents[2]
HALL=ROOT.parent/'20261119-220148-nr-player-same-frame-capture-31bfb3'
TOOLS=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
QRENDERDOC=Path('D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe')


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def prepare():
    held=read(HALL/'request.json')
    control=(ENGINE/'shaders/projected_reflection_prepare.comp').read_bytes()
    target=b'imageStore(preparedDepth,p,vec4(valid?depth:0));'
    new=b'''float searchDepth=valid?depth:0;
    if(all(equal(ivec2(frame.extent.zw),2*ivec2(frame.extent.xy)))){
        // Preserve the nearest eligible depth for ray intersection at half size.
        for(int dy=0;dy!=2;++dy)for(int dx=0;dx!=2;++dx){
            float linear=texelFetch(sourceSurface,2*p+ivec2(dx,dy),0).r;
            if(linear>0&&linear<100000){
                float candidate=(1/linear-frame.decode.y)/frame.decode.x;
                if(candidate>=0&&candidate<=1)searchDepth=max(searchDepth,candidate);
            }
        }
    }
    imageStore(preparedDepth,p,vec4(searchDepth));'''
    assert control.count(target)==1
    programs={}
    for name,data in (('control',control),('candidate',control.replace(target,new))):
        src=ROOT/(name+'.comp')
        binary=ROOT/(name+'.spv')
        src.write_bytes(data)
        subprocess.run([str(TOOLS/'glslc.exe'),'-I',str(ENGINE/'shaders'),str(src),'-o',str(binary)],check=True,timeout=50)
        subprocess.run([str(TOOLS/'spirv-val.exe'),'--target-env','vulkan1.1',str(binary)],check=True,timeout=30)
        programs[name]=sha(binary)
    assert programs['control']==held['shaders']['projected_reflection_prepare.comp.spv'],programs
    patch=subprocess.run(['git','diff','--no-index','--','control.comp','candidate.comp'],cwd=ROOT,capture_output=True)
    assert patch.returncode==1
    (ROOT/'candidate.patch').write_bytes(patch.stdout)
    regional=read(ENGINE/'docs/acceptance/nr/evidence/2026-11-19/reflection-confidence-lod/qualification.json')
    prior=read(HALL/'frame-identity.json')['rows'][1]
    request=dict(base='0f7779f', hypothesis='Nearest depth alone reduces ray miss and address difference at unchanged receiver surfaces.',
        outputs=['preparedDepth','preparedNormal','preparedMask','initialEligibility'],
        stage=21055,trace=21062,filter=21123,frame=1,capture=read(HALL/'capture-receipt.json')['capture'],
        programs=programs,compilerSha256=sha(TOOLS/'glslc.exe'),validatorSha256=sha(TOOLS/'spirv-val.exe'),
        renderdocSha256=sha(QRENDERDOC),reference=regional['reference'],referenceSha256=regional['referenceSha256'],
        rectangles=regional['rectangles'],gates=regional['regionalGates'],
        originalDisplayRgbSha256=prior['rgbSha256'],baselinePng=str(HALL/'capture/frames/frame_000001.png'))
    write(ROOT/'request.json',request)


def execute():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output']).resolve()==ROOT
    req=read(ROOT/'request.json')
    assert sha(Path(req['capture']['path']))==req['capture']['sha256']
    startup=subprocess.STARTUPINFO()
    startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=0
    with (ROOT/'worker.log').open('wb') as log:
        subprocess.run([str(QRENDERDOC),'--python',str(ROOT/'depth_replay.py')],cwd=ROOT,check=True,timeout=180,
            env=dict(os.environ,AZR_DEPTH_TEST_ROOT=str(ROOT)),startupinfo=startup,stdout=log,stderr=subprocess.STDOUT)


if __name__=='__main__':
    {'prepare':prepare,'execute':execute}[sys.argv[1]]()
