"""Recompute preparation and strict hall measurements for the depth candidate."""
import hashlib
import json
from pathlib import Path
import sys
import zlib

import numpy as np
from PIL import Image
from measure_reference import measure

ROOT=Path(__file__).resolve().parent
REQ=json.loads((ROOT/'request.json').read_bytes())
REPLAY=json.loads((ROOT/'replay.json').read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def readback(meta):
    enc=(ROOT/meta['file']).read_bytes()
    assert sha(enc)==meta['encodedSha256']
    raw=zlib.decompress(enc)
    assert len(raw)==meta['bytes'] and sha(raw)==meta['sha256']
    return raw


def gather():
    reference=Path(REQ['reference'])
    assert sha(reference.read_bytes())==REQ['referenceSha256']
    with Image.open(reference) as img:
        reference=np.asarray(img.convert('RGB'))
    with Image.open(REQ['baselinePng']) as img:
        baseline=np.asarray(img.convert('RGB'))
    assert sha(baseline.tobytes())==REQ['originalDisplayRgbSha256']
    display=REPLAY['outputs']['display']
    candidate=np.frombuffer(readback(display['candidate']),'u1').reshape(baseline.shape) if display['differenceBytes'] else baseline
    assert sha(candidate.tobytes())==display['candidateSha256']
    y,x=np.where(np.any(candidate!=baseline,axis=-1))
    arrays=dict(x=x,y=y,reference=reference[y,x],control=baseline[y,x],candidate=candidate[y,x])
    for name in ('centerFloor','cyanRing'):
        l,t,r,b=REQ['rectangles'][name]
        for kind,img in (('reference',reference),('control',baseline),('candidate',candidate)):
            arrays[name+'_'+kind]=img[t:b,l:r]
    np.savez_compressed(ROOT/'hall.npz',**arrays)


def depth():
    assert REPLAY['status']=='verified' and REPLAY['restored']
    o=REPLAY['outputs']
    assert all(o[k]['differenceBytes']==0 for k in ('preparedNormal','preparedMask','initialEligibility'))
    source=REPLAY['source']
    const=bytes.fromhex(source['parameters'])
    assert sha(const)==source['sha256Parameters']
    w,h,sw,sh=map(int,np.frombuffer(const,'<f4')[:4])
    a,b=np.frombuffer(const,'<f4')[4:6]
    assert (w,h,sw,sh)==(1280,720,2560,1440)
    linear=np.frombuffer(readback(source['linearDepth']),'<f4').reshape(sh,sw)
    with np.errstate(divide='ignore',invalid='ignore'):
        decoded=(np.float32(1)/linear-b)/a
    decoded=np.where((linear>0)&(linear<100000)&(decoded>=0)&(decoded<=1),decoded,0)
    control=np.frombuffer(readback(o['preparedDepth']['control']),'<f4').reshape(h,w)
    candidate=np.frombuffer(readback(o['preparedDepth']['candidate']),'<f4').reshape(h,w)
    assert sha(control.tobytes())==o['preparedDepth']['controlSha256']
    assert sha(candidate.tobytes())==o['preparedDepth']['candidateSha256']
    max_depth=decoded.reshape(h,2,w,2).max(axis=(1,3))
    np.testing.assert_array_max_ulp(candidate,max_depth,maxulp=2)
    assert np.all(candidate>=control)
    changed=candidate!=control
    significant=candidate-control>np.maximum(np.spacing(control),np.spacing(candidate))*2
    source_nearer=np.count_nonzero(significant)
    assert source_nearer>0
    return dict(changedTexels=int(changed.sum()),deeperOrEarlierSurfaceTexels=int(source_nearer),
        total=int(changed.size),unchangedPreparation={k:o[k]['differenceBytes'] for k in ('preparedNormal','preparedMask','initialEligibility')},
        affectedRayColorBytes=o['outputColor']['differenceBytes'],affectedRayConfidenceBytes=o['outputConfidence']['differenceBytes'],
        affectedFilterBytes=o['filtered']['differenceBytes'])


def hall():
    regions={}
    with np.load(ROOT/'hall.npz',allow_pickle=False) as a:
        x,y=a['x'],a['y']
        assert len(set(zip(x,y)))==len(x) and np.all((x>=0)&(x<2560)&(y>=0)&(y<1440))
        assert np.all(np.any(a['control']!=a['candidate'],axis=-1))
        assert np.count_nonzero(a['candidate']!=a['control'])==REPLAY['outputs']['display']['differenceBytes']
        close=np.abs(a['reference'].astype('i2')-a['control']).max(axis=-1)<=1
        over=np.abs(a['reference'].astype('i2')-a['candidate']).max(axis=-1)>1
        for name,(l,t,r,b) in REQ['rectangles'].items():
            near=(x>=l)&(x<r)&(y>=t)&(y<b)
            row=dict(changedPixels=int(near.sum()),newOverOne=int((near&close&over).sum()))
            if name in ('centerFloor','cyanRing'):
                control=a[name+'_control']
                candidate=a[name+'_candidate']
                assert np.count_nonzero(np.any(control!=candidate,axis=-1))==near.sum()
                for case,img in (('control',control),('candidate',candidate)):
                    t=measure(img,a[name+'_reference'])
                    row[case]={key:t[key] for key in ('ssim','medianLumaRelativeError')}
            regions[name]=row
    return regions


if __name__=='__main__':
    record=len(sys.argv)==2 and sys.argv[1]=='--record'
    if record:gather()
    p=hall()
    g=REQ['gates']
    passed=all(p[name]['candidate']['ssim']>=g['ssim'] and p[name]['candidate']['medianLumaRelativeError']<=g['lumaRelative']
               for name in ('centerFloor','cyanRing')) and all(row['newOverOne']<=g['newOverOne'] for row in p.values())
    data=dict(depth=depth(),regions=p,hallOneFramePassed=passed)
    if record:(ROOT/'results.json').write_text(json.dumps(data,indent=2)+'\n')
    else:assert data==json.loads((ROOT/'results.json').read_bytes())
    print(json.dumps(data,indent=2))
    print('PASS: GPU depth reduction, unchanged preparation outputs and hall metrics recomputed')
