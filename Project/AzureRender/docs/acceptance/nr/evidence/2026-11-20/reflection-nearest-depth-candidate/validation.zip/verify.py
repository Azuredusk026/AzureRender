"""Verify hall image gates, the compact 2x2 depth witness and trace budgets."""
import json
from pathlib import Path
import sys

import numpy as np

from score_depth import REQ, REPLAY, hall

ROOT=Path(__file__).resolve().parent
s=json.loads((ROOT/'results.json').read_bytes())
assert REPLAY['restored'] and s['regions']==hall()
g=REQ['gates']
assert not s['hallOneFramePassed']
assert all(s['regions'][n]['candidate']['ssim']<g['ssim'] for n in ('centerFloor','cyanRing'))
assert s['regions']['complete']['newOverOne']>g['newOverOne']
assert all(REPLAY['outputs'][k]['differenceBytes']==0 for k in ('preparedNormal','preparedMask','initialEligibility'))
with np.load(ROOT/'depth-witness.npz',allow_pickle=False) as z:
    h,w=z['controlDepth'].shape
    a,b=np.frombuffer(bytes.fromhex(REPLAY['source']['parameters']),'<f4')[4:6]
    linear=z['surfaceDepth']
    with np.errstate(divide='ignore',invalid='ignore'):
        val=(np.float32(1)/linear-b)/a
    valid=(linear>0)&(linear<100000)&(val>=0)&(val<=1)
    depth=np.where(valid,val,0).reshape(h,2,w,2).max(axis=(1,3))
    np.testing.assert_array_max_ulp(z['candidateDepth'],depth,maxulp=2)
    assert np.all(z['candidateDepth']>=z['controlDepth'])
    out=dict(witnessPixels=h*w,changedDepthPixels=int(np.count_nonzero(z['candidateDepth']!=z['controlDepth'])),regions={})
    for name,(l,t,r,b) in {'centerFloor':[505,495,775,585],'cyanRing':[520,530,635,590]}.items():
        row={}
        for label in ('native','player'):
            a=z[label+'Mask'][t-478:b-478,l-498:r-498]
            n=int(z[label+'LongBudget'])
            row[label]=dict(longBudget=n,shortBudget=max(4,(n+7)//8),
                full=int((a>127).sum()),short=int((a<=127).sum()))
        out['regions'][name]=row
if len(sys.argv)==2 and sys.argv[1]=='--record':
    (ROOT/'mask-results.json').write_text(json.dumps(out,indent=2)+'\n')
else:
    assert out==json.loads((ROOT/'mask-results.json').read_bytes())
print(json.dumps(out,indent=2))
print('PASS: compact 2x2 depth, trace budgets and unchanged hall gates')
