"""Compare current-frame depth sources at the previously instrumented hit endpoints."""
import hashlib
import json
from pathlib import Path
import sys
import zlib
import numpy as np

ROOT=Path(__file__).resolve().parent
GEO=ROOT.parent/'20261120-005548-nr-reflection-temporal-attribution-9f3e38'
FIX=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261031-060648-ray-vulkan-a27711/frozen-inputs-portable')
load=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()


def gather():
    manifest=load(FIX/'manifest.json')
    expected=next(t for t in manifest['textures'] if t['role']=='currentDepth')
    data=(FIX/expected['file']).read_bytes()
    assert sha(data)==expected['sha256']
    cropped=data[:1280*720*4]
    replay=load(GEO/'replay.json')
    assert sha(cropped)==replay['native']['control']['currentDepth']['fullSha256']
    native=np.frombuffer(cropped,'<f4').reshape(720,1280)[::-1]
    p=load(ROOT/'replay.json')['outputs']['preparedDepth']
    fields=[native]
    proof=dict(nativeDepthSha256=sha(cropped),routes={},matches={})
    for case in ('control','candidate'):
        row=p[case]
        enc=(ROOT/row['file']).read_bytes()
        value=zlib.decompress(enc)
        assert sha(enc)==row['encodedSha256'] and sha(value)==row['sha256']
        proof[case+'DepthSha256']=sha(value)
        fields.append(np.frombuffer(value,'<f4').reshape(720,1280))
    request=load(GEO/'request.json')
    data=dict(np.load(GEO/'samples.npz',allow_pickle=False))
    decoded=[]
    for label,index in (('native',0),('player',1),('player',2)):
        constant=request['frames'][label]['trace']['constants'][1 if label=='native' else 0]
        raw=bytes.fromhex(constant['hex'])
        assert sha(raw)==constant['sha256']
        a,b=np.frombuffer(raw,'<f4').reshape(-1,4)[2 if label=='native' else 24,2:]
        decoded.append(1/(fields[index]*a+b))
    x,y,r,d=request['crop']
    m=(abs(decoded[0][y:d,x:r]-decoded[1][y:d,x:r])<=.02)&(data['native_confidence']>0)&(data['player_confidence']>0)
    picked={}
    for label in ('native','player'):
        raw=data[label+'_hitUv']
        assert sha(raw.tobytes())==replay[label]['probes']['hitUv']['sha256']
        uv=raw.astype('f8')/65535
        extent=[1280,720]
        lo=np.maximum(np.floor((uv-.5/65535)*extent).astype(int),0)
        hi=np.minimum(np.floor((uv+.5/65535)*extent).astype(int),np.array(extent)-1)
        coords=np.clip(np.floor(uv*extent).astype(int),0,np.array(extent)-1)
        if label=='native':coords[...,1]=719-coords[...,1]
        px,py=coords.transpose(2,0,1)
        choose=m&np.all(lo==hi,axis=-1)
        proof['routes'][label]=replay[label]['probes']['hitUv']['sha256']
        for region,(l,t,u,v) in request['regions'].items():
            in_area=np.zeros(m.shape,bool)
            in_area[t-y:v-y,l-x:u-x]=True
            keep=choose&in_area
            for i,distance in enumerate(decoded):
                key='_'.join((region,label,('native','center','closest')[i]))
                picked[key]=distance[py[keep],px[keep]]
                proof['matches'][key]=sha(picked[key].tobytes())
    np.savez_compressed(ROOT/'geometry.npz',**picked)
    (ROOT/'geometry-sources.json').write_text(json.dumps(proof,indent=2)+'\n')


def report():
    values=load(ROOT/'geometry-sources.json')
    result={}
    with np.load(ROOT/'geometry.npz',allow_pickle=False) as z:
        for key,checksum in values['matches'].items():
            assert sha(z[key].tobytes())==checksum
        for region in ('centerFloor','cyanRing'):
            row={}
            for label in ('native','player'):
                p=region+'_'+label+'_'
                native=z[p+'native']
                assert np.all(np.isfinite(native))
                row[label]=dict(count=len(native))
                for sampled in ('center','closest'):
                    e=np.abs(native-z[p+sampled])
                    row[label][sampled]=dict(medianM=float(np.median(e)),
                        over2cm=int((e>.02).sum()),over50cm=int((e>.5).sum()))
            result[region]=row
    return result


if __name__=='__main__':
    new=len(sys.argv)==2 and sys.argv[1]=='--record'
    if new:gather()
    result=report()
    if new:(ROOT/'geometry-results.json').write_text(json.dumps(result,indent=2)+'\n')
    else:assert result==load(ROOT/'geometry-results.json')
    print(json.dumps(result,indent=2))
    print('PASS: same-address surface depths from three frozen sources')
