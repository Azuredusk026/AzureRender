"""Replay the switch and hall captures with one changed history predicate."""
import hashlib
import json
import os
from pathlib import Path
import traceback
import zlib
import renderdoc as rd

ROOT=Path(os.environ['AZR_TRACKED_DEPTH_ROOT'])
REQ=json.loads((ROOT/'request.json').read_bytes())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name,data):
    (ROOT/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


def raw_texture(ctl,rid):
    return bytes(ctl.GetTextureData(rid,rd.Subresource()))


def pack(name,data):
    encoded=zlib.compress(data,6)
    path=ROOT/(name+'.zlib')
    path.write_bytes(encoded)
    return dict(file=path.name,bytes=len(data),sha256=sha(data),encodedSha256=sha(encoded))


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


def output_bindings(pipe, stage, shader):
    return {shader.readWriteResources[row.access.index].name:row.descriptor.resource
            for row in pipe.GetReadWriteResources(stage)}


def probe(label,job):
    cap=rd.OpenCaptureFile()
    ctl=None
    try:
        assert cap.OpenFile(job['capture']['path'],'',None)==rd.ResultCode.Succeeded
        options=rd.ReplayOptions()
        options.forceGPUVendor=rd.GPUVendor.nVidia
        options.forceGPUDeviceID=0x28e0
        status,ctl=cap.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and not ctl.GetAPIProperties().degraded
        assert ctl.GetFrameInfo().frameNumber==job['frame']
        textures={t.resourceId:t for t in ctl.GetTextures()}
        end=list(walk(ctl.GetRootActions()))[-1].eventId
        ctl.SetFrameEvent(end,True)
        w,h=job['extent']

        def display(rid):
            t=textures[rid]
            bgra=t.format.Name().startswith('B8G8')
            data=raw_texture(ctl,rid)
            assert len(data)==w*h*4
            out=bytearray(w*h*3)
            for i,source in enumerate((2,1,0) if bgra else (0,1,2)):
                out[i::3]=data[source::4]
            return bytes(out)

        available=[rid for rid,t in textures.items() if (t.width,t.height)==(w,h) and
            t.format.Name().startswith(('R8G8B8A8','B8G8R8A8')) and sha(display(rid))==job['displayRgbSha256']]
        assert available,(label,'display identity')
        if label=='hall':
            chosen=[rid for rid in available if str(rid)=='ResourceId::154']
            assert chosen
            rid_display=chosen[0]
        else:
            assert len(available)==1,available
            rid_display=available[0]
        ctl.SetFrameEvent(job['filterEvent'],True)
        cs=rd.ShaderStage.Compute
        fpipe=ctl.GetPipelineState()
        fshader=fpipe.GetShaderReflection(cs)
        assert sha(bytes(fshader.rawBytes))==REQ['filterShader']
        filtered,=[r for r in output_bindings(fpipe,cs,fshader).values() if r in textures]
        ctl.SetFrameEvent(job['event'],True)
        pipe=ctl.GetPipelineState()
        shader=pipe.GetShaderReflection(cs)
        assert sha(bytes(shader.rawBytes))==REQ['programs']['control']
        original=pipe.GetShader(cs)
        slots=output_bindings(pipe,cs,shader)
        slots={n:slots[n] for n in ('outputColor','outputConfidence','outputFootprint')}

        def snapshot(name):
            ctl.SetFrameEvent(job['event'],True)
            values={key:raw_texture(ctl,slot) for key,slot in slots.items()}
            ctl.SetFrameEvent(job['filterEvent'],True)
            values['filtered']=raw_texture(ctl,filtered)
            ctl.SetFrameEvent(end,True)
            values['display']=display(rid_display)
            return values

        def signature(values):
            return {name:sha(blob) for name,blob in values.items()}

        control=snapshot('control')
        assert sha(control['display'])==job['displayRgbSha256']
        results=dict(control=signature(control),replayed={},resources=dict(outputs={k:str(v) for k,v in slots.items()},
            filtered=str(filtered),display=str(rid_display)))
        if label=='switch':
            results['controlReadback']={k:pack(label+'-control-'+k,v) for k,v in control.items()}
        for name in job['programs']:
            code=(ROOT/(name+'.spv')).read_bytes()
            assert sha(code)==REQ['programs'][name]
            target,errmsg=ctl.BuildTargetShader(shader.entryPoint,rd.ShaderEncoding.SPIRV,code,rd.ShaderCompileFlags(),cs)
            assert target!=rd.ResourceId.Null(),errmsg
            try:
                ctl.ReplaceResource(original,target)
                values=snapshot(name)
                assert values['outputColor']==control['outputColor']
                found=dict(sha256=signature(values),differenceBytes={key:sum(a!=b for a,b in zip(raw,control[key]))
                    for key,raw in values.items()})
                if label=='switch':
                    found['readback']={k:pack(label+'-'+name+'-'+k,v) for k,v in values.items()}
                elif values['display']!=control['display']:
                    found['readback']={'display':pack(label+'-'+name+'-display',values['display'])}
                results['replayed'][name]=found
            finally:
                ctl.RemoveReplacement(original)
                ctl.FreeTargetResource(target)
        assert snapshot('restored')==control
        results['originalRestored']=True
        return results
    finally:
        if ctl is not None:
            ctl.Shutdown()
        cap.Shutdown()


try:
    reports={}
    for label,job in REQ['jobs'].items():
        reports[label]=probe(label,job)
        write('replay.json',reports)
except Exception:
    write('failure.json',dict(traceback=traceback.format_exc()))
    os._exit(1)
os._exit(0)
