"""Check replay image metrics and sealed mirror controls."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
subprocess.run([sys.executable,'-B',str(ROOT/'score.py')],cwd=ROOT,check=True)
rows=json.loads((ROOT/'mirror-controls.json').read_bytes())
assert len(rows)==10
for row in rows:
    key=row['program']+'-'+row['mode']
    result=row['result']
    assert result['validationErrors']==result['liveBuffers']==result['liveImages']==0
    expected=int(row['mode']!='history-response-tracked')
    assert row['exitCode']==expected
    assert result['redHits']==(0 if expected else 2432)
    if row['mode']=='history-response-zero-depth':
        assert result['surfacePreparation'] and row['preparedProgramSha256']
    for i,meta in enumerate(row['outputs']):
        path=ROOT/('qualified-'+key)/(str(i)+'.bin')
        raw=path.read_bytes()
        assert len(raw)==meta['bytes'] and hashlib.sha256(raw).hexdigest()==meta['sha256']
        if expected and i==2:
            assert not any(raw)
for control,edited in zip(rows[:5],rows[5:]):
    assert control['mode']==edited['mode'] and control['outputs']==edited['outputs']
print('PASS: ten mirror runs, five exact pairs')
