"""Score the isolated candidate against the frozen switch and hall gates."""
import hashlib
import json
from pathlib import Path
import sys
import zlib

import numpy as np
from PIL import Image

from measure_reference import measure
from test_screen_space_reflections_gpu import LEFT,RIGHT,oracle,polygon_mask,linear

ROOT=Path(__file__).resolve().parent
REQUEST=json.loads((ROOT/'request.json').read_bytes())
REPLAY=json.loads((ROOT/'replay.json').read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def readback(meta):
    encoded=(ROOT/meta['file']).read_bytes()
    raw=zlib.decompress(encoded)
    assert sha(encoded)==meta['encodedSha256']
    assert sha(raw)==meta['sha256'] and len(raw)==meta['bytes']
    return raw


def switch():
    control=REPLAY['switch']['controlReadback']
    candidate=REPLAY['switch']['replayed']['candidate']
    negative=REPLAY['switch']['replayed']['wrongDepth']
    region=polygon_mask(oracle(RIGHT)['reflectionPolygon'],.65)
    right=region[1::2,1::2]
    left=polygon_mask(oracle(LEFT)['reflectionPolygon'],.65)[1::2,1::2]
    assert REPLAY['switch']['originalRestored']

    def values(data):
        def array(key,fmt,extent):
            return np.frombuffer(readback(data[key]),fmt).reshape(extent)
        confidence=array('outputConfidence','u1',(120,160))
        spatial=array('filtered','<f4',(120,160,4))[...,3]
        color=linear(array('display','u1',(240,320,3)))
        red=np.maximum(color[...,0]-.5*(color[...,1]+color[...,2]),0)
        return dict(rightConfidencePixels=int(np.count_nonzero(confidence[right])),
                    leftConfidencePixels=int(np.count_nonzero(confidence[left])),
                    rightFilteredPixels=int(np.count_nonzero(spatial[right])),
                    rightDisplayRedMean=float(red[region].mean()))

    result=dict(control=values(control),candidate=values(candidate['readback']),
                wrongDepth=values(negative['readback']))
    assert result['control']['rightConfidencePixels']==0
    assert result['candidate']['rightConfidencePixels']==int(right.sum())
    assert result['candidate']['leftConfidencePixels']==0
    assert result['candidate']['rightFilteredPixels']==int(right.sum())
    assert result['candidate']['rightDisplayRedMean']>.003
    assert result['wrongDepth']==result['control']
    assert negative['sha256']==REPLAY['switch']['control']
    return result


def prepare_hall():
    retained=ROOT.parent/'20261119-220148-nr-player-same-frame-capture-31bfb3'
    frame=retained/'capture/frames/frame_000001.png'
    with Image.open(frame) as img:
        baseline=np.asarray(img.convert('RGB'))
    assert sha(baseline.tobytes())==REQUEST['jobs']['hall']['displayRgbSha256']
    ref=Path(REQUEST['reference'])
    assert sha(ref.read_bytes())==REQUEST['referenceSha256']
    with Image.open(ref) as img:
        reference=np.asarray(img.convert('RGB'))
    report=REPLAY['hall']['replayed']['candidate']
    if 'readback' in report:
        candidate=np.frombuffer(readback(report['readback']['display']),'u1').reshape(baseline.shape)
    else:
        candidate=baseline
    assert sha(candidate.tobytes())==report['sha256']['display']
    points=np.column_stack(np.where(np.any(candidate!=baseline,axis=-1)))
    y,x=points.T
    data=dict(points=points,initial=baseline[y,x],changed=candidate[y,x],gold=reference[y,x])
    for name in ('centerFloor','cyanRing'):
        l,t,r,b=REQUEST['rectangles'][name]
        for kind,pixels in (('control',baseline),('candidate',candidate),('reference',reference)):
            data[name+'_'+kind]=pixels[t:b,l:r]
    np.savez_compressed(ROOT/'hall-verify.npz',**data)


def hall():
    assert REPLAY['hall']['originalRestored']
    with np.load(ROOT/'hall-verify.npz',allow_pickle=False) as a:
        y,x=a['points'].T
        assert np.all(np.any(a['initial']!=a['changed'],axis=-1))
        assert len(set(map(tuple,a['points'])))==len(x)
        assert np.all((x>=0)&(x<2560)&(y>=0)&(y<1440))
        assert int(np.count_nonzero(a['initial']!=a['changed']))==REPLAY['hall']['replayed']['candidate']['differenceBytes']['display']
        new=(np.abs(a['changed'].astype('i2')-a['gold']).max(axis=-1)>1)&(
             np.abs(a['initial'].astype('i2')-a['gold']).max(axis=-1)<=1)
        out={}
        for name,(l,t,r,b) in REQUEST['rectangles'].items():
            mask=(x>=l)&(x<r)&(y>=t)&(y<b)
            item=dict(changedPixels=int(mask.sum()),newOverOne=int((mask&new).sum()))
            if name+'_control' in a:
                for case in ('control','candidate'):
                    full=measure(a[name+'_'+case],a[name+'_reference'])
                    item[case]={k:full[k] for k in ('ssim','medianLumaRelativeError')}
                    assert np.count_nonzero(np.any(a[name+'_control']!=a[name+'_candidate'],axis=-1))==mask.sum()
            out[name]=item
    return out


def main():
    if len(sys.argv)==2 and sys.argv[1]=='--record':
        prepare_hall()
    result=dict(switch=switch(),hall=hall())
    gates=REQUEST['gates']
    regions=result['hall']
    result['formalHallMeasuredFramePassed']=(all(regions[name]['candidate']['ssim']>=gates['ssim'] and
        regions[name]['candidate']['medianLumaRelativeError']<=gates['lumaRelative'] for name in ('centerFloor','cyanRing'))
        and all(row['newOverOne']<=gates['newOverOne'] for row in regions.values()))
    if len(sys.argv)==2 and sys.argv[1]=='--record':
        (ROOT/'computed.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    else:
        assert json.loads((ROOT/'computed.json').read_bytes())==result
    print(json.dumps(result,indent=2))
    print('PASS: candidate and failure controls independently scored')


if __name__=='__main__':
    main()
