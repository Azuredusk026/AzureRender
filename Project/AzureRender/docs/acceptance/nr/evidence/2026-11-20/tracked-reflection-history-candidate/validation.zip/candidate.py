"""Build an isolated tracked-depth candidate against the exact captured shader."""
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import subprocess
import sys

from PIL import Image

ROOT=Path(__file__).resolve().parent
RUNS=ROOT.parent
ENGINE=ROOT.parents[2]
TRANSITION=RUNS/'20261120-001407-nr-reflection-switch-transition-6707ab'
HALL=RUNS/'20261119-220148-nr-player-same-frame-capture-31bfb3'
CONTROL=RUNS/'20261119-234745-nr-reflection-hit-history-address-d77bf2'
EXE=Path('D:/Projects/FYP/Project/AzureRender/build/ninja-msvc-release/AzureProjectedReflectionCameraGpuTests.exe')
QRENDERDOC=Path('D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe')
SDK=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')


def read(path):
    return json.loads(path.read_bytes())


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def sha(path):
    with path.open('rb') as f:
        return file_digest(f,'sha256').hexdigest()


def shader(name,source):
    path=ROOT/(name+'.hlsl')
    binary=ROOT/(name+'.spv')
    path.write_bytes(source)
    flags=['-spirv','-T','cs_6_0','-E','main','-HV','2018','-fspv-target-env=vulkan1.1',
           '-fvk-b-shift','0','0','-fvk-t-shift','1','0','-fvk-s-shift','8','0','-fvk-u-shift','9','0','-Od']
    subprocess.run([str(SDK/'dxc.exe'),*flags,'-Fo',str(binary),str(path)],check=True,timeout=30)
    subprocess.run([str(SDK/'spirv-val.exe'),'--target-env','vulkan1.1',str(binary)],check=True,timeout=30)
    return sha(binary)


def patch(source, negative=False):
    target=b'if(historyConfig.w>.5&&historyConfig.z<1){float acceptance=trackedMotionAcceptance(v154.yzxw,asfloat(r2.xy),v167.y);r1.x=asuint(asfloat(r1.x)*acceptance);}'
    helper=b'''float3 reflectionHistoryWorld(float2 uv,float depth,float4 columns[4]){
    float2 clip=mad(uv,2,-1);
    if(footprintConfig.w<=.5)clip.y=-clip.y;
    float4 world=mad(columns[0],clip.x,columns[1]*clip.y);
    world=mad(columns[2],depth,world)+columns[3];
    return world.xyz/world.w;
}
'''
    insert=b'[numthreads(8,8,1)]'
    replace=b'''if(historyConfig.w>.5&&historyConfig.z<1){
    float4 trackedMotion=v154.yzxw;
    float2 priorUv=asfloat(r2.xy);
    float acceptance=trackedMotionAcceptance(trackedMotion,priorUv,v167.y);
    // A fully tracked moving surface supplies its previous device depth.
    if(historyConfig.z==0&&acceptance==1&&trackedMotion.w==1&&r1.x==0u&&asfloat(r0.w)>0
        &&any(abs(trackedMotion.xy)>sourceSize.zw)){
        float2 hitUv=asfloat(r8.xy);
        float hitDepth=currentDepth.SampleLevel(pointSampler,hitUv,0).x;
        float3 surface=reflectionHistoryWorld(hitUv,hitDepth,clipToWorld);
        float maxError=max(.25,.01*v182.y*v182.y);
        float expectedDepth=1-trackedMotion.z;
        float3 expected=reflectionHistoryWorld(priorUv,expectedDepth,previousClipToWorld);
        float3 spanX=reflectionHistoryWorld(priorUv+float2(traceSize.z,0),expectedDepth,previousClipToWorld)-expected;
        float3 spanY=reflectionHistoryWorld(priorUv+float2(0,traceSize.w),expectedDepth,previousClipToWorld)-expected;
        float priorTolerance=min(maxError,max(length(spanX),length(spanY)));
        if(hitDepth>0&&expectedDepth>0&&length(surface-v184.xyz)<=maxError
            &&length(expected-v183.xyz)<=priorTolerance)r1.x=r0.w;
    }
    r1.x=asuint(asfloat(r1.x)*acceptance);
}'''
    assert source.count(target)==source.count(insert)==1
    if negative:
        replace=replace.replace(b'1-trackedMotion.z',b'.5*(1-trackedMotion.z)')
    return source.replace(insert,helper+insert).replace(target,replace)


def prepare():
    t=read(TRANSITION/'request.json')
    s=read(TRANSITION/'replay.json')
    h=read(HALL/'request.json')
    source= subprocess.check_output(['git','show','6738365:Project/AzureRender/shaders/projected_reflection_trace.hlsl'],cwd=ENGINE)
    programs=dict(control=shader('control',source),
        candidate=shader('candidate',patch(source)),wrongDepth=shader('wrongDepth',patch(source,True)))
    assert programs['control']==t['rayProgram']==h['playerTraceShader']
    (ROOT/'candidate.patch').write_text(subprocess.run(['git','diff','--no-index','--','control.hlsl','candidate.hlsl'],
        text=True,capture_output=True,cwd=ROOT,check=False).stdout,encoding='utf-8')
    full=read(HALL/'frame-identity.json')
    hall_img=HALL/'capture'/'frames'/'frame_000001.png'
    assert sha(hall_img)==full['rows'][1]['pngSha256']
    quality=read(ENGINE/'docs/acceptance/nr/evidence/2026-11-19/reflection-confidence-lod/qualification.json')
    ref=Path(quality['reference'])
    assert sha(ref)==quality['referenceSha256']
    jobs=dict(
        switch=dict(capture=read(TRANSITION/'capture-receipt.json')['capture'], frame=4,extent=[320,240],
                    displayRgbSha256=t['originalFrameRgbSha256'], event=s['events']['rayProgram'][0],
                    filterEvent=s['events']['filterProgram'][0], programs=['candidate','wrongDepth']),
        hall=dict(capture=read(HALL/'capture-receipt.json')['capture'], frame=1,extent=[2560,1440],
                  displayRgbSha256=full['rows'][1]['rgbSha256'], event=21062,filterEvent=21123,programs=['candidate']))
    req=dict(baseline='9004b03',raySource='6738365',programs=programs,jobs=jobs,filterShader=h['filterShader'],
             toolSha256={p.name:sha(p) for p in (QRENDERDOC,SDK/'dxc.exe',SDK/'dxcompiler.dll',SDK/'spirv-val.exe')},
             reference=str(ref),referenceSha256=sha(ref),rectangles=quality['rectangles'],gates=quality['regionalGates'])
    write(ROOT/'request.json',req)


def execute():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output']).resolve()==ROOT
    req=read(ROOT/'request.json')
    for job in req['jobs'].values():
        assert sha(Path(job['capture']['path']))==job['capture']['sha256']
    startup=subprocess.STARTUPINFO()
    startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=0
    with (ROOT/'worker.log').open('wb') as log:
        subprocess.run([str(QRENDERDOC),'--python',str(ROOT/'candidate_replay.py')],cwd=ROOT,
            env=dict(os.environ,AZR_TRACKED_DEPTH_ROOT=str(ROOT)),startupinfo=startup,stdout=log,
            stderr=subprocess.STDOUT,check=True,timeout=160)
    results=[]
    for program in ('control','candidate'):
        for mode,expected in (('history-response-tracked',0),('history-response-background',1),
                              ('history-response-outside',1),('history-response-zero-depth',1),('history-offset',0)):
            out=ROOT/(program+'-'+mode)
            args=[str(EXE),str(ROOT/(program+'.spv')),str(out),mode]
            result=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=40,startupinfo=startup)
            raw=result.stdout+result.stderr
            (ROOT/(out.name+'.log')).write_bytes(raw)
            row=read(out/'result.json')
            assert result.returncode==expected,(program,mode,row)
            assert row['validationErrors']==row['liveBuffers']==row['liveImages']==0
            results.append(dict(program=program,mode=mode,exitCode=result.returncode,result=row,executable=sha(EXE),
                outputs=[sha(out/(str(i)+'.bin')) for i in range(3)]))
    for control,candidate in zip(results[:5],results[5:]):
        assert control['outputs']==candidate['outputs'],(control,candidate)
    write(ROOT/'mirror-controls.json',results)


if __name__=='__main__':
    {'prepare':prepare,'execute':execute}[sys.argv[1]]()
