"""Retest the mirror controls without repeating the qualified capture replay."""
from candidate import EXE,ROOT,RUNS,read,write,sha
from pathlib import Path
import subprocess

lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
assert lease['state']=='held' and Path(lease['output']).resolve()==ROOT
req=read(ROOT/'request.json')
assert all(v['originalRestored'] for v in read(ROOT/'replay.json').values())
shader=RUNS/'20261114-125923-body-lit-outline-depth-order-a29b63'/'msaa-release'/'shaders'/'projected_reflection_prepare.comp.spv'
old=read(RUNS/'20261119-220148-nr-player-same-frame-capture-31bfb3'/'request.json')
assert sha(shader)==old['shaders'][shader.name]
startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
results=[]
cases=(('history-response-tracked',0,False),('history-response-background',1,False),
       ('history-response-outside',1,False),('history-response-zero-depth',1,True),('history-response-depth',1,False))
for program in ('control','candidate'):
    binary=ROOT/(program+'.spv')
    assert sha(binary)==req['programs'][program]
    for mode,expected,prepared in cases:
        out=ROOT/('qualified-'+program+'-'+mode)
        args=[str(EXE),str(binary),str(out),mode]
        if prepared:
            args.append(str(shader))
        result=subprocess.run(args,cwd=ROOT,capture_output=True,timeout=40,startupinfo=startup)
        (ROOT/(out.name+'.log')).write_bytes(result.stdout+result.stderr)
        row=read(out/'result.json')
        assert result.returncode==expected,(program,mode,row)
        assert row['validationErrors']==row['liveBuffers']==row['liveImages']==0
        assert row['redHits']==(0 if expected else 2432)
        if expected:
            assert not any((out/'2.bin').read_bytes())
        results.append(dict(program=program,mode=mode,command=args,exitCode=result.returncode,result=row,
            executableSha256=sha(EXE),preparedProgramSha256=sha(shader) if prepared else None,
            outputs=[dict(sha256=sha(out/(str(i)+'.bin')),bytes=(out/(str(i)+'.bin')).stat().st_size) for i in range(3)]))
        write(ROOT/'mirror-controls.json',results)
for control,candidate in zip(results[:5],results[5:]):
    assert control['outputs']==candidate['outputs'],(control,candidate)
print('PASS: five paired mirror cases, identical outputs and zero validation or lifetime errors')
