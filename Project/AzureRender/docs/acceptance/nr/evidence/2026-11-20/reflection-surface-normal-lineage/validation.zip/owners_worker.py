"""Confirm the source texel and draw of three representative foreground samples."""
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import struct
import traceback

import renderdoc as rd

ROOT=Path(os.environ['AZR_FOREGROUND_ROOT'])
read=lambda name:json.loads((ROOT/name).read_bytes())


def write(name,data):
    (ROOT/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


def actions(rows):
    for row in rows:
        yield row
        yield from actions(row.children)


def check():
    request=read('request.json')['jobs']['player']
    witness=read('direct.json')['player']['early']['primary']
    examples=read('tail-results.json')['centerFloor']['examples']
    cap=rd.OpenCaptureFile()
    ctl=None
    result=dict(frame=request['frame'],capture=request['captureSha256'],resource=witness['resource'],rows=[])
    try:
        assert cap.OpenFile(request['capture'],'',None)==rd.ResultCode.Succeeded
        options=rd.ReplayOptions()
        options.forceGPUVendor=rd.GPUVendor.nVidia
        options.forceGPUDeviceID=0x28e0
        status,ctl=cap.OpenCapture(options,None)
        assert status==rd.ResultCode.Succeeded and not ctl.GetAPIProperties().degraded
        assert ctl.GetFrameInfo().frameNumber==request['frame']
        tex={str(t.resourceId):t for t in ctl.GetTextures()}
        events={row.eventId:row for row in actions(ctl.GetRootActions())}
        t=tex[witness['resource']]
        res=t.resourceId
        assert (t.width,t.height)==(2560,1440)
        observer=request['prepareEvent']-1
        ctl.SetFrameEvent(observer,True)
        raw=bytes(ctl.GetTextureData(res,rd.Subresource()))
        assert sha256(raw).hexdigest()==witness['fullSha256']
        for item in examples:
            hx,hy=item['addresses'][0]
            xy=[(2*hx+x,2*hy+y) for y in (0,1) for x in (0,1)]
            offsets=[(y*t.width+x)*16 for x,y in xy]
            depths=[struct.unpack_from('<f',raw,index)[0] for index in offsets]
            nearest=min(range(4),key=lambda j:depths[j] if 0<depths[j]<1e5 else math.inf)
            x,y=xy[nearest]
            assert abs(depths[nearest]-item['playerNativeDepthAtPredicted'][0])<.00005
            offset=offsets[nearest]
            expected=raw[offset:offset+16]
            ctl.SetFrameEvent(observer,True)
            history=ctl.PixelHistory(res,x,y,rd.Subresource(),rd.CompType.Typeless)
            passed=sorted({h.eventId for h in history if h.eventId<observer and h.Passed()},reverse=True)
            found=None
            for aid in passed:
                a=events.get(aid)
                if a is None or not(a.flags&rd.ActionFlags.Drawcall):
                    continue
                ctl.SetFrameEvent(aid,True)
                current=bytes(ctl.GetTextureData(res,rd.Subresource()))[offset:offset+16]
                if current!=expected:continue
                ctl.SetFrameEvent(aid-1,True)
                before=bytes(ctl.GetTextureData(res,rd.Subresource()))[offset:offset+16]
                if before==current:continue
                ctl.SetFrameEvent(aid,True)
                pipe=ctl.GetPipelineState()
                ps=pipe.GetShaderReflection(rd.ShaderStage.Fragment)
                found=dict(id=aid,firstIndex=a.indexOffset,indices=a.numIndices,instance=a.instanceOffset,
                    indexResource=str(pipe.GetIBuffer().resourceId),indexBufferOffset=pipe.GetIBuffer().byteOffset,
                    pixelProgram=sha256(bytes(ps.rawBytes)).hexdigest(),before=before.hex(),after=current.hex())
                break
            assert found is not None,(x,y,passed)
            result['rows'].append(dict(receiver=item['receiver'],source=[x,y],tapDepths=depths,draw=found))
            write('foreground-owners.json',result)
    finally:
        if ctl is not None:ctl.Shutdown()
        cap.Shutdown()


try:
    check()
except Exception:
    write('owners-failure.json',dict(traceback=traceback.format_exc()))
    os._exit(1)
os._exit(0)
