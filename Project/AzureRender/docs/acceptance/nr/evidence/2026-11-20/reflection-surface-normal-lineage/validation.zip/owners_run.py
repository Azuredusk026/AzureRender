"""Open the retained Player capture under the shared lease for three geometry samples."""
from pathlib import Path
import json
import os
import subprocess

root=Path(__file__).resolve().parent
lease=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lease['state']=='held' and Path(lease['output']).resolve()==root
info=subprocess.STARTUPINFO()
info.dwFlags|=subprocess.STARTF_USESHOWWINDOW
info.wShowWindow=0
with (root/'owners.log').open('wb') as out:
    subprocess.run(['D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe','--python',str(root/'owners_worker.py')],
        cwd=root,env=dict(os.environ,AZR_FOREGROUND_ROOT=str(root)),stdout=out,stderr=subprocess.STDOUT,
        startupinfo=info,check=True,timeout=110)
