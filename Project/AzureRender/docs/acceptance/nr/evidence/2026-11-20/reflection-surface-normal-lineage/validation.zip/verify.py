"""Recompute archived normal and foreground witnesses."""
import json
from pathlib import Path
import struct
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
read=lambda name: json.loads((ROOT/name).read_bytes())
for script in ('normal_score.py','occurrence.py'):
    subprocess.run([sys.executable,'-B',str(ROOT/script)],cwd=ROOT,check=True)
f=read('fixture.json')
assert [x['config'] for x in f]==['debug','release']
for case in f:
    assert case['exitCode']==0
    log=(ROOT/('fixture-'+case['config']+'.log')).read_bytes()
    assert b'3380 full/half/odd/single-axis pixel references' in log
    assert b'validation=0 resources=0' in log
s=read('tail-results.json')
r=read('foreground-owners.json')
job=read('request.json')['jobs']['player']
assert r['frame']==job['frame'] and r['capture']==job['captureSha256']
examples=s['centerFloor']['examples']
assert len(examples)==len(r['rows'])==3
for example,item in zip(examples,r['rows']):
    assert example['receiver']==item['receiver']
    assert [coord//2 for coord in item['source']]==example['addresses'][0]
    raw=struct.unpack('<4f',bytes.fromhex(item['draw']['after']))
    assert raw[0]==min(item['tapDepths'])
    assert abs(raw[0]-example['playerNativeDepthAtPredicted'][0])<.00005
    assert example['playerNativeDepthAtPredicted'][1]-raw[0]>12
    assert item['draw']['after']!=item['draw']['before']
    assert item['draw']['id']==18593
print('PASS: analytic GPU fixture receipts and three actual foreground draw witnesses')
