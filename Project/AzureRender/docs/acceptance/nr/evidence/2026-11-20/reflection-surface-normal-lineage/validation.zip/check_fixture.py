"""Exercise the frozen preparation program with the existing analytic geometry fixture."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
MAIN=Path('D:/Projects/FYP/Project/AzureRender/build')
inputs=ROOT.parent/'20261114-125923-body-lit-outline-depth-order-a29b63'/'msaa-release'
program=inputs/'shaders/projected_reflection_prepare.comp.spv'
req=json.loads((ROOT/'request.json').read_bytes())
assert sha256(program.read_bytes()).hexdigest()==req['jobs']['player']['prepareShader']
lease=json.loads(Path('D:/Projects/FYP-coordination/resources/current.json').read_bytes())
assert lease['state']=='held' and Path(lease['output']).resolve()==ROOT
fixture=[]
for config in ('debug','release'):
    exe=MAIN/('ninja-msvc-'+config)/'AzureProjectedReflectionPreparationGpuTests.exe'
    args=[str(exe),str(program)]
    result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=False,timeout=50,cwd=ROOT)
    (ROOT/('fixture-'+config+'.log')).write_bytes(result.stdout)
    assert result.returncode==0,result.stdout[-2400:]
    assert b'3380 full/half/odd/single-axis pixel references' in result.stdout
    assert b'validation=0 resources=0' in result.stdout
    fixture.append(dict(config=config,exitCode=result.returncode,programSha256=sha256(program.read_bytes()).hexdigest(),
                        executableSha256=sha256(exe.read_bytes()).hexdigest(),command=args))
(ROOT/'fixture.json').write_text(json.dumps(fixture,indent=2)+'\n',encoding='utf-8')
print('PASS: frozen surface preparation on two analytic fixture configurations')
