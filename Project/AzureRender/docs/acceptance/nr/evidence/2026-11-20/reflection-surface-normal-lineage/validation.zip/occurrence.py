"""Measure foreground depth at the predicted endpoint of the controlled search."""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT=Path(__file__).resolve().parent
STEP=ROOT.parent/'20261120-010938-nr-reflection-step-sensitivity-29dbba'
FIX=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261031-060648-ray-vulkan-a27711/frozen-inputs-portable')
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()


def gather():
    sys.path.insert(0,str(STEP))
    from step_sensitivity import geometry
    from trace_functions import fma,trace

    receipt=read(STEP/'inputs.json')
    with np.load(STEP/'inputs.npz',allow_pickle=False) as z:
        arrays={k:z[k] for k in z.files}
    frame=arrays['constants']
    assert sha(arrays['closestDepth'].tobytes())==receipt['geometry']['candidate']['sha256']
    assert sha(arrays['nativeNormalsPacked'][::-1].tobytes())==receipt['rawNativeNormalsDigest']
    assert sha(arrays['native_hitUv'].tobytes())==receipt['source']['native']['probes']['hitUv']['sha256']
    entry=next(x for x in read(FIX/'manifest.json')['textures'] if x['role']=='currentDepth')
    full=(FIX/entry['file']).read_bytes()
    assert sha(full)==entry['sha256']
    raw=full[:1280*720*4]
    assert sha(raw)==receipt['source']['native']['control']['currentDepth']['fullSha256']
    native=np.frombuffer(raw,'<f4').reshape(720,1280)[::-1]
    depth=arrays['closestDepth']
    dn=lambda a:1/(a*np.float32(9.999899864196777)+np.float32(9.999999747378752e-05))
    vp=lambda a:1/(a*frame[24,2]+frame[24,3])
    eligible=np.load(ROOT/'pairmask.npy',allow_pickle=False)
    normals=arrays['normals'].copy()
    packed=arrays['nativeNormalsPacked']
    normals[...,0]=1-(packed&1023).astype('f4')/1023
    normals[...,1]=((packed>>10)&1023).astype('f4')/1023
    a=dict(arrays,normals=normals)
    g=geometry(frame,depth,a,receipt['crop'],eligible,fma)
    uv,hit=trace(g,32,42,invert_y=True)
    measured=arrays['native_hitUv'].astype('f8')/65535
    measured[...,1]=1.-measured[...,1]
    distance=np.linalg.norm((uv-measured)*[2560,1440],axis=-1)
    limits=np.array([1280,720])
    native_min=np.clip(np.floor((measured-.5/65535)*limits),0,limits-1)
    native_max=np.clip(np.floor((measured+.5/65535)*limits),0,limits-1)
    unambiguous=np.all(native_min==native_max,axis=-1)

    def hit_address(coords):
        return np.clip(np.floor(coords*limits),0,limits-1).astype(int)

    result={}
    x0,y0,_,_=receipt['crop']
    for label,(l,t,r,b) in receipt['regions'].items():
        selected=np.zeros(eligible.shape,bool)
        selected[t-y0:b-y0,l-x0:r-x0]=True
        selected&=eligible&hit&unambiguous
        samplers=[hit_address(v)[selected] for v in (uv,measured)]
        junction=[]
        for array in samplers:
            x,y=array.T
            junction += [dn(native[y,x]),vp(depth[y,x])]
        result[label+'_surfaceDepths']=np.stack(junction,axis=-1)
        result[label+'_sourceEndpoints']=np.stack(samplers,axis=-2).astype('<u2')
        result[label+'_distance']=distance[selected]
        yy,xx=np.where(selected)
        result[label+'_displayReceiver']=np.column_stack([(xx+x0)*2+1,(yy+y0)*2+1]).astype('<u2')
    np.savez_compressed(ROOT/'tail-samples.npz',**result)
    proof=dict(nativeDepthSha256=sha(raw),playerClosestDepthSha256=sha(depth.tobytes()),reader=receipt['source']['native']['probes']['hitUv'],
               compoundControl=dict(steps=32,phaseSeed=42,phaseFlipped=True,measuredNormals=True,closestDepth=True),
               entries={key:sha(value.tobytes()) for key,value in result.items()})
    (ROOT/'tail-inputs.json').write_text(json.dumps(proof,indent=2)+'\n')


def verify():
    proof=read(ROOT/'tail-inputs.json')
    report={}
    with np.load(ROOT/'tail-samples.npz',allow_pickle=False) as z:
        for key,digest in proof['entries'].items():
            assert sha(z[key].tobytes())==digest
        for name in ('centerFloor','cyanRing'):
            xy=z[name+'_sourceEndpoints']
            distance=z[name+'_distance']
            n0,p0,n1,p1=z[name+'_surfaceDepths'].T
            e=p0-n0
            true=p1-n1
            m=distance>50
            foreground=(e<-.5)&m
            examples=[]
            k=np.flatnonzero(foreground)
            if len(k):
                order=k[np.argsort(distance[k])]
                for i in order[[len(order)//4,len(order)//2,3*len(order)//4]]:
                    examples.append(dict(receiver=z[name+'_displayReceiver'][i].tolist(),addresses=xy[i].tolist(),
                        displayDistance=float(distance[i]),playerNativeDepthAtPredicted=[float(p0[i]),float(n0[i])]))
            report[name]=dict(samples=len(distance),outside50px=int(m.sum()),foregroundOver50cm=int(foreground.sum()),
               otherDepthOver50cm=int(((e>.5)&m).sum()),sameDepthWithin2cm=int(((abs(e)<=.02)&m).sum()),
               nativeEndpointsWithDepthGapOver50cm=int(((abs(true)>.5)&m).sum()),examples=examples)
    return report


if __name__=='__main__':
    gather_data=len(sys.argv)==2 and sys.argv[1]=='--record'
    if gather_data:gather()
    stats=verify()
    if gather_data:(ROOT/'tail-results.json').write_text(json.dumps(stats,indent=2)+'\n',encoding='utf-8')
    else:assert stats==read(ROOT/'tail-results.json')
    print(json.dumps(stats,indent=2))
    print('PASS: hit-tail locations and depth checks')
