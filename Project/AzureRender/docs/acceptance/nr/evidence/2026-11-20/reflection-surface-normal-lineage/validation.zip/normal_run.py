"""Read the four source taps and actual prepared normals from the frozen captures."""
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback
import zlib

ROOT=Path(__file__).resolve().parent
RUNS=ROOT.parent
QRENDERDOC=Path('D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe')
RANGE=[498,478,793,703]


def read(path):
    return json.loads(path.read_bytes())


def write(name,value):
    (ROOT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def sha(path):
    digest=sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):
            digest.update(block)
    return digest.hexdigest()


def run():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output']).resolve()==ROOT
    prior=read(RUNS/'20261120-005548-nr-reflection-temporal-attribution-9f3e38'/'request.json')
    assert sha(QRENDERDOC)==prior['toolSha256']
    cold=read(RUNS/'20261119-220148-nr-player-same-frame-capture-31bfb3'/'request.json')
    jobs={}
    for label in ('native','player'):
        entry=prior['frames'][label]
        assert sha(Path(entry['capture']))==entry['captureSha256']
        row=dict(capture=entry['capture'],captureSha256=entry['captureSha256'],frame=entry['frame'],
                 rayEvent=entry['trace']['event'],rayShader=entry['expectedProgram'])
        slots=entry['trace']['textures']
        row['rayNormal']=slots['read:6:texture6' if label=='native' else 'read:7:normalRoughness'][0]
        if label=='native':
            row.update(prepareEvent=8691,prepareShader='4f3aed456ad56586d56a9017bc62061faa7f4939035c32980c8439da4d7f9ccd',
                       sources={'primary':'ResourceId::15834','secondary':'ResourceId::15771'})
        else:
            row.update(prepareEvent=21055,prepareShader=cold['shaders']['projected_reflection_prepare.comp.spv'],
                       sources={'primary':'ResourceId::9847'})
        jobs[label]=row
    write('request.json',dict(baseline='8f60988',range=RANGE,jobs=jobs))
    assert sha(QRENDERDOC)==prior['toolSha256']
    startup=subprocess.STARTUPINFO()
    startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=0
    with (ROOT/'worker.log').open('wb') as log:
        subprocess.run([str(QRENDERDOC),'--python',str(ROOT/'normal_worker.py')],cwd=ROOT,
            check=True,timeout=140,startupinfo=startup,env=dict(os.environ,AZR_NRM_READBACK=str(ROOT)),
            stdout=log,stderr=subprocess.STDOUT)



if __name__=='__main__':
    run()
