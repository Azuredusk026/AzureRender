from hashlib import sha256
import json
import os
from pathlib import Path
import traceback
import zlib
ROOT=Path(os.environ['AZR_NRM_READBACK'])
RANGE=[498,478,793,703]

def read(path):
    return json.loads(path.read_bytes())

def write(name,value):
    (ROOT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

def worker():
    import renderdoc as rd
    req=read(ROOT/'request.json')
    reports={}
    for label,row in req['jobs'].items():
        cap=rd.OpenCaptureFile()
        ctl=None
        try:
            assert cap.OpenFile(row['capture'],'',None)==rd.ResultCode.Succeeded
            opts=rd.ReplayOptions()
            opts.forceGPUVendor=rd.GPUVendor.nVidia
            opts.forceGPUDeviceID=0x28e0
            status,ctl=cap.OpenCapture(opts,None)
            assert status==rd.ResultCode.Succeeded and not ctl.GetAPIProperties().degraded
            assert ctl.GetFrameInfo().frameNumber==row['frame']
            tex={str(t.resourceId):t for t in ctl.GetTextures()}
            compute=rd.ShaderStage.Compute

            def stage(event,program):
                ctl.SetFrameEvent(event,True)
                pipe=ctl.GetPipelineState()
                shader=pipe.GetShaderReflection(compute)
                assert sha256(bytes(shader.rawBytes)).hexdigest()==program
                out={}
                for b in pipe.GetReadOnlyResources(compute):
                    resource=str(b.descriptor.resource)
                    if resource in tex:
                        desc=shader.readOnlyResources[b.access.index]
                        out[resource]=dict(slot=desc.fixedBindNumber,mip=b.descriptor.firstMip,name=desc.name)
                return out

            def take(name, rid, scale, binding):
                t=tex[rid]
                w,h=t.width,t.height
                assert (w,h)==(1280*scale,720*scale)
                data=bytes(ctl.GetTextureData(t.resourceId,rd.Subresource()))
                assert len(data)%(w*h)==0
                bpp=len(data)//(w*h)
                x,y,u,v=(n*scale for n in RANGE)
                rows=range(y,v) if label=='player' else range(h-1-y,h-1-v,-1)
                rect=b''.join(data[(j*w+x)*bpp:(j*w+u)*bpp] for j in rows)
                enc=zlib.compress(rect,6)
                dst=label+'-'+name+'.zlib'
                (ROOT/dst).write_bytes(enc)
                return dict(file=dst,sha256=sha256(rect).hexdigest(),encodedSha256=sha256(enc).hexdigest(),
                    fullSha256=sha256(data).hexdigest(),dimensions=[u-x,v-y],bytesPerPixel=bpp,format=t.format.Name(),
                    resource=rid,binding=binding)
            bound=stage(row['prepareEvent'],row['prepareShader'])
            reads={name:take(name,rid,2,bound[rid]) for name,rid in row['sources'].items()}
            samples=stage(row['rayEvent'],row['rayShader'])
            normal=row['rayNormal']['resource']
            value=take('prepared',normal,1,samples[normal])
            assert value['fullSha256']==row['rayNormal']['fullSha256']
            if label=='native':
                assert reads['primary']['fullSha256']==reads['secondary']['fullSha256']
            reports[label]=dict(frame=row['frame'],captureSha256=row['captureSha256'],early=reads,prepared=value,
                prepareEvent=row['prepareEvent'],rayEvent=row['rayEvent'])
            write('direct.json',reports)
        finally:
            if ctl is not None:ctl.Shutdown()
            cap.Shutdown()

try:
    write('worker-start.json',dict(status='started'))
    worker()
except Exception:
    write('failure.json',dict(traceback=traceback.format_exc()))
    os._exit(1)
os._exit(0)
