import numpy as np

def fma(x, y, z):
    return (np.asarray(x, np.float64) * np.asarray(y, np.float64) + np.asarray(z, np.float64)).astype(np.float32)

def phase(x, y, seed):
    f = lambda u: np.uint32(u).view(np.float32)
    a = fma(seed, f(1074089951), x)
    b = fma(seed, f(1083948663), y)
    h = fma(b, f(1002390928), a * f(1032417603))
    h = (h - np.floor(h)) * f(1112796802)
    return h - np.floor(h)

def trace(g, steps, seed, invert_y=False):
    v, depth, mask, eligible, (x, y), origin, delta, size = g
    count = np.where(mask, steps, max(4, int(np.ceil(steps / 8)))).astype(np.float32)
    tolerance = np.maximum(abs(delta[..., 2]) / count, np.float32(0.0001))
    step = delta * np.array([0.5, 0.5, 1], dtype=np.float32) * (1 / count[..., None])
    length = np.max(abs(step[..., :2] * size), axis=-1)
    jitter = phase(x, size[1] - y if invert_y else y, np.float32(seed))
    initial = np.where(length < 1, 1 / (length + np.float32(0.001)), jitter)
    cur = fma(step, initial[..., None], origin)

    def get(p):
        uv = np.clip(p[..., :2], 0, 1)
        tex = (uv * size).astype(np.int32)
        return depth[np.minimum(tex[..., 1], int(size[1] - 1)), np.minimum(tex[..., 0], int(size[0] - 1))]
    prev = cur[..., 2] - get(cur)
    hit = np.zeros(count.shape, dtype=bool)
    found = np.zeros((*count.shape, 2), dtype=np.float32)
    for i in range(0, steps, 4):
        active = eligible & ~hit & (i < count)
        if not active.any():
            break
        for lane in range(1, 5):
            p = fma(step, lane, cur)
            difference = p[..., 2] - get(p)
            owns = active & ~hit & (abs(difference + tolerance) < tolerance)
            with np.errstate(divide='ignore', invalid='ignore'):
                u = np.clip(prev[owns] / (prev[owns] - difference[owns]), 0, 1) + np.float32(lane - 1)
            found[owns] = fma(step[owns], u[..., None], cur[owns])[..., :2]
            hit |= owns
            prev = difference
        cur = fma(step, 4, cur)
    return (found, hit)
