"""Hold geometry and phase constant to compare the two captured step budgets."""
import ast
import json
from hashlib import sha256
from pathlib import Path
import sys
from zipfile import ZipFile
import zlib

import numpy as np

ROOT=Path(__file__).resolve().parent
REGION=ROOT.parent/'20261120-005548-nr-reflection-temporal-attribution-9f3e38'
DEPTH=ROOT.parent/'20261120-010236-nr-reflection-nearest-depth-ee519e'
OLD=ROOT.parent/'20261119-220148-nr-player-same-frame-capture-31bfb3'
ENGINE=ROOT.parents[2]
EVIDENCE=ENGINE/'docs/acceptance/nr/evidence/2026-11-16/projected-history-bilateral-endpoints/validation.zip'


def read(path):
    return json.loads(path.read_bytes())


def digest(raw):
    return sha256(raw).hexdigest()


def readback(folder,record):
    q=(folder/record['file']).read_bytes()
    assert digest(q)==record['encodedSha256']
    raw=zlib.decompress(q)
    assert digest(raw)==record['sha256']
    return raw


def source():
    q=read(REGION/'request.json')
    p=read(OLD/'player-result.json')['stages']['trace']
    depth=read(DEPTH/'replay.json')['outputs']['preparedDepth']
    x,y,r,b=q['crop']
    h,w=b-y,r-x
    assert [x,y,r,b]==p['textures']['read:7:normalRoughness'][0]['rect']
    shape=(h,w)
    mask=readback(OLD/'player',p['textures']['read:6:surfaceMask'][0])
    normals=readback(OLD/'player',p['textures']['read:7:normalRoughness'][0])
    cn=read(REGION/'replay.json')
    c=p['constants'][0]
    raw=bytes.fromhex(c['hex'])
    assert digest(raw)==c['sha256']
    constants=np.frombuffer(raw,'<f4').reshape(30,4)
    arrays={}
    for label in ('native','player'):
        for name in ('hitUv','confidence','currentDepth'):
            m=cn[label]['probes'][name] if name=='hitUv' else cn[label]['control'][name]
            fmt, dims=('<u2',(*shape,2)) if name=='hitUv' else ('u1',shape) if name=='confidence' else ('<f4',shape)
            arrays[label+'_'+name]=np.frombuffer(readback(REGION,m),fmt).reshape(dims)
    arrays.update(mask=np.frombuffer(mask,'u1').reshape(shape),normals=np.frombuffer(normals,'<f4').reshape(*shape,4),
                  centerDepth=np.frombuffer(readback(DEPTH,depth['control']),'<f4').reshape(720,1280),
                  closestDepth=np.frombuffer(readback(DEPTH,depth['candidate']),'<f4').reshape(720,1280), constants=constants)
    nd=ROOT.parent/'20261119-181852-nr-same-frame-reflection-lineage-ffb239'
    native_record=read(nd/'native-result.json')['stages']['trace']['textures']['read:6:texture6'][0]
    assert native_record['rect']==[x,720-b,r,720-y]
    native_normal=readback(nd/'native',native_record)
    arrays['nativeNormalsPacked']=np.frombuffer(native_normal,'<u4').reshape(h,w)[::-1]
    np.savez_compressed(ROOT/'inputs.npz',**arrays)
    with ZipFile(EVIDENCE) as z:
        script=z.read('analysis/preview-projected-phase-player.py')
    tree=ast.parse(script)
    functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('fma','phase','trace')]
    assert len(functions)==3
    (ROOT/'trace_functions.py').write_text('import numpy as np\n\n'+ast.unparse(ast.Module(body=functions,type_ignores=[]))+'\n',encoding='utf8')
    receipts=dict(source=read(REGION/'replay.json'),geometry=depth,
        rawNativeNormalsDigest=digest(native_normal),rawNormalsDigest=digest(normals),rawMaskDigest=digest(mask),constantDigest=digest(raw),
        archiveSha256=digest(EVIDENCE.read_bytes()),cpuFunctionsSha256=digest(script),
        crop=q['crop'],regions=q['regions'])
    (ROOT/'inputs.json').write_text(json.dumps(receipts,indent=2)+'\n')


def geometry(frame, full_depth, a, bounds, common, fma):
    x,y,r,b=bounds
    size=np.array(frame[25,:2],dtype=np.float32)
    assert tuple(size)==(1280,720) and frame[29,3]==1
    z=full_depth[y:b,x:r]
    mask=a['mask']>127
    xx,yy=np.meshgrid(np.arange(x,r,dtype=np.float32)+.5,np.arange(y,b,dtype=np.float32)+.5)
    uv=np.stack((xx*frame[25,2],yy*frame[25,3]),axis=-1)
    nd=fma(uv,2,-1)
    norm=lambda vec:vec/np.linalg.norm(vec,axis=-1,keepdims=True)
    cp=fma(nd[...,0,None],frame[6],nd[...,1,None]*frame[7])
    cp=fma(z[...,None],frame[8],cp)+frame[9]
    incident=norm(cp[...,:3]/cp[...,3,None])
    rg=a['normals'][...,:2]*2-1
    yy_normal=1-np.abs(rg).sum(axis=2)
    folded=(1-np.abs(rg[...,::-1]))*np.where(rg>=0,1.,-1.).astype('f4')
    xz=np.where((yy_normal<0)[...,None],folded,rg)
    wnorm=norm(np.stack([xz[...,0],yy_normal,xz[...,1]],axis=-1))
    nrm=fma(wnorm[...,0,None],frame[0,:3],wnorm[...,1,None]*frame[1,:3])
    nrm=fma(wnorm[...,2,None],frame[2,:3],nrm)
    dot=fma(incident[...,2],nrm[...,2],fma(incident[...,1],nrm[...,1],incident[...,0]*nrm[...,0]))
    reflect=fma(nrm,-2*dot[...,None],incident)
    xyzw=fma(reflect[...,0,None],frame[3],reflect[...,1,None]*frame[4])
    xyzw=fma(reflect[...,2,None],frame[5],xyzw)
    n_xyz=np.concatenate((nd,z[...,None]),axis=-1)
    xyzw+=np.concatenate((n_xyz,np.ones_like(z)[...,None]),axis=-1)
    slope=xyzw[...,:3]/xyzw[...,3,None]-n_xyz
    half=np.linalg.norm(slope[...,:2],axis=-1)*np.float32(.5)
    with np.errstate(divide='ignore',invalid='ignore'):
        outside=np.maximum(np.abs(fma(nd,half[...,None],slope[...,:2]))-half[...,None],0)
        limit=np.min(1-outside/np.abs(slope[...,:2]),axis=-1)/half
        delta=slope*limit[...,None]
    assert np.isfinite(delta[common]).all()
    return frame,full_depth,mask,common,(xx,yy),np.concatenate((uv,z[...,None]),axis=-1),delta,size


def calculate():
    from trace_functions import fma,trace
    receipts=read(ROOT/'inputs.json')
    with np.load(ROOT/'inputs.npz',allow_pickle=False) as z:
        a={k:z[k] for k in z.files}
    for label in ('native','player'):
        for name in ('hitUv','confidence','currentDepth'):
            row=receipts['source'][label]
            expected=row['probes'][name] if name=='hitUv' else row['control'][name]
            assert digest(a[label+'_'+name].tobytes())==expected['sha256']
    for name,tag in (('centerDepth','control'),('closestDepth','candidate')):
        assert digest(a[name].tobytes())==receipts['geometry'][tag]['sha256']
    for name,tag in (('mask','rawMaskDigest'),('normals','rawNormalsDigest'),('constants','constantDigest')):
        assert digest(a[name].tobytes())==receipts[tag]
    frame=a['constants']
    assert int(frame[28,0])==128 and int(frame[26,0])==0
    nc=a['native_currentDepth']
    pc=a['player_currentDepth']
    # Exact decoder constants are taken from the paired bound uniform buffers.
    ncoeff=np.array([9.999899864196777,9.999999747378752e-05],dtype=np.float32)
    pcoeff=frame[24,2:]
    matched=(abs(1/(nc*ncoeff[0]+ncoeff[1])-1/(pc*pcoeff[0]+pcoeff[1]))<=.02)
    actual={i:a[i+'_hitUv'].astype('f8')/65535 for i in ('native','player')}
    actual['native'][...,1]=1-actual['native'][...,1]
    both=matched&(a['native_confidence']>0)&(a['player_confidence']>0)
    runs={}
    for mode in ('centerDepth','closestDepth'):
        g=geometry(frame,a[mode],a,receipts['crop'],both,fma)
        for steps,seed,invert in ((128,0,False),(32,0,False),(32,42,True)):
            name=mode+'-'+str(steps)+('-phase42' if invert else '')
            uv,valid=trace(g,steps,seed,invert_y=invert)
            errors={k:np.linalg.norm((uv-v)*[2560,1440],axis=-1) for k,v in actual.items()}
            runs[name]=(valid,errors)
    packed=a['nativeNormalsPacked']
    assert digest(packed[::-1].tobytes())==receipts['rawNativeNormalsDigest']
    native_in_player=dict(a)
    n=a['normals'].copy()
    n[...,0]=1-(packed&1023).astype('f4')/1023
    n[...,1]=((packed>>10)&1023).astype('f4')/1023
    native_in_player['normals']=n
    g=geometry(frame,a['closestDepth'],native_in_player,receipts['crop'],both,fma)
    for step,seed,invert in ((128,0,False),(32,42,True)):
        uv,valid=trace(g,step,seed,invert_y=invert)
        error={k:np.linalg.norm((uv-v)*[2560,1440],axis=-1) for k,v in actual.items()}
        runs['closestDepth-'+str(step)+('-phase42' if invert else '')+'-measuredNormals']=(valid,error)
    x0,y0,_,_=receipts['crop']
    result={}
    for name,(x,y,r,b) in receipts['regions'].items():
        rect=np.zeros(both.shape,bool)
        rect[y-y0:b-y0,x-x0:r-x0]=True
        col=rect&both
        common=col&np.logical_and.reduce([run[0] for run in runs.values()])
        assert common.sum()>.85*col.sum()
        errors={}
        for case,(valid,dist) in runs.items():
            pair={label:[float(x) for x in np.percentile(row[common],[50,90])] for label,row in dist.items()}
            errors[case]=dict(medianAndP90Pixels=pair,tracked=int((valid&col).sum()))
        base=errors['centerDepth-128']['medianAndP90Pixels']['player']
        assert base[0]<.03 and base[1]<.3,(name,base)
        result[name]=dict(all=int(col.sum()),shared=int(common.sum()),cases=errors)
    return result


if __name__=='__main__':
    build=len(sys.argv)==2 and sys.argv[1]=='--record'
    if build:source()
    data=calculate()
    if build:(ROOT/'results.json').write_text(json.dumps(data,indent=2)+'\n')
    else:assert data==read(ROOT/'results.json')
    print(json.dumps(data,indent=2))
    print('PASS: same-frame step sensitivity and observed baseline endpoint validation')
