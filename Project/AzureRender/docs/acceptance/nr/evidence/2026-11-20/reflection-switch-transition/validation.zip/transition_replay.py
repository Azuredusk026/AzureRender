"""Capture and sample the existing reflection program on the switch frame."""
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback
import zlib

import renderdoc as rd

ROOT=Path(os.environ['AZURE_TRANSITION_ROOT'])
REQ=json.loads((ROOT/'request.json').read_bytes())
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools/native_render')
from renderdoc_worker import capture_target


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(path,data):
    (ROOT/path).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')


class TargetEnvironment:
    def __getattr__(self, name):
        return getattr(rd,name)

    def ExecuteAndInject(self,*args):
        args=list(args)
        entries=list(args[3])
        for name,value in REQ['environment'].items():
            change=rd.EnvironmentModification()
            change.name=name
            change.value=value
            change.mod=rd.EnvMod.Set
            entries.append(change)
        args[3]=entries
        return rd.ExecuteAndInject(*args)


def walk(actions):
    for action in actions:
        yield action
        yield from walk(action.children)


def binding_rows(pipe, stage, shader):
    for kind,uses,ds in (('read',pipe.GetReadOnlyResources(stage),shader.readOnlyResources),
                        ('write',pipe.GetReadWriteResources(stage),shader.readWriteResources)):
        for use in uses:
            d=use.descriptor
            decl=ds[use.access.index]
            if d.resource!=rd.ResourceId.Null():
                yield decl.name, (d.resource,d.firstMip,d.numMips,decl.fixedBindNumber,kind)


def replay(path):
    cap=rd.OpenCaptureFile()
    ctl=None
    try:
        assert cap.OpenFile(path,'',None)==rd.ResultCode.Succeeded
        opts=rd.ReplayOptions()
        opts.forceGPUVendor=rd.GPUVendor.nVidia
        opts.forceGPUDeviceID=0x28e0
        status,ctl=cap.OpenCapture(opts,None)
        assert status==rd.ResultCode.Succeeded and not ctl.GetAPIProperties().degraded
        actual_frame=ctl.GetFrameInfo().frameNumber
        assert actual_frame==REQ['frame'],actual_frame
        resources={t.resourceId:t for t in ctl.GetTextures()}
        actions=list(walk(ctl.GetRootActions()))
        ctl.SetFrameEvent(actions[-1].eventId,True)
        final=[]
        for rid,t in resources.items():
            if (t.width,t.height)!=(320,240):
                continue
            fmt=t.format.Name()
            if not fmt.startswith(('R8G8B8A8','B8G8R8A8')):
                continue
            payload=bytes(ctl.GetTextureData(rid,rd.Subresource()))
            if len(payload)!=320*240*4:
                continue
            rgb=bytearray(320*240*3)
            order=(2,1,0) if fmt.startswith('B8G8') else (0,1,2)
            for i,src in enumerate(order):
                rgb[i::3]=payload[src::4]
            if sha(rgb)==REQ['originalFrameRgbSha256']:
                final.append(str(rid))
        assert final,'No final capture texture matches the exact sealed switch frame'
        events={key:[] for key in ('rayProgram','filterProgram')}
        cs=rd.ShaderStage.Compute
        for a in actions:
            if not a.flags&rd.ActionFlags.Dispatch:
                continue
            ctl.SetFrameEvent(a.eventId,True)
            shader=ctl.GetPipelineState().GetShaderReflection(cs)
            if shader is None:
                continue
            digest=sha(bytes(shader.rawBytes))
            for name in events:
                if digest==REQ[name]:
                    events[name].append(a.eventId)
        assert all(len(items)==1 for items in events.values()),events
        event=events['rayProgram'][0]
        ctl.SetFrameEvent(event,True)
        pipe=ctl.GetPipelineState()
        shader=pipe.GetShaderReflection(cs)
        original=pipe.GetShader(cs)
        binds=dict(binding_rows(pipe,cs,shader))
        constant=pipe.GetConstantBlock(cs,0,0).descriptor
        params=bytes(ctl.GetBufferData(constant.resource,constant.byteOffset,480))
        assert len(params)==480
        attachments={}

        def capture_attachment(name, rid, mip=0):
            t=resources[rid]
            w,h=max(1,t.width>>mip),max(1,t.height>>mip)
            data=bytes(ctl.GetTextureData(rid,rd.Subresource(mip,0,0)))
            assert len(data)%(w*h)==0
            enc=zlib.compress(data,6)
            descriptor=dict(resource=str(rid),format=t.format.Name(),extent=[w,h],mip=mip,
                            bytes=len(data),sha256=sha(data),encodedSha256=sha(enc),
                            file=name+'.zlib')
            (ROOT/descriptor['file']).write_bytes(enc)
            attachments[name]=descriptor
            return descriptor

        needed=('previousColor','previousDepth','currentDepth','motionInput','surfaceMask','normalRoughness',
                'outputColor','outputFootprint','outputConfidence')
        for name in needed:
            rid,mip,levels,slot,kind=binds[name]
            entry=capture_attachment(name,rid,mip)
            entry.update(binding=slot,kind=kind,mips=levels,event=event)
        confidence=binds['outputConfidence'][0]
        ctl.SetFrameEvent(event-1,True)
        capture_attachment('eligibility',confidence)
        ctl.SetFrameEvent(event,True)
        hashes={n:attachments[n]['sha256'] for n in ('outputColor','outputFootprint','outputConfidence')}

        def originals():
            return {key:sha(bytes(ctl.GetTextureData(binds[key][0],rd.Subresource())))
                    for key in hashes}

        assert originals()==hashes
        for name,record in REQ['probes'].items():
            program=Path(record['path']).read_bytes()
            assert sha(program)==record['sha256']
            code,error=ctl.BuildTargetShader(shader.entryPoint,rd.ShaderEncoding.SPIRV,program,rd.ShaderCompileFlags(),cs)
            assert code!=rd.ResourceId.Null(),error
            try:
                ctl.ReplaceResource(original,code)
                ctl.SetFrameEvent(event,True)
                probe=capture_attachment(name,binds['outputFootprint'][0])
                values=originals()
                assert values['outputColor']==hashes['outputColor'] and values['outputConfidence']==hashes['outputConfidence']
                assert values['outputFootprint']!=hashes['outputFootprint']
                probe.update(event=event,programSha256=record['sha256'],verifiedOutputs=values)
            finally:
                ctl.RemoveReplacement(original)
                ctl.FreeTargetResource(code)
        ctl.SetFrameEvent(event,True)
        restored=originals()
        assert restored==hashes
        filter_event=events['filterProgram'][0]
        ctl.SetFrameEvent(filter_event,True)
        fpipe=ctl.GetPipelineState()
        fshader=fpipe.GetShaderReflection(cs)
        outputs=[v for v in dict(binding_rows(fpipe,cs,fshader)).values() if v[-1]=='write' and v[0] in resources]
        assert len(outputs)==1,outputs
        output=outputs[0][0]
        capture_attachment('filtered',output)
        consumers=[u.eventId for u in ctl.GetUsage(output) if u.eventId>filter_event and str(u.usage)=='ResourceUsage.PS_Resource']
        write('replay.json',dict(status='verified',frame=actual_frame,events=events,displayResources=final,
            originalFrameRgbSha256=REQ['originalFrameRgbSha256'],filterConsumers=consumers,
            constants=dict(resource=str(constant.resource),offset=constant.byteOffset,hex=params.hex(),sha256=sha(params)),
            attachments=attachments,originalRestored=restored))
    finally:
        if ctl is not None:
            ctl.Shutdown()
        cap.Shutdown()


receipt=dict(status='failed',artifacts=[],started_unix=0)
try:
    try:
        capture_target(TargetEnvironment(),REQ,receipt)
    finally:
        write('capture-receipt.json',receipt)
    assert receipt['capture_frame']==REQ['frame']
    artifact=receipt['artifacts'][0]
    assert artifact['bytes']<REQ['limitBytes']-8388608,artifact
    replay(artifact['path'])
except Exception:
    write('failure.json',dict(traceback=traceback.format_exc()))
    os._exit(1)
os._exit(0)
