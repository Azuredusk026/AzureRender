"""Recompute the switch-frame ray, reprojected sample, and rejection."""
import hashlib
import json
from pathlib import Path
import sys
import zlib

import numpy as np
from PIL import Image

from test_screen_space_reflections_gpu import LEFT, RIGHT, oracle, polygon_mask

ROOT=Path(__file__).resolve().parent
REQ=json.loads((ROOT/'request.json').read_bytes())
READBACK=json.loads((ROOT/'replay.json').read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def open_attachment(key, fmt, components=None):
    meta=READBACK['attachments'][key]
    packed=(ROOT/meta['file']).read_bytes()
    data=zlib.decompress(packed)
    assert sha(packed)==meta['encodedSha256']
    assert sha(data)==meta['sha256'] and len(data)==meta['bytes']
    w,h=meta['extent']
    return np.frombuffer(data,fmt).reshape((h,w,components) if components else (h,w))


def at_uv(values, coords):
    h,w=values.shape[:2]
    x,y=np.clip(np.floor(coords*[w,h]).astype(int),[0,0],[w-1,h-1]).T
    return values[y,x]


def world(uv, depth, matrix):
    device=np.column_stack((2*uv-1,depth,np.ones(len(depth))))
    xyzr=device@matrix
    return xyzr[:,:3]/xyzr[:,3,None]


def ufloat(bits,width,offset):
    mantissa=width-5
    m=((bits>>offset)&((1<<mantissa)-1))/float(1<<mantissa)
    e=((bits>>(offset+mantissa))&31).astype(int)
    return np.ldexp(m+(e>0),np.maximum(1,e)-15)


def interval(values,witness=None):
    if witness is None:
        return [float(np.min(values)),float(np.max(values))]
    return [float(np.min(values-witness)),float(np.max(values-witness))]


def symbol(uv, extent):
    lo=np.floor((uv-.5/65535)*extent)
    hi=np.floor((uv+.5/65535)*extent)
    return np.any(lo!=hi,axis=1)


def main():
    assert READBACK['status']=='verified' and READBACK['frame']==REQ['frame']==4
    assert READBACK['displayResources'] and READBACK['originalFrameRgbSha256']==REQ['originalFrameRgbSha256']
    png=ROOT/'transition.png'
    assert sha(png.read_bytes())==REQ['originalFramePngSha256']
    with Image.open(png) as img:
        assert sha(img.convert('RGB').tobytes())==REQ['originalFrameRgbSha256']
    attachments=READBACK['attachments']
    for key in ('outputColor','outputFootprint','outputConfidence'):
        assert READBACK['originalRestored'][key]==attachments[key]['sha256']
    for key in ('hitUv','historyUv','rayDepth'):
        control=attachments[key]
        assert control['programSha256']==REQ['probes'][key]['sha256']
        for unchanged in ('outputColor','outputConfidence'):
            assert control['verifiedOutputs'][unchanged]==attachments[unchanged]['sha256']
    for key,meta in attachments.items():
        open_attachment(key,'u1',meta['bytes']//(meta['extent'][0]*meta['extent'][1]))
    const=bytes.fromhex(READBACK['constants']['hex'])
    assert sha(const)==READBACK['constants']['sha256']
    p=np.frombuffer(const,'<f4').reshape(30,4).astype(float)
    assert list(p[27])==[0,0,0,1] and list(p[29,2:])==[1,1]
    assert np.all(p[26,2:]==0)
    hit=open_attachment('hitUv','<u2',2)
    prior_uv=open_attachment('historyUv','<u2',2)
    ray_depth=open_attachment('rayDepth','<u2',2)
    eligible=open_attachment('eligibility','u1')>0
    confidence=open_attachment('outputConfidence','u1')
    filter_confidence=open_attachment('filtered','<f4',4)[...,3]
    current_z=open_attachment('currentDepth','<f4')
    history_depth=open_attachment('previousDepth','<f4')
    history_color=open_attachment('previousColor','<f2',4)
    motion=open_attachment('motionInput','<f4',4)
    packed_color=open_attachment('outputColor','<u4')
    right=polygon_mask(oracle(RIGHT)['reflectionPolygon'],.65)[1::2,1::2]
    left=polygon_mask(oracle(LEFT)['reflectionPolygon'],.65)[1::2,1::2]
    assert np.all(eligible[left|right]) and not np.any(confidence[left|right])
    assert not np.any(filter_confidence[left|right])
    assert not np.any(hit[left]) and np.all(np.any(hit[right],axis=1))
    hit_uv=hit[right]/65535
    previous_uv=prior_uv[right]/65535
    rz=ray_depth[right,0]/65535
    assert np.all(ray_depth[right,0]==ray_depth[right,1])
    m=at_uv(motion,hit_uv)
    sampled_z=at_uv(history_depth,previous_uv)
    previous=world(previous_uv,sampled_z,p[18:22])
    tracked_z=1-m[:,2].astype(float)
    tracked=world(previous_uv,tracked_z,p[18:22])
    current=world(hit_uv,rz,p[14:18])
    current_surface=world(hit_uv,at_uv(current_z,hit_uv),p[14:18])
    previous_rgb=at_uv(history_color,previous_uv)[:,:3].astype(float)
    compressed=previous_rgb/(1+np.max(previous_rgb,axis=1,keepdims=True))
    bits=packed_color[right]
    output_rgb=np.column_stack((ufloat(bits,11,0),ufloat(bits,11,11),ufloat(bits,10,22)))
    max_channel_diff=np.max(np.abs(output_rgb-compressed))
    world_error=np.linalg.norm(previous-current,axis=1)
    tracked_error=np.linalg.norm(tracked-previous,axis=1)
    ray_surface_error=np.linalg.norm(current_surface-current,axis=1)
    depth_m=1/(rz*p[24,2]+p[24,3])
    limit=np.maximum(.25,.01*depth_m**2)
    uv_residual=np.max(np.abs(hit_uv-previous_uv-m[:,:2]),axis=1)
    hit_ambiguous=symbol(hit_uv,[320,240])
    prior_ambiguous=symbol(previous_uv,[320,240])|symbol(previous_uv,[160,120])
    exact_route=~(hit_ambiguous|prior_ambiguous)
    assert np.all(exact_route)
    assert np.all(m[:,3]==1) and np.all(sampled_z>0)
    assert np.max(uv_residual)<2/65535
    assert np.all(previous_rgb[:,0]>.7) and max_channel_diff<.005
    assert np.all(world_error>limit)
    assert np.all(tracked_error<limit)
    assert np.all(ray_surface_error<limit)
    record=dict(frame=REQ['frame'],leftReceiverPixels=int(left.sum()),rightReceiverPixels=int(right.sum()),
        rightGeometryHits=int(np.count_nonzero(hit[right].any(axis=1))),rightMotionClassOne=int(np.count_nonzero(m[:,3]==1)),
        rightAcceptedRays=int(np.count_nonzero(confidence[right])),rightFilteredPixels=int(np.count_nonzero(filter_confidence[right])),
        rightUnambiguousRoutePixels=int(np.count_nonzero(exact_route)),
        previousSampleRed=interval(previous_rgb[:,0]),maxCompressedChannelError=float(max_channel_diff),
        originalWorldErrorM=interval(world_error),thresholdM=interval(limit),trackedPreviousWorldErrorM=interval(tracked_error),
        currentSurfaceErrorM=interval(ray_surface_error),horizontalUvDisplacement=interval(m[:,0]),
        maximumUvResidual=float(uv_residual.max()))
    if len(sys.argv)==2 and sys.argv[1]=='--record':
        (ROOT/'computed.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    else:
        recorded=json.loads((ROOT/'computed.json').read_bytes())
        assert recorded.keys()==record.keys()
        for name,value in record.items():
            np.testing.assert_allclose(value,recorded[name], rtol=0,atol=1e-9,err_msg=name)
    print(json.dumps(record,indent=2))
    print('PASS: identical display frame, tracked history, ray color and rejection')


if __name__=='__main__':
    main()

