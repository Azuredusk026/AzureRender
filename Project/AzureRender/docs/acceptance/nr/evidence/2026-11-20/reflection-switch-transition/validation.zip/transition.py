"""Freeze the playable transition input and launch its bounded capture."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

from PIL import Image

ROOT = Path(__file__).resolve().parent
RUNS = ROOT.parent
ENGINE = ROOT.parents[2]
ORIGINAL = RUNS/'20261120-000157-nr-original-reflection-switch-fed32b'/'switch-beauty'
PROBE = RUNS/'20261119-234745-nr-reflection-hit-history-address-d77bf2'
PLAYER = RUNS/'20261119-220148-nr-player-same-frame-capture-31bfb3'
DRIVER = RUNS/'20261112-231945-projected-hair-reference-grid-4b775d'/'nv-vk64-active-absolute.json'
RENDERDOC = Path('D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64')
SDK = Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
FRAME = 4


def read(path):
    return json.loads(path.read_bytes())


def write(path, data):
    path.write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8')


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()


def rgb_sha(path):
    with Image.open(path) as img:
        return hashlib.sha256(img.convert('RGB').tobytes()).hexdigest()


def prepare():
    old = read(ORIGINAL/'receipt.json')
    shared = read(PLAYER/'request.json')
    for name,digest in old['inputSha256'].items():
        assert sha(ORIGINAL/name)==digest
    player = Path(old['command'][0])
    assert sha(player)==shared['playerSha256']
    assert {p.name:sha(p) for p in (player.parent/'shaders').glob('*.spv')}==shared['shaders']
    assert sha(DRIVER)==old['driverSha256']
    trace = read(PROBE/'request.json')['player']
    assert trace['expectedProgram']==shared['playerTraceShader']
    probes={}
    for name in ('hitUv','historyUv','rayDepth'):
        source=PROBE/(name+'.spv')
        assert sha(source)==trace['probes'][name]
        probes[name]={'path':str(source),'sha256':sha(source)}
    capture=ROOT/'capture'
    capture.mkdir(exist_ok=True)
    args=old['command'][1:]
    for flag,path in (('--capture-dir',capture/'frames'),('--runtime-report',capture/'runtime.json')):
        args[args.index(flag)+1]=str(path)
    png=ORIGINAL/'frames'/('frame_{:06}.png'.format(FRAME))
    job=dict(operation='capture',output=str(capture),source=dict(path=str(player),sha256=sha(player),bytes=player.stat().st_size),
        arguments=args,working_directory=str(ENGINE),timeout=90,frame=FRAME, originalFrameRgbSha256=rgb_sha(png),
        originalFramePngSha256=sha(png), frozenInputs=old['inputSha256'], rayProgram=trace['expectedProgram'],
        filterProgram=shared['filterShader'], probes=probes, baseline='a91d233',
        hypothesis='The switch-frame miss is caused by rejected history or non-red history at a geometric hit.',
        environment=dict(VK_DRIVER_FILES=str(DRIVER),VK_LAYER_PATH=str(RENDERDOC)+';'+str(SDK),
            VK_INSTANCE_LAYERS='VK_LAYER_RENDERDOC_Capture;VK_LAYER_KHRONOS_validation',
            VK_LAYER_VALIDATE_SYNC='1',ENABLE_VULKAN_RENDERDOC_CAPTURE='1'),
        renderdocSha256=sha(RENDERDOC/'qrenderdoc.exe'),driverManifestSha256=sha(DRIVER),limitBytes=125829120)
    write(ROOT/'request.json',job)


def execute():
    lease=read(Path('D:/Projects/FYP-coordination/resources/current.json'))
    assert lease['state']=='held' and Path(lease['output']).resolve()==ROOT
    expected=read(ROOT/'request.json')
    source=Path(expected['source']['path'])
    assert sha(source)==expected['source']['sha256']
    assert all(sha(ORIGINAL/name)==h for name,h in expected['frozenInputs'].items())
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = 0
    with (ROOT/'worker.log').open('wb') as log:
        subprocess.run([str(RENDERDOC/'qrenderdoc.exe'),'--python',str(ROOT/'transition_replay.py')],
            cwd=ROOT,env=dict(os.environ,AZURE_TRANSITION_ROOT=str(ROOT)),
            startupinfo=startup,stdout=log,stderr=subprocess.STDOUT,timeout=130,check=True)
    capture=ROOT/'capture'
    shot=capture/'frames'/('frame_{:06}.png'.format(FRAME))
    assert rgb_sha(shot)==expected['originalFrameRgbSha256']
    assert sha(source)==expected['source']['sha256']
    assert all(sha(ORIGINAL/name)==h for name,h in expected['frozenInputs'].items())


if __name__=='__main__':
    {'prepare':prepare,'execute':execute}[sys.argv[1]]()
