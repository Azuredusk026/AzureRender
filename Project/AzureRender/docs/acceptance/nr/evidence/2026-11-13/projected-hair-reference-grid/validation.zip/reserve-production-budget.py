from pathlib import Path
import json
import sys

run=Path(__file__).resolve().parent
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import artifact_maintenance as maintenance

limit=448*1024**2
used=maintenance.measure(run)
assert 0<=used<limit
budget=maintenance.reserve_write(run.parents[1],run,used,limit-used)
assert budget['allowed'],budget
card_path=run/'task-card.json'
card=json.loads(card_path.read_text())
card['plannedBytes']=limit
card_path.write_text(json.dumps(card,indent=2)+'\n')
(run/'expanded-budget.json').write_text(json.dumps(dict(budget,used=used,cap=limit),indent=2)+'\n')
print(json.dumps(budget))

