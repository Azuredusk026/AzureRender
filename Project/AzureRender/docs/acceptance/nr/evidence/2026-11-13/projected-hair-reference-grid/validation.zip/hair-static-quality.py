from pathlib import Path
import json
import runpy
import sys

import cv2
import numpy as np

run = Path(__file__).resolve().parent
score = runpy.run_path(str(run / "static-quality.py"))
base = runpy.run_path(str(run.parent / "20261110-112309-hair-relative-projection-control-b9da17/baseline.py"))
native = base["native"]
assert score["sha"](native) == base["manifest"]["nativeWholeSha256"]
packed = np.fromfile(native, "<u4").reshape(1440, 2560)
channels = []
for shift, bits in ((0, 6), (11, 6), (22, 5)):
    word = (packed >> shift) & ((1 << (bits + 5)) - 1)
    exponent = (word >> bits).astype(np.int32)
    mantissa = word & ((1 << bits) - 1)
    channels.append(np.where(exponent == 0, np.ldexp(mantissa.astype(float), -14-bits),
                    np.ldexp(1 + mantissa / (1 << bits), exponent-15)) * .25)
linear = np.stack(channels, axis=-1)
srgb = np.where(linear <= .0031308, 12.92*linear, 1.055*linear**(1/2.4)-.055)
reference = np.rint(np.clip(srgb, 0, 1)*255).astype(np.uint8)
y0, y1, x0, x1 = (base[key] for key in ("y0", "y1", "x0", "x1"))
mask = np.zeros(reference.shape[:2], bool)
mask[y0:y1, x0:x1] = base["mask"]
matches = [
    img for img in (reference, reference[::-1])
    if np.array_equal(img[y0:y1, x0:x1][base["mask"]], base["expected"][base["mask"]])
]
assert len(matches) == 1
reference, = matches
interior = cv2.erode(mask.astype(np.uint8), score["kernel"]).astype(bool)
assert int(interior.sum()) >= 50
controls = json.loads((run.parent / "20261112-175619-reference-hair-color-triple-d2d080/next-triple-residual-lod.json").read_text())
control = {tuple(row["display"]): row for row in controls["pixels"]}
report = dict(referenceSha256=score["sha"](native), masks={"rawOpaqueHair": int(mask.sum()), "qualifiedInterior": int(interior.sum())}, cases={})
for label in sys.argv[1:]:
    path = run / f"{label}-frames/frame_000000.png"
    actual = score["image"](path)
    cases = score["compare"](reference, actual, {"unqualifiedWindows": mask, "qualifiedInterior": interior})
    delta = np.abs(actual.astype(np.int16)-reference.astype(np.int16)).max(axis=2)
    excess = (delta > 1) & mask
    diagnostics = []
    for y, x in np.argwhere(excess):
        data = control[(int(x), int(y))]
        assert data["native"] == reference[y, x].tolist()
        diagnostics.append(dict(display=[int(x), int(y)], actual=actual[y, x].tolist(),
                                expected=data["native"], rgbError=int(delta[y, x]),
                                visibilityError=data["visibilityError"], normalError=data["normalError"],
                                referenceLod=data["referenceLod"], nearMipBoundary=data["nearReferenceMipBoundary"]))
    report["cases"][label] = dict(frameSha256=score["sha"](path), regions=cases,
                                  rgbOverOne=int(excess.sum()), maximumByteError=int(delta[mask].max()),
                                  visibilityOverOne=sum(row["visibilityError"] > 1 for row in diagnostics),
                                  normalOverOne=sum(row["normalError"] > 1 for row in diagnostics),
                                  nearMipBoundary=sum(row["nearMipBoundary"] for row in diagnostics),
                                  residuals=diagnostics)
    known = json.loads((run / f"{label}-results.json").read_text())["colors"][0]
    assert int(excess.sum()) == known["overOne"] and int(delta[mask].max()) == known["maximum"]
(run / "hair-static-results.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({label: {k: v for k, v in case.items() if k != "residuals"} for label, case in report["cases"].items()}))