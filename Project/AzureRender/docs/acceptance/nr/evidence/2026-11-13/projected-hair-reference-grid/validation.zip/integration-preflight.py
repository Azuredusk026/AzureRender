from hashlib import sha256
from pathlib import Path
import json
import subprocess

run = Path(__file__).resolve().parent
engine = run.parents[2]
out = run / "integration-preflight"
out.mkdir(exist_ok=True)
provenance = json.loads((run/"source-provenance.json").read_text())
base = provenance["candidateBase"]
main = provenance["mainIntegration"]
def git_blob(commit,path):
    return subprocess.check_output(["git","-C",str(engine),"show",f"{commit}:Project/AzureRender/{path}"])

report = {}
for path,fingerprint in provenance["candidatePaths"].items():
    current=(engine/path).read_bytes()
    assert sha256(current).hexdigest()==fingerprint
    normalized=current.replace(b"\r\n",b"\n")
    base_blob, main_blob=(git_blob(commit,path) for commit in (base,main))
    if base_blob==main_blob:
        report[path]=dict(result="no-upstream-overlap")
        continue
    folder=out/Path(path).name
    folder.mkdir(exist_ok=True)
    files=(folder/"quality",folder/"base",folder/"main")
    for file,data in zip(files,(normalized,base_blob,main_blob)):
        file.write_bytes(data)
    result=subprocess.run(["git","merge-file","-p",*map(str,files)],capture_output=True)
    assert result.returncode in (0,1,2), result.stderr
    (folder/"merged").write_bytes(result.stdout)
    report[path]=dict(result="merged" if result.returncode==0 else "conflict", conflicts=result.returncode,
                      mergedSha256=sha256(result.stdout).hexdigest())
(run/"integration-preflight.json").write_text(json.dumps(dict(main=main, base=base,paths=report),indent=2)+"\n")
print(json.dumps(report,indent=2))