from pathlib import Path
import json
import subprocess
import sys


out = Path(__file__).resolve().parent
engine = out.parents[2]
configuration, = sys.argv[1:]
assert configuration in ('Release', 'Debug')
name = configuration.lower()
build = out.parent / ('20261110-030251-hair-main-chroma-public-9e799c/release' if configuration == 'Release'
    else '20261110-031856-hair-main-chroma-debug-668bf2/debug')
cmake = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
env = 'D:/Projects/FYP/Project/AzureRender/tools/msvc_env.bat'
targets = ['AzurePlayer', 'AzureReferenceCameraViewTests', 'AzureProjectReferenceViewsTests', 'AzureRenderExtensionRegistryTests',
    'AzureReferenceCameraBindingTests', 'AzureScreenObjectVisibilityTests', 'AzureScreenObjectVisibilityGpuTests',
    'AzureReferenceDepthGpuTests', 'AzureReferenceDepthCoverageGpuTests', 'AzureSurfaceResponseGpuTests', 'AzureMaterialCoverageTests',
    'AzureMaterialDocumentTests', 'AzureCharacterRepairTests', 'AzureMaterialUvPolicyTests', 'AzureMaterialUvImportTests', 'AzureMaterialUvGradientsGpuTests']
if configuration == 'Release':
    targets += ['AzureRender', 'AzureEditorProjectFlowTests']
groups = [targets] if configuration == 'Release' else [targets[1:12], *([target] for target in targets[12:]), targets[:1]]
parallel = '4' if configuration == 'Release' else '2'
commands = [[env, cmake, '--build', str(build), '--target', *group, '--parallel', parallel] for group in groups]
(out / (name + '-build-commands.json')).write_text(json.dumps(commands, indent=2) + '\n')
symbols = []
with (out / (name + '-build.log')).open('wb') as log:
    for command, group in zip(commands, groups):
        subprocess.run(subprocess.list2cmdline(command), shell=True, cwd=engine, stdout=log, stderr=subprocess.STDOUT,
            timeout=900, check=True)
        if configuration == 'Debug':
            from archive_debug_symbols import archive_targets
            symbols.extend(archive_targets(build.resolve(strict=True), group))
if configuration == 'Debug':
    ninja = 'D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe'
    remaining = subprocess.check_output([ninja, '-C', str(build), '-n', *targets], text=True)
    assert '[1/1]' in remaining and 'generate_script_bindings.py --check' in remaining and 'Linking' not in remaining, remaining
    (out / 'debug-symbols.json').write_text(json.dumps(dict(symbols=symbols, dryRun=remaining), indent=2) + '\n')
