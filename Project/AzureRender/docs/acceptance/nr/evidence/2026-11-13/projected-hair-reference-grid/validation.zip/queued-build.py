from pathlib import Path
import json
import sys
import time


out=Path(__file__).resolve().parent
build=out.parents[1]
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')


def run(folder,label,script,*args,timeout):
    command=[sys.executable,'-B',str(out/script),*args]
    result=shared.maintenance.guarded_run(build,folder,command,timeout)
    write(out/(label+'-execution.json'),result)
    print(json.dumps(result),flush=True)
    assert result['status']=='exited' and result['exitCode']==0,result


configuration,predecessor,receipt_path=sys.argv[1:]
assert configuration in ('Release','Debug')
name=configuration.lower()
deadline=time.monotonic()+1800
while time.monotonic()<deadline:
    try:
        state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
        receipt=json.loads(Path(receipt_path).read_text())
    except (OSError,ValueError):
        time.sleep(1)
        continue
    assert state['token']==receipt['token']==predecessor
    if state['state']==receipt['state']=='released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed projected hair raster grid build window has not opened')
write(out/(name+'-build-predecessor.json'),receipt)
lease=None
try:
    with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a',
        'quality-projected-hair-reference-grid-build-'+name,out) as lease:
        write(out/(name+'-build-lease-held.json'),lease)
        parent=('20261110-030251-hair-main-chroma-public-9e799c' if configuration=='Release'
            else '20261110-031856-hair-main-chroma-debug-668bf2')
        shared.maintenance.resume(build,parent)
        if configuration=='Debug':
            run(parent,'debug-prepare','prepare-debug-budget.py',timeout=120)
        run(parent,name+'-build','build.py',configuration,timeout=950)
        run(out.name,name+'-cpu-tests','verify-build.py',configuration,timeout=360)
finally:
    if lease is not None:
        write(out/(name+'-build-lease-released.json'),lease)

