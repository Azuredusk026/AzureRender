from pathlib import Path
import json
import runpy

import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
tools=runpy.run_path(str(run/"static-quality.py"))
read=tools["image"]
reference=read(tools["reference_path"])
receipts=run/"native-face-masks"
metadata=json.loads((receipts/"result.json").read_text())
assert metadata["status"]=="qualified"
masks={}
for name in ("iris","skin","face"):
    path=receipts/f"{name}.png"
    assert tools["sha"](path)==metadata["masks"][name]["sha256"]
    with Image.open(path) as image:
        raw=np.asarray(image)>0
    assert int(raw.sum())==metadata["masks"][name]["pixels"]
    if name=="iris":
        masks[name]=raw
    else:
        masks[name]=tools["cv2"].erode(raw.astype(np.uint8),tools["kernel"]).astype(bool)
        assert int(masks[name].sum())>=50
cases={}
for label in ("static-nvidia","static-intel","release-nvidia","release-intel"):
    source=run/f"{label}-frames/frame_000000.png"
    candidate=read(source)
    delta=np.abs(reference.astype(np.int16)-candidate.astype(np.int16)).max(axis=2)
    result=tools["compare"](reference,candidate,masks)
    for name,mask in masks.items():
        result[name].update(overOne=int((delta[mask]>1).sum()),maxByte=int(delta[mask].max()),
            meanMaxByte=float(delta[mask].mean()),p95Byte=float(np.quantile(delta[mask],.95)))
    cases[label]=dict(sha256=tools["sha"](source),regions=result)
report=dict(referenceSha256=tools["sha"](tools["reference_path"]),masks=metadata["masks"],cases=cases,
    method="Iris: actual opaque draw ownership and final composite RGB. Skin/face: opaque ownership eroded six pixels.")
(run/"face-and-skin-results.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({key:val["regions"] for key,val in cases.items()}))