from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import traceback
import zlib
import renderdoc as rd

request=json.loads(Path(os.environ["AZURE_NATIVE_FACE_MASK_REQUEST"]).read_text())
out=Path(request["output"])
capture=rd.OpenCaptureFile()
receipt=dict(status="failed", masks={}, captureSha256=request["captureSha256"])

def read(controller,event,target):
    controller.SetFrameEvent(event,True)
    data=bytes(controller.GetTextureData(target,rd.Subresource()))
    assert len(data)==2560*1440*4,(event,len(data))
    return data

def chunk(name,data):
    content=name+data
    return struct.pack(">I",len(data))+content+struct.pack(">I",zlib.crc32(content))

def mask(before,after,opaque):
    a,b,c=(memoryview(value).cast("I") for value in (before,after,opaque))
    rows=[bytes(255 if x!=y and y==z else 0 for x,y,z in zip(a[i:i+2560],b[i:i+2560],c[i:i+2560]))
          for i in range(len(a)-2560,-1,-2560)]
    count=sum(row.count(b"\xff") for row in rows)
    pixels=b"".join(b"\0"+row for row in rows)
    data=b"\x89PNG\r\n\x1a\n"+chunk(b"IHDR",struct.pack(">IIBBBBB",2560,1440,8,0,0,0,0))
    data+=chunk(b"IDAT",zlib.compress(pixels))+chunk(b"IEND",b"")
    return count,data

try:
    assert capture.OpenFile(request["native"],"",None)==rd.ResultCode.Succeeded
    options=rd.ReplayOptions()
    options.forceGPUVendor=rd.GPUVendor.nVidia
    options.forceGPUDeviceID=0x28e0
    status,controller=capture.OpenCapture(options,None)
    assert status==rd.ResultCode.Succeeded and controller
    try:
        prop=controller.GetAPIProperties()
        assert prop.vendor==rd.GPUVendor.nVidia and prop.pipelineType==rd.GraphicsAPI.D3D11 and not prop.degraded
        controller.SetFrameEvent(846,True)
        target=controller.GetPipelineState().GetOutputTargets()[0].resource
        receipt["target"]=str(target)
        opaque=read(controller,950,target)
        for label,event in (("iris",846),("face",804),("skin",783)):
            controller.SetFrameEvent(event,True)
            bound=controller.GetPipelineState().GetOutputTargets()[0].resource
            assert bound==target,(label,str(bound),str(target))
            before=read(controller,event-1,target)
            after=read(controller,event,target)
            pixels,png=mask(before,after,opaque)
            (out/f"{label}.png").write_bytes(png)
            receipt["masks"][label]=dict(event=event,pixels=pixels,sha256=sha256(png).hexdigest())
        assert receipt["masks"]["iris"]["pixels"]==255
        assert receipt["masks"]["face"]["pixels"]>1176 and receipt["masks"]["skin"]["pixels"]>28966
    finally:
        controller.Shutdown()
    receipt["status"]="qualified"
except Exception:
    receipt["error"]=traceback.format_exc()
finally:
    capture.Shutdown()
    (out/"result.json").write_text(json.dumps(receipt,indent=2)+"\n")
os._exit(0 if receipt["status"]=="qualified" else 1)