from pathlib import Path
import json
import os
import re
import runpy
import subprocess
import sys

import numpy as np

run = Path(__file__).resolve().parent
score = runpy.run_path(str(run / "static-quality.py"))
sha, image, blur, luma, weights = (score[k] for k in ("sha","image","blur","luma","weights"))
main = Path("D:/Projects/FYP/Project/AzureRender")
source = main / "build/runs/20261101-043757-material-display-transform-93d6e0"
previous = json.loads((source/"native-final-comparison.json").read_text())["comparisons"][1]
reference_path = Path(previous["reference"])
historical_path = Path(previous["candidate"])
assert sha(reference_path) == previous["referenceSha256"] and sha(historical_path) == previous["candidateSha256"]
reference = image(reference_path).astype(float)/255
assert reference.shape == (1536, 1536, 3)

def compare(candidate_path):
    candidate = image(candidate_path).astype(float)/255
    assert candidate.shape == reference.shape
    result = {}
    for row in previous["regions"][:5]:
        x0,y0,x1,y1 = row["bounds"]
        a = reference[y0:y1,x0:x1]
        b = candidate[y0:y1,x0:x1]
        p,q = a @ weights, b @ weights
        u,v = blur(p),blur(q)
        scores = ((2*u*v + .01**2)*(2*(blur(p*q)-u*v) + .03**2))/(
            (u*u+v*v+.01**2)*(blur(p*p)-u*u+blur(q*q)-v*v+.03**2))
        ssim = float(scores[5:-5,5:-5].mean())
        native_median, candidate_median = np.median(luma(a)), np.median(luma(b))
        error = float(abs(candidate_median-native_median)/native_median)
        result[row["region"]] = dict(bounds=row["bounds"],ssim=ssim,medianLuminanceRelativeError=error,
                                     passed=ssim>=.95 and error<=.1)
    return result

control = compare(historical_path)
for row in previous["regions"][:5]:
    actual = control[row["region"]]
    assert abs(actual["ssim"]-row["staticLuminanceSsim"])<1e-10
    assert abs(actual["medianLuminanceRelativeError"]-row["medianLuminanceRelativeError"])<1e-10
report = dict(control=control, referenceSha256=sha(reference_path), cases={})
devices = sys.argv[1:]
assert all(device in ("nvidia","intel") for device in devices)
if devices:
    status = json.loads(Path("D:/Projects/FYP-coordination/resources/current.json").read_text())
    assert status["state"]=="held" and Path(status["output"])==run
    manifest = json.loads((source/"native-final-capture-summary.json").read_text())
    assert manifest["status"]=="captured-inputs-unchanged"
    for name,digest in manifest["inputs"].items():
        assert sha(main/name)==digest, name
    build = run.parent/"20261110-030251-hair-main-chroma-public-9e799c/release"
    runpy.run_path(str(run / "verify-release-catalog.py"))["verify"](run, build, restore_known_control=True)
    player = build/"AzurePlayer.exe"
    fingerprint = json.loads((run/"release-verification.json").read_text())["playerSha256"]
    assert sha(player)==fingerprint
    argv = json.loads((source/"native-final-captures/near-world-linear/command.json").read_text())["command"]
    argv[0] = str(player)
    argv.extend(("--resource-root",str(build)))
    for device in devices:
        frames = run/f"portrait-{device}-frames"
        argv[argv.index("--capture-dir")+1] = str(frames)
        argv[argv.index("--runtime-report")+1] = str(run/f"portrait-{device}-runtime.json")
        (run/f"portrait-{device}-command.json").write_text(json.dumps(argv,indent=2)+"\n")
        env = os.environ.copy()
        for key in ("VK_DRIVER_FILES","VK_ICD_FILENAMES","VK_LAYER_ENABLES"):
            env.pop(key,None)
        env.update(VK_LOADER_DRIVERS_SELECT="*igvk64*" if device=="intel" else "*nv-vk64*",
                   VK_INSTANCE_LAYERS="VK_LAYER_KHRONOS_validation", VK_LAYER_VALIDATE_SYNC="1")
        log_file = run/f"portrait-{device}.log"
        with log_file.open("wb") as log:
            process = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, env=env, timeout=300)
        log = log_file.read_text(errors="replace")
        assert process.returncode==0 and "Allocator after unload: buffers=0 images=0" in log,log[-4000:]
        assert not re.search(r"VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]",log,re.I),log[-4000:]
        frame = frames/"frame_000000.png"
        gpu = json.loads((frames/"gpu_capabilities.json").read_text())
        assert gpu["vendor_id"]==(0x8086 if device=="intel" else 0x10de)
        report["cases"][device] = dict(frameSha256=sha(frame),playerSha256=fingerprint,regions=compare(frame))
        (run/"portrait-results.json").write_text(json.dumps(report,indent=2)+"\n")
    assert sha(player)==fingerprint
    assert all(sha(main/name)==digest for name,digest in manifest["inputs"].items())
print(json.dumps(report,indent=2))