from pathlib import Path
import json
import os
import subprocess
import sys

run = Path(__file__).resolve().parent
sys.path.insert(0, str(run.parents[2] / "tools"))
from artifact_budget import check

batch, = sys.argv[1:]
assert batch in ("release-capture", "debug-capture", "original-four")
lease = json.loads(Path("D:/Projects/FYP-coordination/resources/current.json").read_text())
assert lease["state"] == "held" and Path(lease["output"]) == run

def execute(script, *args, timeout):
    if script in ("capture.py", "default-four.py"):
        planned = 64 * 2**20 if script == "capture.py" else 25_000_000
        budget = check(run.parents[1], run=run, planned=planned)
        assert budget["allowed"], budget
    subprocess.run([sys.executable, "-B", str(run / script), *args], check=True, timeout=timeout)

for key in ("VK_DRIVER_FILES", "VK_ICD_FILENAMES", "VK_LAYER_ENABLES", "VK_LOADER_DRIVERS_SELECT"):
    os.environ.pop(key, None)
os.environ.update(VK_INSTANCE_LAYERS="VK_LAYER_KHRONOS_validation", VK_LAYER_VALIDATE_SYNC="1")
if batch == "original-four":
    os.environ["VK_LOADER_DRIVERS_SELECT"] = "*nv-vk64*"
    execute("default-four.py", timeout=650)
else:
    configuration = batch.split("-")[0].title()
    for device, selection in (("nvidia", "*nv-vk64*"), ("intel", "*igvk64*")):
        os.environ["VK_LOADER_DRIVERS_SELECT"] = selection
        execute("verify-build.py", configuration, device, timeout=390)
        execute("capture.py", configuration, device, timeout=390)
        execute("compact-capture.py", f"{configuration.lower()}-{device}-frames", timeout=60)
    if configuration == "Release":
        os.environ["VK_LOADER_DRIVERS_SELECT"] = "*nv-vk64*"
        execute("capture.py", configuration, "nvidia", "indexed", timeout=390)
        execute("compact-capture.py", "release-nvidia-indexed-frames", timeout=60)