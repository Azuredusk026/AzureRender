from pathlib import Path
import json
import os
import subprocess
import sys

run=Path(__file__).resolve().parent
assert json.loads((run/"debug-symbols.json").read_text())["status"]=="recovered"
assert json.loads((run/"debug-verification.json").read_text())["tests"]==10
for device in ("nvidia","intel"):
    assert json.loads((run/f"debug-{device}-gpu-verification.json").read_text())["tests"]==6
assert all(row["exact"] for row in json.loads((run/"debug-nvidia-results.json").read_text())["attachments"].values())
assert not (run/"debug-intel-frames").exists()
sys.path.insert(0,str(run.parents[2]/"tools"))
from artifact_budget import check
# The five readback planes use 55,296,000 bytes. The same fixture's three PNGs use under 3 MiB.
budget=check(run.parents[1],run=run,planned=56*2**20)
assert budget["allowed"],budget
for key in ("VK_DRIVER_FILES","VK_ICD_FILENAMES","VK_LAYER_ENABLES"):
    os.environ.pop(key,None)
os.environ.update(VK_INSTANCE_LAYERS="VK_LAYER_KHRONOS_validation",VK_LAYER_VALIDATE_SYNC="1",
                  VK_LOADER_DRIVERS_SELECT="*igvk64*")
subprocess.run([sys.executable,"-B",str(run/"capture.py"),"Debug","intel"],check=True,timeout=390)
subprocess.run([sys.executable,"-B",str(run/"compact-capture.py"),"debug-intel-frames"],check=True,timeout=60)