from hashlib import sha256
from pathlib import Path
import json
import subprocess

run = Path(__file__).resolve().parent
engine = run.parents[2]
main = Path("D:/Projects/FYP/Project/AzureRender")

def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args])

paths = git(engine, "diff", "--name-only", "--relative", "-z").decode().strip("\0").split("\0")
assert len(paths) == 8
reference = main / "docs/acceptance/nr/evidence/2026-11-12/projected-hair-viewport-integration/results.json"
merge = "01cc6b26e52d8d602aae1b75d7259a5da4f10dbd"
point_mip = "48847a4caa9031d7ccc70e90c093c9fab81984a3"
head = git(main, "rev-parse", "HEAD").decode().strip()
for commit in (point_mip, merge):
    subprocess.run(["git", "-C", str(main), "merge-base", "--is-ancestor", commit, head], check=True)
diff = git(engine, "diff", "--binary", "--relative")
(run / "handoff-candidate.patch").write_bytes(diff)
doc = dict(mainHead=head, mainIntegration=merge, threeTextureSource=point_mip,
           independentIntegrationEvidenceSha256=sha256(reference.read_bytes()).hexdigest(),
           candidateBase=git(engine, "rev-parse", "HEAD").decode().strip(),
           candidateDiffSha256=sha256(diff).hexdigest(),
           candidatePaths={path: sha256((engine / path).read_bytes()).hexdigest() for path in paths})
(run / "source-provenance.json").write_text(json.dumps(doc, indent=2) + "\n")
print(json.dumps({key: val for key, val in doc.items() if key != "candidatePaths"}))