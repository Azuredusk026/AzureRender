from hashlib import file_digest
from pathlib import Path
import gzip
import json
import shutil
import subprocess
import sys


out = Path(__file__).resolve().parent
engine = out.parents[2]
sys.path.insert(0, str(engine / 'tools'))
from artifact_maintenance import measure


def archive_targets(build, targets):
    archive = out / 'build-symbols'
    archive.mkdir(exist_ok=True)
    assert archive.resolve().parent == out and build.resolve() == build
    rules = (build / 'build.ninja').read_text(encoding='utf-8').splitlines()
    archived = []
    for target in targets:
        symbols = build / (target + '.pdb')
        if not symbols.is_file():
            continue
        assert not symbols.is_symlink() and symbols.resolve(strict=True).parent == build and symbols.stat().st_nlink == 1
        assert subprocess.run(['git', '-C', str(engine), 'check-ignore', '-q', str(symbols)]).returncode == 0
        assert not any(symbols.name in line for line in rules if line.startswith('build ' + target + '.exe'))
        destination = archive / (symbols.name + '.gz')
        assert not destination.exists()
        size = symbols.stat().st_size
        with symbols.open('rb') as stream:
            fingerprint = file_digest(stream, 'sha256').hexdigest()
        try:
            with symbols.open('rb') as stream, gzip.open(destination, 'xb', compresslevel=3) as encoded:
                shutil.copyfileobj(stream, encoded, 1024 * 1024)
            with gzip.open(destination, 'rb') as encoded:
                assert file_digest(encoded, 'sha256').hexdigest() == fingerprint
            assert measure(out) <= json.loads((out/'task-card.json').read_text())['plannedBytes']
        except Exception:
            if destination.exists():
                destination.unlink()
            raise
        symbols.unlink()
        archived.append(dict(file=symbols.name, bytes=size, sha256=fingerprint, archive=str(destination)))
    return archived
