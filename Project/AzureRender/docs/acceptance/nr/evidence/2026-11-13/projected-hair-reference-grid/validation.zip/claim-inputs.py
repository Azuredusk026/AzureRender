
from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys


out=Path(__file__).resolve().parent
build=out.parents[1]
main=Path('D:/Projects/FYP/Project/AzureRender/build')
owner='01a1c099-8121-7be3-b0b8-7af2f9a06b2a'
sys.path.insert(0,str(main.parent/'tools'))
import shared_resources as shared


claim_path=Path('D:/Projects/FYP-coordination/quality-claim.json')
claim=json.loads(claim_path.read_text(encoding='utf-8'))
assert claim['threadId']==owner and claim['state']=='reference-raster-isolated'
source,parent=subprocess.check_output(['git','log','-1','--format=%H%n%P'],cwd=build.parent,text=True).splitlines()
assert parent==claim['lastCommit']=='eb05be0008bbbc7fc737b925eec079d10b2d6f6b'
assert source=='1cceff89e7f7ac40c5e2085045063470c2306083'
folder=build.parent/'docs/acceptance/nr/evidence/2026-11-12/reference-raster-isolated'
results=json.loads((folder/'results.json').read_text())
assert results['status']=='qualified-isolated-raster-and-receiver-sources' and results['lease']['state']=='released'
assert sha256((folder/'validation.zip').read_bytes()).hexdigest()==results['archive']['sha256']
previous=Path(claim['taskPath'])
assert previous.name=='20261112-230338-reference-raster-isolated-c086fb'
old_local,old_main=claim['localInputLease'],claim['inputLease']


def inherited(root,tokens):
    with shared.maintenance.database(root,True) as db:
        records=shared.maintenance.rows(db)
    assert all(records[token]['owner']==owner for token in tokens)
    return list(dict.fromkeys(name for token in tokens for name in records[token]['inputs']))


local_inputs=inherited(build,old_local)+[previous.name]
main_inputs=inherited(main,old_main)
local=shared.acquire_inputs(build,out,local_inputs,owner)
try:
    native=shared.acquire_inputs(main,out,main_inputs,owner)
except Exception:
    shared.release_inputs(build,local,owner)
    raise
claim.update(state='projected-hair-reference-grid',taskPath=str(out),inputLease=[native],localInputLease=[local],
    nativeCaptureLease=native,lastCommit=source,additionalTaskPaths=[],
    pendingCommand='Implement and validate the opt-in projected hair reference raster grid on both configurations and devices',
    ownedFiles=['src/assets/GltfLoader.cpp','src/assets/GltfLoader.hpp','src/assets/MaterialData.cpp',
        'src/assets/MaterialSurfaceProfile.hpp','shaders/mesh.vert','schemas/azure_render_material.schema.json',
        'tests/CharacterRepairTests.cpp','docs/runtime/projected-hair-lighting.md','README.md','CHANGELOG.md',
        'docs/plans/2026-11-09-native-quality.md','docs/plans/azure-engine-plan.md',
        'docs/acceptance/nr/projected-hair-reference-grid.md','docs/acceptance/nr/evidence/2026-11-12/projected-hair-reference-grid'])
claim['observed'].update(isolatedGridIntelRgb=31,isolatedGridIntelOutsideFrozenOverOne=0,bodyFocusNativeAtlasValue=27)
(out/'task-card.json').write_text(json.dumps(dict(local=local,main=native,sourceBase=source,plannedBytes=100663296,
    localInputs=local_inputs,mainInputs=main_inputs,change='Opt-in reference camera subpixel position for projected opaque hair with function-local precision',
    gate='Exact equality to the qualified isolated raster control, default four frames and scoped dual-configuration dual-device regression'),indent=2)+'\n')
temporary=claim_path.with_name(claim_path.name+'.nr-quality-new')
with temporary.open('x',encoding='utf-8') as stream:
    json.dump(claim,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
os.replace(temporary,claim_path)
for token in old_main:
    shared.release_inputs(main,token,owner)
for token in old_local:
    shared.release_inputs(build,token,owner)
print(json.dumps(dict(local=local,main=native,output=str(out))))
