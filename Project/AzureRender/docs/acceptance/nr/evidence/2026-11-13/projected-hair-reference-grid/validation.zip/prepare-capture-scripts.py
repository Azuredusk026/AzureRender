from pathlib import Path

run=Path(__file__).resolve().parent
old=run.parent/'20261112-182312-projected-hair-point-mip-82adc1'
source=(old/'prepare-fixture.py').read_text()


def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)


replace('import struct','import struct\nimport sys')
replace("baseline=run.parent/'20261112-153052-reference-hair-mip-footprint-510ded'",
    "baseline=run.parent/'20261112-182312-projected-hair-point-mip-82adc1'\npreflight=sys.argv[1:]==['--preflight']")
replace("""    path.parent.mkdir(parents=True,exist_ok=True)
    if path.suffix!='.glb':
        copyfile(original,path)
        assert digest(path)==item['sha256']""",
"""    if not preflight:
        path.parent.mkdir(parents=True,exist_ok=True)
    if relative.as_posix()!='character/hair-coverage.glb':
        if not preflight:
            copyfile(original,path)
            assert digest(path)==item['sha256']""")
replace("""    assert 'primaryTextureFootprint' not in ramp
    ramp['primaryTextureFootprint']='axis-diagonal'""",
"""    assert ramp['primaryTextureFootprint']=='axis-diagonal' and 'referenceRasterGrid' not in ramp
    ramp['referenceRasterGrid']='nearest-8'""")
replace("""    path.write_bytes(new)
    assert path.read_bytes()[20+len(encoded):]==binary
    changed.append(dict(relative=item['relative'],originalSha256=item['sha256'],candidateSha256=digest(path),""",
"""    assert ramp.pop('referenceRasterGrid')=='nearest-8' and document==json.loads(raw[20:20+json_size])
    if not preflight:
        with path.open('xb') as stream:
            stream.write(new)
        assert path.read_bytes()[20+len(encoded):]==binary
    changed.append(dict(relative=item['relative'],originalSha256=item['sha256'],candidateSha256=sha256(new).hexdigest(),""")
replace("""assert len(changed)==1
files=""","""assert len(changed)==1
if preflight:
    print(json.dumps(dict(files=len(manifest),changed=changed)))
    raise SystemExit(0)
files=""")
(run/'prepare-fixture.py').write_text(source,encoding='utf-8')
source=(old/'capture.py').read_text()
replace("boundary=root/'20261112-164303-reference-hair-mip-boundary-342000'",
    "boundary=root/'20261112-182312-projected-hair-point-mip-82adc1'")
replace("triple=root/'20261112-175619-reference-hair-color-triple-d2d080/triple'",
    "isolated=root/'20261112-230338-reference-raster-isolated-c086fb/grid'")
replace("control=json.loads((triple/(device+'-results.json')).read_text())\nassert all(item['exact'] for item in control['attachments'].values())",
    "control=json.loads((isolated/(device+'-results.json')).read_text())\nassert all(item['exact'] for item in control['planes'].values())")
replace("expected=triple/(device+'-frames')/name","expected=isolated/(device+'-frames')/name")
replace("expectedSha256=control['colors'][index]['after']","expectedSha256=control['colors'][index]['sha256']")
replace("referenceNormal=previous['normal']","referenceNormal=previous['referenceNormal']")
replace("else 32) for row in report","else 31) for row in report")
replace("assert ('Character texture access: indexed' if indexed else 'Character texture access: fixed') in log",
"""assert ('Character texture access: indexed' if indexed else 'Character texture access: fixed') in log
hair_flags=re.search(r'M_actor_laevat_hair_01 -> hair, flags=0x([0-9a-f]+)',log,re.I)
assert hair_flags and int(hair_flags[1],16)&(1<<29)""")
(run/'capture.py').write_text(source,encoding='utf-8')
for name in ('prepare-fixture.py','capture.py'):
    path=run/name
    compile(path.read_bytes(),str(path),'exec')

