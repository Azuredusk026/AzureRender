from hashlib import file_digest
from pathlib import Path
import gzip
import json
import os
import re
import runpy
import subprocess
import sys

import cv2
import numpy as np
from PIL import Image

cv2.setNumThreads(1)
run = Path(__file__).resolve().parent
main = Path("D:/Projects/FYP/Project/AzureRender")
main_runs = main / "build/runs"
stages = main_runs / "20261103-234012-character-reference-stages-5abe6c"
cloth = main_runs / "20261101-143507-native-cloth-variants-d877ef"
hair = main_runs / "20261023-105023-character-composite-contribution-diagnosis-acb8e5"
background = stages / "snapshot-shell-order-regression/release-background"
reference_path = stages / "snapshot-shell-cloth-reference.png"
weights = np.array([.2126, .7152, .0722])
kernel = np.ones((13, 13), np.uint8)

def sha(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()

def image(path):
    with Image.open(path) as opened:
        return np.asarray(opened.convert("RGB"))

def native_words(path):
    return np.fromfile(path, "<u4").reshape(1440, 2560)[::-1]

def blur(image):
    return cv2.GaussianBlur(image, (11, 11), 1.5)

def luma(image):
    linear = np.where(image <= .04045, image / 12.92, ((image + .055) / 1.055) ** 2.4)
    return linear @ weights

def compare(reference, actual, masks):
    assert reference.shape == actual.shape == (1440, 2560, 3)
    reference = reference.astype(np.float64) / 255
    actual = actual.astype(np.float64) / 255
    x, y = reference @ weights, actual @ weights
    u, v = blur(x), blur(y)
    scores = ((2*u*v + .01**2) * (2*(blur(x*y) - u*v) + .03**2)) / (
        (u*u + v*v + .01**2) * (blur(x*x) - u*u + blur(y*y) - v*v + .03**2)
    )
    reference_luma, actual_luma = luma(reference), luma(actual)
    rows = {}
    for name, mask in masks.items():
        native_median = float(np.median(reference_luma[mask]))
        actual_median = float(np.median(actual_luma[mask]))
        ssim = float(scores[mask].mean())
        error = abs(actual_median - native_median) / max(native_median, 1e-12)
        rows[name] = dict(pixels=int(mask.sum()), ssim=ssim, medianLuminanceRelativeError=error,
                          passed=ssim >= .95 and error <= .10)
    return rows

def masks():
    packed = native_words(hair / "after-hair.bin")
    result = {}
    for draw in json.loads((cloth / "variant-targets.json").read_text())["draws"]:
        if draw["event"] == 1383:
            continue
        before, after = (native_words(cloth / "variant-targets" / item["path"]) for item in draw["outputs"])
        selection = ((before != after) & (after == packed)).astype(np.uint8)
        result[f"cloth-{draw['event']}"] = cv2.erode(selection, kernel).astype(bool)

    owner = np.zeros((1440, 2560), np.uint16)
    directory = stages / "post-opaque-ownership"
    for row in json.loads((directory / "manifest.json").read_text())["events"]:
        before, after = (
            np.frombuffer(gzip.decompress((directory / name).read_bytes()), "<u4").reshape(1440, 2560)[::-1]
            for name in row["files"]
        )
        owner[before != after] = row["event"]
    with Image.open(hair / "native-hair-visible-mask.png") as opened:
        hair_visible = np.asarray(opened.convert("L")) != 0
    result.update({
        "hair-opaque": hair_visible & (owner == 0),
        "hair-outline": owner == 1138,
        "hair-front-blend": owner == 1291,
        "hair-back-blend": owner == 1314,
        "hair-complete": hair_visible | np.isin(owner, [1138, 1291, 1314]),
    })
    return result

def capture(device):
    run_state = json.loads(Path("D:/Projects/FYP-coordination/resources/current.json").read_text())
    assert run_state["state"] == "held" and Path(run_state["output"]) == run
    build = run.parent / "20261110-030251-hair-main-chroma-public-9e799c/release"
    runpy.run_path(str(run / "verify-release-catalog.py"))["verify"](run, build)
    player = build / "AzurePlayer.exe"
    candidate_sha = json.loads((run / "release-verification.json").read_text())["playerSha256"]
    assert sha(player) == candidate_sha
    env = os.environ.copy()
    for key in ("VK_DRIVER_FILES", "VK_ICD_FILENAMES", "VK_LAYER_ENABLES"):
        env.pop(key, None)
    selector = "*nv-vk64*" if device == "nvidia" else "*igvk64*"
    env.update(VK_INSTANCE_LAYERS="VK_LAYER_KHRONOS_validation", VK_LAYER_VALIDATE_SYNC="1",
               VK_LOADER_DRIVERS_SELECT=selector)
    frames = run / f"static-{device}-frames"
    command = json.loads((background / "command.json").read_text())
    command[0] = str(player)
    command[command.index("--capture-dir") + 1] = str(frames)
    command.extend(("--resource-root", str(build)))
    project = Path(command[command.index("--project") + 1])
    files = {str(path.relative_to(project.parent)): sha(path) for path in project.parent.rglob("*")
             if path.is_file() and ".azure" not in path.relative_to(project.parent).parts}
    (run / f"static-{device}-inputs.json").write_text(json.dumps(files, indent=2) + "\n")
    (run / f"static-{device}-command.json").write_text(json.dumps(command, indent=2) + "\n")
    log_path = run / f"static-{device}.log"
    with log_path.open("wb") as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=300)
    log = log_path.read_text(errors="replace")
    assert result.returncode == 0 and "Allocator after unload: buffers=0 images=0" in log, log[-4000:]
    assert not re.search(r"VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]", log, re.I), log[-4000:]
    capabilities = json.loads((frames / "gpu_capabilities.json").read_text())
    assert capabilities["vendor_id"] == (0x10de if device == "nvidia" else 0x8086)
    assert sha(player) == candidate_sha and all(sha(project.parent / name) == value for name, value in files.items())
    return frames / "frame_000000.png"

def main():
    reference = image(reference_path)
    regions = masks()
    control_path = background / "frames/frame_000000.png"
    control = compare(reference, image(control_path), regions)
    historic = json.loads((stages / "snapshot-shell-cloth-comparison.json").read_text())
    assert sha(control_path) == historic["candidateSha256"]
    for row in historic["cases"]:
        actual = control[f"cloth-{row['event']}"]
        assert actual["pixels"] == row["qualifiedPixels"]
        assert abs(actual["ssim"] - row["ssim"]) < 1e-9
        assert abs(actual["medianLuminanceRelativeError"] - row["medianLuminanceRelativeError"]) < 1e-9
    devices = sys.argv[1:]
    assert all(device in ("nvidia", "intel") for device in devices)
    report = dict(referenceSha256=sha(reference_path), control=control, devices={},
                  thresholds=dict(ssim=.95, medianLuminanceRelativeError=.1))
    for device in devices:
        frame = capture(device)
        report["devices"][device] = dict(frameSha256=sha(frame), regions=compare(reference, image(frame), regions))
        (run / "static-quality-results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
