from hashlib import file_digest
from pathlib import Path
import json
import os

def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()

def verify(run, build, *, restore_known_control=False):
    receipt = json.loads((run / "release-verification.json").read_text())
    assert digest(build / "AzurePlayer.exe") == receipt["playerSha256"]
    expected = json.loads((run / "release-base-catalog.json").read_text())
    expected.update({name: row["after"] for name, row in receipt["changedShaders"].items()})
    shader_dir = build / "shaders"
    actual = {path.name: digest(path) for path in shader_dir.glob("*.spv")}
    if actual == expected:
        return
    assert restore_known_control, "Release shader catalog differs from the verified candidate"
    control = run / "half-layer-control"
    journal = json.loads((control / "replacement-journal.json").read_text())
    assert journal["original"] == expected and journal["active"].keys() == expected.keys() == actual.keys()
    assert all(actual[name] in (expected[name], journal["active"][name]) for name in expected)
    for name in expected:
        if actual[name] == expected[name]:
            continue
        source = control / "original" / name
        target = shader_dir / name
        assert Path(name).name == name and digest(source) == expected[name]
        assert not target.is_symlink() and target.resolve().parent == shader_dir.resolve()
        temporary = target.with_suffix(target.suffix + ".nr-quality-recovery")
        with temporary.open("xb") as stream:
            stream.write(source.read_bytes())
        try:
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)
        assert digest(target) == expected[name]
    assert {path.name: digest(path) for path in shader_dir.glob("*.spv")} == expected
    (control / "recovery.json").write_text(json.dumps(dict(shaderCount=len(expected), allExact=True)) + "\n")