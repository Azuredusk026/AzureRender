from hashlib import file_digest
from pathlib import Path
import gzip
import json
import os
import shutil
import subprocess
import sys

run = Path(__file__).resolve().parent
build = run.parents[1]
debug_run = build/"runs/20261110-031856-hair-main-chroma-debug-668bf2"
debug = debug_run/"debug"
sys.path.insert(0, str(build.parent/"tools"))
from artifact_maintenance import measure

def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()

owner = json.loads(Path("D:/Projects/FYP-coordination/resources/current.json").read_text())
assert owner["state"]=="held" and Path(owner["output"])==run
receipt = json.loads((run/"debug-build-execution.json").read_text())
assert receipt["status"]=="budget-stopped" and receipt["reason"]=="Task byte/file-count budget exceeded"
ninja = "D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja/ninja.exe"
commands = json.loads((run/"debug-build-commands.json").read_text())
targets = [target for command in commands for target in command[command.index("--target")+1:command.index("--parallel")]]
def dry_run():
    plan = subprocess.check_output([ninja,"-C",str(debug),"-n",*targets],text=True)
    assert "[1/1]" in plan and "generate_script_bindings.py --check" in plan and "Linking" not in plan, plan
    return plan
plan = dry_run()
assert "Linking CXX executable AzurePlayer.exe" in (run/"debug-build.log").read_text()
assert digest(debug/"AzurePlayer.exe")!=json.loads((run/"debug-baseline-player.json").read_text())["sha256"]
raw = debug/"AzurePlayer.pdb"
archive = run/"build-symbols/AzurePlayer.pdb.gz"
assert raw.resolve(strict=True).parent == debug.resolve() and raw.stat().st_nlink == 1 and not raw.is_symlink()
assert archive.resolve(strict=True).parent == (run/"build-symbols").resolve() and not archive.is_symlink()
truncated = archive.with_suffix(".gz.interrupted")
assert not truncated.exists()
try:
    with gzip.open(archive,"rb") as file:
        file_digest(file,"sha256")
except EOFError:
    os.replace(archive,truncated)
else:
    raise AssertionError("Expected interrupted archive")
size = raw.stat().st_size
fingerprint = digest(raw)
temporary = archive.with_suffix(".gz.recovery")
with raw.open("rb") as source, gzip.open(temporary,"xb",compresslevel=3) as output:
    shutil.copyfileobj(source,output,1024**2)
with gzip.open(temporary,"rb") as file:
    assert file_digest(file,"sha256").hexdigest()==fingerprint
os.replace(temporary,archive)
assert digest(raw)==fingerprint
raw.unlink()
assert measure(debug_run)<2*1024**3 and dry_run()==plan
(run/"debug-symbols.json").write_text(json.dumps(dict(status="recovered",dryRun=plan, playerSha256=digest(debug/"AzurePlayer.exe"),
    interruptedArchiveSha256=digest(truncated), bytes=size, sha256=fingerprint, archiveSha256=digest(archive)),indent=2)+"\n")
subprocess.run([sys.executable,"-B",str(run/"verify-build.py"),"Debug"],check=True,timeout=360)
subprocess.run([sys.executable,"-B",str(run/"dispatch-capture.py"),"debug-capture"],check=True,timeout=1500)