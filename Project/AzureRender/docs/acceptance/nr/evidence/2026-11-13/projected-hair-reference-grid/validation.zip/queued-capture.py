from pathlib import Path
import json
import os
import subprocess
import sys
import time


out=Path(__file__).resolve().parent
build=out.parents[1]
sys.path.insert(0,'D:/Projects/FYP/Project/AzureRender/tools')
import shared_resources as shared


def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')


def managed(label,script,*args,timeout):
    path=out/(label+'-execution.json')
    if path.is_file():
        previous=json.loads(path.read_text())
        assert previous['status']=='exited' and previous['exitCode']==0,previous
        return
    command=[sys.executable,'-B',str(out/script),*args]
    result=shared.maintenance.guarded_run(build,out.name,command,timeout)
    write(path,result)
    print(json.dumps(result),flush=True)
    assert result['status']=='exited' and result['exitCode']==0,result


def capture(config,device,*,indexed=False):
    label=config.lower()+'-'+device+('-indexed' if indexed else '')
    os.environ['VK_LOADER_DRIVERS_SELECT']='*igvk64*' if device=='intel' else '*nv-vk64*'
    if not indexed:
        managed(label+'-gpu-tests','verify-build.py',config,device,timeout=390)
    if not (out/(label+'-frames')/'reference-planes.json').is_file():
        managed(label+'-capture','capture.py',config,device,*(['indexed'] if indexed else []),timeout=390)
        subprocess.run([sys.executable,'-B',str(out/'compact-capture.py'),label+'-frames'],check=True)


batch,predecessor,receipt_path=sys.argv[1:]
assert batch in ('release-capture','debug-capture','original-four')
deadline=time.monotonic()+1800
while time.monotonic()<deadline:
    try:
        state=json.loads((shared.DEFAULT_QUEUE/'current.json').read_text())
        receipt=json.loads(Path(receipt_path).read_text())
    except (OSError,ValueError):
        time.sleep(1)
        continue
    assert state['token']==receipt['token']==predecessor
    if state['state']==receipt['state']=='released':
        break
    time.sleep(1)
else:
    raise TimeoutError('The agreed projected hair raster grid capture window has not opened')
write(out/(batch+'-predecessor.json'),receipt)
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_LAYER_ENABLES','VK_LOADER_DRIVERS_SELECT'):
    os.environ.pop(key,None)
os.environ.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
lease=None
try:
    with shared.lease(shared.DEFAULT_QUEUE,'01a1c099-8121-7be3-b0b8-7af2f9a06b2a',
        'quality-projected-hair-reference-grid-'+batch,out) as lease:
        write(out/(batch+'-lease-held.json'),lease)
        if batch=='original-four':
            os.environ['VK_LOADER_DRIVERS_SELECT']='*nv-vk64*'
            managed(batch,'default-four.py',timeout=650)
        else:
            config=batch.split('-')[0].title()
            parent=('20261110-030251-hair-main-chroma-public-9e799c' if config=='Release'
                else '20261110-031856-hair-main-chroma-debug-668bf2')
            shared.maintenance.resume(build,parent)
            for device in ('nvidia','intel'):
                capture(config,device)
            if config=='Release':
                capture(config,'nvidia',indexed=True)
finally:
    if lease is not None:
        write(out/(batch+'-lease-released.json'),lease)

