from pathlib import Path
import json
import os
import runpy
import subprocess
import sys

run = Path(__file__).resolve().parent
build = run.parents[1]
debug_run = "20261110-031856-hair-main-chroma-debug-668bf2"
sys.path.insert(0, str(build.parent / "tools"))
import artifact_maintenance

state = json.loads(Path("D:/Projects/FYP-coordination/resources/current.json").read_text())
assert state["state"] == "held" and Path(state["output"]) == run
assert state["owner"] == os.environ["CODEX_THREAD_ID"]
artifact_maintenance.resume(build, debug_run)

# The predecessor script verifies the original executable and Ninja relink plan.
prepare = run / "prepare-debug-budget.py"
code = prepare.read_text()
old_check = "queue['owner'] == '01a1c099-8121-7be3-b0b8-7af2f9a06b2a'"
assert code.count(old_check) == 1
code = code.replace(old_check, "queue['owner'] == current_owner")
exec(compile(code, str(prepare), "exec"), {"__file__": str(prepare), "current_owner": state["owner"]})

result = artifact_maintenance.guarded_run(
    build, debug_run, [sys.executable, "-B", str(run / "build.py"), "Debug"], 1200
)
(run / "debug-build-execution.json").write_text(json.dumps(result, indent=2) + "\n")
assert result["status"] == "exited" and result["exitCode"] == 0, result
subprocess.run([sys.executable, "-B", str(run / "verify-build.py"), "Debug"], check=True, timeout=360)
subprocess.run([sys.executable, "-B", str(run / "dispatch-capture.py"), "debug-capture"], check=True, timeout=1820)