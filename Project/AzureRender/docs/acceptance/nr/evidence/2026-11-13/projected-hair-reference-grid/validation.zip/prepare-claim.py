from pathlib import Path

out=Path(__file__).resolve().parent
previous=out.parent/'20261112-230338-reference-raster-isolated-c086fb'
source=(previous/'claim-inputs.py').read_text()


def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)


replace("claim['state']=='reference-raster-source'","claim['state']=='reference-raster-isolated'")
replace("parent==claim['lastCommit']=='48847a4caa9031d7ccc70e90c093c9fab81984a3'",
    "parent==claim['lastCommit']=='eb05be0008bbbc7fc737b925eec079d10b2d6f6b'")
replace("source=='eb05be0008bbbc7fc737b925eec079d10b2d6f6b'","source=='1cceff89e7f7ac40c5e2085045063470c2306083'")
replace("evidence/2026-11-12/reference-raster-source'","evidence/2026-11-12/reference-raster-isolated'")
replace("results['status']=='qualified-independent-raster-sources'","results['status']=='qualified-isolated-raster-and-receiver-sources'")
replace("previous.name=='20261112-213454-reference-raster-source-a825da'",
    "previous.name=='20261112-230338-reference-raster-isolated-c086fb'")
replace("claim.update(state='reference-raster-isolated',","claim.update(state='projected-hair-reference-grid',")
replace("pendingCommand='Verify isolated raster quantization and identify native receiver geometry and source ownership',",
    "pendingCommand='Implement and validate the opt-in projected hair reference raster grid on both configurations and devices',")
replace("ownedFiles=['docs/acceptance/nr/reference-raster-isolated.md','docs/acceptance/nr/evidence/2026-11-12/reference-raster-isolated'])",
    """ownedFiles=['src/assets/GltfLoader.cpp','src/assets/GltfLoader.hpp','src/assets/MaterialData.cpp',
        'src/assets/MaterialSurfaceProfile.hpp','shaders/mesh.vert','schemas/azure_render_material.schema.json',
        'tests/CharacterRepairTests.cpp','docs/runtime/projected-hair-lighting.md','README.md','CHANGELOG.md',
        'docs/plans/2026-11-09-native-quality.md','docs/plans/azure-engine-plan.md',
        'docs/acceptance/nr/projected-hair-reference-grid.md','docs/acceptance/nr/evidence/2026-11-12/projected-hair-reference-grid'])""")
replace("claim['observed'].update(gridIntelRgb=31,gridIntelOutsideFrozenOverOne=6121,bodySampledRgNvidia=45,bodySampledRgIntel=77)",
    "claim['observed'].update(isolatedGridIntelRgb=31,isolatedGridIntelOutsideFrozenOverOne=0,bodyFocusNativeAtlasValue=27)")
replace("sourceBase=source,plannedBytes=134217728","sourceBase=source,plannedBytes=100663296")
replace("change='Function-local precision for the hair viewport grid; native receiver post-vertex and independent attachment substitution'",
    "change='Opt-in reference camera subpixel position for projected opaque hair with function-local precision'")
replace("gate='Stable two-device reference attachments, whole-frame RGB comparisons, and full receiver attachment identity for replay qualification'",
    "gate='Exact equality to the qualified isolated raster control, default four frames and scoped dual-configuration dual-device regression'")
(out/'claim-inputs.py').write_text(source,encoding='utf-8')

