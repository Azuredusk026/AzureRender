from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys


out = Path(__file__).resolve().parent
root = out.parents[2]
sys.path.insert(0, str(root / 'tools'))
from artifact_maintenance import measure


def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


cap = json.loads((out / 'task-card.json').read_text())['plannedBytes']
used = measure(out)
assert used + 25_000_000 <= cap, (used, cap)
build = out.parent / '20261110-030251-hair-main-chroma-public-9e799c/release'
frames = out / 'default-four-frames'
project = Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c/qualified-lit-surfaces-joint-v4/joint-materials.azureproject')
player = build / 'AzurePlayer.exe'
player_sha = digest(player)
project_sha = digest(project)
assert player_sha == json.loads((out / 'release-verification.json').read_text())['playerSha256']
command = [str(player), '--project', str(project), '--width', '2560', '--height', '1440', '--qa-camera', 'scene',
    '--qa-light', 'scene', '--capture-frames', '4', '--capture-fps', '24', '--fixed-frame-step', '--capture-dir', str(frames),
    '--runtime-report', str(out / 'default-runtime.json'), '--resource-root', str(build)]
(out / 'default-four-command.json').write_text(json.dumps(command, indent=2) + '\n')
with (out / 'default-four.log').open('wb') as log:
    process = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=500)
diagnostics = (out / 'default-four.log').read_text(errors='replace')
assert process.returncode == 0 and not re.search(r'VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]', diagnostics), diagnostics[-5000:]
assert 'Allocator after unload: buffers=0 images=0' in diagnostics
assert digest(player) == player_sha and digest(project) == project_sha
expected = ['4faf27a0d379b247e9a0a98d77dd8a8c2622ad689dc914428ca8df7944b79387',
    '55678cd9b32fb282416bb975ead40e01c7a66042b93d8a4ff6f75da29dc3a2ab',
    'ecee0ff56e78afd0447c1704224b1aabcb16f73bac624d0ce69e27a1e4f33d79',
    '1eb14b1cce256811991cb04971dd86d7bb2eda455d127e0e4667c258921a6574']
rows = []
for index, frozen in enumerate(expected):
    path = frames / f'frame_{index:06d}.png'
    actual = digest(path)
    rows.append(dict(frame=path.name, sha256=actual, expectedSha256=frozen, pngExact=actual == frozen))
manifest = json.loads((frames / 'capture_manifest.json').read_text())
depth_absent = 'referenceSceneDepth' not in manifest and not list(frames.glob('reference-depth-*.bin'))
used_after = measure(out)
report = dict(exitCode=process.returncode, frames=rows, validationClean=True, allocatorZero=True, depthCaptureAbsent=depth_absent,
    allExact=all(row['pngExact'] for row in rows), playerSha256=player_sha, projectSha256=project_sha,
    taskBytes=used_after, taskBudgetBytes=cap)
(out / 'default-four-results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
assert report['allExact'] and depth_absent and used_after <= cap

