from hashlib import sha256
from pathlib import Path
import json
import re
import subprocess

run=Path(__file__).resolve().parent
engine=run.parents[2]
build=run.parent/'20261110-030251-hair-main-chroma-public-9e799c/release'
sdk=Path('D:/Tools/VulkanSDK/1.4.350.0/Bin')
programs=json.loads((build/'shader-reload.json').read_text())['programs']
source=engine/'shaders/mesh.vert'
out=run/'shader-preflight'
out.mkdir()
baseline={p.name:sha256(p.read_bytes()).hexdigest() for p in (build/'shaders').glob('*.spv')}
assert len(baseline)==895
(run/'release-base-catalog.json').write_text(json.dumps(baseline,indent=2)+'\n')
debug=run.parent/'20261110-031856-hair-main-chroma-debug-668bf2/debug'
debug_catalog={p.name:sha256(p.read_bytes()).hexdigest() for p in (debug/'shaders').glob('*.spv')}
assert debug_catalog==baseline
(run/'debug-base-catalog.json').write_text(json.dumps(debug_catalog,indent=2)+'\n')


def decoration_map(path):
    text=subprocess.check_output([str(sdk/'spirv-dis.exe'),str(path)],text=True)
    precise=set(re.findall(r'OpDecorate\s+(%\S+)\s+NoContraction',text))
    functions={}
    active=None
    for line in text.splitlines():
        line=line.strip()
        definition=re.match(r'(%\S+)\s*=\s*(Op\S+)(.*)',line)
        if definition and definition[2]=='OpFunction':
            active=definition[1]
            functions[active]=[]
        elif line=='OpFunctionEnd':
            active=None
        elif active and definition and definition[1] in precise:
            functions[active].append(definition[2])
    return functions


report={}
for row in programs:
    if row['source']!='mesh.vert':
        continue
    name=row['output']
    path=out/name
    command=[str(sdk/'glslc.exe'),*row['arguments'],*('-D'+define for define in row['defines']),str(source),'-o',str(path)]
    subprocess.run(command,check=True)
    subprocess.run([str(sdk/'spirv-val.exe'),'--target-env','vulkan1.3','--relax-block-layout',str(path)],check=True)
    digest=sha256(path.read_bytes()).hexdigest()
    defines={item.split('=')[0] for item in row['defines']}
    allowed='AZURE_REFERENCE_CAMERA' in defines and not (defines&{'AZURE_SNAPSHOT_DEPTH','AZURE_OUTLINE_MASK'})
    assert (digest!=baseline[name])==allowed,(name,digest,allowed)
    local=[]
    if allowed:
        old=decoration_map(build/'shaders'/name)
        new=decoration_map(path)
        helper,=set(new)-set(old)
        assert helper=='%azureQuantizedHairRasterXY_vf4_vf2_'
        assert all(new[name]==old[name] for name in old)
        local=new[helper]
        assert len(local)==8
    report[name]=dict(before=baseline[name],after=digest,changes=allowed,localDecorations=local,command=command)
assert any('compute_reference_camera' in name and row['changes'] for name,row in report.items())
assert all(not report[name]['changes'] for name in (
    'character_snapshot_depth_visibility_reference_camera.vert.spv',
    'character_snapshot_depth_visibility_compute_reference_camera.vert.spv'))
(run/'shader-preflight.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(vertexPrograms=len(report),changed=[name for name,row in report.items() if row['changes']])))

