from hashlib import sha256
from pathlib import Path
import json
import zipfile

import numpy as np


run=Path(__file__).resolve().parent
engine=run.parents[2]
evidence=engine/'docs/acceptance/nr/evidence/2026-11-13/projected-hair-reference-grid'
configs=('release','debug')
devices=('nvidia','intel')
labels=tuple(config+'-'+device for config in configs for device in devices)+('release-nvidia-indexed',)


def load(path):
    return json.loads(path.read_text())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


assert 'Unknown projectedRamp field: referenceRasterGrid' in (run/'red-ctest.log').read_text(errors='replace')
assert '1 tests failed out of 1' in (run/'red-ctest.log').read_text(errors='replace')
preflight=load(run/'shader-preflight.json')
assert len(preflight)==42
changes={name:dict(before=row['before'],after=row['after']) for name,row in preflight.items() if row['changes']}
assert len(changes)==12 and all(len(preflight[name]['localDecorations'])==8 for name in changes)
builds={config:load(run/(config+'-verification.json')) for config in configs}
assert all(row['shaderCount']==895 and row['changedShaders']==changes for row in builds.values())
assert [builds[name]['tests'] for name in configs]==[11,10]
cases={label:load(run/(label+'-results.json')) for label in labels}
for label,case in cases.items():
    assert case['validationClean'] and case['allocatorZero']
    assert len(case['attachments'])==5 and all(row['exact'] for row in case['attachments'].values())
    assert case['descriptorIndexing']==label.endswith('-indexed')
    assert case['playerSha256']==builds[case['configuration'].lower()]['playerSha256']
    assert len(case['colors'])==3 and all(row['exactDiagnosticPng'] and row['sha256']==row['expectedSha256']
        and row['overOne']==(0 if case['device']=='nvidia' else 31) for row in case['colors'])
    raw=np.fromfile(run/(label+'-selected-rgb.bin'),'<u2').reshape(17017,8).astype('i4')
    errors=np.abs(raw[:,2:5]-raw[:,5:8]).max(axis=1)
    assert int((errors>1).sum())==case['colors'][0]['overOne']
    assert int(errors.max())==case['colors'][0]['maximum']
    if not case['descriptorIndexing']:
        assert load(run/(label+'-gpu-verification.json'))['tests']==6
for device in devices:
    release,debug=(cases[config+'-'+device] for config in configs)
    assert release['attachments']==debug['attachments'] and release['colors']==debug['colors']
    a,b=(run/f'{config}-{device}-frames' for config in configs)
    with zipfile.ZipFile(a/'reference-planes.zip') as first,zipfile.ZipFile(b/'reference-planes.zip') as second:
        assert first.namelist()==second.namelist() and all(first.read(name)==second.read(name) for name in first.namelist())
    for index in range(3):
        name=f'frame_{index:06d}.png'
        assert (a/name).read_bytes()==(b/name).read_bytes()
assert cases['release-nvidia-indexed']['attachments']==cases['release-nvidia']['attachments']
assert cases['release-nvidia-indexed']['colors']==cases['release-nvidia']['colors']
default=load(run/'default-four-results.json')
assert default['allExact'] and default['validationClean'] and default['allocatorZero'] and default['depthCaptureAbsent']
assert len(default['frames'])==4 and default['playerSha256']==builds['release']['playerSha256']
fixture=load(run/'fixture-inputs.json')
assert len(fixture['files'])==45 and len(fixture['changed'])==1
assert fixture['changed'][0]['candidateSha256']=='19e20c3cd9007c97260d1dd0580774e86e7167f368c240f6f16d69998fd9c3ea'
leases={}
released=load(run/'release-build-lease-released.json')
assert released['state']=='released'
assert released['token']==load(run/'release-build-lease-held.json')['token']
leases['release-build']=released
for label in ('release','debug','frozen-four','static-regions'):
    result=load(run/f'dispatch-{label}-result.json')
    assert result['task']==f'quality-reference-grid-{label}'
    assert Path(result['output'])==run
    assert result['exit_code']==0 and result['ended']>=result['started']
    if label=='debug':
        assert result['state']=='budget-stopped' and result['reason']=='managed-pool-limit'
        assert load(run/'debug-intel-managed-receipt.json')['exitCode']==0
    else:
        assert result['state']=='succeeded'
    leases[label]=result
source_provenance=load(run/'source-provenance.json')
for path,fingerprint in source_provenance['candidatePaths'].items():
    assert digest(engine/path)==fingerprint
static_quality=load(run/'static-quality-results.json')
assert set(static_quality['devices'])=={'nvidia','intel'}
hair_quality=load(run/'hair-static-results.json')
assert all(hair_quality['cases'][label]['rgbOverOne']==case['colors'][0]['overOne']
    for label,case in cases.items())
executions={}
for path in sorted(run.glob('*-execution.json')):
    if path.name.startswith('first-'):
        continue
    value=load(path)
    if path.name=='debug-build-execution.json':
        assert value['status']=='budget-stopped' and load(run/'debug-symbols.json')['status']=='recovered'
    else:
        assert value['status']=='exited' and value['exitCode']==0
    executions[path.stem]=value
evidence.mkdir(parents=True,exist_ok=False)
archive=evidence/'validation.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(run.iterdir()):
        if path.is_file() and not path.name.startswith('next-') and path.suffix in ('.py','.json','.log','.xml','.bin','.patch'):
            z.write(path,path.name)
    for name in ('eye-bloom-control/results.json','native-face-masks/result.json',
                 'native-face-masks/iris.png','native-face-masks/face.png','native-face-masks/skin.png',
                 'half-layer-control/intel-results.json','half-layer-control/restoration.json'):
        z.write(run/name,name)
    for label in labels:
        folder=run/(label+'-frames')
        for name in ('capture_manifest.json','reference-planes.json','gpu_capabilities.json'):
            path=folder/name
            z.write(path,path.relative_to(run).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    count=len(z.namelist())
assert archive.stat().st_size<8*1024**2
summary=dict(status='qualified-projected-hair-reference-grid',overallStatus='failed-user-review',
    source=load(run/'task-card.json'),builds=builds,fixtures=fixture['changed'],cases=cases,originalFour=default,
    leases=leases,executions=executions,sourceProvenance=source_provenance,
    staticQuality=static_quality,hairQuality=hair_quality,
    portrait=load(run/'portrait-results.json'), portraitPixels=load(run/'portrait-pixel-results.json'),
    faceAndSkin=load(run/'face-and-skin-results.json'), eyeBloomControl=load(run/'eye-bloom-control/results.json'),
    integrationPreflight=load(run/'integration-preflight.json'),
    archive=dict(sha256=digest(archive),bytes=archive.stat().st_size,members=count))
(evidence/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))

