from pathlib import Path
import json
import runpy

import numpy as np

run=Path(__file__).resolve().parent
scope=runpy.run_path(str(run/"static-quality.py"))
main=Path("D:/Projects/FYP/Project/AzureRender")
source=main/"build/runs/20261101-043757-material-display-transform-93d6e0/native-final-comparison.json"
baseline=json.loads(source.read_bytes())["comparisons"][1]
result=json.loads((run/"portrait-results.json").read_bytes())
reference_path=Path(baseline["reference"])
assert scope["sha"](reference_path)==result["referenceSha256"]==baseline["referenceSha256"]
reference=scope["image"](reference_path)
report=dict(referenceSha256=result["referenceSha256"],thresholdByte=1,cases={})
for device,case in result["cases"].items():
    frame=run/f"portrait-{device}-frames/frame_000000.png"
    assert scope["sha"](frame)==case["frameSha256"]
    image=scope["image"](frame)
    regions={}
    for name in ("eye-left","face-cheek","face-chin"):
        x0,y0,x1,y1=case["regions"][name]["bounds"]
        a=image[y0:y1,x0:x1]
        b=reference[y0:y1,x0:x1]
        delta=np.abs(a.astype(np.int16)-b.astype(np.int16)).max(axis=2)
        y,x=np.unravel_index(int(delta.argmax()),delta.shape)
        regions[name]=dict(pixels=delta.size,overOne=int((delta>1).sum()),maxByte=int(delta.max()),
            interiorOverOne=int((delta[5:-5,5:-5]>1).sum()),
            p95Byte=float(np.quantile(delta,.95)),worstPixel=[int(x+x0),int(y+y0)],
            worstCandidate=a[y,x].tolist(),worstReference=b[y,x].tolist())
    report["cases"][device]=dict(frameSha256=case["frameSha256"],regions=regions)
(run/"portrait-pixel-results.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report["cases"]))