from hashlib import file_digest
from pathlib import Path
import json
import os
import subprocess
import sys

run = Path(__file__).resolve().parent
main = Path("D:/Projects/FYP/Project/AzureRender")
native = main/"build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc"
with native.open("rb") as source:
    capture_hash = file_digest(source, "sha256").hexdigest()
assert capture_hash == "fa2ca267f7168f5603e83ad5f817a3074d8dbee23a216e6ab8ef2c340ec06a90"
worker = run/"restore-native-face-masks-worker.py"
output = run/"native-face-masks"
output.mkdir(exist_ok=True)
assert all(not (output/name).exists() for name in ("result.json", "iris.png", "skin.png", "face.png"))
env = os.environ.copy()
env["AZURE_NATIVE_FACE_MASK_REQUEST"] = str(output/"request.json")
request = dict(native=str(native), output=str(output), captureSha256=capture_hash)
(output/"request.json").write_text(json.dumps(request))
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
with (output/"process.log").open("wb") as log:
    result = subprocess.run(["D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe","--python",str(worker)],
        cwd=output,env=env,stdout=log,stderr=subprocess.STDOUT,startupinfo=startup,timeout=180)
receipt = json.loads((output/"result.json").read_text())
assert result.returncode == 0 and receipt["status"]=="qualified", receipt
print(json.dumps(receipt))