from hashlib import file_digest
from pathlib import Path
import json
import os
import re
import runpy
import shutil
import subprocess
import sys
import zipfile

import numpy as np
from PIL import Image

run = Path(__file__).resolve().parent
engine = run.parents[2]
out = run / "half-layer-control"
build = run.parent / "20261110-030251-hair-main-chroma-public-9e799c/release"
shader_dir = build / "shaders"
tools = Path("D:/Tools/VulkanSDK/1.4.350.0/Bin")
sys.path.insert(0, str(engine / "tools"))
from artifact_budget import check

def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()

def load(path):
    return json.loads(path.read_text())

def write(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n")

def catalog():
    return {path.name: digest(path) for path in shader_dir.glob("*.spv")}

def compile_control():
    out.mkdir(exist_ok=False)
    source = engine / "shaders/mesh.frag"
    original = source.read_text()
    old = "return mix(explicitSample,implicitSample,bvec4(atBoundary));"
    assert original.count(old) == 1
    probe = out / source.name
    probe.write_text(original.replace(old, "return explicitSample;"), encoding="utf-8")
    reference = run.parent / "20261112-175619-reference-hair-color-triple-d2d080/triple/shader-probe/compiled.json"
    names = set(load(reference)["programs"])
    rules = load(build / "shader-reload.json")["programs"]
    programs = {}
    for rule in rules:
        name = rule["output"]
        if name not in names:
            continue
        target = out / name
        args = [str(tools/"glslc.exe"), *rule["arguments"], *("-D"+flag for flag in rule["defines"]),
                "-I"+str(source.parent), str(probe), "-o", str(target)]
        subprocess.run(args, check=True, timeout=60)
        subprocess.run([str(tools/"spirv-val.exe"), "--target-env", "vulkan1.3", "--relax-block-layout",
                        str(target)], check=True, timeout=60)
        programs[name] = dict(original=digest(shader_dir/name), candidate=digest(target), command=args)
        assert programs[name]["original"] != programs[name]["candidate"]
    assert set(programs) == names
    write(out/"compile.json", dict(originalSourceSha256=digest(source), probeSourceSha256=digest(probe), programs=programs))
    print(f"validated {len(programs)} probe programs")

def capture(device):
    output = out / f"{device}-frames"
    case = f"release-{device}"
    argv = load(run/f"{case}-command.json")
    argv[argv.index("--capture-dir")+1] = str(output)
    write(out/f"{device}-command.json", argv)
    environment = os.environ.copy()
    for variable in ("VK_DRIVER_FILES","VK_ICD_FILENAMES","VK_LAYER_ENABLES"):
        environment.pop(variable, None)
    environment.update(VK_INSTANCE_LAYERS="VK_LAYER_KHRONOS_validation", VK_LAYER_VALIDATE_SYNC="1",
                       VK_LOADER_DRIVERS_SELECT="*igvk64*" if device=="intel" else "*nv-vk64*")
    log_path = out / f"{device}.log"
    with log_path.open("wb") as log:
        process = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, env=environment, timeout=300)
    log = log_path.read_text(errors="replace")
    assert process.returncode == 0 and "Allocator after unload: buffers=0 images=0" in log, log[-5000:]
    assert not re.search(r"VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]",log,re.I), log[-5000:]
    capabilities = load(output/"gpu_capabilities.json")
    assert capabilities["vendor_id"] == (0x8086 if device == "intel" else 0x10de)
    manifest = load(output/"capture_manifest.json")["referenceSceneDepth"]
    expected = load(run/f"{case}-results.json")
    for name,row in expected["attachments"].items():
        assert digest(output/manifest[name]) == row["sha256"], name
    frozen = runpy.run_path(str(run.parent/"20261110-112309-hair-relative-projection-control-b9da17/baseline.py"))
    x0,y0,x1,y1 = (frozen[key] for key in ("x0","y0","x1","y1"))
    mask = frozen["mask"]
    results = []
    for index in range(3):
        name = f"frame_{index:06d}.png"
        with Image.open(run/f"{case}-frames"/name) as old, Image.open(output/name) as new:
            old = np.asarray(old.convert("RGB")).astype(np.int16)
            new = np.asarray(new.convert("RGB")).astype(np.int16)
        before = np.abs(old[y0:y1,x0:x1][mask]-frozen["expected"][mask]).max(axis=1)
        after = np.abs(new[y0:y1,x0:x1][mask]-frozen["expected"][mask]).max(axis=1)
        introduced = (after > 1) & (before <= 1)
        closed = (after <= 1) & (before > 1)
        outside = np.abs(new-old).max(axis=2) > 1
        outside[y0:y1,x0:x1][mask] = False
        points = np.argwhere(mask)
        results.append(dict(overOne=int((after>1).sum()), maximum=int(after.max()),
                            closed=int(closed.sum()), introduced=int(introduced.sum()),
                            outsideOverOne=int(outside.sum()), changed=int((new!=old).any(axis=2).sum()),
                            closedXY=(points[closed][:,::-1]+[x0,y0]).tolist(),
                            introducedXY=(points[introduced][:,::-1]+[x0,y0]).tolist(),
                            pngSha256=digest(output/name)))
    write(out/f"{device}-results.json", results)
    for name in set(manifest[key] for key in expected["attachments"]):
        plane = output/name
        assert plane.resolve().parent == output.resolve()
        plane.unlink()
    print(device, json.dumps(results[0]))
    return results

def run_control():
    owner = load(Path("D:/Projects/FYP-coordination/resources/current.json"))
    assert owner["state"] == "held" and Path(owner["output"]) == run
    plan = check(run.parents[1], run=run, planned=72*2**20)
    assert plan["allowed"], plan
    verified = load(run/"release-verification.json")
    player = build/"AzurePlayer.exe"
    assert digest(player) == verified["playerSha256"]
    expected = load(run/"release-base-catalog.json")
    expected.update({name: row["after"] for name,row in verified["changedShaders"].items()})
    assert len(expected)==895 and catalog()==expected
    compiled = load(out/"compile.json")
    assert digest(engine/"shaders/mesh.frag")==compiled["originalSourceSha256"]
    programs = compiled["programs"]
    backup = out/"original"
    backup.mkdir()
    active = expected.copy()
    for name, info in programs.items():
        assert Path(name).name==name and expected[name]==info["original"]
        assert digest(out/name)==info["candidate"]
        shutil.copyfile(shader_dir/name, backup/name)
        assert digest(backup/name)==expected[name]
        active[name]=info["candidate"]
    write(out/"replacement-journal.json", dict(original=expected, active=active, lease=owner["task"]))
    try:
        for name in programs:
            replace(out/name, shader_dir/name, active[name])
        assert catalog()==active
        results = capture("intel")
        if all(row["closed"] > 0 and row["introduced"] == 0 and row["outsideOverOne"] == 0 for row in results):
            capture("nvidia")
    finally:
        for name in programs:
            replace(backup/name, shader_dir/name, expected[name])
        assert catalog()==expected and digest(player)==verified["playerSha256"]
        write(out/"restoration.json", dict(shaderCount=len(expected), allExact=True))

def replace(source, target, fingerprint):
    assert source.is_file() and digest(source)==fingerprint
    assert not target.is_symlink() and target.resolve().parent==shader_dir.resolve()
    temporary = target.with_suffix(target.suffix+".nr-quality-tmp")
    with temporary.open("xb") as output:
        output.write(source.read_bytes())
    try:
        os.replace(temporary,target)
    finally:
        temporary.unlink(missing_ok=True)
    assert digest(target)==fingerprint

if sys.argv[1:] == ["compile"]:
    compile_control()
elif sys.argv[1:] == ["capture"]:
    run_control()
else:
    raise SystemExit("Specify compile or capture")