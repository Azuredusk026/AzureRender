from pathlib import Path
from hashlib import sha256
import json,numpy as np

run=Path(__file__).resolve().parent
root=run/'iris-explicit-mips'
manifest=json.loads((root/'iris-explicit-mips.json').read_bytes()); assert manifest['status']=='qualified'
points=np.fromfile(run/'native-iris-stages/points.bin','<u4').reshape(255,2)
prior=json.loads((run/'iris-base-native-pixel-history-comparison.json').read_bytes())
report={}
for device,meta in manifest['devices'].items():
 def load(name,digest):
  b=(root/f'{device}-{name}.bin').read_bytes();assert sha256(b).hexdigest()==digest and len(b)==1020
  return np.frombuffer(b,'<u4')
 implicit=load('implicit',meta['implicitSha256'])
 levels=np.stack([load(f'mip-{int(i):02d}',v['sha256']) for i,v in meta['mips'].items()])
 fit=levels==implicit[None]
 assert np.all(fit.any(0)) and meta['copyControlExact'] and meta['baselineRestored']
 categories={tuple(int(i) for i in np.flatnonzero(col)) for col in fit.T}
 counts={','.join(map(str,k)):sum(tuple(np.flatnonzero(c))==k for c in fit.T) for k in sorted(categories)}
 by_pos={tuple(xy):np.flatnonzero(fit[:,i]).tolist() for i,xy in enumerate(points)}
 residual=[]
 for point in prior[device]['uncovered']:
  location=(point['x'],point['y']);matches=by_pos[location]
  residual.append({**point,'matchingNativeLevels':matches})
 report[device]=dict(all=counts,residual=residual,allNativeCovered=len(implicit),
    uncoveredResidualCount=len(residual),uncoveredUniqueMip4=sum(row['matchingNativeLevels']==[4] for row in residual),
    uncoveredLastNativeDepthRejected=sum(row['lastDepthFailed'] for row in residual))
 print(device,counts,report[device]['uncoveredResidualCount'],report[device]['uncoveredUniqueMip4'])
assert [report[device]['uncoveredUniqueMip4'] for device in ('nvidia','intel')]==[35,38]
(run/'iris-explicit-mips-location-report.json').write_text(json.dumps(report,indent=2)+'\n')
