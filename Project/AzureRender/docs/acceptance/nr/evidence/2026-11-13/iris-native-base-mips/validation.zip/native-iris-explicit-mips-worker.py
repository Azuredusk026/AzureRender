from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import sys
import traceback

import renderdoc as rd


job=json.loads(Path(os.environ['AZURE_BODY_NORMAL_MIP_REQUEST']).read_text(encoding='utf-8'))
out=Path(job['output'])
sys.path.insert(0,job['utilities'])
from dxbc_util import checksum,chunks,fbits,imm,instructions,opcode,rebuild,words


def with_level(raw,level):
    assert checksum(raw)==raw[4:20]
    parts=chunks(raw)
    index=next(i for i,(kind,_) in enumerate(parts) if kind in (b'SHEX',b'SHDR'))
    body=words(parts[index][1])
    samples=[(at,n) for _,at,op,n in instructions(body) if op==opcode('SAMPLE_B')]
    assert len(samples)==2
    at,n=samples[0]
    original=body[at:at+n]
    assert original[-2:]==[1,26] and original[-6]==13,original
    substitute=original[:-3]+imm(fbits(level))
    substitute[0]=(substitute[0]&0x80fff800)|opcode('SAMPLE_L')|(len(substitute)<<24)
    body[at:at+n]=substitute
    body[1]=len(body)
    parts[index]=(parts[index][0],struct.pack('<'+'I'*len(body),*body))
    return rebuild(raw,parts)


def replay(label,vendor,device,capture,locations):
    gpu=[g for g in capture.GetAvailableGPUs() if g.vendor==vendor and g.deviceID==device and rd.GraphicsAPI.D3D11 in g.apis][0]
    options=rd.ReplayOptions()
    options.forceGPUVendor=vendor
    options.forceGPUDeviceID=device
    status,controller=capture.OpenCapture(options,None)
    assert status==rd.ResultCode.Succeeded and controller
    original=replacement=None
    try:
        properties=controller.GetAPIProperties()
        assert properties.vendor==vendor and properties.pipelineType==rd.GraphicsAPI.D3D11 and not properties.degraded
        controller.SetFrameEvent(846,True)
        pipeline=controller.GetPipelineState()
        reflection=pipeline.GetShaderReflection(rd.ShaderStage.Pixel)
        original=pipeline.GetShader(rd.ShaderStage.Pixel)
        raw=bytes(reflection.rawBytes)
        assert sha256(raw).hexdigest()==job['pixelShaderSha256']
        target=pipeline.GetOutputTargets()[0].resource
        assert str(target)=='ResourceId::141976'
        texture,=[slot.descriptor.resource for slot in pipeline.GetReadOnlyResources(rd.ShaderStage.Pixel)
            if reflection.readOnlyResources[slot.access.index].fixedBindNumber==13]
        description=next(item for item in controller.GetTextures() if item.resourceId==texture)
        assert description.mips>5

        def readback():
            controller.SetFrameEvent(846,True)
            data=bytes(controller.GetTextureData(target,rd.Subresource()))
            assert len(data)==2560*1440*4
            return data

        def select(data):
            return b''.join(data[offset:offset+4] for offset in locations)

        baseline=readback()
        selected=select(baseline)
        (out/f'{label}-implicit.bin').write_bytes(selected)
        record=dict(device=gpu.name,implicitSha256=sha256(selected).hexdigest(),attachmentSha256=sha256(baseline).hexdigest(),
            pixelShaderSha256=sha256(raw).hexdigest(),mips={})
        record["texture"]=dict(resource=str(texture),width=description.width,height=description.height,mips=description.mips)
        for level in (None,*range(description.mips)):
            code=raw if level is None else with_level(raw,level)
            replacement,errors=controller.BuildTargetShader('main',rd.ShaderEncoding.DXBC,code,rd.ShaderCompileFlags(),rd.ShaderStage.Pixel)
            assert replacement!=rd.ResourceId.Null(),errors
            controller.ReplaceResource(original,replacement)
            observed=readback()
            if level is None:
                assert observed==baseline
                record['copyControlExact']=True
            else:
                pixels=select(observed)
                (out/f'{label}-mip-{level:02d}.bin').write_bytes(pixels)
                record['mips'][level]=dict(sha256=sha256(pixels).hexdigest(),programSha256=sha256(code).hexdigest())
            controller.RemoveReplacement(original)
            controller.FreeTargetResource(replacement)
            replacement=None
        assert readback()==baseline
        record['baselineRestored']=True
        record['messages']=[str(message.description) for message in controller.GetDebugMessages()]
        return record
    finally:
        if original is not None and replacement is not None:
            controller.RemoveReplacement(original)
            controller.FreeTargetResource(replacement)
        controller.Shutdown()


capture=rd.OpenCaptureFile()
report=dict(status='failed',devices={})
try:
    assert capture.OpenFile(job['capture'],'',None)==rd.ResultCode.Succeeded
    locations=[((1439-y)*2560+x)*4 for x,y in struct.iter_unpack('<II',Path(job['points']).read_bytes())]
    assert len(locations)==255
    for label,vendor,device in (('nvidia',rd.GPUVendor.nVidia,0x28e0),('intel',rd.GPUVendor.Intel,0xa788)):
        report['devices'][label]=replay(label,vendor,device,capture,locations)
    report['status']='qualified'
except Exception:
    report['error']=traceback.format_exc()
finally:
    capture.Shutdown()
    (out/'iris-explicit-mips.json').write_text(json.dumps(report,indent=2)+'\n')
os._exit(0 if report['status']=='qualified' else 1)


