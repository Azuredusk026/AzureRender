from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import traceback

import renderdoc as rd

folder = Path(os.environ["AZURE_NR_OVERLAY_REPLAY"])
request = json.loads((folder / "request.json").read_bytes())
capture = rd.OpenCaptureFile()
controller = None
report = dict(status="failed")
try:
    assert capture.OpenFile(request["native"], "", None) == rd.ResultCode.Succeeded
    options = rd.ReplayOptions()
    options.forceGPUVendor = rd.GPUVendor.nVidia
    options.forceGPUDeviceID = 0x28e0
    status, controller = capture.OpenCapture(options, None)
    assert status == rd.ResultCode.Succeeded and controller
    properties = controller.GetAPIProperties()
    assert properties.vendor == rd.GPUVendor.nVidia and not properties.degraded
    controller.SetFrameEvent(846, True)
    pipeline=controller.GetPipelineState()
    stage=rd.ShaderStage.Pixel
    reflection=pipeline.GetShaderReflection(stage)
    target=pipeline.GetOutputTargets()[0].resource
    points=Path(request["irisLocations"]).read_bytes()
    selected=list(struct.iter_unpack("<II",points))
    report["shaderSamples"]=[]
    for x,y in selected:
        event_history=controller.PixelHistory(target,x,1439-y,rd.Subresource(),rd.CompType.Typeless)
        hits=[item for item in event_history if item.eventId==846]
        if not hits:
            continue
        row=hits[-1]
        report["shaderSamples"].append(dict(x=x,y=y,shaderOut=list(row.shaderOut.col.floatValue)[:4],
            post=list(row.postMod.col.floatValue)[:4],front=not row.backfaceCulled,
            depthFailed=row.depthTestFailed,stencilFailed=row.stencilTestFailed,
            primitive=row.primitiveID))
    assert len(report["shaderSamples"])==255
    report["status"] = "qualified"
except Exception:
    report["error"] = traceback.format_exc()
finally:
    if controller:
        controller.Shutdown()
    capture.Shutdown()
    (folder / "results.json").write_text(json.dumps(report, indent=2) + "\n")
os._exit(0 if report["status"] == "qualified" else 1)


