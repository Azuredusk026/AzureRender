from hashlib import file_digest
from pathlib import Path
import json
import os
import re
import runpy
import subprocess
import sys
import zipfile

import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
grid=run.parent/"20261112-231945-projected-hair-reference-grid-4b775d"
engine=run.parents[2]
build=run.parent/"20261110-030251-hair-main-chroma-public-9e799c/release"
shader_dir=build/"shaders"
fixture=grid/"hair-project"
tex=fixture/"character/native-captured-body/t15.dds"
original_sha="3d16ddcced1a4f482f969250b835c5ea569ce620d8ef16cc465fc19cbb266a9e"
prepared=grid/"next-body-normal-fractional-alpha.dds"
prepared_sha="7e57983966a786cf56fe0802c1eb417109f62df6673e3a4f678c7872d1a03c05"
compiled=grid/"next-body-fractional-shaders-verified"
sys.path.insert(0,str(engine/"tools"))
from artifact_budget import check

def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream,"sha256").hexdigest()

def load(path):
    return json.loads(path.read_text())

def write(path,data):
    path.write_text(json.dumps(data,indent=2)+"\n")

def replace(data,path,sha):
    assert path.is_file() and not path.is_symlink()
    temporary=path.with_suffix(path.suffix+".body-control-temp")
    with temporary.open("xb") as stream:
        stream.write(data)
    assert digest(temporary)==sha
    try:
        os.replace(temporary,path)
    finally:
        temporary.unlink(missing_ok=True)
    assert digest(path)==sha

def verify_budget():
    budget=check(run.parents[1],run=run,planned=56*2**20)
    assert budget["allowed"],budget

mode=sys.argv[1] if len(sys.argv)>1 else None
assert mode in ("measure","restore")
control=run/"production-body-control-retest"
control.mkdir(exist_ok=True)
fixed="reference_scene_visibility.frag.spv"
shader=shader_dir/fixed
catalog=runpy.run_path(str(grid/"verify-release-catalog.py"))["verify"]
receipts=load(compiled/"compiled.json")["programs"]
profiles={key:rows[fixed] for key,rows in receipts.items()}
base_shader=profiles["rounded"]["baselineSha256"]
assert profiles["fractional"]["baselineSha256"]==base_shader
backup_tex=control/"baseline-t15.dds"
backup_shader=control/fixed

def restore():
    assert digest(tex) in (original_sha,prepared_sha)
    if digest(tex)!=original_sha:
        assert digest(backup_tex)==original_sha
        replace(backup_tex.read_bytes(),tex,original_sha)
    current_shader=digest(shader)
    assert current_shader in (base_shader,*(row["probeSha256"] for row in profiles.values()))
    if current_shader!=base_shader:
        assert digest(backup_shader)==base_shader
        replace(backup_shader.read_bytes(),shader,base_shader)
    catalog(grid,build)

if mode=="restore":
    restore()
    raise SystemExit(0)
status=load(Path("D:/Projects/FYP-coordination/resources/current.json"))
assert status["state"]=="held" and Path(status["output"]) in (run,grid)
assert status["owner"]==os.environ["CODEX_THREAD_ID"]
catalog(grid,build)
assert digest(tex)==original_sha and digest(prepared)==prepared_sha
backup_tex.write_bytes(tex.read_bytes())
backup_shader.write_bytes(shader.read_bytes())
write(control/"journal.json",dict(textureSha256=original_sha, shaderSha256=base_shader,
      preparedTextureSha256=prepared_sha, lease=status["task"], variants=profiles))
calibration=run.parent/"20261110-003435-visibility-numeric-contract-4f95e7"
x,y=np.fromfile(calibration/"receiver-queries.bin","<f4").reshape(49384,4)[:,:2].astype(np.int32).T
native_visibility=np.fromfile(calibration/"receiver-expected.bin","<u4").astype(np.int32)
regions=run.parent/"20261112-213454-reference-raster-source-a825da/body"
known=np.fromfile(regions/"nvidia-receiver.bin","<u4").reshape(49384,9)
assert np.array_equal(known[:,:2],np.column_stack((x,y)))
owners=known[:,7]
native_normal=known[:,8]

def normal_error(values):
    return np.maximum(*(np.abs(((values>>shift)&1023).astype(np.int32)-
        ((native_normal>>shift)&1023).astype(np.int32)) for shift in (0,10)))

def capture(device,variant):
    folder=control/f"{device}-{variant}"
    folder.mkdir(exist_ok=False)
    verify_budget()
    frames=folder/"frames"
    command=load(grid/f"release-{device}-command.json")
    command[command.index("--capture-dir")+1]=str(frames)
    write(folder/"command.json",command)
    env=os.environ.copy()
    for key in ("VK_DRIVER_FILES","VK_ICD_FILENAMES","VK_LAYER_ENABLES"):
        env.pop(key,None)
    env.update(VK_INSTANCE_LAYERS="VK_LAYER_KHRONOS_validation",VK_LAYER_VALIDATE_SYNC="1",
               VK_LOADER_DRIVERS_SELECT="*igvk64*" if device=="intel" else "*nv-vk64*")
    with (folder/"player.log").open("wb") as log:
        child=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=270)
    log=(folder/"player.log").read_text(errors="replace")
    assert child.returncode==0 and "Allocator after unload: buffers=0 images=0" in log,log[-4000:]
    assert not re.search(r"VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]",log,re.I),log[-4000:]
    gpu=load(frames/"gpu_capabilities.json")
    assert gpu["vendor_id"]==(0x8086 if device=="intel" else 0x10de)
    manifest=load(frames/"capture_manifest.json")["referenceSceneDepth"]
    reference_folder=grid/f"release-{device}-frames"
    reference=load(reference_folder/"reference-planes.json")
    before={}
    with zipfile.ZipFile(reference_folder/"reference-planes.zip") as archive:
        for name in ("raster","hardware","objectIds","packedNormals","objectVisibility"):
            previous=reference[manifest[name]]
            before[name]=archive.read(previous["archiveEntry"])
    after={name:(frames/manifest[name]).read_bytes() for name in before}
    assert all(after[name]==before[name] for name in ("raster","hardware","objectIds"))
    old=np.frombuffer(before["objectVisibility"],"u1").reshape(1440,2560,2)
    new=np.frombuffer(after["objectVisibility"],"u1").reshape(1440,2560,2)
    assert np.array_equal(old[:,:,0],new[:,:,0])
    old_error=np.abs(old[y,x,1].astype(np.int32)-native_visibility)
    new_error=np.abs(new[y,x,1].astype(np.int32)-native_visibility)
    old_normal=np.frombuffer(before["packedNormals"],"<u4").reshape(1440,2560)[y,x]
    new_normal=np.frombuffer(after["packedNormals"],"<u4").reshape(1440,2560)[y,x]
    before_normal_error=normal_error(old_normal)
    after_normal_error=normal_error(new_normal)
    per_owner={}
    for owner in sorted(set(owners)):
        selected=owners==owner
        per_owner[int(owner)]=dict(samples=int(selected.sum()),before=int((selected&(old_error>1)).sum()),
            after=int((selected&(new_error>1)).sum()),introduced=int((selected&(new_error>1)&(old_error<=1)).sum()),
            beforeNormal=int((selected&(before_normal_error>1)).sum()),
            afterNormal=int((selected&(after_normal_error>1)).sum()))
    rows={}
    for frame in sorted(frames.glob("frame_*.png")):
        with Image.open(reference_folder/frame.name) as old_image, Image.open(frame) as new_image:
            old_image=np.asarray(old_image.convert("RGB")).astype(np.int16)
            new_image=np.asarray(new_image.convert("RGB")).astype(np.int16)
        delta=np.abs(new_image-old_image).max(axis=2)
        rows[frame.name]=dict(sha256=digest(frame),changed=int((delta>0).sum()),overOne=int((delta>1).sum()),
                             maximum=int(delta.max()))
    assert len(rows)==3
    write(folder/"results.json",dict(device=device,variant=variant,perOwner=per_owner,frames=rows,
          receiverOverOne=int((new_error>1).sum()),textureSha256=digest(tex),shaderSha256=digest(shader)))
    for path in {frames/manifest[name] for name in before} | set(frames.glob("frame_*.png")):
        assert path.resolve().parent==frames.resolve()
        path.unlink()
    print(device,variant,json.dumps(per_owner[328]),flush=True)

try:
    # Preserve the color shader inputs: the replacement keeps the decoded RGB bytes.
    replace(prepared.read_bytes(),tex,prepared_sha)
    for variant in ("rounded","fractional"):
        path=compiled/variant/fixed
        sha=profiles[variant]["probeSha256"]
        assert digest(path)==sha
        replace(path.read_bytes(),shader,sha)
        for device in ("nvidia","intel"):
            capture(device,variant)
finally:
    restore()
write(control/"restoration.json",dict(shaders=895,textureSha256=digest(tex),verified=True))