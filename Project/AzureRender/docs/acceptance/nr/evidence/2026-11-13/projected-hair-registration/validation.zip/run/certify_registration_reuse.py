from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import sys
from xml.etree import ElementTree as ET

run = Path(__file__).resolve().parent
archive = run/'before-hair-registration-repair'
fixed = {'AzureEngine.ProjectedHairGpu','AzureEngine.ProjectedHairSurfaceGpu'}
source_checks = ['AzureEngine.ContractsSnapshot','AzureEngine.EvolutionCoverage',
                 'AzureEngine.BuildConfiguration','AzureEngine.BuildProvenance']

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def write(path,data):
    tmp=path.with_suffix(path.suffix+'.pending')
    tmp.write_bytes(data)
    tmp.replace(path)

original_seed=read(archive/'registered-seed.json')
for name,expected in read(archive/'preserved.json').items():
    assert digest(archive/name)==expected,name

if sys.argv[1:]==['verify']:
    result={}
    seed=deepcopy(original_seed)
    for config,count in (('release',607),('debug',605)):
        def old(suffix):return read(archive/(config+'-'+suffix))
        def current(suffix):return read(run/(config+'-'+suffix))
        previous=old('products.json');product=current('products.json')
        assert previous['source'].keys()==product['source'].keys()
        changes=[k for k,v in previous['source'].items() if product['source'][k]!=v]
        assert changes==['CMakeLists.txt'],changes
        assert product['products']==previous['products'],[(name,sha) for name,sha in product['products'].items() if previous['products'].get(name)!=sha]
        assert old('tests-source.json')==current('tests-source.json')
        before=old('inventory.json');after=current('inventory.json')
        assert len(before['tests'])==len(after['tests'])==count
        changes=[]
        for one,two in zip(before['tests'],after['tests']):
            assert one['name']==two['name']
            if one==two:continue
            assert config=='release' and one['name'] in fixed and one['command'][-1]=='',one['name']
            expected=one|{'command':one['command'][:-1]}
            assert two==expected,two
            changes.append(one['name'])
        assert set(changes)==(fixed if config=='release' else set()),changes
        names={item['name']:item['command'] for item in after['tests']}
        assert all(name in names for name in source_checks)
        for name in fixed:
            command=names[name]
            assert command[2]=='--executable' and Path(command[3]).name=='AzurePlayer.exe'
            assert command[4:]==(['--require-validation'] if config=='debug' else []),command
        for key,sha in original_seed[config]['provenance'].items():
            assert digest(archive/key)==sha,key
            seed[config]['provenance'][key]=digest(run/key)
        for key,sha in original_seed[config]['junit'].items():
            assert digest(run/key)==sha,key
        write(run/(config+'-hair-registration-gpu.txt'),(''.join(name+'\n' for name in sorted(fixed))).encode())
        write(run/(config+'-hair-registration-source.txt'),(''.join(name+'\n' for name in source_checks)).encode())
        result[config]=dict(registered=count, unchangedProducts=len(product['products']),changedCommands=changes,
                            inputChange='CMakeLists.txt', newCmakeSha256=product['source']['CMakeLists.txt'],
                            newProductReceiptSha256=digest(run/(config+'-products.json')))
    write(run/'hair-registration-reuse.json',(json.dumps(result,indent=2)+'\n').encode())
    write(run/'registered-seed.json',(json.dumps(seed,indent=2)+'\n').encode())
    print(json.dumps(result,indent=2))
else:
    assert sys.argv[1:]==['merge']
    reuse=read(run/'hair-registration-reuse.json')
    for config in ('release','debug'):
        assert reuse[config]['newProductReceiptSha256']==digest(run/(config+'-products.json'))
    def passed(path,expected):
        cases=ET.parse(run/(path+'.xml')).findall('.//testcase')
        result={c.attrib['name']:c for c in cases}
        assert result.keys()==set(expected) and len(cases)==len(result)
        assert all(c.find('failure') is None and c.find('skipped') is None for c in cases)
        row=read(run/(path+'.json'))
        assert row['status']=='passed' and row['tests']==row['selectedTests']==len(cases)
        return result,row
    for config in ('release','debug'):
        passed(config+'-hair-registration-source',source_checks)
    release,retest=passed('release-hair-registration-gpu',fixed)
    passed('debug-hair-registration-gpu',fixed)
    group='release-gpu-27'
    old=read(archive/(group+'.json'))
    cases=ET.parse(archive/(group+'.xml')).findall('.//testcase')
    assert {c.attrib['name'] for c in cases if c.find('failure') is not None}==fixed
    assert all(c.find('skipped') is None for c in cases)
    tree=ET.Element('testsuite',name=group,tests=str(len(cases)))
    tree.extend(release.get(c.attrib['name'],c) for c in cases)
    write(run/(group+'.xml'),ET.tostring(tree,encoding='utf-8',xml_declaration=True))
    old.update(status='passed',exitCode=0,failed=[],skipped=[],seconds=old['seconds']+retest['seconds'],
               retryEvidence='release-hair-registration-gpu.xml',failedEvidence=archive.name+'/'+group+'.xml')
    write(run/(group+'.json'),(json.dumps(old,indent=2)+'\n').encode())
    seed=read(run/'registered-seed.json')
    j='debug-hair-registration-gpu.xml';seed['debug']['junit'][j]=digest(run/j)
    write(run/'registered-seed.json',(json.dumps(seed,indent=2)+'\n').encode())
    print('Both configurations passed the two GPU tests and four source-sensitive tests')
