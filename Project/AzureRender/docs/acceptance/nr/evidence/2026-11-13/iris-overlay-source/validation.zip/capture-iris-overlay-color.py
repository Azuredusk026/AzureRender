from hashlib import sha256
from pathlib import Path
from uuid import UUID, uuid5
import json
import os
import re
import runpy
import struct
import subprocess
import sys

import numpy as np

run = Path(__file__).resolve().parent
capture = runpy.run_path(str(run / "capture-iris-overlay-geometry.py"))
build = capture["build"]
folder = capture["folder"]
source = run / "native-overlay-inputs"
target = run / "iris-overlay-color-captures"
material_name = "M_eyewhiteshadow_common_01"
original_slot = "67d632b6-c69f-5d87-9728-9da8bbedef8d"
namespace = UUID("488e714f-3f2e-4514-92f9-781a5beed58f")
read = lambda p: json.loads(p.read_bytes())


def dump(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def create_variant():
    texture = runpy.run_path(str(run / "native-eye-overlay-texture.py"))
    constant = texture["constants"]
    tint = constant[2,:3].tolist()
    native = read(source / "results.json")
    assert native["textures"]["3"]["format"] == "BC7_UNORM"
    assert native["textures"]["3"]["mips"] == 6
    assert float(np.fromfile(source / "cb1.bin","<f4").reshape(-1,4)[26,0]) == -1
    pixels = []
    for level in range(6):
        red = np.rint(texture["rgba"](level)[...,0]*255).astype("u1")
        output = np.full((*red.shape,4),255,dtype="u1")
        output[...,3] = red[::-1]
        pixels.append(output.tobytes())
    header = bytearray(128)
    header[:4] = b"DDS "
    struct.pack_into("<7I",header,4,124,0x2100F,32,32,128,0,6)
    struct.pack_into("<8I",header,76,32,0x41,0,32,0xff,0xff00,0xff0000,0xff000000)
    struct.pack_into("<I",header,108,0x401008)
    asset_name = "native-eye-shadow-coverage.dds"
    asset_path = folder / "materials" / asset_name
    texture_uuid = str(uuid5(namespace,asset_name))
    with asset_path.open("xb") as output:
        output.write(header+b"".join(pixels))
    dump(asset_path.with_suffix(".dds.azmeta"),dict(schemaVersion=1,id=texture_uuid,dependencies=[],
         settings=dict(texture=dict(usage="linear",colorSpace="linear",filter="linear",
                      mipFilter="nearest",wrapU="repeat",wrapV="repeat",anisotropy=1,mipBias=-1))))
    candidate_uuid = str(uuid5(namespace,"material"))
    original = read(folder / "materials" / (original_slot+".azurematerial"))
    original["textures"]["0"]["asset"] = texture_uuid
    original["surface"]["materials"][0]["pbrMetallicRoughness"]["baseColorFactor"] = tint+[1]
    # Native fog and clustered lights remain independent of this material-source control.
    dest = folder / "materials" / "native-eye-shadow-color.azurematerial"
    dump(dest,original)
    dump(dest.with_suffix(".azurematerial.azmeta"),dict(schemaVersion=1,id=candidate_uuid,dependencies=[],settings={}))
    level = read(folder / "scene/static-qualified.azurelevel")
    added = next(node for node in level["nodes"] if node["id"]=="native-eye-shadow")
    added["materialSlots"]["name:"+material_name] = candidate_uuid
    dump(folder / "scene/static-eye-shadow-color.azurelevel",level)
    project = read(folder / "qualified.azureproject")
    project["startupScene"]="stage:/static-eye-shadow-color.azurelevel"
    dump(folder / "eye-shadow-color.azureproject",project)
    dump(target / "inputs.json",dict(sourceTexture=native["textures"]["3"],sourceTint=tint,
         nativeSampler=native["samplers"]["2"],assetSha256=sha256(asset_path.read_bytes()).hexdigest(),
         materialSha256=sha256(dest.read_bytes()).hexdigest(),sourceMaterial=original_slot))


def measure(device, mode):
    frames = target / f"{device}-{mode}/frames"
    output = frames.parent
    output.mkdir(parents=True, exist_ok=False)
    command = read(run / f"static-{device}-command.json")
    project = "eye-shadow-color.azureproject" if mode != "legacy" else "qualified.azureproject"
    command[command.index("--project") + 1] = str(folder / project)
    command[command.index("--capture-dir") + 1] = str(frames)
    if mode == "disabled":
        command.extend(("--qa-effect", "overlay", "--qa-effect-state", "disabled"))
    dump(output / "command.json",command)
    env = os.environ.copy()
    for key in ("VK_DRIVER_FILES","VK_ICD_FILENAMES","VK_LAYER_ENABLES"):
        env.pop(key,None)
    env.update(VK_LOADER_DRIVERS_SELECT="*nv-vk64*" if device=="nvidia" else "*igvk64*",
               VK_INSTANCE_LAYERS="VK_LAYER_KHRONOS_validation", VK_LAYER_VALIDATE_SYNC="1")
    with (output / "player.log").open("wb") as stream:
        child=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=300)
    log=(output / "player.log").read_text(errors="replace")
    assert child.returncode==0 and "Allocator after unload: buffers=0 images=0" in log,log[-5000:]
    assert not re.search(r"VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]",log,re.I),log[-5000:]
    assert read(frames / "gpu_capabilities.json")["vendor_id"] == (0x10de if device=="nvidia" else 0x8086)


if __name__ == "__main__":
    state = read(Path("D:/Projects/FYP-coordination/resources/current.json"))
    assert state["state"]=="held" and Path(state["output"])==run
    runpy.run_path(str(run/"verify-release-catalog.py"))["verify"](run,build)
    target.mkdir(exist_ok=True)
    if not (target/"inputs.json").is_file():
        create_variant()
    capture["compare"].__globals__["target"]=target
    for device in sys.argv[1:] or ("nvidia","intel"):
        for mode in ("disabled","enabled"):
            measure(device,mode)
        capture["compare"](device)

