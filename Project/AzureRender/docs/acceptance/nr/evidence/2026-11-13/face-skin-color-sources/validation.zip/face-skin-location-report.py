from pathlib import Path
from hashlib import sha256
from PIL import Image
import cv2,json,numpy as np,runpy

run=Path(__file__).resolve().parent
score=runpy.run_path(str(run/'static-quality.py'))
reference=score['image'](score['reference_path']).astype(np.int16)
fixture={kind:cv2.erode(np.asarray(Image.open(run/f'native-face-masks/{kind}.png').convert('L')),np.ones((13,13),dtype=np.uint8))>0 for kind in ('face','skin')}
assert [int(mask.sum()) for mask in fixture.values()]==[1176,28966]
prod={'nvidia':'iris-production-absolute-icd','intel':'iris-production-captures'}
report={}
for kind,mask in fixture.items():
    candidates={dev:score['image'](run/f'{folder}/{dev}-enabled/frames/frame_000000.png').astype(np.int16) for dev,folder in prod.items()}
    channel={dev:a-reference for dev,a in candidates.items()}
    magnitude={dev:np.max(np.abs(e),axis=2) for dev,e in channel.items()}
    shared=np.minimum(magnitude['nvidia'],magnitude['intel'])
    assert int((magnitude['nvidia'][mask]>1).sum())=={'face':1174,'skin':10957}[kind]
    output={}
    chosen={}
    for device,d in [*magnitude.items(),('shared',shared)]:
        points=np.zeros(d.shape,bool)
        by_threshold={}
        for threshold in (1,4,8,12,16,24,32):
            locations=mask&(d>threshold)
            count,label,stats,center=cv2.connectedComponentsWithStats(locations.astype(np.uint8),8)
            bands=sorted((dict(x=int(l),y=int(t),width=int(w),height=int(h),samples=int(area)) for l,t,w,h,area in stats[1:]), key=lambda item:-item['samples'])
            by_threshold[threshold]=dict(samples=int(locations.sum()),clusters=bands[:12],clustersCount=count-1)
            if threshold in (8,16): points|=locations
        output[device]=by_threshold
        if device!='shared':
            y,x=np.unravel_index(np.where(mask,d,-1).argmax(),d.shape)
            output[device]['peak']=dict(x=int(x),y=int(y),maximum=int(d[y,x]),rgbReference=reference[y,x].tolist(),rgbCandidate=candidates[device][y,x].tolist())
            selected=channel[device][mask&(d>8)]
            output[device]['medianRgbDeltaOverEight']=np.median(selected,axis=0).tolist()
            chosen[device]=points
    union=chosen['nvidia']|chosen['intel']; y,x=np.where(union)
    np.column_stack([x,y]).astype('<u4').tofile(run/f'{kind}-residual-points.bin')
    report[kind]=output
path=run/'face-skin-location-report.json'
path.write_text(json.dumps(report,indent=2)+'\n')
for kind,value in report.items():
    print(kind,{device:{'over8':row[8]['samples'],'over16':row[16]['samples'],'peak':row.get('peak'),'clusters8':row[8]['clusters'][:4]} for device,row in value.items()})
