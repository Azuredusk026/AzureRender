from pathlib import Path
from hashlib import file_digest
import gzip,json,numpy as np,runpy

run=Path(__file__).resolve().parent
source=runpy.run_path(str(run/'static-quality.py'))
root=source['stages']/'post-opaque-ownership'
manifest=json.loads((root/'manifest.json').read_bytes())
ref=source['image'](source['reference_path'])
selected={name:np.fromfile(run/f'{name}-residual-points.bin','<u4').reshape(-1,2) for name in ('face','skin')}
colors={dev:source['image'](run/f'{path}/{dev}-enabled/frames/frame_000000.png') for dev,path in (('nvidia','iris-production-absolute-icd'),('intel','iris-production-captures'))}

def unpack(raw):
    channels=[]
    for shift,bits in ((0,6),(11,6),(22,5)):
        value=(raw>>shift)&((1<<(bits+5))-1)
        exponent=(value>>bits).astype(int)
        mantissa=value&((1<<bits)-1)
        linear=np.clip(np.where(exponent==0,np.ldexp(mantissa.astype(float),-14-bits),np.ldexp(1+mantissa/(1<<bits),exponent-15))*.25,0,1)
        channels.append(np.rint(np.where(linear<=.0031308,linear*12.92,1.055*linear**(1/2.4)-.055)*255).astype(np.int16))
    return np.column_stack(channels)


def diff(a,b):
    d=np.max(np.abs(a.astype(np.int16)-b.astype(np.int16)),axis=1)
    return dict(overOne=int((d>1).sum()),overEight=int((d>8).sum()),peak=int(d.max()),mean=float(d.mean()))


def load(path):
    with path.open('rb') as stream:
        digest=file_digest(stream,'sha256').hexdigest()
    return np.frombuffer(gzip.decompress(path.read_bytes()),'<u4').reshape(1440,2560)[::-1],digest


report={kind:{'samples':len(xy),'events':{}} for kind,xy in selected.items()}
for event in manifest['events']:
    (a,digest_a),(b,digest_b)=(load(root/name) for name in event['files'])
    for kind,xy in selected.items():
        x,y=xy.T
        changed=a[y,x]!=b[y,x]
        if not np.any(changed):
            continue
        x,y=x[changed],y[changed]
        after,before=unpack(a[y,x]),unpack(b[y,x])
        target=ref[y,x]
        row=dict(points=int(changed.sum()),indices=event['indices'],nativeAttachment=event['target'],beforeSha256=digest_b,afterSha256=digest_a,
                 afterVsFinal=diff(after,target),beforeVsFinal=diff(before,target),devices={dev:{'before':diff(p[y,x],before),'after':diff(p[y,x],after)} for dev,p in colors.items()})
        report[kind]['events'][event['event']]=row
assert report['face']['events']=={}
assert set(report['skin']['events'])=={1018,1383}
assert sum(row['points'] for row in report['skin']['events'].values())==91
(run/'face-skin-native-later-colors.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
