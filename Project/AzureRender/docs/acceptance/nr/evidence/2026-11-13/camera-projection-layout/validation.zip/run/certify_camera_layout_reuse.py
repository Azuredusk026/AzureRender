from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import shutil
import sys
from xml.etree import ElementTree as ET

run = Path(__file__).resolve().parent
old = run/'before-camera-layout-repair'
fixture_names = {'AzureRender.CameraProjectionGpu','AzureRender.CaptureCameraGpu'}
expected_changes = {'tools/render_capture_layout.py','tools/test_camera_projection_gpu.py','tools/test_capture_camera_gpu.py'}
source_tests = ['AzureEngine.ContractsSnapshot','AzureEngine.EvolutionCoverage','AzureEngine.BuildProvenance']

def read(path):return json.loads(path.read_bytes())
def digest(path):return sha256(path.read_bytes()).hexdigest()
def write(path,data):
    tmp=path.with_suffix(path.suffix+'.pending');tmp.write_bytes(data);tmp.replace(path)

def with_json(path,result):
    write(path,(json.dumps(result,indent=2)+'\n').encode())

if sys.argv[1:]==['verify']:
    for suffix in ('.json','.xml','.txt','.log','-queue.log'):
        name='release-gpu-40'+suffix
        shutil.copy2(run/name,old/name)
        assert digest(run/name)==digest(old/name)
    assert 'AzureRender.CaptureCameraGpu' in read(old/'release-gpu-40.json')['failed']
    seed=deepcopy(read(old/'registered-seed.json'))
    result={}
    for c in ('release','debug'):
        name=c+'-products.json';a=read(old/name);b=read(run/name)
        assert a['source'].keys()==b['source'].keys()
        assert {n for n,h in a['source'].items() if h!=b['source'][n]}==expected_changes
        assert a['products']==b['products']
        for name in (c+'-inventory.json',c+'-tests-source.json'):
            assert read(old/name)==read(run/name)
        for name,sha in seed[c]['provenance'].items():
            assert digest(old/name)==sha,name
            seed[c]['provenance'][name]=digest(run/name)
        for name,sha in seed[c]['junit'].items():assert digest(run/name)==sha,name
        (run/(c+'-camera-layout-gpu.txt')).write_text(''.join(n+'\n' for n in sorted(fixture_names)),encoding='utf-8')
        (run/(c+'-camera-layout-source.txt')).write_text(''.join(n+'\n' for n in source_tests),encoding='utf-8')
        result[c]=dict(unchangedProducts=len(b['products']),changedInputs={n:b['source'][n] for n in sorted(expected_changes)},
                       productReceiptSha256=digest(run/(c+'-products.json')))
    with_json(run/'camera-layout-reuse.json',result)
    with_json(run/'registered-seed.json',seed)
    print(json.dumps(result,indent=2))
else:
    assert sys.argv[1:]==['merge']
    def passed(name,expected=None):
        report=read(run/(name+'.json'))
        assert report['status']=='passed' and report['exitCode']==0 and not report['failed'] and not report['skipped'],name
        cases=ET.parse(run/(name+'.xml')).findall('.//testcase')
        result={case.attrib['name']:case for case in cases}
        if expected is not None:assert set(expected)==result.keys(),name
        assert len(cases)==len(result)==report['tests']==report['selectedTests']
        assert all(c.find('failure') is None and c.find('skipped') is None for c in result.values())
        return result,report
    for c in ('release','debug'):
        passed(c+'-camera-layout-source',source_tests)
        passed(c+'-camera-layout-gpu',fixture_names)
    result,retest=passed('release-camera-layout-gpu',fixture_names)
    affected=(('release-gpu-39','AzureRender.CameraProjectionGpu'),
              ('release-gpu-40','AzureRender.CaptureCameraGpu'))
    if read(old/'release-gpu-40.json')['failed']!=['AzureRender.CaptureCameraGpu']:
        passed('release-gpu-40',set((old/'release-gpu-40.txt').read_text().splitlines()))
        affected=affected[:1]
    for group,fix in affected:
        prior=read(old/(group+'.json'))
        assert prior['failed']==[fix] and not prior['skipped']
        cases=ET.parse(old/(group+'.xml')).findall('.//testcase')
        assert len(cases)==prior['tests']
        assert {c.attrib['name'] for c in cases if c.find('failure') is not None}=={fix}
        assert all(c.find('skipped') is None for c in cases)
        tree=ET.Element('testsuite',name=group,tests=str(len(cases)))
        tree.extend(result[fix] if c.attrib['name']==fix else c for c in cases)
        write(run/(group+'.xml'),ET.tostring(tree,encoding='utf-8',xml_declaration=True))
        prior.update(status='passed',exitCode=0,failed=[],skipped=[],seconds=prior['seconds']+float(result[fix].attrib['time']),
                     retryEvidence='release-camera-layout-gpu.xml',failedEvidence=old.name+'/'+group+'.xml')
        with_json(run/(group+'.json'),prior)
    seed=read(run/'registered-seed.json')
    name='debug-camera-layout-gpu.xml';seed['debug']['junit'][name]=digest(run/name)
    with_json(run/'registered-seed.json',seed)
    print('Both configurations passed camera and source checks; original shard outcomes verified')
