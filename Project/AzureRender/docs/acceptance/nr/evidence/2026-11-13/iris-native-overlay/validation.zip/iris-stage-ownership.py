from pathlib import Path
from hashlib import sha256
import gzip
import json

import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
base=Path("D:/Projects/FYP/Project/AzureRender/build/runs/20261103-234012-character-reference-stages-5abe6c")
directory=base/"post-opaque-ownership"
masks=run/"native-face-masks"
receipt=json.loads((masks/"result.json").read_bytes())
assert receipt["status"]=="qualified"
mask_path=masks/"iris.png"
assert sha256(mask_path.read_bytes()).hexdigest()==receipt["masks"]["iris"]["sha256"]
with Image.open(mask_path) as im:
    mask=np.asarray(im)!=0
assert int(mask.sum())==255
stages={}
for row in json.loads((directory/"manifest.json").read_bytes())["events"]:
    a,b=[np.frombuffer(gzip.decompress((directory/file).read_bytes()),"<u4").reshape(1440,2560)[::-1][mask]
         for file in row["files"]]
    stages[row["event"]]=dict(changed=int((a!=b).sum()),samples=len(a),attachment=row["target"])
report=dict(irisMask=receipt["masks"]["iris"],stages=stages)
(run/"iris-stage-ownership.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report))