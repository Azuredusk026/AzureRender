from pathlib import Path
import gzip
import json
import runpy

import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
score=runpy.run_path(str(run/"static-quality.py"))
native=score["stages"]/"post-opaque-ownership"
with Image.open(run/"native-face-masks/iris.png") as image:
    mask=np.asarray(image)!=0

def unpack(path):
    words=np.frombuffer(gzip.decompress(path.read_bytes()),"<u4").reshape(1440,2560)[::-1][mask]
    channels=[]
    for shift,bits in ((0,6),(11,6),(22,5)):
        raw=(words>>shift)&((1<<(bits+5))-1)
        exp=(raw>>bits).astype(np.int32)
        mantissa=raw&((1<<bits)-1)
        channels.append(np.where(exp==0,np.ldexp(mantissa.astype(float),-14-bits),
                                 np.ldexp(1+mantissa/(1<<bits),exp-15))*.25)
    return np.column_stack(channels)

before,after=(unpack(native/f"1245-{event}.bin.gz") for event in (1244,1245))
changed=np.any(before!=after,axis=1)
assert len(before)==255 and int(changed.sum())==94
ratio=np.divide(after,before,out=np.ones_like(after),where=before>0)
assert not np.any((before==0)&(after>0))
native_final=score["image"](score["reference_path"])[mask]
results={}
for device in ("nvidia","intel"):
    pixels=score["image"](run/f"static-{device}-frames/frame_000000.png")[mask]
    c=pixels.astype(float)/255
    linear=np.where(c<=.04045,c/12.92,((c+.055)/1.055)**2.4)
    predicted=linear*ratio
    srgb=np.where(predicted<=.0031308,predicted*12.92,1.055*predicted**(1/2.4)-.055)
    srgb=np.rint(np.clip(srgb,0,1)*255).astype(np.int16)
    delta=np.abs(srgb-native_final).max(axis=1)
    results[device]=dict(coveredOverOne=int((delta[changed]>1).sum()),totalOverOne=int((delta>1).sum()),
                          peak=int(delta.max()))
report=dict(scope="native per-pixel attenuation source replacement",samples=255,changed=94,
            ratioRange=[ratio[changed].min(axis=0).tolist(),ratio[changed].max(axis=0).tolist()],
            ratioMedian=np.median(ratio[changed],axis=0).tolist(),devices=results)
(run/"iris-overlay-factor-control.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report))