from pathlib import Path
import gzip
import json
import runpy

import numpy as np
from PIL import Image

run=Path(__file__).resolve().parent
score=runpy.run_path(str(run/"static-quality.py"))
image=score["image"]
native=score["stages"]/"post-opaque-ownership"
ownership=json.loads((run/"iris-stage-ownership.json").read_bytes())
assert ownership["stages"]["1245"]["changed"]==94
paths=[native/f"1245-{event}.bin.gz" for event in (1244,1245)]
with Image.open(run/"native-face-masks/iris.png") as mask_file:
    mask=np.asarray(mask_file)!=0
assert int(mask.sum())==255

def decode(path):
    words=np.frombuffer(gzip.decompress(path.read_bytes()),"<u4").reshape(1440,2560)[::-1][mask]
    decoded=[]
    for shift,bits in ((0,6),(11,6),(22,5)):
        word=(words>>shift)&((1<<(bits+5))-1)
        exp=(word>>bits).astype(np.int32)
        mantissa=word&((1<<bits)-1)
        decoded.append(np.where(exp==0,np.ldexp(mantissa.astype(float),-14-bits),
                               np.ldexp(1+mantissa/(1<<bits),exp-15))*.25)
    linear=np.column_stack(decoded)
    srgb=np.where(linear<=.0031308,linear*12.92,1.055*linear**(1/2.4)-.055)
    return words, np.rint(np.clip(srgb,0,1)*255).astype(np.int16)

before,after=[decode(path) for path in paths]
native_reference=image(score["reference_path"])[mask].astype(np.int16)
changed=before[0]!=after[0]
assert int(changed.sum())==94
assert np.array_equal(after[1],native_reference)
report=dict(pixels=255,nativeOverlayChanged=int(changed.sum()),
            nativeDisplayChanged=int(np.any(before[1]!=after[1],axis=1).sum()), devices={})
for device in ("nvidia","intel"):
    candidate=image(run/f"static-{device}-frames/frame_000000.png")[mask].astype(np.int16)
    subsets={}
    for name,selected in (("covered",changed),("uncovered",~changed)):
        results={}
        for label,source in (("before",before[1]),("after",after[1])):
            delta=np.abs(candidate[selected]-source[selected]).max(axis=1)
            results[label]=dict(overOne=int((delta>1).sum()),maximum=int(delta.max()),mean=float(delta.mean()))
        subsets[name]=results
    report["devices"][device]=subsets
(run/"iris-native-overlay-comparison.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))