from io import BytesIO
from pathlib import Path
import json
import runpy
import struct

import numpy as np
from PIL import Image

run = Path(__file__).resolve().parent
source = run / "native-overlay-inputs"
legacy = runpy.run_path(str(run / "eye-overlay-legacy-factor.py"))
geo, active = legacy["geometry"], legacy["active"]
uv = geo[active, 3:5]
native = legacy["native"]
constants = np.fromfile(source / "cb4.bin", "<f4").reshape(-1, 4)
assert constants[0,0] == 1 and constants[0,2] == constants[0,3] == 0
assert constants[2,3] == 1
tint = constants[2,:3].astype(float)
def rgba(mip):
    raw = (source / f"t3-mip{mip}.bin").read_bytes()
    width = 32 >> mip
    header = bytearray(148)
    header[:4] = b"DDS "
    struct.pack_into("<7I", header, 4, 124, 0x81007, width, width, len(raw), 0, 1)
    struct.pack_into("<II4s", header, 76, 32, 4, b"DX10")
    struct.pack_into("<I", header, 108, 0x1000)
    struct.pack_into("<5I", header, 128, 98, 3, 0, 1, 0)
    with Image.open(BytesIO(header+raw)) as image:
        return np.asarray(image.convert("RGBA")).astype(float)/255
report = {}
for flip in (False,True):
    coords=uv.copy()
    if flip:
        coords[:,1]=1-coords[:,1]
    for mip in range(6):
        pixels=rgba(mip)
        data=legacy["sample"](pixels, coords, "repeat")
        estimate=1-data[:,:1]*(1-tint)
        delta=np.abs(estimate-native)
        recovered=(1-native)/(1-tint)
        alpha_error=np.abs(recovered-data[:,:1])
        report[f"{flip}-{mip}"]=dict(meanError=delta.mean(0).tolist(), maxError=delta.max(0).tolist(),
            p95=np.percentile(delta,95,axis=0).tolist(), recoveredAlphaMeanError=alpha_error.mean(0).tolist())
(run / "native-eye-overlay-texture.json").write_text(json.dumps(report,indent=2)+"\n")
for k,v in sorted(report.items(), key=lambda kv: sum(kv[1]["meanError"]))[:6]:
    print(k,v)
