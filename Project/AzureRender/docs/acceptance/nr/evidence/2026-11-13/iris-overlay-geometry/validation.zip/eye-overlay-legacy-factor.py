from pathlib import Path
import gzip
import json
import runpy

import numpy as np
from PIL import Image

run = Path(__file__).resolve().parent
score = runpy.run_path(str(run / "static-quality.py"))
geometry = np.fromfile(run / "native-eye-overlay-footprint.bin", "<f4").reshape(-1, 8)
active = geometry[:, 6] > 0
assert active.sum() == 95
x, y = geometry[active, :2].astype(int).T
uv = geometry[active, 3:5]
root = score["stages"] / "post-opaque-ownership"
texture = score["stages"] / "qualified-background-geometry-static/materials/4bd32c61-225c-5f6f-bcc1-4cf326f0ded6.png"


def decode(path):
    value = np.frombuffer(gzip.decompress(path.read_bytes()), "<u4").reshape(1440, 2560)[::-1][y, x]
    channels = []
    for shift, bits in ((0, 6), (11, 6), (22, 5)):
        packed = (value >> shift) & ((1 << (5 + bits)) - 1)
        exponent, mantissa = (packed >> bits).astype(int), packed & ((1 << bits) - 1)
        channels.append(np.where(exponent == 0, np.ldexp(mantissa.astype(float), -14 - bits),
                                 np.ldexp(1 + mantissa / (1 << bits), exponent - 15)))
    return np.column_stack(channels)


def sample(data, uv, address):
    h, w = data.shape[:2]
    index = uv * [w, h] - .5
    lower = np.floor(index).astype(int)
    f = index - lower
    out = np.zeros((len(uv), 4))
    for dy in (0, 1):
        for dx in (0, 1):
            ij = lower + [dx, dy]
            if address == "repeat":
                i, j = (ij % [w,h]).T
            else:
                i, j = np.clip(ij, 0, [w-1,h-1]).T
            out += data[j, i] * ((f[:, 0] if dx else 1-f[:, 0]) * (f[:, 1] if dy else 1-f[:, 1]))[:, None]
    return out


native = decode(root / "1245-1245.bin.gz") / decode(root / "1245-1244.bin.gz")
with Image.open(texture) as image:
    pixels = np.asarray(image.convert("RGBA")).astype(float) / 255
report = dict(changedPixels=int(active.sum()), nativeMedian=np.median(native, axis=0).tolist(), cases={})
for flip in (False, True):
    for address in ("repeat", "clamp"):
        source = uv.copy()
        if flip:
            source[:, 1] = 1 - source[:, 1]
        sample_rgba = sample(pixels, source, address)
        engine = 1 - sample_rgba[:, 3:4] * (1 - sample_rgba[:, :3])
        # Fit an RGB modulation vector only to distinguish texture coverage from the source tint.
        alpha = sample_rgba[:,3]
        coefficient = (alpha[:, None] * (1 - native)).sum(0) / (alpha ** 2).sum()
        fit = 1 - alpha[:, None] * coefficient
        report["cases"][f"{address}-flip-{flip}"] = dict(
            meanError=np.abs(engine-native).mean(0).tolist(), peakError=np.abs(engine-native).max(0).tolist(),
            alphaRange=[float(alpha.min()),float(alpha.max())], fitColor=(1-coefficient).tolist(),
            fitMeanError=np.abs(fit-native).mean(0).tolist(),
            fitR2=(1-np.square(fit-native).sum(0)/np.square(native-native.mean(0)).sum(0)).tolist(),
        )
(run/"eye-overlay-legacy-factor.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report))
