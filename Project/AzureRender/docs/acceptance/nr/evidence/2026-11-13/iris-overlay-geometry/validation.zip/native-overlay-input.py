from pathlib import Path
from hashlib import file_digest
import json
import os
import subprocess

run = Path(__file__).resolve().parent
folder = run / "native-overlay-inputs"
folder.mkdir(exist_ok=True)
request = json.loads((run / "native-face-masks/request.json").read_bytes())
with Path(request["native"]).open("rb") as stream:
    assert file_digest(stream, "sha256").hexdigest() == request["captureSha256"]
(folder / "request.json").write_text(json.dumps(request, indent=2) + "\n")
env = os.environ.copy()
env["AZURE_NR_OVERLAY_REPLAY"] = str(folder)
startup = subprocess.STARTUPINFO()
startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow = 0
with (folder / "replay.log").open("wb") as log:
    child = subprocess.run(["D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe", "--python",
                            str(run / "native-overlay-input-worker.py")],
                           stdout=log, stderr=subprocess.STDOUT, env=env, cwd=folder, startupinfo=startup, timeout=165)
report = json.loads((folder / "results.json").read_bytes())
print(json.dumps(report), flush=True)
assert child.returncode == 0 and report["status"] == "qualified"
