from pathlib import Path
import gzip
import json
import os
import re
import runpy
import subprocess
import sys

import numpy as np
from PIL import Image

run = Path(__file__).resolve().parent
score = runpy.run_path(str(run / "static-quality.py"))
prepare = runpy.run_path(str(run / "prepare-iris-overlay-geometry.py"))
build = run.parent / "20261110-030251-hair-main-chroma-public-9e799c/release"
folder = run / "iris-overlay-geometry-project"
target = run / "iris-overlay-geometry-captures"


def measure(device, mode):
    frames = target / f"{device}-{mode}/frames"
    output = frames.parent
    output.mkdir(parents=True, exist_ok=False)
    command = json.loads((run / f"static-{device}-command.json").read_bytes())
    command[command.index("--project") + 1] = str(folder / "qualified.azureproject")
    command[command.index("--capture-dir") + 1] = str(frames)
    if mode == "disabled":
        command.extend(("--qa-effect", "overlay", "--qa-effect-state", "disabled"))
    (output / "command.json").write_text(json.dumps(command, indent=2) + "\n")
    env = os.environ.copy()
    for key in ("VK_DRIVER_FILES", "VK_ICD_FILENAMES", "VK_LAYER_ENABLES"):
        env.pop(key, None)
    env.update(VK_LOADER_DRIVERS_SELECT="*nv-vk64*" if device == "nvidia" else "*igvk64*",
               VK_INSTANCE_LAYERS="VK_LAYER_KHRONOS_validation", VK_LAYER_VALIDATE_SYNC="1")
    with (output / "player.log").open("wb") as stream:
        child = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=300)
    log = (output / "player.log").read_text(errors="replace")
    assert child.returncode == 0 and "Allocator after unload: buffers=0 images=0" in log, log[-5000:]
    assert not re.search(r"VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]", log, re.I), log[-5000:]
    manifest = json.loads((frames / "gpu_capabilities.json").read_bytes())
    assert ("NVIDIA" if device == "nvidia" else "Intel") in manifest["device_name"]
    return frames / "frame_000000.png"


def compare(device):
    read = score["image"]
    reference = read(score["reference_path"])
    before = read(run / f"static-{device}-frames/frame_000000.png")
    on = read(target / f"{device}-enabled/frames/frame_000000.png")
    off = read(target / f"{device}-disabled/frames/frame_000000.png")
    iris = np.asarray(Image.open(run / "native-face-masks/iris.png")) != 0
    assert int(iris.sum()) == 255
    directory = score["stages"] / "post-opaque-ownership"
    native_off, native_on = [np.frombuffer(gzip.decompress((directory / name).read_bytes()), "<u4")
                              .reshape(1440, 2560)[::-1]
                              for name in ("1245-1244.bin.gz", "1245-1245.bin.gz")]
    owner = native_off != native_on
    assert int((owner & iris).sum()) == 94
    a, b, c, d = (array.astype(np.int16) for array in (before, on, off, reference))
    ab, ac, ad, bd = (np.abs(x - y).max(2) for x, y in ((a,b),(a,c),(a,d),(b,d)))
    assert int(ac[iris].max()) == 0 and int((ac > 0).sum()) <= 1
    baseline_control_positions = np.argwhere(ac > 0)[:, ::-1].tolist()
    ab = np.abs(c - b).max(2)
    ad = np.abs(c - d).max(2)
    changed = ab > 0
    def count(delta, region):
        values = delta[region]
        return dict(samples=int(values.size), overOne=int((values > 1).sum()), peak=int(values.max()))
    regions = {"iris": iris, "iris-native-overlay": iris & owner, "iris-outside-native-overlay": iris & ~owner}
    for name in ("face", "skin"):
        mask = run / f"native-face-masks/{name}.png"
        if mask.exists():
            regions[name] = score["cv2"].erode(np.asarray(Image.open(mask)), score["kernel"]) != 0
            assert int(regions[name].sum()) == {"face": 1176, "skin": 28966}[name]
    report = dict(device=device, baselineControl=count(ac, np.ones(iris.shape, dtype=bool)),
                  baselineControlPositions=baseline_control_positions,
                  candidateChanged=int(changed.sum()), nativeOverlayChanged=int(owner.sum()),
                  coveredIrisChanged=int((changed & iris & owner).sum()),
                  uncoveredIrisChanged=int((changed & iris & ~owner).sum()),
                  changedOutsideNativeOverlay=int((changed & ~owner).sum()),
                  outsideNativeOverlayOverOne=count(ab, ~owner),
                  baseline={name:count(ad, mask) for name,mask in regions.items()},
                  candidate={name:count(bd, mask) for name,mask in regions.items()},
                  candidateRegional=score["compare"](reference, on, regions),
                  candidateSha256=score["sha"](target / f"{device}-enabled/frames/frame_000000.png"))
    np.column_stack((off[iris], on[iris], before[iris], reference[iris], owner[iris])).astype("u1").tofile(
        target / f"{device}-selected.bin")
    (target / f"{device}-results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    state = json.loads(Path("D:/Projects/FYP-coordination/resources/current.json").read_text())
    assert state["state"] == "held" and Path(state["output"]) == run
    runpy.run_path(str(run / "verify-release-catalog.py"))["verify"](run, build)
    if not folder.exists():
        prepare["prepare"](False)
    target.mkdir(exist_ok=True)
    for device in sys.argv[1:] or ("nvidia", "intel"):
        for mode in ("disabled", "enabled"):
            measure(device, mode)
        compare(device)



