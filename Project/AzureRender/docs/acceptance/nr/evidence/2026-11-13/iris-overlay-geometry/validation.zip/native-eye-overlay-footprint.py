from pathlib import Path
import gzip
import json
import runpy
import sys

import numpy as np
from PIL import Image

run = Path(__file__).resolve().parent
prepare = runpy.run_path(str(run / "prepare-iris-overlay-geometry.py"))
score = runpy.run_path(str(run / "static-quality.py"))
replay = prepare["read_postvs"](prepare["postvs"])
d = replay["attributes"]
clip = d["SV_Position"].astype(np.float64)
triangles = replay["indices"].reshape(-1, 3)
screen = (clip[:, :2] / clip[:, 3, None] + 1) * [1280, 720]
directory = score["stages"] / "post-opaque-ownership"
before, after = [np.frombuffer(gzip.decompress((directory / name).read_bytes()), "<u4")
                 .reshape(1440, 2560)[::-1]
                 for name in ("1245-1244.bin.gz", "1245-1245.bin.gz")]
native = before != after
iris = np.asarray(Image.open(run / "native-face-masks/iris.png")) != 0
assert (native & iris).sum() == 94
assert native.shape == iris.shape
p0 = np.floor(screen.min(axis=0)).astype(int) - 2
p1 = np.ceil(screen.max(axis=0)).astype(int) + 2
x, y = np.meshgrid(np.arange(p0[0], p1[0]), np.arange(p0[1], p1[1]))
x, y = x.ravel(), y.ravel()
pixel = np.column_stack((x, y)).astype(float) + .5
covered = np.zeros(len(pixel), dtype=np.uint8)
uv = np.zeros((len(pixel), 2), dtype=np.float64)
view_depth = np.full(len(pixel), np.inf)
for indices in triangles:
    a, b, c = (np.rint(screen[indices] * 256) / 256)
    inverse = np.linalg.inv(np.stack((b - a, c - a), axis=1))
    bary12 = (pixel - a) @ inverse.T
    bary = np.column_stack((1 - bary12.sum(axis=1), bary12))
    inside = (bary >= 0).all(axis=1)
    covered += inside
    weighted = bary[inside] / clip[indices, 3]
    depth = 1 / weighted.sum(axis=1)
    selected = np.flatnonzero(inside)
    nearest = depth < view_depth[selected]
    chosen = selected[nearest]
    view_depth[chosen] = depth[nearest]
    uv[chosen] = ((weighted @ d["TEXCOORD0"][indices]) * depth[:, None])[nearest]

native_area = native[y, x]
iris_area = iris[y, x]
valid = covered > 0
assert int(native_area.sum()) == int(native.sum())
assert (covered <= 1).all()
report = dict(geometryPixels=int(valid.sum()), nativeChanged=int(native_area.sum()),
              nativeOutsideGeometry=int((native_area & ~valid).sum()),
              irisGeometry=int((valid & iris_area).sum()),
              irisUnchangedInsideGeometry=int((valid & iris_area & ~native_area).sum()),
              nativeIrisOutsideGeometry=int((native_area & iris_area & ~valid).sum()),
              rawBounds=[p0.tolist(),p1.tolist()])
np.column_stack((x, y, covered, uv, view_depth, native_area, iris_area)).astype("<f4").tofile(
    run / "native-eye-overlay-footprint.bin")
(run / "native-eye-overlay-footprint.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report))
