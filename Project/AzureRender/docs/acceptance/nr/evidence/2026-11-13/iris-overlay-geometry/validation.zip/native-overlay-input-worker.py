from hashlib import sha256
from pathlib import Path
import json
import os
import struct
import traceback

import renderdoc as rd

folder = Path(os.environ["AZURE_NR_OVERLAY_REPLAY"])
request = json.loads((folder / "request.json").read_bytes())
capture = rd.OpenCaptureFile()
controller = None
report = dict(status="failed")
try:
    assert capture.OpenFile(request["native"], "", None) == rd.ResultCode.Succeeded
    options = rd.ReplayOptions()
    options.forceGPUVendor = rd.GPUVendor.nVidia
    options.forceGPUDeviceID = 0x28e0
    status, controller = capture.OpenCapture(options, None)
    assert status == rd.ResultCode.Succeeded and controller
    properties = controller.GetAPIProperties()
    assert properties.vendor == rd.GPUVendor.nVidia and not properties.degraded
    controller.SetFrameEvent(1245, True)
    state = controller.GetD3D11PipelineState()
    pipeline = controller.GetPipelineState()
    stage = rd.ShaderStage.Pixel
    reflection = pipeline.GetShaderReflection(stage)
    output = state.outputMerger
    depth = output.depthStencilState
    def stencil(face):
        return {key:str(getattr(face, key)) for key in
                ("function", "failOperation", "depthFailOperation", "passOperation", "reference", "compareMask", "writeMask")
                if hasattr(face, key)}
    report["depthStencil"] = dict(compare=str(depth.depthFunction), stencil=bool(depth.stencilEnable),
        front=stencil(depth.frontFace), back=stencil(depth.backFace))
    report["raster"] = dict(frontCCW=state.rasterizer.state.frontCCW,
                            cull=str(state.rasterizer.state.cullMode))
    report["constantBlocks"] = {}
    for index, block in enumerate(reflection.constantBlocks):
        bound = pipeline.GetConstantBlock(stage, index, 0).descriptor
        raw = bytes(controller.GetBufferData(bound.resource, bound.byteOffset, bound.byteSize))
        assert raw and len(raw)%16 == 0
        filename = f"cb{block.fixedBindNumber}.bin"
        (folder / filename).write_bytes(raw)
        report["constantBlocks"][block.fixedBindNumber] = dict(name=block.name, binding=str(bound.resource),
            offset=bound.byteOffset, size=len(raw), sha256=sha256(raw).hexdigest())
    report["textures"] = {}
    for entry in pipeline.GetReadOnlyResources(stage):
        binding = reflection.readOnlyResources[entry.access.index].fixedBindNumber
        descriptor = entry.descriptor
        row = dict(resource=str(descriptor.resource), format=descriptor.format.Name(),
                   firstMip=descriptor.firstMip, mipCount=descriptor.numMips)
        if binding == 3:
            meta, = [tex for tex in controller.GetTextures() if tex.resourceId == descriptor.resource]
            row.update(width=meta.width, height=meta.height, formatStored=meta.format.Name(), mips=meta.mips)
            for mip in range(meta.mips):
                raw = bytes(controller.GetTextureData(descriptor.resource, rd.Subresource(mip, 0, 0)))
                (folder / f"t3-mip{mip}.bin").write_bytes(raw)
        report["textures"][binding] = row
    report["samplers"] = {}
    for entry in pipeline.GetSamplers(stage):
        binding = reflection.samplers[entry.access.index].fixedBindNumber
        sampler = entry.sampler
        report["samplers"][binding] = dict(minify=str(sampler.filter.minify), magnify=str(sampler.filter.magnify),
            mip=str(sampler.filter.mip), address=[str(sampler.addressU),str(sampler.addressV)],
            anisotropy=sampler.maxAnisotropy, mipBias=sampler.mipBias)
    report["status"] = "qualified"
except Exception:
    report["error"] = traceback.format_exc()
finally:
    if controller:
        controller.Shutdown()
    capture.Shutdown()
    (folder / "results.json").write_text(json.dumps(report, indent=2) + "\n")
os._exit(0 if report["status"] == "qualified" else 1)
