from hashlib import sha256
from pathlib import Path
import json
import math
import os
import runpy
import sys

import numpy as np

run = Path(__file__).resolve().parent
sys.path.insert(0, str(run.parents[2] / "tools"))
from convert_material_semantics import read_asset
from endfield_native.postvs import read_postvs

main = Path("D:/Projects/FYP/Project/AzureRender/build/runs")
source = main / "20261103-234012-character-reference-stages-5abe6c/qualified-background-geometry-static"
postvs = main / "20261023-033116-postvs-linear-verification-591bef/postvs-1245/manifest.json"
source_level = Path("scene/static-qualified.azurelevel")
source_project = Path("qualified.azureproject")
source_model = Path("character/captured-opaque-overlays.glb")
folder = run / "iris-overlay-geometry-project"
material_name = "M_eyewhiteshadow_common_01"
asset_name = "native-eye-shadow"


def dump(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def geometry():
    replay = read_postvs(postvs)
    attributes, indices = replay["attributes"], replay["indices"]
    clip = attributes["SV_Position"].astype(np.float64)
    assert clip.shape == (36, 4) and indices.shape == (96,)
    assert np.isfinite(clip).all() and (clip[:, 3] > .1).all()
    camera = json.loads((run / "static-nvidia-frames/capture_manifest.json").read_bytes())
    origin = np.asarray(camera["qaCameraPosition"])
    forward = np.asarray(camera["qaCameraTarget"]) - origin
    forward /= np.linalg.norm(forward)
    right = np.cross(forward, camera["cameraUp"])
    right /= np.linalg.norm(right)
    up = np.cross(right, forward)
    lens = camera["cameraLens"]
    tan_y = math.tan(lens["verticalFovRadians"] * .5)
    tan_x = tan_y * 2560 / 1440
    shift_x, shift_y = lens["offsetNdc"]
    x, y, _, depth = clip.T
    world = (origin + np.outer(depth, forward)
             + np.outer((x - shift_x * depth) * tan_x, right)
             + np.outer((-y + shift_y * depth) * tan_y, up))
    translated = (attributes["TEXCOORD1"].astype(float) - [-300, 300, -300]) * [-1, 1, 1]
    assert np.abs(world - translated).max() < .0004
    delta = world.astype("<f4") - origin
    view_depth = delta @ forward
    restored = np.column_stack(((delta @ right) / tan_x + shift_x * view_depth,
                                -(delta @ up) / tan_y + shift_y * view_depth))
    residual = np.abs(restored / view_depth[:, None] - clip[:, :2] / depth[:, None]) * [1280, 720]
    assert residual.max() < .001
    tris = indices.reshape(-1, 3)
    corners = world[tris]
    normals = np.cross(corners[:, 1] - corners[:, 0], corners[:, 2] - corners[:, 0])
    back = (normals * (origin - corners[:, 0])).sum(axis=1) < 0
    # The captured left-handed world is reflected into the Player world.
    tris = tris[:, [0, 2, 1]]
    assert back.all()
    center = (clip[:, :2] / depth[:, None] + 1) * [1280, 720]
    receipt = dict(sourceEvent=replay["manifest"]["eid"], vertices=len(world), indices=len(indices),
                   sourceBuffers=replay["manifest"]["buffers"], projectedPixelBounds=[center.min(0).tolist(),
                   center.max(0).tolist()], maximumReprojectionErrorPixels=float(residual.max()))
    uv = attributes["TEXCOORD0"].copy()
    # The qualified overlay texture uses the exported glTF vertical axis.
    uv[:, 1] = 1 - uv[:, 1]
    receipt["textureV"] = "one-minus-native"
    return (world.astype("<f4"), uv.astype("<f4"),
            tris.reshape(-1).astype("<u2")), receipt


def model(arrays, material, image):
    blob = bytearray()
    views, accessors = [], []
    for data, component, kind, target in zip(arrays, (5126, 5126, 5123),
                                               ("VEC3", "VEC2", "SCALAR"), (34962, 34962, 34963)):
        views.append(dict(buffer=0, byteOffset=len(blob), byteLength=data.nbytes, target=target))
        accessors.append(dict(bufferView=len(views) - 1, componentType=component, count=len(data), type=kind))
        blob.extend(data.tobytes())
    accessors[0].update(min=arrays[0].min(0).tolist(), max=arrays[0].max(0).tolist())
    material["pbrMetallicRoughness"]["baseColorTexture"]["index"] = 0
    encoded = dict(asset=dict(version="2.0", generator="AzureRender native reference fixture"),
                   scene=0, scenes=[dict(nodes=[0])], nodes=[dict(name=asset_name, mesh=0)],
                   buffers=[dict(uri=asset_name + ".bin", byteLength=len(blob))],
                   bufferViews=views, accessors=accessors,
                   meshes=[dict(primitives=[dict(attributes=dict(POSITION=0, TEXCOORD_0=1),
                                                indices=2, material=0)])],
                   materials=[material], images=[image], textures=[dict(source=0)])
    return encoded, blob


def prepare(preflight):
    arrays, receipt = geometry()
    project = json.loads((source / source_project).read_bytes())
    level = json.loads((source / source_level).read_bytes())
    hero = next(node for node in level["nodes"] if node["id"] == "hero")
    overlay_slot = hero["materialSlots"]["name:" + material_name]
    original, _ = read_asset(source / source_model)
    eye_node, = [node for node in original["nodes"] if node["name"] == "S_actor_laevat_eyeshadow_01_lod0"]
    assert "mesh" not in eye_node and original["materials"][7]["name"] == material_name
    mat = original["materials"][7]
    tex = mat["pbrMetallicRoughness"]["baseColorTexture"]["index"]
    eye_image = original["images"][original["textures"][tex]["source"]]
    assert eye_image["uri"].startswith("data:image/png;base64,")
    document, payload = model(arrays, mat, eye_image)
    assets = {source_model, Path("character/native-stage-sphere.gltf"),
              Path("character/native-stage-sphere.bin"), Path("character/native-stage-flat-normal.png"),
              Path("character/native-empty-background.png"), Path("scene/cloth-captured-environment.azenv")}
    for item in original["images"]:
        uri = item.get("uri", "")
        if uri and not uri.startswith("data:"):
            assets.add(Path("character") / uri)
    by_id = {json.loads(path.read_bytes())["id"]: path.relative_to(source).with_suffix("")
             for path in source.rglob("*.azmeta") if ".azure" not in path.relative_to(source).parts}
    for identity in hero["materialSlots"].values():
        path = by_id[identity]
        assets.add(path)
        document_material = json.loads((source / path).read_bytes())
        assets.update(by_id[entry["asset"]] for entry in document_material["textures"].values())
    files = set(assets)
    for path in assets:
        sidecar = path.with_name(path.name + ".azmeta")
        if (source / sidecar).is_file():
            files.add(sidecar)
    origin_bytes = sum((source / path).stat().st_size for path in files)
    receipt.update(sourceProject=str(source / source_project), sourceLevel=str(source / source_level),
                   sourceMaterial=overlay_slot, linkedFiles=len(files), linkedBytes=origin_bytes,
                   maximumOutputBytes=3 * origin_bytes + 32 * 2**20,
                   overlayGeometrySha256=sha256(payload).hexdigest())
    if preflight:
        print(json.dumps(receipt))
        return
    import artifact_budget
    budget = artifact_budget.check(run.parents[1], run=run, planned=receipt["maximumOutputBytes"])
    assert budget["allowed"], budget
    folder.mkdir()
    for path in sorted(files):
        target = folder / path
        target.parent.mkdir(parents=True, exist_ok=True)
        assert (source / path).resolve(strict=True).is_relative_to(source.resolve())
        os.link(source / path, target)
    level["resources"].append(dict(id=asset_name, asset=f"character:/{asset_name}.gltf"))
    level["nodes"].append(dict(id=asset_name, resourceId=asset_name,
                               materialSlots={"name:" + material_name: overlay_slot}, components={}))
    dump(folder / source_level, level)
    dump(folder / source_project, project)
    dump(folder / f"character/{asset_name}.gltf", document)
    (folder / f"character/{asset_name}.bin").write_bytes(payload)
    dump(run / "iris-overlay-geometry-inputs.json", receipt)
    print(json.dumps(receipt))


if __name__ == "__main__":
    prepare(sys.argv[1:] == ["--preflight"])

