from hashlib import sha256
from pathlib import Path
import json

import numpy as np


run=Path(__file__).resolve().parent
prior=run/'next-body-native-primitive.py'
scope={'__file__':str(prior)}
exec(compile(prior.read_text().split('\nresults={}',1)[0],str(prior),'exec'),scope)
body,xy,points,screen,vertices,indices,clip=(scope[name] for name in ('body','xy','points','screen','vertices','indices','clip'))
owner_report=json.loads((run/'next-body-native-primitive.json').read_text())
selected_path=run/'next-body-native-primitive-nearest8.bin'
assert sha256(selected_path.read_bytes()).hexdigest()==owner_report['models']['nearest8']['selectedSha256']
selected=np.fromfile(selected_path,'<i4').reshape(9116,7)
assert np.array_equal(selected[:,:2],xy)
reliable=selected[:,4]<=1
tri=indices[selected[:,2]]
raster=(np.rint(screen*256)/256)[tri]
normal_frame=vertices[tri,9:16]
uv=vertices[tri,4:6]
inv_w=1/clip[tri,3]
a,b,c=raster[:,0],raster[:,1],raster[:,2]
ab,ac=b-a,c-a
det=ab[:,0]*ac[:,1]-ab[:,1]*ac[:,0]
assert np.all(np.abs(det)>1.e-12)
face=np.where(det<0,1.,-1.)
reference=np.column_stack((body[:,8]&1023,(body[:,8]>>10)&1023)).astype('i4')


def interpolate(at,attrib):
    p=at-a
    u=(p[:,0]*ac[:,1]-p[:,1]*ac[:,0])/det
    v=(ab[:,0]*p[:,1]-ab[:,1]*p[:,0])/det
    weight=np.stack((1-u-v,u,v),axis=1)*inv_w
    return np.sum(weight[...,None]*attrib,axis=1)/weight.sum(axis=1)[:,None]


frame=interpolate(points,normal_frame)
normal,tangent,sign=frame[:,:3],frame[:,3:6],frame[:,6:7]
bitangent=np.cross(normal,tangent)*sign
coordinates=interpolate(points,uv)
quad=(xy&~1)+.5
quv=[interpolate(quad+step,uv) for step in ((0,0),(1,0),(0,1),(1,1))]
dx=(quv[1]-quv[0])*1024
dy=(quv[2]-quv[0])*1024
dds=run.parent/'20261112-182312-projected-hair-point-mip-82adc1/hair-project/character/native-captured-body/t15.dds'
raw=dds.read_bytes()
assert sha256(raw).hexdigest()=='3d16ddcced1a4f482f969250b835c5ea569ce620d8ef16cc465fc19cbb266a9e'
assert raw[84:88]==b'ATI2'


def decode(blocks,width,decode_mode):
    count=max(1,(width+3)//4)
    block=np.frombuffer(blocks,'u1').reshape(count,count,2,8)
    first,second=(block[...,k].astype('f8') for k in (0,1))
    long=first>second
    values=[first,second]
    for key in range(2,8):
        many=((8-key)*first+(key-1)*second)/7
        few=((6-key)*first+(key-1)*second)/5 if key<6 else (0 if key==6 else 255)
        values.append(np.where(long,many,few))
    table=np.stack(values,axis=-1)
    encoded=np.sum(block[...,2:].astype('u8') << (8*np.arange(6,dtype='u8')),axis=-1)
    index=((encoded[...,None]>>(3*np.arange(16,dtype='u8')))&7).astype('i4')
    samples=np.take_along_axis(table,index,axis=-1).reshape(count,count,2,4,4)
    result=samples.transpose(0,3,1,4,2).reshape(count*4,count*4,2)[:width,:width]
    if decode_mode=='fractional':
        return result
    rounded=np.rint(result)
    if decode_mode=='rounded':
        return rounded
    xy=rounded.astype('f4')/np.float32(255)*np.float32(2)-np.float32(1)
    length=np.sqrt(np.sum(xy*xy,axis=2))
    clipped=length>1
    xy[clipped]/=length[clipped,None]
    rounded[clipped]=np.floor((xy[clipped]*np.float32(.5)+np.float32(.5))*np.float32(255)+np.float32(.5))
    return rounded


def sample(tex,precision):
    width=len(tex)
    pos=coordinates*width-.5
    lower=np.floor(pos)
    f=pos-lower
    if precision:
        f=np.rint(f*precision)/precision
    i=lower.astype('i8')
    x0,y0=(i%width).T
    x1,y1=((i+1)%width).T
    fx,fy=f[:,0:1],f[:,1:2]
    return (tex[y0,x0]*(1-fx)+tex[y0,x1]*fx)*(1-fy)+(tex[y1,x0]*(1-fx)+tex[y1,x1]*fx)*fy


def pack(encoded,orientation):
    nxy=encoded*(2/255)-1
    nz=np.sqrt(np.maximum(1-np.sum(nxy*nxy,axis=1),0))
    basis=bitangent*nxy[:,1,None]+tangent*nxy[:,0,None]+normal*nz[:,None]
    basis*=orientation[:,None]
    oct=basis[:,[0,2]]/np.abs(basis).sum(axis=1)[:,None]
    folded=(1-np.abs(oct[:,::-1]))*np.where(oct>=0,1.,-1.)
    quantized=np.where(basis[:,1:2]<=0,folded,oct)*.5+.5
    return np.rint(np.clip(quantized,0,1)*1023).astype('i4')


def footprint(v):
    absolute=np.abs(v)
    return absolute.max(axis=1)+11/32*absolute.min(axis=1)


mips={
    'axis-euclidean':np.maximum(np.linalg.norm(dx,axis=1),np.linalg.norm(dy,axis=1)),
    'axis-diagonal':np.maximum(np.maximum(footprint(dx),footprint(dy)),11/16*np.maximum(footprint(dx+dy),footprint(dx-dy))),
}
mips={name:np.clip(np.floor(np.log2(rho)-.5),0,10).astype('i4') for name,rho in mips.items()}
result=dict(samples=len(body),depthWithinOneUlp=int(reliable.sum()),options={})
focus_coords=((1235,1072),(1334,1014),(1332,1012),(1254,1089),(1308,1080))
for decode_mode in ('fractional','rounded','renderer-normal-rgba8'):
    for precision in (0,256):
        for orientation in ('front-ccw','front-cw'):
            options=[]
            offset=128
            for level in range(11):
                width=max(1,1024>>level)
                length=max(1,(width+3)//4)**2*16
                decoded=decode(raw[offset:offset+length],width,decode_mode)
                offset+=length
                options.append(pack(sample(decoded,precision),face if orientation=='front-ccw' else -face))
            assert offset==len(raw)
            options=np.stack(options)
            errors=np.abs(options-reference[None]).max(axis=2)
            best=errors.min(axis=0)
            key=f'{decode_mode}-subtexel-{precision}-{orientation}'
            comparisons={}
            for label,selected_mip in mips.items():
                predicted=errors[selected_mip,np.arange(len(body))]
                comparisons[label]=dict(exact=int((reliable&(predicted==0)).sum()),
                    withinOne=int((reliable&(predicted<=1)).sum()),
                    maximum=int(predicted[reliable].max()))
            result['options'][key]=dict(anyMipExact=int((reliable&(best==0)).sum()),
                anyMipWithinOne=int((reliable&(best<=1)).sum()),hypotheses=comparisons)
            if orientation=='front-ccw':
                focus={}
                for x,y in focus_coords:
                    pos,=np.flatnonzero(np.all(xy==[x,y],axis=1))
                    focus[f'{x},{y}']=dict(depthUlp=int(selected[pos,4]),native=reference[pos].tolist(),
                        lowestErrors=errors[:,pos].tolist(),selectedLods={name:int(rows[pos]) for name,rows in mips.items()})
                result['options'][key]['focus']=focus
clipping={}
offset=128
for level in range(11):
    width=max(1,1024>>level)
    length=max(1,(width+3)//4)**2*16
    blocks=raw[offset:offset+length]
    offset+=length
    original=decode(blocks,width,'rounded')
    adjusted=decode(blocks,width,'renderer-normal-rgba8')
    maximum=np.abs(original-adjusted).max(axis=2)
    clipping[level]=dict(texels=int(maximum.size),changed=int((maximum>0).sum()),maximum=int(maximum.max()))
result['textureRadialClipping']=clipping
(run/'next-body-normal-decoder-model.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(radialClipping=clipping,comparison={key:{k:v for k,v in data.items() if k!='focus'}
    for key,data in result['options'].items() if 'subtexel-256-front-ccw' in key})))

