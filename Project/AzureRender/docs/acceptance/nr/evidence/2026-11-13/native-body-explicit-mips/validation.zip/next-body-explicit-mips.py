from hashlib import file_digest
from pathlib import Path
import ast
import json
import os
import struct
import subprocess
import sys

import numpy as np


scripts=Path(__file__).resolve().parent
out=Path(sys.argv[1]).resolve(strict=True)
preflight='--preflight' in sys.argv
worker=scripts/'next-body-explicit-mips-worker.py'
renderdoc=Path('D:/Tools/RenderDoc/1.46/RenderDoc_1.46_64/qrenderdoc.exe')
capture=Path('D:/Projects/FYP/Project/AzureRender/build/runs/20261022-201845-endfield-capture-954719/Endfield-games-child_frame10401.rdc')
capture_sha='fa2ca267f7168f5603e83ad5f817a3074d8dbee23a216e6ab8ef2c340ec06a90'
utilities=scripts.parent/'20261112-053111-intel-reference-visibility-sources-5238e2/native-normal-explicit-mips'
native=scripts.parent/'20261112-072016-native-receiver-producer-replay-523058/native-caster-geometry'
body=scripts.parent/'20261112-213454-reference-raster-source-a825da/body'


def digest(path):
    with path.open('rb') as file:
        return file_digest(file,'sha256').hexdigest()


assert digest(capture)==capture_sha
record=json.loads((native/'native-caster-geometry.json').read_text())['receiverDraws']['328']['pixel']['program']
bytecode=(native/record['path']).read_bytes()
assert digest(native/record['path'])==record['sha256']
sys.path.insert(0,str(utilities))
import dxbc_util
context=dict(vars(dxbc_util),struct=struct)
module=ast.parse(worker.read_text())
method,=[node for node in module.body if isinstance(node,ast.FunctionDef) and node.name=='with_level']
exec(compile(ast.Module(body=[method],type_ignores=[]),str(worker),'exec'),context)
candidates=[context['with_level'](bytecode,level) for level in range(11)]
assert len(set(candidates))==11 and all(dxbc_util.checksum(data)==data[4:20] for data in candidates)
data=np.fromfile(body/'nvidia-receiver.bin','<u4').reshape(49384,9)
points=data[data[:,7]==328,:2]
assert len(points)==9116
if preflight:
    print(json.dumps(dict(captureSha256=capture_sha,rawShaderSha256=record['sha256'],qualifiedOfflineOpcodes=len(candidates),
        workerSha256=digest(worker),points=len(points))))
    raise SystemExit(0)
folder=out/'body-explicit-mips'
folder.mkdir()
points_path=folder/'points.bin'
points.astype('<u4').tofile(points_path)
request=folder/'request.json'
request.write_text(json.dumps(dict(output=str(folder),capture=str(capture),captureSha256=capture_sha,
    pixelShaderSha256=record['sha256'],utilities=str(utilities),points=str(points_path)),indent=2)+'\n')
command=[str(renderdoc),'--python',str(worker)]
(folder/'command.json').write_text(json.dumps(command,indent=2)+'\n')
env=os.environ.copy()
for name in ('VK_INSTANCE_LAYERS','VK_LAYER_PATH','ENABLE_VULKAN_RENDERDOC_CAPTURE',
    'VK_LOADER_DRIVERS_SELECT','VK_DRIVER_FILES','VK_ICD_FILENAMES'):
    env.pop(name,None)
env['AZURE_BODY_NORMAL_MIP_REQUEST']=str(request)
startup=subprocess.STARTUPINFO()
startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
startup.wShowWindow=0
with (folder/'process.log').open('wb') as log:
    process=subprocess.run(command,cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT,
        startupinfo=startup,timeout=240)
actual=json.loads((folder/'body-explicit-mips.json').read_text())
assert process.returncode==0 and actual['status']=='qualified',actual
assert digest(capture)==capture_sha
print(json.dumps({device:row['implicitSha256'] for device,row in actual['devices'].items()}))

