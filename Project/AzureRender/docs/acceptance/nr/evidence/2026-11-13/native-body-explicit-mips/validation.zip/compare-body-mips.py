from hashlib import sha256
from pathlib import Path
import json

import numpy as np

run = Path(__file__).resolve().parent
parent = run.parent / "20261112-231945-projected-hair-reference-grid-4b775d"
raw = run / "body-explicit-mips"
receipt = json.loads((raw / "body-explicit-mips.json").read_text())
assert receipt["status"] == "qualified"
model_script = parent / "next-body-normal-decoder-model.py"
model = {"__file__": str(model_script)}
prefix, separator, _ = model_script.read_text().partition("\nresult=dict(samples=")
assert separator
exec(compile(prefix, str(model_script), "exec"), model)
expected_coords = model["xy"]
assert np.array_equal(np.fromfile(raw / "points.bin", "<u4").reshape(-1, 2), expected_coords)
reliable = model["reliable"]
assert int(reliable.sum()) == 7997

def load_words(path, expected_hash):
    data = path.read_bytes()
    assert sha256(data).hexdigest() == expected_hash and len(data) == 9116 * 4
    return np.frombuffer(data, "<u4")

def pack_rg10(words):
    return np.column_stack((words & 1023, (words >> 10) & 1023)).astype(np.int32)

def score(errors):
    return dict(exact=int((errors == 0).sum()), withinOne=int((errors <= 1).sum()), maximum=int(errors.max()))

report = dict(regions=dict(total=9116, depthWithinOneUlp=int(reliable.sum())), devices={})
models = {}
dds = model["raw"]
for decode_mode in ("rounded", "fractional"):
    offset = 128
    outputs = []
    for level in range(11):
        width = 1024 >> level
        length = max(1, (width+3)//4)**2 * 16
        decoded = model["decode"](dds[offset:offset+length], width, decode_mode)
        sampled = model["sample"](decoded, 256)
        outputs.append(model["pack"](sampled, model["face"]))
        offset += length
    assert offset == len(dds)
    models[decode_mode] = np.stack(outputs)

device_words = {}
for device, evidence in receipt["devices"].items():
    assert evidence["copyControlExact"] and evidence["baselineRestored"] and len(evidence["mips"]) == 11
    implicit_words = load_words(raw / f"{device}-implicit.bin", evidence["implicitSha256"])
    explicit_words = np.stack([
        load_words(raw / f"{device}-mip-{level:02d}.bin", evidence["mips"][str(level)]["sha256"])
        for level in range(11)
    ])
    device_words[device] = implicit_words, explicit_words
    implicit = pack_rg10(implicit_words)
    explicit = np.stack([pack_rg10(level) for level in explicit_words])
    errors = np.abs(explicit - implicit[None]).max(axis=2)
    exact = errors == 0
    best = errors.min(axis=0)
    match_count = exact.sum(axis=0)
    chosen = {
        name: score(errors[levels, np.arange(len(implicit))][reliable])
        for name, levels in model["mips"].items()
    }
    per_level = {
        name: [score(np.abs(expected - sampled).max(axis=1)[reliable])
               for expected, sampled in zip(explicit, predictions)]
        for name, predictions in models.items()
    }
    reference_errors = np.abs(implicit - model["reference"]).max(axis=1)
    report["devices"][device] = dict(copyControlExact=True, baselineRestored=True,
        implicitVsFrozenReceiver=score(reference_errors), anyExplicitMip=score(best[reliable]),
        uniqueExplicitMip=int((reliable & (match_count == 1)).sum()),
        ambiguousExplicitMip=int((reliable & (match_count > 1)).sum()),
        implicitLodHypotheses=chosen, cpuPredictionsAgainstActualMip=per_level)

nv, intel = (device_words[device] for device in ("nvidia", "intel"))
report["crossDevice"] = dict(
    implicitDifferent=int((nv[0] != intel[0]).sum()),
    explicitDifferentPerLevel=np.count_nonzero(nv[1] != intel[1], axis=1).tolist()
)
(run / "body-mip-comparison.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({device: {k: v for k, v in row.items() if k != "cpuPredictionsAgainstActualMip"}
                  for device, row in report["devices"].items()}))
print(json.dumps(report["crossDevice"]))