from pathlib import Path
from hashlib import sha256
from uuid import UUID, uuid5
import json, os, re, runpy, subprocess, sys

run=Path(__file__).resolve().parent
capture=runpy.run_path(str(run/"capture-iris-overlay-geometry.py"))
build=capture["build"]
project=capture["folder"]
out=run/"iris-production-captures"
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(p,d):
    with p.open("x",encoding="utf8") as stream:
        json.dump(d,stream,indent=2)
        stream.write("\n")

def create_project():
    material=read(project/"materials/native-eye-shadow-authored-tint.azurematerial")
    composite=material["surface"]["materials"][0]["extras"]["azureRenderMaterial"]["composite"]
    composite.update(receiver="eye",coverageScale=.95)
    uid=str(uuid5(UUID("488e714f-3f2e-4514-92f9-781a5beed58f"),"production-eye-overlay"))
    path=project/"materials/native-eye-shadow-production.azurematerial"
    dump(path,material)
    dump(path.with_suffix(".azurematerial.azmeta"),dict(schemaVersion=1,id=uid,dependencies=[],settings={}))
    level=read(project/"scene/static-eye-shadow-authored-tint.azurelevel")
    node=next(node for node in level["nodes"] if node["id"]=="native-eye-shadow")
    node["materialSlots"]["name:M_eyewhiteshadow_common_01"]=uid
    dump(project/"scene/static-eye-shadow-production.azurelevel",level)
    document=read(project/"eye-shadow-authored-tint.azureproject")
    document["startupScene"]="stage:/static-eye-shadow-production.azurelevel"
    dump(project/"eye-shadow-production.azureproject",document)

def invoke(device,command,output):
    env=os.environ.copy()
    for key in ("VK_DRIVER_FILES","VK_ICD_FILENAMES","VK_LAYER_ENABLES","VK_LOADER_DRIVERS_SELECT"):
        env.pop(key,None)
    env.update(VK_INSTANCE_LAYERS="VK_LAYER_KHRONOS_validation",VK_LAYER_VALIDATE_SYNC="1")
    if device=="nvidia":
        env["VK_DRIVER_FILES"]=str(run/"nv-vk64-active-absolute.json")
        assert Path(env["VK_DRIVER_FILES"]).is_file()
        env["VK_LOADER_DEBUG"]="error,warn,driver"
    else:
        env["VK_LOADER_DRIVERS_SELECT"]="*igvk64*"
    dump(output/"command.json",command)
    with (output/"player.log").open("wb") as log:
        child=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    log=(output/"player.log").read_text(errors="replace")
    assert child.returncode==0 and "Allocator after unload: buffers=0 images=0" in log,log[-5000:]
    assert not re.search(r"VUID-|SYNC-HAZARD|Validation (?:Error|Warning)|\[error\]",log,re.I),log[-5000:]
    frames=Path(command[command.index("--capture-dir")+1])
    assert read(frames/"gpu_capabilities.json")["vendor_id"]==(0x10de if device=="nvidia" else 0x8086)
    return frames

def candidate():
    capture["compare"].__globals__["target"]=out
    for device in ("intel","nvidia"):
        for mode in ("disabled","enabled"):
            folder=out/f"{device}-{mode}"
            folder.mkdir()
            command=read(run/f"static-{device}-command.json")
            command[command.index("--project")+1]=str(project/"eye-shadow-production.azureproject")
            command[command.index("--capture-dir")+1]=str(folder/"frames")
            if mode=="disabled":
                command.extend(("--qa-effect","overlay","--qa-effect-state","disabled"))
            invoke(device,command,folder)
        capture["compare"](device)

def frozen():
    folder=out/"frozen-four"
    folder.mkdir()
    command=read(run/"default-four-command.json")
    command[command.index("--capture-dir")+1]=str(folder/"frames")
    command[command.index("--runtime-report")+1]=str(folder/"runtime.json")
    frames=invoke("nvidia",command,folder)
    expected=[row["expectedSha256"] for row in read(run/"default-four-results.json")["frames"]]
    actual=[digest(path) for path in sorted(frames.glob("frame_*.png"))]
    dump(folder/"results.json",dict(expected=expected,actual=actual,exact=actual==expected))
    assert actual==expected

if __name__=="__main__":
    state=read(Path("D:/Projects/FYP-coordination/resources/current.json"))
    assert state["state"]=="held" and Path(state["output"])==run
    verified=read(run/"iris-production-catalog.json")
    assert digest(build/"AzurePlayer.exe")==verified["playerSha256"]
    assert all(digest(build/"shaders"/name)==sha for name,sha in verified["shaders"].items())
    out=run/"iris-production-frozen-recovery"
    out.mkdir()
    frozen()
