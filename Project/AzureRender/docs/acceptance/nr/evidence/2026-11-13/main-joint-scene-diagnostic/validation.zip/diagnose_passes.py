from pathlib import Path
import csv
import json
import os
import subprocess
import sys
import time
import zipfile

import numpy as np

root = Path.cwd().resolve()
out = Path(__file__).resolve().parent / 'passes'
out.mkdir(exist_ok=True)
sys.path.insert(0, str(root / 'tools'))
from build_provenance import digest, verify
from gpu_environment import RunEnvironmentMonitor, environment_errors, wait_and_record
from run_playable_performance import memory_snapshot

def write(name, result):
    (out / name).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def check_inputs(manifest):
    for file, expected in manifest.items():
        assert digest(Path(file)) == expected, file

def stats(values):
    return dict(samples=len(values), mean=float(np.mean(values)), p95=float(np.percentile(values, 95)),
                maximum=float(np.max(values)))

archive = root / 'docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope/validation.zip'
with zipfile.ZipFile(archive) as evidence:
    frozen_inputs = json.loads(evidence.read('run/frozen-project-inputs.json'))
    reference = json.loads(evidence.read('run/diagnostic-1080p60/command.json'))['command']
assert len(frozen_inputs) == 1729
assert '--fixed-frame-step' in reference and reference[reference.index('--capture-fps') + 1] == '60'
assert reference[reference.index('--width') + 1] == '1920' and reference[reference.index('--height') + 1] == '1080'
proof_path = root / 'build/runs/20261113-005205-nr-main-registered-regression-c82feb/release-products.json'
proof = json.loads(proof_path.read_bytes())
assert proof['commit'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
subprocess.run(['git', 'merge-base', '--is-ancestor', '01cc6b2', proof['commit']], check=True)
verify(root, proof)
check_inputs(frozen_inputs)
build = root / 'build/ninja-msvc-release'
dlls = {str(p.resolve()): digest(p) for p in sorted(build.glob('*.dll'))}
assert Path(reference[0]).resolve() == (build / 'AzurePlayer.exe').resolve()

os.environ['PATH'] = str(build) + os.pathsep + os.environ['PATH']
os.environ['VK_LOADER_DRIVERS_SELECT'] = '*nv-vk64*'
os.environ['DOTNET_ROOT'] = 'D:/Tools/dotnet9'
for key in ('VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_INSTANCE_LAYERS', 'VK_LAYER_VALIDATE_SYNC',
            'VK_LOADER_DEBUG', 'VK_LAYER_ENABLES', 'AZURE_CPU_WORK_REPORT',
            'AZURERENDER_RESOURCE_ROOT', 'AZURE_DISABLE_COMPUTED_MATERIAL_VIEW'):
    os.environ.pop(key, None)

timing = out / 'timing.json'
warmup, samples = 300, 120
command = [*reference, '--gpu-pass-timing']
command[command.index('--smoke-frames') + 1] = str(warmup + samples)
command[command.index('--gpu-timing-output') + 1] = str(timing)
write('command.json', dict(command=command, buildReceiptSha256=digest(proof_path), dlls=dlls,
                           projectInputs=len(frozen_inputs), archivedInputSource=str(archive)))
env_path = out / 'environment.json'
environment = wait_and_record(env_path, timeout=90)
memory = []
start = time.monotonic()
with RunEnvironmentMonitor(environment, path=env_path, interval=2), (out / 'player.log').open('wb') as log:
    player = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
    try:
        while player.poll() is None:
            try:
                memory.append(dict(seconds=time.monotonic()-start, **memory_snapshot(player.pid)))
            except OSError:
                if player.poll() is not None:
                    break
                raise
            if time.monotonic() - start > 420:
                raise TimeoutError(command)
            time.sleep(.1)
    finally:
        if player.poll() is None:
            player.kill()
            player.wait()
        write('memory-observations.json', memory)

assert player.returncode == 0
data = json.loads(timing.read_bytes())
assert (data['sceneWidth'], data['sceneHeight']) == (1920, 1080)
assert data['computedMaterialViewPipelines'] == 0 and data['computedMaterialViewSelectionsTotal'] == 0
assert 'Allocator after unload: buffers=0 images=0' in (out / 'player.log').read_text(encoding='utf-8', errors='replace')
with timing.with_suffix('.csv').open(encoding='utf-8') as f:
    records = [record for record in csv.DictReader(f) if warmup < int(record['frame']) <= warmup+samples]
assert len(records) == samples and len(data['cpuFrame']['workSamplesMs']) == warmup+samples
breakdown = {field: stats([float(row[field]) for row in records])
             for field in ('frameMs', 'sceneMs', 'shadowMs', 'postProcessMs')}
breakdown['cpuWorkMs'] = stats(data['cpuFrame']['workSamplesMs'][warmup:])
pass_times = {}
with timing.with_suffix('.passes.jsonl').open(encoding='utf-8') as stream:
    for line in stream:
        frame = json.loads(line)
        if not warmup < frame['frame'] <= warmup + samples:
            continue
        for result in frame['passes']:
            if result.get('available'):
                pass_times.setdefault(result['name'], []).append(float(result['milliseconds']))
assert len(pass_times.get('character-opaque-depth', [])) == samples
pass_stats = {name: stats(values) for name, values in pass_times.items()}
verify(root, proof)
check_inputs(dlls)
check_inputs(frozen_inputs)
observed = environment['startup'] + environment['runObservations']
watts = sorted({x['powerLimitWatts'] for x in observed if x['powerLimitWatts'] is not None})
write('results.json', dict(scope='standard-main-1080p60-diagnostic', source=proof['commit'],
                            warmupFrames=warmup, measuredFrames=samples, timings=breakdown, passTimings=pass_stats,
                            peakWorkingSetBytes=max(x['peak'] for x in memory),
                            deviceLocalPeakBytes=data['allocator']['deviceLocalPeakBytes'],
                            fixed80Observed=watts == [80.0] and all(x['powerLimitWatts'] is not None for x in observed),
                            observedWatts=watts, environmentErrors=environment_errors(environment),
                            allocatorZero=True, formalAcceptance=False))
