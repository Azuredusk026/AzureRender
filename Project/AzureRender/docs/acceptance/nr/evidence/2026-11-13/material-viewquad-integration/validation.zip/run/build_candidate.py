from pathlib import Path
import json
import os
import subprocess
import sys

root=Path.cwd().resolve()
out=Path(__file__).resolve().parent
build=root/'build/catalog-computed'
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest, inputs, verify

head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head.startswith('01cc6b2') and not subprocess.check_output(['git','status','--porcelain'])
cache=(build/'CMakeCache.txt').read_text(encoding='utf-8')
assert 'AZURE_ENABLE_COMPUTED_MATERIAL_VIEW:BOOL=ON' in cache and 'CMAKE_BUILD_TYPE:STRING=Release' in cache
env=dict(os.environ,VCPKG_ROOT='D:/Tools/vcpkg',VULKAN_SDK='D:/Tools/VulkanSDK/1.4.350.0',
         DOTNET_ROOT='D:/Tools/dotnet9',CMAKE_BUILD_PARALLEL_LEVEL='3',VCPKG_BINARY_SOURCES='clear',
         VCPKG_DOWNLOADS='D:/Tools/vcpkg/downloads')
env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
before=inputs(root)
with (out/'build.log').open('wb') as log:
    subprocess.run([str(root/'tools/msvc_env.bat'),'cmake','--build',str(build),'--config','Release',
                    '--target','AzurePlayer'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
manifest=json.loads((build/'shader-reload.json').read_bytes())
programs={row['output'] for row in manifest['programs']}
assert len(programs)==len(manifest['programs'])==manifest['maximumPrograms']==1024
spv=sorted((build/'shaders').glob('*.spv'))
assert {file.name for file in spv}==programs
files=[build/'AzurePlayer.exe',*sorted(build.glob('*.dll')),*spv]
assert before==inputs(root)
receipt=dict(schemaVersion=1,commit=head,configuration='Release',source=before,
             products={str(file.resolve()):digest(file) for file in files},activePrograms=len(programs))
verify(root,receipt)
(out/'candidate-products.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(commit=head,activePrograms=len(programs),products=len(files),
                      hostSha256=digest(build/'AzurePlayer.exe'))))
