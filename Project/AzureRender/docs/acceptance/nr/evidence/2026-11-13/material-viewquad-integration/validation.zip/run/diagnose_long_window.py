from pathlib import Path
import csv
import json
import os
import subprocess
import sys
import time
import zipfile

import numpy as np

root=Path.cwd().resolve()
run=Path(__file__).resolve().parent
out=run/'long-window'
main=Path('D:/Projects/FYP/Project/AzureRender')
build=root/'build/catalog-computed'
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest,verify
from gpu_environment import wait_and_record,RunEnvironmentMonitor,environment_errors
from run_playable_performance import memory_snapshot

def read(p):
    return json.loads(p.read_bytes())

def write(name,data):
    (out/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')

def stats(x):
    return dict(samples=len(x),mean=float(np.mean(x)),p95=float(np.percentile(x,95)),maximum=float(np.max(x)))

paired=read(run/'cost-results.json')
assert paired['originalFourExact'] and paired['shortEnvironmentQualified'] and all(paired['criteria'].values())
assert paired['rows'][1]['gpu']['p95']<=16.6 and paired['rows'][1]['cpu']['p95']<=8
proof=read(run/'candidate-products.json')
verify(root,proof)
archive=main/'docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope/validation.zip'
with zipfile.ZipFile(archive) as z:
    locked=json.loads(z.read('run/frozen-project-inputs.json'))
    command=json.loads(z.read('run/diagnostic-1080p60/command.json'))['command']
assert len(locked)==1729
def check_inputs():
    assert all(digest(Path(path))==sha for path,sha in locked.items())
check_inputs()
out.mkdir()
timing=out/'timing.json'
command[0]=str(build/'AzurePlayer.exe')
command[command.index('--resource-root')+1]=str(build)
command[command.index('--gpu-timing-output')+1]=str(timing)
assert command[command.index('--smoke-frames')+1]=='2100'
assert command[command.index('--capture-fps')+1]=='60'
os.environ['PATH']=os.pathsep.join(map(str,(build,main/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin',os.environ['PATH'])))
os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',DOTNET_ROOT='D:/Tools/dotnet9')
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC','VK_LOADER_DEBUG',
            'VK_LAYER_ENABLES','AZURE_CPU_WORK_REPORT','AZURERENDER_RESOURCE_ROOT','AZURE_DISABLE_COMPUTED_MATERIAL_VIEW'):
    os.environ.pop(key,None)
write('command.json',dict(command=command,source=proof['commit'],productReceiptSha256=digest(run/'candidate-products.json')))
path=out/'environment.json'
environment=wait_and_record(path,timeout=90)
memory=[]
start=time.monotonic()
with RunEnvironmentMonitor(environment,path=path,interval=2),(out/'player.log').open('wb') as log:
    player=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
    try:
        while player.poll() is None:
            try:
                memory.append(dict(seconds=time.monotonic()-start,**memory_snapshot(player.pid)))
            except OSError:
                if player.poll() is not None:
                    break
                raise
            if time.monotonic()-start>600:
                raise TimeoutError(command)
            time.sleep(.1)
    finally:
        if player.poll() is None:
            player.kill()
            player.wait()
        write('memory-observations.json',memory)
assert player.returncode==0
log=(out/'player.log').read_text(encoding='utf-8',errors='replace')
assert 'Allocator after unload: buffers=0 images=0' in log and 'VUID-' not in log
data=read(timing)
assert (data['sceneWidth'],data['sceneHeight'])==(1920,1080)
assert data['computedMaterialViewPipelines']>0 and data['computedMaterialViewSelectionsTotal']>0
assert data['computedMaterialViewFrameEligible'] and data['computedMaterialViewFallback']=='ready'
with timing.with_suffix('.csv').open(encoding='utf-8') as stream:
    rows=[r for r in csv.DictReader(stream) if 300<int(r['frame'])<=2100]
cpu=data['cpuFrame']['workSamplesMs']
assert len(rows)==1800 and len(cpu)==2100
def distribution(start,end):
    window=rows[start:end]
    result={name:stats([float(r[name]) for r in window]) for name in ('frameMs','sceneMs','shadowMs','postProcessMs')}
    result['cpuWorkMs']=stats(cpu[300+start:300+end])
    return result
overall=distribution(0,1800)
periods=[dict(firstFrame=301+i,lastFrame=600+i,measurements=distribution(i,i+300)) for i in range(0,1800,300)]
observations=environment['startup']+environment['runObservations']
power=sorted({x['powerLimitWatts'] for x in observations if x['powerLimitWatts'] is not None})
fixed=power==[80.0] and all(x['powerLimitWatts'] is not None for x in observations)
errors=environment_errors(environment)
verify(root,proof)
check_inputs()
write('results.json',dict(scope='isolated-opt-in-1080p60-diagnostic',source=proof['commit'],warmupFrames=300,
    measuredFrames=1800,seconds=time.monotonic()-start,timings=overall,windows=periods,observedWatts=power,
    fixed80Observed=fixed,environmentErrors=errors,peakWorkingSetBytes=max(m['peak'] for m in memory),
    deviceLocalPeakBytes=data['allocator']['deviceLocalPeakBytes'],allocatorZero=True,
    cpuBudgetMet=overall['cpuWorkMs']['p95']<=8,gpuBudgetMet=overall['frameMs']['p95']<=16.6,
    formalAcceptance=False))
