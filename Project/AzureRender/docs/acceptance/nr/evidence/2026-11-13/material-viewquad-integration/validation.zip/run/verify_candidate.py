from pathlib import Path
import csv
import json
import os
import subprocess
import sys
import time
import zipfile

import numpy as np

root=Path.cwd().resolve()
out=Path(__file__).resolve().parent
build=root/'build/catalog-computed'
main=Path('D:/Projects/FYP/Project/AzureRender')
prior=main/'docs/acceptance/nr/evidence/2026-11-11/material-viewquad-pipeline-scope'
sys.path.insert(0,str(root/'tools'))
from build_provenance import digest, verify
from gpu_environment import wait_and_record, RunEnvironmentMonitor, environment_errors

def write(path, document):
    path.write_text(json.dumps(document,indent=2)+'\n',encoding='utf-8')

def run(command,folder,enabled,timeout):
    env=dict(os.environ)
    if not enabled:
        env['AZURE_DISABLE_COMPUTED_MATERIAL_VIEW']='1'
    else:
        env.pop('AZURE_DISABLE_COMPUTED_MATERIAL_VIEW',None)
    env_path=folder/'environment.json'
    environment=wait_and_record(env_path,timeout=90)
    write(folder/'command.json',dict(command=command,enabled=enabled,productReceiptSha256=digest(out/'candidate-products.json')))
    start=time.monotonic()
    with RunEnvironmentMonitor(environment,path=env_path,interval=2), (folder/'player.log').open('wb') as log:
        subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=timeout)
    log=(folder/'player.log').read_text(encoding='utf-8',errors='replace')
    assert 'Allocator after unload: buffers=0 images=0' in log and 'VUID-' not in log
    return environment,time.monotonic()-start

def stats(values):
    return dict(mean=float(np.mean(values)),p95=float(np.percentile(values,95)))

proof=json.loads((out/'candidate-products.json').read_bytes())
verify(root,proof)
with zipfile.ZipFile(prior/'validation.zip') as z:
    locked=json.loads(z.read('run/frozen-project-inputs.json'))
    capture_command=json.loads(z.read('run/capture-command.json'))['command']
    timing_template=json.loads(z.read('run/cost-before/command.json'))['command']
expected=json.loads((prior/'results.json').read_bytes())['originalFour']['frames']
assert len(locked)==1729 and len(expected)==4

def check_project():
    assert all(digest(Path(name))==sha for name,sha in locked.items())

check_project()
exe=build/'AzurePlayer.exe'
os.environ['PATH']=os.pathsep.join(map(str,(build,main/'build/ninja-msvc-debug/vcpkg_installed/x64-windows/bin',os.environ['PATH'])))
os.environ.update(VK_LOADER_DRIVERS_SELECT='*nv-vk64*',DOTNET_ROOT='D:/Tools/dotnet9')
for key in ('VK_DRIVER_FILES','VK_ICD_FILENAMES','VK_INSTANCE_LAYERS','VK_LAYER_VALIDATE_SYNC',
            'VK_LOADER_DEBUG','VK_LAYER_ENABLES','AZURE_CPU_WORK_REPORT','AZURERENDER_RESOURCE_ROOT'):
    os.environ.pop(key,None)
assert '--resource-root' not in capture_command
capture_command[0]=str(exe)
capture_command+=['--resource-root',str(build)]
capture=out/'original-four'
capture.mkdir()
for flag,path in (('--capture-dir',capture/'frames'),('--runtime-report',capture/'runtime.json'),
                  ('--gpu-timing-output',capture/'timing.json')):
    capture_command[capture_command.index(flag)+1]=str(path)
capture_environment,capture_seconds=run(capture_command,capture,True,360)
found=[]
for frame in expected:
    actual=digest(capture/'frames'/frame['name'])
    found.append(dict(name=frame['name'],sha256=actual,expected=frame['referenceSha256'],exact=actual==frame['referenceSha256']))
write(capture/'results.json',dict(seconds=capture_seconds,frames=found,environmentErrors=environment_errors(capture_environment)))
assert all(frame['exact'] for frame in found), found
data=json.loads((capture/'timing.json').read_bytes())
assert data['computedMaterialViewPipelines']>0 and data['computedMaterialViewSelectionsTotal']>0
verify(root,proof)
check_project()

rows=[]
for label,enabled in (('before',False),('candidate',True),('after',False)):
    folder=out/('cost-'+label)
    folder.mkdir()
    command=list(timing_template)
    command[0]=str(exe)
    timing=folder/'timing.json'
    command[command.index('--resource-root')+1]=str(build)
    command[command.index('--gpu-timing-output')+1]=str(timing)
    assert command[command.index('--smoke-frames')+1]=='120'
    environment,seconds=run(command,folder,enabled,290)
    data=json.loads(timing.read_bytes())
    assert (data['sceneWidth'],data['sceneHeight'])==(1920,1080)
    assert data['mainDepthSplitRecorded'] and not data.get('surfaceRadiancePrepared',False) and not data.get('shadowHistoryPrepared',False)
    if enabled:
        assert data['computedMaterialViewPipelines']>0 and data['computedMaterialViewSelectionsTotal']>0
        assert data['computedMaterialViewFrameEligible'] and data['computedMaterialViewFallback']=='ready'
    else:
        assert data['computedMaterialViewPipelines']==0 and data['computedMaterialViewSelectionsTotal']==0
        assert data['computedMaterialViewFallback']=='disabled'
    with timing.with_suffix('.csv').open(encoding='utf-8') as stream:
        measured=[r for r in csv.DictReader(stream) if 60<int(r['frame'])<=120]
    cpu=data['cpuFrame']['workSamplesMs']
    assert len(measured)==60 and len(cpu)==120
    rows.append(dict(label=label,seconds=seconds,gpu=stats([float(r['frameMs']) for r in measured]),
                     scene=stats([float(r['sceneMs']) for r in measured]),cpu=stats(cpu[60:]),
                     environmentErrors=environment_errors(environment),
                     powerLimits=sorted({x['powerLimitWatts'] for x in environment['runObservations']
                                         if x['powerLimitWatts'] is not None})))
    write(out/'cost-progress.json',rows)
    verify(root,proof)
check_project()
reference=(rows[0]['gpu']['mean']+rows[2]['gpu']['mean'])/2
scene_reference=(rows[0]['scene']['mean']+rows[2]['scene']['mean'])/2
drift=abs(rows[0]['gpu']['mean']-rows[2]['gpu']['mean'])/reference
gain=1-rows[1]['gpu']['mean']/reference
scene_gain=1-rows[1]['scene']['mean']/scene_reference
criteria=dict(minimumWholeFrameGain=gain>=.02,twiceReferenceDrift=gain>=2*drift,
              maximumReferenceDrift=drift<=.03,minimumAffectedRangeGain=scene_gain>=.05)
write(out/'cost-results.json',dict(commit=proof['commit'],rows=rows,referenceMeanMs=reference,reductionFraction=gain,
    referenceDriftFraction=drift,affectedRangeReductionFraction=scene_gain,criteria=criteria,
    shortEnvironmentQualified=all(not r['environmentErrors'] for r in rows),
    originalFourExact=True,formalAcceptance=False))
