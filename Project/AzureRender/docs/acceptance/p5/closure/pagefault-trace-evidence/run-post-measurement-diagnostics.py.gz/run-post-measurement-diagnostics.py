import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path.cwd().resolve()
WORK = ROOT / 'build/p5-directory-reclamation-2026-10-11'
METHODS = ROOT / 'build/p5-system-trace-2026-10-11'
sys.path.insert(0, str(ROOT / 'tools'))
from build_provenance import verify
from run_playable_performance import run

assert not ctypes.windll.shell32.IsUserAnAdmin(), 'Workloads use the ordinary desktop token'
deadline = time.monotonic() + 14400
while True:
    if (WORK / 'followup-failure.json').exists():
        raise RuntimeError('Resolve the acceptance runner failure before starting diagnostic GPU work')
    if (WORK / 'gpu-summary.json').exists() and not json.loads((WORK / 'gpu-summary.json').read_text(encoding='utf-8'))['passed']:
        raise RuntimeError('Resolve GPU regression failures first')
    if (WORK / 'followup-status.json').exists():
        records = json.loads((WORK / 'followup-status.json').read_text(encoding='utf-8'))
        if {r['name'] for r in records} >= {'formal-performance', 'delivery', 'platformer-longrun', 'standard-longrun'}:
            break
    assert time.monotonic() < deadline, 'Acceptance completion timeout'
    time.sleep(1)
proof = json.loads((WORK / 'release-provenance.json').read_text(encoding='utf-8'))
verify(ROOT, proof)
result = subprocess.run([sys.executable, str(WORK / 'retest-original-project-target.py')], cwd=ROOT,
    stdout=(WORK / 'original-target-retest.log').open('w', encoding='utf-8'), stderr=subprocess.STDOUT)
print('Original-target retest exit', result.returncode, flush=True)
formal = WORK / 'formal-performance'
summary = json.loads((formal / 'summary.json').read_text(encoding='utf-8'))
failed_loads = [name for name, rounds in summary['rounds'].items()
               if any(any('stableWorkingSetGrowth:' in error for error in row.get('budgetFailures', [])) for row in rounds)]
results = []
control = (METHODS / 'control-session.ps1').read_text(encoding='utf-8').replace('azure-memory-events.wprp', 'azure-pagefaults.wprp')
(WORK / 'control-pagefault-session.ps1').write_text(control, encoding='utf-8')
(WORK / 'azure-pagefaults.wprp').write_bytes((METHODS / 'azure-pagefaults.wprp').read_bytes())
for workload in failed_loads:
    for attempt in range(1, 4):
        verify(ROOT, proof)
        out = WORK / ('pagefault-' + workload + '-' + str(attempt))
        out.mkdir(exist_ok=False)
        project = formal / workload / 'project.azureproject'
        for name, expected in summary['sceneHashes'][workload].items():
            assert hashlib.sha256((project.parent / name).read_bytes()).hexdigest() == expected, name
        method = WORK / 'control-pagefault-session.ps1'
        start = subprocess.run(['powershell.exe', '-NoProfile', '-Command',
            'Start-Process -FilePath powershell.exe -Verb RunAs -WindowStyle Hidden -ArgumentList ' +
            "@('-NoProfile','-ExecutionPolicy','Bypass','-File','" + str(method) + "','-OutputDirectory','" + str(out) + "')"],
            capture_output=True, text=True)
        assert start.returncode == 0, start.stderr
        ready_deadline = time.monotonic() + 60
        while not (out / 'ready.json').exists():
            if (out / 'control-completion.json').exists():
                raise RuntimeError((out / 'control-completion.json').read_text(encoding='utf-8-sig'))
            assert time.monotonic() < ready_deadline, 'Trace startup timeout'
            time.sleep(.1)
        try:
            # Shared entry preserves the 50 ms observations and original budgets.
            # The extra system tracing is explicitly diagnostic overhead.
            import os
            if workload == 'editor':
                os.environ['AZURERENDER_EDITOR_CONFIG'] = str(out / 'editor-config')
            measured = run(ROOT / 'build/ninja-msvc-release' / ('AzureRender.exe' if workload == 'editor' else 'AzurePlayer.exe'),
                project, out / 'measurement', editor=workload == 'editor', stress=workload == 'stress')
            measured.update(diagnosticOnly=True, formalAcceptance=False, sourceHash=summary['sourceHash'],
                eventStacks=True, additionalResidentObserver=False)
            (out / 'result.json').write_text(json.dumps(measured, indent=2), encoding='utf-8')
            subprocess.run([sys.executable, str(METHODS / 'known-allocation-probe.py'), str(out / 'known-probe.json')], check=True)
            results.append(dict(workload=workload, attempt=attempt, workingSetGrowth=measured['stableWorkingSetGrowth'],
                formalFailureReproduced=measured['stableWorkingSetGrowth'] > .05, directory=str(out)))
        finally:
            (out / 'workload-finished.json').write_text('{}', encoding='utf-8')
            stop_deadline = time.monotonic() + 120
            while not (out / 'control-completion.json').exists():
                assert time.monotonic() < stop_deadline, 'Owned trace completion timeout'
                time.sleep(.2)
            completed = json.loads((out / 'control-completion.json').read_text(encoding='utf-8-sig'))
            assert completed['exitCode'] == 0, completed
        verify(ROOT, proof)
        (WORK / 'pagefault-diagnostic-partial.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
        print(json.dumps(results[-1]), flush=True)
        if results[-1]['formalFailureReproduced']:
            break
(WORK / 'post-measurement-diagnostics.json').write_text(json.dumps(dict(originalTargetRetestExitCode=result.returncode,
    formalFailedLoads=failed_loads, traces=results, fullRootCauseResolved=False), indent=2), encoding='utf-8')
