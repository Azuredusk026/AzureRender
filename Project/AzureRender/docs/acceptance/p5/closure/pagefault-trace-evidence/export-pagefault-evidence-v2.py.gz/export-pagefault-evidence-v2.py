import json
from pathlib import Path
import re
import subprocess
import sys

ROOT=Path.cwd().resolve();WORK=ROOT/'build/p5-directory-reclamation-2026-10-11'
KIT=Path('C:/Program Files (x86)/Windows Kits/10/Windows Performance Toolkit')
diagnostics=json.loads((WORK/'post-measurement-diagnostics.json').read_text(encoding='utf-8'))
results=[]
for record in diagnostics['traces']:
    out=Path(record['directory']);etl=out/'memory.etl'
    def invoke(label,args):
        logpath=out/(label+'.log')
        with logpath.open('x',encoding='utf-8') as log:
            result=subprocess.run(list(map(str,args)),cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=120)
        assert result.returncode==0,(label,result.returncode)
    if not (out/'trace-timespan.txt').exists():
        invoke('v2-timespan',[KIT/'xperf.exe','-i',etl,'-o',out/'trace-timespan.txt','-a','tracestats','-timespan'])
        invoke('v2-statistics',[KIT/'xperf.exe','-i',etl,'-o',out/'trace-statistics.txt','-a','tracestats','-detail','stack'])
        invoke('v2-process',[KIT/'xperf.exe','-i',etl,'-o',out/'processes.txt','-a','process'])
        invoke('v2-memory',[KIT/'xperf.exe','-i',etl,'-o',out/'memory-events.csv','-a','dumper','-provider','{3d6fa8d3-fe05-11d0-9dda-00c04fd7ba7c}'])
        invoke('v2-probe',[sys.executable,ROOT/'build/p5-system-trace-2026-10-11/validate-known-probe.py',out])
    matches=[line for line in (out/'processes.txt').read_text(encoding='utf-8-sig',errors='replace').splitlines() if 'AzurePlayer.exe (' in line]
    assert len(matches)==1,matches
    pid=int(re.search(r'AzurePlayer\.exe \((\d+)\)',matches[0]).group(1))
    invoke('v2-fault-stack',[KIT/'xperf.exe','-i',etl,'-o',out/'player-fault-stacks-v2.html','-a','stack','-pid',pid,'-event','PageFault','-butterfly','1'])
    lifetime=out/'wpa-lifetimes-v2';lifetime.mkdir(exist_ok=False)
    invoke('v2-lifetimes',[KIT/'wpaexporter.exe','-i',etl,'-profile',ROOT/'build/p5-system-trace-2026-10-11/memory-lifetimes.wpaProfile','-outputfolder',lifetime])
    results.append(dict(directory=str(out),pid=pid,exportsCompleted=True,formalFailureReproduced=record['formalFailureReproduced']))
    (WORK/'pagefault-export-v2-partial.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps(results[-1]),flush=True)
(WORK/'pagefault-export-v2-completion.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
