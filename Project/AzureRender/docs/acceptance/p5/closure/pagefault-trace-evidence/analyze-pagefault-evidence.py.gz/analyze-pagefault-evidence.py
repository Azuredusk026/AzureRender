import collections
import csv
import hashlib
import json
from pathlib import Path
import re
from html.parser import HTMLParser

class StackTables(HTMLParser):
    def __init__(self):
        super().__init__();self.heading='';self.in_heading=False;self.tables={};self.table=None;self.cell=None
    def handle_starttag(self,tag,attrs):
        if tag=='h2':self.in_heading=True;self.heading=''
        elif tag=='table' and self.heading.startswith('Modules by'):
            self.table=self.tables.setdefault(self.heading,[])
        elif tag=='tr' and self.table is not None:self.row=[]
        elif tag=='td' and self.table is not None:self.cell=''
    def handle_data(self,data):
        if self.in_heading:self.heading+=data
        if self.cell is not None:self.cell+=data
    def handle_endtag(self,tag):
        if tag=='h2':self.in_heading=False
        elif tag=='td' and self.cell is not None:self.row.append(self.cell.strip());self.cell=None
        elif tag=='tr' and self.table is not None and self.row:self.table.append(self.row)
        elif tag=='table':self.table=None

ROOT=Path.cwd().resolve();WORK=ROOT/'build/p5-directory-reclamation-2026-10-11'
exports=json.loads((WORK/'pagefault-export-v2-completion.json').read_text(encoding='utf-8'))
summaries=[]
for export in exports:
    out=Path(export['directory']);pid=export['pid'];target=f'AzurePlayer.exe ({pid})'
    stats=(out/'trace-timespan.txt').read_text(encoding='utf-8-sig')
    assert re.search(r'Total # Lost Buffers\s*:\s*0',stats)
    assert re.search(r'Total # Lost Events\s*:\s*0',stats)
    probe=json.loads((out/'known-probe-analysis.json').read_text(encoding='utf-8'))
    assert probe['passed'] and probe['observedCommits']==probe['observedReleases']==40
    process=next(line for line in (out/'processes.txt').read_text(encoding='utf-8-sig').splitlines() if target in line)
    start_us=int(process.strip().split(',')[0])
    mem=json.loads((out/'measurement.memory.json').read_text(encoding='utf-8'))
    midpoint=mem[len(mem)//2];stable_start=start_us+int(midpoint['seconds']*1_000_000)
    fault_counts=collections.Counter();stable_faults=collections.Counter();stable_sites=collections.Counter()
    rows=[];headers=[]
    with (out/'memory-events.csv').open(encoding='utf-8-sig',newline='') as source:
        for row in csv.reader(source):
            if len(row)>2 and row[2].strip()==target:
                if row[0].strip()=='PageFault':
                    fault_counts[row[6].strip()]+=1
                    if int(row[1])>=stable_start:
                        stable_faults[row[6].strip()]+=1
                        stable_sites[row[7].strip().split('!')[0]]+=1
                rows.append(row)
    with (out/'player-memory-events.csv').open('w',encoding='utf-8',newline='') as dest:
        csv.writer(dest).writerows(rows)
    lifecycle=[]
    source=out/'wpa-lifetimes-v2/VirtualAlloc_Commit_LifeTimes_RuleEngine.csv'
    with source.open(encoding='utf-8-sig',newline='') as stream:
        reader=csv.DictReader(stream);columns=reader.fieldnames
        lifecycle=[row for row in reader if row['Process']==target]
    with (out/'player-commit-lifetimes.csv').open('w',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=columns);writer.writeheader();writer.writerows(lifecycle)
    times=(midpoint['seconds'],max(row['seconds'] for row in mem if row['working']>=midpoint['working']))
    commits=[]
    for seconds in times:
        live=0.;names=collections.Counter()
        absolute=seconds+start_us/1_000_000
        for row in lifecycle:
            begin=float(row['Commit Time (s)'])
            try:end=float(row['Decommit Time (s)'])
            except ValueError:end=float('inf')
            if begin<=absolute<end:
                size=float(row['Size (MB)']);live+=size
                frames=[frame.split('!')[0] for frame in row['Commit Stack'].split('/') if '!' in frame]
                named=[name for name in frames if name.lower() not in ('ntdll.dll','kernel32.dll','kernelbase.dll','ntoskrnl.exe','ntkrnlmp.exe')]
                names[named[-1] if named else 'OtherOrUnresolved']+=size
        commits.append(dict(processSeconds=seconds,liveCommitMiB=live,nearestNamedFrameMiB=dict(names)))
    snapshots=[]
    with (out/'wpa-lifetimes-v2/Virtual_Memory_Snapshots_RuleEngine.csv').open(encoding='utf-8-sig',newline='') as stream:
        snapshots=[row for row in csv.DictReader(stream) if row['Process']==target]
    parser=StackTables();parser.feed((out/'player-fault-stacks-v2.html').read_text(encoding='utf-8-sig'))
    tables=parser.tables
    assert tables.get('Modules by Exclusive Hits') and tables.get('Modules by UniInclusive Hits')
    measured=json.loads((out/'result.json').read_text(encoding='utf-8'))
    summary=dict(sourceHash='41804e80288acf248965027b991f4af357ff57b757d100c77dcf2f1e31ca70f4',pid=pid,
        diagnosticOnly=True,formalAcceptance=False,formalFailureReproduced=False,
        stableWorkingSetGrowth=measured['stableWorkingSetGrowth'],diagnosticBudgetFailures=measured['budgetFailures'],
        lostEvents=0,lostBuffers=0,knownCommits=40,knownReleases=40,
        processStartTraceSeconds=start_us/1_000_000,stableStartProcessSeconds=midpoint['seconds'],
        faultTypes=dict(fault_counts),stableFaultTypes=dict(stable_faults),stableInstructionModules=dict(stable_sites),
        stackModulesExclusive=tables.get('Modules by Exclusive Hits',[]),
        stackModulesInclusive=tables.get('Modules by UniInclusive Hits',[]),
        commitRows=len(lifecycle),workingSetSnapshotCount=len(snapshots),commitComparisons=commits,
        symbolsLoaded=False,ownershipProven=False,
        attributionLimit='Instruction and named stack modules do not prove logical allocation ownership; repeated faults do not count unique resident bytes')
    (out/'player-pagefault-analysis.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    summaries.append(dict(directory=str(out),pid=pid,growth=summary['stableWorkingSetGrowth'],faults=dict(fault_counts),
        stableFaults=dict(stable_faults),commitRows=len(lifecycle),snapshots=len(snapshots),lossAndProbeVerified=True))
(WORK/'pagefault-analysis-summary.json').write_text(json.dumps(summaries,indent=2),encoding='utf-8')
print(json.dumps(summaries,indent=2))
