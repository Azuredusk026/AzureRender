"""Report current measurements and the exact source of reused regression."""
import json
from pathlib import Path

root=Path.cwd().resolve();work=root/'build/p5-relative-thermal-2026-10-11'
formal=json.loads((work/'formal-performance/summary.json').read_text(encoding='utf-8'))
rounds=[row for rows in formal['rounds'].values() for row in rows];assert len(rounds)==15
assert all(not any(f.startswith(('gpu.p95','cpu.p95','physics.p95')) for f in row.get('budgetFailures',[])) for row in rounds)
passed=sum(row['passed'] for row in rounds)
delivery=json.loads((work/'arena-delivery/summary.json').read_text(encoding='utf-8'))
assert delivery['passed'] and len(delivery['checks'])==10
inventory=json.loads((work/'regression-inventory.json').read_text(encoding='utf-8'))
assert inventory['currentCpuTests']==326 and inventory['priorGpuTests']==130
runs={name:json.loads((work/(name+'-longrun')/'summary.json').read_text(encoding='utf-8')) for name in ('platformer','standard')}
assert all(row['actualSeconds']>=1800 for row in runs.values())
def replace(name,old,new):
 p=root/name;s=p.read_text(encoding='utf-8');assert s.count(old)==1,(name,old);p.write_text(s.replace(old,new),encoding='utf-8')
def append(name,text):
 p=root/name;s=p.read_text(encoding='utf-8');assert text.strip() not in s;p.write_text(s+text,encoding='utf-8')
page='docs/acceptance/p5/closure/device-environment.md'
text='# P5-A 设备环境测量验收\n\n> 日期：2026-10-11。\n> 状态：设备环境实现通过，阶段门禁按本页维护。\n'
text+=f"> 候选来源：`{formal['sourceHash']}`。\n\n"
text+='## 现行判断\n\n启动采用驱动热限制与稳定空闲窗口。\n后台 GPU 占用与热降频状态一起校验。\n'
text+='默认保留两摄氏度热余量，等待期限为一百八十秒。\n策略、温度趋势及驱动原始观察分别保存。\n\n'
text+='本机驱动报告的 GPU 目标温度为 87°C。\n该值表示散热控制目标。\n'
text+='热限制使用相对热余量及对应驱动阈值。\n稳定的 65°C 初温在行为测试中允许测量。\n\n'
text+='真实设备观察验证驱动解析与十秒就绪窗口。\n启动与结束观察的覆盖范围在结果中明确登记。\n\n'
text+='普通功率限制和热降频分别解释。\n环境失败保留观察与明确诊断。\n'
text+='数值预算、工作集公式与长跑时长继续适用。\n历史批次保留其原始条件和来源。\n\n'
text+='## 回归与来源\n\n环境十二项与预算十二项行为测试通过。\n新增用例保留实现前失败与实现后通过日志。\n'
text+='覆盖合理高初温、热降频、有限等待和原始观察。\n初温字段与原始启动观察的一致性另有断言。\n\n'
text+='两配置当前 CPU 回归各一百六十三项通过。\n已有 GPU 回归六十六项与六十四项来自缓存候选。\n'
text+='两配置各五十四项记录产物逐字节一致。\n一百一十四项实际运行依赖也逐字节一致。\n\n'
text+='已执行的 GPU 回归来源为缓存候选 `b2af43f8`。\n本轮复用该证据，并记录运行依赖等价关系。\n'
text+='组合清单共四百五十六项，按测试名称核对。\n各组执行来源分别保存在原始清单中。\n\n'
text+='本轮五项目双设备移动发布共十组通过。\n六份 ZIP 的条目、许可与哈希逐项核验。\n'
text+='两份制作项目沿用已制作内容，经当前运行时发布。\n人工操作模板绑定本轮候选包哈希。\n\n'
text+='## 正式性能\n\n'
text+=f'十五轮正式性能中，{passed} 轮通过。\n'
text+='每轮预热三百帧，采样一千八百帧。\n初温由本轮实际设备规则判断。\n原始环境、内存和帧耗时共同保留。\n\n'
text+='| 负载 | 轮次 | 初温 | GPU P95 | 工作集增长 | 结果 |\n| --- | --- | --- | --- | --- | --- |\n'
for name,rows in formal['rounds'].items():
 for index,row in enumerate(rows,1):
  temp=f"{row['initialDevice']['temperature']:.1f}°C" if 'initialDevice' in row else '无有效值'
  gpu=f"{row['gpu']['p95']:.3f} 毫秒" if 'gpu' in row else '无有效值'
  growth=f"{row['stableWorkingSetGrowth']*100:.3f}%" if 'stableWorkingSetGrowth' in row else '无有效值'
  text+=f"| {name} | {index} | {temp} | {gpu} | {growth} | {'通过' if row['passed'] else '失败'} |\n"
text+='\n所有轮次的 GPU、CPU 与物理耗时均通过数值预算。\n'
text+='失败原因按原始预算诊断分别登记。\n\n'
text+='| 负载 | 轮次 | 失败原因 |\n| --- | --- | --- |\n'
for name,rows in formal['rounds'].items():
 for index,row in enumerate(rows,1):
  if row['passed']:continue
  reasons=[]
  for failure in row.get('budgetFailures',[]):
   if 'stableWorkingSetGrowth:' in failure:reasons.append('工作集增长超过百分之五')
   elif 'software thermal slowdown is active' in failure:reasons.append('结束观察的软件热降频处于活动状态')
   else:reasons.append('原始诊断：`'+failure.replace('|','/')+'`')
  text+=f"| {name} | {index} | {'；'.join(reasons) or '测量失败，见原始错误'} |\n"
text+='\n## 正式长跑\n\n| 场景 | 实际秒数 | 帧数 | 工作集增长 | 状态 |\n| --- | --- | --- | --- | --- |\n'
for name,label in [('platformer','平台关卡'),('standard','标准交替场景')]:
 r=runs[name];text+=f"| {label} | {r['actualSeconds']:.3f} | {r['frames']} | {r['workingSetGrowth']*100:.3f}% | {r['status']} |\n"
p=runs['platformer']
text+=f"\n平台完成 {p['completedRoutes']} 次通关。\n必经落点验证 {p['mandatoryLandings']} 次。\n"
text+=f"起点与检查点恢复分别为 {p['startFallRecoveries']}、{p['checkpointFallRecoveries']} 次。\n"
text+=f"水平与垂直承载分别为 {p['horizontalRides']}、{p['verticalRides']} 次。\n\n"
text+='## 阶段门禁\n\n设备环境的实现与实际测量分别维护结果。\n完整工作集因果、实体输入、听感与效率各有待验项。\n'
text+='项目创建的目录拒绝与取消时序仍有归因待项。\nP5、U15、U16 与 P6 按全部必需门禁确定状态。\n\n'
text+='平台长跑进程的模块快照包含 OBS 捕获模块。\n该快照属于环境诊断观察。\n'
text+='捕获影响需由有无该模块的对照验证。\n完整工作集归因保持待验。\n\n'
comparison_path=work/'no-capture-modules.json'
if comparison_path.exists():
 comparison=json.loads(comparison_path.read_text(encoding='utf-8'))
 text+='## 捕获模块对照\n\n'
 text+='复测对子进程声明 OBS 隐式层的禁用变量。\n系统的注册与捕获配置保持原有状态。\n'
 text+='源码、运行产物、场景和预算逐项校验一致。\n模块列表每五秒观察，覆盖范围单独记录。\n\n'
 text+=f"对照正式性能通过 {comparison['comparisonPassedRounds']}/15 轮。\n"
 text+=f"观察到的运行进程为 {comparison['observedProcessCount']} 个。\n"
 text+=('观察中均未出现 OBS 捕获模块。\n' if comparison['noCaptureObservationQualified'] else '模块缺失对照未通过全部观察条件。\n')
 text+='两批原始结果保留，完整内存因果单独验收。\n\n'
text+='原始记录见[设备环境证据](device-environment-evidence/manifest.json)。\n'
text+='相对阈值待修候选见[独立记录](rejected-environment-evidence/manifest.json)。\n'
text+='规则与操作见[实施计划](../../../plans/2026-10-11-performance-environment.md)。\n'
text+='当前阶段全部必需项通过后执行资产格式阶段。\n'
(root/page).write_text(text,encoding='utf-8')
plan='docs/plans/2026-10-11-performance-environment.md'
replace(plan,'> 状态：执行中。','> 状态：实现、回归与实测完成，阶段门禁分别维护。')
s=(root/plan).read_text(encoding='utf-8')
for line in s.splitlines():
 if line.startswith('- [ ]') and '创建独立中文提交' not in line:s=s.replace(line,line.replace('- [ ]','- [x]',1))
(root/plan).write_text(s,encoding='utf-8')
replace('README.md','完整回归与当前来源实测见[缓存并发验收]','缓存候选的回归与实测见[缓存并发验收]')
block='\n性能测量依据驱动热限制与稳定空闲窗口启动。\n温度、热降频与后台占用保留原始观察。\n'
block+='规则和实测见[设备环境验收](docs/acceptance/p5/closure/device-environment.md)。\n'
replace('README.md','\n资产格式后续阶段见',block+'\n资产格式后续阶段见')
change='## P5-A 实际设备环境规则 2026-10-11\n\n温度规则采用驱动热限制与稳定空闲窗口。\n'
change+='热降频、后台负载与等待期限共用工具解释。\n历史初温条件保留在相应批次的原始证据中。\n'
change+='GPU、CPU、物理和内存数值预算保持有效。\n\n'
change+=f'当前 CPU 回归共三百二十六项通过。\n正式性能中，{passed}/15 轮通过。\n'
change+='两类三十分钟实跑及来源见[验收](docs/acceptance/p5/closure/device-environment.md)。\n\n'
replace('CHANGELOG.md','# Changelog\n\n','# Changelog\n\n'+change)
replace('mkdocs.yml','nav:\n','nav:\n  - 设备环境测量验收: acceptance/p5/closure/device-environment.md\n  - 设备环境测量计划: plans/2026-10-11-performance-environment.md\n')
append('docs/acceptance/p5/closure/p5-a.md','\n## 实际设备环境规则\n\n正式启动条件采用驱动热限制与稳定空闲窗口。\n'
 '实现和当前来源实测见[设备环境验收](device-environment.md)。\n历史批次保留原始来源与条件。\n')
append('docs/plans/azure-engine-plan.md','\n## 设备环境候选验收\n\n性能启动依据设备热限制、降频与空闲趋势判断。\n'
 f'当前规则的正式性能通过 {passed}/15 轮。\n'
 '两类长跑及来源见[设备环境验收](../acceptance/p5/closure/device-environment.md)。\n'
 '完整内存因果和人工门禁保持待验。\n')
manifest_path=root/'docs/plans/authoring-usability-manifest.json'
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
manifest['deviceEnvironmentCandidate']=dict(sourceHash=formal['sourceHash'],
 acceptance=page,currentCpuTests=326,priorGpuTests=130,priorGpuSourceHash='b2af43f8a206f6edc16e30c259e41f6230fa64adf6b261e8fd7cbf4dec9b64c2',
 runtimeDependenciesByteEquivalent=True,deliveryChecks=10,formalPerformancePassed=formal['passed'],formalPassedRounds=passed,
 formalTotalRounds=15,longRuns={n:{k:r[k] for k in ('status','actualSeconds','frames','workingSetGrowth')} for n,r in runs.items()},
 packageHashes={r['kind']:r['sha256'] for r in delivery['packages']},physicalInputVerified=False,subjectiveAudioVerified=False,
 authoringEfficiencyVerified=False,priorWorkingSetCauseResolved=False)
manifest['rejectedDeviceEnvironmentCandidate']=dict(sourceHash='3cdb6f659eda85ee63b4cd6bd0bde6ce94a8df2c2aa1324acbe599bb3d9eee7b',
 status='RejectedThermalReferencePolicy',evidence='docs/acceptance/p5/closure/rejected-environment-evidence/manifest.json',
 formalRounds=15,originalPassedRounds=6,longRunsExecuted=False)
if comparison_path.exists():
 manifest['deviceEnvironmentCandidate']['captureComparison']={key:comparison[key] for key in (
  'noCaptureObservationQualified','observedProcessCount','comparisonPassedRounds','sameSourcesProductsScenesAndBudgets')}
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(sourceHash=formal['sourceHash'],formalPassedRounds=passed,longRuns={n:r['status'] for n,r in runs.items()})))
