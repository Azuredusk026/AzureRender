"""Run the remaining measurement entry points after the main GPU batch ends."""
import datetime
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path.cwd().resolve()
work = root/'build/p5-relative-thermal-2026-10-11'
sys.path.insert(0, str(root/'tools'))
from build_provenance import inputs
frozen = inputs(root)
source_hash = __import__('hashlib').sha256(json.dumps(frozen, sort_keys=True).encode()).hexdigest()
status = json.loads((work/'acceptance-status.json').read_text(encoding='utf-8'))
assert {row['name'] for row in status} >= {'formal-performance', 'platformer-longrun', 'standard-longrun'}
records = []
for name, arguments in [
    ('preview-probe', ['tools/run_preview_comparison.py', '--executable', 'build/ninja-msvc-release/AzureRender.exe',
                       '--output', str(work/'preview-probe'), '--rounds', '1', '--warmup', '300', '--samples', '1800']),
    ('cinematic-probe', ['tools/measure_runtime_performance.py', '--executable', 'build/ninja-msvc-release/AzureRender.exe',
                         '--output-dir', str(work/'cinematic-probe')])]:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print('Starting', name, started, flush=True)
    with (work/(name+'.log')).open('w', encoding='utf-8') as stream:
        child = subprocess.Popen([sys.executable, *arguments], cwd=root,
                                 env=dict(os.environ,DISABLE_VULKAN_OBS_CAPTURE='1'),
                                 stdout=stream, stderr=subprocess.STDOUT)
        code = child.wait()
    assert inputs(root) == frozen
    records.append(dict(name=name, exitCode=code, sourceHash=source_hash,
                        processEnvironmentOverride={'DISABLE_VULKAN_OBS_CAPTURE':'1'},startedUtc=started,
                        endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    (work/'additional-entry-status.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
    print(name, 'exit', code, flush=True)
raise SystemExit(int(any(row['exitCode'] for row in records)))
