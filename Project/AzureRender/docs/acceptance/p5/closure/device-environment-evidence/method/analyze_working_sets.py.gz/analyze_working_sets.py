"""Describe observed residency and private commit without assigning a cause."""
import hashlib
import json
from pathlib import Path

work = Path.cwd()/'build/p5-relative-thermal-2026-10-11'
directory = work/'formal-performance'
rows = []
for path in sorted(directory.glob('*.memory.json')):
    samples = json.loads(path.read_text(encoding='utf-8'))
    if len(samples) < 10:
        continue
    stable = samples[len(samples)//2:]
    metrics = {}
    for field in ('working', 'privateBytes'):
        values = [sample[field] for sample in stable]
        metrics[field] = dict(start=values[0], peak=max(values), final=values[-1],
                              growth=max(values)/values[0]-1)
    rows.append(dict(round=path.name.removesuffix('.memory.json'),
                     observationSha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                     stableStartSeconds=stable[0]['seconds'], endSeconds=stable[-1]['seconds'],
                     metrics=metrics))
result = dict(schemaVersion=1, scope='RawObservationsOnly', causeResolved=False, rounds=rows)
(work/'working-set-observation-analysis.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps([dict(round=row['round'], workingGrowthPercent=round(row['metrics']['working']['growth']*100, 3),
                       privateGrowthPercent=round(row['metrics']['privateBytes']['growth']*100, 3)) for row in rows]))
