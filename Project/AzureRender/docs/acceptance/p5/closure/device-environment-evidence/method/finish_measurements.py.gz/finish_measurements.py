"""Finish all machine checks before exposing remaining operator gates."""
import ctypes
import datetime
import json
import subprocess
import sys
from pathlib import Path

root = Path.cwd().resolve()
work = root/'build/p5-relative-thermal-2026-10-11'
state = root/'build/p5-relative-thermal-closure-status.json'
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.restype = ctypes.c_void_p
kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
kernel.CloseHandle.argtypes = [ctypes.c_void_p]
pid = json.loads((work/'detached-launch.json').read_text(encoding='utf-8'))['pid']
handle = kernel.OpenProcess(0x100000, False, pid)
if handle:
    try:
        while kernel.WaitForSingleObject(handle, 1000) == 258:
            pass
    finally:
        kernel.CloseHandle(handle)
assert not (work/'runner-failure.json').exists()
batch = json.loads((work/'acceptance-status.json').read_text(encoding='utf-8'))
assert {row['name'] for row in batch} >= {'standard-longrun', 'platformer-longrun', 'formal-performance'}
records = []
def run(name, arguments, required=True):
    print('Starting', name, flush=True)
    with (work/(name+'.log')).open('w', encoding='utf-8') as stream:
        child = subprocess.run([sys.executable, *arguments], cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    records.append(dict(name=name, exitCode=child.returncode, endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    state.write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
    print(name, 'exit', child.returncode, flush=True)
    if required:
        assert child.returncode == 0, name
run('capture-comparison', [str(work/'repeat_without_capture.py')], required=False)
run('entry-probes', [str(work/'probe_remaining_entries.py')], required=False)
run('memory-analysis', [str(work/'analyze_working_sets.py')])
run('sync-documents', [str(work/'sync_documents.py')])
run('docs-style', ['tools/check_doc_style.py', 'README.md', 'CHANGELOG.md',
                  'docs/runtime/playable-performance.md', 'docs/plans/2026-10-11-performance-environment.md',
                  'docs/acceptance/p5/closure/device-environment.md',
                  'docs/plans/azure-engine-plan.md', 'docs/acceptance/p5/closure/p5-a.md'])
run('archive', [str(work/'archive_evidence.py')])
run('verify', [str(work/'verify_environment_candidate.py')])
print('Machine measurement closure finished; operator gates remain explicit.', flush=True)
