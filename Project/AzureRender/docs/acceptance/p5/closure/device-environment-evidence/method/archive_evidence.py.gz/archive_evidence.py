"""Keep current measurements and source-associated regression as original bytes."""
import gzip
import hashlib
import json
from pathlib import Path

root=Path.cwd().resolve();work=root/'build/p5-relative-thermal-2026-10-11'
target=root/'docs/acceptance/p5/closure/device-environment-evidence';assert not target.exists()
formal=json.loads((work/'formal-performance/summary.json').read_text(encoding='utf-8'))
rounds=[r for rows in formal['rounds'].values() for r in rows];assert len(rounds)==15
delivery=json.loads((work/'arena-delivery/summary.json').read_text(encoding='utf-8'))
assert delivery['passed'] and len(delivery['checks'])==10
inventory=json.loads((work/'regression-inventory.json').read_text(encoding='utf-8'))
assert inventory['total']==456 and inventory['currentCpuTests']==326 and inventory['priorGpuTests']==130
runs={n:json.loads((work/(n+'-longrun')/'summary.json').read_text(encoding='utf-8')) for n in ('platformer','standard')}
selected={}
def add(path,label):
 assert path.is_file() and label not in selected,(path,label)
 selected[label]=path
for p in sorted(work.iterdir()):
 if p.is_file() and p.suffix in ('.py','.ps1','.cmd','.log','.json','.txt','.html') and p.name not in ('archive.log','verify.log'):
  add(p,'method/'+p.name)
for n in ('formal-performance','no-capture-performance','platformer-longrun','standard-longrun','operator-review','preview-probe','cinematic-probe'):
 base=work/n
 if not base.exists():continue
 for p in sorted(base.iterdir()):
  if p.is_file() and p.suffix in ('.json','.jsonl','.log','.csv','.md','.png'):add(p,n+'/'+p.name)
 for p in sorted((base/'captures').glob('*')):
  if p.is_file() and (p.name.startswith('hud-') or p.name=='gpu_capabilities.json'):add(p,n+'/captures/'+p.name)
 if n=='preview-probe':
  for p in sorted(base.glob('*/disabled-*/*'))+sorted(base.glob('*/enabled-*/*')):
   if p.is_file() and p.suffix in ('.json','.log','.csv'):add(p,n+'/'+p.relative_to(base).as_posix())
base=work/'arena-delivery'
for p in sorted(base.iterdir()):
 if p.is_file() and p.suffix in ('.json','.log'):add(p,'delivery/'+p.name)
for p in sorted(base.glob('nvidia-*/*'))+sorted(base.glob('intel-*/*')):
 if p.is_file() and p.suffix in ('.json','.log'):add(p,'delivery/'+p.relative_to(base).as_posix())
add(base/'packages/provenance.json','delivery/provenance.json')
add(root/'docs/acceptance/p5/closure/rejected-environment-evidence/manifest.json','rejected-candidate/manifest.json')
for row in delivery['packages']:
 folder=base/('Moved Engine' if row['kind']=='engine' else 'Moved '+row['kind'])
 add(folder/('install_manifest.json' if row['kind']=='engine' else 'game_manifest.json'),'package-manifests/'+row['kind']+'.json')
for c in ('release','debug'):
 add(root/'build/p5-cache-publication-2026-10-11'/(c+'-gpu.log'),'baseline-gpu/'+c+'.log')
for name in ('gpu_environment.py','performance_budget.py','run_playable_performance.py','run_playable_long_run.py',
 'run_platformer_long_run.py','run_preview_comparison.py','measure_runtime_performance.py','test_gpu_environment.py',
 'test_performance_budget.py','test_playable_delivery_rules.py'):
 add(root/'tools'/name,'source/tools/'+name)
files={}
for label,path in selected.items():
 raw=path.read_bytes();stored=gzip.compress(raw,mtime=0);name=label+'.gz';output=target/name
 output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(stored);assert gzip.decompress(stored)==raw
 files[name]=dict(source=path.relative_to(root).as_posix(),originalBytes=len(raw),storedBytes=len(stored),
  originalSha256=hashlib.sha256(raw).hexdigest(),sha256=hashlib.sha256(stored).hexdigest(),compressed=True)
manifest=dict(schemaVersion=1,sourceHash=formal['sourceHash'],currentCpuTests=326,priorGpuTests=130,
 associatedTotal=456,priorGpuSourceHash=inventory['priorGpuSourceHash'],deliveryChecks=10,
 formalRounds=15,formalPassedRounds=sum(r['passed'] for r in rounds),formalPerformancePassed=formal['passed'],
 longRuns={n:{k:r[k] for k in ('status','actualSeconds','frames','workingSetGrowth')} for n,r in runs.items()},
 physicalInputVerified=False,subjectiveAudioVerified=False,authoringEfficiencyVerified=False,priorWorkingSetCauseResolved=False,files=files)
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(files=len(files),bytes=sum(r['storedBytes'] for r in files.values()),formalPassedRounds=manifest['formalPassedRounds'],longRuns=manifest['longRuns'])))
