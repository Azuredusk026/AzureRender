"""Repeat the unchanged formal batch and observe modules in fresh processes."""
import ctypes
from ctypes import wintypes
import datetime
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd().resolve()
work = root/'build/p5-relative-thermal-2026-10-11'
output = work/'no-capture-performance'
observations = []
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
class ProcessEntry(ctypes.Structure):
    _fields_ = [('dwSize',wintypes.DWORD),('cntUsage',wintypes.DWORD),('th32ProcessID',wintypes.DWORD),
                ('th32DefaultHeapID',ctypes.c_size_t),('th32ModuleID',wintypes.DWORD),('cntThreads',wintypes.DWORD),
                ('th32ParentProcessID',wintypes.DWORD),('pcPriClassBase',wintypes.LONG),('dwFlags',wintypes.DWORD),
                ('szExeFile',wintypes.WCHAR*260)]
class ModuleEntry(ctypes.Structure):
    _fields_ = [('dwSize',wintypes.DWORD),('th32ModuleID',wintypes.DWORD),('th32ProcessID',wintypes.DWORD),
                ('GlblcntUsage',wintypes.DWORD),('ProccntUsage',wintypes.DWORD),('modBaseAddr',ctypes.c_void_p),
                ('modBaseSize',wintypes.DWORD),('hModule',wintypes.HANDLE),('szModule',wintypes.WCHAR*256),
                ('szExePath',wintypes.WCHAR*260)]
for name, entry in [('Process32FirstW', ProcessEntry),('Process32NextW',ProcessEntry),
                    ('Module32FirstW',ModuleEntry),('Module32NextW',ModuleEntry)]:
    getattr(kernel,name).argtypes=[wintypes.HANDLE,ctypes.POINTER(entry)]

def processes(parent):
    handle=kernel.CreateToolhelp32Snapshot(2,0)
    if handle==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
    row=ProcessEntry();row.dwSize=ctypes.sizeof(row);result=[]
    try:
        more=kernel.Process32FirstW(handle,ctypes.byref(row))
        while more:
            if row.th32ParentProcessID==parent and row.szExeFile in ('AzurePlayer.exe','AzureRender.exe'):
                result.append((row.th32ProcessID,row.szExeFile))
            more=kernel.Process32NextW(handle,ctypes.byref(row))
    finally:kernel.CloseHandle(handle)
    return result

def modules(pid):
    handle=kernel.CreateToolhelp32Snapshot(8|16,pid)
    if handle==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
    row=ModuleEntry();row.dwSize=ctypes.sizeof(row);result=[]
    try:
        more=kernel.Module32FirstW(handle,ctypes.byref(row))
        if not more:raise ctypes.WinError(ctypes.get_last_error())
        while more:
            result.append(dict(name=row.szModule,path=row.szExePath,bytes=row.modBaseSize))
            more=kernel.Module32NextW(handle,ctypes.byref(row))
    finally:kernel.CloseHandle(handle)
    return result

assert not output.exists()
layer_path=Path('C:/ProgramData/obs-studio-hook/obs-vulkan64.json')
layer=json.loads(layer_path.read_text(encoding='utf-8'))
assert layer['layer']['disable_environment']=={'DISABLE_VULKAN_OBS_CAPTURE':'1'}
(work/'obs-layer-manifest.json').write_bytes(layer_path.read_bytes())
test_environment=dict(os.environ,DISABLE_VULKAN_OBS_CAPTURE='1')
first_seen={};last_seen={};started=time.monotonic()
with (work/'no-capture-performance.log').open('w',encoding='utf-8') as stream:
    child=subprocess.Popen([sys.executable,'tools/run_playable_performance.py',
        '--player','build/ninja-msvc-release/AzurePlayer.exe','--editor','build/ninja-msvc-release/AzureRender.exe',
        '--exploration','assets_public/exploration/project.azureproject',
        '--platformer','assets_public/platformer/project.azureproject','--output',str(output)],
        cwd=root,env=test_environment,stdout=stream,stderr=subprocess.STDOUT)
    while child.poll() is None:
        now=time.monotonic()
        for pid,name in processes(child.pid):
            first_seen.setdefault(pid,now)
            if now-first_seen[pid]<3 or now-last_seen.get(pid,0)<5:continue
            try:
                rows=modules(pid)
                observations.append(dict(pid=pid,executable=name,seconds=now-started,modules=rows,
                    capturePresent=any(row['name'].lower()=='graphics-hook64.dll' for row in rows)))
            except OSError as error:
                observations.append(dict(pid=pid,executable=name,seconds=now-started,error=str(error)))
            last_seen[pid]=now
        time.sleep(1)
    code=child.wait()
successful=[row for row in observations if 'modules' in row]
observed={row['pid'] for row in successful}
qualified=len(first_seen)==len(observed)==15 and not any(row['capturePresent'] for row in successful)
result=dict(schemaVersion=1,observedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            processEnvironmentOverride={'DISABLE_VULKAN_OBS_CAPTURE':'1'},systemConfigurationModified=False,
            scope='PeriodicModuleSnapshotsAfterThreeSeconds',observerIntervalSeconds=1,moduleIntervalSeconds=5,
            formalExitCode=code,processCount=len(first_seen),observedProcessCount=len(observed),
            noCaptureObservationQualified=qualified,observations=observations)
original=json.loads((work/'formal-performance/summary.json').read_text(encoding='utf-8'))
comparison=json.loads((output/'summary.json').read_text(encoding='utf-8'))
assert original['sourceHash']==comparison['sourceHash']
assert original['products']==comparison['products'] and original['budgets']==comparison['budgets']
assert original['quality']==comparison['quality'] and original['sceneHashes']==comparison['sceneHashes']
result['sourceHash']=comparison['sourceHash']
result['sameSourcesProductsScenesAndBudgets']=True
result['baselinePassedRounds']=sum(row['passed'] for rows in original['rounds'].values() for row in rows)
result['comparisonPassedRounds']=sum(row['passed'] for rows in comparison['rounds'].values() for row in rows)
(work/'no-capture-modules.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='observations'}))
assert qualified,'Fresh process module observations do not establish the requested capture-free comparison'
raise SystemExit(code)
