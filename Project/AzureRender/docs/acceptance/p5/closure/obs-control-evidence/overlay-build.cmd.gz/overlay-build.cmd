@echo off
call "D:\Visual Studio\2022\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64 -vcvars_ver=14.44
if errorlevel 1 exit /b 1
"D:\Visual Studio\2022\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe" -S build/p5-observation-control-2026-10-11/overlay-control -B build/p5-observation-control-2026-10-11/overlay-control/compiled -G Ninja -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 exit /b 2
"D:\Visual Studio\2022\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe" --build build/p5-observation-control-2026-10-11/overlay-control/compiled
exit /b %errorlevel%
