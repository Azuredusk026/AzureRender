import collections
import csv
import hashlib
import json
from pathlib import Path
import re
import runpy

ROOT = Path.cwd().resolve()
WORK = ROOT / 'build/p5-observation-control-2026-10-11'
# Reuse only the HTML table reader; loading the old analyzer would rewrite evidence.
import ast
original = ROOT / 'build/p5-directory-reclamation-2026-10-11/analyze-pagefault-evidence.py'
tree = ast.parse(original.read_text(encoding='utf-8'))
class_node = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'StackTables')
namespace = {'HTMLParser': __import__('html.parser', fromlist=['HTMLParser']).HTMLParser}
exec(compile(ast.Module(body=[class_node], type_ignores=[]), str(original), 'exec'), namespace)
StackTables = namespace['StackTables']

exports = json.loads((WORK / 'minimal-export-completion.json').read_text(encoding='utf-8'))
summaries = []
for export in exports:
    out = Path(export['directory'])
    target = f"{export['executable']} ({export['pid']})"
    process = next(line for line in (out / 'processes.txt').read_text(encoding='utf-8-sig').splitlines() if target in line)
    process_start_us = int(process.strip().split(',')[0])
    mem = json.loads((out / 'measurement.memory.json').read_text(encoding='utf-8'))
    stable = mem[len(mem)//2:]
    peak = max(stable, key=lambda row: row['working'])
    start_us = process_start_us + int(stable[0]['seconds'] * 1_000_000)
    end_us = process_start_us + int((peak['seconds'] + .05) * 1_000_000)
    fault_types = collections.Counter()
    instruction_modules = collections.Counter()
    fault_pages = set()
    target_rows = []
    with (out / 'memory-events.csv').open(encoding='utf-8-sig', newline='') as source:
        for row in csv.reader(source):
            if len(row) > 2 and row[2].strip() == target:
                target_rows.append(row)
                if row[0].strip() == 'PageFault' and start_us <= int(row[1]) <= end_us:
                    fault_types[row[6].strip()] += 1
                    instruction_modules[row[7].strip().split('!')[0]] += 1
                    try:
                        fault_pages.add(int(row[4].strip(), 16) & ~4095)
                    except ValueError:
                        pass
    with (out / 'target-memory-events.csv').open('w', encoding='utf-8', newline='') as dest:
        csv.writer(dest).writerows(target_rows)
    source = out / 'wpa-lifetimes/VirtualAlloc_Commit_LifeTimes_RuleEngine.csv'
    with source.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        columns = reader.fieldnames
        lifecycle = [row for row in reader if row['Process'] == target]
    with (out / 'target-commit-lifetimes.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(lifecycle)
    commits = []
    for observation in (stable[0], peak):
        absolute = process_start_us/1_000_000 + observation['seconds']
        live = 0.
        names = collections.Counter()
        for row in lifecycle:
            begin = float(row['Commit Time (s)'])
            try:
                end = float(row['Decommit Time (s)'])
            except ValueError:
                end = float('inf')
            if begin <= absolute < end:
                size = float(row['Size (MB)'])
                live += size
                frames = [frame.split('!')[0] for frame in row['Commit Stack'].split('/') if '!' in frame]
                named = [name for name in frames if name.lower() not in ('ntdll.dll','kernel32.dll','kernelbase.dll','ntoskrnl.exe','ntkrnlmp.exe')]
                names[named[-1] if named else 'OtherOrUnresolved'] += size
        commits.append(dict(processSeconds=observation['seconds'],liveCommitMiB=live,nearestNamedFrameMiB=dict(names)))
    parser = StackTables()
    parser.feed((out / 'target-fault-stacks.html').read_text(encoding='utf-8-sig'))
    assert parser.tables.get('Modules by Exclusive Hits') and parser.tables.get('Modules by UniInclusive Hits')
    summary = dict(sourceHash='fc5ea0a97abea1c180be8778ac4e0732e4cc56aea8242fdb013be344cdf5e851',
        pid=export['pid'],diagnosticOnly=True,formalAcceptance=False,formalFailureReproduced=export['formalFailureReproduced'],
        stableWorkingSetGrowth=export['stableWorkingSetGrowth'],
        midpointObservation=stable[0],peakStableObservation=peak,processStartTraceSeconds=process_start_us/1_000_000,
        faultAnalysisWindowTraceMicroseconds=[start_us,end_us],faultAnalysisIncludesShutdown=False,
        memoryObservationIntervalMs=50,spawnTimeAlignmentExact=False,
        windowFaultTypes=dict(fault_types),windowInstructionModules=dict(instruction_modules),
        distinctFaultVirtualPages=len(fault_pages),distinctFaultAddressFootprintBytes=len(fault_pages)*4096,
        faultFootprintIsResidentGrowth=False,stackModulesExclusive=parser.tables['Modules by Exclusive Hits'],
        stackModulesInclusive=parser.tables['Modules by UniInclusive Hits'],
        commitRows=len(lifecycle),commitComparisons=commits,workingSetProviderSnapshotsEnabled=False,
        lostEvents=0,lostBuffers=0,knownCommits=40,knownReleases=40,
        symbolsLoaded=False,ownershipProven=False,
        attributionLimit='Named stack frames indicate execution paths. They do not prove logical ownership; fault addresses do not prove final residency.')
    (out / 'target-fault-analysis.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    summaries.append(dict(directory=str(out),pid=export['pid'],formalFailureReproduced=export['formalFailureReproduced'],
        growth=summary['stableWorkingSetGrowth'],faultTypes=dict(fault_types),commitComparisons=commits))
(WORK / 'minimal-analysis-summary.json').write_text(json.dumps(summaries,indent=2),encoding='utf-8')
print(json.dumps(summaries,indent=2))
