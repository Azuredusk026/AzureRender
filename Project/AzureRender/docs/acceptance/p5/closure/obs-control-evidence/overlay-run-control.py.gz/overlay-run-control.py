import ctypes
import csv
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path.cwd().resolve()
WORK=ROOT/'build/p5-observation-control-2026-10-11'
HERE=WORK/'overlay-control'
spec=importlib.util.spec_from_file_location('owned_injection',ROOT/'build/p5-p6-closure-2026-10-10/native-memory-trace/inject_owned.py')
owned=importlib.util.module_from_spec(spec)
spec.loader.exec_module(owned)
sys.path.insert(0,str(ROOT/'tools'))
from run_playable_performance import memory_snapshot, stats
from performance_budget import working_set_growth
from gpu_environment import wait_and_record, snapshot
from build_provenance import verify

def execute(command,out,block):
    out.mkdir(exist_ok=False)
    dll=HERE/'compiled/AzureOverlayControl.dll'
    info=subprocess.STARTUPINFO();info.dwFlags|=subprocess.STARTF_USESHOWWINDOW;info.wShowWindow=0
    started=time.monotonic();process=None;primary=None
    observations=[];inventory=set();observed=denied=None
    with (out/'stdout.log').open('w',encoding='utf-8') as stdout,(out/'stderr.log').open('w',encoding='utf-8') as stderr:
        child=subprocess.Popen(list(map(str,command)),cwd=ROOT,env=dict(os.environ,DISABLE_VULKAN_OBS_CAPTURE='1'),
            creationflags=4,startupinfo=info,stdout=stdout,stderr=stderr)
        try:
            process=owned.checked(owned.OpenProcess(0x1fffff,False,child.pid))
            threads=owned.ownedThreads(child.pid);assert len(threads)==1
            primary=owned.checked(owned.OpenThread(0x1fffff,False,threads[0]))
            owned.invoke(process,owned.GetProcAddress(owned.GetModuleHandleW('kernel32.dll'),b'LoadLibraryW'),owned.remoteString(process,dll))
            remote=next(row for row in owned.modules(process) if Path(row['path']).resolve()==dll)
            local=owned.checked(owned.LoadLibraryW(str(dll)))
            def invoke_export(name,parameter=None):
                entry=owned.checked(owned.GetProcAddress(local,name.encode()))
                return owned.invoke(process,remote['base']+entry-local,parameter)
            assert invoke_export('AzureOverlayStart',1 if block else None)==0
            assert owned.ResumeThread(primary)==1
            while child.poll() is None:
                assert time.monotonic()-started<120,'Owned diagnostic timeout'
                try:
                    mem=memory_snapshot(child.pid);mem['seconds']=time.monotonic()-started;observations.append(mem)
                    inventory.update(Path(row['path']).name for row in owned.modules(process))
                    if observed is None and (command[0].name=='AzureOverlayProbe.exe' or mem['seconds']>8):
                        observed=invoke_export('AzureOverlayObserved');denied=invoke_export('AzureOverlayDenied')
                        if not observed:observed=denied=None
                except OSError:
                    if child.poll() is None:raise
                    break
                time.sleep(.05)
        finally:
            if child.poll() is None:child.kill();child.wait(timeout=15)
            if primary:owned.CloseHandle(primary)
            if process:owned.CloseHandle(process)
    result=dict(diagnosticOnly=True,formalAcceptance=False,blockNvidiaCapture=block,childPid=child.pid,exitCode=child.returncode,
        observedLoadAttempts=observed,deniedLoadAttempts=denied,moduleNames=sorted(inventory),
        nvCaptureObserved=any(name.lower()=='nvspcap64.dll' for name in inventory),
        obsModuleObserved=any('graphics-hook' in name.lower() for name in inventory),
        injectionSha256=hashlib.sha256(dll.read_bytes()).hexdigest(),
        targetSha256=hashlib.sha256(command[0].read_bytes()).hexdigest(),
        registryChanged=False,otherProcessesModified=False,workingSetObservationIntervalMs=50)
    if len(observations)>=10:result['stableWorkingSetGrowth']=working_set_growth([row['working'] for row in observations])
    (out/'memory.json').write_text(json.dumps(observations,indent=2),encoding='utf-8')
    (out/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    assert child.returncode==0,result
    assert observed and bool(denied)==block,result
    assert result['nvCaptureObserved'] != block,result
    return result

probe_results=[]
for block in (False,True):
    result=execute([HERE/'compiled/AzureOverlayProbe.exe',HERE/'compiled/nvspcap64.dll',str(int(not block))],
        HERE/('probe-block' if block else 'probe-control'),block)
    assert 'unrelatedLoaded=1' in (HERE/('probe-block' if block else 'probe-control')/'stdout.log').read_text(encoding='utf-8')
    probe_results.append(result)
(HERE/'probe-completion.json').write_text(json.dumps(probe_results,indent=2),encoding='utf-8')
proof=json.loads((WORK/'release-provenance.json').read_text(encoding='utf-8'))
results=[]
for index,block in enumerate((False,True,False,True),1):
    verify(ROOT,proof)
    out=HERE/('standard-'+str(index))
    environment=wait_and_record(HERE/('standard-'+str(index)+'.environment.json'))
    command=[ROOT/'build/ninja-msvc-release/AzurePlayer.exe','--project',WORK/'formal-performance/standard/project.azureproject',
        '--width','1920','--height','1080','--fixed-frame-step','--smoke-frames','2100',
        '--game-actions',WORK/'formal-performance/standard-1.input.json','--gpu-timing','--gpu-timing-output',out/'timing.json']
    result=execute(command,out,block)
    environment['final']=snapshot()
    (out/'environment.json').write_text(json.dumps(environment,indent=2),encoding='utf-8')
    data=json.loads((out/'timing.json').read_text(encoding='utf-8'))
    with (out/'timing.csv').open(encoding='utf-8',newline='') as stream:gpu=[float(row['frameMs']) for row in csv.DictReader(stream)][300:2100]
    assert len(gpu)==1800
    result.update(gpu=stats(gpu),cpu=stats(data['cpuFrame']['workSamplesMs'][300:]),
        sourceHash='fc5ea0a97abea1c180be8778ac4e0732e4cc56aea8242fdb013be344cdf5e851',
        released='Allocator after unload: buffers=0 images=0' in (out/'stdout.log').read_text(encoding='utf-8'))
    assert result['released'] and not result['obsModuleObserved']
    (out/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    results.append(result)
    (HERE/'diagnostic-partial.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('blockNvidiaCapture','observedLoadAttempts','deniedLoadAttempts','stableWorkingSetGrowth','gpu','cpu')}),flush=True)
    verify(ROOT,proof)
(HERE/'diagnostic-completion.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
