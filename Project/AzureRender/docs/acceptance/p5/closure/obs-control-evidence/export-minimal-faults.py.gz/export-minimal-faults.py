import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path.cwd().resolve()
WORK = ROOT / 'build/p5-observation-control-2026-10-11'
KIT = Path('C:/Program Files (x86)/Windows Kits/10/Windows Performance Toolkit')
deadline = time.monotonic() + 7200
while not (WORK / 'performance-followup-completion.json').exists():
    assert time.monotonic() < deadline, 'Diagnostic collection completion timeout'
    time.sleep(1)
record = json.loads((WORK / 'performance-followup-completion.json').read_text(encoding='utf-8'))
results = []
for entry in record['traces']:
    out = Path(entry['directory'])
    etl = out / 'memory.etl'
    def invoke(label, args):
        with (out / (label + '.log')).open('x', encoding='utf-8') as log:
            result = subprocess.run(list(map(str, args)), cwd=ROOT, stdout=log,
                stderr=subprocess.STDOUT, timeout=150)
        assert result.returncode == 0, (label, result.returncode)
    invoke('minimal-timespan', [KIT / 'xperf.exe', '-i', etl, '-o', out / 'trace-timespan.txt', '-a', 'tracestats', '-timespan'])
    invoke('minimal-statistics', [KIT / 'xperf.exe', '-i', etl, '-o', out / 'trace-statistics.txt', '-a', 'tracestats', '-detail', 'stack'])
    invoke('minimal-process', [KIT / 'xperf.exe', '-i', etl, '-o', out / 'processes.txt', '-a', 'process'])
    invoke('minimal-memory', [KIT / 'xperf.exe', '-i', etl, '-o', out / 'memory-events.csv', '-a', 'dumper', '-provider', '{3d6fa8d3-fe05-11d0-9dda-00c04fd7ba7c}'])
    invoke('minimal-probe', [sys.executable, ROOT / 'build/p5-system-trace-2026-10-11/validate-known-probe.py', out])
    measured = json.loads((out / 'result.json').read_text(encoding='utf-8'))
    target_name = 'AzureRender.exe' if entry['workload'] == 'editor' else 'AzurePlayer.exe'
    matches = [line for line in (out / 'processes.txt').read_text(encoding='utf-8-sig', errors='replace').splitlines() if target_name + ' (' in line]
    assert len(matches) == 1, matches
    pid = int(re.search(re.escape(target_name) + r' \((\d+)\)', matches[0]).group(1))
    invoke('minimal-fault-stack', [KIT / 'xperf.exe', '-i', etl, '-o', out / 'target-fault-stacks.html', '-a', 'stack', '-pid', pid, '-event', 'PageFault', '-butterfly', '1'])
    life = out / 'wpa-lifetimes'
    life.mkdir(exist_ok=False)
    invoke('minimal-lifetimes', [KIT / 'wpaexporter.exe', '-i', etl, '-profile', ROOT / 'build/p5-system-trace-2026-10-11/memory-lifetimes.wpaProfile', '-outputfolder', life])
    stats = (out / 'trace-timespan.txt').read_text(encoding='utf-8-sig')
    assert re.search(r'Total # Lost Buffers\s*:\s*0', stats)
    assert re.search(r'Total # Lost Events\s*:\s*0', stats)
    probe = json.loads((out / 'known-probe-analysis.json').read_text(encoding='utf-8'))
    assert probe['passed'] and probe['observedCommits'] == probe['observedReleases'] == 40
    result = dict(directory=str(out), pid=pid, executable=target_name, diagnosticOnly=True,
        formalFailureReproduced=entry['formalFailureReproduced'], stableWorkingSetGrowth=measured['stableWorkingSetGrowth'],
        lostEvents=0, lostBuffers=0, knownCommits=40, knownReleases=40)
    results.append(result)
    (WORK / 'minimal-export-partial.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(json.dumps(result), flush=True)
(WORK / 'minimal-export-completion.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
