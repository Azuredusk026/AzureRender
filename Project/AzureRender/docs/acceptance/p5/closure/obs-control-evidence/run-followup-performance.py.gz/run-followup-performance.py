import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path.cwd().resolve();WORK=ROOT/'build/p5-observation-control-2026-10-11'
OLD=ROOT/'build/p5-directory-reclamation-2026-10-11'
sys.path.insert(0,str(ROOT/'tools'))
from build_provenance import verify
from run_playable_performance import run
assert not ctypes.windll.shell32.IsUserAnAdmin()
deadline=time.monotonic()+7200
while True:
    if (WORK/'failure.json').exists():
        raise RuntimeError('Resolve current candidate acceptance failure before formal measurement')
    records=json.loads((WORK/'status.json').read_text(encoding='utf-8')) if (WORK/'status.json').exists() else []
    if any(row['name']=='platformer-longrun' for row in records):break
    assert time.monotonic()<deadline,'Current platform long-run completion timeout'
    time.sleep(1)
proof=json.loads((WORK/'release-provenance.json').read_text(encoding='utf-8'));verify(ROOT,proof)
os.environ['DISABLE_VULKAN_OBS_CAPTURE']='1'
with (WORK/'obs-layer-control.log').open('w',encoding='utf-8') as log:
    control=subprocess.run([sys.executable,str(WORK/'verify-obs-layer-exclusion.py')],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
assert control.returncode==0,'Verify effective OBS layer exclusion before the control measurements'
verify(ROOT,proof)
formal=WORK/'formal-performance'
with (WORK/'formal-performance.log').open('w',encoding='utf-8') as log:
    result=subprocess.run([sys.executable,str(ROOT/'tools/run_playable_performance.py'),
        '--player',str(ROOT/'build/ninja-msvc-release/AzurePlayer.exe'),
        '--editor',str(ROOT/'build/ninja-msvc-release/AzureRender.exe'),
        '--exploration',str(ROOT/'assets_public/exploration/project.azureproject'),
        '--platformer',str(ROOT/'assets_public/platformer/project.azureproject'),'--output',str(formal)],
        cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
verify(ROOT,proof)
(WORK/'formal-completion.json').write_text(json.dumps(dict(exitCode=result.returncode,
    environment={'DISABLE_VULKAN_OBS_CAPTURE':'1'},obsLayerExclusionVerified=True),indent=2),encoding='utf-8')
summary=json.loads((formal/'summary.json').read_text(encoding='utf-8'))
loads=[name for name,rounds in summary['rounds'].items() if any(
    any('stableWorkingSetGrowth:' in error for error in row.get('budgetFailures',[])) for row in rounds)]
# Collect allocation and fault stacks with the frozen 50 ms measurement entry.
# Working-set snapshot providers are omitted to reduce diagnostic overhead.
control=(OLD/'control-pagefault-session.ps1').read_text(encoding='utf-8')
(WORK/'control-pagefault-session.ps1').write_text(control,encoding='utf-8')
profile=(OLD/'azure-pagefaults.wprp').read_text(encoding='utf-8').replace('        <Keyword Value="MemoryInfo" />\n','').replace('        <Keyword Value="MemoryInfoWS" />\n','')
(WORK/'azure-pagefaults.wprp').write_text(profile,encoding='utf-8')
traces=[]
for name in loads:
    for attempt in range(1,4):
        verify(ROOT,proof);out=WORK/('minimal-fault-'+name+'-'+str(attempt));out.mkdir(exist_ok=False)
        project=formal/name/'project.azureproject'
        for relative,digest in summary['sceneHashes'][name].items():
            assert hashlib.sha256((project.parent/relative).read_bytes()).hexdigest()==digest,relative
        method=WORK/'control-pagefault-session.ps1'
        launch=subprocess.run(['powershell.exe','-NoProfile','-Command',
            'Start-Process -FilePath powershell.exe -Verb RunAs -WindowStyle Hidden -ArgumentList '+
            "@('-NoProfile','-ExecutionPolicy','Bypass','-File','"+str(method)+"','-OutputDirectory','"+str(out)+"')"],capture_output=True,text=True)
        assert launch.returncode==0
        started=time.monotonic()
        while not (out/'ready.json').exists():
            assert not (out/'control-completion.json').exists(),'Owned trace startup failed'
            assert time.monotonic()-started<60,'Owned trace startup timeout'
            time.sleep(.1)
        try:
            if name=='editor':os.environ['AZURERENDER_EDITOR_CONFIG']=str(out/'editor-config')
            measured=run(ROOT/'build/ninja-msvc-release'/('AzureRender.exe' if name=='editor' else 'AzurePlayer.exe'),
                project,out/'measurement',editor=name=='editor',stress=name=='stress')
            measured.update(diagnosticOnly=True,formalAcceptance=False,sourceHash=summary['sourceHash'],
                eventStacks=True,memoryInfoSnapshots=False)
            (out/'result.json').write_text(json.dumps(measured,indent=2),encoding='utf-8')
            subprocess.run([sys.executable,str(ROOT/'build/p5-system-trace-2026-10-11/known-allocation-probe.py'),str(out/'known-probe.json')],check=True)
            traces.append(dict(workload=name,attempt=attempt,directory=str(out),growth=measured['stableWorkingSetGrowth'],
                formalFailureReproduced=measured['stableWorkingSetGrowth']>.05))
        finally:
            (out/'workload-finished.json').write_text('{}',encoding='utf-8')
            stopped=time.monotonic()
            while not (out/'control-completion.json').exists():
                assert time.monotonic()-stopped<120,'Owned trace completion timeout'
                time.sleep(.2)
            assert json.loads((out/'control-completion.json').read_text(encoding='utf-8-sig'))['exitCode']==0
        verify(ROOT,proof)
        (WORK/'minimal-fault-partial.json').write_text(json.dumps(traces,indent=2),encoding='utf-8')
        print(json.dumps(traces[-1]),flush=True)
        if traces[-1]['formalFailureReproduced']:break
(WORK/'performance-followup-completion.json').write_text(json.dumps(dict(formalExitCode=result.returncode,
    formalFailedMemoryLoads=loads,traces=traces,rootCauseResolved=False),indent=2),encoding='utf-8')
