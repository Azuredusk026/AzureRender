/* Diagnostic only: one optional module in an owned child, with a paired control. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wchar.h>
#include <stdlib.h>
#include "MinHook.h"
typedef struct AzureUnicodeString { USHORT length, capacity; PWSTR buffer; } AzureUnicodeString;
typedef LONG (NTAPI *LoadDll)(PWSTR, ULONG *, AzureUnicodeString *, void **);
static LoadDll realLoad;
static volatile LONG observed, denied;
static int block;
static LONG NTAPI controlledLoad(PWSTR search, ULONG *flags, AzureUnicodeString *name, void **module) {
    static const wchar_t target[] = L"nvspcap64.dll";
    if (name && name->buffer && !(name->length % sizeof(wchar_t))) {
        size_t count = name->length / sizeof(wchar_t), begin = count;
        while (begin && name->buffer[begin-1] != L'\\' && name->buffer[begin-1] != L'/') --begin;
        if (count-begin == _countof(target)-1 && !_wcsnicmp(name->buffer+begin, target, count-begin)) {
            InterlockedIncrement(&observed);
            if (block) {
                InterlockedIncrement(&denied);
                if (module) *module = NULL;
                return (LONG)0xc0000135; /* STATUS_DLL_NOT_FOUND */
            }
        }
    }
    return realLoad(search, flags, name, module);
}
__declspec(dllexport) DWORD WINAPI AzureOverlayStart(void *parameter) {
    block = parameter != NULL;
    HMODULE native = GetModuleHandleW(L"ntdll.dll");
    void *entry = (void *)GetProcAddress(native, "LdrLoadDll");
    if (!entry || MH_Initialize() != MH_OK) return 1;
    if (MH_CreateHook(entry, controlledLoad, (void **)&realLoad) != MH_OK) return 2;
    if (MH_EnableHook(entry) != MH_OK) return 3;
    return 0;
}
__declspec(dllexport) DWORD WINAPI AzureOverlayObserved(void *unused) { (void)unused; return (DWORD)observed; }
__declspec(dllexport) DWORD WINAPI AzureOverlayDenied(void *unused) { (void)unused; return (DWORD)denied; }
BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) DisableThreadLibraryCalls(instance);
    return TRUE;
}
