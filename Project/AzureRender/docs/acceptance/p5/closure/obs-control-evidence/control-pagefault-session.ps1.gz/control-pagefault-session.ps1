param([Parameter(Mandatory=$true)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
$taskOutput=[IO.Path]::GetFullPath($OutputDirectory)
if(-not $taskOutput.StartsWith($PSScriptRoot+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Output must stay within the diagnostic directory'}
$taskPrincipal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
if(-not $taskPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator token required'}
$taskSession='AzureP5Coordinated_'+[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
$taskWpr=Join-Path $env:SystemRoot 'System32/wpr.exe'
$taskStarted=$false
$taskExit=1
try {
    $taskStart=Start-Process -FilePath $taskWpr -ArgumentList @('-start',((Join-Path $PSScriptRoot 'azure-pagefaults.wprp')+'!AzureMemory'),'-filemode','-instancename',$taskSession) -WindowStyle Hidden -Wait -PassThru -RedirectStandardOutput (Join-Path $taskOutput 'wpr-start.log') -RedirectStandardError (Join-Path $taskOutput 'wpr-start-error.log')
    if($taskStart.ExitCode -ne 0){throw ('WPR start failed: '+$taskStart.ExitCode)}
    $taskStarted=$true
    @{administrator=$true;processId=$PID;session=$taskSession;workloadElevated=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskOutput 'ready.json') -Encoding utf8
    $taskClock=[Diagnostics.Stopwatch]::StartNew()
    while(-not (Test-Path -LiteralPath (Join-Path $taskOutput 'workload-finished.json'))){
        if($taskClock.Elapsed.TotalSeconds -gt 300){throw 'Owned workload completion timed out'}
        Start-Sleep -Milliseconds 100
    }
    $taskExit=0
} catch {
    $_ | Out-String | Set-Content -LiteralPath (Join-Path $taskOutput 'control-failure.log') -Encoding utf8
} finally {
    if($taskStarted){
        $taskStop=Start-Process -FilePath $taskWpr -ArgumentList @('-stop',('"'+(Join-Path $taskOutput 'memory.etl')+'"'),'-instancename',$taskSession) -WindowStyle Hidden -Wait -PassThru -RedirectStandardOutput (Join-Path $taskOutput 'wpr-stop.log') -RedirectStandardError (Join-Path $taskOutput 'wpr-stop-error.log')
        if($taskStop.ExitCode -ne 0){$taskExit=1}
    }
    @{administrator=$true;session=$taskSession;exitCode=$taskExit;traceStarted=$taskStarted} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskOutput 'control-completion.json') -Encoding utf8
}
exit $taskExit
