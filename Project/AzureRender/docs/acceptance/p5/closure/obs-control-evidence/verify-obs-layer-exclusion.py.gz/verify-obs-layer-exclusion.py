import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT=Path.cwd().resolve();WORK=ROOT/'build/p5-observation-control-2026-10-11'
out=WORK/'obs-layer-control';out.mkdir(exist_ok=False)
manifest=Path('C:/ProgramData/obs-studio-hook/obs-vulkan64.json')
layer=json.loads(manifest.read_text(encoding='utf-8'))['layer']
assert layer['name']=='VK_LAYER_OBS_HOOK' and layer['disable_environment']=={'DISABLE_VULKAN_OBS_CAPTURE':'1'}
shutil.copytree(ROOT/'build/p5-directory-reclamation-2026-10-11/formal-performance/standard',
    out/'project',ignore=shutil.ignore_patterns('.azure'))
kernel=ctypes.WinDLL('kernel32',use_last_error=True);psapi=ctypes.WinDLL('psapi',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.CloseHandle.argtypes=[wintypes.HANDLE]
psapi.EnumProcessModulesEx.argtypes=[wintypes.HANDLE,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(wintypes.DWORD),wintypes.DWORD]
psapi.GetModuleBaseNameW.argtypes=[wintypes.HANDLE,wintypes.HMODULE,wintypes.LPWSTR,wintypes.DWORD]
def modules(pid):
    handle=kernel.OpenProcess(0x410,False,pid)
    if not handle:raise ctypes.WinError(ctypes.get_last_error())
    try:
        capacity=512;data=(wintypes.HMODULE*capacity)();needed=wintypes.DWORD()
        assert psapi.EnumProcessModulesEx(handle,data,ctypes.sizeof(data),ctypes.byref(needed),3)
        assert needed.value<=ctypes.sizeof(data),'Module inventory exceeds capacity'
        names=[]
        for index in range(needed.value//ctypes.sizeof(wintypes.HMODULE)):
            text=ctypes.create_unicode_buffer(512)
            assert psapi.GetModuleBaseNameW(handle,data[index],text,512)
            names.append(text.value)
        return names
    finally:kernel.CloseHandle(handle)
timing=out/'timing.json';info=subprocess.STARTUPINFO();info.dwFlags|=subprocess.STARTF_USESHOWWINDOW;info.wShowWindow=0
command=[str(ROOT/'build/ninja-msvc-release/AzurePlayer.exe'),'--project',str(out/'project/project.azureproject'),
    '--width','1920','--height','1080','--smoke-frames','2100','--fixed-frame-step','--gpu-timing','--gpu-timing-output',str(timing)]
with (out/'stdout.log').open('w',encoding='utf-8') as stdout,(out/'stderr.log').open('w',encoding='utf-8') as stderr:
    process=subprocess.Popen(command,cwd=ROOT,env=dict(os.environ,DISABLE_VULKAN_OBS_CAPTURE='1'),
        startupinfo=info,stdout=stdout,stderr=stderr)
    try:
        deadline=time.monotonic()+60;csv_path=timing.with_suffix('.csv')
        while not csv_path.exists() or csv_path.stat().st_size<100:
            assert process.poll() is None,'Player exited before module observation'
            assert time.monotonic()<deadline,'Rendering observation timeout'
            time.sleep(.05)
        names=modules(process.pid)
        assert any(name.lower()=='vulkan-1.dll' for name in names),'Vulkan loader must be observed'
        absent=not any('graphics-hook' in name.lower() for name in names)
        result=dict(diagnosticOnly=True,formalAcceptance=False,pid=process.pid,
            sourceHash='fc5ea0a97abea1c180be8778ac4e0732e4cc56aea8242fdb013be344cdf5e851',
            environment={'DISABLE_VULKAN_OBS_CAPTURE':'1'},implicitLayer=layer,
            implicitLayerManifestSha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
            moduleNames=names,obsModuleAbsent=absent,registryChanged=False)
        (out/'module-inventory.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        assert absent,'OBS module exclusion failed'
        assert process.wait(timeout=60)==0
        assert 'Allocator after unload: buffers=0 images=0' in (out/'stdout.log').read_text(encoding='utf-8')
    finally:
        if process.poll() is None:process.kill();process.wait()
print(json.dumps(dict(obsModuleAbsent=True,modules=len(names),registryChanged=False)))
