#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
int wmain(int argc, wchar_t **argv) {
    if (argc != 3) return 2;
    HMODULE allowed = LoadLibraryW(L"version.dll");
    HMODULE capture = LoadLibraryW(argv[1]);
    int expected = _wtoi(argv[2]);
    printf("unrelatedLoaded=%d captureLoaded=%d expectedCapture=%d\n",allowed != NULL,capture != NULL,expected);
    Sleep(300);
    if (capture) FreeLibrary(capture);
    if (allowed) FreeLibrary(allowed);
    return (!allowed || (capture != NULL) != expected) ? 1 : 0;
}
