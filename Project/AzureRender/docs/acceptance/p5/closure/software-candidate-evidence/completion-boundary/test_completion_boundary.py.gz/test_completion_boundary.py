import argparse,copy,importlib.util,json,sys,unittest
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'tools'))
p=argparse.ArgumentParser();p.add_argument('--controller-path',type=Path,default=root/'tools/run_platformer_long_run.py');a,remaining=p.parse_known_args()
spec=importlib.util.spec_from_file_location('tested_platformer_controller',a.controller_path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
observed=json.loads((Path(__file__).parent/'observed-completion.json').read_text(encoding='utf-8'))
platforms=json.loads((root/'assets_public/platformer/PLATFORMER-DESIGN.json').read_text(encoding='utf-8'))['platforms']
class Harness(m.PlatformerScenario):
 def __init__(self,state):
  super().__init__();self.state=state;self.address={};self.phase='jump';self.phaseStarted=361.68;self.index=6;self.platforms=platforms;self.keys={87};self.events=[]
 def call(self,op,**fields):
  assert op=='query' and fields['name']=='game.state'
  return json.dumps(self.state)
 def input(self,**event):self.events.append(event)
 def event(self,kind,**fields):pass
class CompletionBoundary(unittest.TestCase):
 def state(self):return copy.deepcopy(observed['value'])
 def test_observed_terminal_stop_still_requires_final_landing(self):
  scenario=Harness(self.state());scenario._update(363.24)
  self.assertEqual(scenario.phase,'land');self.assertEqual(scenario.counts['mandatoryLandings'],0)
  scenario._update(363.4);self.assertEqual(scenario.index,7);self.assertEqual(scenario.counts['mandatoryLandings'],1);self.assertEqual(scenario.phase,'finish')
  scenario._update(363.6);self.assertEqual(scenario.counts['completedRoutes'],1)
 def test_airborne_completion_cannot_count_as_landing(self):
  state=self.state();state['characters'][0]['grounded']=False;scenario=Harness(state)
  scenario._update(363.24);scenario._update(363.4)
  self.assertEqual(scenario.counts['mandatoryLandings'],0);self.assertEqual(scenario.counts['completedRoutes'],0)
 def test_completion_outside_existing_landing_tolerance_is_rejected(self):
  state=self.state();state['characters'][0]['position'][2]=platforms[7]['z']+1.;scenario=Harness(state)
  scenario._update(363.24);scenario._update(363.4)
  self.assertEqual(scenario.counts['mandatoryLandings'],0);self.assertEqual(scenario.counts['completedRoutes'],0)
 def test_nonterminal_jump_keeps_position_condition(self):
  state=self.state();state['tasks'][0]['completed']=False;scenario=Harness(state);scenario._update(363.24)
  self.assertEqual(scenario.phase,'jump');self.assertEqual(scenario.counts['mandatoryLandings'],0)
if __name__=='__main__':unittest.main(argv=[sys.argv[0],*remaining])
