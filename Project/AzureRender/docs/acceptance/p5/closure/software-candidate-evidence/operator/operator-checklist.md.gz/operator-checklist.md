# 候选包人工复核操作单

> 文档类型：本机验收操作单
> 状态：发布链机器检查通过，人工结果待填写
> 源码基点：`5a8e7d79b2ceb0f9e2d910698d09357ac76e495f`

## 使用条件

正式性能、根因归因和长跑分别维护状态。
操作前核对本轮测量汇总与候选来源。
实体操作、制作效率和听感由操作者记录。
自动输入结果按其实际覆盖范围使用。

## 进入编辑器

使用 PowerShell 启动候选编辑器。
通过项目入口创建两个新的制作项目。
验收项目放入独立目录，保留候选包原件。

```powershell
& "D:/Assigment/2609/FYP/Project/AzureRender/build/p5-p6-delivery-investigation-2026-10-11/final-delivery/Moved Engine/bin/AzureRender.exe" --editor-project "D:/Assigment/2609/FYP/Project/AzureRender/build/p5-p6-delivery-investigation-2026-10-11/final-delivery/Moved scene_inspector/game/project.azureproject"
```

制作步骤见[从空关卡制作并发布游戏](D:/Assigment/2609/FYP/Project/AzureRender/docs/tutorials/editor-first-game.md)。
实体检查见[键鼠与音效复核表](D:/Assigment/2609/FYP/Project/AzureRender/docs/acceptance/p5/physical-input.md)。
制作任务见[P6 制作验收表](D:/Assigment/2609/FYP/Project/AzureRender/docs/acceptance/p6/2026-10-10.md)。
两份表中的未执行项由实际结果填写。

## 完整游戏与听感

启动探索包，实际通关并进入平台关卡。
使用 WASD、Shift、Space、E 和 R 操作。
检查必经跳跃、金币、承载、掉落及终点。
五类音效分别记录辨识度、音量和重复触发。

```powershell
& "D:/Assigment/2609/FYP/Project/AzureRender/build/p5-p6-delivery-investigation-2026-10-11/final-delivery/Moved exploration/start-game.cmd"
```

## 制作效率与反馈

两工作流分别记录步骤、耗时与误操作恢复。
依据首轮实际数据填写效率目标。
目标登记后执行复核并记录结果。
发现问题时记录触发步骤与可观察结果。

结果模板为[feedback-template.json](D:/Assigment/2609/FYP/Project/AzureRender/build/p5-p6-delivery-investigation-2026-10-11/operator-review/feedback-template.json)。
另存填写结果，保留原模板中的待验状态。
记录操作者、设备、显示缩放和声音输出。
每项填写通过、失败或未执行。

## 候选包来源

| 产物 | SHA-256 |
| --- | --- |
| engine | `642ad9e503f6dc93a0b170b177295e2ed5b60ebc152175789412428566a0aa8b` |
| exploration | `ca554cf82fb29ef797b3ea6d1edf873f871aab17940e961b4a8579a4c820ff45` |
| platformer | `b41a346fa7e8a1d8ed6ac9541503dcf7b078938aba70dc507a24db5118d8e6ee` |
| scene_inspector | `ce94634ceea907dcfb33b0ac1ecc001d2c14237c61f3d37fc6c6de9132ef8d02` |
| authored-exploration | `66c96ed7a8cd22aec4c7acc3af826f26a9c83de7adbe11d3e0afedd4f43397d7` |
| authored-inspection | `be90632607c033c50f0eb899f6ae27a96dfad7dc3c2f4334a9fdaf401e763ce9` |

包清单见[发布来源](D:/Assigment/2609/FYP/Project/AzureRender/build/p5-p6-delivery-investigation-2026-10-11/final-delivery/packages/provenance.json)。
源码原字节归档见[构建输入](D:/Assigment/2609/FYP/Project/AzureRender/build/p5-p6-closure-candidate-2026-10-11/final-candidate-source.json)。
人工结果只适用于表中记录的具体候选包。
