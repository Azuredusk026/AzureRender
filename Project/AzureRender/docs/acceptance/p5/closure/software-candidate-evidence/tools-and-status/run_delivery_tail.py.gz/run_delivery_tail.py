import json,os,subprocess,sys,time
from pathlib import Path
root=Path.cwd().resolve();out=root/'build/p5-p6-delivery-investigation-2026-10-11'
cmake=Path('D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin')
os.environ['PATH']=str(cmake)+os.pathsep+os.environ['PATH'];sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify
frozen=inputs(root);verify(root,json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text(encoding='utf-8')))
steps=[]
def run(name,args):
 with (out/(name+'.log')).open('w',encoding='utf-8') as log:
  result=subprocess.run(list(map(str,args)),cwd=root,stdout=log,stderr=subprocess.STDOUT)
 assert inputs(root)==frozen
 steps.append(dict(name=name,exitCode=result.returncode))
 (out/'tail-status.json').write_text(json.dumps(steps,indent=2)+'\n',encoding='utf-8')
 print(name,'exit',result.returncode,flush=True)
 return result.returncode==0
deadline=time.monotonic()+1800
while not (out/'final-delivery/summary.json').is_file():
 assert time.monotonic()<deadline,'Delivery did not complete; retain original logs'
 time.sleep(1)
assert json.loads((out/'final-delivery/summary.json').read_text(encoding='utf-8'))['passed']
run('platformer-probe',[sys.executable,root/'tools/run_platformer_long_run.py','--package',out/'final-delivery/Moved exploration','--output',out/'platformer-probe','--seconds','120','--probe'])
from test_level_cycles import prepare
from build_game import build_game,verify_package
source=out/'standard-source';standard=out/'Moved standard'
prepare(source);build_game(source/'project.azureproject',out/'final-delivery/Moved Engine',standard)
source.rename(out/'Unavailable standard source');verify_package(standard)
run('platformer-longrun',[sys.executable,root/'tools/run_platformer_long_run.py','--package',out/'final-delivery/Moved exploration','--output',out/'platformer-longrun','--seconds','1800'])
run('standard-longrun',[sys.executable,root/'tools/run_playable_long_run.py','--package',standard,'--output',out/'standard-longrun','--seconds','1800'])
run('operator-packet',[sys.executable,out/'create_operator_packet.py'])
raise SystemExit(int(any(s['exitCode'] for s in steps)))
