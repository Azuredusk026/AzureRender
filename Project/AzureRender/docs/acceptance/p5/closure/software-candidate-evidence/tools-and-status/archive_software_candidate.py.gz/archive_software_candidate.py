import gzip,hashlib,json
from pathlib import Path
root=Path.cwd().resolve();prior=root/'build/p5-p6-closure-candidate-2026-10-11';work=root/'build/p5-p6-delivery-investigation-2026-10-11'
out=root/'docs/acceptance/p5/closure/software-candidate-evidence';out.mkdir(exist_ok=False)
selected={}
def add(path,label):
 assert path.is_file(),path
 assert label not in selected,label
 selected[label]=path
for name in ('final-regression-inventory.json','barrier-release-gpu.log','barrier-debug-gpu.log','final-release-native-gpu.log','final-debug-native-gpu.log','final-delivery.log','prior-performance-product-comparison.json','prior-performance-reanalysis.json','system-trace-token-capabilities.json','system-trace-precondition.json','frozen-inputs.json'):
 add(prior/name,'initial/'+name)
for name in ('audit.json','evidence.json','runtime.json','stdout.log','stderr.log'):
 add(prior/'authoring-installed/inspection-create'/name,'original-project-rename-failure/'+name)
for folder,base in [('source-authoring',prior/'authoring-final'),('installed-authoring',work/'authoring-installed')]:
 if not base.exists() and folder=='source-authoring':
  base=prior/'authoring'
 assert base.is_dir(),base
 for path in base.rglob('*'):
  if path.is_file() and path.name in ('summary.json','partial.json','audit.json','evidence.json','stdout.log','stderr.log'):
   add(path,folder+'/'+path.relative_to(base).as_posix())
for name in ('final_delivery.py','authoring_installed.py','run_delivery_tail.py','investigation-reason.json','formal-exploration-private-correlation.json','tail-status.json','completion-recheck-status.json','run_completion_recheck.py','release-measured-provenance.json','debug-measured-provenance.json','create_operator_packet.py','archive_software_candidate.py'):
 add(work/name,'tools-and-status/'+name)
delivery=work/'final-delivery'
for path in delivery.glob('*.log'):add(path,'delivery/'+path.name)
for name in ('summary.json','partial.json'):add(delivery/name,'delivery/'+name)
add(delivery/'packages/provenance.json','delivery/provenance.json')
for name in ('engine','exploration','platformer','scene_inspector','authored-exploration','authored-inspection'):
 package=delivery/('Moved Engine' if name=='engine' else 'Moved '+name)
 manifest='install_manifest.json' if name=='engine' else 'game_manifest.json'
 add(package/manifest,'package-manifests/'+name+'.json')
for name in ('platformer-probe','platformer-longrun','standard-longrun','completion-probe','completion-longrun','completion-boundary','background-probe','background-longrun','background-route'):
 base=work/name
 for path in base.iterdir():
  if path.is_file() and path.suffix in ('.json','.jsonl','.log','.csv','.py'):
   add(path,name+'/'+path.name)
for name in ('feedback-template.json','operator-checklist.md'):add(work/'operator-review'/name,'operator/'+name)
for config in ('release','debug'):add(root/('build/ninja-msvc-'+config)/'build-provenance.json','provenance/'+config+'.json')
for name in ('sync_completion_controller.py','verify_tool_sync.py','tool-sync-verification.json','tool-sync-build.log','release-platformer-rules.log','debug-platformer-rules.log','package-recheck.json','update_software_docs.py','stage_software_candidate.py'):
 add(work/name,'final-tool-verification/'+name)
for name in ('production-red.log','production-green.log','production-sync.json','production-test-addition.txt'):
 add(work/'completion-boundary'/name,'final-tool-verification/'+name)
add(root/'tools/run_platformer_long_run.py','final-tool-verification/run_platformer_long_run.py')
add(root/'tools/test_platformer_long_run.py','final-tool-verification/test_platformer_long_run.py')
add(root/'tests/fixtures/platformer-terminal-stop.json','final-tool-verification/platformer-terminal-stop.json')
add(root/'tests/fixtures/platformer-background-scan.json','final-tool-verification/platformer-background-scan.json')
for name in ('test_background_route.py','run_background_recheck.py','background-recheck-status.json','prepare_background_evidence.py','final_software_checks.py','create_software_certificate.py','delivery-certificate.json','inspect_project_failure.py','project-rename-failure-analysis.json'):
 add(work/name,'final-tool-verification/'+name)
files={}
for label,path in selected.items():
 raw=path.read_bytes();stored=gzip.compress(raw,mtime=0);name=label+'.gz';target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(stored)
 assert gzip.decompress(target.read_bytes())==raw
 files[name]=dict(source=path.relative_to(root).as_posix(),originalBytes=len(raw),storedBytes=len(stored),originalSha256=hashlib.sha256(raw).hexdigest(),sha256=hashlib.sha256(stored).hexdigest(),compressed=True)
manifest=dict(schemaVersion=1,sourceHash='126d7d78297476f6e35aa11250213bddeb8f7d1e5a24a5af1952815ecfee257d',regressionTotal=454,deliveryChecks=10,physicalInputVerified=False,subjectiveAudioVerified=False,formalPerformancePassed=False,originalProjectRenameFailureRetained=True,files=files)
manifest['toolSync']=json.loads((work/'tool-sync-verification.json').read_text(encoding='utf-8'))
manifest['standardLongRun']=json.loads((work/'standard-longrun/summary.json').read_text(encoding='utf-8'))['status']
manifest['correctedPlatformLongRun']=json.loads((work/'background-longrun/summary.json').read_text(encoding='utf-8'))['status']
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Verified',len(files),'original-byte files;',sum(x['storedBytes'] for x in files.values()),'stored bytes')
