import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path.cwd().resolve();out=root/'build/p5-p6-delivery-investigation-2026-10-11';controller=out/'completion-boundary/run_platformer_long_run.py'
original=hashlib.sha256(controller.read_bytes()).hexdigest();status=out/'completion-recheck-status.json';steps=[]
def run(name,directory,seconds,probe=False):
 env=dict(os.environ,PYTHONPATH=str(root/'tools'))
 args=[sys.executable,str(controller),'--package',str(out/'final-delivery/Moved exploration'),'--output',str(out/directory),'--seconds',str(seconds)]
 if probe:args.append('--probe')
 with (out/(name+'.log')).open('w',encoding='utf-8') as log:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert hashlib.sha256(controller.read_bytes()).hexdigest()==original
 steps.append(dict(name=name,exitCode=r.returncode,controllerSha256=original,seconds=seconds))
 status.write_text(json.dumps(steps,indent=2)+'\n',encoding='utf-8');print(name,'exit',r.returncode,flush=True)
 return r.returncode==0
deadline=time.monotonic()+3600
while True:
 data=json.loads((out/'tail-status.json').read_text(encoding='utf-8'))
 if any(r['name']=='standard-longrun' for r in data):break
 assert time.monotonic()<deadline,'Standard run did not finish'
 time.sleep(1)
if not run('completion-probe','completion-probe',120,True):raise SystemExit(1)
if not run('completion-longrun','completion-longrun',1800):raise SystemExit(1)
print('Corrected public-input controller completed. Production tool synchronization remains required.',flush=True)
