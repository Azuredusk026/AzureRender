import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve();out=root/'build/p5-p6-delivery-investigation-2026-10-11';prior=root/'build/p5-p6-closure-candidate-2026-10-11'
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs
assert inputs(root)==json.loads((prior/'frozen-inputs.json').read_text(encoding='utf-8'))
assert json.loads((out/'standard-longrun/summary.json').read_text(encoding='utf-8'))['status']=='passed'
measured=json.loads((out/'background-longrun/summary.json').read_text(encoding='utf-8'))
# This commit verifies the input controller independently. The aggregate
# residency gate stays failed and its original summary is never rewritten.
assert measured['status']=='failed' and measured['actualSeconds']>=1800
assert not measured['controllerErrors'] and measured['completedRoutes']==81
assert measured['mandatoryLandings']>=measured['completedRoutes']*7
assert all(measured[k]>=measured['completedRoutes'] for k in ('startFallRecoveries','checkpointFallRecoveries','horizontalRides','verticalRides'))
assert measured['courseCoins']==8 and measured['released'] and measured['exitCode']==0
assert measured['residencyGrowth']['buffers']>.05
controller=root/'tools/run_platformer_long_run.py';corrected=out/'background-route/run_platformer_long_run.py';test=root/'tools/test_platformer_long_run.py'
originalController=controller.read_bytes();originalTest=test.read_bytes()
anchor="            if position[2]<=target['z']+.35:\n"
replacement="            # A completed goal disables movement before the controller's\n            # stop point. Keep the existing grounded landing check.\n            terminal_stop=self.index==6 and state['tasks'][0]['completed']\n            if position[2]<=target['z']+.35 or terminal_stop:\n"
assert originalController.decode('utf-8').replace('\r\n','\n').count(anchor)==1
candidate=originalController.decode('utf-8').replace('\r\n','\n').replace(anchor,replacement,1)
scanAnchor="        if state['loading']:return\n        assert state['levelReference']==self.course"
scanReplacement="        # Background asset scans keep the current world running. Scene\n        # switches wait in the explicit preloading/loading phases above.\n        assert state['levelReference']==self.course"
assert candidate.count(scanAnchor)==1
assert candidate.replace(scanAnchor,scanReplacement,1)==corrected.read_text(encoding='utf-8')
fixture=root/'tests/fixtures/platformer-terminal-stop.json';fixture.parent.mkdir(parents=True,exist_ok=True)
scanFixture=root/'tests/fixtures/platformer-background-scan.json'
for destination,source in [(fixture,out/'completion-boundary/observed-completion.json'),(scanFixture,out/'background-route/observed-scan.json')]:
 if destination.exists():assert destination.read_bytes()==source.read_bytes()
 else:shutil.copy2(source,destination)
text=originalTest.decode('utf-8').replace('\r\n','\n');anchorMain="if __name__=='__main__':unittest.main()";assert text.count(anchorMain)==1
addition=(out/'completion-boundary/production-test-addition.txt').read_text(encoding='utf-8')+'\n'+(out/'background-route/production-test-addition.txt').read_text(encoding='utf-8')
text=text.replace(anchorMain,addition+'\n'+anchorMain)
test.write_text(text,encoding='utf-8')
def check(name):
 with (out/'completion-boundary'/name).open('w',encoding='utf-8') as log:r=subprocess.run([sys.executable,test],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 return r.returncode
assert check('production-red.log')!=0,'Original controller must reproduce the recorded terminal stop'
red=(out/'completion-boundary/production-red.log').read_text(encoding='utf-8')
assert 'FAILED (failures=4)' in red and 'ERROR:' not in red,red
controller.write_bytes(corrected.read_bytes());assert check('production-green.log')==0
green=(out/'completion-boundary/production-green.log').read_text(encoding='utf-8')
assert 'Ran 21 tests' in green and 'OK' in green,green
assert controller.read_bytes()==corrected.read_bytes()
(out/'completion-boundary/production-sync.json').write_text(json.dumps(dict(originalControllerSha256=hashlib.sha256(originalController).hexdigest(),originalTestSha256=hashlib.sha256(originalTest).hexdigest(),correctedControllerSha256=hashlib.sha256(controller.read_bytes()).hexdigest(),recheckControllerSha256=hashlib.sha256(corrected.read_bytes()).hexdigest(),byteEquivalent=True,declaredRuleTests=14,discoveredTests=21,sourceAfter=inputs(root)),indent=2)+'\n',encoding='utf-8')
print('Production controller matches the measured correction byte for byte; fourteen route rules and seven shared rules pass.')
