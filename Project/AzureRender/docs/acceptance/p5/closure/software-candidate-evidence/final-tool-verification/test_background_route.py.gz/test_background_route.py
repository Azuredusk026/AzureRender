import argparse,copy,importlib.util,json,sys,unittest
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'tools'))
p=argparse.ArgumentParser();p.add_argument('--controller',type=Path,required=True);args,rest=p.parse_known_args()
spec=importlib.util.spec_from_file_location('background_route_controller',args.controller);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
work=root/'build/p5-p6-delivery-investigation-2026-10-11'
observed=json.loads((work/'background-route/observed-scan.json').read_text(encoding='utf-8'))
platforms=json.loads((root/'assets_public/platformer/PLATFORMER-DESIGN.json').read_text(encoding='utf-8'))['platforms']
class Harness(module.PlatformerScenario):
 def __init__(self):
  super().__init__();self.address={};self.phase='jump';self.phaseStarted=1613.8;self.index=0;self.platforms=platforms;self.keys={87};self.events=[];self.state=copy.deepcopy(observed['value'])
 def call(self,op,**fields):
  assert op=='query' and fields['name']=='game.state';return json.dumps(self.state)
 def input(self,**event):self.events.append(event)
 def event(self,*args,**fields):pass
class BackgroundRoute(unittest.TestCase):
 def test_active_world_stops_at_target_during_background_scan(self):
  h=Harness();h._update(observed['seconds']);self.assertEqual(h.phase,'land');self.assertNotIn(87,h.keys)
  self.assertEqual(h.counts['mandatoryLandings'],0)
 def test_background_scan_preserves_existing_grounded_landing_rule(self):
  h=Harness();h.phase='land';h._update(observed['seconds']);self.assertEqual(h.index,1);self.assertEqual(h.counts['mandatoryLandings'],1)
 def test_actual_preload_still_waits_before_scene_switch(self):
  h=Harness();h.phase='preloading';h.desired=h.exploration;h._update(observed['seconds']);self.assertEqual(h.phase,'preloading');self.assertFalse(h.events)
 def test_actual_loading_still_waits_before_route_start(self):
  h=Harness();h.phase='loading';h.desired=h.course;h.oldRevision=h.state['levelRevision']-1;h.nextPhase='start';h._update(observed['seconds']);self.assertEqual(h.phase,'loading');self.assertFalse(h.events)
 def test_airborne_background_scan_cannot_count_a_landing(self):
  h=Harness();h.phase='land';h.state['characters'][0]['grounded']=False;h._update(observed['seconds']);self.assertEqual(h.counts['mandatoryLandings'],0)
 def test_outside_existing_landing_range_stays_rejected(self):
  h=Harness();h.phase='land';h.state['characters'][0]['position'][2]=platforms[1]['z']-0.817775;h._update(observed['seconds']);self.assertEqual(h.counts['mandatoryLandings'],0)
 def test_route_with_unexpected_active_scene_is_rejected(self):
  h=Harness();h.state['levelReference']=h.exploration
  with self.assertRaises(AssertionError):h._update(observed['seconds'])
if __name__=='__main__':unittest.main(argv=[sys.argv[0]]+rest)
