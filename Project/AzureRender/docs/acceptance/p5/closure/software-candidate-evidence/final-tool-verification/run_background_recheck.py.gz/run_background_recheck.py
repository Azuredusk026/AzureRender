import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve();out=root/'build/p5-p6-delivery-investigation-2026-10-11';controller=out/'background-route/run_platformer_long_run.py'
sys.path.insert(0,str(root/'tools'));from build_provenance import inputs
frozen=json.loads((root/'build/p5-p6-closure-candidate-2026-10-11/frozen-inputs.json').read_text(encoding='utf-8'))
assert inputs(root)==frozen
original=hashlib.sha256(controller.read_bytes()).hexdigest();steps=[]
for name,seconds,probe in [('background-probe',120,True),('background-longrun',1800,False)]:
 assert inputs(root)==frozen
 env=dict(os.environ,PYTHONPATH=str(root/'tools'))
 args=[sys.executable,str(controller),'--package',str(out/'final-delivery/Moved exploration'),'--output',str(out/name),'--seconds',str(seconds)]
 if probe:args.append('--probe')
 with (out/(name+'.log')).open('w',encoding='utf-8') as log:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert hashlib.sha256(controller.read_bytes()).hexdigest()==original
 assert inputs(root)==frozen
 steps.append(dict(name=name,exitCode=r.returncode,controllerSha256=original,seconds=seconds))
 (out/'background-recheck-status.json').write_text(json.dumps(steps,indent=2)+'\n',encoding='utf-8');print(name,'exit',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
print('Observed background scan and terminal stop corrections passed the full real-time run.',flush=True)
