import json
from pathlib import Path
root=Path.cwd();work=root/'build/p5-p6-delivery-investigation-2026-10-11'
standard=json.loads((work/'standard-longrun/summary.json').read_text(encoding='utf-8'))
platform=json.loads((work/'background-longrun/summary.json').read_text(encoding='utf-8'))
sync=json.loads((work/'tool-sync-verification.json').read_text(encoding='utf-8'))
assert standard['status']=='passed' and platform['status']=='failed'
assert sync['affectedRuleTestsPassed'] and sync['controllerByteEquivalent']
def replace(name,old,new):
 path=root/name;text=path.read_text(encoding='utf-8');assert text.count(old)==1,(name,old)
 path.write_text(text.replace(old,new,1),encoding='utf-8')
name='docs/acceptance/p5/closure/software-candidate-2026-10-11.md'
replace(name,'> 状态：回归与移动发布通过，长跑执行中。','> 状态：回归与移动发布通过，平台缓冲驻留门禁失败。')
replace(name,'| 平台关卡 | 首轮控制器在 406.797 秒超时，修正后待复测 |',f"| 平台关卡 | 实际 {platform['actualSeconds']:.3f} 秒，{platform['completedRoutes']} 次通关，缓冲驻留失败 |")
replace(name,'候选控制器在标准长跑结束后串行复测。','候选控制器已完成探针与正式串行复测。')
replace(name,'## 待完成门禁',f"""平台正式长跑共运行 {platform['frames']} 帧。
必经落点验证 {platform['mandatoryLandings']} 次。
起点掉落恢复 {platform['startFallRecoveries']} 次。
检查点掉落恢复 {platform['checkpointFallRecoveries']} 次。

水平承载与垂直承载分别验证 {platform['horizontalRides']} 与 {platform['verticalRides']} 次。
切关 {platform['switches']} 次，重开 {platform['restarts']} 次。
工作集增长为 {platform['workingSetGrowth']*100:.3f}%。
GPU 第九十五百分位为 {platform['gpu']['p95']:.3f} 毫秒。

CPU 第九十五百分位为 {platform['cpu']['p95']:.3f} 毫秒。
分时耗时、工作集与容量门禁通过。
控制器错误与验证层错误均为零。
窗口恢复与退出资源释放检查通过。

同关卡活跃缓冲从一百零一个升至一百零七个。
计数增长为 5.941%，超过原有 5% 上限。
首尾计数均为一百零一个，期间峰值仍计入门禁。
整体结果保持失败，缓冲所有者继续调查。

## 控制器同步与证据

生产工具与实跑控制器逐字节一致。
终点四项、后台扫描七项与原有三项规则通过。
测试发现还包括七项共享交付规则。
生产工具先复现失败，再通过全部二十一项。

两配置对应 CTest 各通过一项。

来源变动仅涉及两个客户端工具文件。
两配置各五十四项构建产物哈希保持一致。
正式性能关联的一百一十四项运行文件一致。
已测来源与最终工具来源分别保存。

压缩证据通过原字节及 Git 内容哈希核验。
清单见[软件证据](software-candidate-evidence/manifest.json)。
候选包原件与人工模板继续绑定具体哈希。
正式性能和人工结果分别维护其待验状态。

## 待完成门禁""")
replace('docs/plans/2026-10-11-pipeline-inspection.md','- [ ] 同步阶段状态、证据和交付清单。','- [x] 同步阶段状态、证据和交付清单。')
name='docs/plans/2026-10-10-p5-closure-and-user-experience.md'
replace(name,'| P5-E | 两配置全回归与十组移动发布通过 | 平台及标准长跑、正式性能与人工门禁 |','| P5-E | 全回归、移动发布与标准长跑通过，平台路线控制已核验 | 平台缓冲驻留、正式性能与人工门禁 |')
replace(name,'| P6 | 候选包制作与双设备交付通过机器验证 | 严格性能、长跑及人工验收 |','| P6 | 候选包制作与双设备交付通过机器验证 | 严格性能、平台驻留及人工验收 |')
replace(name,'双工作流制作与十组移动发布通过机器验证。\n实体操作','双工作流制作与十组移动发布通过机器验证。\n\n实体操作')
for old,new in [
 ('- [ ] 两配置分别串行执行全部 GPU 回归。','- [x] 两配置分别串行执行全部 GPU 回归。'),
 ('- [ ] NVIDIA 与 Intel 验证运行、同步和退出。','- [x] NVIDIA 与 Intel 验证运行、同步和退出。'),
 ('- [ ] 重跑受影响标准长跑，并保存全部原始结果。','- [x] 重跑受影响标准长跑，并保存全部原始结果。'),
 ('- [ ] 回归探索接平台、必经跳跃与最终通关。','- [x] 回归探索接平台、必经跳跃与最终通关。'),
 ('- [ ] 核验五项目目录移动及隔离启动。','- [x] 核验五项目目录移动及隔离启动。'),
 ('- [ ] 核验六候选包的来源、许可和 SHA-256。','- [x] 核验六候选包的来源、许可和 SHA-256。')]:replace(name,old,new)
replace('docs/plans/azure-engine-plan.md','平台与标准场景长跑分别执行。','平台与标准场景各完成三十分钟长跑。')
replace('docs/acceptance/p6/2026-10-10.md','| 平台三十分钟长跑 | 待执行 |','| 平台三十分钟长跑 | 实际运行完成，缓冲计数增长 5.941% 超限 |')
replace('docs/acceptance/p6/2026-10-10.md','长跑与正式性能分别维护状态。','标准长跑通过，平台缓冲驻留门禁失败。\n')
replace('docs/acceptance/p5/2026-10-10.md','## 范围与证据','''## 当前软件候选

两配置全回归共四百五十四项通过。
五项目双设备移动发布共十组通过。
两类场景各实际运行三十分钟，平台驻留超限。
正式性能、实体操作和听感仍为待验。

来源、失败及终点控制器修正分别保留。
完整记录见[当前软件候选](closure/software-candidate-2026-10-11.md)。
各批次结果绑定其输入和产物指纹。
阶段完成需满足全部必需门禁。

## 范围与证据''')
path=root/'docs/plans/authoring-usability-manifest.json';manifest=json.loads(path.read_text(encoding='utf-8'))
manifest['currentSoftwareVerification']['longRuns']={key:{field:record[field] for field in ('status','actualSeconds','frames','workingSetGrowth')} for key,record in [('standard',standard),('platformer',platform)]}
manifest['currentSoftwareVerification']['finalToolSourceHash']=sync['configurations']['release']['finalSourceHash']
manifest['currentSoftwareVerification']['controllerByteEquivalent']=True
path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Software evidence synchronized; formal and operator gates remain pending.')
