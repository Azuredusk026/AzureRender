import hashlib,json
from pathlib import Path
root=Path.cwd().resolve();work=root/'build/p5-p6-delivery-investigation-2026-10-11';prior=root/'build/p5-p6-closure-candidate-2026-10-11'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def source_hash(data):return hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()
original=json.loads((prior/'frozen-inputs.json').read_text(encoding='utf-8'))
records={}
for configuration in ('release','debug'):
 measured=json.loads((work/(configuration+'-measured-provenance.json')).read_text(encoding='utf-8'))
 final=json.loads((root/('build/ninja-msvc-'+configuration)/'build-provenance.json').read_text(encoding='utf-8'))
 assert measured['source']==original
 differences=sorted(name for name in set(original)|set(final['source']) if original.get(name)!=final['source'].get(name))
 assert differences==['tools/run_platformer_long_run.py','tools/test_platformer_long_run.py'],differences
 assert measured['products']==final['products']
 for name,expected in final['products'].items():assert digest(Path(name))==expected,name
 records[configuration]=dict(unchangedBuildProducts=len(final['products']),changedProductionInputs=differences,finalSourceHash=source_hash(final['source']))
comparison=json.loads((prior/'prior-performance-product-comparison.json').read_text(encoding='utf-8'))
for item in comparison['products']:assert digest(Path(item['path']))==item['measuredSha256'],item['path']
sync=json.loads((work/'completion-boundary/production-sync.json').read_text(encoding='utf-8'))
assert sync['byteEquivalent'] and sync['correctedControllerSha256']==digest(root/'tools/run_platformer_long_run.py')
assert (root/'tools/run_platformer_long_run.py').read_bytes()==(work/'background-route/run_platformer_long_run.py').read_bytes()
for configuration in records:
 log=(work/(configuration+'-platformer-rules.log')).read_text(encoding='utf-8')
 assert '100% tests passed, 0 tests failed out of 1' in log,log
result=dict(schemaVersion=1,measuredSourceHash='126d7d78297476f6e35aa11250213bddeb8f7d1e5a24a5af1952815ecfee257d',configurations=records,priorPerformanceProductsUnchanged=len(comparison['products']),controllerByteEquivalent=True,fixtureSha256=digest(root/'tests/fixtures/platformer-terminal-stop.json'),backgroundFixtureSha256=digest(root/'tests/fixtures/platformer-background-scan.json'),affectedRuleTestsPassed=True,originalRegressionTotal=454,formalPerformancePassed=False,physicalInputVerified=False)
(work/'tool-sync-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
