import json
from pathlib import Path
root=Path.cwd();original=root/'build/p5-p6-closure-candidate-2026-10-11/authoring-installed/inspection-create/evidence.json'
records=json.loads(original.read_text(encoding='utf-8'))
workspaces=[json.loads(r['response']['value']) for r in records if r['op']=='query' and r['fields'].get('name')=='editor.workspace' and r['response']['passed']]
failed=[state for state in workspaces if any(t['state']=='failed' for t in state['tasks'])]
assert failed
first,last=workspaces[0],failed[-1]
result=dict(source=original.relative_to(root).as_posix(),task=next(t for t in last['tasks'] if t['state']=='failed'),documentBefore=first['document'],documentAfter=last['document'],documentVersionUnchanged=first['document']==last['document'],projectBefore=first['project'],projectAfter=last['project'],projectUnchanged=first['project']==last['project'],selectionBefore=first['selection'],selectionAfter=last['selection'],selectionUnchanged=first['selection']==last['selection'],nodeCountBefore=first['nodeCount'],nodeCountAfter=last['nodeCount'],causeIdentified=False)
(root/'build/p5-p6-delivery-investigation-2026-10-11/project-rename-failure-analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
