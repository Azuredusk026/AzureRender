import json
from pathlib import Path
s=Path('build/p5-p6-delivery-investigation-2026-10-11')
text=(s/'test_background_route.py').read_text(encoding='utf-8')
classes=text[text.index('class Harness'):text.index('if __name__')]
classes=classes.replace('Harness','BackgroundScanHarness').replace('BackgroundRoute','BackgroundScanBoundary').replace('observed','observedScan').replace('module.PlatformerScenario','PlatformerScenario')
addition="\nobservedScan=json.loads((root/'tests/fixtures/platformer-background-scan.json').read_text(encoding='utf-8'))\n"+classes
(s/'background-route/production-test-addition.txt').write_text(addition,encoding='utf-8')
rows=[json.loads(x) for x in (s/'completion-longrun/route.jsonl').read_text(encoding='utf-8').splitlines()]
source=json.loads((s/'background-route/observed-scan.json').read_text(encoding='utf-8'))
d=json.loads(Path('assets_public/platformer/PLATFORMER-DESIGN.json').read_text(encoding='utf-8'))
terminal=rows[-2]['value']['characters'][0]['position']
reason=dict(failedSeconds=rows[-1]['seconds'],completedRoutes=sum(r['kind']=='complete' for r in rows),failedPhase='land',activeRevision=source['value']['levelRevision'],observedScan=source['seconds'],targetZ=d['platforms'][1]['z'],stoppedPosition=terminal,existingLandingTolerance=.8,actualCenterDistance=abs(terminal[2]-d['platforms'][1]['z']),rootCause='Generic loading includes 500 ms background asset scans; controller returned before releasing W while the active world kept moving.',sourceEvidence=['src/runtime/LevelSession.hpp:loading','src/runtime/LevelSession.cpp:poll','src/app/AzureRenderApp.cpp:observeGameState'],changedScope='Public-input route controller only; scene-switch phases retain their loading waits; all budgets and landing conditions retained.')
(s/'background-route/reason.json').write_text(json.dumps(reason,indent=2)+'\n',encoding='utf-8')
print(json.dumps(reason,indent=2))
