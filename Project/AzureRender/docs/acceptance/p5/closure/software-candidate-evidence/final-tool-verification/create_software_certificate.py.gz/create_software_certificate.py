import hashlib,json
from pathlib import Path
root=Path.cwd();work=root/'build/p5-p6-delivery-investigation-2026-10-11'
sync=json.loads((work/'tool-sync-verification.json').read_text(encoding='utf-8'))
delivery=json.loads((work/'final-delivery/summary.json').read_text(encoding='utf-8'))
assert delivery['passed'] and sync['controllerByteEquivalent'] and sync['affectedRuleTestsPassed']
runs={name:json.loads((work/(directory+'/summary.json')).read_text(encoding='utf-8')) for name,directory in [('standard','standard-longrun'),('platformer','background-longrun')]}
assert all(s['actualSeconds']>=1800 for s in runs.values())
assert runs['standard']['status']=='passed' and runs['platformer']['status']=='failed'
provenance=json.loads((work/'final-delivery/packages/provenance.json').read_text(encoding='utf-8'))
packages={}
for package in provenance['packages']:
 actual=hashlib.sha256(Path(package['path']).read_bytes()).hexdigest();assert actual==package['sha256']
 packages[package['kind']]=dict(path=package['path'],sha256=actual)
record=dict(schemaVersion=1,status='RouteControlsVerifiedPlatformResidencyGateFailed',measuredSourceHash=sync['measuredSourceHash'],finalToolSourceHash=sync['configurations']['release']['finalSourceHash'],controllerByteEquivalent=True,regression=dict(release=228,debug=226,originalRuntimeProductsUnchanged=True,affectedTestsPassed=True,routeRules=14,sharedRules=7),deliveryDeviceProjectChecks=10,longRuns={name:{key:s[key] for key in ('status','actualSeconds','frames','workingSetGrowth')} for name,s in runs.items()},packages=packages,formalPerformance=dict(passed=False,passedRounds=14,totalRounds=15,failedWorkingSetGrowth=0.10478702149764252,budget=0.05,systemTrace='NotExecutedAdministratorRequired'),operatorChecks=dict(physicalInput='NotExecuted',subjectiveAudio='NotExecuted',humanAuthoringEfficiency='NotExecuted'),projectRenameIssue='OriginalFailureRetainedCausePending',assetStages='PlannedAfterCurrentMandatoryAcceptance')
(work/'delivery-certificate.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('External certificate binds six unchanged packages to verified software results and pending mandatory gates.')
