import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();work=root/'build/p5-p6-delivery-investigation-2026-10-11';prefix='Project/AzureRender/'
def git(*args,data=None):return subprocess.run(['git',*args],input=data,capture_output=True,check=True).stdout
assert not git('diff','--cached','--name-only').strip()
assert json.loads((work/'tool-sync-verification.json').read_text(encoding='utf-8'))['affectedRuleTestsPassed']
def stage(name,replacements,update_working=False):
 original=git('show','HEAD:'+prefix+name).decode('utf-8');newline='\r\n' if '\r\n' in original else '\n';text=original.replace('\r\n','\n')
 for old,new in replacements:
  assert text.count(old)==1,(name,old);text=text.replace(old,new,1)
 if update_working:
  path=root/name;current=path.read_text(encoding='utf-8')
  for old,new in replacements:
   assert current.count(old)==1,(name,'working',old);current=current.replace(old,new,1)
  path.write_text(current,encoding='utf-8')
 blob=git('hash-object','-w','--stdin',data=text.replace('\n',newline).encode()).decode().strip()
 git('update-index','--cacheinfo','100644,'+blob+','+prefix+name)
stage('README.md',[('\n资产格式后续阶段见','\n回归、移动发布与标准三十分钟长跑通过。\n当前结果见[软件候选验收](docs/acceptance/p5/closure/software-candidate-2026-10-11.md)。\n正式性能与人工复核保持待验。\n\n资产格式后续阶段见')],True)
stage('CHANGELOG.md',[('# Changelog\n\n','# Changelog\n\n## P5-E 软件交付与路线验收控制 2026-10-11\n\n终点控制器按通关状态进入原有落地检查。\n后台资产扫描期间保持当前世界的路线控制。\n十四项路线规则与七项共享交付规则通过。\n两类长跑各运行真实一千八百秒，平台驻留失败。\n\n归档四百五十四项回归与十组移动发布证据。\n正式性能与人工体验仍待验收。\n\n')],True)
stage('mkdocs.yml',[('nav:\n','nav:\n  - 当前软件候选验收: acceptance/p5/closure/software-candidate-2026-10-11.md\n')])
stage('CMakeLists.txt',[('install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-11-pipeline-inspection.md" DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")','install(FILES\n    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-11-pipeline-inspection.md"\n    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/2026-10-11-asset-format-expansion.md"\n    "${CMAKE_CURRENT_SOURCE_DIR}/docs/plans/asset-format-manifest.json"\n    DESTINATION "${CMAKE_INSTALL_DATADIR}/AzureRender/docs/plans")')])
stage('docs/plans/azure-engine-plan.md',[('真实负载、GPU 回归与长跑等待可用环境。','两配置全回归共四百五十四项通过。\n十组双设备移动发布通过机器检查。\n两类场景各实际运行三十分钟，平台驻留超限。\n正式十五轮候选有一轮工作集超限。')])
paths=['tools/run_platformer_long_run.py','tools/test_platformer_long_run.py','tests/fixtures/platformer-terminal-stop.json','tests/fixtures/platformer-background-scan.json',
 'docs/acceptance/p5/closure/software-candidate-2026-10-11.md','docs/acceptance/p5/closure/software-candidate-evidence',
 'docs/acceptance/p5/2026-10-10.md','docs/plans/2026-10-11-pipeline-inspection.md','docs/plans/2026-10-10-p5-closure-and-user-experience.md',
 'docs/plans/authoring-usability-manifest.json','docs/acceptance/p6/2026-10-10.md','docs/acceptance/u16/2026-10-10.md','docs/runtime/observations-generation.md']
git('add','--',*paths)
evidence='docs/acceptance/p5/closure/software-candidate-evidence/';manifest=json.loads((root/evidence/'manifest.json').read_text(encoding='utf-8'))
for name,item in manifest['files'].items():
 raw=git('show',':'+prefix+evidence+name);assert hashlib.sha256(raw).hexdigest()==item['sha256'],name
 assert hashlib.sha256(gzip.decompress(raw)).hexdigest()==item['originalSha256'],name
git('diff','--cached','--check')
print('Selective staging verified:',len(manifest['files']),'archived Git blobs; unrelated changes excluded.')
