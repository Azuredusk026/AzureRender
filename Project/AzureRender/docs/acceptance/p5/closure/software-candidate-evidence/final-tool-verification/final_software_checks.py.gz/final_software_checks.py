import subprocess,sys
from pathlib import Path
root=Path.cwd();work=root/'build/p5-p6-delivery-investigation-2026-10-11'
def run(name,command):
 with (work/name).open('w',encoding='utf-8') as log:
  result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 print(name,'exit',result.returncode,flush=True)
 assert result.returncode==0,(name,command)
run('tool-sync-build.log',['cmd','/c',str(root/'build/p5-p6-inspection-2026-10-11/rebuild_closure.cmd')])
ctest=Path('D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe')
assert ctest.is_file()
for configuration in ('Release','Debug'):
 run(configuration.lower()+'-platformer-rules.log',[str(ctest),'--test-dir','build/ninja-msvc-'+configuration.lower(),'-C',configuration,'--output-on-failure','-R','^AzureTools.PlatformerLongRunRules$'])
run('tool-sync-comparison.log',[sys.executable,str(work/'verify_tool_sync.py')])
