import argparse,hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve();out=root/'build/p5-ui-residency-2026-10-11'
parser=argparse.ArgumentParser();parser.add_argument('--label',required=True);args=parser.parse_args()
label=args.label;assert label in ('compact','combined')
sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,inputs
from build_game import build_game,verify_package
cmake=Path('D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe')
source=inputs(root)
proof=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text(encoding='utf-8'))
verify(root,proof)
(out/(label+'-source.json')).write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
engine=out/(label+' Engine');package=out/(label+' exploration')
assert not engine.exists() and not package.exists()
with (out/(label+'-install.log')).open('w',encoding='utf-8') as log:
 subprocess.run([str(cmake),'--install',str(root/'build/ninja-msvc-release'),'--config','Release','--prefix',str(engine)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
build_game(root/'assets_public/exploration/project.azureproject',engine,package)
verify_package(package)
command=[sys.executable,str(root/'tools/run_platformer_long_run.py'),'--package',str(package),'--output',str(out/(label+'-probe')),'--seconds','180','--probe']
with (out/(label+'-probe.log')).open('w',encoding='utf-8') as log:
 result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
assert inputs(root)==source
print('diagnostic probe exit',result.returncode,flush=True)
case=out/(label+'-probe')
report=json.loads((case/'summary.json').read_text(encoding='utf-8'))
assert report['actualSeconds']>=180 and not report['controllerErrors'] and report['completedRoutes']>=1
assert report['exitCode']==0 and report['released'] and not report['validationErrors']
references={int(k):v for k,v in report['revisionReferences'].items()}
rows=json.loads((case/'timing.json').read_text(encoding='utf-8'))['resourceFrames']
groups={}
for row in rows:
 if row['loading'] or row['committed']:continue
 reference=references.get(row['revision'])
 if not reference:continue
 if label=='compact':assert row['uiBuffers']==2*(row['uiActiveGeometry']+row['uiRetiredGeometry']),row
 else:assert 0<row['uiBuffers']<=row['uiActiveGeometry']+row['uiRetiredGeometry'],row
 groups.setdefault(reference,[]).append(row)
summary={}
for name,values in groups.items():
 summary[name]=dict(samples=len(values),buffers=[min(v['buffers'] for v in values),max(v['buffers'] for v in values)],
  uiBuffers=[min(v['uiBuffers'] for v in values),max(v['uiBuffers'] for v in values)],
  nonUiBuffers=sorted({v['buffers']-v['uiBuffers'] for v in values}),
  peaks=[v for v in values if v['buffers']==max(r['buffers'] for r in values)])
record=dict(schemaVersion=1,diagnosticOnly=True,probeExitCode=result.returncode,sourceHash=hashlib.sha256(json.dumps(source,sort_keys=True).encode()).hexdigest(),groups=summary)
(out/(label+'-ownership.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,indent=2),flush=True)
