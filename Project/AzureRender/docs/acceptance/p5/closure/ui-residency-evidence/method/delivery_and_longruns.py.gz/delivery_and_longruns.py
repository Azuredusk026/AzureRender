import json,os,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve();out=root/'build/p5-ui-residency-2026-10-11'
cmake=Path('D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin')
os.environ['PATH']=str(cmake)+os.pathsep+os.environ['PATH'];sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify
from build_game import build_game,verify_package
from test_level_cycles import prepare
status=json.loads((out/'arena-regression-status.json').read_text(encoding='utf-8'))
assert len(status)==5 and all(row['exitCode']==0 for row in status),status
inventory=json.loads((out/'arena-regression-inventory.json').read_text(encoding='utf-8'))
assert inventory['complete'] and inventory['total']==454
frozen=inputs(root);verify(root,json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text(encoding='utf-8')))
records=[]
def run(name,command):
 with (out/(name+'.log')).open('w',encoding='utf-8') as log:
  result=subprocess.run(list(map(str,command)),cwd=root,stdout=log,stderr=subprocess.STDOUT)
 assert inputs(root)==frozen
 records.append(dict(name=name,exitCode=result.returncode))
 (out/'arena-delivery-longrun-status.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
 print(name,'exit',result.returncode,flush=True)
 return result.returncode
assert run('arena-delivery',[sys.executable,out/'verified_delivery.py'])==0
delivery=out/'arena-delivery';assert json.loads((delivery/'summary.json').read_text(encoding='utf-8'))['passed']
source=out/'arena-standard-source';standard=out/'Moved arena standard'
prepare(source);build_game(source/'project.azureproject',delivery/'Moved Engine',standard)
source.rename(out/'Unavailable arena standard source');verify_package(standard)
run('arena-platformer-longrun',[sys.executable,root/'tools/run_platformer_long_run.py','--package',delivery/'Moved exploration','--output',out/'arena-platformer-longrun','--seconds','1800'])
run('arena-standard-longrun',[sys.executable,root/'tools/run_playable_long_run.py','--package',standard,'--output',out/'arena-standard-longrun','--seconds','1800'])
print('Both real-time runs finished; their original results are retained.',flush=True)
raise SystemExit(int(any(row['exitCode'] for row in records)))
