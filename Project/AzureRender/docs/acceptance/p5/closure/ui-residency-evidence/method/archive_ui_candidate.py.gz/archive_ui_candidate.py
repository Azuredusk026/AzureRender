"""Archive original evidence bytes without changing earlier candidates."""
import gzip
import hashlib
import json
from pathlib import Path

root = Path.cwd().resolve()
work = root/'build/p5-ui-residency-2026-10-11'
target = root/'docs/acceptance/p5/closure/ui-residency-evidence'
assert not target.exists(), target
inventory = json.loads((work/'arena-regression-inventory.json').read_text(encoding='utf-8'))
assert inventory['complete'] and inventory['total'] == 454
delivery = json.loads((work/'arena-delivery/summary.json').read_text(encoding='utf-8'))
assert delivery['passed'] and len(delivery['checks']) == 10
formal = json.loads((work/'arena-final-formal-performance/summary.json').read_text(encoding='utf-8'))
assert sum(map(len, formal['rounds'].values())) == 15
selected = {}
def add(path, label):
    assert path.is_file(), path
    assert label not in selected, label
    selected[label] = path

for path in sorted(work.iterdir()):
    if path.is_file() and path.suffix in ('.json', '.log', '.py', '.txt', '.cmd'):
        add(path, 'method/'+path.name)
for name in ('diagnostic-probe', 'diagnostic-fixed', 'compact-probe', 'compact-fixed',
             'combined-fixed', 'combined-probe', 'arena-platformer-longrun',
             'arena-standard-longrun', 'arena-formal-performance', 'operator-review',
             'arena-platformer-aligned-probe','arena-platformer-aligned-longrun','arena-final-formal-performance'):
    base = work/name
    if not base.is_dir():
        continue
    for path in sorted(base.iterdir()):
        if path.is_file() and path.suffix in ('.json', '.jsonl', '.log', '.csv', '.md', '.py', '.png'):
            add(path, name+'/'+path.name)
    for path in sorted((base/'captures').glob('*')):
        if path.is_file() and (path.name.startswith('hud-') or path.name == 'gpu_capabilities.json'):
            add(path, name+'/captures/'+path.name)
for name in ('arena-platformer-aligned-longrun', 'arena-standard-longrun'):
    assert (work/name/'summary.json').is_file()
for path in sorted((work/'cache-schedule').rglob('*')):
    if path.is_file() and (path.name == 'summary.json' or path.suffix == '.log') and 'project' not in path.relative_to(work/'cache-schedule').parts:
        add(path, 'cache-schedule/'+path.relative_to(work/'cache-schedule').as_posix())
base = work/'arena-delivery'
for path in sorted(base.iterdir()):
    if path.is_file() and path.suffix in ('.json', '.log'):
        add(path, 'delivery/'+path.name)
for path in sorted(base.glob('nvidia-*/*'))+sorted(base.glob('intel-*/*')):
    if path.is_file() and path.suffix in ('.json', '.log'):
        add(path, 'delivery/'+path.relative_to(base).as_posix())
add(base/'packages/provenance.json', 'delivery/provenance.json')
for row in delivery['packages']:
    folder = base/('Moved Engine' if row['kind'] == 'engine' else 'Moved '+row['kind'])
    add(folder/('install_manifest.json' if row['kind'] == 'engine' else 'game_manifest.json'),
        'package-manifests/'+row['kind']+'.json')
for name in ('src/render/GameUiRenderer.hpp', 'src/render/GameUiRenderer.cpp',
             'src/app/AzureRenderFrame.cpp', 'src/app/AzureRenderValidation.cpp',
             'src/runtime/ResourceFrameTrace.hpp', 'tests/GameUiRendererTests.cpp',
             'tests/ResourceFrameTraceTests.cpp', 'tools/run_platformer_long_run.py',
             'tools/test_platformer_long_run.py','tests/fixtures/platformer-landing-overshoot.json'):
    add(root/name, 'source/'+name)

files = {}
for label, path in selected.items():
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    name = label+'.gz'
    output = target/name
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(stored)
    assert gzip.decompress(output.read_bytes()) == raw
    files[name] = dict(source=path.relative_to(root).as_posix(), originalBytes=len(raw),
        storedBytes=len(stored), originalSha256=hashlib.sha256(raw).hexdigest(),
        sha256=hashlib.sha256(stored).hexdigest(), compressed=True)
manifest = dict(schemaVersion=1, sourceHash=formal['sourceHash'], regressionTotal=454,
    deliveryChecks=10, formalPerformancePassed=formal['passed'],
    formalRounds=sum(map(len, formal['rounds'].values())),
    longRuns={name:json.loads((work/directory/'summary.json').read_text(encoding='utf-8'))['status']
        for name,directory in [('platformer','arena-platformer-aligned-longrun'),('standard','arena-standard-longrun')]},
    physicalInputVerified=False, subjectiveAudioVerified=False, authoringEfficiencyVerified=False,
    priorWorkingSetCauseResolved=False, files=files)
manifest['toolSourceEquivalence']=json.loads((work/'tool-source-equivalence.json').read_text(encoding='utf-8'))
(target/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(files=len(files), storedBytes=sum(row['storedBytes'] for row in files.values()),
    formalPerformancePassed=formal['passed'], longRuns=manifest['longRuns'])))
