"""Finish the actual platform run after the frozen initial batch ends."""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-ui-residency-2026-10-11'
os.environ['PATH']='D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin'+os.pathsep+os.environ['PATH']
deadline=time.monotonic()+10800
while True:
    path=work/'continuation-status.json'
    records=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
    if any(row['name']=='operator-packet' and row['exitCode']==0 for row in records):break
    assert time.monotonic()<deadline,'The initial frozen batch has not completed'
    time.sleep(10)
status=[]
def run(name,args):
    print('Starting',name,flush=True)
    with (work/(name+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run(list(map(str,args)),cwd=root,stdout=log,stderr=subprocess.STDOUT)
    status.append(dict(name=name,exitCode=result.returncode))
    (work/'aligned-acceptance-status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
    print(name,'exit',result.returncode,flush=True)
    return result.returncode
assert run('sync-landing',[sys.executable,work/'sync_landing_controller.py'])==0
assert run('arena-platformer-aligned-probe',[sys.executable,root/'tools/run_platformer_long_run.py',
    '--package',work/'arena-delivery/Moved exploration','--output',work/'arena-platformer-aligned-probe',
    '--seconds','180','--probe'])==0
run('final-formal-performance',[sys.executable,root/'tools/run_playable_performance.py',
    '--player',root/'build/ninja-msvc-release/AzurePlayer.exe','--editor',root/'build/ninja-msvc-release/AzureRender.exe',
    '--exploration',root/'assets_public/exploration/project.azureproject',
    '--platformer',root/'assets_public/platformer/project.azureproject','--output',work/'arena-final-formal-performance'])
run('arena-platformer-aligned-longrun',[sys.executable,root/'tools/run_platformer_long_run.py',
    '--package',work/'arena-delivery/Moved exploration','--output',work/'arena-platformer-aligned-longrun','--seconds','1800'])
raise SystemExit(int(any(row['exitCode'] for row in status)))
