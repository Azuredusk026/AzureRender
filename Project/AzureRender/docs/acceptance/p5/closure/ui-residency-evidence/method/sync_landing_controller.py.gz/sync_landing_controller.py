"""Apply the verified client fix and prove runtime products remain identical."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-ui-residency-2026-10-11'
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify
from run_playable_performance import freeze_products
initial=json.loads((work/'arena-formal-performance/frozen-inputs.json').read_text(encoding='utf-8'))
assert inputs(root)==initial['source']
old={configuration:json.loads((root/('build/ninja-msvc-'+configuration)/'build-provenance.json').read_text(encoding='utf-8'))
    for configuration in ('release','debug')}
for proof in old.values():verify(root,proof)
before=initial['source']
for name in ('run_platformer_long_run.py','test_platformer_long_run.py'):
    (work/('controller-original-'+name)).write_bytes((root/'tools'/name).read_bytes())
fixture=root/'tests/fixtures/platformer-landing-overshoot.json'
assert not fixture.exists()
fixture.write_bytes((work/'landing-overshoot.json').read_bytes())
tests=(root/'tools/test_platformer_long_run.py').read_text(encoding='utf-8')
addition=(work/'test_landing_alignment.py').read_text(encoding='utf-8')
addition=addition[addition.index('class LandingAlignment'):addition.index("if __name__=='__main__'")]
addition=addition.replace("observed['value']","observedLanding['value']").replace("observed['seconds']","observedLanding['seconds']")
addition="observedLanding=json.loads((root/'tests/fixtures/platformer-landing-overshoot.json').read_text(encoding='utf-8'))\n"+addition
needle="if __name__=='__main__':unittest.main()"
assert tests.count(needle)==1
(root/'tools/test_platformer_long_run.py').write_text(tests.replace(needle,addition+needle),encoding='utf-8')
def run(name,args):
    with (work/(name+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run(list(map(str,args)),cwd=root,stdout=log,stderr=subprocess.STDOUT)
    print(name,'exit',result.returncode,flush=True)
    return result.returncode
assert run('landing-production-red',[sys.executable,root/'tools/test_platformer_long_run.py'])!=0
red=(work/'landing-production-red.log').read_text(encoding='utf-8')
assert 'Ran 35 tests' in red and 'test_recorded_supported_stop_enters_correction_without_counting' in red
(root/'tools/run_platformer_long_run.py').write_bytes((work/'platformer_alignment.py').read_bytes())
assert run('landing-production-green',[sys.executable,root/'tools/test_platformer_long_run.py'])==0
after=inputs(root)
changed=sorted(key for key in set(before)|set(after) if before.get(key)!=after.get(key))
assert changed==['tools/run_platformer_long_run.py','tools/test_platformer_long_run.py'],changed
configurations={}
assert run('landing-source-build',[os.environ['COMSPEC'],'/d','/c',work/'rebuild.cmd'])==0
for configuration in ('release','debug'):
    build=root/('build/ninja-msvc-'+configuration)
    proof=json.loads((build/'build-provenance.json').read_text(encoding='utf-8'))
    assert proof['products']==old[configuration]['products'],configuration
    verify(root,proof)
    (work/('final-'+configuration+'-provenance.json')).write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
    ctest=Path('D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe')
    assert run('landing-'+configuration+'-rules',[ctest,'--test-dir',build,'-C',configuration.capitalize(),
        '-R','^AzureTools.PlatformerLongRunRules$','--output-on-failure','-j','1'])==0
    configurations[configuration]=dict(products=len(proof['products']),productByteEquivalent=True,affectedRuleTestPassed=True)
runtime=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
assert runtime==initial['products'],'Measured runtime dependency closure changed'
assert inputs(root)==after
record=dict(schemaVersion=1,measuredRuntimeSourceHash=hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),
    finalToolSourceHash=hashlib.sha256(json.dumps(after,sort_keys=True).encode()).hexdigest(),
    changedInputs=changed,configurations=configurations,runtimeProducts=len(runtime),
    runtimeDependencyByteEquivalent=True,productionRules=35,
    originalFailureRetained=True,landingTolerance=.8,formalSeconds=1800)
(work/'tool-source-equivalence.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record),flush=True)
