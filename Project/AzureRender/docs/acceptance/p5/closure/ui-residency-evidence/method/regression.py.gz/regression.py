import hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve();out=root/'build/p5-ui-residency-2026-10-11'
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify
frozen=inputs(root);records=[]
ctest=Path('D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe')
for configuration in ('release','debug'):
 proof=json.loads((root/('build/ninja-msvc-'+configuration)/'build-provenance.json').read_text(encoding='utf-8'));verify(root,proof)
 (out/('arena-'+configuration+'-provenance.json')).write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
 for group,selection in [('cpu',['-LE','gpu','-j','4']),('gpu',['-L','gpu','-j','1'])]:
  log=out/('arena-'+configuration+'-'+group+'.log')
  with log.open('w',encoding='utf-8') as stream:
   result=subprocess.run([str(ctest),'--test-dir',str(root/('build/ninja-msvc-'+configuration)),'-C',configuration.capitalize(),'--output-on-failure',*selection],cwd=root,stdout=stream,stderr=subprocess.STDOUT)
  assert inputs(root)==frozen
  records.append(dict(configuration=configuration,group=group,exitCode=result.returncode,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
  (out/'arena-regression-status.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
  print(configuration,group,'exit',result.returncode,flush=True)
print('Regression finished; all group failures are retained.',flush=True)
raise SystemExit(int(any(row['exitCode'] for row in records)))
