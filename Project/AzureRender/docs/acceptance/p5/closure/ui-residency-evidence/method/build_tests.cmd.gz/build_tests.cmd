@echo off
call "D:\Visual Studio\2022\VC\Auxiliary\Build\vcvars64.bat" -vcvars_ver=14.44
if errorlevel 1 exit /b 1
set "PATH=D:\Visual Studio\2022\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin;%PATH%"
cmake --build build/ninja-msvc-release --target AzureGameUiRendererTests AzureResourceFrameTraceTests -j 4
