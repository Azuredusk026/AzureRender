"""Bind the six immutable packages to measured and pending gates."""
import hashlib
import json
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-ui-residency-2026-10-11'
formal=json.loads((work/'arena-final-formal-performance/summary.json').read_text(encoding='utf-8'))
inventory=json.loads((work/'arena-regression-inventory.json').read_text(encoding='utf-8'))
delivery=json.loads((work/'arena-delivery/summary.json').read_text(encoding='utf-8'))
assert inventory['complete'] and inventory['total']==454 and delivery['passed']
assert len(delivery['packages'])==6 and len(delivery['checks'])==10
runs={name:json.loads((work/directory/'summary.json').read_text(encoding='utf-8'))
    for name,directory in [('platformer','arena-platformer-aligned-longrun'),('standard','arena-standard-longrun')]}
assert all(row['actualSeconds']>=1800 for row in runs.values())
packages={}
for row in delivery['packages']:
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
    packages[row['kind']]=dict(path=row['path'],sha256=row['sha256'])
rounds=[row for group in formal['rounds'].values() for row in group]
assert len(rounds)==15
equivalence=json.loads((work/'tool-source-equivalence.json').read_text(encoding='utf-8'))
assert equivalence['finalToolSourceHash']==formal['sourceHash'] and equivalence['runtimeDependencyByteEquivalent']
result=dict(schemaVersion=1,status='MeasuredCandidateMandatoryGatesPending',sourceHash=formal['sourceHash'],toolSourceEquivalence=equivalence,
    regression=inventory,deliveryDeviceProjectChecks=10,packages=packages,
    longRuns={name:{key:row[key] for key in ('status','actualSeconds','frames','workingSetGrowth')}
        for name,row in runs.items()},
    formalPerformance=dict(passed=formal['passed'],passedRounds=sum(row['passed'] for row in rounds),totalRounds=15),
    historicalWorkingSetCause='UnresolvedSystemTraceNotExecutedAdministratorRequired',
    operatorChecks=dict(physicalInput='NotExecuted',subjectiveAudio='NotExecuted',humanAuthoringEfficiency='NotExecuted'),
    sharedCacheConcurrency='ReproducedSharedTemporaryFileRaceNotFixed',
    projectRenameIssue='OriginalFailureRetainedCausePending',
    assetStages='PlannedAfterCurrentMandatoryAcceptance')
(work/'delivery-certificate.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(packages=6,formalPassedRounds=result['formalPerformance']['passedRounds'],
    longRuns={name:row['status'] for name,row in runs.items()},currentStagesComplete=False)))
