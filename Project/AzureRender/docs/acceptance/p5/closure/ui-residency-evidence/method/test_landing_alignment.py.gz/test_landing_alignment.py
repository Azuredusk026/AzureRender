"""Keep the strict landing rule while recovering a grounded stop overshoot."""
import copy
import json
import sys
import unittest
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-ui-residency-2026-10-11'
sys.path.insert(0,str(root/'tools'))
sys.path.insert(0,str(work))
import platformer_alignment
sys.modules['run_platformer_long_run']=platformer_alignment
from test_platformer_long_run import BackgroundScanHarness
observed=json.loads((work/'landing-overshoot.json').read_text(encoding='utf-8'))

class LandingAlignment(unittest.TestCase):
    def harness(self):
        h=BackgroundScanHarness()
        h.state=copy.deepcopy(observed['value'])
        h.phase='land';h.phaseStarted=observed['seconds']-1;h.keys=set()
        return h
    def update(self,h):h._update(observed['seconds'])
    def test_recorded_supported_stop_enters_correction_without_counting(self):
        h=self.harness();self.update(h)
        self.assertEqual(h.phase,'landing-align')
        self.assertEqual(h.counts['mandatoryLandings'],0)
    def test_correction_uses_backward_input_for_past_center(self):
        h=self.harness();h.phase='landing-align';self.update(h)
        self.assertIn(83,h.keys);self.assertNotIn(87,h.keys)
        self.assertEqual(h.counts['mandatoryLandings'],0)
    def test_correction_uses_forward_input_from_opposite_side(self):
        h=self.harness();h.phase='landing-align'
        h.state['characters'][0]['position'][2]=h.platforms[1]['z']+1
        self.update(h);self.assertIn(87,h.keys);self.assertNotIn(83,h.keys)
    def test_corrected_stop_waits_for_braking_before_original_landing_check(self):
        h=self.harness();h.phase='landing-align';h.keys={83}
        hero=h.state['characters'][0];hero['position'][2]=h.platforms[1]['z']-.1
        hero['velocity'][2]=1.;self.update(h)
        self.assertFalse(h.keys);self.assertEqual(h.phase,'landing-align')
        self.assertEqual(h.counts['mandatoryLandings'],0)
        hero['velocity'][2]=0.;self.update(h)
        self.assertEqual(h.phase,'land');self.assertEqual(h.counts['mandatoryLandings'],0)
        self.update(h);self.assertEqual(h.counts['mandatoryLandings'],1)
    def test_airborne_or_lower_surface_cannot_begin_correction(self):
        for airborne in (True,False):
            h=self.harness();hero=h.state['characters'][0]
            if airborne:hero['grounded']=False
            else:hero['position'][1]=h.platforms[1]['top']-.2
            self.update(h);self.assertEqual(h.phase,'land');self.assertFalse(h.keys)
    def test_ground_outside_target_surface_cannot_begin_correction(self):
        h=self.harness();h.state['characters'][0]['position'][2]=h.platforms[1]['z']-h.platforms[1]['halfLength']-.1
        self.update(h);self.assertEqual(h.phase,'land');self.assertFalse(h.keys)
    def test_completed_goal_does_not_receive_corrective_movement(self):
        h=self.harness();h.state['tasks'][0]['completed']=True
        self.update(h);self.assertEqual(h.phase,'land');self.assertFalse(h.keys)
    def test_correction_releases_input_if_support_or_height_is_lost(self):
        for mode in ('airborne','lower','outside','completed'):
            h=self.harness();h.phase='landing-align';h.keys={83}
            hero=h.state['characters'][0]
            if mode=='airborne':hero['grounded']=False
            elif mode=='lower':hero['position'][1]=h.platforms[1]['top']-.2
            elif mode=='outside':hero['position'][2]=h.platforms[1]['z']-h.platforms[1]['halfLength']-.1
            else:h.state['tasks'][0]['completed']=True
            self.update(h);self.assertFalse(h.keys,msg=mode)
            self.assertEqual(h.phase,'land',msg=mode)
            self.assertEqual(h.counts['mandatoryLandings'],0)
    def test_reversing_correction_releases_old_direction_first(self):
        h=self.harness();h.phase='landing-align';h.keys={83}
        h.state['characters'][0]['position'][2]=h.platforms[1]['z']+1
        self.update(h)
        self.assertEqual(h.keys,{87})
        self.assertEqual(h.events[-2:],[
            dict(action='key',key=83,down=False),dict(action='key',key=87,down=True)])

if __name__=='__main__':unittest.main()
