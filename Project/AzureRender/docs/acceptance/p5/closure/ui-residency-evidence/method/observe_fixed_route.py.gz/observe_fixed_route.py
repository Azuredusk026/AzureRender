import argparse,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve();out=root/'build/p5-ui-residency-2026-10-11'
parser=argparse.ArgumentParser();parser.add_argument('--label',choices=('compact','combined'),required=True);args=parser.parse_args()
sys.path.insert(0,str(root/'tools'))
from run_playable_long_run import isolated_environment
case=out/(args.label+'-fixed');case.mkdir(exist_ok=False)
script=dict(schemaVersion=1,steps=[dict(op='query',name='render.residency') for _ in range(640)])
for index,label in [(20,'hud-start'),(200,'hud-checkpoint'),(490,'hud-finish')]:script['steps'][index]=dict(op='screenshot',label=label)
(case/'script.json').write_text(json.dumps(script),encoding='utf-8')
inputs=root/'build/p5-p6-delivery-investigation-2026-10-11/final-delivery/platformer.input.json'
env=isolated_environment();env.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
command=[str(out/(args.label+' Engine')/'bin/AzurePlayer.exe'),'--resource-root',str(out/(args.label+' Engine')/'share/AzureRender'),
 '--project',str(root/'assets_public/platformer/project.azureproject'),'--game-actions',str(inputs),
 '--validation-script',str(case/'script.json'),'--validation-report',str(case/'validation.json'),
 '--runtime-report',str(case/'runtime.json'),'--gpu-timing','--gpu-timing-output',str(case/'timing.json'),
 '--fixed-frame-step','--capture-fps','15','--smoke-frames','650','--width','1280','--height','720']
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
with (case/'stdout.log').open('w',encoding='utf-8') as stdout,(case/'stderr.log').open('w',encoding='utf-8') as stderr:
 result=subprocess.run(command,cwd=case,env=env,stdout=stdout,stderr=stderr,startupinfo=startup,timeout=180)
assert result.returncode==0
validation=json.loads((case/'validation.json').read_text(encoding='utf-8'));assert validation['passed'] and validation['completedSteps']==640
rows=[json.loads(row['value']) for row in validation['steps'] if isinstance(row.get('value'),str)]
assert len(rows)==637
runtime=json.loads((case/'runtime.json').read_text(encoding='utf-8'))
assert not runtime['scriptErrors'] and not runtime['presentationErrors']
assert any(row['tasks'][0]['completed'] and row['tasks'][0]['collected']==8 for row in runtime['routeFrames'])
logs=(case/'stdout.log').read_text(encoding='utf-8')+(case/'stderr.log').read_text(encoding='utf-8')
assert 'Allocator after unload: buffers=0 images=0' in logs
assert not any(x.lower() in logs.lower() for x in ('VUID-','Validation Error','SYNC-HAZARD'))
stable=[r for r in rows if r['frame']>20 and r['cachedResourceKey']=='']
for image in (out/(args.label+' Engine')/'share/AzureRender/captures').glob('hud-*.png'):
 shutil.copy2(image,case/'captures'/image.name)
summary=dict(schemaVersion=1,diagnosticOnly=True,inputSha256=hashlib.sha256(inputs.read_bytes()).hexdigest(),
 samples=len(rows),completed=True,released=True,validationErrors=0,
 buffers=sorted({r['buffers'] for r in stable}),uiBuffers=sorted({r['uiBuffers'] for r in stable}),
 nonUiBuffers=sorted({r['buffers']-r['uiBuffers'] for r in stable}),
 retiredPeaks=[r for r in stable if r['uiRetiredGeometry']>0],
 captures={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (case/'captures').glob('hud-*.png')})
assert len(summary['captures'])==3
(case/'ownership.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='retiredPeaks'},indent=2))
