"""Stage only this candidate's increments in shared documentation."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

root=Path.cwd().resolve()
prefix='Project/AzureRender/'
work=root/'build/p5-ui-residency-2026-10-11'
def git(*args,data=None):
    return subprocess.run(['git',*args],input=data,capture_output=True,check=True).stdout
assert not git('diff','--cached','--name-only').strip()
inventory=json.loads((work/'arena-regression-inventory.json').read_text(encoding='utf-8'))
assert inventory['complete'] and inventory['total']==454

def stage(name,replacements):
    original=git('show','HEAD:'+prefix+name).decode('utf-8')
    newline='\r\n' if '\r\n' in original else '\n'
    text=original.replace('\r\n','\n')
    for old,new in replacements:
        assert text.count(old)==1,(name,old)
        text=text.replace(old,new,1)
    blob=git('hash-object','-w','--stdin',data=text.replace('\n',newline).encode()).decode().strip()
    git('update-index','--cacheinfo','100644,'+blob+','+prefix+name)

readme=(root/'README.md').read_text(encoding='utf-8')
start=readme.index('界面几何使用共享缓冲页，保留在途退休规则。')
end=readme.index('资产格式后续阶段见',start)
stage('README.md',[('\n资产格式后续阶段见','\n'+readme[start:end]+'资产格式后续阶段见')])
changelog=(root/'CHANGELOG.md').read_text(encoding='utf-8')
start=changelog.index('## P5-E 界面几何驻留修复 2026-10-11')
end=changelog.index('## P5-E 软件交付与路线验收控制 2026-10-11',start)
stage('CHANGELOG.md',[('# Changelog\n\n','# Changelog\n\n'+changelog[start:end])])
stage('mkdocs.yml',[('nav:\n','nav:\n  - 平台界面缓冲驻留: acceptance/p5/closure/ui-residency.md\n')])
plan=(root/'docs/plans/azure-engine-plan.md').read_text(encoding='utf-8')
start=plan.index('共享页候选两类场景各实跑三十分钟。')
end=plan.index('实体键鼠及音效听感按人工记录完成。',start)
stage('docs/plans/azure-engine-plan.md',[
    ('两类场景各实际运行三十分钟，平台驻留超限。\n正式十五轮候选有一轮工作集超限。\n',plan[start:end])])
paths=['src/render/GameUiRenderer.cpp','src/render/GameUiRenderer.hpp',
    'src/app/AzureRenderFrame.cpp','src/app/AzureRenderValidation.cpp',
    'src/runtime/ResourceFrameTrace.hpp','tests/GameUiRendererTests.cpp',
    'tests/ResourceFrameTraceTests.cpp','tools/run_platformer_long_run.py','tools/test_platformer_long_run.py',
    'tests/fixtures/platformer-landing-overshoot.json',
    'docs/runtime/render-residency.md','docs/acceptance/p5/closure/ui-residency.md',
    'docs/acceptance/p5/closure/ui-residency-evidence',
    'docs/plans/2026-10-10-p5-closure-and-user-experience.md',
    'docs/plans/authoring-usability-manifest.json','docs/acceptance/p5/2026-10-10.md',
    'docs/acceptance/p6/2026-10-10.md']
git('add','--',*paths)
evidence='docs/acceptance/p5/closure/ui-residency-evidence/'
manifest=json.loads((root/evidence/'manifest.json').read_text(encoding='utf-8'))
for name,item in manifest['files'].items():
    stored=git('show',':'+prefix+evidence+name)
    assert hashlib.sha256(stored).hexdigest()==item['sha256'],name
    assert hashlib.sha256(gzip.decompress(stored)).hexdigest()==item['originalSha256'],name
git('diff','--cached','--check')
print('Selective index and',len(manifest['files']),'original-byte Git blobs verified.')
