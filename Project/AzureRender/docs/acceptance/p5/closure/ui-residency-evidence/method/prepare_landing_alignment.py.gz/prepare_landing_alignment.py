"""Prepare an isolated controller candidate without changing frozen inputs."""
import json
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-ui-residency-2026-10-11'
rows=[json.loads(line) for line in (work/'arena-platformer-longrun/route.jsonl').read_text(encoding='utf-8').splitlines()]
record=next(row for row in reversed(rows) if row['kind']=='state')
target=json.loads((root/'assets_public/platformer/PLATFORMER-DESIGN.json').read_text(encoding='utf-8'))['platforms'][1]
fixture=dict(schemaVersion=1,seconds=record['seconds'],value=record['value'],target=target,
    originalError=next(row for row in reversed(rows) if row['kind']=='controller-error'))
(work/'landing-overshoot.json').write_text(json.dumps(fixture,indent=2)+'\n',encoding='utf-8')
source=(root/'tools/run_platformer_long_run.py').read_text(encoding='utf-8')
(work/'platformer_alignment.py').write_text(source,encoding='utf-8')
print('Preserved the actual stopped landing and an unmodified controller for the red test.')
