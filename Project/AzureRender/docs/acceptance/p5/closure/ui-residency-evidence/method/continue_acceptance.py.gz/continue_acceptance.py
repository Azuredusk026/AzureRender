"""Continue the frozen candidate after the active regression finishes."""
import json
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd().resolve()
out = root/'build/p5-ui-residency-2026-10-11'
deadline = time.monotonic()+7200
while True:
    records = json.loads((out/'arena-regression-status.json').read_text(encoding='utf-8'))
    if len(records) >= 4:
        break
    assert time.monotonic() < deadline, 'Regression did not finish in the wait window'
    time.sleep(10)

results = []
def run(name, args):
    print('Starting', name, flush=True)
    with (out/(name+'.log')).open('w', encoding='utf-8') as log:
        process = subprocess.run(args, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    results.append(dict(name=name, exitCode=process.returncode))
    (out/'continuation-status.json').write_text(json.dumps(results, indent=2)+'\n', encoding='utf-8')
    print(name, 'exit', process.returncode, flush=True)
    return process.returncode

failures = [row for row in records if row['exitCode'] != 0]
if failures:
    assert len(failures) == 1 and failures[0]['configuration'] == 'debug' and failures[0]['group'] == 'cpu', failures
    original = (out/failures[0]['log']).read_text(encoding='utf-8')
    assert '202 - AzureGame.PlatformerPhase4 (Failed)' in original and 'Cannot write asset file:' in original
    assert '1 tests failed out of 162' in original
    schedule = json.loads((out/'cache-schedule/summary.json').read_text(encoding='utf-8'))
    assert schedule['serializedPassed']
    (out/'arena-regression-status-initial.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
    ctest = 'D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe'
    assert run('arena-debug-cpu-serialized', [ctest, '--test-dir', str(root/'build/ninja-msvc-debug'),
        '-C', 'Debug', '--output-on-failure', '-LE', 'gpu', '-j', '1']) == 0
    import hashlib
    log = out/'arena-debug-cpu-serialized.log'
    records[records.index(failures[0])] = dict(configuration='debug', group='cpu', exitCode=0,
        log=log.name, sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
        initialFailedAttempt='arena-debug-cpu.log', scheduleCorrection='DocumentedSerialExecution')
    (out/'arena-regression-status.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
assert all(row['exitCode'] == 0 for row in records), records
assert run('supplement-packages', [sys.executable, str(out/'supplement_package_tests.py')]) == 0
run('delivery-and-longruns', [sys.executable, str(out/'delivery_and_longruns.py')])
assert (out/'arena-delivery/summary.json').is_file(), 'Publishing did not finish'
assert json.loads((out/'arena-delivery/summary.json').read_text(encoding='utf-8'))['passed']
run('formal-performance', [sys.executable, str(root/'tools/run_playable_performance.py'),
    '--player', str(root/'build/ninja-msvc-release/AzurePlayer.exe'),
    '--editor', str(root/'build/ninja-msvc-release/AzureRender.exe'),
    '--exploration', str(root/'assets_public/exploration/project.azureproject'),
    '--platformer', str(root/'assets_public/platformer/project.azureproject'),
    '--output', str(out/'arena-formal-performance')])
assert run('operator-packet', [sys.executable, str(out/'create_operator_packet.py')]) == 0
raise SystemExit(int(any(row['exitCode'] for row in results)))
