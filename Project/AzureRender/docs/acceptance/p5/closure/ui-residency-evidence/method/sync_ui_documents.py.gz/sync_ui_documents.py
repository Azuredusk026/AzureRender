"""Synchronize measured candidate results while keeping unfinished gates open."""
import json
from pathlib import Path

root = Path.cwd().resolve()
work = root/'build/p5-ui-residency-2026-10-11'
inventory = json.loads((work/'arena-regression-inventory.json').read_text(encoding='utf-8'))
assert inventory['complete'] and inventory['total'] == 454
delivery = json.loads((work/'arena-delivery/summary.json').read_text(encoding='utf-8'))
assert delivery['passed'] and len(delivery['checks']) == 10
formal = json.loads((work/'arena-final-formal-performance/summary.json').read_text(encoding='utf-8'))
rounds = [row for group in formal['rounds'].values() for row in group]
assert len(rounds) == 15
passed = sum(row['passed'] for row in rounds)
runs = {name:json.loads((work/directory/'summary.json').read_text(encoding='utf-8'))
        for name,directory in [('platformer','arena-platformer-aligned-longrun'),('standard','arena-standard-longrun')]}
assert all(row['actualSeconds'] >= 1800 for row in runs.values())
def replace(name, old, new):
    path = root/name
    text = path.read_text(encoding='utf-8')
    assert text.count(old) == 1, (name, old)
    path.write_text(text.replace(old, new, 1), encoding='utf-8')

page = 'docs/acceptance/p5/closure/ui-residency.md'
replace(page, '> 状态：界面峰值已归因，共享缓冲页候选通过探针。',
    '> 状态：界面峰值已归因，正式测量按本页结果维护。')
for old,new in [
    ('- [ ] 完成两配置完整回归。','- [x] 完成两配置完整回归。'),
    ('- [ ] 核验双设备发布与完整游戏流程。','- [x] 核验双设备发布与完整游戏流程。')]:
    replace(page, old, new)
if all(row['status']=='passed' for row in runs.values()):
    replace(page, '- [ ] 完成平台和标准场景各三十分钟长跑。',
        '- [x] 完成平台和标准场景各三十分钟长跑。')
if formal['passed']:
    replace(page, '- [ ] 按当前来源通过全部正式性能门禁。',
        '- [x] 按当前来源通过全部正式性能门禁。')

block = '\n## 落地控制器停稳调查\n\n'
block += '共享页候选首轮平台长跑在 85.844 秒失败。\n'
block += '已落地角色距首个平台中心约 0.951 米。\n'
block += '该点处于平台内，但超过原有 0.8 米范围。\n'
block += '控制器保持等待，直到落地阶段超时。\n\n'
block += '控制器在目标表面内通过前后移动调整位置。\n'
block += '松键后确认制动完成，再执行原有落地检查。\n'
block += '离地、较低表面、越界或通关时释放纠正输入。\n'
block += '位置范围、高度与地面要求均保持有效。\n\n'
block += '九项新规则先复现失败，再通过候选验证。\n'
block += '生产工具的全部三十五项规则通过。\n'
block += '两配置对应 CTest 及构建来源核验通过。\n'
block += '原始失败与实际公共输入分别归档。\n\n'
block += '变化仅涉及两个验收客户端工具。\n'
block += '两配置各五十四项构建产物逐字节一致。\n'
block += '正式性能的一百一十四项运行依赖保持一致。\n'
block += '标准长跑保留测量来源及工具等价说明。\n\n'
block += '## 当前候选正式结果\n\n'
block += 'Release 二百二十八项与 Debug 二百二十六项通过。\n'
block += '测试清单按名称核对，共四百五十四项。\n'
block += 'Debug CPU 使用文档规定的串行入口复测。\n'
block += '初始并行失败及调度对照完整归档。\n\n'
block += '五项目在 NVIDIA 与 Intel 上完成十组检查。\n'
block += '覆盖探索接平台、独立通关与退出释放。\n'
block += '六份 ZIP 的条目、许可与哈希逐项核验。\n'
block += '两份制作项目按当前运行时重新发布。\n\n'
block += '| 正式长跑 | 实际秒数 | 帧数 | 工作集增长 | 状态 |\n| --- | --- | --- | --- | --- |\n'
for name,label in [('platformer','平台关卡'),('standard','标准交替场景')]:
    row=runs[name]
    block += f"| {label} | {row['actualSeconds']:.3f} | {row['frames']} | {row['workingSetGrowth']*100:.3f}% | {row['status']} |\n"
p=runs['platformer']
block += f"\n平台完成 {p['completedRoutes']} 次通关。\n必经落点验证 {p['mandatoryLandings']} 次。\n"
block += f"起点与检查点恢复分别为 {p['startFallRecoveries']}、{p['checkpointFallRecoveries']} 次。\n"
block += f"水平与垂直承载分别为 {p['horizontalRides']}、{p['verticalRides']} 次。\n\n"
block += '| 场景 | GPU P95 | CPU P95 | 物理 P95 | 缓冲数量增长 |\n| --- | --- | --- | --- | --- |\n'
for name,label in [('platformer','平台关卡'),('standard','标准交替场景')]:
    row=runs[name]
    block += f"| {label} | {row['gpu']['p95']:.3f} 毫秒 | {row['cpu']['p95']:.3f} 毫秒 | {row['physics']['p95']:.3f} 毫秒 | {row['residencyGrowth']['buffers']*100:.3f}% |\n"
block += f'\n当前来源十五轮正式性能中，{passed} 轮通过。\n'
block += '每轮沿用三百帧预热及一千八百帧采样。\n'
block += '五百实例、温度与所有预算保持原有要求。\n'
block += '失败轮次按其原始结果保留。\n\n'
failed_rounds = [(name,index,row) for name,group in formal['rounds'].items()
                 for index,row in enumerate(group,1) if not row['passed']]
for name,index,row in failed_rounds:
    if 'stableWorkingSetGrowth' in row:
        block += f"{name} 第 {index} 轮工作集增长 {row['stableWorkingSetGrowth']*100:.3f}%。\n"
    for failure in row.get('budgetFailures',[]):
        block += f"诊断：`{failure}`。\n"
    block += '\n'
if failed_rounds:
    block += '两批正式测量使用相同的运行产物。\n'
    block += '来源变化及产物等价按原始记录核验。\n'
    block += '当前总量记录尚不能确认分配与驻留原因。\n'
    block += '系统追踪需关联这些失败区间及其调用栈。\n\n'
block += '| 负载 | 轮次 | GPU P95 | 工作集增长 | 结果 |\n| --- | --- | --- | --- | --- |\n'
for name,group in formal['rounds'].items():
    for index,row in enumerate(group,1):
        gpu=f"{row['gpu']['p95']:.3f} 毫秒" if 'gpu' in row else '测量失败'
        memory=f"{row['stableWorkingSetGrowth']*100:.3f}%" if 'stableWorkingSetGrowth' in row else '缺少有效值'
        block += f"| {name} | {index} | {gpu} | {memory} | {'通过' if row['passed'] else '失败'} |\n"
block += '\n当前测量通过与历史异常的因果分别记录。\n'
block += '管线查询候选的探索工作集异常仍需系统采集。\n'
block += '实体操作、听感与制作效率保持未执行。\n'
block += '当前阶段全部必需门禁通过后执行格式阶段。\n\n'
block += '原始记录见[界面驻留证据](ui-residency-evidence/manifest.json)。\n'
path=root/page;path.write_text(path.read_text(encoding='utf-8')+block,encoding='utf-8')

replace('README.md', '\n资产格式后续阶段见',
    '\n界面几何使用共享缓冲页，保留在途退休规则。\n'
    '当前来源回归与实测见[界面驻留验收](docs/acceptance/p5/closure/ui-residency.md)。\n'
    '历史内存归因和人工门禁继续按实际结果维护。\n\n资产格式后续阶段见')
replace('CHANGELOG.md', '# Changelog\n\n',
    '# Changelog\n\n## P5-E 界面几何驻留修复 2026-10-11\n\n'
    '界面顶点与索引共用分页缓冲及独立绑定区间。\n'
    '在途区间保留三帧，退休区间合并复用。\n'
    '驻留观察分别记录几何、页面与实际容量。\n'
    '检查点掉落验证先完成中心金币拾取。\n\n'
    f'完整回归四百五十四项与双设备十组交付通过。\n'
    f'两类长跑各实跑三十分钟，正式性能 {passed}/15 轮通过。\n'
    '原始失败、来源与剩余门禁见[验收](docs/acceptance/p5/closure/ui-residency.md)。\n\n')
replace('docs/plans/azure-engine-plan.md',
    '平台与标准场景各完成三十分钟长跑。',
    '共享页候选两类场景各实跑三十分钟。')
replace('docs/plans/azure-engine-plan.md',
    '正式十五轮候选有一轮工作集超限。',
    f'界面共享页候选的正式性能 {passed}/15 轮通过。\n'
    '两类三十分钟长跑按[当前验收](../acceptance/p5/closure/ui-residency.md)维护状态。\n'
    '历史探索工作集归因及人工门禁仍待完成。')
replace('docs/plans/2026-10-10-p5-closure-and-user-experience.md',
    '| P5-B | 驻留分类与真实追踪已保存，覆盖限制已核验 | 完整因果归因 |',
    '| P5-B | 驻留分类、调用追踪与界面缓冲所有权已核验 | 探索工作集完整因果归因 |')
replace('docs/plans/2026-10-10-p5-closure-and-user-experience.md',
    '| P5-C | 切关生命周期局部回归与短测通过 | 内存因果闭环及正式复测 |',
    '| P5-C | 共享页修复、固定画面及当前来源正式复测已执行 | 全轮预算及探索内存因果闭环 |')
replace('docs/plans/2026-10-10-p5-closure-and-user-experience.md',
    '| P5-E | 全回归、移动发布与标准长跑通过，平台路线控制已核验 | 平台缓冲驻留、正式性能与人工门禁 |',
    '| P5-E | 共享页候选完成全回归、双设备交付及两类长跑 | 全部预算、历史归因及人工门禁 |')
if runs['platformer']['status']=='passed':
    replace('docs/plans/2026-10-10-p5-closure-and-user-experience.md',
        '- [ ] 平台实际长跑三十分钟，覆盖重生和重开。',
        '- [x] 平台实际长跑三十分钟，覆盖重生和重开。')
replace('docs/acceptance/p5/2026-10-10.md', '## 当前软件候选',
    '## 界面驻留候选\n\n共享页候选完成四百五十四项完整回归。\n'
    '双设备发布及两类三十分钟测量已经执行。\n'
    f'当前正式性能通过 {passed}/15 轮。\n'
    '详细门禁见[界面驻留验收](closure/ui-residency.md)。\n\n## 软件交付候选来源')
replace('docs/acceptance/p6/2026-10-10.md',
    '| 平台三十分钟长跑 | 实际运行完成，缓冲计数增长 5.941% 超限 | [P5 验收](../p5/2026-10-10.md) |',
    f"| 平台三十分钟长跑 | 共享页候选实跑 {p['actualSeconds']:.3f} 秒，状态为 {p['status']} | [界面驻留验收](../p5/closure/ui-residency.md) |")
replace('docs/acceptance/p6/2026-10-10.md',
    '标准长跑通过，平台缓冲驻留门禁失败。',
    '两类长跑按共享页候选的[实测记录](../p5/closure/ui-residency.md)维护状态。')

path=root/'docs/plans/authoring-usability-manifest.json'
manifest=json.loads(path.read_text(encoding='utf-8'))
assert not any(row['id']=='UX-009' for row in manifest['issues'])
manifest['issues'].append(dict(id='UX-009',severity='major',
    summary='同一项目的并行规划争用资产缓存临时文件',owner='AssetDatabase',
    status='SharedTemporaryPathRaceReproducedNotFixed',source='src/runtime/AssetDatabase.cpp',
    productionUiVerified=False,physicalInputVerified=False,
    acceptance='docs/acceptance/p5/closure/ui-residency.md'))
manifest['uiResidencyCandidate']=dict(sourceHash=formal['sourceHash'],
    acceptance='docs/acceptance/p5/closure/ui-residency.md',releaseTests=228,debugTests=226,
    deliveryChecks=10,formalPerformancePassed=formal['passed'],formalPassedRounds=passed,formalTotalRounds=15,
    longRuns={name:{key:row[key] for key in ('status','actualSeconds','frames','workingSetGrowth')}
        for name,row in runs.items()},
    packageHashes={row['kind']:row['sha256'] for row in delivery['packages']},
    physicalInputVerified=False,subjectiveAudioVerified=False,authoringEfficiencyVerified=False,
    priorWorkingSetCauseResolved=False)
path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(formalPassedRounds=passed,longRuns={name:row['status'] for name,row in runs.items()},
    currentStagesComplete=False,assetStagesStarted=False)))
