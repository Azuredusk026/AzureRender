"""Check original bytes, source association and deliberately open gates."""
import gzip
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-ui-residency-2026-10-11'
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify
evidence=root/'docs/acceptance/p5/closure/ui-residency-evidence'
manifest=json.loads((evidence/'manifest.json').read_text(encoding='utf-8'))
source=hashlib.sha256(json.dumps(inputs(root),sort_keys=True).encode()).hexdigest()
assert source==manifest['sourceHash'], 'Current inputs differ from measured candidate'
for name,item in manifest['files'].items():
    stored=(evidence/name).read_bytes()
    raw=gzip.decompress(stored)
    assert hashlib.sha256(stored).hexdigest()==item['sha256'],name
    assert hashlib.sha256(raw).hexdigest()==item['originalSha256'],name
    assert raw==(root/item['source']).read_bytes(),item['source']
for config in ('release','debug'):
    proof=json.loads((work/('final-'+config+'-provenance.json')).read_text(encoding='utf-8'))
    verify(root,proof)
    assert hashlib.sha256(json.dumps(proof['source'],sort_keys=True).encode()).hexdigest()==source
    original=json.loads((work/('arena-'+config+'-provenance.json')).read_text(encoding='utf-8'))
    assert original['products']==proof['products']
equivalence=manifest['toolSourceEquivalence']
assert equivalence['runtimeDependencyByteEquivalent'] and equivalence['finalToolSourceHash']==source
assert manifest['regressionTotal']==454 and manifest['deliveryChecks']==10
assert manifest['formalRounds']==15
delivery=json.loads((work/'arena-delivery/summary.json').read_text(encoding='utf-8'))
assert len(delivery['packages'])==6
for row in delivery['packages']:
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['kind']
operator=json.loads((work/'operator-review/feedback-template.json').read_text(encoding='utf-8'))
assert operator['status']=='NotExecuted'
assert operator['packageHashes']=={row['kind']:row['sha256'] for row in delivery['packages']}
assert not manifest['physicalInputVerified'] and not manifest['subjectiveAudioVerified']
assert not manifest['authoringEfficiencyVerified'] and not manifest['priorWorkingSetCauseResolved']
plan=json.loads((root/'docs/plans/asset-format-manifest.json').read_text(encoding='utf-8'))
assert not plan['prerequisitesComplete'] and all(row['status']=='Planned' for row in plan['phases'])
pending=json.loads((root/'docs/plans/authoring-usability-manifest.json').read_text(encoding='utf-8'))
assert not pending['u15Complete'] and not pending['u16Complete'] and not pending['p6Complete']
assert pending['uiResidencyCandidate']['sourceHash']==source
assert not pending['uiResidencyCandidate']['priorWorkingSetCauseResolved']
git_mode=sys.argv[1] if len(sys.argv)>1 else None
if git_mode:
    assert git_mode in ('HEAD','index')
    for name,item in manifest['files'].items():
        relative='Project/AzureRender/docs/acceptance/p5/closure/ui-residency-evidence/'+name
        reference='HEAD:'+relative if git_mode=='HEAD' else ':'+relative
        stored=subprocess.run(['git','show',reference],capture_output=True,check=True).stdout
        assert hashlib.sha256(stored).hexdigest()==item['sha256'],name
result=dict(passed=True,files=len(manifest['files']),sourceHash=source,gitMode=git_mode,
    formalPerformancePassed=manifest['formalPerformancePassed'],longRuns=manifest['longRuns'],
    currentStagesComplete=False,assetStagesStarted=False)
(work/('verification-'+(git_mode or 'working')+'.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
