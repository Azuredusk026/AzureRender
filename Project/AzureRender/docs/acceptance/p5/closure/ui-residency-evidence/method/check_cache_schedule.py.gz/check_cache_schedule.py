"""Compare simultaneous and serialized planners on isolated project copies."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

root = Path.cwd().resolve()
out = root/'build/p5-ui-residency-2026-10-11/cache-schedule'
out.mkdir(exist_ok=False)
source = root/'assets_public/platformer'
executable = root/'build/ninja-msvc-debug/AzurePlatformerFlowTests.exe'
records = []
def run(base, phase):
    args = [str(executable), str(base/'project.azureproject'), str(base.parent/('phase-'+str(phase))), str(phase)]
    result = subprocess.run(args, capture_output=True, text=True, encoding='utf-8', errors='replace')
    log = base.parent/('phase-'+str(phase)+'.log')
    log.write_text(result.stdout+result.stderr, encoding='utf-8')
    return dict(phase=phase, exitCode=result.returncode, log=log.relative_to(out).as_posix(),
                failure=result.stderr.strip() if result.returncode else None)
for index in range(3):
    base = out/('concurrent-'+str(index+1))/'project'
    shutil.copytree(source, base, ignore=shutil.ignore_patterns('.azure'))
    with ThreadPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(lambda phase:run(base, phase), (0,60,135)))
    records.append(dict(schedule='concurrent', attempt=index+1, results=results))
base = out/'serialized'/'project'
shutil.copytree(source, base, ignore=shutil.ignore_patterns('.azure'))
results = [run(base, phase) for phase in (0,60,135)]
records.append(dict(schedule='serialized', results=results))
assert all(row['exitCode'] == 0 for row in results), results
result = dict(schemaVersion=1, originalRegressionFailure='AzureGame.PlatformerPhase4',
    originalInvocation='ctest -LE gpu -j 4', documentedInvocation='ctest -LE gpu -j 1',
    sharedTemporarySuffix='.tmp', serializedPassed=True,
    concurrentFailures=sum(row['exitCode'] != 0 for batch in records if batch['schedule']=='concurrent' for row in batch['results']),
    multiProcessCacheWritesVerified=False, records=records,
    executableSha256=hashlib.sha256(executable.read_bytes()).hexdigest())
(out/'summary.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result))
