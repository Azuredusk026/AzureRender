"""Read compact status without polling or changing the running programs."""
import json
from pathlib import Path

root = Path.cwd().resolve()
out = root/'build/p5-ui-residency-2026-10-11'
for name in ('regression.log', 'continuation.log', 'aligned-acceptance.log'):
    path = out/name
    if path.exists():
        print(name, ':', ' | '.join(path.read_text(encoding='utf-8', errors='replace').splitlines()[-5:]))
for name in ('release-cpu', 'release-gpu', 'debug-cpu', 'debug-gpu'):
    path = out/('arena-'+name+'.log')
    if name=='debug-cpu' and (out/'arena-debug-cpu-serialized.log').exists():
        path=out/'arena-debug-cpu-serialized.log'
    if path.exists():
        rows = path.read_text(encoding='utf-8', errors='replace').splitlines()
        print(name, ':', ' | '.join(rows[-3:]))
for name in ('arena-platformer-longrun', 'arena-standard-longrun', 'arena-platformer-aligned-probe', 'arena-platformer-aligned-longrun'):
    for filename in ('progress.json', 'summary.json', 'error.json'):
        path = out/name/filename
        if path.exists():
            data = json.loads(path.read_text(encoding='utf-8'))
            print(name, filename, json.dumps({key:value for key,value in data.items()
                if key in ('status','seconds','actualSeconds','frames','gpuFrames','working',
                           'completedRoutes','mandatoryLandings','errorType','error')}))
    journal=out/name/'route.jsonl'
    if journal.exists():
        with journal.open('rb') as stream:
            stream.seek(max(0,journal.stat().st_size-131072))
            rows=stream.read().splitlines()
        for raw in reversed(rows):
            try:row=json.loads(raw)
            except ValueError:continue
            if row.get('kind')=='complete':
                print(name,'latest complete',json.dumps(row));break
for folder in ('arena-formal-performance','arena-final-formal-performance'):
    path = out/folder/'partial.json'
    if path.exists():
        data = json.loads(path.read_text(encoding='utf-8'))
        print(folder, json.dumps({name:[dict(passed=row['passed'],failures=row.get('budgetFailures'),
            error=row.get('error')) for row in rounds] for name,rounds in data.items()}))
for name in ('arena-delivery.log', 'arena-standard-longrun.log', 'formal-performance.log','final-formal-performance.log','arena-platformer-aligned-longrun.log'):
    path = out/name
    if path.exists():
        rows=path.read_text(encoding='utf-8',errors='replace').splitlines()
        print(name, ':', ' | '.join(line[:300] for line in rows[-2:]))
