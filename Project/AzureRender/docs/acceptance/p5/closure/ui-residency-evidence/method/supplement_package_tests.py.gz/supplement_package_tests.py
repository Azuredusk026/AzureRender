import hashlib,json,re,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve();out=root/'build/p5-ui-residency-2026-10-11'
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs
frozen=inputs(root);records=json.loads((out/'arena-regression-status.json').read_text(encoding='utf-8'))
assert len(records)==4 and all(r['exitCode']==0 for r in records),records
ctest=Path('D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe')
log=out/'arena-release-packages.log'
with log.open('w',encoding='utf-8') as stream:
 result=subprocess.run([str(ctest),'--test-dir',str(root/'build/ninja-msvc-release'),'-C','Release','-R','^AzureEngine.(GamePackage|PlayablePackage)$','--output-on-failure','-j','1'],cwd=root,stdout=stream,stderr=subprocess.STDOUT)
assert inputs(root)==frozen
records.append(dict(configuration='release',group='release-packages',exitCode=result.returncode,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
(out/'arena-regression-status.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
assert result.returncode==0,log
inventory=[]
for configuration in ('release','debug'):
 configured=json.loads(subprocess.run([str(ctest),'--test-dir',str(root/('build/ninja-msvc-'+configuration)),'-C',configuration.capitalize(),'--show-only=json-v1'],capture_output=True,check=True,text=True).stdout)
 expected={t['name'] for t in configured['tests']};passed=set();failures=[]
 for item in records:
  if item['configuration']!=configuration:continue
  text=(out/item['log']).read_text(encoding='utf-8')
  for name,state in re.findall(r'Test\s+#\d+:\s+(\S+)\s+\.{2,}\s+(Passed|\*\*\*Failed)',text):
   if state=='Passed':passed.add(name)
   else:failures.append(name)
 missing=sorted(expected-passed);assert not missing and not failures,(configuration,missing,failures)
 inventory.append(dict(configuration=configuration,configured=len(expected),passed=len(passed),missing=missing,failures=failures))
result=dict(schemaVersion=1,complete=True,configurations=inventory,total=sum(r['passed'] for r in inventory))
assert result['total']==454,result
(out/'arena-regression-inventory.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
