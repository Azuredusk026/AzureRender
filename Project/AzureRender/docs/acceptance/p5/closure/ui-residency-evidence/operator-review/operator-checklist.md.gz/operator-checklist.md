# 候选包人工复核操作单

> 文档类型：本机验收操作单
> 状态：发布链机器检查通过，人工结果待填写
> 源码基点：`3a142deeb857515b7f52d563da1eea09b200da9c`

## 使用条件

正式性能、根因归因和长跑分别维护状态。
操作前核对本轮测量汇总与候选来源。
实体操作、制作效率和听感由操作者记录。
自动输入结果按其实际覆盖范围使用。

## 进入编辑器

使用 PowerShell 启动候选编辑器。
通过项目入口创建两个新的制作项目。
验收项目放入独立目录，保留候选包原件。

```powershell
& "D:/Assigment/2609/FYP/Project/AzureRender/build/p5-ui-residency-2026-10-11/arena-delivery/Moved Engine/bin/AzureRender.exe" --editor-project "D:/Assigment/2609/FYP/Project/AzureRender/build/p5-ui-residency-2026-10-11/arena-delivery/Moved scene_inspector/game/project.azureproject"
```

制作步骤见[从空关卡制作并发布游戏](D:/Assigment/2609/FYP/Project/AzureRender/docs/tutorials/editor-first-game.md)。
实体检查见[键鼠与音效复核表](D:/Assigment/2609/FYP/Project/AzureRender/docs/acceptance/p5/physical-input.md)。
制作任务见[P6 制作验收表](D:/Assigment/2609/FYP/Project/AzureRender/docs/acceptance/p6/2026-10-10.md)。
两份表中的未执行项由实际结果填写。

## 完整游戏与听感

启动探索包，实际通关并进入平台关卡。
使用 WASD、Shift、Space、E 和 R 操作。
检查必经跳跃、金币、承载、掉落及终点。
五类音效分别记录辨识度、音量和重复触发。

```powershell
& "D:/Assigment/2609/FYP/Project/AzureRender/build/p5-ui-residency-2026-10-11/arena-delivery/Moved exploration/start-game.cmd"
```

## 制作效率与反馈

两工作流分别记录步骤、耗时与误操作恢复。
依据首轮实际数据填写效率目标。
目标登记后执行复核并记录结果。
发现问题时记录触发步骤与可观察结果。

结果模板为[feedback-template.json](D:/Assigment/2609/FYP/Project/AzureRender/build/p5-ui-residency-2026-10-11/operator-review/feedback-template.json)。
另存填写结果，保留原模板中的待验状态。
记录操作者、设备、显示缩放和声音输出。
每项填写通过、失败或未执行。

## 候选包来源

| 产物 | SHA-256 |
| --- | --- |
| engine | `4ad5612ec53cfda101ea5f04ac0e9ee89f4f36762cb20b6278db35c21fdb142b` |
| exploration | `ac3743ac981c3cc7af7bb00337eeedb1a4f6408420feeae0e9a291efd423dae7` |
| platformer | `69f47ad36158b8248ff6183515926456355b967f796148204a96c65b856bacdf` |
| scene_inspector | `db824dca71e89088ca469ffebd45aa52c5e34314650f9038e47bdcd4c73e221a` |
| authored-exploration | `1d859b118894378178139b99765ef4885f55407d858c6dfc1d54e6e036654963` |
| authored-inspection | `b9b9163c0770b81f16645af849298cfe902f815d2ee3894688721c696035ffb0` |

包清单见[发布来源](D:/Assigment/2609/FYP/Project/AzureRender/build/p5-ui-residency-2026-10-11/arena-delivery/packages/provenance.json)。
源码原字节归档见[构建输入](D:/Assigment/2609/FYP/Project/AzureRender/build/p5-ui-residency-2026-10-11/arena-release-provenance.json)。
人工结果只适用于表中记录的具体候选包。
