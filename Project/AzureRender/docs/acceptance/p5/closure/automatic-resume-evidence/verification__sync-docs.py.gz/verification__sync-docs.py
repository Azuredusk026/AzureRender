from pathlib import Path
import json,subprocess
root=Path.cwd();out=root/'build/automatic-resume-2026-10-11';changes={}
def replace_file(name,replacements):
    p=root/name;before=p.read_text(encoding='utf-8');after=before
    for old,new in replacements:
        assert old in after,(name,old);after=after.replace(old,new,1)
    p.write_text(after,encoding='utf-8')
    changes[name]=replacements
link='[本轮验收](../acceptance/p5/closure/automatic-resume.md)'
replace_file('docs/plans/azure-engine-plan.md',[
('GPU 八十七项通过，Release 四十一项待测。','GPU 一百二十八项通过，本轮补齐四十一项。'),
('当前来源十五轮性能与两类长跑等待空闲环境。','当前来源十五轮性能通过十四轮。\n探索第二轮的软件热降频保持失败。\n两类长跑依赖正式性能全轮通过。\n当前证据与边界见'+link+'。')])
replace_file('README.md',[
('人工待项在 P8 复核，正式 GPU 门禁等待空闲环境。','人工待项在 P8 复核，非桌面输入 GPU 回归通过。\n正式性能十四轮通过，一轮热状态失败。\n来源与待项见[本轮验收](docs/acceptance/p5/closure/automatic-resume.md)。')])
replace_file('docs/plans/2026-10-11-frame-pacing.md',[
('> 状态：机制已实现，完整 GPU 门禁等待空闲环境。','> 状态：非桌面输入回归通过，正式性能环境门禁失败。'),
('GPU 八十七项通过，Release 四十一项待测。','GPU 一百二十八项通过，本轮补齐四十一项。'),
('游戏保持运行时，执行来源与包完整性检查。\n空闲环境恢复后，先复测发布超时用例。\n随后执行剩余 GPU 回归及十五轮正式性能。','当前候选的发布超时用例复测通过。\n剩余 GPU 回归已完成，正式十五轮通过十四轮。\n探索第二轮的驱动软件热降频导致失败。\n来源与边界见[恢复验收](../acceptance/p5/closure/automatic-resume.md)。')])
replace_file('docs/acceptance/p5/closure/frame-pacing.md',[
('> 状态：CPU 回归通过，GPU 回归等待空闲环境。','> 状态：非桌面输入回归通过，正式性能十四轮通过。'),
('| Release GPU | 二十四项通过 | 四十一项等待空闲环境 |','| Release GPU | 六十五项通过 | 原生桌面输入在 P8 执行 |'),
('| 正式性能 | 当前来源零轮 | 五类负载共十五轮 |','| 正式性能 | 当前来源十五轮，十四轮通过 | 探索第二轮热状态失败 |'),
('八十七项 GPU 通过结果包含三十二项等价关联。\n其余五十五项在当前来源实际执行。','一百二十八项 GPU 通过结果包含三十二项等价关联。\n其余九十六项在当前来源实际执行。'),
('待测 Release 项包含发布流程的失败复测。','发布流程的失败复测通过。\n本轮 CPU 回归另实际执行三百二十六项。\n来源、失败与推进边界见[恢复验收](automatic-resume.md)。')])
block='## P5-B 当前候选自动恢复与正式性能 2026-10-11\n\n两配置 CPU 回归共三百二十六项通过。\n剩余四十一项 GPU 回归通过，累计一百二十八项。\n原生桌面输入的两项测试在 P8 执行。\n\n正式十五轮通过十四轮。\n探索第二轮的运行期间软件热降频导致失败。\n全部轮次的耗时、工作集和容量指标达标。\n证据与推进边界见[恢复验收](docs/acceptance/p5/closure/automatic-resume.md)。\n\n'
replace_file('CHANGELOG.md',[('# Changelog\n\n','# Changelog\n\n'+block)])
manifest=root/'docs/plans/authoring-usability-manifest.json';d=json.loads(manifest.read_text(encoding='utf-8'));c=d['framePacingCandidate']
c.update(status='AutomaticRegressionVerifiedFormalThermalGateBlocked',evidence='docs/acceptance/p5/closure/automatic-resume-evidence/manifest.json',acceptance='docs/acceptance/p5/closure/automatic-resume.md',gpuVerifiedUniqueTests=128,gpuCurrentSourcePassedTests=96,pendingNonDesktopGpuTests=0,formalRounds=15,formalPassedRounds=14,formalPerformancePassed=False,currentSourceLongRuns=0,blockingRound='exploration-2')
manifest.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Save the exact transformations for staging only this turn's changes.
(out/'document-transformations.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),encoding='utf-8')
for name in changes:
    baseline=subprocess.check_output(['git','show','HEAD:Project/AzureRender/'+name],cwd=root).decode('utf-8').replace('\r\n','\n')
    for old,new in changes[name]:
        assert old in baseline,(name,'HEAD context missing');baseline=baseline.replace(old,new,1)
    p=out/'index-content'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(baseline,encoding='utf-8')
print('Synchronized',len(changes)+1,'files; prepared isolated index content')
