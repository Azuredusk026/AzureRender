from pathlib import Path
import subprocess,sys,json,hashlib,time
root=Path.cwd();out=root/'build/automatic-resume-2026-10-11';sys.path.insert(0,str(root/'tools'))
from build_provenance import verify
results=[]
for config in ('debug','release'):
    proof=json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text(encoding='utf-8'));verify(root,proof)
    log=out/f'{config}-cpu.log'
    with log.open('w',encoding='utf-8') as stream:
        code=subprocess.run(['ctest','--test-dir',str(root/f'build/ninja-msvc-{config}'),'-C',config.title(),'--output-on-failure','-LE','gpu','-j','1'],stdout=stream,stderr=subprocess.STDOUT).returncode
    verify(root,proof);results.append({'configuration':config,'exitCode':code,'log':log.name})
    print(json.dumps(results[-1]),flush=True)
    if code:print(log.read_text(encoding='utf-8',errors='replace')[-5000:],flush=True);break
(out/'cpu-summary.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
raise SystemExit(any(r['exitCode'] for r in results))
