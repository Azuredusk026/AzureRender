import json
from pathlib import Path
import subprocess
import sys
root=Path.cwd().resolve();work=root/'build/p8-automatic-2026-10-11'
build=subprocess.run(['cmd.exe','/d','/c',str(work/'build.cmd')],stdout=(work/'monitor-build.log').open('w'),stderr=subprocess.STDOUT)
assert build.returncode==0
for config in ('debug','release'):
    with (work/f'monitor-{config}-cpu.log').open('w') as log:
        result=subprocess.run(['ctest','--test-dir',str(root/f'build/ninja-msvc-{config}'),'-C',config.title(),
            '--output-on-failure','-LE','gpu','-j','1'],stdout=log,stderr=subprocess.STDOUT)
    assert result.returncode==0,config
old=json.loads((root/'build/p5-observation-control-2026-10-11/source-association.json').read_text())
products={}
for config in ('debug','release'):
    proof=json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text())
    assert proof['products']==old['products'][config]['hashes'],config
    products[config]=dict(byteEquivalent=True,products=proof['products'])
data=dict(nativeProducts=products,gpuReexecuted=False,priorEvidence='p5-observation-control-2026-10-11/source-association.json',
    runtimeChanged=False,monitorCpuRegressionPassed=True)
(work/'monitor-verification.json').write_text(json.dumps(data,indent=2)+'\n')
print('Both CPU suites passed; native products byte equivalent.')
