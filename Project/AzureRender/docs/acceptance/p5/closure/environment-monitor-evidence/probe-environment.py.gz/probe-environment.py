import json
import os
from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()/'tools'))
from build_provenance import verify
from run_playable_performance import run

root=Path.cwd().resolve();work=root/'build/p8-automatic-2026-10-11'
proof=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text(encoding='utf-8'))
os.environ['DISABLE_VULKAN_OBS_CAPTURE']='1'
results=[]
for index,name in enumerate(('standard','exploration','standard','exploration'),1):
    verify(root,proof)
    project=(root/'build/p5-observation-control-2026-10-11/formal-performance'/name/'project.azureproject')
    result=run(root/'build/ninja-msvc-release/AzurePlayer.exe',project,work/f'environment-probe-{index}')
    result.update(diagnosticOnly=True,workload=name)
    (work/f'environment-probe-{index}.result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    results.append(dict(workload=name,growth=result['stableWorkingSetGrowth'],passed=result['passed'],
        failures=result['budgetFailures'],observations=len(result['environment']['runObservations']),
        peakTemperature=max(row['temperature'] for row in result['environment']['runObservations'])))
    (work/'environment-probe-summary.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    verify(root,proof)
    print(json.dumps(results[-1]),flush=True)
