import ast
import hashlib
import json
from pathlib import Path

ROOT=Path.cwd().resolve();WORK=ROOT/'build/p5-observation-control-2026-10-11'
OLD=ROOT/'build/p5-directory-reclamation-2026-10-11'
path=WORK/'source-association.json';association=json.loads(path.read_text(encoding='utf-8'))
def definitions(source):
    return {node.name:ast.dump(node,include_attributes=False) for node in ast.parse(source).body
            if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
before=definitions((OLD/'source-snapshot-o/tools/run_playable_long_run.py').read_text(encoding='utf-8'))
after=definitions((ROOT/'tools/run_playable_long_run.py').read_text(encoding='utf-8'))
symbols={}
for name in ('NativeWindow','isolated_environment','evaluate','inputs','periodic_statistics','process_memory'):
    assert before[name]==after[name],name
    symbols[name]=hashlib.sha256(after[name].encode()).hexdigest()
changed=set(association['changedSourceFiles'])
assert changed=={'tools/long_run_telemetry.py','tools/run_platformer_long_run.py',
    'tools/run_playable_long_run.py','tools/test_platformer_long_run.py'},changed
assert association['products']['debug']['byteEquivalent'] and association['products']['release']['byteEquivalent']
association.update(unchangedImportedGpuSymbols=symbols,
    equivalenceScope='Byte-identical native products, shaders and all unchanged functions imported by GPU test tools',
    newRuntimeObservationRequires='Two workflow probes and a new real platform long run',
    gpuTestsPreviouslyExecuted=128,gpuTestsNewlyExecuted=0)
path.write_text(json.dumps(association,indent=2),encoding='utf-8')
print(json.dumps(dict(passed=True,unchangedImportedSymbols=list(symbols),gpuEvidenceReexecuted=False)))
