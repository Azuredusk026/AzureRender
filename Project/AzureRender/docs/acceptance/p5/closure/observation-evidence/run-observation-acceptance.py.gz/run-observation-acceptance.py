import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT=Path.cwd().resolve();WORK=ROOT/'build/p5-observation-control-2026-10-11'
OLD=ROOT/'build/p5-directory-reclamation-2026-10-11'
sys.path.insert(0,str(ROOT/'tools'))
from build_provenance import verify
os.environ['PATH']='D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin'+os.pathsep+os.environ['PATH']
proofs={}
for config in ('debug','release'):
    proof=json.loads((ROOT/('build/ninja-msvc-'+config)/'build-provenance.json').read_text(encoding='utf-8'))
    verify(ROOT,proof);proofs[config]=proof
    (WORK/(config+'-provenance.json')).write_text(json.dumps(proof,indent=2),encoding='utf-8')
source_hash=hashlib.sha256(json.dumps(proofs['release']['source'],sort_keys=True).encode()).hexdigest()
snapshot=WORK/'source-snapshot-p';snapshot.mkdir(exist_ok=False)
for name,digest in proofs['release']['source'].items():
    target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/name).read_bytes())
    assert hashlib.sha256(target.read_bytes()).hexdigest()==digest,name
association=dict(sourceHash=source_hash,products={},gpuEvidenceReexecuted=False,sourceFiles=len(proofs['release']['source']))
for config,proof in proofs.items():
    old=json.loads((OLD/(config+'-provenance.json')).read_text(encoding='utf-8'))
    assert old['products']==proof['products'],'Native product changed; rerun all affected GPU tests'
    association['products'][config]=dict(byteEquivalent=True,hashes=proof['products'])
association.update(unchangedGpuDependencies=True,
    changedSourceFiles=[name for name,digest in proofs['release']['source'].items() if old['source'].get(name)!=digest],
    priorGpuEvidence=str(OLD/'gpu-summary.json'),priorSourceHash='41804e80288acf248965027b991f4af357ff57b757d100c77dcf2f1e31ca70f4')
(WORK/'source-association.json').write_text(json.dumps(association,indent=2),encoding='utf-8')
records=[]
def run(name,args):
    for proof in proofs.values():verify(ROOT,proof)
    print('Starting',name,flush=True)
    start=time.time()
    with (WORK/(name+'.log')).open('w',encoding='utf-8') as log:
        process=subprocess.Popen(list(map(str,args)),cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        (WORK/'owned-child.json').write_text(json.dumps(dict(name=name,pid=process.pid)),encoding='utf-8')
        code=process.wait()
    for proof in proofs.values():verify(ROOT,proof)
    records.append(dict(name=name,exitCode=code,sourceHash=source_hash,seconds=time.time()-start))
    (WORK/'status.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    assert code==0,(name,code)
try:
    for config in ('debug','release'):
        run(config+'-cpu-regression',['ctest','--test-dir',ROOT/('build/ninja-msvc-'+config),'-C',config.title(),
            '--output-on-failure','-LE','gpu','-j','1'])
    template=(OLD/'verified-delivery.py').read_text(encoding='utf-8')
    template=template.replace('build/p5-directory-reclamation-2026-10-11/arena-delivery','build/p5-observation-control-2026-10-11/arena-delivery')
    template=template.replace('Azure-P5P6-directory-','Azure-P5P6-observation-')
    method=WORK/'verified-delivery.py';method.write_text(template,encoding='utf-8')
    run('delivery',[sys.executable,method])
    run('platformer-probe',[sys.executable,ROOT/'tools/run_platformer_long_run.py',
        '--package',WORK/'arena-delivery/Moved exploration','--output',WORK/'platformer-probe','--seconds','120','--probe'])
    run('standard-probe',[sys.executable,ROOT/'tools/run_playable_long_run.py',
        '--package',OLD/'Moved directory standard','--output',WORK/'standard-probe','--seconds','120','--probe'])
    run('platformer-longrun',[sys.executable,ROOT/'tools/run_platformer_long_run.py',
        '--package',WORK/'arena-delivery/Moved exploration','--output',WORK/'platformer-longrun','--seconds','1800'])
except BaseException as error:
    (WORK/'failure.json').write_text(json.dumps(dict(errorType=type(error).__name__,error=str(error),records=records),indent=2),encoding='utf-8')
    raise
