from pathlib import Path
root=Path.cwd().resolve();old=root/'build/p5-p6-closure-2026-10-10/native-memory-trace'
out=root/'build/p5-p6-inspection-2026-10-11/phase-trace';out.mkdir(exist_ok=False)
text=(old/'cache_shim.c').read_text()
text=text.replace('static PFN_vkCreateDevice realDevice;', 'static PFN_vkQueuePresentKHR realPresent;\nstatic uint64_t presentCount;\nstatic PFN_vkCreateDevice realDevice;')
text=text.replace('    realDestroy(device, allocator);', '''    LARGE_INTEGER begin, end;
    QueryPerformanceCounter(&begin);
    fprintf(stderr, "AZURE_DIAGNOSTIC_DESTROY begin=%lld frames=%llu\\n", begin.QuadPart, presentCount);
    realDestroy(device, allocator);
    QueryPerformanceCounter(&end);
    fprintf(stderr, "AZURE_DIAGNOSTIC_DESTROY end=%lld\\n", end.QuadPart);''')
text=text.replace('__declspec(dllexport) DWORD WINAPI AzureCacheStart', '''static VkResult VKAPI_CALL present(VkQueue queue, const VkPresentInfoKHR *info) {
    VkResult result = realPresent(queue, info);
    LARGE_INTEGER counter;
    ++presentCount;
    if (presentCount == 1 || presentCount % 240 == 0 || presentCount == 2100) {
        QueryPerformanceCounter(&counter);
        fprintf(stderr, "AZURE_DIAGNOSTIC_FRAME frame=%llu qpc=%lld\\n", presentCount, counter.QuadPart);
    }
    return result;
}
__declspec(dllexport) DWORD WINAPI AzureCacheStart''')
assert '    return MH_EnableHook(MH_ALL_HOOKS) == MH_OK ? 0 : 25;' in text
text=text.replace('    return MH_EnableHook(MH_ALL_HOOKS) == MH_OK ? 0 : 25;', '''    if (MH_CreateHook(GetProcAddress(loader, "vkQueuePresentKHR"), present, (LPVOID*)&realPresent) != MH_OK) return 25;
    return MH_EnableHook(MH_ALL_HOOKS) == MH_OK ? 0 : 26;''')
(out/'cache_shim.c').write_text(text)
(out/'CMakeLists.txt').write_text(f'''cmake_minimum_required(VERSION 3.21)
project(AzureDiagnosticPhaseTrace LANGUAGES C)
add_subdirectory("{(old/'minhook').as_posix()}" minhook EXCLUDE_FROM_ALL)
find_package(Vulkan REQUIRED)
add_library(AzureCacheShim SHARED cache_shim.c)
target_link_libraries(AzureCacheShim PRIVATE minhook Vulkan::Vulkan)
target_compile_options(AzureCacheShim PRIVATE /W4)
''')
(out/'build.cmd').write_text('''@echo off
call "D:\\Visual Studio\\2022\\VC\\Auxiliary\\Build\\vcvars64.bat" -vcvars_ver=14.38
if errorlevel 1 exit /b 1
"D:\\Visual Studio\\2022\\Common7\\IDE\\CommonExtensions\\Microsoft\\CMake\\CMake\\bin\\cmake.exe" -S build/p5-p6-inspection-2026-10-11/phase-trace -B build/p5-p6-inspection-2026-10-11/phase-trace/compiled -G Ninja -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 exit /b 2
"D:\\Visual Studio\\2022\\Common7\\IDE\\CommonExtensions\\Microsoft\\CMake\\CMake\\bin\\cmake.exe" --build build/p5-p6-inspection-2026-10-11/phase-trace/compiled --target AzureCacheShim
exit /b %errorlevel%
''')
print(out)
