from pathlib import Path
root=Path.cwd().resolve();old=root/'build/p5-p6-closure-2026-10-10/native-memory-trace'
work=root/'build/p5-p6-inspection-2026-10-11';phase=work/'phase-trace'
out=work/'statistics-probe';out.mkdir(exist_ok=False)
text=(phase/'cache_shim.c').read_text()
text=text.replace('static int inspect = 0;', 'static int inspect = 0;\nstatic int captureStatistics = 0;')
text=text.replace('if (result == VK_SUCCESS && (enabled || inspect))', 'if (result == VK_SUCCESS && (enabled || inspect || captureStatistics))')
text=text.replace('if (supported) entry->executableProperties', 'if (supported || captureStatistics) entry->executableProperties')
text=text.replace('if (!inspect) return;', 'if (!inspect && !captureStatistics) return;')
text=text.replace('            else ++inspectedPipelines;', '''            else {
                if (captureStatistics) {
                    PFN_vkGetPipelineExecutableStatisticsKHR statistics = (PFN_vkGetPipelineExecutableStatisticsKHR)vkGetDeviceProcAddr(device, "vkGetPipelineExecutableStatisticsKHR");
                    uint32_t executable;
                    if (!statistics) { ++inspectionErrors; continue; }
                    for (executable = 0; executable < number; ++executable) {
                        VkPipelineExecutableInfoKHR details = {VK_STRUCTURE_TYPE_PIPELINE_EXECUTABLE_INFO_KHR};
                        VkPipelineExecutableStatisticKHR values[128];
                        uint32_t total = 0, statistic;
                        details.pipeline = pipelines[index]; details.executableIndex = executable;
                        if (statistics(device, &details, &total, NULL) != VK_SUCCESS || total > 128) { ++inspectionErrors; continue; }
                        memset(values, 0, sizeof(values));
                        for (statistic = 0; statistic < total; ++statistic) values[statistic].sType = VK_STRUCTURE_TYPE_PIPELINE_EXECUTABLE_STATISTIC_KHR;
                        if (total && statistics(device, &details, &total, values) != VK_SUCCESS) ++inspectionErrors;
                        fprintf(stderr, "AZURE_DIAGNOSTIC_STATISTICS executable=%u count=%u\\n", executable, total);
                    }
                }
                ++inspectedPipelines;
            }''')
text=text.replace('    result = realGraphics(device, cacheFor(device, cache), count, info, allocator, pipelines);', '''    VkGraphicsPipelineCreateInfo modified[128];
    if (captureStatistics && count > 128) { ReleaseSRWLockExclusive(&lock); return VK_ERROR_OUT_OF_HOST_MEMORY; }
    if (captureStatistics) {
        uint32_t i;
        memcpy(modified, info, sizeof(*info)*count);
        for (i = 0; i < count; ++i) modified[i].flags |= VK_PIPELINE_CREATE_CAPTURE_STATISTICS_BIT_KHR;
    }
    result = realGraphics(device, cacheFor(device, cache), count, captureStatistics ? modified : info, allocator, pipelines);''')
text=text.replace('    result = realCompute(device, cacheFor(device, cache), count, info, allocator, pipelines);', '''    VkComputePipelineCreateInfo modified[128];
    if (captureStatistics && count > 128) { ReleaseSRWLockExclusive(&lock); return VK_ERROR_OUT_OF_HOST_MEMORY; }
    if (captureStatistics) {
        uint32_t i;
        memcpy(modified, info, sizeof(*info)*count);
        for (i = 0; i < count; ++i) modified[i].flags |= VK_PIPELINE_CREATE_CAPTURE_STATISTICS_BIT_KHR;
    }
    result = realCompute(device, cacheFor(device, cache), count, captureStatistics ? modified : info, allocator, pipelines);''')
text=text.replace('    if (wcsncmp(cachePath, L"disabled:", 9)', '    if (wcsncmp(cachePath, L"statistics:", 11) == 0) { enabled = 0; captureStatistics = 1; cachePath += 11; }\n    if (wcsncmp(cachePath, L"disabled:", 9)')
(out/'cache_shim.c').write_text(text)
(out/'CMakeLists.txt').write_text((phase/'CMakeLists.txt').read_text().replace('AzureDiagnosticPhaseTrace','AzureDiagnosticStatisticsProbe'))
(out/'build.cmd').write_text((phase/'build.cmd').read_text().replace('phase-trace','statistics-probe'))
print(out)
