from pathlib import Path
root=Path.cwd().resolve();old=root/'build/p5-p6-closure-2026-10-10/native-memory-trace'
out=root/'build/p5-p6-inspection-2026-10-11/mapping-trace';out.mkdir(exist_ok=False)
text=(old/'trace.c').read_text().replace('capacity=262144','capacity=8192')
text=text.replace('static FreeFn realFree;', '''static FreeFn realFree;
typedef LONG (NTAPI *MapFn)(HANDLE,HANDLE,PVOID*,ULONG_PTR,SIZE_T,PVOID,PSIZE_T,ULONG,ULONG,ULONG);
typedef LONG (NTAPI *MapExFn)(HANDLE,HANDLE,PVOID*,PVOID,PSIZE_T,ULONG,ULONG,PVOID,ULONG);
typedef LONG (NTAPI *UnmapFn)(HANDLE,PVOID);
typedef LONG (NTAPI *UnmapExFn)(HANDLE,PVOID,ULONG);
static MapFn realMap;
static MapExFn realMapEx;
static UnmapFn realUnmap;
static UnmapExFn realUnmapEx;''')
text=text.replace('__declspec(dllexport) DWORD WINAPI AzureTraceStart', '''static LONG NTAPI mapView(HANDLE section,HANDLE process,PVOID *base,ULONG_PTR bits,SIZE_T commit,
                          PVOID offset,PSIZE_T size,ULONG inherit,ULONG flags,ULONG protection) {
    uint64_t inBase=readPointer(base),inSize=readSize(size);
    LONG status=realMap(section,process,base,bits,commit,offset,size,inherit,flags,protection);
    record(4,process,base,size,inBase,inSize,flags,protection,status);return status;
}
static LONG NTAPI mapViewEx(HANDLE section,HANDLE process,PVOID *base,PVOID offset,PSIZE_T size,
                            ULONG flags,ULONG protection,PVOID parameters,ULONG count) {
    uint64_t inBase=readPointer(base),inSize=readSize(size);
    LONG status=realMapEx(section,process,base,offset,size,flags,protection,parameters,count);
    record(5,process,base,size,inBase,inSize,flags,protection,status);return status;
}
static LONG NTAPI unmapView(HANDLE process,PVOID address) {
    PVOID base=address;SIZE_T size=0;
    LONG status=realUnmap(process,address);
    record(6,process,&base,&size,(uint64_t)(ULONG_PTR)address,0,0,0,status);return status;
}
static LONG NTAPI unmapViewEx(HANDLE process,PVOID address,ULONG flags) {
    PVOID base=address;SIZE_T size=0;
    LONG status=realUnmapEx(process,address,flags);
    record(7,process,&base,&size,(uint64_t)(ULONG_PTR)address,0,flags,0,status);return status;
}
__declspec(dllexport) DWORD WINAPI AzureTraceStart''')
text=text.replace('    if(MH_EnableHook(MH_ALL_HOOKS)', '''    if(MH_CreateHook(GetProcAddress(nt,"NtMapViewOfSection"),mapView,(LPVOID*)&realMap)!=MH_OK)return 25;
    if(MH_CreateHook(GetProcAddress(nt,"NtMapViewOfSectionEx"),mapViewEx,(LPVOID*)&realMapEx)!=MH_OK)return 26;
    if(MH_CreateHook(GetProcAddress(nt,"NtUnmapViewOfSection"),unmapView,(LPVOID*)&realUnmap)!=MH_OK)return 27;
    if(MH_CreateHook(GetProcAddress(nt,"NtUnmapViewOfSectionEx"),unmapViewEx,(LPVOID*)&realUnmapEx)!=MH_OK)return 28;
    if(MH_EnableHook(MH_ALL_HOOKS)''')
(out/'trace.c').write_text(text)
(out/'CMakeLists.txt').write_text(f'''cmake_minimum_required(VERSION 3.21)
project(AzureMappedMemoryTrace LANGUAGES C)
add_subdirectory("{(old/'minhook').as_posix()}" minhook EXCLUDE_FROM_ALL)
add_library(AzureNtTrace SHARED trace.c)
target_link_libraries(AzureNtTrace PRIVATE minhook)
target_compile_definitions(AzureNtTrace PRIVATE WIN32_LEAN_AND_MEAN)
target_compile_options(AzureNtTrace PRIVATE /W4)
''')
phase=root/'build/p5-p6-inspection-2026-10-11/phase-trace/build.cmd'
(out/'build.cmd').write_text(phase.read_text().replace('phase-trace','mapping-trace').replace('--target AzureCacheShim','--target AzureNtTrace'))
print(out)
