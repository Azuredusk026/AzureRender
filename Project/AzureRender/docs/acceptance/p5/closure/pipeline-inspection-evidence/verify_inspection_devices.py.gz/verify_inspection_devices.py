import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve();out=root/'build/p5-p6-inspection-2026-10-11'
sys.path.insert(0,str(root/'tools'))
from build_provenance import verify,inputs
proof=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text());verify(root,proof)
frozen=inputs(root)
drivers=json.loads((root/'docs/acceptance/p1/evidence/2026-10-05/driver-inventory.json').read_text())
intel=next(x for x in drivers if x['DriverDesc']=='Intel(R) UHD Graphics')
assert hashlib.sha256(Path(intel['VulkanDriverName']).read_bytes()).hexdigest()==intel['manifestSha256']
rows=[]
for device in ('nvidia','intel'):
    for enabled in (True,False):
        case=out/(device+('-inspection-120' if enabled else '-disabled-120'));case.mkdir(exist_ok=False)
        env=os.environ.copy();env.update(VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',VK_LAYER_VALIDATE_SYNC='1')
        if device=='intel':env.update(VK_DRIVER_FILES=intel['VulkanDriverName'],VK_ICD_FILENAMES=intel['VulkanDriverName'])
        args=[str(root/'build/ninja-msvc-release/AzurePlayer.exe'),'--project',str(root/'assets_public/exploration/project.azureproject'),
              '--width','960','--height','540','--fixed-frame-step','--smoke-frames','120',
              '--gpu-timing','--gpu-timing-output',str(case/'timing.json'),'--capture-dir',str(case/'captures'),'--capture-frames','120']
        if not enabled:args.append('--disable-pipeline-inspection')
        info=subprocess.STARTUPINFO();info.dwFlags|=subprocess.STARTF_USESHOWWINDOW;info.wShowWindow=0
        result=subprocess.run(args,env=env,cwd=root,capture_output=True,encoding='utf-8',errors='replace',timeout=180,startupinfo=info)
        (case/'stdout.log').write_text(result.stdout,encoding='utf-8');(case/'stderr.log').write_text(result.stderr,encoding='utf-8')
        assert result.returncode==0,(device,result.stderr[-3000:])
        text=result.stdout+result.stderr
        assert 'Allocator after unload: buffers=0 images=0' in result.stdout
        assert not any(x in text.lower() for x in ('vuid-','sync-hazard','validation error'))
        timing=json.loads((case/'timing.json').read_text());report=timing['pipelineInspection']
        assert ('Intel' if device=='intel' else 'NVIDIA') in timing['gpu']
        assert report['requested']==enabled and report['failed']==0
        if report['enabled']:assert report['inspected']==21 and report['skipped']==0
        else:assert report['inspected']==0 and report['skipped']==21
        assert timing['sceneTriangles']>0 and timing['skinnedVertices']>0
        rows.append(dict(device=device,requested=enabled,report=report,passed=True,actualDevice=timing['gpu'],released=True,validationErrors=0))
        (out/'inspection-devices.json').write_text(json.dumps(dict(passed=len(rows)==4,checks=rows),indent=2)+'\n')
        print(device,'requested',enabled,'enabled',report['enabled'],'queries',report['inspected'],flush=True)
assert inputs(root)==frozen
