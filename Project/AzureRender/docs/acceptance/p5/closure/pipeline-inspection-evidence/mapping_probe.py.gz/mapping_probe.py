import ctypes,json,sys,threading,runpy
from pathlib import Path
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
nt=ctypes.WinDLL('ntdll');ptr=ctypes.POINTER(ctypes.c_void_p);sizeptr=ctypes.POINTER(ctypes.c_size_t)
nt.NtCreateSection.argtypes=[ptr,ctypes.c_ulong,ctypes.c_void_p,ctypes.POINTER(ctypes.c_longlong),ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p]
nt.NtMapViewOfSection.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ptr,ctypes.c_size_t,ctypes.c_size_t,ctypes.c_void_p,sizeptr,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong]
nt.NtMapViewOfSectionEx.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ptr,ctypes.c_void_p,sizeptr,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong]
nt.NtUnmapViewOfSection.argtypes=[ctypes.c_void_p,ctypes.c_void_p];nt.NtUnmapViewOfSectionEx.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ulong]
kernel=ctypes.WinDLL('kernel32');kernel.CloseHandle.argtypes=[ctypes.c_void_p]
section=ctypes.c_void_p();limit=ctypes.c_longlong(4*1024**2)
assert nt.NtCreateSection(ctypes.byref(section),0xf001f,None,ctypes.byref(limit),4,0x8000000,None)==0
rows=[];tid=threading.get_native_id()
try:
    for extended in (False,True):
        base=ctypes.c_void_p();size=ctypes.c_size_t(4*1024**2)
        if extended:status=nt.NtMapViewOfSectionEx(section,ctypes.c_void_p(-1),ctypes.byref(base),None,ctypes.byref(size),0,4,None,0)
        else:status=nt.NtMapViewOfSection(section,ctypes.c_void_p(-1),ctypes.byref(base),0,0,None,ctypes.byref(size),2,0,4)
        assert status==0
        rows.append(dict(api=5 if extended else 4,threadId=tid,base=base.value,size=size.value,status=status))
        ctypes.memset(base.value,0x5c,size.value)
        result=nt.NtUnmapViewOfSectionEx(ctypes.c_void_p(-1),base,0) if extended else nt.NtUnmapViewOfSection(ctypes.c_void_p(-1),base)
        assert result==0
        rows.append(dict(api=7 if extended else 6,threadId=tid,base=base.value,size=0,status=result))
finally:assert kernel.CloseHandle(section)
(out/'mappings.json').write_text(json.dumps(rows,indent=2)+'\n')
sys.argv=[sys.argv[0],str(out/'threads')]
runpy.run_path('docs/acceptance/p5/closure/native-trace-evidence/threaded_probe.py',run_name='__main__')
