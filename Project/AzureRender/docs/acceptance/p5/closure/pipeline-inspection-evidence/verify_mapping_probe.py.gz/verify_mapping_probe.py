import gzip,json,struct,hashlib
from pathlib import Path
root=Path.cwd();work=root/'build/p5-p6-inspection-2026-10-11'
trace=work/'mapping-known-trace';proofs=work/'mapping-known-proofs'
summary=json.loads((trace/'summary.json').read_text())
assert summary['childExitCode']==0 and all(summary[k]==0 for k in ('dropped','reentrant','invalidArguments','unpublished'))
capacity=struct.unpack_from('<8s7Q',(trace/'events.bin').read_bytes())[2]
assert capacity==8192
events=json.loads(gzip.decompress((trace/'events.json.gz').read_bytes()))
expected=json.loads((proofs/'mappings.json').read_text())
for thread in json.loads((proofs/'threads/threads.json').read_text()):
    for row in thread['proof']['events']:
        expected.append(dict(row,api=1 if row['action']=='allocate' else 3,threadId=thread['threadId']))
used=set();previous={};matches=[]
for row in expected:
    addressKey='inputBase' if row['api']==3 else 'base'
    sizeKey='inputSize' if row['api'] in (1,3) else 'size'
    candidates=[i for i,event in enumerate(events) if i not in used and i>previous.get(row['threadId'],-1)
                and event['api']==row['api'] and event['threadId']==row['threadId']
                and event[addressKey]==row['base'] and event['status']==row['status']
                and event[sizeKey]==row['size'] and ('flags' not in row or event['flags']==row['flags'])]
    assert candidates,row
    index=min(candidates);used.add(index);previous[row['threadId']]=index;matches.append(dict(expected=row,eventIndex=index))
assert len(matches)==44
result=dict(passed=True,capacity=capacity,bufferBytes=capacity*232,expectedCalls=44,matchedCalls=len(matches),
            orderedWithinThread=True,uniqueEvents=True,completeAllocationCoverage=False,matches=matches,
            eventSha256=hashlib.sha256((trace/'events.bin').read_bytes()).hexdigest())
(trace/'known-calls.json').write_text(json.dumps(result,indent=2)+'\n')
print('44 calls matched in thread order; bounded buffer:',result['bufferBytes'],'bytes')
