import ctypes
import json
import os
from pathlib import Path
import sys
import time

kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.VirtualAlloc.argtypes = [ctypes.c_void_p,ctypes.c_size_t,ctypes.c_ulong,ctypes.c_ulong]
kernel.VirtualAlloc.restype = ctypes.c_void_p
kernel.VirtualFree.argtypes = [ctypes.c_void_p,ctypes.c_size_t,ctypes.c_ulong]
kernel.VirtualFree.restype = ctypes.c_int
addresses = []
events = []
try:
    for _ in range(40):
        base = kernel.VirtualAlloc(None,65536,0x3000,4)
        if not base:
            raise ctypes.WinError(ctypes.get_last_error())
        addresses.append(base)
        ctypes.memset(base,123,65536)
        events.append(dict(action='allocate',base=base,size=65536,success=True))
    time.sleep(.1)
finally:
    for base in addresses:
        success = bool(kernel.VirtualFree(base,0,0x8000))
        events.append(dict(action='release',base=base,size=0,success=success))
Path(sys.argv[1]).write_text(json.dumps(dict(pid=os.getpid(),events=events),indent=2)+'\n',encoding='utf-8')
assert len(events) == 80 and all(event['success'] for event in events)
