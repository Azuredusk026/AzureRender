import csv
import argparse
import json
from collections import Counter
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--trace-dir',type=Path,default=Path(__file__).resolve().parent)
parser.add_argument('--pid',type=int,default=5144)
args = parser.parse_args()
OUT = args.trace_dir
PID = args.pid
TARGET = f'AzurePlayer.exe ({PID})'
rows = []
with (OUT/'wpa-lifetimes/VirtualAlloc_Commit_LifeTimes_RuleEngine.csv').open(encoding='utf-8-sig', newline='') as stream:
    reader = csv.DictReader(stream)
    columns = reader.fieldnames
    with (OUT/'player-commit-lifetimes.csv').open('w',encoding='utf-8',newline='') as filtered:
        writer = csv.DictWriter(filtered, fieldnames=columns)
        writer.writeheader()
        for row in reader:
            if row['Process'] == TARGET:
                writer.writerow(row)
                rows.append(row)
snapshots = []
with (OUT/'wpa-lifetimes/Virtual_Memory_Snapshots_RuleEngine.csv').open(encoding='utf-8-sig',newline='') as stream:
    for row in csv.DictReader(stream):
        if row['Process'] == TARGET:
            snapshots.append({key: (value if key in ('Process','Thread Name') else float(value.replace(',','')))
                for key,value in row.items()})
timeline = []
for seconds in (1,2,4,6,8,10,12,14,16,18,20,22,24,26,27,28):
    groups = Counter()
    live_count = 0
    for row in rows:
        start = float(row['Commit Time (s)'])
        try:
            end = float(row['Decommit Time (s)'])
        except ValueError:
            end = float('inf')
        if start <= seconds < end:
            live_count += 1
            stack = row['Commit Stack'].split('/')
            modules = [frame.split('!')[0] for frame in stack if '.dll!' in frame or '.exe!' in frame or '.sys!' in frame]
            site = [module for module in modules if module.lower() not in
                ('ntdll.dll','kernelbase.dll','kernel32.dll','ntoskrnl.exe','wow64.dll','wow64cpu.dll')]
            label = site[-1] if site else 'OtherOrUnresolved'
            groups[label] += float(row['Size (MB)'])
    timeline.append(dict(seconds=seconds,liveCommitRows=live_count,nearestNamedStackFrameMiB=dict(groups),
        totalLiveCommitMiB=sum(groups.values())))
summary = dict(diagnosticOnly=True,pid=PID,commitRows=len(rows),workingSetSnapshots=snapshots,
    commitTimeline=timeline,symbolsLoaded=False,exportPrecision='Rounded MiB, three decimals',
    residentSetExportIs='A snapshot after Player exit; does not describe its runtime pages',
    formalFailureReproduced=False,allocationOwnershipProven=False,
    classification='Nearest named stack frame after excluding NT API and kernel entry points; a library frame does not prove the logical owner',
    unattributedCommitIncludes= 'Kernel and system allocations, and module-ambiguous stacks')
(OUT/'player-lifetime-analysis.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(commitRows=len(rows),snapshots=len(snapshots),output=str(OUT/'player-lifetime-analysis.json'))))
