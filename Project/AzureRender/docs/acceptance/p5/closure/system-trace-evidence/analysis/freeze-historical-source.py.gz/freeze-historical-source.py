import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path.cwd()
WORK = ROOT/'build/p5-system-trace-2026-10-11'
FROZEN = ROOT/'build/p5-relative-thermal-2026-10-11/formal-performance/frozen-inputs.json'
expected = json.loads(FROZEN.read_text())
snapshot = WORK/'source-snapshot-n'
snapshot.mkdir(exist_ok=False)
restored = []
for name, digest in expected['source'].items():
    data = (ROOT/name).read_bytes()
    if hashlib.sha256(data).hexdigest() != digest:
        if name not in ('src/editor/content/ContentDirectoryModel.cpp','src/editor/content/ContentDirectoryModel.hpp'):
            raise ValueError('Historical source unavailable: '+name)
        data = subprocess.check_output(['git','show','3f063f7:Project/AzureRender/'+name])
        restored.append(name)
    if hashlib.sha256(data).hexdigest() != digest:
        raise ValueError('Historical bytes differ: '+name)
    destination = snapshot/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(data)
source_hash = hashlib.sha256(json.dumps(expected['source'],sort_keys=True).encode()).hexdigest()
assert source_hash == '32636fe8bc21a8208d6916c18ba71c6afe341b1a1eeb737b2d7109ba67e1c6a8'
for name, digest in expected['products'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
record = dict(sourceHash=source_hash,sourceSnapshot=str(snapshot),files=len(expected['source']),
    restoredFromCommit=restored,currentSourceMayDiffer=True,runtimeProductsUnchanged=True)
(WORK/'source-snapshot-association.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
