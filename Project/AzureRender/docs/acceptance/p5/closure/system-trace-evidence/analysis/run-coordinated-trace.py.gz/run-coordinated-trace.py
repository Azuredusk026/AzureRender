import argparse
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path.cwd()
WORK = ROOT/'build/p5-system-trace-2026-10-11'
SNAPSHOT = WORK/'source-snapshot-n'
sys.path.insert(0,str(SNAPSHOT/'tools'))
from run_playable_performance import memory_snapshot
from collect_memory_residency import ResidentObserver, summarize_residency
from performance_budget import working_set_growth

parser = argparse.ArgumentParser()
parser.add_argument('--workload',choices=('exploration','stress','editor'),default='exploration')
parser.add_argument('--round',type=int,default=1)
args = parser.parse_args()
frozen = json.loads((ROOT/'build/p5-relative-thermal-2026-10-11/formal-performance/frozen-inputs.json').read_text())
for name,digest in frozen['source'].items():
    assert hashlib.sha256((SNAPSHOT/name).read_bytes()).hexdigest() == digest, name
for name,digest in frozen['products'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
assert not ctypes.windll.shell32.IsUserAnAdmin(), 'The workload must run with the ordinary desktop token'
OUT = WORK/f'coordinated-{args.workload}-{args.round}-{time.time_ns()}'
OUT.mkdir()
method = WORK/'control-session.ps1'
start = subprocess.run(['powershell.exe','-NoProfile','-Command',
    'Start-Process -FilePath powershell.exe -Verb RunAs -WindowStyle Hidden -ArgumentList '+
    "@('-NoProfile','-ExecutionPolicy','Bypass','-File','"+str(method)+"','-OutputDirectory','"+str(OUT)+"')"],
    capture_output=True,text=True)
assert start.returncode == 0, start.stderr
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
deadline = time.monotonic()+60
while not (OUT/'ready.json').exists():
    if (OUT/'control-completion.json').exists():
        raise RuntimeError(read(OUT/'control-completion.json'))
    assert time.monotonic() < deadline, 'Trace control startup timeout'
    time.sleep(.1)
process = None
observer = None
samples = []
pages = []
try:
    subprocess.run([sys.executable,str(WORK/'known-allocation-probe.py'),str(OUT/'known-probe.json')],check=True)
    formal = ROOT/'build/p5-relative-thermal-2026-10-11/formal-performance'
    project = formal/args.workload/'project.azureproject'
    actions = formal/f'{args.workload}-{args.round}.input.json'
    summary = json.loads((formal/'summary.json').read_text())
    for name,digest in summary['sceneHashes'][args.workload].items():
        assert hashlib.sha256((project.parent/name).read_bytes()).hexdigest() == digest, name
    timing = OUT/'timing.json'
    command = [str(ROOT/'build/ninja-msvc-release/AzurePlayer.exe'),'--project',str(project),
        '--game-actions',str(actions),'--fixed-frame-step','--width','1920','--height','1080',
        '--smoke-frames','2100','--gpu-timing','--gpu-timing-output',str(timing)]
    if args.workload == 'editor':
        command[0] = str(ROOT/'build/ninja-msvc-release/AzureRender.exe')
        command[1] = '--editor-project'
        command.extend(['--editor-close-policy','save','--editor-actions',str(formal/f'editor-{args.round}.editor.json')])
    (OUT/'association.json').write_text(json.dumps(dict(sourceHash='32636fe8bc21a8208d6916c18ba71c6afe341b1a1eeb737b2d7109ba67e1c6a8',
        sourceSnapshot=str(SNAPSHOT),workloadElevated=False,diagnosticOnly=True,formalAcceptance=False,
        eventStacks=False,command=command,inputSha256=hashlib.sha256(actions.read_bytes()).hexdigest()),indent=2)+'\n')
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = 0
    environment = dict(os.environ)
    if args.workload == 'editor':
        environment['AZURERENDER_EDITOR_CONFIG'] = str(OUT/'editor-config')
    with (OUT/'stdout.log').open('w') as stdout,(OUT/'stderr.log').open('w') as stderr:
        process = subprocess.Popen(command,cwd=ROOT,stdout=stdout,stderr=stderr,startupinfo=startup,env=environment)
        observer = ResidentObserver(process.pid)
        started = time.monotonic()
        last_page = started
        while process.poll() is None:
            now = time.monotonic()
            try:
                sample = memory_snapshot(process.pid)
                sample['seconds'] = now-started
                samples.append(sample)
                if now-last_page >= 1:
                    page = observer.snapshot()
                    page['processSeconds'] = time.monotonic()-started
                    pages.append(page)
                    last_page = time.monotonic()
            except OSError:
                if process.poll() is not None:
                    break
                raise
            assert now-started < 120, 'Owned workload timeout'
            time.sleep(.03)
    process.wait()
    result = dict(pid=process.pid,exitCode=process.returncode,seconds=time.monotonic()-started,
        samples=len(samples),workingSetGrowth=working_set_growth([row['working'] for row in samples]),
        privateCommitGrowth=working_set_growth([row['privateBytes'] for row in samples]),
        ordinaryToken=True,diagnosticOnly=True,formalAcceptance=False)
    if len(pages) > 1:
        result['residentChange'] = summarize_residency(pages[len(pages)//2],pages[-1])
    (OUT/'process.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(path=str(OUT),**{key:value for key,value in result.items() if key != 'residentChange'})),flush=True)
    assert process.returncode == 0
finally:
    if process and process.poll() is None:
        process.kill()
        process.wait()
    if observer:
        observer.close()
    (OUT/'observations.json').write_text(json.dumps(samples,indent=2)+'\n')
    (OUT/'resident-snapshots.json').write_text(json.dumps(pages,indent=2)+'\n')
    (OUT/'workload-finished.json').write_text(json.dumps(dict(pid=process.pid if process else None,
        exitCode=process.returncode if process else None))+'\n')
    deadline = time.monotonic()+120
    while not (OUT/'control-completion.json').exists():
        assert time.monotonic() < deadline, 'Owned trace stop timeout'
        time.sleep(.2)
    assert read(OUT/'control-completion.json')['exitCode'] == 0
