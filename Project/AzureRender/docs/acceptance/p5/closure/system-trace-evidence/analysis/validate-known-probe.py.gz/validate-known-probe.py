import argparse
import csv
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('directory',type=Path)
args = parser.parse_args()
probe = json.loads((args.directory/'known-probe.json').read_text())
allocations = {row['base']:row['size'] for row in probe['events'] if row['action']=='allocate'}
allocated = set()
freed = set()
rows = []
with (args.directory/'memory-events.csv').open(encoding='utf-8-sig',newline='') as stream:
    for row in csv.reader(stream):
        if len(row)<6:
            continue
        event = row[0].strip()
        if event not in ('VirtualAlloc','VirtualFree') or row[2].strip() != f'python.exe ({probe["pid"]})':
            continue
        base = int(row[3].strip(),16)
        if base not in allocations:
            continue
        end = int(row[4].strip(),16)
        flags = row[5].strip().split()
        rows.append(dict(event=event,microseconds=int(row[1]),base=base,end=end,flags=flags))
        if event=='VirtualAlloc' and 'COMMIT' in flags and end-base == allocations[base]:
            allocated.add(base)
        if event=='VirtualFree' and 'RELEASE' in flags:
            freed.add(base)
missing_alloc = sorted(set(allocations)-allocated)
missing_release = sorted(set(allocations)-freed)
result = dict(knownAllocationCount=len(allocations),observedCommits=len(allocated),observedReleases=len(freed),
    knownAllocationBytes=sum(allocations.values()),knownUnpairedBytes=sum(allocations[base] for base in set(allocations)-freed),
    missingCommits=missing_alloc,missingReleases=missing_release,events=rows,
    passed=not missing_alloc and not missing_release,
    coverage='Forty successful VirtualAlloc reserve+commit and whole-region VirtualFree calls in one known process')
(args.directory/'known-probe-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key!='events'}))
assert result['passed'], 'Known allocation and release calls were not fully observed'
