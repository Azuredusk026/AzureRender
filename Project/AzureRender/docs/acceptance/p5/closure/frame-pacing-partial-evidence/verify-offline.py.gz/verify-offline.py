import hashlib
import json
from pathlib import Path
import sys

root = Path.cwd().resolve()
work = root / 'build/p8-automatic-2026-10-11'
sys.path.insert(0, str(root / 'tools'))
from build_provenance import verify
from build_game import verify_package, digest

proofs = {}
for config in ('debug', 'release'):
    proof = json.loads((root / f'build/ninja-msvc-{config}/build-provenance.json').read_text())
    verify(root, proof)
    proofs[config] = dict(sourceHash=hashlib.sha256(json.dumps(proof['source'], sort_keys=True).encode()).hexdigest(),
                          productCount=len(proof['products']), verified=True)
assert proofs['debug']['sourceHash'] == proofs['release']['sourceHash']

manual = json.loads((root / 'docs/plans/manual-review-manifest.json').read_text())
assets = json.loads((root / 'docs/plans/asset-format-manifest.json').read_text())
assert manual['executionPhase'] == 'P8' and manual['blocksFinalCompletion']
assert not manual['blocksIntermediateAutomaticProgress'] and not manual['complete']
assert all(row['status'] == 'DeferredToP8' for row in manual['items'])
assert assets['executionAuthorized'] and not assets['prerequisitesComplete'] and not assets['complete']
assert all(row['dependencyGate'] == 'AllAutomaticGates' and not row['automaticComplete'] for row in assets['phases'])
native = manual['items'][0]['desktopInputAutomation']
assert native['executionPhase'] == 'P8' and native['requiresExclusiveDesktopWindow']

packages = []
current = ['game-package/Windows Game', 'managed-workflows/coreclr/package',
           'managed-workflows/nativeaot/package', 'playable-package/Azure Exploration']
historical = ['Moved authored-exploration', 'Moved authored-inspection',
              'Moved exploration', 'Moved platformer', 'Moved scene_inspector']
paths = [(root / 'build/ninja-msvc-release' / p, 'CurrentRegressionArtifact') for p in current]
paths += [(root / 'build/p5-observation-control-2026-10-11/arena-delivery' / p,
           'HistoricalCandidateArtifact') for p in historical]
player_hash = digest(root / 'build/ninja-msvc-release/AzurePlayer.exe')
for package, scope in paths:
    manifest = verify_package(package)
    package_player_hash = digest(package / 'bin/AzurePlayer.exe')
    if scope == 'CurrentRegressionArtifact':
        assert package_player_hash == player_hash, str(package)
    record = dict(path=package.relative_to(root).as_posix(), scope=scope, integrityVerified=True,
                  manifestHash=digest(package / 'game_manifest.json'), files=len(manifest['files']),
                  playerHash=package_player_hash, currentPlayerByteEquivalent=package_player_hash == player_hash,
                  runtimeExecuted=False, gameplayVerified=False)
    packages.append(record)
    print(json.dumps(record), flush=True)

summary = dict(schemaVersion=1, sourceHash=proofs['release']['sourceHash'], buildProofs=proofs,
               manualItemsDeferredToP8=len(manual['items']), stageDependenciesVerified=True,
               formatsImplemented=False, packages=packages, passed=True,
               formalPerformancePassed=False, longRunsVerified=False, fullGpuRegressionPassed=False)
(work / 'offline-verification.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print('Offline source, phase dependencies and package integrity checks passed.', flush=True)
