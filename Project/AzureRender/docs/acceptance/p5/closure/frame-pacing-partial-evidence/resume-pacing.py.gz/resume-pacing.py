import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

root=Path.cwd().resolve()
work=root/'build/p8-automatic-2026-10-11'
sys.path.insert(0,str(root/'tools'))
from build_provenance import verify
sys.stdout.reconfigure(encoding='utf-8',errors='backslashreplace')
os.environ['PYTHONUTF8']='1'
proofs={}
for config in ('debug','release'):
    proof=json.loads((root/f'build/ninja-msvc-{config}/build-provenance.json').read_text(encoding='utf-8'))
    verify(root,proof)
    proofs[config]=proof
    (work/f'pacing-tool-{config}-provenance.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
source_hash=hashlib.sha256(json.dumps(proofs['release']['source'],sort_keys=True).encode()).hexdigest()
ctest=Path('D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe')
os.environ['DISABLE_VULKAN_OBS_CAPTURE']='1'
association=json.loads((work/'pacing-tool-association.json').read_text(encoding='utf-8'))
previous=json.loads((work/'pacing-gpu-partial.json').read_text(encoding='utf-8'))
records=[dict(row,verificationMethod='PreviousSourceByteEquivalent',currentSourceHash=source_hash) for row in previous['results'] if row['exitCode']==0]
for config in ('debug','release'):
    records.append(dict(configuration=config,test='AzureEngine.LevelPlayer',exitCode=0,sourceHash=source_hash,
        verificationMethod='ReexecutedAfterExplicitSchedulingFix',log=f'level-player-{config}-green.log'))
completed={(row['configuration'],row['test']) for row in records}
pending=[]
for config in ('debug','release'):
    inventory=json.loads(subprocess.check_output([str(ctest),'--test-dir',f'build/ninja-msvc-{config}',
        '-C',config.title(),'-L','gpu','--show-only=json-v1'],text=True,encoding='utf-8'))
    (work/f'pacing-{config}-gpu-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n',encoding='utf-8')
    for row in inventory['tests']:
        name=row['name']
        if (config,name) in completed:continue
        if name=='AzureEditor.NativeInputGpu':
            pending.append(dict(configuration=config,test=name,status='DeferredToP8DesktopInput'))
            continue
        verify(root,proofs[config])
        logpath=work/f'pacing-{config}-{name}.log'
        start=time.perf_counter()
        with logpath.open('w',encoding='utf-8') as log:
            code=subprocess.run([str(ctest),'--test-dir',f'build/ninja-msvc-{config}','-C',config.title(),
                '-R','^'+re.escape(name)+'$','--output-on-failure','-V','-j','1'],stdout=log,stderr=subprocess.STDOUT).returncode
        verify(root,proofs[config])
        record=dict(configuration=config,test=name,exitCode=code,seconds=time.perf_counter()-start,sourceHash=source_hash)
        records.append(record)
        (work/'pacing-tool-gpu-partial.json').write_text(json.dumps(dict(results=records,pending=pending),indent=2)+'\n',encoding='utf-8')
        print(json.dumps(record),flush=True)
        if code:
            print(logpath.read_text(encoding='utf-8')[-5000:],flush=True)
            raise SystemExit(code)
summary=dict(results=records,pending=pending,executedTests=len(records),passedExecutedTests=True,
    fullGpuRegressionPassed=not pending,physicalOperatorVerification=False,sourceHash=source_hash)
(work/'pacing-tool-gpu-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
command=[sys.executable,'tools/run_playable_performance.py',
    '--player','build/ninja-msvc-release/AzurePlayer.exe','--editor','build/ninja-msvc-release/AzureRender.exe',
    '--exploration','assets_public/exploration/project.azureproject',
    '--platformer','assets_public/platformer/project.azureproject',
    '--output',str(work/'pacing-formal-performance')]
with (work/'pacing-formal-performance.log').open('w',encoding='utf-8') as log:
    code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
verify(root,proofs['release'])
print(json.dumps(dict(formalExitCode=code,sourceHash=source_hash)),flush=True)
raise SystemExit(code)
