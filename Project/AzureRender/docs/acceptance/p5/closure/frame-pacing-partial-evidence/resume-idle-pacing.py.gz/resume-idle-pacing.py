import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--check-only', action='store_true')
args = parser.parse_args()
root = Path.cwd().resolve()
work = root / 'build/p8-automatic-2026-10-11'
sys.path.insert(0, str(root / 'tools'))
from build_provenance import verify
from gpu_environment import wait_and_record
expected = '2f5618d62593c83a59a4000654b3e14a2ee9e80dc8a6a77a4ace41ab3a37b901'
proofs = {}
for config in ('debug', 'release'):
    proof = json.loads((root / f'build/ninja-msvc-{config}/build-provenance.json').read_text())
    verify(root, proof)
    assert hashlib.sha256(json.dumps(proof['source'], sort_keys=True).encode()).hexdigest() == expected
    proofs[config] = proof

checkpoint = work / 'pacing-idle-gpu-partial.json'
previous = checkpoint if checkpoint.exists() else work / 'pacing-tool-gpu-partial.json'
records = json.loads(previous.read_text())['results']
completed = {(row['configuration'], row['test']) for row in records if row['exitCode'] == 0}
pending = []
for config in ('debug', 'release'):
    inventory = json.loads((work / f'pacing-{config}-gpu-inventory.json').read_text())
    for row in inventory['tests']:
        if row['name'] != 'AzureEditor.NativeInputGpu' and (config, row['name']) not in completed:
            pending.append((config, row['name']))
pending.sort(key=lambda item: item[1] != 'AzureEngine.PlayablePackage')
print(json.dumps(dict(sourceHash=expected, alreadyVerifiedUniqueTests=len(completed),
                      pendingNonDesktopGpuTests=len(pending), changesSystemPointer=False)), flush=True)
if args.check_only:
    raise SystemExit(0)

os.environ['DISABLE_VULKAN_OBS_CAPTURE'] = '1'
os.environ['PYTHONUTF8'] = '1'
ctest = Path('D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe')
for config, name in pending:
    verify(root, proofs[config])
    attempt = str(time.time_ns())
    wait_and_record(work / f'pacing-idle-environment-{attempt}.json')
    logpath = work / f'pacing-idle-{attempt}-{config}-{name}.log'
    assert not logpath.exists()
    start = time.perf_counter()
    with logpath.open('w', encoding='utf-8') as log:
        code = subprocess.run([str(ctest), '--test-dir', f'build/ninja-msvc-{config}',
                               '-C', config.title(), '-R', '^' + re.escape(name) + '$',
                               '--output-on-failure', '-V', '-j', '1'],
                              stdout=log, stderr=subprocess.STDOUT).returncode
    verify(root, proofs[config])
    record = dict(configuration=config, test=name, exitCode=code,
                  seconds=time.perf_counter() - start, sourceHash=expected,
                  log=logpath.name, verificationMethod='ReexecutedInIdleGpuEnvironment')
    records.append(record)
    checkpoint.write_text(json.dumps(dict(results=records), indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record), flush=True)
    if code:
        print(logpath.read_text(encoding='utf-8', errors='replace')[-5000:], flush=True)
        raise SystemExit(code)
    completed.add((config, name))

assert len(completed) == 128
passed = list({(row['configuration'], row['test']): row for row in records if row['exitCode'] == 0}.values())
summary = dict(results=passed, retainedAttempts=records, executedTests=len(completed),
               passedExecutedTests=True, nonDesktopGpuRegressionPassed=True,
               pending=[dict(configuration=c, test='AzureEditor.NativeInputGpu',
                             status='DeferredToP8DesktopInput') for c in ('debug', 'release')],
               fullGpuRegressionPassed=False, physicalOperatorVerification=False, sourceHash=expected)
(work / 'pacing-tool-gpu-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
formal = work / 'pacing-formal-performance'
assert not formal.exists(), 'Keep formal batches immutable; use a new directory for a new batch'
command = [sys.executable, '-X', 'utf8', 'tools/run_playable_performance.py',
           '--player', 'build/ninja-msvc-release/AzurePlayer.exe',
           '--editor', 'build/ninja-msvc-release/AzureRender.exe',
           '--exploration', 'assets_public/exploration/project.azureproject',
           '--platformer', 'assets_public/platformer/project.azureproject', '--output', str(formal)]
with (work / 'pacing-formal-performance.log').open('w', encoding='utf-8') as log:
    code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
verify(root, proofs['release'])
print(json.dumps(dict(formalExitCode=code, sourceHash=expected)), flush=True)
raise SystemExit(code)
