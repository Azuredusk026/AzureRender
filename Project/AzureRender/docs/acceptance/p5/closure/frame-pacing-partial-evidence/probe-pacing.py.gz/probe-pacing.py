import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
sys.path.insert(0,str(Path.cwd()/'tools'))
from build_provenance import verify
import run_playable_performance as measurement

root=Path.cwd().resolve();work=root/'build/p8-automatic-2026-10-11'
out=work/'pacing-control';out.mkdir(exist_ok=False)
proof=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text(encoding='utf-8'))
sourceHash=hashlib.sha256(json.dumps(proof['source'],sort_keys=True).encode()).hexdigest()
os.environ['DISABLE_VULKAN_OBS_CAPTURE']='1'
original=subprocess.Popen
rate=0
def launch(command,*args,**kwargs):
    if isinstance(command,list) and Path(str(command[0])).name=='AzurePlayer.exe':
        command=[*command,'--set',f'runtime.maxFrameRate={rate}']
    return original(command,*args,**kwargs)
subprocess.Popen=launch
results=[]
for name in ('standard','exploration'):
    for index,rate in enumerate((0,60,0,60),1):
        verify(root,proof)
        project=root/'build/p5-observation-control-2026-10-11/formal-performance'/name/'project.azureproject'
        result=measurement.run(root/'build/ninja-msvc-release/AzurePlayer.exe',project,out/f'{name}-{index}')
        verify(root,proof)
        assert result['framePacing']['maximumRate']==rate
        result.update(diagnosticOnly=True,formalAcceptance=False,sourceHash=sourceHash,
            settingOverrides={'runtime.maxFrameRate':rate},sourceStable=True)
        (out/f'{name}-{index}.result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
        samples=result['environment']['runObservations']
        row=dict(workload=name,rate=rate,sourceHash=sourceHash,sourceStable=True,
            growth=result['stableWorkingSetGrowth'],passed=result['passed'],failures=result['budgetFailures'],
            peakTemperature=max(r['temperature'] for r in samples),
            peakPower=max((r['powerDrawWatts'] for r in samples if r['powerDrawWatts'] is not None),default=None),
            peakUtilization=max(r['gpuUtilization'] for r in samples),duration=result['environment']['runSeconds'],
            thermalSlowdownObserved=any(any(r['thermalSlowdown'].values()) for r in samples),
            pacing=result['framePacing'])
        results.append(row)
        (out/'summary.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(row),flush=True)
