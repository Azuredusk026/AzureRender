import hashlib
import json
from pathlib import Path
work=Path('build/p8-automatic-2026-10-11')
rows={}
for config in ('debug','release'):
    old=json.loads((work/f'pacing-{config}-provenance.json').read_text(encoding='utf-8'))
    new=json.loads(Path(f'build/ninja-msvc-{config}/build-provenance.json').read_text(encoding='utf-8'))
    changed=[name for name in set(old['source'])|set(new['source'])
             if old['source'].get(name)!=new['source'].get(name)]
    assert changed==['tools/test_level_player.py'],changed
    assert old['products']==new['products'],config
    rows[config]=dict(changedSource=changed,productsByteEquivalent=True,
        previousSourceHash=hashlib.sha256(json.dumps(old['source'],sort_keys=True).encode()).hexdigest(),
        currentSourceHash=hashlib.sha256(json.dumps(new['source'],sort_keys=True).encode()).hexdigest())
    (work/f'pacing-tool-{config}-provenance.json').write_text(json.dumps(new,indent=2)+'\n',encoding='utf-8')
(work/'pacing-tool-association.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows))
