import json
from pathlib import Path
import subprocess
import sys
import time
sys.path.insert(0,str(Path.cwd()/'tools'))
from run_playable_long_run import isolated_environment
from test_level_cycles import verify

root=Path.cwd().resolve()
work=root/'build/p8-automatic-2026-10-11'
package=root/'build/ninja-msvc-release/playable-package/Azure Exploration'
out=work/'package-mailbox-control'
out.mkdir(exist_ok=False)
timing=out/'timing.json'
command=[str(package/'bin/AzurePlayer.exe'),'--project',str(package/'game/project.azureproject'),
    '--width','1920','--height','1080','--game-actions',
    str(root/'build/ninja-msvc-release/playable-package/evidence/cycles.input.json'),
    '--fixed-frame-step','--smoke-frames','6600','--gpu-timing','--gpu-timing-output',str(timing),
    '--runtime-report',str(out/'runtime.json'),'--set','runtime.vsync=false']
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
start=time.perf_counter()
with (out/'stdout.log').open('w',encoding='utf-8') as stdout,(out/'stderr.log').open('w',encoding='utf-8') as stderr:
    process=subprocess.Popen(command,cwd=package,env=isolated_environment(),stdout=stdout,stderr=stderr,startupinfo=startup)
    try:code=process.wait(timeout=300)
    finally:
        if process.poll() is None:process.kill();process.wait()
elapsed=time.perf_counter()-start
assert code==0,code
data=json.loads(timing.read_text(encoding='utf-8'))
assert data['framePacing']['presentMode']=='MAILBOX'
summary=dict(seconds=elapsed,framePacing=data['framePacing'],gpu=data['totalP95Ms'],
    cpuWork=data['cpuFrame']['workSamplesMs'][:10],cpuWait=data['cpuFrame']['waitSamplesMs'][:10],
    cycles=verify(timing),runtime=json.loads((out/'runtime.json').read_text(encoding='utf-8')))
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='runtime'}),flush=True)
