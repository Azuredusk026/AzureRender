"""Preserve final documentation checks and the actual WPR denial separately."""
import gzip
import hashlib
import json
from pathlib import Path

root = Path.cwd().resolve()
candidate = root / 'build/p5-relative-thermal-2026-10-11'
target = root / 'docs/acceptance/p5/closure/device-environment-final-checks'
assert not target.exists()
source = '32636fe8bc21a8208d6916c18ba71c6afe341b1a1eeb737b2d7109ba67e1c6a8'
main = json.loads((candidate / 'verification-working.json').read_text())
assert main['passed'] and main['sourceHash'] == source
audit = json.loads((root / 'build/p5-relative-thermal-final-repository-audit.json').read_text())
assert audit['status'] == 'passed'
traces = list(candidate.glob('system-trace-*'))
assert len(traces) == 1
failure = json.loads((traces[0] / 'failure.json').read_text(encoding='utf-8-sig'))
assert failure['message'] == 'WPR start failed: -2147024891' and not failure['traceStarted']
docs = root / 'build/p5-relative-thermal-docs-build.log'
# PowerShell redirection can produce UTF-16 on Windows PowerShell.
raw = docs.read_bytes()
text = raw.decode('utf-16') if raw[:2] in (b'\xff\xfe', b'\xfe\xff') else raw.decode('utf-8')
assert 'Documentation built in' in text
selected = [docs, root / 'build/p5-relative-thermal-final-repository-audit.json',
            root / 'build/p5-relative-thermal-system-trace-attempt.log',
            Path(__file__).resolve()]
selected.extend(p for p in traces[0].iterdir() if p.is_file())
files = {}
for path in selected:
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    name = path.relative_to(root).as_posix() + '.gz'
    output = target / name
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(stored)
    files[name] = dict(source=path.relative_to(root).as_posix(),
                       originalBytes=len(raw), storedBytes=len(stored),
                       originalSha256=hashlib.sha256(raw).hexdigest(),
                       sha256=hashlib.sha256(stored).hexdigest())
manifest = dict(schemaVersion=1, sourceHash=source, strictDocsBuildPassed=True,
                repositoryAuditPassed=True, systemTraceStatus='AccessDenied',
                systemTraceStarted=False, systemTraceError='0x80070005', files=files)
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
for name, item in files.items():
    stored = (target / name).read_bytes()
    assert hashlib.sha256(stored).hexdigest() == item['sha256']
    assert gzip.decompress(stored) == (root / item['source']).read_bytes()
print(json.dumps({key: value for key, value in manifest.items() if key != 'files'}))
