"""Measure the frozen environment candidate; preserve every original failure."""
import datetime
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root=Path.cwd().resolve()
work=root/'build/p5-device-environment-2026-10-11'
os.environ['PATH']='D:/Visual Studio/2022/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin'+os.pathsep+os.environ['PATH']
sys.path.insert(0,str(root/'tools'))
from build_provenance import inputs,verify
from run_playable_performance import freeze_products
from build_game import build_game,verify_package
from test_level_cycles import prepare
frozen=inputs(root)
source_hash=hashlib.sha256(json.dumps(frozen,sort_keys=True).encode()).hexdigest()
proof=json.loads((root/'build/ninja-msvc-release/build-provenance.json').read_text(encoding='utf-8'))
verify(root,proof)
original=json.loads((root/'build/p5-cache-publication-2026-10-11/formal-performance/frozen-inputs.json').read_text(encoding='utf-8'))
dependencies=freeze_products(root,root/'build/ninja-msvc-release/AzurePlayer.exe',root/'build/ninja-msvc-release/AzureRender.exe')
assert dependencies==original['products'],'The prior GPU regression cannot be associated with changed runtime dependencies'
equivalence=dict(sourceHash=source_hash,originalSourceHash='b2af43f8a206f6edc16e30c259e41f6230fa64adf6b261e8fd7cbf4dec9b64c2',
    dependencies=dependencies,byteEquivalent=True,priorGpuTests=130)
(work/'dependency-equivalence.json').write_text(json.dumps(equivalence,indent=2)+'\n',encoding='utf-8')
records=[]
def write_state():
    path=work/'acceptance-status.json';pending=path.with_suffix('.pending')
    pending.write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8');pending.replace(path)
def run(name,arguments,required=True):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    print('Starting',name,started,flush=True)
    with (work/(name+'.log')).open('w',encoding='utf-8') as stream:
        child=subprocess.Popen(list(map(str,arguments)),cwd=root,stdout=stream,stderr=subprocess.STDOUT)
        (work/'owned-child.json').write_text(json.dumps(dict(name=name,pid=child.pid,startedUtc=started))+'\n',encoding='utf-8')
        code=child.wait()
    assert inputs(root)==frozen
    records.append(dict(name=name,exitCode=code,required=required,sourceHash=source_hash,
        startedUtc=started,endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    write_state();print(name,'exit',code,flush=True)
    if required:assert code==0,(name,code)
    return code
try:
    run('regression',[sys.executable,work/'regression.py'])
    run('inventory',[sys.executable,work/'inventory_regression.py'])
    run('delivery',[sys.executable,work/'verified_delivery.py'])
    run('formal-performance',[sys.executable,root/'tools/run_playable_performance.py',
        '--player',root/'build/ninja-msvc-release/AzurePlayer.exe','--editor',root/'build/ninja-msvc-release/AzureRender.exe',
        '--exploration',root/'assets_public/exploration/project.azureproject',
        '--platformer',root/'assets_public/platformer/project.azureproject','--output',work/'formal-performance'],required=False)
    run('operator-packet',[sys.executable,work/'create_operator_packet.py'])
    delivery=work/'arena-delivery'
    source=work/'standard-source';standard=work/'Moved environment standard'
    prepare(source);build_game(source/'project.azureproject',delivery/'Moved Engine',standard)
    source.rename(work/'Unavailable environment standard source');verify_package(standard)
    run('platformer-longrun',[sys.executable,root/'tools/run_platformer_long_run.py',
        '--package',delivery/'Moved exploration','--output',work/'platformer-longrun','--seconds','1800'],required=False)
    run('standard-longrun',[sys.executable,root/'tools/run_playable_long_run.py',
        '--package',standard,'--output',work/'standard-longrun','--seconds','1800'],required=False)
except BaseException as error:
    (work/'runner-failure.json').write_text(json.dumps(dict(type=type(error).__name__,message=str(error),
        sourceHash=source_hash,records=records),indent=2)+'\n',encoding='utf-8')
    raise
print('All scheduled measurements ended; original results are ready for review.',flush=True)
raise SystemExit(int(any(row['exitCode'] for row in records)))
