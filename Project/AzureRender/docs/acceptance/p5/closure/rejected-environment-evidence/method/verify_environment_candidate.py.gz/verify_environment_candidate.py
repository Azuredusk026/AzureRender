"""Verify original measurements, associated regressions and unfinished gates."""
import gzip
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path.cwd().resolve()
work = root/'build/p5-device-environment-2026-10-11'
sys.path.insert(0, str(root/'tools'))
from build_provenance import inputs, verify
from gpu_environment import environment_errors
from performance_budget import validate_round
from run_playable_long_run import evaluate

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

source = hashlib.sha256(json.dumps(inputs(root), sort_keys=True).encode()).hexdigest()
assert source == '3cdb6f659eda85ee63b4cd6bd0bde6ce94a8df2c2aa1324acbe599bb3d9eee7b'
target = root/'docs/acceptance/p5/closure/device-environment-evidence'
manifest = read(target/'manifest.json')
assert manifest['sourceHash'] == source
for name, item in manifest['files'].items():
    stored = (target/name).read_bytes()
    raw = gzip.decompress(stored)
    assert len(raw) == item['originalBytes'] and len(stored) == item['storedBytes'], name
    assert hashlib.sha256(stored).hexdigest() == item['sha256'], name
    assert hashlib.sha256(raw).hexdigest() == item['originalSha256'], name
    assert raw == (root/item['source']).read_bytes(), item['source']
for config in ('release', 'debug'):
    proof = read(work/(config+'-provenance.json'))
    verify(root, proof)
    assert proof['source'] == inputs(root)
inventory = read(work/'regression-inventory.json')
assert inventory['complete'] and inventory['total'] == manifest['associatedTotal'] == 456
assert inventory['currentCpuTests'] == manifest['currentCpuTests'] == 326
assert inventory['priorGpuTests'] == manifest['priorGpuTests'] == 130
assert inventory['association'] == 'CurrentCpuWithByteEquivalentGpuBaseline'
baseline = 'b2af43f8a206f6edc16e30c259e41f6230fa64adf6b261e8fd7cbf4dec9b64c2'
assert inventory['priorGpuSourceHash'] == manifest['priorGpuSourceHash'] == baseline
runtime = read(work/'runtime-equivalence.json')
assert {row['configuration'] for row in runtime} == {'release', 'debug'}
assert all(row['productCount'] == 54 and row['productsByteEquivalent'] and row['sourceHash'] == source for row in runtime)
dependencies = read(work/'dependency-equivalence.json')
assert dependencies['sourceHash'] == source and dependencies['originalSourceHash'] == baseline
assert dependencies['byteEquivalent'] and len(dependencies['dependencies']) == 114

delivery = read(work/'arena-delivery/summary.json')
assert delivery['passed'] and len(delivery['checks']) == manifest['deliveryChecks'] == 10
assert len(delivery['packages']) == 6
for row in delivery['packages']:
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256'], row['kind']
formal = read(work/'formal-performance/summary.json')
assert formal['sourceHash'] == source
rounds = [row for group in formal['rounds'].values() for row in group]
assert len(rounds) == manifest['formalRounds'] == 15
assert sum(row['passed'] for row in rounds) == manifest['formalPassedRounds']
assert formal['passed'] == manifest['formalPerformancePassed'] == all(row['passed'] for row in rounds)
for name, rows in formal['rounds'].items():
    assert len(rows) == 3
    for row in rows:
        if 'environment' in row:
            assert row['passed'] == (not validate_round(row, editor=name == 'editor')), (name, row.get('errors'))
        else:
            assert not row['passed'] and row.get('error'), (name, row)
for name, record in manifest['longRuns'].items():
    measured = read(work/(name+'-longrun')/'summary.json')
    assert measured['sourceHash'] == source and measured['actualSeconds'] >= 1800
    assert measured['realTime'] and measured['released'] and measured['exitCode'] == 0
    if measured['status'] == 'passed':
        evaluate(measured)
    else:
        assert measured['status'] == 'failed', measured
        try:
            evaluate(measured)
        except AssertionError:
            pass
        else:
            raise AssertionError('Failed long run has no reproducible gate failure: '+name)
    assert record == {key: measured[key] for key in record}

operator = read(work/'operator-review/feedback-template.json')
assert operator['status'] == 'NotExecuted'
assert not operator['physicalInput'] and not operator['subjectiveAudio'] and not operator['authoringEfficiency']
assert operator['packageHashes'] == {row['kind']: row['sha256'] for row in delivery['packages']}
for key in ('physicalInputVerified', 'subjectiveAudioVerified', 'authoringEfficiencyVerified', 'priorWorkingSetCauseResolved'):
    assert manifest[key] is False, key
pending = read(root/'docs/plans/authoring-usability-manifest.json')
assert not pending['u15Complete'] and not pending['u16Complete'] and not pending['p6Complete']
assert pending['deviceEnvironmentCandidate']['sourceHash'] == source
assert pending['deviceEnvironmentCandidate']['packageHashes'] == operator['packageHashes']
formats = read(root/'docs/plans/asset-format-manifest.json')
assert not formats['prerequisitesComplete'] and all(row['status'] == 'Planned' for row in formats['phases'])
mode = sys.argv[1] if len(sys.argv) > 1 else None
if mode:
    assert mode in ('HEAD', 'index')
    for name, item in manifest['files'].items():
        path = 'Project/AzureRender/docs/acceptance/p5/closure/device-environment-evidence/'+name
        reference = 'HEAD:'+path if mode == 'HEAD' else ':'+path
        stored = subprocess.run(['git', 'show', reference], capture_output=True, check=True).stdout
        assert hashlib.sha256(stored).hexdigest() == item['sha256'], name
result = dict(passed=True, sourceHash=source, files=len(manifest['files']), gitMode=mode,
              currentCpuTests=326, associatedGpuTests=130, formalPassedRounds=manifest['formalPassedRounds'],
              longRuns=manifest['longRuns'], currentStagesComplete=False, assetStagesStarted=False)
(work/('verification-'+(mode or 'working')+'.json')).write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result))
