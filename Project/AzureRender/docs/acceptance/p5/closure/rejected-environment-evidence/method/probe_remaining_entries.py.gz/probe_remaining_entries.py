"""Run the remaining measurement entry points after the main GPU batch ends."""
import datetime
import json
import subprocess
import sys
from pathlib import Path

root = Path.cwd().resolve()
work = root/'build/p5-device-environment-2026-10-11'
status = json.loads((work/'acceptance-status.json').read_text(encoding='utf-8'))
assert {row['name'] for row in status} >= {'formal-performance', 'platformer-longrun', 'standard-longrun'}
records = []
for name, arguments in [
    ('preview-probe', ['tools/run_preview_comparison.py', '--executable', 'build/ninja-msvc-release/AzureRender.exe',
                       '--output', str(work/'preview-probe'), '--rounds', '1', '--warmup', '300', '--samples', '1800']),
    ('cinematic-probe', ['tools/measure_runtime_performance.py', '--executable', 'build/ninja-msvc-release/AzureRender.exe',
                         '--output-dir', str(work/'cinematic-probe')])]:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print('Starting', name, started, flush=True)
    with (work/(name+'.log')).open('w', encoding='utf-8') as stream:
        child = subprocess.Popen([sys.executable, *arguments], cwd=root, stdout=stream, stderr=subprocess.STDOUT)
        code = child.wait()
    records.append(dict(name=name, exitCode=code, startedUtc=started,
                        endedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    (work/'additional-entry-status.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
    print(name, 'exit', code, flush=True)
raise SystemExit(int(any(row['exitCode'] for row in records)))
