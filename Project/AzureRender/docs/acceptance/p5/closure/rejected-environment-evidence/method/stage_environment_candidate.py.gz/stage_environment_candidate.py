"""Stage the device rule and only this candidate's shared-document increments."""
import subprocess
from pathlib import Path

root = Path.cwd().resolve()
prefix = 'Project/AzureRender/'

def git(*args, data=None):
    return subprocess.run(['git', *args], input=data, capture_output=True, check=True).stdout

assert not git('diff', '--cached', '--name-only').strip()

def stage(name, replacements):
    original = git('show', 'HEAD:'+prefix+name).decode('utf-8')
    newline = '\r\n' if '\r\n' in original else '\n'
    text = original.replace('\r\n', '\n')
    for old, new in replacements:
        assert text.count(old) == 1, (name, old)
        text = text.replace(old, new, 1)
    blob = git('hash-object', '-w', '--stdin', data=text.replace('\n', newline).encode()).decode().strip()
    git('update-index', '--cacheinfo', '100644,'+blob+','+prefix+name)

anchor = '    add_test(NAME AzureTools.PerformanceBudget COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_performance_budget.py")\n'
stage('CMakeLists.txt', [(anchor, anchor+'    add_test(NAME AzureTools.GpuEnvironment COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/tools/test_gpu_environment.py")\n')])
readme = (root/'README.md').read_text(encoding='utf-8')
start = readme.index('性能测量依据驱动热限制与稳定空闲窗口启动。')
end = readme.index('资产格式后续阶段见', start)
stage('README.md', [
    ('完整回归与当前来源实测见[缓存并发验收]', '缓存候选的回归与实测见[缓存并发验收]'),
    ('\n资产格式后续阶段见', '\n'+readme[start:end]+'资产格式后续阶段见')])
change = (root/'CHANGELOG.md').read_text(encoding='utf-8')
start = change.index('## P5-A 实际设备环境规则 2026-10-11')
end = change.index('## U16 缓存并发发布修复 2026-10-11', start)
stage('CHANGELOG.md', [('# Changelog\n\n', '# Changelog\n\n'+change[start:end])])
stage('mkdocs.yml', [('nav:\n', 'nav:\n  - 设备环境测量验收: acceptance/p5/closure/device-environment.md\n  - 设备环境测量计划: plans/2026-10-11-performance-environment.md\n')])
for name, heading in [('docs/plans/azure-engine-plan.md', '\n## 设备环境候选验收\n'),
                      ('docs/acceptance/p5/closure/p5-a.md', '\n## 实际设备环境规则\n')]:
    working = (root/name).read_text(encoding='utf-8')
    increment = working[working.index(heading):]
    base = git('show', 'HEAD:'+prefix+name).decode('utf-8').replace('\r\n', '\n')
    stage(name, [(base, base+increment)])

paths = ['tools/gpu_environment.py', 'tools/test_gpu_environment.py', 'tools/performance_budget.py',
         'tools/test_performance_budget.py', 'tools/test_playable_delivery_rules.py',
         'tools/run_playable_performance.py', 'tools/run_playable_long_run.py',
         'tools/run_platformer_long_run.py', 'tools/run_preview_comparison.py',
         'tools/measure_runtime_performance.py', 'docs/runtime/playable-performance.md',
         'docs/plans/2026-10-11-performance-environment.md',
         'docs/plans/third-person-playable-plan.md', 'docs/plans/g0-implementation.md',
         'docs/acceptance/p5/2026-10-10.md', 'docs/acceptance/p5/closure/device-environment.md',
         'docs/plans/authoring-usability-manifest.json']
name = 'docs/plans/2026-10-10-p5-closure-and-user-experience.md'
base = git('show', 'HEAD:'+prefix+name).decode('utf-8').replace('\r\n', '\n')
stage(name, [('| 独显初温 | 每轮至多 55°C |', '| 设备环境 | 驱动热限制、降频状态与稳定空闲窗口 |')])
git('add', '--', *paths)
git('add', '--force', '--', 'docs/acceptance/p5/closure/device-environment-evidence')
git('diff', '--cached', '--check')
print('Device environment code and isolated documentation increments staged.')
