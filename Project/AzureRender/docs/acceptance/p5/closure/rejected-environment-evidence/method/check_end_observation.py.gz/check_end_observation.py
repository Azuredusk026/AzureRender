"""An end-only thermal event must not mutate or hide healthy startup evidence."""
import copy
import json
import sys
from pathlib import Path

root=Path.cwd().resolve();sys.path.insert(0,str(root/'tools'))
from test_performance_budget import passing_round
from gpu_environment import environment_errors
from performance_budget import validate_round
rows=[]
for reason in ('hardware','software'):
    data=passing_round()
    environment=data['environment']
    environment['final']=copy.deepcopy(environment['final'])
    assert not environment_errors(environment)
    environment['final']['thermalSlowdown'][reason]=True
    assert not data['initialDevice']['thermalSlowdown'][reason]
    assert all(not row['thermalSlowdown'][reason] for row in environment['startup'])
    assert any(reason+' thermal slowdown is active' in message for message in environment_errors(environment))
    assert any(reason+' thermal slowdown is active' in message for message in validate_round(data,editor=False))
    rows.append(dict(reason=reason,startupHealthy=True,endFailureDetected=True))
(root/'build/p5-device-environment-2026-10-11/end-observation-check.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows))
