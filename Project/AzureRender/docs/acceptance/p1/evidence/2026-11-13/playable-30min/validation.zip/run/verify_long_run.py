from hashlib import sha256
import json
from pathlib import Path
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
from build_provenance import digest
from gpu_environment import environment_errors
from run_playable_long_run import evaluate, periodic_statistics

out = Path(__file__).resolve().parent / 'measurement'

def load(name):
    return json.loads((out / name).read_bytes())

summary = load('summary.json')
receipt = load('measurement-receipt.json')
assert summary['status'] == 'passed'
evaluate(summary)
for name, expected in receipt['rawEvidenceHashes'].items():
    assert digest(out / name) == expected, name
assert summary['runtimeHash'] == receipt['runtimeHash']
assert summary['packageManifestHash'] == receipt['packageManifestHash']
assert not environment_errors(load('environment.json'))
assert len(summary['gpuWindows']) >= 30
assert summary['commits'] == summary['switches'] + summary['restarts']
raw = load('timing.json')
assert (raw['sceneWidth'], raw['sceneHeight']) == (1920, 1080)
assert raw['samples'] == summary['frames']
assert raw['allocator']['deviceLocalPeakBytes'] == summary['deviceLocalPeakBytes']
residency = periodic_statistics(raw['resourceFrames'], summary['warmupFrame'])
assert all(summary[key] == value for key, value in residency.items())
print(json.dumps({key: summary[key] for key in (
    'status', 'actualSeconds', 'frames', 'switches', 'restarts', 'commits', 'gpu', 'cpu',
    'periodicCpu', 'periodicPhysics', 'commitExtra', 'commitFrame', 'deviceLocalPeakBytes',
    'peakWorkingSetBytes', 'workingSetGrowth', 'residencyGrowth', 'windowChecks', 'released')}, indent=2))
