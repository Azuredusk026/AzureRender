from hashlib import sha256
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path.cwd() / 'tools'))
from build_game import digest
from run_playable_long_run import run

package, output = map(Path, sys.argv[1:])
expected_runtime = 'ba6f9f1a9790be0b5027cba0d7c9a396d5d3ea70fed80bf266584af7effa472b'
expected_package = '4cad10a8cde0b6f27c861cae538ca3e077dd632ad0aea4dc5e2a57dd9bfa0a4a'
assert digest(package / 'bin/AzurePlayer.exe') == expected_runtime
assert digest(package / 'game_manifest.json') == expected_package
summary = run(package, output)
assert summary['runtimeHash'] == expected_runtime and summary['packageManifestHash'] == expected_package
assert summary['status'] == 'passed'
result = dict(sourceCommit='85dc35f2a89942e55c59c468155ffc5aede13844', packageManifestHash=expected_package,
              runtimeHash=expected_runtime, rawEvidenceHashes={name: digest(output / name) for name in
              ('summary.json', 'timing.json', 'timing.csv', 'runtime.json', 'observation.json', 'environment.json',
               'input.json', 'stdout.log', 'stderr.log')})
(output / 'measurement-receipt.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
