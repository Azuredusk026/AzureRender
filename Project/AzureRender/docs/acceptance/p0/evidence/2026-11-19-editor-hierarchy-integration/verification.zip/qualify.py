"""Run the affected editor checks on the unchanged, previously built candidate."""
from hashlib import file_digest, sha256, sha1
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

from prepare import run, repo, engine, git, snapshot, digest

source = run / "source/Project/AzureRender"
build = Path("D:/Projects/FYP-worktrees/editor-interaction/Project/AzureRender/build/ninja-msvc-release")
binary = build / "AzureRender.exe"
expected = "75778c34da23ceb5387e6baf195cbdcc63a9fac8ae05c304156cc1d1fb2ea9ee"
cpu = {"AzureEditor.NodeAddition", "AzureEditor.Creation", "AzureEditor.SelectionService",
       "AzureEditor.PropertyEditing", "AzureRender.EditorSession"}
ctest = "D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe"

def verify_protected(protected, changed):
    current = snapshot()
    assert all(current["files"].get(name) == value for name, value in protected["files"].items())
    assert all(current["status"].get(name) == value for name, value in protected["status"].items())
    assert not set(changed) & current["status"].keys()
    return current


def execute(name, command, seconds):
    print(name, flush=True)
    with (run / (name+".log")).open("wb") as log:
        subprocess.run(command, cwd=source, env=os.environ.copy(), stdout=log,
                       stderr=subprocess.STDOUT, check=True, timeout=seconds)


def main():
    composition = json.loads((run / "composition.json").read_bytes())
    resume = (run / "reboot-continuation.json").is_file()
    protected_file = "protected-workspace-pre-resume.json" if resume else "protected-workspace.json"
    protected = json.loads((run / protected_file).read_bytes())
    verify_protected(protected, composition["files"])
    assert digest(binary) == expected
    assert not subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=run / "source")
    inputs = {}
    # The merge adds documentation to the tested editor tree. Verify the executable source inputs.
    tracked = git("ls-tree", "-rz", composition["editor"], "--", "Project/AzureRender/src",
                  "Project/AzureRender/shaders", "Project/AzureRender/third_party").split(b"\0")
    editor_source = build.parents[1]
    for entry in tracked:
        if not entry:
            continue
        header, encoded_path = entry.split(b"\t", 1)
        name = encoded_path.decode().removeprefix("Project/AzureRender/")
        expected_blob = header.split()[-1].decode()
        content = (editor_source / name).read_bytes()
        def blob(data):
            return sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
        assert expected_blob in (blob(content), blob(content.replace(b"\r\n", b"\n"))), name
        inputs[name] = sha256(content).hexdigest()
    for name in ("test_editor_selection.py", "test_editor_properties.py", "test_editor_node_addition.py"):
        assert (source / "tools" / name).read_bytes().replace(b"\r\n", b"\n") == (
            editor_source / "tools" / name).read_bytes().replace(b"\r\n", b"\n"), name
    (run / "execution-inputs.json").write_text(json.dumps(dict(executable=str(binary),
        sha256=expected, sourceInputs=inputs, sourceCommit=composition["editor"],
        composition=composition["commit"]), indent=2), encoding="utf-8")
    driver = subprocess.check_output(["C:/Windows/System32/nvidia-smi.exe",
        "--query-gpu=driver_version", "--format=csv,noheader"], text=True).strip()
    assert driver == "595.79"
    os.environ["VK_LOADER_DRIVERS_SELECT"] = "*nv-vk64*"
    install = engine / "build/ninja-msvc-debug/vcpkg_installed/x64-windows"
    os.environ["PATH"] = os.pathsep.join([str(build), str(install / "bin"), os.environ["PATH"]])
    registry = json.loads(subprocess.check_output([ctest, "--test-dir", str(build), "--show-only=json-v1"]))
    selected = [item for item in registry["tests"] if item["name"] in cpu]
    assert len(selected) == len(cpu)
    if not resume:
        execute("cpu", [ctest, "--test-dir", str(build), "--output-on-failure", "--no-tests=error",
            "--parallel", "1", "--output-junit", str(run / "cpu.xml"), "-R",
            "^("+ "|".join(re.escape(name) for name in sorted(cpu))+")$"], 300)
    cases = ET.parse(run / "cpu.xml").findall(".//testcase")
    assert {item.get("name") for item in cases} == cpu
    assert all(item.find("failure") is None and item.find("skipped") is None for item in cases)
    checks = [("selection", "test_editor_selection.py"),
                          ("properties-after-restart" if resume else "properties", "test_editor_properties.py"),
                          ("creation", "test_editor_node_addition.py")]
    for label, script in checks:
        if resume and label == "selection":
            continue
        execute(label, [sys.executable, "-B", "-X", "utf8", str(source / "tools" / script),
                "--executable", str(binary), "--output", str(run / label)], 1100)
    assert digest(binary) == expected
    observed = verify_protected(protected, composition["files"])
    assert not subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=run / "source")
    reports = {path.relative_to(run).as_posix(): json.loads(path.read_bytes())
        for label, _ in checks
        for path in (run / label).rglob("summary.json")}
    assert reports
    for name, report in reports.items():
        rows = report if isinstance(report, list) else [report]
        assert all(row.get("passed") is True for row in rows), (name, report)
    result = dict(passed=True, commit=composition["commit"], tree=composition["tree"],
        driver=driver, executable=str(binary), executableSha256=expected,
        cpu=sorted(cpu), cpuJUnit=digest(run / "cpu.xml"), reports=reports,
        historicalDispatches=composition["historicalDispatches"], protectedPaths=len(protected["status"]),
        physicalInput=False)
    result["observedUnrelatedLocalPaths"] = sorted(set(observed["status"]) - set(protected["status"]))
    (run / "qualification.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print("Affected editor regression passed.", flush=True)


if __name__ == "__main__":
    main()
