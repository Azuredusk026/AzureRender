"""Prepare the isolated editor integration and preserve the main checkout."""
from hashlib import sha256, file_digest
import json
import os
from pathlib import Path
import subprocess
import tempfile
from zipfile import ZipFile

run = Path(__file__).resolve().parent
repo = Path("D:/Projects/FYP")
engine = repo / "Project/AzureRender"
base = "dbe4ab3"
editor = "5d4cf7d"
prefix = "Project/AzureRender/"


def git(*args, env=None, data=None):
    return subprocess.check_output(["git", "-c", "core.autocrlf=false", *args], cwd=repo, env=env, input=data)


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def snapshot():
    status = git("status", "--porcelain=v1", "-z", "--untracked-files=normal").decode().split("\0")
    paths = {line[3:]: line[:2] for line in status if line}
    files = {}
    for name in paths:
        target = repo / name
        if target.is_dir():
            for item in sorted(target.rglob("*")):
                if item.is_file():
                    files[item.relative_to(repo).as_posix()] = digest(item)
        else:
            files[name] = digest(target)
    return dict(status=paths, files=files)


def main():
    assert git("rev-parse", "--short=7", "HEAD").decode().strip() == base
    assert not git("diff", "--cached", "--name-only")
    before = snapshot()
    assert sum(value != "??" for value in before["status"].values()) == 28
    assert sum(value == "??" for value in before["status"].values()) == 2
    (run / "protected-workspace.json").write_text(json.dumps(before, indent=2), encoding="utf-8")
    common = git("merge-base", base, editor).decode().strip()
    assert common.startswith("783889f")
    git("merge-base", "--is-ancestor", "e729305", editor)
    assert git("log", "--format=%h", common+".."+editor).decode().splitlines() == ["5d4cf7d", "e729305"]
    tree = git("merge-tree", "--write-tree", base, editor).decode().strip()
    assert tree == "271036aaffed05620a57eebf11cd25295d5385a9"
    patch = git("diff", "--binary", common, editor)
    (run / "editor.patch").write_bytes(patch)
    with tempfile.TemporaryDirectory(dir=run, prefix="index-") as scratch:
        env = dict(os.environ, GIT_INDEX_FILE=str(Path(scratch) / "index"))
        git("read-tree", base, env=env)
        process = subprocess.run(["git", "apply", "--cached", "--binary", "-"], cwd=repo, env=env, input=patch, capture_output=True)
        assert process.returncode == 0, process.stderr
        assert git("write-tree", env=env).decode().strip() == tree
    changed = git("diff", "--name-only", base, tree).decode().splitlines()
    intersection = sorted(set(changed) & before["status"].keys())
    assert not intersection, intersection
    assert git("diff", "--name-only", editor, tree).decode().splitlines() == [
        prefix+"docs/acceptance/nr/joint-nonlocal-texture-placement.md"]
    ref = "refs/heads/codex/editor-mainline-composed-20261119"
    assert not git("for-each-ref", "--format=%(refname)", ref).strip()
    commit = git("commit-tree", tree, "-p", base, "-p", editor,
        data="feat(p0): 集成层级搜索恢复与节点引用定位\n".encode()).decode().strip()
    git("update-ref", ref, commit, "0"*40)
    archives = []
    for task, pattern in [(1475, "20261116-155429-editor-outliner-selection-reveal-*.zip"),
                          (1497, "20261116-171608-editor-node-reference-reveal-*.zip")]:
        archive, = (engine / "build/maintenance/evidence").glob(pattern)
        with ZipFile(archive) as z:
            assert z.testzip() is None
            selected = [name for name in z.namelist() if name.endswith(("summary.json", "verify.cmd", "release-ctest.log", "integration-receipt.json"))]
            summaries = {}
            for name in selected:
                if name.endswith("/summary.json") and ("/candidate-" in name if task == 1475 else "/properties/" in name or "/selection/" in name):
                    summaries[name] = json.loads(z.read(name))
            archives.append(dict(dispatch=task, path=str(archive), sha256=digest(archive),
                                 entries=selected, summaries=summaries))
    (run / "historical-evidence.json").write_text(json.dumps(archives, indent=2), encoding="utf-8")
    info = dict(base=git("rev-parse", base).decode().strip(), editor=git("rev-parse", editor).decode().strip(),
                common=common, tree=tree, commit=commit, ref=ref, patchSha256=sha256(patch).hexdigest(),
                files=changed, intersections=intersection, historicalDispatches=[1475,1497])
    (run / "composition.json").write_text(json.dumps(info, indent=2), encoding="utf-8")
    assert snapshot() == before
    print(json.dumps(info, indent=2))


if __name__ == "__main__":
    main()
