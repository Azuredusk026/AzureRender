"""Publish the verified composition while retaining every main-checkout local edit."""
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile

from prepare import run, repo, engine, git, digest, snapshot, prefix
from qualify import verify_protected

receipt_root = prefix+"docs/plans/editor-integration-2026-11-19/"
evidence_commit = "51f6f89"
documentation = "docs/acceptance/p0/2026-11-19-editor-hierarchy-integration.md"
evidence_dir = "docs/acceptance/p0/evidence/2026-11-19-editor-hierarchy-integration/"


def main():
    proof = json.loads((run / "qualification.json").read_bytes())
    composition = json.loads((run / "composition.json").read_bytes())
    protected = json.loads((run / "protected-workspace-pre-resume.json").read_bytes())
    before = verify_protected(protected, composition["files"])
    (run / "protected-workspace-pre-integration.json").write_text(json.dumps(before,indent=2),encoding="utf-8")
    assert proof["passed"] and proof["commit"] == composition["commit"]
    assert len(proof["cpu"]) == 5 and proof["cpuJUnit"] == digest(run / "cpu.xml")
    assert digest(Path(proof["executable"])) == proof["executableSha256"]
    assert snapshot() == before
    assert not git("diff", "--cached", "--name-only")
    assert git("rev-parse", "HEAD").decode().strip() == composition["base"]
    old_receipt = git("show", evidence_commit+":"+receipt_root+"integration-receipt.json")
    assert sha256(old_receipt).hexdigest() == "16a9dc7769ac7f7b59f59a03fc2523a80941fb4b9e00176d19eb401b1c83ceb2"
    old = json.loads(old_receipt)
    assert old["targetTree"] == composition["tree"] and old["editor"] == composition["editor"]
    for item in old["evidence"]:
        assert digest(Path(item["archive"])) == item["archiveSha256"]
        for name, fingerprint in item["localCopies"].items():
            data = git("show", evidence_commit+":"+receipt_root+f'dispatch-{item["dispatch"]}/'+name)
            assert sha256(data).hexdigest() == fingerprint
    merged = git("merge-tree", "--write-tree", composition["base"], evidence_commit).decode().strip()
    delta = git("diff", "--name-only", composition["tree"], merged).decode().splitlines()
    assert delta and all(path.startswith(prefix+"docs/") for path in delta)
    out = run / "delivery"
    out.mkdir()
    archive = out / "verification.zip"
    sources = {name:run/name for name in ("prepare.py", "qualify.py", "deliver.py", "composition.json",
        "historical-evidence.json", "protected-workspace.json", "protected-workspace-pre-resume.json",
        "protected-workspace-pre-integration.json",
        "execution-inputs.json", "editor.patch", "cpu.log", "cpu.xml", "selection.log",
        "properties-after-restart.log", "creation.log", "qualification.json", "reboot-continuation.json",
        "ctest-path-failure.log", "ctest-path-failure-dispatch.json", "reboot-interrupted-process.log",
        "post-reboot.stdout.log")}
    for label in ("selection", "properties-after-restart", "creation"):
        for item in (run / label).rglob("summary.json"):
            sources[item.relative_to(run).as_posix()] = item
    for item in (run / "properties-after-restart").glob("locate-node-*/*.png"):
        sources[item.relative_to(run).as_posix()] = item
    for item in (run / "selection").glob("*/**/outliner-*.png"):
        sources[item.relative_to(run).as_posix()] = item
    members = {key:digest(path) for key,path in sources.items()}
    with ZipFile(archive, "x", ZIP_DEFLATED, compresslevel=6) as z:
        for key,path in sorted(sources.items()):
            z.write(path,key)
    with ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist()) == set(members)
        assert all(sha256(z.read(name)).hexdigest() == fingerprint for name,fingerprint in members.items())
    assert archive.stat().st_size < 8*2**20
    index = dict(passed=True, base=composition["base"], editor=composition["editor"],
        testedComposition=composition["commit"], testedTree=composition["tree"],
        evidenceCommit=git("rev-parse",evidence_commit).decode().strip(),
        evidenceReceiptSha256=sha256(old_receipt).hexdigest(), candidatePatch=composition["patchSha256"],
        configuration="Release", driver=proof["driver"], executable=proof["executableSha256"],
        cpu=proof["cpu"], replaySummaries=proof["reports"], physicalInput=False,
        protectedLocalPaths=before["status"], externallyUpdatedPaths=json.loads((run/"reboot-continuation.json").read_bytes())["externallyUpdatedPaths"],
        archive=dict(sha256=digest(archive), files=members),
        limitations=["实体键鼠、输入法和多屏由现场复核。"])
    result=(json.dumps(index,ensure_ascii=False,indent=2)+"\n").encode()
    (out/"results.json").write_bytes(result)
    document = """# 层级搜索与节点引用集成

主线包含层级搜索恢复与节点引用定位。
定位引用时，层级面板打开并展开目标路径。
返回搜索恢复同一场景文档的筛选结果。

Release 的 5 项关联 CPU 检查通过。
探索和资产检视项目完成选择与搜索回放。
两项目的属性回放核对引用定位、拾取和取消。
创建回放覆盖两项目和两种界面缩放。
回放核对场景文件、保存重开及撤销状态。

组合程序沿用已验收的可执行文件。
程序摘要与批次 1497 的提交内索引一致。
组合树相对候选的运行源码逐项核对。
历史矩阵按来源及受影响范围复用。

本次回放通过生产界面的自动输入执行。
实体键鼠、输入法和多屏由现场复核。
房间正式回归、Steam 实机与论文采集保持暂停。

[来源回执](../../plans/editor-integration-2026-11-19/README.md)
[本次验收](evidence/2026-11-19-editor-hierarchy-integration/results.json)
[验证归档](evidence/2026-11-19-editor-hierarchy-integration/verification.zip)
"""
    readme = git("show", merged+":"+prefix+"README.md")
    first = readme.index(b"\n")+1
    link=f"\n[层级搜索与节点引用集成]({documentation})记录两项目回放及关联检查。\n".encode()
    files = {prefix+documentation:document.encode(), prefix+evidence_dir+"results.json":result,
             prefix+evidence_dir+"verification.zip":archive.read_bytes(),
             prefix+"README.md":readme[:first]+link+readme[first:]}
    with tempfile.TemporaryDirectory(dir=run,prefix="delivery-index-") as temporary:
        env=dict(os.environ,GIT_INDEX_FILE=str(Path(temporary)/"index"))
        git("read-tree",merged,env=env)
        for name,data in files.items():
            oid=git("hash-object","-w","--stdin","--no-filters",data=data).decode().strip()
            git("update-index","--add","--cacheinfo","100644",oid,name,env=env)
        git("diff","--cached","--check",composition["base"],env=env)
        tree=git("write-tree",env=env).decode().strip()
    changed=git("diff","--name-only",composition["base"],tree).decode().splitlines()
    assert not set(changed)&before["status"].keys()
    commit=git("commit-tree",tree,"-p",composition["base"],"-p",evidence_commit,
        data="feat(p0): 集成层级搜索恢复与节点引用定位\n".encode()).decode().strip()
    ref="refs/heads/codex/editor-mainline-delivery-20261119"
    git("update-ref",ref,commit,"0"*40)
    assert snapshot()==before
    # Git checks the local checkout conflicts before writing any path.
    git("read-tree","--dry-run","-u","-m","HEAD",commit)
    print(git("merge","--ff-only","--no-autostash",commit).decode(errors="replace"),flush=True)
    assert git("rev-parse","HEAD").decode().strip()==commit
    assert snapshot()==before
    assert not git("diff","--cached","--name-only")
    for name,data in files.items():
        assert (repo/name).read_bytes()==data
    receipt=dict(commit=commit,tree=tree,base=composition["base"],editor=composition["editor"],
        evidenceCommit=index["evidenceCommit"],testedComposition=composition["commit"],
        archive=digest(archive),changed=changed,protectedPaths=len(before["status"]),passed=True)
    (run/"mainline-integration.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(receipt,indent=2),flush=True)


if __name__ == "__main__":
    main()
