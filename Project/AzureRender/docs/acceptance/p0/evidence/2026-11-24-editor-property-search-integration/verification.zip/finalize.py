from pathlib import Path
import hashlib,json,re,sqlite3,subprocess,zipfile
import xml.etree.ElementTree as ET

run=Path(__file__).resolve().parent
repo=Path("D:/Projects/FYP")
engine=repo/"Project/AzureRender"
dest=engine/"docs/acceptance/p0/evidence/2026-11-24-editor-property-search-integration"
def read(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)

composition=read(run/"composition-plan.json")
applied=read(run/"applied.json")["worktreeSha256"]
protected=read(run/"protected.json")
product=read(run/"product.json")
assert all(sha(repo/n)==h for n,h in applied.items())
assert all(sha(repo/n)==h for n,h in protected.items())
assert all(sha(repo/n)==h for n,h in read(run/"execution-inputs.json").items())
assert sha(Path(product["executable"]))==product["sha256"]
staged=set(git("diff","--cached","--name-only").decode().splitlines())
allowed=set(composition["paths"])|{"Project/AzureRender/README.md",
    "Project/AzureRender/docs/acceptance/p0/2026-11-24-editor-property-search-integration.md",
    (dest/"results.json").relative_to(repo).as_posix(),(dest/"verification.zip").relative_to(repo).as_posix()}
assert staged<=allowed,staged-allowed
cpu=ET.parse(run/"cpu.xml").getroot()
cpu_names=[n.attrib["name"] for n in cpu.iter("testcase")]
assert set(cpu_names)=={"AzureEditor.EditTransaction","AzureEditor.PropertyEditing"}
assert not list(cpu.iter("failure")) and not list(cpu.iter("skipped"))
multi,=list((run/"property-workflow").glob("run-*/summary.json"))
ref=run/"reference-search/summary.json"
workflow={}
for p in [multi,ref]:
    s=read(p)
    assert s["executableSha256"]==product["sha256"]
    assert [c["workflow"] for c in s["cases"]]==["exploration","inspector"]
    assert all(c["passed"] and not c["physicalInput"] for c in s["cases"])
    workflow[str(p.relative_to(run))]=s["cases"]
assert all(c["dragFocusLossCancels"] and c["undoRedo"] and c["saveReopen"] for c in read(multi)["cases"])
with sqlite3.connect("file:D:/Projects/FYP-coordination/resources/dispatch.sqlite3?mode=ro",uri=True) as db:
    db.row_factory=sqlite3.Row
    jobs=[dict(r) for r in db.execute("SELECT id,task,state,exit_code,reason,run_seconds FROM jobs WHERE output=? ORDER BY id",(str(run),))]
assert any(j["task"]=="mainline-editor-property-composition-build" and j["state"]=="succeeded" for j in jobs),jobs
assert any(j["task"]=="mainline-editor-property-replays" and j["state"]=="succeeded" for j in jobs),jobs
write(run/"dispatch.json",jobs)
dest.mkdir(parents=True,exist_ok=True)
files={n:run/n for n in ["verify.py","finalize.py","composition-plan.json","applied.json","historical-bundles.json",
    "execution-inputs.json","product.json","environment.json","dispatch.json","build.log","cpu.xml","cpu.log",
    "build-command.json","cpu-command.json","property-workflow-command.json","reference-search-command.json",
    "property-workflow.log","reference-search.log"]}
for p in [multi,ref]:files[p.relative_to(run).as_posix()]=p
manifest={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()}
zip_path=dest/"verification.zip"
with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,p in files.items():z.write(p,n)
    z.writestr("manifest.json",json.dumps(manifest,indent=2))
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None and set(z.namelist())==set(files)|{"manifest.json"}
    assert all(hashlib.sha256(z.read(n)).hexdigest()==m["sha256"] for n,m in manifest.items())
write(dest/"results.json",dict(base=product["base"],editorCandidate=git("rev-parse",composition["editorTip"]).decode().strip(),
    runtimeProduct=product,compiledFrom="local mainline candidate tree with preserved local modifications",
    nativeDriver=read(run/"environment.json")["driver"],cpuChecks=cpu_names,automatedWorkflows=workflow,
    sourceInputCount=len(read(run/"execution-inputs.json")),historicalBundles=composition["historicalEvidence"],
    protectedFiles=len(protected),integrationPaths=composition["paths"],localPlanProtected=composition["excluded"],
    manualState="待人工复验",jobs=jobs,archive=dict(sha256=sha(zip_path),bytes=zip_path.stat().st_size,members=len(files)+1)))
doc=engine/"docs/acceptance/p0/2026-11-24-editor-property-search-integration.md"
s=doc.read_text(encoding="utf-8")
assert all((doc.parent/n).exists() for n in re.findall(r"\]\(([^)]+)\)",s))
assert all(len(re.findall(r"[\u4e00-\u9fff]",part))<=45 for part in re.split(r"[。！？\n]",s))
print("Verified",len(cpu_names),"CPU checks and four replay cases across two projects")
