from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

run = Path(__file__).resolve().parent
root = Path("D:/Projects/FYP")
engine = root/"Project/AzureRender"
build = engine/"build/ninja-msvc-release"
exe = build/"AzureRender.exe"
env = os.environ.copy()
env["DOTNET_ROOT"] = "D:/Tools/dotnet9"
env["PATH"] = env["DOTNET_ROOT"] + os.pathsep + "D:/Tools/Python311" + os.pathsep + env["PATH"]
env["VK_LOADER_DRIVERS_SELECT"] = "*nv-vk64*"

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, value):
    (run/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

def verify_applied():
    applied=json.loads((run/"applied.json").read_bytes())["worktreeSha256"]
    for name,sha in applied.items():
        assert digest(root/name)==sha,name

def runtime_inputs():
    names=subprocess.check_output(["git","ls-files","-z","--","Project/AzureRender/src","Project/AzureRender/shaders"],cwd=root)
    return {name.decode():digest(root/name.decode()) for name in names.split(b"\x00") if name}

def execute(name, args, timeout):
    write(name+"-command.json",args)
    with (run/(name+".log")).open("wb") as log:
        subprocess.run(args,cwd=engine,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=timeout)

if sys.argv[1]=="build":
    verify_applied()
    inputs=runtime_inputs()
    execute("build",[str(engine/"tools/msvc_env.bat"),"cmake","--build",str(build),"--target",
        "AzureRender","AzureEditTransactionTests","AzurePropertyEditingTests","-j","3"],680)
    ctest="D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe"
    execute("cpu",[ctest,"--test-dir",str(build),"-R","^AzureEditor[.](EditTransaction|PropertyEditing)$",
                   "--output-on-failure","--output-junit",str(run/"cpu.xml")],90)
    verify_applied()
    assert runtime_inputs()==inputs
    write("execution-inputs.json",inputs)
    write("product.json",dict(executable=str(exe),sha256=digest(exe),patchSha256=digest(run/"composed.patch"),
        base=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()))
elif sys.argv[1]=="gpu":
    verify_applied()
    product=json.loads((run/"product.json").read_bytes())
    assert digest(exe)==product["sha256"]
    record=subprocess.check_output(["C:/Windows/System32/nvidia-smi.exe","--query-gpu=driver_version,name",
                                     "--format=csv,noheader"],text=True).strip()
    assert record.startswith("595.79"),record
    write("environment.json",dict(driver=record))
    py=str(engine/"build/reinstall-environment/venv/Scripts/python.exe")
    for name, tool in [("property-workflow","test_editor_multi_properties.py"),
                       ("reference-search","test_editor_reference_search.py")]:
        execute(name,[py,str(engine/"tools"/tool),"--executable",str(exe),"--output",str(run/name)],400)
    assert digest(exe)==product["sha256"]
else:
    raise ValueError(sys.argv[1])
