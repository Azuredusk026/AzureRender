from hashlib import file_digest
import json
from pathlib import Path
import subprocess
import sys
import time

def digest(path):
    with path.open("rb") as source:
        return file_digest(source, "sha256").hexdigest()

run = Path(__file__).resolve().parent
root = run.parents[4]
engine = root / "Project/AzureRender"
prior = run.parent / "20261124-022125-mainline-editor-property-search-d05aad"
product = json.loads((prior / "product.json").read_text(encoding="utf-8"))
exe = Path(product["executable"])
before = digest(exe)
assert before == product["sha256"], "Release editor differs from the integrated product"
cases = {
    "viewport-workflow": "test_editor_usability.py",
    "document-recovery": "test_editor_document_guard.py",
    "view-modes": "test_editor_view_modes.py",
}
runners = {name: engine / "tools" / filename for name, filename in cases.items()}
runner_hashes = {name: digest(path) for name, path in runners.items()}
changed_since_build = [name for name, expected in json.loads(
    (prior / "execution-inputs.json").read_text(encoding="utf-8")
).items() if not (root / name).is_file() or digest(root / name) != expected]
receipt = dict(productSha256=before, source="0d56968e0defae85f88aff5990adb0c124b9a47b",
               configuration="Release", physicalInput=False, runnerSha256=runner_hashes,
               changedWorkingInputsSinceProduct=changed_since_build, checks=[])
for name, runner in runners.items():
    command = [sys.executable, "-B", "-X", "utf8", str(runner),
               "--executable", str(exe), "--output", str(run / name)]
    started = time.monotonic()
    print(f"Running {name}", flush=True)
    with (run / f"{name}.log").open("w", encoding="utf-8") as log:
        status = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, cwd=root, timeout=135)
    receipt["checks"].append(dict(name=name, command=command, exitCode=status.returncode,
                                  seconds=round(time.monotonic() - started, 3)))
    (run / "checks.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    if status.returncode:
        print((run / f"{name}.log").read_text(encoding="utf-8", errors="replace")[-4500:], flush=True)
        sys.exit(status.returncode)
    print(f"Passed {name}", flush=True)
assert before == digest(exe)
assert all(digest(runners[name]) == expected for name, expected in runner_hashes.items())
receipt["passed"] = True
(run / "checks.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
