from pathlib import Path
import hashlib,json,os,subprocess
import xml.etree.ElementTree as ET

run=Path(__file__).resolve().parent
repo=Path("D:/Projects/FYP")
engine=repo/"Project/AzureRender"
build=engine/"build/ninja-msvc-debug"
env=os.environ.copy()
env["DOTNET_ROOT"]="D:/Tools/dotnet9"
env["PATH"]=env["DOTNET_ROOT"]+os.pathsep+"D:/Tools/Python311"+os.pathsep+env["PATH"]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(["git",*a],cwd=repo)
def write(name,value):(run/name).write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8")
source=git("rev-parse","HEAD").decode().strip()
assert source.startswith("0d56968")
inputs={n.decode():sha(repo/n.decode()) for n in git("ls-files","-z","--",
    "Project/AzureRender/src","Project/AzureRender/shaders").split(b"\x00") if n}
targets=["AzureTextureMipCoverageTests","AzureSampledTextureCacheTests","AzureEditTransactionTests","AzurePropertyEditingTests"]
build_cmd=[str(engine/"tools/msvc_env.bat"),"cmake","--build",str(build),"--target",*targets,"-j","3"]
ctest="D:/Tools/VS2022BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/ctest.exe"
test_cmd=[ctest,"--test-dir",str(build),"-R",
    "^(AzureRender[.](TextureMipCoverage|SampledTextureCache)|AzureEditor[.](EditTransaction|PropertyEditing))$",
    "--output-on-failure","--output-junit",str(run/"cpu.xml")]
write("commands.json",{"build":build_cmd,"ctest":test_cmd})
for label,command,timeout in [("build",build_cmd,720),("cpu",test_cmd,90)]:
    with (run/(label+".log")).open("wb") as log:
        subprocess.run(command,cwd=engine,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,check=True)
assert all(sha(repo/n)==h for n,h in inputs.items())
checks=ET.parse(run/"cpu.xml").getroot()
tests=[v.attrib["name"] for v in checks.iter("testcase")]
assert len(tests)==4 and not list(checks.iter("failure")) and not list(checks.iter("skipped"))
write("execution-inputs.json",inputs)
write("results.json",dict(source=source,configuration="Debug",tests=tests,inputCount=len(inputs),
    artifacts={n:sha(build/(n+".exe")) for n in targets}))
print("All four affected Debug checks passed",flush=True)
