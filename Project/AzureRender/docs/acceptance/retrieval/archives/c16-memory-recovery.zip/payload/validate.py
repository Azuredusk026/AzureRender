from pathlib import Path
import subprocess,json,hashlib,re,time
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parent; E=R.parents[2]
R8=R.parent/'20261023-105023-character-composite-contribution-diagnosis-acb8e5'
R7=R.parent/'20261023-093843-character-multipixel-input-diagnosis-92843a'
OLD=R.parent/'20261022-051129-character-logistics-restoration-0f2e71'
report={'schemaVersion':1,'status':'running','cpu':[],'gpu':[]}
def save(): (R/'validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
for config in ['release','debug']:
    command=['ctest','--test-dir',str(E/f'build/ninja-msvc-{config}'),'-R','^(AzureRuntime.SceneRenderSnapshot|AzureEditor.MaterialSlotEditing|AzureEngine.RegisteredComponentWorkflow|AzureTools.NativeCapturePixels|AzureTools.NativeNprLighting)$','--output-on-failure']
    with (R/f'cpu-{config}.log').open('w') as log: subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    report['cpu'].append({'config':config,'tests':5,'passed':True});save();print('CPU '+config+' passed',flush=True)
for config in ['release','debug']:
    command=['python',str(E/'tools/test_material_override_gpu.py'),'--executable',str(E/f'build/ninja-msvc-{config}/AzurePlayer.exe'),'--output',str(R/f'material-override-{config}')]
    with (R/f'material-override-{config}.log').open('w') as log: subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1200)
    report['gpu'].append({'name':'material-override-'+config,'captures':8,'passed':True});save();print('GPU material override '+config+' passed',flush=True)
cases=[('control','release',R8/'contributions.azureproject',2560,1440,R8/'beauty-raw/frames/frame_000000.png'),('sparse','release',R8/'authored-rim.azureproject',2560,1440,R8/'beauty-authored-rim/frames/frame_000000.png'),('full','release',R8/'full-authored-rim.azureproject',2560,1440,R/'sparse/frames/frame_000000.png'),('sparse-fixed','debug',R8/'authored-rim.azureproject',2560,1440,R/'sparse/frames/frame_000000.png'),('graded','release',R8/'graded-authored-rim.azureproject',2560,1440,None),('main','release',OLD/'joint-candidate/project.azureproject',1280,720,R7/'main-project/frames/frame_000000.png')]
for name,config,project,width,height,reference in cases:
    out=R/name;out.mkdir();player=E/f'build/ninja-msvc-{config}/AzurePlayer.exe'
    command=[str(player),'--project',str(project),'--width',str(width),'--height',str(height),'--capture-dir',str(out/'frames'),'--capture-frames','1','--fixed-frame-step','--qa-camera','scene','--qa-light','scene','--qa-isolation','beauty','--runtime-report',str(out/'runtime.json')]
    if config=='debug':command+=['--disable-bindless','--disable-compute-skinning','--disable-parallel-recording']
    (out/'command.json').write_text(json.dumps(command,indent=2));print('Capture '+name,flush=True);start=time.monotonic()
    with (out/'player.log').open('w',encoding='utf-8') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=360)
    log=(out/'player.log').read_text(encoding='utf-8',errors='replace');assert not re.search(r'VUID-|Validation (?:Error|Warning)|\[error\]',log),name
    assert 'Allocator after unload: buffers=0 images=0' in log,name
    runtime=json.loads((out/'runtime.json').read_text());assert not runtime['scriptErrors'] and not runtime['presentationErrors']
    if config=='debug':assert 'Validation layer: enabled' in log
    frame=out/'frames/frame_000000.png';entry={'name':name,'config':config,'isolation':'beauty','passed':True,'seconds':round(time.monotonic()-start,2),'playerSha256':hashlib.sha256(player.read_bytes()).hexdigest(),'imageSha256':hashlib.sha256(frame.read_bytes()).hexdigest(),'resourceLines':[line for line in log.splitlines() if any(key in line for key in ['decodedMaterialPixelBytes','requestedSlots','Allocator after unload','Character texture access:'])]}
    if reference is not None:
        assert reference.exists(),str(reference)
        delta=np.abs(np.asarray(Image.open(frame)).astype(int)-np.asarray(Image.open(reference)).astype(int));entry['maximumByteDifference']=int(delta.max());assert delta.max()==0,(name,int(delta.max()))
    report['gpu'].append(entry);save()
report['status']='passed';save();print('All C16 recovery validations passed',flush=True)
