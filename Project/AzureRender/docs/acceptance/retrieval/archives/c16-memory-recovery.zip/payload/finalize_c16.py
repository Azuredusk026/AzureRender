from pathlib import Path
import json,hashlib,re
R=Path(__file__).resolve().parent;E=R.parents[2]
p=E/'docs/acceptance/nr/evidence/2026-10-23/character-composite-diagnosis.json'
receipt=json.loads(p.read_text());validation=json.loads((R/'validation.json').read_text());assert validation['status']=='passed'
receipt['status']='partial-material-input-and-snapshot-verified';receipt['currentSnapshotChange']='debug-release-cpu-and-gpu-verified';receipt['recoveryRun']=str(R.relative_to(E));receipt['recoveryValidation']=validation
receipt['visibleHairComparison']=json.loads((R/'visible-hair-comparison.json').read_text())
receipt['visibleHairComparison']['sourceHashes']={name:hashlib.sha256((R.parent/'20261023-105023-character-composite-contribution-diagnosis-acb8e5'/name).read_bytes()).hexdigest() for name in ['before-hair.bin','after-hair.bin','native-hair-visible-mask.png']}
receipt['processPeakSamples']=json.loads((R/'process-peaks.json').read_text(encoding='utf-8-sig'))
receipt['processPeakScope']='Sampled complete-document and fixed-path actual-character processes; per-view GPU peak pending'
receipt['verifiedSources']={name:hashlib.sha256((E/name).read_bytes()).hexdigest() for name in ['src/runtime/SceneRenderSnapshot.cpp','tests/SceneRenderSnapshotTests.cpp','tools/endfield_native/capture_pixels.py','tools/endfield_native/npr_lighting.py']}
receipt['remaining']=['C17 positive primary and ring shape','C18 production outline inputs','NR7 temporal history and final grading','C16 multi-view GPU residency budget','NR8-V2 production promotion and dynamics']
p.write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
plan=E/'docs/plans/2026-10-22-character-logistics-restoration.md';s=plan.read_text(encoding='utf-8')
s=s.replace('- [ ] 对照多个真实片元的颜色、法线、参数及材质帧。','- [x] 对照多个真实片元的颜色、法线、参数及材质帧。').replace('- [ ] 隔离环境、直接漫反射、双叶及边缘能量。','- [x] 隔离环境、直接漫反射、双叶及边缘能量。').replace('- [ ] 逐项核对实际执行分支及颜色组合顺序。','- [x] 逐项核对实际执行分支及颜色组合顺序。')
s=s.replace('状态：实施中。依据为真实角色覆盖的重复解码。','状态：分项完成。依据为真实角色覆盖的重复解码。')
s=s.replace('- [ ] 复验完整角色、两条描述符路径及峰值预算。','- [x] 复验完整角色、两条描述符路径及进程峰值。\n- [ ] 按 C16 总项测量多视图 GPU 常驻及峰值。').replace('- [ ] 回归材质编辑、预览、普通场景和资源释放。','- [x] 回归材质编辑、预览、普通场景和资源释放。')
s=s.replace('Release 构建及五组 CPU 检查通过。\n系统提交内存不足阻塞 Debug 与 GPU 回归。','双配置构建、各五组 CPU 及十六次 GPU 检查通过。\n六次实际捕获覆盖完整文档、固定路径及主场景。')
plan.write_text(s,encoding='utf-8')
handoff=E/'docs/plans/2026-10-22-native-render-restoration-handoff.md';s=handoff.read_text(encoding='utf-8').replace('当前完整验证受系统提交内存阻塞。','C16-R3 的双配置构建、CPU 及 GPU 回归通过。')
handoff.write_text(s,encoding='utf-8')
readme=E/'README.md';s=readme.read_text(encoding='utf-8');line='材质变体资源归属与实际片元核对见[合成验证](docs/acceptance/nr/character-composite-diagnosis.md)。\n'
if line not in s:s=s.replace('# AzureRender 工程\n','# AzureRender 工程\n\n'+line,1)
readme.write_text(s,encoding='utf-8')
changelog=E/'CHANGELOG.md';s=changelog.read_text(encoding='utf-8');s=s.replace('# Changelog\n','# Changelog\n\n## NR6 材质变体资源与片元核对 2026-10-23\n\n- 渲染快照保留实际消费的材质变体及原有几何顺序。\n- 生成标识与声明资源发生冲突时明确拒绝。\n- 实际角色覆盖的请求槽由 264 降至 138。\n- 解码材质像素由 711672516 降至 355836316 字节。\n- 双配置各五组 CPU、十六次 GPU 及六次实际捕获通过。\n- 原生零全局边缘光经现有参数覆盖接入，四点误差至多一字节。\n- 时间合成和完整环带形态继续按所属门禁验收。\n',1);changelog.write_text(s,encoding='utf-8')
layout=E/'docs/runtime/material-input-layout.md';s=layout.read_text(encoding='utf-8');s+='\n场景渲染快照保留节点消费的材质变体。\n普通实例引用基础资源时，基础资源参与布局。\n全部实例绑定覆盖时，首个变体保留源几何顺序。\n原始文档、不可见普通实例及其他声明资源保持完整。\n派生标识与声明资源冲突时，快照构建明确失败。\n验证范围见[资源与片元核对](../acceptance/nr/character-composite-diagnosis.md)。\n';layout.write_text(s,encoding='utf-8')
print('C16 receipt, plans, README, changelog and ownership contract synchronized')
